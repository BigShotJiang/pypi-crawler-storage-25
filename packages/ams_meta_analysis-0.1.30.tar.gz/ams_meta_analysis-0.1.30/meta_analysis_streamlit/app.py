"""Streamlit front end for the meta-analysis runner toolkit."""

from __future__ import annotations

import base64
import html
import json
import math
import mimetypes
import os
import platform
import queue
import re
import signal
import shutil
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass
from datetime import datetime
from io import BytesIO
from importlib import util as importlib_util
from importlib import metadata
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

PACKAGE_DIR = Path(__file__).resolve().parent
PACKAGE_ROOT = PACKAGE_DIR.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))


def load_local_binary_outcome_helpers() -> tuple[Any, Any, Any, Any]:
    module_path = PACKAGE_DIR / "runners" / "binary_outcome.py"
    runners_dir = str(module_path.parent)
    if runners_dir not in sys.path:
        sys.path.insert(0, runners_dir)
    spec = importlib_util.spec_from_file_location("_ams_local_binary_outcome", module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Could not load local binary_outcome.py from {module_path}")
    module = importlib_util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.detect_excel_header_row, module.load_sheet, module.make_unique_columns, module.default_mapping

try:
    from . import __version__ as PACKAGE_VERSION
except ImportError:  # Streamlit may execute this file as a plain script after installation.
    from meta_analysis_streamlit import __version__ as PACKAGE_VERSION

try:
    from .r_runtime import (
        MIN_R_VERSION,
        ensure_rscript_on_path,
        find_rscript,
        format_r_version,
        path_export_command,
        path_with_rscript,
        rscript_version,
    )
except ImportError:  # Streamlit may execute this file as a plain script after installation.
    from meta_analysis_streamlit.r_runtime import (
        MIN_R_VERSION,
        ensure_rscript_on_path,
        find_rscript,
        format_r_version,
        path_export_command,
        path_with_rscript,
        rscript_version,
    )

try:
    from .runners.binary_outcome import (
        default_mapping as default_binary_mapping,
        detect_excel_header_row,
        load_sheet as load_workbook_sheet,
        make_unique_columns,
    )
except ImportError:  # Streamlit may execute this file as a plain script after installation.
    try:
        from meta_analysis_streamlit.runners.binary_outcome import (
            default_mapping as default_binary_mapping,
            detect_excel_header_row,
            load_sheet as load_workbook_sheet,
            make_unique_columns,
        )
    except (ImportError, AttributeError):
        detect_excel_header_row, load_workbook_sheet, make_unique_columns, default_binary_mapping = load_local_binary_outcome_helpers()


APP_HOME = Path.home() / ".meta_analysis_streamlit"
RUNS_HOME = APP_HOME / "runs"
SECRETS_PATH = APP_HOME / "secrets.json"
SUPPORTED_INPUTS = {".csv", ".xls", ".xlsx", ".xlsm"}
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".gif", ".svg"}
ROUTES = [
    "Auto route workbook",
    "Binary pairwise",
    "Continuous pairwise",
    "Single-arm",
    "Diagnostic accuracy",
    "Network meta-analysis",
]
ROUTE_ALIASES = {
    "auto": "Auto route workbook",
    "auto route": "Auto route workbook",
    "auto route workbook": "Auto route workbook",
    "binary": "Binary pairwise",
    "binary_pairwise": "Binary pairwise",
    "binary pairwise": "Binary pairwise",
    "continuous": "Continuous pairwise",
    "continuous_pairwise": "Continuous pairwise",
    "continuous pairwise": "Continuous pairwise",
    "single": "Single-arm",
    "single_arm": "Single-arm",
    "single-arm": "Single-arm",
    "single arm": "Single-arm",
    "diagnostic": "Diagnostic accuracy",
    "diagnostic accuracy": "Diagnostic accuracy",
    "network": "Network meta-analysis",
    "network meta-analysis": "Network meta-analysis",
    "network meta analysis": "Network meta-analysis",
}
MAX_LLM_ROUTE_SHEETS = 40
LLM_ROUTE_SAMPLE_SHEETS = 8
LOCAL_LLM_PROVIDERS = {"LM Studio", "Ollama"}
OPENROUTER_FREE_MODELS = [
    "openrouter/free",
    "openai/gpt-oss-120b:free",
    "openai/gpt-oss-20b:free",
    "qwen/qwen3-coder:free",
    "qwen/qwen3-next-80b-a3b-instruct:free",
    "google/gemma-4-31b-it:free",
    "nvidia/nemotron-3-super-120b-a12b:free",
]


@dataclass
class LmStudioStatus:
    available: bool
    models: list[str]
    message: str


PROVIDER_DEFAULTS = {
    "LM Studio": {
        "base_url": "http://localhost:1234/v1",
        "key_envs": [],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "Ollama": {
        "base_url": "http://localhost:11434/v1",
        "key_envs": [],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "OpenAI": {
        "base_url": "https://api.openai.com/v1",
        "key_envs": ["OPENAI_API_KEY"],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "Gemini": {
        "base_url": "https://generativelanguage.googleapis.com/v1beta/openai",
        "key_envs": ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "OpenRouter Free": {
        "base_url": os.environ.get("OPENROUTER_BASE_URL", "https://openrouter.ai/api/v1"),
        "key_envs": ["OPENROUTER_API_KEY"],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "Custom OpenAI-compatible": {
        "base_url": os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1"),
        "key_envs": ["META_ANALYSIS_LLM_API_KEY", "OPENAI_API_KEY"],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
    "Manual/no LLM": {
        "base_url": "",
        "key_envs": [],
        "auth_header": "Authorization",
        "auth_prefix": "Bearer",
    },
}


def runners_dir() -> Path:
    return Path(__file__).resolve().parent / "runners"


def runner_script(name: str) -> Path:
    return runners_dir() / name


def apply_theme() -> None:
    st.markdown(
        """
        <style>
        :root {
            --ma-bg: #f7f8fb;
            --ma-panel: #ffffff;
            --ma-border: #d9dee8;
            --ma-text: #18202f;
            --ma-muted: #5f6b7a;
            --ma-accent: #005fcc;
            --ma-accent-hover: #004aa3;
            --ma-accent-soft: #e6f0ff;
            --ma-good: #087443;
            --ma-warn: #8a4b00;
            --ma-bad: #b42318;
            --ma-button-bg: #ffffff;
            --ma-button-text: #0c1b32;
            --ma-button-border: #6b7c93;
            --ma-button-hover-bg: #d9ecff;
            --ma-button-hover-text: #003b73;
            --ma-disabled-bg: #d7dee9;
            --ma-disabled-text: #39475a;
            --ma-disabled-border: #9aa8ba;
        }
        .stApp {
            background:
                linear-gradient(180deg, #f7f9fc 0%, #f3f6fa 260px, #f7f8fb 100%);
            color: var(--ma-text);
        }
        .block-container {
            padding-top: 1.8rem;
            padding-bottom: 3rem;
            max-width: 1280px;
        }
        [data-testid="stSidebar"] {
            background: #101827;
            --ma-button-bg: #f8fbff;
            --ma-button-text: #071426;
            --ma-button-border: #a7bdd5;
            --ma-button-hover-bg: #cfe7ff;
            --ma-button-hover-text: #002e5c;
            --ma-disabled-bg: #2c394d;
            --ma-disabled-text: #d2dbea;
            --ma-disabled-border: #59687d;
        }
        [data-testid="stSidebar"] * {
            color: #edf2f7;
        }
        [data-testid="stSidebar"] .stTextInput input,
        [data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div,
        [data-testid="stSidebar"] textarea {
            background: #172235;
            border-color: #31435f;
            color: #ffffff;
        }
        [data-testid="stSidebar"] code {
            color: #dce8f7;
        }
        [data-testid="stAppViewContainer"] [data-testid="stWidgetLabel"] p,
        [data-testid="stAppViewContainer"] label,
        [data-testid="stAppViewContainer"] .stMarkdown p {
            color: #233044;
        }
        [data-testid="stAppViewContainer"] [data-testid="stAlert"] {
            background: #eaf3ff;
            border: 1px solid #8bbff5;
            color: #10243f;
        }
        [data-testid="stAppViewContainer"] [data-testid="stAlert"] p,
        [data-testid="stAppViewContainer"] [data-testid="stAlert"] div,
        [data-testid="stAppViewContainer"] [data-testid="stAlert"] span {
            color: #10243f !important;
        }
        .ma-upload-empty {
            border: 1px solid #8bbff5;
            background: #eaf3ff;
            color: #10243f;
            border-radius: 8px;
            padding: 0.85rem 1rem;
            font-weight: 750;
            margin: 0.45rem 0 1rem;
        }
        [data-testid="stSidebar"] [data-testid="stWidgetLabel"] p,
        [data-testid="stSidebar"] label,
        [data-testid="stSidebar"] .stMarkdown p {
            color: #edf2f7;
        }
        [data-testid="stAppViewContainer"] div[data-testid="stButton"] button {
            background: var(--ma-button-bg) !important;
            color: var(--ma-button-text) !important;
            border: 1.5px solid var(--ma-button-border) !important;
            border-radius: 7px;
            min-height: 3.2rem;
            font-weight: 800;
            box-shadow: 0 1px 3px rgba(24, 32, 47, 0.16);
        }
        [data-testid="stAppViewContainer"] div[data-testid="stDownloadButton"] button {
            background: var(--ma-button-bg) !important;
            color: var(--ma-button-text) !important;
            border: 1.5px solid var(--ma-button-border) !important;
            border-radius: 7px;
            min-height: 3.2rem;
            font-weight: 800;
            box-shadow: 0 1px 3px rgba(24, 32, 47, 0.16);
        }
        div[data-testid="stButton"] button p,
        div[data-testid="stButton"] button span,
        div[data-testid="stDownloadButton"] button p,
        div[data-testid="stDownloadButton"] button span {
            color: inherit !important;
        }
        [data-testid="stAppViewContainer"] div[data-testid="stButton"] button:hover {
            background: var(--ma-button-hover-bg) !important;
            border-color: var(--ma-accent) !important;
            color: var(--ma-button-hover-text) !important;
        }
        [data-testid="stAppViewContainer"] div[data-testid="stDownloadButton"] button:hover {
            background: var(--ma-button-hover-bg) !important;
            border-color: var(--ma-accent) !important;
            color: var(--ma-button-hover-text) !important;
        }
        [data-testid="stAppViewContainer"] div[data-testid="stButton"] button:disabled,
        [data-testid="stSidebar"] div[data-testid="stButton"] button:disabled {
            background: var(--ma-disabled-bg) !important;
            color: var(--ma-disabled-text) !important;
            border-color: var(--ma-disabled-border) !important;
            opacity: 1 !important;
            box-shadow: none;
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button {
            background: var(--ma-button-bg) !important;
            color: var(--ma-button-text) !important;
            border: 1.5px solid var(--ma-button-border) !important;
            border-radius: 7px;
            min-height: 2.8rem;
            font-weight: 800;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.22);
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button:hover {
            background: var(--ma-button-hover-bg) !important;
            color: var(--ma-button-hover-text) !important;
            border-color: #67b7ff !important;
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="primary"] {
            background: #087443 !important;
            border-color: #064f32 !important;
            color: #ffffff !important;
            box-shadow: 0 2px 5px rgba(8, 116, 67, 0.35);
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="primary"]:hover {
            background: #0a5f39 !important;
            border-color: #043d27 !important;
            color: #ffffff !important;
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="secondary"] {
            background: #2563eb !important;
            border-color: #93c5fd !important;
            color: #ffffff !important;
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="secondary"]:hover {
            background: #1d4ed8 !important;
            border-color: #bfdbfe !important;
            color: #ffffff !important;
        }
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="secondary"] p,
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="secondary"] span,
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="primary"] p,
        [data-testid="stSidebar"] div[data-testid="stButton"] button[kind="primary"] span {
            color: inherit !important;
        }
        .ma-hero {
            border: 1px solid var(--ma-border);
            background: rgba(255, 255, 255, 0.92);
            padding: 1.15rem 1.25rem;
            border-radius: 8px;
            box-shadow: 0 10px 30px rgba(24, 32, 47, 0.08);
            margin-bottom: 1.1rem;
        }
        .ma-kicker {
            color: var(--ma-accent);
            font-size: 0.78rem;
            font-weight: 700;
            letter-spacing: 0;
            text-transform: uppercase;
            margin-bottom: 0.2rem;
        }
        .ma-hero h1 {
            font-size: 2rem;
            line-height: 1.15;
            margin: 0;
            letter-spacing: 0;
        }
        .ma-hero p {
            color: var(--ma-muted);
            margin: 0.45rem 0 0;
            max-width: 850px;
        }
        .ma-strip {
            display: grid;
            gap: 0.75rem;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            margin: 0.8rem 0 1.1rem;
        }
        .ma-stat {
            border: 1px solid var(--ma-border);
            background: var(--ma-panel);
            border-radius: 8px;
            padding: 0.8rem 0.9rem;
        }
        .ma-stat span {
            display: block;
            color: var(--ma-muted);
            font-size: 0.78rem;
            margin-bottom: 0.2rem;
        }
        .ma-stat strong {
            display: block;
            font-size: 1rem;
            font-weight: 700;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .ma-badge {
            display: inline-flex;
            align-items: center;
            border-radius: 999px;
            padding: 0.2rem 0.55rem;
            font-size: 0.78rem;
            font-weight: 700;
            border: 1px solid var(--ma-border);
            background: var(--ma-accent-soft);
            color: #115a96;
        }
        .ma-badge.good { background: #e9f8f1; color: var(--ma-good); border-color: #bce6d3; }
        .ma-badge.warn { background: #fff5e5; color: var(--ma-warn); border-color: #f2d199; }
        .ma-badge.bad { background: #fff0ee; color: var(--ma-bad); border-color: #f3b9b3; }
        .ma-update-status {
            border-radius: 7px;
            padding: 0.75rem 0.85rem;
            margin: 0.65rem 0 0.75rem;
            border: 1px solid #2dd4bf;
            background: #0f2f2a;
            color: #d8fff0 !important;
            font-weight: 750;
            line-height: 1.35;
        }
        .ma-update-status strong,
        .ma-update-status span {
            color: #ffffff !important;
        }
        .ma-update-status code {
            background: rgba(216, 255, 240, 0.12);
            color: #d8fff0 !important;
            padding: 0.08rem 0.28rem;
            border-radius: 5px;
        }
        .ma-update-status.warn {
            border-color: #fbbf24;
            background: #342406;
            color: #fff4cc !important;
        }
        .ma-run-plan {
            border: 1px solid #c5d1e3;
            background: #ffffff;
            border-radius: 8px;
            padding: 0.95rem 1rem;
            margin: 0.9rem 0 0.85rem;
            box-shadow: 0 1px 4px rgba(24, 32, 47, 0.08);
        }
        .ma-run-plan h3 {
            margin: 0 0 0.7rem;
            font-size: 1rem;
            line-height: 1.25;
            color: #18202f;
        }
        .ma-run-grid {
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 0.65rem;
        }
        .ma-run-item {
            border: 1px solid #d9dee8;
            background: #f7f9fc;
            border-radius: 7px;
            padding: 0.65rem 0.7rem;
            min-width: 0;
        }
        .ma-run-item span {
            display: block;
            color: #5f6b7a;
            font-size: 0.76rem;
            font-weight: 700;
            margin-bottom: 0.18rem;
        }
        .ma-run-item strong {
            display: block;
            color: #18202f;
            font-size: 0.94rem;
            line-height: 1.3;
            overflow-wrap: anywhere;
        }
        .ma-run-note {
            margin-top: 0.65rem;
            color: #233044;
            font-size: 0.9rem;
            line-height: 1.35;
        }
        .ma-run-note.warn {
            color: #7a3f00;
            font-weight: 750;
        }
        div[data-testid="stButton"] button[kind="primary"] {
            background: var(--ma-accent) !important;
            border-color: #003f8a !important;
            color: #ffffff !important;
            border-radius: 7px;
            font-weight: 850;
            box-shadow: 0 2px 5px rgba(0, 95, 204, 0.28);
        }
        div[data-testid="stDownloadButton"] button[kind="primary"] {
            background: var(--ma-accent) !important;
            border-color: #003f8a !important;
            color: #ffffff !important;
            border-radius: 7px;
            font-weight: 850;
            box-shadow: 0 2px 5px rgba(0, 95, 204, 0.28);
        }
        div[data-testid="stButton"] button[kind="primary"]:hover,
        div[data-testid="stDownloadButton"] button[kind="primary"]:hover {
            background: var(--ma-accent-hover) !important;
            border-color: #00336f !important;
            color: #ffffff !important;
        }
        div[data-testid="stTabs"] button {
            font-weight: 650;
        }
        @media (max-width: 900px) {
            .ma-strip { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .ma-hero h1 { font-size: 1.55rem; }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_header() -> None:
    st.markdown(
        """
        <div class="ma-hero">
          <div class="ma-kicker">Evidence synthesis workspace</div>
          <h1>Meta-Analysis Runner</h1>
          <p>Upload a workbook, route outcomes, choose model assistance, and run the packaged R-backed Python pipeline from one focused interface.</p>
          <p>Author: Anuraj Sudhakaran</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_examples() -> None:
    st.subheader("Example workflows")
    examples = [
        (
            "Binary adverse events",
            "Upload event and total counts for treatment and control arms. The app can map columns, run pairwise meta-analysis, and show forest plots.",
        ),
        (
            "Multi-outcome workbook",
            "Select all sheets and use auto route to classify outcomes such as clinical success, adverse events, reintervention, and length of stay in one run.",
        ),
        (
            "Subgroups and meta-regression",
            "Choose study-level columns such as etiology, study design, publication year, or sample size for subgroup and moderator analyses.",
        ),
        (
            "No local LLM available",
            "Use manual/no LLM mode, or install Ollama from the sidebar and pull the suggested local model for workbook assessment.",
        ),
    ]
    cols = st.columns(2)
    for index, (title, body) in enumerate(examples):
        with cols[index % 2]:
            st.markdown(f"**{title}**")
            st.caption(body)


def badge(label: str, tone: str = "") -> str:
    class_name = f"ma-badge {tone}".strip()
    return f'<span class="{class_name}">{label}</span>'


def render_run_summary(
    *,
    provider: str,
    status: LmStudioStatus,
    rscript: str | None,
    selected_sheets: list[str],
    route: str,
) -> None:
    llm_tone = "good" if status.available else "warn"
    r_tone = "good" if rscript else "bad"
    llm_label = "Available" if status.available else "Manual"
    r_label = "Ready" if rscript else "Missing"
    st.markdown(
        f"""
        <div class="ma-strip">
          <div class="ma-stat"><span>LLM provider</span><strong>{provider}</strong></div>
          <div class="ma-stat"><span>LLM status</span><strong>{badge(llm_label, llm_tone)}</strong></div>
          <div class="ma-stat"><span>R runtime</span><strong>{badge(r_label, r_tone)}</strong></div>
          <div class="ma-stat"><span>Run scope</span><strong>{len(selected_sheets)} sheet(s), {route}</strong></div>
        </div>
        """,
        unsafe_allow_html=True,
    )


EXPECTED_FORMATS: dict[str, list[tuple[str, str]]] = {
    "Binary pairwise": [
        ("Study", "Study label"),
        ("event.e / event.c", "Events in intervention and control"),
        ("n.e / n.c", "Sample sizes in intervention and control"),
        ("event_treat / total_treat", "Accepted CSV-style aliases; non_event_* can be used to derive totals"),
        ("optional subgroup columns", "Etiology, control type, design, year, etc."),
    ],
    "Continuous pairwise": [
        ("Study", "Study label"),
        ("mean.e / mean.c", "Means in intervention and control"),
        ("sd.e / sd.c", "Standard deviations in intervention and control"),
        ("n.e / n.c", "Sample sizes in intervention and control"),
    ],
    "Single-arm": [
        ("Study", "Study label"),
        ("events + n", "For proportions/prevalence"),
        ("mean + sd + n", "For single-arm means"),
        ("optional subgroup columns", "Categorical study-level groups"),
    ],
    "Diagnostic accuracy": [
        ("Study", "Study label"),
        ("TP / FP / TN / FN", "Diagnostic 2x2 table counts"),
        ("optional test/category", "For comparative diagnostic analyses"),
    ],
    "Network meta-analysis": [
        ("study_id", "Same value for all arms from the same trial"),
        ("treatment", "Arm treatment name"),
        ("events + sample_size", "Binary network outcomes"),
        ("mean + sd + sample_size", "Continuous network outcomes"),
        ("year", "Optional"),
    ],
}


def expected_format_dataframe(route: str) -> pd.DataFrame:
    rows = EXPECTED_FORMATS.get(route) or [
        ("Rows", "One row per study, comparison, or study arm depending on the selected analysis type"),
        ("Columns", "Use recognizable names such as study, treatment, events, n, mean, sd, TP, FP, TN, FN"),
    ]
    return pd.DataFrame(rows, columns=["Expected column", "Meaning"])


def render_expected_format_help(route: str) -> None:
    st.caption("Without an LLM, the app uses these column-name patterns and your manual route selection.")
    st.dataframe(expected_format_dataframe(route), hide_index=True, use_container_width=True)
    st.caption("Title rows are okay. Select the Excel row that contains the actual column names before running.")


def render_run_plan_card(
    *,
    selected_sheets: list[str],
    route: str,
    jobs: int,
    use_llm: bool,
    output_root: Path,
) -> None:
    estimate = runtime_estimate_label(len(selected_sheets), route, jobs, use_llm)
    note = ""
    note_class = "ma-run-note"
    if len(selected_sheets) > 1 and route != "Auto route workbook":
        note = "Specialized routes use only the first selected sheet. Choose Auto route workbook for multi-sheet runs."
        note_class += " warn"
    elif route == "Auto route workbook" and len(selected_sheets) > 1:
        note = f"Auto route will process the selected sheets in up to {jobs} parallel job(s)."
    else:
        note = "Review this plan, then start the analysis when the route and output folder look right."
    st.markdown(
        f"""
        <div class="ma-run-plan">
          <h3>Run Plan</h3>
          <div class="ma-run-grid">
            <div class="ma-run-item"><span>Selected sheets</span><strong>{len(selected_sheets)}</strong></div>
            <div class="ma-run-item"><span>Route</span><strong>{html.escape(route)}</strong></div>
            <div class="ma-run-item"><span>Estimated time</span><strong>{html.escape(estimate)}</strong></div>
            <div class="ma-run-item"><span>Parallel jobs</span><strong>{jobs}</strong></div>
          </div>
          <div class="ma-run-item" style="margin-top: 0.65rem;"><span>Output folder</span><strong>{html.escape(str(output_root))}</strong></div>
          <div class="{note_class}">{html.escape(note)}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def format_minutes(minutes: float) -> str:
    if minutes < 1:
        return "<1 min"
    if minutes < 60:
        return f"{round(minutes)} min"
    hours = minutes / 60
    return f"{hours:.1f} hr"


def estimate_runtime_minutes(sheet_count: int, route: str, jobs: int = 1, use_llm: bool = False) -> tuple[float, float]:
    if sheet_count <= 0:
        return 0, 0
    per_sheet = {
        "Auto route workbook": (2.0, 6.0),
        "Binary pairwise": (1.0, 4.0),
        "Continuous pairwise": (1.0, 4.0),
        "Single-arm": (1.0, 3.5),
        "Diagnostic accuracy": (2.0, 5.0),
        "Network meta-analysis": (4.0, 15.0),
    }.get(route, (2.0, 6.0))
    effective_sheets = sheet_count if route == "Auto route workbook" else 1
    parallel_jobs = max(1, int(jobs or 1)) if route == "Auto route workbook" else 1
    waves = math.ceil(effective_sheets / parallel_jobs)
    low = waves * per_sheet[0]
    high = waves * per_sheet[1]
    if use_llm:
        low += 0.5
        high += max(1.5, 0.6 * effective_sheets)
    return low, high


def runtime_estimate_label(sheet_count: int, route: str, jobs: int = 1, use_llm: bool = False) -> str:
    low, high = estimate_runtime_minutes(sheet_count, route, jobs, use_llm)
    if low == 0 and high == 0:
        return "No sheets selected"
    return f"{format_minutes(low)} - {format_minutes(high)}"


def selected_sheet_table(
    overview: dict[str, dict[str, Any]],
    selected_sheets: list[str],
    sheet_routes: dict[str, str] | None = None,
) -> pd.DataFrame:
    routes = sheet_routes or {}
    rows = []
    for sheet in selected_sheets:
        meta = overview.get(sheet, {})
        rows.append(
            {
                "Sheet": sheet,
                "Rows": meta.get("rows", 0),
                "Columns": len(meta.get("columns", [])),
                "Suggested route": routes.get(sheet, ""),
            }
        )
    return pd.DataFrame(rows)


def analysis_by_sheet_table(
    overview: dict[str, dict[str, Any]],
    selected_sheets: list[str],
    sheet_routes: dict[str, str] | None,
    active_route: str,
) -> pd.DataFrame:
    routes = sheet_routes or {}
    rows = []
    for index, sheet in enumerate(selected_sheets, start=1):
        meta = overview.get(sheet, {})
        analysis = routes.get(sheet, "") if active_route == "Auto route workbook" else active_route
        rows.append(
            {
                "#": index,
                "Sheet": sheet,
                "Analysis": analysis or "Auto route workbook",
                "Rows": meta.get("rows", 0),
                "Columns": len(meta.get("columns", [])),
            }
        )
    return pd.DataFrame(rows)


def route_count_summary(sheet_routes: dict[str, str]) -> str:
    counts: dict[str, int] = {}
    for route in sheet_routes.values():
        counts[route] = counts.get(route, 0) + 1
    if not counts:
        return "No per-sheet route suggestions yet."
    return ", ".join(f"{route}: {count}" for route, count in sorted(counts.items()))


def sheet_routes_for_display(
    overview: dict[str, dict[str, Any]],
    selected_sheets: list[str],
    assessment: dict[str, Any] | None = None,
) -> tuple[dict[str, str], str]:
    assessment_routes = assessment.get("sheet_routes") if isinstance(assessment, dict) else None
    if isinstance(assessment_routes, dict) and all(sheet in assessment_routes for sheet in selected_sheets):
        return {sheet: str(assessment_routes.get(sheet, "")) for sheet in selected_sheets}, str(assessment.get("source", "Assessment"))
    fallback = fallback_route_assessment(overview, selected_sheets)
    routes = fallback.get("sheet_routes") if isinstance(fallback.get("sheet_routes"), dict) else {}
    return {sheet: str(routes.get(sheet, "")) for sheet in selected_sheets}, "Heuristic"


def render_active_job_banner(location: str) -> None:
    job = st.session_state.get("analysis_job")
    if not job:
        return
    poll_background_job(job)
    running = process_running(job)
    elapsed = max(0, int(time.time() - float(job["started_at"])))
    output_root = Path(job["output_root"])
    if running:
        status_col, action_col = st.columns([0.78, 0.22])
        with status_col:
            st.warning(
                f"Analysis is running ({elapsed}s). If it is waiting on LM Studio or another LLM provider, "
                f"use Stop Analysis to terminate the runner. Output folder: {output_root}"
            )
        with action_col:
            if st.button("Stop Analysis", key=f"stop_analysis_{location}", use_container_width=True):
                stop_background_job(job)
                poll_background_job(job)
                st.rerun()
    elif job.get("returncode") == 0 and not job.get("stopped"):
        st.success(f"Last analysis finished. Outputs are in {output_root}")
    else:
        st.error(f"Last analysis stopped or failed with exit code {job.get('returncode')}.")


def lmstudio_models_url(base_url: str) -> list[str]:
    base = base_url.rstrip("/")
    urls: list[str] = []
    if base.endswith("/v1"):
        urls.append(f"{base}/models")
        urls.append(f"{base[:-3].rstrip('/')}/api/v0/models")
    else:
        urls.append(f"{base}/v1/models")
        urls.append(f"{base}/api/v0/models")
    return urls


def api_key_from_env(provider: str) -> str:
    for env_name in PROVIDER_DEFAULTS[provider]["key_envs"]:
        value = os.environ.get(env_name)
        if value:
            return value
    return ""


def load_saved_secrets(path: Path = SECRETS_PATH) -> dict[str, str]:
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return {str(key): str(value) for key, value in payload.items() if value}


def save_provider_api_key(provider: str, api_key: str, path: Path = SECRETS_PATH) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    secrets = load_saved_secrets(path)
    secrets[provider] = api_key
    path.write_text(json.dumps(secrets, indent=2, sort_keys=True), encoding="utf-8")
    try:
        path.chmod(0o600)
    except OSError:
        pass


def clear_provider_api_key(provider: str, path: Path = SECRETS_PATH) -> None:
    secrets = load_saved_secrets(path)
    if provider in secrets:
        secrets.pop(provider)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(secrets, indent=2, sort_keys=True), encoding="utf-8")
        try:
            path.chmod(0o600)
        except OSError:
            pass


def api_key_from_saved_or_env(provider: str) -> tuple[str, str]:
    saved = load_saved_secrets().get(provider, "")
    if saved:
        return saved, "saved"
    env_value = api_key_from_env(provider)
    return env_value, "environment" if env_value else ""


def request_headers(api_key: str, auth_header: str = "Authorization", auth_prefix: str = "Bearer") -> dict[str, str]:
    if not api_key:
        return {}
    return {auth_header: f"{auth_prefix} {api_key}" if auth_prefix else api_key}


def openai_compatible_models_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/models"):
        return base
    return f"{base}/models" if base.endswith("/v1") or base.endswith("/openai") else f"{base}/v1/models"


def openai_compatible_chat_url(base_url: str) -> str:
    base = base_url.rstrip("/")
    if base.endswith("/chat/completions"):
        return base
    return f"{base}/chat/completions" if base.endswith("/v1") or base.endswith("/openai") else f"{base}/v1/chat/completions"


@st.cache_data(ttl=20, show_spinner=False)
def check_lmstudio(base_url: str) -> LmStudioStatus:
    errors: list[str] = []
    for url in lmstudio_models_url(base_url):
        try:
            request = urllib.request.Request(url, method="GET")
            with urllib.request.urlopen(request, timeout=2) as response:
                payload = json.loads(response.read().decode("utf-8"))
            data = payload.get("data", payload if isinstance(payload, list) else [])
            models = []
            for item in data:
                if isinstance(item, dict):
                    model_id = item.get("id") or item.get("model_key") or item.get("path")
                    if model_id:
                        models.append(str(model_id))
            return LmStudioStatus(True, models, f"Connected to {url}")
        except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            errors.append(f"{url}: {exc}")
    return LmStudioStatus(False, [], "; ".join(errors) if errors else "No LM Studio response")


def check_openai_compatible(base_url: str, api_key: str, auth_header: str, auth_prefix: str) -> LmStudioStatus:
    url = openai_compatible_models_url(base_url)
    try:
        request = urllib.request.Request(
            url,
            headers=request_headers(api_key, auth_header, auth_prefix),
            method="GET",
        )
        with urllib.request.urlopen(request, timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
        data = payload.get("data", payload if isinstance(payload, list) else [])
        models = []
        for item in data:
            if isinstance(item, dict):
                model_id = item.get("id") or item.get("name") or item.get("model")
                if model_id:
                    models.append(str(model_id))
        return LmStudioStatus(True, models, f"Connected to {url}")
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        return LmStudioStatus(False, [], f"Not reachable at {url}: {exc}")


def openrouter_is_free_model(item: dict[str, Any]) -> bool:
    model_id = str(item.get("id") or "")
    name = str(item.get("name") or "")
    pricing = item.get("pricing") if isinstance(item.get("pricing"), dict) else {}
    prompt_price = str(pricing.get("prompt", "")).strip()
    completion_price = str(pricing.get("completion", "")).strip()
    architecture = item.get("architecture") if isinstance(item.get("architecture"), dict) else {}
    input_modalities = architecture.get("input_modalities") or []
    output_modalities = architecture.get("output_modalities") or []
    supports_text = "text" in input_modalities and "text" in output_modalities
    zero_price = prompt_price in {"0", "0.0", "0.000000"} and completion_price in {"0", "0.0", "0.000000"}
    free_named = model_id == "openrouter/free" or model_id.endswith(":free") or "(free)" in name.lower()
    return supports_text and (free_named or zero_price)


def ordered_openrouter_free_models(models: list[str]) -> list[str]:
    seen: set[str] = set()
    ordered: list[str] = []
    for model in [*OPENROUTER_FREE_MODELS, *models]:
        if model and model not in seen:
            seen.add(model)
            ordered.append(model)
    return ordered


def check_openrouter_free(base_url: str, api_key: str, auth_header: str, auth_prefix: str) -> LmStudioStatus:
    if not api_key:
        return LmStudioStatus(
            False,
            OPENROUTER_FREE_MODELS,
            "OpenRouter Free needs an OpenRouter API key. Use free models only, such as openrouter/free.",
        )
    url = openai_compatible_models_url(base_url)
    try:
        request = urllib.request.Request(
            url,
            headers=request_headers(api_key, auth_header, auth_prefix),
            method="GET",
        )
        with urllib.request.urlopen(request, timeout=8) as response:
            payload = json.loads(response.read().decode("utf-8"))
        data = payload.get("data", payload if isinstance(payload, list) else [])
        models = [
            str(item.get("id"))
            for item in data
            if isinstance(item, dict) and item.get("id") and openrouter_is_free_model(item)
        ]
        free_models = ordered_openrouter_free_models(models)
        return LmStudioStatus(True, free_models, f"Connected to OpenRouter. Showing {len(free_models)} free/zero-cost model option(s).")
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        return LmStudioStatus(False, OPENROUTER_FREE_MODELS, f"OpenRouter was not reachable at {url}: {exc}")


def ollama_api_base(base_url: str) -> str:
    base = base_url.rstrip("/")
    return base[:-3] if base.endswith("/v1") else base


def parse_openai_models(payload: Any) -> list[str]:
    data = payload.get("data", payload if isinstance(payload, list) else []) if isinstance(payload, (dict, list)) else []
    models: list[str] = []
    for item in data:
        if isinstance(item, dict):
            model_id = item.get("id") or item.get("name") or item.get("model")
            if model_id:
                models.append(str(model_id))
    return models


@st.cache_data(ttl=20, show_spinner=False)
def check_ollama(base_url: str) -> LmStudioStatus:
    errors: list[str] = []
    openai_url = openai_compatible_models_url(base_url)
    try:
        request = urllib.request.Request(openai_url, method="GET")
        with urllib.request.urlopen(request, timeout=2) as response:
            payload = json.loads(response.read().decode("utf-8"))
        return LmStudioStatus(True, parse_openai_models(payload), f"Connected to Ollama at {openai_url}")
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        errors.append(f"{openai_url}: {exc}")

    tags_url = f"{ollama_api_base(base_url)}/api/tags"
    try:
        request = urllib.request.Request(tags_url, method="GET")
        with urllib.request.urlopen(request, timeout=2) as response:
            payload = json.loads(response.read().decode("utf-8"))
        models = []
        for item in payload.get("models", []):
            if isinstance(item, dict):
                model_id = item.get("name") or item.get("model")
                if model_id:
                    models.append(str(model_id))
        return LmStudioStatus(True, models, f"Connected to Ollama at {tags_url}")
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        errors.append(f"{tags_url}: {exc}")
    return LmStudioStatus(False, [], "; ".join(errors) if errors else "Ollama is not reachable.")


def parse_header_overrides(value: str | None) -> dict[str, int]:
    if not value:
        return {}
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError:
        return {}
    if not isinstance(parsed, dict):
        return {}
    overrides: dict[str, int] = {}
    for sheet, row in parsed.items():
        try:
            row_index = int(row)
        except (TypeError, ValueError):
            continue
        if row_index >= 0:
            overrides[str(sheet)] = row_index
    return overrides


def header_overrides_payload(overrides: dict[str, int]) -> str:
    return json.dumps({str(sheet): int(row) for sheet, row in sorted(overrides.items())}, sort_keys=True)


def raw_excel_preview(workbook: Path, sheet: str, rows: int = 10) -> pd.DataFrame:
    raw = pd.read_excel(workbook, sheet_name=sheet, header=None, nrows=rows)
    raw.columns = [f"Column {index + 1}" for index in range(raw.shape[1])]
    raw.index = range(1, len(raw) + 1)
    return raw


def detected_header_metadata(workbook: Path, sheet: str, override_row: int | None = None) -> dict[str, Any]:
    if workbook.suffix.lower() == ".csv":
        return {
            "detected_header_row": 0,
            "header_row": 0,
            "header_source": "CSV header",
            "raw_preview": pd.DataFrame(),
        }
    raw = pd.read_excel(workbook, sheet_name=sheet, header=None)
    detected = detect_excel_header_row(raw)
    header_row = override_row if override_row is not None else detected
    header_row = max(0, min(int(header_row), max(0, len(raw) - 1))) if len(raw) else 0
    source = "Manual override" if override_row is not None else "Auto detected"
    return {
        "detected_header_row": detected,
        "header_row": header_row,
        "header_source": source,
        "raw_preview": raw_excel_preview(workbook, sheet),
    }


@st.cache_data(show_spinner=False)
def workbook_overview(path: str, header_overrides_json: str = "{}") -> dict[str, dict[str, Any]]:
    workbook = Path(path)
    header_overrides = parse_header_overrides(header_overrides_json)
    if workbook.suffix.lower() == ".csv":
        df = load_workbook_sheet(workbook, workbook.stem)
        df.columns = [str(col) for col in df.columns]
        return {
            workbook.stem: {
                "rows": int(len(df)),
                "columns": list(df.columns),
                "preview": df.head(25),
                "detected_header_row": 0,
                "header_row": 0,
                "header_source": "CSV header",
                "raw_preview": pd.DataFrame(),
            }
        }

    excel = pd.ExcelFile(workbook)
    overview: dict[str, dict[str, Any]] = {}
    for sheet in excel.sheet_names:
        override_row = header_overrides.get(sheet)
        sheet_data = load_workbook_sheet(workbook, sheet, header_row=override_row)
        preview = sheet_data.head(25)
        preview.columns = [str(col) for col in preview.columns]
        header_meta = detected_header_metadata(workbook, sheet, override_row=override_row)
        overview[sheet] = {
            "rows": int(sheet_data.shape[0]),
            "columns": list(preview.columns),
            "preview": preview,
            **header_meta,
        }
    return overview


def display_preview(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    return df.copy().fillna("")


def normalize_route(value: Any) -> str | None:
    normalized = str(value or "").strip().lower().replace("-", " ").replace("_", " ")
    normalized = re.sub(r"\s+", " ", normalized)
    return ROUTE_ALIASES.get(normalized)


def heuristic_route_from_columns(columns: list[str]) -> str:
    normalized = [normalize_column_name(column) for column in columns]
    has = lambda terms: any(any(term in column for term in terms) for column in normalized)
    has_network_arm_column = any(
        re.fullmatch(r"(study)?(treat|treatment|arm|intervention|comparator)\d*", column)
        for column in normalized
    )
    if has_network_arm_column and has(("treatment", "intervention", "comparator", "network", "arm", "treat")):
        return "Network meta-analysis"
    if all(has((term,)) for term in ("tp", "fp", "tn", "fn")):
        return "Diagnostic accuracy"
    if has(("event", "events")) and has(("total", "n", "sample")):
        return "Binary pairwise"
    if (
        has(("event", "events"))
        and has(("nonevent", "non-events", "non event"))
        and has(("treat", "intervention", "experimental"))
        and has(("control", "comparator", "placebo"))
    ):
        return "Binary pairwise"
    if has(("mean",)) and has(("sd", "standarddeviation", "se")):
        return "Continuous pairwise"
    if has(("proportion", "prevalence", "rate")) or (has(("event", "events")) and not has(("control", "comparator"))):
        return "Single-arm"
    return "Auto route workbook"


def workbook_assessment_payload(overview: dict[str, dict[str, Any]], selected_sheets: list[str]) -> dict[str, Any]:
    sheets = selected_sheets or list(overview)
    payload: dict[str, Any] = {
        "selected_sheet_count": len(sheets),
        "included_sheet_count": min(len(sheets), MAX_LLM_ROUTE_SHEETS),
        "truncated": len(sheets) > MAX_LLM_ROUTE_SHEETS,
        "sheets": [],
    }
    for index, sheet in enumerate(sheets[:MAX_LLM_ROUTE_SHEETS]):
        meta = overview[sheet]
        columns = list(meta["columns"])
        sheet_payload: dict[str, Any] = {
            "name": sheet,
            "rows": meta["rows"],
            "column_count": len(columns),
            "columns": columns[:80],
            "heuristic_route": heuristic_route_from_columns(columns),
            "detected_header_row_1_based": int(meta.get("detected_header_row", 0)) + 1,
            "active_header_row_1_based": int(meta.get("header_row", 0)) + 1,
            "header_source": meta.get("header_source", "Auto detected"),
        }
        if len(columns) > 80:
            sheet_payload["truncated_columns"] = len(columns) - 80
        if index < LLM_ROUTE_SAMPLE_SHEETS:
            sample_rows = 2 if len(sheets) > 1 else 5
            preview = display_preview(meta["preview"]).head(sample_rows)
            sheet_payload["sample_rows"] = preview.to_dict(orient="records")
            raw_preview = meta.get("raw_preview")
            if isinstance(raw_preview, pd.DataFrame) and not raw_preview.empty:
                sheet_payload["raw_top_rows"] = display_preview(raw_preview).head(8).to_dict(orient="index")
        payload["sheets"].append(sheet_payload)
    return payload


def fallback_route_assessment(overview: dict[str, dict[str, Any]], selected_sheets: list[str]) -> dict[str, Any]:
    sheets = selected_sheets or list(overview)
    sheet_routes = {
        sheet: heuristic_route_from_columns(list(overview[sheet]["columns"]))
        for sheet in sheets
    }
    unique_routes = {route for route in sheet_routes.values() if route != "Auto route workbook"}
    recommended = next(iter(unique_routes)) if len(unique_routes) == 1 and len(sheet_routes) == 1 else "Auto route workbook"
    return {
        "source": "Heuristic",
        "recommended_route": recommended,
        "sheet_routes": sheet_routes,
        "binary_effect_size": "auto",
        "single_arm_type": "auto",
        "diagnostic_mode": "single",
        "network_effect": "auto",
        "network_model": "random",
        "network_engine": "frequentist",
        "reason": "Estimated from sheet and column names. Review and adjust the options before running.",
    }


def fallback_route_assessment_with_note(
    overview: dict[str, dict[str, Any]],
    selected_sheets: list[str],
    *,
    source: str,
    reason: str,
) -> dict[str, Any]:
    assessment = fallback_route_assessment(overview, selected_sheets)
    assessment["source"] = source
    assessment["reason"] = reason
    return assessment


def should_auto_assess_routes_with_llm(provider: str, selected_sheets: list[str], use_llm: bool, model_id: str) -> bool:
    if not use_llm or not model_id or not selected_sheets:
        return False
    return len(selected_sheets) == 1 or provider in LOCAL_LLM_PROVIDERS


def hosted_multi_sheet_route_reason(provider: str) -> str:
    return (
        f"Multiple sheets are classified locally first to avoid {provider} API rate limits. "
        "Use the LLM reassessment button only when you want a hosted API call."
    )


def friendly_llm_route_error(exc: Exception) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        if exc.code == 429:
            retry_after = exc.headers.get("Retry-After")
            suffix = f" Try again in about {retry_after} second(s), or switch to LM Studio/Ollama/local inference." if retry_after else " Try again shortly, or switch to LM Studio/Ollama/local inference."
            return f"The selected LLM provider rate-limited the route assessment.{suffix}"
        if exc.code in {401, 403}:
            return "The selected LLM provider rejected the API key or permissions. Check the saved key, then reassess."
        if exc.code >= 500:
            return "The selected LLM provider is temporarily unavailable. The app is using column heuristics for now."
        return f"The selected LLM provider returned HTTP {exc.code}. The app is using column heuristics for now."
    if isinstance(exc, TimeoutError):
        return "The LLM route assessment timed out. The app is using column heuristics for now."
    if isinstance(exc, urllib.error.URLError) and "timed out" in str(exc.reason).lower():
        return "The LLM route assessment timed out. The app is using column heuristics for now."
    return "The LLM route assessment was unavailable. The app is using column heuristics for now."


def friendly_llm_interpretation_error(exc: Exception) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        if exc.code == 429:
            retry_after = exc.headers.get("Retry-After")
            suffix = f" Try again in about {retry_after} second(s)." if retry_after else " Try again shortly, or use LM Studio/Ollama for local interpretation."
            return f"The selected LLM provider rate-limited the interpretation request.{suffix}"
        if exc.code in {401, 403}:
            return "The selected LLM provider rejected the API key or permissions. Check the saved key, then try again."
        if exc.code in {400, 415, 422}:
            return (
                "The selected provider/model rejected the image payload. "
                "The model may be vision-capable, but this endpoint may not accept OpenAI-style image inputs. "
                "Try text-only mode, a different vision endpoint, or a local LM Studio/Ollama vision model."
            )
        if exc.code >= 500:
            return "The selected LLM provider is temporarily unavailable. Try again later or use a local LLM provider."
        return f"The selected LLM provider returned HTTP {exc.code}. Try again later or use a local LLM provider."
    if isinstance(exc, TimeoutError):
        return "The interpretation request timed out. Try again later or use a local LLM provider."
    if isinstance(exc, urllib.error.URLError) and "timed out" in str(exc.reason).lower():
        return "The interpretation request timed out. Try again later or use a local LLM provider."
    return "The interpretation request was unavailable. Try again later or use a local LLM provider."


def extract_json_object(text: str) -> dict[str, Any]:
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        parsed = json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if not match:
            raise
        parsed = json.loads(match.group(0))
    return parsed if isinstance(parsed, dict) else {}


def is_local_llm_url(base_url: str) -> bool:
    try:
        parsed = urllib.parse.urlparse(base_url)
    except Exception:
        return False
    host = (parsed.hostname or "").lower()
    if host in {"localhost", "127.0.0.1", "::1", "0.0.0.0"}:
        return True
    if host.startswith("127."):
        return True
    if host.startswith("10.") or host.startswith("192.168."):
        return True
    if host.startswith("172."):
        parts = host.split(".")
        if len(parts) > 1 and parts[1].isdigit() and 16 <= int(parts[1]) <= 31:
            return True
    return False


def llm_generation_timeout(base_url: str, timeout: int | float | None) -> int | float | None:
    return None if is_local_llm_url(base_url) else timeout


def llm_route_assessment(
    *,
    overview: dict[str, dict[str, Any]],
    selected_sheets: list[str],
    base_url: str,
    model_id: str,
    api_key: str,
    auth_header: str,
    auth_prefix: str,
) -> dict[str, Any]:
    if not model_id:
        raise RuntimeError("Select or enter a model before using LLM route assessment.")
    prompt = {
        "task": "Assess an evidence-synthesis workbook and recommend Streamlit GUI settings.",
        "allowed_routes": ROUTES,
        "allowed_binary_effect_size": ["auto", "RR", "OR", "RD"],
        "allowed_single_arm_type": ["auto", "proportion", "mean"],
        "allowed_diagnostic_mode": ["single", "comparative"],
        "allowed_network_effect": ["auto", "RR", "OR", "RD", "MD", "SMD"],
        "allowed_network_model": ["random", "common", "fixed"],
        "allowed_network_engine": ["frequentist", "bayesian", "both"],
        "data_layout_rules": [
            "Classify wide binary count CSVs as Binary pairwise even when arm names are abbreviated, for example event_treat/non_event_treat/total_treat and event_control/non_event_control/total_control.",
            "If totals are absent but non-event columns are present, the binary runner can derive totals as events plus non-events after the initial route evaluation.",
        ],
        "workbook": workbook_assessment_payload(overview, selected_sheets),
        "return_json_schema": {
            "recommended_route": "one allowed route",
            "sheet_routes": {"sheet name": "one allowed route"},
            "binary_effect_size": "auto/RR/OR/RD",
            "single_arm_type": "auto/proportion/mean",
            "diagnostic_mode": "single/comparative",
            "network_effect": "auto/RR/OR/RD/MD/SMD",
            "network_model": "random/common/fixed",
            "network_engine": "frequentist/bayesian/both",
            "reason": "short explanation",
        },
    }
    body = {
        "model": model_id,
        "messages": [
            {
                "role": "system",
                "content": "Return only valid JSON. Choose conservative defaults for meta-analysis routing.",
            },
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ],
        "temperature": 0,
    }
    headers = {"Content-Type": "application/json"}
    headers.update(request_headers(api_key, auth_header, auth_prefix))
    request = urllib.request.Request(
        openai_compatible_chat_url(base_url),
        data=json.dumps(body).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=llm_generation_timeout(base_url, 30)) as response:
        payload = json.loads(response.read().decode("utf-8"))
    content = payload["choices"][0]["message"]["content"]
    result = extract_json_object(str(content))
    result["source"] = "LLM"
    route = normalize_route(result.get("recommended_route"))
    result["recommended_route"] = route or "Auto route workbook"
    sheet_routes = result.get("sheet_routes")
    if isinstance(sheet_routes, dict):
        result["sheet_routes"] = {
            str(sheet): normalize_route(route_value) or "Auto route workbook"
            for sheet, route_value in sheet_routes.items()
        }
    else:
        result["sheet_routes"] = {}
    return result


def llm_header_assessment(
    *,
    overview: dict[str, dict[str, Any]],
    selected_sheets: list[str],
    base_url: str,
    model_id: str,
    api_key: str,
    auth_header: str,
    auth_prefix: str,
) -> dict[str, Any]:
    if not model_id:
        raise RuntimeError("Select or enter a model before using LLM sheet-structure assessment.")
    sheets = selected_sheets or list(overview)
    prompt = {
        "task": (
            "Identify the row that contains the actual column headers for each evidence-synthesis sheet. "
            "Rows are shown with 1-based Excel row numbers. Title rows, descriptions, blank rows, and notes are not headers."
        ),
        "instructions": [
            "Return only valid JSON.",
            "Use the first row containing reusable variable names such as study, treatment, event, n, mean, sd, tp/fp/tn/fn, or sample_size.",
            "If row 1 is already the header row, return 1.",
            "If uncertain, keep the current active_header_row_1_based.",
        ],
        "workbook": workbook_assessment_payload(overview, sheets),
        "return_json_schema": {
            "header_rows": {"sheet name": "1-based Excel row number containing column names"},
            "reason": "short explanation",
        },
    }
    body = {
        "model": model_id,
        "messages": [
            {
                "role": "system",
                "content": "Return only valid JSON. Identify worksheet header rows conservatively.",
            },
            {"role": "user", "content": json.dumps(prompt, default=str)},
        ],
        "temperature": 0,
    }
    headers = {"Content-Type": "application/json"}
    headers.update(request_headers(api_key, auth_header, auth_prefix))
    request = urllib.request.Request(
        openai_compatible_chat_url(base_url),
        data=json.dumps(body).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=llm_generation_timeout(base_url, 45)) as response:
        payload = json.loads(response.read().decode("utf-8"))
    content = payload["choices"][0]["message"]["content"]
    result = extract_json_object(str(content))
    rows = result.get("header_rows")
    clean_rows: dict[str, int] = {}
    if isinstance(rows, dict):
        for sheet, row in rows.items():
            if str(sheet) not in overview:
                continue
            try:
                one_based = int(row)
            except (TypeError, ValueError):
                continue
            if one_based >= 1:
                clean_rows[str(sheet)] = one_based
    return {
        "source": "LLM",
        "header_rows": clean_rows,
        "reason": str(result.get("reason") or "LLM reviewed worksheet title rows and header rows."),
    }


def call_openai_compatible_chat(
    *,
    base_url: str,
    model_id: str,
    api_key: str,
    auth_header: str,
    auth_prefix: str,
    messages: list[dict[str, Any]],
    timeout: int | float | None = 60,
) -> str:
    if not model_id:
        raise RuntimeError("Select or enter a model before requesting an LLM interpretation.")
    body = {"model": model_id, "messages": messages, "temperature": 0.2}
    headers = {"Content-Type": "application/json"}
    headers.update(request_headers(api_key, auth_header, auth_prefix))
    request = urllib.request.Request(
        openai_compatible_chat_url(base_url),
        data=json.dumps(body).encode("utf-8"),
        headers=headers,
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=llm_generation_timeout(base_url, timeout)) as response:
        payload = json.loads(response.read().decode("utf-8"))
    return str(payload["choices"][0]["message"]["content"]).strip()


def likely_vision_model(model_id: str) -> bool:
    normalized = normalize_column_name(model_id)
    vision_terms = (
        "vision",
        "vl",
        "llava",
        "bakllava",
        "moondream",
        "pixtral",
        "minicpmv",
        "qwen2vl",
        "qwen25vl",
        "qwenvl",
        "gpt4o",
        "gpt41",
        "gpt5",
        "gemini",
        "gemma3",
        "llama4",
        "llama4maverick",
        "llama4scout",
        "granite32vision",
        "mistralsmall31",
    )
    text_only_terms = ("embedding", "rerank", "whisper", "tts")
    return bool(normalized) and any(term in normalized for term in vision_terms) and not any(
        term in normalized for term in text_only_terms
    )


def vision_model_suggestions(provider: str) -> list[str]:
    suggestions = {
        "OpenAI": ["gpt-4o", "gpt-4.1", "gpt-5"],
        "Gemini": ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-1.5-pro"],
        "Ollama": ["llama3.2-vision", "llava", "qwen2.5vl"],
        "LM Studio": ["llava", "qwen2.5-vl", "gemma-3 vision-capable variants"],
    }
    return suggestions.get(provider, ["a vision-capable OpenAI-compatible model"])


def provider_from_base_url(base_url: str) -> str:
    normalized = base_url.lower()
    if "api.openai.com" in normalized:
        return "OpenAI"
    if "generativelanguage.googleapis.com" in normalized:
        return "Gemini"
    if "11434" in normalized:
        return "Ollama"
    return "LM Studio"


def image_data_url(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"}:
        mime_type = mimetypes.guess_type(path.name)[0] or "image/png"
        data = path.read_bytes()
    else:
        from PIL import Image

        with Image.open(path) as image:
            if image.mode not in {"RGB", "RGBA"}:
                image = image.convert("RGB")
            buffer = BytesIO()
            image.save(buffer, format="PNG")
            data = buffer.getvalue()
        mime_type = "image/png"
    encoded = base64.b64encode(data).decode("ascii")
    return f"data:{mime_type};base64,{encoded}"


def tiny_png_data_url() -> str:
    return (
        "data:image/png;base64,"
        "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+/p9sAAAAASUVORK5CYII="
    )


def probe_vision_support(
    *,
    base_url: str,
    model_id: str,
    api_key: str,
    auth_header: str,
    auth_prefix: str,
) -> str:
    response = call_openai_compatible_chat(
        base_url=base_url,
        model_id=model_id,
        api_key=api_key,
        auth_header=auth_header,
        auth_prefix=auth_prefix,
        timeout=30,
        messages=[
            {
                "role": "system",
                "content": "You are checking whether image input works. Reply briefly.",
            },
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "This is a tiny test image. Reply with VISION_OK if you received the image."},
                    {"type": "image_url", "image_url": {"url": tiny_png_data_url()}},
                ],
            },
        ],
    )
    return f"Vision image payload was accepted by the provider. Model response: {response[:300]}"


def save_upload(uploaded_file: Any) -> Path:
    suffix = Path(uploaded_file.name).suffix.lower()
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    run_dir = RUNS_HOME / f"{Path(uploaded_file.name).stem}-{timestamp}"
    run_dir.mkdir(parents=True, exist_ok=True)
    destination = run_dir / uploaded_file.name
    destination.write_bytes(uploaded_file.getbuffer())
    return destination


def choose_output_directory(initial_dir: Path) -> str | None:
    """Open a native folder chooser when the app is running locally."""

    initial_dir = initial_dir.expanduser().resolve()
    if sys.platform == "darwin" and shutil.which("osascript"):
        script = (
            'POSIX path of (choose folder with prompt "Choose an output folder" '
            f'default location POSIX file "{initial_dir}/")'
        )
        completed = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            text=True,
            check=False,
        )
        if completed.returncode == 0:
            selected = completed.stdout.strip()
            return selected or None
        return None

    try:
        import tkinter as tk
        from tkinter import filedialog

        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected = filedialog.askdirectory(
            title="Choose an output folder",
            initialdir=str(initial_dir),
        )
        root.destroy()
        return selected or None
    except Exception:
        return None


def format_command(command: list[str]) -> str:
    return " ".join(f'"{part}"' if " " in part else part for part in command)


def enqueue_output(stream: Any, output_queue: queue.Queue[str]) -> None:
    for line in iter(stream.readline, ""):
        output_queue.put(line)
    stream.close()


def process_running(job: dict[str, Any] | None) -> bool:
    if not job:
        return False
    process = job.get("process")
    return bool(process and process.poll() is None)


def image_label(path: Path, root: Path) -> str:
    try:
        relative = path.relative_to(root)
    except ValueError:
        relative = path
    parts = list(relative.parts)
    outcome = ""
    if "Collected Outcomes" in parts:
        index = parts.index("Collected Outcomes")
        if len(parts) > index + 1:
            outcome = parts[index + 1]
    elif len(parts) > 1:
        outcome = parts[-2]
    name = path.stem.replace("_", " ").strip()
    return f"{outcome} - {name}" if outcome and outcome not in name else name


def image_category(path: Path) -> str:
    name = path.name.lower().replace("_", " ").replace("-", " ")
    if "leave" in name and "out" in name:
        return "Leave-one-out"
    if "sensitivity" in name:
        return "Sensitivity"
    if "baujat" in name:
        return "Baujat"
    if "forest" in name:
        return "Forest"
    if "funnel" in name:
        return "Funnel"
    if "egger" in name:
        return "Egger"
    if "influence" in name:
        return "Influence"
    if "rank" in name:
        return "Rankogram"
    if "network" in name:
        return "Network"
    return "Image"


def image_sort_key(path: Path, root: Path) -> tuple[int, str, str]:
    priority = {
        "Forest": 0,
        "Leave-one-out": 1,
        "Sensitivity": 2,
        "Baujat": 3,
        "Funnel": 4,
        "Egger": 5,
        "Influence": 6,
        "Network": 7,
        "Rankogram": 8,
        "Image": 9,
    }
    category = image_category(path)
    return (priority.get(category, 9), image_label(path, root).lower(), str(path).lower())


def discover_output_images(output_root: Path) -> list[dict[str, Any]]:
    if not output_root.exists():
        return []
    found: dict[str, Path] = {}
    for manifest in sorted(output_root.rglob("image-manifest.csv")):
        try:
            frame = pd.read_csv(manifest)
        except Exception:
            continue
        collection_root = manifest.parent
        for _, row in frame.iterrows():
            absolute = str(row.get("absolute_path") or "").strip()
            relative = str(row.get("relative_path") or "").strip()
            candidates = []
            if absolute:
                candidates.append(Path(absolute))
            if relative:
                candidates.append(collection_root / relative)
            for candidate in candidates:
                if candidate.exists() and candidate.suffix.lower() in IMAGE_EXTENSIONS:
                    found[str(candidate.resolve())] = candidate
                    break
    for image in sorted(output_root.rglob("*")):
        if image.is_file() and image.suffix.lower() in IMAGE_EXTENSIONS:
            found[str(image.resolve())] = image
    selected = list(found.values())
    selected.sort(key=lambda path: image_sort_key(path, output_root))
    return [
        {
            "path": path,
            "label": f"{image_category(path)} - {image_label(path, output_root)}",
            "category": image_category(path),
            "context": image_context_text(path, output_root),
        }
        for path in selected
    ]


STAT_CONTEXT_TERMS = (
    "p",
    "pval",
    "pvalue",
    "p.value",
    "ci",
    "confidence",
    "heterogeneity",
    "i2",
    "i^2",
    "tau",
    "tau2",
    "tau^2",
    "effect",
    "estimate",
    "rr",
    "or",
    "rd",
    "md",
    "smd",
    "risk",
    "odds",
    "z",
    "q",
    "egger",
    "funnel",
    "leave",
    "sensitivity",
    "baujat",
    "metareg",
    "meta regression",
    "meta-regression",
    "moderator",
    "coefficient",
    "slope",
    "beta",
    "qm",
    "test of moderators",
)


def statistical_line_excerpt(text: str, *, max_lines: int = 40) -> str:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    matching = [
        line
        for line in lines
        if any(term in normalize_column_name(line) or term in line.lower() for term in STAT_CONTEXT_TERMS)
    ]
    selected = matching[:max_lines] if matching else lines[: min(max_lines, 18)]
    return "\n".join(selected)


def table_context_excerpt(path: Path, *, max_rows: int = 20) -> str:
    try:
        frame = pd.read_csv(path)
    except Exception:
        return ""
    if frame.empty:
        return ""
    relevant_columns = [
        column
        for column in frame.columns
        if any(term in normalize_column_name(str(column)) or term in str(column).lower() for term in STAT_CONTEXT_TERMS)
    ]
    if relevant_columns:
        keep_columns = list(dict.fromkeys([*relevant_columns, *list(frame.columns[:6])]))
        subset = frame[keep_columns[:16]].head(max_rows)
    else:
        subset = frame.head(min(max_rows, 8))
    return subset.to_string(index=False, max_colwidth=80)


def context_candidate_score(candidate: Path, image_path: Path, output_root: Path) -> tuple[int, str]:
    try:
        same_dir = candidate.parent == image_path.parent
        relative = str(candidate.relative_to(output_root)).lower()
    except ValueError:
        same_dir = False
        relative = str(candidate).lower()
    name = candidate.name.lower()
    category = image_category(image_path).lower()
    score = 0
    if same_dir:
        score -= 80
    if category in name or category in relative:
        score -= 30
    if any(term in name for term in ("summary", "analysis", "result", "effect", "heterogeneity", "sensitivity", "egger", "funnel")):
        score -= 20
    if candidate.suffix.lower() == ".csv":
        score -= 10
    return score, relative


def image_context_text(path: Path, output_root: Path, limit: int = 14000) -> str:
    search_dirs = []
    if path.parent.exists():
        search_dirs.append(path.parent)
    if output_root.exists():
        search_dirs.append(output_root)
    candidates: list[Path] = []
    for directory in search_dirs:
        for pattern in (
            "*TSA*.txt",
            "*tsa*.txt",
            "*TrialSequential*.txt",
            "*trial*sequential*.txt",
            "*Summary*.txt",
            "*summary*.txt",
            "*run-info*.txt",
            "*Analysis*.txt",
            "*analysis*.txt",
            "*Result*.txt",
            "*result*.txt",
            "*Effect*.csv",
            "*effect*.csv",
            "*Summary*.csv",
            "*summary*.csv",
            "*Result*.csv",
            "*result*.csv",
            "*heterogeneity*.csv",
            "*sensitivity*.csv",
            "*TSA*.csv",
            "*tsa*.csv",
            "*TrialSequential*.csv",
            "*trial*sequential*.csv",
            "*MetaRegression*.csv",
            "*metaregression*.csv",
            "*meta-regression*.csv",
            "*regression*.csv",
            "*.csv",
        ):
            candidates.extend(sorted(directory.rglob(pattern)))
    seen: set[str] = set()
    snippets: list[str] = []
    for candidate in sorted(candidates, key=lambda item: context_candidate_score(item, path, output_root)):
        if not candidate.is_file() or str(candidate.resolve()) in seen:
            continue
        seen.add(str(candidate.resolve()))
        if candidate.suffix.lower() == ".csv":
            text = table_context_excerpt(candidate)
        else:
            try:
                raw_text = candidate.read_text(encoding="utf-8", errors="replace").strip()
            except OSError:
                continue
            text = statistical_line_excerpt(raw_text)
        if not text:
            continue
        snippets.append(f"{candidate.name}\n{text[:3500]}")
        if sum(len(snippet) for snippet in snippets) >= limit:
            break
    return "\n\n---\n\n".join(snippets)[:limit]


def interpret_selected_image(
    *,
    image: dict[str, Any],
    base_url: str,
    model_id: str,
    api_key: str,
    auth_header: str,
    auth_prefix: str,
    include_image: bool = True,
) -> str:
    image_note = "The selected plot image is attached." if include_image else "The selected plot image is not attached; use the text context only."
    prompt = f"""
Interpret this meta-analysis output as a publication-ready Results paragraph for a clinical/research manuscript.

Plot label: {image['label']}
Plot category: {image['category']}
Image file: {image['path']}
Image input: {image_note}

Available generated result text/tables, including any p-values, confidence
intervals, heterogeneity statistics, and sensitivity/publication-bias outputs
that were found near this plot:
{image.get('context') or 'No nearby text summary files were found.'}

Return exactly one polished paragraph. Do not show step-by-step reasoning,
do not use headings, and do not use bullets or numbered lists.

Reporting style:
- For a primary pooled effect, report the effect measure, point estimate, 95%
  confidence interval, exact p-value when supplied, model if supplied, and
  heterogeneity (I^2/tau^2/Q p-value) when supplied.
- For meta-regression, state the moderator, direction of association, regression
  coefficient or slope with 95% CI if supplied, exact p-value for the moderator
  or test of moderators if supplied, and whether the meta-regression was
  statistically significant. If the coefficient/p-value is absent, say that the
  figure suggests the pattern but the generated output did not provide the
  formal meta-regression statistic.
- For leave-one-out sensitivity analysis, state whether omitting any single
  study materially changed the pooled estimate, confidence interval, p-value, or
  heterogeneity; name influential studies only if present in the supplied output.
- For Baujat/influence plots, identify studies contributing most to
  heterogeneity or influence only if present in the supplied output, and report
  whether influence diagnostics suggest robustness or concern.
- For funnel/Egger outputs, report Egger or asymmetry p-values only when
  supplied and avoid claiming publication bias from visual inspection alone.
- For Trial Sequential Analysis (TSA), interpret the plot conservatively and
  separately from the conventional pooled-effect result. Report the
  TSA-adjusted effect estimate/CI/p-value, heterogeneity/D^2, and information
  size milestones (AIS and HARIS) when visible or supplied. Distinguish the
  naive significance boundary from the TSA alpha-spending boundary and the
  beta/futility boundary. Do not claim that evidence is trial-sequentially
  conclusive, that the alpha boundary was crossed, or that sufficient
  information size was reached unless the supplied image/text explicitly shows
  the cumulative Z-curve crossing the red alpha-spending boundary and/or
  reaching the stated required information size. Reaching AIS alone is not the
  same as reaching HARIS when both are shown. If the Z-curve crosses only a
  naive boundary, say that conventional significance is suggested but TSA
  conclusiveness is not visually demonstrated.
- For TSA plots, avoid importing Egger, Baujat, leave-one-out, or other
  diagnostics into the paragraph unless those specific diagnostics are supplied
  for the same selected outcome.
- If multiple outcomes are present in the supplied files, focus the paragraph on
  the selected plot/outcome named above and mention other outcomes only when the
  selected plot explicitly compares them.

Use exact numbers only if they appear in the supplied image or generated text.
Do not invent p-values, confidence intervals, heterogeneity statistics,
meta-regression coefficients, or effect sizes.
""".strip()
    user_content: str | list[dict[str, Any]]
    if include_image:
        user_content = [
            {"type": "text", "text": prompt},
            {"type": "image_url", "image_url": {"url": image_data_url(Path(image["path"]))}},
        ]
    else:
        user_content = prompt
    return call_openai_compatible_chat(
        base_url=base_url,
        model_id=model_id,
        api_key=api_key,
        auth_header=auth_header,
        auth_prefix=auth_prefix,
        messages=[
            {
                "role": "system",
                "content": (
                    "You write accurate manuscript-ready meta-analysis interpretations. "
                    "Use only supplied plot/text/table evidence. Do not invent numbers. "
                    "Return only the final manuscript paragraph, never step-by-step reasoning."
                ),
            },
            {"role": "user", "content": user_content},
        ],
    )


def render_output_image_gallery(
    output_root: Path,
    *,
    use_llm: bool = False,
    llm_base_url: str = "",
    model_id: str = "",
    llm_api_key: str = "",
    auth_header: str = "Authorization",
    auth_prefix: str = "Bearer",
) -> None:
    images = discover_output_images(output_root)
    if not images:
        return
    gallery_key = f"image_gallery_index_{re.sub(r'[^a-zA-Z0-9]+', '_', str(output_root))}"
    current = int(st.session_state.get(gallery_key, 0))
    current = max(0, min(current, len(images) - 1))
    st.subheader("Analysis Images")
    categories = ", ".join(sorted({item["category"] for item in images}))
    st.caption(f"Showing all generated image outputs, including forest plots, leave-one-out/sensitivity plots, Baujat plots, funnel plots, and related figures. Found: {categories}.")
    nav_left, nav_middle, nav_right = st.columns([0.16, 0.68, 0.16], vertical_alignment="center")
    with nav_left:
        if st.button("Previous", key=f"{gallery_key}_prev", disabled=len(images) <= 1, use_container_width=True):
            current = (current - 1) % len(images)
            st.session_state[gallery_key] = current
            st.rerun()
    with nav_middle:
        selected_label = st.selectbox(
            "Selected plot",
            [item["label"] for item in images],
            index=current,
            key=f"{gallery_key}_select",
        )
        current = [item["label"] for item in images].index(selected_label)
        st.session_state[gallery_key] = current
        st.caption(f"{current + 1} of {len(images)}")
    with nav_right:
        if st.button("Next", key=f"{gallery_key}_next", disabled=len(images) <= 1, use_container_width=True):
            current = (current + 1) % len(images)
            st.session_state[gallery_key] = current
            st.rerun()
    selected = images[current]
    st.image(str(selected["path"]), caption=selected["label"], use_container_width=True)
    st.subheader("LLM Interpretation")
    if not use_llm:
        st.caption("Enable an LLM provider in the sidebar to generate an interpretation for the selected image.")
        return
    vision_capable = likely_vision_model(model_id)
    interpretation_options = [
        "Send selected image + text context",
        "Use text context only",
        "Try image even if model is not recognized as vision-capable",
    ]
    default_mode = 0 if vision_capable else 1
    interpretation_mode = st.selectbox(
        "Interpretation input",
        interpretation_options,
        index=default_mode,
        key=f"{gallery_key}_interpretation_mode",
        help="Vision-capable models receive the selected plot image plus nearby text. Text-only mode avoids vision API errors.",
    )
    if vision_capable:
        st.caption(f"`{model_id}` looks vision-capable, so the selected plot image can be sent to the LLM.")
    else:
        st.caption(
            f"`{model_id or 'No model selected'}` does not look like a vision model. "
            f"Suggested vision models: {', '.join(vision_model_suggestions(provider_from_base_url(llm_base_url)))}."
        )
    probe_key = f"vision_probe_{gallery_key}_{normalize_column_name(model_id)}"
    if st.button("Check Vision Support", key=f"{gallery_key}_vision_probe", use_container_width=True):
        with st.spinner("Sending a tiny image probe to the selected model..."):
            try:
                st.session_state[probe_key] = probe_vision_support(
                    base_url=llm_base_url,
                    model_id=model_id,
                    api_key=llm_api_key,
                    auth_header=auth_header,
                    auth_prefix=auth_prefix,
                )
            except Exception as exc:
                st.session_state[probe_key] = friendly_llm_interpretation_error(exc)
    if st.session_state.get(probe_key):
        st.info(str(st.session_state[probe_key]))
    interpretation_key = f"image_interpretation_{gallery_key}_{current}_{normalize_column_name(interpretation_mode)}"
    if st.button("Generate Interpretation", key=f"{gallery_key}_interpret", use_container_width=True):
        include_image = interpretation_mode != "Use text context only"
        if include_image and not vision_capable:
            st.warning("This model is not recognized as vision-capable. The request may fail; choose text-only mode if it does.")
        with st.spinner("Generating interpretation for the selected image..."):
            try:
                st.session_state[interpretation_key] = interpret_selected_image(
                    image=selected,
                    base_url=llm_base_url,
                    model_id=model_id,
                    api_key=llm_api_key,
                    auth_header=auth_header,
                    auth_prefix=auth_prefix,
                    include_image=include_image,
                )
            except Exception as exc:
                st.session_state[interpretation_key] = friendly_llm_interpretation_error(exc)
    interpretation = st.session_state.get(interpretation_key)
    if interpretation:
        interpretation_text = str(interpretation)
        if interpretation_text.startswith(("The selected LLM provider", "The interpretation request")):
            st.info(interpretation_text)
        else:
            st.markdown(interpretation_text)


def start_background_job(command: list[str], env: dict[str, str], output_root: Path) -> dict[str, Any]:
    output_queue: queue.Queue[str] = queue.Queue()
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
        env=env,
        start_new_session=os.name != "nt",
    )
    assert process.stdout is not None
    thread = threading.Thread(target=enqueue_output, args=(process.stdout, output_queue), daemon=True)
    thread.start()
    return {
        "process": process,
        "thread": thread,
        "queue": output_queue,
        "lines": [],
        "command": command,
        "output_root": output_root,
        "started_at": time.time(),
        "returncode": None,
        "log_written": False,
        "stopped": False,
    }


def poll_background_job(job: dict[str, Any]) -> None:
    output_queue: queue.Queue[str] = job["queue"]
    while not output_queue.empty():
        job["lines"].append(output_queue.get())
    process = job["process"]
    if process.poll() is not None:
        job["returncode"] = int(process.returncode or 0)
        if not job["log_written"]:
            output_root = Path(job["output_root"])
            output_root.mkdir(parents=True, exist_ok=True)
            run_text = "".join(job["lines"])
            (output_root / "streamlit-run.log").write_text(run_text, encoding="utf-8")
            if job["returncode"] != 0 or job.get("stopped"):
                (output_root / "streamlit-error.log").write_text(run_text, encoding="utf-8")
            job["log_written"] = True


def stop_background_job(job: dict[str, Any]) -> None:
    process = job["process"]
    if process.poll() is not None:
        return
    job["stopped"] = True
    try:
        if os.name != "nt":
            os.killpg(process.pid, signal.SIGTERM)
        else:
            process.terminate()
        process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        if os.name != "nt":
            os.killpg(process.pid, signal.SIGKILL)
        else:
            process.kill()
    except ProcessLookupError:
        pass


def render_job_controls(
    output_root: Path,
    *,
    use_llm: bool = False,
    llm_base_url: str = "",
    model_id: str = "",
    llm_api_key: str = "",
    auth_header: str = "Authorization",
    auth_prefix: str = "Bearer",
) -> None:
    job = st.session_state.get("analysis_job")
    if not job:
        return
    poll_background_job(job)
    elapsed = max(0, int(time.time() - float(job["started_at"])))
    running = process_running(job)
    status_label = "Running" if running else "Stopped" if job.get("stopped") else "Finished"
    st.subheader("Run Log")
    st.caption(f"{status_label} for {elapsed}s. Log file: {Path(job['output_root']) / 'streamlit-run.log'}")
    error_log = Path(job["output_root"]) / "analysis-errors.log"
    streamlit_error_log = Path(job["output_root"]) / "streamlit-error.log"
    if error_log.exists():
        st.caption(f"Analysis error log: {error_log}")
    elif streamlit_error_log.exists():
        st.caption(f"Streamlit error log: {streamlit_error_log}")
    log_text = "".join(job["lines"][-250:]) or "Starting analysis..."
    with st.expander("Show Run Log", expanded=running):
        st.code(log_text, language="text")
    if running:
        if st.button("Stop Analysis", type="secondary", key="stop_analysis_log"):
            stop_background_job(job)
            poll_background_job(job)
            st.rerun()
        time.sleep(1)
        st.rerun()
    elif job.get("returncode") == 0 and not job.get("stopped"):
        st.success(f"Analysis finished. Outputs are in {job['output_root']}")
        render_output_image_gallery(
            Path(job["output_root"]),
            use_llm=use_llm,
            llm_base_url=llm_base_url,
            model_id=model_id,
            llm_api_key=llm_api_key,
            auth_header=auth_header,
            auth_prefix=auth_prefix,
        )
        archive = zip_directory(Path(job["output_root"]))
        with archive.open("rb") as handle:
            st.download_button("Download Output ZIP", handle, file_name=archive.name, type="primary", use_container_width=True)
        if st.button("Clear Run Log"):
            st.session_state.pop("analysis_job", None)
            st.rerun()
    else:
        st.error(f"Analysis stopped or failed with exit code {job.get('returncode')}.")
        render_output_image_gallery(
            Path(job["output_root"]),
            use_llm=use_llm,
            llm_base_url=llm_base_url,
            model_id=model_id,
            llm_api_key=llm_api_key,
            auth_header=auth_header,
            auth_prefix=auth_prefix,
        )
        if st.button("Clear Run Log"):
            st.session_state.pop("analysis_job", None)
            st.rerun()


def zip_directory(directory: Path) -> Path:
    archive = directory.with_suffix(".zip")
    if archive.exists():
        archive.unlink()
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as zf:
        for path in directory.rglob("*"):
            if path.is_file() and path != archive:
                zf.write(path, path.relative_to(directory))
    return archive


def total_memory_gb() -> float | None:
    try:
        if sys.platform == "darwin":
            completed = subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True, timeout=2, check=False)
            if completed.returncode == 0:
                return int(completed.stdout.strip()) / (1024 ** 3)
        if sys.platform.startswith("linux") and hasattr(os, "sysconf"):
            pages = os.sysconf("SC_PHYS_PAGES")
            page_size = os.sysconf("SC_PAGE_SIZE")
            return float(pages * page_size) / (1024 ** 3)
        if sys.platform == "win32":
            completed = subprocess.run(
                ["wmic", "computersystem", "get", "TotalPhysicalMemory", "/value"],
                capture_output=True,
                text=True,
                timeout=4,
                check=False,
            )
            if completed.returncode == 0:
                match = re.search(r"TotalPhysicalMemory=(\d+)", completed.stdout)
                if match:
                    return int(match.group(1)) / (1024 ** 3)
    except (OSError, subprocess.TimeoutExpired, ValueError):
        return None
    return None


def detect_gpu_label() -> str:
    if sys.platform == "darwin" and platform.machine().lower() in {"arm64", "aarch64"}:
        return "Apple Silicon GPU"
    for command, label in (("nvidia-smi", "NVIDIA GPU"), ("rocm-smi", "AMD ROCm GPU")):
        path = shutil.which(command)
        if not path:
            continue
        try:
            completed = subprocess.run([path, "-L"], capture_output=True, text=True, timeout=2, check=False)
            if completed.returncode == 0 or completed.stdout.strip():
                return label
        except (OSError, subprocess.TimeoutExpired):
            continue
    return "CPU only"


def recommended_ollama_model(memory_gb: float | None = None, gpu_label: str | None = None) -> str:
    memory = memory_gb if memory_gb is not None else total_memory_gb()
    gpu = gpu_label or detect_gpu_label()
    has_gpu = gpu != "CPU only"
    if has_gpu and memory and memory >= 32:
        return "qwen3:14b"
    if has_gpu and (memory is None or memory >= 16):
        return "llama3.1:8b"
    return "llama3.2:3b"


def ollama_install_commands(model: str) -> list[str]:
    if sys.platform == "darwin":
        install = "brew install --cask ollama" if shutil.which("brew") else "open https://ollama.com/download"
    elif sys.platform.startswith("linux"):
        install = "curl -fsSL https://ollama.com/install.sh | sh"
    elif sys.platform == "win32":
        install = "winget install Ollama.Ollama"
    else:
        install = "Open https://ollama.com/download and install Ollama"
    return [
        install,
        "ollama serve",
        f"ollama pull {model}",
        f"ollama run {model}",
    ]


def default_provider() -> str:
    lmstudio = check_lmstudio(os.environ.get("LMSTUDIO_URL", "http://localhost:1234/v1"))
    if lmstudio.available:
        return "LM Studio"
    ollama = check_ollama(os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1"))
    if ollama.available:
        return "Ollama"
    if os.environ.get("OPENAI_API_KEY"):
        return "OpenAI"
    if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"):
        return "Gemini"
    if os.environ.get("OPENROUTER_API_KEY"):
        return "OpenRouter Free"
    if os.environ.get("META_ANALYSIS_LLM_API_KEY"):
        return "Custom OpenAI-compatible"
    return "Ollama"


def install_r_from_app() -> tuple[int, str]:
    command = [sys.executable, "-m", "meta_analysis_streamlit.install_r", "--yes"]
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        check=False,
        env=os.environ.copy(),
    )
    output = "\n".join(part for part in (completed.stdout, completed.stderr) if part)
    return completed.returncode, output


def current_package_version() -> str:
    try:
        return metadata.version("ams-meta_analysis")
    except metadata.PackageNotFoundError:
        return PACKAGE_VERSION


def version_tuple(value: str) -> tuple[int, ...]:
    parts = re.findall(r"\d+", value)
    return tuple(int(part) for part in parts[:4]) if parts else (0,)


@st.cache_data(ttl=3600, show_spinner=False)
def latest_pypi_version() -> tuple[str | None, str]:
    url = "https://pypi.org/pypi/ams-meta_analysis/json"
    try:
        request = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(request, timeout=5) as response:
            payload = json.loads(response.read().decode("utf-8"))
        version = str(payload.get("info", {}).get("version") or "")
        return (version or None), ""
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        return None, str(exc)


def install_package_update() -> tuple[int, str]:
    command = [sys.executable, "-m", "pip", "install", "--upgrade", "ams-meta_analysis"]
    completed = subprocess.run(
        command,
        text=True,
        capture_output=True,
        check=False,
        env=os.environ.copy(),
    )
    output = "\n".join(part for part in (completed.stdout, completed.stderr) if part)
    return completed.returncode, output


def streamlit_restart_command(argv: list[str] | None = None) -> list[str]:
    args = list(sys.argv if argv is None else argv)
    forwarded: list[str] = []
    for index, part in enumerate(args):
        text = str(part)
        if text.endswith("app.py") or Path(text).name == "app.py":
            forwarded = args[index + 1 :]
            break
    return [sys.executable, "-m", "streamlit", "run", str(Path(__file__).resolve()), *forwarded]


def restart_streamlit_app() -> None:
    command = streamlit_restart_command()
    os.execv(command[0], command)


def render_restart_after_update_button() -> None:
    if not st.session_state.get("package_update_ready_to_restart"):
        return
    st.warning("Restart Streamlit to load the newly installed package files. The browser may need a moment to reconnect.")
    if st.button("Restart Streamlit App", type="primary", use_container_width=True):
        restart_streamlit_app()


def render_update_panel() -> None:
    current = current_package_version()
    latest, error = latest_pypi_version()
    st.caption(f"Installed version: `{current}`")
    render_restart_after_update_button()
    if error:
        st.caption(f"Could not check PyPI updates: {error}")
        if st.button("Retry Update Check", use_container_width=True):
            latest_pypi_version.clear()
            st.rerun()
        return
    if not latest:
        st.caption("Could not find the latest PyPI version.")
        return
    if version_tuple(latest) > version_tuple(current):
        st.markdown(
            f'<div class="ma-update-status warn"><strong>Update available</strong><br><code>{latest}</code> is available on PyPI.</div>',
            unsafe_allow_html=True,
        )
        if st.button("Install Update from PyPI", type="primary", use_container_width=True):
            with st.spinner("Installing package update. Restart the app after this completes."):
                update_code, update_output = install_package_update()
            st.code(update_output or "(no output)", language="text")
            if update_code == 0:
                st.session_state.package_update_ready_to_restart = True
                st.success("Update installed. Restart Streamlit to use the new version.")
                render_restart_after_update_button()
            else:
                st.error("Update failed. Review the pip output above.")
    else:
        st.markdown(
            f'<div class="ma-update-status"><strong>ams-meta_analysis is up to date</strong><br><code>{latest}</code></div>',
            unsafe_allow_html=True,
        )
    if st.button("Refresh Update Status", type="secondary", use_container_width=True):
        latest_pypi_version.clear()
        st.rerun()


def normalize_column_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value).lower())


def unique_existing(values: list[str], columns: list[str]) -> list[str]:
    selected: list[str] = []
    for value in values:
        if value in columns and value not in selected:
            selected.append(value)
    return selected


def option_index(options: list[str], value: Any, default: int = 0) -> int:
    try:
        return options.index(str(value))
    except ValueError:
        return default


def auto_group_columns(df: pd.DataFrame, columns: list[str]) -> list[str]:
    outcome_terms = (
        "event", "events", "total", "sample", "number", "count", "n", "mean", "sd",
        "se", "ci", "lower", "upper", "effect", "risk", "ratio", "or", "rr", "hr",
        "tp", "fp", "tn", "fn", "sensitivity", "specificity", "auc", "pvalue",
    )
    identifier_terms = ("study", "author", "citation", "reference", "trialid", "studyid")
    group_terms = (
        "subgroup", "group", "category", "class", "classification", "type", "arm",
        "treatment", "intervention", "control", "comparator", "etiology", "aetiology",
        "region", "country", "setting", "center", "centre", "design", "severity",
        "stage", "riskstrata", "riskgroup",
    )
    scored: list[tuple[int, str]] = []
    for column in columns:
        norm = normalize_column_name(column)
        if any(term in norm for term in identifier_terms):
            continue
        if any(norm == term or norm.endswith(term) for term in ("n", "sd", "se")):
            continue
        series = df[column] if column in df else pd.Series(dtype=object)
        non_missing = series.dropna()
        unique_count = int(non_missing.nunique(dropna=True))
        if unique_count < 2:
            continue
        numeric = pd.to_numeric(non_missing, errors="coerce")
        numeric_ratio = float(numeric.notna().mean()) if len(non_missing) else 0.0
        low_cardinality = unique_count <= max(8, int(len(non_missing) * 0.55))
        has_group_hint = any(term in norm for term in group_terms)
        has_outcome_hint = any(term in norm for term in outcome_terms)
        if has_group_hint or (low_cardinality and numeric_ratio < 0.65 and not has_outcome_hint):
            score = 0
            if "subgroup" in norm:
                score += 5
            if has_group_hint:
                score += 3
            if not has_outcome_hint:
                score += 2
            if low_cardinality:
                score += 1
            scored.append((score, column))
    return [column for _, column in sorted(scored, key=lambda item: (-item[0], columns.index(item[1])))]


def auto_meta_regressor_columns(df: pd.DataFrame, columns: list[str], subgroup_columns: list[str]) -> list[str]:
    excluded_terms = (
        "event", "events", "total", "count", "mean", "median", "sd", "se", "ci",
        "lower", "upper", "effect", "ratio", "or", "rr", "hr", "tp", "fp", "tn",
        "fn", "sensitivity", "specificity", "auc", "pvalue",
    )
    moderator_terms = (
        "regressor", "covariate", "moderator", "age", "bmi", "year", "followup",
        "follow", "duration", "month", "size", "sample", "male", "female", "sex",
        "percent", "percentage", "proportion", "dose", "baseline", "severity",
        "score", "region", "country", "design", "etiology", "aetiology", "type",
    )
    selected_subgroups = set(subgroup_columns)
    scored: list[tuple[int, str]] = []
    for column in columns:
        if column in selected_subgroups:
            continue
        norm = normalize_column_name(column)
        if any(term in norm for term in excluded_terms) and not any(
            term in norm for term in ("regressor", "covariate", "moderator", "age", "bmi", "year", "followup", "duration")
        ):
            continue
        series = df[column] if column in df else pd.Series(dtype=object)
        non_missing = series.dropna()
        if int(non_missing.nunique(dropna=True)) < 2:
            continue
        numeric = pd.to_numeric(non_missing, errors="coerce")
        numeric_ratio = float(numeric.notna().mean()) if len(non_missing) else 0.0
        has_moderator_hint = any(term in norm for term in moderator_terms)
        if numeric_ratio >= 0.75 or has_moderator_hint:
            score = 0
            if any(term in norm for term in ("regressor", "covariate", "moderator")):
                score += 5
            if has_moderator_hint:
                score += 3
            if numeric_ratio >= 0.75:
                score += 2
            scored.append((score, column))
    return [column for _, column in sorted(scored, key=lambda item: (-item[0], columns.index(item[1])))]


def comma_join(values: list[str]) -> str:
    return ",".join(value for value in values if value)


def binary_endpoint_mapping_defaults(columns: list[str]) -> dict[str, str]:
    mapping = default_binary_mapping(columns)
    mapped_columns = mapping.get("columns") if isinstance(mapping, dict) else {}
    return {str(field): str(column) for field, column in (mapped_columns or {}).items() if column in columns}


def column_choice_value(options: list[str], value: str, fallback: str = "(auto)") -> str:
    return value if value in options else fallback


def append_binary_endpoint_overrides(
    command: list[str],
    *,
    route: str,
    binary_endpoint_columns: dict[str, str],
    intervention_label: str,
    control_label: str,
) -> None:
    if route not in {"Auto route workbook", "Binary pairwise"}:
        return
    flag_by_field = {
        "study_label": "--study-column",
        "event_e": "--event-e-column",
        "n_e": "--n-e-column",
        "non_event_e": "--non-event-e-column",
        "event_c": "--event-c-column",
        "n_c": "--n-c-column",
        "non_event_c": "--non-event-c-column",
    }
    for field, flag in flag_by_field.items():
        value = binary_endpoint_columns.get(field, "")
        if value:
            command += [flag, value]
    if intervention_label:
        command += ["--intervention-label", intervention_label]
    if control_label:
        command += ["--control-label", control_label]


def append_column_overrides(
    command: list[str],
    *,
    route: str,
    group_column: str,
    subgroup_columns: list[str],
    meta_regressor_columns: list[str],
) -> None:
    supports_subgroups = route in {
        "Auto route workbook",
        "Binary pairwise",
        "Continuous pairwise",
        "Single-arm",
    }
    supports_meta_regression = route in {
        "Auto route workbook",
        "Binary pairwise",
        "Continuous pairwise",
    }
    if supports_subgroups:
        if group_column:
            command += ["--group-column", group_column]
        if subgroup_columns:
            command += ["--subgroup-columns", comma_join(subgroup_columns)]
        elif not group_column:
            command += ["--subgroup-columns", "none"]
    if supports_meta_regression and meta_regressor_columns:
        command += ["--covariate-columns", comma_join(meta_regressor_columns)]


def build_command(
    *,
    input_path: Path,
    output_root: Path,
    route: str,
    selected_sheets: list[str],
    outcome_name: str,
    lmstudio_enabled: bool,
    lmstudio_url: str,
    model_id: str,
    binary_effect_size: str,
    network_engine: str,
    network_effect: str,
    network_model: str,
    single_arm_type: str,
    diagnostic_mode: str,
    jobs: int,
    dry_run: bool,
    install_r_packages: bool,
    analyze_all_sheets: bool = False,
    group_column: str = "",
    subgroup_columns: list[str] | None = None,
    meta_regressor_columns: list[str] | None = None,
    binary_endpoint_columns: dict[str, str] | None = None,
    intervention_label: str = "",
    control_label: str = "",
) -> list[str]:
    subgroup_columns = subgroup_columns or []
    meta_regressor_columns = meta_regressor_columns or []
    binary_endpoint_columns = binary_endpoint_columns or {}
    common = [str(input_path)]
    sheet_args: list[str] = []
    if analyze_all_sheets:
        sheet_args = ["--all-sheets"]
    elif selected_sheets:
        sheet_args = ["--sheets", ",".join(selected_sheets)]

    if route == "Auto route workbook":
        command = [
            sys.executable,
            str(runner_script("main.py")),
            *common,
            "--output-root",
            str(output_root),
            "--yes",
            "--continue-on-error",
            "--jobs",
            str(jobs),
            "--binary-effect-size",
            binary_effect_size,
            "--network-engine",
            network_engine,
            *sheet_args,
        ]
        if dry_run:
            command.append("--dry-run")
        if install_r_packages:
            command.append("--install-r-packages")
    elif route == "Binary pairwise":
        command = [
            sys.executable,
            str(runner_script("binary_outcome.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
            "--binary-effect-size",
            binary_effect_size,
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    elif route == "Continuous pairwise":
        command = [
            sys.executable,
            str(runner_script("continuous_outcome.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    elif route == "Single-arm":
        command = [
            sys.executable,
            str(runner_script("single_arm_meta_analysis.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
            "--type",
            single_arm_type,
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    elif route == "Diagnostic accuracy":
        command = [
            sys.executable,
            str(runner_script("diagnostic_meta_analysis.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
            "--mode",
            diagnostic_mode,
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
    else:
        command = [
            sys.executable,
            str(runner_script("network_meta_analysis.py")),
            *common,
            "--output-dir",
            str(output_root),
            "--yes",
            "--engine",
            network_engine,
            "--effect",
            network_effect,
            "--model",
            network_model,
        ]
        if selected_sheets:
            command += ["--sheet", selected_sheets[0]]
        if install_r_packages:
            command.append("--install-r-packages")

    if outcome_name and route != "Auto route workbook":
        command += ["--outcome", outcome_name]
    if install_r_packages and route in {
        "Binary pairwise",
        "Continuous pairwise",
        "Single-arm",
        "Diagnostic accuracy",
    }:
        command.append("--install-r-packages")
    append_column_overrides(
        command,
        route=route,
        group_column=group_column,
        subgroup_columns=subgroup_columns,
        meta_regressor_columns=meta_regressor_columns,
    )
    append_binary_endpoint_overrides(
        command,
        route=route,
        binary_endpoint_columns=binary_endpoint_columns,
        intervention_label=intervention_label,
        control_label=control_label,
    )
    if not lmstudio_enabled and route != "Network meta-analysis":
        command.append("--no-lmstudio")
    elif route != "Network meta-analysis":
        command += ["--lmstudio-url", lmstudio_url]
        if model_id:
            command += ["--model", model_id]
    return command


def main() -> None:
    ensure_rscript_on_path()
    st.set_page_config(page_title="AMS Meta-Analysis Runner", page_icon=":bar_chart:", layout="wide")
    apply_theme()
    render_header()
    render_active_job_banner("top")

    with st.sidebar:
        st.header("Runtime")
        sidebar_job = st.session_state.get("analysis_job")
        if process_running(sidebar_job):
            st.error("Analysis running")
            if st.button("Stop Analysis", key="stop_analysis_sidebar", use_container_width=True):
                stop_background_job(sidebar_job)
                poll_background_job(sidebar_job)
                st.rerun()
            st.divider()
        lmstudio_status = check_lmstudio(os.environ.get("LMSTUDIO_URL", "http://localhost:1234/v1"))
        ollama_status = check_ollama(os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1"))
        local_llm_available = lmstudio_status.available or ollama_status.available
        providers = list(PROVIDER_DEFAULTS)
        provider = st.selectbox("LLM provider", providers, index=providers.index(default_provider()))
        provider_defaults = PROVIDER_DEFAULTS[provider]
        if provider == "LM Studio":
            base_url_value = os.environ.get("LMSTUDIO_URL", provider_defaults["base_url"])
        elif provider == "Ollama":
            base_url_value = os.environ.get("OLLAMA_BASE_URL", provider_defaults["base_url"])
        else:
            base_url_value = provider_defaults["base_url"]
        llm_base_url = st.text_input(
            "API base URL",
            value=base_url_value,
            disabled=provider == "Manual/no LLM",
        )
        stored_key, stored_key_source = api_key_from_saved_or_env(provider)
        llm_api_key_input = st.text_input(
            "API key",
            value="",
            type="password",
            placeholder="Saved key will be used" if stored_key else "",
            disabled=provider in {"LM Studio", "Ollama", "Manual/no LLM"},
            help=(
                "OpenAI-compatible providers use an Authorization: Bearer token. "
                "Saved or environment keys are reused without being shown here."
            ),
        )
        llm_api_key = llm_api_key_input.strip() or stored_key
        can_save_key = provider not in {"LM Studio", "Ollama", "Manual/no LLM"}
        if can_save_key:
            if stored_key_source:
                st.caption(f"API key loaded from {stored_key_source} and hidden. Enter a new key only if you want to replace it.")
            save_col, clear_col = st.columns(2)
            with save_col:
                if st.button("Save API Key", use_container_width=True, disabled=not bool(llm_api_key_input.strip())):
                    save_provider_api_key(provider, llm_api_key_input.strip())
                    st.success("API key saved locally for future app launches.")
                    st.rerun()
            with clear_col:
                if st.button("Clear Saved Key", use_container_width=True, disabled=provider not in load_saved_secrets()):
                    clear_provider_api_key(provider)
                    st.success("Saved API key cleared.")
                    st.rerun()
        with st.expander("Advanced API auth"):
            auth_header = st.text_input("Auth header", value=provider_defaults["auth_header"], disabled=provider == "Manual/no LLM")
            auth_prefix = st.text_input("Auth prefix", value=provider_defaults["auth_prefix"], disabled=provider == "Manual/no LLM")

        if provider == "LM Studio":
            status = check_lmstudio(llm_base_url)
        elif provider == "Ollama":
            status = check_ollama(llm_base_url)
        elif provider == "OpenRouter Free":
            status = check_openrouter_free(llm_base_url, llm_api_key, auth_header, auth_prefix)
        elif provider == "Manual/no LLM":
            status = LmStudioStatus(False, [], "LLM calls disabled; the app will use manual selections and runner heuristics.")
        elif not llm_api_key:
            status = LmStudioStatus(False, [], f"{provider} needs an API key before the runner can use it.")
        else:
            status = check_openai_compatible(llm_base_url, llm_api_key, auth_header, auth_prefix)

        if status.available:
            st.success(status.message)
        elif provider == "Manual/no LLM":
            st.info(status.message)
        else:
            st.warning(f"{status.message} Manual study-characteristic choices are still available below.")

        model_options = [""] + status.models
        memory_gb = total_memory_gb()
        gpu_label = detect_gpu_label()
        suggested_ollama_model = recommended_ollama_model(memory_gb, gpu_label)
        if provider == "Ollama":
            memory_label = f"{memory_gb:.0f} GB RAM" if memory_gb else "unknown RAM"
            st.caption(f"Hardware estimate: {gpu_label}, {memory_label}. Suggested model: `{suggested_ollama_model}`.")
            if status.available and not status.models:
                st.info("Ollama is running, but no local models were found. Pull the suggested model before using LLM assessment.")
                st.code(f"ollama pull {suggested_ollama_model}", language="bash")
        if provider == "OpenRouter Free":
            st.caption(
                "Uses OpenRouter's zero-cost router/models only. You still need an OpenRouter API key, "
                "but keep the model as `openrouter/free` or a `:free` model to avoid paid model usage."
            )
            if not llm_api_key:
                st.code("OPENROUTER_API_KEY=sk-or-v1-...", language="bash")
        if not local_llm_available:
            st.warning("No local LLM provider was found. Install LM Studio or Ollama, or use a hosted API/manual mode.")
            with st.expander("Install a local LLM", expanded=provider == "Ollama"):
                st.markdown("**Ollama CLI setup**")
                st.code("\n".join(ollama_install_commands(suggested_ollama_model)), language="bash")
                st.markdown("**LM Studio**")
                st.code("Open https://lmstudio.ai/download and install LM Studio, then start the local server.", language="text")
        selected_model = st.selectbox("Discovered model", model_options, index=0, help="Leave blank to use the custom model field or provider default.")
        model_default = os.environ.get("META_ANALYSIS_LLM_MODEL", os.environ.get("LMSTUDIO_MODEL", ""))
        if provider == "Ollama" and not model_default and not status.models:
            model_default = suggested_ollama_model
        if provider == "OpenRouter Free" and not model_default:
            model_default = "openrouter/free"
        custom_model = st.text_input("Model override", value=model_default)
        model_id = custom_model.strip() or selected_model or (status.models[0] if status.models else "")
        if provider == "LM Studio":
            use_llm = status.available
        elif provider == "Ollama":
            use_llm = status.available and bool(status.models) and bool(model_id)
        else:
            use_llm = provider != "Manual/no LLM" and (status.available or bool(model_id and llm_api_key))
        st.toggle("Use selected LLM provider", value=use_llm, disabled=True)
        rscript, rscript_on_path = find_rscript()
        r_version = rscript_version(rscript) if rscript else None
        r_supported = bool(r_version and r_version >= MIN_R_VERSION)
        if rscript:
            r_message = f"Rscript {format_r_version(r_version)}: {rscript}"
            if r_supported:
                st.success(r_message)
            else:
                st.error(
                    f"{r_message}. R {format_r_version(MIN_R_VERSION)} or newer is required for current CRAN packages such as meta."
                )
            if not rscript_on_path:
                st.caption("Rscript was found outside PATH. The app will add it to PATH for analysis runs.")
                st.code(path_export_command(rscript), language="bash")
        else:
            st.error("Rscript was not found on PATH. Install R before running full analyses.")
        if not r_supported:
            st.caption(
                "Use the button below to install or repair R from inside the app. "
                "It prefers Conda/Mamba when available, otherwise Homebrew, apt, dnf/yum, pacman, or winget."
            )
            if st.button("Install or Update R Runtime", type="primary", use_container_width=True):
                with st.spinner("Installing R runtime and required R packages. This can take several minutes."):
                    install_code, install_output = install_r_from_app()
                st.code(install_output or "(no output)", language="text")
                if install_code == 0:
                    ensure_rscript_on_path()
                    st.success("R setup completed. The app will refresh and re-check Rscript.")
                    st.rerun()
                else:
                    st.error("R setup did not complete. If your system asks for sudo/admin access, run the shown command in a terminal.")
            with st.expander("Terminal fallback"):
                st.code("meta-analysis-install-r --dry-run\nmeta-analysis-install-r\nmeta-analysis-doctor", language="bash")
        st.divider()
        st.caption("Install command")
        st.code("pip install ams-meta_analysis\nams-meta_analysis", language="bash")
        with st.expander("Package updates", expanded=False):
            render_update_panel()

    uploaded = st.file_uploader("Workbook or CSV", type=sorted(ext.strip(".") for ext in SUPPORTED_INPUTS))
    if uploaded is None:
        st.markdown('<div class="ma-upload-empty">Upload an Excel workbook or CSV to begin.</div>', unsafe_allow_html=True)
        render_examples()
        return

    suffix = Path(uploaded.name).suffix.lower()
    if suffix not in SUPPORTED_INPUTS:
        st.error(f"Unsupported file type: {suffix}")
        return

    if "input_path" not in st.session_state or st.session_state.get("uploaded_name") != uploaded.name:
        st.session_state.input_path = save_upload(uploaded)
        st.session_state.uploaded_name = uploaded.name

    input_path = Path(st.session_state.input_path)
    if st.session_state.get("header_overrides_for_input") != str(input_path):
        st.session_state.header_row_overrides = {}
        st.session_state.header_overrides_for_input = str(input_path)
        st.session_state.header_assessment = {}
    header_row_overrides = {
        str(sheet): int(row)
        for sheet, row in dict(st.session_state.get("header_row_overrides", {})).items()
        if isinstance(sheet, str)
    }
    overview = workbook_overview(str(input_path), header_overrides_payload(header_row_overrides))
    sheet_names = list(overview)

    setup_tab, preview_tab, command_tab = st.tabs(["Configure", "Preview", "Command"])
    with setup_tab:
        left, right = st.columns([1.05, 0.95])
        with left:
            st.subheader("Workbook Scope")
            analyze_all_sheets = st.checkbox(
                "Select all sheets",
                value=False,
                help=(
                    "Use every sheet in the workbook. Auto route will analyze all sheets. "
                    "Specialized routes still run the first selected sheet only."
                ),
            )
            if analyze_all_sheets:
                selected_sheets = list(sheet_names)
                st.multiselect(
                    "Analyze sheets",
                    sheet_names,
                    default=sheet_names,
                    disabled=True,
                    help="All workbook sheets are selected.",
                )
                st.caption(f"All {len(selected_sheets)} sheet(s) selected.")
            else:
                selected_sheets = st.multiselect(
                    "Analyze sheets",
                    sheet_names,
                    default=sheet_names[:1],
                    help="Auto route can analyze multiple sheets. Specialized routes use the first selected sheet.",
                )
            display_sheet_routes, display_route_source = sheet_routes_for_display(
                overview,
                selected_sheets,
                st.session_state.get("route_assessment"),
            )
            if selected_sheets:
                st.caption(f"{len(selected_sheets)} of {len(sheet_names)} sheet(s) selected.")
                with st.expander("Selected sheet route plan", expanded=len(selected_sheets) > 1):
                    st.caption(f"Route source: {display_route_source}. {route_count_summary(display_sheet_routes)}")
                    st.dataframe(
                        selected_sheet_table(overview, selected_sheets, display_sheet_routes),
                        use_container_width=True,
                        hide_index=True,
                        height=min(280, 38 * max(2, len(selected_sheets)) + 38),
                    )
            else:
                st.warning("Select at least one sheet before running an analysis.")
            preview_options = selected_sheets or sheet_names
            preview_sheet = st.selectbox(
                "Preview sheet",
                preview_options,
                help="Switch between selected sheets to inspect the rows and columns before running.",
            )
            meta = overview[preview_sheet]
            st.caption(f"{meta['rows']} rows, {len(meta['columns'])} columns in the selected preview sheet.")
            preview_display = display_preview(meta["preview"])
            if preview_display.empty:
                st.info("The selected preview sheet has no rows to display.")
            else:
                st.dataframe(preview_display, use_container_width=True, height=260)
            if suffix != ".csv":
                st.subheader("Sheet Structure")
                active_header = int(meta.get("header_row", 0))
                detected_header = int(meta.get("detected_header_row", active_header))
                source = str(meta.get("header_source") or "Auto detected")
                st.caption(
                    f"{source}: using Excel row {active_header + 1} as column headers. "
                    f"Auto-detected row: {detected_header + 1}."
                )
                raw_preview = meta.get("raw_preview")
                max_header_rows = len(raw_preview) if isinstance(raw_preview, pd.DataFrame) and not raw_preview.empty else 10
                row_options = list(range(1, max_header_rows + 1))
                selected_header_row = st.selectbox(
                    "Header row",
                    row_options,
                    index=row_options.index(active_header + 1) if active_header + 1 in row_options else 0,
                    help="Choose the original Excel row that contains column names. The app will use rows below it as data.",
                )
                if selected_header_row != active_header + 1:
                    updated_overrides = dict(st.session_state.get("header_row_overrides", {}))
                    updated_overrides[preview_sheet] = selected_header_row - 1
                    st.session_state.header_row_overrides = updated_overrides
                    st.rerun()
                structure_cols = st.columns(2)
                with structure_cols[0]:
                    if use_llm and st.button("Ask LLM to Check Header Rows", use_container_width=True):
                        with st.spinner("Asking the selected LLM to review worksheet header rows..."):
                            try:
                                header_assessment = llm_header_assessment(
                                    overview=overview,
                                    selected_sheets=selected_sheets or [preview_sheet],
                                    base_url=llm_base_url,
                                    model_id=model_id,
                                    api_key=llm_api_key,
                                    auth_header=auth_header,
                                    auth_prefix=auth_prefix,
                                )
                                updated_overrides = dict(st.session_state.get("header_row_overrides", {}))
                                for sheet, row in header_assessment.get("header_rows", {}).items():
                                    updated_overrides[sheet] = max(0, int(row) - 1)
                                st.session_state.header_row_overrides = updated_overrides
                                st.session_state.header_assessment = header_assessment
                                st.rerun()
                            except Exception as exc:
                                st.info(f"LLM sheet-structure assessment was unavailable: {friendly_llm_route_error(exc)}")
                    elif not use_llm:
                        st.caption("LLM structure review is off. Use the header-row selector above.")
                with structure_cols[1]:
                    if st.button("Reset Header Row", use_container_width=True, disabled=preview_sheet not in header_row_overrides):
                        updated_overrides = dict(st.session_state.get("header_row_overrides", {}))
                        updated_overrides.pop(preview_sheet, None)
                        st.session_state.header_row_overrides = updated_overrides
                        st.rerun()
                header_assessment = st.session_state.get("header_assessment") or {}
                if header_assessment.get("reason"):
                    st.caption(f"LLM structure note: {header_assessment['reason']}")
                with st.expander("Original top rows"):
                    if isinstance(raw_preview, pd.DataFrame) and not raw_preview.empty:
                        st.dataframe(display_preview(raw_preview), use_container_width=True, height=240)
                    else:
                        st.info("Raw top rows are not available for CSV input.")
        with right:
            st.subheader("Study Characteristics")
            assessment_key = json.dumps(
                {
                    "input": str(input_path),
                    "sheets": selected_sheets,
                    "provider": provider,
                    "base_url": llm_base_url,
                    "model": model_id,
                    "use_llm": bool(use_llm),
                },
                sort_keys=True,
            )
            if st.session_state.get("route_assessment_key") != assessment_key:
                auto_assess_with_llm = should_auto_assess_routes_with_llm(provider, selected_sheets, bool(use_llm), model_id)
                if auto_assess_with_llm:
                    with st.spinner("Assessing workbook with the selected LLM..."):
                        try:
                            st.session_state.route_assessment = llm_route_assessment(
                                overview=overview,
                                selected_sheets=selected_sheets,
                                base_url=llm_base_url,
                                model_id=model_id,
                                api_key=llm_api_key,
                                auth_header=auth_header,
                                auth_prefix=auth_prefix,
                            )
                        except Exception as exc:
                            llm_message = friendly_llm_route_error(exc)
                            st.session_state.route_assessment = fallback_route_assessment_with_note(
                                overview,
                                selected_sheets,
                                source="Heuristic after LLM fallback",
                                reason=llm_message,
                            )
                            st.info(llm_message)
                elif use_llm and model_id and len(selected_sheets) > 1 and provider not in LOCAL_LLM_PROVIDERS:
                    st.session_state.route_assessment = fallback_route_assessment_with_note(
                        overview,
                        selected_sheets,
                        source="Heuristic",
                        reason=hosted_multi_sheet_route_reason(provider),
                    )
                else:
                    st.session_state.route_assessment = fallback_route_assessment(overview, selected_sheets)
                st.session_state.route_assessment_key = assessment_key
                st.session_state.analysis_route = st.session_state.route_assessment.get("recommended_route", "Auto route workbook")
            assessment = st.session_state.get("route_assessment") or fallback_route_assessment(overview, selected_sheets)
            llm_button_label = "Reassess Selected Sheets with LLM" if len(selected_sheets) > 1 else "Reassess Workbook with LLM"
            if use_llm and st.button(llm_button_label, use_container_width=True):
                with st.spinner("Reassessing workbook with the selected LLM..."):
                    try:
                        st.session_state.route_assessment = llm_route_assessment(
                            overview=overview,
                            selected_sheets=selected_sheets,
                            base_url=llm_base_url,
                            model_id=model_id,
                            api_key=llm_api_key,
                            auth_header=auth_header,
                            auth_prefix=auth_prefix,
                        )
                        st.session_state.route_assessment_key = assessment_key
                        st.session_state.analysis_route = st.session_state.route_assessment.get("recommended_route", "Auto route workbook")
                        st.rerun()
                    except Exception as exc:
                        llm_message = friendly_llm_route_error(exc)
                        st.session_state.route_assessment = fallback_route_assessment_with_note(
                            overview,
                            selected_sheets,
                            source="Heuristic after LLM fallback",
                            reason=llm_message,
                        )
                        st.info(llm_message)
            elif not use_llm:
                st.caption("LLM assessment is off. Review the heuristic suggestion and choose the study type manually.")
            assessment_route = normalize_route(assessment.get("recommended_route")) or "Auto route workbook"
            st.caption(f"{assessment.get('source', 'Manual')} suggestion: {assessment_route}. {assessment.get('reason', '')}")
            sheet_routes = assessment.get("sheet_routes") if isinstance(assessment.get("sheet_routes"), dict) else {}
            if len(selected_sheets) > 1:
                st.caption(f"Selected sheet route plan: {route_count_summary(sheet_routes)}")
            route = st.selectbox(
                "Analysis route",
                ROUTES,
                index=option_index(ROUTES, st.session_state.get("analysis_route", assessment_route)),
                key="analysis_route",
            )
            multi_sheet_auto = len(selected_sheets) > 1 and route == "Auto route workbook"
            with st.expander("Expected Sheet Format", expanded=not use_llm):
                render_expected_format_help(route)
            if multi_sheet_auto:
                outcome_name = ""
                st.info("Multiple sheets are selected. Outcome labels and sheet-specific analysis options will be assigned per sheet by Auto route.")
            else:
                outcome_name = st.text_input("Outcome label", value=preview_sheet if selected_sheets else "")
            if analyze_all_sheets and route != "Auto route workbook":
                first_sheet = selected_sheets[0] if selected_sheets else "the first selected sheet"
                st.warning(
                    f"Select all sheets is meant for Auto route workbook. {route} will run only '{first_sheet}'."
                )
            binary_effect_size = str(assessment.get("binary_effect_size") or "auto")
            single_arm_type = str(assessment.get("single_arm_type") or "auto")
            diagnostic_mode = str(assessment.get("diagnostic_mode") or "single")
            network_engine = str(assessment.get("network_engine") or "frequentist")
            network_effect = str(assessment.get("network_effect") or "auto")
            network_model = str(assessment.get("network_model") or "random")
            if route == "Binary pairwise" or (route == "Auto route workbook" and not multi_sheet_auto):
                binary_options = ["auto", "RR", "OR", "RD"]
                binary_effect_size = st.selectbox(
                    "Binary effect size",
                    binary_options,
                    index=option_index(binary_options, binary_effect_size),
                )
            if route == "Single-arm":
                single_options = ["auto", "proportion", "mean"]
                single_arm_type = st.selectbox(
                    "Single-arm outcome",
                    single_options,
                    index=option_index(single_options, single_arm_type),
                )
            if route == "Diagnostic accuracy":
                diagnostic_options = ["single", "comparative"]
                diagnostic_mode = st.selectbox(
                    "Diagnostic mode",
                    diagnostic_options,
                    index=option_index(diagnostic_options, diagnostic_mode),
                )
            if route in {"Auto route workbook", "Network meta-analysis"}:
                net_a, net_b, net_c = st.columns(3)
                with net_a:
                    network_options = ["frequentist", "bayesian", "both"]
                    network_engine = st.selectbox(
                        "Network engine",
                        network_options,
                        index=option_index(network_options, network_engine),
                    )
                if route == "Network meta-analysis":
                    with net_b:
                        effect_options = ["auto", "RR", "OR", "RD", "MD", "SMD"]
                        network_effect = st.selectbox(
                            "Network effect",
                            effect_options,
                            index=option_index(effect_options, network_effect),
                        )
                    with net_c:
                        model_options = ["random", "common", "fixed"]
                        network_model = st.selectbox(
                            "Network model",
                            model_options,
                            index=option_index(model_options, network_model),
                        )
            dry_run = st.toggle("Dry run command planning", value=False)
            jobs = st.number_input("Parallel jobs", min_value=1, max_value=8, value=1, step=1)
            estimate = runtime_estimate_label(len(selected_sheets), route, int(jobs), bool(use_llm))
            st.metric("Estimated analysis time", estimate)
            st.caption("Actual runtime depends on R package availability, model speed, network analysis settings, and workbook size.")
            install_r_packages = st.toggle("Install missing R packages before analysis", value=False)
            default_output_root = input_path.parent / "outputs"
            if (
                "output_root_text" not in st.session_state
                or st.session_state.get("output_for_input") != str(input_path)
            ):
                st.session_state.output_root_text = str(default_output_root)
                st.session_state.output_for_input = str(input_path)

            browse_col, path_col = st.columns([0.22, 0.78], vertical_alignment="bottom")
            with browse_col:
                browse_clicked = st.button(
                    "Browse...",
                    use_container_width=True,
                    help="Open a local folder picker. If your browser blocks native dialogs, type or paste the folder path on the right.",
                )
            with path_col:
                output_root_text = st.text_input(
                    "Output folder",
                    key="output_root_text",
                    help=(
                        "Where generated CSV, R scripts, plots, Word summaries, and run logs are saved. "
                        "You can use the default run folder, choose an existing folder, or type a new folder path."
                    ),
                )
            if browse_clicked:
                selected_folder = choose_output_directory(Path(st.session_state.output_root_text).parent)
                if selected_folder:
                    st.session_state.output_root_text = selected_folder
                    st.rerun()
                st.warning("No folder was selected. You can still type or paste a folder path.")

            with st.expander("What do these options mean?"):
                st.markdown(
                    """
                    - **Auto route workbook**: classify selected sheets and dispatch each to the best runner. Use this for multi-outcome workbooks.
                    - **Select all sheets**: sends every workbook sheet to Auto route. Specialized routes still use the first selected sheet.
                    - **Binary pairwise**: one selected sheet with intervention/control event counts, such as adverse events or clinical success.
                    - **Continuous pairwise**: one selected sheet with means, SDs, and sample sizes.
                    - **Single-arm**: one selected sheet with proportions or means from a single group.
                    - **Diagnostic accuracy**: one selected sheet with TP, FP, TN, and FN columns.
                    - **Network meta-analysis**: one selected long-arm network dataset.
                    - **Dry run**: show the planned command and generated decisions without running the full analysis.
                    - **Parallel jobs**: only applies to auto-routed workbook runs with multiple selected sheets.
                    - **Install missing R packages**: lets the runner install required CRAN packages such as `meta` before analysis.
                    - **Groups and subgroups**: categorical columns used for subgroup analyses. The primary group is placed first when passed to supported runners.
                    - **Meta-regressors**: numeric or categorical study-level moderators used by binary and continuous pairwise runners.
                    """
                )

        column_meta = overview[preview_sheet]
        preview_df = column_meta["preview"]
        available_columns = list(column_meta["columns"])
        auto_subgroups = auto_group_columns(preview_df, available_columns)
        auto_covariates = auto_meta_regressor_columns(preview_df, available_columns, auto_subgroups)
        supports_subgroups = route in {"Auto route workbook", "Binary pairwise", "Continuous pairwise", "Single-arm"}
        supports_meta_regression = route in {"Auto route workbook", "Binary pairwise", "Continuous pairwise"}
        multi_sheet_auto = len(selected_sheets) > 1 and route == "Auto route workbook"
        supports_binary_endpoint_review = route in {"Auto route workbook", "Binary pairwise"}

        st.subheader("Binary Endpoint Columns")
        binary_endpoint_columns: dict[str, str] = {}
        intervention_label_override = ""
        control_label_override = ""
        if supports_binary_endpoint_review:
            st.caption(
                "Review the event, non-event, and total columns before running. Auto route applies these only to binary outcomes with matching columns."
            )
            binary_defaults = binary_endpoint_mapping_defaults(available_columns)
            auto_options = ["(auto)", *available_columns]
            optional_options = ["(auto)", "(none)", *available_columns]
            endpoint_cols_a = st.columns(4)
            with endpoint_cols_a[0]:
                study_choice = st.selectbox(
                    "Study column",
                    auto_options,
                    index=option_index(auto_options, column_choice_value(auto_options, binary_defaults.get("study_label", ""))),
                    key=f"binary_study_column_{preview_sheet}",
                )
            with endpoint_cols_a[1]:
                event_e_choice = st.selectbox(
                    "Treatment events",
                    auto_options,
                    index=option_index(auto_options, column_choice_value(auto_options, binary_defaults.get("event_e", ""))),
                    key=f"binary_event_e_column_{preview_sheet}",
                )
            with endpoint_cols_a[2]:
                n_e_choice = st.selectbox(
                    "Treatment total",
                    optional_options,
                    index=option_index(optional_options, column_choice_value(optional_options, binary_defaults.get("n_e", ""))),
                    key=f"binary_n_e_column_{preview_sheet}",
                )
            with endpoint_cols_a[3]:
                non_event_e_choice = st.selectbox(
                    "Treatment non-events",
                    optional_options,
                    index=option_index(optional_options, column_choice_value(optional_options, binary_defaults.get("non_event_e", ""))),
                    key=f"binary_non_event_e_column_{preview_sheet}",
                )
            endpoint_cols_b = st.columns(4)
            with endpoint_cols_b[0]:
                event_c_choice = st.selectbox(
                    "Control events",
                    auto_options,
                    index=option_index(auto_options, column_choice_value(auto_options, binary_defaults.get("event_c", ""))),
                    key=f"binary_event_c_column_{preview_sheet}",
                )
            with endpoint_cols_b[1]:
                n_c_choice = st.selectbox(
                    "Control total",
                    optional_options,
                    index=option_index(optional_options, column_choice_value(optional_options, binary_defaults.get("n_c", ""))),
                    key=f"binary_n_c_column_{preview_sheet}",
                )
            with endpoint_cols_b[2]:
                non_event_c_choice = st.selectbox(
                    "Control non-events",
                    optional_options,
                    index=option_index(optional_options, column_choice_value(optional_options, binary_defaults.get("non_event_c", ""))),
                    key=f"binary_non_event_c_column_{preview_sheet}",
                )
            with endpoint_cols_b[3]:
                label_pair = st.text_input(
                    "Arm labels",
                    value="treat, control",
                    key=f"binary_arm_labels_{preview_sheet}",
                    help="Optional plot labels as treatment, control.",
                )
            selected_endpoint_values = {
                "study_label": study_choice,
                "event_e": event_e_choice,
                "n_e": n_e_choice,
                "non_event_e": non_event_e_choice,
                "event_c": event_c_choice,
                "n_c": n_c_choice,
                "non_event_c": non_event_c_choice,
            }
            binary_endpoint_columns = {
                field: value
                for field, value in selected_endpoint_values.items()
                if value not in {"", "(auto)", "(none)"}
            }
            if label_pair.strip():
                labels = [part.strip() for part in label_pair.split(",", 1)]
                intervention_label_override = labels[0] if labels else ""
                control_label_override = labels[1] if len(labels) > 1 else ""
        else:
            st.caption("Binary endpoint column review is available for Binary pairwise and Auto route workbook runs.")

        st.subheader("Groups, Subgroups, and Meta-Regression")
        group_column = ""
        subgroup_columns: list[str] = []
        meta_regressor_columns: list[str] = []
        if multi_sheet_auto:
            st.info(
                "Multiple sheets are selected. Sheet-specific subgroup and meta-regression controls are hidden; "
                "Auto route will use per-sheet mapping decisions instead."
            )
        else:
            st.caption(
                "Suggested subgroup columns are shown for review, but subgroup analysis only runs when you select columns here."
            )
            if supports_subgroups and auto_subgroups:
                st.caption("Suggested subgroup columns: " + ", ".join(auto_subgroups))
            use_suggested_subgroups = False
            if supports_subgroups and auto_subgroups:
                use_suggested_subgroups = st.checkbox(
                    "Use suggested subgroup columns",
                    value=False,
                    help="Leave this off to prevent automatic subgroup analyses. You can still choose subgroup columns manually.",
                )
            group_col, subgroup_col, regressor_col = st.columns([0.9, 1.1, 1.1])
            with group_col:
                group_column_choice = st.selectbox(
                    "Primary group",
                    ["(none)", *available_columns],
                    index=0,
                    disabled=not supports_subgroups,
                    help="Optional main grouping column. It is also included in the subgroup column list for supported analyses.",
                )
                group_column = "" if group_column_choice == "(none)" else group_column_choice
            subgroup_defaults = auto_subgroups if supports_subgroups and use_suggested_subgroups else []
            with subgroup_col:
                subgroup_columns = st.multiselect(
                    "Subgroup columns",
                    available_columns,
                    default=unique_existing(subgroup_defaults, available_columns),
                    disabled=not supports_subgroups,
                    help="Only selected columns are used for subgroup analyses. Empty means no subgroup analysis.",
                )
            if group_column and group_column not in subgroup_columns:
                subgroup_columns = [group_column, *subgroup_columns]
            with regressor_col:
                meta_regressor_columns = st.multiselect(
                    "Meta-regressors",
                    available_columns,
                    default=unique_existing(auto_covariates, available_columns),
                    disabled=not supports_meta_regression,
                    help="Study-level moderator columns for meta-regression. Supported for binary and continuous pairwise analyses.",
                )
        if not supports_meta_regression and not multi_sheet_auto:
            meta_regressor_columns = []
            st.info("Meta-regression column overrides are used by auto, binary pairwise, and continuous pairwise routes.")

    render_run_summary(provider=provider, status=status, rscript=rscript, selected_sheets=selected_sheets, route=route)

    with preview_tab:
        meta = overview[preview_sheet]
        if selected_sheets:
            st.subheader("Analysis By Sheet")
            st.caption(
                f"Route source: {display_route_source}. "
                "Auto route uses the per-sheet analysis below; specialized routes run the first selected sheet."
            )
            st.dataframe(
                analysis_by_sheet_table(overview, selected_sheets, display_sheet_routes, route),
                use_container_width=True,
                hide_index=True,
                height=min(320, 38 * max(2, len(selected_sheets)) + 38),
            )
        st.subheader(preview_sheet)
        col_a, col_b, col_c = st.columns(3)
        col_a.metric("Rows", meta["rows"])
        col_b.metric("Columns", len(meta["columns"]))
        col_c.metric("Selected sheets", len(selected_sheets))
        preview_display = display_preview(meta["preview"])
        if preview_display.empty:
            st.info("The selected preview sheet has no rows to display.")
        else:
            st.dataframe(preview_display, use_container_width=True, height=360)

    output_root = Path(output_root_text).expanduser().resolve()
    command = build_command(
        input_path=input_path,
        output_root=output_root,
        route=route,
        selected_sheets=selected_sheets,
        analyze_all_sheets=analyze_all_sheets and route == "Auto route workbook",
        outcome_name=outcome_name,
        group_column=group_column,
        subgroup_columns=subgroup_columns,
        meta_regressor_columns=meta_regressor_columns,
        binary_endpoint_columns=binary_endpoint_columns,
        intervention_label=intervention_label_override,
        control_label=control_label_override,
        lmstudio_enabled=bool(use_llm),
        lmstudio_url=llm_base_url,
        model_id=model_id,
        binary_effect_size=binary_effect_size,
        network_engine=network_engine,
        network_effect=network_effect,
        network_model=network_model,
        single_arm_type=single_arm_type,
        diagnostic_mode=diagnostic_mode,
        jobs=int(jobs),
        dry_run=dry_run,
        install_r_packages=install_r_packages,
    )

    with command_tab:
        st.subheader("Generated Command")
        st.code(format_command(command), language="bash")
        st.caption(f"Outputs will be written under {output_root}")
        if selected_sheets:
            st.subheader("Analysis By Sheet")
            st.dataframe(
                analysis_by_sheet_table(overview, selected_sheets, display_sheet_routes, route),
                use_container_width=True,
                hide_index=True,
                height=min(320, 38 * max(2, len(selected_sheets)) + 38),
            )

    run_disabled = not selected_sheets or not rscript or not r_supported
    job_running = process_running(st.session_state.get("analysis_job"))
    render_run_plan_card(
        selected_sheets=selected_sheets,
        route=route,
        jobs=int(jobs),
        use_llm=bool(use_llm),
        output_root=output_root,
    )
    run_col, stop_col = st.columns([0.5, 0.5], vertical_alignment="center")
    with run_col:
        run_clicked = st.button("Run Analysis", type="primary", disabled=run_disabled or job_running, use_container_width=True)
    with stop_col:
        stop_clicked = False
        if job_running:
            stop_clicked = st.button("Stop Running Script", type="primary", use_container_width=True)
        else:
            st.button("Stop Running Script", disabled=True, use_container_width=True)
    if stop_clicked:
        job = st.session_state.get("analysis_job")
        stop_background_job(job)
        poll_background_job(job)
        st.rerun()
    if run_clicked:
        output_root.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        env["PATH"] = path_with_rscript(env.get("PATH", ""), rscript)
        if header_row_overrides:
            env["META_ANALYSIS_EXCEL_HEADER_ROWS"] = header_overrides_payload(header_row_overrides)
        if use_llm:
            env["LMSTUDIO_URL"] = llm_base_url
            env["META_ANALYSIS_LLM_PROVIDER"] = provider
            if model_id:
                env["LMSTUDIO_MODEL"] = model_id
                env["META_ANALYSIS_LLM_MODEL"] = model_id
            if llm_api_key:
                env["META_ANALYSIS_LLM_API_KEY"] = llm_api_key
                env["META_ANALYSIS_LLM_AUTH_HEADER"] = auth_header
                env["META_ANALYSIS_LLM_AUTH_PREFIX"] = auth_prefix
        st.session_state.analysis_job = start_background_job(command, env, output_root)
        st.rerun()
    render_job_controls(
        output_root,
        use_llm=bool(use_llm),
        llm_base_url=llm_base_url,
        model_id=model_id,
        llm_api_key=llm_api_key,
        auth_header=auth_header,
        auth_prefix=auth_prefix,
    )


if __name__ == "__main__":
    main()
