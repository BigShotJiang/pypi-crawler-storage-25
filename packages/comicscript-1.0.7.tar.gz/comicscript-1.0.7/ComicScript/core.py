﻿import sys
import random
import linecache
import traceback
import pyperclip  # Recuerda: pip install pyperclip
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

console = Console()

class ComicHookProxy:
    def __init__(self):
        self.shell_hook = sys.__excepthook__
        self.roasts = {
            'NameError': [
                "Whoops! '{0}'? I haven't heard that name since the Big Bang.",
                "Are you inventing a new language? Because '{0}' is definitely not in Python.",
                "Variable '{0}' not found. Maybe it's hiding in a different dimension?",
                "I searched everywhere for '{0}', even in your browser history. Found nothing.",
                "'{0}' is missing. Did it run away because of your bad coding?"
            ],
            'SyntaxError': [
                "Syntax Error at '{0}'? My keyboard codes cleaner than this.",
                "You call '{0}' code? It looks like a cat walked over the keyboard.",
                "Check '{0}' again. Even a compiler has feelings, you know?",
                "Syntax Error: Your code is so messy it's basically a modern art piece.",
                "Is this Python or a random soup of characters at '{0}'?",
                "Your code has successfully crashed with '{0}'"
            ],
            'TypeError': [
                "'{0}'? You're trying to mix things that don't belong together.",
                "Invalid type '{0}'! Even an AI has higher standards than this.",
                "TypeError '{0}': Your code is trying to be something it's not. Just be yourself.",
                "You can't do that with '{0}'. It's like trying to fry an egg with a flashlight.",
                "Trying to force '{0}'? Consent matters, even in data types."
            ],
            'IndexError': [
                "Index '{0}' is out of bounds! You're reaching for things that don't exist.",
                "Index '{0}' out of range. You've gone too far, come back to reality!",
                "Error at index '{0}': Try staying inside the lines for once.",
                "There is nothing at index '{0}'. Just like there's nothing in my 'patience' variable."
            ],
            'ZeroDivisionError': [
                "Dividing '{0}'? Do you want to create a black hole in the server room?",
                "Math '{0}' is hard, I know. But that's literally impossible.",
                "Zero division '{0}' detected. Somewhere, a math teacher is crying.",
                "Dividing by zero is the adult version of 'the floor is lava'. Don't do it."
            ],
            'AttributeError': [
                "'{0}'? Asking for that is like asking a fish to fly a plane.",
                "Attribute Error: Stop trying to make '{0}' happen. It's not going to happen.",
                "'{0}' is not here. Maybe it went to look for a better programmer."
            ],
            'KeyError': [
                "Key '{0}' isn't in the dictionary. It's like looking for keys already in your hand.",
                "KeyError '{0}': Access denied. The dictionary says NO.",
                "You are looking for '{0}', but the dictionary is as empty as your promises."
            ],
            'UnicodeError': [
                "Unicode Error: Writing in hieroglyphics again? Use UTF-8 or stop using emojis!",
                "Does '{0}' look like ASCII to you? Python doesn't speak 'Alien'.",
                "Your encoding is so bad that even a Rosetta Stone couldn't translate '{0}'.",
                "UnicodeError: You tried to use a special character and now everything is on fire."
            ],
            'OverflowError': [
                "OverflowError: That number is bigger than the national debt. Chill out, Elon!",
                "Calculating the atoms in the universe? The CPU says it won't fit.",
                "Your number is so large it just lapped the universe and came back as a bug."
            ],
            'NotImplementedError': [
                "NotImplementedError: Ah, the programmer got lazy. Finish your code, slacker!",
                "Throwing errors for functions that don't exist? Peak 'optimization'.",
                "This feature is coming soon... just like your retirement."
            ],
            'RecursionError': [
                "Recursion depth exceeded. You're stuck in a loop of your own failure.",
                "Infinite loop? Do you want to melt the CPU or what?",
                "Mirror, mirror on the wall... your code is crashing after all."
            ],
            'IndentationError': [
                "One space to rule them all, and in the darkness bind them.",
                "Is it a tab? Is it a space? No, it's just you failing at basic alignment.",
                "Your code's indentation is as messy as my room. Fix it.",
                "Python is not a freestyle poem. Align your code or go back to Notepad."
            ],
            'ImportError': [
                "Import Error: You're trying to bring in '{0}', but it doesn't want to be seen with you.",
                "Failed to import '{0}'. Maybe it's ghosting you?",
                "Importing '{0}' failed. Have you tried installing it first? Just a thought."
            ],
            'ValueError': [
                "Value Error: '{0}'? That value is more wrong than pineapple on pizza.",
                "I expected something useful, but you gave me '{0}'. Thanks for nothing.",
                "ValueError: That's not how this works. That's not how ANY of this works."
            ],
            'MemoryError': [
                "Memory Error: You've eaten all the RAM! Go buy a new PC or code better.",
                "Out of memory. My brain hurts just looking at your loops.",
                "MemoryError: You're treating my RAM like a free buffet. Stop it."
            ],
            'AssertionError': [
                "Assertion Failed: You claimed something was true, but the code caught your lie.",
                "Assert Error: You were so confident, yet so wrong.",
                "Your logic failed the test. Don't be so assertive next time."
            ],
            'FileNotFoundError': [
                "I can't find '{0}'. Did it vanish into thin air or are you just hallucinating?",
                "File '{0}' not found. It's probably hiding with your lost socks.",
                "Searching for '{0}'... 404: File has left the building."
            ],
            'PermissionError': [
                "Access denied for '{0}'. You don't have the permissions for this.",
                "Permission Error: Stop touching things that aren't yours, '{0}'!",
                "You tried to open '{0}'? Nice try, but the system says 'No'."
            ],
            'KeyboardInterrupt': [
                "Rage quit? Finishing with Ctrl+C is the ultimate white flag.",
                "KeyboardInterrupt: Leaving so soon? I was just starting to enjoy your bugs.",
                "Program stopped by user. Coward."
            ]
        }

    def __call__(self, type, value, tb):
        error_name = type.__name__
        if error_name == 'ModuleNotFoundError':
            actual_hook = sys.excepthook
            if actual_hook != self:
                return actual_hook(type, value, tb)
        self.mostrar_panel(type, value, tb)

    def mostrar_panel(self, type, value, tb):
        error_name = type.__name__
        try:
            traceback_details = traceback.extract_tb(tb)[-1]
            archivo_completo = traceback_details.filename
            nombre_archivo = archivo_completo.split('\\')[-1]
            num_linea = traceback_details.lineno
            contenido_linea = linecache.getline(archivo_completo, num_linea).strip()
        except:
            nombre_archivo, num_linea, contenido_linea = "Unknown", 0, "???"

        try:
            error_puro = f"{error_name}: {value}"
            pyperclip.copy(error_puro)
            msg_clipboard = "\n\n📋 Copied to Clipboard (for your lazy search)"
        except:
            msg_clipboard = ""

        if error_name in self.roasts:
            msg_roast = random.choice(self.roasts[error_name]).format(value)
            
            error_text = Text()
            error_text.append(f">>> {msg_roast}\n", style="bold yellow")
            error_text.append(f"\n📍 File: ", style="cyan")
            error_text.append(f"'{nombre_archivo}'", style="bold white")
            error_text.append(f"\n📟 Line {num_linea}: ", style="magenta")
            error_text.append(f"{contenido_linea}", style="italic green")
            
            if msg_clipboard:
                error_text.append(msg_clipboard, style="italic grey50")

            panel = Panel(
                error_text,
                title="[bold red]🔥 COMIC-SCRIPT ERROR 🔥[/bold red]",
                border_style="red",
                expand=False,
                padding=(1, 2)
            )
            
            console.print("\n", panel, "\n")
        else:
            console.print(f"\n[italic]🙄 Even I don't know what you did with '{value}'. Here's the boring stuff:[/italic]")
            self.shell_hook(type, value, tb)

def setup_comic_errors():
    proxy = ComicHookProxy()
    sys.excepthook = proxy

setup_comic_errors()