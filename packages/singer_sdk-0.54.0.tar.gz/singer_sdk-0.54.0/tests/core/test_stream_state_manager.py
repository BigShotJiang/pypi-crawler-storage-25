"""Tests for StreamStateManager class."""

from __future__ import annotations

import typing as t

import pytest

from singer_sdk.exceptions import InvalidStreamSortException
from singer_sdk.singerlib.catalog import REPLICATION_FULL_TABLE, REPLICATION_INCREMENTAL
from singer_sdk.streams._state import StreamStateManager

if t.TYPE_CHECKING:
    from singer_sdk.helpers import types


@pytest.fixture
def tap_state() -> types.TapState:
    """Return an empty tap state dict."""
    return {}


@pytest.fixture
def state_manager(tap_state: types.TapState) -> StreamStateManager:
    """Return a StreamStateManager instance."""
    return StreamStateManager(stream_name="test_stream", tap_state=tap_state)


# Tests for StreamStateManager initialization


def test_init_sets_attributes(tap_state: types.TapState) -> None:
    """Test that init sets all attributes correctly."""
    manager = StreamStateManager(
        stream_name="my_stream",
        tap_state=tap_state,
        state_partitioning_keys=["tenant_id"],
    )
    assert manager.stream_name == "my_stream"
    assert manager.tap_state is tap_state
    assert manager.state_partitioning_keys == ["tenant_id"]
    assert manager.is_flushed is True


def test_init_default_partitioning_keys(tap_state: types.TapState) -> None:
    """Test that state_partitioning_keys defaults to None."""
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    assert manager.state_partitioning_keys is None


# Tests for stream_state property


def test_stream_state_creates_bookmark(
    state_manager: StreamStateManager,
    tap_state: types.TapState,
) -> None:
    """Test that accessing stream_state creates bookmark entry."""
    assert tap_state == {}
    _ = state_manager.stream_state
    assert tap_state == {"bookmarks": {"test_stream": {}}}


def test_stream_state_returns_existing(tap_state: types.TapState) -> None:
    """Test that stream_state returns existing bookmark."""
    tap_state["bookmarks"] = {"test_stream": {"replication_key_value": "2021-01-01"}}
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    state = manager.stream_state
    assert state == {"replication_key_value": "2021-01-01"}


# Tests for get_context_state method


def test_get_context_state_no_context_returns_stream_state(
    state_manager: StreamStateManager,
    tap_state: types.TapState,
) -> None:
    """Test that None context returns stream state."""
    state = state_manager.get_context_state(None)
    assert state == {}
    assert tap_state == {"bookmarks": {"test_stream": {}}}


def test_get_context_state_creates_partition(
    state_manager: StreamStateManager,
    tap_state: types.TapState,
) -> None:
    """Test that context creates partition state."""
    context = {"tenant_id": "abc123"}
    state = state_manager.get_context_state(context)
    assert state == {"context": {"tenant_id": "abc123"}}
    assert tap_state["bookmarks"]["test_stream"]["partitions"] == [
        {"context": {"tenant_id": "abc123"}}
    ]


def test_get_context_state_returns_existing_partition(
    tap_state: types.TapState,
) -> None:
    """Test that existing partition is returned."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "partitions": [
                {
                    "context": {"tenant_id": "abc123"},
                    "replication_key_value": "2021-01-01",
                }
            ]
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    context = {"tenant_id": "abc123"}
    state = manager.get_context_state(context)
    assert state["replication_key_value"] == "2021-01-01"


def test_get_context_state_with_state_partitioning_keys(
    tap_state: types.TapState,
) -> None:
    """Test that state partitioning keys are used to create partition state."""
    state_context = {"tenant_id": "abc123"}
    partition_context = {**state_context, "extra": "ignored"}
    tap_state["bookmarks"] = {
        "test_stream": {
            "partitions": [
                {
                    "context": state_context,
                    "replication_key_value": "2021-01-01",
                },
            ],
        },
    }
    manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        state_partitioning_keys=["tenant_id"],
    )

    state = manager.get_context_state(partition_context)
    assert state["context"] == state_context
    assert state["replication_key_value"] == "2021-01-01"


# Tests for get_state_partition_context method


def test_get_state_partition_context_none_returns_none(
    state_manager: StreamStateManager,
) -> None:
    """Test that None context returns None."""
    result = state_manager.get_state_partition_context(None)
    assert result is None


def test_get_state_partition_context_no_keys_returns_full_context(
    state_manager: StreamStateManager,
) -> None:
    """Test that full context is returned when no partitioning keys."""
    context = {"tenant_id": "abc", "date": "2021-01-01"}
    result = state_manager.get_state_partition_context(context)
    assert result == context


def test_get_state_partition_context_filters_by_keys(
    tap_state: types.TapState,
) -> None:
    """Test that context is filtered by partitioning keys."""
    manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        state_partitioning_keys=["tenant_id"],
    )
    context = {"tenant_id": "abc", "date": "2021-01-01", "extra": "ignored"}
    result = manager.get_state_partition_context(context)
    assert result == {"tenant_id": "abc"}


# Tests for is_flushed flag behavior


def test_is_flushed_initial_state(state_manager: StreamStateManager) -> None:
    """Test that is_flushed starts as True."""
    assert state_manager.is_flushed is True


def test_is_flushed_after_finalize_state(
    state_manager: StreamStateManager,
) -> None:
    """Test that finalize_state sets is_flushed to False."""
    state_manager.finalize_state({})
    assert state_manager.is_flushed is False


# Tests for increment_state method


def test_increment_state_updates_bookmark(tap_state: types.TapState) -> None:
    """Test that increment_state updates replication key value."""
    state_manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        is_sorted=True,
        check_sorted=False,
    )
    state_manager.increment_state(
        {"updated_at": "2021-05-17T20:41:16Z"},
        replication_key="updated_at",
    )
    stream_state = tap_state["bookmarks"]["test_stream"]
    assert stream_state["replication_key"] == "updated_at"
    assert stream_state["replication_key_value"] == "2021-05-17T20:41:16Z"


def test_increment_state_with_context(tap_state: types.TapState) -> None:
    """Test increment_state with partition context."""
    manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        is_sorted=True,
        check_sorted=False,
    )
    context = {"tenant_id": "abc123"}
    manager.increment_state(
        {"updated_at": "2021-05-17T20:41:16Z"},
        context=context,
        replication_key="updated_at",
    )
    partitions = tap_state["bookmarks"]["test_stream"]["partitions"]
    assert len(partitions) == 1
    assert partitions[0]["context"] == context
    assert partitions[0]["replication_key_value"] == "2021-05-17T20:41:16Z"


def test_increment_state_unsorted_creates_progress_markers(
    tap_state: types.TapState,
) -> None:
    """Test that unsorted streams create progress markers."""
    state_manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        is_sorted=False,
        check_sorted=False,
    )
    state_manager.increment_state(
        {"updated_at": "2021-05-17T20:41:16Z"},
        replication_key="updated_at",
    )
    stream_state = tap_state["bookmarks"]["test_stream"]
    assert "progress_markers" in stream_state
    assert stream_state["progress_markers"]["replication_key"] == "updated_at"


def test_increment_not_required(tap_state: types.TapState) -> None:
    """Test that increment_state does not compare when no old value."""
    state_manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        is_sorted=False,
    )
    state_manager.increment_state(
        {"updated_at": "2021-05-17T20:41:16Z"},
        replication_key="updated_at",
    )
    stream_state = tap_state["bookmarks"]["test_stream"]
    assert (
        stream_state["progress_markers"]["replication_key_value"]
        == "2021-05-17T20:41:16Z"
    )

    state_manager.increment_state(
        {"updated_at": "2021-05-05T20:41:16Z"},
        replication_key="updated_at",
    )
    stream_state = tap_state["bookmarks"]["test_stream"]
    assert (
        stream_state["progress_markers"]["replication_key_value"]
        == "2021-05-17T20:41:16Z"
    )


def test_increment_with_partitioning_keys(tap_state: types.TapState) -> None:
    """Test that partitioning keys make streams non-resumable."""
    state_manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        is_sorted=True,
        state_partitioning_keys=["tenant_id"],
    )
    state_manager.increment_state(
        {"updated_at": "2021-05-17T20:41:16Z"},
        replication_key="updated_at",
    )
    stream_state = tap_state["bookmarks"]["test_stream"]
    assert "progress_markers" in stream_state


def test_increment_invalid_sort(tap_state: types.TapState) -> None:
    """Test that increment_state does not compare when no old value."""
    state_manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        is_sorted=True,
    )
    state_manager.increment_state(
        {"updated_at": "2021-05-17T20:41:16Z"},
        replication_key="updated_at",
    )

    with pytest.raises(
        InvalidStreamSortException,
        match="Unsorted data detected in stream",
    ):
        state_manager.increment_state(
            {"updated_at": "2021-05-05T20:41:16Z"},
            replication_key="updated_at",
        )


# Tests for finalize_state method


def test_finalize_state_promotes_progress_markers(
    tap_state: types.TapState,
) -> None:
    """Test that finalize_state promotes progress markers."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "progress_markers": {
                "replication_key": "updated_at",
                "replication_key_value": "2021-05-17T20:41:16Z",
            }
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    state = manager.stream_state
    manager.finalize_state(state)

    assert "progress_markers" not in state
    assert state["replication_key"] == "updated_at"
    assert state["replication_key_value"] == "2021-05-17T20:41:16Z"


# Tests for finalize_progress_markers method


def test_finalize_progress_markers_no_state_uses_stream_state(
    state_manager: StreamStateManager,
    tap_state: types.TapState,
) -> None:
    """Test finalize_progress_markers with no state creates stream bookmark."""
    state_manager.finalize_progress_markers()
    assert "bookmarks" in tap_state
    assert "test_stream" in tap_state["bookmarks"]
    assert state_manager.is_flushed is False


def test_finalize_progress_markers_with_partitions(tap_state: types.TapState) -> None:
    """Test finalize_progress_markers with partitions."""
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    partitions = [{"tenant_id": "a"}, {"tenant_id": "b"}]
    manager.finalize_progress_markers(partitions=partitions)

    stream_state = tap_state["bookmarks"]["test_stream"]
    assert "partitions" in stream_state
    assert len(stream_state["partitions"]) == 2


def test_finalize_progress_markers_with_explicit_state(
    state_manager: StreamStateManager,
) -> None:
    """Test finalize_progress_markers with explicit state."""
    state = {
        "progress_markers": {
            "replication_key": "updated_at",
            "replication_key_value": "2021-05-17T20:41:16Z",
        }
    }

    state_manager.finalize_progress_markers(state=state)
    assert state == {
        "replication_key": "updated_at",
        "replication_key_value": "2021-05-17T20:41:16Z",
    }


def test_finalize_progress_markers_beyond_signpost() -> None:
    """Test finalize_progress_markers with replication key value beyond signpost."""
    signpost_value = "2021-05-17T00:00:00Z"
    replication_key_value = "2021-05-17T20:41:16Z"

    tap_state: types.TapState = {}
    manager = StreamStateManager(
        stream_name="test_stream",
        tap_state=tap_state,
        is_sorted=False,
        check_sorted=False,
    )
    manager.increment_state(
        latest_record={"updated_at": replication_key_value},
        replication_key="updated_at",
    )
    manager.write_replication_key_signpost(signpost_value)
    manager.finalize_progress_markers()
    assert tap_state == {
        "bookmarks": {
            "test_stream": {
                "replication_key": "updated_at",
                "replication_key_value": signpost_value,
            }
        }
    }


# Tests for get_state_partitions method


def test_get_state_partitions_no_partitions_returns_none(
    state_manager: StreamStateManager,
) -> None:
    """Test that None is returned when no partitions exist."""
    result = state_manager.get_state_partitions()
    assert result is None


def test_get_state_partitions_returns_existing(tap_state: types.TapState) -> None:
    """Test that existing partitions are returned."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "partitions": [
                {"context": {"tenant_id": "a"}},
                {"context": {"tenant_id": "b"}},
            ]
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    partitions = manager.get_state_partitions()
    assert partitions is not None
    assert len(partitions) == 2


# Tests for get_starting_replication_value method


def test_get_starting_replication_value_full_table_returns_none(
    tap_state: types.TapState,
) -> None:
    """Test that FULL_TABLE replication returns None."""
    tap_state["bookmarks"] = {"test_stream": {"replication_key_value": "2021-01-01"}}
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    result = manager.get_starting_replication_value(None, REPLICATION_FULL_TABLE)
    assert result is None


def test_get_starting_replication_value_incremental_returns_value(
    tap_state: types.TapState,
) -> None:
    """Test that INCREMENTAL replication returns bookmark value."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "replication_key": "updated_at",
            "starting_replication_value": "2021-05-17T20:41:16Z",
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    result = manager.get_starting_replication_value(None, REPLICATION_INCREMENTAL)
    assert result == "2021-05-17T20:41:16Z"


def test_get_starting_replication_value_no_state_returns_none(
    state_manager: StreamStateManager,
) -> None:
    """Test that no prior state returns None."""
    result = state_manager.get_starting_replication_value(
        None,
        REPLICATION_INCREMENTAL,
    )
    assert result is None


def test_get_starting_replication_value_multiple_partitions(
    tap_state: types.TapState,
) -> None:
    """Test retrieving starting replication value for multiple partitions."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "partitions": [
                {
                    "context": {"tenant_id": "a"},
                    "starting_replication_value": "2021-05-17T20:41:16Z",
                },
                {
                    "context": {"tenant_id": "b"},
                    "starting_replication_value": "2021-05-18T10:30:00Z",
                },
            ]
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)

    result = manager.get_starting_replication_value(
        {"tenant_id": "a"},
        REPLICATION_INCREMENTAL,
    )
    assert result == "2021-05-17T20:41:16Z"

    result = manager.get_starting_replication_value(
        {"tenant_id": "b"},
        REPLICATION_INCREMENTAL,
    )
    assert result == "2021-05-18T10:30:00Z"

    result = manager.get_starting_replication_value(
        {"tenant_id": "c"},
        REPLICATION_INCREMENTAL,
    )
    assert result is None


# Tests for is_state_non_resumable method


def test_is_state_non_resumable_no_progress_markers(
    state_manager: StreamStateManager,
) -> None:
    """Test that state without progress markers is resumable."""
    assert state_manager.is_state_non_resumable() is False


def test_is_state_non_resumable_with_progress_markers(
    tap_state: types.TapState,
) -> None:
    """Test that state with progress markers is non-resumable."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "progress_markers": {
                "replication_key": "updated_at",
                "replication_key_value": "2021-05-17T20:41:16Z",
            }
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    assert manager.is_state_non_resumable() is True


# Tests for write_starting_replication_value method


def test_write_starting_replication_value_full_table_does_nothing(
    state_manager: StreamStateManager,
    tap_state: types.TapState,
) -> None:
    """Test that FULL_TABLE replication does not write starting value."""
    state_manager.write_starting_replication_value(
        context=None,
        replication_method=REPLICATION_FULL_TABLE,
        replication_key="updated_at",
        config={},
    )
    # Stream state should exist but be empty (no starting_replication_value)
    assert tap_state == {}


def test_write_starting_replication_value_incremental_writes_value(
    tap_state: types.TapState,
) -> None:
    """Test that INCREMENTAL replication writes starting value from state."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "replication_key": "updated_at",
            "replication_key_value": "2021-05-17T20:41:16Z",
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    manager.write_starting_replication_value(
        context=None,
        replication_method=REPLICATION_INCREMENTAL,
        replication_key="updated_at",
        config={},
    )
    state = manager.stream_state
    assert state["starting_replication_value"] == "2021-05-17T20:41:16Z"


def test_write_starting_replication_value_uses_start_date_when_no_state(
    state_manager: StreamStateManager,
) -> None:
    """Test that start_date from config is used when no prior state."""
    state_manager.write_starting_replication_value(
        context=None,
        replication_method=REPLICATION_INCREMENTAL,
        replication_key="updated_at",
        config={"start_date": "2020-01-01"},
    )
    state = state_manager.stream_state
    assert state["starting_replication_value"] == "2020-01-01"


def test_write_starting_replication_value_compare_fn_used(
    tap_state: types.TapState,
) -> None:
    """Test that compare_start_date_fn is called to compare values."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "replication_key": "updated_at",
            "replication_key_value": "2021-05-17",
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)

    # This function always returns the second argument
    def compare_fn(a: str, b: str) -> str:  # noqa: ARG001
        return b

    manager.write_starting_replication_value(
        context=None,
        replication_method=REPLICATION_INCREMENTAL,
        replication_key="updated_at",
        config={"start_date": "2020-01-01"},
        compare_start_date_fn=compare_fn,
    )
    state = manager.stream_state
    # compare_fn returns second arg (start_date)
    assert state["starting_replication_value"] == "2020-01-01"


def test_write_starting_replication_value_no_compare_fn(
    tap_state: types.TapState,
) -> None:
    """Test that compare_start_date_fn is not called if no function is provided."""
    tap_state["bookmarks"] = {
        "test_stream": {
            "replication_key": "updated_at",
            "replication_key_value": "2021-05-17",
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)

    manager.write_starting_replication_value(
        context=None,
        replication_method=REPLICATION_INCREMENTAL,
        replication_key="updated_at",
        config={"start_date": "2020-01-01"},
        compare_start_date_fn=None,
    )
    state = manager.stream_state
    assert state["starting_replication_value"] == "2021-05-17"


def test_write_starting_replication_value_no_replication_key_does_nothing(
    state_manager: StreamStateManager,
) -> None:
    """Test that no replication key does not write starting value."""
    state_manager.write_starting_replication_value(
        context=None,
        replication_method=REPLICATION_INCREMENTAL,
        replication_key=None,
        config={},
    )
    assert state_manager.stream_state == {"starting_replication_value": None}


def test_write_starting_replication_value_replication_key_changed() -> None:
    """Test that replication key changed does not write a starting value."""
    tap_state: types.TapState = {
        "bookmarks": {
            "test_stream": {
                "replication_key": "old_replication_key",
                "replication_key_value": "2021-05-17T20:41:16Z",
            }
        }
    }
    manager = StreamStateManager(stream_name="test_stream", tap_state=tap_state)
    manager.write_starting_replication_value(
        context=None,
        replication_method=REPLICATION_INCREMENTAL,
        replication_key="new_replication_key",
        config={},
    )
    value = manager.get_starting_replication_value(None, REPLICATION_INCREMENTAL)
    assert value is None


# Tests for write_replication_key_signpost method


def test_write_replication_key_signpost_writes_value(
    state_manager: StreamStateManager,
    tap_state: types.TapState,
) -> None:
    """Test that signpost value is written to state."""
    state_manager.write_replication_key_signpost("2021-05-17T20:41:16Z")
    state = tap_state["bookmarks"]["test_stream"]
    assert state["replication_key_signpost"] == "2021-05-17T20:41:16Z"


def test_write_replication_key_signpost_empty_does_nothing(
    state_manager: StreamStateManager,
    tap_state: dict,
) -> None:
    """Test that empty value does not write signpost."""
    state_manager.write_replication_key_signpost("")
    assert not tap_state


def test_write_replication_key_signpost_none_does_nothing(
    state_manager: StreamStateManager,
    tap_state: dict,
) -> None:
    """Test that None value does not write signpost."""
    state_manager.write_replication_key_signpost(None)
    assert not tap_state


# Tests for log_sort_error method


def test_log_sort_error_logs_message(
    state_manager: StreamStateManager,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Test that sort error is logged."""
    ex = Exception("Sort order violated")
    state_manager.log_sort_error(
        ex=ex,
        current_context=None,
        record_count=10,
        partition_record_count=10,
    )
    assert len(caplog.records) == 1
    assert "Sorting error" in caplog.records[0].message
    assert "test_stream" in caplog.records[0].message
    assert "record #10" in caplog.records[0].message


def test_log_sort_error_includes_partition_info_when_different(
    state_manager: StreamStateManager,
    caplog: pytest.LogCaptureFixture,
) -> None:
    """Test that partition record count is included when different."""
    ex = Exception("Sort order violated")
    state_manager.log_sort_error(
        ex=ex,
        current_context={"tenant_id": "abc"},
        record_count=100,
        partition_record_count=5,
    )
    assert "partition record #5" in caplog.records[0].message
    assert "tenant_id" in caplog.records[0].message
