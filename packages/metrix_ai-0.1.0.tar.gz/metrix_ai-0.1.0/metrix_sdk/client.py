"""
💾 Code:
 * Name: Ahmad Sharique
 * Email: eshariq.am@gmail.com
 * Description: MetrixClient — main SDK client for metrix.ai Python SDK
"""

import time
import httpx
from typing import Any, Dict, List, Optional

from .exceptions import (
    MetrixAuthError, MetrixConfigError, MetrixConnectionError,
    ProviderAuthError, ProviderRateLimitError, ProviderTimeoutError,
    ProviderError, MetrixRoutingError, UnsupportedProviderError,
)
from .types import ChatMessage, ChatResponse
from .utils import (
    load_env_config, serialize_tags,
    debug_log, debug_request, debug_response, Colors,
)

SUPPORTED_PROVIDERS = ("anthropic", "openai", "gemini")
DEFAULT_BASE_URL = "http://localhost:8000"


class MetrixClient:
    """
    metrix.ai Python SDK client.

    Wraps LLM provider calls through the metrix.ai proxy,
    enabling token tracking, cost logging, smart routing,
    and project attribution — with zero changes to your workflow.

    Usage:
        client = MetrixClient(
            api_key="your-metrix-token",
            provider_api_key="your-anthropic-key",
            project="my-project",
            auto_route=True,
            debug=True,
        )
        response = client.chat(
            provider="anthropic",
            model="claude-sonnet-4-6",
            messages=[{"role": "user", "content": "Hello"}],
        )
        print(response["content"])
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        provider_api_key: Optional[str] = None,
        project: Optional[str] = None,
        auto_route: bool = False,
        tags: Optional[Dict[str, str]] = None,
        timeout: int = 60,
        max_retries: int = 2,
        debug: bool = False,
        base_url: Optional[str] = None,
    ):
        # Load from env vars first, then override with explicit args
        env = load_env_config()

        self.api_key = api_key or env.get("api_key")
        self.provider_api_key = provider_api_key or env.get("provider_api_key")
        self.project = project or env.get("project")
        self.auto_route = auto_route or env.get("auto_route", False)
        self.tags = tags
        self.timeout = timeout
        self.max_retries = max_retries
        self.debug = debug or env.get("debug", False)
        self.base_url = (base_url or env.get("base_url") or DEFAULT_BASE_URL).rstrip("/")

        # Validate required fields
        if not self.api_key:
            raise MetrixConfigError(
                "api_key is required. Pass it directly or set METRIX_API_KEY env var."
            )
        if not self.provider_api_key:
            raise MetrixConfigError(
                "provider_api_key is required. Pass it directly or set METRIX_PROVIDER_API_KEY env var."
            )

        if self.debug:
            debug_log(f"MetrixClient initialized — base_url: {self.base_url}", Colors.CYAN)
            debug_log(f"project: {self.project or 'none'} | auto_route: {self.auto_route}", Colors.GRAY)

    def _build_headers(self, provider: str, project: Optional[str], tags: Optional[Dict[str, str]], auto_route: bool) -> Dict[str, str]:
        """Build all required HTTP headers for the metrix.ai proxy."""
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "x-provider-api-key": self.provider_api_key,
        }

        effective_project = project or self.project
        if effective_project:
            headers["x-metrix-project"] = effective_project

        effective_tags = tags or self.tags
        serialized = serialize_tags(effective_tags)
        if serialized:
            headers["x-metrix-tags"] = serialized

        if auto_route or self.auto_route:
            headers["x-metrix-auto-route"] = "true"

        return headers

    def _extract_content(self, provider: str, raw: Dict[str, Any]) -> str:
        """Extract text content from provider response."""
        try:
            if provider == "anthropic":
                return raw["content"][0]["text"]
            elif provider == "openai":
                return raw["choices"][0]["message"]["content"]
            elif provider == "gemini":
                return raw["candidates"][0]["content"]["parts"][0]["text"]
        except (KeyError, IndexError):
            pass
        return ""

    def _extract_tokens(self, provider: str, raw: Dict[str, Any]) -> tuple[int, int]:
        """Extract input and output token counts from provider response."""
        try:
            if provider == "anthropic":
                usage = raw.get("usage", {})
                return usage.get("input_tokens", 0), usage.get("output_tokens", 0)
            elif provider == "openai":
                usage = raw.get("usage", {})
                return usage.get("prompt_tokens", 0), usage.get("completion_tokens", 0)
            elif provider == "gemini":
                meta = raw.get("usageMetadata", {})
                return meta.get("promptTokenCount", 0), meta.get("candidatesTokenCount", 0)
        except Exception:
            pass
        return 0, 0

    def _extract_routing(self, raw: Dict[str, Any]) -> tuple[bool, Optional[str]]:
        """Extract routing metadata from metrix response envelope."""
        routing = raw.get("_metrix_routing", {})
        return routing.get("routed", False), routing.get("original_model")

    def chat(
        self,
        provider: str,
        model: str,
        messages: List[ChatMessage],
        project: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        auto_route: Optional[bool] = None,
        max_tokens: int = 1024,
        temperature: float = 0.7,
        system: Optional[str] = None,
    ) -> ChatResponse:
        """
        Send a chat completion request through the metrix.ai proxy.

        Args:
            provider:    LLM provider — "anthropic", "openai", or "gemini"
            model:       Model name e.g. "claude-sonnet-4-6", "gpt-4o"
            messages:    List of ChatMessage dicts with role and content
            project:     Optional project slug for attribution
            tags:        Optional tags dict e.g. {"env": "prod"}
            auto_route:  Override auto_route for this call only
            max_tokens:  Maximum tokens in response
            temperature: Sampling temperature
            system:      Optional system prompt (Anthropic style)

        Returns:
            ChatResponse with content, tokens, cost, latency, routing info

        Raises:
            UnsupportedProviderError: If provider is not supported
            MetrixAuthError: If metrix token is invalid
            ProviderAuthError: If provider API key is invalid
            ProviderRateLimitError: If provider rate limits you
            ProviderTimeoutError: If request times out
            MetrixConnectionError: If proxy is unreachable
        """
        if provider not in SUPPORTED_PROVIDERS:
            raise UnsupportedProviderError(provider)

        url = f"{self.base_url}/api/v1/proxy/{provider}"
        effective_auto_route = auto_route if auto_route is not None else self.auto_route
        headers = self._build_headers(provider, project, tags, effective_auto_route)

        # Build provider-specific payload
        if provider == "anthropic":
            payload: Dict[str, Any] = {
                "model": model,
                "max_tokens": max_tokens,
                "messages": messages,
            }
            if system:
                payload["system"] = system
        elif provider == "openai":
            all_messages = []
            if system:
                all_messages.append({"role": "system", "content": system})
            all_messages.extend(messages)
            payload = {
                "model": model,
                "messages": all_messages,
                "max_tokens": max_tokens,
                "temperature": temperature,
            }
        elif provider == "gemini":
            payload = {
                "model": model,
                "contents": [{"parts": [{"text": m["content"]}], "role": m["role"]} for m in messages],
            }

        if self.debug:
            debug_request(
                provider=provider,
                model=model,
                url=url,
                auto_route=effective_auto_route,
                project=project or self.project,
                tags=tags or self.tags,
            )

        # Retry logic with exponential backoff
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                start = time.time()
                with httpx.Client(timeout=self.timeout) as client:
                    resp = client.post(url, json=payload, headers=headers)
                latency_ms = int((time.time() - start) * 1000)

                if resp.status_code == 401:
                    raise MetrixAuthError("Invalid or expired metrix.ai token.", status_code=401)
                if resp.status_code == 403:
                    raise ProviderAuthError("Provider API key is invalid or unauthorized.", status_code=403)
                if resp.status_code == 429:
                    raise ProviderRateLimitError("Provider rate limit exceeded. Try again later.", status_code=429)
                if resp.status_code >= 500:
                    raise ProviderError(f"Provider returned server error {resp.status_code}.", status_code=resp.status_code)

                resp.raise_for_status()
                raw = resp.json()

                content = self._extract_content(provider, raw)
                input_tokens, output_tokens = self._extract_tokens(provider, raw)
                total_tokens = input_tokens + output_tokens
                routed, original_model = self._extract_routing(raw)

                # Rough cost estimate client-side
                cost_usd = 0.0

                if self.debug:
                    debug_response(
                        model=raw.get("model", model),
                        total_tokens=total_tokens,
                        cost_usd=cost_usd,
                        latency_ms=latency_ms,
                        routed=routed,
                        original_model=original_model,
                    )

                return ChatResponse(
                    provider=provider,
                    model=raw.get("model", model),
                    content=content,
                    input_tokens=input_tokens,
                    output_tokens=output_tokens,
                    total_tokens=total_tokens,
                    latency_ms=latency_ms,
                    cost_usd=cost_usd,
                    routed=routed,
                    original_model=original_model,
                    raw=raw,
                )

            except httpx.TimeoutException:
                last_error = ProviderTimeoutError(
                    f"Request timed out after {self.timeout}s (attempt {attempt + 1}/{self.max_retries + 1})"
                )
                if self.debug:
                    debug_log(f"Timeout on attempt {attempt + 1} — retrying...", Colors.YELLOW)
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)

            except httpx.ConnectError:
                last_error = MetrixConnectionError(
                    f"Cannot connect to metrix.ai proxy at {self.base_url}. Is the backend running?"
                )
                break

            except (MetrixAuthError, ProviderAuthError, ProviderRateLimitError, UnsupportedProviderError):
                raise

            except ProviderError:
                last_error = ProviderError(f"Provider error on attempt {attempt + 1}")
                if attempt < self.max_retries:
                    time.sleep(2 ** attempt)

        raise last_error