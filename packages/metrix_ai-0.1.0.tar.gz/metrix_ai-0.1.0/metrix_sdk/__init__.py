"""
💾 Code:
 * Name: Ahmad Sharique
 * Email: eshariq.am@gmail.com
 * Description: metrix.ai Python SDK — public exports
"""

from .client import MetrixClient
from .exceptions import (
    MetrixError,
    MetrixAuthError,
    MetrixConfigError,
    MetrixConnectionError,
    ProviderAuthError,
    ProviderRateLimitError,
    ProviderTimeoutError,
    ProviderError,
    MetrixRoutingError,
    UnsupportedProviderError,
)
from .types import ChatMessage, ChatResponse, MetrixConfig

__version__ = "0.1.0"
__all__ = [
    "MetrixClient",
    "MetrixError",
    "MetrixAuthError",
    "MetrixConfigError",
    "MetrixConnectionError",
    "ProviderAuthError",
    "ProviderRateLimitError",
    "ProviderTimeoutError",
    "ProviderError",
    "MetrixRoutingError",
    "UnsupportedProviderError",
    "ChatMessage",
    "ChatResponse",
    "MetrixConfig",
]