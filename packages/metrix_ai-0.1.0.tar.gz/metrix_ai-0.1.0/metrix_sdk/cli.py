"""
💾 Code:
 * Name: Ahmad Sharique
 * Email: eshariq.am@gmail.com
 * Description: metrix.ai CLI — beautiful terminal usage reports for Claude Code
"""

import os
import json
import glob
import click
from datetime import datetime, timedelta
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.columns import Columns
from rich import box
from rich.text import Text
from rich.progress import Progress, BarColumn, TextColumn
from rich.live import Live
from rich.layout import Layout
import time

console = Console()

# ─── Pricing ──────────────────────────────────────────────────────────────────

PRICING = {
    "claude-opus-4-6":          (5.00, 25.00),
    "claude-sonnet-4-6":        (3.00, 15.00),
    "claude-haiku-4-5-20251001":(0.80,  4.00),
    "claude-haiku-4-5":         (0.80,  4.00),
    "gpt-4o":                   (2.50, 10.00),
    "gpt-4o-mini":              (0.15,  0.60),
    "gemini-1.5-pro":           (1.25,  5.00),
    "gemini-1.5-flash":         (0.075, 0.30),
}

CHEAPER = {
    "claude-opus-4-6":   ("claude-haiku-4-5-20251001", 94),
    "claude-sonnet-4-6": ("claude-haiku-4-5-20251001", 73),
    "gpt-4o":            ("gpt-4o-mini", 94),
    "gpt-4-turbo":       ("gpt-4o-mini", 97),
    "gemini-1.5-pro":    ("gemini-1.5-flash", 94),
}

# ─── Data Loading ─────────────────────────────────────────────────────────────

def find_claude_dirs():
    """Find Claude Code JSONL data directories."""
    candidates = [
        Path.home() / ".config" / "claude" / "projects",
        Path.home() / ".claude" / "projects",
        Path("C:/Users") / os.getenv("USERNAME", "") / "AppData" / "Roaming" / "Claude" / "projects",
    ]
    env = os.getenv("CLAUDE_CONFIG_DIR")
    if env:
        candidates.insert(0, Path(env) / "projects")

    found = [p for p in candidates if p.exists()]
    return found


def load_jsonl_files(dirs):
    """Load all JSONL usage records from Claude Code directories."""
    records = []
    for d in dirs:
        for f in glob.glob(str(d / "**" / "*.jsonl"), recursive=True):
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    for line in fp:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            obj = json.loads(line)
                            if obj.get("type") == "assistant" and "usage" in obj.get("message", {}):
                                records.append(obj)
                        except json.JSONDecodeError:
                            continue
            except Exception:
                continue
    return records


def parse_records(records):
    """Parse raw JSONL records into clean usage entries."""
    entries = []
    for r in records:
        try:
            msg = r.get("message", {})
            usage = msg.get("usage", {})
            model = msg.get("model", "unknown")
            input_tokens = usage.get("input_tokens", 0)
            output_tokens = usage.get("output_tokens", 0)
            total = input_tokens + output_tokens

            # Estimate cost
            pricing = PRICING.get(model, (0.003, 0.015))
            cost = (input_tokens / 1_000_000 * pricing[0]) + (output_tokens / 1_000_000 * pricing[1])

            # Timestamp
            ts = r.get("timestamp", "")
            try:
                dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
            except Exception:
                dt = datetime.now()

            entries.append({
                "model": model,
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
                "total_tokens": total,
                "cost": cost,
                "dt": dt,
                "session_id": r.get("sessionId", "unknown"),
                "waste_ratio": input_tokens / max(total, 1),
            })
        except Exception:
            continue
    return entries


# ─── Analysis ─────────────────────────────────────────────────────────────────

def analyze(entries, days=1):
    """Aggregate entries into summary stats."""
    since = datetime.now().astimezone() - timedelta(days=days)
    filtered = [e for e in entries if e["dt"].astimezone() >= since]

    total_cost = sum(e["cost"] for e in filtered)
    total_tokens = sum(e["total_tokens"] for e in filtered)
    total_input = sum(e["input_tokens"] for e in filtered)
    total_output = sum(e["output_tokens"] for e in filtered)

    # By model
    by_model = {}
    for e in filtered:
        m = by_model.setdefault(e["model"], {"cost": 0, "tokens": 0, "requests": 0})
        m["cost"] += e["cost"]
        m["tokens"] += e["total_tokens"]
        m["requests"] += 1

    # Sessions
    sessions = {}
    for e in filtered:
        s = sessions.setdefault(e["session_id"], {"cost": 0, "tokens": 0, "model": e["model"]})
        s["cost"] += e["cost"]
        s["tokens"] += e["total_tokens"]

    # Waste detection
    high_waste = [e for e in filtered if e["waste_ratio"] > 0.85 and e["total_tokens"] > 500]
    waste_cost = sum(e["cost"] * 0.4 for e in high_waste)

    # Savings potential
    savings = 0
    for model, stats in by_model.items():
        alt = CHEAPER.get(model)
        if alt:
            savings += stats["cost"] * (alt[1] / 100)

    return {
        "entries": filtered,
        "total_cost": total_cost,
        "total_tokens": total_tokens,
        "total_input": total_input,
        "total_output": total_output,
        "by_model": by_model,
        "sessions": sessions,
        "high_waste": high_waste,
        "waste_cost": waste_cost,
        "savings": savings,
        "days": days,
    }


# ─── Rendering ────────────────────────────────────────────────────────────────

def render_header():
    console.print()
    console.print(Panel(
        Text("⚡ Metrix — Token Usage Intelligence", justify="center", style="bold white"),
        style="bold blue",
        border_style="blue",
    ))


def render_kpis(data):
    today_cost = data["total_cost"]
    total_tokens = data["total_tokens"]
    savings = data["savings"]
    sessions = len(data["sessions"])

    kpis = [
        Panel(f"[bold green]${today_cost:.4f}[/bold green]\n[dim]Today Spend[/dim]", border_style="green"),
        Panel(f"[bold blue]{total_tokens:,}[/bold blue]\n[dim]Total Tokens[/dim]", border_style="blue"),
        Panel(f"[bold yellow]${savings:.4f}[/bold yellow]\n[dim]Potential Savings[/dim]", border_style="yellow"),
        Panel(f"[bold magenta]{sessions}[/bold magenta]\n[dim]Sessions[/dim]", border_style="magenta"),
    ]
    console.print(Columns(kpis, equal=True))


def render_model_table(data):
    table = Table(
        title="📊 Model Breakdown",
        box=box.ROUNDED,
        border_style="blue",
        header_style="bold cyan",
        show_lines=True,
    )
    table.add_column("Model", style="cyan", no_wrap=True)
    table.add_column("Requests", justify="right")
    table.add_column("Tokens", justify="right")
    table.add_column("Cost", justify="right", style="green")
    table.add_column("$/1K tokens", justify="right")
    table.add_column("Savings Available", justify="center")

    by_model = sorted(data["by_model"].items(), key=lambda x: x[1]["cost"], reverse=True)
    total_cost = data["total_cost"]

    for model, stats in by_model:
        cost_per_1k = (stats["cost"] / max(stats["tokens"], 1)) * 1000
        alt = CHEAPER.get(model)
        savings_badge = f"[green]Save {alt[1]}% → {alt[0].split('-')[1]}[/green]" if alt else "[dim]Most efficient[/dim]"
        pct = (stats["cost"] / max(total_cost, 0.000001)) * 100

        table.add_row(
            model,
            str(stats["requests"]),
            f"{stats['tokens']:,}",
            f"${stats['cost']:.6f} ({pct:.0f}%)",
            f"${cost_per_1k:.5f}",
            savings_badge,
        )

    console.print(table)


def render_top_sessions(data):
    sessions = sorted(data["sessions"].items(), key=lambda x: x[1]["cost"], reverse=True)[:5]
    if not sessions:
        return

    table = Table(
        title="🔥 Top Sessions by Cost",
        box=box.ROUNDED,
        border_style="red",
        header_style="bold red",
    )
    table.add_column("Session ID", style="dim", no_wrap=True)
    table.add_column("Model", style="cyan")
    table.add_column("Tokens", justify="right")
    table.add_column("Cost", justify="right", style="red")

    for sid, stats in sessions:
        table.add_row(
            sid[:16] + "...",
            stats["model"],
            f"{stats['tokens']:,}",
            f"${stats['cost']:.6f}",
        )

    console.print(table)


def render_waste(data):
    if not data["high_waste"]:
        console.print(Panel("[green]✓ No significant prompt waste detected[/green]", border_style="green"))
        return

    console.print(Panel(
        f"[bold yellow]⚠ Prompt Waste Detected[/bold yellow]\n\n"
        f"[white]{len(data['high_waste'])} sessions had >85% input tokens with low output value[/white]\n"
        f"[dim]Estimated waste cost: [/dim][red]${data['waste_cost']:.6f}[/red]\n\n"
        f"[dim]Fix: Reduce repeated context, trim system prompts, use /compact in Claude Code[/dim]",
        border_style="yellow",
        title="Waste Analysis",
    ))


def render_recommendations(data):
    recs = []

    for model, stats in data["by_model"].items():
        alt = CHEAPER.get(model)
        if alt and stats["cost"] > 0.001:
            saving = stats["cost"] * (alt[1] / 100)
            recs.append(f"💡 Switch [cyan]{model}[/cyan] → [green]{alt[0]}[/green] — save [yellow]{alt[1]}%[/yellow] (~${saving:.4f})")

    if data["waste_cost"] > 0.001:
        recs.append(f"🔧 Reduce prompt bloat — estimated waste [red]${data['waste_cost']:.4f}[/red]")

    if not data["by_model"]:
        recs.append("📊 No usage data found — start using Claude Code to see insights")

    if not recs:
        recs.append("✅ Your usage looks efficient — no major optimizations needed")

    # Efficiency score
    total = data["total_cost"]
    savings = data["savings"]
    score = max(0, min(100, int(100 - (savings / max(total, 0.0001)) * 100)))
    score_color = "green" if score >= 80 else "yellow" if score >= 60 else "red"

    console.print(Panel(
        "\n".join(recs) + f"\n\n[bold]Efficiency Score: [{score_color}]{score}/100[/{score_color}][/bold]",
        title="💰 Recommendations",
        border_style="green",
    ))


def render_no_data():
    console.print(Panel(
        "[yellow]No Claude Code usage data found.[/yellow]\n\n"
        "[dim]metrix.ai looks for data in:\n"
        "  • ~/.config/claude/projects\n"
        "  • ~/.claude/projects\n"
        "  • %APPDATA%/Claude/projects\n\n"
        "Start using Claude Code in your terminal to see usage tracking here.[/dim]",
        title="⚡ metrix.ai",
        border_style="yellow",
    ))


# ─── Commands ─────────────────────────────────────────────────────────────────

@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """⚡ metrix.ai — LLM Cost Intelligence CLI"""
    if ctx.invoked_subcommand is None:
        ctx.invoke(today)


@cli.command()
@click.option("--days", default=1, help="Number of days to analyze")
def today(days):
    """Show today's usage summary"""
    render_header()

    dirs = find_claude_dirs()
    if not dirs:
        render_no_data()
        return

    records = load_jsonl_files(dirs)
    entries = parse_records(records)

    if not entries:
        render_no_data()
        return

    data = analyze(entries, days=days)

    render_kpis(data)
    console.print()
    render_model_table(data)
    console.print()
    render_top_sessions(data)
    console.print()
    render_waste(data)
    console.print()
    render_recommendations(data)
    console.print()


@cli.command()
def sessions():
    """Show top sessions ranked by cost"""
    render_header()
    dirs = find_claude_dirs()
    if not dirs:
        render_no_data()
        return

    records = load_jsonl_files(dirs)
    entries = parse_records(records)
    data = analyze(entries, days=30)
    render_top_sessions(data)


@cli.command()
def savings():
    """Show optimization recommendations and savings potential"""
    render_header()
    dirs = find_claude_dirs()
    if not dirs:
        render_no_data()
        return

    records = load_jsonl_files(dirs)
    entries = parse_records(records)
    data = analyze(entries, days=30)
    render_waste(data)
    console.print()
    render_recommendations(data)


@cli.command()
def blocks():
    """Show session blocks — compatible with ccusage blocks"""
    ctx = click.get_current_context()
    ctx.invoke(today, days=1)


def main():
    cli()


if __name__ == "__main__":
    main()