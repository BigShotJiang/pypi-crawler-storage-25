"""
💾 Code:
 * Name: Ahmad Sharique
 * Email: eshariq.am@gmail.com
 * Description: Utility functions for metrix.ai Python SDK
"""

import os
import json
import time
from typing import Any, Dict, Optional


# ANSI color codes for debug output
class Colors:
    BLUE = "\033[94m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    CYAN = "\033[96m"
    GRAY = "\033[90m"
    BOLD = "\033[1m"
    RESET = "\033[0m"


def load_env_config() -> Dict[str, Any]:
    """
    Load metrix.ai config from environment variables.
    Supports:
        METRIX_API_KEY
        METRIX_PROVIDER_API_KEY
        METRIX_PROJECT
        METRIX_AUTO_ROUTE
        METRIX_BASE_URL
        METRIX_DEBUG
    """
    config = {}

    api_key = os.getenv("METRIX_API_KEY")
    if api_key:
        config["api_key"] = api_key

    provider_api_key = os.getenv("METRIX_PROVIDER_API_KEY")
    if provider_api_key:
        config["provider_api_key"] = provider_api_key

    project = os.getenv("METRIX_PROJECT")
    if project:
        config["project"] = project

    auto_route = os.getenv("METRIX_AUTO_ROUTE", "").lower()
    if auto_route in ("1", "true", "yes"):
        config["auto_route"] = True

    base_url = os.getenv("METRIX_BASE_URL")
    if base_url:
        config["base_url"] = base_url

    debug = os.getenv("METRIX_DEBUG", "").lower()
    if debug in ("1", "true", "yes"):
        config["debug"] = True

    return config


def serialize_tags(tags: Optional[Dict[str, str]]) -> Optional[str]:
    """Serialize tags dict to header format: key1=val1,key2=val2"""
    if not tags:
        return None
    return ",".join(f"{k}={v}" for k, v in tags.items())


def debug_log(message: str, color: str = Colors.CYAN, prefix: str = "metrix") -> None:
    """Print a colored debug message."""
    timestamp = time.strftime("%H:%M:%S")
    print(f"{Colors.GRAY}[{timestamp}]{Colors.RESET} {color}{Colors.BOLD}[{prefix}]{Colors.RESET} {message}")


def debug_request(
    provider: str,
    model: str,
    url: str,
    auto_route: bool,
    project: Optional[str],
    tags: Optional[Dict[str, str]],
) -> None:
    """Print a formatted debug block for outgoing requests."""
    print(f"\n{Colors.BLUE}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.CYAN}  metrix.ai → outgoing request{Colors.RESET}")
    print(f"{Colors.BLUE}{'─' * 50}{Colors.RESET}")
    print(f"  {Colors.YELLOW}provider  {Colors.RESET}{provider}")
    print(f"  {Colors.YELLOW}model     {Colors.RESET}{model}")
    print(f"  {Colors.YELLOW}url       {Colors.RESET}{url}")
    print(f"  {Colors.YELLOW}routing   {Colors.RESET}{'✓ enabled' if auto_route else '✗ disabled'}")
    if project:
        print(f"  {Colors.YELLOW}project   {Colors.RESET}{project}")
    if tags:
        print(f"  {Colors.YELLOW}tags      {Colors.RESET}{json.dumps(tags)}")
    print(f"{Colors.BLUE}{'─' * 50}{Colors.RESET}\n")


def debug_response(
    model: str,
    total_tokens: int,
    cost_usd: float,
    latency_ms: int,
    routed: bool,
    original_model: Optional[str],
) -> None:
    """Print a formatted debug block for incoming responses."""
    print(f"\n{Colors.GREEN}{'─' * 50}{Colors.RESET}")
    print(f"{Colors.BOLD}{Colors.GREEN}  metrix.ai → response received{Colors.RESET}")
    print(f"{Colors.GREEN}{'─' * 50}{Colors.RESET}")
    print(f"  {Colors.YELLOW}model     {Colors.RESET}{model}")
    print(f"  {Colors.YELLOW}tokens    {Colors.RESET}{total_tokens:,}")
    print(f"  {Colors.YELLOW}cost      {Colors.RESET}${cost_usd:.6f}")
    print(f"  {Colors.YELLOW}latency   {Colors.RESET}{latency_ms}ms")
    if routed and original_model:
        print(f"  {Colors.GREEN}routed    {Colors.RESET}✓ {original_model} → {model}")
    print(f"{Colors.GREEN}{'─' * 50}{Colors.RESET}\n")