"""
💾 Code:
 * Name: Ahmad Sharique
 * Email: eshariq.am@gmail.com
 * Description: Type definitions for metrix.ai Python SDK
"""

from typing import Any, Dict, List, Literal, Optional, TypedDict


class ChatMessage(TypedDict):
    """A single message in a chat conversation."""
    role: Literal["user", "assistant", "system"]
    content: str


class ChatResponse(TypedDict):
    """Normalized response returned by MetrixClient.chat()"""
    provider: str
    model: str
    content: str
    input_tokens: int
    output_tokens: int
    total_tokens: int
    latency_ms: int
    cost_usd: float
    routed: bool
    original_model: Optional[str]
    raw: Dict[str, Any]


class MetrixConfig(TypedDict, total=False):
    """Full configuration for MetrixClient."""
    api_key: str
    provider_api_key: str
    project: Optional[str]
    auto_route: bool
    tags: Optional[Dict[str, str]]
    timeout: int
    max_retries: int
    debug: bool
    base_url: str