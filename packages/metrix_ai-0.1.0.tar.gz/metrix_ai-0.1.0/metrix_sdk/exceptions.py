"""
💾 Code:
 * Name: Ahmad Sharique
 * Email: eshariq.am@gmail.com
 * Description: Custom exceptions for metrix.ai Python SDK
"""


class MetrixError(Exception):
    """Base exception for all metrix.ai SDK errors."""
    def __init__(self, message: str, status_code: int = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)

    def __str__(self):
        if self.status_code:
            return f"[metrix.ai] {self.message} (status: {self.status_code})"
        return f"[metrix.ai] {self.message}"


class MetrixAuthError(MetrixError):
    """Raised when metrix.ai API key is missing or invalid."""
    pass


class MetrixConfigError(MetrixError):
    """Raised when SDK is misconfigured — missing required fields."""
    pass


class MetrixConnectionError(MetrixError):
    """Raised when the metrix.ai proxy cannot be reached."""
    pass


class ProviderAuthError(MetrixError):
    """Raised when the provider API key is invalid or missing."""
    pass


class ProviderRateLimitError(MetrixError):
    """Raised when the LLM provider returns a 429 rate limit response."""
    pass


class ProviderTimeoutError(MetrixError):
    """Raised when the provider does not respond within the configured timeout."""
    pass


class ProviderError(MetrixError):
    """Raised for general provider-side errors (5xx responses)."""
    pass


class MetrixRoutingError(MetrixError):
    """Raised when smart routing fails or returns an unsupported model."""
    pass


class UnsupportedProviderError(MetrixError):
    """Raised when an unsupported provider is specified."""
    def __init__(self, provider: str):
        super().__init__(f"Provider '{provider}' is not supported. Use: anthropic, openai, gemini.")