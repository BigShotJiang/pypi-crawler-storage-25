"""
💾 Code:
 * Name: Ahmad Sharique
 * Email: eshariq.am@gmail.com
 * Description: pip setup for metrix.ai Python SDK
"""

from setuptools import setup, find_packages

setup(
    name="metrix-ai",
    version="0.1.0",
    description="LLM Cost Intelligence SDK — track, optimize, and control your AI spend",
    author="Ahmad Sharique",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.24.0",
        "rich>=13.0.0",
        "click>=8.0.0",
    ],
    entry_points={
        "console_scripts": [
            "metrix=metrix_sdk.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)