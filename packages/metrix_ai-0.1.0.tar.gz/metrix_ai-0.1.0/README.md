# metrix-ai 🚀

**Python SDK for tracking LLM cost, usage, and routing decisions across OpenAI, Anthropic, and Gemini.**

[![PyPI version](https://img.shields.io/pypi/v/metrix-ai.svg)](https://pypi.org/project/metrix-ai/)
[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## Why metrix-ai?

Track every LLM API call. See where money goes. Route to cheaper models automatically.

- 🔍 Track tokens, cost, and model per request
- 💡 Detect expensive models used for simple tasks  
- 🚀 Auto-route to cheaper alternatives
- 📊 Dashboard insights and attribution

---

## Install
```bash
pip install metrix-ai
```

---

## Quickstart
```python
from metrix_sdk import MetrixClient

client = MetrixClient(
    api_key="your-metrix-token",
    provider_api_key="your-anthropic-key",
    project="my-project",
)

response = client.chat(
    provider="anthropic",
    model="claude-sonnet-4-6",
    messages=[{"role": "user", "content": "Hello from metrix.ai!"}],
)

print(response["content"])
print(f"Tokens used: {response['total_tokens']}")
print(f"Cost: ${response['cost']:.6f}")
```

---

## Environment Variables
```bash
export METRIX_API_KEY=your-metrix-token
export METRIX_PROVIDER_API_KEY=your-anthropic-key
export METRIX_PROJECT=my-project
export METRIX_AUTO_ROUTE=true
export METRIX_DEBUG=true
```

Then:
```python
from metrix_sdk import MetrixClient
client = MetrixClient()
```

---

## Smart Routing

Auto-route to cheaper models:
```python
client = MetrixClient(
    api_key="...",
    provider_api_key="...",
    auto_route=True,
)

response = client.chat(
    provider="anthropic",
    model="claude-opus-4-6",
    messages=[{"role": "user", "content": "What is 2+2?"}],
)

if response["routed"]:
    print(f"Routed: {response['original_model']} → {response['model']}")
    print(f"Savings: {response['savings_potential']}%")
```

---

## Project Attribution

Tag requests by team, feature, environment:
```python
response = client.chat(
    provider="anthropic",
    model="claude-sonnet-4-6",
    messages=[{"role": "user", "content": "Summarize..."}],
    project="customer-support",
    tags={"env": "prod", "feature": "summarization", "customer": "acme"},
)
```

Dashboard shows costs breakdown by tags.

---

## Supported Providers

| Provider | Models |
|----------|--------|
| **anthropic** | claude-opus-4-6, claude-sonnet-4-6, claude-haiku-4-5 |
| **openai** | gpt-4o, gpt-4o-mini, gpt-4-turbo |
| **gemini** | gemini-1.5-pro, gemini-1.5-flash |

---

## Error Handling
```python
from metrix_sdk import (
    MetrixAuthError,
    ProviderRateLimitError,
    ProviderTimeoutError,
    MetrixConnectionError,
    UnsupportedProviderError,
)

try:
    response = client.chat(...)
except MetrixAuthError:
    print("Invalid metrix.ai token")
except ProviderRateLimitError:
    print("Provider rate limit hit")
except ProviderTimeoutError:
    print("Request timed out")
except MetrixConnectionError:
    print("Cannot reach metrix.ai")
except UnsupportedProviderError as e:
    print(str(e))
```

---

## Configuration

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| api_key | str | env | metrix.ai JWT token |
| provider_api_key | str | env | LLM provider API key |
| project | str | None | Project slug for attribution |
| auto_route | bool | False | Enable smart routing |
| tags | dict | None | Attribution tags |
| timeout | int | 60 | Request timeout (seconds) |
| max_retries | int | 2 | Retries on failure |
| debug | bool | False | Debug output |
| base_url | str | localhost | metrix.ai proxy URL |

---

## CLI Tool
```bash
metrix today           # Today's spend
metrix savings         # Total savings from routing
metrix sessions        # Breakdown by provider
metrix blocks          # Top expensive requests
```

---

## Dashboard

View costs, routing, and efficiency:
- Cost breakdown by provider/model/date
- Routing insights and savings
- Efficiency scores
- Budget alerts

Visit: [metrix.ai](http://localhost:3000/en/dashboard)

---

## License

MIT — Ahmad Sharique