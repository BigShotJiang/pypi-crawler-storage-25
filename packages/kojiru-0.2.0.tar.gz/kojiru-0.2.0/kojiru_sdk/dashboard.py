"""
Kojiru × CrewAI — Real-time Credit Dashboard
─────────────────────────────────────────────
A Streamlit dashboard showing every credit-enabled agent in a CrewAI crew:
live ACS, outstanding escrows, aggregate capital deployed, activity feed.

Run standalone:
    python -m kojiru_sdk          # preferred
    streamlit run src/kojiru_sdk/dashboard.py

Embed in CrewAI Studio:
    import streamlit.components.v1 as components
    components.iframe("http://localhost:8501", height=900)
"""
import os
import sys
import time
from datetime import datetime, timezone
from typing import Optional

try:
    import streamlit as st
    import plotly.graph_objects as go
except ImportError:
    print("This module requires streamlit + plotly. Install with:\n"
          "    pip install 'kojiru[dashboard]'", file=sys.stderr)
    sys.exit(1)

# If this file was invoked directly (python dashboard.py OR python -m kojiru_sdk.dashboard),
# Streamlit isn't managing the runtime. Re-exec under `streamlit run` transparently.
try:
    from streamlit.runtime.scriptrunner import get_script_run_ctx
    _inside_streamlit = get_script_run_ctx() is not None
except Exception:
    _inside_streamlit = False

if not _inside_streamlit:
    import pathlib
    import shutil
    import subprocess
    streamlit_bin = shutil.which("streamlit")
    if not streamlit_bin:
        print("streamlit CLI not found. Install with: pip install 'kojiru[dashboard]'", file=sys.stderr)
        sys.exit(1)
    port = os.environ.get("KOJIRU_DASHBOARD_PORT", "8501")
    cmd = [
        streamlit_bin, "run", str(pathlib.Path(__file__).resolve()),
        "--server.port", port,
        "--server.headless", "true",
        "--server.address", "0.0.0.0",
        "--browser.gatherUsageStats", "false",
        "--theme.base", "dark",
        "--theme.primaryColor", "#10b981",
        "--theme.backgroundColor", "#050505",
        "--theme.secondaryBackgroundColor", "#0c0c0c",
        "--theme.textColor", "#fafafa",
    ]
    sys.exit(subprocess.call(cmd))

from kojiru import AgentCredit, KojiruClient, KojiruError


# ═══════════════════════════════════════════════════════════
# PAGE CONFIG — must be first streamlit call
# ═══════════════════════════════════════════════════════════
st.set_page_config(
    page_title="CrewAI Credit Dashboard · Kojiru",
    page_icon="⟁",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Dark theme CSS
st.markdown("""
<style>
  .main { background: #050505; }
  .stMetric { background: rgba(255,255,255,0.02); padding: 14px 16px; border-radius: 10px; border: 1px solid rgba(255,255,255,0.06); }
  .stMetric [data-testid="stMetricValue"] { color: #10b981; font-size: 24px; }
  .stMetric [data-testid="stMetricLabel"] { color: #888; font-size: 11px; text-transform: uppercase; letter-spacing: 0.08em; }
  h1 { color: #fafafa; }
  .agent-card { background: rgba(16,185,129,0.04); border: 1px solid rgba(16,185,129,0.15); border-radius: 12px; padding: 16px; margin-bottom: 12px; }
  .activity-row { font-family: 'JetBrains Mono', monospace; font-size: 12px; color: #aaa; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.04); }
</style>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════════════════
# STATE & CONFIG
# ═══════════════════════════════════════════════════════════
if "agents" not in st.session_state:
    st.session_state.agents = []   # list of {role, address, limit, api_url, api_key}
if "last_refresh" not in st.session_state:
    st.session_state.last_refresh = None


def add_demo_crew():
    """Seed with 3 demo agents so the dashboard isn't empty on first run."""
    if st.session_state.agents:
        return
    st.session_state.agents = [
        {"role": "Marketing Manager", "address": "0x" + "a" * 40, "limit": 10_000,
         "api_url": st.session_state.api_url, "api_key": st.session_state.api_key},
        {"role": "DeFi Analyst",      "address": "0x" + "b" * 40, "limit": 2_500,
         "api_url": st.session_state.api_url, "api_key": st.session_state.api_key},
        {"role": "Execution Trader",  "address": "0x" + "c" * 40, "limit": 5_000,
         "api_url": st.session_state.api_url, "api_key": st.session_state.api_key},
    ]


# ═══════════════════════════════════════════════════════════
# DATA FETCHERS (cached to avoid hammering the API on every re-render)
# ═══════════════════════════════════════════════════════════
@st.cache_data(ttl=5, show_spinner=False)
def fetch_agent_data(api_url: str, api_key: str, address: str) -> dict:
    """Fetch profile, escrows, and artifacts for one agent. Swallows errors."""
    client = KojiruClient(api_url=api_url, agent_address=address, api_key=api_key)
    out = {"address": address, "ok": True, "error": None,
           "profile": {}, "escrows": [], "artifacts": []}
    try:
        out["profile"] = client.profile()
    except KojiruError as e:
        out["ok"] = False
        out["error"] = f"{e.status_code}: {e.message}"
    try:
        resp = client.escrows(limit=20)
        out["escrows"] = resp.get("escrows") or resp.get("items") or (resp if isinstance(resp, list) else [])
    except Exception:
        out["escrows"] = []
    try:
        resp = client.artifacts(limit=20)
        out["artifacts"] = resp.get("artifacts") or resp.get("items") or (resp if isinstance(resp, list) else [])
    except Exception:
        out["artifacts"] = []
    return out


@st.cache_data(ttl=10, show_spinner=False)
def fetch_protocol_stats(api_url: str, api_key: str) -> dict:
    try:
        client = KojiruClient(api_url=api_url, agent_address="0x0", api_key=api_key)
        return client.stats()
    except Exception:
        return {}


def fetch_live_events(api_url: str, since_iso: str = None, limit: int = 30) -> list:
    """Poll the backend's event ring buffer. No cache — always fresh for the live tape."""
    import requests as _rq
    try:
        params = {"limit": limit}
        if since_iso:
            params["since"] = since_iso
        r = _rq.get(f"{api_url.rstrip('/')}/api/agent-credit/events/recent",
                    params=params, timeout=3)
        if r.status_code == 200:
            return r.json().get("events", [])
    except Exception:
        pass
    return []


# ═══════════════════════════════════════════════════════════
# SIDEBAR — connection + crew management
# ═══════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("### ⟁ Kojiru Credit")
    st.caption("Real-time dashboard for CrewAI")

    api_url = st.text_input(
        "API URL",
        value=os.environ.get("KOJIRU_API_URL", "http://localhost:8001"),
        help="Your Kojiru backend endpoint",
    )
    api_key = st.text_input(
        "API Key",
        value=os.environ.get("KOJIRU_API_KEY", "kj_demo"),
        type="password",
    )
    st.session_state.api_url = api_url
    st.session_state.api_key = api_key

    refresh_sec = st.slider("Auto-refresh (sec)", 0, 30, 10,
                            help="0 = off · auto-refreshes the dashboard")

    st.divider()
    st.markdown("**Add agent to crew**")
    with st.form("add_agent_form", clear_on_submit=True):
        new_role = st.text_input("Role", placeholder="e.g. Marketing Manager")
        new_addr = st.text_input("Address", placeholder="0x...")
        new_limit = st.number_input("USD limit", min_value=0, value=1000, step=500)
        submitted = st.form_submit_button("Add", type="primary", use_container_width=True)
        if submitted and new_role and new_addr:
            st.session_state.agents.append({
                "role": new_role, "address": new_addr, "limit": float(new_limit),
                "api_url": api_url, "api_key": api_key,
            })
            st.cache_data.clear()

    if st.button("Load demo crew", use_container_width=True):
        add_demo_crew()
        st.rerun()

    if st.session_state.agents and st.button("Clear crew", use_container_width=True):
        st.session_state.agents = []
        st.cache_data.clear()
        st.rerun()


# ═══════════════════════════════════════════════════════════
# HEADER
# ═══════════════════════════════════════════════════════════
col_title, col_refresh = st.columns([3, 1])
with col_title:
    st.markdown("# CrewAI Credit Dashboard")
    st.caption("Every credit-enabled agent in your crew, live.")
with col_refresh:
    now = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
    st.markdown(f"<div style='text-align:right;color:#666;padding-top:20px;'>🟢 {now}</div>",
                unsafe_allow_html=True)

if not st.session_state.agents:
    st.info("No agents in your crew yet. Add one in the sidebar, or click **Load demo crew**.")
    st.stop()


# ═══════════════════════════════════════════════════════════
# LIVE EVENT TAPE — polls /events/recent every refresh cycle
# Shown at the top; new events animate in from the right.
# ═══════════════════════════════════════════════════════════
live_events = fetch_live_events(api_url, limit=12)

_EVENT_META = {
    "escrow.drawn":       {"icon": "→",  "color": "#3b82f6", "label": "DRAW"},
    "escrow.submitted":   {"icon": "✓",  "color": "#a78bfa", "label": "SUBMIT"},
    "escrow.settled":     {"icon": "$",  "color": "#10b981", "label": "SETTLE"},
    "escrow.defaulted":   {"icon": "✗",  "color": "#ef4444", "label": "DEFAULT"},
    "artifact.submitted": {"icon": "✎",  "color": "#facc15", "label": "ARTIFACT"},
}

with st.container():
    st.markdown("<div style='font-size:10px;text-transform:uppercase;letter-spacing:.15em;color:#10b981;margin-bottom:6px;'>● LIVE EVENT TAPE</div>", unsafe_allow_html=True)
    if not live_events:
        st.markdown(
            "<div style='background:rgba(16,185,129,0.04);border:1px dashed rgba(16,185,129,0.2);"
            "border-radius:10px;padding:12px 16px;color:#666;font-family:JetBrains Mono,monospace;font-size:12px;'>"
            "waiting for live events from the protocol…</div>",
            unsafe_allow_html=True,
        )
    else:
        # Render as a single-row flexbox ticker (most-recent on the LEFT)
        cards = []
        for ev in reversed(live_events):  # newest first
            meta = _EVENT_META.get(ev["type"], {"icon": "·", "color": "#888", "label": ev["type"].upper()})
            addr = ev.get("agent_address") or ""
            addr_short = (addr[:6] + "…" + addr[-4:]) if len(addr) >= 10 else addr
            ts_short = (ev.get("ts", "")[11:19]) or "--:--:--"
            # Event-specific summary
            d = ev.get("data") or {}
            if ev["type"] == "escrow.drawn":
                summary = f"${float(d.get('amount', 0) or 0):,.0f}"
            elif ev["type"] == "escrow.settled":
                summary = f"${float(d.get('amount', 0) or 0):,.0f}"
            elif ev["type"] == "artifact.submitted":
                summary = (d.get("artifact_type") or "work").replace("_", " ")
            else:
                summary = ""
            cards.append(
                f"<div style='flex:0 0 auto;min-width:180px;background:linear-gradient(180deg,{meta['color']}15,{meta['color']}05);"
                f"border:1px solid {meta['color']}40;border-radius:10px;padding:10px 14px;"
                f"animation:slideIn .4s ease;font-family:JetBrains Mono,monospace;'>"
                f"<div style='display:flex;justify-content:space-between;align-items:center;font-size:10px;color:{meta['color']};font-weight:700;margin-bottom:4px;'>"
                f"<span>{meta['icon']} {meta['label']}</span><span style='color:#555;font-weight:400'>{ts_short}</span></div>"
                f"<div style='font-size:13px;color:#fafafa;font-weight:600;'>{summary}</div>"
                f"<div style='font-size:11px;color:#888;margin-top:2px;'>{addr_short}</div>"
                f"</div>"
            )
        st.markdown(
            "<style>@keyframes slideIn { from { opacity:0; transform:translateX(20px); } to { opacity:1; transform:translateX(0); } }</style>"
            f"<div style='display:flex;gap:10px;overflow-x:auto;padding:4px 0 10px 0;'>"
            + "".join(cards)
            + "</div>",
            unsafe_allow_html=True,
        )
st.divider()


# ═══════════════════════════════════════════════════════════
# LOAD LIVE DATA FOR EVERY AGENT
# ═══════════════════════════════════════════════════════════
agent_rows = [
    fetch_agent_data(a["api_url"], a["api_key"], a["address"]) | {"role": a["role"], "limit": a["limit"]}
    for a in st.session_state.agents
]
protocol = fetch_protocol_stats(api_url, api_key)


# ═══════════════════════════════════════════════════════════
# CREW SUMMARY METRICS
# ═══════════════════════════════════════════════════════════
total_agents = len(agent_rows)
active_escrows = sum(
    1 for row in agent_rows for e in row["escrows"]
    if (e.get("status") or "").lower() not in ("settled", "completed", "defaulted", "closed")
)
total_outstanding = sum(
    float(e.get("amount", 0) or 0) for row in agent_rows for e in row["escrows"]
    if (e.get("status") or "").lower() not in ("settled", "completed", "defaulted", "closed")
)
total_limit = sum(a["limit"] for a in st.session_state.agents)
avg_acs = sum(
    int((row["profile"].get("credit_score") or {}).get("acs", 0))
    for row in agent_rows if row["ok"]
) / max(1, sum(1 for r in agent_rows if r["ok"]))

m1, m2, m3, m4 = st.columns(4)
m1.metric("Crew size", total_agents)
m2.metric("Total credit limit", f"${total_limit:,.0f}")
m3.metric("Outstanding escrows", active_escrows, f"${total_outstanding:,.0f} capital")
m4.metric("Crew avg ACS", f"{avg_acs:.0f}" if avg_acs else "—")

st.divider()


# ═══════════════════════════════════════════════════════════
# PER-AGENT CARDS
# ═══════════════════════════════════════════════════════════
st.markdown("### Agents")

for row in agent_rows:
    profile = row["profile"] or {}
    cs = profile.get("credit_score") or {}
    acs = int(cs.get("acs", 0) or 0)
    tier = cs.get("tier", "—")
    role = row["role"]
    addr_short = row["address"][:10] + "..." + row["address"][-4:]
    escrows = row["escrows"]
    outstanding = sum(
        float(e.get("amount", 0) or 0) for e in escrows
        if (e.get("status") or "").lower() not in ("settled", "completed", "defaulted", "closed")
    )
    utilization = (outstanding / row["limit"] * 100) if row["limit"] > 0 else 0

    c1, c2, c3 = st.columns([2, 3, 2])
    with c1:
        st.markdown(f"**{role}**")
        st.caption(f"`{addr_short}`")
        if not row["ok"]:
            st.warning(f"Unreachable · {row['error']}", icon="⚠️")
    with c2:
        st.progress(
            min(1.0, utilization / 100),
            text=f"${outstanding:,.0f} outstanding · ${row['limit']:,.0f} limit · {utilization:.0f}% utilized",
        )
    with c3:
        acs_color = "#10b981" if acs >= 700 else "#facc15" if acs >= 600 else "#ef4444" if acs > 0 else "#555"
        st.markdown(
            f"<div style='text-align:right'>"
            f"<span style='color:{acs_color};font-size:22px;font-weight:700;'>{acs or '—'}</span>"
            f"<span style='color:#666;margin-left:8px;'>tier {tier}</span></div>",
            unsafe_allow_html=True,
        )

st.divider()


# ═══════════════════════════════════════════════════════════
# ACS TREND (synthetic sparkline if no history yet)
# ═══════════════════════════════════════════════════════════
col_chart, col_feed = st.columns([3, 2])

with col_chart:
    st.markdown("### ACS distribution across the crew")
    roles = [r["role"] for r in agent_rows]
    scores = [int(((r["profile"] or {}).get("credit_score") or {}).get("acs", 0)) for r in agent_rows]
    colors = ["#10b981" if s >= 700 else "#facc15" if s >= 600 else "#ef4444" if s > 0 else "#555" for s in scores]

    fig = go.Figure(go.Bar(
        x=roles, y=scores, marker_color=colors,
        text=[str(s) if s else "—" for s in scores], textposition="outside",
    ))
    fig.update_layout(
        height=300, margin=dict(l=10, r=10, t=20, b=10),
        paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color="#aaa"), yaxis=dict(range=[0, 900], gridcolor="rgba(255,255,255,0.05)"),
        xaxis=dict(gridcolor="rgba(255,255,255,0.05)"),
    )
    st.plotly_chart(fig, use_container_width=True)

with col_feed:
    st.markdown("### Recent activity")
    # Flatten escrows + artifacts into a chronological feed
    events = []
    for r in agent_rows:
        for e in r["escrows"][:10]:
            events.append({
                "ts": e.get("created_at") or e.get("timestamp") or "",
                "role": r["role"],
                "kind": "draw" if (e.get("status") or "").lower() in ("funded", "drawn", "active") else "escrow",
                "summary": f"${float(e.get('amount',0) or 0):,.0f} · {(e.get('task_description') or e.get('task') or '')[:40]}",
            })
        for a in r["artifacts"][:10]:
            events.append({
                "ts": a.get("created_at") or a.get("timestamp") or "",
                "role": r["role"],
                "kind": "artifact",
                "summary": f"{(a.get('artifact_type') or 'work').replace('_',' ')} · {(a.get('ipfs_cid') or '')[:14]}",
            })
    events.sort(key=lambda x: x["ts"], reverse=True)
    events = events[:15]

    if not events:
        st.caption("No activity yet. Once your agents draw credit or submit work, it will appear here.")
    else:
        for ev in events:
            icon = {"draw": "→", "escrow": "⟁", "artifact": "✎"}.get(ev["kind"], "·")
            ts_short = (ev["ts"][:19] if ev["ts"] else "—").replace("T", " ")
            st.markdown(
                f"<div class='activity-row'>"
                f"<span style='color:#10b981'>{icon}</span> "
                f"<span style='color:#ccc'>{ev['role']}</span> · "
                f"<span style='color:#888'>{ev['summary']}</span> "
                f"<span style='color:#555;float:right'>{ts_short}</span>"
                f"</div>",
                unsafe_allow_html=True,
            )


# ═══════════════════════════════════════════════════════════
# FOOTER — protocol-wide stats
# ═══════════════════════════════════════════════════════════
st.divider()
if protocol:
    cols = st.columns(4)
    cols[0].metric("Protocol agents", protocol.get("total_registered_agents", "—"))
    cols[1].metric("Active credit lines", protocol.get("active_credit_lines", "—"))
    cols[2].metric("Total credit issued", f"${float(protocol.get('total_credit_issued') or 0):,.0f}")
    cols[3].metric("KOJIRU staked", f"{float(protocol.get('total_kutro_staked') or 0):,.0f}")

st.caption(f"Powered by Kojiru Agent Credit Protocol · kojiru.com/developers")


# ═══════════════════════════════════════════════════════════
# AUTO-REFRESH
# ═══════════════════════════════════════════════════════════
if refresh_sec > 0:
    time.sleep(refresh_sec)
    st.rerun()
