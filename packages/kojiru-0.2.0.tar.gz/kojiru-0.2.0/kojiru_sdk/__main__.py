"""Entry point: `python -m kojiru_sdk` launches the dashboard."""
from kojiru_sdk.dashboard import *  # noqa: F401,F403 — triggers the auto-launcher
