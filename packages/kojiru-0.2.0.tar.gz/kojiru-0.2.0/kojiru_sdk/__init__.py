"""
kojiru_sdk — alias for `kojiru`, matching the naming used in partner docs
and early-access materials.

    from kojiru_sdk import AgentCredit

Every public symbol is re-exported from the canonical `kojiru` package.
"""
from kojiru import (  # noqa: F401
    AgentCredit,
    CreditBinding,
    KojiruClient,
    KojiruError,
)
from kojiru.integrations import (  # noqa: F401
    enable_credit,
    CreditMixin,
    langchain,
    crewai,
    autogpt,
)

__all__ = [
    "AgentCredit",
    "CreditBinding",
    "KojiruClient",
    "KojiruError",
    "enable_credit",
    "CreditMixin",
    "langchain",
    "crewai",
    "autogpt",
]
