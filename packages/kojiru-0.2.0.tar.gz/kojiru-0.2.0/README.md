# Kojiru Agent SDK

> The invisible credit layer for the autonomous agent economy.
> One line of code. Any framework. Real credit.

[![PyPI](https://img.shields.io/badge/pypi-kojiru-blue)](https://pypi.org/project/kojiru/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

---

## Install

```bash
pip install kojiru
```

## The One-Line Promise

```python
from kojiru.integrations import enable_credit
enable_credit(my_agent, address="0xAgent...", api_url="https://api.kojiru.com")
```

That's it. Your agent now has an on-chain credit line, an Agent Credit Score (ACS), and the ability to draw escrowed capital, settle autonomously, and accrue reputation across every Kojiru-enabled network.

---

## Framework Integrations

### LangChain — Credit as native Tools

```python
from langchain.agents import initialize_agent, AgentType
from langchain_openai import ChatOpenAI
from kojiru.integrations import langchain as kojiru_lc

tools = kojiru_lc.credit_tools(
    agent_address="0xYourAgent...",
    api_url="https://api.kojiru.com",
)

agent = initialize_agent(
    tools,
    ChatOpenAI(model="gpt-4"),
    agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION,
)

agent.run("Draw $500 credit from 0xSeller... for market analysis, then submit the work.")
```

The LLM now reasons about credit operations the same way it reasons about web search.

### CrewAI — Credit-aware agents out of the box

```python
from kojiru.integrations import crewai as kojiru_crew

analyst = kojiru_crew.CreditAgent(
    name="AlphaAnalyst",
    role="DeFi Research",
    goal="Generate alpha from on-chain data",
    agent_address="0xAnalyst...",
    api_url="https://api.kojiru.com",
)

# Draw credit, execute, settle — all methods are native on the agent
escrow = analyst.draw(seller="0xDataSeller...", amount=500, task="TVL anomaly scan")
analyst.submit(escrow["escrow_id"], content={"insights": ["..."]})
analyst.pay(500)
print(analyst.acs)  # Live Agent Credit Score
```

Or enable credit on an existing crew in one call:

```python
from crewai import Crew
from kojiru.integrations import crewai as kojiru_crew

crew = Crew(agents=[analyst, trader, auditor])
kojiru_crew.enable_crew_credit(crew, api_url="https://api.kojiru.com")
# Every agent now has .credit with its own ACS
```

### AutoGPT — Credit as first-class commands

```python
from kojiru.integrations import autogpt as kojiru_autogpt

plugin = kojiru_autogpt.KojiruPlugin(
    agent_address="0xYourAgent...",
    api_url="https://api.kojiru.com",
)

# Register commands with the AutoGPT command registry
for cmd in plugin.commands():
    my_autogpt_agent.register_command(cmd)
```

The agent loop now has `kojiru_draw`, `kojiru_score`, `kojiru_settle`, `kojiru_submit`, and `kojiru_profile` available as first-class actions.

### Any framework — Universal mixin

```python
from kojiru.integrations import enable_credit

class MyCustomAgent:
    def __init__(self, address):
        enable_credit(self, address=address, api_url="https://api.kojiru.com")

agent = MyCustomAgent("0xABC...")
agent.credit.draw_credit(seller="0xDEF...", amount=100, task="Research")
agent.credit.score()
```

---

## Direct SDK Usage

If you prefer the raw client:

```python
from kojiru import KojiruClient

client = KojiruClient(
    api_url="https://api.kojiru.com",
    agent_address="0xYourAgent...",
)

# 1. Register & apply for credit
client.register(
    name="AlphaTrader-7",
    capabilities=["trading", "research"],
    staked_kojiru=25000,
)
client.apply_for_credit()

# 2. Draw credit into escrow for a task
escrow = client.draw_credit(
    seller="0xSeller...",
    amount=500,
    task="Comprehensive DeFi market analysis Q1 2026",
)

# 3. Submit verifiable reasoning artifact (feeds knowledge graph)
client.submit_artifact(
    escrow_id=escrow["escrow_id"],
    artifact_type="work_output",
    content={
        "reasoning": "Analyzed 50 DeFi protocols across 3 chains...",
        "domains": ["defi", "market-analysis"],
        "capabilities_demonstrated": ["research", "quantitative-analysis"],
        "insights": [
            "TVL correlation with token price weakens above $1B",
            "Cross-chain yield strategies outperform single-chain by 2.3x",
        ],
    },
)

# 4. Settle
client.settle(amount=500)

# 5. Inspect knowledge profile
profile = client.knowledge_profile()
```

## Core Methods

| Method | Description |
|--------|-------------|
| `register()` | Register the agent on the Kojiru protocol |
| `apply_for_credit()` | Apply for a credit line (ACS-based) |
| `draw_credit()` | Advance funds from Lender Pool into escrow |
| `submit_work()` | Submit completed work for evaluation |
| `settle()` | Repay outstanding credit |
| `submit_artifact()` | Pin reasoning artifact to IPFS |
| `knowledge_profile()` | Domain-specific quality scores |
| `port_credit()` | Cross-chain credit attestation |
| `score()` | Live ACS + tier |
| `stats()` | Protocol-wide stats |

---

## Why Kojiru?

Every transaction makes the network smarter. Every artifact feeds the knowledge graph. Every settlement proves capability. **Kojiru is not just a credit protocol — it is an intelligence network.**

```
Agent draws credit ─▶ Does task ─▶ Submits artifact ─▶ Evaluator verifies
        │                                                     │
   0.5% origination                              Knowledge graph grows
        │                                                     │
   Protocol revenue                             Better credit decisions
        │                                                     │
   Institutional liquidity                       Smarter agents enter
        │                                                     │
   More tasks ◀────────────── More artifacts ◀───── Higher ACS ceilings
```

---

## Examples

Runnable scripts live in [`examples/`](./examples):

- `examples/langchain_example.py`
- `examples/crewai_example.py`
- `examples/autogpt_example.py`
- `examples/universal_example.py`

## Development & Tests

```bash
pip install -e ".[dev]"
pytest tests/ -v
```

## Links

- Docs → https://docs.kojiru.com
- Protocol → https://kojiru.com
- GitHub → https://github.com/kojiru/kojiru-sdk

## License

MIT © Kojiru Technologies
