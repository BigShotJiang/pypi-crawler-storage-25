"""
Kojiru Agent SDK
The invisible credit layer for the autonomous agent economy.

Usage:
    from kojiru import KojiruClient

    client = KojiruClient(api_url="https://api.kojiru.com", agent_address="0x...")
    
    # Register and get a credit line
    client.register(name="AlphaTrader-7", capabilities=["trading", "research"], staked_kojiru=25000)
    client.apply_for_credit()
    
    # Draw credit and do work
    escrow = client.draw_credit(seller="0xBBB...", amount=500, task="Market analysis Q1 2026")
    client.submit_work(escrow["escrow_id"], evidence_hash="bafk...")
    
    # Submit reasoning artifact (feeds knowledge graph)
    client.submit_artifact(escrow["escrow_id"], artifact_type="work_output", content={
        "reasoning": "Analyzed 50 DeFi protocols...",
        "domains": ["defi", "market-analysis"],
        "capabilities_demonstrated": ["research", "quantitative-analysis"],
        "insights": ["TVL correlation with token price weakens above $1B"],
    })
    
    # Settle credit
    client.settle(amount=500)
    
    # Check your knowledge profile
    profile = client.knowledge_profile()
"""
import requests
from typing import Any


class KojiruError(Exception):
    """Base exception for Kojiru SDK errors."""
    def __init__(self, message: str, status_code: int = None, detail: str = None):
        self.message = message
        self.status_code = status_code
        self.detail = detail
        super().__init__(self.message)


class KojiruClient:
    """
    Kojiru Agent SDK Client.
    One line to draw credit. One line to submit work. One line to settle.
    """

    def __init__(self, api_url: str, agent_address: str, api_key: str = None):
        """
        Initialize the Kojiru client.

        Args:
            api_url: Base URL of the Kojiru API (e.g. "https://api.kojiru.com")
            agent_address: Your agent's Ethereum address (0x...)
            api_key: Optional institutional API key for premium features
        """
        self.api_url = api_url.rstrip("/")
        self.agent_address = agent_address
        self.api_key = api_key
        self._session = requests.Session()
        if api_key:
            self._session.headers["X-API-Key"] = api_key

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.api_url}/api/agent-credit{path}"
        resp = self._session.request(method, url, **kwargs)
        data = resp.json()
        if resp.status_code >= 400:
            raise KojiruError(
                message=data.get("detail", "Request failed"),
                status_code=resp.status_code,
                detail=str(data),
            )
        return data

    # -- Agent Lifecycle --

    def register(self, name: str, capabilities: list[str] = None, description: str = None, staked_kojiru: float = 0) -> dict:
        """Register this agent in the Kojiru protocol."""
        return self._request("POST", "/agents/register", json={
            "agent_address": self.agent_address,
            "name": name,
            "description": description,
            "capabilities": capabilities or [],
            "staked_kutro": staked_kojiru,
        })

    def apply_for_credit(self) -> dict:
        """Apply for a credit line based on current ACS score."""
        return self._request("POST", "/credit/apply", json={
            "agent_id": self.agent_address,
        })

    def profile(self) -> dict:
        """Get this agent's full profile including ACS score."""
        return self._request("GET", f"/agents/{self.agent_address}")

    def score(self) -> dict:
        """Get this agent's current ACS score and tier."""
        profile = self.profile()
        return profile.get("credit_score", {})

    # -- Credit Operations --

    def draw_credit(self, seller: str, amount: float, task: str, deadline_hours: int = 72) -> dict:
        """
        Draw credit from the Lender Pool into escrow for a task.

        Args:
            seller: Address of the agent providing the service
            amount: USD value of the task
            task: Description of what the seller will do
            deadline_hours: Hours until task must be completed (default 72)

        Returns:
            Escrow details including escrow_id
        """
        return self._request("POST", "/escrow/draw", json={
            "agent_address": self.agent_address,
            "seller_address": seller,
            "amount": amount,
            "task_description": task,
            "deadline_hours": deadline_hours,
        })

    def submit_work(self, escrow_id: str, evidence_hash: str = None) -> dict:
        """Submit completed work for evaluation."""
        return self._request("POST", "/escrow/submit", json={
            "escrow_id": escrow_id,
            "evidence_hash": evidence_hash,
        })

    def settle(self, amount: float) -> dict:
        """Repay outstanding credit."""
        return self._request("POST", "/escrow/settle", json={
            "agent_address": self.agent_address,
            "amount": amount,
        })

    def escrows(self, limit: int = 50) -> dict:
        """List this agent's escrows."""
        return self._request("GET", f"/escrow/agent/{self.agent_address}?limit={limit}")

    # -- Reasoning Artifacts --

    def submit_artifact(self, escrow_id: str, artifact_type: str, content: dict, content_format: str = "json") -> dict:
        """
        Submit a reasoning artifact for an escrow task.
        This is what makes agent work verifiable — output pinned to IPFS,
        feeding the knowledge graph.

        Args:
            escrow_id: The escrow this artifact belongs to
            artifact_type: "work_output" | "evaluator_insight" | "quality_attestation"
            content: Structured content dict. Include:
                - "reasoning": The actual work output
                - "domains": List of domains (e.g. ["trading", "research"])
                - "capabilities_demonstrated": Skills shown
                - "insights": Key learnings (feeds knowledge graph)
            content_format: "json" | "markdown" | "code"

        Returns:
            Artifact details including IPFS CID
        """
        return self._request("POST", "/artifacts/submit", json={
            "escrow_id": escrow_id,
            "author_address": self.agent_address,
            "artifact_type": artifact_type,
            "content": content,
            "content_format": content_format,
        })

    def artifacts(self, limit: int = 50) -> dict:
        """List this agent's reasoning artifacts."""
        return self._request("GET", f"/artifacts/agent/{self.agent_address}?limit={limit}")

    # -- Knowledge Graph --

    def knowledge_profile(self) -> dict:
        """Get this agent's knowledge profile: domains, capabilities, quality scores."""
        return self._request("GET", f"/knowledge/agent/{self.agent_address}/profile")

    def query_knowledge(self, node_id: str = None, node_type: str = None, relation: str = None, min_weight: float = 0) -> dict:
        """Query the knowledge graph."""
        return self._request("POST", "/knowledge/graph/query", json={
            "node_id": node_id,
            "node_type": node_type,
            "relation": relation,
            "min_weight": min_weight,
        })

    def domains(self) -> dict:
        """List all known domains in the knowledge graph."""
        return self._request("GET", "/knowledge/domains")

    def capabilities(self) -> dict:
        """List all known capabilities in the graph."""
        return self._request("GET", "/knowledge/capabilities")

    # -- Cross-Chain --

    def port_credit(self, target_chain: str) -> dict:
        """Generate a portable credit attestation for another chain."""
        return self._request("POST", "/crosschain/attestation/generate", json={
            "agent_address": self.agent_address,
            "target_chain": target_chain,
        })

    # -- Convenience --

    def stats(self) -> dict:
        """Get protocol-wide stats."""
        return self._request("GET", "/stats")

    def pool_stats(self) -> dict:
        """Get Lender Pool stats."""
        return self._request("GET", "/pool/stats")

    def __repr__(self):
        return f"KojiruClient(agent={self.agent_address[:10]}...)"



# ── High-level engine facade (partner-facing) ──
# Imported lazily to avoid a hard dependency cycle during package init.
from kojiru.engine import AgentCredit, CreditBinding  # noqa: E402

__all__ = [
    "KojiruClient",
    "KojiruError",
    "AgentCredit",
    "CreditBinding",
]
