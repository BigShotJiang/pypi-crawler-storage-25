"""
Kojiru AgentCredit Engine
─────────────────────────
The high-level "engine" facade — the one developers see first.

This is the pattern CrewAI, LangChain, and AutoGPT partners will copy into
their own docs:

    from kojiru_sdk import AgentCredit

    credit_engine = AgentCredit(api_key="your_kojiru_key")
    credit_engine.enable_credit(my_agent, limit=10_000)

Under the hood it uses the existing KojiruClient + framework adapters, but
the surface is a single object with a single decision: "enable credit."
"""
import hashlib
import os
from typing import Any, Optional

from kojiru import KojiruClient


class CreditBinding:
    """
    The result of `AgentCredit.enable_credit(agent, ...)`.

    Holds a strong reference to the underlying KojiruClient plus per-agent
    metadata (limit, role, address). Exposes all credit operations and also
    mirrors them onto the bound agent when the agent object allows attribute
    assignment (plain classes, dicts, CrewAI Agents with extra='allow').
    """

    def __init__(
        self,
        agent: Any,
        client: KojiruClient,
        address: str,
        limit_usd: float,
        role: Optional[str] = None,
    ):
        self.agent = agent
        self.client = client
        self.address = address
        self.limit_usd = limit_usd
        self.role = role

    # ── delegation to the underlying client ──

    def draw(self, seller: str, amount: float, task: str, **kwargs):
        if amount > self.limit_usd:
            raise ValueError(
                f"Draw amount ${amount} exceeds agent credit limit ${self.limit_usd}. "
                f"Increase the limit via AgentCredit.update_limit() or split the task."
            )
        return self.client.draw_credit(seller=seller, amount=amount, task=task, **kwargs)

    def pay(self, amount: float):
        return self.client.settle(amount=amount)

    def submit(self, escrow_id: str, content: dict, artifact_type: str = "work_output"):
        return self.client.submit_artifact(escrow_id, artifact_type, content)

    @property
    def acs(self) -> dict:
        return self.client.score()

    @property
    def credit(self) -> KojiruClient:
        return self.client

    def __repr__(self):
        r = f"role={self.role!r}, " if self.role else ""
        return f"CreditBinding({r}address={self.address[:10]}..., limit=${self.limit_usd:,.0f})"


class AgentCredit:
    """
    Kojiru Agent Credit Engine — the one-stop entrypoint for partners.

    Usage (framework-agnostic):
        from kojiru_sdk import AgentCredit
        engine = AgentCredit(api_key="your_key")
        binding = engine.enable_credit(my_agent, limit=10_000)
        binding.draw(seller="0x...", amount=500, task="Campaign")

    Usage (CrewAI):
        from crewai import Agent
        from kojiru_sdk import AgentCredit

        engine = AgentCredit(api_key="your_key")

        manager = Agent(
            role='Marketing Manager',
            goal='Execute ad spend autonomously',
            backstory='Expert in ROI-driven campaigns',
            allow_delegation=True,
        )

        engine.enable_credit(manager, limit=10_000)

        # `manager.credit` / `manager.acs` / `manager.draw(...)` now available
        manager.draw(seller="0xAdNetwork...", amount=500, task="Meta Ads campaign")
    """

    def __init__(
        self,
        api_key: str,
        api_url: str = "https://api.kojiru.com",
    ):
        if not api_key:
            raise ValueError("AgentCredit requires an api_key. Get one at https://kojiru.com/developers")
        self.api_key = api_key
        self.api_url = api_url
        # Registry of active bindings keyed by agent id() — lets us look them up later.
        self._bindings: dict[int, CreditBinding] = {}

    # ── Core API ──

    def enable_credit(
        self,
        agent: Any,
        limit: float,
        address: Optional[str] = None,
        name: Optional[str] = None,
        capabilities: Optional[list] = None,
        staked_kojiru: float = 0,
        auto_register: bool = True,
    ) -> CreditBinding:
        """
        The magic line. Enable Kojiru credit on any agent.

        Args:
            agent: Any Python object — CrewAI Agent, LangChain agent, custom class.
            limit: Max USD this agent can draw in a single escrow.
            address: Agent's on-chain address. If omitted, one is deterministically
                     derived from the agent's role/name (for dev/demo only;
                     production should pass an explicit ERC-8004 identity).
            name: Friendly name (auto-detected from agent.role / agent.name if omitted).
            capabilities: Skills the agent claims (auto-detected when possible).
            staked_kojiru: KOJIRU tokens the agent has staked.
            auto_register: Call register() + apply_for_credit() on the protocol.
                           Set False if the agent is already registered.

        Returns:
            CreditBinding — the operational handle.
        """
        detected_name = name or self._infer_name(agent)
        detected_caps = capabilities if capabilities is not None else self._infer_capabilities(agent)
        resolved_address = address or self._derive_address(detected_name, agent)

        client = KojiruClient(
            api_url=self.api_url,
            agent_address=resolved_address,
            api_key=self.api_key,
        )

        if auto_register:
            try:
                client.register(
                    name=detected_name,
                    capabilities=detected_caps,
                    staked_kojiru=staked_kojiru,
                )
            except Exception:
                # Already registered or protocol rejected — continue; the binding
                # still works for read ops and for agents re-booting.
                pass
            try:
                client.apply_for_credit()
            except Exception:
                pass

        binding = CreditBinding(
            agent=agent,
            client=client,
            address=resolved_address,
            limit_usd=float(limit),
            role=self._infer_name(agent),
        )

        # Attach convenience attributes to the agent if the object permits it.
        # CrewAI's Agent is a pydantic model with extra='allow' so this works;
        # for strict pydantic models we silently skip and rely on the returned binding.
        for attr, value in (
            ("credit", client),
            ("kojiru_binding", binding),
            ("draw", binding.draw),
            ("pay", binding.pay),
            ("submit", binding.submit),
        ):
            try:
                setattr(agent, attr, value)
            except (AttributeError, TypeError, ValueError):
                try:
                    object.__setattr__(agent, attr, value)
                except Exception:
                    pass  # Strict model — user will use the returned binding directly.

        # Mirror acs as a property-like lookup — can't assign @property to instance,
        # so we set a callable under .acs and let users call or read .kojiru_binding.acs.
        try:
            setattr(agent, "acs", lambda: binding.acs)
        except Exception:
            pass

        self._bindings[id(agent)] = binding
        return binding

    def binding_for(self, agent: Any) -> Optional[CreditBinding]:
        """Retrieve a previously-created binding by agent reference."""
        return self._bindings.get(id(agent))

    def enable_crew(self, crew: Any, limit: float, **kwargs) -> list[CreditBinding]:
        """
        Enable credit on every agent in a CrewAI Crew with a uniform limit.
        Returns list of bindings in the same order as crew.agents.
        """
        agents = getattr(crew, "agents", None) or crew
        return [self.enable_credit(a, limit=limit, **kwargs) for a in agents]

    # ── Helpers ──

    @staticmethod
    def _infer_name(agent: Any) -> str:
        for attr in ("role", "name", "agent_name"):
            v = getattr(agent, attr, None)
            if v:
                return str(v)
        return agent.__class__.__name__

    @staticmethod
    def _infer_capabilities(agent: Any) -> list:
        caps = getattr(agent, "capabilities", None)
        if caps:
            return list(caps)
        # Fall back to CrewAI's tools list — tool names make decent capability tags.
        tools = getattr(agent, "tools", None) or []
        out = []
        for t in tools:
            name = getattr(t, "name", None) or getattr(t, "__name__", None)
            if name:
                out.append(str(name))
        return out

    @staticmethod
    def _derive_address(name: str, agent: Any) -> str:
        """
        Deterministic dev address derived from agent identity.
        Production should pass an explicit ERC-8004 address via `address=`.
        """
        seed = f"{name}|{getattr(agent, 'goal', '')}|{getattr(agent, 'backstory', '')}"
        digest = hashlib.sha256(seed.encode("utf-8")).hexdigest()
        return "0x" + digest[:40]

    def __repr__(self):
        return f"AgentCredit(api_url={self.api_url!r}, active_bindings={len(self._bindings)})"
