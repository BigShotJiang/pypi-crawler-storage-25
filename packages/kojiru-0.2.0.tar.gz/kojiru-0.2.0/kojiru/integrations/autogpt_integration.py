"""
Kojiru x AutoGPT Integration
Adds Kojiru credit as a native AutoGPT plugin/command.

Usage:
    from kojiru.integrations.autogpt_integration import KojiruPlugin, enable_autogpt_credit

    # Option 1: Get the plugin for AutoGPT command registry
    plugin = KojiruPlugin(agent_address="0xAgent...", api_url="https://api.kojiru.com")
    commands = plugin.commands()  # Returns list of AutoGPT-compatible command dicts

    # Option 2: Enable credit on an existing AutoGPT agent
    enable_autogpt_credit(agent, address="0xAgent...", api_url="https://api.kojiru.com")
    agent.credit.draw_credit(seller="0x...", amount=500, task="Research")
"""
from kojiru import KojiruClient
from kojiru.integrations.core import enable_credit


class KojiruPlugin:
    """
    AutoGPT plugin that exposes Kojiru credit as agent commands.

    When registered with AutoGPT, the agent can:
    - kojiru_draw: Draw credit for a task
    - kojiru_score: Check ACS
    - kojiru_settle: Repay credit
    - kojiru_submit: Submit work artifacts
    - kojiru_profile: View knowledge profile
    """

    def __init__(self, agent_address: str, api_url: str = "https://api.kojiru.com", api_key: str = None):
        self.client = KojiruClient(api_url=api_url, agent_address=agent_address, api_key=api_key)
        self.agent_address = agent_address

    def commands(self) -> list:
        """Return AutoGPT-compatible command definitions."""
        return [
            {
                "name": "kojiru_draw",
                "description": "Draw credit from Kojiru into escrow for a task",
                "parameters": {
                    "seller": {"type": "string", "description": "Seller agent address", "required": True},
                    "amount": {"type": "number", "description": "USD amount", "required": True},
                    "task": {"type": "string", "description": "Task description", "required": True},
                },
                "handler": self._draw,
            },
            {
                "name": "kojiru_score",
                "description": "Check current Agent Credit Score (ACS) and tier",
                "parameters": {},
                "handler": self._score,
            },
            {
                "name": "kojiru_settle",
                "description": "Repay outstanding credit",
                "parameters": {
                    "amount": {"type": "number", "description": "USD amount to repay", "required": True},
                },
                "handler": self._settle,
            },
            {
                "name": "kojiru_submit",
                "description": "Submit work artifact for verification",
                "parameters": {
                    "escrow_id": {"type": "string", "description": "Escrow ID", "required": True},
                    "content": {"type": "object", "description": "Work output content", "required": True},
                },
                "handler": self._submit,
            },
            {
                "name": "kojiru_profile",
                "description": "Get agent knowledge profile from Kojiru graph",
                "parameters": {},
                "handler": self._profile,
            },
        ]

    def _draw(self, seller: str, amount: float, task: str) -> dict:
        return self.client.draw_credit(seller=seller, amount=amount, task=task)

    def _score(self) -> dict:
        return self.client.score()

    def _settle(self, amount: float) -> dict:
        return self.client.settle(amount=amount)

    def _submit(self, escrow_id: str, content: dict) -> dict:
        return self.client.submit_artifact(escrow_id, "work_output", content)

    def _profile(self) -> dict:
        return self.client.knowledge_profile()

    def __repr__(self):
        return f"KojiruPlugin(agent={self.agent_address[:10]}...)"


def enable_autogpt_credit(agent, address: str, api_url: str = "https://api.kojiru.com", api_key: str = None) -> KojiruClient:
    """
    Enable Kojiru credit on an AutoGPT agent instance.
    Attaches .credit (KojiruClient) and .kojiru_plugin (KojiruPlugin).

    Args:
        agent: AutoGPT agent instance
        address: Agent's Ethereum address
        api_url: Kojiru API URL
        api_key: Optional API key

    Returns:
        KojiruClient instance
    """
    client = enable_credit(agent, address=address, api_url=api_url, api_key=api_key)
    agent.kojiru_plugin = KojiruPlugin(agent_address=address, api_url=api_url, api_key=api_key)
    return client
