"""
Kojiru Core Integration Layer
Framework-agnostic credit enablement for any Python agent.

The magic line:
    from kojiru.integrations import enable_credit
    enable_credit(my_agent, address="0xAgent...", api_url="https://api.kojiru.com")

This attaches .credit (KojiruClient) to any object, enabling:
    my_agent.credit.draw_credit(seller="0x...", amount=500, task="Analysis")
    my_agent.credit.score()
    my_agent.credit.settle(amount=500)
"""
from kojiru import KojiruClient


class CreditMixin:
    """
    Mixin that adds Kojiru credit capabilities to any agent class.

    Usage:
        class MyAgent(CreditMixin):
            def __init__(self):
                self.init_credit("0xAgent...", "https://api.kojiru.com")

        agent = MyAgent()
        agent.credit.draw_credit(seller="0x...", amount=100, task="work")
    """

    def init_credit(self, agent_address: str, api_url: str = "https://api.kojiru.com", api_key: str = None):
        """Initialize Kojiru credit on this agent."""
        self._kojiru = KojiruClient(api_url=api_url, agent_address=agent_address, api_key=api_key)
        return self._kojiru

    @property
    def credit(self) -> KojiruClient:
        """Access the Kojiru credit client."""
        if not hasattr(self, '_kojiru') or self._kojiru is None:
            raise RuntimeError("Credit not initialized. Call init_credit() first or use enable_credit().")
        return self._kojiru

    def enable_credit(self, agent_address: str, api_url: str = "https://api.kojiru.com", api_key: str = None):
        """Alias for init_credit — the one-line enablement."""
        return self.init_credit(agent_address, api_url, api_key)


def enable_credit(agent, address: str, api_url: str = "https://api.kojiru.com", api_key: str = None) -> KojiruClient:
    """
    Enable Kojiru credit on ANY agent object with a single line.

    This is the universal integration point — works with any Python object.
    Attaches a .credit property that provides full Kojiru SDK access.

    Args:
        agent: Any Python object (LangChain agent, CrewAI agent, custom class, etc.)
        address: Agent's Ethereum address (0x...)
        api_url: Kojiru API URL
        api_key: Optional institutional API key

    Returns:
        KojiruClient instance (also accessible via agent.credit)

    Example:
        from kojiru.integrations import enable_credit

        # Works with ANY agent
        my_agent = SomeFrameworkAgent()
        enable_credit(my_agent, address="0xABC...", api_url="https://api.kojiru.com")

        # Now the agent has financial capabilities
        my_agent.credit.draw_credit(seller="0xDEF...", amount=500, task="Research")
        my_agent.credit.score()  # Check ACS
        my_agent.credit.settle(amount=500)  # Repay
    """
    client = KojiruClient(api_url=api_url, agent_address=address, api_key=api_key)
    agent.credit = client
    return client
