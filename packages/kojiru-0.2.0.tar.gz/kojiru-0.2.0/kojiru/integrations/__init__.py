"""
Kojiru Framework Integrations
One-line credit enablement for any agent framework.

Usage:
    # LangChain
    from kojiru.integrations import langchain
    tools = langchain.credit_tools("0xAgent...", api_url="https://api.kojiru.com")

    # CrewAI
    from kojiru.integrations import crewai
    agent = crewai.CreditAgent(name="Trader", address="0x...", api_url="https://api.kojiru.com")

    # Any framework
    from kojiru.integrations import enable_credit
    enable_credit(agent, address="0x...", api_url="https://api.kojiru.com")
"""

from kojiru.integrations.core import enable_credit, CreditMixin
from kojiru.integrations import langchain_integration as langchain
from kojiru.integrations import crewai_integration as crewai
from kojiru.integrations import autogpt_integration as autogpt

__all__ = ["enable_credit", "CreditMixin", "langchain", "crewai", "autogpt"]
