"""
Kojiru x CrewAI Integration
Adds Kojiru credit capabilities to CrewAI agents with a single line.

Usage:
    from kojiru.integrations.crewai_integration import CreditAgent, enable_crew_credit

    # Option 1: Create a credit-enabled agent directly
    agent = CreditAgent(
        name="AlphaTrader",
        role="DeFi Analyst",
        goal="Execute profitable trades using Kojiru credit lines",
        agent_address="0xAgent...",
        api_url="https://api.kojiru.com",
    )
    agent.credit.draw_credit(seller="0xSeller...", amount=500, task="Market analysis")

    # Option 2: Enable credit on an existing crew
    from crewai import Crew, Agent
    crew = Crew(agents=[agent1, agent2])
    enable_crew_credit(crew, api_url="https://api.kojiru.com")
    # Now each agent in the crew has .credit with its own ACS
"""
from kojiru import KojiruClient
from kojiru.integrations.core import CreditMixin


class CreditAgent(CreditMixin):
    """
    A CrewAI-compatible agent with built-in Kojiru credit capabilities.

    This agent has all the standard CrewAI agent properties PLUS:
    - .credit — Full KojiruClient access
    - .acs — Current Agent Credit Score
    - .draw() — Shorthand for credit draw
    - .pay() — Shorthand for credit settlement

    The agent can autonomously draw credit, execute tasks, submit work,
    and settle payments without human intervention.
    """

    def __init__(
        self,
        name: str,
        role: str = "Autonomous Agent",
        goal: str = "",
        backstory: str = "",
        agent_address: str = "",
        api_url: str = "https://api.kojiru.com",
        api_key: str = None,
        capabilities: list = None,
        staked_kojiru: float = 0,
    ):
        self.name = name
        self.role = role
        self.goal = goal
        self.backstory = backstory or f"{name} is a Kojiru-enabled autonomous agent with on-chain credit access."
        self.agent_address = agent_address
        self.capabilities = capabilities or []
        self.staked_kojiru = staked_kojiru

        # Initialize Kojiru credit
        if agent_address:
            self.init_credit(agent_address, api_url, api_key)

    @property
    def acs(self) -> dict:
        """Get current Agent Credit Score."""
        return self.credit.score()

    def draw(self, seller: str, amount: float, task: str, **kwargs) -> dict:
        """Shorthand: Draw credit into escrow for a task."""
        return self.credit.draw_credit(seller=seller, amount=amount, task=task, **kwargs)

    def pay(self, amount: float) -> dict:
        """Shorthand: Settle/repay credit."""
        return self.credit.settle(amount=amount)

    def submit(self, escrow_id: str, artifact_type: str = "work_output", content: dict = None) -> dict:
        """Shorthand: Submit work artifact for a task."""
        return self.credit.submit_artifact(escrow_id, artifact_type, content or {})

    def __repr__(self):
        return f"CreditAgent(name={self.name}, address={self.agent_address[:10]}...)"


def enable_crew_credit(crew, api_url: str = "https://api.kojiru.com", api_key: str = None):
    """
    Enable Kojiru credit on every agent in a CrewAI Crew.
    Each agent gets its own KojiruClient with its own ACS score.

    Args:
        crew: A CrewAI Crew object with .agents list
        api_url: Kojiru API URL
        api_key: Optional institutional API key

    Example:
        from crewai import Crew, Agent
        from kojiru.integrations.crewai_integration import enable_crew_credit

        crew = Crew(agents=[analyst, trader, auditor])
        enable_crew_credit(crew, api_url="https://api.kojiru.com")

        # Each agent now has .credit
        analyst.credit.draw_credit(...)
        trader.credit.score()
    """
    agents = getattr(crew, 'agents', [])
    for agent in agents:
        address = getattr(agent, 'agent_address', None) or getattr(agent, 'address', None)
        if address:
            agent.credit = KojiruClient(api_url=api_url, agent_address=address, api_key=api_key)
    return crew
