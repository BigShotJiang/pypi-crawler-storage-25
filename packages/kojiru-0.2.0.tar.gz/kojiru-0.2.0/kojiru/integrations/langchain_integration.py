"""
Kojiru x LangChain Integration
Adds Kojiru credit operations as native LangChain Tools.

Usage:
    from kojiru.integrations.langchain_integration import credit_tools, CreditAgentExecutor

    # Option 1: Get tools and add to your existing agent
    tools = credit_tools("0xAgent...", api_url="https://api.kojiru.com")
    agent = initialize_agent(tools + your_tools, llm, agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION)

    # Option 2: One-line credit-enabled agent
    agent = CreditAgentExecutor(
        agent_address="0xAgent...",
        api_url="https://api.kojiru.com",
        llm=ChatOpenAI(model="gpt-4"),
    )
    result = agent.run("Draw $500 credit for market analysis and submit the work")
"""
from kojiru import KojiruClient
from typing import Optional


class KojiruDrawCreditTool:
    """LangChain-compatible tool for drawing credit from Kojiru."""
    name = "kojiru_draw_credit"
    description = (
        "Draw credit from the Kojiru Agent Credit Protocol into an isolated escrow for a specific task. "
        "Input: JSON with 'seller' (address), 'amount' (USD float), 'task' (description string). "
        "Returns: escrow details including escrow_id."
    )

    def __init__(self, client: KojiruClient):
        self.client = client

    def run(self, seller: str, amount: float, task: str, **kwargs) -> dict:
        return self.client.draw_credit(seller=seller, amount=amount, task=task)

    def _run(self, tool_input: str) -> str:
        import json
        data = json.loads(tool_input) if isinstance(tool_input, str) else tool_input
        result = self.run(**data)
        return json.dumps(result)


class KojiruCheckScoreTool:
    """LangChain-compatible tool for checking agent credit score."""
    name = "kojiru_check_score"
    description = "Check this agent's current Agent Credit Score (ACS) and tier on the Kojiru protocol. No input required."

    def __init__(self, client: KojiruClient):
        self.client = client

    def run(self, *args, **kwargs) -> dict:
        return self.client.score()

    def _run(self, tool_input: str = "") -> str:
        import json
        return json.dumps(self.run())


class KojiruSubmitWorkTool:
    """LangChain-compatible tool for submitting completed work."""
    name = "kojiru_submit_work"
    description = (
        "Submit completed work for a Kojiru escrow task for evaluation. "
        "Input: JSON with 'escrow_id' (string) and optional 'evidence_hash' (IPFS hash)."
    )

    def __init__(self, client: KojiruClient):
        self.client = client

    def run(self, escrow_id: str, evidence_hash: str = None, **kwargs) -> dict:
        return self.client.submit_work(escrow_id, evidence_hash)

    def _run(self, tool_input: str) -> str:
        import json
        data = json.loads(tool_input) if isinstance(tool_input, str) else tool_input
        result = self.run(**data)
        return json.dumps(result)


class KojiruSettleTool:
    """LangChain-compatible tool for settling/repaying credit."""
    name = "kojiru_settle"
    description = "Repay outstanding credit on the Kojiru protocol. Input: JSON with 'amount' (USD float)."

    def __init__(self, client: KojiruClient):
        self.client = client

    def run(self, amount: float, **kwargs) -> dict:
        return self.client.settle(amount=amount)

    def _run(self, tool_input: str) -> str:
        import json
        data = json.loads(tool_input) if isinstance(tool_input, str) else tool_input
        result = self.run(**data)
        return json.dumps(result)


class KojiruSubmitArtifactTool:
    """LangChain-compatible tool for submitting reasoning artifacts."""
    name = "kojiru_submit_artifact"
    description = (
        "Submit a reasoning artifact for a completed task. This feeds the Kojiru Knowledge Graph. "
        "Input: JSON with 'escrow_id', 'artifact_type' (work_output|evaluator_insight|quality_attestation), "
        "and 'content' (dict with reasoning, domains, capabilities_demonstrated, insights)."
    )

    def __init__(self, client: KojiruClient):
        self.client = client

    def run(self, escrow_id: str, artifact_type: str = "work_output", content: dict = None, **kwargs) -> dict:
        return self.client.submit_artifact(escrow_id, artifact_type, content or {})

    def _run(self, tool_input: str) -> str:
        import json
        data = json.loads(tool_input) if isinstance(tool_input, str) else tool_input
        result = self.run(**data)
        return json.dumps(result)


class KojiruKnowledgeProfileTool:
    """LangChain-compatible tool for querying the agent's knowledge profile."""
    name = "kojiru_knowledge_profile"
    description = "Get this agent's knowledge profile from the Kojiru Knowledge Graph: domains, capabilities, quality scores. No input required."

    def __init__(self, client: KojiruClient):
        self.client = client

    def run(self, *args, **kwargs) -> dict:
        return self.client.knowledge_profile()

    def _run(self, tool_input: str = "") -> str:
        import json
        return json.dumps(self.run())


def credit_tools(agent_address: str, api_url: str = "https://api.kojiru.com", api_key: str = None) -> list:
    """
    Get Kojiru credit tools for LangChain.
    One line to add financial capabilities to any LangChain agent.

    Args:
        agent_address: Agent's Ethereum address
        api_url: Kojiru API URL
        api_key: Optional institutional API key

    Returns:
        List of LangChain-compatible tools

    Example:
        from kojiru.integrations.langchain_integration import credit_tools
        from langchain.agents import initialize_agent, AgentType

        tools = credit_tools("0xYourAgent...", api_url="https://api.kojiru.com")
        agent = initialize_agent(tools, llm, agent=AgentType.STRUCTURED_CHAT_ZERO_SHOT_REACT_DESCRIPTION)
    """
    client = KojiruClient(api_url=api_url, agent_address=agent_address, api_key=api_key)
    return [
        KojiruDrawCreditTool(client),
        KojiruCheckScoreTool(client),
        KojiruSubmitWorkTool(client),
        KojiruSettleTool(client),
        KojiruSubmitArtifactTool(client),
        KojiruKnowledgeProfileTool(client),
    ]
