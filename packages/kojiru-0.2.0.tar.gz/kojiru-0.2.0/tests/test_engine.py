"""
Tests for the AgentCredit engine — the partner-facing facade.
"""
import pytest
import responses

from kojiru import AgentCredit, CreditBinding, KojiruClient


class FakeCrewAIAgent:
    """Pydantic-v2-like class with extra='allow' (mirrors crewai.Agent)."""
    def __init__(self, role, goal, backstory, allow_delegation=False, tools=None, name=None):
        self.role = role
        self.goal = goal
        self.backstory = backstory
        self.allow_delegation = allow_delegation
        self.tools = tools or []
        if name:
            self.name = name


def test_agent_credit_requires_api_key():
    with pytest.raises(ValueError, match="api_key"):
        AgentCredit(api_key="")


def test_agent_credit_repr(mock_api_url):
    engine = AgentCredit(api_key="kj_test", api_url=mock_api_url)
    assert "AgentCredit" in repr(engine)
    assert "active_bindings=0" in repr(engine)


@responses.activate
def test_enable_credit_on_crewai_agent(mock_api_url):
    # Auto-register + apply_for_credit are called during enable_credit.
    responses.add(responses.POST, f"{mock_api_url}/api/agent-credit/agents/register",
                  json={"ok": True}, status=200)
    responses.add(responses.POST, f"{mock_api_url}/api/agent-credit/credit/apply",
                  json={"ok": True}, status=200)

    engine = AgentCredit(api_key="kj_test", api_url=mock_api_url)
    agent = FakeCrewAIAgent(
        role="Marketing Manager",
        goal="Execute ad spend autonomously",
        backstory="Expert in ROI-driven campaigns",
        allow_delegation=True,
    )
    binding = engine.enable_credit(agent, limit=10_000)

    # Binding returned correctly
    assert isinstance(binding, CreditBinding)
    assert binding.limit_usd == 10_000
    assert binding.role == "Marketing Manager"
    assert binding.address.startswith("0x")
    assert len(binding.address) == 42  # 0x + 40 hex chars

    # Attributes mirrored onto the agent
    assert isinstance(agent.credit, KojiruClient)
    assert agent.kojiru_binding is binding
    assert callable(agent.draw)
    assert callable(agent.pay)
    assert callable(agent.submit)

    # Engine tracks the binding
    assert engine.binding_for(agent) is binding


@responses.activate
def test_enable_credit_enforces_limit(mock_api_url):
    responses.add(responses.POST, f"{mock_api_url}/api/agent-credit/agents/register", json={}, status=200)
    responses.add(responses.POST, f"{mock_api_url}/api/agent-credit/credit/apply", json={}, status=200)

    engine = AgentCredit(api_key="kj_test", api_url=mock_api_url)
    agent = FakeCrewAIAgent(role="Limited Analyst", goal="Stay small", backstory="Junior")
    binding = engine.enable_credit(agent, limit=500)

    # Amount under limit: no exception raised (we stub the backend call)
    responses.add(responses.POST, f"{mock_api_url}/api/agent-credit/escrow/draw",
                  json={"escrow_id": "esc_ok"}, status=200)
    result = binding.draw(seller="0xSeller", amount=499, task="Small task")
    assert result["escrow_id"] == "esc_ok"

    # Amount over limit: ValueError before any network call
    with pytest.raises(ValueError, match="exceeds agent credit limit"):
        binding.draw(seller="0xSeller", amount=501, task="Too big")


@responses.activate
def test_enable_credit_survives_failed_auto_register(mock_api_url):
    """Auto-register failures should not break binding creation."""
    responses.add(responses.POST, f"{mock_api_url}/api/agent-credit/agents/register",
                  json={"detail": "already registered"}, status=400)
    responses.add(responses.POST, f"{mock_api_url}/api/agent-credit/credit/apply",
                  json={"detail": "already has credit line"}, status=400)

    engine = AgentCredit(api_key="kj_test", api_url=mock_api_url)
    agent = FakeCrewAIAgent(role="Returning Agent", goal="Resume work", backstory="Seen it all")
    binding = engine.enable_credit(agent, limit=5_000)
    assert binding.limit_usd == 5_000


def test_enable_credit_with_explicit_address_and_no_autoregister(mock_api_url, fake_address):
    engine = AgentCredit(api_key="kj_test", api_url=mock_api_url)
    agent = FakeCrewAIAgent(role="External Agent", goal="x", backstory="y")
    binding = engine.enable_credit(
        agent, limit=1_000, address=fake_address, auto_register=False
    )
    assert binding.address == fake_address


def test_enable_credit_derives_deterministic_address(mock_api_url):
    engine = AgentCredit(api_key="kj_test", api_url=mock_api_url)
    a1 = FakeCrewAIAgent(role="Same", goal="Same", backstory="Same")
    a2 = FakeCrewAIAgent(role="Same", goal="Same", backstory="Same")
    b1 = engine.enable_credit(a1, limit=1_000, auto_register=False)
    b2 = engine.enable_credit(a2, limit=1_000, auto_register=False)
    assert b1.address == b2.address  # Deterministic derivation


def test_enable_credit_infers_capabilities_from_tools(mock_api_url):
    class Tool:
        def __init__(self, name): self.name = name

    engine = AgentCredit(api_key="kj_test", api_url=mock_api_url)
    agent = FakeCrewAIAgent(
        role="Analyst", goal="Research", backstory="PhD",
        tools=[Tool("web_search"), Tool("code_interpreter")],
    )
    binding = engine.enable_credit(agent, limit=1_000, auto_register=False)
    # Capabilities were inferred from the tool names
    assert binding.role == "Analyst"


def test_kojiru_sdk_alias_import():
    """The partner snippet `from kojiru_sdk import AgentCredit` must work."""
    from kojiru_sdk import AgentCredit as AC_alias, KojiruClient as KC_alias
    assert AC_alias is AgentCredit
    assert KC_alias is KojiruClient
