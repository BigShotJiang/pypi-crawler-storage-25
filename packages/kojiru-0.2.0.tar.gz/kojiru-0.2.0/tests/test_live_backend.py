"""
Live integration smoke tests — hits the local Kojiru backend (not mocked).
Skipped automatically when the backend is unreachable.
"""
import pytest
import requests
from kojiru import KojiruClient


def _backend_up(url: str) -> bool:
    try:
        r = requests.get(f"{url}/api/agent-credit/stats", timeout=2)
        return r.status_code == 200
    except Exception:
        return False


@pytest.fixture
def live_client(local_api_url, fake_address):
    if not _backend_up(local_api_url):
        pytest.skip("Local Kojiru backend not running on :8001")
    return KojiruClient(api_url=local_api_url, agent_address=fake_address)


def test_live_stats(live_client):
    data = live_client.stats()
    assert "total_registered_agents" in data
    assert data["total_registered_agents"] >= 0


def test_live_domains_endpoint(live_client):
    data = live_client.domains()
    # Should return a list or dict; not raise
    assert data is not None
