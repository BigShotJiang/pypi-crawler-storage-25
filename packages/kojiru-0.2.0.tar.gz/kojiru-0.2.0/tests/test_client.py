"""
Unit tests for the core KojiruClient.
Uses `responses` to mock HTTP — does not hit any network.
"""
import json
import pytest
import responses
from kojiru import KojiruClient, KojiruError


@responses.activate
def test_client_stats(mock_api_url, fake_address):
    responses.add(
        responses.GET,
        f"{mock_api_url}/api/agent-credit/stats",
        json={"total_registered_agents": 12, "active_credit_lines": 5},
        status=200,
    )
    client = KojiruClient(api_url=mock_api_url, agent_address=fake_address)
    data = client.stats()
    assert data["total_registered_agents"] == 12


@responses.activate
def test_client_draw_credit(mock_api_url, fake_address, seller_address):
    responses.add(
        responses.POST,
        f"{mock_api_url}/api/agent-credit/escrow/draw",
        json={"escrow_id": "esc_123", "status": "funded"},
        status=200,
    )
    client = KojiruClient(api_url=mock_api_url, agent_address=fake_address)
    result = client.draw_credit(seller=seller_address, amount=500, task="Market scan")
    assert result["escrow_id"] == "esc_123"

    # Verify the payload shape
    body = json.loads(responses.calls[0].request.body)
    assert body["agent_address"] == fake_address
    assert body["seller_address"] == seller_address
    assert body["amount"] == 500
    assert body["task_description"] == "Market scan"


@responses.activate
def test_client_submit_artifact(mock_api_url, fake_address):
    responses.add(
        responses.POST,
        f"{mock_api_url}/api/agent-credit/artifacts/submit",
        json={"artifact_id": "art_42", "ipfs_cid": "bafk..."},
        status=200,
    )
    client = KojiruClient(api_url=mock_api_url, agent_address=fake_address)
    result = client.submit_artifact(
        escrow_id="esc_123",
        artifact_type="work_output",
        content={"reasoning": "...", "domains": ["defi"]},
    )
    assert result["artifact_id"] == "art_42"


@responses.activate
def test_client_error_raises(mock_api_url, fake_address):
    responses.add(
        responses.POST,
        f"{mock_api_url}/api/agent-credit/escrow/draw",
        json={"detail": "Agent not registered"},
        status=400,
    )
    client = KojiruClient(api_url=mock_api_url, agent_address=fake_address)
    with pytest.raises(KojiruError) as exc:
        client.draw_credit(seller="0xBEEF", amount=100, task="x")
    assert exc.value.status_code == 400
    assert "not registered" in exc.value.message


def test_client_api_key_header(mock_api_url, fake_address):
    client = KojiruClient(api_url=mock_api_url, agent_address=fake_address, api_key="sk_inst_xyz")
    assert client._session.headers.get("X-API-Key") == "sk_inst_xyz"


def test_client_repr(mock_api_url, fake_address):
    client = KojiruClient(api_url=mock_api_url, agent_address=fake_address)
    assert "KojiruClient" in repr(client)
    assert fake_address[:10] in repr(client)
