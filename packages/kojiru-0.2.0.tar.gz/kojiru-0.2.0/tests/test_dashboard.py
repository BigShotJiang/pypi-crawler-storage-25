"""
Smoke tests for the CrewAI Credit Dashboard module.

These validate that the dashboard imports cleanly and its data-layer
helpers work correctly. The Streamlit UI itself is tested visually in
the browser (not unit-testable without a Streamlit runtime).
"""
import os
import subprocess
import sys
import pytest
import responses


def test_dashboard_module_path_exists():
    """The dashboard file must be discoverable by streamlit."""
    import kojiru_sdk
    dash_path = os.path.join(os.path.dirname(kojiru_sdk.__file__), "dashboard.py")
    assert os.path.isfile(dash_path), f"dashboard.py not found at {dash_path}"


def test_main_entry_exists():
    """`python -m kojiru_sdk` must be a valid entry point."""
    import kojiru_sdk
    main_path = os.path.join(os.path.dirname(kojiru_sdk.__file__), "__main__.py")
    assert os.path.isfile(main_path), f"__main__.py not found at {main_path}"


def test_dashboard_script_syntax_valid():
    """Dashboard file must compile without syntax errors."""
    import kojiru_sdk
    dash_path = os.path.join(os.path.dirname(kojiru_sdk.__file__), "dashboard.py")
    result = subprocess.run(
        [sys.executable, "-m", "py_compile", dash_path],
        capture_output=True, text=True,
    )
    assert result.returncode == 0, f"Syntax error in dashboard.py: {result.stderr}"


def test_dashboard_uses_kojiru_sdk_public_api():
    """Dashboard must only rely on documented public SDK surface."""
    import kojiru_sdk
    dash_path = os.path.join(os.path.dirname(kojiru_sdk.__file__), "dashboard.py")
    with open(dash_path) as f:
        src = f.read()
    # Imports the documented engine/client
    assert "from kojiru import" in src
    assert "KojiruClient" in src
    assert "AgentCredit" in src
    # Does not leak private internals
    assert "_request" not in src
    assert "_bindings" not in src


@responses.activate
def test_live_backend_fetch_with_mock():
    """Validate that the dashboard's data fetcher would work against a live backend."""
    from kojiru import KojiruClient

    mock_url = "https://api.kojiru.test"
    addr = "0x" + "a" * 40

    responses.add(
        responses.GET,
        f"{mock_url}/api/agent-credit/agents/{addr}",
        json={"credit_score": {"acs": 742, "tier": "A"}, "address": addr},
        status=200,
    )
    responses.add(
        responses.GET,
        f"{mock_url}/api/agent-credit/escrow/agent/{addr}?limit=20",
        json={"escrows": [{"amount": 500, "status": "funded", "task": "x"}]},
        status=200,
    )
    responses.add(
        responses.GET,
        f"{mock_url}/api/agent-credit/artifacts/agent/{addr}?limit=20",
        json={"artifacts": []},
        status=200,
    )

    client = KojiruClient(api_url=mock_url, agent_address=addr)
    profile = client.profile()
    escrows = client.escrows(limit=20)
    artifacts = client.artifacts(limit=20)

    assert profile["credit_score"]["acs"] == 742
    assert len(escrows["escrows"]) == 1
    assert escrows["escrows"][0]["amount"] == 500
    assert artifacts["artifacts"] == []
