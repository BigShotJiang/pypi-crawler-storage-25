"""
Unit tests for framework integration wrappers.
Validates that the 1-line `enable_credit` story actually works for every framework.
"""
import json
import pytest
import responses

from kojiru import KojiruClient
from kojiru.integrations import enable_credit, CreditMixin
from kojiru.integrations import langchain as kojiru_lc
from kojiru.integrations import crewai as kojiru_crew
from kojiru.integrations import autogpt as kojiru_autogpt


# ──────────────── Core enable_credit() ────────────────

def test_enable_credit_attaches_client_to_any_object(mock_api_url, fake_address):
    class DummyAgent:
        pass

    agent = DummyAgent()
    client = enable_credit(agent, address=fake_address, api_url=mock_api_url)

    assert isinstance(client, KojiruClient)
    assert agent.credit is client
    assert agent.credit.agent_address == fake_address


def test_credit_mixin_initialization(mock_api_url, fake_address):
    class MyAgent(CreditMixin):
        def __init__(self, address):
            self.init_credit(address, api_url=mock_api_url)

    agent = MyAgent(fake_address)
    assert isinstance(agent.credit, KojiruClient)
    assert agent.credit.agent_address == fake_address


def test_credit_mixin_raises_if_not_initialized():
    class MyAgent(CreditMixin):
        pass

    agent = MyAgent()
    with pytest.raises(RuntimeError, match="Credit not initialized"):
        _ = agent.credit


# ──────────────── LangChain ────────────────

def test_langchain_credit_tools_returns_six_tools(mock_api_url, fake_address):
    tools = kojiru_lc.credit_tools(agent_address=fake_address, api_url=mock_api_url)
    names = [t.name for t in tools]
    assert len(tools) == 6
    assert "kojiru_draw_credit" in names
    assert "kojiru_check_score" in names
    assert "kojiru_submit_work" in names
    assert "kojiru_settle" in names
    assert "kojiru_submit_artifact" in names
    assert "kojiru_knowledge_profile" in names
    for t in tools:
        assert t.description  # every tool must expose a description for the LLM


@responses.activate
def test_langchain_draw_tool_hits_backend(mock_api_url, fake_address, seller_address):
    responses.add(
        responses.POST,
        f"{mock_api_url}/api/agent-credit/escrow/draw",
        json={"escrow_id": "esc_lc_1"},
        status=200,
    )
    tools = kojiru_lc.credit_tools(agent_address=fake_address, api_url=mock_api_url)
    draw_tool = next(t for t in tools if t.name == "kojiru_draw_credit")

    # LangChain invokes `_run` with a JSON string
    raw = draw_tool._run(json.dumps({
        "seller": seller_address,
        "amount": 250,
        "task": "Vulnerability scan",
    }))
    assert "esc_lc_1" in raw


# ──────────────── CrewAI ────────────────

def test_crewai_credit_agent_has_native_helpers(mock_api_url, fake_address):
    agent = kojiru_crew.CreditAgent(
        name="AlphaTrader",
        role="DeFi Analyst",
        goal="Find alpha",
        agent_address=fake_address,
        api_url=mock_api_url,
    )
    assert agent.name == "AlphaTrader"
    assert isinstance(agent.credit, KojiruClient)
    # Backstory auto-fills when not provided
    assert "Kojiru" in agent.backstory


@responses.activate
def test_crewai_draw_shorthand(mock_api_url, fake_address, seller_address):
    responses.add(
        responses.POST,
        f"{mock_api_url}/api/agent-credit/escrow/draw",
        json={"escrow_id": "esc_crew_99"},
        status=200,
    )
    agent = kojiru_crew.CreditAgent(
        name="Crew1",
        agent_address=fake_address,
        api_url=mock_api_url,
    )
    result = agent.draw(seller=seller_address, amount=100, task="Audit")
    assert result["escrow_id"] == "esc_crew_99"


def test_enable_crew_credit_wraps_every_agent(mock_api_url, fake_address):
    class FakeAgent:
        def __init__(self, addr):
            self.agent_address = addr

    class FakeCrew:
        def __init__(self, agents):
            self.agents = agents

    crew = FakeCrew(agents=[FakeAgent(fake_address), FakeAgent(fake_address[:-1] + "F")])
    kojiru_crew.enable_crew_credit(crew, api_url=mock_api_url)

    for a in crew.agents:
        assert isinstance(a.credit, KojiruClient)


# ──────────────── AutoGPT ────────────────

def test_autogpt_plugin_exposes_five_commands(mock_api_url, fake_address):
    plugin = kojiru_autogpt.KojiruPlugin(agent_address=fake_address, api_url=mock_api_url)
    cmds = plugin.commands()
    names = [c["name"] for c in cmds]
    assert len(cmds) == 5
    assert set(names) == {
        "kojiru_draw", "kojiru_score", "kojiru_settle",
        "kojiru_submit", "kojiru_profile",
    }
    for c in cmds:
        assert callable(c["handler"])
        assert c["description"]


@responses.activate
def test_autogpt_handler_executes(mock_api_url, fake_address):
    responses.add(
        responses.GET,
        f"{mock_api_url}/api/agent-credit/agents/{fake_address}",
        json={"credit_score": {"acs": 725, "tier": "A"}},
        status=200,
    )
    plugin = kojiru_autogpt.KojiruPlugin(agent_address=fake_address, api_url=mock_api_url)
    score_cmd = next(c for c in plugin.commands() if c["name"] == "kojiru_score")
    result = score_cmd["handler"]()
    assert result["acs"] == 725


def test_enable_autogpt_credit_attaches_both(mock_api_url, fake_address):
    class FakeAutoGPT:
        pass

    agent = FakeAutoGPT()
    kojiru_autogpt.enable_autogpt_credit(agent, address=fake_address, api_url=mock_api_url)
    assert isinstance(agent.credit, KojiruClient)
    assert isinstance(agent.kojiru_plugin, kojiru_autogpt.KojiruPlugin)
