"""old_oven: code-generation wrapper around HyperNix.

The oven metaphor: a raw HuggingFace snapshot is dough. :func:`preheat`
downloads / loads it into a fully-ready :class:`CodeOven` you can bake
code out of — low-temperature sampling defaults, stop-sequence awareness,
and an optional fill-in-the-middle API for code infilling tasks.

Typical use (Python)::

    from hypernix import old_oven

    oven = old_oven.preheat("ray0rf1re/hyper-nix.1")
    print(oven.complete("def fibonacci(n):"))
    print(oven.fill(prefix="def add(a, b):\\n    return ",
                    suffix="\\n\\nresult = add(1, 2)"))
    oven.save_pt("./hypernix.pt")   # self-contained torch.load()-able bundle

Typical use (CLI)::

    hypernix --auto-oven --prompt "def fib(n):"
    hypernix oven --model-dir ./snapshot --prompt "def fib(n):"
    hypernix oven --model-dir ./snapshot --fill-prefix "def add(a,b):\\n    return " \\
                                         --fill-suffix "\\n\\nprint(add(1,2))"
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn

from .download import download_model, verify_snapshot
from .generate import _load_tokenizer, _sample_next
from .train import (
    HyperNixConfig,
    HyperNixModel,
    _iter_chunks,
    init_from_scratch,
    load_snapshot,
    save_snapshot,
)

# Heuristic stop strings we trim off a code completion. Users can pass an
# explicit `stop=...` to override; set `stop=()` to disable trimming.
DEFAULT_STOPS: tuple[str, ...] = ("\nclass ", "\ndef ", "\n\n\n", "</s>")

# FIM tokens used by the common "starcoder-style" convention; generate.fill()
# falls back to plain prefix-only continuation if these aren't in the vocab.
_FIM_PREFIX = "<fim_prefix>"
_FIM_SUFFIX = "<fim_suffix>"
_FIM_MIDDLE = "<fim_middle>"


# ---------------------------------------------------------------------------
# Architecture presets
# ---------------------------------------------------------------------------
# The HyperNix model class is a parametric Llama-style causal LM. By flipping
# a handful of config knobs it can also be used as the Qwen2 / Qwen2.5
# architecture: the only structural difference is that Qwen2 places a bias on
# q_proj / k_proj / v_proj (but not o_proj). Defaults also differ for
# rope_theta and the RMSNorm epsilon. These presets encode those differences
# so callers can request either architecture by name.
ARCH_PRESETS: dict[str, dict[str, Any]] = {
    "hypernix": {
        "attention_bias": False,
        "model_type": "hypernix",
        "rope_theta": 10000.0,
        "rms_norm_eps": 1e-5,
        "tie_word_embeddings": False,
    },
    "qwen2": {
        "attention_bias": True,
        "model_type": "qwen2",
        "rope_theta": 1000000.0,
        "rms_norm_eps": 1e-6,
        "tie_word_embeddings": True,
    },
    # Alias so users can spell the arch the way Qwen2.5 is marketed.
    "qwen2.5": {
        "attention_bias": True,
        "model_type": "qwen2",
        "rope_theta": 1000000.0,
        "rms_norm_eps": 1e-6,
        "tie_word_embeddings": True,
    },
}


def _dtype_from_str(name: str) -> torch.dtype:
    return {"float32": torch.float32, "float16": torch.float16, "bfloat16": torch.bfloat16}[name]


def _trim_at_stop(text: str, stops: tuple[str, ...]) -> str:
    if not stops:
        return text
    earliest = len(text)
    for s in stops:
        idx = text.find(s)
        if idx >= 0:
            earliest = min(earliest, idx)
    return text[:earliest]


@dataclass
class CodeOven:
    """A loaded HyperNix-family model + tokenizer ready for generation.

    Returned by :func:`preheat`. Safe to reuse across many generate calls —
    the model is loaded once and kept resident on ``device``.

    ``model`` is typed as :class:`torch.nn.Module` so the oven can also
    host non-HyperNix architectures loaded via :func:`hypernix.train.load_snapshot`
    — currently ``NanoNanoModel`` from :mod:`hypernix.nano_nano`. Both
    classes share the same forward signature
    (``forward(input_ids, labels=None) -> {"logits": ..., "loss": ...}``)
    and expose a ``config`` attribute with ``max_position_embeddings`` and
    ``model_type``, which is all this class relies on.
    """

    model: nn.Module
    tokenizer: Any
    tokenizer_kind: str  # "hf" or "byte"
    device: torch.device
    dtype: torch.dtype
    model_dir: Path

    # ------------------------------------------------------------------
    # Tokenizer helpers
    # ------------------------------------------------------------------

    def _encode(self, text: str) -> list[int]:
        if self.tokenizer_kind == "hf":
            return list(self.tokenizer.encode(text, add_special_tokens=False))
        return self.tokenizer.encode(text)

    def _decode(self, ids: list[int]) -> str:
        if self.tokenizer_kind == "hf":
            return self.tokenizer.decode(ids, skip_special_tokens=True)
        return self.tokenizer.decode(ids)

    def _fim_token_id(self, marker: str) -> int | None:
        if self.tokenizer_kind != "hf":
            return None
        tid = self.tokenizer.convert_tokens_to_ids(marker)
        # HF returns `unk_token_id` (or a bare int like 0/None) on miss;
        # treat anything falling back to the unk token as "not present".
        unk = getattr(self.tokenizer, "unk_token_id", None)
        if tid is None or (unk is not None and tid == unk):
            return None
        return int(tid)

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------

    @torch.no_grad()
    def _run(
        self,
        input_ids: list[int],
        *,
        max_new_tokens: int,
        temperature: float,
        top_k: int,
        top_p: float,
        eos_ids: tuple[int, ...] = (),
    ) -> list[int]:
        ctx = torch.tensor([input_ids], dtype=torch.long, device=self.device)
        max_ctx = self.model.config.max_position_embeddings
        generated: list[int] = []
        for _ in range(max_new_tokens):
            if ctx.size(1) > max_ctx:
                ctx = ctx[:, -max_ctx:]
            logits = self.model(ctx)["logits"][:, -1, :].float()
            nxt = _sample_next(
                logits[0], temperature=temperature, top_k=top_k, top_p=top_p,
            )
            tok = int(nxt.item())
            generated.append(tok)
            if tok in eos_ids:
                break
            ctx = torch.cat([ctx, nxt.view(1, 1)], dim=1)
        return generated

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def complete(
        self,
        prompt: str,
        *,
        max_new_tokens: int = 256,
        temperature: float = 0.2,
        top_k: int = 40,
        top_p: float = 0.95,
        stop: tuple[str, ...] = DEFAULT_STOPS,
        seed: int | None = None,
    ) -> str:
        """Continue ``prompt`` as code.

        Defaults favour code generation: low temperature, moderate top-p,
        and a stop-sequence trimmer that cuts the output at the first
        ``\\nclass `` / ``\\ndef `` boundary so you usually get one
        function back rather than a whole file.
        """
        if seed is not None:
            torch.manual_seed(seed)

        ids = self._encode(prompt) if prompt else []
        bos = getattr(self.tokenizer, "bos_token_id", None) if self.tokenizer_kind == "hf" else None
        if bos is not None and (not ids or ids[0] != bos):
            ids = [bos, *ids]
        if not ids:
            ids = [0]

        eos: tuple[int, ...] = ()
        if self.tokenizer_kind == "hf":
            eid = getattr(self.tokenizer, "eos_token_id", None)
            if isinstance(eid, int):
                eos = (eid,)

        out_ids = self._run(
            ids,
            max_new_tokens=max_new_tokens,
            temperature=temperature, top_k=top_k, top_p=top_p,
            eos_ids=eos,
        )
        new_text = self._decode(out_ids)
        return _trim_at_stop(new_text, stop)

    def fill(
        self,
        prefix: str,
        suffix: str,
        *,
        max_new_tokens: int = 128,
        temperature: float = 0.2,
        top_k: int = 40,
        top_p: float = 0.95,
        seed: int | None = None,
    ) -> str:
        """Fill-in-the-middle: generate text that fits between ``prefix``
        and ``suffix``.

        Uses the starcoder-style ``<fim_prefix> ... <fim_suffix> ... <fim_middle>``
        convention when the tokenizer has those special tokens; otherwise
        falls back to prefix-only completion (ignoring ``suffix``). Useful
        for editor-style code infilling.
        """
        if seed is not None:
            torch.manual_seed(seed)

        pre_id = self._fim_token_id(_FIM_PREFIX)
        suf_id = self._fim_token_id(_FIM_SUFFIX)
        mid_id = self._fim_token_id(_FIM_MIDDLE)

        if pre_id is not None and suf_id is not None and mid_id is not None:
            ids = [pre_id, *self._encode(prefix), suf_id, *self._encode(suffix), mid_id]
        else:
            # Graceful fallback: ignore the suffix and continue the prefix.
            # Users can detect this by comparing the tokenizer vocabulary.
            ids = self._encode(prefix) or [0]

        out_ids = self._run(
            ids,
            max_new_tokens=max_new_tokens,
            temperature=temperature, top_k=top_k, top_p=top_p,
        )
        return self._decode(out_ids)

    # ------------------------------------------------------------------
    # Chat
    # ------------------------------------------------------------------

    def _format_chat(self, messages: list[dict[str, str]]) -> list[int]:
        """Render a list of ``{role, content}`` messages into token ids.

        Preference order:
        1. ``tokenizer.apply_chat_template`` when the HF tokenizer has one
           wired up (this is what ``nano-nano-v4`` and ``nano-mini`` ship
           with, so we get the canonical Llama/Qwen chat format for free).
        2. A plain ``role: content`` transcript with an ``assistant:``
           suffix — works with any tokenizer, including the byte fallback.
        """
        if self.tokenizer_kind == "hf":
            apply = getattr(self.tokenizer, "apply_chat_template", None)
            tmpl = getattr(self.tokenizer, "chat_template", None)
            if callable(apply) and tmpl:
                ids = apply(
                    messages, tokenize=True, add_generation_prompt=True,
                )
                return list(ids)

        parts: list[str] = []
        for m in messages:
            parts.append(f"{m['role']}: {m['content']}")
        parts.append("assistant:")
        return self._encode("\n".join(parts))

    def chat(
        self,
        messages: list[dict[str, str]],
        *,
        max_new_tokens: int = 256,
        temperature: float = 0.7,
        top_k: int = 40,
        top_p: float = 0.95,
        seed: int | None = None,
    ) -> str:
        """Run a chat turn. ``messages`` is a list of ``{"role", "content"}``.

        Works with all three new HyperNix-family models:

        * ``Nano-nano-v4`` and ``Nano-mini-6.99-v2`` ship a HF Llama-style
          chat template, so ``apply_chat_template`` takes the fast path.
        * ``nano-nano-927-v3`` / HyperNix v1 / freshly-initialized ovens
          don't — those fall back to a simple ``role: content`` transcript.

        Defaults use ``temperature=0.7`` (chat-typical), higher than the
        code-completion default of 0.2.
        """
        if seed is not None:
            torch.manual_seed(seed)

        ids = self._format_chat(messages)
        if not ids:
            ids = [0]

        eos: tuple[int, ...] = ()
        if self.tokenizer_kind == "hf":
            eid = getattr(self.tokenizer, "eos_token_id", None)
            if isinstance(eid, int):
                eos = (eid,)

        out_ids = self._run(
            ids,
            max_new_tokens=max_new_tokens,
            temperature=temperature, top_k=top_k, top_p=top_p,
            eos_ids=eos,
        )
        return self._decode(out_ids)

    # ------------------------------------------------------------------
    # Training
    # ------------------------------------------------------------------

    def train(
        self,
        dataset_path: Path | str,
        out_dir: Path | str | None = None,
        *,
        steps: int = 1000,
        batch_size: int = 2,
        context_length: int = 512,
        lr: float = 3e-4,
        weight_decay: float = 0.1,
        grad_clip: float = 1.0,
        log_every: int = 10,
        save_every: int = 500,
        seed: int | None = None,
        quiet: bool = False,
    ) -> Path:
        """Continue-pretrain this oven on a raw-text file.

        Works for both architectures (HyperNix and Qwen2/Qwen2.5) — the
        underlying model class is the same, the preset just flips
        ``attention_bias`` and a few hyperparameters. Uses the snapshot's
        HF tokenizer if one is present, otherwise falls back to the
        byte-level tokenizer so the training loop is always runnable
        (handy for smoke-testing / CI).

        Args:
            dataset_path: Path to a raw-text file.
            out_dir: Where to save the trained snapshot. Defaults to
                ``<model_dir>-trained`` next to the current model dir.
            steps, batch_size, context_length, lr, weight_decay, grad_clip:
                Standard training knobs.
            log_every, save_every: Console / checkpoint cadence.
            seed: Optional torch seed for reproducible runs.
            quiet: Suppress per-step logging.

        Returns:
            Path to the written snapshot directory (a HF-style snapshot
            that feeds straight back into ``preheat(local_dir=...)``).
        """
        import math

        dataset_path = Path(dataset_path)
        if out_dir is None:
            out = self.model_dir.parent / (self.model_dir.name + "-trained")
        else:
            out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)

        if seed is not None:
            torch.manual_seed(seed)

        # Training mode may run in a higher-precision path than the
        # generation dtype; keep the user's dtype but flip on train().
        self.model.train()

        bos_id: int | None = None
        if self.tokenizer_kind == "hf":
            bos_id = getattr(self.tokenizer, "bos_token_id", None)

        chunks = list(
            _iter_chunks(dataset_path, self.tokenizer, context_length, bos_id=bos_id)
        )
        if not chunks:
            raise RuntimeError(
                f"dataset {dataset_path} produced no training chunks "
                f"(needs > context_length={context_length} tokens)"
            )

        opt = torch.optim.AdamW(
            self.model.parameters(), lr=lr, weight_decay=weight_decay, betas=(0.9, 0.95),
        )
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(1, steps))

        step = 0
        while step < steps:
            batch = torch.stack([
                chunks[(step * batch_size + i) % len(chunks)] for i in range(batch_size)
            ]).to(self.device)
            inputs = batch[:, :-1]
            labels = batch[:, 1:]
            out_dict = self.model(inputs, labels=labels)
            loss = out_dict["loss"]

            opt.zero_grad(set_to_none=True)
            loss.backward()
            if grad_clip:
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), grad_clip)
            opt.step()
            sched.step()
            step += 1

            if not quiet and step % log_every == 0:
                ppl = math.exp(min(loss.item(), 20))
                print(
                    f"[old_oven.train] arch={self.model.config.model_type} "
                    f"step {step}/{steps}  loss={loss.item():.4f}  ppl={ppl:.2f}"
                )
            if save_every and step % save_every == 0:
                save_snapshot(self.model, out, tokenizer_source=self.model_dir)

        save_snapshot(self.model, out, tokenizer_source=self.model_dir)
        self.model.eval()
        # Point the oven at the newly-saved snapshot so subsequent
        # .save_pt() / re-preheat calls pick up the trained weights.
        self.model_dir = out
        return out

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save_pt(self, out_path: Path | str) -> Path:
        """Save a self-contained ``torch.load``-able bundle to ``out_path``.

        The resulting ``.pt`` contains ``config`` (dict), ``state_dict``,
        and the source ``model_dir`` for later tokenizer recovery — so
        callers can ship a single file around and reconstruct the model
        with :func:`load_pt`.
        """
        out_path = Path(out_path)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        bundle = {
            "hypernix_format_version": 1,
            "config": self.model.config.to_dict(),
            "state_dict": {k: v.detach().cpu() for k, v in self.model.state_dict().items()},
            "source_model_dir": str(self.model_dir),
        }
        torch.save(bundle, out_path)
        return out_path


# ---------------------------------------------------------------------------
# Top-level functional API
# ---------------------------------------------------------------------------

def preheat(
    repo_id: str = "ray0rf1re/hyper-nix.1",
    *,
    local_dir: Path | str | None = None,
    revision: str | None = None,
    token: str | None = None,
    device: str | None = None,
    dtype: str = "float32",
    quiet: bool = False,
) -> CodeOven:
    """Download (if necessary) + load a HyperNix snapshot into a ``CodeOven``.

    If ``local_dir`` already contains a valid snapshot (``config.json`` +
    weights), no network call is made; otherwise the snapshot is fetched
    from the HF Hub. This is the one-call "get me a working PyTorch model
    right now" entry point; pairs with ``hypernix --auto-oven`` on the CLI.
    """
    path: Path
    if local_dir is not None:
        ld = Path(local_dir)
        try:
            if ld.exists():
                verify_snapshot(ld)
                path = ld
            else:
                raise FileNotFoundError(ld)
        except FileNotFoundError:
            path = download_model(
                repo_id=repo_id, revision=revision,
                local_dir=str(ld), token=token, quiet=quiet,
            )
    else:
        path = download_model(
            repo_id=repo_id, revision=revision, token=token, quiet=quiet,
        )

    model, _cfg = load_snapshot(path)
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    tdtype = _dtype_from_str(dtype)
    model.to(dev, dtype=tdtype)
    model.eval()

    tok, kind = _load_tokenizer(path)
    return CodeOven(
        model=model, tokenizer=tok, tokenizer_kind=kind,
        device=dev, dtype=tdtype, model_dir=path,
    )


def new_oven(
    out_dir: Path | str,
    *,
    arch: str = "hypernix",
    vocab_size: int = 32000,
    hidden_size: int = 1024,
    intermediate_size: int = 4096,
    num_hidden_layers: int = 16,
    num_attention_heads: int = 16,
    num_key_value_heads: int | None = None,
    max_position_embeddings: int = 2048,
    tokenizer_source: Path | str | None = None,
    device: str | None = None,
    dtype: str = "float32",
    seed: int | None = None,
) -> CodeOven:
    """Create a new untrained oven in HyperNix or Qwen2 (Qwen2.5) architecture.

    Writes a fresh HuggingFace-style snapshot at ``out_dir`` (so the model
    can be re-loaded from disk later), then returns a :class:`CodeOven`
    pointing at it. The returned oven is ready for ``.train(...)``.

    Args:
        out_dir: Where to write the new snapshot.
        arch: ``"hypernix"`` (default) or ``"qwen2"`` / ``"qwen2.5"``.
            The Qwen presets enable q/k/v bias, switch ``model_type`` to
            ``"qwen2"``, and use Qwen's canonical rope/eps defaults.
        vocab_size, hidden_size, ... max_position_embeddings: Standard
            causal-LM shape knobs.
        tokenizer_source: Existing snapshot to copy tokenizer files from.
            If omitted, the snapshot has no HF tokenizer and training /
            generation falls back to the byte-level tokenizer.
        device, dtype: Runtime placement for the returned oven.
        seed: Optional torch seed for reproducible initialization.

    Returns:
        A trainable :class:`CodeOven`. Call ``.train(dataset_path, ...)``
        to pretrain, then ``.complete(...)`` / ``.fill(...)`` as usual.
    """
    if arch not in ARCH_PRESETS:
        raise ValueError(
            f"unknown arch {arch!r}; choose from {sorted(ARCH_PRESETS)}"
        )
    preset = ARCH_PRESETS[arch]
    cfg = HyperNixConfig(
        vocab_size=vocab_size,
        hidden_size=hidden_size,
        intermediate_size=intermediate_size,
        num_hidden_layers=num_hidden_layers,
        num_attention_heads=num_attention_heads,
        num_key_value_heads=num_key_value_heads,
        max_position_embeddings=max_position_embeddings,
        **preset,
    )
    path = init_from_scratch(
        out_dir, cfg, tokenizer_source=tokenizer_source, seed=seed,
    )

    model, _ = load_snapshot(path)
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    tdtype = _dtype_from_str(dtype)
    model.to(dev, dtype=tdtype)
    model.eval()

    tok, kind = _load_tokenizer(path)
    return CodeOven(
        model=model, tokenizer=tok, tokenizer_kind=kind,
        device=dev, dtype=tdtype, model_dir=path,
    )


def bake_code(source: CodeOven | Path | str, prompt: str, **kwargs: Any) -> str:
    """Convenience: accepts a preheated oven or a snapshot path/URL."""
    oven = source if isinstance(source, CodeOven) else preheat(local_dir=str(source))
    return oven.complete(prompt, **kwargs)


def fill_middle(
    source: CodeOven | Path | str, prefix: str, suffix: str, **kwargs: Any,
) -> str:
    """Convenience FIM API — accepts a preheated oven or a snapshot path."""
    oven = source if isinstance(source, CodeOven) else preheat(local_dir=str(source))
    return oven.fill(prefix, suffix, **kwargs)


def load_pt(pt_path: Path | str, *, device: str | None = None) -> CodeOven:
    """Rehydrate a CodeOven from a ``save_pt`` bundle.

    Tokenizer files are pulled from the original ``source_model_dir`` when
    still available; otherwise falls back to the byte-level tokenizer.
    """
    pt_path = Path(pt_path)
    bundle = torch.load(pt_path, map_location="cpu", weights_only=False)
    from .train import HyperNixConfig

    cfg = HyperNixConfig.from_dict(bundle["config"])
    model = HyperNixModel(cfg)
    model.load_state_dict(bundle["state_dict"], strict=False)
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    model.to(dev)
    model.eval()

    src_dir = Path(bundle.get("source_model_dir") or "")
    tok, kind = _load_tokenizer(src_dir) if src_dir.exists() else _load_tokenizer(Path("."))
    return CodeOven(
        model=model, tokenizer=tok, tokenizer_kind=kind,
        device=dev, dtype=next(model.parameters()).dtype,
        model_dir=src_dir if src_dir.exists() else pt_path.parent,
    )
