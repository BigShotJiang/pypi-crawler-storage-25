"""Sampler implementations."""
