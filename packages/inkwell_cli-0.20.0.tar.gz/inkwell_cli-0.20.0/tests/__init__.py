"""Tests for Inkwell CLI."""
