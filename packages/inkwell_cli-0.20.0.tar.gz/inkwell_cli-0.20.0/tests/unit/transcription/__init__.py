"""Tests for transcription module."""
