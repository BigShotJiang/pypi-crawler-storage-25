"""Tests for plugin infrastructure."""
