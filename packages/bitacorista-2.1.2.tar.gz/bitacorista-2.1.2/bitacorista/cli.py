"""
Bitacorista v2 — Interfaz de línea de comandos.
"""

import sys
import os
import json
import argparse
import logging
import sqlite3
from pathlib import Path

# Encoding para Windows
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
    sys.stderr.reconfigure(encoding="utf-8")  # type: ignore[union-attr]

from . import db as store
from . import engine


def cmd_init(args: argparse.Namespace) -> None:
    """Crea una nueva sesión o proyecto."""
    modo = "proyecto" if args.proyecto else "sesion"
    if args.proyecto:
        path = args.db or f"{args.proyecto}.db"
    else:
        path = args.db or default_db_path()
    if Path(path).exists() and not args.force:
        print(f"Ya existe: {path}")
        print("Usá --force para sobreescribir.")
        return
    if Path(path).exists() and args.force:
        Path(path).unlink()
        for ext in ["-wal", "-shm"]:
            p = Path(path + ext)
            if p.exists():
                p.unlink()
    conn = store.init_db(path, modo=modo)
    if modo == "proyecto":
        sid = store.create_session(conn, name=args.proyecto)
        print(f"Proyecto creado: {path} (sesión {sid})")
    else:
        print(f"Sesión creada: {path}")
    conn.close()


TIPOS_SESION = {'DECISIÓN', 'DESCUBRIMIENTO', 'ENTREGABLE', 'IDEA',
                'CAMBIO-DE-TEMA', 'CORRECCIÓN', 'PREMISA', 'DESCARTE'}
TIPOS_PROYECTO = TIPOS_SESION | {'HIPÓTESIS', 'FUENTE'}


def cmd_add(args: argparse.Namespace) -> None:
    """Agrega una entrada manualmente."""
    conn = open_session(args)
    modo = store.get_meta(conn, "modo") or "sesion"
    tipos_valid = TIPOS_PROYECTO if modo == "proyecto" else TIPOS_SESION
    if args.tipo not in tipos_valid:
        print(f"Tipo inválido: '{args.tipo}'")
        print(f"Tipos válidos: {', '.join(sorted(tipos_valid))}")
        conn.close()
        return
    session_id = store.get_active_session(conn) if modo == "proyecto" else None
    emb = engine.embed(args.resumen) if args.resumen else None
    entry_id = store.add_entry(
        conn,
        tipo=args.tipo,
        resumen=args.resumen,
        contexto=args.contexto,
        estado=args.estado or "FIRME",
        embedding=emb,
        embedding_model=engine._MODEL_NAME if emb else None,
        session_id=session_id,
    )
    print(f"{entry_id} [{args.tipo}] [{args.estado or 'FIRME'}] {args.resumen}")
    if args.json:
        print(json.dumps({"id": entry_id, "tipo": args.tipo, "estado": args.estado or "FIRME"}, ensure_ascii=False))
    conn.close()


def cmd_process(args: argparse.Namespace) -> None:
    """Procesa un intercambio (detecta eventos automáticamente)."""
    conn = open_session(args)
    session_id = store.get_active_session(conn)
    n = store.count_exchanges(conn) + 1
    entries = engine.process_exchange(
        conn,
        user_msg=args.user,
        asst_msg=args.assistant,
        exchange_n=n,
        session_id=session_id,
    )
    if entries:
        for e in entries:
            print(f"{e['id']} [{e['tipo']}] [{e['estado']}] {e['resumen']}")
    else:
        print("Ningún evento detectado.")
    if args.json:
        print(json.dumps(entries, ensure_ascii=False))
    conn.close()


def cmd_open(args: argparse.Namespace) -> None:
    """Abre un proyecto y crea una nueva sesión."""
    path = args.db or f"{args.name}.db"
    if not Path(path).exists():
        print(f"Proyecto no encontrado: {path}")
        return
    conn = store.open_db(path)
    modo = store.get_meta(conn, "modo")
    if modo != "proyecto":
        print(f"'{path}' no es un proyecto (modo={modo}). Usá 'process' directamente.")
        conn.close()
        return
    sid = store.create_session(conn, name=args.session_name)
    print(f"Nueva sesión: {sid}")
    conn.close()


def cmd_sesiones(args: argparse.Namespace) -> None:
    """Lista sesiones de un proyecto."""
    conn = open_session(args)
    sessions = store.list_sessions(conn)
    if not sessions:
        print("No hay sesiones (modo sesión, no proyecto).")
    else:
        for s in sessions:
            active = store.get_active_session(conn)
            marker = " *" if s["session_id"] == active else ""
            print(f"  {s['session_id']}{marker} — {s.get('name', '')} ({s['created'][:10]})")
    conn.close()


def cmd_evidencia(args: argparse.Namespace) -> None:
    """Muestra evidencia a favor y en contra de una hipótesis."""
    conn = open_session(args)
    entry = store.get_entry(conn, args.entry_id)
    if not entry:
        print(f"Entrada {args.entry_id} no encontrada.")
        conn.close()
        return
    ev = store.evidencia(conn, args.entry_id)
    print(f"Hipótesis {args.entry_id}: {entry['resumen']}")
    if ev["supports"]:
        print("\n  A FAVOR:")
        for e in ev["supports"]:
            print(f"    {e['id']} [{e['tipo']}] {e['resumen']}")
    if ev["contradicts"]:
        print("\n  EN CONTRA:")
        for e in ev["contradicts"]:
            print(f"    {e['id']} [{e['tipo']}] {e['resumen']}")
    if not ev["supports"] and not ev["contradicts"]:
        print("  Sin evidencia conectada.")
    if args.json:
        safe = {
            "supports": [{"id": e["id"], "resumen": e["resumen"]} for e in ev["supports"]],
            "contradicts": [{"id": e["id"], "resumen": e["resumen"]} for e in ev["contradicts"]],
        }
        print(json.dumps(safe, ensure_ascii=False))
    conn.close()


def cmd_versiones(args: argparse.Namespace) -> None:
    """Muestra el historial de versiones de una entrada."""
    conn = open_session(args)
    chain = store.versiones(conn, args.entry_id)
    if len(chain) <= 1:
        print(f"Sin historial de versiones para {args.entry_id}.")
    else:
        print(f"Historial ({len(chain)} versiones):")
        for i, e in enumerate(chain):
            marker = " ← actual" if e["id"] == args.entry_id else ""
            print(f"  v{i+1}: {e['id']} [{e['estado']}] {e['resumen']}{marker}")
    conn.close()


def cmd_resumen(args: argparse.Namespace) -> None:
    """Muestra el resumen vivo."""
    conn = open_session(args)
    print(store.get_resumen(conn))
    conn.close()


def cmd_buscar(args: argparse.Namespace) -> None:
    """Búsqueda semántica en la sesión."""
    conn = open_session(args)
    emb = engine.embed(args.query)
    if not emb:
        print("Modelo de embeddings no disponible. Instalá onnxruntime y descargá el modelo.")
        conn.close()
        return
    resultados = store.buscar_similares(conn, emb, k=args.k or 5)
    if not resultados:
        print("Sin resultados.")
    else:
        for eid, dist in resultados:
            entry = store.get_entry(conn, eid)
            if entry:
                print(f"  {eid} (dist={dist:.3f}) [{entry['estado']}] {entry['resumen']}")
    if args.json:
        print(json.dumps([{"id": eid, "distance": round(dist, 4)} for eid, dist in resultados], ensure_ascii=False))
    conn.close()


def cmd_descartes(args: argparse.Namespace) -> None:
    """Lista descartes documentados para reevaluación."""
    conn = open_session(args)
    descartes = engine.proyectar_descartes(conn)
    if not descartes:
        print("No hay descartes registrados.")
    else:
        for d in descartes:
            ctx = f" — {d['contexto']}" if d.get("contexto") else ""
            print(f"  {d['id']}: {d['resumen']}{ctx}")
    conn.close()


def cmd_firmes(args: argparse.Namespace) -> None:
    """Lista decisiones firmes vigentes."""
    conn = open_session(args)
    firmes = store.get_entries(conn, estado="FIRME")
    if not firmes:
        print("No hay decisiones firmes.")
    else:
        for e in firmes:
            print(f"  {e['id']} [{e['tipo']}] {e['resumen']}")
    conn.close()


def cmd_entries(args: argparse.Namespace) -> None:
    """Lista todas las entradas."""
    conn = open_session(args)
    entries = store.get_entries(conn, tipo=args.tipo, estado=args.estado)
    if not entries:
        print("No hay entradas.")
    else:
        for e in entries:
            print(f"  {e['id']} [{e['tipo']:15}] [{e['estado']:10}] {e['resumen']}")
    if args.json:
        safe = [{k: v for k, v in e.items() if k != "embedding"} for e in entries]
        print(json.dumps(safe, ensure_ascii=False, indent=2))
    conn.close()


def cmd_latentes(args: argparse.Namespace) -> None:
    """Descubre conexiones latentes entre entradas."""
    conn = open_session(args)
    latentes = engine.explorar_latentes(conn, umbral=args.umbral or engine.UMBRAL_LATENTES)
    if not latentes:
        print("No se encontraron conexiones latentes.")
    else:
        for l in latentes:
            print(f"  {l['a']} <-> {l['b']} (sim={l['similitud']:.3f})")
            print(f"    {l['resumen_a']}")
            print(f"    {l['resumen_b']}")
    conn.close()


def cmd_scan(args: argparse.Namespace) -> None:
    """Barre exchanges buscando eventos no registrados."""
    conn = open_session(args)
    unregistered = engine.batch_scan(conn)
    if not unregistered:
        print("No hay eventos sin registrar.")
    else:
        for u in unregistered:
            print(f"  Ex#{u['exchange_n']} [{u['tipo']}] {u['resumen']}")
    conn.close()


def cmd_export(args: argparse.Namespace) -> None:
    """Exporta la sesión a Markdown."""
    conn = open_session(args)
    entries = store.get_entries(conn)
    edges = store.get_edges(conn)

    lines = ["# Bitácora de sesión", ""]

    # Índice
    lines.append("## Índice")
    for e in entries:
        lines.append(f"- **{e['id']}** [{e['tipo']}] [{e['estado']}] {e['resumen']}")
    lines.append("")

    # Entradas
    lines.append("## Entradas")
    for e in entries:
        lines.append(f"### {e['id']} — {e['resumen']}")
        lines.append(f"- **Tipo:** {e['tipo']}")
        lines.append(f"- **Estado:** {e['estado']}")
        if e.get("contexto"):
            lines.append(f"- **Contexto:** {e['contexto']}")
        lines.append(f"- **Timestamp:** {e['timestamp']}")
        lines.append("")

    # Grafo
    if edges:
        lines.append("## Conexiones")
        for edge in edges:
            lines.append(f"- {edge['source']} → {edge['target']} [{edge['edge_type']}]")
        lines.append("")

    output = "\n".join(lines)

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"Exportado a: {args.output}")
    else:
        print(output)

    conn.close()


# --- Helpers ---


def default_db_path() -> str:
    """Devuelve la ruta por defecto de la DB de sesión."""
    return str(Path.cwd() / "sesion.db")


def open_session(args: argparse.Namespace) -> sqlite3.Connection:
    """Abre la sesión. Crea si no existe (solo con ruta por defecto)."""
    path = getattr(args, "db", None)
    if path:
        # Ruta explícita: no crear silenciosamente
        if not Path(path).exists():
            print(f"No encontrado: {path}")
            print("Usá 'init' para crear una sesión nueva.")
            sys.exit(1)
        try:
            return store.open_db(path, validate=True)
        except ValueError as e:
            print(str(e))
            sys.exit(1)
    # Ruta por defecto: crear si no existe
    path = default_db_path()
    if not Path(path).exists():
        return store.init_db(path)
    return store.open_db(path, validate=True)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="bitacorista",
        description="Bitacorista v2 — Memoria estructurada para conversaciones con IA",
    )
    parser.add_argument("--db", help="Ruta al archivo .db de sesión")
    parser.add_argument("--json", action="store_true", help="Output en JSON")
    parser.add_argument("--verbose", action="store_true", help="Modo debug")

    sub = parser.add_subparsers(dest="command")

    # init
    p_init = sub.add_parser("init", help="Crear nueva sesión o proyecto")
    p_init.add_argument("--force", action="store_true", help="Sobreescribir si existe")
    p_init.add_argument("--proyecto", help="Nombre del proyecto (activa modo proyecto)")

    # add
    p_add = sub.add_parser("add", help="Agregar entrada manualmente")
    p_add.add_argument("--tipo", required=True, help="Tipo de entrada")
    p_add.add_argument("--resumen", required=True, help="Resumen de la entrada")
    p_add.add_argument("--contexto", help="Contexto adicional")
    p_add.add_argument("--estado", help="Estado (FIRME/INFERIDO/DESCARTADO/OBSOLETO)")

    # process
    p_proc = sub.add_parser("process", help="Procesar un intercambio")
    p_proc.add_argument("--user", required=True, help="Mensaje del usuario")
    p_proc.add_argument("--assistant", help="Respuesta del asistente")

    # resumen
    sub.add_parser("resumen", help="Mostrar resumen vivo")

    # buscar
    p_buscar = sub.add_parser("buscar", help="Búsqueda semántica")
    p_buscar.add_argument("query", help="Texto a buscar")
    p_buscar.add_argument("-k", type=int, help="Número de resultados")

    # descartes
    sub.add_parser("descartes", help="Listar descartes para reevaluar")

    # firmes
    sub.add_parser("firmes", help="Listar decisiones firmes")

    # entries
    p_entries = sub.add_parser("entries", help="Listar todas las entradas")
    p_entries.add_argument("--tipo", help="Filtrar por tipo")
    p_entries.add_argument("--estado", help="Filtrar por estado")

    # latentes
    p_lat = sub.add_parser("latentes", help="Descubrir conexiones latentes")
    p_lat.add_argument("--umbral", type=float, help="Umbral de similitud (default 0.5)")

    # scan
    sub.add_parser("scan", help="Barrer exchanges por eventos no registrados")

    # export
    p_export = sub.add_parser("export", help="Exportar a Markdown")
    p_export.add_argument("--output", "-o", help="Archivo de salida")

    # --- Modo proyecto ---

    # open
    p_open = sub.add_parser("open", help="Abrir proyecto y crear nueva sesión")
    p_open.add_argument("name", help="Nombre del proyecto")
    p_open.add_argument("--session-name", help="Nombre para la sesión")

    # sesiones
    sub.add_parser("sesiones", help="Listar sesiones del proyecto")

    # evidencia
    p_ev = sub.add_parser("evidencia", help="Evidencia a favor/contra de una hipótesis")
    p_ev.add_argument("entry_id", help="ID de la entrada (ej: E014)")

    # versiones
    p_ver = sub.add_parser("versiones", help="Historial de versiones de una entrada")
    p_ver.add_argument("entry_id", help="ID de la entrada (ej: E003)")

    args = parser.parse_args()

    # Logging
    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s %(levelname)s: %(message)s")

    if not args.command:
        parser.print_help()
        return

    commands = {
        "init": cmd_init,
        "add": cmd_add,
        "process": cmd_process,
        "resumen": cmd_resumen,
        "buscar": cmd_buscar,
        "descartes": cmd_descartes,
        "firmes": cmd_firmes,
        "entries": cmd_entries,
        "latentes": cmd_latentes,
        "scan": cmd_scan,
        "export": cmd_export,
        "open": cmd_open,
        "sesiones": cmd_sesiones,
        "evidencia": cmd_evidencia,
        "versiones": cmd_versiones,
    }

    commands[args.command](args)


if __name__ == "__main__":
    main()
