"""
Bitacorista — Structured memory for AI conversations.
Mechanical event detection + semantic search, no LLM required.
"""
from __future__ import annotations

from . import db
from . import engine
from .db import (
    init_db,
    open_db,
    add_entry,
    get_entry,
    get_entries,
    update_estado,
    add_edge,
    get_edges,
    add_exchange,
    get_exchanges,
    get_resumen,
    buscar_similares,
    detect_duplicate,
    bfs,
    blast_radius,
)
from .engine import (
    detect_events,
    classify_estado,
    extract_resumen,
    process_exchange,
    process_batch,
    embed,
)

__version__ = "2.1.2"


class Session:
    """High-level API for bitacorista. Wraps a connection with convenience methods.

    Usage:
        session = Session("my-project.db")
        entries = session.process("We decided to use SQLite.")
        print(session.summary())
        session.close()
    """

    def __init__(self, path: str = "bitacorista.db", modo: str = "sesion", create: bool = True):
        if create:
            self.conn = init_db(path, modo=modo)
        else:
            self.conn = open_db(path, validate=True)
        self.path = path
        self._exchange_n = db.count_exchanges(self.conn)

    def process(self, user_msg: str, asst_msg: str | None = None) -> list[dict]:
        """Process a message, detect events, store entries. Returns list of detected entries."""
        self._exchange_n += 1
        return process_exchange(self.conn, user_msg, asst_msg, exchange_n=self._exchange_n)

    def search(self, query: str, k: int = 5) -> list[tuple]:
        """Semantic search over stored entries. Requires ONNX model."""
        emb = embed(query)
        if emb is None:
            return []
        return buscar_similares(self.conn, emb, k=k)

    def entries(self, tipo: str | None = None, estado: str | None = None) -> list[dict]:
        """Get stored entries, optionally filtered."""
        return get_entries(self.conn, tipo=tipo, estado=estado)

    def summary(self) -> str:
        """Get a text summary of all entries."""
        return get_resumen(self.conn)

    def close(self) -> None:
        """Close the database connection."""
        self.conn.close()

    def __enter__(self) -> Session:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
