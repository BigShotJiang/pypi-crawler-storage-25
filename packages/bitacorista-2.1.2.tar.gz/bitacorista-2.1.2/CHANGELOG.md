# Changelog

All notable changes to this project are documented here.

## [2.1.2] - 2026-04-13

### Fixed
- **[HIGH]** `Session._exchange_n` restarted at 0 when reopening an existing DB, silently overwriting previous exchanges. Now initializes from `count_exchanges()`.
- `Session` always ran `init_db` even for existing DBs. Added `create=False` parameter to use `open_db(validate=True)` instead, raising an error on invalid/missing paths.
- Example `semantic_search.py` had wrong download command (`python download_model.py` → `python -m bitacorista.download_model`)
- Source distribution missing test files. Added `MANIFEST.in` to include tests/, examples/, CHANGELOG, CONTRIBUTING, LICENSE.

## [2.1.1] - 2026-04-13

### Fixed
- `NameError: name 'Session' is not defined` on Python 3.10-3.12 — added `from __future__ import annotations` to `__init__.py`
- 6 write functions missing `BEGIN IMMEDIATE` (`add_exchange`, `add_edge`, `set_meta`, `update_estado`, `touch_session`, `_set_meta_if_missing`) — writes landed via autocommit but without contention protection
- Dead `db.commit()` call after `executescript` in `init_db`

### Added
- Full type annotations across all 62 functions (mypy strict mode, zero errors)
- `py.typed` marker (PEP 561) for downstream type checking
- Concurrent write tests (8 tests with threading + `queue.Queue`)
- CONTRIBUTING.md with setup, testing, and code conventions
- GitHub issue templates (bug report + feature request)
- PyPI publish workflow via trusted publishing (OIDC, no API tokens)
- `dev-lite` optional extra (tests without ONNX download)
- `@pytest.mark.embeddings` marker replacing `--ignore` for test filtering

### Changed
- CI uses `-m "not embeddings"` instead of `--ignore=tests/test_embeddings.py`
- CI accepts both `master` and `main` branches
- mypy pinned to `<1.16` (was `<2`)
- Core test jobs use `dev-lite` (faster, no ONNX download)
- Test count: 74 → 112

## [2.1.0] - 2026-04-13

Complete rewrite. SQLite replaces Markdown files, embeddings replace keywords, 3 Python files replace 28 scripts.

### Architecture
- SQLite as single source of truth (WAL mode, `BEGIN IMMEDIATE` for writes)
- sqlite-vec for cosine vector search (`distance_metric=cosine`)
- ONNX runtime embeddings (paraphrase-multilingual-MiniLM-L12-v2, 384 dims)
- Two modes: `sesion` (default, 8 event types) and `proyecto` (multi-session, +HIPOTESIS, +FUENTE)

### Added
- `bitacorista.Session` — high-level API with context manager (5-line usage)
- Bilingual event detection: Spanish + English via regex (10 event types)
- 3-layer dedup in `process_exchange`: pre-transaction, in-transaction re-check, intra-transaction local cosine
- 2-phase writes: prepare (embeddings, no lock) then write (BEGIN IMMEDIATE, minimal lock)
- Blast radius: BFS over edges to find affected entries
- `explorar_latentes`: discover implicit connections via embedding similarity
- `proyectar_descartes`: surface discarded decisions for reevaluation
- `detect_break`: detect topic shifts via cosine distance between exchanges
- CLI with 15 commands (`init`, `add`, `list`, `search`, `resumen`, `graph`, etc.)
- `download_model.py` as `python -m bitacorista.download_model`
- GitHub Actions CI: core tests on Python 3.10-3.13, embedding tests on 3.12

### Packaging
- Proper Python package: `pip install bitacorista`
- `pyproject.toml` with entry points, optional deps (`[embeddings]`, `[dev]`)
- 74 tests (64 core + 10 embedding), all passing
- 3 examples: quickstart, Claude Code hook, semantic search

### Fixed (across 4 expert review rounds, 25 fixes)
- Race condition in `next_id` (read-modify-write without transaction)
- ROLLBACK in except blocks masking original exceptions
- Embed calls inside `BEGIN IMMEDIATE` blocking writers unnecessarily
- sqlite-vec defaulting to L2 instead of cosine (wrong results, no error)
- TOCTOU in dedup check (check outside transaction, write inside)
- Intra-transaction dedup for near-identical events in same exchange
- Silent error swallowing in `touch_session`, `list_sessions`, `buscar_similares`
- Schema duplication between sesion and proyecto modes
- `download_model.py` unreachable as Python module
- `cmd_add` not passing `session_id` in proyecto mode (orphaned entries)

## [1.0.0] - 2026-04-12

Original implementation. 28 standalone scripts operating on Markdown files.

### Architecture
- Markdown files as storage (bitacora.md, grafo.json)
- Keyword-based search and dedup
- Scoring via mechanical heuristics
- Graph snapshot + blast radius via JSON

### Added
- `add_entry.py` — register entries to Markdown bitacora
- `graph_engine.py`, `graph_snapshot.py` — build/update graph from entries
- `blast_radius.py` — trace impact of changes through graph
- `score_entry.py` — confidence scoring for entries
- `detect_merge.py` — suggest thread merges
- `detect_break.py` — detect topic shifts
- `batch_scan.py` — regex scan over exchanges
- `compactar.py`, `explorador.py`, `minero.py`, `proyectar.py` — manual tools
- 135 tests via pytest, CI with coverage
