"""Tests for bitacorista CLI commands."""

import subprocess
import sys
import json
import os
import tempfile
import pytest


def run_cli(*args, db=None):
    """Run bitacorista CLI and return (stdout, stderr, returncode)."""
    cmd = [sys.executable, "-m", "bitacorista"]
    if db:
        cmd += ["--db", db]
    # --json flag must come before subcommand too
    cmd += list(args)
    result = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8")
    return result.stdout, result.stderr, result.returncode


# --- init ---


class TestInit:
    def test_init_creates_db(self, db_path):
        out, _, rc = run_cli("init", db=db_path)
        assert rc == 0
        assert "Sesión creada" in out
        assert os.path.exists(db_path)

    def test_init_proyecto(self, db_path):
        out, _, rc = run_cli("init", "--proyecto", "myproject", db=db_path)
        assert rc == 0
        assert "Proyecto creado" in out

    def test_init_refuses_overwrite(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("init", db=db_path)
        assert rc == 0
        assert "Ya existe" in out

    def test_init_force_overwrites(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("init", "--force", db=db_path)
        assert rc == 0
        assert "Sesión creada" in out


# --- add ---


class TestAdd:
    def test_add_entry(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("add", "--tipo", "DECISIÓN", "--resumen", "Use SQLite", db=db_path)
        assert rc == 0
        assert "E001" in out
        assert "DECISIÓN" in out

    def test_add_invalid_tipo(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("add", "--tipo", "INVALID", "--resumen", "test", db=db_path)
        assert rc == 0
        assert "Tipo inválido" in out

    def test_add_with_estado(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("add", "--tipo", "DECISIÓN", "--resumen", "test", "--estado", "FIRME", db=db_path)
        assert rc == 0
        assert "FIRME" in out

    def test_add_json_output(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("--json", "add", "--tipo", "IDEA", "--resumen", "test idea", db=db_path)
        assert rc == 0
        # JSON output should contain the entry
        assert '"id"' in out or "E001" in out


# --- process ---


class TestProcess:
    def test_process_detects_decision(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("process", "--user", "We decided to use Vue.", db=db_path)
        assert rc == 0
        assert "DECISIÓN" in out

    def test_process_no_events(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("process", "--user", "The weather is nice today.", db=db_path)
        assert rc == 0
        assert "Ningún evento" in out

    def test_process_with_assistant(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("process", "--user", "Decidimos usar SQLite.", "--assistant", "OK, registro la decisión.", db=db_path)
        assert rc == 0
        assert "DECISIÓN" in out


# --- entries ---


class TestEntries:
    def test_entries_empty(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("entries", db=db_path)
        assert rc == 0
        assert "No hay entradas" in out

    def test_entries_after_add(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DECISIÓN", "--resumen", "Use SQLite", db=db_path)
        run_cli("add", "--tipo", "DESCARTE", "--resumen", "Drop MongoDB", db=db_path)
        out, _, rc = run_cli("entries", db=db_path)
        assert rc == 0
        assert "E001" in out
        assert "E002" in out

    def test_entries_filter_tipo(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DECISIÓN", "--resumen", "Use SQLite", db=db_path)
        run_cli("add", "--tipo", "IDEA", "--resumen", "Maybe Redis", db=db_path)
        out, _, rc = run_cli("entries", "--tipo", "IDEA", db=db_path)
        assert rc == 0
        assert "Maybe Redis" in out
        assert "Use SQLite" not in out

    def test_entries_filter_estado(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DECISIÓN", "--resumen", "SQLite", "--estado", "FIRME", db=db_path)
        run_cli("add", "--tipo", "IDEA", "--resumen", "Redis", db=db_path)
        out, _, rc = run_cli("entries", "--estado", "FIRME", db=db_path)
        assert rc == 0
        assert "SQLite" in out


# --- resumen ---


class TestResumen:
    def test_resumen_empty(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("resumen", db=db_path)
        assert rc == 0
        assert "0 entradas" in out

    def test_resumen_with_entries(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DECISIÓN", "--resumen", "Use SQLite", db=db_path)
        out, _, rc = run_cli("resumen", db=db_path)
        assert rc == 0
        assert "1 entrad" in out


# --- descartes ---


class TestDescartes:
    def test_descartes_empty(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("descartes", db=db_path)
        assert rc == 0
        assert "No hay descartes" in out

    def test_descartes_shows_discarded(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DESCARTE", "--resumen", "Drop React", "--estado", "DESCARTADO", db=db_path)
        out, _, rc = run_cli("descartes", db=db_path)
        assert rc == 0
        assert "Drop React" in out


# --- firmes ---


class TestFirmes:
    def test_firmes_empty(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("firmes", db=db_path)
        assert rc == 0
        assert "No hay decisiones firmes" in out

    def test_firmes_shows_firm(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DECISIÓN", "--resumen", "Use Vue", "--estado", "FIRME", db=db_path)
        out, _, rc = run_cli("firmes", db=db_path)
        assert rc == 0
        assert "Use Vue" in out


# --- export ---


class TestExport:
    def test_export_stdout(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DECISIÓN", "--resumen", "Use SQLite", db=db_path)
        out, _, rc = run_cli("export", db=db_path)
        assert rc == 0
        assert "# Bitácora de sesión" in out
        assert "Use SQLite" in out

    def test_export_to_file(self, db_path):
        run_cli("init", db=db_path)
        run_cli("add", "--tipo", "DECISIÓN", "--resumen", "Use SQLite", db=db_path)
        fd, out_path = tempfile.mkstemp(suffix=".md")
        os.close(fd)
        try:
            out, _, rc = run_cli("export", "-o", out_path, db=db_path)
            assert rc == 0
            assert "Exportado a" in out
            content = open(out_path, encoding="utf-8").read()
            assert "Use SQLite" in content
        finally:
            os.unlink(out_path)


# --- proyecto mode ---


class TestProyecto:
    def test_open_creates_session(self, db_path):
        run_cli("init", "--proyecto", "testproj", db=db_path)
        out, _, rc = run_cli("open", "testproj", db=db_path)
        assert rc == 0
        assert "Nueva sesión" in out

    def test_sesiones_lists(self, db_path):
        run_cli("init", "--proyecto", "testproj", db=db_path)
        out, _, rc = run_cli("sesiones", db=db_path)
        assert rc == 0
        assert "testproj" in out or "S-" in out

    def test_open_nonexistent(self):
        out, _, rc = run_cli("open", "nonexistent_project_xyz")
        assert "no encontrado" in out.lower() or rc != 0


# --- error paths ---


class TestErrorPaths:
    def test_no_command_shows_help(self):
        out, _, rc = run_cli()
        assert rc == 0
        assert "bitacorista" in out.lower() or "usage" in out.lower()

    def test_explicit_db_not_found(self):
        _, _, rc = run_cli("entries", db="/tmp/nonexistent_db_xyz.db")
        assert rc != 0

    def test_verbose_flag(self, db_path):
        run_cli("init", db=db_path)
        out, err, rc = run_cli("--verbose", "resumen", db=db_path)
        assert rc == 0


# --- scan ---


class TestScan:
    def test_scan_no_exchanges(self, db_path):
        run_cli("init", db=db_path)
        out, _, rc = run_cli("scan", db=db_path)
        assert rc == 0
        assert "No hay eventos" in out
