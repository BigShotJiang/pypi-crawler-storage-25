"""Tests for bitacorista.engine — detection, classification, pipeline."""

import time
import pytest
from bitacorista import db as store
from bitacorista import engine


# --- Detection: Spanish ---


class TestDetectEventsSpanish:
    def test_decision(self):
        tipos = [e["tipo"] for e in engine.detect_events("Decidimos usar Vue para el frontend.")]
        assert "DECISIÓN" in tipos

    def test_descarte(self):
        tipos = [e["tipo"] for e in engine.detect_events("Descartamos React por complejidad.")]
        assert "DESCARTE" in tipos

    def test_correccion(self):
        tipos = [e["tipo"] for e in engine.detect_events("No, eso está mal. La API es REST, no GraphQL.")]
        assert "CORRECCIÓN" in tipos

    def test_cambio_de_tema(self):
        tipos = [e["tipo"] for e in engine.detect_events("Cambiando de tema, hablemos del deploy.")]
        assert "CAMBIO-DE-TEMA" in tipos

    def test_entregable(self):
        tipos = [e["tipo"] for e in engine.detect_events("Creá el archivo de configuración.")]
        assert "ENTREGABLE" in tipos

    def test_descubrimiento(self):
        tipos = [e["tipo"] for e in engine.detect_events("Descubrí que la API tiene rate limiting.")]
        assert "DESCUBRIMIENTO" in tipos

    def test_multiple_events(self):
        events = engine.detect_events("Decidimos usar Vue. Descartamos React.")
        tipos = [e["tipo"] for e in events]
        assert "DECISIÓN" in tipos
        assert "DESCARTE" in tipos
        assert len(events) >= 2

    def test_no_events_in_plain_text(self):
        assert len(engine.detect_events("El clima está lindo hoy.")) == 0

    def test_dedup_nearby(self):
        events = engine.detect_events("No, eso está mal, corregí esto.")
        corr = [e for e in events if e["tipo"] == "CORRECCIÓN"]
        assert 1 <= len(corr) <= 2


# --- Detection: English ---


class TestDetectEventsEnglish:
    def test_decision(self):
        tipos = [e["tipo"] for e in engine.detect_events("We decided to use PostgreSQL.")]
        assert "DECISIÓN" in tipos

    def test_descarte(self):
        tipos = [e["tipo"] for e in engine.detect_events("Scrap that, it doesn't work.")]
        assert "DESCARTE" in tipos

    def test_correccion(self):
        tipos = [e["tipo"] for e in engine.detect_events("No, that's wrong. The API uses REST.")]
        assert "CORRECCIÓN" in tipos

    def test_cambio_de_tema(self):
        tipos = [e["tipo"] for e in engine.detect_events("Switching gears, let's talk about deployment.")]
        assert "CAMBIO-DE-TEMA" in tipos

    def test_entregable(self):
        tipos = [e["tipo"] for e in engine.detect_events("Create the configuration file.")]
        assert "ENTREGABLE" in tipos

    def test_descubrimiento(self):
        tipos = [e["tipo"] for e in engine.detect_events("Turns out the API has rate limiting.")]
        assert "DESCUBRIMIENTO" in tipos

    def test_mixed(self):
        tipos = [e["tipo"] for e in engine.detect_events("We decided to use Vue. Drop that React idea.")]
        assert "DECISIÓN" in tipos
        assert "DESCARTE" in tipos


# --- Detection: Proyecto mode ---


class TestDetectEventsProyecto:
    def test_hipotesis_filtered_in_sesion(self):
        tipos = [e["tipo"] for e in engine.detect_events("Mi hipótesis es que funciona.", modo="sesion")]
        assert "HIPÓTESIS" not in tipos

    def test_hipotesis_included_in_proyecto(self):
        tipos = [e["tipo"] for e in engine.detect_events("Mi hipótesis es que funciona.", modo="proyecto")]
        assert "HIPÓTESIS" in tipos

    def test_english_hipotesis(self):
        tipos = [e["tipo"] for e in engine.detect_events("My hypothesis is that it works.", modo="proyecto")]
        assert "HIPÓTESIS" in tipos

    def test_fuente_in_proyecto(self):
        tipos = [e["tipo"] for e in engine.detect_events("Según el paper de Smith, es correcto.", modo="proyecto")]
        assert "FUENTE" in tipos

    def test_english_fuente(self):
        tipos = [e["tipo"] for e in engine.detect_events("According to the study, it works.", modo="proyecto")]
        assert "FUENTE" in tipos


# --- Classification ---


class TestClassifyEstado:
    def test_english_firme(self):
        assert engine.classify_estado("Confirmed: we use Vue", "DECISIÓN") == "FIRME"
        assert engine.classify_estado("We decided to go with SQLite", "DECISIÓN") == "FIRME"

    def test_descarte_always_descartado(self):
        assert engine.classify_estado("cualquier texto", "DESCARTE") == "DESCARTADO"

    def test_spanish_firme(self):
        assert engine.classify_estado("Confirmado: usamos Vue", "DECISIÓN") == "FIRME"
        assert engine.classify_estado("Decidimos ir con SQLite", "DECISIÓN") == "FIRME"

    def test_no_signal_is_inferido(self):
        assert engine.classify_estado("algo pasó", "DECISIÓN") == "INFERIDO"

    def test_descarte_beats_firme(self):
        assert engine.classify_estado("decidimos descartar React", "DESCARTE") == "DESCARTADO"


# --- Resumen extraction ---


def test_extract_resumen_clean():
    resumen = engine.extract_resumen("  Decidimos usar Vue para el frontend.  ", "DECISIÓN")
    assert 5 < len(resumen) < 200
    assert "\n" not in resumen


def test_extract_contexto_fragment():
    text = "A" * 50 + "MATCH" + "B" * 250
    contexto = engine.extract_contexto(text, 50)
    assert 0 < len(contexto) <= 350


# --- Pipeline ---


def test_process_exchange_registers_events(db):
    conn, _ = db
    entries = engine.process_exchange(conn, "Decidimos usar Vue. Descartamos React.", exchange_n=1)
    assert len(entries) >= 2
    tipos = [e["tipo"] for e in entries]
    assert "DECISIÓN" in tipos
    assert "DESCARTE" in tipos
    for e in entries:
        if e["tipo"] == "DESCARTE":
            assert e["estado"] == "DESCARTADO"


def test_process_exchange_stores_exchange(db):
    conn, _ = db
    engine.process_exchange(conn, "Hola mundo", exchange_n=1)
    exs = store.get_exchanges(conn)
    assert len(exs) == 1
    assert exs[0]["user_msg"] == "Hola mundo"


def test_process_exchange_no_events_for_plain_text(db):
    conn, _ = db
    assert len(engine.process_exchange(conn, "El clima está lindo.", exchange_n=1)) == 0


def test_process_batch(db):
    conn, _ = db
    exchanges = [
        {"user_msg": "Decidimos usar Python.", "n": 1},
        {"user_msg": "Descartamos Java.", "n": 2},
    ]
    assert len(engine.process_batch(conn, exchanges)) >= 2


def test_proyectar_descartes(db):
    conn, _ = db
    store.add_entry(conn, tipo="DESCARTE", resumen="React", estado="DESCARTADO")
    store.add_entry(conn, tipo="DECISIÓN", resumen="Vue", estado="FIRME")
    descartes = engine.proyectar_descartes(conn)
    assert len(descartes) == 1
    assert descartes[0]["resumen"] == "React"


def test_process_exchange_proyecto_hipotesis(proyecto_db):
    conn, _ = proyecto_db
    sid = store.get_active_session(conn)
    entries = engine.process_exchange(
        conn, "Mi hipótesis es que Vue es más rápido. Decidimos probar.",
        exchange_n=1, session_id=sid,
    )
    tipos = [e["tipo"] for e in entries]
    assert "HIPÓTESIS" in tipos
    assert "DECISIÓN" in tipos


# --- Timing ---


def test_full_cycle_under_10_seconds(db):
    conn, _ = db
    start = time.time()
    engine.process_exchange(conn, "Decidimos usar Python.", exchange_n=1)
    engine.process_exchange(conn, "Descartamos Java.", exchange_n=2)
    engine.process_exchange(conn, "Confirmado: SQLite como DB.", exchange_n=3)
    store.get_resumen(conn)
    store.get_entries(conn)
    store.get_edges(conn)
    engine.proyectar_descartes(conn)
    assert time.time() - start < 10
