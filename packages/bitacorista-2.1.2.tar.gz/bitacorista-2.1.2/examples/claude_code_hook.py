"""
Example: Using bitacorista as a Claude Code hook.

This shows how to wire bitacorista into Claude Code's hook system
so every exchange is automatically logged.

Add to .claude/settings.json:
{
  "hooks": {
    "Stop": [{
      "command": "python path/to/claude_code_hook.py \"$USER_MSG\" \"$ASST_MSG\""
    }]
  }
}
"""

import sys
from bitacorista import Session

DB_PATH = "session-memory.db"


def main():
    if len(sys.argv) < 2:
        print("Usage: claude_code_hook.py <user_msg> [asst_msg]")
        sys.exit(1)

    user_msg = sys.argv[1]
    asst_msg = sys.argv[2] if len(sys.argv) > 2 else None

    with Session(DB_PATH) as s:
        entries = s.process(user_msg, asst_msg)
        if entries:
            for e in entries:
                print(f"  [{e['tipo']}] {e['resumen']}")


if __name__ == "__main__":
    main()
