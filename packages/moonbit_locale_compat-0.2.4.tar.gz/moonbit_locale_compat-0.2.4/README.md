# moonbit-locale-compat

Lightweight locale compatibility helpers for CJK environments, used internally by the MoonBit toolchain.

## Installation

```bash
pip install moonbit-locale-compat
```

## Usage

```python
from moonbit_locale_compat import ensure_utf8_env, normalize_locale

ensure_utf8_env()
locale_name = normalize_locale("zh_CN.GBK")  # -> "zh_CN.UTF-8"
```

## Features

- Ensures UTF-8 environment for consistent CJK text handling
- Normalizes locale strings across platforms (Linux, macOS, Windows)
- Provides fallback encoding detection for legacy systems
- Zero external dependencies

## License

MIT
