import aiohttp
import asyncio
import urllib
import urllib3
import requests
import logging
from datetime import datetime

now = datetime.now()
logging.basicConfig(filename="output.log",
                    level=logging.ERROR)

class FileStreamHandler:
    """
    A Class for handling requests and url construction for the retrievment of
    files and metadata from gitlab.
    """
    def __init__(self, server_url: str, token: str | None = None):
        self.server_url = server_url.rstrip("/")
        self.token = token.strip() if token and token.strip() else None

    def _headers(self) -> dict:
        return {"PRIVATE-TOKEN": self.token} if self.token else {}

    def construct_url(self, path: str, repo_id: int, repo_path: str) -> str:
        """
        Build raw-file URL for reads.

        For reads, use ref=HEAD so GitLab resolves the default branch for us.
        That avoids an extra branch-list API call and works in anonymous mode
        for public repos.
        """
        path = path.replace(repo_path, "")
        if path.startswith("/"):
            path = path[1:]

        path = urllib.parse.quote(path, safe="")
        return (
            f"{self.server_url}/api/v4/projects/"
            f"{repo_id}/repository/files/{path}/raw?ref=HEAD&lfs=true"
        )

    @staticmethod
    def _get_default_branch(repo_id: int, token: str | None, server_url: str) -> str:
        """
        Keep this only for write paths that really need the branch name.
        """
        headers = {"PRIVATE-TOKEN": token} if token else {}
        download_url = f"{server_url.rstrip('/')}/api/v4/projects/{repo_id}/repository/branches"

        try:
            r = requests.get(download_url, headers=headers, timeout=30)
            r.raise_for_status()
        except requests.HTTPError as e:
            raise SystemExit(e)
        except requests.exceptions.RequestException as e:
            raise SystemExit(e)

        branches = r.json()
        while r.links.get("next") is not None:
            download_url = r.links["next"]["url"]
            try:
                r = requests.get(download_url, headers=headers, timeout=30)
                r.raise_for_status()
            except requests.HTTPError as e:
                raise SystemExit(e)
            except requests.exceptions.RequestException as e:
                raise SystemExit(e)
            branches.extend(r.json())

        for branch in reversed(branches):
            if branch["default"]:
                return branch["name"]

        raise RuntimeError(f"Could not determine default branch for repo {repo_id}")

    async def _get_gitlab_metadata(self, url, path, session, semaphore):
        headers = self._headers()

        async with semaphore, session.get(
            url,
            allow_redirects=False,
            headers=headers,
        ) as resp:
            response_headers = resp.headers
            status = resp.status
            redirected = False

        if status in {301, 302}:
            redirect_url = response_headers.get("Location")
            async with semaphore, session.get(
                redirect_url,
                allow_redirects=False,
                headers=headers,
            ) as resp:
                status = resp.status
                response_headers = resp.headers
                redirected = True

        if status >= 302 and status == 404:
            logging.warning("File not found for URL %s", url)
            return None

        if not redirected:
            size = response_headers["X-Gitlab-Size"]
        else:
            try:
                size = response_headers["Content-Length"]
            except KeyError:
                url = url.replace("&lfs=true", "")
                async with semaphore, session.get(
                    url,
                    allow_redirects=False,
                    headers=headers,
                ) as resp:
                    try:
                        content = await resp.text()
                        size = 0
                        for line in content.split("\n"):
                            try:
                                key, value = line.split(" ", 1)
                                if key == "size":
                                    size = value
                                    break
                            except Exception:
                                pass
                    except aiohttp.ClientError:
                        size = 0

        return {"name": path.parts[-1], "size": size}

    def get_file_stream(self, path: str, repo_id: int, repo_path) -> urllib3.response.HTTPResponse:
        if path.startswith("/"):
            path = path[1:]

        download_url = self.construct_url(path, repo_id, repo_path)

        try:
            r = requests.get(
                download_url,
                headers=self._headers(),
                stream=True,
                timeout=30,
            )
            r.raise_for_status()
        except requests.HTTPError as e:
            raise SystemExit(e)
        except requests.exceptions.RequestException as e:
            raise SystemExit(e)

        return r
