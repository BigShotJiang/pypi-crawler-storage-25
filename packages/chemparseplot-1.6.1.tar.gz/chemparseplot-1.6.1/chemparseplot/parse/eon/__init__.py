"""eOn trajectory parsers."""
