from rlearn.sports.soccer.main_class_soccer.main import rlearn_model_soccer


def _player(player_id, team_name, role="MF"):
    return {
        "index": player_id,
        "team_name": team_name,
        "player_name": f"{team_name}_{player_id}",
        "player_id": player_id,
        "player_role": role,
        "position": {"x": float(player_id), "y": float(player_id)},
        "velocity": {"x": 0.0, "y": 0.0},
        "action": "idle",
        "action_probs": None,
    }


def _event(game_id, sequence_id, attack_team, defense_team, attack_player_ids):
    attack_players = [_player(player_id, attack_team) for player_id in attack_player_ids]
    defense_players = [_player(100 + sequence_id, defense_team)]
    return {
        "game_id": game_id,
        "half": "1",
        "sequence_id": sequence_id,
        "sequence_start_frame": "0",
        "sequence_end_frame": "1",
        "team_name_attack": attack_team,
        "team_name_defense": defense_team,
        "events": [
            {
                "state": {
                    "ball": {
                        "position": {"x": 0.0, "y": 0.0},
                        "velocity": {"x": 0.0, "y": 0.0},
                    },
                    "players": attack_players + defense_players,
                    "attack_players": attack_players,
                    "defense_players": defense_players,
                },
                "action": None,
                "reward": 0.0,
            }
        ],
    }


def _batch(events):
    return {key: [event[key] for event in events] for key in events[0]}


def test_observation_metadata_stays_with_source_event_when_attacker_counts_differ():
    model = rlearn_model_soccer(state_def="PVS")
    events = [
        _event("game_a", 1, "team_a", "team_b", [1]),
        _event("game_c", 2, "team_c", "team_d", [2, 3]),
    ]

    result = model.events2attacker_simple_observation_action_sequence(
        _batch(events),
        min_frame_len_threshold=1,
        max_frame_len_threshold=1,
    )

    assert result["game_id"] == ["game_a", "game_c", "game_c"]
    assert result["sequence_id"] == [1, 2, 2]
    assert result["team_name_attack"] == ["team_a", "team_c", "team_c"]

    ego_teams = [
        sequence[0]["observation"]["ego_player"]["team_name"]
        for sequence in result["sequence"]
    ]
    assert ego_teams == result["team_name_attack"]
