import logging
import re
from pathlib import Path
import os
import shutil
from typing import Any, Dict
from copy import deepcopy
import time
from tqdm import tqdm
import pandas as pd
from datasets import load_dataset, load_from_disk
from sklearn.model_selection import train_test_split
import pytorch_lightning as pl
import torch
import warnings


from ..dataclass import (
    Events_PVS,
    Events_EDMS,
    SimpleObservation_PVS,
    SimpleObservation_EDMS,
    SimpleObservationAction_PVS,
    SimpleObservationAction_EDMS,
    SimpleObservationActionSequence_PVS,
    SimpleObservationActionSequence_EDMS,
)
from ..utils.file_utils import load_json, save_formatted_json
from ..env import PROJECT_DIR
from ..models.q_model_base import QModelBase
from ..modules.datamodule import DataModule
from ..application.q_values_movie import create_movie
from ..application.q_values_csv import save_q_values_to_csv
from .run_rlearn_config import (
    PreprocessObservationConfig,
    SplitTrainTestConfig,
    TrainAndTestConfig,
    VisualizeDataConfig,
)
from .run_rlearn_helpers import (
    build_training_config_for_preprocessed_data,
    prepare_class_weights,
    preprocess_split_datasets,
    resolve_latest_checkpoint_path,
    resolve_output_base_dir,
    resolve_resume_checkpoint_path,
    resolve_training_runtime,
)


logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

warnings.filterwarnings("ignore")


class rlearn_model_soccer:
    def __init__(
        self,
        state_def,
        model_name=None,
        config=None,
        seed=42,
        num_process=4,
        input_path=None,
        output_path=None,
    ):
        self.model_name = model_name
        self.state_def = state_def
        self.config = config
        self.seed = seed
        self.num_process = num_process
        self.input_path = input_path
        self.output_path = output_path

    def split_train_test(self, test_mode=False):
        # Load data into a Dataset

        output_dir = Path(self.output_path)
        # Set output directory
        if output_dir is None:
            output_dir = self.input_path
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if test_mode:
            game_ids = [str(p.name) for p in Path(self.input_path).glob("*") if p.is_dir() and p.name.isdigit()]
            if not game_ids:
                raise ValueError(f"No game directories found under input_path: {self.input_path}")

            train_dataset = load_dataset(
                "json",
                data_files=[str(Path(self.input_path) / f"{game_id}" / "events.jsonl") for game_id in game_ids],
                split="train",
                num_proc=self.num_process,
            )
        else:
            game_ids = [str(p.name) for p in Path(self.input_path).glob("*") if p.is_dir() and p.name.isdigit()]
            train_game_ids, test_val_game_ids = train_test_split(game_ids, test_size=0.5, random_state=self.seed)
            test_game_ids, val_game_ids = train_test_split(test_val_game_ids, test_size=0.1, random_state=self.seed)

            train_dataset = load_dataset(
                "json",
                data_files=[str(Path(self.input_path) / f"{game_id}" / "events.jsonl") for game_id in train_game_ids],
                split="train",
                num_proc=self.num_process,
            )
            valid_dataset = load_dataset(
                "json",
                data_files=[str(Path(self.input_path) / f"{game_id}" / "events.jsonl") for game_id in val_game_ids],
                split="train",
                num_proc=self.num_process,
            )
            test_dataset = load_dataset(
                "json",
                data_files=[str(Path(self.input_path) / f"{game_id}" / "events.jsonl") for game_id in test_game_ids],
                split="train",
                num_proc=self.num_process,
            )

            # Save the splits
            for split_name, split_dataset in zip(
                ["train", "validation", "test"],
                [train_dataset, valid_dataset, test_dataset],
            ):
                split_dataset.save_to_disk(output_dir / split_name)

            logging.info(f"Data splits saved in {output_dir}:")
            logging.info(f"Train: {len(train_dataset)}")
            logging.info(f"Validation: {len(valid_dataset)}")
            logging.info(f"Test: {len(test_dataset)}")

        # for debugging
        train_dataset.select(range(5)).save_to_disk(output_dir / "mini")

    def events2attacker_simple_observation_action_sequence(
        self, examples, min_frame_len_threshold: int = 30, max_frame_len_threshold: int = 500, num_offball_players: int = 3
    ) -> Dict[str, Any]:
        if self.state_def == "PVS":
            Events = Events_PVS
            SimpleObservation = SimpleObservation_PVS
            SimpleObservationAction = SimpleObservationAction_PVS
            SimpleObservationActionSequence = SimpleObservationActionSequence_PVS
        elif self.state_def == "EDMS":
            Events = Events_EDMS
            SimpleObservation = SimpleObservation_EDMS
            SimpleObservationAction = SimpleObservationAction_EDMS
            SimpleObservationActionSequence = SimpleObservationActionSequence_EDMS
        else:
            raise ValueError(f"Unsupported state definition: {self.state_def}")

        events_list = [Events.from_dict(dict(zip(examples, v))) for v in zip(*examples.values())]
        for events in events_list:
            assert min_frame_len_threshold <= len(events.events) <= max_frame_len_threshold, (
                f"len(events.events): {len(events.events)}"
            )
        attacker_observation_action_sequence = []
        for events in events_list:
            if self.state_def == "PVS":
                valid_attack_player_ids = [
                    player.player_id
                    for player in events.events[0].state.players
                    if player.player_role != "GK" and player.player_id > 0 and player.team_name == events.team_name_attack
                ]
            elif self.state_def == "EDMS":
                valid_attack_player_ids = [
                    player.player_id
                    for player in events.events[0].state.raw_state.players
                    if player.player_role != "GK" and player.player_id > 0 and player.team_name == events.team_name_attack
                ]
            else:
                raise ValueError(f"Unsupported state definition: {self.state_def}")

            if len(valid_attack_player_ids) != 10:
                logger.warning(
                    f"Found onlu {len(valid_attack_player_ids)} valid attack players in game_id: {events.game_id}, half: {events.half}, sequence_id: {events.sequence_id}. "
                )

            if self.state_def == "EDMS":
                onball_list = None
                previous_attack_team = events.team_name_attack
                onball_list = [0] * len(events.events)
                attack_action = ["pass", "dribble", "shot", "through_pass", "cross"]
                last_attack_index = -1

                for i, event in enumerate(events.events):
                    for player_index, player in enumerate(event.state.raw_state.players):
                        if player.action in attack_action:
                            onball_list[i] = player_index
                            current_team = player.team_name
                            if current_team == previous_attack_team and last_attack_index >= 0:
                                last_player_index = onball_list[last_attack_index]
                                for j in range(last_attack_index + 1, i):
                                    onball_list[j] = last_player_index
                            previous_attack_team = current_team
                            last_attack_index = i
                            break

            for number_of_player, target_player_id in enumerate(valid_attack_player_ids):
                attacker_observation_action_sequence_in_event = []

                for number_of_event, event in enumerate(events.events):
                    try:
                        if self.state_def == "PVS":
                            target_player = [
                                player for player in event.state.attack_players if player.player_id == target_player_id
                            ][0]
                        elif self.state_def == "EDMS":
                            target_player = [
                                player
                                for player in event.state.raw_state.attack_players
                                if player.player_id == target_player_id
                            ][0]
                        else:
                            raise ValueError(f"Unsupported state definition: {self.state_def}")
                    except (IndexError, Exception):
                        continue

                    if self.state_def == "PVS":
                        observation = SimpleObservation.from_state(event.state, target_player)
                    elif self.state_def == "EDMS":
                        gk_idx = next(
                            (i for i, player in enumerate(event.state.raw_state.attack_players) if player.player_role == "GK"),
                            -1,
                        )
                        observation = SimpleObservation.from_state(
                            event.state,
                            target_player,
                            target_player_id,
                            gk_idx,
                            number_of_player,
                            num_offball_players,
                            onball_list,
                            number_of_event,
                            self.state_def,
                        )
                    else:
                        raise ValueError(f"Unsupported state definition: {self.state_def}")

                    action = target_player.action
                    observation_action = SimpleObservationAction(
                        player=target_player, observation=observation, action=action, reward=event.reward
                    )
                    attacker_observation_action_sequence_in_event.append(observation_action)

                if attacker_observation_action_sequence_in_event:
                    attacker_observation_action_sequence.append(
                        {
                            "events": events,
                            "sequence": attacker_observation_action_sequence_in_event,
                        }
                    )
                else:
                    logger.warning(
                        f"Skipping empty attacker observation sequence in game_id: {events.game_id}, "
                        f"half: {events.half}, sequence_id: {events.sequence_id}, player_id: {target_player_id}."
                    )

        for item in attacker_observation_action_sequence:
            events = item["events"]
            observation_action_sequence = item["sequence"]
            if (
                observation_action_sequence
                and observation_action_sequence[0].observation.ego_player.team_name != events.team_name_attack
            ):
                logger.warning(
                    f"ego player is not attacker: {observation_action_sequence[0].observation.ego_player.team_name} "
                    f"(expected: {events.team_name_attack}) in game_id: {events.game_id}, "
                    f"half: {events.half}, sequence_id: {events.sequence_id}."
                )

        attacker_observation_action_sequence = [
            SimpleObservationActionSequence(
                game_id=item["events"].game_id,
                half=item["events"].half,
                sequence_id=item["events"].sequence_id,
                team_name_attack=item["events"].team_name_attack,
                team_name_defense=item["events"].team_name_defense,
                sequence=item["sequence"],
            ).to_dict()
            for item in attacker_observation_action_sequence
        ]

        if not attacker_observation_action_sequence:
            return {
                "game_id": [],
                "half": [],
                "sequence_id": [],
                "team_name_attack": [],
                "team_name_defense": [],
                "sequence": [],
            }

        return {
            key: [item[key] for item in attacker_observation_action_sequence]
            for key in attacker_observation_action_sequence[0].keys()
        }

    def preprocess_observation(self, batch_size):
        logging.info(f"input_path: {self.input_path}")
        start = time.time()
        config = load_json(self.config)
        dataset = load_from_disk(str(self.input_path))
        logger.info("Length of dataset: {}".format(len(dataset)))
        dataset = dataset.map(
            self.events2attacker_simple_observation_action_sequence,
            batched=True,
            remove_columns=dataset.column_names,
            num_proc=self.num_process,
            batch_size=batch_size,
            fn_kwargs={
                "min_frame_len_threshold": config["min_frame_len_threshold"],
                "max_frame_len_threshold": config["max_frame_len_threshold"],
                "num_offball_players": config["num_offball_players"],
            },
        )
        logger.info("Length of dataset after processing: {}".format(len(dataset)))
        dataset.save_to_disk(str(self.output_path))
        logging.info(f"output_path: {self.output_path} (elapsed: {time.time() - start:.2f} sec)")

    def train_and_test(
        self,
        exp_name,
        run_name,
        accelerator=None,
        devices=None,
        strategy=None,
        save_q_values_csv=False,
        max_games_csv=1,
        max_sequences_per_game_csv=5,
        save_intermediate_checkpoints=False,
        checkpoint_every_n_epochs=1,
        checkpoint_save_top_k=-1,
        test_mode=False,
        use_class_weights: bool | None = None,
        resume_checkpoint_path: str | None = None,
        output_base_dir: str | None = None,
        class_weight_only=False,
    ):
        pl.seed_everything(self.seed)
        exp_config = load_json(self.config)
        config_copy = deepcopy(exp_config)
        accelerator, devices, strategy = resolve_training_runtime(
            accelerator=accelerator,
            devices=devices,
            strategy=strategy,
            exp_config=exp_config,
            test_mode=test_mode,
        )
        resume_checkpoint_path = resolve_resume_checkpoint_path(
            resume_checkpoint_path=resume_checkpoint_path,
            logger=logger,
        )
        output_base_dir_path = resolve_output_base_dir(output_base_dir)

        output_dir = output_base_dir_path / exp_name / run_name
        output_dir.mkdir(exist_ok=True, parents=True)

        logger.info("loading dataset...")
        train_dataset = load_from_disk(Path(exp_config["dataset"]["train_filename"]).resolve())
        valid_dataset = None
        test_dataset = None
        if not class_weight_only:
            valid_dataset = load_from_disk(Path(exp_config["dataset"]["valid_filename"]).resolve())
            test_dataset = load_from_disk(Path(exp_config["dataset"]["test_filename"]).resolve())
        logger.info("Preprocessing dataset...")
        start = time.time()
        train_dataset = DataModule.by_name(exp_config["datamodule"]["type"]).preprocess_data(
            train_dataset, self.state_def, **exp_config["dataset"]["preprocess_config"]
        )
        if not class_weight_only:
            valid_dataset = DataModule.by_name(exp_config["datamodule"]["type"]).preprocess_data(
                valid_dataset, self.state_def, **exp_config["dataset"]["preprocess_config"]
            )
            test_dataset = DataModule.by_name(exp_config["datamodule"]["type"]).preprocess_data(
                test_dataset, self.state_def, **exp_config["dataset"]["preprocess_config"]
            )
        logger.info(f"Preprocessing dataset is done. {time.time() - start} sec")
        logger.info(f"Train dataset size: {len(train_dataset)}")
        if valid_dataset is not None:
            logger.info(f"Valid dataset size: {len(valid_dataset)}")
        if test_dataset is not None:
            logger.info(f"Test dataset size: {len(test_dataset)}")

        datamodule = DataModule.from_params(
            params_=exp_config["datamodule"],
            train_dataset=train_dataset,
            valid_dataset=valid_dataset,
            test_dataset=test_dataset,
        )
        class_weights = prepare_class_weights(
            exp_config=exp_config,
            datamodule=datamodule,
            use_class_weights=use_class_weights,
            logger=logger,
        )

        if class_weight_only:
            if class_weights is None:
                raise ValueError("class_weight_only=True requires `class_weight_fn` in exp config.")
            logger.info("class_weight_only=True: class weights prepared. Skipping training and testing.")
            return

        tensorboard_logger = pl.loggers.TensorBoardLogger(
            save_dir=str(output_base_dir_path / "tensorboard_logs"),
            name=run_name,
        )
        training_loggers = [tensorboard_logger]

        try:
            mlflow_logger = pl.loggers.MLFlowLogger(
                experiment_name=exp_name,
                run_name=run_name,
                save_dir=str(output_base_dir_path / "mlruns"),
            )
            training_loggers.append(mlflow_logger)
        except ModuleNotFoundError as exc:
            logger.warning(f"MLflow logger is disabled because dependency is missing: {exc}")

        checkpoint_filename = "{epoch:02d}-{step}-val_loss={val_loss:.4f}"
        if save_intermediate_checkpoints:
            checkpoint_callback = pl.callbacks.ModelCheckpoint(
                dirpath=output_dir / "checkpoints",
                monitor="val_loss",
                mode="min",
                every_n_epochs=checkpoint_every_n_epochs,
                save_top_k=checkpoint_save_top_k,
                filename=checkpoint_filename,
                auto_insert_metric_name=False,
                save_last=True,
                save_on_exception=True,
            )
        else:
            checkpoint_callback = pl.callbacks.ModelCheckpoint(
                dirpath=output_dir / "checkpoints",
                monitor="val_loss",
                mode="min",
                save_top_k=1,
                filename=checkpoint_filename,
                auto_insert_metric_name=False,
                save_last=True,
                save_on_exception=True,
            )
        callbacks = [checkpoint_callback]
        early_stopping_callback = pl.callbacks.EarlyStopping(
            monitor="val_loss",
            patience=5,
            mode="min",
            min_delta=0.01,
        )
        callbacks.append(early_stopping_callback)
        trainer = pl.Trainer(
            max_epochs=exp_config["max_epochs"],
            logger=training_loggers if training_loggers else False,
            callbacks=callbacks,
            accelerator=accelerator,
            devices=devices,
            strategy=strategy,
            deterministic=True,
            val_check_interval=exp_config["val_check_interval"] if "val_check_interval" in exp_config else None,
            detect_anomaly=False,
            accumulate_grad_batches=exp_config["accumulate_grad_batches"] if "accumulate_grad_batches" in exp_config else 1,
            gradient_clip_val=None,
            log_every_n_steps=1,
            enable_progress_bar=False,
        )

        params_ = {
            "type": exp_config["model"]["type"],
            "observation_dim": exp_config["model"]["observation_dim"],
            "sequence_encoder": exp_config["model"]["sequence_encoder"],
            "optimizer": exp_config["model"]["optimizer"],
            "vocab_size": datamodule.state_action_tokenizer.num_tokens,
            "pad_token_id": datamodule.state_action_tokenizer.encode("[PAD]"),
            "gamma": exp_config["model"]["gamma"],
            "lambda_": exp_config["model"]["lambda_"],
            "lambda2_": exp_config["model"]["lambda2_"],
            "class_weights": class_weights,
            "offball_action_idx": exp_config["offball_action_idx"],
            "onball_action_idx": exp_config["onball_action_idx"],
        }
        params_.update(
            {
                key: exp_config["model"][key]
                for key in (
                    "n_agents",
                    "state_dim",
                    "action_dim",
                    "mixer_network",
                    "tau",
                    "target_update_interval",
                )
                if key in exp_config["model"]
            }
        )
        params_["class_weights"] = params_["class_weights"].tolist() if params_["class_weights"] is not None else None

        model = QModelBase.from_params(params_=params_)

        if resume_checkpoint_path is None:
            logger.info("Starting training from scratch.")
        else:
            logger.info(f"Starting training by resuming from checkpoint: {resume_checkpoint_path}")

        trainer.fit(model=model, datamodule=datamodule, ckpt_path=resume_checkpoint_path)
        
        if checkpoint_callback.best_model_path:
            best_ckpt_src = Path(checkpoint_callback.best_model_path)
            best_ckpt_dst = output_dir / "checkpoints" / f"best-{best_ckpt_src.stem}.ckpt"
            if best_ckpt_src.resolve() != best_ckpt_dst.resolve():
                shutil.copy2(best_ckpt_src, best_ckpt_dst)
            logger.info(f"Best checkpoint: {best_ckpt_src} (alias: {best_ckpt_dst})")
        else:
            logger.warning("Best checkpoint was not created. Check ModelCheckpoint settings.")
            
        trainer.test(model=model, dataloaders=datamodule.test_dataloader())
        save_formatted_json(config_copy, output_dir / "config.json")

        # Save Q-values to CSV if requested
        if save_q_values_csv:
            model_name = self.config.split("/")[-1].split(".")[0]
            save_dir = output_base_dir_path / "figures" / model_name
            save_q_values_to_csv(
                model=model,
                datamodule=datamodule,
                state_def=self.state_def,
                output_dir=save_dir,
                max_games=max_games_csv,
                max_sequences_per_game=max_sequences_per_game_csv,
            )

    def visualize_data(
        self,
        model_name,
        exp_config_path,
        checkpoint_path,
        tracking_file_path,
        match_id,
        sequence_id,
        test_mode=False,
        viz_style="radar",
        movie_output_dir=None,
        keep_frames=True,
    ):
        exp_config = load_json(exp_config_path)
        test_file_path = Path(exp_config["dataset"]["test_filename"]).resolve()
        test_dataset = load_from_disk(test_file_path)
        test_dataset = DataModule.by_name(exp_config["datamodule"]["type"]).preprocess_data(
            test_dataset, self.state_def, **exp_config["dataset"]["preprocess_config"]
        )

        print(f"start loading {match_id} {sequence_id}")

        datamodule = DataModule.from_params(
            exp_config["datamodule"],
            train_dataset=test_dataset,
            valid_dataset=None,
            test_dataset=None,
        )

        type_ = exp_config["model"]["type"]
        observation_dim = exp_config["model"]["observation_dim"]
        sequence_encoder = exp_config["model"]["sequence_encoder"]
        optimizer = exp_config["model"]["optimizer"]
        params_ = {
            "type": type_,
            "observation_dim": observation_dim,
            "sequence_encoder": sequence_encoder,
            "vocab_size": datamodule.state_action_tokenizer.num_tokens,
            "optimizer": optimizer,
            "gamma": exp_config["model"]["gamma"],
            "lambda_": exp_config["model"]["lambda_"],
            "lambda2_": exp_config["model"]["lambda2_"],
        }
        params_.update(
            {
                key: exp_config["model"][key]
                for key in (
                    "n_agents",
                    "state_dim",
                    "action_dim",
                    "mixer_network",
                    "tau",
                    "target_update_interval",
                )
                if key in exp_config["model"]
            }
        )
        model = QModelBase.from_params(params_=params_)
        checkpoint = (
            torch.load(checkpoint_path, weights_only=False)
            if not test_mode
            else torch.load(checkpoint_path, weights_only=False, map_location=torch.device("cpu"))
        )
        state_dict = checkpoint["state_dict"]
        model.load_state_dict(state_dict)
        model.eval()

        # Auto-detect device
        device = "cuda" if torch.cuda.is_available() and not test_mode else "cpu"
        model.to(device)

        q_values_list = []

        for data, batch in tqdm(
            zip(datamodule.train_dataset, datamodule.train_dataloader(batch_size=1, shuffle=False)),
            total=len(datamodule.train_dataset),
        ):
            q_values_df = pd.DataFrame(
                index=range(len(data["sequence"])),
                columns=[
                    "game_id",
                    "sequence_id",
                    "frame_num",
                    "team_name",
                    "player_name",
                    "q_value",
                    "action_idx",
                    "q_values_for_actions",
                ],
            )
            q_values_df_path = (
                PROJECT_DIR / f"output/figures/{model_name}/players_q_state/q_values_{match_id}_{sequence_id}.csv"
            )
            q_values_df_path.parent.mkdir(parents=True, exist_ok=True)

            if data["game_id"] == match_id and data["sequence_id"] == sequence_id:
                player = data["sequence"][0]["player"]
                q_values = (
                    model(datamodule.transfer_batch_to_device(batch, device, 0)).squeeze(0).detach().cpu()
                )  # (seq_len, num_actions)
                action_idx = batch["action"].squeeze(0)  # (seq_len, )

                # gather q_values for the actions taken
                q_values_for_actions = q_values.gather(1, action_idx.unsqueeze(1)).squeeze(1).tolist()  # len = seq_len

                for i, _ in enumerate(data["sequence"]):
                    q_values_df.loc[i, "game_id"] = data["game_id"]
                    q_values_df.loc[i, "sequence_id"] = data["sequence_id"]
                    q_values_df.loc[i, "frame_num"] = i
                    q_values_df.loc[i, "player_name"] = player["player_name"]
                    q_values_df.loc[i, "q_value"] = q_values[i, :]
                    q_values_df.loc[i, "action_idx"] = action_idx[i]
                    q_values_df.loc[i, "q_values_for_actions"] = q_values_for_actions[i]

            else:
                continue

            q_values_list.append(q_values_df)

            final_q_values_df = pd.concat(q_values_list, ignore_index=True)
            final_q_values_df.to_csv(q_values_df_path, index=False)

        create_movie(
            q_values_path=q_values_df_path,
            match_id=match_id,
            sequence_id=sequence_id,
            tracking_file_path=tracking_file_path,
            output_dir=movie_output_dir,
            test_mode=test_mode,
            viz_style=viz_style,
            keep_frames=keep_frames,
        )

    def run_rlearn(
        self,
        run_split_train_test=False,
        run_preprocess_observation=False,
        run_train_and_test=False,
        run_visualize_data=False,
        split_config: SplitTrainTestConfig | None = None,
        preprocess_config: PreprocessObservationConfig | None = None,
        train_and_test_config: TrainAndTestConfig | None = None,
        visualize_config: VisualizeDataConfig | None = None,
    ):
        """Run the selected pipeline steps with step-specific configuration."""
        # Store original paths
        original_input_path = self.input_path
        original_output_path = self.output_path
        original_config = self.config
        split_config = split_config or SplitTrainTestConfig()
        preprocess_config = preprocess_config or PreprocessObservationConfig()
        train_and_test_config = train_and_test_config or TrainAndTestConfig()
        visualize_config = visualize_config or VisualizeDataConfig()
        preprocessed_output_base = None

        if run_split_train_test:
            self.split_train_test(test_mode=split_config.test_mode)

        if run_preprocess_observation:
            if run_split_train_test and original_input_path and original_output_path:
                preprocessed_output_base = preprocess_split_datasets(
                    model=self,
                    original_output_path=original_output_path,
                    preprocess_config=preprocess_config,
                    logger=logger,
                )
            else:
                self.preprocess_observation(batch_size=preprocess_config.batch_size)
                preprocessed_output_base = self.output_path

        if run_train_and_test:
            if not train_and_test_config.exp_config_path:
                raise ValueError("exp_config_path must be provided when running training.")

            if run_preprocess_observation:
                if preprocessed_output_base is None:
                    raise ValueError("preprocessed_output_base must be available when run_preprocess_observation=True.")
                self.config = build_training_config_for_preprocessed_data(
                    exp_config_path=train_and_test_config.exp_config_path,
                    preprocessed_output_base=preprocessed_output_base,
                    test_mode=train_and_test_config.test_mode,
                )
            else:
                self.config = train_and_test_config.exp_config_path

            self.train_and_test(
                exp_name=train_and_test_config.exp_name,
                run_name=train_and_test_config.run_name,
                accelerator=train_and_test_config.accelerator,
                devices=train_and_test_config.devices,
                strategy=train_and_test_config.strategy,
                use_class_weights=train_and_test_config.use_class_weights,
                output_base_dir=train_and_test_config.output_base_dir,
                save_q_values_csv=train_and_test_config.save_q_values_csv,
                max_games_csv=train_and_test_config.max_games_csv,
                max_sequences_per_game_csv=train_and_test_config.max_sequences_per_game_csv,
                save_intermediate_checkpoints=train_and_test_config.save_intermediate_checkpoints,
                checkpoint_every_n_epochs=train_and_test_config.checkpoint_every_n_epochs,
                checkpoint_save_top_k=train_and_test_config.checkpoint_save_top_k,
                resume_checkpoint_path=train_and_test_config.resume_checkpoint_path,
                test_mode=train_and_test_config.test_mode,
                class_weight_only=train_and_test_config.class_weight_only,
            )

            if run_visualize_data and visualize_config.checkpoint_path is None:
                visualize_config.checkpoint_path = resolve_latest_checkpoint_path(
                    exp_name=train_and_test_config.exp_name,
                    run_name=train_and_test_config.run_name,
                    output_base_dir=train_and_test_config.output_base_dir,
                    logger=logger,
                )

        if run_visualize_data:
            visualization_exp_config_path = visualize_config.exp_config_path
            if run_train_and_test:
                visualization_exp_config_path = self.config

            if not visualize_config.checkpoint_path:
                logger.warning("No checkpoint path specified and none found. Skipping visualization.")
            elif visualization_exp_config_path is None:
                logger.warning("No experiment config path available for visualization. Skipping visualization.")
            else:
                self.visualize_data(
                    model_name=visualize_config.model_name,
                    exp_config_path=visualization_exp_config_path,
                    checkpoint_path=visualize_config.checkpoint_path,
                    tracking_file_path=visualize_config.tracking_file_path,
                    match_id=visualize_config.match_id,
                    sequence_id=visualize_config.sequence_id,
                    test_mode=visualize_config.test_mode,
                    viz_style=visualize_config.viz_style,
                    movie_output_dir=visualize_config.movie_output_dir,
                    keep_frames=visualize_config.keep_frames,
                )

        # Restore original paths
        self.input_path = original_input_path
        self.output_path = original_output_path
        self.config = original_config


if __name__ == "__main__":
    pass
    # rlearn_model_soccer(
    #     state_def="PVS",
    #     input_path=os.getcwd() + "/test/sports/rlearn_data/data/datafactory/preprocess_data/",
    #     output_path=os.getcwd() + "/test/sports/rlearn_data/data/datafactory/preprocess_data/split/",
    # ).run_rlearn(
    #     run_split_train_test=True,
    #     split_config=SplitTrainTestConfig(),
    # )

    # rlearn_model_soccer(
    #     state_def="PVS",
    #     config=os.getcwd() + "/test/config/preprocessing_datafactory.json",
    #     input_path=os.getcwd() + "/test/sports/rlearn_data/data/datafactory/preprocess_data/split/mini",
    #     output_path=os.getcwd() + "/test/sports/rlearn_data/data/datafactory_simple_obs_action_seq/split/mini",
    #     num_process=5,
    # ).run_rlearn(
    #     run_preprocess_observation=True,
    #     preprocess_config=PreprocessObservationConfig(),
    # )

    # Pattern 1: initial run
    # rlearn_model_soccer(
    #     state_def="PVS",
    #     config=os.getcwd() + "/test/config/exp_config.json",
    # ).run_rlearn(
    #     run_train_and_test=True,
    #     train_and_test_config=TrainAndTestConfig(
    #         exp_config_path=os.getcwd() + "/test/config/exp_config.json",
    #         exp_name="sarsa_attacker",
    #         run_name="test",
    #         accelerator=None,
    #         devices=None,
    #         strategy=None,
    #         use_class_weights=False,
    #         save_q_values_csv=True,
    #         max_games_csv=1,
    #         max_sequences_per_game_csv=5,
    #     ),
    # )

    # Pattern 2: reuse cached class weights
    # rlearn_model_soccer(
    #     state_def="PVS",
    #     config=os.getcwd() + "/test/config/exp_config.json",
    # ).run_rlearn(
    #     run_train_and_test=True,
    #     train_and_test_config=TrainAndTestConfig(
    #         exp_config_path=os.getcwd() + "/test/config/exp_config.json",
    #         exp_name="sarsa_attacker",
    #         run_name="test",
    #         accelerator=None,
    #         devices=None,
    #         strategy=None,
    #         use_class_weights=True,
    #         save_q_values_csv=True,
    #         max_games_csv=1,
    #         max_sequences_per_game_csv=5,
    #     ),
    # )

    # Pattern 3: resume from last.ckpt
    # rlearn_model_soccer(
    #     state_def="PVS",
    #     config=os.getcwd() + "/test/config/exp_config.json",
    # ).run_rlearn(
    #     run_train_and_test=True,
    #     train_and_test_config=TrainAndTestConfig(
    #         exp_config_path=os.getcwd() + "/test/config/exp_config.json",
    #         exp_name="sarsa_attacker",
    #         run_name="test",
    #         accelerator=None,
    #         devices=None,
    #         strategy=None,
    #         resume_checkpoint_path=os.getcwd() + "/rlearn/sports/output/sarsa_attacker/test/checkpoints/last.ckpt",
    #         save_intermediate_checkpoints=True,
    #         use_class_weights=True,
    #         save_q_values_csv=True,
    #         max_games_csv=1,
    #         max_sequences_per_game_csv=5,
    #     ),
    # )

    # rlearn_model_soccer(
    #     state_def="PVS",
    # ).run_rlearn(
    #     run_visualize_data=True,
    #     visualize_config=VisualizeDataConfig(
    #         model_name="exp_config",
    #         exp_config_path=os.getcwd() + "/test/config/exp_config.json",
    #         checkpoint_path=os.getcwd() + "/rlearn/sports/output/sarsa_attacker/test/checkpoints/epoch=9-step=10.ckpt",
    #         tracking_file_path=os.getcwd() + "/test/sports/rlearn_data/data/datafactory/preprocess_data/0001/events.jsonl",
    #         match_id="0001",
    #         sequence_id=0,
    #         viz_style="bar",
    #     ),
    # )
