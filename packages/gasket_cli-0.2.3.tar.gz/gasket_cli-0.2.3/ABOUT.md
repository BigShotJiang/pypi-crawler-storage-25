# gasket-cli

Short description here — Run GitHub Actions workflows locally using [nektos/act](https://github.com/nektos/act).

---

## 🚀 Usage

### `run-act`

Run GitHub Actions workflows locally.

```bash
gasket run-act                              # Run push event workflows
gasket run-act --event pull_request         # Run pull_request workflows
gasket run-act --list                       # List available workflows
gasket run-act --dry-run                    # Dry run only
gasket run-act -j test                      # Run specific job
gasket run-act -W .github/workflows/ci.yml  # Run specific workflow
gasket run-act -s MY_SECRET=value           # Pass secrets
gasket run-act --secret-file=.secrets       # Load secrets from file
gasket run-act --env-file=.env              # Load environment variables from file
gasket run-act -P ubuntu-latest=node:16-buster-slim  # Platform override
```

#### Options

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `--event` / `-e` | Choice | `push` | Event type: `push`, `pull_request`, `workflow_dispatch`, `schedule`, `release` |
| `--workflow` / `-W` | Path | None | Specific workflow file or directory |
| `--job` / `-j` | String | None | Specific job name to run |
| `--secret` / `-s` | String | None | Secret in KEY=VALUE format (repeatable) |
| `--secret-file` | Path | None | Path to secrets file (.env format) |
| `--var` | String | None | Variable in KEY=VALUE format (repeatable) |
| `--var-file` | Path | None | Path to variables file |
| `--input` | String | None | Input in KEY=VALUE format for workflow_dispatch (repeatable) |
| `--input-file` | Path | None | Path to inputs file |
| `--event-file` | Path | None | Path to event JSON payload file |
| `--platform` / `-P` | String | None | Platform override RUNNER=IMAGE (repeatable) |
| `--env` | String | None | Environment variable KEY=VALUE (repeatable) |
| `--env-file` | Path | None | Path to env file |
| `--matrix` | String | None | Matrix filter KEY:VALUE (repeatable) |
| `--container-architecture` | String | None | Container architecture (e.g. `linux/amd64`) |
| `--artifact-server-path` | Path | None | Path to enable artifact server |
| `--dry-run` / `-n` | Flag | `False` | Dry run mode |
| `--list` / `-l` | Flag | `False` | List workflows without running |
| `--verbose` / `-v` | Flag | `False` | Verbose output |
| `--offline` | Flag | `False` | Use cached actions (offline mode) |
| `--timeout` | Integer | `600` | Timeout in seconds |

---

### `setup`

Manage installation and prerequisites.

```bash
gasket setup check                 # Check all prerequisites
gasket setup check --format json   # JSON output
gasket setup install-act           # Download and install act
gasket setup install-act --force   # Force reinstall
gasket setup install-all           # Install everything + verify
gasket setup uninstall-act         # Remove act binary
```