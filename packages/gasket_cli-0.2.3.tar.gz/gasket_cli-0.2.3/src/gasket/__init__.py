"""Gasket - Run GitHub Actions locally using nektos/act."""

from __future__ import annotations

__version__ = "0.2.3"
