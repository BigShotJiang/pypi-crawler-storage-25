"""Tests for runtm-cli."""
