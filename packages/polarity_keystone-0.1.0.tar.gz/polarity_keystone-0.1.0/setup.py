from setuptools import setup, find_packages

setup(
    name="polarity-keystone",
    version="0.1.0",
    description="Python SDK client for the Keystone API",
    author="Polarity",
    packages=find_packages(),
    python_requires=">=3.9",
    # Zero external dependencies -- uses only urllib.request.
)
