"""Alert operations for the Keystone SDK."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from ._http import HTTPClient
from .types import AlertRule


class AlertService:
    """CRUD operations for Keystone alert rules."""

    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def create(
        self,
        name: str,
        condition: str,
        notify: str = "webhook",
        *,
        eval_id: Optional[str] = None,
        window: Optional[str] = None,
        webhook_url: Optional[str] = None,
        id: Optional[str] = None,
    ) -> AlertRule:
        """Create a new alert rule.

        Args:
            name: Human-readable alert name.
            condition: Condition expression (e.g. ``"pass_rate < 0.8"``).
            notify: Notification channel (default ``"webhook"``).
            eval_id: Optional eval ID to scope the alert to.
            window: Optional window (e.g. ``"last_5_runs"``).
            webhook_url: URL to POST when the alert fires.
            id: Optional explicit ID; the server generates one if omitted.
        """
        body: Dict[str, Any] = {
            "name": name,
            "condition": condition,
            "notify": notify,
        }
        if id is not None:
            body["id"] = id
        if eval_id is not None:
            body["eval_id"] = eval_id
        if window is not None:
            body["window"] = window
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        data = self._http.post("/v1/alerts", body)
        return AlertRule.from_dict(data)

    def list(self) -> List[AlertRule]:
        """List all alert rules."""
        data = self._http.get("/v1/alerts")
        if data is None:
            return []
        return [AlertRule.from_dict(item) for item in data]

    def delete(self, alert_id: str) -> None:
        """Delete an alert rule by ID."""
        self._http.delete(f"/v1/alerts/{alert_id}")
