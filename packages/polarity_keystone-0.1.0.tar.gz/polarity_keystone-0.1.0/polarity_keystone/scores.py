"""Scoring functions for Keystone experiments.

Built-in scorers map to spec invariant check types. Custom scorers are
Python functions that run client-side after the experiment completes.

Usage::

    from polarity_keystone import Keystone
    from polarity_keystone.scores import (
        FileExists, FileContains, CommandExits, SQLEquals,
        LLMJudge, Score, Scorer,
    )

    ks = Keystone()

    # Built-in scorers — these become spec invariants on the server
    scores = [
        FileExists("hello.py"),
        FileContains("output.txt", contains="Hello"),
        CommandExits("python hello.py", exit_code=0),
        SQLEquals(service="db", query="SELECT count(*) FROM drift", equals=0),
        LLMJudge(criteria="Is the code clean?", model="paragon-fast"),
    ]

    # Custom scorer — runs client-side on the results
    @Scorer
    def check_output(result):
        return 1.0 if "Hello" in result.agent_output else 0.0

    results = ks.experiments.run_and_wait(exp.id, scores=[*scores, check_output])
"""

from __future__ import annotations

import functools
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union


# ---------------------------------------------------------------------------
# Score result
# ---------------------------------------------------------------------------

@dataclass
class Score:
    """A single score produced by a scorer."""
    name: str
    score: float  # 0.0 - 1.0
    passed: bool = True
    message: str = ""
    metadata: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Scorer protocol
# ---------------------------------------------------------------------------

class BaseScorer:
    """Base class for all scorers."""

    name: str = ""
    weight: float = 1.0
    gate: bool = False

    def to_invariant(self) -> Optional[Dict[str, Any]]:
        """Convert to a spec invariant dict, or None if this scorer runs client-side."""
        return None

    def score_result(self, scenario: Any) -> Optional[Score]:
        """Run client-side scoring on a ScenarioResult. Override for custom scorers."""
        return None


# ---------------------------------------------------------------------------
# Built-in scorers — these convert to spec invariants
# ---------------------------------------------------------------------------

class FileExists(BaseScorer):
    """Check that a file exists in the workspace."""

    def __init__(self, path: str, *, weight: float = 1.0, gate: bool = False):
        self.name = f"file_exists:{path}"
        self.path = path
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        return {
            "description": f"{self.path} exists",
            "weight": self.weight,
            "gate": self.gate,
            "check": {"type": "file_exists", "path": self.path},
        }


class FileContains(BaseScorer):
    """Check that a file contains a string or matches a pattern."""

    def __init__(
        self,
        path: str,
        *,
        contains: Optional[str] = None,
        not_contains: Optional[str] = None,
        pattern: Optional[str] = None,
        weight: float = 1.0,
        gate: bool = False,
    ):
        self.name = f"file_content:{path}"
        self.path = path
        self.contains = contains
        self.not_contains = not_contains
        self.pattern = pattern
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        check: Dict[str, Any] = {"type": "file_content", "path": self.path}
        if self.contains:
            check["contains"] = self.contains
        if self.not_contains:
            check["not_contains"] = self.not_contains
        if self.pattern:
            check["pattern"] = self.pattern
        return {
            "description": f"{self.path} content check",
            "weight": self.weight,
            "gate": self.gate,
            "check": check,
        }


class CommandExits(BaseScorer):
    """Check that a command exits with a specific code."""

    def __init__(
        self, command: str, *, exit_code: int = 0, weight: float = 1.0, gate: bool = False
    ):
        self.name = f"command:{command[:30]}"
        self.command = command
        self.exit_code = exit_code
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        return {
            "description": f"command exits {self.exit_code}",
            "weight": self.weight,
            "gate": self.gate,
            "check": {
                "type": "command_exit",
                "command": self.command,
                "exit_code": self.exit_code,
            },
        }


class SQLEquals(BaseScorer):
    """Check that a SQL query returns an expected value."""

    def __init__(
        self,
        *,
        service: str,
        query: str,
        equals: Any,
        weight: float = 1.0,
        gate: bool = False,
    ):
        self.name = f"sql:{service}"
        self.service = service
        self.query = query
        self.equals = equals
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        return {
            "description": f"SQL check on {self.service}",
            "weight": self.weight,
            "gate": self.gate,
            "check": {
                "type": "sql",
                "service": self.service,
                "query": self.query,
                "equals": self.equals,
            },
        }


class LLMJudge(BaseScorer):
    """Use an LLM to judge the agent's output."""

    def __init__(
        self,
        criteria: str,
        *,
        model: str = "paragon-fast",
        input_from: str = "workspace",
        rubric: Optional[Dict[str, str]] = None,
        temperature: float = 0,
        weight: float = 1.0,
        gate: bool = False,
    ):
        self.name = "llm_judge"
        self.criteria = criteria
        self.model = model
        self.input_from = input_from
        self.rubric = rubric
        self.temperature = temperature
        self.weight = weight
        self.gate = gate

    def to_invariant(self) -> Dict[str, Any]:
        check: Dict[str, Any] = {
            "type": "llm_as_judge",
            "model": self.model,
            "criteria": self.criteria,
            "input_from": self.input_from,
            "temperature": self.temperature,
        }
        if self.rubric:
            check["rubric"] = self.rubric
        return {
            "description": self.criteria[:80],
            "weight": self.weight,
            "gate": self.gate,
            "check": check,
        }


# ---------------------------------------------------------------------------
# Custom scorer — wraps a user function
# ---------------------------------------------------------------------------

class _CustomScorer(BaseScorer):
    """Wraps a user-defined function as a client-side scorer."""

    def __init__(self, fn: Callable, name: str, weight: float, gate: bool):
        self.fn = fn
        self.name = name
        self.weight = weight
        self.gate = gate

    def score_result(self, scenario: Any) -> Optional[Score]:
        try:
            result = self.fn(scenario)
            if isinstance(result, Score):
                return result
            if isinstance(result, (int, float)):
                return Score(
                    name=self.name,
                    score=float(result),
                    passed=float(result) >= 0.5,
                )
            if isinstance(result, bool):
                return Score(
                    name=self.name,
                    score=1.0 if result else 0.0,
                    passed=result,
                )
            return None
        except Exception as e:
            return Score(
                name=self.name,
                score=0.0,
                passed=False,
                message=f"scorer error: {e}",
            )


def Scorer(
    fn: Optional[Callable] = None,
    *,
    name: Optional[str] = None,
    weight: float = 1.0,
    gate: bool = False,
) -> Union[_CustomScorer, Callable]:
    """Decorator to create a custom client-side scorer from a function.

    The function receives a ``ScenarioResult`` and returns a float (0-1),
    a bool, or a ``Score`` object.

    Usage::

        @Scorer
        def my_check(result):
            return 1.0 if result.exit_code == 0 else 0.0

        @Scorer(name="custom-name", weight=0.5, gate=True)
        def critical_check(result):
            return "expected" in (result.agent_output or "")
    """
    if fn is not None:
        return _CustomScorer(fn, name=name or fn.__name__, weight=weight, gate=gate)

    def decorator(f: Callable) -> _CustomScorer:
        return _CustomScorer(f, name=name or f.__name__, weight=weight, gate=gate)
    return decorator


# ---------------------------------------------------------------------------
# Helpers for the experiment service
# ---------------------------------------------------------------------------

def scorers_to_invariants(scorers: List[BaseScorer]) -> Dict[str, Any]:
    """Convert built-in scorers to a dict of spec invariants."""
    invariants = {}
    for scorer in scorers:
        inv = scorer.to_invariant()
        if inv is not None:
            key = scorer.name.replace(":", "_").replace("/", "_").replace(" ", "_")
            invariants[key] = inv
    return invariants


def run_client_scorers(
    scorers: List[BaseScorer], scenario: Any
) -> List[Score]:
    """Run client-side scorers against a scenario result."""
    results = []
    for scorer in scorers:
        score = scorer.score_result(scenario)
        if score is not None:
            results.append(score)
    return results
