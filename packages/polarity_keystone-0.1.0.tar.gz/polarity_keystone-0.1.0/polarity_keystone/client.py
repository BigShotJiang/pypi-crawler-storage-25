"""Main Keystone client."""

from __future__ import annotations

import os
from typing import Optional

from ._http import HTTPClient
from .agents import AgentService
from .alerts import AlertService
from .datasets import DatasetService
from .experiments import ExperimentService
from .sandboxes import SandboxService
from .scoring import ScoringService
from .specs import SpecService


class Keystone:
    """Client for the Keystone API.

    Example::

        from polarity_keystone import Keystone

        ks = Keystone(api_key="sk-...")

        # Upload a spec and run an experiment.
        spec = ks.specs.create_from_file("eval.yaml")
        exp = ks.experiments.create("nightly", spec.id)
        results = ks.experiments.run_and_wait(exp.id)

        print(f"Pass rate: {results.metrics.pass_rate:.0%}")

    Args:
        api_key: API key for authentication. Falls back to the
            ``KEYSTONE_API_KEY`` environment variable.
        base_url: Base URL of the Keystone server (default
            ``https://keystone.ngrok-free.dev``).
        timeout: HTTP request timeout in seconds (default 30).
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://keystone.ngrok-free.dev",
        timeout: int = 30,
    ) -> None:
        resolved_key = api_key or os.environ.get("KEYSTONE_API_KEY")
        http = HTTPClient(base_url, resolved_key, timeout)
        self._http = http

        self.sandboxes = SandboxService(http)
        self.specs = SpecService(http)
        self.experiments = ExperimentService(http)
        self.alerts = AlertService(http)
        self.agents = AgentService(http)
        self.datasets = DatasetService(http)
        self.scoring = ScoringService(http)

    def wrap(self, client: object, sandbox_id: str) -> object:
        """Wrap an LLM client to auto-report tool calls to Keystone.

        Monkey-patches the client's ``create()`` method so that every LLM
        call automatically sends trace events to the specified sandbox.
        Supports Anthropic (``client.messages.create``) and OpenAI
        (``client.chat.completions.create``) clients, both sync and async.

        The original response is always returned unchanged.  If trace
        reporting fails, the error is silently ignored.

        Args:
            client: An Anthropic or OpenAI client instance.
            sandbox_id: The Keystone sandbox ID to report traces to.

        Returns:
            The same client object, now instrumented.

        Example::

            from anthropic import Anthropic
            from polarity_keystone import Keystone

            ks = Keystone(api_key="ks_live_...")
            anthropic = ks.wrap(Anthropic(), sandbox_id="sb-xxx")
            # anthropic.messages.create() now auto-reports to Keystone
        """
        from .wrap import wrap_client
        return wrap_client(client, sandbox_id, self._http)

    @classmethod
    def from_sandbox(cls) -> tuple["Keystone", "Sandbox"]:
        """Create a client from the environment variables that Keystone injects
        into agent processes and return the current sandbox with its services.

        Reads ``KEYSTONE_BASE_URL``, ``KEYSTONE_API_KEY``, and
        ``KEYSTONE_SANDBOX_ID`` from the environment.

        Example::

            from polarity_keystone import Keystone

            ks, sb = Keystone.from_sandbox()
            db = sb.services["db"]  # ServiceInfo(host, port, ready)

        Raises:
            KeystoneError: If ``KEYSTONE_SANDBOX_ID`` is not set.
        """
        from .types import KeystoneError, Sandbox

        sandbox_id = os.environ.get("KEYSTONE_SANDBOX_ID")
        if not sandbox_id:
            raise KeystoneError(0, "KEYSTONE_SANDBOX_ID not set — not running inside a sandbox")
        base_url = os.environ.get("KEYSTONE_BASE_URL", "https://keystone.ngrok-free.dev")
        ks = cls(base_url=base_url)
        sb = ks.sandboxes.get(sandbox_id)
        return ks, sb

    def init_tracing(self, sandbox_id: str) -> None:
        """Initialize tracing for the current thread.

        After calling this, any function decorated with ``@traced`` will
        auto-report spans (start, end, duration, errors) to Keystone.

        Args:
            sandbox_id: The sandbox to report traces to.

        Example::

            from polarity_keystone import Keystone, traced

            ks = Keystone()
            ks.init_tracing(sandbox_id="sb-xxx")

            @traced
            def write_file(path, content):
                ...  # duration + errors auto-captured
        """
        from .tracing import init_tracing
        init_tracing(self._http, sandbox_id)

    def health(self) -> dict:
        """Check server health.

        Returns:
            A dict like ``{"status": "ok"}``.
        """
        return self._http.get("/health")
