"""Tracing primitives — ``@traced`` decorator and context manager.

Wrap any function with ``@traced`` to auto-capture input, output, duration,
and errors as a trace span. Nesting is automatic via thread-local context.

Usage::

    from polarity_keystone import Keystone, traced

    ks = Keystone()
    ks.init_tracing(sandbox_id="sb-xxx")

    @traced
    def write_file(path: str, content: str):
        with open(path, "w") as f:
            f.write(content)

    @traced
    def run_command(cmd: str) -> str:
        import subprocess
        return subprocess.check_output(cmd, shell=True).decode()

    # Context manager form:
    with traced(name="custom-step"):
        do_work()
"""

from __future__ import annotations

import functools
import json
import threading
import time
import traceback
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Callable, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from ._http import HTTPClient

# Thread-local storage for span context propagation.
_context = threading.local()


def _get_http() -> "Optional[HTTPClient]":
    return getattr(_context, "http", None)


def _get_sandbox_id() -> Optional[str]:
    return getattr(_context, "sandbox_id", None)


def _get_parent_span() -> Optional[str]:
    return getattr(_context, "current_span_id", None)


def _set_parent_span(span_id: Optional[str]) -> Optional[str]:
    prev = getattr(_context, "current_span_id", None)
    _context.current_span_id = span_id
    return prev


def init_tracing(http: "HTTPClient", sandbox_id: str) -> None:
    """Initialize tracing for the current thread. Called by Keystone.init_tracing()."""
    _context.http = http
    _context.sandbox_id = sandbox_id
    _context.current_span_id = None


def _post_event(event: dict) -> None:
    """Fire-and-forget post of a single trace event."""
    http = _get_http()
    sandbox_id = _get_sandbox_id()
    if http is None or sandbox_id is None:
        return

    def _send():
        try:
            http.post(f"/v1/sandboxes/{sandbox_id}/trace", {"events": [event]})
        except Exception:
            pass

    t = threading.Thread(target=_send, daemon=True)
    t.start()


def _make_span_id() -> str:
    import uuid
    return uuid.uuid4().hex[:16]


class _TracedContextManager:
    """Context manager that captures a span."""

    def __init__(self, name: str) -> None:
        self.name = name
        self.span_id = _make_span_id()
        self.parent_span_id: Optional[str] = None
        self._prev_span: Optional[str] = None
        self._start: float = 0
        self._output: Any = None

    def set_output(self, output: Any) -> None:
        """Manually set the span output."""
        self._output = output

    def __enter__(self) -> "_TracedContextManager":
        self.parent_span_id = _get_parent_span()
        self._prev_span = _set_parent_span(self.span_id)
        self._start = time.time()

        _post_event({
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_type": "tool_call",
            "tool": self.name,
            "phase": "start",
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id or "",
            "status": "ok",
        })
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        duration_ms = int((time.time() - self._start) * 1000)
        _set_parent_span(self._prev_span)

        status = "ok"
        error_type = ""
        output = ""
        if exc_val is not None:
            status = "error"
            error_type = "tool_error"
            output = f"{type(exc_val).__name__}: {exc_val}"
        elif self._output is not None:
            try:
                output = json.dumps(self._output) if not isinstance(self._output, str) else self._output
            except (TypeError, ValueError):
                output = str(self._output)

        _post_event({
            "ts": datetime.now(timezone.utc).isoformat(),
            "event_type": "tool_call",
            "tool": self.name,
            "phase": "end",
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id or "",
            "duration_ms": duration_ms,
            "status": status,
            "error_type": error_type,
            "output": output,
        })
        return None  # don't suppress exceptions


def traced(fn: Optional[Callable] = None, *, name: Optional[str] = None):
    """Decorator and context manager for tracing function calls.

    As a decorator::

        @traced
        def my_tool(arg):
            return result

    With a custom name::

        @traced(name="custom-name")
        def my_tool(arg):
            return result

    As a context manager::

        with traced(name="step-name") as span:
            result = do_work()
            span.set_output(result)
    """
    # Called as @traced (no parens) — fn is the decorated function.
    if fn is not None and callable(fn):
        tool_name = name or fn.__name__

        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            with _TracedContextManager(tool_name) as span:
                result = fn(*args, **kwargs)
                span.set_output(result)
                return result

        @functools.wraps(fn)
        async def async_wrapper(*args, **kwargs):
            with _TracedContextManager(tool_name) as span:
                result = await fn(*args, **kwargs)
                span.set_output(result)
                return result

            return result

        import asyncio
        if asyncio.iscoroutinefunction(fn):
            return async_wrapper
        return wrapper

    # Called as @traced(name="...") or traced(name="...") context manager.
    if fn is None:
        if name is not None:
            # Context manager: traced(name="step")
            return _TracedContextManager(name)
        # @traced() with empty parens — return decorator factory.
        def decorator(f: Callable) -> Callable:
            return traced(f, name=name)
        return decorator

    raise TypeError(f"traced() got unexpected argument: {fn!r}")
