markdown_content = """# 🔢 decitobin CLI & WebStyle `2026.1`

[![PyPI version](https://img.shields.io/pypi/v/decitobin.svg)](https://pypi.org/project/decitobin/)
[![Downloads](https://static.pepy.tech/personalized-badge/decitobin?period=total&units=international_system&left_color=black&right_color=blue&left_text=Downloads)](https://pepy.tech/project/decitobin)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

**decitobin** là một công cụ Python đa năng giúp chuyển đổi giữa các hệ cơ số và văn bản—nay đã được nâng cấp với giao diện người dùng hiện đại và công cụ dòng lệnh (CLI) mạnh mẽ cho lập trình viên.

Cho dù bạn đang chuyển đổi thập phân sang nhị phân, khám phá mã hóa ASCII hay xử lý các chuỗi thập lục phân phức tạp, `decitobin` đều mang lại trải nghiệm tương tác và thân thiện.

---

## ✨ Tính năng nổi bật

* **🚀 CLI Pro:** Thao tác cực nhanh qua dòng lệnh, hỗ trợ lập trình viên tích hợp vào script.
* **🎨 WebStyle GUI:** Giao diện Tkinter hiện đại, dễ sử dụng cho người mới bắt đầu.
* **🛠️ Đa dạng hệ cơ số:**
    * Thập phân (Decimal) ↔ Nhị phân (Binary)
    * Thập lục phân (Hex) ↔ Nhị phân (Binary)
    * ASCII ↔ Nhị phân (Binary)
    * Thập phân (Decimal) ↔ Thập lục phân (Hex)
    * Bát phân (Octal) ↔ Nhị phân (Binary)
    * **Đặc biệt:** Thập phân (Decimal) ↔ **Thập nhị phân (Duodecimal)**
* **📋 Tiện ích:** Sao chép kết quả vào clipboard chỉ với một cú click/lệnh.

---

## 📥 Cài đặt

Sử dụng `pip` để cài đặt phiên bản mới nhất:

```bash
pip install decitobin
```
## Cách dùng bản GUI
Ghi dòng lệnh sau:
```python
import decitobin
```
## Cách dùng bản CLI
Ghi dòng lệnh sau:
```python
from decitobin import cli

# Để chạy trình điều khiển CLI ngay trong code
if __name__ == "__main__":
    cli.main()
```
## CLI arguments
![alt text](image.png)