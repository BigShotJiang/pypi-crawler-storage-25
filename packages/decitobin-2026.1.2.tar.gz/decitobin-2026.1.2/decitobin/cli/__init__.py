import argparse
import sys

# Core Logic - Giữ nguyên tinh hoa của Leader
def dec2bin(n): return bin(int(n))[2:]
def bin2dec(b): return str(int(b, 2))
def hex2bin(h): return bin(int(h, 16))[2:].zfill(len(h)*4)
def bin2hex(b): return hex(int(b, 2))[2:].upper()
def ascii2bin(t): return ' '.join(bin(ord(c))[2:].zfill(8) for c in t)
def bin2ascii(b):
    chunks = b.split() if ' ' in b else [b[i:i+8] for i in range(0, len(b), 8)]
    return ''.join(chr(int(c, 2)) for c in chunks if len(c) == 8)
def dec2hex(n): return hex(int(n))[2:].upper()
def hex2dec(h): return str(int(h, 16))
def dec2duodec(n):
    digits = "0123456789AB"
    n = int(n)
    if n == 0: return "0"
    result = ""
    while n > 0:
        result = digits[n % 12] + result
        n //= 12
    return result

def main():
    parser = argparse.ArgumentParser(description="decitobin CLI - Professional Base Converter by thailam12")
    
    # Định nghĩa các flag cho dev dễ dùng
    parser.add_argument("data", help="Dữ liệu cần chuyển đổi")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("-db", "--dec2bin", action="store_true", help="Decimal to Binary")
    group.add_argument("-bd", "--bin2dec", action="store_true", help="Binary to Decimal")
    group.add_argument("-hb", "--hex2bin", action="store_true", help="Hex to Binary")
    group.add_argument("-bh", "--bin2hex", action="store_true", help="Binary to Hex")
    group.add_argument("-ab", "--ascii2bin", action="store_true", help="ASCII to Binary")
    group.add_argument("-ba", "--bin2ascii", action="store_true", help="Binary to ASCII")
    group.add_argument("-dh", "--dec2hex", action="store_true", help="Decimal to Hex")
    group.add_argument("-hd", "--hex2dec", action="store_true", help="Hex to Decimal")
    group.add_argument("-dd", "--dec2duo", action="store_true", help="Decimal to Duodecimal")

    args = parser.parse_args()

    try:
        if args.dec2bin: print(dec2bin(args.data))
        elif args.bin2dec: print(bin2dec(args.data))
        elif args.hex2bin: print(hex2bin(args.data))
        elif args.bin2hex: print(bin2hex(args.data))
        elif args.ascii2bin: print(ascii2bin(args.data))
        elif args.bin2ascii: print(bin2ascii(args.data))
        elif args.dec2hex: print(dec2hex(args.data))
        elif args.hex2dec: print(hex2dec(args.data))
        elif args.dec2duo: print(dec2duodec(args.data))
    except Exception as e:
        print(f"⚠️ Lỗi: Đầu vào không hợp lệ cho kiểu chuyển đổi này!")
        sys.exit(1)

if __name__ == "__main__":
    main()