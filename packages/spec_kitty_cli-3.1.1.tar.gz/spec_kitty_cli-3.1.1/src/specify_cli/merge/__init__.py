"""Merge support package for lane-based Spec Kitty merges."""

from __future__ import annotations

from specify_cli.merge.config import (
    ConfigError,
    MergeConfig,
    MergeStrategy,
    load_merge_config,
)
from specify_cli.merge.conflict_resolver import (
    ConflictType,
    ResolutionResult,
    classify_conflict,
    resolve_owned_conflicts,
)
from specify_cli.merge.ordering import MergeOrderError, get_merge_order, has_dependency_info
from specify_cli.merge.state import (
    MergeState,
    acquire_merge_lock,
    clear_state,
    has_active_merge,
    is_merge_locked,
    load_state,
    release_merge_lock,
    save_state,
)
from specify_cli.merge.workspace import (
    cleanup_merge_workspace,
    create_merge_workspace,
    get_merge_workspace,
    get_merge_workspace_path,
)

__all__ = [
    # Merge config
    "MergeStrategy",
    "MergeConfig",
    "ConfigError",
    "load_merge_config",
    # Conflict resolution
    "ConflictType",
    "ResolutionResult",
    "classify_conflict",
    "resolve_owned_conflicts",
    # Ordering
    "get_merge_order",
    "MergeOrderError",
    "has_dependency_info",
    # State persistence
    "MergeState",
    "save_state",
    "load_state",
    "clear_state",
    "has_active_merge",
    "acquire_merge_lock",
    "release_merge_lock",
    "is_merge_locked",
    # Workspace
    "create_merge_workspace",
    "cleanup_merge_workspace",
    "get_merge_workspace",
    "get_merge_workspace_path",
]
