#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# **************************************************
__author__  = "Teddy Chantrait"
__email__   = "teddy.chantrait@gmail.com"
__status__  = "Development"
__date__    = "2024-07-03 17:28:00.999352"
__version__ = "@COSTO_VERSION@"
# **************************************************
from .clock import clock

class IScheduler():
    __slots__ = (
        "_clock",
        "_its_a_meeting_point",
        "_dt_to_meeting",
        "_dt_seuil",
        "_t_next_meeting",
        "_new_t_meeting",
        "_planify_call_allowed",
        "_accept_call_allowed"
    )

    def __init__(self, dt_seuil=1e-9):
        self._clock = clock()
        self._its_a_meeting_point = True
        self._dt_to_meeting = -1
        self._dt_seuil = dt_seuil
        # self.neibor_dt = 0
        # self._dtmax = 0
        # self._dtmin = 0
        self._t_next_meeting = 0
        self._new_t_meeting = 0

        self._planify_call_allowed = True
        self._accept_call_allowed = False
        # self.dt_guest = 0

    @property
    def is_a_meeting_point(self):
        self._dt_to_meeting = abs(self.t_next_meeting-self._clock.time)
        if self._dt_to_meeting < self._dt_seuil:
            self._its_a_meeting_point = True
        else:
            self._its_a_meeting_point = False
        return self._its_a_meeting_point

    @is_a_meeting_point.setter
    def is_a_meeting_point(self, val):
        return

    def planify_new_meeting(self, val):
        if self._planify_call_allowed:
            self._new_t_meeting = val
            self._planify_call_allowed = False
            self._accept_call_allowed = True
        else:
            raise RuntimeError("A new meeting has been planified and not yet accepted")
        return

    def accept(self):
        if self._accept_call_allowed:
            self._t_next_meeting = self._new_t_meeting*1.
            self._accept_call_allowed = False
            self._planify_call_allowed = True
        else:
            raise RuntimeError("You must call planify_new_meeting before")

    @property
    def t_next_meeting(self):
        return self._t_next_meeting

    @t_next_meeting.setter
    def t_next_meeting(self, val):
        raise RuntimeError("Yout must use planify_new_meeting and accept to modify it")

    def do_publish_action(self):
        return self.is_a_meeting_point

    def do_collect_action(self):
        # self._check_schedule()  # par securité le garder?
        return self._its_a_meeting_point



    def __repr__(self):
        to_ret = ""
        to_ret += "time to next meeting: " + str(self._dt_to_meeting) + "\n"
        to_ret += "next meeting point: " + str(self.t_next_meeting) + "\n"
        return to_ret
