#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__  = "Teddy Chantrait"
__email__   = "teddy.chantrait@gmail.com"
__status__  = "Development"
__date__    = "2024-11-09 17:39:32.284214"
__version__ = 1.0

import costo.scheduler as COS
from costo.clock import clock as Clock
import traceback

def sould_not_be_called():
    raise RuntimeError

def test_IScheduler():
    clock = Clock(0.)

    clock.reset(0.2)

    scheduler = COS.IScheduler()
    scheduler.planify_new_meeting(1.)
    scheduler.accept()
    assert scheduler.is_a_meeting_point  == False
    assert scheduler.do_publish_action()  == False
    assert scheduler.do_collect_action()  == False

    clock.tic(0.8)
    assert clock.time == 0.2
    assert scheduler.is_a_meeting_point  == False
    assert scheduler.do_publish_action()  == False
    assert scheduler.do_collect_action()  == False
    clock.tac()
    assert clock.time == 1.
    assert scheduler.is_a_meeting_point  == True
    assert scheduler.do_publish_action()  == True
    assert scheduler.do_collect_action()  == True


    scheduler.planify_new_meeting(2.)
    scheduler.accept()
    assert scheduler.is_a_meeting_point  == False
    assert scheduler.do_publish_action()  == False
    assert scheduler.do_collect_action()  == False

    clock.tic(1.)
    assert clock.time == 1.
    assert scheduler.is_a_meeting_point  == False
    assert scheduler.do_publish_action()  == False
    assert scheduler.do_collect_action()  == False
    clock.tac()
    assert clock.time == 2.
    assert scheduler.is_a_meeting_point  == True
    assert scheduler.do_publish_action()  == True
    assert scheduler.do_collect_action()  == True

    clock.reset(0.)
    assert scheduler.is_a_meeting_point  == False
    assert scheduler.do_publish_action()  == False
    assert scheduler.do_collect_action()  == False

    clock.tic(2.)
    assert clock.time == 0.
    assert scheduler.is_a_meeting_point  == False
    assert scheduler.do_publish_action()  == False
    assert scheduler.do_collect_action()  == False
    clock.tac()
    assert clock.time == 2.
    assert scheduler.is_a_meeting_point  == True
    assert scheduler.do_publish_action()  == True
    assert scheduler.do_collect_action()  == True

    clock.tic(2.)
    # reset between tic and tac calls
    clock.reset(0.)

    try:
        clock.tac()
        sould_not_be_called()
    except:
        print("Normal exception (tic must be call first)")
    # A tic call is needed first
    clock.tic(2.)
    assert clock.time == 0.
    assert scheduler.is_a_meeting_point  == False
    assert scheduler.do_publish_action()  == False
    assert scheduler.do_collect_action()  == False
    clock.tac()
    assert clock.time == 2.
    assert scheduler.is_a_meeting_point  == True
    assert scheduler.do_publish_action()  == True
    assert scheduler.do_collect_action()  == True

    clock.tic(2.)
    try:
        clock.tic(1.)
        sould_not_be_called()
    except:
        print("Normal exception (tic can't be called two times without a tac call between)")
