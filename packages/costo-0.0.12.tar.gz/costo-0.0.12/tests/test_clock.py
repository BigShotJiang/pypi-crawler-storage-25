#!/usr/bin/env python3
# -*- coding: utf-8 -*-
__author__  = "Teddy Chantrait"
__email__   = "teddy.chantrait@gmail.com"
__status__  = "Development"
__date__    = "2024-11-09 17:39:32.284214"
__version__ = 1.0

from costo.clock import clock as Clock
import traceback

def sould_not_be_called():
    raise RuntimeError

def test_rest_behavior():
    clock = Clock(t0=0)
    clock.reset(0.)
    assert clock.time == 0.

    clock = Clock(t0=0)
    clock.reset(10.)
    assert clock.time == 10.

def test_time_attribute_behavior():
    clock = Clock(t0=0)
    clock.reset(1.)
    # try to set protected atribut time
    try:
        clock.time = 2
        sould_not_be_called()
    except:
        print()
        print("-"*50)
        print('Dont worry, the following exception is a normal behavior')
        print("-"*50)
        ret = traceback.format_exc()
        assert "RuntimeError: Time can't be set, use reset or increment" in ret
        print(ret)
        print("-"*50)
        pass
    assert clock.time == 1.

    # try to acces to an non existing attribut (times)
    try:
        clock.times = 2
        sould_not_be_called()
    except:
        print()
        print("-"*50)
        print('Dont worry, the following exception is a normal behavior')
        print("-"*50)
        ret = traceback.format_exc()
        assert "AttributeError: 'clock' object has no attribute 'times'" in ret
        print(ret)
        print("-"*50)
        pass


def test_tic_tac_behavior_and_next_time_attribut():
    clock = Clock(t0=0)
    clock.reset(0.)

    clock.tic(2.)
    assert clock.next_time == 2.
    clock.tac()
    assert clock.time == 2.
    assert clock.next_time == 2.
    clock.tic(2.)
    assert clock.next_time == 4.
    clock.tac()
    assert clock.next_time == 4.
    assert clock.time == 4.
    clock.reset(1.)
    assert clock.time == 1.
    assert clock.next_time == 1.
    clock.tic(2.)
    assert clock.next_time == 3.
    clock.tac()
    assert clock.next_time == 3.
    assert clock.time == 3.

    # try to acces to an non existing attribut (times)
    try:
        clock.next_time = 12.
        sould_not_be_called()
    except:
        print()
        print("-"*50)
        print('Dont worry, the following exception is a normal behavior')
        print("-"*50)
        ret = traceback.format_exc()
        assert "RuntimeError: next_time can't be set" in ret
        print(ret)
        print("-"*50)
        pass
    assert clock.next_time == 3.

def test_time_singleton_behavior():
    clock = Clock(t0=0)
    clock.reset(3)

    clock2 = Clock(t0=0)
    assert id(clock) == id(clock2)
    assert clock2.time == 3

    clock2.reset(0)
    assert clock.time == 0

    clock.tic(2.5)
    clock.tac()
    assert clock.time == clock2.time
    assert clock2.time == 2.5

    clock2.tic(2.5)
    clock2.tac()
    assert clock.time == clock2.time
    assert clock.time == 5.
