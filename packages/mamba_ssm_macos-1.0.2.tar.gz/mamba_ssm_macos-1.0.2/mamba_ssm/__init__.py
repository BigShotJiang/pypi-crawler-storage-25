from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("mamba-ssm-macos")
except PackageNotFoundError:
    __version__ = "0.0.0"

from mamba_ssm.models.mixer_seq_simple import MambaLMHeadModel
from mamba_ssm.modules.mamba2 import Mamba2
from mamba_ssm.modules.mamba_simple import Mamba
from mamba_ssm.ops.selective_scan_interface import mamba_inner_fn, selective_scan_fn
from mamba_ssm.utils.macos import (
    create_tokenizer,
    generate_text_with_model,
    get_device,
    load_and_prepare_model,
)

__all__ = [
    "selective_scan_fn",
    "mamba_inner_fn",
    "Mamba",
    "Mamba2",
    "MambaLMHeadModel",
    "get_device",
    "create_tokenizer",
    "generate_text_with_model",
    "load_and_prepare_model",
]
