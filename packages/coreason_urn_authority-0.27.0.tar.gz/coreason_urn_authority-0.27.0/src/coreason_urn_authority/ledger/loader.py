# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""OCI Artifact Ledger Loader.

Loads and queries the declarative YAML index that maps CoReason URNs
to external OCI artifact URIs and their authorized signer DIDs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

import yaml
from coreason_manifest.spec.ontology import CoreasonBaseState
from pydantic import Field

from coreason_urn_authority.crypto.cosign_verifier import TopologicalSeveranceEvent

# ────────────────────────────────────────────────────────────────────
# Data Structures
# ────────────────────────────────────────────────────────────────────


class MCPRegistryRef(CoreasonBaseState):
    """AGENT INSTRUCTION: An optional reference mapping this URN to its equivalent
    public MCP Registry listing.

    CAUSAL AFFORDANCE: Enables the semantic router to link OCI artifacts to their
    HTTP-discoverable MCP counterparts for dual-publishing architectures.

    EPISTEMIC BOUNDS: Namespace must follow reverse-DNS format.

    MCP ROUTING TRIGGERS: MCP Registry, Cross-Reference, Dual-Publish
    """

    namespace: str = Field(
        description="The reverse-DNS namespace (e.g. io.github.username/server).",
        max_length=256,
    )
    registry_url: str = Field(
        description="The URL of the MCP Registry.",
        default="https://registry.modelcontextprotocol.io",
        max_length=512,
    )
    verified: bool = Field(
        description="Whether this capability has been Cosign verified against the registry.",
        default=True,
    )


class LedgerEntry(CoreasonBaseState):
    """AGENT INSTRUCTION: An immutable, cryptographically canonicalizable record in the
    OCI Artifact Ledger mapping a CoReason URN to its external OCI artifact URI and
    the DID of the authorized signer.

    CAUSAL AFFORDANCE: Enables the semantic router to resolve URNs to verified OCI
    artifact locations and extract the signer's public key for Cosign verification.

    EPISTEMIC BOUNDS: Frozen via CoreasonBaseState. URN pattern follows the CoReason
    namespace convention. OCI URI bounded to 512 characters. DID bounded to
    the did:key: format.

    MCP ROUTING TRIGGERS: OCI Artifact Ledger, URN Resolution, DID Key Mapping,
    Supply Chain Trust, Capability Registry
    """

    urn: str = Field(
        description="The CoReason Uniform Resource Name for this capability.",
        max_length=256,
    )
    oci_uri: str = Field(
        description="The OCI artifact URI (e.g. ghcr.io/coreason-ai/solver:v1).",
        max_length=512,
    )
    authorized_signer_did: str = Field(
        description="The W3C DID of the authorized signer (e.g. did:key:z6Mk...).",
        max_length=256,
    )
    tenant_cid: str = Field(
        description="The tenant capability identifier for zero-trust multi-tenancy isolation.",
        default="urn:tenant:coreason:global:authority",
        max_length=256,
    )
    mcp_registry: MCPRegistryRef | None = Field(
        description="Optional cross-reference to the public MCP Registry.",
        default=None,
    )
    license_tier: Literal["prosperity-3.0", "commercial"] = Field(
        description="The licensing class under which this capability was registered. "
        "'prosperity-3.0' = forged under the Prosperity Public License (copyright assigned to CoReason, Inc. via CLA). "
        "'commercial' = forged under a commercial license agreement (tenant retains IP sovereignty).",
        default="prosperity-3.0",
    )


# ────────────────────────────────────────────────────────────────────
# Default Ledger Path
# ────────────────────────────────────────────────────────────────────

_DEFAULT_LEDGER_PATH = Path(__file__).parent / "index.yaml"


# ────────────────────────────────────────────────────────────────────
# Public API
# ────────────────────────────────────────────────────────────────────


def load_ledger(ledger_path: Path | None = None) -> list[LedgerEntry]:
    """Load the OCI artifact ledger from a YAML file.

    Args:
        ledger_path: Path to the ledger YAML file. Defaults to the
            package-bundled ``index.yaml``.

    Returns:
        A list of ``LedgerEntry`` objects.

    Raises:
        TopologicalSeveranceEvent: If the ledger file is missing or malformed.
    """
    path = ledger_path or _DEFAULT_LEDGER_PATH

    if not path.exists():
        raise TopologicalSeveranceEvent(f"OCI Ledger not found at {path}")

    raw: dict[str, Any] = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    capabilities: list[dict[str, Any]] = raw.get("capabilities", [])

    entries: list[LedgerEntry] = []
    for cap in capabilities:
        urn = cap.get("urn", "")
        oci_uri = cap.get("oci_uri", "")
        did = cap.get("authorized_signer_did", "")
        tenant_cid = cap.get("tenant_cid", "urn:tenant:coreason:global:authority")
        mcp_registry_raw = cap.get("mcp_registry")

        if not urn or not oci_uri or not did:
            raise TopologicalSeveranceEvent(f"Malformed ledger entry: missing required fields in {cap}")

        mcp_registry = None
        if mcp_registry_raw:
            mcp_registry = MCPRegistryRef(
                namespace=mcp_registry_raw.get("namespace", ""),
                registry_url=mcp_registry_raw.get("registry_url", "https://registry.modelcontextprotocol.io"),
                verified=mcp_registry_raw.get("verified", True),
            )

        entries.append(
            LedgerEntry(
                urn=urn,
                oci_uri=oci_uri,
                authorized_signer_did=did,
                tenant_cid=tenant_cid,
                mcp_registry=mcp_registry,
                license_tier=cap.get("license_tier", "prosperity-3.0"),
            )
        )

    return entries


def resolve_urn(urn: str, ledger: list[LedgerEntry]) -> LedgerEntry:
    """Look up a URN in the ledger.

    Args:
        urn: The URN to resolve.
        ledger: The loaded ledger entries.

    Returns:
        The matching ``LedgerEntry``.

    Raises:
        TopologicalSeveranceEvent: If the URN is not found.
    """
    for entry in ledger:
        if entry.urn == urn:
            return entry

    available = [e.urn for e in ledger]
    raise TopologicalSeveranceEvent(f"URN '{urn}' not found in OCI Ledger. Available URNs: {available}")
