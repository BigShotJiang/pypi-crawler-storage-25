# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")
# A copy of the license is available at <https://prosperitylicense.com/versions/3.0.0>
# For details, see the LICENSE file
# Commercial use beyond a 30-day trial requires a separate license
#
# Source Code: <https://github.com/CoReason-AI/coreason-urn-authority>

"""OCI Artifact Ledger Promoter.

Automates the addition of new URNs to the ledger.
"""

from pathlib import Path


def append_to_ledger(
    ledger_path: Path,
    urn: str,
    oci_uri: str,
    did: str,
    tenant_cid: str,
    mcp_namespace: str | None = None,
) -> None:
    """Appends a new capability to the YAML ledger while preserving comments.

    Args:
        ledger_path: Path to the ledger YAML file.
        urn: The CoReason URN.
        oci_uri: The OCI artifact URI.
        did: The W3C did:key of the authorized signer.
        tenant_cid: The tenant capability identifier.
        mcp_namespace: Optional MCP Registry reverse-DNS namespace.
    """
    entry = f"""
  - urn: "{urn}"
    oci_uri: "{oci_uri}"
    authorized_signer_did: "{did}"
    tenant_cid: "{tenant_cid}"
"""
    if mcp_namespace:
        entry += f"""    mcp_registry:
      namespace: "{mcp_namespace}"
      registry_url: "https://registry.modelcontextprotocol.io"
      verified: true
"""

    with open(ledger_path, "a", encoding="utf-8") as f:
        f.write(entry)
