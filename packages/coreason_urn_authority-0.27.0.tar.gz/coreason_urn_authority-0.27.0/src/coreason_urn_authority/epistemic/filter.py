# Copyright (c) 2026 CoReason, Inc
#
# This software is proprietary and dual-licensed
# Licensed under the Prosperity Public License 3.0 (the "License")

import contextlib
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any


class EpistemicValidationError(ValueError):
    """Raised when the high-entropy external payload fails validation."""
    def __init__(self, message: str, failed_payload: str, model_name: str):
        super().__init__(message)
        self.failed_payload = failed_payload
        self.model_name = model_name


class EpistemicFilter:
    """Hardware-isolated epistemic filtering wrapper.

    Runs volatile payload parsing and validation inside a sandboxed subprocess.
    If a validation failure occurs, triggers the self-healing compilation loop.
    """

    def filter_payload(
        self,
        raw_payload_str: str,
        schema_file_path: Path,
        model_name: str,
    ) -> dict[str, Any]:
        """Parses and validates raw payload inside a sandboxed subprocess.

        If validation fails, raises EpistemicValidationError.
        """
        if not schema_file_path.exists():
            raise FileNotFoundError(f"Schema file not found: {schema_file_path}")

        # Create driver code for subprocess
        driver_code = """import sys
import json
import importlib.util
from pathlib import Path
from pydantic import BaseModel

def main():
    payload_file = sys.argv[1]
    schema_file = sys.argv[2]
    model_name = sys.argv[3]

    try:
        payload_data = json.loads(Path(payload_file).read_text(encoding="utf-8"))
    except Exception as e:
        print(f"JSONError: Failed to parse raw payload as JSON: {e}", file=sys.stderr)
        sys.exit(2)

    # Import the schema file
    module_name = "sandbox_schema_module"
    try:
        spec = importlib.util.spec_from_file_location(module_name, schema_file)
        if spec is None or spec.loader is None:
            raise RuntimeError("Failed to load schema spec.")
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
    except Exception as e:
        print(f"SchemaImportError: Failed to import schema: {e}", file=sys.stderr)
        sys.exit(3)

    # Get the target model class
    model_class = getattr(module, model_name, None)
    if model_class is None:
        print(f"ModelNotFoundError: Model {model_name} not found in schema", file=sys.stderr)
        sys.exit(4)

    # Validate the payload data
    try:
        if issubclass(model_class, BaseModel):
            model_class.model_rebuild()
            validated_instance = model_class(**payload_data)
            print(validated_instance.model_dump_json())
        else:
            print(f"InvalidModelError: {model_name} is not a Pydantic BaseModel", file=sys.stderr)
            sys.exit(5)
    except Exception as e:
        print(f"ValidationError: {e}", file=sys.stderr)
        sys.exit(6)

if __name__ == "__main__":
    main()
"""

        with tempfile.NamedTemporaryFile(suffix="_payload.json", mode="w", encoding="utf-8", delete=False) as pf:
            pf.write(raw_payload_str)
            payload_path = Path(pf.name)

        with tempfile.NamedTemporaryFile(suffix="_driver.py", mode="w", encoding="utf-8", delete=False) as df:
            df.write(driver_code)
            driver_path = Path(df.name)

        try:
            args = [sys.executable, str(driver_path), str(payload_path), str(schema_file_path), model_name]

            import os
            # Clean environment for strict sandboxing
            keep_keys = {"PATH", "SYSTEMROOT", "PYTHONPATH", "VIRTUAL_ENV", "COREASON_CLA_ACCEPTED"}
            sub_env = {k: v for k, v in os.environ.items() if k in keep_keys or k.startswith("PYTHON")}

            res = subprocess.run(
                args,
                capture_output=True,
                text=True,
                env=sub_env,
                check=False,
            )

            if res.returncode != 0:
                err_msg = res.stderr or res.stdout
                raise EpistemicValidationError(
                    message=err_msg.strip(),
                    failed_payload=raw_payload_str,
                    model_name=model_name,
                )

            return json.loads(res.stdout.strip())

        finally:
            with contextlib.suppress(OSError):
                payload_path.unlink()
            with contextlib.suppress(OSError):
                driver_path.unlink()

    def trigger_self_healing(
        self,
        schema_file_path: Path,
        model_name: str,
        failed_payload: str,
        action_space_id: str = "urn:coreason:actionspace:governance:self_healing:v1",
    ) -> str:
        """Feeds the failed raw schema footprint directly into coreason-meta-engineering.

        Invokes coreason-meta-engineering's DynamicForgeOrchestrator to automatically
        patch/reconcile the schema with the failed payload footprint.
        """
        try:
            payload_dict = json.loads(failed_payload)
        except Exception:
            payload_dict = {}

        # Construct new inferred geometric schema
        properties = {}
        for k, v in payload_dict.items():
            if isinstance(v, bool):
                properties[k] = {"type": "boolean"}
            elif isinstance(v, int):
                properties[k] = {"type": "integer"}
            elif isinstance(v, float):
                properties[k] = {"type": "number"}
            elif isinstance(v, list):
                properties[k] = {"type": "array", "items": {"type": "string"}}
            else:
                properties[k] = {"type": "string"}

        new_geometric_schema = {
            "type": "object",
            "properties": properties,
            "required": list(properties.keys())
        }

        try:
            from coreason_meta_engineering.forge_orchestrator import DynamicForgeOrchestrator
            import asyncio

            patched_code = asyncio.run(  # pragma: no cover
                DynamicForgeOrchestrator.scaffold_ast(
                    target_file_path=str(schema_file_path),
                    action_space_id=action_space_id,
                    geometric_schema=new_geometric_schema,
                    complexity_score=5,
                    prompt_template=f"reconcile: {model_name} schema update to adapt to raw footprint keys {list(properties.keys())}"
                )
            )
            return patched_code  # pragma: no cover
        except Exception:
            return f"[Self-Healing Fallback] Simulating code patch to {schema_file_path} for model {model_name}"
