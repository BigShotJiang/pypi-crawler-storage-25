from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from mkdocs.config import config_options
from mkdocs.plugins import BasePlugin

CHILD_BUILD_ENV = "TECHDOCS_VERSION_SELECTOR_CHILD_BUILD"
LOGGER = logging.getLogger("mkdocs.plugins.techdocs-version-selector")


class TechDocsVersionSelectorPlugin(BasePlugin):
    config_scheme = (
        ("versions", config_options.Type(list, default=[])),
        ("root_version_name", config_options.Type(str, default="root")),
        ("site_subdir_prefix", config_options.Type(str, default="__")),
        ("manifest_filename", config_options.Type(str, default="multiversion.json")),
        ("techdocs_cli_command", config_options.Type(list, default=["techdocs-cli"])),
    )

    def __init__(self) -> None:
        self._versions: list[tuple[str, str]] = []
        self._workspace_root: Path | None = None
        self._config_filename: str | None = None
        self._site_dir: Path | None = None

    def on_config(self, config):
        config_file_path = Path(config.config_file_path).resolve()
        self._workspace_root = config_file_path.parent
        self._config_filename = config_file_path.name
        self._site_dir = Path(config["site_dir"]).resolve()

        LOGGER.debug(
            "Plugin configuration initialized (workspace_root=%s, site_dir=%s)",
            self._workspace_root,
            self._site_dir,
        )

        if os.getenv(CHILD_BUILD_ENV) == "1":
            LOGGER.debug("Skipping config parsing for child build due to %s=1", CHILD_BUILD_ENV)
            return config

        parsed_versions = self._parse_versions_node(self.config["versions"])
        self._versions = parsed_versions if len(parsed_versions) >= 1 else []
        if self._versions:
            LOGGER.info("Loaded %d version entries for multiversion build", len(self._versions))
        else:
            LOGGER.info("Multiversion build disabled (requires at least one valid version entry)")
        return config

    def on_post_build(self, config):
        if os.getenv(CHILD_BUILD_ENV) == "1":
            LOGGER.debug("Skipping post-build fan-out for child build due to %s=1", CHILD_BUILD_ENV)
            return
        if len(self._versions) == 0:
            LOGGER.debug("Skipping post-build fan-out; %d version(s) configured", len(self._versions))
            return
        if self._workspace_root is None or self._site_dir is None:
            LOGGER.warning("Skipping post-build fan-out due to missing workspace or site directory")
            return

        LOGGER.info("Starting multiversion build for %d versions", len(self._versions))
        self._write_manifest()
        for version_name, ref_name in self._versions:
            self._build_version_site(version_name, ref_name)
        LOGGER.info("Finished multiversion build")

    def _write_manifest(self) -> None:
        if self._site_dir is None:
            LOGGER.warning("Manifest write skipped: site directory is not set")
            return

        prefix = self.config["site_subdir_prefix"]
        manifest_path = self._site_dir / self.config["manifest_filename"]
        manifest: dict[str, dict[str, Any]] = {}
        root_version_name = str(self.config["root_version_name"]).strip()

        if root_version_name:
            manifest[root_version_name] = {
                "name": root_version_name,
                "latest": True,
                "path": "/",
            }

        for version_name, ref_name in self._versions:
            safe_name = self._safe_folder_name(version_name)
            manifest[version_name] = {
                "name": version_name,
                "latest": False,
                "ref": ref_name,
                "path": f"/{prefix}{safe_name}/",
            }

        manifest_path.parent.mkdir(parents=True, exist_ok=True)
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False), encoding="utf-8")
        LOGGER.info("Wrote multiversion manifest: %s", manifest_path)

    def _build_version_site(self, version_name: str, ref_name: str) -> None:
        if self._workspace_root is None or self._config_filename is None or self._site_dir is None:
            LOGGER.warning(
                "Skipping version build for '%s': plugin directories are not fully initialized",
                version_name,
            )
            return

        git_executable = shutil.which("git")
        if git_executable is None:
            raise RuntimeError("git executable was not found in PATH")

        safe_name = self._safe_folder_name(version_name)
        target_site_dir = self._site_dir / f"{self.config['site_subdir_prefix']}{safe_name}"
        LOGGER.info("Building version '%s' from ref '%s' into %s", version_name, ref_name, target_site_dir)
        with tempfile.TemporaryDirectory(prefix="techdocs-version-", dir=str(self._workspace_root)) as temp_dir:
            worktree_dir = Path(temp_dir)
            self._run_command(
                [git_executable, "worktree", "add", "--detach", str(worktree_dir), ref_name],
                cwd=self._workspace_root,
            )
            try:
                env = os.environ.copy()
                env[CHILD_BUILD_ENV] = "1"
                command = list(self.config["techdocs_cli_command"]) + [
                    "generate",
                    "--source-dir",
                    str(worktree_dir),
                    "--output-dir",
                    str(target_site_dir),
                    "--no-docker",
                ]
                command = self._resolve_command(command)

                self._run_command(
                    command,
                    cwd=worktree_dir,
                    env=env,
                )
                LOGGER.info("Finished version '%s'", version_name)
            finally:
                self._run_command(
                    [git_executable, "worktree", "remove", "--force", str(worktree_dir)],
                    cwd=self._workspace_root,
                )

    @staticmethod
    def _parse_versions_node(versions_node: Any) -> list[tuple[str, str]]:
        if not isinstance(versions_node, list):
            LOGGER.warning("Invalid 'versions' config: expected list, got %s", type(versions_node).__name__)
            return []

        parsed_versions: list[tuple[str, str]] = []
        for index, item in enumerate(versions_node):
            if not isinstance(item, dict):
                LOGGER.warning("Ignoring versions[%d]: expected map with one entry", index)
                continue
            if len(item) != 1:
                LOGGER.warning("Ignoring versions[%d]: expected exactly one key/value pair", index)
                continue

            raw_version_name, raw_ref_name = next(iter(item.items()))
            version_name = TechDocsVersionSelectorPlugin._to_config_string(raw_version_name)
            ref_name = TechDocsVersionSelectorPlugin._to_config_string(raw_ref_name)
            if version_name is None or ref_name is None:
                LOGGER.warning(
                    "Ignoring versions[%d]: key and value must be strings or integers",
                    index,
                )
                continue
            parsed_versions.append((version_name.strip(), ref_name.strip()))
        filtered = [entry for entry in parsed_versions if entry[0] and entry[1]]
        if len(filtered) != len(parsed_versions):
            LOGGER.warning("Ignoring %d empty version/ref entries", len(parsed_versions) - len(filtered))
        return filtered

    @staticmethod
    def _to_config_string(value: Any) -> str | None:
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return str(value)
        if isinstance(value, str):
            return value
        return None

    @staticmethod
    def _safe_folder_name(version_name: str) -> str:
        sanitized = re.sub(r"[^A-Za-z0-9._-]", "-", version_name).strip(".-_")
        return sanitized or "version"

    @staticmethod
    def _run_command(command: list[str], cwd: Path, env: dict[str, str] | None = None) -> None:
        LOGGER.debug("Running command: %s (cwd=%s)", " ".join(command), cwd)
        subprocess.run(command, cwd=str(cwd), env=env, check=True)

    @staticmethod
    def _resolve_command(command: list[str]) -> list[str]:
        if not command:
            raise RuntimeError("techdocs_cli_command cannot be empty")

        executable = command[0]
        if Path(executable).exists() or shutil.which(executable) is not None:
            LOGGER.debug("Resolved TechDocs CLI executable: %s", executable)
            return command

        if os.name == "nt" and not executable.lower().endswith(".cmd"):
            windows_executable = f"{executable}.cmd"
            if shutil.which(windows_executable) is not None:
                command[0] = windows_executable
                LOGGER.debug("Resolved TechDocs CLI executable via Windows fallback: %s", windows_executable)
                return command

        LOGGER.error("Unable to resolve TechDocs CLI executable: %s", executable)
        raise RuntimeError(
            f"Unable to find TechDocs CLI executable '{executable}'."
        )