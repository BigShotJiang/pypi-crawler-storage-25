###################################################################################
#                                                                                 #
# This file is an implementation of RaDE+: A Rank-based Graph Embedding Approach  #
# with Multi-Representative Nodes.                                                 #
#                                                                                 #
# RaDE+ is free software; you can redistribute it and/or modify it under the      #
# terms of the GNU General Public License as published by the Free Software        #
# Foundation; either version 2 of the License, or (at your option) any later      #
# version.                                                                         #
#                                                                                 #
# RaDE+ is distributed in the hope that it will be useful, but WITHOUT ANY        #
# WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR   #
# A PARTICULAR PURPOSE. See the GNU General Public License for more details.      #
#                                                                                 #
# You should have received a copy of the GNU General Public License along with    #
# RaDE+. If not, see <http://www.gnu.org/licenses/>.                              #
#                                                                                 #
###################################################################################

import numpy as np
from tqdm import tqdm
from .rade import RaDE


class RaDEPlus(RaDE):
    '''
    This class implements the code of RaDE+.
    DE FERNANDO, F. A. ;
    PEDRONETTE, D. C. G. ;
    DE SOUSA, G. J. ;
    VALEM, L. P. ;
    GUILHERME, I. R. .
    RaDE+: A semantic rank-based graph embedding algorithm.
    International Journal of Information Management Data Insights, 2(2), 100078, 2022.

    RaDE+ extends RaDE by expanding each selected representative node into a set
    of similar nodes (expansion set), producing more robust and diversified embeddings.
    Each embedding dimension aggregates affinities to an expansion set rather than
    a single representative.
    '''

    def __init__(self, rks_path=None, rks_size_L=20):
        print("\tInitializing RaDE+")
        super().__init__(rks_path=rks_path, rks_size_L=rks_size_L)
        self.expansion_sets = None  # {leader_idx: [r, s1, s2, ...]}
        self._m = None              # expansion parameter, stored for generate_embeddings
        print("\tRaDE+ initialized successfully!")

    def compute_expansion_sets(self, m):
        """
        Build expansion sets for each leader via Algorithm 1 from the paper:
        Multi-Representative Nodes Set Expansion.

        For each leader r, φ_r starts as {r} and is expanded by greedily picking
        the candidate from the shared pool C with the highest affinity A[r, x].
        Each candidate is consumed from C at most once across all expansion sets.

        Args:
            m (int): Number of elements to add to each expansion set beyond the
                     leader itself. Final |φ_r| = m + 1. Must satisfy m * d ≤ |C|.
        """
        if self.leaders is None or self.transition_matrix_A is None:
            raise ValueError("Call compute_leaders() before compute_expansion_sets().")

        print("\tComputing expansion sets (Algorithm 1)...")
        A = self.transition_matrix_A
        candidates = set(self.candidates)
        expansion_sets = {}

        # Initialization: φ_r = {r}, remove all leaders from shared pool
        for r in self.leaders:
            expansion_sets[r] = [r]
            candidates.discard(r)

        # Pre-sort candidates by affinity to each leader (descending)
        candidates_list = list(candidates)
        sorted_candidates = {}
        for r in self.leaders:
            affinities = A[r, candidates_list]
            order = np.argsort(-affinities)
            sorted_candidates[r] = [candidates_list[idx] for idx in order]

        consumed = set()
        pointers = {r: 0 for r in self.leaders}  # track position in sorted list

        # Expansion: m rounds, each round adds one element per leader
        for _ in tqdm(range(m)):
            for r in self.leaders:
                # Advance pointer to first available (not consumed) candidate
                while pointers[r] < len(sorted_candidates[r]):
                    s = sorted_candidates[r][pointers[r]]
                    pointers[r] += 1
                    if s not in consumed:
                        expansion_sets[r].append(s)
                        consumed.add(s)
                        break

        self.expansion_sets = expansion_sets
        self._m = m

    def generate_embeddings(self):
        """
        Generate RaDE+ embedding vectors using the γ function over expansion sets.

        For each element e and leader r_i:
            γ(e, r) = Σ_{s ∈ φ_r} (m − τ) · A[e, s]
        where τ is the 0-indexed selection order of s in φ_r, giving weights
        m, m-1, ..., 0 from the leader down to the last expansion element.
        """
        if self.expansion_sets is None:
            raise ValueError("Call compute_expansion_sets() before generate_embeddings().")

        print("\tGenerating embeddings (RaDE+)...")
        A = self.transition_matrix_A
        m = self._m
        embeddings = np.zeros((self.dataset_size, len(self.leaders)))

        # Vectorized over N, with explicit tau-order accumulation to match
        # the original sequential sum() and preserve bit-exact determinism.
        # (np.matmul/@  may reorder ops internally via BLAS causing ~1-ULP drift)
        for j, r in enumerate(self.leaders):
            phi_r = self.expansion_sets[r]
            for tau, s in enumerate(phi_r):
                embeddings[:, j] += (m - tau) * A[:, s]

        self.embeddings = embeddings

    def fit(self, num_candidates=1000, num_leaders=128, t=2, m=3):
        """
        Compute W matrix, transition matrix A, select leaders, and build expansion sets.

        Args:
            num_candidates (int): Size of the candidate pool (top-k by diagonal of A).
            num_leaders (int): Number of representative nodes (embedding dimensionality).
            t (int): Diffusion steps for transition matrix A = W^t.
            m (int): Expansion size — elements added to each leader's expansion set.
                     Constraint: m * num_leaders ≤ num_candidates.
        """
        self.compute_W_matrix()
        self.compute_leaders(num_candidates, num_leaders, t)
        self.compute_expansion_sets(m)

    def transform(self):
        """
        Generate and return the RaDE+ embedding matrix.
        """
        if self.expansion_sets is None:
            raise ValueError("Call fit() before transform().")
        self.generate_embeddings()
        return self.embeddings

    def fit_transform(self, num_candidates=1000, num_leaders=128, t=2, m=3):
        """
        Fit model and return RaDE+ embeddings.

        Args:
            num_candidates (int): Size of the candidate pool.
            num_leaders (int): Embedding dimensionality.
            t (int): Diffusion steps.
            m (int): Expansion size per leader.

        Returns:
            np.ndarray: Embedding matrix of shape (n, num_leaders).
        """
        self.fit(num_candidates, num_leaders, t, m)
        return self.transform()
