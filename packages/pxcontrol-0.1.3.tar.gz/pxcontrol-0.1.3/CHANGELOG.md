# Changelog

All notable changes to `pxcontrol` will be documented here. The format
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and this
project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.3] - 2026-04-18

### Changed
- **BREAKING (HTTP status codes):** Middlewares
  (`PxControlASGIMiddleware`, `PxControlWSGIMiddleware`,
  `DjangoPxControlMiddleware`) now return `HTTP 402 Payment Required`
  when a project is `PAUSED` instead of `HTTP 503 Service Unavailable`.
  `OFFLINE` and `FAILED` continue to return `503`. The JSON error code
  for paused responses is `payment_required` (was `service_unavailable`).
- The default pause message is now `"Software Development payment is Due"`
  (was `"Service temporarily unavailable"`).

### Deprecated
- **Versions `0.1.2` and below are deprecated.** The control-plane API's
  `/api/v1/sdk/versions` endpoint now advertises `0.1.3` as the minimum
  supported release.

## [0.1.2] - 2026-04-18

### Changed
- Package metadata now points at the canonical repository
  [`Codefied-CodePix/px-sdk-py`](https://github.com/Codefied-CodePix/px-sdk-py)
  (`Source`, `Issues`, `Changelog`, `Homepage`).
- README badges updated to link to the real repository.

### Deprecated
- **Versions `0.1.1` and below are deprecated.** The control-plane API's
  `/api/v1/sdk/versions` endpoint now advertises `0.1.2` as the minimum
  supported release. Older clients still run but the boot-time version
  check will log a warning until you upgrade.

## [0.1.1] - 2026-04-17

### Changed
- Default `ws_url` switched from `wss://ws.pxcontrol.io` to
  `wss://api-pxcontrol.codefied.online` (same host now serves HTTP + WS).
- `api_url` derives from `ws_url` automatically.

## [0.1.0] - 2026-04-17

Initial public release.

### Added
- `PxClient` running an asyncio loop in a daemon thread so it works
  identically in sync (Flask, Django/WSGI, scripts) and async
  (FastAPI, Starlette) frameworks.
- Auto-reconnect with exponential backoff + full-jitter, capped at 60s.
- Middleware integrations:
  - `PxControlASGIMiddleware` — FastAPI / Starlette / any ASGI app.
  - `PxControlWSGIMiddleware` — Flask / classic Django / generic WSGI.
  - `DjangoPxControlMiddleware` — modern Django `MIDDLEWARE` class.
- Heartbeats (`30s` default) with `sdk_version`, `language`, `env`,
  `timestamp`.
- HTTP poll fallback (`GET /api/v1/status/{token}`) after 3 consecutive
  WS failures; stops automatically once the WS reconnects.
- Boot-time version check against `GET /api/v1/sdk/versions`.
- Configurable `fail_mode` (`closed` / `open`), `health_path`, `debug`,
  and all poll / version-check toggles via kwargs **or** environment
  variables (`PX_TOKEN`, `PX_WS_URL`, `PX_API_URL`, `PX_DEBUG`,
  `PX_DISABLE_POLL`, `PX_DISABLE_VERSION_CHECK`).
- Typed with `from __future__ import annotations`; supports Python 3.9+.
- Built on the modern `websockets.asyncio.client` API (requires
  `websockets>=13`).
