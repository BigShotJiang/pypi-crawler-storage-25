"""Framework middleware integrations for PXControl."""

from __future__ import annotations

import json
from typing import Any, Awaitable, Callable, Iterable, Optional

from .client import PxClient, get_client

DEFAULT_HEALTH_PATH = "/health"

# HTTP status code returned for each non-ACTIVE project state.
#
#   PAUSED  -> 402 Payment Required   (intentional "hold" — e.g. unpaid invoice)
#   OFFLINE -> 503 Service Unavailable (temporary outage / maintenance)
#   FAILED  -> 503 Service Unavailable (emergency stop)
_STATUS_CODE = {"PAUSED": 402, "OFFLINE": 503, "FAILED": 503}
_ERROR_CODE = {
    "PAUSED": "payment_required",
    "OFFLINE": "service_unavailable",
    "FAILED": "service_unavailable",
}
_STATUS_LINE = {402: "402 Payment Required", 503: "503 Service Unavailable"}


def _build_block_body(message: str, status: str) -> bytes:
    error = _ERROR_CODE.get(status, "service_unavailable")
    return json.dumps({"error": error, "status": status, "message": message}).encode(
        "utf-8"
    )


def _decision(
    client: PxClient, path: str, health_path: str
) -> Optional[tuple[int, bytes]]:
    """Return ``(status_code, body)`` if the request must be blocked, else ``None``."""
    if path == health_path:
        return None
    status = client.get_status()
    if status == "ACTIVE":
        return None
    if status == "PAUSED":
        return _STATUS_CODE["PAUSED"], _build_block_body(client.get_pause_message(), "PAUSED")
    if status in ("OFFLINE", "FAILED"):
        return _STATUS_CODE[status], _build_block_body(client.get_offline_message(), status)
    return None


# ====================================================================== ASGI

class PxControlASGIMiddleware:
    """ASGI middleware (FastAPI / Starlette / any ASGI app)."""

    def __init__(
        self,
        app: Callable[..., Awaitable[None]],
        client: Optional[PxClient] = None,
        health_path: str = DEFAULT_HEALTH_PATH,
        **client_kwargs: Any,
    ) -> None:
        self.app = app
        self.client = client or get_client(**client_kwargs)
        self.health_path = health_path

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")
        decision = _decision(self.client, path, self.health_path)
        if decision is None:
            await self.app(scope, receive, send)
            return

        status_code, body = decision
        await send(
            {
                "type": "http.response.start",
                "status": status_code,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode("ascii")),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


# ====================================================================== WSGI

class PxControlWSGIMiddleware:
    """WSGI middleware (Flask / classic Django / generic WSGI)."""

    def __init__(
        self,
        app: Callable[[dict, Callable], Iterable[bytes]],
        client: Optional[PxClient] = None,
        health_path: str = DEFAULT_HEALTH_PATH,
        **client_kwargs: Any,
    ) -> None:
        self.app = app
        self.client = client or get_client(**client_kwargs)
        self.health_path = health_path

    def __call__(self, environ: dict, start_response: Callable) -> Iterable[bytes]:
        path = environ.get("PATH_INFO", "")
        decision = _decision(self.client, path, self.health_path)
        if decision is None:
            return self.app(environ, start_response)

        status_code, body = decision
        status_line = _STATUS_LINE.get(status_code, f"{status_code} Blocked by PXControl")
        headers = [
            ("Content-Type", "application/json"),
            ("Content-Length", str(len(body))),
        ]
        start_response(status_line, headers)
        return [body]


# ==================================================================== Django

class DjangoPxControlMiddleware:
    """Django-style middleware class.

    Add to ``MIDDLEWARE`` in ``settings.py``::

        MIDDLEWARE = [
            "pxcontrol.DjangoPxControlMiddleware",
            ...
        ]

    Configure via the ``PXCONTROL`` Django setting (optional)::

        PXCONTROL = {
            "TOKEN": "px_xxxxx",        # else PX_TOKEN env
            "WS_URL": "wss://...",       # else PX_WS_URL env
            "HEALTH_PATH": "/health",
        }
    """

    def __init__(self, get_response: Callable) -> None:
        self.get_response = get_response
        try:
            from django.conf import settings as django_settings  # type: ignore

            cfg = getattr(django_settings, "PXCONTROL", {}) or {}
        except Exception:  # pragma: no cover - django is optional
            cfg = {}

        self.health_path = cfg.get("HEALTH_PATH", DEFAULT_HEALTH_PATH)
        self.client = get_client(
            token=cfg.get("TOKEN"),
            ws_url=cfg.get("WS_URL"),
        )

    def __call__(self, request: Any) -> Any:
        path = getattr(request, "path", "")
        decision = _decision(self.client, path, self.health_path)
        if decision is None:
            return self.get_response(request)

        status_code, body = decision
        try:
            from django.http import HttpResponse  # type: ignore

            return HttpResponse(body, status=status_code, content_type="application/json")
        except Exception:  # pragma: no cover
            raise RuntimeError(
                "DjangoPxControlMiddleware requires Django to be installed"
            )
