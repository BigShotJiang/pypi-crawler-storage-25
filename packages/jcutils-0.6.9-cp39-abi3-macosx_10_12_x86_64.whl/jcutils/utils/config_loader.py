# coding: utf-8
"""
nacos-sdk-python
pyapollo-zenkilan
"""

from __future__ import annotations

import asyncio
import importlib
import importlib.util
import os
import sys
from typing import TYPE_CHECKING

from dotenv import dotenv_values, load_dotenv

from .platform_ import is_mac, is_windows

if TYPE_CHECKING:
    from schema import AppConfig  # 只有 IDE/类型检查时才执行，运行时跳过

SCHEMA_PATH = os.path.join(os.getcwd(), "schema.py")

# 先加载 .env（不覆盖已有环境变量）
load_dotenv(override=False)


class ConfigLoader:
    """配置加载器"""

    _config_dict = {}

    @staticmethod
    def _merge_with_env(source_config: dict) -> dict:
        """只用环境变量覆盖配置源中已有的 key，避免系统环境变量污染业务配置"""
        return {k: os.environ.get(k, v) for k, v in source_config.items()}

    @classmethod
    def _load_from_nacos(cls) -> dict:
        """从 Nacos 拉取配置，合并环境变量（环境变量优先级更高）"""
        from ..utils.nacos_client import NacosClient

        NACOS_SERVER = os.getenv("NACOS_SERVER", default="")
        NACOS_NAMESPACE = os.getenv("NACOS_NAMESPACE") or os.getenv("ENV", default="dev").lower()
        NACOS_GROUP = os.getenv("NACOS_GROUP", default="")
        NACOS_DATA_ID = os.getenv("NACOS_DATA_ID", default="")
        NACOS_USERNAME = os.getenv("NACOS_USERNAME", default="")
        NACOS_PASSWORD = os.getenv("NACOS_PASSWORD", default="")

        if (
            not NACOS_SERVER
            or not NACOS_NAMESPACE
            or not NACOS_GROUP
            or not NACOS_DATA_ID
            or not NACOS_USERNAME
            or not NACOS_PASSWORD
        ):
            raise ValueError(
                "使用 Nacos 时必须配置 NACOS_SERVER、NACOS_NAMESPACE、NACOS_GROUP、NACOS_DATA_ID、NACOS_USERNAME 和 NACOS_PASSWORD"
            )

        print(f"[config] 从 Nacos 加载配置: {NACOS_SERVER}")
        print(f"[config] NACOS_NAMESPACE: {NACOS_NAMESPACE}，NACOS_DATA_ID: {NACOS_DATA_ID}")

        nacos_client = NacosClient(
            server=NACOS_SERVER, namespace=NACOS_NAMESPACE, username=NACOS_USERNAME, password=NACOS_PASSWORD
        )

        async def _fetch():
            async with nacos_client:
                return await nacos_client.get_dict(NACOS_DATA_ID, NACOS_GROUP)

        nacos_config = asyncio.run(_fetch())
        if not nacos_config:
            raise Exception(f"Nacos 配置拉取失败: DATA_ID={NACOS_DATA_ID}, GROUP={NACOS_GROUP}")

        nacos_config["APP_NAME"] = NACOS_DATA_ID
        nacos_config["ENV"] = NACOS_NAMESPACE

        return cls._merge_with_env(nacos_config)

    @classmethod
    def _load_from_apollo(cls) -> dict:
        """从 Apollo 拉取所有命名空间配置，合并环境变量（环境变量优先级更高）"""
        from pyapollo.client import ApolloClient  # type: ignore

        APOLLO_META_SERVER_ADDRESS = os.getenv("APOLLO_META_SERVER_ADDRESS", default="")
        APOLLO_APP_ID = os.getenv("APOLLO_APP_ID", default="")
        APOLLO_APP_SECRET = os.getenv("APOLLO_APP_SECRET", default="")
        APOLLO_CLUSTER = os.getenv("APOLLO_CLUSTER", default="default")
        APOLLO_ENV = os.getenv("APOLLO_ENV") or os.getenv("ENV", "DEV")
        APOLLO_NAMESPACES = os.getenv("APOLLO_NAMESPACES", "application").split(",")

        if not APOLLO_META_SERVER_ADDRESS:
            raise ValueError("APOLLO_META_SERVER_ADDRESS 未配置")
        if not APOLLO_APP_ID:
            raise ValueError("使用 Apollo 时必须配置 APOLLO_APP_ID")

        print(f"[config] 从 Apollo 加载配置: {APOLLO_META_SERVER_ADDRESS}")
        print(f"[config] APOLLO_APP_ID: {APOLLO_APP_ID}，APOLLO_ENV: {APOLLO_ENV}")

        client = ApolloClient(
            meta_server_address=APOLLO_META_SERVER_ADDRESS,
            app_id=APOLLO_APP_ID,
            app_secret=APOLLO_APP_SECRET,
            cluster=APOLLO_CLUSTER,
            env=APOLLO_ENV,
            namespaces=APOLLO_NAMESPACES,
        )

        apollo_config = {}
        for ns in APOLLO_NAMESPACES:
            ns_config = client._cache.get(ns.strip(), {})
            for k, v in ns_config.items():
                apollo_config[k] = str(v) if isinstance(v, dict) else v

        if not apollo_config:
            raise Exception(f"Apollo 配置为空: APP_ID={APOLLO_APP_ID}, NAMESPACES={APOLLO_NAMESPACES}")

        apollo_config["APP_NAME"] = APOLLO_APP_ID
        apollo_config["ENV"] = APOLLO_ENV

        return cls._merge_with_env(apollo_config)

    @classmethod
    def _load_from_consul(cls) -> dict:
        """从 Consul KV 拉取配置，合并环境变量（环境变量优先级更高）

        依赖：pip install python-consul2

        KV 路径约定（两种方式二选一）：
          1. 显式指定前缀：CONSUL_PREFIX=myapp/prod/
          2. 自动拼接：{CONSUL_APP_ID}/{CONSUL_ENV}/  →  例如 myapp/dev/

        KV 结构示例：
          myapp/dev/DB_HOST        → "127.0.0.1"
          myapp/dev/DB_PORT        → "5432"
          myapp/dev/feature/ENABLE → "true"   # 子目录 "/" 会被替换为 "_"，key 变为 FEATURE_ENABLE
        """
        import consul.aio  # type: ignore

        CONSUL_HOST = os.getenv("CONSUL_HOST", default="127.0.0.1")
        CONSUL_PORT = int(os.getenv("CONSUL_PORT", default="8500"))
        CONSUL_TOKEN = os.getenv("CONSUL_TOKEN", default="")
        CONSUL_PREFIX = os.getenv("CONSUL_PREFIX", default="")
        CONSUL_APP_ID = os.getenv("CONSUL_APP_ID", default="")
        CONSUL_ENV = os.getenv("CONSUL_ENV") or os.getenv("ENV", default="dev").lower()

        if not CONSUL_PREFIX and not CONSUL_APP_ID:
            raise ValueError("使用 Consul 时必须配置 CONSUL_PREFIX 或 CONSUL_APP_ID（作为 KV 路径前缀）")

        # 优先用 CONSUL_PREFIX，否则自动拼接 {APP_ID}/{ENV}/
        kv_prefix = CONSUL_PREFIX or f"{CONSUL_APP_ID}/{CONSUL_ENV}/"
        # 统一确保末尾有 "/"，避免 recurse 时匹配到同名前缀的其他路径
        if not kv_prefix.endswith("/"):
            kv_prefix += "/"

        print(f"[config] 从 Consul 加载配置: {CONSUL_HOST}:{CONSUL_PORT}")
        print(f"[config] KV prefix: {kv_prefix}")

        async def _fetch() -> dict:
            client = consul.aio.Consul(
                host=CONSUL_HOST,
                port=CONSUL_PORT,
                token=CONSUL_TOKEN or None,
            )
            try:
                _, data = await client.kv.get(kv_prefix, recurse=True)
            finally:
                # python-consul2 aio 底层使用 aiohttp，需手动关闭 session
                if hasattr(client.http, "_session") and client.http._session:
                    await client.http._session.close()

            if not data:
                raise Exception(f"Consul KV 配置为空或路径不存在: prefix={kv_prefix}")

            result = {}
            prefix_len = len(kv_prefix)
            for item in data:
                raw_key: str = item["Key"]
                raw_value: bytes | None = item["Value"]
                if raw_value is None:
                    continue  # 目录节点，跳过
                # 去掉公共前缀，子路径 "/" → "_"，全部大写 → 对齐其他来源的 key 风格
                key = raw_key[prefix_len:].lstrip("/").replace("/", "_").upper()
                if not key:
                    continue
                result[key] = raw_value.decode("utf-8")

            return result

        consul_config = asyncio.run(_fetch())
        if not consul_config:
            raise Exception(f"Consul 配置拉取后为空: prefix={kv_prefix}")

        consul_config["APP_NAME"] = CONSUL_APP_ID or kv_prefix.strip("/").split("/")[0]
        consul_config["ENV"] = CONSUL_ENV

        return cls._merge_with_env(consul_config)

    @classmethod
    def _load_from_local(cls) -> dict:
        """从 .env 读取配置，合并环境变量"""
        print("[config] 从 .env 加载配置")
        ENV = os.getenv("ENV", default="dev").lower()
        APP_NAME = os.getenv("APP_NAME", default="")
        local_config = dict(dotenv_values(".env"))
        local_config["APP_NAME"] = APP_NAME
        local_config["ENV"] = ENV
        return cls._merge_with_env(local_config)

    @staticmethod
    def _infer_type(value: str) -> str:
        if value.lower() in ("true", "false"):
            return "bool"
        try:
            int(value)
            return "int"
        except ValueError:
            pass
        try:
            float(value)
            return "float"
        except ValueError:
            pass
        return "str"

    @staticmethod
    def _cast_value(value: str, type_hint: str):
        """将字符串值按类型提示转换为对应的 Python 类型"""
        if not isinstance(value, str):
            return value  # 非字符串（已经是正确类型）直接返回
        if type_hint == "bool":
            return value.lower() == "true"
        if type_hint == "int":
            return int(value)
        if type_hint == "float":
            return float(value)
        return value  # str，保持原样

    @staticmethod
    def _format_key(key: str) -> str:
        return key.replace("-", "_").replace(".", "_").upper()

    @classmethod
    def _build_schema_content(cls, raw: dict) -> str:
        lines = [
            "from pydantic import BaseModel",
            "from typing import Optional",
            "",
            "",
            "class AppConfig(BaseModel):",
        ]
        if not raw:
            lines.append("    pass")
        for key, value in sorted(raw.items()):
            k = cls._format_key(key)
            t = cls._infer_type(str(value))
            lines.append(f"    {k}: {t}")
        return "\n".join(lines)

    @classmethod
    def _load_schema_module(cls) -> type[AppConfig]:
        """动态加载或重载 schema 模块，返回最新的 AppConfig 类"""
        if "schema" in sys.modules:
            module = importlib.reload(sys.modules["schema"])
        else:
            spec = importlib.util.spec_from_file_location("schema", SCHEMA_PATH)
            assert spec is not None and spec.loader is not None
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            sys.modules["schema"] = module
        return getattr(module, "AppConfig")

    @classmethod
    def sync_schema(cls) -> type[AppConfig]:
        """判断 schema.py 是否存在或发生变化，按需生成，返回最新的 AppConfig 类"""
        new_content = cls._build_schema_content(cls._config_dict)

        if os.path.exists(SCHEMA_PATH):
            with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
                existing_content = f.read()
            if existing_content == new_content:
                print("[config] schema.py 无变化，跳过生成")
            else:
                print("[config] schema.py 已变化，更新生成")
                with open(SCHEMA_PATH, "w", encoding="utf-8") as f:
                    f.write(new_content)
                print(f"[config] schema.py 更新完成，共 {len(cls._config_dict)} 个配置项")
        else:
            print("[config] schema.py 不存在，生成中")
            with open(SCHEMA_PATH, "w", encoding="utf-8") as f:
                f.write(new_content)
            print(f"[config] schema.py 生成完成，共 {len(cls._config_dict)} 个配置项")

        return cls._load_schema_module()

    @classmethod
    def _get_dirs(cls, app_name: str) -> tuple[str, str]:
        if is_windows():
            drive = "D:\\" if os.path.exists("D:\\") else "C:\\"
            return os.path.join(drive, "data", app_name), os.path.join(drive, "logs", app_name)
        elif is_mac():
            home = os.path.expanduser("~")
            return os.path.join(home, "data", app_name), os.path.join(home, "logs", app_name)
        else:
            return os.path.join("/data", app_name), os.path.join("/logs", app_name)

    @classmethod
    def load_config(cls, init_dirs: bool = False) -> AppConfig:
        """
        根据 CONFIG_SOURCE 判断配置来源：
        - nacos  → 从 Nacos 拉取，再合并环境变量
        - apollo → 从 Apollo 拉取，再合并环境变量
        - local（默认）→ 从 .env 读取，再合并环境变量
        """
        CONFIG_SOURCE = os.getenv("CONFIG_SOURCE", "local").lower()

        if CONFIG_SOURCE == "nacos":
            config_dict = cls._load_from_nacos()
        elif CONFIG_SOURCE == "apollo":
            config_dict = cls._load_from_apollo()
        elif CONFIG_SOURCE == "consul":
            config_dict = cls._load_from_consul()
        else:
            config_dict = cls._load_from_local()

        cls._config_dict = config_dict

        if init_dirs:
            # 按需创建目录
            app_name = config_dict.get("APP_NAME", "")
            data_dir, logs_dir = cls._get_dirs(app_name)
            for d in [data_dir, logs_dir]:
                os.makedirs(d, exist_ok=True)
            # 注入到 config_dict，schema 会自动生成这两个字段
            config_dict["DATA_DIR"] = data_dir
            config_dict["LOGS_DIR"] = logs_dir

        # 生成/更新 schema.py，并拿到当次运行最新的 AppConfig 类
        LatestAppConfig = cls.sync_schema()

        # 按 schema 字段定义的类型，将字符串值转换为正确的 Python 类型
        typed_config = {}
        for k, v in config_dict.items():
            if k not in LatestAppConfig.model_fields:  # 忽略 schema 中未定义的字段
                continue
            type_hint = cls._infer_type(str(v))
            typed_config[k] = cls._cast_value(str(v), type_hint)

        app_config = LatestAppConfig.model_construct(**typed_config)

        return app_config
