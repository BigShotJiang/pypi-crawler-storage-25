"""Tests for ARD Mediathek API client."""

from mediathekwatch.api import ARD


class TestExtractShowId:
    def test_extracts_id_from_series_url(self):
        url = "https://www.ardmediathek.de/serie/feuer-und-flamme/staffel-11/Y3JpZDovL3dkci5kZS9mZXVlcnVuZGZsYW1tZQ/11"
        result = ARD.extract_show_id(url)
        assert result == "Y3JpZDovL3dkci5kZS9mZXVlcnVuZGZsYW1tZQ"

    def test_extracts_id_from_sendung_url(self):
        url = "https://www.ardmediathek.de/sendung/ABC123/verylongbase64encodedstringgoeshere1234567890abcdef"
        result = ARD.extract_show_id(url)
        assert result == "verylongbase64encodedstringgoeshere1234567890abcdef"

    def test_returns_none_for_short_id(self):
        url = "https://www.ardmediathek.de/serie/feuer-und-flamme/11"
        result = ARD.extract_show_id(url)
        assert result is None


class TestExtractSeasonFromWidget:
    def test_staffel(self):
        assert ARD._extract_season_from_widget({"title": "Staffel 11"}) == 11

    def test_season(self):
        assert ARD._extract_season_from_widget({"title": "Season 5"}) == 5

    def test_no_title(self):
        assert ARD._extract_season_from_widget({}) == 1


class TestParseTeaser:
    def test_basic(self):
        teaser = {
            "id": "12345",
            "title": "Episode 5 - Der neue Fall",
            "links": {"target": {"href": "/video/12345"}},
            "seasonNumber": 11,
            "episodeNumber": 5,
            "duration": 3600,
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert ep.episode_id == "12345"
        assert ep.title == "Episode 5 - Der neue Fall"
        assert ep.season == 11
        assert ep.episode_number == 5
        assert ep.duration == 3600
        assert ep.url == "https://www.ardmediathek.de/video/12345"

    def test_no_explicit_numbers(self):
        teaser = {
            "id": "67890",
            "title": "Folge 3",
            "links": {"target": {"href": "https://example.com/video"}},
        }
        ep = ARD._parse_teaser(teaser)
        assert ep is not None
        assert ep.episode_number == 3
        assert ep.season == 1

    def test_fallback_episode_numbering(self):
        from mediathekwatch.models import Episode

        episodes = [
            Episode(episode_id="c", title="C", season=1, episode_number=0, url="u3", aired_date="2026-04-20T16:00:00Z"),
            Episode(episode_id="a", title="A", season=1, episode_number=0, url="u1", aired_date="2026-04-06T16:00:00Z"),
            Episode(episode_id="b", title="B", season=1, episode_number=0, url="u2", aired_date="2026-04-13T16:00:00Z"),
        ]
        result = ARD._assign_fallback_episode_numbers(episodes)
        by_id = {ep.episode_id: ep for ep in result}
        assert by_id["a"].episode_number == 1  # oldest
        assert by_id["b"].episode_number == 2
        assert by_id["c"].episode_number == 3  # newest

    def test_fallback_skips_explicit_numbers(self):
        from mediathekwatch.models import Episode

        episodes = [
            Episode(episode_id="a", title="A", season=1, episode_number=0, url="u1", aired_date="2026-04-06T16:00:00Z"),
            Episode(episode_id="b", title="B", season=1, episode_number=5, url="u2", aired_date="2026-04-13T16:00:00Z"),
            Episode(episode_id="c", title="C", season=1, episode_number=0, url="u3", aired_date="2026-04-20T16:00:00Z"),
        ]
        result = ARD._assign_fallback_episode_numbers(episodes)
        by_id = {ep.episode_id: ep for ep in result}
        assert by_id["a"].episode_number == 1
        assert by_id["b"].episode_number == 5  # preserved
        assert by_id["c"].episode_number == 2  # skips 5
