"""Handler for ARD Mediathek API interactions."""

import re
import sys
from typing import Optional
from urllib.parse import urlparse

import requests

from mediathekwatch.models import Episode
from mediathekwatch.statics import HEADERS

BASE_URL = "https://api.ardmediathek.de/page-gateway/widgets/ard/asset/"
PLAYER_URL_TEMPLATE = "https://www.ardmediathek.de/video/{episode_id}"

MAX_PAGES = 50
PAGE_SIZE = 100

SEASON_WIDGET_PATTERNS = [
    r"Staffel\s+(\d+)",
    r"Season\s+(\d+)",
    r"(\d+)\.?\s*Staffel",
]

SEASON_TITLE_PATTERNS = [
    r"S(\d+)/E\d+",
    r"Staffel\s+(\d+)",
    r"Season\s+(\d+)",
]

EPISODE_TITLE_PATTERNS = [
    r"Folge\s+(\d+)",
    r"Episode\s+(\d+)",
    r"\((\d+)/\d+\)",
    r"S\d+/E(\d+)",
]

TITLE_CLEANUP_PATTERNS = [
    r"\s*\(S\d+/E\d+\)\s*$",  # " (S11/E09)" at end
    r"^Folge\s+\d+:\s*",  # "Folge 9: " at start
    r"^Episode\s+\d+:\s*",  # "Episode 9: " at start
]

ARD_SHOW_ID_RE = re.compile(r"^[A-Za-z0-9_-]+$", re.ASCII)


class ARD:
    """Handler for ARD Mediathek API interactions."""

    SHOW_ID_RE = ARD_SHOW_ID_RE

    @staticmethod
    def fetch_series_name(show_id: str) -> Optional[str]:
        """Fetch the series/show name from the ARD API."""
        try:
            data = ARD._fetch_page(show_id, 1)
            # Top-level title is the series name
            title = data.get("title")
            if title and title.strip():
                return title.strip()
            # Fallback: check links.self.title
            links = data.get("links", {})
            self_link = links.get("self", {})
            if isinstance(self_link, dict):
                title = self_link.get("title")
                if title and title.strip():
                    return title.strip()
            # Fallback: check first teaser's show title
            teasers = data.get("teasers", [])
            if teasers:
                show = teasers[0].get("show", {})
                if isinstance(show, dict):
                    title = show.get("title")
                    if title and title.strip():
                        return title.strip()
            return None
        except Exception as e:
            print(f"Error fetching series name: {e}", file=sys.stderr)
            return None

    @staticmethod
    def extract_show_id(url: str) -> Optional[str]:
        """Extract the show ID from an ARD Mediathek URL."""
        path = urlparse(url).path
        parts = [p for p in path.split("/") if p]

        for part in reversed(parts):
            if len(part) > 20 and ARD.SHOW_ID_RE.match(part):
                return part

        return None

    @staticmethod
    def _extract_season_from_widget(widget: dict) -> int:
        """Try to extract season number from widget title (e.g., 'Staffel 11')."""
        title = widget.get("title", "")
        if not title:
            return 1

        for pattern in SEASON_WIDGET_PATTERNS:
            match = re.search(pattern, title, re.IGNORECASE)
            if match:
                return int(match.group(1))
        return 1

    @staticmethod
    def _fetch_page(show_id: str, page: int = 1) -> dict:
        """Fetch a single page of widgets from the ARD API."""
        url = f"{BASE_URL}{show_id}?pageSize={PAGE_SIZE}&pageNumber={page - 1}"
        response = requests.get(url, headers=HEADERS, timeout=30)
        response.raise_for_status()
        return response.json()

    @staticmethod
    def _process_teasers(teasers: list[dict], seen_ids: set[str], target_season: Optional[int]) -> list[Episode]:
        """Process a flat list of teasers into episodes."""
        episodes = []
        for teaser in teasers:
            episode = ARD._parse_teaser(teaser)
            if not episode or episode.episode_id in seen_ids:
                continue
            seen_ids.add(episode.episode_id)
            if target_season is not None and episode.season != target_season:
                continue
            episodes.append(episode)
        return episodes

    @staticmethod
    def _process_widget_teasers(widgets: list[dict], seen_ids: set[str], target_season: Optional[int]) -> list[Episode]:
        """Process widget-based teaser structure into episodes."""
        episodes = []
        for widget in widgets:
            widget_teasers = widget.get("teasers", [])
            if not widget_teasers:
                continue
            widget_season = ARD._extract_season_from_widget(widget)
            for teaser in widget_teasers:
                episode = ARD._parse_teaser(teaser, default_season=widget_season)
                if not episode or episode.episode_id in seen_ids:
                    continue
                seen_ids.add(episode.episode_id)
                if target_season is not None and episode.season != target_season:
                    continue
                episodes.append(episode)
        return episodes

    @staticmethod
    def _assign_fallback_episode_numbers(episodes: list[Episode]) -> list[Episode]:
        """Assign sequential episode numbers to episodes that lack explicit ones.

        Groups by season, sorts by broadcast date (oldest first), and fills in
        episode_number == 0 with the next available sequential number. This keeps
        numbering stable for existing episodes when new ones are added later.
        """
        from collections import defaultdict
        from dataclasses import replace

        by_season: dict[int, list[Episode]] = defaultdict(list)
        for ep in episodes:
            by_season[ep.season].append(ep)

        result: list[Episode] = []
        for season_eps in by_season.values():
            used_numbers = {ep.episode_number for ep in season_eps if ep.episode_number != 0}
            # Sort by broadcast date (oldest first) so episode 1 = first aired
            season_eps.sort(key=lambda e: e.aired_date or "")
            next_number = 1
            for ep in season_eps:
                if ep.episode_number == 0:
                    while next_number in used_numbers:
                        next_number += 1
                    ep = replace(ep, episode_number=next_number)
                    used_numbers.add(next_number)
                    next_number += 1
                result.append(ep)

        # Preserve reverse-chronological order (newest first) to match API order
        result.sort(key=lambda e: e.aired_date or "", reverse=True)
        return result

    @staticmethod
    def fetch_episodes(show_id: str, target_season: Optional[int] = None) -> list[Episode]:
        """Fetch all episodes for a show from ARD Mediathek API."""
        episodes = []
        seen_ids = set()
        page = 1

        while True:
            try:
                data = ARD._fetch_page(show_id, page)
            except requests.RequestException as e:
                print(f"Error fetching page {page}: {e}", file=sys.stderr)
                break

            teasers = data.get("teasers", [])
            widgets = data.get("widgets", [])
            if teasers:
                episodes.extend(ARD._process_teasers(teasers, seen_ids, target_season))
            else:
                if not widgets:
                    break
                episodes.extend(ARD._process_widget_teasers(widgets, seen_ids, target_season))

            items_on_page = len(teasers) if teasers else sum(len(w.get("teasers", [])) for w in widgets)
            if items_on_page == 0:
                break

            page += 1
            if page > MAX_PAGES:
                print("Warning: Reached page limit, stopping pagination", file=sys.stderr)
                break

        episodes = ARD._assign_fallback_episode_numbers(episodes)
        return episodes

    @staticmethod
    def _extract_title(teaser: dict) -> str:
        """Extract title from teaser using various possible keys."""
        return teaser.get("title") or teaser.get("shortTitle") or teaser.get("mediumTitle") or teaser.get("longTitle") or "Unknown"

    @staticmethod
    def _extract_season(teaser: dict, default_season: int, title: str) -> int:
        """Extract season number from explicit fields or title patterns."""
        if "seasonNumber" in teaser and teaser["seasonNumber"] is not None:
            return int(teaser["seasonNumber"])

        for pattern in SEASON_TITLE_PATTERNS:
            match = re.search(pattern, title, re.IGNORECASE)
            if match:
                return int(match.group(1))

        return default_season

    @staticmethod
    def _extract_episode_number(teaser: dict, title: str) -> int:
        """Extract episode number from explicit fields or title patterns."""
        if "episodeNumber" in teaser and teaser["episodeNumber"] is not None:
            return int(teaser["episodeNumber"])

        for pattern in EPISODE_TITLE_PATTERNS:
            match = re.search(pattern, title, re.IGNORECASE)
            if match:
                return int(match.group(1))

        return 0

    @staticmethod
    def _clean_title(title: str) -> str:
        """Remove redundant metadata patterns from title."""
        for pattern in TITLE_CLEANUP_PATTERNS:
            title = re.sub(pattern, "", title, flags=re.IGNORECASE).strip()
        return title

    @staticmethod
    def _parse_teaser(teaser: dict, default_season: int = 1) -> Optional[Episode]:
        """Parse a teaser item into an Episode object."""
        try:
            episode_id = teaser.get("id")
            if not episode_id:
                return None

            title = ARD._extract_title(teaser)
            season = ARD._extract_season(teaser, default_season, title)
            episode_number = ARD._extract_episode_number(teaser, title)
            title = ARD._clean_title(title)

            url = PLAYER_URL_TEMPLATE.format(episode_id=episode_id)

            aired_date = teaser.get("broadcastedOn") or teaser.get("availableTo")
            duration = teaser.get("duration")

            return Episode(
                episode_id=episode_id,
                title=title,
                season=season,
                episode_number=episode_number,
                url=url,
                aired_date=aired_date,
                duration=duration,
            )
        except (KeyError, ValueError, TypeError) as e:
            print(f"Warning: Failed to parse teaser: {e}", file=sys.stderr)
            return None
