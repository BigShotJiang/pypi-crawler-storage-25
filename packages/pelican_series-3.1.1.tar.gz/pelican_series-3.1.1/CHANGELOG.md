CHANGELOG
=========

3.1.1 - 2026-04-04
------------------

Fix #31 - Series breaks on draft articles

Contributed by [Leonardo Giordani](https://github.com/lgiordani) via [PR #43](https://github.com/pelican-plugins/series/pull/43/)


3.1.0 - 2025-10-30
------------------

Support translations in series

3.0.0 - 2024-04-29
------------------

Add series metadata to pages.

Change `series` global context variable to `article_series`.

Improve documentation.

2.1.0 - 2021-05-04
------------------

* Add `series` dictionary to the generator context
* Add better tests (including indexed articles) and improve the documentation

2.0.0 - 2021-03-19
------------------

Convert and release as namespace plugin

1.0.0 - 2016-10-06
------------------

Initial release
