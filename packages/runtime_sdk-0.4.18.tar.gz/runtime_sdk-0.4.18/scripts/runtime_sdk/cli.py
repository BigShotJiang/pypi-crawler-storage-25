from __future__ import annotations

import argparse
import contextlib
import importlib
import json
import os
import select
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import webbrowser
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urljoin, urlparse

from websockets.exceptions import ConnectionClosed, InvalidHandshake
from websockets.sync.client import connect as websocket_connect

from runtime_sdk import __version__
from runtime_sdk.client import DEFAULT_WARMUP_TIMEOUT, RuntimeAPIError, RuntimeClient
from runtime_sdk.config import (
    DEFAULT_BASE_URL,
    PendingSignup,
    RuntimeConfig,
    RuntimeConfigError,
    load_config,
    save_config,
)


# --------------------------------------------------------------------------- #
# TTY detection + lazy rich/questionary imports                               #
# --------------------------------------------------------------------------- #


def _interactive() -> bool:
    """True when we have a real terminal on both ends — enables fancy UI."""
    if os.environ.get("RUNTIME_NO_TTY"):
        return False
    try:
        return sys.stdin.isatty() and sys.stdout.isatty()
    except (AttributeError, ValueError):
        return False


SPINNER = "aesthetic"  # unicode ▰▱ progress-bar style; single place to tweak.


def _with_spinner(label: str, fn: Callable[[], Any]) -> Any:
    """Run fn(), wrapped in a rich spinner when interactive."""
    if not _interactive():
        return fn()
    with _UI.console().status(f"[cyan]{label}[/cyan]", spinner=SPINNER):
        return fn()


class _UI:
    """Lazy holder for rich + questionary so non-TTY paths stay import-cheap."""

    _console: Any = None
    _err_console: Any = None
    _questionary: Any = None
    _questionary_style: Any = None
    _rich_mods: dict[str, Any] | None = None

    @classmethod
    def console(cls) -> Any:
        if cls._console is None:
            from rich.console import Console

            cls._console = Console()
        return cls._console

    @classmethod
    def err(cls) -> Any:
        if cls._err_console is None:
            from rich.console import Console

            cls._err_console = Console(stderr=True)
        return cls._err_console

    @classmethod
    def q(cls) -> Any:
        if cls._questionary is None:
            import questionary

            cls._questionary = questionary
        return cls._questionary

    @classmethod
    def style(cls) -> Any:
        if cls._questionary_style is None:
            cls._questionary_style = cls.q().Style(
                [
                    ("qmark", "fg:#22c55e bold"),
                    ("question", "bold fg:#e5e7eb"),
                    ("answer", "fg:#22c55e bold"),
                    ("pointer", "fg:#60a5fa bold"),
                    ("highlighted", "fg:#ffffff bg:#1f2937 bold"),
                    ("selected", "fg:#22c55e bold"),
                    ("separator", "fg:#4b5563"),
                    ("instruction", "fg:#94a3b8 italic"),
                    ("text", "fg:#d1d5db"),
                    ("disabled", "fg:#6b7280 italic"),
                ]
            )
        return cls._questionary_style

    @classmethod
    def rich(cls) -> dict[str, Any]:
        if cls._rich_mods is None:
            from rich import box
            from rich.panel import Panel
            from rich.table import Table
            from rich.text import Text

            cls._rich_mods = {"Panel": Panel, "Text": Text, "Table": Table, "box": box}
        return cls._rich_mods


# --------------------------------------------------------------------------- #
# argparse                                                                    #
# --------------------------------------------------------------------------- #


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="runtime")
    parser.add_argument("--base-url", help="Override the Runtime API base URL")
    parser.add_argument("--version", action="version", version=f"runtime-sdk {__version__}")

    # Subcommand is optional: bare `runtime` defaults to `create`.
    subparsers = parser.add_subparsers(dest="command", required=False)

    signup = subparsers.add_parser("signup", help="Send an email verification code")
    signup.add_argument("email", nargs="?", default=None)
    signup.add_argument("--name", default=None)

    verify = subparsers.add_parser("verify", help="Verify an emailed code and save a fresh API key")
    verify.add_argument("code", nargs="?", default=None)
    verify.add_argument("--flow-id", type=int)

    login = subparsers.add_parser("login", help="Start email login or import an API key")
    login.add_argument(
        "identifier",
        nargs="?",
        default=None,
        help="Email address to send a code to, or an API key for backwards compatibility",
    )
    login.add_argument("--name", default=None, help="Optional display name for first-time email signup")
    login.add_argument(
        "--api-key",
        nargs="?",
        const="",
        default=None,
        help="Import an API key explicitly (prompts if omitted in interactive mode)",
    )

    subparsers.add_parser("whoami")
    subparsers.add_parser("logout")

    api_keys_cmd = subparsers.add_parser("api-keys", help="Manage Runtime API keys")
    api_keys_subparsers = api_keys_cmd.add_subparsers(dest="api_keys_action", required=True)
    api_keys_subparsers.add_parser("list", aliases=["ls"], help="List API keys")
    api_keys_create = api_keys_subparsers.add_parser("create", help="Create a new API key")
    api_keys_create.add_argument("label", nargs="?", default=None, help="Human-friendly label for the new API key")
    api_keys_revoke = api_keys_subparsers.add_parser("revoke", help="Revoke an API key")
    api_keys_revoke.add_argument("id", nargs="?", default=None, help="API key id")

    secrets_cmd = subparsers.add_parser("secrets", help="Manage account-level secret sets")
    secrets_subparsers = secrets_cmd.add_subparsers(dest="secrets_action", required=True)
    secrets_subparsers.add_parser("list", aliases=["ls"], help="List secret sets")
    secrets_show = secrets_subparsers.add_parser("show", help="Show one secret set")
    secrets_show.add_argument("slug", nargs="?", default=None, help="Secret set slug")
    secrets_set = secrets_subparsers.add_parser("set", help="Create or replace a secret set from KEY=VALUE pairs")
    secrets_set.add_argument("slug", nargs="?", default=None, help="Secret set slug")
    secrets_set.add_argument("pairs", nargs="*", help="KEY=VALUE pairs")
    secrets_import = secrets_subparsers.add_parser("import", help="Create or replace a secret set from a .env file")
    secrets_import.add_argument("slug", nargs="?", default=None, help="Secret set slug")
    secrets_import.add_argument("--env-file", required=True, help="Path to .env file")
    secrets_delete = secrets_subparsers.add_parser("delete", aliases=["rm"], help="Delete a secret set")
    secrets_delete.add_argument("slug", nargs="?", default=None, help="Secret set slug")

    integrations_cmd = subparsers.add_parser("integrations", help="Connect account-level integrations")
    integrations_subparsers = integrations_cmd.add_subparsers(dest="integrations_action", required=True)
    integrations_connect = integrations_subparsers.add_parser("connect", help="Connect an integration")
    integrations_connect.add_argument("provider", choices=["github"])
    integrations_connect.add_argument("--slug", default="github", help="Integration slug to create (default: github)")
    integrations_connect.add_argument("--owner", default=None, help="GitHub username or org where the app is installed")
    integrations_connect.add_argument("--no-open", action="store_true", help="Print the install URL instead of opening a browser")

    create_cmd = subparsers.add_parser("create", help="Create a new computer with the starter app published by default")
    create_cmd.add_argument(
        "name",
        nargs="?",
        default=None,
        help="Subdomain name (e.g. redsox → redsox.runruntime.dev). Random if skipped.",
    )
    create_cmd.add_argument("--command", dest="startup_command", help="Durable startup command to save on create")
    create_cmd.add_argument("--cwd", help="Working directory for the durable startup command")
    create_cmd.add_argument("--port", type=int, help="App port to publish for durable startup")
    subparsers.add_parser("list", aliases=["ls"], help="List computers")

    enter_cmd = subparsers.add_parser("enter", help="Enter a computer's console")
    enter_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    info_cmd = subparsers.add_parser("info", help="Get computer details")
    info_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    url_cmd = subparsers.add_parser("url", help="Show a computer's public URL and live published port")
    url_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    start_cmd = subparsers.add_parser("start", help="Wake a cold computer")
    start_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    delete_cmd = subparsers.add_parser("delete", aliases=["rm"], help="Delete a computer")
    delete_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    run_cmd = subparsers.add_parser("run", help="Run a one-shot command in a computer")
    run_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    run_cmd.add_argument(
        "run_command",
        metavar="command",
        nargs="?",
        default=None,
        help="Command to run",
    )
    run_cmd.add_argument("--uid", type=int, help="User ID")
    run_cmd.add_argument("--gid", type=int, help="Group ID")
    run_cmd.add_argument("--cwd", help="Working directory")
    run_cmd.add_argument("--shell", help="Shell to use")

    publish_cmd = subparsers.add_parser(
        "publish", help="Promote the running app on a local port into the durable public app"
    )
    publish_cmd.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    publish_cmd.add_argument("port", nargs="?", type=int, default=None, help="Local app port")

    startup_cmd = subparsers.add_parser("startup", help="Manage durable startup config")
    startup_subparsers = startup_cmd.add_subparsers(dest="startup_action", required=True)
    startup_show = startup_subparsers.add_parser("show", help="Show durable startup config")
    startup_show.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    startup_set = startup_subparsers.add_parser("set", help="Set durable startup config")
    startup_set.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    startup_set.add_argument("--command", dest="startup_value_command", required=True, help="Durable startup command")
    startup_set.add_argument("--cwd", help="Working directory for the durable startup command")
    startup_set.add_argument("--port", required=True, type=int, help="App port to publish for durable startup")
    startup_clear = startup_subparsers.add_parser("clear", help="Clear durable startup config")
    startup_clear.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    service_cmd = subparsers.add_parser("service", help="Manage the durable published app service")
    service_subparsers = service_cmd.add_subparsers(dest="service_action", required=True)
    service_show = service_subparsers.add_parser("show", help="Show the durable published app service")
    service_show.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")
    service_clear = service_subparsers.add_parser("clear", help="Clear the durable published app service")
    service_clear.add_argument("id", nargs="?", default=None, help="Computer ID (hostname)")

    proxy_cmd = subparsers.add_parser("proxy", help="Manage background local port proxies")
    proxy_subparsers = proxy_cmd.add_subparsers(dest="proxy_command", required=True)
    proxy_start = proxy_subparsers.add_parser("start", help="Start one or more background local port proxies")
    proxy_start.add_argument("id", help="Computer ID (hostname)")
    proxy_start.add_argument("ports", nargs="+", help="Port mappings like 5432 or 15432:5432")
    proxy_subparsers.add_parser("ls", help="List background local port proxies")
    proxy_stop = proxy_subparsers.add_parser("stop", help="Stop one or more background local port proxies")
    proxy_stop.add_argument("local_ports", nargs="*", type=int, help="Local ports to stop")
    proxy_stop.add_argument("--all", action="store_true", help="Stop all running proxies")

    proxy_agent = subparsers.add_parser("_proxy_agent", help=argparse.SUPPRESS)
    proxy_agent.add_argument("--base-url", required=True)
    proxy_agent.add_argument("--computer-id", required=True)
    proxy_agent.add_argument("--display-name", required=True)
    proxy_agent.add_argument("--local-port", type=int, required=True)
    proxy_agent.add_argument("--remote-port", type=int, required=True)

    return parser


def _windows_unsupported() -> bool:
    return sys.platform == "win32"



def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if _windows_unsupported():
        return report_error("runtime-sdk supports macOS and Linux only; Windows is not supported")

    try:
        config = load_config()
        if args.base_url:
            config.base_url = args.base_url
        elif os.environ.get("RUNTIME_BASE_URL"):
            config.base_url = str(os.environ.get("RUNTIME_BASE_URL"))
        else:
            config.base_url = config.configured_base_url or DEFAULT_BASE_URL

        # Bare `runtime` → first-run onboarding for interactive users, create otherwise.
        if args.command is None:
            if _interactive() and not config.api_key:
                return handle_onboarding(config)
            args.command = "create"
            args.name = None

        if args.command == "signup":
            return handle_signup(config, args.email, args.name)
        if args.command == "verify":
            return handle_verify(config, args.code, args.flow_id)
        if args.command == "login":
            return handle_login(config, args.identifier, args.name, args.api_key)
        if args.command == "whoami":
            return handle_whoami(config)
        if args.command == "logout":
            return handle_logout(config)
        if args.command == "api-keys":
            if args.api_keys_action in ("list", "ls"):
                return handle_api_keys_list(config)
            if args.api_keys_action == "create":
                return handle_api_keys_create(config, args.label)
            if args.api_keys_action == "revoke":
                return handle_api_keys_revoke(config, args.id)
            return report_error("unknown api-keys command")
        if args.command == "secrets":
            if args.secrets_action in ("list", "ls"):
                return handle_secrets_list(config)
            if args.secrets_action == "show":
                return handle_secrets_show(config, args.slug)
            if args.secrets_action == "set":
                return handle_secrets_set(config, args.slug, args.pairs)
            if args.secrets_action == "import":
                return handle_secrets_import(config, args.slug, args.env_file)
            if args.secrets_action in ("delete", "rm"):
                return handle_secrets_delete(config, args.slug)
            return report_error("unknown secrets command")
        if args.command == "integrations":
            if args.integrations_action == "connect":
                return handle_integrations_connect(config, args.provider, args.slug, args.owner, no_open=args.no_open)
            return report_error("unknown integrations command")
        if args.command == "create":
            return handle_create(
                config,
                args.name,
                getattr(args, "startup_command", None),
                getattr(args, "cwd", None),
                getattr(args, "port", None),
            )
        if args.command in ("list", "ls"):
            return handle_list(config)
        if args.command == "info":
            return handle_info(config, args.id)
        if args.command == "url":
            return handle_url(config, args.id)
        if args.command == "start":
            return handle_start(config, args.id)
        if args.command == "enter":
            return handle_enter(config, args.id)
        if args.command in ("delete", "rm"):
            return handle_delete(config, args.id)
        if args.command == "run":
            return handle_run(
                config, args.id, args.run_command, args.uid, args.gid, args.cwd, args.shell
            )
        if args.command == "publish":
            return handle_publish(config, args.id, args.port)
        if args.command == "startup":
            if args.startup_action == "show":
                return handle_startup_show(config, args.id)
            if args.startup_action == "set":
                return handle_startup_set(config, args.id, args.startup_value_command, args.cwd, args.port)
            if args.startup_action == "clear":
                return handle_startup_clear(config, args.id)
            return report_error("unknown startup command")
        if args.command == "service":
            if args.service_action == "show":
                return handle_service_show(config, args.id)
            if args.service_action == "clear":
                return handle_service_clear(config, args.id)
            return report_error("unknown service command")
        if args.command == "proxy":
            if args.proxy_command == "start":
                return handle_proxy_start(config, args.id, args.ports)
            if args.proxy_command == "ls":
                return handle_proxy_ls(config)
            if args.proxy_command == "stop":
                return handle_proxy_stop(config, args.local_ports, stop_all=args.all)
            return report_error("unknown proxy command")
        if args.command == "_proxy_agent":
            return run_proxy_agent(
                args.base_url,
                os.environ.get("RUNTIME_PROXY_API_KEY", ""),
                args.computer_id,
                args.display_name,
                args.local_port,
                args.remote_port,
            )
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)
    except RuntimeConfigError as exc:
        return report_error(str(exc))
    except KeyboardInterrupt:
        if _interactive():
            UI = _UI.err()
            UI.print("\n[dim]cancelled[/dim]")
            return 130
        return report_error("cancelled")

    return report_error("unknown command")


# --------------------------------------------------------------------------- #
# Shared helpers                                                              #
# --------------------------------------------------------------------------- #


def write_json(payload: dict[str, Any], *, error: bool = False) -> int:
    stream = sys.stderr if error else sys.stdout
    stream.write(json.dumps(payload) + "\n")
    return 1 if error else 0


def report_error(message: str, *, status_code: int | None = None) -> int:
    """Error output — JSON in non-TTY mode, rich in TTY mode."""
    if _interactive():
        err = _UI.err()
        suffix = f" [dim](http {status_code})[/dim]" if status_code is not None else ""
        err.print(f"[bold red]✗[/bold red] {message}{suffix}")
        return 1
    payload: dict[str, Any] = {"success": False, "error": message}
    if status_code is not None:
        payload["status_code"] = status_code
    return write_json(payload, error=True)


def report_success(payload: dict[str, Any], renderer: Callable[[dict[str, Any]], None] | None = None) -> int:
    """Success output — rich renderer in TTY, JSON otherwise."""
    if _interactive() and renderer is not None:
        renderer(payload)
        return 0
    return write_json({"success": True, **payload})


def _require_api_key(config: RuntimeConfig) -> int | None:
    if config.api_key:
        return None
    return report_error("missing api key; run login or verify first")


def _runtime_state_dir() -> Path:
    root = os.environ.get("XDG_STATE_HOME")
    if root:
        return Path(root) / "runtime"
    return Path.home() / ".local" / "state" / "runtime"


def _proxy_dir() -> Path:
    return _runtime_state_dir() / "proxies"


def _proxy_state_path(local_port: int) -> Path:
    return _proxy_dir() / f"proxy-{local_port}.json"


def _proxy_log_path(local_port: int) -> Path:
    return _proxy_dir() / f"proxy-{local_port}.log"


def _pid_running(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def _pid_command(pid: int) -> str:
    if pid <= 0:
        return ""
    try:
        return subprocess.check_output(
            ["ps", "-o", "command=", "-p", str(pid)],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (OSError, subprocess.SubprocessError):
        return ""


def _proxy_pid_matches(pid: int, local_port: int) -> bool:
    if not _pid_running(pid):
        return False
    command = _pid_command(pid)
    if not command:
        return False
    with contextlib.suppress(ValueError):
        argv = shlex.split(command)
        if "_proxy_agent" not in argv:
            return False
        if "--local-port" not in argv:
            return False
        index = argv.index("--local-port")
        if index + 1 >= len(argv) or argv[index + 1] != str(local_port):
            return False
        return "runtime_sdk.cli" in argv or any(part.endswith("runtime_sdk.cli") for part in argv)
    return False


def _load_proxy_records(*, clean_stale: bool = False) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    directory = _proxy_dir()
    if not directory.exists():
        return records
    for path in sorted(directory.glob("proxy-*.json")):
        try:
            record = json.loads(path.read_text())
        except (OSError, ValueError):
            continue
        if not isinstance(record, dict):
            continue
        record["state_path"] = str(path)
        pid = int(record.get("pid") or 0)
        local_port = int(record.get("local_port") or 0)
        record["status"] = "running" if _proxy_pid_matches(pid, local_port) else "stopped"
        if clean_stale and record["status"] != "running":
            with contextlib.suppress(OSError):
                path.unlink()
            continue
        records.append(record)
    return records


def _parse_proxy_port_spec(spec: str) -> tuple[int, int]:
    text = str(spec or "").strip()
    if not text:
        raise RuntimeAPIError("port mapping is required")
    if ":" in text:
        local_text, remote_text = text.split(":", 1)
    else:
        local_text, remote_text = text, text
    try:
        local_port = int(local_text)
        remote_port = int(remote_text)
    except ValueError as exc:
        raise RuntimeAPIError(f"invalid port mapping: {text}") from exc
    for port in (local_port, remote_port):
        if port <= 0 or port > 65535:
            raise RuntimeAPIError("port must be between 1 and 65535")
    return local_port, remote_port


def _resolve_ws_url(base_url: str, ws_url: Any) -> str:
    text = str(ws_url or "").strip()
    if not text:
        return ""
    if text.startswith("ws://") or text.startswith("wss://"):
        return text

    parsed = urlparse(base_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    root = f"{scheme}://{parsed.netloc}"
    if text.startswith("/"):
        return root + text
    return urljoin(root + "/", text)


def _spawn_proxy_agent(base_url: str, api_key: str, computer_id: str, display_name: str, local_port: int, remote_port: int) -> int:
    proxy_dir = _proxy_dir()
    proxy_dir.mkdir(parents=True, exist_ok=True)
    log_path = _proxy_log_path(local_port)
    log_file = log_path.open("a", encoding="utf-8")
    child_env = os.environ.copy()
    child_env["RUNTIME_PROXY_API_KEY"] = api_key
    try:
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "runtime_sdk.cli",
                "_proxy_agent",
                "--base-url",
                base_url,
                "--computer-id",
                computer_id,
                "--display-name",
                display_name,
                "--local-port",
                str(local_port),
                "--remote-port",
                str(remote_port),
            ],
            stdin=subprocess.DEVNULL,
            stdout=log_file,
            stderr=log_file,
            start_new_session=True,
            close_fds=True,
            env=child_env,
        )
    finally:
        log_file.close()

    deadline = time.time() + max(4.0, DEFAULT_WARMUP_TIMEOUT + 2.0)
    state_path = _proxy_state_path(local_port)
    while time.time() < deadline:
        if state_path.exists():
            return proc.pid
        code = proc.poll()
        if code is not None:
            break
        time.sleep(0.1)

    message = f"proxy failed to start on localhost:{local_port}"
    with contextlib.suppress(OSError):
        tail = log_path.read_text(encoding="utf-8").strip()
        if tail:
            message = tail.splitlines()[-1]
    raise RuntimeAPIError(message)


def _remove_proxy_state(local_port: int) -> None:
    with contextlib.suppress(OSError):
        _proxy_state_path(local_port).unlink()


def _stop_proxy_ports(local_ports: list[int], *, stop_all: bool = False) -> list[dict[str, Any]]:
    records = _load_proxy_records(clean_stale=False)
    stopped: list[dict[str, Any]] = []
    wanted = set(local_ports)
    for record in records:
        port = int(record.get("local_port") or 0)
        if not stop_all and port not in wanted:
            continue
        pid = int(record.get("pid") or 0)
        if _proxy_pid_matches(pid, port):
            with contextlib.suppress(OSError):
                os.kill(pid, signal.SIGTERM)
        _remove_proxy_state(port)
        record["status"] = "stopped"
        stopped.append(record)
    return stopped


def _prompt_text(message: str, *, default: str | None = None) -> str | None:
    """Ask for a line of text. Returns None if the user left it blank.

    Ctrl-C propagates as KeyboardInterrupt, handled centrally by main().
    """
    answer = _UI.q().text(message, default=default or "").unsafe_ask()
    return answer.strip() or None


def _prompt_password(message: str) -> str | None:
    answer = _UI.q().password(message).unsafe_ask()
    return answer.strip() or None


def _prompt_confirm(message: str, *, default: bool = False) -> bool:
    return bool(_UI.q().confirm(message, default=default).unsafe_ask())


def _display_width(value: Any, minimum: int, maximum: int) -> int:
    text = str(value or "")
    return max(minimum, min(len(text), maximum))


def _fit_cell(value: Any, width: int) -> str:
    text = str(value or "")
    if width <= 0:
        return ""
    if len(text) > width:
        if width == 1:
            return "…"
        text = text[: width - 1] + "…"
    return text.ljust(width)


def _computer_power_state(c: dict[str, Any]) -> str:
    power = c.get("power_state")
    if power is not None:
        return str(power or "?")
    status = str(c.get("status") or "?")
    if status in ("warm", "cold"):
        return status
    if status == "deleted":
        return "cold"
    return "warm"



def _computer_internal_status(c: dict[str, Any]) -> str:
    internal = c.get("internal_status")
    if internal is not None:
        return str(internal or "?")
    return str(c.get("status") or "?")



def _computer_status_label(c: dict[str, Any]) -> str:
    power = _computer_power_state(c)
    internal = _computer_internal_status(c)
    if power == internal:
        return power
    if power == "warm" and internal == "running":
        return power
    return f"{power}/{internal}"



def _computer_matches_ref(c: dict[str, Any], ref: str) -> bool:
    ref = ref.strip()
    if not ref:
        return False

    candidates = {
        str(c.get("id") or "").strip(),
        str(c.get("slug") or "").strip(),
        str(c.get("hostname") or "").strip(),
        str(c.get("public_url") or "").strip(),
    }

    public_url = str(c.get("public_url") or "").strip()
    if public_url:
        parsed = urlparse(public_url)
        if parsed.netloc:
            candidates.add(parsed.netloc)
            first_label = parsed.netloc.split(".", 1)[0].strip()
            if first_label:
                candidates.add(first_label)

    return ref in {value for value in candidates if value}



def _resolve_computer_ref(client: RuntimeClient, ref: str) -> str:
    ref = ref.strip()
    if not ref:
        raise RuntimeAPIError("computer id is required")
    if ref.startswith("cmp_"):
        return ref

    try:
        payload = client.list_computers()
    except RuntimeAPIError:
        return ref

    computers = payload.get("computers") or []
    if not isinstance(computers, list):
        computers = []

    matches = [c for c in computers if isinstance(c, dict) and _computer_matches_ref(c, ref)]
    if len(matches) == 1:
        resolved = str(matches[0].get("id") or "").strip()
        return resolved or ref
    if len(matches) > 1:
        raise RuntimeAPIError(f"multiple computers matched {ref!r}; use the exact computer id")
    raise RuntimeAPIError(f"computer {ref!r} not found")



def _computer_name(c: dict[str, Any]) -> str:
    return str(c.get("slug") or c.get("id") or "?")



def _computer_url_label(c: dict[str, Any]) -> str:
    public_url = str(c.get("public_url") or "").strip()
    if not public_url:
        return ""
    parsed = urlparse(public_url)
    return parsed.netloc or public_url



def _relative_time_label(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        created = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return raw
    delta = datetime.now(timezone.utc) - created.astimezone(timezone.utc)
    seconds = max(0, int(delta.total_seconds()))
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    if hours < 24:
        return f"{hours}h"
    days = hours // 24
    return f"{days}d"



def _computer_created_label(c: dict[str, Any]) -> str:
    return _relative_time_label(c.get("created_at"))



def _computer_status_style(status: str) -> str:
    if "cold" in status:
        return "bold cyan"
    if "warm" in status or "running" in status:
        return "bold green"
    if "archiving" in status or "restoring" in status:
        return "bold yellow"
    if "creating" in status:
        return "bold magenta"
    if "orphaned" in status:
        return "bold red"
    return "white"



def _computer_status_dot(status: str) -> str:
    if "cold" in status:
        return "◌"
    if "warm" in status or "running" in status:
        return "●"
    if "archiving" in status or "restoring" in status:
        return "◐"
    if "creating" in status:
        return "◔"
    if "orphaned" in status:
        return "✕"
    return "•"



def _computer_sort_key(c: dict[str, Any]) -> tuple[int, str, str]:
    status = _computer_status_label(c)
    priority = 1
    if "warm" in status or "running" in status:
        priority = 0
    elif "cold" in status:
        priority = 1
    elif "restoring" in status or "creating" in status:
        priority = 2
    else:
        priority = 3
    return (priority, _computer_name(c).lower(), str(c.get("id") or ""))



def _computer_table_layout(computers: list[dict[str, Any]]) -> dict[str, int]:
    term_width = shutil.get_terminal_size((100, 20)).columns
    slug_width = max(_display_width(_computer_name(c), len("name"), 24) for c in computers)
    status_width = max(
        _display_width(_computer_status_label(c), len("state"), 20)
        for c in computers
    )
    created_width = max(
        _display_width(_computer_created_label(c), len("age"), 8)
        for c in computers
    )
    reserved = slug_width + status_width + created_width + len("  ") * 3
    url_budget = max(16, term_width - reserved)
    url_width = max(
        len("url"),
        min(max(len(_computer_url_label(c)) for c in computers), url_budget),
    )
    return {
        "slug": slug_width,
        "status": status_width,
        "public_url": url_width,
        "created_at": created_width,
    }


def _format_computer_row(c: dict[str, Any], widths: dict[str, int]) -> str:
    return " │ ".join(
        [
            _fit_cell(_computer_name(c), widths["slug"]),
            _fit_cell(_computer_status_label(c), widths["status"]),
            _fit_cell(_computer_url_label(c), widths["public_url"]),
            _fit_cell(_computer_created_label(c), widths["created_at"]),
        ]
    )


def _computer_table_prompt(prompt: str, computers: list[dict[str, Any]]) -> tuple[str, dict[str, int]]:
    widths = _computer_table_layout(computers)
    header = " │ ".join(
        [
            _fit_cell("name", widths["slug"]),
            _fit_cell("state", widths["status"]),
            _fit_cell("url", widths["public_url"]),
            _fit_cell("age", widths["created_at"]),
        ]
    )
    divider = "─" * len(header)
    return f"{prompt}\n{header}\n{divider}", widths



def _computer_choice_title(c: dict[str, Any], widths: dict[str, int]) -> str:
    del widths
    status = _computer_status_label(c)
    url = _computer_url_label(c)
    created = _computer_created_label(c)
    parts = [f"{_computer_name(c)}", status]
    if url:
        parts.append(url)
    if created:
        parts.append(created)
    return "  ·  ".join(parts)



def _render_computer_summary(computers: list[dict[str, Any]]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    counts: dict[str, int] = {}
    for computer in computers:
        status = _computer_status_label(computer)
        counts[status] = counts.get(status, 0) + 1

    body = Text()
    body.append(f"total {len(computers)}", style="bold white")
    if counts:
        body.append("   ")
    first = True
    status_styles = {
        "warm": "bold green",
        "cold": "bold cyan",
        "running": "bold green",
        "archiving": "bold yellow",
        "restoring": "bold yellow",
        "creating": "bold magenta",
        "orphaned": "bold red",
    }
    for status in sorted(counts):
        if not first:
            body.append("  •  ", style="dim")
        first = False
        status_style = "bold white"
        for token, style in status_styles.items():
            if token in status:
                status_style = style
                break
        body.append(status, style=status_style)
        body.append(f" {counts[status]}", style="white")

    _UI.console().print(
        Panel(body, title="runtime", border_style="blue", expand=False, padding=(0, 1))
    )



def _render_computer_table(computers: list[dict[str, Any]], *, title: str | None = None) -> None:
    mods = _UI.rich()
    Table, box = mods["Table"], mods["box"]
    table = Table(
        title=title,
        box=box.MINIMAL_DOUBLE_HEAD,
        expand=True,
        show_lines=False,
        header_style="bold #7dd3fc",
        title_style="bold white",
        pad_edge=False,
        collapse_padding=True,
        row_styles=["", "dim"],
    )
    table.add_column("Name", style="bold white", no_wrap=True, ratio=2)
    table.add_column("State", no_wrap=True, ratio=2)
    table.add_column("URL", style="white", overflow="fold", ratio=4)
    table.add_column("Age", style="dim", no_wrap=True, justify="right", ratio=1)

    for computer in sorted(computers, key=_computer_sort_key):
        status = _computer_status_label(computer)
        status_style = _computer_status_style(status)
        table.add_row(
            _computer_name(computer),
            f"[{status_style}]{_computer_status_dot(status)} {status}[/{status_style}]",
            _computer_url_label(computer),
            _computer_created_label(computer),
        )

    _UI.console().print(table)


def _select_prompt(message: str, choices: list[Any]) -> Any:
    return _UI.q().select(
        message,
        choices=choices,
        qmark="●",
        pointer="❯",
        instruction="↑/↓ or j/k • Enter",
        use_indicator=True,
        style=_UI.style(),
    )


def _pick_computer(
    config: RuntimeConfig,
    prompt: str,
    predicate: Callable[[dict[str, Any]], bool] | None = None,
) -> dict[str, Any] | None:
    """Fetch computers and let the user arrow-key through them.

    Returns the picked computer dict, or None if the list is empty or the user
    explicitly chose "← cancel". Ctrl-C propagates as KeyboardInterrupt.
    """
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    payload = client.list_computers()
    computers = payload.get("computers") or []
    if not isinstance(computers, list):
        computers = []
    if predicate is not None:
        computers = [c for c in computers if isinstance(c, dict) and predicate(c)]
    computers = sorted(computers, key=_computer_sort_key)
    if not computers:
        _UI.err().print("[yellow]no matching computers found[/yellow]")
        return None

    questionary = _UI.q()
    widths = _computer_table_layout(computers)
    _render_computer_table(computers)
    choices = [
        questionary.Choice(title=_computer_choice_title(c, widths), value=c) for c in computers
    ]
    choices.append(questionary.Choice(title="← cancel", value=None))
    picked = _select_prompt(prompt, choices).unsafe_ask()
    return picked if isinstance(picked, dict) else None


# --------------------------------------------------------------------------- #
# Rich renderers                                                              #
# --------------------------------------------------------------------------- #


def _render_computer_panel(c: dict[str, Any], *, title: str = "computer") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    status = _computer_status_label(c)
    status_style = _computer_status_style(status)
    rows: list[tuple[str, str, str | None]] = [
        ("name", _computer_name(c), "bold white"),
        ("state", f"{_computer_status_dot(status)} {status}", status_style),
        ("url", _computer_url_label(c) or "—", "white"),
        ("age", _computer_created_label(c) or "—", "dim"),
        ("id", str(c.get("id") or "—"), "dim"),
    ]
    for label, value, style in rows:
        body.append(f"{label:<8}", style="dim")
        body.append(value, style=style or "white")
        body.append("\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False, padding=(0, 1)))


def _render_run_result(result: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel = mods["Panel"]
    console = _UI.console()
    stdout = result.get("stdout") or ""
    stderr = result.get("stderr") or ""
    exit_code = result.get("exit_code")
    if stdout:
        console.print(Panel(stdout.rstrip(), title="stdout", border_style="green", expand=False))
    if stderr:
        console.print(Panel(stderr.rstrip(), title="stderr", border_style="red", expand=False))
    color = "green" if exit_code == 0 else "red"
    console.print(f"[{color}]exit {exit_code}[/{color}]")


def _render_network_panel(payload: dict[str, Any], *, title: str = "url") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    status = str(payload.get("status") or "unknown")
    published_port = payload.get("published_port")
    startup_port = payload.get("startup_port")
    rows: list[tuple[str, str, str | None]] = [
        ("url", str(payload.get("public_url") or "—"), "cyan"),
        ("state", f"{_computer_status_dot(status)} {status}", _computer_status_style(status)),
    ]
    if published_port:
        rows.append(("port", str(published_port), "bold white"))
    elif startup_port:
        rows.append(("port", str(startup_port), "bold white"))
        rows.append(("source", "durable startup", "dim"))
    else:
        rows.append(("port", "—", "dim"))
    if published_port and startup_port and startup_port != published_port:
        rows.append(("startup", str(startup_port), "dim"))
    for label, value, style in rows:
        body.append(f"{label:<8}", style="dim")
        body.append(value, style=style or "white")
        body.append("\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False, padding=(0, 1)))


def _render_startup_panel(payload: dict[str, Any], *, title: str = "startup") -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    configured = bool(payload.get("configured"))
    rows: list[tuple[str, str, str | None]] = [("configured", "yes" if configured else "no", "bold white" if configured else "dim")]
    if configured:
        rows.extend(
            [
                ("command", str(payload.get("command") or "—"), "white"),
                ("cwd", str(payload.get("cwd") or "/home/ubuntu"), "dim"),
                ("port", str(payload.get("port") or "—"), "bold white"),
            ]
        )
    for label, value, style in rows:
        body.append(f"{label:<10}", style="dim")
        body.append(value, style=style or "white")
        body.append("\n")
    _UI.console().print(Panel(body, title=title, border_style="cyan", expand=False, padding=(0, 1)))


def _render_whoami_panel(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    owner = payload.get("owner") or {}
    rows: list[tuple[str, Any]] = [
        ("email", owner.get("email")),
        ("name", owner.get("name")),
        ("account id", payload.get("account_id")),
        ("trust tier", payload.get("trust_tier")),
    ]
    body = Text()
    for label, value in rows:
        if value is None:
            continue
        body.append(f"{label:<12}", style="dim")
        body.append(f"{value}\n")
    _UI.console().print(Panel(body, title="whoami", border_style="cyan", expand=False))



def _api_key_status_label(key: dict[str, Any]) -> str:
    if key.get("revoked_at"):
        return "revoked"
    if key.get("last_used_at"):
        return "used"
    return "unused"



def _api_key_status_style(status: str) -> str:
    if status == "revoked":
        return "bold red"
    if status == "used":
        return "bold green"
    return "yellow"



def _render_api_keys_table(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Table = mods["Table"]
    api_keys = payload.get("api_keys") or []
    if not isinstance(api_keys, list) or not api_keys:
        _UI.console().print("[yellow]no api keys found[/yellow]")
        return

    table = Table(title="API keys", expand=True, box=mods["box"].SIMPLE_HEAVY)
    table.add_column("ID", style="dim", no_wrap=True)
    table.add_column("Label", style="bold white")
    table.add_column("Prefix", style="white", no_wrap=True)
    table.add_column("Created", style="dim", no_wrap=True, justify="right")
    table.add_column("Last used", style="dim", no_wrap=True, justify="right")
    table.add_column("Status", no_wrap=True)

    for entry in api_keys:
        if not isinstance(entry, dict):
            continue
        status = _api_key_status_label(entry)
        style = _api_key_status_style(status)
        table.add_row(
            str(entry.get("id") or "—"),
            str(entry.get("label") or "—"),
            str(entry.get("key_prefix") or "—"),
            _relative_time_label(entry.get("created_at")) or "—",
            _relative_time_label(entry.get("last_used_at")) or "—",
            f"[{style}]{status}[/{style}]",
        )

    _UI.console().print(table)



def _render_api_key_created(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    key = payload.get("key") or {}
    secret = str(payload.get("api_key") or "")
    body = Text()
    rows = [
        ("id", key.get("id")),
        ("label", key.get("label")),
        ("prefix", key.get("key_prefix")),
    ]
    for label, value in rows:
        if value is None:
            continue
        body.append(f"{label:<12}", style="dim")
        body.append(f"{value}\n")
    if secret:
        body.append("save now     ", style="bold yellow")
        body.append("this secret is only shown once\n", style="yellow")
        body.append("api key      ", style="dim")
        body.append(secret, style="bold white")
        body.append("\n")
    _UI.console().print(Panel(body, title="api key created", border_style="cyan", expand=False))



def _render_secret_sets_table(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Table = mods["Table"]
    secret_sets = payload.get("secret_sets") or []
    if not isinstance(secret_sets, list) or not secret_sets:
        _UI.console().print("[yellow]no secret sets found[/yellow]")
        return

    table = Table(title="Secret sets", expand=True, box=mods["box"].SIMPLE_HEAVY)
    table.add_column("Slug", style="bold white")
    table.add_column("Keys", style="white")
    table.add_column("Updated", style="dim", no_wrap=True, justify="right")

    for entry in secret_sets:
        if not isinstance(entry, dict):
            continue
        keys = entry.get("keys") or []
        table.add_row(
            str(entry.get("slug") or "—"),
            ", ".join(str(key) for key in keys) or "—",
            _relative_time_label(entry.get("updated_at")) or "—",
        )

    _UI.console().print(table)



def _render_secret_set_panel(payload: dict[str, Any]) -> None:
    mods = _UI.rich()
    Panel, Text = mods["Panel"], mods["Text"]
    body = Text()
    body.append(f"{'slug':<12}", style="dim")
    body.append(f"{payload.get('slug') or '—'}\n")
    body.append(f"{'keys':<12}", style="dim")
    body.append(", ".join(str(key) for key in (payload.get("keys") or [])) or "—")
    _UI.console().print(Panel(body, title="secret set", border_style="cyan", expand=False))


# --------------------------------------------------------------------------- #
# Command handlers                                                            #
# --------------------------------------------------------------------------- #


def _looks_like_api_key(value: str | None) -> bool:
    candidate = (value or "").strip()
    return candidate.startswith("rt_live_")


def _begin_verification_flow(config: RuntimeConfig, email: str, name: str | None) -> dict[str, Any]:
    client = RuntimeClient(base_url=config.base_url)
    result = client.start_verification(email, name)
    config.pending_signup = PendingSignup(
        flow_id=int(result["flow_id"]),
        email=email,
        expires_at=result.get("expires_at"),
    )
    save_config(config)
    return result



def _start_verification_flow(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    if email is None:
        if not _interactive():
            return report_error("email is required")
        email = _prompt_text("Email")
        if not email:
            return report_error("email is required")

    result = _begin_verification_flow(config, email, name)

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print(
            f"[green]✓[/green] verification code sent to [bold]{email}[/bold]"
        )
        _UI.console().print(
            f"[dim]then run:[/dim] runtime verify <code>"
        )

    return report_success(result, render)



def _interactive_email_auth_flow(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    pending = config.pending_signup
    if email is None and pending is not None and pending.email:
        _UI.console().print(
            f"[green]✓[/green] verification code already sent to [bold]{pending.email}[/bold]"
        )
        code = _prompt_text("Verification code")
        if not code:
            return report_error("verification code is required")
        return handle_verify(config, code, pending.flow_id)

    if email is None:
        email = _prompt_text("Email")
        if not email:
            return report_error("email is required")

    _begin_verification_flow(config, email, name)
    _UI.console().print(
        f"[green]✓[/green] verification code sent to [bold]{email}[/bold]"
    )
    code = _prompt_text("Verification code")
    if not code:
        return report_error("verification code is required")
    return handle_verify(config, code, None)


def _login_with_api_key(config: RuntimeConfig, api_key: str | None) -> int:
    if api_key is None or api_key == "":
        if not _interactive():
            return report_error("api key is required")
        api_key = _prompt_password("API key")
        if not api_key:
            return report_error("api key is required")

    client = RuntimeClient(base_url=config.base_url, api_key=api_key)
    whoami = client.whoami()
    config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(_: dict[str, Any]) -> None:
        owner = whoami.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] api key saved")

    return report_success({"message": "logged in", **whoami}, render)


def handle_signup(config: RuntimeConfig, email: str | None, name: str | None) -> int:
    if _interactive():
        return _interactive_email_auth_flow(config, email, name)
    return _start_verification_flow(config, email, name)


def handle_verify(config: RuntimeConfig, code: str | None, flow_id: int | None) -> int:
    pending = config.pending_signup
    resolved_flow_id = flow_id or (pending.flow_id if pending else None)
    if not resolved_flow_id:
        return report_error("missing flow id; run login first or pass --flow-id")

    if code is None:
        if not _interactive():
            return report_error("verification code is required")
        code = _prompt_text("Verification code")
        if not code:
            return report_error("verification code is required")

    client = RuntimeClient(base_url=config.base_url)
    result = client.verify(resolved_flow_id, code)
    api_key = result.get("api_key")
    if api_key:
        config.api_key = api_key
    config.pending_signup = None
    save_config(config)

    def render(payload: dict[str, Any]) -> None:
        owner = payload.get("owner") or {}
        email = owner.get("email")
        if email:
            _UI.console().print(f"[green]✓[/green] verified, logged in as [bold]{email}[/bold]")
            return
        _UI.console().print("[green]✓[/green] verified, api key saved")

    return report_success(result, render)


def handle_login(
    config: RuntimeConfig,
    identifier: str | None,
    name: str | None,
    api_key: str | None,
) -> int:
    if api_key is not None:
        if identifier is not None:
            return report_error("pass either an email/api key argument or --api-key, not both")
        return _login_with_api_key(config, api_key)

    if _looks_like_api_key(identifier):
        return _login_with_api_key(config, identifier)

    if _interactive():
        return _interactive_email_auth_flow(config, identifier, name)
    return _start_verification_flow(config, identifier, name)


def handle_whoami(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.whoami()
    return report_success(result, _render_whoami_panel)


def handle_logout(config: RuntimeConfig) -> int:
    had_api_key = config.api_key is not None
    revoked = False
    if config.api_key:
        try:
            RuntimeClient(base_url=config.base_url, api_key=config.api_key).logout()
            revoked = True
        except RuntimeAPIError:
            revoked = False

    config.api_key = None
    config.pending_signup = None
    save_config(config)

    message = "logged out"
    if had_api_key and not revoked:
        message = "logged out locally"

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] {message}")

    return report_success({"message": message}, render)



def handle_api_keys_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_api_keys(), _render_api_keys_table)



def handle_api_keys_create(config: RuntimeConfig, label: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if label is None:
        if not _interactive():
            return report_error("label is required")
        label = _prompt_text("API key label")
        if not label:
            return report_error("label is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    result = client.create_api_key(label)
    return report_success(result, _render_api_key_created)



def handle_api_keys_revoke(config: RuntimeConfig, key_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if key_id is None:
        if not _interactive():
            return report_error("api key id is required")
        key_id = _prompt_text("API key id")
        if not key_id:
            return report_error("api key id is required")

    try:
        resolved_key_id = int(str(key_id).strip())
    except ValueError:
        return report_error("api key id must be a number")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    client.revoke_api_key(resolved_key_id)

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] api key {resolved_key_id} revoked")

    return report_success({"id": resolved_key_id, "message": f"api key {resolved_key_id} revoked"}, render)



def _coerce_secret_set_slug(slug: str | None) -> str | None:
    value = str(slug or "").strip()
    return value or None



def _parse_secret_pairs(pairs: list[str] | None) -> dict[str, str]:
    values: dict[str, str] = {}
    for pair in pairs or []:
        if "=" not in pair:
            raise RuntimeConfigError(f"invalid secret pair: {pair}")
        key, value = pair.split("=", 1)
        key = key.strip()
        if not key:
            raise RuntimeConfigError(f"invalid secret pair: {pair}")
        values[key] = value
    return values



def _parse_env_file(path: str) -> dict[str, str]:
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise RuntimeConfigError(f"failed to read env file: {exc}") from exc
    values: dict[str, str] = {}
    for raw_line in lines:
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[len("export "):].strip()
        if "=" not in line:
            raise RuntimeConfigError(f"invalid env line: {raw_line}")
        key, value = line.split("=", 1)
        key = key.strip()
        if not key:
            raise RuntimeConfigError(f"invalid env line: {raw_line}")
        value = value.strip()
        if value and value[0] == value[-1] and value[0] in {'\"', "'"}:
            value = value[1:-1]
        values[key] = value
    return values



def handle_secrets_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_secret_sets(), _render_secret_sets_table)



def handle_secrets_show(config: RuntimeConfig, slug: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.get_secret_set(resolved_slug), _render_secret_set_panel)



def handle_secrets_set(config: RuntimeConfig, slug: str | None, pairs: list[str] | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    values = _parse_secret_pairs(pairs)
    if not values:
        return report_error("at least one KEY=VALUE pair is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    secret_set = client.put_secret_set(resolved_slug, values)
    return report_success(
        {"secret_set": secret_set},
        lambda payload: _UI.console().print(f"[green]✓[/green] saved [bold]{payload['secret_set'].get('slug', resolved_slug)}[/bold]"),
    )



def handle_secrets_import(config: RuntimeConfig, slug: str | None, env_file: str) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    values = _parse_env_file(env_file)
    if not values:
        return report_error("env file did not contain any secrets")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    secret_set = client.put_secret_set(resolved_slug, values)
    return report_success(
        {"secret_set": secret_set},
        lambda payload: _UI.console().print(f"[green]✓[/green] saved [bold]{payload['secret_set'].get('slug', resolved_slug)}[/bold] from [bold]{env_file}[/bold]"),
    )



def handle_secrets_delete(config: RuntimeConfig, slug: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    resolved_slug = _coerce_secret_set_slug(slug)
    if resolved_slug is None:
        if not _interactive():
            return report_error("secret set slug is required")
        resolved_slug = _prompt_text("Secret set slug")
        if not resolved_slug:
            return report_error("secret set slug is required")
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    client.delete_secret_set(resolved_slug)
    return report_success(
        {"slug": resolved_slug, "deleted": True},
        lambda payload: _UI.console().print(f"[green]✓[/green] deleted [bold]{payload['slug']}[/bold]"),
    )



def handle_integrations_connect(
    config: RuntimeConfig,
    provider: str,
    slug: str | None,
    owner: str | None,
    *,
    no_open: bool = False,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if provider != "github":
        return report_error(f"unsupported integration provider: {provider}")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    payload = _with_spinner("getting GitHub install link…", lambda: client.start_github_connect(slug=slug))
    install_url = str(payload.get("install_url") or "").strip()
    resolved_slug = str(payload.get("slug") or slug or "github").strip() or "github"
    if not install_url:
        return report_error("server did not return a GitHub install URL")

    opened = False
    if not no_open:
        with contextlib.suppress(Exception):
            opened = bool(webbrowser.open(install_url))

    if _interactive():
        action = "opened in your browser" if opened else "copy this URL into your browser"
        _UI.console().print(f"[cyan]→[/cyan] {action}: [link={install_url}]{install_url}[/link]")
        _UI.console().print("[dim]Install the RuntimeVM GitHub App, then come back here.[/dim]")
        input("Press Enter after the GitHub App is installed... ")
        if not owner:
            owner = _prompt_text("GitHub owner (username or org)")
    elif not owner:
        return report_error("--owner is required without a TTY")

    resolved_owner = str(owner or "").strip()
    if not resolved_owner:
        return report_error("GitHub owner is required")

    integration = _with_spinner(
        "connecting GitHub…",
        lambda: client.create_integration(
            slug=resolved_slug,
            provider="github",
            transport="scoped_credential",
            backend="native",
            credential_source="external_account",
            credential_ref=resolved_owner,
            config={},
        ),
    )

    def render(result: dict[str, Any]) -> None:
        connected = result.get("integration") or {}
        _UI.console().print(
            f"[green]✓[/green] connected [bold]{connected.get('slug', resolved_slug)}[/bold] → [bold]{connected.get('credential_ref', resolved_owner)}[/bold]"
        )

    return report_success({"integration": integration, "install_url": install_url}, render)



def handle_onboarding(config: RuntimeConfig) -> int:
    code = handle_login(config, None, None, None)
    if code != 0:
        return code
    return handle_create(config, None, None, None, None)



def handle_create(
    config: RuntimeConfig,
    name: str | None,
    startup_command: str | None,
    cwd: str | None,
    port: int | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if name is None and _interactive():
        name = _prompt_text("Name your computer")

    if startup_command is None and port is not None:
        return report_error("startup command is required when port is provided")
    if startup_command is not None and port is None:
        return report_error("port is required when startup command is provided")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    label = "creating computer…"
    if startup_command is not None:
        label = f"creating computer and starting app on port {port}…"
    result = _with_spinner(
        label,
        lambda: client.create_computer(slug=name, command=startup_command, cwd=cwd, port=port),
    )

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="created")
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    code = report_success(result, render)
    if code != 0 or not _interactive():
        return code

    computer_id = result.get("id") or result.get("slug")
    if not computer_id:
        return code
    return _enter_computer(config, str(computer_id))


def handle_list(config: RuntimeConfig) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if _interactive():
        return _interactive_list(config)

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    return report_success(client.list_computers())


def handle_info(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_computer(computer_id)
    return report_success(result, lambda p: _render_computer_panel(p, title="computer"))


def handle_url(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_computer_network(computer_id)
    return report_success(result, lambda p: _render_network_panel(p, title="url"))


def handle_startup_show(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_startup_config(computer_id)
    return report_success(result, lambda p: _render_startup_panel(p, title="startup"))


def handle_startup_set(
    config: RuntimeConfig,
    computer_id: str | None,
    command: str | None,
    cwd: str | None,
    port: int | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    if not command:
        return report_error("startup command is required")
    if port is None:
        return report_error("port is required")
    if port <= 0 or port > 65535:
        return report_error("port must be between 1 and 65535")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"saving startup config for {computer_id}…",
        lambda: client.set_startup_config(computer_id, command=command, cwd=cwd, port=port),
    )
    return report_success(result, lambda p: _render_startup_panel(p, title="startup saved"))


def handle_startup_clear(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"clearing startup config for {computer_id}…",
        lambda: client.clear_startup_config(computer_id),
    )

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] cleared durable startup config for [bold]{computer_id}[/bold]")

    return report_success(result or {"configured": False}, render)


def handle_service_show(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = client.get_service_config(computer_id)
    return report_success(result, lambda p: _render_startup_panel(p, title="service"))


def handle_service_clear(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"clearing service for {computer_id}…",
        lambda: client.clear_service_config(computer_id),
    )

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] cleared durable service for [bold]{computer_id}[/bold]")

    return report_success(result or {"configured": False}, render)


def handle_start(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a cold computer to wake",
            lambda c: _computer_power_state(c) == "cold",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(f"warming {computer_id}…", lambda: client.start_computer(computer_id))

    def render(payload: dict[str, Any]) -> None:
        _render_computer_panel(payload, title="warmed")
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    return report_success(result, render)


def handle_enter(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not _interactive():
        return report_error("enter requires an interactive terminal")

    if computer_id is None:
        picked = _pick_computer(
            config,
            "Pick a computer to enter",
            lambda c: _computer_internal_status(c) in ("running", "cold"),
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, str(computer_id))
    return _enter_computer(config, str(computer_id))


def handle_delete(config: RuntimeConfig, computer_id: str | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    interactive_pick = False
    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(config, "Pick a computer to delete")
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")
        interactive_pick = True

    if interactive_pick:
        if not _prompt_confirm(
            f"Delete {computer_id}? This cannot be undone.", default=False
        ):
            _UI.console().print("[dim]cancelled[/dim]")
            return 0

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    display_ref = computer_id
    computer_id = _resolve_computer_ref(client, computer_id)
    client.delete_computer(computer_id)

    def render(_: dict[str, Any]) -> None:
        _UI.console().print(f"[green]✓[/green] deleted [bold]{display_ref}[/bold]")

    return report_success({"message": f"computer {display_ref} deleted"}, render)


def handle_run(
    config: RuntimeConfig,
    computer_id: str | None,
    command: str | None,
    uid: int | None,
    gid: int | None,
    cwd: str | None,
    shell: str | None,
) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a computer",
            lambda c: _computer_internal_status(c) == "running",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if command is None:
        if not _interactive():
            return report_error("command is required")
        command = _prompt_text("Command to run")
        if not command:
            return report_error("command is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"running on {computer_id}…",
        lambda: client.run_command(
            computer_id, command, uid=uid, gid=gid, cwd=cwd, shell=shell
        ),
    )
    return report_success(result, _render_run_result)


def handle_publish(config: RuntimeConfig, computer_id: str | None, port: int | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err

    if computer_id is None:
        if not _interactive():
            return report_error("computer id is required")
        picked = _pick_computer(
            config,
            "Pick a computer",
            lambda c: _computer_internal_status(c) == "running",
        )
        if picked is None:
            return 0
        computer_id = picked.get("id") or picked.get("slug")
        if not computer_id:
            return report_error("computer is missing an id")

    if port is None:
        if not _interactive():
            return report_error("port is required")
        port_text = _prompt_text("Port to publish", default="3000")
        if not port_text:
            return report_error("port is required")
        try:
            port = int(port_text)
        except ValueError:
            return report_error("port must be a number")

    if port <= 0 or port > 65535:
        return report_error("port must be between 1 and 65535")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    computer_id = _resolve_computer_ref(client, computer_id)
    result = _with_spinner(
        f"publishing port {port} on {computer_id}…",
        lambda: client.publish_port(computer_id, port),
    )

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print(
            f"[green]✓[/green] public url for [bold]{computer_id}[/bold] now points at durable app port [bold]{payload.get('published_port') or port}[/bold]"
        )
        url = payload.get("public_url")
        if url:
            _UI.console().print(f"[bold green]→[/bold green] [cyan]{url}[/cyan]")

    return report_success(result, render)


def handle_proxy_start(config: RuntimeConfig, computer_id: str | None, specs: list[str] | None) -> int:
    if (err := _require_api_key(config)) is not None:
        return err
    if not computer_id:
        return report_error("computer id is required")
    if not specs:
        return report_error("at least one port mapping is required")

    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    resolved_id = _resolve_computer_ref(client, computer_id)
    existing_records = _load_proxy_records(clean_stale=True)
    existing_ports = {int(r.get("local_port") or 0) for r in existing_records}
    mappings: list[tuple[int, int]] = []
    seen_ports: set[int] = set()
    for spec in specs:
        local_port, remote_port = _parse_proxy_port_spec(spec)
        if local_port in existing_ports:
            return report_error(f"local port {local_port} is already in use by a runtime proxy")
        if local_port in seen_ports:
            return report_error(f"local port {local_port} was specified more than once")
        seen_ports.add(local_port)
        mappings.append((local_port, remote_port))

    started: list[dict[str, Any]] = []
    started_ports: list[int] = []
    for local_port, remote_port in mappings:
        try:
            _spawn_proxy_agent(config.base_url, str(config.api_key or ""), resolved_id, computer_id, local_port, remote_port)
        except RuntimeAPIError as exc:
            if started_ports:
                _stop_proxy_ports(started_ports, stop_all=False)
            return report_error(str(exc), status_code=exc.status_code)
        except Exception as exc:
            if started_ports:
                _stop_proxy_ports(started_ports, stop_all=False)
            return report_error(str(exc))
        started_ports.append(local_port)
        started.append({"computer_id": resolved_id, "computer": computer_id, "local_port": local_port, "remote_port": remote_port})

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print("[green]✓[/green] proxy started")
        for proxy in payload.get("proxies", []):
            _UI.console().print(
                f"  [bold]localhost:{proxy['local_port']}[/bold] -> [cyan]{proxy['computer']}[/cyan]:{proxy['remote_port']}"
            )

    return report_success({"proxies": started}, render)


def handle_proxy_ls(config: RuntimeConfig) -> int:
    proxies = _load_proxy_records(clean_stale=True)

    def render(payload: dict[str, Any]) -> None:
        mods = _UI.rich()
        Table = mods["Table"]
        table = Table(title="proxies")
        table.add_column("VM", style="white")
        table.add_column("Local", style="cyan")
        table.add_column("Remote", style="white")
        table.add_column("Status", style="green")
        for proxy in payload.get("proxies", []):
            table.add_row(
                str(proxy.get("display_name") or proxy.get("computer_id") or "—"),
                str(proxy.get("local_port") or "—"),
                str(proxy.get("remote_port") or "—"),
                str(proxy.get("status") or "unknown"),
            )
        _UI.console().print(table)

    return report_success({"proxies": proxies}, render if _interactive() else None)


def handle_proxy_stop(config: RuntimeConfig, local_ports: list[int] | None, *, stop_all: bool = False) -> int:
    if not stop_all and not local_ports:
        return report_error("pass one or more local ports, or use --all")

    stopped = _stop_proxy_ports(local_ports or [], stop_all=stop_all)

    def render(payload: dict[str, Any]) -> None:
        _UI.console().print("[green]✓[/green] proxy stopped")
        for proxy in payload.get("proxies", []):
            _UI.console().print(
                f"  [bold]localhost:{proxy.get('local_port')}[/bold] -> [cyan]{proxy.get('display_name') or proxy.get('computer_id')}[/cyan]:{proxy.get('remote_port')}"
            )

    return report_success({"proxies": stopped}, render if _interactive() else None)


def _proxy_preflight(base_url: str, api_key: str, computer_id: str, remote_port: int) -> None:
    client = RuntimeClient(base_url=base_url, api_key=api_key)
    ticket_payload = client.create_proxy_ticket(computer_id, remote_port)
    ws_url = _resolve_ws_url(base_url, ticket_payload.get("ws_url"))
    if not ws_url:
        raise RuntimeAPIError("proxy endpoint did not return a websocket url")
    with websocket_connect(ws_url, open_timeout=DEFAULT_WARMUP_TIMEOUT, close_timeout=1, max_size=None):
        return



def run_proxy_agent(base_url: str, api_key: str, computer_id: str, display_name: str, local_port: int, remote_port: int) -> int:
    if not api_key:
        print("proxy agent missing api key", file=sys.stderr)
        return 1

    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        listener.bind(("127.0.0.1", local_port))
        listener.listen()
        listener.settimeout(1.0)
    except OSError as exc:
        print(f"proxy listen failed on localhost:{local_port}: {exc}", file=sys.stderr)
        return 1

    try:
        _proxy_preflight(base_url, api_key, computer_id, remote_port)
    except Exception as exc:
        with contextlib.suppress(OSError):
            listener.close()
        print(f"proxy preflight failed for localhost:{local_port} -> {computer_id}:{remote_port}: {exc}", file=sys.stderr)
        return 1

    proxy_dir = _proxy_dir()
    proxy_dir.mkdir(parents=True, exist_ok=True)
    state = {
        "pid": os.getpid(),
        "computer_id": computer_id,
        "display_name": display_name,
        "local_port": local_port,
        "remote_port": remote_port,
        "started_at": datetime.now(timezone.utc).isoformat(),
    }
    _proxy_state_path(local_port).write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")

    stop_event = threading.Event()

    def handle_signal(_signum: int, _frame: Any) -> None:
        stop_event.set()
        with contextlib.suppress(OSError):
            listener.close()

    signal.signal(signal.SIGTERM, handle_signal)
    signal.signal(signal.SIGINT, handle_signal)

    try:
        while not stop_event.is_set():
            try:
                conn, _ = listener.accept()
            except socket.timeout:
                continue
            except OSError:
                if stop_event.is_set():
                    break
                continue
            thread = threading.Thread(
                target=_handle_proxy_client,
                args=(base_url, api_key, computer_id, remote_port, conn),
                daemon=True,
            )
            thread.start()
    finally:
        with contextlib.suppress(OSError):
            listener.close()
        _remove_proxy_state(local_port)
    return 0


def _handle_proxy_client(base_url: str, api_key: str, computer_id: str, remote_port: int, conn: socket.socket) -> None:
    client = RuntimeClient(base_url=base_url, api_key=api_key)
    try:
        ticket_payload = client.create_proxy_ticket(computer_id, remote_port)
        ws_url = _resolve_ws_url(base_url, ticket_payload.get("ws_url"))
        if not ws_url:
            raise RuntimeAPIError("proxy endpoint did not return a websocket url")
        with websocket_connect(ws_url, open_timeout=DEFAULT_WARMUP_TIMEOUT, close_timeout=1, max_size=None) as ws:
            stop = threading.Event()

            def local_to_ws() -> None:
                try:
                    while not stop.is_set():
                        data = conn.recv(65536)
                        if not data:
                            break
                        ws.send(data)
                except Exception:
                    pass
                finally:
                    stop.set()
                    with contextlib.suppress(Exception):
                        ws.close()

            def ws_to_local() -> None:
                try:
                    while not stop.is_set():
                        data = ws.recv()
                        if data is None:
                            break
                        if isinstance(data, str):
                            chunk = data.encode()
                        else:
                            chunk = data
                        if chunk:
                            conn.sendall(chunk)
                except Exception:
                    pass
                finally:
                    stop.set()
                    with contextlib.suppress(OSError):
                        conn.shutdown(socket.SHUT_RDWR)

            t1 = threading.Thread(target=local_to_ws, daemon=True)
            t2 = threading.Thread(target=ws_to_local, daemon=True)
            t1.start()
            t2.start()
            t1.join()
            t2.join()
    except Exception as exc:
        print(f"proxy connection failed for localhost:{conn.getsockname()[1]} -> {computer_id}:{remote_port}: {exc}", file=sys.stderr)
    finally:
        with contextlib.suppress(OSError):
            conn.close()


def _enter_computer(config: RuntimeConfig, computer_id: str) -> int:
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    ticket_payload = _with_spinner(
        f"preparing console for {computer_id}…",
        lambda: client.create_terminal_ticket(computer_id),
    )
    ws_url = _resolve_ws_url(config.base_url, ticket_payload.get("ws_url"))
    if not ws_url:
        return report_error("terminal endpoint did not return a websocket url")

    _UI.console().print("[cyan]●[/cyan] Connecting to console...")

    try:
        return _run_terminal_session(ws_url)
    except RuntimeAPIError as exc:
        return report_error(str(exc), status_code=exc.status_code)
    except (InvalidHandshake, TimeoutError, OSError) as exc:
        return report_error(f"terminal failed: {exc}")


def _load_posix_tty_modules() -> tuple[Any, Any]:
    try:
        termios_mod = importlib.import_module("termios")
        tty_mod = importlib.import_module("tty")
    except ModuleNotFoundError as exc:
        raise RuntimeAPIError(
            "interactive console is not supported on this platform yet; use `runtime run` for one-shot commands"
        ) from exc
    return termios_mod, tty_mod



def _run_terminal_session(ws_url: str) -> int:
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return report_error("enter requires an interactive terminal")

    termios_mod, tty_mod = _load_posix_tty_modules()
    fd = sys.stdin.fileno()
    old_settings = termios_mod.tcgetattr(fd)
    stop = threading.Event()
    result: dict[str, Any] = {"code": 0, "error": None}
    output_state: dict[str, Any] = {"buffer": "", "suppressing_preamble": True}

    with websocket_connect(ws_url, open_timeout=DEFAULT_WARMUP_TIMEOUT, close_timeout=1) as ws:
        _send_terminal_resize(ws)

        def recv_loop() -> None:
            try:
                while not stop.is_set():
                    raw = ws.recv()
                    if raw is None:
                        result["code"] = 0
                        stop.set()
                        return
                    event = json.loads(raw)
                    event_type = str(event.get("type") or "")
                    if event_type == "ready":
                        continue
                    if event_type == "output":
                        data = _filter_terminal_output(str(event.get("data") or ""), output_state)
                        if data:
                            sys.stdout.write(data)
                            sys.stdout.flush()
                        continue
                    if event_type == "exit":
                        result["code"] = int(event.get("code") or 0)
                        message = str(event.get("message") or "").strip()
                        if message:
                            result["error"] = message
                        stop.set()
                        return
                    if event_type == "error":
                        result["code"] = 1
                        result["error"] = str(event.get("message") or "terminal error")
                        stop.set()
                        return
            except ConnectionClosed:
                if not stop.is_set() and not result.get("error") and int(result.get("code") or 0) == 0:
                    result["code"] = 1
                    result["error"] = "terminal connection closed unexpectedly"
                stop.set()
            except Exception as exc:  # pragma: no cover - defensive for real TTY sessions
                result["code"] = 1
                result["error"] = str(exc)
                stop.set()

        recv_thread = threading.Thread(target=recv_loop, daemon=True)
        recv_thread.start()

        last_size = shutil.get_terminal_size((100, 24))
        try:
            tty_mod.setraw(fd)
            while not stop.is_set():
                current_size = shutil.get_terminal_size((100, 24))
                if current_size != last_size:
                    _send_terminal_resize(ws)
                    last_size = current_size

                readable, _, _ = select.select([fd], [], [], 0.1)
                if fd not in readable:
                    continue
                data = os.read(fd, 1024)
                if not data:
                    stop.set()
                    break
                ws.send(json.dumps({"type": "input", "data": data.decode("utf-8", errors="ignore")}))
        finally:
            stop.set()
            with contextlib.suppress(Exception):
                ws.close()
            termios_mod.tcsetattr(fd, termios_mod.TCSADRAIN, old_settings)
            recv_thread.join(timeout=1)

    sys.stdout.write("\n")
    sys.stdout.flush()
    tail = _flush_terminal_output(output_state)
    if tail:
        sys.stdout.write(tail)
        sys.stdout.flush()
    if result.get("error"):
        _UI.err().print(f"[bold red]✗[/bold red] {result['error']}")
    return int(result.get("code") or 0)


def _filter_terminal_output(chunk: str, state: dict[str, Any]) -> str:
    if not chunk:
        return ""
    if not state.get("suppressing_preamble", False):
        return _strip_terminal_noise(chunk)

    buffer = str(state.get("buffer") or "") + chunk
    marker = "\x1b[1;34mruntime@"
    idx = buffer.find(marker)
    if idx != -1:
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return _strip_terminal_noise(buffer[idx:])

    cleaned = _strip_terminal_noise(buffer)
    if cleaned and _should_release_terminal_output(cleaned):
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return cleaned

    if len(buffer) > 8192:
        state["suppressing_preamble"] = False
        state["buffer"] = ""
        return _strip_terminal_noise(buffer)

    state["buffer"] = buffer
    return ""



def _should_release_terminal_output(text: str) -> bool:
    if not text:
        return False
    if "\n" in text or "\r" in text:
        return True
    if len(text) >= 256:
        return True

    stripped = text.rstrip()
    return text.endswith(("$ ", "# ", "% ", "> ")) or stripped.endswith(("$", "#", "%", ">"))



def _flush_terminal_output(state: dict[str, Any]) -> str:
    buffer = str(state.get("buffer") or "")
    state["buffer"] = ""
    return _strip_terminal_noise(buffer)


def _strip_terminal_noise(text: str) -> str:
    if not text:
        return ""

    lines = text.splitlines(keepends=True)
    filtered: list[str] = []
    for line in lines:
        stripped = line.rstrip("\r\n")
        if stripped.startswith("Running bootstrap command: export PS1='\\[\\033[1;34m\\]runtime@"):
            continue
        if stripped == "Connected! Press Ctrl+] to exit.":
            continue
        if stripped == "* Image built by SlicerVM (2026)":
            continue
        if stripped == "* Website: https://slicervm.com":
            continue
        if stripped == "* Docs: https://docs.slicervm.com":
            continue
        filtered.append(line)
    return "".join(filtered)


def _send_terminal_resize(ws: Any) -> None:
    size = shutil.get_terminal_size((100, 24))
    ws.send(json.dumps({"type": "resize", "cols": size.columns, "rows": size.lines}))


# --------------------------------------------------------------------------- #
# Interactive list → detail → action loop                                    #
# --------------------------------------------------------------------------- #


def _interactive_list(config: RuntimeConfig) -> int:
    """Nested menu: table → pick VM → action → back."""
    client = RuntimeClient(base_url=config.base_url, api_key=config.api_key)
    questionary = _UI.q()

    while True:
        payload = _with_spinner("fetching computers…", client.list_computers)
        computers = payload.get("computers") or []
        if not isinstance(computers, list):
            computers = []

        if not computers:
            _UI.console().print("[dim]no computers yet. create one with `runtime create`.[/dim]")
            return 0

        computers = sorted(computers, key=_computer_sort_key)
        _render_computer_summary(computers)
        widths = _computer_table_layout(computers)
        _render_computer_table(computers, title="computers")
        choices = [
            questionary.Choice(title=_computer_choice_title(c, widths), value=c)
            for c in computers
        ]
        choices.append(questionary.Separator())
        choices.append(questionary.Choice(title="↻ refresh", value="__refresh__"))
        choices.append(questionary.Choice(title="✕ quit", value="__quit__"))

        picked = _select_prompt("Pick a computer", choices).unsafe_ask()

        if picked == "__quit__":
            return 0
        if picked == "__refresh__":
            continue
        if not isinstance(picked, dict):
            continue

        action = _vm_detail_menu(client, picked)
        if action == "__quit__":
            return 0
        # otherwise: loop and refresh the list


def _vm_detail_menu(client: RuntimeClient, vm: dict[str, Any]) -> str:
    """Action menu for a single VM. Returns '__back__' or '__quit__'."""
    questionary = _UI.q()
    vm_id = vm.get("id") or vm.get("slug") or "?"
    slug = vm.get("slug") or vm_id

    while True:
        _render_computer_panel(vm, title=f"computer: {slug}")

        power_state = _computer_power_state(vm)
        internal_status = _computer_internal_status(vm)
        choices = []
        if internal_status in ("running", "cold"):
            choices.append(questionary.Choice(title="⌨ enter console", value="enter"))
        if internal_status == "running":
            choices.append(questionary.Choice(title="▶ run a command", value="run"))
            choices.append(questionary.Choice(title="⤴ publish a port", value="publish"))
        if power_state == "cold":
            choices.append(questionary.Choice(title="☀ start / wake", value="start"))
        choices.extend(
            [
                questionary.Choice(title="ℹ refresh info", value="info"),
                questionary.Choice(title="⧉ copy public url", value="url"),
                questionary.Choice(title="✕ delete", value="delete"),
                questionary.Separator(),
                questionary.Choice(title="← back", value="__back__"),
                questionary.Choice(title="✕ quit", value="__quit__"),
            ]
        )

        action = _select_prompt(
            f"What would you like to do with {slug}?",
            choices,
        ).unsafe_ask()

        if action == "__back__":
            return "__back__"
        if action == "__quit__":
            return "__quit__"

        if action == "enter":
            _enter_computer(RuntimeConfig(base_url=client.base_url, api_key=client.api_key), str(vm_id))
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "run":
            command = _prompt_text("Command to run")
            if not command:
                continue
            result = _with_spinner(
                f"running on {slug}…", lambda: client.run_command(vm_id, command)
            )
            _render_run_result(result)
            continue

        if action == "start":
            vm = _with_spinner(f"warming {slug}…", lambda: client.start_computer(vm_id))
            continue

        if action == "publish":
            port_text = _prompt_text("Port to publish", default="3000")
            if not port_text:
                continue
            try:
                port = int(port_text)
            except ValueError:
                _UI.err().print("[red]port must be a number[/red]")
                continue
            if port <= 0 or port > 65535:
                _UI.err().print("[red]port must be between 1 and 65535[/red]")
                continue
            _with_spinner(
                f"publishing port {port} on {slug}…",
                lambda: client.publish_port(vm_id, port),
            )
            _UI.console().print(
                f"[green]✓[/green] public url for [bold]{slug}[/bold] pinned to [bold]{port}[/bold]"
            )
            continue

        if action == "info":
            vm = _with_spinner("fetching…", lambda: client.get_computer(vm_id))
            continue

        if action == "url":
            url = vm.get("public_url") or ""
            if not url:
                _UI.console().print("[yellow]no public url on this computer[/yellow]")
                continue
            _UI.console().print(f"[cyan]{url}[/cyan]")
            continue

        if action == "delete":
            if not _prompt_confirm(
                f"Delete {slug}? This cannot be undone.", default=False
            ):
                _UI.console().print("[dim]cancelled[/dim]")
                continue
            _with_spinner(f"deleting {slug}…", lambda: client.delete_computer(vm_id))
            _UI.console().print(f"[green]✓[/green] deleted [bold]{slug}[/bold]")
            return "__back__"


if __name__ == "__main__":
    raise SystemExit(main())
