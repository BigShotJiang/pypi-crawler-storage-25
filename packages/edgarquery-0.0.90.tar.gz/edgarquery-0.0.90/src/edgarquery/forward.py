#
# look into 
# edgartools
# https://github.com/dgunning/edgartools
# https://edgartools.readthedocs.io/en/latest/concepts/data-objects/
import os
import sys
import urllib.request

import lxml
from lxml import etree

amzurl = 'https://www.sec.gov/Archives/edgar/data/1018724/000101872426000004/amzn-20251231.htm'
hdr = {"User-Agent": os.environ["EQEMAIL"]}

req = urllib.request.Request(amzurl, headers=hdr)
resp = urllib.request.urlopen(req)
ht = resp.read()
hs = ht.decode('utf-8')
hf = '/tmp/10k.html'
with open(hf, 'w') as fp:
    fp.write(hs)

root = etree.fromstring(ht)
pp = etree.tostring(root, pretty_print=True).decode('utf-8')
with open(hf, 'w') as fp:
    fp.write(pp)

tree = etree.ElementTree(root)
troot = tree.getroot()
pp = etree.tostring(troot, pretty_print=True).decode('utf-8')

ptree = etree.parse(hf)
proot = ptree.getroot()
pp = etree.tostring(proot, pretty_print=True).decode('utf-8')

#print(dir(root) )
#print(root.tag)

terms = [
        'forward-looking statements',
        'Risk Factors',
        'Risks'
        ]
fws = 'Forward-Looking Statements'
mdf = 'Discussion and Analysis of Financial Condition'
infls = False
for element in root.iter():
    if isinstance(element.tag, str):
        if element.text == None:
            continue
        #print(f"{element.tag} - {element.text}")
        txt = element.text
        if element.tag.endswith('span') and txt == fws:
            infls = True
        if element.tag.endswith('span') and mdf in txt:
            infls = False
        if infls == True:
            for t in terms:
                if t in txt:
                    print(element.tag)
                    print(txt)
    else:
        # print(f"SPECIAL: {element} - {element.text}")
        pass

#print(dir(tree) )

# parser = etree.XMLParser()
# parser.feed(ht)
# root = parser.close()
#print(dir(root) )
#print(root.tag)

#print(type(ht))
