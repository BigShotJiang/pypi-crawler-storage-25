"""FastAPI/SSE backend server for the TypeScript TUI."""

from __future__ import annotations

import asyncio
import json
import threading
from typing import Any, AsyncIterator, Dict, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .agent import Agent, AgentMode
from .config import Config
from .core import AICode

app = FastAPI(title="codrninja-server", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_ai: Optional[AICode] = None


def get_ai() -> AICode:
    global _ai
    if _ai is None:
        _ai = AICode()
    return _ai


# ── request models ────────────────────────────────────────────────────────────

class SendRequest(BaseModel):
    message: str
    model: Optional[str] = None
    max_steps: int = 50
    auto_approve: bool = True
    mode: str = "build"


class CreateSessionRequest(BaseModel):
    name: str


class ExecRequest(BaseModel):
    command: str


class SearchRequest(BaseModel):
    query: str


class FetchRequest(BaseModel):
    url: str


class CommitRequest(BaseModel):
    message: str


class TestRequest(BaseModel):
    command: str = "pytest -q"


class SetModelRequest(BaseModel):
    model: str
    provider: Optional[str] = None
    set_as_default: bool = False


class SetProviderRequest(BaseModel):
    provider: str


class ApiKeyRequest(BaseModel):
    api_key: str


class OllamaConfigRequest(BaseModel):
    url: str


# ── routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/config")
def get_config():
    cfg = get_ai().config
    return {
        "provider": cfg.default_provider,
        "model": cfg.default_model,
        "ollama_url": cfg.ollama_url,
        "reasoning_level": cfg.reasoning_level,
        "permissions_mode": cfg.permissions_mode,
    }


@app.get("/sessions")
def list_sessions():
    return {"sessions": get_ai().list_sessions()}


@app.post("/sessions")
def create_session(req: CreateSessionRequest):
    session = get_ai().create_session(req.name)
    return {"id": session.id, "name": session.name, "created_at": session.created_at}


@app.get("/sessions/{name}")
def get_session(name: str):
    ai = get_ai()
    history = ai.get_history(name)
    if not history:
        raise HTTPException(status_code=404, detail=f"Session '{name}' not found")
    return history


@app.post("/sessions/{name}/model")
def set_session_model(name: str, req: SetModelRequest):
    """Set the model for a specific session. Optionally set as global default."""
    ai = get_ai()
    # Always persist the provider alongside the model so _call_ai_stream can match them
    effective_provider = req.provider or ai.config.default_provider
    ai.session_manager.update_state(name, model=req.model, provider=effective_provider)
    if req.set_as_default:
        ai.config.default_model = req.model
        if req.provider:
            ai.config.default_provider = req.provider
        try:
            ai.config.save()
        except Exception:
            pass
        ai.refresh_provider()
    return {"model": req.model, "provider": req.provider, "set_as_default": req.set_as_default}


@app.delete("/sessions/{name}")
def delete_session(name: str):
    ai = get_ai()
    try:
        ai.session_manager.delete(name)
        return {"deleted": name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/sessions/{name}/stream")
async def stream_agent(name: str, req: SendRequest) -> StreamingResponse:
    """Stream agent execution as Server-Sent Events."""
    ai = get_ai()
    ai.create_session(name)

    mode = AgentMode.PLAN if req.mode == "plan" else AgentMode.BUILD

    async def event_generator() -> AsyncIterator[str]:
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue[Optional[Dict[str, Any]]] = asyncio.Queue()

        def run_agent():
            agent = Agent(ai, name, max_iterations=req.max_steps, mode=mode)
            try:
                for event in agent.stream_run(req.message, auto_approve=req.auto_approve):
                    loop.call_soon_threadsafe(queue.put_nowait, event)
            except Exception as exc:
                loop.call_soon_threadsafe(
                    queue.put_nowait,
                    {"type": "result", "result": {"success": False, "error": str(exc)}},
                )
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        thread = threading.Thread(target=run_agent, daemon=True)
        thread.start()

        while True:
            event = await queue.get()
            if event is None:
                yield "event: done\ndata: {}\n\n"
                break
            yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/models")
def list_models():
    ai = get_ai()
    try:
        models = ai.provider_manager.list_models()
    except Exception:
        models = []
    return {
        "models": models,
        "current_model": ai.config.default_model,
        "current_provider": ai.config.default_provider,
    }


@app.post("/config/model")
def set_model(req: SetModelRequest):
    ai = get_ai()
    ai.config.default_model = req.model
    if req.provider:
        ai.config.default_provider = req.provider
    ai.refresh_provider()
    try:
        ai.config.save()
    except Exception:
        pass
    return {"model": ai.config.default_model, "provider": ai.config.default_provider}


@app.get("/providers")
def list_providers():
    from .auth import TokenManager
    from .providers import ClaudeCliProvider
    ai = get_ai()
    tm = TokenManager()
    providers = ai.provider_manager.list_providers()
    result = []
    for name in providers:
        status = tm.list_status().get(name, {})
        if name == "claude-cli":
            ready = bool(ClaudeCliProvider.find_binary() and ClaudeCliProvider.is_authenticated())
            result.append({
                "name": name,
                "active": ai.config.default_provider == name,
                "authenticated": ready,
                "oauth": ready,
                "expired": False,
            })
            continue
        has_key = bool(
            getattr(ai.config, f"{name}_api_key", "")
            or (name == "ollama")
        )
        result.append({
            "name": name,
            "active": ai.config.default_provider == name,
            "authenticated": bool(status.get("authenticated") or has_key),
            "oauth": bool(status.get("authenticated")),
            "expired": bool(status.get("expired")),
        })
    return {"providers": result, "current": ai.config.default_provider}


_PROVIDER_DEFAULT_MODELS = {
    "openai": "gpt-4o",
    "anthropic": "claude-sonnet-4-6",
    "openrouter": "anthropic/claude-3.5-sonnet",
    "claude-cli": "claude-sonnet-4-6",
}


@app.post("/config/provider")
def set_active_provider(req: SetProviderRequest):
    ai = get_ai()
    ai.config.default_provider = req.provider
    if req.provider in _PROVIDER_DEFAULT_MODELS:
        ai.config.default_model = _PROVIDER_DEFAULT_MODELS[req.provider]
        _save_config_field("model", ai.config.default_model)
    ai.refresh_provider()
    try:
        ai.config.save()
    except Exception:
        pass
    return {"provider": ai.config.default_provider}


@app.post("/providers/{name}/apikey")
def set_api_key(name: str, req: ApiKeyRequest):
    ai = get_ai()
    key = req.api_key.strip()
    if name == "openai":
        ai.config.openai_api_key = key
    elif name == "anthropic":
        ai.config.anthropic_api_key = key
    elif name == "openrouter":
        ai.config.openrouter_api_key = key
    else:
        raise HTTPException(status_code=400, detail=f"API key not applicable for {name}")
    # persist
    import os, json as _json
    cfg_path = os.path.expanduser("~/.config/codrninja/config.json")
    try:
        cfg: dict = {}
        if os.path.exists(cfg_path):
            with open(cfg_path) as f:
                cfg = _json.load(f)
        cfg.setdefault("api_keys", {})[name] = key
        os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
        with open(cfg_path, "w") as f:
            _json.dump(cfg, f, indent=2)
    except Exception:
        pass
    ai.refresh_provider()
    return {"success": True, "provider": name}


def _extract_account_id(access_token: str) -> Optional[str]:
    """Extract account/sub ID from a JWT access token payload."""
    import base64 as _b64, json as _json
    try:
        parts = access_token.split(".")
        if len(parts) >= 2:
            padded = parts[1] + "=" * (4 - len(parts[1]) % 4)
            payload = _json.loads(_b64.urlsafe_b64decode(padded))
            return payload.get("sub") or payload.get("account_id") or payload.get("accountId")
    except Exception:
        pass
    return None


def _save_config_field(key: str, value):
    import os, json as _json
    cfg_path = os.path.expanduser("~/.config/codrninja/config.json")
    try:
        cfg: dict = {}
        if os.path.exists(cfg_path):
            with open(cfg_path) as f:
                cfg = _json.load(f)
        cfg[key] = value
        os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
        with open(cfg_path, "w") as f:
            _json.dump(cfg, f, indent=2)
    except Exception:
        pass


@app.post("/providers/ollama/configure")
def configure_ollama(req: OllamaConfigRequest):
    import requests as _req
    url = req.url.rstrip("/")
    if not url.startswith("http"):
        url = "http://" + url
    try:
        r = _req.get(f"{url}/api/tags", timeout=5)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Cannot reach Ollama at {url}: {e}")
    ai = get_ai()
    # Set as the primary Ollama URL
    ai.config.ollama_url = url
    # Also add to known servers list if not already there
    if url not in ai.config.ollama_urls:
        ai.config.ollama_urls = [*ai.config.ollama_urls, url]
    if url not in ai.config.ollama_active_urls:
        ai.config.ollama_active_urls = [*ai.config.ollama_active_urls, url]
    _save_config_field("ollama_url", url)
    _save_config_field("ollama_urls", ai.config.ollama_urls)
    _save_config_field("ollama_active_urls", ai.config.ollama_active_urls)
    ai.refresh_provider()
    return {"success": True, "url": url, "models": models}


@app.get("/providers/ollama/servers")
def get_ollama_servers():
    """List all known Ollama servers with online status and models."""
    import requests as _req
    ai = get_ai()
    all_urls = ai.config.get_ollama_urls()
    active_urls = ai.config.get_ollama_active_urls()
    servers = []
    for url in all_urls:
        if not url.startswith("http"):
            url = "http://" + url
        is_active = url in active_urls
        try:
            r = _req.get(f"{url}/api/tags", timeout=3)
            models = [m["name"] for m in r.json().get("models", [])] if r.ok else []
            online = r.ok
        except Exception:
            models, online = [], False
        servers.append({"url": url, "active": is_active, "online": online, "models": models})
    return {"servers": servers, "primary": ai.config.ollama_url}


@app.post("/providers/ollama/add-server")
def add_ollama_server(req: OllamaConfigRequest):
    """Add a new Ollama server and optionally make it active."""
    import requests as _req
    url = req.url.rstrip("/")
    if not url.startswith("http"):
        url = "http://" + url
    try:
        r = _req.get(f"{url}/api/tags", timeout=5)
        r.raise_for_status()
        models = [m["name"] for m in r.json().get("models", [])]
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Cannot reach Ollama at {url}: {e}")
    ai = get_ai()
    if url not in ai.config.ollama_urls:
        ai.config.ollama_urls = [*ai.config.ollama_urls, url]
    if not ai.config.ollama_urls:
        ai.config.ollama_urls = [url]
    if url not in ai.config.ollama_active_urls:
        ai.config.ollama_active_urls = [*ai.config.ollama_active_urls, url]
    _save_config_field("ollama_urls", ai.config.ollama_urls)
    _save_config_field("ollama_active_urls", ai.config.ollama_active_urls)
    ai.refresh_provider()
    return {"success": True, "url": url, "models": models}


@app.post("/providers/ollama/remove-server")
def remove_ollama_server(req: OllamaConfigRequest):
    """Remove a known Ollama server."""
    ai = get_ai()
    url = req.url.rstrip("/")
    if not url.startswith("http"):
        url = "http://" + url
    ai.config.ollama_urls = [u for u in ai.config.ollama_urls if u != url]
    ai.config.ollama_active_urls = [u for u in ai.config.ollama_active_urls if u != url]
    if ai.config.ollama_url == url:
        ai.config.ollama_url = ai.config.ollama_urls[0] if ai.config.ollama_urls else "http://localhost:11434"
    _save_config_field("ollama_urls", ai.config.ollama_urls)
    _save_config_field("ollama_active_urls", ai.config.ollama_active_urls)
    _save_config_field("ollama_url", ai.config.ollama_url)
    ai.refresh_provider()
    return {"success": True}


@app.post("/providers/ollama/toggle-server")
def toggle_ollama_server(req: OllamaConfigRequest):
    """Toggle whether a server's models appear in the combined model list."""
    ai = get_ai()
    url = req.url.rstrip("/")
    if not url.startswith("http"):
        url = "http://" + url
    active = list(ai.config.get_ollama_active_urls())
    if url in active:
        active.remove(url)
    else:
        active.append(url)
    ai.config.ollama_active_urls = active
    _save_config_field("ollama_active_urls", active)
    ai.refresh_provider()
    return {"success": True, "active": active}


@app.post("/providers/openai/oauth")
async def run_openai_oauth() -> StreamingResponse:
    """Browser PKCE OAuth flow for OpenAI."""
    async def generator() -> AsyncIterator[str]:
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue[Optional[Dict[str, Any]]] = asyncio.Queue()

        def run_flow():
            from .auth import OAuthCallbackServer, PKCEHandler, TokenManager
            from .oauth_providers import OpenAIOAuth
            import webbrowser
            provider = OpenAIOAuth()
            cb = OAuthCallbackServer(
                host=OpenAIOAuth.CALLBACK_HOST,
                port=OpenAIOAuth.CALLBACK_PORT,
                callback_path=OpenAIOAuth.CALLBACK_PATH,
            )
            callback_url = cb.start()
            verifier = PKCEHandler.generate_verifier()
            challenge = PKCEHandler.generate_challenge(verifier)
            state = PKCEHandler.generate_state()
            auth_url = provider.build_authorization_url(callback_url, challenge, state)
            loop.call_soon_threadsafe(queue.put_nowait, {"type": "url", "url": auth_url})
            try:
                webbrowser.open(auth_url)
            except Exception:
                pass
            loop.call_soon_threadsafe(queue.put_nowait, {"type": "waiting"})
            result = cb.wait_for_callback()
            cb.shutdown()
            if result.error:
                loop.call_soon_threadsafe(queue.put_nowait, {"type": "error", "error": result.error_description or result.error})
            elif not result.code or result.state != state:
                loop.call_soon_threadsafe(queue.put_nowait, {"type": "error", "error": "Invalid OAuth response"})
            else:
                try:
                    tokens = provider.exchange_code(result.code, verifier, callback_url)
                    if not tokens.get("account_id"):
                        tokens["account_id"] = _extract_account_id(tokens.get("access_token", "")) or ""
                    from .auth import TokenManager
                    TokenManager().store_tokens("openai", tokens)
                    get_ai().refresh_provider()
                    loop.call_soon_threadsafe(queue.put_nowait, {"type": "success"})
                except Exception as exc:
                    loop.call_soon_threadsafe(queue.put_nowait, {"type": "error", "error": str(exc)})
            loop.call_soon_threadsafe(queue.put_nowait, None)

        threading.Thread(target=run_flow, daemon=True).start()
        while True:
            event = await queue.get()
            if event is None:
                yield "event: done\ndata: {}\n\n"
                break
            yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(generator(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/providers/openai/credentials")
def load_openai_credentials():
    """Load Codex CLI OAuth credentials (Keychain or auth file)."""
    from .openai_codex import load_codex_auth, refresh_codex_token
    auth = load_codex_auth()
    if not auth:
        return {"success": False, "error": "~/.codex/auth.json not found. Log in with the Codex CLI first (codex login)."}
    # store token so provider can pick it up
    if not auth.get("plain_key"):
        from .auth import TokenManager
        import time

        # Try to get a fresh token via refresh if we have a refresh_token
        rt = auth.get("refresh_token")
        access = auth["access"]
        expires_at = time.time() + 3600  # default 1h
        if rt:
            refreshed = refresh_codex_token(rt)
            if refreshed:
                access = refreshed["access"]
                rt = refreshed.get("refresh_token", rt)
                expires_at = refreshed.get("expires_at", expires_at)

        account_id = auth.get("accountId") or _extract_account_id(access) or ""
        token_data: dict = {
            "access_token": access,
            "account_id": account_id,
            "expires_at": expires_at,
            "token_type": "Bearer",
            "metadata": {"source": "codex_cli", "provider": "openai"},
        }
        if rt:
            token_data["refresh_token"] = rt
        TokenManager().store_tokens("openai", token_data)
    else:
        import os, json as _json
        cfg_path = os.path.expanduser("~/.config/codrninja/config.json")
        try:
            cfg: dict = {}
            if os.path.exists(cfg_path):
                with open(cfg_path) as f:
                    cfg = _json.load(f)
            cfg.setdefault("api_keys", {})["openai"] = auth["access"]
            os.makedirs(os.path.dirname(cfg_path), exist_ok=True)
            with open(cfg_path, "w") as f:
                _json.dump(cfg, f, indent=2)
        except Exception:
            pass
        get_ai().config.openai_api_key = auth["access"]
    get_ai().refresh_provider()
    return {"success": True}


@app.post("/providers/anthropic/credentials")
def load_anthropic_credentials():
    """Load Claude Code OAuth credentials (Keychain or credentials file)."""
    from .openai_codex import load_claude_code_token
    import time
    token = load_claude_code_token()
    if not token:
        return {
            "success": False,
            "error": "No Claude Code credentials found. Log in with Claude Code first.",
        }
    try:
        from .auth import TokenManager
        TokenManager().store_tokens("anthropic", {
            "access_token": token,
            "expires_at": time.time() + 86400,
            "scope": "openid profile email offline_access",
            "token_type": "Bearer",
            "metadata": {"source": "claude_code", "provider": "anthropic"},
        })
        get_ai().refresh_provider()
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.post("/run/exec")
def run_exec(req: ExecRequest):
    result = get_ai().tools.execute_command(req.command)
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/search")
def run_search(req: SearchRequest):
    result = get_ai().tools.web_search(req.query)
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/fetch")
def run_fetch(req: FetchRequest):
    result = get_ai().tools.web_fetch(req.url)
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/commit")
def run_commit(req: CommitRequest):
    import shlex
    get_ai().tools.execute_command("git add -A")
    result = get_ai().tools.execute_command(f"git commit -m {shlex.quote(req.message)}")
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/test")
def run_test(req: TestRequest):
    result = get_ai().tools.execute_command(req.command)
    return {"success": result.success, "output": result.output, "error": result.error}


@app.get("/version")
def get_version():
    try:
        import importlib.metadata
        version = importlib.metadata.version("codrninja")
    except Exception:
        version = "unknown"
    return {"version": version}


@app.post("/providers/{provider}/oauth/browser")
def open_oauth_browser(provider: str):
    """Open the browser to the provider's OAuth/API key page."""
    import subprocess, sys
    urls = {
        "openai":      "https://platform.openai.com/api-keys",
        "anthropic":   "https://console.anthropic.com/settings/keys",
        "openrouter":  "https://openrouter.ai/keys",
    }
    url = urls.get(provider, "")
    if url:
        try:
            if sys.platform == "darwin":
                subprocess.Popen(["open", url])
            elif sys.platform.startswith("linux"):
                subprocess.Popen(["xdg-open", url])
            else:
                subprocess.Popen(["start", url], shell=True)
        except Exception:
            pass
    return {"success": bool(url), "url": url}


def run_server(host: str = "127.0.0.1", port: int = 7384):
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")
