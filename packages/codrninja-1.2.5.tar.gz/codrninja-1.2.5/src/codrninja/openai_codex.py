"""Read Codex CLI / ChatGPT OAuth credentials and call the Responses API."""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterator, Optional

import requests


def _read_keychain(service: str) -> Optional[str]:
    """Read a generic-password from the macOS Keychain. Non-macOS or missing → None."""
    if sys.platform != "darwin":
        return None
    try:
        r = subprocess.run(
            ["security", "find-generic-password", "-s", service, "-w"],
            capture_output=True, text=True, timeout=5,
        )
        return r.stdout.strip() if r.returncode == 0 and r.stdout.strip() else None
    except Exception:
        return None


def _parse_codex_data(data: dict) -> Optional[Dict[str, str]]:
    tokens = data.get("tokens") or {}
    access = tokens.get("access_token") or tokens.get("accessToken")
    account_id = tokens.get("account_id") or tokens.get("accountId") or ""
    if access:
        return {"access": access, "accountId": account_id}
    key = data.get("OPENAI_API_KEY") or data.get("openai_api_key")
    if key:
        return {"access": key, "accountId": "", "plain_key": True}
    return None


def load_codex_auth() -> Optional[Dict[str, str]]:
    """Return {'access': str, 'accountId': str} or None if not available.

    Checks macOS Keychain first, then falls back to the Codex config file.
    """
    # 1. macOS Keychain (preferred — always up to date)
    raw = _read_keychain("Codex Auth")
    if raw:
        try:
            result = _parse_codex_data(json.loads(raw))
            if result:
                return result
        except Exception:
            pass

    # 2. Fallback: config file written by Codex CLI
    path = Path.home() / ".codex" / "auth.json"
    if path.exists():
        try:
            result = _parse_codex_data(json.loads(path.read_text()))
            if result:
                return result
        except Exception:
            pass

    return None


def load_claude_code_token() -> Optional[str]:
    """Return Claude Code OAuth access token or None.

    Checks macOS Keychain first, then the credentials file written by Claude Code.
    """
    # 1. macOS Keychain
    raw = _read_keychain("Claude Code-credentials")
    if raw:
        try:
            token = json.loads(raw).get("claudeAiOauth", {}).get("accessToken")
            if token:
                return token
        except Exception:
            pass

    # 2. Fallback: credentials file written by Claude Code
    creds_file = Path.home() / ".claude" / ".credentials.json"
    if creds_file.exists():
        try:
            data = json.loads(creds_file.read_text())
            token = (
                data.get("claudeAiOauth", {}).get("accessToken")
                or data.get("access_token")
            )
            if token:
                return token
        except Exception:
            pass

    return None


_RESPONSES_URL = "https://api.openai.com/v1/responses"
_CODEX_CLIENT_ID = "app_EMoamEEZ73f0CkXaXp7hrann"
_TOKEN_REFRESH_URL = "https://auth.openai.com/oauth/token"


def refresh_codex_token(refresh_token: str) -> Optional[Dict[str, str]]:
    """Refresh a Codex/ChatGPT OAuth token. Returns updated auth dict or None."""
    try:
        r = requests.post(
            _TOKEN_REFRESH_URL,
            data={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": _CODEX_CLIENT_ID,
            },
            timeout=30,
        )
        if r.ok:
            data = r.json()
            new_access = data.get("access_token")
            new_refresh = data.get("refresh_token", refresh_token)
            # Extract account_id from id_token if present, fallback to top-level field
            import base64 as _b64
            id_token = data.get("id_token", "")
            account_id = ""
            if id_token:
                try:
                    parts = id_token.split(".")
                    if len(parts) >= 2:
                        import json as _json
                        padded = parts[1] + "=" * (4 - len(parts[1]) % 4)
                        payload = _json.loads(_b64.urlsafe_b64decode(padded))
                        account_id = payload.get("account_id") or payload.get("sub") or ""
                except Exception:
                    pass
            if not account_id:
                account_id = data.get("account_id") or data.get("accountId") or ""
            expires_in = data.get("expires_in", 3600)
            if new_access:
                return {
                    "access": new_access,
                    "accountId": account_id,
                    "refresh_token": new_refresh,
                    "expires_at": time.time() + expires_in,
                }
    except Exception:
        pass
    return None


def _codex_headers(auth: Dict[str, str]) -> Dict[str, str]:
    h: Dict[str, str] = {
        "Authorization": f"Bearer {auth['access']}",
        "Content-Type": "application/json",
        "User-Agent": "opencode/0.0.0",
    }
    if not auth.get("plain_key"):
        h["Originator"] = "opencode"
        if auth.get("accountId"):
            h["ChatGPT-Account-Id"] = auth["accountId"]
    return h


def _build_input(messages: list) -> tuple[str, list]:
    """Split messages into (instructions/system, input_array)."""
    instructions = ""
    input_arr = []
    for m in messages:
        if m["role"] == "system":
            instructions = m["content"]
        else:
            input_arr.append({"role": m["role"], "content": m["content"]})
    return instructions, input_arr


def chat_stream_codex(
    messages: list,
    model: str,
    auth: Dict[str, str],
    temperature: float = 0.7,
    max_tokens: int = 4096,
) -> Iterator[Dict[str, Any]]:
    """Stream via Responses API. Yields same shape as OpenAIProvider.chat_stream()."""
    if auth.get("plain_key"):
        # fall back to Chat Completions with the plain key
        yield from _chat_stream_completions(messages, model, auth["access"], temperature, max_tokens)
        return

    # Auto-refresh if token is expired or about to expire
    expires_at = auth.get("expires_at")
    if expires_at and float(expires_at) <= time.time() + 60:
        rt = auth.get("refresh_token")
        if rt:
            refreshed = refresh_codex_token(rt)
            if refreshed:
                auth = {**auth, **refreshed}

    instructions, input_arr = _build_input(messages)
    payload: Dict[str, Any] = {
        "model": model,
        "input": input_arr,
        "stream": True,
    }
    if instructions:
        payload["instructions"] = instructions

    try:
        with requests.post(
            _RESPONSES_URL,
            headers=_codex_headers(auth),
            json=payload,
            stream=True,
            timeout=300,
        ) as r:
            r.raise_for_status()
            tokens_in = tokens_out = 0
            for raw in r.iter_lines():
                if not raw:
                    continue
                line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                if line.startswith("data: "):
                    payload_str = line[6:].strip()
                    if payload_str in ("[DONE]", ""):
                        yield {"delta": "", "model": model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                        return
                    try:
                        data = json.loads(payload_str)
                    except json.JSONDecodeError:
                        continue
                    event_type = data.get("type", "")
                    if event_type == "response.output_text.delta":
                        delta = data.get("delta", "")
                        if delta:
                            yield {"delta": delta, "model": model,
                                   "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
                    elif event_type == "response.completed":
                        usage = data.get("response", {}).get("usage", {})
                        tokens_in = usage.get("input_tokens", tokens_in)
                        tokens_out = usage.get("output_tokens", tokens_out)
                        yield {"delta": "", "model": model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                        return
                    elif event_type in ("error", "response.failed"):
                        msg = data.get("message") or data.get("error", {}).get("message", "Unknown error")
                        yield {"error": msg, "delta": "", "done": True}
                        return
    except Exception as e:
        yield {"error": str(e), "delta": "", "done": True}


def _chat_stream_completions(
    messages: list,
    model: str,
    api_key: str,
    temperature: float,
    max_tokens: int,
) -> Iterator[Dict[str, Any]]:
    """Fallback to Chat Completions API when only a plain API key is available."""
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    try:
        with requests.post(
            "https://api.openai.com/v1/chat/completions",
            headers=headers,
            json={"model": model, "messages": messages, "temperature": temperature,
                  "max_tokens": max_tokens, "stream": True},
            stream=True,
            timeout=300,
        ) as r:
            r.raise_for_status()
            tokens_in = tokens_out = 0
            for raw in r.iter_lines():
                if not raw:
                    continue
                line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                if not line.startswith("data: "):
                    continue
                payload = line[6:].strip()
                if payload == "[DONE]":
                    yield {"delta": "", "model": model,
                           "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                    return
                try:
                    data = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                usage = data.get("usage") or {}
                tokens_in = usage.get("prompt_tokens", tokens_in)
                tokens_out = usage.get("completion_tokens", tokens_out)
                delta = (data.get("choices") or [{}])[0].get("delta", {}).get("content") or ""
                if delta:
                    yield {"delta": delta, "model": model,
                           "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
    except Exception as e:
        yield {"error": str(e), "delta": "", "done": True}
