"""Shared terminal bridge for routing command output into the Textual PTY view."""

from __future__ import annotations

import threading
from typing import Callable, Optional

_TerminalSink = Callable[[str, bool], None]

_lock = threading.Lock()
_sink: Optional[_TerminalSink] = None


def register_terminal_sink(sink: Optional[_TerminalSink]) -> None:
    """Register a process-local sink for terminal transcript updates."""
    global _sink
    with _lock:
        _sink = sink


def emit_terminal_output(text: str, is_error: bool = False) -> None:
    """Emit command text to the active terminal sink if one is registered."""
    with _lock:
        sink = _sink
    if sink and text:
        sink(text, is_error)
