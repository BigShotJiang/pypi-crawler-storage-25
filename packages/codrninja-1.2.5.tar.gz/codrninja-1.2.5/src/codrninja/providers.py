"""Multi-provider support for codrninja."""

import json
import os
import shutil
import subprocess
from abc import ABC, abstractmethod
from typing import Dict, Iterator, List, Optional, Any

import requests
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

from .auth import OAuthFlow, TokenManager


# ── OpenAI Responses API helpers ──────────────────────────────────────────────

_RESPONSES_API_MODELS = frozenset({
    "gpt-5.5", "gpt-5.4", "gpt-5.4-mini", "gpt-5.3-codex",
    "gpt-5.3-codex-spark", "gpt-5.2", "gpt-5",
    "codex-mini-latest", "codex-davinci-002",
})

# VERIFIED WORKING — DO NOT CHANGE. /codex/ path required; /responses alone → 401.
CODEX_RESPONSES_ENDPOINT = "https://chatgpt.com/backend-api/codex/responses"

# Only these models are confirmed to work with the Codex OAuth endpoint
_CODEX_OAUTH_SUPPORTED = frozenset({"gpt-5.5"})


def _needs_responses_api(model: str) -> bool:
    return model in _RESPONSES_API_MODELS or model.startswith("gpt-5")


def _get_model_config(model: str) -> dict:
    if model.startswith("gpt-5"):
        return {"system_mode": "developer"}
    return {"system_mode": "system"}


def _convert_messages_to_responses_input(messages: list, model: str) -> tuple:
    """Convert chat messages to Responses API format. Returns (input_arr, instructions)."""
    mode = _get_model_config(model)["system_mode"]
    input_arr: list = []
    instructions = ""
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")
        if not isinstance(content, str):
            content = ""
        if role == "system":
            if mode == "developer":
                instructions = content
            else:
                input_arr.append({"role": "system", "content": content})
        elif role == "user":
            input_arr.append({"role": "user", "content": [{"type": "input_text", "text": content}]})
        elif role == "assistant":
            input_arr.append({"role": "assistant", "content": [{"type": "output_text", "text": content}]})
    return input_arr, instructions


class BaseProvider(ABC):

    def __init__(self, config: Dict[str, Any]):
        self.config = config

    @abstractmethod
    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        pass

    @abstractmethod
    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        """Yield dicts: {'delta': str, 'model': str, 'tokens_input': int, 'tokens_output': int, 'done': bool}"""
        pass

    @abstractmethod
    def list_models(self) -> List[str]:
        pass

    @abstractmethod
    def get_default_model(self) -> str:
        pass


# ── Ollama ────────────────────────────────────────────────────────────────────

class OllamaProvider(BaseProvider):

    # Separator used to encode the server URL inside a model name
    _URL_SEP = "@ollama@"

    @classmethod
    def encode_model(cls, model: str, url: str) -> str:
        """Encode server URL into model name for multi-server routing."""
        return f"{model}{cls._URL_SEP}{url}"

    @classmethod
    def decode_model(cls, model: str) -> tuple:
        """Return (bare_model_name, server_url_or_None)."""
        if cls._URL_SEP in model:
            bare, url = model.split(cls._URL_SEP, 1)
            return bare, url
        return model, None

    def _base_url(self, model: Optional[str] = None) -> str:
        # If model encodes a specific server URL, use that
        if model:
            _, server_url = self.decode_model(model)
            if server_url:
                url = server_url
            else:
                url = self.config.get("url", "http://localhost:11434")
        else:
            url = self.config.get("url", "http://localhost:11434")
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "http://" + url
        return url.rstrip("/")

    def _payload(self, messages, model, stream: bool) -> dict:
        bare_model, _ = self.decode_model(model or self.config.get("model", "codellama"))
        reasoning = self.config.get("reasoning_level", "medium")
        num_ctx_map = {"none": 4096, "low": 8192, "medium": 16384, "high": 32768}
        num_ctx = self.config.get("num_ctx") or num_ctx_map.get(reasoning, 16384)
        return {
            "model": bare_model,
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": self.config.get("temperature", 0.7),
                "num_predict": self.config.get("max_tokens", 16384),
                "num_ctx": num_ctx,
            },
        }

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        model = model or self.config.get("model", "codellama")
        try:
            r = requests.post(
                f"{self._base_url(model)}/api/chat",
                json=self._payload(messages, model, stream=False),
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            return {
                "content": data.get("message", {}).get("content", ""),
                "model": model,
                "tokens_input": data.get("prompt_eval_count", 0),
                "tokens_output": data.get("eval_count", 0),
                "done": True,
            }
        except requests.exceptions.ConnectionError:
            return {"error": f"Cannot connect to Ollama at {self._base_url(model)}", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        model = model or self.config.get("model", "codellama")
        try:
            with requests.post(
                f"{self._base_url(model)}/api/chat",
                json=self._payload(messages, model, stream=True),
                stream=True,
                timeout=300,
            ) as r:
                r.raise_for_status()
                tokens_in = tokens_out = 0
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    try:
                        data = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    delta = data.get("message", {}).get("content", "")
                    tokens_in = data.get("prompt_eval_count", tokens_in)
                    tokens_out = data.get("eval_count", tokens_out)
                    if delta:
                        yield {"delta": delta, "model": model, "tokens_input": tokens_in,
                               "tokens_output": tokens_out, "done": False}
                    if data.get("done"):
                        yield {"delta": "", "model": model, "tokens_input": tokens_in,
                               "tokens_output": tokens_out, "done": True}
                        return
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        active_urls = self.config.get("active_urls") or [self.config.get("url", "http://localhost:11434")]
        all_urls = self.config.get("all_urls") or active_urls
        all_models: List[str] = []
        multi = len(all_urls) > 1
        for url in active_urls:
            if not url.startswith("http"):
                url = "http://" + url
            url = url.rstrip("/")
            try:
                r = requests.get(f"{url}/api/tags", timeout=10)
                if r.ok:
                    names = [m["name"] for m in r.json().get("models", [])]
                    if multi:
                        # Encode the URL into the model name for routing, display shows server
                        short = url.replace("http://", "").replace("https://", "")
                        all_models.extend(f"{n} ({short})|{self.encode_model(n, url)}" for n in names)
                    else:
                        all_models.extend(names)
            except Exception:
                pass
        return all_models if all_models else ["codellama", "llama2", "mistral"]

    def get_default_model(self) -> str:
        return self.config.get("model", "codellama")


# ── OAuth-capable base ────────────────────────────────────────────────────────

class OAuthCapableProvider(BaseProvider):
    oauth_env_var: str = ""

    def _auth_headers(self) -> Dict[str, str]:
        access_token = self.config.get("access_token")
        if access_token:
            return {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        api_key = self.config.get("api_key") or os.environ.get(self.oauth_env_var)
        if not api_key:
            return {}
        return self._api_key_headers(api_key)

    @abstractmethod
    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        pass


# ── OpenAI ────────────────────────────────────────────────────────────────────

class OpenAIProvider(OAuthCapableProvider):
    oauth_env_var = "OPENAI_API_KEY"
    _BASE = "https://api.openai.com/v1"

    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    def _oauth_headers(self, access_token: str) -> Dict[str, str]:
        import sys
        # VERIFIED WORKING — DO NOT CHANGE these header details:
        # - "authorization" must be lowercase (not "Authorization")
        # - value is the raw token, NO "Bearer " prefix
        # - "originator: opencode" is required or OpenAI returns 401
        h: Dict[str, str] = {
            "authorization": access_token,  # lowercase, no "Bearer "
            "Content-Type": "application/json",
            "originator": "opencode",
            "User-Agent": f"codrninja/1.0.7 ({sys.platform.capitalize()})",
        }
        account_id = self.config.get("account_id") or self.config.get("accountId")
        if account_id:
            h["ChatGPT-Account-Id"] = account_id
        return h

    def _auth_headers(self) -> Dict[str, str]:
        access_token = self.config.get("access_token")
        if access_token:
            return self._oauth_headers(access_token)
        api_key = self.config.get("api_key") or os.environ.get(self.oauth_env_var)
        if not api_key:
            return {}
        return self._api_key_headers(api_key)

    def _is_oauth(self) -> bool:
        return bool(self.config.get("access_token"))

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        headers = self._auth_headers()
        if not headers:
            return {"error": "OpenAI API key not set. Use /provider to configure.", "content": ""}
        model = model or self.config.get("model", "gpt-4o")
        try:
            r = requests.post(
                f"{self._BASE}/chat/completions",
                headers=headers,
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096)},
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            choice = data.get("choices", [{}])[0]
            usage = data.get("usage", {})
            return {
                "content": choice.get("message", {}).get("content", ""),
                "model": data.get("model", model),
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "done": True,
            }
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        headers = self._auth_headers()
        if not headers:
            yield {"error": "OpenAI API key not set.", "delta": "", "done": True}
            return
        model = model or self.config.get("model", "gpt-4o")

        if self._is_oauth():
            # Codex backend only supports specific models; fall back to gpt-5.5
            codex_model = model if model in _CODEX_OAUTH_SUPPORTED else "gpt-5.5"
            yield from self._responses_api_stream(messages, codex_model, headers)
            return

        try:
            with requests.post(
                f"{self._BASE}/chat/completions",
                headers=headers,
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096),
                      "stream": True},
                stream=True,
                timeout=300,
            ) as r:
                r.raise_for_status()
                actual_model = model
                tokens_in = tokens_out = 0
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        yield {"delta": "", "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                        return
                    try:
                        data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    actual_model = data.get("model", actual_model)
                    usage = data.get("usage") or {}
                    tokens_in = usage.get("prompt_tokens", tokens_in)
                    tokens_out = usage.get("completion_tokens", tokens_out)
                    delta = (data.get("choices") or [{}])[0].get("delta", {}).get("content") or ""
                    if delta:
                        yield {"delta": delta, "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def _responses_api_stream(self, messages: List[Dict], model: str, headers: Dict) -> Iterator[Dict[str, Any]]:
        """Responses API for OAuth tokens with gpt-5.x / codex models."""
        input_arr, instructions = _convert_messages_to_responses_input(messages, model)
        payload: Dict[str, Any] = {
            "model": model,
            "input": input_arr,
            "instructions": instructions or "You are a helpful assistant.",
            "store": False,
            "stream": True,
        }
        try:
            with requests.post(
                CODEX_RESPONSES_ENDPOINT,
                headers=headers,
                json=payload,
                stream=True,
                timeout=300,
                verify=False,  # required: chatgpt.com SSL fails on macOS without this
            ) as r:
                r.raise_for_status()
                tokens_in = tokens_out = 0
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                    if not line.startswith("data: "):
                        continue
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue
                    t = chunk.get("type", "")
                    if t == "response.output_text.delta":
                        delta = chunk.get("delta", "")
                        if delta:
                            yield {"delta": delta, "model": model,
                                   "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
                    elif t in ("response.completed", "response.incomplete"):
                        usage = chunk.get("response", {}).get("usage", {})
                        tokens_in = usage.get("input_tokens", tokens_in)
                        tokens_out = usage.get("output_tokens", tokens_out)
                        break
                    elif t == "error":
                        yield {"error": str(chunk), "delta": "", "done": True}
                        return
                yield {"delta": "", "model": model,
                       "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        try:
            headers = self._auth_headers()
            if headers:
                r = requests.get(f"{self._BASE}/models", headers=headers, timeout=8)
                if r.ok:
                    ids = sorted(
                        m["id"] for m in r.json().get("data", [])
                        if any(m["id"].startswith(p) for p in ("gpt-", "o1", "o3", "o4", "codex"))
                    )
                    if ids:
                        return ids
        except Exception:
            pass
        return [
            "gpt-5.5", "gpt-5.4", "gpt-5.4-mini", "gpt-5.3-codex", "gpt-5.2", "gpt-5",
            "gpt-4.5",
            "gpt-4.1", "gpt-4.1-mini", "gpt-4.1-nano",
            "gpt-4o", "gpt-4o-mini",
            "o1", "o1-mini", "o1-pro",
            "o3", "o3-mini", "o4-mini",
            "codex-mini-latest",
        ]

    def get_default_model(self) -> str:
        return self.config.get("model", "gpt-4o")


# ── Anthropic ─────────────────────────────────────────────────────────────────

class AnthropicProvider(OAuthCapableProvider):
    oauth_env_var = "ANTHROPIC_API_KEY"
    _BASE = "https://api.anthropic.com/v1"

    def _api_key_headers(self, api_key: str) -> Dict[str, str]:
        return {"x-api-key": api_key, "Content-Type": "application/json",
                "anthropic-version": "2023-06-01"}

    def _is_oauth_token(self) -> bool:
        token = self.config.get("access_token", "")
        return bool(token and token.startswith("sk-ant-oat"))

    def _auth_headers(self) -> Dict[str, str]:
        access_token = self.config.get("access_token")
        if access_token:
            h = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
                "anthropic-version": "2023-06-01",
            }
            if self._is_oauth_token():
                h["anthropic-beta"] = "claude-code-20250219,oauth-2025-04-20,fine-grained-tool-streaming-2025-05-14"
                h["user-agent"] = "claude-cli/2.1.75"
                h["x-app"] = "cli"
            return h
        api_key = self.config.get("api_key") or os.environ.get(self.oauth_env_var)
        if not api_key:
            return {}
        return self._api_key_headers(api_key)

    def _split_messages(self, messages):
        system = ""
        user_msgs = []
        for m in messages:
            if m["role"] == "system":
                system = m["content"]
            else:
                user_msgs.append({"role": m["role"], "content": m["content"]})
        return system, user_msgs

    def _build_payload(self, model: str, system: str, user_msgs: list, stream: bool) -> dict:
        payload: dict = {
            "model": model,
            "max_tokens": self.config.get("max_tokens", 4096),
            "messages": user_msgs,
            "stream": stream,
        }
        if system:
            if self._is_oauth_token():
                payload["system"] = [{"type": "text", "text": system}]
            else:
                payload["system"] = system
        if not self._is_oauth_token():
            payload["temperature"] = self.config.get("temperature", 0.7)
        return payload

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        headers = self._auth_headers()
        if not headers:
            return {"error": "Anthropic API key not set. Use /provider to configure.", "content": ""}
        model = model or self.config.get("model", "claude-sonnet-4-6")
        system, user_msgs = self._split_messages(messages)
        try:
            r = requests.post(
                f"{self._BASE}/messages",
                headers=headers,
                json=self._build_payload(model, system, user_msgs, stream=False),
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            usage = data.get("usage", {})
            content = data.get("content", [{}])
            return {
                "content": content[0].get("text", "") if content else "",
                "model": data.get("model", model),
                "tokens_input": usage.get("input_tokens", 0),
                "tokens_output": usage.get("output_tokens", 0),
                "done": True,
            }
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        headers = self._auth_headers()
        if not headers:
            yield {"error": "Anthropic API key not set.", "delta": "", "done": True}
            return
        model = model or self.config.get("model", "claude-sonnet-4-6")
        system, user_msgs = self._split_messages(messages)
        import time as _time
        for attempt in range(3):
            try:
                with requests.post(
                    f"{self._BASE}/messages",
                    headers=headers,
                    json=self._build_payload(model, system, user_msgs, stream=True),
                    stream=True,
                    timeout=300,
                ) as r:
                    if r.status_code == 429:
                        retry_after = int(r.headers.get("retry-after", 20))
                        if attempt < 2:
                            _time.sleep(retry_after)
                            continue
                        yield {"error": (
                            "Rate limit reached on Claude Code credentials. "
                            "The Claude Code OAuth token has strict per-minute limits. "
                            "Wait a moment and try again, or add your own Anthropic API key "
                            "via /provider → anthropic → API key."
                        ), "delta": "", "done": True}
                        return
                    r.raise_for_status()
                    tokens_in = tokens_out = 0
                    actual_model = model
                    for raw in r.iter_lines():
                        if not raw:
                            continue
                        line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                        if line.startswith("data: "):
                            try:
                                data = json.loads(line[6:])
                            except json.JSONDecodeError:
                                continue
                            t = data.get("type", "")
                            if t == "content_block_delta":
                                delta = data.get("delta", {}).get("text", "")
                                if delta:
                                    yield {"delta": delta, "model": actual_model,
                                           "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
                            elif t == "message_delta":
                                usage = data.get("usage", {})
                                tokens_out = usage.get("output_tokens", tokens_out)
                            elif t == "message_start":
                                msg = data.get("message", {})
                                actual_model = msg.get("model", actual_model)
                                usage = msg.get("usage", {})
                                tokens_in = usage.get("input_tokens", tokens_in)
                            elif t == "message_stop":
                                yield {"delta": "", "model": actual_model,
                                       "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                                return
                    return
            except Exception as e:
                yield {"error": str(e), "delta": "", "done": True}
                return

    def list_models(self) -> List[str]:
        return [
            "claude-opus-4-7",
            "claude-sonnet-4-6",
            "claude-haiku-4-5",
            "claude-3-7-sonnet-20250219",
            "claude-3-5-sonnet-20241022",
            "claude-3-5-haiku-20241022",
            "claude-3-opus-20240229",
            "claude-3-haiku-20240307",
        ]

    def get_default_model(self) -> str:
        return self.config.get("model", "claude-sonnet-4-6")


# ── OpenRouter ────────────────────────────────────────────────────────────────

class OpenRouterProvider(BaseProvider):
    _BASE = "https://openrouter.ai/api/v1"

    def _headers(self) -> Dict[str, str]:
        api_key = self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY", "")
        return {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        if not (self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY")):
            return {"error": "OpenRouter API key not set. Use /provider to configure.", "content": ""}
        model = model or self.config.get("model", "openai/gpt-4o")
        try:
            r = requests.post(
                f"{self._BASE}/chat/completions",
                headers=self._headers(),
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096)},
                timeout=300,
            )
            r.raise_for_status()
            data = r.json()
            choice = data.get("choices", [{}])[0]
            usage = data.get("usage", {})
            return {
                "content": choice.get("message", {}).get("content", ""),
                "model": data.get("model", model),
                "tokens_input": usage.get("prompt_tokens", 0),
                "tokens_output": usage.get("completion_tokens", 0),
                "done": True,
            }
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        if not (self.config.get("api_key") or os.environ.get("OPENROUTER_API_KEY")):
            yield {"error": "OpenRouter API key not set.", "delta": "", "done": True}
            return
        model = model or self.config.get("model", "openai/gpt-4o")
        try:
            with requests.post(
                f"{self._BASE}/chat/completions",
                headers=self._headers(),
                json={"model": model, "messages": messages,
                      "temperature": self.config.get("temperature", 0.7),
                      "max_tokens": self.config.get("max_tokens", 4096),
                      "stream": True},
                stream=True,
                timeout=300,
            ) as r:
                r.raise_for_status()
                actual_model = model
                tokens_in = tokens_out = 0
                for raw in r.iter_lines():
                    if not raw:
                        continue
                    line = raw.decode("utf-8") if isinstance(raw, bytes) else raw
                    if not line.startswith("data: "):
                        continue
                    payload = line[6:].strip()
                    if payload == "[DONE]":
                        yield {"delta": "", "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
                        return
                    try:
                        data = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    actual_model = data.get("model", actual_model)
                    usage = data.get("usage") or {}
                    tokens_in = usage.get("prompt_tokens", tokens_in)
                    tokens_out = usage.get("completion_tokens", tokens_out)
                    delta = (data.get("choices") or [{}])[0].get("delta", {}).get("content") or ""
                    if delta:
                        yield {"delta": delta, "model": actual_model,
                               "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        try:
            r = requests.get(f"{self._BASE}/models",
                             headers=self._headers(), timeout=8)
            if r.ok:
                return sorted(m["id"] for m in r.json().get("data", []))
        except Exception:
            pass
        return ["openai/gpt-4o", "openai/gpt-4.1", "anthropic/claude-sonnet-4-6",
                "google/gemini-2.5-pro", "meta-llama/llama-3.3-70b-instruct"]

    def get_default_model(self) -> str:
        return self.config.get("model", "openai/gpt-4o")


# ── Claude CLI ────────────────────────────────────────────────────────────────

class ClaudeCliProvider(BaseProvider):
    """Routes requests through the local `claude` CLI binary.
    Uses the user's Claude Code subscription instead of raw API credentials,
    avoiding the strict per-minute rate limits on OAuth tokens."""

    _MODELS = [
        "claude-opus-4-7",
        "claude-sonnet-4-6",
        "claude-haiku-4-5",
        "claude-3-7-sonnet-20250219",
        "claude-3-5-sonnet-20241022",
        "claude-3-5-haiku-20241022",
        "claude-3-opus-20240229",
    ]

    @staticmethod
    def find_binary() -> Optional[str]:
        return shutil.which("claude")

    @staticmethod
    def is_authenticated() -> bool:
        # Claude Code stores credentials in the OS keychain, NOT in a plain file.
        # Do NOT check for credentials.json — it doesn't exist on macOS.
        # Best proxy: ~/.claude/settings.json exists (written on first `claude auth login`).
        claude_dir = os.path.expanduser("~/.claude")
        return os.path.isdir(claude_dir) and os.path.isfile(os.path.join(claude_dir, "settings.json"))

    def _prepare(self, messages: List[Dict], model: Optional[str]) -> tuple:
        """Returns (cmd_list, error_str)."""
        binary = self.find_binary()
        if not binary:
            return None, "claude binary not found. Install Claude Code: https://claude.ai/code"
        if not self.is_authenticated():
            return None, "Not logged into Claude Code. Run: claude auth login"

        model = model or self.config.get("model", "claude-sonnet-4-6")

        system = ""
        conversation: List[Dict] = []
        for msg in messages:
            if msg.get("role") == "system":
                system = msg.get("content", "")
            else:
                conversation.append(msg)

        if not conversation:
            return None, "No messages to send"

        # Build the prompt: prepend conversation history to the last user message
        last_msg = conversation[-1].get("content", "")
        history = conversation[:-1]

        if history:
            parts = []
            for msg in history:
                label = "Human" if msg["role"] == "user" else "Assistant"
                parts.append(f"{label}: {msg['content']}")
            last_msg = "\n\n".join(parts) + f"\n\nHuman: {last_msg}"

        # VERIFIED WORKING — DO NOT CHANGE these flags without testing.
        # --print:                    non-interactive single-turn mode
        # --output-format stream-json: NDJSON output, one event per line
        # --verbose:                  REQUIRED for stream-json, omitting it causes an error
        # --dangerously-skip-permissions: suppresses interactive permission prompts
        # --no-tools does NOT exist in claude CLI — do not add it
        cmd = [
            binary, "--print",
            "--output-format", "stream-json",
            "--verbose",
            "--model", model,
            "--dangerously-skip-permissions",
        ]
        if system:
            cmd += ["--system-prompt", system]
        cmd.append(last_msg)

        return cmd, None

    def chat(self, messages: List[Dict], model: Optional[str] = None) -> Dict[str, Any]:
        cmd, err = self._prepare(messages, model)
        if err:
            return {"error": err, "content": ""}
        model_used = model or self.config.get("model", "claude-sonnet-4-6")
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            content = ""
            tokens_in = tokens_out = 0
            for line in result.stdout.splitlines():
                if not line.strip():
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if data.get("type") == "assistant":
                    for block in data.get("message", {}).get("content", []):
                        if block.get("type") == "text":
                            content += block.get("text", "")
                    usage = data.get("message", {}).get("usage", {})
                    tokens_in = usage.get("input_tokens", tokens_in)
                    tokens_out = usage.get("output_tokens", tokens_out)
                elif data.get("type") == "result":
                    usage = data.get("usage", {})
                    tokens_in = usage.get("input_tokens", tokens_in)
                    tokens_out = usage.get("output_tokens", tokens_out)
                    if not content:
                        content = data.get("result", "")
            return {"content": content, "model": model_used,
                    "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
        except subprocess.TimeoutExpired:
            return {"error": "Request timed out", "content": ""}
        except Exception as e:
            return {"error": str(e), "content": ""}

    def chat_stream(self, messages: List[Dict], model: Optional[str] = None) -> Iterator[Dict[str, Any]]:
        cmd, err = self._prepare(messages, model)
        if err:
            yield {"error": err, "delta": "", "done": True}
            return
        model_used = model or self.config.get("model", "claude-sonnet-4-6")
        tokens_in = tokens_out = 0
        try:
            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            )
            assert proc.stdout is not None
            for line in proc.stdout:
                line = line.rstrip("\n")
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                event_type = data.get("type")
                if event_type == "assistant":
                    msg_data = data.get("message", {})
                    model_used = msg_data.get("model", model_used)
                    usage = msg_data.get("usage", {})
                    tokens_in = usage.get("input_tokens", tokens_in)
                    tokens_out = usage.get("output_tokens", tokens_out)
                    for block in msg_data.get("content", []):
                        if block.get("type") == "text":
                            text = block.get("text", "")
                            if text:
                                yield {"delta": text, "model": model_used,
                                       "tokens_input": tokens_in, "tokens_output": tokens_out, "done": False}
                elif event_type == "result":
                    usage = data.get("usage", {})
                    tokens_in = usage.get("input_tokens", tokens_in)
                    tokens_out = usage.get("output_tokens", tokens_out)
            proc.wait()
            yield {"delta": "", "model": model_used,
                   "tokens_input": tokens_in, "tokens_output": tokens_out, "done": True}
        except Exception as e:
            yield {"error": str(e), "delta": "", "done": True}

    def list_models(self) -> List[str]:
        return self._MODELS

    def get_default_model(self) -> str:
        return self.config.get("model", "claude-sonnet-4-6")


# ── Manager ───────────────────────────────────────────────────────────────────

class ProviderManager:

    PROVIDERS = {
        "ollama":      OllamaProvider,
        "openai":      OpenAIProvider,
        "anthropic":   AnthropicProvider,
        "openrouter":  OpenRouterProvider,
        "claude-cli":  ClaudeCliProvider,   # routes via local claude binary, no API key needed
    }

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.current_provider = config.get("provider", "ollama")
        self.token_manager = TokenManager()
        self.oauth_buffer_minutes = int(config.get("oauth", {}).get("refresh_buffer_minutes", 5))

    def _provider_config(self, name: str) -> Dict[str, Any]:
        return dict(self.config.get("providers", {}).get(name, {}))

    def _inject_oauth(self, name: str, cfg: Dict[str, Any]) -> Dict[str, Any]:
        if name not in {"openai", "anthropic"}:
            return cfg
        tokens = self.token_manager.get_tokens(name)
        if not tokens:
            return cfg
        if self.token_manager.is_token_expired(tokens, buffer_minutes=self.oauth_buffer_minutes):
            rt = tokens.get("refresh_token")
            if rt:
                try:
                    refreshed = OAuthFlow(name).refresh(rt, metadata=tokens.get("metadata", {}))
                    if not refreshed.get("refresh_token"):
                        refreshed["refresh_token"] = rt
                    self.token_manager.store_tokens(name, refreshed)
                    tokens = refreshed
                except Exception:
                    pass
        if tokens.get("access_token"):
            cfg["access_token"] = tokens["access_token"]
        if tokens.get("account_id"):
            cfg["account_id"] = tokens["account_id"]
        return cfg

    def get_provider(self, name: Optional[str] = None) -> BaseProvider:
        name = name or self.current_provider
        if name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {name}. Available: {list(self.PROVIDERS.keys())}")
        return self.PROVIDERS[name](self._inject_oauth(name, self._provider_config(name)))

    def set_provider(self, name: str):
        if name not in self.PROVIDERS:
            raise ValueError(f"Unknown provider: {name}")
        self.current_provider = name

    def list_providers(self) -> List[str]:
        return list(self.PROVIDERS.keys())

    def list_models(self, provider: Optional[str] = None) -> List[str]:
        return self.get_provider(provider).list_models()
