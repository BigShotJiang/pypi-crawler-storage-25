from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class MessageEntry:
    id: str
    role: str
    text: str
    model: str = ""
    kind: str = "message"


@dataclass
class ToolCallEntry:
    call_id: str
    tool_name: str
    args: dict[str, Any] = field(default_factory=dict)
    status: str = "running"
    step: int = 0
    max_steps: int = 0
    output: str = ""
    success: Optional[bool] = None
    order: int = 0


@dataclass
class ArtifactEntry:
    path: str
    diff: str = ""
    status: str = "modified"
    action: str = "modify"


@dataclass
class FileTab:
    path: str
    content: str = ""
    language: str = "text"


@dataclass
class SessionViewModel:
    messages: list[MessageEntry] = field(default_factory=list)
    tools: dict[str, ToolCallEntry] = field(default_factory=dict)
    artifacts: list[ArtifactEntry] = field(default_factory=list)
    open_files: list[FileTab] = field(default_factory=list)
    terminal_lines: list[str] = field(default_factory=list)
    current_step: int = 0
    max_steps: int = 50
    status: str = "ready"
    _order: list[tuple[str, str]] = field(default_factory=list)

    def reset(self) -> None:
        self.messages.clear()
        self.tools.clear()
        self.artifacts.clear()
        self.open_files.clear()
        self.terminal_lines.clear()
        self.current_step = 0
        self.status = "ready"
        self._order.clear()

    def add_message(self, entry: MessageEntry) -> None:
        self.messages.append(entry)
        self._order.append((entry.kind, entry.id))

    def upsert_tool(self, entry: ToolCallEntry) -> None:
        if entry.call_id not in self.tools:
            entry.order = len(self._order)
            self._order.append(("tool", entry.call_id))
        else:
            entry.order = self.tools[entry.call_id].order
        self.tools[entry.call_id] = entry

    def set_tool_result(self, call_id: str, output: str, success: bool, step: int, max_steps: int) -> None:
        if call_id not in self.tools:
            self.upsert_tool(ToolCallEntry(call_id=call_id, tool_name="tool", step=step, max_steps=max_steps))
        entry = self.tools[call_id]
        entry.output = output
        entry.success = success
        entry.status = "done" if success else "failed"
        entry.step = step
        entry.max_steps = max_steps
        self.tools[call_id] = entry

    def set_artifacts(self, artifacts: list[ArtifactEntry]) -> None:
        self.artifacts = artifacts

    def timeline_entries(self) -> list[tuple[str, Any]]:
        indexed_messages = {entry.id: entry for entry in self.messages}
        items: list[tuple[str, Any]] = []
        for kind, entry_id in self._order:
            if kind == "tool" and entry_id in self.tools:
                items.append((kind, self.tools[entry_id]))
            elif entry_id in indexed_messages:
                items.append((kind, indexed_messages[entry_id]))
        return items
