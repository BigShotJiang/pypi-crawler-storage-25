#!/usr/bin/env python3
"""
skill_unload.py -- Unload skills/agents from the current session or permanently suppress them.

Usage:
    python skill_unload.py --name fastapi-pro              # Unload from current session
    python skill_unload.py --name fastapi-pro --permanent   # Set never_load: true in wiki
    python skill_unload.py --names "fastapi-pro,docker-expert"
    python skill_unload.py --stale                          # Unload all stale skills
    python skill_unload.py --list-loaded                    # Show currently loaded skills
    python skill_unload.py --list-never                     # Show permanently suppressed skills
    python skill_unload.py --restore fastapi-pro            # Remove never_load flag
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path

from ctx.core.wiki.wiki_utils import validate_skill_name
from ctx.utils._file_lock import file_lock
from ctx.utils._fs_utils import atomic_write_text as _atomic_write_text

CLAUDE_DIR = Path(os.path.expanduser("~/.claude"))
MANIFEST_PATH = CLAUDE_DIR / "skill-manifest.json"
PENDING_UNLOAD = CLAUDE_DIR / "pending-unload.json"
WIKI_DIR = CLAUDE_DIR / "skill-wiki"
SKILL_ENTITIES = WIKI_DIR / "entities" / "skills"
AGENT_ENTITIES = WIKI_DIR / "entities" / "agents"



def _sanitize_yaml_value(value: str) -> str:
    """Strip newlines/CRs so a value can't inject extra YAML keys."""
    return value.replace("\r", " ").replace("\n", " ").strip()


def load_manifest() -> dict:
    if MANIFEST_PATH.exists():
        try:
            return json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {"load": [], "unload": [], "warnings": []}


def save_manifest(manifest: dict) -> None:
    _atomic_write_text(MANIFEST_PATH, json.dumps(manifest, indent=2))


def set_frontmatter_field(filepath: Path, field: str, value: str) -> bool:
    """Set a YAML frontmatter field in a wiki entity page. Returns True if changed.

    Hardened: ``field`` is re-escaped before regex use (prevents ReDoS and
    regex-injection via caller-controlled field names); ``value`` is sanitized
    to strip newlines that would inject extra YAML keys.
    """
    if not filepath.exists():
        return False
    safe_value = _sanitize_yaml_value(value)
    escaped_field = re.escape(field)
    content = filepath.read_text(encoding="utf-8", errors="replace")
    pattern = rf"^{escaped_field}:\s*.+$"
    replacement = f"{field}: {safe_value}"
    new_content, count = re.subn(pattern, replacement, content, count=1, flags=re.MULTILINE)
    if count == 0:
        # Field doesn't exist — add it after the opening frontmatter delimiter.
        new_content = re.sub(r"(---\n)", rf"\1{field}: {safe_value}\n", content, count=1)
    if new_content != content:
        _atomic_write_text(filepath, new_content)
        return True
    return False


def find_entity_page(name: str) -> Path | None:
    """Find entity page for a skill or agent by name.

    Hardened against path traversal (CWE-22): name is validated against
    ``SAFE_NAME_RE`` before any filesystem access.
    """
    try:
        validate_skill_name(name)
    except ValueError:
        return None
    skill_page = SKILL_ENTITIES / f"{name}.md"
    if skill_page.exists():
        return skill_page
    agent_page = AGENT_ENTITIES / f"{name}.md"
    if agent_page.exists():
        return agent_page
    return None


def clear_pending_unload(names: list[str]) -> None:
    """Remove unloaded skills from pending-unload.json."""
    if not PENDING_UNLOAD.exists():
        return
    try:
        data = json.loads(PENDING_UNLOAD.read_text(encoding="utf-8"))
        data["suggestions"] = [s for s in data.get("suggestions", []) if s["name"] not in names]
        _atomic_write_text(PENDING_UNLOAD, json.dumps(data, indent=2))
    except Exception as exc:
        print(f"Warning: failed to clear pending unload: {exc}", file=sys.stderr)


def unload_from_session(
    names: list[str],
    *,
    entity_type: str | None = None,
) -> list[str]:
    """Remove skills/agents from the current session manifest.

    Emits one ``unload`` line per removed skill to
    ``~/.claude/skill-events.jsonl`` and one ``skill.unloaded`` record
    to the unified audit log. The random-load-unload playbook caught
    that loads flowed through skill-events.jsonl but unloads didn't,
    making the two halves of the lifecycle asymmetric at the ground-
    truth log level. Fix both at the single choke point.
    """
    import uuid
    from datetime import datetime, timezone

    names_set = set(names)
    with file_lock(MANIFEST_PATH):
        manifest = load_manifest()
        removed: list[str] = []
        remaining = []
        for entry in manifest.get("load", []):
            entry_type = entry.get("entity_type", "skill")
            if (
                entry["skill"] in names_set
                and (entity_type is None or entry_type == entity_type)
            ):
                removed.append(entry["skill"])
                manifest.setdefault("unload", []).append(entry)
            else:
                remaining.append(entry)
        manifest["load"] = remaining
        save_manifest(manifest)

    # Emit ground-truth unload events. Best-effort — a disk failure on
    # the event log must not block the manifest save above.
    if removed:
        events_path = CLAUDE_DIR / "skill-events.jsonl"
        session_id = os.environ.get("CTX_SESSION_ID") or f"unload-{uuid.uuid4().hex[:8]}"
        now_iso = datetime.now(timezone.utc).isoformat()
        try:
            events_path.parent.mkdir(parents=True, exist_ok=True)
            with events_path.open("a", encoding="utf-8") as fh:
                for slug in removed:
                    fh.write(json.dumps({
                        "event": "unload",
                        "event_id": uuid.uuid4().hex,
                        "meta": {"source": "skill_unload"},
                        "session_id": session_id,
                        "skill": slug,
                        "timestamp": now_iso,
                    }) + "\n")
        except OSError as exc:
            print(f"Warning: failed to log unload events: {exc}", file=sys.stderr)
        try:
            from ctx_audit_log import log_skill_event
            for slug in removed:
                log_skill_event(
                    "skill.unloaded", slug,
                    actor="cli", session_id=session_id,
                    meta={"via": "skill_unload"},
                )
        except Exception:  # noqa: BLE001 — audit best-effort
            pass

    return removed


def set_never_load(names: list[str]) -> list[str]:
    """Set never_load: true in wiki entity pages."""
    updated: list[str] = []
    for name in names:
        page = find_entity_page(name)
        if page and set_frontmatter_field(page, "never_load", "true"):
            updated.append(name)
            print(f"  {name}: never_load set to true")
        elif page:
            print(f"  {name}: already set to never_load")
        else:
            print(f"  {name}: entity page not found", file=sys.stderr)
    return updated


def restore_load(names: list[str]) -> list[str]:
    """Remove never_load flag from wiki entity pages."""
    restored: list[str] = []
    for name in names:
        page = find_entity_page(name)
        if page and set_frontmatter_field(page, "never_load", "false"):
            restored.append(name)
            print(f"  {name}: never_load removed, skill can be recommended again")
        elif page:
            print(f"  {name}: was not suppressed")
        else:
            print(f"  {name}: entity page not found", file=sys.stderr)
    return restored


def get_stale_skills() -> list[str]:
    """Find all skills with status: stale in their entity pages."""
    stale: list[str] = []
    for entity_dir in [SKILL_ENTITIES, AGENT_ENTITIES]:
        if not entity_dir.exists():
            continue
        for page in entity_dir.glob("*.md"):
            content = page.read_text(encoding="utf-8", errors="replace")
            if re.search(r"^status:\s*stale", content, re.MULTILINE):
                stale.append(page.stem)
    return stale


def list_loaded() -> None:
    """Show currently loaded skills/agents."""
    manifest = load_manifest()
    loaded = manifest.get("load", [])
    if not loaded:
        print("No skills/agents currently loaded in this session.")
        return
    print(f"Currently loaded ({len(loaded)}):\n")
    for entry in loaded:
        source = entry.get("source", "unknown")
        print(f"  - {entry['skill']}  (source: {source})")


def list_never_load() -> None:
    """Show permanently suppressed skills/agents."""
    suppressed: list[str] = []
    for entity_dir in [SKILL_ENTITIES, AGENT_ENTITIES]:
        if not entity_dir.exists():
            continue
        for page in entity_dir.glob("*.md"):
            content = page.read_text(encoding="utf-8", errors="replace")
            if re.search(r"^never_load:\s*true", content, re.MULTILINE):
                suppressed.append(page.stem)
    if not suppressed:
        print("No skills/agents are permanently suppressed.")
        return
    print(f"Permanently suppressed ({len(suppressed)}):\n")
    for name in sorted(suppressed):
        print(f"  - {name}")
    print("\nTo restore: python src/skill_unload.py --restore <name>")


def main() -> None:
    parser = argparse.ArgumentParser(description="Unload skills/agents from session or suppress permanently")
    # ``--slug`` is an alias for ``--name`` so docs/playbooks that say
    # "slug" (the canonical vocabulary everywhere else in ctx) work
    # without the user remembering that this one CLI uses "name".
    parser.add_argument("--name", "--slug", dest="name",
                        help="Skill or agent slug to unload")
    parser.add_argument("--names", help="Comma-separated slugs to unload")
    parser.add_argument("--session-id", dest="session_id",
                        help="Override CTX_SESSION_ID env for the emitted "
                             "unload events (default: env var or synthetic id)")
    parser.add_argument("--permanent", action="store_true", help="Set never_load: true (won't be recommended again)")
    parser.add_argument("--stale", action="store_true", help="Unload all stale skills")
    parser.add_argument("--restore", help="Remove never_load flag from a skill/agent")
    parser.add_argument("--list-loaded", action="store_true", help="Show currently loaded skills")
    parser.add_argument("--list-never", action="store_true", help="Show permanently suppressed skills")
    args = parser.parse_args()

    # Propagate --session-id into the env so unload_from_session() and
    # its audit-log call both tag the emitted events with the caller's
    # chosen session id.
    if args.session_id:
        os.environ["CTX_SESSION_ID"] = args.session_id

    if args.list_loaded:
        list_loaded()
        return

    if args.list_never:
        list_never_load()
        return

    if args.restore:
        raw_names = [n.strip() for n in args.restore.split(",")]
        valid: list[str] = []
        for n in raw_names:
            try:
                valid.append(validate_skill_name(n))
            except ValueError as exc:
                print(f"Skipping invalid name {n!r}: {exc}", file=sys.stderr)
        if valid:
            restore_load(valid)
        return

    names: list[str] = []
    if args.name:
        names.append(args.name)
    if args.names:
        names.extend(n.strip() for n in args.names.split(","))
    if args.stale:
        stale = get_stale_skills()
        print(f"Found {len(stale)} stale skills")
        names.extend(stale)

    if not names:
        parser.print_help()
        sys.exit(1)

    # Reject any name that doesn't match the allowlist before we touch the FS.
    safe_names: list[str] = []
    for n in names:
        try:
            safe_names.append(validate_skill_name(n))
        except ValueError as exc:
            print(f"Skipping invalid name {n!r}: {exc}", file=sys.stderr)
    names = safe_names
    if not names:
        sys.exit(1)

    # Unload from current session manifest
    removed = unload_from_session(names)
    if removed:
        print(f"Unloaded from session: {', '.join(removed)}")

    # Mark as stale in wiki (so they drop in priority next session)
    not_removed = [n for n in names if n not in removed]
    if not_removed:
        for name in not_removed:
            page = find_entity_page(name)
            if page:
                set_frontmatter_field(page, "status", "stale")
                print(f"  {name}: marked stale (lower priority next session)")

    # Always clear from pending-unload
    clear_pending_unload(names)

    # Permanently suppress if requested
    if args.permanent:
        print("Setting never_load: true (will not be recommended again):")
        set_never_load(names)


if __name__ == "__main__":
    main()
