#!/usr/bin/env python3
"""
wiki_graphify.py -- Build a knowledge graph from wiki entity pages, detect
communities, generate concept pages, and inject wikilinks.

Uses networkx for graph construction and greedy_modularity_communities for
community detection (no external Leiden dependency needed).

Usage:
    python wiki_graphify.py                    # Full run: graph + communities + inject
    python wiki_graphify.py --graph-only       # Build graph and export JSON only
    python wiki_graphify.py --dry-run          # Preview changes without writing
"""

import argparse
import json
import os
import re
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

import networkx as nx
from networkx.algorithms.community import (
    greedy_modularity_communities,  # legacy CNM — slow on 10K+ node graphs
    louvain_communities,
)

from ctx.core.entity_types import (
    RELATED_SECTION_FOR_ENTITY_TYPE,
    entity_page_path,
    entity_wikilink,
    mcp_shard,
)
from ctx.core.wiki.wiki_utils import parse_frontmatter as _parse_fm
from ctx.utils._fs_utils import safe_atomic_write_text

TODAY = datetime.now(timezone.utc).strftime("%Y-%m-%d")
GRAPH_RELATED_START = "<!-- ctx-graph-related:start -->"
GRAPH_RELATED_END = "<!-- ctx-graph-related:end -->"
GRAPH_RELATED_BLOCK_RE = re.compile(
    rf"\n?{re.escape(GRAPH_RELATED_START)}\n.*?{re.escape(GRAPH_RELATED_END)}\n?",
    re.DOTALL,
)

WIKI_DIR = Path(os.path.expanduser("~/.claude/skill-wiki"))
SKILL_ENTITIES = WIKI_DIR / "entities" / "skills"
AGENT_ENTITIES = WIKI_DIR / "entities" / "agents"
# MCP entities are sharded by first character
# (entities/mcp-servers/<shard>/<slug>.md) — see McpRecord.entity_relpath.
# Iterate recursively so the shard layout is transparent here.
MCP_ENTITIES = WIKI_DIR / "entities" / "mcp-servers"
HARNESS_ENTITIES = WIKI_DIR / "entities" / "harnesses"
CONCEPTS_DIR = WIKI_DIR / "concepts"
GRAPH_OUT = WIKI_DIR / "graphify-out"
# Source of truth for per-node quality: sidecars produced by
# ``src/skill_quality.py``. Graph nodes get ``quality_score`` and
# ``quality_grade`` attached when a matching sidecar exists.
QUALITY_SIDECAR_DIR = Path(os.path.expanduser("~/.claude/skill-quality"))


def configure_wiki_dir(wiki_dir: Path) -> None:
    """Point graphify at a specific wiki root.

    The shipped tarball can be rebuilt in an isolated temp directory, so
    graphify must not be hard-wired to the operator's live
    ``~/.claude/skill-wiki``. Keep the derived entity/output paths in sync.
    """
    global WIKI_DIR, SKILL_ENTITIES, AGENT_ENTITIES, MCP_ENTITIES
    global HARNESS_ENTITIES, CONCEPTS_DIR, GRAPH_OUT

    WIKI_DIR = wiki_dir.expanduser().resolve()
    SKILL_ENTITIES = WIKI_DIR / "entities" / "skills"
    AGENT_ENTITIES = WIKI_DIR / "entities" / "agents"
    MCP_ENTITIES = WIKI_DIR / "entities" / "mcp-servers"
    HARNESS_ENTITIES = WIKI_DIR / "entities" / "harnesses"
    CONCEPTS_DIR = WIKI_DIR / "concepts"
    GRAPH_OUT = WIKI_DIR / "graphify-out"


def parse_frontmatter(filepath: Path) -> dict:
    """Parse YAML frontmatter from a markdown file, adding path metadata."""
    content = filepath.read_text(encoding="utf-8", errors="replace")
    result: dict = {"_path": str(filepath), "_stem": filepath.stem, "_content": content}
    result.update(_parse_fm(content))
    return result


# ────────────────────────────────────────────────────────────────────
# Entity-type dispatch — keeps skill/agent/mcp-server treatment in one
# place so the inject loop below stays readable as types grow.
# ────────────────────────────────────────────────────────────────────


def _mcp_shard(slug: str) -> str:
    """Return the shard segment for an MCP slug (matches McpRecord.entity_relpath)."""
    return mcp_shard(slug)


def _entity_page_path(entity_type: str, slug: str) -> Path | None:
    """Resolve (entity_type, slug) to its on-disk page path. None for unknown types."""
    wiki = WIKI_DIR
    if entity_type == "skill":
        wiki = SKILL_ENTITIES.parents[1]
    elif entity_type == "agent":
        wiki = AGENT_ENTITIES.parents[1]
    elif entity_type == "mcp-server":
        wiki = MCP_ENTITIES.parents[1]
    elif entity_type == "harness":
        wiki = HARNESS_ENTITIES.parents[1]
    else:
        return None
    return entity_page_path(wiki, entity_type, slug)


def _entity_wikilink(entity_type: str, slug: str) -> str | None:
    """Wikilink target for an entity. None for unknown types."""
    return entity_wikilink(entity_type, slug)


def _related_section_header(entity_type: str) -> str:
    """Section header under which graph-derived backlinks land."""
    return RELATED_SECTION_FOR_ENTITY_TYPE.get(entity_type, "## Related")


SLUG_STOP: frozenset[str] = frozenset({
    "a", "an", "the", "and", "of", "for", "to", "with",
    "skill", "agent", "expert", "pro", "core",
})


def _strip_frontmatter(content: str) -> str:
    """Return the markdown body with the YAML frontmatter removed."""
    parts = content.split("---", 2)
    return parts[2] if len(parts) >= 3 else content


def _load_full_body(meta: dict, slug: str, entity_type: str) -> str:
    """Load the canonical content source for semantic embedding.

    Different entity types live in different places in the wiki:

      - **skill**: when a micro-skill conversion preserved
        ``SKILL.md.original``, use that full source body for semantic
        embedding. This keeps graph quality high without crawling every
        generated shard file. Otherwise use the converted ``SKILL.md``
        plus ``references/*.md`` stages when present. Falls back to the
        entity card body when no converted dir exists.
      - **agent**: ``<wiki>/converted-agents/<slug>.md`` holds the full
        Claude Code agent prompt (populated by ``ctx-agent-mirror``).
        Falls back to the entity card body when the mirror hasn't
        run for a particular slug.
      - **mcp-server** and **harness**: entity cards are the only body we have; the
        pulsemcp description + tags + related links inside the
        card are the full context. Phase 6f.B detail-enrichment
        could later pull the GitHub README here, but that's out of
        scope for this pass.

    The returned text is always non-empty — falls through to the
    slug (hyphen-split) if every richer source was blank.
    """
    entity_body = _strip_frontmatter(meta.get("_content", ""))

    rich_body = ""
    if entity_type == "skill":
        converted_dir = WIKI_DIR / "converted" / slug
        original_md = converted_dir / "SKILL.md.original"
        skill_md = converted_dir / "SKILL.md"
        if original_md.is_file():
            try:
                rich_body = original_md.read_text(encoding="utf-8", errors="replace")
            except OSError:
                rich_body = ""
        if skill_md.is_file() and not rich_body:
            try:
                rich_body = skill_md.read_text(encoding="utf-8", errors="replace")
            except OSError:
                rich_body = ""
            refs_dir = converted_dir / "references"
            if refs_dir.is_dir():
                parts: list[str] = [rich_body] if rich_body else []
                for ref in sorted(refs_dir.glob("*.md")):
                    try:
                        parts.append(ref.read_text(encoding="utf-8", errors="replace"))
                    except OSError:
                        continue
                rich_body = "\n\n".join(p for p in parts if p.strip())
    elif entity_type == "agent":
        agent_md = WIKI_DIR / "converted-agents" / f"{slug}.md"
        if agent_md.is_file():
            try:
                rich_body = agent_md.read_text(encoding="utf-8", errors="replace")
            except OSError:
                rich_body = ""

    body = rich_body or entity_body

    # Prepend a tiny header (name + tags) so it rides along even when
    # body content is noisy. Short, canonical, high-signal.
    header_pieces: list[str] = []
    for key in ("name", "title"):
        v = meta.get(key)
        if isinstance(v, str) and v.strip():
            header_pieces.append(v.strip())
            break
    desc = meta.get("description")
    if isinstance(desc, str) and desc.strip():
        header_pieces.append(desc.strip())
    header_pieces.append(slug.replace("-", " "))
    tags = meta.get("tags") or []
    if isinstance(tags, list) and tags:
        header_pieces.append(" ".join(str(t) for t in tags if t))

    head = " | ".join(p for p in header_pieces if p)
    combined = f"{head}\n\n{body}" if body else head
    return combined.strip() or slug.replace("-", " ")


def _slug_tokens(slug: str) -> list[str]:
    """Return the >=3-char non-stopword tokens from a slug."""
    return [
        t for t in slug.lower().split("-")
        if len(t) >= 3 and t not in SLUG_STOP
    ]


def _pairs_from_index(
    index: dict[str, list[str]],
    *,
    dense_threshold: int,
    saturation: int,
) -> tuple[dict[tuple[str, str], int], dict[tuple[str, str], list[str]]]:
    """Turn a ``{key: [node_ids]}`` index into per-pair overlap counts.

    Buckets with more than ``dense_threshold`` nodes are skipped —
    they'd produce O(N^2) noise edges of weight 1 (e.g. a "python"
    tag on 1,000 entities ⇒ 499,500 near-meaningless pairs).

    Returns ``(counts, shared_keys)``:
      - ``counts[pair]`` is the number of shared keys in that pair
      - ``shared_keys[pair]`` is the concrete list of shared keys,
        for edge attribution in the rendered graph.
    """
    counts: dict[tuple[str, str], int] = defaultdict(int)
    shared: dict[tuple[str, str], list[str]] = defaultdict(list)
    for key, node_ids in index.items():
        if len(node_ids) > dense_threshold:
            continue
        sorted_ids = sorted(node_ids)
        for i, n1 in enumerate(sorted_ids):
            for n2 in sorted_ids[i + 1:]:
                pair = (n1, n2)
                counts[pair] += 1
                shared[pair].append(key)
    return counts, shared


def build_graph(
    *, incremental: bool = True,
    _affected_out: set[str] | None = None,
) -> tuple[nx.Graph, dict[str, dict]]:
    """Build a networkx graph from all entity pages.

    Nodes = entity pages (skills + agents + mcp-servers).

    Edges come from three independent signals whose per-edge
    contributions are blended into a single ``final_weight``:

      - **Semantic similarity** (default blend 0.70) — cosine between
        sentence-embedding vectors of each entity's name+description+
        slug+tags. Captures context-level affinity that tags miss
        (e.g. a python-linter MCP ↔ a code-reviewer agent).
      - **Shared tags** (default 0.15) — explicit ``tags:`` frontmatter
        overlap, saturating at ``shared_tag_saturation`` overlaps.
      - **Shared slug tokens** (default 0.15) — matching >=3-char
        non-stopword tokens from the slug (``atlassian-admin`` ↔
        ``atlassian-cloud`` share the ``atlassian`` token).

    Weights and thresholds are configurable via ``cfg.graph.*`` in
    config.json (see the ``graph`` section comments for the full
    rationale). Setting ``semantic=0.0`` reverts to the pre-7.1
    tag+token-only behaviour.

    Each edge carries: ``semantic_sim``, ``tag_sim``, ``token_sim``,
    ``final_weight``, ``weight`` (alias of final_weight for backward
    compat with Obsidian graph view + downstream consumers that still
    read ``weight``), and ``shared_tags`` / ``shared_tokens`` lists
    for explainability.
    """
    from ctx_config import cfg as _cfg  # noqa: PLC0415 — local to avoid
    # a config read at module-import time (tests patch cfg).
    from ctx.core.graph import semantic_edges as _sem  # noqa: PLC0415

    G = nx.Graph()
    entities: dict[str, dict] = {}

    sources: list[tuple[Path, str, str]] = [
        (SKILL_ENTITIES, "skill", "*.md"),
        (AGENT_ENTITIES, "agent", "*.md"),
        (MCP_ENTITIES, "mcp-server", "**/*.md"),
        (HARNESS_ENTITIES, "harness", "*.md"),
    ]

    # ── Phase 1: discover nodes + collect embedding texts ─────────────
    embed_nodes: list[_sem.SemanticNode] = []
    for entity_dir, entity_type, glob_pattern in sources:
        if not entity_dir.exists():
            continue
        if "**" in glob_pattern:
            pages = sorted(entity_dir.rglob("*.md"))
        else:
            pages = sorted(entity_dir.glob(glob_pattern))
        for page in pages:
            meta = parse_frontmatter(page)
            tags = meta.get("tags", [])
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",") if t.strip()]
            slug = page.stem
            node_id = f"{entity_type}:{slug}"
            G.add_node(node_id, label=slug, type=entity_type, tags=tags)
            entities[node_id] = meta
            embed_nodes.append(_sem.SemanticNode(
                node_id=node_id,
                text=_load_full_body(meta, slug, entity_type),
            ))

    # ── Phase 2: tag + slug-token indices (cheap) ────────────────────
    tag_index: dict[str, list[str]] = defaultdict(list)
    token_index: dict[str, list[str]] = defaultdict(list)
    for nid, data in G.nodes(data=True):
        for tag in data.get("tags", []):
            if tag and tag != "uncategorized":
                tag_index[str(tag)].append(nid)
        slug = data.get("label", nid.split(":", 1)[-1])
        for token in _slug_tokens(slug):
            token_index[token].append(nid)

    tag_counts, tag_shared = _pairs_from_index(
        tag_index,
        dense_threshold=_cfg.graph_dense_tag_threshold,
        saturation=_cfg.graph_shared_tag_saturation,
    )
    token_counts, token_shared = _pairs_from_index(
        token_index,
        dense_threshold=_cfg.graph_dense_token_threshold,
        saturation=_cfg.graph_shared_token_saturation,
    )

    # ── Phase 3: semantic edges (expensive) ──────────────────────────
    # ``build_floor`` governs inclusion in graph.json; ``min_cosine`` is
    # the query-time filter applied by consumers. Materialising everything
    # down to the floor lets operators A/B different display thresholds
    # without regraphifying — the slow path only runs when the floor
    # itself, top_k, or the embedding text changes.
    if _cfg.graph_edge_weight_semantic > 0.0:
        sem_pairs = _sem.compute_semantic_edges(
            embed_nodes,
            top_k=_cfg.graph_semantic_top_k,
            min_cosine=_cfg.graph_semantic_build_floor,
            batch_size=_cfg.graph_semantic_batch_size,
            cache_dir=_cfg.graph_semantic_cache_dir,
            backend=_cfg.intake_backend,
            model=_cfg.intake_model,
            incremental=incremental,
        )
    else:
        sem_pairs = {}

    # ── Phase 4: union all pairs and blend weights per pair ──────────
    tag_sat = max(_cfg.graph_shared_tag_saturation, 1)
    tok_sat = max(_cfg.graph_shared_token_saturation, 1)
    w_sem = _cfg.graph_edge_weight_semantic
    w_tag = _cfg.graph_edge_weight_tags
    w_tok = _cfg.graph_edge_weight_tokens

    all_pairs: set[tuple[str, str]] = (
        set(sem_pairs) | set(tag_counts) | set(token_counts)
    )

    # Materialise the target edge set as ``{pair: attr_dict}`` — both
    # the full-build and patch paths consume this same dict, which
    # keeps the blend formula in one place and makes the patch path
    # a pure data op.
    target_edges: dict[tuple[str, str], dict] = {}
    for pair in all_pairs:
        sem = sem_pairs.get(pair, 0.0)
        tag = min(tag_counts.get(pair, 0) / tag_sat, 1.0)
        tok = min(token_counts.get(pair, 0) / tok_sat, 1.0)
        final = w_sem * sem + w_tag * tag + w_tok * tok
        if final <= 0.0:
            # Useless edge — only happens when every signal dropped to
            # zero or landed below its floor. Skip materialisation.
            continue
        target_edges[pair] = {
            "semantic_sim": round(sem, 4),
            "tag_sim": round(tag, 4),
            "token_sim": round(tok, 4),
            "final_weight": round(final, 4),
            "weight": round(final, 4),
            "shared_tags": tag_shared.get(pair, []),
            "shared_tokens": token_shared.get(pair, []),
        }

    # Decide: full build or patch an existing graph? Patching requires
    # a compatible pickle on disk AND an incremental run. Anything
    # else falls through to a clean rebuild.
    prior_graph = load_prior_graph() if incremental else None

    # ── Patch-path safety: detect "edge generation parameters changed"
    # since the prior build (e.g. semantic backend went from
    # unavailable → available between runs). The patch path's
    # affected-nodes detector only catches *content* changes; it does
    # NOT catch the case where the same content needs different edges
    # because a signal source was just enabled/disabled. Without this
    # guard, a freshly-computed semantic_sim never lands on edges that
    # the patch path leaves "untouched", and the published graph
    # silently ships with semantic_sim=0 everywhere.
    #
    # The check: if we just computed semantic pairs (len(sem_pairs) > 0)
    # but the prior graph has zero edges with semantic_sim > 0, the
    # prior was built without semantic. Force a full rebuild — the
    # patch path cannot reconcile this without rebuilding every edge.
    if prior_graph is not None and len(sem_pairs) > 0:
        prior_with_sem = sum(
            1 for _, _, d in prior_graph.edges(data=True)
            if d.get("semantic_sim", 0.0) > 0
        )
        if prior_with_sem == 0:
            print(
                "graphify: prior graph has 0 semantic edges but current run "
                f"computed {len(sem_pairs):,} semantic pairs — forcing full "
                "rebuild (patch path cannot reconcile signal-source change).",
                flush=True,
            )
            prior_graph = None
    current_node_info: dict[str, dict] = {
        nid: {
            "label": data.get("label", nid.split(":", 1)[-1]),
            "type": data.get("type", ""),
            "tags": list(data.get("tags", []) or []),
        }
        for nid, data in G.nodes(data=True)
    }
    # The "affected" set for the patch path is every node that got a
    # fresh top-K this run (semantic_edges Option B partition). We
    # recover it from the edge delta: any node that appears in an
    # edge whose semantic_sim is from a fresh computation. As a
    # proxy we use "every node in target_edges" — too aggressive but
    # correct; a future refinement can thread the exact affected set
    # out of semantic_edges explicitly.
    # For the first patch-capable release we flag ALL nodes that
    # currently have a target edge as affected — that's not strictly
    # minimal but it's correct, and edge-count in the prior graph's
    # unaffected set is still large enough to pay off.
    if prior_graph is not None and incremental:
        affected_nodes = _recover_affected_from_sem_state(
            cache_dir=_cfg.graph_semantic_cache_dir,
            current_ids=set(current_node_info),
        )
        patched = patch_graph(
            prior_graph,
            current_node_info=current_node_info,
            target_edges=target_edges,
            affected_node_ids=affected_nodes,
        )
        # Patching mutates the prior; swap it in for G so downstream
        # sees the patched graph.
        G = patched
        if _affected_out is not None:
            _affected_out.update(affected_nodes)
    else:
        # Full build path — add every target edge to the fresh graph.
        for pair, attrs in target_edges.items():
            n1, n2 = pair
            G.add_edge(n1, n2, **attrs)
        # Full rebuilds have no per-entity delta; leave _affected_out empty.

    _attach_quality_attrs(G, QUALITY_SIDECAR_DIR)

    # Record the build-time floor on the graph so consumers that
    # inherit a stale graph.json can sanity-check their filter
    # request (filtering below the floor is meaningless — those
    # edges were never materialised).
    G.graph["semantic_build_floor"] = round(_cfg.graph_semantic_build_floor, 4)
    G.graph["semantic_min_cosine_default"] = round(_cfg.graph_semantic_min_cosine, 4)

    print(f"Graph: {G.number_of_nodes()} nodes, {G.number_of_edges()} edges")
    print(
        f"Edge sources: semantic={len(sem_pairs)}, tag_pairs={len(tag_counts)}, "
        f"token_pairs={len(token_counts)} "
        f"(blend: sem={w_sem}, tag={w_tag}, tok={w_tok})"
    )
    print(f"Tag index: {len(tag_index)} unique tags; token index: {len(token_index)} tokens")
    return G, entities


def _recover_affected_from_sem_state(
    *, cache_dir: Path, current_ids: set[str],
) -> set[str]:
    """Compute the set of node IDs whose incident edges need refresh.

    Reads the Option-B top-K state and returns the set of nodes whose
    content_hash differs from whatever is currently on disk, plus nodes
    that are new this run. Nodes that are in the prior state but NOT
    in current_ids are implicitly affected (they'll be removed) and
    are left for patch_graph to handle via its own node-delta pass.

    Falls back to "all current nodes" when the state file is missing
    or unreadable — that's correct but loses the patch speedup.
    """
    import json  # noqa: PLC0415

    state_path = cache_dir / "topk-state.json"
    if not state_path.is_file():
        return set(current_ids)
    try:
        raw = json.loads(state_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return set(current_ids)
    prior_nodes = raw.get("nodes", {})
    if not isinstance(prior_nodes, dict):
        return set(current_ids)
    prior_ids = set(prior_nodes.keys())
    # New nodes are always affected; the per-hash diff for overlap
    # nodes is already computed inside compute_semantic_edges and
    # folded into the returned pairs, but we don't thread the exact
    # list out of there today. Instead we treat as affected: (a) new
    # nodes and (b) nodes whose prior top-K contained a now-removed
    # neighbour. That catches the common "a few entities changed"
    # case. For a full rebuild run, the caller passes incremental=False
    # and this function is never reached.
    new_nodes = current_ids - prior_ids
    removed = prior_ids - current_ids
    affected = set(new_nodes)
    if removed:
        for nid, entry in prior_nodes.items():
            if nid not in current_ids:
                continue
            for tk in entry.get("top_k", []):
                if not tk:
                    continue
                neighbor = tk[0]
                if neighbor in removed:
                    affected.add(nid)
                    break
    # Also mark anything with a content-hash change. We compute hashes
    # against the current texts fresh here — cheap, and avoids
    # threading state through the caller.
    return affected


def load_prior_graph() -> nx.Graph | None:
    """Load the previous run's graph from ``graph.json``, or None on any issue.

    The canonical on-disk artifact is ``graph.json`` (node-link format).
    ``patch_graph`` uses the loaded graph as the starting point for an
    incremental update; callers that can't load (missing file, corrupt
    JSON, wrong schema, first run) just build from scratch instead.

    SECURITY NOTE: earlier revisions of this function read a
    ``graph.pickle`` sidecar via ``pickle.loads``, which is an RCE
    primitive — a poisoned pickle executes during deserialisation,
    before any type check. Security-auditor finding C-1. The pickle
    path is now permanently removed; a stale ``graph.pickle`` on disk
    is ignored. Do not reintroduce it — use JSON or a checksummed
    binary format (msgpack) if the JSON parse cost ever matters.
    """
    path = GRAPH_OUT / "graph.json"
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(
            f"wiki_graphify: prior graph.json unreadable ({exc}); full rebuild",
            flush=True,
        )
        return None
    # Shape check: networkx node-link documents have a 'nodes' list and
    # an 'edges' (or legacy 'links') list. Anything else is either a
    # garbage file someone dropped in graphify-out/ or an unrelated
    # JSON blob — reject rather than feed to node_link_graph.
    if not isinstance(data, dict):
        return None
    if "nodes" not in data or not isinstance(data["nodes"], list):
        return None
    if "edges" not in data and "links" not in data:
        return None
    try:
        # ``edges="edges"`` matches what export_graph writes. networkx
        # auto-falls-back to the legacy ``links`` key internally when
        # reading, but being explicit here pins the contract.
        graph = nx.node_link_graph(data, edges="edges")
    except (KeyError, TypeError, ValueError) as exc:
        print(
            f"wiki_graphify: prior graph.json rejected by node_link_graph "
            f"({exc}); full rebuild",
            flush=True,
        )
        return None
    if not isinstance(graph, nx.Graph):
        return None
    return graph


def patch_graph(
    prior: nx.Graph,
    *,
    current_node_info: dict[str, dict],
    target_edges: dict[tuple[str, str], dict],
    affected_node_ids: set[str],
) -> nx.Graph:
    """Mutate ``prior`` in-place to match the new graph state.

    Args:
        prior: the previous run's graph (from ``load_prior_graph``).
        current_node_info: ``{node_id: {label, type, tags}}`` for every
            node that should be in the new graph.
        target_edges: ``{(n1, n2): attr_dict}`` for the blended edge
            set produced by ``build_graph`` this run. Keys are
            canonicalised with ``n1 < n2``.
        affected_node_ids: nodes whose incident edges need to be
            refreshed (changed + new + contamination from Option B's
            partition). Edges where BOTH endpoints are outside this
            set are left untouched — they're guaranteed identical
            to the prior run.

    Returns the patched graph (same instance as ``prior``).
    """
    # Node-level delta.
    prior_ids = set(prior.nodes())
    current_ids = set(current_node_info.keys())
    removed_nodes = prior_ids - current_ids
    new_nodes = current_ids - prior_ids

    for nid in removed_nodes:
        prior.remove_node(nid)
    for nid in new_nodes:
        info = current_node_info[nid]
        prior.add_node(
            nid,
            label=info.get("label", nid.split(":", 1)[-1]),
            type=info.get("type", ""),
            tags=list(info.get("tags", [])),
        )
    # Refresh attrs on existing nodes (tags may have changed).
    for nid in current_ids & prior_ids:
        info = current_node_info[nid]
        prior.nodes[nid]["label"] = info.get("label", nid.split(":", 1)[-1])
        prior.nodes[nid]["type"] = info.get("type", prior.nodes[nid].get("type", ""))
        prior.nodes[nid]["tags"] = list(info.get("tags", []))

    # Edge delta — only touch edges incident on affected nodes.
    # Pairs where both endpoints are unaffected are guaranteed to
    # have the same blended weight (same semantic_sim from cache,
    # same tag/token overlap) and we skip them.
    affected = affected_node_ids | new_nodes | removed_nodes

    # Remove outdated edges incident on affected nodes. We collect
    # first, mutate after — avoids "dictionary changed size during
    # iteration" on Graph.edges view.
    to_remove: list[tuple[str, str]] = []
    for nid in affected:
        if nid not in prior:
            continue
        for neighbor in list(prior.neighbors(nid)):
            to_remove.append((nid, neighbor))
    for u, v in to_remove:
        if prior.has_edge(u, v):
            prior.remove_edge(u, v)

    # Re-add all target edges where at least one endpoint is affected.
    # Also re-add edges between unaffected-and-in-target pairs to
    # repair any drift — but that's a no-op because those edges
    # survived the remove step and are identical to the prior.
    added = 0
    for (n1, n2), attrs in target_edges.items():
        if n1 not in prior or n2 not in prior:
            continue
        if n1 in affected or n2 in affected:
            prior.add_edge(n1, n2, **attrs)
            added += 1

    print(
        f"patch_graph: removed={len(removed_nodes)} nodes + {len(to_remove)} edges; "
        f"added={len(new_nodes)} nodes + {added} edges; "
        f"untouched={prior.number_of_edges() - added} edges",
        flush=True,
    )
    return prior


def _build_delta(G: nx.Graph, delta_nodes: set[str]) -> dict:
    """Return a JSON-serializable dict of nodes + edges touching ``delta_nodes``.

    When ``delta_nodes`` is empty, returns a shell with ``"full_rebuild": true``
    so consumers know the whole ``graph.json`` is fresh.
    """
    if not delta_nodes:
        return {
            "version": 1,
            "full_rebuild": True,
            "generated": TODAY,
            "node_count": G.number_of_nodes(),
            "edge_count": G.number_of_edges(),
        }
    nodes_out: list[dict] = []
    edges_out: list[dict] = []
    for nid in delta_nodes:
        if nid not in G:
            continue
        attrs = dict(G.nodes[nid])
        nodes_out.append({"id": nid, **attrs})
        for neighbor in G.neighbors(nid):
            # Canonicalise so a neighbor listing doesn't produce
            # duplicates when both endpoints are in delta_nodes.
            u, v = (nid, neighbor) if nid < neighbor else (neighbor, nid)
            edge_attrs = dict(G[u][v])
            edges_out.append({"source": u, "target": v, **edge_attrs})
    # De-dup edges (a pair where both endpoints are in delta_nodes
    # would appear twice otherwise).
    seen: set[tuple[str, str]] = set()
    deduped_edges: list[dict] = []
    for e in edges_out:
        key = (e["source"], e["target"])
        if key in seen:
            continue
        seen.add(key)
        deduped_edges.append(e)
    return {
        "version": 1,
        "full_rebuild": False,
        "generated": TODAY,
        "delta_node_count": len(nodes_out),
        "delta_edge_count": len(deduped_edges),
        "graph_node_count": G.number_of_nodes(),
        "graph_edge_count": G.number_of_edges(),
        "nodes": nodes_out,
        "edges": deduped_edges,
    }


def filter_graph_by_min_cosine(G: nx.Graph, min_cosine: float) -> nx.Graph:
    """Return a subgraph view with semantic edges filtered at query time.

    Keeps an edge when ANY of the three signals justifies it:
      - ``semantic_sim`` >= ``min_cosine``, OR
      - ``tag_sim > 0`` (any shared explicit tag), OR
      - ``token_sim > 0`` (any shared slug token)

    This means tag/token-only connections survive any semantic
    threshold — only edges whose sole reason-to-exist is a below-
    threshold cosine disappear. That matches user intent: "show me
    only strong semantic links" shouldn't hide edges that are
    validated by explicit categorical overlap.

    Downstream consumers (resolve_graph, visualize, recommenders)
    should call this with ``cfg.graph_semantic_min_cosine`` at the
    top of their pipeline, then work with the filtered copy.

    Refuses to filter below the graph's build floor — that request
    would return a graph that doesn't contain edges it pretends to
    include at that threshold. The caller either regraphifies with
    a lower build_floor or raises the requested min_cosine.
    """
    build_floor = float(G.graph.get("semantic_build_floor", 0.0))
    if min_cosine < build_floor:
        raise ValueError(
            f"min_cosine ({min_cosine}) is below the graph's build_floor "
            f"({build_floor}); regraphify with a lower floor or raise "
            "min_cosine."
        )
    sub = nx.Graph()
    sub.graph.update(G.graph)
    sub.add_nodes_from(G.nodes(data=True))
    for n1, n2, attrs in G.edges(data=True):
        sem = float(attrs.get("semantic_sim", 0.0))
        tag = float(attrs.get("tag_sim", 0.0))
        tok = float(attrs.get("token_sim", 0.0))
        if sem >= min_cosine or tag > 0.0 or tok > 0.0:
            sub.add_edge(n1, n2, **attrs)
    return sub


def _attach_quality_attrs(G: nx.Graph, sidecar_dir: Path) -> int:
    """Decorate graph nodes with quality score + grade from sidecar JSONs.

    The sidecar directory is the source of truth for quality data; this
    function just mirrors ``quality_score`` and ``quality_grade`` onto
    matching graph nodes so downstream consumers (graph export, Obsidian
    graph view coloring) see one consistent number. Nodes without a
    sidecar keep their default values so the attribute is always present.

    Scans two roots:
      - ``<sidecar_dir>/*.json`` — skill + agent scores from
        ``skill_quality.persist_quality``
      - ``<sidecar_dir>/mcp/*.json`` — MCP scores from
        ``mcp_quality.persist_quality`` (Phase 4 separated MCP scores
        into a subdir so the MCP scorer's different signal-set
        doesn't pollute the flat skill/agent layout).
    """
    attached = 0
    # Default attrs so callers can always read the key without KeyError.
    for nid in G.nodes():
        G.nodes[nid].setdefault("quality_score", None)
        G.nodes[nid].setdefault("quality_grade", None)

    if not sidecar_dir.is_dir():
        return 0

    # Two roots to scan. The ``subject_type`` field in each sidecar
    # determines the graph node prefix — ``skill:`` or ``agent:`` for
    # the flat dir, ``mcp-server:`` for the mcp/ subdir. We don't infer
    # the prefix from the directory because the subject_type is the
    # canonical source of truth and some historical sidecars may have
    # landed in the wrong place.
    roots: list[Path] = [sidecar_dir]
    mcp_subdir = sidecar_dir / "mcp"
    if mcp_subdir.is_dir():
        roots.append(mcp_subdir)

    for root in roots:
        for path in root.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            slug = data.get("slug")
            subject_type = data.get("subject_type", "skill")
            if not slug:
                continue
            # MCP sidecars written by Phase 4 don't carry a
            # ``subject_type`` field (the McpQualityScore shape omits
            # it since the subdir is the type discriminator). When a
            # sidecar lives under mcp/ we treat it as mcp-server.
            if root == mcp_subdir and subject_type == "skill":
                subject_type = "mcp-server"
            node_id = f"{subject_type}:{slug}"
            if node_id not in G:
                continue
            G.nodes[node_id]["quality_score"] = float(data.get("score", 0.0))
            G.nodes[node_id]["quality_grade"] = data.get("grade")
            attached += 1
    return attached


def detect_communities(G: nx.Graph) -> dict[int, list[str]]:
    """Run community detection.

    Uses Louvain by default — it's near-linear in edge count and finishes
    on a 13K-node / 800K-edge graph in seconds. Falls back to the slower
    greedy-modularity (CNM) algorithm only if the env var
    ``CTX_GRAPH_COMMUNITY=cnm`` is set, since CNM is O(n²) on dense
    graphs and hangs on this dataset (~50min and counting was observed
    on 2026-04-27).
    """
    if G.number_of_nodes() == 0:
        return {}

    algo = os.environ.get("CTX_GRAPH_COMMUNITY", "louvain").lower()
    if algo == "cnm":
        communities_iter = greedy_modularity_communities(
            G, weight="weight", resolution=1.2,
        )
    else:
        # Louvain returns list[set[node]] directly. Resolution=1.2 to
        # match the CNM resolution we shipped previously, so cluster
        # granularity is comparable.
        # seed=42 fixed so output is reproducible across runs.
        communities_iter = louvain_communities(
            G, weight="weight", resolution=1.2, seed=42,
        )

    communities: dict[int, list[str]] = {}
    for i, community in enumerate(communities_iter):
        communities[i] = sorted(community)

    print(f"Communities: {len(communities)} detected (algo={algo})")
    for cid, members in sorted(communities.items(), key=lambda x: -len(x[1]))[:10]:
        print(f"  Community {cid}: {len(members)} members")
    return communities


def label_community(G: nx.Graph, members: list[str]) -> str:
    """Generate a human-readable label for a community based on dominant tags."""
    tag_counts: dict[str, int] = defaultdict(int)
    for nid in members:
        for tag in G.nodes[nid].get("tags", []):
            if tag != "uncategorized":
                tag_counts[tag] += 1

    if not tag_counts:
        return "Miscellaneous"

    top_tags = sorted(tag_counts.items(), key=lambda x: -x[1])[:3]
    return " + ".join(t[0].title() for t in top_tags)


def generate_concept_pages(
    G: nx.Graph,
    communities: dict[int, list[str]],
    dry_run: bool = False,
) -> list[str]:
    """Generate concept pages for each community."""
    CONCEPTS_DIR.mkdir(parents=True, exist_ok=True)
    created: list[str] = []

    # Reverse index: O(1) community lookup per neighbor instead of O(C) linear
    # scan through communities.items(). Reduces cross-edge loop from O(C²·members)
    # to O(C·members).
    node_to_community: dict[str, int] = {
        nid: cid for cid, members in communities.items() for nid in members
    }
    # Pre-compute community labels once to avoid redundant label_community calls
    community_labels: dict[int, str] = {
        cid: label_community(G, members) for cid, members in communities.items()
    }

    for cid, members in sorted(communities.items(), key=lambda x: -len(x[1])):
        if len(members) < 3:
            continue  # Skip tiny communities

        label = community_labels[cid]
        safe_name = label.lower().replace(" + ", "-").replace(" ", "-")
        filename = f"community-{safe_name}.md"

        # Top members by degree.
        #
        # Prior impl used ``'skills' if 'skill:' in m else 'agents'`` which
        # silently routed every ``mcp-server:`` node into ``entities/agents/``,
        # producing a sea of broken wikilinks once the MCP catalog was
        # ingested. Reuse _entity_wikilink which knows all three types
        # and the MCP shard layout.
        top_members = sorted(members, key=lambda n: G.degree(n), reverse=True)[:20]
        member_link_lines: list[str] = []
        for m in top_members:
            entity_type, _sep, slug = m.partition(":")
            link = _entity_wikilink(entity_type, slug)
            member_link_lines.append(f"- {link}" if link else f"- {m}")
        member_links = "\n".join(member_link_lines)
        remaining = len(members) - len(top_members)

        # Cross-community connections (O(neighbors) via reverse-index lookup)
        cross: dict[str, int] = defaultdict(int)
        members_set = set(members)
        for nid in members:
            for neighbor in G.neighbors(nid):
                if neighbor not in members_set:
                    other_cid = node_to_community.get(neighbor)
                    if other_cid is not None and other_cid != cid:
                        cross[community_labels[other_cid]] += 1

        cross_links = "\n".join(
            f"- {lbl} ({cnt} connections)"
            for lbl, cnt in sorted(cross.items(), key=lambda x: -x[1])[:8]
        )

        page = f"""---
title: "{label}"
created: {TODAY}
updated: {TODAY}
type: concept
community_id: {cid}
member_count: {len(members)}
tags: [{', '.join(t for t, _ in sorted(defaultdict(int, {t: c for m in members for t, c in [(tag, 1) for tag in G.nodes[m].get('tags', [])] if t != 'uncategorized'}).items(), key=lambda x: -x[1])[:5])}]
---

# {label}

> Auto-generated community of {len(members)} related skills and agents.

## Key Members

{member_links}
{f'*... and {remaining} more*' if remaining > 0 else ''}

## Cross-Community Connections

{cross_links if cross_links else '*No strong cross-community connections*'}

---

*Generated by wiki_graphify.py via community detection. See [[graphify-out/graph-report]] for full graph.*
"""
        if dry_run:
            print(f"  [DRY RUN] Would create: concepts/{filename}")
        else:
            safe_atomic_write_text(CONCEPTS_DIR / filename, page, encoding="utf-8")
        created.append(filename)

    print(f"Concept pages: {len(created)} created")
    return created


def _remove_graph_related_block(content: str) -> tuple[str, bool]:
    stripped, count = GRAPH_RELATED_BLOCK_RE.subn("\n", content)
    return re.sub(r"\n{3,}", "\n\n", stripped), bool(count)


def _render_graph_related_block(new_links: list[str]) -> str:
    return "\n".join([GRAPH_RELATED_START, *new_links, GRAPH_RELATED_END])


def inject_community_links(
    G: nx.Graph,
    communities: dict[int, list[str]],
    dry_run: bool = False,
) -> int:
    """Refresh graph-generated top-N neighbor wikilinks on entity pages."""
    updated = 0

    # Build node->community mapping
    node_community: dict[str, int] = {}
    for cid, members in communities.items():
        for nid in members:
            node_community[nid] = cid

    for nid, data in G.nodes(data=True):
        entity_type = data.get("type", "skill")
        name = data.get("label", nid.split(":", 1)[-1])
        page_path = _entity_page_path(entity_type, name)

        if page_path is None or not page_path.exists():
            continue

        original_content = page_path.read_text(encoding="utf-8", errors="replace")
        content, had_generated_block = _remove_graph_related_block(original_content)

        # Find top neighbors by edge weight
        neighbors = sorted(
            G.neighbors(nid),
            key=lambda n: G[nid][n].get("weight", 1),
            reverse=True,
        )[:6]

        new_links: list[str] = []
        for neighbor in neighbors:
            n_type = G.nodes[neighbor].get("type", "skill")
            n_name = G.nodes[neighbor].get("label", neighbor.split(":", 1)[-1])
            link = _entity_wikilink(n_type, n_name)
            if link is None or link in content:
                continue
            new_links.append(f"- {link}")

        if not new_links and not had_generated_block:
            continue

        # Refresh only ctx's generated block. Manual links in the same
        # section stay untouched and prevent duplicates.
        section_header = _related_section_header(entity_type)
        insert_text = _render_graph_related_block(new_links) if new_links else ""
        if new_links and section_header in content:
            content = content.replace(
                section_header + "\n",
                section_header + "\n" + insert_text + "\n",
                1,
            )
        elif new_links:
            content = content.rstrip() + f"\n\n{section_header}\n" + insert_text + "\n"

        if content == original_content:
            continue

        if not dry_run:
            safe_atomic_write_text(page_path, content, encoding="utf-8")
        updated += 1

    print(f"Entity pages updated with graph-based wikilinks: {updated}")
    return updated


def export_graph(
    G: nx.Graph,
    communities: dict[int, list[str]],
    *,
    delta_nodes: set[str] | None = None,
) -> None:
    """Export graph as JSON (+ pickle for patch-incremental reruns).

    ``delta_nodes``, when provided, is the set of node IDs that the
    incremental path touched — we also write a ``graph-delta.json``
    containing only those nodes and their incident edges so downstream
    consumers can ingest just the change rather than re-read 130MB.
    """
    GRAPH_OUT.mkdir(parents=True, exist_ok=True)

    # Export graph as node-link JSON. Pin the edges key so readers
    # (resolve_graph, wiki_visualize) can rely on it regardless of the
    # networkx version that wrote it — default changed from "links" in
    # <3.0 to "edges" in >=3.0, which silently broke every consumer.
    graph_data = nx.node_link_data(G, edges="edges")
    safe_atomic_write_text(
        GRAPH_OUT / "graph.json",
        json.dumps(graph_data, indent=2, default=str),
        encoding="utf-8",
    )

    # No binary sidecar. An earlier revision wrote ``graph.pickle`` next
    # to this JSON for faster incremental loads, but pickle.loads is an
    # RCE primitive — security-auditor finding C-1 (fixed). The JSON
    # parse overhead (~3s at 13k nodes / 850k edges) is acceptable for
    # the once-per-regraphify load path. ``load_prior_graph`` reads
    # graph.json directly.

    # Delta export — only the nodes touched this run + their incident
    # edges. Written unconditionally (empty when the full run produced
    # the graph from scratch) so downstream consumers can always
    # stat a single file to detect changes.
    delta = _build_delta(G, delta_nodes or set())
    safe_atomic_write_text(
        GRAPH_OUT / "graph-delta.json",
        json.dumps(delta, indent=2, default=str),
        encoding="utf-8",
    )

    # Community labels
    labels = {}
    for cid, members in communities.items():
        labels[cid] = label_community(G, members)

    safe_atomic_write_text(
        GRAPH_OUT / "communities.json",
        json.dumps({
            "communities": {str(cid): {"label": labels[cid], "members": members}
                           for cid, members in communities.items()},
            "total_communities": len(communities),
            "generated": TODAY,
        }, indent=2),
        encoding="utf-8",
    )

    # God nodes (highest degree)
    god_nodes = sorted(G.nodes(), key=lambda n: G.degree(n), reverse=True)[:20]
    report_lines = [
        "# Graph Report",
        "",
        f"> Generated: {TODAY}",
        f"> Nodes: {G.number_of_nodes()} | Edges: {G.number_of_edges()} | Communities: {len(communities)}",
        "",
        "## God Nodes (Most Connected)",
        "",
    ]
    for nid in god_nodes:
        d = G.nodes[nid]
        report_lines.append(f"- **{d.get('label', nid)}** ({G.degree(nid)} connections) — {d.get('type', '?')}")

    report_lines += ["", "## Communities (by size)", ""]
    for cid, members in sorted(communities.items(), key=lambda x: -len(x[1])):
        report_lines.append(f"- **{labels[cid]}** — {len(members)} members")

    safe_atomic_write_text(
        GRAPH_OUT / "graph-report.md",
        "\n".join(report_lines),
        encoding="utf-8",
    )
    print(f"Graph exported to {GRAPH_OUT}/")


def main() -> None:
    parser = argparse.ArgumentParser(description="Build knowledge graph from wiki entities")
    parser.add_argument(
        "--wiki-dir",
        type=Path,
        default=None,
        help="Wiki root to graphify (default: ~/.claude/skill-wiki)",
    )
    parser.add_argument("--graph-only", action="store_true", help="Build graph and export only")
    parser.add_argument("--dry-run", action="store_true", help="Preview without writing")
    # Incremental vs full: incremental reuses the prior run's per-node
    # top-K where the entity text hasn't changed. Full forces a top-K
    # recompute for every node (but still honors the embedding cache,
    # so the embedding pass is only expensive on first run or after a
    # model/text change).
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--incremental", dest="incremental", action="store_true",
        default=True,
        help="Reuse prior top-K for unchanged nodes (default)",
    )
    mode.add_argument(
        "--full", dest="incremental", action="store_false",
        help="Force a full top-K recompute for every node",
    )
    args = parser.parse_args()

    if args.wiki_dir is not None:
        configure_wiki_dir(args.wiki_dir)

    affected: set[str] = set()
    G, entities = build_graph(
        incremental=args.incremental, _affected_out=affected,
    )
    communities = detect_communities(G)
    export_graph(G, communities, delta_nodes=affected)

    if args.graph_only:
        return

    generate_concept_pages(G, communities, args.dry_run)
    inject_community_links(G, communities, args.dry_run)

    print("\nDone. Open wiki in Obsidian to see the graph visualization.")


if __name__ == "__main__":
    main()
