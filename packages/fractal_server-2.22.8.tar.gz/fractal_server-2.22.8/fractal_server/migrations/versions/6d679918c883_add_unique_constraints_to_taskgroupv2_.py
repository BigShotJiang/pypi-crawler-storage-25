"""Add unique constraints to TaskGroupV2 and TaskGroupActivityV2

Revision ID: 6d679918c883
Revises: cfd13f7954e7
Create Date: 2026-02-16 09:55:16.390386

"""

import sqlalchemy as sa
from alembic import op

# revision identifiers, used by Alembic.
revision = "6d679918c883"
down_revision = "cfd13f7954e7"
branch_labels = None
depends_on = None


def upgrade() -> None:
    with op.batch_alter_table("taskgroupactivityv2", schema=None) as batch_op:
        batch_op.create_index(
            "ix_taskgroupactivityv2_collect_unique_constraint",
            ["taskgroupv2_id"],
            unique=True,
            postgresql_where=sa.text("action = 'collect'"),
        )

    with op.batch_alter_table("taskgroupv2", schema=None) as batch_op:
        batch_op.create_index(
            "ix_taskgroupv2_path_unique_constraint",
            ["path", "resource_id"],
            unique=True,
        )


def downgrade() -> None:
    with op.batch_alter_table("taskgroupv2", schema=None) as batch_op:
        batch_op.drop_index("ix_taskgroupv2_path_unique_constraint")

    with op.batch_alter_table("taskgroupactivityv2", schema=None) as batch_op:
        batch_op.drop_index(
            "ix_taskgroupactivityv2_collect_unique_constraint",
            postgresql_where=sa.text("action = 'collect'"),
        )
