"""
v2 `models` module
"""

from fractal_server.app.models.linkuserproject import LinkUserProjectV2

from .accounting import AccountingRecord
from .accounting import AccountingRecordSlurm
from .dataset import DatasetV2
from .history import HistoryImageCache
from .history import HistoryRun
from .history import HistoryUnit
from .job import JobV2
from .profile import Profile
from .project import ProjectV2
from .resource import Resource
from .task import TaskV2
from .task_group import TaskGroupActivityV2
from .task_group import TaskGroupV2
from .workflow import WorkflowV2
from .workflow_template import WorkflowTemplate
from .workflowtask import WorkflowTaskV2

__all__ = [
    "AccountingRecord",
    "AccountingRecordSlurm",
    "LinkUserProjectV2",
    "DatasetV2",
    "JobV2",
    "ProjectV2",
    "TaskGroupV2",
    "TaskGroupActivityV2",
    "TaskV2",
    "WorkflowV2",
    "WorkflowTaskV2",
    "WorkflowTemplate",
    "HistoryRun",
    "HistoryUnit",
    "HistoryImageCache",
    "Resource",
    "Profile",
]
