from typing import Any

from fastapi import APIRouter
from fastapi import Depends
from fastapi import HTTPException
from fastapi import Response
from fastapi import status
from sqlmodel import func
from sqlmodel import select

from fractal_server.app.db import AsyncSession
from fractal_server.app.db import get_async_db
from fractal_server.app.models import UserOAuth
from fractal_server.app.models.linkuserproject import LinkUserProjectV2
from fractal_server.app.models.v2 import DatasetV2
from fractal_server.app.models.v2 import JobV2
from fractal_server.app.models.v2.project import ProjectV2
from fractal_server.app.routes.auth import get_api_guest
from fractal_server.app.routes.auth import get_api_user
from fractal_server.app.routes.pagination import PaginationRequest
from fractal_server.app.routes.pagination import PaginationResponse
from fractal_server.app.routes.pagination import get_pagination_data
from fractal_server.app.routes.pagination import get_pagination_params
from fractal_server.app.schemas.v2 import DatasetCreate
from fractal_server.app.schemas.v2 import DatasetRead
from fractal_server.app.schemas.v2 import DatasetReadExpanded
from fractal_server.app.schemas.v2 import DatasetUpdate
from fractal_server.app.schemas.v2.dataset import DatasetExport
from fractal_server.app.schemas.v2.dataset import DatasetImport
from fractal_server.app.schemas.v2.sharing import ProjectPermissions
from fractal_server.string_tools import sanitize_string
from fractal_server.urls import normalize_url
from fractal_server.urls import url_is_relative_to
from fractal_server.urls import url_join

from ._aux_functions import _get_dataset_check_access
from ._aux_functions import _get_project_check_access
from ._aux_functions import _get_submitted_jobs_statement

router = APIRouter()


@router.post(
    "/project/{project_id}/dataset/",
    response_model=DatasetRead,
    status_code=status.HTTP_201_CREATED,
)
async def create_dataset(
    project_id: int,
    dataset: DatasetCreate,
    user: UserOAuth = Depends(get_api_user),
    db: AsyncSession = Depends(get_async_db),
) -> DatasetV2:
    """
    Add new dataset to current project
    """
    project = await _get_project_check_access(
        project_id=project_id,
        user_id=user.id,
        required_permissions=ProjectPermissions.WRITE,
        db=db,
    )

    db_dataset = DatasetV2(
        project_id=project_id,
        zarr_dir="__PLACEHOLDER__",
        **dataset.model_dump(exclude={"project_dir", "zarr_subfolder"}),
    )
    db.add(db_dataset)
    await db.commit()
    await db.refresh(db_dataset)

    if dataset.project_dir is None:
        project_dir = user.project_dirs[0]
    else:
        if dataset.project_dir not in user.project_dirs:
            await db.delete(db_dataset)
            await db.commit()
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"You are not allowed to use {dataset.project_dir=}.",
            )
        project_dir = dataset.project_dir

    if dataset.zarr_subfolder is None:
        zarr_subfolder = (
            f"fractal/{project_id}_{sanitize_string(project.name)}/"
            f"{db_dataset.id}_{sanitize_string(db_dataset.name)}"
        )
    else:
        zarr_subfolder = dataset.zarr_subfolder

    zarr_dir = url_join(project_dir, zarr_subfolder)
    db_dataset.zarr_dir = normalize_url(zarr_dir)

    db.add(db_dataset)
    await db.commit()
    await db.refresh(db_dataset)

    return db_dataset


@router.get(
    "/project/{project_id}/dataset/",
    response_model=list[DatasetRead],
)
async def read_dataset_list(
    project_id: int,
    user: UserOAuth = Depends(get_api_guest),
    db: AsyncSession = Depends(get_async_db),
) -> list[DatasetV2]:
    """
    Get dataset list for given project
    """
    # Access control
    project = await _get_project_check_access(
        project_id=project_id,
        user_id=user.id,
        required_permissions=ProjectPermissions.READ,
        db=db,
    )
    stm = select(DatasetV2).where(DatasetV2.project_id == project.id)
    res = await db.execute(stm)
    dataset_list = res.scalars().all()
    return dataset_list


@router.get(
    "/project/{project_id}/dataset/{dataset_id}/",
    response_model=DatasetRead,
)
async def read_dataset(
    project_id: int,
    dataset_id: int,
    user: UserOAuth = Depends(get_api_guest),
    db: AsyncSession = Depends(get_async_db),
) -> DatasetV2:
    """
    Get info on a dataset associated to the current project
    """
    output = await _get_dataset_check_access(
        project_id=project_id,
        dataset_id=dataset_id,
        user_id=user.id,
        required_permissions=ProjectPermissions.READ,
        db=db,
    )
    dataset = output["dataset"]
    return dataset


@router.patch(
    "/project/{project_id}/dataset/{dataset_id}/",
    response_model=DatasetRead,
)
async def update_dataset(
    project_id: int,
    dataset_id: int,
    dataset_update: DatasetUpdate,
    user: UserOAuth = Depends(get_api_user),
    db: AsyncSession = Depends(get_async_db),
) -> DatasetV2:
    """
    Edit a dataset associated to the current project
    """

    output = await _get_dataset_check_access(
        project_id=project_id,
        dataset_id=dataset_id,
        user_id=user.id,
        required_permissions=ProjectPermissions.WRITE,
        db=db,
    )
    db_dataset = output["dataset"]

    for key, value in dataset_update.model_dump(exclude_unset=True).items():
        setattr(db_dataset, key, value)

    await db.commit()
    await db.refresh(db_dataset)
    return db_dataset


@router.delete(
    "/project/{project_id}/dataset/{dataset_id}/",
    status_code=204,
)
async def delete_dataset(
    project_id: int,
    dataset_id: int,
    user: UserOAuth = Depends(get_api_user),
    db: AsyncSession = Depends(get_async_db),
) -> Response:
    """
    Delete a dataset associated to the current project
    """
    output = await _get_dataset_check_access(
        project_id=project_id,
        dataset_id=dataset_id,
        user_id=user.id,
        required_permissions=ProjectPermissions.WRITE,
        db=db,
    )
    dataset = output["dataset"]

    # Fail if there exist jobs that are submitted and in relation with the
    # current dataset.
    stm = _get_submitted_jobs_statement().where(JobV2.dataset_id == dataset_id)
    res = await db.execute(stm)
    jobs = res.scalars().all()
    if jobs:
        string_ids = str([job.id for job in jobs])[1:-1]
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=(
                f"Cannot delete dataset {dataset.id} because it "
                f"is linked to active job(s) {string_ids}."
            ),
        )

    # Delete dataset
    await db.delete(dataset)
    await db.commit()

    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.get(
    "/project/{project_id}/dataset/{dataset_id}/export/",
    response_model=DatasetExport,
)
async def export_dataset(
    project_id: int,
    dataset_id: int,
    user: UserOAuth = Depends(get_api_guest),
    db: AsyncSession = Depends(get_async_db),
) -> DatasetV2:
    """
    Export an existing dataset
    """
    dict_dataset_project = await _get_dataset_check_access(
        project_id=project_id,
        dataset_id=dataset_id,
        user_id=user.id,
        required_permissions=ProjectPermissions.READ,
        db=db,
    )
    dataset = dict_dataset_project["dataset"]

    return dataset


@router.post(
    "/project/{project_id}/dataset/import/",
    response_model=DatasetRead,
    status_code=status.HTTP_201_CREATED,
)
async def import_dataset(
    project_id: int,
    dataset: DatasetImport,
    user: UserOAuth = Depends(get_api_user),
    db: AsyncSession = Depends(get_async_db),
) -> DatasetV2:
    """
    Import an existing dataset into a project
    """

    # Preliminary checks
    await _get_project_check_access(
        project_id=project_id,
        user_id=user.id,
        required_permissions=ProjectPermissions.WRITE,
        db=db,
    )

    if not any(
        url_is_relative_to(url=dataset.zarr_dir, base=project_dir)
        for project_dir in user.project_dirs
    ):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=(
                f"{dataset.zarr_dir=} is not relative to any of user's project "
                "dirs."
            ),
        )

    # Create new Dataset
    db_dataset = DatasetV2(
        project_id=project_id,
        **dataset.model_dump(exclude_none=True),
    )
    db.add(db_dataset)
    await db.commit()
    await db.refresh(db_dataset)

    return db_dataset


@router.get("/dataset/", response_model=PaginationResponse[DatasetReadExpanded])
async def get_all_datasets(
    project_name: str | None = None,
    dataset_name: str | None = None,
    only_owned: bool = False,
    user: UserOAuth = Depends(get_api_guest),
    db: AsyncSession = Depends(get_async_db),
    pagination: PaginationRequest = Depends(get_pagination_params),
) -> dict[str, Any]:
    stm = (
        select(
            DatasetV2,
            (
                select(UserOAuth.email)
                .join(
                    LinkUserProjectV2,
                    UserOAuth.id == LinkUserProjectV2.user_id,
                )
                .where(
                    LinkUserProjectV2.project_id == DatasetV2.project_id,
                    LinkUserProjectV2.is_owner.is_(True),
                )
                .scalar_subquery()
                .correlate(DatasetV2)
            ),
            func.jsonb_array_length(DatasetV2.images),
        )
        .join(ProjectV2, DatasetV2.project_id == ProjectV2.id)
        .join(LinkUserProjectV2, LinkUserProjectV2.project_id == ProjectV2.id)
        .where(LinkUserProjectV2.user_id == user.id)
        .order_by(DatasetV2.timestamp_created.desc())
    )
    stm_count = (
        select(func.count(DatasetV2.id))
        .join(LinkUserProjectV2, LinkUserProjectV2.user_id == user.id)
        .join(ProjectV2, ProjectV2.id == LinkUserProjectV2.project_id)
        .where(DatasetV2.project_id == ProjectV2.id)
    )

    if project_name is not None:
        stm = stm.where(ProjectV2.name.icontains(project_name))
        stm_count = stm_count.where(ProjectV2.name.icontains(project_name))
    if only_owned is True:
        stm = stm.where(LinkUserProjectV2.is_owner.is_(True))
        stm_count = stm_count.where(LinkUserProjectV2.is_owner.is_(True))
    if dataset_name is not None:
        stm = stm.where(DatasetV2.name.icontains(dataset_name))
        stm_count = stm_count.where(DatasetV2.name.icontains(dataset_name))

    stm, pagination_data = await get_pagination_data(
        stm=stm,
        stm_count=stm_count,
        pagination=pagination,
        db=db,
    )

    res = await db.execute(stm)
    records = res.all()

    return dict(
        items=[
            dict(
                image_count=image_count,
                owner_email=owner_email,
                project=dataset.project.model_dump(),
                **dataset.model_dump(),
            )
            for dataset, owner_email, image_count in records
        ],
        **pagination_data.model_dump(),
    )
