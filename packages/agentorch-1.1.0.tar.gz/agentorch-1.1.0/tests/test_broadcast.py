import asyncio
import json
import time
from pathlib import Path

import pytest

from devtorch_core.broadcast.broadcaster import EventBroadcaster, _is_coordination_event
from devtorch_core.broadcast.watcher import GCCWatcher


# ── _is_coordination_event ──────────────────────────────────────────────────

def test_coordination_filter_divergence():
    assert _is_coordination_event("DIVERGENCE_DETECTED") is True

def test_coordination_filter_hitl():
    assert _is_coordination_event("HITL_REQUEST") is True

def test_coordination_filter_consolidation():
    assert _is_coordination_event("CONSOLIDATION_STARTED") is True

def test_coordination_filter_consensus():
    assert _is_coordination_event("CONSENSUS_RESOLVED") is True

def test_coordination_filter_sensitivity_excluded():
    assert _is_coordination_event("SENSITIVITY_ADDED") is False

def test_coordination_filter_commit_excluded():
    assert _is_coordination_event("COMMIT") is False


# ── EventBroadcaster ────────────────────────────────────────────────────────

def test_broadcaster_publish_to_subscriber():
    b = EventBroadcaster()
    q = b.subscribe()
    b.publish({"event_type": "DIVERGENCE_DETECTED", "concept": "auth"})
    assert not q.empty()
    item = q.get_nowait()
    assert item["concept"] == "auth"

def test_broadcaster_filters_non_coordination():
    b = EventBroadcaster()
    q = b.subscribe()
    b.publish({"event_type": "SENSITIVITY_ADDED", "concept": "auth"})
    assert q.empty()

def test_broadcaster_unsubscribe():
    b = EventBroadcaster()
    q = b.subscribe()
    b.unsubscribe(q)
    b.publish({"event_type": "DIVERGENCE_DETECTED"})
    assert q.empty()

def test_broadcaster_multiple_subscribers():
    b = EventBroadcaster()
    q1, q2 = b.subscribe(), b.subscribe()
    b.publish({"event_type": "HITL_REQUEST"})
    assert not q1.empty()
    assert not q2.empty()


# ── GCCWatcher ──────────────────────────────────────────────────────────────

def test_watcher_picks_up_new_coordination_line(tmp_path):
    log = tmp_path / "events.log.jsonl"
    log.write_text("")
    b = EventBroadcaster()
    q = b.subscribe()
    watcher = GCCWatcher(tmp_path, b, poll_interval=0.05)
    watcher.start()
    try:
        event = {"event_type": "DIVERGENCE_DETECTED", "concept": "auth"}
        with log.open("a") as f:
            f.write(json.dumps(event) + "\n")
        deadline = time.monotonic() + 2.0
        while q.empty() and time.monotonic() < deadline:
            time.sleep(0.02)
        assert not q.empty()
        item = q.get_nowait()
        assert item["concept"] == "auth"
    finally:
        watcher.stop()

def test_watcher_ignores_non_coordination_lines(tmp_path):
    log = tmp_path / "events.log.jsonl"
    log.write_text("")
    b = EventBroadcaster()
    q = b.subscribe()
    watcher = GCCWatcher(tmp_path, b, poll_interval=0.05)
    watcher.start()
    try:
        event = {"event_type": "SENSITIVITY_ADDED", "concept": "auth"}
        with log.open("a") as f:
            f.write(json.dumps(event) + "\n")
        time.sleep(0.3)
        assert q.empty()
    finally:
        watcher.stop()

def test_watcher_stop_is_clean(tmp_path):
    b = EventBroadcaster()
    watcher = GCCWatcher(tmp_path, b, poll_interval=0.05)
    watcher.start()
    watcher.stop()
    assert watcher._thread is None
