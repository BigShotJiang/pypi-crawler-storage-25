from __future__ import annotations
import hashlib
import json
import time
import pytest
from unittest.mock import MagicMock, patch
from fastapi import FastAPI
from fastapi.testclient import TestClient
from devtorch_core.mcp.auth import APIKeyMiddleware, OAuthMiddleware

try:
    import jwt as _jwt
    import cryptography  # noqa: F401
    _JWT_AVAILABLE = True
except ImportError:
    _JWT_AVAILABLE = False

pytestmark_jwt = pytest.mark.skipif(not _JWT_AVAILABLE, reason="PyJWT + cryptography not installed")


def _make_app_with_apikey(api_keys: dict) -> TestClient:
    """Build a minimal FastAPI app with APIKeyMiddleware and a fake R2 backend."""
    backend = MagicMock()
    backend.read_bytes.return_value = json.dumps(api_keys).encode()

    app = FastAPI()
    app.add_middleware(APIKeyMiddleware, backend=backend)

    @app.get("/{org_id}/{repo_id}/ping")
    def ping(org_id: str, repo_id: str):
        return {"ok": True}

    return TestClient(app, raise_server_exceptions=False)


def test_api_key_valid() -> None:
    raw_key = "secret123"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    keys = {key_hash: {"org_id": "acme", "allowed_repos": None}}
    client = _make_app_with_apikey(keys)
    resp = client.get("/acme/repo1/ping", headers={"X-DevTorch-Key": raw_key})
    assert resp.status_code == 200


def test_api_key_missing_returns_401() -> None:
    client = _make_app_with_apikey({})
    resp = client.get("/acme/repo1/ping")
    assert resp.status_code == 401


def test_api_key_wrong_returns_401() -> None:
    raw_key = "correct"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    keys = {key_hash: {"org_id": "acme", "allowed_repos": None}}
    client = _make_app_with_apikey(keys)
    resp = client.get("/acme/repo1/ping", headers={"X-DevTorch-Key": "wrong"})
    assert resp.status_code == 401


def test_api_key_wrong_org_returns_403() -> None:
    raw_key = "secret"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    keys = {key_hash: {"org_id": "acme", "allowed_repos": None}}
    client = _make_app_with_apikey(keys)
    resp = client.get("/other/repo1/ping", headers={"X-DevTorch-Key": raw_key})
    assert resp.status_code == 403


def test_api_key_repo_allowlist_blocks_unlisted_repo() -> None:
    raw_key = "secret"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    keys = {key_hash: {"org_id": "acme", "allowed_repos": ["allowed-repo"]}}
    client = _make_app_with_apikey(keys)
    resp = client.get("/acme/blocked-repo/ping", headers={"X-DevTorch-Key": raw_key})
    assert resp.status_code == 403


def test_api_key_repo_allowlist_permits_listed_repo() -> None:
    raw_key = "secret"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    keys = {key_hash: {"org_id": "acme", "allowed_repos": ["allowed-repo"]}}
    client = _make_app_with_apikey(keys)
    resp = client.get("/acme/allowed-repo/ping", headers={"X-DevTorch-Key": raw_key})
    assert resp.status_code == 200


def test_api_key_short_path_returns_403() -> None:
    """A valid key on a path with < 2 segments must be rejected (not bypass auth)."""
    raw_key = "secret"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
    keys = {key_hash: {"org_id": "acme", "allowed_repos": None}}

    backend = MagicMock()
    backend.read_bytes.return_value = json.dumps(keys).encode()

    app = FastAPI()
    app.add_middleware(APIKeyMiddleware, backend=backend)

    @app.get("/ping")
    def ping():
        return {"ok": True}

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.get("/ping", headers={"X-DevTorch-Key": raw_key})
    assert resp.status_code == 403


@pytestmark_jwt
def test_oauth_valid_jwt() -> None:
    import jwt
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.backends import default_backend

    private_key = rsa.generate_private_key(65537, 2048, default_backend())
    public_key = private_key.public_key()

    token = jwt.encode(
        {"sub": "user1", "org": "acme", "exp": int(time.time()) + 3600},
        private_key,
        algorithm="RS256",
        headers={"kid": "test-key-1"},
    )

    with patch.object(OAuthMiddleware, "_get_key", return_value=public_key):
        app = FastAPI()
        app.add_middleware(OAuthMiddleware, jwks_urls=[])

        @app.get("/{org_id}/{repo_id}/ping")
        def ping(org_id: str, repo_id: str):
            return {"ok": True}

        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get("/acme/repo1/ping", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 200


@pytestmark_jwt
def test_oauth_missing_token_returns_401() -> None:
    app = FastAPI()
    app.add_middleware(OAuthMiddleware, jwks_urls=[])

    @app.get("/{org_id}/{repo_id}/ping")
    def ping(org_id: str, repo_id: str):
        return {"ok": True}

    client = TestClient(app, raise_server_exceptions=False)
    resp = client.get("/acme/repo1/ping")
    assert resp.status_code == 401


@pytestmark_jwt
def test_oauth_expired_token_returns_401() -> None:
    import jwt
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.backends import default_backend

    private_key = rsa.generate_private_key(65537, 2048, default_backend())
    public_key = private_key.public_key()

    token = jwt.encode(
        {"sub": "user1", "org": "acme", "exp": int(time.time()) - 10},
        private_key,
        algorithm="RS256",
        headers={"kid": "test-key-1"},
    )

    with patch.object(OAuthMiddleware, "_get_key", return_value=public_key):
        app = FastAPI()
        app.add_middleware(OAuthMiddleware, jwks_urls=[])

        @app.get("/{org_id}/{repo_id}/ping")
        def ping(org_id: str, repo_id: str):
            return {"ok": True}

        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get("/acme/repo1/ping", headers={"Authorization": f"Bearer {token}"})
        assert resp.status_code == 401
