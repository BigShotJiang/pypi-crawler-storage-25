import pytest
from devtorch_core.rep_network.merge import merge_theta


def _make_theta(concepts: dict) -> dict:
    """Helper: build a theta dict from {concept: (count, confidence, level)}."""
    cv = {
        c: {"event_count": cnt, "mean_confidence": conf, "disclosure_level": lvl,
            "last_updated": "2026-05-01T00:00:00+00:00"}
        for c, (cnt, conf, lvl) in concepts.items()
    }
    return {"version": 1, "updated_at": "2026-05-01T00:00:00+00:00",
            "coordination_vector": cv}


def test_merge_sums_event_counts():
    local = _make_theta({"auth": (3, 0.7, "PUBLIC")})
    remote = _make_theta({"auth": (5, 0.9, "PUBLIC")})
    result = merge_theta(local, remote)
    assert result["coordination_vector"]["auth"]["event_count"] == 8


def test_merge_weighted_mean_confidence():
    # local: 3 events at 0.6; remote: 7 events at 0.9 → (3*0.6 + 7*0.9)/10 = 0.81
    local = _make_theta({"auth": (3, 0.6, "PUBLIC")})
    remote = _make_theta({"auth": (7, 0.9, "PUBLIC")})
    result = merge_theta(local, remote)
    assert abs(result["coordination_vector"]["auth"]["mean_confidence"] - 0.81) < 1e-5


def test_merge_takes_max_disclosure_level():
    local = _make_theta({"auth": (2, 0.8, "PUBLIC")})
    remote = _make_theta({"auth": (2, 0.8, "PRIVATE")})
    result = merge_theta(local, remote)
    assert result["coordination_vector"]["auth"]["disclosure_level"] == "PRIVATE"


def test_merge_union_of_concepts():
    local = _make_theta({"auth": (2, 0.7, "PUBLIC")})
    remote = _make_theta({"schema": (4, 0.6, "PROTECTED")})
    result = merge_theta(local, remote)
    assert "auth" in result["coordination_vector"]
    assert "schema" in result["coordination_vector"]


def test_merge_concept_only_in_local():
    local = _make_theta({"auth": (3, 0.8, "PROTECTED")})
    remote = {"version": 1, "updated_at": "", "coordination_vector": {}}
    result = merge_theta(local, remote)
    cv = result["coordination_vector"]["auth"]
    assert cv["event_count"] == 3
    assert cv["disclosure_level"] == "PROTECTED"


def test_merge_empty_local():
    local = {"version": 1, "updated_at": "", "coordination_vector": {}}
    remote = _make_theta({"pii": (10, 0.95, "PRIVATE")})
    result = merge_theta(local, remote)
    assert result["coordination_vector"]["pii"]["event_count"] == 10


def test_merge_idempotent():
    """Merging a theta with itself doubles counts but is otherwise consistent."""
    t = _make_theta({"auth": (4, 0.75, "PROTECTED")})
    result = merge_theta(t, t)
    assert result["coordination_vector"]["auth"]["event_count"] == 8
    assert abs(result["coordination_vector"]["auth"]["mean_confidence"] - 0.75) < 1e-5


def test_merge_latest_timestamp_wins():
    local = _make_theta({"auth": (1, 0.5, "PUBLIC")})
    local["coordination_vector"]["auth"]["last_updated"] = "2026-05-10T00:00:00+00:00"
    remote = _make_theta({"auth": (1, 0.5, "PUBLIC")})
    remote["coordination_vector"]["auth"]["last_updated"] = "2026-05-12T00:00:00+00:00"
    result = merge_theta(local, remote)
    assert result["coordination_vector"]["auth"]["last_updated"] == "2026-05-12T00:00:00+00:00"
