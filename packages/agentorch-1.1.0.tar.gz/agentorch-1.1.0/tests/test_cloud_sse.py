# tests/test_cloud_sse.py
from __future__ import annotations
import json
import pytest
from unittest.mock import MagicMock
from fastapi.testclient import TestClient
from devtorch_core.mcp.server import build_sse_app


def _mock_repo() -> MagicMock:
    repo = MagicMock()
    repo.commit.return_value = None
    repo.get_theta.return_value = {"coordination_vector": {"auth": {"mean": 0.8}}}
    repo.context_bundle.return_value = {"artifacts": []}
    return repo


def _make_client(repo: MagicMock) -> TestClient:
    app = build_sse_app(repo_factory=lambda org, repo_id: repo)
    return TestClient(app, raise_server_exceptions=False)


@pytest.mark.anyio
async def test_sse_endpoint_returns_200() -> None:
    """Test the SSE endpoint returns 200 with text/event-stream content-type.

    Uses a direct ASGI call to avoid httpx TestClient's sync buffering, which
    deadlocks on infinite streaming responses in Starlette 1.x.
    """
    import asyncio

    repo = _mock_repo()
    app = build_sse_app(repo_factory=lambda org, repo_id: repo)

    scope = {
        "type": "http",
        "asgi": {"version": "3.0", "spec_version": "2.4"},  # use simple path
        "http_version": "1.1",
        "method": "GET",
        "path": "/acme/repo1/sse",
        "raw_path": b"/acme/repo1/sse",
        "query_string": b"",
        "root_path": "",
        "headers": [(b"host", b"testserver")],
        "server": ("testserver", 80),
        "client": ("testclient", 50000),
    }

    status_code: int | None = None
    response_headers: list[tuple[bytes, bytes]] = []

    class _StopAfterHeaders(Exception):
        pass

    async def receive():  # type: ignore[return]
        await asyncio.sleep(9999)

    async def send(message: dict) -> None:
        nonlocal status_code, response_headers
        if message["type"] == "http.response.start":
            status_code = message["status"]
            response_headers = message.get("headers", [])
            raise _StopAfterHeaders()

    try:
        await app(scope, receive, send)
    except (_StopAfterHeaders, Exception):
        pass

    assert status_code == 200
    content_type = dict(response_headers).get(b"content-type", b"")
    assert b"text/event-stream" in content_type


def test_messages_unknown_session_returns_404() -> None:
    repo = _mock_repo()
    client = _make_client(repo)
    resp = client.post(
        "/acme/repo1/messages?sessionId=nonexistent",
        json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
    )
    assert resp.status_code == 404


def test_tools_list_via_messages() -> None:
    repo = _mock_repo()
    app = build_sse_app(repo_factory=lambda org, repo_id: repo)

    import asyncio
    import uuid
    from devtorch_core.mcp.server import _session_queues

    session_id = str(uuid.uuid4())
    queue: asyncio.Queue = asyncio.Queue()
    _session_queues[session_id] = (queue, repo)

    try:
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.post(
            f"/acme/repo1/messages?sessionId={session_id}",
            json={"jsonrpc": "2.0", "id": 1, "method": "tools/list", "params": {}},
        )
        assert resp.status_code == 202

        assert not queue.empty()
        item = queue.get_nowait()
        assert "tools" in item["result"]
    finally:
        _session_queues.pop(session_id, None)
