import pytest
from pathlib import Path
from devtorch_core import GCCRepository
from devtorch_core.sensitivity import SensitivityEvent
from devtorch_core.divergence import DivergenceSignal, DivergenceDetector


def _make_repo(tmp_path: Path) -> GCCRepository:
    repo = GCCRepository.at(tmp_path / "proj")
    repo.init()
    return repo


def test_divergence_signal_fields():
    s = DivergenceSignal(
        signal_type="B",
        severity="MEDIUM",
        concept="auth",
        agent_ids=["agent-A", "agent-B"],
        description="Confidence gap 0.40 on auth",
        evidence={"agent_A_confidence": 0.9, "agent_B_confidence": 0.5},
    )
    assert s.signal_type == "B"
    assert s.severity == "MEDIUM"
    assert "agent-A" in s.agent_ids


def test_detector_finds_confidence_gap(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, conf in [("agent-A", 0.9), ("agent-B", 0.5)]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="auth",
            counterfactuals="JWT reasoning", confidence=conf,
            disclosure_level="PROTECTED", agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    detector = DivergenceDetector(repo)
    signals = detector.detect(concept="auth")
    types = {s.signal_type for s in signals}
    assert "B" in types  # confidence gap ≥0.35


def test_detector_finds_disclosure_mismatch(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, disc in [("agent-A", "PUBLIC"), ("agent-B", "PRIVATE")]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="payments",
            counterfactuals="payment flow", confidence=0.8,
            disclosure_level=disc, agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    detector = DivergenceDetector(repo)
    signals = detector.detect(concept="payments")
    types = {s.signal_type for s in signals}
    assert "C" in types  # disclosure mismatch
    c_signals = [s for s in signals if s.signal_type == "C"]
    assert c_signals[0].severity == "HIGH"


def test_detector_no_divergence_single_agent(tmp_path):
    repo = _make_repo(tmp_path)
    ev = SensitivityEvent(
        source_node="agent-solo", target_concept="schema",
        counterfactuals="reason", confidence=0.7,
        disclosure_level="PROTECTED", agent_id="agent-solo",
    )
    repo.add_sensitivity(ev)
    detector = DivergenceDetector(repo)
    signals = detector.detect(concept="schema")
    assert signals == []


def test_detector_no_divergence_fewer_than_two_events(tmp_path):
    repo = _make_repo(tmp_path)
    # Only 1 event total — cannot diverge
    ev = SensitivityEvent(
        source_node="agent-A", target_concept="config",
        counterfactuals="reason", confidence=0.7,
        disclosure_level="PROTECTED", agent_id="agent-A",
    )
    repo.add_sensitivity(ev)
    detector = DivergenceDetector(repo)
    signals = detector.detect(concept="config")
    assert signals == []


def test_detector_returns_severity_ordered(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, disc, conf in [
        ("a1", "PUBLIC", 0.9), ("a2", "PRIVATE", 0.5)
    ]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="pii",
            counterfactuals="reason", confidence=conf,
            disclosure_level=disc, agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    detector = DivergenceDetector(repo)
    signals = detector.detect(concept="pii")
    # Should have at least B and C signals; HIGH (C) must come before MEDIUM (B)
    assert len(signals) >= 2
    severities = [s.severity for s in signals]
    high_indices = [i for i, sv in enumerate(severities) if sv == "HIGH"]
    medium_indices = [i for i, sv in enumerate(severities) if sv == "MEDIUM"]
    if high_indices and medium_indices:
        assert max(high_indices) < min(medium_indices)


def test_detector_empty_concept_returns_empty(tmp_path):
    repo = _make_repo(tmp_path)
    detector = DivergenceDetector(repo)
    signals = detector.detect(concept="never-seen")
    assert signals == []


from devtorch_core.consolidation import ConsolidationRecord, ConsolidationWorkflow


def test_consolidation_record_fields():
    record = ConsolidationRecord(
        record_id="rec-1",
        concept="auth",
        signals=[],
        state="drafting",
        decision="",
        decision_trace="",
        agents_involved=["agent-A", "agent-B"],
        human_comments=[],
        created_at="2026-05-12T10:00:00+00:00",
        resolved_at=None,
    )
    assert record.concept == "auth"
    assert record.state == "drafting"


def test_consolidation_workflow_creates_record(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, disc in [("agent-A", "PUBLIC"), ("agent-B", "PRIVATE")]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="payments",
            counterfactuals="reason", confidence=0.8,
            disclosure_level=disc, agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    detector = DivergenceDetector(repo)
    signals = detector.detect(concept="payments")
    workflow = ConsolidationWorkflow(repo)
    record = workflow.start(concept="payments", signals=signals)
    assert record.state in ("drafting", "pending_human", "auto_resolved", "blocked")
    assert record.concept == "payments"
    assert record.record_id != ""


def test_consolidation_workflow_persists_record(tmp_path):
    repo = _make_repo(tmp_path)
    ev = SensitivityEvent(
        source_node="a1", target_concept="config",
        counterfactuals="reason", confidence=0.7,
        disclosure_level="PROTECTED", agent_id="a1",
    )
    repo.add_sensitivity(ev)
    workflow = ConsolidationWorkflow(repo)
    signal = DivergenceSignal(
        signal_type="B", severity="MEDIUM", concept="config",
        agent_ids=["a1", "a2"], description="gap", evidence={},
    )
    record = workflow.start(concept="config", signals=[signal])
    import json
    consolidations_dir = tmp_path / "proj" / ".GCC" / "consolidations"
    assert consolidations_dir.exists()
    files = list(consolidations_dir.glob("*.json"))
    assert len(files) == 1
    loaded = json.loads(files[0].read_text())
    assert loaded["record_id"] == record.record_id


def test_consolidation_workflow_high_severity_sets_pending_human(tmp_path):
    repo = _make_repo(tmp_path)
    workflow = ConsolidationWorkflow(repo)
    signal = DivergenceSignal(
        signal_type="C", severity="HIGH", concept="pii",
        agent_ids=["a1", "a2"], description="disclosure mismatch", evidence={},
    )
    record = workflow.start(concept="pii", signals=[signal])
    assert record.state in ("pending_human", "blocked")


def test_consolidation_workflow_low_severity_auto_resolves(tmp_path):
    repo = _make_repo(tmp_path)
    workflow = ConsolidationWorkflow(repo)
    signal = DivergenceSignal(
        signal_type="D", severity="LOW", concept="deploy",
        agent_ids=["a1"], description="missing coverage", evidence={},
    )
    record = workflow.start(concept="deploy", signals=[signal])
    assert record.state == "auto_resolved"
    assert record.decision != ""
    assert record.decision_trace != ""
