from __future__ import annotations

import json
from pathlib import Path

from devtorch_core import GCCRepository, GCC_DIR_NAME, EVENT_LOG_NAME, MAIN_MD_NAME, LOG_MD_NAME


def _read_events(event_log: Path) -> list[dict]:
    events: list[dict] = []
    with event_log.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            events.append(json.loads(line))
    return events


def test_init_creates_layout(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()

    gcc_dir = tmp_path / GCC_DIR_NAME
    assert gcc_dir.is_dir()
    assert (gcc_dir / "VERSION").is_file()
    assert (gcc_dir / EVENT_LOG_NAME).is_file()
    assert (gcc_dir / MAIN_MD_NAME).is_file()
    assert (gcc_dir / LOG_MD_NAME).is_file()
    assert (gcc_dir / "capabilities" / "omega.json").is_file()

    # doctor should report no issues
    issues = repo.doctor()
    assert issues == []


def test_commit_happy_path_and_doctor(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit(message="first reasoning step")

    gcc_dir = tmp_path / GCC_DIR_NAME
    main_md = (gcc_dir / MAIN_MD_NAME).read_text(encoding="utf-8")
    log_md = (gcc_dir / LOG_MD_NAME).read_text(encoding="utf-8")

    assert "first reasoning step" in main_md
    assert "first reasoning step" in log_md

    # Event log should contain INIT + COMMIT with matching hash chain
    events = _read_events(gcc_dir / EVENT_LOG_NAME)
    assert len(events) >= 2
    assert events[0]["event_type"] == "INIT"
    assert events[-1]["event_type"] == "COMMIT"

    issues = repo.doctor()
    assert issues == []


def test_concurrent_append_preserves_hash_chain(tmp_path: Path) -> None:
    """Concurrent _append_event calls from parallel subprocesses must not fork the hash chain."""
    import concurrent.futures
    import subprocess
    import sys

    repo = GCCRepository.at(tmp_path)
    repo.init()

    def _spawn(i: int) -> None:
        code = (
            "from pathlib import Path; "
            "from devtorch_core import GCCRepository; "
            f"r = GCCRepository.at(Path({str(tmp_path)!r})); "
            f"r._append_event('PARALLEL_WRITE', {{'worker': {i}}})"
        )
        subprocess.run([sys.executable, "-c", code], check=True)

    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as exe:
        futs = [exe.submit(_spawn, i) for i in range(8)]
        for fut in concurrent.futures.as_completed(futs):
            fut.result()

    issues = repo.doctor()
    event_issues = [iss for iss in issues if iss.kind == "event-log"]
    assert event_issues == [], f"Hash chain forked under concurrent writes: {event_issues}"


def test_doctor_detects_corrupted_event_log(tmp_path: Path) -> None:
    repo = GCCRepository.at(tmp_path)
    repo.init()
    repo.commit(message="ok")

    gcc_dir = tmp_path / GCC_DIR_NAME
    event_log = gcc_dir / EVENT_LOG_NAME

    # Corrupt the last line
    lines = event_log.read_text(encoding="utf-8").splitlines()
    assert lines, "event log should not be empty"
    lines[-1] = lines[-1].replace('"event_type": "COMMIT"', '"event_type": "COMMIT_CORRUPTED"')
    event_log.write_text("\n".join(lines) + "\n", encoding="utf-8")

    issues = repo.doctor()
    assert any(issue.kind == "event-log" for issue in issues)


def test_realistic_reasoning_log_for_schema_migration(tmp_path: Path) -> None:
    """
    Real-world style scenario inspired by the DevTorch payment-service narrative.

    We simulate a Staff Engineer coordinating an ORM migration across services.
    Each `commit` here stands for a concrete reasoning milestone that must be
    persisted into `main.md` and `log.md` so later agents/humans can reconstruct
    why a particular migration plan was chosen.
    """
    repo = GCCRepository.at(tmp_path)
    repo.init()

    print("\n[scenario] Starting ORM migration reasoning log for payment-service.")
    repo.commit("Define backward-compatible ORM migration plan for payments.")
    print("[scenario] Recorded plan that keeps old and new schemas compatible.")
    repo.commit("Validate migration against legacy transaction log consumers (billing service).")
    print("[scenario] Verified that billing's hard-coded transaction log format still works.")
    repo.commit("Approve phased rollout plan with canary deployment strategy.")
    print("[scenario] Captured rollout strategy that limits blast radius in production.")

    gcc_dir = tmp_path / GCC_DIR_NAME
    main_md = (gcc_dir / MAIN_MD_NAME).read_text(encoding="utf-8")
    log_md = (gcc_dir / LOG_MD_NAME).read_text(encoding="utf-8")

    for phrase in [
        "Define backward-compatible ORM migration plan for payments.",
        "Validate migration against legacy transaction log consumers (billing service).",
        "Approve phased rollout plan with canary deployment strategy.",
    ]:
        assert phrase in main_md
        assert phrase in log_md

    # Event log should reflect multiple COMMIT milestones without doctor complaining.
    events = _read_events(gcc_dir / EVENT_LOG_NAME)
    commit_events = [e for e in events if e["event_type"] == "COMMIT"]
    assert len(commit_events) >= 3
    issues = repo.doctor()
    assert issues == []

