import pytest
from pathlib import Path
from devtorch_core import GCCRepository
from devtorch_core.sensitivity import SensitivityEvent
from devtorch_core.divergence import DivergenceSignal, DivergenceDetector
from devtorch_core.consolidation import ConsolidationWorkflow
from devtorch_core.hitl import HITLRequest, CLIHITLChannel, HITLOrchestrator
from devtorch_core.mcp.server import _dispatch_tool


def _make_repo(tmp_path: Path) -> GCCRepository:
    repo = GCCRepository.at(tmp_path / "proj")
    repo.init()
    return repo


def test_hitl_request_fields():
    req = HITLRequest(
        request_id="req-1",
        concept="auth",
        consolidation_record_id="rec-1",
        signals=[],
        prompt="How should we handle auth disclosure?",
        options=["Use PROTECTED", "Use PRIVATE", "Defer to security team"],
        state="pending",
        created_at="2026-05-12T10:00:00+00:00",
    )
    assert req.request_id == "req-1"
    assert req.state == "pending"
    assert len(req.options) == 3


def test_cli_channel_delivers_and_gets_response(tmp_path):
    channel = CLIHITLChannel(response_queue=["Use PROTECTED — default for internal logic"])
    req = HITLRequest(
        request_id="req-test",
        concept="auth",
        consolidation_record_id="rec-test",
        signals=[],
        prompt="How should auth be classified?",
        options=["PROTECTED", "PRIVATE"],
        state="pending",
        created_at="2026-05-12T10:00:00+00:00",
    )
    channel.send(req)
    response = channel.poll("req-test")
    assert response is not None
    assert "PROTECTED" in response


def test_hitl_orchestrator_creates_record_on_high_severity(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, disc in [("agent-A", "PUBLIC"), ("agent-B", "PRIVATE")]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="payments",
            counterfactuals="reason", confidence=0.8,
            disclosure_level=disc, agent_id=agent_id,
        )
        repo.add_sensitivity(ev)

    channel = CLIHITLChannel(response_queue=["Use PRIVATE — payments always private"])
    orchestrator = HITLOrchestrator(repo, channels=[channel])
    record = orchestrator.run(concept="payments")

    assert record is not None
    assert record.state in ("resolved", "pending_human", "auto_resolved")


def test_hitl_orchestrator_no_divergence_returns_none(tmp_path):
    repo = _make_repo(tmp_path)
    ev = SensitivityEvent(
        source_node="solo", target_concept="deploy",
        counterfactuals="deploy reason", confidence=0.7,
        disclosure_level="PROTECTED", agent_id="solo",
    )
    repo.add_sensitivity(ev)
    orchestrator = HITLOrchestrator(repo, channels=[])
    record = orchestrator.run(concept="deploy")
    assert record is None


def test_hitl_request_persisted_to_gcc(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, disc in [("agent-A", "PUBLIC"), ("agent-B", "PRIVATE")]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="pii",
            counterfactuals="reason", confidence=0.8,
            disclosure_level=disc, agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    channel = CLIHITLChannel(response_queue=["PRIVATE for all PII"])
    orchestrator = HITLOrchestrator(repo, channels=[channel])
    orchestrator.run(concept="pii")
    hitl_dir = tmp_path / "proj" / ".GCC" / "hitl"
    assert hitl_dir.exists()
    files = list(hitl_dir.glob("*.json"))
    assert len(files) >= 1


def test_hitl_mcp_respond_tool(tmp_path):
    repo = _make_repo(tmp_path)
    # Create a consolidation record that is pending_human
    signal = DivergenceSignal(
        signal_type="C", severity="HIGH", concept="pii",
        agent_ids=["a1", "a2"], description="disclosure mismatch", evidence={},
    )
    wf = ConsolidationWorkflow(repo)
    record = wf.start(concept="pii", signals=[signal])
    assert record.state in ("pending_human", "blocked")

    result = _dispatch_tool(repo, "devtorch_hitl_respond", {
        "record_id": record.record_id,
        "author": "hemant",
        "comment": "Always PRIVATE for PII",
        "decision": "All PII fields must use PRIVATE disclosure",
    })
    assert "resolved" in result.lower() or "recorded" in result.lower()


def test_gcc_check_divergence(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, disc in [("agent-A", "PUBLIC"), ("agent-B", "PRIVATE")]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="auth",
            counterfactuals="reason", confidence=0.8,
            disclosure_level=disc, agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    signals = repo.check_divergence(concept="auth")
    assert len(signals) >= 1
    types = {s["signal_type"] for s in signals}
    assert "C" in types


def test_gcc_start_consolidation(tmp_path):
    repo = _make_repo(tmp_path)
    for agent_id, disc in [("agent-A", "PUBLIC"), ("agent-B", "PRIVATE")]:
        ev = SensitivityEvent(
            source_node=agent_id, target_concept="auth",
            counterfactuals="reason", confidence=0.8,
            disclosure_level=disc, agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    record = repo.start_consolidation(concept="auth")
    assert record is not None
    assert record["concept"] == "auth"
    assert record["state"] in ("pending_human", "blocked", "auto_resolved")


def test_gcc_reasoning_query(tmp_path):
    repo = _make_repo(tmp_path)
    repo.commit(message="Chose JWT — stateless", agent_id="agent-A")
    ev = SensitivityEvent(
        source_node="agent-A", target_concept="auth",
        counterfactuals="JWT because stateless service",
        confidence=0.9, disclosure_level="PROTECTED", agent_id="agent-A",
    )
    repo.add_sensitivity(ev)
    entries = repo.reasoning_query(concept="auth", agent_id="agent-A")
    assert len(entries) >= 1
    assert entries[0]["concept"] == "auth"
    assert "JWT" in entries[0]["reasoning_text"]
