"""
Sprint 19 tests – ReasoningEntry and ReasoningStore.

Tests for the cross-agent reasoning query layer that combines
SensitivityEvents (the why) with associated commits (the decision).
"""

from __future__ import annotations

from pathlib import Path

import pytest

from devtorch_core import GCCRepository
from devtorch_core.sensitivity import SensitivityEvent
from devtorch_core.reasoning import ReasoningEntry, ReasoningStore


def _make_repo(tmp_path: Path) -> GCCRepository:
    repo = GCCRepository.at(tmp_path / "proj")
    repo.init()
    return repo


def test_reasoning_entry_fields():
    """Test that ReasoningEntry has all required fields."""
    e = ReasoningEntry(
        entry_id="e1",
        agent_id="agent-1",
        concept="auth",
        reasoning_text="JWT chosen because service is stateless",
        decision_text="Chose JWT over sessions",
        confidence=0.9,
        disclosure_level="PROTECTED",
        session_id="sess-1",
        branch="main",
        timestamp="2026-05-12T10:00:00+00:00",
        source_type="sensitivity",
    )
    assert e.concept == "auth"
    assert e.agent_id == "agent-1"
    assert e.source_type == "sensitivity"


def test_reasoning_store_query_by_concept(tmp_path):
    """Test that ReasoningStore.query() returns entries for the requested concept."""
    repo = _make_repo(tmp_path)
    repo.commit(message="chose JWT — stateless", agent_id="agent-1")
    ev = SensitivityEvent(
        source_node="agent-1",
        target_concept="auth",
        counterfactuals="JWT because stateless service, no session store needed",
        confidence=0.9,
        disclosure_level="PROTECTED",
        agent_id="agent-1",
        session_id="sess-1",
    )
    repo.add_sensitivity(ev)
    store = ReasoningStore(repo)
    entries = store.query(concept="auth")
    assert len(entries) >= 1
    assert all(e.concept == "auth" for e in entries)


def test_reasoning_store_query_filters_by_agent_id(tmp_path):
    """Test that query(agent_id=...) filters entries correctly."""
    repo = _make_repo(tmp_path)
    for agent_id, concept in [("agent-A", "auth"), ("agent-B", "schema"), ("agent-A", "auth")]:
        ev = SensitivityEvent(
            source_node=agent_id,
            target_concept=concept,
            counterfactuals=f"reason by {agent_id}",
            confidence=0.7,
            disclosure_level="PROTECTED",
            agent_id=agent_id,
        )
        repo.add_sensitivity(ev)
    store = ReasoningStore(repo)
    entries = store.query(concept="auth", agent_id="agent-A")
    assert all(e.agent_id == "agent-A" for e in entries)
    assert all(e.concept == "auth" for e in entries)


def test_reasoning_store_query_token_budget(tmp_path):
    """Test that query(k_tokens=...) respects the token budget."""
    repo = _make_repo(tmp_path)
    for i in range(20):
        ev = SensitivityEvent(
            source_node="agent-1",
            target_concept="auth",
            counterfactuals="x " * 100,  # ~100 tokens each
            confidence=0.8,
            disclosure_level="PROTECTED",
            agent_id="agent-1",
        )
        repo.add_sensitivity(ev)
    store = ReasoningStore(repo)
    entries = store.query(concept="auth", k_tokens=500)
    # With a 500-token budget and ~100 tokens per entry, we expect far fewer than 20
    assert len(entries) < 20


def test_reasoning_store_query_no_results(tmp_path):
    """Test that query() returns empty list for nonexistent concept."""
    repo = _make_repo(tmp_path)
    store = ReasoningStore(repo)
    entries = store.query(concept="nonexistent-concept")
    assert entries == []


def test_reasoning_store_falls_back_to_source_node_when_no_agent_id(tmp_path):
    """Backward compat: events without agent_id use source_node as agent_id."""
    repo = _make_repo(tmp_path)
    ev = SensitivityEvent(
        source_node="legacy-node",
        target_concept="schema",
        counterfactuals="old event, no agent_id",
        confidence=0.6,
        disclosure_level="PUBLIC",
        # no agent_id set
    )
    repo.add_sensitivity(ev)
    store = ReasoningStore(repo)
    entries = store.query(concept="schema", agent_id="legacy-node")
    assert len(entries) >= 1
    assert entries[0].agent_id == "legacy-node"


from devtorch_core.mcp.server import _dispatch_tool


def test_mcp_reasoning_query_tool(tmp_path):
    repo = _make_repo(tmp_path)
    ev = SensitivityEvent(
        source_node="agent-x",
        target_concept="auth",
        counterfactuals="chose bcrypt for password hashing",
        confidence=0.85,
        disclosure_level="PROTECTED",
        agent_id="agent-x",
    )
    repo.add_sensitivity(ev)
    result = _dispatch_tool(repo, "devtorch_reasoning_query", {
        "concept": "auth",
        "agent_id": "agent-x",
    })
    assert "auth" in result
    assert "bcrypt" in result


def test_mcp_reasoning_query_unknown_concept(tmp_path):
    repo = _make_repo(tmp_path)
    result = _dispatch_tool(repo, "devtorch_reasoning_query", {"concept": "no-such"})
    assert "no" in result.lower() and "entr" in result.lower()
