from __future__ import annotations
import pytest
from pathlib import Path
from unittest.mock import MagicMock
from botocore.exceptions import ClientError
from devtorch_core.storage import LocalFileBackend, R2Backend


def test_write_and_read_bytes(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    b.write_bytes("foo.txt", b"hello")
    assert b.read_bytes("foo.txt") == b"hello"


def test_write_creates_parent_dirs(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    b.write_bytes("a/b/c.txt", b"deep")
    assert (tmp_path / "a" / "b" / "c.txt").read_bytes() == b"deep"


def test_exists(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    assert not b.exists("x.txt")
    b.write_bytes("x.txt", b"data")
    assert b.exists("x.txt")


def test_append_bytes_atomic_sequential(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    b.append_bytes_atomic("log.jsonl", b"line1\n")
    b.append_bytes_atomic("log.jsonl", b"line2\n")
    assert b.read_bytes("log.jsonl") == b"line1\nline2\n"


def test_list_keys(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    b.write_bytes("commits/aaa.json", b"{}")
    b.write_bytes("commits/bbb.json", b"{}")
    b.write_bytes("other.txt", b"x")
    keys = b.list_keys("commits/")
    assert set(keys) == {"commits/aaa.json", "commits/bbb.json"}


def test_delete(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    b.write_bytes("del.txt", b"bye")
    b.delete("del.txt")
    assert not b.exists("del.txt")


def test_read_nonexistent_raises(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    with pytest.raises(FileNotFoundError):
        b.read_bytes("missing.txt")


def test_path_traversal_raises(tmp_path: Path) -> None:
    b = LocalFileBackend(tmp_path)
    with pytest.raises(ValueError, match="escapes root"):
        b.read_bytes("../escape.txt")


def _make_r2(store: dict | None = None) -> tuple[R2Backend, dict]:
    """Build an R2Backend with a fake in-memory S3 client."""
    mem: dict[str, bytes] = store if store is not None else {}
    etags: dict[str, str] = {}

    client = MagicMock()

    def fake_get(Bucket, Key):
        if Key not in mem:
            err = ClientError({"Error": {"Code": "NoSuchKey", "Message": ""}}, "GetObject")
            raise err
        return {"Body": MagicMock(read=lambda: mem[Key]), "ETag": f'"{etags.get(Key, "0")}"'}

    def fake_put(Bucket, Key, Body, **kwargs):
        if_match = kwargs.get("IfMatch")
        current_etag = etags.get(Key)
        if if_match and f'"{current_etag}"' != if_match:
            err = ClientError({"Error": {"Code": "PreconditionFailed", "Message": ""}}, "PutObject")
            raise err
        mem[Key] = Body
        etags[Key] = str(len(mem[Key]))

    def fake_list(Bucket, Prefix="", **kwargs):
        keys = [k for k in mem if k.startswith(Prefix)]
        return {"Contents": [{"Key": k} for k in keys], "IsTruncated": False}

    def fake_delete(Bucket, Key):
        mem.pop(Key, None)

    client.get_object.side_effect = fake_get
    client.put_object.side_effect = fake_put
    client.list_objects_v2.side_effect = fake_list
    client.delete_object.side_effect = fake_delete
    client.exceptions.ClientError = ClientError

    r2 = R2Backend(client=client, bucket="test-bucket", prefix="acme/repo1/.GCC")
    return r2, mem


def test_r2_write_and_read() -> None:
    r2, mem = _make_r2()
    r2.write_bytes("VERSION", b"gcc-v0\n")
    assert r2.read_bytes("VERSION") == b"gcc-v0\n"
    assert "acme/repo1/.GCC/VERSION" in mem


def test_r2_exists() -> None:
    r2, _ = _make_r2()
    assert not r2.exists("VERSION")
    r2.write_bytes("VERSION", b"x")
    assert r2.exists("VERSION")


def test_r2_append_atomic() -> None:
    r2, _ = _make_r2()
    r2.append_bytes_atomic("log.jsonl", b"line1\n")
    r2.append_bytes_atomic("log.jsonl", b"line2\n")
    assert r2.read_bytes("log.jsonl") == b"line1\nline2\n"


def test_r2_read_and_append_atomic() -> None:
    r2, _ = _make_r2()
    r2.write_bytes("log.jsonl", b"line0\n")

    def add_line(current: bytes) -> bytes:
        return b"line1\n"

    r2.read_and_append_atomic("log.jsonl", add_line)
    assert r2.read_bytes("log.jsonl") == b"line0\nline1\n"


def test_r2_list_keys() -> None:
    r2, _ = _make_r2()
    r2.write_bytes("commits/aaa.json", b"{}")
    r2.write_bytes("commits/bbb.json", b"{}")
    r2.write_bytes("VERSION", b"x")
    keys = r2.list_keys("commits/")
    assert set(keys) == {"commits/aaa.json", "commits/bbb.json"}


def test_r2_delete() -> None:
    r2, _ = _make_r2()
    r2.write_bytes("x.txt", b"data")
    r2.delete("x.txt")
    assert not r2.exists("x.txt")


def test_r2_atomic_retries_on_stale_etag() -> None:
    """Retry loop recovers from a single PreconditionFailed (concurrent writer race)."""
    from botocore.exceptions import ClientError as CE

    r2, mem = _make_r2()
    r2.write_bytes("log.jsonl", b"v0\n")

    put_attempts = {"n": 0}
    real_put = r2._s3.put_object.side_effect

    def flaky_put(Bucket, Key, Body, **kwargs):
        put_attempts["n"] += 1
        if put_attempts["n"] == 1:
            raise CE({"Error": {"Code": "PreconditionFailed", "Message": ""}}, "PutObject")
        return real_put(Bucket=Bucket, Key=Key, Body=Body, **kwargs)

    r2._s3.put_object.side_effect = flaky_put
    r2.append_bytes_atomic("log.jsonl", b"v1\n")
    assert r2.read_bytes("log.jsonl") == b"v0\nv1\n"
    assert put_attempts["n"] == 2  # first attempt failed, second succeeded
