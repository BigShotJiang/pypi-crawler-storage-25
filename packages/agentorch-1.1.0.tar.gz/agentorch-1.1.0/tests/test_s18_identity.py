import pytest
from pathlib import Path
from devtorch_core.identity import AgentIdentity, AgentRegistry


def test_agent_identity_fields():
    a = AgentIdentity(agent_id="agent-1", name="ReviewBot", provider="native", scope="branch")
    assert a.agent_id == "agent-1"
    assert a.name == "ReviewBot"
    assert a.provider == "native"
    assert a.scope == "branch"
    assert a.metadata == {}


def test_agent_identity_to_dict():
    a = AgentIdentity(agent_id="a1", name="bot", provider="bedrock", scope="session",
                      metadata={"region": "us-east-1"})
    d = a.to_dict()
    assert d["agent_id"] == "a1"
    assert d["provider"] == "bedrock"
    assert d["metadata"]["region"] == "us-east-1"


def test_agent_registry_register_and_get(tmp_path):
    reg = AgentRegistry(tmp_path)
    a = AgentIdentity(agent_id="bot-1", name="Bot1", provider="native", scope="branch")
    reg.register(a)
    loaded = reg.get("bot-1")
    assert loaded is not None
    assert loaded.name == "Bot1"


def test_agent_registry_get_missing_returns_none(tmp_path):
    reg = AgentRegistry(tmp_path)
    assert reg.get("no-such-agent") is None


def test_agent_registry_list_all(tmp_path):
    reg = AgentRegistry(tmp_path)
    for i in range(3):
        reg.register(AgentIdentity(agent_id=f"bot-{i}", name=f"Bot{i}",
                                   provider="native", scope="org"))
    agents = reg.list_all()
    assert len(agents) == 3
    ids = {a.agent_id for a in agents}
    assert "bot-0" in ids and "bot-2" in ids


from devtorch_core.identity.providers import (
    NativeProvider, BedrockProvider, AzureProvider, AnonymousProvider,
    resolve_agent_identity,
)


def test_native_provider_from_env(monkeypatch):
    monkeypatch.setenv("DEVTORCH_AGENT_ID", "dev-agent-99")
    monkeypatch.setenv("DEVTORCH_AGENT_NAME", "DevAgent99")
    monkeypatch.setenv("DEVTORCH_AGENT_SCOPE", "branch")
    identity = NativeProvider().resolve()
    assert identity is not None
    assert identity.agent_id == "dev-agent-99"
    assert identity.provider == "native"
    assert identity.scope == "branch"


def test_native_provider_missing_env_returns_none(monkeypatch):
    monkeypatch.delenv("DEVTORCH_AGENT_ID", raising=False)
    assert NativeProvider().resolve() is None


def test_bedrock_provider_from_env(monkeypatch):
    monkeypatch.setenv("BEDROCK_AGENT_ID", "bedrock-agent-42")
    identity = BedrockProvider().resolve()
    assert identity is not None
    assert identity.agent_id == "bedrock-agent-42"
    assert identity.provider == "bedrock"
    assert identity.scope == "session"


def test_bedrock_provider_missing_env_returns_none(monkeypatch):
    monkeypatch.delenv("BEDROCK_AGENT_ID", raising=False)
    assert BedrockProvider().resolve() is None


def test_azure_provider_from_env(monkeypatch):
    monkeypatch.setenv("AZURE_CLIENT_ID", "azure-client-007")
    identity = AzureProvider().resolve()
    assert identity is not None
    assert identity.agent_id == "azure-client-007"
    assert identity.provider == "azure"
    assert identity.scope == "session"


def test_azure_provider_missing_env_returns_none(monkeypatch):
    monkeypatch.delenv("AZURE_CLIENT_ID", raising=False)
    assert AzureProvider().resolve() is None


def test_anonymous_provider_always_returns(monkeypatch):
    monkeypatch.delenv("DEVTORCH_AGENT_ID", raising=False)
    monkeypatch.delenv("BEDROCK_AGENT_ID", raising=False)
    monkeypatch.delenv("AZURE_CLIENT_ID", raising=False)
    identity = AnonymousProvider().resolve()
    assert identity is not None
    assert identity.provider == "anonymous"
    assert identity.scope == "session"
    assert identity.agent_id.startswith("anon-")


def test_resolve_agent_identity_prefers_native_over_anonymous(monkeypatch):
    monkeypatch.setenv("DEVTORCH_AGENT_ID", "my-agent")
    monkeypatch.setenv("DEVTORCH_AGENT_NAME", "MyAgent")
    monkeypatch.setenv("DEVTORCH_AGENT_SCOPE", "org")
    monkeypatch.delenv("BEDROCK_AGENT_ID", raising=False)
    monkeypatch.delenv("AZURE_CLIENT_ID", raising=False)
    identity = resolve_agent_identity()
    assert identity.provider == "native"
    assert identity.agent_id == "my-agent"


def test_resolve_agent_identity_falls_back_to_anonymous(monkeypatch):
    monkeypatch.delenv("DEVTORCH_AGENT_ID", raising=False)
    monkeypatch.delenv("BEDROCK_AGENT_ID", raising=False)
    monkeypatch.delenv("AZURE_CLIENT_ID", raising=False)
    identity = resolve_agent_identity()
    assert identity.provider == "anonymous"


def test_commit_stamped_with_agent_id(tmp_path):
    from devtorch_core import GCCRepository
    repo = GCCRepository.at(tmp_path / "proj")
    repo.init()
    repo.commit(message="test commit", agent_id="agent-1")
    import json
    commits = list((tmp_path / "proj" / ".GCC" / "commits").glob("*.json"))
    assert len(commits) == 1
    obj = json.loads(commits[0].read_text())
    assert obj["agent_id"] == "agent-1"


def test_commit_agent_id_optional_backward_compat(tmp_path):
    from devtorch_core import GCCRepository
    repo = GCCRepository.at(tmp_path / "proj")
    repo.init()
    repo.commit(message="no agent")
    import json
    commits = list((tmp_path / "proj" / ".GCC" / "commits").glob("*.json"))
    assert len(commits) == 1
    obj = json.loads(commits[0].read_text())
    # agent_id absent or None — both acceptable
    assert obj.get("agent_id") is None


def test_sensitivity_event_has_agent_id_field():
    from devtorch_core.sensitivity import SensitivityEvent
    ev = SensitivityEvent(
        source_node="test-node",
        target_concept="auth",
        counterfactuals="JWT chosen over sessions",
        confidence=0.9,
        disclosure_level="PROTECTED",
        agent_id="agent-1",
        session_id="sess-abc",
    )
    assert ev.agent_id == "agent-1"
    assert ev.session_id == "sess-abc"
    d = ev.to_dict()
    assert d["agent_id"] == "agent-1"
    assert d["session_id"] == "sess-abc"


def test_sensitivity_event_agent_id_defaults_none():
    from devtorch_core.sensitivity import SensitivityEvent
    ev = SensitivityEvent(
        source_node="node",
        target_concept="schema",
        counterfactuals="text",
        confidence=0.5,
        disclosure_level="PUBLIC",
    )
    assert ev.agent_id is None
    assert ev.session_id is None
