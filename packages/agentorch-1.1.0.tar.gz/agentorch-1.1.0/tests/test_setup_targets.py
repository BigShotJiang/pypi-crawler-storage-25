import json
import pytest
from pathlib import Path
from devtorch_core.hooks.installer import install_cursor_mcp, install_antigravity_mcp


# ---------------------------------------------------------------------------
# install_cursor_mcp
# ---------------------------------------------------------------------------

def test_install_cursor_mcp_creates_file(tmp_path):
    ok, path = install_cursor_mcp(str(tmp_path))
    assert ok is True
    mcp_file = tmp_path / ".cursor" / "mcp.json"
    assert mcp_file.exists()
    data = json.loads(mcp_file.read_text())
    assert "mcpServers" in data
    assert "devtorch" in data["mcpServers"]
    assert data["mcpServers"]["devtorch"]["args"] == ["mcp-server"]


def test_install_cursor_mcp_idempotent(tmp_path):
    install_cursor_mcp(str(tmp_path))
    ok, _ = install_cursor_mcp(str(tmp_path))
    assert ok is True
    mcp_file = tmp_path / ".cursor" / "mcp.json"
    data = json.loads(mcp_file.read_text())
    assert len(data["mcpServers"]) == 1


def test_install_cursor_mcp_preserves_existing_servers(tmp_path):
    cursor_dir = tmp_path / ".cursor"
    cursor_dir.mkdir()
    existing = {"mcpServers": {"other-tool": {"command": "other", "args": []}}}
    (cursor_dir / "mcp.json").write_text(json.dumps(existing))
    ok, _ = install_cursor_mcp(str(tmp_path))
    assert ok is True
    data = json.loads((cursor_dir / "mcp.json").read_text())
    assert "other-tool" in data["mcpServers"]
    assert "devtorch" in data["mcpServers"]


# ---------------------------------------------------------------------------
# install_antigravity_mcp
# ---------------------------------------------------------------------------

def test_install_antigravity_mcp_creates_file(tmp_path):
    ok, path = install_antigravity_mcp(str(tmp_path))
    assert ok is True
    mcp_file = tmp_path / "mcp_config.json"
    assert mcp_file.exists()
    data = json.loads(mcp_file.read_text())
    assert "mcpServers" in data
    assert "devtorch" in data["mcpServers"]
    assert data["mcpServers"]["devtorch"]["args"] == ["mcp-server"]


def test_install_antigravity_mcp_idempotent(tmp_path):
    install_antigravity_mcp(str(tmp_path))
    ok, _ = install_antigravity_mcp(str(tmp_path))
    assert ok is True
    data = json.loads((tmp_path / "mcp_config.json").read_text())
    assert len(data["mcpServers"]) == 1


def test_install_antigravity_mcp_preserves_existing_servers(tmp_path):
    existing = {"mcpServers": {"gemini": {"command": "gemini-mcp", "args": []}}}
    (tmp_path / "mcp_config.json").write_text(json.dumps(existing))
    ok, _ = install_antigravity_mcp(str(tmp_path))
    assert ok is True
    data = json.loads((tmp_path / "mcp_config.json").read_text())
    assert "gemini" in data["mcpServers"]
    assert "devtorch" in data["mcpServers"]
