"""
DevTorch FAQ PDF generator — last 4 Q&A pairs.
Run: python3 docs/generate_faq_pdf.py
Output: docs/DevTorch_FAQ.pdf
"""
from pathlib import Path
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, KeepTogether, Flowable
)
from reportlab.platypus.flowables import BalancedColumns
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_JUSTIFY
from reportlab.graphics.shapes import Drawing, Rect, String, Line, Circle, Polygon
from reportlab.graphics import renderPDF
from reportlab.pdfgen.canvas import Canvas
from reportlab.platypus import BaseDocTemplate, Frame, PageTemplate

# ── Palette ────────────────────────────────────────────────────────────────
NAVY      = colors.HexColor("#0F1B2D")
BLUE      = colors.HexColor("#1E6FD9")
TEAL      = colors.HexColor("#0D9488")
AMBER     = colors.HexColor("#F59E0B")
LIGHT_BG  = colors.HexColor("#F0F4FA")
CARD_BG   = colors.HexColor("#F8FAFC")
BORDER    = colors.HexColor("#CBD5E1")
CODE_BG   = colors.HexColor("#1E293B")
CODE_FG   = colors.HexColor("#E2E8F0")
WHITE     = colors.white
GREY_MID  = colors.HexColor("#64748B")
GREY_DARK = colors.HexColor("#334155")

W, H = A4  # 595 x 842 pts

OUT = Path(__file__).parent / "DevTorch_FAQ.pdf"


# ── Canvas callbacks (header / footer) ─────────────────────────────────────

def _header_footer(canvas: Canvas, doc):
    canvas.saveState()
    # Top bar
    canvas.setFillColor(NAVY)
    canvas.rect(0, H - 42, W, 42, fill=1, stroke=0)
    # Logo text
    canvas.setFillColor(WHITE)
    canvas.setFont("Helvetica-Bold", 13)
    canvas.drawString(2 * cm, H - 27, "DevTorch")
    canvas.setFont("Helvetica", 9)
    canvas.setFillColor(colors.HexColor("#94A3B8"))
    canvas.drawString(2 * cm + 70, H - 27, "AI Governance Platform")
    # Right side: doc title
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.HexColor("#94A3B8"))
    canvas.drawRightString(W - 2 * cm, H - 27, "Multi-Agent Coordination FAQ")
    # Thin accent line under header
    canvas.setStrokeColor(TEAL)
    canvas.setLineWidth(2)
    canvas.line(0, H - 44, W, H - 44)

    # Footer
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(2 * cm, 1.8 * cm, W - 2 * cm, 1.8 * cm)
    canvas.setFont("Helvetica", 7.5)
    canvas.setFillColor(GREY_MID)
    canvas.drawString(2 * cm, 1.2 * cm, "© 2026 DevTorch · flotorch.ai · Confidential")
    canvas.drawRightString(W - 2 * cm, 1.2 * cm, f"Page {doc.page}")
    canvas.restoreState()


# ── Styles ──────────────────────────────────────────────────────────────────

def make_styles():
    base = getSampleStyleSheet()

    cover_title = ParagraphStyle("CoverTitle",
        fontName="Helvetica-Bold", fontSize=32, textColor=WHITE,
        leading=38, alignment=TA_CENTER, spaceAfter=8)

    cover_sub = ParagraphStyle("CoverSub",
        fontName="Helvetica", fontSize=13, textColor=colors.HexColor("#93C5FD"),
        leading=18, alignment=TA_CENTER, spaceAfter=4)

    cover_date = ParagraphStyle("CoverDate",
        fontName="Helvetica", fontSize=9, textColor=colors.HexColor("#64748B"),
        alignment=TA_CENTER)

    q_label = ParagraphStyle("QLabel",
        fontName="Helvetica-Bold", fontSize=8.5, textColor=WHITE,
        leading=11, spaceAfter=2)

    q_text = ParagraphStyle("QText",
        fontName="Helvetica-Bold", fontSize=13.5, textColor=WHITE,
        leading=18, spaceAfter=0)

    body = ParagraphStyle("Body",
        fontName="Helvetica", fontSize=10, textColor=GREY_DARK,
        leading=15.5, alignment=TA_JUSTIFY, spaceAfter=8)

    body_nb = ParagraphStyle("BodyNB",
        fontName="Helvetica", fontSize=10, textColor=GREY_DARK,
        leading=15.5, alignment=TA_JUSTIFY, spaceAfter=2)

    bold_inline = ParagraphStyle("BoldInline",
        fontName="Helvetica-Bold", fontSize=10, textColor=NAVY,
        leading=15, spaceAfter=6)

    section_head = ParagraphStyle("SectionHead",
        fontName="Helvetica-Bold", fontSize=11, textColor=NAVY,
        leading=14, spaceBefore=10, spaceAfter=5,
        borderPadding=(0, 0, 3, 0))

    callout_text = ParagraphStyle("Callout",
        fontName="Helvetica", fontSize=9.5, textColor=GREY_DARK,
        leading=14, spaceAfter=4)

    callout_bold = ParagraphStyle("CalloutBold",
        fontName="Helvetica-Bold", fontSize=9.5, textColor=NAVY,
        leading=14, spaceAfter=2)

    code = ParagraphStyle("Code",
        fontName="Courier", fontSize=8.5, textColor=CODE_FG,
        leading=13, backColor=CODE_BG, spaceAfter=0,
        leftIndent=6, rightIndent=6, borderPadding=(5, 6, 5, 6))

    caption = ParagraphStyle("Caption",
        fontName="Helvetica-Oblique", fontSize=8, textColor=GREY_MID,
        alignment=TA_CENTER, spaceAfter=4)

    return dict(
        cover_title=cover_title, cover_sub=cover_sub, cover_date=cover_date,
        q_label=q_label, q_text=q_text,
        body=body, body_nb=body_nb, bold_inline=bold_inline,
        section_head=section_head,
        callout_text=callout_text, callout_bold=callout_bold,
        code=code, caption=caption,
    )


# ── Drawing helpers ─────────────────────────────────────────────────────────

def cover_graphic():
    """Abstract hexagonal network graphic for cover."""
    d = Drawing(W, 180)
    cx, cy = W / 2, 90
    # Outer rings of circles representing agents/nodes
    import math
    positions = []
    for angle_deg in range(0, 360, 60):
        r = 65
        angle = math.radians(angle_deg)
        positions.append((cx + r * math.cos(angle), cy + r * math.sin(angle)))

    # Draw connecting lines first
    for i, (x1, y1) in enumerate(positions):
        for j, (x2, y2) in enumerate(positions):
            if j > i:
                l = Line(x1, y1, x2, y2, strokeColor=colors.HexColor("#1E40AF"),
                         strokeWidth=0.8, strokeOpacity=0.4)
                d.add(l)
        # Connect to center
        l = Line(cx, cy, x1, y1, strokeColor=TEAL, strokeWidth=1,
                 strokeOpacity=0.5)
        d.add(l)

    # Node circles
    node_labels = ["Agent A", "Human", "Agent B", "Agent C", "Human", "Agent D"]
    node_colors = [BLUE, AMBER, BLUE, BLUE, AMBER, BLUE]
    for (x, y), label, nc in zip(positions, node_labels, node_colors):
        c = Circle(x, y, 18, fillColor=nc, strokeColor=WHITE, strokeWidth=1.5)
        d.add(c)
        s = String(x, y - 3, label[:1], fontName="Helvetica-Bold",
                   fontSize=10, fillColor=WHITE, textAnchor="middle")
        d.add(s)

    # Center node: DevTorch
    c = Circle(cx, cy, 26, fillColor=TEAL, strokeColor=WHITE, strokeWidth=2)
    d.add(c)
    s = String(cx, cy + 5, "Dev", fontName="Helvetica-Bold",
               fontSize=9, fillColor=WHITE, textAnchor="middle")
    d.add(s)
    s2 = String(cx, cy - 7, "Torch", fontName="Helvetica-Bold",
                fontSize=9, fillColor=WHITE, textAnchor="middle")
    d.add(s2)
    return d


def racp_rep_diagram():
    """Layered diagram showing RACP vs REP responsibilities."""
    d = Drawing(W - 4 * cm, 200)
    dw = W - 4 * cm
    # Three layers
    layers = [
        (BLUE,  "RACP Capture Layer",    "Parses LLM output → commits + sensitivity events to .GCC/"),
        (NAVY,  ".GCC/ Event Store",     "Hash-chained JSONL + Θ vector + commit DAG"),
        (TEAL,  "REP Transport Layer",   "Envelopes + ledger + HTTP push/pull to peer nodes"),
    ]
    y = 160
    for lc, title, desc in layers:
        # Box
        r = Rect(0, y, dw, 42, fillColor=lc, strokeColor=WHITE,
                 strokeWidth=1, rx=4, ry=4)
        d.add(r)
        t = String(14, y + 26, title, fontName="Helvetica-Bold",
                   fontSize=10, fillColor=WHITE)
        d.add(t)
        t2 = String(14, y + 12, desc, fontName="Helvetica",
                    fontSize=8, fillColor=colors.HexColor("#CBD5E1"))
        d.add(t2)
        y -= 52
        if y > 10:
            # Arrow
            for ix in [dw // 2 - 6, dw // 2, dw // 2 + 6]:
                arr = Line(dw // 2, y + 10, dw // 2, y + 2,
                           strokeColor=AMBER, strokeWidth=1.5)
                d.add(arr)
            arr_head = Line(dw // 2 - 5, y + 5, dw // 2, y + 1,
                            strokeColor=AMBER, strokeWidth=1.5)
            d.add(arr_head)
            arr_head2 = Line(dw // 2 + 5, y + 5, dw // 2, y + 1,
                             strokeColor=AMBER, strokeWidth=1.5)
            d.add(arr_head2)
    return d


def sse_fallback_diagram():
    """Diagram showing the SSE broadcast + REP sync fallback stack."""
    d = Drawing(W - 4 * cm, 160)
    dw = W - 4 * cm
    # Machine A box
    ma_w = dw * 0.42
    r = Rect(0, 30, ma_w, 120, fillColor=LIGHT_BG, strokeColor=BORDER,
             strokeWidth=1, rx=4, ry=4)
    d.add(r)
    t = String(ma_w / 2, 138, "Machine A", fontName="Helvetica-Bold",
               fontSize=9, fillColor=NAVY, textAnchor="middle")
    d.add(t)

    inner = [
        (BLUE, ".GCC/ store", 100),
        (TEAL, "file watcher", 76),
        (NAVY, "SSE server :9877", 52),
    ]
    for ic, il, iy in inner:
        rb = Rect(8, iy, ma_w - 16, 18, fillColor=ic,
                  strokeColor=WHITE, strokeWidth=0.5, rx=2, ry=2)
        d.add(rb)
        tb = String(ma_w / 2, iy + 5, il, fontName="Helvetica",
                    fontSize=7.5, fillColor=WHITE, textAnchor="middle")
        d.add(tb)

    # Machine B box (mirror)
    bx = dw - ma_w
    r2 = Rect(bx, 30, ma_w, 120, fillColor=LIGHT_BG, strokeColor=BORDER,
              strokeWidth=1, rx=4, ry=4)
    d.add(r2)
    t2 = String(bx + ma_w / 2, 138, "Machine B", fontName="Helvetica-Bold",
                fontSize=9, fillColor=NAVY, textAnchor="middle")
    d.add(t2)
    for ic, il, iy in inner:
        rb = Rect(bx + 8, iy, ma_w - 16, 18, fillColor=ic,
                  strokeColor=WHITE, strokeWidth=0.5, rx=2, ry=2)
        d.add(rb)
        tb = String(bx + ma_w / 2, iy + 5, il, fontName="Helvetica",
                    fontSize=7.5, fillColor=WHITE, textAnchor="middle")
        d.add(tb)

    # REP sync arrow between machines
    mid_x = dw / 2
    sync_y = 62
    arr = Line(ma_w + 4, sync_y, bx - 4, sync_y,
               strokeColor=AMBER, strokeWidth=2)
    d.add(arr)
    t3 = String(mid_x, sync_y + 5, "REP sync (push/pull)", fontName="Helvetica-Bold",
                fontSize=7.5, fillColor=AMBER, textAnchor="middle")
    d.add(t3)

    # Agents subscribing below SSE
    for ix, label in [(ma_w * 0.25, "Agent A"), (ma_w * 0.75, "Human")]:
        l = Line(ix, 30, ix, 16, strokeColor=BLUE, strokeWidth=1)
        d.add(l)
        tb = String(ix, 5, label, fontName="Helvetica", fontSize=7,
                    fillColor=GREY_DARK, textAnchor="middle")
        d.add(tb)
    for ix, label in [(bx + ma_w * 0.25, "Agent B"), (bx + ma_w * 0.75, "Agent C")]:
        l = Line(ix, 30, ix, 16, strokeColor=BLUE, strokeWidth=1)
        d.add(l)
        tb = String(ix, 5, label, fontName="Helvetica", fontSize=7,
                    fillColor=GREY_DARK, textAnchor="middle")
        d.add(tb)
    return d


def concurrency_table():
    """Table: what works now vs needs cloud server."""
    data = [
        [Paragraph("<b>Scenario</b>", ParagraphStyle("th", fontName="Helvetica-Bold",
            fontSize=8.5, textColor=WHITE, leading=11)),
         Paragraph("<b>Works today</b>", ParagraphStyle("th", fontName="Helvetica-Bold",
            fontSize=8.5, textColor=WHITE, leading=11)),
         Paragraph("<b>Notes</b>", ParagraphStyle("th", fontName="Helvetica-Bold",
            fontSize=8.5, textColor=WHITE, leading=11))],
        ["Sequential agent handoffs", "✅ Full", "devtorch_context loads prior reasoning"],
        ["Humans as first-class agents", "✅ Full", "agent_id via DEVTORCH_AGENT_ID env"],
        ["Divergence detection (N agents)", "✅ Full", "Reads all events, any agent count"],
        ["HITL: human resolves conflict", "✅ Full", "CLI or Slack channel"],
        ["Concurrent writes, single machine", "⚠️ Partial", "Use shared .GCC/ via Cloud MCP"],
        ["Concurrent writes, multi-machine", "⚠️ Partial", "Route through Cloud MCP or REP sync"],
        ["Real-time cross-agent broadcast", "🔲 Planned", "SSE broadcaster + watchdog (next sprint)"],
    ]
    ps_body = ParagraphStyle("td", fontName="Helvetica", fontSize=8.5,
                             textColor=GREY_DARK, leading=12)
    ps_check = ParagraphStyle("tc", fontName="Helvetica-Bold", fontSize=8.5,
                              textColor=TEAL, leading=12)
    ps_warn = ParagraphStyle("tw", fontName="Helvetica-Bold", fontSize=8.5,
                             textColor=AMBER, leading=12)
    ps_plan = ParagraphStyle("tp", fontName="Helvetica", fontSize=8.5,
                             textColor=GREY_MID, leading=12)

    for i, row in enumerate(data[1:], 1):
        status = row[1]
        if "✅" in status:
            data[i][1] = Paragraph(status, ps_check)
        elif "⚠️" in status:
            data[i][1] = Paragraph(status, ps_warn)
        else:
            data[i][1] = Paragraph(status, ps_plan)
        data[i][0] = Paragraph(row[0], ps_body)
        data[i][2] = Paragraph(row[2], ps_body)

    col_w = [(W - 4*cm) * p for p in [0.37, 0.18, 0.45]]
    t = Table(data, colWidths=col_w, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, CARD_BG]),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
    ]))
    return t


def broadcast_options_table():
    """Comparison table for broadcast mechanism options."""
    data = [
        [Paragraph("<b>Option</b>", ParagraphStyle("th", fontName="Helvetica-Bold",
            fontSize=8.5, textColor=WHITE, leading=11)),
         Paragraph("<b>Verdict</b>", ParagraphStyle("th", fontName="Helvetica-Bold",
            fontSize=8.5, textColor=WHITE, leading=11)),
         Paragraph("<b>Reason</b>", ParagraphStyle("th", fontName="Helvetica-Bold",
            fontSize=8.5, textColor=WHITE, leading=11))],
        ["SSE (recommended)", "✅ Use this", "Already in codebase; HTTP-native; MCP-compatible"],
        ["WebSockets", "— Skip", "Bidirectional overkill for one-way broadcast"],
        ["Redis Pub/Sub", "— Skip", "External dependency; defeats local-first design"],
        ["NATS / ZeroMQ", "— Skip", "Operational burden; external infra required"],
        ["File polling", "— Skip", "5–30 s latency; burns CPU; SSE replaces it"],
        ["Long-polling /rep/entries", "— Skip", "Effectively reinvents SSE with worse UX"],
    ]
    ps_body = ParagraphStyle("td", fontName="Helvetica", fontSize=8.5,
                             textColor=GREY_DARK, leading=12)
    ps_yes = ParagraphStyle("ty", fontName="Helvetica-Bold", fontSize=8.5,
                            textColor=TEAL, leading=12)
    ps_no = ParagraphStyle("tn", fontName="Helvetica", fontSize=8.5,
                           textColor=GREY_MID, leading=12)
    for i, row in enumerate(data[1:], 1):
        v = row[1]
        data[i][0] = Paragraph(row[0], ps_body)
        data[i][1] = Paragraph(v, ps_yes if "✅" in v else ps_no)
        data[i][2] = Paragraph(row[2], ps_body)

    col_w = [(W - 4*cm) * p for p in [0.25, 0.18, 0.57]]
    t = Table(data, colWidths=col_w, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, CARD_BG]),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 7),
    ]))
    return t


# ── Q block builder ─────────────────────────────────────────────────────────

def q_block(number: str, question: str, styles) -> list:
    """Blue header card with question number and text."""
    data = [[
        Paragraph(f"Q{number}", styles["q_label"]),
        Paragraph(question, styles["q_text"]),
    ]]
    t = Table(data, colWidths=[1.4 * cm, W - 4 * cm - 1.4 * cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), BLUE),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 12),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 12),
        ("LEFTPADDING", (0, 0), (0, 0), 14),
        ("LEFTPADDING", (1, 0), (1, 0), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 12),
        ("ROUNDEDCORNERS", [5, 5, 5, 5]),
    ]))
    return [t, Spacer(1, 10)]


def callout_box(label: str, lines: list, styles, color=TEAL) -> Table:
    """Teal/amber side-bar callout for key points."""
    content = [Paragraph(f"<b>{label}</b>", styles["callout_bold"])]
    for l in lines:
        content.append(Paragraph(f"• {l}", styles["callout_text"]))
    accent = Table([[""]], colWidths=[4])
    accent.setStyle(TableStyle([("BACKGROUND", (0, 0), (0, 0), color)]))

    inner = Table([[c] for c in content],
                  colWidths=[W - 4*cm - 10 - 4])
    inner.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), CARD_BG),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]))
    outer = Table([[accent, inner]], colWidths=[4, W - 4*cm - 10 - 4])
    outer.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), CARD_BG),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
    ]))
    return outer


def code_block(text: str, styles) -> Table:
    lines = text.strip().splitlines()
    rows = [[Paragraph(l if l else " ", styles["code"])] for l in lines]
    t = Table(rows, colWidths=[W - 4*cm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), CODE_BG),
        ("TOPPADDING", (0, 0), (-1, -1), 1),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 1),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("ROUNDEDCORNERS", [4, 4, 4, 4]),
    ]))
    return t


# ── Cover page ──────────────────────────────────────────────────────────────

class FullBleedRect(Flowable):
    """A full-width colored rectangle spanning the page margins."""
    def __init__(self, height, color):
        Flowable.__init__(self)
        self.rect_h = height
        self.color = color
        self.width = W - 4 * cm
        self.height = height

    def draw(self):
        self.canv.setFillColor(self.color)
        self.canv.rect(-2 * cm, -2, W, self.rect_h + 4, fill=1, stroke=0)


def build_cover(styles) -> list:
    story = []
    # Dark hero block
    story.append(FullBleedRect(220, NAVY))
    story.append(Spacer(1, -220 + 30))
    story.append(cover_graphic())
    story.append(Spacer(1, 14))
    story.append(Paragraph("DevTorch FAQ", styles["cover_title"]))
    story.append(Paragraph("Multi-Agent Coordination & Real-Time Sync", styles["cover_sub"]))
    story.append(Spacer(1, 6))
    story.append(Paragraph("May 2026 · flotorch.ai", styles["cover_date"]))
    story.append(Spacer(1, 28))

    # Four topic pills
    topics = [
        ("Q1", "4–6 Agent Coordination"),
        ("Q2", "Offline Fallback Sync"),
        ("Q3", "Broadcast Mechanism"),
        ("Q4", "RACP vs REP"),
    ]
    pill_data = [[
        Paragraph(f"<b>{n}</b>  {t}", ParagraphStyle("pill",
            fontName="Helvetica", fontSize=9, textColor=NAVY, leading=12))
        for n, t in topics
    ]]
    pill_t = Table(pill_data, colWidths=[(W - 4*cm) / 4] * 4)
    pill_t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#DBEAFE")),
        ("BOX", (0, 0), (-1, -1), 0.5, BLUE),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, BLUE),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
    ]))
    story.append(pill_t)
    story.append(PageBreak())
    return story


# ── Q1 ───────────────────────────────────────────────────────────────────────

def build_q1(S) -> list:
    story = []
    story += q_block("1", "Will DevTorch work with 4–6 agents working concurrently on the same software — including a mix of AI agents and human developers?", S)

    story.append(Paragraph("Short answer: yes for sequential handoffs and mixed teams; concurrent writes need the Cloud MCP Server or the REP network.", S["bold_inline"]))
    story.append(Spacer(1, 6))

    story.append(Paragraph(
        "DevTorch treats humans and AI agents symmetrically. A human developer sets "
        "<font face='Courier' size='9'>DEVTORCH_AGENT_ID=alice</font> and their commits and "
        "sensitivity events are recorded identically to an AI agent's — with the same "
        "agent_id stamping, the same disclosure levels, and the same queryability via "
        "<font face='Courier' size='9'>devtorch_reasoning_query</font>. "
        "HITL channels (CLI and Slack) give humans a first-class way to respond to "
        "divergence consolidation requests, with their decision recorded as an auditable "
        "reasoning event.", S["body"]))

    story.append(Spacer(1, 4))
    story.append(concurrency_table())
    story.append(Paragraph("Status of multi-agent coordination scenarios.", S["caption"]))
    story.append(Spacer(1, 8))

    story.append(Paragraph("Where concurrency breaks", S["section_head"]))
    story.append(Paragraph(
        "The <font face='Courier' size='9'>.GCC/</font> store is local files with no locking. "
        "Three specific failure modes arise under simultaneous writes: "
        "(1) the hash-chained event log can be corrupted by interleaved appends; "
        "(2) <font face='Courier' size='9'>theta.json</font> is subject to lost-update races "
        "when two agents read-modify-write concurrently; "
        "(3) two agents calling <font face='Courier' size='9'>start_consolidation()</font> "
        "simultaneously on the same concept will each create a separate record, producing "
        "duplicate consolidation state. "
        "All three are resolved by routing writes through the Cloud MCP Server, which "
        "serialises access through a single server process.", S["body"]))

    story.append(callout_box("Human developers as first-class agents", [
        "Set DEVTORCH_AGENT_ID, DEVTORCH_AGENT_NAME, DEVTORCH_AGENT_SCOPE in shell profile",
        "Reasoning commits and sensitivity events are attributed and queryable",
        "HITL Slack channel delivers divergence requests; human responds via devtorch_hitl_respond",
        "Human's decision is stored with authorship in the ConsolidationRecord",
    ], S, color=TEAL))
    story.append(Spacer(1, 8))
    return story


# ── Q2 ───────────────────────────────────────────────────────────────────────

def build_q2(S) -> list:
    story = []
    story += q_block("2", "When DevTorch cannot connect to the Cloud MCP Server, is there a fallback that keeps local .GCC/ folders in sync across machines in real time?", S)

    story.append(Paragraph(
        "Yes — the codebase already contains a P2P sync layer called the "
        "<b>REP Network</b> (<font face='Courier' size='9'>devtorch_core/rep_network/</font>). "
        "It exposes HTTP push/pull endpoints on each machine so nodes can exchange "
        "reasoning events without a central server. Three fallback layers are available, "
        "ordered by ease of deployment:", S["body"]))

    story.append(Spacer(1, 6))
    story.append(sse_fallback_diagram())
    story.append(Paragraph(
        "Each machine runs a local SSE broadcaster fed by the file watcher. "
        "The REP sync bridge propagates events across machines on a configurable cadence.", S["caption"]))
    story.append(Spacer(1, 10))

    layers = [
        ("Option 1 — Git as sync bus (zero new code, works today)",
         "Put .GCC/ in the git repo. Agents run git pull/push on a cadence or via "
         "pre/post-commit hooks. The hash-chained event log survives git merges because "
         "commit IDs are deterministic — no two nodes produce the same ID. "
         "Not real-time, but reliable, auditable, and conflict-resolved by git."),
        ("Option 2 — REP Network peer sync (~1–2 days to harden)",
         "Each machine runs devtorch sync --interval 30, which calls sync_all_peers() "
         "in a loop. A theta.json merge function (sum event counts, take max confidence "
         "per concept) is the main gap. Tests for concurrent-write and merge scenarios "
         "are needed before production use."),
        ("Option 3 — Shared NFS volume (ops solution)",
         "Mount .GCC/ on a shared NFS volume. All agents read and write the same directory "
         "with OS-level file locking. Fragile under high write concurrency but requires "
         "no new code."),
    ]
    for title, desc in layers:
        story.append(Paragraph(f"<b>{title}</b>", S["body_nb"]))
        story.append(Paragraph(desc, S["body"]))
        story.append(Spacer(1, 2))

    story.append(callout_box("What REP network needs to be production-ready", [
        "theta.json merge function: sum event_count, take max mean_confidence per concept",
        "devtorch sync --interval <n> background daemon command",
        "Tests: concurrent-write safety, merge correctness, peer discovery",
        "Estimated effort: 1–2 days",
    ], S, color=AMBER))
    story.append(Spacer(1, 8))
    return story


# ── Q3 ───────────────────────────────────────────────────────────────────────

def build_q3(S) -> list:
    story = []
    story += q_block("3", "What do you recommend for the broadcast/subscription mechanism so agents are notified immediately when another agent records a new event?", S)

    story.append(Paragraph(
        "<b>Recommendation: SSE (Server-Sent Events)</b> — extend what is already built.", S["body_nb"]))
    story.append(Paragraph(
        "The Cloud MCP Server already uses SSE for its transport. Reusing the same "
        "mechanism for local broadcast means no new concepts for agents to learn, "
        "FastAPI is already a dependency, and the MCP protocol already consumes SSE streams. "
        "A file watcher (<font face='Courier' size='9'>watchdog</font> library) fires "
        "when <font face='Courier' size='9'>.GCC/events.log.jsonl</font> is appended to; "
        "the local SSE server pushes the new event to all subscribed agents within ~100 ms.", S["body"]))

    story.append(Spacer(1, 6))
    story.append(broadcast_options_table())
    story.append(Paragraph("Broadcast mechanism comparison.", S["caption"]))
    story.append(Spacer(1, 10))

    story.append(Paragraph("What needs to be built", S["section_head"]))
    story.append(Paragraph(
        "Three focused additions totalling approximately two days of work:", S["body"]))

    items = [
        ("File watcher", "watchdog library watches .GCC/events.log.jsonl. On append, parses "
         "the new line and puts it into the broadcaster's queue. Handles Linux (inotify), "
         "macOS (kqueue), and Windows (ReadDirectoryChangesW) with one import."),
        ("Local SSE broadcaster", "Small FastAPI app — ~60 lines — reusing the exact pattern "
         "from build_sse_app() in the cloud server. Exposes GET /events/stream. Each "
         "subscriber gets a queue; keepalive pings every 30 s."),
        ("REP sync bridge", "When pull_from_peer() in rep_network/sync.py receives new "
         "entries from a remote peer, it forwards them to the local broadcaster so agents "
         "on that machine are notified of cross-machine events within one sync cycle."),
    ]
    for title, desc in items:
        story.append(Paragraph(f"<b>{title}.</b>  {desc}", S["body"]))

    story.append(Spacer(1, 6))
    story.append(Paragraph("Event stream payload (filtered — coordination signals only):", S["body_nb"]))
    story.append(code_block("""\
{
  "event_type": "DIVERGENCE_DETECTED",
  "agent_id":   "agent-A",
  "concept":    "auth",
  "severity":   "HIGH",
  "timestamp":  "2026-05-13T09:14:22+00:00"
}""", S))
    story.append(Spacer(1, 6))

    story.append(callout_box("Design decision: filter the stream", [
        "Broadcast only coordination-relevant events: DIVERGENCE_DETECTED, CONSOLIDATION_STARTED, HITL_REQUEST, CONSENSUS_RESOLVED",
        "Raw SENSITIVITY_ADDED and COMMIT events stay in events.log.jsonl — too noisy for broadcast",
        "Agents subscribe once at session start; ignore event_types they don't need",
        "devtorch watch CLI command tails the stream as human-readable output",
    ], S, color=BLUE))
    story.append(Spacer(1, 8))
    return story


# ── Q4 ───────────────────────────────────────────────────────────────────────

def build_q4(S) -> list:
    story = []
    story += q_block("4", "What is the difference between RACP and REP?", S)

    story.append(Paragraph(
        "They operate at different layers and solve different problems. "
        "The one-line summary: <b>RACP is the language agents use to reason together. "
        "REP is the postal system that delivers their letters.</b>", S["body"]))

    story.append(Spacer(1, 8))
    story.append(racp_rep_diagram())
    story.append(Paragraph(
        "RACP operates at the LLM interaction layer. REP operates at the infrastructure "
        "transport layer. Neither can replace the other.", S["caption"]))
    story.append(Spacer(1, 10))

    story.append(Paragraph("RACP — Reasoning and Coordination Protocol", S["section_head"]))
    story.append(Paragraph(
        "RACP defines the protocol between the LLM and the .GCC/ store. It has three components:", S["body"]))

    racp_items = [
        ("The vocabulary",
         "The XML blocks an LLM emits to record decisions during a response:"),
        ("The injection contract",
         "Before every LLM call, RACPInjector prepends a system prefix containing the "
         "RACP prompt, the top Θ concepts by confidence, and the context bundle. "
         "The agent starts each turn already knowing what prior agents were sensitive about."),
        ("The coordination vector Θ",
         "The shared epistemic state that accumulates across sessions. "
         "Agent B sees not just what Agent A did, but what Agent A was worried about, "
         "at what confidence, under what disclosure level."),
    ]
    for title, desc in racp_items:
        story.append(Paragraph(f"<b>{title}.</b>  {desc}", S["body_nb"]))
        if title == "The vocabulary":
            story.append(code_block(
                '<devtorch:commit message="Chose JWT — stateless service"/>\n'
                '<devtorch:sensitivity concept="auth" signal="token expiry matters" '
                'confidence="0.9" disclosure="PROTECTED"/>',
                S))
        story.append(Spacer(1, 4))

    story.append(Paragraph("REP — Reasoning Exchange Protocol", S["section_head"]))
    story.append(Paragraph(
        "REP is the transport layer for moving captured records between nodes. "
        "A REPEnvelope wraps any reasoning event with a checksum and sender identity. "
        "The REPLedger is an append-only local log of envelopes. "
        "rep_network/ adds HTTP push/pull so one machine's ledger can replicate to another's. "
        "REP is agnostic to what is inside the envelope — it moves records reliably, "
        "deduplicates them by envelope_id, and verifies checksums on replay.", S["body"]))

    # Side-by-side comparison table
    comp_data = [
        [Paragraph("<b>RACP</b>", ParagraphStyle("ch", fontName="Helvetica-Bold",
            fontSize=9, textColor=WHITE, leading=12)),
         Paragraph("<b>REP</b>", ParagraphStyle("ch", fontName="Helvetica-Bold",
            fontSize=9, textColor=WHITE, leading=12))],
        ["Capture and coordination protocol", "Transport protocol"],
        ["Between LLM and .GCC/ store", "Between nodes (machines)"],
        ["Injection: Θ + context → LLM prompt", "Push/pull: ledger entries ↔ peers"],
        ["Capture: XML blocks → commits + events", "Envelope: event + checksum + sender"],
        ["Coordination vector Θ", "REP ledger (append-only, replay-safe)"],
        ["Answers: what to capture and how", "Answers: how to move records between nodes"],
    ]
    ps_c = ParagraphStyle("td", fontName="Helvetica", fontSize=8.5,
                          textColor=GREY_DARK, leading=12)
    for i, row in enumerate(comp_data[1:], 1):
        comp_data[i] = [Paragraph(row[0], ps_c), Paragraph(row[1], ps_c)]

    cw = [(W - 4 * cm) / 2] * 2
    ct = Table(comp_data, colWidths=cw, repeatRows=1)
    ct.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (0, 0), BLUE),
        ("BACKGROUND", (1, 0), (1, 0), TEAL),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, CARD_BG]),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("LINEAFTER", (0, 0), (0, -1), 1, BORDER),
    ]))
    story.append(ct)
    story.append(Spacer(1, 10))

    story.append(callout_box("The analogy", [
        "RACP is like HTTP — the protocol for how reasoning is expressed and consumed",
        "REP is like TCP/IP — the transport for moving that reasoning between nodes",
        "A system with only RACP has no way to share reasoning across machines",
        "A system with only REP has envelopes to transport but no protocol for what goes in them",
    ], S, color=NAVY))
    story.append(Spacer(1, 8))
    return story


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    doc = SimpleDocTemplate(
        str(OUT),
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=2.8 * cm,
        bottomMargin=2.5 * cm,
        title="DevTorch FAQ — Multi-Agent Coordination",
        author="DevTorch · flotorch.ai",
        subject="Multi-Agent Coordination, Sync, Broadcast, RACP vs REP",
    )

    S = make_styles()
    story = []
    story += build_cover(S)
    story += build_q1(S)
    story.append(HRFlowable(width="100%", thickness=0.5, color=BORDER,
                            spaceAfter=14, spaceBefore=6))
    story += build_q2(S)
    story.append(HRFlowable(width="100%", thickness=0.5, color=BORDER,
                            spaceAfter=14, spaceBefore=6))
    story += build_q3(S)
    story.append(HRFlowable(width="100%", thickness=0.5, color=BORDER,
                            spaceAfter=14, spaceBefore=6))
    story += build_q4(S)

    doc.build(story, onFirstPage=_header_footer, onLaterPages=_header_footer)
    print(f"✓ PDF written → {OUT}")


if __name__ == "__main__":
    main()
