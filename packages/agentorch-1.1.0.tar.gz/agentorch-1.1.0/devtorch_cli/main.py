from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from devtorch_core import (
    GCCRepository,
    SensitivityEvent,
    OmegaCapability,
    L_MAX_DEFAULT,
)


def cmd_init(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    repo.init()
    print(f"Initialized DevTorch GCC store at {repo.gcc_dir}")
    return 0


def cmd_commit(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        repo.commit(message=args.message or "")
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Recorded commit in {repo.gcc_dir}")
    return 0


def cmd_doctor(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    issues = repo.doctor()
    if not issues:
        print("devtorch doctor: OK")
        return 0
    print("devtorch doctor: found issues:")
    for issue in issues:
        print(f"- [{issue.kind}] {issue.message}")
    return 1


def cmd_branch(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        repo.create_branch(args.name, from_ref=args.from_ref)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Created branch `{args.name}`.")
    return 0


def cmd_history(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    history = repo.history(branch=args.branch)
    if not history:
        print("No commits.")
        return 0
    for commit in history:
        cid = commit.get("id")
        msg = commit.get("message", "")
        br = commit.get("branch")
        parent = commit.get("parent")
        ts = commit.get("timestamp")
        print(f"{cid} [{br}] parent={parent} {ts} :: {msg}")
    return 0


def cmd_merge(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        repo.merge_fast_forward(source=args.source, target=args.target)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Merged `{args.source}` into `{args.target or repo._current_branch()}` (fast-forward).")
    return 0


def cmd_context(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        bundle = repo.context_bundle(
            k_tokens=args.k,
            policy={"sensitivity_policy": args.policy},
            branch=args.branch,
            explain=args.explain,
        )
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1

    print(f"Context bundle for branch `{bundle['branch']}` "
          f"(approx {bundle['approx_tokens_used']}/{bundle['k_tokens']} tokens):")
    for art in bundle["artifacts"]:
        print(f"- {art['path']} :: {art['reason']} "
              f"(~{art['approx_tokens']} tokens)")
    if args.explain and "bundle_path" in bundle:
        print(f"Bundle persisted as `.GCC/{bundle['bundle_path']}`")
    return 0


def cmd_sensitivity_add(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        event = SensitivityEvent(
            source_node=args.source,
            target_concept=args.concept,
            counterfactuals=args.counterfactuals or "",
            confidence=args.confidence,
            disclosure_level=args.disclosure.upper(),
            numerical_value=args.numerical,
            uncertainty=args.uncertainty,
            message=args.message or "",
        )
        event_id = repo.add_sensitivity(event)
    except (ValueError, RuntimeError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Sensitivity recorded (id={event_id}).")
    return 0


def cmd_sensitivity_list(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        events = repo.list_sensitivities(
            concept=args.concept,
            disclosure_level=args.disclosure.upper() if args.disclosure else None,
            source_node=args.source_node,
        )
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if not events:
        print("No sensitivity events found.")
        return 0
    for ev in events:
        num = f" num={ev['numerical_value']}" if ev.get("numerical_value") is not None else ""
        print(
            f"[{ev['disclosure_level']}] {ev['source_node']} → {ev['target_concept']} "
            f"conf={ev['confidence']}{num}  id={ev['event_id']}"
        )
    return 0


def cmd_sensitivity_filter(args: argparse.Namespace) -> int:
    """Alias for `sensitivity list` with a mandatory --disclosure filter."""
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        events = repo.list_sensitivities(
            concept=args.concept,
            disclosure_level=args.disclosure.upper() if args.disclosure else None,
            source_node=args.source_node,
        )
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    theta = repo.get_theta()
    cv = theta.get("coordination_vector", {})

    print(f"Filtered sensitivities (disclosure={args.disclosure or 'any'}, "
          f"concept={args.concept or 'any'}):")
    for ev in events:
        num = f" num={ev['numerical_value']}" if ev.get("numerical_value") is not None else ""
        print(
            f"  [{ev['disclosure_level']}] {ev['source_node']} → {ev['target_concept']} "
            f"conf={ev['confidence']}{num}"
        )
    print(f"\nΘ coordination vector (all concepts):")
    for concept, entry in cv.items():
        print(
            f"  {concept}: mean_conf={entry['mean_confidence']} "
            f"level={entry['disclosure_level']} n={entry['event_count']}"
        )
    return 0


def cmd_capability_set(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        cap = OmegaCapability(
            agent_id=args.agent_id,
            lipschitz_bound=args.lipschitz_bound,
            calibration_dataset_hash=args.calibration_hash,
            embedding_model=args.embedding_model,
            calibration_date=args.calibration_date,
            temperature_used=args.temperature,
            lipschitz_p95=args.lipschitz_p95,
            expiry_days=args.expiry_days,
        )
        repo.set_capability(cap)
    except (ValueError, RuntimeError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Capability declaration set for agent '{cap.agent_id}'.")
    return 0


def cmd_capability_show(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        cap = repo.get_capability()
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if cap is None:
        print("No capability declaration set. Run `devtorch capability set` first.")
        return 1
    print(f"Ωᵢ capability for agent '{cap['agent_id']}':")
    for key in (
        "schema_version", "lipschitz_bound", "lipschitz_p95",
        "embedding_model", "calibration_date", "temperature_used",
        "expiry_days", "pst_status", "pst_score",
        "pst_n_prompts", "pst_n_repetitions", "calibration_dataset_hash",
        "created_at", "updated_at",
    ):
        val = cap.get(key)
        if val is not None:
            print(f"  {key}: {val}")
    return 0


def cmd_capability_validate(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        result = repo.validate_capability(l_max=args.l_max)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if result["textual_mode_allowed"]:
        print(f"Capability valid. Textual Mode: ALLOWED (agent={result['agent_id']}).")
        return 0
    print(f"Capability DEGRADED. Textual Mode: BLOCKED (agent={result['agent_id']}).")
    for reason in result["reasons"]:
        print(f"  - {reason}")
    return 1


# Sprint 4: lock, unlock, invariant, concept, variance

def cmd_lock(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        repo.lock(reason=args.reason or "", required_peer_count=args.peers)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print("Consensus lock acquired.")
    return 0


def cmd_unlock(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        repo.unlock()
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print("Consensus lock released.")
    return 0


def cmd_invariant_check(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        concepts_raw = (args.concepts or "").strip()
        concepts_used = [c.strip() for c in concepts_raw.split(",") if c.strip()] or None
        failures = repo.invariant_check(
            operation=args.operation or "merge",
            branch_tips=None,
            concepts_used=concepts_used,
        )
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if not failures:
        print("All invariant checks passed.")
        return 0
    print("Invariant check(s) failed:")
    for f in failures:
        print(f"  [{f.invariant_id}] {f.message}")
        print(f"    Fix: {f.actionable_fix}")
    return 1


def cmd_concept_add(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        repo.concept_add(args.name, args.definition)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Concept '{args.name}' registered.")
    return 0


def cmd_concept_list(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        names = repo.concept_list()
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if not names:
        print("No concepts registered.")
        return 0
    for n in names:
        print(n)
    return 0


def cmd_variance_calibrate(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    # Parse agent variances: key=value[,key=value...]
    agent_variances = {}
    if getattr(args, "variances", None):
        for part in args.variances.split(","):
            part = part.strip()
            if "=" in part:
                k, v = part.split("=", 1)
                agent_variances[k.strip()] = float(v.strip())
    try:
        report = repo.variance_calibrate(agent_variances)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Variance calibration: n={report.n}, σ²_obs={report.sigma_sq_obs:.4f}, f_max={report.f_max}")
    return 0


def cmd_variance_monitor(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    agent_variances = None
    if getattr(args, "variances", None):
        agent_variances = {}
        for part in args.variances.split(","):
            part = part.strip()
            if "=" in part:
                k, v = part.split("=", 1)
                agent_variances[k.strip()] = float(v.strip())
    try:
        result = repo.variance_monitor_run(agent_variances)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Variance monitor: f_max_live={result['f_max_live']}, previous_f_max={result.get('previous_f_max')}, "
          f"σ²_obs={result.get('sigma_sq_obs', 0):.4f}, alert_emitted={result.get('alert_emitted')}, "
          f"deterministic_mode_forced={result.get('deterministic_mode_forced')}")
    return 0


# Sprint 5: REP, SIS-TC, prompt, deltaf, RDP, disclosure

def cmd_rep_append(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        payload = json.loads(args.payload) if args.payload else {}
        seq = repo.rep_append(args.agent_id, args.round_id, payload, trust=args.trust or 0.5)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"REP envelope appended (sequence_id={seq}).")
    return 0


def cmd_rep_checksum(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    cs = repo.rep_replay_checksum()
    if not cs:
        print("No REP ledger or repo not initialized.")
        return 0
    print(cs)
    return 0


def cmd_sis_tc_run(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        report = repo.sis_tc_run(corpus_path=Path(args.corpus) if getattr(args, "corpus", None) else None)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"SIS-TC report: n={report.n_total}, FPR={report.fpr:.4f}, FNR={report.fnr:.4f}")
    return 0


def cmd_prompt_set(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    content = args.content if hasattr(args, "content") and args.content else ""
    if not content and hasattr(args, "file") and args.file:
        content = Path(args.file).read_text(encoding="utf-8")
    try:
        repo.prompt_set(content, version=getattr(args, "version", "v2.1") or "v2.1")
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print("RACP_SYSTEM_PROMPT_v2.1 stored.")
    return 0


def cmd_prompt_show(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    content = repo.prompt_get()
    if content is None:
        print("No system prompt set.")
        return 0
    print(content)
    return 0


def cmd_deltaf_run(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        report = repo.deltaf_run(expiry_days=getattr(args, "expiry_days", None) or 90)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Δf report: delta_f={report.delta_f}, expiry={report.expiry_date}")
    return 0


def cmd_rdp_spend(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        allowed, event = repo.rdp_spend(args.round_id, args.epsilon)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if not allowed:
        print(f"Privacy budget exhausted: {event}")
        return 1
    print("Epsilon spend recorded.")
    return 0


def cmd_rdp_status(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    ro = repo.rdp_read_only()
    print("read_only=True" if ro else "read_only=False")
    return 0


def cmd_disclosure_redact(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    text = args.text if getattr(args, "text", None) else sys.stdin.read()
    try:
        out = repo.disclosure_redact(text, padding_length=getattr(args, "padding", None))
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(out, end="")
    return 0


# Sprint 19: reasoning subcommand

def cmd_reasoning_show(args: argparse.Namespace) -> int:
    from devtorch_core.mcp.server import _tool_devtorch_reasoning_query
    gcc = GCCRepository.at(Path(args.path).resolve())
    result = _tool_devtorch_reasoning_query(gcc, {
        "concept": args.concept,
        "agent_id": args.agent_id,
        "k": args.tokens,
    })
    print(result)
    return 0


# Sprint 9: status command

def cmd_status(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())

    # 1. Current branch
    branch = repo._current_branch()

    # 2. Last commit
    history = repo.history(branch=None)
    if history:
        last = history[0]
        commit_id = (last.get("id") or "")[:7]
        commit_msg = last.get("message", "")
        commit_str = f'{commit_id} "{commit_msg}"'
    else:
        commit_str = "(no commits)"

    print(f'Branch: {branch}  |  Last commit: {commit_str}')

    # 3. Top 5 Θ hot zones by mean_confidence
    theta = repo.get_theta()
    cv = theta.get("coordination_vector", {})
    sorted_cv = sorted(cv.items(), key=lambda kv: kv[1].get("mean_confidence", 0), reverse=True)
    hot_zones = "  ".join(
        f"{concept} ({entry['mean_confidence']:.2f})"
        for concept, entry in sorted_cv[:5]
    )
    print(f"Θ hot zones: {hot_zones or '(none)'}")

    # 4. Node state
    node_state_path = repo.gcc_dir / "NODE_STATE"
    if node_state_path.exists():
        node_state = node_state_path.read_text(encoding="utf-8").strip()
    else:
        node_state = "UNKNOWN"
    print(f"Node state: {node_state}")

    # 5. Invariant summary
    try:
        failures = repo.invariant_check(operation="status")
        if not failures:
            print("Invariants: \u2713 clear")
        else:
            print(f"Invariants: {len(failures)} failure(s):")
            for f in failures:
                print(f"  [{f.invariant_id}] {f.message}")
    except Exception as e:
        print(f"Invariants: ERROR ({e})")

    # 6. Consensus lock status
    locked = repo.is_locked()
    print(f"Lock: {'LOCKED' if locked else 'UNLOCKED'}")

    return 0


# Sprint 9: log command

def cmd_log(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    log_path = repo.gcc_dir / "log.md"

    if not log_path.exists():
        print("No log found. Run `devtorch init` first.")
        return 0

    if getattr(args, "branch", None):
        print("(branch filter not yet supported — log.md is global)")

    content = log_path.read_text(encoding="utf-8")
    lines = content.splitlines()

    tail = getattr(args, "tail", None)
    if tail is not None:
        lines = lines[-tail:]

    print("\n".join(lines))
    return 0


# S7: proxy subcommand (server in devtorch_core/proxy/)

def cmd_proxy_start(args: argparse.Namespace) -> int:
    port = getattr(args, "port", 8765)
    host = getattr(args, "host", "127.0.0.1")
    try:
        from devtorch_core.proxy.server import run_proxy
        run_proxy(port=port, host=host)
    except ImportError:
        print("Install proxy deps: pip install devtorch[proxy]")
        return 1
    return 0


def cmd_proxy_stop(args: argparse.Namespace) -> int:
    print("The proxy runs in the foreground. To stop it:")
    print("  - Press Ctrl+C in the terminal where it is running, or")
    print("  - Find the PID with `lsof -i :8765` and run `kill <PID>`.")
    return 0


def cmd_proxy_install(args: argparse.Namespace) -> int:
    try:
        from devtorch_core.proxy.server import install_service
        install_service()
    except ImportError:
        print("Install proxy deps: pip install devtorch[proxy]")
        return 1
    return 0


def cmd_proxy_status(args: argparse.Namespace) -> int:
    import socket
    port = 8765
    try:
        with socket.create_connection(("127.0.0.1", port), timeout=1):
            print(f"Proxy running on :{port}")
    except (ConnectionRefusedError, OSError):
        print("Proxy not running")
    return 0


# Sprint 6: debug views

def cmd_debug_timeline(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    filter_types = None
    if getattr(args, "filter", None):
        filter_types = [t.strip() for t in args.filter.split(",") if t.strip()]
    events = repo.debug_timeline(filter_types=filter_types)
    for e in events:
        ts = e.get("timestamp", "")
        et = e.get("event_type", "")
        payload = e.get("payload", {})
        print(f"{ts}  {et}  {payload}")
    return 0


def cmd_debug_branch_compare(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    b1 = args.branch1
    b2 = args.branch2
    try:
        data = repo.debug_branch_compare(b1, b2)
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    print(f"Branch: {b1}")
    for c in data["branch1"]:
        print(f"  {c.get('id')}  {c.get('timestamp')}  {c.get('message')}")
    print(f"\nBranch: {b2}")
    for c in data["branch2"]:
        print(f"  {c.get('id')}  {c.get('timestamp')}  {c.get('message')}")
    print("\nΘ (coordination vector):")
    for k, v in (data.get("theta") or {}).items():
        print(f"  {k}: {v}")
    return 0


def cmd_debug_invariant_trace(args: argparse.Namespace) -> int:
    repo = GCCRepository.at(Path(args.path).resolve())
    try:
        traces = repo.debug_invariant_trace()
    except RuntimeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    if not traces:
        print("No invariant failures (trace clear).")
        return 0
    print("Invariant trace (failures):")
    for t in traces:
        print(f"  [{t['invariant_id']}] {t['message']}")
        print(f"    Fix: {t['actionable_fix']}")
    return 1


_CLAUDE_MD_BLOCK = """
## DevTorch — Reasoning Capture

This project uses DevTorch for AI governance. Follow these rules on every task:

1. **Before writing code**: call `devtorch_commit` (MCP tool) with your reasoning.
   Include what you decided and why, not just what you did.

2. **When touching sensitive areas** (auth, payments, database schema, secrets,
   PII, external APIs): call `devtorch_sensitivity_add` with the concept name,
   your confidence (0–1), and disclosure level (PUBLIC / PROTECTED / PRIVATE).

3. **At the start of a new task**: call `devtorch_context` to retrieve prior
   decisions before making new ones.
"""

_MCP_SERVER_ENTRY = {
    "devtorch": {
        "command": "devtorch",
        "args": ["mcp-server"],
    }
}


def cmd_setup(args: argparse.Namespace) -> int:
    """
    One-command setup: init + hooks + MCP server config + optional CLAUDE.md.
    Idempotent — safe to run on an already-configured project.
    """
    import shutil

    project_root = Path(args.path).resolve()
    ok_mark = "✓"
    skip_mark = "–"
    fail_mark = "✗"

    print("DevTorch setup\n")

    # ------------------------------------------------------------------ #
    # Step 1: devtorch init
    # ------------------------------------------------------------------ #
    repo = GCCRepository.at(project_root)
    if repo.is_initialized():
        print(f"  {skip_mark}  .GCC/  already initialized — skipping")
    else:
        try:
            repo.init()
            print(f"  {ok_mark}  .GCC/  initialized at {repo.gcc_dir}")
        except Exception as exc:
            print(f"  {fail_mark}  .GCC/  init failed: {exc}", file=sys.stderr)
            return 1

    # ------------------------------------------------------------------ #
    # Step 2: Claude Code hooks (.claude/hooks.json)
    # ------------------------------------------------------------------ #
    from devtorch_core.hooks.installer import install_all_hooks, get_hooks_status

    hooks_status = get_hooks_status(str(project_root))
    if hooks_status["claude_hooks"]:
        print(f"  {skip_mark}  .claude/hooks.json  already installed — skipping")
    else:
        result = install_all_hooks(str(project_root))
        if result.claude_hooks_written:
            print(f"  {ok_mark}  .claude/hooks.json  written")
        else:
            err = result.errors[0] if result.errors else "unknown error"
            print(f"  {fail_mark}  .claude/hooks.json  failed: {err}")

    if hooks_status["git_hook"]:
        print(f"  {skip_mark}  .git/hooks/commit-msg  already installed — skipping")
    elif not hooks_status["claude_hooks"]:
        # result was assigned in the else-branch above
        if result.git_hook_written:
            print(f"  {ok_mark}  .git/hooks/commit-msg  written")
        else:
            print(f"  {skip_mark}  .git/hooks/commit-msg  no .git repo found (skipped)")
    else:
        print(f"  {skip_mark}  .git/hooks/commit-msg  no .git repo found (skipped)")

    # ------------------------------------------------------------------ #
    # Step 3: Claude Code MCP server (.claude/settings.json)
    # ------------------------------------------------------------------ #
    claude_dir = project_root / ".claude"
    claude_dir.mkdir(parents=True, exist_ok=True)
    settings_path = claude_dir / "settings.json"

    try:
        existing_settings: dict = {}
        if settings_path.exists():
            try:
                existing_settings = json.loads(settings_path.read_text(encoding="utf-8"))
            except Exception:
                existing_settings = {}

        mcp_servers = existing_settings.setdefault("mcpServers", {})
        if "devtorch" in mcp_servers:
            print(f"  {skip_mark}  .claude/settings.json  MCP entry already present — skipping")
        else:
            mcp_servers["devtorch"] = _MCP_SERVER_ENTRY["devtorch"]
            settings_path.write_text(
                json.dumps(existing_settings, indent=2), encoding="utf-8"
            )
            print(f"  {ok_mark}  .claude/settings.json  MCP server entry added")
    except Exception as exc:
        print(f"  {fail_mark}  .claude/settings.json  failed: {exc}", file=sys.stderr)

    # ------------------------------------------------------------------ #
    # Step 4: CLAUDE.md DevTorch instructions
    # ------------------------------------------------------------------ #
    if not getattr(args, "skip_claude_md", False):
        claude_md_path = project_root / "CLAUDE.md"
        marker = "## DevTorch"
        if claude_md_path.exists() and marker in claude_md_path.read_text(encoding="utf-8"):
            print(f"  {skip_mark}  CLAUDE.md  DevTorch section already present — skipping")
        else:
            try:
                with claude_md_path.open("a", encoding="utf-8") as f:
                    f.write(_CLAUDE_MD_BLOCK)
                action = "appended to" if claude_md_path.stat().st_size > len(_CLAUDE_MD_BLOCK) else "created"
                print(f"  {ok_mark}  CLAUDE.md  DevTorch instructions {action}")
            except Exception as exc:
                print(f"  {fail_mark}  CLAUDE.md  failed: {exc}", file=sys.stderr)

    # ------------------------------------------------------------------ #
    # Step 5: AGENTS.md DevTorch instructions (Google Antigravity)
    # ------------------------------------------------------------------ #
    if not getattr(args, "skip_agents_md", False):
        from devtorch_core.hooks.installer import install_agents_md
        agents_md_path = project_root / "AGENTS.md"
        marker = "## DevTorch"
        if agents_md_path.exists() and marker in agents_md_path.read_text(encoding="utf-8"):
            print(f"  {skip_mark}  AGENTS.md  DevTorch section already present — skipping")
        else:
            ok, path_or_err = install_agents_md(str(project_root))
            if ok:
                action = "appended to" if agents_md_path.exists() and agents_md_path.stat().st_size > len(
                    "\n## DevTorch"
                ) else "created"
                print(f"  {ok_mark}  AGENTS.md  DevTorch instructions {action}")
            else:
                print(f"  {fail_mark}  AGENTS.md  failed: {path_or_err}", file=sys.stderr)

    # ------------------------------------------------------------------ #
    # Step 6: Cursor MCP config (.cursor/mcp.json)
    # ------------------------------------------------------------------ #
    target = getattr(args, "target", "claude-code")
    if target == "cursor":
        from devtorch_core.hooks.installer import install_cursor_mcp
        cursor_mcp = project_root / ".cursor" / "mcp.json"
        already = (
            cursor_mcp.exists()
            and "devtorch" in json.loads(cursor_mcp.read_text()).get("mcpServers", {})
        )
        if already:
            print(f"  {skip_mark}  .cursor/mcp.json  MCP entry already present — skipping")
        else:
            ok, path_or_err = install_cursor_mcp(str(project_root))
            if ok:
                print(f"  {ok_mark}  .cursor/mcp.json  MCP server entry added")
            else:
                print(f"  {fail_mark}  .cursor/mcp.json  failed: {path_or_err}", file=sys.stderr)
        print()
        print("  Next: install the VS Code extension in Cursor:")
        print("    Extensions: Install from VSIX... →")
        print("    extensions/vscode/devtorch-0.1.0.vsix")

    # ------------------------------------------------------------------ #
    # Step 7: Antigravity MCP config (mcp_config.json)
    # ------------------------------------------------------------------ #
    elif target == "antigravity":
        from devtorch_core.hooks.installer import install_antigravity_mcp
        ag_mcp = project_root / "mcp_config.json"
        already = (
            ag_mcp.exists()
            and "devtorch" in json.loads(ag_mcp.read_text()).get("mcpServers", {})
        )
        if already:
            print(f"  {skip_mark}  mcp_config.json  MCP entry already present — skipping")
        else:
            ok, path_or_err = install_antigravity_mcp(str(project_root))
            if ok:
                print(f"  {ok_mark}  mcp_config.json  MCP server entry added")
            else:
                print(f"  {fail_mark}  mcp_config.json  failed: {path_or_err}", file=sys.stderr)

    # ------------------------------------------------------------------ #
    # Done
    # ------------------------------------------------------------------ #
    print()
    print("Setup complete. Start Claude Code and run: devtorch status")
    if not shutil.which("devtorch"):
        print()
        print("  NOTE: 'devtorch' not found in PATH.")
        print("  Activate your venv first: source .venv/bin/activate")
    return 0


def cmd_calibrate(args: argparse.Namespace) -> int:
    from devtorch_core.metrics.calibrate import CalibrationStore, run_calibrate_wizard

    gcc_dir = Path(args.path).resolve() / ".GCC"

    if getattr(args, "set_value", None):
        # Parse KEY=VALUE
        raw = args.set_value.strip()
        if "=" not in raw:
            print(f"error: --set expects KEY=VALUE, got: {raw!r}", file=sys.stderr)
            return 1
        key, _, value_str = raw.partition("=")
        key = key.strip()
        value_str = value_str.strip()
        # Try numeric coercion
        try:
            value: object = float(value_str)
        except ValueError:
            value = value_str
        try:
            store = CalibrationStore(gcc_dir)
            store.set_value(key, value)
            print(f"Calibration set: {key} = {value}")
        except Exception as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 1
        return 0

    # Interactive wizard
    try:
        result = run_calibrate_wizard(gcc_dir)
        print("Calibration saved:")
        for k, v in sorted(result.items()):
            print(f"  {k}: {v}")
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


def cmd_metrics(args: argparse.Namespace) -> int:
    import glob as _glob

    from devtorch_core.metrics.calibrate import CalibrationStore
    from devtorch_core.metrics.shadow_ai import detect_shadow_ai
    from devtorch_core.metrics.dhs import compute_dhs, DHSComponents, dhs_to_label

    repo_root = Path(args.path).resolve()
    gcc_dir = repo_root / ".GCC"

    # Parse period
    period_str = getattr(args, "period", "30d")
    try:
        period_days = int(period_str.rstrip("d"))
    except (ValueError, AttributeError):
        period_days = 30

    # Load calibration
    try:
        store = CalibrationStore(gcc_dir)
        calibration = store.load()
    except Exception:
        calibration = {}

    # Read session metrics
    session_dir = gcc_dir / "metrics" / "session"
    session_files: list[dict] = []
    if session_dir.exists():
        for p in session_dir.glob("*.json"):
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    session_files.append(data)
            except Exception:
                pass

    # Read sprint metrics
    sprint_dir = gcc_dir / "metrics" / "sprint"
    sprint_files: list[dict] = []
    if sprint_dir.exists():
        for p in sprint_dir.glob("*.json"):
            try:
                data = json.loads(p.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    sprint_files.append(data)
            except Exception:
                pass

    # Shadow AI detection
    try:
        shadow = detect_shadow_ai(repo_root)
    except Exception:
        shadow = {"git_commits": 0, "gcc_commits": 0, "unregistered": 0, "shadow_ratio": 0.0, "flagged": False}

    # DHS computation (best-effort from available data)
    try:
        components = DHSComponents(
            commit_health=1.0 if (shadow.get("gcc_commits", 0) > 0) else 0.0,
            sensitivity_health=1.0,
            capability_health=0.0,
            variance_health=1.0,
        )
        dhs_score = compute_dhs(components)
        dhs_label = dhs_to_label(dhs_score)
    except Exception:
        dhs_score = 0.0
        dhs_label = "UNAVAILABLE"

    # Aggregate session data
    total_tokens_used = sum(s.get("tokens_used", 0) for s in session_files)
    total_tokens_saved = sum(s.get("tokens_saved", 0) for s in session_files)
    avg_coverage = (
        sum(s.get("coverage", 0.0) for s in session_files) / len(session_files)
        if session_files else 0.0
    )
    # Aggregate confidence distribution
    conf_dist: dict[str, int] = {}
    for s in session_files:
        for tier, cnt in (s.get("confidence_distribution") or {}).items():
            conf_dist[tier] = conf_dist.get(tier, 0) + int(cnt)

    # Aggregate sprint data
    avg_mcs = (
        sum(sp.get("mcs_score", 0.0) for sp in sprint_files) / len(sprint_files)
        if sprint_files else 0.0
    )
    total_i3_violations = sum(sp.get("i3_violations", 0) for sp in sprint_files)
    total_collisions_prevented = sum(sp.get("collisions_prevented", 0) for sp in sprint_files)

    # Auditability: fraction of git commits that are GCC-registered
    git_commits = shadow.get("git_commits", 0)
    gcc_commits = shadow.get("gcc_commits", 0)
    auditability = gcc_commits / git_commits if git_commits > 0 else 1.0

    disclosure = (
        "\nNOTE: MCS/DHS weights are DevTorch design choices pending empirical calibration."
    )

    if getattr(args, "as_json", False):
        output = {
            "period_days": period_days,
            "calibration": calibration,
            "developer": {
                "tokens_used": {"value": total_tokens_used, "tier": "MEASURED"},
                "tokens_saved": {"value": total_tokens_saved, "tier": "CALIBRATED"},
                "coverage_pct": {"value": round(avg_coverage * 100, 1), "tier": "MEASURED"},
                "confidence_distribution": {"value": conf_dist, "tier": "MEASURED"},
            },
            "tech_lead": {
                "mcs_trend": {"value": round(avg_mcs, 4), "tier": "CALIBRATED"},
                "i3_violations": {"value": total_i3_violations, "tier": "MEASURED"},
                "collisions_prevented": {"value": total_collisions_prevented, "tier": "CALIBRATED"},
            },
            "ciso": {
                "dhs_score": {"value": round(dhs_score, 4), "label": dhs_label, "tier": "CALIBRATED"},
                "shadow_ai_ratio": {"value": round(shadow.get("shadow_ratio", 0.0), 4), "flagged": shadow.get("flagged", False), "tier": "MEASURED"},
                "auditability_pct": {"value": round(auditability * 100, 1), "tier": "MEASURED"},
            },
            "shadow_ai": shadow,
            "disclosure": disclosure.strip(),
        }
        print(json.dumps(output, indent=2))
        return 0

    # Formatted output
    print(f"DevTorch Metrics Summary  (period: {period_days}d)\n")
    print("=== Developer ===")
    print(f"  Tokens used:   {total_tokens_used:,}  [MEASURED]")
    print(f"  Tokens saved:  {total_tokens_saved:,}  [CALIBRATED]")
    print(f"  Coverage:      {avg_coverage * 100:.1f}%  [MEASURED]")
    if conf_dist:
        conf_str = "  ".join(f"{t}:{c}" for t, c in sorted(conf_dist.items()))
        print(f"  Confidence:    {conf_str}  [MEASURED]")
    else:
        print("  Confidence:    (no session data)  [UNAVAILABLE]")

    print("\n=== Tech Lead ===")
    print(f"  MCS trend:             {avg_mcs:.4f}  [CALIBRATED]")
    print(f"  I3 violations:         {total_i3_violations}  [MEASURED]")
    print(f"  Collisions prevented:  {total_collisions_prevented}  [CALIBRATED]")

    print("\n=== CISO ===")
    print(f"  DHS score:        {dhs_score:.4f} ({dhs_label})  [CALIBRATED]")
    shadow_ratio = shadow.get("shadow_ratio", 0.0)
    flagged_str = " *** FLAGGED ***" if shadow.get("flagged") else ""
    print(f"  Shadow AI ratio:  {shadow_ratio:.4f}{flagged_str}  [MEASURED]")
    print(f"  Auditability:     {auditability * 100:.1f}%  [MEASURED]")

    print(disclosure)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="devtorch", description="DevTorch OSS substrate CLI (Sprint 0)")
    parser.add_argument(
        "-C",
        "--path",
        default=".",
        help="Path to the repository root (default: current directory).",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    # One-command setup: init + hooks + MCP + CLAUDE.md
    p_setup = subparsers.add_parser(
        "setup",
        help="One-command setup: init + MCP server config + IDE-specific wiring.",
    )
    p_setup.add_argument(
        "--target",
        choices=["claude-code", "cursor", "antigravity"],
        default="claude-code",
        help="IDE to configure (default: claude-code).",
    )
    p_setup.add_argument(
        "--skip-claude-md",
        dest="skip_claude_md",
        action="store_true",
        help="Skip writing the DevTorch section to CLAUDE.md.",
    )
    p_setup.add_argument(
        "--skip-agents-md",
        dest="skip_agents_md",
        action="store_true",
        help="Skip writing the DevTorch section to AGENTS.md (Google Antigravity).",
    )
    p_setup.set_defaults(func=cmd_setup)

    p_init = subparsers.add_parser("init", help="Initialize the .GCC layout.")
    p_init.set_defaults(func=cmd_init)

    p_commit = subparsers.add_parser("commit", help="Record a reasoning commit (Sprint 0 happy path).")
    p_commit.add_argument("-m", "--message", help="Commit message.", default="")
    p_commit.set_defaults(func=cmd_commit)

    p_doctor = subparsers.add_parser("doctor", help="Validate .GCC layout and event log integrity.")
    p_doctor.set_defaults(func=cmd_doctor)

    p_branch = subparsers.add_parser("branch", help="Create a new branch.")
    p_branch.add_argument("name", help="New branch name.")
    p_branch.add_argument("--from-ref", help="Commit ID to start from (default: current tip).", default=None)
    p_branch.set_defaults(func=cmd_branch)

    p_history = subparsers.add_parser("history", help="Show commit history.")
    p_history.add_argument("--branch", help="Branch name (default: current branch).", default=None)
    p_history.set_defaults(func=cmd_history)

    p_merge = subparsers.add_parser("merge", help="Fast-forward merge source into target branch.")
    p_merge.add_argument("source", help="Source branch name.")
    p_merge.add_argument(
        "--target",
        help="Target branch name (default: current branch).",
        default=None,
    )
    p_merge.set_defaults(func=cmd_merge)

    p_context = subparsers.add_parser("context", help="Build a MECW-aware context bundle.")
    p_context.add_argument(
        "-k",
        type=int,
        required=True,
        help="Approximate token budget for the bundle.",
    )
    p_context.add_argument(
        "--branch",
        help="Branch name to build context from (default: current branch).",
        default=None,
    )
    p_context.add_argument(
        "--policy",
        help="Optional sensitivity policy name (e.g. 'default', 'no-private'); "
             "recorded in the bundle for future enforcement.",
        default="default",
    )
    p_context.add_argument(
        "--explain",
        action="store_true",
        help="Include bundle file path in the output for debugging.",
    )
    p_context.set_defaults(func=cmd_context)

    # Sprint 3: sensitivity subcommands
    p_sens = subparsers.add_parser("sensitivity", help="Manage sensitivity events.")
    sens_sub = p_sens.add_subparsers(dest="sens_command", required=True)

    p_sens_add = sens_sub.add_parser("add", help="Record a sensitivity event.")
    p_sens_add.add_argument("--source", required=True, help="Source node identifier.")
    p_sens_add.add_argument("--concept", required=True, help="Target concept name.")
    p_sens_add.add_argument("--confidence", type=float, required=True, help="Confidence [0, 1].")
    p_sens_add.add_argument(
        "--disclosure",
        default="PUBLIC",
        choices=["PUBLIC", "PROTECTED", "PRIVATE"],
        help="Disclosure level (default: PUBLIC).",
    )
    p_sens_add.add_argument("--counterfactuals", default="", help="Counterfactual description.")
    p_sens_add.add_argument("--numerical", type=float, default=None, help="Optional numerical sensitivity value.")
    p_sens_add.add_argument("--uncertainty", type=float, default=None, help="Optional ±uncertainty for numerical value.")
    p_sens_add.add_argument("-m", "--message", default="", help="Human-readable annotation.")
    p_sens_add.set_defaults(func=cmd_sensitivity_add)

    p_sens_list = sens_sub.add_parser("list", help="List sensitivity events.")
    p_sens_list.add_argument("--concept", default=None, help="Filter by concept name.")
    p_sens_list.add_argument("--disclosure", default=None, choices=["PUBLIC", "PROTECTED", "PRIVATE"],
                             help="Filter by disclosure level.")
    p_sens_list.add_argument("--source-node", default=None, dest="source_node",
                              help="Filter by source node identifier.")
    p_sens_list.set_defaults(func=cmd_sensitivity_list)

    p_sens_filter = sens_sub.add_parser("filter", help="Filter sensitivities and show Θ vector.")
    p_sens_filter.add_argument("--concept", default=None, help="Filter by concept name.")
    p_sens_filter.add_argument("--disclosure", default=None, choices=["PUBLIC", "PROTECTED", "PRIVATE"],
                               help="Filter by disclosure level.")
    p_sens_filter.add_argument("--source-node", default=None, dest="source_node",
                               help="Filter by source node identifier.")
    p_sens_filter.set_defaults(func=cmd_sensitivity_filter)

    # Sprint 3: capability subcommands
    p_cap = subparsers.add_parser("capability", help="Manage Ωᵢ capability declarations.")
    cap_sub = p_cap.add_subparsers(dest="cap_command", required=True)

    p_cap_set = cap_sub.add_parser("set", help="Set the Ωᵢ capability declaration.")
    p_cap_set.add_argument("--agent-id", required=True, dest="agent_id", help="Agent identifier.")
    p_cap_set.add_argument("--lipschitz-bound", type=float, required=True, dest="lipschitz_bound",
                           help="Empirical Lipschitz bound L̂.")
    p_cap_set.add_argument("--calibration-hash", required=True, dest="calibration_hash",
                           help="SHA-256 hex digest of calibration dataset.")
    p_cap_set.add_argument("--embedding-model", required=True, dest="embedding_model",
                           help="Embedding model name/version.")
    p_cap_set.add_argument("--calibration-date", required=True, dest="calibration_date",
                           help="ISO date of calibration run (YYYY-MM-DD).")
    p_cap_set.add_argument("--temperature", type=float, required=True, dest="temperature",
                           help="Sampling temperature used during calibration [0, 2].")
    p_cap_set.add_argument("--lipschitz-p95", type=float, default=None, dest="lipschitz_p95",
                           help="Optional 95th-percentile Lipschitz estimate.")
    p_cap_set.add_argument("--expiry-days", type=int, default=90, dest="expiry_days",
                           help="Days until calibration expires (default: 90).")
    p_cap_set.set_defaults(func=cmd_capability_set)

    p_cap_show = cap_sub.add_parser("show", help="Display the current Ωᵢ declaration.")
    p_cap_show.set_defaults(func=cmd_capability_show)

    p_cap_val = cap_sub.add_parser("validate", help="Validate Ωᵢ against A1 gate conditions.")
    p_cap_val.add_argument("--l-max", type=float, default=L_MAX_DEFAULT, dest="l_max",
                           help=f"Lipschitz bound threshold L_max (default: {L_MAX_DEFAULT}).")
    p_cap_val.set_defaults(func=cmd_capability_validate)

    # Sprint 4: lock, unlock, invariant, concept, variance
    p_lock = subparsers.add_parser("lock", help="Acquire consensus lock.")
    p_lock.add_argument("--reason", default="", help="Reason for locking.")
    p_lock.add_argument("--peers", type=int, default=None, dest="peers", help="Required peer count (optional).")
    p_lock.set_defaults(func=cmd_lock)

    p_unlock = subparsers.add_parser("unlock", help="Release consensus lock (I1 checked).")
    p_unlock.set_defaults(func=cmd_unlock)

    p_inv = subparsers.add_parser("invariant", help="Run invariant checks.")
    inv_sub = p_inv.add_subparsers(dest="inv_command", required=True)
    p_inv_check = inv_sub.add_parser("check", help="Run I1/I3 invariant engine.")
    p_inv_check.add_argument("--operation", default="merge", help="Operation context (default: merge).")
    p_inv_check.add_argument("--concepts", default="", help="Comma-separated concept names for I3.")
    p_inv_check.set_defaults(func=cmd_invariant_check)

    p_concept = subparsers.add_parser("concept", help="Manage concept definitions (I3 semantic grounding).")
    concept_sub = p_concept.add_subparsers(dest="concept_command", required=True)
    p_concept_add = concept_sub.add_parser("add", help="Add a concept definition.")
    p_concept_add.add_argument("name", help="Concept name.")
    p_concept_add.add_argument("definition", help="Concept definition text.")
    p_concept_add.set_defaults(func=cmd_concept_add)
    p_concept_list = concept_sub.add_parser("list", help="List registered concepts.")
    p_concept_list.set_defaults(func=cmd_concept_list)

    p_var = subparsers.add_parser("variance", help="Variance calibration and rolling monitor (f_max, A2/I2).")
    var_sub = p_var.add_subparsers(dest="var_command", required=True)
    p_var_cal = var_sub.add_parser("calibrate", help="Run calibration and persist report.")
    p_var_cal.add_argument("--variances", default="", help="Comma-separated agent_id=sigma_sq (e.g. a1=0.1,a2=0.2).")
    p_var_cal.set_defaults(func=cmd_variance_calibrate)
    p_var_mon = var_sub.add_parser("monitor", help="Run rolling monitor; emit VARIANCE_ALERT if f_max drops or is 0.")
    p_var_mon.add_argument("--variances", default="", help="Optional: comma-separated agent_id=sigma_sq for live re-check.")
    p_var_mon.set_defaults(func=cmd_variance_monitor)

    # Sprint 5: rep, sis-tc, prompt, deltaf, rdp, disclosure
    p_rep = subparsers.add_parser("rep", help="REP envelope and local ledger (S5).")
    rep_sub = p_rep.add_subparsers(dest="rep_command", required=True)
    p_rep_append = rep_sub.add_parser("append", help="Append REP envelope to ledger.")
    p_rep_append.add_argument("--agent-id", required=True, dest="agent_id", help="Agent ID.")
    p_rep_append.add_argument("--round", type=int, required=True, dest="round_id", help="Round ID.")
    p_rep_append.add_argument("--payload", default="{}", help="JSON payload.")
    p_rep_append.add_argument("--trust", type=float, default=0.5, help="Trust score [0,1].")
    p_rep_append.set_defaults(func=cmd_rep_append)
    p_rep_checksum = rep_sub.add_parser("checksum", help="Replay checksum of ledger.")
    p_rep_checksum.set_defaults(func=cmd_rep_checksum)

    p_sis = subparsers.add_parser("sis-tc", help="SIS-TC evaluation (A3).")
    sis_sub = p_sis.add_subparsers(dest="sis_command", required=True)
    p_sis_run = sis_sub.add_parser("run", help="Run SIS-TC eval; persist report.")
    p_sis_run.add_argument("--corpus", default=None, help="Path to corpus JSONL (default: .GCC/sis/sis_tc_corpus.jsonl).")
    p_sis_run.set_defaults(func=cmd_sis_tc_run)

    p_prompt = subparsers.add_parser("prompt", help="RACP system prompt artifact (A3).")
    prompt_sub = p_prompt.add_subparsers(dest="prompt_command", required=True)
    p_prompt_set = prompt_sub.add_parser("set", help="Store RACP_SYSTEM_PROMPT_v2.1.")
    p_prompt_set.add_argument("--file", default=None, help="Read content from file.")
    p_prompt_set.add_argument("content", nargs="?", default="", help="Prompt content (or use --file).")
    p_prompt_set.add_argument("--version", default="v2.1")
    p_prompt_set.set_defaults(func=cmd_prompt_set)
    p_prompt_show = prompt_sub.add_parser("show", help="Show stored prompt.")
    p_prompt_show.set_defaults(func=cmd_prompt_show)

    p_deltaf = subparsers.add_parser("deltaf", help="Δf estimation (A4).")
    deltaf_sub = p_deltaf.add_subparsers(dest="deltaf_command", required=True)
    p_deltaf_run = deltaf_sub.add_parser("run", help="Run Δf estimation; persist report.")
    p_deltaf_run.add_argument("--expiry-days", type=int, default=90, dest="expiry_days")
    p_deltaf_run.set_defaults(func=cmd_deltaf_run)

    p_rdp = subparsers.add_parser("rdp", help="RDP accountant (A4).")
    rdp_sub = p_rdp.add_subparsers(dest="rdp_command", required=True)
    p_rdp_spend = rdp_sub.add_parser("spend", help="Spend epsilon for round.")
    p_rdp_spend.add_argument("round_id", type=int, help="Round ID.")
    p_rdp_spend.add_argument("epsilon", type=float, help="Epsilon cost.")
    p_rdp_spend.set_defaults(func=cmd_rdp_spend)
    p_rdp_status = rdp_sub.add_parser("status", help="Show read_only status.")
    p_rdp_status.set_defaults(func=cmd_rdp_status)

    p_disc = subparsers.add_parser("disclosure", help="[PRIVATE] suppression and padding (A4).")
    disc_sub = p_disc.add_subparsers(dest="disclosure_command", required=True)
    p_disc_redact = disc_sub.add_parser("redact", help="Redact [PRIVATE] with padding.")
    p_disc_redact.add_argument("text", nargs="?", default="", help="Input text (or stdin).")
    p_disc_redact.add_argument("--padding", type=int, default=32, help="Padding length.")
    p_disc_redact.set_defaults(func=cmd_disclosure_redact)

    # Sprint 6: debug
    p_debug = subparsers.add_parser("debug", help="Debug views (timeline, branch comparison, invariant trace).")
    debug_sub = p_debug.add_subparsers(dest="debug_command", required=True)
    p_debug_timeline = debug_sub.add_parser("timeline", help="Event timeline, optionally filtered.")
    p_debug_timeline.add_argument(
        "--filter",
        default=None,
        help="Comma-separated event types (e.g. CAPABILITY_DEGRADED,VARIANCE_ALERT,QUARANTINE,PRIVACY_BUDGET_EXHAUSTED).",
    )
    p_debug_timeline.set_defaults(func=cmd_debug_timeline)
    p_debug_branch = debug_sub.add_parser("branch-compare", help="Compare two branches (history + Θ).")
    p_debug_branch.add_argument("branch1", help="First branch name.")
    p_debug_branch.add_argument("branch2", help="Second branch name.")
    p_debug_branch.set_defaults(func=cmd_debug_branch_compare)
    p_debug_inv = debug_sub.add_parser("invariant-trace", help="Show invariant failures and actionable fixes.")
    p_debug_inv.set_defaults(func=cmd_debug_invariant_trace)

    # Sprint 9: status command
    p_status = subparsers.add_parser("status", help="Show repository status (branch, commits, Θ hot zones, invariants, lock).")
    p_status.set_defaults(func=cmd_status)

    # Sprint 9: log command
    p_log = subparsers.add_parser("log", help="Print .GCC/log.md to stdout.")
    p_log.add_argument("--tail", type=int, default=None, metavar="N",
                       help="Print last N lines only (default: print all).")
    p_log.add_argument("--branch", default=None, metavar="B",
                       help="Branch filter (note: log.md is global; filter is noted but not applied).")
    p_log.set_defaults(func=cmd_log)

    # S7: proxy subcommand (server in devtorch_core/proxy/)
    p_proxy = subparsers.add_parser("proxy", help="LLM proxy management (S7).")
    proxy_sub = p_proxy.add_subparsers(dest="proxy_command", required=True)

    p_proxy_start = proxy_sub.add_parser("start", help="Start the LLM proxy server in the foreground.")
    p_proxy_start.add_argument("--port", type=int, default=8765, help="Port to listen on (default: 8765).")
    p_proxy_start.add_argument("--host", default="127.0.0.1", help="Host to bind to (default: 127.0.0.1).")
    p_proxy_start.set_defaults(func=cmd_proxy_start)

    p_proxy_stop = proxy_sub.add_parser("stop", help="Print instructions to stop the proxy.")
    p_proxy_stop.set_defaults(func=cmd_proxy_stop)

    p_proxy_install = proxy_sub.add_parser("install", help="Install proxy as a system service.")
    p_proxy_install.set_defaults(func=cmd_proxy_install)

    p_proxy_status = proxy_sub.add_parser("status", help="Check if the proxy is running on :8765.")
    p_proxy_status.set_defaults(func=cmd_proxy_status)

    # S17a: calibrate subcommand
    p_calibrate = subparsers.add_parser("calibrate", help="Calibrate DevTorch metrics baselines.")
    p_calibrate.add_argument(
        "--set",
        dest="set_value",
        metavar="KEY=VALUE",
        help="Set a single calibration value.",
    )
    p_calibrate.set_defaults(func=cmd_calibrate)

    # S17a: metrics subcommand
    p_metrics = subparsers.add_parser("metrics", help="Show DevTorch metrics summary.")
    p_metrics.add_argument(
        "--period",
        default="30d",
        help="Time period (e.g. 30d, 7d). Default: 30d.",
    )
    p_metrics.add_argument(
        "--json",
        action="store_true",
        dest="as_json",
        help="Output raw JSON.",
    )
    p_metrics.set_defaults(func=cmd_metrics)

    # Sprint 19: reasoning subcommand
    reasoning_parser = subparsers.add_parser("reasoning", help="Query agent reasoning")
    reasoning_sub = reasoning_parser.add_subparsers(dest="reasoning_cmd")
    rshow = reasoning_sub.add_parser("show", help="Show agent reasoning for a concept")
    rshow.add_argument("--concept", required=True)
    rshow.add_argument("--agent", dest="agent_id", default=None)
    rshow.add_argument("--tokens", type=int, default=4000)
    rshow.set_defaults(func=cmd_reasoning_show)

    sync_parser = subparsers.add_parser("sync", help="Sync REP ledger with registered peers.")
    sync_parser.add_argument("--interval", type=int, default=0,
                             help="If >0, repeat sync every N seconds (runs until interrupted).")
    sync_parser.add_argument("--gcc-dir", default=".GCC",
                             help="Path to .GCC directory (default: .GCC in cwd).")
    sync_parser.set_defaults(func=cmd_sync)

    watch_parser = subparsers.add_parser("watch", help="Tail coordination events from .GCC/ in real time.")
    watch_parser.add_argument("--gcc-dir", default=".GCC",
                              help="Path to .GCC directory (default: .GCC in cwd).")
    watch_parser.set_defaults(func=cmd_watch)

    # S11: mcp-server subcommand
    mcp_parser = subparsers.add_parser("mcp-server", help="Start the DevTorch MCP server")
    mcp_parser.add_argument(
        "--transport", choices=["stdio", "sse"], default="stdio",
        help="Transport: stdio (default, local) or sse (cloud HTTPS)",
    )
    mcp_parser.add_argument("--host", default="0.0.0.0", help="SSE bind host (default: 0.0.0.0)")
    mcp_parser.add_argument("--port", type=int, default=8080, help="SSE bind port (default: 8080)")

    # Cloud key management
    cloud_parser = subparsers.add_parser("cloud", help="Cloud MCP server management")
    cloud_sub = cloud_parser.add_subparsers(dest="cloud_command", required=True)
    key_parser = cloud_sub.add_parser("key", help="API key management")
    key_sub = key_parser.add_subparsers(dest="key_command", required=True)
    key_create = key_sub.add_parser("create", help="Create a new API key")
    key_create.add_argument("--org", required=True, help="Org ID")
    key_create.add_argument("--repo", help="Repo ID (optional, adds to allowed_repos)")
    key_create.add_argument(
        "--github", metavar="OWNER/REPO",
        help="Also set DEVTORCH_API_KEY as a GitHub Repository Secret",
    )

    # S11: hooks subcommand
    p_hooks = subparsers.add_parser("hooks", help="Manage DevTorch hooks for Claude Code and git (S11).")
    hooks_sub = p_hooks.add_subparsers(dest="hooks_command", required=True)

    p_hooks_install = hooks_sub.add_parser("install", help="Install .claude/hooks.json and git commit-msg hook.")
    p_hooks_install.set_defaults(hooks_command="install")

    p_hooks_status = hooks_sub.add_parser("status", help="Show which DevTorch hooks are installed.")
    p_hooks_status.set_defaults(hooks_command="status")

    p_hooks_git_commit = hooks_sub.add_parser("git-commit", help="Git commit-msg hook entry point.")
    p_hooks_git_commit.add_argument("commit_msg_file", help="Path to the git commit message file.")
    p_hooks_git_commit.set_defaults(hooks_command="git-commit")

    p_hooks_run = hooks_sub.add_parser("run", help="Run a Claude Code hook (reads JSON from stdin).")
    p_hooks_run.add_argument("hook_name", choices=["pre-tool-use", "post-tool-use", "session-end"])
    p_hooks_run.set_defaults(hooks_command="run")

    return parser


def _set_github_secret(owner_repo: str, secret_name: str, secret_value: str) -> None:
    import os
    import urllib.request
    import json as _json

    token = os.environ.get("GITHUB_TOKEN", "")
    if not token:
        print("Warning: GITHUB_TOKEN not set; skipping GitHub secret creation.")
        return
    owner, repo = owner_repo.split("/", 1)

    url = f"https://api.github.com/repos/{owner}/{repo}/actions/secrets/public-key"
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github+json",
        },
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        pub_key_data = _json.loads(resp.read())

    try:
        import nacl.public
        from base64 import b64decode, b64encode
        pub_key = nacl.public.PublicKey(b64decode(pub_key_data["key"]))
        sealed = nacl.public.SealedBox(pub_key).encrypt(secret_value.encode())
        encrypted = b64encode(sealed).decode()
    except ImportError:
        print("Warning: PyNaCl not installed; cannot encrypt GitHub secret. Install with: pip install PyNaCl")
        return

    payload = _json.dumps({
        "encrypted_value": encrypted,
        "key_id": pub_key_data["key_id"],
    }).encode()
    put_url = f"https://api.github.com/repos/{owner}/{repo}/actions/secrets/{secret_name}"
    put_req = urllib.request.Request(
        put_url, data=payload, method="PUT",
        headers={
            "Authorization": f"token {token}",
            "Accept": "application/vnd.github+json",
            "Content-Type": "application/json",
        },
    )
    with urllib.request.urlopen(put_req, timeout=10):
        pass
    print(f"GitHub secret {secret_name} set on {owner_repo}.")


def cmd_sync(args: argparse.Namespace) -> int:
    import time
    from pathlib import Path
    from devtorch_core.rep import REPLedger
    from devtorch_core.rep_network.node import NodeRegistry
    from devtorch_core.rep_network.sync import sync_all_peers

    gcc_dir = Path(args.gcc_dir)
    ledger = REPLedger(gcc_dir / "rep")
    registry = NodeRegistry(gcc_dir / "rep")

    def _do_sync():
        results = sync_all_peers(ledger, registry)
        if not results:
            print("No peers configured.")
            return
        for r in results:
            status = "✓" if r.success else "✗"
            print(f"  {status} {r.peer_node_id} ({r.peer_url}): "
                  f"pushed={r.pushed_count} pulled={r.pulled_count}"
                  + (f" errors={r.errors}" if r.errors else ""))

    if args.interval > 0:
        print(f"Syncing every {args.interval}s — Ctrl-C to stop.")
        try:
            while True:
                _do_sync()
                time.sleep(args.interval)
        except KeyboardInterrupt:
            print("\nSync stopped.")
    else:
        _do_sync()
    return 0


def cmd_watch(args: argparse.Namespace) -> int:
    """Tail the DevTorch event stream (SSE broadcaster)."""
    import sys
    from pathlib import Path
    from devtorch_core.broadcast.broadcaster import EventBroadcaster
    from devtorch_core.broadcast.watcher import GCCWatcher

    gcc_dir = Path(args.gcc_dir)
    if not gcc_dir.exists():
        print(f"Error: {gcc_dir} does not exist. Run devtorch init first.", file=sys.stderr)
        return 1

    broadcaster = EventBroadcaster()
    q = broadcaster.subscribe()
    watcher = GCCWatcher(gcc_dir, broadcaster, poll_interval=0.2)
    watcher.start()
    print(f"Watching {gcc_dir}/events.log.jsonl for coordination events... (Ctrl-C to stop)")
    import json as _json
    import time as _time
    try:
        while True:
            _time.sleep(0.1)
            while not q.empty():
                event = q.get_nowait()
                print(_json.dumps(event, indent=None))
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        watcher.stop()
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # S11: mcp-server
    if args.command == "mcp-server":
        if args.transport == "sse":
            import os
            from devtorch_core.mcp.server import _run_with_sse
            from devtorch_core.storage import R2Backend
            import boto3

            _SSE_REQUIRED_VARS = ["DEVTORCH_ORG_ID", "R2_BUCKET", "R2_ACCOUNT_ID", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY"]
            missing = [v for v in _SSE_REQUIRED_VARS if v not in os.environ]
            if missing:
                for var in missing:
                    print(f"error: required environment variable {var} is not set.", file=sys.stderr)
                return 1

            org_id = os.environ["DEVTORCH_ORG_ID"]
            r2_bucket = os.environ["R2_BUCKET"]
            r2_account_id = os.environ["R2_ACCOUNT_ID"]
            r2_access_key = os.environ["R2_ACCESS_KEY_ID"]
            r2_secret_key = os.environ["R2_SECRET_ACCESS_KEY"]

            s3 = boto3.client(
                "s3",
                endpoint_url=f"https://{r2_account_id}.r2.cloudflarestorage.com",
                aws_access_key_id=r2_access_key,
                aws_secret_access_key=r2_secret_key,
                region_name="auto",
            )

            auth_backend = R2Backend(client=s3, bucket=r2_bucket, prefix=org_id)

            def repo_factory(req_org: str, repo_id: str):
                from devtorch_core.gcc import GCCRepository
                from pathlib import Path
                backend = R2Backend(
                    client=s3, bucket=r2_bucket,
                    prefix=f"{req_org}/{repo_id}/.GCC",
                )
                return GCCRepository(root=Path(f"/tmp/{req_org}/{repo_id}"), backend=backend)

            _run_with_sse(
                repo_factory=repo_factory,
                auth_backend=auth_backend,
                host=args.host,
                port=args.port,
            )
        else:
            from devtorch_core.mcp.server import main as mcp_main
            mcp_main()
        return 0

    if args.command == "cloud":
        if args.cloud_command == "key" and args.key_command == "create":
            import os
            import secrets
            import hashlib
            import json
            import datetime
            from devtorch_core.storage import R2Backend
            import boto3

            _KEY_REQUIRED_VARS = ["R2_ACCOUNT_ID", "R2_ACCESS_KEY_ID", "R2_SECRET_ACCESS_KEY", "R2_BUCKET"]
            missing = [v for v in _KEY_REQUIRED_VARS if v not in os.environ]
            if missing:
                for var in missing:
                    print(f"error: required environment variable {var} is not set.", file=sys.stderr)
                return 1

            raw_key = secrets.token_urlsafe(32)
            key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

            s3 = boto3.client(
                "s3",
                endpoint_url=f"https://{os.environ['R2_ACCOUNT_ID']}.r2.cloudflarestorage.com",
                aws_access_key_id=os.environ["R2_ACCESS_KEY_ID"],
                aws_secret_access_key=os.environ["R2_SECRET_ACCESS_KEY"],
                region_name="auto",
            )
            backend = R2Backend(
                client=s3,
                bucket=os.environ["R2_BUCKET"],
                prefix=args.org,
            )

            keys_path = ".devtorch/api_keys.json"
            try:
                existing = json.loads(backend.read_bytes(keys_path))
            except FileNotFoundError:
                existing = {}

            existing[key_hash] = {
                "org_id": args.org,
                "allowed_repos": [args.repo] if args.repo else None,
                "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            }
            backend.write_bytes(keys_path, json.dumps(existing, indent=2).encode())
            print(f"API key created. Store this — it will not be shown again:\n\n  {raw_key}\n")

            if args.github:
                _set_github_secret(args.github, "DEVTORCH_API_KEY", raw_key)
            return 0
        print(f"error: unknown cloud command: {args.cloud_command}", file=sys.stderr)
        return 1

    # S11: hooks
    if args.command == "hooks":
        from devtorch_core.hooks.installer import install_all_hooks, get_hooks_status

        # Try to resolve the project root from a GCC repo, fall back to cwd
        try:
            gcc_repo = GCCRepository.at(Path(args.path).resolve())
            project_root = str(gcc_repo.root) if gcc_repo.is_initialized() else args.path
        except Exception:
            project_root = args.path

        if args.hooks_command == "install":
            result = install_all_hooks(project_root)
            print(f"Claude hooks: {'✓' if result.claude_hooks_written else '✗'} {result.claude_hooks_path}")
            print(f"Git hook:     {'✓' if result.git_hook_written else '✗'} {result.git_hook_path}")
            if result.errors:
                for e in result.errors:
                    print(f"  Error: {e}")
        elif args.hooks_command == "status":
            status = get_hooks_status(project_root)
            for k, v in status.items():
                print(f"{k}: {v}")
        elif args.hooks_command == "git-commit":
            from devtorch_core.hooks.git_commit import handle_commit_msg
            handle_commit_msg(args.commit_msg_file)
        elif args.hooks_command == "run":
            from devtorch_core.hooks.runner import run as run_hook
            run_hook(args.hook_name)
        return 0

    if args.command == "reasoning":
        if getattr(args, "reasoning_cmd", None) is None:
            # Print help when no subcommand given
            build_parser().parse_args(["reasoning", "--help"])
            return 0
        return args.func(args)

    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

