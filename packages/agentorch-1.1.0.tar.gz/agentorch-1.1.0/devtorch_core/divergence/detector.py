from __future__ import annotations

import dataclasses
import json
from pathlib import Path
from typing import List, Optional

_SENSITIVITIES_FILE = "sensitivities/events.jsonl"
_SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
_CONFIDENCE_GAP_THRESHOLD = 0.35


@dataclasses.dataclass
class DivergenceSignal:
    """
    A detected divergence between agents on a specific concept.

    signal_type:
      A — conflicting decisions (commit messages contradict each other)
      B — confidence gap ≥0.35 between two agents on the same concept
      C — disclosure mismatch (e.g. PUBLIC vs PRIVATE)
      D — missing coverage (agent has no reasoning for a concept another agent flagged)
      E — consensus contradiction (new signal conflicts with a durable consensus commit)
    """
    signal_type: str   # "A" | "B" | "C" | "D" | "E"
    severity: str      # "HIGH" | "MEDIUM" | "LOW"
    concept: str
    agent_ids: List[str]
    description: str
    evidence: dict


class DivergenceDetector:
    """Detect reasoning divergence across agents for a given concept."""

    def __init__(self, repo) -> None:
        self._repo = repo
        self._gcc_dir = repo.gcc_dir

    def detect(self, concept: str) -> List[DivergenceSignal]:
        events = self._load_events(concept)
        if len(events) < 2:
            return []

        signals: List[DivergenceSignal] = []
        signals.extend(self._check_confidence_gap(concept, events))
        signals.extend(self._check_disclosure_mismatch(concept, events))
        signals.extend(self._check_consensus_contradiction(concept, events))

        signals.sort(key=lambda s: _SEVERITY_ORDER.get(s.severity, 99))
        return signals

    def _load_events(self, concept: str) -> List[dict]:
        path = self._gcc_dir / _SENSITIVITIES_FILE
        if not path.exists():
            return []
        results = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                if d.get("target_concept") == concept:
                    results.append(d)
            except json.JSONDecodeError:
                continue
        return results

    def _check_confidence_gap(self, concept: str, events: List[dict]) -> List[DivergenceSignal]:
        """Signal B: two agents differ in confidence by ≥0.35."""
        by_agent: dict[str, List[float]] = {}
        for ev in events:
            agent = ev.get("agent_id") or ev.get("source_node", "unknown")
            by_agent.setdefault(agent, []).append(float(ev.get("confidence", 0.0)))

        if len(by_agent) < 2:
            return []

        agent_means = {a: sum(cs) / len(cs) for a, cs in by_agent.items()}
        agents = list(agent_means.keys())
        signals = []
        for i in range(len(agents)):
            for j in range(i + 1, len(agents)):
                gap = abs(agent_means[agents[i]] - agent_means[agents[j]])
                if gap >= _CONFIDENCE_GAP_THRESHOLD:
                    signals.append(DivergenceSignal(
                        signal_type="B",
                        severity="MEDIUM",
                        concept=concept,
                        agent_ids=[agents[i], agents[j]],
                        description=f"Confidence gap {gap:.2f} on '{concept}': "
                                    f"{agents[i]}={agent_means[agents[i]]:.2f}, "
                                    f"{agents[j]}={agent_means[agents[j]]:.2f}",
                        evidence={
                            f"{agents[i]}_mean_confidence": round(agent_means[agents[i]], 4),
                            f"{agents[j]}_mean_confidence": round(agent_means[agents[j]], 4),
                            "gap": round(gap, 4),
                        },
                    ))
        return signals

    def _check_disclosure_mismatch(self, concept: str, events: List[dict]) -> List[DivergenceSignal]:
        """Signal C: agents disagree on disclosure level — always HIGH severity."""
        by_agent: dict[str, set] = {}
        for ev in events:
            agent = ev.get("agent_id") or ev.get("source_node", "unknown")
            by_agent.setdefault(agent, set()).add(ev.get("disclosure_level", "PROTECTED"))

        # Take the most restrictive disclosure level per agent
        all_levels: dict[str, str] = {
            agent: max(levels, key=lambda l: {"PRIVATE": 2, "PROTECTED": 1, "PUBLIC": 0}.get(l, 0))
            for agent, levels in by_agent.items()
        }

        if len(all_levels) < 2:
            return []

        unique_levels = set(all_levels.values())
        if len(unique_levels) <= 1:
            return []

        return [DivergenceSignal(
            signal_type="C",
            severity="HIGH",
            concept=concept,
            agent_ids=list(all_levels.keys()),
            description=f"Disclosure mismatch on '{concept}': " +
                        ", ".join(f"{a}={l}" for a, l in all_levels.items()),
            evidence=dict(all_levels),
        )]

    def _check_consensus_contradiction(self, concept: str, events: List[dict]) -> List[DivergenceSignal]:
        """Signal E: new sensitivity contradicts an existing consensus commit."""
        consensus_path = self._gcc_dir / "consolidations"
        if not consensus_path.exists():
            return []

        signals = []
        for f in consensus_path.glob("*.json"):
            try:
                record = json.loads(f.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                continue
            if record.get("concept") != concept:
                continue
            if record.get("state") not in ("resolved", "auto_resolved"):
                continue
            resolved_at = record.get("resolved_at", "")
            post_consensus = [
                ev for ev in events
                if ev.get("created_at", "") > resolved_at
            ]
            if post_consensus:
                signals.append(DivergenceSignal(
                    signal_type="E",
                    severity="HIGH",
                    concept=concept,
                    agent_ids=list({
                        ev.get("agent_id") or ev.get("source_node", "unknown")
                        for ev in post_consensus
                    }),
                    description=f"{len(post_consensus)} new signals on '{concept}' after consensus at {resolved_at[:19]}",
                    evidence={"consensus_record_id": record.get("record_id", ""), "post_consensus_count": len(post_consensus)},
                ))
        return signals
