"""
Installs DevTorch hooks for Claude Code, git, and Google Antigravity (AGENTS.md).
"""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Canonical hooks.json configuration
# ---------------------------------------------------------------------------

CLAUDE_HOOKS_CONFIG: dict = {
    "hooks": {
        "PreToolUse": [
            {
                "matcher": "*",
                "hooks": [
                    {
                        "type": "command",
                        "command": "devtorch hooks run pre-tool-use",
                    }
                ],
            }
        ],
        "PostToolUse": [
            {
                "matcher": "*",
                "hooks": [
                    {
                        "type": "command",
                        "command": "devtorch hooks run post-tool-use",
                    }
                ],
            }
        ],
        "Stop": [
            {
                "hooks": [
                    {
                        "type": "command",
                        "command": "devtorch hooks run session-end",
                    }
                ]
            }
        ],
    }
}


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------


@dataclass
class HookInstallResult:
    claude_hooks_written: bool = False
    claude_hooks_path: str = ""
    git_hook_written: bool = False
    git_hook_path: str = ""
    errors: list[str] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Deep-merge helpers
# ---------------------------------------------------------------------------


def _deep_merge(base: dict, overlay: dict) -> dict:
    """
    Recursively merge *overlay* into *base*.

    - For dicts: recurse.
    - For lists keyed under "hooks" event names: append overlay entries
      whose commands are not already present.
    - Scalar values: overlay wins.
    """
    result = copy.deepcopy(base)
    for key, val in overlay.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = _deep_merge(result[key], val)
        elif key in result and isinstance(result[key], list) and isinstance(val, list):
            # Merge lists without duplicating identical entries
            existing_cmds = _extract_commands(result[key])
            for item in val:
                item_cmds = _extract_commands([item])
                if not item_cmds or not item_cmds.issubset(existing_cmds):
                    result[key].append(copy.deepcopy(item))
        else:
            result[key] = copy.deepcopy(val)
    return result


def _extract_commands(items: list) -> set:
    """Extract all command strings from a list of hook entries."""
    cmds: set = set()
    for item in items:
        if isinstance(item, dict):
            for hook in item.get("hooks", []):
                if isinstance(hook, dict) and "command" in hook:
                    cmds.add(hook["command"])
    return cmds


# ---------------------------------------------------------------------------
# install_claude_hooks
# ---------------------------------------------------------------------------


def install_claude_hooks(project_root: str) -> tuple[bool, str]:
    """
    Write (or merge into) .claude/hooks.json under *project_root*.

    - Creates .claude/ directory if it does not exist.
    - If .claude/hooks.json already exists, deep-merges DevTorch hooks into
      the existing config without removing existing keys.
    - Returns (True, path) on success, (False, error_message) on failure.
    """
    try:
        claude_dir = Path(project_root) / ".claude"
        claude_dir.mkdir(parents=True, exist_ok=True)

        hooks_path = claude_dir / "hooks.json"

        if hooks_path.exists():
            try:
                existing = json.loads(hooks_path.read_text(encoding="utf-8"))
            except Exception:
                existing = {}
            merged = _deep_merge(existing, CLAUDE_HOOKS_CONFIG)
        else:
            merged = copy.deepcopy(CLAUDE_HOOKS_CONFIG)

        hooks_path.write_text(json.dumps(merged, indent=2), encoding="utf-8")
        return True, str(hooks_path)

    except Exception as exc:
        return False, str(exc)


# ---------------------------------------------------------------------------
# install_git_commit_hook
# ---------------------------------------------------------------------------


def install_git_commit_hook(repo_root: str) -> tuple[bool, str]:
    """
    Install the git commit-msg hook in .git/hooks/commit-msg.

    Calls devtorch_core.hooks.git_commit.install_hook(repo_root).
    Returns (True, path) on success, (False, reason) when no .git found or
    on any other error.
    """
    git_dir = Path(repo_root) / ".git"
    if not git_dir.is_dir():
        return False, "no .git found"

    try:
        from devtorch_core.hooks.git_commit import install_hook

        install_hook(Path(repo_root))
        hook_path = str(git_dir / "hooks" / "commit-msg")
        return True, hook_path

    except Exception as exc:
        return False, str(exc)


# ---------------------------------------------------------------------------
# install_all_hooks
# ---------------------------------------------------------------------------


def install_all_hooks(project_root: str) -> HookInstallResult:
    """
    Install all DevTorch hooks (Claude Code + git).

    Never raises — all exceptions are captured into result.errors.
    """
    result = HookInstallResult()

    # Claude Code hooks
    try:
        ok, path = install_claude_hooks(project_root)
        result.claude_hooks_written = ok
        result.claude_hooks_path = path
        if not ok:
            result.errors.append(f"claude hooks: {path}")
    except Exception as exc:
        result.errors.append(f"claude hooks exception: {exc}")

    # Git commit-msg hook
    try:
        ok, path = install_git_commit_hook(project_root)
        result.git_hook_written = ok
        result.git_hook_path = path
        if not ok:
            result.errors.append(f"git hook: {path}")
    except Exception as exc:
        result.errors.append(f"git hook exception: {exc}")

    return result


# ---------------------------------------------------------------------------
# AGENTS.md block for Google Antigravity
# ---------------------------------------------------------------------------

ANTIGRAVITY_AGENTS_MD_BLOCK = """
## DevTorch — Reasoning Capture

This project uses DevTorch for AI governance. These steps are mandatory for all agent actions.

### At the start of every task

Call `devtorch_context` (MCP tool) before reading files or writing code:
- Tool: `devtorch_context`
- Args: `{ "max_tokens": 2000 }`

Use the returned context to understand prior decisions before proceeding.

### Before writing or editing any code

Call `devtorch_commit` before the first file write:
- Tool: `devtorch_commit`
- Args: `{ "message": "<what you decided and WHY — include alternatives considered>", "concepts": ["<concept>"], "confidence": 0.0–1.0 }`

The message must explain the *why*, not just the *what*.
"Added login endpoint" is not acceptable.
"Chose JWT over sessions because the service is stateless" is.

### When touching sensitive areas

Call `devtorch_sensitivity_add` for auth, payments, database schema, secrets, PII, external APIs:
- Tool: `devtorch_sensitivity_add`
- Args: `{ "concept": "<auth|schema|payments|secrets|pii|api|security|config>", "confidence": 0.0–1.0, "disclosure_level": "PUBLIC|PROTECTED|PRIVATE" }`

| Level | Use when |
|---|---|
| PUBLIC | General design decisions |
| PROTECTED | Internal implementation, business logic |
| PRIVATE | Credentials, PII, secrets |
"""


# ---------------------------------------------------------------------------
# install_agents_md
# ---------------------------------------------------------------------------


def install_agents_md(project_root: str) -> tuple[bool, str]:
    """
    Write (or append to) AGENTS.md under *project_root* with the DevTorch
    governance block for Google Antigravity.

    - Creates AGENTS.md if it does not exist.
    - If AGENTS.md already contains the marker ``## DevTorch``, does nothing
      (idempotent).
    - Returns (True, path) on success, (False, error_message) on failure.
    """
    try:
        agents_md_path = Path(project_root) / "AGENTS.md"
        marker = "## DevTorch"

        if agents_md_path.exists():
            existing = agents_md_path.read_text(encoding="utf-8")
            if marker in existing:
                return True, str(agents_md_path)

        with agents_md_path.open("a", encoding="utf-8") as f:
            f.write(ANTIGRAVITY_AGENTS_MD_BLOCK)

        return True, str(agents_md_path)

    except Exception as exc:
        return False, str(exc)


# ---------------------------------------------------------------------------
# get_hooks_status
# ---------------------------------------------------------------------------


def get_hooks_status(project_root: str) -> dict:
    """
    Return the install status of DevTorch hooks without writing anything.

    Returns:
        {
            "claude_hooks": bool,
            "claude_hooks_path": str,
            "git_hook": bool,
            "git_hook_path": str,
        }
    """
    claude_hooks_path = str(Path(project_root) / ".claude" / "hooks.json")
    claude_hooks = Path(claude_hooks_path).exists()

    git_hook_path = str(Path(project_root) / ".git" / "hooks" / "commit-msg")
    git_hook = Path(git_hook_path).exists()

    return {
        "claude_hooks": claude_hooks,
        "claude_hooks_path": claude_hooks_path,
        "git_hook": git_hook,
        "git_hook_path": git_hook_path,
    }


# ---------------------------------------------------------------------------
# Shared MCP server entry for Cursor / Antigravity
# ---------------------------------------------------------------------------

_MCP_SERVER_ENTRY = {
    "devtorch": {
        "command": "devtorch",
        "args": ["mcp-server"],
    }
}


# ---------------------------------------------------------------------------
# install_cursor_mcp
# ---------------------------------------------------------------------------


def install_cursor_mcp(project_root: str) -> tuple[bool, str]:
    """
    Write (or merge into) .cursor/mcp.json under *project_root*.

    Adds the devtorch MCP server entry. Preserves any existing servers.
    Idempotent — skips write if devtorch entry already present.
    Returns (True, path) on success, (False, error_message) on failure.
    """
    try:
        cursor_dir = Path(project_root) / ".cursor"
        cursor_dir.mkdir(parents=True, exist_ok=True)
        mcp_path = cursor_dir / "mcp.json"

        existing: dict = {}
        if mcp_path.exists():
            try:
                existing = json.loads(mcp_path.read_text(encoding="utf-8"))
            except Exception:
                existing = {}

        servers = existing.setdefault("mcpServers", {})
        if "devtorch" not in servers:
            servers["devtorch"] = _MCP_SERVER_ENTRY["devtorch"]
            mcp_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")

        return True, str(mcp_path)

    except Exception as exc:
        return False, str(exc)


# ---------------------------------------------------------------------------
# install_antigravity_mcp
# ---------------------------------------------------------------------------


def install_antigravity_mcp(project_root: str) -> tuple[bool, str]:
    """
    Write (or merge into) mcp_config.json at *project_root*.

    Antigravity uses a project-level mcp_config.json for MCP server registration.
    Adds the devtorch MCP server entry. Preserves any existing servers.
    Idempotent — skips write if devtorch entry already present.
    Returns (True, path) on success, (False, error_message) on failure.
    """
    try:
        mcp_path = Path(project_root) / "mcp_config.json"

        existing: dict = {}
        if mcp_path.exists():
            try:
                existing = json.loads(mcp_path.read_text(encoding="utf-8"))
            except Exception:
                existing = {}

        servers = existing.setdefault("mcpServers", {})
        if "devtorch" not in servers:
            servers["devtorch"] = _MCP_SERVER_ENTRY["devtorch"]
            mcp_path.write_text(json.dumps(existing, indent=2), encoding="utf-8")

        return True, str(mcp_path)

    except Exception as exc:
        return False, str(exc)
