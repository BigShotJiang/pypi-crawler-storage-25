from __future__ import annotations

import fcntl
from pathlib import Path
from typing import Any, Callable, Protocol, runtime_checkable


@runtime_checkable
class StorageBackend(Protocol):
    def read_bytes(self, key: str) -> bytes: ...
    def write_bytes(self, key: str, data: bytes) -> None: ...
    def append_bytes_atomic(self, key: str, data: bytes) -> None: ...
    def read_and_append_atomic(self, key: str, transform: Callable[[bytes], bytes]) -> None: ...
    def exists(self, key: str) -> bool: ...
    def list_keys(self, prefix: str) -> list[str]: ...
    def delete(self, key: str) -> None: ...


class LocalFileBackend:
    """StorageBackend backed by the local filesystem. Thread-safe via fcntl.flock."""

    def __init__(self, root: Path) -> None:
        self._root = root

    def _path(self, key: str) -> Path:
        p = (self._root / key).resolve()
        if not str(p).startswith(str(self._root.resolve())):
            raise ValueError(f"Key escapes root: {key!r}")
        return p

    def read_bytes(self, key: str) -> bytes:
        return self._path(key).read_bytes()

    def write_bytes(self, key: str, data: bytes) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_bytes(data)
        tmp.replace(p)

    def append_bytes_atomic(self, key: str, data: bytes) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("ab") as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            try:
                f.write(data)
                f.flush()
            finally:
                fcntl.flock(f, fcntl.LOCK_UN)

    def read_and_append_atomic(self, key: str, transform: Callable[[bytes], bytes]) -> None:
        """Read current content, call transform(content) to get bytes to append, write atomically."""
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("a+b") as f:
            fcntl.flock(f, fcntl.LOCK_EX)
            try:
                f.seek(0)
                current = f.read()
                new_data = transform(current)
                f.seek(0, 2)
                f.write(new_data)
                f.flush()
            finally:
                fcntl.flock(f, fcntl.LOCK_UN)

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def list_keys(self, prefix: str) -> list[str]:
        base = self._root / prefix
        if not base.exists():
            return []
        return sorted(
            str(p.relative_to(self._root))
            for p in base.rglob("*")
            if p.is_file()
        )

    def delete(self, key: str) -> None:
        self._path(key).unlink(missing_ok=True)


class R2Backend:
    """StorageBackend backed by Cloudflare R2 (S3-compatible). Uses conditional PUTs for atomic append."""

    def __init__(self, client: Any, bucket: str, prefix: str) -> None:
        # prefix = "{org_id}/{repo_id}/.GCC"  (no trailing slash)
        self._s3 = client
        self._bucket = bucket
        self._prefix = prefix.rstrip("/")

    def _key(self, relative: str) -> str:
        return f"{self._prefix}/{relative}"

    def read_bytes(self, key: str) -> bytes:
        try:
            resp = self._s3.get_object(Bucket=self._bucket, Key=self._key(key))
            return resp["Body"].read()
        except self._s3.exceptions.ClientError as e:
            if e.response["Error"]["Code"] in ("NoSuchKey", "404"):
                raise FileNotFoundError(key)
            raise

    def write_bytes(self, key: str, data: bytes) -> None:
        self._s3.put_object(Bucket=self._bucket, Key=self._key(key), Body=data)

    def append_bytes_atomic(self, key: str, data: bytes) -> None:
        self.read_and_append_atomic(key, lambda current: data)

    def read_and_append_atomic(self, key: str, transform: Callable[[bytes], bytes]) -> None:
        full_key = self._key(key)
        for attempt in range(10):
            try:
                resp = self._s3.get_object(Bucket=self._bucket, Key=full_key)
                current = resp["Body"].read()
                etag = resp["ETag"].strip('"')
            except self._s3.exceptions.ClientError as e:
                if e.response["Error"]["Code"] in ("NoSuchKey", "404"):
                    current, etag = b"", None
                else:
                    raise

            new_data = transform(current)
            new_content = current + new_data

            try:
                kwargs: dict = {"Bucket": self._bucket, "Key": full_key, "Body": new_content}
                if etag:
                    kwargs["IfMatch"] = f'"{etag}"'
                self._s3.put_object(**kwargs)
                return
            except self._s3.exceptions.ClientError as e:
                if e.response["Error"]["Code"] == "PreconditionFailed":
                    continue
                raise
        raise RuntimeError(f"R2Backend: failed to atomically update {key} after 10 retries")

    def exists(self, key: str) -> bool:
        try:
            self.read_bytes(key)
            return True
        except FileNotFoundError:
            return False

    def list_keys(self, prefix: str) -> list[str]:
        full_prefix = self._key(prefix)
        resp = self._s3.list_objects_v2(Bucket=self._bucket, Prefix=full_prefix)
        contents = resp.get("Contents", [])
        strip = self._prefix + "/"
        return sorted(item["Key"].removeprefix(strip) for item in contents)

    def delete(self, key: str) -> None:
        self._s3.delete_object(Bucket=self._bucket, Key=self._key(key))
