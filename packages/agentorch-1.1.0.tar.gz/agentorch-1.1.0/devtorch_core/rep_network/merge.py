"""
theta.json merge function for REP network synchronisation.
"""
from __future__ import annotations
from typing import Dict

_LEVEL_RANK = {"PUBLIC": 0, "PROTECTED": 1, "PRIVATE": 2}
_RANK_LEVEL = {0: "PUBLIC", 1: "PROTECTED", 2: "PRIVATE"}


def merge_theta(local: dict, remote: dict) -> dict:
    """
    Merge two theta.json dicts (remote into local) and return the merged result.

    Merge rules per concept:
    - event_count: sum of both
    - mean_confidence: weighted mean (weighted by event_count from each side)
    - disclosure_level: max (most restrictive) of both sides
    - last_updated: take the more recent of both (ISO string comparison)

    The returned dict has the same shape as ThetaStore.load() output:
    {
      "version": 1,
      "updated_at": <now ISO UTC>,
      "coordination_vector": { concept: { ... } }
    }
    """
    import datetime as _dt

    local_cv = local.get("coordination_vector", {})
    remote_cv = remote.get("coordination_vector", {})
    all_concepts = set(local_cv) | set(remote_cv)

    merged_cv: Dict[str, dict] = {}
    for concept in all_concepts:
        l = local_cv.get(concept, {})
        r = remote_cv.get(concept, {})

        l_count = int(l.get("event_count", 0))
        r_count = int(r.get("event_count", 0))
        total = l_count + r_count

        if total == 0:
            merged_conf = 0.0
        else:
            l_conf = float(l.get("mean_confidence", 0.0))
            r_conf = float(r.get("mean_confidence", 0.0))
            merged_conf = round((l_conf * l_count + r_conf * r_count) / total, 6)

        l_rank = _LEVEL_RANK.get(l.get("disclosure_level", "PUBLIC"), 0)
        r_rank = _LEVEL_RANK.get(r.get("disclosure_level", "PUBLIC"), 0)
        merged_level = _RANK_LEVEL[max(l_rank, r_rank)]

        l_ts = l.get("last_updated", "")
        r_ts = r.get("last_updated", "")
        merged_ts = l_ts if l_ts >= r_ts else r_ts

        merged_cv[concept] = {
            "event_count": total,
            "mean_confidence": merged_conf,
            "disclosure_level": merged_level,
            "last_updated": merged_ts,
        }

    now = _dt.datetime.now(tz=_dt.timezone.utc).isoformat()
    return {
        "version": local.get("version", 1),
        "updated_at": now,
        "coordination_vector": merged_cv,
    }
