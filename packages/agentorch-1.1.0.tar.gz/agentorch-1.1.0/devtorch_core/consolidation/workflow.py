from __future__ import annotations

import dataclasses
import datetime as _dt
import json
import uuid
from pathlib import Path
from typing import List, Optional

from devtorch_core.divergence.detector import DivergenceSignal

_CONSOLIDATIONS_DIR = "consolidations"

_SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


@dataclasses.dataclass
class ConsolidationRecord:
    """
    Durable record of a consolidation event.

    decision_trace is DevTorch's own reasoning — WHY it chose to block,
    escalate to human, or auto-resolve.
    """
    record_id: str
    concept: str
    signals: List[dict]          # serialised DivergenceSignal dicts
    state: str                   # drafting | pending_human | auto_resolved | resolved | blocked
    decision: str                # consolidated position text
    decision_trace: str          # DevTorch's reasoning for its action
    agents_involved: List[str]
    human_comments: List[dict]
    created_at: str
    resolved_at: Optional[str] = None

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ConsolidationRecord":
        known = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in known})


class ConsolidationWorkflow:
    """
    State machine for agent reasoning consolidation.

    Transitions:
      drafting → pending_human  (HIGH or MEDIUM severity divergence)
      drafting → auto_resolved  (LOW severity only)
      drafting → blocked        (signal type E: consensus contradiction)
      pending_human → resolved  (human provides decision via add_human_comment)
    """

    def __init__(self, repo) -> None:
        self._repo = repo
        self._gcc_dir = repo.gcc_dir
        self._dir = self._gcc_dir / _CONSOLIDATIONS_DIR
        self._dir.mkdir(exist_ok=True)

    def start(
        self,
        concept: str,
        signals: List[DivergenceSignal],
    ) -> ConsolidationRecord:
        """Create a ConsolidationRecord and determine initial state from signals."""
        record_id = str(uuid.uuid4())
        now = _dt.datetime.now(tz=_dt.timezone.utc).isoformat()

        all_agents = list({aid for s in signals for aid in s.agent_ids})
        max_severity = self._max_severity(signals)

        # E-type signals always block
        e_signals = [s for s in signals if s.signal_type == "E"]
        if e_signals:
            state = "blocked"
            decision = ""
            trace = (
                f"Blocked: {len(e_signals)} consensus contradiction(s) detected on '{concept}'. "
                "Human review required before proceeding."
            )
        elif max_severity == "LOW":
            state = "auto_resolved"
            decision = self._auto_decision(concept, signals)
            trace = (
                f"Auto-resolved: all signals LOW severity on '{concept}'. "
                f"Signals: {', '.join(s.signal_type for s in signals)}. "
                "No human intervention required."
            )
        else:
            state = "pending_human"
            decision = ""
            trace = (
                f"Escalated to human: {max_severity} severity signal(s) detected on '{concept}'. "
                f"Signal types: {', '.join(s.signal_type + '(' + s.severity + ')' for s in signals)}. "
                "Awaiting human comment or resolution."
            )

        record = ConsolidationRecord(
            record_id=record_id,
            concept=concept,
            signals=[dataclasses.asdict(s) for s in signals],
            state=state,
            decision=decision,
            decision_trace=trace,
            agents_involved=all_agents,
            human_comments=[],
            created_at=now,
            resolved_at=now if state == "auto_resolved" else None,
        )
        self._save(record)
        return record

    def add_human_comment(
        self,
        record_id: str,
        author: str,
        comment: str,
        decision: Optional[str] = None,
    ) -> ConsolidationRecord:
        """Add a human comment and optionally resolve the record."""
        record = self.get(record_id)
        if record is None:
            raise ValueError(f"ConsolidationRecord {record_id!r} not found")

        now = _dt.datetime.now(tz=_dt.timezone.utc).isoformat()
        record.human_comments.append({"author": author, "comment": comment, "timestamp": now})

        if decision is not None:
            record.decision = decision
            record.state = "resolved"
            record.resolved_at = now
            record.decision_trace += f"\nResolved by {author} at {now[:19]}: {decision}"

        self._save(record)
        return record

    def get(self, record_id: str) -> Optional[ConsolidationRecord]:
        path = self._dir / f"{record_id}.json"
        if not path.exists():
            return None
        try:
            return ConsolidationRecord.from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, TypeError):
            return None

    def list_for_concept(self, concept: str) -> List[ConsolidationRecord]:
        results = []
        for f in self._dir.glob("*.json"):
            try:
                d = json.loads(f.read_text(encoding="utf-8"))
                if d.get("concept") == concept:
                    results.append(ConsolidationRecord.from_dict(d))
            except (json.JSONDecodeError, TypeError):
                continue
        return sorted(results, key=lambda r: r.created_at, reverse=True)

    def _save(self, record: ConsolidationRecord) -> None:
        path = self._dir / f"{record.record_id}.json"
        path.write_text(json.dumps(record.to_dict(), indent=2) + "\n", encoding="utf-8")

    @staticmethod
    def _max_severity(signals: List[DivergenceSignal]) -> str:
        if not signals:
            return "LOW"
        return min(signals, key=lambda s: _SEVERITY_ORDER.get(s.severity, 99)).severity

    @staticmethod
    def _auto_decision(concept: str, signals: List[DivergenceSignal]) -> str:
        return (
            f"No high-severity divergence detected on '{concept}'. "
            "Agents may proceed with existing sensitivity signals. "
            f"Low-severity signals noted: {', '.join(s.description[:80] for s in signals)}."
        )
