"""
LLM-powered consolidation synthesizer.

Uses the same pattern as theta_synthesis.py: builds a prompt from
ReasoningEntries + DivergenceSignals, sends to claude-haiku, returns
a ConsolidationDraft. Gated by DEVTORCH_DISABLE env var.
Never raises — errors return a skip result.
"""
from __future__ import annotations

import dataclasses
import os
from typing import List


@dataclasses.dataclass
class ConsolidationDraft:
    decision: str
    decision_trace: str
    model: str
    tokens_used: int
    skipped: bool = False
    skip_reason: str = ""


def synthesise_consolidation(
    concept: str,
    reasoning_entries: list,
    divergence_signals: list,
    model: str = "claude-haiku-4-5-20251001",
) -> ConsolidationDraft:
    """Run LLM synthesis over reasoning entries + divergence signals."""
    if os.environ.get("DEVTORCH_DISABLE"):
        return ConsolidationDraft(decision="", decision_trace="", model=model, tokens_used=0,
                                  skipped=True, skip_reason="DEVTORCH_DISABLE set")
    try:
        import anthropic
    except ImportError:
        return ConsolidationDraft(decision="", decision_trace="", model=model, tokens_used=0,
                                  skipped=True, skip_reason="anthropic SDK not installed")

    prompt = _build_prompt(concept, reasoning_entries, divergence_signals)
    try:
        client = anthropic.Anthropic()
        response = client.messages.create(
            model=model,
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}],
        )
        text = response.content[0].text if response.content else ""
        tokens = response.usage.input_tokens + response.usage.output_tokens
        decision, trace = _parse_response(text)
        return ConsolidationDraft(decision=decision, decision_trace=trace,
                                  model=model, tokens_used=tokens)
    except Exception as exc:
        return ConsolidationDraft(decision="", decision_trace="", model=model, tokens_used=0,
                                  skipped=True, skip_reason=str(exc))


def _build_prompt(concept: str, reasoning_entries: list, divergence_signals: list) -> str:
    entry_lines = "\n".join(
        f"  [{i+1}] agent={e.agent_id} conf={e.confidence:.2f}: {e.reasoning_text[:200]}"
        for i, e in enumerate(reasoning_entries[:10])
    )
    signal_lines = "\n".join(
        f"  [{s.signal_type}/{s.severity}] {s.description}"
        for s in divergence_signals[:5]
    )
    return (
        f"You are a governance analyst. Agents have diverged on concept: '{concept}'.\n\n"
        f"Agent reasoning:\n{entry_lines or '  (none)'}\n\n"
        f"Divergence signals:\n{signal_lines or '  (none)'}\n\n"
        "Write two sections:\n"
        "DECISION: A 1-2 sentence consolidated position that resolves the divergence.\n"
        "TRACE: A 1-2 sentence explanation of WHY this consolidation was reached.\n\n"
        "Format exactly:\nDECISION: <text>\nTRACE: <text>"
    )


def _parse_response(text: str) -> tuple[str, str]:
    decision, trace = "", ""
    for line in text.splitlines():
        if line.startswith("DECISION:"):
            decision = line[len("DECISION:"):].strip()
        elif line.startswith("TRACE:"):
            trace = line[len("TRACE:"):].strip()
    return decision or text[:200], trace or "LLM synthesis"
