from __future__ import annotations

import hashlib
import hmac
import json
import threading
import time
from typing import Any, Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse

EXEMPT_PATHS = frozenset({"/health", "/readyz"})


class APIKeyMiddleware(BaseHTTPMiddleware):
    """
    Validates X-DevTorch-Key header against SHA-256 hashes stored in R2
    at {org_id}/.devtorch/api_keys.json.

    Injects request.state.org_id and request.state.allowed_repos on success.
    Org is taken from URL path: /{org_id}/{repo_id}/...
    """

    API_KEYS_KEY = ".devtorch/api_keys.json"

    def __init__(self, app: Any, backend: Any) -> None:
        super().__init__(app)
        self._backend = backend

    async def dispatch(self, request: Request, call_next: Any) -> Any:
        if request.url.path in EXEMPT_PATHS:
            return await call_next(request)
        raw_key = request.headers.get("X-DevTorch-Key")
        if raw_key is None:
            return JSONResponse({"detail": "Missing X-DevTorch-Key"}, status_code=401)

        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

        try:
            data = json.loads(self._backend.read_bytes(self.API_KEYS_KEY))
        except (FileNotFoundError, json.JSONDecodeError):
            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

        entry = next(
            (v for k, v in data.items() if hmac.compare_digest(k, key_hash)),
            None,
        )
        if entry is None:
            return JSONResponse({"detail": "Unauthorized"}, status_code=401)

        token_org = entry.get("org_id", "")
        allowed_repos = entry.get("allowed_repos")  # None means all repos

        # Validate org from URL path
        path_parts = request.url.path.strip("/").split("/")
        if request.url.path not in EXEMPT_PATHS:
            if len(path_parts) < 2:
                return JSONResponse({"detail": "Forbidden"}, status_code=403)
            url_org, url_repo = path_parts[0], path_parts[1]
            if url_org != token_org:
                return JSONResponse({"detail": "Forbidden"}, status_code=403)
            if allowed_repos is not None and url_repo not in allowed_repos:
                return JSONResponse({"detail": "Forbidden"}, status_code=403)

        request.state.org_id = token_org
        request.state.allowed_repos = allowed_repos
        return await call_next(request)


class OAuthMiddleware(BaseHTTPMiddleware):
    """
    Validates Authorization: Bearer <jwt> against JWKS endpoints.
    Supports multiple providers via DEVTORCH_JWKS_URLS (comma-separated).
    Caches JWKS in memory with a 5-minute TTL.
    Trusted providers include GitHub Actions OIDC (https://token.actions.githubusercontent.com).
    """

    CACHE_TTL = 300  # 5 minutes

    def __init__(self, app: Any, jwks_urls: list[str]) -> None:
        super().__init__(app)
        self._jwks_urls = jwks_urls
        self._jwks_cache: dict[str, Any] = {}  # kid → public key
        self._cache_lock = threading.Lock()
        self._cache_expiry: float = 0.0

    async def dispatch(self, request: Request, call_next: Any) -> Any:
        if request.url.path in EXEMPT_PATHS:
            return await call_next(request)

        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            return JSONResponse({"detail": "Missing Bearer token"}, status_code=401)

        token = auth.removeprefix("Bearer ").strip()

        try:
            import jwt as _jwt
            from jwt.exceptions import PyJWTError
        except ImportError:
            return JSONResponse({"detail": "Server misconfiguration: PyJWT not installed"}, status_code=500)

        try:
            header = _jwt.get_unverified_header(token)
            kid = header.get("kid")
            key = self._get_key(kid)
            if key is None:
                return JSONResponse({"detail": "Unknown key id"}, status_code=401)
            payload = _jwt.decode(token, key, algorithms=["RS256", "ES256"])
        except PyJWTError:
            return JSONResponse({"detail": "Invalid or expired token"}, status_code=401)

        org_id = payload.get("org") or payload.get("https://devtorch.ai/org")
        if not org_id:
            return JSONResponse({"detail": "Missing org claim"}, status_code=401)

        path_parts = request.url.path.strip("/").split("/")
        if len(path_parts) >= 1 and path_parts[0] != org_id:
            return JSONResponse({"detail": "Forbidden"}, status_code=403)

        request.state.org_id = org_id
        request.state.user_id = payload.get("sub")
        return await call_next(request)

    def _get_key(self, kid: Optional[str]) -> Optional[Any]:
        with self._cache_lock:
            expiry = self._cache_expiry
            current_cache = dict(self._jwks_cache)

        # Refresh outside the lock — may be done by multiple threads simultaneously
        # (idempotent: worst case is a redundant fetch)
        if time.monotonic() > expiry:
            new_cache = self._fetch_jwks()
            if new_cache:
                with self._cache_lock:
                    merged = dict(self._jwks_cache)
                    merged.update(new_cache)
                    self._jwks_cache = merged
                    self._cache_expiry = time.monotonic() + self.CACHE_TTL
                    current_cache = dict(self._jwks_cache)
            else:
                # Back off 30s before next attempt to avoid thundering herd
                with self._cache_lock:
                    self._cache_expiry = time.monotonic() + 30

        return current_cache.get(kid) if kid else None

    def _fetch_jwks(self) -> dict[str, Any]:
        """Fetch all JWKS URLs and return a dict of kid → public_key. Returns empty dict on total failure."""
        import urllib.request
        import json as _json

        new_cache: dict[str, Any] = {}
        for url in self._jwks_urls:
            try:
                with urllib.request.urlopen(url, timeout=5) as resp:
                    data = _json.loads(resp.read())
                for jwk in data.get("keys", []):
                    try:
                        key = self._jwk_to_public_key(jwk)
                        new_cache[jwk["kid"]] = key
                    except Exception:
                        pass
            except Exception:
                pass  # keep going, try next URL
        return new_cache

    @staticmethod
    def _jwk_to_public_key(jwk: dict) -> Any:
        from jwt.algorithms import RSAAlgorithm, ECAlgorithm
        import json as _json
        alg = jwk.get("kty", "RSA")
        if alg == "RSA":
            return RSAAlgorithm.from_jwk(_json.dumps(jwk))
        return ECAlgorithm.from_jwk(_json.dumps(jwk))
