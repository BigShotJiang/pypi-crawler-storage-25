"""
S7 MCP Server — DevTorch primitives exposed via JSON-RPC 2.0 / MCP protocol.

Supports two transports:
- If the `mcp` SDK is installed: uses mcp.server.Server + stdio_server
- Fallback: raw JSON-RPC 2.0 line-by-line stdio loop

Tools exposed:
  devtorch_commit          — Commit a reasoning milestone to .GCC/
  devtorch_sensitivity_add — Record a sensitivity signal
  devtorch_context         — Retrieve bounded context bundle
  devtorch_theta_read      — Read coordination vector Θ
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# FastAPI / Starlette imports — only needed for SSE transport, but must be at
# module level so that FastAPI can resolve string annotations (PEP 563) when
# building the route dependency graph.
try:
    from fastapi import FastAPI as _FastAPI, Request as _Request, HTTPException as _HTTPException
    from fastapi.responses import StreamingResponse as _StreamingResponse, Response as _Response
    _FASTAPI_AVAILABLE = True
except ImportError:  # pragma: no cover
    _FASTAPI_AVAILABLE = False
    _FastAPI = None  # type: ignore[assignment,misc]
    _Request = None  # type: ignore[assignment]
    _HTTPException = None  # type: ignore[assignment]
    _StreamingResponse = None  # type: ignore[assignment]
    _Response = None  # type: ignore[assignment]

# ---------------------------------------------------------------------------
# Tool definitions (shared between MCP-SDK path and fallback path)
# ---------------------------------------------------------------------------

TOOLS: List[Dict[str, Any]] = [
    {
        "name": "devtorch_commit",
        "description": "Commit a reasoning milestone to the .GCC/ store",
        "inputSchema": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "Commit message"},
                "branch": {
                    "type": "string",
                    "description": "Branch name (optional)",
                },
            },
            "required": ["message"],
        },
    },
    {
        "name": "devtorch_sensitivity_add",
        "description": "Record what this decision depends on (sensitivity signal)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "concept": {"type": "string", "description": "Target concept"},
                "signal": {
                    "type": "string",
                    "description": "Signal / counterfactual text",
                },
                "confidence": {
                    "type": "number",
                    "description": "Confidence in [0, 1]",
                },
                "disclosure": {
                    "type": "string",
                    "description": "Disclosure level: PUBLIC, PROTECTED (default), or PRIVATE",
                },
            },
            "required": ["concept", "signal", "confidence"],
        },
    },
    {
        "name": "devtorch_context",
        "description": "Retrieve bounded context bundle from .GCC/ (use this at session start)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "k": {
                    "type": "integer",
                    "description": "Token budget (default 8000)",
                },
            },
        },
    },
    {
        "name": "devtorch_theta_read",
        "description": "Read current coordination vector Θ (shared sensitivity state)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "concepts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Filter to specific concepts (optional)",
                },
            },
        },
    },
    {
        "name": "devtorch_reasoning_query",
        "description": "Query an agent's reasoning about a specific concept (use at session start to understand prior decisions)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "concept": {"type": "string", "description": "Concept to query (e.g. auth, schema, payments)"},
                "agent_id": {"type": "string", "description": "Filter to a specific agent ID (optional)"},
                "scope": {"type": "string", "description": "branch | session | org (default: branch)"},
                "k": {"type": "integer", "description": "Token budget (default 4000)"},
            },
            "required": ["concept"],
        },
    },
    {
        "name": "devtorch_divergence_detect",
        "description": "Detect reasoning divergence between agents for a concept",
        "inputSchema": {
            "type": "object",
            "properties": {
                "concept": {"type": "string"},
            },
            "required": ["concept"],
        },
    },
    {
        "name": "devtorch_consolidation_status",
        "description": "Get consolidation record status for a concept",
        "inputSchema": {
            "type": "object",
            "properties": {
                "concept": {"type": "string"},
            },
            "required": ["concept"],
        },
    },
    {
        "name": "devtorch_hitl_respond",
        "description": "Provide a human or agent resolution to a pending HITL consolidation",
        "inputSchema": {
            "type": "object",
            "properties": {
                "record_id": {"type": "string", "description": "ConsolidationRecord ID"},
                "author": {"type": "string", "description": "Responder name or agent_id"},
                "comment": {"type": "string", "description": "Explanation or reasoning"},
                "decision": {"type": "string", "description": "The consolidated decision text"},
            },
            "required": ["record_id", "author", "decision"],
        },
    },
]

# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------


def _tool_devtorch_commit(repo: Any, args: dict) -> str:
    message = args.get("message", "")
    repo.commit(message=message)
    return "Committed to .GCC/"


def _tool_devtorch_sensitivity_add(repo: Any, args: dict) -> str:
    from devtorch_core.sensitivity import SensitivityEvent

    concept = args["concept"]
    signal = args["signal"]
    confidence = float(args["confidence"])
    disclosure = args.get("disclosure", "PROTECTED").upper()
    if disclosure not in ("PUBLIC", "PROTECTED", "PRIVATE"):
        disclosure = "PROTECTED"

    ev = SensitivityEvent(
        source_node="mcp-client",
        target_concept=concept,
        counterfactuals=signal,
        confidence=confidence,
        disclosure_level=disclosure,
        message=signal,
    )
    repo.add_sensitivity(ev)
    return f"Sensitivity recorded: {concept} @ {confidence}"


def _tool_devtorch_context(repo: Any, args: dict) -> str:
    k = int(args.get("k", 8000))
    bundle = repo.context_bundle(
        k_tokens=k, policy={"sensitivity_policy": "default"}
    )
    # bundle is a dict; format it as a readable string
    artifacts = bundle.get("artifacts", [])
    if not artifacts:
        return f"Context bundle (budget={k} tokens): no artifacts found."

    lines = [f"Context bundle (budget={k} tokens, {len(artifacts)} artifacts):"]
    for art in artifacts:
        # Support both "name" (test mock) and "path" (real GCCRepository output)
        name = art.get("name", art.get("path", art.get("id", "unknown")))
        reason = art.get("reason", "")
        # Support both "tokens" (test mock) and "approx_tokens" (real GCCRepository output)
        tokens = art.get("tokens", art.get("approx_tokens", "?"))
        lines.append(f"  - {name} ({tokens} tokens): {reason}")
    return "\n".join(lines)


def _tool_devtorch_theta_read(repo: Any, args: dict) -> str:
    theta = repo.get_theta().get("coordination_vector", {})
    concepts = args.get("concepts")
    if concepts:
        theta = {k: v for k, v in theta.items() if k in concepts}
    return json.dumps(theta, indent=2)


def _tool_devtorch_reasoning_query(repo: Any, args: dict) -> str:
    from devtorch_core.reasoning import ReasoningStore

    concept = args["concept"]
    agent_id = args.get("agent_id")
    scope = args.get("scope", "branch")
    k = int(args.get("k", 4000))

    store = ReasoningStore(repo)
    entries = store.query(concept=concept, agent_id=agent_id, scope=scope, k_tokens=k)

    if not entries:
        return f"No reasoning entries found for concept '{concept}'."

    lines = [f"Reasoning for '{concept}' ({len(entries)} entries, budget={k} tokens):"]
    for e in entries:
        lines.append(
            f"\n  [{e.timestamp[:19]}] agent={e.agent_id} conf={e.confidence:.2f} [{e.disclosure_level}]"
        )
        lines.append(f"  Reasoning: {e.reasoning_text}")
        if e.decision_text:
            lines.append(f"  Decision:  {e.decision_text}")
    return "\n".join(lines)


def _tool_devtorch_divergence_detect(repo: Any, args: dict) -> str:
    from devtorch_core.divergence import DivergenceDetector
    concept = args["concept"]
    signals = DivergenceDetector(repo).detect(concept=concept)
    if not signals:
        return f"No divergence detected for concept '{concept}'."
    lines = [f"Divergence signals for '{concept}' ({len(signals)} signals):"]
    for s in signals:
        lines.append(f"  [{s.signal_type}/{s.severity}] {s.description}")
    return "\n".join(lines)


def _tool_devtorch_consolidation_status(repo: Any, args: dict) -> str:
    from devtorch_core.consolidation import ConsolidationWorkflow
    concept = args["concept"]
    records = ConsolidationWorkflow(repo).list_for_concept(concept)
    if not records:
        return f"No consolidation records found for concept '{concept}'."
    r = records[0]  # most recent
    return (
        f"Consolidation '{r.record_id[:8]}' — concept='{r.concept}' state={r.state}\n"
        f"  Decision: {r.decision or '(pending)'}\n"
        f"  Trace: {r.decision_trace[:200]}\n"
        f"  Agents: {', '.join(r.agents_involved)}"
    )


def _tool_devtorch_hitl_respond(repo: Any, args: dict) -> str:
    from devtorch_core.consolidation import ConsolidationWorkflow
    record_id = args["record_id"]
    author = args["author"]
    comment = args.get("comment", "")
    decision = args["decision"]
    workflow = ConsolidationWorkflow(repo)
    record = workflow.add_human_comment(
        record_id=record_id,
        author=author,
        comment=comment or decision,
        decision=decision,
    )
    return f"Recorded: consolidation '{record_id[:8]}' resolved by '{author}'. State: {record.state}."


def _dispatch_tool(repo: Any, name: str, args: dict) -> str:
    if name == "devtorch_commit":
        return _tool_devtorch_commit(repo, args)
    elif name == "devtorch_sensitivity_add":
        return _tool_devtorch_sensitivity_add(repo, args)
    elif name == "devtorch_context":
        return _tool_devtorch_context(repo, args)
    elif name == "devtorch_theta_read":
        return _tool_devtorch_theta_read(repo, args)
    elif name == "devtorch_reasoning_query":
        return _tool_devtorch_reasoning_query(repo, args)
    elif name == "devtorch_divergence_detect":
        return _tool_devtorch_divergence_detect(repo, args)
    elif name == "devtorch_consolidation_status":
        return _tool_devtorch_consolidation_status(repo, args)
    elif name == "devtorch_hitl_respond":
        return _tool_devtorch_hitl_respond(repo, args)
    else:
        raise ValueError(f"Unknown tool: {name}")


# ---------------------------------------------------------------------------
# MCP SDK path
# ---------------------------------------------------------------------------


def _run_with_sdk(repo: Any) -> None:
    """Run using the official mcp Python SDK."""
    import asyncio
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    import mcp.types as types

    server = Server("devtorch")

    @server.list_tools()  # type: ignore[misc]
    async def list_tools() -> List[types.Tool]:
        result = []
        for t in TOOLS:
            result.append(
                types.Tool(
                    name=t["name"],
                    description=t["description"],
                    inputSchema=t["inputSchema"],
                )
            )
        return result

    @server.call_tool()  # type: ignore[misc]
    async def call_tool(
        name: str, arguments: dict
    ) -> List[types.TextContent]:
        try:
            text = _dispatch_tool(repo, name, arguments or {})
        except Exception as exc:
            text = f"Error: {exc}"
        return [types.TextContent(type="text", text=text)]

    async def _run() -> None:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )

    asyncio.run(_run())


# ---------------------------------------------------------------------------
# Minimal JSON-RPC 2.0 fallback
# ---------------------------------------------------------------------------

_JSONRPC_VERSION = "2.0"


def _make_response(id: Any, result: Any) -> dict:
    return {"jsonrpc": _JSONRPC_VERSION, "id": id, "result": result}


def _make_error(id: Any, code: int, message: str) -> dict:
    return {
        "jsonrpc": _JSONRPC_VERSION,
        "id": id,
        "error": {"code": code, "message": message},
    }


def _handle_request(repo: Any, req: dict) -> Optional[dict]:
    """Dispatch a single JSON-RPC request and return the response dict (or None for notifications)."""
    req_id = req.get("id")
    method = req.get("method", "")
    params = req.get("params") or {}

    # Notifications (no id) — process but no response
    is_notification = "id" not in req

    if method == "initialize":
        result = {
            "protocolVersion": "2024-11-05",
            "capabilities": {"tools": {}},
            "serverInfo": {"name": "devtorch", "version": "0.7.0"},
        }
        if is_notification:
            return None
        return _make_response(req_id, result)

    elif method == "notifications/initialized":
        return None  # no response for notifications

    elif method == "tools/list":
        result = {"tools": TOOLS}
        if is_notification:
            return None
        return _make_response(req_id, result)

    elif method == "tools/call":
        name = params.get("name", "")
        arguments = params.get("arguments") or {}
        try:
            text = _dispatch_tool(repo, name, arguments)
            result = {
                "content": [{"type": "text", "text": text}],
                "isError": False,
            }
        except Exception as exc:
            result = {
                "content": [{"type": "text", "text": f"Error: {exc}"}],
                "isError": True,
            }
        if is_notification:
            return None
        return _make_response(req_id, result)

    elif method == "ping":
        if is_notification:
            return None
        return _make_response(req_id, {})

    else:
        if is_notification:
            return None
        return _make_error(req_id, -32601, f"Method not found: {method}")


def _run_raw_stdio(repo: Any) -> None:
    """Minimal JSON-RPC 2.0 stdio loop (fallback when mcp SDK not installed)."""
    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        try:
            req = json.loads(raw_line)
        except json.JSONDecodeError as exc:
            resp = _make_error(None, -32700, f"Parse error: {exc}")
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()
            continue

        try:
            resp = _handle_request(repo, req)
        except Exception as exc:
            resp = _make_error(req.get("id"), -32603, f"Internal error: {exc}")

        if resp is not None:
            sys.stdout.write(json.dumps(resp) + "\n")
            sys.stdout.flush()


# ---------------------------------------------------------------------------
# Server entry points
# ---------------------------------------------------------------------------


def run_server(repo: Any) -> None:
    """Run the MCP server using the best available transport."""
    try:
        import mcp  # noqa: F401
        _run_with_sdk(repo)
    except ImportError:
        _run_raw_stdio(repo)


def find_gcc_repo() -> Optional[Any]:
    """
    Find an initialised .GCC/ repository.

    Search order:
    1. DEVTORCH_GCC_PATH env var — explicit project root (used by IDE MCP configs)
    2. Walk upward from cwd
    """
    import os
    from devtorch_core import GCCRepository

    explicit = os.environ.get("DEVTORCH_GCC_PATH", "").strip()
    if explicit:
        r = GCCRepository.at(Path(explicit))
        if r.is_initialized():
            return r

    for parent in [Path.cwd()] + list(Path.cwd().parents):
        r = GCCRepository.at(parent)
        if r.is_initialized():
            return r
    return None


def main() -> None:
    """Entry point: devtorch mcp-server"""
    gcc = find_gcc_repo()
    if gcc is None:
        print(
            "error: no .GCC/ found in current directory or parents. "
            "Set DEVTORCH_GCC_PATH=/path/to/project to point to your project root.",
            file=sys.stderr,
        )
        sys.exit(1)
    run_server(gcc)


# ---------------------------------------------------------------------------
# SSE transport (cloud MCP server)
# ---------------------------------------------------------------------------

import asyncio as _asyncio
import uuid as _uuid_mod
import json as _json_mod
from typing import Callable as _Callable

# Global session registry: session_id → (asyncio.Queue, GCCRepository)
_session_queues: dict[str, tuple[_asyncio.Queue, Any]] = {}


def build_sse_app(
    repo_factory: _Callable[[str, str], Any],
    auth_backend: Any = None,
) -> Any:
    """Build the FastAPI app for the cloud SSE MCP server."""
    # Use module-level _FastAPI / _Request etc. so FastAPI can resolve the
    # string annotations produced by `from __future__ import annotations`.
    app = _FastAPI(title="DevTorch Cloud MCP Server")

    if auth_backend is not None:
        from devtorch_core.mcp.auth import APIKeyMiddleware, OAuthMiddleware
        import os
        jwks_urls = [u for u in os.environ.get("DEVTORCH_JWKS_URLS", "").split(",") if u]
        if jwks_urls:
            app.add_middleware(OAuthMiddleware, jwks_urls=jwks_urls)
        app.add_middleware(APIKeyMiddleware, backend=auth_backend)

    @app.get("/{org_id}/{repo_id}/sse")
    async def sse_endpoint(org_id: str, repo_id: str, request: _Request):
        session_id = str(_uuid_mod.uuid4())
        queue: _asyncio.Queue = _asyncio.Queue()
        repo = repo_factory(org_id, repo_id)
        _session_queues[session_id] = (queue, repo)

        base_url = str(request.base_url).rstrip("/")
        messages_url = f"{base_url}/{org_id}/{repo_id}/messages?sessionId={session_id}"

        async def event_stream():
            try:
                yield f"event: endpoint\ndata: {messages_url}\n\n"
                while True:
                    try:
                        item = await _asyncio.wait_for(queue.get(), timeout=30)
                        yield f"event: message\ndata: {_json_mod.dumps(item)}\n\n"
                    except _asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            finally:
                _session_queues.pop(session_id, None)

        return _StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    @app.post("/{org_id}/{repo_id}/messages")
    async def messages_endpoint(org_id: str, repo_id: str, sessionId: str, request: _Request):
        entry = _session_queues.get(sessionId)
        if entry is None:
            raise _HTTPException(status_code=404, detail="Session not found")

        queue, repo = entry
        body = await request.json()

        if not isinstance(body, dict):
            raise _HTTPException(status_code=400, detail="Request body must be a JSON object")

        try:
            response = _handle_request(repo, body)
        except Exception as exc:
            response = _make_error(body.get("id"), -32603, str(exc))

        if response is not None:
            await queue.put(response)

        return _Response(status_code=202)

    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/readyz")
    async def readyz():
        return {"status": "ready"}

    return app


def _run_with_sse(
    repo_factory: _Callable[[str, str], Any],
    auth_backend: Any = None,
    host: str = "0.0.0.0",
    port: int = 8080,
) -> None:
    import uvicorn
    app = build_sse_app(repo_factory=repo_factory, auth_backend=auth_backend)
    uvicorn.run(app, host=host, port=port)
