from __future__ import annotations

import datetime as _dt
import json
import uuid
from pathlib import Path
from typing import List, Optional

from devtorch_core.divergence import DivergenceDetector
from devtorch_core.consolidation import ConsolidationWorkflow, ConsolidationRecord
from .channels import HITLChannel, HITLRequest

_HITL_DIR = "hitl"


class HITLOrchestrator:
    """
    Detects divergence, starts a ConsolidationWorkflow, and triggers HITL
    when the severity requires human input.

    Flow:
      1. Detect divergence for concept.
      2. If no divergence → return None.
      3. Start ConsolidationWorkflow → get ConsolidationRecord.
      4. If state is pending_human/blocked → build HITLRequest, send to channels.
      5. Poll channels for response; if found → add_human_comment to record.
      6. Return ConsolidationRecord.
    """

    def __init__(self, repo, channels: List[HITLChannel], poll_attempts: int = 1) -> None:
        self._repo = repo
        self._channels = channels
        self._poll_attempts = poll_attempts
        self._hitl_dir = repo.gcc_dir / _HITL_DIR
        self._hitl_dir.mkdir(exist_ok=True)

    def run(self, concept: str) -> Optional[ConsolidationRecord]:
        signals = DivergenceDetector(self._repo).detect(concept=concept)
        if not signals:
            return None

        workflow = ConsolidationWorkflow(self._repo)
        record = workflow.start(concept=concept, signals=signals)

        if record.state in ("pending_human", "blocked"):
            request = self._build_request(record)
            self._persist_request(request)
            for channel in self._channels:
                channel.send(request)

            response = self._collect_response(request)
            if response:
                workflow.add_human_comment(
                    record_id=record.record_id,
                    author=response.get("responder", "human"),
                    comment=response.get("text", ""),
                    decision=response.get("text"),
                )
                record = workflow.get(record.record_id)

        return record

    def _build_request(self, record: ConsolidationRecord) -> HITLRequest:
        signal_descs = [s.get("description", "")[:100] for s in record.signals[:3]]
        options = [
            f"Accept highest-disclosure level (most restrictive)",
            f"Accept lowest-disclosure level (most permissive)",
            f"Defer — mark concept '{record.concept}' as requiring manual review",
        ]
        return HITLRequest(
            request_id=str(uuid.uuid4()),
            concept=record.concept,
            consolidation_record_id=record.record_id,
            signals=record.signals,
            prompt=(
                f"Divergence detected on '{record.concept}': "
                + "; ".join(signal_descs)
                + "\nPlease provide a resolution or select an option."
            ),
            options=options,
            state="pending",
            created_at=_dt.datetime.now(tz=_dt.timezone.utc).isoformat(),
        )

    def _persist_request(self, request: HITLRequest) -> None:
        path = self._hitl_dir / f"{request.request_id}.json"
        path.write_text(json.dumps(request.to_dict(), indent=2) + "\n", encoding="utf-8")

    def _collect_response(self, request: HITLRequest) -> Optional[dict]:
        for _ in range(self._poll_attempts):
            for channel in self._channels:
                text = channel.poll(request.request_id)
                if text:
                    return {"text": text, "responder": channel.channel_name}
        return None
