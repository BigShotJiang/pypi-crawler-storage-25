from __future__ import annotations

import dataclasses
import datetime as _dt
import json
import uuid
from collections import deque
from pathlib import Path
from typing import Deque, List, Optional


@dataclasses.dataclass
class HITLRequest:
    """
    A request for human (or arbiter agent) input on a divergence.

    options provides suggested resolution choices; the human may pick one
    or write free-form text in their response.
    """
    request_id: str
    concept: str
    consolidation_record_id: str
    signals: List[dict]
    prompt: str
    options: List[str]
    state: str               # "pending" | "responded" | "timeout"
    created_at: str
    response: Optional[str] = None
    responded_at: Optional[str] = None
    responder: Optional[str] = None

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)


class HITLChannel:
    """Base class for HITL notification + response channels."""
    channel_name: str = "base"

    def send(self, request: HITLRequest) -> None:
        raise NotImplementedError

    def poll(self, request_id: str) -> Optional[str]:
        """Return response text if available, else None."""
        raise NotImplementedError


class CLIHITLChannel(HITLChannel):
    """
    CLI-based HITL channel for development and testing.

    In tests, pass a `response_queue` list — responses are dequeued in order.
    In interactive use (response_queue=None), reads from stdin.
    """
    channel_name = "cli"

    def __init__(self, response_queue: Optional[List[str]] = None) -> None:
        self._queue: Deque[str] = deque(response_queue or [])
        self._responses: dict[str, str] = {}

    def send(self, request: HITLRequest) -> None:
        if self._queue:
            response = self._queue.popleft()
            self._responses[request.request_id] = response
        else:
            print(f"\n[DevTorch HITL] Concept: {request.concept}")
            print(f"  {request.prompt}")
            for i, opt in enumerate(request.options, 1):
                print(f"  {i}. {opt}")
            answer = input("  Your response: ").strip()
            self._responses[request.request_id] = answer

    def poll(self, request_id: str) -> Optional[str]:
        return self._responses.get(request_id)


class SlackHITLChannel(HITLChannel):
    """
    Slack-based HITL channel.

    Sends a Block Kit message via webhook. Responses are written to
    .GCC/hitl/<request_id>.response.json by an external Slack action handler;
    poll() reads from that file.
    """
    channel_name = "slack"

    def __init__(self, webhook_url: str, gcc_dir: Path) -> None:
        self._webhook_url = webhook_url
        self._gcc_dir = gcc_dir

    def send(self, request: HITLRequest) -> None:
        import urllib.request
        options_text = "\n".join(f"  {i+1}. {opt}" for i, opt in enumerate(request.options))
        payload = {
            "blocks": [
                {
                    "type": "header",
                    "text": {"type": "plain_text", "text": f"[DevTorch HITL] Concept: {request.concept}"},
                },
                {
                    "type": "section",
                    "text": {"type": "mrkdwn", "text": f"*{request.prompt}*\n{options_text}"},
                },
                {
                    "type": "context",
                    "elements": [{"type": "mrkdwn",
                                  "text": f"Record ID: `{request.consolidation_record_id}` | Request: `{request.request_id}`"}],
                },
            ]
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self._webhook_url, data=data,
            headers={"Content-Type": "application/json"},
        )
        try:
            urllib.request.urlopen(req, timeout=5)
        except Exception:
            pass  # Non-blocking; Slack delivery failure does not block the workflow

    def poll(self, request_id: str) -> Optional[str]:
        response_file = self._gcc_dir / "hitl" / f"{request_id}.response.json"
        if not response_file.exists():
            return None
        try:
            d = json.loads(response_file.read_text(encoding="utf-8"))
            return d.get("response")
        except (json.JSONDecodeError, OSError):
            return None
