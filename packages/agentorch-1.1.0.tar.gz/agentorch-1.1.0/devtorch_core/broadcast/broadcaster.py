"""
Local SSE broadcaster for DevTorch coordination events.

Agents subscribe to GET /events/stream and receive coordination-relevant
events as they are appended to .GCC/events.log.jsonl.

Only broadcasts events whose event_type contains one of:
DIVERGENCE, CONSOLIDATION, HITL, CONSENSUS
"""
from __future__ import annotations

import asyncio
import json
import threading
from pathlib import Path
from typing import List, Optional, Set

COORDINATION_TYPES: Set[str] = {"DIVERGENCE", "CONSOLIDATION", "HITL", "CONSENSUS"}


def _is_coordination_event(event_type: str) -> bool:
    """Return True if any coordination keyword appears in the event_type string."""
    upper = event_type.upper()
    return any(kw in upper for kw in COORDINATION_TYPES)


class EventBroadcaster:
    """Thread-safe in-process event broadcaster backed by asyncio queues."""

    def __init__(self) -> None:
        self._queues: List[asyncio.Queue] = []
        self._lock = threading.Lock()

    def subscribe(self) -> asyncio.Queue:
        # asyncio.Queue.put_nowait() and get_nowait() are safe to call from threads
        # under CPython's GIL (deque operations are atomic). The async await q.get()
        # path in create_broadcast_app is only reached from within the FastAPI event loop.
        q: asyncio.Queue = asyncio.Queue()
        with self._lock:
            self._queues.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        with self._lock:
            try:
                self._queues.remove(q)
            except ValueError:
                pass

    def publish(self, event: dict) -> None:
        """Publish event to all subscriber queues (non-blocking)."""
        event_type = event.get("event_type", "")
        if not _is_coordination_event(event_type):
            return
        with self._lock:
            targets = list(self._queues)
        for q in targets:
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                pass


def create_broadcast_app(broadcaster: EventBroadcaster):
    """
    Build a FastAPI app exposing GET /events/stream (SSE).
    Returns None if FastAPI is not installed.
    """
    try:
        from fastapi import FastAPI
        from fastapi.responses import StreamingResponse
    except ImportError:
        return None

    app = FastAPI(title="DevTorch Event Broadcaster", version="0.1.0")

    @app.get("/events/stream")
    async def event_stream():
        q = broadcaster.subscribe()

        async def generate():
            try:
                # Send keepalive immediately
                yield "data: {\"type\": \"connected\"}\n\n"
                while True:
                    try:
                        event = await asyncio.wait_for(q.get(), timeout=30.0)
                        yield f"data: {json.dumps(event)}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            finally:
                broadcaster.unsubscribe(q)

        return StreamingResponse(generate(), media_type="text/event-stream")

    @app.get("/events/health")
    def health():
        return {"status": "ok", "subscribers": len(broadcaster._queues)}

    return app
