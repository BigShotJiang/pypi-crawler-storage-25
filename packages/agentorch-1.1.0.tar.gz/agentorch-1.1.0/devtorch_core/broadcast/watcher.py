"""
File watcher that monitors .GCC/events.log.jsonl for new lines
and publishes coordination events to an EventBroadcaster.

Uses watchdog if available; falls back to polling.
"""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path
from typing import Optional

from .broadcaster import EventBroadcaster


class GCCWatcher:
    """
    Watches .GCC/events.log.jsonl for new lines and publishes
    coordination-relevant events to the broadcaster.
    """

    def __init__(self, gcc_dir: Path, broadcaster: EventBroadcaster,
                 poll_interval: float = 0.5) -> None:
        self._log_path = gcc_dir / "events.log.jsonl"
        self._broadcaster = broadcaster
        self._poll_interval = poll_interval
        self._offset: int = 0
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def _read_new_lines(self) -> None:
        """Read any new lines appended since last check and publish them."""
        if not self._log_path.exists():
            return
        try:
            with self._log_path.open("r", encoding="utf-8") as f:
                f.seek(self._offset)
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        event = json.loads(line)
                        self._broadcaster.publish(event)
                    except json.JSONDecodeError:
                        pass
                self._offset = f.tell()
        except OSError:
            pass

    def _poll_loop(self) -> None:
        while not self._stop_event.is_set():
            self._read_new_lines()
            self._stop_event.wait(self._poll_interval)

    def start(self) -> None:
        """Start the watcher background thread."""
        if self._log_path.exists():
            self._offset = self._log_path.stat().st_size
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the watcher background thread."""
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None
