"""
Sprint 18 — Identity providers for resolving agent identity from env vars.

Each provider reads environment variables set by its runtime (native, Bedrock, Azure, etc.)
and returns an AgentIdentity. resolve_agent_identity() tries them in priority order,
falling back to AnonymousProvider if none match.
"""
from __future__ import annotations

import os
import uuid
from typing import Optional

from .agent import AgentIdentity


class NativeProvider:
    """Reads DEVTORCH_AGENT_ID / DEVTORCH_AGENT_NAME / DEVTORCH_AGENT_SCOPE env vars."""

    def resolve(self) -> Optional[AgentIdentity]:
        agent_id = os.environ.get("DEVTORCH_AGENT_ID", "").strip()
        if not agent_id:
            return None
        return AgentIdentity(
            agent_id=agent_id,
            name=os.environ.get("DEVTORCH_AGENT_NAME", agent_id),
            provider="native",
            scope=os.environ.get("DEVTORCH_AGENT_SCOPE", "branch"),
        )


class BedrockProvider:
    """Reads BEDROCK_AGENT_ID env var (set by AWS Bedrock AgentCore runtime)."""

    def resolve(self) -> Optional[AgentIdentity]:
        agent_id = os.environ.get("BEDROCK_AGENT_ID", "").strip()
        if not agent_id:
            return None
        return AgentIdentity(
            agent_id=agent_id,
            name=os.environ.get("BEDROCK_AGENT_ALIAS", agent_id),
            provider="bedrock",
            scope="session",
            metadata={"region": os.environ.get("AWS_DEFAULT_REGION", "")},
        )


class AzureProvider:
    """Reads AZURE_CLIENT_ID env var (set by Azure Managed Identity)."""

    def resolve(self) -> Optional[AgentIdentity]:
        agent_id = os.environ.get("AZURE_CLIENT_ID", "").strip()
        if not agent_id:
            return None
        return AgentIdentity(
            agent_id=agent_id,
            name=os.environ.get("AZURE_AGENT_NAME", agent_id),
            provider="azure",
            scope="session",
            metadata={"tenant_id": os.environ.get("AZURE_TENANT_ID", "")},
        )


class AnonymousProvider:
    """Fallback: generates a session-scoped random id."""

    def resolve(self) -> AgentIdentity:
        return AgentIdentity(
            agent_id=f"anon-{uuid.uuid4().hex[:8]}",
            name="anonymous",
            provider="anonymous",
            scope="session",
        )


_PROVIDERS = [NativeProvider, BedrockProvider, AzureProvider]


def resolve_agent_identity() -> AgentIdentity:
    """Try each provider in priority order; fall back to anonymous."""
    for cls in _PROVIDERS:
        identity = cls().resolve()
        if identity is not None:
            return identity
    return AnonymousProvider().resolve()
