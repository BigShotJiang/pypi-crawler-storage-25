"""
Sprint 18 (S18) — Agent Identity substrate.

AgentIdentity names a reasoning agent; AgentRegistry persists identities as an
append-only JSONL file under a configurable directory so any .GCC/ can maintain
a record of which agents have contributed to the project.
"""
from __future__ import annotations

import dataclasses
import json
from pathlib import Path
from typing import List, Optional


@dataclasses.dataclass
class AgentIdentity:
    """Named identity for a reasoning agent with scoped visibility."""

    agent_id: str
    name: str
    provider: str   # "native" | "bedrock" | "azure" | "anonymous"
    scope: str      # "branch" | "session" | "org"
    metadata: dict = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "AgentIdentity":
        return cls(
            agent_id=d["agent_id"],
            name=d["name"],
            provider=d["provider"],
            scope=d["scope"],
            metadata=d.get("metadata", {}),
        )


_REGISTRY_FILE = "agent_registry.jsonl"


class AgentRegistry:
    """Append-only JSONL registry of known agent identities."""

    def __init__(self, registry_dir: Path) -> None:
        self._dir = registry_dir
        self._dir.mkdir(parents=True, exist_ok=True)
        self._path = self._dir / _REGISTRY_FILE

    def register(self, identity: AgentIdentity) -> None:
        existing = self.get(identity.agent_id)
        if existing is not None:
            return  # idempotent
        with self._path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(identity.to_dict()) + "\n")

    def get(self, agent_id: str) -> Optional[AgentIdentity]:
        if not self._path.exists():
            return None
        for line in self._path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                if d.get("agent_id") == agent_id:
                    return AgentIdentity.from_dict(d)
            except json.JSONDecodeError:
                continue
        return None

    def list_all(self) -> List[AgentIdentity]:
        if not self._path.exists():
            return []
        seen: dict[str, AgentIdentity] = {}
        for line in self._path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                seen[d["agent_id"]] = AgentIdentity.from_dict(d)
            except (json.JSONDecodeError, KeyError):
                continue
        return list(seen.values())
