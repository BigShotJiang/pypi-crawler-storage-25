from __future__ import annotations

import dataclasses
from typing import Optional


@dataclasses.dataclass
class ReasoningEntry:
    """
    A single cross-agent-queryable reasoning record.

    Combines a SensitivityEvent (the why) with its associated commit message
    (the decision), token-budgeted and structured for Agent B to consume.
    """

    entry_id: str
    agent_id: str
    concept: str
    reasoning_text: str   # counterfactuals / why text from SensitivityEvent
    decision_text: str    # commit message from nearest preceding commit
    confidence: float
    disclosure_level: str
    session_id: Optional[str]
    branch: str
    timestamp: str
    source_type: str  # "sensitivity" | "commit"

    def approx_tokens(self) -> int:
        """Rough token estimate: 4 chars ≈ 1 token."""
        text = self.reasoning_text + " " + self.decision_text
        return max(1, len(text) // 4)
