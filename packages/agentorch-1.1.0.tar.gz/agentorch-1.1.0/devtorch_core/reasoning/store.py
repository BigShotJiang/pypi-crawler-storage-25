from __future__ import annotations

import json
from pathlib import Path
from typing import List, Optional

from .entry import ReasoningEntry

_SENSITIVITIES_FILE = "sensitivities/events.jsonl"
_COMMITS_DIR = "commits"


class ReasoningStore:
    """
    Query Agent reasoning from the .GCC/ event store.

    Combines SensitivityEvents (the why) with the nearest commit on the same
    branch (the decision), filtered by agent_id and concept, token-budgeted.
    """

    def __init__(self, repo) -> None:
        self._repo = repo
        self._gcc_dir = repo.gcc_dir

    def query(
        self,
        concept: str,
        agent_id: Optional[str] = None,
        scope: str = "branch",
        k_tokens: int = 4000,
    ) -> List[ReasoningEntry]:
        """
        Return reasoning entries for the given concept, optionally filtered by agent_id.

        Falls back to source_node as agent_id for events without an explicit agent_id
        (backward compatibility with pre-S18 events).
        """
        events = self._load_sensitivity_events(concept)
        commits = self._load_commits_index()

        entries: List[ReasoningEntry] = []
        for ev in events:
            effective_agent = ev.get("agent_id") or ev.get("source_node", "unknown")
            if agent_id is not None and effective_agent != agent_id:
                continue

            decision_text = self._nearest_commit_message(
                ev.get("created_at", ""), ev.get("branch", "main"), commits
            )

            entry = ReasoningEntry(
                entry_id=ev.get("event_id", ""),
                agent_id=effective_agent,
                concept=concept,
                reasoning_text=ev.get("counterfactuals", "") or ev.get("message", ""),
                decision_text=decision_text,
                confidence=float(ev.get("confidence", 0.0)),
                disclosure_level=ev.get("disclosure_level", "PROTECTED"),
                session_id=ev.get("session_id"),
                branch=ev.get("branch", "main"),
                timestamp=ev.get("created_at", ""),
                source_type="sensitivity",
            )
            entries.append(entry)

        # Sort by timestamp descending (most recent first), then apply token budget
        entries.sort(key=lambda e: e.timestamp, reverse=True)
        return self._apply_token_budget(entries, k_tokens)

    def _load_sensitivity_events(self, concept: str) -> List[dict]:
        path = self._gcc_dir / _SENSITIVITIES_FILE
        if not path.exists():
            return []
        results = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
                if d.get("target_concept") == concept:
                    results.append(d)
            except json.JSONDecodeError:
                continue
        return results

    def _load_commits_index(self) -> List[dict]:
        commits_dir = self._gcc_dir / _COMMITS_DIR
        if not commits_dir.exists():
            return []
        commits = []
        for f in sorted(commits_dir.glob("*.json")):
            try:
                commits.append(json.loads(f.read_text(encoding="utf-8")))
            except (json.JSONDecodeError, OSError):
                continue
        return sorted(commits, key=lambda c: c.get("timestamp", ""))

    def _nearest_commit_message(
        self, event_ts: str, branch: str, commits: List[dict]
    ) -> str:
        """Find the commit message from the latest commit at or before event_ts on branch."""
        branch_commits = [c for c in commits if c.get("branch") == branch]
        before = [c for c in branch_commits if c.get("timestamp", "") <= event_ts]
        if before:
            return before[-1].get("message", "")
        # Fall back to nearest commit regardless of branch
        if commits:
            return commits[-1].get("message", "")
        return ""

    @staticmethod
    def _apply_token_budget(entries: List[ReasoningEntry], k_tokens: int) -> List[ReasoningEntry]:
        result = []
        used = 0
        for e in entries:
            t = e.approx_tokens()
            if used + t > k_tokens:
                break
            result.append(e)
            used += t
        return result
