"""
Thread (session) management for neoCoder CLI.

Provides:
- Multiple concurrent agent sessions
- Switch between threads
- Thread visibility control
- Persistent state (optional)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional
import uuid


@dataclass
class ThreadState:
    """Single thread/session state."""
    id: str
    title: str
    agent: Any  # NeoCoderAgent
    mode: str = "coding"
    visible: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    last_active: datetime = field(default_factory=datetime.now)
    message_count: int = 0


class ThreadManager:
    """Manages multiple agent sessions (threads)."""
    
    def __init__(self):
        self._threads: Dict[str, ThreadState] = {}
        self._current_id: Optional[str] = None
    
    @property
    def current_id(self) -> Optional[str]:
        return self._current_id
    
    @property
    def current(self) -> Optional[ThreadState]:
        if self._current_id:
            return self._threads.get(self._current_id)
        return None
    
    def create(
        self,
        agent: Any,
        title: str = "New Thread",
        mode: str = "coding",
        switch_to: bool = True,
    ) -> ThreadState:
        """Create a new thread with the given agent."""
        thread_id = f"T-{uuid.uuid4().hex[:8]}"
        thread = ThreadState(
            id=thread_id,
            title=title,
            agent=agent,
            mode=mode,
        )
        self._threads[thread_id] = thread
        
        if switch_to or self._current_id is None:
            self._current_id = thread_id
        
        return thread
    
    def switch(self, thread_id: str) -> bool:
        """Switch to a different thread."""
        if thread_id not in self._threads:
            return False
        self._current_id = thread_id
        self._threads[thread_id].last_active = datetime.now()
        return True
    
    def get(self, thread_id: str) -> Optional[ThreadState]:
        return self._threads.get(thread_id)
    
    def list_all(self) -> list[ThreadState]:
        """List all threads, sorted by last active."""
        return sorted(
            self._threads.values(),
            key=lambda t: t.last_active,
            reverse=True,
        )
    
    def list_visible(self) -> list[ThreadState]:
        """List only visible threads."""
        return [t for t in self.list_all() if t.visible]
    
    def toggle_visibility(self, thread_id: Optional[str] = None) -> bool:
        """Toggle visibility of a thread."""
        tid = thread_id or self._current_id
        if tid and tid in self._threads:
            self._threads[tid].visible = not self._threads[tid].visible
            return True
        return False
    
    def delete(self, thread_id: str) -> bool:
        """Delete a thread."""
        if thread_id not in self._threads:
            return False
        
        del self._threads[thread_id]
        
        if self._current_id == thread_id:
            remaining = self.list_all()
            self._current_id = remaining[0].id if remaining else None
        
        return True
    
    def update_activity(self, thread_id: Optional[str] = None):
        """Update last_active timestamp and message count."""
        tid = thread_id or self._current_id
        if tid and tid in self._threads:
            self._threads[tid].last_active = datetime.now()
            self._threads[tid].message_count += 1
    
    def rename(self, thread_id: str, new_title: str) -> bool:
        """Rename a thread."""
        if thread_id in self._threads:
            self._threads[thread_id].title = new_title
            return True
        return False
    
    def count(self) -> int:
        return len(self._threads)
