"""
Command Palette for neoCoder CLI.

Provides:
- Fuzzy command search
- Mode switching (coding/debug/refactor)
- Thread management UI
- Settings access
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.table import Table


@dataclass
class Command:
    """Single command definition."""
    id: str                 # "mode.switch", "thread.switch"
    title: str              # "Switch mode"
    category: str           # "mode", "thread", "prompt"
    description: str
    keywords: List[str] = field(default_factory=list)
    handler: Callable[["CommandContext", Dict[str, Any]], None] = None
    hotkey: Optional[str] = None  # "Ctrl+S"


@dataclass
class CommandContext:
    """Context passed to command handlers."""
    console: Console
    config: dict
    agent: Any              # NeoCoderAgent
    threads: Any            # ThreadManager
    settings: Any           # Settings object
    create_agent_fn: Callable  # Function to create new agent


class CommandPalette:
    """Command palette with fuzzy search."""
    
    def __init__(self, console: Console):
        self.console = console
        self._commands: Dict[str, Command] = {}
    
    def register(self, cmd: Command):
        self._commands[cmd.id] = cmd
    
    def register_all(self, commands: List[Command]):
        for cmd in commands:
            self.register(cmd)
    
    def get(self, cmd_id: str) -> Optional[Command]:
        return self._commands.get(cmd_id)
    
    def list_commands(self) -> List[Command]:
        return list(self._commands.values())
    
    def search(self, query: str, limit: int = 10) -> List[Command]:
        """Fuzzy search commands."""
        query = query.lower().strip()
        if not query:
            return list(self._commands.values())[:limit]
        
        scored: List[tuple[float, Command]] = []
        for cmd in self._commands.values():
            text = " ".join([cmd.id, cmd.title, cmd.description] + cmd.keywords).lower()
            score = self._score(query, text)
            if score > 0:
                scored.append((score, cmd))
        
        scored.sort(key=lambda x: x[0], reverse=True)
        return [cmd for _, cmd in scored[:limit]]
    
    def _score(self, query: str, text: str) -> float:
        """Simple scoring: exact match > subsequence."""
        if query in text:
            return 100 + len(query)
        # subsequence match
        it = iter(text)
        match_len = sum(1 for ch in query if ch in it)
        if match_len == len(query):
            return 50 + match_len
        return 0.0
    
    def show(self, ctx: CommandContext) -> Optional[str]:
        """Show palette and execute selected command."""
        query = ctx.console.input("[bold cyan]Command › [/bold cyan]").strip()
        matches = self.search(query)
        
        if not matches:
            ctx.console.print("[red]No matching commands.[/red]")
            return None
        
        # Show matches
        table = Table(title=f"Commands ({len(matches)})", show_header=True)
        table.add_column("#", justify="right", style="dim")
        table.add_column("Command", style="cyan")
        table.add_column("Description")
        table.add_column("Hotkey", style="dim")
        
        for i, cmd in enumerate(matches, start=1):
            table.add_row(str(i), cmd.title, cmd.description, cmd.hotkey or "")
        
        self.console.print(Panel(table, border_style="cyan"))
        
        # Select
        choice = ctx.console.input("[bold]Select # (Enter to cancel): [/bold]").strip()
        if not choice:
            return None
        
        try:
            idx = int(choice) - 1
            if not (0 <= idx < len(matches)):
                raise ValueError()
        except ValueError:
            ctx.console.print("[red]Invalid selection.[/red]")
            return None
        
        cmd = matches[idx]
        if cmd.handler:
            cmd.handler(ctx, {})
        return cmd.id


# =====================================================================
# Built-in command handlers
# =====================================================================

def handle_mode_switch(ctx: CommandContext, params: dict):
    """Switch agent mode (coding/debug/refactor/review)."""
    modes = ["coding", "debug", "refactor", "review"]
    current = ctx.config.get("mode", "coding")
    
    ctx.console.print(f"[dim]Current mode: {current}[/dim]")
    ctx.console.print(f"Available: [bold]{', '.join(modes)}[/bold]")
    
    new_mode = ctx.console.input("New mode: ").strip().lower()
    if new_mode not in modes:
        ctx.console.print("[red]Invalid mode.[/red]")
        return
    
    if new_mode == current:
        ctx.console.print("[yellow]Already in this mode.[/yellow]")
        return
    
    ctx.config["mode"] = new_mode
    
    # Recreate agent with new mode
    new_agent = ctx.create_agent_fn(
        model=ctx.config.get("model"),
        working_dir=ctx.config["working_dir"],
        mode=new_mode,
        preset=ctx.config.get("preset"),
        base_url=ctx.config.get("base_url"),
        api_key=ctx.config.get("api_key"),
        require_confirmation=ctx.config.get("confirm", False),
    )
    
    # Update thread
    if ctx.threads.current:
        ctx.threads.current.agent = new_agent
        ctx.threads.current.mode = new_mode
    ctx.agent = new_agent
    
    ctx.console.print(f"[green]✓ Mode switched to {new_mode}[/green]")


def handle_mode_toggle(ctx: CommandContext, params: dict):
    """Toggle between coding and debug modes."""
    current = ctx.config.get("mode", "coding")
    new_mode = "debug" if current == "coding" else "coding"
    
    ctx.config["mode"] = new_mode
    
    new_agent = ctx.create_agent_fn(
        model=ctx.config.get("model"),
        working_dir=ctx.config["working_dir"],
        mode=new_mode,
        preset=ctx.config.get("preset"),
        base_url=ctx.config.get("base_url"),
        api_key=ctx.config.get("api_key"),
        require_confirmation=ctx.config.get("confirm", False),
    )
    
    if ctx.threads.current:
        ctx.threads.current.agent = new_agent
        ctx.threads.current.mode = new_mode
    ctx.agent = new_agent
    
    ctx.console.print(f"[green]✓ Mode toggled: {current} → {new_mode}[/green]")


def handle_thread_switch(ctx: CommandContext, params: dict):
    """Switch to another thread or create new."""
    threads = ctx.threads.list_all()
    
    if not threads:
        ctx.console.print("[yellow]No threads. Creating new...[/yellow]")
        handle_thread_new(ctx, params)
        return
    
    table = Table(title="Threads", show_header=True)
    table.add_column("#", justify="right", style="dim")
    table.add_column("ID", style="cyan")
    table.add_column("Title")
    table.add_column("Mode")
    table.add_column("Messages", justify="right")
    table.add_column("", style="dim")
    
    current_id = ctx.threads.current_id
    for i, t in enumerate(threads, start=1):
        marker = "◀" if t.id == current_id else ""
        vis = "" if t.visible else "(hidden)"
        table.add_row(str(i), t.id, t.title, t.mode, str(t.message_count), f"{marker} {vis}")
    
    ctx.console.print(table)
    ctx.console.print("[dim]Enter # to switch, 'n' for new, Enter to cancel[/dim]")
    
    choice = ctx.console.input("Select: ").strip().lower()
    if not choice:
        return
    
    if choice == "n":
        handle_thread_new(ctx, params)
        return
    
    try:
        idx = int(choice) - 1
        if not (0 <= idx < len(threads)):
            raise ValueError()
    except ValueError:
        ctx.console.print("[red]Invalid selection.[/red]")
        return
    
    thread = threads[idx]
    ctx.threads.switch(thread.id)
    ctx.agent = thread.agent
    ctx.config["mode"] = thread.mode
    ctx.console.print(f"[green]✓ Switched to: {thread.title} ({thread.mode})[/green]")


def handle_thread_new(ctx: CommandContext, params: dict):
    """Create a new thread."""
    title = ctx.console.input("Thread title (Enter for default): ").strip()
    if not title:
        title = f"Thread #{ctx.threads.count() + 1}"
    
    mode = ctx.config.get("mode", "coding")
    new_agent = ctx.create_agent_fn(
        model=ctx.config.get("model"),
        working_dir=ctx.config["working_dir"],
        mode=mode,
        preset=ctx.config.get("preset"),
        base_url=ctx.config.get("base_url"),
        api_key=ctx.config.get("api_key"),
        require_confirmation=ctx.config.get("confirm", False),
    )
    
    thread = ctx.threads.create(new_agent, title=title, mode=mode, switch_to=True)
    ctx.agent = new_agent
    ctx.console.print(f"[green]✓ Created: {thread.title} ({thread.id})[/green]")


def handle_thread_visibility(ctx: CommandContext, params: dict):
    """Toggle current thread visibility."""
    if ctx.threads.toggle_visibility():
        vis = "visible" if ctx.threads.current.visible else "hidden"
        ctx.console.print(f"[green]✓ Thread is now {vis}[/green]")
    else:
        ctx.console.print("[red]No active thread.[/red]")


def handle_help(ctx: CommandContext, params: dict):
    """Show command palette help."""
    commands = ctx.console._palette.list_commands() if hasattr(ctx.console, '_palette') else []
    
    ctx.console.print("\n[bold cyan]Command Palette[/bold cyan]\n")
    ctx.console.print("[bold]Shortcuts:[/bold]")
    ctx.console.print("  ::      Open command palette")
    ctx.console.print("  ::m     Mode switch")
    ctx.console.print("  ::t     Thread switch")
    ctx.console.print("  ::s     Toggle mode (coding ↔ debug)")
    ctx.console.print()


# =====================================================================
# Command registry
# =====================================================================

def build_default_commands() -> List[Command]:
    """Build the default command set."""
    return [
        Command(
            id="mode.switch",
            title="Switch mode",
            category="mode",
            description="Switch between coding/debug/refactor/review",
            keywords=["mode", "coding", "debug", "refactor"],
            handler=handle_mode_switch,
        ),
        Command(
            id="mode.toggle",
            title="Toggle mode",
            category="mode",
            description="Toggle between coding and debug",
            keywords=["toggle", "mode", "switch"],
            handler=handle_mode_toggle,
            hotkey="Ctrl+S",
        ),
        Command(
            id="thread.switch",
            title="Switch thread",
            category="thread",
            description="Switch to another session",
            keywords=["thread", "session", "switch"],
            handler=handle_thread_switch,
        ),
        Command(
            id="thread.new",
            title="New thread",
            category="thread",
            description="Create a new session",
            keywords=["thread", "new", "create", "session"],
            handler=handle_thread_new,
        ),
        Command(
            id="thread.visibility",
            title="Toggle visibility",
            category="thread",
            description="Hide/show current thread",
            keywords=["visibility", "hide", "show", "thread"],
            handler=handle_thread_visibility,
        ),
        Command(
            id="help",
            title="Help",
            category="help",
            description="Show command palette help",
            keywords=["help", "?", "commands"],
            handler=handle_help,
        ),
    ]
