"""Command-line interface for neoCoder."""
