"""
Command-line interface for the neoCoder Agent.

Provides:
- Interactive chat mode
- Single task execution mode
- Configuration options
"""

from __future__ import annotations

import asyncio
import logging
import os
import sys

# Enable debug logging if NEOCODER_DEBUG is set
if os.getenv("NEOCODER_DEBUG"):
    logging.basicConfig(level=logging.DEBUG, format="%(name)s: %(message)s")

import click
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.live import Live
from rich.text import Text

from neoCoder.nca.agent import NeoCoderAgent
from neoCoder.nca.config import NCAConfig, PRESETS


console = Console()


def _run_async(coro):
    """Run an async coroutine safely from sync context.

    Uses an existing event loop if available, otherwise creates a new one.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # Use run_coroutine_threadsafe for proper event loop integration
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result()
    else:
        return asyncio.run(coro)


def _show_token_usage(result, config: dict, settings=None):
    """Show token usage after task completion.

    Args:
        result: OrchestratorResult with token counts.
        config: CLI config dict with 'model' key.
        settings: Pre-loaded Settings (loaded if None).
    """
    try:
        if settings is None:
            from neoCoder.config import load_settings
            settings = load_settings()

        if not (settings.agent_config.monitoring.enabled
                and settings.agent_config.monitoring.show_usage_updates):
            return

        from neoCoder.sdk.monitoring.models import TokenUsage, UsagePercentages
        from neoCoder.sdk.monitoring import ModelInfoFetcher, ModelInfoDisplay

        fetcher = ModelInfoFetcher(
            api_key=settings.agent_config.zenmux.api_key,
            cache_ttl=settings.agent_config.monitoring.cache_ttl,
            api_timeout=settings.agent_config.monitoring.api_timeout,
            base_url=settings.agent_config.zenmux.base_url,
        )

        model_name = config.get("model") or settings.agent_config.default_model
        model_info = _run_async(fetcher.get_model_info(model_name))

        # Use real per-category token data when available, otherwise estimate
        has_detailed = getattr(result, "input_tokens", 0) > 0 or getattr(result, "output_tokens", 0) > 0
        if has_detailed:
            context_tokens = result.input_tokens
            output_tokens = result.output_tokens
            reasoning_tokens = getattr(result, "reasoning_tokens", 0) or 0
        else:
            context_tokens = int(result.total_tokens * 0.7)
            output_tokens = result.total_tokens - context_tokens
            reasoning_tokens = 0

        usage = TokenUsage(
            context_tokens=context_tokens,
            output_tokens=output_tokens,
            total_tokens=result.total_tokens,
            reasoning_tokens=reasoning_tokens,
        )

        context_pct = (context_tokens / model_info.max_context_tokens * 100) if model_info.max_context_tokens > 0 else 0
        output_pct = (output_tokens / model_info.max_output_tokens * 100) if model_info.max_output_tokens > 0 else 0
        reasoning_pct = None
        if reasoning_tokens > 0 and model_info.reasoning_tokens:
            reasoning_pct = (reasoning_tokens / model_info.reasoning_tokens * 100)

        percentages = UsagePercentages(
            context_percent=context_pct,
            output_percent=output_pct,
            reasoning_percent=reasoning_pct,
        )

        display_format = getattr(settings.agent_config.monitoring, "display_format", "box")
        display = ModelInfoDisplay(display_format=display_format)
        usage_display = display.format_token_usage(usage, percentages, model_info)
        console.print()
        console.print(usage_display)
    except Exception as e:
        logging.debug(f"Failed to show token usage: {e}")


def print_banner(model_name: str = None, show_monitoring: bool = True):
    """Print the neoCoder banner with optional model information."""
    # Get model info if monitoring is enabled
    model_info_lines = []
    if show_monitoring and model_name:
        try:
            from neoCoder.config import load_settings
            from neoCoder.sdk.monitoring import ModelInfoFetcher
            
            settings = load_settings()
            if settings.agent_config.monitoring.enabled and settings.agent_config.monitoring.show_startup_info:
                # Use Zenmux API if available, otherwise use fallback values
                api_key = settings.agent_config.zenmux.api_key or "fallback"
                fetcher = ModelInfoFetcher(
                    api_key=api_key,
                    cache_ttl=settings.agent_config.monitoring.cache_ttl,
                    api_timeout=settings.agent_config.monitoring.api_timeout,
                    base_url=settings.agent_config.zenmux.base_url,
                )
                
                model_info = _run_async(fetcher.get_model_info(model_name))
                
                # Format model info for banner (78 chars total width)
                # Build context/output line with dynamic padding
                context_output_base = f"║  Context: {model_info.max_context_tokens:>7,} | Output: {model_info.max_output_tokens:>7,} tokens"
                context_output_padding = 75 - len(context_output_base) - 1
                context_output_line = context_output_base + " " * context_output_padding + "║"
                
                model_info_lines = [
                    f"║  Model: {model_info.name:<64}║",
                    context_output_line,
                ]
                
                if model_info.reasoning_tokens:
                    # Use "Thinking" for Anthropic, "Reasoning" for OpenAI
                    label = "Thinking" if model_info.provider == "anthropic" else "Reasoning"
                    effort_label = model_info.reasoning_effort or 'N/A'
                    # Build thinking line with dynamic padding
                    thinking_base = f"║  {label}: {model_info.reasoning_tokens:>7,} | Effort: {effort_label}"
                    thinking_padding = 75 - len(thinking_base) - 1
                    thinking_line = thinking_base + " " * thinking_padding + "║"
                    model_info_lines.append(thinking_line)
        except Exception as e:
            logging.warning(f"Failed to show monitoring info: {e}")
    
    # ASCII Art Banner (flat style)
    # Split into NEO (green matrix style) and CODER (cyan)
    border_top = "╔═════════════════════════════════════════════════════════════════════════╗"
    border_bottom = "╚═════════════════════════════════════════════════════════════════════════╝"
    empty_line = "║                                                                         ║"
    
    # NEO part (green matrix style)
    neo_lines = [
        "║  ███╗   ██╗███████╗ ██████╗ ",
        "║  ████╗  ██║██╔════╝██╔═══██╗",
        "║  ██╔██╗ ██║█████╗  ██║   ██║",
        "║  ██║╚██╗██║██╔══╝  ██║   ██║",
        "║  ██║ ╚████║███████╗╚██████╔╝",
        "║  ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ",
    ]
    
    # CODER part (cyan)
    coder_lines = [
        " ██████╗ ██████╗ ██████╗ ███████╗██████╗    ║",
        "██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔══██╗   ║",
        "██║     ██║   ██║██║  ██║█████╗  ██████╔╝   ║",
        "██║     ██║   ██║██║  ██║██╔══╝  ██╔══██╗   ║",
        "╚██████╗╚██████╔╝██████╔╝███████╗██║  ██║   ║",
        " ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝   ║",
    ]
    
    subtitle = "║      AI-Native Engineering Agent for Enterprise-Scale Codebase          ║"
    
    # Print banner with colors
    console.print(f"\n{border_top}", style="bold cyan")
    console.print(empty_line, style="bold cyan")
    
    # Print each line with NEO in green and CODER in cyan
    for neo, coder in zip(neo_lines, coder_lines):
        console.print(neo, style="bold green", end="")
        console.print(coder, style="bold cyan")
    
    console.print(empty_line, style="bold cyan")
    console.print(subtitle, style="bold cyan")
    console.print(empty_line, style="bold cyan")
    
    # Add model info if available
    if model_info_lines:
        for line in model_info_lines:
            console.print(line, style="bold cyan")
        console.print(empty_line, style="bold cyan")
    
    console.print(f"{border_bottom}\n", style="bold cyan")


def create_agent(
    model: str | None,
    working_dir: str,
    mode: str,
    preset: str | None,
    base_url: str | None = None,
    api_key: str | None = None,
    require_confirmation: bool = False,
) -> NeoCoderAgent:
    """Create and configure the agent."""
    # Load settings first - always needed for api_key, base_url, reasoning params
    from neoCoder.config import load_settings
    try:
        settings = load_settings()
        logging.debug(f"create_agent: settings loaded from {settings.config_path}")
        logging.debug(f"create_agent: zenmux.api_key={'set' if settings.agent_config.zenmux.api_key else 'None'}")
        logging.debug(f"create_agent: zenmux.base_url={settings.agent_config.zenmux.base_url}")
    except Exception as e:
        logging.warning(f"create_agent: failed to load settings: {e}")
        settings = None

    if preset and preset in PRESETS:
        # Start with preset config, then merge settings for API credentials
        preset_config = PRESETS[preset]
        overrides = {"mode": mode}
        # Carry over preset-specific params
        if preset_config.max_tokens != NCAConfig.max_tokens:
            overrides["max_tokens"] = preset_config.max_tokens
        if preset_config.max_iterations != NCAConfig.max_iterations:
            overrides["max_iterations"] = preset_config.max_iterations
        if preset_config.temperature != NCAConfig.temperature:
            overrides["temperature"] = preset_config.temperature
        if preset_config.rolling_window_size != NCAConfig.rolling_window_size:
            overrides["rolling_window_size"] = preset_config.rolling_window_size
        if preset_config.compression_threshold != NCAConfig.compression_threshold:
            overrides["compression_threshold"] = preset_config.compression_threshold
        if model:
            overrides["model"] = model

        if settings:
            config = NCAConfig.from_settings(settings, **overrides)
        else:
            config = preset_config
            if model:
                config.model = model
            config.mode = mode
        config.working_dir = working_dir
    else:
        # Load from settings.json with all overrides at once
        # This ensures api_key, base_url, reasoning params are computed correctly
        if settings:
            overrides = {"mode": mode}
            if model:
                overrides["model"] = model
            config = NCAConfig.from_settings(settings, **overrides)
            config.working_dir = working_dir
        else:
            # Fallback to default if settings can't be loaded
            config = NCAConfig()
            if model:
                config.model = model
            config.working_dir = working_dir
            config.mode = mode
    
    # Apply API configuration from explicit parameters (override settings)
    if base_url:
        config.base_url = base_url
    elif os.getenv("NEOCODER_BASE_URL"):
        config.base_url = os.getenv("NEOCODER_BASE_URL")
    
    if api_key:
        config.api_key = api_key
    elif not config.api_key:
        # Only use env vars if not already set from settings
        if os.getenv("ANTHROPIC_API_KEY"):
            config.api_key = os.getenv("ANTHROPIC_API_KEY")
        elif os.getenv("ANTHROPIC_AUTH_TOKEN"):
            config.api_key = os.getenv("ANTHROPIC_AUTH_TOKEN")
    
    # Auto-enable ZenMux format if using ZenMux URL
    if config.base_url and "zenmux" in config.base_url.lower():
        config.use_zenmux_format = True
    
    # Enable file confirmation if requested
    if require_confirmation:
        config.require_file_confirmation = True

    return NeoCoderAgent(config=config)


@click.group(invoke_without_command=True)
@click.option(
    "--model", "-m",
    default=None,
    help="Model to use (default: claude-sonnet-4-5-20241022)",
)
@click.option(
    "--working-dir", "-d",
    default=".",
    help="Working directory (default: current directory)",
)
@click.option(
    "--mode",
    type=click.Choice(["coding", "debug", "refactor"]),
    default="coding",
    help="Agent mode (default: coding)",
)
@click.option(
    "--preset", "-p",
    type=click.Choice(["default", "fast", "thorough", "zenmux", "workflow"]),
    default=None,
    help="Use a preset configuration",
)
@click.option(
    "--base-url",
    default=None,
    help="Custom API base URL (e.g., https://api.zenmux.ai/v1)",
)
@click.option(
    "--api-key",
    default=None,
    help="API key (defaults to ANTHROPIC_API_KEY env var)",
)
@click.option(
    "--confirm/--no-confirm", "-c",
    default=False,
    help="Require confirmation before file changes",
)
@click.argument("task", required=False)
@click.pass_context
def cli(ctx, model, working_dir, mode, preset, base_url, api_key, confirm, task):
    """
    neoCoder Agent - AI-powered coding assistant.

    Run with a TASK argument for single execution, or without for interactive mode.

    Examples:

        neocoder "Create a Python hello world script"

        neocoder --mode debug "Fix the failing test in test_api.py"

        neocoder  # Interactive mode
    """
    ctx.ensure_object(dict)
    ctx.obj["model"] = model
    ctx.obj["working_dir"] = os.path.abspath(working_dir)
    ctx.obj["mode"] = mode
    ctx.obj["preset"] = preset
    ctx.obj["base_url"] = base_url
    ctx.obj["api_key"] = api_key
    ctx.obj["confirm"] = confirm

    # If invoked without subcommand, run main logic
    if ctx.invoked_subcommand is None:
        # Known system commands (can be used with or without \ prefix)
        SYSTEM_COMMANDS = {"init-config", "help", "version", "coding", "debug", "refactor", "review"}
        
        # Check for system commands
        if task:
            # Normalize: remove leading \ if present
            is_explicit_cmd = task.startswith("\\")
            command = task[1:].lower() if is_explicit_cmd else task.lower()
            
            # Only treat as system command if explicit (\cmd) or exact match
            is_system_command = is_explicit_cmd or command in SYSTEM_COMMANDS
            
            if is_system_command and command == "init-config":
                # Create configuration
                from pathlib import Path
                from neoCoder.config.init_config import ConfigInitializer
                
                console.print("\n[bold cyan]Configuration Initialization[/bold cyan]\n")
                target_dir = Path.home() / ".neoCoder"
                console.print(f"Creating configuration in: {target_dir}\n")
                
                try:
                    created_dir = ConfigInitializer.create_example_config(target_dir)
                    console.print()
                    console.print("[bold green]✓ Configuration created successfully![/bold green]")
                    console.print()
                    console.print("[bold]Next steps:[/bold]")
                    console.print("1. Edit settings.json to add your API keys")
                    console.print("2. Or set environment variables:")
                    console.print("   set ANTHROPIC_API_KEY=your-key")
                    console.print("   set ZENMUX_API_KEY=your-key")
                    console.print()
                    console.print(f"Configuration location: {created_dir}")
                except Exception as e:
                    logging.error("Error creating configuration", exc_info=True)
                    console.print(f"[red]Error: {type(e).__name__}: {str(e)[:100]}[/red]")
                    sys.exit(1)
                return
            
            elif is_system_command and command == "help":
                # Show system commands help
                console.print("\n[bold cyan]System Commands[/bold cyan]\n")
                console.print("[bold]Configuration:[/bold]")
                console.print("  init-config       Create example configuration")
                console.print()
                console.print("[bold]Information:[/bold]")
                console.print("  help              Show this help")
                console.print("  version           Show version")
                console.print()
                console.print("[bold]Examples:[/bold]")
                console.print("  neocoder init-config")
                console.print()
                console.print("[dim]For regular tasks:[/dim]")
                console.print("[dim]  neocoder \"create a hello world script\"[/dim]")
                return
            
            elif is_system_command and command == "version":
                # Show version
                from neoCoder import __version__
                console.print(f"\nneoCoder Agent v{__version__}\n")
                return
            
            elif is_system_command and command in ("coding", "debug", "refactor", "review"):
                # Quick mode switch - launch interactive mode with specified mode
                ctx.obj["mode"] = command
                console.print(f"[green]Starting neoCoder in {command} mode...[/green]\n")
                # Continue to interactive session with this mode
                task = None  # Clear task so we go to interactive mode
            
            elif is_explicit_cmd:
                # Unknown explicit system command
                console.print(f"[red]Unknown system command: \\{command}[/red]")
                console.print("[dim]Use help to see available commands[/dim]")
                sys.exit(1)
        
        # Check if workflow preset is active
        if preset == "workflow":
            if task:
                # Workflow preset mode
                run_workflow_preset(ctx.obj, task)
            else:
                console.print("[red]Error: Workflow preset requires a task description[/red]")
                console.print("Usage: neocoder --preset workflow \"your task description\"")
                sys.exit(1)
        elif task:
            # Single task execution
            run_single_task(ctx.obj, task)
        else:
            # Interactive mode
            run_interactive(ctx.obj)


def run_single_task(config: dict, task: str):
    """Run a single task."""
    # Get model name for monitoring
    from neoCoder.config import load_settings
    try:
        settings = load_settings()
        model_name = config.get("model") or settings.agent_config.default_model
    except Exception:
        model_name = config.get("model") or "claude-3-5-sonnet-20241022"
    
    print_banner(model_name=model_name, show_monitoring=True)
    console.print()
    console.print(f"[bold]Working directory:[/bold] {config['working_dir']}")
    console.print(f"[bold]Mode:[/bold] {config['mode']}")
    console.print()

    agent = create_agent(
        model=config["model"],
        working_dir=config["working_dir"],
        mode=config["mode"],
        preset=config["preset"],
        base_url=config.get("base_url"),
        api_key=config.get("api_key"),
        require_confirmation=config.get("confirm", False),
    )

    # Set up output callbacks
    current_output = []

    def on_stream(chunk: str):
        console.print(chunk, end="")
        current_output.append(chunk)

    def on_output(text: str):
        # Only print if there's actual content
        if text and text.strip():
            console.print()
            console.print(Panel(text, title="🔧 Tool Result", border_style="cyan"))

    # Set up confirmation callback if enabled
    confirmation_callback = None
    if config.get("confirm"):
        from neoCoder.sdk.extensions.interactive_confirm import create_cli_confirmation
        confirmation_callback = create_cli_confirmation(console=console, enabled=True)

    agent.set_callbacks(
        on_output=on_output,
        on_stream=on_stream,
        confirmation_callback=confirmation_callback,
    )

    console.print(Panel(task, title="Task", border_style="green"))
    console.print()

    try:
        result = agent.run(task)

        console.print()
        if result.success:
            console.print(Panel(
                f"[green]✓ Completed[/green] in {result.iterations} iterations\n"
                f"Tokens used: {result.total_tokens}",
                title="Result",
                border_style="green",
            ))
        else:
            console.print(Panel(
                f"[red]✗ Failed[/red]: {result.error}\n"
                f"Iterations: {result.iterations}",
                title="Result",
                border_style="red",
            ))
        
        _show_token_usage(result, config)

    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        sys.exit(1)
    except Exception as e:
        logging.error("Error in single task execution", exc_info=True)
        console.print("\n[red]An error occurred. Check logs for details.[/red]")
        console.print(f"[dim]{type(e).__name__}: {str(e)[:100]}[/dim]")
        sys.exit(1)


def run_interactive(config: dict):
    """Run interactive mode."""
    from neoCoder.cli.threads import ThreadManager
    from neoCoder.cli.command_palette import (
        CommandPalette, CommandContext, build_default_commands,
        handle_mode_switch, handle_mode_toggle, handle_thread_switch,
    )
    
    # Get model name for monitoring
    from neoCoder.config import load_settings
    try:
        settings = load_settings()
        model_name = config.get("model") or settings.agent_config.default_model
    except Exception:
        settings = None
        model_name = config.get("model") or "claude-3-5-sonnet-20241022"
    
    print_banner(model_name=model_name, show_monitoring=True)
    console.print()
    console.print(f"[bold]Working directory:[/bold] {config['working_dir']}")
    console.print(f"[bold]Mode:[/bold] {config['mode']}")
    console.print()
    console.print("[dim]Type your task and press Enter. Type 'exit' or 'quit' to exit.[/dim]")
    console.print("[dim]Type 'reset' to start a new session. Type '::' for command palette.[/dim]")
    console.print()

    agent = create_agent(
        model=config["model"],
        working_dir=config["working_dir"],
        mode=config["mode"],
        preset=config["preset"],
        base_url=config.get("base_url"),
        api_key=config.get("api_key"),
        require_confirmation=config.get("confirm", False),
    )

    # Initialize thread manager and command palette
    threads = ThreadManager()
    threads.create(agent, title="Main", mode=config["mode"])
    
    palette = CommandPalette(console)
    palette.register_all(build_default_commands())
    
    # Command context (will be updated on mode/thread changes)
    ctx = CommandContext(
        console=console,
        config=config,
        agent=agent,
        threads=threads,
        settings=settings,
        create_agent_fn=create_agent,
    )

    def on_stream(chunk: str):
        console.print(chunk, end="")

    def on_output(text: str):
        if text and text.strip():
            console.print()
            console.print(Panel(text, title="Tool Output", border_style="blue"))

    # Set up confirmation callback if enabled
    confirmation_callback = None
    if config.get("confirm"):
        from neoCoder.sdk.extensions.interactive_confirm import create_cli_confirmation
        confirmation_callback = create_cli_confirmation(console=console, enabled=True)

    agent.set_callbacks(
        on_output=on_output,
        on_stream=on_stream,
        confirmation_callback=confirmation_callback,
    )

    while True:
        try:
            console.print()
            # Show current mode/thread in prompt
            mode_indicator = config.get("mode", "coding")[0].upper()
            thread_count = threads.count()
            prompt_prefix = f"[{mode_indicator}]" if thread_count <= 1 else f"[{mode_indicator}:{thread_count}]"
            task = console.input(f"[bold green]{prompt_prefix}>>> [/bold green]").strip()

            if not task:
                continue

            if task.lower() in ["exit", "quit", "q"]:
                console.print("[dim]Goodbye![/dim]")
                break

            if task.lower() == "reset":
                agent = ctx.agent
                agent.reset()
                console.print("[yellow]Session reset.[/yellow]")
                continue

            # Command palette triggers
            if task == "::":
                palette.show(ctx)
                agent = ctx.agent  # May have changed
                continue
            
            if task == "::m":
                handle_mode_switch(ctx, {})
                agent = ctx.agent
                continue
            
            if task == "::t":
                handle_thread_switch(ctx, {})
                agent = ctx.agent
                continue
            
            if task == "::s":
                handle_mode_toggle(ctx, {})
                agent = ctx.agent
                continue
            
            # Quick mode switch commands: \coding, \debug, \refactor, \review
            if task.startswith("\\"):
                mode_cmd = task[1:].lower()
                if mode_cmd in ("coding", "debug", "refactor", "review"):
                    current_mode = ctx.config.get("mode", "coding")
                    if mode_cmd == current_mode:
                        console.print(f"[yellow]Already in {mode_cmd} mode[/yellow]")
                    else:
                        ctx.config["mode"] = mode_cmd
                        new_agent = ctx.create_agent_fn(
                            model=ctx.config.get("model"),
                            working_dir=ctx.config["working_dir"],
                            mode=mode_cmd,
                            preset=ctx.config.get("preset"),
                            base_url=ctx.config.get("base_url"),
                            api_key=ctx.config.get("api_key"),
                            require_confirmation=ctx.config.get("confirm", False),
                        )
                        if ctx.threads.current:
                            ctx.threads.current.agent = new_agent
                            ctx.threads.current.mode = mode_cmd
                        ctx.agent = new_agent
                        agent = new_agent
                        console.print(f"[green]✓ Switched to {mode_cmd} mode[/green]")
                    continue

            if task.lower() == "help":
                console.print("""
[bold]Commands:[/bold]
  exit, quit, q  - Exit the agent
  reset          - Start a new session
  help           - Show this help

[bold]Quick Mode Switch:[/bold]
  \\coding        - Switch to coding mode
  \\debug         - Switch to debug mode
  \\refactor      - Switch to refactor mode
  \\review        - Switch to code review mode

[bold]Command Palette:[/bold]
  ::             - Open command palette
  ::m            - Switch mode (coding/debug/refactor/review)
  ::t            - Switch thread
  ::s            - Toggle mode (coding ↔ debug)

[bold]Tips:[/bold]
  - Be specific about what you want to accomplish
  - The agent can read, write, and search files
  - The agent can run shell commands
""")
                continue

            # Run the task
            console.print()
            agent.set_callbacks(
                on_output=on_output,
                on_stream=on_stream,
                confirmation_callback=confirmation_callback,
            )
            result = agent.run(task)
            threads.update_activity()

            console.print()
            if result.success:
                console.print(f"[dim]✓ Completed in {result.iterations} iterations[/dim]")
            else:
                console.print(f"[red]✗ {result.error}[/red]")
            
            _show_token_usage(result, config)

        except KeyboardInterrupt:
            console.print("\n[yellow]Interrupted. Type 'exit' to quit.[/yellow]")
        except EOFError:
            console.print("\n[dim]Goodbye![/dim]")
            break
        except Exception as e:
            logging.error("Error in interactive mode", exc_info=True)
            console.print(f"\n[red]Error: {type(e).__name__}[/red]")
            console.print(f"[dim]{str(e)[:100]}[/dim]")


def run_workflow_preset(config: dict, task: str):
    """Run agent with workflow preset."""
    from neoCoder.nca.workflow.manager import WorkflowManager
    from neoCoder.nca.workflow.stages import WorkflowConfig, StageLibrary
    from neoCoder.nca.workflow.display import (
        display_stage_header,
        display_stage_completion,
        display_workflow_summary,
    )
    from neoCoder.sdk.memory.notes import NotesStorage, NotesConfig
    
    # Get model name for monitoring
    from neoCoder.config import load_settings
    try:
        settings = load_settings()
        model_name = config.get("model") or settings.agent_config.default_model
    except Exception:
        model_name = config.get("model") or "claude-3-5-sonnet-20241022"
    
    print_banner(model_name=model_name, show_monitoring=True)
    console.print()
    console.print(f"[bold]Working directory:[/bold] {config['working_dir']}")
    console.print(f"[bold]Mode:[/bold] {config['mode']}")
    console.print(f"[bold]Preset:[/bold] workflow")
    console.print()
    
    # Initialize workflow manager
    workflow_config = WorkflowConfig(
        stages=StageLibrary.get_default_workflow(),
        enable_auto_transitions=True,
        require_user_approval=True,
        persist_state=True,
    )
    workflow_manager = WorkflowManager(workflow_config)
    
    # Check for existing workflow state
    if workflow_manager.load_state():
        console.print("[yellow]Resuming previous workflow...[/yellow]")
        console.print(f"[dim]Task: {workflow_manager.state.task_description}[/dim]")
        console.print(f"[dim]Current stage: {workflow_manager.get_current_stage().name}[/dim]")
        console.print()
        
        # Ask user if they want to continue or start fresh
        response = console.input("[bold]Continue from previous state? (y/n):[/bold] ").strip().lower()
        if response != 'y':
            workflow_manager.reset_workflow()
            console.print("[yellow]Starting fresh workflow...[/yellow]")
            console.print()
    
    # Start workflow if not already started
    if workflow_manager.state is None:
        workflow_manager.start_workflow(task)
    
    # Initialize notes storage for saving stage outputs
    notes_storage = NotesStorage(NotesConfig(storage_dir=".neoCoder/notes"))
    
    # Create agent with workflow preset
    agent = create_agent(
        model=config["model"],
        working_dir=config["working_dir"],
        mode=config["mode"],
        preset=config["preset"],
        base_url=config.get("base_url"),
        api_key=config.get("api_key"),
    )
    
    # Set up output callbacks
    def on_stream(chunk: str):
        console.print(chunk, end="")
    
    def on_output(text: str):
        # Only print if there's actual content
        if text and text.strip():
            console.print()
            console.print(Panel(text, title="🔧 Tool Result", border_style="cyan"))
    
    agent.set_callbacks(on_output=on_output, on_stream=on_stream)
    
    # Store original task for display
    original_task = task
    
    try:
        # Main workflow loop - continues until all stages complete
        while True:
            # Display current stage header
            current_stage = workflow_manager.get_current_stage()
            display_stage_header(current_stage, console)
            console.print()
            
            # Enhance task with stage-specific prompt
            stage_prompt = workflow_manager.get_stage_prompt()
            task_description = workflow_manager.state.task_description if workflow_manager.state else original_task
            
            # Build context from previous stages
            previous_context = ""
            if workflow_manager.state and workflow_manager.state.stage_outputs:
                previous_context = "\n\n---\n\n## Previous Stage Outputs\n"
                for stage_name, output in workflow_manager.state.stage_outputs.items():
                    # Truncate long outputs to avoid context overflow
                    truncated = output[:4000] + "..." if len(output) > 4000 else output
                    previous_context += f"\n### {stage_name}\n{truncated}\n"
            
            enhanced_task = f"{stage_prompt}\n\n---\n\nOriginal Task: {task_description}{previous_context}"
            
            # Show task panel only on first stage
            if current_stage.number == 1:
                console.print(Panel(original_task, title="Task", border_style="green"))
                console.print()
            
            # Run agent for this stage
            result = agent.run(enhanced_task)
            
            console.print()
            
            # Check for stage completion in the final output
            if workflow_manager.detect_stage_completion(result.output or ""):
                current_stage = workflow_manager.get_current_stage()
                display_stage_completion(current_stage, True, console=console)
                
                # Save stage output for context in next stages
                if workflow_manager.state and result.output:
                    workflow_manager.state.stage_outputs[current_stage.name] = result.output
                    workflow_manager.save_state()
                    
                    # Save important stages to persistent notes
                    if current_stage.name in ["Problem Breakdown", "Plan", "Code Review"]:
                        # Generate project name from task
                        import re
                        project_name = re.sub(r'[^\w\s-]', '', original_task[:50]).strip().replace(' ', '_').lower()
                        notes_storage.create_note(
                            title=f"{current_stage.name} - {original_task[:50]}",
                            content=result.output,
                            category="projects",
                            keywords=[current_stage.name.lower(), "workflow", project_name],
                            path=f"projects/{project_name}/{current_stage.name.lower().replace(' ', '_')}.md",
                        )
                        console.print(f"[dim]📝 Saved to notes: projects/{project_name}/{current_stage.name.lower().replace(' ', '_')}.md[/dim]")
                
                # Ask for user approval if required
                if current_stage.requires_user_approval:
                    console.print()
                    response = console.input(
                        f"[bold]Proceed to next stage? (y/n):[/bold] "
                    ).strip().lower()
                    
                    if response != 'y':
                        console.print("[yellow]Workflow paused. Run again to continue.[/yellow]")
                        workflow_manager.save_state()
                        return
                
                # Transition to next stage
                if workflow_manager.transition_to_next_stage():
                    console.print(f"[cyan]→ Moving to next stage: {workflow_manager.get_current_stage().name}[/cyan]")
                    console.print()
                    # Reset agent memory for new stage to avoid context overflow
                    agent.reset()
                    continue  # Continue to next stage
                else:
                    # Workflow complete - all stages done
                    console.print()
                    console.print("[bold green]🎉 Workflow Complete![/bold green]")
                    console.print()
                    display_workflow_summary(workflow_manager, console)
                    
                    # Clean up state file
                    workflow_manager.reset_workflow()
                    return
            
            # Stage not completed - display result and exit
            if result.success:
                console.print(Panel(
                    f"[green]✓ Stage iteration completed[/green] in {result.iterations} iterations\n"
                    f"Tokens used: {result.total_tokens}",
                    title="Result",
                    border_style="green",
                ))
            else:
                console.print(Panel(
                    f"[red]✗ Failed[/red]: {result.error}\n"
                    f"Iterations: {result.iterations}",
                    title="Result",
                    border_style="red",
                ))
            
            _show_token_usage(result, config)
            
            # Inform user about continuing workflow
            console.print()
            console.print("[dim]Stage not completed. Run the command again to continue.[/dim]")
            workflow_manager.save_state()
            return
    
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted by user[/yellow]")
        console.print("[dim]Workflow state saved. Run again to resume.[/dim]")
        workflow_manager.save_state()
        sys.exit(1)
    except Exception as e:
        logging.error("Error in workflow execution", exc_info=True)
        console.print("\n[red]An error occurred. Check logs for details.[/red]")
        console.print(f"[dim]{type(e).__name__}: {str(e)[:100]}[/dim]")
        workflow_manager.save_state()
        sys.exit(1)


@cli.command()
@click.pass_context
def version(ctx):
    """Show version information."""
    from neoCoder import __version__
    console.print(f"neoCoder Agent v{__version__}")


@cli.command()
@click.pass_context
def info(ctx):
    """Show configuration information."""
    console.print("[bold]Configuration:[/bold]")
    for key, value in ctx.obj.items():
        console.print(f"  {key}: {value}")


@cli.group()
def workflow():
    """Workflow management commands."""
    pass


@workflow.command()
@click.option(
    "--state-file",
    default=".neoCoder/workflow_state.json",
    help="Path to workflow state file",
)
def status(state_file):
    """Show current workflow status."""
    from pathlib import Path
    from neoCoder.nca.workflow.manager import WorkflowManager
    from neoCoder.nca.workflow.display import display_workflow_summary
    from rich.table import Table
    import json
    
    state_path = Path(state_file)
    
    if not state_path.exists():
        console.print("[yellow]No active workflow found.[/yellow]")
        console.print(f"State file: {state_file}")
        return
    
    try:
        # Load state
        with open(state_path, 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        # Display workflow status
        console.print("\n[bold cyan]Workflow Status[/bold cyan]\n")
        
        # Create status table
        table = Table(show_header=True, header_style="bold cyan")
        table.add_column("Property", style="cyan")
        table.add_column("Value")
        
        table.add_row("Task", state_data.get("task_description", "N/A"))
        table.add_row("Current Stage", str(state_data.get("current_stage", 0)))
        table.add_row("Started At", state_data.get("started_at", "N/A"))
        table.add_row("Updated At", state_data.get("updated_at", "N/A"))
        table.add_row("Retry Count", str(state_data.get("retry_count", 0)))
        table.add_row("Total Failures", str(len(state_data.get("failures", []))))
        
        console.print(table)
        
        # Display stage outputs if available
        stage_outputs = state_data.get("stage_outputs", {})
        if stage_outputs:
            console.print("\n[bold cyan]Stage Outputs:[/bold cyan]")
            for stage_name, output in stage_outputs.items():
                console.print(f"\n[bold]{stage_name}:[/bold]")
                if isinstance(output, dict):
                    for key, value in output.items():
                        console.print(f"  {key}: {value}")
                else:
                    output_str = str(output)
                    if len(output_str) > 100:
                        output_str = output_str[:97] + "..."
                    console.print(f"  {output_str}")
        
        # Display failures if any
        failures = state_data.get("failures", [])
        if failures:
            console.print("\n[bold yellow]Failures:[/bold yellow]")
            for failure in failures[-5:]:  # Show last 5 failures
                console.print(f"  [red]•[/red] Stage {failure.get('stage_number')}: {failure.get('stage_name')}")
                console.print(f"    {failure.get('error_message')}")
                console.print(f"    {failure.get('timestamp')}")
        
        console.print()
        
    except Exception as e:
        console.print(f"[red]Error reading workflow state: {e}[/red]")
        sys.exit(1)


@workflow.command()
@click.option(
    "--state-file",
    default=".neoCoder/workflow_state.json",
    help="Path to workflow state file",
)
@click.confirmation_option(
    prompt="Are you sure you want to reset the workflow state?"
)
def reset(state_file):
    """Reset workflow state and start fresh."""
    from pathlib import Path
    import os
    
    state_path = Path(state_file)
    
    if not state_path.exists():
        console.print("[yellow]No workflow state to reset.[/yellow]")
        return
    
    try:
        # Delete state file
        os.remove(state_path)
        console.print("[green]✓ Workflow state reset successfully.[/green]")
        console.print(f"Deleted: {state_file}")
    except Exception as e:
        console.print(f"[red]Error resetting workflow state: {e}[/red]")
        sys.exit(1)


if __name__ == "__main__":
    cli()
