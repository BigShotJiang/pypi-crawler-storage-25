import json
from typing import Any, Dict, List, Union

def is_uniform_dict_list(data: List[Any]) -> bool:
    """Check if a list contains dictionaries with the exact same keys."""
    if not data or not isinstance(data[0], dict):
        return False
    keys = set(data[0].keys())
    for item in data[1:]:
        if not isinstance(item, dict) or set(item.keys()) != keys:
            return False
    return True

def dumps(data: Any, indent: int = 0, indent_size: int = 2) -> str:
    """
    Serialize a Python dictionary or list to TOON 
    (Token-Oriented Object Notation).
    """
    prefix = " " * indent
    
    if data is None:
        return "null"
    elif isinstance(data, bool):
        return "true" if data else "false"
    elif isinstance(data, (int, float)):
        return str(data)
    elif isinstance(data, str):
        # Only quote strings if they contain newlines or colons, else bare string
        if "\n" in data or ":" in data or data.lower() in ("true", "false", "null"):
            return json.dumps(data)
        return data
    elif isinstance(data, list):
        if not data:
            return "[]"
            
        # Check if we can use tabular (CSV) format for uniform objects
        if is_uniform_dict_list(data):
            keys = list(data[0].keys())
            header = " | ".join(str(k) for k in keys)
            lines = [prefix + header]
            for item in data:
                row = []
                for k in keys:
                    val = item[k]
                    # Keep values simple in table
                    if isinstance(val, (dict, list)):
                        row.append(json.dumps(val)) # fallback for complex nested in table
                    else:
                        row.append(str(val).replace("|", "\\\\|").replace("\n", " "))
                lines.append(prefix + " | ".join(row))
            return "\n".join(lines)
            
        # Standard list representation
        lines = []
        for item in data:
            # For complex items, indent them
            item_str = dumps(item, indent + indent_size, indent_size)
            lines.append(f"{prefix}- {item_str.lstrip()}")
        return "\n".join(lines)
        
    elif isinstance(data, dict):
        if not data:
            return "{}"
            
        lines = []
        for k, v in data.items():
            key_str = str(k)
            # If value is simple, put on same line
            if v is None or isinstance(v, (bool, int, float, str)):
                val_str = dumps(v, 0)
                lines.append(f"{prefix}{key_str}: {val_str}")
            # If value is complex, newline and indent
            else:
                lines.append(f"{prefix}{key_str}:")
                val_str = dumps(v, indent + indent_size, indent_size)
                lines.append(val_str)
                
        return "\n".join(lines)
        
    else:
        return str(data)
