"""
neoCoder Orchestrator - Core agent execution loop.

The orchestrator is the heart of the neoCoder SDK. It:
1. Invokes the LLM with system prompt + memory
2. Parses LLM output into actions
3. Routes actions to extensions
4. Updates memory with results
5. Manages iteration and termination

Based on Algorithm 1 from the neoCoder paper.
"""

from __future__ import annotations

import asyncio
import json
import time
import uuid
import threading
from dataclasses import dataclass, field
from typing import Any, Callable
from enum import Enum

from neoCoder.sdk.llm.client import ClaudeClientConfig, ToolDefinition, LLMResponse
from neoCoder.sdk.llm.client_factory import create_client
from neoCoder.sdk.llm.base_client import BaseLLMClient, InsufficientBalanceError
from neoCoder.sdk.llm.output_parser import OutputParser, Action, format_tool_result
from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.memory.working import WorkingMemory, WorkingMemoryConfig
from neoCoder.sdk.memory.hierarchical import HierarchicalMemory, HierarchicalMemoryConfig
from neoCoder.sdk.memory.episodic import EpisodicMemory, EpisodicMemoryConfig, Episode
from neoCoder.sdk.memory.cognitive import CognitiveMemoryManager, CognitiveMemoryConfig
from neoCoder.sdk.adaptive_memory import AdaptiveMemoryManager, AdaptiveMemoryConfig, AdaptiveMemoryResult
from neoCoder.sdk.monitoring.token_tracker import TokenTracker
from neoCoder.sdk.monitoring.models import TokenUsage
from neoCoder.sdk.self_correction import SelfCorrectionManager, SelfCorrectionConfig, CorrectionResult


class OrchestratorState(Enum):
    """State of the orchestrator."""

    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    ERROR = "error"


@dataclass
class OrchestratorConfig:
    """Configuration for the orchestrator."""

    max_iterations: int = 100
    llm_config: ClaudeClientConfig | None = None
    memory_config: WorkingMemoryConfig | None = None
    working_dir: str = "."
    enable_streaming: bool = True
    enable_adaptive_memory: bool = True
    adaptive_memory_config: AdaptiveMemoryConfig | None = None
    enable_hierarchical_memory: bool = True  # Enable persistent hierarchical memory
    hierarchical_memory_config: HierarchicalMemoryConfig | None = None
    balance_retry_interval: int = 60  # Seconds to wait before retrying on 402
    balance_retry_max_attempts: int = 5  # Max retries on balance errors (0 = infinite, not recommended)
    enable_token_tracking: bool = True  # Enable TokenTracker integration
    api_key: str | None = None  # API key for TokenTracker (Zenmux)
    
    # Cognitive memory (Context as Cognitive Architecture)
    enable_cognitive_memory: bool = True  # Enable episodic memory + consolidation
    cognitive_memory_config: CognitiveMemoryConfig | None = None
    
    # Self-Questioning (AgentEvolver-inspired)
    enable_self_questioning: bool = True  # Trigger reflection after tool errors
    self_questioning_consecutive_errors: int = 2  # Trigger after N consecutive errors
    
    # Self-Correction (validate → analyze → fix loop)
    enable_self_correction: bool = True  # Run validation after task completion
    self_correction_config: SelfCorrectionConfig | None = None  # Detailed config


@dataclass
class OrchestratorResult:
    """Result of an orchestrator run."""

    success: bool
    output: str
    iterations: int
    total_tokens: int
    artifacts: dict[str, Any] = field(default_factory=dict)
    error: str | None = None
    adaptive_memory_metrics: dict[str, Any] = field(default_factory=dict)
    
    # Self-correction results
    self_correction_result: CorrectionResult | None = None
    
    # Detailed token usage
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0
    reasoning_tokens: int = 0
    generation_id: str | None = None  # Last generation ID for external tracking


class Orchestrator:
    """
    Core agent execution loop.

    Implements the neoCoder orchestrator that coordinates:
    - LLM invocations
    - Extension-based tool use
    - Memory management
    - Iteration control
    """

    def __init__(
        self,
        config: OrchestratorConfig | None = None,
        extensions: list[Extension] | None = None,
        system_prompt: str | None = None,
    ):
        """
        Initialize the orchestrator.

        Args:
            config: Orchestrator configuration.
            extensions: List of extensions to register.
            system_prompt: System prompt for the agent.
        """
        import logging
        logger = logging.getLogger(__name__)
        logger.info("Orchestrator.__init__ started")
        
        self.config = config or OrchestratorConfig()
        logger.info("Orchestrator: Config initialized")

        # Initialize thread lock for config updates
        self._config_lock = threading.RLock()

        # Initialize adaptive memory manager if enabled
        self._adaptive_memory: AdaptiveMemoryManager | None = None
        if self.config.enable_adaptive_memory:
            logger.info("Orchestrator: Creating adaptive memory...")
            self._adaptive_memory = AdaptiveMemoryManager(
                config=self.config.adaptive_memory_config
            )
            logger.info("Orchestrator: Adaptive memory created")
        
        # Initialize hierarchical memory if enabled (persistent cross-session memory)
        self._hierarchical_memory: HierarchicalMemory | None = None
        if self.config.enable_hierarchical_memory:
            logger.info("Orchestrator: Creating hierarchical memory...")
            self._hierarchical_memory = HierarchicalMemory(
                config=self.config.hierarchical_memory_config
            )
            logger.info("Orchestrator: Hierarchical memory created")

        # Initialize cognitive memory (Context as Cognitive Architecture)
        self._cognitive_memory: CognitiveMemoryManager | None = None
        self._episodic_memory: EpisodicMemory | None = None
        if self.config.enable_cognitive_memory:
            logger.info("Orchestrator: Creating cognitive memory...")
            # Pass orchestrator's hierarchical memory to avoid dual instances
            cognitive_config = self.config.cognitive_memory_config or CognitiveMemoryConfig()
            if self._hierarchical_memory is not None:
                cognitive_config.hierarchical_memory = self._hierarchical_memory
            self._cognitive_memory = CognitiveMemoryManager(config=cognitive_config)
            self._episodic_memory = self._cognitive_memory.episodic
            logger.info("Orchestrator: Cognitive memory created")
            
            # Configure xMemory LLM and embedding functions after LLM client is ready
            # (will be called in _configure_xmemory after LLM init)

        # Initialize components
        logger.info("Orchestrator: Creating LLM client...")
        self._llm: BaseLLMClient = create_client(config=self.config.llm_config)
        logger.info(f"Orchestrator: LLM client created (type: {type(self._llm).__name__})")
        
        logger.info("Orchestrator: Creating memory...")
        self._memory = WorkingMemory(config=self.config.memory_config)
        logger.info("Orchestrator: Memory created")
        
        self._parser = OutputParser()
        self._extensions: dict[str, Extension] = {}
        self._system_prompt = system_prompt or self._default_system_prompt()
        logger.info("Orchestrator: Parser and prompt initialized")

        # State
        self._state = OrchestratorState.IDLE
        self._session_id = str(uuid.uuid4())
        self._iteration = 0
        self._total_tokens = 0
        self._current_task_description: str = ""
        
        # Detailed token tracking
        self._input_tokens = 0
        self._output_tokens = 0
        self._cache_creation_tokens = 0
        self._cache_read_tokens = 0
        self._reasoning_tokens = 0
        self._last_generation_id: str | None = None
        
        # Initialize TokenTracker for monitoring integration
        self._token_tracker: TokenTracker | None = None
        if self.config.enable_token_tracking and self.config.api_key:
            self._token_tracker = TokenTracker(api_key=self.config.api_key)
            logger.info("Orchestrator: TokenTracker initialized")
        
        # Adaptive memory metrics
        self._adaptive_memory_metrics: dict[str, Any] = {
            "enabled": self.config.enable_adaptive_memory,
            "config_updates": 0,
            "initial_config": None,
            "final_config": None,
            "task_type": None,
            "complexity": None,
        }

        # Callbacks
        self._on_user_output: Callable[[str], None] | None = None
        self._on_user_output_stream: Callable[[str], None] | None = None
        self._on_iteration: Callable[[int, LLMResponse], None] | None = None

        # Track if any streaming text was emitted in current iteration
        self._streamed_text_since_iteration = False

        # Track if a pre-action preface was already shown for current iteration
        self._preface_emitted_for_iteration = False

        # Track if we should suppress the next post-tool text (redundant preface)
        self._suppress_next_post_tool_text = False

        # Buffer streaming chunks when suppressing post-tool text
        self._post_tool_stream_buffer: list[str] = []

        # Self-Questioning state (AgentEvolver-inspired)
        self._consecutive_errors: int = 0
        self._self_questioning_triggered: bool = False
        
        # Error tracking for episode memory
        self._pending_errors: list[str] = []  # Errors encountered, waiting to be fixed
        
        # Self-Correction manager (validate → analyze → fix loop)
        self._self_correction: SelfCorrectionManager | None = None
        if self.config.enable_self_correction:
            logger.info("Orchestrator: Creating self-correction manager...")
            self._self_correction = SelfCorrectionManager(
                working_dir=self.config.working_dir,
                llm_invoke=self._llm_invoke_for_correction,
                config=self.config.self_correction_config,
                on_status=self._on_correction_status,
            )
            logger.info("Orchestrator: Self-correction manager created")

        # Register extensions
        if extensions:
            logger.info(f"Orchestrator: Registering {len(extensions)} extensions...")
            for ext in extensions:
                self.register_extension(ext)
            logger.info("Orchestrator: Extensions registered")
        
        # Configure xMemory with LLM and embedding functions
        self._configure_xmemory()
        
        logger.info("Orchestrator.__init__ completed")

    def _configure_xmemory(self) -> None:
        """
        Configure xMemory with LLM and embedding functions.
        
        This enables:
        - Semantic extraction from episodes
        - Theme summarization
        - Embedding-based retrieval
        """
        import logging
        logger = logging.getLogger(__name__)
        
        if not self._cognitive_memory or not self._cognitive_memory.xmemory:
            return
        
        # Create LLM call wrapper using streaming to avoid timeout
        def llm_call(prompt: str) -> str:
            """Call LLM for xMemory operations using streaming."""
            try:
                # Use streaming to avoid "Streaming is required" error
                response = self._llm.invoke_stream(
                    messages=[{"role": "user", "content": prompt}],
                    system="You are a helpful assistant that extracts and summarizes knowledge. Be concise.",
                    on_text=lambda x: None,  # Discard streaming chunks
                )
                return response.content
            except Exception as e:
                logger.warning(f"xMemory LLM call failed: {e}")
                return ""
        
        # Create embedding function using OpenAI-compatible endpoint
        def embed_fn(text: str):
            """Generate embedding for text."""
            import numpy as np
            try:
                # Try using OpenAI-compatible embedding endpoint
                import httpx
                
                # Get embedding endpoint from LLM config
                api_key = getattr(self.config.llm_config, 'api_key', None)
                base_url = getattr(self.config.llm_config, 'base_url', None)
                
                if api_key and base_url:
                    # Use embedding endpoint
                    embed_url = f"{base_url.rstrip('/')}/embeddings"
                    
                    response = httpx.post(
                        embed_url,
                        headers={"Authorization": f"Bearer {api_key}"},
                        json={
                            "model": "text-embedding-3-small",
                            "input": text[:8000],  # Limit input
                        },
                        timeout=30.0,
                    )
                    
                    if response.status_code == 200:
                        data = response.json()
                        embedding = data["data"][0]["embedding"]
                        return np.array(embedding, dtype=np.float32)
                
                # Fallback: generate pseudo-embedding from text hash
                # (for testing/demo without real embeddings)
                return _generate_pseudo_embedding(text)
                
            except Exception as e:
                logger.debug(f"Embedding generation fallback: {e}")
                return _generate_pseudo_embedding(text)
        
        def _generate_pseudo_embedding(text: str, dim: int = 1536):
            """Generate pseudo-embedding from text hash (fallback)."""
            import numpy as np
            import hashlib
            
            # Create deterministic embedding from text
            text_hash = hashlib.sha256(text.encode()).hexdigest()
            seed = int(text_hash[:8], 16)
            rng = np.random.RandomState(seed)
            vec = rng.randn(dim).astype(np.float32)
            return vec / (np.linalg.norm(vec) + 1e-9)
        
        # Set summary generator for cognitive memory
        self._cognitive_memory.set_summary_generator(llm_call)
        
        # Set embedding function for xMemory
        self._cognitive_memory.set_embedding_function(embed_fn)
        
        logger.info("Orchestrator: xMemory configured with LLM and embedding functions")

    def _default_system_prompt(self) -> str:
        """Default system prompt."""
        return """You are a carefully AI assistant with access to tools for coding tasks.

When you need to perform actions, use the available tools. After using a tool,
analyze the result and continue with the task.

When the task is complete, provide a summary of what was accomplished."""

    def _is_redundant_preface(self, content: str) -> bool:
        """Detect redundant post-tool preface text."""
        if not content:
            return False
        normalized = content.strip().lower()
        if not normalized:
            return False
        if len(normalized) > 200:
            return False
        preface_starts = (
            "i'll create",
            "i will create",
            "i can create",
            "i am creating",
            "creating ",
            "i'll write",
            "i will write",
            "i can write",
            "writing ",
            "i'll use the",
            "i will use the",
            "i can use the",
            "i'll use the ",
            "i will use the ",
            "i can use the ",
            "i'll use the file",
            "i will use the file",
            "i can use the file",
            "i'll use the file_read",
            "i will use the file_read",
            "i can use the file_read",
            "let me check",
        )
        if normalized.startswith(preface_starts):
            return True
        if "create" in normalized and "file" in normalized:
            return True
        return False

    @property
    def state(self) -> OrchestratorState:
        """Current orchestrator state."""
        return self._state

    @property
    def memory(self) -> WorkingMemory:
        """Access to working memory."""
        return self._memory

    @property
    def hierarchical_memory(self) -> HierarchicalMemory | None:
        """Access to hierarchical memory (persistent cross-session)."""
        return self._hierarchical_memory

    @property
    def token_tracker(self) -> TokenTracker | None:
        """Access to token tracker for monitoring integration."""
        return self._token_tracker

    @property
    def last_generation_id(self) -> str | None:
        """Last generation ID from LLM response."""
        return self._last_generation_id

    @property
    def cognitive_memory(self) -> CognitiveMemoryManager | None:
        """Access to cognitive memory manager."""
        return self._cognitive_memory

    @property
    def episodic_memory(self) -> EpisodicMemory | None:
        """Access to episodic memory."""
        return self._episodic_memory

    @property
    def self_correction(self) -> SelfCorrectionManager | None:
        """Access to self-correction manager."""
        return self._self_correction

    # ------------------------------------------------------------------
    # Self-Correction helper methods
    # ------------------------------------------------------------------

    async def _llm_invoke_for_correction(
        self,
        messages: list[dict[str, Any]],
        **kwargs,
    ) -> Any:
        """
        LLM invoke wrapper for self-correction manager.
        
        Uses the same LLM client as the orchestrator.
        """
        reasoning_effort = kwargs.get("reasoning_effort", "low")
        
        # Use streaming for consistency
        response = await self._llm.invoke_stream_async(
            messages=messages,
            system="You are analyzing validation errors and generating fixes. Be precise and specific.",
            on_text=lambda x: None,  # Discard streaming chunks for analysis
        )
        
        return response

    def _on_correction_status(self, status: str) -> None:
        """
        Callback for self-correction status updates.
        
        Routes to user output callback if available.
        """
        if self._on_user_output:
            self._on_user_output(status)

    async def _run_self_correction(
        self,
        changed_files: list[str],
        task_context: str,
    ) -> CorrectionResult | None:
        """
        Run self-correction loop after task completion.
        
        Args:
            changed_files: List of files that were changed
            task_context: Original task description
            
        Returns:
            CorrectionResult or None if correction not enabled/needed
        """
        if not self._self_correction or not self.config.enable_self_correction:
            return None
        
        if not changed_files:
            return None
        
        return await self._self_correction.run_correction_loop(
            changed_files=changed_files,
            task_context=task_context,
        )

    def _run_self_correction_sync(
        self,
        changed_files: list[str],
        task_context: str,
    ) -> CorrectionResult | None:
        """
        Synchronous version of self-correction for use in run().
        
        Args:
            changed_files: List of files that were changed
            task_context: Original task description
            
        Returns:
            CorrectionResult or None if correction not enabled/needed
        """
        if not self._self_correction or not self.config.enable_self_correction:
            return None
        
        if not changed_files:
            return None
        
        # Run async code in sync context
        import asyncio
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None
        
        if loop and loop.is_running():
            # Already in async context - create task
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(
                    asyncio.run,
                    self._self_correction.run_correction_loop(
                        changed_files=changed_files,
                        task_context=task_context,
                    )
                )
                return future.result()
        else:
            # No running loop - use asyncio.run
            return asyncio.run(
                self._self_correction.run_correction_loop(
                    changed_files=changed_files,
                    task_context=task_context,
                )
            )

    def _apply_adaptive_memory_config(self, task: str) -> None:
        """
        Apply adaptive memory configuration based on task.

        Args:
            task: Task description to analyze.
        """
        if not self._adaptive_memory:
            return

        with self._config_lock:
            # Get adaptive memory configuration
            result = self._adaptive_memory.get_memory_config(task)

            # Track metrics
            self._adaptive_memory_metrics["initial_config"] = {
                "compression_threshold": result.config.compression_threshold,
                "rolling_window_size": result.config.rolling_window_size,
            }
            self._adaptive_memory_metrics["task_type"] = result.task_type
            self._adaptive_memory_metrics["complexity"] = result.complexity

            # Apply to working memory
            if self._memory.config:
                self._memory.config.compression_threshold = result.config.compression_threshold
                self._memory.config.rolling_window_size = result.config.rolling_window_size

    def _update_adaptive_memory_config(self, context_update: str) -> None:
        """
        Update adaptive memory configuration during execution.

        This allows the orchestrator to adjust memory parameters mid-execution
        based on how the task is evolving.

        Args:
            context_update: Additional context about task evolution.
        """
        if not self._adaptive_memory:
            return

        with self._config_lock:
            # Combine original task with context update
            updated_task = f"{self._current_task_description}\n\nContext: {context_update}"

            # Get new adaptive memory configuration
            result = self._adaptive_memory.get_memory_config(updated_task)

            # Track metrics
            self._adaptive_memory_metrics["config_updates"] += 1
            self._adaptive_memory_metrics["final_config"] = {
                "compression_threshold": result.config.compression_threshold,
                "rolling_window_size": result.config.rolling_window_size,
            }

            # Apply to working memory
            if self._memory.config:
                self._memory.config.compression_threshold = result.config.compression_threshold
                self._memory.config.rolling_window_size = result.config.rolling_window_size

    def _should_update_config(self, output: str) -> bool:
        """
        Determine if config should be updated based on action output.

        Args:
            output: Action output to analyze.

        Returns:
            True if config should be updated.
        """
        # Keywords that suggest task type might have changed
        debug_keywords = ["error", "exception", "traceback", "failed", "bug"]
        refactor_keywords = ["refactor", "restructure", "reorganize", "improve"]
        
        output_lower = output.lower()
        
        # Check for significant context changes
        has_debug = any(kw in output_lower for kw in debug_keywords)
        has_refactor = any(kw in output_lower for kw in refactor_keywords)
        
        # Update config if we detect a shift in task type
        return has_debug or has_refactor

    def register_extension(self, extension: Extension) -> None:
        """
        Register an extension.

        Args:
            extension: Extension to register.
        """
        self._extensions[extension.name] = extension

        # Register extension's XML tags with parser
        for tag in extension.xml_tags:
            self._parser.add_tag(tag)

        # Register extension's tools with LLM client
        for tool_def in extension.tool_definitions:
            self._llm.register_tool(
                ToolDefinition(
                    name=tool_def["name"],
                    description=tool_def["description"],
                    input_schema=tool_def["input_schema"],
                )
            )
        
        # Link extensions after registration
        self._link_extensions()
    
    def _link_extensions(self) -> None:
        """
        Link extensions together for cross-extension functionality.

        Links:
        - FileEditExtension ← CodeReviewExtension (legacy field)
        - FileEditExtension ← any extension with pre_file_operation_hook
        """
        file_edit_ext = self._extensions.get("file_edit")
        if file_edit_ext is None:
            return

        # Link: code_review → file_edit (so batch_review can read written_files)
        code_review_ext = self._extensions.get("code_review")
        if code_review_ext and hasattr(code_review_ext, "_file_edit_extension"):
            code_review_ext._file_edit_extension = file_edit_ext

        # Generic hooks: register every other extension that exposes the hook
        if hasattr(file_edit_ext, "_pre_operation_hooks"):
            for ext_name, ext in self._extensions.items():
                if ext_name in ("file_edit", "code_review"):
                    continue  # already handled above
                if hasattr(ext, "pre_file_operation_hook"):
                    if ext not in file_edit_ext._pre_operation_hooks:
                        file_edit_ext._pre_operation_hooks.append(ext)

        # Post-write hooks: register extensions that verify AFTER file is on disk
        if hasattr(file_edit_ext, "_post_operation_hooks"):
            for ext_name, ext in self._extensions.items():
                if ext_name == "file_edit":
                    continue
                if hasattr(ext, "post_file_operation_hook"):
                    if ext not in file_edit_ext._post_operation_hooks:
                        file_edit_ext._post_operation_hooks.append(ext)

    def set_callbacks(
        self,
        on_output: Callable[[str], None] | None = None,
        on_stream: Callable[[str], None] | None = None,
        on_iteration: Callable[[int, LLMResponse], None] | None = None,
        confirmation_callback: Any | None = None,
    ) -> None:
        """Set callback functions for UX output."""
        self._on_user_output = on_output
        if on_stream:
            def tracked_on_stream(chunk: str) -> None:
                if self._suppress_next_post_tool_text:
                    self._post_tool_stream_buffer.append(chunk)
                    return
                self._streamed_text_since_iteration = True
                on_stream(chunk)
            self._on_user_output_stream = tracked_on_stream
        else:
            self._on_user_output_stream = None
        self._on_iteration = on_iteration
        self._confirmation_callback = confirmation_callback

    def _create_context(self) -> ExtensionContext:
        """Create extension context for current run."""
        return ExtensionContext(
            memory=self._memory,
            session_id=self._session_id,
            working_dir=self.config.working_dir,
            on_user_output=self._on_user_output,
            on_user_output_stream=self._on_user_output_stream,
            confirmation_callback=getattr(self, '_confirmation_callback', None),
        )

    def _route_action(self, action: Action) -> Extension | None:
        """
        Route an action to the appropriate extension.

        Args:
            action: Action to route.

        Returns:
            Extension that can handle the action, or None.
        """
        # First try direct name match
        if action.name in self._extensions:
            return self._extensions[action.name]

        # Then try each extension's can_handle
        for ext in self._extensions.values():
            if ext.enabled and ext.can_handle(action):
                return ext

        return None

    def _execute_action(
        self,
        action: Action,
        context: ExtensionContext,
        pre_action_text: str | None = None,
        preface_already_shown: bool = False,
    ) -> ExecutionResult:
        """
        Execute an action through its extension.

        Args:
            action: Action to execute.
            context: Extension context.

        Returns:
            ExecutionResult from the extension.
        """
        extension = self._route_action(action)

        if extension is None:
            return ExecutionResult.error_result(
                f"No extension found to handle action: {action.name}"
            )

        try:
            suppress_preface = False
            if pre_action_text:
                suppress_preface = self._is_redundant_preface(pre_action_text)
            if pre_action_text and self._on_user_output and not preface_already_shown:
                if not suppress_preface:
                    self._on_user_output(pre_action_text)
                    self._preface_emitted_for_iteration = True
                    preface_already_shown = True
            if pre_action_text:
                self._suppress_next_post_tool_text = True
            start_time = time.time()
            result = extension.execute(action, context)
            duration_ms = (time.time() - start_time) * 1000

            # Record tool invocation - generate ID if missing
            tool_use_id = action.id or f"tool_{action.name}_{int(time.time() * 1000)}"
            self._memory.add_tool_result(
                tool_use_id=tool_use_id,
                tool_name=action.name,
                input_params=action.input,
                output=result.output,
                success=result.success,
                duration_ms=duration_ms,
            )

            # Output to user (UX)
            if result.user_output and self._on_user_output:
                if pre_action_text and not preface_already_shown:
                    self._on_user_output(pre_action_text)
                    self._preface_emitted_for_iteration = True
                    preface_already_shown = True
                self._on_user_output(result.user_output)

            return result

        except Exception as e:
            # Let extension handle error if possible
            error_result = extension.on_error(e, context)
            if error_result:
                return error_result
            return ExecutionResult.error_result(str(e))

    def _invoke_llm(self, context: ExtensionContext) -> LLMResponse:
        """
        Invoke the LLM with current context.

        Args:
            context: Extension context.

        Returns:
            LLM response.
        """
        import logging
        logger = logging.getLogger(__name__)
        
        # Get messages for LLM
        messages = self._memory.get_messages_for_llm()

        # Let extensions modify messages
        for ext in self._extensions.values():
            if ext.enabled:
                messages = ext.on_input_messages(messages, context)

        # Invoke LLM
        if self.config.enable_streaming and self._on_user_output_stream:
            response = self._llm.invoke_stream(
                messages=messages,
                system=self._system_prompt,
                on_text=self._on_user_output_stream,
            )
        else:
            response = self._llm.invoke(
                messages=messages,
                system=self._system_prompt,
            )

        # Let extensions process output
        content = response.content
        for ext in self._extensions.values():
            if ext.enabled:
                content = ext.on_llm_output(content, context)

        # Update token count
        usage = response.usage
        self._input_tokens += usage.get("input_tokens", 0)
        self._output_tokens += usage.get("output_tokens", 0)
        self._cache_creation_tokens += usage.get("cache_creation_input_tokens", 0)
        self._cache_read_tokens += usage.get("cache_read_input_tokens", 0)
        self._reasoning_tokens += usage.get("reasoning_tokens", 0)
        
        # Total tokens
        self._total_tokens += usage.get("input_tokens", 0)
        self._total_tokens += usage.get("output_tokens", 0)

        # Track generation_id and update TokenTracker
        if response.generation_id:
            self._last_generation_id = response.generation_id
        
        if self._token_tracker:
            self._token_tracker.update_from_response({
                "prompt_tokens": usage.get("input_tokens", 0),
                "completion_tokens": usage.get("output_tokens", 0),
                "reasoning_tokens": usage.get("reasoning_tokens", 0),
                "total_tokens": usage.get("input_tokens", 0) + usage.get("output_tokens", 0),
            })
            logger.debug(
                f"TokenTracker updated: ctx={self._token_tracker.current_usage.context_tokens}, "
                f"out={self._token_tracker.current_usage.output_tokens}"
            )

        return response

    def _is_complete(self, response: LLMResponse) -> bool:
        """
        Check if the task is complete.

        Args:
            response: Latest LLM response.

        Returns:
            True if task should be considered complete.
        """
        import logging
        import re
        logger = logging.getLogger(__name__)
        
        # 1. No actions and natural stop
        if not response.actions and response.stop_reason in ("stop", "end_turn", "completed"):
            logger.info("Task complete: No actions + natural stop")
            return True

        # 2. Check for explicit completion phrases in response
        if response.content and not response.actions:
            content_lower = response.content.lower()
            
            # Multi-word completion phrases (safe, no false positives)
            completion_phrases = [
                "task is complete",
                "task complete",
                "finished creating",
                "successfully created",
                "file has been created",
                "i've created",
                "i have created",
                "implementation is complete",
                "changes have been applied",
            ]
            has_completion_phrase = any(phrase in content_lower for phrase in completion_phrases)
            
            if has_completion_phrase:
                logger.info("Task complete: Completion phrase detected + no new actions")
                return True
            
            # Check for standalone "done" at end of sentence (avoid "not done", "half-done")
            # Match "done." or "done!" at end, or "I'm done" / "I am done"
            done_patterns = [
                r"\bi['\u2019]?m done\b",      # I'm done
                r"\bi am done\b",              # I am done
                r"\bdone[.!]?\s*$",            # done. / done! at end
            ]
            for pattern in done_patterns:
                if re.search(pattern, content_lower):
                    # Extra check: ensure no negation nearby
                    negation_pattern = r"\b(not|never|isn['\u2019]?t|haven['\u2019]?t|hasn['\u2019]?t|half-?)\s*(done|finished)"
                    if not re.search(negation_pattern, content_lower):
                        logger.info("Task complete: 'done' pattern detected + no new actions")
                        return True

        return False

    def run(self, task: str) -> OrchestratorResult:
        """
        Run the orchestrator on a task.

        This is the main entry point that implements Algorithm 1 from the paper.

        Args:
            task: The task to perform.

        Returns:
            OrchestratorResult with output and metadata.
        """
        import logging
        logger = logging.getLogger(__name__)
        self._state = OrchestratorState.RUNNING
        self._iteration = 0
        self._total_tokens = 0
        self._input_tokens = 0
        self._output_tokens = 0
        self._cache_creation_tokens = 0
        self._cache_read_tokens = 0
        self._reasoning_tokens = 0
        self._current_task_description = task
        
        # Reset self-questioning state for new task
        self._consecutive_errors = 0
        self._self_questioning_triggered = False

        # Apply adaptive memory configuration
        self._apply_adaptive_memory_config(task)

        # Initialize cognitive memory for this task (episodic retrieval)
        episode_context: str | None = None
        if self._cognitive_memory:
            episode_context = self._cognitive_memory.start_task(
                task=task,
                session_id=self._session_id,
            )

        # Add initial task message (with episode context if available)
        if episode_context:
            self._memory.add_user_message(f"{episode_context}\n\nCurrent task: {task}")
        else:
            self._memory.add_user_message(task)

        context = self._create_context()
        last_content = ""
        accumulated_output = []  # Accumulate all LLM outputs for stage tracking

        try:
            while self._iteration < self.config.max_iterations:
                self._iteration += 1
                self._streamed_text_since_iteration = False
                self._preface_emitted_for_iteration = False

                # Step 1: Invoke LLM with retry on balance errors
                balance_retry_count = 0
                while True:
                    try:
                        response = self._invoke_llm(context)
                        break  # Success, exit retry loop
                    except InsufficientBalanceError as e:
                        balance_retry_count += 1
                        max_attempts = self.config.balance_retry_max_attempts
                        
                        if max_attempts > 0 and balance_retry_count >= max_attempts:
                            raise  # Max retries exceeded
                        
                        # Display waiting message
                        wait_seconds = self.config.balance_retry_interval
                        if self._on_user_output:
                            self._on_user_output(
                                f"\n💳 {e}\n"
                                f"⏳ Waiting for balance top-up... (attempt {balance_retry_count}, "
                                f"retry in {wait_seconds}s)\n"
                                f"   Progress saved. Press Ctrl+C to exit.\n"
                            )
                        
                        # Wait and retry
                        time.sleep(wait_seconds)
                        continue
                
                last_content = response.content
                
                # Accumulate meaningful output for stage context
                if response.content and response.content.strip():
                    accumulated_output.append(response.content)

                if self._suppress_next_post_tool_text and self._is_redundant_preface(response.content):
                    response.content = ""
                    last_content = ""
                    self._post_tool_stream_buffer.clear()
                    self._suppress_next_post_tool_text = False
                elif self._suppress_next_post_tool_text:
                    self._post_tool_stream_buffer.clear()
                    self._suppress_next_post_tool_text = False

                # Callback for iteration
                if self._on_iteration:
                    self._on_iteration(self._iteration, response)

                # Step 2: Add assistant message to memory
                if response.content or response.actions:
                    content_for_memory: str | list[dict[str, Any]] = response.content

                    # If there are tool uses, format properly
                    if response.actions:
                        content_blocks: list[dict[str, Any]] = []
                        if response.content:
                            content_blocks.append({"type": "text", "text": response.content})
                        for action in response.actions:
                            if action.type == "tool_use" and action.id:
                                content_blocks.append({
                                    "type": "tool_use",
                                    "id": action.id,
                                    "name": action.name,
                                    "input": action.input,
                                })
                        content_for_memory = content_blocks

                    self._memory.add_assistant_message(content_for_memory)

                # Step 3: Capture LLM text as pre-action message
                # (streaming already outputs via on_text callback)
                pre_action_text: str | None = None
                preface_already_shown = False
                if response.content and not self._preface_emitted_for_iteration:
                    pre_action_text = response.content
                    if self._is_redundant_preface(pre_action_text):
                        preface_already_shown = True
                        self._preface_emitted_for_iteration = True
                        self._suppress_next_post_tool_text = True
                    elif self._streamed_text_since_iteration:
                        preface_already_shown = True
                    elif self._on_user_output_stream:
                        self._on_user_output_stream(pre_action_text)
                        preface_already_shown = True
                    elif self._on_user_output:
                        self._on_user_output(pre_action_text)
                        preface_already_shown = True
                    if preface_already_shown:
                        self._preface_emitted_for_iteration = True
                        self._suppress_next_post_tool_text = True

                # Step 4: Check for completion (no actions)
                if self._is_complete(response):
                    self._state = OrchestratorState.COMPLETED
                    break

                # Step 5: Execute actions
                should_continue = True
                for action in response.actions:
                    result = self._execute_action(
                        action,
                        context,
                        pre_action_text,
                        preface_already_shown,
                    )
                    pre_action_text = None
                    if preface_already_shown:
                        self._preface_emitted_for_iteration = True

                    # Store artifacts with smart accumulation for lists
                    self._accumulate_artifacts(context.artifacts, result.artifacts)

                    # Self-Questioning: track consecutive errors
                    if self.config.enable_self_questioning:
                        if not result.success:
                            self._consecutive_errors += 1
                            # Track error for potential fix recording
                            error_summary = result.output[:200] if result.output else "Unknown error"
                            self._pending_errors.append(error_summary)
                            # Trigger self-questioning after N consecutive errors
                            if (
                                self._consecutive_errors >= self.config.self_questioning_consecutive_errors
                                and not self._self_questioning_triggered
                            ):
                                self._invoke_self_questioning(result.output, context)
                        else:
                            # Success after errors = errors were fixed
                            if self._pending_errors and action.action_type in ("file_write", "file_edit"):
                                # Record fixed errors in artifacts
                                self._accumulate_artifacts(
                                    context.artifacts,
                                    {"errors_fixed": self._pending_errors.copy()}
                                )
                                self._pending_errors.clear()
                            # Reset on success
                            self._consecutive_errors = 0
                            self._self_questioning_triggered = False

                    # Check if extension signals task completion
                    if result.metadata.get("task_complete"):
                        should_continue = False
                        break

                    # Check if action result suggests task type change
                    if self._adaptive_memory and result.output:
                        # Detect context changes that might require config adjustment
                        if self._should_update_config(result.output):
                            self._update_adaptive_memory_config(result.output[:500])

                    if not result.should_continue:
                        should_continue = False
                        break

                if not should_continue:
                    self._state = OrchestratorState.COMPLETED
                    break

                # Step 6: Check for context compression
                if self._memory.needs_compression():
                    self._compress_context(context)

            # If we hit max iterations
            if self._iteration >= self.config.max_iterations:
                self._state = OrchestratorState.ERROR
                return OrchestratorResult(
                    success=False,
                    output=last_content,
                    iterations=self._iteration,
                    total_tokens=self._total_tokens,
                    artifacts=context.artifacts,
                    error="Max iterations reached",
                    adaptive_memory_metrics=self._adaptive_memory_metrics,
                    input_tokens=self._input_tokens,
                    output_tokens=self._output_tokens,
                    cache_creation_tokens=self._cache_creation_tokens,
                    cache_read_tokens=self._cache_read_tokens,
                    reasoning_tokens=self._reasoning_tokens,
                    generation_id=self._last_generation_id,
                )

            self._state = OrchestratorState.COMPLETED

            # Run deferred project-scope build verification (compile, type-check)
            # once at the end, instead of after every file save.
            build_result = self._run_deferred_build(context)
            if build_result:
                build_output = build_result.get("output", "")
                if build_output:
                    if self._on_user_output:
                        self._on_user_output(
                            f"\n🔨 Final build verification:\n{build_output}"
                        )
                    accumulated_output.append(build_output)

            # Self-correction loop: validate → analyze → fix (sync version)
            correction_result: CorrectionResult | None = None
            if self.config.enable_self_correction and self._self_correction:
                changed_files = context.artifacts.get("changed_files", [])
                if changed_files:
                    correction_result = self._run_self_correction_sync(
                        changed_files=changed_files,
                        task_context=task,
                    )

            # Use accumulated output to capture full stage content (for workflow)
            full_output = "\n\n".join(accumulated_output) if accumulated_output else last_content
            
            # Save to hierarchical memory for cross-session persistence
            self._save_to_hierarchical_memory(
                task=task,
                output=full_output,
                success=True,
                artifacts=context.artifacts,
            )
            
            # Consolidate cognitive memory (create episode from this task)
            if self._cognitive_memory:
                self._cognitive_memory.complete_task(
                    success=True,
                    output=full_output,
                    artifacts=context.artifacts,
                    metrics={
                        "task_type": self._adaptive_memory_metrics.get("task_type", "coding"),
                        "complexity": self._adaptive_memory_metrics.get("complexity", 0.5),
                        "total_tokens": self._total_tokens,
                        "iterations": self._iteration,
                    },
                )
            
            return OrchestratorResult(
                success=True,
                output=full_output,
                iterations=self._iteration,
                total_tokens=self._total_tokens,
                artifacts=context.artifacts,
                adaptive_memory_metrics=self._adaptive_memory_metrics,
                self_correction_result=correction_result,
                input_tokens=self._input_tokens,
                output_tokens=self._output_tokens,
                cache_creation_tokens=self._cache_creation_tokens,
                cache_read_tokens=self._cache_read_tokens,
                reasoning_tokens=self._reasoning_tokens,
                generation_id=self._last_generation_id,
            )

        except Exception as e:
            self._state = OrchestratorState.ERROR
            return OrchestratorResult(
                success=False,
                output=last_content,
                iterations=self._iteration,
                total_tokens=self._total_tokens,
                artifacts=context.artifacts,
                error=str(e),
                adaptive_memory_metrics=self._adaptive_memory_metrics,
                input_tokens=self._input_tokens,
                output_tokens=self._output_tokens,
                cache_creation_tokens=self._cache_creation_tokens,
                cache_read_tokens=self._cache_read_tokens,
                reasoning_tokens=self._reasoning_tokens,
                generation_id=self._last_generation_id,
            )

    def _run_deferred_build(
        self,
        context: ExtensionContext,
    ) -> dict[str, Any] | None:
        """
        Run deferred project-scope build verification through
        the file_edit extension's post-operation hooks.
        Called once when the task is complete.
        """
        file_edit_ext = self._extensions.get("file_edit")
        if file_edit_ext is None:
            return None
        if not hasattr(file_edit_ext, "run_deferred_build_verification"):
            return None

        try:
            return file_edit_ext.run_deferred_build_verification(
                project_dir=context.working_dir,
            )
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(
                "Deferred build verification failed: %s", e,
            )
            return None

    def _invoke_self_questioning(self, error: str, context: ExtensionContext) -> None:
        """
        Invoke Self-Questioning after consecutive tool errors.
        
        AgentEvolver-inspired mechanism that prompts the LLM to reflect on
        its assumptions and explore alternative hypotheses before retrying.
        
        Args:
            error: The error message from the failed tool.
            context: Extension context.
        """
        from neoCoder.nca.prompts import SELF_QUESTIONING_PROMPT
        
        import logging
        logger = logging.getLogger(__name__)
        logger.info("Self-Questioning triggered after %d consecutive errors", self._consecutive_errors)
        
        # Format the self-questioning prompt
        sq_prompt = SELF_QUESTIONING_PROMPT.format(error=error)
        
        # Add as user message to prompt reflection
        self._memory.add_user_message(f"[Self-Questioning]\n{sq_prompt}")
        
        # Notify user
        if self._on_user_output:
            self._on_user_output(
                f"\n🤔 [Self-Questioning] Reflecting on error after {self._consecutive_errors} failed attempts...\n"
            )
        
        # Mark that we triggered self-questioning (to avoid multiple triggers)
        self._self_questioning_triggered = True

    def _compress_context(self, context: ExtensionContext) -> None:
        """
        Compress context when approaching token limits.

        This triggers the Architect agent to summarize old messages.

        Args:
            context: Extension context.
        """
        candidates = self._memory.get_compression_candidates()
        if not candidates:
            return

        # Build summary request
        messages_text = "\n".join(
            f"{m.role}: {m.content if isinstance(m.content, str) else '[tool interaction]'}"
            for m in candidates
        )

        summary_prompt = f"""Summarize the following conversation history, preserving:
- Task goals and current state
- Key decisions made
- Important findings or errors
- Open TODOs or next steps

Conversation:
{messages_text}

Provide a concise summary:"""

        # Make summarization call
        summary_response = self._llm.invoke(
            messages=[{"role": "user", "content": summary_prompt}],
            system="You are a helpful assistant that creates concise summaries.",
        )

        # Apply compression
        self._memory.apply_compression(
            summary=summary_response.content,
            compressed_count=len(candidates),
        )

        # Notify cognitive memory of compression (for consolidation)
        if self._cognitive_memory:
            self._cognitive_memory.on_compression(
                summary=summary_response.content,
                compressed_count=len(candidates),
            )

    def _accumulate_artifacts(
        self,
        target: dict[str, Any],
        source: dict[str, Any],
    ) -> None:
        """
        Accumulate artifacts with smart merging for list-type fields.
        
        - 'last_written_file' gets accumulated into 'files_written' list
        - List fields get extended rather than replaced
        - Other fields use simple update semantics
        """
        for key, value in source.items():
            if key == "last_written_file":
                # Accumulate written files into a list
                if "files_written" not in target:
                    target["files_written"] = []
                if value and value not in target["files_written"]:
                    target["files_written"].append(value)
            elif key in ("files_written", "changed_files", "errors_fixed", "key_decisions", "tags"):
                # List fields: extend rather than replace
                if key not in target:
                    target[key] = []
                if isinstance(value, list):
                    for item in value:
                        if item not in target[key]:
                            target[key].append(item)
                elif value and value not in target[key]:
                    target[key].append(value)
            else:
                # Default: simple update
                target[key] = value

    def _save_to_hierarchical_memory(
        self,
        task: str,
        output: str,
        success: bool,
        artifacts: dict[str, Any],
    ) -> None:
        """
        Save task results to hierarchical memory for cross-session persistence.
        
        Args:
            task: Task description
            output: Task output/result
            success: Whether task completed successfully
            artifacts: Task artifacts
        """
        if not self._hierarchical_memory:
            return
        
        try:
            # Create entry for this task
            entry_id = self._hierarchical_memory.create_entry(
                name=task[:50].replace(" ", "_"),
                metadata={
                    "task": task,
                    "session_id": self._session_id,
                    "success": success,
                    "iterations": self._iteration,
                    "total_tokens": self._total_tokens,
                }
            )
            
            # Store task details
            self._hierarchical_memory.store("task", task)
            self._hierarchical_memory.store("output", output[:5000])  # Limit size
            self._hierarchical_memory.store("success", success)
            
            # Store key artifacts
            if artifacts:
                artifact_summary = {k: str(v)[:500] for k, v in artifacts.items()}
                self._hierarchical_memory.store("artifacts", artifact_summary)
            
            # Store adaptive memory metrics if available
            if self._adaptive_memory_metrics.get("task_type"):
                self._hierarchical_memory.store("task_type", self._adaptive_memory_metrics["task_type"])
                self._hierarchical_memory.store("complexity", self._adaptive_memory_metrics.get("complexity"))
                
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"Failed to save to hierarchical memory: {e}")

    def reset(self) -> None:
        """Reset the orchestrator for a new task."""
        self._memory.clear()
        self._state = OrchestratorState.IDLE
        self._iteration = 0
        self._total_tokens = 0
        self._input_tokens = 0
        self._output_tokens = 0
        self._cache_creation_tokens = 0
        self._cache_read_tokens = 0
        self._reasoning_tokens = 0
        self._last_generation_id = None
        self._session_id = str(uuid.uuid4())
        self._current_task_description = ""
        self._adaptive_memory_metrics = {
            "enabled": self.config.enable_adaptive_memory,
            "config_updates": 0,
            "initial_config": None,
            "final_config": None,
            "task_type": None,
            "complexity": None,
        }
        # Reset self-questioning state
        self._consecutive_errors = 0
        self._self_questioning_triggered = False
        
        if self._token_tracker:
            self._token_tracker.reset()

    def get_task_history(self) -> list[dict[str, Any]]:
        """
        Get history of all tasks from hierarchical memory.
        
        Returns:
            List of task entries with metadata
        """
        if not self._hierarchical_memory:
            return []
        return self._hierarchical_memory.get_all_entries()

    def get_memory_tree(self) -> str:
        """
        Get visual representation of hierarchical memory tree.
        
        Returns:
            Tree structure as string
        """
        if not self._hierarchical_memory:
            return "Hierarchical memory not enabled"
        return self._hierarchical_memory.get_tree_structure()

    def export_memory_to_markdown(self) -> str:
        """
        Export hierarchical memory to markdown format.
        
        Returns:
            Markdown formatted memory content
        """
        if not self._hierarchical_memory:
            return "Hierarchical memory not enabled"
        return self._hierarchical_memory.export_to_markdown()

    # ------------------------------------------------------------------
    # Async execution methods
    # ------------------------------------------------------------------

    async def run_async(self, task: str) -> OrchestratorResult:
        """
        Run the orchestrator on a task asynchronously.

        This is the async version of run() that enables:
        - Non-blocking LLM invocations
        - Parallel tool execution for independent actions
        - Better integration with async frameworks

        Args:
            task: The task to perform.

        Returns:
            OrchestratorResult with output and metadata.
        """
        import logging
        logger = logging.getLogger(__name__)
        self._state = OrchestratorState.RUNNING
        self._iteration = 0
        self._total_tokens = 0
        self._input_tokens = 0
        self._output_tokens = 0
        self._cache_creation_tokens = 0
        self._cache_read_tokens = 0
        self._reasoning_tokens = 0
        self._current_task_description = task
        
        # Reset self-questioning state for new task
        self._consecutive_errors = 0
        self._self_questioning_triggered = False

        # Apply adaptive memory configuration
        self._apply_adaptive_memory_config(task)

        # Add initial task message
        self._memory.add_user_message(task)

        context = self._create_context()
        last_content = ""
        accumulated_output = []

        try:
            while self._iteration < self.config.max_iterations:
                self._iteration += 1
                self._streamed_text_since_iteration = False
                self._preface_emitted_for_iteration = False

                # Step 1: Invoke LLM asynchronously
                response = await self._invoke_llm_async(context)
                
                last_content = response.content

                if response.content and response.content.strip():
                    accumulated_output.append(response.content)

                if self._suppress_next_post_tool_text and self._is_redundant_preface(response.content):
                    response.content = ""
                    last_content = ""
                    self._post_tool_stream_buffer.clear()
                    self._suppress_next_post_tool_text = False
                elif self._suppress_next_post_tool_text:
                    self._post_tool_stream_buffer.clear()
                    self._suppress_next_post_tool_text = False

                if self._on_iteration:
                    self._on_iteration(self._iteration, response)

                # Step 2: Add assistant message to memory
                if response.content or response.actions:
                    content_for_memory: str | list[dict[str, Any]] = response.content

                    if response.actions:
                        content_blocks: list[dict[str, Any]] = []
                        if response.content:
                            content_blocks.append({"type": "text", "text": response.content})
                        for action in response.actions:
                            if action.type == "tool_use" and action.id:
                                content_blocks.append({
                                    "type": "tool_use",
                                    "id": action.id,
                                    "name": action.name,
                                    "input": action.input,
                                })
                        content_for_memory = content_blocks

                    self._memory.add_assistant_message(content_for_memory)

                # Step 3: Pre-action text handling
                pre_action_text: str | None = None
                preface_already_shown = False
                if response.content and not self._preface_emitted_for_iteration:
                    pre_action_text = response.content
                    if self._is_redundant_preface(pre_action_text):
                        preface_already_shown = True
                        self._preface_emitted_for_iteration = True
                        self._suppress_next_post_tool_text = True
                    elif self._streamed_text_since_iteration:
                        preface_already_shown = True

                # Step 4: Check for completion
                if self._is_complete(response):
                    self._state = OrchestratorState.COMPLETED
                    break

                # Step 5: Execute actions (potentially in parallel)
                should_continue = await self._execute_actions_async(
                    response.actions, context, pre_action_text, preface_already_shown
                )

                if not should_continue:
                    self._state = OrchestratorState.COMPLETED
                    break

                # Step 6: Check for context compression
                if self._memory.needs_compression():
                    self._compress_context(context)

            # Max iterations check
            if self._iteration >= self.config.max_iterations:
                self._state = OrchestratorState.ERROR
                return OrchestratorResult(
                    success=False,
                    output=last_content,
                    iterations=self._iteration,
                    total_tokens=self._total_tokens,
                    artifacts=context.artifacts,
                    error="Max iterations reached",
                    adaptive_memory_metrics=self._adaptive_memory_metrics,
                    input_tokens=self._input_tokens,
                    output_tokens=self._output_tokens,
                    cache_creation_tokens=self._cache_creation_tokens,
                    cache_read_tokens=self._cache_read_tokens,
                    reasoning_tokens=self._reasoning_tokens,
                    generation_id=self._last_generation_id,
                )

            self._state = OrchestratorState.COMPLETED

            # Deferred build verification
            build_result = self._run_deferred_build(context)
            if build_result:
                build_output = build_result.get("output", "")
                if build_output:
                    if self._on_user_output:
                        self._on_user_output(f"\n🔨 Final build verification:\n{build_output}")
                    accumulated_output.append(build_output)

            # Self-correction loop: validate → analyze → fix
            correction_result: CorrectionResult | None = None
            if self.config.enable_self_correction and self._self_correction:
                changed_files = context.artifacts.get("changed_files", [])
                if changed_files:
                    correction_result = await self._run_self_correction(
                        changed_files=changed_files,
                        task_context=task,
                    )

            full_output = "\n\n".join(accumulated_output) if accumulated_output else last_content
            return OrchestratorResult(
                success=True,
                output=full_output,
                iterations=self._iteration,
                total_tokens=self._total_tokens,
                artifacts=context.artifacts,
                adaptive_memory_metrics=self._adaptive_memory_metrics,
                self_correction_result=correction_result,
                input_tokens=self._input_tokens,
                output_tokens=self._output_tokens,
                cache_creation_tokens=self._cache_creation_tokens,
                cache_read_tokens=self._cache_read_tokens,
                reasoning_tokens=self._reasoning_tokens,
                generation_id=self._last_generation_id,
            )

        except Exception as e:
            self._state = OrchestratorState.ERROR
            return OrchestratorResult(
                success=False,
                output=last_content,
                iterations=self._iteration,
                total_tokens=self._total_tokens,
                artifacts=context.artifacts,
                error=str(e),
                adaptive_memory_metrics=self._adaptive_memory_metrics,
                input_tokens=self._input_tokens,
                output_tokens=self._output_tokens,
                cache_creation_tokens=self._cache_creation_tokens,
                cache_read_tokens=self._cache_read_tokens,
                reasoning_tokens=self._reasoning_tokens,
                generation_id=self._last_generation_id,
            )

    async def _invoke_llm_async(self, context: ExtensionContext) -> LLMResponse:
        """
        Invoke the LLM asynchronously.

        Args:
            context: Extension context.

        Returns:
            LLM response.
        """
        messages = self._memory.get_messages_for_llm()

        for ext in self._extensions.values():
            if ext.enabled:
                messages = ext.on_input_messages(messages, context)

        if self.config.enable_streaming and self._on_user_output_stream:
            response = await self._llm.invoke_stream_async(
                messages=messages,
                system=self._system_prompt,
                on_text=self._handle_stream_chunk,
            )
        else:
            response = await self._llm.invoke_async(
                messages=messages,
                system=self._system_prompt,
            )

        # Update token tracking
        self._total_tokens += response.usage.get("total_tokens", 0)
        self._input_tokens += response.usage.get("input_tokens", 0)
        self._output_tokens += response.usage.get("output_tokens", 0)
        self._cache_creation_tokens += response.usage.get("cache_creation_input_tokens", 0)
        self._cache_read_tokens += response.usage.get("cache_read_input_tokens", 0)
        self._reasoning_tokens += response.usage.get("reasoning_tokens", 0)
        if response.generation_id:
            self._last_generation_id = response.generation_id

        for ext in self._extensions.values():
            if ext.enabled:
                response.content = ext.on_llm_output(response.content, context)

        return response

    async def _execute_actions_async(
        self,
        actions: list[Action],
        context: ExtensionContext,
        pre_action_text: str | None,
        preface_already_shown: bool,
    ) -> bool:
        """
        Execute multiple actions, potentially in parallel.

        Independent actions (different files, read-only operations) can run
        concurrently for better performance.

        Args:
            actions: List of actions to execute.
            context: Extension context.
            pre_action_text: Pre-action text for display.
            preface_already_shown: Whether preface was already shown.

        Returns:
            True if should continue, False if task complete or error.
        """
        if not actions:
            return True

        # Classify actions for potential parallelization
        parallel_safe = self._can_parallelize(actions)

        if parallel_safe and len(actions) > 1:
            # Execute in parallel
            tasks = [
                self._execute_action_async(action, context, pre_action_text if i == 0 else None, preface_already_shown)
                for i, action in enumerate(actions)
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    result = ExecutionResult.error_result(str(result))
                
                context.artifacts.update(result.artifacts)
                
                if result.metadata.get("task_complete") or not result.should_continue:
                    return False
        else:
            # Execute sequentially (default behavior)
            for action in actions:
                result = await self._execute_action_async(
                    action, context, pre_action_text, preface_already_shown
                )
                pre_action_text = None
                if preface_already_shown:
                    self._preface_emitted_for_iteration = True

                context.artifacts.update(result.artifacts)

                if result.metadata.get("task_complete") or not result.should_continue:
                    return False

        return True

    async def _execute_action_async(
        self,
        action: Action,
        context: ExtensionContext,
        pre_action_text: str | None = None,
        preface_already_shown: bool = False,
    ) -> ExecutionResult:
        """
        Execute a single action asynchronously.

        Args:
            action: Action to execute.
            context: Extension context.
            pre_action_text: Pre-action text for display.
            preface_already_shown: Whether preface was already shown.

        Returns:
            ExecutionResult from the extension.
        """
        extension = self._route_action(action)

        if extension is None:
            return ExecutionResult.error_result(
                f"No extension found to handle action: {action.name}"
            )

        try:
            suppress_preface = False
            if pre_action_text:
                suppress_preface = self._is_redundant_preface(pre_action_text)
            if pre_action_text and self._on_user_output and not preface_already_shown:
                if not suppress_preface:
                    self._on_user_output(pre_action_text)
                    self._preface_emitted_for_iteration = True
            if pre_action_text:
                self._suppress_next_post_tool_text = True

            start_time = time.time()
            result = await extension.execute_async(action, context)
            duration_ms = (time.time() - start_time) * 1000

            # Record tool invocation
            tool_use_id = action.id or f"tool_{action.name}_{int(time.time() * 1000)}"
            self._memory.add_tool_result(
                tool_use_id=tool_use_id,
                tool_name=action.name,
                input_params=action.input,
                output=result.output,
                success=result.success,
                duration_ms=duration_ms,
            )

            if result.user_output and self._on_user_output:
                self._on_user_output(result.user_output)

            return result

        except Exception as e:
            error_result = extension.on_error(e, context)
            if error_result:
                return error_result
            return ExecutionResult.error_result(str(e))

    def _can_parallelize(self, actions: list[Action]) -> bool:
        """
        Determine if a list of actions can be executed in parallel.

        Actions are safe to parallelize if they:
        - Are all read-only (file_read, grep, glob)
        - Don't write to the same file
        - Don't have dependencies on each other's output

        Args:
            actions: List of actions to check.

        Returns:
            True if actions can be safely parallelized.
        """
        if len(actions) <= 1:
            return False

        read_only_tools = {"file_read", "grep", "glob", "read_context"}
        write_tools = {"file_write", "file_edit", "bash"}

        # Check if all are read-only
        all_read_only = all(action.name in read_only_tools for action in actions)
        if all_read_only:
            return True

        # Check if any are write operations
        has_writes = any(action.name in write_tools for action in actions)
        if has_writes:
            # Check for conflicts (same file targets)
            file_targets = set()
            for action in actions:
                path = action.input.get("path") or action.input.get("file_path")
                if path and action.name in write_tools:
                    if path in file_targets:
                        return False  # Same file, can't parallelize
                    file_targets.add(path)
            return True

        return False
