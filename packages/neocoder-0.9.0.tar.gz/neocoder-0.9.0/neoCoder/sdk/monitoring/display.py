"""
Display formatting for monitoring information.
"""

from typing import Optional

from neoCoder.sdk.monitoring.models import ModelInfo, TokenUsage, UsagePercentages


class ModelInfoDisplay:
    """Formats and displays monitoring information."""
    
    def __init__(self, display_format: str = "tree"):
        """
        Initialize display formatter.
        
        Args:
            display_format: Display format ("tree" or "box")
        """
        self.display_format = display_format
    
    def format_model_info(self, model_info: ModelInfo) -> str:
        """
        Format model information for display.
        
        Args:
            model_info: Model information
            
        Returns:
            Formatted string
        """
        lines = [
            "\n📊 Model Information:",
            f"  ├─ Model:          {model_info.name}",
            f"  ├─ Context Limit:  {ModelInfoDisplay._format_number(model_info.max_context_tokens)} tokens",
            f"  └─ Output Limit:   {ModelInfoDisplay._format_number(model_info.max_output_tokens)} tokens",
        ]
        
        if model_info.reasoning_effort:
            # Replace last line's └─ with ├─ and add new lines
            lines[-1] = f"  ├─ Output Limit:   {ModelInfoDisplay._format_number(model_info.max_output_tokens)} tokens"
            lines.append(f"  ├─ Reasoning Effort: {model_info.reasoning_effort}")
            
            if model_info.reasoning_tokens:
                lines.append(f"  └─ Reasoning Tokens: {ModelInfoDisplay._format_number(model_info.reasoning_tokens)} tokens")
            else:
                lines[-1] = f"  └─ Reasoning Effort: {model_info.reasoning_effort}"
        elif model_info.reasoning_tokens:
            lines[-1] = f"  ├─ Output Limit:   {ModelInfoDisplay._format_number(model_info.max_output_tokens)} tokens"
            lines.append(f"  └─ Reasoning Tokens: {ModelInfoDisplay._format_number(model_info.reasoning_tokens)} tokens")
        
        return "\n".join(lines)
    
    def format_token_usage(
        self,
        usage: TokenUsage,
        percentages: UsagePercentages,
        model_info: ModelInfo
    ) -> str:
        """
        Format token usage with percentages.
        
        Args:
            usage: Token usage
            percentages: Usage percentages
            model_info: Model information
            
        Returns:
            Formatted string
        """
        if self.display_format == "box":
            return self._format_token_usage_box(usage, percentages, model_info)
        else:
            return self._format_token_usage_tree(usage, percentages, model_info)
    
    def _format_token_usage_tree(
        self,
        usage: TokenUsage,
        percentages: UsagePercentages,
        model_info: ModelInfo
    ) -> str:
        """Format token usage in tree style."""
        lines = [
            "\n📊 Token Usage:",
        ]
        
        # Context usage
        context_bar = self._format_progress_bar(
            percentages.context_percent,
            used_tokens=usage.context_tokens,
            max_tokens=model_info.max_context_tokens
        )
        context_line = (
            f"  ├─ Context:   {self._format_number(usage.context_tokens):>6} / "
            f"{self._format_number(model_info.max_context_tokens):>7} "
            f"({percentages.context_percent:>5.2f}%)  {context_bar}"
        )
        lines.append(context_line)
        
        # Output usage
        output_bar = self._format_progress_bar(percentages.output_percent)
        
        # Check if we need reasoning line
        has_reasoning = (
            percentages.reasoning_percent is not None 
            and model_info.reasoning_tokens 
            and usage.reasoning_tokens > 0
        )
        
        output_line = (
            f"  {'├' if has_reasoning else '└'}─ Output:    {self._format_number(usage.output_tokens):>6} / "
            f"{self._format_number(model_info.max_output_tokens):>7} "
            f"({percentages.output_percent:>5.2f}%)  {output_bar}"
        )
        lines.append(output_line)
        
        # Reasoning usage (if applicable)
        if has_reasoning:
            reasoning_bar = self._format_progress_bar(percentages.reasoning_percent)
            reasoning_line = (
                f"  └─ Reasoning: {self._format_number(usage.reasoning_tokens):>6} / "
                f"{self._format_number(model_info.reasoning_tokens):>7} "
                f"({percentages.reasoning_percent:>5.2f}%)  {reasoning_bar}"
            )
            lines.append(reasoning_line)
        
        return "\n".join(lines)
    
    def _format_token_usage_box(
        self,
        usage: TokenUsage,
        percentages: UsagePercentages,
        model_info: ModelInfo
    ) -> str:
        """Format token usage in box style."""
        # Calculate box width
        width = 60
        
        lines = [
            "╭" + "─" * (width - 2) + "╮",
            "│ Token Usage" + " " * (width - 14) + "│",
            "├" + "─" * (width - 2) + "┤",
        ]
        
        bar_width = 10
        bar_visual_width = bar_width + 2  # brackets + content
        
        # Context usage
        context_bar = self._format_progress_bar(
            percentages.context_percent, 
            bar_width,
            used_tokens=usage.context_tokens,
            max_tokens=model_info.max_context_tokens
        )
        context_text = (
            f"│ Context:   {self._format_number(usage.context_tokens):>6} / "
            f"{self._format_number(model_info.max_context_tokens):>7} "
            f"({percentages.context_percent:>5.2f}%) {context_bar}"
        )
        content_len = len(context_text) - len(context_bar) + bar_visual_width
        padding = width - content_len - 1
        context_text += " " * max(0, padding) + "│"
        lines.append(context_text)
        
        # Output usage
        output_bar = self._format_progress_bar(percentages.output_percent, bar_width)
        output_text = (
            f"│ Output:    {self._format_number(usage.output_tokens):>6} / "
            f"{self._format_number(model_info.max_output_tokens):>7} "
            f"({percentages.output_percent:>5.2f}%) {output_bar}"
        )
        content_len = len(output_text) - len(output_bar) + bar_visual_width
        padding = width - content_len - 1
        output_text += " " * max(0, padding) + "│"
        lines.append(output_text)
        
        # Reasoning usage (if applicable)
        if percentages.reasoning_percent is not None and model_info.reasoning_tokens and usage.reasoning_tokens > 0:
            reasoning_bar = self._format_progress_bar(percentages.reasoning_percent, bar_width)
            reasoning_text = (
                f"│ Reasoning: {self._format_number(usage.reasoning_tokens):>6} / "
                f"{self._format_number(model_info.reasoning_tokens):>7} "
                f"({percentages.reasoning_percent:>5.2f}%) {reasoning_bar}"
            )
            content_len = len(reasoning_text) - len(reasoning_bar) + bar_visual_width
            padding = width - content_len - 1
            reasoning_text += " " * max(0, padding) + "│"
            lines.append(reasoning_text)
        
        lines.append("╰" + "─" * (width - 2) + "╯")
        
        return "\n" + "\n".join(lines)
    
    def format_startup_banner(self, working_dir: str, model_info: ModelInfo) -> str:
        """
        Format complete startup banner.
        
        Args:
            working_dir: Current working directory
            model_info: Model information
            
        Returns:
            Formatted string
        """
        return f"Working directory: {working_dir}\n\n{self.format_model_info(model_info)}"
    
    def format_usage_update(self, usage: TokenUsage, percentages: UsagePercentages, model_info: ModelInfo) -> str:
        """
        Format usage update after request.
        
        Args:
            usage: Token usage
            percentages: Usage percentages
            model_info: Model information
            
        Returns:
            Formatted string
        """
        return self.format_token_usage(usage, percentages, model_info)
    
    @staticmethod
    def _format_progress_bar(
        percentage: float, 
        width: int = 10, 
        used_tokens: int = 0, 
        max_tokens: int = 0,
        threshold: int = 200000
    ) -> str:
        """
        Format a progress bar with two-color indication.
        
        Args:
            percentage: Percentage value (0-100)
            width: Width of the progress bar in characters
            used_tokens: Current token count
            max_tokens: Maximum token limit
            threshold: Token threshold for color change (default 200k)
            
        Returns:
            Progress bar string with gray for under threshold, orange for over
        """
        percentage = max(0, min(100, percentage))
        filled = int((percentage / 100) * width)
        if percentage > 0 and filled == 0:
            filled = 1
        empty = width - filled
        
        if max_tokens > threshold and used_tokens > 0:
            threshold_percent = (threshold / max_tokens) * 100
            threshold_chars = int((threshold_percent / 100) * width)
            
            if used_tokens <= threshold:
                gray_filled = filled
                orange_filled = 0
            else:
                gray_filled = min(threshold_chars, filled)
                orange_filled = filled - gray_filled
            
            gray_bar = '▓' * gray_filled
            orange_bar = '█' * orange_filled
            empty_bar = ' ' * empty
            return f"[{gray_bar}{orange_bar}{empty_bar}]"
        else:
            return f"[{'█' * filled}{' ' * empty}]"
    
    @staticmethod
    def _format_number(num: int) -> str:
        """
        Format a number with thousand separators.
        
        Args:
            num: Number to format
            
        Returns:
            Formatted string
        """
        return f"{num:,}"
