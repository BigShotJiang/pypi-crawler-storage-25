"""
Token usage tracker.
"""

import json
import logging
from typing import Optional

import aiohttp

from neoCoder.sdk.monitoring.models import ModelInfo, TokenUsage, UsagePercentages

logger = logging.getLogger(__name__)


class TokenTracker:
    """Tracks token usage across requests."""
    
    def __init__(self, api_key: str, api_timeout: int = 5, base_url: str = None):
        """
        Initialize the token tracker.
        
        Args:
            api_key: Zenmux API key
            api_timeout: API request timeout in seconds
            base_url: Base URL for API requests (loaded from settings if None)
        """
        self.api_key = api_key
        self.api_timeout = api_timeout
        self.current_usage = TokenUsage()
        
        # Resolve base URL from parameter or settings
        if base_url is None:
            try:
                from neoCoder.config import get_settings
                settings = get_settings()
                base_url = settings.agent_config.zenmux.base_url
            except Exception:
                base_url = "https://zenmux.ai/api/v1"
        
        self._base_url = base_url
    
    async def update_from_generation(self, generation_id: str) -> TokenUsage:
        """
        Fetch usage from generation API and update current usage.
        
        Args:
            generation_id: Generation ID from API response
            
        Returns:
            Updated TokenUsage object
            
        Raises:
            aiohttp.ClientError: If API request fails
        """
        try:
            usage_data = await self._fetch_generation_info(generation_id)
            
            self.current_usage = TokenUsage(
                context_tokens=usage_data.get("prompt_tokens", 0),
                output_tokens=usage_data.get("completion_tokens", 0),
                reasoning_tokens=usage_data.get("reasoning_tokens", 0),
                total_tokens=usage_data.get("total_tokens", 0)
            )
            
            return self.current_usage
            
        except Exception as e:
            logger.error(f"Error fetching generation info: {e}")
            # Return current usage without updating
            return self.current_usage
    
    def update_from_response(self, response_usage: dict) -> TokenUsage:
        """
        Update usage from response metadata (fallback method).
        
        Args:
            response_usage: Usage dict from API response
            
        Returns:
            Updated TokenUsage object
        """
        self.current_usage = TokenUsage(
            context_tokens=response_usage.get("prompt_tokens", 0),
            output_tokens=response_usage.get("completion_tokens", 0),
            reasoning_tokens=response_usage.get("reasoning_tokens", 0),
            total_tokens=response_usage.get("total_tokens", 0)
        )
        
        return self.current_usage
    
    def calculate_percentages(self, model_info: ModelInfo) -> UsagePercentages:
        """
        Calculate usage percentages relative to model limits.
        
        Args:
            model_info: Model information with limits
            
        Returns:
            UsagePercentages object
        """
        context_percent = (
            (self.current_usage.context_tokens / model_info.max_context_tokens) * 100
            if model_info.max_context_tokens > 0
            else 0.0
        )
        
        output_percent = (
            (self.current_usage.output_tokens / model_info.max_output_tokens) * 100
            if model_info.max_output_tokens > 0
            else 0.0
        )
        
        reasoning_percent = None
        if model_info.reasoning_tokens and self.current_usage.reasoning_tokens > 0:
            reasoning_percent = (
                (self.current_usage.reasoning_tokens / model_info.reasoning_tokens) * 100
            )
        
        return UsagePercentages(
            context_percent=context_percent,
            output_percent=output_percent,
            reasoning_percent=reasoning_percent
        )
    
    def reset(self):
        """Reset tracking for new session."""
        self.current_usage = TokenUsage()
    
    async def _fetch_generation_info(self, generation_id: str) -> dict:
        """
        Fetch generation info from Zenmux API.
        
        Args:
            generation_id: Generation ID
            
        Returns:
            Usage data dict
            
        Raises:
            aiohttp.ClientError: If API request fails
        """
        url = f"{self._base_url}/generation"
        params = {"id": generation_id}
        # Filter out None keys/values to avoid serialization errors with proxies
        headers = {k: v for k, v in {"Authorization": f"Bearer {self.api_key}"}.items() if k is not None and v is not None}
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url,
                params=params,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=self.api_timeout)
            ) as response:
                response.raise_for_status()
                # Read raw text and parse JSON manually to avoid
                # "Cannot serialize non-str key None" errors with proxies
                raw_text = await response.text()
                data = json.loads(raw_text)
                return data.get("usage", {})

