"""
Model information fetcher with caching.
"""

import asyncio
import json
import logging
import time
from typing import Dict, List, Optional

import aiohttp

from neoCoder.sdk.monitoring.models import ModelInfo

logger = logging.getLogger(__name__)


class ModelInfoFetcher:
    """Fetches and caches model information from Zenmux API."""
    
    def __init__(self, api_key: str, cache_ttl: int = 3600, api_timeout: int = 5, base_url: str = None):
        """
        Initialize the model info fetcher.
        
        Args:
            api_key: Zenmux API key
            cache_ttl: Cache time-to-live in seconds (default: 1 hour)
            api_timeout: API request timeout in seconds (default: 5)
            base_url: Base URL for API requests (loaded from settings if None)
        """
        self.api_key = api_key
        self.cache_ttl = cache_ttl
        self.api_timeout = api_timeout
        self._cache: Dict[str, ModelInfo] = {}
        self._cache_timestamps: Dict[str, float] = {}
        
        # Resolve base URL from parameter or settings
        if base_url is None:
            try:
                from neoCoder.config import get_settings
                settings = get_settings()
                base_url = settings.agent_config.zenmux.base_url
            except Exception:
                base_url = "https://zenmux.ai/api/v1"
        
        self._openai_base_url = base_url
        # Derive anthropic URL: insert /anthropic before the version path
        # e.g. https://zenmux.ai/api/v1 -> https://zenmux.ai/api/anthropic/v1
        if "/api/v" in base_url:
            self._anthropic_base_url = base_url.replace("/api/v", "/api/anthropic/v")
        else:
            self._anthropic_base_url = base_url.rstrip("/") + "/anthropic"
        
        # Path to local models cache
        import os
        self._models_cache_path = os.path.join(
            os.path.expanduser("~"),
            ".neoCoder",
            "models.json"
        )
    
    async def get_model_info(self, model_name: str, provider: Optional[str] = None) -> ModelInfo:
        """
        Get model information with caching.
        
        When using ZenMux, we use fallback values enriched with settings
        instead of calling the API (ZenMux doesn't expose /models endpoint).
        
        Args:
            model_name: Name of the model
            provider: Provider name ("openai" or "anthropic"), auto-detected if None
            
        Returns:
            ModelInfo object
        """
        # Auto-detect provider if not specified
        if provider is None:
            provider = self._detect_provider(model_name)
        
        # Check cache
        if self._is_cache_valid(model_name):
            logger.debug(f"Using cached model info for {model_name}")
            cached_info = self._cache[model_name]
            return self._enrich_with_settings(cached_info, provider)
        
        # If using ZenMux, skip API call and use settings-enriched fallback
        # ZenMux doesn't expose /models endpoint
        if self._is_zenmux_configured():
            logger.debug(f"Using settings-based fallback for {model_name} (ZenMux)")
            fallback = self._get_fallback_info(model_name, provider)
            enriched = self._enrich_with_settings(fallback, provider)
            self._cache[model_name] = enriched
            self._cache_timestamps[model_name] = time.time()
            return enriched
        
        # Fetch from native API (non-ZenMux)
        try:
            if provider == "openai":
                models = await self._fetch_openai_models()
            elif provider == "anthropic":
                models = await self._fetch_anthropic_models()
            else:
                raise ValueError(f"Invalid provider: {provider}")
            
            # Find the specific model
            for model in models:
                if model.name == model_name:
                    self._cache[model_name] = model
                    self._cache_timestamps[model_name] = time.time()
                    return self._enrich_with_settings(model, provider)
            
            # Model not found, return fallback
            logger.warning(f"Model {model_name} not found in API response, using fallback")
            fallback = self._get_fallback_info(model_name, provider)
            return self._enrich_with_settings(fallback, provider)
            
        except asyncio.TimeoutError:
            logger.warning(f"Timeout fetching model info for {model_name}, using fallback")
            fallback = self._get_fallback_info(model_name, provider)
            return self._enrich_with_settings(fallback, provider)
        except Exception as e:
            logger.warning(f"Error fetching model info for {model_name}: {e}, using fallback")
            fallback = self._get_fallback_info(model_name, provider)
            return self._enrich_with_settings(fallback, provider)
    
    def _is_zenmux_configured(self) -> bool:
        """Check if ZenMux is the configured provider."""
        return "zenmux" in self._openai_base_url.lower()
    
    def _enrich_with_settings(self, model_info: ModelInfo, provider: str) -> ModelInfo:
        """
        Enrich model info with settings from config.
        
        Args:
            model_info: Base model info
            provider: Provider name
            
        Returns:
            Enriched ModelInfo
        """
        try:
            from neoCoder.config import get_settings
            settings = get_settings()
            
            # Override max_output_tokens from settings if available
            if hasattr(settings.agent_config, 'zenmux') and settings.agent_config.zenmux.max_output_tokens:
                model_info.max_output_tokens = settings.agent_config.zenmux.max_output_tokens
            
            # Enrich Anthropic models with thinking settings
            if provider == "anthropic":
                if settings.agent_config.anthropic.thinking_enabled:
                    # Always use settings value for thinking-enabled models
                    # Priority: ZenMux max_output_tokens > Anthropic thinking_budget
                    if hasattr(settings.agent_config, 'zenmux') and settings.agent_config.zenmux.max_output_tokens:
                        model_info.reasoning_tokens = settings.agent_config.zenmux.max_output_tokens
                    elif not model_info.reasoning_tokens:
                        model_info.reasoning_tokens = settings.agent_config.anthropic.thinking_budget
                    
                    if not model_info.reasoning_effort:
                        model_info.reasoning_effort = "extended"
            
            # Enrich OpenAI models with reasoning settings from zenmux config
            elif provider == "openai":
                if settings.agent_config.zenmux.reasoning_enabled:
                    # Check if it's a reasoning model
                    is_reasoning = any(x in model_info.name.lower() for x in ["o1", "o3"])
                    if is_reasoning:
                        if not model_info.reasoning_tokens and settings.agent_config.zenmux.default_reasoning_max_tokens:
                            model_info.reasoning_tokens = settings.agent_config.zenmux.default_reasoning_max_tokens
                        if not model_info.reasoning_effort:
                            model_info.reasoning_effort = settings.agent_config.zenmux.default_reasoning_effort
        except Exception as e:
            logger.debug(f"Could not enrich with settings: {e}")
        
        return model_info
    
    async def _fetch_openai_models(self) -> List[ModelInfo]:
        """
        Fetch OpenAI models from Zenmux API.
        
        Returns:
            List of ModelInfo objects
        """
        url = f"{self._openai_base_url}/models"
        headers = {k: v for k, v in {"Authorization": f"Bearer {self.api_key}"}.items() if k is not None and v is not None}
        
        async with aiohttp.ClientSession() as session:
            async with session.get(
                url,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=self.api_timeout)
            ) as response:
                response.raise_for_status()
                # Read raw text and parse JSON manually to avoid
                # "Cannot serialize non-str key None" errors with proxies
                raw_text = await response.text()
                if not raw_text or not raw_text.strip():
                    logger.warning(f"Empty response from {url}, using fallback")
                    return []
                try:
                    data = json.loads(raw_text)
                except json.JSONDecodeError as json_err:
                    logger.warning(
                        f"Invalid JSON from {url} ({json_err}): "
                        f"{raw_text[:200]!r} — using fallback"
                    )
                    return []
                
                models = []
                for model_data in data.get("data", []):
                    model_info = ModelInfo(
                        name=model_data["id"],
                        max_context_tokens=model_data.get("context_window", 128000),
                        max_output_tokens=model_data.get("max_output_tokens", 4096),
                        provider="openai"
                    )
                    
                    # Add reasoning info if available
                    if "reasoning" in model_data and model_data["reasoning"].get("enabled"):
                        model_info.reasoning_tokens = model_data["reasoning"].get("max_tokens")
                    
                    models.append(model_info)
                
                return models
    
    def _load_models_from_cache(self) -> Optional[List[ModelInfo]]:
        """
        Load models from local cache file.
        
        Returns:
            List of ModelInfo objects or None if cache doesn't exist
        """
        try:
            import json
            import os
            
            if not os.path.exists(self._models_cache_path):
                return None
            
            with open(self._models_cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            models = []
            for model_data in data.get("data", []):
                # Only process Anthropic models
                if not model_data["id"].startswith("anthropic/"):
                    continue
                
                # Parse context_length
                context_length = model_data.get("context_length", 1000000)
                
                # Estimate max_output_tokens (not provided by API)
                # Based on Claude Code documentation: default 32K, max 64K
                max_output_tokens = 32000  # Default for most Anthropic models
                if "opus" in model_data["id"].lower():
                    max_output_tokens = 64000  # Opus can handle more
                elif "haiku" in model_data["id"].lower():
                    max_output_tokens = 16000  # Haiku is smaller but still capable
                
                model_info = ModelInfo(
                    name=model_data["id"],
                    max_context_tokens=context_length,
                    max_output_tokens=max_output_tokens,
                    provider="anthropic"
                )
                
                # Add reasoning/thinking info
                capabilities = model_data.get("capabilities", {})
                if capabilities.get("reasoning"):
                    model_info.reasoning_tokens = 10000
                    model_info.reasoning_effort = "extended"
                
                models.append(model_info)
            
            return models
        except Exception as e:
            logger.debug(f"Failed to load models from cache: {e}")
            return None
    
    async def _fetch_anthropic_models(self) -> List[ModelInfo]:
        """
        Fetch Anthropic models from Zenmux API.
        
        Returns:
            List of ModelInfo objects
        """
        url = f"{self._anthropic_base_url}/models"
        # Filter out None keys/values to avoid serialization errors with proxies
        headers = {k: v for k, v in {"x-api-key": self.api_key}.items() if k is not None and v is not None}
        
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    url,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=self.api_timeout)
                ) as response:
                    response.raise_for_status()
                    # Read raw text and parse JSON manually to avoid
                    # "Cannot serialize non-str key None" errors with proxies
                    raw_text = await response.text()
                    data = json.loads(raw_text)
                    
                    models = []
                    for model_data in data.get("data", []):
                        # Parse context_length (max_context_tokens)
                        context_length = model_data.get("context_length", 1000000)
                        
                        # Estimate max_output_tokens (not provided by API)
                        # Based on Claude Code documentation: default 32K, max 64K
                        max_output_tokens = 32000  # Default for most Anthropic models
                        if "opus" in model_data["id"].lower():
                            max_output_tokens = 64000  # Opus can handle more
                        elif "haiku" in model_data["id"].lower():
                            max_output_tokens = 16000  # Haiku is smaller but still capable
                        
                        model_info = ModelInfo(
                            name=model_data["id"],
                            max_context_tokens=context_length,
                            max_output_tokens=max_output_tokens,
                            provider="anthropic"
                        )
                        
                        # Add reasoning/thinking info if available
                        capabilities = model_data.get("capabilities", {})
                        if capabilities.get("reasoning"):
                            # Anthropic models with reasoning have extended thinking
                            model_info.reasoning_tokens = 10000  # Default thinking budget
                            model_info.reasoning_effort = "extended"
                        
                        models.append(model_info)
                    
                    return models
        except Exception as e:
            logger.warning(f"Failed to fetch Anthropic models from API: {e}, trying cache")
            # Try to load from cache
            cached_models = self._load_models_from_cache()
            if cached_models:
                logger.info(f"Loaded {len(cached_models)} Anthropic models from cache")
                return cached_models
            # If cache also fails, raise the original exception
            raise
    
    def _is_cache_valid(self, model_name: str) -> bool:
        """
        Check if cached data is still valid.
        
        Args:
            model_name: Name of the model
            
        Returns:
            True if cache is valid, False otherwise
        """
        if model_name not in self._cache:
            return False
        
        timestamp = self._cache_timestamps.get(model_name, 0)
        age = time.time() - timestamp
        return age < self.cache_ttl
    
    def _detect_provider(self, model_name: str) -> str:
        """
        Detect provider from model name.
        
        Args:
            model_name: Name of the model
            
        Returns:
            Provider name ("openai" or "anthropic")
        """
        model_lower = model_name.lower()
        
        if "claude" in model_lower or model_lower.startswith("anthropic/"):
            return "anthropic"
        elif any(prefix in model_lower for prefix in ["gpt", "o1", "o3", "openai/"]):
            return "openai"
        else:
            # Default to OpenAI
            return "openai"
    
    def _get_fallback_info(self, model_name: str, provider: str) -> ModelInfo:
        """
        Get fallback model info when API is unavailable.
        
        Args:
            model_name: Name of the model
            provider: Provider name
            
        Returns:
            ModelInfo with reasonable defaults
        """
        # Reasonable defaults based on provider
        if provider == "anthropic":
            # Check if it's a thinking-enabled model (Claude Opus 4, Sonnet 4)
            model_lower = model_name.lower()
            has_thinking = any(x in model_lower for x in ["opus-4", "sonnet-4", "claude-4"])
            
            # Determine max_output_tokens based on model type
            # Based on Claude Code documentation: default 32K, max 64K
            max_output_tokens = 32000  # Default
            if "opus" in model_lower:
                max_output_tokens = 64000
            elif "haiku" in model_lower:
                max_output_tokens = 16000
            
            model_info = ModelInfo(
                name=model_name,
                max_context_tokens=1000000,
                max_output_tokens=max_output_tokens,
                provider=provider
            )
            
            # Add thinking budget for thinking-enabled models
            if has_thinking:
                model_info.reasoning_tokens = 10000  # Default thinking budget
                model_info.reasoning_effort = "extended"
            
            return model_info
        else:  # openai
            model_lower = model_name.lower()
            is_o_series = any(x in model_lower for x in ["o1", "o3"])  # dedicated reasoning models
            is_gpt5 = "gpt-5" in model_lower                           # gpt-5.x with extended reasoning
            has_reasoning = is_o_series or is_gpt5

            return ModelInfo(
                name=model_name,
                max_context_tokens=1_050_000 if is_gpt5 else 128_000,
                max_output_tokens=131_072 if is_gpt5 else (100_000 if is_o_series else 16_384),
                reasoning_tokens=100_000 if has_reasoning else None,
                reasoning_effort="xhigh" if is_gpt5 else ("high" if is_o_series else None),
                provider=provider
            )
