"""
Architect Agent (F1) - Context compression and summarization.

The Architect agent is responsible for:
- Analyzing conversation history when context approaches limits
- Creating structured summaries that preserve essential information
- Replacing old messages with compressed summaries
- Maintaining a rolling window of recent messages

Based on Figure 4 from the neoCoder paper.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from neoCoder.sdk.llm.client_factory import create_client
from neoCoder.sdk.llm.client import ClaudeClientConfig
from neoCoder.sdk.memory.working import WorkingMemory, Message


@dataclass
class ArchitectConfig:
    """Configuration for the Architect agent."""

    # Model for summarization (can be smaller/faster than main agent)
    model: str = "claude-sonnet-4-6"
    max_tokens: int = 8192
    temperature: float = 0.0
    thinking_budget: int | None = None  # Disabled by default for faster summarization

    # API credentials (inherited from parent agent)
    api_key: str | None = None
    base_url: str | None = None
    use_zenmux_format: bool = False

    # Compression settings
    compression_threshold: float = 0.8  # Trigger at 80% of max tokens
    rolling_window_size: int = 10  # Keep last N messages uncompressed
    min_messages_to_compress: int = 5  # Don't compress fewer than this


ARCHITECT_SYSTEM_PROMPT = """You are the Architect, a specialized agent for summarizing conversation history.

Your task is to create a concise, structured summary of a conversation that preserves:

1. **Task Goals**: What the user wants to accomplish
2. **Current State**: Progress made so far
3. **Key Decisions**: Important choices and their rationale
4. **Critical Findings**: Important discoveries, errors, or insights
5. **Open TODOs**: Tasks that remain to be completed
6. **Important Context**: Any context needed for continuation

## Output Format

Provide your summary in this structure:

### Goals
[What the task is trying to achieve]

### Progress
[What has been accomplished]

### Decisions Made
[Key decisions and why]

### Findings
[Important discoveries or errors encountered]

### Next Steps
[What remains to be done]

### Context
[Any other important information]

Be concise but complete. The agent reading this summary should be able to continue the task effectively."""


@dataclass
class CompressionResult:
    """Result of a compression operation."""

    summary: str
    messages_compressed: int
    original_tokens: int
    compressed_tokens: int
    compression_ratio: float


class ArchitectAgent:
    """
    The Architect agent for context compression.

    Monitors context length and triggers summarization when needed.
    Creates structured summaries that preserve essential information
    while reducing token count.
    """

    def __init__(self, config: ArchitectConfig | None = None):
        """
        Initialize the Architect agent.

        Args:
            config: Architect configuration.
        """
        self.config = config or ArchitectConfig()

        # Initialize LLM client for summarization using factory
        self._llm = create_client(
            config=ClaudeClientConfig(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                thinking_budget=self.config.thinking_budget,

                api_key=self.config.api_key,
                base_url=self.config.base_url,
                use_zenmux_format=self.config.use_zenmux_format,
            )
        )

    def should_compress(self, memory: WorkingMemory, max_tokens: int) -> bool:
        """
        Check if compression should be triggered.

        Args:
            memory: Current working memory.
            max_tokens: Maximum allowed tokens.

        Returns:
            True if compression should be triggered.
        """
        # Check token threshold
        threshold = int(max_tokens * self.config.compression_threshold)
        if memory._total_tokens < threshold:
            return False

        # Check if enough messages to compress
        candidates = self._get_compression_candidates(memory)
        if len(candidates) < self.config.min_messages_to_compress:
            return False

        return True

    def _get_compression_candidates(self, memory: WorkingMemory) -> list[Message]:
        """
        Get messages that can be compressed.

        Excludes the rolling window of recent messages.
        """
        messages = memory.messages
        window_size = self.config.rolling_window_size

        if len(messages) <= window_size:
            return []

        return messages[:-window_size]

    def _format_messages_for_summary(self, messages: list[Message]) -> str:
        """Format messages into text for summarization."""
        formatted = []

        for msg in messages:
            role = msg.role.upper()
            content = msg.content

            if isinstance(content, list):
                # Handle tool use/result blocks
                parts = []
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            parts.append(block.get("text", ""))
                        elif block.get("type") == "tool_use":
                            parts.append(f"[Tool: {block.get('name')}]")
                        elif block.get("type") == "tool_result":
                            result = block.get("content", "")
                            if len(result) > 500:
                                result = result[:500] + "..."
                            parts.append(f"[Tool Result: {result}]")
                content = " ".join(parts)

            # Truncate very long messages
            if len(content) > 2000:
                content = content[:2000] + "... [truncated]"

            formatted.append(f"{role}: {content}")

        return "\n\n".join(formatted)

    def compress(self, memory: WorkingMemory) -> CompressionResult:
        """
        Compress conversation history.

        Args:
            memory: Working memory to compress.

        Returns:
            CompressionResult with summary and statistics.
        """
        candidates = self._get_compression_candidates(memory)

        if not candidates:
            return CompressionResult(
                summary="",
                messages_compressed=0,
                original_tokens=0,
                compressed_tokens=0,
                compression_ratio=1.0,
            )

        # Format messages for summarization
        messages_text = self._format_messages_for_summary(candidates)
        original_tokens = len(messages_text) // 4  # Rough estimate

        # Create summarization prompt
        summary_prompt = f"""Summarize the following conversation history.

CONVERSATION:
{messages_text}

Create a structured summary following the format in your instructions."""

        # Generate summary
        response = self._llm.invoke(
            messages=[{"role": "user", "content": summary_prompt}],
            system=ARCHITECT_SYSTEM_PROMPT,
        )

        summary = response.content
        compressed_tokens = len(summary) // 4

        # Apply compression to memory
        memory.apply_compression(
            summary=summary,
            compressed_count=len(candidates),
        )

        compression_ratio = compressed_tokens / original_tokens if original_tokens > 0 else 1.0

        return CompressionResult(
            summary=summary,
            messages_compressed=len(candidates),
            original_tokens=original_tokens,
            compressed_tokens=compressed_tokens,
            compression_ratio=compression_ratio,
        )

    def create_plan_summary(
        self,
        task: str,
        progress: list[str],
        errors: list[str],
        next_steps: list[str],
    ) -> str:
        """
        Create a plan summary for context injection.

        This is used to create structured summaries at specific points,
        not just for compression.

        Args:
            task: The original task.
            progress: List of completed steps.
            errors: List of errors encountered.
            next_steps: List of planned next steps.

        Returns:
            Formatted plan summary.
        """
        summary_parts = [f"### Task\n{task}"]

        if progress:
            summary_parts.append("### Progress\n" + "\n".join(f"- {p}" for p in progress))

        if errors:
            summary_parts.append("### Errors Encountered\n" + "\n".join(f"- {e}" for e in errors))

        if next_steps:
            summary_parts.append("### Next Steps\n" + "\n".join(f"- {s}" for s in next_steps))

        return "\n\n".join(summary_parts)
