"""
Self-Correction Manager.

Orchestrates the validation → analysis → fix loop.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import Any, Callable, TYPE_CHECKING

from neoCoder.sdk.self_correction.models import (
    ValidationError,
    ValidationResult,
    AnalysisResult,
    FixAction,
    CorrectionResult,
    SelfCorrectionConfig,
)
from neoCoder.sdk.self_correction.validators import ValidationRunner
from neoCoder.sdk.self_correction.analyzer import ErrorAnalyzer

if TYPE_CHECKING:
    from neoCoder.sdk.llm.base_client import BaseLLMClient

logger = logging.getLogger(__name__)


class SelfCorrectionManager:
    """
    Manages the self-correction loop: validate → analyze → fix → re-validate.
    
    Features:
    - Configurable validation (tests, lint, build, typecheck)
    - LLM-powered error analysis with extended thinking support
    - Bounded iterations to prevent infinite loops
    - File edit integration for applying fixes
    - Detailed logging and metrics
    
    Usage:
        manager = SelfCorrectionManager(
            working_dir=".",
            llm_client=client,
            config=SelfCorrectionConfig(max_iterations=2),
        )
        
        result = await manager.run_correction_loop(
            changed_files=["src/main.py"],
            task_context="Add user authentication",
        )
        
        if result.success:
            print(f"Fixed {result.errors_fixed} errors!")
        else:
            print(f"Remaining: {len(result.errors_remaining)} errors")
    """
    
    def __init__(
        self,
        working_dir: str,
        llm_client: BaseLLMClient | None = None,
        llm_invoke: Callable[..., Any] | None = None,
        file_edit_fn: Callable[[str, str, str], bool] | None = None,
        config: SelfCorrectionConfig | None = None,
        on_status: Callable[[str], None] | None = None,
    ):
        """
        Initialize self-correction manager.
        
        Args:
            working_dir: Project working directory
            llm_client: LLM client for analysis (uses invoke_async)
            llm_invoke: Alternative: direct async invoke function
            file_edit_fn: Function to edit files: (path, old_code, new_code) -> success
            config: Self-correction configuration
            on_status: Callback for status updates
        """
        self.working_dir = Path(working_dir)
        self.config = config or SelfCorrectionConfig()
        self.on_status = on_status or (lambda x: None)
        
        # LLM invoke function
        if llm_invoke:
            self._llm_invoke = llm_invoke
        elif llm_client:
            self._llm_invoke = llm_client.invoke_stream_async
        else:
            raise ValueError("Either llm_client or llm_invoke must be provided")
        
        # File edit function (default: simple file write)
        self._file_edit_fn = file_edit_fn or self._default_file_edit
        
        # Initialize components
        self._validator = ValidationRunner(
            working_dir=str(self.working_dir),
            config=self.config,
        )
        
        self._analyzer = ErrorAnalyzer(
            llm_invoke=self._llm_invoke,
            config=self.config,
            working_dir=str(self.working_dir),
        )
        
        # Metrics tracking
        self._correction_history: list[dict[str, Any]] = []
    
    async def run_correction_loop(
        self,
        changed_files: list[str],
        task_context: str,
    ) -> CorrectionResult:
        """
        Run the main correction loop.
        
        Args:
            changed_files: List of files that were changed
            task_context: Original task description for context
            
        Returns:
            CorrectionResult with success status and details
        """
        if not self.config.enabled:
            return CorrectionResult(success=True, iterations=0)
        
        start_time = time.time()
        iteration = 0
        total_fixed = 0
        all_fixes_applied: list[FixAction] = []
        validation_history: list[ValidationResult] = []
        
        files_str = ", ".join(changed_files[:3])
        if len(changed_files) > 3:
            files_str += f" (+{len(changed_files) - 3} more)"
        self.on_status(f"🔍 Starting self-correction loop for: {files_str}")
        
        while iteration < self.config.max_iterations:
            iteration += 1
            self.on_status(f"📋 Iteration {iteration}/{self.config.max_iterations}")
            
            # Step 1: VALIDATE
            validators = self._validator.get_validators()
            validator_names = ", ".join(v.type.value for v in validators if v.enabled)
            self.on_status(f"  ▶ Running validators: {validator_names or 'none configured'}")
            
            validation_result = await self._validator.run_all(
                changed_files=changed_files if self.config.only_validate_changed_files else None,
            )
            validation_history.append(validation_result)
            
            # Check if passed
            if validation_result.success:
                duration_sec = validation_result.duration_ms / 1000
                self.on_status(f"  ✅ All validators passed! ({duration_sec:.1f}s)")
                break
            
            self.on_status(
                f"  ❌ Found {validation_result.error_count} error(s), "
                f"{validation_result.warning_count} warning(s)"
            )
            
            # Step 2: ANALYZE
            self.on_status("  ▶ Analyzing errors...")
            analysis = await self._analyzer.analyze(
                errors=validation_result.errors,
                changed_files=changed_files,
                task_context=task_context,
            )
            
            if not analysis.has_fixes:
                self.on_status("  ⚠️ No fixes identified")
                break
            
            self.on_status(
                f"  📝 Identified {len(analysis.root_causes)} root cause(s), "
                f"{len(analysis.fix_plan)} fix(es)"
            )
            
            # Step 3: APPLY FIXES
            self.on_status("  ▶ Applying fixes...")
            fixes_applied = await self._apply_fixes(
                analysis.fix_plan,
                task_context,
            )
            
            if fixes_applied == 0:
                self.on_status("  ⚠️ No fixes could be applied")
                break
            
            total_fixed += fixes_applied
            all_fixes_applied.extend(analysis.fix_plan[:fixes_applied])
            self.on_status(f"  ✓ Applied {fixes_applied} fix(es)")
            
            # Update changed files list with any new files
            for fix in analysis.fix_plan:
                if fix.file not in changed_files:
                    changed_files.append(fix.file)
        
        # Final validation
        final_result = validation_history[-1] if validation_history else None
        remaining_errors = final_result.errors if final_result else []
        
        total_duration = (time.time() - start_time) * 1000
        
        result = CorrectionResult(
            success=len(remaining_errors) == 0,
            iterations=iteration,
            errors_fixed=total_fixed,
            errors_remaining=remaining_errors,
            fixes_applied=all_fixes_applied,
            total_duration_ms=total_duration,
            validation_history=validation_history,
        )
        
        # Log summary
        self.on_status(result.summary())
        
        # Track for history
        self._correction_history.append({
            "timestamp": time.time(),
            "result": result.to_dict(),
            "task_context": task_context[:200],
        })
        
        return result
    
    async def _apply_fixes(
        self,
        fix_plan: list[FixAction],
        task_context: str,
    ) -> int:
        """
        Apply fixes from the fix plan.
        
        Args:
            fix_plan: List of fixes to apply
            task_context: Task context for fix generation
            
        Returns:
            Number of fixes successfully applied
        """
        applied_count = 0
        
        # Sort by confidence (high first)
        sorted_fixes = sorted(
            fix_plan,
            key=lambda f: {"high": 0, "medium": 1, "low": 2}.get(f.confidence, 1),
        )
        
        for fix in sorted_fixes:
            try:
                success = await self._apply_single_fix(fix, task_context)
                if success:
                    applied_count += 1
                    logger.info(f"Applied fix to {fix.file}: {fix.description[:50]}")
                else:
                    logger.warning(f"Failed to apply fix to {fix.file}")
            except Exception as e:
                logger.error(f"Error applying fix to {fix.file}: {e}")
        
        return applied_count
    
    async def _apply_single_fix(
        self,
        fix: FixAction,
        task_context: str,
    ) -> bool:
        """
        Apply a single fix action.
        
        Args:
            fix: Fix action to apply
            task_context: Task context
            
        Returns:
            True if fix was applied successfully
        """
        file_path = self.working_dir / fix.file
        
        # Handle different actions
        if fix.action == "create":
            # Create new file
            if fix.new_code:
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_text(fix.new_code, encoding="utf-8")
                return True
            return False
        
        if fix.action == "delete":
            # Delete file
            if file_path.exists():
                file_path.unlink()
                return True
            return False
        
        # For modify/add, need file content
        if not file_path.exists():
            logger.warning(f"File not found: {fix.file}")
            return False
        
        content = file_path.read_text(encoding="utf-8", errors="replace")
        
        # If we have old_code and new_code, use simple replacement
        if fix.old_code and fix.new_code:
            if fix.old_code in content:
                new_content = content.replace(fix.old_code, fix.new_code, 1)
                file_path.write_text(new_content, encoding="utf-8")
                return True
            else:
                logger.warning(f"Old code not found in {fix.file}")
                # Try using file edit function
                return self._file_edit_fn(str(file_path), fix.old_code, fix.new_code)
        
        # If we have line numbers but no exact code, generate fix
        if fix.line_start and fix.description:
            new_code = await self._analyzer.generate_fix(
                fix_action=fix,
                file_content=content,
                task_context=task_context,
            )
            
            if new_code:
                # Apply line-based fix
                lines = content.split("\n")
                start = fix.line_start - 1
                end = (fix.line_end or fix.line_start)
                
                if 0 <= start < len(lines):
                    new_lines = new_code.split("\n")
                    lines[start:end] = new_lines
                    file_path.write_text("\n".join(lines), encoding="utf-8")
                    return True
        
        # Fallback: try to use description-based edit
        if fix.description and fix.new_code:
            # Just append/insert the new code
            if fix.action == "add":
                file_path.write_text(content + "\n" + fix.new_code, encoding="utf-8")
                return True
        
        logger.warning(f"Could not apply fix: insufficient information")
        return False
    
    def _default_file_edit(
        self,
        file_path: str,
        old_code: str,
        new_code: str,
    ) -> bool:
        """
        Default file edit implementation using simple string replacement.
        
        Args:
            file_path: Path to file
            old_code: Code to replace
            new_code: New code
            
        Returns:
            True if edit was successful
        """
        try:
            path = Path(file_path)
            if not path.exists():
                return False
            
            content = path.read_text(encoding="utf-8", errors="replace")
            
            if old_code not in content:
                return False
            
            new_content = content.replace(old_code, new_code, 1)
            path.write_text(new_content, encoding="utf-8")
            return True
            
        except Exception as e:
            logger.error(f"File edit failed: {e}")
            return False
    
    async def validate_only(
        self,
        changed_files: list[str] | None = None,
    ) -> ValidationResult:
        """
        Run validation without correction loop.
        
        Useful for checking if fixes are needed before starting loop.
        
        Args:
            changed_files: Optional list of changed files
            
        Returns:
            Validation result
        """
        return await self._validator.run_all(changed_files=changed_files)
    
    def get_statistics(self) -> dict[str, Any]:
        """
        Get statistics about correction history.
        
        Returns:
            Dictionary with statistics
        """
        if not self._correction_history:
            return {
                "total_runs": 0,
                "success_rate": 0.0,
                "avg_iterations": 0.0,
                "avg_errors_fixed": 0.0,
            }
        
        total = len(self._correction_history)
        successful = sum(1 for h in self._correction_history if h["result"]["success"])
        
        return {
            "total_runs": total,
            "success_rate": successful / total if total > 0 else 0.0,
            "avg_iterations": sum(
                h["result"]["iterations"] for h in self._correction_history
            ) / total,
            "avg_errors_fixed": sum(
                h["result"]["errors_fixed"] for h in self._correction_history
            ) / total,
            "avg_duration_ms": sum(
                h["result"]["total_duration_ms"] for h in self._correction_history
            ) / total,
        }
    
    def clear_history(self) -> None:
        """Clear correction history."""
        self._correction_history.clear()
