"""
Self-Correction module for neoCoder.

Provides automated validation and fix loop:
  execute → validate → analyze → fix → re-validate

Key components:
- SelfCorrectionManager: Main orchestration of the correction loop
- ValidationRunner: Runs validators (tests, lint, build, typecheck)
- ErrorAnalyzer: LLM-powered analysis of validation errors
- Models: Data structures for errors, analysis results, etc.
"""

from neoCoder.sdk.self_correction.models import (
    ValidationError,
    ValidationResult,
    ValidationSeverity,
    AnalysisResult,
    FixAction,
    CorrectionResult,
    SelfCorrectionConfig,
)
from neoCoder.sdk.self_correction.validators import (
    ValidationRunner,
    ValidatorType,
)
from neoCoder.sdk.self_correction.analyzer import ErrorAnalyzer
from neoCoder.sdk.self_correction.manager import SelfCorrectionManager

__all__ = [
    # Models
    "ValidationError",
    "ValidationResult", 
    "ValidationSeverity",
    "AnalysisResult",
    "FixAction",
    "CorrectionResult",
    "SelfCorrectionConfig",
    # Components
    "ValidationRunner",
    "ValidatorType",
    "ErrorAnalyzer",
    "SelfCorrectionManager",
]
