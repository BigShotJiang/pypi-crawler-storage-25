"""
Data models for self-correction system.

Defines structures for validation errors, analysis results, and fix actions.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ValidationSeverity(str, Enum):
    """Severity level of a validation error."""
    
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class ValidatorType(str, Enum):
    """Type of validator that produced the error."""
    
    TEST = "test"
    LINT = "lint"
    BUILD = "build"
    TYPECHECK = "typecheck"
    CUSTOM = "custom"


@dataclass
class ValidationError:
    """
    A structured validation error from any validator.
    
    Attributes:
        source: Type of validator (test, lint, build, typecheck)
        file: Path to the file with the error
        line: Line number (if available)
        column: Column number (if available)
        message: Error message
        code: Error code (e.g., E501, TS2322, pytest assertion)
        severity: Error severity level
        context: Additional context (e.g., code snippet, test name)
        raw_output: Original raw output from validator
    """
    
    source: ValidatorType
    file: str
    message: str
    line: int | None = None
    column: int | None = None
    code: str | None = None
    severity: ValidationSeverity = ValidationSeverity.ERROR
    context: str | None = None
    raw_output: str | None = None
    
    def to_context_string(self) -> str:
        """Format error for LLM context."""
        loc = self.file
        if self.line:
            loc += f":{self.line}"
            if self.column:
                loc += f":{self.column}"
        
        code_part = f" [{self.code}]" if self.code else ""
        return f"[{self.source.value}]{code_part} {loc}: {self.message}"
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "source": self.source.value,
            "file": self.file,
            "line": self.line,
            "column": self.column,
            "message": self.message,
            "code": self.code,
            "severity": self.severity.value,
            "context": self.context,
        }


@dataclass
class ValidationResult:
    """
    Result of running validators.
    
    Attributes:
        success: True if all validators passed
        errors: List of validation errors
        warnings: List of validation warnings
        validators_run: Which validators were executed
        duration_ms: Total validation time in milliseconds
        raw_outputs: Raw outputs from each validator
    """
    
    success: bool
    errors: list[ValidationError] = field(default_factory=list)
    warnings: list[ValidationError] = field(default_factory=list)
    validators_run: list[ValidatorType] = field(default_factory=list)
    duration_ms: float = 0.0
    raw_outputs: dict[str, str] = field(default_factory=dict)
    
    @property
    def error_count(self) -> int:
        """Total number of errors."""
        return len(self.errors)
    
    @property
    def warning_count(self) -> int:
        """Total number of warnings."""
        return len(self.warnings)
    
    def get_errors_by_file(self) -> dict[str, list[ValidationError]]:
        """Group errors by file path."""
        by_file: dict[str, list[ValidationError]] = {}
        for error in self.errors:
            if error.file not in by_file:
                by_file[error.file] = []
            by_file[error.file].append(error)
        return by_file
    
    def get_errors_by_source(self) -> dict[ValidatorType, list[ValidationError]]:
        """Group errors by validator type."""
        by_source: dict[ValidatorType, list[ValidationError]] = {}
        for error in self.errors:
            if error.source not in by_source:
                by_source[error.source] = []
            by_source[error.source].append(error)
        return by_source


@dataclass
class FixAction:
    """
    A single fix action to apply.
    
    Attributes:
        file: File to modify
        action: Type of action (modify, add, delete, create)
        description: What to change
        confidence: Confidence level (high, medium, low)
        line_start: Starting line for the fix (if applicable)
        line_end: Ending line for the fix (if applicable)
        old_code: Code to replace (for verification)
        new_code: New code to insert
        related_errors: Which errors this fix addresses
    """
    
    file: str
    action: str  # modify, add, delete, create
    description: str
    confidence: str = "medium"  # high, medium, low
    line_start: int | None = None
    line_end: int | None = None
    old_code: str | None = None
    new_code: str | None = None
    related_errors: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "file": self.file,
            "action": self.action,
            "description": self.description,
            "confidence": self.confidence,
            "line_start": self.line_start,
            "line_end": self.line_end,
            "old_code": self.old_code,
            "new_code": self.new_code,
            "related_errors": self.related_errors,
        }


@dataclass
class AnalysisResult:
    """
    Result of LLM analysis of validation errors.
    
    Attributes:
        root_causes: Identified root causes of errors
        fix_plan: Ordered list of fix actions
        confidence: Overall confidence in the analysis (0-1)
        needs_more_context: Whether more context is needed
        context_requests: Files/info to gather if more context needed
        reasoning: LLM's reasoning process (for debugging)
    """
    
    root_causes: list[str] = field(default_factory=list)
    fix_plan: list[FixAction] = field(default_factory=list)
    confidence: float = 0.5
    needs_more_context: bool = False
    context_requests: list[str] = field(default_factory=list)
    reasoning: str | None = None
    
    @property
    def has_fixes(self) -> bool:
        """Whether any fixes were identified."""
        return len(self.fix_plan) > 0
    
    def get_high_confidence_fixes(self) -> list[FixAction]:
        """Get only high-confidence fixes."""
        return [f for f in self.fix_plan if f.confidence == "high"]


@dataclass
class CorrectionResult:
    """
    Result of the entire self-correction loop.
    
    Attributes:
        success: True if all errors were fixed
        iterations: Number of correction iterations performed
        errors_fixed: Number of errors that were fixed
        errors_remaining: Errors that could not be fixed
        fixes_applied: List of fixes that were applied
        total_duration_ms: Total time spent in correction loop
        validation_history: History of validation results
    """
    
    success: bool
    iterations: int = 0
    errors_fixed: int = 0
    errors_remaining: list[ValidationError] = field(default_factory=list)
    fixes_applied: list[FixAction] = field(default_factory=list)
    total_duration_ms: float = 0.0
    validation_history: list[ValidationResult] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "success": self.success,
            "iterations": self.iterations,
            "errors_fixed": self.errors_fixed,
            "errors_remaining": [e.to_dict() for e in self.errors_remaining],
            "fixes_applied": [f.to_dict() for f in self.fixes_applied],
            "total_duration_ms": self.total_duration_ms,
        }
    
    def summary(self) -> str:
        """Human-readable summary."""
        if self.success:
            return (
                f"✅ Self-correction succeeded: "
                f"{self.errors_fixed} error(s) fixed in {self.iterations} iteration(s)"
            )
        else:
            return (
                f"⚠️ Self-correction incomplete: "
                f"{self.errors_fixed} fixed, {len(self.errors_remaining)} remaining "
                f"after {self.iterations} iteration(s)"
            )


@dataclass
class SelfCorrectionConfig:
    """
    Configuration for self-correction behavior.
    
    Attributes:
        enabled: Whether self-correction is enabled
        max_iterations: Maximum correction iterations (1-2 recommended)
        run_tests: Run test validators
        run_lint: Run lint validators  
        run_build: Run build validators
        run_typecheck: Run typecheck validators
        test_command: Custom test command (auto-detect if None)
        lint_command: Custom lint command (auto-detect if None)
        build_command: Custom build command (auto-detect if None)
        typecheck_command: Custom typecheck command (auto-detect if None)
        max_errors_to_analyze: Limit errors sent to LLM
        use_extended_thinking: Use extended thinking for analysis
        stop_on_first_success: Stop after first successful validation
        timeout_per_validator: Timeout for each validator in seconds
    """
    
    enabled: bool = True
    max_iterations: int = 2
    
    # Validator toggles
    run_tests: bool = True
    run_lint: bool = True
    run_build: bool = True
    run_typecheck: bool = True
    
    # Custom commands (None = auto-detect)
    test_command: str | None = None
    lint_command: str | None = None
    build_command: str | None = None
    typecheck_command: str | None = None
    
    # Limits
    max_errors_to_analyze: int = 10
    max_files_context: int = 5
    timeout_per_validator: int = 120
    
    # Behavior
    use_extended_thinking: bool = True
    stop_on_first_success: bool = True
    only_validate_changed_files: bool = True
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "enabled": self.enabled,
            "max_iterations": self.max_iterations,
            "run_tests": self.run_tests,
            "run_lint": self.run_lint,
            "run_build": self.run_build,
            "run_typecheck": self.run_typecheck,
            "test_command": self.test_command,
            "lint_command": self.lint_command,
            "build_command": self.build_command,
            "typecheck_command": self.typecheck_command,
            "max_errors_to_analyze": self.max_errors_to_analyze,
            "use_extended_thinking": self.use_extended_thinking,
        }
