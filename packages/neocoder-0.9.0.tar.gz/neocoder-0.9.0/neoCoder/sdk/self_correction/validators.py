"""
Validation runners and output parsers.

Supports:
- pytest (Python tests)
- ruff/flake8/pylint (Python linting)
- mypy/pyright (Python type checking)
- npm test / jest / vitest (JS/TS tests)
- eslint / biome (JS/TS linting)
- tsc (TypeScript type checking)
- go test / go build / golint
- cargo test / cargo build / clippy (Rust)
- Generic build commands
"""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import re
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from neoCoder.sdk.self_correction.models import (
    ValidationError,
    ValidationResult,
    ValidationSeverity,
    ValidatorType,
    SelfCorrectionConfig,
)

logger = logging.getLogger(__name__)


@dataclass
class ValidatorCommand:
    """A validator command configuration."""
    
    type: ValidatorType
    command: str
    enabled: bool = True
    timeout: int = 120


class ValidationRunner:
    """
    Runs validators and parses their output.
    
    Features:
    - Auto-detection of project type and appropriate validators
    - Parallel execution of independent validators
    - Structured error parsing for multiple tools
    - Cross-platform support (Windows/Unix)
    """
    
    def __init__(
        self,
        working_dir: str,
        config: SelfCorrectionConfig | None = None,
    ):
        """
        Initialize validation runner.
        
        Args:
            working_dir: Project working directory
            config: Self-correction configuration
        """
        self.working_dir = Path(working_dir)
        self.config = config or SelfCorrectionConfig()
        self.is_windows = platform.system() == "Windows"
        
        # Detected project info
        self._project_type: str | None = None
        self._validators: list[ValidatorCommand] = []
        self._tool_cache: dict[str, bool] = {}  # Cache for tool availability checks
        
    def detect_project_type(self) -> str:
        """
        Detect project type from files in working directory.
        
        Returns:
            Project type: 'python', 'node', 'java', 'csharp', 'unknown'
        """
        if self._project_type:
            return self._project_type
            
        # Check for project files
        files = set(os.listdir(self.working_dir))
        
        if "pyproject.toml" in files or "setup.py" in files or "requirements.txt" in files:
            self._project_type = "python"
        elif "package.json" in files:
            self._project_type = "node"
        elif "pom.xml" in files or "build.gradle" in files or "build.gradle.kts" in files:
            self._project_type = "java"
        elif any(f.endswith(".csproj") or f.endswith(".sln") for f in files):
            self._project_type = "csharp"
        else:
            self._project_type = "unknown"
            
        logger.info(f"Detected project type: {self._project_type}")
        return self._project_type
    
    def _is_tool_available(self, tool: str) -> bool:
        """
        Check if a tool is available (installed and in PATH or as Python module).
        
        Args:
            tool: Tool name (e.g., 'pytest', 'ruff', 'npm', 'dotnet')
            
        Returns:
            True if tool is available
        """
        if tool in self._tool_cache:
            return self._tool_cache[tool]
        
        available = False
        
        try:
            if tool.startswith("python -m "):
                # Check Python module availability
                module = tool.replace("python -m ", "").split()[0]
                result = subprocess.run(
                    ["python", "-c", f"import {module}"],
                    capture_output=True,
                    cwd=str(self.working_dir),
                    timeout=10,
                )
                available = result.returncode == 0
            elif tool in ("npm", "npx", "node"):
                # Check npm/node
                cmd = "where" if self.is_windows else "which"
                result = subprocess.run(
                    [cmd, tool],
                    capture_output=True,
                    timeout=5,
                )
                available = result.returncode == 0
            elif tool == "dotnet":
                result = subprocess.run(
                    ["dotnet", "--version"],
                    capture_output=True,
                    timeout=5,
                )
                available = result.returncode == 0
            elif tool in ("mvn", "maven"):
                cmd = "where" if self.is_windows else "which"
                result = subprocess.run(
                    [cmd, "mvn"],
                    capture_output=True,
                    timeout=5,
                )
                available = result.returncode == 0
            elif tool in ("gradle", "gradlew"):
                # Check for gradlew in project
                gradlew = "gradlew.bat" if self.is_windows else "gradlew"
                if (self.working_dir / gradlew).exists():
                    available = True
                else:
                    cmd = "where" if self.is_windows else "which"
                    result = subprocess.run(
                        [cmd, "gradle"],
                        capture_output=True,
                        timeout=5,
                    )
                    available = result.returncode == 0
            else:
                # Generic check via which/where
                cmd = "where" if self.is_windows else "which"
                result = subprocess.run(
                    [cmd, tool],
                    capture_output=True,
                    timeout=5,
                )
                available = result.returncode == 0
        except Exception as e:
            logger.debug(f"Tool check failed for {tool}: {e}")
            available = False
        
        self._tool_cache[tool] = available
        if not available:
            logger.info(f"Tool '{tool}' is not available, skipping validator")
        return available
    
    def _is_python_module_available(self, module: str) -> bool:
        """Check if a Python module is importable."""
        return self._is_tool_available(f"python -m {module}")
    
    def get_validators(self) -> list[ValidatorCommand]:
        """
        Get list of validators to run based on project type and config.
        
        Returns:
            List of validator commands
        """
        if self._validators:
            return self._validators
            
        project_type = self.detect_project_type()
        validators: list[ValidatorCommand] = []
        
        if project_type == "python":
            validators = self._get_python_validators()
        elif project_type == "node":
            validators = self._get_node_validators()
        elif project_type == "java":
            validators = self._get_java_validators()
        elif project_type == "csharp":
            validators = self._get_csharp_validators()
        else:
            logger.warning(f"Unknown project type, using minimal validators")
            
        self._validators = validators
        return validators
    
    def _get_python_validators(self) -> list[ValidatorCommand]:
        """Get Python project validators with auto-detection."""
        validators: list[ValidatorCommand] = []
        
        # Tests - check for pytest, unittest, nose
        if self.config.run_tests:
            cmd = self.config.test_command or self._detect_python_test_cmd()
            if cmd:
                validators.append(ValidatorCommand(
                    type=ValidatorType.TEST,
                    command=cmd,
                    enabled=True,
                    timeout=self.config.timeout_per_validator,
                ))
        
        # Linting - check for ruff, flake8, pylint
        if self.config.run_lint:
            cmd = self.config.lint_command or self._detect_python_lint_cmd()
            if cmd:
                validators.append(ValidatorCommand(
                    type=ValidatorType.LINT,
                    command=cmd,
                    enabled=True,
                    timeout=60,
                ))
        
        # Type checking - check for mypy, pyright
        if self.config.run_typecheck:
            cmd = self.config.typecheck_command or self._detect_python_typecheck_cmd()
            if cmd:
                validators.append(ValidatorCommand(
                    type=ValidatorType.TYPECHECK,
                    command=cmd,
                    enabled=True,
                    timeout=120,
                ))
        
        # Build (for packages)
        if self.config.run_build:
            cmd = self.config.build_command or self._detect_python_build_cmd()
            if cmd:
                validators.append(ValidatorCommand(
                    type=ValidatorType.BUILD,
                    command=cmd,
                    enabled=True,
                    timeout=120,
                ))
        
        return validators
    
    def _get_node_validators(self) -> list[ValidatorCommand]:
        """Get Node.js project validators."""
        validators: list[ValidatorCommand] = []
        
        # Check if npm is available
        if not self._is_tool_available("npm"):
            logger.info("npm not available, skipping Node.js validators")
            return validators
        
        # Read package.json for scripts
        pkg_json = self.working_dir / "package.json"
        scripts: dict[str, str] = {}
        if pkg_json.exists():
            import json
            try:
                with open(pkg_json) as f:
                    pkg = json.load(f)
                    scripts = pkg.get("scripts", {})
            except Exception:
                pass
        
        # Tests
        if self.config.run_tests and "test" in scripts:
            cmd = self.config.test_command or "npm test"
            validators.append(ValidatorCommand(
                type=ValidatorType.TEST,
                command=cmd,
                enabled=True,
                timeout=self.config.timeout_per_validator,
            ))
        
        # Linting
        if self.config.run_lint:
            cmd = self.config.lint_command
            if not cmd:
                if "lint" in scripts:
                    cmd = "npm run lint"
                elif (self.working_dir / ".eslintrc.js").exists() or \
                     (self.working_dir / ".eslintrc.json").exists() or \
                     (self.working_dir / "eslint.config.js").exists() or \
                     (self.working_dir / "eslint.config.mjs").exists():
                    if self._is_tool_available("npx"):
                        cmd = "npx eslint ."
            if cmd:
                validators.append(ValidatorCommand(
                    type=ValidatorType.LINT,
                    command=cmd,
                    enabled=True,
                    timeout=60,
                ))
        
        # Type checking (TypeScript)
        if self.config.run_typecheck:
            cmd = self.config.typecheck_command
            if not cmd and (self.working_dir / "tsconfig.json").exists():
                if self._is_tool_available("npx"):
                    cmd = "npx tsc --noEmit"
            if cmd:
                validators.append(ValidatorCommand(
                    type=ValidatorType.TYPECHECK,
                    command=cmd,
                    enabled=True,
                    timeout=120,
                ))
        
        # Build
        if self.config.run_build and "build" in scripts:
            cmd = self.config.build_command or "npm run build"
            validators.append(ValidatorCommand(
                type=ValidatorType.BUILD,
                command=cmd,
                enabled=True,
                timeout=120,
            ))
        
        return validators
    
    def _get_java_validators(self) -> list[ValidatorCommand]:
        """Get Java/Kotlin project validators (Maven/Gradle)."""
        validators: list[ValidatorCommand] = []
        
        # Detect build tool
        files = set(os.listdir(self.working_dir))
        is_gradle = "build.gradle" in files or "build.gradle.kts" in files
        is_maven = "pom.xml" in files
        
        # Check if build tool is available
        if is_gradle and not self._is_tool_available("gradlew"):
            logger.info("Gradle project detected but gradlew/gradle not available")
            is_gradle = False
        if is_maven and not self._is_tool_available("mvn"):
            logger.info("Maven project detected but mvn not available")
            is_maven = False
        
        if not is_gradle and not is_maven:
            logger.info("No Java build tool available, skipping Java validators")
            return validators
        
        if self.config.run_tests:
            if self.config.test_command:
                cmd = self.config.test_command
            elif is_gradle:
                cmd = "./gradlew test" if not self.is_windows else "gradlew.bat test"
            else:
                cmd = "mvn test"
            validators.append(ValidatorCommand(
                type=ValidatorType.TEST,
                command=cmd,
                timeout=self.config.timeout_per_validator,
            ))
        
        if self.config.run_build:
            if self.config.build_command:
                cmd = self.config.build_command
            elif is_gradle:
                cmd = "./gradlew build -x test" if not self.is_windows else "gradlew.bat build -x test"
            else:
                cmd = "mvn compile -DskipTests"
            validators.append(ValidatorCommand(
                type=ValidatorType.BUILD,
                command=cmd,
                timeout=180,
            ))
        
        if self.config.run_lint:
            if self.config.lint_command:
                cmd = self.config.lint_command
            else:
                # Auto-detect configured linter
                cmd = self._detect_java_linter(is_gradle, is_maven)
            
            if cmd:
                validators.append(ValidatorCommand(
                    type=ValidatorType.LINT,
                    command=cmd,
                    timeout=120,
                ))
        
        return validators
    
    def _detect_java_linter(self, is_gradle: bool, is_maven: bool) -> str | None:
        """
        Detect which linter is configured in the Java project.
        
        Checks for: SpotBugs, Checkstyle, PMD (in order of preference).
        Returns None if no linter is configured.
        """
        if is_gradle:
            # Read build.gradle or build.gradle.kts
            gradle_file = self.working_dir / "build.gradle"
            if not gradle_file.exists():
                gradle_file = self.working_dir / "build.gradle.kts"
            
            if gradle_file.exists():
                try:
                    content = gradle_file.read_text(encoding="utf-8", errors="replace")
                    content_lower = content.lower()
                    
                    gradlew = "./gradlew" if not self.is_windows else "gradlew.bat"
                    
                    # Check for plugins (order: spotbugs, checkstyle, pmd)
                    if "spotbugs" in content_lower or "com.github.spotbugs" in content:
                        return f"{gradlew} spotbugsMain"
                    elif "checkstyle" in content_lower:
                        return f"{gradlew} checkstyleMain"
                    elif "pmd" in content_lower:
                        return f"{gradlew} pmdMain"
                except Exception:
                    pass
        
        elif is_maven:
            # Read pom.xml
            pom_file = self.working_dir / "pom.xml"
            if pom_file.exists():
                try:
                    content = pom_file.read_text(encoding="utf-8", errors="replace")
                    content_lower = content.lower()
                    
                    # Check for plugins (order: spotbugs, checkstyle, pmd)
                    if "spotbugs-maven-plugin" in content or "findbugs" in content_lower:
                        return "mvn spotbugs:check"
                    elif "maven-checkstyle-plugin" in content or "checkstyle" in content_lower:
                        return "mvn checkstyle:check"
                    elif "maven-pmd-plugin" in content or "<pmd>" in content_lower:
                        return "mvn pmd:check"
                except Exception:
                    pass
        
        # No linter detected
        logger.info("No Java linter configured in project (spotbugs/checkstyle/pmd)")
        return None
    
    def _get_csharp_validators(self) -> list[ValidatorCommand]:
        """Get C#/.NET project validators."""
        validators: list[ValidatorCommand] = []
        
        # Check if dotnet is available
        if not self._is_tool_available("dotnet"):
            logger.info("dotnet not available, skipping C# validators")
            return validators
        
        if self.config.run_tests:
            cmd = self.config.test_command or "dotnet test"
            validators.append(ValidatorCommand(
                type=ValidatorType.TEST,
                command=cmd,
                timeout=self.config.timeout_per_validator,
            ))
        
        if self.config.run_build:
            cmd = self.config.build_command or "dotnet build"
            validators.append(ValidatorCommand(
                type=ValidatorType.BUILD,
                command=cmd,
                timeout=180,
            ))
        
        if self.config.run_lint:
            cmd = self.config.lint_command or "dotnet format --verify-no-changes"
            validators.append(ValidatorCommand(
                type=ValidatorType.LINT,
                command=cmd,
                timeout=60,
            ))
        
        return validators
    
    def _detect_python_test_cmd(self) -> str | None:
        """Detect Python test command - checks for pytest, unittest."""
        # Check for pytest config or dependency
        has_pytest_config = (
            (self.working_dir / "pytest.ini").exists() or
            (self.working_dir / "conftest.py").exists() or
            self._has_pyproject_section("tool.pytest") or
            self._has_python_dependency("pytest") or
            (self.working_dir / "tests").exists()
        )
        
        if has_pytest_config:
            # Verify pytest is actually installed
            if self._is_python_module_available("pytest"):
                return "python -m pytest -v"
            else:
                logger.info("pytest configured but not installed")
        
        # No test framework detected
        logger.info("No Python test framework detected (pytest)")
        return None
    
    def _detect_python_lint_cmd(self) -> str | None:
        """Detect Python lint command - checks for ruff, flake8, pylint."""
        # Check for ruff (preferred - fast)
        has_ruff_config = (
            (self.working_dir / "ruff.toml").exists() or
            self._has_pyproject_section("tool.ruff") or
            self._has_python_dependency("ruff")
        )
        if has_ruff_config and self._is_python_module_available("ruff"):
            return "python -m ruff check ."
        
        # Check for flake8
        has_flake8_config = (
            (self.working_dir / ".flake8").exists() or
            self._has_python_dependency("flake8")
        )
        if has_flake8_config and self._is_python_module_available("flake8"):
            return "python -m flake8 ."
        
        # Check for pylint
        has_pylint_config = (
            (self.working_dir / ".pylintrc").exists() or
            (self.working_dir / "pylintrc").exists() or
            self._has_python_dependency("pylint")
        )
        if has_pylint_config and self._is_python_module_available("pylint"):
            return "python -m pylint --recursive=y ."
        
        # No linter detected
        logger.info("No Python linter detected (ruff/flake8/pylint)")
        return None
    
    def _detect_python_typecheck_cmd(self) -> str | None:
        """Detect Python type checking command - checks for mypy, pyright."""
        # Check for mypy
        has_mypy_config = (
            (self.working_dir / "mypy.ini").exists() or
            self._has_pyproject_section("tool.mypy") or
            self._has_python_dependency("mypy")
        )
        if has_mypy_config and self._is_python_module_available("mypy"):
            return "python -m mypy ."
        
        # Check for pyright (requires npx/npm)
        has_pyright_config = (
            (self.working_dir / "pyrightconfig.json").exists() or
            self._has_python_dependency("pyright")
        )
        if has_pyright_config and self._is_tool_available("npx"):
            return "npx pyright"
        
        # No type checker detected
        logger.info("No Python type checker detected (mypy/pyright)")
        return None
    
    def _detect_python_build_cmd(self) -> str | None:
        """Detect Python build command."""
        # Check for pyproject.toml with build-system
        if self._has_pyproject_section("build-system"):
            return "python -m build --no-isolation"
        
        # Check for setup.py
        if (self.working_dir / "setup.py").exists():
            return "python setup.py build"
        
        # No build system detected (probably not a package)
        return None
    
    def _has_pyproject_section(self, section: str) -> bool:
        """Check if pyproject.toml has a section."""
        pyproject = self.working_dir / "pyproject.toml"
        if not pyproject.exists():
            return False
        try:
            content = pyproject.read_text()
            return f"[{section}]" in content
        except Exception:
            return False
    
    def _has_python_dependency(self, package: str) -> bool:
        """Check if a Python package is in dependencies."""
        # Check pyproject.toml
        pyproject = self.working_dir / "pyproject.toml"
        if pyproject.exists():
            try:
                content = pyproject.read_text().lower()
                if package.lower() in content:
                    return True
            except Exception:
                pass
        
        # Check requirements.txt
        requirements = self.working_dir / "requirements.txt"
        if requirements.exists():
            try:
                content = requirements.read_text().lower()
                if package.lower() in content:
                    return True
            except Exception:
                pass
        
        # Check requirements-dev.txt
        requirements_dev = self.working_dir / "requirements-dev.txt"
        if requirements_dev.exists():
            try:
                content = requirements_dev.read_text().lower()
                if package.lower() in content:
                    return True
            except Exception:
                pass
        
        return False
    
    async def run_all(
        self,
        changed_files: list[str] | None = None,
    ) -> ValidationResult:
        """
        Run all configured validators.
        
        Args:
            changed_files: Optional list of changed files for targeted validation
            
        Returns:
            Combined validation result
        """
        start_time = time.time()
        validators = self.get_validators()
        
        if not validators:
            logger.warning("No validators configured")
            return ValidationResult(success=True, validators_run=[])
        
        # Run validators (could parallelize independent ones)
        all_errors: list[ValidationError] = []
        all_warnings: list[ValidationError] = []
        raw_outputs: dict[str, str] = {}
        validators_run: list[ValidatorType] = []
        
        for validator in validators:
            if not validator.enabled:
                continue
                
            logger.info(f"Running validator: {validator.type.value} ({validator.command})")
            validators_run.append(validator.type)
            
            try:
                output, return_code = await self._run_command(
                    validator.command,
                    timeout=validator.timeout,
                )
                raw_outputs[validator.type.value] = output
                
                # Parse errors from output
                errors, warnings = self._parse_output(
                    output=output,
                    validator_type=validator.type,
                    return_code=return_code,
                )
                
                all_errors.extend(errors)
                all_warnings.extend(warnings)
                
            except asyncio.TimeoutError:
                logger.warning(f"Validator {validator.type.value} timed out")
                all_errors.append(ValidationError(
                    source=validator.type,
                    file="<timeout>",
                    message=f"Validator timed out after {validator.timeout}s",
                    severity=ValidationSeverity.ERROR,
                ))
            except Exception as e:
                logger.error(f"Validator {validator.type.value} failed: {e}")
                all_errors.append(ValidationError(
                    source=validator.type,
                    file="<error>",
                    message=f"Validator execution failed: {str(e)}",
                    severity=ValidationSeverity.ERROR,
                ))
        
        duration_ms = (time.time() - start_time) * 1000
        
        return ValidationResult(
            success=len(all_errors) == 0,
            errors=all_errors,
            warnings=all_warnings,
            validators_run=validators_run,
            duration_ms=duration_ms,
            raw_outputs=raw_outputs,
        )
    
    async def _run_command(
        self,
        command: str,
        timeout: int = 120,
    ) -> tuple[str, int]:
        """
        Run a shell command asynchronously.
        
        Args:
            command: Command to run
            timeout: Timeout in seconds
            
        Returns:
            Tuple of (output, return_code)
        """
        if self.is_windows:
            # Use PowerShell on Windows
            process = await asyncio.create_subprocess_exec(
                "powershell", "-NoProfile", "-Command", command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=str(self.working_dir),
            )
        else:
            # Use bash on Unix
            process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=str(self.working_dir),
            )
        
        try:
            stdout, _ = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout,
            )
            output = stdout.decode("utf-8", errors="replace")
            return output, process.returncode or 0
        except asyncio.TimeoutError:
            process.kill()
            raise
    
    def _parse_output(
        self,
        output: str,
        validator_type: ValidatorType,
        return_code: int,
    ) -> tuple[list[ValidationError], list[ValidationError]]:
        """
        Parse validator output into structured errors.
        
        Args:
            output: Raw validator output
            validator_type: Type of validator
            return_code: Process return code
            
        Returns:
            Tuple of (errors, warnings)
        """
        if validator_type == ValidatorType.TEST:
            return self._parse_test_output(output, return_code)
        elif validator_type == ValidatorType.LINT:
            return self._parse_lint_output(output)
        elif validator_type == ValidatorType.TYPECHECK:
            return self._parse_typecheck_output(output)
        elif validator_type == ValidatorType.BUILD:
            return self._parse_build_output(output, return_code)
        else:
            return self._parse_generic_output(output, validator_type, return_code)
    
    def _parse_test_output(
        self,
        output: str,
        return_code: int,
    ) -> tuple[list[ValidationError], list[ValidationError]]:
        """Parse pytest/test output."""
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        
        if return_code == 0:
            return errors, warnings
        
        # pytest FAILED pattern: FAILED tests/test_foo.py::test_bar - AssertionError
        pytest_failed = re.findall(
            r'FAILED\s+([^\s:]+)::([^\s]+)\s*[-–]\s*(.+?)(?=\n|$)',
            output,
        )
        for file, test_name, message in pytest_failed:
            errors.append(ValidationError(
                source=ValidatorType.TEST,
                file=file,
                message=f"{test_name}: {message}",
                code=test_name,
                severity=ValidationSeverity.ERROR,
                context=test_name,
            ))
        
        # pytest ERROR pattern
        pytest_errors = re.findall(
            r'ERROR\s+([^\s:]+)(?:::([^\s]+))?\s*[-–]\s*(.+?)(?=\n|$)',
            output,
        )
        for file, test_name, message in pytest_errors:
            errors.append(ValidationError(
                source=ValidatorType.TEST,
                file=file,
                message=message,
                code=test_name or "ERROR",
                severity=ValidationSeverity.ERROR,
            ))
        
        # AssertionError with file:line
        assertion_errors = re.findall(
            r'([^\s:]+\.py):(\d+):\s*(?:in\s+\w+\s*)?AssertionError[:\s]*(.+)?',
            output,
        )
        for file, line, message in assertion_errors:
            errors.append(ValidationError(
                source=ValidatorType.TEST,
                file=file,
                line=int(line),
                message=f"AssertionError: {message or 'assertion failed'}",
                severity=ValidationSeverity.ERROR,
            ))
        
        # If no specific errors parsed but return code != 0
        if not errors and return_code != 0:
            # Extract summary line
            summary_match = re.search(
                r'(\d+)\s+failed',
                output,
                re.IGNORECASE,
            )
            if summary_match:
                errors.append(ValidationError(
                    source=ValidatorType.TEST,
                    file="<tests>",
                    message=f"{summary_match.group(1)} test(s) failed",
                    severity=ValidationSeverity.ERROR,
                    raw_output=output[-500:] if len(output) > 500 else output,
                ))
            else:
                errors.append(ValidationError(
                    source=ValidatorType.TEST,
                    file="<tests>",
                    message="Tests failed (unable to parse specific errors)",
                    severity=ValidationSeverity.ERROR,
                    raw_output=output[-500:] if len(output) > 500 else output,
                ))
        
        return errors, warnings
    
    def _parse_lint_output(
        self,
        output: str,
    ) -> tuple[list[ValidationError], list[ValidationError]]:
        """Parse lint output (ruff, flake8, eslint, etc.)."""
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        
        # Common pattern: file.py:10:5: E501 line too long
        # Or: file.py:10: E501 line too long
        lint_pattern = re.compile(
            r'^([^\s:]+):(\d+)(?::(\d+))?:\s*([A-Z]\d+)?\s*(.+)$',
            re.MULTILINE,
        )
        
        for match in lint_pattern.finditer(output):
            file = match.group(1)
            line = int(match.group(2))
            column = int(match.group(3)) if match.group(3) else None
            code = match.group(4)
            message = match.group(5).strip()
            
            # Determine severity
            severity = ValidationSeverity.ERROR
            if code:
                code_upper = code.upper()
                if code_upper.startswith("W") or "warning" in message.lower():
                    severity = ValidationSeverity.WARNING
            
            error = ValidationError(
                source=ValidatorType.LINT,
                file=file,
                line=line,
                column=column,
                message=message,
                code=code,
                severity=severity,
            )
            
            if severity == ValidationSeverity.WARNING:
                warnings.append(error)
            else:
                errors.append(error)
        
        return errors, warnings
    
    def _parse_typecheck_output(
        self,
        output: str,
    ) -> tuple[list[ValidationError], list[ValidationError]]:
        """Parse type checker output (mypy, tsc, pyright)."""
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        
        # mypy pattern: file.py:10: error: Incompatible types
        mypy_pattern = re.compile(
            r'^([^\s:]+):(\d+)(?::(\d+))?:\s*(error|warning|note):\s*(.+?)(?:\s+\[(\w+)\])?$',
            re.MULTILINE,
        )
        
        for match in mypy_pattern.finditer(output):
            file = match.group(1)
            line = int(match.group(2))
            column = int(match.group(3)) if match.group(3) else None
            level = match.group(4)
            message = match.group(5).strip()
            code = match.group(6)
            
            if level == "note":
                continue  # Skip notes
            
            severity = ValidationSeverity.WARNING if level == "warning" else ValidationSeverity.ERROR
            
            error = ValidationError(
                source=ValidatorType.TYPECHECK,
                file=file,
                line=line,
                column=column,
                message=message,
                code=code,
                severity=severity,
            )
            
            if severity == ValidationSeverity.WARNING:
                warnings.append(error)
            else:
                errors.append(error)
        
        # tsc pattern: file.ts(10,5): error TS2322: Type 'string' is not assignable
        tsc_pattern = re.compile(
            r'^([^\s(]+)\((\d+),(\d+)\):\s*(error|warning)\s+(TS\d+):\s*(.+)$',
            re.MULTILINE,
        )
        
        for match in tsc_pattern.finditer(output):
            file = match.group(1)
            line = int(match.group(2))
            column = int(match.group(3))
            level = match.group(4)
            code = match.group(5)
            message = match.group(6).strip()
            
            severity = ValidationSeverity.WARNING if level == "warning" else ValidationSeverity.ERROR
            
            error = ValidationError(
                source=ValidatorType.TYPECHECK,
                file=file,
                line=line,
                column=column,
                message=message,
                code=code,
                severity=severity,
            )
            
            if severity == ValidationSeverity.WARNING:
                warnings.append(error)
            else:
                errors.append(error)
        
        return errors, warnings
    
    def _parse_build_output(
        self,
        output: str,
        return_code: int,
    ) -> tuple[list[ValidationError], list[ValidationError]]:
        """Parse build output."""
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        
        if return_code == 0:
            return errors, warnings
        
        # Generic error patterns
        error_patterns = [
            # Python syntax/import errors
            (r'File "([^"]+)", line (\d+).*\n\s*(.+)\n(\s*\^+)?\n(\w+Error): (.+)', "python"),
            # GCC/Clang style
            (r'([^\s:]+):(\d+):(\d+): error: (.+)', "gcc"),
            # Java/Maven: [ERROR] /path/File.java:[10,5] error message
            (r'\[ERROR\]\s+([^\s:]+\.java):\[(\d+),(\d+)\]\s*(.+)', "java_maven"),
            # Java/Gradle: File.java:10: error: message
            (r'([^\s:]+\.java):(\d+):\s*error:\s*(.+)', "java_gradle"),
            # C#/dotnet: File.cs(10,5): error CS1234: message
            (r'([^\s(]+\.cs)\((\d+),(\d+)\):\s*error\s+(CS\d+):\s*(.+)', "csharp"),
            # C#/MSBuild: File.cs(10): error CS1234: message
            (r'([^\s(]+\.cs)\((\d+)\):\s*error\s+(CS\d+):\s*(.+)', "csharp_simple"),
        ]
        
        for pattern, style in error_patterns:
            for match in re.finditer(pattern, output, re.MULTILINE):
                if style == "python":
                    file = match.group(1)
                    line = int(match.group(2))
                    error_type = match.group(5)
                    message = match.group(6)
                    errors.append(ValidationError(
                        source=ValidatorType.BUILD,
                        file=file,
                        line=line,
                        message=f"{error_type}: {message}",
                        severity=ValidationSeverity.ERROR,
                    ))
                elif style == "gcc":
                    errors.append(ValidationError(
                        source=ValidatorType.BUILD,
                        file=match.group(1),
                        line=int(match.group(2)),
                        column=int(match.group(3)),
                        message=match.group(4),
                        severity=ValidationSeverity.ERROR,
                    ))
                elif style == "java_maven":
                    errors.append(ValidationError(
                        source=ValidatorType.BUILD,
                        file=match.group(1),
                        line=int(match.group(2)),
                        column=int(match.group(3)),
                        message=match.group(4),
                        severity=ValidationSeverity.ERROR,
                    ))
                elif style == "java_gradle":
                    errors.append(ValidationError(
                        source=ValidatorType.BUILD,
                        file=match.group(1),
                        line=int(match.group(2)),
                        message=match.group(3),
                        severity=ValidationSeverity.ERROR,
                    ))
                elif style == "csharp":
                    errors.append(ValidationError(
                        source=ValidatorType.BUILD,
                        file=match.group(1),
                        line=int(match.group(2)),
                        column=int(match.group(3)),
                        code=match.group(4),
                        message=match.group(5),
                        severity=ValidationSeverity.ERROR,
                    ))
                elif style == "csharp_simple":
                    errors.append(ValidationError(
                        source=ValidatorType.BUILD,
                        file=match.group(1),
                        line=int(match.group(2)),
                        code=match.group(3),
                        message=match.group(4),
                        severity=ValidationSeverity.ERROR,
                    ))
        
        # If no specific errors found
        if not errors and return_code != 0:
            errors.append(ValidationError(
                source=ValidatorType.BUILD,
                file="<build>",
                message="Build failed (unable to parse specific errors)",
                severity=ValidationSeverity.ERROR,
                raw_output=output[-1000:] if len(output) > 1000 else output,
            ))
        
        return errors, warnings
    
    def _parse_generic_output(
        self,
        output: str,
        validator_type: ValidatorType,
        return_code: int,
    ) -> tuple[list[ValidationError], list[ValidationError]]:
        """Parse generic validator output."""
        errors: list[ValidationError] = []
        warnings: list[ValidationError] = []
        
        if return_code != 0:
            errors.append(ValidationError(
                source=validator_type,
                file="<unknown>",
                message=f"Validator exited with code {return_code}",
                severity=ValidationSeverity.ERROR,
                raw_output=output[-1000:] if len(output) > 1000 else output,
            ))
        
        return errors, warnings
