"""
LLM-powered error analyzer.

Analyzes validation errors and generates fix plans using the LLM.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Callable

from neoCoder.sdk.self_correction.models import (
    ValidationError,
    AnalysisResult,
    FixAction,
    SelfCorrectionConfig,
)

logger = logging.getLogger(__name__)


# Prompt template for error analysis
ANALYSIS_PROMPT_TEMPLATE = """## Error Analysis Task

You are analyzing validation errors that occurred after code changes.
Your goal is to identify the root causes and provide a concrete fix plan.

### Original Task Context
{task_context}

### Validation Errors ({error_count} total)
{errors_text}

### Changed Files Content
{files_text}

## Instructions

1. **Identify Root Causes**: What exactly is wrong? Be specific, not generic.
   - Look at the actual code and error messages
   - Consider the relationship between files
   - Think about what the original task was trying to achieve

2. **Create Fix Plan**: Order fixes by priority (fix dependencies first).
   For each fix:
   - `file`: Which file to modify
   - `action`: "modify" | "add" | "delete" | "create"
   - `description`: Exact change to make (be specific!)
   - `confidence`: "high" | "medium" | "low"
   - `line_start`/`line_end`: Line range if applicable
   - `old_code`: Code to replace (for verification)
   - `new_code`: New code to insert

3. **Request More Context** if needed (only if truly necessary).

## Response Format

Respond with a JSON object:
```json
{{
  "root_causes": [
    "Specific cause 1",
    "Specific cause 2"
  ],
  "fix_plan": [
    {{
      "file": "path/to/file.py",
      "action": "modify",
      "description": "Change function return type from str to int",
      "confidence": "high",
      "line_start": 42,
      "line_end": 45,
      "old_code": "def foo() -> str:",
      "new_code": "def foo() -> int:",
      "related_errors": ["error 1 description"]
    }}
  ],
  "confidence": 0.85,
  "needs_more_context": false,
  "context_requests": []
}}
```

IMPORTANT:
- Be SPECIFIC in descriptions, not generic
- Include actual code in old_code/new_code when possible
- Only request context if absolutely necessary
- Fix root causes, not symptoms
"""


class ErrorAnalyzer:
    """
    Analyzes validation errors using LLM.
    
    Features:
    - Structured error analysis with root cause identification
    - Concrete fix plan generation with confidence levels
    - Context gathering when needed
    - Support for extended thinking for complex analysis
    """
    
    def __init__(
        self,
        llm_invoke: Callable[..., Any],
        config: SelfCorrectionConfig | None = None,
        working_dir: str | None = None,
    ):
        """
        Initialize error analyzer.
        
        Args:
            llm_invoke: Async function to invoke LLM. 
                        Should accept (messages, **kwargs) and return response with .content
            config: Self-correction configuration
            working_dir: Working directory for file reading
        """
        self.llm_invoke = llm_invoke
        self.config = config or SelfCorrectionConfig()
        self.working_dir = Path(working_dir) if working_dir else Path(".")
    
    async def analyze(
        self,
        errors: list[ValidationError],
        changed_files: list[str],
        task_context: str,
        additional_context: str | None = None,
    ) -> AnalysisResult:
        """
        Analyze validation errors and generate fix plan.
        
        Args:
            errors: List of validation errors
            changed_files: List of files that were changed
            task_context: Original task description/context
            additional_context: Extra context from previous analysis
            
        Returns:
            Analysis result with root causes and fix plan
        """
        # Limit errors to avoid context overflow
        errors_to_analyze = errors[:self.config.max_errors_to_analyze]
        
        # Format errors
        errors_text = self._format_errors(errors_to_analyze)
        
        # Read changed files content
        files_text = await self._read_files_content(
            changed_files[:self.config.max_files_context]
        )
        
        # Add additional context if provided
        full_task_context = task_context
        if additional_context:
            full_task_context += f"\n\n### Additional Context\n{additional_context}"
        
        # Build prompt
        prompt = ANALYSIS_PROMPT_TEMPLATE.format(
            task_context=full_task_context,
            error_count=len(errors_to_analyze),
            errors_text=errors_text,
            files_text=files_text,
        )
        
        # Invoke LLM
        try:
            response = await self.llm_invoke(
                messages=[{"role": "user", "content": prompt}],
                reasoning_effort="high" if self.config.use_extended_thinking else "low",
            )
            
            # Parse response
            return self._parse_response(response.content)
            
        except Exception as e:
            logger.error(f"Error analysis failed: {e}")
            return AnalysisResult(
                root_causes=[f"Analysis failed: {str(e)}"],
                fix_plan=[],
                confidence=0.0,
            )
    
    def _format_errors(self, errors: list[ValidationError]) -> str:
        """Format errors for the prompt."""
        if not errors:
            return "No errors to analyze."
        
        lines: list[str] = []
        for i, error in enumerate(errors, 1):
            lines.append(f"{i}. {error.to_context_string()}")
            if error.context:
                lines.append(f"   Context: {error.context}")
            if error.raw_output and len(error.raw_output) < 200:
                lines.append(f"   Raw: {error.raw_output}")
        
        return "\n".join(lines)
    
    async def _read_files_content(self, files: list[str]) -> str:
        """Read content of changed files."""
        if not files:
            return "No files provided."
        
        sections: list[str] = []
        
        for file_path in files:
            try:
                full_path = self.working_dir / file_path
                if full_path.exists() and full_path.is_file():
                    content = full_path.read_text(encoding="utf-8", errors="replace")
                    
                    # Add line numbers
                    numbered_lines = []
                    for i, line in enumerate(content.split("\n"), 1):
                        numbered_lines.append(f"{i:4d} | {line}")
                    numbered_content = "\n".join(numbered_lines)
                    
                    # Truncate if too long
                    if len(numbered_content) > 3000:
                        numbered_content = numbered_content[:3000] + "\n... (truncated)"
                    
                    sections.append(f"### {file_path}\n```\n{numbered_content}\n```")
                else:
                    sections.append(f"### {file_path}\n(file not found or not readable)")
                    
            except Exception as e:
                sections.append(f"### {file_path}\n(error reading: {e})")
        
        return "\n\n".join(sections)
    
    def _parse_response(self, content: str) -> AnalysisResult:
        """Parse LLM response into AnalysisResult."""
        # Try to extract JSON from response
        json_match = re.search(r'```json\s*(.*?)\s*```', content, re.DOTALL)
        
        if json_match:
            json_str = json_match.group(1)
        else:
            # Try to find raw JSON
            json_match = re.search(r'\{[\s\S]*\}', content)
            if json_match:
                json_str = json_match.group(0)
            else:
                logger.warning("Could not extract JSON from analysis response")
                return AnalysisResult(
                    root_causes=["Could not parse analysis response"],
                    reasoning=content,
                )
        
        try:
            data = json.loads(json_str)
            
            # Parse root causes
            root_causes = data.get("root_causes", [])
            if isinstance(root_causes, str):
                root_causes = [root_causes]
            
            # Parse fix plan
            fix_plan: list[FixAction] = []
            for fix_data in data.get("fix_plan", []):
                if isinstance(fix_data, dict):
                    fix_plan.append(FixAction(
                        file=fix_data.get("file", ""),
                        action=fix_data.get("action", "modify"),
                        description=fix_data.get("description", ""),
                        confidence=fix_data.get("confidence", "medium"),
                        line_start=fix_data.get("line_start"),
                        line_end=fix_data.get("line_end"),
                        old_code=fix_data.get("old_code"),
                        new_code=fix_data.get("new_code"),
                        related_errors=fix_data.get("related_errors", []),
                    ))
            
            return AnalysisResult(
                root_causes=root_causes,
                fix_plan=fix_plan,
                confidence=float(data.get("confidence", 0.5)),
                needs_more_context=data.get("needs_more_context", False),
                context_requests=data.get("context_requests", []),
                reasoning=content,
            )
            
        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse error: {e}")
            return AnalysisResult(
                root_causes=["JSON parse error in analysis response"],
                reasoning=content,
            )
    
    async def generate_fix(
        self,
        fix_action: FixAction,
        file_content: str,
        task_context: str,
    ) -> str | None:
        """
        Generate actual code fix for a FixAction.
        
        Used when fix_action doesn't have complete new_code.
        
        Args:
            fix_action: Fix action to generate code for
            file_content: Current file content
            task_context: Task context
            
        Returns:
            Generated code or None if failed
        """
        prompt = f"""## Code Fix Generation

### Task
{fix_action.description}

### File: {fix_action.file}
```
{file_content}
```

### Fix Details
- Action: {fix_action.action}
- Lines: {fix_action.line_start or 'N/A'} - {fix_action.line_end or 'N/A'}
- Old code: {fix_action.old_code or 'N/A'}

### Instructions
Generate the EXACT new code to replace the old code.
Return ONLY the new code, no explanations.
If modifying, return the complete modified section.

```
"""
        try:
            response = await self.llm_invoke(
                messages=[{"role": "user", "content": prompt}],
                reasoning_effort="low",  # Quick fix generation
            )
            
            # Extract code from response
            code_match = re.search(r'```(?:\w+)?\s*(.*?)\s*```', response.content, re.DOTALL)
            if code_match:
                return code_match.group(1)
            
            # Return raw content if no code block
            return response.content.strip()
            
        except Exception as e:
            logger.error(f"Fix generation failed: {e}")
            return None
