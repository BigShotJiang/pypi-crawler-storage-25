"""
Hierarchical Memory System for the neoCoder SDK.

Provides multi-level memory scopes:
- Session scope: Persistent across the entire session
- Entry scope: Per-task memory
- Runnable scope: Per-execution memory

The hierarchy allows efficient storage and retrieval of context
at different granularities, supporting long-running sessions
on industrial-scale codebases.
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Literal
from enum import Enum


class MemoryScope(Enum):
    """Scope levels for hierarchical memory."""

    SESSION = "session"  # Persistent across entire session
    ENTRY = "entry"  # Per-task/entry
    RUNNABLE = "runnable"  # Per-execution


@dataclass
class MemoryNode:
    """A node in the hierarchical memory tree."""

    id: str
    name: str
    scope: MemoryScope
    content: dict[str, Any] = field(default_factory=dict)
    children: list[MemoryNode] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    def add_child(self, child: MemoryNode) -> None:
        """Add a child node."""
        self.children.append(child)
        self.updated_at = datetime.now()

    def find_child(self, name: str) -> MemoryNode | None:
        """Find a child by name."""
        for child in self.children:
            if child.name == name:
                return child
        return None

    def get_or_create_child(self, name: str, scope: MemoryScope) -> MemoryNode:
        """Get existing child or create new one."""
        child = self.find_child(name)
        if child is None:
            child = MemoryNode(
                id=str(uuid.uuid4()),
                name=name,
                scope=scope,
            )
            self.add_child(child)
        return child

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "scope": self.scope.value,
            "content": self.content,
            "children": [c.to_dict() for c in self.children],
            "metadata": self.metadata,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> MemoryNode:
        """Deserialize from dictionary."""
        node = cls(
            id=data["id"],
            name=data["name"],
            scope=MemoryScope(data["scope"]),
            content=data.get("content", {}),
            metadata=data.get("metadata", {}),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
        )
        for child_data in data.get("children", []):
            node.children.append(cls.from_dict(child_data))
        return node


@dataclass
class HierarchicalMemoryConfig:
    """Configuration for hierarchical memory."""

    storage_dir: str | None = None  # Directory for persistence
    auto_persist: bool = True  # Automatically save changes
    max_depth: int = 5  # Maximum tree depth


class HierarchicalMemory:
    """
    Hierarchical memory manager.

    Organizes memory in a tree structure with configurable scopes.
    Supports persistence to disk for cross-session memory.

    Example structure:
    ```
    session_root/
    ├── instance_abc123/
    │   ├── analysis.md
    │   ├── implementation_summary.md
    │   └── errors/
    │       └── compilation_error_1.md
    └── instance_def456/
        └── solution.md
    ```
    """

    def __init__(self, config: HierarchicalMemoryConfig | None = None):
        """
        Initialize hierarchical memory.

        Args:
            config: Memory configuration.
        """
        self.config = config or HierarchicalMemoryConfig()

        # Create root node
        self._root = MemoryNode(
            id=str(uuid.uuid4()),
            name="root",
            scope=MemoryScope.SESSION,
        )

        # Current context path
        self._current_path: list[str] = []

        # Storage setup
        if self.config.storage_dir:
            self._storage_path = Path(self.config.storage_dir)
            self._storage_path.mkdir(parents=True, exist_ok=True)
            self._load_from_disk()

    @property
    def root(self) -> MemoryNode:
        """Get the root node."""
        return self._root

    def _get_node_at_path(self, path: list[str]) -> MemoryNode:
        """Get node at specified path, creating if needed."""
        current = self._root
        for name in path:
            current = current.get_or_create_child(name, MemoryScope.ENTRY)
        return current

    def set_context(self, path: list[str]) -> None:
        """
        Set the current context path.

        Args:
            path: Path components (e.g., ["instance_abc", "analysis"]).
        """
        self._current_path = path

    def get_context(self) -> list[str]:
        """Get current context path."""
        return self._current_path.copy()

    def store(
        self,
        key: str,
        value: Any,
        path: list[str] | None = None,
        scope: MemoryScope = MemoryScope.ENTRY,
    ) -> None:
        """
        Store a value in memory.

        Args:
            key: Key for the value.
            value: Value to store.
            path: Path to store at (default: current context).
            scope: Memory scope.
        """
        target_path = path if path is not None else self._current_path
        node = self._get_node_at_path(target_path)
        node.content[key] = value
        node.updated_at = datetime.now()

        if self.config.auto_persist:
            self._persist_to_disk()

    def retrieve(
        self,
        key: str,
        path: list[str] | None = None,
        default: Any = None,
    ) -> Any:
        """
        Retrieve a value from memory.

        Args:
            key: Key to retrieve.
            path: Path to retrieve from (default: current context).
            default: Default value if not found.

        Returns:
            Retrieved value or default.
        """
        target_path = path if path is not None else self._current_path
        node = self._get_node_at_path(target_path)
        return node.content.get(key, default)

    def create_entry(self, name: str, metadata: dict[str, Any] | None = None) -> str:
        """
        Create a new entry (task) in memory.

        Args:
            name: Name for the entry.
            metadata: Optional metadata.

        Returns:
            Entry ID.
        """
        entry_id = f"{name}_{uuid.uuid4().hex[:8]}"
        entry_node = MemoryNode(
            id=entry_id,
            name=entry_id,
            scope=MemoryScope.ENTRY,
            metadata=metadata or {},
        )
        self._root.add_child(entry_node)
        self._current_path = [entry_id]

        if self.config.auto_persist:
            self._persist_to_disk()

        return entry_id

    def create_runnable(self, entry_id: str, name: str) -> str:
        """
        Create a new runnable (execution) within an entry.

        Args:
            entry_id: Parent entry ID.
            name: Name for the runnable.

        Returns:
            Runnable ID.
        """
        runnable_id = f"{name}_{uuid.uuid4().hex[:8]}"
        entry_node = self._root.find_child(entry_id)

        if entry_node is None:
            raise ValueError(f"Entry not found: {entry_id}")

        runnable_node = MemoryNode(
            id=runnable_id,
            name=runnable_id,
            scope=MemoryScope.RUNNABLE,
        )
        entry_node.add_child(runnable_node)
        self._current_path = [entry_id, runnable_id]

        if self.config.auto_persist:
            self._persist_to_disk()

        return runnable_id

    def get_all_entries(self) -> list[dict[str, Any]]:
        """Get all entry nodes with their metadata."""
        return [
            {
                "id": child.id,
                "name": child.name,
                "metadata": child.metadata,
                "created_at": child.created_at.isoformat(),
                "children_count": len(child.children),
            }
            for child in self._root.children
            if child.scope == MemoryScope.ENTRY
        ]

    def get_tree_structure(self, max_depth: int | None = None) -> str:
        """
        Get a text representation of the memory tree.

        Args:
            max_depth: Maximum depth to display.

        Returns:
            Tree structure as string.
        """
        lines = []
        self._build_tree_lines(self._root, lines, "", max_depth or self.config.max_depth)
        return "\n".join(lines)

    def _build_tree_lines(
        self,
        node: MemoryNode,
        lines: list[str],
        prefix: str,
        max_depth: int,
        depth: int = 0,
    ) -> None:
        """Recursively build tree lines."""
        if depth > max_depth:
            return

        lines.append(f"{prefix}+-- {node.name}")

        for i, child in enumerate(node.children):
            is_last = i == len(node.children) - 1
            child_prefix = prefix + ("    " if is_last else "|   ")
            self._build_tree_lines(child, lines, child_prefix, max_depth, depth + 1)

    def _persist_to_disk(self) -> None:
        """Save memory to disk."""
        if not self.config.storage_dir:
            return

        data = self._root.to_dict()
        storage_file = self._storage_path / "memory.json"

        with open(storage_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def _load_from_disk(self) -> None:
        """Load memory from disk."""
        if not self.config.storage_dir:
            return

        storage_file = self._storage_path / "memory.json"

        if storage_file.exists():
            with open(storage_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self._root = MemoryNode.from_dict(data)

    def clear(self) -> None:
        """Clear all memory."""
        self._root = MemoryNode(
            id=str(uuid.uuid4()),
            name="root",
            scope=MemoryScope.SESSION,
        )
        self._current_path = []

        if self.config.auto_persist:
            self._persist_to_disk()

    def export_to_markdown(self, path: list[str] | None = None) -> str:
        """
        Export memory contents to markdown format.

        Args:
            path: Path to export (default: entire tree).

        Returns:
            Markdown formatted content.
        """
        if path:
            node = self._get_node_at_path(path)
        else:
            node = self._root

        return self._node_to_markdown(node, 0)

    def _node_to_markdown(self, node: MemoryNode, depth: int) -> str:
        """Convert node to markdown."""
        lines = []
        header = "#" * (depth + 1)

        lines.append(f"{header} {node.name}")
        lines.append(f"*Scope: {node.scope.value} | Updated: {node.updated_at}*")
        lines.append("")

        if node.content:
            for key, value in node.content.items():
                lines.append(f"**{key}:**")
                if isinstance(value, str):
                    lines.append(value)
                else:
                    lines.append(f"```json\n{json.dumps(value, indent=2)}\n```")
                lines.append("")

        for child in node.children:
            lines.append(self._node_to_markdown(child, depth + 1))

        return "\n".join(lines)
