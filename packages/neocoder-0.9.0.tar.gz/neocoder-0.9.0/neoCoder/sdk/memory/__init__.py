"""Memory management for agent context.

Memory System Architecture:
- WorkingMemory: Short-term message history and tool tracking
- HierarchicalMemory: Long-term persistent storage with scopes
- EpisodicMemory: Task episode storage and retrieval
- ProceduralMemory: Learned workflow patterns
- NotesStorage: Detailed knowledge notes
- CognitiveMemoryManager: Central coordinator

xMemory System (from "Beyond RAG" paper):
- SemanticMemory: Factual knowledge extraction (L2)
- ThemeManager: High-level theme organization (L3)
- HierarchicalRetriever: Top-down retrieval with expansion
- ConsolidationEngine: Sparsity-semantics optimization
- XMemoryIntegration: Bridge with CognitiveMemoryManager
"""

from neoCoder.sdk.memory.working import WorkingMemory, WorkingMemoryConfig
from neoCoder.sdk.memory.hierarchical import HierarchicalMemory, HierarchicalMemoryConfig, MemoryScope
from neoCoder.sdk.memory.notes import NotesStorage, NotesConfig, Note
from neoCoder.sdk.memory.episodic import Episode, EpisodicMemory, EpisodicMemoryConfig
from neoCoder.sdk.memory.procedural import (
    Procedure,
    ProceduralMemory,
    ProceduralMemoryConfig,
    ProcedureExtractor,
)
from neoCoder.sdk.memory.cognitive import CognitiveMemoryManager, CognitiveMemoryConfig

# xMemory imports (lazy import to avoid circular dependencies)
from neoCoder.sdk.memory.xmemory import (
    SemanticMemory,
    SemanticMemoryConfig,
    SemanticUnit,
    KnowledgeType,
    ThemeNode,
    ThemeManager,
    ThemeManagerConfig,
    HierarchicalRetriever,
    RetrieverConfig,
    RetrievalResult,
    ConsolidationEngine,
    ConsolidationConfig,
    XMemoryIntegration,
    XMemoryConfig,
    create_xmemory_integration,
)

__all__ = [
    # Working memory
    "WorkingMemory",
    "WorkingMemoryConfig",
    # Hierarchical memory
    "HierarchicalMemory",
    "HierarchicalMemoryConfig",
    "MemoryScope",
    # Notes
    "NotesStorage",
    "NotesConfig",
    "Note",
    # Episodic memory
    "Episode",
    "EpisodicMemory",
    "EpisodicMemoryConfig",
    # Procedural memory
    "Procedure",
    "ProceduralMemory",
    "ProceduralMemoryConfig",
    "ProcedureExtractor",
    # Cognitive manager
    "CognitiveMemoryManager",
    "CognitiveMemoryConfig",
    # xMemory - Semantic (L2)
    "SemanticMemory",
    "SemanticMemoryConfig",
    "SemanticUnit",
    "KnowledgeType",
    # xMemory - Themes (L3)
    "ThemeNode",
    "ThemeManager",
    "ThemeManagerConfig",
    # xMemory - Retrieval
    "HierarchicalRetriever",
    "RetrieverConfig",
    "RetrievalResult",
    # xMemory - Consolidation
    "ConsolidationEngine",
    "ConsolidationConfig",
    # xMemory - Integration
    "XMemoryIntegration",
    "XMemoryConfig",
    "create_xmemory_integration",
]
