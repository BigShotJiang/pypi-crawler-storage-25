"""
Procedural Memory for the neoCoder SDK.

Stores and retrieves learned procedures - reusable workflows and patterns
extracted from successful task episodes.

Key concepts:
- Procedure: A generalized "how to do X" pattern with steps
- Extraction: LLM-based pattern mining from similar episodes
- Matching: Find relevant procedures for new tasks

Based on cognitive architecture research on procedural/skill memory.
"""

from __future__ import annotations

import re
import time
import uuid
import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from neoCoder.sdk.memory.episodic import Episode, EpisodicMemory

logger = logging.getLogger(__name__)


@dataclass
class Procedure:
    """A learned procedure - generalized workflow pattern."""

    id: str
    name: str
    description: str
    steps: list[str]
    
    # Matching criteria
    tech_stack: list[str] = field(default_factory=list)
    task_types: list[str] = field(default_factory=list)  # coding, debug, refactor
    trigger_keywords: list[str] = field(default_factory=list)
    
    # Metadata
    source_episodes: list[str] = field(default_factory=list)  # Episode IDs used to extract
    created_at: float = field(default_factory=time.time)
    usage_count: int = 0
    success_rate: float = 1.0  # Updated based on feedback
    
    # Conventions and examples
    conventions: list[str] = field(default_factory=list)
    examples: list[dict[str, str]] = field(default_factory=list)  # {file, snippet}

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "name": self.name,
            "description": self.description,
            "steps": self.steps,
            "tech_stack": self.tech_stack,
            "task_types": self.task_types,
            "trigger_keywords": self.trigger_keywords,
            "source_episodes": self.source_episodes,
            "created_at": self.created_at,
            "usage_count": self.usage_count,
            "success_rate": self.success_rate,
            "conventions": self.conventions,
            "examples": self.examples,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Procedure:
        """Deserialize from dictionary."""
        return cls(
            id=data["id"],
            name=data["name"],
            description=data["description"],
            steps=data["steps"],
            tech_stack=data.get("tech_stack", []),
            task_types=data.get("task_types", []),
            trigger_keywords=data.get("trigger_keywords", []),
            source_episodes=data.get("source_episodes", []),
            created_at=data.get("created_at", time.time()),
            usage_count=data.get("usage_count", 0),
            success_rate=data.get("success_rate", 1.0),
            conventions=data.get("conventions", []),
            examples=data.get("examples", []),
        )

    def to_prompt_string(self) -> str:
        """Format procedure for injection into LLM prompt."""
        lines = [
            f"## Procedure: {self.name}",
            f"*{self.description}*",
            "",
            "### Steps:",
        ]
        
        for i, step in enumerate(self.steps, 1):
            lines.append(f"{i}. {step}")
        
        if self.conventions:
            lines.append("")
            lines.append("### Conventions:")
            for conv in self.conventions:
                lines.append(f"- {conv}")
        
        if self.examples:
            lines.append("")
            lines.append("### Examples:")
            for ex in self.examples[:2]:  # Limit examples
                lines.append(f"- `{ex.get('file', 'example')}`: {ex.get('snippet', '')[:100]}")
        
        return "\n".join(lines)

    def matches_task(self, task: str, tech_hints: list[str] | None = None) -> float:
        """
        Score how well this procedure matches a task.
        
        Returns:
            Score from 0.0 to 1.0
        """
        score = 0.0
        task_lower = task.lower()
        
        # Keyword matching (primary signal)
        keyword_matches = sum(
            1 for kw in self.trigger_keywords
            if kw.lower() in task_lower
        )
        if self.trigger_keywords:
            score += 0.4 * (keyword_matches / len(self.trigger_keywords))
        
        # Tech stack matching
        if tech_hints:
            tech_hints_lower = [t.lower() for t in tech_hints]
            tech_matches = sum(
                1 for t in self.tech_stack
                if t.lower() in tech_hints_lower
            )
            if self.tech_stack:
                score += 0.3 * (tech_matches / len(self.tech_stack))
        
        # Task type matching
        task_type_signals = {
            "debug": ["fix", "bug", "error", "issue", "debug"],
            "refactor": ["refactor", "clean", "optimize", "improve"],
            "coding": ["create", "add", "implement", "build", "write"],
        }
        for task_type in self.task_types:
            if task_type in task_type_signals:
                if any(sig in task_lower for sig in task_type_signals[task_type]):
                    score += 0.2
                    break
        
        # Boost by success rate
        score *= (0.5 + 0.5 * self.success_rate)
        
        return min(1.0, score)


@dataclass
class ProceduralMemoryConfig:
    """Configuration for procedural memory."""

    max_procedures: int = 50
    min_episodes_for_extraction: int = 2  # Min similar episodes to extract procedure
    extraction_similarity_threshold: float = 0.3
    retrieval_threshold: float = 0.25  # Min score to retrieve procedure
    max_retrieved: int = 2


class ProceduralMemory:
    """
    Procedural memory - stores and retrieves learned workflows.
    
    Can automatically extract procedures from clusters of similar
    successful episodes using LLM analysis.
    """

    def __init__(self, config: ProceduralMemoryConfig | None = None):
        """
        Initialize procedural memory.

        Args:
            config: Memory configuration.
        """
        self.config = config or ProceduralMemoryConfig()
        self._procedures: list[Procedure] = []
        
        # LLM callback for procedure extraction (set by orchestrator)
        self._llm_extract: Callable[[str], str] | None = None

    def set_llm_extractor(self, extractor: Callable[[str], str]) -> None:
        """
        Set the LLM callback for procedure extraction.

        Args:
            extractor: Function that takes a prompt and returns LLM response.
        """
        self._llm_extract = extractor

    def add_procedure(self, procedure: Procedure) -> None:
        """Add a procedure to memory."""
        # Check for duplicates by name
        existing = self.get_procedure_by_name(procedure.name)
        if existing:
            # Merge: update existing procedure
            self._merge_procedure(existing, procedure)
        else:
            self._procedures.append(procedure)
        
        # Prune if over limit
        if len(self._procedures) > self.config.max_procedures:
            # Remove lowest success rate procedures
            self._procedures.sort(key=lambda p: p.success_rate * p.usage_count, reverse=True)
            self._procedures = self._procedures[:self.config.max_procedures]

    def _merge_procedure(self, existing: Procedure, new: Procedure) -> None:
        """Merge new procedure info into existing."""
        # Add new source episodes
        for ep_id in new.source_episodes:
            if ep_id not in existing.source_episodes:
                existing.source_episodes.append(ep_id)
        
        # Merge steps if different (take longer version as more detailed)
        if len(new.steps) > len(existing.steps):
            existing.steps = new.steps
        
        # Merge keywords
        for kw in new.trigger_keywords:
            if kw not in existing.trigger_keywords:
                existing.trigger_keywords.append(kw)
        
        # Merge conventions
        for conv in new.conventions:
            if conv not in existing.conventions:
                existing.conventions.append(conv)

    def get_procedure_by_name(self, name: str) -> Procedure | None:
        """Get procedure by name."""
        name_lower = name.lower()
        for proc in self._procedures:
            if proc.name.lower() == name_lower:
                return proc
        return None

    def retrieve_for_task(
        self,
        task: str,
        tech_hints: list[str] | None = None,
        max_results: int | None = None,
    ) -> list[tuple[Procedure, float]]:
        """
        Retrieve procedures relevant to a task.

        Args:
            task: Task description.
            tech_hints: Technology hints (e.g., ["python", "django"]).
            max_results: Maximum procedures to return.

        Returns:
            List of (procedure, score) tuples, sorted by score.
        """
        if not self._procedures:
            return []

        max_results = max_results or self.config.max_retrieved
        
        scored: list[tuple[Procedure, float]] = []
        for proc in self._procedures:
            score = proc.matches_task(task, tech_hints)
            if score >= self.config.retrieval_threshold:
                scored.append((proc, score))
        
        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:max_results]

    def format_for_context(
        self,
        procedures: list[tuple[Procedure, float]],
        max_chars: int = 1500,
    ) -> str:
        """Format procedures for injection into context."""
        if not procedures:
            return ""

        lines = [
            "[Recommended Procedures]",
            "(These are generalized, proven workflows extracted from successful tasks.",
            "Prefer these over individual episodes when applicable.)",
            "",
        ]
        current_chars = sum(len(line) for line in lines)
        
        for proc, score in procedures:
            proc_str = proc.to_prompt_string()
            if current_chars + len(proc_str) > max_chars:
                break
            lines.append(proc_str)
            lines.append("")
            current_chars += len(proc_str)
            
            # Record usage
            proc.usage_count += 1

        return "\n".join(lines)

    def extract_from_episodes(
        self,
        episodes: list[Episode],
        force: bool = False,
    ) -> Procedure | None:
        """
        Extract a procedure from a cluster of similar episodes.

        Uses LLM to identify common patterns and generalize into a procedure.

        Args:
            episodes: List of similar successful episodes.
            force: Force extraction even if below threshold.

        Returns:
            Extracted Procedure, or None if extraction failed.
        """
        if not self._llm_extract:
            logger.warning("LLM extractor not set, cannot extract procedure")
            return None

        if len(episodes) < self.config.min_episodes_for_extraction and not force:
            logger.debug(f"Not enough episodes ({len(episodes)}) for extraction")
            return None

        # Filter to successful episodes only
        successful = [ep for ep in episodes if ep.outcome == "success"]
        if len(successful) < self.config.min_episodes_for_extraction and not force:
            return None

        # Build extraction prompt
        prompt = self._build_extraction_prompt(successful)
        
        try:
            response = self._llm_extract(prompt)
            procedure = self._parse_extraction_response(response, successful)
            
            if procedure:
                self.add_procedure(procedure)
                logger.info(f"Extracted procedure: {procedure.name}")
            
            return procedure
            
        except Exception as e:
            logger.error(f"Procedure extraction failed: {e}")
            return None

    def _build_extraction_prompt(self, episodes: list[Episode]) -> str:
        """Build the LLM prompt for procedure extraction."""
        episodes_text = []
        for i, ep in enumerate(episodes[:5], 1):  # Limit to 5 episodes
            ep_lines = [
                f"### Episode {i}",
                f"Task: {ep.task_description}",
                f"Summary: {ep.summary}",
            ]
            if ep.files_touched:
                ep_lines.append(f"Files: {', '.join(ep.files_touched[:5])}")
            if ep.key_decisions:
                ep_lines.append(f"Decisions: {'; '.join(ep.key_decisions[:3])}")
            episodes_text.append("\n".join(ep_lines))

        return f"""Analyze these similar successful task episodes and extract a reusable PROCEDURE.

{chr(10).join(episodes_text)}

---

Extract a generalized procedure that captures the common workflow pattern.

Respond in this EXACT format:
```
PROCEDURE_NAME: <short_name_with_underscores>
DESCRIPTION: <one line description>
TECH_STACK: <comma-separated technologies>
TASK_TYPES: <comma-separated: coding, debug, refactor>
TRIGGER_KEYWORDS: <comma-separated keywords that indicate this procedure applies>

STEPS:
1. <first step>
2. <second step>
...

CONVENTIONS:
- <convention 1>
- <convention 2>
```

Focus on:
- Generalizing specific details into reusable patterns
- Identifying the logical sequence of steps
- Capturing project-specific conventions
"""

    def _parse_extraction_response(
        self,
        response: str,
        source_episodes: list[Episode],
    ) -> Procedure | None:
        """Parse LLM response into a Procedure."""
        try:
            # Extract fields using regex
            name_match = re.search(r'PROCEDURE_NAME:\s*(.+)', response)
            desc_match = re.search(r'DESCRIPTION:\s*(.+)', response)
            tech_match = re.search(r'TECH_STACK:\s*(.+)', response)
            types_match = re.search(r'TASK_TYPES:\s*(.+)', response)
            keywords_match = re.search(r'TRIGGER_KEYWORDS:\s*(.+)', response)
            
            if not name_match or not desc_match:
                logger.warning("Could not parse procedure name/description")
                return None

            name = name_match.group(1).strip()
            description = desc_match.group(1).strip()
            
            tech_stack = []
            if tech_match:
                tech_stack = [t.strip() for t in tech_match.group(1).split(",")]
            
            task_types = []
            if types_match:
                task_types = [t.strip() for t in types_match.group(1).split(",")]
            
            trigger_keywords = []
            if keywords_match:
                trigger_keywords = [k.strip() for k in keywords_match.group(1).split(",")]

            # Extract steps
            steps = []
            steps_match = re.search(r'STEPS:\s*\n((?:\d+\.\s*.+\n?)+)', response)
            if steps_match:
                steps_text = steps_match.group(1)
                steps = re.findall(r'\d+\.\s*(.+)', steps_text)

            # Extract conventions
            conventions = []
            conv_match = re.search(r'CONVENTIONS:\s*\n((?:-\s*.+\n?)+)', response)
            if conv_match:
                conv_text = conv_match.group(1)
                conventions = re.findall(r'-\s*(.+)', conv_text)

            return Procedure(
                id=f"proc_{uuid.uuid4().hex[:8]}",
                name=name,
                description=description,
                steps=steps,
                tech_stack=tech_stack,
                task_types=task_types,
                trigger_keywords=trigger_keywords,
                source_episodes=[ep.id for ep in source_episodes],
                conventions=conventions,
            )

        except Exception as e:
            logger.error(f"Failed to parse procedure response: {e}")
            return None

    def record_outcome(self, procedure_id: str, success: bool) -> None:
        """
        Record the outcome when a procedure was used.

        Updates success_rate for future retrieval ranking.
        """
        for proc in self._procedures:
            if proc.id == procedure_id:
                # Exponential moving average
                alpha = 0.3
                outcome = 1.0 if success else 0.0
                proc.success_rate = alpha * outcome + (1 - alpha) * proc.success_rate
                break

    def get_all_procedures(self) -> list[Procedure]:
        """Get all stored procedures."""
        return self._procedures.copy()

    def clear(self) -> None:
        """Clear all procedures."""
        self._procedures.clear()

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "procedures": [p.to_dict() for p in self._procedures],
        }

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        config: ProceduralMemoryConfig | None = None,
    ) -> ProceduralMemory:
        """Deserialize from dictionary."""
        memory = cls(config=config)
        for proc_data in data.get("procedures", []):
            memory._procedures.append(Procedure.from_dict(proc_data))
        return memory


class ProcedureExtractor:
    """
    Automatic procedure extraction from episodic memory.
    
    Clusters similar episodes and extracts procedures from clusters.
    """

    def __init__(
        self,
        episodic_memory: EpisodicMemory,
        procedural_memory: ProceduralMemory,
    ):
        """
        Initialize extractor.

        Args:
            episodic_memory: Source of episodes.
            procedural_memory: Target for extracted procedures.
        """
        self.episodic = episodic_memory
        self.procedural = procedural_memory

    def find_episode_clusters(
        self,
        min_cluster_size: int = 2,
        similarity_threshold: float = 0.3,
    ) -> list[list[Episode]]:
        """
        Find clusters of similar episodes.

        Uses simple keyword-based clustering.
        """
        episodes = self.episodic.get_all_episodes()
        if len(episodes) < min_cluster_size:
            return []

        # Filter successful episodes
        successful = [ep for ep in episodes if ep.outcome == "success"]
        if len(successful) < min_cluster_size:
            return []

        clusters: list[list[Episode]] = []
        used: set[str] = set()

        for ep in successful:
            if ep.id in used:
                continue

            # Find similar episodes
            cluster = [ep]
            ep_keywords = self._extract_keywords(ep.task_description)

            for other in successful:
                if other.id == ep.id or other.id in used:
                    continue

                other_keywords = self._extract_keywords(other.task_description)
                similarity = self._keyword_similarity(ep_keywords, other_keywords)

                if similarity >= similarity_threshold:
                    cluster.append(other)

            if len(cluster) >= min_cluster_size:
                clusters.append(cluster)
                for c_ep in cluster:
                    used.add(c_ep.id)

        return clusters

    def _extract_keywords(self, text: str) -> set[str]:
        """Extract keywords from text."""
        text_lower = text.lower()
        words = re.findall(r'\b[a-z_][a-z0-9_]*\b', text_lower)
        
        stopwords = {
            "a", "an", "the", "is", "are", "was", "were", "be", "been",
            "have", "has", "had", "do", "does", "did", "will", "would",
            "to", "of", "in", "for", "on", "with", "at", "by", "from",
            "and", "but", "or", "if", "this", "that", "these", "those",
            "i", "me", "my", "we", "our", "you", "your", "it", "its",
        }
        
        return {w for w in words if w not in stopwords and len(w) > 2}

    def _keyword_similarity(self, kw1: set[str], kw2: set[str]) -> float:
        """Compute Jaccard similarity between keyword sets."""
        if not kw1 or not kw2:
            return 0.0
        intersection = kw1 & kw2
        union = kw1 | kw2
        return len(intersection) / len(union)

    def extract_all(self) -> list[Procedure]:
        """
        Find all episode clusters and extract procedures from them.

        Returns:
            List of newly extracted procedures.
        """
        clusters = self.find_episode_clusters()
        extracted: list[Procedure] = []

        for cluster in clusters:
            # Check if we already have a procedure from these episodes
            cluster_ids = {ep.id for ep in cluster}
            already_extracted = False
            
            for proc in self.procedural.get_all_procedures():
                if cluster_ids & set(proc.source_episodes):
                    already_extracted = True
                    break

            if not already_extracted:
                procedure = self.procedural.extract_from_episodes(cluster)
                if procedure:
                    extracted.append(procedure)

        return extracted

    def extract_for_tech_stack(
        self,
        tech_stack: list[str],
    ) -> list[Procedure]:
        """
        Extract procedures specific to a tech stack.

        Args:
            tech_stack: Technologies to filter by.

        Returns:
            Extracted procedures.
        """
        episodes = self.episodic.get_all_episodes()
        tech_lower = {t.lower() for t in tech_stack}

        # Filter episodes by tech stack (from tags)
        matching = [
            ep for ep in episodes
            if ep.outcome == "success" and
            any(t.lower() in tech_lower for t in ep.tags)
        ]

        if len(matching) < self.procedural.config.min_episodes_for_extraction:
            return []

        # Cluster and extract
        clusters = self._cluster_episodes(matching)
        extracted: list[Procedure] = []

        for cluster in clusters:
            procedure = self.procedural.extract_from_episodes(cluster)
            if procedure:
                extracted.append(procedure)

        return extracted

    def _cluster_episodes(self, episodes: list[Episode]) -> list[list[Episode]]:
        """Simple clustering of episodes."""
        if len(episodes) < 2:
            return []

        clusters: list[list[Episode]] = []
        used: set[str] = set()

        for ep in episodes:
            if ep.id in used:
                continue

            cluster = [ep]
            ep_keywords = self._extract_keywords(ep.task_description)

            for other in episodes:
                if other.id == ep.id or other.id in used:
                    continue

                other_keywords = self._extract_keywords(other.task_description)
                if self._keyword_similarity(ep_keywords, other_keywords) >= 0.25:
                    cluster.append(other)

            if len(cluster) >= 2:
                clusters.append(cluster)
                for c_ep in cluster:
                    used.add(c_ep.id)

        return clusters
