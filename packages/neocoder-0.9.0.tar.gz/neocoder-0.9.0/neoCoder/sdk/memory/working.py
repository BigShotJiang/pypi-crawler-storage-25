"""
Working memory management for the neoCoder SDK.

Provides short-term memory for agent conversations, including:
- Message history
- Tool invocations and results
- Artifact tracking
- Token counting and management
"""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Literal
from copy import deepcopy


MessageRole = Literal["user", "assistant", "system"]


@dataclass
class Message:
    """A single message in the conversation."""

    role: MessageRole
    content: str | list[dict[str, Any]]
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def to_api_format(self) -> dict[str, Any]:
        """Convert to Anthropic API message format."""
        return {
            "role": self.role,
            "content": self.content,
        }

    @classmethod
    def user(cls, content: str, **metadata) -> Message:
        """Create a user message."""
        return cls(role="user", content=content, metadata=metadata)

    @classmethod
    def assistant(cls, content: str | list[dict[str, Any]], **metadata) -> Message:
        """Create an assistant message."""
        return cls(role="assistant", content=content, metadata=metadata)


@dataclass
class ToolInvocation:
    """Record of a tool invocation."""

    tool_name: str
    tool_use_id: str
    input: dict[str, Any]
    output: str
    success: bool
    timestamp: datetime = field(default_factory=datetime.now)
    duration_ms: float | None = None


@dataclass
class WorkingMemoryConfig:
    """Configuration for working memory."""

    max_messages: int = 100  # Max messages before truncation
    max_tokens: int = 100000  # Target max tokens
    compression_threshold: float = 0.8  # Trigger compression at 80% of max
    rolling_window_size: int = 10  # Keep last N messages uncompressed
    max_tool_invocations: int = 1000  # Max tool invocations to keep in memory
    max_tool_output_chars: int = 8000  # Max chars for tool output in LLM context (truncate larger)


class WorkingMemory:
    """
    Working memory for agent context.

    Manages:
    - Conversation message history
    - Tool invocation tracking
    - Token counting
    - Automatic truncation/compression triggers
    """

    def __init__(self, config: WorkingMemoryConfig | None = None):
        """
        Initialize working memory.

        Args:
            config: Memory configuration.
        """
        self.config = config or WorkingMemoryConfig()
        self._messages: list[Message] = []
        self._tool_invocations: list[ToolInvocation] = []
        self._artifacts: dict[str, Any] = {}
        self._compressed_summary: str | None = None
        self._total_tokens: int = 0

    @property
    def messages(self) -> list[Message]:
        """Get all messages."""
        return self._messages.copy()

    @property
    def message_count(self) -> int:
        """Get number of messages."""
        return len(self._messages)

    @property
    def tool_invocations(self) -> list[ToolInvocation]:
        """Get tool invocation history."""
        return self._tool_invocations.copy()

    def add_message(self, message: Message) -> None:
        """
        Add a message to memory.

        Args:
            message: Message to add.
        """
        self._messages.append(message)
        self._update_token_count(message)

    def add_user_message(self, content: str, **metadata) -> Message:
        """Add a user message and return it."""
        msg = Message.user(content, **metadata)
        self.add_message(msg)
        return msg

    def add_assistant_message(
        self, content: str | list[dict[str, Any]], **metadata
    ) -> Message:
        """Add an assistant message and return it."""
        msg = Message.assistant(content, **metadata)
        self.add_message(msg)
        return msg

    def add_tool_result(
        self,
        tool_use_id: str,
        tool_name: str,
        input_params: dict[str, Any],
        output: str,
        success: bool,
        duration_ms: float | None = None,
    ) -> None:
        """
        Record a tool invocation and add result to messages.

        Args:
            tool_use_id: ID from the tool use block.
            tool_name: Name of the tool.
            input_params: Input parameters.
            output: Tool output.
            success: Whether execution succeeded.
            duration_ms: Execution duration in milliseconds.
        """
        # Truncate output for LLM context to save tokens (keep full for invocation record)
        max_chars = self.config.max_tool_output_chars
        if len(output) > max_chars:
            truncated_output = output[:max_chars] + f"\n... (truncated, {len(output) - max_chars} more chars)"
        else:
            truncated_output = output

        # Record invocation (with full output for debugging)
        invocation = ToolInvocation(
            tool_name=tool_name,
            tool_use_id=tool_use_id,
            input=input_params,
            output=output,  # Keep full output in invocation record
            success=success,
            duration_ms=duration_ms,
        )
        self._tool_invocations.append(invocation)
        
        # Trim old invocations if limit exceeded (prevent memory leak)
        if len(self._tool_invocations) > self.config.max_tool_invocations:
            # Keep only recent invocations
            excess = len(self._tool_invocations) - self.config.max_tool_invocations
            self._tool_invocations = self._tool_invocations[excess:]

        # Add result message (with truncated output to save tokens)
        result_content = [
            {
                "type": "tool_result",
                "tool_use_id": tool_use_id,
                "content": truncated_output,
                "is_error": not success,
            }
        ]
        self.add_message(Message(role="user", content=result_content))

    def get_messages_for_llm(self) -> list[dict[str, Any]]:
        """
        Get messages formatted for LLM API.

        Returns:
            List of messages in API format.
        """
        messages = []

        # Add compressed summary if exists
        if self._compressed_summary:
            messages.append({
                "role": "user",
                "content": f"[Previous context summary]\n{self._compressed_summary}",
            })

        # Add regular messages
        for msg in self._messages:
            messages.append(msg.to_api_format())

        return messages

    def get_recent_messages(self, n: int) -> list[Message]:
        """Get the N most recent messages."""
        return self._messages[-n:] if n < len(self._messages) else self._messages.copy()

    def needs_compression(self) -> bool:
        """Check if compression should be triggered."""
        threshold = int(self.config.max_tokens * self.config.compression_threshold)
        return self._total_tokens > threshold

    def get_compression_candidates(self) -> list[Message]:
        """
        Get messages that can be compressed.

        Returns messages except the rolling window of recent ones.
        """
        window_size = self.config.rolling_window_size
        if len(self._messages) <= window_size:
            return []
        return self._messages[:-window_size]

    def apply_compression(self, summary: str, compressed_count: int) -> None:
        """
        Apply compression by replacing old messages with summary.

        Args:
            summary: Compressed summary of old messages.
            compressed_count: Number of messages that were compressed.
        """
        self._compressed_summary = summary
        # Keep only the rolling window
        self._messages = self._messages[-self.config.rolling_window_size:]
        # Recalculate token count
        self._recalculate_tokens()

    def store_artifact(self, key: str, value: Any) -> None:
        """Store an artifact."""
        self._artifacts[key] = value

    def get_artifact(self, key: str, default: Any = None) -> Any:
        """Retrieve an artifact."""
        return self._artifacts.get(key, default)

    def clear(self) -> None:
        """Clear all memory."""
        self._messages.clear()
        self._tool_invocations.clear()
        self._artifacts.clear()
        self._compressed_summary = None
        self._total_tokens = 0

    def _update_token_count(self, message: Message) -> None:
        """Update token count after adding a message."""
        content = message.content

        try:
            import tiktoken
            # Use cl100k_base as a general approximation for modern LLMs if specific tokenizer isn't provided
            encoding = tiktoken.get_encoding("cl100k_base")

            if isinstance(content, str):
                self._total_tokens += len(encoding.encode(content, disallowed_special=()))
            else:
                for block in content:
                    if isinstance(block, dict):
                        if "text" in block:
                            self._total_tokens += len(encoding.encode(str(block["text"]), disallowed_special=()))
                        if "content" in block:
                            self._total_tokens += len(encoding.encode(str(block["content"]), disallowed_special=()))
                        if "name" in block:
                            self._total_tokens += len(encoding.encode(str(block["name"]), disallowed_special=())) + 5
                    else:
                        self._total_tokens += len(encoding.encode(str(block), disallowed_special=()))
            return
        except ImportError:
            # Fallback heuristic if tiktoken is not installed
            # Rough estimate: 4 chars per token
            if isinstance(content, str):
                self._total_tokens += len(content) // 4
            else:
                char_count = 0
                for block in content:
                    if isinstance(block, dict):
                        if "text" in block:
                            char_count += len(str(block["text"]))
                        if "content" in block:
                            char_count += len(str(block["content"]))
                        if "name" in block:
                            char_count += len(str(block["name"])) + 20
                    else:
                        char_count += len(str(block))
                self._total_tokens += char_count // 4

    def _recalculate_tokens(self) -> None:
        """Recalculate total token count."""
        self._total_tokens = 0
        for msg in self._messages:
            self._update_token_count(msg)
        if self._compressed_summary:
            try:
                import tiktoken
                encoding = tiktoken.get_encoding("cl100k_base")
                self._total_tokens += len(encoding.encode(self._compressed_summary, disallowed_special=()))
            except ImportError:
                self._total_tokens += len(self._compressed_summary) // 4

    def to_dict(self) -> dict[str, Any]:
        """Serialize memory to dictionary."""
        return {
            "messages": [
                {
                    "role": m.role,
                    "content": m.content,
                    "timestamp": m.timestamp.isoformat(),
                    "id": m.id,
                }
                for m in self._messages
            ],
            "compressed_summary": self._compressed_summary,
            "artifacts": self._artifacts,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any], config: WorkingMemoryConfig | None = None) -> WorkingMemory:
        """Deserialize memory from dictionary."""
        memory = cls(config=config)
        for msg_data in data.get("messages", []):
            msg = Message(
                role=msg_data["role"],
                content=msg_data["content"],
                timestamp=datetime.fromisoformat(msg_data["timestamp"]),
                id=msg_data.get("id", str(uuid.uuid4())),
            )
            memory._messages.append(msg)
        memory._compressed_summary = data.get("compressed_summary")
        memory._artifacts = data.get("artifacts", {})
        memory._recalculate_tokens()
        return memory
