"""
Semantic Memory (L2) for xMemory system.

Stores factual and procedural knowledge extracted from episodes.
Each SemanticUnit represents a discrete piece of knowledge that
can be clustered into themes.

Based on xMemory paper: semantic memories bridge episodes and themes,
enabling efficient retrieval without redundancy.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable

import numpy as np

logger = logging.getLogger(__name__)


class KnowledgeType(Enum):
    """Type of knowledge stored in semantic memory."""
    
    FACTUAL = "factual"           # Facts about the codebase/project
    PROCEDURAL = "procedural"     # How to do something
    CONCEPTUAL = "conceptual"     # Understanding of concepts
    CONTEXTUAL = "contextual"     # Context-specific information
    PREFERENCE = "preference"     # User/project preferences


@dataclass
class SemanticUnit:
    """
    A single semantic memory unit (L2 in xMemory hierarchy).
    
    Represents extracted knowledge from one or more episodes,
    with embedding for similarity-based operations.
    """
    
    id: str
    content: str
    knowledge_type: KnowledgeType
    
    # Source tracking
    source_episode_ids: list[str] = field(default_factory=list)
    
    # Embedding for similarity operations
    embedding: np.ndarray | None = None
    
    # kNN neighbors (computed by ThemeManager)
    neighbor_ids: list[str] = field(default_factory=list)
    neighbor_sims: list[float] = field(default_factory=list)
    
    # Theme assignment (set by ThemeManager)
    theme_id: str | None = None
    
    # Metadata
    confidence: float = 1.0
    created_at: float = field(default_factory=time.time)
    access_count: int = 0
    last_accessed: float = field(default_factory=time.time)
    
    # Keywords for fast filtering
    keywords: list[str] = field(default_factory=list)
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "content": self.content,
            "knowledge_type": self.knowledge_type.value,
            "source_episode_ids": self.source_episode_ids,
            "embedding": self.embedding.tolist() if self.embedding is not None else None,
            "neighbor_ids": self.neighbor_ids,
            "neighbor_sims": self.neighbor_sims,
            "theme_id": self.theme_id,
            "confidence": self.confidence,
            "created_at": self.created_at,
            "access_count": self.access_count,
            "last_accessed": self.last_accessed,
            "keywords": self.keywords,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SemanticUnit:
        """Deserialize from dictionary."""
        embedding = None
        if data.get("embedding") is not None:
            embedding = np.array(data["embedding"], dtype=np.float32)
        
        return cls(
            id=data["id"],
            content=data["content"],
            knowledge_type=KnowledgeType(data["knowledge_type"]),
            source_episode_ids=data.get("source_episode_ids", []),
            embedding=embedding,
            neighbor_ids=data.get("neighbor_ids", []),
            neighbor_sims=data.get("neighbor_sims", []),
            theme_id=data.get("theme_id"),
            confidence=data.get("confidence", 1.0),
            created_at=data.get("created_at", time.time()),
            access_count=data.get("access_count", 0),
            last_accessed=data.get("last_accessed", time.time()),
            keywords=data.get("keywords", []),
        )
    
    def record_access(self) -> None:
        """Record that this unit was accessed."""
        self.access_count += 1
        self.last_accessed = time.time()


@dataclass
class SemanticMemoryConfig:
    """Configuration for semantic memory."""
    
    max_units: int = 500                      # Maximum semantic units
    embedding_dim: int = 1536                 # Embedding dimension (OpenAI default)
    knn_k: int = 10                           # Number of neighbors to compute
    similarity_threshold: float = 0.85        # Threshold for duplicate detection
    min_content_length: int = 10              # Minimum content length
    max_content_length: int = 2000            # Maximum content length


class SemanticMemory:
    """
    Semantic Memory Manager (L2 in xMemory hierarchy).
    
    Manages extraction, storage, and retrieval of semantic units.
    Works with ThemeManager for hierarchical organization.
    """
    
    def __init__(self, config: SemanticMemoryConfig | None = None):
        """
        Initialize semantic memory.
        
        Args:
            config: Memory configuration.
        """
        self.config = config or SemanticMemoryConfig()
        self._units: dict[str, SemanticUnit] = {}  # id -> SemanticUnit
        
        # Embedding function (set externally)
        self._embed_fn: Callable[[str], np.ndarray] | None = None
        
        # LLM extraction function (set externally)
        self._extract_fn: Callable[[str], list[dict[str, Any]]] | None = None
        
        # Cached embedding matrix for kNN
        self._embedding_matrix: np.ndarray | None = None
        self._embedding_ids: list[str] = []
        self._embeddings_dirty: bool = True
    
    def set_embedding_function(self, fn: Callable[[str], np.ndarray]) -> None:
        """Set the embedding function."""
        self._embed_fn = fn
    
    def set_extraction_function(
        self, fn: Callable[[str], list[dict[str, Any]]]
    ) -> None:
        """
        Set the LLM-based extraction function.
        
        The function should take episode content and return a list of:
        [{"content": str, "knowledge_type": str, "keywords": list[str]}]
        """
        self._extract_fn = fn
    
    def add_unit(self, unit: SemanticUnit) -> bool:
        """
        Add a semantic unit to memory.
        
        Args:
            unit: SemanticUnit to add.
            
        Returns:
            True if added, False if duplicate.
        """
        # Check for duplicates
        if self._is_duplicate(unit):
            logger.debug(f"Duplicate semantic unit rejected: {unit.id}")
            return False
        
        # Generate embedding if not present
        if unit.embedding is None and self._embed_fn:
            try:
                unit.embedding = self._embed_fn(unit.content)
            except Exception as e:
                logger.warning(f"Failed to generate embedding: {e}")
        
        self._units[unit.id] = unit
        self._embeddings_dirty = True
        
        # Prune if over limit
        if len(self._units) > self.config.max_units:
            self._prune_least_accessed()
        
        logger.debug(f"Added semantic unit: {unit.id}")
        return True
    
    def _is_duplicate(self, unit: SemanticUnit) -> bool:
        """Check if unit is duplicate of existing."""
        if unit.embedding is None:
            return False
        
        for existing in self._units.values():
            if existing.embedding is None:
                continue
            
            # Same knowledge type required
            if existing.knowledge_type != unit.knowledge_type:
                continue
            
            sim = self._cosine_similarity(unit.embedding, existing.embedding)
            if sim > self.config.similarity_threshold:
                return True
        
        return False
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a < 1e-9 or norm_b < 1e-9:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))
    
    def extract_from_episode(
        self,
        episode_id: str,
        episode_content: str,
    ) -> list[SemanticUnit]:
        """
        Extract semantic units from an episode using LLM.
        
        Args:
            episode_id: Source episode ID.
            episode_content: Episode content text.
            
        Returns:
            List of extracted SemanticUnits.
        """
        if not self._extract_fn:
            logger.warning("Extraction function not set")
            return []
        
        try:
            # Call LLM extraction
            raw_units = self._extract_fn(episode_content)
            
            extracted: list[SemanticUnit] = []
            for raw in raw_units:
                content = raw.get("content", "").strip()
                
                # Validate content length
                if len(content) < self.config.min_content_length:
                    continue
                if len(content) > self.config.max_content_length:
                    content = content[:self.config.max_content_length]
                
                # Parse knowledge type
                kt_str = raw.get("knowledge_type", "factual").lower()
                try:
                    knowledge_type = KnowledgeType(kt_str)
                except ValueError:
                    knowledge_type = KnowledgeType.FACTUAL
                
                unit = SemanticUnit(
                    id=f"sem_{uuid.uuid4().hex[:12]}",
                    content=content,
                    knowledge_type=knowledge_type,
                    source_episode_ids=[episode_id],
                    keywords=raw.get("keywords", []),
                    confidence=raw.get("confidence", 1.0),
                )
                
                if self.add_unit(unit):
                    extracted.append(unit)
            
            logger.info(f"Extracted {len(extracted)} semantic units from episode {episode_id}")
            return extracted
            
        except Exception as e:
            logger.error(f"Semantic extraction failed: {e}")
            return []
    
    def get_unit(self, unit_id: str) -> SemanticUnit | None:
        """Get a unit by ID."""
        return self._units.get(unit_id)
    
    def get_units_by_theme(self, theme_id: str) -> list[SemanticUnit]:
        """Get all units belonging to a theme."""
        return [u for u in self._units.values() if u.theme_id == theme_id]
    
    def get_unassigned_units(self) -> list[SemanticUnit]:
        """Get units not yet assigned to a theme."""
        return [u for u in self._units.values() if u.theme_id is None]
    
    def assign_to_theme(self, unit_id: str, theme_id: str) -> bool:
        """Assign a unit to a theme."""
        unit = self._units.get(unit_id)
        if unit:
            unit.theme_id = theme_id
            return True
        return False
    
    def search_by_embedding(
        self,
        query_embedding: np.ndarray,
        top_k: int = 10,
        knowledge_type: KnowledgeType | None = None,
    ) -> list[tuple[SemanticUnit, float]]:
        """
        Search semantic units by embedding similarity.
        
        Args:
            query_embedding: Query embedding vector.
            top_k: Number of results.
            knowledge_type: Optional filter by type.
            
        Returns:
            List of (unit, similarity) tuples.
        """
        results: list[tuple[SemanticUnit, float]] = []
        
        for unit in self._units.values():
            if unit.embedding is None:
                continue
            
            if knowledge_type and unit.knowledge_type != knowledge_type:
                continue
            
            sim = self._cosine_similarity(query_embedding, unit.embedding)
            results.append((unit, sim))
        
        # Sort by similarity descending
        results.sort(key=lambda x: x[1], reverse=True)
        
        # Record access for retrieved units
        for unit, _ in results[:top_k]:
            unit.record_access()
        
        return results[:top_k]
    
    def search_by_keywords(
        self,
        keywords: list[str],
        top_k: int = 10,
    ) -> list[SemanticUnit]:
        """Search semantic units by keyword matching."""
        keywords_lower = {kw.lower() for kw in keywords}
        
        scored: list[tuple[SemanticUnit, int]] = []
        for unit in self._units.values():
            unit_keywords = {kw.lower() for kw in unit.keywords}
            matches = len(keywords_lower & unit_keywords)
            if matches > 0:
                scored.append((unit, matches))
        
        scored.sort(key=lambda x: x[1], reverse=True)
        return [unit for unit, _ in scored[:top_k]]
    
    def compute_knn(self, k: int | None = None) -> None:
        """
        Compute k-nearest neighbors for all units.
        
        Updates neighbor_ids and neighbor_sims for each unit.
        """
        k = k or self.config.knn_k
        
        # Build embedding matrix
        units_with_emb = [
            (uid, u) for uid, u in self._units.items()
            if u.embedding is not None
        ]
        
        if len(units_with_emb) < 2:
            return
        
        ids = [uid for uid, _ in units_with_emb]
        embeddings = np.stack([u.embedding for _, u in units_with_emb], axis=0)
        
        # Normalize
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-9
        embeddings_norm = embeddings / norms
        
        # Compute all pairwise similarities
        sim_matrix = embeddings_norm @ embeddings_norm.T
        
        # For each unit, find top-k neighbors (excluding self)
        for i, uid in enumerate(ids):
            sims = sim_matrix[i].copy()
            sims[i] = -1  # Exclude self
            
            top_k_idx = np.argsort(sims)[::-1][:k]
            
            unit = self._units[uid]
            unit.neighbor_ids = [ids[j] for j in top_k_idx]
            unit.neighbor_sims = [float(sims[j]) for j in top_k_idx]
        
        self._embeddings_dirty = False
        logger.debug(f"Computed kNN for {len(ids)} semantic units")
    
    def get_embedding_matrix(self) -> tuple[np.ndarray, list[str]]:
        """
        Get embedding matrix and corresponding unit IDs.
        
        Returns:
            (embedding_matrix, unit_ids)
        """
        if self._embeddings_dirty or self._embedding_matrix is None:
            units_with_emb = [
                (uid, u) for uid, u in self._units.items()
                if u.embedding is not None
            ]
            
            if not units_with_emb:
                return np.array([]), []
            
            self._embedding_ids = [uid for uid, _ in units_with_emb]
            self._embedding_matrix = np.stack(
                [u.embedding for _, u in units_with_emb], axis=0
            )
            self._embeddings_dirty = False
        
        return self._embedding_matrix, self._embedding_ids
    
    def _prune_least_accessed(self) -> None:
        """Remove least accessed units to stay within limit."""
        if len(self._units) <= self.config.max_units:
            return
        
        # Sort by access count and recency
        units_list = list(self._units.values())
        units_list.sort(
            key=lambda u: (u.access_count, u.last_accessed),
            reverse=True
        )
        
        # Keep top max_units
        keep_ids = {u.id for u in units_list[:self.config.max_units]}
        self._units = {uid: u for uid, u in self._units.items() if uid in keep_ids}
        self._embeddings_dirty = True
        
        removed = len(units_list) - len(self._units)
        logger.info(f"Pruned {removed} least accessed semantic units")
    
    def get_all_units(self) -> list[SemanticUnit]:
        """Get all semantic units."""
        return list(self._units.values())
    
    def clear(self) -> None:
        """Clear all semantic memory."""
        self._units.clear()
        self._embedding_matrix = None
        self._embedding_ids = []
        self._embeddings_dirty = True
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "units": [u.to_dict() for u in self._units.values()],
        }
    
    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        config: SemanticMemoryConfig | None = None,
    ) -> SemanticMemory:
        """Deserialize from dictionary."""
        memory = cls(config=config)
        for unit_data in data.get("units", []):
            unit = SemanticUnit.from_dict(unit_data)
            memory._units[unit.id] = unit
        memory._embeddings_dirty = True
        return memory
    
    def get_stats(self) -> dict[str, Any]:
        """Get memory statistics."""
        by_type: dict[str, int] = {}
        assigned = 0
        
        for unit in self._units.values():
            kt = unit.knowledge_type.value
            by_type[kt] = by_type.get(kt, 0) + 1
            if unit.theme_id:
                assigned += 1
        
        return {
            "total_units": len(self._units),
            "assigned_to_themes": assigned,
            "unassigned": len(self._units) - assigned,
            "by_knowledge_type": by_type,
        }
