"""
Sparsity-Semantics Scoring for xMemory.

Implements the scoring function from xMemory paper:
f = SparsityScore + SemanticScore

SparsityScore: Encourages balanced partition of semantics across themes
SemanticScore: Encourages coherent themes with high intra-similarity

This scoring guides:
- Split decisions (which partition is best)
- Merge decisions (does merging improve score)
- Overall memory organization quality
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import numpy as np

from neoCoder.sdk.memory.xmemory.semantic import SemanticMemory, SemanticUnit
from neoCoder.sdk.memory.xmemory.themes import ThemeNode

logger = logging.getLogger(__name__)


@dataclass
class ScoringConfig:
    """Configuration for sparsity-semantics scoring."""
    
    # Sparsity weight
    sparsity_weight: float = 1.0
    
    # Semantic weight
    semantic_weight: float = 1.0
    
    # Context subgraph size for scoring
    context_k: int = 10
    
    # Gaussian weighting parameters for semantic score
    gaussian_sigma: float = 0.5
    
    # Numerical stability
    eps: float = 1e-8


class SparsitySemanticsScorer:
    """
    Scorer for evaluating memory organization quality.
    
    Implements the xMemory scoring function that balances:
    - Sparsity: Even distribution of semantics across themes
    - Semantics: Coherent themes with high internal similarity
    """
    
    def __init__(
        self,
        semantic_memory: SemanticMemory,
        config: ScoringConfig | None = None,
    ):
        """
        Initialize scorer.
        
        Args:
            semantic_memory: The semantic memory being scored.
            config: Scoring configuration.
        """
        self.semantic_memory = semantic_memory
        self.config = config or ScoringConfig()
    
    def score_themes(
        self,
        themes: list[ThemeNode],
    ) -> float:
        """
        Score a set of themes.
        
        Args:
            themes: List of themes to score.
            
        Returns:
            Combined sparsity + semantic score.
        """
        if not themes:
            return 0.0
        
        sparsity = self._compute_sparsity_score(themes)
        semantic = self._compute_semantic_score(themes)
        
        return (
            self.config.sparsity_weight * sparsity +
            self.config.semantic_weight * semantic
        )
    
    def score_partition(
        self,
        partition: list[list[str]],
    ) -> float:
        """
        Score a partition of semantic IDs.
        
        Used when evaluating split candidates.
        
        Args:
            partition: List of lists of semantic IDs.
            
        Returns:
            Score for this partition.
        """
        if not partition:
            return 0.0
        
        # Compute sparsity
        sizes = [len(cluster) for cluster in partition]
        sparsity = self._sparsity_from_sizes(sizes)
        
        # Compute semantic (cohesion for each cluster)
        cohesions = []
        for cluster_ids in partition:
            cohesion = self._compute_cluster_cohesion(cluster_ids)
            cohesions.append(cohesion)
        
        semantic = float(np.mean(cohesions)) if cohesions else 0.0
        
        return (
            self.config.sparsity_weight * sparsity +
            self.config.semantic_weight * semantic
        )
    
    def _compute_sparsity_score(self, themes: list[ThemeNode]) -> float:
        """
        Compute sparsity score for themes.
        
        SparsityScore = (N/K) * (N / Σ(n_k²))
        
        Where:
        - N = total semantics
        - K = number of themes
        - n_k = members in theme k
        
        This encourages balanced partitioning.
        """
        if not themes:
            return 0.0
        
        sizes = [t.member_count for t in themes]
        return self._sparsity_from_sizes(sizes)
    
    def _sparsity_from_sizes(self, sizes: list[int]) -> float:
        """Compute sparsity from a list of cluster sizes."""
        if not sizes:
            return 0.0
        
        total_n = sum(sizes)
        k = len(sizes)
        sum_squared = sum(s * s for s in sizes)
        
        if k == 0 or sum_squared == 0:
            return 0.0
        
        # Normalized sparsity
        # Perfect balance: all clusters have N/K members
        # Score approaches 1.0 for balanced partitions
        sparsity = (total_n / k) * (total_n / (sum_squared + self.config.eps))
        
        # Normalize to [0, 1] range
        # When perfectly balanced: sparsity = N/K * K/N = 1.0
        return min(1.0, sparsity)
    
    def _compute_semantic_score(self, themes: list[ThemeNode]) -> float:
        """
        Compute semantic score for themes.
        
        SemanticScore = mean(cohesion_k * g(s_k))
        
        Where:
        - cohesion_k = mean cosine similarity to centroid
        - s_k = max kNN similarity within theme
        - g(·) = Gaussian weighting
        """
        if not themes:
            return 0.0
        
        scores = []
        
        for theme in themes:
            cohesion = self._compute_theme_cohesion(theme)
            knn_factor = self._compute_knn_factor(theme)
            
            # Gaussian weighting for kNN factor
            weighted_knn = self._gaussian_weight(knn_factor)
            
            score = cohesion * weighted_knn
            scores.append(score)
        
        return float(np.mean(scores)) if scores else 0.0
    
    def _compute_theme_cohesion(self, theme: ThemeNode) -> float:
        """Compute mean cosine similarity of members to centroid."""
        if theme.centroid is None or not theme.semantic_ids:
            return 0.0
        
        sims = []
        for sem_id in theme.semantic_ids:
            unit = self.semantic_memory.get_unit(sem_id)
            if unit and unit.embedding is not None:
                sim = self._cosine_similarity(unit.embedding, theme.centroid)
                sims.append(sim)
        
        return float(np.mean(sims)) if sims else 0.0
    
    def _compute_cluster_cohesion(self, semantic_ids: list[str]) -> float:
        """Compute cohesion for a cluster of semantic IDs."""
        if not semantic_ids:
            return 0.0
        
        # Get embeddings
        embeddings = []
        for sem_id in semantic_ids:
            unit = self.semantic_memory.get_unit(sem_id)
            if unit and unit.embedding is not None:
                embeddings.append(unit.embedding)
        
        if len(embeddings) < 2:
            return 1.0  # Single-member cluster is perfectly coherent
        
        # Compute centroid
        centroid = np.mean(embeddings, axis=0)
        
        # Compute mean similarity to centroid
        sims = []
        for emb in embeddings:
            sim = self._cosine_similarity(emb, centroid)
            sims.append(sim)
        
        return float(np.mean(sims))
    
    def _compute_knn_factor(self, theme: ThemeNode) -> float:
        """
        Compute kNN factor for a theme.
        
        Uses max kNN similarity as indicator of theme quality.
        High max kNN sim suggests theme overlaps with another.
        """
        if not theme.neighbor_sims:
            return 0.5  # Default neutral value
        
        # Use max neighbor similarity
        return max(theme.neighbor_sims)
    
    def _gaussian_weight(self, x: float) -> float:
        """
        Apply Gaussian weighting.
        
        Maps similarity to a weight that:
        - Penalizes very high similarity (redundant themes)
        - Prefers moderate similarity (related but distinct)
        """
        # Center around median expected similarity
        center = 0.5
        sigma = self.config.gaussian_sigma
        
        # Gaussian: exp(-(x - center)² / (2σ²))
        return float(np.exp(-((x - center) ** 2) / (2 * sigma ** 2)))
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a < self.config.eps or norm_b < self.config.eps:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))
    
    def evaluate_merge(
        self,
        theme1: ThemeNode,
        theme2: ThemeNode,
    ) -> dict[str, float]:
        """
        Evaluate whether merging two themes improves the score.
        
        Args:
            theme1: First theme.
            theme2: Second theme.
            
        Returns:
            {"before": score, "after": score, "delta": delta}
        """
        # Score before merge
        score_before = self.score_themes([theme1, theme2])
        
        # Simulate merged theme
        merged_ids = theme1.semantic_ids + theme2.semantic_ids
        
        # Compute merged centroid
        embeddings = []
        for sem_id in merged_ids:
            unit = self.semantic_memory.get_unit(sem_id)
            if unit and unit.embedding is not None:
                embeddings.append(unit.embedding)
        
        merged_centroid = np.mean(embeddings, axis=0) if embeddings else None
        
        merged_theme = ThemeNode(
            id="merged_temp",
            summary="",
            semantic_ids=merged_ids,
            centroid=merged_centroid,
        )
        
        # Score after merge
        score_after = self.score_themes([merged_theme])
        
        return {
            "before": score_before,
            "after": score_after,
            "delta": score_after - score_before,
        }
    
    def evaluate_split(
        self,
        theme: ThemeNode,
        partitions: list[list[list[str]]],
    ) -> list[dict[str, Any]]:
        """
        Evaluate multiple split partitions and rank them.
        
        Args:
            theme: Theme to split.
            partitions: List of possible partitions.
            
        Returns:
            Ranked list of {"partition": [...], "score": float}
        """
        score_before = self.score_themes([theme])
        
        results = []
        for partition in partitions:
            score = self.score_partition(partition)
            delta = score - score_before
            
            results.append({
                "partition": partition,
                "score": score,
                "delta": delta,
            })
        
        # Sort by score descending
        results.sort(key=lambda x: x["score"], reverse=True)
        
        return results
    
    def get_memory_quality_score(
        self,
        themes: list[ThemeNode],
    ) -> dict[str, float]:
        """
        Get overall memory quality metrics.
        
        Args:
            themes: All themes in memory.
            
        Returns:
            Quality metrics dictionary.
        """
        if not themes:
            return {
                "overall": 0.0,
                "sparsity": 0.0,
                "semantic": 0.0,
                "coverage": 0.0,
            }
        
        sparsity = self._compute_sparsity_score(themes)
        semantic = self._compute_semantic_score(themes)
        overall = (
            self.config.sparsity_weight * sparsity +
            self.config.semantic_weight * semantic
        )
        
        # Coverage: % of semantics assigned to themes
        total_assigned = sum(t.member_count for t in themes)
        total_semantics = len(self.semantic_memory.get_all_units())
        coverage = total_assigned / total_semantics if total_semantics > 0 else 0.0
        
        return {
            "overall": overall,
            "sparsity": sparsity,
            "semantic": semantic,
            "coverage": coverage,
        }
