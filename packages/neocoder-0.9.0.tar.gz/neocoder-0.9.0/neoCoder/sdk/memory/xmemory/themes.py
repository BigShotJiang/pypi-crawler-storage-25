"""
Theme Manager (L3) for xMemory system.

Manages high-level themes that group semantic units.
Implements the xMemory consolidation approach:
- Attachment: Assign semantics to best-matching theme
- Split: Break heterogeneous themes into coherent subgroups
- Merge: Combine similar themes to reduce redundancy

Themes form the top level of the hierarchy and enable
efficient top-down retrieval.
"""

from __future__ import annotations

import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

import numpy as np

from neoCoder.sdk.memory.xmemory.semantic import SemanticMemory, SemanticUnit

logger = logging.getLogger(__name__)


@dataclass
class ThemeNode:
    """
    A theme node (L3 in xMemory hierarchy).
    
    Groups related semantic units under a high-level concept.
    Maintains both centroid (mean of members) and summary embedding.
    """
    
    id: str
    summary: str                              # LLM-generated description
    
    # Member semantic unit IDs
    semantic_ids: list[str] = field(default_factory=list)
    
    # Embeddings
    centroid: np.ndarray | None = None        # Mean of member embeddings
    summary_embedding: np.ndarray | None = None  # Embedding of summary
    
    # kNN neighbors (other themes)
    neighbor_ids: list[str] = field(default_factory=list)
    neighbor_sims: list[float] = field(default_factory=list)
    
    # Metadata
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    access_count: int = 0
    
    @property
    def member_count(self) -> int:
        """Number of semantic units in this theme."""
        return len(self.semantic_ids)
    
    def add_semantic(self, semantic_id: str) -> None:
        """Add a semantic unit to this theme."""
        if semantic_id not in self.semantic_ids:
            self.semantic_ids.append(semantic_id)
            self.updated_at = time.time()
    
    def remove_semantic(self, semantic_id: str) -> None:
        """Remove a semantic unit from this theme."""
        if semantic_id in self.semantic_ids:
            self.semantic_ids.remove(semantic_id)
            self.updated_at = time.time()
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "id": self.id,
            "summary": self.summary,
            "semantic_ids": self.semantic_ids,
            "centroid": self.centroid.tolist() if self.centroid is not None else None,
            "summary_embedding": (
                self.summary_embedding.tolist()
                if self.summary_embedding is not None else None
            ),
            "neighbor_ids": self.neighbor_ids,
            "neighbor_sims": self.neighbor_sims,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "access_count": self.access_count,
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ThemeNode:
        """Deserialize from dictionary."""
        centroid = None
        if data.get("centroid") is not None:
            centroid = np.array(data["centroid"], dtype=np.float32)
        
        summary_embedding = None
        if data.get("summary_embedding") is not None:
            summary_embedding = np.array(data["summary_embedding"], dtype=np.float32)
        
        return cls(
            id=data["id"],
            summary=data["summary"],
            semantic_ids=data.get("semantic_ids", []),
            centroid=centroid,
            summary_embedding=summary_embedding,
            neighbor_ids=data.get("neighbor_ids", []),
            neighbor_sims=data.get("neighbor_sims", []),
            created_at=data.get("created_at", time.time()),
            updated_at=data.get("updated_at", time.time()),
            access_count=data.get("access_count", 0),
        )


@dataclass
class ThemeManagerConfig:
    """Configuration for theme manager."""
    
    # Attachment thresholds
    attach_threshold: float = 0.62            # Min similarity to attach to theme
    lenient_attach_floor: float = 0.52        # Lenient attachment if theme has space
    
    # Split thresholds
    max_theme_size: int = 12                  # Max members before split
    min_intra_similarity: float = 0.72        # Min cohesion before split
    split_threshold: float = 0.66             # Clustering threshold for split
    
    # Merge thresholds
    merge_threshold: float = 0.78             # Min similarity for merge
    micro_theme_size: int = 2                 # Themes smaller are candidates for absorption
    
    # kNN
    knn_k: int = 10                           # Number of theme neighbors
    
    # Summary
    max_summary_length: int = 200             # Max chars for theme summary


class ThemeManager:
    """
    Theme Manager for xMemory hierarchy.
    
    Organizes semantic units into themes through:
    1. Assimilation: Attach new semantics to existing themes
    2. Accommodation: Split/merge themes for optimal organization
    """
    
    def __init__(
        self,
        semantic_memory: SemanticMemory,
        config: ThemeManagerConfig | None = None,
    ):
        """
        Initialize theme manager.
        
        Args:
            semantic_memory: The semantic memory to organize.
            config: Manager configuration.
        """
        self.semantic_memory = semantic_memory
        self.config = config or ThemeManagerConfig()
        self._themes: dict[str, ThemeNode] = {}  # id -> ThemeNode
        
        # LLM summary generator (set externally)
        self._summarize_fn: Callable[[list[str]], str] | None = None
        
        # Embedding function (set externally)
        self._embed_fn: Callable[[str], np.ndarray] | None = None
    
    def set_summarize_function(self, fn: Callable[[list[str]], str]) -> None:
        """
        Set the LLM function for generating theme summaries.
        
        Args:
            fn: Function that takes list of semantic contents and returns summary.
        """
        self._summarize_fn = fn
    
    def set_embedding_function(self, fn: Callable[[str], np.ndarray]) -> None:
        """Set the embedding function."""
        self._embed_fn = fn
    
    def assimilate_semantics(
        self,
        semantic_ids: list[str],
    ) -> dict[str, int]:
        """
        Assimilate new semantic units into themes.
        
        This is the main entry point for consolidation.
        
        Args:
            semantic_ids: IDs of new semantic units to assimilate.
            
        Returns:
            Stats: {"attached": N, "created": M}
        """
        attached = 0
        created = 0
        
        for sem_id in semantic_ids:
            unit = self.semantic_memory.get_unit(sem_id)
            if not unit or unit.embedding is None:
                continue
            
            theme_id = self._attach_semantic_to_theme(unit)
            
            if theme_id:
                attached += 1
            else:
                # Create new single-member theme
                new_theme = self._create_theme_for_semantic(unit)
                if new_theme:
                    created += 1
        
        return {"attached": attached, "created": created}
    
    def accommodate(self) -> dict[str, int]:
        """
        Run accommodation: split and merge themes.
        
        Returns:
            Stats: {"split": N, "merged": M, "absorbed": K}
        """
        stats = {"split": 0, "merged": 0, "absorbed": 0}
        
        # 1. Split oversized or heterogeneous themes
        split_count = self._split_themes()
        stats["split"] = split_count
        
        # 2. Merge similar themes
        merge_count = self._merge_themes()
        stats["merged"] = merge_count
        
        # 3. Absorb micro-themes
        absorbed_count = self._absorb_micro_themes()
        stats["absorbed"] = absorbed_count
        
        # 4. Recompute kNN
        self._compute_theme_knn()
        
        return stats
    
    def consolidate(self, new_semantic_ids: list[str]) -> dict[str, Any]:
        """
        Full consolidation: assimilate + accommodate.
        
        Args:
            new_semantic_ids: IDs of new semantic units.
            
        Returns:
            Combined stats.
        """
        assim_stats = self.assimilate_semantics(new_semantic_ids)
        accom_stats = self.accommodate()
        
        return {
            "assimilation": assim_stats,
            "accommodation": accom_stats,
        }
    
    def _attach_semantic_to_theme(self, unit: SemanticUnit) -> str | None:
        """
        Try to attach a semantic unit to the best matching theme.
        
        Returns:
            Theme ID if attached, None otherwise.
        """
        if not self._themes or unit.embedding is None:
            return None
        
        best_theme_id = None
        best_sim = 0.0
        
        for theme in self._themes.values():
            if theme.centroid is None:
                continue
            
            sim = self._cosine_similarity(unit.embedding, theme.centroid)
            
            if sim > best_sim:
                best_sim = sim
                best_theme_id = theme.id
        
        # Check attachment thresholds
        if best_sim >= self.config.attach_threshold:
            # Standard attachment
            self._add_semantic_to_theme(unit.id, best_theme_id)
            return best_theme_id
        
        elif (
            best_sim >= self.config.lenient_attach_floor and
            best_theme_id and
            self._themes[best_theme_id].member_count < self.config.max_theme_size
        ):
            # Lenient attachment if theme has space
            self._add_semantic_to_theme(unit.id, best_theme_id)
            return best_theme_id
        
        return None
    
    def _add_semantic_to_theme(self, semantic_id: str, theme_id: str) -> None:
        """Add semantic to theme and update centroid."""
        theme = self._themes.get(theme_id)
        unit = self.semantic_memory.get_unit(semantic_id)
        
        if not theme or not unit:
            return
        
        theme.add_semantic(semantic_id)
        unit.theme_id = theme_id
        
        # Update centroid
        self._update_theme_centroid(theme_id)
    
    def _update_theme_centroid(self, theme_id: str) -> None:
        """Recompute theme centroid from member embeddings."""
        theme = self._themes.get(theme_id)
        if not theme:
            return
        
        embeddings = []
        for sem_id in theme.semantic_ids:
            unit = self.semantic_memory.get_unit(sem_id)
            if unit and unit.embedding is not None:
                embeddings.append(unit.embedding)
        
        if embeddings:
            theme.centroid = np.mean(embeddings, axis=0)
    
    def _create_theme_for_semantic(self, unit: SemanticUnit) -> ThemeNode | None:
        """Create a new theme for a single semantic unit."""
        # Generate summary (use unit content if no LLM)
        if self._summarize_fn:
            try:
                summary = self._summarize_fn([unit.content])
            except Exception as e:
                logger.warning(f"Summary generation failed: {e}")
                summary = unit.content[:self.config.max_summary_length]
        else:
            summary = unit.content[:self.config.max_summary_length]
        
        theme = ThemeNode(
            id=f"theme_{uuid.uuid4().hex[:12]}",
            summary=summary,
            semantic_ids=[unit.id],
            centroid=unit.embedding.copy() if unit.embedding is not None else None,
        )
        
        # Generate summary embedding
        if self._embed_fn and theme.summary:
            try:
                theme.summary_embedding = self._embed_fn(theme.summary)
            except Exception:
                pass
        
        self._themes[theme.id] = theme
        unit.theme_id = theme.id
        
        logger.debug(f"Created new theme: {theme.id}")
        return theme
    
    def _split_themes(self) -> int:
        """
        Split oversized or heterogeneous themes.
        
        Returns:
            Number of splits performed.
        """
        split_count = 0
        themes_to_check = list(self._themes.keys())
        
        for theme_id in themes_to_check:
            theme = self._themes.get(theme_id)
            if not theme:
                continue
            
            should_split = False
            
            # Check size
            if theme.member_count > self.config.max_theme_size:
                should_split = True
            
            # Check cohesion
            elif theme.member_count >= 4:
                cohesion = self._compute_theme_cohesion(theme_id)
                if cohesion < self.config.min_intra_similarity:
                    should_split = True
            
            if should_split:
                new_themes = self._perform_split(theme_id)
                if len(new_themes) > 1:
                    split_count += 1
        
        return split_count
    
    def _compute_theme_cohesion(self, theme_id: str) -> float:
        """Compute mean intra-theme similarity."""
        theme = self._themes.get(theme_id)
        if not theme or theme.centroid is None:
            return 1.0
        
        sims = []
        for sem_id in theme.semantic_ids:
            unit = self.semantic_memory.get_unit(sem_id)
            if unit and unit.embedding is not None:
                sim = self._cosine_similarity(unit.embedding, theme.centroid)
                sims.append(sim)
        
        return float(np.mean(sims)) if sims else 1.0
    
    def _perform_split(self, theme_id: str) -> list[ThemeNode]:
        """
        Split a theme into coherent subgroups.
        
        Uses connectivity-based clustering at threshold.
        """
        theme = self._themes.get(theme_id)
        if not theme or theme.member_count < 2:
            return [theme] if theme else []
        
        # Get member embeddings
        members: list[tuple[str, np.ndarray]] = []
        for sem_id in theme.semantic_ids:
            unit = self.semantic_memory.get_unit(sem_id)
            if unit and unit.embedding is not None:
                members.append((sem_id, unit.embedding))
        
        if len(members) < 2:
            return [theme]
        
        # Compute similarity matrix
        ids = [m[0] for m in members]
        embeddings = np.stack([m[1] for m in members], axis=0)
        norms = np.linalg.norm(embeddings, axis=1, keepdims=True) + 1e-9
        embeddings_norm = embeddings / norms
        sim_matrix = embeddings_norm @ embeddings_norm.T
        
        # Find connected components at threshold
        clusters = self._find_connected_components(
            ids, sim_matrix, self.config.split_threshold
        )
        
        if len(clusters) < 2:
            return [theme]
        
        # Remove old theme
        del self._themes[theme_id]
        
        # Create new themes from clusters
        new_themes: list[ThemeNode] = []
        for cluster_ids in clusters:
            # Get representative content for summary
            contents = []
            for sem_id in cluster_ids:
                unit = self.semantic_memory.get_unit(sem_id)
                if unit:
                    contents.append(unit.content)
                    unit.theme_id = None  # Reset, will be set below
            
            # Generate summary
            if self._summarize_fn and contents:
                try:
                    summary = self._summarize_fn(contents)
                except Exception:
                    summary = contents[0][:self.config.max_summary_length]
            else:
                summary = contents[0][:self.config.max_summary_length] if contents else "Theme"
            
            new_theme = ThemeNode(
                id=f"theme_{uuid.uuid4().hex[:12]}",
                summary=summary,
                semantic_ids=cluster_ids,
            )
            
            # Compute centroid
            cluster_embs = []
            for sem_id in cluster_ids:
                unit = self.semantic_memory.get_unit(sem_id)
                if unit and unit.embedding is not None:
                    cluster_embs.append(unit.embedding)
                    unit.theme_id = new_theme.id
            
            if cluster_embs:
                new_theme.centroid = np.mean(cluster_embs, axis=0)
            
            self._themes[new_theme.id] = new_theme
            new_themes.append(new_theme)
        
        logger.info(f"Split theme {theme_id} into {len(new_themes)} themes")
        return new_themes
    
    def _find_connected_components(
        self,
        ids: list[str],
        sim_matrix: np.ndarray,
        threshold: float,
    ) -> list[list[str]]:
        """Find connected components in similarity graph."""
        n = len(ids)
        visited = [False] * n
        components: list[list[str]] = []
        
        def dfs(node: int, component: list[int]) -> None:
            visited[node] = True
            component.append(node)
            for neighbor in range(n):
                if not visited[neighbor] and sim_matrix[node, neighbor] >= threshold:
                    dfs(neighbor, component)
        
        for i in range(n):
            if not visited[i]:
                component: list[int] = []
                dfs(i, component)
                components.append([ids[j] for j in component])
        
        return components
    
    def _merge_themes(self) -> int:
        """
        Merge similar themes.
        
        Returns:
            Number of merges performed.
        """
        merge_count = 0
        merged_ids: set[str] = set()
        
        theme_ids = list(self._themes.keys())
        
        for i, tid1 in enumerate(theme_ids):
            if tid1 in merged_ids:
                continue
            
            theme1 = self._themes.get(tid1)
            if not theme1 or theme1.centroid is None:
                continue
            
            for tid2 in theme_ids[i + 1:]:
                if tid2 in merged_ids:
                    continue
                
                theme2 = self._themes.get(tid2)
                if not theme2 or theme2.centroid is None:
                    continue
                
                sim = self._cosine_similarity(theme1.centroid, theme2.centroid)
                
                if sim >= self.config.merge_threshold:
                    # Merge theme2 into theme1
                    self._merge_into(tid1, tid2)
                    merged_ids.add(tid2)
                    merge_count += 1
        
        return merge_count
    
    def _merge_into(self, target_id: str, source_id: str) -> None:
        """Merge source theme into target theme."""
        target = self._themes.get(target_id)
        source = self._themes.get(source_id)
        
        if not target or not source:
            return
        
        # Move all semantics to target
        for sem_id in source.semantic_ids:
            target.add_semantic(sem_id)
            unit = self.semantic_memory.get_unit(sem_id)
            if unit:
                unit.theme_id = target_id
        
        # Update centroid
        self._update_theme_centroid(target_id)
        
        # Remove source theme
        del self._themes[source_id]
        
        logger.debug(f"Merged theme {source_id} into {target_id}")
    
    def _absorb_micro_themes(self) -> int:
        """
        Absorb tiny themes into nearest larger themes.
        
        Returns:
            Number of absorptions.
        """
        absorbed_count = 0
        themes_to_absorb: list[str] = []
        
        for tid, theme in self._themes.items():
            if theme.member_count <= self.config.micro_theme_size:
                themes_to_absorb.append(tid)
        
        for tid in themes_to_absorb:
            theme = self._themes.get(tid)
            if not theme or theme.centroid is None:
                continue
            
            # Find best target (not micro-theme itself)
            best_target = None
            best_sim = 0.0
            
            for other_id, other in self._themes.items():
                if other_id == tid:
                    continue
                if other.member_count <= self.config.micro_theme_size:
                    continue
                if other.centroid is None:
                    continue
                
                sim = self._cosine_similarity(theme.centroid, other.centroid)
                if sim > best_sim:
                    best_sim = sim
                    best_target = other_id
            
            # Absorb if similarity is reasonable
            if best_target and best_sim >= self.config.lenient_attach_floor:
                self._merge_into(best_target, tid)
                absorbed_count += 1
        
        return absorbed_count
    
    def _compute_theme_knn(self) -> None:
        """Compute k-nearest neighbors for all themes."""
        themes_with_centroid = [
            (tid, t) for tid, t in self._themes.items()
            if t.centroid is not None
        ]
        
        if len(themes_with_centroid) < 2:
            return
        
        ids = [tid for tid, _ in themes_with_centroid]
        centroids = np.stack([t.centroid for _, t in themes_with_centroid], axis=0)
        
        norms = np.linalg.norm(centroids, axis=1, keepdims=True) + 1e-9
        centroids_norm = centroids / norms
        sim_matrix = centroids_norm @ centroids_norm.T
        
        k = min(self.config.knn_k, len(ids) - 1)
        
        for i, tid in enumerate(ids):
            theme = self._themes[tid]
            sims = sim_matrix[i].copy()
            sims[i] = -1  # Exclude self
            
            top_k_idx = np.argsort(sims)[::-1][:k]
            
            theme.neighbor_ids = [ids[j] for j in top_k_idx]
            theme.neighbor_sims = [float(sims[j]) for j in top_k_idx]
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """Compute cosine similarity between two vectors."""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a < 1e-9 or norm_b < 1e-9:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))
    
    def get_theme(self, theme_id: str) -> ThemeNode | None:
        """Get a theme by ID."""
        return self._themes.get(theme_id)
    
    def get_all_themes(self) -> list[ThemeNode]:
        """Get all themes."""
        return list(self._themes.values())
    
    def search_themes(
        self,
        query_embedding: np.ndarray,
        top_k: int = 5,
    ) -> list[tuple[ThemeNode, float]]:
        """
        Search themes by embedding similarity.
        
        Args:
            query_embedding: Query embedding.
            top_k: Number of results.
            
        Returns:
            List of (theme, similarity) tuples.
        """
        results: list[tuple[ThemeNode, float]] = []
        
        for theme in self._themes.values():
            if theme.centroid is None:
                continue
            
            sim = self._cosine_similarity(query_embedding, theme.centroid)
            results.append((theme, sim))
        
        results.sort(key=lambda x: x[1], reverse=True)
        
        for theme, _ in results[:top_k]:
            theme.access_count += 1
        
        return results[:top_k]
    
    def clear(self) -> None:
        """Clear all themes."""
        self._themes.clear()
    
    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "themes": [t.to_dict() for t in self._themes.values()],
        }
    
    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        semantic_memory: SemanticMemory,
        config: ThemeManagerConfig | None = None,
    ) -> ThemeManager:
        """Deserialize from dictionary."""
        manager = cls(semantic_memory, config)
        for theme_data in data.get("themes", []):
            theme = ThemeNode.from_dict(theme_data)
            manager._themes[theme.id] = theme
        return manager
    
    def get_stats(self) -> dict[str, Any]:
        """Get manager statistics."""
        if not self._themes:
            return {
                "total_themes": 0,
                "total_semantics": 0,
                "avg_theme_size": 0.0,
            }
        
        sizes = [t.member_count for t in self._themes.values()]
        return {
            "total_themes": len(self._themes),
            "total_semantics": sum(sizes),
            "avg_theme_size": float(np.mean(sizes)),
            "max_theme_size": max(sizes),
            "min_theme_size": min(sizes),
        }
