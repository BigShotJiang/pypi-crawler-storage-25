"""
OpenAI Responses API client for Poe, ZenMux, and other compatible providers.

The Responses API provides advanced capabilities beyond Chat Completions:
- Built-in reasoning and extended thinking support via `reasoning`
- Web search as a built-in tool (`web_search_preview`)
- Structured outputs with JSON schema via `text.format`
- Multi-turn conversations via `previous_response_id`

Supported providers:
- Poe: https://api.poe.com/v1
- ZenMux: https://zenmux.ai/api/v1

See: 
- https://creator.poe.com/docs/external-applications/responses-api
- https://zenmux.ai/docs/guide/advanced/tool-calls.html
"""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Callable

from openai import OpenAI
import httpx

from neoCoder.sdk.llm.base_client import BaseLLMClient, ToolDefinition, LLMResponse, InsufficientBalanceError
from neoCoder.sdk.llm.output_parser import Action


logger = logging.getLogger(__name__)


@dataclass
class ResponsesClientConfig:
    """Configuration for Responses API client."""
    
    model: str = "Claude-Sonnet-4.5"
    api_key: str | None = None
    base_url: str = "https://api.poe.com/v1"
    max_output_tokens: int = 8192
    temperature: float | None = None  # Only set if not using high reasoning
    top_p: float | None = None
    # Reasoning configuration
    reasoning_effort: str | None = "high"  # low, medium, high
    reasoning_summary: str | None = "auto"  # auto, concise, detailed
    # System instructions (maps to 'instructions' parameter)
    instructions: str | None = None
    # Multi-turn conversation
    previous_response_id: str | None = None
    # Enable web search tool
    enable_web_search: bool = False
    include_web_sources: bool = False
    # Tool choice: "auto", "none", "required", or {"type": "function", "name": "..."}
    tool_choice: str | dict | None = "auto"
    # Timeout
    timeout: int = 300
    # Custom headers
    default_headers: dict[str, str] = field(default_factory=dict)


class ResponsesAPIClient(BaseLLMClient):
    """
    OpenAI Responses API client for Poe and compatible providers.
    
    Supports:
    - Extended reasoning with effort levels (low/medium/high)
    - Built-in web search tool
    - Structured outputs with JSON schema
    - Multi-turn conversations via previous_response_id
    - Streaming responses
    """

    def __init__(self, config: ResponsesClientConfig | None = None, **kwargs):
        """
        Initialize Responses API client.
        
        Args:
            config: Client configuration.
            **kwargs: Override specific config values.
        """
        import os
        
        if config is None:
            config = ResponsesClientConfig()

        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        self.config = config
        self._api_key = (
            config.api_key 
            or os.environ.get("POE_API_KEY")
            or os.environ.get("ZENMUX_API_KEY")
            or os.environ.get("OPENAI_API_KEY")
        )

        if not self._api_key:
            raise ValueError(
                "API key required for Responses API.\n\n"
                "Set environment variable:\n"
                "  For Poe:    set POE_API_KEY=your-key\n"
                "  For ZenMux: set ZENMUX_API_KEY=your-key\n"
            )

        client_kwargs = {
            "api_key": self._api_key,
            "base_url": config.base_url,
            "timeout": config.timeout,
        }
        
        # Set default headers
        default_headers = config.default_headers.copy() if config.default_headers else {}
        default_headers["Content-Type"] = "application/json"
        client_kwargs["default_headers"] = default_headers

        self._client = OpenAI(**client_kwargs)
        self._tools: list[ToolDefinition] = []
        self._last_response_id: str | None = None

    def _build_request_params(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> dict[str, Any]:
        """Build request parameters for Responses API."""
        
        # Convert messages to input format
        # For Responses API, input can be a string or array of input items
        input_items = self._convert_messages_to_input(messages)
        
        params: dict[str, Any] = {
            "model": self.config.model,
            "input": input_items,
        }
        
        if self.config.max_output_tokens:
            params["max_output_tokens"] = self.config.max_output_tokens
        
        # Add temperature only if not using high reasoning
        if self.config.reasoning_effort not in ("medium", "high"):
            if self.config.temperature is not None:
                params["temperature"] = self.config.temperature
            if self.config.top_p is not None:
                params["top_p"] = self.config.top_p
        
        # Add instructions (system prompt)
        instructions = system or self.config.instructions
        if instructions:
            params["instructions"] = instructions
        
        # Add reasoning configuration
        if self.config.reasoning_effort:
            reasoning: dict[str, str] = {"effort": self.config.reasoning_effort}
            if self.config.reasoning_summary:
                reasoning["summary"] = self.config.reasoning_summary
            params["reasoning"] = reasoning
        
        # NOTE: We don't use previous_response_id since we pass full message history in input
        # previous_response_id would conflict with explicit input messages
        
        # Build tools list
        api_tools = []
        
        # Add web search if enabled
        if self.config.enable_web_search:
            api_tools.append({"type": "web_search_preview"})
            if self.config.include_web_sources:
                params["include"] = ["web_search_call.action.sources"]
        
        # Add function tools - Responses API uses flat format (name at top level)
        active_tools = tools if tools is not None else self._tools
        if active_tools:
            for t in active_tools:
                api_tools.append({
                    "type": "function",
                    "name": t.name,
                    "description": t.description,
                    "parameters": t.input_schema,
                })
        
        if api_tools:
            params["tools"] = api_tools
            # Add tool_choice to encourage tool use
            if self.config.tool_choice is not None:
                params["tool_choice"] = self.config.tool_choice
        
        return params

    def _convert_messages_to_input(
        self, messages: list[dict[str, Any]]
    ) -> str | list[dict[str, Any]]:
        """
        Convert chat messages to Responses API input format.
        
        For simple single user message, return string.
        For complex conversation, return array of input items.
        """
        # Filter out system messages (handled by 'instructions')
        non_system = [m for m in messages if m.get("role") != "system"]
        
        if not non_system:
            return ""
        
        # If single user message with string content, use simple format
        if len(non_system) == 1 and non_system[0].get("role") == "user":
            content = non_system[0].get("content", "")
            if isinstance(content, str):
                return content
        
        # Convert to input items format
        input_items = []
        for msg in non_system:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            if role == "user":
                if isinstance(content, str):
                    input_items.append({
                        "type": "message",
                        "role": "user",
                        "content": content,
                    })
                elif isinstance(content, list):
                    # Check for Anthropic-style tool_result in content list
                    has_tool_result = False
                    for item in content:
                        if isinstance(item, dict) and item.get("type") == "tool_result":
                            has_tool_result = True
                            input_items.append({
                                "type": "function_call_output",
                                "call_id": item.get("tool_use_id", ""),
                                "output": item.get("content", ""),
                            })
                    # If no tool_result, treat as regular multimodal content
                    if not has_tool_result:
                        input_items.append({
                            "type": "message",
                            "role": "user",
                            "content": content,
                        })
            elif role == "assistant":
                # Check for OpenAI-style tool_calls
                tool_calls = msg.get("tool_calls", [])
                if tool_calls:
                    for tc in tool_calls:
                        func = tc.get("function", {})
                        input_items.append({
                            "type": "function_call",
                            "call_id": tc.get("id", ""),
                            "name": func.get("name", ""),
                            "arguments": func.get("arguments", "{}"),
                        })
                # Check for Anthropic-style tool_use in content list
                elif isinstance(content, list):
                    for item in content:
                        if isinstance(item, dict):
                            item_type = item.get("type")
                            if item_type == "tool_use":
                                input_items.append({
                                    "type": "function_call",
                                    "call_id": item.get("id", ""),
                                    "name": item.get("name", ""),
                                    "arguments": json.dumps(item.get("input", {})),
                                })
                            elif item_type == "text" and item.get("text"):
                                input_items.append({
                                    "type": "message",
                                    "role": "assistant", 
                                    "content": item["text"],
                                })
                            else:
                                pass
                elif isinstance(content, str) and content:
                    input_items.append({
                        "type": "message",
                        "role": "assistant",
                        "content": content,
                    })
            elif role == "tool":
                # Tool result (OpenAI format)
                input_items.append({
                    "type": "function_call_output",
                    "call_id": msg.get("tool_call_id", ""),
                    "output": content if isinstance(content, str) else json.dumps(content),
                })
        
        return input_items if input_items else ""

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with the given messages using Responses API via httpx.
        """
        params = self._build_request_params(messages, system, tools)
        
        # Use httpx directly for full control over request format
        base_url = self.config.base_url or "https://api.openai.com/v1"
        url = f"{base_url.rstrip('/')}/responses"
        
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        
        try:
            logger.debug(f"Responses API: model={params.get('model')}, tools={len(params.get('tools', []))}")
            with httpx.Client(timeout=self.config.timeout) as client:
                resp = client.post(url, json=params, headers=headers)
                resp.raise_for_status()
                response_data = resp.json()
        except httpx.HTTPStatusError as e:
            error_str = str(e)
            try:
                error_body = e.response.json()
                error_str = str(error_body)
            except:
                pass
            logger.error(f"Responses API error: {error_str}")
            if "402" in error_str or "insufficient" in error_str.lower():
                raise InsufficientBalanceError(
                    "Insufficient balance for API", 
                    original_error=e
                )
            raise
        except Exception as e:
            logger.error(f"Responses API error: {e}")
            raise

        # Store response ID for multi-turn
        self._last_response_id = response_data.get("id")
        
        # Extract content and actions from response
        content = self._extract_output_text(response_data)
        actions = self._extract_actions_from_dict(response_data)
        
        # Build usage dict
        usage = {}
        resp_usage = response_data.get("usage", {})
        if resp_usage:
            usage = {
                "input_tokens": resp_usage.get("input_tokens", 0),
                "output_tokens": resp_usage.get("output_tokens", 0),
            }
            if resp_usage.get("total_tokens"):
                usage["total_tokens"] = resp_usage["total_tokens"]

        return LLMResponse(
            content=content,
            actions=actions,
            raw_response=response_data,
            stop_reason=response_data.get("status") or "completed",
            usage=usage,
            generation_id=response_data.get("id"),
        )

    def _extract_output_text(self, response_data: dict) -> str:
        """Extract text content from response output."""
        text_parts = []
        for item in response_data.get("output", []):
            if isinstance(item, dict):
                if item.get("type") == "message":
                    content = item.get("content", [])
                    if isinstance(content, str):
                        text_parts.append(content)
                    elif isinstance(content, list):
                        for c in content:
                            if isinstance(c, dict) and c.get("type") == "output_text":
                                text_parts.append(c.get("text", ""))
                            elif isinstance(c, dict) and c.get("type") == "text":
                                text_parts.append(c.get("text", ""))
        return "".join(text_parts)

    def _extract_actions_from_dict(self, response_data: dict) -> list[Action]:
        """Extract tool call actions from response dict."""
        actions = []
        
        for item in response_data.get("output", []):
            if not isinstance(item, dict):
                continue
            
            item_type = item.get("type")
            
            if item_type == "function_call":
                try:
                    args = item.get("arguments", "{}")
                    if isinstance(args, str):
                        args = json.loads(args)
                except json.JSONDecodeError:
                    args = {}
                
                actions.append(Action(
                    type="tool_use",
                    name=item.get("name", ""),
                    input=args,
                    id=item.get("call_id") or item.get("id", ""),
                ))
        
        return actions

    def _extract_actions(self, response) -> list[Action]:
        """Extract tool call actions from response output."""
        actions = []
        
        if not response.output:
            return actions
        
        for item in response.output:
            item_type = getattr(item, "type", None)
            
            if item_type == "function_call":
                try:
                    # Parse arguments if string
                    args = item.arguments
                    if isinstance(args, str):
                        args = json.loads(args)
                except (json.JSONDecodeError, AttributeError):
                    args = {}
                
                actions.append(Action(
                    type="tool_use",
                    name=getattr(item, "name", ""),
                    input=args,
                    id=getattr(item, "call_id", getattr(item, "id", "")),
                ))
            elif item_type == "web_search_call":
                # Web search tool call (informational)
                logger.info(f"Web search performed: {getattr(item, 'action', {})}")
        
        return actions

    def invoke_stream(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
        on_text: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with streaming using Responses API.
        
        Streaming event types:
        - response.output_text.delta: Text content delta
        - response.function_call_arguments.delta: Tool call arguments delta
        - response.completed: Final response
        """
        params = self._build_request_params(messages, system, tools)
        params["stream"] = True
        
        logger.debug(f"invoke_stream: model={params.get('model')}, tools={len(params.get('tools', []))}")
        
        base_url = self.config.base_url or "https://api.openai.com/v1"
        url = f"{base_url.rstrip('/')}/responses"
        
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        
        content_text = ""
        actions: list[Action] = []
        function_calls_data: dict[str, dict] = {}  # call_id -> {name, arguments}
        input_tokens = 0
        output_tokens = 0
        stop_reason = "completed"
        generation_id = None
        
        max_retries = 3
        retry_delay = 2
        
        for attempt in range(max_retries):
            try:
                with httpx.Client(timeout=self.config.timeout) as client:
                    with client.stream("POST", url, json=params, headers=headers) as resp:
                        resp.raise_for_status()
                        
                        for line in resp.iter_lines():
                            if not line or line.startswith(":"):
                                continue
                            if line == "data: [DONE]":
                                break
                            if line.startswith("data: "):
                                try:
                                    event = json.loads(line[6:])
                                except json.JSONDecodeError:
                                    continue
                                
                                event_type = event.get("type", "")
                                
                                # Handle response ID
                                if event.get("id") and not generation_id:
                                    generation_id = event["id"]
                                
                                # Handle output_item.added (contains function name)
                                if event_type == "response.output_item.added":
                                    item = event.get("item", {})
                                    if item.get("type") == "function_call":
                                        call_id = item.get("call_id", "")
                                        item_id = item.get("id", "")  # item.id maps to delta's item_id
                                        fn_name = item.get("name", "")
                                        # Store by BOTH call_id and item_id for lookup
                                        if fn_name:
                                            entry = {"name": fn_name, "arguments": "", "call_id": call_id}
                                            if call_id:
                                                function_calls_data[call_id] = entry
                                            if item_id:
                                                function_calls_data[item_id] = entry
                                
                                # Handle text delta
                                if event_type == "response.output_text.delta":
                                    delta = event.get("delta", "")
                                    if delta:
                                        content_text += delta
                                        if on_text:
                                            on_text(delta)
                                
                                # Handle function call arguments delta
                                elif event_type == "response.function_call_arguments.delta":
                                    # ZenMux uses item_id, not call_id for deltas
                                    lookup_id = event.get("call_id", "") or event.get("item_id", "")
                                    if lookup_id in function_calls_data:
                                        function_calls_data[lookup_id]["arguments"] += event.get("delta", "")
                                
                                # Handle function call done
                                elif event_type == "response.function_call_arguments.done":
                                    call_id = event.get("call_id", "")
                                    if call_id in function_calls_data:
                                        function_calls_data[call_id]["name"] = event.get("name", function_calls_data[call_id].get("name", ""))
                                
                                # Handle response completed
                                elif event_type == "response.completed":
                                    response_obj = event.get("response", {})
                                    if response_obj:
                                        generation_id = response_obj.get("id", generation_id)
                                        stop_reason = response_obj.get("status", "completed")
                                        
                                        # Extract usage
                                        usage_obj = response_obj.get("usage", {})
                                        if usage_obj:
                                            input_tokens = usage_obj.get("input_tokens", 0)
                                            output_tokens = usage_obj.get("output_tokens", 0)
                
                # Convert function calls to actions (deduplicate by call_id)
                seen_call_ids = set()
                for key, fc_data in function_calls_data.items():
                    # Use the stored call_id if available, otherwise use key
                    actual_call_id = fc_data.get("call_id", key)
                    if actual_call_id in seen_call_ids:
                        continue  # Skip duplicate (same entry stored under item_id and call_id)
                    seen_call_ids.add(actual_call_id)
                    
                    try:
                        args = json.loads(fc_data["arguments"]) if fc_data["arguments"] else {}
                    except json.JSONDecodeError:
                        args = {}
                    
                    if fc_data["name"]:  # Only add if we have a name
                        actions.append(Action(
                            type="tool_use",
                            name=fc_data["name"],
                            input=args,
                            id=actual_call_id,
                        ))
                
                break  # Success
                
            except (httpx.RemoteProtocolError, httpx.ReadTimeout, httpx.ConnectError) as e:
                if attempt < max_retries - 1:
                    logger.warning(f"Stream interrupted (attempt {attempt + 1}): {e}")
                    import time
                    time.sleep(retry_delay)
                    continue
                raise
            except httpx.HTTPStatusError as e:
                error_str = str(e)
                try:
                    error_body = e.response.json()
                    error_str = str(error_body)
                    logger.error(f"Responses API streaming error: {error_str}")
                    # Log input for debugging
                    import json as _json
                    logger.debug(f"Request params: {_json.dumps(params, default=str)[:1000]}")
                except:
                    pass
                if "402" in error_str or "insufficient" in error_str.lower():
                    raise InsufficientBalanceError(
                        "Insufficient balance for API",
                        original_error=e
                    )
                raise
            except Exception as e:
                logger.error(f"Responses API streaming error: {e}")
                raise

        # Store response ID for multi-turn
        if generation_id:
            self._last_response_id = generation_id

        usage = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        }

        return LLMResponse(
            content=content_text,
            actions=actions,
            raw_response=None,
            stop_reason=stop_reason,
            usage=usage,
            generation_id=generation_id,
        )

    def register_tool(self, tool: ToolDefinition) -> None:
        """Register a tool."""
        self._tools.append(tool)

    def clear_tools(self) -> None:
        """Clear all registered tools."""
        self._tools.clear()

    def count_tokens(self, text: str) -> int:
        """Approximate token count."""
        return len(text) // 4

    def get_last_response_id(self) -> str | None:
        """Get the last response ID for multi-turn conversations."""
        return self._last_response_id

    def set_previous_response_id(self, response_id: str | None) -> None:
        """Set the previous response ID for multi-turn conversations."""
        self._last_response_id = response_id
        self.config.previous_response_id = response_id

    def enable_web_search(self, enabled: bool = True, include_sources: bool = False) -> None:
        """Enable or disable built-in web search tool."""
        self.config.enable_web_search = enabled
        self.config.include_web_sources = include_sources
