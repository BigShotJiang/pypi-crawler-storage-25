"""
Native Anthropic API client.

Uses the official Anthropic SDK directly without custom base_url.
Optimized for official API features and behavior.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass
from typing import Any, Callable

import anthropic
import httpx
from anthropic.types import Message, ToolUseBlock, TextBlock

from neoCoder.sdk.llm.base_client import BaseLLMClient, ToolDefinition, LLMResponse
from neoCoder.sdk.llm.output_parser import Action, OutputParser


logger = logging.getLogger(__name__)


@dataclass
class ClaudeClientConfig:
    """Configuration for the Claude client."""

    model: str = "claude-sonnet-4-5-20241022"
    max_tokens: int = 8192
    temperature: float = 0.0
    api_key: str | None = None
    use_native_tools: bool = True
    
    # Extended thinking configuration
    thinking_budget: int | None = None
    thinking_effort: str | None = None  # "low", "medium", "high" - auto-calculates thinking_budget
    thinking_mode: str | None = None  # "auto", "enabled", "adaptive", "disabled"
    thinking_display: str | None = None  # "summarized", "omitted"
    
    # Reasoning effort (OpenAI o1 models via ZenMux)
    reasoning_effort: str | None = None

    # Sampling parameters
    top_p: float | None = None  # Nucleus sampling (0.0-1.0)
    top_k: int | None = None  # Top-K sampling
    stop_sequences: list[str] | None = None  # Custom stop sequences
    
    # Metadata
    user_id: str | None = None  # For metadata.user_id
    metadata: dict[str, Any] | None = None  # Full metadata dict
    
    # Tool control
    tool_choice: Any | None = None  # "auto", "none", {"type": "tool", "name": "..."}, etc.
    
    # Caching
    cache_control: dict[str, Any] | None = None  # e.g. {"type": "ephemeral", "ttl": "5m"}

    # Transport / routing
    base_url: str | None = None
    use_zenmux_format: bool = False
    force_native_anthropic: bool = False
    force_custom_api: bool = False
    use_responses_api: bool = False  # Use OpenAI Responses API instead of Chat Completions
    default_headers: dict[str, str] | None = None  # Custom headers for proxy/custom endpoints
    timeout: int | None = 60  # Request timeout in seconds


class NativeAnthropicClient(BaseLLMClient):
    """
    Native Anthropic API client.
    
    Uses official Anthropic SDK directly without custom base_url.
    Optimized for official API features and behavior.
    """

    def __init__(self, config: ClaudeClientConfig | None = None, **kwargs):
        """
        Initialize native Anthropic client.
        
        Args:
            config: Client configuration. If not provided, uses defaults.
            **kwargs: Override specific config values.
        
        Raises:
            ValueError: If API key is not provided.
        """
        if config is None:
            config = ClaudeClientConfig()

        # Apply any overrides
        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        self.config = config
        self._api_key = config.api_key or os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_AUTH_TOKEN")

        if not self._api_key:
            raise ValueError(
                "API key required for native Anthropic client. "
                "Set ANTHROPIC_API_KEY or ANTHROPIC_AUTH_TOKEN environment variable "
                "or pass api_key in config."
            )

        # Initialize official Anthropic client (no base_url)
        self._client = anthropic.Anthropic(api_key=self._api_key)
        self._parser = OutputParser()
        self._tools: list[ToolDefinition] = []

        logger.info("Initialized NativeAnthropicClient")

    def _calculate_thinking_budget(self, max_tokens: int) -> int | None:
        """
        Auto-calculate thinking_budget based on thinking_effort and max_tokens.
        
        Similar to OpenAI's reasoning.max_tokens calculation:
        - low: 20% of max_tokens
        - medium: 50% of max_tokens  
        - high: 80% of max_tokens
        
        Anthropic API Requirements:
        - budget_tokens must be >= 1024
        - budget_tokens must be < max_tokens
        
        Args:
            max_tokens: Maximum completion tokens
            
        Returns:
            Calculated thinking_budget or None if thinking not enabled
        """
        # If thinking_budget explicitly set, validate and use it
        if self.config.thinking_budget is not None:
            budget = self.config.thinking_budget
            
            # Validate: must be >= 1024
            if budget < 1024:
                logger.warning(f"thinking_budget ({budget}) < 1024, setting to minimum 1024")
                budget = 1024
            
            # Validate: must be < max_tokens
            if budget >= max_tokens:
                logger.warning(f"thinking_budget ({budget}) >= max_tokens ({max_tokens}), adjusting")
                budget = max(1024, max_tokens - 1024)
            
            return budget
            
        # If thinking_effort not set, no auto-calculation
        if not self.config.thinking_effort:
            return None
            
        # Calculate based on effort level
        effort_ratios = {
            "low": 0.20,
            "medium": 0.50,
            "high": 0.80
        }
        
        effort = self.config.thinking_effort.lower()
        if effort not in effort_ratios:
            logger.warning(f"Invalid thinking_effort '{effort}', expected low/medium/high")
            return None
            
        budget = int(max_tokens * effort_ratios[effort])
        
        # Ensure minimum 1024 tokens
        if budget < 1024:
            logger.warning(f"Calculated budget ({budget}) < 1024, setting to minimum")
            budget = 1024
        
        # Ensure < max_tokens
        if budget >= max_tokens:
            logger.warning(f"Calculated budget ({budget}) >= max_tokens ({max_tokens}), adjusting")
            budget = max(1024, max_tokens - 1024)
        
        logger.debug(f"Auto-calculated thinking_budget: {budget} ({effort} effort, {max_tokens} max_tokens)")
        return budget

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """
        Invoke native Anthropic API.
        
        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools to use for this invocation (overrides registered tools).

        Returns:
            LLMResponse containing the response content and any parsed actions.
        """
        request_kwargs: dict[str, Any] = {
            "model": self.config.model,  # Use model name as-is
            "max_tokens": self.config.max_tokens,
            "messages": messages,
        }

        if system:
            request_kwargs["system"] = system

        # Sampling parameters
        if self.config.top_p is not None:
            request_kwargs["top_p"] = self.config.top_p
        if self.config.top_k is not None:
            request_kwargs["top_k"] = self.config.top_k
        if self.config.stop_sequences:
            request_kwargs["stop_sequences"] = self.config.stop_sequences

        # Metadata (user_id for tracking)
        metadata: dict[str, Any] = {}
        if self.config.metadata:
            metadata.update(self.config.metadata)
        if self.config.user_id:
            metadata.setdefault("user_id", self.config.user_id)
        if metadata:
            request_kwargs["metadata"] = metadata

        # Cache control
        if self.config.cache_control:
            request_kwargs["cache_control"] = self.config.cache_control

        # Add tools if using native tool use
        active_tools = tools if tools is not None else self._tools
        if self.config.use_native_tools and active_tools:
            request_kwargs["tools"] = [
                {
                    "name": t.name,
                    "description": t.description,
                    "input_schema": t.input_schema,
                }
                for t in active_tools
            ]
            # Tool choice (only valid when tools present)
            if self.config.tool_choice is not None:
                request_kwargs["tool_choice"] = self.config.tool_choice

        # Add thinking parameter for Anthropic Extended Thinking
        # When thinking is enabled: temperature MUST be 1, top_k is not supported
        # See: https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking
        thinking_budget = self._calculate_thinking_budget(self.config.max_tokens)
        thinking_mode = (self.config.thinking_mode or "auto").lower()
        thinking: dict[str, Any] | None = None

        if thinking_mode == "disabled":
            thinking = {"type": "disabled"}
        elif thinking_budget:
            t_type = "enabled"
            if thinking_mode == "adaptive":
                t_type = "adaptive"
            elif thinking_mode not in ("auto", "enabled"):
                logger.warning(f"Unknown thinking_mode '{thinking_mode}', defaulting to 'enabled'")
            thinking = {
                "type": t_type,
                "budget_tokens": thinking_budget,
            }

        if thinking:
            if self.config.thinking_display:
                thinking["display"] = self.config.thinking_display
            request_kwargs["thinking"] = thinking
            # Extended Thinking constraint: temperature must be 1, top_k not allowed
            request_kwargs["temperature"] = 1
            if "top_k" in request_kwargs:
                logger.warning("top_k is not supported with Extended Thinking; removing top_k")
                request_kwargs.pop("top_k", None)
        elif self.config.temperature > 0:
            request_kwargs["temperature"] = self.config.temperature

        # Make API call
        response = self._client.messages.create(**request_kwargs)

        # Parse response
        return self._parse_response(response)

    def invoke_stream(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
        on_text: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """
        Invoke with streaming.
        
        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools for this invocation.
            on_text: Callback for each text chunk.

        Returns:
            Complete LLMResponse after stream finishes.
        """
        request_kwargs: dict[str, Any] = {
            "model": self.config.model,
            "max_tokens": self.config.max_tokens,
            "messages": messages,
        }

        if system:
            request_kwargs["system"] = system

        # Sampling parameters
        if self.config.top_p is not None:
            request_kwargs["top_p"] = self.config.top_p
        if self.config.top_k is not None:
            request_kwargs["top_k"] = self.config.top_k
        if self.config.stop_sequences:
            request_kwargs["stop_sequences"] = self.config.stop_sequences

        # Metadata (user_id for tracking)
        metadata: dict[str, Any] = {}
        if self.config.metadata:
            metadata.update(self.config.metadata)
        if self.config.user_id:
            metadata.setdefault("user_id", self.config.user_id)
        if metadata:
            request_kwargs["metadata"] = metadata

        # Cache control
        if self.config.cache_control:
            request_kwargs["cache_control"] = self.config.cache_control

        active_tools = tools if tools is not None else self._tools
        if self.config.use_native_tools and active_tools:
            request_kwargs["tools"] = [
                {
                    "name": t.name,
                    "description": t.description,
                    "input_schema": t.input_schema,
                }
                for t in active_tools
            ]
            # Tool choice (only valid when tools present)
            if self.config.tool_choice is not None:
                request_kwargs["tool_choice"] = self.config.tool_choice

        # Add thinking parameter for Anthropic Extended Thinking
        # When thinking is enabled: temperature MUST be 1, top_k is not supported
        thinking_budget = self._calculate_thinking_budget(self.config.max_tokens)
        thinking_mode = (self.config.thinking_mode or "auto").lower()
        thinking: dict[str, Any] | None = None

        if thinking_mode == "disabled":
            thinking = {"type": "disabled"}
        elif thinking_budget:
            t_type = "enabled"
            if thinking_mode == "adaptive":
                t_type = "adaptive"
            elif thinking_mode not in ("auto", "enabled"):
                logger.warning(f"Unknown thinking_mode '{thinking_mode}', defaulting to 'enabled'")
            thinking = {
                "type": t_type,
                "budget_tokens": thinking_budget,
            }

        if thinking:
            if self.config.thinking_display:
                thinking["display"] = self.config.thinking_display
            request_kwargs["thinking"] = thinking
            # Extended Thinking constraint: temperature must be 1, top_k not allowed
            request_kwargs["temperature"] = 1
            if "top_k" in request_kwargs:
                logger.warning("top_k is not supported with Extended Thinking; removing top_k")
                request_kwargs.pop("top_k", None)
        elif self.config.temperature > 0:
            request_kwargs["temperature"] = self.config.temperature

        content_text = ""
        actions: list[Action] = []
        input_tokens = 0
        output_tokens = 0
        stop_reason = ""
        stream = None
        final_message = None

        max_retries = 3
        retry_delay = 2  # seconds

        for attempt in range(max_retries):
            try:
                stream = self._client.messages.stream(**request_kwargs)
                with stream:
                    for event in stream:
                        if hasattr(event, "type"):
                            if event.type == "content_block_delta":
                                if hasattr(event.delta, "text"):
                                    chunk = event.delta.text
                                    content_text += chunk
                                    if on_text:
                                        on_text(chunk)
                            elif event.type == "message_start":
                                if hasattr(event.message, "usage"):
                                    input_tokens = event.message.usage.input_tokens
                            elif event.type == "message_delta":
                                if hasattr(event, "usage"):
                                    output_tokens = event.usage.output_tokens
                                if hasattr(event.delta, "stop_reason"):
                                    stop_reason = event.delta.stop_reason

                    final_message = stream.get_final_message()
                    for block in final_message.content:
                        if isinstance(block, ToolUseBlock):
                            actions.append(
                                Action(
                                    type="tool_use",
                                    name=block.name,
                                    input=block.input,
                                    id=block.id,
                                )
                            )
                
                # Success - break out of retry loop
                break

            except (httpx.RemoteProtocolError, httpx.ReadTimeout, httpx.ConnectError) as e:
                if attempt < max_retries - 1:
                    logger.warning(
                        f"Stream interrupted (attempt {attempt + 1}/{max_retries}): {e}. "
                        f"Retrying in {retry_delay}s..."
                    )
                    import time
                    time.sleep(retry_delay)
                    retry_delay *= 2  # Exponential backoff
                    continue
                else:
                    logger.error(f"Stream failed after {max_retries} attempts: {e}", exc_info=True)
                    raise
            except Exception as e:
                logger.error(f"Stream error: {e}", exc_info=True)
                raise
            finally:
                # Ensure stream is properly closed
                if stream is not None:
                    try:
                        if hasattr(stream, 'close'):
                            stream.close()
                    except Exception as cleanup_error:
                        logger.warning(f"Error during stream cleanup: {cleanup_error}")

        # Parse XML if not using native tools
        if not self.config.use_native_tools and content_text:
            xml_actions = self._parser.parse_xml_tags(content_text)
            actions.extend(xml_actions)

        # Extract generation ID from final message
        generation_id = getattr(final_message, 'id', None) if final_message else None

        return LLMResponse(
            content=content_text,
            actions=actions,
            raw_response=final_message,
            stop_reason=stop_reason,
            usage={
                "input_tokens": input_tokens,
                "output_tokens": output_tokens,
            },
            generation_id=generation_id,
        )

    def register_tool(self, tool: ToolDefinition) -> None:
        """Register a tool that can be used by the LLM."""
        self._tools.append(tool)

    def clear_tools(self) -> None:
        """Clear all registered tools."""
        self._tools.clear()

    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text using tiktoken (approximate for Claude).

        Args:
            text: Text to count tokens for.

        Returns:
            Approximate token count.
        """
        try:
            import tiktoken

            # Use cl100k_base as approximate for Claude
            enc = tiktoken.get_encoding("cl100k_base")
            return len(enc.encode(text))
        except ImportError:
            # Rough estimate if tiktoken not available
            return len(text) // 4

    def _parse_response(self, response: Message) -> LLMResponse:
        """
        Parse Anthropic API response.
        
        Args:
            response: Raw Anthropic API response.
            
        Returns:
            Parsed LLMResponse.
        """
        content_text = ""
        actions: list[Action] = []

        for block in response.content:
            if isinstance(block, TextBlock):
                content_text += block.text
            elif isinstance(block, ToolUseBlock):
                actions.append(
                    Action(
                        type="tool_use",
                        name=block.name,
                        input=block.input,
                        id=block.id,
                    )
                )

        # If not using native tools, parse XML tags from text
        if not self.config.use_native_tools and content_text:
            xml_actions = self._parser.parse_xml_tags(content_text)
            actions.extend(xml_actions)

        # Extract generation ID from response
        generation_id = getattr(response, 'id', None)

        return LLMResponse(
            content=content_text,
            actions=actions,
            raw_response=response,
            stop_reason=response.stop_reason,
            usage={
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens,
            },
            generation_id=generation_id,
        )
