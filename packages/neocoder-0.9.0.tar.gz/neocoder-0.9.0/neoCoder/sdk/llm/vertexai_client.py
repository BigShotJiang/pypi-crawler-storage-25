"""
Google Vertex AI API client via ZenMux.

Uses the Google Gen AI SDK for Vertex AI compatible API.
Supports Gemini 2.5/3 models with thinking, tool calling, and streaming.

Endpoint: https://zenmux.ai/api/vertex-ai

See: https://zenmux.ai/docs/api/vertexai/generate-content.html
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Callable

from neoCoder.sdk.llm.base_client import BaseLLMClient, ToolDefinition, LLMResponse, InsufficientBalanceError
from neoCoder.sdk.llm.output_parser import Action


logger = logging.getLogger(__name__)


@dataclass
class VertexAIClientConfig:
    """Configuration for Vertex AI client via ZenMux."""
    
    model: str = "google/gemini-2.5-pro"
    api_key: str | None = None
    base_url: str = "https://zenmux.ai/api/vertex-ai"
    api_version: str = "v1"
    max_output_tokens: int = 8192
    temperature: float | None = None
    top_p: float | None = None
    top_k: int | None = None
    # Thinking configuration (Gemini 2.5/3)
    thinking_budget: int | None = None  # Token budget for thinking (Gemini 2.5)
    thinking_level: str | None = None  # MINIMAL, LOW, MEDIUM, HIGH (Gemini 3)
    # Response format
    response_mime_type: str | None = None  # text/plain, application/json
    response_schema: dict | None = None  # JSON schema for structured output
    # System instruction
    system_instruction: str | None = None
    # Timeout
    timeout: int = 300


class VertexAIClient(BaseLLMClient):
    """
    Google Vertex AI API client via ZenMux.
    
    Supports:
    - Gemini 2.5/3 models
    - Thinking configuration (thinkingBudget for 2.5, thinkingLevel for 3)
    - Tool calling with FunctionDeclaration format
    - Structured output with JSON schema
    - Streaming responses
    """

    def __init__(self, config: VertexAIClientConfig | None = None, **kwargs):
        """
        Initialize Vertex AI client.
        
        Args:
            config: Client configuration.
            **kwargs: Override specific config values.
        """
        if config is None:
            config = VertexAIClientConfig()

        for key, value in kwargs.items():
            if hasattr(config, key):
                setattr(config, key, value)

        self.config = config
        self._api_key = (
            config.api_key 
            or os.environ.get("ZENMUX_API_KEY")
            or os.environ.get("GOOGLE_API_KEY")
        )

        if not self._api_key:
            raise ValueError(
                "API key required for Vertex AI API.\n\n"
                "Set environment variable:\n"
                "  set ZENMUX_API_KEY=your-key\n"
            )

        # Initialize Google Gen AI client
        try:
            from google import genai
            from google.genai import types
            
            self._genai = genai
            self._types = types
            
            self._client = genai.Client(
                api_key=self._api_key,
                vertexai=True,
                http_options=types.HttpOptions(
                    api_version=config.api_version,
                    base_url=config.base_url,
                ),
            )
        except ImportError:
            raise ImportError(
                "google-genai package required for Vertex AI client.\n"
                "Install with: pip install google-genai"
            )

        self._tools: list[ToolDefinition] = []

    def _build_generation_config(self) -> dict[str, Any]:
        """Build generation configuration."""
        config: dict[str, Any] = {}
        
        if self.config.max_output_tokens:
            config["max_output_tokens"] = self.config.max_output_tokens
        
        if self.config.temperature is not None:
            config["temperature"] = self.config.temperature
        
        if self.config.top_p is not None:
            config["top_p"] = self.config.top_p
        
        if self.config.top_k is not None:
            config["top_k"] = self.config.top_k
        
        # Thinking configuration
        if self.config.thinking_budget is not None:
            config["thinking_config"] = {"thinking_budget": self.config.thinking_budget}
        elif self.config.thinking_level:
            config["thinking_config"] = {"thinking_level": self.config.thinking_level}
        
        # Response format
        if self.config.response_mime_type:
            config["response_mime_type"] = self.config.response_mime_type
        
        if self.config.response_schema:
            config["response_schema"] = self.config.response_schema
        
        return config

    def _build_tools(
        self, tools: list[ToolDefinition] | None = None
    ) -> list[Any] | None:
        """Build tools in Vertex AI format (FunctionDeclaration)."""
        active_tools = tools if tools is not None else self._tools
        
        if not active_tools:
            return None
        
        function_declarations = []
        for t in active_tools:
            func_decl = self._types.FunctionDeclaration(
                name=t.name,
                description=t.description,
                parameters=t.input_schema,
            )
            function_declarations.append(func_decl)
        
        return [self._types.Tool(function_declarations=function_declarations)]

    def _convert_messages_to_contents(
        self, messages: list[dict[str, Any]]
    ) -> list[Any]:
        """Convert chat messages to Vertex AI contents format."""
        contents = []
        
        for msg in messages:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            
            # Skip system messages (handled separately)
            if role == "system":
                continue
            
            # Map roles
            vertex_role = "user" if role == "user" else "model"
            
            if role == "tool":
                # Tool result -> function_response
                contents.append(
                    self._types.Content(
                        role="user",
                        parts=[
                            self._types.Part(
                                function_response=self._types.FunctionResponse(
                                    name=msg.get("name", ""),
                                    response={"result": content},
                                )
                            )
                        ],
                    )
                )
            elif isinstance(content, str):
                contents.append(
                    self._types.Content(
                        role=vertex_role,
                        parts=[self._types.Part(text=content)],
                    )
                )
            elif isinstance(content, list):
                # Multimodal content
                parts = []
                for item in content:
                    if isinstance(item, dict):
                        if item.get("type") == "text":
                            parts.append(self._types.Part(text=item.get("text", "")))
                        elif item.get("type") == "image_url":
                            # Handle image
                            url = item.get("image_url", {}).get("url", "")
                            if url.startswith("data:"):
                                # Base64 inline data
                                mime_type, data = self._parse_data_url(url)
                                parts.append(
                                    self._types.Part(
                                        inline_data=self._types.Blob(
                                            mime_type=mime_type,
                                            data=data,
                                        )
                                    )
                                )
                    elif isinstance(item, str):
                        parts.append(self._types.Part(text=item))
                
                if parts:
                    contents.append(
                        self._types.Content(role=vertex_role, parts=parts)
                    )
        
        return contents

    def _parse_data_url(self, data_url: str) -> tuple[str, bytes]:
        """Parse data URL to extract mime type and data."""
        import base64
        
        # Format: data:mime_type;base64,data
        if not data_url.startswith("data:"):
            return "application/octet-stream", b""
        
        header, encoded = data_url.split(",", 1)
        mime_type = header.split(":")[1].split(";")[0]
        data = base64.b64decode(encoded)
        
        return mime_type, data

    def _extract_system_instruction(
        self, messages: list[dict[str, Any]], system: str | None
    ) -> str | None:
        """Extract system instruction from messages or parameter."""
        if system:
            return system
        
        if self.config.system_instruction:
            return self.config.system_instruction
        
        # Check for system message in messages
        for msg in messages:
            if msg.get("role") == "system":
                content = msg.get("content", "")
                if isinstance(content, str):
                    return content
        
        return None

    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with the given messages using Vertex AI API.
        """
        contents = self._convert_messages_to_contents(messages)
        generation_config = self._build_generation_config()
        vertex_tools = self._build_tools(tools)
        system_instruction = self._extract_system_instruction(messages, system)
        
        request_kwargs: dict[str, Any] = {
            "model": self.config.model,
            "contents": contents,
        }
        
        if generation_config:
            request_kwargs["config"] = self._types.GenerateContentConfig(
                **generation_config,
                tools=vertex_tools,
                system_instruction=system_instruction,
            )
        elif vertex_tools or system_instruction:
            request_kwargs["config"] = self._types.GenerateContentConfig(
                tools=vertex_tools,
                system_instruction=system_instruction,
            )
        
        try:
            logger.debug(f"Vertex AI request: model={self.config.model}")
            response = self._client.models.generate_content(**request_kwargs)
        except Exception as e:
            error_str = str(e)
            logger.error(f"Vertex AI API error: {error_str}")
            if "402" in error_str or "insufficient" in error_str.lower():
                raise InsufficientBalanceError(
                    "Insufficient balance for Vertex AI API",
                    original_error=e
                )
            raise

        # Extract content
        content = response.text if hasattr(response, "text") else ""
        
        # Extract tool calls (function calls)
        actions = self._extract_actions(response)
        
        # Build usage
        usage = {}
        if hasattr(response, "usage_metadata") and response.usage_metadata:
            um = response.usage_metadata
            usage = {
                "input_tokens": getattr(um, "prompt_token_count", 0),
                "output_tokens": getattr(um, "candidates_token_count", 0),
            }
            if hasattr(um, "thoughts_token_count"):
                usage["thinking_tokens"] = um.thoughts_token_count

        # Get finish reason
        stop_reason = "stop"
        if response.candidates:
            finish_reason = getattr(response.candidates[0], "finish_reason", None)
            if finish_reason:
                stop_reason = str(finish_reason)

        return LLMResponse(
            content=content,
            actions=actions,
            raw_response=response,
            stop_reason=stop_reason,
            usage=usage,
            generation_id=getattr(response, "response_id", None),
        )

    def _extract_actions(self, response) -> list[Action]:
        """Extract function call actions from response."""
        actions = []
        
        if not response.candidates:
            return actions
        
        candidate = response.candidates[0]
        if not hasattr(candidate, "content") or not candidate.content:
            return actions
        
        for part in candidate.content.parts:
            if hasattr(part, "function_call") and part.function_call:
                fc = part.function_call
                actions.append(Action(
                    type="tool_use",
                    name=getattr(fc, "name", ""),
                    input=dict(getattr(fc, "args", {})),
                    id=getattr(fc, "id", f"call_{len(actions)}"),
                ))
        
        return actions

    def invoke_stream(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
        on_text: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with streaming using Vertex AI API.
        """
        contents = self._convert_messages_to_contents(messages)
        generation_config = self._build_generation_config()
        vertex_tools = self._build_tools(tools)
        system_instruction = self._extract_system_instruction(messages, system)
        
        request_kwargs: dict[str, Any] = {
            "model": self.config.model,
            "contents": contents,
        }
        
        if generation_config:
            request_kwargs["config"] = self._types.GenerateContentConfig(
                **generation_config,
                tools=vertex_tools,
                system_instruction=system_instruction,
            )
        elif vertex_tools or system_instruction:
            request_kwargs["config"] = self._types.GenerateContentConfig(
                tools=vertex_tools,
                system_instruction=system_instruction,
            )
        
        content_text = ""
        actions: list[Action] = []
        input_tokens = 0
        output_tokens = 0
        thinking_tokens = 0
        stop_reason = "stop"
        generation_id = None
        
        try:
            logger.debug(f"Vertex AI stream request: model={self.config.model}")
            
            for chunk in self._client.models.generate_content_stream(**request_kwargs):
                # Extract response ID
                if hasattr(chunk, "response_id") and chunk.response_id:
                    generation_id = chunk.response_id
                
                # Extract text
                if hasattr(chunk, "text") and chunk.text:
                    content_text += chunk.text
                    if on_text:
                        on_text(chunk.text)
                
                # Extract function calls from chunk
                chunk_actions = self._extract_actions(chunk)
                actions.extend(chunk_actions)
                
                # Extract usage from final chunk
                if hasattr(chunk, "usage_metadata") and chunk.usage_metadata:
                    um = chunk.usage_metadata
                    input_tokens = getattr(um, "prompt_token_count", 0)
                    output_tokens = getattr(um, "candidates_token_count", 0)
                    if hasattr(um, "thoughts_token_count"):
                        thinking_tokens = um.thoughts_token_count
                
                # Extract finish reason
                if chunk.candidates:
                    finish_reason = getattr(chunk.candidates[0], "finish_reason", None)
                    if finish_reason:
                        stop_reason = str(finish_reason)
                        
        except Exception as e:
            error_str = str(e)
            logger.error(f"Vertex AI stream error: {error_str}")
            if "402" in error_str or "insufficient" in error_str.lower():
                raise InsufficientBalanceError(
                    "Insufficient balance for Vertex AI API",
                    original_error=e
                )
            raise

        usage = {
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        }
        if thinking_tokens:
            usage["thinking_tokens"] = thinking_tokens

        return LLMResponse(
            content=content_text,
            actions=actions,
            raw_response=None,
            stop_reason=stop_reason,
            usage=usage,
            generation_id=generation_id,
        )

    def register_tool(self, tool: ToolDefinition) -> None:
        """Register a tool."""
        self._tools.append(tool)

    def clear_tools(self) -> None:
        """Clear all registered tools."""
        self._tools.clear()

    def count_tokens(self, text: str) -> int:
        """Approximate token count."""
        return len(text) // 4
