"""
Base LLM client interface.

Defines the abstract interface that all LLM clients must implement,
ensuring consistent behavior across different API providers.

Supports both sync and async operations for flexible integration.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable

from neoCoder.sdk.llm.output_parser import Action


class InsufficientBalanceError(Exception):
    """Raised when API returns 402 - insufficient balance/credits."""
    
    def __init__(self, message: str = "Insufficient balance", original_error: Exception | None = None):
        super().__init__(message)
        self.original_error = original_error


@dataclass
class ToolDefinition:
    """Definition of a tool that can be used by the LLM."""

    name: str
    description: str
    input_schema: dict[str, Any]


@dataclass
class LLMResponse:
    """Response from an LLM invocation."""

    content: str
    actions: list[Action]
    raw_response: Any
    stop_reason: str
    usage: dict[str, int]
    metadata: dict[str, Any] | None = None  # Additional metadata (reasoning, annotations, etc.)
    generation_id: str | None = None  # Generation ID for token tracking


class BaseLLMClient(ABC):
    """
    Abstract base class for LLM clients.
    
    All LLM client implementations must inherit from this class and
    implement its abstract methods. This ensures a consistent interface
    across different API providers (native Anthropic, custom APIs, etc.).
    """

    @abstractmethod
    def invoke(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with the given messages.

        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools to use for this invocation (overrides registered tools).

        Returns:
            LLMResponse containing the response content and any parsed actions.
        """
        pass

    @abstractmethod
    def invoke_stream(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
        on_text: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """
        Invoke the LLM with streaming, calling on_text for each text chunk.

        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools for this invocation.
            on_text: Callback for each text chunk.

        Returns:
            Complete LLMResponse after stream finishes.
        """
        pass

    @abstractmethod
    def register_tool(self, tool: ToolDefinition) -> None:
        """
        Register a tool that can be used by the LLM.
        
        Args:
            tool: Tool definition to register.
        """
        pass

    @abstractmethod
    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text.

        Args:
            text: Text to count tokens for.

        Returns:
            Approximate token count.
        """
        pass

    def register_tools(self, tools: list[ToolDefinition]) -> None:
        """
        Register multiple tools.
        
        Args:
            tools: List of tool definitions to register.
        """
        for tool in tools:
            self.register_tool(tool)

    def clear_tools(self) -> None:
        """Clear all registered tools."""
        # Default implementation - subclasses can override
        pass

    # ------------------------------------------------------------------
    # Async methods (default implementations use thread pool)
    # ------------------------------------------------------------------

    async def invoke_async(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
    ) -> LLMResponse:
        """
        Async version of invoke.
        
        Default implementation runs sync invoke in thread pool.
        Subclasses can override for native async support.

        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools for this invocation.

        Returns:
            LLMResponse containing the response content and any parsed actions.
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.invoke(messages, system, tools)
        )

    async def invoke_stream_async(
        self,
        messages: list[dict[str, Any]],
        system: str | None = None,
        tools: list[ToolDefinition] | None = None,
        on_text: Callable[[str], None] | None = None,
    ) -> LLMResponse:
        """
        Async version of invoke_stream.
        
        Default implementation runs sync invoke_stream in thread pool.
        Subclasses can override for native async support.

        Args:
            messages: List of conversation messages.
            system: Optional system prompt.
            tools: Optional tools for this invocation.
            on_text: Callback for each text chunk.

        Returns:
            Complete LLMResponse after stream finishes.
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.invoke_stream(messages, system, tools, on_text)
        )
