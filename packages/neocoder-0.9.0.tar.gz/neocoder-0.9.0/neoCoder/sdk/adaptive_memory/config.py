"""
Configuration for Adaptive Memory Management.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class WorkingMemoryConfig:
    """Configuration for working memory."""
    
    compression_threshold: float = 0.8
    rolling_window_size: int = 10
    max_tokens: int = 4000


@dataclass
class AdaptiveMemoryResult:
    """Result from adaptive memory configuration with metadata."""
    
    config: WorkingMemoryConfig
    task_type: str
    complexity: float
    

@dataclass
class AdaptiveMemoryConfig:
    """Configuration for adaptive memory management."""
    
    enabled: bool = True
    default_compression_threshold: float = 0.8
    default_rolling_window: int = 10
    
    # Task-specific overrides
    debug_compression_threshold: float = 0.9
    debug_rolling_window: int = 15
    
    refactor_compression_threshold: float = 0.7
    refactor_rolling_window: int = 8
    
    # Complexity adjustments
    high_complexity_threshold: float = 0.8
    low_complexity_threshold: float = 0.3
    complexity_adjustment: float = 0.05

