"""
Adaptive Memory Manager.

Dynamically adjusts memory parameters based on task type and complexity.
"""

from typing import Dict, Any, Optional
from neoCoder.sdk.adaptive_memory.config import (
    AdaptiveMemoryConfig,
    AdaptiveMemoryResult,
    WorkingMemoryConfig,
)


class TaskClassifier:
    """Classifies tasks into categories using regex for better boundary matching."""

    def classify(self, task: str) -> str:
        """
        Classify task type.

        Args:
            task: Task description

        Returns:
            Task type: 'debug', 'refactor', 'coding', etc.
        """
        import re
        task_lower = task.lower()

        # Debug keywords (most specific)
        debug_pattern = r'\b(debug|fix\s+bug|fix\s+error|bug|issue)\b'
        if re.search(debug_pattern, task_lower):
            return 'debug'

        # Refactor keywords
        refactor_pattern = r'\b(refactor|clean|optimize|improve|restructure)\b'
        if re.search(refactor_pattern, task_lower):
            return 'refactor'

        # Fix without bug/error is still debug
        if re.search(r'\bfix\b', task_lower):
            return 'debug'

        # Default to coding
        return 'coding'


class ComplexityEstimator:
    """Estimates task complexity."""
    
    def estimate(self, task: str, context: Dict[str, Any]) -> float:
        """
        Estimate task complexity (0.0 to 1.0).
        
        Args:
            task: Task description
            context: Additional context
            
        Returns:
            Complexity score (0.0 = simple, 1.0 = complex)
        """
        complexity = 0.5  # Default medium complexity
        explicit_complexity = False
        
        # Check context for complexity hints
        if 'complexity' in context:
            complexity_str = str(context['complexity']).lower()
            if complexity_str == 'simple':
                complexity = 0.25
                explicit_complexity = True
            elif complexity_str == 'medium':
                complexity = 0.5
                explicit_complexity = True
            elif complexity_str == 'complex':
                complexity = 0.9
                explicit_complexity = True
        
        # Adjust based on task length only if complexity was not explicitly set
        if not explicit_complexity:
            task_length = len(task.split())
            if task_length > 50:
                complexity += 0.15
            elif task_length < 5:
                complexity -= 0.1
        
        # Clamp to [0.0, 1.0]
        return max(0.0, min(1.0, complexity))


class AdaptiveMemoryManager:
    """
    Dynamically adjusts memory parameters based on task type and complexity.
    
    This is a minimal implementation to enable Phase 1 performance tests.
    Full implementation will be done in Week 7-8.
    """
    
    def __init__(self, config: Optional[AdaptiveMemoryConfig] = None):
        """
        Initialize adaptive memory manager.
        
        Args:
            config: Configuration for adaptive memory
        """
        self.config = config or AdaptiveMemoryConfig()
        self.task_classifier = TaskClassifier()
        self.complexity_estimator = ComplexityEstimator()
    
    def get_memory_config(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None
    ) -> AdaptiveMemoryResult:
        """
        Get optimal memory configuration for task.
        
        Args:
            task: Task description
            context: Additional context
            
        Returns:
            Adaptive memory result with config and metadata
        """
        if not self.config.enabled:
            return AdaptiveMemoryResult(
                config=WorkingMemoryConfig(),
                task_type='coding',
                complexity=0.5,
            )
        
        context = context or {}
        
        # 1. Classify task type
        task_type = self.task_classifier.classify(task)
        
        # 2. Estimate complexity
        complexity = self.complexity_estimator.estimate(task, context)
        
        # 3. Determine base parameters
        if task_type == 'debug':
            compression_threshold = self.config.debug_compression_threshold
            rolling_window = self.config.debug_rolling_window
        elif task_type == 'refactor':
            compression_threshold = self.config.refactor_compression_threshold
            rolling_window = self.config.refactor_rolling_window
        else:
            compression_threshold = self.config.default_compression_threshold
            rolling_window = self.config.default_rolling_window
        
        # 4. Adjust for complexity
        if complexity >= self.config.high_complexity_threshold:
            compression_threshold += self.config.complexity_adjustment
            rolling_window += 2
        elif complexity < self.config.low_complexity_threshold:
            compression_threshold -= self.config.complexity_adjustment
            rolling_window -= 2
        
        # 5. Clamp values
        compression_threshold = max(0.5, min(1.0, compression_threshold))
        rolling_window = max(5, min(20, rolling_window))
        
        return AdaptiveMemoryResult(
            config=WorkingMemoryConfig(
                compression_threshold=compression_threshold,
                rolling_window_size=rolling_window
            ),
            task_type=task_type,
            complexity=complexity,
        )
