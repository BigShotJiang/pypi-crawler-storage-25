"""
Adaptive Memory Management Module.

Dynamically adjusts memory parameters based on task type and complexity.
"""

from neoCoder.sdk.adaptive_memory.manager import AdaptiveMemoryManager
from neoCoder.sdk.adaptive_memory.config import (
    AdaptiveMemoryConfig,
    AdaptiveMemoryResult,
    WorkingMemoryConfig,
)

__all__ = [
    "AdaptiveMemoryManager",
    "AdaptiveMemoryConfig",
    "AdaptiveMemoryResult",
    "WorkingMemoryConfig",
]
