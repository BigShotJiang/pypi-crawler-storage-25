"""
Tool choice control for Anthropic API

Implements tool_choice parameter according to Anthropic API specification:
https://docs.anthropic.com/en/docs/build-with-claude/tool-use
"""

from typing import Optional, Dict, Any, Union, Literal
from dataclasses import dataclass
from ..utils import get_logger
from ..exceptions import ZenmuxError


# Type aliases for tool choice types
ToolChoiceType = Literal["auto", "any", "tool", "none"]


@dataclass
class ToolChoice:
    """
    Tool choice configuration
    
    Controls how Claude uses the tools declared in the request.
    
    Attributes:
        type: Choice type ("auto", "any", "tool", "none")
        name: Tool name (required when type="tool")
        disable_parallel_tool_use: Disable parallel tool calls
    """
    type: ToolChoiceType
    name: Optional[str] = None
    disable_parallel_tool_use: bool = False
    
    def __post_init__(self):
        """Validate tool choice configuration"""
        if self.type == "tool" and not self.name:
            raise ZenmuxError("Tool name is required when type='tool'")
        
        if self.type != "tool" and self.name:
            raise ZenmuxError(f"Tool name should not be specified for type='{self.type}'")
    
    def to_dict(self) -> Dict[str, Any]:
        """
        Convert to API format
        
        Returns:
            Dictionary in Anthropic API format
        """
        result: Dict[str, Any] = {"type": self.type}
        
        if self.type == "tool" and self.name:
            result["name"] = self.name
        
        if self.disable_parallel_tool_use:
            result["disable_parallel_tool_use"] = True
        
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ToolChoice":
        """
        Create from dictionary
        
        Args:
            data: Dictionary with tool choice configuration
            
        Returns:
            ToolChoice instance
        """
        return cls(
            type=data["type"],
            name=data.get("name"),
            disable_parallel_tool_use=data.get("disable_parallel_tool_use", False)
        )
    
    @classmethod
    def auto(cls, disable_parallel: bool = False) -> "ToolChoice":
        """
        Create "auto" tool choice (recommended default)
        
        Claude decides on its own whether to call tools and which tools to call.
        
        Args:
            disable_parallel: If True, calls at most 1 tool
            
        Returns:
            ToolChoice instance
        """
        return cls(type="auto", disable_parallel_tool_use=disable_parallel)
    
    @classmethod
    def any(cls, disable_parallel: bool = False) -> "ToolChoice":
        """
        Create "any" tool choice
        
        Similar to "auto" but usually more strongly encourages tool use.
        
        Args:
            disable_parallel: If True, calls at most 1 tool
            
        Returns:
            ToolChoice instance
        """
        return cls(type="any", disable_parallel_tool_use=disable_parallel)
    
    @classmethod
    def tool(cls, name: str, disable_parallel: bool = True) -> "ToolChoice":
        """
        Create "tool" tool choice
        
        Forces using a specific tool.
        
        Args:
            name: Tool name to force
            disable_parallel: If True, only this tool is called once
            
        Returns:
            ToolChoice instance
        """
        return cls(type="tool", name=name, disable_parallel_tool_use=disable_parallel)
    
    @classmethod
    def none(cls) -> "ToolChoice":
        """
        Create "none" tool choice
        
        Disallows tool usage; only generates plain text/multimodal responses.
        
        Returns:
            ToolChoice instance
        """
        return cls(type="none")


class ToolChoiceManager:
    """
    Manager for tool choice operations
    
    Provides utilities for working with tool_choice parameter.
    """
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.tool_calling")
    
    def parse_tool_choice(
        self,
        tool_choice: Union[str, Dict[str, Any], ToolChoice, None]
    ) -> Optional[Dict[str, Any]]:
        """
        Parse tool_choice parameter into API format
        
        Args:
            tool_choice: Tool choice specification (string, dict, or ToolChoice)
            
        Returns:
            Dictionary in API format or None
            
        Raises:
            ZenmuxError: If tool_choice format is invalid
        """
        if tool_choice is None:
            return None
        
        # Already a ToolChoice instance
        if isinstance(tool_choice, ToolChoice):
            return tool_choice.to_dict()
        
        # String shorthand
        if isinstance(tool_choice, str):
            if tool_choice not in ["auto", "any", "none"]:
                raise ZenmuxError(
                    f"Invalid tool_choice string: '{tool_choice}'. "
                    f"Must be 'auto', 'any', or 'none'"
                )
            return {"type": tool_choice}
        
        # Dictionary format
        if isinstance(tool_choice, dict):
            if "type" not in tool_choice:
                raise ZenmuxError("tool_choice dict must have 'type' field")
            
            choice_type = tool_choice["type"]
            if choice_type not in ["auto", "any", "tool", "none"]:
                raise ZenmuxError(
                    f"Invalid tool_choice type: '{choice_type}'. "
                    f"Must be 'auto', 'any', 'tool', or 'none'"
                )
            
            # Validate tool type
            if choice_type == "tool":
                if "name" not in tool_choice:
                    raise ZenmuxError("tool_choice with type='tool' must have 'name' field")
            
            return tool_choice
        
        raise ZenmuxError(
            f"Invalid tool_choice type: {type(tool_choice)}. "
            f"Must be string, dict, or ToolChoice instance"
        )
    
    def validate_tool_choice(
        self,
        tool_choice: Optional[Dict[str, Any]],
        available_tools: Optional[list[str]] = None
    ) -> bool:
        """
        Validate tool_choice against available tools
        
        Args:
            tool_choice: Tool choice configuration
            available_tools: List of available tool names
            
        Returns:
            True if valid
            
        Raises:
            ZenmuxError: If validation fails
        """
        if tool_choice is None:
            return True
        
        choice_type = tool_choice.get("type")
        
        # Validate type
        if choice_type not in ["auto", "any", "tool", "none"]:
            raise ZenmuxError(f"Invalid tool_choice type: '{choice_type}'")
        
        # Validate tool name if type="tool"
        if choice_type == "tool":
            tool_name = tool_choice.get("name")
            if not tool_name:
                raise ZenmuxError("tool_choice with type='tool' must have 'name' field")
            
            # Check if tool exists in available tools
            if available_tools is not None and tool_name not in available_tools:
                raise ZenmuxError(
                    f"Tool '{tool_name}' specified in tool_choice not found in available tools. "
                    f"Available: {available_tools}"
                )
        
        return True
    
    def should_force_tool_use(self, tool_choice: Optional[Dict[str, Any]]) -> bool:
        """
        Check if tool_choice forces tool use
        
        Args:
            tool_choice: Tool choice configuration
            
        Returns:
            True if tool use is forced
        """
        if tool_choice is None:
            return False
        
        choice_type = tool_choice.get("type")
        return choice_type in ["any", "tool"]
    
    def get_forced_tool_name(self, tool_choice: Optional[Dict[str, Any]]) -> Optional[str]:
        """
        Get forced tool name if type="tool"
        
        Args:
            tool_choice: Tool choice configuration
            
        Returns:
            Tool name or None
        """
        if tool_choice is None:
            return None
        
        if tool_choice.get("type") == "tool":
            return tool_choice.get("name")
        
        return None
    
    def is_parallel_disabled(self, tool_choice: Optional[Dict[str, Any]]) -> bool:
        """
        Check if parallel tool use is disabled
        
        Args:
            tool_choice: Tool choice configuration
            
        Returns:
            True if parallel tool use is disabled
        """
        if tool_choice is None:
            return False
        
        return tool_choice.get("disable_parallel_tool_use", False)
    
    def create_auto(self, disable_parallel: bool = False) -> Dict[str, Any]:
        """Create auto tool choice"""
        return ToolChoice.auto(disable_parallel).to_dict()
    
    def create_any(self, disable_parallel: bool = False) -> Dict[str, Any]:
        """Create any tool choice"""
        return ToolChoice.any(disable_parallel).to_dict()
    
    def create_tool(self, name: str, disable_parallel: bool = True) -> Dict[str, Any]:
        """Create tool tool choice"""
        return ToolChoice.tool(name, disable_parallel).to_dict()
    
    def create_none(self) -> Dict[str, Any]:
        """Create none tool choice"""
        return ToolChoice.none().to_dict()
