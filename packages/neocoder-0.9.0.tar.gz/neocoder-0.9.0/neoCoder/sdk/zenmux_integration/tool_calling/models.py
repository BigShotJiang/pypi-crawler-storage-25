"""
Data models for tool calling
"""

from typing import Dict, Any, Optional, Callable, List
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime


class ToolExecutionStatus(str, Enum):
    """Status of tool execution"""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"


@dataclass
class Tool:
    """Tool definition"""
    name: str
    description: str
    parameters: Dict[str, Any]
    function: Callable
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to API format"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            }
        }


@dataclass
class ToolCall:
    """Tool call from model response"""
    id: str
    name: str
    arguments: Dict[str, Any]
    type: str = "function"
    
    @classmethod
    def from_api_response(cls, tool_call_data: Dict[str, Any]) -> "ToolCall":
        """Create from API response"""
        import json
        
        function = tool_call_data.get("function", {})
        arguments_str = function.get("arguments", "{}")
        
        # Parse arguments if string
        if isinstance(arguments_str, str):
            try:
                arguments = json.loads(arguments_str)
            except json.JSONDecodeError:
                arguments = {}
        else:
            arguments = arguments_str
        
        return cls(
            id=tool_call_data.get("id", ""),
            name=function.get("name", ""),
            arguments=arguments,
            type=tool_call_data.get("type", "function")
        )


@dataclass
class ToolResult:
    """Result of tool execution"""
    tool_call_id: str
    name: str
    result: Any
    status: ToolExecutionStatus
    error: Optional[str] = None
    execution_time: float = 0.0
    
    def to_message(self) -> Dict[str, Any]:
        """Convert to message format for API"""
        import json
        
        # Format result as string
        if isinstance(self.result, (dict, list)):
            content = json.dumps(self.result)
        else:
            content = str(self.result)
        
        return {
            "role": "tool",
            "tool_call_id": self.tool_call_id,
            "name": self.name,
            "content": content,
        }
    
    def is_success(self) -> bool:
        """Check if execution was successful"""
        return self.status == ToolExecutionStatus.SUCCESS


@dataclass
class ToolExecution:
    """Record of tool execution"""
    tool_call: ToolCall
    result: ToolResult
    timestamp: datetime = field(default_factory=datetime.now)
    context: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            "tool_call": {
                "id": self.tool_call.id,
                "name": self.tool_call.name,
                "arguments": self.tool_call.arguments,
            },
            "result": {
                "status": self.result.status.value,
                "result": self.result.result,
                "error": self.result.error,
                "execution_time": self.result.execution_time,
            },
            "timestamp": self.timestamp.isoformat(),
            "context": self.context,
        }
