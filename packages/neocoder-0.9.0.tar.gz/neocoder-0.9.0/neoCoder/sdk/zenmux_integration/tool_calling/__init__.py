"""
Tool calling enhancement for Zenmux integration

This module provides enhanced tool calling capabilities:
- Tool registry and management
- Automatic tool execution
- Tool call formatting
- Tool choice control (Anthropic API)
- Integration with existing tool_selection
"""

from .models import (
    Tool,
    ToolCall,
    ToolResult,
    ToolExecution,
    ToolExecutionStatus,
)
from .registry import ToolRegistry
from .executor import ToolExecutor
from .formatter import ToolCallFormatter
from .tool_choice import ToolChoice, ToolChoiceManager, ToolChoiceType
from .integration import EnhancedToolManager, TOOL_SELECTION_AVAILABLE

__all__ = [
    # Models
    "Tool",
    "ToolCall",
    "ToolResult",
    "ToolExecution",
    "ToolExecutionStatus",
    # Core classes
    "ToolRegistry",
    "ToolExecutor",
    "ToolCallFormatter",
    # Tool choice
    "ToolChoice",
    "ToolChoiceManager",
    "ToolChoiceType",
    # Integration
    "EnhancedToolManager",
    "TOOL_SELECTION_AVAILABLE",
]
