"""
Tool call formatter for API messages
"""

import json
from typing import List, Dict, Any
from .models import ToolCall, ToolResult
from ..utils import get_logger


class ToolCallFormatter:
    """Formats tool calls and results for API messages"""
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.tool_calling")
    
    def format_tool_call_message(
        self,
        tool_calls: List[ToolCall],
        content: str = ""
    ) -> Dict[str, Any]:
        """
        Format tool calls as assistant message
        
        Args:
            tool_calls: List of tool calls
            content: Optional message content
            
        Returns:
            Assistant message with tool calls
        """
        tool_calls_data = []
        
        for tool_call in tool_calls:
            tool_calls_data.append({
                "id": tool_call.id,
                "type": tool_call.type,
                "function": {
                    "name": tool_call.name,
                    "arguments": json.dumps(tool_call.arguments)
                }
            })
        
        message = {
            "role": "assistant",
            "content": content or None,
            "tool_calls": tool_calls_data
        }
        
        self.logger.debug(f"Formatted {len(tool_calls)} tool calls")
        
        return message
    
    def format_tool_result_message(
        self,
        tool_call_id: str,
        name: str,
        result: Any
    ) -> Dict[str, Any]:
        """
        Format tool result as tool message
        
        Args:
            tool_call_id: Tool call ID
            name: Tool name
            result: Tool result
            
        Returns:
            Tool message
        """
        # Format result as string
        if isinstance(result, (dict, list)):
            content = json.dumps(result)
        elif result is None:
            content = "null"
        else:
            content = str(result)
        
        message = {
            "role": "tool",
            "tool_call_id": tool_call_id,
            "name": name,
            "content": content
        }
        
        self.logger.debug(f"Formatted tool result for {name}")
        
        return message
    
    def format_tool_results_messages(
        self,
        results: List[ToolResult]
    ) -> List[Dict[str, Any]]:
        """
        Format multiple tool results as messages
        
        Args:
            results: List of tool results
            
        Returns:
            List of tool messages
        """
        messages = []
        
        for result in results:
            message = result.to_message()
            messages.append(message)
        
        self.logger.debug(f"Formatted {len(results)} tool results")
        
        return messages
    
    def extract_tool_calls_from_response(
        self,
        response: Any
    ) -> List[ToolCall]:
        """
        Extract tool calls from API response
        
        Args:
            response: API response object
            
        Returns:
            List of tool calls
        """
        tool_calls = []
        
        try:
            # Get message from response
            message = response.choices[0].message
            
            # Check if message has tool calls
            if hasattr(message, 'tool_calls') and message.tool_calls:
                for tool_call_data in message.tool_calls:
                    # Convert to dict if needed
                    if hasattr(tool_call_data, 'model_dump'):
                        tool_call_dict = tool_call_data.model_dump()
                    elif hasattr(tool_call_data, 'dict'):
                        tool_call_dict = tool_call_data.dict()
                    else:
                        tool_call_dict = tool_call_data
                    
                    tool_call = ToolCall.from_api_response(tool_call_dict)
                    tool_calls.append(tool_call)
                
                self.logger.info(f"Extracted {len(tool_calls)} tool calls from response")
        
        except Exception as e:
            self.logger.error(f"Error extracting tool calls: {e}")
        
        return tool_calls
    
    def has_tool_calls(self, response: Any) -> bool:
        """
        Check if response has tool calls
        
        Args:
            response: API response object
            
        Returns:
            True if response has tool calls
        """
        try:
            message = response.choices[0].message
            return hasattr(message, 'tool_calls') and message.tool_calls is not None
        except Exception:
            return False
