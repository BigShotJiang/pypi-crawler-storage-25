"""
Tool registry for managing available tools
"""

from typing import Dict, List, Optional, Callable, Any
from .models import Tool
from ..utils import get_logger
from ..exceptions import ZenmuxError


class ToolRegistry:
    """Registry for managing available tools"""
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.tool_calling")
        self._tools: Dict[str, Tool] = {}
    
    def register(
        self,
        name: str,
        function: Callable,
        description: str,
        parameters: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Register a tool
        
        Args:
            name: Tool name
            function: Callable function
            description: Tool description
            parameters: JSON Schema for parameters
            metadata: Optional metadata
            
        Raises:
            ZenmuxError: If tool already registered
        """
        if name in self._tools:
            raise ZenmuxError(f"Tool '{name}' is already registered")
        
        tool = Tool(
            name=name,
            description=description,
            parameters=parameters,
            function=function,
            metadata=metadata or {}
        )
        
        self._tools[name] = tool
        self.logger.info(f"Registered tool: {name}")
    
    def unregister(self, name: str) -> None:
        """
        Unregister a tool
        
        Args:
            name: Tool name
            
        Raises:
            ZenmuxError: If tool not found
        """
        if name not in self._tools:
            raise ZenmuxError(f"Tool '{name}' not found")
        
        del self._tools[name]
        self.logger.info(f"Unregistered tool: {name}")
    
    def get_tool(self, name: str) -> Tool:
        """
        Get tool by name
        
        Args:
            name: Tool name
            
        Returns:
            Tool instance
            
        Raises:
            ZenmuxError: If tool not found
        """
        if name not in self._tools:
            raise ZenmuxError(f"Tool '{name}' not found")
        
        return self._tools[name]
    
    def has_tool(self, name: str) -> bool:
        """
        Check if tool exists
        
        Args:
            name: Tool name
            
        Returns:
            True if tool exists
        """
        return name in self._tools
    
    def list_tools(self) -> List[str]:
        """
        List all registered tool names
        
        Returns:
            List of tool names
        """
        return list(self._tools.keys())
    
    def get_tool_definitions(
        self,
        allowed_tools: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Get tool definitions for API
        
        Args:
            allowed_tools: Optional list of allowed tool names
            
        Returns:
            List of tool definitions in API format
        """
        tools = self._tools.values()
        
        # Filter by allowed tools if specified
        if allowed_tools is not None:
            tools = [t for t in tools if t.name in allowed_tools]
        
        return [tool.to_dict() for tool in tools]
    
    def format_for_zenmux(
        self,
        allowed_tools: Optional[List[str]] = None
    ) -> List[Dict[str, Any]]:
        """
        Format tools for Zenmux API
        
        Args:
            allowed_tools: Optional list of allowed tool names
            
        Returns:
            List of tool definitions in Zenmux format
        """
        return self.get_tool_definitions(allowed_tools)
    
    def clear(self) -> None:
        """Clear all registered tools"""
        self._tools.clear()
        self.logger.info("Cleared all tools")
    
    def __len__(self) -> int:
        """Get number of registered tools"""
        return len(self._tools)
    
    def __contains__(self, name: str) -> bool:
        """Check if tool exists (supports 'in' operator)"""
        return name in self._tools
