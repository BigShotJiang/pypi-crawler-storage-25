"""
Tool executor for executing tool calls
"""

import asyncio
import time
from typing import List, Optional, Dict, Any
from .models import (
    ToolCall,
    ToolResult,
    ToolExecution,
    ToolExecutionStatus,
)
from .registry import ToolRegistry
from ..utils import get_logger
from ..exceptions import ZenmuxError


class ToolExecutor:
    """Executes tool calls from model responses"""
    
    def __init__(
        self,
        registry: ToolRegistry,
        max_retries: int = 2,
        timeout: float = 30.0
    ):
        """
        Initialize tool executor
        
        Args:
            registry: Tool registry
            max_retries: Maximum retry attempts
            timeout: Execution timeout in seconds
        """
        self.logger = get_logger("zenmux_integration.tool_calling")
        self.registry = registry
        self.max_retries = max_retries
        self.timeout = timeout
        self.execution_history: List[ToolExecution] = []
    
    async def execute_tool_calls(
        self,
        tool_calls: List[ToolCall],
        context: Optional[Dict[str, Any]] = None,
        parallel: bool = True
    ) -> List[ToolResult]:
        """
        Execute multiple tool calls
        
        Args:
            tool_calls: List of tool calls to execute
            context: Optional execution context
            parallel: Execute in parallel if True
            
        Returns:
            List of tool results
        """
        if not tool_calls:
            return []
        
        self.logger.info(f"Executing {len(tool_calls)} tool calls (parallel={parallel})")
        
        if parallel:
            # Execute all tool calls in parallel
            tasks = [
                self.execute_single(tool_call, context)
                for tool_call in tool_calls
            ]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Convert exceptions to failed results
            final_results = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    final_results.append(ToolResult(
                        tool_call_id=tool_calls[i].id,
                        name=tool_calls[i].name,
                        result=None,
                        status=ToolExecutionStatus.FAILED,
                        error=str(result)
                    ))
                else:
                    final_results.append(result)
            
            return final_results
        else:
            # Execute sequentially
            results = []
            for tool_call in tool_calls:
                result = await self.execute_single(tool_call, context)
                results.append(result)
            
            return results
    
    async def execute_single(
        self,
        tool_call: ToolCall,
        context: Optional[Dict[str, Any]] = None
    ) -> ToolResult:
        """
        Execute single tool call with retry logic
        
        Args:
            tool_call: Tool call to execute
            context: Optional execution context
            
        Returns:
            Tool result
        """
        self.logger.debug(f"Executing tool: {tool_call.name} (id={tool_call.id})")
        
        # Check if tool exists
        if not self.registry.has_tool(tool_call.name):
            error_msg = f"Tool '{tool_call.name}' not found in registry"
            self.logger.error(error_msg)
            return ToolResult(
                tool_call_id=tool_call.id,
                name=tool_call.name,
                result=None,
                status=ToolExecutionStatus.FAILED,
                error=error_msg
            )
        
        # Get tool
        tool = self.registry.get_tool(tool_call.name)
        
        # Execute with retries
        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                start_time = time.time()
                
                # Execute tool function with timeout
                result = await asyncio.wait_for(
                    self._execute_function(tool.function, tool_call.arguments),
                    timeout=self.timeout
                )
                
                execution_time = time.time() - start_time
                
                # Create successful result
                tool_result = ToolResult(
                    tool_call_id=tool_call.id,
                    name=tool_call.name,
                    result=result,
                    status=ToolExecutionStatus.SUCCESS,
                    execution_time=execution_time
                )
                
                # Record execution
                self._record_execution(tool_call, tool_result, context)
                
                self.logger.info(
                    f"Tool '{tool_call.name}' executed successfully "
                    f"in {execution_time:.2f}s"
                )
                
                return tool_result
                
            except asyncio.TimeoutError:
                last_error = f"Tool execution timed out after {self.timeout}s"
                self.logger.warning(
                    f"Tool '{tool_call.name}' timeout (attempt {attempt + 1})"
                )
                
            except Exception as e:
                last_error = str(e)
                self.logger.warning(
                    f"Tool '{tool_call.name}' failed (attempt {attempt + 1}): {e}"
                )
                
                # Don't retry on certain errors
                if "not found" in str(e).lower() or "invalid" in str(e).lower():
                    break
        
        # All retries failed
        tool_result = ToolResult(
            tool_call_id=tool_call.id,
            name=tool_call.name,
            result=None,
            status=ToolExecutionStatus.FAILED,
            error=last_error
        )
        
        # Record failed execution
        self._record_execution(tool_call, tool_result, context)
        
        self.logger.error(
            f"Tool '{tool_call.name}' failed after {self.max_retries + 1} attempts"
        )
        
        return tool_result
    
    async def _execute_function(
        self,
        function: Any,
        arguments: Dict[str, Any]
    ) -> Any:
        """
        Execute tool function (sync or async)
        
        Args:
            function: Tool function
            arguments: Function arguments
            
        Returns:
            Function result
        """
        # Check if function is async
        if asyncio.iscoroutinefunction(function):
            return await function(**arguments)
        else:
            # Run sync function in executor to avoid blocking
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, lambda: function(**arguments))
    
    def _record_execution(
        self,
        tool_call: ToolCall,
        result: ToolResult,
        context: Optional[Dict[str, Any]]
    ) -> None:
        """
        Record tool execution in history
        
        Args:
            tool_call: Tool call
            result: Tool result
            context: Execution context
        """
        execution = ToolExecution(
            tool_call=tool_call,
            result=result,
            context=context or {}
        )
        
        self.execution_history.append(execution)
        
        # Keep only last 100 executions
        if len(self.execution_history) > 100:
            self.execution_history = self.execution_history[-100:]
    
    def get_execution_history(
        self,
        limit: Optional[int] = None
    ) -> List[ToolExecution]:
        """
        Get execution history
        
        Args:
            limit: Optional limit on number of records
            
        Returns:
            List of tool executions
        """
        if limit is None:
            return self.execution_history.copy()
        else:
            return self.execution_history[-limit:]
    
    def clear_history(self) -> None:
        """Clear execution history"""
        self.execution_history.clear()
        self.logger.info("Cleared execution history")
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get execution statistics
        
        Returns:
            Dictionary with statistics
        """
        if not self.execution_history:
            return {
                "total_executions": 0,
                "successful": 0,
                "failed": 0,
                "success_rate": 0.0,
                "average_execution_time": 0.0
            }
        
        total = len(self.execution_history)
        successful = sum(
            1 for e in self.execution_history
            if e.result.status == ToolExecutionStatus.SUCCESS
        )
        failed = total - successful
        
        execution_times = [
            e.result.execution_time
            for e in self.execution_history
            if e.result.status == ToolExecutionStatus.SUCCESS
        ]
        
        avg_time = sum(execution_times) / len(execution_times) if execution_times else 0.0
        
        return {
            "total_executions": total,
            "successful": successful,
            "failed": failed,
            "success_rate": successful / total if total > 0 else 0.0,
            "average_execution_time": avg_time
        }
