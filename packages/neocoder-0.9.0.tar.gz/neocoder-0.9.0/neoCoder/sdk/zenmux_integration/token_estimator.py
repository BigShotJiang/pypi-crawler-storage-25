"""
Adaptive Token Estimator for ZenMux.

Learns the chars-per-token ratio from actual API responses
and uses it for more accurate token estimation.

Inspired by CCA-SWEBench TokenEstimatorExtension.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Any

from .utils import get_logger


# Default values
DEFAULT_CHARS_PER_TOKEN = 4.0
MIN_CHARS_PER_TOKEN = 2.5
MAX_CHARS_PER_TOKEN = 5.0

# Minimum samples before using learned value
MIN_SAMPLES_FOR_LEARNING = 3


@dataclass
class TokenUsage:
    """Token usage from API response."""
    
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0
    reasoning_tokens: int = 0
    
    @property
    def total_input(self) -> int:
        """Total input tokens including cache."""
        return self.input_tokens + self.cache_creation_tokens + self.cache_read_tokens
    
    @property
    def total(self) -> int:
        """Total tokens used."""
        return self.total_input + self.output_tokens
    
    @classmethod
    def from_response(cls, response: Any) -> "TokenUsage":
        """Extract token usage from API response."""
        usage = TokenUsage()
        
        # Try to extract from response object
        if hasattr(response, "usage") and response.usage:
            u = response.usage
            usage.input_tokens = getattr(u, "prompt_tokens", 0) or getattr(u, "input_tokens", 0) or 0
            usage.output_tokens = getattr(u, "completion_tokens", 0) or getattr(u, "output_tokens", 0) or 0
            usage.cache_creation_tokens = getattr(u, "cache_creation_input_tokens", 0) or 0
            usage.cache_read_tokens = getattr(u, "cache_read_input_tokens", 0) or 0
            
            # Reasoning tokens (for thinking models)
            if hasattr(u, "completion_tokens_details") and u.completion_tokens_details:
                details = u.completion_tokens_details
                usage.reasoning_tokens = getattr(details, "reasoning_tokens", 0) or 0
        
        # Try to extract from response_metadata (Anthropic style)
        elif hasattr(response, "response_metadata"):
            meta = response.response_metadata
            if isinstance(meta, dict) and "usage" in meta:
                u = meta["usage"]
                usage.input_tokens = u.get("input_tokens", 0)
                usage.output_tokens = u.get("output_tokens", 0)
                usage.cache_creation_tokens = u.get("cache_creation_input_tokens", 0)
                usage.cache_read_tokens = u.get("cache_read_input_tokens", 0)
        
        return usage


@dataclass
class EstimatorStats:
    """Statistics for token estimation."""
    
    samples: int = 0
    total_chars: int = 0
    total_tokens: int = 0
    learned_ratio: float = DEFAULT_CHARS_PER_TOKEN
    
    # Per-model stats
    model_ratios: dict[str, float] = field(default_factory=dict)
    model_samples: dict[str, int] = field(default_factory=dict)


class TokenEstimator:
    """
    Adaptive token estimator that learns from API responses.
    
    Features:
    - Learns chars-per-token ratio from actual usage
    - Per-model learning (different models have different tokenizers)
    - Thread-safe
    - Falls back to default ratio until enough samples
    
    Usage:
        estimator = TokenEstimator()
        
        # Before API call - estimate tokens
        estimated = estimator.estimate_tokens(prompt_text)
        
        # After API call - learn from response
        estimator.learn_from_response(prompt_text, response)
        
        # Future estimates will be more accurate
    """
    
    def __init__(self, default_ratio: float = DEFAULT_CHARS_PER_TOKEN):
        self._lock = threading.Lock()
        self._default_ratio = default_ratio
        self._stats = EstimatorStats()
        self._logger = get_logger("zenmux_integration.token_estimator")
        
        # Track last prompt for learning
        self._last_prompt_chars: int = 0
        self._last_model: str | None = None
    
    def estimate_tokens(
        self,
        text: str | list[dict[str, Any]] | dict[str, Any],
        model: str | None = None,
    ) -> int:
        """
        Estimate token count for text.
        
        Args:
            text: Text string, messages list, or content dict
            model: Optional model name for model-specific ratio
            
        Returns:
            Estimated token count
        """
        chars = self._count_chars(text)
        ratio = self._get_ratio(model)
        
        estimated = int(chars / ratio)
        
        self._logger.debug(
            f"Estimated {estimated} tokens for {chars} chars "
            f"(ratio={ratio:.2f}, model={model})"
        )
        
        return estimated
    
    def estimate_messages(
        self,
        messages: list[dict[str, Any]],
        model: str | None = None,
    ) -> int:
        """Estimate tokens for a list of messages."""
        total_chars = 0
        for msg in messages:
            content = msg.get("content", "")
            total_chars += self._count_chars(content)
            # Add overhead for role, etc.
            total_chars += 10
        
        ratio = self._get_ratio(model)
        return int(total_chars / ratio)
    
    def prepare_for_request(
        self,
        prompt_text: str | list[dict[str, Any]],
        model: str | None = None,
    ) -> int:
        """
        Prepare for API request - estimate tokens and remember for learning.
        
        Call this before making API request, then call learn_from_response after.
        
        Args:
            prompt_text: The prompt being sent
            model: Model being used
            
        Returns:
            Estimated token count
        """
        chars = self._count_chars(prompt_text)
        
        with self._lock:
            self._last_prompt_chars = chars
            self._last_model = model
        
        return self.estimate_tokens(prompt_text, model)
    
    def learn_from_response(
        self,
        response: Any,
        prompt_chars: int | None = None,
        model: str | None = None,
    ) -> TokenUsage:
        """
        Learn from API response.
        
        Extracts actual token usage and updates chars-per-token ratio.
        
        Args:
            response: API response object
            prompt_chars: Character count of prompt (uses stored if None)
            model: Model used (uses stored if None)
            
        Returns:
            TokenUsage extracted from response
        """
        usage = TokenUsage.from_response(response)
        
        if usage.total_input == 0:
            return usage
        
        with self._lock:
            chars = prompt_chars if prompt_chars is not None else self._last_prompt_chars
            used_model = model or self._last_model
            
            if chars > 0:
                # Calculate ratio for this response
                new_ratio = chars / usage.total_input
                
                # Clamp to reasonable bounds
                new_ratio = max(MIN_CHARS_PER_TOKEN, min(MAX_CHARS_PER_TOKEN, new_ratio))
                
                # Update global stats
                self._stats.samples += 1
                self._stats.total_chars += chars
                self._stats.total_tokens += usage.total_input
                
                # Update running average
                if self._stats.samples >= MIN_SAMPLES_FOR_LEARNING:
                    self._stats.learned_ratio = (
                        self._stats.total_chars / self._stats.total_tokens
                    )
                
                # Update per-model stats
                if used_model:
                    model_key = self._normalize_model_name(used_model)
                    prev_samples = self._stats.model_samples.get(model_key, 0)
                    prev_ratio = self._stats.model_ratios.get(model_key, new_ratio)
                    
                    # Exponential moving average
                    alpha = 0.3  # Weight for new sample
                    updated_ratio = alpha * new_ratio + (1 - alpha) * prev_ratio
                    
                    self._stats.model_ratios[model_key] = updated_ratio
                    self._stats.model_samples[model_key] = prev_samples + 1
                
                self._logger.debug(
                    f"Learned from response: {chars} chars -> {usage.total_input} tokens "
                    f"(ratio={new_ratio:.2f}, global={self._stats.learned_ratio:.2f})"
                )
            
            # Clear stored values
            self._last_prompt_chars = 0
            self._last_model = None
        
        return usage
    
    def _count_chars(self, content: Any) -> int:
        """Count characters in content."""
        if isinstance(content, str):
            return len(content)
        
        if isinstance(content, list):
            total = 0
            for item in content:
                if isinstance(item, dict):
                    # Message or content block
                    text = item.get("text", "") or item.get("content", "")
                    total += self._count_chars(text)
                else:
                    total += len(str(item))
            return total
        
        if isinstance(content, dict):
            text = content.get("text", "") or content.get("content", "")
            return len(str(text))
        
        return len(str(content))
    
    def _get_ratio(self, model: str | None = None) -> float:
        """Get chars-per-token ratio, preferring model-specific if available."""
        with self._lock:
            # Try model-specific ratio first
            if model:
                model_key = self._normalize_model_name(model)
                if model_key in self._stats.model_ratios:
                    samples = self._stats.model_samples.get(model_key, 0)
                    if samples >= MIN_SAMPLES_FOR_LEARNING:
                        return self._stats.model_ratios[model_key]
            
            # Use global learned ratio if enough samples
            if self._stats.samples >= MIN_SAMPLES_FOR_LEARNING:
                return self._stats.learned_ratio
            
            # Fall back to default
            return self._default_ratio
    
    def _normalize_model_name(self, model: str) -> str:
        """Normalize model name for grouping (e.g., claude-3-5-sonnet -> claude)."""
        model_lower = model.lower()
        
        # Extract base model family
        if "claude" in model_lower:
            return "claude"
        if "gpt" in model_lower:
            return "gpt"
        if "gemini" in model_lower:
            return "gemini"
        if "deepseek" in model_lower:
            return "deepseek"
        if "qwen" in model_lower:
            return "qwen"
        if "llama" in model_lower:
            return "llama"
        
        # Return first part of model name
        return model.split("/")[-1].split("-")[0]
    
    def get_statistics(self) -> dict[str, Any]:
        """Get estimation statistics."""
        with self._lock:
            return {
                "samples": self._stats.samples,
                "total_chars": self._stats.total_chars,
                "total_tokens": self._stats.total_tokens,
                "global_ratio": round(self._stats.learned_ratio, 3),
                "default_ratio": self._default_ratio,
                "model_ratios": {
                    k: round(v, 3) for k, v in self._stats.model_ratios.items()
                },
                "model_samples": dict(self._stats.model_samples),
                "is_learning": self._stats.samples >= MIN_SAMPLES_FOR_LEARNING,
            }
    
    def reset(self) -> None:
        """Reset all learned statistics."""
        with self._lock:
            self._stats = EstimatorStats()
            self._last_prompt_chars = 0
            self._last_model = None


# Global singleton instance
_global_estimator: TokenEstimator | None = None
_global_lock = threading.Lock()


def get_token_estimator() -> TokenEstimator:
    """Get the global TokenEstimator instance."""
    global _global_estimator
    
    with _global_lock:
        if _global_estimator is None:
            _global_estimator = TokenEstimator()
        return _global_estimator


def estimate_tokens(
    text: str | list[dict[str, Any]] | dict[str, Any],
    model: str | None = None,
) -> int:
    """
    Convenience function to estimate tokens using global estimator.
    
    Args:
        text: Text, messages, or content to estimate
        model: Optional model for model-specific estimation
        
    Returns:
        Estimated token count
    """
    return get_token_estimator().estimate_tokens(text, model)
