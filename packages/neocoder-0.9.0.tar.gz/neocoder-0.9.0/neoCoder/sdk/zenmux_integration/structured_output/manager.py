"""
Structured output manager for Zenmux integration
"""

from typing import Type, Dict, Any, Optional, Literal, Union
from dataclasses import is_dataclass
from pydantic import BaseModel

from .schema import SchemaGenerator
from .validator import ResponseValidator
from ..utils import get_logger
from ..exceptions import StructuredOutputError


class StructuredOutputManager:
    """Manages structured output generation and validation"""
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.structured_output")
        self.schema_generator = SchemaGenerator()
        self.validator = ResponseValidator()
    
    def create_response_format(
        self,
        schema_type: Literal["json_object", "json_schema"],
        model_class: Optional[Type[BaseModel]] = None,
        schema_dict: Optional[Dict[str, Any]] = None,
        strict: bool = True,
    ) -> Dict[str, Any]:
        """
        Create response_format parameter for API
        
        Args:
            schema_type: Type of schema ("json_object" or "json_schema")
            model_class: Optional Pydantic model class
            schema_dict: Optional schema dictionary
            strict: Enable strict mode (default: True)
            
        Returns:
            response_format dictionary for API
            
        Raises:
            StructuredOutputError: If parameters are invalid
        """
        try:
            if schema_type == "json_object":
                # Simple JSON object mode
                return {"type": "json_object"}
            
            elif schema_type == "json_schema":
                # JSON Schema mode - requires schema
                if model_class is not None:
                    # Generate from Pydantic model
                    if not issubclass(model_class, BaseModel):
                        raise StructuredOutputError(
                            "model_class must be a Pydantic BaseModel"
                        )
                    
                    schema = self.schema_generator.from_pydantic(model_class)
                    
                    return {
                        "type": "json_schema",
                        "json_schema": {
                            "name": model_class.__name__,
                            "schema": schema,
                            "strict": strict,
                        }
                    }
                
                elif schema_dict is not None:
                    # Use provided schema
                    schema = self.schema_generator.from_dict(schema_dict)
                    
                    return {
                        "type": "json_schema",
                        "json_schema": {
                            "name": schema_dict.get("title", "response"),
                            "schema": schema,
                            "strict": strict,
                        }
                    }
                
                else:
                    raise StructuredOutputError(
                        "json_schema type requires either model_class or schema_dict"
                    )
            
            else:
                raise StructuredOutputError(
                    f"Invalid schema_type: {schema_type}. "
                    "Must be 'json_object' or 'json_schema'"
                )
        
        except StructuredOutputError:
            raise
        except Exception as e:
            self.logger.error(f"Error creating response format: {e}")
            raise StructuredOutputError(f"Failed to create response format: {e}")
    
    def validate_response(
        self,
        response: str,
        schema: Optional[Dict[str, Any]] = None,
        model_class: Optional[Type[BaseModel]] = None,
    ) -> Union[Dict[str, Any], BaseModel]:
        """
        Validate and parse response
        
        Args:
            response: JSON response string
            schema: Optional JSON Schema for validation
            model_class: Optional Pydantic model class
            
        Returns:
            Validated dictionary or Pydantic model instance
            
        Raises:
            StructuredOutputError: If validation fails
        """
        try:
            # Parse to Pydantic model if provided
            if model_class is not None:
                return self.validator.parse_to_model(response, model_class)
            
            # Validate against schema if provided
            elif schema is not None:
                return self.validator.validate(response, schema)
            
            # Just parse JSON
            else:
                import json
                return json.loads(response)
        
        except StructuredOutputError:
            raise
        except Exception as e:
            self.logger.error(f"Error validating response: {e}")
            raise StructuredOutputError(f"Failed to validate response: {e}")
    
    def generate_schema(
        self,
        source: Union[Type[BaseModel], Type, Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Generate JSON Schema from various sources
        
        Args:
            source: Pydantic model, dataclass, or dict schema
            
        Returns:
            JSON Schema dictionary
            
        Raises:
            StructuredOutputError: If schema generation fails
        """
        try:
            # Pydantic model
            if isinstance(source, type) and issubclass(source, BaseModel):
                return self.schema_generator.from_pydantic(source)
            
            # Dataclass
            elif is_dataclass(source):
                return self.schema_generator.from_dataclass(source)
            
            # Dict schema
            elif isinstance(source, dict):
                return self.schema_generator.from_dict(source)
            
            else:
                raise StructuredOutputError(
                    f"Unsupported source type: {type(source)}. "
                    "Must be Pydantic model, dataclass, or dict"
                )
        
        except StructuredOutputError:
            raise
        except Exception as e:
            self.logger.error(f"Error generating schema: {e}")
            raise StructuredOutputError(f"Failed to generate schema: {e}")
