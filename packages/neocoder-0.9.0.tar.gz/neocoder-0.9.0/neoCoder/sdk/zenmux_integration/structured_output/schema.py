"""
JSON Schema generation for structured output
"""

from typing import Type, Dict, Any, Optional
from dataclasses import is_dataclass, fields as dataclass_fields, MISSING
from pydantic import BaseModel
import json

from ..utils import get_logger


class SchemaGenerator:
    """Generates JSON Schema from Python types"""
    
    def __init__(self):
        self.logger = get_logger("zenmux_integration.structured_output")
    
    def from_pydantic(self, model: Type[BaseModel]) -> Dict[str, Any]:
        """
        Generate JSON Schema from Pydantic model
        
        Args:
            model: Pydantic model class
            
        Returns:
            JSON Schema dictionary
        """
        try:
            # Use Pydantic's built-in schema generation
            schema = model.model_json_schema()
            
            # Ensure required fields
            if "$defs" in schema:
                # Move definitions to top level for compatibility
                definitions = schema.pop("$defs")
                schema["definitions"] = definitions
            
            self.logger.debug(f"Generated schema from Pydantic model: {model.__name__}")
            return schema
            
        except Exception as e:
            self.logger.error(f"Error generating schema from Pydantic: {e}")
            raise ValueError(f"Failed to generate schema from Pydantic model: {e}")
    
    def from_dataclass(self, cls: Type) -> Dict[str, Any]:
        """
        Generate JSON Schema from dataclass
        
        Args:
            cls: Dataclass type
            
        Returns:
            JSON Schema dictionary
        """
        if not is_dataclass(cls):
            raise ValueError(f"{cls} is not a dataclass")
        
        try:
            properties = {}
            required = []
            
            for field in dataclass_fields(cls):
                field_type = field.type
                field_schema = self._type_to_schema(field_type)
                
                properties[field.name] = field_schema
                
                # Check if field has default value
                if field.default is MISSING and field.default_factory is MISSING:
                    required.append(field.name)
            
            schema = {
                "type": "object",
                "properties": properties,
            }
            
            if required:
                schema["required"] = required
            
            self.logger.debug(f"Generated schema from dataclass: {cls.__name__}")
            return schema
            
        except Exception as e:
            self.logger.error(f"Error generating schema from dataclass: {e}")
            raise ValueError(f"Failed to generate schema from dataclass: {e}")
    
    def from_dict(self, schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate and normalize dict schema
        
        Args:
            schema: Schema dictionary
            
        Returns:
            Validated JSON Schema dictionary
        """
        try:
            # Basic validation
            if not isinstance(schema, dict):
                raise ValueError("Schema must be a dictionary")
            
            # Ensure it has type
            if "type" not in schema:
                raise ValueError("Schema must have 'type' field")
            
            # Validate structure
            self._validate_schema(schema)
            
            self.logger.debug("Validated dict schema")
            return schema
            
        except Exception as e:
            self.logger.error(f"Error validating dict schema: {e}")
            raise ValueError(f"Invalid schema dictionary: {e}")
    
    def _type_to_schema(self, python_type: Type) -> Dict[str, Any]:
        """
        Convert Python type to JSON Schema
        
        Args:
            python_type: Python type
            
        Returns:
            JSON Schema for the type
        """
        # Handle string type annotations
        if isinstance(python_type, str):
            return {"type": "string"}
        
        # Get origin for generic types
        origin = getattr(python_type, "__origin__", None)
        
        # Handle Optional types
        if origin is type(None):
            return {"type": "null"}
        
        # Handle List types
        if origin is list:
            args = getattr(python_type, "__args__", ())
            if args:
                return {
                    "type": "array",
                    "items": self._type_to_schema(args[0])
                }
            return {"type": "array"}
        
        # Handle Dict types
        if origin is dict:
            return {"type": "object"}
        
        # Handle basic types
        type_mapping = {
            str: {"type": "string"},
            int: {"type": "integer"},
            float: {"type": "number"},
            bool: {"type": "boolean"},
            list: {"type": "array"},
            dict: {"type": "object"},
        }
        
        return type_mapping.get(python_type, {"type": "string"})
    
    def _validate_schema(self, schema: Dict[str, Any]) -> None:
        """
        Validate JSON Schema structure
        
        Args:
            schema: Schema to validate
            
        Raises:
            ValueError: If schema is invalid
        """
        valid_types = ["object", "array", "string", "number", "integer", "boolean", "null"]
        
        schema_type = schema.get("type")
        if schema_type not in valid_types:
            raise ValueError(f"Invalid schema type: {schema_type}")
        
        # Validate object schema
        if schema_type == "object":
            if "properties" in schema:
                if not isinstance(schema["properties"], dict):
                    raise ValueError("'properties' must be a dictionary")
            
            if "required" in schema:
                if not isinstance(schema["required"], list):
                    raise ValueError("'required' must be a list")
        
        # Validate array schema
        if schema_type == "array":
            if "items" in schema:
                if not isinstance(schema["items"], dict):
                    raise ValueError("'items' must be a dictionary")
