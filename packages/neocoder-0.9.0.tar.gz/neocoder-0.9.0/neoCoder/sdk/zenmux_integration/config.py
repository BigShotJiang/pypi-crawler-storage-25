"""
Configuration management for Zenmux integration
"""

import os
from typing import Optional, Dict, Any
from pydantic import BaseModel, ConfigDict, Field, field_validator

class ZenmuxConfig(BaseModel):
    """Zenmux integration configuration"""
    model_config = ConfigDict(use_enum_values=True, validate_assignment=True)

    # API Configuration
    api_key: str = Field(
        default_factory=lambda: os.getenv("ZENMUX_API_KEY", ""),
        description="Zenmux API key"
    )
    base_url: str = Field(
        default="https://zenmux.ai/api/v1",
        description="Zenmux API base URL"
    )
    timeout: int = Field(
        default=60,
        ge=1,
        description="Request timeout in seconds"
    )
    max_retries: int = Field(
        default=3,
        ge=0,
        description="Maximum number of retries"
    )
    
    # Model Limits
    max_context_tokens: int = Field(
        default=400000,
        ge=1,
        description="Maximum context window size in tokens (400K for Zenmux)"
    )
    max_output_tokens: int = Field(
        default=128000,
        ge=1,
        description="Maximum output length in tokens (128K for Zenmux)"
    )
    
    # Streaming Configuration
    streaming_enabled: bool = Field(
        default=True,
        description="Enable streaming responses"
    )
    streaming_chunk_size: int = Field(
        default=1024,
        ge=1,
        description="Streaming chunk size in bytes"
    )
    streaming_timeout: int = Field(
        default=120,
        ge=1,
        description="Streaming timeout in seconds"
    )
    
    # Structured Output Configuration
    structured_output_enabled: bool = Field(
        default=True,
        description="Enable structured output"
    )
    strict_validation: bool = Field(
        default=True,
        description="Enable strict JSON schema validation"
    )
    
    # Tool Calling Configuration
    tool_calling_enabled: bool = Field(
        default=True,
        description="Enable tool calling"
    )
    max_tool_calls: int = Field(
        default=10,
        ge=1,
        description="Maximum number of tool calls per request"
    )
    tool_timeout: int = Field(
        default=30,
        ge=1,
        description="Tool execution timeout in seconds"
    )
    auto_execute_tools: bool = Field(
        default=True,
        description="Automatically execute tool calls"
    )
    
    # Prompt Caching Configuration
    prompt_caching_enabled: bool = Field(
        default=True,
        description="Enable prompt caching (explicit for Claude, implicit for others)"
    )
    min_tokens_for_cache: int = Field(
        default=1024,
        ge=256,
        description="Minimum tokens to trigger cache breakpoint"
    )
    max_cache_breakpoints: int = Field(
        default=4,
        ge=1,
        le=10,
        description="Maximum number of cache breakpoints"
    )
    
    # Reasoning Configuration
    reasoning_enabled: bool = Field(
        default=True,
        description="Enable reasoning models support"
    )
    default_reasoning_effort: str = Field(
        default="medium",
        description="Default reasoning effort level (low, medium, high)"
    )
    default_reasoning_max_tokens: Optional[int] = Field(
        default=8192,
        ge=1,
        le=128000,
        description="Default max tokens for reasoning output (max 128K)"
    )
    adaptive_reasoning: bool = Field(
        default=True,
        description="Enable adaptive reasoning effort adjustment"
    )
    
    # Logging Configuration
    log_level: str = Field(
        default="INFO",
        description="Logging level"
    )
    log_requests: bool = Field(
        default=True,
        description="Log API requests"
    )
    log_responses: bool = Field(
        default=False,
        description="Log API responses (may contain sensitive data)"
    )
    
    @field_validator("api_key")
    @classmethod
    def validate_api_key(cls, v: str) -> str:
        """Validate API key is not empty"""
        if not v or v.strip() == "":
            raise ValueError(
                "ZENMUX_API_KEY is required. "
                "Set it via environment variable or pass to ZenmuxConfig."
            )
        return v
    
    @field_validator("default_reasoning_max_tokens")
    @classmethod
    def validate_reasoning_max_tokens(cls, v: Optional[int], info) -> Optional[int]:
        """Validate reasoning max_tokens doesn't exceed model limit"""
        if v is not None:
            # Get max_output_tokens from the model (default 128000)
            max_output = info.data.get("max_output_tokens", 128000)
            if v > max_output:
                raise ValueError(
                    f"default_reasoning_max_tokens ({v}) cannot exceed "
                    f"max_output_tokens ({max_output})"
                )
        return v
    
    @field_validator("default_reasoning_effort")
    @classmethod
    def validate_reasoning_effort(cls, v: str) -> str:
        """Validate reasoning effort level"""
        valid_efforts = ["low", "medium", "high"]
        if v not in valid_efforts:
            raise ValueError(
                f"Invalid reasoning effort: {v}. "
                f"Must be one of: {', '.join(valid_efforts)}"
            )
        return v
    
    @classmethod
    def from_env(cls) -> "ZenmuxConfig":
        """Create configuration from environment variables"""
        return cls(
            api_key=os.getenv("ZENMUX_API_KEY", ""),
            base_url=os.getenv("ZENMUX_BASE_URL", "https://zenmux.ai/api/v1"),
            timeout=int(os.getenv("ZENMUX_TIMEOUT", "60")),
            streaming_enabled=os.getenv("ZENMUX_STREAMING_ENABLED", "true").lower() == "true",
            log_level=os.getenv("ZENMUX_LOG_LEVEL", "INFO"),
        )
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "ZenmuxConfig":
        """Create configuration from dictionary"""
        return cls(**config_dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary"""
        return self.model_dump()
