"""
Data models for streaming
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, ConfigDict, Field


class StreamChunk(BaseModel):
    """Single streaming chunk"""
    model_config = ConfigDict(frozen=False)

    content: str = Field(default="", description="Chunk content")
    role: str = Field(default="assistant", description="Message role")
    finish_reason: Optional[str] = Field(default=None, description="Finish reason")
    tool_calls: Optional[List[Dict[str, Any]]] = Field(
        default=None,
        description="Tool calls in this chunk"
    )
    index: int = Field(default=0, description="Chunk index")


class ToolCallChunk(BaseModel):
    """Tool call chunk for streaming"""
    model_config = ConfigDict(frozen=False)

    index: int = Field(description="Tool call index")
    id: Optional[str] = Field(default=None, description="Tool call ID")
    type: str = Field(default="function", description="Tool call type")
    function_name: Optional[str] = Field(default=None, description="Function name")
    function_arguments: str = Field(default="", description="Function arguments (partial)")


class StreamMetrics(BaseModel):
    """Metrics for streaming performance"""
    model_config = ConfigDict(frozen=False)

    ttft: float = Field(default=0.0, description="Time to first token (seconds)")
    total_time: float = Field(default=0.0, description="Total streaming time (seconds)")
    chunks_received: int = Field(default=0, description="Number of chunks received")
    total_tokens: int = Field(default=0, description="Total tokens received")
    tokens_per_second: float = Field(default=0.0, description="Tokens per second")
    
    def calculate_tps(self):
        """Calculate tokens per second"""
        if self.total_time > 0:
            self.tokens_per_second = self.total_tokens / self.total_time
