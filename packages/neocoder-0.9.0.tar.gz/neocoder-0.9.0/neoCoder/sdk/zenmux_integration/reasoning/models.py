"""
Data models for reasoning control
"""

from enum import Enum
from typing import List, Optional, Dict, Any
from datetime import datetime
from pydantic import BaseModel, Field


class TaskComplexity(str, Enum):
    """Task complexity levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ReasoningEffort(str, Enum):
    """Reasoning effort levels"""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class ReasoningTrace(BaseModel):
    """Reasoning trace from model response"""
    
    thinking: str = Field(
        description="Raw thinking/reasoning content from model"
    )
    steps: List[str] = Field(
        default_factory=list,
        description="Individual reasoning steps extracted"
    )
    conclusion: str = Field(
        default="",
        description="Final conclusion from reasoning"
    )
    tokens_used: int = Field(
        default=0,
        description="Number of tokens used for reasoning"
    )
    duration_ms: Optional[float] = Field(
        default=None,
        description="Time taken for reasoning in milliseconds"
    )
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata"
    )
    
    def __str__(self) -> str:
        """String representation"""
        return f"ReasoningTrace(steps={len(self.steps)}, tokens={self.tokens_used})"
    
    def get_summary(self) -> str:
        """Get summary of reasoning trace"""
        return f"{len(self.steps)} steps, {self.tokens_used} tokens"


class ReasoningPerformance(BaseModel):
    """Performance metrics for reasoning execution"""
    
    task: str = Field(description="Task description")
    complexity: TaskComplexity = Field(description="Detected task complexity")
    effort: ReasoningEffort = Field(description="Reasoning effort used")
    
    tokens_used: int = Field(description="Total tokens used")
    reasoning_tokens: int = Field(
        default=0,
        description="Tokens used specifically for reasoning"
    )
    completion_tokens: int = Field(
        default=0,
        description="Tokens used for completion"
    )
    
    duration_ms: float = Field(description="Total duration in milliseconds")
    success: bool = Field(description="Whether task completed successfully")
    
    quality_score: Optional[float] = Field(
        default=None,
        description="Quality score (0-1) if available"
    )
    
    timestamp: datetime = Field(
        default_factory=datetime.now,
        description="When this performance was recorded"
    )
    
    metadata: Dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata"
    )
    
    def get_efficiency_score(self) -> float:
        """
        Calculate efficiency score (quality per token)
        
        Returns:
            Efficiency score (0-1), or 0 if quality_score not available
        """
        if self.quality_score is None or self.tokens_used == 0:
            return 0.0
        
        # Normalize by tokens (higher quality with fewer tokens = better)
        return self.quality_score / (1 + self.tokens_used / 1000)
    
    def should_increase_effort(self) -> bool:
        """
        Determine if effort should be increased for similar tasks
        
        Returns:
            True if effort should be increased
        """
        # Increase if failed or low quality
        if not self.success:
            return True
        
        if self.quality_score is not None and self.quality_score < 0.7:
            return True
        
        return False
    
    def should_decrease_effort(self) -> bool:
        """
        Determine if effort can be decreased for similar tasks
        
        Returns:
            True if effort can be decreased
        """
        # Decrease if high quality with high effort
        if self.success and self.effort == ReasoningEffort.HIGH:
            if self.quality_score is not None and self.quality_score > 0.9:
                return True
        
        return False


class ReasoningConfig(BaseModel):
    """Configuration for reasoning control"""
    
    enabled: bool = Field(
        default=True,
        description="Enable reasoning control"
    )
    
    effort: Optional[ReasoningEffort] = Field(
        default=None,
        description="Fixed reasoning effort (None for adaptive)"
    )
    
    max_tokens: Optional[int] = Field(
        default=None,
        description="Maximum tokens for reasoning"
    )
    
    adaptive: bool = Field(
        default=True,
        description="Enable adaptive effort adjustment"
    )
    
    track_performance: bool = Field(
        default=True,
        description="Track performance metrics"
    )
    
    extract_traces: bool = Field(
        default=True,
        description="Extract reasoning traces from responses"
    )
    
    # Complexity detection settings
    complexity_keywords: Dict[TaskComplexity, List[str]] = Field(
        default_factory=lambda: {
            TaskComplexity.LOW: [
                "simple", "basic", "straightforward", "quick",
                "list", "show", "display", "what is"
            ],
            TaskComplexity.MEDIUM: [
                "analyze", "compare", "explain", "describe",
                "how", "why", "implement", "create"
            ],
            TaskComplexity.HIGH: [
                "complex", "optimize", "design", "architect",
                "solve", "debug", "refactor", "prove",
                "mathematical", "algorithm", "system",
                "analyzing potential issues", "assessing potential code issues",
                "evaluating potential issues", "clarifying model calculations",
                "reviewing potential code issues"
            ]
        }
    )
    
    # Token limits by effort
    token_limits: Dict[ReasoningEffort, int] = Field(
        default_factory=lambda: {
            ReasoningEffort.LOW: 1000,
            ReasoningEffort.MEDIUM: 5000,
            ReasoningEffort.HIGH: 50000,
        }
    )
    
    # Thinking budget limits for Anthropic models (extended thinking)
    thinking_budget_limits: Dict[ReasoningEffort, int] = Field(
        default_factory=lambda: {
            ReasoningEffort.LOW: 10000,
            ReasoningEffort.MEDIUM: 30000,
            ReasoningEffort.HIGH: 63900,
        }
    )
    
    # Performance history settings
    max_history_size: int = Field(
        default=100,
        description="Maximum number of performance records to keep"
    )
    
    min_samples_for_adaptation: int = Field(
        default=5,
        description="Minimum samples before adapting effort"
    )


class ReasoningParams(BaseModel):
    """Parameters for reasoning API calls"""
    
    reasoning_effort: Optional[str] = Field(
        default=None,
        description="Reasoning effort level (low, medium, high)"
    )
    
    max_completion_tokens: Optional[int] = Field(
        default=None,
        description="Maximum tokens for completion"
    )
    
    thinking_budget: Optional[int] = Field(
        default=None,
        description="Thinking token budget - for Anthropic Claude extended thinking (NOTE: Extended Thinking is automatic, this is for reference only)"
    )
    
    reasoning: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Additional reasoning parameters"
    )
    
    def to_api_params(self, model: Optional[str] = None) -> Dict[str, Any]:
        """
        Convert to API parameters
        
        Args:
            model: Model identifier to determine parameter format
        
        Returns:
            Dictionary of API parameters
            
        Note:
            Anthropic Extended Thinking uses the 'thinking' parameter:
            {
                "thinking": {
                    "type": "enabled",
                    "budget_tokens": 10000  # >= 1024 and < max_tokens
                }
            }
            Response includes content blocks with type="thinking".
        """
        params = {}
        
        # Detect model type
        is_anthropic = model and ("claude" in model.lower() or "anthropic" in model.lower())
        
        # Reasoning effort (for models that support it)
        if self.reasoning_effort and not is_anthropic:
            params["reasoning_effort"] = self.reasoning_effort
        
        # Anthropic Extended Thinking
        if is_anthropic or self.thinking_budget:
            if self.thinking_budget:
                # Ensure budget is >= 1024
                budget = max(1024, self.thinking_budget)
                params["thinking"] = {
                    "type": "enabled",
                    "budget_tokens": budget
                }
        
        if self.max_completion_tokens:
            params["max_completion_tokens"] = self.max_completion_tokens
        
        if self.reasoning:
            params["reasoning"] = self.reasoning
        
        return params
