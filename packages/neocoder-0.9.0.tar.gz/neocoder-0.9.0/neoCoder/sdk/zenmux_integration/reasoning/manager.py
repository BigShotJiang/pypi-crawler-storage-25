"""
Adaptive reasoning manager
"""

import time
from typing import Optional, Dict, Any, List
from collections import deque
from .models import (
    ReasoningPerformance,
    ReasoningConfig,
    ReasoningEffort,
    TaskComplexity,
)
from .controller import ReasoningController
from .extractor import ReasoningTraceExtractor


class AdaptiveReasoningManager:
    """
    Manages adaptive reasoning effort based on performance
    
    Features:
    - Performance tracking
    - Automatic effort adjustment
    - Learning from history
    - Metrics collection
    """
    
    def __init__(
        self,
        config: Optional[ReasoningConfig] = None,
        client: Optional[Any] = None
    ):
        """
        Initialize adaptive reasoning manager
        
        Args:
            config: Reasoning configuration
            client: ZenmuxClient instance
        """
        self.config = config or ReasoningConfig()
        self.controller = ReasoningController(self.config)
        self.extractor = ReasoningTraceExtractor()
        self.client = client
        
        # Performance history (limited size deque)
        self.performance_history: deque = deque(
            maxlen=self.config.max_history_size
        )
        
        # Task-specific effort cache
        self._effort_cache: Dict[str, ReasoningEffort] = {}
    
    async def execute_with_adaptive_reasoning(
        self,
        task: str,
        messages: List[Dict[str, Any]],
        model: str,
        context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Execute with adaptive reasoning effort
        
        Args:
            task: Task description
            messages: Message list
            model: Model identifier
            context: Optional context
            **kwargs: Additional parameters
            
        Returns:
            Dictionary with response and performance metrics
        """
        if not self.client:
            raise ValueError("Client not set. Initialize with client parameter.")
        
        # Get initial effort recommendation
        effort = self._get_recommended_effort(task, context)
        
        # Create reasoning params
        params = self.controller.create_reasoning_params(
            effort=effort,
            enabled=True
        )
        
        # Track start time
        start_time = time.time()
        
        # Make API call with reasoning
        response = await self.client.complete(
            messages=messages,
            model=model,
            reasoning=params.to_api_params(),
            **kwargs
        )
        
        # Calculate duration
        duration_ms = (time.time() - start_time) * 1000
        
        # Extract reasoning trace if available
        trace = None
        if self.config.extract_traces:
            trace = self.extractor.extract(response)
        
        # Get token usage
        tokens_used = 0
        reasoning_tokens = 0
        completion_tokens = 0
        
        if hasattr(response, 'usage'):
            usage = response.usage
            tokens_used = getattr(usage, 'total_tokens', 0)
            reasoning_tokens = getattr(usage, 'reasoning_tokens', 0)
            completion_tokens = getattr(usage, 'completion_tokens', 0)
        
        # Detect complexity
        complexity = self.controller.analyzer.analyze(task, context)
        
        # Track performance
        performance = ReasoningPerformance(
            task=task,
            complexity=complexity,
            effort=effort,
            tokens_used=tokens_used,
            reasoning_tokens=reasoning_tokens,
            completion_tokens=completion_tokens,
            duration_ms=duration_ms,
            success=True,  # Assume success if no exception
            metadata={
                "model": model,
                "has_trace": trace is not None,
            }
        )
        
        if self.config.track_performance:
            self._track_performance(performance)
        
        # Adapt effort for future similar tasks
        if self.config.adaptive:
            self._adapt_effort(task, performance)
        
        return {
            "response": response,
            "performance": performance,
            "trace": trace,
            "effort_used": effort,
            "tokens_used": tokens_used,
            "reasoning_tokens": reasoning_tokens,
            "duration_ms": duration_ms,
        }
    
    def _get_recommended_effort(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None
    ) -> ReasoningEffort:
        """
        Get recommended effort for task
        
        Args:
            task: Task description
            context: Optional context
            
        Returns:
            Recommended effort level
        """
        # Check cache first
        task_key = self._get_task_key(task)
        if task_key in self._effort_cache:
            return self._effort_cache[task_key]
        
        # Use controller to analyze
        params = self.controller.auto_configure(task, context)
        
        if params.reasoning_effort:
            return ReasoningEffort(params.reasoning_effort)
        
        return ReasoningEffort.MEDIUM
    
    def _track_performance(self, performance: ReasoningPerformance):
        """
        Track performance in history
        
        Args:
            performance: Performance record
        """
        self.performance_history.append(performance)
    
    def _adapt_effort(self, task: str, performance: ReasoningPerformance):
        """
        Adapt effort based on performance
        
        Args:
            task: Task description
            performance: Performance record
        """
        # Need minimum samples before adapting
        if len(self.performance_history) < self.config.min_samples_for_adaptation:
            return
        
        # Get similar tasks from history
        similar_tasks = self._get_similar_tasks(task)
        
        if len(similar_tasks) < 2:
            return
        
        # Analyze performance trends
        if performance.should_increase_effort():
            # Increase effort for this task type
            new_effort = self.controller.adjust_effort(
                performance.effort,
                increase=True
            )
            self._effort_cache[self._get_task_key(task)] = new_effort
        
        elif performance.should_decrease_effort():
            # Decrease effort for this task type
            new_effort = self.controller.adjust_effort(
                performance.effort,
                increase=False
            )
            self._effort_cache[self._get_task_key(task)] = new_effort
    
    def _get_similar_tasks(
        self,
        task: str,
        max_results: int = 10
    ) -> List[ReasoningPerformance]:
        """
        Get similar tasks from history
        
        Args:
            task: Task description
            max_results: Maximum results to return
            
        Returns:
            List of similar task performances
        """
        # Simple similarity: same complexity
        task_complexity = self.controller.analyzer.analyze(task)
        
        similar = [
            perf for perf in self.performance_history
            if perf.complexity == task_complexity
        ]
        
        return similar[-max_results:]
    
    def _get_task_key(self, task: str) -> str:
        """
        Get cache key for task
        
        Args:
            task: Task description
            
        Returns:
            Cache key
        """
        # Simple key: first 100 chars lowercased
        return task[:100].lower().strip()
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Get performance statistics
        
        Returns:
            Dictionary of statistics
        """
        if not self.performance_history:
            return {
                "total_executions": 0,
                "average_tokens": 0,
                "average_duration_ms": 0,
                "success_rate": 0.0,
                "effort_distribution": {},
                "complexity_distribution": {},
            }
        
        total = len(self.performance_history)
        successful = sum(1 for p in self.performance_history if p.success)
        
        avg_tokens = sum(p.tokens_used for p in self.performance_history) / total
        avg_duration = sum(p.duration_ms for p in self.performance_history) / total
        
        # Effort distribution
        effort_dist = {}
        for effort in ReasoningEffort:
            count = sum(
                1 for p in self.performance_history
                if p.effort == effort
            )
            effort_dist[effort.value] = count
        
        # Complexity distribution
        complexity_dist = {}
        for complexity in TaskComplexity:
            count = sum(
                1 for p in self.performance_history
                if p.complexity == complexity
            )
            complexity_dist[complexity.value] = count
        
        return {
            "total_executions": total,
            "successful": successful,
            "failed": total - successful,
            "success_rate": successful / total if total > 0 else 0.0,
            "average_tokens": avg_tokens,
            "average_reasoning_tokens": sum(
                p.reasoning_tokens for p in self.performance_history
            ) / total,
            "average_duration_ms": avg_duration,
            "effort_distribution": effort_dist,
            "complexity_distribution": complexity_dist,
            "cached_efforts": len(self._effort_cache),
        }
    
    def get_performance_history(
        self,
        limit: Optional[int] = None,
        complexity: Optional[TaskComplexity] = None,
        effort: Optional[ReasoningEffort] = None
    ) -> List[ReasoningPerformance]:
        """
        Get performance history with optional filtering
        
        Args:
            limit: Maximum number of records
            complexity: Filter by complexity
            effort: Filter by effort
            
        Returns:
            List of performance records
        """
        history = list(self.performance_history)
        
        # Apply filters
        if complexity:
            history = [p for p in history if p.complexity == complexity]
        
        if effort:
            history = [p for p in history if p.effort == effort]
        
        # Apply limit
        if limit:
            history = history[-limit:]
        
        return history
    
    def clear_history(self):
        """Clear performance history"""
        self.performance_history.clear()
        self._effort_cache.clear()
    
    def export_history(self) -> List[Dict[str, Any]]:
        """
        Export performance history as JSON-serializable list
        
        Returns:
            List of performance dictionaries
        """
        return [
            perf.model_dump()
            for perf in self.performance_history
        ]
    
    def import_history(self, history_data: List[Dict[str, Any]]):
        """
        Import performance history from JSON data
        
        Args:
            history_data: List of performance dictionaries
        """
        for data in history_data:
            try:
                perf = ReasoningPerformance(**data)
                self.performance_history.append(perf)
            except Exception:
                # Skip invalid records
                pass
