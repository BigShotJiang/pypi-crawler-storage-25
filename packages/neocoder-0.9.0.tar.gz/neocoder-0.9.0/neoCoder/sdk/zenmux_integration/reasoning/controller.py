"""
Reasoning controller for managing reasoning parameters
"""

from typing import Optional, Dict, Any
from .models import (
    TaskComplexity,
    ReasoningEffort,
    ReasoningConfig,
    ReasoningParams,
)
from .analyzer import TaskComplexityAnalyzer


class ReasoningController:
    """
    Controls reasoning model behavior
    
    Features:
    - Automatic complexity detection
    - Parameter generation for API calls
    - Effort level management
    """
    
    def __init__(self, config: Optional[ReasoningConfig] = None):
        """
        Initialize controller
        
        Args:
            config: Reasoning configuration
        """
        self.config = config or ReasoningConfig()
        self.analyzer = TaskComplexityAnalyzer(self.config)
    
    def create_reasoning_params(
        self,
        task_complexity: Optional[TaskComplexity] = None,
        effort: Optional[ReasoningEffort] = None,
        max_tokens: Optional[int] = None,
        thinking_budget: Optional[int] = None,
        model: Optional[str] = None,
        enabled: bool = True,
        **kwargs
    ) -> ReasoningParams:
        """
        Create reasoning parameters for API call
        
        Args:
            task_complexity: Task complexity level
            effort: Reasoning effort level (overrides complexity-based)
            max_tokens: Maximum tokens for reasoning
            thinking_budget: Thinking token budget for Anthropic models
            model: Model identifier to determine parameter format
            enabled: Enable reasoning
            **kwargs: Additional parameters
            
        Returns:
            ReasoningParams object
        """
        if not enabled or not self.config.enabled:
            return ReasoningParams()
        
        # Determine effort level
        if effort is None and task_complexity is not None:
            # Map complexity to effort
            effort_map = {
                TaskComplexity.LOW: ReasoningEffort.LOW,
                TaskComplexity.MEDIUM: ReasoningEffort.MEDIUM,
                TaskComplexity.HIGH: ReasoningEffort.HIGH,
            }
            effort = effort_map[task_complexity]
        
        # Use config default if still None
        if effort is None:
            effort = self.config.effort or ReasoningEffort.MEDIUM
        
        # Detect model type
        is_anthropic = model and ("claude" in model.lower() or "anthropic" in model.lower())
        
        # Determine thinking budget for Anthropic models
        if is_anthropic and thinking_budget is None:
            thinking_budget = self.config.thinking_budget_limits.get(effort, 5000)
        
        # Determine max tokens for non-Anthropic models
        if max_tokens is None and not is_anthropic:
            max_tokens = self.config.token_limits.get(effort, 5000)
        
        # Build reasoning params
        params = ReasoningParams(
            reasoning_effort=effort.value if not is_anthropic else None,
            max_completion_tokens=max_tokens,
            thinking_budget=thinking_budget if is_anthropic else None,
            reasoning=kwargs if kwargs else None
        )
        
        return params
    
    def auto_configure(
        self,
        task: str,
        context: Optional[Dict[str, Any]] = None,
        override_effort: Optional[ReasoningEffort] = None,
        model: Optional[str] = None
    ) -> ReasoningParams:
        """
        Auto-configure reasoning based on task
        
        Args:
            task: Task description
            context: Optional context information
            override_effort: Override detected effort level
            model: Model identifier to determine parameter format
            
        Returns:
            ReasoningParams object
        """
        if not self.config.enabled:
            return ReasoningParams()
        
        # Detect task features
        features = self.analyzer.detect_task_features(task)
        
        # Merge features into context
        full_context = {**(context or {}), **features}
        
        # Analyze complexity
        complexity = self.analyzer.analyze(task, full_context)
        
        # Determine effort
        effort = override_effort or self.analyzer.recommend_effort(task, full_context)
        
        # Estimate tokens
        max_tokens = self.analyzer.estimate_tokens(complexity, effort)
        
        # Create params
        return self.create_reasoning_params(
            task_complexity=complexity,
            effort=effort,
            max_tokens=max_tokens,
            model=model,
            enabled=True
        )
    
    def validate_params(self, params: ReasoningParams) -> bool:
        """
        Validate reasoning parameters
        
        Args:
            params: Parameters to validate
            
        Returns:
            True if valid, False otherwise
        """
        # Check effort level
        if params.reasoning_effort:
            try:
                ReasoningEffort(params.reasoning_effort)
            except ValueError:
                return False
        
        # Check token limits
        if params.max_completion_tokens:
            if params.max_completion_tokens < 0:
                return False
            if params.max_completion_tokens > 100000:  # Reasonable upper limit
                return False
        
        return True
    
    def adjust_effort(
        self,
        current_effort: ReasoningEffort,
        increase: bool
    ) -> ReasoningEffort:
        """
        Adjust reasoning effort level
        
        Args:
            current_effort: Current effort level
            increase: True to increase, False to decrease
            
        Returns:
            Adjusted effort level
        """
        efforts = [ReasoningEffort.LOW, ReasoningEffort.MEDIUM, ReasoningEffort.HIGH]
        current_index = efforts.index(current_effort)
        
        if increase:
            new_index = min(current_index + 1, len(efforts) - 1)
        else:
            new_index = max(current_index - 1, 0)
        
        return efforts[new_index]
    
    def get_effort_description(self, effort: ReasoningEffort) -> str:
        """
        Get human-readable description of effort level
        
        Args:
            effort: Effort level
            
        Returns:
            Description string
        """
        descriptions = {
            ReasoningEffort.LOW: (
                "Low effort - Quick reasoning for simple tasks. "
                "Uses ~1000 tokens."
            ),
            ReasoningEffort.MEDIUM: (
                "Medium effort - Balanced reasoning for typical tasks. "
                "Uses ~5000 tokens."
            ),
            ReasoningEffort.HIGH: (
                "High effort - Deep reasoning for complex tasks. "
                "Uses ~20000 tokens."
            ),
        }
        return descriptions.get(effort, "Unknown effort level")
    
    def estimate_cost(
        self,
        effort: ReasoningEffort,
        model: str = "anthropic/claude-3-5-sonnet-20241022"
    ) -> Dict[str, float]:
        """
        Estimate cost for reasoning
        
        Args:
            effort: Reasoning effort level
            model: Model identifier
            
        Returns:
            Dictionary with cost estimates
        """
        # Token estimates
        token_estimates = self.config.token_limits
        tokens = token_estimates.get(effort, 5000)
        
        # Rough cost estimates (per 1M tokens)
        # These are approximate and should be updated based on actual pricing
        cost_per_million = {
            "anthropic/claude-3-5-sonnet-20241022": 3.0,  # $3 per 1M output tokens
            "anthropic/claude-3-opus-20240229": 75.0,  # $75 per 1M output tokens
        }
        
        base_cost = cost_per_million.get(model, 10.0)
        estimated_cost = (tokens / 1_000_000) * base_cost
        
        return {
            "tokens": tokens,
            "cost_usd": estimated_cost,
            "cost_per_million": base_cost,
        }
