"""
Custom exceptions for Zenmux integration
"""


class ZenmuxError(Exception):
    """Base exception for Zenmux integration"""
    pass


class StreamingError(ZenmuxError):
    """Streaming-related errors"""
    pass


class StructuredOutputError(ZenmuxError):
    """Structured output validation errors"""
    pass


class ToolExecutionError(ZenmuxError):
    """Tool execution errors"""
    pass


class ReasoningError(ZenmuxError):
    """Reasoning-related errors"""
    pass


class ConfigurationError(ZenmuxError):
    """Configuration errors"""
    pass


class AuthenticationError(ZenmuxError):
    """Authentication errors"""
    pass


class RateLimitError(ZenmuxError):
    """Rate limit exceeded errors"""
    pass
