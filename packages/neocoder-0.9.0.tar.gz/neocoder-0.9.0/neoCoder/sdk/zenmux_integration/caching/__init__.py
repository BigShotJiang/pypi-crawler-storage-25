"""
Prompt Caching for ZenMux integration.

Supports both implicit (auto) and explicit caching strategies:
- Implicit: OpenAI, DeepSeek, Grok, Gemini, Qwen (no config needed)
- Explicit: Anthropic Claude (requires cache_control markers)

Usage:
    from neoCoder.sdk.zenmux_integration.caching import PromptCacheManager

    cache_manager = PromptCacheManager()
    
    # Add cache breakpoints to messages
    cached_messages = cache_manager.apply_cache_control(
        messages=messages,
        system_prompt=system_prompt,
        tools=tools,
    )
"""

from .manager import PromptCacheManager
from .strategy import CacheStrategy, ExplicitCacheStrategy, ImplicitCacheStrategy
from .breakpoints import CacheBreakpointPlacer

__all__ = [
    "PromptCacheManager",
    "CacheStrategy",
    "ExplicitCacheStrategy",
    "ImplicitCacheStrategy",
    "CacheBreakpointPlacer",
]
