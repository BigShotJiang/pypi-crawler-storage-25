"""
Base extension class and context for the neoCoder SDK.

Extensions are modular components that attach to the orchestrator and
participate in each iteration of the agent loop. They handle:
- Perception: Parse model outputs into structured actions
- Reasoning: Rewrite or annotate messages before LLM invocation
- Action: Execute tools and persist results

Supports both sync and async execution for flexible orchestration.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Callable, TYPE_CHECKING
from enum import Enum

if TYPE_CHECKING:
    from neoCoder.sdk.memory.working import WorkingMemory
    from neoCoder.sdk.llm.output_parser import Action
    from neoCoder.sdk.extensions.interactive_confirm import ConfirmationCallback


class CallbackPhase(Enum):
    """Phases when extension callbacks are invoked."""

    PRE_LLM = "pre_llm"  # Before LLM invocation
    POST_LLM = "post_llm"  # After LLM response
    PRE_ACTION = "pre_action"  # Before action execution
    POST_ACTION = "post_action"  # After action execution


@dataclass
class ExtensionContext:
    """
    Shared context passed to extension callbacks.

    Provides access to:
    - I/O interface for user interaction
    - Session storage
    - Hierarchical memory
    - Artifact storage
    """

    memory: WorkingMemory
    session_id: str
    working_dir: str
    artifacts: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)

    # Callbacks for UX output (what users see)
    on_user_output: Callable[[str], None] | None = None
    on_user_output_stream: Callable[[str], None] | None = None
    
    # Callback for interactive confirmation of file changes
    confirmation_callback: ConfirmationCallback | None = None

    def output_to_user(self, message: str) -> None:
        """Output a message to the user (UX)."""
        if self.on_user_output:
            self.on_user_output(message)

    def stream_to_user(self, chunk: str) -> None:
        """Stream a chunk to the user (UX)."""
        if self.on_user_output_stream:
            self.on_user_output_stream(chunk)

    def store_artifact(self, key: str, value: Any) -> None:
        """Store an artifact for later retrieval."""
        self.artifacts[key] = value

    def get_artifact(self, key: str, default: Any = None) -> Any:
        """Retrieve a stored artifact."""
        return self.artifacts.get(key, default)


@dataclass
class ExecutionResult:
    """Result of executing an action through an extension."""

    success: bool
    output: str  # Compressed output for AX (agent memory)
    user_output: str | None = None  # Rich output for UX (user display)
    error: str | None = None
    should_continue: bool = True  # Whether orchestrator should continue
    artifacts: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)  # Additional metadata (e.g., task_complete flag)

    @classmethod
    def success_result(
        cls,
        output: str,
        user_output: str | None = ...,  # Use ... as sentinel for "not provided"
        artifacts: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> ExecutionResult:
        """Create a successful result."""
        # If user_output not provided (default ...), use output
        # If explicitly None, keep it None (don't show to user)
        # If provided as string, use that string
        if user_output is ...:
            user_output = output
        
        return cls(
            success=True,
            output=output,
            user_output=user_output,
            artifacts=artifacts or {},
            metadata=metadata or {},
        )

    @classmethod
    def error_result(
        cls,
        error: str,
        should_continue: bool = True,
        user_output: str | None = None,
    ) -> ExecutionResult:
        """Create an error result."""
        return cls(
            success=False,
            output=f"Error: {error}",
            user_output=user_output or f"Error: {error}",
            error=error,
            should_continue=should_continue,
        )


class Extension(ABC):
    """
    Base class for all extensions.

    Extensions define tool-use behavior, parsing, prompt shaping, and
    interaction policies through typed callbacks. Each extension has:
    - A name for routing actions
    - Tool definitions for LLM
    - Callbacks for different phases of the agent loop
    """

    def __init__(self):
        self._enabled = True

    @property
    @abstractmethod
    def name(self) -> str:
        """Unique name for this extension."""
        pass

    @property
    def enabled(self) -> bool:
        """Whether this extension is enabled."""
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        """
        Tool definitions for the LLM.

        Returns:
            List of tool definitions in Claude tool format.
        """
        return []

    @property
    def xml_tags(self) -> list[str]:
        """
        XML tags this extension handles.

        Returns:
            List of tag names (e.g., ["bash", "shell"]).
        """
        return []

    def on_input_messages(
        self, messages: list[dict[str, Any]], context: ExtensionContext
    ) -> list[dict[str, Any]]:
        """
        Hook called before messages are sent to LLM.

        Can modify messages, add format instructions, or inject context.

        Args:
            messages: Current message list.
            context: Extension context.

        Returns:
            Modified message list.
        """
        return messages

    def on_llm_output(self, output: str, context: ExtensionContext) -> str:
        """
        Hook called after LLM response, before action parsing.

        Can filter or transform the output.

        Args:
            output: Raw LLM output text.
            context: Extension context.

        Returns:
            Transformed output.
        """
        return output

    def can_handle(self, action: Action) -> bool:
        """
        Check if this extension can handle the given action.

        Args:
            action: Parsed action.

        Returns:
            True if this extension should handle the action.
        """
        # Check if action name matches extension name or XML tags
        if action.name == self.name:
            return True
        if action.name in self.xml_tags:
            return True
        return False

    @abstractmethod
    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """
        Execute an action (sync).

        Args:
            action: The action to execute.
            context: Extension context.

        Returns:
            ExecutionResult with output for AX and UX.
        """
        pass

    async def execute_async(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """
        Execute an action (async).
        
        Default implementation runs sync execute in thread pool.
        Subclasses can override for native async support (e.g., async HTTP calls).

        Args:
            action: The action to execute.
            context: Extension context.

        Returns:
            ExecutionResult with output for AX and UX.
        """
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None,
            lambda: self.execute(action, context)
        )

    def on_error(self, error: Exception, context: ExtensionContext) -> ExecutionResult | None:
        """
        Handle an error during execution.

        Args:
            error: The exception that occurred.
            context: Extension context.

        Returns:
            ExecutionResult if error was handled, None to propagate.
        """
        return None

    def signals_continuation(self) -> bool:
        """
        Whether this extension typically signals continuation.

        Some extensions (like bash) usually want the agent to continue
        processing after their execution.

        Returns:
            True if continuation is typical.
        """
        return True


class CompositeExtension(Extension):
    """
    An extension that composes multiple sub-extensions.

    Useful for grouping related functionality.
    """

    def __init__(self, name: str, extensions: list[Extension]):
        super().__init__()
        self._name = name
        self._extensions = extensions

    @property
    def name(self) -> str:
        return self._name

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        definitions = []
        for ext in self._extensions:
            definitions.extend(ext.tool_definitions)
        return definitions

    @property
    def xml_tags(self) -> list[str]:
        tags = []
        for ext in self._extensions:
            tags.extend(ext.xml_tags)
        return tags

    def can_handle(self, action: Action) -> bool:
        return any(ext.can_handle(action) for ext in self._extensions)

    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        for ext in self._extensions:
            if ext.can_handle(action):
                return ext.execute(action, context)
        return ExecutionResult.error_result(f"No handler found for action: {action.name}")
