"""
Memory Extension - Programmable Context for LLM.

Allows the LLM to explicitly manage its own working memory and notes,
implementing "Context as Cognitive Architecture" pattern.

Tools:
- memory_store: Store a note in working or hierarchical memory
- memory_get: Retrieve a stored note
- memory_list: List all stored notes/keys
- memory_search_episodes: Search past task episodes for relevant context
- procedure_search: Search for relevant procedures (learned workflows)
- procedure_list: List all available procedures
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.llm.output_parser import Action
from neoCoder.sdk.memory.hierarchical import HierarchicalMemory, MemoryScope
from neoCoder.sdk.memory.episodic import EpisodicMemory
from neoCoder.sdk.memory.procedural import ProceduralMemory
from neoCoder.sdk.memory.notes import NotesStorage, Note

logger = logging.getLogger(__name__)


@dataclass
class MemoryExtensionConfig:
    """Configuration for memory extension."""

    max_value_size: int = 4096  # Max chars per stored value
    reserved_prefix: str = "_internal/"  # Reserved key prefix
    enable_episodic_search: bool = True
    enable_procedural_search: bool = True
    enable_notes_search: bool = True


class MemoryExtension(Extension):
    """
    Extension for programmable working memory.

    Lets the LLM explicitly store and retrieve notes, implementing
    the "Context as Cognitive Architecture" pattern from research.
    """

    __slots__ = (
        "config",
        "_hierarchical_memory",
        "_episodic_memory",
        "_procedural_memory",
        "_notes_storage",
    )

    def __init__(
        self,
        config: MemoryExtensionConfig | None = None,
        hierarchical_memory: HierarchicalMemory | None = None,
        episodic_memory: EpisodicMemory | None = None,
        procedural_memory: ProceduralMemory | None = None,
        notes_storage: NotesStorage | None = None,
    ):
        """
        Initialize memory extension.

        Args:
            config: Extension configuration.
            hierarchical_memory: Reference to hierarchical memory (optional).
            episodic_memory: Reference to episodic memory (optional).
            procedural_memory: Reference to procedural memory (optional).
            notes_storage: Reference to notes storage (optional).
        """
        super().__init__()
        self.config = config or MemoryExtensionConfig()
        self._hierarchical_memory = hierarchical_memory
        self._episodic_memory = episodic_memory
        self._procedural_memory = procedural_memory
        self._notes_storage = notes_storage

    def set_hierarchical_memory(self, memory: HierarchicalMemory) -> None:
        """Set hierarchical memory reference."""
        self._hierarchical_memory = memory

    def set_episodic_memory(self, memory: EpisodicMemory) -> None:
        """Set episodic memory reference."""
        self._episodic_memory = memory

    def set_procedural_memory(self, memory: ProceduralMemory) -> None:
        """Set procedural memory reference."""
        self._procedural_memory = memory

    def set_notes_storage(self, storage: NotesStorage) -> None:
        """Set notes storage reference."""
        self._notes_storage = storage

    @property
    def name(self) -> str:
        return "memory"

    @property
    def xml_tags(self) -> list[str]:
        return [
            "memory_store", "memory_get", "memory_list",
            "memory_search_episodes", "procedure_search", "procedure_list",
            "notes_search", "record_decision"
        ]

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        tools = [
            {
                "name": "memory_store",
                "description": (
                    "Store a note in memory for later retrieval. "
                    "Use 'working' scope for current session notes. "
                    "Use 'hierarchical' scope for persistent cross-session notes. "
                    "Good for: key decisions, important findings, intermediate results."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "key": {
                            "type": "string",
                            "description": "Unique key for the note (e.g., 'auth_decision', 'found_bug')",
                        },
                        "value": {
                            "type": "string",
                            "description": "The note content to store",
                        },
                        "scope": {
                            "type": "string",
                            "enum": ["working", "hierarchical"],
                            "description": "Memory scope: 'working' (session) or 'hierarchical' (persistent)",
                        },
                    },
                    "required": ["key", "value"],
                },
            },
            {
                "name": "memory_get",
                "description": (
                    "Retrieve a previously stored note from memory. "
                    "Returns the value if found, or an error if not found."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "key": {
                            "type": "string",
                            "description": "Key of the note to retrieve",
                        },
                        "scope": {
                            "type": "string",
                            "enum": ["working", "hierarchical"],
                            "description": "Memory scope to search in",
                        },
                    },
                    "required": ["key"],
                },
            },
            {
                "name": "memory_list",
                "description": (
                    "List all stored note keys in the specified scope. "
                    "Useful for seeing what context is available."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "scope": {
                            "type": "string",
                            "enum": ["working", "hierarchical", "all"],
                            "description": "Which scope to list keys from",
                        },
                    },
                },
            },
        ]

        if self.config.enable_episodic_search:
            tools.append({
                "name": "memory_search_episodes",
                "description": (
                    "Search past task episodes for relevant context. "
                    "Returns summaries of similar past tasks that might inform the current task. "
                    "Use when starting a task similar to something done before."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Description of what you're looking for",
                        },
                        "max_results": {
                            "type": "integer",
                            "description": "Maximum number of episodes to return (default: 3)",
                        },
                    },
                    "required": ["query"],
                },
            })

        if self.config.enable_procedural_search:
            tools.append({
                "name": "procedure_search",
                "description": (
                    "Search for learned procedures (workflows) relevant to a task. "
                    "Procedures are reusable step-by-step patterns extracted from past successes. "
                    "Use when you need guidance on how to approach a familiar type of task."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "Description of the task you need a procedure for",
                        },
                        "tech_stack": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Technologies involved (e.g., ['python', 'django'])",
                        },
                    },
                    "required": ["task"],
                },
            })
            tools.append({
                "name": "procedure_list",
                "description": (
                    "List all available procedures with their descriptions. "
                    "Use to see what learned workflows are available."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "tech_filter": {
                            "type": "string",
                            "description": "Optional: filter by technology (e.g., 'python')",
                        },
                    },
                },
            })

        if self.config.enable_notes_search:
            tools.append({
                "name": "notes_search",
                "description": (
                    "Search the knowledge base of detailed notes created by NoteTaker. "
                    "Notes contain solutions, patterns, hindsight lessons, and architecture insights. "
                    "Use when you need detailed guidance or solutions from past work."
                ),
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Text to search in note titles and content",
                        },
                        "keywords": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Keywords to match (e.g., ['auth', 'jwt', 'security'])",
                        },
                        "category": {
                            "type": "string",
                            "enum": ["projects", "shared", "hindsight"],
                            "description": "Optional: filter by category",
                        },
                    },
                },
            })

        # Record decision tool - always available
        tools.append({
            "name": "record_decision",
            "description": (
                "Record a key design or implementation decision for this task. "
                "Use this when making important architectural choices, trade-offs, "
                "or decisions that should be remembered for future reference. "
                "These decisions will be stored in the episode memory."
            ),
            "input_schema": {
                "type": "object",
                "properties": {
                    "decision": {
                        "type": "string",
                        "description": "Brief description of the decision made",
                    },
                    "rationale": {
                        "type": "string",
                        "description": "Why this decision was made (optional)",
                    },
                },
                "required": ["decision"],
            },
        })

        return tools

    def can_handle(self, action: Action) -> bool:
        """Check if we can handle this action."""
        return action.name in [
            "memory_store",
            "memory_get",
            "memory_list",
            "memory_search_episodes",
            "procedure_search",
            "procedure_list",
            "notes_search",
            "record_decision",
        ]

    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """
        Execute a memory action.

        Args:
            action: Action to execute.
            context: Extension context.

        Returns:
            ExecutionResult.
        """
        if action.name == "memory_store":
            return self._handle_store(action, context)
        elif action.name == "memory_get":
            return self._handle_get(action, context)
        elif action.name == "memory_list":
            return self._handle_list(action, context)
        elif action.name == "memory_search_episodes":
            return self._handle_search_episodes(action, context)
        elif action.name == "procedure_search":
            return self._handle_procedure_search(action, context)
        elif action.name == "procedure_list":
            return self._handle_procedure_list(action, context)
        elif action.name == "notes_search":
            return self._handle_notes_search(action, context)
        elif action.name == "record_decision":
            return self._handle_record_decision(action, context)
        else:
            return ExecutionResult.error_result(f"Unknown memory action: {action.name}")

    def _handle_store(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle memory_store action."""
        key = action.input.get("key", "")
        value = action.input.get("value", "")
        scope = action.input.get("scope", "working")

        if not key:
            return ExecutionResult.error_result("No key provided")
        if not value:
            return ExecutionResult.error_result("No value provided")

        # Check reserved prefix
        if key.startswith(self.config.reserved_prefix):
            return ExecutionResult.error_result(
                f"Keys starting with '{self.config.reserved_prefix}' are reserved"
            )

        # Truncate value if too large
        if len(value) > self.config.max_value_size:
            value = value[: self.config.max_value_size]
            truncated = True
        else:
            truncated = False

        if scope == "working":
            context.memory.store_artifact(f"note:{key}", value)
            location = "working memory"
        elif scope == "hierarchical":
            if self._hierarchical_memory is None:
                return ExecutionResult.error_result(
                    "Hierarchical memory not available"
                )
            self._hierarchical_memory.store(f"note:{key}", value)
            location = "hierarchical memory"
        else:
            return ExecutionResult.error_result(f"Unknown scope: {scope}")

        msg = f"Stored note '{key}' in {location}"
        if truncated:
            msg += f" (truncated to {self.config.max_value_size} chars)"

        return ExecutionResult.success_result(
            output=msg,
            user_output=f"[Memory] {msg}",
        )

    def _handle_get(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle memory_get action."""
        key = action.input.get("key", "")
        scope = action.input.get("scope", "working")

        if not key:
            return ExecutionResult.error_result("No key provided")

        prefixed_key = f"note:{key}"

        if scope == "working":
            value = context.memory.get_artifact(prefixed_key)
        elif scope == "hierarchical":
            if self._hierarchical_memory is None:
                return ExecutionResult.error_result(
                    "Hierarchical memory not available"
                )
            value = self._hierarchical_memory.retrieve(prefixed_key)
        else:
            return ExecutionResult.error_result(f"Unknown scope: {scope}")

        if value is None:
            return ExecutionResult.error_result(f"Note '{key}' not found in {scope} memory")

        return ExecutionResult.success_result(
            output=f"[{key}]: {value}",
            user_output=f"[Memory] Retrieved note '{key}'",
        )

    def _handle_list(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle memory_list action."""
        scope = action.input.get("scope", "all")

        keys: dict[str, list[str]] = {"working": [], "hierarchical": []}

        # Get working memory keys
        if scope in ("working", "all"):
            artifacts = context.memory._artifacts if hasattr(context.memory, "_artifacts") else {}
            working_keys = [
                k.replace("note:", "") for k in artifacts.keys()
                if k.startswith("note:")
            ]
            keys["working"] = working_keys

        # Get hierarchical memory keys
        if scope in ("hierarchical", "all") and self._hierarchical_memory:
            # Get current context node content
            path = self._hierarchical_memory.get_context()
            node = self._hierarchical_memory._get_node_at_path(path)
            hier_keys = [
                k.replace("note:", "") for k in node.content.keys()
                if k.startswith("note:")
            ]
            keys["hierarchical"] = hier_keys

        # Format output
        lines = ["Stored notes:"]
        if keys["working"]:
            lines.append(f"  Working memory: {', '.join(keys['working'])}")
        else:
            lines.append("  Working memory: (none)")

        if scope in ("hierarchical", "all"):
            if keys["hierarchical"]:
                lines.append(f"  Hierarchical memory: {', '.join(keys['hierarchical'])}")
            else:
                lines.append("  Hierarchical memory: (none)")

        output = "\n".join(lines)
        return ExecutionResult.success_result(
            output=output,
            user_output=f"[Memory] Listed {len(keys['working']) + len(keys['hierarchical'])} notes",
        )

    def _handle_search_episodes(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """Handle memory_search_episodes action."""
        query = action.input.get("query", "")
        max_results = action.input.get("max_results", 3)

        if not query:
            return ExecutionResult.error_result("No query provided")

        if self._episodic_memory is None:
            return ExecutionResult.error_result("Episodic memory not available")

        # Search for similar episodes
        episodes = self._episodic_memory.retrieve_similar(
            task=query,
            max_results=max_results,
        )

        if not episodes:
            return ExecutionResult.success_result(
                output="No relevant past tasks found",
                user_output="[Memory] No matching episodes found",
            )

        # Format episodes for output
        output = self._episodic_memory.format_for_context(episodes)

        return ExecutionResult.success_result(
            output=output,
            user_output=f"[Memory] Found {len(episodes)} relevant past tasks",
        )

    def _handle_procedure_search(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """Handle procedure_search action."""
        task = action.input.get("task", "")
        tech_stack = action.input.get("tech_stack", [])

        if not task:
            return ExecutionResult.error_result("No task description provided")

        if self._procedural_memory is None:
            return ExecutionResult.error_result("Procedural memory not available")

        # Search for relevant procedures
        procedures = self._procedural_memory.retrieve_for_task(
            task=task,
            tech_hints=tech_stack,
        )

        if not procedures:
            return ExecutionResult.success_result(
                output="No relevant procedures found for this task type",
                user_output="[Procedures] No matching procedures found",
            )

        # Format procedures for output
        output = self._procedural_memory.format_for_context(procedures)

        return ExecutionResult.success_result(
            output=output,
            user_output=f"[Procedures] Found {len(procedures)} relevant procedures",
        )

    def _handle_procedure_list(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """Handle procedure_list action."""
        tech_filter = action.input.get("tech_filter", "")

        if self._procedural_memory is None:
            return ExecutionResult.error_result("Procedural memory not available")

        procedures = self._procedural_memory.get_all_procedures()

        if not procedures:
            return ExecutionResult.success_result(
                output="No procedures available yet. Procedures are learned from successful task completions.",
                user_output="[Procedures] No procedures available",
            )

        # Filter by tech if specified
        if tech_filter:
            tech_lower = tech_filter.lower()
            procedures = [
                p for p in procedures
                if any(tech_lower in t.lower() for t in p.tech_stack)
            ]

        if not procedures:
            return ExecutionResult.success_result(
                output=f"No procedures found for technology: {tech_filter}",
                user_output=f"[Procedures] No procedures for {tech_filter}",
            )

        # Format list
        lines = ["Available Procedures:", ""]
        for proc in procedures:
            tech_str = ", ".join(proc.tech_stack[:3]) if proc.tech_stack else "general"
            lines.append(f"**{proc.name}** [{tech_str}]")
            lines.append(f"  {proc.description}")
            lines.append(f"  Usage: {proc.usage_count}x | Success rate: {proc.success_rate:.0%}")
            lines.append("")

        output = "\n".join(lines)

        return ExecutionResult.success_result(
            output=output,
            user_output=f"[Procedures] Listed {len(procedures)} procedures",
        )

    def _handle_record_decision(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """Handle record_decision action - records key decisions for episode memory."""
        decision = action.input.get("decision", "")
        rationale = action.input.get("rationale", "")

        if not decision:
            return ExecutionResult.error_result("No decision provided")

        # Format the decision
        if rationale:
            full_decision = f"{decision} (Rationale: {rationale})"
        else:
            full_decision = decision

        # Return with artifacts - orchestrator will accumulate these
        return ExecutionResult.success_result(
            output=f"Recorded decision: {decision}",
            user_output=f"[Decision] {decision}",
            artifacts={"key_decisions": [full_decision]},
        )

    def _handle_notes_search(
        self, action: Action, context: ExtensionContext
    ) -> ExecutionResult:
        """Handle notes_search action."""
        query = action.input.get("query")
        keywords = action.input.get("keywords", [])
        category = action.input.get("category")

        if self._notes_storage is None:
            return ExecutionResult.error_result("Notes storage not available")

        # Search notes
        notes = self._notes_storage.search_notes(
            query=query,
            keywords=keywords if keywords else None,
            category=category,
        )

        if not notes:
            return ExecutionResult.success_result(
                output="No matching notes found in knowledge base",
                user_output="[Notes] No matching notes found",
            )

        # Format notes for output
        lines = ["[Knowledge Base Notes]", ""]
        for note in notes[:5]:  # Limit to 5 notes
            lines.append(f"### {note.metadata.title}")
            lines.append(f"*Path: {note.path} | Category: {note.metadata.category}*")
            lines.append(f"*Keywords: {', '.join(note.metadata.keywords[:5])}*")
            lines.append("")
            
            # Include content preview
            content_preview = note.content[:500]
            if len(note.content) > 500:
                content_preview += "..."
            lines.append(content_preview)
            lines.append("")
            lines.append("---")
            lines.append("")

        output = "\n".join(lines)

        return ExecutionResult.success_result(
            output=output,
            user_output=f"[Notes] Found {len(notes)} matching notes",
        )

    def signals_continuation(self) -> bool:
        """Memory operations want continuation."""
        return True
