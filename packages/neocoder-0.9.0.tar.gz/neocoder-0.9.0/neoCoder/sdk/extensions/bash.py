"""
Bash extension for executing shell commands.

Provides safe command execution with:
- Timeout handling
- Output capture
- Error handling
- Optional command validation/sandboxing
- Cross-platform support (Windows CMD/PowerShell, Unix bash)
"""

from __future__ import annotations

import subprocess
import shlex
import os
import platform
from dataclasses import dataclass
from typing import Any, Literal

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.llm.output_parser import Action


ShellType = Literal["cmd", "powershell", "bash", "sh"]


@dataclass
class BashConfig:
    """Configuration for bash extension."""

    timeout: int = 120  # Default timeout in seconds
    max_output_length: int = 50000  # Max chars to return
    shell: bool = True  # Use shell mode
    blocked_commands: list[str] | None = None  # Commands to block
    working_dir: str | None = None  # Override working directory
    auto_detect_shell: bool = True  # Auto-detect shell based on OS
    prefer_powershell: bool = True  # Prefer PowerShell over CMD on Windows


class BashExtension(Extension):
    """
    Extension for executing bash/shell commands.

    Features:
    - Captures stdout and stderr
    - Timeout handling
    - Output truncation for long outputs
    - Optional command blocking for safety
    - Cross-platform support (Windows CMD/PowerShell, Unix bash)
    - Automatic shell detection
    """

    def __init__(self, config: BashConfig | None = None):
        """
        Initialize bash extension.

        Args:
            config: Bash configuration.
        """
        super().__init__()
        self.config = config or BashConfig()
        
        # Detect OS and shell
        self.is_windows = platform.system() == "Windows"
        self.shell_type = self._detect_shell()
        self.shell_name = self._get_shell_name()

        # Default blocked commands for safety (cross-platform)
        windows_blocked = [
            "format",
            "del /f /s /q c:\\*",
            "rd /s /q c:\\",
            "rmdir /s /q c:\\",
        ]
        unix_blocked = [
            "rm -rf /",
            "rm -rf /*",
            "mkfs",
            "dd if=/dev/zero",
            ":(){:|:&};:",  # Fork bomb
        ]
        
        default_blocked = windows_blocked if self.is_windows else unix_blocked
        self._blocked_commands = set(self.config.blocked_commands or default_blocked)

    def _detect_shell(self) -> ShellType:
        """
        Detect the current shell environment.
        
        Returns:
            Shell type (cmd, powershell, bash, sh).
        """
        if not self.is_windows:
            # Unix/Linux/Mac - check for bash
            shell_env = os.environ.get("SHELL", "")
            if "bash" in shell_env.lower():
                return "bash"
            elif "zsh" in shell_env.lower():
                return "bash"  # zsh is compatible with bash commands
            return "sh"
        
        # Windows - detect PowerShell or CMD
        # Method 1: Check COMSPEC - if running in CMD, this points to cmd.exe
        comspec = os.environ.get("COMSPEC", "").lower()
        
        # Method 2: Check for PowerShell-specific environment variables
        # PSModulePath is set when PowerShell initializes
        ps_module_path = os.environ.get("PSModulePath")
        
        # Method 3: Check the parent process name (most reliable)
        parent_shell = self._get_parent_shell()
        if parent_shell:
            return parent_shell
        
        # Method 4: Check if we're in a PowerShell environment
        # PowerShell sets PSVersionTable which we can detect via env vars
        if ps_module_path and "WindowsPowerShell" in ps_module_path:
            return "powershell"
        
        # Method 5: Check PROMPT variable - CMD sets this, PowerShell doesn't use it the same way
        prompt = os.environ.get("PROMPT")
        if prompt and "$P$G" in prompt:
            return "cmd"
        
        # Method 6: Check if ComSpec points to cmd.exe and no PS indicators
        if "cmd.exe" in comspec and not ps_module_path:
            return "cmd"
        
        # Default: prefer PowerShell on modern Windows if configured
        if self.config.prefer_powershell:
            return "powershell"
        
        return "cmd"
    
    def _get_parent_shell(self) -> ShellType | None:
        """
        Try to detect parent shell process.
        
        Returns:
            Shell type if detected, None otherwise.
        """
        try:
            import psutil
            current = psutil.Process()
            parent = current.parent()
            
            if parent:
                parent_name = parent.name().lower()
                if "powershell" in parent_name or "pwsh" in parent_name:
                    return "powershell"
                elif "cmd" in parent_name:
                    return "cmd"
                elif "bash" in parent_name:
                    return "bash"
                elif "sh" in parent_name:
                    return "sh"
                
                # Check grandparent (MCP server may be child of shell)
                grandparent = parent.parent()
                if grandparent:
                    gp_name = grandparent.name().lower()
                    if "powershell" in gp_name or "pwsh" in gp_name:
                        return "powershell"
                    elif "cmd" in gp_name:
                        return "cmd"
        except (ImportError, Exception):
            # psutil not available or error - fall through to other methods
            pass
        
        return None

    def _get_shell_name(self) -> str:
        """Get human-readable shell name."""
        names = {
            "cmd": "CMD",
            "powershell": "PowerShell",
            "bash": "bash",
            "sh": "sh"
        }
        return names.get(self.shell_type, self.shell_type)

    @property
    def name(self) -> str:
        return "bash"

    @property
    def xml_tags(self) -> list[str]:
        return ["bash", "shell", "command"]

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        shell_desc = self.shell_name
        examples = self._get_shell_examples()
        
        return [
            {
                "name": "bash",
                "description": f"Execute a {shell_desc} command in the shell. Use for running commands, scripts, or system operations.\n\nExamples:\n{examples}",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": f"The {shell_desc} command to execute",
                        },
                        "timeout": {
                            "type": "integer",
                            "description": "Optional timeout in seconds (default: 120)",
                        },
                        "working_dir": {
                            "type": "string",
                            "description": "Optional working directory for the command",
                        },
                    },
                    "required": ["command"],
                },
            }
        ]

    def _get_shell_examples(self) -> str:
        """Get shell-specific command examples."""
        if self.shell_type == "powershell":
            return """- List files: Get-ChildItem or ls
- View file: Get-Content file.txt or cat file.txt
- Run Python: python script.py
- Run tests: python -m pytest"""
        elif self.shell_type == "cmd":
            return """- List files: dir
- View file: type file.txt
- Run Python: python script.py
- Run tests: python -m pytest"""
        else:  # bash/sh
            return """- List files: ls -la
- View file: cat file.txt
- Run Python: python3 script.py
- Run tests: pytest"""

    def _is_command_blocked(self, command: str) -> bool:
        """Check if a command should be blocked."""
        import re
        command_lower = command.lower().strip()
        for blocked in self._blocked_commands:
            # Basic regex to catch common bypasses for dangerous commands
            if "rm -rf" in blocked:
                if re.search(r"rm\s+-[^\s]*[rf]+[^\s]*\s+/", command_lower):
                    return True
            elif blocked.lower() in command_lower:
                return True
        return False

    def _truncate_output(self, output: str) -> tuple[str, bool]:
        """
        Truncate output if too long, prioritizing the end.

        Returns:
            Tuple of (truncated_output, was_truncated).
        """
        if len(output) <= self.config.max_output_length:
            return output, False

        # Keep 20% from start, 80% from end (errors/stack traces usually at the end)
        start_chars = int(self.config.max_output_length * 0.2)
        end_chars = self.config.max_output_length - start_chars

        truncated = (
            output[:start_chars]
            + f"\n\n... [{len(output) - self.config.max_output_length} chars truncated] ...\n\n"
            + output[-end_chars:]
        )
        return truncated, True

    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """
        Execute a bash command.

        Args:
            action: Action containing the command.
            context: Extension context.

        Returns:
            ExecutionResult with command output.
        """
        # Extract command from action
        if action.type == "xml_tag":
            command = action.input.get("content", "")
        else:
            command = action.input.get("command", "")

        if not command:
            return ExecutionResult.error_result("No command provided")

        # Check for blocked commands
        if self._is_command_blocked(command):
            return ExecutionResult.error_result(
                f"Command blocked for safety: {command[:50]}..."
            )

        # Get timeout and working directory
        timeout = action.input.get("timeout", self.config.timeout)
        working_dir = (
            action.input.get("working_dir")
            or self.config.working_dir
            or context.working_dir
        )

        try:
            # Execute command based on shell type
            if self.shell_type == "powershell":
                # PowerShell execution
                result = subprocess.run(
                    ["powershell", "-NoProfile", "-Command", command],
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    cwd=working_dir,
                    env={**os.environ},
                )
            else:
                # CMD or bash execution
                result = subprocess.run(
                    command,
                    shell=self.config.shell,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                    cwd=working_dir,
                    env={**os.environ},
                )

            # Combine stdout and stderr
            output = ""
            if result.stdout:
                output += result.stdout
            if result.stderr:
                if output:
                    output += "\n"
                output += result.stderr

            # Truncate if needed
            output, was_truncated = self._truncate_output(output)

            # Build user output (rich) - include command
            user_output = f"$ {command}\n{output}"
            if was_truncated:
                user_output = f"$ {command}\n[Output truncated]\n{output}"

            if result.returncode != 0:
                user_output = f"$ {command}\n[Exit code: {result.returncode}]\n{output}"

            # Build agent output (compressed)
            agent_output = output
            if result.returncode != 0:
                agent_output = f"Exit code: {result.returncode}\n{agent_output}"

            # Return result with user_output (orchestrator will handle display)
            return ExecutionResult(
                success=result.returncode == 0,
                output=agent_output,
                user_output=user_output,
                error=None if result.returncode == 0 else f"Exit code: {result.returncode}",
                should_continue=True,
            )

        except subprocess.TimeoutExpired:
            error_msg = f"Command timed out after {timeout} seconds"
            return ExecutionResult.error_result(
                error_msg,
                user_output=f"$ {command}\n[Error] {error_msg}"
            )

        except Exception as e:
            error_msg = f"Command execution failed: {str(e)}"
            return ExecutionResult.error_result(
                error_msg,
                user_output=f"$ {command}\n[Error] {error_msg}"
            )

    def signals_continuation(self) -> bool:
        """Bash commands typically want continuation."""
        return True


class InteractiveBashExtension(BashExtension):
    """
    Extended bash extension with interactive session support.

    Maintains a persistent shell session for commands that need state.
    """

    def __init__(self, config: BashConfig | None = None):
        super().__init__(config)
        self._process: subprocess.Popen | None = None
        self._cwd = os.getcwd()

    def _start_session(self, working_dir: str) -> None:
        """Start an interactive shell session."""
        if self._process is None or self._process.poll() is not None:
            self._process = subprocess.Popen(
                ["/bin/bash"],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=working_dir,
            )
            self._cwd = working_dir

    def close_session(self) -> None:
        """Close the interactive session."""
        if self._process:
            self._process.terminate()
            self._process = None
