"""
ProjectContextExtension — simplified project-aware extension.

Simply discovers key project files and provides them to the agent.
LLM handles all the analysis — no hardcoded conventions or commands.
"""

from __future__ import annotations

import logging
from typing import Any

from neoCoder.sdk.extensions.base import (
    Extension,
    ExtensionContext,
    ExecutionResult,
)
from neoCoder.sdk.extensions.project_context.discovery import (
    ProjectDiscovery,
    ProjectProfile,
)

logger = logging.getLogger(__name__)


class ProjectContextExtension(Extension):
    """
    Simplified project context extension.
    
    - Discovers key project files (package.json, pom.xml, etc.)
    - Provides file list to tech stack analyzer
    - LLM handles all analysis and best practices
    """

    def __init__(self) -> None:
        super().__init__()
        self._discovery = ProjectDiscovery()
        self._profile: ProjectProfile | None = None
        self._working_dir: str | None = None

    @property
    def name(self) -> str:
        return "project_context"

    @property
    def xml_tags(self) -> list[str]:
        return []

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        return []

    def can_handle(self, action: Any) -> bool:
        return False

    def execute(self, action: Any, context: ExtensionContext) -> ExecutionResult:
        return ExecutionResult.error_result("project_context does not execute actions")

    def _ensure_discovery(self) -> ProjectProfile:
        """Run discovery if not done yet."""
        if self._profile is not None:
            return self._profile

        if self._working_dir is None:
            self._profile = ProjectProfile()
            return self._profile

        self._profile = self._discovery.scan(self._working_dir)
        if self._profile.detected_any:
            logger.info("Project profile: %s", self._profile.describe())

        return self._profile

    def get_discovered_files(self) -> list[str]:
        """Get list of discovered file names for tech stack analyzer."""
        profile = self._ensure_discovery()
        return profile.tool_names()

    def reset(self) -> None:
        """Reset state for new session."""
        self._profile = None
