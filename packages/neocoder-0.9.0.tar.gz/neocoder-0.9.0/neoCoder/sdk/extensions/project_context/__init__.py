"""
Project Context Extension for neoCoder Agent.

Simple file scanner that discovers key project files (package.json, pom.xml, etc.)
and provides them to the tech stack analyzer. LLM handles all analysis.
"""

from neoCoder.sdk.extensions.project_context.extension import ProjectContextExtension
from neoCoder.sdk.extensions.project_context.discovery import (
    ProjectDiscovery,
    ProjectProfile,
    DiscoveredFile,
)

__all__ = [
    "ProjectContextExtension",
    "ProjectDiscovery",
    "ProjectProfile",
    "DiscoveredFile",
]
