"""Extension system for modular tool use."""

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.extensions.bash import BashExtension, BashConfig
from neoCoder.sdk.extensions.file_edit import FileEditExtension, FileEditConfig
from neoCoder.sdk.extensions.file_search import FileSearchExtension, FileSearchConfig
from neoCoder.sdk.extensions.thinking import ThinkingExtension, ThinkingConfig
from neoCoder.sdk.extensions.session_context import SessionContext
from neoCoder.sdk.extensions.code_review import CodeReviewExtension, CodeReviewConfig

__all__ = [
    "Extension",
    "ExtensionContext",
    "ExecutionResult",
    "BashExtension",
    "BashConfig",
    "FileEditExtension",
    "FileEditConfig",
    "FileSearchExtension",
    "FileSearchConfig",
    "ThinkingExtension",
    "ThinkingConfig",
    "SessionContext",
    "CodeReviewExtension",
    "CodeReviewConfig",
]
