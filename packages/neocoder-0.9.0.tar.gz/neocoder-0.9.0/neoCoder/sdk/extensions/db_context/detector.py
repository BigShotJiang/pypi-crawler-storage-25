"""
Database context detector.

Lightweight keyword-based detection of DB-related tasks.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from neoCoder.sdk.extensions.db_context.config import DatabaseContextConfig


@dataclass
class DbContextSnapshot:
    """Result of DB context detection."""
    active: bool = False
    reason: str = ""


class DatabaseContextDetector:
    """Stateless detector — checks if task involves database work."""

    def __init__(self, config: DatabaseContextConfig):
        self._cfg = config

    def task_is_db_related(self, task_text: str) -> bool:
        """
        Check if task description mentions DB/migration concepts.

        Uses two-tier keyword system:
          - Strong keywords: one match is enough ("migration", "flyway", ...)
          - Weak keywords: need >= threshold matches ("table", "column", ...)
        """
        lower = task_text.lower()

        # Any strong keyword is sufficient
        if any(kw in lower for kw in self._cfg.task_keywords_strong):
            return True

        # Count weak keyword matches
        weak_hits = sum(1 for kw in self._cfg.task_keywords_weak if kw in lower)
        return weak_hits >= self._cfg.weak_keyword_threshold
