"""
DatabaseContextExtension — lightweight DB-aware extension.

Detects when task involves database work and injects a protocol/checklist
into the conversation. All validation is done by the LLM using the checklist,
not by hardcoded regex parsing.

Lifecycle:
  on_input_messages — detects DB context, injects protocol once
"""

from __future__ import annotations

import logging
from typing import Any

from neoCoder.sdk.extensions.base import (
    Extension,
    ExtensionContext,
    ExecutionResult,
)
from neoCoder.sdk.extensions.db_context.config import DatabaseContextConfig
from neoCoder.sdk.extensions.db_context.detector import (
    DatabaseContextDetector,
    DbContextSnapshot,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Protocol injected when DB context is detected
# ---------------------------------------------------------------------------
_DB_PROTOCOL = """
## 🗄️ Database Migration Protocol

You are working with database migrations. Follow this protocol strictly.

### ⚠️ MANDATORY RULES (apply BEFORE writing any migration)

**1. DEPENDENCY GRAPH**: You MUST determine table creation order:
- Build a dependency graph from entity relationships (FK → referenced table)
- Tables with no FK dependencies come FIRST
- Tables depending on others come AFTER their dependencies
- Circular dependencies require special handling (create tables first, add FK later)
- **NEVER create a table with FK before the referenced table exists**

**2. ENUM ORDINAL COLUMNS — PROJECT STANDARD**:

When entity has enum field without `@Enumerated(STRING)`:
```sql
<enum_field_name> TINYINT NOT NULL
```

❌ **NEVER use SMALLINT for enums** — even if Hibernate/JPA generates it.
Override ORM default: enum ordinal → TINYINT (0-255 is always sufficient).

### PHASE 1: Gather Ground Truth (BEFORE writing migration)

1. **Read DB config** — find application.properties / .yml / persistence.xml /
   .env to determine DBMS, dialect, and ORM version.

2. **Read ALL related entities** — for every table your change touches, read
   the full entity source. Note every @Column, @Enumerated, field type.
   
   - **Detect ORM and version**: check build files (pom.xml, build.gradle, requirements.txt)
     for ORM library and version — this affects type mappings.

3. **Read existing migrations** — scan the migration directory, read relevant
   migrations to see what types are already used.

4. **Generate ORM DDL** (most reliable starting point):
   - Hibernate: `mvn compile` with `ddl-auto=create` or schema export
   - Django: `python manage.py sqlmigrate`
   - Alembic: `alembic upgrade --sql`
   
   Use generated column types as baseline, **then apply project conventions
   that override ORM defaults** (see Enum Handling below).

### PHASE 2: Pre-Write Checklist

Before writing ANY migration, verify:

#### Foreign Keys
- [ ] Referenced table EXISTS (check all migrations)
- [ ] FK column type MATCHES referenced PK type EXACTLY
- [ ] No circular FK dependencies (A→B→C→A)
- [ ] Self-referencing FK has ON DELETE clause

#### DROP TABLE
- [ ] No other tables have FK pointing to this table
- [ ] Or drop FK constraints FIRST

#### ALTER TABLE ADD COLUMN
- [ ] NOT NULL column has DEFAULT, or table is empty
- [ ] Or use two-step: add nullable → backfill → set NOT NULL

#### Type Consistency
- [ ] Column types match entity field types EXACTLY
- [ ] Use same types as existing migrations for same concepts
- [ ] TINYINT ≠ SMALLINT ≠ INT ≠ BIGINT (never interchangeable!)

#### Ordinal Enums
- [ ] **TINYINT** for all enum ordinals (project standard — never SMALLINT)
- [ ] Keep entity and migration in sync

### PHASE 3: Post-Write Verification

After writing migration, suggest running:
- Hibernate: `mvn compile` with `ddl-auto=validate`
- Django: `python manage.py migrate --check`
- Rails: `rails db:migrate:status`
- Alembic: `alembic check`

⚠️ DO NOT GUESS column types. Check existing migrations first.
**Exception**: Enum ordinals ALWAYS use TINYINT (project standard).
""".strip()


class DatabaseContextExtension(Extension):
    """
    Lightweight extension that detects DB work and injects protocol.
    
    No validation logic — LLM uses the checklist to self-validate.
    """

    def __init__(self, config: DatabaseContextConfig | None = None):
        super().__init__()
        self.config = config or DatabaseContextConfig()
        self._detector = DatabaseContextDetector(self.config)
        self._snapshot = DbContextSnapshot()
        self._protocol_injected = False
        self._decided = False

    @property
    def name(self) -> str:
        return "db_context"

    @property
    def xml_tags(self) -> list[str]:
        return []

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        return []

    def can_handle(self, action: Any) -> bool:
        return False

    def execute(self, action: Any, context: ExtensionContext) -> ExecutionResult:
        return ExecutionResult.error_result("db_context does not execute actions")

    def on_input_messages(
        self, messages: list[dict[str, Any]], context: ExtensionContext
    ) -> list[dict[str, Any]]:
        """
        Check user prompt for DB keywords (once), inject protocol if detected.
        """
        if not self.config.enabled:
            return messages

        # Decision gate — runs once per session
        if not self._decided:
            self._decided = True
            user_prompt = self._extract_user_prompt(messages)
            if user_prompt and self._detector.task_is_db_related(user_prompt):
                self._snapshot.active = True
                self._snapshot.reason = "DB keywords detected in task"
                logger.info("Database context activated: %s", self._snapshot.reason)

        # Nothing to do if not DB-related
        if not self._snapshot.active:
            return messages

        # Inject protocol once
        if not self._protocol_injected:
            messages = self._inject_protocol(messages)
            self._protocol_injected = True

        return messages

    @staticmethod
    def _extract_user_prompt(messages: list[dict[str, Any]]) -> str | None:
        """Return text of the first user message."""
        for msg in messages:
            if msg.get("role") == "user":
                content = msg.get("content", "")
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    parts = []
                    for block in content:
                        if isinstance(block, str):
                            parts.append(block)
                        elif isinstance(block, dict) and block.get("type") == "text":
                            parts.append(block.get("text", ""))
                    return "\n".join(parts)
        return None

    def _inject_protocol(
        self, messages: list[dict[str, Any]]
    ) -> list[dict[str, Any]]:
        """Inject DB protocol as a system-style user message."""
        protocol_msg = {
            "role": "user",
            "content": f"[SYSTEM — Database Context]\n\n{_DB_PROTOCOL}",
        }
        messages = list(messages)
        # Insert before the last user message
        insert_idx = len(messages)
        for i in range(len(messages) - 1, -1, -1):
            if messages[i].get("role") == "user":
                insert_idx = i
                break
        messages.insert(insert_idx, protocol_msg)
        return messages

    @property
    def is_active(self) -> bool:
        """Check if DB context is currently active."""
        return self._snapshot.active

    def reset(self) -> None:
        """Reset state between tasks."""
        self._protocol_injected = False
        self._snapshot = DbContextSnapshot()
        self._decided = False
