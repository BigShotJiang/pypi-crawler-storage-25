"""
Streaming diff renderer for real-time code change visualization.

Provides live diff display as code is being generated/modified,
with Rich-based terminal rendering and line-by-line updates.
"""

from __future__ import annotations

import difflib
import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from io import StringIO
from pathlib import Path
from typing import Callable, Iterator

from rich.console import Console
from rich.live import Live
from rich.panel import Panel
from rich.text import Text


class DiffLineType(Enum):
    """Type of diff line for styling."""
    CONTEXT = "context"
    ADDITION = "addition"
    DELETION = "deletion"
    HEADER = "header"
    HUNK = "hunk"


@dataclass
class DiffLine:
    """Single line in a diff with metadata."""
    content: str
    line_type: DiffLineType
    old_line_no: int | None = None
    new_line_no: int | None = None


@dataclass
class StreamingDiffState:
    """State for streaming diff rendering."""
    file_path: str
    old_content: str
    new_lines: list[str] = field(default_factory=list)
    diff_lines: list[DiffLine] = field(default_factory=list)
    is_complete: bool = False
    start_time: float = field(default_factory=time.time)
    lines_added: int = 0
    lines_removed: int = 0


class StreamingDiffRenderer:
    """
    Renders diffs in real-time as content streams in.
    
    Features:
    - Live terminal updates
    - Plain text diff output
    - Statistics (lines added/removed)
    - Support for partial content updates
    """
    
    def __init__(
        self,
        on_output: Callable[[str], None] | None = None,
        on_stream: Callable[[str], None] | None = None,
        max_context_lines: int = 3,
        console: Console | None = None,
    ):
        """
        Initialize streaming diff renderer.
        
        Args:
            on_output: Callback for final output
            on_stream: Callback for streaming chunks
            max_context_lines: Max context lines around changes
            console: Rich Console instance
        """
        self.on_output = on_output
        self.on_stream = on_stream
        self.max_context_lines = max_context_lines
        self.console = console or Console(force_terminal=True)
        
        self._state: StreamingDiffState | None = None
        self._lock = threading.Lock()
        self._live: Live | None = None
    
    def start_diff(self, file_path: str, old_content: str) -> None:
        """
        Start a new streaming diff session.
        
        Args:
            file_path: Path to the file being modified
            old_content: Original file content
        """
        with self._lock:
            self._state = StreamingDiffState(
                file_path=file_path,
                old_content=old_content,
            )
            
            # Emit header
            if self.on_stream:
                header = self._format_header_ansi(file_path)
                self.on_stream(header)
    
    def add_content_chunk(self, chunk: str) -> None:
        """
        Add a chunk of new content and update diff display.
        
        Args:
            chunk: Partial new content chunk
        """
        if not self._state:
            return
        
        with self._lock:
            # Append chunk to accumulated new content
            current_text = "".join(self._state.new_lines)
            current_text += chunk
            self._state.new_lines = current_text.splitlines(keepends=True)
            
            # Compute incremental diff
            new_diff_lines = self._compute_diff(
                self._state.old_content,
                current_text,
            )
            
            # Find new lines to emit
            prev_count = len(self._state.diff_lines)
            new_lines_to_emit = new_diff_lines[prev_count:]
            
            self._state.diff_lines = new_diff_lines
            
            # Stream new diff lines
            if self.on_stream and new_lines_to_emit:
                for diff_line in new_lines_to_emit:
                    formatted = self._format_diff_line_ansi(diff_line)
                    self.on_stream(formatted)
    
    def complete_diff(self, final_content: str) -> str:
        """
        Complete the diff with final content and return formatted result.
        
        Args:
            final_content: Complete new file content
            
        Returns:
            Final formatted diff string
        """
        if not self._state:
            return ""
        
        with self._lock:
            self._state.is_complete = True
            self._state.new_lines = final_content.splitlines(keepends=True)
            
            # Compute final diff
            final_diff = self._compute_diff(
                self._state.old_content,
                final_content,
            )
            
            # Count statistics
            for line in final_diff:
                if line.line_type == DiffLineType.ADDITION:
                    self._state.lines_added += 1
                elif line.line_type == DiffLineType.DELETION:
                    self._state.lines_removed += 1
            
            # Generate final formatted output
            result = self._format_complete_diff()
            
            # Emit to callback
            if self.on_output:
                self.on_output(result)
            
            return result
    
    def _compute_diff(self, old_content: str, new_content: str) -> list[DiffLine]:
        """Compute diff between old and new content."""
        old_lines = old_content.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)
        
        diff_lines: list[DiffLine] = []
        
        # Use unified diff
        diff_gen = difflib.unified_diff(
            old_lines,
            new_lines,
            fromfile="a/" + (self._state.file_path if self._state else "file"),
            tofile="b/" + (self._state.file_path if self._state else "file"),
            lineterm="",
        )
        
        old_line_no = 0
        new_line_no = 0
        
        for line in diff_gen:
            if line.startswith("---") or line.startswith("+++"):
                diff_lines.append(DiffLine(
                    content=line.rstrip("\n"),
                    line_type=DiffLineType.HEADER,
                ))
            elif line.startswith("@@"):
                diff_lines.append(DiffLine(
                    content=line.rstrip("\n"),
                    line_type=DiffLineType.HUNK,
                ))
                # Parse line numbers from hunk header
                # Format: @@ -old_start,old_count +new_start,new_count @@
                try:
                    parts = line.split(" ")
                    old_part = parts[1]  # -old_start,old_count
                    new_part = parts[2]  # +new_start,new_count
                    old_line_no = int(old_part.split(",")[0][1:]) - 1
                    new_line_no = int(new_part.split(",")[0][1:]) - 1
                except (IndexError, ValueError):
                    pass
            elif line.startswith("+"):
                new_line_no += 1
                diff_lines.append(DiffLine(
                    content=line[1:].rstrip("\n"),
                    line_type=DiffLineType.ADDITION,
                    new_line_no=new_line_no,
                ))
            elif line.startswith("-"):
                old_line_no += 1
                diff_lines.append(DiffLine(
                    content=line[1:].rstrip("\n"),
                    line_type=DiffLineType.DELETION,
                    old_line_no=old_line_no,
                ))
            elif line.startswith(" "):
                old_line_no += 1
                new_line_no += 1
                diff_lines.append(DiffLine(
                    content=line[1:].rstrip("\n"),
                    line_type=DiffLineType.CONTEXT,
                    old_line_no=old_line_no,
                    new_line_no=new_line_no,
                ))
        
        return diff_lines
    
    def _format_header_ansi(self, file_path: str) -> str:
        """Format diff header as plain text."""
        name = Path(file_path).name
        return f"📝 {name}\n"
    
    def _format_diff_line_ansi(self, diff_line: DiffLine) -> str:
        """Format a single diff line with Rich markup."""
        if diff_line.line_type == DiffLineType.HEADER:
            return ""
        elif diff_line.line_type == DiffLineType.HUNK:
            return ""
        elif diff_line.line_type == DiffLineType.ADDITION:
            return f"[green]+{diff_line.content}[/green]\n"
        elif diff_line.line_type == DiffLineType.DELETION:
            return f"[red]-{diff_line.content}[/red]\n"
        else:
            return f" {diff_line.content}\n"
    
    def _format_complete_diff(self) -> str:
        """Format the complete diff with Rich markup."""
        if not self._state:
            return ""
        
        lines = []
        
        # Header
        name = Path(self._state.file_path).name
        lines.append(f"📝 {name}")
        
        for diff_line in self._state.diff_lines:
            if diff_line.line_type in (DiffLineType.HEADER, DiffLineType.HUNK):
                continue
            elif diff_line.line_type == DiffLineType.ADDITION:
                lines.append(f"[green]+{diff_line.content}[/green]")
            elif diff_line.line_type == DiffLineType.DELETION:
                lines.append(f"[red]-{diff_line.content}[/red]")
            else:
                lines.append(f" {diff_line.content}")
        
        # Statistics footer
        lines.append(f"[green]+{self._state.lines_added}[/green] [red]-{self._state.lines_removed}[/red]")
        
        return "\n".join(lines)


class IncrementalDiffBuilder:
    """
    Builds diff incrementally as new content is added.
    
    Useful for streaming scenarios where content arrives chunk by chunk.
    """
    
    def __init__(self, old_content: str, file_path: str = "file"):
        """
        Initialize incremental diff builder.
        
        Args:
            old_content: Original file content
            file_path: Path for diff header
        """
        self.old_lines = old_content.splitlines(keepends=True)
        self.file_path = file_path
        self.new_content = ""
        self._last_diff_index = 0
    
    def add_chunk(self, chunk: str) -> Iterator[str]:
        """
        Add content chunk and yield new diff lines.
        
        Args:
            chunk: New content chunk
            
        Yields:
            New diff lines as ANSI-formatted strings
        """
        self.new_content += chunk
        new_lines = self.new_content.splitlines(keepends=True)
        
        # Simple approach: find changed region
        # More sophisticated algorithms could be used for better incremental updates
        
        matcher = difflib.SequenceMatcher(None, self.old_lines, new_lines)
        
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == "replace":
                for line in self.old_lines[i1:i2]:
                    yield f"\033[31m-{line.rstrip()}\033[0m\n"
                for line in new_lines[j1:j2]:
                    yield f"\033[32m+{line.rstrip()}\033[0m\n"
            elif tag == "delete":
                for line in self.old_lines[i1:i2]:
                    yield f"\033[31m-{line.rstrip()}\033[0m\n"
            elif tag == "insert":
                for line in new_lines[j1:j2]:
                    yield f"\033[32m+{line.rstrip()}\033[0m\n"
    
    def get_final_diff(self) -> str:
        """Get final unified diff."""
        new_lines = self.new_content.splitlines(keepends=True)
        
        diff = difflib.unified_diff(
            self.old_lines,
            new_lines,
            fromfile=f"a/{self.file_path}",
            tofile=f"b/{self.file_path}",
        )
        
        return "".join(diff)


def create_live_diff_display(
    file_path: str,
    old_content: str,
    console: Console | None = None,
) -> tuple[Live, StreamingDiffRenderer]:
    """
    Create a Rich Live display for streaming diff.
    
    Args:
        file_path: Path to file being modified
        old_content: Original content
        console: Optional Console instance
        
    Returns:
        Tuple of (Live display, StreamingDiffRenderer)
    """
    if console is None:
        console = Console()
    
    renderer = StreamingDiffRenderer(console=console)
    renderer.start_diff(file_path, old_content)
    
    # Create initial panel
    name = Path(file_path).name
    initial_panel = Panel(
        Text("Generating changes...", style="dim italic"),
        title=f"📝 Diff: {name}",
        border_style="blue",
    )
    
    live = Live(initial_panel, console=console, refresh_per_second=10)
    
    return live, renderer
