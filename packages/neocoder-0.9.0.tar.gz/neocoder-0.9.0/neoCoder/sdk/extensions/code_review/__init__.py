"""
Code Review Extension — prompt-based.

The agent IS the reviewer: it gets coding rules from ``coding_rules.py``
and file contents, then uses its semantic understanding to find issues.
No regex, no AST, no static analysis.
"""

from .extension import CodeReviewExtension
from .config import CodeReviewConfig

__all__ = [
    "CodeReviewExtension",
    "CodeReviewConfig",
]
