"""
Interactive confirmation for file changes.

Provides user prompts before applying file modifications with options to:
- Accept changes (y)
- Reject changes (n)
- Edit changes in external editor (e)
- View full diff (d)
- Accept all remaining changes (a)
"""

from __future__ import annotations

import os
import subprocess
import tempfile
from dataclasses import dataclass
from enum import Enum
from io import StringIO
from pathlib import Path
from typing import Callable

from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from rich.text import Text
from rich.prompt import Prompt


class ConfirmAction(Enum):
    """User response to confirmation prompt."""
    ACCEPT = "accept"           # y - Apply changes
    REJECT = "reject"           # n - Skip changes
    EDIT = "edit"               # e - Edit in external editor
    VIEW_DIFF = "view_diff"     # d - View full diff
    ACCEPT_ALL = "accept_all"   # a - Accept all remaining changes
    ABORT = "abort"             # q - Abort entire operation


@dataclass
class ConfirmationResult:
    """Result of user confirmation."""
    action: ConfirmAction
    modified_content: str | None = None  # If edited, new content


@dataclass
class ChangePreview:
    """Preview of a file change for confirmation."""
    file_path: str
    old_content: str
    new_content: str
    diff_text: str
    operation: str  # "write", "edit", "delete"
    is_new_file: bool = False


class InteractiveConfirmation:
    """
    Handles interactive confirmation prompts for file changes.
    
    Features:
    - Rich terminal UI with diff preview
    - External editor support for modifications
    - Accept all option for batch operations
    - Configurable auto-accept for specific patterns
    """
    
    def __init__(
        self,
        console: Console | None = None,
        editor: str | None = None,
        auto_accept_patterns: list[str] | None = None,
        max_diff_lines: int = 30,
    ):
        """
        Initialize interactive confirmation.
        
        Args:
            console: Rich Console for output
            editor: External editor command (default: $EDITOR or notepad/vim)
            auto_accept_patterns: File patterns to auto-accept (e.g., ["*.test.*"])
            max_diff_lines: Max diff lines to show in preview
        """
        self.console = console or Console()
        self.editor = editor or os.environ.get("EDITOR", self._default_editor())
        self.auto_accept_patterns = auto_accept_patterns or []
        self.max_diff_lines = max_diff_lines
        self._accept_all = False
    
    @staticmethod
    def _default_editor() -> str:
        """Get default editor based on platform."""
        if os.name == "nt":
            return "notepad"
        return "vim"
    
    def should_auto_accept(self, file_path: str) -> bool:
        """Check if file should be auto-accepted based on patterns."""
        if self._accept_all:
            return True
        
        from fnmatch import fnmatch
        name = Path(file_path).name
        return any(fnmatch(name, pattern) for pattern in self.auto_accept_patterns)
    
    def reset_accept_all(self) -> None:
        """Reset the accept-all flag."""
        self._accept_all = False
    
    def confirm_change(self, preview: ChangePreview) -> ConfirmationResult:
        """
        Prompt user to confirm a file change.
        
        Args:
            preview: Change preview with diff
            
        Returns:
            ConfirmationResult with user's decision
        """
        # Check auto-accept
        if self.should_auto_accept(preview.file_path):
            return ConfirmationResult(action=ConfirmAction.ACCEPT)
        
        # Show preview panel
        self._show_preview(preview)
        
        # Prompt for action
        while True:
            action = self._prompt_action(preview)
            
            if action == ConfirmAction.VIEW_DIFF:
                self._show_full_diff(preview)
                continue
            
            if action == ConfirmAction.EDIT:
                modified = self._edit_content(preview)
                if modified is not None:
                    return ConfirmationResult(
                        action=ConfirmAction.ACCEPT,
                        modified_content=modified,
                    )
                continue
            
            if action == ConfirmAction.ACCEPT_ALL:
                self._accept_all = True
                return ConfirmationResult(action=ConfirmAction.ACCEPT)
            
            return ConfirmationResult(action=action)
    
    def _show_preview(self, preview: ChangePreview) -> None:
        """Show change preview panel."""
        name = Path(preview.file_path).name
        
        # Format diff with colors
        diff_lines = preview.diff_text.splitlines()
        text = Text()
        
        shown_lines = 0
        for line in diff_lines:
            if shown_lines >= self.max_diff_lines:
                text.append(f"\n... ({len(diff_lines) - shown_lines} more lines)", style="dim")
                break
            
            if line.startswith("+++") or line.startswith("---"):
                text.append(line + "\n", style="bold cyan")
            elif line.startswith("@@"):
                text.append(line + "\n", style="cyan")
            elif line.startswith("+"):
                text.append(line + "\n", style="green")
            elif line.startswith("-"):
                text.append(line + "\n", style="red")
            else:
                text.append(line + "\n", style="dim")
            shown_lines += 1
        
        # Determine title based on operation
        if preview.is_new_file:
            title = f"✨ New file: {name}"
            border_style = "green"
        elif preview.operation == "delete":
            title = f"🗑️ Delete: {name}"
            border_style = "red"
        else:
            title = f"📝 Changes: {name}"
            border_style = "yellow"
        
        panel = Panel(
            text,
            title=title,
            subtitle=preview.file_path,
            border_style=border_style,
            padding=(0, 1),
        )
        
        self.console.print()
        self.console.print(panel)
    
    def _prompt_action(self, preview: ChangePreview) -> ConfirmAction:
        """Prompt user for action."""
        self.console.print()
        self.console.print(
            "[bold]Apply changes?[/bold] "
            "[green](y)es[/green] "
            "[red](n)o[/red] "
            "[cyan](e)dit[/cyan] "
            "[blue](d)iff[/blue] "
            "[yellow](a)ll[/yellow] "
            "[dim](q)uit[/dim]"
        )
        
        while True:
            response = Prompt.ask(
                "[bold]>[/bold]",
                choices=["y", "n", "e", "d", "a", "q", "yes", "no", "edit", "diff", "all", "quit"],
                default="y",
                show_choices=False,
            ).lower()
            
            action_map = {
                "y": ConfirmAction.ACCEPT,
                "yes": ConfirmAction.ACCEPT,
                "n": ConfirmAction.REJECT,
                "no": ConfirmAction.REJECT,
                "e": ConfirmAction.EDIT,
                "edit": ConfirmAction.EDIT,
                "d": ConfirmAction.VIEW_DIFF,
                "diff": ConfirmAction.VIEW_DIFF,
                "a": ConfirmAction.ACCEPT_ALL,
                "all": ConfirmAction.ACCEPT_ALL,
                "q": ConfirmAction.ABORT,
                "quit": ConfirmAction.ABORT,
            }
            
            if response in action_map:
                return action_map[response]
    
    def _show_full_diff(self, preview: ChangePreview) -> None:
        """Show full diff with syntax highlighting."""
        self.console.print()
        
        # Show complete diff
        text = Text()
        for line in preview.diff_text.splitlines():
            if line.startswith("+++") or line.startswith("---"):
                text.append(line + "\n", style="bold cyan")
            elif line.startswith("@@"):
                text.append(line + "\n", style="cyan")
            elif line.startswith("+"):
                text.append(line + "\n", style="green")
            elif line.startswith("-"):
                text.append(line + "\n", style="red")
            else:
                text.append(line + "\n", style="dim")
        
        panel = Panel(
            text,
            title="Full Diff",
            border_style="blue",
        )
        self.console.print(panel)
    
    def _edit_content(self, preview: ChangePreview) -> str | None:
        """Open content in external editor for modification."""
        # Create temp file with new content
        ext = Path(preview.file_path).suffix or ".txt"
        
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=ext,
            delete=False,
            encoding="utf-8",
        ) as f:
            f.write(preview.new_content)
            temp_path = f.name
        
        try:
            # Open in editor
            self.console.print(f"[dim]Opening in {self.editor}...[/dim]")
            
            if os.name == "nt":
                # Windows: use start command for GUI editors
                subprocess.run([self.editor, temp_path], check=True)
            else:
                # Unix: direct execution
                subprocess.run([self.editor, temp_path], check=True)
            
            # Read modified content
            with open(temp_path, "r", encoding="utf-8") as f:
                modified = f.read()
            
            # Check if content changed
            if modified != preview.new_content:
                self.console.print("[green]✓ Content modified[/green]")
                return modified
            else:
                self.console.print("[dim]No changes made[/dim]")
                return preview.new_content
            
        except subprocess.CalledProcessError as e:
            self.console.print(f"[red]Editor error: {e}[/red]")
            return None
        except Exception as e:
            self.console.print(f"[red]Error: {e}[/red]")
            return None
        finally:
            # Clean up temp file
            try:
                os.unlink(temp_path)
            except Exception:
                pass


class ConfirmationCallback:
    """
    Callback interface for confirmation in ExtensionContext.
    
    Allows file_edit extension to request user confirmation
    through the orchestrator/CLI layer.
    """
    
    def __init__(
        self,
        confirm_func: Callable[[ChangePreview], ConfirmationResult] | None = None,
        enabled: bool = True,
    ):
        """
        Initialize confirmation callback.
        
        Args:
            confirm_func: Function to call for confirmation
            enabled: Whether confirmation is enabled
        """
        self.confirm_func = confirm_func
        self.enabled = enabled
    
    def confirm(self, preview: ChangePreview) -> ConfirmationResult:
        """
        Request confirmation for a change.
        
        Args:
            preview: Change preview
            
        Returns:
            ConfirmationResult (ACCEPT if disabled or no callback)
        """
        if not self.enabled or not self.confirm_func:
            return ConfirmationResult(action=ConfirmAction.ACCEPT)
        
        return self.confirm_func(preview)


def create_cli_confirmation(
    console: Console | None = None,
    enabled: bool = True,
    auto_accept_patterns: list[str] | None = None,
) -> ConfirmationCallback:
    """
    Create a CLI-based confirmation callback.
    
    Args:
        console: Rich Console
        enabled: Whether confirmation is enabled
        auto_accept_patterns: Patterns to auto-accept
        
    Returns:
        ConfirmationCallback for use in ExtensionContext
    """
    if not enabled:
        return ConfirmationCallback(enabled=False)
    
    confirmation = InteractiveConfirmation(
        console=console,
        auto_accept_patterns=auto_accept_patterns,
    )
    
    return ConfirmationCallback(
        confirm_func=confirmation.confirm_change,
        enabled=True,
    )
