"""
File search extension for code exploration.

Provides:
- Glob pattern matching for finding files
- Content search (grep) with regex support
- Code-aware search results
"""

from __future__ import annotations

import os
import re
import fnmatch
from pathlib import Path
from dataclasses import dataclass
from typing import Any

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.llm.output_parser import Action


@dataclass
class FileSearchConfig:
    """Configuration for file search extension."""

    max_results: int = 100
    max_file_size: int = 1_000_000  # Skip files larger than this
    context_lines: int = 2  # Lines before/after match
    ignored_dirs: list[str] | None = None
    ignored_patterns: list[str] | None = None


class FileSearchExtension(Extension):
    """
    Extension for searching files and code.

    Supports:
    - glob: Find files matching patterns
    - grep: Search file contents with regex
    """

    def __init__(self, config: FileSearchConfig | None = None):
        """
        Initialize file search extension.

        Args:
            config: Search configuration.
        """
        super().__init__()
        self.config = config or FileSearchConfig()

        # Default ignored directories
        self._ignored_dirs = set(self.config.ignored_dirs or [
            ".git",
            "node_modules",
            "__pycache__",
            ".venv",
            "venv",
            ".tox",
            "dist",
            "build",
            ".eggs",
            "*.egg-info",
        ])

        # Default ignored patterns
        self._ignored_patterns = self.config.ignored_patterns or [
            "*.pyc",
            "*.pyo",
            "*.so",
            "*.o",
            "*.a",
            "*.dll",
            "*.exe",
            "*.bin",
        ]

    @property
    def name(self) -> str:
        return "file_search"

    @property
    def xml_tags(self) -> list[str]:
        return ["glob", "grep", "search"]

    @property
    def tool_definitions(self) -> list[dict[str, Any]]:
        return [
            {
                "name": "glob",
                "description": "Find files matching a glob pattern (e.g., '**/*.py', 'src/**/*.ts').",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "Glob pattern to match files",
                        },
                        "path": {
                            "type": "string",
                            "description": "Starting directory (default: current directory)",
                        },
                    },
                    "required": ["pattern"],
                },
            },
            {
                "name": "grep",
                "description": "Search for a pattern in file contents. Returns matching lines with context.",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "Regex pattern to search for",
                        },
                        "path": {
                            "type": "string",
                            "description": "File or directory to search in",
                        },
                        "glob": {
                            "type": "string",
                            "description": "Glob pattern to filter files (e.g., '*.py')",
                        },
                        "case_sensitive": {
                            "type": "boolean",
                            "description": "Whether search is case-sensitive (default: true)",
                        },
                    },
                    "required": ["pattern"],
                },
            },
        ]

    def can_handle(self, action: Action) -> bool:
        """Check if we can handle this action."""
        return action.name in ["glob", "grep", "search", "file_search"]

    def _should_ignore(self, path: Path) -> bool:
        """Check if a path should be ignored."""
        # Check directory names
        for part in path.parts:
            if part in self._ignored_dirs:
                return True

        # Check file patterns
        name = path.name
        for pattern in self._ignored_patterns:
            if fnmatch.fnmatch(name, pattern):
                return True

        return False

    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """
        Execute a search operation.

        Args:
            action: Action to execute.
            context: Extension context.

        Returns:
            ExecutionResult with search results.
        """
        if action.name == "glob":
            return self._handle_glob(action, context)
        elif action.name in ["grep", "search"]:
            return self._handle_grep(action, context)
        else:
            return ExecutionResult.error_result(f"Unknown search action: {action.name}")

    def _handle_glob(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle glob file search."""
        pattern = action.input.get("pattern", "")
        if not pattern:
            return ExecutionResult.error_result("pattern is required")

        base_path = action.input.get("path", context.working_dir)
        base = Path(base_path).resolve()

        if not base.exists():
            return ExecutionResult.error_result(f"Path not found: {base_path}")

        try:
            matches = []
            for path in base.glob(pattern):
                if self._should_ignore(path):
                    continue
                if path.is_file():
                    rel_path = path.relative_to(base)
                    matches.append(str(rel_path))

                if len(matches) >= self.config.max_results:
                    break

            # Sort matches
            matches.sort()

            # Build output
            if not matches:
                output = f"No files found matching pattern: {pattern}"
            else:
                output = f"Found {len(matches)} files matching '{pattern}':\n"
                output += "\n".join(f"  {m}" for m in matches)
                if len(matches) >= self.config.max_results:
                    output += f"\n  ... (limited to {self.config.max_results} results)"

            # Don't call context.output_to_user() - orchestrator will handle it via result.user_output
            # Set user_output=None to prevent duplicate display (output goes to memory only)

            return ExecutionResult.success_result(
                output=output,
                user_output=None,  # Don't show to user - LLM will describe results
                artifacts={"glob_matches": matches},
            )

        except Exception as e:
            return ExecutionResult.error_result(f"Glob search failed: {str(e)}")

    def _handle_grep(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle content search (grep)."""
        pattern = action.input.get("pattern", "")
        if not pattern:
            return ExecutionResult.error_result("pattern is required")

        base_path = action.input.get("path", context.working_dir)
        base = Path(base_path).resolve()
        file_glob = action.input.get("glob", "**/*")
        case_sensitive = action.input.get("case_sensitive", True)

        if not base.exists():
            return ExecutionResult.error_result(f"Path not found: {base_path}")

        try:
            # Compile regex
            flags = 0 if case_sensitive else re.IGNORECASE
            regex = re.compile(pattern, flags)

            results = []
            files_searched = 0
            files_with_matches = 0

            # Determine files to search
            if base.is_file():
                files_to_search = [base]
            else:
                files_to_search = list(base.glob(file_glob))

            for file_path in files_to_search:
                if not file_path.is_file():
                    continue

                if self._should_ignore(file_path):
                    continue

                # Skip large files
                try:
                    if file_path.stat().st_size > self.config.max_file_size:
                        continue
                except OSError:
                    continue

                files_searched += 1
                file_matches = self._search_file(file_path, regex, base)

                if file_matches:
                    files_with_matches += 1
                    results.extend(file_matches)

                if len(results) >= self.config.max_results:
                    break

            # Build output
            if not results:
                output = f"No matches found for pattern: {pattern}"
            else:
                output = f"Found {len(results)} matches in {files_with_matches} files:\n\n"
                output += "\n".join(results[:self.config.max_results])
                if len(results) > self.config.max_results:
                    output += f"\n\n... ({len(results) - self.config.max_results} more matches)"

            # Don't call context.output_to_user() - orchestrator will handle it via result.user_output
            # Set user_output=None to prevent duplicate display (output goes to memory only)

            return ExecutionResult.success_result(
                output=output,
                user_output=None,  # Don't show to user - LLM will describe results
                artifacts={
                    "grep_match_count": len(results),
                    "files_with_matches": files_with_matches,
                },
            )

        except re.error as e:
            return ExecutionResult.error_result(f"Invalid regex pattern: {str(e)}")
        except Exception as e:
            return ExecutionResult.error_result(f"Search failed: {str(e)}")

    def _search_file(
        self, file_path: Path, regex: re.Pattern, base: Path
    ) -> list[str]:
        """Search a single file for matches."""
        results = []

        try:
            content = file_path.read_text(encoding="utf-8", errors="ignore")
            lines = content.splitlines()

            rel_path = file_path.relative_to(base) if base in file_path.parents else file_path

            for i, line in enumerate(lines):
                if regex.search(line):
                    # Get context lines
                    start = max(0, i - self.config.context_lines)
                    end = min(len(lines), i + self.config.context_lines + 1)

                    context_block = []
                    for j in range(start, end):
                        prefix = ">" if j == i else " "
                        context_block.append(f"  {j + 1:4d}{prefix} {lines[j]}")

                    match_str = f"{rel_path}:{i + 1}\n" + "\n".join(context_block)
                    results.append(match_str)

        except (UnicodeDecodeError, IOError):
            # Skip files that can't be read
            pass

        return results

    def signals_continuation(self) -> bool:
        """Search operations typically want continuation."""
        return True
