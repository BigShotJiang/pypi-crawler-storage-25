"""
Main code understanding cache.
"""

from __future__ import annotations

import hashlib
import os
from datetime import datetime
from pathlib import Path

from neoCoder.sdk.code_cache.config import CacheConfig
from neoCoder.sdk.code_cache.store import CacheStore
from neoCoder.sdk.code_cache.invalidator import CacheInvalidator
from neoCoder.sdk.code_cache.parser import CodeParser
from neoCoder.sdk.code_cache.analyzer import CodeAnalyzer
from neoCoder.sdk.code_cache.models import (
    CachedFileAnalysis,
    FileMetadata,
)


class CodeUnderstandingCache:
    """
    Main cache for code understanding.
    
    Coordinates parsing, analysis, storage, and invalidation
    of file analysis results.
    """
    
    def __init__(self, config: CacheConfig | None = None):
        """
        Initialize cache.
        
        Args:
            config: Cache configuration (uses defaults if None)
        """
        self.config = config or CacheConfig()
        self.store = CacheStore(self.config)
        self.invalidator = CacheInvalidator(self.config)
        self.parser = CodeParser()
        self.analyzer = CodeAnalyzer()
        
        # Metrics
        self.hits = 0
        self.misses = 0
    
    def get_analysis(self, file_path: str) -> CachedFileAnalysis | None:
        """
        Get cached analysis for a file.
        
        Args:
            file_path: Path to file
            
        Returns:
            Cached analysis if valid, None otherwise
        """
        if not self.config.enabled:
            return None
        
        # Get from cache
        cached = self.store.get(file_path)
        
        if cached is None:
            self.misses += 1
            return None
        
        # Check if still valid
        if not self.invalidator.is_valid(cached, file_path):
            # Invalidate
            self.store.delete(file_path)
            self.misses += 1
            return None
        
        # Note: CacheStore.get() already updated access_count and last_accessed
        self.hits += 1
        return cached
    
    def analyze_file(self, file_path: str) -> CachedFileAnalysis:
        """
        Analyze a file and cache the result.
        
        Args:
            file_path: Path to file
            
        Returns:
            Analysis result (from cache or newly computed)
        """
        # Check cache first
        cached = self.get_analysis(file_path)
        if cached is not None:
            return cached
        
        # Check file size
        file_size = os.path.getsize(file_path)
        max_size_bytes = self.config.max_file_size_mb * 1024 * 1024
        
        if file_size > max_size_bytes:
            # File too large, return minimal analysis
            return self._create_minimal_analysis(file_path)
        
        # Read and analyze file
        try:
            content = Path(file_path).read_text(encoding="utf-8")
        except (UnicodeDecodeError, FileNotFoundError):
            return self._create_minimal_analysis(file_path)
        
        # Create metadata
        metadata = FileMetadata(
            file_path=file_path,
            size_bytes=file_size,
            mtime=os.path.getmtime(file_path),
            content_hash=hashlib.md5(content.encode()).hexdigest(),
            language=self._detect_language(file_path),
        )
        
        # Parse code structure
        if metadata.language == "python" and self.config.parse_ast:
            parsed = self.parser.parse_python(content)
            functions = parsed["functions"]
            classes = parsed["classes"]
            imports = parsed["imports"]
        else:
            # Unsupported language or AST parsing disabled
            functions = []
            classes = []
            imports = []
        
        # Analyze code
        if self.config.calculate_complexity:
            analysis_result = self.analyzer.analyze(
                content,
                functions,
                classes,
                imports,
            )
            summary = analysis_result["summary"]
            complexity = analysis_result["complexity"]
            loc = analysis_result["loc"]
        else:
            summary = f"File: {Path(file_path).name}"
            complexity = 0.0
            loc = len(content.split("\n"))
        
        # Create cached analysis
        cached_analysis = CachedFileAnalysis(
            metadata=metadata,
            functions=functions,
            classes=classes,
            imports=imports,
            summary=summary,
            complexity=complexity,
            loc=loc,
            cached_at=datetime.now(),
            access_count=1,
            last_accessed=datetime.now(),
        )
        
        # Store in cache
        self.store.put(file_path, cached_analysis)
        
        return cached_analysis
    
    def invalidate(self, file_path: str):
        """
        Invalidate cache entry for a file.
        
        Args:
            file_path: Path to file
        """
        self.store.delete(file_path)
    
    def clear(self):
        """Clear all cache entries."""
        self.store.clear()
        self.hits = 0
        self.misses = 0
    
    def get_stats(self) -> dict:
        """
        Get cache statistics.
        
        Returns:
            Dictionary with cache metrics
        """
        total_requests = self.hits + self.misses
        hit_rate = self.hits / total_requests if total_requests > 0 else 0.0
        
        return {
            "hits": self.hits,
            "misses": self.misses,
            "total_requests": total_requests,
            "hit_rate": hit_rate,
            "cache_size": self.store.size(),
            "max_entries": self.config.max_entries,
        }
    
    def _detect_language(self, file_path: str) -> str:
        """Detect programming language from file extension."""
        ext = Path(file_path).suffix.lower()
        
        language_map = {
            ".py": "python",
            ".js": "javascript",
            ".ts": "typescript",
            ".jsx": "javascript",
            ".tsx": "typescript",
            ".java": "java",
            ".cpp": "cpp",
            ".c": "c",
            ".go": "go",
            ".rs": "rust",
        }
        
        return language_map.get(ext, "unknown")
    
    def _create_minimal_analysis(self, file_path: str) -> CachedFileAnalysis:
        """Create minimal analysis for files that can't be fully analyzed."""
        metadata = FileMetadata(
            file_path=file_path,
            size_bytes=0,
            mtime=0.0,
            content_hash="",
            language=self._detect_language(file_path),
        )
        
        return CachedFileAnalysis(
            metadata=metadata,
            functions=[],
            classes=[],
            imports=[],
            summary=f"File: {Path(file_path).name}",
            complexity=0.0,
            loc=0,
            cached_at=datetime.now(),
            access_count=1,
            last_accessed=datetime.now(),
        )
