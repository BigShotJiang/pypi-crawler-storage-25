"""
Code Cache Extension.

Integrates CodeUnderstandingCache with file operations to provide
automatic caching and analysis of code files.
"""

from typing import Optional
from pathlib import Path

from neoCoder.sdk.extensions.base import Extension, ExtensionContext, ExecutionResult
from neoCoder.sdk.llm.output_parser import Action
from neoCoder.sdk.code_cache.cache import CodeUnderstandingCache
from neoCoder.sdk.code_cache.config import CacheConfig


class CodeCacheExtension(Extension):
    """
    Extension that integrates code understanding cache with file operations.
    
    Features:
    - Automatic cache warming on file reads
    - Cache invalidation on file writes/edits
    - Cache statistics tracking
    - Enhanced file analysis
    """
    
    def __init__(self, config: Optional[CacheConfig] = None):
        """
        Initialize code cache extension.
        
        Args:
            config: Code cache configuration
        """
        super().__init__()
        self.config = config or CacheConfig()
        self.cache = CodeUnderstandingCache(config)
    
    @property
    def name(self) -> str:
        return "code_cache"
    
    @property
    def xml_tags(self) -> list[str]:
        return []  # This extension hooks into other extensions
    
    @property
    def tool_definitions(self) -> list[dict]:
        return [
            {
                "name": "analyze_code_file",
                "description": "Analyze a code file and get detailed information about its structure",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the code file to analyze",
                        },
                    },
                    "required": ["file_path"],
                },
            },
            {
                "name": "warm_cache_directory",
                "description": "Warm code cache for all files in a directory",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "directory": {
                            "type": "string",
                            "description": "Directory path to warm cache for",
                        },
                        "recursive": {
                            "type": "boolean",
                            "description": "Whether to search recursively (default: true)",
                        },
                    },
                    "required": ["directory"],
                },
            },
            {
                "name": "warm_cache_related",
                "description": "Warm cache for files related to a given file (e.g., imports)",
                "input_schema": {
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the main file",
                        },
                    },
                    "required": ["file_path"],
                },
            },
            {
                "name": "get_cache_stats",
                "description": "Get code cache statistics (hits, misses, size)",
                "input_schema": {
                    "type": "object",
                    "properties": {},
                },
            },
            {
                "name": "clear_cache",
                "description": "Clear the code understanding cache",
                "input_schema": {
                    "type": "object",
                    "properties": {},
                },
            },
        ]
    
    def can_handle(self, action: Action) -> bool:
        """Check if we can handle this action."""
        return action.name in [
            "analyze_code_file",
            "warm_cache_directory",
            "warm_cache_related",
            "get_cache_stats",
            "clear_cache",
        ]
    
    def execute(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """
        Execute cache operation.
        
        Args:
            action: Action to execute
            context: Extension context
            
        Returns:
            ExecutionResult with operation result
        """
        if action.name == "analyze_code_file":
            return self._handle_analyze(action, context)
        elif action.name == "warm_cache_directory":
            return self._handle_warm_directory(action, context)
        elif action.name == "warm_cache_related":
            return self._handle_warm_related(action, context)
        elif action.name == "get_cache_stats":
            return self._handle_stats(action, context)
        elif action.name == "clear_cache":
            return self._handle_clear(action, context)
        else:
            return ExecutionResult.error_result(f"Unknown action: {action.name}")
    
    def _handle_analyze(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle file analysis request."""
        file_path = action.input.get("file_path")
        if not file_path:
            return ExecutionResult.error_result("file_path is required")
        
        # Resolve path
        path = Path(file_path)
        if not path.is_absolute():
            path = Path(context.working_dir) / path
        path = path.resolve()
        
        if not path.exists():
            return ExecutionResult.error_result(f"File not found: {file_path}")
        
        try:
            # Analyze file
            analysis = self.cache.analyze_file(str(path))
            
            if not analysis:
                return ExecutionResult.error_result(f"Failed to analyze file: {file_path}")
            
            # Format output
            output_lines = [
                f"File: {file_path}",
                f"Language: {analysis.metadata.language}",
                f"Lines of code: {analysis.loc}",
                f"Functions: {len(analysis.functions)}",
                f"Classes: {len(analysis.classes)}",
                f"Imports: {len(analysis.imports)}",
                "",
                "Summary:",
                analysis.summary,
            ]
            
            if analysis.functions:
                output_lines.append("")
                output_lines.append("Functions:")
                for func in analysis.functions[:10]:  # Limit to 10
                    complexity = func.complexity if hasattr(func, 'complexity') else 'N/A'
                    output_lines.append(f"  - {func.name} (complexity: {complexity})")
                if len(analysis.functions) > 10:
                    output_lines.append(f"  ... and {len(analysis.functions) - 10} more")
            
            if analysis.classes:
                output_lines.append("")
                output_lines.append("Classes:")
                for cls in analysis.classes[:10]:  # Limit to 10
                    methods = cls.methods if hasattr(cls, 'methods') else []
                    output_lines.append(f"  - {cls.name} ({len(methods)} methods)")
                if len(analysis.classes) > 10:
                    output_lines.append(f"  ... and {len(analysis.classes) - 10} more")
            
            user_output = "\n".join(output_lines)
            context.output_to_user(user_output)
            
            return ExecutionResult.success_result(
                output=user_output,
                user_output=user_output,
            )
            
        except Exception as e:
            return ExecutionResult.error_result(f"Error analyzing file: {str(e)}")
    
    def _handle_stats(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle cache statistics request."""
        stats = self.cache.get_stats()
        
        output_lines = [
            "Code Cache Statistics:",
            f"  Hits: {stats['hits']}",
            f"  Misses: {stats['misses']}",
            f"  Total requests: {stats['total_requests']}",
            f"  Hit rate: {stats['hit_rate']:.1%}",
            f"  Cache size: {stats['cache_size']} entries",
        ]
        
        user_output = "\n".join(output_lines)
        context.output_to_user(user_output)
        
        return ExecutionResult.success_result(
            output=user_output,
            user_output=user_output,
        )
    
    def _handle_clear(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle cache clear request."""
        self.cache.clear()
        
        user_output = "Code cache cleared successfully"
        context.output_to_user(user_output)
        
        return ExecutionResult.success_result(
            output=user_output,
            user_output=user_output,
        )
    
    def _handle_warm_directory(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle directory cache warming request."""
        directory = action.input.get("directory")
        if not directory:
            return ExecutionResult.error_result("directory is required")
        
        recursive = action.input.get("recursive", True)
        
        # Resolve path
        dir_path = Path(directory)
        if not dir_path.is_absolute():
            dir_path = Path(context.working_dir) / dir_path
        dir_path = dir_path.resolve()
        
        result = self.warm_cache_for_directory(str(dir_path), recursive)
        
        if not result["success"]:
            return ExecutionResult.error_result(result["error"])
        
        output_lines = [
            f"Cache warming completed for: {directory}",
            f"  Files warmed: {result['files_warmed']}",
            f"  Files skipped: {result['files_skipped']}",
        ]
        
        if result["errors"]:
            output_lines.append(f"  Errors: {len(result['errors'])}")
            for error in result["errors"][:5]:  # Show first 5 errors
                output_lines.append(f"    - {error}")
            if len(result["errors"]) > 5:
                output_lines.append(f"    ... and {len(result['errors']) - 5} more")
        
        user_output = "\n".join(output_lines)
        context.output_to_user(user_output)
        
        return ExecutionResult.success_result(
            output=user_output,
            user_output=user_output,
        )
    
    def _handle_warm_related(self, action: Action, context: ExtensionContext) -> ExecutionResult:
        """Handle related files cache warming request."""
        file_path = action.input.get("file_path")
        if not file_path:
            return ExecutionResult.error_result("file_path is required")
        
        # Resolve path
        path = Path(file_path)
        if not path.is_absolute():
            path = Path(context.working_dir) / path
        path = path.resolve()
        
        result = self.warm_cache_for_related_files(str(path))
        
        if not result["success"]:
            return ExecutionResult.error_result(result["error"])
        
        output_lines = [
            f"Cache warming completed for related files of: {file_path}",
            f"  Files warmed: {result['files_warmed']}",
            f"  Files skipped: {result['files_skipped']}",
        ]
        
        if result["errors"]:
            output_lines.append(f"  Errors: {len(result['errors'])}")
            for error in result["errors"][:5]:
                output_lines.append(f"    - {error}")
            if len(result["errors"]) > 5:
                output_lines.append(f"    ... and {len(result['errors']) - 5} more")
        
        user_output = "\n".join(output_lines)
        context.output_to_user(user_output)
        
        return ExecutionResult.success_result(
            output=user_output,
            user_output=user_output,
        )
    
    def on_input_messages(self, messages: list, context: ExtensionContext) -> list:
        """
        Hook called before messages are sent to LLM.
        
        Can be used to warm cache for files mentioned in messages.
        Also warms cache for files from glob/grep results.
        
        Args:
            messages: Input messages
            context: Extension context
            
        Returns:
            Modified messages (unchanged in this case)
        """
        if not self.config.enabled:
            return messages
        
        # Extract file paths from messages and warm cache
        for message in messages:
            content = message.get("content", "")
            artifacts = message.get("artifacts", {})
            
            # Warm cache from glob results
            if "glob_matches" in artifacts:
                for file_path in artifacts["glob_matches"]:
                    self._warm_cache_for_file(file_path, context)
            
            # Extract file paths from content (simple heuristic)
            if isinstance(content, str):
                words = content.split()
                for word in words:
                    if "/" in word or "\\" in word:
                        # Might be a file path
                        self._warm_cache_for_file(word.strip("'\""), context)
        
        return messages
    
    def _warm_cache_for_file(self, file_path: str, context: ExtensionContext) -> None:
        """
        Warm cache for a single file.
        
        Args:
            file_path: Path to file
            context: Extension context
        """
        try:
            path = Path(file_path)
            if not path.is_absolute():
                path = Path(context.working_dir) / path
            
            if path.exists() and path.is_file():
                # Only warm cache for code files
                if self._is_code_file(path):
                    self.cache.analyze_file(str(path))
        except Exception:
            pass  # Ignore errors during warming
    
    def _is_code_file(self, path: Path) -> bool:
        """
        Check if file is a code file worth caching.
        
        Args:
            path: File path
            
        Returns:
            True if file should be cached
        """
        code_extensions = {
            ".py", ".js", ".ts", ".jsx", ".tsx",
            ".java", ".c", ".cpp", ".h", ".hpp",
            ".go", ".rs", ".rb", ".php", ".cs",
            ".swift", ".kt", ".scala", ".r",
        }
        return path.suffix.lower() in code_extensions
    
    def warm_cache_for_directory(self, directory: str, recursive: bool = True) -> dict:
        """
        Warm cache for all code files in a directory.
        
        Args:
            directory: Directory path
            recursive: Whether to search recursively
            
        Returns:
            Dictionary with warming statistics
        """
        dir_path = Path(directory)
        if not dir_path.exists() or not dir_path.is_dir():
            return {
                "success": False,
                "error": f"Directory not found: {directory}",
            }
        
        pattern = "**/*" if recursive else "*"
        files_warmed = 0
        files_skipped = 0
        errors = []
        
        for file_path in dir_path.glob(pattern):
            if not file_path.is_file():
                continue
            
            if not self._is_code_file(file_path):
                files_skipped += 1
                continue
            
            try:
                self.cache.analyze_file(str(file_path))
                files_warmed += 1
            except Exception as e:
                errors.append(f"{file_path}: {str(e)}")
        
        return {
            "success": True,
            "files_warmed": files_warmed,
            "files_skipped": files_skipped,
            "errors": errors,
        }
    
    def warm_cache_for_related_files(self, file_path: str) -> dict:
        """
        Warm cache for files related to the given file (e.g., imports).
        
        Args:
            file_path: Path to the main file
            
        Returns:
            Dictionary with warming statistics
        """
        path = Path(file_path)
        if not path.exists() or not path.is_file():
            return {
                "success": False,
                "error": f"File not found: {file_path}",
            }
        
        # Analyze main file first
        try:
            analysis = self.cache.analyze_file(str(path))
        except Exception as e:
            return {
                "success": False,
                "error": f"Failed to analyze file: {str(e)}",
            }
        
        if not analysis:
            return {
                "success": False,
                "error": "No analysis available",
            }
        
        # Warm cache for imported files
        files_warmed = 1  # Main file
        files_skipped = 0
        errors = []
        
        for import_info in analysis.imports:
            # Try to resolve import to file path
            # This is a simple heuristic - could be enhanced
            import_name = import_info.module if hasattr(import_info, 'module') else str(import_info)
            
            # Convert import to file path (Python-specific)
            if path.suffix == ".py":
                import_path = path.parent / f"{import_name.replace('.', '/')}.py"
                if import_path.exists():
                    try:
                        self.cache.analyze_file(str(import_path))
                        files_warmed += 1
                    except Exception as e:
                        errors.append(f"{import_path}: {str(e)}")
                else:
                    files_skipped += 1
        
        return {
            "success": True,
            "files_warmed": files_warmed,
            "files_skipped": files_skipped,
            "errors": errors,
        }
    
    def on_output_messages(self, messages: list, context: ExtensionContext) -> list:
        """
        Hook called after LLM generates messages.
        
        Can be used to invalidate cache for files that were modified.
        
        Args:
            messages: Output messages
            context: Extension context
            
        Returns:
            Modified messages (unchanged in this case)
        """
        if not self.config.enabled:
            return messages
        
        # Check if any files were modified
        # Look for file_write or file_edit actions in artifacts
        for message in messages:
            if isinstance(message, dict):
                artifacts = message.get("artifacts", {})
                
                # Invalidate cache for written/edited files
                if "last_written_file" in artifacts:
                    file_path = artifacts["last_written_file"]
                    self.cache.invalidate(file_path)
                
                if "last_edited_file" in artifacts:
                    file_path = artifacts["last_edited_file"]
                    self.cache.invalidate(file_path)
        
        return messages
    
    def signals_continuation(self) -> bool:
        """Cache operations don't signal continuation."""
        return False
