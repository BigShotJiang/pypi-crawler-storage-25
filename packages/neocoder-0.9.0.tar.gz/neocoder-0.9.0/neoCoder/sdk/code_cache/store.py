"""
Cache store with LRU eviction.
"""

from __future__ import annotations

import json
from collections import OrderedDict
from datetime import datetime
from pathlib import Path
from typing import Any

from neoCoder.sdk.code_cache.config import CacheConfig
from neoCoder.sdk.code_cache.models import CachedFileAnalysis


class CacheStore:
    """
    LRU cache store for file analysis results.
    
    Supports both in-memory and disk-based storage with automatic
    eviction when size limits are reached.
    """
    
    def __init__(self, config: CacheConfig | None = None):
        """
        Initialize cache store.
        
        Args:
            config: Cache configuration.
        """
        self.config = config or CacheConfig()
        self._cache: OrderedDict[str, CachedFileAnalysis] = OrderedDict()
        self.hits = 0
        self.misses = 0
        
        # Load from disk if configured
        if self.config.use_disk_cache and self.config.storage_path:
            self._load_from_disk()
    
    def get(self, key: str) -> CachedFileAnalysis | None:
        """
        Get cached analysis by key.
        
        Args:
            key: Cache key (usually file path).
            
        Returns:
            Cached analysis or None if not found.
        """
        if not self.config.enabled:
            return None
        
        if key in self._cache:
            # Move to end (most recently used)
            self._cache.move_to_end(key)
            
            # Update access metadata
            cached = self._cache[key]
            cached.access_count += 1
            cached.last_accessed = datetime.now()
            
            self.hits += 1
            return cached
        
        self.misses += 1
        return None
    
    def put(self, key: str, analysis: CachedFileAnalysis) -> None:
        """
        Store analysis in cache.
        
        Args:
            key: Cache key (usually file path).
            analysis: File analysis to cache.
        """
        if not self.config.enabled:
            return
        
        # Remove if already exists (will be re-added at end)
        if key in self._cache:
            del self._cache[key]
        
        # Add to cache
        self._cache[key] = analysis
        
        # Evict if over size limit
        if len(self._cache) > self.config.max_entries:
            self._evict_lru()
        
        # Save to disk if configured
        if self.config.use_disk_cache:
            self._save_to_disk()
    
    def remove(self, key: str) -> bool:
        """
        Remove entry from cache.
        
        Args:
            key: Cache key to remove.
            
        Returns:
            True if removed, False if not found.
        """
        if key in self._cache:
            del self._cache[key]
            
            if self.config.use_disk_cache:
                self._save_to_disk()
            
            return True
        
        return False
    
    def delete(self, key: str) -> bool:
        """
        Alias for remove() for compatibility.
        
        Args:
            key: Cache key to remove.
            
        Returns:
            True if removed, False if not found.
        """
        return self.remove(key)
    
    def size(self) -> int:
        """
        Get current cache size.
        
        Returns:
            Number of entries in cache.
        """
        return len(self._cache)
    
    def clear(self) -> None:
        """Clear all cache entries."""
        self._cache.clear()
        self.hits = 0
        self.misses = 0
        
        if self.config.use_disk_cache:
            self._save_to_disk()
    
    def get_stats(self) -> dict[str, Any]:
        """
        Get cache statistics.
        
        Returns:
            Dictionary with cache stats.
        """
        total_requests = self.hits + self.misses
        hit_rate = self.hits / total_requests if total_requests > 0 else 0.0
        
        return {
            "size": len(self._cache),
            "max_entries": self.config.max_entries,
            "hits": self.hits,
            "misses": self.misses,
            "hit_rate": hit_rate,
            "enabled": self.config.enabled,
        }
    
    def _evict_lru(self) -> None:
        """Evict least recently used entry."""
        if self._cache:
            # Remove first item (least recently used)
            self._cache.popitem(last=False)
    
    def _save_to_disk(self) -> None:
        """Save cache to disk."""
        if not self.config.storage_path:
            return
        
        try:
            storage_path = Path(self.config.storage_path)
            storage_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Convert cache to serializable format
            data = {
                "cache": {
                    key: analysis.to_dict()
                    for key, analysis in self._cache.items()
                },
                "stats": {
                    "hits": self.hits,
                    "misses": self.misses,
                },
            }
            
            with open(storage_path, 'w') as f:
                json.dump(data, f, indent=2)
        
        except Exception as e:
            # Log error but don't fail
            print(f"Warning: Failed to save cache to disk: {e}")
    
    def _load_from_disk(self) -> None:
        """Load cache from disk."""
        if not self.config.storage_path:
            return
        
        try:
            storage_path = Path(self.config.storage_path)
            
            if not storage_path.exists():
                return
            
            with open(storage_path, 'r') as f:
                data = json.load(f)
            
            # Restore cache
            for key, analysis_dict in data.get("cache", {}).items():
                analysis = CachedFileAnalysis.from_dict(analysis_dict)
                self._cache[key] = analysis
            
            # Restore stats
            stats = data.get("stats", {})
            self.hits = stats.get("hits", 0)
            self.misses = stats.get("misses", 0)
        
        except Exception as e:
            # Log error but don't fail
            print(f"Warning: Failed to load cache from disk: {e}")
