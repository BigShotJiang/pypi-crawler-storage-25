"""
Cache invalidator - checks if cached entries are still valid.
"""

from __future__ import annotations

import hashlib
import os
from datetime import datetime
from pathlib import Path

from neoCoder.sdk.code_cache.config import CacheConfig
from neoCoder.sdk.code_cache.models import CachedFileAnalysis


class CacheInvalidator:
    """
    Validates cached entries and determines if they need refresh.
    
    Checks file modification time, content hash, and TTL.
    """
    
    def __init__(self, config: CacheConfig | None = None):
        """
        Initialize cache invalidator.
        
        Args:
            config: Cache configuration.
        """
        self.config = config or CacheConfig()
    
    def is_valid(self, cached: CachedFileAnalysis, file_path: str) -> bool:
        """
        Check if cached entry is still valid.
        
        Args:
            cached: Cached file analysis.
            file_path: Path to the file.
            
        Returns:
            True if valid, False if needs refresh.
        """
        # Check TTL
        if not self._check_ttl(cached):
            return False
        
        # Check file exists
        if not Path(file_path).exists():
            return False
        
        # Check mtime if configured
        if self.config.check_mtime and not self._check_mtime(cached, file_path):
            return False
        
        # Check content hash if configured
        if self.config.check_content_hash and not self._check_content_hash(cached, file_path):
            return False
        
        return True
    
    def _check_ttl(self, cached: CachedFileAnalysis) -> bool:
        """Check if entry has expired based on TTL."""
        age_seconds = (datetime.now() - cached.cached_at).total_seconds()
        return age_seconds <= self.config.ttl_seconds
    
    def _check_mtime(self, cached: CachedFileAnalysis, file_path: str) -> bool:
        """Check if file modification time has changed."""
        try:
            current_mtime = os.path.getmtime(file_path)
            return abs(current_mtime - cached.metadata.mtime) < 0.001  # Allow small float differences
        except OSError:
            return False
    
    def _check_content_hash(self, cached: CachedFileAnalysis, file_path: str) -> bool:
        """Check if file content hash has changed."""
        try:
            content = Path(file_path).read_text(encoding='utf-8', errors='ignore')
            current_hash = hashlib.md5(content.encode()).hexdigest()
            return current_hash == cached.metadata.content_hash
        except (OSError, UnicodeDecodeError):
            return False
