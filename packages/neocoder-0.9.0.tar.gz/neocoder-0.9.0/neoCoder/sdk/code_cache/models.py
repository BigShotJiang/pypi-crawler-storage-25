"""
Data models for code cache.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class FileMetadata:
    """Metadata about a file."""
    
    file_path: str
    size_bytes: int
    mtime: float
    content_hash: str
    language: str


@dataclass
class FunctionInfo:
    """Information about a function."""
    
    name: str
    line_start: int
    line_end: int
    args: list[str]
    returns: str | None
    docstring: str | None
    complexity: int = 0


@dataclass
class ClassInfo:
    """Information about a class."""
    
    name: str
    line_start: int
    line_end: int
    methods: list[FunctionInfo]
    bases: list[str]
    docstring: str | None


@dataclass
class CachedFileAnalysis:
    """
    Cached analysis of a file.
    
    Contains all information extracted from analyzing a file,
    including metadata, structure, and metrics.
    """
    
    # File metadata
    metadata: FileMetadata
    
    # Code structure
    functions: list[FunctionInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    
    # Analysis results
    summary: str = ""
    complexity: float = 0.0
    loc: int = 0  # Lines of code
    
    # Cache metadata
    cached_at: datetime = field(default_factory=datetime.now)
    access_count: int = 0
    last_accessed: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "metadata": {
                "file_path": self.metadata.file_path,
                "size_bytes": self.metadata.size_bytes,
                "mtime": self.metadata.mtime,
                "content_hash": self.metadata.content_hash,
                "language": self.metadata.language,
            },
            "functions": [
                {
                    "name": f.name,
                    "line_start": f.line_start,
                    "line_end": f.line_end,
                    "args": f.args,
                    "returns": f.returns,
                    "docstring": f.docstring,
                    "complexity": f.complexity,
                }
                for f in self.functions
            ],
            "classes": [
                {
                    "name": c.name,
                    "line_start": c.line_start,
                    "line_end": c.line_end,
                    "methods": [
                        {
                            "name": m.name,
                            "line_start": m.line_start,
                            "line_end": m.line_end,
                            "args": m.args,
                            "returns": m.returns,
                            "docstring": m.docstring,
                            "complexity": m.complexity,
                        }
                        for m in c.methods
                    ],
                    "bases": c.bases,
                    "docstring": c.docstring,
                }
                for c in self.classes
            ],
            "imports": self.imports,
            "summary": self.summary,
            "complexity": self.complexity,
            "loc": self.loc,
            "cached_at": self.cached_at.isoformat(),
            "access_count": self.access_count,
            "last_accessed": self.last_accessed.isoformat(),
        }
    
    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CachedFileAnalysis:
        """Create from dictionary."""
        metadata = FileMetadata(
            file_path=data["metadata"]["file_path"],
            size_bytes=data["metadata"]["size_bytes"],
            mtime=data["metadata"]["mtime"],
            content_hash=data["metadata"]["content_hash"],
            language=data["metadata"]["language"],
        )
        
        functions = [
            FunctionInfo(
                name=f["name"],
                line_start=f["line_start"],
                line_end=f["line_end"],
                args=f["args"],
                returns=f.get("returns"),
                docstring=f.get("docstring"),
                complexity=f.get("complexity", 0),
            )
            for f in data.get("functions", [])
        ]
        
        classes = [
            ClassInfo(
                name=c["name"],
                line_start=c["line_start"],
                line_end=c["line_end"],
                methods=[
                    FunctionInfo(
                        name=m["name"],
                        line_start=m["line_start"],
                        line_end=m["line_end"],
                        args=m["args"],
                        returns=m.get("returns"),
                        docstring=m.get("docstring"),
                        complexity=m.get("complexity", 0),
                    )
                    for m in c.get("methods", [])
                ],
                bases=c.get("bases", []),
                docstring=c.get("docstring"),
            )
            for c in data.get("classes", [])
        ]
        
        return cls(
            metadata=metadata,
            functions=functions,
            classes=classes,
            imports=data.get("imports", []),
            summary=data.get("summary", ""),
            complexity=data.get("complexity", 0.0),
            loc=data.get("loc", 0),
            cached_at=datetime.fromisoformat(data["cached_at"]),
            access_count=data.get("access_count", 0),
            last_accessed=datetime.fromisoformat(data.get("last_accessed", data["cached_at"])),
        )
