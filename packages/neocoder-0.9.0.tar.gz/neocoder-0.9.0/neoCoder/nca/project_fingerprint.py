"""
Project fingerprint for detecting dependency changes.

Uses mtime + size of dependency files to detect when
the tech stack might have changed and needs rescanning.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEPENDENCY_FILES = [
    # Python
    "pyproject.toml",
    "poetry.lock",
    "requirements.txt",
    "requirements-dev.txt",
    "requirements-test.txt",
    "Pipfile",
    "Pipfile.lock",
    "setup.py",
    "setup.cfg",
    # JavaScript/TypeScript
    "package.json",
    "package-lock.json",
    "yarn.lock",
    "pnpm-lock.yaml",
    "tsconfig.json",
    # Rust
    "Cargo.toml",
    "Cargo.lock",
    # Go
    "go.mod",
    "go.sum",
    # Ruby
    "Gemfile",
    "Gemfile.lock",
    # Java/Kotlin
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    # .NET
    "*.csproj",
    "*.fsproj",
    "packages.config",
]

FINGERPRINT_FILE = "tech_stack_fingerprint.json"
NEOCODER_DIR = ".neoCoder"


def compute_project_fingerprint(root: Path) -> dict[str, str]:
    """
    Compute fingerprint based on dependency file mtimes and sizes.
    
    Args:
        root: Project root directory.
        
    Returns:
        Dict mapping relative path to "mtime_ns:size" string.
    """
    fingerprint: dict[str, str] = {}
    
    for pattern in DEPENDENCY_FILES:
        if "*" in pattern:
            for p in root.glob(pattern):
                if p.is_file():
                    rel = str(p.relative_to(root))
                    st = p.stat()
                    fingerprint[rel] = f"{st.st_mtime_ns}:{st.st_size}"
        else:
            p = root / pattern
            if p.is_file():
                st = p.stat()
                fingerprint[pattern] = f"{st.st_mtime_ns}:{st.st_size}"
    
    return fingerprint


def load_cached_fingerprint(root: Path) -> dict[str, Any] | None:
    """
    Load cached fingerprint from .neoCoder/tech_stack_fingerprint.json.
    
    Returns:
        Cached data dict or None if not found/invalid.
    """
    fp_file = root / NEOCODER_DIR / FINGERPRINT_FILE
    
    if not fp_file.exists():
        return None
    
    try:
        with open(fp_file, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to load fingerprint: %s", e)
        return None


def save_fingerprint(root: Path, fingerprint: dict[str, str]) -> None:
    """
    Save fingerprint to .neoCoder/tech_stack_fingerprint.json.
    """
    neocoder_dir = root / NEOCODER_DIR
    neocoder_dir.mkdir(parents=True, exist_ok=True)
    
    fp_file = neocoder_dir / FINGERPRINT_FILE
    
    data = {
        "fingerprint": fingerprint,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    
    try:
        with open(fp_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        logger.debug("Fingerprint saved to %s", fp_file)
    except OSError as e:
        logger.warning("Failed to save fingerprint: %s", e)


def fingerprint_changed(root: Path) -> bool:
    """
    Check if project fingerprint has changed since last scan.
    
    Args:
        root: Project root directory.
        
    Returns:
        True if fingerprint changed or no cache exists.
    """
    current_fp = compute_project_fingerprint(root)
    cached = load_cached_fingerprint(root)
    
    if cached is None:
        logger.debug("No cached fingerprint found")
        return True
    
    cached_fp = cached.get("fingerprint", {})
    
    if current_fp != cached_fp:
        # Find what changed
        added = set(current_fp.keys()) - set(cached_fp.keys())
        removed = set(cached_fp.keys()) - set(current_fp.keys())
        changed = {k for k in current_fp if k in cached_fp and current_fp[k] != cached_fp[k]}
        
        if added:
            logger.info("Dependency files added: %s", added)
        if removed:
            logger.info("Dependency files removed: %s", removed)
        if changed:
            logger.info("Dependency files changed: %s", changed)
        
        return True
    
    logger.debug("Fingerprint unchanged, using cached tech stack")
    return False


def needs_tech_stack_refresh(root: Path, session_context_raw: str | None) -> bool:
    """
    Determine if tech stack needs to be refreshed.
    
    Refresh is needed if:
    1. No tech stack in context.md
    2. Fingerprint changed
    
    Args:
        root: Project root directory.
        session_context_raw: Raw content of context.md (or None).
        
    Returns:
        True if refresh needed.
    """
    has_tech_stack = session_context_raw and "## Tech Stack" in session_context_raw
    
    if not has_tech_stack:
        logger.debug("No tech stack in context.md, refresh needed")
        return True
    
    return fingerprint_changed(root)
