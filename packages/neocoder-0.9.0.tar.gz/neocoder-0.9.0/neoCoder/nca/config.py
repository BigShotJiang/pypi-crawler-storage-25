"""
Configuration for the neoCoder Agent.
"""

from dataclasses import dataclass, field
from typing import Literal, Optional
import os
import logging

from neoCoder.sdk.orchestrator import OrchestratorConfig
from neoCoder.sdk.llm.client import ClaudeClientConfig
from neoCoder.sdk.memory.working import WorkingMemoryConfig
from neoCoder.sdk.memory.hierarchical import HierarchicalMemoryConfig

logger = logging.getLogger(__name__)


@dataclass
class NCAConfig:
    """Configuration for the neoCoder Agent."""

    # Model settings
    model: str = "claude-3-5-sonnet-20241022"  # Default fallback (should be loaded from settings)
    max_tokens: int = 8192
    temperature: float = 0.0
    
    # API settings (for ZenMux or other providers)
    api_key: str | None = None
    base_url: str | None = "https://zenmux.ai/api/v1"  # Default to ZenMux
    use_zenmux_format: bool = False  # Use ZenMux model names directly

    # Execution settings
    max_iterations: int = 100
    working_dir: str = "."
    enable_streaming: bool = True

    # Memory settings
    max_memory_tokens: int = 100000
    compression_threshold: float = 0.8
    rolling_window_size: int = 10

    # Tool settings
    bash_timeout: int = 120
    max_file_size: int = 1_000_000
    
    # File edit settings
    require_file_confirmation: bool = False  # Require user confirmation before file changes

    # Mode
    mode: Literal["coding", "debug", "refactor", "review"] = "coding"
    
    # Extended thinking settings
    thinking_budget: int | None = None
    thinking_effort: str | None = None  # "low"/"medium"/"high" — auto-calculates budget
    thinking_mode: str | None = None  # "auto", "enabled", "adaptive", "disabled"
    thinking_display: str | None = None  # "summarized", "omitted"
    
    # Sampling parameters
    top_p: float | None = None
    top_k: int | None = None
    stop_sequences: list[str] | None = None
    
    # Tool control
    tool_choice: str | None = None
    
    # Caching
    cache_control: dict | None = None
    
    # Metadata
    user_id: str | None = None
    
    # Reasoning settings (OpenAI / ZenMux)
    reasoning_effort: str | None = None
    reasoning_max_tokens: int | None = None

    # Sub-agent settings (loaded from specialized_agents config)
    architect_model: str | None = None
    architect_max_tokens: int | None = None
    architect_temperature: float | None = None
    architect_thinking_budget: int | None = None

    note_taker_model: str | None = None
    note_taker_max_tokens: int | None = None
    note_taker_temperature: float | None = None
    note_taker_thinking_budget: int | None = None

    # Hierarchical memory settings
    enable_hierarchical_memory: bool = True
    hierarchical_memory_dir: str | None = None  # Default: working_dir/.neoCoder/memory

    @classmethod
    def from_settings(
        cls,
        settings: Optional["Settings"] = None,
        agent_type: str = "coder",
        **overrides
    ) -> "NCAConfig":
        """
        Create NCAConfig from settings.json.
        
        Args:
            settings: Settings instance (loads default if None)
            agent_type: Type of specialized agent (coder, architect, etc.)
            **overrides: Override specific settings
            
        Returns:
            NCAConfig instance configured from settings
        """
        if settings is None:
            from neoCoder.config import load_settings
            settings = load_settings()
        
        # Get specialized agent configuration (including thinking_budget)
        model, temperature, max_tokens, thinking_budget_default = settings.get_specialized_agent_config(agent_type)
        logger.debug(f"from_settings: specialized_agent model={model}, agent_type={agent_type}")
        
        # If specialized agent config returns default, use default_model from settings
        if model == settings.agent_config.specialized_agents.coder_model:
            # This is the default, check if we should use default_model instead
            if hasattr(settings.agent_config, 'default_model'):
                model = settings.agent_config.default_model
                logger.debug(f"from_settings: using default_model={model}")
        
        # Apply model override if provided
        if "model" in overrides:
            model = overrides["model"]
            logger.info(f"from_settings: override model={model}")
        
        # Detect API settings based on model prefix
        api_key = None
        base_url = None
        thinking_budget = None
        thinking_effort = None
        thinking_mode = None
        thinking_display = None
        reasoning_effort = None
        reasoning_max_tokens = None
        top_p = None
        top_k = None
        stop_sequences = None
        tool_choice = None
        cache_control = None
        user_id = None
        
        use_zenmux_format = False
        
        if "/" in model:
            # Model has provider prefix - use ZenMux routing
            provider_prefix = model.split("/")[0].lower()
            
            # All provider-prefixed models go through ZenMux
            zenmux_config = settings.agent_config.zenmux
            api_key = zenmux_config.api_key or os.environ.get("ZENMUX_API_KEY")
            base_url = zenmux_config.base_url
            use_zenmux_format = True  # Enable ZenMux format for provider-prefixed models
            
            # Anthropic models get thinking_budget + thinking_effort
            # Priority: specialized_agent > anthropic config > default
            if provider_prefix == "anthropic" and zenmux_config.reasoning_enabled:
                anthropic_config = settings.agent_config.anthropic
                thinking_budget = thinking_budget_default or anthropic_config.thinking_budget
                thinking_effort = anthropic_config.thinking_effort
                thinking_mode = anthropic_config.thinking_mode
                thinking_display = anthropic_config.thinking_display
                top_p = anthropic_config.top_p
                top_k = anthropic_config.top_k
                stop_sequences = anthropic_config.stop_sequences
                tool_choice = anthropic_config.tool_choice
                user_id = anthropic_config.user_id
                if anthropic_config.cache_control_enabled:
                    cache_control = {"type": "ephemeral"}
                    if anthropic_config.cache_control_ttl:
                        cache_control["ttl"] = anthropic_config.cache_control_ttl
            
        elif "claude" in model.lower():
            # Anthropic model without prefix (direct Anthropic API)
            anthropic_config = settings.agent_config.anthropic
            api_key = anthropic_config.auth_token or os.environ.get("ANTHROPIC_AUTH_TOKEN") or os.environ.get("ANTHROPIC_API_KEY")
            base_url = anthropic_config.base_url
            if anthropic_config.thinking_enabled:
                # Priority: specialized_agent > anthropic config
                thinking_budget = thinking_budget_default or anthropic_config.thinking_budget
                thinking_effort = anthropic_config.thinking_effort
                thinking_mode = anthropic_config.thinking_mode
                thinking_display = anthropic_config.thinking_display
            top_p = anthropic_config.top_p
            top_k = anthropic_config.top_k
            stop_sequences = anthropic_config.stop_sequences
            tool_choice = anthropic_config.tool_choice
            user_id = anthropic_config.user_id
            if anthropic_config.cache_control_enabled:
                cache_control = {"type": "ephemeral"}
                if anthropic_config.cache_control_ttl:
                    cache_control["ttl"] = anthropic_config.cache_control_ttl
        
        # Create config with settings values
        logger.info(f"from_settings: final model={model}, api_key={'set' if api_key else 'None'}, base_url={base_url}")
        # Sub-agent settings from specialized config
        specialized = settings.agent_config.specialized_agents

        return cls(
            model=model,
            max_tokens=overrides.get("max_tokens", max_tokens),
            temperature=overrides.get("temperature", temperature),
            api_key=overrides.get("api_key", api_key),
            base_url=overrides.get("base_url", base_url),
            use_zenmux_format=overrides.get("use_zenmux_format", use_zenmux_format),
            thinking_budget=overrides.get("thinking_budget", thinking_budget),
            thinking_effort=overrides.get("thinking_effort", thinking_effort),
            thinking_mode=overrides.get("thinking_mode", thinking_mode),
            thinking_display=overrides.get("thinking_display", thinking_display),
            reasoning_effort=overrides.get("reasoning_effort", reasoning_effort),
            reasoning_max_tokens=overrides.get("reasoning_max_tokens", reasoning_max_tokens),
            top_p=overrides.get("top_p", top_p),
            top_k=overrides.get("top_k", top_k),
            stop_sequences=overrides.get("stop_sequences", stop_sequences),
            tool_choice=overrides.get("tool_choice", tool_choice),
            cache_control=overrides.get("cache_control", cache_control),
            user_id=overrides.get("user_id", user_id),
            max_iterations=overrides.get("max_iterations", settings.agent_config.max_iterations),
            enable_streaming=overrides.get("enable_streaming", settings.agent_config.anthropic.streaming),
            max_memory_tokens=overrides.get("max_memory_tokens", settings.agent_config.memory.max_context_length),
            compression_threshold=overrides.get("compression_threshold", settings.agent_config.memory.compression_threshold),
            # Architect sub-agent
            architect_model=overrides.pop("architect_model", None) or specialized.architect_model,
            architect_max_tokens=specialized.architect_max_tokens,
            architect_temperature=specialized.architect_temperature,
            architect_thinking_budget=specialized.architect_thinking_budget,
            # Note-taker sub-agent
            note_taker_model=overrides.pop("note_taker_model", None) or specialized.note_taker_model,
            note_taker_max_tokens=specialized.note_taker_max_tokens,
            note_taker_temperature=specialized.note_taker_temperature,
            note_taker_thinking_budget=specialized.note_taker_thinking_budget,
            **{k: v for k, v in overrides.items() if k not in [
                "model", "max_tokens", "temperature", "api_key", "base_url",
                "use_zenmux_format", "thinking_budget", "thinking_effort", "thinking_mode", "thinking_display",
                "reasoning_effort", "reasoning_max_tokens", "top_p", "top_k", "stop_sequences",
                "tool_choice", "cache_control", "user_id",
                "max_iterations", "enable_streaming", "max_memory_tokens", "compression_threshold",
            ]}
        )

    def to_orchestrator_config(self) -> OrchestratorConfig:
        """Convert to OrchestratorConfig."""
        llm_config = ClaudeClientConfig(
            model=self.model,
            max_tokens=self.max_tokens,
            temperature=self.temperature,
            api_key=self.api_key,
            base_url=self.base_url,
            use_zenmux_format=self.use_zenmux_format,
            thinking_budget=self.thinking_budget,
            thinking_effort=self.thinking_effort,
            thinking_mode=self.thinking_mode,
            thinking_display=self.thinking_display,
            reasoning_effort=self.reasoning_effort,
            top_p=self.top_p,
            top_k=self.top_k,
            stop_sequences=self.stop_sequences,
            tool_choice=self.tool_choice,
            cache_control=self.cache_control,
            user_id=self.user_id,
        )
        
        hierarchical_config = None
        if self.enable_hierarchical_memory:
            storage_dir = self.hierarchical_memory_dir or os.path.join(
                self.working_dir, ".neoCoder", "memory"
            )
            hierarchical_config = HierarchicalMemoryConfig(
                storage_dir=storage_dir,
                auto_persist=True,
            )
        
        return OrchestratorConfig(
            max_iterations=self.max_iterations,
            working_dir=self.working_dir,
            enable_streaming=self.enable_streaming,
            llm_config=llm_config,
            memory_config=WorkingMemoryConfig(
                max_tokens=self.max_memory_tokens,
                compression_threshold=self.compression_threshold,
                rolling_window_size=self.rolling_window_size,
            ),
            enable_token_tracking=bool(self.api_key),
            api_key=self.api_key,
            enable_hierarchical_memory=self.enable_hierarchical_memory,
            hierarchical_memory_config=hierarchical_config,
        )


# Preset configurations
PRESETS = {
    "default": NCAConfig(),
    "fast": NCAConfig(
        model="anthropic/claude-sonnet-4.5",
        max_tokens=4096,
        max_iterations=50,
    ),
    "thorough": NCAConfig(
        model="anthropic/claude-sonnet-4.5",
        max_tokens=16384,
        max_iterations=200,
        rolling_window_size=20,
    ),
    "workflow": NCAConfig(
        model="anthropic/claude-sonnet-4.5",
        max_tokens=16384,  # High token limit for complex multi-stage reasoning
        max_iterations=250,  # Extended iterations for 8-stage workflow
        temperature=0.0,  # Deterministic for consistent stage execution
        rolling_window_size=25,  # Larger window to maintain context across stages
        compression_threshold=0.85,  # Higher threshold to preserve stage outputs
    ),
    "zenmux": NCAConfig(
        base_url="https://zenmux.ai/api/v1",  # Correct ZenMux base URL
        model="anthropic/claude-sonnet-4.5",
        use_zenmux_format=False,
    ),
    "anthropic": NCAConfig(
        base_url=None,  # Use official Anthropic API
        model="claude-sonnet-4-5-20241022",
        use_zenmux_format=False,
    ),
}
