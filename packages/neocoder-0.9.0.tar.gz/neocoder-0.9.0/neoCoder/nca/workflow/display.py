"""
Rich terminal display components for workflow stages.

This module provides Rich-formatted display functions for workflow progress
indication, including stage headers, completion messages, and workflow summaries.
"""

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from .stages import Stage


def display_stage_header(stage: Stage, console: Console | None = None) -> None:
    """
    Display stage header with progress indicator.
    
    Shows a Rich-formatted panel with the stage name, description, and
    progress indicator (e.g., "Stage 3/7"). Uses cyan color for info.
    
    Args:
        stage: The Stage to display header for
        console: Optional Rich Console instance (creates new one if not provided)
    
    Example output:
        ╭─────────── 🔄 Stage 3 ────────────╮
        │ Implement                          │
        │ Execute the implementation plan    │
        │                                    │
        │ Stage 3/7                          │
        ╰────────────────────────────────────╯
    """
    if console is None:
        console = Console()
    
    # Build panel content with stage info
    content = (
        f"[bold cyan]{stage.name}[/bold cyan]\n"
        f"{stage.description}\n\n"
        f"[dim]Stage {stage.number}/{stage.total_stages}[/dim]"
    )
    
    panel = Panel(
        content,
        title=f"🔄 Stage {stage.number}",
        border_style="cyan",
    )
    
    console.print(panel)


def display_stage_completion(
    stage: Stage,
    success: bool,
    message: str | None = None,
    console: Console | None = None
) -> None:
    """
    Display stage completion status with status indicators.
    
    Shows a completion message with appropriate color coding:
    - Green (✓) for successful completion
    - Red (✗) for failure
    - Yellow (⚠) for warnings
    
    Args:
        stage: The Stage that completed
        success: Whether the stage completed successfully
        message: Optional additional message to display
        console: Optional Rich Console instance (creates new one if not provided)
    
    Example output:
        ✓ Implement complete
        ✗ Integration Test failed: Tests did not pass
    """
    if console is None:
        console = Console()
    
    if success:
        status_icon = "✓"
        color = "green"
        status_text = "complete"
    else:
        status_icon = "✗"
        color = "red"
        status_text = "failed"
    
    # Build completion message
    completion_msg = f"[{color}]{status_icon} {stage.name} {status_text}[/{color}]"
    
    if message:
        completion_msg += f": {message}"
    
    console.print(completion_msg)


def display_workflow_summary(
    workflow_manager,
    console: Console | None = None
) -> None:
    """
    Display final workflow summary with Rich Table.
    
    Shows a comprehensive table of all workflow stages with their status
    and outputs. Uses consistent color coding:
    - Cyan for stage names
    - Green for completed stages (✓)
    - Dim gray for pending stages (○)
    - Yellow for current stage (●)
    
    Args:
        workflow_manager: WorkflowManager instance with workflow state
        console: Optional Rich Console instance (creates new one if not provided)
    
    Example output:
        ┏━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━┓
        ║ Stage               ║ Status ║ Output                   ║
        ┡━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━┩
        │ Problem Breakdown   │ ✓      │ Identified 3 subtasks... │
        │ Plan                │ ✓      │ Created implementation...│
        │ Implement           │ ●      │ In progress...           │
        │ Integration Test    │ ○      │                          │
        │ Tech Stack Review   │ ○      │                          │
        │ Code Review         │ ○      │                          │
        │ Merge Preparation   │ ○      │                          │
        └─────────────────────┴────────┴──────────────────────────┘
    """
    if console is None:
        console = Console()
    
    # Create table with workflow summary
    table = Table(title="Workflow Summary", show_header=True, header_style="bold cyan")
    table.add_column("Stage", style="cyan", no_wrap=True)
    table.add_column("Status", justify="center")
    table.add_column("Output", style="dim")
    
    # Add row for each stage
    for i, stage in enumerate(workflow_manager.config.stages):
        # Determine status icon
        if i < workflow_manager.state.current_stage:
            status = "[green]✓[/green]"  # Completed
        elif i == workflow_manager.state.current_stage:
            status = "[yellow]●[/yellow]"  # Current
        else:
            status = "[dim]○[/dim]"  # Pending
        
        # Get stage output (truncated to 50 chars)
        output = workflow_manager.state.stage_outputs.get(stage.name, "")
        if isinstance(output, dict):
            # If output is a dict, show a summary
            output = f"{len(output)} items"
        elif isinstance(output, str) and len(output) > 50:
            output = output[:47] + "..."
        
        table.add_row(stage.name, status, str(output))
    
    console.print(table)
