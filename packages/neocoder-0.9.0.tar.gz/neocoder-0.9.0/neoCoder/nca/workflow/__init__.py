"""
Workflow preset module for neoCoder Agent.

This module implements a structured, multi-stage development process that guides
the agent through systematic stages from problem breakdown to merge preparation.
"""

from neoCoder.nca.workflow.stages import (
    Stage,
    WorkflowState,
    WorkflowConfig,
    StageLibrary,
    StageFailure,
)
from neoCoder.nca.workflow.manager import WorkflowManager
from neoCoder.nca.workflow.display import (
    display_stage_header,
    display_stage_completion,
    display_workflow_summary,
)

__all__ = [
    "Stage",
    "WorkflowState",
    "WorkflowConfig",
    "StageLibrary",
    "StageFailure",
    "WorkflowManager",
    "display_stage_header",
    "display_stage_completion",
    "display_workflow_summary",
]
