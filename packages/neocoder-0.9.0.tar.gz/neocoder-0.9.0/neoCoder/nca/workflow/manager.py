"""
Workflow manager for coordinating multi-stage development workflows.

This module implements the WorkflowManager class, which tracks workflow state,
manages stage transitions, and coordinates the execution of workflow stages
within the neoCoder Agent orchestrator loop.
"""

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .stages import Stage, WorkflowState, WorkflowConfig, StageFailure

logger = logging.getLogger(__name__)


class WorkflowManager:
    """
    Manages workflow stage execution and transitions.
    
    The WorkflowManager coordinates the execution of multi-stage workflows by:
    - Tracking the current stage and workflow state
    - Generating stage-specific prompts for the LLM
    - Detecting stage completion from LLM output
    - Managing transitions between stages
    - Persisting and restoring workflow state
    
    The manager integrates with the orchestrator loop through callbacks and
    prompt enhancement, without requiring modifications to the core orchestrator.
    
    Attributes:
        config: WorkflowConfig defining stages and execution settings
        state: Current WorkflowState (None if workflow not started)
    """
    
    def __init__(self, config: WorkflowConfig):
        """
        Initialize the workflow manager.
        
        Args:
            config: WorkflowConfig with stages and execution settings
        """
        self.config = config
        self.state: WorkflowState | None = None
        self.extension_usage: dict[str, list[str]] = {}  # Track extensions used per stage
    
    def start_workflow(self, task: str) -> None:
        """
        Initialize workflow for a new task.
        
        Creates a new WorkflowState with the first stage active and saves
        it to disk if persistence is enabled.
        
        Args:
            task: The task description provided by the user
        """
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self.state = WorkflowState(
            current_stage=0,  # Start at first stage (0-indexed)
            stage_outputs={},
            task_description=task,
            started_at=now,
            updated_at=now,
            failures=[],
            retry_count=0,
            stage_started_at=now,
        )
        
        if self.config.persist_state:
            self.save_state()
    
    def get_current_stage(self) -> Stage:
        """
        Get the currently active stage.
        
        Returns:
            The Stage object for the current stage
            
        Raises:
            RuntimeError: If workflow has not been started
            IndexError: If current_stage index is out of bounds
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        if self.state.current_stage >= len(self.config.stages):
            raise IndexError(
                f"Current stage index {self.state.current_stage} is out of bounds. "
                f"Workflow has {len(self.config.stages)} stages."
            )
        
        return self.config.stages[self.state.current_stage]
    
    def get_stage_prompt(self) -> str:
        """
        Generate system prompt for current stage.

        Creates a comprehensive prompt that includes the stage's objectives,
        description, and guidance, formatted for optimal LLM comprehension.
        The prompt provides clear context about the current stage and what
        is expected from the LLM.

        Returns:
            System prompt string for the current stage, including:
            - Stage name and progress indicator
            - Stage description
            - Specific objectives
            - Detailed guidance from prompt template

        Raises:
            RuntimeError: If workflow has not been started
        """
        current_stage = self.get_current_stage()

        # Build comprehensive prompt with stage context
        prompt_parts = [
            f"# {current_stage.name} (Stage {current_stage.number}/{current_stage.total_stages})",
            "",
            f"## Description",
            current_stage.description,
            "",
            f"## Objectives",
        ]

        # Add numbered objectives
        for i, objective in enumerate(current_stage.objectives, 1):
            prompt_parts.append(f"{i}. {objective}")

        prompt_parts.extend([
            "",
            "## Guidance",
            current_stage.prompt_template,
        ])

        return "\n".join(prompt_parts)

    
    def detect_stage_completion(self, llm_output: str) -> bool:
        """
        Detect if current stage is complete based on LLM output.
        
        Checks if any of the stage's completion markers appear in the
        LLM's output text (case-insensitive).
        
        Args:
            llm_output: The text output from the LLM
            
        Returns:
            True if stage completion is detected, False otherwise
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        current_stage = self.get_current_stage()
        llm_output_lower = llm_output.lower()
        
        # Check if any completion marker appears in the output
        for marker in current_stage.completion_markers:
            if marker.lower() in llm_output_lower:
                return True
        
        return False
    
    def transition_to_next_stage(self) -> bool:
        """
        Move to next stage in the workflow.
        
        Increments the current stage index and updates the workflow state.
        If persistence is enabled, saves the updated state to disk.
        Resets retry count when transitioning to a new stage.
        
        Returns:
            True if transition was successful, False if workflow is complete
            (no more stages remaining)
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        # Check if there are more stages
        if self.state.current_stage >= len(self.config.stages) - 1:
            # Already at last stage, workflow is complete
            return False
        
        # Move to next stage
        self.state.current_stage += 1
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self.state.updated_at = now
        self.state.stage_started_at = now
        self.state.retry_count = 0  # Reset retry count for new stage
        
        # Persist state if enabled
        if self.config.persist_state:
            self.save_state()
        
        return True
    
    def save_state(self) -> None:
        """
        Persist workflow state to disk.
        
        Saves the current WorkflowState as JSON to the configured state file.
        Creates parent directories if they don't exist.
        
        Raises:
            RuntimeError: If workflow has not been started
            OSError: If file cannot be written
        """
        if self.state is None:
            raise RuntimeError("No workflow state to save. Call start_workflow() first.")
        
        # Ensure parent directory exists
        state_path = Path(self.config.state_file)
        state_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Write state as JSON
        with open(state_path, 'w', encoding='utf-8') as f:
            json.dump(self.state.to_dict(), f, indent=2)
    
    def load_state(self) -> bool:
        """
        Restore workflow state from disk.
        
        Loads WorkflowState from the configured state file if it exists.
        
        Returns:
            True if state was successfully loaded, False if state file doesn't exist
            
        Raises:
            json.JSONDecodeError: If state file contains invalid JSON
            KeyError: If state file is missing required fields
        """
        state_path = Path(self.config.state_file)
        
        if not state_path.exists():
            return False
        
        # Load state from JSON
        with open(state_path, 'r', encoding='utf-8') as f:
            state_data = json.load(f)
        
        self.state = WorkflowState.from_dict(state_data)
        return True
    
    def reset_workflow(self) -> None:
        """
        Clear workflow state and start fresh.
        
        Removes the workflow state from memory and deletes the state file
        from disk if it exists.
        """
        self.state = None
        
        # Delete state file if it exists
        state_path = Path(self.config.state_file)
        if state_path.exists():
            os.remove(state_path)
    
    def record_stage_failure(self, error_message: str) -> None:
        """
        Record a failure for the current stage.
        
        Creates a StageFailure record and adds it to the workflow state.
        Increments the retry count for the current stage.
        
        Args:
            error_message: Description of the failure
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        current_stage = self.get_current_stage()
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        
        failure = StageFailure(
            stage_name=current_stage.name,
            stage_number=current_stage.number,
            error_message=error_message,
            timestamp=now,
            retry_count=self.state.retry_count,
        )
        
        self.state.failures.append(failure.to_dict())
        self.state.retry_count += 1
        self.state.updated_at = now
        
        # Persist state if enabled
        if self.config.persist_state:
            self.save_state()
    
    def can_retry_stage(self) -> bool:
        """
        Check if the current stage can be retried.
        
        Returns True if the retry count is below the maximum retry limit.
        
        Returns:
            True if stage can be retried, False if max retries reached
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        return self.state.retry_count < self.config.max_retries
    
    def retry_current_stage(self) -> None:
        """
        Retry the current stage.
        
        Resets the stage start time but keeps the retry count.
        This allows the stage to be executed again with the same configuration.
        
        Raises:
            RuntimeError: If workflow has not been started
            ValueError: If max retries have been reached
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        if not self.can_retry_stage():
            raise ValueError(
                f"Cannot retry stage: max retries ({self.config.max_retries}) reached. "
                f"Current retry count: {self.state.retry_count}"
            )
        
        # Reset stage start time for retry
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self.state.stage_started_at = now
        self.state.updated_at = now
        
        # Persist state if enabled
        if self.config.persist_state:
            self.save_state()
    
    def rollback_to_previous_stage(self) -> bool:
        """
        Rollback to the previous stage in the workflow.
        
        Decrements the current stage index and resets retry count.
        This is useful when a stage fails and needs to return to a previous
        stage for corrections.
        
        Returns:
            True if rollback was successful, False if already at first stage
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        # Check if we can rollback
        if self.state.current_stage <= 0:
            # Already at first stage, cannot rollback
            return False
        
        # Move to previous stage
        self.state.current_stage -= 1
        now = datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        self.state.updated_at = now
        self.state.stage_started_at = now
        self.state.retry_count = 0  # Reset retry count for rolled-back stage
        
        # Persist state if enabled
        if self.config.persist_state:
            self.save_state()
        
        return True
    
    def is_stage_timeout(self) -> bool:
        """
        Check if the current stage has exceeded its timeout.
        
        Returns True if the stage has been running longer than the configured
        timeout. Returns False if no timeout is configured (timeout = 0) or
        if stage start time is not set.
        
        Returns:
            True if stage has timed out, False otherwise
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        # No timeout configured
        if self.config.stage_timeout_minutes <= 0:
            return False
        
        # Stage start time not set
        if self.state.stage_started_at is None:
            return False
        
        # Calculate elapsed time
        stage_start = datetime.fromisoformat(self.state.stage_started_at.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        elapsed_minutes = (now - stage_start).total_seconds() / 60
        
        return elapsed_minutes > self.config.stage_timeout_minutes
    
    def get_failure_summary(self) -> dict[str, Any]:
        """
        Get a summary of all failures that have occurred in the workflow.
        
        Returns:
            Dictionary containing failure statistics and details
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        # Group failures by stage
        failures_by_stage: dict[str, list[dict[str, Any]]] = {}
        for failure_dict in self.state.failures:
            stage_name = failure_dict["stage_name"]
            if stage_name not in failures_by_stage:
                failures_by_stage[stage_name] = []
            failures_by_stage[stage_name].append(failure_dict)
        
        return {
            "total_failures": len(self.state.failures),
            "current_retry_count": self.state.retry_count,
            "max_retries": self.config.max_retries,
            "can_retry": self.can_retry_stage(),
            "failures_by_stage": failures_by_stage,
        }

    def track_extension_usage(self, extension_name: str) -> None:
        """
        Track that an extension was used during the current stage.
        
        Records which extensions are invoked during each stage for validation
        and debugging purposes.
        
        Args:
            extension_name: Name of the extension that was used
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        current_stage = self.get_current_stage()
        stage_key = f"{current_stage.number}_{current_stage.name}"
        
        if stage_key not in self.extension_usage:
            self.extension_usage[stage_key] = []
        
        if extension_name not in self.extension_usage[stage_key]:
            self.extension_usage[stage_key].append(extension_name)
    
    def get_stage_extension_usage(self, stage_name: str | None = None) -> list[str]:
        """
        Get list of extensions used during a specific stage.
        
        Args:
            stage_name: Name of the stage (uses current stage if None)
            
        Returns:
            List of extension names used during the stage
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        if stage_name is None:
            current_stage = self.get_current_stage()
            stage_name = current_stage.name
        
        # Find the stage key
        for key in self.extension_usage:
            if key.endswith(f"_{stage_name}"):
                return self.extension_usage[key]
        
        return []
    
    def validate_required_extensions(self) -> dict[str, Any]:
        """
        Validate that required extensions were used during appropriate stages.
        
        Checks that:
        - Implement stage used file operations (file_read, file_write, file_edit)
        - Integration Test stage used bash extension
        - Code Review stage accessed code-review-rules.json
        
        Returns:
            Dictionary with validation results:
            - valid: bool indicating if all requirements met
            - missing: dict mapping stage names to missing extensions
            - used: dict mapping stage names to extensions used
            
        Raises:
            RuntimeError: If workflow has not been started
        """
        if self.state is None:
            raise RuntimeError("Workflow has not been started. Call start_workflow() first.")
        
        # Define required extensions per stage
        required_extensions = {
            "Implement": ["file_read", "file_write", "file_edit"],
            "Integration Test": ["bash"],
            "Code Review": ["file_read"],  # Should read code-review-rules.json
        }
        
        validation_result = {
            "valid": True,
            "missing": {},
            "used": {},
        }
        
        # Check each stage that has requirements
        for stage_name, required in required_extensions.items():
            used = self.get_stage_extension_usage(stage_name)
            validation_result["used"][stage_name] = used
            
            # Check if at least one required extension was used
            has_required = any(ext in used for ext in required)
            
            if not has_required:
                validation_result["valid"] = False
                validation_result["missing"][stage_name] = required
        
        return validation_result

    @staticmethod
    def load_custom_config(config_path: str = ".neoCoder/workflow_config.json") -> WorkflowConfig | None:
        """
        Load custom workflow configuration from JSON file.
        
        Supports:
        - Enabling/disabling individual stages
        - Reordering stages
        - Adding custom stages with prompts and validation
        - Overriding workflow settings
        
        Args:
            config_path: Path to workflow configuration file
            
        Returns:
            WorkflowConfig if custom config exists and is valid, None otherwise
            
        Raises:
            json.JSONDecodeError: If config file contains invalid JSON
            ValueError: If config file has invalid structure
        """
        from .stages import StageLibrary
        
        config_file = Path(config_path)
        
        if not config_file.exists():
            return None
        
        # Load config from JSON
        with open(config_file, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
        
        # Get default stages as a reference
        default_stages = {
            "Brainstorming": StageLibrary.brainstorming(),
            "Plan": StageLibrary.plan(),
            "Implement": StageLibrary.implement(),

            "Integration Test": StageLibrary.integration_test(),
            "Tech Stack Review": StageLibrary.tech_stack_review(),
            "Code Review": StageLibrary.code_review(),
            "Merge Preparation": StageLibrary.merge_prep(),
        }
        
        # Build stage list based on config
        stages = []
        stage_configs = config_data.get("stages", [])
        
        for i, stage_config in enumerate(stage_configs, 1):
            stage_name = stage_config.get("name")
            enabled = stage_config.get("enabled", True)
            
            if not enabled:
                continue
            
            # Use default stage if available
            if stage_name in default_stages:
                stage = default_stages[stage_name]
                # Update stage number based on position in custom config
                stage.number = i
                stage.total_stages = len([s for s in stage_configs if s.get("enabled", True)])
                
                # Override requires_approval if specified
                if "requires_approval" in stage_config:
                    stage.requires_user_approval = stage_config["requires_approval"]
                
                stages.append(stage)
            else:
                # Custom stage - create from config
                from .stages import Stage
                
                stage = Stage(
                    name=stage_name,
                    number=i,
                    total_stages=len([s for s in stage_configs if s.get("enabled", True)]),
                    description=stage_config.get("description", ""),
                    objectives=stage_config.get("objectives", []),
                    prompt_template=stage_config.get("prompt_template", ""),
                    completion_markers=stage_config.get("completion_markers", []),
                    validation_rules=[],  # Custom validation not supported yet
                    requires_user_approval=stage_config.get("requires_approval", True),
                )
                stages.append(stage)
        
        # Create WorkflowConfig with custom settings
        return WorkflowConfig(
            stages=stages,
            enable_auto_transitions=config_data.get("auto_transitions", True),
            require_user_approval=config_data.get("require_user_approval", True),
            persist_state=config_data.get("persist_state", True),
            state_file=config_data.get("state_file", ".neoCoder/workflow_state.json"),
            max_retries=config_data.get("max_retries", 3),
            stage_timeout_minutes=config_data.get("stage_timeout_minutes", 60),
        )
    
    @staticmethod
    def get_config_with_fallback(custom_config_path: str = ".neoCoder/workflow_config.json") -> WorkflowConfig:
        """
        Get workflow configuration with fallback to defaults.
        
        Attempts to load custom configuration from file. If custom config
        doesn't exist or is invalid, falls back to default configuration.
        
        Args:
            custom_config_path: Path to custom workflow configuration file
            
        Returns:
            WorkflowConfig (custom if available, default otherwise)
        """
        from .stages import StageLibrary
        
        # Try to load custom config
        try:
            custom_config = WorkflowManager.load_custom_config(custom_config_path)
            if custom_config is not None:
                return custom_config
        except (json.JSONDecodeError, ValueError, KeyError) as e:
            logger.warning("Failed to load custom workflow config: %s", e)
            logger.warning("Falling back to default workflow configuration.")
        
        # Fall back to default configuration
        return WorkflowConfig(
            stages=StageLibrary.get_default_workflow(),
            enable_auto_transitions=True,
            require_user_approval=True,
            persist_state=True,
            state_file=".neoCoder/workflow_state.json",
            max_retries=3,
            stage_timeout_minutes=60,
        )
