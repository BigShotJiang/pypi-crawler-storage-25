"""
Tech Stack Analyzer — passes codebase discovery results to the LLM
and instructs it to identify the full stack + generate best practices
from its own pre-trained knowledge.

No static best-practices dictionaries, no regex pattern matching.
The LLM is better at both tasks than any hardcoded list.

Flow:
  1. Collect raw tool names from ProjectDiscovery (codebase scan).
  2. Build a prompt block that lists what was auto-detected and
     instructs the LLM to complete the picture + generate practices.

Consumer:
  - ``build_tech_stack_context()`` → injected into the task before Brainstorming.
"""

from __future__ import annotations

import logging
from typing import Sequence

logger = logging.getLogger(__name__)

# =====================================================================
# Prompt blocks — injected into the task context
# =====================================================================

_TECH_STACK_INSTRUCTION = """\
## Tech Stack Discovery & Best Practices (MANDATORY)

{discovery_section}

### What YOU must do

1. **Read the task** and identify every technology, framework, library,
   database, ORM, API style, Architecture style, Design Patterns, Integration Patterns, build tool, and deployment target mentioned.
2. **Inspect the codebase** (`glob` / `grep` on config files: package.json,
   pyproject.toml, pom.xml, Cargo.toml, Gemfile, requirements.txt,
   Dockerfile, docker-compose.yml, .eslintrc, tsconfig.json, etc.)
   to discover technologies not mentioned in the task.
3. **Confirm exact versions** where determinable — best practices are
   version-sensitive (e.g. React 18 vs 19, SQLAlchemy 1.4 vs 2.0).
4. **Merge** auto-detected tools (above) + task-mentioned + codebase-inspected
   into a single authoritative tech stack list.
5. **For each technology** produce 2-3 actionable best practices, prioritised by impact on THIS specific task.
   Do NOT recite generic checklists — focus on what matters here.
6. **For every interacting pair** (ORM + DB, framework + Docker,
   language + test runner, etc.) add 2–3 integration-specific practices
   (async drivers, layer caching, session/fixture wiring, etc.).

### Required output format (in `thinking`)
```
Tech Stack:
- <Tech> <version>: <practice 1>; <practice 2>; <practice 3>
- ...
Architecture style:
- <Tech A> + <Tech B>: <integration practice 1>; <practice 2>
- ...
Integration:
- <Tech A> + <Tech B>: <integration practice 1>; <practice 2>
- ...
```
These best practices become **binding constraints** for Brainstorming and Implement stages.
"""


# =====================================================================
# Helpers
# =====================================================================

def _describe_discovery(discovery_results: Sequence[object]) -> str:
    """Format ProjectDiscovery results into a readable list."""
    if not discovery_results:
        return ""

    file_names: list[str] = []
    seen: set[str] = set()
    for result in discovery_results:
        # Support both old format (tool_name) and new format (name)
        name = getattr(result, "name", None) or getattr(result, "tool_name", None)
        if name and name not in seen:
            file_names.append(name)
            seen.add(name)

    if not file_names:
        return ""

    lines = ["**Project files detected:** " + ", ".join(file_names)]
    lines.append(
        "(These are key project files found by scanning the project root. "
        "Analyze them to determine the full tech stack and best practices.)"
    )
    return "\n".join(lines)


# =====================================================================
# Main entry point
# =====================================================================

def build_tech_stack_context(
    task: str = "",
    discovery_results: Sequence[object] | None = None,
) -> str:
    """
    Build a prompt block that tells the LLM what was auto-detected and
    instructs it to complete the tech stack + generate best practices.

    Returns:
        Markdown string ready to inject into agent prompt.
        Empty string if there is nothing to inject (no discovery results
        AND no task text — though the Brainstorming prompt already handles
        the pure-task case).
    """
    discovery_section = _describe_discovery(discovery_results or [])

    # If nothing was discovered from the codebase, still inject the
    # instruction — the LLM will extract the stack from the task text
    # and by inspecting the codebase itself.
    if not discovery_section and not task:
        return ""

    if not discovery_section:
        discovery_section = (
            "No tools were auto-detected from the codebase yet. "
            "You must discover the full stack yourself by inspecting "
            "config files and project structure."
        )

    result = _TECH_STACK_INSTRUCTION.format(
        discovery_section=discovery_section,
    )

    logger.debug(
        "Tech stack context built: %d chars (discovery: %s)",
        len(result),
        bool(discovery_results),
    )
    return result


# Allow quick inspection:  python -m neoCoder.nca.tech_stack_analyzer
if __name__ == "__main__":
    # Simulate with no discovery (task-only mode)
    print("=== No discovery ===")
    print(build_tech_stack_context(task="Build a FastAPI + PostgreSQL app"))
    print()

    # Simulate with mock discovery results
    class _MockResult:
        def __init__(self, name: str) -> None:
            self.tool_name = name

    mock_results = [_MockResult("poetry/pip"), _MockResult("pytest"), _MockResult("ruff")]
    print("=== With discovery ===")
    print(build_tech_stack_context(task="Add Redis caching", discovery_results=mock_results))
