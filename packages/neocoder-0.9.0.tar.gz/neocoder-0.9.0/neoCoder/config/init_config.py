"""
Configuration initialization utility for neoCoder.

Creates example configuration files in the specified directory.
"""
import json
from pathlib import Path
from typing import Optional


class ConfigInitializer:
    """Utility class to create example configuration files."""
    
    @staticmethod
    def get_example_settings() -> dict:
        """Get example settings.json content."""
        return {
            "name": "neoCoder",
            "description": "NeoCoder Agent with advanced features",
            "default_model": "claude-opus-4-6",
            "anthropic": {
                "auth_token": None,
                "base_url": "",
                "timeout": 60,
                "max_retries": 3,
                "streaming": True,
                "thinking_enabled": True,
                "thinking_effort": "high",
                "extra_params": {}
            },
            "openai": {
                "api_key": None,
                "base_url": "",
                "timeout": 60,
                "max_retries": 3,
                "streaming": True,
                "reasoning_effort": "high",
                "reasoning_enabled": True,
                "reasoning_max_tokens": None,
                "reasoning_exclude": False,
                "top_p": None,
                "frequency_penalty": None,
                "presence_penalty": None,
                "stop": None,
                "web_search_enabled": False,
                "extra_params": {}
            },
            "zenmux": {
                "api_key": "",
                "base_url": "",
                "timeout": 60,
                "max_retries": 3,
                "max_context_tokens": 200000,
                "max_output_tokens": 64000,
                "streaming_enabled": True,
                "streaming_chunk_size": 1024,
                "streaming_timeout": 120,
                "structured_output_enabled": True,
                "strict_validation": True,
                "tool_calling_enabled": True,
                "max_tool_calls": 10,
                "tool_timeout": 30,
                "auto_execute_tools": True,
                "reasoning_enabled": True,
                "default_reasoning_effort": "high",
                "default_reasoning_max_tokens": 8192,
                "adaptive_reasoning": True,
                "log_level": "INFO",
                "log_requests": True,
                "log_responses": False
            },
            "semantic_compression": {
                "enabled": True,
                "compression_ratio": 0.5,
                "min_chunk_size": 100,
                "max_chunk_size": 1000,
                "similarity_threshold": 0.8,
                "preserve_important": True,
                "embedding_model": "all-MiniLM-L6-v2"
            },
            "tool_selection": {
                "strategy": "semantic",
                "max_tools": 10,
                "similarity_threshold": 0.7,
                "use_embeddings": True,
                "cache_enabled": True
            },
            "specialized_agents": {
                "coder_model": "claude-opus-4-6",
                "architect_model": "claude-sonnet-4-6",
                "note_taker_model": "claude-sonnet-4-6",
                "coder_temperature": 0.3,
                "architect_temperature": 0.7,
                "note_taker_temperature": 0.3,
                "coder_max_tokens": 24000,
                "architect_max_tokens": 8192,
                "note_taker_max_tokens": 4096,
                "coder_thinking_budget": 4800,
                "architect_thinking_budget": 38000,
                "note_taker_thinking_budget": 0
            },
            "memory": {
                "enabled": True,
                "max_context_length": 100000,
                "compression_enabled": True,
                "compression_threshold": 0.8,
                "adaptive_enabled": True,
                "persistence_enabled": False,
                "persistence_path": None
            },
            "cache": {
                "enabled": True,
                "max_size": 1000,
                "ttl": 3600,
                "code_cache_enabled": True,
                "semantic_cache_enabled": True
            },
            "monitoring": {
                "enabled": True,
                "show_startup_info": True,
                "show_usage_updates": True,
                "cache_ttl": 3600,
                "api_timeout": 5,
                "display_format": "box"
            },
            "tools_enabled": True,
            "reasoning_enabled": True,
            "max_iterations": 100,
            "debug": False,
            "log_level": "INFO"
        }
    
    @staticmethod
    def get_example_models() -> dict:
        """Get example models.json content."""
        return {
            "models": {
                "anthropic/claude-opus-4": {
                    "name": "Claude Opus 4",
                    "provider": "anthropic",
                    "max_context_tokens": 200000,
                    "max_output_tokens": 16384,
                    "reasoning_tokens": 100000,
                    "reasoning_effort": "high",
                    "supports_vision": True,
                    "supports_tools": True,
                    "supports_streaming": True
                },
                "anthropic/claude-sonnet-4.5": {
                    "name": "Claude Sonnet 4.5",
                    "provider": "anthropic",
                    "max_context_tokens": 200000,
                    "max_output_tokens": 16384,
                    "reasoning_tokens": 100000,
                    "reasoning_effort": "medium",
                    "supports_vision": True,
                    "supports_tools": True,
                    "supports_streaming": True
                },
                "anthropic/claude-sonnet-4": {
                    "name": "Claude Sonnet 4",
                    "provider": "anthropic",
                    "max_context_tokens": 200000,
                    "max_output_tokens": 8192,
                    "reasoning_tokens": None,
                    "reasoning_effort": None,
                    "supports_vision": True,
                    "supports_tools": True,
                    "supports_streaming": True
                },
                "anthropic/claude-haiku-4": {
                    "name": "Claude Haiku 4",
                    "provider": "anthropic",
                    "max_context_tokens": 200000,
                    "max_output_tokens": 8192,
                    "reasoning_tokens": None,
                    "reasoning_effort": None,
                    "supports_vision": True,
                    "supports_tools": True,
                    "supports_streaming": True
                }
            }
        }
    
    @staticmethod
    def create_example_config(target_dir: Optional[Path] = None) -> Path:
        """
        Create example configuration files in the target directory.
        
        Args:
            target_dir: Directory to create config files in.
                       Defaults to ~/.neoCoder
        
        Returns:
            Path to the created configuration directory
        """
        if target_dir is None:
            target_dir = Path.home() / ".neoCoder"
        else:
            target_dir = Path(target_dir)
        
        # Create directory
        target_dir.mkdir(parents=True, exist_ok=True)
        
        # Create settings.json
        settings_path = target_dir / "settings.json"
        if not settings_path.exists():
            with open(settings_path, 'w', encoding='utf-8') as f:
                json.dump(ConfigInitializer.get_example_settings(), f, indent=2)
            print(f"✓ Created: {settings_path}")
        else:
            print(f"- Exists: {settings_path}")
        
        # Create models.json
        models_path = target_dir / "models.json"
        if not models_path.exists():
            with open(models_path, 'w', encoding='utf-8') as f:
                json.dump(ConfigInitializer.get_example_models(), f, indent=2)
            print(f"✓ Created: {models_path}")
        else:
            print(f"- Exists: {models_path}")
        
        # Create notes directory
        notes_dir = target_dir / "notes"
        notes_dir.mkdir(exist_ok=True)
        
        # Create README in notes directory
        readme_path = notes_dir / "README.md"
        if not readme_path.exists():
            with open(readme_path, 'w', encoding='utf-8') as f:
                f.write("# neoCoder Notes\n\n")
                f.write("This directory stores persistent notes from agent sessions.\n\n")
                f.write("Notes are automatically created by the Note-Taker agent and include:\n")
                f.write("- Hindsight notes (lessons learned from errors)\n")
                f.write("- Session summaries\n")
                f.write("- Code patterns and solutions\n")
            print(f"✓ Created: {readme_path}")
        
        return target_dir
    
    @staticmethod
    def init_config_interactive():
        """Interactive configuration initialization."""
        print("=" * 60)
        print("neoCoder Configuration Initialization")
        print("=" * 60)
        print()
        
        # Ask for target directory
        default_dir = Path.home() / ".neoCoder"
        print(f"Default configuration directory: {default_dir}")
        response = input("Use default location? (y/n): ").strip().lower()
        
        if response == 'y':
            target_dir = default_dir
        else:
            custom_path = input("Enter custom path: ").strip()
            target_dir = Path(custom_path)
        
        print()
        print(f"Creating configuration in: {target_dir}")
        print()
        
        # Create config
        created_dir = ConfigInitializer.create_example_config(target_dir)
        
        print()
        print("=" * 60)
        print("Configuration created successfully!")
        print("=" * 60)
        print()
        print("Next steps:")
        print("1. Edit settings.json to add your API keys:")
        print(f"   - Anthropic: agent.anthropic.auth_token")
        print(f"   - ZenMux: agent.zenmux.api_key")
        print()
        print("2. Or set environment variables:")
        print("   export ANTHROPIC_API_KEY=your-key")
        print("   export ZENMUX_API_KEY=your-key")
        print()
        print(f"Configuration location: {created_dir}")
        print()


def main():
    """Main entry point for config initialization."""
    import sys
    
    if len(sys.argv) > 1:
        # Non-interactive mode with custom path
        target_dir = Path(sys.argv[1])
        print(f"Creating configuration in: {target_dir}")
        ConfigInitializer.create_example_config(target_dir)
    else:
        # Interactive mode
        ConfigInitializer.init_config_interactive()


if __name__ == "__main__":
    main()
