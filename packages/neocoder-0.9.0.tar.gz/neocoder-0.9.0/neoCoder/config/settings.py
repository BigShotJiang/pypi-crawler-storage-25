"""Settings management for neoCoder."""

import json
import os
import shutil
from pathlib import Path
from typing import Optional, Dict, Any
import logging

from .models import (
    AgentConfig,
    AnthropicConfig,
    ZenMuxConfig,
    SpecializedAgentConfig,
    MemoryConfig,
    CacheConfig,
    MonitoringConfig,
)

logger = logging.getLogger(__name__)


class Settings:
    """Settings manager for neoCoder."""
    
    def __init__(self, config_path: Optional[Path] = None):
        """Initialize settings.
        
        Args:
            config_path: Path to settings.json file
        """
        self.config_path = config_path or self._find_config_path()
        self.agent_config: Optional[AgentConfig] = None
        self._raw_config: Dict[str, Any] = {}
        
        if self.config_path and self.config_path.exists():
            self.load()
        else:
            logger.warning(f"Config file not found: {self.config_path}")
            self.agent_config = AgentConfig()
    
    def _find_config_path(self) -> Path:
        """Find settings.json in standard locations.
        
        Priority:
        1. NEOCODER_CONFIG environment variable
        2. ~/.neoCoder/settings.json in home directory
        """
        env_path = os.getenv("NEOCODER_CONFIG")
        if env_path:
            return Path(env_path)

        return Path.home() / ".neoCoder" / "settings.json"
    
    def load(self) -> None:
        """Load settings from JSON file."""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                self._raw_config = json.load(f)
            
            self.agent_config = self._parse_config(self._raw_config)
            logger.info(f"Loaded settings from {self.config_path}")
            
        except Exception as e:
            logger.error(f"Failed to load settings: {e}")
            self.agent_config = AgentConfig()
    
    def _parse_config(self, config: Dict[str, Any]) -> AgentConfig:
        """Parse configuration dictionary into AgentConfig.
        
        Args:
            config: Raw configuration dictionary
            
        Returns:
            Parsed AgentConfig
        """
        # Parse Anthropic config
        anthropic_data = config.get("anthropic", {})
        anthropic_config = AnthropicConfig(
            auth_token=anthropic_data.get("auth_token") or os.getenv("ANTHROPIC_AUTH_TOKEN"),
            base_url=anthropic_data.get("base_url") or os.getenv("ANTHROPIC_BASE_URL"),
            timeout=anthropic_data.get("timeout", 60),
            max_retries=anthropic_data.get("max_retries", 3),
            streaming=anthropic_data.get("streaming", True),
            thinking_enabled=anthropic_data.get("thinking_enabled", True),
            thinking_budget=anthropic_data.get("thinking_budget", 10000),
            thinking_effort=anthropic_data.get("thinking_effort"),
            thinking_mode=anthropic_data.get("thinking_mode"),
            thinking_display=anthropic_data.get("thinking_display"),
            top_p=anthropic_data.get("top_p"),
            top_k=anthropic_data.get("top_k"),
            stop_sequences=anthropic_data.get("stop_sequences"),
            tool_choice=anthropic_data.get("tool_choice"),
            cache_control_enabled=anthropic_data.get("cache_control_enabled", False),
            cache_control_ttl=anthropic_data.get("cache_control_ttl"),
            user_id=anthropic_data.get("user_id"),
            extra_params=anthropic_data.get("extra_params", {}),
        )
        
        # Parse ZenMux config
        zenmux_data = config.get("zenmux", {})
        zenmux_config = ZenMuxConfig(
            api_key=zenmux_data.get("api_key") or os.getenv("ZENMUX_API_KEY"),
            base_url=zenmux_data.get("base_url", "https://zenmux.ai/api/v1"),
            timeout=zenmux_data.get("timeout", 60),
            max_retries=zenmux_data.get("max_retries", 3),
            max_context_tokens=zenmux_data.get("max_context_tokens"),
            max_output_tokens=zenmux_data.get("max_output_tokens"),
            streaming_enabled=zenmux_data.get("streaming_enabled", True),
            streaming_chunk_size=zenmux_data.get("streaming_chunk_size", 1024),
            streaming_timeout=zenmux_data.get("streaming_timeout", 120),
            structured_output_enabled=zenmux_data.get("structured_output_enabled", True),
            strict_validation=zenmux_data.get("strict_validation", True),
            tool_calling_enabled=zenmux_data.get("tool_calling_enabled", True),
            max_tool_calls=zenmux_data.get("max_tool_calls", 10),
            tool_timeout=zenmux_data.get("tool_timeout", 30),
            auto_execute_tools=zenmux_data.get("auto_execute_tools", True),
            reasoning_enabled=zenmux_data.get("reasoning_enabled", True),
            default_reasoning_effort=zenmux_data.get("default_reasoning_effort", "medium"),
            default_reasoning_max_tokens=zenmux_data.get("default_reasoning_max_tokens", 8192),
            adaptive_reasoning=zenmux_data.get("adaptive_reasoning", True),
            log_level=zenmux_data.get("log_level", "INFO"),
            log_requests=zenmux_data.get("log_requests", True),
            log_responses=zenmux_data.get("log_responses", False),
        )
        
        # Parse Specialized Agents config
        specialized_data = config.get("specialized_agents", {})
        specialized_config = SpecializedAgentConfig(
            coder_model=specialized_data.get("coder_model", "claude-3-5-sonnet-20241022"),
            architect_model=specialized_data.get("architect_model", "claude-3-5-sonnet-20241022"),
            note_taker_model=specialized_data.get("note_taker_model", "claude-3-5-sonnet-20241022"),
            coder_temperature=specialized_data.get("coder_temperature", 0.3),
            architect_temperature=specialized_data.get("architect_temperature", 0.7),
            note_taker_temperature=specialized_data.get("note_taker_temperature", 0.3),
            coder_max_tokens=specialized_data.get("coder_max_tokens", 8192),
            architect_max_tokens=specialized_data.get("architect_max_tokens", 8192),
            note_taker_max_tokens=specialized_data.get("note_taker_max_tokens", 4096),
            coder_thinking_budget=specialized_data.get("coder_thinking_budget", 10000),
            architect_thinking_budget=specialized_data.get("architect_thinking_budget", 30000),
            note_taker_thinking_budget=specialized_data.get("note_taker_thinking_budget", 0),
        )
        
        # Parse memory config
        memory_data = config.get("memory", {})
        memory_config = MemoryConfig(
            enabled=memory_data.get("enabled", True),
            max_context_length=memory_data.get("max_context_length", 100000),
            compression_enabled=memory_data.get("compression_enabled", True),
            compression_threshold=memory_data.get("compression_threshold", 0.8),
            adaptive_enabled=memory_data.get("adaptive_enabled", True),
            persistence_enabled=memory_data.get("persistence_enabled", False),
            persistence_path=Path(memory_data["persistence_path"]) if memory_data.get("persistence_path") else None,
        )
        
        # Parse cache config
        cache_data = config.get("cache", {})
        cache_config = CacheConfig(
            enabled=cache_data.get("enabled", True),
            max_size=cache_data.get("max_size", 1000),
            ttl=cache_data.get("ttl", 3600),
            code_cache_enabled=cache_data.get("code_cache_enabled", True),
            semantic_cache_enabled=cache_data.get("semantic_cache_enabled", True),
        )
        
        # Parse monitoring config
        monitoring_data = config.get("monitoring", {})
        monitoring_config = MonitoringConfig(
            enabled=monitoring_data.get("enabled", True),
            show_startup_info=monitoring_data.get("show_startup_info", True),
            show_usage_updates=monitoring_data.get("show_usage_updates", True),
            cache_ttl=monitoring_data.get("cache_ttl", 3600),
            api_timeout=monitoring_data.get("api_timeout", 5),
            display_format=monitoring_data.get("display_format", "box"),
        )
        
        # Create agent config
        return AgentConfig(
            name=config.get("name", "neocoder-agent"),
            description=config.get("description", "neoCoder AI Agent"),
            default_model=config.get("default_model", "claude-3-5-sonnet-20241022"),
            anthropic=anthropic_config,
            zenmux=zenmux_config,
            specialized_agents=specialized_config,
            memory=memory_config,
            cache=cache_config,
            monitoring=monitoring_config,
            tools_enabled=config.get("tools_enabled", True),
            reasoning_enabled=config.get("reasoning_enabled", True),
            max_iterations=config.get("max_iterations", 10),
            debug=config.get("debug", False),
            log_level=config.get("log_level", "INFO"),
        )
    
    def save(self, path: Optional[Path] = None) -> None:
        """Save settings to JSON file.
        
        Args:
            path: Optional path to save to (defaults to config_path)
        """
        save_path = path or self.config_path
        
        # Ensure directory exists
        save_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Convert to dictionary
        config_dict = self._to_dict()
        
        # Save to file
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(config_dict, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Saved settings to {save_path}")
    
    def _to_dict(self) -> Dict[str, Any]:
        """Convert AgentConfig to dictionary.
        
        Returns:
            Configuration dictionary
        """
        if not self.agent_config:
            return {}
        
        config = self.agent_config
        
        return {
            "name": config.name,
            "description": config.description,
            "anthropic": {
                "auth_token": config.anthropic.auth_token,
                "base_url": config.anthropic.base_url,
                "timeout": config.anthropic.timeout,
                "max_retries": config.anthropic.max_retries,
                "streaming": config.anthropic.streaming,
                "thinking_enabled": config.anthropic.thinking_enabled,
                "thinking_budget": config.anthropic.thinking_budget,
                "thinking_effort": config.anthropic.thinking_effort,
                "thinking_mode": config.anthropic.thinking_mode,
                "thinking_display": config.anthropic.thinking_display,
                "top_p": config.anthropic.top_p,
                "top_k": config.anthropic.top_k,
                "stop_sequences": config.anthropic.stop_sequences,
                "tool_choice": config.anthropic.tool_choice,
                "cache_control_enabled": config.anthropic.cache_control_enabled,
                "cache_control_ttl": config.anthropic.cache_control_ttl,
                "user_id": config.anthropic.user_id,
                "extra_params": config.anthropic.extra_params,
            },
            "zenmux": {
                "api_key": config.zenmux.api_key,
                "base_url": config.zenmux.base_url,
                "timeout": config.zenmux.timeout,
                "max_retries": config.zenmux.max_retries,
                "streaming_enabled": config.zenmux.streaming_enabled,
                "streaming_chunk_size": config.zenmux.streaming_chunk_size,
                "streaming_timeout": config.zenmux.streaming_timeout,
                "structured_output_enabled": config.zenmux.structured_output_enabled,
                "strict_validation": config.zenmux.strict_validation,
                "tool_calling_enabled": config.zenmux.tool_calling_enabled,
                "max_tool_calls": config.zenmux.max_tool_calls,
                "tool_timeout": config.zenmux.tool_timeout,
                "auto_execute_tools": config.zenmux.auto_execute_tools,
                "reasoning_enabled": config.zenmux.reasoning_enabled,
                "default_reasoning_effort": config.zenmux.default_reasoning_effort,
                "default_reasoning_max_tokens": config.zenmux.default_reasoning_max_tokens,
                "adaptive_reasoning": config.zenmux.adaptive_reasoning,
                "log_level": config.zenmux.log_level,
                "log_requests": config.zenmux.log_requests,
                "log_responses": config.zenmux.log_responses,
            },
            "specialized_agents": {
                "coder_model": config.specialized_agents.coder_model,
                "architect_model": config.specialized_agents.architect_model,
                "note_taker_model": config.specialized_agents.note_taker_model,
                "coder_temperature": config.specialized_agents.coder_temperature,
                "architect_temperature": config.specialized_agents.architect_temperature,
                "note_taker_temperature": config.specialized_agents.note_taker_temperature,
                "coder_max_tokens": config.specialized_agents.coder_max_tokens,
                "architect_max_tokens": config.specialized_agents.architect_max_tokens,
                "note_taker_max_tokens": config.specialized_agents.note_taker_max_tokens,
                "coder_thinking_budget": config.specialized_agents.coder_thinking_budget,
                "architect_thinking_budget": config.specialized_agents.architect_thinking_budget,
                "note_taker_thinking_budget": config.specialized_agents.note_taker_thinking_budget,
            },
            "memory": {
                "enabled": config.memory.enabled,
                "max_context_length": config.memory.max_context_length,
                "compression_enabled": config.memory.compression_enabled,
                "compression_threshold": config.memory.compression_threshold,
                "adaptive_enabled": config.memory.adaptive_enabled,
                "persistence_enabled": config.memory.persistence_enabled,
                "persistence_path": str(config.memory.persistence_path) if config.memory.persistence_path else None,
            },
            "cache": {
                "enabled": config.cache.enabled,
                "max_size": config.cache.max_size,
                "ttl": config.cache.ttl,
                "code_cache_enabled": config.cache.code_cache_enabled,
                "semantic_cache_enabled": config.cache.semantic_cache_enabled,
            },
            "monitoring": {
                "enabled": config.monitoring.enabled,
                "show_startup_info": config.monitoring.show_startup_info,
                "show_usage_updates": config.monitoring.show_usage_updates,
                "cache_ttl": config.monitoring.cache_ttl,
                "api_timeout": config.monitoring.api_timeout,
                "display_format": config.monitoring.display_format,
            },
            "tools_enabled": config.tools_enabled,
            "reasoning_enabled": config.reasoning_enabled,
            "max_iterations": config.max_iterations,
            "debug": config.debug,
            "log_level": config.log_level,
        }
    
    def get_specialized_agent_config(self, agent_type: str) -> tuple[str, float, int, int]:
        """Get model, temperature, max_tokens, and thinking_budget for specialized agent.
        
        Args:
            agent_type: Type of agent (coder, architect, note_taker)
            
        Returns:
            Tuple of (model, temperature, max_tokens, thinking_budget)
        """
        if not self.agent_config:
            return ("claude-3-5-sonnet-20241022", 0.3, 8192, 10000)
        
        specialized = self.agent_config.specialized_agents
        
        agent_configs = {
            "coder": (
                specialized.coder_model, 
                specialized.coder_temperature, 
                specialized.coder_max_tokens,
                specialized.coder_thinking_budget
            ),
            "architect": (
                specialized.architect_model, 
                specialized.architect_temperature, 
                specialized.architect_max_tokens,
                specialized.architect_thinking_budget
            ),
            "note_taker": (
                specialized.note_taker_model, 
                specialized.note_taker_temperature, 
                specialized.note_taker_max_tokens,
                specialized.note_taker_thinking_budget
            ),
        }
        
        return agent_configs.get(agent_type, ("claude-3-5-sonnet-20241022", 0.3, 8192, 10000))
    
    def get_provider_config(self, provider: str):
        """Get configuration for specific provider.
        
        Args:
            provider: Provider name (anthropic)
            
        Returns:
            Provider configuration
        """
        if not self.agent_config:
            return None
        
        if provider == "anthropic":
            return self.agent_config.anthropic
        else:
            return None


# Global settings instance
_settings: Optional[Settings] = None


def load_settings(config_path: Optional[Path] = None) -> Settings:
    """Load settings from file.
    
    Args:
        config_path: Optional path to settings.json
        
    Returns:
        Settings instance
    """
    global _settings
    _settings = Settings(config_path)
    return _settings


def get_settings() -> Settings:
    """Get global settings instance.
    
    Returns:
        Settings instance
    """
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
