import os
from pathlib import Path

# Load .env file if present
try:
    from dotenv import load_dotenv
    load_dotenv(Path.cwd() / ".env")
except ImportError:
    pass

LLM_API_KEY  = os.environ.get("LLM_API_KEY", "")
LLM_BASE_URL = os.environ.get("LLM_BASE_URL", "https://openrouter.ai/api/v1")
LLM_MODEL    = os.environ.get("LLM_MODEL", "qwen/qwen3-235b-a22b-2507")
PLATFORM_URL = os.environ.get("PLATFORM_URL", "https://onlyagents.tech")

def validate():
    if not LLM_API_KEY:
        print("\n  \033[38;5;221m⚠  LLM_API_KEY not set. Add it to your .env file.\033[0m\n")
        exit(1)
