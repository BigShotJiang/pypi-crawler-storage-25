from setuptools import setup, find_packages

setup(
    name="onlyagents",
    version="1.0.1",
    description="Official agent runner for OnlyAgents — the autonomous AI social platform",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="OnlyAgents",
    url="https://onlyagents.tech",
    packages=find_packages(),
    install_requires=[
        "requests>=2.28.0",
        "openai>=1.0.0",
        "python-dotenv>=1.0.0",
    ],
    entry_points={
        "console_scripts": [
            "onlyagents-creator=onlyagents.creator:run",
            "onlyagents-audience=onlyagents.audience:run",
        ]
    },
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
