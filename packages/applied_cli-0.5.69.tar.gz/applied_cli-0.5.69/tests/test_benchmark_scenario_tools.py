import json

import pytest

from applied_cli import tools

INPUT_CONVERSATION = {
    "id": "conv-input",
    "title": "Pause subscription request",
    "status": "open",
    "resolution": "escalated",
    "type": "email",
    "summary": "Customer wants to pause an annual subscription.",
    "score": 2,
    "comment": "Agent missed the annual-plan edge case.",
    "sentiment": "negative",
    "sentiment_score": -0.4,
    "created_at": "2026-03-20T10:00:00Z",
    "last_message_at": "2026-03-20T10:05:00Z",
    "message_count": 2,
    "contact": {
        "name": "Casey Customer",
        "email": "casey@example.com",
    },
    "label": {"name": "Billing"},
    "sublabel": {"name": "Pause subscription"},
    "messages": [
        {
            "id": "msg-1",
            "created_at": "2026-03-20T10:00:00Z",
            "role": "user",
            "text": "Can I pause my annual plan for two months?",
            "contact": {"email": "casey@example.com"},
        },
        {
            "id": "msg-2",
            "created_at": "2026-03-20T10:05:00Z",
            "role": "assistant",
            "content": "Let me check your subscription options.",
            "agent": {"name": "August"},
        },
    ],
    "runs": [
        {
            "id": "flow-run-embedded",
            "flow_id": "flow-1",
            "node_ids": ["node-1", "node-2"],
        }
    ],
}

OUTPUT_CONVERSATION = {
    **INPUT_CONVERSATION,
    "id": "conv-output",
    "resolution": "resolved",
    "comment": "Handled correctly after knowledge update.",
}

SCENARIO = {
    "id": "scenario-1",
    "name": "Pause annual plan",
    "agent": {"id": "agent-1", "name": "August"},
    "benchmark": {"id": "bench-1", "name": "Retention Regression"},
    "benchmarks": [{"id": "bench-1", "name": "Retention Regression"}],
    "context": {"channel": "email"},
    "allow_remote_ticket_creation": False,
    "pass_status": "fail",
    "csat_score": 2,
    "feedback": "Needs clearer annual-plan policy guidance.",
    "run_count": 3,
    "created_at": "2026-03-20T09:00:00Z",
    "updated_at": "2026-03-20T10:00:00Z",
    "input_conversation": INPUT_CONVERSATION,
}

SCENARIO_RUN = {
    "id": "scenario-run-1",
    "status": "COMPLETED",
    "pass_status": "pass",
    "csat_score": 5,
    "reference_score": 0.92,
    "reference_notes": "Matched expected policy explanation.",
    "feedback": "Correctly explained the pause policy.",
    "is_escalated": False,
    "is_input_run": False,
    "error": "",
    "metadata": {"target_agent_id": "agent-1"},
    "bulk_job_id": "job-1",
    "evaluated_at": "2026-03-21T09:00:00Z",
    "evaluated_by": {"id": "user-1", "name": "QA Reviewer"},
    "scenario": {"id": "scenario-1", "name": "Pause annual plan"},
    "output_conversation": OUTPUT_CONVERSATION,
    "created_at": "2026-03-21T08:00:00Z",
    "updated_at": "2026-03-21T09:00:00Z",
}

FLOW_RUN = {
    "id": "flow-run-1",
    "status": "Failed",
    "conversation_id": "conv-output",
    "flow": {"id": "flow-1", "name": "Pause Subscription"},
    "started_at": "2026-03-21T08:00:00Z",
    "ended_at": "2026-03-21T08:00:03Z",
    "duration": 3.2,
    "spans": [
        {
            "span_id": "span-1",
            "span_name": "branch",
            "scope_name": "flows",
            "duration": 0.2,
            "status_code": "OK",
            "status_message": "",
            "span_attributes": {
                "tool_name": "Pause check",
                "selected.path": "default",
                "input": "{\"value\": \"annual\"}",
            },
        },
        {
            "span_id": "span-2",
            "span_name": "completion",
            "scope_name": "flows",
            "duration": 1.2,
            "status_code": "ERROR",
            "status_message": "Model timeout",
            "span_attributes": {
                "tool_name": "Agent Response",
                "content": "Sorry, I hit a timeout.",
                "input": "prompt",
            },
        },
    ],
    "actions": [
        {
            "id": "action-1",
            "tool": {"name": "Agent Response"},
            "status": "failed",
            "cost": 0.03,
        }
    ],
}

MESSAGE_REFERENCES = [
    {
        "id": "ref-1",
        "message_id": "msg-2",
        "response": {
            "id": "resp-1",
            "type": "qa",
            "question": "Can customers pause annual plans?",
        },
        "content": {
            "id": "content-1",
            "title": "Annual plan pause policy",
            "source_url": "https://example.com/policies/pause",
        },
        "reason": "Matched pause-policy article",
        "relevance_score": 0.91,
        "text_fragment_data": {"start": 0, "end": 32},
        "knowledge_gap": {
            "id": "gap-1",
            "title": "Add annual-plan examples",
        },
    }
]

BENCHMARK = {
    "id": "bench-1",
    "name": "Retention Regression",
    "description": "Regression coverage for retention workflows.",
    "agent": {"id": "agent-1", "name": "August"},
    "scenario_count": 1,
    "created_at": "2026-03-19T09:00:00Z",
    "updated_at": "2026-03-21T09:00:00Z",
}


class FakeScenarioClient:
    def __init__(self):
        self.list_scenarios_kwargs = None
        self.bulk_run_kwargs = None

    async def get_benchmark(self, benchmark_id):
        assert benchmark_id == "bench-1"
        return BENCHMARK

    async def list_scenarios(
        self,
        benchmark_id=None,
        agent_id=None,
        pass_status=None,
        limit=50,
    ):
        self.list_scenarios_kwargs = {
            "benchmark_id": benchmark_id,
            "agent_id": agent_id,
            "pass_status": pass_status,
            "limit": limit,
        }
        return [SCENARIO]

    async def get_scenario(self, scenario_id):
        assert scenario_id == "scenario-1"
        return SCENARIO

    async def list_scenario_runs(
        self,
        scenario_id=None,
        benchmark_id=None,
        latest=False,
        limit=50,
    ):
        assert scenario_id == "scenario-1"
        return [SCENARIO_RUN]

    async def get_scenario_run(self, run_id):
        assert run_id == "scenario-run-1"
        return SCENARIO_RUN

    async def get_conversation_references(self, conversation_id, *, shop_id=None):
        assert conversation_id == "conv-output"
        assert shop_id is None
        return MESSAGE_REFERENCES

    async def get_flow_run(self, flow_run_id):
        assert flow_run_id == "flow-run-1"
        return FLOW_RUN

    async def bulk_run_scenarios(
        self,
        scenario_ids=None,
        benchmark_id=None,
        target_agent_id=None,
        contact_override=None,
    ):
        self.bulk_run_kwargs = {
            "scenario_ids": scenario_ids,
            "benchmark_id": benchmark_id,
            "target_agent_id": target_agent_id,
            "contact_override": contact_override,
        }
        return {
            "job_id": "job-1",
            "total": len(scenario_ids or []),
            "queued": len(scenario_ids or []),
            "failed_queue": [],
            "scenario_run_ids": ["scenario-run-1"],
            "target_agent_id": target_agent_id,
        }


@pytest.mark.asyncio
async def test_benchmark_get_json_includes_scenarios():
    client = FakeScenarioClient()

    result = await tools.benchmark_get(
        client,
        benchmark_id="bench-1",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["agent_name"] == "August"
    assert payload["scenarios"][0]["id"] == "scenario-1"
    assert payload["scenarios"][0]["feedback"] == SCENARIO["feedback"]
    assert client.list_scenarios_kwargs["benchmark_id"] == "bench-1"


@pytest.mark.asyncio
async def test_scenario_get_json_includes_embedded_conversation_and_recent_runs():
    client = FakeScenarioClient()

    result = await tools.scenario_get(
        client,
        scenario_id="scenario-1",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["input_conversation"]["conversation"]["contact_email"] == "casey@example.com"
    assert payload["input_conversation"]["messages"][0]["content"] == "Can I pause my annual plan for two months?"
    assert payload["input_conversation"]["flow_runs"][0]["id"] == "flow-run-embedded"
    assert payload["recent_runs"][0]["reference_score"] == 0.92
    assert payload["recent_runs"][0]["flow_run_ids"] == ["flow-run-embedded"]


@pytest.mark.asyncio
async def test_scenario_run_get_json_includes_output_conversation_and_escalation_state():
    client = FakeScenarioClient()

    result = await tools.scenario_run_get(
        client,
        run_id="scenario-run-1",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["scenario"]["name"] == "Pause annual plan"
    assert payload["output_conversation"]["conversation"]["resolution"] == "resolved"
    assert payload["output_conversation"]["messages"][1]["author"] == "August"
    assert payload["is_escalated"] is False


@pytest.mark.asyncio
async def test_conversation_references_csv_exposes_source_and_gap_columns():
    client = FakeScenarioClient()

    result = await tools.conversation_references(
        client,
        conversation_id="conv-output",
        output_format="csv",
    )

    lines = result.strip().splitlines()
    assert lines[0] == (
        "id,message_id,response_type,response_question,content_title,"
        "content_source_url,reason,relevance_score,knowledge_gap_title"
    )
    assert "Annual plan pause policy" in lines[1]
    assert "Add annual-plan examples" in lines[1]


@pytest.mark.asyncio
async def test_flow_run_get_json_returns_structured_trace():
    client = FakeScenarioClient()

    result = await tools.flow_run_get(
        client,
        flow_run_id="flow-run-1",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["flow"]["name"] == "Pause Subscription"
    assert payload["actions"][0]["node_name"] == "Agent Response"
    assert payload["spans"][0]["selected_path"] == "default"
    assert payload["error_span_count"] == 1


@pytest.mark.asyncio
async def test_scenario_bulk_run_resolves_ids_from_benchmark():
    client = FakeScenarioClient()

    result = await tools.scenario_bulk_run(
        client,
        benchmark_id="bench-1",
        target_agent_id="agent-2",
        output_format="json",
    )

    payload = json.loads(result)
    assert client.bulk_run_kwargs == {
        "scenario_ids": ["scenario-1"],
        "benchmark_id": None,
        "target_agent_id": "agent-2",
        "contact_override": None,
    }
    assert payload["benchmark_id"] == "bench-1"
    assert payload["scenario_run_ids"] == ["scenario-run-1"]
