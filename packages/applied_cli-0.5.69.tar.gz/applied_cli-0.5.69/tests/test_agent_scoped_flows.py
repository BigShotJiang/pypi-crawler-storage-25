import json
import sys
from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from applied_cli.agent_scoped_flows import (  # noqa: E402
    AgentScopedFlowCLIError,
    _handle_edge_create,
    _handle_edge_delete,
    _handle_edge_update,
    _handle_flow_create,
    _handle_flow_delete,
    _handle_flow_update,
    _handle_node_create,
    _handle_node_delete,
    _handle_node_update,
    _parse_nested_command,
    run_agent_scoped_flow_command,
)


class StubClient:
    def __init__(
        self,
        *,
        flow_lookup: dict | None = None,
        flow_result: dict | None = None,
        node: dict | None = None,
        edge: dict | None = None,
    ):
        self.flow_lookup = flow_lookup or {
            "id": "flow-1",
            "agent": {"id": "agent-1"},
            "graph": {
                "nodes": [{"id": "node-1", "name": "completion-node"}],
                "edges": [{"id": "edge-1", "source": "node-1", "target": "node-2"}],
            },
        }
        self.flow_result = flow_result or {
            "id": "flow-1",
            "agent_id": "agent-1",
            "shop_id": "shop-1",
            "name": "Flow 1",
            "trigger": "llm.call",
            "type": "conversational",
        }
        self.node = node or {
            "id": "node-1",
            "name": "completion-node",
            "metadata": {"position": {"x": 1, "y": 2}},
            "description": "",
            "prompt": "",
            "guardrail": "",
            "human_readable_name": "Completion Node",
        }
        self.edge = edge or {
            "id": "edge-1",
            "source": "node-1",
            "target": "node-2",
            "source_handle": "default",
            "target_handle": None,
            "label": "fallback",
            "metadata": {},
            "data": {"label": "fallback", "metadata": {}},
        }
        self.created_flow_args = None
        self.updated_flow_args = None
        self.deleted_flow_id = None
        self.created_node_args = None
        self.updated_node_args = None
        self.deleted_node_args = None
        self.created_edge_args = None
        self.updated_edge_args = None
        self.deleted_edge_args = None

    async def get_flow(self, flow_id: str):
        assert flow_id == self.flow_lookup["id"]
        return self.flow_lookup

    async def create_flow(self, **kwargs):
        self.created_flow_args = kwargs
        return {
            **self.flow_result,
            "name": kwargs["name"],
            "trigger": kwargs["trigger"],
            "type": kwargs["flow_type"],
            "description": kwargs["description"],
        }

    async def update_flow(self, flow_id: str, **kwargs):
        self.updated_flow_args = (flow_id, kwargs)
        return {**self.flow_result, "id": flow_id, **kwargs}

    async def delete_flow(self, flow_id: str):
        self.deleted_flow_id = flow_id

    async def create_node(self, **kwargs):
        self.created_node_args = kwargs
        return self.node

    async def update_node(self, flow_id: str, node_id: str, **kwargs):
        self.updated_node_args = (flow_id, node_id, kwargs)
        return {**self.node, "id": node_id, **kwargs}

    async def delete_node(self, flow_id: str, node_id: str):
        self.deleted_node_args = (flow_id, node_id)

    async def create_edge(self, **kwargs):
        self.created_edge_args = kwargs
        return self.edge

    async def update_edge(self, flow_id: str, edge_id: str, **kwargs):
        self.updated_edge_args = (flow_id, edge_id, kwargs)
        return {**self.edge, "id": edge_id, **kwargs}

    async def delete_edge(self, flow_id: str, edge_id: str):
        self.deleted_edge_args = (flow_id, edge_id)


def _parse_args(argv: list[str]):
    parsed = _parse_nested_command(argv)
    assert parsed is not None
    return parsed[1]


def test_parse_nested_node_create_command():
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "create",
            "--executor-type",
            "Agent Response",
            "--metadata",
            '{"position":{"x":1,"y":2}}',
            "--format",
            "json",
        ]
    )

    assert args.agent_id == "agent-1"
    assert args.flow_id == "flow-1"
    assert args.executor_type == "Agent Response"
    assert args.format == "json"


def test_agent_scoped_parser_ignores_top_level_agents_command():
    assert run_agent_scoped_flow_command(["agents"], lambda _shop_id: None) is None
    assert (
        run_agent_scoped_flow_command(
            ["agents", "--format", "json"],
            lambda _shop_id: None,
        )
        is None
    )


@pytest.mark.asyncio
async def test_flow_create_prints_raw_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "create",
            "--name",
            "New Flow",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_flow_create(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.created_flow_args is not None
    assert json.loads(capsys.readouterr().out) == {
        **client.flow_result,
        "name": "New Flow",
        "trigger": "llm.call",
        "type": "conversational",
        "description": "",
    }


@pytest.mark.asyncio
async def test_flow_update_prints_raw_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "update",
            "--name",
            "Renamed Flow",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_flow_update(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.updated_flow_args == ("flow-1", {"name": "Renamed Flow"})
    assert json.loads(capsys.readouterr().out) == {
        **client.flow_result,
        "id": "flow-1",
        "name": "Renamed Flow",
    }


@pytest.mark.asyncio
async def test_flow_delete_prints_no_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "delete",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_flow_delete(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.deleted_flow_id == "flow-1"
    assert capsys.readouterr().out == ""


@pytest.mark.asyncio
async def test_node_create_prints_raw_json(capsys):
    client = StubClient(
        node={
            "id": "node-9",
            "name": "completion-node",
            "metadata": {"position": {"x": 1, "y": 2}},
            "description": "",
            "prompt": "",
            "guardrail": "",
            "human_readable_name": "Completion Node",
        }
    )
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "create",
            "--executor-type",
            "Agent Response",
            "--metadata",
            '{"position":{"x":1,"y":2}}',
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_node_create(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.created_node_args is not None
    assert client.created_node_args["name"] == "completion"
    assert client.created_node_args["metadata"] == {"position": {"x": 1, "y": 2}}
    assert json.loads(capsys.readouterr().out) == client.node


@pytest.mark.asyncio
async def test_node_create_accepts_guardrail_on_create():
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "create",
            "--executor-type",
            "Agent Response",
            "--guardrail",
            "Be careful",
        ]
    )

    exit_code = await _handle_node_create(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.created_node_args is not None
    assert client.created_node_args["guardrail"] == "Be careful"


@pytest.mark.asyncio
async def test_node_update_rejects_wrong_agent():
    client = StubClient(flow_lookup={"id": "flow-1", "agent": {"id": "agent-2"}})
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "node-1",
            "update",
            "--prompt",
            "hi",
        ]
    )

    with pytest.raises(AgentScopedFlowCLIError, match="does not belong to agent"):
        await _handle_node_update(args, lambda _shop_id: client)


@pytest.mark.asyncio
async def test_node_update_prints_raw_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "node-1",
            "update",
            "--prompt",
            "hi",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_node_update(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.updated_node_args == ("flow-1", "node-1", {"prompt": "hi"})
    assert json.loads(capsys.readouterr().out) == {
        **client.node,
        "id": "node-1",
        "prompt": "hi",
    }


@pytest.mark.asyncio
async def test_node_delete_prints_no_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "node",
            "node-1",
            "delete",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_node_delete(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.deleted_node_args == ("flow-1", "node-1")
    assert capsys.readouterr().out == ""


@pytest.mark.asyncio
async def test_edge_create_prints_raw_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "edge",
            "create",
            "--source-node-id",
            "node-1",
            "--target-node-id",
            "node-2",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_edge_create(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.created_edge_args is not None
    assert json.loads(capsys.readouterr().out) == client.edge


@pytest.mark.asyncio
async def test_edge_update_prints_raw_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "edge",
            "edge-1",
            "update",
            "--label",
            "updated label",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_edge_update(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.updated_edge_args == ("flow-1", "edge-1", {"label": "updated label"})
    assert json.loads(capsys.readouterr().out) == {
        **client.edge,
        "id": "edge-1",
        "label": "updated label",
    }


@pytest.mark.asyncio
async def test_edge_delete_prints_no_json(capsys):
    client = StubClient()
    args = _parse_args(
        [
            "agents",
            "agent-1",
            "flows",
            "flow-1",
            "edge",
            "edge-1",
            "delete",
            "--format",
            "json",
        ]
    )

    exit_code = await _handle_edge_delete(args, lambda _shop_id: client)

    assert exit_code == 0
    assert client.deleted_edge_args == ("flow-1", "edge-1")
    assert capsys.readouterr().out == ""
