import subprocess
import json
import os
import re

MEMORY_FILE = os.path.expanduser("~/.kinu_memory.json")

def default_memory():
    return {
        "identity": {"name": None, "origin": None, "location": None},
        "preferences": {"likes": [], "dislikes": []},
        "projects": [],
        "notes": []
    }

def load_memory():
    if os.path.exists(MEMORY_FILE):
        with open(MEMORY_FILE, "r") as f:
            data = json.load(f)
        if "identity" not in data:
            return default_memory()
        return data
    return default_memory()

def save_memory(memory):
    with open(MEMORY_FILE, "w") as f:
        json.dump(memory, f, indent=4)

class Colors:
    GREEN = '\033[92m'
    BLUE = '\033[94m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    CYAN = '\033[96m'
    MAGENTA = '\033[95m'
    RESET = '\033[0m'
    BOLD = '\033[1m'

def auto_learn(user_input, memory):
    text = user_input.lower()
    name_match = re.search(r"(my name is|call me) (.+)", text)
    if name_match:
        memory["identity"]["name"] = name_match.group(2).strip().capitalize()
        save_memory(memory)
        print(f"{Colors.MAGENTA}🧠 Name stored.{Colors.RESET}")
        return
    location_match = re.search(r"(i live in|i am in) (.+)", text)
    if location_match:
        memory["identity"]["location"] = location_match.group(2).strip().capitalize()
        save_memory(memory)
        print(f"{Colors.MAGENTA}🧠 Learned location.{Colors.RESET}")
        return
    like_match = re.search(r"i like (.+)", text)
    if like_match:
        like = like_match.group(1).strip()
        if like not in memory["preferences"]["likes"]:
            memory["preferences"]["likes"].append(like)
            save_memory(memory)
            print(f"{Colors.MAGENTA}🧠 Learned like.{Colors.RESET}")
        return
    project_match = re.search(r"i am building (.+)", text)
    if project_match:
        project = project_match.group(1).strip()
        if project not in memory["projects"]:
            memory["projects"].append(project)
            save_memory(memory)
            print(f"{Colors.MAGENTA}🧠 Learned project.{Colors.RESET}")
        return

def classify_intent(prompt):
    text = prompt.lower()
    high_emotion = ["burned out", "i can't do this", "i give up", "i hate this", "i'm done"]
    medium_emotion = ["overwhelmed", "frustrated", "stressed", "stuck"]
    if any(w in text for w in high_emotion): return "emotional_high"
    if any(w in text for w in medium_emotion): return "emotional_medium"
    if any(x in text for x in ["what is my name", "who am i"]): return "identity"
    if any(x in text for x in ["project", "building", "working on"]): return "project"
    return "knowledge"

def build_memory_summary(memory):
    lines = []
    identity = memory["identity"]
    if identity["name"]: lines.append(f"Name: {identity['name']}")
    if identity["location"]: lines.append(f"Location: {identity['location']}")
    if memory["projects"]: lines.append("Projects: " + ", ".join(memory["projects"]))
    if memory["notes"]: lines.append("Notes: " + ", ".join(memory["notes"]))
    return "\n".join(lines)

def chat(prompt, conversation_history, memory):
    intent = classify_intent(prompt)
    memory_context = build_memory_summary(memory) if intent in ["identity", "personal_general"] else ""
    base = "You are KINU, a helpful local AI assistant."
    if intent == "emotional_high":
        system = f"{base} The user is in distress. Be calm and grounding."
    elif memory_context:
        system = f"{base}\nKnown about user:\n{memory_context}"
    else:
        system = base

    messages = [f"system: {system}"]
    for msg in conversation_history:
        messages.append(f"{msg['role']}: {msg['content']}")
    messages.append(f"user: {prompt}")

    process = subprocess.Popen(
        ['ollama', 'run', 'llama3.2', "\n".join(messages)],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    response = ""
    for line in process.stdout:
        print(line, end='', flush=True)
        response += line
    process.wait()
    return response.strip()

def show_profile(memory):
    print(f"\n{Colors.CYAN}{Colors.BOLD}👤 USER PROFILE{Colors.RESET}")
    print("-" * 40)
    print(f"Name: {memory['identity']['name'] or 'Not set'}")
    print(f"Location: {memory['identity']['location'] or 'Not set'}")
    print(f"Projects: {', '.join(memory['projects']) or 'None'}")
    print(f"Notes: {', '.join(memory['notes']) or 'None'}")
    print("-" * 40 + "\n")

def main():
    print("=" * 50)
    print(f"{Colors.BOLD}{Colors.YELLOW}🤖 KINU AI v1.0.0{Colors.RESET}")
    print(f"{Colors.CYAN}Local AI Terminal Assistant{Colors.RESET}")
    print("=" * 50)

    memory = load_memory()
    conversation_history = []

    while True:
        try:
            user_input = input(f"{Colors.GREEN}You: {Colors.RESET}")
            auto_learn(user_input, memory)

            if user_input.lower().startswith("remember "):
                note = user_input[9:].strip()
                if note:
                    memory["notes"].append(note)
                    save_memory(memory)
                    print(f"{Colors.MAGENTA}🧠 Note saved!{Colors.RESET}\n")
                continue

            if user_input.lower() == "profile":
                show_profile(memory)
                continue

            if user_input.lower() in ["quit", "exit"]:
                print(f"{Colors.YELLOW}👋 Goodbye!{Colors.RESET}")
                break

            if user_input.strip():
                conversation_history.append({"role": "user", "content": user_input})
                print(f"{Colors.BLUE}KINU 🤖: {Colors.RESET}", end="", flush=True)
                response = chat(user_input, conversation_history, memory)
                print("\n")
                conversation_history.append({"role": "assistant", "content": response})

        except KeyboardInterrupt:
            print(f"\n{Colors.YELLOW}Interrupted. Goodbye!{Colors.RESET}")
            break

if __name__ == "__main__":
    main()
