# 🤖 KINU AI

A local AI terminal assistant powered by Llama 3.2 via Ollama.

## Install
```bash
pip install kinu-ai
```

## Usage
```bash
kinu-ai
```

## Requirements

- Python 3.10+
- [Ollama](https://ollama.com) installed and running
- Llama 3.2 model: `ollama pull llama3.2`

## Features

- 🧠 Persistent memory across sessions
- 🎭 Intent and emotional detection
- 💻 Runs fully locally — no API keys needed

## Author

Alex Kinuthia — [GitHub](https://github.com/bettalex33-prog)
