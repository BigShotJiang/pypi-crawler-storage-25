# REF-0000: Document Index

**Applies to:** All projects using the COR document system
**Last updated:** 2026-03-19
**Last reviewed:** 2026-03-19
**Status:** Active

---

## What Is It?

A reference index of all documents in the COR system.

---

| ACID | Type | Title |
|------|------|-------|
| 0001 | REF | Glossary |
| 1000 | SOP | Create SOP |
| 1001 | SOP | Create Document |
| 1002 | SOP | Read Document |
| 1100 | SOP | Create Decision Record |
| 1101 | SOP | Submit Change Request |
| 1102 | SOP | Create Proposal |
| 1200 | SOP | Session Retrospective |
| 1201 | SOP | Discussion Tracking |
| 1300 | SOP | Update Document |
| 1301 | SOP | Deprecate Document |
| 1302 | SOP | Maintain Document Index |
| 1400 | SOP | Atomic SOP Principle |
| 1401 | SOP | Documentation Language Policy |
| 1402 | SOP | Declare Active Process |
| 1403 | SOP | Interactive Question Principle |
| 1404 | SOP | Interactive Question — Claude Code Implementation |
| 1405 | SOP | Interactive Question — GitHub Copilot Implementation |
| 1500 | SOP | TDD Development Workflow |
| 1501 | SOP | Create GitHub Issue |
| 1502 | SOP | Git Branch Naming |
| 1600 | SOP | Workflow — Direct Review Loop |
| 1601 | SOP | Workflow — Leader Mediated Review Loop |
| 1602 | SOP | Workflow — Multi Model Parallel Review |
| 1603 | SOP | Workflow — Parallel Module Implementation |
| 1604 | SOP | Workflow — Competitive Parallel Exploration |
| 1605 | SOP | Workflow — Sequential Pipeline |
| 1606 | SOP | Workflow — Selection |
| 1700 | SOP | Initialize Project |
| 1701 | SOP | Archive Project |
| 1702 | SOP | Sync Project |
| 1703 | SOP | Fork Project |

---

## Change History

| Date | Change | By |
|------|--------|----|
| 2026-03-19 | Initial version with proper structure | Frank |
