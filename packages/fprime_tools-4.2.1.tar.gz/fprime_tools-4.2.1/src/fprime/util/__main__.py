"""
fprime.util.__main__:

This acts as the main entry point for the fprime.util module. This allows users to run fprime.util as an entry point.
This will include the build_helper scripts and run them.
"""

import sys

import fprime.util.cli


def main():
    """Run wrapper, to point a console_script at"""
    return fprime.util.cli.utility_entry(args=sys.argv[1:])


if __name__ == "__main__":
    sys.exit(main())
