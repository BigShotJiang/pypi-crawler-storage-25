"""MDA §09 DSSE PAE construction and Sigstore verifier hook orchestration."""

from __future__ import annotations

import base64
import re
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import NoReturn, NotRequired, Protocol, TypedDict

import jcs  # type: ignore[reportMissingTypeStubs]

from .errors import ErrorCategory, MdaConfigError
from .integrity import IntegrityField

DEFAULT_PAYLOAD_TYPE = "application/vnd.mda.integrity+json"


SignatureEntry = TypedDict(
    "SignatureEntry",
    {
        "signer": str,
        "key-id": str,
        "payload-digest": str,
        "algorithm": str,
        "signature": str,
        "rekor-log-id": NotRequired[str],
        "rekor-log-index": NotRequired[int],
        "payload-type": NotRequired[str],
    },
)


class DsseSignature(TypedDict, total=False):
    """One signature inside a Rekor DSSE envelope."""

    sig: str
    keyid: str


class DsseEnvelope(TypedDict):
    """Rekor-indexed DSSE envelope subset used by MDA verification."""

    payload_type: str
    payload: str
    signatures: list[DsseSignature]


class RekorEntry(TypedDict, total=False):
    """Rekor dsse-v0.0.1 entry subset used by MDA verification."""

    kind: str
    certificate_pem: str
    dsse_envelope: DsseEnvelope


@dataclass(frozen=True)
class AllowedSigner:
    """Operator trust-policy allow-list entry."""

    issuer: str
    identity_pattern: re.Pattern[str]


@dataclass(frozen=True)
class TrustPolicy:
    """Operator trust policy for Sigstore verification."""

    allowed_signers: Sequence[AllowedSigner] = field(default_factory=tuple)


@dataclass(frozen=True)
class SigstoreVerificationResult:
    """Verified identity returned by an injected Sigstore verifier."""

    certificate_pem: str | None = None
    issuer: str | None = None
    subject_alternative_name: str | None = None


class RekorClient(Protocol):
    """Pluggable Rekor lookup used by signature verification."""

    def fetch_entry(self, log_id: str, log_index: int) -> RekorEntry | None:
        """Fetch a Rekor entry by log coordinates."""
        ...


class SigstoreVerifier(Protocol):
    """Injected Sigstore verifier hook; performs real crypto outside this package."""

    def verify(
        self,
        entry: RekorEntry,
        signature: SignatureEntry,
        pae_bytes: bytes,
    ) -> SigstoreVerificationResult:
        """Verify one Rekor entry/signature/PAE tuple."""
        ...


def construct_dsse_pae(payload_type: str, payload_bytes: bytes) -> bytes:
    """MDA §09-3.1 constructs DSSE PAE bytes."""

    head = f"DSSEv1 {len(payload_type)} {payload_type} {len(payload_bytes)} ".encode()
    return head + payload_bytes


def verify_signatures(
    signatures: Sequence[SignatureEntry],
    integrity: IntegrityField,
    trust_policy: TrustPolicy,
    rekor_client: RekorClient,
    sigstore_verifier: SigstoreVerifier,
) -> None:
    """MDA §09-4.2 verifies signatures using injected Rekor and Sigstore hooks."""

    if not signatures:
        raise MdaConfigError(
            ErrorCategory.SignatureVerificationFailure,
            "verify_signatures=True requires a non-empty signatures[] field",
        )

    payload_bytes = _canonical_json(integrity)
    expected_payload = base64.b64encode(payload_bytes).decode("ascii")

    for sig in signatures:
        if sig["payload-digest"] != integrity["digest"]:
            raise MdaConfigError(
                ErrorCategory.SignatureDigestMismatch,
                "signature payload-digest does not equal integrity.digest",
                {"signer": sig["signer"]},
            )

        signer_issuer, signer_identity = _parse_sigstore_signer(sig["signer"])
        payload_type = sig.get("payload-type", DEFAULT_PAYLOAD_TYPE)
        pae_bytes = construct_dsse_pae(payload_type, payload_bytes)

        log_id = sig.get("rekor-log-id")
        log_index = sig.get("rekor-log-index")
        if not log_id or log_index is None:
            raise MdaConfigError(
                ErrorCategory.RekorInclusionFailure,
                "Sigstore signature missing rekor-log-id or rekor-log-index",
                {"signer": sig["signer"]},
            )

        entry = rekor_client.fetch_entry(log_id, log_index)
        if entry is None:
            raise MdaConfigError(
                ErrorCategory.RekorInclusionFailure,
                "Rekor entry not found for the supplied log coordinates",
                {"logId": log_id, "logIndex": log_index},
            )
        if entry.get("kind") != "dsse-v0.0.1":
            raise MdaConfigError(
                ErrorCategory.RekorEntryTypeMismatch,
                f"Rekor entry kind '{entry.get('kind')}' is not 'dsse-v0.0.1'",
                {"logId": log_id, "logIndex": log_index, "kind": entry.get("kind")},
            )

        _validate_rekor_dsse_envelope(entry, sig, payload_type, expected_payload)

        try:
            verification = sigstore_verifier.verify(entry, sig, pae_bytes)
        except Exception as cause:
            raise MdaConfigError(
                ErrorCategory.SignatureVerificationFailure,
                "Sigstore verification failed",
                {"signer": sig["signer"], "cause": str(cause)},
            ) from cause

        _enforce_trust_policy(
            verification,
            trust_policy,
            sig,
            signer_issuer=signer_issuer,
            signer_identity=signer_identity,
        )


def _canonical_json(value: object) -> bytes:
    raw = jcs.canonicalize(value)  # type: ignore[reportUnknownMemberType]
    return raw if isinstance(raw, bytes) else raw.encode("utf-8")


def _parse_sigstore_signer(signer: str) -> tuple[str, str]:
    if signer.startswith("did-web:"):
        raise MdaConfigError(
            ErrorCategory.UnknownSignerMethod,
            "did:web signatures are not supported in v1.0 (use Sigstore OIDC)",
            {"signer": signer},
        )
    prefix = "sigstore-oidc:"
    if not signer.startswith(prefix):
        raise MdaConfigError(
            ErrorCategory.UnknownSignerMethod,
            "unknown signer method (expected 'sigstore-oidc:' prefix)",
            {"signer": signer},
        )
    rest = signer[len(prefix) :]
    issuer, sep, identity = rest.rpartition("#")
    if not sep or not issuer or not identity:
        raise MdaConfigError(
            ErrorCategory.UntrustedIssuer,
            "sigstore-oidc signer must be '<issuer>#<identity>'",
            {"signer": signer},
        )
    return issuer, identity


def _validate_rekor_dsse_envelope(
    entry: RekorEntry,
    sig: SignatureEntry,
    payload_type: str,
    expected_payload: str,
) -> None:
    envelope = entry.get("dsse_envelope")
    if envelope is None:
        _rekor_inclusion_failure("Rekor entry is missing DSSE envelope", sig)
    if envelope["payload_type"] != payload_type:
        _rekor_inclusion_failure("Rekor DSSE envelope payloadType mismatch", sig)
    if envelope["payload"] != expected_payload:
        _rekor_inclusion_failure("Rekor DSSE envelope payload mismatch", sig)
    if not any(
        candidate.get("sig") == sig["signature"] and candidate.get("keyid") == sig["key-id"]
        for candidate in envelope["signatures"]
    ):
        _rekor_inclusion_failure("Rekor DSSE envelope does not contain signature/key-id", sig)


def _rekor_inclusion_failure(message: str, sig: SignatureEntry) -> NoReturn:
    raise MdaConfigError(
        ErrorCategory.RekorInclusionFailure,
        message,
        {"signer": sig["signer"]},
    )


def _enforce_trust_policy(
    verification: SigstoreVerificationResult,
    policy: TrustPolicy,
    sig: SignatureEntry,
    *,
    signer_issuer: str,
    signer_identity: str,
) -> None:
    issuer = verification.issuer
    identity = verification.subject_alternative_name or _extract_cert_identity(
        verification.certificate_pem or ""
    )
    if issuer is None or identity is None:
        raise MdaConfigError(
            ErrorCategory.UntrustedIssuer,
            "Sigstore verifier did not return verified issuer and identity claims",
            {"signer": sig["signer"]},
        )
    if issuer != signer_issuer:
        raise MdaConfigError(
            ErrorCategory.UntrustedIssuer,
            "verified Sigstore issuer does not match signatures[i].signer",
            {"issuer": issuer, "signerIssuer": signer_issuer, "signer": sig["signer"]},
        )
    if identity != signer_identity:
        raise MdaConfigError(
            ErrorCategory.UntrustedIssuer,
            "verified Sigstore identity does not match signatures[i].signer",
            {"identity": identity, "signerIdentity": signer_identity, "signer": sig["signer"]},
        )
    for allowed in policy.allowed_signers:
        if allowed.issuer == issuer and allowed.identity_pattern.search(identity):
            return
    raise MdaConfigError(
        ErrorCategory.UntrustedIssuer,
        "signer identity not in operator trust policy",
        {"issuer": issuer, "identity": identity, "signer": sig["signer"]},
    )


def _extract_cert_identity(cert_pem: str) -> str | None:
    match = re.search(r"(?:email|uri):([^,\n]+)", cert_pem, flags=re.IGNORECASE)
    return match.group(1).strip() if match else None
