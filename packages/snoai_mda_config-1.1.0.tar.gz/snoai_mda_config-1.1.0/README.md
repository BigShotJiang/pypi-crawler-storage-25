# snoai-mda-config

Python source-mode loader for MDA v1.0 configuration artifacts.

This package mirrors the TypeScript `@snoai/mda-config` and Rust
`snoai-mda-config` loader contract. The v1.0 surface covers frontmatter
extraction, MDA source-schema validation, integrity verification,
`requires.network` enforcement, Sigstore verification hooks, and consumer
pydantic validation.

Python does not perform real Rekor transport or Sigstore cryptography by
itself. When `verify_signatures=True`, callers must provide a trust policy,
Rekor client, and Sigstore verifier hook. Missing verifier pieces fail closed.

```python
from pathlib import Path
from pydantic import BaseModel
from snoai_mda_config import load_mda_source


class Preset(BaseModel, extra="forbid"):
    name: str
    description: str
    metadata: dict | None = None
    integrity: dict | None = None
    signatures: list[dict] | None = None


config = load_mda_source(
    Path("preset.mda"),
    schema=Preset,
    verify_integrity=True,
)
```

For signed presets, also pass `verify_signatures=True`,
`trust_policy=...`, `rekor_client=...`, and `sigstore_verifier=...`. For
capability enforcement, pass `enforce_requires=True` with
`allowed_networks=[...]`.
