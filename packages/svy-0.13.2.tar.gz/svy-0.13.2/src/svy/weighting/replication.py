# src/svy/engine/weighting/replication.py
"""
Replicate weight creation for variance estimation.

Simplified design:
- No variance scale stored (computed on-the-fly when needed)
- Store df (degrees of freedom) with sensible defaults
- Store fay_coef only when relevant
- PSU index mapping for correct weight application
"""

from __future__ import annotations

import math

from dataclasses import dataclass
from typing import Literal

import numpy as np

from numpy.typing import NDArray

from svy.utils import hadamard as hdd
from svy.utils.random_state import RandomState, resolve_random_state, spawn_child_rngs


FloatArr = NDArray[np.float64]
IntArr = NDArray[np.int64]


@dataclass
class ReplicateSpec:
    """
    Replicate weight specification.

    Attributes:
        coefs: Replicate coefficient matrix, shape (n_psus, n_reps)
        psu_index: Array mapping each observation to its PSU row, shape (n_obs,)
        method: Replication method name ("BRR", "JKn", "Bootstrap")
        fay_coef: Fay's coefficient for BRR (0.0 for standard BRR)
        df: Degrees of freedom (default: n_reps - 1 or n_psus - n_strata)
    """

    coefs: FloatArr
    psu_index: IntArr
    method: str
    fay_coef: float = 0.0
    df: int | None = None  # None means "use default"


# ---------------------------------------------------------------------
# BRR methods
# ---------------------------------------------------------------------


def _brr_nb_reps(*, n_reps: int | None, psu: NDArray, stratum: NDArray | None = None) -> int:
    """
    Ensure a valid number of BRR replicates (R) given the PSU/stratum layout.

    Raises:
        AssertionError: If the design is not paired (2 PSUs per stratum).
    """
    if stratum is None:
        n_psus = np.unique(psu).size
        H = (n_psus + 1) // 2
    else:
        # Validate that EACH stratum has exactly 2 PSUs
        unique_strata = np.unique(stratum)
        H = unique_strata.size

        for s in unique_strata:
            mask = stratum == s
            n_psus_in_stratum = np.unique(psu[mask]).size
            if n_psus_in_stratum != 2:
                raise AssertionError(
                    f"BRR requires exactly 2 PSUs per stratum. "
                    f"Stratum {s!r} has {n_psus_in_stratum} PSUs."
                )

    if n_reps is None:
        return int(4 * (H // 4 + 1))

    R = int(n_reps)
    if R < H:
        R = H

    if R <= 28:
        if R % 4 != 0:
            R = 4 * (R // 4 + 1)
    else:
        R = 1 << (R - 1).bit_length()

    return R


def _brr_replicate_spec(
    *,
    n_reps: int,
    psu: NDArray,
    stratum: NDArray | None = None,
    fay_coef: float = 0.0,
    df: int | None = None,
) -> ReplicateSpec:
    """
    Create BRR replicate specification with proper PSU ordering.

    Args:
        n_reps: Number of replicates (must satisfy BRR constraints)
        psu: PSU identifiers (any hashable type)
        stratum: Stratum identifiers, or None for unstratified
        fay_coef: Fay's adjustment coefficient in [0, 1)
        df: Degrees of freedom (default: n_psus - n_strata)

    Returns:
        ReplicateSpec with properly ordered coefficients
    """
    if not (0.0 <= fay_coef < 1.0):
        raise ValueError("Fay coefficient must be in [0, 1).")

    # Build ordered PSU list
    if stratum is None:
        unique_psus = np.unique(psu)
        n_psus = len(unique_psus)
        n_strata = (n_psus + 1) // 2
        ordered_psus = unique_psus
    else:
        unique_strata = np.unique(stratum)
        n_strata = len(unique_strata)

        ordered_psus = []
        for s in unique_strata:
            mask = stratum == s
            psus_in_stratum = np.unique(psu[mask])
            psus_in_stratum = np.sort(psus_in_stratum)
            ordered_psus.extend(psus_in_stratum)

        ordered_psus = np.array(ordered_psus)

    n_psus_total = len(ordered_psus)

    # Create PSU id -> row index mapping
    psu_to_row = {psu_id: idx for idx, psu_id in enumerate(ordered_psus)}

    # Generate Hadamard-based coefficients
    H_matrix: FloatArr = np.asarray(hdd.hadamard(n_reps), dtype=np.float64)
    hadamard_signs: FloatArr = H_matrix[:, 1 : n_strata + 1]

    coef_plus = fay_coef
    coef_minus = 2.0 - fay_coef

    is_plus_sign = hadamard_signs == 1.0

    rep_coef_psu1 = np.where(is_plus_sign, coef_plus, coef_minus)
    rep_coef_psu2 = np.where(is_plus_sign, coef_minus, coef_plus)

    out_interleaved = np.empty((n_reps, 2 * n_strata), dtype=np.float64)
    out_interleaved[:, ::2] = rep_coef_psu1
    out_interleaved[:, 1::2] = rep_coef_psu2

    # Handle odd number of PSUs
    if n_psus_total < 2 * n_strata:
        coefs = out_interleaved.T[:n_psus_total, :]
    else:
        coefs = out_interleaved.T

    # Create index array for original PSU order
    psu_index = np.array([psu_to_row[p] for p in psu], dtype=np.int64)

    # Default df: n_psus - n_strata
    if df is None:
        df = max(1, n_psus_total - n_strata)

    return ReplicateSpec(
        coefs=coefs,
        psu_index=psu_index,
        method="BRR",
        fay_coef=fay_coef,
        df=df,
    )


# ---------------------------------------------------------------------
# Jackknife
# ---------------------------------------------------------------------
def _jkn_psus_replicates(*, n_psus: int) -> FloatArr:
    """
    JKn replicate scaling among n_psus PSUs, returning a (n_psus, n_psus) matrix.

    Coefficient = n/(n-1) if unit is NOT dropped, 0 if unit IS dropped.
    """
    if n_psus <= 1:
        raise ValueError("JK requires at least 2 PSUs for variance calculation.")

    scale = float(n_psus) / float(n_psus - 1)
    jk = scale * (1.0 - np.eye(n_psus, dtype=np.float64))

    return jk


def _jkn_replicate_spec(
    *,
    psu: NDArray,
    stratum: NDArray | None,
    df: int | None = None,
) -> ReplicateSpec:
    """
    Jackknife replicate specification (block-diagonal by stratum).

    Args:
        psu: PSU identifiers
        stratum: Stratum identifiers, or None
        df: Degrees of freedom (default: n_psus - n_strata)

    Returns:
        ReplicateSpec with JKn coefficients
    """
    if stratum is None:
        psu_ids = np.unique(psu)
        n_psus = psu_ids.size
        n_strata = 0

        jk_coefs = _jkn_psus_replicates(n_psus=n_psus)
        ordered_psus = psu_ids

    else:
        strata = np.unique(stratum)
        n_strata = len(strata)
        blocks: list[FloatArr] = []
        ordered_psus = []

        for s in strata:
            mask = stratum == s
            psu_ids_s = np.unique(psu[mask])
            n_psus_s = psu_ids_s.size

            if n_psus_s <= 1:
                raise ValueError(
                    f"Jackknife requires at least 2 PSUs per stratum. "
                    f"Stratum {s!r} has only {n_psus_s}."
                )

            psu_ids_s = np.sort(psu_ids_s)
            blocks.append(_jkn_psus_replicates(n_psus=n_psus_s))
            ordered_psus.extend(psu_ids_s)

        ordered_psus = np.array(ordered_psus)

        # Block diagonal assembly
        try:
            from scipy.linalg import block_diag

            jk_coefs = block_diag(*blocks)
        except ImportError:
            total_psus = sum(b.shape[0] for b in blocks)
            jk_coefs = np.zeros((total_psus, total_psus), dtype=np.float64)
            row_offset = 0
            for b in blocks:
                n = b.shape[0]
                jk_coefs[row_offset : row_offset + n, row_offset : row_offset + n] = b
                row_offset += n

    n_psus_total = len(ordered_psus)

    # Create PSU mapping
    psu_to_row = {psu_id: idx for idx, psu_id in enumerate(ordered_psus)}
    psu_index = np.array([psu_to_row[p] for p in psu], dtype=np.int64)

    # Default df: n_psus - n_strata
    if df is None:
        df = max(1, n_psus_total - n_strata)

    return ReplicateSpec(
        coefs=jk_coefs,
        psu_index=psu_index,
        method="JKn",
        fay_coef=0.0,
        df=df,
    )


# ---------------------------------------------------------------------
# Bootstrap methods
# ---------------------------------------------------------------------
def _boot_psus_replicates(
    *,
    n_psus: int,
    n_reps: int,
    samp_rate: float | int = 0,
    size_gap: int = 1,
    rstate: RandomState = None,
) -> FloatArr:
    """
    PSU-level bootstrap replicate coefficients using Rao-Wu-Yue adjustment.

    Returns array of shape (n_psus, n_reps).
    """
    if n_psus <= size_gap:
        raise AssertionError("size_gap should be smaller than the number of PSUs.")

    rng = resolve_random_state(rstate)

    sample_size = n_psus - size_gap
    psu_indices = np.arange(n_psus, dtype=np.int64)
    psu_boot = rng.choice(psu_indices, size=(n_reps, sample_size), replace=True)

    psu_replicates = np.zeros((n_psus, n_reps), dtype=np.float64)

    for rep in range(n_reps):
        psu_ids, psus_counts = np.unique(psu_boot[rep, :], return_counts=True)
        psu_replicates[psu_ids, rep] = psus_counts.astype(np.float64, copy=False)

    # Rao-Wu-Yue adjustment
    ratio_sqrt = math.sqrt((1.0 - float(samp_rate)) * sample_size / (n_psus - 1.0))
    out = 1.0 - ratio_sqrt + ratio_sqrt * (n_psus / sample_size) * psu_replicates

    return out


def _boot_replicate_spec(
    *,
    n_reps: int,
    psu: NDArray,
    stratum: NDArray | None,
    samp_rate: float | int = 0,
    size_gap: int = 1,
    rstate: RandomState = None,
    df: int | None = None,
) -> ReplicateSpec:
    """
    Bootstrap replicate specification, stacked by stratum if present.

    Args:
        n_reps: Number of bootstrap replicates
        psu: PSU identifiers
        stratum: Stratum identifiers, or None
        samp_rate: Sampling rate
        size_gap: Bootstrap gap (m = n - gap)
        rstate: Random state for reproducibility
        df: Degrees of freedom (default: n_reps - 1)

    Returns:
        ReplicateSpec with bootstrap coefficients
    """
    if stratum is None:
        psu_ids = np.unique(psu)
        ordered_psus = np.sort(psu_ids)

        boot_coefs = _boot_psus_replicates(
            n_psus=len(ordered_psus),
            n_reps=n_reps,
            samp_rate=samp_rate,
            size_gap=size_gap,
            rstate=rstate,
        )

    else:
        strata = np.unique(stratum)
        rng_parent = resolve_random_state(rstate)
        child_rngs = spawn_child_rngs(rng_parent, strata)

        blocks: list[FloatArr] = []
        ordered_psus = []

        for s in strata:
            mask = stratum == s
            psu_ids_s = np.unique(psu[mask])
            psu_ids_s = np.sort(psu_ids_s)

            block = _boot_psus_replicates(
                n_psus=len(psu_ids_s),
                n_reps=n_reps,
                samp_rate=samp_rate,
                size_gap=size_gap,
                rstate=child_rngs[s],
            )
            blocks.append(block)
            ordered_psus.extend(psu_ids_s)

        ordered_psus = np.array(ordered_psus)
        boot_coefs = np.vstack(blocks) if blocks else np.zeros((0, n_reps), dtype=np.float64)

    # Create PSU mapping
    psu_to_row = {psu_id: idx for idx, psu_id in enumerate(ordered_psus)}
    psu_index = np.array([psu_to_row[p] for p in psu], dtype=np.int64)

    # Default df: n_reps - 1
    if df is None:
        df = max(1, n_reps - 1)

    return ReplicateSpec(
        coefs=boot_coefs,
        psu_index=psu_index,
        method="Bootstrap",
        fay_coef=0.0,
        df=df,
    )


# ---------------------------------------------------------------------
# Main dispatcher
# ---------------------------------------------------------------------
def create_replicate_weights(
    *,
    method: Literal["BRR", "Fay", "JKn", "JK1", "Bootstrap"],
    psu: NDArray,
    stratum: NDArray | None = None,
    n_reps: int | None = None,
    fay_coef: float = 0.0,
    samp_rate: float = 0.0,
    size_gap: int = 1,
    rstate: RandomState = None,
    df: int | None = None,
) -> ReplicateSpec:
    """
    Create replicate weight specification for variance estimation.

    Args:
        method: Replication method ("BRR", "Fay", "JKn", "Bootstrap")
        psu: PSU identifiers for each observation
        stratum: Stratum identifiers, or None
        n_reps: Number of replicates (method-specific defaults if None)
        fay_coef: Fay's coefficient for BRR (0 = standard BRR)
        samp_rate: Sampling rate for bootstrap
        size_gap: Bootstrap gap (m = n - gap)
        rstate: Random state for bootstrap reproducibility
        df: Degrees of freedom (None = use method-specific default)

    Returns:
        ReplicateSpec with coefficients and metadata

    Notes:
        Default df:
        - BRR/JKn: n_psus - n_strata (design-based)
        - Bootstrap: n_reps - 1

        Variance scale (computed when needed, not stored):
        - BRR: 1.0 (or 1/(1-fay_coef)^2 for Fay's)
        - JKn: (n-1)/n per stratum
        - Bootstrap: 1.0
    """
    _meth = method.upper()

    if _meth in ("BRR", "FAY"):
        if n_reps is None:
            n_reps = _brr_nb_reps(n_reps=None, psu=psu, stratum=stratum)
        return _brr_replicate_spec(
            n_reps=n_reps,
            psu=psu,
            stratum=stratum,
            fay_coef=fay_coef,
            df=df,
        )

    elif _meth in ("JKN", "JK1"):
        return _jkn_replicate_spec(psu=psu, stratum=stratum, df=df)

    elif _meth == "BOOTSTRAP":
        if n_reps is None:
            n_reps = 500  # Default for bootstrap
        return _boot_replicate_spec(
            n_reps=n_reps,
            psu=psu,
            stratum=stratum,
            samp_rate=samp_rate,
            size_gap=size_gap,
            rstate=rstate,
            df=df,
        )

    else:
        raise ValueError(f"Unknown replication method: {method}")


def compute_variance_scale(method: str, fay_coef: float = 0.0) -> float:
    """
    Compute variance scale factor for a replication method.

    This is used in variance estimation formulas. For example:
        var(θ̂) = scale * (1/R) * Σ(θ̂_r - θ̂)²

    Args:
        method: Replication method ("BRR", "JKn", "Bootstrap")
        fay_coef: Fay's coefficient (only used for BRR)

    Returns:
        Variance scale factor

    Notes:
        - BRR (standard): scale = 1.0
        - BRR (Fay's): scale = 1 / (1 - fay_coef)²
        - JKn: scale = 1.0 (the (n-1)/n is in the coefficient matrix)
        - Bootstrap: scale = 1.0
    """
    _meth = method.upper()

    if _meth == "BRR":
        if fay_coef == 0.0:
            return 1.0
        else:
            return 1.0 / ((1.0 - fay_coef) ** 2)

    elif _meth in ("JKN", "JK1"):
        # The (n-1)/n scaling is already in the coefficient matrix
        return 1.0

    elif _meth == "BOOTSTRAP":
        return 1.0

    else:
        raise ValueError(f"Unknown method: {_meth}")
