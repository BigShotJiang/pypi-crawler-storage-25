from .notification import Notifications
from .update_parametrs import UpdatedParameters
from .update import Update


# class Updates(
#     Update,
#     UpdatedParameters,
#     Notifications
# ):
#     pass

__all__ = [
    "Update",
    "UpdatedParameters",
    "Notifications"
]