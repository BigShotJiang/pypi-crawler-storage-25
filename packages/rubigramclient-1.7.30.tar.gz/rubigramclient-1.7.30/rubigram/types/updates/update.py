from typing import Optional, Any, cast
from dataclasses import dataclass, field

import rubigram
from rubigram.types import Message

from rubigram.enums import ParseMode, MessageAction
from rubigram.types.chats.chat_update import ChatUpdate
from rubigram.types.messages.message_update import MessageUpdate
from .notification import Notifications
from rubigram.types.base import Base


@dataclass(repr=False)
class Update(Base):
    action: MessageAction
    message: Message
    user_guid: str
    # chat_updates: "ChatUpdate"
    # message_updates: "MessageUpdate"
    # show_notifications: "Notifications"
    client: "rubigram.Client" = field(repr=False)
    raw: dict = field(repr=False)

    @classmethod
    def read(cls, data: dict[str, Any], **kwargs) -> "Update":
        data.update(kwargs)
        # chat = data.get("chat_updates", [])
        # notification = data.get("show_notifications", [{}])

        update = data.get("message_updates", [])[0]
        message = update.get("message") if update else None

        return cls(
            action=MessageAction(update.get("action")),
            message=Message.read(message) if message else None,
            user_guid=data.get("user_guid"),
            client=cast(rubigram.Client, data.get("client")),
            raw=data
        )

        # return cls(
        #     chat_updates=ChatUpdate.read(chat[0]),
        #     message_updates=MessageUpdate.read(message[0]),
        #     show_notifications=Notifications.read(notification[0]),
        #     user_guid=data.get("user_guid"),
        #     client=cast(rubigram.Client, data.get("client")),
        #     raw=data,
        # )

    async def reply_text(
        self,
        text: str,
        quote: bool = True,
        metadata: ... = None,
        parse_mode: Optional["ParseMode"] = None,
        auto_delete: Optional[int] = None,
    ):
        message = self.message
        if not quote:
            reply_id = None
        else:
            reply_id = message.message_id
        return await self.client.send_message(
            guid=message.author_object_guid,
            text=text,
            reply_to_message_id=reply_id,
            metadata=metadata,
            parse_mode=parse_mode,
            auto_delete=auto_delete,
        )
