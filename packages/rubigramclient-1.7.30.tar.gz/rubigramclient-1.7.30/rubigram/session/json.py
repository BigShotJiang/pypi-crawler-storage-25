import json


class Json:
    ...