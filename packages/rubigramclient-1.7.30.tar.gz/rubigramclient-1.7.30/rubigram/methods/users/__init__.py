from .get_me import GetMe
from .get_user_info import GetUserInfo
from .update_username import UpdateUsername


class Users(
    GetMe,
    GetUserInfo,
    UpdateUsername
):
    pass