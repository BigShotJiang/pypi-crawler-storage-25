from .get_chats_updates import GetChatsUpdates
from .add_channel import AddChannel
from .add_group import AddGroup
from .join_group import JoinGroup
from .leave_group import LeaveGroup
from .set_channel_admin import SetChannelAdmin
from .update_channel_username import UpdateChannelUsername
from .join_channel import JoinChannel
from .get_chats import GetChats
from .get_chat_info import GetChatInfo
from .delete_chat_history import DeleteChatHistory


class Chats(
    GetChatsUpdates,
    AddChannel,
    AddGroup,
    JoinGroup,
    LeaveGroup,
    SetChannelAdmin,
    UpdateChannelUsername,
    JoinChannel,
    GetChats,
    GetChatInfo,
    DeleteChatHistory
):
    pass