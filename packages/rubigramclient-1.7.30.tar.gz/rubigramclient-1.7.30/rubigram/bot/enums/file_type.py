#  RubigramClient - Rubika API library for python
#  Copyright (C) 2025-present Javad <https://github.com/DevJavad>
#  Github - https://github.com/DevJavad/rubigram


from enum import Enum


class FileType(Enum):
    FILE = "File"
    IMAGE = "Image"
    VIDEO = "Video"
    GIF = "Gif"
    MUSIC = "Music"
    VOICE = "Voice"
    OTHER = "Other"