


class Websocket:
    ...