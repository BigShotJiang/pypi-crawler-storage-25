from enum import Enum


class FileType(Enum):
    GIF = "Gif"
    FILE = "File"
    IMAGE = "Image"
    VIDEO = "Video"
    MUSIC = "Music"
    VOCIE = "Voice"
    TEXT = "Text"
    OTHER = "Other"
    VIDEO_MESSAGE = "VideoMessage"