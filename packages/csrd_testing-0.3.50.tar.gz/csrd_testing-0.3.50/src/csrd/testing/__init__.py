"""Minimal csrd.testing stub package."""

__all__: tuple[str, ...] = ()
