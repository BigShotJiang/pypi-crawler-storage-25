# csrd-testing

Minimal stub package reserved for future testing utilities in the `csrd` ecosystem.
