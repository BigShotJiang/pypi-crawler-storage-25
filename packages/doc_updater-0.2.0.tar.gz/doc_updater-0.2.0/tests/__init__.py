"""Tests for doc-updater."""
