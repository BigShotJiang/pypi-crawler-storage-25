class IsNotArrayError(Exception):
    pass

class ArrayTypeError(Exception):
    pass


def check(array):
    if isinstance(array, (int, str, bool, float)):
        raise IsNotArrayError