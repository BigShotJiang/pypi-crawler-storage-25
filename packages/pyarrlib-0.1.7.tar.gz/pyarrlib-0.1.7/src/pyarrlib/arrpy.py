from ._checks import IsNotArrayError, ArrayTypeError, check


def reverse_arr(array):
    check(array)
    return array[::-1]

def sum_arr(array):
    check(array)   
    res = 0
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else: res += i
    return res

def multiplication_arr(array):
    check(array)
    res = 1
    for i in array:
        if not isinstance(i, (int, float)):
            return ArrayTypeError
        else:
            res *= i
    return res

def min(array):
    check(array)
    res = array[0]
    for i in array:
        if not isinstance(i, (int, float)):
            raise ArrayTypeError
        elif i < res:
            res = i
    return res

def max(array):
    check(array)
    res = array[0]
    for i in array:
        if not isinstance(i, (int, float)):
            raise ArrayTypeError
        if i > res:
            res = i 
    return res

def arifmetic_mean(array):
    check(array)
    s = sum_arr(array)
    return s / len(array)


def sort(array):
    check(array)
    def mi(array):
        min_indexes = []
        min_n = array[0]

        for i, n in enumerate(array):
            if n > min_n:
                continue
            elif n < min_n:
                min_indexes.clear()
                min_n = n
            min_indexes.append(i)

        return min_indexes, min_n

    tmp_lst = []

    while array:
        indexes, n = mi(array)
        for i in range(len(indexes)):
            ind = indexes[len(indexes) - i - 1]
            array.pop(ind)
            tmp_lst.append(n)

    array[:] = tmp_lst

def same(array1, array2):
    check(array1)
    check(array2)
    return array1 & array2

def step_filter(array, step:int, first_num=0):
    check(array)
    array[first_num:step]