# WebSocket RPC implementation
