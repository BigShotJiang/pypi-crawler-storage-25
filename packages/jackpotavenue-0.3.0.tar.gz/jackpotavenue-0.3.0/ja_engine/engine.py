import random
from typing import List, Tuple


def draw_powerball() -> Tuple[List[int], int]:
    nums = random.sample(range(1, 70), 5)
    bonus = random.randint(1, 26)
    return nums, bonus


def draw_megamillions() -> Tuple[List[int], int]:
    nums = random.sample(range(1, 71), 5)
    bonus = random.randint(1, 25)
    return nums, bonus


def draw_multimatch() -> List[int]:
    return sorted(random.sample(range(1, 44), 6))


def draw_gh_lottery(count: int = 5) -> List[int]:
    return sorted(random.sample(range(1, 91), count))


def draw_bonusmatch5() -> Tuple[List[int], int]:
    nums = random.sample(range(1, 40), 5)
    bonus = random.randint(1, 39)
    return nums, bonus
