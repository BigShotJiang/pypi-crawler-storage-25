import sys
import time
import random
import shutil

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.prompt import Prompt, IntPrompt
from rich.live import Live

# --- CLEAN ENGINE IMPORT PROTOCOL ---
try:
    from ja_engine.engine import (
        draw_powerball,
        draw_megamillions,
        draw_multimatch,
        draw_gh_lottery,
        draw_bonusmatch5,
    )
except ImportError:
    try:
        from jackpotavenue.engine import (  # type: ignore
            draw_powerball,
            draw_megamillions,
            draw_multimatch,
            draw_gh_lottery,
            draw_bonusmatch5,
        )
    except ImportError:
        from engine import (
            draw_powerball,
            draw_megamillions,
            draw_multimatch,
            draw_gh_lottery,
            draw_bonusmatch5,
        )


def get_dynamic_console() -> Console:
    width, _ = shutil.get_terminal_size(fallback=(44, 20))
    return Console(width=min(width, 44), force_terminal=True)


console = get_dynamic_console()


def print_banner() -> None:
    banner = r"""
 __  __  ___  _   _  _   _  __   __
|  \/  |/ _ \| \ | || \ | | \ \ / /
| |\/| | | | |  \| ||  \| |  \ V / 
| |  | | |_| | |\  || |\  |   | |  
|_|  |_|\___/|_| \_||_| \_|   |_|  
"""
    console.print(f"[bold green]{banner}[/bold green]")
    console.print(
        "[bold white on blue] >>> JACKPOT AVENUE: v0.2.9 <<< [/]",
        justify="center",
    )


def format_ticket(numbers, bonus=None, theme="blue") -> str:
    nums_str = " ".join(
        f"[bold white on {theme}] {n:02} [/]" for n in sorted(numbers)
    )
    if bonus is not None:
        return f"{nums_str} [bold white]●[/] [bold white on red] {bonus:02} [/]"
    return nums_str


def generate_spinning_content(game_label: str, theme: str, has_bonus: bool) -> str:
    count = 6 if "MULTI" in game_label.upper() else 5
    fake_nums = [random.randint(1, 60) for _ in range(count)]
    fake_bonus = random.randint(1, 25) if has_bonus else None
    return format_ticket(fake_nums, fake_bonus, theme)


def main() -> None:
    while True:
        console.clear()
        print_banner()

        games = {
            "1": ("POWERBALL", draw_powerball, "blue", True),
            "2": ("MEGA MILLIONS", draw_megamillions, "magenta", True),
            "3": ("MULTI-MATCH", draw_multimatch, "dark_green", False),
            "4": ("GHANA 5/90", lambda: draw_gh_lottery(5), "red", False),
            "5": ("BONUS MATCH 5", draw_bonusmatch5, "cyan", True),
        }

        menu = Table(
            title="\n[bold white]--- SELECT GAME ---[/]",
            show_header=False,
            box=None,
        )
        menu.add_row("[blue]1)[/] Powerball", "[bold red][US][/]")
        menu.add_row("[magenta]2)[/] Mega Millions", "[bold red][US][/]")
        menu.add_row("[green]3)[/] Multi-Match", "[blue][MD][/]")
        menu.add_row("[red]4)[/] GH Lottery", "[white][GH][/]")
        menu.add_row("[cyan]5)[/] Bonus Match 5", "[blue][MD][/]")
        menu.add_row("[bold white]6) EXIT[/]", "")

        console.print(menu)

        choice = Prompt.ask(
            "[bold green]Choice[/]",
            choices=["1", "2", "3", "4", "5", "6"],
            default="6",
        )

        if choice == "6":
            console.print("\n[bold red]💸 GOOD LUCK! 💸[/]\n")
            break

        num_tickets = IntPrompt.ask("[bold cyan]Tickets[/]", default=1)
        label, func, theme, has_bonus = games[choice]

        for i in range(1, num_tickets + 1):

            # --- ANIMATION ---
            with Live(console=console, refresh_per_second=20, transient=True) as live:
                for _ in range(12):
                    live.update(
                        Panel(
                            generate_spinning_content(label, theme, has_bonus),
                            title=f"[bold yellow]DRAWING #{i}[/]",
                            border_style="yellow",
                            expand=False,
                            padding=(0, 1),
                        )
                    )
                    time.sleep(0.05)

                # Final result
                result = func()
                nums, bonus = (result if has_bonus else (result, None))

                final_panel = Panel(
                    format_ticket(nums, bonus, theme),
                    title=f"[bold white]{label} FINAL[/]",
                    border_style="green",
                    expand=False,
                    padding=(0, 1),
                )

                # Show final result inside Live (temporary)
                live.update(final_panel)

            # --- PERMANENT FINAL RESULT (STAYS ON SCREEN) ---
            console.print(final_panel)

        # After all tickets, pause before menu returns
        console.print("\n[dim]Press Enter to return to menu...[/]")
        input()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n[bold red]Terminated.[/]")
        sys.exit(0)
