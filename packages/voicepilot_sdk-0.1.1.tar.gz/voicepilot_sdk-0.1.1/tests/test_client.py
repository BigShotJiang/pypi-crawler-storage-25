import pytest
import responses
from voicepilot import VoicePilotClient
from voicepilot.exceptions import ValidationError, AuthenticationError, APIError

BASE_URL = "http://localhost:8000/api/v1"
API_KEY = "sk_platform_test_key"

@pytest.fixture
def client():
    return VoicePilotClient(api_key=API_KEY, base_url=BASE_URL)

@responses.activate
def test_tts_success(client):
    responses.add(
        responses.POST,
        f"{BASE_URL}/tts",
        json={"audios": ["base64_data"]},
        status=200
    )
    
    resp = client.tts.create("Hello")
    assert resp.audio_base64 == "base64_data"
    assert resp.text == "Hello"

def test_invalid_key():
    with pytest.raises(ValidationError):
        VoicePilotClient(api_key="wrong_prefix")

@responses.activate
def test_auth_error(client):
    responses.add(
        responses.POST,
        f"{BASE_URL}/tts",
        status=401
    )
    
    with pytest.raises(AuthenticationError):
        client.tts.create("Hello")

@responses.activate
def test_server_error(client):
    responses.add(
        responses.POST,
        f"{BASE_URL}/tts",
        status=500,
        body="Internal Server Error"
    )
    
    with pytest.raises(APIError):
        client.tts.create("Hello")

def test_empty_input(client):
    with pytest.raises(ValidationError):
        client.tts.create("")
