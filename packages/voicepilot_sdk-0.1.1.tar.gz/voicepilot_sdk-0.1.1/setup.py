from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="voicepilot-sdk",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "urllib3>=1.26.0",
    ],
    extras_require={
        "ws": ["websocket-client>=1.3.0"],
        "dev": ["pytest", "responses"],
    },
    python_requires=">=3.8",
    author="VoicePilot Team",
    author_email="support@intelligens.app",
    description="Official Python SDK for high-fidelity voice and conversational AI.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://openclaw.intelligens.app",
    project_urls={
        "Homepage": "https://openclaw.intelligens.app",
        "Source": "https://github.com/voicepilot/voicepilot-python",
        "Bug Tracker": "https://github.com/voicepilot/voicepilot-python/issues",
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Multimedia :: Sound/Audio :: Speech",
    ],
)
