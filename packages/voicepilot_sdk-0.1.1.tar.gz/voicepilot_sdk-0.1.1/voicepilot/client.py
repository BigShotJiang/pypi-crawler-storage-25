import requests
import json
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from typing import List, Optional, Generator
from contextlib import contextmanager

from .exceptions import (
    AuthenticationError, ValidationError, RateLimitError, 
    APIError, ConnectionError, VoicePilotError
)
from .types import TTSResponse, STTResponse, Agent, ConversationResponse, WSMessage, SessionToken

class VoicePilotClient:
    """
    The official VoicePilot SDK client.
    
    Initialize once and use namespaced services (tts, stt, agents).
    """

    def __init__(self, api_key: str, base_url: str = "https://openclaw.intelligens.app/api/v1"):
        if not api_key.startswith("sk_platform_"):
            raise ValidationError("Invalid API key format. Must start with 'sk_platform_'")
        
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.session = self._init_session()

        # Namespaced services
        self.tts = TTSService(self)
        self.stt = STTService(self)
        self.agents = AgentService(self)
        self.sessions = SessionService(self)
        self.keys = KeyService(self)
        self.webhooks = WebhookService(self)
        self.conversations = ConversationLogService(self)
        self.usage = UsageService(self)

    def _init_session(self) -> requests.Session:
        session = requests.Session()
        retries = Retry(total=3, backoff_factor=1, status_forcelist=[502, 503, 504])
        session.mount("http://", HTTPAdapter(max_retries=retries))
        session.mount("https://", HTTPAdapter(max_retries=retries))
        session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        })
        return session

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.base_url}/{path.lstrip('/')}"
        try:
            response = self.session.request(method, url, timeout=30, **kwargs)
            self._handle_error(response)
            return response.json()
        except requests.exceptions.ConnectionError as e:
            raise ConnectionError(f"Failed to connect to VoicePilot: {e}")
        except requests.exceptions.RequestException as e:
            raise VoicePilotError(f"Unexpected request error: {e}")

    def _handle_error(self, response: requests.Response):
        if response.status_code == 200:
            return
        
        if response.status_code == 401:
            raise AuthenticationError("Invalid or expired API token.")
        
        if response.status_code == 422:
            detail = response.json().get("detail", "Validation failed")
            raise ValidationError(f"API Validation Error: {detail}", detail=detail)
        
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 5))
            raise RateLimitError("Too many requests. Please slow down.", retry_after=retry_after)
        
        if response.status_code >= 500:
            raise APIError(response.text, status_code=response.status_code)

class TTSService:
    def __init__(self, client: VoicePilotClient):
        self.client = client

    def create(self, text: str, voice: str = "anushka") -> TTSResponse:
        """
        Synthesize text into speech.
        
        Args:
            text (str): The text to synthesize.
            voice (str): Speaker ID (default: 'anushka').
            
        Returns:
            TTSResponse: Dataclass containing base64 audio and metadata.
            
        Raises:
            ValidationError: If text is empty.
            
        Example:
            audio = client.tts.create("Hello world")
        """
        if not text.strip():
            raise ValidationError("TTS 'text' cannot be empty.")
        
        data = self.client._request("POST", "/tts", json={"text": text, "voice": voice})
        return TTSResponse(audio_base64=data["audios"][0], text=text, voice=voice)

    def stream(self, text: str, voice: str = "anushka") -> Generator[bytes, None, None]:
        """
        Synthesize text into a streaming WAV audio response.
        
        Args:
            text (str): The text to synthesize.
            voice (str): Speaker ID (default: 'anushka').
            
        Yields:
            bytes: Chunks of the WAV audio file format.
            
        Example:
            with open("output.wav", "wb") as f:
                for chunk in client.tts.stream("Hello world!"):
                    f.write(chunk)
        """
        if not text.strip():
            raise ValidationError("TTS 'text' cannot be empty.")
            
        url = f"{self.client.base_url}/tts/stream"
        response = self.client.session.post(url, json={"text": text, "voice": voice}, stream=True)
        self.client._handle_error(response)
        
        for chunk in response.iter_content(chunk_size=8192):
            if chunk:
                yield chunk

class STTService:
    def __init__(self, client: VoicePilotClient):
        self.client = client

    def transcribe(self, file_path: str) -> STTResponse:
        """
        Transcribe an audio file to text.
        
        Args:
            file_path (str): Path to local .wav or .mp3 file.
            
        Returns:
            STTResponse: The transcription result.
            
        Example:
            text = client.stt.transcribe("my_audio.wav")
        """
        try:
            url = f"{self.client.base_url}/stt"
            with open(file_path, 'rb') as f:
                # Use session directly so requests sets the multipart Content-Type/boundary automatically
                # (do NOT set Content-Type: application/json for file uploads)
                resp = self.client.session.post(
                    url,
                    files={"audio": f},
                    headers={"Content-Type": None},
                    timeout=30
                )
                self.client._handle_error(resp)
                data = resp.json()
                return STTResponse(transcript=data["transcript"], confidence=data.get("confidence", 1.0))
        except FileNotFoundError:
            raise ValidationError(f"Audio file not found at: {file_path}")

class AgentService:
    def __init__(self, client: VoicePilotClient):
        self.client = client

    def list(self) -> List[Agent]:
        """List all owned agents."""
        data = self.client._request("GET", "/list_agents")
        return [Agent(id=a["id"], name=a["name"], system_prompt=a["system_prompt"]) for a in data]

    def create(self, name: str, system_prompt: str) -> Agent:
        """Create a new custom agent."""
        data = self.client._request("POST", "/create_agent", json={"name": name, "system_prompt": system_prompt})
        return Agent(id=data["agent_id"], name=data["name"], system_prompt=data["system_prompt"])

    def delete(self, agent_id: str) -> bool:
        """Delete an agent by ID."""
        self.client._request("DELETE", f"/agents/{agent_id}")
        return True

    def chat(self, agent_id: str, text: str, history: Optional[List[dict]] = None) -> ConversationResponse:
        """
        Stateless single-turn conversation with an agent using REST (no WebSockets).
        
        Args:
            agent_id (str): The target agent to chat with.
            text (str): The user's message.
            history (List[dict]): Previous turns in `{"role": "...", "content": "..."}` format.
            
        Returns:
            ConversationResponse: Contains reply_text, audio_base64, and the updated history.
        """
        from .types import ConversationResponse
        payload = {"user_text": text, "history": history or []}
        data = self.client._request("POST", f"/agents/{agent_id}/conversational", json=payload)
        return ConversationResponse(
            reply_text=data["reply_text"],
            audio_base64=data.get("audio_base64"),
            provider=data.get("provider", "gemini"),
            history=data.get("history", [])
        )

    @contextmanager
    def connect(self, agent_id: Optional[str] = None, use_session_token: bool = False) -> Generator['LiveSession', None, None]:
        """
        Connect to a real-time conversation WebSocket.
        Automatically creates a conversation record first (create-first pattern).
        
        Args:
            agent_id (str, optional): Target agent ID.
            use_session_token (bool): If True, auto-creates a session token.
            
        Yields:
            LiveSession: An active WebSocket session context.
        """
        try:
            import websocket
        except ImportError:
            raise ImportError("Websocket support requires 'websocket-client'. Install it with: pip install voicepilot[ws]")
        
        # 1. Determine token
        if use_session_token:
            session_token = self.client.sessions.create(expires_in=300)
            ws_token = session_token.token
        else:
            ws_token = self.client.api_key

        # 2. Create conversation record via REST (create-first pattern)
        conv_data = self.client.conversations.create(agent_id=agent_id)
        conversation_id = conv_data.get("conversation_id", "")

        # 3. Open WebSocket with conversation_id (derive WS URL from base_url)
        session = LiveSession(ws_token, agent_id, conversation_id=conversation_id, base_url=self.client.base_url)
        try:
            session.open()
            yield session
        finally:
            session.close()


class SessionService:
    """Manage short-lived session tokens for browser-safe WebSocket connections."""

    def __init__(self, client: VoicePilotClient):
        self.client = client

    def create(self, expires_in: int = 300) -> SessionToken:
        """
        Exchange the permanent API key for a short-lived session token.

        Args:
            expires_in (int): TTL in seconds (default: 300, range: 30-3600).

        Returns:
            SessionToken: A temporary token safe for browser-side use.

        Raises:
            ValidationError: If expires_in is out of range.

        Example:
            token = client.sessions.create(expires_in=600)
            # Pass token.token to your frontend for WebSocket connections
        """
        if expires_in < 30 or expires_in > 3600:
            raise ValidationError("expires_in must be between 30 and 3600 seconds.")
        data = self.client._request("POST", "/session/create", json={"expires_in": expires_in})
        return SessionToken(
            token=data["session_token"],
            expires_in=data["expires_in"],
            expires_at=data["expires_at"],
        )

    def revoke(self, token: str) -> bool:
        """
        Explicitly revoke a session token before it expires.

        Args:
            token (str): The session token to revoke.

        Returns:
            bool: True if the token was successfully revoked.

        Example:
            client.sessions.revoke("sess_abc123...")
        """
        self.client._request("POST", "/session/revoke", json={"token": token})
        return True


class KeyService:
    """Manage scoped API keys."""

    def __init__(self, client: VoicePilotClient):
        self.client = client

    def create(self, scope: str = "read", label: str = "") -> dict:
        """Create an additional API key with a specific scope ('full' or 'read')."""
        return self.client._request("POST", "/keys/create", json={"scope": scope, "label": label})

    def list(self) -> list:
        """List all API keys for the user."""
        return self.client._request("GET", "/keys/list")

    def revoke(self, api_key_prefix: str) -> dict:
        """Revoke a scoped API key by its prefix."""
        return self.client._request("DELETE", "/keys/revoke", json={"api_key_prefix": api_key_prefix})


class WebhookService:
    """Register and manage webhook URLs for platform events."""

    def __init__(self, client: VoicePilotClient):
        self.client = client

    def register(self, url: str) -> dict:
        """Register a webhook URL to receive events like 'conversation.ended'."""
        return self.client._request("POST", "/webhook/register", json={"url": url})

    def get(self) -> dict:
        """Get the currently registered webhook URL."""
        return self.client._request("GET", "/webhook")

    def remove(self) -> dict:
        """Remove the registered webhook URL."""
        return self.client._request("DELETE", "/webhook")


class ConversationLogService:
    """Create, end, and fetch conversation logs."""

    def __init__(self, client: VoicePilotClient):
        self.client = client

    def create(self, agent_id: Optional[str] = None) -> dict:
        """Create a new conversation record (call before WS connect)."""
        payload = {}
        if agent_id:
            payload["agent_id"] = agent_id
        return self.client._request("POST", "/conversations/create", json=payload)

    def end(self, conversation_id: str) -> dict:
        """Explicitly end an active conversation."""
        return self.client._request("POST", f"/conversations/{conversation_id}/end")

    def list(self, limit: int = 50) -> dict:
        """List past conversation logs."""
        return self.client._request("GET", f"/conversations?limit={limit}")

    def get(self, log_id: str) -> dict:
        """Fetch a single conversation log with full turns."""
        return self.client._request("GET", f"/conversations/{log_id}")


class UsageService:
    """View API usage statistics."""

    def __init__(self, client: VoicePilotClient):
        self.client = client

    def get(self) -> dict:
        """Get usage statistics including request counts and rate limit status."""
        return self.client._request("GET", "/usage")


class LiveSession:
    """Real-time WebSocket session for conversational agents."""

    def __init__(self, token: str, agent_id: Optional[str], conversation_id: str = "", base_url: str = "https://openclaw.intelligens.app/api/v1"):
        # Derive WebSocket URL from the HTTP base_url
        ws_base = base_url.replace("https://", "wss://").replace("http://", "ws://")
        ws_base = ws_base.replace("/api/v1", "").replace("/api/v1/", "")
        self.url = f"{ws_base}/ws/conversation?token={token}"
        if agent_id:
            self.url += f"&agent_id={agent_id}"
        if conversation_id:
            self.url += f"&conversation_id={conversation_id}"
        self.conversation_id = conversation_id
        self.ws = None
        self._turn_counter = 0

    def _next_turn_id(self) -> str:
        self._turn_counter += 1
        return f"turn_{self._turn_counter:04d}"

    def open(self):
        import websocket
        self.ws = websocket.create_connection(self.url)

    def send(self, text: str):
        """
        Send finalized user text to the agent.

        Args:
            text: The user's message.

        Raises:
            ConnectionError: If WebSocket is not connected.

        Example:
            session.send("What is the capital of France?")
        """
        if not self.ws:
            raise ConnectionError("WebSocket is not connected.")
        turn_id = self._next_turn_id()
        self.ws.send(json.dumps({
            "type": "transcript.final",
            "text": text,
            "turn_id": turn_id,
        }))

    def listen(self) -> Generator[WSMessage, None, None]:
        """
        Yield structured WSMessage objects from the server event stream.

        Yields:
            WSMessage: Typed event matching the VoicePilot event schema.

        Example:
            for msg in session.listen():
                if msg.type == "agent.response":
                    print(msg.text)
        """
        while self.ws and self.ws.connected:
            raw = self.ws.recv()
            data = json.loads(raw)
            yield WSMessage(
                type=data.get("type", "unknown"),
                id=data.get("id", ""),
                speaker=data.get("speaker", ""),
                text=data.get("text"),
                turn_id=data.get("turn_id", ""),
                timestamp=data.get("timestamp", ""),
                is_final=data.get("is_final", True),
                confidence=data.get("confidence"),
                source=data.get("source"),
                latency_ms=data.get("latency_ms"),
                llm_provider=data.get("llm_provider"),
                tts_provider=data.get("tts_provider"),
                audio_base64=data.get("audio_base64"),
                error=data.get("msg"),
            )

    def close(self):
        if self.ws:
            self.ws.close()
