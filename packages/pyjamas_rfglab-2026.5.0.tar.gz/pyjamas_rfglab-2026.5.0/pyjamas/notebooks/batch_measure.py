import marimo

__generated_with = "0.20.4"
app = marimo.App(width="full")


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    # PyJAMAS notebook {{DATE_TIME}}
    """)
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    We start by importing the packages necessary to run and plot the analysis. We also create lists that define what we will be plotting.
    """)
    return


@app.cell
def _():
    import marimo as mo
    import numpy
    import pandas as pd
    import plotly.express as px
    import sys
    sys.path.extend(['{{PJS_PATH}}'])
    from pyjamas.rutils import RUtils

    return RUtils, mo, numpy, pd, px


@app.cell
def _():
    TIME_PLOTS = {{TIME_PLOTS}}  # self.measurement_list
    BOX_PLOTS = {{BOX_PLOTS}}  # self.box_plot_measurements
    PLOT_STYLE = '{{PLOT_STYLE}}'  # self.plot_style_value
    ERR_STYLE = '{{ERR_STYLE}}' # self.err_style_value
    return BOX_PLOTS, ERR_STYLE, PLOT_STYLE, TIME_PLOTS


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Run the analysis (uncomment the code in this cell; otherwise see below to load analysis results from disk):
    """)
    return


@app.cell
def _(RUN_ANALYSIS_CODE):
    {{RUN_ANALYSIS_CODE}}
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Or load analysis results from disk:
    """)
    return


@app.cell
def _(pd):
    all_data = pd.read_csv('{{CSV_FILE_PATH}}')
    return (all_data,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    Plot results: first, set up plots.
    """)
    return


@app.cell
def _(all_data, numpy, px):
    group_labels = numpy.unique(all_data['experimental group'])
    n_groups: int = len(group_labels)
    a_color_scale = px.colors.qualitative.D3[:n_groups]
    alpha = 0.6
    return a_color_scale, alpha, group_labels


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Means plots comparing two groups.
    You may use *fig_name.write_image("filename.ext")* after the code that creates figure *fig_name* to save the figure. *ext* can be png, svg, etc ...

    For documentation on how to edit figure properties, take a look at https://plotly.com/python/reference/
    """)
    return


@app.cell
def _(TIME_PLOTS, mo):
    # Create the dropdown
    metric = mo.ui.dropdown(
        options=TIME_PLOTS,
        value=TIME_PLOTS[0]  # default value
    )
    return (metric,)


@app.cell
def _(ERR_STYLE, RUtils, a_color_scale, alpha, metric, mo, all_data):
    fig_means_band = RUtils.plotly_lineplot_witherrors(all_data, x_feature='time (min)', y_feature=metric.value, err_feature='sem', hex_palette=a_color_scale, alpha=alpha, err_style=ERR_STYLE)

    RUtils.plotly_format_figure(fig_means_band, y_range=(0, None), x_label='time (min)', y_label=metric.value)

    mo.vstack([metric, fig_means_band])
    return (fig_means_band,)


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Plot individual curves for each of the experiments.
    You may use *fig_name.write_image("filename.ext")* after the code that creates figure *fig_name* to save the figure. *ext* can be png, svg, etc ...

    For documentation on how to edit figure properties, take a look at https://plotly.com/python/reference/
    """)
    return


@app.cell
def _(RUtils, all_data, fig_means_band, group_labels, metric, mo, px):
    fig_individuals = px.line(
        all_data,
        x='time (min)',
        y=metric.value,
        color='experimental group',
        hover_data=['file name'],  # add columns you want in the tooltip
        labels={'experimental group': 'group'},  # optional: cleaner labels
        template="simple_white",
    )

    # Customize if needed
    fig_individuals.update_traces(line=dict(width=3))
    RUtils.plotly_format_figure(fig_individuals, x_label='time (min)', y_label=metric.value)

    group_figs = []
    for _an_index, _a_group in enumerate(group_labels):
        group_figs.append(px.line(
            all_data[all_data['experimental group'] == _a_group],
            x='time (min)',
            y=metric.value,
            color='experiment index',
            hover_data=['file name'],  # add columns you want in the tooltip
            labels={'experiment index': 'index'},  # optional: cleaner labels
            template="simple_white",
        ))

        group_figs[-1].update_traces(line=dict(width=3))
        RUtils.plotly_format_figure(group_figs[-1], y_range=(0, None), x_label='time (min)', y_label=metric.value)


    mo.vstack([metric, mo.hstack([fig_means_band, fig_individuals]), mo.hstack(group_figs)])
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ## Box plots for summary metrics.
    You may use *fig_name.write_image("filename.ext")* after the code that creates figure *fig_name* to save the figure. *ext* can be png, svg, etc ... Also note that, if you want to look at the *initial* value of any time features, you can replace *BOX_PLOTS* with *TIME_PLOTS* below.

    For documentation on how to edit figure properties, take a look at https://plotly.com/python/reference/
    """)
    return


@app.cell
def _(BOX_PLOTS, mo):
    box_metrics = mo.ui.dropdown(
        options=BOX_PLOTS,
        value=BOX_PLOTS[0]  # default value
    )
    return (box_metrics,)


@app.cell
def _(PLOT_STYLE, RUtils, a_color_scale, box_metrics, mo, all_data):
    fig_box_plotly = RUtils.plotly_boxplot(all_data, hex_palette=a_color_scale, y_feature=box_metrics.value, plot_style=PLOT_STYLE)

    RUtils.plotly_format_figure(fig_box_plotly, y_range=(None, None), y_label=box_metrics.value)

    mo.vstack([box_metrics, fig_box_plotly])
    return


if __name__ == "__main__":
    app.run()
