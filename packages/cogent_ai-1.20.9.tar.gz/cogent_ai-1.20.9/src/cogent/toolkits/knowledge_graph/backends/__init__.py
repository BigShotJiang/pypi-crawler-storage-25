"""Graph backend implementations.

This module provides different storage backends for the KnowledgeGraph:
- InMemoryGraph: Fast in-memory storage using networkx (if available)
- SQLiteGraph: Persistent storage using SQLite for large graphs
- JSONFileGraph: Simple JSON file persistence with auto-save
- Neo4jGraph: Production graph database with Cypher queries
"""

from cogent.toolkits.knowledge_graph.backends.base import GraphBackend
from cogent.toolkits.knowledge_graph.backends.json_file import JSONFileGraph
from cogent.toolkits.knowledge_graph.backends.memory import InMemoryGraph

# SQLiteGraph requires sqlalchemy - only import if available
try:
    from cogent.toolkits.knowledge_graph.backends.sqlite import SQLiteGraph

    _HAS_SQLITE = True
except ImportError:
    SQLiteGraph = None  # type: ignore
    _HAS_SQLITE = False

# Neo4j is optional - only import if neo4j package is installed
try:
    from cogent.toolkits.knowledge_graph.backends.neo4j import Neo4jGraph

    _HAS_NEO4J = True
except ImportError:
    Neo4jGraph = None  # type: ignore
    _HAS_NEO4J = False

__all__ = [
    "GraphBackend",
    "InMemoryGraph",
    "JSONFileGraph",
    *(["SQLiteGraph"] if _HAS_SQLITE else []),
    *(["Neo4jGraph"] if _HAS_NEO4J else []),
]
