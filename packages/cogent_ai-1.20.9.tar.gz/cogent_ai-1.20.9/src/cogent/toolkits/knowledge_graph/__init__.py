"""
KnowledgeGraph toolkit for persistent entity/relationship memory.

This module provides a knowledge graph toolkit with multiple storage backends:
- In-memory graph (uses networkx if available)
- SQLite database for persistence and large graphs
- JSON file for simple persistence with auto-save

Example:
    ```python
    from cogent.toolkits import KnowledgeGraph

    # In-memory (default)
    kg = KnowledgeGraph()

    # SQLite for persistence
    kg = KnowledgeGraph(backend="sqlite", path="knowledge.db")

    # Or load from file (auto-detects backend)
    kg = KnowledgeGraph.from_file("knowledge.db")
    ```
"""

from cogent.toolkits.knowledge_graph.backends import (
    _HAS_SQLITE,
)
from cogent.toolkits.knowledge_graph.backends import (
    GraphBackend as GraphBackend,
)
from cogent.toolkits.knowledge_graph.backends import (
    InMemoryGraph as InMemoryGraph,
)
from cogent.toolkits.knowledge_graph.backends import (
    JSONFileGraph as JSONFileGraph,
)
from cogent.toolkits.knowledge_graph.backends import (
    SQLiteGraph as SQLiteGraph,
)
from cogent.toolkits.knowledge_graph.models import Entity as Entity
from cogent.toolkits.knowledge_graph.models import Relationship as Relationship
from cogent.toolkits.knowledge_graph.toolkit import (
    KnowledgeGraph as KnowledgeGraph,
)

_base_all = [
    # Main toolkit
    "KnowledgeGraph",
    # Models
    "Entity",
    "Relationship",
    # Backends
    "GraphBackend",
    "InMemoryGraph",
    "JSONFileGraph",
]

if _HAS_SQLITE:
    _base_all.append("SQLiteGraph")

__all__ = _base_all
