"""
Observability — Extensible, composable observability for Cogent.

Quick Start:
    ```python
    from cogent.observability import Observer

    # Show agent / tool / subagent lifecycle (default)
    observer = Observer()

    # Also show LLM request/response lines and token counts
    observer = Observer(llm_calls=True)

    # Attach to agent
    agent = Agent(name="Assistant", model=model, observer=observer)
    await agent.run("Hello!")
    ```
"""

from cogent.observability.core.bus import EventBus
from cogent.observability.core.config import (
    THEMES,
    FormatConfig,
    Layout,
    Level,
    LlmTelemetry,
    MemoryTelemetry,
    ObservabilityPolicy,
    ObserverConfig,
    RetrievalTelemetry,
    Theme,
    ToolTelemetry,
    get_preset,
    policy_for_level,
    resolve_theme,
)
from cogent.observability.core.event import Event, EventTypes, create_event
from cogent.observability.formatters import (
    AgentFormatter,
    BaseFormatter,
    Color,
    DefaultFormatter,
    Formatter,
    FormatterRegistry,
    JSONFormatter,
    MemoryFormatter,
    RetrievalFormatter,
    StreamFormatter,
    Style,
    Styler,
    TaskFormatter,
    ToolFormatter,
)
from cogent.observability.logger import (
    LogEntry,
    LogLevel,
    ObservabilityLogger,
)
from cogent.observability.observer import Observer, create_observer
from cogent.observability.sinks.base import BaseSink, Sink
from cogent.observability.sinks.callback import CallbackSink
from cogent.observability.sinks.console import ConsoleSink
from cogent.observability.sinks.file import FileSink

__all__ = [
    # Core
    "Event",
    "EventBus",
    "EventTypes",
    "FormatConfig",
    "Layout",
    "Level",
    "LlmTelemetry",
    "MemoryTelemetry",
    "ObservabilityPolicy",
    "ObserverConfig",
    "RetrievalTelemetry",
    "THEMES",
    "Theme",
    "ToolTelemetry",
    "create_event",
    "get_preset",
    "policy_for_level",
    "resolve_theme",
    # Formatters
    "AgentFormatter",
    "BaseFormatter",
    "Color",
    "DefaultFormatter",
    "Formatter",
    "FormatterRegistry",
    "JSONFormatter",
    "MemoryFormatter",
    "RetrievalFormatter",
    "StreamFormatter",
    "Style",
    "Styler",
    "TaskFormatter",
    "ToolFormatter",
    # Sinks
    "BaseSink",
    "CallbackSink",
    "ConsoleSink",
    "FileSink",
    "Sink",
    # Observer
    "Observer",
    "create_observer",
    # Logger
    "LogEntry",
    "LogLevel",
    "ObservabilityLogger",
]
