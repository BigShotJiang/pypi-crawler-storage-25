"""
Observer - Main entry point for observability.

This is a minimal, focused class that coordinates:
- Event publishing via EventBus
- Event formatting via FormatterRegistry
- Output via Sinks
- Event capture for history/state tracking (opt-in)
"""

from __future__ import annotations

import fnmatch
import sys
from collections import defaultdict, deque
from collections.abc import Callable, Iterator
from typing import TYPE_CHECKING, Literal, TextIO, overload

from cogent.observability.core.bus import EventBus
from cogent.observability.core.config import (
    FormatConfig,
    Layout,
    Level,
    LlmTelemetry,
    MemoryTelemetry,
    ObservabilityPolicy,
    ObserverConfig,
    RetrievalTelemetry,
    Theme,
    policy_for_level,
    resolve_theme,
)
from cogent.observability.core.event import Event, create_event
from cogent.observability.formatters.registry import FormatterRegistry
from cogent.observability.sinks.console import ConsoleSink

if TYPE_CHECKING:
    from cogent.observability.formatters.base import Formatter
    from cogent.observability.sinks.base import Sink


# Events that are only shown when Observer(llm_calls=True).
# These are LLM-internal details (request/response payloads, token counts, thinking).
_LLM_EVENTS: frozenset[str] = frozenset(
    {
        "llm.request",
        "llm.response",
        "llm.thinking",
        "llm.tool_decision",
        "agent.reasoning",
        "agent.acting",
    }
)

# Memory events gated by MemoryTelemetry sub-flags.
_MEMORY_CONVERSATION_EVENTS: frozenset[str] = frozenset(
    {"memory.conversation.loaded", "memory.conversation.saved"}
)
_MEMORY_ACC_EVENTS: frozenset[str] = frozenset(
    {"memory.acc.context_formatted", "memory.acc.updated"}
)
_MEMORY_CACHE_EVENTS: frozenset[str] = frozenset(
    {"memory.cache.hit", "memory.cache.miss", "memory.cache.write"}
)
_MEMORY_TOOL_EVENTS: frozenset[str] = frozenset(
    {"memory.read", "memory.write", "memory.search", "memory.delete", "memory.clear"}
)
_MEMORY_EPISODIC_EVENTS: frozenset[str] = frozenset(
    {
        "memory.episodic.recorded",
        "memory.episodic.recalled",
        "memory.episodic.reflected",
    }
)
_ALL_MEMORY_EVENTS: frozenset[str] = (
    _MEMORY_CONVERSATION_EVENTS
    | _MEMORY_ACC_EVENTS
    | _MEMORY_CACHE_EVENTS
    | _MEMORY_TOOL_EVENTS
    | _MEMORY_EPISODIC_EVENTS
)

# Infrastructure-lifecycle events that are always suppressed at progress level.
# They duplicate information already carried by tool.* / subagent.* events and
# produce noise without adding value for the end-user.
_ALWAYS_HIDDEN_EVENTS: frozenset[str] = frozenset(
    {
        "mcp.server.connecting",
        "mcp.server.connected",
        "mcp.server.disconnected",
        "mcp.tools.discovered",
        "mcp.tool.called",
        "mcp.tool.result",
    }
)

# Retrieval events gated by RetrievalTelemetry.
_RETRIEVAL_EVENTS: frozenset[str] = frozenset(
    {
        "retrieval.start",
        "retrieval.complete",
        "retrieval.error",
    }
)
_RETRIEVAL_SUMMARY_EVENTS: frozenset[str] = frozenset(
    {
        "retrieval.summary_index.start",
        "retrieval.summary_index.document_summarized",
        "retrieval.summary_index.complete",
        "retrieval.summary_index.error",
    }
)
_ALL_RETRIEVAL_EVENTS: frozenset[str] = _RETRIEVAL_EVENTS | _RETRIEVAL_SUMMARY_EVENTS


class Observer:
    """
    Main observability interface.

    Coordinates event publishing, formatting, and output.

    Example:
        ```python
        # Show agent / tool / subagent lifecycle (default)
        observer = Observer()
        observer.emit("agent.invoked", agent_name="MyAgent")

        # Also show LLM request/response lines and token breakdowns
        observer = Observer(llm_calls=True)

        # Also show timestamps on every line
        observer = Observer(llm_calls=True, timestamps=True)

        # Subscribe to events
        observer.on("tool.*", lambda e: print(f"Tool event: {e.type}"))

        # Capture events for history tracking
        observer = Observer(capture=["tool.result", "agent.*"])
        ```
    """

    def __init__(
        self,
        config: ObserverConfig | None = None,
        *,
        # Primary API — fine-grained flags
        llm_calls: bool = False,
        memory_events: bool = False,
        retrieval_events: bool | None = None,
        timestamps: bool = False,
        trace_ids: bool = False,
        # Deprecated: kept for backward compatibility; maps to flags above
        level: Literal["off", "progress", "debug", "trace"] | Level | None = None,
        # Policy-based API — mutually exclusive with level=
        policy: ObservabilityPolicy | None = None,
        # Other options
        stream: TextIO | None = None,
        capture: list[str] | None = None,
        capture_maxlen: int | None = None,
        theme: str | Theme = "default",
        use_unicode: bool | None = None,
        layout: Layout = "standard",
        subagent_trace: Literal["off", "nested"] = "off",
    ) -> None:
        """
        Initialize observer.

        Args:
            llm_calls: Show LLM request/response lines (`[request]`, `[response]`,
                token breakdown, thinking). Default False.
            memory_events: Show memory events (conversation load/save,
                ACC context/update, cache hit/miss). Default False.
            retrieval_events: Show retrieval events (retrieval.start,
                retrieval.complete, retrieval.error, summary_index.*). Default
                None — inherits from the resolved policy (True at PROGRESS+).
            timestamps: Prepend timestamps to every output line. Default False.
            trace_ids: Show correlation IDs on event lines. Default False.
            level: Deprecated. String or enum level name kept for backward compatibility.
                ``"debug"`` / ``"trace"`` map to ``llm_calls=True``;
                ``"off"`` disables the observer.
                Mutually exclusive with ``policy``.
            policy: Fine-grained :class:`ObservabilityPolicy` controlling which
                event domains are visible.  Mutually exclusive with ``level``.
                Flat flags (``llm_calls``, ``memory_events``) override the
                corresponding policy domain when both are provided.
            config: Full configuration object (overrides all flags when provided).
            stream: Output stream (default stderr).
            capture: Event patterns to capture for history (e.g. ``["tool.result", "agent.*"]``).
            capture_maxlen: Maximum events to retain in history (None = unlimited).
            theme: Color/style palette name or custom ``Theme`` instance.
            use_unicode: Use Unicode symbols instead of ASCII fallbacks.
                ``None`` (default) auto-detects from terminal encoding.
            layout: Output density preset. ``"compact"`` collapses to single-line,
                ``"standard"`` (default) keeps current multi-line style,
                ``"verbose"`` expands payloads and disables truncation.
            subagent_trace: ``"off"`` (default) or ``"nested"`` to inline child-agent
                traces under subagent branches.

        Raises:
            ValueError: If both ``level`` and ``policy`` are provided.
        """
        # --- Mutual exclusion: level= vs policy= ---
        if level is not None and policy is not None:
            raise ValueError(
                "Cannot specify both 'level' and 'policy'. "
                "Use level= for simple presets or policy= for fine-grained control."
            )

        _enabled = True

        # --- Policy-based path ---
        if policy is not None:
            self._policy = policy
            llm_calls = llm_calls or policy.llm.enabled
        # --- Backward-compat: level= maps to flags ---
        elif level is not None:
            level_str = level if isinstance(level, str) else level.name.lower()
            if level_str == "off":
                _enabled = False
            elif level_str in ("debug", "trace"):
                llm_calls = True
                memory_events = True
            resolved_level = (
                Level.from_string(level_str) if isinstance(level, str) else level
            )
            self._policy = policy_for_level(resolved_level)
        # --- Legacy config= path ---
        elif config is not None:
            # If someone passed ObserverConfig with a high level, respect it
            if config.level >= Level.DEBUG:
                llm_calls = True
                memory_events = True
            if config.level == Level.OFF:
                _enabled = False
            llm_calls = llm_calls or config.llm_calls
            timestamps = timestamps or config.format.show_timestamps
            trace_ids = trace_ids or config.format.show_trace_ids
            if config.policy is not None:
                self._policy = config.policy
            else:
                self._policy = policy_for_level(config.level)
        else:
            # Default: PROGRESS-equivalent policy
            self._policy = policy_for_level(Level.PROGRESS)

        # --- Apply flat flags as overrides on policy ---
        if llm_calls and not self._policy.llm.enabled:
            self._policy = ObservabilityPolicy(
                llm=LlmTelemetry(enabled=True),
                tool=self._policy.tool,
                memory=self._policy.memory,
                retrieval=self._policy.retrieval,
            )
        if memory_events and not self._policy.memory.enabled:
            self._policy = ObservabilityPolicy(
                llm=self._policy.llm,
                tool=self._policy.tool,
                memory=MemoryTelemetry(enabled=True),
                retrieval=self._policy.retrieval,
            )
        if retrieval_events is True and not self._policy.retrieval.enabled:
            self._policy = ObservabilityPolicy(
                llm=self._policy.llm,
                tool=self._policy.tool,
                memory=self._policy.memory,
                retrieval=RetrievalTelemetry(enabled=True),
            )
        elif retrieval_events is False and self._policy.retrieval.enabled:
            self._policy = ObservabilityPolicy(
                llm=self._policy.llm,
                tool=self._policy.tool,
                memory=self._policy.memory,
                retrieval=RetrievalTelemetry(enabled=False),
            )

        # Build ObserverConfig from resolved flags
        resolved_theme = resolve_theme(theme)
        _stream = (
            (config.stream if config is not None else None)
            if stream is None
            else stream
        )
        _include = config.include if config is not None else None
        _exclude = config.exclude if config is not None else None

        self._config = ObserverConfig(
            level=Level.OFF
            if not _enabled
            else Level.DEBUG
            if llm_calls
            else Level.PROGRESS,
            format=FormatConfig(
                use_colors=config.format.use_colors if config is not None else True,
                show_timestamps=timestamps,
                show_duration=True,
                show_trace_ids=trace_ids,
                truncate=config.format.truncate if config is not None else 0,
                indent=config.format.indent if config is not None else "  ",
                **({"use_unicode": use_unicode} if use_unicode is not None else {}),
                theme=resolved_theme,
                layout=layout,
            ),
            stream=_stream,
            include=_include,
            exclude=_exclude,
            llm_calls=llm_calls,
            policy=self._policy,
        )

        self._subagent_trace = subagent_trace
        self._bus = EventBus()
        self._formatter_registry = FormatterRegistry.with_defaults()

        self._sinks: list[Sink] = []
        self._default_sink = ConsoleSink(stream=self._config.stream or sys.stderr)
        self._sinks.append(self._default_sink)

        # State
        self._enabled = _enabled
        self._streaming_mode = False

        # Event capture for history tracking
        self._capture_patterns: list[str] = capture or []
        self._captured_events: deque[Event] = deque(maxlen=capture_maxlen)

    @property
    def subagent_trace(self) -> Literal["off", "nested"]:
        """Current subagent trace rendering mode."""
        return self._subagent_trace

    # === Core API ===

    def emit(self, event_type: str, **data: object) -> Event | None:
        """
        Emit an event.

        Args:
            event_type: Event type (e.g., "agent.invoked")
            **data: Event data as keyword arguments

        Returns:
            The created Event, or None if filtered/disabled
        """
        if not self._enabled:
            return None

        # Always suppress infrastructure noise
        if event_type in _ALWAYS_HIDDEN_EVENTS:
            return None

        # Policy-based domain filtering
        if not self._policy_allows(event_type):
            return None

        # Check include/exclude filters
        if not self._should_include(event_type):
            return None

        # Create event
        event = create_event(event_type, **data)

        # Capture if pattern matches
        self._maybe_capture(event)

        # Publish to bus (for subscribers)
        self._bus.publish(event)

        # Format and output
        self._output(event)

        return event

    def emit_event(self, event: Event) -> None:
        """
        Emit a pre-created event.

        Args:
            event: Event to emit
        """
        if not self._enabled:
            return

        # Always suppress infrastructure noise
        if event.type in _ALWAYS_HIDDEN_EVENTS:
            return

        # Policy-based domain filtering
        if not self._policy_allows(event.type):
            return

        if not self._should_include(event.type):
            return

        # Capture if pattern matches
        self._maybe_capture(event)

        self._bus.publish(event)
        self._output(event)

    def on(self, pattern: str, handler: Callable[[Event], None]) -> Callable[[], None]:
        """
        Subscribe to events matching a pattern.

        Args:
            pattern: Glob pattern (e.g., "agent.*", "tool.called")
            handler: Function called with matching events

        Returns:
            Unsubscribe function
        """
        return self._bus.subscribe(pattern, handler)

    def on_all(self, handler: Callable[[Event], None]) -> Callable[[], None]:
        """
        Subscribe to all events.

        Args:
            handler: Function called with every event

        Returns:
            Unsubscribe function
        """
        return self._bus.subscribe_all(handler)

    # === Configuration ===

    @property
    def llm_calls(self) -> bool:
        """Whether LLM request/response events are shown."""
        return self._config.llm_calls

    @property
    def level(self) -> Level:
        """Synthetic level for backward compatibility."""
        return self._config.level

    @level.setter
    def level(self, value: Level | str) -> None:
        """Set level (deprecated — pass flags to Observer() instead)."""
        if isinstance(value, str):
            value = Level.from_string(value)
        llm_calls = value >= Level.DEBUG
        self._enabled = value != Level.OFF
        self._policy = policy_for_level(value)
        self._config = ObserverConfig(
            level=value,
            format=self._config.format,
            stream=self._config.stream,
            include=self._config.include,
            exclude=self._config.exclude,
            llm_calls=llm_calls,
            policy=self._policy,
        )

    @property
    def enabled(self) -> bool:
        """Whether observer is enabled."""
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        """Enable or disable observer."""
        self._enabled = value

    @property
    def config(self) -> ObserverConfig:
        """Current configuration."""
        return self._config

    @property
    def policy(self) -> ObservabilityPolicy:
        """Active observability policy."""
        return self._policy

    # === Sinks ===

    def add_sink(self, sink: Sink) -> None:
        """
        Add an output sink.

        Args:
            sink: Sink to add
        """
        self._sinks.append(sink)

    def remove_sink(self, sink: Sink) -> None:
        """
        Remove an output sink.

        Args:
            sink: Sink to remove
        """
        if sink in self._sinks:
            self._sinks.remove(sink)

    # === Formatters ===

    def add_formatter(self, formatter: Formatter) -> None:
        """
        Add a custom formatter.

        Args:
            formatter: Formatter to add (checked before defaults)
        """
        # Insert at beginning so custom formatters take priority
        self._formatter_registry._formatters.insert(0, formatter)

    # === Streaming ===

    def stream_token(self, token: str) -> None:
        """
        Output a streaming token directly.

        Bypasses normal formatting for real-time token output.

        Args:
            token: Token string to output
        """
        if not self._enabled:
            return

        # Write directly to console sink
        if hasattr(self._default_sink, "write_raw"):
            self._default_sink.write_raw(token)

    def start_streaming(self) -> None:
        """Enter streaming mode."""
        self._streaming_mode = True

    def end_streaming(self) -> None:
        """Exit streaming mode, flush output."""
        self._streaming_mode = False
        self._default_sink.write_raw("\n")
        self.flush()

    # === Lifecycle ===

    def flush(self) -> None:
        """Flush all sinks."""
        for sink in self._sinks:
            sink.flush()

    def close(self) -> None:
        """Close all sinks."""
        for sink in self._sinks:
            sink.close()
        self._sinks.clear()

    def __enter__(self) -> Observer:
        """Context manager entry."""
        return self

    def __exit__(
        self, exc_type: type | None, exc_val: BaseException | None, exc_tb: object
    ) -> None:
        """Context manager exit."""
        self.close()

    # === Statistics ===

    def summary(self) -> str:
        """
        Get a summary of observed events.

        Returns:
            Human-readable summary string
        """
        stats = self.observed_stats()
        lines = [
            f"Events: {stats['total_events']}",
        ]
        if stats.get("by_category"):
            for cat, count in sorted(stats["by_category"].items()):
                lines.append(f"  {cat}: {count}")
        return "\n".join(lines)

    def observed_summary(self) -> str:
        """Get a summary of all observed events, whether captured or not."""
        return self.summary()

    def captured_summary(self) -> str:
        """Get a summary of captured events only."""
        stats = self.captured_stats()
        lines = [
            f"Events: {stats['total_events']}",
        ]
        if stats.get("by_category"):
            for cat, count in sorted(stats["by_category"].items()):
                lines.append(f"  {cat}: {count}")
        return "\n".join(lines)

    def stats(self) -> dict[str, object]:
        """
        Get event statistics.

        Returns:
            Dictionary with event counts by type/category
        """
        return self.observed_stats()

    def observed_stats(self) -> dict[str, object]:
        """Get statistics for all observed events."""
        return self._bus.stats()

    def captured_stats(self) -> dict[str, object]:
        """Get statistics for captured events only."""
        by_type: dict[str, int] = defaultdict(int)
        by_category: dict[str, int] = defaultdict(int)

        for event in self._captured_events:
            by_type[event.type] += 1
            by_category[event.category] += 1

        return {
            "total_events": len(self._captured_events),
            "by_type": dict(by_type),
            "by_category": dict(by_category),
        }

    # === Event History ===

    @overload
    def history(self) -> list[Event]: ...
    @overload
    def history(self, pattern: str) -> Iterator[Event]: ...

    def history(self, pattern: str | None = None) -> list[Event] | Iterator[Event]:
        """
        Get captured events.

        Must have set `capture=[...]` patterns when creating the Observer.

        Args:
            pattern: Optional glob pattern to filter events (e.g., "tool.*")
                     If None, returns all captured events.

        Returns:
            List of all captured events, or iterator of matching events.

        Example:
            ```python
            observer = Observer(level="trace", capture=["tool.result"])
            # ... run agent ...

            # Get all captured events
            all_events = observer.history()

            # Filter by pattern
            for event in observer.history("tool.*"):
                print(event.data.get("tool_name"))
            ```
        """
        if pattern is None:
            return list(self._captured_events)

        return (e for e in self._captured_events if fnmatch.fnmatch(e.type, pattern))

    def clear_history(self) -> None:
        """Clear all captured events."""
        self._captured_events.clear()

    @property
    def captured(self) -> list[Event]:
        """All captured events (alias for history())."""
        return list(self._captured_events)

    # === Internal ===

    def _policy_allows(self, event_type: str) -> bool:
        """Check if the active policy permits this event type."""
        p = self._policy

        # LLM domain
        if event_type in _LLM_EVENTS:
            return p.llm.enabled

        # Memory domain — check master switch first, then sub-flags
        if event_type in _ALL_MEMORY_EVENTS:
            if not p.memory.enabled:
                return False
            if event_type in _MEMORY_CONVERSATION_EVENTS:
                return p.memory.conversation
            if event_type in _MEMORY_ACC_EVENTS:
                return p.memory.acc
            if event_type in _MEMORY_CACHE_EVENTS:
                return p.memory.cache
            if event_type in _MEMORY_TOOL_EVENTS:
                return p.memory.tools
            if event_type in _MEMORY_EPISODIC_EVENTS:
                return p.memory.episodic
            return True  # unknown memory sub-event — allow

        # Tool domain
        if event_type.startswith("tool."):
            return p.tool.enabled

        # Retrieval domain
        if event_type in _ALL_RETRIEVAL_EVENTS:
            if not p.retrieval.enabled:
                return False
            if event_type in _RETRIEVAL_SUMMARY_EVENTS:
                return p.retrieval.summary_index
            return True

        # Everything else (agent.*, subagent.*, stream.*, output.*, custom) — allow
        return True

    def _maybe_capture(self, event: Event) -> None:
        """Capture event if it matches any capture pattern."""
        if not self._capture_patterns:
            return

        for pattern in self._capture_patterns:
            if fnmatch.fnmatch(event.type, pattern):
                self._captured_events.append(event)
                break  # Capture once even if multiple patterns match

    def _should_include(self, event_type: str) -> bool:
        """Check if event passes include/exclude filters."""
        # If include list specified, event must match at least one
        if self._config.include:
            event = create_event(event_type)
            if not any(event.matches(p) for p in self._config.include):
                return False

        # If exclude list specified, event must not match any
        if self._config.exclude:
            event = create_event(event_type)
            if any(event.matches(p) for p in self._config.exclude):
                return False

        return True

    def _output(self, event: Event) -> None:
        """Format and output an event to all sinks."""
        output = self._formatter_registry.format(event, self._config.format)
        if output:
            if self._config.format.show_timestamps:
                ts = event.timestamp.strftime("%H:%M:%S.%f")[:12]
                output = f"[{ts}] {output}"
            for sink in self._sinks:
                if hasattr(sink, "handle_event"):
                    sink.handle_event(event, output)
                else:
                    sink.write(output)


# === Factory Functions ===


def create_observer(
    level: str | Level = "progress",
    *,
    stream: TextIO | None = None,
    use_colors: bool = True,
    show_timestamps: bool = False,
    theme: str | Theme = "default",
    use_unicode: bool | None = None,
    subagent_trace: Literal["off", "nested"] = "off",
) -> Observer:
    """
    Create an observer with common settings.

    Args:
        level: Deprecated level string kept for backward compatibility.
        stream: Output stream
        use_colors: Enable colored output
        show_timestamps: Show timestamps in output
        theme: Color/style palette name or custom ``Theme`` instance.
        use_unicode: Enable Unicode symbols. ``None`` (default) auto-detects.
        subagent_trace: Subagent observability rendering mode: ``"off"`` or ``"nested"``.

    Returns:
        Configured Observer instance
    """
    level_str = level if isinstance(level, str) else level.name.lower()
    llm_calls = level_str in ("debug", "trace")
    enabled = level_str != "off"

    return Observer(
        llm_calls=llm_calls,
        timestamps=show_timestamps,
        stream=stream,
        theme=theme,
        use_unicode=use_unicode,
        subagent_trace=subagent_trace,
        level=None if enabled else "off",
    )
