"""Tool Formatter — Formats ``tool.*`` and ``subagent.*`` events."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter
from cogent.observability.formatters.style import Symbols

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class ToolFormatter(BaseFormatter):
    """Formats tool.* and subagent.* events."""

    patterns = ["tool.*", "subagent.*"]

    def _name_prefix(self, event: Event, is_subagent: bool) -> str:  # noqa: ARG002
        """Return 'a2a://' or 'mcp://' prefix, or empty string."""
        if is_subagent and event.get("subagent_type") == "a2a":
            return "a2a://"
        if not is_subagent:
            src = str(event.get("tool_source", ""))
            if src.startswith("mcp"):
                return "mcp://"
        return ""

    def _name_address(self, event: Event, is_subagent: bool) -> str:
        """Return '@host:port' or '@servername' suffix, or empty string."""
        if is_subagent and event.get("subagent_type") == "a2a":
            url = event.get("subagent_url", "")
            if url:
                from urllib.parse import urlparse

                netloc = urlparse(str(url)).netloc
                return f"@{netloc}"
        if not is_subagent:
            src = str(event.get("tool_source", ""))
            if src.startswith("mcp:"):
                return f"@{src[4:]}"
        return ""

    def _display_name(self, event: Event, is_subagent: bool, tool_name: str) -> str:
        """Build the qualified tool/subagent display name."""
        return (
            self._name_prefix(event, is_subagent)
            + tool_name
            + self._name_address(event, is_subagent)
        )

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = self._make_styler(config)
        is_subagent_event = event.category == "subagent"
        name_key = "subagent_name" if is_subagent_event else "tool_name"
        fallback_key = "subagent" if is_subagent_event else "tool"
        tool_name = event.get(name_key, event.get(fallback_key, event.category))
        agent_name = event.get("agent_name", "")
        call_id = event.get("call_id", "")

        # Short ID for display (first 8 chars)
        short_id = call_id[:8] if call_id else ""

        agent_prefix = f"{s.agent(self.format_name(agent_name))} " if agent_name else ""
        action = event.action
        display_name = self._display_name(event, is_subagent_event, tool_name)
        indent = config.indent
        trunc = config.effective_truncate

        def info_label(text: str) -> str:
            return s.info(text)

        def success_label(text: str) -> str:
            return s.success(text)

        if action == "called":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            if is_subagent_event:
                task = event.get("task")
                call_parts: list[str] = []
                if task:
                    task_preview = str(task).replace("\n", " ")
                    if trunc:
                        task_preview = self.truncate(task_preview, trunc)
                    call_parts.append(repr(task_preview))
                # Show forwarded data when present
                args = event.get("args", {})
                raw_data = args.get("data") if isinstance(args, dict) else None
                if raw_data:
                    data_str = str(raw_data).replace("\n", " ")
                    if trunc:
                        data_str = self.truncate(data_str, trunc)
                    call_parts.append(f"data={data_str}")
                call_expr = f"{display_name}({', '.join(call_parts)})"
                label = self._label("subagent", "call")
                if config.is_compact:
                    return (
                        f"{agent_prefix}{info_label(label)} {id_str}{s.tool(call_expr)}"
                    )
                return f"{agent_prefix}{info_label(label)} {id_str.rstrip()}\n{indent}{s.tool(call_expr)}"
            else:
                args = event.get("args", {})
                args_str = ""
                if args:
                    args_str = ", ".join(f"{k}={v!r}" for k, v in args.items())
                label = self._label("tool", "call")
                call_expr = (
                    f"{display_name}({args_str})" if args_str else f"{display_name}()"
                )
                if config.is_compact:
                    return (
                        f"{agent_prefix}{info_label(label)} {id_str}{s.tool(call_expr)}"
                    )
                return f"{agent_prefix}{info_label(label)} {id_str.rstrip()}\n{indent}{s.tool(call_expr)}"

        elif action == "result":
            duration_part = self._format_duration_part(event, config, s)

            id_str = f"{s.dim(short_id)} " if short_id else ""
            result = event.get("result_preview", str(event.get("result", "")))
            result_str = ""
            if result:
                result = str(result).replace("\n", " ")
                if trunc:
                    result = self.truncate(result, trunc)
                result_formatted = self._format_result(result)
                result_str = f" {s.content(result_formatted)}"
            # A2A envelope indicators: data parts, file parts
            parts_indicators: list[str] = []
            data_parts = event.get("data_parts", 0)
            file_parts = event.get("file_parts", 0)
            if data_parts:
                parts_indicators.append(f"{data_parts} data")
            if file_parts:
                file_names = event.get("file_names", [])
                names = [n for n in file_names if n]
                if names:
                    parts_indicators.append(
                        f"{file_parts} file{'s' if file_parts > 1 else ''} ({', '.join(names)})"
                    )
                else:
                    parts_indicators.append(
                        f"{file_parts} file{'s' if file_parts > 1 else ''}"
                    )
            parts_str = ""
            if parts_indicators:
                parts_str = f" {s.dim('+' + ', '.join(parts_indicators))}"
            label = (
                self._label("subagent", "result")
                if is_subagent_event
                else self._label("tool", "result")
            )
            body = f"{s.tool(display_name)}{result_str}{parts_str}"
            if config.is_compact:
                return f"{agent_prefix}{success_label(label)} {id_str.rstrip()}{duration_part} {body}"
            return f"{agent_prefix}{success_label(label)} {id_str.rstrip()}{duration_part}\n{indent}{body}"

        elif action == "context":
            # subagent.context — delegation context was summarized
            subagent = event.get("subagent_name", "?")
            summary_chars = event.get("summary_chars", 0)
            history_turns = event.get("history_turns", 0)
            summarizer_name = event.get("summarizer", "")
            arrow = s.sym(Symbols.ARROW_RIGHT)
            detail = f"{history_turns} turns {arrow} {summary_chars} chars"
            if summarizer_name:
                detail += f" ({summarizer_name})"
            label = self._label("subagent", "context")
            return (
                f"{agent_prefix}{info_label(label)} {s.tool(subagent)} {s.dim(detail)}"
            )

        elif action == "failed":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error_body = self._format_error(event)
            label = self._label("tool", "failed")
            body = f"{s.tool(display_name)} {s.error(error_body)}"
            if config.is_compact:
                return f"{agent_prefix}{s.error(label)} {id_str}{body}"
            return f"{agent_prefix}{s.error(label)} {id_str.rstrip()}\n{indent}{body}"

        elif action == "retry":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error_body = self._format_error(event)
            attempt = event.get("attempt")
            max_retries = event.get("max_retries")
            label = self._label("tool", "retry")
            retry_meta = (
                f" {s.warning(f'{attempt}/{max_retries}')}"
                if (attempt and max_retries)
                else ""
            )
            body = f"{s.tool(display_name)} {s.error(error_body)}"
            if config.is_compact:
                return f"{agent_prefix}{s.warning(label)} {id_str.rstrip()}{retry_meta} {body}"
            return f"{agent_prefix}{s.warning(label)} {id_str.rstrip()}{retry_meta}\n{indent}{body}"

        elif action == "error":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error_body = self._format_error(event)
            label = (
                self._label("subagent", "error")
                if is_subagent_event
                else self._label("tool", "error")
            )
            body = f"{s.tool(display_name)} {s.error(error_body)}"
            if config.is_compact:
                return f"{agent_prefix}{s.error(label)} {id_str}{body}"
            return f"{agent_prefix}{s.error(label)} {id_str.rstrip()}\n{indent}{body}"

        elif action == "escalated":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error_body = self._format_error(event)
            label = self._label("tool", "escalated")
            body = f"{s.tool(display_name)} {s.dim(error_body)}"
            if config.is_compact:
                return f"{agent_prefix}{s.warning(label)} {id_str}{body}"
            return f"{agent_prefix}{s.warning(label)} {id_str.rstrip()}\n{indent}{body}"

        elif action == "waiting":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            timeout = event.get("timeout", 0)
            interval = event.get("interval", 0)
            label = self._label("tool", "waiting")
            if timeout is None:
                detail = f" {s.dim(f'interval={interval:.0f}s')}"
            elif timeout:
                detail = f" {s.dim(f'timeout={timeout:.0f}s interval={interval:.0f}s')}"
            else:
                detail = ""
            if config.is_compact:
                return f"{agent_prefix}{s.warning(label)} {id_str}{s.tool(display_name)}{detail}"
            return f"{agent_prefix}{s.warning(label)} {id_str.rstrip()}{detail}\n{indent}{s.tool(display_name)}"

        elif action == "suspended":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            callback_id = event.get("callback_id", "")
            message = event.get("message", "")
            label = self._label("tool", "suspended")
            cb_str = f" callback_id={callback_id}" if callback_id else ""
            msg_str = ""
            if message:
                msg_preview = str(message).replace("\n", " ")
                if trunc:
                    msg_preview = self.truncate(msg_preview, trunc)
                msg_str = f" {s.content(repr(msg_preview))}"
            body = f"{s.tool(display_name)}{s.dim(cb_str)}{msg_str}"
            if config.is_compact:
                return f"{agent_prefix}{s.warning(label)} {id_str}{body}"
            return f"{agent_prefix}{s.warning(label)} {id_str.rstrip()}\n{indent}{body}"

        return f"{agent_prefix}{s.dim(self._label(event.category, action))} {s.tool(tool_name)}"

    def _format_result(self, result: str) -> str:
        """Format result value, handling dict-like strings."""
        import ast

        # Try to parse as Python literal (dict, list, etc.)
        try:
            parsed = ast.literal_eval(result)
            if isinstance(parsed, dict):
                # Format as {key='value', ...}
                parts = [f"{k}={v!r}" for k, v in parsed.items()]
                return "{" + ", ".join(parts) + "}"
            elif isinstance(parsed, (list, tuple)):
                return repr(parsed)
            else:
                return repr(parsed)
        except (ValueError, SyntaxError):
            # Not a Python literal, return as quoted string
            return repr(result)
