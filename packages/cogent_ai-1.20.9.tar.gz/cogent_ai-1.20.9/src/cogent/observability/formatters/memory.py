"""Memory Formatter — Formats ``memory.*`` events.

Each memory system gets a distinct label so the source is immediately
identifiable when scanning logs:

- ``[conversation-*]`` — thread-based message history
- ``[acc-*]``          — bounded cognitive compression
- ``[memory-*]``       — non-agentic auto-retrieval
- ``[episodic-*]``     — graph-backed experience recall
- ``[cache-*]``        — semantic tool-output cache

Agentic knowledge memory (tools) uses ``[tool-*]`` from the ToolFormatter.

``memory.write`` / ``memory.read`` / ``memory.delete`` / ``memory.search``
are suppressed because the tool events (``remember(…)`` / ``recall(…)`` /
``forget(…)`` / ``search_memories(…)``) already surface the same operations
at a higher, more useful level.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter
from cogent.observability.formatters.style import Symbols

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class MemoryFormatter(BaseFormatter):
    """Formats memory.* events."""

    patterns = ["memory.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = self._make_styler(config)
        indent = config.indent
        trunc = config.effective_truncate
        query_trunc = trunc if trunc else 60
        action = event.action

        # --- Suppress store-level ops (already shown by tool events) ---
        if action in ("write", "read", "delete", "clear", "search"):
            return None

        # --- Non-agentic auto-retrieval ---
        if action == "retrieved":
            count = event.get("results_count", 0)
            retriever_name = event.get("retriever", "")
            top_scores = event.get("top_scores", [])
            query = event.get("query", "")
            duration = event.get("duration_ms", 0)

            # Build call expression: retriever(query='...')
            call_args = []
            if query:
                short_q = self.truncate(query, query_trunc)
                call_args.append(f"query='{short_q}'")
            name = retriever_name or "retrieve"
            call_expr = f"{name}({', '.join(call_args)})"

            if config.is_compact:
                return (
                    f"{indent}{s.dim(self._label('memory', 'retrieved'))} "
                    f"{s.dim(call_expr)} {s.dim(f'{count} results')}"
                )

            # Trailing metrics
            bullet = s.sym(Symbols.BULLET)
            trailing = []
            trailing.append(f"{count} result{'s' if count != 1 else ''}")
            if top_scores:
                score_str = ", ".join(f"{sc:.2f}" for sc in top_scores)
                trailing.append(f"scores=[{score_str}]")
            if duration:
                trailing.append(f"{duration:.0f}ms")
            trailing_str = (
                f" {bullet} {f' {bullet} '.join(trailing)}" if trailing else ""
            )
            return (
                f"{indent}{s.dim(self._label('memory', 'retrieved'))} "
                f"{s.dim(call_expr)}{s.dim(trailing_str)}"
            )

        # --- Conversation load/save ---
        # The ``mode`` field distinguishes transcript from ACC.
        if action == "conversation.loaded":
            mode = event.get("mode", "transcript")
            layer = "acc" if mode == "acc" else "conversation"
            tid = event.get("thread_id", "")
            msg_count = event.get("message_count", 0)
            if msg_count:
                call_expr = f"{tid}(messages={msg_count})"
            else:
                call_expr = f"{tid}() \u2022 new"
            return f"{indent}{s.dim(self._label(layer, 'loaded'))} {s.dim(call_expr)}"

        if action == "conversation.saved":
            mode = event.get("mode", "transcript")
            layer = "acc" if mode == "acc" else "conversation"
            tid = event.get("thread_id", "")
            msg_count = event.get("message_count", 0)
            call_args = []
            if msg_count:
                call_args.append(f"messages={msg_count}")
            call_expr = f"{tid}({', '.join(call_args)})"
            return f"{indent}{s.dim(self._label(layer, 'saved'))} {s.dim(call_expr)}"

        # --- ACC context / update ---
        if action == "acc.context_formatted":
            has_ctx = event.get("has_context", False)
            chars = event.get("context_chars", 0)
            stats = event.get("acc_stats")

            if config.is_compact:
                detail = f"{chars} chars" if has_ctx else "no prior state"
                return f"{indent}{s.dim(self._label('acc', 'context'))} {s.dim(detail)}"

            if has_ctx and stats:
                breakdown = (
                    f"{stats.get('constraints', 0)} constraints, "
                    f"{stats.get('entities', 0)} entities, "
                    f"{stats.get('actions', 0)} actions, "
                    f"{stats.get('context', 0)} context"
                )
                detail = f"{chars} chars {s.sym(Symbols.BULLET)} {stats.get('total_items', 0)} items ({breakdown})"
            elif has_ctx:
                detail = f"{chars} chars injected"
            else:
                detail = "no prior state"
            return f"{indent}{s.dim(self._label('acc', 'context'))} {s.dim(detail)}"

        if action == "acc.updated":
            stats = event.get("acc_stats")

            if config.is_compact:
                items = stats.get("total_items", 0) if stats else 0
                detail = f"{items} items" if items else "compressed turn"
                return f"{indent}{s.dim(self._label('acc', 'updated'))} {s.dim(detail)}"

            if stats:
                breakdown = (
                    f"{stats.get('constraints', 0)} constraints, "
                    f"{stats.get('entities', 0)} entities, "
                    f"{stats.get('actions', 0)} actions, "
                    f"{stats.get('context', 0)} context"
                )
                detail = f"{stats.get('total_items', 0)} items ({breakdown})"
            else:
                tool_count = event.get("tool_calls_count", 0)
                detail = (
                    f"compressed {tool_count} tool call{'s' if tool_count != 1 else ''}"
                    if tool_count
                    else "compressed turn"
                )
            return f"{indent}{s.dim(self._label('acc', 'updated'))} {s.dim(detail)}"

        # --- Semantic cache ---
        if action in ("cache.hit", "cache.miss", "cache.write"):
            if config.is_compact:
                return None
            tool = event.get("tool_name", "")
            raw_key = event.get("cache_key", "")
            # Strip "toolname:" prefix for display
            display_key = raw_key.split(":", 1)[1] if ":" in raw_key else raw_key

            if action == "cache.hit":
                raw_matched = event.get("matched_key", "")
                matched_display = (
                    raw_matched.split(":", 1)[1] if ":" in raw_matched else raw_matched
                )
                score = event.get("similarity")
                arrow = s.sym(Symbols.ARROW_RIGHT)
                parts = [s.dim(tool)]
                if display_key and matched_display and display_key != matched_display:
                    parts.append(
                        s.dim(f"'{display_key}' {arrow} matched '{matched_display}'")
                    )
                    if score is not None:
                        parts.append(s.dim(f"(similarity={score:.2f})"))
                elif display_key:
                    parts.append(s.dim(f"'{display_key}'"))
                return f"{indent}{s.dim(self._label('cache', 'hit'))} {' '.join(parts)}"

            detail = (
                f"{tool} {s.sym(Symbols.BULLET)} {display_key}" if display_key else tool
            )
            label = "miss" if action == "cache.miss" else "write"
            return f"{indent}{s.dim(self._label('cache', label))} {s.dim(detail)}"

        # --- L4: Episodic memory ---
        if action == "episodic.recalled":
            count = event.get("observations_count", 0)
            query = event.get("query", "")
            sources = event.get("source_threads", {})

            if config.is_compact:
                return (
                    f"{indent}{s.dim(self._label('episodic', 'recalled'))} "
                    f"{s.dim(f'{count} observations')}"
                )

            parts = []
            if query:
                short_q = self.truncate(query, query_trunc)
                parts.append(f"query='{short_q}'")
            parts.append(f"{count} observation{'s' if count != 1 else ''}")
            if sources:
                threads = ", ".join(sources)
                parts.append(
                    f"from {len(sources)} episode{'s' if len(sources) != 1 else ''} ({threads})"
                )
            return (
                f"{indent}{s.dim(self._label('episodic', 'recalled'))} "
                f"{s.dim(f' {s.sym(Symbols.BULLET)} '.join(parts))}"
            )

        if action == "episodic.recorded":
            tid = event.get("thread_id", "")
            ep_id = event.get("episode_id", "")
            count = event.get("observations_count", 0)
            short_ep = ep_id[:8] if ep_id else ""
            call_args = []
            if short_ep:
                call_args.append(f"episode={short_ep}")
            call_args.append(f"observations={count}")
            call_expr = f"{tid}({', '.join(call_args)})"
            return f"{indent}{s.dim(self._label('episodic', 'recorded'))} {s.dim(call_expr)}"

        if action == "episodic.reflected":
            ep_id = event.get("episode_id", "")
            count = event.get("reflections_count", 0)
            short_ep = ep_id[:8] if ep_id else ""
            call_args = []
            if short_ep:
                call_args.append(f"episode={short_ep}")
            call_args.append(f"lessons={count}")
            call_expr = f"reflect({', '.join(call_args)})"
            return f"{indent}{s.dim(self._label('episodic', 'reflected'))} {s.dim(call_expr)}"

        # Unknown memory sub-event — dim fallback
        return f"{indent}{s.dim(self._label('memory', action))}"
