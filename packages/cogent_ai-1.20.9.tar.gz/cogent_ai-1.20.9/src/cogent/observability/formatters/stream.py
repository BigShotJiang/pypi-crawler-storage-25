"""Stream Formatter — Formats ``stream.*`` events."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class StreamFormatter(BaseFormatter):
    """Formats stream.* events."""

    patterns = ["stream.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = self._make_styler(config)
        agent_name = event.get("agent_name", "Agent")
        formatted_name = self.format_name(agent_name)
        indent = config.indent
        action = event.action

        if action == "start":
            model = event.get("model", "")
            model_str = f" {s.dim(f'({model})')}" if model else ""
            return f"{s.agent(formatted_name)} {s.info(self._label('stream', 'start'))}{model_str}"

        elif action == "token":
            return None

        elif action == "end":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                ms = event.data["duration_ms"]
                token_count = event.get("token_count", 0)
                if token_count > 0 and ms > 0:
                    tok_per_sec = token_count / (ms / 1000)
                    duration_str = f" ({ms / 1000:.1f}s, {tok_per_sec:.0f} tok/s)"
                else:
                    duration_str = f" ({self.format_duration(ms)})"
            duration_part = s.success(duration_str) if duration_str else ""
            return f"{s.agent(formatted_name)} {s.success(self._label('stream', 'end'))}{duration_part}"

        elif action == "error":
            error_body = self._format_error(event)
            if config.is_compact:
                return f"{s.agent(formatted_name)} {s.error(self._label('stream', 'error'))} {s.error(error_body)}"
            return f"{s.agent(formatted_name)} {s.error(self._label('stream', 'error'))}\n{indent}{s.error(error_body)}"

        return None
