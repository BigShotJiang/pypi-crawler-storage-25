"""LLM Formatter — Formats ``llm.*`` events with thinking/reasoning display."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter
from cogent.observability.formatters.style import Symbols

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class LLMFormatter(BaseFormatter):
    """Formats llm.* events with thinking/reasoning display."""

    patterns = ["llm.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = self._make_styler(config)
        agent_name = event.get("agent_name", "LLM")
        formatted_name = self.format_name(agent_name)
        action = event.action
        indent = config.indent
        indent2 = indent * 2
        trunc = config.effective_truncate

        if action == "request":
            model = event.get("model", "")
            provider = event.get("provider", "")
            model_label = (
                f"{provider}/{model}" if provider and provider != "unknown" else model
            )
            messages: list[dict[str, str]] = event.get("messages", [])
            msg_count = event.get("message_count", len(messages))
            tools = event.get("tools_available", [])
            bullet = s.sym(Symbols.BULLET)
            tools_str = f" {bullet} {len(tools)} tools" if tools else ""
            header = f"{indent}{s.dim(self._label('llm', 'request'))} {s.dim(model_label)} ({msg_count} msgs){s.dim(tools_str)}"

            if config.is_compact or not messages:
                return header

            lines = []
            for m in messages:
                role = m.get("role", "?")
                content = m.get("content", "")
                if trunc:
                    content = self.truncate(content, trunc)
                lines.append(f"{indent2}{s.dim(role)}: {s.content(content)}")
            return header + "\n" + "\n".join(lines)

        elif action == "response":
            duration_part = self._format_duration_part(event, config, s)

            tokens = event.get("tokens", {})
            token_str = self._format_tokens(tokens, s)

            # Thinking summary
            thinking_preview = event.get("thinking_preview", "")
            thinking_str = ""
            if thinking_preview and not config.is_compact:
                preview = thinking_preview
                if trunc:
                    preview = self.truncate(preview, trunc)
                thinking_str = f"\n{indent2}{s.dim(self._label('llm', 'thinking'))} {s.italic(preview)}"

            # Tool calls
            has_tools = event.get("has_tool_calls", False)
            arrow = s.sym(Symbols.ARROW_RIGHT)
            finish_str = f" {arrow} {s.tool('tool_calls')}" if has_tools else ""

            return f"{indent}{s.success(self._label('llm', 'response'))}{duration_part}{token_str}{finish_str}{thinking_str}"

        elif action == "thinking":
            thinking_content = event.get("thinking", event.get("content", ""))
            thinking_tokens = event.get("thinking_tokens", 0)

            tokens_str = f" ({thinking_tokens} tokens)" if thinking_tokens else ""

            if config.is_compact:
                return f"{indent}{s.info(self._label('llm', 'thinking'))}{s.dim(tokens_str)}"

            if thinking_content:
                preview = thinking_content
                if trunc:
                    preview = self.truncate(preview, trunc)
                return f"{indent}{s.info(self._label('llm', 'thinking'))}{s.dim(tokens_str)}\n{indent2}{s.italic(preview)}"
            elif thinking_tokens:
                return f"{indent}{s.info(self._label('llm', 'reasoning'))}{s.dim(tokens_str)} {s.dim('(content not exposed)')}"
            return f"{indent}{s.info(self._label('llm', 'thinking'))}"

        elif action == "tool_decision":
            tools = event.get("tools_selected", [])
            subagents = event.get("subagents_selected", [])
            regular_tools = event.get("regular_tools_selected", [])
            reasoning = event.get("reasoning", "")

            has_subagents = bool(subagents)
            has_tools = bool(regular_tools)
            if has_subagents and has_tools:
                label = self._label("llm", "tool-decision")
            elif has_subagents:
                label = self._label("llm", "subagent-decision")
            else:
                label = self._label("llm", "tool-decision")

            all_names: list[str] = list(subagents) + list(regular_tools) or tools

            if config.is_compact:
                names_str = f" {', '.join(all_names[:5])}" if all_names else ""
                return f"{s.agent(formatted_name)} {s.info(label)}{names_str}"

            if len(all_names) > 5:
                all_names = all_names[:5] + [f"... (+{len(all_names) - 5})"]
            tools_body = (
                f"\n{indent}{s.content(', '.join(all_names))}" if all_names else ""
            )

            reason_str = ""
            if reasoning:
                reason_text = reasoning.strip()
                if trunc:
                    reason_text = self.truncate(reason_text, trunc)
                reason_str = f"\n{indent}{s.italic(reason_text)}"

            return f"{s.agent(formatted_name)} {s.info(label)}{tools_body}{reason_str}"

        return f"{s.agent(formatted_name)} {s.dim(self._label('llm', action))}"
