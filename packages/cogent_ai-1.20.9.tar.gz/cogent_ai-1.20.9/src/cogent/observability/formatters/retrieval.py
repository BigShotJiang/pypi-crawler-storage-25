"""Retrieval Formatter — Formats ``retrieval.*`` events.

Labels:

- ``[retrieval-start]``     — retrieval query initiated
- ``[retrieval-complete]``  — results returned
- ``[retrieval-error]``     — retrieval failed
- ``[retrieval-indexing]``  — summary index document processed
- ``[retrieval-indexed]``   — summary index build completed
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter
from cogent.observability.formatters.style import Symbols

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class RetrievalFormatter(BaseFormatter):
    """Formats retrieval.* events."""

    patterns = ["retrieval.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = self._make_styler(config)
        indent = config.indent
        indent2 = indent * 2
        trunc = config.effective_truncate
        query_trunc = trunc if trunc else 60
        action = event.action
        retriever = event.get("retriever", "")

        if action == "start":
            query = event.get("query", "")
            k = event.get("k", 4)
            call_args = []
            if query:
                short_q = self.truncate(query, query_trunc)
                call_args.append(f"query='{short_q}'")
            call_args.append(f"k={k}")
            name = retriever or "retrieve"
            call_expr = f"{name}({', '.join(call_args)})"
            if config.is_compact:
                return f"{indent}{s.info(self._label('retrieval', 'start'))} {s.tool(call_expr)}"
            return (
                f"{indent}{s.info(self._label('retrieval', 'start'))}\n"
                f"{indent2}{s.tool(call_expr)}"
            )

        if action == "complete":
            count = event.get("results_count", 0)
            top_scores = event.get("top_scores", [])
            duration = event.get("duration_ms", 0)
            name = retriever or "retrieve"

            bullet = s.sym(Symbols.BULLET)
            trailing = []
            trailing.append(f"{count} result{'s' if count != 1 else ''}")
            if top_scores:
                score_str = ", ".join(f"{sc:.2f}" for sc in top_scores)
                trailing.append(f"scores=[{score_str}]")
            if duration:
                trailing.append(self.format_duration(duration))
            trailing_str = f" {f' {bullet} '.join(trailing)}" if trailing else ""
            ok_mark = s.sym(Symbols.CHECK)
            return (
                f"{indent}{s.success(self._label('retrieval', 'complete'))} "
                f"{s.success(ok_mark)} {s.tool(name)}{s.dim(trailing_str)}"
            )

        if action == "error":
            error_body = self._format_error(event)
            duration = event.get("duration_ms", 0)
            name = retriever or "retrieve"
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            err_mark = s.sym(Symbols.DOUBLE_BANG)
            return (
                f"{indent}{s.error(self._label('retrieval', 'error'))} "
                f"{s.error(err_mark)} {s.tool(name)}{s.dim(duration_str)} "
                f"{s.error(error_body)}"
            )

        # --- Summary index events ---
        if action == "summary_index.start":
            doc_count = event.get("documents_count", 0)
            suffix = "s" if doc_count != 1 else ""
            return (
                f"{indent}{s.info(self._label('retrieval', 'indexing'))} "
                f"{s.dim(f'{doc_count} document{suffix}')}"
            )

        if action == "summary_index.document_summarized":
            if config.is_compact:
                return None
            idx = event.get("doc_index", 0)
            total = event.get("doc_total", 0)
            duration = event.get("duration_ms", 0)
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            return (
                f"{indent2}{s.dim(self._label('retrieval', 'summarized'))} "
                f"{s.dim(f'{idx}/{total}')}{s.dim(duration_str)}"
            )

        if action == "summary_index.complete":
            doc_count = event.get("documents_count", 0)
            summary_count = event.get("summaries_count", 0)
            duration = event.get("duration_ms", 0)
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            ok_mark = s.sym(Symbols.CHECK)
            return (
                f"{indent}{s.success(self._label('retrieval', 'indexed'))} "
                f"{s.success(ok_mark)} "
                f"{s.dim(f'{summary_count} summaries from {doc_count} docs')}"
                f"{s.dim(duration_str)}"
            )

        if action == "summary_index.error":
            error_body = self._format_error(event)
            duration = event.get("duration_ms", 0)
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            err_mark = s.sym(Symbols.DOUBLE_BANG)
            return (
                f"{indent}{s.error(self._label('retrieval', 'index-error'))} "
                f"{s.error(err_mark)}{s.dim(duration_str)} {s.error(error_body)}"
            )

        # Unknown retrieval sub-event — dim fallback
        return f"{indent}{s.dim(self._label('retrieval', action))}"
