"""
Formatter Protocol - Interface for event formatters.

Formatters transform Event objects into formatted strings for output.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event
    from cogent.observability.formatters.style import Styler


class Formatter(Protocol):
    """
    Protocol for event formatters.

    Implement this protocol to create custom formatters.

    Example:
        ```python
        class MyFormatter:
            def can_format(self, event: Event) -> bool:
                return event.type.startswith("my_app.")

            def format(self, event: Event, config: FormatConfig) -> str | None:
                return f"[MY APP] {event.type}: {event.data}"
        ```
    """

    def can_format(self, event: Event) -> bool:
        """
        Check if this formatter can handle the given event.

        Args:
            event: Event to check

        Returns:
            True if this formatter should handle the event
        """
        ...

    def format(self, event: Event, config: FormatConfig) -> str | None:
        """
        Format an event to a string.

        Args:
            event: Event to format
            config: Formatting configuration

        Returns:
            Formatted string, or None to skip output
        """
        ...


class BaseFormatter:
    """
    Base class for formatters with common utilities.

    Provides helper methods for formatting. Subclasses should
    implement `patterns` and `format`.
    """

    patterns: list[str] = []
    """Glob patterns this formatter handles (e.g., ["agent.*"])."""

    def can_format(self, event: Event) -> bool:
        """Check if event matches any of our patterns."""
        return any(event.matches(p) for p in self.patterns)

    def format(self, event: Event, config: FormatConfig) -> str | None:
        """Format the event. Subclasses must implement this."""
        raise NotImplementedError

    # === Utility Methods ===

    @staticmethod
    def truncate(text: str, max_len: int) -> str:
        """Truncate text to max length, adding ellipsis if needed."""
        if max_len <= 0 or len(text) <= max_len:
            return text
        return text[: max_len - 3] + "..."

    @staticmethod
    def format_duration(ms: float) -> str:
        """Format duration in human-readable form."""
        if ms < 1000:
            return f"{ms:.0f}ms"
        elif ms < 60000:
            return f"{ms / 1000:.1f}s"
        else:
            mins = int(ms / 60000)
            secs = (ms % 60000) / 1000
            return f"{mins}m {secs:.0f}s"

    @staticmethod
    def format_name(name: str) -> str:
        """Format agent/tool name with brackets."""
        return f"[{name}]"

    @staticmethod
    def _label(category: str, action: str = "") -> str:
        """Build a canonical label.

        This is the single source-of-truth for label construction.
        All formatters must go through this method — never write
        bracket labels as free-form strings.

        With two args: ``[category-action]`` (e.g. ``[tool-call]``).
        With one arg:  ``[action]``           (e.g. ``[response]``).
        """
        if not action:
            return f"[{category}]"
        return f"[{category}-{action}]"

    @staticmethod
    def _make_styler(config: FormatConfig) -> Styler:
        """Create a Styler from the active config."""
        from cogent.observability.formatters.style import Styler as _Styler

        return _Styler(config.use_colors, config.theme, config.use_unicode)

    def _format_duration_part(
        self, event: Event, config: FormatConfig, s: Styler, *, muted: bool = False
    ) -> str:
        """Format duration as a styled string, or empty if absent/disabled."""
        if not config.show_duration or "duration_ms" not in event.data:
            return ""
        text = f" ({self.format_duration(event.data['duration_ms'])})"
        return s.muted_success(text) if muted else s.success(text)

    @staticmethod
    def _format_error(event: Event) -> str:
        """Extract and format error message with optional type prefix."""
        error = event.get("error", "Unknown error")
        error_type = event.get("error_type")
        return f"{error_type}: {error}" if error_type else str(error)

    @staticmethod
    def _format_tokens(tokens: dict, s: Styler) -> str:
        """Format token usage with optional reasoning breakdown.

        Returns a styled string like ``" • 150 tokens in=80/out=70"``
        or ``""`` when there is nothing to show.
        """
        if not tokens:
            return ""

        from cogent.observability.formatters.style import Symbols

        parts: list[str] = []

        total = tokens.get("total", tokens.get("total_tokens", 0))
        if total:
            parts.append(f"{total} tokens")

        prompt = tokens.get("prompt", tokens.get("prompt_tokens", 0))
        completion = tokens.get("completion", tokens.get("completion_tokens", 0))
        if prompt or completion:
            parts.append(f"in={prompt}/out={completion}")

        reasoning = tokens.get("reasoning", tokens.get("reasoning_tokens", 0))
        if reasoning:
            parts.append(f"reasoning={reasoning}")

        if parts:
            bullet = s.sym(Symbols.BULLET)
            return f" {bullet} {s.dim(' '.join(parts))}"
        return ""
