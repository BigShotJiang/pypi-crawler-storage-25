"""
Style Primitives — Single source of truth for ANSI codes, colors, and symbols.

All formatters import from here. No other module should define raw ANSI escapes.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cogent.observability.core.config import Theme


# ---------------------------------------------------------------------------
# ANSI escape codes (low-level constants, used by Style.render)
# ---------------------------------------------------------------------------

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
ITALIC = "\033[3m"

RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
BLUE = "\033[34m"
MAGENTA = "\033[35m"
CYAN = "\033[36m"
WHITE = "\033[37m"


# ---------------------------------------------------------------------------
# Color — named 8-color palette + 256-color + true-color
# ---------------------------------------------------------------------------


class Color(Enum):
    """Standard 8-color ANSI foreground colors."""

    RED = 31
    GREEN = 32
    YELLOW = 33
    BLUE = 34
    MAGENTA = 35
    CYAN = 36
    WHITE = 37

    def ansi(self) -> str:
        """Return the ANSI escape for this 8-color value."""
        return f"\033[{self.value}m"

    @staticmethod
    def from_256(n: int) -> _ExtendedColor:
        """Create a 256-color value (0–255)."""
        if not 0 <= n <= 255:
            raise ValueError(f"256-color index must be 0–255, got {n}")
        return _ExtendedColor(ansi=f"\033[38;5;{n}m", fallback=None)

    @staticmethod
    def from_rgb(r: int, g: int, b: int) -> _ExtendedColor:
        """Create a true-color (24-bit) value.

        Automatically computes a 256-color fallback for terminals that
        don't support true-color.
        """
        for val, name in ((r, "r"), (g, "g"), (b, "b")):
            if not 0 <= val <= 255:
                raise ValueError(f"{name} must be 0–255, got {val}")
        fb_idx = _rgb_to_256(r, g, b)
        return _ExtendedColor(
            ansi=f"\033[38;2;{r};{g};{b}m",
            fallback=f"\033[38;5;{fb_idx}m",
        )


@dataclass(frozen=True, slots=True)
class _ExtendedColor:
    """Internal representation of 256- or true-color values."""

    ansi: str
    fallback: str | None  # 256-color fallback for true-color values


def _rgb_to_256(r: int, g: int, b: int) -> int:
    """Approximate an RGB triple to the nearest 256-color index."""
    # Greyscale ramp (232–255) check
    if r == g == b:
        if r < 8:
            return 16
        if r > 248:
            return 231
        return round((r - 8) / 247 * 24) + 232
    # 6×6×6 color cube (indices 16–231)
    ri = round(r / 255 * 5)
    gi = round(g / 255 * 5)
    bi = round(b / 255 * 5)
    return 16 + 36 * ri + 6 * gi + bi


# ---------------------------------------------------------------------------
# Terminal capability detection
# ---------------------------------------------------------------------------


class _ColorSupport(Enum):
    NONE = 0
    BASIC = 1  # 8-color
    COLOR_256 = 2  # 256-color
    TRUE_COLOR = 3  # 24-bit

    def __ge__(self, other: object) -> bool:
        if isinstance(other, _ColorSupport):
            return self.value >= other.value
        return NotImplemented


def _detect_color_support() -> _ColorSupport:
    """Detect terminal color depth from environment variables."""
    ct = os.environ.get("COLORTERM", "").lower()
    if ct in ("truecolor", "24bit"):
        return _ColorSupport.TRUE_COLOR
    term = os.environ.get("TERM", "")
    if "256color" in term:
        return _ColorSupport.COLOR_256
    if term:
        return _ColorSupport.BASIC
    return _ColorSupport.NONE


_terminal_support: _ColorSupport | None = None


def _get_color_support() -> _ColorSupport:
    global _terminal_support
    if _terminal_support is None:
        _terminal_support = _detect_color_support()
    return _terminal_support


# ---------------------------------------------------------------------------
# Style — composable style primitive
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Style:
    """Composable terminal style.

    Construct with named colors and modifiers, renders to an ANSI escape
    string. Replaces raw string concatenation like ``BOLD + MAGENTA``.

    Examples::

        Style(fg=Color.CYAN)
        Style(fg=Color.MAGENTA, bold=True)
        Style(dim=True)
        Style(fg=Color.from_rgb(100, 200, 255), bold=True)
    """

    fg: Color | _ExtendedColor | None = None
    bold: bool = False
    dim: bool = False
    italic: bool = False

    def render(self) -> str:
        """Render to an ANSI escape prefix string.

        Extended colors are automatically degraded based on detected terminal
        capability.
        """
        parts: list[str] = []
        if self.bold:
            parts.append(BOLD)
        if self.dim:
            parts.append(DIM)
        if self.italic:
            parts.append(ITALIC)
        if self.fg is not None:
            parts.append(self._resolve_fg())
        return "".join(parts)

    def _resolve_fg(self) -> str:
        """Resolve foreground color respecting terminal capability."""
        fg = self.fg
        if fg is None:
            return ""
        if isinstance(fg, Color):
            return fg.ansi()
        # _ExtendedColor — degrade if needed
        support = _get_color_support()
        if support >= _ColorSupport.TRUE_COLOR:
            return fg.ansi
        if support >= _ColorSupport.COLOR_256:
            return fg.fallback or fg.ansi  # fallback only set for true-color
        # BASIC or NONE — can't render extended colors, skip fg
        return ""

    def with_dim(self) -> Style:
        """Return a copy with ``dim=True`` added."""
        if self.dim:
            return self
        return Style(fg=self.fg, bold=self.bold, dim=True, italic=self.italic)

    def __bool__(self) -> bool:
        """True if this style produces any ANSI output."""
        return self.fg is not None or self.bold or self.dim or self.italic


# ---------------------------------------------------------------------------
# Unicode / ASCII symbol pairs
# ---------------------------------------------------------------------------


class Symbols:
    """Unicode symbols with ASCII fallbacks.

    Use :meth:`get` to resolve based on ``use_unicode`` config.
    """

    CHECK = "\u2713"  # ✓
    CROSS = "\u2717"  # ✗
    DOUBLE_BANG = "\u203c"  # ‼
    ARROW_RIGHT = "\u2192"  # →
    ARROW_DIAGONAL = "\u2197"  # ↗
    RETRY = "\u21bb"  # ↻
    HOURGLASS = "\u23f3"  # ⏳
    PAUSE = "\u23f8"  # ⏸
    BULLET = "\u2022"  # •
    ELLIPSIS = "\u2026"  # …

    _ASCII_FALLBACKS: dict[str, str] = {
        CHECK: "OK",
        CROSS: "FAIL",
        DOUBLE_BANG: "!!",
        ARROW_RIGHT: "->",
        ARROW_DIAGONAL: "->",
        RETRY: "R",
        HOURGLASS: "WAITING",
        PAUSE: "PAUSED",
        BULLET: "*",
        ELLIPSIS: "...",
    }

    @classmethod
    def get(cls, symbol: str, *, use_unicode: bool = True) -> str:
        """Return *symbol* when unicode is available, else its ASCII fallback."""
        if use_unicode:
            return symbol
        return cls._ASCII_FALLBACKS.get(symbol, symbol)


# ---------------------------------------------------------------------------
# Styler — semantic style application using a Theme
# ---------------------------------------------------------------------------


class Styler:
    """Applies theme colors based on config.

    Instantiate once per ``format()`` call with the active
    ``use_colors`` flag and ``Theme``.
    """

    def __init__(
        self,
        use_colors: bool = True,
        theme: Theme | None = None,
        use_unicode: bool = True,
    ) -> None:
        self.use_colors = use_colors
        self.use_unicode = use_unicode
        if theme is None:
            from cogent.observability.core.config import Theme as _Theme

            self._theme = _Theme()
        else:
            self._theme = theme

    def _wrap(self, text: str, style: Style) -> str:
        if not self.use_colors or not style:
            return text
        return style.render() + text + RESET

    # -- semantic roles -------------------------------------------------------

    def agent(self, text: str) -> str:
        return self._wrap(text, self._theme.agent)

    def muted_agent(self, text: str) -> str:
        """Dimmed agent style for delegated/nested runs."""
        return self._wrap(text, self._theme.agent.with_dim())

    def tool(self, text: str) -> str:
        return self._wrap(text, self._theme.tool)

    def success(self, text: str) -> str:
        return self._wrap(text, self._theme.success)

    def error(self, text: str) -> str:
        return self._wrap(text, self._theme.error)

    def warning(self, text: str) -> str:
        return self._wrap(text, self._theme.warning)

    def info(self, text: str) -> str:
        return self._wrap(text, self._theme.info)

    def dim(self, text: str) -> str:
        return self._wrap(text, self._theme.dim)

    def bold(self, text: str) -> str:
        return self._wrap(text, self._theme.bold)

    def content(self, text: str) -> str:
        """Default terminal color for readable body content."""
        return text

    def italic(self, text: str) -> str:
        """Italic dim — for LLM reasoning and thinking text."""
        return self._wrap(text, self._theme.italic)

    def muted_info(self, text: str) -> str:
        """Dimmed info style for delegated/nested labels."""
        return self._wrap(text, self._theme.info.with_dim())

    def muted_success(self, text: str) -> str:
        """Dimmed success style for delegated/nested labels."""
        return self._wrap(text, self._theme.success.with_dim())

    def sym(self, symbol: str) -> str:
        """Resolve a unicode symbol respecting the ``use_unicode`` setting."""
        return Symbols.get(symbol, use_unicode=self.use_unicode)
