"""Task Formatter — Formats ``task.*`` events."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class TaskFormatter(BaseFormatter):
    """Formats task.* events."""

    patterns = ["task.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = self._make_styler(config)
        action = event.action
        indent = config.indent
        trunc = config.effective_truncate

        if action == "started":
            task = event.get("task_name", event.get("task", "task"))
            task = str(task)
            if trunc:
                task = self.truncate(task, trunc)
            return f"{s.success(self._label('task', 'started'))} {task}"

        elif action == "completed":
            duration_part = self._format_duration_part(event, config, s)
            return f"{s.success(self._label('task', 'completed'))}{duration_part}"

        elif action == "failed":
            error_body = self._format_error(event)
            if trunc:
                error_body = self.truncate(error_body, trunc)
            if config.is_compact:
                return f"{s.error(self._label('task', 'failed'))} {s.error(error_body)}"
            return f"{s.error(self._label('task', 'failed'))}\n{indent}{s.error(error_body)}"

        return f"{s.dim(self._label('task', action))}"
