"""Output Formatter — Formats ``output.*`` events.

``output.generated`` is primarily useful for capture, export, and downstream
subscriptions. The console already shows the final completion line via
``agent.responded``, so we suppress this event in human-readable terminal
output to avoid duplicate noise.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class OutputFormatter(BaseFormatter):
    """Suppresses output.generated from console display."""

    patterns = ["output.generated"]

    def format(self, event: Event, config: FormatConfig) -> str | None:  # noqa: ARG002
        return None
