"""Agent Formatter — Formats ``agent.*`` events."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class AgentFormatter(BaseFormatter):
    """Formats agent.* events."""

    patterns = ["agent.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = self._make_styler(config)
        agent_name = event.get("agent_name", "Agent")
        formatted_name = self.format_name(agent_name)
        is_delegated = bool(event.get("parent_run_id"))
        name_part = (
            s.muted_agent(formatted_name) if is_delegated else s.agent(formatted_name)
        )
        indent = config.indent
        trunc = config.effective_truncate

        action = event.action

        if action == "invoked":
            task = event.get("task", "")
            run_id = event.correlation_id or ""
            run_id_str = (
                f" {s.dim(run_id[:8])}" if run_id and config.show_trace_ids else ""
            )
            input_source = str(event.get("input_source", "")).strip().lower()
            if input_source in {"user", "agent", "system"}:
                input_label = self._label(input_source, "input")
            elif event.get("parent_run_id"):
                input_label = self._label("agent", "input")
            else:
                input_label = self._label("user", "input")
            label_part = (
                s.muted_info(input_label) if is_delegated else s.info(input_label)
            )

            if task:
                task = str(task).replace("\n", " ")
                if trunc:
                    task = self.truncate(task, trunc)

                # Show structured data when present (from Message.data_parts)
                input_data = event.get("input_data")
                data_str = ""
                if input_data and isinstance(input_data, list):
                    import json as _json

                    for dp in input_data:
                        raw = _json.dumps(dp, default=str)
                        if trunc:
                            raw = self.truncate(raw, trunc)
                        data_str += f"\n{indent}{s.dim('data=')} {s.content(raw)}"

                if config.is_compact:
                    return f"{name_part} {label_part}{run_id_str} {s.content(task)}"

                # Build context hint: (user:thread), (user), or (thread)
                ctx_str = ""
                if config.show_trace_ids:
                    _uid = event.get("user_id")
                    _tid = event.get("thread_id")
                    if _uid and _tid:
                        ctx_str = f" {s.dim(f'({_uid}:{_tid})')}"
                    elif _uid:
                        ctx_str = f" {s.dim(f'({_uid})')}"
                    elif _tid:
                        ctx_str = f" {s.dim(f'({_tid})')}"

                return f"{name_part} {label_part}{run_id_str}{ctx_str}\n{indent}{s.content(task)}{data_str}"
            return None

        elif action == "thinking":
            return None

        elif action == "reasoning":
            if config.is_compact:
                return f"{name_part} {s.dim(self._label('agent', 'reasoning'))}"
            thought = event.get("thought_preview", "")
            if thought:
                if trunc:
                    thought = self.truncate(thought, trunc)
                return f"{name_part} {s.dim(self._label('agent', 'reasoning'))}\n{indent}{s.italic(thought)}"
            return f"{name_part} {s.dim(self._label('agent', 'reasoning'))}"

        elif action == "acting":
            return f"{name_part} {s.dim(self._label('agent', 'acting'))}"

        elif action == "responded":
            duration_part = self._format_duration_part(
                event, config, s, muted=is_delegated
            )

            # Token info
            tokens = event.get("tokens", {})
            token_str = self._format_tokens(tokens, s)
            completed_label = self._label("agent", "completed")
            label_part = (
                s.muted_success(completed_label)
                if is_delegated
                else s.success(completed_label)
            )

            if config.is_compact:
                return f"{name_part} {label_part}{duration_part}{token_str}"

            response_str = ""
            preview = event.get("response_preview") or event.get("response", "")
            if preview:
                preview = str(preview)
                # Unwrap StructuredResult — show only the .data repr
                if preview.startswith("StructuredResult("):
                    try:
                        from cogent.agent.output import StructuredResult

                        raw = event.get("response")
                        if isinstance(raw, StructuredResult):
                            preview = repr(raw.data)
                    except Exception:
                        pass
                preview = preview.replace("\n", " ")
                if trunc:
                    preview = self.truncate(preview, trunc)
                response_str = f"\n{indent}{s.content(preview)}"

            return f"{name_part} {label_part}{duration_part}{token_str}{response_str}"

        elif action == "error":
            error_body = self._format_error(event)
            if config.is_compact:
                return f"{name_part} {s.error(self._label('agent', 'error'))} {s.error(error_body)}"
            return f"{name_part} {s.error(self._label('agent', 'error'))}\n{indent}{s.error(error_body)}"

        # Default for unknown agent actions
        return f"{name_part} {s.dim(self._label('agent', action))}"
