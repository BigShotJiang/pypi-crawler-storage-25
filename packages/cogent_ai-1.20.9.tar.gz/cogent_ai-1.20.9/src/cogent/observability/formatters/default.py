"""Default Formatter — Fallback for unhandled events.

Unrecognised event types are suppressed from console output.  They still
flow through the event bus (available to ``observer.on()`` subscribers)
and are stored by ``capture=`` patterns.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig
    from cogent.observability.core.event import Event


class DefaultFormatter(BaseFormatter):
    """Fallback — suppresses unrecognised events from console output."""

    patterns = ["*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:  # noqa: ARG002
        return None
