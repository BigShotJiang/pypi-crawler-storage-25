"""Context summarization for subagent delegation.

When an agent delegates to a subagent, the subagent receives only the
delegated task — no parent conversation history.  A ContextSummarizer
generates a compressed briefing from the parent's conversation and prepends
it to the delegated task so the subagent has relevant background.

Two built-in strategies:

* **HeuristicSummarizer** — extracts recent turns into a concise block
  without an LLM call (fast, free, deterministic).
* **LLMSummarizer** — asks a chat model to produce a 1-paragraph briefing
  (slower, higher quality, costs tokens).

Example:
    ```python
    from cogent import Agent
    from cogent.agent.summarizer import HeuristicSummarizer

    coordinator = Agent(
        name="coordinator",
        subagents={"analyst": analyst},
        delegate_summary=True,                       # default heuristic
        # delegate_summary=HeuristicSummarizer(max_turns=3),  # custom
    )
    ```
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    from cogent.core.messages import BaseMessage
    from cogent.models.base import BaseChatModel


# ---------------------------------------------------------------------------
# Protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class ContextSummarizer(Protocol):
    """Generates a compressed context briefing for subagent delegation."""

    async def summarize(
        self,
        messages: list[BaseMessage],
        task: str,
    ) -> str | None:
        """Produce a summary of *messages* relevant to *task*.

        Args:
            messages: The parent agent's conversation history (oldest first).
            task: The task being delegated to the subagent.

        Returns:
            A concise summary string, or ``None`` if the history is too short
            to warrant a summary.
        """
        ...


# ---------------------------------------------------------------------------
# Heuristic (no LLM call)
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class HeuristicSummarizer:
    """Extract recent conversation turns into a compact briefing.

    Fast and free — no model call required.  Keeps the last *max_turns*
    user/assistant pairs and truncates to *max_chars*.

    Attributes:
        max_turns: Maximum number of recent user+assistant pairs to include.
        max_chars: Hard character cap on the produced summary.
    """

    max_turns: int = 5
    max_chars: int = 2000

    async def summarize(
        self,
        messages: list[BaseMessage],
        task: str,  # noqa: ARG002 – present for protocol conformance
    ) -> str | None:
        """Extract recent turns into a context block."""
        # Filter to user/assistant content turns (skip system, tool messages).
        turns: list[str] = []
        for msg in messages:
            if msg.role == "user":
                turns.append(f"User: {msg.content}")
            elif msg.role == "assistant" and msg.content:
                turns.append(f"Assistant: {msg.content}")

        if not turns:
            return None

        # Keep the most recent turns within budget.
        recent = turns[-(self.max_turns * 2) :]
        text = "\n".join(recent)
        if len(text) > self.max_chars:
            text = text[-self.max_chars :]
            # Trim to first complete line after truncation.
            first_nl = text.find("\n")
            if first_nl != -1:
                text = text[first_nl + 1 :]

        return text or None


# ---------------------------------------------------------------------------
# LLM-powered
# ---------------------------------------------------------------------------

_SUMMARIZE_PROMPT = (
    "You are a concise summarizer. Given the conversation history below, "
    "produce a **single short paragraph** (3-5 sentences) capturing the key "
    "context that would help a specialist agent understand the background for "
    "the following task:\n\n"
    "Task: {task}\n\n"
    "Conversation:\n{conversation}\n\n"
    "Write only the summary paragraph — no preamble, no bullet points."
)


@dataclass(slots=True)
class LLMSummarizer:
    """Use a chat model to produce a 1-paragraph context briefing.

    Attributes:
        model: The chat model to use for summarization.
        max_history_chars: Maximum characters of history to feed the model.
    """

    model: BaseChatModel
    max_history_chars: int = 6000

    async def summarize(
        self,
        messages: list[BaseMessage],
        task: str,
    ) -> str | None:
        """Ask the model for a concise briefing."""
        from cogent.core.messages import HumanMessage

        turns: list[str] = []
        for msg in messages:
            if msg.role in ("user", "assistant") and msg.content:
                label = "User" if msg.role == "user" else "Assistant"
                turns.append(f"{label}: {msg.content}")

        if not turns:
            return None

        conversation = "\n".join(turns)
        if len(conversation) > self.max_history_chars:
            conversation = conversation[-self.max_history_chars :]
            first_nl = conversation.find("\n")
            if first_nl != -1:
                conversation = conversation[first_nl + 1 :]

        prompt = _SUMMARIZE_PROMPT.format(task=task, conversation=conversation)
        response = await self.model.chat([HumanMessage(prompt)])
        text = response.content.strip() if response.content else None
        return text or None
