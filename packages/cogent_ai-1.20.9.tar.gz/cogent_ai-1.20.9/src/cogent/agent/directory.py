"""Agent discovery registry.

Provides :class:`AgentDirectory` — an in-process catalog of agents that
can be queried by name, tag, or description keyword.  Coordinators use
it to discover specialists at runtime instead of hard-coding subagent
lists.

Example::

    from cogent import Agent, AgentDirectory

    directory = AgentDirectory()

    analyst = Agent(name="analyst", model="gpt-4o", tags=["data", "finance"])
    writer = Agent(name="writer", model="gpt-4o", tags=["content", "writing"])

    directory.register(analyst, writer)

    # Find by tag
    agents = directory.find(tags=["finance"])  # → [analyst]

    # Coordinator picks subagents from the directory
    coordinator = Agent(
        name="coordinator",
        model="gpt-4o",
        subagents=directory.find(tags=["data"]),
    )
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cogent.agent.base import Agent


class AgentDirectory:
    """In-process catalog for agent discovery.

    Agents register themselves (or are registered by a setup function),
    and coordinators query the directory to assemble their subagent teams.

    All lookups are case-insensitive.  ``find()`` returns agents matching
    **all** supplied criteria (AND logic across parameters, OR within a
    tag list).

    Example::

        directory = AgentDirectory()
        directory.register(analyst, writer, researcher)

        # OR within tags: matches agents that have "data" OR "finance"
        directory.find(tags=["data", "finance"])

        # AND across criteria: must match tags AND name substring
        directory.find(tags=["data"], name="analyst")
    """

    def __init__(self) -> None:
        self._agents: dict[str, Agent] = {}  # keyed by lowercase name

    def register(self, *agents: Agent) -> AgentDirectory:
        """Add one or more agents to the directory.

        Args:
            *agents: Agent instances to register.  Uses
                ``agent.config.name`` as the unique key (case-insensitive).

        Returns:
            Self for chaining: ``directory.register(a).register(b)``.

        Raises:
            ValueError: If an agent with the same name is already registered.
        """
        for agent in agents:
            key = agent.config.name.lower()
            if key in self._agents:
                raise ValueError(f"Agent '{agent.config.name}' is already registered")
            self._agents[key] = agent
        return self

    def unregister(self, name: str) -> Agent | None:
        """Remove an agent by name.

        Returns:
            The removed agent, or ``None`` if not found.
        """
        return self._agents.pop(name.lower(), None)

    def get(self, name: str) -> Agent | None:
        """Look up a single agent by exact name (case-insensitive)."""
        return self._agents.get(name.lower())

    def find(
        self,
        *,
        tags: Sequence[str] | None = None,
        name: str | None = None,
        description: str | None = None,
    ) -> list[Agent]:
        """Find agents matching the given criteria.

        All supplied criteria must match (AND logic).  Within ``tags``,
        an agent matches if it has **any** of the requested tags (OR).

        Args:
            tags: Match agents that have at least one of these tags.
            name: Match agents whose name contains this substring.
            description: Match agents whose description contains this
                substring.

        Returns:
            List of matching agents (may be empty).

        Example::

            # Find agents tagged "data" or "analytics"
            directory.find(tags=["data", "analytics"])

            # Find agents named like "analyst" AND tagged "finance"
            directory.find(tags=["finance"], name="analyst")
        """
        results: list[Agent] = list(self._agents.values())

        if tags is not None:
            lower_tags = {t.lower() for t in tags}
            results = [
                a for a in results if lower_tags & {t.lower() for t in a.config.tags}
            ]

        if name is not None:
            needle = name.lower()
            results = [a for a in results if needle in a.config.name.lower()]

        if description is not None:
            needle = description.lower()
            results = [
                a for a in results if needle in (a.config.description or "").lower()
            ]

        return results

    def all(self) -> list[Agent]:
        """Return all registered agents."""
        return list(self._agents.values())

    def names(self) -> list[str]:
        """Return names of all registered agents."""
        return [a.config.name for a in self._agents.values()]

    def __len__(self) -> int:
        return len(self._agents)

    def __contains__(self, name: str) -> bool:
        return name.lower() in self._agents

    def __repr__(self) -> str:
        names = ", ".join(self.names())
        return f"AgentDirectory([{names}])"
