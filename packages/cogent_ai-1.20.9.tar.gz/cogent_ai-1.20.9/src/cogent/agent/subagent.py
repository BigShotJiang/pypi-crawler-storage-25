"""Subagent registry and management.

Enables native subagent support where agents can delegate to other agents
while preserving full Response[T] metadata for aggregation.
"""

from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

from cogent.core.utils import generate_id

if TYPE_CHECKING:
    from cogent.core.context import RunContext
    from cogent.core.message import Message
    from cogent.core.response import Response


@dataclass(slots=True)
class SubagentRegistry:
    """Manages subagent registration, execution, and response tracking.

    The registry allows agents to delegate to other agents while preserving
    full Response[T] objects for metadata aggregation (tokens, duration, etc.).

    Subagents are registered as tools from the LLM's perspective, but the
    executor recognizes them and handles them specially to preserve metadata.

    Example:
        ```python
        registry = SubagentRegistry()
        registry.register("analyst", analyst_agent)

        # In executor
        if registry.has_subagent(tool_name):
            response = await registry.execute(tool_name, task, context)
            # Full Response[T] preserved, not just string
        ```
    """

    _agents: dict[str, Any] = field(default_factory=dict)
    _responses: list[Response] = field(default_factory=list)

    def register(self, name: str, agent: Any) -> None:
        """Register a subagent.

        Args:
            name: The name to register the agent under (used in tool calls).
            agent: The Agent instance to register.

        Example:
            ```python
            registry.register("analyst", analyst_agent)
            registry.register("writer", writer_agent)
            ```
        """
        self._agents[name] = agent

    def has_subagent(self, name: str) -> bool:
        """Check if a name corresponds to a registered subagent.

        Args:
            name: The name to check.

        Returns:
            True if name is a registered subagent, False otherwise.

        Example:
            ```python
            if registry.has_subagent("analyst"):
                # Handle as subagent
            else:
                # Handle as regular tool
            ```
        """
        return name in self._agents

    def get_subagent(self, name: str) -> Any | None:
        """Return the registered subagent object, or None if not found."""
        return self._agents.get(name)

    async def execute(
        self,
        name: str,
        task: str | Message,
        context: RunContext | None = None,
    ) -> Response:
        """Execute a subagent and cache its Response.

        Args:
            name: Name of the subagent to execute.
            task: Task to delegate — a plain string or a
                :class:`~cogent.core.message.Message` carrying text, data,
                and/or file references.
            context: Optional RunContext to propagate to subagent.

        Returns:
            Full Response[T] object from subagent execution.

        Raises:
            KeyError: If subagent name is not registered.

        Example:
            ```python
            response = await registry.execute(
                "analyst",
                "Analyze Q4 sales data",
                context=run_context
            )
            # response.metadata.tokens available for aggregation
            ```
        """
        if name not in self._agents:
            raise KeyError(f"Subagent '{name}' not registered")

        agent = self._agents[name]

        # Remote agents (url= set) only need the task string — no context
        # propagation.  Local agents get the full RunContext with lineage.
        if getattr(agent, "is_remote", False):
            schema = getattr(agent.config, "returns", None)

            # Forward correlation IDs so the remote agent can stitch
            # distributed traces back to this invocation.
            correlation: dict[str, str] | None = None
            if context is not None:
                ids: dict[str, str] = {}
                if context.run_id:
                    ids["run_id"] = context.run_id
                    ids["parent_run_id"] = (
                        context.run_id
                    )  # remote sees caller as parent
                if ids:
                    correlation = ids

            response = await agent.run(task, returns=schema, correlation=correlation)
        else:
            # Optional nested-trace mode: if parent observer requests nested
            # subagent traces and the child has no observer, temporarily inherit
            # the parent observer for this delegation call only.
            injected_parent_observer = False
            original_observer = getattr(agent, "_observer", None)
            parent_observer = None
            if context is not None and getattr(context, "agent", None) is not None:
                parent_observer = getattr(context.agent, "observer", None)
            if (
                parent_observer is not None
                and getattr(parent_observer, "subagent_trace", "off") == "nested"
                and original_observer is None
                and hasattr(agent, "_observer")
            ):
                agent._observer = parent_observer
                injected_parent_observer = True

            # Local agent (or compatible duck-typed adapter): propagate RunContext with lineage.
            delegated_context: RunContext | None
            if context is None:
                # No context at all — subagent also receives None.  The
                # _LINEAGE_CV ContextVar (set by the caller's
                # _set_observability_context) will carry the parent run_id into
                # the subagent's _prepare_run_context so observability lineage is
                # preserved without injecting a synthetic context object.
                delegated_context = None
            elif getattr(context, "_synthetic", False):
                # Context was auto-created by the framework (caller passed
                # context=None), not supplied by the user.  Pass None so the
                # subagent's run() argument is also None — user-facing contract.
                # Lineage is propagated via _LINEAGE_CV as above.
                delegated_context = None
            else:
                # User-supplied context: build a delegated copy with a fresh
                # run_id while keeping the *same* metadata dict object so that
                # mutations by the subagent are visible in the caller's original
                # context (pass-by-reference semantics).
                import copy as _copy

                parent_run_id = context.run_id or None
                delegated_context = _copy.copy(
                    context
                )  # shallow — shares metadata dict
                delegated_context.run_id = generate_id(12)
                delegated_context.parent_run_id = parent_run_id
                # Update the shared metadata dict in-place
                delegated_context.metadata["run_id"] = delegated_context.run_id
                if parent_run_id is not None:
                    delegated_context.metadata.setdefault(
                        "parent_run_id", parent_run_id
                    )

            # Use the agent's declared return schema (set via returns= on Agent)
            schema = getattr(agent.config, "returns", None)

            # Execute subagent with context propagation and optional structured output.
            # Test doubles and lightweight adapters may not expose a `returns` kwarg.
            try:
                run_signature = inspect.signature(agent.run)
                if "returns" in run_signature.parameters:
                    response = await agent.run(
                        task, context=delegated_context, returns=schema
                    )
                else:
                    response = await agent.run(task, context=delegated_context)
            finally:
                if injected_parent_observer:
                    agent._observer = original_observer

        # Cache response for metadata aggregation
        self._responses.append(response)

        return response

    def get_responses(self) -> list[Response]:
        """Get all cached subagent responses for metadata aggregation.

        Returns:
            List of Response objects from all subagent executions.

        Example:
            ```python
            # After execution
            responses = registry.get_responses()
            total_tokens = sum(
                r.metadata.tokens.total_tokens
                for r in responses
                if r.metadata and r.metadata.tokens
            )
            ```
        """
        return list(self._responses)

    def clear(self) -> None:
        """Clear cached responses.

        Should be called before each new run to avoid accumulating
        responses from previous executions.

        Example:
            ```python
            # Before new run
            registry.clear()
            result = await agent.run(task)
            ```
        """
        self._responses.clear()

    def generate_documentation(self) -> str:
        """Generate system prompt documentation for registered subagents.

        Creates human-readable documentation that gets added to the agent's
        system prompt, explaining what specialist agents are available.

        Returns:
            Formatted documentation string, or empty if no subagents.

        Example:
            ```python
            docs = registry.generate_documentation()
            # "# Specialist Agents
            #
            # You have access to specialist agents:
            # - analyst: Financial data analysis specialist
            # - writer: Report writing specialist
            # ..."
            ```
        """
        if not self._agents:
            return ""

        lines = ["# Specialist Agents", ""]
        lines.append("You have access to specialist agents for complex tasks:")
        lines.append("")

        for name, agent in self._agents.items():
            description = agent.config.description or "No description available"
            lines.append(f"- **{name}**: {description}")

        lines.append("")
        lines.append(
            "To use a specialist, call them like a tool with a 'task' parameter describing what you want them to do."
        )

        return "\n".join(lines)

    @property
    def agent_names(self) -> list[str]:
        """Get list of registered subagent names.

        Returns:
            List of subagent names.
        """
        return list(self._agents.keys())

    @property
    def count(self) -> int:
        """Get count of registered subagents.

        Returns:
            Number of registered subagents.
        """
        return len(self._agents)

    def __repr__(self) -> str:
        """String representation of registry."""
        agents = ", ".join(self._agents.keys()) if self._agents else "none"
        return f"SubagentRegistry(agents=[{agents}], cached_responses={len(self._responses)})"
