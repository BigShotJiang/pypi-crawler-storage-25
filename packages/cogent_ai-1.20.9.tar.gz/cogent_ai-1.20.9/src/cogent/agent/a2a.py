"""A2A (Agent2Agent) remote agent — backwards-compatible alias.

Prefer ``Agent(url=...)`` directly::

    from cogent import Agent
    remote = Agent(url="http://svc/a2a", name="analyst")
"""

from __future__ import annotations

from typing import Any

from cogent.agent.base import Agent


class A2AAgent(Agent):
    """Alias for ``Agent(url=..., name=...)``.

    Kept for backward compatibility with code that imports ``A2AAgent``
    directly.  New code should use ``Agent(url=...)`` instead.
    """

    def __init__(
        self,
        url: str,
        *,
        name: str,
        description: str = "",
        timeout: float = 60.0,
        headers: dict[str, str] | None = None,
        returns: type | dict | None = None,
    ) -> None:
        super().__init__(
            url=url,
            name=name,
            description=description,
            timeout=timeout,
            headers=headers,
            returns=returns,
        )

    def __repr__(self) -> str:
        return f"A2AAgent(name={self.config.name!r}, url={self._url!r})"


# Keep _extract_text importable for existing tests.
def _extract_text(event: Any) -> str:
    return Agent._extract_remote_text(event)


# Keep _A2AAgentConfig importable for existing tests.
class _A2AAgentConfig:
    __slots__ = ("name", "description", "returns")

    def __init__(self, name: str, description: str, returns: Any = None) -> None:
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "description", description)
        object.__setattr__(self, "returns", returns)

    def __setattr__(self, _name: str, _value: Any) -> None:
        raise AttributeError("_A2AAgentConfig is frozen")
