"""Structured inter-agent message envelope.

Provides a rich message type for agent-to-agent communication that carries
text, structured data, and file references in a single container.  Aligned
with the A2A protocol's ``TextPart`` / ``DataPart`` / ``FilePart`` model but
usable without the ``a2a`` extra for local (in-process) delegation.

Quick usage::

    from cogent.core.message import Message

    # Shorthand — text only (equivalent to a bare string)
    msg = Message("Analyze Q4 sales")

    # Text + structured data
    msg = Message("Analyze trends", data={"region": "EMEA", "year": 2026})

    # Full control — explicit parts list
    msg = Message(parts=[
        TextPart("Analyze this document"),
        DataPart({"format": "summary", "max_length": 500}),
        FilePart(uri="s3://bucket/report.pdf", mime_type="application/pdf"),
    ])
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True, frozen=True)
class TextPart:
    """Plain-text content in an inter-agent message."""

    text: str
    metadata: dict[str, Any] | None = None


@dataclass(slots=True, frozen=True)
class DataPart:
    """Structured JSON-serializable data in an inter-agent message."""

    data: dict[str, Any]
    metadata: dict[str, Any] | None = None


@dataclass(slots=True, frozen=True)
class FilePart:
    """File reference in an inter-agent message.

    Provide *either* ``uri`` (a URL / path the receiver can fetch) or
    ``data`` (raw bytes, typically base64-encoded).
    """

    uri: str | None = None
    data: bytes | None = None
    name: str | None = None
    mime_type: str | None = None
    metadata: dict[str, Any] | None = None

    def __post_init__(self) -> None:
        if self.uri is None and self.data is None:
            raise ValueError("FilePart requires either uri or data")


Part = TextPart | DataPart | FilePart


@dataclass(slots=True)
class Message:
    """Structured envelope for inter-agent communication.

    Can be built with convenience kwargs or an explicit parts list.

    Examples::

        # Convenience — text only
        Message("Summarise this paragraph")

        # Convenience — text + data
        Message("Analyze trends", data={"region": "EMEA"})

        # Explicit parts
        Message(parts=[TextPart("hello"), DataPart({"k": "v"})])

    The ``text`` property returns the concatenated text from all
    :class:`TextPart` entries (most common access pattern).  For richer
    inspection iterate ``parts`` directly.
    """

    parts: list[Part] = field(default_factory=list)

    def __init__(
        self,
        text: str | None = None,
        *,
        data: dict[str, Any] | None = None,
        files: list[FilePart] | None = None,
        parts: list[Part] | None = None,
    ) -> None:
        if parts is not None:
            if text is not None or data is not None or files is not None:
                raise ValueError("Cannot combine parts= with text=, data=, or files=")
            self.parts = list(parts)
            return

        built: list[Part] = []
        if text is not None:
            built.append(TextPart(text))
        if data is not None:
            built.append(DataPart(data))
        if files:
            built.extend(files)

        if not built:
            raise ValueError(
                "Message requires at least one part (text, data, or files)"
            )
        self.parts = built

    # ── Convenience accessors ────────────────────────────────────────

    @property
    def text(self) -> str:
        """Concatenated text from all TextPart entries."""
        return "\n".join(p.text for p in self.parts if isinstance(p, TextPart))

    @property
    def data_parts(self) -> list[DataPart]:
        """All DataPart entries."""
        return [p for p in self.parts if isinstance(p, DataPart)]

    @property
    def file_parts(self) -> list[FilePart]:
        """All FilePart entries."""
        return [p for p in self.parts if isinstance(p, FilePart)]

    @property
    def has_data(self) -> bool:
        """True if the message contains at least one DataPart."""
        return any(isinstance(p, DataPart) for p in self.parts)

    @property
    def has_files(self) -> bool:
        """True if the message contains at least one FilePart."""
        return any(isinstance(p, FilePart) for p in self.parts)

    def first_data(self) -> dict[str, Any] | None:
        """Return the first DataPart's data dict, or None."""
        for p in self.parts:
            if isinstance(p, DataPart):
                return p.data
        return None

    def __repr__(self) -> str:
        part_counts = {}
        for p in self.parts:
            key = type(p).__name__
            part_counts[key] = part_counts.get(key, 0) + 1
        summary = ", ".join(f"{k}={v}" for k, v in part_counts.items())
        return f"Message({summary})"
