"""`meshcode run <agent>` — universal agent launcher.

Looks up the agent's workspace dir (created by `meshcode setup`) in the
registry at ~/meshcode/.registry.json, auto-detects the user's MCP-aware
editor, and launches it pointing at that workspace's isolated .mcp.json
so ONLY this one agent loads in the new window.

Editor detection order (first match wins):
    1. $MESHCODE_EDITOR env var (explicit override: claude / cursor / code)
    2. claude (Claude Code) — uses --mcp-config flag for per-instance config
    3. cursor — opens Cursor in the workspace dir (reads .cursor/mcp.json)
    4. code (VS Code, used by Cline) — opens VS Code in the workspace dir
       (Cline reads .vscode/mcp.json)

The workspace dir contains all three config files (.mcp.json,
.cursor/mcp.json, .vscode/mcp.json) so any of these editors works
identically. Closing the editor window kills the MCP subprocess and
the agent flips to offline.
"""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional, Tuple

from .preferences import resolve_permission_mode
from . import self_update

WORKSPACES_ROOT = Path.home() / "meshcode"
REGISTRY_PATH = WORKSPACES_ROOT / ".registry.json"


def _fetch_or_generate_art(agent: str, project: str) -> tuple:
    """Fetch ASCII art + role + profile color from server.
    Returns (ascii_art, role_description, profile_color)."""
    from .ascii_art import generate_art
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return generate_art(agent), agent, None

    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return generate_art(agent), agent, None

    sb = _load_supabase_env()
    profile_color = None
    try:
        from urllib.request import Request, urlopen
        import urllib.parse
        # Step 1: resolve project_id via RPC (bypasses RLS on mc_projects)
        resolve_body = json.dumps({"p_api_key": api_key, "p_project_name": project})
        proj_req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_project",
            data=resolve_body.encode(),
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
                "Content-Profile": "meshcode",
            },
        )
        with urlopen(proj_req, timeout=5) as resp:
            proj_data = json.loads(resp.read().decode())
        if not proj_data or not proj_data.get("project_id"):
            return generate_art(agent), agent, None
        project_id = proj_data["project_id"]
        # Step 2: fetch existing art + role
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/mc_agents?select=ascii_art,role,id&name=eq.{urllib.parse.quote(agent)}&project_id=eq.{project_id}",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Accept-Profile": "meshcode",
            },
        )
        with urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        if data:
            agent_id = data[0].get("id")
            # Step 3: fetch profile color
            if agent_id:
                try:
                    prof_req = Request(
                        f"{sb['SUPABASE_URL']}/rest/v1/mc_agent_profiles?select=color&agent_id=eq.{agent_id}",
                        headers={
                            "apikey": sb["SUPABASE_KEY"],
                            "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                            "Accept-Profile": "meshcode",
                        },
                    )
                    with urlopen(prof_req, timeout=5) as resp:
                        prof_data = json.loads(resp.read().decode())
                    if prof_data and prof_data[0].get("color"):
                        profile_color = prof_data[0]["color"]
                except Exception:
                    pass
            if data[0].get("ascii_art"):
                return data[0]["ascii_art"], data[0].get("role") or agent, profile_color
    except Exception:
        pass

    # Generate and store
    art = generate_art(agent)
    try:
        body = json.dumps({"p_project_name": project, "p_agent_name": agent, "p_ascii_art": art})
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_store_agent_art",
            data=body.encode(),
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
                "Content-Profile": "meshcode",
            },
        )
        urlopen(req, timeout=5)
    except Exception:
        pass
    return art, agent, profile_color


def _fetch_agent_stats(agent: str, project: str) -> dict:
    """Fetch basic agent stats for achievement badges. Non-critical."""
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return {}
    profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return {}
    sb = _load_supabase_env()
    try:
        from urllib.request import Request, urlopen
        import urllib.parse
        body = json.dumps({
            "p_api_key": api_key,
            "p_project_name": project,
            "p_agent_name": agent,
        }).encode()
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_agent_stats_for_banner",
            data=body, method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
                "Content-Profile": "meshcode",
            },
        )
        with urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def _check_agent_ownership(agent: str, project: str) -> Optional[str]:
    """Pre-flight check: verify caller owns this agent before launching editor.

    Returns an error message string if blocked, None if OK.
    """
    try:
        from .setup_clients import _load_supabase_env
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return None  # Can't check — let the RPC catch it later

    # Try scoped profile first (from invite join), then default
    scoped_profile = f"mesh:{project}:{agent}"
    api_key = secrets_mod.get_api_key(profile=scoped_profile)
    if not api_key:
        profile = os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
        api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return None  # No key — RPC will reject later

    sb = _load_supabase_env()
    try:
        from urllib.request import Request, urlopen
        body = json.dumps({
            "p_api_key": api_key,
            "p_project_name": project,
            "p_agent_name": agent,
        }).encode()
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_check_agent_ownership",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except Exception:
        return None  # Network error — let the RPC catch it later

    if isinstance(data, dict) and data.get("error"):
        return data["error"]
    return None


def _try_auto_setup(agent: str, project: Optional[str] = None) -> Optional[Tuple[Path, str]]:
    """If agent exists on the server but has no local workspace, auto-create it.

    Returns (workspace_path, project_name) on success, None on failure.
    """
    try:
        from .setup_clients import _load_supabase_env, setup_workspace
        import importlib
        secrets_mod = importlib.import_module("meshcode.secrets")
    except Exception:
        return None

    import os as _os
    profile = _os.environ.get("MESHCODE_KEYCHAIN_PROFILE") or "default"
    api_key = secrets_mod.get_api_key(profile=profile)
    if not api_key:
        return None

    sb = _load_supabase_env()

    # Ask the server which project(s) this agent belongs to
    try:
        from urllib.request import Request, urlopen
        body = json.dumps({"p_api_key": api_key, "p_agent_name": agent}).encode()
        req = Request(
            f"{sb['SUPABASE_URL']}/rest/v1/rpc/mc_resolve_agent_projects",
            data=body,
            method="POST",
            headers={
                "apikey": sb["SUPABASE_KEY"],
                "Authorization": f"Bearer {sb['SUPABASE_KEY']}",
                "Content-Type": "application/json",
            },
        )
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
    except Exception:
        return None

    if not isinstance(data, dict) or data.get("error"):
        return None

    projects = data.get("projects", [])
    if not projects:
        return None

    # If user specified a project, filter to that one
    if project:
        projects = [p for p in projects if p["project_name"] == project]
        if not projects:
            return None

    if len(projects) > 1:
        print(f"[meshcode] Agent '{agent}' exists in multiple projects:", file=sys.stderr)
        for p in projects:
            print(f"[meshcode]   meshcode run {agent} --project {p['project_name']}", file=sys.stderr)
        print(f"[meshcode] Specify which one with --project.", file=sys.stderr)
        return None

    resolved_project = projects[0]["project_name"]
    role = projects[0].get("role", "")

    print(f"[meshcode] Workspace recreated automatically for agent '{agent}' (project: {resolved_project})")
    rc = setup_workspace(resolved_project, agent, role)
    if rc != 0:
        return None

    ws = WORKSPACES_ROOT / f"{resolved_project}-{agent}"
    if ws.exists():
        return ws, resolved_project
    return None


def _load_registry() -> dict:
    if not REGISTRY_PATH.exists():
        return {}
    try:
        return json.loads(REGISTRY_PATH.read_text())
    except Exception:
        return {}


def _find_agent_workspace(agent: str, project: Optional[str] = None, quiet: bool = False) -> Optional[Tuple[Path, str]]:
    """Look up the agent in the registry. Returns (workspace_path, project_name) or None.

    If multiple agents share the same name across projects, requires the
    user to disambiguate by passing project explicitly.
    When quiet=True, suppresses error messages (used before auto-setup fallback).
    """
    reg = _load_registry()
    agents = reg.get("agents", {})

    # Direct hit by agent name (current model: agent names unique within registry)
    info = agents.get(agent)
    if info:
        ws = Path(info["workspace"])
        if not ws.exists():
            # Don't print error in quiet mode — caller will try auto-setup
            return None
        if project and info.get("project") != project:
            if not quiet:
                print(f"[meshcode] ERROR: agent '{agent}' belongs to project '{info.get('project')}', not '{project}'", file=sys.stderr)
            return None
        return ws, info.get("project", "")

    # Fallback: scan ~/meshcode for any dir matching <project>-<agent>
    if project:
        ws = WORKSPACES_ROOT / f"{project}-{agent}"
        if ws.exists():
            return ws, project
    else:
        # Scan all workspaces for any matching <*>-<agent>
        if WORKSPACES_ROOT.exists():
            matches = [p for p in WORKSPACES_ROOT.iterdir() if p.is_dir() and p.name.endswith(f"-{agent}")]
            if len(matches) == 1:
                return matches[0], matches[0].name.rsplit(f"-{agent}", 1)[0]
            if len(matches) > 1:
                print(f"[meshcode] ERROR: agent '{agent}' exists in multiple projects:", file=sys.stderr)
                for m in matches:
                    print(f"[meshcode]   {m.name}", file=sys.stderr)
                print(f"[meshcode] Disambiguate: meshcode run {agent} --project <name>", file=sys.stderr)
                return None

    return None


def _detect_editor() -> Optional[str]:
    """Pick the user's preferred MCP-aware editor."""
    override = os.environ.get("MESHCODE_EDITOR", "").strip().lower()
    if override:
        if shutil.which(override):
            return override
        print(f"[meshcode] WARNING: MESHCODE_EDITOR='{override}' not found in PATH", file=sys.stderr)

    # Detection order: most likely to be installed + best per-workspace MCP
    # support first. codex is last because its MCP config is GLOBAL only —
    # launching it doesn't take a workspace-scoped .mcp.json, so it should
    # only be picked if nothing else is available.
    for cmd in ("claude", "cursor", "code", "windsurf", "codex"):
        if shutil.which(cmd):
            return cmd

    # Windows fallback: check common install locations not in PATH
    if sys.platform == "win32":
        appdata = os.environ.get("APPDATA", "")
        localappdata = os.environ.get("LOCALAPPDATA", "")
        win_candidates = [
            os.path.join(appdata, "npm", "claude.cmd"),
            os.path.join(appdata, "npm", "claude"),
            os.path.join(localappdata, "Programs", "claude", "claude.exe"),
            os.path.join(localappdata, "Programs", "cursor", "Cursor.exe"),
            os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "Claude", "claude.exe"),
            os.path.join(os.environ.get("ProgramFiles", r"C:\Program Files"), "nodejs", "claude.cmd"),
        ]
        for c in win_candidates:
            if c and os.path.isfile(c):
                return c
        # Last resort: ask npm where its global bin is
        try:
            npm_bin = subprocess.check_output(["npm", "root", "-g"], text=True, timeout=5).strip()
            # npm root -g returns node_modules dir, bin is one level up
            npm_bin_dir = os.path.dirname(npm_bin)
            for name in ("claude.cmd", "claude.ps1", "claude", "claude.exe"):
                p = os.path.join(npm_bin_dir, name)
                if os.path.isfile(p):
                    return p
        except Exception:
            pass

    return None


def run(agent: str, project: Optional[str] = None, editor_override: Optional[str] = None, permission_override: Optional[str] = None) -> int:
    """Launch the user's editor with ONLY the named agent's MCP server loaded."""
    # Non-blocking self-update check (consumes prior result, may spawn bg pip)
    try:
        self_update.check_and_maybe_update()
    except Exception:
        pass

    # Detect: are we already inside a Claude Code session? os.execvp(claude)
    # from inside an existing claude won't work — claude needs a fresh
    # interactive terminal it owns. Refuse with a clear message.
    if os.environ.get("CLAUDECODE") == "1" or os.environ.get("CLAUDE_CODE_SESSION"):
        print("[meshcode] ERROR: meshcode run cannot bootstrap a new agent from inside an", file=sys.stderr)
        print("[meshcode]        existing Claude Code session.", file=sys.stderr)
        print("[meshcode]        Open a fresh Terminal / iTerm window and run the command there.", file=sys.stderr)
        print(f"[meshcode]        (or copy this exact line into a new terminal: meshcode run {agent})", file=sys.stderr)
        return 2

    found = _find_agent_workspace(agent, project, quiet=True)
    if not found:
        # Auto-setup: if agent exists on the server, recreate workspace
        found = _try_auto_setup(agent, project)
        if not found:
            print(f"[meshcode] ERROR: no workspace found for agent '{agent}'", file=sys.stderr)
            print(f"[meshcode]        Run `meshcode setup <project> {agent}` first.", file=sys.stderr)
            return 2
    ws, resolved_project = found

    # ── Ownership pre-check ──────────────────────────────────────────
    # Before launching the editor, verify the caller owns this agent.
    # This prevents hijacking another user's agent in shared meshworks.
    ownership_err = _check_agent_ownership(agent, resolved_project)
    if ownership_err:
        print(f"[meshcode] ERROR: {ownership_err}", file=sys.stderr)
        return 2
    server_id = f"meshcode-{resolved_project}-{agent}"

    editor = editor_override or _detect_editor()
    if not editor:
        print("[meshcode] ERROR: 'claude' not found in PATH", file=sys.stderr)
        print(f"[meshcode]        Workspace is ready at: {ws}", file=sys.stderr)
        print("[meshcode]        Install Claude Code: npm install -g @anthropic-ai/claude-code", file=sys.stderr)
        if sys.platform == "win32":
            print("[meshcode]        Then verify: where claude", file=sys.stderr)
            print("[meshcode]        If 'where' finds it, open a NEW terminal and try again.", file=sys.stderr)
            print("[meshcode]        Or set: set MESHCODE_EDITOR=<full path to claude.cmd>", file=sys.stderr)
            try:
                npm_root = subprocess.check_output(["npm", "root", "-g"], text=True, timeout=5).strip()
                print(f"[meshcode]        npm global root: {npm_root}", file=sys.stderr)
            except Exception:
                print("[meshcode]        (npm not found — install Node.js first)", file=sys.stderr)
        else:
            print("[meshcode]        Then verify: which claude", file=sys.stderr)
        return 2

    # ── Welcome banner with unique ASCII art + personality ──────────
    try:
        from .ascii_art import generate_art, render_welcome
        from . import __version__ as cli_version
        ascii_art, agent_role, profile_color = _fetch_or_generate_art(agent, resolved_project)
        is_cmd = "commander" in agent.lower() or "commander" in agent_role.lower()
        agent_stats = _fetch_agent_stats(agent, resolved_project)
        print(render_welcome(
            agent, resolved_project, ascii_art, cli_version,
            is_commander=is_cmd, role=agent_role, stats=agent_stats,
            profile_color=profile_color,
        ))
    except Exception:
        pass  # Non-critical — skip banner on error

    print(f"[meshcode] Launching {editor} for agent '{agent}' (project: {resolved_project})")
    print(f"[meshcode]   Workspace: {ws}")
    print(f"[meshcode]   MCP server: {server_id}")
    print(f"[meshcode]   Closing the editor will flip this agent offline.")
    print()

    if editor == "claude":
        # Claude Code: pass --mcp-config to point at the workspace's .mcp.json
        # and --strict-mcp-config so it ignores ~/.claude.json's mcpServers.
        mode = resolve_permission_mode(permission_override)
        cmd = [
            editor,
            "--mcp-config", str(ws / ".mcp.json"),
        ]
        if mode == "bypass":
            cmd.append("--dangerously-skip-permissions")
            print(f"[meshcode]   Permission mode: bypass (autonomous loop, no prompts)")
        else:
            print(f"[meshcode]   Permission mode: safe (Claude will prompt for every tool call)")
            print(f"[meshcode]   Tip: change with `meshcode prefs permission-mode bypass`")
        # Boot prompt: triggers the SESSION START sequence from MCP
        # instructions so the agent auto-initializes (set_status, check
        # messages, claim tasks, greet peers) without waiting for user input.
        # Uses -- to separate options from the positional prompt argument.
        cmd.extend(["--", "boot"])
        try:
            os.chdir(ws)
        except Exception:
            pass
    elif editor == "cursor":
        # Cursor reads .cursor/mcp.json from the workspace cwd.
        cmd = [editor, str(ws)]
    elif editor == "code":
        # VS Code (Cline reads .vscode/mcp.json from workspace cwd).
        cmd = [editor, str(ws)]
    elif editor == "windsurf":
        # Windsurf (Codeium fork of VS Code) — reads workspace cwd the same
        # way VS Code does; global MCP config at ~/.codeium/windsurf/mcp_config.json.
        cmd = [editor, str(ws)]
    elif editor == "codex":
        # Codex CLI reads ~/.codex/config.toml globally. There's no per-
        # workspace flag, so launching is just `codex` with cwd set to the
        # workspace dir so any file ops the agent does land there.
        try:
            os.chdir(ws)
        except Exception:
            pass
        cmd = [editor]
    else:
        cmd = [editor, str(ws)]

    # If stdin is not a tty (e.g. heredoc from `meshcode scan <<'ART'`),
    # replace it with /dev/null so the editor can't seek back and re-read
    # the heredoc content.  We intentionally do NOT reopen /dev/tty here:
    # Claude Code (and other TUI editors) open /dev/tty themselves for raw
    # keyboard input when they detect stdin is not a terminal.  Giving them
    # a dup'd /dev/tty as fd 0 tricks them into a different code-path that
    # breaks interactive input.
    if not sys.stdin.isatty():
        try:
            null_fd = os.open(os.devnull, os.O_RDONLY)
            os.dup2(null_fd, 0)
            os.close(null_fd)
        except OSError:
            pass  # No devnull (unlikely) — let the editor handle it

    try:
        if sys.platform == "win32":
            # Windows: no execvp, use subprocess and wait
            import subprocess as _sp
            result = _sp.run(cmd)
            sys.exit(result.returncode)
        else:
            # Unix: replace this process with the editor
            os.execvp(cmd[0], cmd)
    except FileNotFoundError:
        print(f"[meshcode] ERROR: '{editor}' not found in PATH", file=sys.stderr)
        return 127
    except Exception as e:
        print(f"[meshcode] ERROR launching {editor}: {e}", file=sys.stderr)
        return 1
