"""Sub-agent lifecycle hook protocol.

Provides extension points for:
- prepare_subagent_spawn: before sub-agent execution starts
- on_subagent_ended: after sub-agent finishes/suspends/fails
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass(slots=True)
class SubAgentPrepareContext:
    """Context payload before a sub-agent starts."""

    session_id: str
    invocation_id: str
    parent_block_id: str
    call_id: str
    agent_key: str
    display_name: str
    branch: str | None = None
    task_context: str | None = None
    artifact_refs: list[dict[str, Any]] = field(default_factory=list)


@dataclass(slots=True)
class SubAgentEndContext:
    """Context payload after a sub-agent reaches terminal/suspended state."""

    session_id: str
    invocation_id: str
    parent_block_id: str
    call_id: str
    agent_key: str
    display_name: str
    status: str  # success|failed|suspended|aborted|unknown
    branch: str | None = None
    output: str | None = None
    error: str | None = None
    hitl_id: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)


@runtime_checkable
class SubAgentLifecycleHook(Protocol):
    """Lifecycle extension hook for sub-agent orchestration."""

    async def prepare_subagent_spawn(self, context: SubAgentPrepareContext) -> None:
        """Called before sub-agent execution starts."""
        ...

    async def on_subagent_ended(self, context: SubAgentEndContext) -> None:
        """Called when sub-agent ends/suspends/fails."""
        ...


__all__ = [
    "SubAgentLifecycleHook",
    "SubAgentPrepareContext",
    "SubAgentEndContext",
]
