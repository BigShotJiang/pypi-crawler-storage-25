"""Reusable bridge for sub-agent streaming passthrough + message backfill.

Design goals:
- block channel: forward child BlockEvent to parent queue in realtime.
- message channel: build bounded terminal text for tool result backfill.
- HITL-safe: caller decides suspend semantics; bridge is side-effect free on resume.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, replace
from typing import Any

from .types.action import ActionCollector, ActionEvent, ActionType
from .types.block import BlockAggregator, BlockEvent, BlockKind


@dataclass
class SubAgentBridgeStats:
    """Runtime statistics for bridge forwarding."""

    forwarded_blocks: int = 0
    forwarded_actions: int = 0


class SubAgentStreamBridge:
    """Bridge child agent events into parent stream with dual channels.

    - Realtime: forward child block/action events to parent emit queue.
    - Terminal: aggregate forwarded data into a bounded backfill string.
    """

    def __init__(
        self,
        *,
        parent_queue: Any | None,
        parent_block_id: str,
        default_branch: str | None,
        session_id: str,
        invocation_id: str,
        max_backfill_chars: int = 6000,
        max_truncated_chars: int = 2000,
    ):
        self.parent_queue = parent_queue
        self.parent_block_id = parent_block_id
        self.default_branch = default_branch
        self.session_id = session_id
        self.invocation_id = invocation_id
        self.max_backfill_chars = max_backfill_chars
        self.max_truncated_chars = max_truncated_chars

        self._forwarded_block_ids: set[str] = set()
        self._aggregator = BlockAggregator()
        self._actions = ActionCollector()
        self.stats = SubAgentBridgeStats()

    async def consume(self, event: BlockEvent | ActionEvent) -> None:
        """Consume one child event: collect and forward."""
        if isinstance(event, BlockEvent):
            normalized = self._normalize_block(event)
            self._aggregator.process(normalized)
            if self.parent_queue is not None:
                await self.parent_queue.put(normalized)
                self.stats.forwarded_blocks += 1
        elif isinstance(event, ActionEvent):
            self._actions.collect(event)
            if not event.internal and self.parent_queue is not None:
                await self.parent_queue.put(event)
                self.stats.forwarded_actions += 1

    def collect_action(self, event: ActionEvent) -> None:
        """Collect action from child runtime (e.g., internal collector)."""
        self._actions.collect(event)

    def build_backfill(self) -> tuple[str, str | None]:
        """Build terminal backfill text for ToolResult.

        Returns:
            (output, truncated_output)
        """
        sections: list[str] = []

        for block in self._aggregator.blocks:
            rendered = self._render_block(block.kind, block.data or {})
            if rendered:
                sections.append(rendered)

        for action in self._actions.actions:
            rendered = self._render_action(action)
            if rendered:
                sections.append(rendered)

        output = self._dedupe_sections(sections)
        if not output:
            return "", None

        output = self._truncate(output, self.max_backfill_chars)
        truncated = self._truncate(output, self.max_truncated_chars)
        if truncated == output:
            truncated = None
        return output, truncated

    def _normalize_block(self, event: BlockEvent) -> BlockEvent:
        """Normalize child block for parent stream compatibility."""
        normalized = replace(event)

        if not normalized.parent_id or normalized.parent_id not in self._forwarded_block_ids:
            normalized.parent_id = self.parent_block_id

        if not normalized.branch:
            normalized.branch = self.default_branch

        if not normalized.session_id:
            normalized.session_id = self.session_id
        if not normalized.invocation_id:
            normalized.invocation_id = self.invocation_id

        self._forwarded_block_ids.add(normalized.block_id)
        return normalized

    def _render_block(self, kind: BlockKind | str, data: dict[str, Any]) -> str | None:
        kind_str = kind.value if isinstance(kind, BlockKind) else kind

        if kind_str in {BlockKind.TEXT.value, BlockKind.THINKING.value}:
            content = self._pick_text(data)
            return content or None

        if kind_str == BlockKind.TOOL_USE.value:
            status = str(data.get("status") or "").strip().lower()
            if status not in {"success", "failed", "aborted", "suspended"}:
                return None
            tool_name = (
                data.get("display_name")
                or data.get("name")
                or data.get("tool_name")
                or "tool"
            )
            summary = f"[tool:{tool_name}] status={status}"
            extras: list[str] = []
            error_text = data.get("error")
            if isinstance(error_text, str) and error_text.strip():
                extras.append(f"error={error_text.strip()[:160]}")
            search_results = data.get("search_results")
            if isinstance(search_results, list):
                extras.append(f"results={len(search_results)}")
            if extras:
                summary = f"{summary} ({'; '.join(extras)})"
            return summary

        if kind_str == BlockKind.ARTIFACT.value:
            artifact_id = data.get("artifact_id", "")
            title = data.get("title") or data.get("name") or data.get("filename") or artifact_id
            url = data.get("url") or data.get("content_url")
            if title and url:
                return f"[artifact] {title}: {url}"
            if title:
                return f"[artifact] {title}"
            return None

        if kind_str == BlockKind.ERROR.value:
            message = data.get("message")
            if isinstance(message, str) and message.strip():
                return f"[error] {message.strip()}"
            return f"[error] {self._safe_json(data)}"

        return None

    def _render_action(self, action: ActionEvent) -> str | None:
        action_type = action.action.value if isinstance(action.action, ActionType) else action.action

        if action_type == ActionType.SET_RESULT.value:
            text = self._pick_text(action.data)
            if text:
                return text
            return self._safe_json(action.data)

        if action_type == ActionType.PROGRESS.value:
            message = action.data.get("message")
            if isinstance(message, str) and message.strip():
                return f"[progress] {message.strip()}"

        if action_type == ActionType.TASK_COMPLETION.value:
            agent = action.data.get("display_name") or action.data.get("agent") or "subagent"
            status = action.data.get("status") or "unknown"
            summary = self._pick_text(action.data)
            if summary:
                return f"[task_completion:{agent}] {summary}"
            return f"[task_completion:{agent}] status={status}"

        return None

    @staticmethod
    def _pick_text(payload: dict[str, Any]) -> str:
        for key in ("content", "text", "message", "output", "result"):
            value = payload.get(key)
            if isinstance(value, str) and value.strip():
                return value.strip()
        return ""

    @staticmethod
    def _safe_json(payload: Any) -> str:
        try:
            return json.dumps(payload, ensure_ascii=False)
        except Exception:
            return str(payload)

    @staticmethod
    def _dedupe_sections(sections: list[str]) -> str:
        ordered: list[str] = []
        seen: set[str] = set()
        for item in sections:
            value = item.strip()
            if not value or value in seen:
                continue
            seen.add(value)
            ordered.append(value)
        return "\n\n".join(ordered)

    @staticmethod
    def _truncate(text: str, limit: int) -> str:
        if limit <= 0 or len(text) <= limit:
            return text
        if limit < 128:
            return text[:limit]

        head = int(limit * 0.6)
        tail = max(0, limit - head - 48)
        omitted = len(text) - head - tail
        marker = f"\n\n... (delegate backfill truncated, omitted {omitted} chars) ...\n\n"
        return f"{text[:head]}{marker}{text[-tail:] if tail else ''}"
