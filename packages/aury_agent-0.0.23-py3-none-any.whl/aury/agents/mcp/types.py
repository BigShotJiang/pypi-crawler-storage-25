"""MCP protocol types and data structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MCPTransport(str, Enum):
    """MCP transport types."""

    STDIO = "stdio"
    HTTP = "http"
    SSE = "sse"


@dataclass
class MCPTool:
    """MCP tool definition."""

    name: str
    description: str | None = None
    input_schema: dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPToolResult:
    """MCP tool execution result."""

    content: list[dict[str, Any]] = field(default_factory=list)
    is_error: bool = False
    structured_content: dict[str, Any] | None = None

    @property
    def text(self) -> str:
        """Extract text from content."""
        texts = []
        for item in self.content:
            if item.get("type") == "text":
                texts.append(item.get("text", ""))
            elif item.get("type") == "image":
                texts.append(f"[Image: {item.get('mimeType', 'unknown')}]")
            elif item.get("type") == "resource":
                texts.append(f"[Resource: {item.get('resource', {}).get('uri', 'unknown')}]")
        return "\n".join(texts) if texts else ""


@dataclass
class MCPServerCapabilities:
    """MCP server capabilities."""

    tools: dict[str, Any] | None = None
    resources: dict[str, Any] | None = None
    prompts: dict[str, Any] | None = None
    logging: dict[str, Any] | None = None


@dataclass
class MCPClientCapabilities:
    """MCP client capabilities."""

    sampling: dict[str, Any] | None = None
    roots: dict[str, Any] | None = None
    experimental: dict[str, Any] | None = None


@dataclass
class MCPInitializeResult:
    """MCP initialize result."""

    protocol_version: str
    capabilities: MCPServerCapabilities
    server_info: dict[str, Any] = field(default_factory=dict)


@dataclass
class MCPRequest:
    """MCP JSON-RPC request."""

    jsonrpc: str = "2.0"
    id: int | str | None = None
    method: str = ""
    params: dict[str, Any] | None = None


@dataclass
class MCPResponse:
    """MCP JSON-RPC response."""

    jsonrpc: str = "2.0"
    id: int | str | None = None
    result: dict[str, Any] | None = None
    error: dict[str, Any] | None = None


@dataclass
class MCPNotification:
    """MCP JSON-RPC notification."""

    jsonrpc: str = "2.0"
    method: str = ""
    params: dict[str, Any] | None = None
