"""MCP Toolset - Connect to external MCP servers and use their tools."""

from __future__ import annotations

import time
from typing import Any

from ..core.logging import agent_logger as logger
from ..core.types.tool import BaseTool, ToolContext, ToolResult
from ..tool.set import ToolSet
from .client import MCPClient, MCPClientError
from .types import MCPTool


class MCPToolWrapper(BaseTool):
    """Wrapper that converts an MCP tool to an Aury BaseTool."""

    def __init__(
        self,
        mcp_tool: MCPTool,
        client: MCPClient,
        server_key: str | None = None,
    ):
        self._mcp_tool = mcp_tool
        self._client = client
        self._server_key = server_key or "default"

        # Set tool properties from MCP tool
        self._name = mcp_tool.name
        self._display_name = mcp_tool.name.replace("_", " ").title()
        self._description = mcp_tool.description or f"MCP tool: {mcp_tool.name}"
        self._parameters = mcp_tool.input_schema or {
            "type": "object",
            "properties": {},
            "required": [],
        }

    async def execute(self, params: dict[str, Any], ctx: ToolContext) -> ToolResult:
        """Execute the MCP tool."""
        start_time = time.time()

        try:
            # Call the MCP tool
            result = await self._client.call_tool(self._mcp_tool.name, params)
            duration_ms = int((time.time() - start_time) * 1000)

            # Report usage
            await self._report_usage(ctx, duration_ms, is_error=result.is_error)

            if result.is_error:
                return ToolResult.error(
                    result.text or f"MCP tool {self._mcp_tool.name} returned error"
                )

            return ToolResult.success(
                output=result.text or "Tool executed successfully",
                truncated_output=self._truncate_output(result.text),
            )
        except MCPClientError as e:
            duration_ms = int((time.time() - start_time) * 1000)
            await self._report_usage(ctx, duration_ms, error=str(e), is_error=True)
            return ToolResult.error(f"MCP tool error: {e}")
        except Exception as e:
            duration_ms = int((time.time() - start_time) * 1000)
            await self._report_usage(ctx, duration_ms, error=str(e), is_error=True)
            return ToolResult.error(f"Tool execution failed: {e}")

    def _truncate_output(self, text: str | None, max_chars: int = 1500) -> str:
        """Truncate output for context window management."""
        if not text:
            return ""
        if len(text) <= max_chars:
            return text
        return text[: max_chars - 1] + "…"

    async def _report_usage(
        self,
        ctx: ToolContext,
        duration_ms: int,
        error: str | None = None,
        is_error: bool = False,
    ) -> None:
        """Report MCP tool usage for billing."""
        try:
            from app.agents.handlers.usage_handler import record_usage
            from app.agents.tools.utils import get_usage_context

            usage_ctx = get_usage_context(ctx)
            if not usage_ctx:
                return

            await record_usage(
                tenant_id=usage_ctx.tenant_id,
                identity_id=usage_ctx.identity_id,
                source_type="mcp",
                source_key=f"{self._server_key}:{self._mcp_tool.name}",
                session_id=usage_ctx.session_id,
                space_id=usage_ctx.space_id,
                trace_id=usage_ctx.trace_id,
                invocation_id=usage_ctx.invocation_id,
                step_no=usage_ctx.step_no,
                tool_call_id=usage_ctx.tool_call_id,
                metrics={
                    "units": 1,
                    "mcp_server_key": self._server_key,
                    "mcp_method": self._mcp_tool.name,
                    "is_error": is_error,
                },
                duration_ms=duration_ms,
                error=error,
            )
        except ImportError:
            # syngents-specific module not available, skip usage reporting
            pass
        except Exception as e:
            logger.warning(f"[MCP] Failed to report usage: {e}")


class MCPToolset:
    """Connect to external MCP servers and use their tools.

    Usage:
        # Via stdio
        mcp_tools = MCPToolset(
            connection_params=StdioServerParams(
                command="npx",
                args=["-y", "@modelcontextprotocol/server-filesystem", "/path"],
            ),
            tool_filter=["read_file", "list_directory"],
        )

        # Via HTTP
        mcp_tools = MCPToolset(
            connection_params=HttpServerParams(url="http://localhost:8080/mcp"),
        )

        # Get tools
        tools = await mcp_tools.get_tools()

        # Use with agent
        agent = ReactAgent.create(llm=llm, tools=[mcp_tools])
    """

    def __init__(
        self,
        connection_params: Any,  # StdioServerParams or HttpServerParams
        tool_filter: list[str] | None = None,
        server_key: str | None = None,
    ):
        from . import HttpServerParams, StdioServerParams

        self.connection_params = connection_params
        self.tool_filter = tool_filter
        self.server_key = server_key or self._generate_server_key(connection_params)

        # Create MCP client based on connection params
        if isinstance(connection_params, StdioServerParams):
            self._client = MCPClient.create_stdio(
                command=connection_params.command,
                args=connection_params.args,
                env=connection_params.env,
            )
        elif isinstance(connection_params, HttpServerParams):
            self._client = MCPClient.create_http(
                url=connection_params.url,
                headers=connection_params.headers,
            )
        else:
            raise ValueError(f"Unknown connection params type: {type(connection_params)}")

        self._tools: list[MCPToolWrapper] | None = None
        self._connected = False

    def _generate_server_key(self, params: Any) -> str:
        """Generate a server key from connection params."""
        from . import HttpServerParams, StdioServerParams

        if isinstance(params, StdioServerParams):
            return f"stdio:{params.command}"
        elif isinstance(params, HttpServerParams):
            return f"http:{params.url}"
        return "unknown"

    async def connect(self) -> None:
        """Connect to MCP server and initialize."""
        if self._connected:
            return

        try:
            await self._client.connect()
            await self._client.initialize()
            self._connected = True
            logger.info(f"[MCP] Toolset connected: {self.server_key}")
        except Exception as e:
            logger.error(f"[MCP] Failed to connect: {e}")
            raise

    async def disconnect(self) -> None:
        """Disconnect from MCP server."""
        if not self._connected:
            return

        try:
            await self._client.disconnect()
            self._connected = False
            self._tools = None
            logger.info(f"[MCP] Toolset disconnected: {self.server_key}")
        except Exception as e:
            logger.warning(f"[MCP] Error during disconnect: {e}")

    async def get_tools(self) -> list[MCPToolWrapper]:
        """Get tools from MCP server.

        Returns a list of MCPToolWrapper instances that can be used as Aury tools.
        """
        if self._tools is not None:
            return self._tools

        if not self._connected:
            await self.connect()

        try:
            # Get tools from MCP server
            mcp_tools = await self._client.list_tools()

            # Filter tools if specified
            if self.tool_filter:
                mcp_tools = [t for t in mcp_tools if t.name in self.tool_filter]

            # Wrap MCP tools as Aury tools
            self._tools = [
                MCPToolWrapper(
                    mcp_tool=tool,
                    client=self._client,
                    server_key=self.server_key,
                )
                for tool in mcp_tools
            ]

            logger.info(
                f"[MCP] Loaded {len(self._tools)} tools from {self.server_key}: "
                f"{[t.name for t in self._tools]}"
            )

            return self._tools
        except Exception as e:
            logger.error(f"[MCP] Failed to get tools: {e}")
            raise

    def to_toolset(self) -> ToolSet:
        """Convert to Aury ToolSet.

        This is a synchronous helper that returns an empty ToolSet.
        Use get_tools() to get the actual tools after connecting.
        """
        return ToolSet()

    async def to_toolset_async(self) -> ToolSet:
        """Convert to Aury ToolSet asynchronously.

        Connects to the MCP server and returns a ToolSet with all available tools.
        """
        tools = await self.get_tools()
        return ToolSet.from_list(tools)

    @property
    def is_connected(self) -> bool:
        """Check if connected to MCP server."""
        return self._connected

    @property
    def client(self) -> MCPClient:
        """Get the underlying MCP client."""
        return self._client


__all__ = [
    "MCPToolset",
    "MCPToolWrapper",
]
