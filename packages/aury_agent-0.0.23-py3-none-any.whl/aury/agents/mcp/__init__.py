"""MCP (Model Context Protocol) module.

This module provides:
- MCPToolset: Connect to external MCP servers and use their tools
- MCPClient: Low-level MCP client for discovery
- MCPServer: Expose Aury tools as MCP server (TODO)

Reference: Model Context Protocol
https://modelcontextprotocol.io/
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from .client import (
    HTTPTransport,
    MCPClient,
    MCPClientError,
    MCPConnectionError,
    MCPProtocolError,
    StdioTransport,
)
from .toolset import MCPToolset, MCPToolWrapper
from .types import (
    MCPClientCapabilities,
    MCPInitializeResult,
    MCPServerCapabilities,
    MCPTool,
    MCPToolResult,
)

if TYPE_CHECKING:
    from ..tool import BaseTool


# =============================================================================
# Connection Parameters
# =============================================================================


@dataclass
class StdioServerParams:
    """Parameters for connecting to MCP server via stdio."""

    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)


@dataclass
class HttpServerParams:
    """Parameters for connecting to MCP server via HTTP."""

    url: str
    headers: dict[str, str] = field(default_factory=dict)


# =============================================================================
# TODO: MCP Server
# =============================================================================


class MCPServer:
    """Expose Aury tools as MCP server.

    TODO: Implement MCP server.

    Usage:
        server = MCPServer(
            name="my_service",
            tools=[my_tool1, my_tool2],
            transport="http",
            port=8000,
        )
        await server.start()
    """

    def __init__(
        self,
        name: str,
        tools: list[BaseTool],
        transport: str = "stdio",
        host: str = "0.0.0.0",
        port: int = 8000,
    ):
        self.name = name
        self.tools = tools
        self.transport = transport
        self.host = host
        self.port = port
        raise NotImplementedError("TODO: MCP server not yet implemented")

    async def start(self) -> None:
        """Start MCP server."""
        raise NotImplementedError("TODO: MCP server not yet implemented")

    async def stop(self) -> None:
        """Stop MCP server."""
        raise NotImplementedError("TODO: MCP server not yet implemented")


__all__ = [
    # Connection params
    "HttpServerParams",
    "StdioServerParams",
    # Client
    "MCPClient",
    "MCPClientError",
    "MCPConnectionError",
    "MCPProtocolError",
    # Transport
    "HTTPTransport",
    "StdioTransport",
    # Toolset
    "MCPToolset",
    "MCPToolWrapper",
    # Types
    "MCPClientCapabilities",
    "MCPInitializeResult",
    "MCPTool",
    "MCPToolResult",
    "MCPServerCapabilities",
    # Server (TODO)
    "MCPServer",
]
