"""MCP client implementation with stdio and HTTP transport support."""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from typing import Any

from ..core.logging import agent_logger as logger
from .types import (
    MCPClientCapabilities,
    MCPInitializeResult,
    MCPNotification,
    MCPRequest,
    MCPResponse,
    MCPServerCapabilities,
    MCPTool,
    MCPToolResult,
)


class MCPClientError(Exception):
    """MCP client error."""

    pass


class MCPConnectionError(MCPClientError):
    """MCP connection error."""

    pass


class MCPProtocolError(MCPClientError):
    """MCP protocol error."""

    def __init__(self, message: str, code: int | None = None, data: Any = None):
        super().__init__(message)
        self.code = code
        self.data = data


class MCPTransportBase(ABC):
    """Base class for MCP transports."""

    @abstractmethod
    async def connect(self) -> None:
        """Connect to MCP server."""
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """Disconnect from MCP server."""
        pass

    @abstractmethod
    async def send_request(self, request: MCPRequest) -> MCPResponse:
        """Send request and wait for response."""
        pass

    @abstractmethod
    async def send_notification(self, notification: MCPNotification) -> None:
        """Send notification (no response expected)."""
        pass

    @property
    @abstractmethod
    def is_connected(self) -> bool:
        """Check if transport is connected."""
        pass


class StdioTransport(MCPTransportBase):
    """MCP stdio transport implementation."""

    def __init__(
        self,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ):
        self.command = command
        self.args = args or []
        self.env = env or {}
        self._process: asyncio.subprocess.Process | None = None
        self._request_id = 0
        self._pending_requests: dict[int, asyncio.Future[MCPResponse]] = {}
        self._reader_task: asyncio.Task[None] | None = None
        self._is_connected = False

    @property
    def is_connected(self) -> bool:
        return self._is_connected and self._process is not None

    async def connect(self) -> None:
        """Connect to MCP server via stdio."""
        try:
            import os

            env = {**os.environ, **self.env}

            self._process = await asyncio.create_subprocess_exec(
                self.command,
                *self.args,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )
            self._is_connected = True
            self._reader_task = asyncio.create_task(self._read_responses())
            logger.info(f"[MCP] stdio transport connected: {self.command}")
        except Exception as e:
            raise MCPConnectionError(f"Failed to start MCP server: {e}") from e

    async def disconnect(self) -> None:
        """Disconnect from MCP server."""
        self._is_connected = False

        if self._reader_task:
            self._reader_task.cancel()
            try:
                await self._reader_task
            except asyncio.CancelledError:
                pass
            self._reader_task = None

        if self._process:
            try:
                self._process.terminate()
                await asyncio.wait_for(self._process.wait(), timeout=5.0)
            except TimeoutError:
                self._process.kill()
                await self._process.wait()
            except Exception:
                pass
            self._process = None

        # Cancel pending requests
        for future in self._pending_requests.values():
            if not future.done():
                future.cancel()
        self._pending_requests.clear()
        logger.info("[MCP] stdio transport disconnected")

    async def send_request(self, request: MCPRequest) -> MCPResponse:
        """Send request via stdio."""
        if not self.is_connected or not self._process or not self._process.stdin:
            raise MCPConnectionError("Not connected")

        self._request_id += 1
        request.id = self._request_id

        future: asyncio.Future[MCPResponse] = asyncio.get_event_loop().create_future()
        self._pending_requests[self._request_id] = future

        try:
            message = json.dumps(self._request_to_dict(request)) + "\n"
            self._process.stdin.write(message.encode())
            await self._process.stdin.drain()

            response = await asyncio.wait_for(future, timeout=30.0)
            return response
        except TimeoutError:
            self._pending_requests.pop(self._request_id, None)
            raise MCPConnectionError("Request timeout") from None
        except Exception as e:
            self._pending_requests.pop(self._request_id, None)
            raise MCPConnectionError(f"Failed to send request: {e}") from e

    async def send_notification(self, notification: MCPNotification) -> None:
        """Send notification via stdio."""
        if not self.is_connected or not self._process or not self._process.stdin:
            raise MCPConnectionError("Not connected")

        try:
            message = json.dumps(self._notification_to_dict(notification)) + "\n"
            self._process.stdin.write(message.encode())
            await self._process.stdin.drain()
        except Exception as e:
            raise MCPConnectionError(f"Failed to send notification: {e}") from e

    async def _read_responses(self) -> None:
        """Read responses from stdout."""
        if not self._process or not self._process.stdout:
            return

        try:
            while self._is_connected:
                line = await self._process.stdout.readline()
                if not line:
                    break

                try:
                    data = json.loads(line.decode().strip())
                    if "id" in data and data["id"] in self._pending_requests:
                        future = self._pending_requests.pop(data["id"])
                        if not future.done():
                            response = self._dict_to_response(data)
                            future.set_result(response)
                    elif "method" in data:
                        # Handle notification from server
                        logger.debug(f"[MCP] Received notification: {data.get('method')}")
                except json.JSONDecodeError:
                    logger.warning(f"[MCP] Invalid JSON received: {line[:100]}")
                except Exception as e:
                    logger.error(f"[MCP] Error processing response: {e}")
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"[MCP] Reader task error: {e}")

    @staticmethod
    def _request_to_dict(request: MCPRequest) -> dict[str, Any]:
        """Convert request to dict."""
        result: dict[str, Any] = {"jsonrpc": request.jsonrpc, "method": request.method}
        if request.id is not None:
            result["id"] = request.id
        if request.params is not None:
            result["params"] = request.params
        return result

    @staticmethod
    def _notification_to_dict(notification: MCPNotification) -> dict[str, Any]:
        """Convert notification to dict."""
        result: dict[str, Any] = {"jsonrpc": notification.jsonrpc, "method": notification.method}
        if notification.params is not None:
            result["params"] = notification.params
        return result

    @staticmethod
    def _dict_to_response(data: dict[str, Any]) -> MCPResponse:
        """Convert dict to response."""
        return MCPResponse(
            jsonrpc=data.get("jsonrpc", "2.0"),
            id=data.get("id"),
            result=data.get("result"),
            error=data.get("error"),
        )


class HTTPTransport(MCPTransportBase):
    """MCP HTTP transport implementation."""

    def __init__(
        self,
        url: str,
        headers: dict[str, str] | None = None,
    ):
        self.url = url
        self.headers = headers or {}
        self._session: Any = None  # aiohttp.ClientSession
        self._request_id = 0
        self._is_connected = False

    @property
    def is_connected(self) -> bool:
        return self._is_connected

    async def connect(self) -> None:
        """Connect to MCP server via HTTP."""
        try:
            import aiohttp

            self._session = aiohttp.ClientSession(headers=self.headers)
            self._is_connected = True
            logger.info(f"[MCP] HTTP transport connected: {self.url}")
        except ImportError as e:
            raise MCPConnectionError("aiohttp is required for HTTP transport") from e
        except Exception as e:
            raise MCPConnectionError(f"Failed to connect to MCP server: {e}") from e

    async def disconnect(self) -> None:
        """Disconnect from MCP server."""
        self._is_connected = False
        if self._session:
            await self._session.close()
            self._session = None
        logger.info("[MCP] HTTP transport disconnected")

    async def send_request(self, request: MCPRequest) -> MCPResponse:
        """Send request via HTTP POST."""
        if not self.is_connected or not self._session:
            raise MCPConnectionError("Not connected")

        self._request_id += 1
        request.id = self._request_id

        try:
            payload = {
                "jsonrpc": request.jsonrpc,
                "id": request.id,
                "method": request.method,
            }
            if request.params is not None:
                payload["params"] = request.params

            async with self._session.post(self.url, json=payload) as resp:
                if resp.status != 200:
                    raise MCPConnectionError(f"HTTP error: {resp.status}")
                data = await resp.json()
                return self._dict_to_response(data)
        except Exception as e:
            raise MCPConnectionError(f"Failed to send request: {e}") from e

    async def send_notification(self, notification: MCPNotification) -> None:
        """Send notification via HTTP POST."""
        if not self.is_connected or not self._session:
            raise MCPConnectionError("Not connected")

        try:
            payload = {
                "jsonrpc": notification.jsonrpc,
                "method": notification.method,
            }
            if notification.params is not None:
                payload["params"] = notification.params

            async with self._session.post(self.url, json=payload) as resp:
                if resp.status != 200:
                    logger.warning(f"[MCP] Notification HTTP error: {resp.status}")
        except Exception as e:
            logger.error(f"[MCP] Failed to send notification: {e}")

    @staticmethod
    def _dict_to_response(data: dict[str, Any]) -> MCPResponse:
        """Convert dict to response."""
        return MCPResponse(
            jsonrpc=data.get("jsonrpc", "2.0"),
            id=data.get("id"),
            result=data.get("result"),
            error=data.get("error"),
        )


class MCPClient:
    """MCP client for connecting to MCP servers."""

    def __init__(self, transport: MCPTransportBase):
        self.transport = transport
        self._initialized = False
        self._server_capabilities: MCPServerCapabilities | None = None
        self._server_info: dict[str, Any] = {}

    @classmethod
    def create_stdio(
        cls,
        command: str,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
    ) -> MCPClient:
        """Create MCP client with stdio transport."""
        transport = StdioTransport(command, args, env)
        return cls(transport)

    @classmethod
    def create_http(
        cls,
        url: str,
        headers: dict[str, str] | None = None,
    ) -> MCPClient:
        """Create MCP client with HTTP transport."""
        transport = HTTPTransport(url, headers)
        return cls(transport)

    async def connect(self) -> None:
        """Connect to MCP server."""
        await self.transport.connect()

    async def disconnect(self) -> None:
        """Disconnect from MCP server."""
        self._initialized = False
        self._server_capabilities = None
        await self.transport.disconnect()

    async def initialize(
        self,
        client_capabilities: MCPClientCapabilities | None = None,
        client_info: dict[str, Any] | None = None,
    ) -> MCPInitializeResult:
        """Initialize MCP connection."""
        if not self.transport.is_connected:
            raise MCPConnectionError("Not connected")

        params: dict[str, Any] = {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": client_info or {"name": "aury-agent", "version": "1.0.0"},
        }

        if client_capabilities:
            if client_capabilities.sampling:
                params["capabilities"]["sampling"] = client_capabilities.sampling
            if client_capabilities.roots:
                params["capabilities"]["roots"] = client_capabilities.roots
            if client_capabilities.experimental:
                params["capabilities"]["experimental"] = client_capabilities.experimental

        request = MCPRequest(method="initialize", params=params)
        response = await self.transport.send_request(request)

        if response.error:
            raise MCPProtocolError(
                response.error.get("message", "Initialize failed"),
                code=response.error.get("code"),
                data=response.error.get("data"),
            )

        result = response.result or {}
        capabilities_data = result.get("capabilities", {})

        self._server_capabilities = MCPServerCapabilities(
            tools=capabilities_data.get("tools"),
            resources=capabilities_data.get("resources"),
            prompts=capabilities_data.get("prompts"),
            logging=capabilities_data.get("logging"),
        )
        self._server_info = result.get("serverInfo", {})

        # Send initialized notification
        notification = MCPNotification(method="notifications/initialized")
        await self.transport.send_notification(notification)

        self._initialized = True

        return MCPInitializeResult(
            protocol_version=result.get("protocolVersion", "2024-11-05"),
            capabilities=self._server_capabilities,
            server_info=self._server_info,
        )

    async def list_tools(self) -> list[MCPTool]:
        """List available tools from MCP server."""
        if not self._initialized:
            raise MCPClientError("Client not initialized")

        request = MCPRequest(method="tools/list")
        response = await self.transport.send_request(request)

        if response.error:
            raise MCPProtocolError(
                response.error.get("message", "Failed to list tools"),
                code=response.error.get("code"),
                data=response.error.get("data"),
            )

        tools_data = (response.result or {}).get("tools", [])
        return [
            MCPTool(
                name=tool.get("name", ""),
                description=tool.get("description"),
                input_schema=tool.get("inputSchema", {}),
            )
            for tool in tools_data
        ]

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
    ) -> MCPToolResult:
        """Call a tool on the MCP server."""
        if not self._initialized:
            raise MCPClientError("Client not initialized")

        params: dict[str, Any] = {"name": name}
        if arguments is not None:
            params["arguments"] = arguments

        request = MCPRequest(method="tools/call", params=params)
        response = await self.transport.send_request(request)

        if response.error:
            raise MCPProtocolError(
                response.error.get("message", f"Failed to call tool {name}"),
                code=response.error.get("code"),
                data=response.error.get("data"),
            )

        result = response.result or {}
        return MCPToolResult(
            content=result.get("content", []),
            is_error=result.get("isError", False),
            structured_content=result.get("structuredContent"),
        )

    async def list_resources(self) -> list[dict[str, Any]]:
        """List available resources from MCP server."""
        if not self._initialized:
            raise MCPClientError("Client not initialized")

        request = MCPRequest(method="resources/list")
        response = await self.transport.send_request(request)

        if response.error:
            raise MCPProtocolError(
                response.error.get("message", "Failed to list resources"),
                code=response.error.get("code"),
                data=response.error.get("data"),
            )

        return (response.result or {}).get("resources", [])

    async def read_resource(self, uri: str) -> dict[str, Any]:
        """Read a resource from MCP server."""
        if not self._initialized:
            raise MCPClientError("Client not initialized")

        request = MCPRequest(method="resources/read", params={"uri": uri})
        response = await self.transport.send_request(request)

        if response.error:
            raise MCPProtocolError(
                response.error.get("message", f"Failed to read resource {uri}"),
                code=response.error.get("code"),
                data=response.error.get("data"),
            )

        return response.result or {}

    @property
    def is_initialized(self) -> bool:
        """Check if client is initialized."""
        return self._initialized

    @property
    def server_capabilities(self) -> MCPServerCapabilities | None:
        """Get server capabilities."""
        return self._server_capabilities

    @property
    def server_info(self) -> dict[str, Any]:
        """Get server info."""
        return self._server_info


__all__ = [
    "MCPClient",
    "MCPClientError",
    "MCPConnectionError",
    "MCPProtocolError",
    "MCPTransportBase",
    "StdioTransport",
    "HTTPTransport",
]
