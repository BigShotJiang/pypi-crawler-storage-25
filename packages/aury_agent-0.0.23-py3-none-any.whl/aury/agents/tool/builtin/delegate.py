"""Delegate tool - delegate tasks to sub-agents.

Uses SubAgentBackend to retrieve available agents.
LLM specifies agent key and task data.
Mode is determined by agent config, not LLM.

Supports parallel execution of multiple sub-agents.
"""
from __future__ import annotations

import asyncio
from datetime import datetime
from typing import Any, TYPE_CHECKING

from ...core.logging import tool_logger as logger
from ...core.subagent_bridge import SubAgentStreamBridge
from ...core.subagent_lifecycle import (
    SubAgentEndContext,
    SubAgentLifecycleHook,
    SubAgentPrepareContext,
)
from ...core.types.action import ActionEvent, ActionType
from ...core.types.tool import BaseTool, ToolContext, ToolResult
from ...core.types.session import generate_id, ControlFrame
from ...core.types.subagent import SubAgentResult, SubAgentMetadata
from ...core.types.block import BlockEvent, BlockKind, BlockOp
from ...core.parallel import ParallelSubAgentContext
from ...core.signals import HITLSuspend

if TYPE_CHECKING:
    from ...backends.subagent import SubAgentBackend, AgentConfig
    from ...middleware import MiddlewareChain


class DelegateTool(BaseTool):
    """Delegate tasks to sub-agents.
    
    Uses SubAgentBackend to retrieve available agents.
    The execution mode (embedded/delegated) is determined by agent config.
    """
    
    _name = "delegate"
    
    def __init__(
        self,
        subagent_backend: "SubAgentBackend",
        middleware: "MiddlewareChain | None" = None,
        lifecycle_hook: "SubAgentLifecycleHook | None" = None,
    ):
        """Initialize with SubAgentBackend.
        
        Args:
            subagent_backend: Backend for retrieving sub-agents
            middleware: Optional middleware chain for progressive disclosure
            lifecycle_hook: Optional lifecycle hook for spawn/end orchestration
        """
        self.backend = subagent_backend
        self.middleware = middleware
        self.lifecycle_hook = lifecycle_hook
        self._description_cache: str | None = None
        self._parameters_cache: dict | None = None
        self._active_block_ids: dict[str, str] = {}  # session_id:agent -> block_id
        self._dynamic_agents: dict[str, "AgentConfig"] = {}  # Dynamic agents from middleware
    
    @property
    def name(self) -> str:
        return self._name
    
    def _get_agents_sync(self) -> list["AgentConfig"]:
        """Synchronously get agent list for property getters."""
        if hasattr(self.backend, 'list_sync'):
            return self.backend.list_sync()
        return []
    
    @property
    def description(self) -> str:
        """Build description with available agents."""
        agents = self._get_agents_sync()
        if not agents:
            return "Delegate a task to a specialized sub-agent. No agents currently available."
        
        agent_list = "\n".join([
            f"  - {a.key}: {a.description or 'No description'}"
            for a in agents
        ])
        return f"""Delegate a task to a specialized sub-agent.

Use this tool immediately when:
- the user explicitly asks to let a specific agent handle the task
- the task clearly matches one specialized agent
- parallel specialist execution is more efficient than doing it yourself

Available agents:
{agent_list}

Do not ask the user to repeat the task if the current conversation already contains enough information.
Provide task_context (user intent, background, requirements) and artifact_refs (related materials) for the sub-agent."""
    
    @property
    def parameters(self) -> dict[str, Any]:
        """Build parameters with agent enum."""
        agents = self._get_agents_sync()
        agent_keys = [a.key for a in agents] if agents else []
        
        agent_schema: dict[str, Any] = {
            "type": "string",
            "description": "Key of the agent to delegate to",
        }
        if agent_keys:
            agent_schema["enum"] = agent_keys
        
        return {
            "type": "object",
            "properties": {
                "agent": agent_schema,
                "task_context": {
                    "type": "string",
                    "description": "任务上下文：尽可能描述用户意图、背景信息、具体要求。包括用户最初的问题、对话中提到的偏好、强调的重点等。",
                },
                "artifact_refs": {
                    "type": "array",
                    "description": "相关资料引用列表，每项包含 id 和 summary",
                    "items": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string", "description": "Artifact ID"},
                            "summary": {"type": "string", "description": "摘要"},
                        },
                        "required": ["id"],
                    },
                },
            },
            "required": ["agent"],
        }
    
    async def get_dynamic_description(self, ctx: ToolContext | None = None) -> str:
        """Build description with available agents.
        
        Includes both static agents from backend and dynamic agents from middleware.
        """
        agents = await self._get_all_agents(ctx)
        if not agents:
            return "Delegate a task to a sub-agent. No agents currently available."
        
        agent_list = "\n".join([
            f"- {a.key}: {a.description or 'No description'} (mode: {a.mode})"
            for a in agents
        ])
        return f"""Delegate a task to a specialized sub-agent.

Prefer this tool when:
- the user directly says “委派/交给/让某个 Agent 来做”
- a specialist agent is clearly better suited than the current agent
- the task can be split to another agent without extra clarification

If the user already gave enough context, delegate directly instead of asking the user to restate the request.

Available agents:
{agent_list}

Specify the agent key and task data."""
    
    async def _get_all_agents(
        self,
        ctx: ToolContext | None = None,
    ) -> list["AgentConfig"]:
        """Get all available agents (static + dynamic from middleware).
        
        Args:
            ctx: Optional tool context for middleware disclosure
            
        Returns:
            Combined list of AgentConfig
        """
        # Get static agents from backend
        agents = list(await self.backend.list())
        
        # Get dynamic agents from middleware (progressive disclosure)
        if self.middleware and ctx:
            dynamic_agents = await self.middleware.get_dynamic_subagents()
            if dynamic_agents:
                # Store dynamic agents for later lookup
                for config in dynamic_agents:
                    self._dynamic_agents[config.key] = config
                agents.extend(dynamic_agents)
        
        return agents
    
    async def _get_agent_config(
        self,
        key: str,
        ctx: ToolContext | None = None,
    ) -> "AgentConfig | None":
        """Get agent config by key (static or dynamic).
        
        Args:
            key: Agent key
            ctx: Optional tool context
            
        Returns:
            AgentConfig or None if not found
        """
        # First check static backend
        config = await self.backend.get(key)
        if config:
            return config
        
        # Then check dynamic agents from middleware
        if key in self._dynamic_agents:
            return self._dynamic_agents[key]
        
        # If not found and we have middleware, try to refresh dynamic agents
        if self.middleware and ctx:
            await self._get_all_agents(ctx)
            return self._dynamic_agents.get(key)
        
        return None
    
    async def execute(
        self,
        params: dict[str, Any],
        ctx: ToolContext,
    ) -> ToolResult:
        """Execute delegation.
        
        Supports two modes:
        1. Single agent: {"agent": "name", "data": {...}}
        2. Parallel agents: {"agents": [{"agent": "name1", "data": {...}}, ...]}
        """
        # Check if parallel execution
        agents_param = params.get("agents")
        if agents_param and isinstance(agents_param, list) and len(agents_param) > 1:
            return await self._execute_parallel(agents_param, ctx)
        
        # Single agent execution
        agent_key = params.get("agent", "")
        task_context = params.get("task_context")
        artifact_refs = params.get("artifact_refs")
        
        # Handle single item in agents array
        if agents_param and len(agents_param) == 1:
            agent_key = agents_param[0].get("agent", "")
            task_context = task_context or agents_param[0].get("task_context")
            artifact_refs = artifact_refs or agents_param[0].get("artifact_refs")
        
        if not agent_key:
            return ToolResult.error("Missing 'agent' parameter")
        
        logger.info(
            "Delegating to sub-agent",
            extra={
                "agent": agent_key,
                "invocation_id": ctx.invocation_id,
                "session_id": ctx.session_id,
            },
        )
        
        # Get agent config (static or dynamic)
        config = await self._get_agent_config(agent_key, ctx)
        if config is None:
            logger.error(
                f"Unknown sub-agent: {agent_key}",
                extra={"invocation_id": ctx.invocation_id},
            )
            agents = await self._get_all_agents(ctx)
            available = ", ".join(a.key for a in agents) or "none"
            return ToolResult.error(f"Unknown agent: {agent_key}. Available: {available}")
        
        # Create block_id for this delegation
        block_key = f"{ctx.session_id}:{config.key}"
        block_id = generate_id("blk")
        self._active_block_ids[block_key] = block_id

        prepared = await self._run_prepare_hook(
            config=config,
            ctx=ctx,
            parent_block_id=block_id,
            task_context=task_context,
            artifact_refs=artifact_refs,
        )
        if not prepared:
            self._active_block_ids.pop(block_key, None)
            await self._emit_task_completion(
                config=config,
                ctx=ctx,
                status="failed",
                parent_block_id=block_id,
                error="lifecycle_prepare_failed",
            )
            await self._run_end_hook(
                config=config,
                ctx=ctx,
                parent_block_id=block_id,
                status="failed",
                error="lifecycle_prepare_failed",
            )
            return ToolResult.error(f"Sub-agent '{agent_key}' prepare failed")
        
        # Emit SUB_AGENT block (start)
        await self._emit_subagent_block(
            ctx,
            config,
            "start",
            block_id,
            parent_id=ctx.block_id,
        )
        await self._emit_subagent_assignment(
            ctx=ctx,
            config=config,
            parent_block_id=block_id,
            task_context=task_context,
            artifact_refs=artifact_refs,
        )
        
        try:
            # 根据 create_invocation 决定执行模式
            mode = "delegated" if config.create_invocation else "embedded"
            logger.debug(
                f"Executing sub-agent in {mode} mode",
                extra={"agent": agent_key, "invocation_id": ctx.invocation_id},
            )
            
            if config.create_invocation:
                result = await self._execute_delegated(
                    config, ctx, task_context, artifact_refs
                )
            else:
                result = await self._execute_embedded(
                    config,
                    ctx,
                    parent_block_id=block_id,
                    task_context=task_context,
                    artifact_refs=artifact_refs,
                )

            if result.is_error:
                await self._emit_subagent_terminal_text(
                    ctx=ctx,
                    parent_block_id=block_id,
                    content=result.output,
                    status="failed",
                )
                await self._emit_subagent_block(
                    ctx,
                    config,
                    "error",
                    block_id,
                    parent_id=ctx.block_id,
                )
                await self._emit_task_completion(
                    config=config,
                    ctx=ctx,
                    status="failed",
                    parent_block_id=block_id,
                    error=result.output,
                )
                await self._run_end_hook(
                    config=config,
                    ctx=ctx,
                    parent_block_id=block_id,
                    status="failed",
                    error=result.output,
                )
                self._active_block_ids.pop(block_key, None)
                return result
            
            logger.info(
                f"Sub-agent execution completed",
                extra={
                    "agent": agent_key,
                    "invocation_id": ctx.invocation_id,
                    "is_error": result.is_error,
                },
            )
            
            # Emit SUB_AGENT block (end)
            await self._emit_subagent_block(
                ctx,
                config,
                "end",
                block_id,
                parent_id=ctx.block_id,
            )
            await self._emit_task_completion(
                config=config,
                ctx=ctx,
                status="success",
                parent_block_id=block_id,
                output=result.output,
            )
            await self._run_end_hook(
                config=config,
                ctx=ctx,
                parent_block_id=block_id,
                status="success",
                output=result.output,
            )
            
            # Cleanup
            self._active_block_ids.pop(block_key, None)
            
            return result
        except HITLSuspend as suspend:
            await self._emit_subagent_block(
                ctx,
                config,
                "suspended",
                block_id,
                parent_id=ctx.block_id,
            )
            await self._emit_task_completion(
                config=config,
                ctx=ctx,
                status="suspended",
                parent_block_id=block_id,
                hitl_id=getattr(suspend, "hitl_id", None),
            )
            await self._run_end_hook(
                config=config,
                ctx=ctx,
                parent_block_id=block_id,
                status="suspended",
                hitl_id=getattr(suspend, "hitl_id", None),
            )
            self._active_block_ids.pop(block_key, None)
            raise
        except Exception as e:
            logger.error(
                "Sub-agent delegation failed",
                extra={"agent": agent_key, "invocation_id": ctx.invocation_id, "error": str(e)},
                exc_info=True,
            )
            # Emit error state
            await self._emit_subagent_block(
                ctx,
                config,
                "error",
                block_id,
                parent_id=ctx.block_id,
            )
            await self._emit_task_completion(
                config=config,
                ctx=ctx,
                status="failed",
                parent_block_id=block_id,
                error=str(e),
            )
            await self._run_end_hook(
                config=config,
                ctx=ctx,
                parent_block_id=block_id,
                status="failed",
                error=str(e),
            )
            self._active_block_ids.pop(block_key, None)
            return ToolResult.error(f"Delegation failed: {str(e)}")
    
    async def _execute_parallel(
        self,
        agents_param: list[dict[str, Any]],
        ctx: ToolContext,
    ) -> ToolResult:
        """Execute multiple sub-agents in parallel.
        
        Args:
            agents_param: List of {"agent": "name", ...}
            ctx: Tool context
            
        Returns:
            Combined results from all agents
        """
        logger.info(
            "Parallel delegation",
            extra={
                "agents": [a.get("agent") for a in agents_param],
                "invocation_id": ctx.invocation_id,
                "session_id": ctx.session_id,
                "count": len(agents_param),
            },
        )
        
        # Validate all agents exist
        configs: list[tuple["AgentConfig", dict[str, Any]]] = []
        for item in agents_param:
            agent_key = item.get("agent", "")
            
            config = await self._get_agent_config(agent_key, ctx)
            if config is None:
                agents = await self._get_all_agents(ctx)
                available = ", ".join(a.key for a in agents) or "none"
                return ToolResult.error(f"Unknown agent: {agent_key}. Available: {available}")
            configs.append((config, item))
        
        # Create parallel context for tracking
        parallel_ctx = ParallelSubAgentContext(
            parent_invocation_id=ctx.invocation_id,
            session_id=ctx.session_id,
        )
        
        # Emit parallel start block
        parallel_block_id = generate_id("blk")
        await self._emit_parallel_block(
            ctx,
            [c.key for c, _ in configs],
            "start",
            parallel_block_id,
            parent_id=ctx.block_id,
        )
        
        # Execute all agents in parallel
        async def run_one(
            config: "AgentConfig",
            args: dict[str, Any],
        ) -> tuple[str, ToolResult, HITLSuspend | None]:
            """Run single agent and return (name, result)."""
            branch_id = parallel_ctx.create_branch(config.key)
            block_id = generate_id("blk")
            
            try:
                prepared = await self._run_prepare_hook(
                    config=config,
                    ctx=ctx,
                    parent_block_id=block_id,
                    task_context=args.get("task_context"),
                    artifact_refs=args.get("artifact_refs"),
                    branch=branch_id,
                )
                if not prepared:
                    await self._emit_subagent_block(
                        ctx,
                        config,
                        "error",
                        block_id,
                        branch=branch_id,
                        parent_id=parallel_block_id,
                    )
                    await self._emit_task_completion(
                        config=config,
                        ctx=ctx,
                        status="failed",
                        parent_block_id=block_id,
                        branch=branch_id,
                        error="lifecycle_prepare_failed",
                    )
                    await self._run_end_hook(
                        config=config,
                        ctx=ctx,
                        parent_block_id=block_id,
                        status="failed",
                        branch=branch_id,
                        error="lifecycle_prepare_failed",
                    )
                    return (
                        config.key,
                        ToolResult.error("Sub-agent prepare failed"),
                        None,
                    )

                # Emit individual agent start
                await self._emit_subagent_block(
                    ctx,
                    config,
                    "start",
                    block_id,
                    branch=branch_id,
                    parent_id=parallel_block_id,
                )
                await self._emit_subagent_assignment(
                    ctx=ctx,
                    config=config,
                    parent_block_id=block_id,
                    task_context=args.get("task_context"),
                    artifact_refs=args.get("artifact_refs"),
                    branch=branch_id,
                )
                
                # 根据 create_invocation 决定执行模式
                if config.create_invocation:
                    result = await self._execute_delegated(
                        config,
                        ctx,
                        task_context=args.get("task_context"),
                        artifact_refs=args.get("artifact_refs"),
                    )
                else:
                    result = await self._execute_embedded(
                        config,
                        ctx,
                        parent_block_id=block_id,
                        task_context=args.get("task_context"),
                        artifact_refs=args.get("artifact_refs"),
                        branch=branch_id,
                    )

                if result.is_error:
                    await self._emit_subagent_terminal_text(
                        ctx=ctx,
                        parent_block_id=block_id,
                        content=result.output,
                        status="failed",
                        branch=branch_id,
                    )
                    await self._emit_subagent_block(
                        ctx,
                        config,
                        "error",
                        block_id,
                        branch=branch_id,
                        parent_id=parallel_block_id,
                    )
                    await self._emit_task_completion(
                        config=config,
                        ctx=ctx,
                        status="failed",
                        parent_block_id=block_id,
                        branch=branch_id,
                        error=result.output,
                    )
                    await self._run_end_hook(
                        config=config,
                        ctx=ctx,
                        parent_block_id=block_id,
                        status="failed",
                        branch=branch_id,
                        error=result.output,
                    )
                    parallel_ctx.mark_failed(config.key, result.output)
                    return (
                        config.key,
                        result,
                        None,
                    )
                
                # Emit individual agent end
                await self._emit_subagent_block(
                    ctx,
                    config,
                    "end",
                    block_id,
                    branch=branch_id,
                    parent_id=parallel_block_id,
                )
                await self._emit_task_completion(
                    config=config,
                    ctx=ctx,
                    status="success",
                    parent_block_id=block_id,
                    branch=branch_id,
                    output=result.output,
                )
                await self._run_end_hook(
                    config=config,
                    ctx=ctx,
                    parent_block_id=block_id,
                    status="success",
                    branch=branch_id,
                    output=result.output,
                )
                
                parallel_ctx.mark_completed(config.key, result)
                return (config.key, result, None)
            except HITLSuspend as suspend:
                # 子分支 HITL：标记为 suspended，等待其它并行分支结束后统一上抛
                parallel_ctx.mark_completed(config.key, {"status": "suspended"})
                await self._emit_subagent_block(
                    ctx,
                    config,
                    "suspended",
                    block_id,
                    branch=branch_id,
                    parent_id=parallel_block_id,
                )
                await self._emit_task_completion(
                    config=config,
                    ctx=ctx,
                    status="suspended",
                    parent_block_id=block_id,
                    branch=branch_id,
                    hitl_id=getattr(suspend, "hitl_id", None),
                )
                await self._run_end_hook(
                    config=config,
                    ctx=ctx,
                    parent_block_id=block_id,
                    status="suspended",
                    branch=branch_id,
                    hitl_id=getattr(suspend, "hitl_id", None),
                )
                return (
                    config.key,
                    ToolResult.success(""),
                    suspend,
                )
                
            except Exception as e:
                error_msg = str(e)
                parallel_ctx.mark_failed(config.key, error_msg)
                await self._emit_subagent_block(
                    ctx,
                    config,
                    "error",
                    block_id,
                    branch=branch_id,
                    parent_id=parallel_block_id,
                )
                await self._emit_task_completion(
                    config=config,
                    ctx=ctx,
                    status="failed",
                    parent_block_id=block_id,
                    branch=branch_id,
                    error=error_msg,
                )
                await self._run_end_hook(
                    config=config,
                    ctx=ctx,
                    parent_block_id=block_id,
                    status="failed",
                    branch=branch_id,
                    error=error_msg,
                )
                return (
                    config.key,
                    ToolResult.error(f"Delegation failed: {error_msg}"),
                    None,
                )
        
        # Run all agents in parallel using asyncio.gather
        tasks = [run_one(config, args) for config, args in configs]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Combine results
        combined_output = []
        suspended_signals: dict[str, HITLSuspend] = {}
        
        for item in results:
            if isinstance(item, HITLSuspend):
                suspended_signals["unknown"] = item
            elif isinstance(item, Exception):
                combined_output.append(f"Error: {str(item)}")
            elif isinstance(item, tuple):
                name, result, suspend_signal = item
                if suspend_signal is not None:
                    suspended_signals[name] = suspend_signal
                    continue
                rendered = result.output.strip()
                if rendered:
                    combined_output.append(f"[{name}] {rendered}")

        # 并行中存在任一挂起：父链路也应挂起，不能提前回到上层
        if suspended_signals:
            await self._emit_parallel_block(
                ctx,
                [c.key for c, _ in configs],
                "suspended",
                parallel_block_id,
                parent_id=ctx.block_id,
            )
            if len(suspended_signals) == 1:
                single = next(iter(suspended_signals.values()))
                raise single
            raise HITLSuspend(
                hitl_id=ctx.call_id,
                hitl_type="parallel_subagent",
                data={
                    "pending_agents": {
                        name: signal.to_dict()
                        for name, signal in suspended_signals.items()
                    },
                },
                tool_name="delegate",
                block_id=parallel_block_id,
                metadata={"pending_agents": list(suspended_signals.keys())},
            )

        # Emit parallel end block
        await self._emit_parallel_block(
            ctx,
            [c.key for c, _ in configs],
            "end",
            parallel_block_id,
            parent_id=ctx.block_id,
        )
        
        return ToolResult.success("\n\n".join(combined_output))
    
    def _get_merged_middleware(
        self,
        config: "AgentConfig",
        ctx: ToolContext,
    ) -> "MiddlewareChain | None":
        """Get merged middleware for sub-agent execution.
        
        Merges caller's inheritable middlewares with sub-agent's own middlewares.
        
        Args:
            config: Sub-agent config
            ctx: Tool context containing caller's middleware
            
        Returns:
            Merged MiddlewareChain or None
        """
        caller_middleware = ctx.middleware
        
        # Get sub-agent's middleware (if agent is an instance with middleware)
        sub_agent = config.agent
        sub_middleware = getattr(sub_agent, 'middleware', None)
        
        # Merge: caller's inheritable + sub-agent's own
        if caller_middleware:
            return caller_middleware.merge(sub_middleware)
        elif sub_middleware:
            return sub_middleware
        
        return None
    
    async def _execute_embedded(
        self,
        config: "AgentConfig",
        ctx: ToolContext,
        *,
        parent_block_id: str,
        task_context: str | None = None,
        artifact_refs: list[dict[str, str]] | None = None,
        branch: str | None = None,
    ) -> ToolResult:
        """Execute in embedded mode (inline, same invocation).
        
        Embedded 模式特点：
        - 不创建新 invocation
        - BlockEvent 透传到父 agent 的 queue
        - ActionEvent 被收集，用于获取 sub-agent 结果
        - 客户端可以实时看到 sub-agent 的执行过程
        
        消息记录配置：
        - config.record_messages=False → SubAgent 不记录消息
        - config.message_namespace → 消息写入独立命名空间（隔离）
        """
        from ...core.types.action import ActionEvent
        from ...core.context import _emit_queue_var
        
        start_time = datetime.now()
        
        # Get agent instance
        agent = config.agent
        if agent is None:
            return ToolResult.error(f"Agent '{config.key}' not found")
        
        # Configure message recording for sub-agent
        self._configure_subagent_messages(agent, config, ctx)
        
        # Build input message
        input_message = self._build_input_message(task_context, artifact_refs)
        
        logger.info(f"Starting sub-agent '{config.key}' in embedded mode")
        logger.info(f"Input: {input_message[:300]}...")
        
        # Capture parent queue BEFORE sub-agent sets its own
        # This is critical - sub-agent's run() will set ContextVar to its own queue
        try:
            parent_queue = _emit_queue_var.get()
        except LookupError:
            parent_queue = None

        bridge = SubAgentStreamBridge(
            parent_queue=parent_queue,
            parent_block_id=parent_block_id,
            default_branch=branch or config.key,
            session_id=ctx.session_id,
            invocation_id=ctx.invocation_id,
        )
        
        # Get timeout from config (default 5 min)
        timeout = getattr(config, 'timeout', 300.0)
        
        try:
            # 消费事件流：BlockEvent 转发，ActionEvent 收集
            # 使用 _force_own_queue=True 让 sub-agent 创建自己的 queue
            # 实现活跃刷新超时：收到事件时重置超时
            import asyncio
            
            async def iter_with_activity_timeout():
                """Iterate with activity-based timeout refresh."""
                stream = agent.run(
                    input_message,
                    _force_own_queue=True,
                    enable_thinking=True,
                    stream_thinking=True,
                )
                while True:
                    try:
                        event = await asyncio.wait_for(stream.__anext__(), timeout=timeout)
                    except StopAsyncIteration:
                        break
                    except asyncio.TimeoutError as timeout_error:
                        raise asyncio.TimeoutError(
                            f"Sub-agent timed out after {timeout}s of inactivity"
                        ) from timeout_error
                    yield event
            
            async for event in iter_with_activity_timeout():
                if isinstance(event, ActionEvent):
                    await bridge.consume(event)
                    continue
                await bridge.consume(event)
                await asyncio.sleep(0)
            
            logger.info(f"Sub-agent '{config.key}' completed")

            pending_request: dict[str, Any] | None = None
            try:
                agent_state = getattr(agent, "state", None)
                if agent_state is not None:
                    pending_request = agent_state.execution.get("pending_request")
            except Exception:
                pending_request = None

            current_invocation = getattr(agent, "_current_invocation", None)
            current_state = getattr(getattr(current_invocation, "state", None), "value", None)
            if pending_request or current_state == "suspended":
                if isinstance(pending_request, dict) and pending_request.get("hitl_id"):
                    raise HITLSuspend.from_dict(pending_request)
                raise HITLSuspend(
                    hitl_id=ctx.call_id,
                    hitl_type="ask_user",
                    data={},
                    tool_name="delegate",
                    block_id=parent_block_id,
                )
        
        except HITLSuspend:
            raise
        except Exception as e:
            logger.error(f"Sub-agent execution failed: {e}")
            return ToolResult.error(f"Sub-agent '{config.key}' failed: {str(e)}")

        duration_ms = int((datetime.now() - start_time).total_seconds() * 1000)
        logger.debug(
            "Sub-agent embedded forwarding done",
            extra={
                "agent": config.key,
                "invocation_id": ctx.invocation_id,
                "duration_ms": duration_ms,
                "forwarded_blocks": bridge.stats.forwarded_blocks,
            },
        )

        if not config.return_to_parent:
            return ToolResult.success("")

        # Merge internal ActionEvents collected by child runtime.
        action_collector = getattr(agent, "_action_collector", None)
        if action_collector and hasattr(action_collector, "actions"):
            for action in action_collector.actions:
                if isinstance(action, ActionEvent) and action.internal:
                    bridge.collect_action(action)

        output, truncated = bridge.build_backfill()
        has_child_text = any(
            (
                (item.kind.value if hasattr(item.kind, "value") else item.kind)
                in {BlockKind.TEXT.value, BlockKind.THINKING.value}
            )
            for item in bridge._aggregator.blocks
        )
        if output and not has_child_text:
            await self._emit_subagent_terminal_text(
                ctx=ctx,
                parent_block_id=parent_block_id,
                content=truncated or output,
                status="completed",
                branch=branch,
            )
        if bridge.stats.forwarded_blocks == 0 and not output:
            return ToolResult.error(
                f"Sub-agent '{config.key}' produced no stream events"
            )
        return ToolResult.success(output, truncated_output=truncated)
    
    def _configure_subagent_messages(
        self,
        agent: Any,
        config: "AgentConfig",
        ctx: ToolContext,
    ) -> None:
        """Configure sub-agent's message recording based on config.
        
        消息记录策略（由 return_to_parent 派生）：
        - record_messages=False → 禁用消息保存
        - record_messages=True → 保存到独立 namespace（agent_key:call_id）
        
        每次委派调用使用 call_id 保证对话独立。
        """
        if not config.record_messages:
            # 禁用消息保存
            agent._disable_message_save = True
            if hasattr(agent, '_message_namespace'):
                delattr(agent, '_message_namespace')
        else:
            # 保存到独立 namespace
            agent._message_namespace = f"{config.key}:{ctx.call_id}"
            agent._disable_message_save = False
    
    def _build_input_message(
        self,
        task_context: str | None = None,
        artifact_refs: list[dict[str, str]] | None = None,
    ) -> str:
        """构建输入消息.
        
        Args:
            task_context: 任务上下文
            artifact_refs: 相关资料引用
        """
        parts = []
        
        # 任务上下文
        if task_context:
            parts.append(f"任务背景：\n{task_context}")
        
        # 相关资料
        if artifact_refs:
            refs_text = "\n".join([
                f"- [{r.get('id', '')}] {r.get('summary', '')[:100]}"
                for r in artifact_refs
            ])
            parts.append(f"可用资料（使用 read_artifact 工具获取完整内容）：\n{refs_text}")
        parts.append("输出要求：执行完成后必须给出简洁中文结论，不要只停留在工具调用记录。")
        
        return "\n\n".join(parts) if parts else "请执行任务"
    
    def _extract_text_from_event(self, event: Any) -> str | None:
        """从 agent event 中提取文本."""
        # BlockEvent with text content
        if hasattr(event, 'kind'):
            kind = event.kind.value if hasattr(event.kind, 'value') else event.kind
            if kind == "text" and hasattr(event, 'data') and event.data:
                return event.data.get('content', '')
        
        # Direct text delta
        if hasattr(event, 'text_delta'):
            return event.text_delta
        
        return None
    
    def _extract_data_from_event(self, event: Any) -> dict[str, Any] | None:
        """从 agent event 中提取结构化数据."""
        # ARTIFACT block
        if hasattr(event, 'kind'):
            kind = event.kind.value if hasattr(event.kind, 'value') else event.kind
            if kind == "artifact" and hasattr(event, 'data') and event.data:
                return {
                    "artifact_id": event.data.get('artifact_id'),
                    "url": event.data.get('url'),
                }
        
        # Tool result with metadata
        if hasattr(event, 'metadata') and event.metadata:
            if 'artifact_id' in event.metadata:
                return {
                    "artifact_id": event.metadata.get('artifact_id'),
                    "url": event.metadata.get('url'),
                }
        
        return None
    
    async def _emit_subagent_progress(
        self,
        ctx: ToolContext,
        config: "AgentConfig",
        event: Any,
    ) -> None:
        """发送 sub-agent 进度事件（transient，不持久化）."""
        # 直接转发 event，但标记为 sub-agent 的
        if hasattr(event, 'to_dict'):
            # 已经是 BlockEvent，直接转发
            await self.emit(event)
    
    async def _execute_delegated(
        self,
        config: "AgentConfig",
        ctx: ToolContext,
        task_context: str | None = None,
        artifact_refs: list[dict[str, str]] | None = None,
    ) -> ToolResult:
        """Execute in delegated mode (new invocation, user can interact)."""
        child_inv_id = generate_id("inv")
        
        # Get merged middleware for sub-agent
        merged_middleware = self._get_merged_middleware(config, ctx)
        
        # Create control frame
        frame = ControlFrame(
            agent_id=config.key,
            invocation_id=child_inv_id,
            parent_invocation_id=ctx.invocation_id,
        )
        
        # Note: Real implementation would:
        # 1. Push frame to session.control_stack
        # 2. Create child InvocationContext with merged_middleware
        # 3. Inject yield_result tool
        # 4. Start agent execution
        # 5. Return - user continues with sub-agent
        
        result = SubAgentResult(
            output=f"[DELEGATED] Control transferred to {config.key}. User can interact directly.",
            status="completed",
            metadata=SubAgentMetadata(
                child_invocation_id=child_inv_id,
                agent_name=config.key,
                agent_type="react",
            ),
        )
        
        return ToolResult(output=result.output)

    async def _emit_task_completion(
        self,
        *,
        config: "AgentConfig",
        ctx: ToolContext,
        status: str,
        output: str | None = None,
        error: str | None = None,
        hitl_id: str | None = None,
        parent_block_id: str | None = None,
        branch: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Emit typed internal completion event for orchestration handoff."""
        payload: dict[str, Any] = {
            "source": "subagent",
            "agent": config.key,
            "display_name": config.display_name or config.key,
            "status": status,
            "session_id": ctx.session_id,
            "invocation_id": ctx.invocation_id,
            "call_id": ctx.call_id,
        }
        if parent_block_id:
            payload["parent_block_id"] = parent_block_id
        if branch:
            payload["branch"] = branch
        if output:
            payload["output"] = output
        if error:
            payload["error"] = error
        if hitl_id:
            payload["hitl_id"] = hitl_id
        if metadata:
            payload["metadata"] = metadata

        await self.emit(ActionEvent(
            action=ActionType.TASK_COMPLETION,
            data=payload,
            branch=branch or config.key,
            internal=True,
        ))

    async def _run_prepare_hook(
        self,
        *,
        config: "AgentConfig",
        ctx: ToolContext,
        parent_block_id: str,
        task_context: str | None = None,
        artifact_refs: list[dict[str, Any]] | None = None,
        branch: str | None = None,
    ) -> bool:
        """Run optional pre-spawn lifecycle hook.

        Returns:
            True if hook succeeded or absent, False if failed.
        """
        if self.lifecycle_hook is None:
            return True
        try:
            await self.lifecycle_hook.prepare_subagent_spawn(SubAgentPrepareContext(
                session_id=str(ctx.session_id),
                invocation_id=str(ctx.invocation_id),
                parent_block_id=parent_block_id,
                call_id=str(ctx.call_id),
                agent_key=config.key,
                display_name=config.display_name or config.key,
                branch=branch,
                task_context=task_context,
                artifact_refs=list(artifact_refs or []),
            ))
            return True
        except Exception as e:
            logger.error(
                "Subagent lifecycle prepare hook failed",
                extra={
                    "agent": config.key,
                    "invocation_id": ctx.invocation_id,
                    "error": str(e),
                },
                exc_info=True,
            )
            return False

    async def _run_end_hook(
        self,
        *,
        config: "AgentConfig",
        ctx: ToolContext,
        parent_block_id: str,
        status: str,
        output: str | None = None,
        error: str | None = None,
        hitl_id: str | None = None,
        branch: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Run optional post-end lifecycle hook (best-effort)."""
        if self.lifecycle_hook is None:
            return
        try:
            await self.lifecycle_hook.on_subagent_ended(SubAgentEndContext(
                session_id=str(ctx.session_id),
                invocation_id=str(ctx.invocation_id),
                parent_block_id=parent_block_id,
                call_id=str(ctx.call_id),
                agent_key=config.key,
                display_name=config.display_name or config.key,
                status=status,
                branch=branch,
                output=output,
                error=error,
                hitl_id=hitl_id,
                metadata=metadata or {},
            ))
        except Exception as e:
            logger.error(
                "Subagent lifecycle end hook failed",
                extra={
                    "agent": config.key,
                    "invocation_id": ctx.invocation_id,
                    "status": status,
                    "error": str(e),
                },
                exc_info=True,
            )

    async def _emit_subagent_block(
        self,
        ctx: ToolContext,
        config: "AgentConfig",
        stage: str,
        block_id: str,
        branch: str | None = None,
        parent_id: str | None = None,
    ) -> None:
        """Emit SUB_AGENT block."""
        status_map = {
            "start": "running",
            "end": "success",
            "error": "failed",
            "suspended": "suspended",
        }
        label = config.display_name or config.key
        avatar_url = str(getattr(config, "avatar_url", "") or "").strip()
        block = BlockEvent(
            block_id=block_id,
            parent_id=parent_id,
            kind=BlockKind.SUB_AGENT,
            op=BlockOp.APPLY if stage == "start" else BlockOp.PATCH,
            data={
                "agent": config.key,
                "name": config.key,
                "display_name": label,
                "subagent_label": label,
                "is_subagent": True,
                "mode": config.mode,
                "stage": stage,
                "status": status_map.get(stage, "running"),
                "branch": branch,
                "avatar_url": avatar_url or None,
            },
            session_id=ctx.session_id,
            invocation_id=ctx.invocation_id,
        )
        
        await self.emit(block)

    def _build_assignment_text(
        self,
        *,
        config: "AgentConfig",
        task_context: str | None = None,
        artifact_refs: list[dict[str, Any]] | None = None,
    ) -> str:
        """Build immediate plain-text assignment preview for UI visibility."""
        label = config.display_name or config.key
        task = "请基于当前会话上下文继续执行。"
        if isinstance(task_context, str):
            normalized = " ".join(task_context.strip().split())
            if normalized:
                task = normalized
        max_len = 240
        if len(task) > max_len:
            task = f"{task[:max_len].rstrip()}…"

        refs = artifact_refs if isinstance(artifact_refs, list) else []
        ref_count = sum(1 for item in refs if isinstance(item, dict) and item.get("id"))
        suffix = f"\n已附带资料：{ref_count} 项。" if ref_count > 0 else ""
        return f"已指派给「{label}」执行任务：{task}{suffix}"

    async def _emit_subagent_assignment(
        self,
        *,
        ctx: ToolContext,
        config: "AgentConfig",
        parent_block_id: str,
        task_context: str | None = None,
        artifact_refs: list[dict[str, Any]] | None = None,
        branch: str | None = None,
    ) -> None:
        """Emit an immediate assignment text block under sub-agent container."""
        block = BlockEvent(
            block_id=generate_id("blk"),
            parent_id=parent_block_id,
            kind=BlockKind.TEXT,
            op=BlockOp.APPLY,
            data={
                "content": self._build_assignment_text(
                    config=config,
                    task_context=task_context,
                    artifact_refs=artifact_refs,
                ),
                "status": "completed",
                "message_type": "subagent_assignment",
            },
            branch=branch,
            session_id=ctx.session_id,
            invocation_id=ctx.invocation_id,
        )
        await self.emit(block)

    async def _emit_subagent_terminal_text(
        self,
        *,
        ctx: ToolContext,
        parent_block_id: str,
        content: str,
        status: str = "completed",
        branch: str | None = None,
    ) -> None:
        """Emit terminal text under sub-agent container for visibility."""
        normalized = str(content or "").strip()
        if not normalized:
            return
        block = BlockEvent(
            block_id=generate_id("blk"),
            parent_id=parent_block_id,
            kind=BlockKind.TEXT,
            op=BlockOp.APPLY,
            data={
                "content": normalized,
                "status": status,
                "message_type": "subagent_terminal",
            },
            branch=branch,
            session_id=ctx.session_id,
            invocation_id=ctx.invocation_id,
        )
        await self.emit(block)

    async def _emit_parallel_block(
        self,
        ctx: ToolContext,
        agents: list[str],
        stage: str,
        block_id: str,
        parent_id: str | None = None,
    ) -> None:
        """Emit PARALLEL block for parallel execution."""
        status_map = {
            "start": "running",
            "end": "success",
            "error": "failed",
            "suspended": "suspended",
        }
        block = BlockEvent(
            block_id=block_id,
            parent_id=parent_id,
            kind=BlockKind.SUB_AGENT,  # Use SUB_AGENT with parallel flag
            op=BlockOp.APPLY if stage == "start" else BlockOp.PATCH,
            data={
                "parallel": True,
                "agents": agents,
                "stage": stage,
                "status": status_map.get(stage, "running"),
            },
            session_id=ctx.session_id,
            invocation_id=ctx.invocation_id,
        )
        
        await self.emit(block)


__all__ = ["DelegateTool"]
