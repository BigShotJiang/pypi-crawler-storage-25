"""Loop control helpers for ReactAgent execution."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

from ..core.logging import react_logger as logger
from ..core.types import ToolInvocation, ToolResult
from ..core.types.block import BlockEvent, BlockKind, BlockOp

if TYPE_CHECKING:
    from .agent import ReactAgent


DEFAULT_MAX_STEPS = 50
DEFAULT_MAX_CONSECUTIVE_TOOL_CALLS = 5


def coerce_positive_int(value: Any) -> int | None:
    """Coerce positive integer-like values from config."""
    if isinstance(value, bool):
        return None
    try:
        normalized = int(str(value).strip()) if isinstance(value, str) else int(value)
    except (TypeError, ValueError):
        return None
    if normalized <= 0:
        return None
    return normalized


def resolve_step_limit(value: Any, *, default_limit: int = DEFAULT_MAX_STEPS) -> int:
    """Resolve max_steps from config, falling back to framework default."""
    return coerce_positive_int(value) or default_limit


def resolve_max_consecutive_tool_calls(
    value: Any,
    *,
    default_limit: int = DEFAULT_MAX_CONSECUTIVE_TOOL_CALLS,
) -> int:
    """Resolve the per-fingerprint consecutive tool-call allowance."""
    return coerce_positive_int(value) or default_limit


def resolve_max_same_tool_calls(value: Any, *, default_limit: int = DEFAULT_MAX_CONSECUTIVE_TOOL_CALLS) -> int:
    """Backward-compatible alias for older naming."""
    return resolve_max_consecutive_tool_calls(value, default_limit=default_limit)


def reset_tool_call_repeat_state(agent: ReactAgent) -> None:
    """Reset per-invocation repeated-tool streak state."""
    agent._tool_call_repeat_state = {"fingerprint": None, "count": 0}


def reset_tool_call_fingerprint_counts(agent: ReactAgent) -> None:
    """Backward-compatible alias for resetting repeat state."""
    reset_tool_call_repeat_state(agent)


def reset_successful_tool_fingerprints(agent: ReactAgent) -> None:
    """Backward-compatible alias for resetting repeated-tool state."""
    reset_tool_call_repeat_state(agent)


def has_exceeded_step_limit(agent: ReactAgent) -> bool:
    """Check whether the current invocation has exceeded the configured step budget."""
    return agent._current_step > resolve_step_limit(agent.config.max_steps)


async def emit_step_limit_exceeded(agent: ReactAgent) -> None:
    """Emit the framework-standard max-steps error block."""
    logger.warning(
        "Max steps exceeded",
        extra={
            "max_steps": resolve_step_limit(agent.config.max_steps),
            "invocation_id": agent._current_invocation.id,
        },
    )
    await agent.ctx.emit(BlockEvent(
        kind=BlockKind.ERROR,
        op=BlockOp.APPLY,
        data={"message": f"Max steps ({resolve_step_limit(agent.config.max_steps)}) exceeded"},
    ))


def build_tool_call_fingerprint(tool_name: str, arguments: dict[str, Any] | None) -> str:
    """Build a stable fingerprint for duplicate tool-call detection."""
    normalized_name = str(tool_name or "").strip().lower()
    normalized_args = json.dumps(arguments or {}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return f"{normalized_name}::{normalized_args}"


def build_tool_invocation_fingerprint(invocation: ToolInvocation) -> str:
    """Build a stable fingerprint from a ToolInvocation."""
    return build_tool_call_fingerprint(invocation.tool_name, invocation.args)


def build_duplicate_tool_call_message(
    tool_name: str,
    arguments: dict[str, Any] | None,
    *,
    max_consecutive_tool_calls: int = DEFAULT_MAX_CONSECUTIVE_TOOL_CALLS,
) -> str:
    """Build a human-readable duplicate-call message for the model and UI."""
    serialized_args = json.dumps(arguments or {}, ensure_ascii=False, sort_keys=True)
    if len(serialized_args) > 240:
        serialized_args = f"{serialized_args[:237]}..."
    return (
        "Repeated tool call blocked: "
        f"{tool_name or 'tool'} with arguments {serialized_args} "
        f"was requested {max_consecutive_tool_calls} consecutive times in this invocation."
    )


def build_duplicate_tool_message(invocation: ToolInvocation) -> str:
    """Backward-compatible wrapper for duplicate-call message generation."""
    return build_duplicate_tool_call_message(
        invocation.tool_name,
        invocation.args,
        max_consecutive_tool_calls=DEFAULT_MAX_CONSECUTIVE_TOOL_CALLS,
    )


def partition_repeated_tool_invocations(
    agent: ReactAgent,
    invocations: list[ToolInvocation],
) -> tuple[list[ToolInvocation], list[tuple[ToolInvocation, str]]]:
    """Split new tool invocations into executable and repeated groups."""
    state = dict(getattr(agent, "_tool_call_repeat_state", {}) or {})
    last_fingerprint = str(state.get("fingerprint") or "") or None
    consecutive_count = int(state.get("count") or 0)
    max_consecutive_tool_calls = resolve_max_consecutive_tool_calls(
        getattr(agent.config, "max_consecutive_tool_calls", None)
    )
    executable: list[ToolInvocation] = []
    duplicates: list[tuple[ToolInvocation, str]] = []

    for invocation in invocations:
        fingerprint = build_tool_invocation_fingerprint(invocation)
        invocation.metadata["fingerprint"] = fingerprint
        consecutive_count = consecutive_count + 1 if fingerprint == last_fingerprint else 1
        invocation.metadata["consecutive_tool_call_count"] = consecutive_count
        last_fingerprint = fingerprint
        if consecutive_count >= max_consecutive_tool_calls:
            duplicates.append(
                (
                    invocation,
                    build_duplicate_tool_call_message(
                        invocation.tool_name,
                        invocation.args,
                        max_consecutive_tool_calls=max_consecutive_tool_calls,
                    ),
                )
            )
            continue
        executable.append(invocation)
    agent._tool_call_repeat_state = {
        "fingerprint": last_fingerprint,
        "count": consecutive_count,
    }

    return executable, duplicates


def partition_duplicate_tool_invocations(
    agent: ReactAgent,
    invocations: list[ToolInvocation],
) -> tuple[list[ToolInvocation], list[tuple[ToolInvocation, str]]]:
    """Backward-compatible alias for repeated-call partitioning."""
    return partition_repeated_tool_invocations(agent, invocations)


def record_tool_invocation_attempt(
    agent: ReactAgent,
    invocation: ToolInvocation,
    result: ToolResult,
) -> None:
    """Compatibility no-op: consecutive repeat state is tracked before execution."""
    _ = (agent, invocation, result)


def record_successful_tool_invocation(
    agent: ReactAgent,
    invocation: ToolInvocation,
    result: ToolResult,
) -> None:
    """Backward-compatible alias retained for older call sites."""
    record_tool_invocation_attempt(agent, invocation, result)
