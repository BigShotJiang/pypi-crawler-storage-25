# Youtube Autonomous TTS Kokoro Onnx Module

This project is to include the TTS functionality using the official `kokoro-onnx` project (https://github.com/thewh1teagle/kokoro-onnx) which is apparently supporting more languages than the original project.

The models and voices needed are downloaded automatically by the `kokoro-onnx` dependency from Hugginface. But here are the links just in case you need to download them manually.

### Models and voices
| Name             	| Description         	| Link                                                                              	|
|------------------	|---------------------	|-----------------------------------------------------------------------------------	|
| kokoro-v1.0.onnx 	| Model based on Onnx 	| https://github.com/nazdridoy/kokoro-tts/releases/download/v1.0.0/kokoro-v1.0.onnx 	|
| voices-v1.0.bin  	| Voices              	| https://github.com/nazdridoy/kokoro-tts/releases/download/v1.0.0/voices-v1.0.bin  	|

### Supported languages
- `American English`
- `British English`
- `Spanish`
- `French`
- `Italian`
- `Japanese`
- `Chinese`
- `Hindi`
- `Portuguese`

### Supported voices
The voices are specifically created for a language and have a gender, and their name is based on this premise, but can be used in any other different language. Two valid voices are `jf_tebukuro` and `im_nicola`.

The first letter of the voice is the language (`j` for `Japanese` and `i` for `Italian`), and the second is for the gender (`f` is `female` and `m` is `male`). The rest is just the real name of that voice.

To check all the voices available, check the `yta_tts_kokoro_voices` dependency in https://github.com/Implosiv3/yta-tts-kokoro-voices.


### Some results
Here you have one example using the Spanish language: https://www.dailymotion.com/video/xa87qpy