from yta_tts_kokoro_voices.utils import is_voice_valid

import numpy as np


def get_voice_blended(
    kokoro: 'Kokoro',
    voices_with_weights: dict
):
    """
    The `voice_with_weights` must be a dict including
    the voice as a key and the percentage as its value.

    The weights will be adjusted to sum a 100% in case
    they are not well balanced.

    ```
    voices_with_weights = {
        'af_nicole': 80,
        'am_michael': 20
    }
    ```
    """
    styles = []
    weights = []

    for voice_name, weight in voices_with_weights.items():
        validate_voice(voice = voice_name)
        styles.append(kokoro.get_voice_style(voice_name))
        weights.append(weight)

    weights = np.array(weights, dtype = float)
    weights /= weights.sum()

    voice_blended = np.zeros_like(styles[0])
    for style, w in zip(styles, weights):
        voice_blended += style * w

    return voice_blended

def validate_voice(
    voice: str
):
    """
    Check if the `voice` provided is supported or raise
    an Exception if not.
    """
    if not is_voice_valid(voice):
        raise Exception(f'The voice "{voice}" provided is not supported.')