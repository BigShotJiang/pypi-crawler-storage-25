"""
The code to use the TTS Kokoro.
"""
from yta_tts_kokoro_onnx.utils import validate_voice
from yta_tts_kokoro_voices import SPANISH, AMERICAN_ENGLISH, BRITISH_ENGLISH, FRENCH, ITALIAN, JAPANESE, CHINESE, HINDI, PORTUGUESE
from kokoro_onnx import Kokoro
from misaki.espeak import EspeakG2P

import numpy as np
import wave


# TODO: Currently we do nothing with this...
REQUIRED_FILES = {
    # TODO: These were for the 'onnx' version, but now is not
    'model': {
        # TODO: Include in a 'safetensors' folder (?)
        'path': 'kokoro-v1.0.onnx',
        'url': 'https://github.com/nazdridoy/kokoro-tts/releases/download/v1.0.0/kokoro-v1.0.onnx'
    },
    'voices': {
        # TODO: Include in a 'safetensors' folder (?)
        'path': 'voices-v1.0.bin',
        'url': 'https://github.com/nazdridoy/kokoro-tts/releases/download/v1.0.0/voices-v1.0.bin'
    }
}
        
class KokoroTTS:
    """
    Kokoro is a lightweighted TTS module, useful while
    needing not a lot of resources to load it, and is
    able to blend different voices in one audio output
    generation.

    TODO: Write here
    """

    # TODO: Apparently 'kokoro-onnx' is lighter as it
    # doesn't depend on pytorch, and also is supporting
    # the Spanish language, but 'kokoro' is the original
    # one

    def __init__(
        self
    ):
        # TODO: Make this more intelligent (?)
        self._kokoro = Kokoro(
            # TODO: I should force the download with the 'huggingface-hub'
            # dependency but by now I have it manually downloaded
            model_path = 'C:/Users/dania/.cache/huggingface/hub/models--hexgrad--Kokoro-82M/snapshots/f3ff3571791e39611d31c381e3a41a3af07b4987/kokoro-v1.0.onnx',
            voices_path = 'C:/Users/dania/.cache/huggingface/hub/models--hexgrad--Kokoro-82M/snapshots/f3ff3571791e39611d31c381e3a41a3af07b4987/voices-v1.0.bin'
        )
        """
        *For internal use only*
        
        The real instance of the Kokoro class.

        TODO: The KPipeline should be one specific for each
        language, so we should have some cache.
        """
        pass

    def narrate(
        self,
        text: str,
        language: str = 'a',
        voice: str = 'af_heart',
        speed: float = 1.0,
        output_filename: str = 'output.wav'
        # TODO: Implement 'None' to return stream or bytes
        # output_filename: Union[str, None] = None
    ) -> str:
        """
        Narrate the `text` provided in the `language` given
        and with the `voice` also provided. The `speed`
        parameter will determine how fast the speech is, when
        `0.8` means slower and `1.2` faster than normal, which
        is `1.0`. 
        """
        # TODO: Use 'yta_validation' instead
        if isinstance(voice, str):
            validate_voice(voice = voice)

        # The languages accepted are here:
        # https://github.com/espeak-ng/espeak-ng/blob/master/docs/languages.md
        language = {
            SPANISH.code: 'es',
            AMERICAN_ENGLISH.code: 'en-us',
            BRITISH_ENGLISH.code: 'en-gb',
            FRENCH.code: 'fr-fr',
            ITALIAN.code: 'it',
            JAPANESE.code: 'ja',
            CHINESE.code: 'cmn',
            HINDI.code: 'hi',
            PORTUGUESE.code: 'pt'
        }.get(language, None)

        if language is None:
            raise Exception(f'The language "{language}" provided is not supported.')

        # Phonemes creator based on the `language` requested
        g2p = EspeakG2P(language = language)
        phonemes, _ = g2p(text)

        """
        We could be asking for the voice only and inferencing
        the language from its voice name, but we could want
        to have a Spanish narration with an american accent,
        and this is possible by choosing the `language='es'`
        but with an american voice.
        """
        audio_samples, sample_rate = self._kokoro.create(
            text = phonemes,
            voice = voice,
            speed = speed,
            # This is always English for phonemes
            lang = 'en-us',
            is_phonemes = True
        )

        # Transform to int16 PCM
        audio_samples = np.clip(audio_samples, -1.0, 1.0)
        audio_samples_int16 = (audio_samples * 32767).astype(np.int16)

        # TODO: How to return it as a stream instead of a file (?)
        with wave.open(output_filename, 'wb') as wf:
            wf.setnchannels(1)
            # 16-bit
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(audio_samples_int16.tobytes())

        return output_filename