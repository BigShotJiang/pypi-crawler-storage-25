"""Inflate compact syllable tuples back into thaiphon model types."""

from __future__ import annotations

from thaiphon.model.enums import EffectiveClass, SyllableType, Tone, VowelLength
from thaiphon.model.phoneme import Cluster, Phoneme
from thaiphon.model.syllable import Syllable
from thaiphon.model.word import PhonologicalWord


def _inflate_onset(t: tuple) -> Phoneme | Cluster | None:
    if t[0] is None:
        return None
    if t[0] == "P":
        return Phoneme(symbol=t[1], is_aspirated=t[2], is_sonorant=t[3])
    if t[0] == "C":
        first = Phoneme(symbol=t[1], is_aspirated=t[2], is_sonorant=t[3])
        second = Phoneme(symbol=t[4], is_aspirated=t[5], is_sonorant=t[6])
        return Cluster(first=first, second=second)
    raise ValueError(f"unknown onset tag: {t[0]!r}")


def inflate_syllable(t: tuple) -> Syllable:
    onset_t, vowel_t, vlen_v, coda_t, tone_v, eclass_v, stype_v = t
    onset = _inflate_onset(onset_t)
    vowel = Phoneme(symbol=vowel_t[0], is_aspirated=vowel_t[1], is_sonorant=vowel_t[2])
    coda = None if coda_t is None else Phoneme(symbol=coda_t[0], is_sonorant=coda_t[1])
    return Syllable(
        onset=onset,
        vowel=vowel,
        vowel_length=VowelLength(vlen_v),
        coda=coda,
        tone=Tone(tone_v),
        effective_class=EffectiveClass(eclass_v),
        syllable_type=SyllableType(stype_v),
    )


def inflate_word(tuples: tuple[tuple, ...]) -> PhonologicalWord:
    sylls = tuple(inflate_syllable(t) for t in tuples)
    return PhonologicalWord(syllables=sylls, confidence=1.0, source="lexicon")
