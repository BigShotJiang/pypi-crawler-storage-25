"""Bundled Thai lexicon for thaiphon.

Data derived from the VOLUBILIS Mundo Multilingual Thai Dictionary by Belisan,
licensed under CC BY-SA 4.0. See NOTICE and LICENSE.
"""

from __future__ import annotations

import functools
from collections.abc import Mapping
from types import MappingProxyType

from thaiphon.model.word import PhonologicalWord

from ._inflate import inflate_word
from ._lexicon import _ENTRIES

__version__ = "0.1.0"


@functools.cache
def _build() -> Mapping[str, PhonologicalWord]:
    return MappingProxyType({k: inflate_word(v) for k, v in _ENTRIES.items()})


class _LazyEntries(Mapping[str, PhonologicalWord]):
    def __getitem__(self, key: str) -> PhonologicalWord:
        return _build()[key]

    def __iter__(self):  # type: ignore[no-untyped-def]
        return iter(_build())

    def __len__(self) -> int:
        return len(_build())

    def __contains__(self, key: object) -> bool:
        return key in _build()

    def get(self, key: str, default=None):  # type: ignore[override]
        return _build().get(key, default)


ENTRIES: Mapping[str, PhonologicalWord] = _LazyEntries()
