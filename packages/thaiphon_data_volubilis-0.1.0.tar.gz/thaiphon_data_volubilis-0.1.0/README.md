# thaiphon-data-volubilis

An exact-match Thai pronunciation lexicon for the [thaiphon](https://pypi.org/project/thaiphon/) phonological engine, derived from the VOLUBILIS *Mundo* Multilingual Thai Dictionary & Database by Belisan. When installed alongside `thaiphon`, the analysis pipeline transparently short-circuits on entries present in this data, yielding exact-form pronunciations without running the rule-based derivation.

## Install

```bash
pip install thaiphon-data-volubilis
```

## Attribution

Source data: VOLUBILIS Mundo Multilingual Thai Dictionary & Database by Belisan — <https://belisan-volubilis.blogspot.com/>.

## License

The data is distributed under [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/), matching the upstream source license. Derivative works of this data must also be licensed under CC BY-SA 4.0 or a compatible license. See `LICENSE` and `NOTICE` for details.
