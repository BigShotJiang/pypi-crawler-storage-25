# Changelog

All notable changes to ExodusDB CLI will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/), and this project adheres to [Semantic Versioning](https://semver.org/).

## v0.1.0 (2026-03-28) -- Initial Release

### Features
- Bidirectional Oracle <-> PostgreSQL migration
- 35 rule modules (21 O2P + 14 P2O) with 90%+ deterministic coverage
- AI-assisted conversion for remaining 10% (BYOK -- your API keys)
- 4-stage verification with confidence scoring
- CLI: scan, convert, verify, report commands
- Web playground with Monaco Editor
- 870+ golden test pairs, 1,643 automated tests
- Free tier: unlimited rules-only CLI, offline, no signup
- BSL 1.1 license (source-available)

### Supported Conversions
- Data types (23 Oracle types, 15 PostgreSQL types)
- SQL syntax (NVL, DECODE, CONNECT BY, (+) joins, ROWNUM, etc.)
- PL/SQL <-> PL/pgSQL (triggers, procedures, packages, exceptions)
- DDL (CREATE TABLE, ALTER TABLE, sequences, indexes, partitioning)
- 7 static analysis rules for silent bug detection
