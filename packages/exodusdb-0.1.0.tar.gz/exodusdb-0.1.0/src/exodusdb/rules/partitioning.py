# src/exodusdb/rules/partitioning.py
"""Partitioning rules: Oracle partition syntax -> PostgreSQL PARTITION BY."""

from __future__ import annotations

import re

from exodusdb.rules.base import Rule, RuleCategory


class RangePartitionRule(Rule):
    """Oracle range partition -> PG PARTITION BY RANGE.

    Oracle:
        CREATE TABLE t (...)
        PARTITION BY RANGE (col)
        (PARTITION p1 VALUES LESS THAN (100),
         PARTITION p2 VALUES LESS THAN (MAXVALUE));

    PG:
        CREATE TABLE t (...) PARTITION BY RANGE (col);
        CREATE TABLE p1 PARTITION OF t FOR VALUES FROM (MINVALUE) TO (100);
        CREATE TABLE p2 PARTITION OF t FOR VALUES FROM (100) TO (MAXVALUE);
    """

    name = "range_partition"
    category = RuleCategory.PARTITIONING
    priority = 10
    description = "Convert Oracle RANGE partitions to PG PARTITION BY RANGE"

    _PATTERN = re.compile(
        r"(?P<create>CREATE\s+TABLE\s+(?P<table>\w+)\s*\((?:[^()]*|\([^()]*\))*\))\s*"
        r"PARTITION\s+BY\s+RANGE\s*\((?P<col>[^)]+)\)\s*"
        r"\((?P<parts>(?:[^()]*|\([^()]*\))*)\)\s*;?",
        re.IGNORECASE | re.DOTALL,
    )

    _PART_PATTERN = re.compile(
        r"PARTITION\s+(?P<pname>\w+)\s+VALUES\s+LESS\s+THAN\s*\((?P<val>[^)]+)\)",
        re.IGNORECASE,
    )

    def matches(self, sql: str) -> bool:
        return bool(self._PATTERN.search(sql))

    def apply(self, sql: str) -> str:
        m = self._PATTERN.search(sql)
        if not m:
            return sql

        create = m.group("create")
        table = m.group("table")
        col = m.group("col").strip()
        parts_str = m.group("parts")

        lines = [f"{create} PARTITION BY RANGE ({col});"]

        partitions = list(self._PART_PATTERN.finditer(parts_str))
        prev_val = "MINVALUE"

        for part in partitions:
            pname = part.group("pname")
            val = part.group("val").strip()
            upper = val if val.upper() != "MAXVALUE" else "MAXVALUE"
            lines.append(
                f"CREATE TABLE {pname} PARTITION OF {table} "
                f"FOR VALUES FROM ({prev_val}) TO ({upper});"
            )
            if val.upper() != "MAXVALUE":
                prev_val = val

        return "\n".join(lines)


class ListPartitionRule(Rule):
    """Oracle list partition -> PG PARTITION BY LIST.

    Oracle:
        PARTITION BY LIST (region)
        (PARTITION p_east VALUES ('NY','NJ'),
         PARTITION p_west VALUES ('CA','WA'));

    PG:
        CREATE TABLE t (...) PARTITION BY LIST (region);
        CREATE TABLE p_east PARTITION OF t FOR VALUES IN ('NY','NJ');
    """

    name = "list_partition"
    category = RuleCategory.PARTITIONING
    priority = 20
    description = "Convert Oracle LIST partitions to PG PARTITION BY LIST"

    _PATTERN = re.compile(
        r"(?P<create>CREATE\s+TABLE\s+(?P<table>\w+)\s*\((?:[^()]*|\([^()]*\))*\))\s*"
        r"PARTITION\s+BY\s+LIST\s*\((?P<col>[^)]+)\)\s*"
        r"\((?P<parts>.*)\)\s*;?",
        re.IGNORECASE | re.DOTALL,
    )

    _PART_PATTERN = re.compile(
        r"PARTITION\s+(?P<pname>\w+)\s+VALUES\s*\((?P<vals>[^)]+)\)",
        re.IGNORECASE,
    )

    def matches(self, sql: str) -> bool:
        return bool(self._PATTERN.search(sql))

    def apply(self, sql: str) -> str:
        m = self._PATTERN.search(sql)
        if not m:
            return sql

        create = m.group("create")
        table = m.group("table")
        col = m.group("col").strip()
        parts_str = m.group("parts")

        lines = [f"{create} PARTITION BY LIST ({col});"]

        for part in self._PART_PATTERN.finditer(parts_str):
            pname = part.group("pname")
            vals = part.group("vals").strip()
            lines.append(f"CREATE TABLE {pname} PARTITION OF {table} FOR VALUES IN ({vals});")

        return "\n".join(lines)


class HashPartitionRule(Rule):
    """Oracle hash partition -> PG PARTITION BY HASH.

    Oracle:
        PARTITION BY HASH (id) PARTITIONS 4;

    PG:
        CREATE TABLE t (...) PARTITION BY HASH (id);
        CREATE TABLE t_p0 PARTITION OF t FOR VALUES WITH (MODULUS 4, REMAINDER 0);
        ...
    """

    name = "hash_partition"
    category = RuleCategory.PARTITIONING
    priority = 30
    description = "Convert Oracle HASH partitions to PG PARTITION BY HASH"

    _PATTERN = re.compile(
        r"(?P<create>CREATE\s+TABLE\s+(?P<table>\w+)\s*\((?:[^()]*|\([^()]*\))*\))\s*"
        r"PARTITION\s+BY\s+HASH\s*\((?P<col>[^)]+)\)\s*"
        r"PARTITIONS\s+(?P<num>\d+)\s*;?",
        re.IGNORECASE | re.DOTALL,
    )

    def matches(self, sql: str) -> bool:
        return bool(self._PATTERN.search(sql))

    def apply(self, sql: str) -> str:
        m = self._PATTERN.search(sql)
        if not m:
            return sql

        create = m.group("create")
        table = m.group("table")
        col = m.group("col").strip()
        num = int(m.group("num"))

        lines = [f"{create} PARTITION BY HASH ({col});"]

        for i in range(num):
            lines.append(
                f"CREATE TABLE {table}_p{i} PARTITION OF {table} "
                f"FOR VALUES WITH (MODULUS {num}, REMAINDER {i});"
            )

        return "\n".join(lines)


class SubpartitionRule(Rule):
    """Subpartition detection -> forward to LLM.

    Oracle subpartitions (composite partitioning) are too complex for
    deterministic rules.
    """

    name = "subpartition"
    category = RuleCategory.PARTITIONING
    priority = 40
    description = "Detect subpartitions and forward to LLM"

    _PATTERN = re.compile(
        r"\bSUBPARTITION\s+BY\b",
        re.IGNORECASE,
    )

    def matches(self, sql: str) -> bool:
        return bool(self._PATTERN.search(sql))

    def apply(self, sql: str) -> str:
        return (
            "-- FORWARD TO LLM: Subpartitioning (composite partitioning) detected.\n"
            "-- This requires LLM conversion due to complexity.\n"
            f"-- Original:\n{sql}"
        )
