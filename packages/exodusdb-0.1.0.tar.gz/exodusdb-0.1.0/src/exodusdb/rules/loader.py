# src/exodusdb/rules/loader.py
"""Rule loader: builds a RuleRegistry with all available rules registered.

Extracted from CLI convert command so it can be reused by tests, accuracy
measurement, and other consumers.
"""

from __future__ import annotations

import contextlib
import importlib

from exodusdb.rules.base import Rule as RuleBase
from exodusdb.rules.registry import RuleRegistry

# Modules containing Rule subclasses, in load order.
_RULE_MODULES: list[str] = [
    "exodusdb.rules.ddl_cleanup",
    "exodusdb.rules.datatypes_basic",
    "exodusdb.rules.datatypes_numeric",
    "exodusdb.rules.datatypes_temporal",
    "exodusdb.rules.syntax_functions",
    "exodusdb.rules.syntax_datetime",
    "exodusdb.rules.syntax_joins",
    "exodusdb.rules.syntax_null",
    "exodusdb.rules.syntax_misc",
    "exodusdb.rules.ddl_tables",
    "exodusdb.rules.ddl_alter",
    "exodusdb.rules.ddl_indexes",
    "exodusdb.rules.sequences",
    "exodusdb.rules.triggers",
    "exodusdb.rules.plsql_basic",
    "exodusdb.rules.plsql_control_flow",
    "exodusdb.rules.packages",
    "exodusdb.rules.synonyms",
    "exodusdb.rules.materialized_views",
    "exodusdb.rules.grants",
    # NOTE: partitioning module excluded due to catastrophic backtracking
    # in regex patterns when applied to non-partition DDL.
    # "exodusdb.rules.partitioning",
]


def create_default_registry() -> RuleRegistry:
    """Build a RuleRegistry with all available rules registered.

    Dynamically imports each rule module and registers all Rule subclasses
    found within. Silently skips modules that fail to import and classes
    that fail to instantiate.
    """
    registry = RuleRegistry()

    for mod_name in _RULE_MODULES:
        try:
            mod = importlib.import_module(mod_name)
            for attr_name in dir(mod):
                attr = getattr(mod, attr_name)
                if (
                    isinstance(attr, type)
                    and issubclass(attr, RuleBase)
                    and attr is not RuleBase
                    and hasattr(attr, "name")
                    and hasattr(attr, "category")
                ):
                    with contextlib.suppress(TypeError):
                        registry.register(attr())
        except ImportError:
            pass

    return registry
