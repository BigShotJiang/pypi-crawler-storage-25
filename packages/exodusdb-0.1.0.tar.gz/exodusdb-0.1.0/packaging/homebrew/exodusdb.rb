class Exodusdb < Formula
  include Language::Python::Virtualenv

  desc "AI-powered Oracle-to-PostgreSQL migration tool"
  homepage "https://exodusdb.com"
  url "https://files.pythonhosted.org/packages/source/e/exodusdb/exodusdb-0.1.0.tar.gz"
  sha256 "PLACEHOLDER"
  license "Apache-2.0"

  depends_on "python@3.12"

  def install
    virtualenv_install_with_resources
  end

  test do
    assert_match "ExodusDB CLI v", shell_output("#{bin}/exodus --version")
  end
end
