"""LLM tool 정의 + 실행 함수.

동일 구현을 MCP 서버와 Claude API Tool Use 양쪽에서 재사용한다.
각 함수는 JSON-serializable dict를 반환.
"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

from . import load

# -------- JSON schemas (Claude API tool use와 MCP 공용) --------

TOOL_DEFINITIONS: list[dict[str, Any]] = [
    {
        "name": "inspect_document",
        "description": (
            "문서(.docx/.pptx/.hwpx)의 구조를 분석한다. "
            "placeholders({{key}} 태그 목록)와 tables(각 표의 행/열/미리보기)를 반환한다. "
            "LLM이 어떤 필드를 채우거나 수정할지 판단할 때 먼저 호출해야 한다. "
            "\n"
            "**PPTX 특화**: 반환 JSON 에 `shape_summary` (total_shapes / empty_shapes / "
            "hint) 포함. `hint` 가 있으면 그 지시 를 따라 get_shapes + set_shape_text "
            "를 호출해야 보고서가 완성됨. 표만 채우면 대부분의 보고서가 비어있는 상태로 "
            "남음."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "문서 절대경로",
                },
                "min_rows": {
                    "type": "integer",
                    "description": "표 필터: 최소 행 수 (기본 1)",
                    "default": 1,
                },
                "min_cols": {
                    "type": "integer",
                    "description": "표 필터: 최소 열 수 (기본 1)",
                    "default": 1,
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "render_template",
        "description": (
            "문서의 {{key}} placeholder를 context의 값으로 치환해 새 파일로 저장한다. "
            "DOCX는 docxtpl(Jinja2 loop/if 지원), PPTX/HWPX는 단순 {{key}} 치환."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "템플릿 파일 경로"},
                "context": {
                    "type": "object",
                    "description": "{{key}}에 주입할 값 dict",
                    "additionalProperties": True,
                },
                "output_path": {
                    "type": "string",
                    "description": "결과 저장 경로 (생략 시 원본 옆에 _rendered 붙여 저장)",
                },
            },
            "required": ["path", "context"],
        },
    },
    {
        "name": "get_cell",
        "description": (
            "셀 하나의 전체 내용과 병합/중첩 메타를 반환한다. "
            "inspect_document의 preview는 max_cell_len으로 잘리지만 get_cell은 전체 텍스트를 돌려준다. "
            "병합 영역 내부의 non-anchor 좌표로 호출해도 에러 없이 anchor 셀의 내용을 반환한다 "
            "(is_anchor=false, anchor/span 필드로 구조 확인 가능). "
            "nested_table_indices: 셀 안에 중첩 테이블이 있을 경우 그 flat index 목록 (DOCX/HWPX)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "table_index": {"type": "integer"},
                "row": {"type": "integer"},
                "col": {"type": "integer"},
            },
            "required": ["path", "table_index", "row", "col"],
        },
    },
    {
        "name": "set_cell",
        "description": (
            "특정 표의 셀 값을 교체한다. table_index는 inspect_document의 tables 배열 인덱스. "
            "3개 포맷(DOCX/PPTX/HWPX) 모두 병합 셀을 인지한다: inspect_document의 "
            "tables[i].merges에 나온 anchor 좌표로만 수정 가능. 병합 영역 내부의 non-anchor "
            "좌표로 호출하면 MergedCellWriteError(ValueError 호환)가 발생하며, preview의 해당 "
            "슬롯은 null로 표시된다."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "table_index": {"type": "integer"},
                "row": {"type": "integer"},
                "col": {"type": "integer"},
                "value": {"type": "string"},
                "output_path": {
                    "type": "string",
                    "description": "생략 시 원본 덮어쓰기",
                },
                "allow_merge_redirect": {
                    "type": "boolean",
                    "description": (
                        "true면 병합 영역 non-anchor 좌표 호출 시 앵커로 자동 리디렉트 + 경고 "
                        "(권장 X, 구조 잘못 이해한 호출을 숨김)."
                    ),
                    "default": False,
                },
            },
            "required": ["path", "table_index", "row", "col", "value"],
        },
    },
    {
        "name": "append_to_cell",
        "description": (
            "기존 셀 텍스트 뒤에 separator + value를 덧붙인다. "
            "한국 관공서 폼처럼 '성  명' 같은 라벨 셀 뒤에 값을 붙이는 용도로 유용. "
            "빈 셀이면 separator 없이 value만 기록. set_cell과 동일하게 병합 anchor만 수정 가능."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "table_index": {"type": "integer"},
                "row": {"type": "integer"},
                "col": {"type": "integer"},
                "value": {"type": "string", "description": "추가할 값"},
                "separator": {
                    "type": "string",
                    "description": "기존 텍스트와 값 사이 구분자 (기본 '  ')",
                    "default": "  ",
                },
                "output_path": {
                    "type": "string",
                    "description": "생략 시 원본 덮어쓰기",
                },
                "allow_merge_redirect": {
                    "type": "boolean",
                    "default": False,
                },
            },
            "required": ["path", "table_index", "row", "col", "value"],
        },
    },
    {
        "name": "append_row",
        "description": (
            "표 끝에 새 행을 추가한다. DOCX / PPTX / HWPX 모두 지원 (v0.5+). "
            "마지막 행을 deepcopy 해 스타일/서식 상속. "
            "제약: 마지막 행이 위 행의 rowSpan 영역에 걸쳐있으면 거부."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "table_index": {"type": "integer"},
                "values": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "새 행의 각 셀 값. 열 수보다 적으면 나머지는 공백.",
                },
                "output_path": {"type": "string"},
            },
            "required": ["path", "table_index", "values"],
        },
    },
    {
        "name": "get_shapes",
        "description": (
            "**PPTX 전용**. 표 외 shape (textbox / placeholder / 도형 내 텍스트) 목록을 "
            "반환한다. PPTX 는 17 슬라이드에 걸쳐 표 4 개 외에 수십 개의 textbox / "
            "placeholder 로 내용이 채워져 있으므로, 전체 편집에는 get_tables 만으로 "
            "부족하다. "
            "반환: shapes[] — 각 항목에 slide_index (1-based), shape_id (슬라이드 내 고유 "
            "숫자), name, kind (placeholder/text_box), text/text_preview, placeholder_type. "
            "DOCX/HWPX 는 빈 리스트 반환 (표와 paragraph 중심이라 shape 편집 개념 약함)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "slide_index": {
                    "type": "integer",
                    "description": "1-based. 생략 시 전체 슬라이드.",
                },
                "min_text_len": {
                    "type": "integer",
                    "default": 1,
                    "description": "이 값 미만 길이의 텍스트 shape 는 제외.",
                },
            },
            "required": ["path"],
        },
    },
    {
        "name": "set_shape_text",
        "description": (
            "**PPTX 전용**. shape (textbox/placeholder) 의 텍스트를 교체한다. run-level "
            "포맷 (폰트/크기/색상) 은 보존. get_shapes 로 slide_index + shape_id 파악 후 "
            "호출. 표 셀은 이 도구 아닌 set_cell 을 쓸 것."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "slide_index": {"type": "integer", "description": "1-based"},
                "shape_id": {"type": "integer"},
                "text": {"type": "string"},
                "output_path": {"type": "string"},
            },
            "required": ["path", "slide_index", "shape_id", "text"],
        },
    },
    {
        "name": "fill_form",
        "description": (
            "라벨 이름으로 값 셀을 자동 탐지해 **일괄 채우기**. 좌표 (table_index, row, col) "
            "계산 없이 '접수번호', '성명' 같은 라벨 key-value dict 로 양식 채움. "
            "\n"
            "**direction 선택 기준 (중요)**: "
            "(a) `auto` (기본, 보수적): 기존 값이 있는 셀은 다른 라벨로 간주하고 skip → 같은 "
            "셀에 append_to_cell. **값 셀이 비어있는 양식**에 적합 (HWPX 공공 서식 등). "
            "(b) `right` / `below` (명시): 라벨 오른쪽/아래 셀을 **덮어쓰기**. **기존에 "
            "예시값이 채워져 있는 양식**(PPTX 템플릿 등) 에는 반드시 direction='right' 명시. "
            "\n"
            "**Dot-path 섹션 지정**: 같은 라벨이 여러 섹션에 있어 ambiguous 로 반환되면 "
            "`{'피해자.금액': '...', '지급정지요청계좌.금액': '...'}` 처럼 섹션힌트.라벨 "
            "형태로 재호출. ambiguous 반환의 hint 필드에 예시 제공됨. "
            "\n"
            "**output_path**: 생략 시 **원본 파일에 덮어쓰기** (대부분의 경우 생략 권장). "
            "다른 위치에 저장이 필요할 때만 지정. "
            "\n"
            "**팁**: 한 양식의 관련 라벨을 **한 번에 dict 로** 넘기면 라벨끼리 서로 보호되어 "
            "인접 라벨 오염이 방지됩니다. "
            "\n"
            "반환: `{filled: [...], not_found: [...], ambiguous: [...]}`. "
            "ambiguous candidates 각각에 `context` 필드 포함 (어느 섹션인지 확인)."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "data": {
                    "type": "object",
                    "description": "라벨: 값 dict (예: {'접수번호': '2026-0001', '성명': '홍길동'})",
                    "additionalProperties": {"type": "string"},
                },
                "direction": {
                    "type": "string",
                    "enum": ["auto", "right", "below", "same"],
                    "default": "auto",
                    "description": "값 셀 탐색 방향. auto 권장.",
                },
                "strict": {
                    "type": "boolean",
                    "default": False,
                    "description": "True 면 라벨 매칭 실패 시 에러. False 면 not_found 에 기록.",
                },
                "output_path": {"type": "string"},
            },
            "required": ["path", "data"],
        },
    },
]


# -------- 실행 함수 --------

def _resolve_output(path: str, output_path: str | None, suffix: str = "_out") -> Path:
    if output_path:
        return Path(output_path)
    p = Path(path)
    return p.with_name(f"{p.stem}{suffix}{p.suffix}")


def inspect_document(path: str, min_rows: int = 1, min_cols: int = 1) -> dict[str, Any]:
    doc = load(path)
    try:
        schema = doc.get_schema()
        # min_rows/min_cols 필터 재적용
        filtered = [t for t in doc.get_tables(min_rows=min_rows, min_cols=min_cols)]
        result = schema.to_dict()

        # PPTX: shape 요약을 추가해 LLM 에게 set_shape_text 필요성을 신호.
        # (표 4 개만 보고 set_cell 만 호출하는 실패 패턴 관찰됨 — 실제론 수십 개
        # textbox 가 비어있어 보고서 완성이 안 됨.)
        if schema.format == "pptx":
            try:
                all_shapes = doc.get_shapes(min_text_len=0)
                total = len(all_shapes)
                empty = sum(1 for s in all_shapes if not s.has_text)
                summary: dict[str, Any] = {
                    "total_shapes": total,
                    "empty_shapes": empty,
                    "filled_shapes": total - empty,
                }
                if total > 0 and empty / total > 0.5:
                    summary["hint"] = (
                        f"⚠ 이 PPTX 는 {total} 개 shape (textbox / placeholder / 도형 "
                        f"텍스트) 중 {empty} 개가 비어있는 '빈 양식' 상태입니다. "
                        f"표({len(filtered)}개) 만 set_cell 로 채우면 보고서의 대부분이 "
                        f"여전히 비어있습니다. get_shapes 로 전체 shape 목록을 가져와 "
                        f"set_shape_text 로 시나리오 내용에 맞게 각 shape 를 채워야 "
                        f"완성본이 됩니다."
                    )
                elif total > 0 and empty > 0:
                    summary["hint"] = (
                        f"{total} 개 shape 중 {empty} 개가 비어있음. 필요 시 "
                        f"get_shapes / set_shape_text 사용."
                    )
                result["shape_summary"] = summary
            except NotImplementedError:
                pass  # DOCX / HWPX 는 shape 개념 약함 — skip
        result["tables"] = [t.to_dict() for t in filtered]
        return result
    finally:
        doc.close()


def render_template(path: str, context: dict[str, Any],
                    output_path: str | None = None) -> dict[str, Any]:
    out = _resolve_output(path, output_path, "_rendered")
    shutil.copy2(path, out)

    doc = load(out)
    try:
        before = doc.get_placeholders()
        doc.render_template(context)
        doc.save()
    finally:
        doc.close()

    # 검증 재로드
    doc2 = load(out)
    try:
        after = doc2.get_placeholders()
    finally:
        doc2.close()

    return {
        "output_path": str(out),
        "placeholders_before": before,
        "placeholders_after": after,
        "rendered_count": len(before) - len(after),
    }


def get_cell(path: str, table_index: int, row: int, col: int) -> dict[str, Any]:
    doc = load(path)
    try:
        cell = doc.get_cell(table_index, row, col)
        return cell.to_dict()
    finally:
        doc.close()


def set_cell(path: str, table_index: int, row: int, col: int, value: str,
             output_path: str | None = None,
             allow_merge_redirect: bool = False) -> dict[str, Any]:
    target = Path(output_path) if output_path else Path(path)
    if output_path and Path(path) != target:
        shutil.copy2(path, target)

    doc = load(target)
    try:
        old = doc.set_cell(
            table_index, row, col, value,
            allow_merge_redirect=allow_merge_redirect,
        )
        doc.save()
    finally:
        doc.close()

    return {
        "output_path": str(target),
        "table_index": table_index,
        "row": row,
        "col": col,
        "previous_value": old,
        "new_value": value,
    }


def append_to_cell(path: str, table_index: int, row: int, col: int, value: str,
                   separator: str = "  ",
                   output_path: str | None = None,
                   allow_merge_redirect: bool = False) -> dict[str, Any]:
    target = Path(output_path) if output_path else Path(path)
    if output_path and Path(path) != target:
        shutil.copy2(path, target)

    doc = load(target)
    try:
        old = doc.append_to_cell(
            table_index, row, col, value,
            separator=separator,
            allow_merge_redirect=allow_merge_redirect,
        )
        doc.save()
    finally:
        doc.close()

    return {
        "output_path": str(target),
        "table_index": table_index,
        "row": row,
        "col": col,
        "previous_value": old,
        "appended_value": value,
        "separator": separator,
    }


def append_row(path: str, table_index: int, values: list[str],
               output_path: str | None = None) -> dict[str, Any]:
    target = Path(output_path) if output_path else Path(path)
    if output_path and Path(path) != target:
        shutil.copy2(path, target)

    doc = load(target)
    try:
        doc.append_row(table_index, values)
        doc.save()
        new_tables = doc.get_tables()
    finally:
        doc.close()

    target_schema = next((t for t in new_tables if t.index == table_index), None)
    return {
        "output_path": str(target),
        "table_index": table_index,
        "new_row_count": target_schema.rows if target_schema else None,
        "appended_values": values,
    }


def get_shapes(path: str, slide_index: int | None = None,
               min_text_len: int = 1) -> dict[str, Any]:
    doc = load(path)
    try:
        shapes = doc.get_shapes(slide_index=slide_index, min_text_len=min_text_len)
    finally:
        doc.close()
    return {
        "format": doc.format,
        "source": str(path),
        "shape_count": len(shapes),
        "shapes": [s.to_dict() for s in shapes],
    }


def set_shape_text(path: str, slide_index: int, shape_id: int, text: str,
                   output_path: str | None = None) -> dict[str, Any]:
    target = Path(output_path) if output_path else Path(path)
    if output_path and Path(path) != target:
        shutil.copy2(path, target)

    doc = load(target)
    try:
        old = doc.set_shape_text(slide_index, shape_id, text)
        doc.save()
    finally:
        doc.close()

    return {
        "output_path": str(target),
        "slide_index": slide_index,
        "shape_id": shape_id,
        "previous_text": old,
        "new_text": text,
    }


def fill_form(path: str, data: dict[str, str],
              direction: str = "auto", strict: bool = False,
              output_path: str | None = None) -> dict[str, Any]:
    target = Path(output_path) if output_path else Path(path)
    if output_path and Path(path) != target:
        shutil.copy2(path, target)

    doc = load(target)
    try:
        result = doc.fill_form(data, direction=direction, strict=strict)
        doc.save()
    finally:
        doc.close()

    result["output_path"] = str(target)
    return result


# -------- 이름으로 dispatch --------

TOOL_HANDLERS = {
    "inspect_document": inspect_document,
    "render_template": render_template,
    "get_cell": get_cell,
    "set_cell": set_cell,
    "append_to_cell": append_to_cell,
    "append_row": append_row,
    "fill_form": fill_form,
    "get_shapes": get_shapes,
    "set_shape_text": set_shape_text,
}


def call_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """이름으로 tool 실행. 예외도 dict로 직렬화."""
    handler = TOOL_HANDLERS.get(name)
    if handler is None:
        return {"error": f"unknown tool: {name}"}
    try:
        return handler(**arguments)
    except NotImplementedError as e:
        return {"error": "not_implemented", "message": str(e)}
    except (IndexError, ValueError, FileNotFoundError) as e:
        return {"error": type(e).__name__, "message": str(e)}
    except Exception as e:
        return {"error": "unexpected", "type": type(e).__name__, "message": str(e)}
