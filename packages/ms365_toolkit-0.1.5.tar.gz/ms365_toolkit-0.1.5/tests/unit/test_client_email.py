from __future__ import annotations

import hashlib
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any
from urllib.error import HTTPError

from ms365_toolkit.client.email import EmailClient
from ms365_toolkit.client.graph import GraphClient
from ms365_toolkit.config.loader import load_config, write_config_text

if TYPE_CHECKING:
    from pathlib import Path


def test_list_inbox_uses_focused_filter_then_falls_back(tmp_path: Path) -> None:
    calls: list[dict[str, Any]] = []
    responses = iter(
        [
            {"value": []},
            {"value": [_message_item("msg-1")]},
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append({"url": req.full_url})
        return _response(next(responses))

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.list_inbox(mailbox_filter="focused", top=5)

    assert len(messages) == 1
    assert "inferenceClassification+eq+'focused'" in calls[0]["url"]
    assert len(calls) == 2


def test_read_email_maps_graph_payload_to_email_message(tmp_path: Path) -> None:
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(_message_item("msg-1")),
        )
    )

    message = client.read_email("msg-1")

    assert message.id == "msg-1"
    assert message.sender == "sender@example.com"
    assert message.to == ("to@example.com",)
    assert message.body_content == "<untrusted-email-content>Hello world</untrusted-email-content>"
    assert message.received_at == datetime(2026, 3, 12, 15, 0, tzinfo=UTC)
    assert message.is_flagged is True
    assert message.attachments[0].name == "report.txt"
    assert message.attachments[0].sha256 == hashlib.sha256(b"i\xb7").hexdigest()


def test_download_attachments_fetches_bytes_and_skips_reference_attachments(tmp_path: Path) -> None:
    calls: list[str] = []
    responses = iter(
        [
            {
                "value": [
                    {
                        "id": "att-1",
                        "name": "report.txt",
                        "contentType": "text/plain",
                        "size": 10,
                        "@odata.type": "#microsoft.graph.fileAttachment",
                    },
                    {
                        "id": "att-2",
                        "name": "shared.docx",
                        "contentType": (
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                        ),
                        "size": 0,
                        "@odata.type": "#microsoft.graph.referenceAttachment",
                    },
                ]
            },
            b"hello",
        ]
    )

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        payload = next(responses)
        if isinstance(payload, bytes):
            return _bytes_response(payload)
        return _response(payload)

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    attachments = client.download_attachments("msg-1")

    assert [item.name for item in attachments] == ["report.txt"]
    assert attachments[0].content == b"hello"
    assert (
        calls[0]
        == "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments?$top=100"
    )
    assert (
        calls[1]
        == "https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments/att-1/$value"
    )


def test_download_attachments_uses_inline_content_bytes_when_available(tmp_path: Path) -> None:
    calls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        return _response(
            {
                "value": [
                    {
                        "id": "att-1",
                        "name": "report.txt",
                        "contentType": "text/plain",
                        "size": 10,
                        "contentBytes": "aGVsbG8=",
                        "@odata.type": "#microsoft.graph.fileAttachment",
                    }
                ]
            }
        )

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    attachments = client.download_attachments("msg-1")

    assert len(attachments) == 1
    assert attachments[0].content == b"hello"
    assert calls == ["https://graph.microsoft.com/v1.0/me/messages/msg-1/attachments?$top=100"]


def test_search_emails_builds_filter_query(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        captured["headers"] = dict(req.headers)
        return _response({"value": []})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.search_emails("board", mailbox_filter="focused")

    assert "$search=%22board%22" in captured["url"]
    assert captured["headers"]["Consistencylevel"] == "eventual"


def test_search_emails_strips_surrounding_quotes_before_building_search(tmp_path: Path) -> None:
    captured: dict[str, Any] = {}

    def transport(req: Any, timeout: float) -> Any:
        captured["url"] = req.full_url
        return _response({"value": []})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.search_emails('"board review"')

    assert "$search=%22board+review%22" in captured["url"]


def test_search_emails_retries_with_plain_search_for_position_zero_parse_error(
    tmp_path: Path,
) -> None:
    calls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        if len(calls) == 1:
            raise HTTPError(
                url=req.full_url,
                code=400,
                msg="Bad Request",
                hdrs=None,
                fp=_response(
                    {
                        "error": {
                            "code": "BadRequest",
                            "message": "An identifier was expected at position 0.",
                        }
                    }
                ),
            )
        return _response({"value": [_message_item("msg-1")]})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    messages = client.search_emails('"RE: EOS AWS EDP Renewal"')

    assert len(messages) == 1
    assert "$search=%22RE:+EOS+AWS+EDP+Renewal%22" in calls[0]
    assert "$search=RE:+EOS+AWS+EDP+Renewal" in calls[1]


def test_search_emails_fallback_escapes_odata_quotes(tmp_path: Path) -> None:
    calls: list[str] = []

    def transport(req: Any, timeout: float) -> Any:
        calls.append(req.full_url)
        if len(calls) == 1:
            raise HTTPError(
                url=req.full_url,
                code=400,
                msg="Bad Request",
                hdrs=None,
                fp=_response(
                    {
                        "error": {
                            "code": "Request_UnsupportedQuery",
                            "message": "The property does not support filtering.",
                        }
                    }
                ),
            )
        return _response({"value": []})

    client = EmailClient(GraphClient(config=_config(tmp_path), token="token", transport=transport))

    client.search_emails("o'brien")

    assert "contains(subject,'o''brien')" in calls[1]


def test_list_folders_returns_folder_summaries(tmp_path: Path) -> None:
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {"value": [{"id": "folder-1", "displayName": "Archive"}]}
            ),
        )
    )

    assert client.list_folders() == [{"id": "folder-1", "display_name": "Archive"}]


def test_delta_sync_returns_messages_removed_ids_and_links(tmp_path: Path) -> None:
    client = EmailClient(
        GraphClient(
            config=_config(tmp_path),
            token="token",
            transport=lambda req, timeout: _response(
                {
                    "value": [
                        _message_item("msg-1"),
                        {"id": "msg-2", "@removed": {"reason": "deleted"}},
                    ],
                    "@odata.deltaLink": "https://delta-link",
                }
            ),
        )
    )

    result = client.delta_sync(top=25)

    assert [message.id for message in result.messages] == ["msg-1"]
    assert result.removed_ids == ["msg-2"]
    assert result.delta_link == "https://delta-link"


class _FakeResponse:
    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        import json

        self._payload = json.dumps(payload).encode("utf-8")
        self.status = status

    def __enter__(self) -> _FakeResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload

    def close(self) -> None:
        return None


class _FakeBytesResponse:
    def __init__(self, payload: bytes, status: int = 200) -> None:
        self._payload = payload
        self.status = status

    def __enter__(self) -> _FakeBytesResponse:
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        return None

    def read(self) -> bytes:
        return self._payload

    def close(self) -> None:
        return None


def _response(payload: dict[str, Any], status: int = 200) -> _FakeResponse:
    return _FakeResponse(payload, status)


def _bytes_response(payload: bytes, status: int = 200) -> _FakeBytesResponse:
    return _FakeBytesResponse(payload, status)


def _message_item(message_id: str) -> dict[str, Any]:
    return {
        "id": message_id,
        "subject": "Hello",
        "from": {"emailAddress": {"address": "sender@example.com"}},
        "toRecipients": [{"emailAddress": {"address": "to@example.com"}}],
        "ccRecipients": [],
        "bccRecipients": [],
        "bodyPreview": "Hello world",
        "body": {"content": "<p>Hello <strong>world</strong></p>"},
        "receivedDateTime": "2026-03-12T15:00:00Z",
        "isRead": False,
        "flag": {"flagStatus": "flagged"},
        "importance": "high",
        "hasAttachments": True,
        "attachments": [
            {
                "name": "report.txt",
                "contentType": "text/plain",
                "size": 10,
                "contentBytes": "abc=",
                "@odata.type": "#microsoft.graph.fileAttachment",
            }
        ],
        "conversationId": "conv-1",
        "parentFolderId": "folder-1",
    }


def _config(tmp_path: Path) -> Any:
    config_path = tmp_path / "default" / "config.toml"
    content = """
[auth]
tenant_id = "tenant"
client_id = "client"

[user]
endpoint = "me"
user_principal_name = ""
timezone = "America/Chicago"

[safety]
domain_allowlist = ["example.com"]
folder_allowlist = ["Archive"]
send_email_per_hour = 5
send_email_per_day = 20
draft_email_per_hour = 10
draft_email_per_day = 30
reply_email_per_hour = 5
reply_email_per_day = 20
forward_email_per_hour = 5
forward_email_per_day = 20
move_email_per_hour = 20
flag_email_per_hour = 50
create_event_per_hour = 5
create_event_per_day = 20
update_event_per_hour = 10
respond_event_per_hour = 10

[vip]
emails = []
domains = []

[intelligence]
critical_keywords = []
noise_keywords = []
action_keywords = []
""".strip()
    write_config_text(config_path, content)
    return load_config(base_dir=tmp_path)
