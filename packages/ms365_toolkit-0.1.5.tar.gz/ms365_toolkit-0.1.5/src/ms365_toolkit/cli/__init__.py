from __future__ import annotations

import argparse
from typing import TYPE_CHECKING

from ms365_toolkit.cli.auth import login_command, revoke_write_command, status_command
from ms365_toolkit.cli.inbox import inbox_command
from ms365_toolkit.cli.labeling import (
    export_label_candidates_command,
    label_thread_command,
    review_label_candidates_command,
)
from ms365_toolkit.cli.labeling_web import launch_label_ui_command
from ms365_toolkit.cli.read_tools import (
    download_email_attachments_command,
    list_channel_messages_command,
    list_channel_replies_command,
    list_channels_command,
    list_chat_messages_command,
    list_chats_command,
    list_events_command,
    list_teams_command,
    morning_brief_command,
    read_channel_message_command,
    read_channel_thread_command,
    read_chat_message_command,
    read_email_command,
    search_channel_messages_command,
    search_chat_messages_command,
    search_chats_command,
    search_emails_command,
    search_local_mail_index_command,
    search_teams_messages_command,
    sync_mail_index_command,
    triage_inbox_command,
)
from ms365_toolkit.config.loader import load_config

if TYPE_CHECKING:
    from collections.abc import Sequence


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    if not hasattr(args, "handler"):
        parser.print_help()
        return 1
    if args.command == "revoke-write":
        return int(args.handler(args))
    config = load_config(profile=args.profile)
    return int(args.handler(args, config))


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="ms365-toolkit")
    parser.add_argument("--profile", default="default")
    subparsers = parser.add_subparsers(dest="command")

    auth_parser = subparsers.add_parser("auth")
    auth_subparsers = auth_parser.add_subparsers(dest="auth_command")

    login_parser = auth_subparsers.add_parser("login")
    login_parser.add_argument("--write", action="store_true")
    login_parser.add_argument("--teams-channel-messages", action="store_true")
    login_parser.add_argument("--insecure-env-write", action="store_true")
    login_parser.set_defaults(handler=login_command)

    status_parser = auth_subparsers.add_parser("status")
    status_parser.set_defaults(handler=status_command)

    revoke_parser = auth_subparsers.add_parser("revoke-write")
    revoke_parser.set_defaults(handler=revoke_write_command, command="revoke-write")

    inbox_parser = subparsers.add_parser("inbox")
    inbox_parser.add_argument("--top", type=int, default=10)
    inbox_parser.add_argument("--filter", choices=("focused", "all"), default="all")
    inbox_parser.set_defaults(handler=inbox_command)

    search_parser = subparsers.add_parser("search-emails")
    search_parser.add_argument("query")
    search_parser.add_argument("--top", type=int, default=10)
    search_parser.add_argument("--filter", choices=("focused", "all"), default="all")
    search_parser.set_defaults(handler=search_emails_command)

    sync_index_parser = subparsers.add_parser("sync-mail-index")
    sync_index_parser.add_argument("--batch-size", type=int, default=100)
    sync_index_parser.add_argument("--max-pages", type=int, default=10)
    sync_index_parser.set_defaults(handler=sync_mail_index_command)

    search_local_parser = subparsers.add_parser("search-local-mail")
    search_local_parser.add_argument("query")
    search_local_parser.add_argument("--top", type=int, default=10)
    search_local_parser.set_defaults(handler=search_local_mail_index_command)

    export_labels_parser = subparsers.add_parser("export-label-candidates")
    export_labels_parser.add_argument("--top", type=int, default=20)
    export_labels_parser.add_argument("--sync-index", action="store_true")
    export_labels_parser.add_argument("--max-pages", type=int, default=5)
    export_labels_parser.set_defaults(handler=export_label_candidates_command)

    review_labels_parser = subparsers.add_parser("review-label-candidates")
    review_labels_parser.add_argument("--top", type=int, default=10)
    review_labels_parser.add_argument(
        "--status",
        choices=("unlabeled", "labeled", "all"),
        default="unlabeled",
    )
    review_labels_parser.add_argument("--thread-id")
    review_labels_parser.set_defaults(handler=review_label_candidates_command)

    label_ui_parser = subparsers.add_parser("label-ui")
    label_ui_parser.add_argument("--host", default="127.0.0.1")
    label_ui_parser.add_argument("--port", type=int, default=8765)
    label_ui_parser.add_argument("--no-open", action="store_true")
    label_ui_parser.set_defaults(handler=launch_label_ui_command)

    label_thread_parser = subparsers.add_parser("label-thread")
    label_thread_parser.add_argument("thread_id")
    label_thread_parser.add_argument(
        "--thread-class",
        required=True,
        choices=(
            "approval_request",
            "decision_request",
            "incident_or_risk",
            "contract_or_renewal",
            "strategic_update",
            "status_update",
            "fyi_noise",
        ),
    )
    label_thread_parser.add_argument(
        "--action-needed",
        required=True,
        choices=("yes", "no", "unclear"),
    )
    label_thread_parser.add_argument(
        "--urgency",
        required=True,
        choices=("high", "medium", "low"),
    )
    label_thread_parser.add_argument(
        "--acted-by-you",
        required=True,
        choices=("replied", "forwarded", "ignored", "archived", "unknown"),
    )
    label_thread_parser.add_argument("--confidence", required=True, type=float)
    label_thread_parser.add_argument("--notes")
    label_thread_parser.set_defaults(handler=label_thread_command)

    triage_parser = subparsers.add_parser("triage-inbox")
    triage_parser.add_argument("--top", type=int, default=15)
    triage_parser.add_argument("--limit", type=int, default=5)
    triage_parser.add_argument("--sync-index", action="store_true")
    triage_parser.add_argument("--max-pages", type=int, default=5)
    triage_parser.set_defaults(handler=triage_inbox_command)

    read_email_parser = subparsers.add_parser("read-email")
    read_email_parser.add_argument("message_id")
    read_email_parser.set_defaults(handler=read_email_command)

    download_attachments_parser = subparsers.add_parser("download-email-attachments")
    download_attachments_parser.add_argument("message_id")
    download_attachments_parser.add_argument("--output-dir", default=".")
    download_attachments_parser.set_defaults(handler=download_email_attachments_command)

    list_events_parser = subparsers.add_parser("list-events")
    list_events_parser.add_argument("--hours", type=int, default=8)
    list_events_parser.set_defaults(handler=list_events_command)

    list_chats_parser = subparsers.add_parser("list-chats")
    list_chats_parser.add_argument("--top", type=int, default=25)
    list_chats_parser.set_defaults(handler=list_chats_command)

    search_chats_parser = subparsers.add_parser("search-chats")
    search_chats_parser.add_argument("query")
    search_chats_parser.add_argument("--top", type=int, default=10)
    search_chats_parser.set_defaults(handler=search_chats_command)

    list_chat_messages_parser = subparsers.add_parser("list-chat-messages")
    list_chat_messages_parser.add_argument("chat_id")
    list_chat_messages_parser.add_argument("--top", type=int, default=25)
    list_chat_messages_parser.set_defaults(handler=list_chat_messages_command)

    search_chat_messages_parser = subparsers.add_parser("search-chat-messages")
    search_chat_messages_parser.add_argument("chat_id")
    search_chat_messages_parser.add_argument("query")
    search_chat_messages_parser.add_argument("--top", type=int, default=10)
    search_chat_messages_parser.set_defaults(handler=search_chat_messages_command)

    search_teams_messages_parser = subparsers.add_parser("search-teams-messages")
    search_teams_messages_parser.add_argument("query")
    search_teams_messages_parser.add_argument("--top", type=int, default=10)
    search_teams_messages_parser.set_defaults(handler=search_teams_messages_command)

    read_chat_message_parser = subparsers.add_parser("read-chat-message")
    read_chat_message_parser.add_argument("chat_id")
    read_chat_message_parser.add_argument("message_id")
    read_chat_message_parser.set_defaults(handler=read_chat_message_command)

    list_teams_parser = subparsers.add_parser("list-teams")
    list_teams_parser.set_defaults(handler=list_teams_command)

    list_channels_parser = subparsers.add_parser("list-channels")
    list_channels_parser.add_argument("team_id")
    list_channels_parser.set_defaults(handler=list_channels_command)

    list_channel_messages_parser = subparsers.add_parser("list-channel-messages")
    list_channel_messages_parser.add_argument("team_id")
    list_channel_messages_parser.add_argument("channel_id")
    list_channel_messages_parser.add_argument("--top", type=int, default=25)
    list_channel_messages_parser.set_defaults(handler=list_channel_messages_command)

    search_channel_messages_parser = subparsers.add_parser("search-channel-messages")
    search_channel_messages_parser.add_argument("team_id")
    search_channel_messages_parser.add_argument("channel_id")
    search_channel_messages_parser.add_argument("query")
    search_channel_messages_parser.add_argument("--top", type=int, default=10)
    search_channel_messages_parser.set_defaults(handler=search_channel_messages_command)

    list_channel_replies_parser = subparsers.add_parser("list-channel-replies")
    list_channel_replies_parser.add_argument("team_id")
    list_channel_replies_parser.add_argument("channel_id")
    list_channel_replies_parser.add_argument("message_id")
    list_channel_replies_parser.add_argument("--top", type=int, default=25)
    list_channel_replies_parser.set_defaults(handler=list_channel_replies_command)

    read_channel_message_parser = subparsers.add_parser("read-channel-message")
    read_channel_message_parser.add_argument("team_id")
    read_channel_message_parser.add_argument("channel_id")
    read_channel_message_parser.add_argument("message_id")
    read_channel_message_parser.set_defaults(handler=read_channel_message_command)

    read_channel_thread_parser = subparsers.add_parser("read-channel-thread")
    read_channel_thread_parser.add_argument("team_id")
    read_channel_thread_parser.add_argument("channel_id")
    read_channel_thread_parser.add_argument("message_id")
    read_channel_thread_parser.add_argument("--top", type=int, default=25)
    read_channel_thread_parser.set_defaults(handler=read_channel_thread_command)

    morning_brief_parser = subparsers.add_parser("morning-brief")
    morning_brief_parser.add_argument("--top", type=int, default=10)
    morning_brief_parser.set_defaults(handler=morning_brief_command)

    return parser
