from __future__ import annotations

from datetime import UTC, datetime
from functools import wraps
from typing import TYPE_CHECKING, Any, ParamSpec, TypeVar

from ms365_toolkit.client.exceptions import AuthenticationError, GraphAPIError, RateLimitedError
from ms365_toolkit.mcp.planner import find_open_windows
from ms365_toolkit.mcp.serializers import (
    serialize_channel,
    serialize_chat,
    serialize_email,
    serialize_event,
    serialize_team,
    serialize_teams_message,
    serialize_teams_message_search_hit,
    serialize_teams_reply_page,
    serialize_teams_thread,
    serialize_windows,
)

if TYPE_CHECKING:
    from collections.abc import Callable

    from fastmcp import FastMCP

    from ms365_toolkit.mcp.runtime import ReadRuntime

P = ParamSpec("P")
R = TypeVar("R")


def register_tools(mcp: FastMCP, runtime: ReadRuntime) -> None:
    @mcp.tool(description="List inbox messages from the current mailbox.")
    @_tool_errors
    def list_inbox(
        mailbox_filter: str = "all",
        top: int = 10,
        skip: int = 0,
    ) -> dict[str, Any]:
        normalized_filter = _normalize_mailbox_filter(mailbox_filter)
        messages = runtime.email_client().list_inbox(
            mailbox_filter=normalized_filter,
            top=_positive_int(top, "top"),
            skip=_non_negative_int(skip, "skip"),
        )
        return {"messages": [serialize_email(item) for item in messages]}

    @mcp.tool(description="Search mailbox messages by query.")
    @_tool_errors
    def search_emails(
        query: str,
        mailbox_filter: str = "all",
        top: int = 10,
    ) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        normalized_filter = _normalize_mailbox_filter(mailbox_filter)
        messages = runtime.email_client().search_emails(
            query=query,
            mailbox_filter=normalized_filter,
        )
        return {
            "messages": [serialize_email(item) for item in messages[: _positive_int(top, "top")]]
        }

    @mcp.tool(description="Read a single email message by id.")
    @_tool_errors
    def read_email(message_id: str) -> dict[str, Any]:
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_email(runtime.email_client().read_email(message_id))

    @mcp.tool(description="List available mail folders.")
    @_tool_errors
    def list_folders() -> dict[str, Any]:
        return {"folders": runtime.email_client().list_folders()}

    @mcp.tool(description="List calendar events in a time window.")
    @_tool_errors
    def list_events(
        start: str,
        end: str,
        calendar_id: str | None = None,
        calendar_filter: str | None = None,
    ) -> dict[str, Any]:
        start_dt, end_dt = _parse_window(start, end)
        events = runtime.calendar_client().list_events(
            start=start_dt,
            end=end_dt,
            calendar_id=_optional_str(calendar_id),
            calendar_filter=_optional_str(calendar_filter),
        )
        return {"events": [serialize_event(item) for item in events]}

    @mcp.tool(description="Get a single calendar event by id.")
    @_tool_errors
    def get_event(event_id: str) -> dict[str, Any]:
        if not event_id.strip():
            raise ValueError("event_id must be a non-empty string")
        return serialize_event(runtime.calendar_client().get_event(event_id))

    @mcp.tool(description="Search calendar events by subject.")
    @_tool_errors
    def search_events(
        query: str,
        start: str | None = None,
        end: str | None = None,
    ) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        start_dt = _parse_datetime(start, "start") if start is not None else None
        end_dt = _parse_datetime(end, "end") if end is not None else None
        if start_dt is not None and end_dt is not None and end_dt <= start_dt:
            raise ValueError("end must be later than start")
        events = runtime.calendar_client().search_events(query=query, start=start_dt, end=end_dt)
        return {"events": [serialize_event(item) for item in events]}

    @mcp.tool(description="List available calendars.")
    @_tool_errors
    def list_calendars() -> dict[str, Any]:
        return {"calendars": runtime.calendar_client().list_calendars()}

    @mcp.tool(description="Find open windows across attendees using Microsoft 365 free/busy.")
    @_tool_errors
    def find_free_slots(
        attendees: list[str],
        start: str,
        end: str,
        duration_minutes: int,
        ignore_subject_terms: list[str] | None = None,
    ) -> dict[str, Any]:
        normalized_attendees = [item.strip() for item in attendees if item.strip()]
        if not normalized_attendees:
            raise ValueError("attendees must contain at least one email address")
        start_dt, end_dt = _parse_window(start, end)
        response = runtime.graph_client().post(
            "calendar/getSchedule",
            body={
                "schedules": normalized_attendees,
                "startTime": {
                    "dateTime": start_dt.isoformat().replace("+00:00", "Z"),
                    "timeZone": "UTC",
                },
                "endTime": {
                    "dateTime": end_dt.isoformat().replace("+00:00", "Z"),
                    "timeZone": "UTC",
                },
                "availabilityViewInterval": _positive_int(duration_minutes, "duration_minutes"),
            },
        )
        windows = find_open_windows(
            response,
            start=start_dt,
            end=end_dt,
            duration_minutes=duration_minutes,
            ignore_subject_terms=ignore_subject_terms or [],
        )
        return {"windows": serialize_windows(windows)}

    @mcp.tool(description="List Teams chats for the current user.")
    @_tool_errors
    def list_chats(top: int = 25) -> dict[str, Any]:
        chats = runtime.teams_client(include_channel_messages=False).list_chats(
            top=_positive_int(top, "top")
        )
        return {"chats": [serialize_chat(item) for item in chats]}

    @mcp.tool(description="Search Teams chats by participant name, email, or topic.")
    @_tool_errors
    def search_chats(query: str, top: int = 10) -> dict[str, Any]:
        chats = runtime.teams_client(include_channel_messages=False).search_chats(
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"chats": [serialize_chat(item) for item in chats]}

    @mcp.tool(description="List messages from a Teams chat.")
    @_tool_errors
    def list_chat_messages(chat_id: str, top: int = 25) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=False).list_chat_messages(
            chat_id=chat_id,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="Search messages in a Teams chat.")
    @_tool_errors
    def search_chat_messages(chat_id: str, query: str, top: int = 10) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=False).search_chat_messages(
            chat_id=chat_id,
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="Search Teams messages across chats and channels.")
    @_tool_errors
    def search_teams_messages(query: str, top: int = 10) -> dict[str, Any]:
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=True).search_teams_messages(
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message_search_hit(item) for item in messages]}

    @mcp.tool(description="Read a single Teams chat message by id.")
    @_tool_errors
    def read_chat_message(chat_id: str, message_id: str) -> dict[str, Any]:
        if not chat_id.strip():
            raise ValueError("chat_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_teams_message(
            runtime.teams_client(include_channel_messages=False).get_chat_message(
                chat_id,
                message_id,
            )
        )

    @mcp.tool(description="List Teams joined teams for the current user.")
    @_tool_errors
    def list_teams() -> dict[str, Any]:
        return {
            "teams": [
                serialize_team(item)
                for item in runtime.teams_client(include_channel_messages=False).list_teams()
            ]
        }

    @mcp.tool(description="List channels in a Teams team.")
    @_tool_errors
    def list_channels(team_id: str) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        channels = runtime.teams_client(include_channel_messages=False).list_channels(team_id)
        return {"channels": [serialize_channel(item) for item in channels]}

    @mcp.tool(description="List top-level messages in a Teams channel.")
    @_tool_errors
    def list_channel_messages(team_id: str, channel_id: str, top: int = 25) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=True).list_channel_messages(
            team_id=team_id,
            channel_id=channel_id,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="Search top-level messages in a Teams channel.")
    @_tool_errors
    def search_channel_messages(
        team_id: str,
        channel_id: str,
        query: str,
        top: int = 10,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not query.strip():
            raise ValueError("query must be a non-empty string")
        messages = runtime.teams_client(include_channel_messages=True).search_channel_messages(
            team_id=team_id,
            channel_id=channel_id,
            query=query,
            top=_positive_int(top, "top"),
        )
        return {"messages": [serialize_teams_message(item) for item in messages]}

    @mcp.tool(description="List replies to a Teams channel message.")
    @_tool_errors
    def list_channel_replies(
        team_id: str,
        channel_id: str,
        message_id: str,
        top: int = 25,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        reply_page = runtime.teams_client(include_channel_messages=True).list_channel_replies(
            team_id=team_id,
            channel_id=channel_id,
            message_id=message_id,
            top=_positive_int(top, "top"),
        )
        return serialize_teams_reply_page(reply_page)

    @mcp.tool(description="Read a single Teams channel message by id.")
    @_tool_errors
    def read_channel_message(team_id: str, channel_id: str, message_id: str) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        return serialize_teams_message(
            runtime.teams_client(include_channel_messages=True).get_channel_message(
                team_id,
                channel_id,
                message_id,
            )
        )

    @mcp.tool(description="Read a Teams channel thread, including replies.")
    @_tool_errors
    def read_channel_thread(
        team_id: str,
        channel_id: str,
        message_id: str,
        top: int = 25,
    ) -> dict[str, Any]:
        if not team_id.strip():
            raise ValueError("team_id must be a non-empty string")
        if not channel_id.strip():
            raise ValueError("channel_id must be a non-empty string")
        if not message_id.strip():
            raise ValueError("message_id must be a non-empty string")
        thread = runtime.teams_client(include_channel_messages=True).read_channel_thread(
            team_id,
            channel_id,
            message_id,
            replies_top=_positive_int(top, "top"),
        )
        return serialize_teams_thread(thread)


def _tool_errors(func: Callable[P, R]) -> Callable[P, R]:
    @wraps(func)
    def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
        try:
            return func(*args, **kwargs)
        except ValueError:
            raise
        except AuthenticationError as exc:
            raise RuntimeError(f"Authentication failed: {exc}") from exc
        except RateLimitedError as exc:
            raise RuntimeError(str(exc)) from exc
        except GraphAPIError as exc:
            raise RuntimeError(
                f"Microsoft Graph error {exc.status_code} ({exc.error_code}): {exc.message}"
            ) from exc
        except Exception as exc:
            raise RuntimeError("Internal MCP server error") from exc

    return wrapper


def _normalize_mailbox_filter(value: str) -> str | None:
    normalized = value.strip().lower()
    if normalized not in {"all", "focused"}:
        raise ValueError("filter must be 'all' or 'focused'")
    return None if normalized == "all" else normalized


def _parse_window(start: str, end: str) -> tuple[datetime, datetime]:
    start_dt = _parse_datetime(start, "start")
    end_dt = _parse_datetime(end, "end")
    if end_dt <= start_dt:
        raise ValueError("end must be later than start")
    return start_dt, end_dt


def _parse_datetime(value: str, field_name: str) -> datetime:
    raw = value.strip()
    if not raw:
        raise ValueError(f"{field_name} must be a non-empty ISO 8601 datetime")
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError(f"{field_name} must be a valid ISO 8601 datetime") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{field_name} must include a timezone offset")
    return parsed.astimezone(UTC)


def _positive_int(value: int, field_name: str) -> int:
    if value <= 0:
        raise ValueError(f"{field_name} must be a positive integer")
    return value


def _non_negative_int(value: int, field_name: str) -> int:
    if value < 0:
        raise ValueError(f"{field_name} must be zero or greater")
    return value


def _optional_str(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip()
    return normalized or None
