from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from datetime import datetime


@dataclass(frozen=True)
class TeamsChat:
    id: str
    topic: str
    display_label: str
    chat_type: str
    created_at: datetime | None
    last_updated_at: datetime | None
    last_message_read_at: datetime | None
    web_url: str
    is_hidden: bool
    is_hidden_for_all_members: bool
    other_participants: tuple[TeamsParticipant, ...]


@dataclass(frozen=True)
class TeamsParticipant:
    display_name: str
    email: str
    user_id: str


@dataclass(frozen=True)
class TeamSummary:
    id: str
    display_name: str
    description: str
    is_archived: bool
    tenant_id: str


@dataclass(frozen=True)
class ChannelSummary:
    id: str
    display_name: str
    description: str
    membership_type: str
    web_url: str


@dataclass(frozen=True)
class TeamsSender:
    display_name: str
    email: str
    user_id: str
    kind: str


@dataclass(frozen=True)
class TeamsMessage:
    id: str
    body_content: str
    content_type: str
    created_at: datetime | None
    last_modified_at: datetime | None
    last_edited_at: datetime | None
    deleted_at: datetime | None
    subject: str
    summary: str
    importance: str
    message_type: str
    reply_to_id: str
    reply_count: int
    web_url: str
    chat_id: str
    team_id: str
    channel_id: str
    sender: TeamsSender


@dataclass(frozen=True)
class TeamsMessageSearchHit:
    id: str
    summary: str
    created_at: datetime | None
    last_modified_at: datetime | None
    subject: str
    importance: str
    web_url: str
    chat_id: str
    team_id: str
    channel_id: str
    sender_name: str
    sender_email: str
    location_kind: str


@dataclass(frozen=True)
class TeamsReplyPage:
    replies: tuple[TeamsMessage, ...]
    has_more_replies: bool


@dataclass(frozen=True)
class TeamsThread:
    root_message: TeamsMessage
    replies: tuple[TeamsMessage, ...]
    has_more_replies: bool
