# ########################################################################
#
# Ricgraph - Research in context graph
#
# ########################################################################
#
# MIT License
#
# Copyright (c) 2023 - 2025 Rik D.T. Janssen
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
# ########################################################################
#
# General Ricgraph functions.
# For more information about Ricgraph and Ricgraph Explorer,
# go to https://www.ricgraph.eu and https://docs.ricgraph.eu.
#
# ########################################################################
#
# Original version Rik D.T. Janssen, December 2022.
# Updated Rik D.T. Janssen, February, March, September to December 2023.
# Updated Rik D.T. Janssen, February to June, September to December  2024.
# Updated Rik D.T. Janssen, January to June, October 2025.
#
# ########################################################################


from os import path
from sys import prefix
from re import sub, findall
from numpy import maximum
from pandas import DataFrame
from typing import Tuple
from ast import literal_eval
from random import choice
from string import ascii_lowercase
from datetime import datetime
from uuid import uuid4
from collections import defaultdict
from configparser import ConfigParser
from unidecode import unidecode
from markupsafe import escape as markupsafe_escape
from .ricgraph_constants import (RICGRAPH_INI_FILENAME,
                                 RICGRAPH_KEY_SEPARATOR, RICGRAPH_KEY_SEPARATOR_REPLACEMENT,
                                 RICGRAPH_VALUE_SEPARATOR, RICGRAPH_VALUE_SEPARATOR_REPLACEMENT,
                                 MAX_ORG_ABBREVIATION_LENGTH)


def get_ricgraph_ini_file() -> str:
    """Get the location of the ricgraph ini file.

    :return: the location of the ini file.
    """
    # Try to find RICGRAPH_INI_FILENAME in the root of the virtual environment.
    ricgraph_ini_path = prefix
    ricgraph_ini = path.join(ricgraph_ini_path, RICGRAPH_INI_FILENAME)
    if path.exists(ricgraph_ini):
        return ricgraph_ini

    # Try to find RICGRAPH_INI_FILENAME in the parent directory of the venv,
    # which may happen when using a Python IDE.
    ricgraph_ini_path_parent = path.dirname(ricgraph_ini_path)
    ricgraph_ini = path.join(ricgraph_ini_path_parent, RICGRAPH_INI_FILENAME)
    if path.exists(ricgraph_ini):
        return ricgraph_ini

    print('Ricgraph initialization: error, Ricgraph ini file "' + RICGRAPH_INI_FILENAME + '" not found in')
    print('   directory "' + ricgraph_ini_path + '", nor in')
    print('   directory "' + ricgraph_ini_path_parent + '", exiting.')
    exit(1)


def timestamp(seconds: bool = False) -> str:
    """Get a timestamp only consisting of a time.

    :param seconds: If True, also show seconds in the timestamp.
    :return: the timestamp.
    """
    now = datetime.now()
    if seconds:
        time_stamp = now.strftime("%H:%M:%S")
    else:
        time_stamp = now.strftime("%H:%M")
    return time_stamp


def datetimestamp(seconds: bool = False) -> str:
    """Get a timestamp consisting of a date and a time.

    :param seconds: If True, also show seconds in the timestamp.
    :return: the timestamp.
    """
    now = datetime.now()
    if seconds:
        datetime_stamp = now.strftime("%Y-%m-%d %H:%M:%S")
    else:
        datetime_stamp = now.strftime("%Y-%m-%d %H:%M")
    return datetime_stamp


def timestamp_posix() -> int:
    """Get a timestamp in seconds, in posix format.
    This is different from timestamp(), that function
    uses Python datetime (a complex type).

    :return: the timestamp.
    """
    now = int(datetime.now().timestamp())
    return now


def print_records_per_minute(start_ts: int, end_ts: int,
                             nr_records: int,
                             what: str = 'Processed') -> None:
    """Prints processing rate in records per minute using POSIX timestamps.

    :param start_ts: Start time (POSIX timestamp, seconds since epoch).
    :param end_ts: End time (POSIX timestamp, seconds since epoch).
    :param nr_records: Number of records processed.
    :param what: What the "processed" message means.
    :return: None.
    """
    if start_ts > end_ts:
        print('print_records_per_minute(): Error, start_ts (' + str(start_ts)
              + ') is larger than end_ts (' + str(end_ts) + '). Exiting.')
        exit(1)

    elapsed_ts = end_ts - start_ts
    if elapsed_ts <= 120:
        print(what + ' ' + str(nr_records) + ' records in almost no time.')
    else:
        # Only show the number of records/min if elapsed_ts > 2 min.
        rpm = str(round((nr_records / elapsed_ts) * 60))
        elapsed = str(round(elapsed_ts / 60))
        print(what + ' ' + str(nr_records) + ' records in (rounded) ' + elapsed
              + ' minutes, or ' + rpm + ' records/minute.')
    return


def convert_string_to_ascii(value: str = '') -> str:
    """Convert all accented etc. characters to their ASCII equivalent.
    We use Unidecode from https://github.com/avian2/unidecode.

    :return: the ASCII equivalent.
    """
    asc = unidecode(string=value)
    return asc


def create_unique_string(length: int = 0) -> str:
    """Create a (pseudo) unique string of characters.
    Only if you don't specify 'length' or give it value 0,
    the string will really be unique. Otherwise, it will
    be pseudo unique.

    :param length: 0 or empty for unique string, otherwise length
      of string to create.
    :return: unique string.
    """
    if length == 0:
        # UUID4 is randomly generated and guaranteed to be unique.
        # The probability to find a duplicate within 103 trillion
        # version-4 UUIDs is one in a billion.
        # https://en.wikipedia.org/wiki/Universally_unique_identifier.
        return str(uuid4())

    # This will generate a pseudo random string.
    value = ''.join(choice(ascii_lowercase) for _ in range(length))
    return value


def sanitize_string(to_sanitize: str) -> str:
    """Replace any character that is a non-ASCII letter or digit with '_'.
    ASCII characters will be converted to lower case.

    :param to_sanitize: the string to sanitize.
    :return: result.
    """
    result = to_sanitize.lower()
    result = sub(pattern=r'[^a-z0-9]', repl='_', string=result)
    return result


def serialize_value(value: str) -> bytes:
    """Serialize a value (convert to bytes).

    :param value: the value.
    :return: its serialized value.
    """
    return value.encode(encoding='utf-8')


def deserialize_value(serialized: bytes) -> str:
    """Deserialize a value (convert back from bytes).

    :param serialized: the serialized value.
    :return: its deserialized value.
    """
    return serialized.decode(encoding='utf-8')


def make_dataframe_square_symmetric(df: DataFrame | None) -> DataFrame | None:
    """Ensure the DataFrame is square by adding missing rows/columns
    filled with zeros. After that, make it symmetric.

    :param df: the DataFrame.
    :return: the resulting DataFrame.
    """
    if df is None or df.empty:
        print('make_df_square_symmetric(): Error, DataFrame is empty.')
        return None

    all_orgs = list(set(df.index).union(df.columns))
    df = df.reindex(index=all_orgs, columns=all_orgs, fill_value=0)
    if df is None or df.empty:
        return None

    # Make it a symmetric matrix. Since collaborations are symmetric,
    # we use the element wise maximum, using np.maximum().
    df_symmetric = df.combine(other=df.T, func=maximum)

    return df_symmetric


def combine_dataframes(df1: DataFrame | None, df2: DataFrame | None) -> DataFrame | None:
    """Combines two DataFrames with additive overlapping values
    and union of indices/columns.

    :param df1: first DataFrame.
    :param df2: second DataFrame.
    :return: combined DataFrame.
    """
    if df1 is None or df1.empty:
        return None
    if df2 is None or df2.empty:
        return None
    if df1 is None or df1.empty:
        # DataFrame 1 is empty.
        return df2.copy(deep=True)
    if df2 is None or df2.empty:
        # DataFrame 2 is empty.
        return df1.copy(deep=True)

    # Note that the top left cell contains the researchresult_category/ies
    # that were used to get the result stored in the DataFrame.
    # The new DataFrame should have their combined values.
    index_name1 = str(df1.index.name) if df1.index.name is not None else ''
    index_name2 = str(df2.index.name) if df2.index.name is not None else ''
    df1_researchresult_category = literal_eval(node_or_string=index_name1)
    df2_researchresult_category = literal_eval(node_or_string=index_name2)
    df_combined_researchresult_category = list(set(df1_researchresult_category).union(set(df2_researchresult_category)))
    df_combined_researchresult_category.sort(key=lambda s: s.lower())
    df_combined = df1.copy(deep=True)
    df_combined = df_combined.add(df2, fill_value=0).fillna(0).astype(int)
    df_combined.index.name = str(df_combined_researchresult_category)
    return df_combined


def convert_cypher_recordslist_to_nodeslist(records_list:list) -> list:
    """Convert a Cypher list with Records to a list of Nodes.
    This is necessary since cypher_result, _, _ = graph.execute_query()
    returns a list of Records, and most of the time I need a list of Nodes.
    Note that the nodes should have name 'node', so do something like
    'RETURN personroot AS node' in your Cypher query.

    :param records_list: the list of Records.
    :return: the list of Nodes, or [] if the list of Records is empty.
    """
    if len(records_list) == 0:
        return []

    if not 'node' in records_list[0].keys():
        print('convert_cypher_recordslist_to_nodeslist(): Error. The elements in the')
        print('list of Records do not have name "node". They should. Exiting...')
        exit(1)

    nodes_list = [record['node'] for record in records_list]
    return nodes_list


def convert_nodeslist_to_dataframe(nodes_list: list,
                                   columns_and_order: list = None) -> None | DataFrame:
    """Convert a list of RicgraphNode nodes to a DataFrame,
    with selected columns in an order given.

    :param nodes_list: the list of nodes.
    :param columns_and_order: only return these columns, and in the order given.
    :return: the DataFrame, or None if empty.
    """
    if len(nodes_list) == 0:
        return None
    if columns_and_order is None:
        print('convert_nodeslist_to_dataframe(): Warning, columns_and_order not specified, continuing...')
        return None

    nodes_dict = [dict(node) for node in nodes_list]
    result = DataFrame(data=nodes_dict)
    # Make sure we select only columns that exist.
    present_columns = [col for col in columns_and_order if col in result.columns]
    result = result[present_columns]
    if result is None or result.empty:
        return None
    result.set_index(keys='name', inplace=True)
    return result


def extract_organization_abbreviation(org_name: str) -> str:
    """This function extracts the organization abbreviation from an organization
    name. It is assumed that the organization name has an organization abbreviation,
    it should be the first 2 to MAX_ORG_ABBREVIATION_LENGTH characters.

    :param org_name: the organization name.
    :return: uppercase version of the organization abbreviation.
    """
    org_abbr = org_name[:MAX_ORG_ABBREVIATION_LENGTH]
    org_abbr = org_abbr.rstrip()
    if ' ' in org_abbr:
        # Split at the first space character, keep everything before the space.
        org_abbr = org_abbr.split(sep=' ', maxsplit=1)[0]
    return org_abbr.upper()


def construct_extended_org_name(org_abbr: str,
                                org_type: str = '',
                                org_name: str = '') -> str:
    """Construct the extended organization name.
    This is done by appending the organization abbreviation,
    the organization type, and the organization name.

    :param org_abbr: The organization abbreviation.
    :param org_type: The type of organization (faculty, department, etc.)
    :param org_name: The organization name.
    :return: the combination of both.
    """
    extended_org_name = org_abbr.upper() + ' '
    if org_type != '':
        extended_org_name += org_type + ': '
    extended_org_name += org_name
    return extended_org_name


def create_ricgraph_key(name: str, value: str) -> str:
    """Create a key for a node.
    This function generates a composite key for a node in a graph.

    :param name: name of the node.
    :param value: value of the node.
    :return: key generated for the node.
    """
    # Check and correct for occurrences of RICGRAPH_KEY_SEPARATOR.
    name = name.replace(RICGRAPH_KEY_SEPARATOR, RICGRAPH_KEY_SEPARATOR_REPLACEMENT)
    value = value.replace(RICGRAPH_KEY_SEPARATOR, RICGRAPH_KEY_SEPARATOR_REPLACEMENT)

    return value.lower() + RICGRAPH_KEY_SEPARATOR + name.lower()


def get_namepart_from_ricgraph_key(key: str) -> str:
    """Get the 'name' part from the composite key in a node.

    :param key: key of the node.
    :return: name part of key for the node, or '' on error.
    """
    key_list = key.split(sep=RICGRAPH_KEY_SEPARATOR)
    if len(key_list) != 2:
        return ''
    return key_list[1]


def get_valuepart_from_ricgraph_key(key: str) -> str:
    """Get the 'value' part from the composite key in a node.

    :param key: key of the node.
    :return: value part of key for the node, or '' on error.
    """
    key_list = key.split(sep=RICGRAPH_KEY_SEPARATOR)
    if len(key_list) != 2:
        return ''
    return key_list[0]


def create_ricgraph_value(value: str, additional: str) -> str:
    """Sometimes, we may want to have non-unique nodes.
    E.g. the same name may apply to different persons,
    so FULL_NAME is not unique.
    However, for Ricgraph every node needs to be unique,
    so we append a certain value to it, 'additional'.
    Together they need to be unique.

    :param value: value.
    :param additional: an additional value to make this node unique.
    :return: the concatenation.
    """
    # Check and correct for occurrences of RICGRAPH_KEY_SEPARATOR.
    value = value.replace(RICGRAPH_VALUE_SEPARATOR, RICGRAPH_VALUE_SEPARATOR_REPLACEMENT)
    additional = additional.replace(RICGRAPH_VALUE_SEPARATOR, RICGRAPH_VALUE_SEPARATOR_REPLACEMENT)

    # Note that we don't do a .lower(), since we want the correctly spelled name.
    return value + RICGRAPH_VALUE_SEPARATOR + additional.lower()


def get_valuepart_from_ricgraph_value(key: str) -> str:
    """Get the 'value' part from the composite key in a node.

    :param key: key of the node.
    :return: the value part, or '' on error.
    """
    key_list = key.split(sep=RICGRAPH_VALUE_SEPARATOR)
    if len(key_list) != 2:
        return ''
    return key_list[0]


def get_additionalpart_from_ricgraph_value(key: str) -> str:
    """Get the 'value' part from the composite key in a node.

    :param key: key of the node.
    :return: the additional part, or '' on error.
    """
    key_list = key.split(sep=RICGRAPH_VALUE_SEPARATOR)
    if len(key_list) != 2:
        return ''
    return key_list[1]


def create_multidimensional_dict(dimension: int, dict_type):
    """Create a multidimensional dict.
    Non-existing keys will be added automatically.
    From https://stackoverflow.com/questions/29348345/declaring-a-multi-dimensional-dictionary-in-python,
    the second answer.

    Example use:
    new_dict = create_multidimensional_dict(2, int)
    new_dict['key1']['key2'] += 5

    :param dimension: dimension of the dict.
    :param dict_type: type of the dict.
    :return: the dict.
    """
    if dimension == 0:
        return None
    if dimension == 1:
        return defaultdict(dict_type)
    else:
        return defaultdict(lambda: create_multidimensional_dict(dimension=dimension - 1,
                                                                dict_type=dict_type))


def construct_filename(base_filename: str,
                       year: str = '', organization: str = '') -> str:
    """Construct a filename, based on a base filename,
    including year (if present) and organization (if present).

    :param base_filename: The base of the filename. It should
        have an extension, because we split around it.
    :param year: Optional, the year.
    :param organization: Optional, the organization.
    :return: The constructed filename
    """
    if '.' not in base_filename:
        print('construct_data_filename(): Error, missing dot (.) in "'
              + base_filename + '".')
        exit(1)

    filename = base_filename.split('.')[0]
    if year != '':
        filename += '-' + year
    if organization != '':
        filename += '-' + organization
    filename += '.' + base_filename.split('.')[1]
    return filename


def print_commandline_arguments(argument_list: list) -> None:
    """Print the script name and all command line arguments.

    :param argument_list: the argument list.
    :return: None.
    """
    if len(argument_list) == 0:
        print('print_commandline_arguments(): Error, empty argument_list passed, exiting.')
        exit(1)

    print('\nScript name: ' + argument_list[0])
    if len(argument_list) == 1:
        print('Command line arguments: [none]')
    else:
        print('Command line arguments: '
              + ' '.join([str(arg) for arg in argument_list[1:]])
              + '\n')
    return


def get_commandline_argument(argument: str, argument_list: list) -> str:
    """Get the value of a command line argument

    :param argument: the command line argument name.
    :param argument_list: the argument list.
    :return: the value that belongs to 'argument'.
    """
    length = len(argument_list)
    if length == 0:
        print('get_commandline_argument(): Error, empty argument_list passed, exiting.')
        exit(1)

    if str(argument) == '':
        # No argument passed.
        return ''

    if length == 1:
        # The argument list contains the script name only.
        return ''

    for i in range(1, length - 1):
        if str(argument_list[i]) == str(argument):
            if i + 1 <= length:
                # Only get the next index if we are still in the array bounds.
                return str(argument_list[i + 1])
    return ''


def get_commandline_argument_organization(argument_list: list) -> str:
    """Get the value of a command line argument '--organization'.
    Prompt if no argument is given.

    :param argument_list: the argument list.
    :return: the organization, or '' if no answer is given.
    """
    answer = get_commandline_argument(argument='--organization',
                                      argument_list=argument_list)
    if answer == '':
        print('\nYou need to specify an organization abbreviation.')
        print('This script will be run for that organization.')
        print('The organization abbreviation you enter will determine')
        print('which parameters will be read from the Ricgraph ini file')
        print('"' + get_ricgraph_ini_file() + '".')
        print('If you make a typo, you can run this script again.')
        print('If you enter an empty value, this script will exit.')
        answer = input('For what organization do you want to run this script? ')
        if answer == '':
            return ''

    answer = answer.upper()
    return answer


def get_commandline_argument_empty_ricgraph(argument_list: list) -> str:
    """Get the value of a command line argument '--empty_ricgraph'.
    Prompt if no argument is given.

    :param argument_list: the argument list.
    :return: 'yes' or 'no', the answer whether to empty Ricgraph,
      or '' if no answer is given.
    """
    answer = get_commandline_argument(argument='--empty_ricgraph',
                                      argument_list=argument_list)
    if answer == '':
        print('\nDo you want to empty Ricgraph? You have the following options:')
        print('- "yes": Ricgraph will be emptied.')
        print('- "no": Ricgraph will not be emptied.')
        print('- any other answer: Ricgraph will not be emptied,')
        print('  execution of this script will abort.')
        answer = input('Please make a choice: ')
        if answer == '':
            return ''

    answer = answer.lower()
    if answer != 'yes' and answer != 'no':
        return ''
    return answer


def get_commandline_argument_harvest_projects(argument_list: list) -> str:
    """Get the value of a command line argument '--harvest_projects'.
    Prompt if no argument is given.

    :param argument_list: the argument list.
    :return: 'yes' or 'no', the answer whether to harvest projects,
      or '' if no answer is given.
    """
    answer = get_commandline_argument(argument='--harvest_projects',
                                      argument_list=argument_list)
    if answer == '':
        print('\nYou can specify whether you want to harvest projects.')
        print('Only if enter "yes", this script will harvest projects.')
        answer = input('Do you want to harvest projects? ')
        if answer == '':
            return ''

    answer = answer.lower()
    if answer != 'yes' and answer != 'no':
        return ''
    return answer


def get_commandline_argument_filename(argument_list: list) -> str:
    """Get the value of a command line argument '--filename'.
    Prompt if no argument is given.

    :param argument_list: the argument list.
    :return: 'yes' or 'no', the answer whether to harvest projects,
      or '' if no answer is given.
    """
    answer = get_commandline_argument(argument='--filename',
                                      argument_list=argument_list)
    if answer == '':
        answer = input('Please specify a filename: ')
        if answer == '':
            return ''

    answer = answer.lower()
    return answer


def get_year_range_text(year_first: str = '', year_last:str = '') -> str:
    """Get a text describing the year range, like "from 2025 onwards",
    "up to 2025", "from 2023 to 2025", or "for all years".

    :param year_first: The first year, or '' if not specified.
    :param year_last: The last year, or '' if not specified.
    :return: The text describing the year range.
    """
    year_range_text = ''
    if year_first == '' and year_last == '':
        year_range_text += 'for all years '
    else:
        if year_first == '':
            year_range_text += 'up '
        else:
            year_range_text += 'from ' + year_first + ' '
        if year_last == '':
            year_range_text += 'onwards '
        else:
            year_range_text += 'to ' + year_last + ' '
    return year_range_text.strip()


def check_valid_year(year_first: str = '-1', year_last:str = '-1') -> str:
    """This function tests if either year_first or year_last or both
    have a valid value. If you specify both, also a comparison whether
    year_first < year_last is done.
    Since this function can be called to produce HTML, we escape the
    values that are printed.

    :param year_first: The first year. Do not specify if you don't need to
      check for it.
    :param year_last: The last year. Do not specify if you don't need to
      check for it.
    :return: If everything is oke, returns '', otherwise an error message.
    """
    if year_first == '-1' and year_last == '-1':
        return 'check_valid_year(): Error, invalid call to function.'
    if year_first != '-1':
        if year_first == '':
            return ''
        if not year_first.isdigit():
            message = 'Error: you did not specify a valid first year "'
            message += str(markupsafe_escape(year_first)) + '".'
            return message
    if year_last != '-1':
        if year_last == '':
            return ''
        if not year_last.isdigit():
            message = 'Error: you did not specify a valid last year "'
            message += str(markupsafe_escape(year_last)) + '".'
            return message
    if year_first != '-1' and year_last != '-1':
        if int(year_first) > int(year_last):
            message = 'Error: you did not specify a valid year range ["'
            message += str(markupsafe_escape(year_first)) + '", "'
            message += str(markupsafe_escape(year_last)) + '"].'
            return message
    return ''


def get_commandline_argument_year_first_last(argument_list: list) -> Tuple[str, str]:
    """Get the values of a command line arguments '--year_first' and '--year_last',
    and check for validity.

    :param argument_list: the argument list.
    :return: the year as a str, or '' if no answer is given.
    """
    year_first = get_commandline_argument(argument='--year_first',
                                          argument_list=argument_list)
    if year_first == '':
        year_first = input('Please enter the first year from which you would like to harvest: ')
    if (message := check_valid_year(year_first=year_first)) != '':
        print(message)
        return '', ''

    year_last = get_commandline_argument(argument='--year_last',
                                         argument_list=argument_list)
    if year_last == '':
        year_last = input('Please enter the last year from which you would like to harvest: ')
    if (message := check_valid_year(year_last=year_last)) != '':
        print(message)
        return '', ''

    if (message := check_valid_year(year_first=year_first,
                                    year_last=year_last)) != '':
        print(message)
        return '', ''
    return year_first, year_last


def get_configfile_key(section: str, key: str) -> str:
    """Get the value of a key in the Ricgraph config file.

    :param section: the section where the key is to be read from.
    :param key: the name of the key.
    :return: the value of the key (can be ''), or '' if absent.
    """
    config = ConfigParser(inline_comment_prefixes='#')
    config.read(get_ricgraph_ini_file())
    try:
        value = config[section][key]
    except KeyError:
        return ''

    return value


def get_configfile_key_organizations_with_hierarchies() -> DataFrame | None:
    """Get the value of the key 'organizations_with_hierarchies'
    in the Ricgraph config file.

    :return: the value of the key as a DataFrame, or None if absent.
    """
    multi_line_str = get_configfile_key(section='Organization',
                                        key='organizations_with_hierarchies')
    if multi_line_str == '':
        return None

    # Split the multiline string into lines and strip spaces
    lines = multi_line_str.strip().splitlines()

    # Join lines with commas and wrap as a list string
    list_str = "[" + ",".join(line.strip() for line in lines) + "]"

    orgs_with_hierarchies_list = literal_eval(list_str)
    if len(orgs_with_hierarchies_list) <= 1:
        # The first element of the list is the header, so if len <= 1
        # then there is still no data.
        return None
    else:
        headers = orgs_with_hierarchies_list[0]
        rows = orgs_with_hierarchies_list[1:]
        orgs_with_hierarchies = DataFrame(data=rows, columns=headers)
        orgs_with_hierarchies['org_abbreviation'] = orgs_with_hierarchies['org_abbreviation'].str.upper()
        orgs_with_hierarchies['org_fullname'] = orgs_with_hierarchies['org_abbreviation'] + ' ' + orgs_with_hierarchies['org_name']
        orgs_with_hierarchies = orgs_with_hierarchies.drop(columns=['org_name'])

    return orgs_with_hierarchies


def get_configfile_key_graphdb_parameters() -> tuple[str, str, str, str, str]:
    """Get the value of multiple keys in the Ricgraph config file
    that relate to the graph database.

    :return: the value of the graph database parameters, as a python tuple.
    """
    graphdb = get_configfile_key(section='GraphDB', key='graphdb')
    graphdb_hostname = get_configfile_key(section='GraphDB', key='graphdb_hostname')
    graphdb_databasename = get_configfile_key(section='GraphDB', key='graphdb_databasename')
    graphdb_user = get_configfile_key(section='GraphDB', key='graphdb_user')
    graphdb_password = get_configfile_key(section='GraphDB', key='graphdb_password')
    graphdb_scheme = get_configfile_key(section='GraphDB', key='graphdb_scheme')
    graphdb_port = get_configfile_key(section='GraphDB', key='graphdb_port')
    if graphdb == '' or graphdb_hostname == '' or graphdb_databasename == '' \
            or graphdb_user == '' or graphdb_password == '' \
            or graphdb_scheme == '' or graphdb_port == '':
        print('Ricgraph initialization: error, one or more of the GraphDB parameters')
        print('  not existing or empty in Ricgraph ini')
        print('  file "' + get_ricgraph_ini_file() + '", exiting.')
        exit(1)

    graphdb_url = '{scheme}://{hostname}:{port}'.format(scheme=graphdb_scheme,
                                                         hostname=graphdb_hostname,
                                                         port=graphdb_port)
    return graphdb, graphdb_url, graphdb_databasename, graphdb_user, graphdb_password


def get_configfile_key_memcached_parameters() -> tuple[bool, str, int]:
    """Get the value of multiple keys in the Ricgraph config file
    that relate to the Memcached cache.

    :return: the value of the Memcached parameters, as a python tuple.
    """
    memcached_to_be_used_str = get_configfile_key(section='Memcached',
                                                  key='ricgraph_explorer_uses_memcached')
    memcached_host = get_configfile_key(section='Memcached',
                                         key='memcached_host')
    memcached_port_str = get_configfile_key(section='Memcached',
                                        key='memcached_port')

    memcached_to_be_used = False
    if memcached_to_be_used_str == 'True':
        memcached_to_be_used = True
    memcached_port = int(memcached_port_str)

    return memcached_to_be_used, memcached_host, memcached_port


def _json_item_get(json_item: dict, json_path: str,
                   verbose: bool = False) -> str | list | dict | None:
    """Safely retrieve a nested value from a JSON-like structure
    using a string path. Either a str or list return value is expected.

    :param json_item: The JSON item.
    :param json_path: The path to be returned in the JSON item.
    :param verbose: If True, explain what went wrong.
    :return: the value of that path, or None if it does not exist.
    """
    parts = findall(pattern=r"[^\.\[\]]+", string=json_path)
    current_path = []

    try:
        for key in parts:
            current_path.append(key)
            if isinstance(json_item, dict):
                json_item = json_item[key]
            elif isinstance(json_item, list):
                json_item = json_item[int(key)]
            else:
                raise TypeError('Cannot access "' + key
                                + '" (current value type: '
                                + type(json_item).__name__ + ').')

    except (KeyError, IndexError, TypeError, ValueError) as e:
        if verbose:
            print('_json_item_get(): Error parsing json_item, failed at path: "'
                + '.'.join(current_path) + '".')
            print('    json_item: "' + str(json_item) + '".')
            print('    reason: ' + type(e).__name__ + ': ' + str(e))
        return None

    return json_item


def json_item_get_str(json_item: dict, json_path: str,
                      verbose: bool = False) -> str:
    """Safely retrieve a nested value from a JSON-like structure
    using a string path. A str return value is expected.
    Examples:
        json_get_str(data, 'workflow.workflowStep')
        json_get_str(data, 'references[0].title.text[0].value')

    :param json_item: The JSON item.
    :param json_path: The path to be returned in the JSON item.
    :param verbose: If True, explain what went wrong.
    :return: the value of that path, or '' if it does not exist.
    """
    value = _json_item_get(json_item=json_item, json_path=json_path,
                           verbose=verbose)
    if isinstance(value, str):
        return value
    elif isinstance(value, int):
        return str(value)
    else:
        return ''


def json_item_get_list(json_item: dict, json_path: str,
                       verbose: bool = False) -> list:
    """Safely retrieve a nested value from a JSON-like structure
    using a string path. A list return value is expected.
    For examples see json_get_str().

    :param json_item: The JSON item.
    :param json_path: The path to be returned in the JSON item.
    :param verbose: If True, explain what went wrong.
    :return: the value of that path, or [] if it does not exist.
    """
    value = _json_item_get(json_item=json_item, json_path=json_path,
                           verbose=verbose)
    if isinstance(value, list):
        return value
    else:
        return []


def json_item_get_int(json_item: dict, json_path: str) -> int | None:
    """Safely retrieve a nested value from a JSON-like structure
    using a string path. An int return value is expected.
    For examples see json_get_str().

    :param json_item: The JSON item.
    :param json_path: The path to be returned in the JSON item.
    :return: the value of that path, or None if it does not exist.
    """
    value = _json_item_get(json_item=json_item, json_path=json_path)
    if isinstance(value, int):
        return value
    else:
        return None


def json_item_get_dict(json_item: dict, json_path: str) -> dict:
    """Safely retrieve a nested value from a JSON-like structure
    using a string path. A dict return value is expected.
    For examples see json_get_str().

    :param json_item: The JSON item.
    :param json_path: The path to be returned in the JSON item.
    :return: the value of that path, or {} if it does not exist.
    """
    value = _json_item_get(json_item=json_item, json_path=json_path)
    if isinstance(value, dict):
        return value
    else:
        return {}


def json_item_get_bool(json_item: dict, json_path: str) -> bool | None:
    """Safely retrieve a nested value from a JSON-like structure
    using a string path. A bool return value is expected.
    For examples see json_get_str().

    :param json_item: The JSON item.
    :param json_path: The path to be returned in the JSON item.
    :return: the value of that path, or None if it does not exist.
    """
    value = _json_item_get(json_item=json_item, json_path=json_path)
    if isinstance(value, bool):
        return value
    else:
        return None


def print_progress(count: int, now: bool = False, interval: int = 250) -> int:
    """Print the progress according to a counter, for every 'interval'
    counts. Every 10 x interval, a newline will be printed.
    The counter will be increased with 1 on every call, unless now = True.

    :param count: The counter.
    :param now: If True, always print the count.
    :param interval: The interval to print counts.
    :return: if now = False, return 'count' + 1, otherwise return 'count'.
    """
    if now:
        if not (count % (interval * 10) == 0):
            # Only print a newline if we did not do that
            # in the previous iteration.
            print('\n', end='', flush=True)
        print('Done at ' + str(count) + ' (' + timestamp() + ').\n', end='', flush=True)
        return count

    count += 1
    if (count % interval) == 0:
        print(count, ' ', end='', flush=True)
    if (count % (interval * 10)) == 0:
        print('(' + timestamp() + ')\n', end='', flush=True)
    return count
