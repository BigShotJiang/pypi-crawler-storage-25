from oneclickai.YOLO import load_model, predict, draw_result, COCO_CLASS_NAMES
import os
import cv2
import numpy as np

data_path = './public/'
file_img = os.listdir(data_path)

model = load_model("YOLO_coco")

for i in range(5):
    image = cv2.imread(data_path + file_img[i])
    result_annotation = predict(model, image)
    result_image = draw_result(np.array(image), result_annotation, class_names=COCO_CLASS_NAMES)
    cv2.imshow('image', result_image)
    cv2.waitKey(0)

