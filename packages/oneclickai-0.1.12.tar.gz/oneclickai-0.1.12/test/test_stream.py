#%%
from oneclickai.YOLO import stream, load_model

# example usage
model = load_model("./20260422_1224/yolo_model_best.tflite")
# model = load_model("./20260422_1156/yolo_model_best.keras")

# coco dataset cls names
coco_cls_names = ['handcream']

stream(model, conf=0.4, class_names=coco_cls_names, video_source=0)