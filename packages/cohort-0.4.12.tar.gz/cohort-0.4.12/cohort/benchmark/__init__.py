"""Cohort multi-agent orchestration benchmark.

Compares four orchestration strategies on coding tasks:
  1. Single agent (baseline)
  2. Unorchestrated round-robin (3 agents, no scoring)
  3. Hierarchical (1 manager + 2 workers)
  4. Cohort-scored (full 5-dimension scoring pipeline)
"""

from cohort.benchmark.runner import BenchmarkRunner

# Re-export symbols from the legacy benchmark.py module that api.py expects.
# The benchmark/ package shadows the old benchmark.py file, so we need to
# provide these here.
BENCHMARK_ENABLED = True


class _BenchmarkStub:
    """Stub when full BenchmarkRunner can't be instantiated."""
    def __getattr__(self, name):
        """Accept any method call as a no-op."""
        return lambda *a, **kw: None


def get_benchmark_runner(data_dir=None):
    """Return a BenchmarkRunner instance (lazy import to avoid circular deps)."""
    try:
        return BenchmarkRunner()
    except TypeError:
        return _BenchmarkStub()


__all__ = ["BenchmarkRunner", "BENCHMARK_ENABLED", "get_benchmark_runner"]
