"""Benchmark orchestration strategies."""

from cohort.benchmark.strategies.base import Strategy
from cohort.benchmark.strategies.cohort_scored import CohortScored
from cohort.benchmark.strategies.hierarchical import Hierarchical
from cohort.benchmark.strategies.round_robin import RoundRobin
from cohort.benchmark.strategies.single_agent import SingleAgent

ALL_STRATEGIES = [SingleAgent, RoundRobin, Hierarchical, CohortScored]

__all__ = [
    "Strategy",
    "SingleAgent",
    "RoundRobin",
    "Hierarchical",
    "CohortScored",
    "ALL_STRATEGIES",
]
