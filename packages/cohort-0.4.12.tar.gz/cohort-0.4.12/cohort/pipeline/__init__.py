"""cohort.pipeline -- Git-aware, approval-gated task pipeline on top of WorkQueue.

Adds the full SMACK-style lifecycle to Cohort's thin work queue:

    queued -> active -> reviewing -> approved -> applied -> completed
                           |
                           +-> rejected -> (requeue, max 3x)

Extra features over bare WorkQueue:
- Git SHA capture at enqueue time + staleness detection at claim time
- File manifest tracking with automatic dependency detection
- Deliverables gate (acceptance criteria set before execution)
- Self-review report attached at completion
- Requeue with hard cap (default 3)
- Append-only JSONL audit log for every state transition

Context engineering (ported from BOSS SMACK):
- ChannelCondenser: compress channel history into structured JSON summaries
- InlineCondenser: non-destructive in-place message compression with archival
- TaskEnricher: discover sibling deps, dependents, discussion context, file windows
- MemoryDistiller: distil agent memory to query-relevant bullets
"""

from cohort.pipeline.audit_log import AuditLog
from cohort.pipeline.condenser import ChannelCondenser, CondensedContext
from cohort.pipeline.deliverables import (
    Deliverable,
    DeliverableStatus,
    all_met,
    deliverables_ready,
    set_deliverables,
    unmet_deliverables,
    update_deliverable,
)
from cohort.pipeline.enrichment import (
    DependentFile,
    EnrichedContext,
    FileWindow,
    SiblingContract,
    TaskEnricher,
)
from cohort.pipeline.inline_condenser import InlineCondenser, InlineResult
from cohort.pipeline.memory_distiller import MemoryDistiller
from cohort.pipeline.pipeline import PipelineQueue
from cohort.pipeline.pipeline_task import PipelineTask, ReviewStatus, StalenessLevel
from cohort.pipeline.requeue import MAX_REQUEUES, requeue
from cohort.pipeline.self_review import SelfReviewReport, self_review
from cohort.pipeline.staleness import StalenessResult, assess_staleness, capture_sha
from cohort.pipeline.worker import (
    EXECUTOR_API,
    EXECUTOR_CLAUDE_CODE,
    EXECUTOR_OLLAMA,
    PipelineWorker,
    WorkerStatus,
)

__all__ = [
    # Pipeline core
    "PipelineQueue",
    "PipelineTask",
    "ReviewStatus",
    "StalenessLevel",
    "StalenessResult",
    "assess_staleness",
    "capture_sha",
    # Deliverables
    "Deliverable",
    "DeliverableStatus",
    "set_deliverables",
    "update_deliverable",
    "all_met",
    "unmet_deliverables",
    "deliverables_ready",
    # Review
    "SelfReviewReport",
    "self_review",
    # Requeue
    "requeue",
    "MAX_REQUEUES",
    # Audit
    "AuditLog",
    # Worker
    "PipelineWorker",
    "WorkerStatus",
    "EXECUTOR_OLLAMA",
    "EXECUTOR_API",
    "EXECUTOR_CLAUDE_CODE",
    # Context engineering
    "ChannelCondenser",
    "CondensedContext",
    "InlineCondenser",
    "InlineResult",
    "TaskEnricher",
    "EnrichedContext",
    "SiblingContract",
    "DependentFile",
    "FileWindow",
    "MemoryDistiller",
]
