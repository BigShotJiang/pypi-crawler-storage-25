"""MCP tools — Domain Controllers, FSMO roles, EventLog config, NTP."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP
    from legacy_mcp.workspace.workspace import Workspace


def register(mcp: "FastMCP", workspace: "Workspace") -> None:

    @mcp.tool()
    def get_domain_controllers(
        forest_name: str | None = None,
        offset: int = 0,
        limit: int = 100,
    ) -> dict[str, Any]:
        """Return all Domain Controllers in the forest with OS version,
        IP address, GC/RODC status, site, reachability state, LDAP/SSL ports,
        FSMO roles held, and Server Core detection.

        Returns a paginated result: {items, total, offset, limit, has_more}.
        Default limit is 100.
        """
        conn = workspace.connector(forest_name)
        return conn.query_page("dcs", offset=offset, limit=limit)

    @mcp.tool()
    def get_fsmo_roles(forest_name: str | None = None) -> dict[str, Any]:
        """Return the current FSMO role holders:
        Schema Master, Domain Naming Master, PDC Emulator, RID Master,
        Infrastructure Master — per domain."""
        conn = workspace.connector(forest_name)
        return conn.scalar("fsmo_roles") or {}

    @mcp.tool()
    def get_eventlog_config(
        forest_name: str | None = None,
        offset: int = 0,
        limit: int = 100,
    ) -> dict[str, Any]:
        """Return EventLog configuration for each DC: log name, max size, retention,
        and overflow behavior for all enabled logs except Security
        (Security log ACL not delegable without local Administrators).

        Returns a paginated result: {items, total, offset, limit, has_more}.
        Default limit is 100 (5 DCs x 3 logs = 15 rows in a typical domain;
        up to 600 in a large forest).
        """
        conn = workspace.connector(forest_name)
        return conn.query_page("eventlog_config", offset=offset, limit=limit)

    @mcp.tool()
    def get_ntp_config(
        forest_name: str | None = None,
        offset: int = 0,
        limit: int = 100,
    ) -> dict[str, Any]:
        """Return NTP configuration from the registry of each DC:
        NtpServer, Type, AnnounceFlags, poll intervals, VMICTimeProvider state,
        and current time source (w32tm /query /source) -- retrieved per-DC via WinRM.

        Returns a paginated result: {items, total, offset, limit, has_more}.
        Default limit is 100.
        """
        conn = workspace.connector(forest_name)
        return conn.query_page("ntp_config", offset=offset, limit=limit)

    @mcp.tool()
    def get_dc_features(
        forest_name: str | None = None,
        dc_name: str | None = None,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return installed Windows Server roles for each Domain Controller.
        Each item contains the DC hostname, status, and a nested list of
        installed roles (name, display_name).

        Use dc_name to filter results to a specific Domain Controller.
        Returns a paginated result: {items, total, offset, limit, has_more}.
        Default limit is 50 (one entry per DC with nested role list).
        """
        conn = workspace.connector(forest_name)
        if dc_name:
            all_items = conn.query("dc_windows_features")
            items = [i for i in all_items if i.get("DC", "").lower() == dc_name.lower()]
            total = len(items)
            sliced = items[offset: offset + limit]
            has_more = (offset + limit) < total
            result: dict[str, Any] = {
                "items": sliced, "total": total,
                "offset": offset, "limit": limit, "has_more": has_more,
            }
            if len(all_items) == 0:
                result["_note"] = "data not available \u2014 collector < v1.6"
            return result
        result = conn.query_page("dc_windows_features", offset=offset, limit=limit)
        if result["total"] == 0:
            result["_note"] = "data not available \u2014 collector < v1.6"
        return result

    @mcp.tool()
    def get_dc_services(
        forest_name: str | None = None,
        dc_name: str | None = None,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return services that are Running or have Startup Type Auto
        for each Domain Controller. Covers: what is currently running,
        and what is configured to start automatically.

        Use dc_name to filter results to a specific Domain Controller.
        Returns a paginated result: {items, total, offset, limit, has_more}.
        Default limit is 50.
        """
        conn = workspace.connector(forest_name)
        if dc_name:
            all_items = conn.query("dc_services")
            items = [i for i in all_items if i.get("DC", "").lower() == dc_name.lower()]
            total = len(items)
            sliced = items[offset: offset + limit]
            has_more = (offset + limit) < total
            result = {
                "items": sliced, "total": total,
                "offset": offset, "limit": limit, "has_more": has_more,
            }
            if len(all_items) == 0:
                result["_note"] = "data not available \u2014 collector < v1.6"
            return result
        result = conn.query_page("dc_services", offset=offset, limit=limit)
        if result["total"] == 0:
            result["_note"] = "data not available \u2014 collector < v1.6"
        return result

    @mcp.tool()
    def get_dc_software(
        forest_name: str | None = None,
        dc_name: str | None = None,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return installed software from the registry of each Domain Controller.
        Each item contains the DC hostname, status, and a nested list of
        installed software (name, version, vendor, install_date).

        Note: registry data may include stale entries from incomplete uninstalls.
        Use dc_name to filter results to a specific Domain Controller.
        Returns a paginated result: {items, total, offset, limit, has_more}.
        Default limit is 50.
        """
        conn = workspace.connector(forest_name)
        if dc_name:
            all_items = conn.query("dc_installed_software")
            items = [i for i in all_items if i.get("DC", "").lower() == dc_name.lower()]
            total = len(items)
            sliced = items[offset: offset + limit]
            has_more = (offset + limit) < total
            result = {
                "items": sliced, "total": total,
                "offset": offset, "limit": limit, "has_more": has_more,
            }
            if len(all_items) == 0:
                result["_note"] = "data not available \u2014 collector < v1.6"
            return result
        result = conn.query_page("dc_installed_software", offset=offset, limit=limit)
        if result["total"] == 0:
            result["_note"] = "data not available \u2014 collector < v1.6"
        return result

    @mcp.tool()
    def get_dc_file_locations(
        forest_name: str | None = None,
        dc_name: str | None = None,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return AD database file locations for each Domain Controller:
        NTDS database path, log files path, and SYSVOL path -- read from
        the registry via WinRM (Remote Management Users sufficient).

        Note: DIT file size is not reported -- requires local Administrators.
        Use dc_name to filter results to a specific Domain Controller.
        Returns a paginated result: {items, total, offset, limit, has_more}.
        """
        conn = workspace.connector(forest_name)
        if dc_name:
            all_items = conn.query("dc_file_locations")
            items = [i for i in all_items if i.get("DC", "").lower() == dc_name.lower()]
            total = len(items)
            sliced = items[offset: offset + limit]
            has_more = (offset + limit) < total
            return {
                "items": sliced, "total": total,
                "offset": offset, "limit": limit, "has_more": has_more,
            }
        return conn.query_page("dc_file_locations", offset=offset, limit=limit)

    @mcp.tool()
    def get_dc_network_config(
        forest_name: str | None = None,
        dc_name: str | None = None,
        offset: int = 0,
        limit: int = 50,
    ) -> dict[str, Any]:
        """Return network adapter configuration for each Domain Controller:
        IP addresses (IPv4 and IPv6), DNS server IPs, default gateway,
        and DHCP status -- per IP-enabled adapter.

        Field-tested on WS2012R2 with Remote Management Users (POLP-safe).
        Use dc_name to filter results to a specific Domain Controller.
        Returns a paginated result: {items, total, offset, limit, has_more}.
        """
        conn = workspace.connector(forest_name)
        if dc_name:
            all_items = conn.query("dc_network_config")
            items = [i for i in all_items if i.get("DC", "").lower() == dc_name.lower()]
            total = len(items)
            sliced = items[offset: offset + limit]
            has_more = (offset + limit) < total
            return {
                "items": sliced, "total": total,
                "offset": offset, "limit": limit, "has_more": has_more,
            }
        return conn.query_page("dc_network_config", offset=offset, limit=limit)
