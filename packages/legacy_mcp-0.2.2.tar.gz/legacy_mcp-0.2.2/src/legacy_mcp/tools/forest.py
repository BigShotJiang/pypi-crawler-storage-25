"""MCP tools — Forest and AD Schema."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP
    from legacy_mcp.workspace.workspace import Workspace


def register(mcp: "FastMCP", workspace: "Workspace") -> None:

    @mcp.tool()
    def get_forest_info(forest_name: str | None = None) -> dict[str, Any]:
        """Return forest-level information: name, functional level, schema version,
        FSMO roles (SchemaMaster, DomainNamingMaster), sites, domains, global catalogs,
        SPN suffixes, UPN suffixes, application partitions, and tombstone lifetime."""
        conn = workspace.connector(forest_name)
        result = conn.scalar("forest")
        return result or {}

    @mcp.tool()
    def get_optional_features(forest_name: str | None = None) -> list[dict[str, Any]]:
        """Return the list of optional AD features and their enabled state
        (e.g. Recycle Bin, Privileged Access Management)."""
        conn = workspace.connector(forest_name)
        return conn.query("optional_features")

    @mcp.tool()
    def get_schema_extensions(
        forest_name: str | None = None,
        offset: int = 0,
        limit: int = 200,
    ) -> dict[str, Any]:
        """Return custom schema classes and attributes added to the AD schema
        beyond the default Microsoft base schema.

        Returns a paginated result: {items, total, offset, limit, has_more}.
        Default limit is 200. The collector caps collection at 500 objects.
        """
        conn = workspace.connector(forest_name)
        return conn.query_page("schema", offset=offset, limit=limit)

    @mcp.tool()
    def get_schema_product_presence(forest_name: str | None = None) -> dict[str, Any]:
        """Return schema-based product presence detection for the forest.
        Checks for LAPS (legacy and Windows), Exchange, SCCM/ConfigMgr,
        Lync/Skype for Business, and Azure AD Connect schema extensions.

        Returns a dict with boolean values for each product.
        """
        conn = workspace.connector(forest_name)
        result = conn.scalar("schema_products")
        return result or {}
