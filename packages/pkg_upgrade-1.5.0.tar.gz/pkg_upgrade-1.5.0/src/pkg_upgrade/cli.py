from __future__ import annotations

import argparse
import asyncio
import sys
from datetime import date
from pathlib import Path
from typing import Any

from pkg_upgrade import __version__
from pkg_upgrade.config import (
    DEFAULT_CONFIG,
    config_exists,
    load_config_dict,
    save_config,
)
from pkg_upgrade.self_update import run_self_update
from pkg_upgrade.ui import select_dashboard, select_onboarding


def build_parser() -> argparse.ArgumentParser:
    """Build and return the argument parser (extracted for testability)."""
    parser = argparse.ArgumentParser(
        prog="pkg-upgrade",
        description="Cross-platform TUI that upgrades every package manager on your system",
    )
    parser.add_argument(
        "--skip", type=lambda s: set(s.split(",")), default=None, metavar="MANAGERS"
    )
    parser.add_argument(
        "--only", type=lambda s: set(s.split(",")), default=None, metavar="MANAGERS"
    )
    parser.add_argument("--yes", "-y", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--no-notify", action="store_true")
    parser.add_argument("--no-log", action="store_true")
    parser.add_argument("--log-dir", type=str, default=None, metavar="PATH")
    parser.add_argument("--list", action="store_true", dest="list_managers")
    parser.add_argument(
        "--plain",
        action="store_true",
        help="With --list, print bare manager keys (one per line) for shell completion.",
    )
    parser.add_argument(
        "--onboard",
        action="store_true",
        help="Run the configuration wizard and exit",
    )
    parser.add_argument(
        "--show-graph",
        action="store_true",
        help="Print execution plan (topo-sorted groups) and exit",
    )
    parser.add_argument(
        "--max-parallel",
        type=int,
        default=None,
        metavar="N",
        help="Cap per-level concurrency",
    )
    parser.add_argument("--version", action="version", version=f"pkg-upgrade {__version__}")
    parser.add_argument(
        "--self-update",
        dest="self_update",
        action="store_true",
        help="Upgrade pkg-upgrade itself",
    )
    subparsers = parser.add_subparsers(dest="subcommand")
    comp = subparsers.add_parser("completion", help="Print shell completion script")
    comp.add_argument("shell", choices=["bash", "zsh", "fish", "powershell"])
    return parser


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    return build_parser().parse_args(argv)


def get_log_path(log_enabled: bool, log_dir: str | None) -> str | None:
    if not log_enabled:
        return None
    base = Path(log_dir).expanduser() if log_dir else Path.home()
    today = date.today().isoformat()
    return str(base / f"pkg-upgrade-{today}.log")


def resolve_settings(args: argparse.Namespace, cfg: dict[str, Any]) -> dict[str, Any]:
    """Merge CLI flags with config — flags always win."""
    cfg_managers = set(cfg.get("managers") or DEFAULT_CONFIG["managers"])

    effective = cfg_managers & args.only if args.only is not None else set(cfg_managers)
    if args.skip:
        effective -= args.skip

    auto_yes = bool(cfg.get("auto_yes", False)) or args.yes
    notify = bool(cfg.get("notify", True)) and not args.no_notify
    log_enabled = bool(cfg.get("log", True)) and not args.no_log
    log_dir = args.log_dir if args.log_dir is not None else cfg.get("log_dir")

    return {
        "only": effective if args.only is not None else None,
        "skip": args.skip,
        "managers": effective,
        "auto_yes": auto_yes,
        "notify": notify,
        "log_path": get_log_path(log_enabled, log_dir),
        "dry_run": args.dry_run,
        "list_only": args.list_managers,
    }


def _print_list(skip: set[str] | None = None, only: set[str] | None = None) -> int:
    """Print managers grouped by Available / Unavailable / Not on this OS."""
    from pkg_upgrade.platform import current_os  # noqa: PLC0415
    from pkg_upgrade.registry import (  # noqa: PLC0415
        all_registered,
        discover_managers,
        select_managers,
    )

    on_os = discover_managers(load_entry_points=False, load_declarative=True)
    on_os_filtered = select_managers(on_os, skip=skip, only=only)
    on_os_keys = {m.key for m in on_os}
    all_classes = all_registered()
    cur = current_os()

    async def _probe() -> list[tuple[Any, bool]]:
        return [(m, await m.is_available()) for m in on_os_filtered]

    probed = asyncio.run(_probe())
    available = [m for m, ok in probed if ok]
    unavailable = [m for m, ok in probed if not ok]
    other_os = [c for c in all_classes if c.key not in on_os_keys]

    print("Available:")
    for m in available:
        print(f"  {m.icon} {m.key} — {m.name}")
    print()
    print("Unavailable (declared for this OS, binary missing):")
    for m in unavailable:
        hint = f"  hint: {m.install_hint}" if m.install_hint else ""
        print(f"  {m.icon} {m.key} — {m.name}{hint}")
    print()
    print(f"Not on this OS ({cur}):")
    for c in other_os:
        plats = ",".join(sorted(c.platforms))
        print(f"  {c.icon} {c.key} — {c.name} [{plats}]")
    return 0


def _print_graph(skip: set[str] | None = None, only: set[str] | None = None) -> int:
    """Print the topo-sorted execution plan and exit."""
    from pkg_upgrade.executor import Executor  # noqa: PLC0415
    from pkg_upgrade.registry import discover_managers, select_managers  # noqa: PLC0415

    managers = discover_managers(load_entry_points=False, load_declarative=True)
    managers = select_managers(managers, skip=skip, only=only)
    ex = Executor.from_managers(managers)
    for i, group in enumerate(ex.groups):
        keys = ", ".join(m.key for m in group.managers)
        print(f"Level {i}: {keys}")
    return 0


def _handle_list(args: argparse.Namespace) -> int:
    """Dispatch `--list` to either the grouped view or the plain completion view."""
    if args.plain:
        from pkg_upgrade.completion import plain_list_managers  # noqa: PLC0415

        for key in plain_list_managers(write_cache=True):
            print(key)
        return 0
    return _print_list(skip=args.skip, only=args.only)


def main() -> int:  # noqa: PLR0911, PLR0912
    args = parse_args()

    if args.subcommand == "completion":
        from pkg_upgrade.completion import completion_subcommand  # noqa: PLC0415

        return completion_subcommand(args.shell)

    if args.self_update:
        return run_self_update()

    if args.onboard:
        ob = select_onboarding()
        if ob is None:
            print(
                "error: onboarding requires an interactive terminal."
                " Re-run in a TTY, or create ~/.mac-upgrade manually.",
                file=sys.stderr,
            )
            return 2
        existing, _ = load_config_dict() if config_exists() else (dict(DEFAULT_CONFIG), None)
        saved = ob.run(existing)
        if saved is None:
            print("Onboarding cancelled — no changes written.")
            return 0
        save_config(saved)
        print(f"Saved configuration to {Path.home() / '.mac-upgrade'}")
        return 0

    if args.list_managers:
        return _handle_list(args)

    if args.show_graph:
        return _print_graph(skip=args.skip, only=args.only)

    if "--version" in sys.argv:
        cfg = DEFAULT_CONFIG
        warning = None
    elif not config_exists():
        ob = select_onboarding()
        if ob is None:
            print(
                "error: onboarding requires an interactive terminal."
                " Re-run in a TTY, or create ~/.mac-upgrade manually.",
                file=sys.stderr,
            )
            return 2
        saved = ob.run(dict(DEFAULT_CONFIG))
        if saved is None:
            print("Onboarding cancelled — exiting.")
            return 0
        save_config(saved)
        cfg = saved
        warning = None
    else:
        cfg, warning = load_config_dict()

    if warning:
        print(f"warning: {warning}", file=sys.stderr)

    settings = resolve_settings(args, cfg)

    from pkg_upgrade.executor import Executor  # noqa: PLC0415
    from pkg_upgrade.registry import discover_managers, select_managers  # noqa: PLC0415

    managers = discover_managers(load_entry_points=False, load_declarative=True)
    managers = select_managers(managers, skip=settings["skip"], only=settings["only"])
    executor = Executor.from_managers(managers)
    if args.max_parallel is not None:
        executor.set_max_parallel(args.max_parallel)
    ui = select_dashboard()
    asyncio.run(ui.run(executor, auto_yes=settings["auto_yes"], dry_run=settings["dry_run"]))
    return 0
