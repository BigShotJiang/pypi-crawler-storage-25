"""Retry interceptor — exponential backoff for transient LLM failures."""

from __future__ import annotations

import time
import random
from typing import Any, Callable, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from maev.runner import AgentRun

_RETRYABLE_STATUS_CODES = {429, 500, 502, 503, 504}

_MAX_ATTEMPTS = 3
_BASE_DELAY_S = 1.0
_MAX_DELAY_S = 30.0
_JITTER_FACTOR = 0.25


def is_retryable(exc: Exception) -> bool:
    """Return True if this exception warrants a retry."""
    name = type(exc).__name__

    if name in (
        "RateLimitError",
        "APIConnectionError",
        "APITimeoutError",
        "InternalServerError",
        "ServiceUnavailableError",
        "OverloadedError",
        "Timeout",
        "ConnectionError",
    ):
        return True

    status = getattr(exc, "status_code", None) or getattr(exc, "status", None)
    if isinstance(status, int) and status in _RETRYABLE_STATUS_CODES:
        return True

    return False


def is_rate_limit(exc: Exception) -> bool:
    name = type(exc).__name__
    return name == "RateLimitError" or getattr(exc, "status_code", None) == 429


def backoff_delay(attempt: int, is_rate_limit_err: bool = False) -> float:
    base = _BASE_DELAY_S * (2 ** (attempt - 1))
    if is_rate_limit_err:
        base = max(base, 2.0)
    jitter = base * _JITTER_FACTOR * random.random()
    return min(base + jitter, _MAX_DELAY_S)


def retry_call(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    run: Optional["AgentRun"] = None,
    max_attempts: int = _MAX_ATTEMPTS,
) -> Any:
    """Execute fn with automatic retry on transient errors."""
    last_exc: Optional[Exception] = None

    for attempt in range(1, max_attempts + 1):
        try:
            result = fn(*args, **kwargs)

            # Detect empty/null text responses — but only retry if the response
            # genuinely has no useful content (not tool_use or other valid types)
            if _is_empty_text_response(result) and attempt < max_attempts:
                kwargs = _bump_temperature(kwargs)
                if run:
                    run.record_intervention(
                        type="retry",
                        trigger="empty_response",
                        strategy="temp_increase",
                        outcome="pending",
                    )
                continue

            if run and attempt > 1:
                run.record_intervention(
                    type="retry",
                    trigger=type(last_exc).__name__ if last_exc else "empty_response",
                    strategy="exponential_backoff",
                    outcome="success",
                )
            return result

        except Exception as exc:
            last_exc = exc
            if not is_retryable(exc) or attempt == max_attempts:
                raise

            delay = backoff_delay(attempt, is_rate_limit_err=is_rate_limit(exc))
            if run:
                run.record_intervention(
                    type="retry",
                    trigger=type(exc).__name__,
                    strategy=f"backoff_{delay:.1f}s",
                    outcome="pending",
                )
            time.sleep(delay)

    raise last_exc  # type: ignore[misc]


async def retry_call_async(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    run: Optional["AgentRun"] = None,
    max_attempts: int = _MAX_ATTEMPTS,
) -> Any:
    """Async version of retry_call."""
    import asyncio

    last_exc: Optional[Exception] = None

    for attempt in range(1, max_attempts + 1):
        try:
            result = await fn(*args, **kwargs)

            if _is_empty_text_response(result) and attempt < max_attempts:
                kwargs = _bump_temperature(kwargs)
                if run:
                    run.record_intervention(
                        type="retry",
                        trigger="empty_response",
                        strategy="temp_increase",
                        outcome="pending",
                    )
                continue

            if run and attempt > 1:
                run.record_intervention(
                    type="retry",
                    trigger=type(last_exc).__name__ if last_exc else "empty_response",
                    strategy="exponential_backoff",
                    outcome="success",
                )
            return result

        except Exception as exc:
            last_exc = exc
            if not is_retryable(exc) or attempt == max_attempts:
                raise

            delay = backoff_delay(attempt, is_rate_limit_err=is_rate_limit(exc))
            if run:
                run.record_intervention(
                    type="retry",
                    trigger=type(exc).__name__,
                    strategy=f"backoff_{delay:.1f}s",
                    outcome="pending",
                )
            await asyncio.sleep(delay)

    raise last_exc  # type: ignore[misc]


def _is_empty_text_response(result: Any) -> bool:
    """Detect empty/null LLM text responses.

    Returns False for valid non-text responses (tool_use, function_call)
    so we don't retry an agent that legitimately called a tool.
    """
    if result is None:
        return True

    # OpenAI ChatCompletion
    choices = getattr(result, "choices", None)
    if choices is not None:
        if not choices:
            return True
        choice = choices[0]
        message = getattr(choice, "message", None)
        if message is None:
            return True
        # If there's a tool_call or function_call, the response is valid
        if getattr(message, "tool_calls", None):
            return False
        if getattr(message, "function_call", None):
            return False
        content = getattr(message, "content", None)
        return content is None or (isinstance(content, str) and not content.strip())

    # Anthropic Message
    content = getattr(result, "content", None)
    if isinstance(content, list):
        if not content:
            return True
        # If any block is tool_use, the response is valid
        for block in content:
            block_type = getattr(block, "type", None) or (
                block.get("type") if isinstance(block, dict) else None
            )
            if block_type == "tool_use":
                return False
        # Check if all text blocks are empty
        text_blocks = [
            b for b in content
            if (getattr(b, "type", None) or (b.get("type") if isinstance(b, dict) else None)) == "text"
        ]
        if not text_blocks:
            return True
        for block in text_blocks:
            text = getattr(block, "text", None) or (
                block.get("text") if isinstance(block, dict) else None
            )
            if text and str(text).strip():
                return False
        return True

    return False


def _bump_temperature(kwargs: dict) -> dict:
    """Slightly increase temperature to escape degenerate outputs.

    If temperature is None (provider default), we start from 0.7 and nudge up.
    If temperature is already set, we nudge up from there.
    """
    updated = dict(kwargs)
    current = updated.get("temperature")
    if current is None:
        # Provider default — start at 0.7 and nudge
        updated["temperature"] = 0.8
    else:
        updated["temperature"] = min(float(current) + 0.1, 1.0)
    return updated
