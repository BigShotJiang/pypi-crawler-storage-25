"""Circuit breaker interceptor — cost, call count, and duration guards."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from maev.runner import AgentRun


class CircuitBrokenError(RuntimeError):
    """Raised when a circuit breaker trips."""

    def __init__(self, reason: str, details: str = "") -> None:
        self.reason = reason
        self.details = details
        super().__init__(f"[maev] Circuit broken — {reason}. {details}".strip())


def check_cost(run: "AgentRun") -> None:
    """Raise CircuitBrokenError if the run has exceeded its cost budget."""
    if run.config.cost_budget <= 0:
        return
    if run.cost_accumulated >= run.config.cost_budget:
        run.record_intervention(
            type="circuit_break",
            trigger="cost_exceeded",
            strategy="halt",
            outcome="success",
        )
        raise CircuitBrokenError(
            "cost budget exceeded",
            f"spent ${run.cost_accumulated:.4f} of ${run.config.cost_budget:.2f} budget",
        )


def check_call_count(run: "AgentRun") -> None:
    """Raise CircuitBrokenError if the run has made too many LLM calls."""
    if run.call_count >= run.config.max_calls:
        run.record_intervention(
            type="circuit_break",
            trigger="call_count_exceeded",
            strategy="halt",
            outcome="success",
        )
        raise CircuitBrokenError(
            "max LLM call limit reached",
            f"made {run.call_count} calls (limit: {run.config.max_calls})",
        )


def check_duration(run: "AgentRun") -> None:
    """Raise CircuitBrokenError if the run has exceeded its time budget."""
    if run.config.max_duration_s <= 0:
        return
    elapsed = time.time() - run.started_at
    if elapsed >= run.config.max_duration_s:
        run.record_intervention(
            type="circuit_break",
            trigger="duration_exceeded",
            strategy="halt",
            outcome="success",
        )
        raise CircuitBrokenError(
            "max duration exceeded",
            f"ran for {elapsed:.0f}s (limit: {run.config.max_duration_s:.0f}s)",
        )


def extract_call_cost(result: object) -> float:
    """Best-effort extraction of cost from an LLM response object."""
    # OpenAI usage object
    usage = getattr(result, "usage", None)
    if usage is not None:
        total_tokens = getattr(usage, "total_tokens", 0) or 0
        # Rough estimate: $0.000003 per token (gpt-4o-mini ballpark)
        # Real cost tracking comes from OpenLIT spans
        return total_tokens * 0.000003
    return 0.0
