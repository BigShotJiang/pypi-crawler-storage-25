"""Loop detector — catches agents repeating the same prompt in a tight loop."""

from __future__ import annotations

import hashlib
from collections import deque
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from maev.runner import AgentRun

_LOOP_WINDOW = 20      # how many recent prompt hashes to keep (matches AgentRun.prompt_hashes maxlen)
_LOOP_THRESHOLD = 3    # if same hash appears this many times in the window → loop


class LoopDetectedError(RuntimeError):
    """Raised when an agent appears to be stuck in a loop."""

    def __init__(self, prompt_hash: str, count: int) -> None:
        self.prompt_hash = prompt_hash
        self.count = count
        super().__init__(
            f"[maev] Infinite loop detected — same prompt repeated {count}x. "
            "Agent execution halted."
        )


def hash_messages(messages: Any) -> str:
    """Compute a stable, collision-resistant hash of an LLM messages list.

    Uses the full message content (no truncation) to avoid false positives
    where two different long prompts have the same first 200 chars.
    Returns 32 hex chars (128 bits) — negligible collision probability.
    """
    try:
        if isinstance(messages, (list, tuple)):
            parts = []
            for m in messages:
                if isinstance(m, dict):
                    role = m.get("role", "?")
                    content = m.get("content", "")
                    # Handle list content (Anthropic multi-block format)
                    if isinstance(content, list):
                        content_str = "|".join(
                            str(block.get("text", "") if isinstance(block, dict) else block)
                            for block in content
                        )
                    else:
                        content_str = str(content)
                    parts.append(f"{role}:{content_str}")
                else:
                    # OpenAI/Anthropic message objects
                    role = getattr(m, "role", "?")
                    content = getattr(m, "content", "")
                    if isinstance(content, list):
                        content_str = "|".join(
                            str(getattr(b, "text", b) if not isinstance(b, dict) else b.get("text", ""))
                            for b in content
                        )
                    else:
                        content_str = str(content) if content is not None else ""
                    parts.append(f"{role}:{content_str}")
            canonical = "||".join(parts)
        else:
            canonical = str(messages)

        return hashlib.sha256(canonical.encode()).hexdigest()[:32]  # 128 bits
    except Exception:  # noqa: BLE001
        return "unknown"


def check_loop(run: "AgentRun", prompt_hash: str) -> None:
    """Raise LoopDetectedError if the same prompt has appeared too many times
    in the recent window."""
    run.prompt_hashes.append(prompt_hash)

    # Count occurrences in the full window
    window = list(run.prompt_hashes)
    count = window.count(prompt_hash)

    if count >= _LOOP_THRESHOLD:
        run.record_intervention(
            type="loop_break",
            trigger="repeated_prompt",
            strategy="halt",
            outcome="success",
        )
        raise LoopDetectedError(prompt_hash, count)
