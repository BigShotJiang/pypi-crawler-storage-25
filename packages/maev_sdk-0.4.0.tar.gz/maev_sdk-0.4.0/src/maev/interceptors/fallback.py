"""Model fallback interceptor — routes to alternative models on failure."""

from __future__ import annotations

import sys
from typing import Any, Callable, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from maev.runner import AgentRun


class AllFallbacksExhaustedError(RuntimeError):
    """Raised when all fallback models have been tried and failed."""

    def __init__(self, models: List[str]) -> None:
        super().__init__(
            f"[maev] All fallback models exhausted: {', '.join(models)}. "
            "Agent execution failed."
        )


def _dedup_fallbacks(original_model: str, fallbacks: List[str]) -> List[str]:
    """Return fallback list with duplicates removed and original model excluded."""
    seen = {original_model}
    result = []
    for m in fallbacks:
        if m not in seen:
            seen.add(m)
            result.append(m)
    return result


def try_with_fallbacks(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    exc: Exception,
    run: "AgentRun",
) -> Any:
    """Try calling fn with each fallback model in order.

    Returns on first success. Raises AllFallbacksExhaustedError if all fail.
    """
    fallbacks = run.config.fallback_models
    if not fallbacks:
        raise exc

    original_model = kwargs.get("model", "unknown")
    deduped = _dedup_fallbacks(original_model, fallbacks)
    tried = [original_model]

    for model in deduped:
        tried.append(model)
        updated_kwargs = {**kwargs, "model": model}

        try:
            print(
                f"[maev] Primary model '{original_model}' failed ({type(exc).__name__}). "
                f"Trying fallback: '{model}'",
                file=sys.stderr,
            )
            result = fn(*args, **updated_kwargs)
            run.record_intervention(
                type="fallback",
                trigger=type(exc).__name__,
                strategy=f"model_fallback_{model}",
                outcome="success",
            )
            return result
        except Exception as fallback_exc:  # noqa: BLE001
            print(
                f"[maev] Fallback model '{model}' also failed: {fallback_exc}",
                file=sys.stderr,
            )
            run.record_intervention(
                type="fallback",
                trigger=type(exc).__name__,
                strategy=f"model_fallback_{model}",
                outcome="failure",
            )
            exc = fallback_exc

    raise AllFallbacksExhaustedError(tried)


async def try_with_fallbacks_async(
    fn: Callable,
    args: tuple,
    kwargs: dict,
    exc: Exception,
    run: "AgentRun",
) -> Any:
    """Async version of try_with_fallbacks."""
    fallbacks = run.config.fallback_models
    if not fallbacks:
        raise exc

    original_model = kwargs.get("model", "unknown")
    deduped = _dedup_fallbacks(original_model, fallbacks)
    tried = [original_model]

    for model in deduped:
        tried.append(model)
        updated_kwargs = {**kwargs, "model": model}

        try:
            print(
                f"[maev] Primary model '{original_model}' failed ({type(exc).__name__}). "
                f"Trying fallback: '{model}'",
                file=sys.stderr,
            )
            result = await fn(*args, **updated_kwargs)
            run.record_intervention(
                type="fallback",
                trigger=type(exc).__name__,
                strategy=f"model_fallback_{model}",
                outcome="success",
            )
            return result
        except Exception as fallback_exc:  # noqa: BLE001
            print(
                f"[maev] Fallback model '{model}' also failed: {fallback_exc}",
                file=sys.stderr,
            )
            run.record_intervention(
                type="fallback",
                trigger=type(exc).__name__,
                strategy=f"model_fallback_{model}",
                outcome="failure",
            )
            exc = fallback_exc

    raise AllFallbacksExhaustedError(tried)
