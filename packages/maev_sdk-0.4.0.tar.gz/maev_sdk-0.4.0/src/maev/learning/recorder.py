"""Call outcome recorder — the atom of the learning loop.

Every LLM call that goes through Maev is recorded here:
  (prompt_hash, model, failure_type, recovery_strategy, recovery_outcome)

These records are batched and flushed async to the Maev backend, where
they are aggregated server-side into the strategy store.
"""

from __future__ import annotations

import atexit
import hashlib
import sys
import threading
import time
from typing import Any, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from maev.runner import AgentRun

_FLUSH_INTERVAL_S = 10.0
_BATCH_SIZE = 50
_FLUSH_TIMEOUT_S = 5.0   # how long to wait for final flush on process exit

_pending: List[dict] = []
_lock = threading.Lock()
_flush_thread_started = False
_flush_thread: Optional[threading.Thread] = None
_exit_flush_registered = False


def record_call(
    run: Optional["AgentRun"],
    kwargs: dict,
    result: Any,
    status: str,
    failure_type: Optional[str],
    recovery_strategy: Optional[str],   # strategy name applied to recover this call
    recovery_outcome: Optional[str],     # "success" | "failure" | None
    latency_ms: int,
    cost_usd: float,
) -> None:
    """Buffer a call record for async flush. Never blocks the call path."""
    if run is None:
        return

    try:
        messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        tool_count = len(kwargs.get("tools", []) or kwargs.get("functions", []) or [])

        record = {
            "run_id": run.run_id,
            "agent_name": run.config.agent_name,
            "prompt_hash": _hash_messages(messages),
            "prompt_length": _count_tokens_approx(messages),
            "model": model,
            "tool_count": tool_count,
            "turn_number": run.call_count,
            "status": status,
            "failure_type": failure_type,
            "latency_ms": latency_ms,
            "cost_usd": cost_usd,
            "recovery_strategy": recovery_strategy,
            "recovery_outcome": recovery_outcome,
        }

        with _lock:
            _pending.append(record)
            should_flush = len(_pending) >= _BATCH_SIZE

        if should_flush:
            _trigger_flush(run.config)

        _ensure_flush_thread(run.config)
        _ensure_exit_flush(run.config)

    except Exception:  # noqa: BLE001
        pass  # Learning is best-effort, never crash the agent


def _hash_messages(messages: Any) -> str:
    """Privacy-safe hash of the messages list."""
    try:
        if isinstance(messages, (list, tuple)):
            canonical = "|".join(
                f"{m.get('role','?')}:{str(m.get('content',''))[:200]}"
                if isinstance(m, dict)
                else str(m)[:200]
                for m in messages
            )
        else:
            canonical = str(messages)[:500]
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]
    except Exception:  # noqa: BLE001
        return "unknown"


def _count_tokens_approx(messages: Any) -> int:
    """Rough token count — 4 chars per token heuristic."""
    try:
        if isinstance(messages, (list, tuple)):
            total = sum(
                len(str(m.get("content", ""))) if isinstance(m, dict) else len(str(m))
                for m in messages
            )
            return total // 4
        return len(str(messages)) // 4
    except Exception:  # noqa: BLE001
        return 0


def _ensure_flush_thread(config: Any) -> None:
    global _flush_thread_started, _flush_thread  # noqa: PLW0603

    with _lock:
        if _flush_thread_started:
            return
        _flush_thread_started = True

    t = threading.Thread(target=_flush_loop, args=(config,), daemon=True)
    t.start()
    _flush_thread = t


def _ensure_exit_flush(config: Any) -> None:
    """Register a one-time atexit handler to flush pending records on exit."""
    global _exit_flush_registered  # noqa: PLW0603

    with _lock:
        if _exit_flush_registered:
            return
        _exit_flush_registered = True

    def _on_exit() -> None:
        """Flush remaining records synchronously before the process exits."""
        with _lock:
            if not _pending:
                return
            batch = list(_pending)
            _pending.clear()

        _send_records(config, batch)  # synchronous — blocks until done or timeout

    atexit.register(_on_exit)


def _flush_loop(config: Any) -> None:
    while True:
        time.sleep(_FLUSH_INTERVAL_S)
        _trigger_flush(config)


def _trigger_flush(config: Any) -> None:
    with _lock:
        if not _pending:
            return
        batch = list(_pending)
        _pending.clear()

    # Non-daemon so it completes even if main thread is exiting
    t = threading.Thread(target=_send_records, args=(config, batch), daemon=False)
    t.start()


def _send_records(config: Any, records: List[dict]) -> None:
    import json
    import urllib.request

    try:
        data = json.dumps({"records": records}).encode("utf-8")
        req = urllib.request.Request(
            f"{config.endpoint}/api/autopilot/record",
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-api-key": config.api_key,
            },
            method="POST",
        )
        urllib.request.urlopen(req, timeout=_FLUSH_TIMEOUT_S)
    except Exception as exc:  # noqa: BLE001
        print(f"[maev] Learning flush failed (non-fatal): {exc}", file=sys.stderr)
