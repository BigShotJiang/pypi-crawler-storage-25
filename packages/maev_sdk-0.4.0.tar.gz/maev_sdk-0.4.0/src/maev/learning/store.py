"""Strategy store — local in-memory cache of learned recovery strategies.

Fetched from the Maev backend at maev.run() time (once per process).
Refreshed every REFRESH_INTERVAL_S in a background thread so long-running
processes (servers, containers) pick up newly learned strategies.

Zero latency at call time — all lookups are in-memory dict reads.
Scope priority: agent > org > global
"""

from __future__ import annotations

import sys
import threading
import time
from typing import Any, Dict, List, Optional

from maev.types import RunConfig, Strategy

_strategies: List[Strategy] = []
_loaded = False
_lock = threading.Lock()
_refresh_thread_started = False

# Refresh interval — re-fetch strategies every 30 minutes so long-running
# processes pick up strategies learned since boot.
REFRESH_INTERVAL_S = 30 * 60  # 30 minutes


def load(config: RunConfig) -> None:
    """Fetch strategies and start background refresh. Called once at init."""
    global _refresh_thread_started  # noqa: PLW0603

    # Kick off immediate fetch in background
    t = threading.Thread(target=_fetch_strategies, args=(config,), daemon=True)
    t.start()

    # Start refresh loop (idempotent)
    with _lock:
        if _refresh_thread_started:
            return
        _refresh_thread_started = True

    r = threading.Thread(target=_refresh_loop, args=(config,), daemon=True)
    r.start()


def lookup(
    failure_type: str,
    model: str,
    prompt_length: int,
) -> Optional[Strategy]:
    """Return the best known strategy for this failure pattern, or None.

    Checks agent-scope first, then org, then global — highest confidence wins.
    Thread-safe read under GIL; list replacement in _fetch_strategies is atomic.
    """
    bucket = _length_bucket(prompt_length)

    # Take a snapshot of the list to avoid races with refresh
    with _lock:
        current = list(_strategies)

    candidates = [
        s for s in current
        if s.failure_type == failure_type
        and (s.model == model or s.model == "*")
        and (s.prompt_length_bucket == bucket or s.prompt_length_bucket == "*")
        and s.win_rate >= 0.6
        and s.sample_count >= 10
    ]

    if not candidates:
        return None

    scope_order = {"agent": 0, "org": 1, "global": 2}
    candidates.sort(key=lambda s: (scope_order.get(s.scope, 9), -s.confidence))
    return candidates[0]


def _refresh_loop(config: RunConfig) -> None:
    """Periodically re-fetch strategies so long-running processes stay current."""
    while True:
        time.sleep(REFRESH_INTERVAL_S)
        _fetch_strategies(config)


def _length_bucket(token_count: int) -> str:
    if token_count < 500:
        return "short"
    if token_count < 2000:
        return "medium"
    if token_count < 8000:
        return "long"
    return "huge"


def _fetch_strategies(config: RunConfig) -> None:
    global _strategies, _loaded  # noqa: PLW0603

    import json
    import urllib.request
    import urllib.parse

    try:
        url = (
            f"{config.endpoint}/api/autopilot/strategies"
            f"?agent_name={urllib.parse.quote(config.agent_name)}"
        )
        req = urllib.request.Request(
            url,
            headers={"x-api-key": config.api_key},
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=3.0) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            raw = data.get("strategies", [])
            new_strategies = [_deserialize(s) for s in raw if s]

        with _lock:
            _strategies = new_strategies
            _loaded = True

        if new_strategies:
            print(
                f"[maev] {len(new_strategies)} strategies loaded for '{config.agent_name}'",
                file=sys.stderr,
            )
    except Exception as exc:  # noqa: BLE001
        with _lock:
            _loaded = True
        print(f"[maev] Strategy fetch failed (non-fatal): {exc}", file=sys.stderr)


def apply_strategy(strategy: Strategy, kwargs: dict) -> dict:
    """Mutate LLM call kwargs based on a learned strategy's params.

    Returns a new kwargs dict — never mutates the original.
    """
    updated = dict(kwargs)
    name = strategy.strategy
    params = strategy.params

    if name == "temp_increase":
        current = float(updated.get("temperature") or 0.7)
        target = float(params.get("max", 1.0))
        updated["temperature"] = min(current + 0.15, target)

    elif name == "temp_decrease":
        current = float(updated.get("temperature") or 0.7)
        target = float(params.get("min", 0.0))
        updated["temperature"] = max(current - 0.15, target)

    elif name == "model_fallback":
        target_model = params.get("target")
        if target_model:
            updated["model"] = target_model

    elif name == "max_tokens":
        value = params.get("value")
        if isinstance(value, int):
            if "max_completion_tokens" in updated:
                updated["max_completion_tokens"] = value
            else:
                updated["max_tokens"] = value

    elif name == "system_append":
        text = params.get("text", "").strip()
        if text:
            messages = list(updated.get("messages") or [])
            for i, msg in enumerate(messages):
                role = msg.get("role") if isinstance(msg, dict) else getattr(msg, "role", None)
                if role == "system":
                    if isinstance(msg, dict):
                        messages[i] = {**msg, "content": msg["content"].rstrip() + "\n\n" + text}
                    break
            else:
                messages.insert(0, {"role": "system", "content": text})
            updated["messages"] = messages

    return updated


def _deserialize(raw: dict) -> Strategy:
    return Strategy(
        failure_type=raw.get("failure_type", "unknown"),
        model=raw.get("model", "*"),
        prompt_length_bucket=raw.get("prompt_length_bucket", "*"),
        strategy=raw.get("strategy", ""),
        params=raw.get("params", {}),
        win_rate=float(raw.get("win_rate", 0.0)),
        sample_count=int(raw.get("sample_count", 0)),
        confidence=float(raw.get("confidence", 0.0)),
        scope=raw.get("scope", "global"),
    )
