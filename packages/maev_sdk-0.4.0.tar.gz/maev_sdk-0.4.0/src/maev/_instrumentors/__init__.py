"""Instrumentation is handled by OpenLIT internally.

This module is kept for future Maev-specific instrumentors
(e.g. custom agent frameworks not supported by OpenLIT).
"""
