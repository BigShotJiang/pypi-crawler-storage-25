"""SDK patches — intercept LLM calls for retry, circuit breaking, and learning.

Patching strategy:
  1. Patch existing instances — walk gc.get_objects() to find already-created
     LLM clients and wrap their methods directly on the instance.
  2. Patch the class — subclass OpenAI/Anthropic so any future instances also
     get wrapped automatically on __init__.
  3. Install import hook — re-run patching when a supported SDK is imported
     after maev.run() is called.

This triple approach means it doesn't matter when the client was created
relative to maev.run(). All three cases are covered.
"""

from __future__ import annotations

import builtins
import gc
import inspect
import sys
from typing import Any, Callable, Optional

from maev.types import RunConfig

_original_import = builtins.__import__
_import_hook_installed = False

# SDKs we patch. Google and Cohere are intentionally excluded until
# we have proper patch implementations for them.
_PATCH_TARGETS = (
    "openai",
    "anthropic",
    "langchain_core",
    "litellm",
)


def apply_all(config: RunConfig) -> None:
    """Patch all detected SDKs — existing instances + classes + future imports."""
    openai_mod = sys.modules.get("openai")
    anthropic_mod = sys.modules.get("anthropic")

    _patch_openai(openai_mod, config)
    _patch_anthropic(anthropic_mod, config)
    _patch_langchain(config)
    _patch_litellm(sys.modules.get("litellm"), config)

    # Patch already-existing instances (clients created before maev.run())
    _patch_existing_instances(openai_mod, anthropic_mod, config)

    _install_import_hook(config)


# ---------------------------------------------------------------------------
# Existing instance patching — the key fix for "client created before maev.run()"
# ---------------------------------------------------------------------------

def _patch_existing_instances(
    openai_mod: Any,
    anthropic_mod: Any,
    config: RunConfig,
) -> None:
    """Walk all live objects and patch any LLM client instances we find."""
    try:
        _patch_existing_openai(openai_mod, config)
    except Exception:  # noqa: BLE001
        pass
    try:
        _patch_existing_anthropic(anthropic_mod, config)
    except Exception:  # noqa: BLE001
        pass
    try:
        _patch_existing_langchain(config)
    except Exception:  # noqa: BLE001
        pass


def _patch_existing_openai(openai_mod: Any, config: RunConfig) -> None:
    if openai_mod is None:
        return

    client_classes = tuple(
        filter(None, [
            getattr(openai_mod, n, None)
            for n in ("OpenAI", "AsyncOpenAI", "AzureOpenAI", "AsyncAzureOpenAI")
        ])
    )
    if not client_classes:
        return

    for obj in gc.get_objects():
        try:
            if not isinstance(obj, client_classes):
                continue
        except TypeError:
            continue

        _wrap_method_path(obj, ("chat", "completions"), "create", config)
        _wrap_method_path(obj, ("responses",), "create", config)


def _patch_existing_anthropic(anthropic_mod: Any, config: RunConfig) -> None:
    if anthropic_mod is None:
        return

    client_classes = tuple(
        filter(None, [
            getattr(anthropic_mod, n, None)
            for n in ("Anthropic", "AsyncAnthropic")
        ])
    )
    if not client_classes:
        return

    for obj in gc.get_objects():
        try:
            if not isinstance(obj, client_classes):
                continue
        except TypeError:
            continue

        _wrap_method_path(obj, ("messages",), "create", config)


def _patch_existing_langchain(config: RunConfig) -> None:
    chat_models = sys.modules.get("langchain_core.language_models.chat_models")
    if chat_models is None:
        return

    BaseChatModel = getattr(chat_models, "BaseChatModel", None)
    if BaseChatModel is None:
        return

    for obj in gc.get_objects():
        try:
            if not isinstance(obj, BaseChatModel):
                continue
        except TypeError:
            continue

        # Patch the instance's bound methods directly
        for method_name in ("invoke", "ainvoke"):
            method = getattr(obj, method_name, None)
            if method is None or getattr(method, "__maev_patched__", False):
                continue
            wrapped = _make_wrapper(method, config)
            try:
                setattr(obj, method_name, wrapped)
            except (AttributeError, TypeError):
                pass


# ---------------------------------------------------------------------------
# Import hook — catches SDKs imported after maev.run()
# ---------------------------------------------------------------------------

def _install_import_hook(config: RunConfig) -> None:
    global _import_hook_installed  # noqa: PLW0603

    if _import_hook_installed:
        return

    def _patched_import(name, globals=None, locals=None, fromlist=(), level=0):  # type: ignore
        module = _original_import(name, globals, locals, fromlist, level)
        root = name.split(".", 1)[0]
        if root in _PATCH_TARGETS or name in _PATCH_TARGETS:
            # Re-run patching — idempotent due to __maev_patched__ guards
            try:
                apply_all(config)
            except Exception:  # noqa: BLE001
                pass
        return module

    builtins.__import__ = _patched_import
    _import_hook_installed = True


# ---------------------------------------------------------------------------
# OpenAI — class patching (new instances)
# ---------------------------------------------------------------------------

def _patch_openai(openai_module: Any, config: RunConfig) -> None:
    if openai_module is None:
        return

    for client_name in ("OpenAI", "AsyncOpenAI", "AzureOpenAI", "AsyncAzureOpenAI"):
        _wrap_openai_class(openai_module, client_name, config)


def _wrap_openai_class(module: Any, name: str, config: RunConfig) -> None:
    Original = getattr(module, name, None)
    if Original is None or getattr(Original, "__maev_patched__", False):
        return

    class Patched(Original):  # type: ignore[misc,valid-type]
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw)
            _wrap_method_path(self, ("chat", "completions"), "create", config)
            _wrap_method_path(self, ("responses",), "create", config)

    Patched.__name__ = Original.__name__
    Patched.__qualname__ = Original.__qualname__
    Patched.__maev_patched__ = True  # type: ignore[attr-defined]
    setattr(module, name, Patched)


# ---------------------------------------------------------------------------
# Anthropic — class patching (new instances)
# ---------------------------------------------------------------------------

def _patch_anthropic(anthropic_module: Any, config: RunConfig) -> None:
    if anthropic_module is None:
        return

    for client_name in ("Anthropic", "AsyncAnthropic"):
        _wrap_anthropic_class(anthropic_module, client_name, config)


def _wrap_anthropic_class(module: Any, name: str, config: RunConfig) -> None:
    Original = getattr(module, name, None)
    if Original is None or getattr(Original, "__maev_patched__", False):
        return

    class Patched(Original):  # type: ignore[misc,valid-type]
        def __init__(self, *a, **kw):
            super().__init__(*a, **kw)
            _wrap_method_path(self, ("messages",), "create", config)

    Patched.__name__ = Original.__name__
    Patched.__qualname__ = Original.__qualname__
    Patched.__maev_patched__ = True  # type: ignore[attr-defined]
    setattr(module, name, Patched)


# ---------------------------------------------------------------------------
# LangChain — class patching (new instances)
# ---------------------------------------------------------------------------

def _patch_langchain(config: RunConfig) -> None:
    chat_models = sys.modules.get("langchain_core.language_models.chat_models")
    if chat_models is None:
        return

    BaseChatModel = getattr(chat_models, "BaseChatModel", None)
    if BaseChatModel is None or getattr(BaseChatModel, "__maev_patched__", False):
        return

    _wrap_class_method(BaseChatModel, "invoke", config)
    _wrap_class_method(BaseChatModel, "ainvoke", config)
    BaseChatModel.__maev_patched__ = True  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# LiteLLM — hook into callback system (most reliable approach for LiteLLM)
# ---------------------------------------------------------------------------

def _patch_litellm(litellm_module: Any, config: RunConfig) -> None:
    if litellm_module is None:
        return

    if getattr(litellm_module, "__maev_patched__", False):
        return

    from maev.patches._litellm_callbacks import MaevLiteLLMCallback
    cb = MaevLiteLLMCallback(config)

    success_cbs = getattr(litellm_module, "success_callback", [])
    failure_cbs = getattr(litellm_module, "failure_callback", [])
    litellm_module.success_callback = list(success_cbs) + [cb.on_success]
    litellm_module.failure_callback = list(failure_cbs) + [cb.on_failure]
    litellm_module.__maev_patched__ = True  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# Generic wrapping utilities
# ---------------------------------------------------------------------------

def _wrap_method_path(owner: Any, path: tuple, method_name: str, config: RunConfig) -> None:
    """Wrap a nested method like obj.chat.completions.create on an instance."""
    target = owner
    try:
        for attr in path:
            target = getattr(target, attr)
        original = getattr(target, method_name)
    except AttributeError:
        return

    if getattr(original, "__maev_patched__", False):
        return

    wrapped = _make_wrapper(original, config)
    try:
        setattr(target, method_name, wrapped)
    except (AttributeError, TypeError):
        pass


def _wrap_class_method(cls: Any, method_name: str, config: RunConfig) -> None:
    original = getattr(cls, method_name, None)
    if original is None or getattr(original, "__maev_patched__", False):
        return
    try:
        setattr(cls, method_name, _make_wrapper(original, config))
    except (AttributeError, TypeError):
        pass


def _make_wrapper(original: Callable, config: RunConfig) -> Callable:
    """Create a sync or async wrapper that applies all interceptors."""
    if inspect.iscoroutinefunction(original):
        @wraps_fn(original)
        async def _async_wrapper(*args, **kwargs):
            return await _intercept_async(original, args, kwargs, config)
        return _async_wrapper
    else:
        @wraps_fn(original)
        def _sync_wrapper(*args, **kwargs):
            return _intercept_sync(original, args, kwargs, config)
        return _sync_wrapper


def wraps_fn(fn: Callable) -> Callable:
    """functools.wraps but also copies __maev_patched__ marker."""
    from functools import wraps

    def decorator(wrapper: Callable) -> Callable:
        wrapped = wraps(fn)(wrapper)
        wrapped.__maev_patched__ = True  # type: ignore[attr-defined]
        return wrapped

    return decorator


# ---------------------------------------------------------------------------
# Interceptors — the core logic that runs on every LLM call
# ---------------------------------------------------------------------------

def _intercept_sync(
    fn: Callable, args: tuple, kwargs: dict, config: RunConfig
) -> Any:
    """Apply all interceptors synchronously around an LLM call."""
    from maev.interceptors.circuit import (
        check_call_count, check_cost, check_duration, extract_call_cost,
        CircuitBrokenError,
    )
    from maev.interceptors.loop_detector import check_loop, hash_messages, LoopDetectedError
    from maev.interceptors.retry import retry_call
    from maev.interceptors.fallback import try_with_fallbacks
    from maev.runner import get_current_run
    from maev.learning.recorder import record_call
    from maev.learning.store import lookup as _lookup_strategy, apply_strategy as _apply_strategy

    run = get_current_run()

    # Circuit breaker pre-checks
    if run:
        check_cost(run)
        check_call_count(run)
        check_duration(run)
        run.increment_calls()

        # Loop detection
        messages = kwargs.get("messages") or (args[1] if len(args) > 1 else None)
        if messages:
            try:
                check_loop(run, hash_messages(messages))
            except LoopDetectedError:
                raise

    start = _now_ms()
    try:
        result = retry_call(fn, args, kwargs, run=run)
        cost = extract_call_cost(result)
        if run:
            run.add_cost(cost)
        record_call(run, kwargs, result, "success", None, None, None, _now_ms() - start, cost)
        return result

    except Exception as exc:
        failure_type = type(exc).__name__

        # Strategy store: apply a learned recovery strategy before fallback
        if run and not isinstance(exc, CircuitBrokenError):
            model = kwargs.get("model", "*")
            messages = kwargs.get("messages") or []
            prompt_length = sum(
                len(str(m.get("content", ""))) // 4
                for m in messages
                if isinstance(m, dict)
            )
            strategy = _lookup_strategy(failure_type, model, prompt_length)
            if strategy:
                strat_start = _now_ms()
                kwargs_patched = _apply_strategy(strategy, kwargs)
                try:
                    result = retry_call(fn, args, kwargs_patched, run=run)
                    cost = extract_call_cost(result)
                    run.add_cost(cost)
                    run.record_intervention(
                        type="strategy_apply",
                        trigger=failure_type,
                        strategy=strategy.strategy,
                        outcome="success",
                        latency_ms=_now_ms() - strat_start,
                        metadata={"win_rate": strategy.win_rate, "scope": strategy.scope},
                    )
                    record_call(
                        run, kwargs_patched, result, "success", failure_type,
                        strategy.strategy, "success", _now_ms() - start, cost,
                    )
                    return result
                except Exception:
                    run.record_intervention(
                        type="strategy_apply",
                        trigger=failure_type,
                        strategy=strategy.strategy,
                        outcome="failure",
                        latency_ms=_now_ms() - strat_start,
                    )

        # Fallback models
        if run and config.fallback_models and not isinstance(exc, CircuitBrokenError):
            try:
                result = try_with_fallbacks(fn, args, kwargs, exc, run)
                cost = extract_call_cost(result)
                run.add_cost(cost)
                record_call(
                    run, kwargs, result, "success", failure_type,
                    f"model_fallback", "success", _now_ms() - start, cost,
                )
                return result
            except Exception:
                pass

        record_call(run, kwargs, None, "failed", failure_type, None, None, _now_ms() - start, 0.0)
        raise


async def _intercept_async(
    fn: Callable, args: tuple, kwargs: dict, config: RunConfig
) -> Any:
    """Async version of _intercept_sync."""
    from maev.interceptors.circuit import (
        check_call_count, check_cost, check_duration, extract_call_cost,
        CircuitBrokenError,
    )
    from maev.interceptors.loop_detector import check_loop, hash_messages, LoopDetectedError
    from maev.interceptors.retry import retry_call_async
    from maev.interceptors.fallback import try_with_fallbacks_async
    from maev.runner import get_current_run
    from maev.learning.recorder import record_call
    from maev.learning.store import lookup as _lookup_strategy, apply_strategy as _apply_strategy

    run = get_current_run()

    if run:
        check_cost(run)
        check_call_count(run)
        check_duration(run)
        run.increment_calls()

        messages = kwargs.get("messages") or (args[1] if len(args) > 1 else None)
        if messages:
            try:
                check_loop(run, hash_messages(messages))
            except LoopDetectedError:
                raise

    start = _now_ms()
    try:
        result = await retry_call_async(fn, args, kwargs, run=run)
        cost = extract_call_cost(result)
        if run:
            run.add_cost(cost)
        record_call(run, kwargs, result, "success", None, None, None, _now_ms() - start, cost)
        return result

    except Exception as exc:
        failure_type = type(exc).__name__

        # Strategy store: apply a learned recovery strategy before fallback
        if run and not isinstance(exc, CircuitBrokenError):
            model = kwargs.get("model", "*")
            messages = kwargs.get("messages") or []
            prompt_length = sum(
                len(str(m.get("content", ""))) // 4
                for m in messages
                if isinstance(m, dict)
            )
            strategy = _lookup_strategy(failure_type, model, prompt_length)
            if strategy:
                strat_start = _now_ms()
                kwargs_patched = _apply_strategy(strategy, kwargs)
                try:
                    result = await retry_call_async(fn, args, kwargs_patched, run=run)
                    cost = extract_call_cost(result)
                    run.add_cost(cost)
                    run.record_intervention(
                        type="strategy_apply",
                        trigger=failure_type,
                        strategy=strategy.strategy,
                        outcome="success",
                        latency_ms=_now_ms() - strat_start,
                        metadata={"win_rate": strategy.win_rate, "scope": strategy.scope},
                    )
                    record_call(
                        run, kwargs_patched, result, "success", failure_type,
                        strategy.strategy, "success", _now_ms() - start, cost,
                    )
                    return result
                except Exception:
                    run.record_intervention(
                        type="strategy_apply",
                        trigger=failure_type,
                        strategy=strategy.strategy,
                        outcome="failure",
                        latency_ms=_now_ms() - strat_start,
                    )

        # Fallback models
        if run and config.fallback_models and not isinstance(exc, CircuitBrokenError):
            try:
                result = await try_with_fallbacks_async(fn, args, kwargs, exc, run)
                cost = extract_call_cost(result)
                run.add_cost(cost)
                record_call(
                    run, kwargs, result, "success", failure_type,
                    "model_fallback", "success", _now_ms() - start, cost,
                )
                return result
            except Exception:
                pass

        record_call(run, kwargs, None, "failed", failure_type, None, None, _now_ms() - start, 0.0)
        raise


def _now_ms() -> int:
    import time
    return int(time.time() * 1000)
