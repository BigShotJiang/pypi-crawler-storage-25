"""LiteLLM callback integration — hook into their success/failure system."""

from __future__ import annotations

import sys
from typing import Any

from maev.types import RunConfig


class MaevLiteLLMCallback:
    """Registers into LiteLLM's callback system for observability + learning."""

    def __init__(self, config: RunConfig) -> None:
        self.config = config

    def on_success(self, kwargs: Any, response: Any, start_time: Any, end_time: Any) -> None:
        from maev.runner import get_current_run
        from maev.interceptors.circuit import extract_call_cost
        from maev.learning.recorder import record_call

        run = get_current_run()
        latency_ms = int((end_time - start_time).total_seconds() * 1000) if (end_time and start_time) else 0
        cost = extract_call_cost(response)
        if run:
            run.add_cost(cost)
        record_call(run, kwargs, response, "success", None, None, None, latency_ms, cost)

    def on_failure(self, kwargs: Any, response: Any, start_time: Any, end_time: Any) -> None:
        from maev.runner import get_current_run
        from maev.learning.recorder import record_call

        run = get_current_run()
        latency_ms = int((end_time - start_time).total_seconds() * 1000) if (end_time and start_time) else 0
        exc_name = type(kwargs.get("exception", Exception())).__name__
        record_call(run, kwargs, None, "failed", exc_name, None, None, latency_ms, 0.0)
