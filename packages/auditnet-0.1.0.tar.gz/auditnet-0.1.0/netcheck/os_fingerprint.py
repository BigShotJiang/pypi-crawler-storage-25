"""Fingerprinting OS basique via TTL (Time To Live) des paquets ICMP/TCP."""

import socket
import platform
from rich.console import Console

console = Console()

# Table de correspondance TTL -> OS (approximative)
TTL_OS = {
    64: ("Linux/Unix", "Linux, macOS, Android, iOS, BSD"),
    128: ("Windows", "Windows XP/7/8/10/11/Server"),
    255: ("Réseau/Cisco", "Routeurs Cisco, switches, équipements réseau, Solaris"),
    254: ("Réseau", "Équipements réseau (juniper, etc.)"),
    60: ("AIX/Digital Unix", "IBM AIX, DEC/Compaq Tru64"),
}


def obtenir_ttl_os(adresse_ip: str, delai: float = 1.0) -> dict:
    """Tente de déterminer l'OS via le TTL d'un ping ICMP basique (socket raw non nécessaire)."""
    resultat = {
        "ip": adresse_ip,
        "ttl_detecte": None,
        "os_estime": "Inconnu",
        "os_probables": "",
        "confiance": "FAIBLE"
    }
    
    try:
        # Utiliser socket raw ICMP (nécessite admin sur Windows, mais on gère l'erreur)
        import struct
        import select
        
        proto_icmp = socket.getprotobyname("icmp")
        sock = socket.socket(socket.AF_INET, socket.SOCK_RAW, proto_icmp)
        sock.settimeout(delai)
        
        # Construction d'un paquet ICMP Echo Request
        # Type=8 (echo), Code=0, checksum=0, id, seq
        identifiant = 12345
        sequence = 1
        checksum = 0
        header = struct.pack("!BBHHH", 8, 0, checksum, identifiant, sequence)
        data = b"netcheck"
        
        # Calcul du checksum
        def calculer_checksum(source):
            if len(source) % 2:
                source += b'\0'
            somme = sum(struct.unpack("!%dH" % (len(source) // 2), source))
            somme = (somme >> 16) + (somme & 0xffff)
            somme += somme >> 16
            return ~somme & 0xffff
        
        checksum = calculer_checksum(header + data)
        header = struct.pack("!BBHHH", 8, 0, checksum, identifiant, sequence)
        paquet = header + data
        
        sock.sendto(paquet, (adresse_ip, 0))
        
        # Attendre la réponse
        pret, _, _ = select.select([sock], [], [], delai)
        if pret:
            reponse, adresse = sock.recvfrom(1024)
            # Le TTL est au 9ème octet (offset 8) du paquet IP
            ttl = reponse[8]
            resultat["ttl_detecte"] = ttl
            
            # Estimation OS
            os_info = TTL_OS.get(ttl)
            if os_info:
                resultat["os_estime"] = os_info[0]
                resultat["os_probables"] = os_info[1]
                resultat["confiance"] = "MOYENNE"
            else:
                # Chercher le TTL le plus proche
                ttl_connu = min(TTL_OS.keys(), key=lambda x: abs(x - ttl))
                os_info = TTL_OS.get(ttl_connu)
                if os_info:
                    resultat["os_estime"] = f"Probablement {os_info[0]}"
                    resultat["os_probables"] = os_info[1]
                    resultat["confiance"] = "FAIBLE"
        
        sock.close()
        
    except PermissionError:
        resultat["confiance"] = "N/A"
        resultat["os_probables"] = "Nécessite les droits administrateur/root pour le ping ICMP"
    except OSError:
        # Raw sockets non disponibles
        resultat["confiance"] = "N/A"
        resultat["os_probables"] = "Ping ICMP non disponible sur ce système"
    except Exception:
        pass
    
    return resultat


def estimer_os_hote(donnees_hote: dict) -> dict:
    """Ajoute l'estimation d'OS aux données d'un hôte."""
    fingerprint = obtenir_ttl_os(donnees_hote["ip"])
    donnees_hote["os_estime"] = fingerprint["os_estime"]
    donnees_hote["os_probables"] = fingerprint["os_probables"]
    donnees_hote["ttl"] = fingerprint["ttl_detecte"]
    
    # Ajouter une alerte informative si on a une estimation
    if fingerprint["ttl_detecte"] and fingerprint["confiance"] != "N/A":
        donnees_hote["alertes"].append({
            "ip": donnees_hote["ip"],
            "port": "-",
            "niveau": "FAIBLE",
            "titre": f"OS estimé : {fingerprint['os_estime']}",
            "description": f"Basé sur le TTL ICMP ({fingerprint['ttl_detecte']}). Systèmes possibles : {fingerprint['os_probables']}.",
            "conseil": "Cette estimation est indicative. Utilisez-la comme point de départ, pas comme preuve."
        })
    
    return donnees_hote
