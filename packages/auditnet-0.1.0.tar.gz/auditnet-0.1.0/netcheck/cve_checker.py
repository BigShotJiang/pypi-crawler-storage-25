"""Vérification des CVE via l'API publique NVD (National Vulnerability Database)."""

import requests
import time
from rich.console import Console

console = Console()

URL_NVD = "https://services.nvd.nist.gov/rest/json/cves/2.0"


def rechercher_cves(mot_cle: str, nombre_max: int = 3) -> list:
    """Recherche des CVE via l'API NVD à partir d'un mot-clé (ex: 'OpenSSH 8.2')."""
    if not mot_cle or len(mot_cle) < 2:
        return []
    
    try:
        parametres = {
            "keywordSearch": mot_cle,
            "resultsPerPage": nombre_max,
            "noRejected": ""
        }
        reponse = requests.get(URL_NVD, params=parametres, timeout=15)
        reponse.raise_for_status()
        donnees = reponse.json()
        
        cves = []
        for element in donnees.get("vulnerabilities", []):
            identifiant_cve = element["cve"]["id"]
            descriptions = element["cve"].get("descriptions", [])
            description = descriptions[0]["value"] if descriptions else "Pas de description disponible"
            
            # Récupération du score CVSS si disponible
            metriques = element["cve"].get("metrics", {})
            score_cvss = None
            severite = "Inconnue"
            
            if "cvssMetricV31" in metriques:
                score_cvss = metriques["cvssMetricV31"][0]["cvssData"]["baseScore"]
                severite = metriques["cvssMetricV31"][0]["cvssData"]["baseSeverity"]
            elif "cvssMetricV30" in metriques:
                score_cvss = metriques["cvssMetricV30"][0]["cvssData"]["baseScore"]
                severite = metriques["cvssMetricV30"][0]["cvssData"]["baseSeverity"]
            
            cves.append({
                "id": identifiant_cve,
                "description": description[:150] + "..." if len(description) > 150 else description,
                "score": score_cvss,
                "severite": severite
            })
        
        # Respect de la limite de débit de l'API NVD (environ 5 requêtes par seconde max, on attend 6s)
        time.sleep(6)
        return cves
    except requests.exceptions.Timeout:
        console.print(f"[yellow]⚠️  Délai dépassé pour la recherche CVE : {mot_cle}[/yellow]")
        return []
    except requests.exceptions.RequestException as erreur:
        console.print(f"[yellow]⚠️  Erreur API CVE pour '{mot_cle}' : {erreur}[/yellow]")
        return []
    except Exception as erreur:
        console.print(f"[yellow]⚠️  Erreur inattendue CVE : {erreur}[/yellow]")
        return []


def verifier_vulnerabilites_hote(donnees_hote: dict) -> dict:
    """Vérifie les CVE pour chaque service détecté sur un hôte."""
    if "services" not in donnees_hote or not donnees_hote["services"]:
        return donnees_hote
    
    vulnerabilites = []
    
    for port, infos_service in donnees_hote["services"].items():
        nom_service = infos_service.get("service", "")
        version = infos_service.get("version", "")
        
        # Construction du mot-clé de recherche
        if version:
            mot_cle = f"{nom_service} {version}"
        else:
            mot_cle = nom_service
        
        if mot_cle and mot_cle != "Inconnu":
            cves_trouves = rechercher_cves(mot_cle, nombre_max=2)
            if cves_trouves:
                for cve in cves_trouves:
                    vulnerabilites.append({
                        "port": port,
                        "service": nom_service,
                        "version": version,
                        "cve_id": cve["id"],
                        "description": cve["description"],
                        "score": cve["score"],
                        "severite": cve["severite"]
                    })
    
    donnees_hote["vulnerabilites"] = vulnerabilites
    return donnees_hote
