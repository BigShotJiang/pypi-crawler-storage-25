"""Scan réseau et découverte des hôtes et ports ouverts."""

import socket
import ipaddress
import platform
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console
from rich.progress import Progress, TaskID

console = Console()

# Ports communs à scanner
PORTS_COMMUNS = [21, 22, 23, 25, 53, 80, 110, 135, 139, 143, 443, 445, 993, 995, 1723, 3306, 3389, 5432, 5900, 8080]


def hote_est_actif(adresse_ip: str, delai: float = 1.0) -> bool:
    """Vérifie si un hôte est actif via ICMP ping, puis fallback TCP 80."""
    # Méthode 1 : ICMP ping (le plus fiable pour détecter un hôte vivant)
    try:
        if platform.system().lower() == "windows":
            # -n = nombre de paquets, -w = timeout ms, > nul = pas d'affichage
            resultat = subprocess.run(
                ["ping", "-n", "1", "-w", str(int(delai * 1000)), adresse_ip],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=delai + 1
            )
        else:
            resultat = subprocess.run(
                ["ping", "-c", "1", "-W", str(int(delai)), adresse_ip],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=delai + 1
            )
        
        if resultat.returncode == 0:
            return True
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    
    # Méthode 2 : TCP sur port 80 (fallback si ping bloqué par firewall)
    try:
        connexion = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        connexion.settimeout(delai)
        resultat = connexion.connect_ex((adresse_ip, 80))
        connexion.close()
        return resultat == 0 or resultat == 10061  # 10061 = Connexion refusée (Windows)
    except (socket.timeout, OSError):
        return False


def scanner_port(adresse_ip: str, port: int, delai: float = 1.0) -> tuple:
    """Scanne un port TCP sur une adresse IP donnée."""
    try:
        connexion = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        connexion.settimeout(delai)
        resultat = connexion.connect_ex((adresse_ip, port))
        connexion.close()
        if resultat == 0:
            return (port, True)
        return (port, False)
    except (socket.timeout, OSError):
        return (port, False)


def scanner_ports_hote(adresse_ip: str, ports: list = None, delai: float = 1.0) -> dict:
    """Scanne une liste de ports sur un hôte donné."""
    if ports is None:
        ports = PORTS_COMMUNS
    
    ports_ouverts = []
    with ThreadPoolExecutor(max_workers=10) as executeur:
        taches = {executeur.submit(scanner_port, adresse_ip, port, delai): port for port in ports}
        for tache in as_completed(taches):
            port, est_ouvert = tache.result()
            if est_ouvert:
                ports_ouverts.append(port)
    
    return {
        "ip": adresse_ip,
        "ports_ouverts": sorted(ports_ouverts),
        "services": {},
        "vulnerabilites": [],
        "alertes": []
    }


def scanner_sous_reseau(sous_reseau: str, nombre_max_hotes: int = 50, barre_progression: Progress = None, tache: TaskID = None, ports: list = None) -> list:
    """Scanne un sous-réseau pour trouver les hôtes actifs et leurs ports ouverts."""
    try:
        reseau = ipaddress.ip_network(sous_reseau, strict=False)
    except ValueError as erreur:
        console.print(f"[bold red]❌ Sous-réseau invalide : {erreur}[/bold red]")
        return []
    
    hotes = [str(hote) for hote in reseau.hosts()][:nombre_max_hotes]
    
    if not hotes:
        console.print("[yellow]⚠️  Aucun hôte à scanner dans ce sous-réseau.[/yellow]")
        return []
    
    hotes_actifs = []
    
    if barre_progression and tache:
        barre_progression.update(tache, total=len(hotes), description="[cyan]Scan des hôtes...[/cyan]")
    
    # Première phase : vérifier si les hôtes sont vivants
    hotes_vivants = []
    with ThreadPoolExecutor(max_workers=20) as executeur:
        taches = {executeur.submit(hote_est_actif, hote): hote for hote in hotes}
        for tache_future in as_completed(taches):
            hote = taches[tache_future]
            if tache_future.result():
                hotes_vivants.append(hote)
            if barre_progression and tache:
                barre_progression.advance(tache)
    
    if barre_progression and tache:
        barre_progression.update(tache, completed=len(hotes), description=f"[green]{len(hotes_vivants)} hôtes actifs trouvés[/green]")
    
    if not hotes_vivants:
        console.print("[yellow]⚠️  Aucun hôte actif détecté sur ce sous-réseau.[/yellow]")
        return []
    
    # Deuxième phase : scanner les ports des hôtes vivants
    ports_a_scanner = ports if ports else PORTS_COMMUNS
    console.print(f"[cyan]🔍 Scan des ports sur {len(hotes_vivants)} hôte(s) actif(s)...[/cyan]")
    
    with ThreadPoolExecutor(max_workers=10) as executeur:
        taches = {executeur.submit(scanner_ports_hote, hote, ports_a_scanner): hote for hote in hotes_vivants}
        for tache_future in as_completed(taches):
            donnees_hote = tache_future.result()
            if donnees_hote["ports_ouverts"]:
                hotes_actifs.append(donnees_hote)
    
    return sorted(hotes_actifs, key=lambda x: ipaddress.ip_address(x["ip"]))
