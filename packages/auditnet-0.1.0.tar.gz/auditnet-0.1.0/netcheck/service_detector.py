"""Détection des services et récupération des bannières."""

import socket
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from rich.console import Console

console = Console()

# Correspondance ports -> services connus
SERVICES_PAR_PORT = {
    21: "FTP",
    22: "SSH",
    23: "Telnet",
    25: "SMTP",
    53: "DNS",
    80: "HTTP",
    110: "POP3",
    135: "MS-RPC",
    139: "NetBIOS",
    143: "IMAP",
    443: "HTTPS",
    445: "SMB",
    993: "IMAPS",
    995: "POP3S",
    1723: "PPTP",
    3306: "MySQL",
    3389: "RDP",
    5432: "PostgreSQL",
    5900: "VNC",
    8080: "HTTP-Proxy"
}


def recuperer_banniere(adresse_ip: str, port: int, delai: float = 2.0) -> str:
    """Récupère la bannière d'un service sur un port donné."""
    try:
        connexion = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        connexion.settimeout(delai)
        connexion.connect((adresse_ip, port))
        
        # Pour certains services, envoyer une requête pour obtenir une réponse
        if port in [80, 8080]:
            connexion.send(b"GET / HTTP/1.0\r\n\r\n")
        elif port == 21:
            pass  # Le serveur FTP envoie la bannière spontanément
        elif port == 22:
            pass  # SSH envoie la bannière spontanément
        elif port == 25:
            connexion.send(b"EHLO netcheck.local\r\n")
        
        banniere = connexion.recv(1024).decode("utf-8", errors="ignore").strip()
        connexion.close()
        return banniere
    except (socket.timeout, ConnectionRefusedError, OSError):
        return ""
    except Exception:
        return ""


def detecter_service(adresse_ip: str, port: int) -> dict:
    """Détecte le service et sa version sur un port donné."""
    banniere = recuperer_banniere(adresse_ip, port)
    nom_service = SERVICES_PAR_PORT.get(port, "Inconnu")
    version = ""
    
    # Extraction de versions simples
    if banniere:
        # SSH : SSH-2.0-OpenSSH_8.2p1
        correspondance_ssh = re.search(r'SSH-[\d.]+-([^\s]+)', banniere)
        if correspondance_ssh:
            version = correspondance_ssh.group(1)
            nom_service = "SSH"
        
        # HTTP/HTTPS : Server: Apache/2.4.41
        correspondance_http = re.search(r'Server:\s*([^\r\n]+)', banniere)
        if correspondance_http:
            version = correspondance_http.group(1).strip()
            nom_service = "HTTP" if port in [80, 8080] else "HTTPS"
        
        # FTP : 220 Welcome to Pure-FTPd
        correspondance_ftp = re.search(r'220\s+(.+)', banniere)
        if correspondance_ftp and port == 21:
            version = correspondance_ftp.group(1).strip()
            nom_service = "FTP"
        
        # SMTP : 220 mail.example.com ESMTP Postfix
        correspondance_smtp = re.search(r'ESMTP\s+(.+)', banniere)
        if correspondance_smtp:
            version = correspondance_smtp.group(1).strip()
            nom_service = "SMTP"
        
        # MySQL : 5.5.5-10.3.28-MariaDB
        correspondance_mysql = re.search(r'(\d+\.\d+\.\d+[^\s]*)', banniere)
        if correspondance_mysql and port == 3306:
            version = correspondance_mysql.group(1)
            nom_service = "MySQL/MariaDB"
    
    return {
        "port": port,
        "service": nom_service,
        "version": version,
        "banniere": banniere[:100] + "..." if len(banniere) > 100 else banniere
    }


def detecter_tous_les_services(donnees_hote: dict) -> dict:
    """Détecte tous les services pour un hôte donné."""
    adresse_ip = donnees_hote["ip"]
    services = {}
    
    with ThreadPoolExecutor(max_workers=5) as executeur:
        taches = {executeur.submit(detecter_service, adresse_ip, port): port for port in donnees_hote["ports_ouverts"]}
        for tache_future in as_completed(taches):
            port = taches[tache_future]
            try:
                infos_service = tache_future.result()
                services[port] = infos_service
            except Exception:
                services[port] = {
                    "port": port,
                    "service": SERVICES_PAR_PORT.get(port, "Inconnu"),
                    "version": "",
                    "banniere": ""
                }
    
    donnees_hote["services"] = services
    return donnees_hote
