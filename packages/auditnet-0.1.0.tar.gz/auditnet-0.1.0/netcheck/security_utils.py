"""Utilitaires de sécurité et avertissements éthiques pour netcheck."""

import os
import sys
import ctypes
import platform
from rich.console import Console
from rich.panel import Panel

console = Console()


def est_administrateur() -> bool:
    """Vérifie si le script est exécuté avec les privilèges administrateur/root."""
    try:
        return os.getuid() == 0
    except AttributeError:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0


def obtenir_systeme() -> str:
    """Retourne le système d'exploitation détecté."""
    return platform.system().lower()


def afficher_avertissement_ethique():
    """Affiche un avertissement éthique à chaque lancement de l'outil."""
    texte_avertissement = (
        "[bold yellow]⚠️  Usage éthique et légal obligatoire[/bold yellow]\n\n"
        "[white]Cet outil est destiné à un usage [bold green]pédagogique et éthique[/bold green].\n"
        "Ne scannez que des réseaux dont vous êtes [bold]propriétaire[/bold] "
        "ou pour lesquels vous disposez d'une [bold]autorisation explicite[/bold].\n\n"
        "Tout scan non autorisé peut constituer une infraction pénale.[/white]"
    )
    console.print(Panel.fit(texte_avertissement, title="netcheck", border_style="red"))
    console.print()


def verifier_prerequis_scapy():
    """Vérifie les prérequis pour Scapy et affiche des instructions si nécessaire."""
    nom_systeme = obtenir_systeme()
    if nom_systeme == "windows":
        try:
            from scapy.all import conf
        except ImportError:
            console.print("[bold red]❌ Scapy non installé.[/bold red]")
            return False
        if not hasattr(conf, "use_npcap") or not conf.use_npcap:
            console.print(
                "[yellow]⚠️  Npcap non détecté. Pour la capture de trames sur Windows, "
                "installez Npcap depuis https://npcap.com/[/yellow]"
            )
            return False
    return True


def afficher_avertissement_admin():
    """Affiche un avertissement si l'outil est lancé avec des privilèges élevés."""
    if est_administrateur():
        console.print(
            "[bold red]⚠️  Vous êtes en mode administrateur/root. "
            "Limitez les privilèges en dehors de la capture de trames.[/bold red]\n"
        )


def verifier_securite():
    """Exécute toutes les vérifications de sécurité au démarrage."""
    afficher_avertissement_ethique()
    afficher_avertissement_admin()
