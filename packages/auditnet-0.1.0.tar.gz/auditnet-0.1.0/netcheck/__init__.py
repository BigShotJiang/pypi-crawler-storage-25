"""netcheck - Outil CLI de vulgarisation d'audit de sécurité réseau local."""

__version__ = "0.1.0"
__auteurs__ = "Korgho Sosthene, Ouedraogo Chakira"
__description__ = "Outil CLI de vulgarisation d'audit de sécurité réseau local"
