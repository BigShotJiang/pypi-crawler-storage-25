"""Point d'entrée pour python -m netcheck."""

from .cli import main

if __name__ == "__main__":
    main()
