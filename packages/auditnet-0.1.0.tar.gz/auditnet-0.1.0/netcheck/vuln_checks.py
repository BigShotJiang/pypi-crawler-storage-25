"""Vérifications de sécurité basiques et alertes de vulnérabilités."""

from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()

# Base de connaissances des ports dangereux
PORTS_DANGEREUX = {
    23: {
        "niveau": "CRITIQUE",
        "titre": "Telnet actif",
        "description": "Telnet transmet les données en clair (texte non chiffré). Les identifiants et mots de passe sont visibles sur le réseau.",
        "conseil": "Désactivez Telnet et remplacez-le par SSH (port 22) qui chiffre les communications."
    },
    21: {
        "niveau": "MOYEN",
        "titre": "FTP non sécurisé",
        "description": "Le protocole FTP envoie les identifiants et fichiers sans chiffrement.",
        "conseil": "Utilisez SFTP (SSH File Transfer) ou FTPS à la place."
    },
    445: {
        "niveau": "CRITIQUE",
        "titre": "Partage SMB ouvert",
        "description": "SMB (Samba / Partage Windows) est souvent ciblé par des ransomwares comme WannaCry.",
        "conseil": "Limitez l'accès au pare-feu, désactivez SMBv1, et vérifiez les partages publics."
    },
    3389: {
        "niveau": "MOYEN",
        "titre": "Bureau à distance exposé",
        "description": "RDP (Remote Desktop Protocol) exposé sur Internet est souvent attaqué par force brute.",
        "conseil": "Restreignez l'accès par VPN, activez l'authentification forte (MFA)."
    },
    53: {
        "niveau": "FAIBLE",
        "titre": "DNS ouvert",
        "description": "Un serveur DNS ouvert peut être utilisé pour des attaques par amplification.",
        "conseil": "Restreignez les requêtes DNS aux utilisateurs de votre réseau."
    },
    80: {
        "niveau": "MOYEN",
        "titre": "HTTP sans chiffrement",
        "description": "Le trafic HTTP circule en clair et peut être intercepté (attaque de l'homme du milieu).",
        "conseil": "Activez HTTPS avec un certificat TLS/SSL (port 443)."
    }
}

# Ports généralement nécessaires mais à surveiller
PORTS_A_SURVEILLER = [22, 3306, 5432, 5900]

# Mots de passe par défaut connus (service -> credentials)
CREDENTIALS_DEFAUT = {
    "Telnet": ["admin/admin", "root/root", "user/user"],
    "FTP": ["anonymous/anonymous", "ftp/ftp", "admin/admin"],
    "SSH": ["root/root", "admin/admin", "pi/raspberry"],
    "MySQL": ["root/(vide)", "root/root", "admin/admin"],
    "PostgreSQL": ["postgres/postgres"],
    "RDP": ["administrator/administrator"],
    "VNC": ["(vide)/(vide)"]
}

# Services avec versions connues pour avoir des vulnérabilités graves
VERSIONS_VULNERABLES = {
    "openssh_7": "OpenSSH 7.x contient des failles de sécurité connues (CVE-2018-15473, etc.)",
    "openssh_6": "OpenSSH 6.x est obsolète et vulnérable",
    "openssl_1.0": "OpenSSL 1.0.x n'est plus maintenu et présente des failles critiques",
    "apache_2.2": "Apache 2.2 est obsolète, migrez vers Apache 2.4",
    "nginx_1.14": "Nginx 1.14 est ancien, vérifiez les mises à jour",
    "php_5": "PHP 5.x n'est plus maintenu, migration urgente requise",
    "php_7.0": "PHP 7.0 n'est plus maintenu, passez à PHP 7.4+ ou 8.x",
    "vsftpd_2": "vsftpd 2.x présente des failles historiques",
    "proftpd_1.3.5": "ProFTPD 1.3.5 vulnérable à plusieurs CVE",
    "samba_3": "Samba 3.x obsolète, vulnérable à des exploits critiques",
    "samba_4.0": "Samba 4.0 ancien, mise à jour recommandée",
    "windows_xp": "Windows XP n'est plus supporté, vulnérabilités non corrigées",
    "windows_7": "Windows 7 n'est plus supporté, risque élevé",
    "windows_server_2008": "Windows Server 2008 obsolète, fin de support"
}


def verifier_ports_dangereux(donnees_hote: dict) -> list:
    """Vérifie si un hôte possède des ports considérés comme dangereux."""
    alertes = []
    
    for port in donnees_hote.get("ports_ouverts", []):
        if port in PORTS_DANGEREUX:
            alerte = PORTS_DANGEREUX[port].copy()
            alerte["port"] = port
            alerte["ip"] = donnees_hote["ip"]
            alertes.append(alerte)
        elif port in PORTS_A_SURVEILLER:
            # Alertes spécifiques
            if port == 22:
                alertes.append({
                    "port": 22,
                    "ip": donnees_hote["ip"],
                    "niveau": "FAIBLE",
                    "titre": "SSH accessible",
                    "description": "SSH est sécurisé, mais vérifiez que l'authentification par mot de passe est désactivée (clés privées recommandées).",
                    "conseil": "Utilisez l'authentification par clé SSH et désactivez root."
                })
            elif port == 3306:
                alertes.append({
                    "port": 3306,
                    "ip": donnees_hote["ip"],
                    "niveau": "MOYEN",
                    "titre": "MySQL exposé",
                    "description": "Une base de données MySQL accessible depuis le réseau local peut être vulnérable si les mots de passe sont faibles.",
                    "conseil": "Liez MySQL à 127.0.0.1 sauf si multi-serveur, utilisez des mots de passe forts."
                })
    
    return alertes


def verifier_configurations_dangereuses(donnees_hote: dict) -> list:
    """Vérifie des configurations spécifiques dangereuses."""
    alertes = []
    services = donnees_hote.get("services", {})
    
    for port, infos_service in services.items():
        banniere = infos_service.get("banniere", "").lower()
        nom_service = infos_service.get("service", "")
        nom_service_lower = nom_service.lower()
        version = infos_service.get("version", "").lower()
        
        # Vérifier HTTP sans HTTPS
        if port == 80 and 443 not in donnees_hote.get("ports_ouverts", []):
            alertes.append({
                "port": 80,
                "ip": donnees_hote["ip"],
                "niveau": "MOYEN",
                "titre": "HTTP sans HTTPS",
                "description": "Ce serveur web n'a pas de HTTPS configuré. Les données échangées sont lisibles par n'importe qui sur le réseau.",
                "conseil": "Installez un certificat SSL/TLS et redirigez le trafic HTTP vers HTTPS."
            })
        
        # Vérifier les versions vulnérables connues
        texte_complet = (banniere + " " + version + " " + nom_service_lower).lower()
        for motif, message in VERSIONS_VULNERABLES.items():
            motif_recherche = motif.replace("_", " ").lower()
            if motif_recherche in texte_complet:
                alertes.append({
                    "port": port,
                    "ip": donnees_hote["ip"],
                    "niveau": "CRITIQUE",
                    "titre": "Version obsolète / vulnérable détectée",
                    "description": message,
                    "conseil": "Mettez à jour immédiatement vers la dernière version stable."
                })
                break  # Une seule alerte par service
        
        # Alerte sur les credentials par défaut connus
        if nom_service in CREDENTIALS_DEFAUT:
            creds = CREDENTIALS_DEFAUT[nom_service]
            creds_str = ", ".join(creds)
            alertes.append({
                "port": port,
                "ip": donnees_hote["ip"],
                "niveau": "MOYEN",
                "titre": f"{nom_service} — Vérifiez les identifiants par défaut",
                "description": f"Les identifiants par défaut ({creds_str}) sont connus publiquement et souvent utilisés par les attaquants.",
                "conseil": "Changez immédiatement les mots de passe par défaut et désactivez les comptes inutiles."
            })
    
    return alertes


def executer_verifications_securite(liste_hotes: list) -> list:
    """Exécute toutes les vérifications de sécurité sur la liste des hôtes."""
    toutes_alertes = []
    
    for donnees_hote in liste_hotes:
        alertes_ports = verifier_ports_dangereux(donnees_hote)
        alertes_config = verifier_configurations_dangereuses(donnees_hote)
        donnees_hote["alertes"] = alertes_ports + alertes_config
        toutes_alertes.extend(donnees_hote["alertes"])
    
    return toutes_alertes


def afficher_rapport_alertes(liste_hotes: list):
    """Affiche un rapport vulgarisé des alertes de sécurité."""
    alertes_totales = []
    for donnees_hote in liste_hotes:
        alertes_totales.extend(donnees_hote.get("alertes", []))
    
    if not alertes_totales:
        console.print(Panel(
            "[bold green]✅ Aucune alerte majeure détectée !\n\n"
            "Votre réseau semble bien configuré, continuez à maintenir vos systèmes à jour.[/bold green]",
            title="État du réseau", border_style="green"
        ))
        return
    
    # Compteur par niveau
    compteur = {"CRITIQUE": 0, "MOYEN": 0, "FAIBLE": 0}
    for alerte in alertes_totales:
        compteur[alerte.get("niveau", "FAIBLE")] += 1
    
    console.print(Panel(
        f"[bold]Résumé des alertes de sécurité :[/bold]\n\n"
        f"[bold red]🔴 Critiques : {compteur['CRITIQUE']}[/bold red]\n"
        f"[bold yellow]🟡 Moyennes : {compteur['MOYEN']}[/bold yellow]\n"
        f"[bold blue]🔵 Faibles : {compteur['FAIBLE']}[/bold blue]",
        title="État de santé du réseau", border_style="yellow"
    ))
    
    table = Table(title="Détails des alertes de sécurité")
    table.add_column("IP", style="cyan", no_wrap=True)
    table.add_column("Port", style="magenta")
    table.add_column("Niveau", style="red")
    table.add_column("Alerte", style="yellow")
    table.add_column("Conseil", style="green")
    
    for alerte in alertes_totales:
        couleur_niveau = {
            "CRITIQUE": "[bold red]CRITIQUE[/bold red]",
            "MOYEN": "[bold yellow]MOYEN[/bold yellow]",
            "FAIBLE": "[bold blue]FAIBLE[/bold blue]"
        }.get(alerte["niveau"], alerte["niveau"])
        
        table.add_row(
            alerte.get("ip", "-"),
            str(alerte.get("port", "-")),
            couleur_niveau,
            alerte.get("titre", "Alerte"),
            alerte.get("conseil", "-")
        )
    
    console.print(table)
