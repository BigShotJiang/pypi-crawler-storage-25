"""Capture et analyse de trames réseau avec Scapy (optionnel)."""

from rich.console import Console
from rich.table import Table
from rich.panel import Panel

console = Console()


def paquet_vers_dictionnaire(paquet) -> dict:
    """Convertit un paquet Scapy en dictionnaire lisible."""
    infos = {
        "type": "Inconnu",
        "source": "",
        "destination": "",
        "protocole": "",
        "details": ""
    }
    
    try:
        if paquet.haslayer("ARP"):
            infos["type"] = "ARP"
            infos["source"] = paquet.psrc
            infos["destination"] = paquet.pdst
            infos["protocole"] = "ARP"
            infos["details"] = f"Requête ARP : {paquet.psrc} cherche {paquet.pdst}"
            
        elif paquet.haslayer("IP"):
            couche_ip = paquet["IP"]
            infos["source"] = couche_ip.src
            infos["destination"] = couche_ip.dst
            
            if paquet.haslayer("TCP"):
                couche_tcp = paquet["TCP"]
                infos["type"] = "TCP"
                infos["protocole"] = f"TCP port {couche_tcp.dport}"
                drapeaux = couche_tcp.sprintf("%TCP.flags%")
                infos["details"] = f"Flags : {drapeaux}"
                
            elif paquet.haslayer("UDP"):
                couche_udp = paquet["UDP"]
                infos["type"] = "UDP"
                infos["protocole"] = f"UDP port {couche_udp.dport}"
                infos["details"] = f"Longueur : {len(paquet)} octets"
                
            elif paquet.haslayer("ICMP"):
                infos["type"] = "ICMP"
                infos["protocole"] = "ICMP"
                infos["details"] = "Ping / Message de contrôle"
                
            else:
                infos["type"] = "IP"
                infos["protocole"] = f"Protocole {couche_ip.proto}"
                
        elif paquet.haslayer("IPv6"):
            infos["type"] = "IPv6"
            infos["source"] = paquet["IPv6"].src
            infos["destination"] = paquet["IPv6"].dst
            infos["protocole"] = "IPv6"
            
    except Exception as erreur:
        infos["details"] = f"Erreur d'analyse : {erreur}"
    
    return infos


def afficher_paquet(paquet):
    """Affiche un paquet capturé de manière vulgarisée."""
    infos = paquet_vers_dictionnaire(paquet)
    
    if infos["type"] == "ARP":
        console.print(f"[cyan][ARP][/cyan] {infos['source']} → {infos['destination']}")
    elif infos["type"] == "TCP":
        console.print(f"[green][TCP][/green] {infos['source']}:{paquet['TCP'].sport} → {infos['destination']}:{paquet['TCP'].dport} ({infos['details']})")
    elif infos["type"] == "UDP":
        console.print(f"[blue][UDP][/blue] {infos['source']} → {infos['destination']} ({infos['protocole']})")
    elif infos["type"] == "ICMP":
        console.print(f"[magenta][ICMP][/magenta] {infos['source']} → {infos['destination']} (Ping)")
    else:
        console.print(f"[white][{infos['type']}][/white] {infos['source']} → {infos['destination']}")


def capturer_trames(interface: str = None, nombre_max: int = 50, filtre: str = "arp or tcp or udp or icmp"):
    """Capture des trames réseau de manière ciblée."""
    try:
        from scapy.all import sniff
    except ImportError:
        console.print("[bold red]❌ Scapy n'est pas installé. Installez-le avec : pip install scapy[/bold red]")
        return []
    
    console.print(Panel.fit(
        f"[bold blue]📡 Capture de {nombre_max} paquets...[/bold blue]\n"
        f"Interface : {interface or 'défaut'}\n"
        f"Filtre : {filtre}\n\n"
        "[yellow]Appuyez sur Ctrl+C pour arrêter la capture[/yellow]",
        title="Capture de trames", border_style="blue"
    ))
    
    paquets_captures = []
    
    try:
        paquets_captures = sniff(
            iface=interface,
            prn=afficher_paquet,
            count=nombre_max,
            filter=filtre,
            store=True
        )
    except PermissionError:
        console.print("[bold red]❌ Permission refusée. Lancez la capture en tant qu'administrateur/root.[/bold red]")
    except Exception as erreur:
        console.print(f"[bold red]❌ Erreur de capture : {erreur}[/bold red]")
    
    console.print(f"\n[bold green]✅ {len(paquets_captures)} paquets capturés[/bold green]")
    
    # Affichage d'un résumé
    if paquets_captures:
        compteur_types = {}
        for paquet in paquets_captures:
            infos = paquet_vers_dictionnaire(paquet)
            type_paquet = infos["type"]
            compteur_types[type_paquet] = compteur_types.get(type_paquet, 0) + 1
        
        table = Table(title="Résumé de la capture")
        table.add_column("Type de paquet", style="cyan")
        table.add_column("Quantité", style="magenta")
        
        for type_paquet, quantite in sorted(compteur_types.items(), key=lambda x: x[1], reverse=True):
            table.add_row(type_paquet, str(quantite))
        
        console.print(table)
    
    return paquets_captures
