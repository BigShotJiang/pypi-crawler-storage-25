"""Interface en ligne de commande principale de netcheck."""

import argparse
import sys
from rich.console import Console
from rich.panel import Panel

from .security_utils import verifier_securite, verifier_prerequis_scapy
from .network_scanner import scanner_sous_reseau
from .service_detector import detecter_tous_les_services
from .cve_checker import verifier_vulnerabilites_hote
from .vuln_checks import executer_verifications_securite, afficher_rapport_alertes
from .packet_sniffer import capturer_trames
from .reporter import (
    afficher_resultats_scan,
    afficher_cves,
    afficher_etat_sante,
    exporter_json,
    exporter_html,
    calculer_etat_sante
)
from .web_security import verifier_securite_web_hote
from .os_fingerprint import estimer_os_hote

console = Console()


def analyser_arguments():
    """Configure et analyse les arguments de la ligne de commande."""
    analyseur = argparse.ArgumentParser(
        description="netcheck - Vulgarisation d'audit de sécurité réseau local",
        epilog="Exemple : netcheck --sous-reseau 192.168.1.0/24 --exporter rapport.json"
    )
    
    analyseur.add_argument(
        "--sous-reseau",
        default="192.168.1.0/24",
        help="Sous-réseau à scanner (défaut : 192.168.1.0/24)"
    )
    analyseur.add_argument(
        "--max-hotes",
        type=int,
        default=50,
        help="Nombre maximum d'hôtes à scanner (défaut : 50)"
    )
    analyseur.add_argument(
        "--ports",
        nargs="+",
        type=int,
        default=None,
        help="Ports personnalisés à scanner (ex: --ports 22 80 443 8080)"
    )
    analyseur.add_argument(
        "--verbose",
        action="store_true",
        help="Afficher plus de détails pendant le scan"
    )
    analyseur.add_argument(
        "--silencieux",
        action="store_true",
        help="Réduire les messages (mode silencieux)"
    )
    analyseur.add_argument(
        "--capture",
        action="store_true",
        help="Activer la capture de trames réseau (nécessite Scapy + droits admin)"
    )
    analyseur.add_argument(
        "--interface",
        help="Interface réseau pour la capture de trames"
    )
    analyseur.add_argument(
        "--paquets",
        type=int,
        default=50,
        help="Nombre de paquets à capturer (défaut : 50)"
    )
    analyseur.add_argument(
        "--exporter",
        help="Exporter le rapport au format JSON (ex: --exporter rapport.json)"
    )
    analyseur.add_argument(
        "--html",
        help="Exporter le rapport au format HTML (ex: --html rapport.html)"
    )
    analyseur.add_argument(
        "--web-security",
        action="store_true",
        help="Vérifier la sécurité web (headers HTTP, certificats SSL/TLS)"
    )
    analyseur.add_argument(
        "--pas-web-security",
        action="store_true",
        help="Désactiver la vérification de sécurité web"
    )
    analyseur.add_argument(
        "--os-detect",
        action="store_true",
        help="Activer la détection d'OS basée sur le TTL (nécessite les droits admin sur Windows)"
    )
    analyseur.add_argument(
        "--rapide",
        action="store_true",
        help="Mode rapide : skip la détection de services et les CVE (scan réseau + alertes uniquement)"
    )
    analyseur.add_argument(
        "--pas-cve",
        action="store_true",
        help="Désactiver la vérification des CVE (plus rapide)"
    )
    analyseur.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.1.0"
    )
    analyseur.add_argument(
        "--aide-commandes",
        action="store_true",
        help="Afficher le guide des commandes avec exemples"
    )
    
    return analyseur.parse_args()


def afficher_aide_commandes():
    """Affiche un guide vulgarisé des commandes disponibles."""
    console.print("[bold cyan]📖 Guide des commandes auditnet[/bold cyan]\n")
    
    console.print("[bold]Structure d'une commande :[/bold]")
    console.print("  auditnet [OPTIONS]\n")
    console.print("[dim]Sur Windows avec le launcher py : py -m netcheck [OPTIONS][/dim]\n")
    
    console.print("[bold]Arguments principaux :[/bold]")
    console.print("  [green]--sous-reseau[/green]   Le réseau à scanner (ex: 192.168.1.0/24)")
    console.print("  [green]--max-hotes[/green]     Nombre max d'appareils à scanner")
    console.print("  [green]--ports[/green]         Ports personnalisés à scanner")
    console.print("  [green]--verbose[/green]       Affiche plus de détails en direct")
    console.print("  [green]--silencieux[/green]    Mode silencieux (pour les scripts)")
    console.print("  [green]--rapide[/green]        Scan rapide (ports + alertes uniquement)")
    console.print("  [green]--os-detect[/green]     Détecte le système d'exploitation")
    console.print("  [green]--web-security[/green]  Vérifie les headers HTTP et certificats SSL")
    console.print("  [green]--pas-cve[/green]       Désactive la recherche de vulnérabilités")
    console.print("  [green]--exporter[/green]      Exporte un rapport JSON")
    console.print("  [green]--html[/green]          Exporte un rapport HTML")
    console.print("  [green]--capture[/green]       Capture les paquets réseau (nécessite admin)")
    console.print("  [green]--interface[/green]     Interface réseau pour la capture")
    console.print("  [green]--paquets[/green]       Nombre de paquets à capturer\n")
    
    console.print("[bold]Exemples pratiques :[/bold]\n")
    
    console.print("[yellow]1. Premier scan rapide (30 secondes)[/yellow]")
    console.print("  auditnet --rapide\n")
    
    console.print("[yellow]2. Scan complet avec rapport web[/yellow]")
    console.print("  auditnet --web-security --html rapport.html\n")
    
    console.print("[yellow]3. Scan ciblé sur des ports sensibles[/yellow]")
    console.print("  auditnet --ports 22 23 445 3389 --verbose\n")
    
    console.print("[yellow]4. Scan silencieux pour un script[/yellow]")
    console.print("  auditnet --silencieux --rapide --exporter resultats.json\n")
    
    console.print("[yellow]5. Audit complet (le plus poussé)[/yellow]")
    console.print("  auditnet --verbose --web-security --os-detect --html complet.html --exporter complet.json\n")
    
    console.print("[yellow]6. Capture de trames sur Wi-Fi[/yellow]")
    console.print("  auditnet --capture --interface \"Wi-Fi\" --paquets 100\n")
    
    console.print("[italic]Tapez auditnet --help pour la liste technique complète.[/italic]\n")


def main():
    """Point d'entrée principal de l'application."""
    arguments = analyser_arguments()
    
    if arguments.aide_commandes:
        afficher_aide_commandes()
        sys.exit(0)
    
    # Vérifications de sécurité au démarrage
    verifier_securite()
    
    if not arguments.silencieux:
        console.print(Panel.fit(
            "[bold cyan]🔍 auditnet[/bold cyan] - [white]Outil de vulgarisation d'audit réseau[/white]\n"
            "[italic]Scan simple, rapide et pédagogique[/italic]\n"
            "[dim]Par Korgho Sosthene et Ouedraogo Chakira - Projet tutoré : Audit de sécurité d'un réseau local[/dim]",
            border_style="cyan"
        ))
        console.print(f"[cyan]▶ Sous-réseau cible : {arguments.sous_reseau}[/cyan]\n")
    
    # Ports à scanner
    ports_a_scanner = arguments.ports
    if ports_a_scanner and arguments.verbose:
        console.print(f"[dim]Ports personnalisés : {ports_a_scanner}[/dim]")
    
    # Phase 1 : Scan réseau
    if not arguments.silencieux:
        console.print("[cyan]🔍 Recherche des hôtes actifs sur le réseau...[/cyan]")
        hotes = scanner_sous_reseau(
            arguments.sous_reseau,
            nombre_max_hotes=arguments.max_hotes,
            ports=ports_a_scanner
        )
    else:
        hotes = scanner_sous_reseau(
            arguments.sous_reseau,
            nombre_max_hotes=arguments.max_hotes,
            ports=ports_a_scanner
        )
    
    if not hotes:
        if not arguments.silencieux:
            console.print("\n[yellow]Aucun résultat à afficher. Fin de l'analyse.[/yellow]")
        sys.exit(0)
    
    # Phase 1b : Détection d'OS (optionnel)
    if arguments.os_detect:
        if not arguments.silencieux:
            console.print("\n[cyan]🖥️  Détection du système d'exploitation...[/cyan]")
        for donnees_hote in hotes:
            estimer_os_hote(donnees_hote)
            if not arguments.silencieux and donnees_hote.get("os_estime") != "Inconnu":
                console.print(f"  [dim]{donnees_hote['ip']} → OS estimé : {donnees_hote['os_estime']}[/dim]")
    
    # Phase 2 : Détection des services (sauté en mode rapide)
    if not arguments.rapide:
        if not arguments.silencieux:
            console.print("\n[cyan]🔎 Détection des services et versions...[/cyan]")
        for index, donnees_hote in enumerate(hotes):
            detecter_tous_les_services(donnees_hote)
            if arguments.verbose:
                for port, infos in donnees_hote.get("services", {}).items():
                    if infos.get("version"):
                        console.print(f"  [dim]{donnees_hote['ip']}:{port} → {infos['service']} {infos['version']}[/dim]")
            if not arguments.silencieux:
                console.print(f"  [green]✓[/green] {donnees_hote['ip']} ({len(donnees_hote['ports_ouverts'])} port(s))")
    else:
        if not arguments.silencieux:
            console.print("\n[yellow]⚡ Mode rapide : détection de services et CVE désactivées[/yellow]")
    
    # Phase 3 : Vérification CVE (optionnel, sauté en mode rapide)
    if not arguments.pas_cve and not arguments.rapide:
        if not arguments.silencieux:
            console.print("\n[cyan]🌐 Vérification des vulnérabilités connues (CVE)...[/cyan]")
            console.print("  [yellow]ℹ️  Cette étape peut prendre quelques minutes (limite API NVD)[/yellow]")
        for donnees_hote in hotes:
            verifier_vulnerabilites_hote(donnees_hote)
    
    # Phase 4 : Vérifications de sécurité
    if not arguments.silencieux:
        console.print("\n[cyan]🛡️  Analyse des configurations de sécurité...[/cyan]")
    executer_verifications_securite(hotes)
    
    # Phase 4b : Sécurité web (optionnel)
    if arguments.web_security and not arguments.pas_web_security:
        if not arguments.silencieux:
            console.print("\n[cyan]🌐 Vérification de la sécurité web (headers + SSL)...[/cyan]")
        for donnees_hote in hotes:
            verifier_securite_web_hote(donnees_hote)
    
    # Phase 5 : Affichage des résultats
    if not arguments.silencieux:
        console.print("\n" + "=" * 60)
        afficher_resultats_scan(hotes)
        
        console.print("\n" + "=" * 60)
        if not arguments.pas_cve:
            afficher_cves(hotes)
        
        console.print("\n" + "=" * 60)
        afficher_rapport_alertes(hotes)
        
        console.print("\n" + "=" * 60)
        afficher_etat_sante(hotes)
    
    # Phase 6 : Capture de trames (optionnel)
    if arguments.capture:
        if not arguments.silencieux:
            console.print("\n" + "=" * 60)
        if verifier_prerequis_scapy():
            capturer_trames(
                interface=arguments.interface,
                nombre_max=arguments.paquets
            )
        else:
            if not arguments.silencieux:
                console.print("[yellow]⚠️  Capture ignorée (prérequis manquants)[/yellow]")
    
    # Phase 7 : Export JSON
    if arguments.exporter:
        if not arguments.silencieux:
            console.print("\n" + "=" * 60)
        exporter_json(hotes, arguments.exporter)
    
    # Phase 8 : Export HTML
    if arguments.html:
        if not arguments.silencieux:
            console.print("\n" + "=" * 60)
        exporter_html(hotes, arguments.html)
    
    if not arguments.silencieux:
        console.print("\n[bold green]✅ Analyse terminée ![/bold green]\n")
    else:
        console.print(f"\nScore: {calculer_etat_sante(hotes)['score']}/100 | Hôtes: {len(hotes)}")


if __name__ == "__main__":
    main()
