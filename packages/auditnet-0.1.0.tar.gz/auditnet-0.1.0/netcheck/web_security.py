"""Vérifications de sécurité web : headers HTTP et certificats SSL/TLS."""

import socket
import ssl
import requests
from urllib.parse import urlsplit
from datetime import datetime
from rich.console import Console

console = Console()

# Headers de sécurité recommandés et leur description vulgarisée
HEADERS_SECURITE = {
    "Strict-Transport-Security": {
        "nom_vulgarise": "HSTS (Forçage HTTPS)",
        "description": "Force le navigateur à toujours utiliser HTTPS. Empêche les attaques de rétrogradation.",
        "niveau": "IMPORTANT"
    },
    "X-Frame-Options": {
        "nom_vulgarise": "Protection anti-clickjacking",
        "description": "Empêche votre site d'être intégré dans un iframe malveillant (attaques clickjacking).",
        "niveau": "IMPORTANT"
    },
    "X-Content-Type-Options": {
        "nom_vulgarise": "Protection MIME-sniffing",
        "description": "Empêche le navigateur de deviner le type de fichier (évite l'exécution de fichiers malveillants).",
        "niveau": "IMPORTANT"
    },
    "Content-Security-Policy": {
        "nom_vulgarise": "CSP (Politique de contenu)",
        "description": "Contrôle les sources de contenu autorisées (scripts, images, etc.). Protection XSS avancée.",
        "niveau": "RECOMMANDE"
    },
    "X-XSS-Protection": {
        "nom_vulgarise": "Filtre anti-XSS (legacy)",
        "description": "Ancien mécanisme de protection contre les attaques XSS. Moins utile si CSP est présent.",
        "niveau": "FAIBLE"
    },
    "Referrer-Policy": {
        "nom_vulgarise": "Contrôle du referrer",
        "description": "Contrôle quelles informations sont envoyées lors des clics sur des liens externes.",
        "niveau": "RECOMMANDE"
    },
    "Permissions-Policy": {
        "nom_vulgarise": "Contrôle des permissions",
        "description": "Limite les fonctionnalités du navigateur utilisables (caméra, micro, géolocalisation, etc.).",
        "niveau": "RECOMMANDE"
    }
}


def verifier_headers_http(url: str, delai: float = 5.0) -> dict:
    """Vérifie les headers de sécurité d'un serveur web HTTP/HTTPS."""
    resultat = {
        "url": url,
        "accessible": False,
        "headers_manquants": [],
        "headers_presents": {},
        "alertes": []
    }
    
    # S'assurer que l'URL a un scheme
    if not url.startswith("http://") and not url.startswith("https://"):
        url = f"http://{url}"
    
    try:
        reponse = requests.get(url, timeout=delai, allow_redirects=True, verify=False)
        resultat["accessible"] = True
        resultat["url_finale"] = reponse.url
        resultat["status_code"] = reponse.status_code
        
        headers = {k.lower(): v for k, v in reponse.headers.items()}
        
        # Vérifier chaque header de sécurité
        for header_nom, infos in HEADERS_SECURITE.items():
            header_lower = header_nom.lower()
            if header_lower in headers:
                resultat["headers_presents"][header_nom] = headers[header_lower]
            else:
                resultat["headers_manquants"].append({
                    "header": header_nom,
                    "nom_vulgarise": infos["nom_vulgarise"],
                    "description": infos["description"],
                    "niveau": infos["niveau"]
                })
        
        # Alerte si HTTP sans redirect vers HTTPS
        parsed = urlsplit(resultat["url_finale"])
        if parsed.scheme == "http":
            resultat["alertes"].append({
                "niveau": "CRITIQUE",
                "titre": "Site accessible en HTTP (sans chiffrement)",
                "description": "Les données échangées avec ce site ne sont pas chiffrées. Tout le réseau peut les lire.",
                "conseil": "Activez HTTPS et redirigez le trafic HTTP vers HTTPS."
            })
        
        # Vérifier si HSTS est présent sur HTTPS
        if parsed.scheme == "https" and "strict-transport-security" not in headers:
            resultat["alertes"].append({
                "niveau": "MOYEN",
                "titre": "HTTPS sans HSTS",
                "description": "Le site utilise HTTPS mais n'envoie pas l'en-tête HSTS. Un attaquant pourrait forcer la connexion en HTTP.",
                "conseil": "Ajoutez l'en-tête Strict-Transport-Security."
            })
        
    except requests.exceptions.ConnectionError:
        resultat["alertes"].append({
            "niveau": "INFO",
            "titre": "Service web inaccessible",
            "description": f"Impossible de se connecter à {url}",
            "conseil": "Vérifiez que le service web est en cours d'exécution."
        })
    except requests.exceptions.Timeout:
        resultat["alertes"].append({
            "niveau": "INFO",
            "titre": "Délai dépassé",
            "description": f"Le serveur n'a pas répondu dans les {delai}s.",
            "conseil": "Vérifiez la connectivité réseau."
        })
    except Exception as erreur:
        resultat["alertes"].append({
            "niveau": "INFO",
            "titre": "Erreur de vérification web",
            "description": str(erreur),
            "conseil": "Vérifiez l'URL et la connectivité."
        })
    
    return resultat


def verifier_certificat_ssl(adresse_ip: str, port: int = 443, delai: float = 5.0) -> dict:
    """Vérifie le certificat SSL/TLS d'un serveur."""
    resultat = {
        "ip": adresse_ip,
        "port": port,
        "certificat_present": False,
        "alertes": [],
        "infos": {}
    }
    
    try:
        contexte = ssl.create_default_context()
        contexte.check_hostname = False
        contexte.verify_mode = ssl.CERT_NONE
        
        with socket.create_connection((adresse_ip, port), timeout=delai) as sock:
            with contexte.wrap_socket(sock, server_hostname=adresse_ip) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
                version_tls = ssock.version()
                
                resultat["certificat_present"] = True
                resultat["infos"] = {
                    "sujet": cert.get("subject"),
                    "emetteur": cert.get("issuer"),
                    "date_debut": cert.get("notBefore"),
                    "date_fin": cert.get("notAfter"),
                    "version_tls": version_tls,
                    "cipher": cipher[0] if cipher else "Inconnu"
                }
                
                # Vérifier la date d'expiration
                if cert.get("notAfter"):
                    try:
                        date_exp = datetime.strptime(cert["notAfter"], "%b %d %H:%M:%S %Y %Z")
                        jours_restants = (date_exp - datetime.utcnow()).days
                        resultat["infos"]["jours_restants"] = jours_restants
                        
                        if jours_restants < 0:
                            resultat["alertes"].append({
                                "niveau": "CRITIQUE",
                                "titre": "Certificat SSL expiré",
                                "description": f"Le certificat a expiré il y a {abs(jours_restants)} jours.",
                                "conseil": "Renouvelez immédiatement le certificat SSL/TLS."
                            })
                        elif jours_restants < 30:
                            resultat["alertes"].append({
                                "niveau": "MOYEN",
                                "titre": "Certificat SSL bientôt expiré",
                                "description": f"Le certificat expire dans {jours_restants} jours.",
                                "conseil": "Prévoyez le renouvellement du certificat."
                            })
                    except ValueError:
                        pass
                
                # Vérifier la version TLS
                if version_tls in ["TLSv1", "TLSv1.1"]:
                    resultat["alertes"].append({
                        "niveau": "CRITIQUE",
                        "titre": "Version TLS obsolète",
                        "description": f"Le serveur utilise {version_tls}, qui est obsolète et non sécurisé.",
                        "conseil": "Passez à TLS 1.2 minimum (TLS 1.3 recommandé)."
                    })
                elif version_tls == "TLSv1.2":
                    resultat["alertes"].append({
                        "niveau": "FAIBLE",
                        "titre": "TLS 1.2 (pas le plus récent)",
                        "description": "TLS 1.2 est acceptable mais TLS 1.3 offre de meilleures performances et sécurité.",
                        "conseil": "Envisagez de passer à TLS 1.3 si possible."
                    })
                
                # Vérifier si auto-signé (sujet == émetteur)
                sujet = cert.get("subject")
                emetteur = cert.get("issuer")
                if sujet and emetteur and sujet == emetteur:
                    resultat["alertes"].append({
                        "niveau": "MOYEN",
                        "titre": "Certificat auto-signé",
                        "description": "Le certificat est auto-signé. Les navigateurs afficheront un avertissement.",
                        "conseil": "Utilisez un certificat émis par une autorité de confiance (Let's Encrypt, etc.)."
                    })
                
    except socket.timeout:
        resultat["alertes"].append({
            "niveau": "INFO",
            "titre": "Connexion SSL timeout",
            "description": f"Impossible de se connecter en SSL à {adresse_ip}:{port}",
            "conseil": "Vérifiez que le service HTTPS est actif."
        })
    except ConnectionRefusedError:
        resultat["alertes"].append({
            "niveau": "INFO",
            "titre": "Connexion SSL refusée",
            "description": f"Le port {port} refuse la connexion SSL.",
            "conseil": "Vérifiez que le service est en cours d'exécution."
        })
    except Exception as erreur:
        resultat["alertes"].append({
            "niveau": "INFO",
            "titre": "Erreur SSL",
            "description": str(erreur),
            "conseil": "Vérifiez la configuration SSL/TLS."
        })
    
    return resultat


def verifier_securite_web_hote(donnees_hote: dict) -> dict:
    """Vérifie la sécurité web d'un hôte (headers HTTP + SSL si ports 80/443 ouverts)."""
    adresse_ip = donnees_hote["ip"]
    ports_ouverts = donnees_hote.get("ports_ouverts", [])
    
    donnees_hote["securite_web"] = {
        "headers_http": None,
        "certificat_ssl": None
    }
    
    # Vérifier headers HTTP si port 80 ou 8080 ouvert
    if 80 in ports_ouverts:
        donnees_hote["securite_web"]["headers_http"] = verifier_headers_http(f"http://{adresse_ip}")
    elif 8080 in ports_ouverts:
        donnees_hote["securite_web"]["headers_http"] = verifier_headers_http(f"http://{adresse_ip}:8080")
    
    # Vérifier certificat SSL si port 443 ouvert
    if 443 in ports_ouverts:
        donnees_hote["securite_web"]["certificat_ssl"] = verifier_certificat_ssl(adresse_ip, 443)
    
    # Ajouter les alertes web aux alertes générales
    if donnees_hote["securite_web"]["headers_http"]:
        for alerte in donnees_hote["securite_web"]["headers_http"].get("alertes", []):
            alerte["ip"] = adresse_ip
            donnees_hote["alertes"].append(alerte)
    
    if donnees_hote["securite_web"]["certificat_ssl"]:
        for alerte in donnees_hote["securite_web"]["certificat_ssl"].get("alertes", []):
            alerte["ip"] = adresse_ip
            donnees_hote["alertes"].append(alerte)
    
    return donnees_hote
