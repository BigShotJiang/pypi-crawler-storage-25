"""Affichage des résultats et export de rapports."""

import json
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

console = Console()


def afficher_resultats_scan(liste_hotes: list):
    """Affiche les résultats du scan dans un tableau coloré et vulgarisé."""
    if not liste_hotes:
        console.print(Panel(
            "[yellow]Aucun hôte actif avec des ports ouverts n'a été trouvé.[/yellow]\n"
            "Vérifiez que vous êtes connecté au bon réseau et que les appareils sont allumés.",
            title="Résultats", border_style="yellow"
        ))
        return
    
    console.print(f"\n[bold cyan]📊 Résultats du scan réseau[/bold cyan]\n")
    
    table = Table(title=f"{len(liste_hotes)} hôte(s) trouvé(s)")
    table.add_column("Adresse IP", style="cyan", no_wrap=True)
    table.add_column("Ports ouverts", style="magenta")
    table.add_column("Services détectés", style="green")
    table.add_column("Versions", style="yellow")
    table.add_column("OS estimé", style="blue")
    
    for donnees_hote in liste_hotes:
        adresse_ip = donnees_hote["ip"]
        ports = ", ".join(str(p) for p in donnees_hote["ports_ouverts"])
        
        services = []
        versions = []
        for port, infos_service in donnees_hote.get("services", {}).items():
            nom_service = infos_service.get("service", "Inconnu")
            version = infos_service.get("version", "?")
            services.append(f"{port}/{nom_service}")
            versions.append(version if version else "?")
        
        os_estime = donnees_hote.get("os_estime", "Inconnu")
        os_texte = os_estime if os_estime != "Inconnu" else "—"
        
        table.add_row(
            adresse_ip,
            ports,
            "\n".join(services) if services else "—",
            "\n".join(versions) if versions else "—",
            os_texte
        )
    
    console.print(table)


def afficher_cves(liste_hotes: list):
    """Affiche les CVE trouvées de manière vulgarisée."""
    cves_totales = []
    for donnees_hote in liste_hotes:
        for vuln in donnees_hote.get("vulnerabilites", []):
            cves_totales.append(vuln)
    
    if not cves_totales:
        console.print("\n[bold green]✅ Aucune CVE connue détectée sur les services identifiés.[/bold green]\n")
        return
    
    console.print(f"\n[bold red]⚠️  {len(cves_totales)} CVE potentielle(s) détectée(s)[/bold red]\n")
    
    table = Table(title="Vulnérabilités potentielles")
    table.add_column("IP", style="cyan", no_wrap=True)
    table.add_column("Service", style="magenta")
    table.add_column("CVE", style="red", no_wrap=True)
    table.add_column("Sévérité", style="yellow")
    table.add_column("Description", style="white")
    
    for vuln in cves_totales:
        score = vuln.get("score")
        severite = vuln.get("severite", "Inconnue")
        
        if score:
            texte_severite = f"{severite} ({score})"
        else:
            texte_severite = severite
        
        table.add_row(
            vuln.get("ip", "?"),
            f"{vuln.get('service', '?')} {vuln.get('version', '')}",
            vuln.get("cve_id", "?"),
            texte_severite,
            vuln.get("description", "Pas de description")[:80]
        )
    
    console.print(table)
    console.print("\n[yellow]ℹ️  Ces CVE sont des vulnérabilités publiquement connues. "
                  "Vérifiez sur le site du fabricant si un patch est disponible.[/yellow]\n")


def calculer_etat_sante(liste_hotes: list) -> dict:
    """Calcule l'état de santé global du réseau."""
    total_alertes = 0
    total_cves = 0
    total_ports = 0
    total_hotes = len(liste_hotes)
    
    for donnees_hote in liste_hotes:
        total_ports += len(donnees_hote.get("ports_ouverts", []))
        total_alertes += len(donnees_hote.get("alertes", []))
        total_cves += len(donnees_hote.get("vulnerabilites", []))
    
    # Score simple : plus il y a d'alertes et de CVE, plus le score est bas
    score_base = 100
    score_base -= total_alertes * 10
    score_base -= total_cves * 5
    score_base = max(0, min(100, score_base))
    
    if score_base >= 80:
        etat = "[bold green]🟢 Bon[/bold green]"
        message = "Votre réseau semble globalement sécurisé. Continuez à surveiller les mises à jour."
    elif score_base >= 50:
        etat = "[bold yellow]🟡 Moyen[/bold yellow]"
        message = "Quelques problèmes à régler. Passez en revue les alertes et appliquez les conseils."
    else:
        etat = "[bold red]🔴 Critique[/bold red]"
        message = "Votre réseau présente plusieurs failles importantes. Action recommandée immédiate."
    
    return {
        "score": score_base,
        "etat": etat,
        "message": message,
        "total_hotes": total_hotes,
        "total_ports": total_ports,
        "total_alertes": total_alertes,
        "total_cves": total_cves
    }


def afficher_etat_sante(liste_hotes: list):
    """Affiche un résumé de l'état de santé du réseau."""
    sante = calculer_etat_sante(liste_hotes)
    
    console.print(Panel(
        f"[bold]État du réseau :[/bold] {sante['etat']}\n\n"
        f"[white]Score de sécurité :[/white] [bold]{sante['score']}/100[/bold]\n"
        f"[white]Hôtes scannés :[/white] {sante['total_hotes']}\n"
        f"[white]Ports ouverts :[/white] {sante['total_ports']}\n"
        f"[white]Alertes de sécurité :[/white] {sante['total_alertes']}\n"
        f"[white]CVE détectées :[/white] {sante['total_cves']}\n\n"
        f"[italic]{sante['message']}[/italic]",
        title="🩺 État de santé du réseau", border_style="cyan"
    ))


def exporter_json(liste_hotes: list, chemin_fichier: str):
    """Exporte les résultats au format JSON."""
    rapport = {
        "date_generation": datetime.now().isoformat(),
        "outil": "netcheck",
        "version": "0.1.0",
        "etat_sante": calculer_etat_sante(liste_hotes),
        "hotes": liste_hotes
    }
    
    try:
        with open(chemin_fichier, "w", encoding="utf-8") as fichier:
            json.dump(rapport, fichier, indent=2, ensure_ascii=False)
        console.print(f"\n[bold green]✅ Rapport exporté : {chemin_fichier}[/bold green]")
    except Exception as erreur:
        console.print(f"\n[bold red]❌ Erreur d'export : {erreur}[/bold red]")


def _html_escape(texte: str) -> str:
    """Échappe les caractères spéciaux HTML."""
    if not isinstance(texte, str):
        texte = str(texte)
    return (texte
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
            .replace("'", "&#x27;"))


def _generer_html_alertes(liste_hotes: list) -> str:
    """Génère le HTML pour les alertes."""
    alertes_html = ""
    for donnees_hote in liste_hotes:
        for alerte in donnees_hote.get("alertes", []):
            couleur = {
                "CRITIQUE": "#e74c3c",
                "MOYEN": "#f39c12",
                "FAIBLE": "#3498db"
            }.get(alerte.get("niveau", "FAIBLE"), "#95a5a6")
            alertes_html += f"""
            <tr>
                <td>{_html_escape(donnees_hote['ip'])}</td>
                <td>{_html_escape(alerte.get('port', '-'))}</td>
                <td><span style="color:{couleur};font-weight:bold;">{_html_escape(alerte.get('niveau', 'FAIBLE'))}</span></td>
                <td>{_html_escape(alerte.get('titre', ''))}</td>
                <td>{_html_escape(alerte.get('conseil', ''))}</td>
            </tr>
            """
    return alertes_html


def _generer_html_cves(liste_hotes: list) -> str:
    """Génère le HTML pour les CVE."""
    cves_html = ""
    for donnees_hote in liste_hotes:
        for vuln in donnees_hote.get("vulnerabilites", []):
            score = vuln.get("score")
            severite = vuln.get("severite", "Inconnue")
            if score:
                texte_severite = f"{_html_escape(severite)} ({score})"
            else:
                texte_severite = _html_escape(severite)
            cves_html += f"""
            <tr>
                <td>{_html_escape(donnees_hote['ip'])}</td>
                <td>{_html_escape(vuln.get('service', '?'))} {_html_escape(vuln.get('version', ''))}</td>
                <td><a href="https://nvd.nist.gov/vuln/detail/{_html_escape(vuln.get('cve_id', ''))}" target="_blank">{_html_escape(vuln.get('cve_id', '?'))}</a></td>
                <td>{texte_severite}</td>
                <td>{_html_escape(vuln.get('description', 'Pas de description')[:120])}</td>
            </tr>
            """
    return cves_html


def _generer_html_hotes(liste_hotes: list) -> str:
    """Génère le HTML pour les hôtes."""
    hotes_html = ""
    for donnees_hote in liste_hotes:
        ports = ", ".join(str(p) for p in donnees_hote.get("ports_ouverts", []))
        services = []
        for port, infos in donnees_hote.get("services", {}).items():
            services.append(f"{_html_escape(infos.get('service', 'Inconnu'))} (port {port}) — {_html_escape(infos.get('version', '?'))}")
        
        alertes_count = len(donnees_hote.get("alertes", []))
        cves_count = len(donnees_hote.get("vulnerabilites", []))
        
        hotes_html += f"""
        <div class="host-card">
            <h3>🖥️ {_html_escape(donnees_hote['ip'])}</h3>
            <p><strong>Ports ouverts :</strong> {_html_escape(ports)}</p>
            <p><strong>Services :</strong></p>
            <ul>{''.join(f'<li>{s}</li>' for s in services) or '<li>Aucun service identifié</li>'}</ul>
            <p><strong>Alertes :</strong> <span style="color:{'#e74c3c' if alertes_count > 0 else '#2ecc71'};">{alertes_count}</span></p>
            <p><strong>CVE :</strong> <span style="color:{'#e74c3c' if cves_count > 0 else '#2ecc71'};">{cves_count}</span></p>
        </div>
        """
    return hotes_html


def _generer_html_web(liste_hotes: list) -> str:
    """Génère le HTML pour la sécurité web."""
    web_html = ""
    for donnees_hote in liste_hotes:
        sec_web = donnees_hote.get("securite_web", {})
        if not sec_web:
            continue
        
        headers = sec_web.get("headers_http")
        ssl_info = sec_web.get("certificat_ssl")
        
        if headers and headers.get("accessible"):
            web_html += f"""
            <div class="web-card">
                <h4>🌐 {_html_escape(donnees_hote['ip'])} — Headers HTTP</h4>
                <p><strong>URL :</strong> {_html_escape(headers.get('url_finale', ''))}</p>
                <p><strong>Headers manquants :</strong></p>
                <ul>
            """
            for h in headers.get("headers_manquants", []):
                web_html += f"<li><strong>{_html_escape(h['header'])}</strong> ({_html_escape(h['nom_vulgarise'])}) — {_html_escape(h['description'])}</li>"
            if not headers.get("headers_manquants"):
                web_html += "<li style='color:#2ecc71;'>Tous les headers de sécurité sont présents !</li>"
            web_html += "</ul></div>"
        
        if ssl_info and ssl_info.get("certificat_present"):
            infos = ssl_info.get("infos", {})
            web_html += f"""
            <div class="web-card">
                <h4>🔒 {_html_escape(donnees_hote['ip'])} — Certificat SSL/TLS</h4>
                <p><strong>Version TLS :</strong> {_html_escape(infos.get('version_tls', 'Inconnu'))}</p>
                <p><strong>Cipher :</strong> {_html_escape(infos.get('cipher', 'Inconnu'))}</p>
                <p><strong>Jours restants :</strong> {_html_escape(infos.get('jours_restants', 'Inconnu'))}</p>
            </div>
            """
    return web_html


def exporter_html(liste_hotes: list, chemin_fichier: str):
    """Exporte les résultats au format HTML avec un rapport vulgarisé et coloré."""
    sante = calculer_etat_sante(liste_hotes)
    couleur_score = "#2ecc71" if sante["score"] >= 80 else "#f39c12" if sante["score"] >= 50 else "#e74c3c"
    
    alertes_html = _generer_html_alertes(liste_hotes)
    cves_html = _generer_html_cves(liste_hotes)
    hotes_html = _generer_html_hotes(liste_hotes)
    web_html = _generer_html_web(liste_hotes)
    
    html = f"""<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapport netcheck — Audit réseau</title>
    <style>
        :root {{
            --bg: #f8f9fa;
            --card: #ffffff;
            --text: #2c3e50;
            --primary: #3498db;
            --danger: #e74c3c;
            --warning: #f39c12;
            --success: #2ecc71;
            --info: #9b59b6;
        }}
        * {{ box-sizing: border-box; }}
        body {{
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            background: var(--bg);
            color: var(--text);
            margin: 0;
            padding: 0;
            line-height: 1.6;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }}
        header {{
            text-align: center;
            padding: 2rem 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 12px;
            margin-bottom: 2rem;
        }}
        header h1 {{ margin: 0; font-size: 2.2rem; }}
        header p {{ margin: 0.5rem 0 0; opacity: 0.9; }}
        .score-card {{
            background: var(--card);
            border-radius: 12px;
            padding: 2rem;
            text-align: center;
            margin-bottom: 2rem;
            box-shadow: 0 4px 6px rgba(0,0,0,0.07);
        }}
        .score-circle {{
            width: 140px;
            height: 140px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem;
            font-size: 2.5rem;
            font-weight: bold;
            color: white;
            background: {couleur_score};
        }}
        .grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }}
        .stat-card {{
            background: var(--card);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            text-align: center;
        }}
        .stat-card h3 {{ margin: 0 0 0.5rem; font-size: 2rem; }}
        .stat-card p {{ margin: 0; color: #7f8c8d; }}
        section {{
            background: var(--card);
            border-radius: 12px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }}
        section h2 {{
            margin-top: 0;
            border-bottom: 2px solid var(--primary);
            padding-bottom: 0.5rem;
            display: inline-block;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }}
        th, td {{
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #ecf0f1;
        }}
        th {{
            background: #f1f2f6;
            font-weight: 600;
        }}
        tr:hover {{ background: #f8f9fa; }}
        .host-card {{
            border: 1px solid #ecf0f1;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            background: #fdfdfd;
        }}
        .host-card h3 {{ margin-top: 0; color: var(--primary); }}
        .web-card {{
            border-left: 4px solid var(--info);
            padding: 1rem 1.5rem;
            margin-bottom: 1rem;
            background: #faf5ff;
        }}
        .web-card h4 {{ margin-top: 0; color: var(--info); }}
        footer {{
            text-align: center;
            color: #95a5a6;
            padding: 2rem 0;
        }}
        a {{ color: var(--primary); text-decoration: none; }}
        a:hover {{ text-decoration: underline; }}
        @media print {{
            body {{ background: white; }}
            .container {{ max-width: 100%; padding: 0; }}
            header {{ border-radius: 0; }}
        }}
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🔍 Rapport netcheck</h1>
            <p>Audit de sécurité réseau — {_html_escape(datetime.now().strftime('%d/%m/%Y %H:%M'))}</p>
        </header>

        <div class="score-card">
            <div class="score-circle">{sante['score']}</div>
            <h2>État du réseau : {_html_escape(sante['etat'].replace('[bold green]', '').replace('[bold yellow]', '').replace('[bold red]', '').replace('[/bold green]', '').replace('[/bold yellow]', '').replace('[/bold red]', ''))}</h2>
            <p>{_html_escape(sante['message'])}</p>
        </div>

        <div class="grid">
            <div class="stat-card">
                <h3>{sante['total_hotes']}</h3>
                <p>Hôtes scannés</p>
            </div>
            <div class="stat-card">
                <h3>{sante['total_ports']}</h3>
                <p>Ports ouverts</p>
            </div>
            <div class="stat-card">
                <h3 style="color:var(--warning);">{sante['total_alertes']}</h3>
                <p>Alertes sécurité</p>
            </div>
            <div class="stat-card">
                <h3 style="color:var(--danger);">{sante['total_cves']}</h3>
                <p>CVE détectées</p>
            </div>
        </div>

        <section>
            <h2>🖥️ Hôtes détectés</h2>
            {hotes_html if hotes_html else '<p>Aucun hôte actif trouvé.</p>'}
        </section>

        <section>
            <h2>🛡️ Alertes de sécurité</h2>
            <table>
                <thead>
                    <tr><th>IP</th><th>Port</th><th>Niveau</th><th>Alerte</th><th>Conseil</th></tr>
                </thead>
                <tbody>
                    {alertes_html if alertes_html else '<tr><td colspan="5" style="text-align:center;color:#7f8c8d;">Aucune alerte majeure détectée !</td></tr>'}
                </tbody>
            </table>
        </section>

        <section>
            <h2>⚠️ Vulnérabilités connues (CVE)</h2>
            <table>
                <thead>
                    <tr><th>IP</th><th>Service</th><th>CVE</th><th>Sévérité</th><th>Description</th></tr>
                </thead>
                <tbody>
                    {cves_html if cves_html else '<tr><td colspan="5" style="text-align:center;color:#7f8c8d;">Aucune CVE détectée sur les services identifiés.</td></tr>'}
                </tbody>
            </table>
        </section>

        {f'<section><h2>🌐 Sécurité web</h2>{web_html}</section>' if web_html else ''}

        <footer>
            <p>Généré par <strong>netcheck</strong> — Outil de vulgarisation d'audit réseau</p>
            <p style="font-size:0.9rem;">Usage éthique et pédagogique uniquement. Ne scannez que des réseaux dont vous êtes propriétaire ou autorisé.</p>
        </footer>
    </div>
</body>
</html>"""
    
    try:
        with open(chemin_fichier, "w", encoding="utf-8") as fichier:
            fichier.write(html)
        console.print(f"\n[bold green]✅ Rapport HTML exporté : {chemin_fichier}[/bold green]")
    except Exception as erreur:
        console.print(f"\n[bold red]❌ Erreur d'export HTML : {erreur}[/bold red]")
