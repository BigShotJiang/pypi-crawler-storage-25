"""Tests pour le module service_detector."""

import unittest
from unittest.mock import patch, MagicMock
from netcheck.service_detector import (
    recuperer_banniere,
    detecter_service,
    detecter_tous_les_services,
    SERVICES_PAR_PORT
)


class TestRecupererBanniere(unittest.TestCase):
    def test_banniere_ssh(self):
        with patch("netcheck.service_detector.socket.socket") as mock_sock:
            instance = mock_sock.return_value
            instance.recv.return_value = b"SSH-2.0-OpenSSH_8.2p1 Ubuntu-4ubuntu0.5\r\n"
            banniere = recuperer_banniere("127.0.0.1", 22)
            self.assertIn("OpenSSH", banniere)

    def test_banniere_http(self):
        with patch("netcheck.service_detector.socket.socket") as mock_sock:
            instance = mock_sock.return_value
            instance.recv.return_value = b"HTTP/1.1 200 OK\r\nServer: Apache/2.4.41\r\n"
            banniere = recuperer_banniere("127.0.0.1", 80)
            self.assertIn("Apache", banniere)

    def test_connexion_refusee(self):
        with patch("netcheck.service_detector.socket.socket") as mock_sock:
            instance = mock_sock.return_value
            instance.connect.side_effect = ConnectionRefusedError
            banniere = recuperer_banniere("127.0.0.1", 9999)
            self.assertEqual(banniere, "")


class TestDetecterService(unittest.TestCase):
    def test_detection_ssh(self):
        with patch("netcheck.service_detector.recuperer_banniere") as mock_ban:
            mock_ban.return_value = "SSH-2.0-OpenSSH_8.2p1"
            resultat = detecter_service("127.0.0.1", 22)
            self.assertEqual(resultat["service"], "SSH")
            self.assertEqual(resultat["version"], "OpenSSH_8.2p1")

    def test_detection_http(self):
        with patch("netcheck.service_detector.recuperer_banniere") as mock_ban:
            mock_ban.return_value = "Server: nginx/1.18.0"
            resultat = detecter_service("127.0.0.1", 80)
            self.assertEqual(resultat["service"], "HTTP")
            self.assertEqual(resultat["version"], "nginx/1.18.0")

    def test_service_inconnu(self):
        with patch("netcheck.service_detector.recuperer_banniere") as mock_ban:
            mock_ban.return_value = ""
            resultat = detecter_service("127.0.0.1", 12345)
            self.assertEqual(resultat["service"], "Inconnu")


class TestServicesParPort(unittest.TestCase):
    def test_ports_connus(self):
        self.assertEqual(SERVICES_PAR_PORT[22], "SSH")
        self.assertEqual(SERVICES_PAR_PORT[80], "HTTP")
        self.assertEqual(SERVICES_PAR_PORT[443], "HTTPS")


if __name__ == "__main__":
    unittest.main()
