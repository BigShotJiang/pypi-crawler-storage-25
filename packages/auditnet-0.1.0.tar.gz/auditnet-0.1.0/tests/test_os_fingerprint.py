"""Tests pour le module os_fingerprint."""

import unittest
from unittest.mock import patch, MagicMock
from netcheck.os_fingerprint import obtenir_ttl_os, estimer_os_hote, TTL_OS


class TestObtenirTtlOs(unittest.TestCase):
    @patch("netcheck.os_fingerprint.socket.socket")
    def test_ttl_linux(self, mock_sock):
        instance = mock_sock.return_value
        instance.__enter__ = MagicMock(return_value=instance)
        instance.__exit__ = MagicMock(return_value=False)
        
        # Simuler une réponse ICMP avec TTL=64 (Linux)
        import struct
        header_ip = struct.pack("!BBHHHBBH4s4s", 
                                0x45, 0, 0, 0, 0, 64, 1, 0, b'\x00\x00\x00\x00', b'\x00\x00\x00\x00')
        header_icmp = struct.pack("!BBHHH", 0, 0, 0, 0, 0)
        
        # select.select retourne ([sock], [], [])
        with patch("builtins.__import__", side_effect=lambda name, *args, **kwargs: __import__(name, *args, **kwargs)):
            pass
        
        # On simule le recvfrom directement en mockant select
        import select as select_module
        original_select = select_module.select
        
        def fake_select(rlist, wlist, xlist, timeout=None):
            return ([instance], [], [])
        
        with patch.object(select_module, "select", fake_select):
            instance.recvfrom.return_value = (header_ip + header_icmp, ("127.0.0.1", 0))
            
            # Injecter select dans le module localement pour le test
            import netcheck.os_fingerprint as fp
            old_select = getattr(fp, "select", None)
            fp.select = select_module
            try:
                resultat = obtenir_ttl_os("127.0.0.1")
                self.assertEqual(resultat["ttl_detecte"], 64)
                self.assertIn("Linux", resultat["os_estime"])
            finally:
                if old_select:
                    fp.select = old_select
                else:
                    delattr(fp, "select")

    def test_permission_denied(self):
        with patch("netcheck.os_fingerprint.socket.socket") as mock_sock:
            mock_sock.side_effect = PermissionError
            resultat = obtenir_ttl_os("192.168.1.1")
            self.assertEqual(resultat["os_estime"], "Inconnu")
            self.assertIn("administrateur", resultat["os_probables"])


class TestEstimerOsHote(unittest.TestCase):
    @patch("netcheck.os_fingerprint.obtenir_ttl_os")
    def test_ajout_os(self, mock_ttl):
        mock_ttl.return_value = {
            "ttl_detecte": 128,
            "os_estime": "Windows",
            "os_probables": "Windows 10/11",
            "confiance": "MOYENNE"
        }
        hote = {
            "ip": "192.168.1.1",
            "ports_ouverts": [80],
            "services": {},
            "vulnerabilites": [],
            "alertes": []
        }
        resultat = estimer_os_hote(hote)
        self.assertEqual(resultat["os_estime"], "Windows")
        self.assertEqual(resultat["ttl"], 128)
        self.assertTrue(any("Windows" in a["titre"] for a in resultat["alertes"]))


class TestTtlOsMapping(unittest.TestCase):
    def test_ttl_connu(self):
        self.assertIn(64, TTL_OS)
        self.assertIn(128, TTL_OS)
        self.assertIn(255, TTL_OS)


if __name__ == "__main__":
    unittest.main()
