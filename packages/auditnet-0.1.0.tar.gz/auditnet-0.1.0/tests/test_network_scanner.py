"""Tests pour le module network_scanner."""

import unittest
from unittest.mock import patch, MagicMock
from netcheck.network_scanner import (
    hote_est_actif,
    scanner_port,
    scanner_ports_hote,
    scanner_sous_reseau
)


class TestHoteEstActif(unittest.TestCase):
    @patch("netcheck.network_scanner.subprocess.run")
    @patch("netcheck.network_scanner.platform.system")
    def test_hote_actif_ping(self, mock_system, mock_run):
        mock_system.return_value = "Windows"
        mock_run.return_value.returncode = 0
        self.assertTrue(hote_est_actif("127.0.0.1"))

    @patch("netcheck.network_scanner.subprocess.run")
    @patch("netcheck.network_scanner.platform.system")
    @patch("netcheck.network_scanner.socket.socket")
    def test_hote_actif_fallback_tcp(self, mock_sock, mock_system, mock_run):
        mock_system.return_value = "Windows"
        mock_run.return_value.returncode = 1
        instance = mock_sock.return_value
        instance.connect_ex.return_value = 0
        self.assertTrue(hote_est_actif("127.0.0.1"))
        instance.close.assert_called_once()

    @patch("netcheck.network_scanner.subprocess.run")
    @patch("netcheck.network_scanner.platform.system")
    @patch("netcheck.network_scanner.socket.socket")
    def test_hote_inactif(self, mock_sock, mock_system, mock_run):
        mock_system.return_value = "Windows"
        mock_run.return_value.returncode = 1
        instance = mock_sock.return_value
        instance.connect_ex.return_value = 10060
        self.assertFalse(hote_est_actif("127.0.0.1"))


class TestScannerPort(unittest.TestCase):
    def test_port_ouvert(self):
        with patch("netcheck.network_scanner.socket.socket") as mock_sock:
            instance = mock_sock.return_value
            instance.connect_ex.return_value = 0
            port, ouvert = scanner_port("127.0.0.1", 80)
            self.assertEqual(port, 80)
            self.assertTrue(ouvert)

    def test_port_ferme(self):
        with patch("netcheck.network_scanner.socket.socket") as mock_sock:
            instance = mock_sock.return_value
            instance.connect_ex.return_value = 10061
            port, ouvert = scanner_port("127.0.0.1", 9999)
            self.assertEqual(port, 9999)
            self.assertFalse(ouvert)


class TestScannerPortsHote(unittest.TestCase):
    def test_scan_ports(self):
        with patch("netcheck.network_scanner.scanner_port") as mock_scan:
            mock_scan.return_value = (80, True)
            resultat = scanner_ports_hote("127.0.0.1", ports=[80, 443])
            self.assertEqual(resultat["ip"], "127.0.0.1")
            self.assertIn(80, resultat["ports_ouverts"])


class TestScannerSousReseau(unittest.TestCase):
    def test_sous_reseau_invalide(self):
        with patch("netcheck.network_scanner.console"):
            resultat = scanner_sous_reseau("invalid")
            self.assertEqual(resultat, [])

    def test_sous_reseau_vide(self):
        with patch("netcheck.network_scanner.console"):
            resultat = scanner_sous_reseau("192.168.255.255/32")
            self.assertEqual(resultat, [])


if __name__ == "__main__":
    unittest.main()
