"""Tests pour le module vuln_checks."""

import unittest
from netcheck.vuln_checks import (
    verifier_ports_dangereux,
    verifier_configurations_dangereuses,
    executer_verifications_securite,
    PORTS_DANGEREUX
)


class TestVerifierPortsDangereux(unittest.TestCase):
    def test_port_telnet(self):
        hote = {"ip": "192.168.1.1", "ports_ouverts": [23], "services": {}, "alertes": []}
        alertes = verifier_ports_dangereux(hote)
        self.assertEqual(len(alertes), 1)
        self.assertEqual(alertes[0]["titre"], "Telnet actif")
        self.assertEqual(alertes[0]["niveau"], "CRITIQUE")

    def test_port_smb(self):
        hote = {"ip": "192.168.1.1", "ports_ouverts": [445], "services": {}, "alertes": []}
        alertes = verifier_ports_dangereux(hote)
        self.assertEqual(alertes[0]["titre"], "Partage SMB ouvert")

    def test_port_ssh(self):
        hote = {"ip": "192.168.1.1", "ports_ouverts": [22], "services": {}, "alertes": []}
        alertes = verifier_ports_dangereux(hote)
        self.assertEqual(alertes[0]["titre"], "SSH accessible")

    def test_aucun_port_dangereux(self):
        hote = {"ip": "192.168.1.1", "ports_ouverts": [443], "services": {}, "alertes": []}
        alertes = verifier_ports_dangereux(hote)
        self.assertEqual(len(alertes), 0)


class TestVerifierConfigurationsDangereuses(unittest.TestCase):
    def test_http_sans_https(self):
        hote = {
            "ip": "192.168.1.1",
            "ports_ouverts": [80],
            "services": {80: {"service": "HTTP", "banniere": "Server: nginx/1.18.0"}},
            "alertes": []
        }
        alertes = verifier_configurations_dangereuses(hote)
        self.assertTrue(any("HTTP sans HTTPS" in a["titre"] for a in alertes))

    def test_https_present(self):
        hote = {
            "ip": "192.168.1.1",
            "ports_ouverts": [80, 443],
            "services": {80: {"service": "HTTP", "banniere": ""}},
            "alertes": []
        }
        alertes = verifier_configurations_dangereuses(hote)
        self.assertFalse(any("HTTP sans HTTPS" in a["titre"] for a in alertes))


class TestExecuterVerificationsSecurite(unittest.TestCase):
    def test_execution_complete(self):
        hotes = [
            {"ip": "192.168.1.1", "ports_ouverts": [23], "services": {}, "alertes": [], "vulnerabilites": []}
        ]
        alertes = executer_verifications_securite(hotes)
        self.assertGreater(len(alertes), 0)
        self.assertGreater(len(hotes[0]["alertes"]), 0)


if __name__ == "__main__":
    unittest.main()
