"""Tests pour le module cve_checker."""

import unittest
from unittest.mock import patch, MagicMock
from netcheck.cve_checker import rechercher_cves, verifier_vulnerabilites_hote


class TestRechercherCves(unittest.TestCase):
    @patch("netcheck.cve_checker.requests.get")
    @patch("netcheck.cve_checker.time.sleep")
    def test_recherche_reussie(self, mock_sleep, mock_get):
        mock_reponse = MagicMock()
        mock_reponse.raise_for_status.return_value = None
        mock_reponse.json.return_value = {
            "vulnerabilities": [
                {
                    "cve": {
                        "id": "CVE-2021-1234",
                        "descriptions": [{"value": "Test description"}],
                        "metrics": {
                            "cvssMetricV31": [
                                {"cvssData": {"baseScore": 7.5, "baseSeverity": "HIGH"}}
                            ]
                        }
                    }
                }
            ]
        }
        mock_get.return_value = mock_reponse
        
        resultat = rechercher_cves("OpenSSH 8.2")
        self.assertEqual(len(resultat), 1)
        self.assertEqual(resultat[0]["id"], "CVE-2021-1234")
        self.assertEqual(resultat[0]["score"], 7.5)

    @patch("netcheck.cve_checker.requests.get")
    def test_timeout(self, mock_get):
        mock_get.side_effect = Exception("Timeout")
        resultat = rechercher_cves("OpenSSH")
        self.assertEqual(resultat, [])

    def test_mot_cle_vide(self):
        resultat = rechercher_cves("")
        self.assertEqual(resultat, [])


class TestVerifierVulnerabilitesHote(unittest.TestCase):
    @patch("netcheck.cve_checker.rechercher_cves")
    def test_verification_service(self, mock_recherche):
        mock_recherche.return_value = [
            {"id": "CVE-2021-1234", "description": "Test", "score": 7.5, "severite": "HIGH"}
        ]
        hote = {
            "ip": "192.168.1.1",
            "services": {22: {"service": "SSH", "version": "8.2"}},
            "vulnerabilites": []
        }
        resultat = verifier_vulnerabilites_hote(hote)
        self.assertGreater(len(resultat["vulnerabilites"]), 0)

    def test_sans_services(self):
        hote = {"ip": "192.168.1.1", "services": {}, "vulnerabilites": []}
        resultat = verifier_vulnerabilites_hote(hote)
        self.assertEqual(resultat["vulnerabilites"], [])


if __name__ == "__main__":
    unittest.main()
