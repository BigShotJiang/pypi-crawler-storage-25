"""Tests pour le module reporter."""

import unittest
import json
import os
from tempfile import TemporaryDirectory
from netcheck.reporter import (
    calculer_etat_sante,
    exporter_json
)


class TestCalculerEtatSante(unittest.TestCase):
    def test_sante_bonne(self):
        hotes = [
            {"ip": "192.168.1.1", "ports_ouverts": [443], "alertes": [], "vulnerabilites": []}
        ]
        sante = calculer_etat_sante(hotes)
        self.assertEqual(sante["score"], 100)
        self.assertIn("Bon", sante["etat"])

    def test_sante_critique(self):
        hotes = [
            {
                "ip": "192.168.1.1",
                "ports_ouverts": [23, 445, 3389],
                "alertes": [{}, {}, {}, {}, {}, {}],
                "vulnerabilites": [{}, {}]
            }
        ]
        sante = calculer_etat_sante(hotes)
        self.assertLess(sante["score"], 50)
        self.assertIn("Critique", sante["etat"])


class TestExporterJson(unittest.TestCase):
    def test_export_reussi(self):
        hotes = [
            {"ip": "192.168.1.1", "ports_ouverts": [80], "services": {}, "vulnerabilites": [], "alertes": []}
        ]
        with TemporaryDirectory() as tmpdir:
            chemin = os.path.join(tmpdir, "rapport.json")
            exporter_json(hotes, chemin)
            self.assertTrue(os.path.exists(chemin))
            with open(chemin, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.assertEqual(data["outil"], "netcheck")
            self.assertIn("hotes", data)


if __name__ == "__main__":
    unittest.main()
