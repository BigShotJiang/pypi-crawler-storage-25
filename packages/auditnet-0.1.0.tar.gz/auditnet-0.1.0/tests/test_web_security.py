"""Tests pour le module web_security."""

import unittest
from unittest.mock import patch, MagicMock
from netcheck.web_security import (
    verifier_headers_http,
    verifier_certificat_ssl,
    verifier_securite_web_hote
)


class TestVerifierHeadersHttp(unittest.TestCase):
    @patch("netcheck.web_security.requests.get")
    def test_headers_securite_presents(self, mock_get):
        mock_reponse = MagicMock()
        mock_reponse.url = "https://example.com"
        mock_reponse.status_code = 200
        mock_reponse.headers = {
            "Strict-Transport-Security": "max-age=31536000",
            "X-Frame-Options": "DENY",
            "X-Content-Type-Options": "nosniff",
            "Content-Security-Policy": "default-src 'self'"
        }
        mock_get.return_value = mock_reponse
        
        resultat = verifier_headers_http("https://example.com")
        self.assertTrue(resultat["accessible"])
        self.assertEqual(len(resultat["headers_manquants"]), 3)  # 4 manquants sur 7

    @patch("netcheck.web_security.requests.get")
    def test_http_sans_https(self, mock_get):
        mock_reponse = MagicMock()
        mock_reponse.url = "http://example.com"
        mock_reponse.status_code = 200
        mock_reponse.headers = {}
        mock_get.return_value = mock_reponse
        
        resultat = verifier_headers_http("http://example.com")
        self.assertTrue(any("Site accessible en HTTP" in a["titre"] for a in resultat["alertes"]))

    @patch("netcheck.web_security.requests.get")
    def test_connexion_erreur(self, mock_get):
        mock_get.side_effect = Exception("ConnectionError")
        resultat = verifier_headers_http("http://invalid.local")
        self.assertFalse(resultat["accessible"])


class TestVerifierCertificatSsl(unittest.TestCase):
    @patch("netcheck.web_security.socket.create_connection")
    @patch("netcheck.web_security.ssl.create_default_context")
    def test_certificat_valide(self, mock_context, mock_conn):
        mock_sock = MagicMock()
        mock_ssock = MagicMock()
        mock_ssock.getpeercert.return_value = {
            "subject": (("commonName", "example.com"),),
            "issuer": (("commonName", "Let's Encrypt"),),
            "notBefore": "Jan 01 00:00:00 2025 GMT",
            "notAfter": "Dec 31 23:59:59 2025 GMT"
        }
        mock_ssock.cipher.return_value = ("TLS_AES_256_GCM_SHA384", "TLSv1.3", 256)
        mock_ssock.version.return_value = "TLSv1.3"
        mock_ssock.__enter__ = MagicMock(return_value=mock_ssock)
        mock_ssock.__exit__ = MagicMock(return_value=False)
        mock_sock.__enter__ = MagicMock(return_value=mock_sock)
        mock_sock.__exit__ = MagicMock(return_value=False)
        
        mock_conn.return_value = mock_sock
        mock_context.return_value.wrap_socket.return_value = mock_ssock
        mock_context.return_value.__enter__ = MagicMock(return_value=mock_context.return_value)
        mock_context.return_value.__exit__ = MagicMock(return_value=False)
        
        # Simplification : on teste plutôt la structure
        resultat = verifier_certificat_ssl("192.168.1.1")
        self.assertIsInstance(resultat, dict)
        self.assertIn("alertes", resultat)

    def test_connexion_refusee(self):
        with patch("netcheck.web_security.socket.create_connection") as mock_conn:
            mock_conn.side_effect = ConnectionRefusedError
            resultat = verifier_certificat_ssl("192.168.1.1")
            self.assertFalse(resultat["certificat_present"])
            self.assertTrue(any("refusée" in a["titre"] for a in resultat["alertes"]))


class TestVerifierSecuriteWebHote(unittest.TestCase):
    @patch("netcheck.web_security.verifier_headers_http")
    @patch("netcheck.web_security.verifier_certificat_ssl")
    def test_verification_complete(self, mock_ssl, mock_headers):
        mock_headers.return_value = {
            "accessible": True,
            "alertes": [{"niveau": "MOYEN", "titre": "Test header", "description": "", "conseil": ""}]
        }
        mock_ssl.return_value = {
            "certificat_present": True,
            "alertes": []
        }
        
        hote = {
            "ip": "192.168.1.1",
            "ports_ouverts": [80, 443],
            "services": {},
            "vulnerabilites": [],
            "alertes": []
        }
        resultat = verifier_securite_web_hote(hote)
        self.assertIn("securite_web", resultat)


if __name__ == "__main__":
    unittest.main()
