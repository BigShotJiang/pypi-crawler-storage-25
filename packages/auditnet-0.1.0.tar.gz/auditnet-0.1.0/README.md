# netcheck

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Outil CLI de vulgarisation d'audit de sécurité réseau local.

## Description

**netcheck** est un outil en ligne de commande conçu pour vulgariser l'audit de sécurité réseau. Il permet à n'importe quel utilisateur, même sans connaissances techniques avancées, d'obtenir des informations sur son réseau local et d'identifier d'éventuelles failles de sécurité.

## Fonctionnalités

- **Scan du réseau local** : découverte des appareils connectés (IP, ports ouverts)
- **Détection de services** : identification des services réseau et récupération des bannières (SSH, HTTP, FTP, etc.)
- **Vérification de vulnérabilités** : comparaison avec la base CVE (NVD) pour détecter les systèmes potentiellement vulnérables
- **Alertes de sécurité** : détection de configurations dangereuses (Telnet, SMB, HTTP sans HTTPS, versions obsolètes, mots de passe par défaut...)
- **Sécurité web** : vérification des headers HTTP de sécurité et analyse des certificats SSL/TLS
- **Capture de trames** : analyse ciblée du trafic réseau avec Scapy (optionnel, nécessite les droits administrateur)
- **Rapport console** : affichage coloré et vulgarisé des résultats
- **Export JSON** : sauvegarde des résultats structurés pour analyse ultérieure
- **Export HTML** : rapport web moderne et coloré, prêt à partager ou imprimer
- **Scan de ports personnalisés** : choisissez vous-même les ports à scanner
- **Mode silencieux** : pour l'intégration dans des scripts ou des pipelines

## Installation rapide (via pip)

```bash
pip install netcheck
```

Ou depuis les sources :

```bash
git clone https://github.com/etudiant/netcheck.git
cd netcheck
pip install -e .
```

> **Windows avec le launcher `py` :** Si la commande `netcheck` n'est pas reconnue après l'installation, utilisez `py -m netcheck` à la place. Exemple : `py -m netcheck --rapide`

**Prérequis pour la capture de trames (Scapy) :**
- **Windows** : installer [Npcap](https://npcap.com/) avec l'option "WinPcap API-compatible Mode"
- **Linux** : exécuter la capture avec `sudo`

**Dépendances Python** : rich, requests, scapy (installées automatiquement avec pip)

## Utilisation

### Scan basique

```bash
# Scan du réseau par défaut (192.168.1.0/24)
netcheck

# Spécifier un sous-réseau
netcheck --sous-reseau 192.168.1.0/24

# Scanner des ports personnalisés
netcheck --ports 22 80 443 8080

# Mode verbose (plus de détails)
netcheck --verbose

# Mode silencieux (pour les scripts)
netcheck --silencieux

# Mode rapide (scan réseau + alertes uniquement, très rapide)
netcheck --rapide

# Détection d'OS (nécessite les droits admin sur Windows)
netcheck --os-detect
```

### Sécurité avancée

```bash
# Activer la vérification de sécurité web (headers HTTP + SSL/TLS)
netcheck --web-security

# Désactiver la vérification CVE (plus rapide)
netcheck --pas-cve

# Exporter un rapport JSON
netcheck --exporter rapport.json

# Exporter un rapport HTML
netcheck --html rapport.html

# Tout faire d'un coup !
netcheck --web-security --exporter rapport.json --html rapport.html
```

### Capture de trames (nécessite les droits admin)

```bash
netcheck --capture --interface "Wi-Fi" --paquets 100
```

## Guide des arguments expliqué simplement

| Argument | À quoi ça sert ? | Exemple concret |
|---|---|---|
| `--sous-reseau` | Indique quel réseau scanner. Par défaut : `192.168.1.0/24` (votre box). | `netcheck --sous-reseau 192.168.0.0/24` |
| `--max-hotes` | Limite le nombre d'appareils à scanner (évite d'attendre trop longtemps). | `netcheck --max-hotes 10` |
| `--ports` | Vous choisissez vous-même les ports à tester (sinon ceux par défaut). | `netcheck --ports 22 80 443 3306` |
| `--verbose` | Affiche plus d'infos en direct (versions, services...). | `netcheck --verbose` |
| `--silencieux` | Réduit l'affichage au minimum. Idéal pour les scripts. | `netcheck --silencieux` |
| `--rapide` | **Le plus rapide.** Scan les ports + alertes uniquement. Skip services et CVE. | `netcheck --rapide` |
| `--os-detect` | Essaie de deviner le système d'exploitation (Windows, Linux...) via le TTL. | `netcheck --os-detect` |
| `--web-security` | Vérifie les sites web trouvés (headers sécurité + certificats SSL). | `netcheck --web-security` |
| `--pas-cve` | Désactive la recherche de vulnérabilités CVE (gain de temps). | `netcheck --pas-cve` |
| `--exporter` | Sauvegarde les résultats dans un fichier JSON. | `netcheck --exporter mon_reseau.json` |
| `--html` | Génère un rapport web coloré, prêt à ouvrir dans un navigateur. | `netcheck --html rapport.html` |
| `--capture` | Capture les paquets réseau en direct (besoin des droits admin). | `netcheck --capture` |
| `--interface` | Précise quelle carte réseau utiliser pour la capture. | `netcheck --capture --interface "Wi-Fi"` |

### Scénarios prêts à l'emploi

```bash
# 1. Premier scan rapide de votre box (1 minute)
netcheck --rapide

# 2. Scan complet avec rapport web
netcheck --web-security --html rapport_box.html

# 3. Scan des ports importants avec export JSON
netcheck --ports 21 22 23 80 443 445 3389 --exporter scan.json

# 4. Scan silencieux pour un script automatisé
netcheck --silencieux --rapide --exporter resultats.json

# 5. Tout vérifier (le plus poussé)
netcheck --verbose --web-security --os-detect --html complet.html --exporter complet.json
```

## Avertissement

Cet outil est destiné à un usage éducatif et éthique. Ne scannez que des réseaux dont vous êtes propriétaire ou pour lesquels vous disposez d'une autorisation explicite.

## Architecture

```
netcheck/
├── netcheck/
│   ├── __init__.py
│   ├── cli.py              # Interface en ligne de commande
│   ├── network_scanner.py  # Scan réseau et ports (multithreadé)
│   ├── service_detector.py # Détection des services et bannières
│   ├── cve_checker.py      # Recherche de CVE via l'API NVD
│   ├── vuln_checks.py      # Tests de sécurité basiques + versions vulnérables
│   ├── web_security.py     # Vérification headers HTTP + certificats SSL/TLS
│   ├── packet_sniffer.py   # Capture de trames Scapy
│   ├── security_utils.py   # Utilitaires de sécurité
│   └── reporter.py         # Affichage console + export JSON/HTML
├── tests/                  # Tests unitaires complets
├── pyproject.toml
└── README.md
```

## Tests

```bash
# Exécuter tous les tests
python -m pytest tests/

# Ou avec unittest
python -m unittest discover tests/
```

## Auteurs

**Korgho Sosthene** et **Ouedraogo Chakira**

Projet tutoré : Audit de sécurité d'un réseau local

## Licence

MIT — Voir le fichier [LICENSE](LICENSE) pour plus de détails.
