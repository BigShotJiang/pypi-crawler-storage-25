# quartermaster-gc

Tile garbage collection with retention policies. Like a ship's quartermaster managing supplies: keep what matters, discard what's expired, sample what's abundant.

## Policies

- **KEEP_ALL** — never delete anything
- **KEEP_RECENT** — keep tiles newer than `max_age_seconds`
- **KEEP_IMPORTANT** — keep tiles with weight above `min_weight`
- **KEEP_SAMPLED** — keep 1 in every N tiles

Stack policies for compound filtering (all must agree to keep).

## Usage

```python
from quartermaster_gc import TileGC, RetentionPolicy, TileEntry
import time

gc = TileGC()
gc.add_tile(TileEntry(id="t1", room="bridge", timestamp=time.time(), weight=0.9))
gc.add_tile(TileEntry(id="t2", room="engine", timestamp=time.time() - 9999, weight=0.1))
gc.add_policy(RetentionPolicy.KEEP_RECENT, max_age_seconds=3600)
gc.add_policy(RetentionPolicy.KEEP_IMPORTANT, min_weight=0.5)

report = gc.collect()
# t2 collected (old + low weight), t1 kept (recent + important)
```

Zero deps. `pip install quartermaster-gc`
