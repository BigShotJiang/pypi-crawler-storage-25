"""quartermaster-gc — Tile garbage collection with retention policies.

Like a ship's quartermaster managing supplies: keep what matters, 
discard what's expired, sample what's abundant.
"""
__version__ = "0.1.0"
from .gc import TileGC, RetentionPolicy, GCSchedule, TileEntry, GCReport
__all__ = ["TileGC", "RetentionPolicy", "GCSchedule", "TileEntry", "GCReport"]
