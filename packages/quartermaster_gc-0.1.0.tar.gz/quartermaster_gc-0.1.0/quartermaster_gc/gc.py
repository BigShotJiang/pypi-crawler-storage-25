"""Tile garbage collector with configurable retention policies."""

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set


class RetentionPolicy(Enum):
    KEEP_ALL = "keep_all"
    KEEP_RECENT = "keep_recent"
    KEEP_IMPORTANT = "keep_important"
    KEEP_SAMPLED = "keep_sampled"


@dataclass
class TileEntry:
    """A tile in the GC registry."""
    id: str
    room: str
    timestamp: float
    weight: float = 1.0
    tags: List[str] = field(default_factory=list)
    pinned: bool = False  # pinned tiles are never collected


@dataclass
class GCReport:
    """Result of a garbage collection pass."""
    kept: int = 0
    collected: int = 0
    pinned: int = 0
    collected_ids: List[str] = field(default_factory=list)
    policy_used: str = ""
    elapsed_seconds: float = 0.0


@dataclass
class GCSchedule:
    """Schedule for automatic GC runs."""
    interval_seconds: float = 3600.0  # default: 1 hour
    last_run: float = 0.0
    
    def is_due(self, now: Optional[float] = None) -> bool:
        now = now or time.time()
        return (now - self.last_run) >= self.interval_seconds
    
    def mark_run(self, now: Optional[float] = None) -> None:
        self.last_run = now or time.time()


class TileGC:
    """Garbage collector for PLATO tiles.
    
    Usage:
        gc = TileGC()
        gc.add_tile(TileEntry(id="t1", room="bridge", timestamp=time.time(), weight=0.9))
        gc.add_policy(RetentionPolicy.KEEP_IMPORTANT, min_weight=0.5)
        report = gc.collect()
    """
    
    def __init__(self):
        self.tiles: Dict[str, TileEntry] = {}
        self.policies: List[dict] = []  # list of {type, params}
    
    def add_tile(self, tile: TileEntry) -> "TileGC":
        self.tiles[tile.id] = tile
        return self
    
    def add_policy(self, policy: RetentionPolicy, **params) -> "TileGC":
        self.policies.append({"type": policy, **params})
        return self
    
    def _should_keep(self, tile: TileEntry, now: float) -> bool:
        if tile.pinned:
            return True
        
        # If no policies, keep everything
        if not self.policies:
            return True
        
        # ALL policies must agree to keep (intersection)
        keeps = []
        for p in self.policies:
            ptype = p["type"]
            if ptype == RetentionPolicy.KEEP_ALL:
                keeps.append(True)
            elif ptype == RetentionPolicy.KEEP_RECENT:
                max_age = p.get("max_age_seconds", 86400)
                keeps.append((now - tile.timestamp) <= max_age)
            elif ptype == RetentionPolicy.KEEP_IMPORTANT:
                min_weight = p.get("min_weight", 0.5)
                keeps.append(tile.weight >= min_weight)
            elif ptype == RetentionPolicy.KEEP_SAMPLED:
                rate = p.get("sample_rate", 10)
                # Deterministic sampling based on tile id hash
                keeps.append(hash(tile.id) % rate == 0)
            else:
                keeps.append(True)
        
        return all(keeps) if keeps else True
    
    def collect(self, now: Optional[float] = None) -> GCReport:
        """Run garbage collection. Returns report of what was kept/collected."""
        start = time.time()
        now = now or start
        collected_ids = []
        pinned = 0
        kept = 0
        
        to_remove = []
        for tid, tile in self.tiles.items():
            if tile.pinned:
                pinned += 1
                kept += 1
                continue
            if self._should_keep(tile, now):
                kept += 1
            else:
                to_remove.append(tid)
        
        for tid in to_remove:
            del self.tiles[tid]
            collected_ids.append(tid)
        
        policy_names = ", ".join(str(p["type"].value) for p in self.policies) or "none"
        
        return GCReport(
            kept=kept,
            collected=len(collected_ids),
            pinned=pinned,
            collected_ids=collected_ids,
            policy_used=policy_names,
            elapsed_seconds=round(time.time() - start, 4),
        )
    
    def tile_count(self) -> int:
        return len(self.tiles)
    
    def pin(self, tile_id: str) -> bool:
        if tile_id in self.tiles:
            self.tiles[tile_id].pinned = True
            return True
        return False
    
    def unpin(self, tile_id: str) -> bool:
        if tile_id in self.tiles:
            self.tiles[tile_id].pinned = False
            return True
        return False
