"""Tests for quartermaster-gc."""
import time
import pytest
from quartermaster_gc import TileGC, RetentionPolicy, GCSchedule, TileEntry


def test_keep_all():
    gc = TileGC()
    gc.add_policy(RetentionPolicy.KEEP_ALL)
    for i in range(10):
        gc.add_tile(TileEntry(id=f"t{i}", room="r", timestamp=time.time(), weight=0.1))
    report = gc.collect()
    assert report.collected == 0
    assert report.kept == 10


def test_keep_recent():
    now = time.time()
    gc = TileGC()
    gc.add_policy(RetentionPolicy.KEEP_RECENT, max_age_seconds=100)
    gc.add_tile(TileEntry(id="old", room="r", timestamp=now - 200, weight=1.0))
    gc.add_tile(TileEntry(id="new", room="r", timestamp=now - 10, weight=1.0))
    report = gc.collect(now=now)
    assert report.collected == 1
    assert "old" in report.collected_ids


def test_keep_important():
    gc = TileGC()
    gc.add_policy(RetentionPolicy.KEEP_IMPORTANT, min_weight=0.7)
    gc.add_tile(TileEntry(id="low", room="r", timestamp=time.time(), weight=0.3))
    gc.add_tile(TileEntry(id="high", room="r", timestamp=time.time(), weight=0.9))
    report = gc.collect()
    assert report.collected == 1
    assert "low" in report.collected_ids


def test_pinned_tiles_survive():
    gc = TileGC()
    gc.add_policy(RetentionPolicy.KEEP_IMPORTANT, min_weight=0.9)
    gc.add_tile(TileEntry(id="pinned", room="r", timestamp=time.time(), weight=0.1, pinned=True))
    gc.add_tile(TileEntry(id="unpinned", room="r", timestamp=time.time(), weight=0.1))
    report = gc.collect()
    assert report.pinned == 1
    assert report.collected == 1
    assert "pinned" not in report.collected_ids


def test_compound_policies():
    now = time.time()
    gc = TileGC()
    gc.add_policy(RetentionPolicy.KEEP_RECENT, max_age_seconds=100)
    gc.add_policy(RetentionPolicy.KEEP_IMPORTANT, min_weight=0.5)
    # Old + low weight → collected (fails both)
    gc.add_tile(TileEntry(id="bad", room="r", timestamp=now - 200, weight=0.3))
    # Recent but low weight → collected (passes recent, fails important)
    gc.add_tile(TileEntry(id="recent_low", room="r", timestamp=now - 10, weight=0.3))
    # Old but high weight → collected (fails recent, passes important)
    gc.add_tile(TileEntry(id="old_high", room="r", timestamp=now - 200, weight=0.9))
    # Recent + high weight → kept (passes both)
    gc.add_tile(TileEntry(id="good", room="r", timestamp=now - 10, weight=0.9))
    report = gc.collect(now=now)
    assert report.kept == 1
    assert report.collected == 3
    assert "good" not in report.collected_ids


def test_schedule():
    sched = GCSchedule(interval_seconds=60)
    assert sched.is_due(now=0)  # never run
    sched.mark_run(now=100)
    assert not sched.is_due(now=120)
    assert sched.is_due(now=170)
