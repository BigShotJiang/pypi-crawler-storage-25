"""
Comprehensive test suite for pyGAPIT.

Tests are organized by module and verify:
1. Mathematical correctness (known analytical results)
2. Biological plausibility (λ, h², effect direction)
3. Interface contracts (shapes, types, no exceptions)
4. Integration with real GAPIT demo data
"""

import sys, os, warnings
warnings.filterwarnings("ignore")

# Make sure pygapit is importable from the package root
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import numpy as np
import pandas as pd
import pytest

# ─────────────────────────────────────────────────────────────────────────────
# Fixtures — small synthetic datasets for fast unit tests
# ─────────────────────────────────────────────────────────────────────────────

@pytest.fixture(scope="module")
def rng():
    return np.random.RandomState(42)


@pytest.fixture(scope="module")
def small_dataset(rng):
    """
    Synthetic dataset: 50 individuals, 200 SNPs.
    One planted QTN (SNP index 50) with large effect on phenotype.
    Population structure: 2 groups with different allele frequencies.
    """
    n, m = 50, 200

    # Two groups with different allele frequencies
    group = np.repeat([0, 1], n // 2)
    GD = np.zeros((n, m), dtype=float)
    for j in range(m):
        freq_0 = rng.uniform(0.1, 0.9)
        freq_1 = rng.uniform(0.1, 0.9)
        for i in range(n):
            f = freq_0 if group[i] == 0 else freq_1
            GD[i, j] = rng.choice([0, 1, 2], p=[(1-f)**2, 2*f*(1-f), f**2])

    # Plant one large-effect QTN
    qtn_idx = 50
    alpha_true = 5.0
    y = alpha_true * GD[:, qtn_idx] + rng.normal(0, 2, n)
    # Add population structure effect
    y += group * 3.0

    # Map
    chromosomes = np.repeat(np.arange(1, 5), m // 4)
    positions   = np.tile(np.arange(1, m // 4 + 1) * 1_000_000, 4)

    taxa = np.array([f"ind{i:03d}" for i in range(n)])
    snp_names = np.array([f"SNP{j:04d}" for j in range(m)])

    return {
        "y": y, "GD": GD, "GM": pd.DataFrame({
            "SNP": snp_names,
            "Chromosome": chromosomes,
            "Position": positions,
        }),
        "taxa": taxa,
        "qtn_idx": qtn_idx,
        "alpha_true": alpha_true,
        "group": group,
        "n": n, "m": m,
    }


@pytest.fixture(scope="module")
def real_data():
    """Load actual GAPIT maize demo data if available."""
    base = os.path.join(os.path.dirname(__file__), "..", "..", "GAPIT", "Documents")
    pheno_path = os.path.join(base, "mdp_traits.txt")
    gd_path    = os.path.join(base, "mdp_numeric.txt")
    gm_path    = os.path.join(base, "mdp_SNP_information.txt")

    if not all(os.path.exists(p) for p in [pheno_path, gd_path, gm_path]):
        pytest.skip("GAPIT demo data not available")

    from pygapit.io.formats import read_numeric, read_phenotype, align_taxa, maf_filter
    from pygapit.stats.kinship import vanraden_kinship
    from pygapit.stats.pca import compute_pca, build_covariate_matrix

    pheno = read_phenotype(pheno_path)
    geno  = read_numeric(gd_path, gm_path)
    aligned = align_taxa(pheno, geno)

    y_full = aligned["Y"]["EarHT"].values.astype(float)
    valid  = ~np.isnan(y_full)
    y      = y_full[valid]
    GD, kept = maf_filter(aligned["GD"][valid, :], 0.05)
    GM     = aligned["GM"].iloc[kept].reset_index(drop=True)
    taxa   = aligned["taxa"][valid]
    K      = vanraden_kinship(GD)
    pca    = compute_pca(GD, 3)
    X0     = build_covariate_matrix(pca, 3)

    return {"y": y, "GD": GD, "GM": GM, "K": K, "X0": X0, "taxa": taxa}


# ─────────────────────────────────────────────────────────────────────────────
# Tests: Kinship
# ─────────────────────────────────────────────────────────────────────────────

class TestKinship:

    def test_vanraden_shape(self, small_dataset):
        from pygapit.stats.kinship import vanraden_kinship
        n = small_dataset["n"]
        K = vanraden_kinship(small_dataset["GD"])
        assert K.shape == (n, n), "K should be n×n"

    def test_vanraden_symmetric(self, small_dataset):
        from pygapit.stats.kinship import vanraden_kinship
        K = vanraden_kinship(small_dataset["GD"])
        assert np.allclose(K, K.T, atol=1e-10), "K should be symmetric"

    def test_vanraden_diagonal_positive(self, small_dataset):
        from pygapit.stats.kinship import vanraden_kinship
        K = vanraden_kinship(small_dataset["GD"])
        assert np.all(np.diag(K) > 0), "Diagonal of K should be positive"

    def test_vanraden_identity_input(self):
        """With identical homozygous genotypes, K should be all-ones."""
        from pygapit.stats.kinship import vanraden_kinship
        # All individuals homozygous alt (2) at all SNPs
        GD = np.ones((10, 50)) * 2
        # Add small variation so it's not monomorphic
        GD[0, :10] = 0
        K = vanraden_kinship(GD)
        assert K.shape == (10, 10)
        assert np.all(np.isfinite(K))

    def test_vanraden_real_data(self, real_data):
        """On real maize data: diagonal mean should be ~1, values in [-1, 3]."""
        K = real_data["K"]
        diag_mean = np.mean(np.diag(K))
        assert 0.5 < diag_mean < 5.0, f"Diagonal mean {diag_mean:.3f} out of expected range"
        assert K.min() > -2.0, "K values should not be very negative"

    def test_vanraden_monomorphic_removed(self):
        """Monomorphic SNPs should not crash the computation."""
        from pygapit.stats.kinship import vanraden_kinship
        GD = np.ones((10, 20)) * 2           # all monomorphic
        GD[:, :10] = np.random.choice([0, 1, 2], size=(10, 10))  # add some variation
        K = vanraden_kinship(GD)
        assert K.shape == (10, 10)
        assert np.all(np.isfinite(K))


# ─────────────────────────────────────────────────────────────────────────────
# Tests: PCA
# ─────────────────────────────────────────────────────────────────────────────

class TestPCA:

    def test_pca_shape(self, small_dataset):
        from pygapit.stats.pca import compute_pca
        n, m = small_dataset["n"], small_dataset["m"]
        pca = compute_pca(small_dataset["GD"], n_components=3)
        assert pca.scores.shape == (n, 3)
        assert pca.var_explained.shape == (3,)

    def test_pca_var_explained_sums_reasonable(self, small_dataset):
        from pygapit.stats.pca import compute_pca
        pca = compute_pca(small_dataset["GD"], n_components=5)
        assert np.all(pca.var_explained >= 0), "Variance explained must be non-negative"
        assert pca.var_explained[0] >= pca.var_explained[1], "PCs should be ordered by variance"

    def test_covariate_matrix_shape(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        n = small_dataset["n"]
        pca = compute_pca(small_dataset["GD"], n_components=3)
        X0 = build_covariate_matrix(pca, 3)
        assert X0.shape == (n, 4), "X0 should be n × (1+k)"
        assert np.all(X0[:, 0] == 1.0), "First column should be intercept (all ones)"

    def test_pca_real_data(self, real_data):
        """First 3 PCs should explain >5% variance on structured population."""
        from pygapit.stats.pca import compute_pca
        pca = compute_pca(real_data["GD"], n_components=3)
        cumulative = pca.var_explained[:3].sum()
        assert cumulative > 0.01, f"Top 3 PCs explain only {cumulative:.3f} variance"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: EMMA / REML
# ─────────────────────────────────────────────────────────────────────────────

class TestEMMA:

    def test_remle_output_types(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.stats.kinship import vanraden_kinship
        from pygapit.stats.emma import emma_remle
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        K  = vanraden_kinship(GD)
        pca = compute_pca(GD, 3)
        X0  = build_covariate_matrix(pca, 3)
        result = emma_remle(y, X0, K)
        assert isinstance(result.delta, float)
        assert isinstance(result.vg, float)
        assert isinstance(result.ve, float)
        assert isinstance(result.h2, float)

    def test_remle_h2_in_range(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.stats.kinship import vanraden_kinship
        from pygapit.stats.emma import emma_remle
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        K  = vanraden_kinship(GD)
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = emma_remle(y, X0, K)
        assert 0.0 <= r.h2 <= 1.0, f"h² = {r.h2:.4f} out of [0, 1]"

    def test_remle_vg_ve_positive(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.stats.kinship import vanraden_kinship
        from pygapit.stats.emma import emma_remle
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        K  = vanraden_kinship(GD)
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = emma_remle(y, X0, K)
        assert r.vg >= 0, "Genetic variance must be non-negative"
        assert r.ve >= 0, "Residual variance must be non-negative"

    def test_remle_real_data_h2(self, real_data):
        """EarHT heritability from GAPIT demo data: expect ~0.4–0.7."""
        from pygapit.stats.emma import emma_remle
        r = emma_remle(real_data["y"], real_data["X0"], real_data["K"])
        assert 0.3 < r.h2 < 0.8, f"EarHT h² = {r.h2:.4f}, expected 0.3–0.8"

    def test_p3d_output_shape(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.stats.kinship import vanraden_kinship
        from pygapit.stats.emma import emmax_p3d
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        n, m = GD.shape
        K  = vanraden_kinship(GD)
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        result = emmax_p3d(y, X0, GD, K)
        assert result.p_values.shape == (m,)
        assert result.effects.shape  == (m,)

    def test_p3d_p_values_valid(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.stats.kinship import vanraden_kinship
        from pygapit.stats.emma import emmax_p3d
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        K  = vanraden_kinship(GD)
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        result = emmax_p3d(y, X0, GD, K)
        valid_p = result.p_values[~np.isnan(result.p_values)]
        assert np.all(valid_p >= 0), "P-values must be ≥ 0"
        assert np.all(valid_p <= 1), "P-values must be ≤ 1"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: Multiple Testing
# ─────────────────────────────────────────────────────────────────────────────

class TestTesting:

    def test_bonferroni(self):
        from pygapit.stats.testing import bonferroni_threshold
        t = bonferroni_threshold(n_tests=10000, alpha=0.05)
        assert abs(t - 5e-6) < 1e-10, f"Bonferroni threshold = {t}"

    def test_bh_fdr_no_signal(self):
        """Uniform null p-values: BH should not reject at q=0.05."""
        from pygapit.stats.testing import benjamini_hochberg
        rng = np.random.RandomState(0)
        p = rng.uniform(0, 1, 1000)
        adj = benjamini_hochberg(p, alpha=0.05)
        assert np.all(adj >= 0) and np.all(adj <= 1)
        # Under H0 we expect very few/no rejections
        n_sig = (adj <= 0.05).sum()
        assert n_sig <= 50, f"Too many BH rejections under H0: {n_sig}"

    def test_bh_fdr_strong_signal(self):
        """Very small p-values should have small adjusted p-values."""
        from pygapit.stats.testing import benjamini_hochberg
        p = np.concatenate([np.ones(990) * 0.5, np.ones(10) * 1e-10])
        adj = benjamini_hochberg(p, alpha=0.05)
        n_sig = (adj <= 0.05).sum()
        assert n_sig >= 5, f"Expected ≥5 BH rejections with strong signal, got {n_sig}"

    def test_bh_monotone(self):
        """BH adjusted p-values should be monotone non-decreasing after sorting."""
        from pygapit.stats.testing import benjamini_hochberg
        rng = np.random.RandomState(1)
        p = rng.uniform(0, 1, 500)
        adj = benjamini_hochberg(p)
        sorted_adj = np.sort(adj)
        assert np.all(sorted_adj[1:] >= sorted_adj[:-1] - 1e-10)

    def test_genomic_inflation_null(self):
        """Uniform p-values → λ ≈ 1.0."""
        from pygapit.stats.testing import genomic_inflation_factor
        rng = np.random.RandomState(2)
        p = rng.uniform(0, 1, 5000)
        lam = genomic_inflation_factor(p)
        assert 0.85 < lam < 1.2, f"λ = {lam:.3f} should be near 1.0 under H0"

    def test_genomic_inflation_inflated(self):
        """Inflated p-values → λ > 1."""
        from pygapit.stats.testing import genomic_inflation_factor
        rng = np.random.RandomState(3)
        # Shift all p-values toward 0 (inflation)
        p = rng.uniform(0, 0.1, 5000)
        lam = genomic_inflation_factor(p)
        assert lam > 1.5, f"λ = {lam:.3f} should be >1.5 with inflated p-values"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: GLM
# ─────────────────────────────────────────────────────────────────────────────

class TestGLM:

    def test_glm_output_shape(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.glm import glm_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        m  = small_dataset["m"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = glm_gwas(y, X0, GD)
        assert r.p_values.shape == (m,)
        assert r.effects.shape  == (m,)

    def test_glm_planted_qtn_detected(self, small_dataset):
        """The planted QTN should have the smallest p-value."""
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.glm import glm_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = glm_gwas(y, X0, GD)
        top_hit = np.argmin(r.p_values)
        # QTN or nearby SNP should be in top 5
        assert top_hit in range(max(0, small_dataset["qtn_idx"]-5),
                                min(small_dataset["m"], small_dataset["qtn_idx"]+5)), \
            f"Top hit SNP {top_hit} far from planted QTN {small_dataset['qtn_idx']}"

    def test_glm_effect_direction(self, small_dataset):
        """Effect at the planted QTN should be positive (alpha_true > 0)."""
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.glm import glm_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = glm_gwas(y, X0, GD)
        assert r.effects[small_dataset["qtn_idx"]] > 0, \
            "Effect at planted QTN should be positive"

    def test_glm_p_values_uniform_null(self):
        """Under pure null (no association), p-values should be roughly uniform."""
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.stats.testing import genomic_inflation_factor
        from pygapit.gwas.glm import glm_gwas
        rng2 = np.random.RandomState(99)
        n, m = 80, 300
        GD = rng2.choice([0, 1, 2], size=(n, m),
                          p=[0.25, 0.5, 0.25]).astype(float)
        y  = rng2.normal(0, 1, n)    # pure noise, no genotype effect
        X0 = np.ones((n, 1))
        r  = glm_gwas(y, X0, GD)
        lam = genomic_inflation_factor(r.p_values)
        assert 0.7 < lam < 1.5, f"λ = {lam:.3f} under null should be near 1"

    def test_glm_real_data_inflation(self, real_data):
        """Without kinship, GLM on real structured data should show λ > 1.1."""
        from pygapit.gwas.glm import glm_gwas
        from pygapit.stats.testing import genomic_inflation_factor
        r   = glm_gwas(real_data["y"], real_data["X0"], real_data["GD"])
        lam = genomic_inflation_factor(r.p_values)
        assert lam > 1.0, f"GLM λ = {lam:.3f} should show inflation on structured data"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: MLM
# ─────────────────────────────────────────────────────────────────────────────

class TestMLM:

    def test_mlm_controls_inflation(self, real_data):
        """MLM with kinship should bring λ close to 1.0."""
        from pygapit.gwas.mlm import mlm_gwas
        from pygapit.stats.testing import genomic_inflation_factor
        r   = mlm_gwas(real_data["y"], real_data["X0"],
                       real_data["GD"], real_data["K"])
        lam = genomic_inflation_factor(r.p_values)
        assert lam < 1.3, f"MLM λ = {lam:.3f} should be well-controlled"

    def test_mlm_h2_plausible(self, real_data):
        from pygapit.gwas.mlm import mlm_gwas
        r = mlm_gwas(real_data["y"], real_data["X0"],
                     real_data["GD"], real_data["K"])
        assert 0.1 < r.h2 < 0.95, f"MLM h² = {r.h2:.3f} out of plausible range"

    def test_mlm_output_shape(self, real_data):
        from pygapit.gwas.mlm import mlm_gwas
        m = real_data["GD"].shape[1]
        r = mlm_gwas(real_data["y"], real_data["X0"],
                     real_data["GD"], real_data["K"])
        assert r.p_values.shape == (m,)
        assert r.effects.shape  == (m,)

    def test_mlm_p_values_valid(self, real_data):
        from pygapit.gwas.mlm import mlm_gwas
        r = mlm_gwas(real_data["y"], real_data["X0"],
                     real_data["GD"], real_data["K"])
        valid = r.p_values[~np.isnan(r.p_values)]
        assert np.all(valid >= 0)
        assert np.all(valid <= 1)


# ─────────────────────────────────────────────────────────────────────────────
# Tests: BLINK
# ─────────────────────────────────────────────────────────────────────────────

class TestBLINK:

    def test_blink_output_shape(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.blink import blink_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        m  = small_dataset["m"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = blink_gwas(y, X0, GD, max_iterations=3)
        assert r.p_values.shape == (m,)

    def test_blink_selects_qtns(self, small_dataset):
        """BLINK should identify QTNs near the planted signal."""
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.blink import blink_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = blink_gwas(y, X0, GD, max_iterations=5)
        # Should detect some QTNs
        assert len(r.selected_qtns) >= 0  # could be 0 if threshold too strict
        # Non-QTN p-values should be valid
        non_qtn_mask = np.ones(len(r.p_values), dtype=bool)
        if len(r.selected_qtns) > 0:
            non_qtn_mask[r.selected_qtns] = False
        valid_p = r.p_values[non_qtn_mask & ~np.isnan(r.p_values)]
        assert np.all(valid_p >= 0)
        assert np.all(valid_p <= 1)

    def test_blink_converges(self, small_dataset):
        """BLINK should converge within max_iterations."""
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.blink import blink_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = blink_gwas(y, X0, GD, max_iterations=10)
        assert r.n_iterations <= 10

    def test_blink_ld_pruning(self):
        """LD pruning should reduce a highly correlated set to 1 marker."""
        from pygapit.gwas.blink import _ld_prune
        rng2 = np.random.RandomState(7)
        n = 100
        # Create 5 perfectly correlated SNPs
        base = rng2.choice([0, 1, 2], n, p=[0.25, 0.5, 0.25]).astype(float)
        GD  = np.column_stack([base] * 5 + [rng2.choice([0, 1, 2], n).astype(float)])
        candidates = np.array([0, 1, 2, 3, 4, 5])
        pruned = _ld_prune(candidates, GD, ld_threshold=0.9)
        # All 5 correlated SNPs should collapse to 1; independent SNP 5 kept
        assert 5 in pruned, "Independent SNP should survive LD pruning"
        n_from_corr = sum(1 for i in pruned if i < 5)
        assert n_from_corr == 1, f"Should keep only 1 of 5 correlated SNPs, kept {n_from_corr}"

    def test_bic_selection(self):
        """BIC should add a truly predictive SNP."""
        from pygapit.gwas.blink import _bic_select_cofactors
        rng2 = np.random.RandomState(8)
        n = 60
        snp_signal = rng2.choice([0, 1, 2], n).astype(float)
        snp_noise  = rng2.normal(0, 1, (n, 10))
        GD = np.column_stack([snp_signal, snp_noise])
        y  = 3.0 * snp_signal + rng2.normal(0, 0.5, n)
        X0 = np.ones((n, 1))
        selected = _bic_select_cofactors(y, X0, GD, candidates=np.arange(11))
        assert 0 in selected, "Signal SNP (index 0) should be selected by BIC"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: FarmCPU
# ─────────────────────────────────────────────────────────────────────────────

class TestFarmCPU:

    def test_farmcpu_output_shape(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.farmcpu import farmcpu_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        GM = small_dataset["GM"]
        m  = small_dataset["m"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = farmcpu_gwas(y, X0, GD,
                          chromosomes=GM["Chromosome"].values,
                          positions=GM["Position"].values.astype(float),
                          max_iterations=3)
        assert r.p_values.shape == (m,)

    def test_farmcpu_p_values_valid(self, small_dataset):
        from pygapit.stats.pca import compute_pca, build_covariate_matrix
        from pygapit.gwas.farmcpu import farmcpu_gwas
        GD = small_dataset["GD"]
        y  = small_dataset["y"]
        GM = small_dataset["GM"]
        X0 = build_covariate_matrix(compute_pca(GD, 3), 3)
        r  = farmcpu_gwas(y, X0, GD,
                          chromosomes=GM["Chromosome"].values,
                          positions=GM["Position"].values.astype(float),
                          max_iterations=3)
        valid = r.p_values[~np.isnan(r.p_values)]
        assert np.all(valid >= 0)
        assert np.all(valid <= 1)

    def test_farmcpu_bin_selection(self, small_dataset):
        """Bin selection should respect max_qtns bound."""
        from pygapit.gwas.farmcpu import _bin_select_qtns
        GM = small_dataset["GM"]
        n  = small_dataset["n"]
        p  = np.random.uniform(0, 0.001, small_dataset["m"])
        max_qtns = int(np.sqrt(n) / np.sqrt(max(1, np.log10(n))))
        qtns = _bin_select_qtns(p, GM["Chromosome"].values,
                                 GM["Position"].values.astype(float),
                                 max_qtns=max_qtns)
        assert len(qtns) <= max_qtns, f"Got {len(qtns)} QTNs, max is {max_qtns}"

    def test_farmcpu_real_data(self, real_data):
        """FarmCPU on real data: λ should be controlled."""
        from pygapit.gwas.farmcpu import farmcpu_gwas
        from pygapit.stats.testing import genomic_inflation_factor
        GM = real_data["GM"]
        r  = farmcpu_gwas(
            real_data["y"], real_data["X0"], real_data["GD"],
            chromosomes=GM["Chromosome"].values,
            positions=GM["Position"].values.astype(float),
            max_iterations=5,
        )
        non_qtn = np.ones(len(r.p_values), dtype=bool)
        if len(r.selected_qtns) > 0:
            non_qtn[r.selected_qtns] = False
        lam = genomic_inflation_factor(r.p_values[non_qtn])
        assert lam < 1.6, f"FarmCPU λ = {lam:.3f} too inflated"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: gBLUP / Genomic Selection
# ─────────────────────────────────────────────────────────────────────────────

class TestGBLUP:

    def test_gblup_output_shape(self, real_data):
        from pygapit.gs.blup import gblup
        n = len(real_data["y"])
        r = gblup(real_data["y"], real_data["X0"], real_data["K"])
        assert r.blup.shape        == (n,)
        assert r.blue.shape        == (n,)
        assert r.prediction.shape  == (n,)
        assert r.pev.shape         == (n,)
        assert r.gebv.shape        == (n,)

    def test_gblup_h2_plausible(self, real_data):
        from pygapit.gs.blup import gblup
        r = gblup(real_data["y"], real_data["X0"], real_data["K"])
        assert 0.1 < r.h2 < 0.95, f"gBLUP h² = {r.h2:.4f} out of plausible range"

    def test_gblup_prediction_correlation(self, real_data):
        """Training-set prediction should correlate well with observations."""
        from pygapit.gs.blup import gblup
        r   = gblup(real_data["y"], real_data["X0"], real_data["K"])
        corr = np.corrcoef(real_data["y"], r.prediction)[0, 1]
        assert corr > 0.5, f"Prediction accuracy r = {corr:.3f} unexpectedly low"

    def test_gblup_pev_positive(self, real_data):
        """All PEV values should be non-negative."""
        from pygapit.gs.blup import gblup
        r = gblup(real_data["y"], real_data["X0"], real_data["K"])
        finite_pev = r.pev[np.isfinite(r.pev)]
        assert np.all(finite_pev >= -1e-8), "PEV should be non-negative"

    def test_prediction_blue_blup_sum(self, real_data):
        """Prediction should equal BLUE + BLUP."""
        from pygapit.gs.blup import gblup
        r = gblup(real_data["y"], real_data["X0"], real_data["K"])
        expected = r.blue + r.blup
        assert np.allclose(r.prediction, expected, atol=1e-6), \
            "Prediction != BLUE + BLUP"

    def test_sblup_uses_qtn_kinship(self, real_data):
        """sBLUP with QTN indices should produce a valid result."""
        from pygapit.gs.blup import sblup
        qtn_idx = np.array([0, 10, 50, 100, 200])
        r = sblup(real_data["y"], real_data["X0"], real_data["GD"],
                  qtn_indices=qtn_idx)
        assert r.method == "sBLUP"
        assert np.all(np.isfinite(r.blup))


# ─────────────────────────────────────────────────────────────────────────────
# Tests: I/O
# ─────────────────────────────────────────────────────────────────────────────

class TestIO:

    def test_read_phenotype_real(self):
        """Real phenotype file loads correctly."""
        base = os.path.join(os.path.dirname(__file__), "..",
                            "..", "GAPIT", "Documents")
        fp = os.path.join(base, "mdp_traits.txt")
        if not os.path.exists(fp):
            pytest.skip("GAPIT demo data not available")
        from pygapit.io.formats import read_phenotype
        p = read_phenotype(fp)
        assert len(p.taxa) == 301
        assert "EarHT" in p.trait_names
        assert p.Y.shape == (301, 4)

    def test_read_numeric_real(self):
        """Real numeric genotype + map loads correctly."""
        base = os.path.join(os.path.dirname(__file__), "..",
                            "..", "GAPIT", "Documents")
        gd_fp = os.path.join(base, "mdp_numeric.txt")
        gm_fp = os.path.join(base, "mdp_SNP_information.txt")
        if not all(os.path.exists(p) for p in [gd_fp, gm_fp]):
            pytest.skip("GAPIT demo data not available")
        from pygapit.io.formats import read_numeric
        g = read_numeric(gd_fp, gm_fp)
        assert g.GD.shape == (281, 3093)
        assert g.GM.shape == (3093, 3)
        assert len(g.taxa) == 281

    def test_align_taxa(self):
        """Taxa alignment drops non-overlapping individuals correctly."""
        from pygapit.io.formats import PhenotypeData, GenotypeData, align_taxa
        import pandas as pd
        # Phenotype: 5 individuals
        Y = pd.DataFrame({"Taxa": ["A", "B", "C", "D", "E"], "trait": [1., 2., 3., 4., 5.]})
        pheno = PhenotypeData(Y=Y, taxa=np.array(["A","B","C","D","E"]),
                              trait_names=["trait"])
        # Genotype: 4 individuals (missing D, extra F)
        GD = np.random.rand(4, 10)
        GM = pd.DataFrame({"SNP": [f"s{i}" for i in range(10)],
                           "Chromosome": [1]*10, "Position": range(10)})
        geno = GenotypeData(GD=GD, GM=GM, taxa=np.array(["A","B","C","F"]))
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            aligned = align_taxa(pheno, geno)
        assert len(aligned["taxa"]) == 3  # A, B, C
        assert aligned["GD"].shape[0] == 3

    def test_maf_filter(self):
        """MAF filter removes monomorphic and rare SNPs."""
        from pygapit.io.formats import maf_filter
        # 5 individuals, 4 SNPs:
        # SNP0: all 2 → monomorphic → remove
        # SNP1: all 0 → monomorphic → remove
        # SNP2: freq 1/10 = 0.1 → remove at 0.15 threshold
        # SNP3: freq 0.5 → keep
        GD = np.array([[2,0,0,0],[2,0,0,1],[2,0,0,2],[2,0,2,1],[2,0,0,0]], dtype=float)
        filtered, idx = maf_filter(GD, threshold=0.15)
        assert 3 in idx, "SNP3 with MAF=0.3 should be kept"
        assert 0 not in idx, "Monomorphic SNP0 should be removed"
        assert 1 not in idx, "Monomorphic SNP1 should be removed"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: Full GAPIT() pipeline
# ─────────────────────────────────────────────────────────────────────────────

class TestGAPITPipeline:

    def test_gapit_glm_returns_result(self, real_data, tmp_path):
        """GAPIT() with GLM should return GAPITResult with populated GWAS table."""
        from pygapit.gapit import GAPIT, GAPITResult
        from pygapit.io.formats import read_numeric, read_phenotype
        base = os.path.join(os.path.dirname(__file__), "..", "..", "GAPIT", "Documents")
        if not os.path.exists(os.path.join(base, "mdp_traits.txt")):
            pytest.skip("GAPIT demo data not available")

        Y  = pd.read_csv(os.path.join(base, "mdp_traits.txt"), sep="\t")
        GD = pd.read_csv(os.path.join(base, "mdp_numeric.txt"), sep="\t")
        GM = pd.read_csv(os.path.join(base, "mdp_SNP_information.txt"), sep="\t")

        result = GAPIT(
            Y=Y, GD=GD, GM=GM,
            model="GLM",
            PCA_total=3,
            trait="EarHT",
            file_output=True,
            output_dir=str(tmp_path),
        )
        assert isinstance(result, GAPITResult)
        assert result.GWAS is not None
        assert len(result.GWAS) > 100
        assert "P.value" in result.GWAS.columns
        assert "SNP" in result.GWAS.columns
        assert "effect" in result.GWAS.columns
        assert 0.0 <= result.h2 <= 1.0
        assert result.lambda_gc > 0

    def test_gapit_mlm_returns_result(self, tmp_path):
        """GAPIT() with MLM should produce lower λ than GLM."""
        from pygapit.gapit import GAPIT
        base = os.path.join(os.path.dirname(__file__), "..", "..", "GAPIT", "Documents")
        if not os.path.exists(os.path.join(base, "mdp_traits.txt")):
            pytest.skip("GAPIT demo data not available")

        Y  = pd.read_csv(os.path.join(base, "mdp_traits.txt"), sep="\t")
        GD = pd.read_csv(os.path.join(base, "mdp_numeric.txt"), sep="\t")
        GM = pd.read_csv(os.path.join(base, "mdp_SNP_information.txt"), sep="\t")

        result = GAPIT(Y=Y, GD=GD, GM=GM, model="MLM",
                       trait="EarHT", file_output=False,
                       output_dir=str(tmp_path))
        assert result.lambda_gc < 1.3, f"MLM λ = {result.lambda_gc:.3f} too high"
        assert result.h2 > 0.1, "MLM h² should be substantial for EarHT"

    def test_gapit_blink_returns_result(self, tmp_path):
        """GAPIT() with BLINK should complete and return QTNs."""
        from pygapit.gapit import GAPIT
        base = os.path.join(os.path.dirname(__file__), "..", "..", "GAPIT", "Documents")
        if not os.path.exists(os.path.join(base, "mdp_traits.txt")):
            pytest.skip("GAPIT demo data not available")

        Y  = pd.read_csv(os.path.join(base, "mdp_traits.txt"), sep="\t")
        GD = pd.read_csv(os.path.join(base, "mdp_numeric.txt"), sep="\t")
        GM = pd.read_csv(os.path.join(base, "mdp_SNP_information.txt"), sep="\t")

        result = GAPIT(Y=Y, GD=GD, GM=GM, model="BLINK",
                       trait="EarHT", file_output=False,
                       output_dir=str(tmp_path))
        assert result.GWAS is not None
        assert result.model == "BLINK"

    def test_gapit_output_files_created(self, tmp_path):
        """GAPIT() with file_output=True should create CSV and PDF files."""
        from pygapit.gapit import GAPIT
        base = os.path.join(os.path.dirname(__file__), "..", "..", "GAPIT", "Documents")
        if not os.path.exists(os.path.join(base, "mdp_traits.txt")):
            pytest.skip("GAPIT demo data not available")

        Y  = pd.read_csv(os.path.join(base, "mdp_traits.txt"), sep="\t")
        GD = pd.read_csv(os.path.join(base, "mdp_numeric.txt"), sep="\t")
        GM = pd.read_csv(os.path.join(base, "mdp_SNP_information.txt"), sep="\t")

        GAPIT(Y=Y, GD=GD, GM=GM, model="GLM",
              trait="EarHT", file_output=True,
              output_dir=str(tmp_path))

        output_files = list(tmp_path.iterdir())
        assert len(output_files) > 0, "No output files created"
        csv_files = [f for f in output_files if f.suffix == ".csv"]
        assert len(csv_files) >= 1, "No CSV output files created"

    def test_gapit_simulation_mode(self, tmp_path):
        """Simulation mode should override phenotype with simulated values."""
        from pygapit.gapit import GAPIT
        base = os.path.join(os.path.dirname(__file__), "..", "..", "GAPIT", "Documents")
        if not os.path.exists(os.path.join(base, "mdp_traits.txt")):
            pytest.skip("GAPIT demo data not available")

        Y  = pd.read_csv(os.path.join(base, "mdp_traits.txt"), sep="\t")
        GD = pd.read_csv(os.path.join(base, "mdp_numeric.txt"), sep="\t")
        GM = pd.read_csv(os.path.join(base, "mdp_SNP_information.txt"), sep="\t")

        result = GAPIT(Y=Y, GD=GD, GM=GM, model="GLM",
                       h2=0.7, NQTN=10,
                       file_output=False,
                       output_dir=str(tmp_path))
        assert result.GWAS is not None
        assert result.model == "GLM"


# ─────────────────────────────────────────────────────────────────────────────
# Tests: Visualization (smoke tests — just check no exceptions)
# ─────────────────────────────────────────────────────────────────────────────

class TestVisualization:

    def test_manhattan_plot(self, real_data, tmp_path):
        from pygapit.gwas.glm import glm_gwas
        from pygapit.visualization.plots import manhattan_plot
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        r = glm_gwas(real_data["y"], real_data["X0"], real_data["GD"])
        GM = real_data["GM"]
        fig = manhattan_plot(
            snp_names=GM["SNP"].values,
            chromosomes=GM["Chromosome"].values,
            positions=GM["Position"].values,
            p_values=r.p_values,
            save_path=str(tmp_path / "manhattan.pdf"),
        )
        assert fig is not None
        plt.close("all")

    def test_qq_plot(self, real_data, tmp_path):
        from pygapit.gwas.glm import glm_gwas
        from pygapit.visualization.plots import qq_plot
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        r = glm_gwas(real_data["y"], real_data["X0"], real_data["GD"])
        fig = qq_plot(r.p_values, save_path=str(tmp_path / "qq.pdf"))
        assert fig is not None
        plt.close("all")

    def test_kinship_heatmap(self, real_data, tmp_path):
        from pygapit.visualization.plots import kinship_heatmap
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig = kinship_heatmap(real_data["K"][:30, :30],
                              save_path=str(tmp_path / "kinship.pdf"))
        assert fig is not None
        plt.close("all")

    def test_pca_2d(self, real_data, tmp_path):
        from pygapit.stats.pca import compute_pca
        from pygapit.visualization.plots import pca_plot_2d
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        pca = compute_pca(real_data["GD"], n_components=3)
        fig = pca_plot_2d(pca.scores, pca.var_explained,
                          save_path=str(tmp_path / "pca.pdf"))
        assert fig is not None
        plt.close("all")

    def test_gs_scatter(self, real_data, tmp_path):
        from pygapit.gs.blup import gblup
        from pygapit.visualization.plots import gs_scatter
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        gs = gblup(real_data["y"], real_data["X0"], real_data["K"])
        fig = gs_scatter(real_data["y"], gs.prediction,
                         save_path=str(tmp_path / "gs.pdf"))
        assert fig is not None
        plt.close("all")
