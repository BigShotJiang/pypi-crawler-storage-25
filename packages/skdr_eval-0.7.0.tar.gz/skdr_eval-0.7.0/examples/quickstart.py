#!/usr/bin/env python3
"""Quickstart example for skdr-eval library."""

from sklearn.ensemble import HistGradientBoostingRegressor, RandomForestRegressor

import skdr_eval


def main():
    """Run the quickstart example."""
    print("skdr-eval Quickstart Example")
    print("=" * 50)

    # 1. Generate synthetic logs
    print("\n1. Generating synthetic service logs...")
    logs, ops_all, _ = skdr_eval.make_synth_logs(n=5000, n_ops=5, seed=42)

    # Preflight: confirm the logs schema is what evaluate_sklearn_models expects.
    skdr_eval.validate_logs(logs)

    print(f"   Generated {len(logs)} log entries")
    print(f"   Operators: {list(ops_all)}")
    print(
        f"   Service time range: {logs['service_time'].min():.2f} - {logs['service_time'].max():.2f}"
    )
    print(f"   Mean service time: {logs['service_time'].mean():.2f}")

    # 2. Define candidate models
    print("\n2. Defining candidate models...")
    models = {
        "RandomForest": RandomForestRegressor(
            n_estimators=100, max_depth=10, random_state=42
        ),
        "HistGradientBoosting": HistGradientBoostingRegressor(
            max_iter=100, max_depth=6, random_state=42
        ),
    }

    print(f"   Models to evaluate: {list(models.keys())}")

    # 3. Evaluate models using DR and SNDR
    print("\n3. Evaluating models with DR and SNDR...")
    print("   (This may take a moment...)")

    artifact = skdr_eval.evaluate_sklearn_models(
        logs=logs,
        models=models,
        fit_models=True,
        n_splits=3,
        outcome_estimator="hgb",
        random_state=42,
        policy_train="pre_split",
        policy_train_frac=0.8,
        keep_contributions=True,  # #92: enable per-decision V_hat contributions
    )

    # 0.6.0: evaluate_sklearn_models returns a single EvaluationArtifact bundling
    # the report DataFrame, per-model DRResult map, warnings, clip-grid
    # sensitivity, and propensity diagnostics.
    report = artifact.report
    detailed_results = artifact.detailed

    # 4. Display results
    print("\n4. Results Summary")
    print("-" * 50)

    # Format and display the report
    display_cols = [
        "model",
        "estimator",
        "V_hat",
        "SE_if",
        "clip",
        "ESS",
        "match_rate",
        "min_pscore",
    ]

    report_display = report[display_cols].copy()

    # Round numeric columns for better display
    numeric_cols = ["V_hat", "SE_if", "ESS", "match_rate", "min_pscore"]
    for col in numeric_cols:
        if col in report_display.columns:
            report_display[col] = report_display[col].round(4)

    print(report_display.to_string(index=False))

    # 5. Show detailed analysis for best model
    print("\n5. Detailed Analysis")
    print("-" * 50)

    # Find best model by DR estimate (lowest service time)
    dr_results = report[report["estimator"] == "DR"]
    best_model_name = dr_results.loc[dr_results["V_hat"].idxmin(), "model"]
    best_dr_value = dr_results.loc[dr_results["V_hat"].idxmin(), "V_hat"]

    print(f"Best model: {best_model_name}")
    print(f"Estimated service time (DR): {best_dr_value:.3f}")

    # Show clipping grid for best model
    best_detailed = detailed_results[best_model_name]
    dr_grid = best_detailed["DR"].grid
    sndr_grid = best_detailed["SNDR"].grid

    print(f"\nClipping analysis for {best_model_name}:")
    print("Clip | DR_Value | SNDR_Value | ESS   | Tail_Mass")
    print("-" * 50)

    for _, row in dr_grid.iterrows():
        sndr_value = sndr_grid[sndr_grid["clip"] == row["clip"]]["V_SNDR"].iloc[0]
        print(
            f"{row['clip']:4.0f} | {row['V_DR']:8.3f} | {sndr_value:10.3f} | "
            f"{row['ESS']:5.1f} | {row['tail_mass']:9.3f}"
        )

    # 6. Policy comparison
    print("\n6. Policy Performance Comparison")
    print("-" * 50)

    # Compare with baseline (mean observed service time)
    baseline_performance = logs["service_time"].mean()
    print(f"Baseline (observed): {baseline_performance:.3f}")

    for model_name in models:
        dr_value = report[
            (report["model"] == model_name) & (report["estimator"] == "DR")
        ]["V_hat"].iloc[0]
        sndr_value = report[
            (report["model"] == model_name) & (report["estimator"] == "SNDR")
        ]["V_hat"].iloc[0]

        dr_improvement = (
            (baseline_performance - dr_value) / baseline_performance
        ) * 100
        sndr_improvement = (
            (baseline_performance - sndr_value) / baseline_performance
        ) * 100

        print(f"{model_name}:")
        print(f"  DR:   {dr_value:.3f} ({dr_improvement:+.1f}% vs baseline)")
        print(f"  SNDR: {sndr_value:.3f} ({sndr_improvement:+.1f}% vs baseline)")

    # 7. Diagnostics
    print("\n7. Evaluation Diagnostics")
    print("-" * 50)

    for model_name in models:
        model_report = report[report["model"] == model_name]
        dr_row = model_report[model_report["estimator"] == "DR"].iloc[0]

        print(f"{model_name}:")
        print(f"  Match rate: {dr_row['match_rate']:.3f}")
        print(f"  Min p-score: {dr_row['min_pscore']:.6f}")
        print(f"  P-score Q01: {dr_row['pscore_q01']:.6f}")
        print(f"  P-score Q05: {dr_row['pscore_q05']:.6f}")
        print(f"  P-score Q10: {dr_row['pscore_q10']:.6f}")
        print(f"  ESS: {dr_row['ESS']:.1f}")

    # 8. Trust signals from the artifact
    print("\n8. Trust signals (from artifact.warnings)")
    print("-" * 50)
    print(artifact.warnings.to_string(index=False))

    # 8a. Trust diagnostics (#80, #84): PSIS Pareto-k + propensity calibration
    print("\n8a. Trust diagnostics (PSIS Pareto-k + propensity calibration)")
    print("-" * 50)
    pareto_cols = [
        c for c in ("model", "estimator", "pareto_k") if c in artifact.report.columns
    ]
    print(artifact.report[pareto_cols].to_string(index=False))
    for model_name, diag in artifact.diagnostics.items():
        print(
            f"   {model_name}: ECE={diag.ece:.4f}  Brier={diag.brier_score:.4f}  "
            f"(15-bin)"
        )

    # 9. Clip-grid sensitivity summary
    print("\n9. Clip-grid sensitivity (from artifact.sensitivity)")
    print("-" * 50)
    print(artifact.sensitivity.to_string(index=False))

    # 10. Export evaluation artifacts
    print("\n10. Export artifacts")
    print("-" * 50)
    written = artifact.export("artifacts/quickstart", formats=["json", "html"])
    print(f"   Wrote JSON: {written['json']}")
    print(f"   Wrote HTML: {written['html']}")

    # 11. Render a stakeholder card for the best model
    card_path = artifact.save_card(
        f"artifacts/quickstart_{best_model_name}_card.html",
        best_model_name,
    )
    print(f"   Wrote card: {card_path}")

    # 12. Per-decision contributions (issue #92)
    print("\n12. Top decisions driving V_hat (DR contributions)")
    print("-" * 50)
    top5 = artifact.contributions(best_model_name, estimator="DR", top_k=5)
    print(top5.to_string(index=False))

    print("\nQuickstart example completed!")
    print("\nNext steps:")
    print("- Try different models or hyperparameters")
    print("- Experiment with different clip_grid values")
    print("- Use bootstrap confidence intervals with ci_bootstrap=True")
    print("- Inspect artifact.diagnostics for propensity-quality details")


if __name__ == "__main__":
    main()
