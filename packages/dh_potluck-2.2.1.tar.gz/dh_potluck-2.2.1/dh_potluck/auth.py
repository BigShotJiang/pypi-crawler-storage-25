import hashlib
import logging
import re
from functools import wraps
from http import HTTPStatus
from pickle import loads
from typing import Callable, Optional, ParamSpec, TypeVar

import requests
from flask import current_app, g, jsonify, request
from flask_redis import FlaskRedis
from redis.exceptions import ConnectionError, TimeoutError

logger = logging.getLogger(__name__)


P = ParamSpec('P')
T = TypeVar('T')


auth_cookie_key = 'dashhudson-api-token'
impersonation_header_key = 'X-On-Behalf-Of'
auth_header_key = 'Authorization'
user_auth_header_value_prefix = 'Bearer'
app_auth_header_value_prefix = 'Application'


class AuthenticationError(Exception):
    description = 'Unknown Authentication Error'
    status = HTTPStatus.UNAUTHORIZED


class InvalidTokenError(AuthenticationError):
    description = 'Authentication token missing or invalid.'
    status = HTTPStatus.UNAUTHORIZED


class ImpersonationInvalidError(AuthenticationError):
    description = f'Invalid {impersonation_header_key} header provided.'
    status = HTTPStatus.FORBIDDEN


class ImpersonationUserNotFoundError(AuthenticationError):
    description = 'Unable to find user for impersonation.'
    status = HTTPStatus.FORBIDDEN


class PermissionDeniedError(AuthenticationError):
    description = 'You do not have access to this resource.'
    status = HTTPStatus.FORBIDDEN


class UnauthenticatedUser:
    role = None
    is_active = True

    def has_brand_access(self, brand: str | int) -> bool:
        return False

    def has_organization_access(self, org_id: int) -> bool:
        return False

    def has_permission(self, category: str, perm_key: str, brand: str | int) -> bool:
        return False

    def has_brand_permission(self, category: str, perm_key: str, brand: str | int) -> bool:
        return False

    def filter_brands_with_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> list[int]:
        return []

    def any_brand_has_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return False

    def all_brands_have_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return False

    def filter_brands_with_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> list[int]:
        return []

    def any_brand_has_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return False

    def all_brands_have_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return False

    def has_organization_permission(self, category: str, perm_key: str, org_id: int) -> bool:
        return False

    def has_user_organization_permission(self, category: str, perm_key: str, org_id: int) -> bool:
        return False


class AuthenticatedUser:
    id = None
    email = None
    first_name = None
    last_name = None
    default_time_zone = None
    time_zone_name = None
    password_reset_expires = None
    password_reset_url = None
    has_device = None
    status = None
    brandpanel_id = None
    is_superadmin = None
    is_shared = None
    is_pending = None
    job_title = None
    avatar_url = None
    organization = None
    brands = None
    accessible_brands: list[int] | None = None
    permissions = None
    updated_at = None
    created_at = None

    def __init__(self, *initial_data, **kwargs):
        for dictionary in initial_data:
            for key in dictionary:
                setattr(self, key, dictionary[key])
        for key in kwargs:
            setattr(self, key, kwargs[key])

    @property
    def role(self):
        if self.is_superadmin:
            return 'superadmin'
        return 'user'

    @property
    def is_active(self):
        return self.status == 0

    @property
    def _brand_id_to_label(self) -> dict[int, str]:
        if not hasattr(self, '_brand_id_label_map'):
            mapping: dict[int, str] = {}
            if self.brands:
                for label, brand_data in self.brands.items():
                    if isinstance(brand_data, dict):
                        bid = brand_data.get('id')
                        if bid is not None:
                            mapping[bid] = label
            self._brand_id_label_map = mapping
        return self._brand_id_label_map

    def _resolve_brand_label(self, brand: str | int) -> str | None:
        if isinstance(brand, str):
            return brand
        return self._brand_id_to_label.get(brand)

    def has_brand_access(self, brand: str | int) -> bool:
        if isinstance(brand, int):
            return brand in (self.accessible_brands or [])
        return brand in (self.brands or {})

    @property
    def _accessible_organization_ids(self) -> set[int]:
        if not hasattr(self, '_accessible_org_ids_cache'):
            result: set[int] = set()
            if self.brands:
                for brand_data in self.brands.values():
                    if isinstance(brand_data, dict):
                        org_id = brand_data.get('organization_id')
                        if org_id is not None:
                            result.add(int(org_id))
            self._accessible_org_ids_cache = result
        return self._accessible_org_ids_cache

    def has_organization_access(self, org_id: int) -> bool:
        return org_id in self._accessible_organization_ids

    def _resolve_org_id_for_brand(self, brand: str | int) -> str | None:
        label = self._resolve_brand_label(brand)
        if label is None or not self.brands:
            return None
        brand_data = self.brands.get(label)
        if not isinstance(brand_data, dict):
            return None
        org_id = brand_data.get('organization_id')
        return str(org_id) if org_id is not None else None

    def has_permission(self, category: str, perm_key: str, brand: str | int) -> bool:
        if self.is_superadmin and self.has_brand_access(brand):
            return True
        label = self._resolve_brand_label(brand)
        if label is None or not self.permissions:
            return False
        try:
            return bool(self.permissions.get(category, {}).get(label, {}).get(perm_key, False))
        except AttributeError:
            return False

    def has_brand_permission(self, category: str, perm_key: str, brand: str | int) -> bool:
        if self.is_superadmin and self.has_brand_access(brand):
            return True
        label = self._resolve_brand_label(brand)
        if label is None or not self.brands:
            return False
        try:
            brand_data = self.brands.get(label, {})
            return bool(brand_data.get('permissions', {}).get(category, {}).get(perm_key, False))
        except AttributeError:
            return False

    def _resolve_brands(self, brands: list[str | int] | None) -> list[int]:
        if brands is not None:
            result = []
            for b in brands:
                if isinstance(b, int):
                    result.append(b)
                else:
                    # label -> id
                    for bid, label in self._brand_id_to_label.items():
                        if label == b:
                            result.append(bid)
                            break
            return result
        return list(self.accessible_brands) if self.accessible_brands else []

    def filter_brands_with_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> list[int]:
        return [
            b for b in self._resolve_brands(brands) if self.has_permission(category, perm_key, b)
        ]

    def any_brand_has_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return any(self.has_permission(category, perm_key, b) for b in self._resolve_brands(brands))

    def all_brands_have_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        resolved = self._resolve_brands(brands)
        if not resolved:
            return False
        return all(self.has_permission(category, perm_key, b) for b in resolved)

    def filter_brands_with_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> list[int]:
        return [
            b
            for b in self._resolve_brands(brands)
            if self.has_brand_permission(category, perm_key, b)
        ]

    def any_brand_has_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return any(
            self.has_brand_permission(category, perm_key, b) for b in self._resolve_brands(brands)
        )

    def all_brands_have_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        resolved = self._resolve_brands(brands)
        if not resolved:
            return False
        return all(self.has_brand_permission(category, perm_key, b) for b in resolved)

    def has_organization_permission(self, category: str, perm_key: str, org_id: int) -> bool:
        if self.is_superadmin and self.has_organization_access(org_id):
            return True
        org_perms = getattr(self, 'organization_permissions', None)
        if not org_perms:
            return False
        try:
            return bool(org_perms.get(str(org_id), {}).get(category, {}).get(perm_key, False))
        except AttributeError:
            return False

    def has_user_organization_permission(self, category: str, perm_key: str, org_id: int) -> bool:
        if self.is_superadmin and self.has_organization_access(org_id):
            return True
        org_user_perms = getattr(self, 'organization_user_permissions', None)
        if not org_user_perms:
            return False
        try:
            return bool(org_user_perms.get(str(org_id), {}).get(category, {}).get(perm_key, False))
        except AttributeError:
            return False


class ApplicationUser:
    role = 'app'
    is_active = True
    is_shared = False

    def has_brand_access(self, brand: str | int) -> bool:
        return True

    def has_organization_access(self, org_id: int) -> bool:
        return True

    def has_permission(self, category: str, perm_key: str, brand: str | int) -> bool:
        return True

    def has_brand_permission(self, category: str, perm_key: str, brand: str | int) -> bool:
        return True

    def filter_brands_with_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> list[int]:
        return [b for b in (brands or []) if isinstance(b, int)]

    def any_brand_has_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return True

    def all_brands_have_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return True

    def filter_brands_with_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> list[int]:
        return [b for b in (brands or []) if isinstance(b, int)]

    def any_brand_has_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return True

    def all_brands_have_brand_permission(
        self, category: str, perm_key: str, brands: list[str | int] | None = None
    ) -> bool:
        return True

    def has_organization_permission(self, category: str, perm_key: str, org_id: int) -> bool:
        return True

    def has_user_organization_permission(self, category: str, perm_key: str, org_id: int) -> bool:
        return True


def authenticate_request(app_tokens, validate_token_func):
    user, valid_token = _handle_auth_header(app_tokens, validate_token_func)

    if not user:
        user, valid_token = _handle_auth_cookie(user, valid_token, validate_token_func)

    if not user or not user.is_active:
        user = UnauthenticatedUser()

    user, impersonator = _handle_impersonation(user, valid_token, validate_token_func)

    return user, impersonator


def _handle_auth_header(app_tokens, validate_token_func):
    user = None
    valid_token = None
    # handle header authentication
    auth_header = request.headers.get(auth_header_key)
    if auth_header is not None:
        match = re.match(
            rf'^({app_auth_header_value_prefix}|{user_auth_header_value_prefix}):? (\S+)$',
            auth_header,
        )
        if match:
            method = match.group(1)
            token = match.group(2)

            # Application token
            if method == app_auth_header_value_prefix:
                if token in app_tokens:
                    valid_token = token
                    user = ApplicationUser()

            # Bearer token
            elif method == user_auth_header_value_prefix:
                potential_user = validate_token_func(token)
                if potential_user:
                    valid_token = token
                    user = potential_user
    return user, valid_token


def _handle_auth_cookie(user, valid_token, validate_token_func):
    # handle cookie authentication
    auth_cookie = request.cookies.get(auth_cookie_key)
    if auth_cookie:
        potential_user = validate_token_func(auth_cookie)
        if potential_user:
            valid_token = auth_cookie
            user = potential_user
    return user, valid_token


def _handle_impersonation(user, valid_token, validate_token_func):
    impersonator = None
    on_behalf_of_user_id_str = request.headers.get(impersonation_header_key)
    if on_behalf_of_user_id_str:
        if valid_token and user_has_role(user, 'superadmin'):
            try:
                on_behalf_of_user_id = int(on_behalf_of_user_id_str)
            except ValueError:
                raise ImpersonationInvalidError()
            user_to_impersonate = validate_token_func(
                valid_token,
                (
                    app_auth_header_value_prefix
                    if isinstance(user, ApplicationUser)
                    else user_auth_header_value_prefix
                ),
                on_behalf_of_user_id,
            )
            if user_to_impersonate:
                impersonator = user
                user = user_to_impersonate
            else:
                raise ImpersonationUserNotFoundError()
        else:
            raise ImpersonationInvalidError()
    return user, impersonator


roles = {
    'user': 0,
    'brand_admin': 1,
    'superadmin': 2,
    'app': 3,
}


def user_has_role(user, role):
    if not user.role:
        return False
    return roles[user.role] >= roles[role]


def role_required(role, shareable=False):
    """
    Currently, the supported roles are:

    1. user
    2. brand_admin
    3. superadmin
    4. app

    Roles are ordered from least to most privilege. Each role receives the permissions of the roles
    before it. Example:

    If role='user', users with 'user', 'superadmin', or 'app' roles will be granted access.
    If role='superadmin', only users with 'superadmin' or 'app' roles will be granted access.
    """

    def decorator(func):
        # finds the role within a brand of the current user
        def get_brand_role():
            # extract the brand_id from the path
            brand_id = request.view_args.get('brand_id')
            if not brand_id:
                return None

            # use the brand_id to find the specific brand_role from the list of brand_roles
            brs = g.user.permissions.get('brand_roles', [])
            br = next((br.get('role') for br in brs if br.get('brand_id') == brand_id), None)

            # br.value will exist if g.user is assigned a user model (called from auth)
            # otherwise, br alone is the value we want
            return getattr(br, 'value', br)

        @wraps(func)
        def wrapper(*args, **kwargs):
            if isinstance(g.user, UnauthenticatedUser):
                raise InvalidTokenError()

            if getattr(g.user, 'is_shared', False) and not shareable:
                raise PermissionDeniedError()

            if user_has_role(g.user, role):
                return func(*args, **kwargs)

            # a check for the brand_admin role is needed as it isn't stored in the user instance
            if role == 'brand_admin' and g.user.brands and get_brand_role() == 'admin':
                return func(*args, **kwargs)

            raise PermissionDeniedError()

        return wrapper

    return decorator


def brand_access_required(
    *, brand_id_arg: str = 'brand_id'
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            brand_id = (request.view_args or {}).get(brand_id_arg)
            if brand_id is None or not g.user.has_brand_access(brand_id):
                raise PermissionDeniedError()
            return func(*args, **kwargs)

        return wrapper

    return decorator


def user_brand_permission_required(
    category: str, perm_key: str, *, brand_id_arg: str = 'brand_id'
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            brand_id = (request.view_args or {}).get(brand_id_arg)
            if brand_id is None or not g.user.has_permission(category, perm_key, brand_id):
                raise PermissionDeniedError()
            return func(*args, **kwargs)

        return wrapper

    return decorator


def brand_permission_required(
    category: str, perm_key: str, *, brand_id_arg: str = 'brand_id'
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            brand_id = (request.view_args or {}).get(brand_id_arg)
            if brand_id is None or not g.user.has_brand_permission(category, perm_key, brand_id):
                raise PermissionDeniedError()
            return func(*args, **kwargs)

        return wrapper

    return decorator


def organization_access_required(
    *, org_id_arg: str = 'org_id'
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            org_id = (request.view_args or {}).get(org_id_arg)
            if org_id is None or not g.user.has_organization_access(org_id):
                raise PermissionDeniedError()
            return func(*args, **kwargs)

        return wrapper

    return decorator


def organization_permission_required(
    category: str, perm_key: str, *, org_id_arg: str = 'org_id'
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            org_id = (request.view_args or {}).get(org_id_arg)
            if org_id is None or not g.user.has_organization_permission(category, perm_key, org_id):
                raise PermissionDeniedError()
            return func(*args, **kwargs)

        return wrapper

    return decorator


def user_organization_permission_required(
    category: str, perm_key: str, *, org_id_arg: str = 'org_id'
) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def decorator(func: Callable[P, T]) -> Callable[P, T]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            org_id = (request.view_args or {}).get(org_id_arg)
            if org_id is None or not g.user.has_user_organization_permission(
                category, perm_key, org_id
            ):
                raise PermissionDeniedError()
            return func(*args, **kwargs)

        return wrapper

    return decorator


class AuthCache(object):
    cache = None

    @classmethod
    def get_cache(cls):
        if not current_app.config.get('DH_POTLUCK_AUTH_REDIS_URL'):
            logger.debug('Identity cache url (DH_POTLUCK_AUTH_REDIS_URL) not configured')
            return None
        if not cls.cache:
            cls.cache = FlaskRedis(
                app=current_app, config_prefix='DH_POTLUCK_AUTH_REDIS', socket_timeout=0.4
            )
        return cls.cache


def _get_from_cache(token):
    logger.debug('Get identity from cache')
    cache = AuthCache.get_cache()
    if not cache:
        return None
    try:
        cached_identity = cache.get(get_auth_cache_key(token))
        if cached_identity:
            logger.debug('Identity found!')
            return jsonify(loads(cached_identity)).json
    except (ConnectionError, TimeoutError) as e:
        logger.exception(f'Error getting identity from cache: {e}')
        return None


def get_auth_cache_key(token):
    hash_object = hashlib.sha256(token.encode('utf-8'))
    token_hash = hash_object.hexdigest()
    return f'auth:token#{token_hash}'


def validate_token_using_api(
    token: str,
    token_prefix: str = user_auth_header_value_prefix,
    on_behalf_of_user_id: Optional[int] = None,
) -> Optional[AuthenticatedUser]:
    if current_app.config.get('DH_POTLUCK_ENABLE_AUTH_CACHE') and not on_behalf_of_user_id:
        identity = _get_from_cache(token)
        if identity:
            return AuthenticatedUser(identity)

    logger.debug(
        f'Get {"impersonating" if on_behalf_of_user_id else ""} identity from auth service'
    )

    headers = {
        'Authorization': f'{token_prefix} {token}',
        'content-type': 'application/json',
    }
    if on_behalf_of_user_id:
        headers[impersonation_header_key] = str(on_behalf_of_user_id)
        if token_prefix == app_auth_header_value_prefix:
            token = current_app.config['DH_POTLUCK_AUTH_API_TOKEN']
            headers['Authorization'] = f'{token_prefix} {token}'

    auth_api_url = current_app.config['DH_POTLUCK_AUTH_API_URL']
    res = requests.get(auth_api_url + 'self', headers=headers)
    if res.status_code == HTTPStatus.OK:
        identity = res.json()
        if token.startswith('share-'):
            identity['is_shared'] = True
        return AuthenticatedUser(identity)

    return None
