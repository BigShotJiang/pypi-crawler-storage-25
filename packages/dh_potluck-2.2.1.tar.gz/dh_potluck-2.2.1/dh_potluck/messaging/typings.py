from typing import Any, Callable, Dict, List, Optional, Tuple, Union

from marshmallow import Schema

from dh_potluck.messaging import Message

# See: https://github.com/edenhill/librdkafka/blob/master/CONFIGURATION.md
# Cannot use a TypedDict easily here, see: https://github.com/python/mypy/issues/6462
ConsumerConfig = Dict[str, Any]

BatchingMessagesHandler = Callable[[str, List[Message]], Optional[bool]]

MessageFilterFunction = Callable[[str, str, Dict[str, Any]], bool]

# Schema dict key: either a message_type string or a (topic, message_type) tuple.
# The tuple form takes priority during lookup, falling back to message_type-only.
SchemaKey = Union[str, Tuple[str, str]]
SchemasDict = Dict[SchemaKey, Schema]
