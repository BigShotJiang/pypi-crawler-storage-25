import json
import logging
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Final, Iterable, Iterator, List, Optional, Pattern, Tuple

from confluent_kafka import Consumer, KafkaError, KafkaException
from confluent_kafka import Message as RawMessage
from confluent_kafka import TopicPartition

from dh_potluck.decorators import retry
from dh_potluck.messaging import Message, MessageEnvelopeSchema
from dh_potluck.messaging.exceptions import CommitTimeoutException
from dh_potluck.messaging.typings import ConsumerConfig, MessageFilterFunction
from dh_potluck.messaging.utils import build_consumer_config

RETRYABLE_COMMIT_ERROR_MAP: Final = {
    KafkaError.REQUEST_TIMED_OUT: CommitTimeoutException,
}

LOG = logging.getLogger(__name__)


@dataclass(frozen=True)
class BatchConfig:
    batch_size: int
    release_after: float  # in milliseconds


@dataclass
class _BatchState:
    messages: List[Message] = field(default_factory=list)
    deadline: Optional[float] = None


class BatchingMessageConsumer:

    _consumer: Consumer
    _default_batch_config: BatchConfig
    _auto_commit: bool
    _poll_timeout: float
    _shutdown: bool
    _message_schema: MessageEnvelopeSchema = MessageEnvelopeSchema()
    _message_filters: Dict[str, Optional[MessageFilterFunction]]
    _regex_message_filters: Dict[Pattern[str], Optional[MessageFilterFunction]]

    # Per-topic batch configuration and state
    _topic_batch_configs: Dict[str, BatchConfig]
    _topic_batch_states: Dict[str, _BatchState]

    # Default batch state (for topics without per-topic config)
    _default_batch_state: _BatchState

    def __init__(
        self,
        consumer_group_id: str,
        batch_size: int,
        release_after: float,
        auto_commit: bool = True,
        poll_timeout: float = 1.0,
        config_overrides: Optional[ConsumerConfig] = None,
        brokers: Optional[str] = None,
        should_connect_ssl: Optional[bool] = None,
    ) -> None:
        """
        BatchingMessageConsumer is a consumer that waits to collect batches of messages before
        releasing them for consumption
        :param str consumer_group_id: The kafka consumer group ID to use
        :param int batch_size: The max number of messages to collect before releasing a batch
        :param float release_after: How long to wait before releasing a batch if batch_size isn't
            exceeded (in milliseconds)
        :param bool auto_commit: If truthy, BatchingMessageConsumer will commit offsets for a batch
            under the hood. If falsy, then developers will be responsible for this behavior
        :param float poll_timeout: The poll_timeout config to pass to the inner Kafka consumer
        :param dict config_overrides: Custom config to pass to the inner Kafka consumer
        :param str brokers: list of brokers to connect to (also can be provided via the flask
            config `KAFKA_BROKERS_LIST`)
        :param bool should_connect_ssl: if a ssl connection should be used to kafka (also can be
            provided via the flask config `KAFKA_USE_SSL_CONNECTION`)
        """
        self._consumer = Consumer(
            build_consumer_config(consumer_group_id, config_overrides, brokers, should_connect_ssl)
        )
        self._default_batch_config = BatchConfig(batch_size=batch_size, release_after=release_after)
        self._auto_commit = auto_commit
        self._poll_timeout = poll_timeout
        self._shutdown = False
        self._default_batch_state = _BatchState()
        self._topic_batch_configs = {}
        self._topic_batch_states = {}
        self._message_filters = {}
        self._regex_message_filters = {}

    def subscribe(self, topics: Iterable[str]) -> None:
        """
        Subscribe to a list of topics
        :param list[str] topics: The list of topics to subscribe to
        """
        LOG.debug(f'Subscribing batching consumer to topics: {topics}')
        self._consumer.subscribe(list(topics))

    def get_batches(self) -> Iterator[List[Message]]:
        """
        Get messages from topic(s) and yield batches of them.
        When per-topic batch configs are set, yields batches from each configured
        topic separately based on their individual batch_size and release_after settings.
        :return: Iterator[Message]
        """
        LOG.debug('Starting batching consumer')
        while not self._shutdown:
            ready_batches = self._get_ready_batches()
            if ready_batches:
                all_messages = []
                for batch_key, batch_messages in ready_batches:
                    LOG.debug(f'Releasing batch for key={batch_key}')
                    yield batch_messages
                    all_messages.extend(batch_messages)
                    self._do_reset_batch_state(batch_key)
                if self._auto_commit and all_messages:
                    self._do_auto_commit(all_messages)
            self._do_poll_for_raw_messages()
        self._do_shutdown()

    def commit(self, messages: List[Message], asynchronous: bool = False) -> None:
        """
        Commit offsets for a list of Messages
        :param list[Message] messages: The list of messages to commit for
        :param bool asynchronous: Controls if commits should be async
        """
        LOG.debug(f'Manually committing offsets for {len(messages)} messages')
        for m in messages:
            self._consumer.commit(message=m.raw_message(), asynchronous=asynchronous)

    def force_shutdown(self) -> None:
        """
        Forcibly shutdown the batching consumer / polling loop
        """
        LOG.debug('Force shutting down batching consumer')
        self._shutdown = True

    def add_message_filter(
        self,
        topic: str,
        message_filter: Optional[MessageFilterFunction],
    ) -> None:
        """
        Adds a filter function to discard messages on the topic from the batch to increase
        performance of things happening on the handler. Be cautious using these filters,
        because they can have a negative impact to the message throughput
        :param str topic: Kafka topic to associate this filter with
        :param FilterFuncType message_filter: Function to use as a filter on each message
        """
        LOG.debug(f'Adding filter function for [topic: {topic}] to batching consumer')
        # regexes must start with ^ for kafka to pick up on them
        if topic.startswith('^'):
            self._regex_message_filters[re.compile(topic)] = message_filter
        else:
            self._message_filters[topic] = message_filter

    def add_batch_config(
        self,
        topic: str,
        batch_size: int,
        release_after: float,
    ) -> None:
        """
        Adds per-topic batch configuration. Messages matching this topic will be batched
        separately from the default batch, using the specified batch_size and release_after
        settings.

        This enables deterministic batch sizes per topic when subscribing to multiple topics,
        ensuring that high-volume topics don't dominate batches meant for lower-volume topics.

        :param str topic: Kafka topic to associate this config with
        :param int batch_size: Max number of messages before releasing a batch for this topic
        :param float release_after: Time in milliseconds before releasing a batch for this topic
        """
        LOG.debug(
            f'Adding batch config for [topic: {topic}] '
            f'with batch_size={batch_size}, release_after={release_after}'
        )
        self._topic_batch_configs[topic] = BatchConfig(
            batch_size=batch_size, release_after=release_after
        )
        self._topic_batch_states[topic] = _BatchState()

    def _do_poll_for_raw_messages(self) -> None:
        """
        Poll topic(s) for messages and pass them along for collection into batches
        """
        raw_message = self._consumer.poll(timeout=self._poll_timeout)
        if raw_message is None:
            return
        err = raw_message.error()
        if err:
            LOG.error(f'Consumer error: {err}')
            return
        self._do_collect_raw_message(raw_message)

    def _do_collect_raw_message(self, raw_message: RawMessage) -> None:
        """
        Collect a raw Kafka message, transform it into a DH message and collect it in a batch.
        Routes the message to a per-topic batch if configured, otherwise to the default batch.
        :param RawMessage raw_message: The raw Kafka message object
        """
        message_value_str = raw_message.value().decode('utf-8')
        message_value = self._message_schema.loads(message_value_str)
        message_type = message_value['message_type']
        topic = raw_message.topic()

        batch_state, batch_config = self._get_batch_state_and_config(topic)

        # Set deadline when first message arrives (before filtering, matching original behavior)
        # This ensures batches can time out even if all messages are filtered out
        if batch_state.deadline is None:
            batch_state.deadline = batch_config.release_after / 1000.0 + time.time()

        LOG.debug(f'Received message: {message_value_str}')

        if self._should_filter_message(topic, message_type, message_value):
            return

        message = Message(topic, message_value, raw_message)
        batch_state.messages.append(message)

    def _get_batch_state_and_config(self, topic: str) -> Tuple[_BatchState, BatchConfig]:
        if topic in self._topic_batch_configs:
            return self._topic_batch_states[topic], self._topic_batch_configs[topic]
        return self._default_batch_state, self._default_batch_config

    def _get_message_filter(self, topic: str) -> Optional[MessageFilterFunction]:
        message_filter = self._message_filters.get(topic)

        if not message_filter:
            for topic_regex, _filter in self._regex_message_filters.items():
                if topic_regex.match(topic):
                    message_filter = _filter
                    break

        return message_filter

    def _should_filter_message(
        self, topic: str, message_type: str, message_value: Dict[str, Any]
    ) -> bool:
        message_filter = self._get_message_filter(topic)
        if message_filter is None:
            return False
        return not message_filter(topic, message_type, json.loads(message_value['payload']))

    @staticmethod
    def _should_release_batch_state(batch_state: _BatchState, batch_config: BatchConfig) -> bool:
        """
        Checks if a specific batch should be released based on size or deadline.
        Returns True if batch_size is exceeded OR if deadline has passed (even for empty batches).
        """
        batch_size_exceeded = len(batch_state.messages) >= batch_config.batch_size
        batch_deadline_exceeded = (
            batch_state.deadline is not None and time.time() > batch_state.deadline
        )
        return batch_size_exceeded or batch_deadline_exceeded

    def _get_ready_batches(
        self,
    ) -> List[Tuple[Optional[str], List[Message]]]:
        """
        Returns a list of (batch_key, messages) tuples for batches ready to be released.
        batch_key is None for the default batch, or a topic string for per-topic batches.
        """
        ready_batches: List[Tuple[Optional[str], List[Message]]] = []

        # Check per-topic batches first
        for batch_key, batch_state in self._topic_batch_states.items():
            batch_config = self._topic_batch_configs[batch_key]
            if self._should_release_batch_state(batch_state, batch_config):
                ready_batches.append((batch_key, batch_state.messages))

        # Check default batch
        if self._should_release_batch_state(self._default_batch_state, self._default_batch_config):
            ready_batches.append((None, self._default_batch_state.messages))

        return ready_batches

    @retry(tuple(RETRYABLE_COMMIT_ERROR_MAP.values()))
    def _do_auto_commit(self, messages: List[Message]) -> None:
        """
        Commit offsets for batch of messages synchronously in a single bulk call.
        Computes the highest offset per (topic, partition) and commits them all at once,
        reducing N per-message round-trips to 1. Does expo. retries on network timeouts.
        """
        LOG.debug(f'Attempting to auto-commit for {len(messages)} messages')

        offsets = self._compute_batch_offsets(messages)
        if not offsets:
            LOG.debug('No offsets to commit')
            return

        try:
            self._consumer.commit(offsets=offsets, asynchronous=False)
        except KafkaException as exc:
            error_code = exc.args[0].code()
            if error_code == KafkaError._NO_OFFSET:
                LOG.warning('Unable to commit offset', exc_info=exc)
                return
            raise RETRYABLE_COMMIT_ERROR_MAP.get(error_code, exc)
        LOG.debug(f'Committed offsets for {len(messages)} messages')

    @staticmethod
    def _compute_batch_offsets(messages: List[Message]) -> List[TopicPartition]:
        highest: Dict[Tuple[str, int], int] = {}
        for message in messages:
            raw = message.raw_message()
            key = (raw.topic(), raw.partition())
            offset = raw.offset()
            if key not in highest or offset > highest[key]:
                highest[key] = offset

        return [
            TopicPartition(topic, partition, offset + 1)
            for (topic, partition), offset in highest.items()
        ]

    def _do_reset_batch_state(self, batch_key: Optional[str] = None) -> None:
        """
        Reset the batch state back to the default.
        :param batch_key: The batch key to reset. None means reset the default batch.
        """
        LOG.debug(f'Resetting batch state for key={batch_key}')
        if batch_key is not None:
            self._topic_batch_states[batch_key] = _BatchState()
        else:
            self._default_batch_state = _BatchState()

    def _do_shutdown(self) -> None:
        """
        Flush out the batch state and close the connection to the topic(s)
        """
        LOG.debug('Stopping batching consumer')

        self._do_reset_batch_state(None)  # reset default batch

        for batch_key in list(self._topic_batch_states.keys()):
            self._do_reset_batch_state(batch_key)
        if self._consumer:
            self._consumer.close()
        LOG.debug('Stopped batching consumer')

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._do_shutdown()

    @property
    def auto_commit(self) -> bool:
        return self._auto_commit
