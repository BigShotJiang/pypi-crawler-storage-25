"""Utilities for converting ATIF and Harbor traces into Docent AgentRuns.

This module keeps the Harbor conversion helpers in the SDK so they can be
imported from regular Docent code instead of living under `personal/`.
"""

from __future__ import annotations

import json
import sys
from collections.abc import Iterable, Iterator
from contextlib import contextmanager
from copy import deepcopy
from pathlib import Path
from typing import Any, TextIO, TypeGuard, cast
from uuid import uuid4

from docent.data_models.agent_run import AgentRun
from docent.sdk.integrations.util import (
    ConversionError,
    JsonDict,
    optional_dict,
    require_dict,
    require_existing_directory,
    require_list,
    require_string,
)


def _require_dict(value: Any, context: str) -> JsonDict:
    return require_dict(value, context, exc_type=ConversionError)


def _require_list(value: Any, context: str) -> list[Any]:
    return require_list(value, context, exc_type=ConversionError)


def _require_string(value: Any, context: str) -> str:
    return require_string(value, context, exc_type=ConversionError)


def _optional_string(value: Any, context: str) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str):
        raise ConversionError(f"{context} must be a string when present")
    return value


def _optional_dict(value: Any, context: str) -> JsonDict | None:
    return optional_dict(value, context, exc_type=ConversionError)


def _deepcopy_if_present(value: Any) -> Any:
    if value is None:
        return None
    return deepcopy(value)


def _content_text(text: str) -> JsonDict:
    return {"type": "text", "text": text}


def _content_reasoning(reasoning: str) -> JsonDict:
    return {"type": "reasoning", "reasoning": reasoning}


def _convert_atif_content(
    raw_content: Any,
    *,
    context: str,
) -> tuple[str | list[JsonDict], JsonDict | None]:
    content_items: list[JsonDict] = []

    if isinstance(raw_content, str):
        return raw_content, None
    elif isinstance(raw_content, list):
        raw_parts = cast(list[Any], raw_content)
        for part_index, raw_part in enumerate(raw_parts):
            part = _require_dict(raw_part, f"{context}[{part_index}]")
            part_type = _require_string(part.get("type"), f"{context}[{part_index}].type")

            if part_type == "text":
                text = _require_string(part.get("text"), f"{context}[{part_index}].text")
                content_items.append(_content_text(text))
                continue

            if part_type == "image":
                source = _require_dict(part.get("source"), f"{context}[{part_index}].source")
                media_type = _require_string(
                    source.get("media_type"),
                    f"{context}[{part_index}].source.media_type",
                )
                path = _require_string(source.get("path"), f"{context}[{part_index}].source.path")
                raise ConversionError(
                    f"{context}[{part_index}] is an image part "
                    f"({media_type} at {path}), but Docent chat messages "
                    "currently only support text and reasoning content"
                )

            raise ConversionError(
                f"{context}[{part_index}].type must be 'text' or 'image', got {part_type!r}"
            )
    else:
        raise ConversionError(f"{context} must be a string or an array of content parts")

    if not content_items:
        return "", None
    if len(content_items) == 1 and content_items[0]["type"] == "text":
        return content_items[0]["text"], None
    return content_items, None


def _convert_tool_calls(
    raw_tool_calls: Any,
    *,
    step_context: str,
) -> tuple[list[JsonDict], dict[str, str]]:
    tool_calls: list[JsonDict] = []
    tool_call_id_to_function: dict[str, str] = {}

    for call_index, raw_call in enumerate(_require_list(raw_tool_calls, step_context)):
        call = _require_dict(raw_call, f"{step_context}[{call_index}]")
        tool_call_id = _require_string(
            call.get("tool_call_id"),
            f"{step_context}[{call_index}].tool_call_id",
        )
        if tool_call_id in tool_call_id_to_function:
            raise ConversionError(
                f"{step_context}[{call_index}].tool_call_id duplicates an earlier "
                f"tool call in the same step: {tool_call_id!r}"
            )
        function_name = _require_string(
            call.get("function_name"),
            f"{step_context}[{call_index}].function_name",
        )
        if "arguments" not in call:
            raise ConversionError(f"{step_context}[{call_index}].arguments is required")
        arguments_value = call["arguments"]
        if not isinstance(arguments_value, dict):
            raise ConversionError(f"{step_context}[{call_index}].arguments must be an object")
        arguments = cast(JsonDict, arguments_value)

        tool_calls.append(
            {
                "id": tool_call_id,
                "type": "function",
                "function": function_name,
                "arguments": deepcopy(arguments),
            }
        )
        tool_call_id_to_function[tool_call_id] = function_name

    return tool_calls, tool_call_id_to_function


def _raise_on_subagent_refs(raw_refs: list[Any], context: str) -> None:
    for ref_index, raw_ref in enumerate(raw_refs):
        ref = _require_dict(raw_ref, f"{context}[{ref_index}]")
        session_id = _require_string(ref.get("session_id"), f"{context}[{ref_index}].session_id")
        trajectory_path = _optional_string(
            ref.get("trajectory_path"),
            f"{context}[{ref_index}].trajectory_path",
        )
        ref_desc = session_id if trajectory_path is None else f"{session_id} ({trajectory_path})"
        raise ConversionError(
            "ATIF subagent_trajectory_ref is not supported by this converter because it "
            f"emits a single standalone Docent AgentRun. Found {ref_desc} at {context}."
        )


def _base_message_metadata(step: JsonDict, *, step_id: int, step_source: str) -> JsonDict:
    metadata: JsonDict = {
        "atif_step_id": step_id,
        "atif_source": step_source,
    }

    timestamp = _optional_string(step.get("timestamp"), f"steps[{step_id - 1}].timestamp")
    if timestamp is not None:
        metadata["atif_timestamp"] = timestamp

    extra = _optional_dict(step.get("extra"), f"steps[{step_id - 1}].extra")
    if extra:
        metadata["atif_extra"] = deepcopy(extra)

    return metadata


def _convert_observation_messages(
    step: JsonDict,
    *,
    step_id: int,
    step_source: str,
    tool_call_lookup: dict[str, str],
) -> list[JsonDict]:
    observation = step.get("observation")
    if observation is None:
        return []

    observation_obj = _require_dict(observation, f"steps[{step_id - 1}].observation")
    results = _require_list(
        observation_obj.get("results"), f"steps[{step_id - 1}].observation.results"
    )

    messages: list[JsonDict] = []
    for result_index, raw_result in enumerate(results):
        result = _require_dict(
            raw_result,
            f"steps[{step_id - 1}].observation.results[{result_index}]",
        )

        source_call_id = _optional_string(
            result.get("source_call_id"),
            (f"steps[{step_id - 1}].observation.results[{result_index}].source_call_id"),
        )

        raw_subagent_refs = result.get("subagent_trajectory_ref")
        if raw_subagent_refs is not None:
            _raise_on_subagent_refs(
                _require_list(
                    raw_subagent_refs,
                    f"steps[{step_id - 1}].observation.results"
                    f"[{result_index}].subagent_trajectory_ref",
                ),
                f"steps[{step_id - 1}].observation.results[{result_index}].subagent_trajectory_ref",
            )

        raw_content = result.get("content", "")
        content, conversion_metadata = _convert_atif_content(
            raw_content,
            context=f"steps[{step_id - 1}].observation.results[{result_index}].content",
        )

        metadata = _base_message_metadata(step, step_id=step_id, step_source=step_source)
        metadata["atif_observation_index"] = result_index
        if source_call_id is not None:
            metadata["atif_source_call_id"] = source_call_id
        if conversion_metadata is not None:
            metadata["docent_conversion"] = conversion_metadata
        if source_call_id and source_call_id not in tool_call_lookup:
            raise ConversionError(
                "ATIF observation result references a source_call_id that does not appear "
                f"in the same step's tool_calls array: {source_call_id!r} at "
                f"steps[{step_id - 1}].observation.results[{result_index}].source_call_id"
            )

        function_name = tool_call_lookup.get(source_call_id) if source_call_id is not None else None
        tool_message: JsonDict = {
            "role": "tool",
            "content": content,
        }
        if source_call_id is not None:
            tool_message["tool_call_id"] = source_call_id
        if function_name is not None:
            tool_message["function"] = function_name
        if metadata:
            tool_message["metadata"] = metadata
        messages.append(tool_message)

    return messages


def _build_assistant_turn_content(
    *,
    reasoning_parts: list[str],
    text_parts: list[str | list[JsonDict]],
) -> str | list[JsonDict]:
    reasoning_text = "\n\n".join(part for part in reasoning_parts if part)
    text_content_items: list[JsonDict] = []
    plain_text_parts: list[str] = []
    structured_text_present = False

    for text_part in text_parts:
        if isinstance(text_part, str):
            plain_text_parts.append(text_part)
            if text_part:
                text_content_items.append(_content_text(text_part))
            continue

        structured_text_present = True
        text_content_items.extend(deepcopy(text_part))

    if reasoning_text:
        content: list[JsonDict] = [_content_reasoning(reasoning_text)]
        content.extend(text_content_items)
        return content

    if not text_parts:
        return ""
    if not structured_text_present:
        return "".join(plain_text_parts)
    if not text_content_items:
        return ""
    return text_content_items


def _build_assistant_turn_metadata(
    *,
    step_metadatas: list[JsonDict],
    model_names: list[str | None],
) -> JsonDict:
    if not step_metadatas:
        return {}

    if len(step_metadatas) == 1:
        return deepcopy(step_metadatas[0])

    step_ids: list[int] = []
    timestamps: list[str] = []
    for step_metadata in step_metadatas:
        step_id = step_metadata.get("atif_step_id")
        if isinstance(step_id, int):
            step_ids.append(step_id)

        timestamp = step_metadata.get("atif_timestamp")
        if isinstance(timestamp, str):
            timestamps.append(timestamp)

    metadata: JsonDict = {
        "atif_source": "agent",
        "atif_step_ids": step_ids,
        "atif_source_steps": deepcopy(step_metadatas),
        "docent_conversion": {
            "merged_atif_step_ids": step_ids,
        },
    }
    if timestamps:
        metadata["atif_first_timestamp"] = timestamps[0]
        if timestamps[-1] != timestamps[0]:
            metadata["atif_last_timestamp"] = timestamps[-1]
    if any(model_name is not None for model_name in model_names):
        metadata["atif_source_models"] = deepcopy(model_names)

    return metadata


def _build_assistant_turn_message(
    *,
    reasoning_parts: list[str],
    text_parts: list[str | list[JsonDict]],
    tool_calls: list[JsonDict],
    step_metadatas: list[JsonDict],
    model_names: list[str | None],
) -> JsonDict:
    message: JsonDict = {
        "role": "assistant",
        "content": _build_assistant_turn_content(
            reasoning_parts=reasoning_parts,
            text_parts=text_parts,
        ),
    }

    distinct_model_names: list[str] = []
    for model_name in model_names:
        if model_name is None or model_name in distinct_model_names:
            continue
        distinct_model_names.append(model_name)

    if len(distinct_model_names) == 1:
        message["model"] = distinct_model_names[0]
    if tool_calls:
        message["tool_calls"] = deepcopy(tool_calls)

    metadata = _build_assistant_turn_metadata(
        step_metadatas=step_metadatas,
        model_names=model_names,
    )
    if metadata:
        message["metadata"] = metadata

    return message


def _validate_step(
    step: JsonDict,
    *,
    index: int,
) -> tuple[int, str]:
    step_id = step.get("step_id")
    if not isinstance(step_id, int):
        raise ConversionError(f"steps[{index}].step_id must be an integer")
    if step_id != index + 1:
        raise ConversionError(
            f"steps[{index}].step_id must be sequential starting at 1; "
            f"expected {index + 1}, got {step_id}"
        )

    source = _require_string(step.get("source"), f"steps[{index}].source")
    if source not in {"system", "user", "agent"}:
        raise ConversionError(
            f"steps[{index}].source must be 'system', 'user', or 'agent', got {source!r}"
        )

    raw_message = step.get("message")
    if raw_message is None:
        raise ConversionError(f"steps[{index}].message is required")

    return step_id, source


def _convert_steps_to_messages(
    steps: list[Any],
    *,
    default_model_name: str | None,
) -> list[JsonDict]:
    messages: list[JsonDict] = []
    pending_reasoning_parts: list[str] = []
    pending_text_parts: list[str | list[JsonDict]] = []
    pending_tool_calls: list[JsonDict] = []
    pending_step_metadatas: list[JsonDict] = []
    pending_model_names: list[str | None] = []

    def flush_pending_assistant_turn() -> None:
        nonlocal pending_reasoning_parts
        nonlocal pending_text_parts
        nonlocal pending_tool_calls
        nonlocal pending_step_metadatas
        nonlocal pending_model_names

        if not pending_step_metadatas:
            return

        messages.append(
            _build_assistant_turn_message(
                reasoning_parts=pending_reasoning_parts,
                text_parts=pending_text_parts,
                tool_calls=pending_tool_calls,
                step_metadatas=pending_step_metadatas,
                model_names=pending_model_names,
            )
        )
        pending_reasoning_parts = []
        pending_text_parts = []
        pending_tool_calls = []
        pending_step_metadatas = []
        pending_model_names = []

    for index, raw_step in enumerate(steps):
        step = _require_dict(raw_step, f"steps[{index}]")
        step_id, source = _validate_step(step, index=index)

        content, conversion_metadata = _convert_atif_content(
            step["message"],
            context=f"steps[{index}].message",
        )
        metadata = _base_message_metadata(step, step_id=step_id, step_source=source)
        if conversion_metadata is not None:
            metadata["docent_conversion"] = conversion_metadata

        tool_call_lookup: dict[str, str] = {}

        if source != "agent":
            flush_pending_assistant_turn()
            message: JsonDict = {"role": source, "content": content}
            if metadata:
                message["metadata"] = metadata
            messages.append(message)
            messages.extend(
                _convert_observation_messages(
                    step,
                    step_id=step_id,
                    step_source=source,
                    tool_call_lookup=tool_call_lookup,
                )
            )
            continue

        reasoning = _optional_string(
            step.get("reasoning_content"),
            f"steps[{index}].reasoning_content",
        )
        if reasoning:
            pending_reasoning_parts.append(reasoning)

        reasoning_effort = step.get("reasoning_effort")
        if reasoning_effort is not None:
            if not isinstance(reasoning_effort, (str, int, float)):
                raise ConversionError(f"steps[{index}].reasoning_effort must be a string or number")
            metadata["atif_reasoning_effort"] = reasoning_effort

        metrics = step.get("metrics")
        if metrics is not None:
            metadata["atif_metrics"] = _require_dict(metrics, f"steps[{index}].metrics")

        pending_text_parts.append(content)
        pending_step_metadatas.append(metadata)

        model_name = _optional_string(step.get("model_name"), f"steps[{index}].model_name")
        if model_name is None:
            model_name = default_model_name
        pending_model_names.append(model_name)

        raw_tool_calls = step.get("tool_calls")
        if raw_tool_calls is not None:
            tool_calls, tool_call_lookup = _convert_tool_calls(
                raw_tool_calls,
                step_context=f"steps[{index}].tool_calls",
            )
            pending_tool_calls.extend(tool_calls)

        observation_messages = _convert_observation_messages(
            step,
            step_id=step_id,
            step_source=source,
            tool_call_lookup=tool_call_lookup,
        )
        if observation_messages:
            flush_pending_assistant_turn()
            messages.extend(observation_messages)

    flush_pending_assistant_turn()
    return messages


def _extract_first_timestamp(steps: list[Any]) -> str | None:
    for index, raw_step in enumerate(steps):
        step = _require_dict(raw_step, f"steps[{index}]")
        timestamp = _optional_string(step.get("timestamp"), f"steps[{index}].timestamp")
        if timestamp is not None:
            return timestamp
    return None


def convert_atif_to_agent_run(
    atif: JsonDict,
) -> AgentRun:
    """Convert one ATIF trajectory payload into one Docent `AgentRun`.

    The converter preserves ATIF root and step metadata under `AgentRun.metadata`
    and message metadata, while mapping ATIF steps onto a single Docent
    transcript. The conversion is intentionally strict: image parts,
    continued-trajectory references, and subagent references are rejected
    because they cannot be represented losslessly in the current Docent chat
    schema.

    Args:
        atif: Parsed ATIF JSON object. The payload must contain an `agent`
            object, a `session_id`, and a sequential `steps` array using the
            ATIF schema.

    Returns:
        A validated Docent `AgentRun` containing exactly one transcript.

    Raises:
        ConversionError: If the ATIF payload is malformed or uses features that
            cannot be converted, such as continued trajectories, subagent
            references, or image content.
    """
    schema_version = _require_string(atif.get("schema_version"), "schema_version")
    session_id = _require_string(atif.get("session_id"), "session_id")
    agent = _require_dict(atif.get("agent"), "agent")
    agent_name = _require_string(agent.get("name"), "agent.name")
    agent_version = _require_string(agent.get("version"), "agent.version")
    default_model_name = _optional_string(agent.get("model_name"), "agent.model_name")
    continued_trajectory_ref = _optional_string(
        atif.get("continued_trajectory_ref"),
        "continued_trajectory_ref",
    )
    if continued_trajectory_ref is not None:
        raise ConversionError(
            "ATIF continued_trajectory_ref is not supported by this converter because it "
            "emits a single standalone Docent AgentRun. "
            f"Found continued_trajectory_ref={continued_trajectory_ref!r}."
        )
    steps = _require_list(atif.get("steps"), "steps")

    messages = _convert_steps_to_messages(
        steps,
        default_model_name=default_model_name,
    )

    atif_metadata: JsonDict = {
        "schema_version": schema_version,
        "session_id": session_id,
        "agent": deepcopy(agent),
        "original_step_count": len(steps),
    }
    if "final_metrics" in atif:
        atif_metadata["final_metrics"] = _deepcopy_if_present(atif.get("final_metrics"))
    if "extra" in atif:
        atif_metadata["extra"] = _deepcopy_if_present(_optional_dict(atif.get("extra"), "extra"))

    root_metadata: JsonDict = {
        "source_format": schema_version,
        "converted_from": "ATIF",
        "atif": atif_metadata,
    }

    notes = _optional_string(atif.get("notes"), "notes")
    if notes is not None:
        root_metadata["atif"]["notes"] = notes

    transcript: JsonDict = {
        "name": agent_name,
        "description": f"Converted ATIF trajectory for {agent_name} {agent_version}",
        "messages": messages,
        "metadata": {
            "agent_name": agent_name,
            "agent_version": agent_version,
        },
    }

    created_at = _extract_first_timestamp(steps)
    if created_at is not None:
        transcript["metadata"]["atif_first_timestamp"] = created_at
    if default_model_name is not None:
        transcript["metadata"]["default_model_name"] = default_model_name

    agent_run: JsonDict = {
        "name": agent_name,
        "transcripts": [transcript],
        "transcript_groups": [],
        "metadata": root_metadata,
    }
    if notes is not None:
        agent_run["description"] = notes

    return AgentRun.model_validate(agent_run)


def is_atif_payload(value: object) -> TypeGuard[JsonDict]:
    """Return whether a parsed JSON value looks like an ATIF trajectory payload."""
    if not isinstance(value, dict):
        return False

    typed_value = cast(dict[str, object], value)
    schema_version = typed_value.get("schema_version")
    return isinstance(schema_version, str) and schema_version.startswith("ATIF-")


def _load_json_file(path: Path) -> object:
    try:
        with path.open("r", encoding="utf-8") as infile:
            return json.load(infile)
    except json.JSONDecodeError as exc:
        raise ConversionError(f"{path}: invalid JSON ({exc.msg})") from exc


def _require_existing_directory(path: Path, *, context: str) -> Path:
    return require_existing_directory(path, context=context, exc_type=ConversionError)


def load_atif_payload(path: str | Path) -> JsonDict:
    """Load and validate an ATIF payload from disk."""
    atif_path = Path(path)
    payload = _load_json_file(atif_path)
    if not is_atif_payload(payload):
        raise ConversionError(f"{atif_path}: JSON payload is not an ATIF trajectory")
    return payload


def convert_atif_file_to_agent_run(
    path: str | Path,
) -> AgentRun:
    """Load an ATIF JSON file from disk and convert it into a Docent AgentRun."""
    atif_path = Path(path)
    atif_payload = load_atif_payload(atif_path)
    try:
        return convert_atif_to_agent_run(atif_payload)
    except ConversionError as exc:
        raise ConversionError(f"{atif_path}: {exc}") from exc


def is_harbor_trial_dir(path: str | Path) -> bool:
    """Return whether a path matches the expected Harbor trial directory layout."""
    trial_dir = Path(path)
    return (
        trial_dir.is_dir()
        and (trial_dir / "agent").is_dir()
        and (trial_dir / "verifier").is_dir()
        and (trial_dir / "config.json").is_file()
        and (trial_dir / "result.json").is_file()
    )


def _require_harbor_trial_dir(path: Path) -> Path:
    _require_existing_directory(path, context="Harbor trial directory")

    missing_entries: list[str] = []
    if not (path / "agent").is_dir():
        missing_entries.append("agent/")
    if not (path / "verifier").is_dir():
        missing_entries.append("verifier/")
    if not (path / "config.json").is_file():
        missing_entries.append("config.json")
    if not (path / "result.json").is_file():
        missing_entries.append("result.json")

    if missing_entries:
        missing_display = ", ".join(missing_entries)
        raise ConversionError(f"{path}: missing required Harbor trial entries: {missing_display}")

    return path


def find_harbor_trial_dirs(root: str | Path) -> list[Path]:
    """Recursively find Harbor trial directories under a root path."""
    root_path = _require_existing_directory(Path(root), context="root directory")
    trial_dirs = {
        candidate.parent
        for candidate in root_path.rglob("config.json")
        if is_harbor_trial_dir(candidate.parent)
    }
    if is_harbor_trial_dir(root_path):
        trial_dirs.add(root_path)
    return sorted(trial_dirs)


def _attach_harbor_trial_metadata(
    agent_run: AgentRun,
    *,
    root: Path,
    trajectory_path: Path,
    trial_dir: Path,
    config_payload: object,
    result_payload: object,
) -> None:
    try:
        relative_trajectory_path = trajectory_path.relative_to(root)
        relative_trial_dir = trial_dir.relative_to(root)
    except ValueError as exc:
        raise ConversionError(
            f"Cannot attach Harbor metadata for {trajectory_path} relative to {root}"
        ) from exc

    metadata = agent_run.metadata
    metadata["harbor"] = {
        "trajectory_path": str(relative_trajectory_path),
        "trial_path": str(relative_trial_dir),
        "config_json": config_payload,
        "result_json": result_payload,
    }


def _iter_trial_agent_json_paths(trial_dir: Path) -> Iterator[Path]:
    agent_dir = trial_dir / "agent"
    yield from sorted(agent_dir.glob("*.json"))


def _find_trial_atif_paths(trial_dir: Path) -> list[Path]:
    atif_paths: list[Path] = []
    for trajectory_path in _iter_trial_agent_json_paths(trial_dir):
        payload = _load_json_file(trajectory_path)
        if is_atif_payload(payload):
            atif_paths.append(trajectory_path)
    return atif_paths


def convert_harbor_trial_to_agent_run(
    trial_dir: str | Path,
    *,
    path_root: str | Path | None = None,
) -> AgentRun:
    """Convert one Harbor trial directory into one Docent `AgentRun`.

    A Harbor trial is expected to contain `agent/`, `verifier/`,
    `config.json`, and `result.json`. Exactly one ATIF trajectory file must be
    present directly under `agent/`. The converted `AgentRun` includes Harbor
    metadata describing the relative trajectory path, trial path, and the raw
    `config.json` and `result.json` payloads.

    Args:
        trial_dir: Path to a Harbor trial directory containing `agent/`,
            `verifier/`, `config.json`, and `result.json`.
        path_root: Optional root used when storing relative Harbor metadata paths
            on the returned `AgentRun`. Defaults to the trial directory's
            parent.

    Returns:
        The converted Docent `AgentRun` for the trial.

    Raises:
        ConversionError: If the directory is not a valid Harbor trial, contains no
            ATIF trajectories, contains multiple ATIF trajectories, or the ATIF file
            cannot be converted.
    """
    trial_path = _require_harbor_trial_dir(Path(trial_dir))
    metadata_root = (
        _require_existing_directory(Path(path_root), context="path_root")
        if path_root is not None
        else trial_path.parent
    )

    config_payload = _load_json_file(trial_path / "config.json")
    result_payload = _load_json_file(trial_path / "result.json")

    atif_paths = _find_trial_atif_paths(trial_path)
    if not atif_paths:
        raise ConversionError(f"{trial_path}: no ATIF JSON files found directly under agent/")
    if len(atif_paths) > 1:
        atif_paths_display = ", ".join(str(path.name) for path in atif_paths)
        raise ConversionError(
            f"{trial_path}: expected exactly one ATIF JSON file under agent/, "
            f"found {len(atif_paths)} ({atif_paths_display})"
        )

    trajectory_path = atif_paths[0]
    payload = load_atif_payload(trajectory_path)
    try:
        agent_run = convert_atif_to_agent_run(payload)
    except ConversionError as exc:
        raise ConversionError(f"{trajectory_path}: {exc}") from exc

    _attach_harbor_trial_metadata(
        agent_run,
        root=metadata_root,
        trajectory_path=trajectory_path,
        trial_dir=trial_path,
        config_payload=config_payload,
        result_payload=result_payload,
    )
    return agent_run


def convert_harbor_directory_to_agent_runs(
    root: str | Path,
) -> list[AgentRun]:
    """Convert every Harbor trial found under a root path into `AgentRun`s.

    This function recursively discovers Harbor trial directories below `root`
    and converts each one via `convert_harbor_trial_to_agent_run()`. Relative
    Harbor metadata paths on each returned `AgentRun` are rooted at `root`.

    Args:
        root: Directory to scan recursively for Harbor trial directories.

    Returns:
        Converted Docent `AgentRun` objects for every Harbor trial discovered
        under `root`.

    Raises:
        ConversionError: If `root` does not exist, is not a directory, or contains
            no Harbor trial directories.
    """
    root_path = _require_existing_directory(Path(root), context="root directory")
    trial_dirs = find_harbor_trial_dirs(root_path)
    if not trial_dirs:
        raise ConversionError(f"No Harbor trial directories found under {root_path}")

    return [
        convert_harbor_trial_to_agent_run(trial_dir, path_root=root_path)
        for trial_dir in trial_dirs
    ]


def serialize_agent_run_jsonl_line(agent_run: AgentRun) -> str:
    """Serialize one `AgentRun` into a compact JSONL line."""
    return json.dumps(agent_run.model_dump(mode="json"), ensure_ascii=True, separators=(",", ":"))


@contextmanager
def _output_writer(path: Path | None) -> Iterator[TextIO]:
    if path is None:
        yield sys.stdout
        return

    path.parent.mkdir(parents=True, exist_ok=True)

    temp_path = path.parent / f".{path.name}.{uuid4().hex}.tmp"
    try:
        with temp_path.open("w", encoding="utf-8") as outfile:
            yield outfile
        temp_path.replace(path)
    except Exception:
        temp_path.unlink(missing_ok=True)
        raise


def _normalize_jsonl_output_path(path: str | Path | None) -> Path | None:
    if path is None:
        return None

    output_path = Path(path)
    if str(output_path) == "-":
        return None
    return output_path


def write_agent_runs_jsonl(
    agent_runs: Iterable[AgentRun],
    path: str | Path | None,
) -> int:
    """Write `AgentRun` objects as JSONL and return the number of rows written."""
    output_path = _normalize_jsonl_output_path(path)

    converted_count = 0
    with _output_writer(output_path) as outfile:
        for agent_run in agent_runs:
            outfile.write(serialize_agent_run_jsonl_line(agent_run))
            outfile.write("\n")
            converted_count += 1

    return converted_count
