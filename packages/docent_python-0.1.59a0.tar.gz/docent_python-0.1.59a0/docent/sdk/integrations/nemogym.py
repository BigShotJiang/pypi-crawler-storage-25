"""Helpers for converting Nemogym rollout JSONL data into Docent AgentRuns."""

from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any, cast

from docent.data_models.agent_run import AgentRun
from docent.sdk.integrations.util import (
    ConversionError,
    JsonDict,
    require_dict,
    require_existing_file,
    require_list,
    require_string,
)

ROLLOUT_RESERVED_TOP_LEVEL_KEYS = {
    "responses_create_params",
    "response",
    "reward",
    "_ng_task_index",
    "_ng_rollout_index",
    "agent_ref",
}


def _require_existing_file(path: Path, *, context: str) -> Path:
    return require_existing_file(path, context=context, exc_type=ConversionError)


def _require_dict(value: Any, context: str) -> JsonDict:
    return require_dict(value, context, exc_type=ConversionError)


def _require_list(value: Any, context: str) -> list[Any]:
    return require_list(value, context, exc_type=ConversionError)


def _require_string(value: Any, context: str) -> str:
    return require_string(value, context, exc_type=ConversionError)


def _require_int(value: Any, context: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ConversionError(f"{context} must be an integer")
    return value


def _require_input_items(raw_input: Any, context: str) -> list[Any]:
    if isinstance(raw_input, str):
        return [{"role": "user", "content": raw_input, "type": "message"}]
    return _require_list(raw_input, context)


def _drop_empty_values(value: Any) -> Any:
    if isinstance(value, dict):
        result: JsonDict = {}
        for key, child in cast(JsonDict, value).items():
            normalized = _drop_empty_values(child)
            if normalized in (None, [], {}, ""):
                continue
            result[key] = normalized
        return result

    if isinstance(value, list):
        return [_drop_empty_values(child) for child in cast(list[Any], value)]

    return value


def _parse_tool_arguments(raw_arguments: Any, *, context: str) -> JsonDict:
    if isinstance(raw_arguments, dict):
        return deepcopy(cast(JsonDict, raw_arguments))
    if not isinstance(raw_arguments, str):
        raise ConversionError(f"{context} must be a JSON object or JSON object string")

    try:
        parsed = json.loads(raw_arguments)
    except json.JSONDecodeError as exc:
        raise ConversionError(f"{context} must be valid JSON ({exc.msg})") from exc

    if not isinstance(parsed, dict):
        raise ConversionError(f"{context} must parse to a JSON object")

    return cast(JsonDict, parsed)


def _serialize_tool_output(output: Any) -> str:
    if isinstance(output, str):
        return output
    return json.dumps(output, ensure_ascii=True, sort_keys=True)


def _extract_reasoning_text(item: JsonDict, *, context: str) -> str:
    if item.get("encrypted_content"):
        raise ConversionError(
            f"{context}.encrypted_content is not supported because Docent only stores "
            "plain reasoning text"
        )

    summary_items = _require_list(item.get("summary"), f"{context}.summary")
    texts: list[str] = []

    for summary_index, raw_summary in enumerate(summary_items):
        summary = _require_dict(raw_summary, f"{context}.summary[{summary_index}]")
        summary_type = _require_string(
            summary.get("type"),
            f"{context}.summary[{summary_index}].type",
        )
        if summary_type not in {"summary_text", "text"}:
            raise ConversionError(
                f"{context}.summary[{summary_index}].type must be 'summary_text' or 'text', "
                f"got {summary_type!r}"
            )

        text = _require_string(summary.get("text"), f"{context}.summary[{summary_index}].text")
        if text:
            texts.append(text)

    return "\n".join(texts)


def _extract_message_content(content: Any, *, context: str) -> tuple[str, JsonDict]:
    if isinstance(content, str):
        return content, {}

    if not isinstance(content, list):
        raise ConversionError(f"{context} must be a string or an array of content parts")

    text_parts: list[str] = []
    content_part_types: list[str] = []
    refusal = False
    annotations_present = False
    logprobs_present = False

    for part_index, raw_part in enumerate(cast(list[Any], content)):
        part = _require_dict(raw_part, f"{context}[{part_index}]")
        part_type = _require_string(part.get("type"), f"{context}[{part_index}].type")
        content_part_types.append(part_type)
        if part_type in {"input_text", "output_text"}:
            text_parts.append(_require_string(part.get("text"), f"{context}[{part_index}].text"))
            annotations_present = annotations_present or bool(part.get("annotations"))
            logprobs_present = logprobs_present or bool(part.get("logprobs"))
        elif part_type == "refusal":
            refusal = True
            text_parts.append(
                _require_string(part.get("refusal"), f"{context}[{part_index}].refusal")
            )
        else:
            raise ConversionError(
                f"{context}[{part_index}].type must be 'input_text', 'output_text', or "
                f"'refusal', got {part_type!r}"
            )

    detail = _drop_empty_values(
        {
            "content_part_types": content_part_types,
            "contains_refusal_part": refusal,
            "contains_annotations": annotations_present,
            "contains_logprobs": logprobs_present,
        }
    )
    return "".join(text_parts), cast(JsonDict, detail)


def _normalize_message_role(item: JsonDict, *, context: str) -> tuple[str, str]:
    original_role = _require_string(item.get("role"), f"{context}.role")
    if original_role not in {"developer", "system", "user", "assistant"}:
        raise ConversionError(
            f"{context}.role must be 'developer', 'system', 'user', or 'assistant', "
            f"got {original_role!r}"
        )

    role = "system" if original_role == "developer" else original_role
    return original_role, role


def _build_item_detail(
    item: JsonDict,
    *,
    item_type: Any,
    origin: str,
) -> JsonDict:
    return cast(
        JsonDict,
        _drop_empty_values(
            {
                "origin": origin,
                "source_item_type": item_type,
                "source_item_id": item.get("id"),
                "source_item_status": item.get("status"),
            }
        ),
    )


def _convert_message_item(
    item: JsonDict,
    detail: JsonDict,
    *,
    context: str,
) -> tuple[JsonDict, JsonDict]:
    original_role, role = _normalize_message_role(item, context=context)
    content, content_detail = _extract_message_content(
        item.get("content"), context=f"{context}.content"
    )
    message: JsonDict = {"role": role, "content": content}

    if original_role != role:
        detail["original_role"] = original_role
    detail.update(content_detail)

    return message, cast(JsonDict, _drop_empty_values(detail))


def _build_emitted_message_detail(
    *,
    message: JsonDict,
    source_items: list[JsonDict],
) -> JsonDict:
    origins = [
        origin for detail in source_items if isinstance((origin := detail.get("origin")), str)
    ]
    source_item_types = [
        source_item_type
        for detail in source_items
        if isinstance((source_item_type := detail.get("source_item_type")), str)
    ]

    origin_value: str | list[str] | None = None
    if origins:
        origin_value = origins[0] if all(origin == origins[0] for origin in origins) else origins

    return cast(
        JsonDict,
        _drop_empty_values(
            {
                "role": message.get("role"),
                "origin": origin_value,
                "source_item_count": len(source_items),
                "source_item_types": source_item_types,
                "source_items": deepcopy(source_items),
            }
        ),
    )


def _build_assistant_turn_message(
    *,
    reasoning_parts: list[str],
    text_parts: list[str],
    tool_calls: list[JsonDict],
) -> JsonDict:
    reasoning_text = "\n\n".join(part for part in reasoning_parts if part)
    text_content = "".join(text_parts)

    if reasoning_text:
        content: str | list[JsonDict] = [{"type": "reasoning", "reasoning": reasoning_text}]
        if text_content:
            content.append({"type": "text", "text": text_content})
    else:
        content = text_content

    message: JsonDict = {"role": "assistant", "content": content}
    if tool_calls:
        message["tool_calls"] = deepcopy(tool_calls)
    return message


def _convert_items_to_docent_messages(
    items: list[Any],
    *,
    origin: str,
    call_id_to_name: dict[str, str],
    context_prefix: str,
) -> tuple[list[JsonDict], list[JsonDict]]:
    transcript_messages: list[JsonDict] = []
    message_details: list[JsonDict] = []
    pending_reasoning_parts: list[str] = []
    pending_text_parts: list[str] = []
    pending_tool_calls: list[JsonDict] = []
    pending_source_items: list[JsonDict] = []

    def flush_pending_assistant_turn() -> None:
        nonlocal pending_reasoning_parts
        nonlocal pending_text_parts
        nonlocal pending_tool_calls
        nonlocal pending_source_items

        if not pending_source_items:
            return

        message = _build_assistant_turn_message(
            reasoning_parts=pending_reasoning_parts,
            text_parts=pending_text_parts,
            tool_calls=pending_tool_calls,
        )
        transcript_messages.append(message)
        message_details.append(
            _build_emitted_message_detail(message=message, source_items=pending_source_items)
        )
        pending_reasoning_parts = []
        pending_text_parts = []
        pending_tool_calls = []
        pending_source_items = []

    for item_index, item in enumerate(items):
        context = f"{context_prefix}[{item_index}]"
        if not isinstance(item, dict):
            raise ConversionError(f"{context} must be an object")

        item_dict = cast(JsonDict, item)
        item_type = item_dict.get("type")
        if item_type is None and "role" in item_dict:
            item_type = "message"

        detail = _build_item_detail(item_dict, item_type=item_type, origin=origin)

        if item_type == "message":
            original_role, role = _normalize_message_role(item_dict, context=context)
            if role == "assistant":
                content, content_detail = _extract_message_content(
                    item_dict.get("content"), context=f"{context}.content"
                )
                detail.update(content_detail)
                if original_role != role:
                    detail["original_role"] = original_role
                pending_text_parts.append(content)
                pending_source_items.append(cast(JsonDict, _drop_empty_values(detail)))
                continue

            flush_pending_assistant_turn()
            message, detail = _convert_message_item(item_dict, detail, context=context)
            transcript_messages.append(message)
            message_details.append(
                _build_emitted_message_detail(message=message, source_items=[detail])
            )
            continue

        if item_type == "reasoning":
            reasoning_text = _extract_reasoning_text(item_dict, context=context)
            detail.update(
                cast(
                    JsonDict,
                    _drop_empty_values(
                        {
                            "summary_item_types": [
                                cast(JsonDict, part).get("type")
                                for part in _require_list(
                                    item_dict.get("summary"), f"{context}.summary"
                                )
                                if isinstance(part, dict)
                            ]
                        }
                    ),
                )
            )
            pending_reasoning_parts.append(reasoning_text)
            pending_source_items.append(cast(JsonDict, _drop_empty_values(detail)))
            continue

        if item_type == "function_call":
            if "arguments" not in item_dict:
                raise ConversionError(f"{context}.arguments is required")
            raw_arguments = item_dict["arguments"]
            parsed_arguments = _parse_tool_arguments(raw_arguments, context=f"{context}.arguments")
            call_id = item_dict.get("call_id")
            tool_name = item_dict.get("name")

            if not isinstance(call_id, str) or not call_id:
                raise ConversionError(f"{context}.call_id must be a non-empty string")

            if not isinstance(tool_name, str) or not tool_name:
                raise ConversionError(f"{context}.name must be a non-empty string")

            call_id_to_name[call_id] = tool_name
            detail.update(
                cast(
                    JsonDict,
                    _drop_empty_values(
                        {
                            "call_id": call_id,
                            "tool_name": tool_name,
                            "raw_arguments": raw_arguments,
                        }
                    ),
                )
            )
            pending_tool_calls.append(
                {
                    "id": call_id,
                    "function": tool_name,
                    "arguments": parsed_arguments,
                    "type": "function",
                }
            )
            pending_source_items.append(cast(JsonDict, _drop_empty_values(detail)))
            continue

        if item_type == "function_call_output":
            flush_pending_assistant_turn()
            call_id = item_dict.get("call_id")
            detail.update(cast(JsonDict, _drop_empty_values({"call_id": call_id})))
            if not isinstance(call_id, str) or not call_id:
                raise ConversionError(f"{context}.call_id must be a non-empty string")
            function_name = call_id_to_name.get(call_id)
            if function_name is None:
                raise ConversionError(
                    f"{context}.call_id references a function_call that does not appear earlier "
                    f"in the imported rollout: {call_id!r}"
                )
            if "output" not in item_dict:
                raise ConversionError(f"{context}.output is required")

            message = {
                "role": "tool",
                "function": function_name,
                "tool_call_id": call_id,
                "content": _serialize_tool_output(item_dict["output"]),
            }
            transcript_messages.append(message)
            message_details.append(
                _build_emitted_message_detail(message=message, source_items=[detail])
            )
            continue

        raise ConversionError(
            f"{context}.type must be 'message', 'reasoning', 'function_call', or "
            f"'function_call_output', got {item_type!r}"
        )

    flush_pending_assistant_turn()
    return transcript_messages, message_details


def _build_rollout_non_trace(
    *,
    row: JsonDict,
    request_metadata: JsonDict,
    response_metadata: JsonDict,
) -> JsonDict:
    benchmark_fields = {
        key: value
        for key, value in row.items()
        if key not in ROLLOUT_RESERVED_TOP_LEVEL_KEYS and value is not None
    }
    return cast(
        JsonDict,
        _drop_empty_values(
            {
                "request": request_metadata,
                "response": response_metadata,
                "benchmark_fields": benchmark_fields,
            }
        ),
    )


def _build_agent_run_name(
    *,
    agent_name: str,
    task_index: int,
    rollout_index: int,
) -> str:
    return f"{agent_name}/task/{task_index}/rollout/{rollout_index}"


def convert_nemogym_rollout_to_agent_run(rollout: JsonDict) -> AgentRun:
    """Convert one parsed Nemogym rollout payload into a Docent AgentRun."""
    row = deepcopy(_require_dict(rollout, "Nemogym rollout"))

    responses_create_params = _require_dict(
        row.get("responses_create_params"),
        "Nemogym rollout.responses_create_params",
    )
    response = _require_dict(
        row.get("response"),
        "Nemogym rollout.response",
    )

    request_metadata = deepcopy(responses_create_params)
    response_metadata = deepcopy(response)
    if "input" not in request_metadata:
        raise ConversionError("Nemogym rollout.responses_create_params.input is required")
    if "output" not in response_metadata:
        raise ConversionError("Nemogym rollout.response.output is required")
    input_items = _require_input_items(
        request_metadata.pop("input"),
        "Nemogym rollout.responses_create_params.input",
    )
    output_items = _require_list(response_metadata.pop("output"), "Nemogym rollout.response.output")

    call_id_to_name: dict[str, str] = {}
    transcript_messages, message_details = _convert_items_to_docent_messages(
        input_items,
        origin="input",
        call_id_to_name=call_id_to_name,
        context_prefix="Nemogym rollout.responses_create_params.input",
    )
    output_messages, output_message_details = _convert_items_to_docent_messages(
        output_items,
        origin="output",
        call_id_to_name=call_id_to_name,
        context_prefix="Nemogym rollout.response.output",
    )
    transcript_messages.extend(output_messages)
    message_details.extend(output_message_details)

    if not transcript_messages:
        raise ConversionError("Nemogym rollout must produce at least one transcript message")

    agent_ref = _require_dict(row.get("agent_ref"), "Nemogym rollout.agent_ref")
    agent_name = _require_string(agent_ref.get("name"), "Nemogym rollout.agent_ref.name")
    task_index = _require_int(row.get("_ng_task_index"), "Nemogym rollout._ng_task_index")
    rollout_index = _require_int(
        row.get("_ng_rollout_index"),
        "Nemogym rollout._ng_rollout_index",
    )
    rollout_non_trace = _build_rollout_non_trace(
        row=row,
        request_metadata=request_metadata,
        response_metadata=response_metadata,
    )

    transcript_metadata = cast(
        JsonDict,
        _drop_empty_values(
            {
                "source": {
                    "schema": "nemo_gym_rollout",
                    "response_id": response.get("id"),
                    "response_model": response.get("model"),
                    "response_created_at": response.get("created_at"),
                    "response_status": response.get("status"),
                    "input_item_count": len(input_items),
                    "output_item_count": len(output_items),
                },
                "message_details": message_details,
            }
        ),
    )

    agent_run_metadata = cast(
        JsonDict,
        _drop_empty_values(
            {
                "scores": {"reward": row.get("reward")},
                "nemogym": {
                    "task_index": task_index,
                    "rollout_index": rollout_index,
                    "agent_ref": agent_ref,
                },
                "source": {
                    "schema": "nemo_gym_rollout",
                    "rollout_non_trace": rollout_non_trace,
                },
            }
        ),
    )

    agent_run_payload = {
        "name": _build_agent_run_name(
            agent_name=agent_name,
            task_index=task_index,
            rollout_index=rollout_index,
        ),
        "transcripts": [
            {
                "name": agent_name,
                "messages": transcript_messages,
                "metadata": transcript_metadata,
            }
        ],
        "metadata": agent_run_metadata,
    }

    return AgentRun.model_validate(agent_run_payload)


def convert_nemogym_jsonl_file_to_agent_runs(file_path: str | Path) -> list[AgentRun]:
    """Convert a Nemogym rollout JSONL file into Docent AgentRuns."""
    jsonl_path = _require_existing_file(Path(file_path), context="Nemogym rollout JSONL file")

    agent_runs: list[AgentRun] = []
    with jsonl_path.open("r", encoding="utf-8") as infile:
        for line_number, raw_line in enumerate(infile, start=1):
            line = raw_line.strip()
            if not line:
                continue

            try:
                parsed = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ConversionError(
                    f"{jsonl_path}: invalid JSON on line {line_number} ({exc.msg})"
                ) from exc

            if not isinstance(parsed, dict):
                raise ConversionError(
                    f"{jsonl_path}: line {line_number} must be a JSON object rollout"
                )

            try:
                agent_runs.append(convert_nemogym_rollout_to_agent_run(cast(JsonDict, parsed)))
            except ConversionError as exc:
                raise ConversionError(f"{jsonl_path}: line {line_number}: {exc}") from exc

    return agent_runs
