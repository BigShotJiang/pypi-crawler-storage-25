"""Shared utilities for SDK integration modules."""

from __future__ import annotations

from pathlib import Path
from typing import Any, cast

JsonDict = dict[str, Any]


class ConversionError(ValueError):
    """Raised when an integration payload cannot be converted safely."""


def require_existing_directory(
    path: Path,
    *,
    context: str,
    exc_type: type[Exception] = ValueError,
) -> Path:
    if not path.exists():
        raise exc_type(f"{context} does not exist: {path}")
    if not path.is_dir():
        raise exc_type(f"{context} is not a directory: {path}")
    return path


def require_existing_file(
    path: Path,
    *,
    context: str,
    exc_type: type[Exception] = ValueError,
) -> Path:
    if not path.exists():
        raise exc_type(f"{context} does not exist: {path}")
    if not path.is_file():
        raise exc_type(f"{context} is not a file: {path}")
    return path


def require_dict(
    value: Any,
    context: str,
    *,
    exc_type: type[Exception] = ValueError,
) -> JsonDict:
    if not isinstance(value, dict):
        raise exc_type(f"{context} must be an object")
    return cast(JsonDict, value)


def require_list(
    value: Any,
    context: str,
    *,
    exc_type: type[Exception] = ValueError,
) -> list[Any]:
    if not isinstance(value, list):
        raise exc_type(f"{context} must be an array")
    return cast(list[Any], value)


def require_string(
    value: Any,
    context: str,
    *,
    exc_type: type[Exception] = ValueError,
) -> str:
    if not isinstance(value, str):
        raise exc_type(f"{context} must be a string")
    return value


def optional_dict(
    value: Any,
    context: str,
    *,
    exc_type: type[Exception] = ValueError,
) -> JsonDict | None:
    if value is None:
        return None
    if not isinstance(value, dict):
        raise exc_type(f"{context} must be an object when present")
    return cast(JsonDict, value)
