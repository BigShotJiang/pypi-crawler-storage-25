"""
TIBET Unified CLI - The Trust Kernel for AI

Audit as a Precondition, Not an Afterthought.
"""

import click
import sys
import subprocess
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()


BANNER = """
████████╗██╗██████╗ ███████╗████████╗
╚══██╔══╝██║██╔══██╗██╔════╝╚══██╔══╝
   ██║   ██║██████╔╝█████╗     ██║
   ██║   ██║██╔══██╗██╔══╝     ██║
   ██║   ██║██████╔╝███████╗   ██║
   ╚═╝   ╚═╝╚═════╝ ╚══════╝   ╚═╝
"""


BUNDLES = {
    "provenance": {
        "desc": "Cryptographic proof of what happened",
        "packages": ["tibet-core", "tibet-claw", "tibet-forge", "tibet-sbom", "tibet-audit", "tibet-trail"],
        "install": "pip install tibet[provenance]",
    },
    "security": {
        "desc": "Isolation, monitoring, threat detection",
        "packages": ["snaft", "tibet-triage", "tibet-nis2", "tibet-snap", "tibet-pqc", "tibet-soc", "tibet-chip"],
        "install": "pip install tibet[security]",
    },
    "network": {
        "desc": "Multiplexed communication & mesh",
        "packages": ["tibet-mux", "tibet-overlay", "tibet-ping", "tibet-mesh", "ainternet", "ipoll"],
        "install": "pip install tibet[network]",
    },
    "runtime": {
        "desc": "Session portability & AI routing",
        "packages": ["tibet-phantom", "tibet-phantom-mcp", "tibet-voice-cache", "tibet-llm-router", "tibet-context"],
        "install": "pip install tibet[runtime]",
    },
    "compliance": {
        "desc": "Regulatory reporting & CI/CD audit",
        "packages": ["tibet-audit", "tibet-nis2", "tibet-sbom", "tibet-ci", "tibet-pol"],
        "install": "pip install tibet[compliance]",
    },
    "mcp": {
        "desc": "MCP servers for Claude Code / Cursor / OpenClaw",
        "packages": ["tibet-ainternet-mcp", "tibet-triage-mcp", "tibet-phantom-mcp"],
        "install": "pip install tibet[mcp]",
    },
}


@click.group()
@click.version_option(version="2.0.0", prog_name="tibet")
def main():
    """TIBET - The Trust Kernel for AI.

    One install, complete security: provenance, isolation, monitoring, compliance.

    \b
    Quick start:
      pip install tibet              # Core CLI
      pip install tibet[security]    # + isolation, SNAFT, triage
      pip install tibet[network]     # + mux, overlay, AInternet
      pip install tibet[full]        # Everything — the complete stack
    """
    pass


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--format", "-f", type=click.Choice(["text", "json", "markdown"]), default="text")
def audit(path, format):
    """Run compliance health scan (tibet-audit).

    Scans your project for AI Act, NIS2, GDPR compliance.
    """
    try:
        cmd = ["tibet-audit", "scan", path]
        if format != "text":
            cmd.extend(["--format", format])
        subprocess.run(cmd, check=True)
    except FileNotFoundError:
        console.print("[red]tibet-audit not installed.[/red]")
        console.print("Install with: [cyan]pip install tibet[audit][/cyan]")
        sys.exit(1)


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
def forge(path):
    """Run trust score scan (tibet-forge).

    Analyzes code quality, security, efficiency, and provenance readiness.
    """
    try:
        subprocess.run(["tibet-forge", "scan", path], check=True)
    except FileNotFoundError:
        console.print("[red]tibet-forge not installed.[/red]")
        console.print("Install with: [cyan]pip install tibet[forge][/cyan]")
        sys.exit(1)


@main.command()
@click.argument("action")
@click.option("--why", "-w", required=True, help="Intent behind this action (ERACHTER)")
@click.option("--what", "-W", default="{}", help="Content JSON (ERIN)")
@click.option("--refs", "-r", multiple=True, help="References (ERAAN)")
@click.option("--actor", "-a", default="cli", help="Who is performing this action")
def create(action, why, what, refs, actor):
    """Create a TIBET provenance token.

    Documents an action BEFORE execution with full provenance.

    Example:
        tibet create file_write --why "Fix login bug" --refs issue-123
    """
    try:
        from tibet_core import Provider
        import json

        provider = Provider(actor=actor)

        erin = json.loads(what) if what != "{}" else {}
        eraan = list(refs) if refs else []

        token = provider.create(
            action=action,
            erin=erin,
            erachter=why,
            eraan=eraan,
            eromheen={"cli": "tibet", "cwd": str(Path.cwd())}
        )

        console.print(Panel(
            f"[green]Token Created[/green]\n\n"
            f"[bold]ID:[/bold] {token.id}\n"
            f"[bold]Action:[/bold] {action}\n"
            f"[bold]Intent:[/bold] {why}\n"
            f"[bold]Actor:[/bold] {actor}",
            title="TIBET Provenance",
            border_style="green"
        ))

    except ImportError:
        console.print("[red]tibet-core not installed.[/red]")
        console.print("Install with: [cyan]pip install tibet[/cyan]")
        sys.exit(1)


@main.command()
@click.argument("token_id")
def verify(token_id):
    """Verify a TIBET token's integrity."""
    try:
        from tibet_core import Provider

        provider = Provider()
        token = provider.get(token_id)

        if not token:
            console.print(f"[red]Token not found: {token_id}[/red]")
            sys.exit(1)

        is_valid = token.verify()

        if is_valid:
            console.print(Panel(
                f"[green]✓ Token Valid[/green]\n\n"
                f"[bold]Action:[/bold] {token.action}\n"
                f"[bold]Actor:[/bold] {token.actor}\n"
                f"[bold]Created:[/bold] {token.timestamp}",
                title="Verification Result",
                border_style="green"
            ))
        else:
            console.print(Panel(
                "[red]✗ Token Invalid - Possible tampering detected[/red]",
                title="Verification Result",
                border_style="red"
            ))
            sys.exit(1)

    except ImportError:
        console.print("[red]tibet-core not installed.[/red]")
        sys.exit(1)


@main.command()
@click.option("--format", "-f", type=click.Choice(["json", "markdown", "summary"]), default="summary")
def export(format):
    """Export the full audit trail."""
    try:
        from tibet_core import Provider
        import json

        provider = Provider()
        data = provider.export()

        if format == "json":
            console.print(json.dumps(data, indent=2, default=str))
        elif format == "markdown":
            console.print("# TIBET Audit Trail\n")
            for token in data.get("tokens", []):
                console.print(f"## {token.get('action')}")
                console.print(f"- ID: `{token.get('id')}`")
                console.print(f"- Actor: {token.get('actor')}")
                console.print(f"- Intent: {token.get('erachter')}\n")
        else:
            tokens = data.get("tokens", [])
            console.print(Panel(
                f"[bold]Total Tokens:[/bold] {len(tokens)}\n"
                f"[bold]Actors:[/bold] {len(set(t.get('actor') for t in tokens))}\n"
                f"[bold]Actions:[/bold] {len(set(t.get('action') for t in tokens))}",
                title="TIBET Audit Summary",
                border_style="blue"
            ))

    except ImportError:
        console.print("[red]tibet-core not installed.[/red]")
        sys.exit(1)


@main.command()
def status():
    """Show TIBET ecosystem status — all bundles and components."""
    console.print(BANNER, style="cyan")
    console.print("[bold]The Trust Kernel for AI[/bold]")
    console.print("[dim]One install, complete security.[/dim]\n")

    # All checkable packages
    all_packages = {
        "tibet-core": "tibet_core",
        "tibet-claw": "tibet_claw",
        "tibet-forge": "tibet_forge",
        "tibet-audit": "tibet_audit",
        "tibet-sbom": "tibet_sbom",
        "tibet-trail": "tibet_trail",
        "tibet-vault": "tibet_vault",
        "snaft": "snaft",
        "tibet-triage": "tibet_triage",
        "tibet-nis2": "tibet_nis2",
        "tibet-snap": "tibet_snap",
        "tibet-pqc": "tibet_pqc",
        "tibet-soc": "tibet_soc",
        "tibet-chip": "tibet_chip",
        "tibet-mux": "tibet_mux",
        "tibet-overlay": "tibet_overlay",
        "tibet-ping": "tibet_ping",
        "tibet-mesh": "tibet_mesh",
        "ainternet": "ainternet",
        "ipoll": "ipoll",
        "tibet-phantom": "tibet_phantom",
        "tibet-phantom-mcp": "tibet_phantom_mcp",
        "tibet-voice-cache": "tibet_voice_cache",
        "tibet-llm-router": "tibet_llm_router",
        "tibet-context": "tibet_context",
        "tibet-ci": "tibet_ci",
        "tibet-pol": "tibet_pol",
        "tibet-ainternet-mcp": "tibet_ainternet_mcp",
        "tibet-triage-mcp": "tibet_triage_mcp",
    }

    # Check what's installed
    import importlib
    installed = {}
    for pkg_name, mod_name in all_packages.items():
        try:
            mod = importlib.import_module(mod_name)
            ver = getattr(mod, "__version__", "?")
            installed[pkg_name] = ver
        except ImportError:
            pass

    total = len(all_packages)
    found = len(installed)

    console.print(f"[bold green]{found}[/bold green]/{total} components installed\n")

    # Show per bundle
    for bundle_name, bundle_info in BUNDLES.items():
        bundle_pkgs = bundle_info["packages"]
        bundle_installed = sum(1 for p in bundle_pkgs if p in installed)
        bundle_total = len(bundle_pkgs)

        if bundle_installed == bundle_total:
            icon = "[green]■[/green]"
            label = f"[green]{bundle_name}[/green]"
        elif bundle_installed > 0:
            icon = "[yellow]◧[/yellow]"
            label = f"[yellow]{bundle_name}[/yellow]"
        else:
            icon = "[dim]□[/dim]"
            label = f"[dim]{bundle_name}[/dim]"

        parts = []
        for p in bundle_pkgs:
            if p in installed:
                parts.append(f"[green]{p}[/green]")
            else:
                parts.append(f"[dim]{p}[/dim]")

        console.print(f"  {icon} {label} ({bundle_installed}/{bundle_total}) — {bundle_info['desc']}")
        console.print(f"    {' '.join(parts)}")
        if bundle_installed < bundle_total:
            console.print(f"    [dim]{bundle_info['install']}[/dim]")
        console.print()

    console.print("[dim]pip install tibet[full]  — install everything[/dim]")
    console.print("[dim]One love, one fAmIly![/dim]")


@main.command()
@click.argument("path", default=".", type=click.Path())
def init(path):
    """Initialize TIBET in a project.

    Creates .tibet/ directory for local token storage.
    """
    tibet_dir = Path(path) / ".tibet"
    tibet_dir.mkdir(exist_ok=True)

    config_file = tibet_dir / "config.json"
    if not config_file.exists():
        import json
        config = {
            "version": "1.0.0",
            "actor": "local",
            "store": "file",
            "created": str(Path.cwd())
        }
        config_file.write_text(json.dumps(config, indent=2))

    console.print(Panel(
        f"[green]TIBET initialized in {path}[/green]\n\n"
        f"Created: .tibet/config.json\n\n"
        f"Next steps:\n"
        f"  tibet audit    - Scan for compliance\n"
        f"  tibet forge    - Check trust score\n"
        f"  tibet create   - Create provenance token",
        title="TIBET Init",
        border_style="green"
    ))


@main.command()
def bundles():
    """Show available installation bundles."""
    console.print("[bold]TIBET Installation Bundles[/bold]\n")

    table = Table()
    table.add_column("Bundle", style="cyan")
    table.add_column("Packages", style="dim")
    table.add_column("Install", style="green")

    for name, info in BUNDLES.items():
        table.add_row(
            f"{name}\n[dim]{info['desc']}[/dim]",
            "\n".join(info["packages"]),
            info["install"],
        )

    table.add_row(
        "[bold]full[/bold]\n[dim]The complete stack[/dim]",
        "[bold]All of the above[/bold]",
        "[bold]pip install tibet[full][/bold]",
    )

    console.print(table)


@main.command()
def version():
    """Show versions of all installed TIBET components."""
    import importlib

    all_packages = {
        "tibet": "tibet",
        "tibet-core": "tibet_core",
        "tibet-claw": "tibet_claw",
        "tibet-forge": "tibet_forge",
        "tibet-audit": "tibet_audit",
        "tibet-sbom": "tibet_sbom",
        "snaft": "snaft",
        "tibet-triage": "tibet_triage",
        "tibet-mux": "tibet_mux",
        "ainternet": "ainternet",
        "tibet-ainternet-mcp": "tibet_ainternet_mcp",
        "tibet-phantom": "tibet_phantom",
        "tibet-nis2": "tibet_nis2",
    }

    for pkg_name, mod_name in all_packages.items():
        try:
            mod = importlib.import_module(mod_name)
            ver = getattr(mod, "__version__", "?")
            console.print(f"{pkg_name}: [cyan]{ver}[/cyan]")
        except ImportError:
            pass


if __name__ == "__main__":
    main()
