# tibet

The Trust Kernel for AI. Audit as a precondition, not an afterthought.

[![PyPI](https://img.shields.io/pypi/v/tibet)](https://pypi.org/project/tibet/)
[![IETF Draft](https://img.shields.io/badge/IETF-draft--vandemeent--tibet--provenance-blue)](https://datatracker.ietf.org/doc/draft-vandemeent-tibet-provenance/)
[![Whitepaper](https://img.shields.io/badge/Zenodo-DOI:10.5281/zenodo.18712238-green)](https://doi.org/10.5281/zenodo.18712238)

Unified CLI for [tibet-core](https://pypi.org/project/tibet-core/) provenance, compliance scanning, and trust scoring. One command to document, verify, and audit every AI action.

## Install

```bash
pip install tibet                # CLI + tibet-core
pip install tibet[audit]         # + compliance scanning (AI Act, NIS2, GDPR)
pip install tibet[forge]         # + trust scoring
pip install tibet[full]          # everything
```

## Quick Start

```bash
# Initialize TIBET in your project
tibet init

# Create a provenance token (document BEFORE you act)
tibet create deploy --why "Release v1.0.0" --refs ticket-123

# Verify token integrity
tibet verify <token-id>

# Export audit trail
tibet export --format json

# Run compliance scan
tibet audit

# Check trust score
tibet forge

# Show installed components
tibet status
```

## Commands

| Command | Description |
|---------|-------------|
| `tibet init` | Initialize `.tibet/` directory for local token storage |
| `tibet create <action>` | Create provenance token with intent (`--why`), content (`--what`), and references (`--refs`) |
| `tibet verify <id>` | Verify a token's cryptographic integrity |
| `tibet export` | Export audit trail (JSON, markdown, or summary) |
| `tibet audit` | Run compliance health scan — AI Act, NIS2, GDPR (requires `tibet[audit]`) |
| `tibet forge` | Run trust score analysis — code quality, security, provenance readiness (requires `tibet[forge]`) |
| `tibet status` | Show ecosystem status and installed component versions |
| `tibet version` | Show versions of all TIBET components |

### Creating Tokens

Every token captures four provenance dimensions:

```bash
tibet create file_write \
  --why "Fix login bug"          \  # ERACHTER — intent
  --what '{"file":"auth.py"}'    \  # ERIN — content
  --refs issue-123               \  # ERAAN — references
  --actor "jis:dev:alice"           # Who
```

The token is created BEFORE the action happens. This is structural — provenance that's recorded after the fact is just logging.

## TIBET Provenance

Every token records four dimensions:

| Dimension | Dutch | Meaning |
|-----------|-------|---------|
| **ERIN** | "Er in" | What's IN the action (content, data) |
| **ERAAN** | "Er aan" | What's attached (dependencies, references) |
| **EROMHEEN** | "Er omheen" | Context around it (environment, state) |
| **ERACHTER** | "Er achter" | Intent behind it (why this action) |

## Ecosystem

`tibet` is the CLI. The kernel is [tibet-core](https://pypi.org/project/tibet-core/). Together with the rest of the stack:

| Layer | Package | What it does |
|-------|---------|--------------|
| **Identity** | [jis-core](https://pypi.org/project/jis-core/) | Ed25519 keys, DID documents, bilateral consent |
| **Provenance** | [tibet-core](https://pypi.org/project/tibet-core/) | TIBET tokens — ERIN/ERAAN/EROMHEEN/ERACHTER |
| **CLI** | **tibet** | `tibet create`, `tibet verify`, `tibet audit`, `tibet forge` |
| **Firewall** | [snaft](https://pypi.org/project/snaft/) | 22 immutable rules, OWASP 20/20, FIR/A trust |
| **Network** | [ainternet](https://pypi.org/project/ainternet/) | .aint domains, I-Poll messaging, agent discovery |
| **Compliance** | [tibet-audit](https://pypi.org/project/tibet-audit/) | AI Act, NIS2, GDPR, CRA — 112+ checks |
| **Trust** | [tibet-forge](https://pypi.org/project/tibet-forge/) | Trust scoring and certification |
| **SBOM** | [tibet-sbom](https://pypi.org/project/tibet-sbom/) | Supply chain verification with provenance |
| **Triage** | [tibet-triage](https://pypi.org/project/tibet-triage/) | Airlock sandbox, UPIP reproducibility, flare rescue |
| **Secrets** | [tibet-vault](https://pypi.org/project/tibet-vault/) | Time-locked secrets with dead man's switch |
| **Discovery** | [tibet-ping](https://pypi.org/project/tibet-ping/) | LAN discovery, heartbeat, mesh relay |

## Standards

### IETF Standardization

- [draft-vandemeent-tibet-provenance](https://datatracker.ietf.org/doc/draft-vandemeent-tibet-provenance/) — Traceable Intent-Based Event Tokens
- [draft-vandemeent-jis-identity](https://datatracker.ietf.org/doc/draft-vandemeent-jis-identity/) — JTel Identity Standard
- [draft-vandemeent-upip-process-integrity](https://datatracker.ietf.org/doc/draft-vandemeent-upip-process-integrity/) — Universal Process Integrity Protocol
- [draft-vandemeent-rvp-continuous-verification](https://datatracker.ietf.org/doc/draft-vandemeent-rvp-continuous-verification/) — Real-time Verification Protocol
- [draft-vandemeent-ains-discovery](https://datatracker.ietf.org/doc/draft-vandemeent-ains-discovery/) — AInternet Name Service

### Regulatory

| Regulation | TIBET provides |
|------------|---------------|
| **EU AI Act** | Automated decision traceability, transparency |
| **EU CRA** | Build provenance, SBOM accountability |
| **GDPR Art. 22** | Consent proof, decision audit trail |
| **NIS2** | Continuous logging, incident snapshots |

CRA enforcement starts **September 2026**. TIBET makes compliance architectural, not bolted-on.

## License

MIT

## Credits

Designed by [Jasper van de Meent](https://github.com/jaspertvdm). Built by Jasper and [Root AI](https://humotica.com) as part of [HumoticaOS](https://humotica.com).

One love, one fAmIly.
