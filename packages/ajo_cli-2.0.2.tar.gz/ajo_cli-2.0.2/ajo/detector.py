"""Professional project detector for Django projects with enhanced state detection."""

import os
import re
import socket
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Optional, Dict, List, Any, Tuple


class DjangoProjectDetector:
    """
    Professional Django project detector.
    Detects Django projects, extracts information, and provides
    comprehensive project state analysis with visual feedback.
    """

    def __init__(self, path: Optional[Path] = None):
        self.path = path or Path.cwd()
        self.is_django_project = False
        self.project_info: Dict[str, Any] = {
            "project_name": "Unknown",
            "settings_module": "Unknown",
            "apps": [],
            "needs_migrations": False,
            "server_running": False,
            "venv_active": False,
            "git_branch": "N/A",
            "models_count": 0,
            "unapplied_migrations": [],
            "has_admin": False,
            "has_static": False,
            "has_media": False,
        }
        self._detect()

    def _show_progress(
        self, target_func, message: str, timeout_threshold: float = 2.0
    ) -> Any:
        """Runs a heavy operation in a background thread while displaying a live progress bar."""
        result_holder = {"data": None, "done": False}

        def worker():
            try:
                result_holder["data"] = target_func()
            except Exception:
                pass
            finally:
                result_holder["done"] = True

        thread = threading.Thread(target=worker, daemon=True)
        start_time = time.time()
        thread.start()

        # رسوم متحركة للـ Loading (Spinner & Progress Bar)
        spinner = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
        idx = 0

        while not result_holder["done"]:
            elapsed = time.time() - start_time
            # بناء شريط تقدم بسيط (يتكرر كل ثانيتين ليعطي إيحاء بالحركة)
            bar_length = int((elapsed % 2) * 10)
            progress_bar = f"[{'■' * bar_length}{' ' * (10 - bar_length)}]"

            # إذا استغرقت العملية وقت أطول من المعتاد، نظهر تلميح ذكي للمستخدم
            hint = ""
            if elapsed > timeout_threshold:
                hint = f" ⏳ (Taking longer than usual... Check DB connection?)"

            # طباعة السطر ومسح المتبقي في الكونسول لعرض مستمر وسلس
            sys.stdout.write(
                f"\r {spinner[idx % len(spinner)]} {message} {progress_bar}{hint}"
            )
            sys.stdout.flush()

            idx += 1
            time.sleep(0.08)

        # تنظيف السطر بعد انتهاء العملية بنجاح
        sys.stdout.write("\r" + " " * 80 + "\r")
        sys.stdout.flush()
        return result_holder["data"]

    def _detect(self) -> None:
        if self.path.name == "ajo-cli":
            self.is_django_project = False
            return

        manage_py = self._find_manage_py()
        if not manage_py or not self._verify_django_project(manage_py):
            self.is_django_project = False
            return

        self.is_django_project = True

        # Extract core info first (Fast operations)
        self._extract_project_name(manage_py)
        self.project_info["venv_active"] = self._check_venv()
        self.project_info["server_running"] = self._check_server_running()
        self.project_info["git_branch"] = self._get_git_branch()
        self.project_info["has_static"] = self._check_static_files()
        self.project_info["has_media"] = self._check_media_files()
        self.project_info["has_admin"] = self._check_admin_enabled()

        # Detect apps and count models locally (Fast)
        self.project_info["apps"] = self._detect_apps()
        self.project_info["models_count"] = self._count_models()

        # Subprocess operations (Heavy operations wrapped with a smooth progress bar)
        print("🔍 Analyzing project states...")
        self.project_info["needs_migrations"] = self._show_progress(
            self._check_migrations_needed,
            message="Checking for model changes",
            timeout_threshold=2.5,
        )
        self.project_info["unapplied_migrations"] = self._show_progress(
            self._check_unapplied_migrations,
            message="Checking for unapplied migrations",
            timeout_threshold=2.5,
        )

    def _find_manage_py(self) -> Optional[Path]:
        manage_py = self.path / "manage.py"
        if manage_py.exists():
            return manage_py

        for parent in self.path.parents:
            if (parent / "manage.py").exists():
                self.path = parent
                return parent / "manage.py"
        return None

    def _verify_django_project(self, manage_py: Path) -> bool:
        try:
            content = manage_py.read_text(encoding="utf-8", errors="ignore")
            return "django.core.management" in content
        except Exception:
            return False

    def _extract_project_name(self, manage_py: Path) -> None:
        try:
            content = manage_py.read_text(encoding="utf-8", errors="ignore")
            match = re.search(r"DJANGO_SETTINGS_MODULE\s*=\s*['\"]([^'\"]+)", content)
            if match:
                self.project_info["settings_module"] = match.group(1)
                self.project_info["project_name"] = match.group(1).split(".")[0]
            else:
                self.project_info["project_name"] = self.path.name
        except Exception:
            self.project_info["project_name"] = self.path.name

    def _detect_apps(self) -> List[Dict[str, Any]]:
        apps = []
        try:
            for item in self.path.iterdir():
                if (
                    not item.is_dir()
                    or item.name.startswith(".")
                    or item.name == "config"
                ):
                    continue

                is_app = (item / "apps.py").exists() or (item / "models.py").exists()
                if not is_app:
                    continue

                apps.append(
                    {
                        "name": item.name,
                        "path": str(item),
                        "has_models": (item / "models.py").exists(),
                        "has_admin": (item / "admin.py").exists(),
                        "has_views": (item / "views.py").exists(),
                        "has_urls": (item / "urls.py").exists(),
                        "has_templates": (item / "templates").exists(),
                        "has_migrations": (item / "migrations").exists(),
                        "is_installed": self._is_in_installed_apps(item.name),
                        "models_count": self._count_app_models(item),
                    }
                )
        except Exception:
            pass
        return apps

    def _count_app_models(self, app_path: Path) -> int:
        try:
            models_file = app_path / "models.py"
            if models_file.exists():
                content = models_file.read_text(encoding="utf-8", errors="ignore")
                return len(re.findall(r"class\s+(\w+)\s*\(.*models\.Model\)", content))
        except Exception:
            pass
        return 0

    def _is_in_installed_apps(self, app_name: str) -> bool:
        try:
            settings_dir = (
                self.path / self.project_info.get("project_name", "") / "settings"
            )
            files_to_check = (
                list(settings_dir.glob("*.py")) if settings_dir.exists() else []
            )

            single_settings = self._find_settings_path()
            if single_settings:
                files_to_check.append(single_settings)

            for settings_file in files_to_check:
                content = settings_file.read_text(encoding="utf-8", errors="ignore")
                if (
                    f"'{app_name}'" in content
                    or f'"{app_name}"' in content
                    or f"{app_name}.apps" in content
                ):
                    return True
        except Exception:
            pass
        return False

    def _find_settings_path(self) -> Optional[Path]:
        p_name = self.project_info.get("project_name", "")
        paths = [self.path / p_name / "settings.py", self.path / "settings.py"]
        for p in paths:
            if p.exists():
                return p
        for p in self.path.glob("**/settings.py"):
            return p
        return None

    def _check_migrations_needed(self) -> bool:
        try:
            result = subprocess.run(
                ["uv", "run", "python", "manage.py", "makemigrations", "--dry-run"],
                cwd=self.path,
                capture_output=True,
                text=True,
                timeout=5,
            )
            return "No changes detected" not in result.stdout and result.returncode == 0
        except Exception:
            return False

    def _check_server_running(self) -> bool:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(0.2)
            result = sock.connect_ex(("127.0.0.1", 8000))
            sock.close()
            return result == 0
        except Exception:
            return False

    def _check_venv(self) -> bool:
        return bool(os.environ.get("VIRTUAL_ENV")) or bool(
            os.environ.get("UV_PROJECT_ENVIRONMENT")
        )

    def _get_git_branch(self) -> str:
        try:
            result = subprocess.run(
                ["git", "branch", "--show-current"],
                cwd=self.path,
                capture_output=True,
                text=True,
                timeout=1,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except Exception:
            pass
        return "N/A"

    def _count_models(self) -> int:
        return sum(
            app.get("models_count", 0) for app in self.project_info.get("apps", [])
        )

    def _check_unapplied_migrations(self) -> List[str]:
        try:
            result = subprocess.run(
                ["uv", "run", "python", "manage.py", "showmigrations", "--plan"],
                cwd=self.path,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                unapplied = []
                for line in result.stdout.splitlines():
                    if "[ ]" in line:
                        clean_line = line.replace("[ ]", "").strip()
                        if clean_line:
                            unapplied.append(clean_line)
                return unapplied
        except Exception:
            pass
        return []

    def _check_admin_enabled(self) -> bool:
        try:
            p_name = self.project_info.get("project_name", "")
            urls_path = self.path / p_name / "urls.py"
            if not urls_path.exists():
                urls_path = self.path / "urls.py"

            if urls_path.exists():
                return "admin.site.urls" in urls_path.read_text(
                    encoding="utf-8", errors="ignore"
                )
        except Exception:
            pass
        return False

    def _check_static_files(self) -> bool:
        return (self.path / "static").exists() or (self.path / "staticfiles").exists()

    def _check_media_files(self) -> bool:
        return (self.path / "media").exists()

    def get_status_dashboard(self) -> str:
        if not self.is_django_project:
            return "❌ Not a Django project (Missing manage.py)"

        project_name = str(self.project_info.get("project_name", "Unknown"))[:40]
        git_branch = str(self.project_info.get("git_branch", "N/A"))[:40]
        venv_status = (
            "✅ Active" if self.project_info.get("venv_active") else "❌ Inactive"
        )
        server_status = (
            "🟢 Running" if self.project_info.get("server_running") else "⚫ Stopped"
        )
        apps_count = str(len(self.project_info.get("apps", [])))
        models_count = str(self.project_info.get("models_count", 0))
        needs_migrations = (
            "⚠️ Needed" if self.project_info.get("needs_migrations") else "✅ Up to date"
        )
        unapplied_count = str(len(self.project_info.get("unapplied_migrations", [])))
        admin_status = (
            "✅ Enabled" if self.project_info.get("has_admin") else "❌ Disabled"
        )

        return f"""
╭─────────────────────────────────────────────────────────────────╮
│                     📊 DJANGO PROJECT STATUS                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  📁 Project:     {project_name:<46} │
│  🌿 Branch:      {git_branch:<46} │
│  🐍 VirtualEnv:  {venv_status:<46} │
│  🖥️  Server:      {server_status:<46} │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│  📦 Apps:        {apps_count:<46} │
│  🗄️  Models:      {models_count:<46} │
│  👑 Admin:       {admin_status:<46} │
│                                                                 │
├─────────────────────────────────────────────────────────────────┤
│  📝 Migrations:  {needs_migrations:<46} │
│  ⏳ Pending:      {unapplied_count:<46} │
│                                                                 │
╰─────────────────────────────────────────────────────────────────╯
"""


class SmartDjangoCLI:
    """Smart CLI for Django project management with contextual commands."""

    def __init__(self, detector: DjangoProjectDetector):
        self.detector = detector

    def get_commands(self) -> List[Dict[str, str]]:
        base_commands = [
            {
                "name": "🏃 Run Server",
                "action": "runserver",
                "description": "Start development server",
                "icon": "🖥️",
            },
            {
                "name": "🔄 Make Migrations",
                "action": "makemigrations",
                "description": "Create new migrations",
                "icon": "📝",
            },
            {
                "name": "⚙️ Migrate",
                "action": "migrate",
                "description": "Apply migrations",
                "icon": "🔄",
            },
            {
                "name": "👤 Create Superuser",
                "action": "createsuperuser",
                "description": "Create admin user",
                "icon": "👑",
            },
            {
                "name": "🧪 Run Tests",
                "action": "test",
                "description": "Run all tests",
                "icon": "✅",
            },
            {
                "name": "📱 Create New App",
                "action": "create_app",
                "description": "Scaffold a new app",
                "icon": "📦",
            },
            {
                "name": "🔧 Django Shell",
                "action": "shell",
                "description": "Open Django shell",
                "icon": "💻",
            },
        ]

        dynamic_commands = []

        if self.detector.project_info.get("needs_migrations"):
            base_commands = [
                c for c in base_commands if c["action"] != "makemigrations"
            ]
            dynamic_commands.append(
                {
                    "name": "⚠️ Make Migrations (Needed!)",
                    "action": "makemigrations",
                    "description": "Model changes detected! Run this first",
                    "icon": "⚠️",
                }
            )

        unapplied = len(self.detector.project_info.get("unapplied_migrations", []))
        if unapplied > 0:
            base_commands = [c for c in base_commands if c["action"] != "migrate"]
            dynamic_commands.append(
                {
                    "name": f"⚠️ Migrate ({unapplied} pending)",
                    "action": "migrate",
                    "description": f"Apply {unapplied} pending migration(s)",
                    "icon": "⚠️",
                }
            )

        return dynamic_commands + base_commands

    def execute_command(self, action: str) -> None:
        if not self.detector.is_django_project:
            print("Error: No Django project detected here.")
            return

        cmd_mapping = {
            "runserver": ["run", "python", "manage.py", "runserver"],
            "makemigrations": ["run", "python", "manage.py", "makemigrations"],
            "migrate": ["run", "python", "manage.py", "migrate"],
            "createsuperuser": ["run", "python", "manage.py", "createsuperuser"],
            "test": ["run", "python", "manage.py", "test"],
            "shell": ["run", "python", "manage.py", "shell"],
        }

        if action in cmd_mapping:
            try:
                subprocess.run(
                    ["uv"] + cmd_mapping[action], cwd=self.detector.path, check=True
                )
            except KeyboardInterrupt:
                print("\n⚫ Command terminated by user.")
            except subprocess.CalledProcessError as e:
                print(f"\n❌ Error executing command: {e}")
        elif action == "create_app":
            app_name = input("Enter new app name: ").strip()
            if app_name:
                subprocess.run(
                    ["uv", "run", "python", "manage.py", "startapp", app_name],
                    cwd=self.detector.path,
                )
                print(
                    f"✅ App '{app_name}' created. Don't forget to add it to INSTALLED_APPS!"
                )


if __name__ == "__main__":
    # لتجربة الكود مباشرة ورؤية التأثير المرئي:
    detector = DjangoProjectDetector()
    print(detector.get_status_dashboard())
