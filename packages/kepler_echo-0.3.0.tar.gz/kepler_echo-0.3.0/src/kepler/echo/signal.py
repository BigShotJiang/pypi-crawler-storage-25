"""
Signal processor for handling trading signals.
"""
from typing import Optional
import pandas as pd
import numpy as np

from kepler.echo.types import MatchingType
from kepler.echo.exceptions import SignalError


TIME_SHIFT = pd.Timedelta(seconds=1)


class SignalProcessor:
    """
    Signal processor for validating and transforming trading signals.

    Attributes:
        matching: The matching type ('next_bar' or 'current_bar')
    """

    def __init__(self, matching: str = "next_bar"):
        if not MatchingType.is_valid(matching):
            raise ValueError("matching must be next_bar or current_bar")
        self.matching = matching
        self._original_signal: Optional[pd.DataFrame] = None

    def process(self, signal: pd.DataFrame) -> pd.DataFrame:
        """
        Process raw signal into internal format.

        Args:
            signal: Raw signal DataFrame

        Returns:
            Processed signal DataFrame with cash weight added
        """
        self._validate(signal)
        signal = self._transform_format(signal)
        self._original_signal = signal.copy()

        signal = self._add_cash_weight(signal)

        if self.matching == MatchingType.NEXT_BAR:
            signal.index += TIME_SHIFT

        return signal

    def _validate(self, signal: pd.DataFrame) -> None:
        """Validate signal format."""
        if not isinstance(signal, pd.DataFrame):
            raise SignalError("The signal must be a DataFrame!")

        if signal.empty:
            raise SignalError("Signal cannot be empty")

    def _transform_format(self, signal: pd.DataFrame) -> pd.DataFrame:
        """
        Transform signal to wide format if needed.

        Supports two input formats:
        1. Wide format: DataFrame with dates as index and stock IDs as columns
        2. Long format: DataFrame with columns ['date', 'stockid', 'weight']
        """
        signal = signal.copy()

        # Check if long format (three columns with integer index)
        if isinstance(signal.index[0], (int, np.int64)):
            signal.columns = [c.lower() for c in signal.columns]
            required = {"date", "stockid", "weight"}
            if not required.issubset(set(signal.columns)):
                raise SignalError(f"Long format signal must contain {required}")

            signal = signal.pivot(values="weight", index="date", columns="stockid")

        # Remove cash column if present
        signal.drop(["cash"], axis=1, inplace=True, errors="ignore")

        # Ensure index is datetime
        signal.index = pd.to_datetime(signal.index)

        return signal

    def get_original_signal(self) -> pd.DataFrame:
        """Get the original signal (before cash weight and time shift)."""
        return self._original_signal

    def _add_cash_weight(self, signal: pd.DataFrame) -> pd.DataFrame:
        """
        Add cash weight to make total weight equal to 1 (or -1 for short bias).

        cash = sign(total_weight) - total_weight

        This allows leverage when total_weight > 1.
        """
        total = signal.sum(axis=1)
        signal = signal.copy()
        signal["cash"] = 1 * np.sign(total + 1e-8) - total
        return signal
