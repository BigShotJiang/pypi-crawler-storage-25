"""
Performance analyzer for backtesting metrics.
"""
from dataclasses import dataclass
from typing import Optional
import pandas as pd
import numpy as np


@dataclass
class PerformanceMetrics:
    """
    Performance metrics dataclass.

    Attributes:
        turnover: Annualized turnover rate
        total_return: Total return over the period
        annual_return: Annualized return
        max_drawdown: Maximum drawdown
        sharpe_ratio: Sharpe ratio (annualized)
        volatility: Annualized volatility
    """
    turnover: float = 0.0
    total_return: float = 0.0
    annual_return: float = 0.0
    max_drawdown: float = 0.0
    sharpe_ratio: float = 0.0
    volatility: float = 0.0

    def to_dict(self) -> dict:
        """Convert to dictionary."""
        return {
            'turnover': self.turnover,
            'total_return': self.total_return,
            'annual_return': self.annual_return,
            'max_drawdown': self.max_drawdown,
            'sharpe_ratio': self.sharpe_ratio,
            'volatility': self.volatility
        }


class PerformanceAnalyzer:
    """
    Analyzer for computing performance metrics.

    This class extracts performance analysis logic from the Strategy class,
    providing standardized metrics calculation.

    Attributes:
        trading_days_per_year: Number of trading days used for annualization
    """

    TRADING_DAYS_PER_YEAR = 252

    def __init__(self, trading_days_per_year: int = 252):
        """
        Initialize the performance analyzer.

        Args:
            trading_days_per_year: Number of trading days for annualization
        """
        self.trading_days_per_year = trading_days_per_year

    def calculate_turnover(self, signal: pd.DataFrame, periods: int) -> float:
        """
        Calculate annualized turnover rate.

        Turnover is calculated as the sum of absolute weight changes,
        annualized by the number of periods.

        Args:
            signal: Signal DataFrame with weights
            periods: Number of periods in the backtest

        Returns:
            Annualized turnover rate
        """
        if signal.empty or periods == 0:
            return 0.0

        turnover = (
            signal.fillna(0).diff().abs().sum(axis=1).sum()
            / periods
            * self.trading_days_per_year
        )
        return turnover

    def analyze(
        self,
        nav: pd.Series,
        risk_free_rate: float = 0.04
    ) -> PerformanceMetrics:
        """
        Analyze performance metrics from NAV series.

        Args:
            nav: Cumulative returns (NAV) series
            risk_free_rate: Annual risk-free rate for Sharpe calculation

        Returns:
            PerformanceMetrics object with computed metrics
        """
        if nav.empty or len(nav) < 2:
            return PerformanceMetrics()

        returns = nav.pct_change(fill_method=None).dropna()

        # Total return
        total_return = (nav.iloc[-1] / nav.iloc[0] - 1) if len(nav) > 1 else 0

        # Annualized return
        days = len(nav)
        annual_return = (
            (1 + total_return) ** (self.trading_days_per_year / days) - 1
            if days > 0 else 0
        )

        # Maximum drawdown
        cumulative_max = nav.cummax()
        drawdown = (nav - cumulative_max) / cumulative_max
        max_drawdown = drawdown.min()

        # Volatility (annualized)
        volatility = (
            returns.std() * np.sqrt(self.trading_days_per_year)
            if len(returns) > 1 else 0
        )

        # Sharpe ratio
        excess_return = annual_return - risk_free_rate
        sharpe_ratio = excess_return / volatility if volatility > 0 else 0

        return PerformanceMetrics(
            total_return=total_return,
            annual_return=annual_return,
            max_drawdown=max_drawdown,
            sharpe_ratio=sharpe_ratio,
            volatility=volatility
        )

    def calculate_total_return(self, nav: pd.Series) -> float:
        """Calculate total return from NAV series."""
        if nav.empty or len(nav) < 2:
            return 0.0
        return nav.iloc[-1] / nav.iloc[0] - 1

    def calculate_max_drawdown(self, nav: pd.Series) -> float:
        """Calculate maximum drawdown from NAV series."""
        if nav.empty:
            return 0.0

        cumulative_max = nav.cummax()
        drawdown = (nav - cumulative_max) / cumulative_max
        return drawdown.min()

    def calculate_sharpe_ratio(
        self,
        nav: pd.Series,
        risk_free_rate: float = 0.04
    ) -> float:
        """Calculate Sharpe ratio from NAV series."""
        if nav.empty or len(nav) < 2:
            return 0.0

        returns = nav.pct_change(fill_method=None).dropna()

        if len(returns) < 2:
            return 0.0

        days = len(nav)
        total_return = nav.iloc[-1] / nav.iloc[0] - 1
        annual_return = (1 + total_return) ** (self.trading_days_per_year / days) - 1
        volatility = returns.std() * np.sqrt(self.trading_days_per_year)

        if volatility == 0:
            return 0.0

        return (annual_return - risk_free_rate) / volatility
