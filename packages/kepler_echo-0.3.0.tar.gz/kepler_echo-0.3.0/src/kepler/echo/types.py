"""
Type definitions for kepler-echo backtesting framework.
"""


class MatchingType:
    """Matching type constants."""
    NEXT_BAR = "next_bar"
    CURRENT_BAR = "current_bar"

    VALID_TYPES = (NEXT_BAR, CURRENT_BAR)

    @classmethod
    def is_valid(cls, matching: str) -> bool:
        """Check if matching type is valid."""
        return matching in cls.VALID_TYPES
