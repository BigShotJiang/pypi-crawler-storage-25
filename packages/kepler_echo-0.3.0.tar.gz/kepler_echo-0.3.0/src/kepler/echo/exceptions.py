"""
Custom exceptions for kepler-echo backtesting framework.
"""
from typing import Optional, Set


class KeplerEchoError(Exception):
    """Base exception for all kepler-echo errors."""
    pass


class DataError(KeplerEchoError):
    """Exception raised for data-related errors.

    Attributes:
        message: Error message
        missing_columns: Set of missing column names (if applicable)
    """

    def __init__(self, message: str, missing_columns: Optional[Set[str]] = None):
        super().__init__(message)
        self.missing_columns = missing_columns


class SignalError(KeplerEchoError):
    """Exception raised for signal-related errors.

    Attributes:
        message: Error message
    """
    pass


class ConfigurationError(KeplerEchoError):
    """Exception raised for configuration errors.

    Attributes:
        message: Error message
        parameter: Name of the invalid parameter (if applicable)
    """

    def __init__(self, message: str, parameter: Optional[str] = None):
        super().__init__(message)
        self.parameter = parameter


class BacktestError(KeplerEchoError):
    """Exception raised during backtest execution.

    Attributes:
        message: Error message
        stage: The stage where the error occurred (if applicable)
    """

    def __init__(self, message: str, stage: Optional[str] = None):
        super().__init__(message)
        self.stage = stage
