class ShiftChatexception(Exception):
    """Base exception for Shift Chat Client"""
    pass

class AuthenticationError(ShiftChatexception):
    """Raised when authentication fails"""
    pass

class APIError(ShiftChatexception):
    """Raised when API request fails"""
    pass
