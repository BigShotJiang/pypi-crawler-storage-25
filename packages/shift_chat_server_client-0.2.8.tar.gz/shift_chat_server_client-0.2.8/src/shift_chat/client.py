import requests
from typing import Optional, Dict, List
from .exceptions import AuthenticationError, APIError

class ShiftChatClient:
    def __init__(self, client_id: str, client_secret: str):
        self.base_url = "https://api.shiftchat.io"
        self.client_id = client_id
        self.client_secret = client_secret
        self._access_token: Optional[str] = None
        self._session = requests.Session()

    def authenticate(self) -> str:
        """Authenticate as a client and get an access token."""
        url = f"{self.base_url}/auth/client/login"
        payload = {
            "clientId": self.client_id,
            "clientSecret": self.client_secret
        }
        
        try:
            response = self._session.post(url, json=payload)
            response.raise_for_status()
            data = response.json()
            self._access_token = data.get("accessToken")
            if not self._access_token:
                raise AuthenticationError("No access token received")
            return self._access_token
        except requests.exceptions.HTTPError as e:
            raise AuthenticationError(f"Authentication failed: {str(e)}") from e

    def _get_headers(self, token: Optional[str] = None, impersonate_token: Optional[str] = None) -> Dict[str, str]:
        headers = {
            "Content-Type": "application/json"
        }
        
        auth_token = impersonate_token or token or self._access_token
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"
            
        return headers

    def authenticate_user(self, user_id: str) -> 'ShiftChatUserClient':
        """Authenticate a user via client delegation and return a user client."""
        if not self._access_token:
            self.authenticate()
            
        url = f"{self.base_url}/auth/client/delegate"
        payload = {"userId": user_id}
        headers = self._get_headers()
        
        try:
            response = self._session.post(url, json=payload, headers=headers)
            response.raise_for_status()
            data = response.json()
            user_token = data.get("accessToken")
            if not user_token:
                raise AuthenticationError("No user token received")
            
            return ShiftChatUserClient(user_token)
            
        except requests.exceptions.HTTPError as e:
            raise APIError(f"Failed to authenticate user: {str(e)}") from e

    def set_user(self, 
                 first_name: str, 
                 last_name: str, 
                 password: str,
                 email: Optional[str] = None, 
                 phone_number: Optional[str] = None,
                 reference_id: Optional[str] = None) -> Dict:
        """Create or update a user.
        
        Args:
            first_name: User's first name
            last_name: User's last name
            password: User's password
            email: User's email (optional if phone_number is provided)
            email: User's email (optional if phone_number is provided)
            phone_number: User's phone number (optional if email is provided)
            reference_id: External unique ID for mapping (optional)
            
        Returns:
            Dict: The created or updated user data
            
        Raises:
            ValueError: If neither email nor phone_number is provided
            APIError: If the API request fails
        """
        if not email and not phone_number:
            raise ValueError("At least one of email or phone_number must be provided")
            
        url = f"{self.base_url}/users"
        payload = {
            "firstName": first_name,
            "lastName": last_name,
            "password": password
        }
        
        if email:
            payload["email"] = email
        if email:
            payload["email"] = email
        if phone_number:
            payload["phoneNumber"] = phone_number
        if reference_id:
            payload["referenceId"] = reference_id
        
        try:
            response = self._session.post(url, json=payload)
            if response.status_code == 201:
                return response.json()
            
            # If 409 (Conflict) or similar, we might want to update? 
            # But standard public register might not support update.
            # Ideally we'd have a server-to-server endpoint for upserting users.
            
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
             raise APIError(f"Failed to create user: {str(e)}") from e

    def sync_user(self, 
                 first_name: str, 
                 last_name: str, 
                 email: Optional[str] = None, 
                 phone_number: Optional[str] = None,
                 reference_id: Optional[str] = None,
                 is_admin: Optional[bool] = None,
                 is_soft_user: Optional[bool] = None) -> Dict:
        """Create or update a user using the API client securely.
        
        Args:
            first_name: User's first name
            last_name: User's last name
            email: User's email (optional)
            phone_number: User's phone number (optional)
            reference_id: External unique ID for mapping (optional)
            is_admin: Set user as admin (optional)
            is_soft_user: Set if the user is a soft user (optional)
            
        Returns:
            Dict: The created or updated user data
            
        Raises:
            ValueError: If neither email, phone_number nor reference_id is provided
            APIError: If the API request fails
        """
        if not email and not phone_number and not reference_id:
            raise ValueError("At least one of email, phone_number, or reference_id must be provided")
            
        if not self._access_token:
            self.authenticate()

        url = f"{self.base_url}/users/client/sync"
        payload = {
            "firstName": first_name,
            "lastName": last_name
        }
        
        if email:
            payload["email"] = email
        if phone_number:
            payload["phoneNumber"] = phone_number
        if reference_id:
            payload["referenceId"] = reference_id
        if is_admin is not None:
            payload["isAdmin"] = is_admin
        if is_soft_user is not None:
            payload["isSoftUser"] = is_soft_user
            
        try:
            response = self._session.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise APIError(f"Failed to sync user: {str(e)}") from e

    def get_user_by_reference_id(self, reference_id: str) -> Dict:
        """Get a user by their external reference ID.
        
        Args:
            reference_id: The external unique ID
            
        Returns:
            Dict: The user data
            
        Raises:
            APIError: If the API request fails (e.g. 404 Not Found)
        """
        url = f"{self.base_url}/users/reference/{reference_id}"
        try:
            response = self._session.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 404:
                return None
            raise APIError(f"Failed to get user by reference ID: {str(e)}") from e

class ShiftChatUserClient:
    """Client for performing actions on behalf of a user."""
    def __init__(self, access_token: str):
        self.base_url = "https://api.shiftchat.io"
        self._access_token = access_token
        self._session = requests.Session()

    def _get_headers(self) -> Dict[str, str]:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._access_token}"
        }

    def create_workspace(self, name: str, slug: Optional[str] = None) -> Dict:
        """Create a new workspace."""
        url = f"{self.base_url}/workspaces"
        
        if not slug:
            # Simple slug generation
            slug = name.lower().replace(" ", "-")
            # Remove special chars if needed, but keeping it simple for now
            
        payload = {
            "name": name,
            "slug": slug
        }
        
        try:
            response = self._session.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise APIError(f"Failed to create workspace '{name}': {str(e)}") from e

    def add_user_to_workspace(self, user_id: str, workspace_id: str) -> None:
        """Add a user to a workspace."""
        url = f"{self.base_url}/workspaces/invite"
        payload = {
            "userId": user_id,
            "workspaceId": workspace_id
        }
        
        try:
            response = self._session.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            raise APIError(f"Failed to add user {user_id} to workspace {workspace_id}: {str(e)}") from e

    def add_user_to_channel(self, user_id: str, channel_id: str) -> None:
        """Add a user to a channel."""
        url = f"{self.base_url}/channels/invite"
        payload = {
            "userId": user_id,
            "channelId": channel_id
        }
        
        try:
            response = self._session.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
             raise APIError(f"Failed to add user {user_id} to channel {channel_id}: {str(e)}") from e

    def set_channel(self, workspace_id: str, name: str, is_public: bool = False, type: str = "GROUP") -> Dict:
        """Create a channel."""
        url = f"{self.base_url}/channels/group"
        payload = {
            "workspaceId": workspace_id,
            "name": name,
            "isPublic": is_public
        }
        
        try:
            response = self._session.post(url, json=payload, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise APIError(f"Failed to create channel: {str(e)}") from e

    def get_workspaces(self) -> List[Dict]:
        """Get all workspaces the user is a member of."""
        url = f"{self.base_url}/workspaces"
        try:
            response = self._session.get(url, headers=self._get_headers())
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise APIError(f"Failed to get workspaces: {str(e)}") from e

    def get_workspace_channels(self, workspace_id: str) -> List[Dict]:
        """Get all channels for a user in a specific workspace."""
        url = f"{self.base_url}/channels/user"
        params = {"workspaceId": workspace_id}
        try:
            response = self._session.get(url, headers=self._get_headers(), params=params)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.HTTPError as e:
            raise APIError(f"Failed to get channels for workspace {workspace_id}: {str(e)}") from e

    def get_workspaces_with_channels(self) -> List[Dict]:
        """Get all workspaces with their channels and members, formatted for mobile app."""
        workspaces = self.get_workspaces()
        for workspace in workspaces:
            workspace_id = workspace.get("id")
            if workspace_id:
                try:
                    # fetch channels for the user in this workspace
                    channels = self.get_workspace_channels(workspace_id)
                    
                    formatted_channels = []
                    for channel in channels:
                        # Extract basic info
                        channel_data = {
                            "channel": channel.get("name"),
                            "id": channel.get("id"),
                            "users": []
                        }
                        
                        # Extract members if available (server should return them in members field)
                        members = channel.get("members", [])
                        users_list = []
                        for member in members:
                            # member structure from Prisma include usually has 'user' object inside
                            user_obj = member.get("user")
                            if user_obj:
                                users_list.append(user_obj)
                        
                        channel_data["users"] = users_list
                        formatted_channels.append(channel_data)

                    workspace["channels"] = formatted_channels
                except APIError:
                    workspace["channels"] = []
        return workspaces
