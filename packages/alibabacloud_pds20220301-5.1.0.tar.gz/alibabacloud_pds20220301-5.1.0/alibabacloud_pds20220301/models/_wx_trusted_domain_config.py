# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class WxTrustedDomainConfig(DaraModel):
    def __init__(
        self,
        content: str = None,
        name: str = None,
        show: bool = None,
    ):
        self.content = content
        self.name = name
        self.show = show

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.content is not None:
            result['content'] = self.content

        if self.name is not None:
            result['name'] = self.name

        if self.show is not None:
            result['show'] = self.show

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('content') is not None:
            self.content = m.get('content')

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('show') is not None:
            self.show = m.get('show')

        return self

