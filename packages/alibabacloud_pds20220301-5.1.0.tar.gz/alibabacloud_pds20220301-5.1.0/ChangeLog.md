2026-04-28 Version: 5.0.0
- Support API PunishFile.
- Update API CreateDomain: add request parameters body.store_redundancy_type.
- Update API CreateFile: add request parameters body.part_info_list.$.content_type.
- Update API CreateFile: delete request parameters body.image_media_metadata.
- Update API CreateFile: delete request parameters body.video_media_metadata.
- Update API GetAsyncTask: add response parameters Body.task_type.
- Update API MoveFile: add response parameters Body.file_name.
- Update API MoveFile: add response parameters Body.revision_id.
- Update API MoveFile: add response parameters Body.updated_at.


2025-05-20 Version: 4.2.6
- Update API CompleteFile: add request parameters body.crc64_hash.


2025-04-22 Version: 4.2.5
- Generated python 2022-03-01 for pds.

2025-04-22 Version: 4.2.4
- Update API GetShareLinkByAnonymous: add response parameters Body.has_pwd.


2025-03-24 Version: 4.2.3
- Generated python 2022-03-01 for pds.

2025-03-20 Version: 4.2.2
- Generated python 2022-03-01 for pds.

2025-03-20 Version: 4.2.1
- Generated python 2022-03-01 for pds.

2025-03-20 Version: 4.2.0
- Support API AuditLogExport.


2025-03-10 Version: 4.1.0
- Support API VideoDRMLicense.
- Update API ListRecyclebin: update param body.
- Update API SearchFile: update param body.


2025-01-10 Version: 4.0.3
- Generated python 2022-03-01 for pds.

2025-01-10 Version: 4.0.2
- Generated python 2022-03-01 for pds.

2024-12-30 Version: 4.0.1
- Update API AddStoryFiles: update response param.
- Update API ClearRecyclebin: update param body.
- Update API CreateShareLink: update param body.
- Update API FileListPermission: update param body.
- Update API GetLinkInfoByUserId: update param body.
- Update API ListAssignment: update param body.
- Update API ListMyGroupDrive: update param body.
- Update API UpdateShareLink: update param body.


2024-08-26 Version: 4.0.0
- Update API GetVideoPreviewPlayInfo: update param body.
- Update API GetVideoPreviewPlayInfo: update response param.
- Update API InvestigateFile: update param body.


2024-07-31 Version: 3.0.3
- Generated python 2022-03-01 for pds.

2024-07-24 Version: 3.0.2
- Update API GetDownloadUrl: update param body.
- Update API SearchFile: update param body.


2024-06-05 Version: 3.0.1
- Update API Batch: update param body.
- Update API Batch: update response param.
- Update API CreateDrive: update response param.
- Update API CreateShareLink: update param body.
- Update API GetDomain: update param body.
- Update API GetUploadUrl: update param body.
- Update API InvestigateFile: update param body.
- Update API ListDomains: update param body.
- Update API ListMyGroupDrive: update response param.
- Update API SearchDomains: update param body.
- Update API SearchFile: update param body.


2023-11-30 Version: 3.0.0
- Generated python 2022-03-01 for pds.

2023-10-19 Version: 2.1.0
- Generated python 2022-03-01 for pds.

2023-09-01 Version: 2.0.1
- Generated python 2022-03-01 for pds.

2023-08-28 Version: 2.0.0
- Generated python 2022-03-01 for pds.

2023-06-25 Version: 1.0.11
- 新增AI字段

2023-05-23 Version: 1.0.10
- Support list assignment api.

2023-04-26 Version: 1.0.9
- support benefit management

2023-04-14 Version: 1.0.8
- support modify owner when update drive.
- support share drive
- suport live transcoding

2023-04-06 Version: 1.0.7
- Add domain api

2022-11-18 Version: 1.0.6
- Add get media meta interface

2022-11-18 Version: 1.0.5
- Add get media meta interface

2022-08-29 Version: 1.0.4
- 新增异步任务接口

2022-07-13 Version: 1.0.3
- 修复 list delta 接口关于 domain id 参数的属性.

2022-07-11 Version: 1.0.2
- Update remove face group file request.


2022-07-11 Version: 1.0.1
- Update remove face group file request.


2022-07-10 Version: 1.0.0
升级amp平台sdk

