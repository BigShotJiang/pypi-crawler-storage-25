"""Sensor browsing CLI commands (issues #54, #59).

Read-only commands for browsing the sensor registry backed by 80+
sensor YAML definitions with TF-IDF keyword search.
"""

import json

import click
from rich.console import Console
from rich.table import Table

console = Console()


@click.group()
def sensor():
    """Browse the sensor registry.

    \\b
    Examples:
      branes sensor list
      branes sensor list --category visual
      branes sensor show <sensor_id>
      branes sensor search "stereo camera 30fps"
      branes sensor categories
    """
    pass


@sensor.command("list")
@click.option(
    "--category",
    type=str,
    default=None,
    help="Filter by category (visual, ranging, inertial, ...)",
)
@click.pass_context
def sensor_list(ctx, category):
    """List all sensors in the registry."""
    from embodied_ai_architect.sensors import SensorRegistry

    registry = SensorRegistry()
    sensors = registry.list_sensors(modality=category)

    json_output = ctx.obj.get("json", False)
    if json_output:
        click.echo(
            json.dumps(
                [{"id": s.id, "name": s.name, "category": s.category} for s in sensors],
                indent=2,
            )
        )
        return

    if not sensors:
        msg = "No sensors found."
        if category:
            msg += f" (filtered by category={category})"
        console.print(f"[yellow]{msg}[/yellow]")
        return

    table = Table(title="Sensors", show_header=True)
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Category")
    table.add_column("Type", style="dim")

    for s in sensors:
        table.add_row(s.id, s.name, s.category, s.sensor_type)

    console.print(table)


@sensor.command("show")
@click.argument("sensor_id")
@click.pass_context
def sensor_show(ctx, sensor_id):
    """Show details for a specific sensor."""
    from embodied_ai_architect.sensors import SensorRegistry

    registry = SensorRegistry()
    s = registry.get(sensor_id)

    json_output = ctx.obj.get("json", False)
    if not s:
        if json_output:
            click.echo(json.dumps({"error": f"Sensor '{sensor_id}' not found"}))
        else:
            console.print(f"[red]Sensor '{sensor_id}' not found.[/red]")
        ctx.exit(1)
        return
    if json_output:
        click.echo(
            json.dumps(
                {
                    "id": s.id,
                    "name": s.name,
                    "category": s.category,
                    "sensor_type": s.sensor_type,
                    "description": s.description,
                    "attributes": s.attributes,
                },
                indent=2,
            )
        )
        return

    console.print(f"\n[bold cyan]{s.name}[/bold cyan]  ({s.id})")
    console.print(f"  Category:  {s.category}")
    if s.sensor_type:
        console.print(f"  Type:      {s.sensor_type}")
    if s.description:
        console.print(f"  {s.description}")
    if s.aliases:
        console.print(f"  Aliases:   {', '.join(s.aliases)}")
    if s.attributes:
        console.print("\n  [bold]Attributes[/bold]")
        for k, v in s.attributes.items():
            console.print(f"    {k}: {v}")


@sensor.command("search")
@click.argument("query")
@click.pass_context
def sensor_search(ctx, query):
    """Search sensors by keyword."""
    from embodied_ai_architect.sensors import SensorRegistry

    registry = SensorRegistry()
    results = registry.search(query)

    json_output = ctx.obj.get("json", False)
    if json_output:
        click.echo(
            json.dumps(
                [
                    {
                        "id": r.sensor_id,
                        "name": r.sensor.name,
                        "category": r.sensor.category,
                        "score": r.score,
                    }
                    for r in results
                ],
                indent=2,
            )
        )
        return

    if not results:
        console.print(f"[yellow]No sensors matching '{query}'.[/yellow]")
        return

    table = Table(title=f"Search: {query}", show_header=True)
    table.add_column("ID", style="cyan")
    table.add_column("Name")
    table.add_column("Category")
    table.add_column("Score", style="green")

    for r in results:
        table.add_row(r.sensor_id, r.sensor.name, r.sensor.category, f"{r.score:.3f}")

    console.print(table)


@sensor.command("categories")
@click.pass_context
def sensor_categories(ctx):
    """List sensor categories."""
    from embodied_ai_architect.sensors import SensorRegistry

    registry = SensorRegistry()
    cats = registry.categories()

    json_output = ctx.obj.get("json", False)
    if json_output:
        click.echo(json.dumps(cats, indent=2))
        return

    console.print("\n[bold]Sensor Categories[/bold]\n")
    for cat in cats:
        console.print(f"  {cat}")
    console.print(f"\n[dim]{len(cats)} categories available[/dim]")
