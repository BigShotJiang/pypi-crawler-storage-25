"""tmviz CLI entry-point.

  python -m tmviz make <match.csv> --home X --away Y [...flags]
                                              # one-shot, scriptable
  python -m tmviz wizard <match.csv>          # interactive prompts
  python -m tmviz render <config.yml>         # re-render a saved config
  python -m tmviz pages                       # list available pages
"""
from __future__ import annotations
import argparse
import sys

from .config import ReportConfig
from .cli import run_wizard
from .render import render_report
from .api import generate_report
from .pages import REGISTRY, PAGE_LABELS


def _build_make_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tmviz make",
        description="Generate a match report from a SPADL CSV (non-interactive).",
    )
    p.add_argument("csv", help="path to the SPADL event CSV")
    p.add_argument("--home", required=True, help="display name for the home team")
    p.add_argument("--away", required=True, help="display name for the away team")
    p.add_argument("--players-csv", default=None,
                   help="optional id->name lookup if main CSV has player_id only "
                        "(must have columns: player_id, player_name)")
    p.add_argument("--teams-csv", default=None,
                   help="optional id->name lookup if main CSV has team_id only "
                        "(must have columns: team_id, team_name)")
    p.add_argument("--home-id", type=int, default=None,
                   help="team_id of the home team (auto-detected if omitted)")
    p.add_argument("--away-id", type=int, default=None,
                   help="team_id of the away team (auto-detected if omitted)")
    p.add_argument("--matchday", type=int, default=None)
    p.add_argument("--date", default=None, help="match date, e.g. 2026-04-26")
    p.add_argument("--venue", default=None, help='stadium, e.g. "Craven Cottage"')
    p.add_argument("--competition", default="", help='e.g. "Premier League 25/26"')
    p.add_argument("--home-color", default=None,
                   help="hex color for home team accents, e.g. '#C8102E'")
    p.add_argument("--away-color", default=None, help="hex color for away team accents")
    p.add_argument("--home-crest", default=None, help="path to home crest image (optional)")
    p.add_argument("--away-crest", default=None, help="path to away crest image (optional)")
    p.add_argument("--own-goals", default="",
                   help='comma-separated minute(s) of any own-goals, e.g. "12,67"')
    p.add_argument("--pages", default=None,
                   help="comma-separated page names to include (default: all). "
                        "Use 'tmviz pages' to list.")
    p.add_argument("--out-dir", default="out/match_report",
                   help='output directory (default: "out/match_report")')
    p.add_argument("--page-width",  type=int, default=1600)
    p.add_argument("--page-height", type=int, default=1100)
    p.add_argument("--pdf-name", default=None, help="custom PDF filename")
    p.add_argument("--add-handle", action="store_true",
                   help="add @yureedelahi handle to every page (default off)")
    p.add_argument("--no-attribution", action="store_true",
                   help="hide the small 'generated with tmviz' line in the footer")
    p.add_argument("--theme", default="cream", help="theme name (default: cream)")
    return p


def _run_make(argv: list[str]) -> int:
    p = _build_make_parser()
    args = p.parse_args(argv)
    own = [int(x) for x in args.own_goals.split(",") if x.strip()] if args.own_goals else []
    pages = [s.strip() for s in args.pages.split(",")] if args.pages else None
    res = generate_report(
        csv=args.csv,
        players_csv=args.players_csv, teams_csv=args.teams_csv,
        home=args.home, away=args.away,
        home_team_id=args.home_id, away_team_id=args.away_id,
        competition=args.competition,
        matchday=args.matchday, date=args.date, venue=args.venue,
        home_color=args.home_color, away_color=args.away_color,
        home_crest=args.home_crest, away_crest=args.away_crest,
        own_goal_minutes=own, pages=pages,
        out_dir=args.out_dir,
        page_width=args.page_width, page_height=args.page_height,
        pdf_filename=args.pdf_name,
        show_handle=args.add_handle,
        show_attribution=not args.no_attribution,
        theme=args.theme,
    )
    print(f"\nRendered {len(res['png_paths'])} pages.")
    print(f"  PDF: {res['pdf_path']}")
    return 0


def cli_entry() -> int:
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help", "help"):
        print(__doc__)
        return 0
    cmd = sys.argv[1]

    if cmd == "make":
        return _run_make(sys.argv[2:])

    if cmd == "wizard":
        if len(sys.argv) < 3:
            print("Usage: python -m tmviz wizard <match.csv> [out.yml]")
            return 1
        csv = sys.argv[2]
        out = sys.argv[3] if len(sys.argv) > 3 else "out/match_report.yml"
        cfg = run_wizard(csv, out)
        ans = input("\nRender now? [Y/n]: ").strip().lower()
        if ans != "n":
            res = render_report(cfg)
            print(f"\nRendered {len(res['png_paths'])} pages.")
            print(f"  PDF: {res['pdf_path']}")
        return 0

    if cmd == "render":
        if len(sys.argv) < 3:
            print("Usage: python -m tmviz render <config.yml>")
            return 1
        cfg = ReportConfig.load(sys.argv[2])
        res = render_report(cfg)
        print(f"\nRendered {len(res['png_paths'])} pages.")
        print(f"  PDF: {res['pdf_path']}")
        for p in res["png_paths"]:
            print(f"  PNG: {p}")
        return 0

    if cmd == "pages":
        print("Registered pages:")
        for n in REGISTRY:
            print(f"  {n:<24}  {PAGE_LABELS.get(n, n)}")
        return 0

    print(f"Unknown command: {cmd}")
    print(__doc__)
    return 1


if __name__ == "__main__":
    raise SystemExit(cli_entry())
