"""tmviz — team-level match report generator from SPADL event data."""

__version__ = "0.1.0"

from .api import generate_report

__all__ = ["generate_report", "__version__"]
