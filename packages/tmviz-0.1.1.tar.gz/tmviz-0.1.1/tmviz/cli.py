"""Interactive wizard for tmviz.

  python -m tmviz wizard <match.csv>

Walks the user through:
  1. Confirming the two team_ids and giving them readable names
  2. Listing every detected goal and asking which (if any) are own-goals
  3. Optional metadata (competition, matchday, date, venue)
  4. Picking which pages to include in the report

Saves the resulting config as YAML so the same report can be re-rendered.
"""
from __future__ import annotations
from pathlib import Path

from .config import ReportConfig, TeamInfo, GoalInfo, MatchInfo, OutputConfig
from .data import load_match, detect_teams, detect_goals
from .pages import REGISTRY as PAGE_REGISTRY, PAGE_LABELS


def _ask(prompt: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default is not None else ""
    raw = input(f"  {prompt}{suffix}: ").strip()
    return raw if raw else (default or "")


def _ask_yn(prompt: str, default_no: bool = True) -> bool:
    d = "n" if default_no else "y"
    raw = input(f"  {prompt} [{'y/N' if default_no else 'Y/n'}]: ").strip().lower()
    if not raw: raw = d
    return raw == "y"


def run_wizard(csv_path: str, out_path: str | Path = "out/match_report.yml") -> ReportConfig:
    print()
    print("─" * 70)
    print(" tmviz wizard — build a match report")
    print("─" * 70)
    print(f"  Reading {csv_path}")
    # Peek at the columns without merging so we can prompt for lookups
    import pandas as pd
    head = pd.read_csv(csv_path, nrows=2, encoding="utf-8", encoding_errors="replace")
    players_csv = None
    teams_csv = None
    if "player_name" not in head.columns:
        print("  ⚠  Main CSV has no `player_name` column.")
        players_csv = _ask("Path to players CSV (cols: player_id, player_name)", "")
        players_csv = players_csv or None
    if "team_name" not in head.columns:
        ans = _ask_yn("Provide a teams_csv (id->name) for nicer team prompts? "
                      "Skip if you'll just type team names below", default_no=True)
        if ans:
            teams_csv = _ask("Path to teams CSV (cols: team_id, team_name)", "") or None
    df = load_match(csv_path, players_csv=players_csv, teams_csv=teams_csv)
    print(f"  Loaded {len(df):,} actions")

    # --- Teams ---
    print("\n[1/4] Teams")
    teams = detect_teams(df)
    if len(teams) < 2:
        raise ValueError("Match data should contain exactly 2 team_ids; found %d." % len(teams))
    home_id, _ = teams[0]
    away_id, _ = teams[1]
    # If we have a team_name column, use it as the default suggestion
    suggest_h = ""
    suggest_a = ""
    if "team_name" in df.columns:
        try:
            suggest_h = str(df.loc[df["team_id"] == home_id, "team_name"].dropna().iloc[0])
            suggest_a = str(df.loc[df["team_id"] == away_id, "team_name"].dropna().iloc[0])
        except (IndexError, KeyError):
            pass
    print(f"  Detected team_ids: {home_id} (most actions), {away_id}")
    home_name = _ask(f"Name for team_id {home_id} (HOME / will be shown attacking right)",
                     suggest_h or f"Team {home_id}")
    away_name = _ask(f"Name for team_id {away_id} (AWAY)",
                     suggest_a or f"Team {away_id}")

    # --- Goals + own-goal confirmation ---
    print("\n[2/4] Goals — flag any own-goals so the score is correct")
    goals_raw = detect_goals(df)
    if not goals_raw:
        print("  No goals detected.")
    own_goal_indexes: set[int] = set()
    for i, g in enumerate(goals_raw, 1):
        team_name = home_name if g["team_id"] == home_id else away_name
        opp_name  = away_name if g["team_id"] == home_id else home_name
        print(f"\n  Goal {i}/{len(goals_raw)}: {g['scorer']} @ {g['minute']}'  "
              f"(action by {team_name}, type={g['type_name']})")
        if _ask_yn(f"    Own goal? Credit this goal to {opp_name} instead", default_no=True):
            own_goal_indexes.add(i - 1)

    goals = [
        GoalInfo(
            minute=g["minute"], period=g["period"],
            time_seconds=g["time_seconds"], scorer=g["scorer"],
            team_id=g["team_id"], is_own_goal=(idx in own_goal_indexes),
        )
        for idx, g in enumerate(goals_raw)
    ]

    # --- Match meta ---
    print("\n[3/4] Match metadata — these show up in the page header strip")
    print("       (you can press Enter to skip any single field)")
    competition = _ask("Competition", "Premier League 25/26")
    matchday    = _ask("Matchday number (e.g. 35)", "")
    date        = _ask("Date (YYYY-MM-DD)", "")
    venue       = _ask("Venue / stadium", "")

    # --- Pages ---
    print("\n[4/4] Pages to include in the report")
    available = list(PAGE_REGISTRY.keys())
    print("  Available pages:")
    for i, name in enumerate(available, 1):
        marker = "*" if name in ("overview", "passing_home", "passing_away",
                                  "carries_home", "carries_away", "shots", "tables") else " "
        print(f"    {i:>2} {marker} {name:<16}  {PAGE_LABELS.get(name, name)}")
    print("  Default = all of them. Type a comma-separated list to subset, or Enter for all.")
    raw = input("  Your picks: ").strip()
    if raw:
        toks = [t.strip() for t in raw.replace(",", " ").split() if t.strip()]
        try:
            chosen = [available[int(t) - 1] for t in toks]
        except (ValueError, IndexError):
            chosen = [t for t in toks if t in available]
        if not chosen:
            chosen = available
    else:
        chosen = available

    out_dir = _ask("Output directory", "out")

    print("\n[5/5] Footer / branding")
    keep_attrib = _ask_yn("Keep small 'generated with tmviz' line in the footer?",
                          default_no=False)
    show_handle = _ask_yn("Add @yureedelahi handle to the corner of every page?",
                          default_no=True)

    cfg = ReportConfig(
        csv=str(Path(csv_path).resolve()),
        players_csv=str(Path(players_csv).resolve()) if players_csv else None,
        teams_csv=str(Path(teams_csv).resolve()) if teams_csv else None,
        home=TeamInfo(team_id=int(home_id), team_name=home_name),
        away=TeamInfo(team_id=int(away_id), team_name=away_name),
        match=MatchInfo(
            competition=competition,
            matchday=int(matchday) if matchday.isdigit() else None,
            date=date or None, venue=venue or None,
        ),
        goals=goals,
        pages=chosen,
        output=OutputConfig(
            out_dir=out_dir,
            show_handle=show_handle,
            show_attribution=keep_attrib,
        ),
    )
    cfg.save(out_path)
    print(f"\nSaved config to {out_path}")
    print(f"Render with: python -m tmviz render {out_path}")
    return cfg
