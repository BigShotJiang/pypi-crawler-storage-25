from .main import cli_entry

raise SystemExit(cli_entry())
