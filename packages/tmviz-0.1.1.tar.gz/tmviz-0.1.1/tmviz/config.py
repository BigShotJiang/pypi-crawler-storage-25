"""Match-report config (YAML-backed).

Captures everything the wizard collects so the same report can be
re-rendered later: match metadata, team naming, own-goal flags,
which optional pages to include, output paths.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import yaml


@dataclass
class TeamInfo:
    team_id: int
    team_name: str
    crest: Optional[str] = None        # path to PNG/SVG, optional
    color_primary: Optional[str] = None  # optional override (defaults from theme)


@dataclass
class GoalInfo:
    """One goal in the match. `is_own_goal` flips the credit from
    `team_id` (the team of the player who took the action) to the OTHER team."""
    minute: int
    period: int
    time_seconds: float
    scorer: str
    team_id: int                        # team of the player who took the shot
    is_own_goal: bool = False


@dataclass
class MatchInfo:
    competition: str = ""               # "Premier League 25/26"
    matchday: Optional[int] = None
    date: Optional[str] = None          # ISO date, optional
    venue: Optional[str] = None


@dataclass
class OutputConfig:
    out_dir: str = "out"
    page_width: int = 1600
    page_height: int = 1100
    pdf_filename: Optional[str] = None  # auto-generated if None
    show_handle: bool = False                # default: no twitter handle on pages
    show_attribution: bool = True            # default: keep "generated with tmviz" footer


@dataclass
class ReportConfig:
    csv: str
    home: TeamInfo                      # team attacking right on team-pages by default
    away: TeamInfo
    players_csv: Optional[str] = None   # optional id->name lookup for players
    teams_csv:   Optional[str] = None   # optional id->name lookup for teams
    match: MatchInfo = field(default_factory=MatchInfo)
    goals: list[GoalInfo] = field(default_factory=list)
    pages: list[str] = field(default_factory=lambda: [
        "overview",
        "passing_home", "passing_away",
        "network_home", "network_away",
        "players_pass_home", "players_pass_away",
        "carries_home", "carries_away",
        "players_carry_home", "players_carry_away",
        "defense_home", "defense_away",
        "players_defense_home", "players_defense_away",
        "shots",
        "flow",
        "tables",
    ])
    theme: str = "cream"
    output: OutputConfig = field(default_factory=OutputConfig)

    @classmethod
    def load(cls, path: str | Path) -> "ReportConfig":
        with open(path, encoding="utf-8") as f:
            raw = yaml.safe_load(f)
        return cls.from_dict(raw)

    @classmethod
    def from_dict(cls, raw: dict) -> "ReportConfig":
        return cls(
            csv=raw["csv"],
            home=TeamInfo(**raw["home"]),
            away=TeamInfo(**raw["away"]),
            players_csv=raw.get("players_csv"),
            teams_csv=raw.get("teams_csv"),
            match=MatchInfo(**raw.get("match", {})),
            goals=[GoalInfo(**g) for g in raw.get("goals", [])],
            pages=raw.get("pages", []) or [],
            theme=raw.get("theme", "cream"),
            output=OutputConfig(**raw.get("output", {})),
        )

    def save(self, path: str | Path) -> None:
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        d = {
            "csv": self.csv,
            "players_csv": self.players_csv,
            "teams_csv": self.teams_csv,
            "home": asdict(self.home),
            "away": asdict(self.away),
            "match": asdict(self.match),
            "goals": [asdict(g) for g in self.goals],
            "pages": list(self.pages),
            "theme": self.theme,
            "output": asdict(self.output),
        }
        def clean(o):
            if isinstance(o, dict): return {k: clean(v) for k, v in o.items() if v is not None}
            if isinstance(o, list): return [clean(x) for x in o]
            return o
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(clean(d), f, sort_keys=False, allow_unicode=True)

    def team_for(self, team_id: int) -> TeamInfo:
        if team_id == self.home.team_id: return self.home
        if team_id == self.away.team_id: return self.away
        raise ValueError(f"team_id {team_id} not in match")

    def opp_for(self, team_id: int) -> TeamInfo:
        return self.away if team_id == self.home.team_id else self.home

    def score(self) -> tuple[int, int]:
        """Return (home_goals, away_goals) honoring own-goal flips."""
        h, a = 0, 0
        for g in self.goals:
            if g.is_own_goal:
                # credit goes to the OTHER team
                if g.team_id == self.home.team_id: a += 1
                else:                              h += 1
            else:
                if g.team_id == self.home.team_id: h += 1
                else:                              a += 1
        return h, a
