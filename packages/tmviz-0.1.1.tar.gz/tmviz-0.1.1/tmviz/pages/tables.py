"""Top-performer tables — side-by-side per team across all categories."""
from __future__ import annotations

from .base import BasePage, DerivedData
from ..themes import get_theme


# (key, label) -- order matters; xg only added if data has it
CATEGORIES = [
    ("xt",                 "xT created"),
    ("passes",             "Passes completed"),
    ("prog_passes",        "Progressive passes"),
    ("passes_into_f3",     "Passes into final third"),
    ("passes_into_box",    "Passes into penalty box"),
    ("prog_carries",       "Progressive carries"),
    ("carries_into_f3",    "Carries into final third"),
    ("carries_into_box",   "Carries into penalty box"),
    ("take_ons_won",       "Take-ons won"),
    ("defensive_actions",  "Defensive actions"),
    ("shots",              "Shots"),
]


class TablesPage(BasePage):
    name = "tables"
    title = "Top performers"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        h_top = derived.home_top
        a_top = derived.away_top

        cats = list(CATEGORIES)
        if "xg" in h_top or "xg" in a_top:
            cats.append(("xg", "xG"))

        def fmt(val, key):
            if isinstance(val, float):
                return f"{val:.2f}" if key in ("xt","xg") else f"{val:.0f}"
            return f"{int(val)}"

        def render_table(title, top, color_class):
            rows = [t for t in top.get(title[0], [])]
            cells = []
            for i in range(5):
                if i < len(rows):
                    p, v = rows[i]
                    cells.append(
                        f'<div class="trow">'
                        f'<span class="rank {color_class}">{i+1}</span>'
                        f'<span class="player">{p}</span>'
                        f'<span class="val">{fmt(v, title[0])}</span>'
                        f'</div>'
                    )
                else:
                    cells.append(f'<div class="trow empty"><span class="rank">{i+1}</span><span class="player">—</span><span class="val">—</span></div>')
            return ''.join(cells)

        col_html = []
        for key, label in cats:
            col_html.append(f'''
<div class="cat">
  <div class="cat-title">{label}</div>
  <div class="cat-grid">
    <div class="cat-team">
      <div class="cat-team-name"><span class="swatch home"></span>{cfg.home.team_name}</div>
      {render_table((key, label), h_top, "home")}
    </div>
    <div class="cat-team">
      <div class="cat-team-name"><span class="swatch away"></span>{cfg.away.team_name}</div>
      {render_table((key, label), a_top, "away")}
    </div>
  </div>
</div>''')

        # 4 columns when there are 7+ categories so 11-12 cards fit in 3 rows.
        ncats = len(cats)
        cols  = 4 if ncats >= 7 else 3
        return f'''
<style>
  .tbody {{ flex: 1; min-height: 0; display: grid;
             grid-template-columns: repeat({cols}, 1fr);
             grid-auto-rows: 1fr; gap: 12px; }}
  .cat {{ background: var(--paper); border: 1px solid var(--hair);
           padding: 8px 10px; min-height: 0; overflow: hidden; }}
  .cat-title {{ font-family: 'Anton','Oswald',sans-serif; font-size: 15px;
                color: var(--ink); letter-spacing: -0.2px; padding-bottom: 6px;
                text-transform: uppercase;
                border-bottom: 2px solid var(--ink); }}
  .cat-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 10px; padding-top: 6px; }}
  .cat-team-name {{ font-family: 'Inter',sans-serif; font-weight: 800;
                     font-size: 9px; letter-spacing: 0.14em; text-transform: uppercase;
                     color: var(--ink-2); padding-bottom: 4px; margin-bottom: 3px;
                     border-bottom: 1px solid var(--hair); }}
  .cat-team-name .swatch {{ margin-right: 5px; vertical-align: middle; }}
  .trow {{ display: grid; grid-template-columns: 14px 1fr auto; gap: 4px;
           align-items: baseline; padding: 3px 0;
           border-bottom: 1px dotted var(--hair); }}
  .trow:last-child {{ border-bottom: none; }}
  .trow .rank {{ font-family: 'Anton','Oswald',sans-serif; font-size: 11px; color: var(--ink-2); }}
  .trow .rank.home {{ color: var(--home); }}
  .trow .rank.away {{ color: var(--away); }}
  .trow .player {{ font-size: 10px; font-weight: 600;
                    overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }}
  .trow .val {{ font-family: 'Anton','Oswald',sans-serif; font-size: 12px;
                font-variant-numeric: tabular-nums; }}
  .trow.empty {{ color: var(--ink-3); }}
</style>

<div class="tbody">
  {''.join(col_html)}
</div>
'''
