"""Base page class and the shared HTML page shell.

Each subclass implements `build(cfg, df, derived) -> str (inner HTML)`.
The shell wraps it with the standard top strip, footer, and styles.
"""
from __future__ import annotations
from dataclasses import dataclass

import pandas as pd

from ..themes import get_theme


@dataclass
class DerivedData:
    """Pre-computed per-team stats / top-performer tables."""
    home_stats: object        # TeamStats
    away_stats: object        # TeamStats
    home_top: dict            # category -> [(player, value), ...]
    away_top: dict


class BasePage:
    name: str = "page"
    title: str = "Page"

    def build(self, cfg, df: pd.DataFrame, derived: DerivedData) -> str:
        """Return the inner HTML for the page (no <html>, no <head>)."""
        raise NotImplementedError


def page_shell(cfg, inner_html: str, page_label: str, page_num: int, page_total: int) -> str:
    """Wrap a page's inner HTML with the standard shell (top strip, footer, styles)."""
    theme = get_theme(cfg.theme)()
    h, a = cfg.score()
    score_str = f"{cfg.home.team_name}  {h} – {a}  {cfg.away.team_name}"
    md = cfg.match
    sub_bits = []
    if md.competition: sub_bits.append(md.competition)
    if md.matchday is not None: sub_bits.append(f"Matchday {md.matchday}")
    if md.date: sub_bits.append(str(md.date))
    if md.venue: sub_bits.append(md.venue)
    sub_strip = " · ".join(str(s) for s in sub_bits)

    show_handle = cfg.output.show_handle
    show_attribution = cfg.output.show_attribution
    handle_html_top = f'<span class="handle">@yureedelahi</span>' if show_handle else ''
    handle_html_bottom = f'<div class="right">@yureedelahi</div>' if show_handle else '<div></div>'
    attribution_html = ('<div>generated with tmviz · github.com/yureed/tmviz</div>'
                        if show_attribution else '<div></div>')

    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"/>
<title>{score_str} — tmviz · {page_label}</title>
{theme.google_fonts_link}
<style>
  :root {{
    --paper: {theme.paper}; --paper-2: {theme.paper_2};
    --ink: {theme.ink}; --ink-2: {theme.ink_2}; --ink-3: {theme.ink_3};
    --hair: {theme.hairline}; --hair-2: {theme.hairline2};
    --red: {theme.red}; --gold: {theme.gold}; --blue: {theme.blue};
    --home: {cfg.home.color_primary or theme.home_color};
    --away: {cfg.away.color_primary or theme.away_color};
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: 'Inter', system-ui, sans-serif; background: var(--paper); color: var(--ink);
         -webkit-font-smoothing: antialiased; }}
  .page {{
    width: {cfg.output.page_width}px; height: {cfg.output.page_height}px;
    margin: 0 auto; background:
      radial-gradient(circle at 22% 18%, rgba(27,24,20,0.022) 0 0.6px, transparent 1px),
      radial-gradient(circle at 78% 62%, rgba(27,24,20,0.022) 0 0.6px, transparent 1px),
      var(--paper);
    background-size: 11px 11px, 9px 9px, auto;
    padding: 28px 44px 56px 44px;
    display: flex; flex-direction: column; overflow: hidden;
  }}
  .topstrip {{
    display: flex; justify-content: space-between; align-items: center;
    font-family: 'Inter',sans-serif; font-size: 11px; font-weight: 700;
    letter-spacing: 0.22em; text-transform: uppercase; color: var(--ink-2);
    border-bottom: 1px solid var(--hair); padding-bottom: 10px;
  }}
  .topstrip .left {{ display: flex; gap: 12px; align-items: center; }}
  .topstrip .left .red-mark {{ display: inline-block; width: 8px; height: 8px; background: var(--red); }}
  .topstrip .right {{ display: flex; gap: 14px; align-items: center; }}
  .topstrip .pageno {{ color: var(--ink); font-weight: 800; font-variant-numeric: tabular-nums; }}
  .topstrip .handle {{ color: var(--red); font-weight: 800; }}

  .header {{
    display: flex; justify-content: space-between; align-items: flex-end;
    margin-top: 12px;
  }}
  .header .scorebar {{
    display: flex; align-items: baseline; gap: 14px;
    font-family: 'Anton','Oswald',sans-serif; font-size: 36px; line-height: 1;
    color: var(--ink); letter-spacing: -0.5px;
  }}
  .header .scorebar .sep {{ color: var(--ink-3); margin: 0 4px; }}
  .header .scorebar .score {{
    font-size: 42px; padding: 0 12px;
    background: var(--ink); color: var(--paper); border-radius: 4px;
    font-variant-numeric: tabular-nums;
  }}
  .header .pagetitle {{
    font-family: 'Inter',sans-serif; font-size: 12px; font-weight: 800;
    color: var(--ink-2); letter-spacing: 0.20em; text-transform: uppercase;
  }}

  .content {{ flex: 1; min-height: 0; margin-top: 18px;
              display: flex; flex-direction: column;
              padding-bottom: 18px; overflow: hidden; }}

  .footer {{ margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--hair);
             display: flex; justify-content: space-between;
             font-family: 'Inter',sans-serif; font-size: 10px; color: var(--ink-3);
             letter-spacing: 0.18em; text-transform: uppercase; }}
  .footer .right {{ color: var(--red); font-weight: 800; }}

  /* Re-usable building blocks */
  .panel-title {{
    font-family: 'Inter',sans-serif; font-weight: 800; font-size: 11px;
    color: var(--ink-2); letter-spacing: 0.20em; text-transform: uppercase;
    padding-bottom: 6px;
  }}
  .panel-body {{ background: var(--paper-2); border: 1px solid var(--hair-2); }}
  .panel-body svg {{ display: block; width: 100%; height: 100%; }}

  /* Team color swatch dot used in multiple pages */
  .swatch {{ display: inline-block; width: 10px; height: 10px; border-radius: 50%; }}
  .swatch.home {{ background: var(--home); }}
  .swatch.away {{ background: var(--away); }}
</style></head>
<body>
<div class="page">
  <div class="topstrip">
    <div class="left">
      <span class="red-mark"></span>
      <span>tmviz · match report{f' · {sub_strip}' if sub_strip else ''}</span>
    </div>
    <div class="right">
      <span class="pageno">{page_num:02d} / {page_total:02d}</span>
      {handle_html_top}
    </div>
  </div>

  <div class="header">
    <div class="scorebar">
      <span>{cfg.home.team_name}</span>
      <span class="score">{h} – {a}</span>
      <span>{cfg.away.team_name}</span>
    </div>
    <div class="pagetitle">{page_label}</div>
  </div>

  <div class="content">
    {inner_html}
  </div>

  <div class="footer">
    {attribution_html}
    {handle_html_bottom}
  </div>
</div>
</body></html>
'''
