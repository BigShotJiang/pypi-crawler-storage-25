"""Match flow — momentum graph (Sofascore-style).

Per-minute "danger" signal per team: xG of any shot in that minute,
plus xT_added of any successful pass / cross / dribble. Subtract
away from home, smooth with a rolling 5-minute window, and render
as a signed area chart oscillating around zero (above = home on top,
below = away on top). Goal markers placed on the curve.

Signal source preference: xG if the data has it, else xT.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .base import BasePage, DerivedData
from ..components import svg_wrap
from ..themes import get_theme


CHART_W = 1300
CHART_H = 580
LEFT_PAD = 60
RIGHT_PAD = 30
TOP_PAD = 36
BOT_PAD = 40
ROLL_WINDOW = 5            # minute window for smoothing


class FlowPage(BasePage):
    name = "flow"
    title = "Match flow"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        home_color = cfg.home.color_primary or theme.home_color
        away_color = cfg.away.color_primary or theme.away_color

        df = df.copy()
        df["minute"] = (df["period_id"] - 1) * 45 + df["time_seconds"] / 60
        max_minute = max(int(np.ceil(df["minute"].max())) + 1, 95)

        xg_col = "xG" if "xG" in df.columns else ("xg" if "xg" in df.columns else None)
        signal_label = "xG" if xg_col else "xT"

        # Per-event danger: shot-xG when present + non-shot xT (so build-up
        # passes also count, not just the final ball). xT-only as fallback.
        if xg_col is not None:
            shot_mask = df["type_name"].astype(str).str.startswith("shot")
            df["danger"] = df[xg_col].where(shot_mask, 0).fillna(0).astype(float)
            df["danger"] = df["danger"] + df["xT_added"].clip(lower=0).fillna(0)
        else:
            df["danger"] = df["xT_added"].clip(lower=0).fillna(0)

        bins = np.arange(0, max_minute + 2)
        def per_minute(team_id):
            sub = df[df["team_id"] == team_id]
            return np.histogram(sub["minute"], bins=bins, weights=sub["danger"])[0]

        h_per = per_minute(cfg.home.team_id)
        a_per = per_minute(cfg.away.team_id)
        diff = h_per - a_per

        kernel = np.ones(ROLL_WINDOW) / ROLL_WINDOW
        smoothed = np.convolve(diff, kernel, mode="same")
        mins = (bins[:-1] + 0.5)
        peak = max(abs(smoothed.min()), abs(smoothed.max()), 0.05) * 1.10

        plot_w = CHART_W - LEFT_PAD - RIGHT_PAD
        plot_h = CHART_H - TOP_PAD - BOT_PAD
        zero_y = TOP_PAD + plot_h / 2
        def x(m): return LEFT_PAD + (m / max_minute) * plot_w
        def y(v): return zero_y - (v / peak) * (plot_h / 2)

        parts = [f'<rect x="0" y="0" width="{CHART_W}" height="{CHART_H}" fill="{theme.paper}"/>']

        for m in range(0, max_minute + 1, 15):
            xx = x(m)
            parts.append(f'<line x1="{xx:.1f}" y1="{TOP_PAD}" x2="{xx:.1f}" y2="{TOP_PAD+plot_h}" '
                         f'stroke="{theme.hairline}" stroke-width="0.4" opacity="0.4"/>')
            parts.append(f'<text x="{xx:.1f}" y="{TOP_PAD+plot_h+18}" text-anchor="middle" '
                         f'font-family="Inter,sans-serif" font-size="10" fill="{theme.ink_3}">{m}\'</text>')

        parts.append(f'<line x1="{x(45):.1f}" y1="{TOP_PAD}" x2="{x(45):.1f}" y2="{TOP_PAD+plot_h}" '
                     f'stroke="{theme.ink_3}" stroke-width="1" stroke-dasharray="3 3"/>')
        parts.append(f'<text x="{x(45):.1f}" y="{TOP_PAD-8}" text-anchor="middle" '
                     f'font-family="Inter,sans-serif" font-size="9" font-weight="800" '
                     f'fill="{theme.ink_3}" letter-spacing="0.16em">HT</text>')

        parts.append(f'<line x1="{LEFT_PAD}" y1="{zero_y:.1f}" x2="{LEFT_PAD+plot_w}" y2="{zero_y:.1f}" '
                     f'stroke="{theme.ink_2}" stroke-width="1.2"/>')

        parts.append(f'<text x="{LEFT_PAD-12}" y="{TOP_PAD+12:.1f}" text-anchor="end" '
                     f'font-family="Inter,sans-serif" font-size="10" font-weight="800" '
                     f'fill="{home_color}" letter-spacing="0.18em">{cfg.home.team_name.upper()} ↑</text>')
        parts.append(f'<text x="{LEFT_PAD-12}" y="{TOP_PAD+plot_h-4:.1f}" text-anchor="end" '
                     f'font-family="Inter,sans-serif" font-size="10" font-weight="800" '
                     f'fill="{away_color}" letter-spacing="0.18em">{cfg.away.team_name.upper()} ↓</text>')

        def build_area(values_signed, color, side: str):
            """side='up' clips to positive values (home), 'down' to negative (away)."""
            pts = []
            for m, v in zip(mins, values_signed):
                clipped = max(v, 0) if side == "up" else min(v, 0)
                pts.append((x(m), y(clipped)))
            if not pts: return ""
            d = f"M {pts[0][0]:.1f} {zero_y:.1f} "
            d += " ".join(f"L {px:.1f} {py:.1f}" for px, py in pts)
            d += f" L {pts[-1][0]:.1f} {zero_y:.1f} Z"
            return (f'<path d="{d}" fill="{color}" fill-opacity="0.55"/>'
                    f'<path d="{" ".join(("M" if i==0 else "L") + f" {px:.1f} {py:.1f}" for i,(px,py) in enumerate(pts))}" '
                    f'fill="none" stroke="{color}" stroke-width="1.4"/>')

        parts.append(build_area(smoothed, home_color, "up"))
        parts.append(build_area(smoothed, away_color, "down"))

        for g in cfg.goals:
            credited_home = (g.team_id == cfg.home.team_id) ^ g.is_own_goal
            color = home_color if credited_home else away_color
            cx = x(g.minute)
            parts.append(f'<line x1="{cx:.1f}" y1="{TOP_PAD}" x2="{cx:.1f}" y2="{TOP_PAD+plot_h}" '
                         f'stroke="{color}" stroke-width="1" stroke-dasharray="2 2" opacity="0.5"/>')
            parts.append(f'<circle cx="{cx:.1f}" cy="{zero_y:.1f}" r="6.5" '
                         f'fill="{color}" stroke="{theme.paper}" stroke-width="2"/>')
            parts.append(f'<circle cx="{cx:.1f}" cy="{zero_y:.1f}" r="2" fill="{theme.paper}"/>')
            label_y = zero_y - 14 if credited_home else zero_y + 22
            anchor = "middle"
            parts.append(f'<text x="{cx:.1f}" y="{label_y:.1f}" text-anchor="{anchor}" '
                         f'font-family="Anton,Oswald,sans-serif" font-size="11" '
                         f'fill="{theme.ink}">{g.minute}\' {_short(g.scorer)}{" (OG)" if g.is_own_goal else ""}</text>')

        parts.append(f'<text x="14" y="{(TOP_PAD+plot_h/2):.1f}" '
                     f'font-family="Inter,sans-serif" font-size="11" font-weight="800" '
                     f'fill="{theme.ink_2}" letter-spacing="0.18em" '
                     f'transform="rotate(-90, 14, {(TOP_PAD+plot_h/2):.1f})">MOMENTUM ({signal_label}, {ROLL_WINDOW}-MIN ROLL)</text>')

        chart_svg = svg_wrap(parts, CHART_W, CHART_H)

        def period_total(team_id, period_id):
            sub = df[(df["team_id"] == team_id) & (df["period_id"] == period_id)]
            return round(float(sub["danger"].sum()), 2)
        h1 = period_total(cfg.home.team_id, 1); h2 = period_total(cfg.home.team_id, 2)
        a1 = period_total(cfg.away.team_id, 1); a2 = period_total(cfg.away.team_id, 2)

        return f'''
<style>
  .fbody {{ display: flex; flex-direction: column; gap: 14px; flex: 1; min-height: 0; }}
  .chart-wrap {{ display: flex; flex-direction: column; }}
  .chart-wrap .panel-body {{ height: {CHART_H+8}px; }}
  .legend {{ margin-top: 8px; display: flex; gap: 18px;
             font-family: 'Inter',sans-serif; font-size: 10px; font-weight: 700;
             letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-2); }}
  .legend .swatch {{ vertical-align: middle; margin-right: 6px; }}
  .sumrow {{ display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }}
  .team-box {{ padding: 12px; background: var(--paper); border: 1px solid var(--hair); }}
  .team-box h3 {{ font-family: 'Inter',sans-serif; font-weight: 800; font-size: 11px;
                   color: var(--ink-2); letter-spacing: 0.18em; text-transform: uppercase;
                   padding-bottom: 8px; border-bottom: 1px solid var(--hair); margin-bottom: 6px; }}
  .team-box h3 .swatch {{ vertical-align: middle; margin-right: 8px; }}
  .grid {{ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; }}
  .grid .num {{ font-family: 'Anton','Oswald',sans-serif; font-size: 26px;
                color: var(--ink); line-height: 1; }}
  .grid .lbl {{ font-size: 10px; font-weight: 700;
                letter-spacing: 0.16em; text-transform: uppercase; color: var(--ink-2);
                margin-top: 4px; }}
</style>

<div class="fbody">
  <div class="chart-wrap">
    <div class="panel-title">Match flow — momentum ({signal_label}-based, {ROLL_WINDOW}-min rolling)</div>
    <div class="panel-body">{chart_svg}</div>
    <div class="legend">
      <span><span class="swatch home"></span>{cfg.home.team_name} (above zero)</span>
      <span><span class="swatch away"></span>{cfg.away.team_name} (below zero)</span>
      <span style="margin-left:auto; color: var(--ink-3)">SIGNAL = {signal_label.upper()} PER MINUTE · GOALS ON ZERO LINE</span>
    </div>
  </div>
  <div class="sumrow">
    <div class="team-box">
      <h3><span class="swatch home"></span>{cfg.home.team_name.upper()}</h3>
      <div class="grid">
        <div><div class="num">{h1:.2f}</div><div class="lbl">{signal_label} 1H</div></div>
        <div><div class="num">{h2:.2f}</div><div class="lbl">{signal_label} 2H</div></div>
        <div><div class="num">{(h1+h2):.2f}</div><div class="lbl">{signal_label} total</div></div>
      </div>
    </div>
    <div class="team-box">
      <h3><span class="swatch away"></span>{cfg.away.team_name.upper()}</h3>
      <div class="grid">
        <div><div class="num">{a1:.2f}</div><div class="lbl">{signal_label} 1H</div></div>
        <div><div class="num">{a2:.2f}</div><div class="lbl">{signal_label} 2H</div></div>
        <div><div class="num">{(a1+a2):.2f}</div><div class="lbl">{signal_label} total</div></div>
      </div>
    </div>
  </div>
</div>
'''


def _short(name: str) -> str:
    bits = name.split()
    if len(bits) == 1: return name
    return f"{bits[0][0]}.{bits[-1]}"
