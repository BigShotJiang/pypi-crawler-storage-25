"""Page registry. Each page exports build(cfg, df, derived) -> str (HTML).

Pages can be requested by name in cfg.pages. Per-team pages take a
`side` param (`home` or `away`) baked into the page key.
"""
from .base import BasePage, page_shell
from .overview import OverviewPage
from .passing import PassingPage
from .carries import CarriesPage
from .shots import ShotsPage
from .tables import TablesPage
from .network import NetworkPage
from .defense import DefensePage
from .flow import FlowPage
from .players_grid import PlayersPassGrid, PlayersCarryGrid, PlayersDefenseGrid

REGISTRY = {
    "overview":               OverviewPage,
    "passing_home":           lambda: PassingPage(side="home"),
    "passing_away":           lambda: PassingPage(side="away"),
    "network_home":           lambda: NetworkPage(side="home"),
    "network_away":           lambda: NetworkPage(side="away"),
    "players_pass_home":      lambda: PlayersPassGrid(side="home"),
    "players_pass_away":      lambda: PlayersPassGrid(side="away"),
    "carries_home":           lambda: CarriesPage(side="home"),
    "carries_away":           lambda: CarriesPage(side="away"),
    "players_carry_home":     lambda: PlayersCarryGrid(side="home"),
    "players_carry_away":     lambda: PlayersCarryGrid(side="away"),
    "defense_home":           lambda: DefensePage(side="home"),
    "defense_away":           lambda: DefensePage(side="away"),
    "players_defense_home":   lambda: PlayersDefenseGrid(side="home"),
    "players_defense_away":   lambda: PlayersDefenseGrid(side="away"),
    "shots":                  ShotsPage,
    "flow":                   FlowPage,
    "tables":                 TablesPage,
}


def get_page(name: str):
    if name not in REGISTRY:
        raise ValueError(f"Unknown page '{name}'. Available: {list(REGISTRY)}")
    factory = REGISTRY[name]
    return factory()


PAGE_LABELS = {
    "overview":             "Overview",
    "passing_home":         "Passing — home",
    "passing_away":         "Passing — away",
    "network_home":         "Pass network — home",
    "network_away":         "Pass network — away",
    "players_pass_home":    "Individual pass maps — home",
    "players_pass_away":    "Individual pass maps — away",
    "carries_home":         "Carries & take-ons — home",
    "carries_away":         "Carries & take-ons — away",
    "players_carry_home":   "Individual carry maps — home",
    "players_carry_away":   "Individual carry maps — away",
    "defense_home":         "Defensive activity — home",
    "defense_away":         "Defensive activity — away",
    "players_defense_home": "Individual defensive duels — home",
    "players_defense_away": "Individual defensive duels — away",
    "shots":                "Shot map",
    "flow":                 "Match flow",
    "tables":               "Top performers",
}
