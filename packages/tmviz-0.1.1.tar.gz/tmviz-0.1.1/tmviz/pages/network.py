"""Per-team pass network.

  - Nodes at each player's average action position
  - Node radius proportional to passes attempted
  - Edges = successful passes player A -> player B
  - Edge thickness proportional to combination count
  - Top 14 outfield players by pass count are shown
"""
from __future__ import annotations

import pandas as pd

from .base import BasePage, DerivedData
from ..components import pitch_full, svg_wrap, attack_caption
from ..themes import get_theme


class NetworkPage(BasePage):
    name = "network"

    def __init__(self, side: str = "home"):
        self.side = side
        self.title = f"Pass network · {side}"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        team = cfg.home if self.side == "home" else cfg.away
        accent = theme.home_color if self.side == "home" else theme.away_color
        accent_var = "var(--home)" if self.side == "home" else "var(--away)"

        # SPADL stores each team's events in their own attacking direction —
        # no flip needed for per-team pages.
        t = df[df["team_id"] == team.team_id].copy().reset_index(drop=True)

        # Receiver = next event by same player (any same-team next event).
        succ = t[(t["type_name"].isin(["pass","cross"])) & (t["result_name"] == "success")]
        edges: dict[tuple[str, str], int] = {}
        for idx in succ.index:
            if idx + 1 >= len(t): continue
            nxt = t.iloc[idx + 1]
            passer = succ.loc[idx, "player_name"]
            receiver = nxt["player_name"]
            if pd.isna(passer) or pd.isna(receiver) or passer == receiver:
                continue
            key = (str(passer), str(receiver))
            edges[key] = edges.get(key, 0) + 1

        passes_attempted = t[t["type_name"].isin(["pass","cross"])].groupby("player_name").size()
        avg = t[t["type_name"].isin(["pass","cross","dribble","take_on","shot"])].groupby("player_name")[["start_x","start_y"]].mean()

        # Prefer real starting-XI metadata if a players_csv with `is_starter`
        # was provided; fall back to top 11 by passes attempted otherwise.
        if "is_starter" in t.columns and t["is_starter"].any():
            starters = (t[t["is_starter"] == True]["player_name"]
                        .dropna().drop_duplicates().tolist())
            top_players = [p for p in starters if p in passes_attempted.index]
            picker_label = "starting XI"
        else:
            top_players = passes_attempted.sort_values(ascending=False).head(11).index.tolist()
            picker_label = "top 11 by passes attempted"
        top_set = set(top_players)
        edges = {k: v for k, v in edges.items() if k[0] in top_set and k[1] in top_set}

        PW, PH = 1280, 800
        parts, x, y = pitch_full(PW, PH, theme)

        if not top_players:
            parts.append(f'<text x="{PW/2}" y="{PH/2}" text-anchor="middle" '
                         f'font-family="Inter,sans-serif" font-size="14" fill="{theme.ink_3}">'
                         f'no passing data</text>')
            return self._wrap(cfg, theme, team, accent_var, svg_wrap(parts, PW, PH),
                              len(top_players), len(edges), len(succ), PH,
                              picker_label=picker_label)

        # Draw edges first so node circles render on top.
        max_edge = max(edges.values()) if edges else 1
        for (a, b), count in edges.items():
            if a not in avg.index or b not in avg.index: continue
            ax, ay = avg.loc[a, "start_x"], avg.loc[a, "start_y"]
            bx, by = avg.loc[b, "start_x"], avg.loc[b, "start_y"]
            x1, y1, x2, y2 = x(ax), y(ay), x(bx), y(by)
            w_line = 0.6 + (count / max_edge) * 4.5
            opa = 0.20 + (count / max_edge) * 0.55
            parts.append(
                f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                f'stroke="{theme.ink}" stroke-width="{w_line:.2f}" opacity="{opa:.2f}" '
                f'stroke-linecap="round"/>'
            )

        # Per-player jersey number lookup (only if the players_csv supplied one).
        jersey_by_player = {}
        if "jersey_number" in t.columns:
            j = t.dropna(subset=["jersey_number"]).drop_duplicates("player_name")
            jersey_by_player = dict(zip(j["player_name"], j["jersey_number"]))

        # Render in three z-ordered passes so labels never sit behind a node:
        #   1. all circles
        #   2. inside-circle jersey numbers
        #   3. below-circle full names (top layer)
        max_pass = passes_attempted.loc[top_players].max() if len(top_players) else 1
        node_geom = []   # (player, cx, cy, r) — reused across passes
        for player in top_players:
            if player not in avg.index: continue
            ax, ay = avg.loc[player, "start_x"], avg.loc[player, "start_y"]
            cx, cy = x(ax), y(ay)
            n = passes_attempted.get(player, 0)
            r = 9 + (n / max_pass) * 16
            node_geom.append((player, cx, cy, r))

        # Pass 1: circles
        for player, cx, cy, r in node_geom:
            parts.append(
                f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r:.1f}" '
                f'fill="{accent}" '
                f'stroke="{theme.paper}" stroke-width="1.6"/>'
            )
        # Pass 2: jersey numbers (inside circles)
        for player, cx, cy, r in node_geom:
            jersey = jersey_by_player.get(player)
            if jersey is None: continue
            try: jersey = str(int(float(jersey)))
            except (TypeError, ValueError): jersey = str(jersey)
            parts.append(
                f'<text x="{cx:.1f}" y="{cy+1:.1f}" text-anchor="middle" '
                f'dominant-baseline="middle" font-family="Anton,Oswald,sans-serif" '
                f'font-size="13" fill="{theme.paper}" '
                f'letter-spacing="-0.5px">{jersey}</text>'
            )
        # Pass 3: full names (top layer, drawn last so they sit above every node)
        for player, cx, cy, r in node_geom:
            parts.append(
                f'<text x="{cx:.1f}" y="{cy + r + 12:.1f}" text-anchor="middle" '
                f'font-family="Inter,sans-serif" font-size="10" font-weight="700" '
                f'fill="{theme.ink}" stroke="{theme.paper}" stroke-width="2.4" '
                f'stroke-linejoin="round" paint-order="stroke" '
                f'letter-spacing="0.04em">{player}</text>'
            )

        attack_caption(parts, PW, PH, theme,
                       prefix=f"{team.team_name.upper()} ATTACK", side="right")
        pitch_svg = svg_wrap(parts, PW, PH)

        combos = sorted(edges.items(), key=lambda kv: -kv[1])[:8]
        combo_html = []
        for i, ((a, b), n) in enumerate(combos, 1):
            combo_html.append(
                f'<div class="trow"><span class="rank">{i}</span>'
                f'<span class="player">{a}</span><span class="arr">→</span>'
                f'<span class="player">{b}</span>'
                f'<span class="val">{n}</span></div>'
            )
        if not combo_html:
            combo_html.append('<div class="trow empty">No combinations</div>')

        return self._wrap(cfg, theme, team, accent_var, pitch_svg,
                          len(top_players), len(edges), len(succ), PH,
                          combo_html=''.join(combo_html),
                          picker_label=picker_label)

    @staticmethod
    def _wrap(cfg, theme, team, accent_var, pitch_svg,
              n_players, n_edges, n_succ_passes, PH, combo_html: str = "",
              picker_label: str = "top 11 by passes attempted"):
        return f'''
<style>
  .nbody {{ display: grid; grid-template-columns: 3fr 1fr; gap: 16px; flex: 1; min-height: 0; }}
  .nbody .pitch-wrap {{ display: flex; flex-direction: column; }}
  .legend {{ margin-top: 8px; display: flex; gap: 16px;
             font-family: 'Inter',sans-serif; font-size: 10px; font-weight: 700;
             letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-2); }}
  .legend .stripe {{ display: inline-block; width: 24px; height: 3px; vertical-align: middle; margin-right: 6px; background: var(--ink); }}
  .legend .dot {{ display: inline-block; width: 12px; height: 12px; border-radius: 50%;
                   vertical-align: middle; margin-right: 6px; background: {accent_var}; }}
  .side .meta {{ padding: 10px; background: var(--paper); border: 1px solid var(--hair); }}
  .side .meta-row {{ display: flex; justify-content: space-between; padding: 4px 0;
                      font-size: 11px; }}
  .side .meta-row .lbl {{ font-weight: 700; letter-spacing: 0.10em;
                            text-transform: uppercase; color: var(--ink-2); }}
  .side .meta-row .num {{ font-family: 'Anton','Oswald',sans-serif; font-size: 16px; }}
  .side .top {{ margin-top: 12px; padding: 10px; background: var(--paper); border: 1px solid var(--hair); }}
  .side .top h4 {{ font-family: 'Inter',sans-serif; font-weight: 800;
                   font-size: 11px; letter-spacing: 0.20em;
                   text-transform: uppercase; color: var(--ink-2); padding-bottom: 8px; }}
  .trow {{ display: grid; grid-template-columns: 18px 1fr 14px 1fr auto; gap: 4px;
           align-items: baseline; padding: 5px 0; border-bottom: 1px solid var(--hair); }}
  .trow:last-child {{ border-bottom: none; }}
  .trow .rank {{ font-family: 'Anton','Oswald',sans-serif; font-size: 13px; color: {accent_var}; }}
  .trow .player {{ font-size: 11px; font-weight: 600; overflow: hidden;
                    text-overflow: ellipsis; white-space: nowrap; }}
  .trow .arr {{ text-align: center; color: var(--ink-3); font-weight: 700; }}
  .trow .val {{ font-family: 'Anton','Oswald',sans-serif; font-size: 14px; font-variant-numeric: tabular-nums; }}
  .trow.empty {{ color: var(--ink-3); }}
</style>

<div class="nbody">
  <div class="pitch-wrap">
    <div class="panel-title">{team.team_name.upper()} -- pass network ({picker_label})</div>
    <div class="panel-body" style="height: {PH+8}px;">{pitch_svg}</div>
    <div class="legend">
      <span><span class="dot"></span>NODE = AVG POSITION (size = passes)</span>
      <span><span class="stripe"></span>EDGE WIDTH = COMBINATION COUNT</span>
      <span style="margin-left:auto; color: var(--ink-3)">{n_succ_passes} successful passes between {n_players} players</span>
    </div>
  </div>
  <div class="side">
    <div class="meta">
      <div class="meta-row"><span class="lbl">Players</span><span class="num">{n_players}</span></div>
      <div class="meta-row"><span class="lbl">Combinations</span><span class="num">{n_edges}</span></div>
      <div class="meta-row"><span class="lbl">Successful passes</span><span class="num">{n_succ_passes}</span></div>
    </div>
    <div class="top">
      <h4>Top combinations</h4>
      {combo_html}
    </div>
  </div>
</div>
'''


def _short(name: str) -> str:
    bits = name.split()
    if not bits: return name
    if len(bits) == 1: return bits[0][:8]
    return f"{bits[0][0]}.{bits[-1]}"[:9]
