"""Overview page — match summary + key stats + goals + tiny shot map."""
from __future__ import annotations

from .base import BasePage, DerivedData
from ..components import pitch_full, svg_wrap, attack_caption
from ..themes import get_theme


class OverviewPage(BasePage):
    name = "overview"
    title = "Overview"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        h_stats = derived.home_stats
        a_stats = derived.away_stats

        goals_html = []
        for g in sorted(cfg.goals, key=lambda x: (x.period, x.time_seconds)):
            credited_to = cfg.opp_for(g.team_id) if g.is_own_goal else cfg.team_for(g.team_id)
            side_class = "home" if credited_to.team_id == cfg.home.team_id else "away"
            label = f"{g.scorer} ({g.minute}')"
            if g.is_own_goal: label += " (OG)"
            goals_html.append(
                f'<div class="goal-row goal-{side_class}">'
                f'<span class="goal-min">{g.minute}\'</span>'
                f'<span class="goal-name">{g.scorer}{" (OG)" if g.is_own_goal else ""}</span>'
                f'<span class="goal-side">{credited_to.team_name}</span>'
                f'</div>'
            )
        if not goals_html:
            goals_html.append('<div class="goal-row goal-empty">No goals</div>')

        def stat_row(label, h_val, a_val, fmt="{}"):
            try:
                h_num = float(h_val); a_num = float(a_val)
                tot = h_num + a_num
                h_share = h_num / tot if tot > 0 else 0.5
            except Exception:
                h_share = 0.5
            return (
                f'<div class="srow">'
                f'  <span class="sval h">{fmt.format(h_val)}</span>'
                f'  <span class="slabel">{label}</span>'
                f'  <span class="sval a">{fmt.format(a_val)}</span>'
                f'  <div class="sbar">'
                f'    <div class="sbar-h" style="width: {h_share*100:.1f}%"></div>'
                f'    <div class="sbar-a" style="width: {(1-h_share)*100:.1f}%"></div>'
                f'  </div>'
                f'</div>'
            )

        stat_rows = [
            stat_row("Possession %",       h_stats.possession_pct, a_stats.possession_pct, "{:.1f}%"),
            stat_row("Shots",              h_stats.shots,          a_stats.shots),
            stat_row("Shots on target",    h_stats.shots_on_target,a_stats.shots_on_target),
        ]
        if h_stats.has_xg:
            stat_rows.append(stat_row("Expected goals (xG)",
                                      h_stats.xg_for, a_stats.xg_for, "{:.2f}"))
        stat_rows.extend([
            stat_row("Open-play xT",       h_stats.xt_open_play,   a_stats.xt_open_play, "{:.2f}"),
            stat_row("Pass completion %",  h_stats.pass_pct,       a_stats.pass_pct, "{:.1f}%"),
            stat_row("Progressive passes", h_stats.progressive_passes, a_stats.progressive_passes),
            stat_row("Progressive carries",h_stats.progressive_carries, a_stats.progressive_carries),
            stat_row("Take-ons (won/att)",
                     f"{h_stats.take_ons_won}/{h_stats.take_ons_attempted}",
                     f"{a_stats.take_ons_won}/{a_stats.take_ons_attempted}"),
            stat_row("Box entries",        h_stats.box_entries,    a_stats.box_entries),
            stat_row("Defensive actions",  h_stats.defensive_actions, a_stats.defensive_actions),
        ])

        SHOT_W, SHOT_H = 760, 460
        parts, x, y = pitch_full(SHOT_W, SHOT_H, theme)
        shots = df[df["type_name"].isin(["shot","shot_freekick","shot_penalty"])]
        for _, r in shots.iterrows():
            is_home = (r["team_id"] == cfg.home.team_id)
            color = "var(--home)" if is_home else "var(--away)"
            # Home attacks right, Away attacks left — flip away coords
            sx_v = r["start_x"] if is_home else (100 - r["start_x"])
            sy_v = r["start_y"] if is_home else (100 - r["start_y"])
            cx, cy = x(sx_v), y(sy_v)
            r_size = 4.0
            if "xG" in df.columns or "xg" in df.columns:
                xg_col = "xG" if "xG" in df.columns else "xg"
                xg = float(r.get(xg_col, 0) or 0)
                r_size = 4.0 + min(max(xg, 0), 1.0) * 5.0
            fill = color if r.get("is_goal", False) else "none"
            parts.append(
                f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r_size:.1f}" '
                f'fill="{fill}" fill-opacity="0.75" '
                f'stroke="{color}" stroke-width="1.4"/>'
            )
        shot_svg = svg_wrap(parts, SHOT_W, SHOT_H)

        return f'''
<style>
  .ovbody {{ display: grid; grid-template-columns: 1.4fr 1fr; gap: 16px; flex: 1; min-height: 0; }}
  .ovleft, .ovright {{ display: flex; flex-direction: column; gap: 12px; }}

  .stats-card .srow {{
    position: relative; display: grid;
    grid-template-columns: 1fr 1.2fr 1fr;
    gap: 10px; align-items: baseline;
    padding: 9px 4px 12px 4px;
    border-bottom: 1px solid var(--hair);
  }}
  .stats-card .srow:last-child {{ border-bottom: none; }}
  .sval {{ font-family: 'Anton','Oswald',sans-serif; font-size: 18px;
            color: var(--ink); font-variant-numeric: tabular-nums; }}
  .sval.h {{ text-align: left; color: var(--home); }}
  .sval.a {{ text-align: right; color: var(--away); }}
  .slabel {{ text-align: center; font-size: 10px; font-weight: 700;
             letter-spacing: 0.18em; text-transform: uppercase; color: var(--ink-2); }}
  .sbar {{ position: absolute; left: 4px; right: 4px; bottom: 4px; height: 3px;
           display: flex; gap: 2px; }}
  .sbar-h {{ background: var(--home); height: 100%; }}
  .sbar-a {{ background: var(--away); height: 100%; }}

  .goals-card {{ padding: 10px 12px 12px; }}
  .goals-card h3 {{ font-family: 'Inter',sans-serif; font-weight: 800;
                    font-size: 11px; color: var(--ink-2);
                    letter-spacing: 0.20em; text-transform: uppercase; padding-bottom: 8px; }}
  .goal-row {{ display: grid; grid-template-columns: 44px 1fr auto;
               align-items: baseline; gap: 8px; padding: 5px 0;
               border-bottom: 1px solid var(--hair); }}
  .goal-row:last-child {{ border-bottom: none; }}
  .goal-min {{ font-family: 'Anton','Oswald',sans-serif; font-size: 16px; color: var(--ink); }}
  .goal-name {{ font-size: 13px; font-weight: 600; color: var(--ink); }}
  .goal-side {{ font-size: 10px; font-weight: 800; letter-spacing: 0.16em;
                text-transform: uppercase; }}
  .goal-row.goal-home .goal-side {{ color: var(--home); }}
  .goal-row.goal-away .goal-side {{ color: var(--away); }}
  .goal-empty {{ font-size: 12px; color: var(--ink-3); padding: 8px 0; }}

  .shots-card {{ flex: 1; display: flex; flex-direction: column; }}
  .shots-card .panel-body {{ flex: 1; }}
  .legend-row {{ margin-top: 8px; display: flex; gap: 18px;
                 font-size: 10px; font-weight: 700; letter-spacing: 0.16em;
                 text-transform: uppercase; color: var(--ink-2); }}
  .legend-row .swatch {{ margin-right: 6px; }}
  .legend-row .filled {{ display: inline-block; width: 10px; height: 10px;
                          border: 1.4px solid var(--ink-2); border-radius: 50%; margin-right: 4px; }}
  .legend-row .filled.solid {{ background: var(--ink-2); }}
  .dir-row {{ display: flex; justify-content: space-between; align-items: center;
              padding: 6px 4px 0 4px;
              font-family: 'Inter',sans-serif; font-size: 10px; font-weight: 800;
              letter-spacing: 0.18em; text-transform: uppercase; color: var(--ink-2); }}
</style>

<div class="ovbody">
  <div class="ovleft">
    <div class="shots-card">
      <div class="panel-title">Shots — both teams</div>
      <div class="panel-body" style="height: {SHOT_H+8}px;">{shot_svg}</div>
      <div class="dir-row">
        <span class="dir-left">← {cfg.away.team_name.upper()} ATTACKS</span>
        <span class="dir-right">{cfg.home.team_name.upper()} ATTACKS →</span>
      </div>
      <div class="legend-row">
        <span><span class="swatch home"></span>{cfg.home.team_name}</span>
        <span><span class="swatch away"></span>{cfg.away.team_name}</span>
        <span><span class="filled"></span>SHOT</span>
        <span><span class="filled solid"></span>GOAL</span>
        <span style="margin-left:auto; color: var(--ink-3)">{"CIRCLE SIZE = xG" if h_stats.has_xg else "FIXED-SIZE CIRCLES"}</span>
      </div>
    </div>
  </div>
  <div class="ovright">
    <div class="goals-card panel-body" style="background: var(--paper);">
      <h3>Goals</h3>
      {''.join(goals_html)}
    </div>
    <div class="stats-card panel-body" style="background: var(--paper); padding: 6px 12px 8px; flex:1;">
      <div class="panel-title" style="padding: 6px 0 4px;">
        <span class="swatch home"></span> {cfg.home.team_name.upper()}
        &nbsp;·&nbsp;
        {cfg.away.team_name.upper()} <span class="swatch away"></span>
      </div>
      {''.join(stat_rows)}
    </div>
  </div>
</div>
'''
