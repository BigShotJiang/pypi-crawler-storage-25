"""Per-team defensive activity page.

  - Heatmap (binned) of defensive actions across the pitch
  - Distinct markers overlaid for tackles / intercepts / clearances
  - Side panel: per-player defensive-action counts (top 8) + summary
"""
from __future__ import annotations

import numpy as np

from .base import BasePage, DerivedData
from ..components import pitch_full, svg_wrap, attack_caption, PW_DATA, PH_DATA
from ..themes import get_theme


DEF_TYPES = ("tackle", "interception", "clearance")


class DefensePage(BasePage):
    name = "defense"

    def __init__(self, side: str = "home"):
        self.side = side
        self.title = f"Defensive activity · {side}"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        team = cfg.home if self.side == "home" else cfg.away
        opp  = cfg.away if self.side == "home" else cfg.home
        accent_var = "var(--home)" if self.side == "home" else "var(--away)"

        t = df[df["team_id"] == team.team_id].copy()

        def_acts = t[t["type_name"].isin(DEF_TYPES)]
        # Opponent passes per defensive action (simple PPDA-style intensity)
        opp_passes = df[(df["team_id"] == opp.team_id) & (df["type_name"] == "pass")]
        ppda = round(len(opp_passes) / max(len(def_acts), 1), 1) if len(def_acts) else float("nan")

        PW, PH = 1280, 800
        parts, x, y = pitch_full(PW, PH, theme)

        # Heatmap underneath (binned 12x8 cells, accent-colored)
        if len(def_acts):
            grid, _, _ = np.histogram2d(
                def_acts["start_x"].clip(0, 100),
                def_acts["start_y"].clip(0, 100),
                bins=[12, 8], range=[[0, 100], [0, 100]],
            )
            max_v = grid.max()
            cell_w_data = 100 / 12
            cell_h_data = 100 / 8
            cells = []
            for ix in range(12):
                for iy in range(8):
                    v = grid[ix, iy]
                    if v <= 0: continue
                    op = (v / max_v) ** 0.65 * 0.50
                    px1 = x(ix * cell_w_data)
                    py1 = y((iy + 1) * cell_h_data)
                    px2 = x((ix + 1) * cell_w_data)
                    py2 = y(iy * cell_h_data)
                    cells.append(
                        f'<rect x="{px1:.1f}" y="{py1:.1f}" '
                        f'width="{px2-px1:.1f}" height="{py2-py1:.1f}" '
                        f'fill="{accent_var}" opacity="{op:.3f}"/>'
                    )
            # Insert heatmap cells after background rect, under pitch lines
            parts[1:1] = cells

        # Markers per type
        type_styles = {
            "tackle":       (theme.ink,  "circle"),
            "interception": (theme.red,  "diamond"),
            "clearance":    (theme.gold, "triangle"),
        }
        for tname, (color, shape) in type_styles.items():
            sub = def_acts[def_acts["type_name"] == tname]
            for _, r in sub.iterrows():
                cx, cy = x(r["start_x"]), y(r["start_y"])
                if shape == "circle":
                    parts.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3.4" '
                                 f'fill="{color}" stroke="{theme.paper}" stroke-width="0.9" opacity="0.92"/>')
                elif shape == "diamond":
                    parts.append(f'<rect x="{cx-3:.1f}" y="{cy-3:.1f}" width="6" height="6" '
                                 f'transform="rotate(45 {cx:.1f} {cy:.1f})" '
                                 f'fill="{color}" stroke="{theme.paper}" stroke-width="0.9" opacity="0.92"/>')
                else:
                    pts = f"{cx:.1f},{cy-4:.1f} {cx-3.6:.1f},{cy+3:.1f} {cx+3.6:.1f},{cy+3:.1f}"
                    parts.append(f'<polygon points="{pts}" fill="{color}" '
                                 f'stroke="{theme.paper}" stroke-width="0.9" opacity="0.92"/>')

        attack_caption(parts, PW, PH, theme,
                       prefix=f"{team.team_name.upper()} ATTACK", side="right")
        pitch_svg = svg_wrap(parts, PW, PH)

        # Per-player counts (top 8)
        per_p = (t[t["type_name"].isin(DEF_TYPES)]
                 .groupby("player_name").size()
                 .sort_values(ascending=False).head(8))
        rows = []
        for i, (player, n) in enumerate(per_p.items(), 1):
            rows.append(
                f'<div class="trow"><span class="rank">{i}</span>'
                f'<span class="player">{player}</span>'
                f'<span class="val">{int(n)}</span></div>'
            )
        if not rows:
            rows.append('<div class="trow empty">No defensive actions</div>')

        n_t = int((def_acts["type_name"] == "tackle").sum())
        n_i = int((def_acts["type_name"] == "interception").sum())
        n_c = int((def_acts["type_name"] == "clearance").sum())
        ppda_html = "—" if not (ppda == ppda) else f"{ppda:.1f}"

        return f'''
<style>
  .dbody {{ display: grid; grid-template-columns: 3fr 1fr; gap: 16px; flex: 1; min-height: 0; }}
  .dbody .pitch-wrap {{ display: flex; flex-direction: column; }}
  .legend {{ margin-top: 8px; display: flex; gap: 16px;
             font-family: 'Inter',sans-serif; font-size: 10px; font-weight: 700;
             letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-2); }}
  .legend .marker {{ display: inline-block; width: 12px; height: 12px;
                      vertical-align: middle; margin-right: 6px; }}
  .legend .marker.tackle {{ background: var(--ink); border-radius: 50%; }}
  .legend .marker.intercept {{ background: var(--red); transform: rotate(45deg); }}
  .legend .marker.clear {{ width: 0; height: 0; border-left: 6px solid transparent;
                            border-right: 6px solid transparent;
                            border-bottom: 10px solid var(--gold); margin-right: 6px; }}
  .side .stat-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
                       padding: 10px; border: 1px solid var(--hair-2); background: var(--paper-2); }}
  .side .stat-grid .num {{ font-family: 'Anton','Oswald',sans-serif; font-size: 26px;
                            color: var(--ink); line-height: 1; }}
  .side .stat-grid .lbl {{ font-size: 10px; font-weight: 700;
                            letter-spacing: 0.16em; text-transform: uppercase; color: var(--ink-2);
                            margin-top: 4px; }}
  .side .top {{ margin-top: 12px; padding: 10px; background: var(--paper); border: 1px solid var(--hair); }}
  .side .top h4 {{ font-family: 'Inter',sans-serif; font-weight: 800;
                   font-size: 11px; letter-spacing: 0.20em;
                   text-transform: uppercase; color: var(--ink-2); padding-bottom: 8px; }}
  .trow {{ display: grid; grid-template-columns: 24px 1fr auto; gap: 8px;
           align-items: baseline; padding: 5px 0; border-bottom: 1px solid var(--hair); }}
  .trow:last-child {{ border-bottom: none; }}
  .trow .rank {{ font-family: 'Anton','Oswald',sans-serif; font-size: 14px; color: {accent_var}; }}
  .trow .player {{ font-size: 12px; font-weight: 700; }}
  .trow .val {{ font-family: 'Anton','Oswald',sans-serif; font-size: 16px; font-variant-numeric: tabular-nums; }}
  .trow.empty {{ color: var(--ink-3); }}
</style>

<div class="dbody">
  <div class="pitch-wrap">
    <div class="panel-title">{team.team_name.upper()} — defensive activity (heatmap + actions)</div>
    <div class="panel-body" style="height: {PH+8}px;">{pitch_svg}</div>
    <div class="legend">
      <span><span class="marker tackle"></span>TACKLE</span>
      <span><span class="marker intercept"></span>INTERCEPTION</span>
      <span><span class="marker clear"></span>CLEARANCE</span>
      <span style="margin-left:auto; color: var(--ink-3)">{len(def_acts)} defensive actions total</span>
    </div>
  </div>
  <div class="side">
    <div class="stat-grid">
      <div class="cell"><div class="num">{n_t}</div><div class="lbl">Tackles</div></div>
      <div class="cell"><div class="num">{n_i}</div><div class="lbl">Intercepts</div></div>
      <div class="cell"><div class="num">{n_c}</div><div class="lbl">Clearances</div></div>
      <div class="cell"><div class="num">{ppda_html}</div><div class="lbl">Opp passes / def act (PPDA)</div></div>
    </div>
    <div class="top">
      <h4>Top defensive workers</h4>
      {''.join(rows)}
    </div>
  </div>
</div>
'''
