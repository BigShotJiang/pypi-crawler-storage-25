"""Per-team passing page. Full-pitch landscape, attacking right.

Successful pass = thin ink line. Forward (end_x > start_x) is darker;
backward is lighter. Failed = red dotted. Progressive passes = gold,
heavier, with arrowhead.

Side panel: top 5 progressive passers with counts.
"""
from __future__ import annotations

from .base import BasePage, DerivedData
from ..components import pitch_full, svg_wrap, attack_caption
from ..themes import get_theme


class PassingPage(BasePage):
    name = "passing"

    def __init__(self, side: str = "home"):
        self.side = side
        self.title = f"Passing · {side}"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        team = cfg.home if self.side == "home" else cfg.away
        opp  = cfg.away if self.side == "home" else cfg.home
        stats = derived.home_stats if self.side == "home" else derived.away_stats
        top   = derived.home_top   if self.side == "home" else derived.away_top
        accent_var = "var(--home)" if self.side == "home" else "var(--away)"

        PW, PH = 1280, 800
        parts, x, y = pitch_full(PW, PH, theme)

        parts.insert(0,
            '<defs>'
            f'<marker id="pa_p" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">'
            f'<path d="M0,0 L6,3 L0,6 z" fill="{theme.gold}"/></marker>'
            '</defs>'
        )

        # SPADL stores each team's events in their own attacking direction
        # (low x = own goal). Both teams' raw coords already attack right
        # on a per-team page — no flip needed.
        t = df[df["team_id"] == team.team_id].copy()

        # Drop kick-off passes (start at centre spot)
        is_kickoff = (t["start_x"].between(48, 52)) & (t["start_y"].between(48, 52))
        t = t[~is_kickoff]

        passes = t[t["type_name"].isin(["pass","cross"])]
        succ = passes[passes["result_name"] == "success"]
        fail = passes[passes["result_name"] != "success"]

        # Failed (faintest, drawn first)
        for _, r in fail.iterrows():
            x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
            parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                         f'stroke="{theme.red}" stroke-width="0.7" opacity="0.35" '
                         f'stroke-dasharray="2 2"/>')

        # Successful non-prog
        non_prog = succ[succ.get("is_progressive", False) == False]
        for _, r in non_prog.iterrows():
            x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
            forward = (r["end_x"] - r["start_x"]) >= 0
            color = theme.ink if forward else theme.ink_3
            parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                         f'stroke="{color}" stroke-width="0.9" opacity="0.55"/>')

        # Progressive (gold, heavier, on top)
        prog = succ[succ.get("is_progressive", False) == True]
        for _, r in prog.iterrows():
            x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
            parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                         f'stroke="{theme.gold}" stroke-width="1.8" opacity="0.92" '
                         f'stroke-linecap="round" marker-end="url(#pa_p)"/>')
            parts.append(f'<circle cx="{x1:.1f}" cy="{y1:.1f}" r="2.0" fill="{theme.gold}"/>')

        attack_caption(parts, PW, PH, theme,
                       prefix=f"{team.team_name.upper()} ATTACK", side="right")
        pitch_svg = svg_wrap(parts, PW, PH)

        # Top-5 panel
        top_html = []
        for i, (player, val) in enumerate(top.get("prog_passes", []), 1):
            top_html.append(
                f'<div class="trow">'
                f'<span class="rank">{i}</span>'
                f'<span class="player">{player}</span>'
                f'<span class="val">{int(val)}</span>'
                f'</div>'
            )
        if not top_html:
            top_html.append('<div class="trow empty">No progressive passes recorded</div>')

        return f'''
<style>
  .pbody {{ display: grid; grid-template-columns: 3fr 1fr; gap: 16px; flex: 1; min-height: 0; }}
  .pbody .pitch-wrap {{ display: flex; flex-direction: column; }}
  .pbody .pitch-wrap .panel-body {{ flex: 1; }}

  .legend {{
    margin-top: 8px; display: flex; gap: 16px;
    font-family: 'Inter',sans-serif; font-size: 10px; font-weight: 700;
    letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-2);
  }}
  .legend .stripe {{ display: inline-block; width: 24px; height: 3px; vertical-align: middle; margin-right: 6px; }}
  .legend .stripe.gold {{ background: var(--gold); height: 3px; }}
  .legend .stripe.ink {{ background: var(--ink); height: 1.5px; }}
  .legend .stripe.ink3 {{ background: var(--ink-3); height: 1.5px; }}
  .legend .stripe.fail {{ background: repeating-linear-gradient(90deg, var(--red), var(--red) 3px, transparent 3px, transparent 6px); height: 1.5px; opacity: 0.7; }}

  .side .stat-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
                       padding: 10px; border: 1px solid var(--hair-2); background: var(--paper-2); }}
  .side .stat-grid .cell {{ }}
  .side .stat-grid .num {{ font-family: 'Anton','Oswald',sans-serif; font-size: 26px;
                            color: var(--ink); line-height: 1; }}
  .side .stat-grid .lbl {{ font-size: 10px; font-weight: 700;
                            letter-spacing: 0.16em; text-transform: uppercase; color: var(--ink-2);
                            margin-top: 4px; }}
  .side .top {{ margin-top: 12px; padding: 10px; background: var(--paper); border: 1px solid var(--hair); }}
  .side .top h4 {{ font-family: 'Inter',sans-serif; font-weight: 800;
                   font-size: 11px; letter-spacing: 0.20em;
                   text-transform: uppercase; color: var(--ink-2); padding-bottom: 8px; }}
  .trow {{ display: grid; grid-template-columns: 24px 1fr auto; gap: 8px;
           align-items: baseline; padding: 5px 0;
           border-bottom: 1px solid var(--hair); }}
  .trow:last-child {{ border-bottom: none; }}
  .trow .rank {{ font-family: 'Anton','Oswald',sans-serif; font-size: 14px;
                  color: {accent_var}; }}
  .trow .player {{ font-size: 12px; font-weight: 700; }}
  .trow .val {{ font-family: 'Anton','Oswald',sans-serif; font-size: 16px; font-variant-numeric: tabular-nums; }}
  .trow.empty {{ color: var(--ink-3); }}
</style>

<div class="pbody">
  <div class="pitch-wrap">
    <div class="panel-title">{team.team_name.upper()} — open-play passes (progressive highlighted)</div>
    <div class="panel-body" style="height: {PH+8}px;">{pitch_svg}</div>
    <div class="legend">
      <span><span class="stripe gold"></span>PROGRESSIVE PASS</span>
      <span><span class="stripe ink"></span>FORWARD</span>
      <span><span class="stripe ink3"></span>BACKWARD</span>
      <span><span class="stripe fail"></span>FAILED</span>
      <span style="margin-left:auto; color: var(--ink-3)">{len(prog)} of {len(succ)} successful passes were progressive</span>
    </div>
  </div>
  <div class="side">
    <div class="stat-grid">
      <div class="cell"><div class="num">{stats.passes_completed}/{stats.passes_attempted}</div><div class="lbl">Passes</div></div>
      <div class="cell"><div class="num">{stats.pass_pct:.1f}%</div><div class="lbl">Completion</div></div>
      <div class="cell"><div class="num">{stats.progressive_passes}</div><div class="lbl">Prog passes</div></div>
      <div class="cell"><div class="num">{stats.box_entries}</div><div class="lbl">Box entries</div></div>
      <div class="cell"><div class="num">{stats.xt_open_play:.2f}</div><div class="lbl">Open-play xT</div></div>
      <div class="cell"><div class="num">{stats.possession_pct:.1f}%</div><div class="lbl">Possession</div></div>
    </div>
    <div class="top">
      <h4>Top progressive passers</h4>
      {''.join(top_html)}
    </div>
  </div>
</div>
'''
