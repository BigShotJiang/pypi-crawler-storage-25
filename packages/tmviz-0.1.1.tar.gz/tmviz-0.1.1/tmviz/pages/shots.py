"""Both-teams shot map page.

Single horizontal pitch with home team attacking right, away attacking
left. Stat strip below with shots / on target / goals / xG (if avail)
per team.
"""
from __future__ import annotations

from .base import BasePage, DerivedData
from ..components import pitch_full, svg_wrap
from ..themes import get_theme


class ShotsPage(BasePage):
    name = "shots"
    title = "Shots — both teams"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        h_stats = derived.home_stats
        a_stats = derived.away_stats

        PW, PH = 1280, 760
        parts, x, y = pitch_full(PW, PH, theme)

        shots = df[df["type_name"].isin(["shot","shot_freekick","shot_penalty"])]
        xg_col = "xG" if "xG" in df.columns else ("xg" if "xg" in df.columns else None)

        for _, r in shots.iterrows():
            is_home = (r["team_id"] == cfg.home.team_id)
            color_var = "var(--home)" if is_home else "var(--away)"
            sx_v = r["start_x"] if is_home else (100 - r["start_x"])
            sy_v = r["start_y"] if is_home else (100 - r["start_y"])
            cx, cy = x(sx_v), y(sy_v)
            r_size = 6.0
            if xg_col is not None:
                xg = float(r.get(xg_col, 0) or 0)
                r_size = 5.0 + min(max(xg, 0), 1.0) * 12.0
            is_goal = bool(r.get("is_goal", False))
            fill_op = 0.85 if is_goal else 0.0
            stroke_w = 2.0 if is_goal else 1.4
            parts.append(
                f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r_size:.1f}" '
                f'fill="{color_var}" fill-opacity="{fill_op}" '
                f'stroke="{color_var}" stroke-width="{stroke_w}"/>'
            )
            if is_goal:
                parts.append(
                    f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="{r_size+4:.1f}" '
                    f'fill="none" stroke="{theme.gold}" stroke-width="1.6" opacity="0.85"/>'
                )

        pitch_svg = svg_wrap(parts, PW, PH)

        def stat_block(stats, color_class, name):
            xg_html = ""
            if stats.has_xg:
                xg_html = f'<div class="cell"><div class="num">{stats.xg_for:.2f}</div><div class="lbl">xG</div></div>'
            return f'''
<div class="team-box {color_class}">
  <div class="team-name"><span class="swatch {color_class}"></span>{name}</div>
  <div class="stat-grid">
    <div class="cell"><div class="num">{stats.shots}</div><div class="lbl">Shots</div></div>
    <div class="cell"><div class="num">{stats.shots_on_target}</div><div class="lbl">On target</div></div>
    <div class="cell"><div class="num">{stats.goals_for}</div><div class="lbl">Goals</div></div>
    {xg_html}
    <div class="cell"><div class="num">{(stats.goals_for / stats.shots * 100) if stats.shots else 0:.0f}%</div><div class="lbl">Conversion</div></div>
  </div>
</div>'''

        size_caption = "CIRCLE SIZE = xG" if h_stats.has_xg else "FIXED-SIZE CIRCLES"
        return f'''
<style>
  .sbody {{ display: flex; flex-direction: column; gap: 14px; flex: 1; min-height: 0; }}
  .sbody .pitch-wrap {{ display: flex; flex-direction: column; }}
  .sbody .pitch-wrap .panel-body {{ height: {PH+8}px; }}
  .legend {{ margin-top: 8px; display: flex; gap: 16px;
             font-family: 'Inter',sans-serif; font-size: 10px; font-weight: 700;
             letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-2); }}
  .legend .filled {{ display: inline-block; width: 12px; height: 12px;
                      border: 1.6px solid var(--ink-2); border-radius: 50%; margin-right: 6px;
                      vertical-align: middle; }}
  .legend .filled.solid {{ background: var(--ink-2); }}
  .legend .halo {{ display: inline-block; width: 12px; height: 12px;
                    border-radius: 50%; margin-right: 6px; vertical-align: middle;
                    background: var(--ink-2); box-shadow: 0 0 0 2px var(--gold);
                    margin-left: 4px; }}
  .dir-row {{ display: flex; justify-content: space-between; align-items: center;
              padding: 6px 4px 0 4px;
              font-family: 'Inter',sans-serif; font-size: 11px; font-weight: 800;
              letter-spacing: 0.18em; text-transform: uppercase; color: var(--ink-2); }}
  .stat-row {{ display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }}
  .team-box {{ padding: 12px; background: var(--paper); border: 1px solid var(--hair); }}
  .team-name {{ font-family: 'Inter',sans-serif; font-weight: 800; font-size: 12px;
                color: var(--ink); letter-spacing: 0.18em; text-transform: uppercase;
                padding-bottom: 8px; margin-bottom: 6px; border-bottom: 1px solid var(--hair); }}
  .team-name .swatch {{ margin-right: 8px; }}
  .stat-grid {{ display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; }}
  .stat-grid .cell {{ }}
  .stat-grid .num {{ font-family: 'Anton','Oswald',sans-serif; font-size: 24px;
                      color: var(--ink); line-height: 1; }}
  .stat-grid .lbl {{ font-size: 9.5px; font-weight: 700;
                      letter-spacing: 0.16em; text-transform: uppercase; color: var(--ink-2);
                      margin-top: 4px; }}
</style>

<div class="sbody">
  <div class="pitch-wrap">
    <div class="panel-title">Shot map — both teams</div>
    <div class="panel-body">{pitch_svg}</div>
    <div class="dir-row">
      <span class="dir-left">← {cfg.away.team_name.upper()} ATTACKS</span>
      <span class="dir-right">{cfg.home.team_name.upper()} ATTACKS →</span>
    </div>
    <div class="legend">
      <span><span class="filled"></span>SHOT</span>
      <span><span class="filled solid"></span>GOAL</span>
      <span style="margin-left:auto">{size_caption}</span>
    </div>
  </div>
  <div class="stat-row">
    {stat_block(h_stats, "home", cfg.home.team_name)}
    {stat_block(a_stats, "away", cfg.away.team_name)}
  </div>
</div>
'''
