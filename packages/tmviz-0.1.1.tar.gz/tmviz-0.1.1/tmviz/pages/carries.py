"""Per-team carries + take-ons page."""
from __future__ import annotations

from .base import BasePage, DerivedData
from ..components import pitch_full, svg_wrap, attack_caption
from ..themes import get_theme


class CarriesPage(BasePage):
    name = "carries"

    def __init__(self, side: str = "home"):
        self.side = side
        self.title = f"Carries · {side}"

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        team = cfg.home if self.side == "home" else cfg.away
        stats = derived.home_stats if self.side == "home" else derived.away_stats
        top   = derived.home_top   if self.side == "home" else derived.away_top
        accent_var = "var(--home)" if self.side == "home" else "var(--away)"

        PW, PH = 1280, 800
        parts, x, y = pitch_full(PW, PH, theme)

        parts.insert(0,
            '<defs>'
            f'<marker id="cm_p" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">'
            f'<path d="M0,0 L6,3 L0,6 z" fill="{theme.gold}"/></marker>'
            f'<marker id="cm_n" markerWidth="6" markerHeight="6" refX="5" refY="3" orient="auto" markerUnits="strokeWidth">'
            f'<path d="M0,0 L6,3 L0,6 z" fill="{theme.ink_2}"/></marker>'
            '</defs>'
        )

        t = df[df["team_id"] == team.team_id].copy()

        carries = t[t["type_name"] == "dribble"]
        non_prog = carries[carries.get("is_carry_prog", False) == False]
        prog = carries[carries.get("is_carry_prog", False) == True]
        for _, r in non_prog.iterrows():
            x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
            parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                         f'stroke="{theme.ink_2}" stroke-width="0.9" opacity="0.55" '
                         f'marker-end="url(#cm_n)"/>')
        for _, r in prog.iterrows():
            x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
            parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                         f'stroke="{theme.gold}" stroke-width="1.8" opacity="0.95" '
                         f'stroke-linecap="round" marker-end="url(#cm_p)"/>')
            parts.append(f'<circle cx="{x1:.1f}" cy="{y1:.1f}" r="2.0" fill="{theme.gold}"/>')

        tos = t[t["type_name"] == "take_on"]
        for _, r in tos.iterrows():
            cx, cy = x(r["start_x"]), y(r["start_y"])
            won = (r["result_name"] == "success")
            parts.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="3.4" '
                         f'fill="{theme.ink if won else theme.red}" '
                         f'stroke="{theme.paper}" stroke-width="0.9" opacity="0.92"/>')

        attack_caption(parts, PW, PH, theme,
                       prefix=f"{team.team_name.upper()} ATTACK", side="right")
        pitch_svg = svg_wrap(parts, PW, PH)

        prog_html = []
        for i, (player, val) in enumerate(top.get("prog_carries", []), 1):
            prog_html.append(
                f'<div class="trow"><span class="rank">{i}</span>'
                f'<span class="player">{player}</span>'
                f'<span class="val">{int(val)}</span></div>'
            )
        if not prog_html:
            prog_html.append('<div class="trow empty">None</div>')

        to_html = []
        for i, (player, val) in enumerate(top.get("take_ons_won", []), 1):
            to_html.append(
                f'<div class="trow"><span class="rank">{i}</span>'
                f'<span class="player">{player}</span>'
                f'<span class="val">{int(val)}</span></div>'
            )
        if not to_html:
            to_html.append('<div class="trow empty">None</div>')

        return f'''
<style>
  .cbody {{ display: grid; grid-template-columns: 3fr 1fr; gap: 16px; flex: 1; min-height: 0; }}
  .cbody .pitch-wrap {{ display: flex; flex-direction: column; }}
  .legend {{ margin-top: 8px; display: flex; gap: 16px;
             font-family: 'Inter',sans-serif; font-size: 10px; font-weight: 700;
             letter-spacing: 0.14em; text-transform: uppercase; color: var(--ink-2); }}
  .legend .stripe {{ display: inline-block; width: 24px; height: 3px; vertical-align: middle; margin-right: 6px; }}
  .legend .stripe.gold {{ background: var(--gold); }}
  .legend .stripe.ink2 {{ background: var(--ink-2); height: 1.5px; }}
  .legend .dot {{ display: inline-block; width: 10px; height: 10px; border-radius: 50%;
                   vertical-align: middle; margin-right: 6px; }}
  .legend .dot.win {{ background: var(--ink); }}
  .legend .dot.lose {{ background: var(--red); }}

  .side .stat-grid {{ display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
                       padding: 10px; border: 1px solid var(--hair-2); background: var(--paper-2); }}
  .side .stat-grid .num {{ font-family: 'Anton','Oswald',sans-serif; font-size: 26px;
                            color: var(--ink); line-height: 1; }}
  .side .stat-grid .lbl {{ font-size: 10px; font-weight: 700;
                            letter-spacing: 0.16em; text-transform: uppercase; color: var(--ink-2);
                            margin-top: 4px; }}
  .side .top {{ margin-top: 12px; padding: 10px; background: var(--paper); border: 1px solid var(--hair); }}
  .side .top h4 {{ font-family: 'Inter',sans-serif; font-weight: 800;
                   font-size: 11px; letter-spacing: 0.20em;
                   text-transform: uppercase; color: var(--ink-2); padding-bottom: 8px; }}
  .trow {{ display: grid; grid-template-columns: 24px 1fr auto; gap: 8px;
           align-items: baseline; padding: 5px 0;
           border-bottom: 1px solid var(--hair); }}
  .trow:last-child {{ border-bottom: none; }}
  .trow .rank {{ font-family: 'Anton','Oswald',sans-serif; font-size: 14px;
                  color: {accent_var}; }}
  .trow .player {{ font-size: 12px; font-weight: 700; }}
  .trow .val {{ font-family: 'Anton','Oswald',sans-serif; font-size: 16px; font-variant-numeric: tabular-nums; }}
  .trow.empty {{ color: var(--ink-3); }}
</style>

<div class="cbody">
  <div class="pitch-wrap">
    <div class="panel-title">{team.team_name.upper()} — carries (progressive highlighted) + take-ons</div>
    <div class="panel-body" style="height: {PH+8}px;">{pitch_svg}</div>
    <div class="legend">
      <span><span class="stripe gold"></span>PROGRESSIVE CARRY</span>
      <span><span class="stripe ink2"></span>OTHER CARRY</span>
      <span><span class="dot win"></span>TAKE-ON WON</span>
      <span><span class="dot lose"></span>TAKE-ON LOST</span>
      <span style="margin-left:auto; color: var(--ink-3)">{len(prog)} of {len(carries)} carries were progressive</span>
    </div>
  </div>
  <div class="side">
    <div class="stat-grid">
      <div class="cell"><div class="num">{len(carries)}</div><div class="lbl">Total carries</div></div>
      <div class="cell"><div class="num">{stats.progressive_carries}</div><div class="lbl">Prog carries</div></div>
      <div class="cell"><div class="num">{stats.take_ons_won}/{stats.take_ons_attempted}</div><div class="lbl">Take-ons</div></div>
      <div class="cell"><div class="num">{(stats.take_ons_won / stats.take_ons_attempted * 100) if stats.take_ons_attempted else 0:.0f}%</div><div class="lbl">Take-on rate</div></div>
    </div>
    <div class="top">
      <h4>Top progressive carriers</h4>
      {''.join(prog_html)}
    </div>
    <div class="top">
      <h4>Most take-ons won</h4>
      {''.join(to_html)}
    </div>
  </div>
</div>
'''
