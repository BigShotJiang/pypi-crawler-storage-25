"""Per-player grid pages — one mini pitch per player who featured.

Three kinds, each parameterised by side:
  - PlayersPassGrid     -> mini pass map per player (prog highlighted)
  - PlayersCarryGrid    -> mini carry + take-on map per player
  - PlayersDefenseGrid  -> mini defensive-actions map per player

The grid columns adapt to the number of players (target ~5 cols, max 6).
"""
from __future__ import annotations
import math

from .base import BasePage, DerivedData
from ..components import pitch_full, svg_wrap
from ..themes import get_theme


# All on-ball events used to define "player featured in this match"
ON_BALL = ("pass","cross","dribble","take_on","shot",
           "freekick_short","freekick_crossed","corner_short","corner_crossed",
           "throw_in","tackle","interception","clearance",
           "shot_freekick","shot_penalty")


def _grid_geom(n_players: int) -> tuple[int, int]:
    """Return (cols, rows) for a roughly-square grid that fits n_players."""
    if n_players <= 0: return (1, 1)
    if n_players <= 6:  cols = 3
    elif n_players <= 12: cols = 4
    else: cols = 5
    rows = math.ceil(n_players / cols)
    return cols, rows


def _featured_players(df, team_id: int) -> list[str]:
    """Players for a team who took at least one on-ball action, sorted by
    overall on-ball involvement (most active first)."""
    t = df[(df["team_id"] == team_id) & df["type_name"].isin(ON_BALL)]
    counts = t.groupby("player_name").size().sort_values(ascending=False)
    return [str(p) for p in counts.index]


# ---------------------------------------------------------------------------
# Mini-pitch renderers — each takes (player_df_for_team, theme, w, h) -> SVG
# ---------------------------------------------------------------------------

def _mini_pass_svg(pdf, theme, w: int, h: int) -> tuple[str, dict]:
    parts, x, y = pitch_full(w, h, theme)
    parts.insert(0,
        '<defs>'
        f'<marker id="mp_p" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto" markerUnits="strokeWidth">'
        f'<path d="M0,0 L5,2.5 L0,5 z" fill="{theme.gold}"/></marker>'
        '</defs>'
    )
    passes = pdf[pdf["type_name"].isin(["pass","cross"])]
    succ = passes[passes["result_name"] == "success"]
    fail = passes[passes["result_name"] != "success"]
    prog = succ[succ.get("is_progressive", False) == True]
    non_prog = succ[succ.get("is_progressive", False) == False]

    for _, r in fail.iterrows():
        x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
        parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                     f'stroke="{theme.red}" stroke-width="0.6" opacity="0.4" stroke-dasharray="2 2"/>')
    for _, r in non_prog.iterrows():
        x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
        forward = (r["end_x"] - r["start_x"]) >= 0
        color = theme.ink if forward else theme.ink_3
        parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                     f'stroke="{color}" stroke-width="0.7" opacity="0.55"/>')
    for _, r in prog.iterrows():
        x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
        parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                     f'stroke="{theme.gold}" stroke-width="1.4" opacity="0.95" '
                     f'stroke-linecap="round" marker-end="url(#mp_p)"/>')

    stats = {
        "completed": int(len(succ)), "attempted": int(len(passes)),
        "prog": int(len(prog)),
        "pct": round(len(succ) / max(len(passes), 1) * 100, 0),
    }
    return svg_wrap(parts, w, h), stats


def _mini_carry_svg(pdf, theme, w: int, h: int) -> tuple[str, dict]:
    parts, x, y = pitch_full(w, h, theme)
    parts.insert(0,
        '<defs>'
        f'<marker id="mc_p" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto" markerUnits="strokeWidth">'
        f'<path d="M0,0 L5,2.5 L0,5 z" fill="{theme.gold}"/></marker>'
        f'<marker id="mc_n" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto" markerUnits="strokeWidth">'
        f'<path d="M0,0 L5,2.5 L0,5 z" fill="{theme.ink_2}"/></marker>'
        '</defs>'
    )
    carries = pdf[pdf["type_name"] == "dribble"]
    non_prog = carries[carries.get("is_carry_prog", False) == False]
    prog     = carries[carries.get("is_carry_prog", False) == True]
    for _, r in non_prog.iterrows():
        x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
        parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                     f'stroke="{theme.ink_2}" stroke-width="0.7" opacity="0.55" '
                     f'marker-end="url(#mc_n)"/>')
    for _, r in prog.iterrows():
        x1, y1, x2, y2 = x(r["start_x"]), y(r["start_y"]), x(r["end_x"]), y(r["end_y"])
        parts.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
                     f'stroke="{theme.gold}" stroke-width="1.5" opacity="0.95" '
                     f'stroke-linecap="round" marker-end="url(#mc_p)"/>')

    tos = pdf[pdf["type_name"] == "take_on"]
    for _, r in tos.iterrows():
        cx, cy = x(r["start_x"]), y(r["start_y"])
        won = (r["result_name"] == "success")
        parts.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="2.6" '
                     f'fill="{theme.ink if won else theme.red}" '
                     f'stroke="{theme.paper}" stroke-width="0.7" opacity="0.92"/>')

    stats = {
        "carries": int(len(carries)), "prog": int(len(prog)),
        "to_won": int((tos["result_name"] == "success").sum()), "to_att": int(len(tos)),
    }
    return svg_wrap(parts, w, h), stats


def _mini_defense_svg(pdf, theme, w: int, h: int) -> tuple[str, dict]:
    parts, x, y = pitch_full(w, h, theme)
    type_styles = {
        "tackle":       (theme.ink,  "circle"),
        "interception": (theme.red,  "diamond"),
        "clearance":    (theme.gold, "triangle"),
    }
    counts = {k: 0 for k in type_styles}
    for tname, (color, shape) in type_styles.items():
        sub = pdf[pdf["type_name"] == tname]
        counts[tname] = len(sub)
        for _, r in sub.iterrows():
            cx, cy = x(r["start_x"]), y(r["start_y"])
            if shape == "circle":
                parts.append(f'<circle cx="{cx:.1f}" cy="{cy:.1f}" r="2.6" '
                             f'fill="{color}" stroke="{theme.paper}" stroke-width="0.7" opacity="0.92"/>')
            elif shape == "diamond":
                parts.append(f'<rect x="{cx-2.4:.1f}" y="{cy-2.4:.1f}" width="4.8" height="4.8" '
                             f'transform="rotate(45 {cx:.1f} {cy:.1f})" '
                             f'fill="{color}" stroke="{theme.paper}" stroke-width="0.7" opacity="0.92"/>')
            else:
                pts = f"{cx:.1f},{cy-3:.1f} {cx-2.7:.1f},{cy+2.4:.1f} {cx+2.7:.1f},{cy+2.4:.1f}"
                parts.append(f'<polygon points="{pts}" fill="{color}" '
                             f'stroke="{theme.paper}" stroke-width="0.7" opacity="0.92"/>')

    stats = {"tackle": counts["tackle"], "intercept": counts["interception"],
             "clear": counts["clearance"],
             "total": sum(counts.values())}
    return svg_wrap(parts, w, h), stats


# ---------------------------------------------------------------------------
# Page classes
# ---------------------------------------------------------------------------

KIND_INFO = {
    "pass":    ("Individual pass maps",     _mini_pass_svg,
                lambda s: f"{s['completed']}/{s['attempted']} · {s['prog']} prog"),
    "carry":   ("Individual carries / take-ons", _mini_carry_svg,
                lambda s: f"{s['carries']} carry · {s['prog']} prog · {s['to_won']}/{s['to_att']} to"),
    "defense": ("Individual defensive duels", _mini_defense_svg,
                lambda s: f"{s['tackle']} tk · {s['intercept']} int · {s['clear']} cl"),
}


class _PlayersGrid(BasePage):
    """Base class for the three per-player grid pages."""
    name = "players_grid"
    kind = "pass"

    def __init__(self, side: str = "home"):
        self.side = side

    def build(self, cfg, df, derived: DerivedData) -> str:
        theme = get_theme(cfg.theme)()
        team = cfg.home if self.side == "home" else cfg.away
        accent_var = "var(--home)" if self.side == "home" else "var(--away)"

        t = df[df["team_id"] == team.team_id].copy()

        players = _featured_players(t, team.team_id)
        cols, rows = _grid_geom(len(players))

        page_label, mini_fn, stat_fmt = KIND_INFO[self.kind]
        # Available card area = page minus the shell chrome (top strip,
        # header, content padding, footer). 248 covers all of it on the
        # default 1100px page; bump if you change the shell.
        content_w = cfg.output.page_width - 88
        content_h = cfg.output.page_height - 248
        gap = 12
        title_h = 26
        cell_w = (content_w - gap * (cols - 1)) // cols
        label_h = 30
        # Pitch height respects natural aspect but shrinks to fit all rows.
        natural_pitch_h = int((cell_w - 14) / 1.54)
        avail_for_pitches = content_h - title_h - rows * (label_h + 4) - (rows - 1) * gap
        max_pitch_h = max(avail_for_pitches // rows, 70)
        pitch_h = min(natural_pitch_h, max_pitch_h)

        cards = []
        for player in players:
            pdf = t[t["player_name"] == player]
            svg, stats = mini_fn(pdf, theme, cell_w - 8, pitch_h)
            cards.append(
                f'<div class="card">'
                f'  <div class="card-head">'
                f'    <span class="player">{player}</span>'
                f'    <span class="stat">{stat_fmt(stats)}</span>'
                f'  </div>'
                f'  <div class="card-body">{svg}</div>'
                f'</div>'
            )
        # Pad to fill grid
        while len(cards) < cols * rows:
            cards.append('<div class="card empty"></div>')

        page_subtitle = f"{team.team_name.upper()} — {len(players)} players featured"

        return f'''
<style>
  .pg-body {{ flex: 1; min-height: 0; display: flex; flex-direction: column; }}
  .pg-grid {{
    display: grid;
    grid-template-columns: repeat({cols}, 1fr);
    gap: {gap}px {gap}px;
    margin-top: 6px;
  }}
  .card {{ display: flex; flex-direction: column;
           border: 1px solid var(--hair-2); background: var(--paper-2); }}
  .card.empty {{ visibility: hidden; }}
  .card-head {{ display: flex; justify-content: space-between; align-items: baseline;
                padding: 5px 8px; border-bottom: 1px solid var(--hair); background: var(--paper); }}
  .card-head .player {{ font-family: 'Anton','Oswald',sans-serif; font-size: 14px;
                         color: var(--ink); letter-spacing: -0.2px; text-transform: uppercase;
                         overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
                         max-width: 65%; }}
  .card-head .stat {{ font-family: 'Inter',sans-serif; font-size: 9.5px; font-weight: 800;
                       letter-spacing: 0.10em; text-transform: uppercase; color: {accent_var}; }}
  .card-body {{ background: var(--paper-2); }}
  .card-body svg {{ display: block; width: 100%; height: auto; }}
</style>

<div class="pg-body">
  <div class="panel-title" style="display: flex; justify-content: space-between;">
    <span>{page_label.upper()}</span><span style="color: var(--ink-3)">{page_subtitle}</span>
  </div>
  <div class="pg-grid">
    {''.join(cards)}
  </div>
</div>
'''


class PlayersPassGrid(_PlayersGrid):
    name = "players_pass_grid"
    kind = "pass"
    title = "Individual pass maps"


class PlayersCarryGrid(_PlayersGrid):
    name = "players_carry_grid"
    kind = "carry"
    title = "Individual carries / take-ons"


class PlayersDefenseGrid(_PlayersGrid):
    name = "players_defense_grid"
    kind = "defense"
    title = "Individual defensive duels"
