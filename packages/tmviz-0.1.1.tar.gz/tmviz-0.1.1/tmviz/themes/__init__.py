from .cream import CreamTheme

THEMES = {"cream": CreamTheme}


def get_theme(name: str):
    if name not in THEMES:
        raise ValueError(f"Unknown theme '{name}'. Available: {list(THEMES)}")
    return THEMES[name]
