"""Cream / RosterMaker palette — tmviz default theme."""
from dataclasses import dataclass


@dataclass(frozen=True)
class CreamTheme:
    name: str = "cream"

    paper:    str = "#EFE7D5"
    paper_2:  str = "#E8DFC8"
    ink:      str = "#1B1814"
    ink_2:    str = "#5A5044"
    ink_3:    str = "#998D78"
    hairline: str = "#C9C0AC"
    hairline2: str = "#B5AC95"

    red:  str = "#C8102E"
    gold: str = "#B8881C"
    blue: str = "#2563EB"
    sand: str = "#D9CFB8"

    pitch_line:  str = "rgba(27,24,20,0.22)"
    pitch_line2: str = "rgba(27,24,20,0.10)"
    pitch_line3: str = "rgba(27,24,20,0.32)"

    title_font: str = "'Anton', 'Oswald', sans-serif"
    body_font:  str = "'Inter', system-ui, sans-serif"

    # Per-team accents — the home team uses the primary red, away uses
    # the secondary blue. Pages can override per match.
    home_color: str = "#C8102E"
    away_color: str = "#2563EB"

    @property
    def google_fonts_link(self) -> str:
        return ('<link rel="preconnect" href="https://fonts.googleapis.com"/>'
                '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>'
                '<link href="https://fonts.googleapis.com/css2?family=Anton'
                '&family=Oswald:wght@500;600;700'
                '&family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet"/>')
