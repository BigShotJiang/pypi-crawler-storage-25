"""Multi-page render: HTML + PNG per page, plus combined PDF."""
from __future__ import annotations
import asyncio
from pathlib import Path

from .config import ReportConfig
from .data import load_match, derive_metrics
from .data.metrics import per_team_stats, top_n_per_player
from .pages import get_page, page_shell, PAGE_LABELS
from .pages.base import DerivedData


def render_report(cfg: ReportConfig) -> dict:
    """Render every page to HTML+PNG, then stitch into a single PDF.

    Returns:
        {"html_paths": [...], "png_paths": [...], "pdf_path": Path}
    """
    df = derive_metrics(load_match(
        cfg.csv,
        players_csv=cfg.players_csv,
        teams_csv=cfg.teams_csv,
    ))
    h_score, a_score = cfg.score()

    derived = DerivedData(
        home_stats=per_team_stats(df, cfg.home.team_id, cfg.away.team_id,
                                  h_score, a_score, is_home=True),
        away_stats=per_team_stats(df, cfg.away.team_id, cfg.home.team_id,
                                  h_score, a_score, is_home=False),
        home_top=top_n_per_player(df, cfg.home.team_id),
        away_top=top_n_per_player(df, cfg.away.team_id),
    )

    out_dir = Path(cfg.output.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    html_paths, png_paths = [], []
    total = len(cfg.pages)
    for i, page_name in enumerate(cfg.pages, 1):
        page = get_page(page_name)
        inner = page.build(cfg, df, derived)
        full_html = page_shell(cfg, inner, PAGE_LABELS.get(page_name, page_name), i, total)
        slug = f"{i:02d}_{page_name}"
        html_path = out_dir / f"{slug}.html"
        png_path  = out_dir / f"{slug}.png"
        html_path.write_text(full_html, encoding="utf-8")
        html_paths.append(html_path)
        png_paths.append(png_path)

    # Render all to PNG in one Playwright session
    asyncio.run(_render_all(html_paths, png_paths,
                            cfg.output.page_width, cfg.output.page_height))

    # Stitch into PDF
    pdf_name = cfg.output.pdf_filename or _safe_pdf_name(cfg)
    pdf_path = out_dir / pdf_name
    _stitch_pdf(png_paths, pdf_path)

    return {"html_paths": html_paths, "png_paths": png_paths, "pdf_path": pdf_path}


def _safe_pdf_name(cfg: ReportConfig) -> str:
    h, a = cfg.score()
    parts = [
        cfg.home.team_name.lower().replace(" ", "_"),
        f"{h}-{a}",
        cfg.away.team_name.lower().replace(" ", "_"),
    ]
    if cfg.match.matchday is not None:
        parts.append(f"md{cfg.match.matchday}")
    return "_".join(parts) + ".pdf"


async def _render_all(html_paths, png_paths, w, h):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={"width": w, "height": h},
                                  device_scale_factor=2)
        page = await ctx.new_page()
        for html, png in zip(html_paths, png_paths):
            await page.goto("file:///" + str(html.absolute()).replace("\\", "/"))
            await page.wait_for_load_state("networkidle")
            await page.evaluate("document.fonts.ready")
            await page.wait_for_timeout(700)
            await page.locator(".page").screenshot(path=str(png))
        await b.close()


def _stitch_pdf(png_paths, pdf_path):
    """Combine the per-page PNGs into one multi-page PDF.
    PIL.PdfImagePlugin internally calls JPEG to compress raster images,
    so we explicitly Image.init() to make sure all bundled plugins
    register before save."""
    from PIL import Image
    Image.init()
    if not png_paths:
        return
    images = [Image.open(p).convert("RGB") for p in png_paths]
    images[0].save(pdf_path, "PDF", resolution=150.0,
                   save_all=True, append_images=images[1:])
