"""Shared SVG/HTML helpers used by every page."""
from .pitch import (
    pitch_full, pitch_vertical_full, svg_wrap, attack_caption,
    PW_DATA, PH_DATA, BOX_X, BOX_Y_LO, BOX_Y_HI,
    SIX_X, SIX_Y_LO, SIX_Y_HI, GOAL_Y_LO, GOAL_Y_HI, PEN_SPOT_X,
)
