"""Pitch SVG primitives.

Both `pitch_full` and `pitch_vertical_full` apply ~5% interior padding
so the touchlines, corner flags, and goal frames don't get clipped
against the panel edges. Pitch lines render LAST so any data layer
inserted before them sits underneath.
"""
from __future__ import annotations

PW_DATA = 100.0
PH_DATA = 100.0
BOX_X    = 15.7
BOX_Y_LO = 50 - 59.3 / 2
BOX_Y_HI = 50 + 59.3 / 2
SIX_X    = 5.2
SIX_Y_LO = 50 - 26.9 / 2
SIX_Y_HI = 50 + 26.9 / 2
GOAL_Y_LO = 50 - 10.8 / 2
GOAL_Y_HI = 50 + 10.8 / 2
CIRCLE_R  = 8.7
PEN_SPOT_X = 89.524

PAD_FRAC = 0.04         # 4% interior padding around the pitch outline


def pitch_full(w: int, h: int, theme):
    """Horizontal full pitch, attacking RIGHT.
    Returns (parts, x(), y()) where x()/y() map data coords to canvas px."""
    pad_x = w * PAD_FRAC
    pad_y = h * PAD_FRAC
    inner_w = w - 2 * pad_x
    inner_h = h - 2 * pad_y
    sx = inner_w / PW_DATA
    sy = inner_h / PH_DATA

    def x(v): return pad_x + v * sx
    def y(v): return pad_y + (PH_DATA - v) * sy

    parts = [f'<rect x="0" y="0" width="{w}" height="{h}" fill="{theme.paper_2}"/>']
    parts.append(f'<rect x="{x(0):.1f}" y="{y(100):.1f}" '
                 f'width="{100*sx:.1f}" height="{100*sy:.1f}" '
                 f'fill="none" stroke="{theme.pitch_line}" stroke-width="1.0"/>')
    parts.append(f'<line x1="{x(50):.1f}" y1="{y(0):.1f}" x2="{x(50):.1f}" y2="{y(100):.1f}" '
                 f'stroke="{theme.pitch_line2}" stroke-width="1.0"/>')
    parts.append(f'<circle cx="{x(50):.1f}" cy="{y(50):.1f}" r="{CIRCLE_R*sx:.1f}" '
                 f'fill="none" stroke="{theme.pitch_line2}" stroke-width="1.0"/>')
    parts.append(f'<circle cx="{x(50):.1f}" cy="{y(50):.1f}" r="2.0" fill="{theme.pitch_line}"/>')
    for px0 in [0, PW_DATA - BOX_X]:
        parts.append(f'<rect x="{x(px0):.1f}" y="{y(BOX_Y_HI):.1f}" '
                     f'width="{BOX_X*sx:.1f}" height="{(BOX_Y_HI-BOX_Y_LO)*sy:.1f}" '
                     f'fill="none" stroke="{theme.pitch_line2}" stroke-width="1.0"/>')
    for px0 in [0, PW_DATA - SIX_X]:
        parts.append(f'<rect x="{x(px0):.1f}" y="{y(SIX_Y_HI):.1f}" '
                     f'width="{SIX_X*sx:.1f}" height="{(SIX_Y_HI-SIX_Y_LO)*sy:.1f}" '
                     f'fill="none" stroke="{theme.pitch_line2}" stroke-width="0.8"/>')
    for gx0 in [-1.4, PW_DATA]:
        parts.append(f'<rect x="{x(gx0):.1f}" y="{y(GOAL_Y_HI):.1f}" '
                     f'width="{1.4*sx:.1f}" height="{(GOAL_Y_HI-GOAL_Y_LO)*sy:.1f}" '
                     f'fill="none" stroke="{theme.pitch_line3}" stroke-width="1.2"/>')
    for px0 in [100 - PEN_SPOT_X, PEN_SPOT_X]:
        parts.append(f'<circle cx="{x(px0):.1f}" cy="{y(50):.1f}" r="1.5" fill="{theme.pitch_line}"/>')
    return parts, x, y


def pitch_vertical_full(w: int, h: int, theme):
    """Vertical full pitch, attacking UP (own goal at bottom).
    Useful for shot maps when both teams are stacked top/bottom."""
    pad_x = w * PAD_FRAC
    pad_y = h * PAD_FRAC
    inner_w = w - 2 * pad_x
    inner_h = h - 2 * pad_y
    sx = inner_w / PH_DATA           # data y -> canvas x
    sy = inner_h / PW_DATA           # data x -> canvas y

    def x(v_y): return pad_x + v_y * sx                  # v_y is data y (0..100)
    def y(v_x): return pad_y + (PW_DATA - v_x) * sy      # v_x is data x (0..100)

    parts = [f'<rect x="0" y="0" width="{w}" height="{h}" fill="{theme.paper_2}"/>']
    parts.append(f'<rect x="{x(0):.1f}" y="{y(100):.1f}" '
                 f'width="{100*sx:.1f}" height="{100*sy:.1f}" '
                 f'fill="none" stroke="{theme.pitch_line}" stroke-width="1.0"/>')
    parts.append(f'<line x1="{x(0):.1f}" y1="{y(50):.1f}" x2="{x(100):.1f}" y2="{y(50):.1f}" '
                 f'stroke="{theme.pitch_line2}" stroke-width="1.0"/>')
    parts.append(f'<circle cx="{x(50):.1f}" cy="{y(50):.1f}" r="{CIRCLE_R*sx:.1f}" '
                 f'fill="none" stroke="{theme.pitch_line2}" stroke-width="1.0"/>')
    parts.append(f'<circle cx="{x(50):.1f}" cy="{y(50):.1f}" r="2.0" fill="{theme.pitch_line}"/>')
    for px in [0, PW_DATA - BOX_X]:
        parts.append(f'<rect x="{x(BOX_Y_LO):.1f}" y="{y(px+BOX_X) if px==0 else y(PW_DATA):.1f}" '
                     f'width="{(BOX_Y_HI-BOX_Y_LO)*sx:.1f}" height="{BOX_X*sy:.1f}" '
                     f'fill="none" stroke="{theme.pitch_line2}" stroke-width="1.0"/>')
    for px in [0, PW_DATA - SIX_X]:
        parts.append(f'<rect x="{x(SIX_Y_LO):.1f}" y="{y(px+SIX_X) if px==0 else y(PW_DATA):.1f}" '
                     f'width="{(SIX_Y_HI-SIX_Y_LO)*sx:.1f}" height="{SIX_X*sy:.1f}" '
                     f'fill="none" stroke="{theme.pitch_line2}" stroke-width="0.8"/>')
    parts.append(f'<rect x="{x(GOAL_Y_LO):.1f}" y="{y(PW_DATA)-3:.1f}" '
                 f'width="{(GOAL_Y_HI-GOAL_Y_LO)*sx:.1f}" height="3" '
                 f'fill="none" stroke="{theme.pitch_line3}" stroke-width="1.2"/>')
    parts.append(f'<rect x="{x(GOAL_Y_LO):.1f}" y="{y(0):.1f}" '
                 f'width="{(GOAL_Y_HI-GOAL_Y_LO)*sx:.1f}" height="3" '
                 f'fill="none" stroke="{theme.pitch_line3}" stroke-width="1.2"/>')
    for px in [PEN_SPOT_X, 100 - PEN_SPOT_X]:
        parts.append(f'<circle cx="{x(50):.1f}" cy="{y(px):.1f}" r="1.5" fill="{theme.pitch_line}"/>')
    return parts, x, y


def attack_caption(parts: list[str], w: int, h: int, theme,
                   prefix: str = "", side: str = "right"):
    """Append an 'ATTACK →' caption to the bottom of a pitch SVG."""
    text = (prefix + " · " if prefix else "") + "ATTACK →"
    if side == "left":
        parts.append(f'<text x="12" y="{h-10}" text-anchor="start" '
                     f'font-family="Inter,sans-serif" font-size="11" font-weight="800" '
                     f'fill="{theme.ink_2}" letter-spacing="0.18em">{text}</text>')
    else:
        parts.append(f'<text x="{w-12}" y="{h-10}" text-anchor="end" '
                     f'font-family="Inter,sans-serif" font-size="11" font-weight="800" '
                     f'fill="{theme.ink_2}" letter-spacing="0.18em">{text}</text>')


def svg_wrap(parts: list[str], w: int, h: int) -> str:
    return (f'<svg viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg" '
            f'width="{w}" height="{h}" preserveAspectRatio="xMidYMid meet">'
            f'{"".join(parts)}</svg>')
