"""Per-team and per-player aggregations.

These are computed once after loading and reused across pages so we
don't recompute the same numbers in each renderer.
"""
from __future__ import annotations
from dataclasses import dataclass

import pandas as pd


SHOT_TYPES = {"shot", "shot_freekick", "shot_penalty"}


@dataclass
class TeamStats:
    team_id: int
    actions: int
    possession_pct: float                 # share of (pass+cross+dribble+take_on+shot) actions
    passes_attempted: int
    passes_completed: int
    pass_pct: float
    progressive_passes: int
    progressive_carries: int
    take_ons_attempted: int
    take_ons_won: int
    box_entries: int                      # successful passes into the opp box
    shots: int
    shots_on_target: int
    goals_for: int                        # honors own-goal flips passed in via cfg
    goals_against: int
    xt_open_play: float
    xg_for: float                         # 0 if no xG col
    xg_against: float
    has_xg: bool
    defensive_actions: int                # tackle + interception + clearance


def per_team_stats(df: pd.DataFrame, team_id: int, opp_id: int,
                   home_goals: int, away_goals: int,
                   is_home: bool) -> TeamStats:
    t = df[df["team_id"] == team_id]
    actions_for_possession = df[df["type_name"].isin([
        "pass","cross","dribble","take_on","shot","shot_freekick"
    ])]
    poss_share = float((actions_for_possession["team_id"] == team_id).mean()) if len(actions_for_possession) else 0.0

    passes = t[t["type_name"].isin(["pass","cross"])]
    pa = len(passes)
    pc = int((passes["result_name"] == "success").sum())
    prog_p = int((t.get("is_progressive", False) == True).sum())
    prog_c = int(((t["type_name"] == "dribble") & (t.get("is_carry_prog", False) == True)).sum())

    tos = t[t["type_name"] == "take_on"]
    to_a = len(tos)
    to_w = int((tos["result_name"] == "success").sum())

    box_e = int((t.get("ball_into_box", False) == True).sum())

    shots = t[t["type_name"].isin(SHOT_TYPES)]
    n_shots = len(shots)
    # On target = shot followed by keeper_save / keeper_pick_up / keeper_punch / keeper_claim
    # OR is_goal. We approximate via "result_name == success" or "is_goal".
    on_target = int((shots["is_goal"] == True).sum() + (shots["result_name"] == "success").sum())
    on_target = min(on_target, n_shots)   # avoid double count

    has_xg = "xG" in df.columns or "xg" in df.columns
    xg_col = "xG" if "xG" in df.columns else ("xg" if "xg" in df.columns else None)
    xg_for     = float(shots[xg_col].fillna(0).sum()) if xg_col else 0.0
    xg_against = float(df[(df["team_id"] == opp_id) & df["type_name"].isin(SHOT_TYPES)][xg_col].fillna(0).sum()) if xg_col else 0.0

    xt = float(t["xT_added"].clip(lower=0).fillna(0).sum())

    def_acts = int(t["type_name"].isin(["tackle","interception","clearance"]).sum())

    return TeamStats(
        team_id=team_id, actions=len(t),
        possession_pct=round(poss_share * 100, 1),
        passes_attempted=pa, passes_completed=pc,
        pass_pct=round(pc / pa * 100, 1) if pa else 0.0,
        progressive_passes=prog_p, progressive_carries=prog_c,
        take_ons_attempted=to_a, take_ons_won=to_w,
        box_entries=box_e,
        shots=n_shots, shots_on_target=on_target,
        goals_for=home_goals if is_home else away_goals,
        goals_against=away_goals if is_home else home_goals,
        xt_open_play=round(xt, 2),
        xg_for=round(xg_for, 2), xg_against=round(xg_against, 2),
        has_xg=has_xg,
        defensive_actions=def_acts,
    )


FINAL_THIRD_X = 66.7
BOX_X_THRESH  = 83.0          # opp 18-yd box edge
BOX_Y_LO, BOX_Y_HI = 21.0, 79.0


def top_n_per_player(df: pd.DataFrame, team_id: int, n: int = 5) -> dict:
    """{category: [(player_name, value), ...]} for the top N per team.
    Categories below; xg only present if the data has an xG column."""
    t = df[df["team_id"] == team_id]
    out: dict[str, list[tuple[str, float]]] = {}

    def topN(series, key):
        out[key] = [(p, float(v)) for p, v in series.nlargest(n).items() if v > 0]

    g = t.groupby("player_name", group_keys=False)

    pass_succ = (t["type_name"].isin(["pass","cross"])) & (t["result_name"] == "success")
    started_outside_f3   = (t["start_x"] <  FINAL_THIRD_X)
    ended_in_f3          = (t["end_x"]   >= FINAL_THIRD_X)
    started_outside_box  = ~((t["start_x"] >= BOX_X_THRESH) & t["start_y"].between(BOX_Y_LO, BOX_Y_HI))
    ended_in_box         = (t["end_x"]   >= BOX_X_THRESH) & t["end_y"].between(BOX_Y_LO, BOX_Y_HI)

    is_carry = (t["type_name"] == "dribble")

    topN(g.apply(lambda x: int(((x["type_name"].isin(["pass","cross"])) & (x["result_name"] == "success")).sum()),
                  include_groups=False), "passes")
    topN(g.apply(lambda x: int((x.get("is_progressive", False) == True).sum()),
                  include_groups=False), "prog_passes")
    topN(g.apply(lambda x: int(((x["type_name"].isin(["pass","cross"])) & (x["result_name"]=="success")
                                  & (x["start_x"] < FINAL_THIRD_X) & (x["end_x"] >= FINAL_THIRD_X)).sum()),
                  include_groups=False), "passes_into_f3")
    topN(g.apply(lambda x: int(((x["type_name"].isin(["pass","cross"])) & (x["result_name"]=="success")
                                  & ~((x["start_x"] >= BOX_X_THRESH) & x["start_y"].between(BOX_Y_LO, BOX_Y_HI))
                                  & (x["end_x"] >= BOX_X_THRESH) & x["end_y"].between(BOX_Y_LO, BOX_Y_HI)).sum()),
                  include_groups=False), "passes_into_box")
    topN(g.apply(lambda x: int(((x["type_name"] == "dribble") & (x.get("is_carry_prog", False) == True)).sum()),
                  include_groups=False), "prog_carries")
    topN(g.apply(lambda x: int(((x["type_name"] == "dribble")
                                  & (x["start_x"] < FINAL_THIRD_X)
                                  & (x["end_x"]   >= FINAL_THIRD_X)).sum()),
                  include_groups=False), "carries_into_f3")
    topN(g.apply(lambda x: int(((x["type_name"] == "dribble")
                                  & ~((x["start_x"] >= BOX_X_THRESH) & x["start_y"].between(BOX_Y_LO, BOX_Y_HI))
                                  & (x["end_x"] >= BOX_X_THRESH) & x["end_y"].between(BOX_Y_LO, BOX_Y_HI)).sum()),
                  include_groups=False), "carries_into_box")
    topN(g.apply(lambda x: int(((x["type_name"] == "take_on") & (x["result_name"] == "success")).sum()),
                  include_groups=False), "take_ons_won")
    topN(g["xT_added"].apply(lambda s: round(float(s.clip(lower=0).sum()), 2)),
         "xt")
    topN(g.apply(lambda x: int(x["type_name"].isin(["tackle","interception","clearance"]).sum()),
                  include_groups=False), "defensive_actions")
    topN(g.apply(lambda x: int(x["type_name"].isin(SHOT_TYPES).sum()),
                  include_groups=False), "shots")
    if "xG" in t.columns:
        topN(g.apply(lambda x: round(float(x[x["type_name"].isin(SHOT_TYPES)]["xG"].fillna(0).sum()), 2),
                      include_groups=False), "xg")
    elif "xg" in t.columns:
        topN(g.apply(lambda x: round(float(x[x["type_name"].isin(SHOT_TYPES)]["xg"].fillna(0).sum()), 2),
                      include_groups=False), "xg")
    return out


def avg_position(df: pd.DataFrame, team_id: int) -> dict[str, tuple[float, float]]:
    """Average (x, y) per player for that team — useful for positioning labels
    on the pass map without overlapping arrows."""
    t = df[(df["team_id"] == team_id) & df["type_name"].isin(
        ["pass","cross","dribble","take_on","shot"]
    )]
    out = {}
    for name, g in t.groupby("player_name"):
        out[name] = (float(g["start_x"].mean()), float(g["start_y"].mean()))
    return out
