"""Karun Singh's expected-threat (xT) grid — bundled with tmviz so we
can auto-compute `xT_added` if the input CSV doesn't already have it.

Standard 12 cols × 8 rows over a 100×100 pitch. Each cell holds the
chance the team in possession scores within the next ~few seconds
from that location. xT_added for a pass/carry/dribble is therefore
end_zone_value − start_zone_value (positive = improved scoring chance).

Reference values from the original Karun Singh blog post:
  https://karun.in/blog/expected-threat.html
"""
from __future__ import annotations
import numpy as np
import pandas as pd

XT_GRID = np.array([
    [0.00638303, 0.00779616, 0.00844854, 0.00977659, 0.01126267, 0.01248344, 0.01473596, 0.0174506, 0.02122129, 0.02756312, 0.03485072, 0.0379259],
    [0.00750072, 0.00878589, 0.00942382, 0.0105949,  0.01214719, 0.0138454,  0.01611813, 0.01870347, 0.02401398, 0.02953272, 0.04066992, 0.04647721],
    [0.0088799,  0.00977745, 0.01001304, 0.01110462, 0.01269174, 0.01429128, 0.01685596, 0.01935132, 0.0241224,  0.02855202, 0.05491138, 0.06442595],
    [0.00941056, 0.01082722, 0.01016549, 0.01132376, 0.01262646, 0.01484598, 0.01689528, 0.0199707,  0.02385149, 0.03511326, 0.10805102, 0.25745362],
    [0.00941056, 0.01082722, 0.01016549, 0.01132376, 0.01262646, 0.01484598, 0.01689528, 0.0199707,  0.02385149, 0.03511326, 0.10805102, 0.25745362],
    [0.0088799,  0.00977745, 0.01001304, 0.01110462, 0.01269174, 0.01429128, 0.01685596, 0.01935132, 0.0241224,  0.02855202, 0.05491138, 0.06442595],
    [0.00750072, 0.00878589, 0.00942382, 0.0105949,  0.01214719, 0.0138454,  0.01611813, 0.01870347, 0.02401398, 0.02953272, 0.04066992, 0.04647721],
    [0.00638303, 0.00779616, 0.00844854, 0.00977659, 0.01126267, 0.01248344, 0.01473596, 0.0174506,  0.02122129, 0.02756312, 0.03485072, 0.0379259],
])

XT_ROWS, XT_COLS = XT_GRID.shape    # 8, 12
PROGRESSION_TYPES = {"pass", "cross", "dribble"}


def compute_xt(df: pd.DataFrame) -> pd.Series:
    """Compute per-event xT using the bundled grid. Only successful
    pass/cross/dribble events get a non-zero value (they're the actions
    that move the ball between zones). Coordinates assumed Opta 0-100
    in the team's own attacking direction (low x = own goal)."""
    sx = df["start_x"].clip(0, 99.999)
    sy = df["start_y"].clip(0, 99.999)
    ex = df["end_x"].clip(0, 99.999)
    ey = df["end_y"].clip(0, 99.999)
    x1b = (sx * XT_COLS / 100).astype(int).clip(0, XT_COLS - 1)
    y1b = (sy * XT_ROWS / 100).astype(int).clip(0, XT_ROWS - 1)
    x2b = (ex * XT_COLS / 100).astype(int).clip(0, XT_COLS - 1)
    y2b = (ey * XT_ROWS / 100).astype(int).clip(0, XT_ROWS - 1)
    start_v = XT_GRID[y1b.values, x1b.values]
    end_v   = XT_GRID[y2b.values, x2b.values]
    xt = end_v - start_v
    # Zero out non-progression events (shots, defensive actions, etc.)
    is_prog = df["type_name"].isin(PROGRESSION_TYPES)
    is_succ = df.get("result_name", pd.Series(["success"] * len(df))) == "success"
    xt[~(is_prog & is_succ).values] = 0.0
    return pd.Series(xt, index=df.index)
