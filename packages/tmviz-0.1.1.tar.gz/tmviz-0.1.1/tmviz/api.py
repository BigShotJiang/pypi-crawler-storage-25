"""Library entry point. See `generate_report` below."""
from __future__ import annotations
from pathlib import Path
from typing import Optional, Iterable

from .config import (
    ReportConfig, TeamInfo, GoalInfo, MatchInfo, OutputConfig,
)
from .data import load_match, detect_teams, detect_goals
from .render import render_report
from .pages import REGISTRY as PAGE_REGISTRY


DEFAULT_PAGES = list(ReportConfig(
    csv="", home=TeamInfo(0, ""), away=TeamInfo(0, "")
).pages)


def generate_report(
    csv: str | Path,
    home: str,
    away: str,
    *,
    players_csv: Optional[str | Path] = None,
    teams_csv:   Optional[str | Path] = None,
    home_team_id: Optional[int] = None,
    away_team_id: Optional[int] = None,
    competition: str = "",
    matchday: Optional[int] = None,
    date: Optional[str] = None,
    venue: Optional[str] = None,
    home_color: Optional[str] = None,
    away_color: Optional[str] = None,
    home_crest: Optional[str] = None,
    away_crest: Optional[str] = None,
    own_goal_minutes: Iterable[int] = (),
    pages: Optional[list[str]] = None,
    out_dir: str | Path = "out/match_report",
    page_width: int = 1600,
    page_height: int = 1100,
    show_handle: bool = False,
    show_attribution: bool = True,
    theme: str = "cream",
    pdf_filename: Optional[str] = None,
) -> dict:
    """Generate a full match report from a single-match SPADL CSV.

    Returns the paths dict from `render_report()`: html_paths, png_paths,
    pdf_path.

    Team-ids are auto-detected from the data unless you pass
    `home_team_id` / `away_team_id` explicitly. Own-goals: pass the
    minute(s) in `own_goal_minutes` to flip credit. Lookup CSVs
    (`players_csv`, `teams_csv`) are merged in at load if the main CSV
    only has ids.
    """
    df = load_match(
        str(csv),
        players_csv=str(players_csv) if players_csv else None,
        teams_csv=str(teams_csv) if teams_csv else None,
    )

    # --- Team-id resolution -------------------------------------------------
    detected = detect_teams(df)
    if len(detected) < 2:
        raise ValueError(f"Expected 2 team_ids in the CSV; found {len(detected)}.")
    if home_team_id is None and away_team_id is None:
        home_team_id = int(detected[0][0])
        away_team_id = int(detected[1][0])
    elif home_team_id is None:
        home_team_id = int(next(tid for tid, _ in detected if tid != away_team_id))
    elif away_team_id is None:
        away_team_id = int(next(tid for tid, _ in detected if tid != home_team_id))

    # --- Own-goal flagging --------------------------------------------------
    goals_raw = detect_goals(df)
    og_minutes = set(int(m) for m in own_goal_minutes)
    goals = []
    for g in goals_raw:
        is_og = g["minute"] in og_minutes
        goals.append(GoalInfo(
            minute=g["minute"], period=g["period"],
            time_seconds=g["time_seconds"], scorer=g["scorer"],
            team_id=g["team_id"], is_own_goal=is_og,
        ))

    # --- Page selection ----------------------------------------------------
    if pages is None:
        pages = DEFAULT_PAGES
    bad = [p for p in pages if p not in PAGE_REGISTRY]
    if bad:
        raise ValueError(f"Unknown pages: {bad}. Known: {list(PAGE_REGISTRY)}")

    cfg = ReportConfig(
        csv=str(Path(csv).resolve()),
        players_csv=str(Path(players_csv).resolve()) if players_csv else None,
        teams_csv=str(Path(teams_csv).resolve()) if teams_csv else None,
        home=TeamInfo(team_id=int(home_team_id), team_name=home,
                      crest=home_crest, color_primary=home_color),
        away=TeamInfo(team_id=int(away_team_id), team_name=away,
                      crest=away_crest, color_primary=away_color),
        match=MatchInfo(competition=competition, matchday=matchday,
                        date=date, venue=venue),
        goals=goals,
        pages=pages,
        theme=theme,
        output=OutputConfig(
            out_dir=str(out_dir),
            page_width=page_width, page_height=page_height,
            pdf_filename=pdf_filename,
            show_handle=show_handle, show_attribution=show_attribution,
        ),
    )
    return render_report(cfg)
