import typing as t
from pyglm import glm

if t.TYPE_CHECKING:
    from .. import hints


def lerp[T: hints.vec2 | hints.vec3 | hints.vec4](
    start: T,
    end: T,
    progress: float,
) -> T:
    return glm.lerp(
        start,
        end,
        progress,
    ).to_tuple()  # pyright: ignore[reportReturnType]
