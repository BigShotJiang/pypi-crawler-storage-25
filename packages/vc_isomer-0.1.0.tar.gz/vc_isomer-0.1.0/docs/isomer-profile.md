# W3C VRD Isomer Profile

This document defines the initial isomer profile for projecting authoritative
VRD ACDC credentials into W3C VC-JWT credentials.

For the live-stack runtime and integration mental model behind this profile,
see
[`integration-maintainer-guide.md`](docs/integration-maintainer-guide.md).

## Core Rules

- ACDC is the source of truth.
- W3C credentials are derived interoperability twins.
- The W3C twin is signed by the LE's `did:webs` key material through a live
  KERI habitat signer.
- Signature verification must resolve key state through the
  `did-webs-resolver` Universal Resolver endpoint.
- Revocation is projected through an isomer-owned `credentialStatus`
  resource backed by KERI registry state.
- Deterministic demo signers are not allowed.

## Supported Source Schemas

- `VRDAuthorizationCredential`:
  `EFiYsVADHXcn1BZirDRH301Rm12301povihg5UMIYkfc`
- `VRDCredential`:
  `EAyv2DLocYxJlPrWAfYBuHWDpjCStdQBzNLg0-3qQ-KP`
- Referenced LE credential schema:
  `ENPXp1vQzRF6JwIuS-mp2U8Uf1MoADoP_GqQ62VsDZWY`

## Isomer Payload Shape

- `issuer`: the `did:webs` of the LE signer producing the W3C twin
- `credentialSubject.id`: the subject DID from the source attributes block
- `credentialSubject.aid`: the subject AID from `AID` or `LE`
- `credentialStatus.id`: `${status_base_url}/status/${source_said}`
- `isomer.sourceCredentialSaid`: source ACDC SAID
- `isomer.sourceSchemaSaid`: source ACDC schema SAID
- `isomer.sourceIssuerAid`: source ACDC issuer AID
- `isomer.sourceRegistry`: source ACDC registry SAID
- `isomer.sourceEdges`: normalized source edges block

## Validation Rules

- VC-JWT header `alg` must be `EdDSA`.
- VC-JWT header `typ` must be `vc+jwt`.
- `issuer` must resolve through `did-webs-resolver`.
- `kid` must resolve to a `JsonWebKey` `Ed25519` verification method.
- `credentialStatus` must resolve to an active record.
- Dual verification must confirm equivalence between source ACDC fields and the
  W3C `isomer` projection.
