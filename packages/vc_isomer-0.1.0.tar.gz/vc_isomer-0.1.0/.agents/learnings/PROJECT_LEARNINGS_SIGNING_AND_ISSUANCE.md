# PROJECT_LEARNINGS_SIGNING_AND_ISSUANCE

## Purpose

Persistent learnings for signer selection, issuance flows, and signing-related
isomer interoperability behavior.

## Current Status

### 2026-03-26

1. Deterministic demo signers are banned.
2. Runtime and integration signing must come from live KERI habitat signers.
3. For now, those live habitat signers must come from KLI/KERIpy-managed
   keystores.
4. Test determinism is allowed only by creating real temporary habitats
   through KERI library salt or passcode inputs.
5. Any CLI or service path that mints a W3C credential without opening a real
   habitat signer is incomplete and should be treated as a defect.

## Scope Checklist

Use this doc for:

1. signer selection and key material rules,
2. issuance flow invariants,
3. runtime vs test signer boundaries,
4. wallet and KLI signer integration notes.

## Decision Log

### 2026-04-15 - PyPI Publishing Pipeline Added

- What changed:
  - Added a repo `Makefile` with sync, smoke, test, build, artifact check,
    TestPyPI upload, and PyPI upload targets.
  - Publish targets use `uv publish`, validate artifacts with `twine check`
    through `uvx`, and require a clean worktree unless `ALLOW_DIRTY=1`.
- Why:
  - First publication needs a repeatable release gate that verifies the
    `vc-isomer` distribution, the `vc_isomer` import package, and the `isomer`
    console script before upload.
- Tests:
  - Run `make help`, `make smoke`, `make dist-check`, and the pytest targets
    before publishing.
- Contracts/plans touched:
  - `Makefile`
  - `README.md`
  - `.agents/PROJECT_LEARNINGS.md`
- Risks and TODOs:
  - TestPyPI should be used before the first real PyPI upload; the Makefile
    supports separate `TEST_PYPI_TOKEN` and `PYPI_TOKEN` values.

### 2026-04-15 - PyPI Distribution Split to `vc-isomer` / `vc_isomer`

- What changed:
  - Changed the installable distribution name to `vc-isomer` because `isomer`
    is already taken on PyPI.
  - Renamed the Python import package from `isomer` to `vc_isomer`.
  - Kept the installed CLI command, product language, profile constants,
    provenance payload field, result kind, and operation storage paths branded
    as Isomer.
- Why:
  - Python packaging best practice separates distribution names from import
    package names; the distribution can use a hyphen, while the import package
    must be a valid Python identifier.
- Tests:
  - Use `vc_isomer` for import and module-mode smoke checks.
  - Keep `isomer --help` as the CLI smoke check.
- Contracts/plans touched:
  - `pyproject.toml`
  - `uv.lock`
  - `README.md`
  - `.agents/PROJECT_LEARNINGS.md`
- Risks and TODOs:
  - The `isomer` console script can still conflict with other installed tools
    in the same environment; that is an accepted product naming decision.

### 2026-04-15 - Project Identity Hard-Cut to `isomer`

- What changed:
  - Renamed the Python import package, distribution metadata, CLI entrypoint,
    docs, placeholder app/package dirs, integration test target, profile
    constants, pair-verification result kind, provenance payload field, and
    operation storage defaults from the legacy project naming to `isomer`.
  - Removed compatibility by omission: legacy imports and the old console
    script are expected to fail after `uv sync`.
- Why:
  - The project now treats Isomer as the canonical product and protocol-profile
    identity rather than the transitional legacy name.
- Tests:
  - `./.venv/bin/python -m py_compile $(find src/vc_isomer -name '*.py' -print)`
  - `./.venv/bin/python -m vc_isomer.cli --help`
  - `./.venv/bin/python -c "import vc_isomer"`
  - Legacy import smoke check fails as expected.
  - `./.venv/bin/python -m pytest tests/test_cli.py -q`
  - `./.venv/bin/python -m pytest tests/test_cesr_fixtures.py tests/test_profile.py tests/test_jwt.py tests/test_status.py tests/test_verifier.py tests/test_service.py tests/test_longrunning.py tests/test_runtime_http.py tests/test_verifier_runtime.py tests/test_isomer_runtime.py -q`
- Contracts/plans touched:
  - `pyproject.toml`
  - `uv.lock`
  - `docs/isomer-profile.md`
  - `plans/w3c-vrd-isomer-plan.md`
  - `.agents/PROJECT_LEARNINGS.md`
- Risks and TODOs:
  - Any external consumer still posting or reading the old VC
    provenance field must migrate to `isomer`; no fallback reader was kept.

### 2026-04-15 - Integration Doer Steps Must Be Supervised by `Doist.do()`

- What changed:
  - `run_doers_until(...)` now runs a small supervisory `DoDoer` through `Doist.do(real=True, limit=timeout)` instead of manually calling `Doist.recur(...)` inside a wall-clock loop.
  - The supervisor owns the target doers, records the latest observed state, removes child doers once the external readiness predicate succeeds, and lets the outer doist perform real-time pacing.
- Why:
  - The old helper mixed two clocks: a manual `time.monotonic()` deadline around direct logical-time recurrences.
  - That made verifier HTTP waits sensitive to scheduler tight-loop behavior; `Doist.do(real=True)` is the correct HIO construct for wall-clock-paced test execution.
- Tests:
  - Add focused helper tests for success, timeout diagnostics, and cleanup.
- Risks and TODOs:
  - This fixes harness pacing, not verifier client timeout semantics. Wall-clock I/O deadlines should still be handled as a separate, focused verifier-client change if the live POST timeout remains.

### 2026-04-15 - Verifier Observability Instrumentation Removed as PoC Bloat

- What changed:
  - Removed verifier request correlation, operation event timelines, trace JSON logs, request summaries, client snapshots, and matching-operation lookup.
  - Verifier operations returned to the bare PoC model: operation name, state timestamps, terminal response, and terminal error.
- Why:
  - The instrumentation made the code harder to read and learn from before the verifier architecture had stabilized.
  - Scheduler and timeout fixes should be handled directly instead of hiding behind more diagnostics.
- Tests:
  - Update and rerun focused long-running, service, client, runtime, and DID resolver tests.
- Contracts/plans touched:
  - `.agents/PROJECT_LEARNINGS.md`
- Risks and TODOs:
  - The next verifier timing fix should focus on `Doist.do()`/supervisory-doer pacing and wall-clock I/O deadlines, not on rebuilding fine-grained observability.

### 2026-04-15 - did:webs Resolver URLs Must Not Be Pre-Quoted for HIO

- What changed:
  - Isomer stopped percent-encoding the full did:webs DID before passing it to HIO clienting for resolver requests.
  - `resolution_url(...)` now appends the canonical DID value as the final path component and lets HIO quote the request path exactly once during transport.
- Why:
  - `did-webs-resolver` calls `didding.requote(...)`, which expects a once-path-encoded DID such as `did%3Awebs%3Ahost%253Aport...`.
  - Pre-quoting in isomer made HIO quote the percent signs again, producing `did%253Awebs...`; `requote(...)` no longer recognized that as an encoded DID and the resolver rejected it as invalid.
  - The right split is: canonicalize the DID value itself, including `%3A` for the did:webs host/port separator, but do not perform HTTP transport quoting before handing the path to HIO.
- Tests:
  - `./.venv/bin/python -m pytest tests/test_didwebs.py -q`
  - `./.venv/bin/python -m py_compile src/vc_isomer/didwebs.py tests/test_didwebs.py`
  - `./.venv/bin/python -m pytest tests/integration/test_single_sig_vrd_isomer.py -k test_single_sig_vrd_isomer_live -s --tb=short -vv --maxfail=1`
- Contracts/plans touched:
  - None.
- Risks and TODOs:
  - The live test now shows did:webs resolution returning `200 OK`; the remaining failure is the verifier POST response timing issue, not resolver DID parsing.

### 2026-04-14 - did:webs Fixture Must Be In-Process but Snapshot-Isolated

- What changed:
  - The live integration fixture stopped launching did:webs artifact and resolver through the `dws` CLI subprocess wrapper.
  - did:webs now starts in-process as background HIO doers under the pytest runtime.
  - The fixture copies the live stack's `.keri` state into separate snapshot HOME roots for the artifact doers and resolver doers before launching them.
  - Resolver startup now waits on the TCP port directly instead of probing a fake `/health` path under `/1.0/identifiers`.
- Why:
  - Breakpoints in did:webs library code were not firing because the old fixture executed `dws` in a separate child process against installed `site-packages` paths.
  - A naive in-process refactor immediately hit LMDB's same-process "environment is already open" restriction because the main test workflow, artifact service, and resolver service all tried to reopen the same qvi keystore path.
  - Separate snapshot homes preserve in-process debuggability without giving the long-lived did:webs services ownership over the same LMDB environment as the mutable workflow.
- Tests:
  - `./.venv/bin/python -m py_compile tests/integration/conftest.py tests/integration/helpers.py`
  - `./.venv/bin/python -m pytest tests/integration/test_single_sig_vrd_isomer.py -q -k test_single_sig_vrd_isomer_live -s --tb=line`
- Contracts/plans touched:
  - `.agents/PROJECT_LEARNINGS.md`
- Risks and TODOs:
  - did:webs now shares the pytest runtime for debugging, but it serves from a snapshot of the live stack's `.keri` state rather than the mutable primary keystore.
  - This is acceptable for current DID resolution because the identifier state is stable before launch, but it would be the wrong model if later test phases required live identifier mutations after did:webs startup.

### 2026-03-31 - Stock KERIpy Doers Should Own Their Cleanup

- What changed:
  - `isomer` stopped using local managed copies of the KERIpy registry, credential issuance, grant, and admit doers.
  - KERIpy stock doers were patched to retain explicit ownership of `Notifier` instances and to close their `Noter`, `Regery`, and `Habery` resources on outer scheduler exit.
  - KERIpy `RegistryInceptor` was patched to stop forwarding hio-injected `temp` into `Registry.make(...)`.
  - KERIpy `CredentialIssuer` was patched to remove its long-lived subdoers after successful issuance so the doer can actually complete.
  - The isomer live test was updated to resolve recipient-side incoming grants by `credential_said + sender_prefix` before admit instead of assuming the sender-side returned grant exchange SAID is immediately the recipient-local admit handle.
- Why:
  - Hidden `Notifier` ownership in KERIpy stock doers caused real LMDB leaks and forced `isomer` into temporary local wrapper doers.
  - The right fix was to repair ownership and completion semantics in KERIpy and then rely on the stock doers again.
  - The live workflow also showed that recipient-side admit must correlate to the recipient-visible incoming grant exchange, not just the sender-side immediately returned exchange SAID.
- Tests:
  - `python -m py_compile` on the patched KERIpy doer modules and `tests/integration/kli_flow.py`
  - `uv run pytest tests/test_profile.py tests/test_jwt.py tests/test_status.py tests/test_verifier.py -q`
  - Repeated live runs of `uv run pytest tests/integration/test_single_sig_vrd_isomer.py -q -s`
- Contracts/plans touched:
  - `AGENTS.md`
  - `.agents/PROJECT_LEARNINGS.md`
- Risks and TODOs:
  - The live integration flow now gets materially further on stock KERIpy doers, but it is still not fully green; continue driving the next blocking condition from live runs instead of reintroducing local managed doers.
  - Upstream the KERIpy cleanup and completion fixes as PRs instead of letting them remain only in the local checkout.

### 2026-03-31 - Schema Fixes Must Not Land as KERIpy Special Cases

- What changed:
  - The VRD Auth schema workaround was removed from KERIpy core validation.
  - The VRD Auth schema was fixed at the schema source to define `AID` directly instead of relying on a validator-side property injection.
  - The corrected schema was re-SAIDified, producing a new canonical VRD Auth schema SAID: `EFiYsVADHXcn1BZirDRH301Rm12301povihg5UMIYkfc`.
  - `isomer` constants, fixtures, and integration references were updated to the new SAID.
- Why:
  - Product-specific behavior in KERIpy core is the wrong layer and hides schema defects instead of fixing them honestly.
  - Because schemas are content-addressed, any schema body change that is not re-SAIDified is a lie.
- Tests:
  - `uv run pytest tests/test_profile.py tests/test_jwt.py tests/test_status.py tests/test_verifier.py -q`
- Contracts/plans touched:
  - `AGENTS.md`
  - `.agents/PROJECT_LEARNINGS.md`
- Risks and TODOs:
  - The old VRD Auth schema artifact still exists as a historical file and may still be referenced by external repos until they migrate.
  - The live integration flow should be rerun against the new schema SAID once the in-process doer path is stable again.

### 2026-03-31 - Workflow Commands Should Run In-Process

- What changed:
  - The project now records a hard rule that KERI workflow steps should not be orchestrated through `kli` subprocesses when the equivalent KERIpy doers or library APIs are available directly.
  - Subprocesses remain appropriate for long-lived services like witnesses, `vLEI-server`, and `did-webs-resolver`.
  - Integration helpers should prefer in-process doer execution and direct state inspection over parsing CLI output.
- Why:
  - Subprocess-driven KLI orchestration introduces avoidable races, obscures internal state, and makes debugging harder even though the underlying logic already exists as importable KERIpy code.
  - The correct harness boundary is service processes out-of-process and workflow logic in-process.
- Tests:
  - The live-stack harness exposed multiple issues that were harder to diagnose because workflow steps were mediated through `kli` subprocesses.
- Contracts/plans touched:
  - `AGENTS.md`
- Risks and TODOs:
  - Refactor `tests/integration/kli_flow.py` to replace `kli` subprocess orchestration with direct KERIpy doers and library calls.

### 2026-03-26 - Demo Signers Explicitly Banned

- What changed:
  - The project now records a hard rule that demo signers are not allowed.
  - CLI issuance and presentation flows are expected to open live KERI
    habitats, not standalone deterministic signers.
  - Tests should build real temporary habitats through KERI APIs when
    deterministic behavior is needed.
- Why:
  - An isomer project that bypasses live habitat signers will drift away from
    the exact interoperability story it is supposed to prove.
- Tests:
  - KERI-backed JWT tests and verifier tests now create real temporary habitats
    instead of constructing convenience signers directly.
- Contracts/plans touched:
  - `AGENTS.md`
  - `docs/design-docs/PROJECT_LEARNINGS.md`
  - `plans/w3c-vrd-isomer-plan.md`
- Risks and TODOs:
  - Wire the live habitat signer path into the first true end-to-end workflow
    using wallet/KLI state instead of fixture-only inputs.
