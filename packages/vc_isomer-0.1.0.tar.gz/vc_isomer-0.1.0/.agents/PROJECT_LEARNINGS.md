# PROJECT_LEARNINGS (Index)

## Purpose

Top-level routing and durable cross-topic memory for `isomer`.

Use this file to:

1. identify current focus areas,
2. locate the right topic learnings doc(s),
3. capture only the highest-signal cross-topic state,
4. apply consistent handoff updates without duplicating topic detail.

## Current Focus

1. Establish the first true end-to-end ACDC -> W3C VRD isomer flow.
2. Keep `did-webs-resolver` mandatory for W3C key-state verification.
3. Enforce live KERI habitat signers everywhere and ban demo signers.
4. Refactor integration workflow helpers away from `kli` subprocess orchestration and toward in-process KERIpy doers.

## Topic Learnings Index

| Topic | File | Scope |
| ----- | ---- | ----- |
| Signing and Issuance | `.agents/learnings/PROJECT_LEARNINGS_SIGNING_AND_ISSUANCE.md` | Habitat signer policy, issuance seams, runtime vs test signer rules |

## Context Pack Policy

At session start:

1. Read `AGENTS.md`.
2. Read this file.
3. Read only the topic doc(s) relevant to the requested task.
4. Read any plan docs referenced by those topic docs.

## Cross-Topic Snapshot

1. Deterministic demo signers are banned in this repo.
2. Runtime and integration signing must use live KLI/KERIpy habitat signers.
3. Test determinism is acceptable only through KERI-managed salt or passcode
   inputs that create real temporary habitats.
4. `did-webs-resolver` is a hard dependency for W3C verification; verifier key
   lookup must not bypass it.
5. `w3c-signer` is legacy reference material, not the production base for this
   project.
6. Long-lived services may run as subprocesses, but KERI workflow steps should
   run in-process through KERIpy doers or library APIs.
7. Maintainer-facing Python code in both `src/` and `tests/` should use concise
   Google-style docstrings; integration helpers and fixtures are first-class
   maintenance surfaces, not second-tier code.
8. Product-specific schema defects must be fixed at the schema layer, not by
   adding schema-SAID-specific behavior to KERIpy core validation.
9. Any schema body change must be re-SAIDified and all consuming constants,
   fixtures, and docs must be updated to the new schema SAID.
10. Prefer stock KERIpy doers over isomer-managed copies; if stock doers leak
    owned resources or fail to complete cleanly, fix KERIpy and upstream the
    bugfix instead of growing a permanent parallel doer layer in isomer.
11. For live-stack or service debugging, use low-output diagnosis first: short
    pytest tracebacks, 20-40 line source slices, and narrowly targeted log
    reads instead of broad dumps.
12. Verifier operation metadata is intentionally minimal for the PoC; avoid
    reintroducing request correlation, event timelines, or trace logs unless
    the project explicitly commits to a production observability design.
13. In-process `did:webs` debugging should run artifact and resolver as
    background HIO doers inside the pytest runtime, but each long-lived doer
    set needs its own snapshot HOME/`.keri` tree to avoid same-process LMDB
    open collisions with the main workflow or with each other.
14. Project identity is Isomer, but packaging now uses a three-name split:
    PyPI/pip distribution `vc-isomer`, Python import package `vc_isomer`, and
    CLI entrypoint `isomer`. Profile/provenance field, pair-verification result
    kind, operation storage prefix, docs, tests, and placeholders remain
    Isomer-branded; legacy import compatibility aliases are intentionally not
    preserved.
15. Publishing is Makefile-driven with `uv build`, `twine check` via `uvx`, and
    guarded `uv publish` targets for TestPyPI and PyPI. Upload targets require
    a clean worktree unless `ALLOW_DIRTY=1` is explicitly set.

## Handoff Template

When updating a topic learnings doc, capture:

1. What changed
2. Why it changed
3. Tests or verification used
4. Contracts or plans touched
5. Risks and TODOs
