# isomer_cli

CLI entrypoints for issuing, presenting, verifying, revoking, and serving
isomer resources.

The current Python implementation lives in `src/vc_isomer/cli.py`.

