# w3c_verifier

W3C verifier service for direct `vc+jwt`, direct `vp+jwt`, and dual
isomer verification.

The current Python implementation lives in `src/vc_isomer/service.py` and
`src/vc_isomer/verifier.py`.

