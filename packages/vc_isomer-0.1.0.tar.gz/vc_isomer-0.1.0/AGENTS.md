# isomer Working Instructions

## Purpose

Assist W3C and ACDC integration with the verifiable reference data (VRD) ACDC schema set.
This is an integration project and a showcase of using W3C and ACDC together. This AGENTS.md helps
keep isomer work consistent, low-drift, and decision-traceable across ACDC, W3C VC-JWT, 
did:webs resolution, status projection, issue-hold-verify workflow, and wallet integration.

## Session Start Protocol (Required)

At the start of each new task thread, read these files first:

1. `AGENTS.md` (this file)
2. `.agents/PROJECT_LEARNINGS.md`
3. Task-relevant topic learnings docs listed under "Current Focus" in
   `.agents/PROJECT_LEARNINGS.md`
4. Any task-specific plan docs referenced by those topic docs
5. As needed, refer to sibling repos:
   - `../wallet` for holder/issuer integration seams
   - `../did-webs-resolver` for DID/key-state resolution behavior
   - `../sally` for ACDC verifier behavior
   - `../w3c-signer` only as legacy reference, not as a runtime foundation
   - `../keripy` as the gold-standard Python behavior reference

Then produce:

1. A concise current-state summary
2. A concise implementation plan for the requested task

## Local Dependency Setup Rule

1. Install sibling repos that this project depends on into the `isomer` local `.venv` as editable installs instead of relying on source-root `PYTHONPATH` tricks when the dependency is used as a Python package in this repo.
2. The expected local editable installs for integration work are `../keripy` and `../did-webs-resolver`.
3. The vLEI schema service should be launched from the local `../vLEI` repo's `vLEI-server` binary and should use `VLEI_ROOT` paths for schemas, credentials, and OOBIs.
4. Repo instructions and test setup should assume those local installs or local service binaries are present when integration functionality depends on them.

## End-of-Task Handoff (Required)

For tasks where significant changes have been made, before final response,
update:

1. The appropriate topic learnings doc(s) for the task context
2. `.agents/PROJECT_LEARNINGS.md` with a concise cross-topic summary if needed. Be brief.
3. Relevant plan docs in `plans/` when assumptions, scope, or sequencing have
   materially changed

## Learnings Document Policy

Use a hierarchical memory model:

1. `.agents/PROJECT_LEARNINGS.md`: top-level routing and durable
   cross-topic memory
2. `.agents/learnings/PROJECT_LEARNINGS_*.md`: deeper topic-specific
   learnings and handoff log

## Non-Negotiable Signer Rule

1. Use KERIpy live habitats (Hab, Habery) for signing. Never use or introduce a deterministic demo signer.
2. Use stable salts, passcodes, and aliases for deterministic results.
3. If a task seems easier with a fake signer, the seam is wrong and the code must be fixed instead.

## Non-Negotiable Workflow Rule

1. Use subprocesses only for long-lived external services such as witnesses, `vLEI-server`, `did-webs-resolver`, and similar network-facing processes.
2. Do not orchestrate KERI workflow steps by shelling out to `kli` commands when equivalent KERIpy doers or library APIs are available in-process.
3. Integration workflow helpers should run KERIpy doers directly, keep state in-process, and use direct database/library inspection for assertions instead of parsing CLI stdout.
4. If a workflow step currently depends on a `kli` subprocess, treat that as transitional debt to be refactored away.
5. Prefer reusing KERIpy code or KERIpy logic directly when practical instead of lifting protocol behavior into `isomer`. Only add small local helpers when KERIpy does not expose a reusable seam.
6. Prefer stock KERIpy `Doer` and `DoDoer` classes over isomer-managed replacements. Do not create local wrapper doers unless KERIpy does not expose the owned resources that must be closed or does not provide the needed reuse seam.
7. If a local managed doer is unavoidable, keep it narrowly scoped, document exactly which hidden KERIpy-owned resources it exposes for deterministic cleanup, and treat it as integration debt rather than a new abstraction to expand.

## Documentation Standard

1. Use concise Google-style docstrings for Python modules, classes, methods, and non-trivial functions.
2. Prefer present tense and behavior-first wording. Explain why a symbol exists, what it coordinates with, and any non-obvious side effects or failure modes.
3. Do not restate obvious type information already visible in the signature unless the type needs semantic clarification.
4. Treat tests and integration helpers as maintainer-facing code: fixtures, workflow helpers, topology builders, and service shims should be documented to the same standard as runtime code.
5. For constants, prefer grouped maintainer comments over artificial docstrings.

## Tooling Simplicity Rule

1. Prefer the simplest command that solves the problem before inventing scaffolding, wrappers, or packaging workarounds.
2. For local Python dependencies, try a direct local editable install first when that fits the repo's workflow.
3. Do not add environment hacks, symlink tricks, or copied packaging internals when a straightforward command is sufficient.

## Debugging Discipline Rule

1. Default to low-output debugging for long-running service or integration failures. Do not start with full test traces, whole-file dumps, or broad log tails.
2. When running pytest for diagnosis, prefer `--tb=short` or `--tb=line` unless a full traceback is clearly necessary.
3. Read only the smallest useful slice of source first: 20-40 relevant lines. Expand only in 40-line increments if the first slice is insufficient.
4. Read only the smallest useful slice of logs first: targeted `rg` searches or short `tail` output. Do not pull full logs unless the short slice proves inadequate.
5. Treat added debug logging as temporary scaffolding. Remove or reduce it as soon as the failure boundary is isolated.
6. Before collecting more output, summarize the current hypothesis and the exact missing fact needed to confirm or falsify it.
