import numpy as np
import pandas as pd
import os
import random
from typing import List, Tuple, Dict, Optional
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold
import sys

try:
    from .preprocessing import (
        LabelProcessor,
        DatasetOrganizer,
        MultiAxisDatasetOrganizer,
        resolve_axis_data_paths,
    )
    from .advanced_splitting import StratifiedDataSplitter, CrossValidationSplitter
except ImportError:
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from preprocessing import (
        LabelProcessor,
        DatasetOrganizer,
        MultiAxisDatasetOrganizer,
        resolve_axis_data_paths,
    )
    from advanced_splitting import StratifiedDataSplitter, CrossValidationSplitter


class EnhancedDataSplitter:
    """
    增强的数据集分割器，支持CSV导出和多种分割模式
    """

    def __init__(self, data_path: str, label_path: str, config=None):
        self.data_path = data_path
        self.label_path = label_path
        self.config = config

        # 初始化处理器
        self.label_processor = LabelProcessor(label_path)
        self.organizer = self._create_organizer()

        # 获取所有患者和标签
        self.all_patients = self.organizer.get_all_patients()
        self.labels = {pid: self.label_processor.get_label(pid) for pid in self.all_patients}

        # 分割结果存储
        self.train_patients = []
        self.val_patients = []
        self.test_patients = []
        self.cv_splits = []

    def _create_organizer(self):
        multi_axis_config = getattr(self.config, 'multi_axis', None)
        if getattr(multi_axis_config, 'enabled', False):
            axis_data_paths = resolve_axis_data_paths(
                getattr(multi_axis_config, 'axis_data_paths', {}),
                base_data_path=self.data_path,
            )
            multi_axis_config.axis_data_paths = axis_data_paths
            return MultiAxisDatasetOrganizer(
                axis_data_paths=axis_data_paths,
                label_processor=self.label_processor,
                active_axes=getattr(multi_axis_config, 'active_axes', None),
                images_per_axis=getattr(multi_axis_config, 'images_per_axis', None),
            )

        return DatasetOrganizer(self.data_path, self.label_processor)

    def split_data(self, method: str = "stratified", **kwargs) -> Dict:
        """
        分割数据集

        Args:
            method: 分割方法 ("stratified", "random", "cv")
            **kwargs: 分割参数
        """
        if method == "stratified":
            return self._stratified_split(**kwargs)
        elif method == "random":
            return self._random_split(**kwargs)
        elif method == "cv":
            return self._cv_split(**kwargs)
        else:
            raise ValueError(f"不支持的分割方法: {method}")

    def _stratified_split(self, train_ratio: float = 0.75, val_ratio: float = 0.25,
                          test_ratio: float = 0.0, random_seed: int = 42) -> Dict:
        """分层分割，按配置保留训练/验证/测试集比例。"""

        splitter = StratifiedDataSplitter(random_seed=random_seed)
        self.train_patients, self.val_patients, self.test_patients = splitter.stratified_split_patients(
            self.all_patients, self.labels, train_ratio, val_ratio, test_ratio
        )

        stats = splitter.get_split_statistics(self.train_patients, self.val_patients, self.test_patients, self.labels)
        return {"method": "stratified", "splits": stats, "cv_folds": []}

    def _random_split(self, train_ratio: float = 0.8, val_ratio: float = 0.1,
                      test_ratio: float = 0.1, random_seed: int = 42) -> Dict:
        """随机分割"""
        np.random.seed(random_seed)
        np.random.shuffle(self.all_patients)

        n_patients = len(self.all_patients)
        n_train = int(n_patients * train_ratio)
        n_val = int(n_patients * val_ratio)

        self.train_patients = self.all_patients[:n_train]
        self.val_patients = self.all_patients[n_train:n_train + n_val]
        self.test_patients = self.all_patients[n_train + n_val:]

        # 计算统计信息
        def get_stats(patients, name):
            patient_labels = [self.labels[pid] for pid in patients]
            pos_count = sum(patient_labels)
            neg_count = len(patient_labels) - pos_count
            pos_ratio = pos_count / len(patient_labels) if len(patient_labels) > 0 else 0
            return {
                'total_patients': len(patients),
                'positive_patients': pos_count,
                'negative_patients': neg_count,
                'positive_ratio': pos_ratio,
                'negative_ratio': 1 - pos_ratio
            }

        stats = {
            'train': get_stats(self.train_patients, 'train'),
            'val': get_stats(self.val_patients, 'val'),
            'test': get_stats(self.test_patients, 'test'),
            'overall': get_stats(self.all_patients, 'overall')
        }

        return {"method": "random", "splits": stats, "cv_folds": []}

    def _cv_split(self, n_folds: int = 5, random_seed: int = 42) -> Dict:
        """交叉验证分割"""
        splitter = CrossValidationSplitter(n_folds=n_folds, random_seed=random_seed)
        self.cv_splits = splitter.create_cv_splits(self.all_patients, self.labels)
        cv_stats = splitter.get_cv_statistics(self.cv_splits, self.labels)

        # 对于交叉验证，使用第一折作为示例的train/val分割
        self.train_patients, self.val_patients = self.cv_splits[0]
        self.test_patients = []  # 交叉验证通常没有独立的测试集

        return {"method": "cv", "splits": cv_stats, "cv_folds": self.cv_splits}

    def export_split_to_csv(self, output_path: str, experiment_name: str = "default") -> str:
        """
        将数据集划分信息导出到CSV文件

        Returns:
            str: 导出的CSV文件路径
        """
        os.makedirs(os.path.dirname(output_path), exist_ok=True)

        split_data = []

        # 添加训练集信息
        for patient_id in self.train_patients:
            split_data.append({
                'patient_id': patient_id,
                'split': 'train',
                'label': self.labels[patient_id],
                'experiment_name': experiment_name
            })

        # 添加验证集信息
        for patient_id in self.val_patients:
            split_data.append({
                'patient_id': patient_id,
                'split': 'val',
                'label': self.labels[patient_id],
                'experiment_name': experiment_name
            })

        # 添加测试集信息（如果存在）
        for patient_id in self.test_patients:
            split_data.append({
                'patient_id': patient_id,
                'split': 'test',
                'label': self.labels[patient_id],
                'experiment_name': experiment_name
            })

        # 创建DataFrame并保存
        df = pd.DataFrame(split_data)
        df.to_csv(output_path, index=False)

        return output_path

    def export_cv_splits_to_csv(self, output_dir: str, experiment_name: str = "default") -> List[str]:
        """
        将交叉验证的所有折信息导出到CSV文件

        Returns:
            List[str]: 导出的CSV文件路径列表
        """
        os.makedirs(output_dir, exist_ok=True)
        csv_files = []

        for fold_idx, (train_patients, val_patients) in enumerate(self.cv_splits):
            fold_data = []

            # 添加训练集信息
            for patient_id in train_patients:
                fold_data.append({
                    'patient_id': patient_id,
                    'split': 'train',
                    'fold': fold_idx + 1,
                    'label': self.labels[patient_id],
                    'experiment_name': experiment_name
                })

            # 添加验证集信息
            for patient_id in val_patients:
                fold_data.append({
                    'patient_id': patient_id,
                    'split': 'val',
                    'fold': fold_idx + 1,
                    'label': self.labels[patient_id],
                    'experiment_name': experiment_name
                })

            # 保存当前折的CSV文件
            csv_path = os.path.join(output_dir, f"cv_fold_{fold_idx + 1}_split.csv")
            df = pd.DataFrame(fold_data)
            df.to_csv(csv_path, index=False)
            csv_files.append(csv_path)

        return csv_files

    @staticmethod
    def load_split_from_csv(csv_path: str) -> Dict:
        """
        从CSV文件加载数据集划分信息

        Returns:
            Dict: 包含train, val, test患者列表的字典
        """
        df = pd.read_csv(csv_path)

        splits = {
            'train': [],
            'val': [],
            'test': []
        }

        for _, row in df.iterrows():
            split_type = row['split']
            patient_id = row['patient_id']

            if split_type in splits:
                splits[split_type].append(patient_id)

        return splits

    def load_all_splits_from_csv(self, csv_path: str, logger=None) -> Dict:
        """
        从CSV文件加载所有划分（train, val, test），不进行重新划分

        Args:
            csv_path: CSV文件路径
            logger: 日志记录器

        Returns:
            Dict: 包含加载的划分信息和统计
        """
        # 使用现有的静态方法
        splits = self.load_split_from_csv(csv_path)

        # 验证患者有效性
        validated_splits = {}
        for split_name, patients in splits.items():
            validated_splits[split_name] = [
                pid for pid in patients
                if pid in self.labels
            ]

        # 设置实例变量
        self.train_patients = validated_splits['train']
        self.val_patients = validated_splits['val']
        self.test_patients = validated_splits['test']

        # 计算统计信息
        def get_split_stats(patients):
            if not patients:
                return {
                    'total_patients': 0,
                    'positive_patients': 0,
                    'negative_patients': 0,
                    'positive_ratio': 0.0,
                    'negative_ratio': 0.0
                }

            split_labels = [self.labels[pid] for pid in patients]
            positive_count = sum(split_labels)
            negative_count = len(split_labels) - positive_count
            total_count = len(split_labels)

            return {
                'total_patients': total_count,
                'positive_patients': positive_count,
                'negative_patients': negative_count,
                'positive_ratio': positive_count / total_count if total_count > 0 else 0.0,
                'negative_ratio': negative_count / total_count if total_count > 0 else 0.0
            }

        if logger:
            logger.info(f"从CSV加载所有划分: {csv_path}")
            logger.info(f"  原始 - 训练: {len(splits['train'])}, 验证: {len(splits['val'])}, 测试: {len(splits['test'])}")
            logger.info(f"  有效 - 训练: {len(validated_splits['train'])}, 验证: {len(validated_splits['val'])}, 测试: {len(validated_splits['test'])}")

        return {
            'method': 'csv_direct',
            'splits': {
                'train': get_split_stats(self.train_patients),
                'val': get_split_stats(self.val_patients),
                'test': get_split_stats(self.test_patients),
                'overall': get_split_stats(self.train_patients + self.val_patients + self.test_patients)
            },
            'csv_info': {
                'csv_path': csv_path,
                'original_train_count': len(splits['train']),
                'original_val_count': len(splits['val']),
                'original_test_count': len(splits['test']),
                'valid_train_count': len(validated_splits['train']),
                'valid_val_count': len(validated_splits['val']),
                'valid_test_count': len(validated_splits['test'])
            }
        }

    def load_from_csv(self, csv_path: str, logger=None) -> List[str]:
        """
        从CSV文件加载训练数据（仅包含split=train的数据）

        Args:
            csv_path: CSV文件路径
            logger: 日志记录器

        Returns:
            List[str]: 从CSV中提取的训练患者ID列表
        """
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"CSV文件不存在: {csv_path}")

        try:
            df = pd.read_csv(csv_path)

            # 检查必需的列
            required_columns = ['patient_id', 'split', 'label']
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise ValueError(f"CSV文件缺少必需的列: {missing_columns}")

            # 过滤训练数据
            train_df = df[df['split'] == 'train'].copy()

            if len(train_df) == 0:
                raise ValueError(f"CSV文件中没有找到split=train的数据")

            # 获取训练患者ID列表
            train_patients = train_df['patient_id'].unique().tolist()

            # 验证数据完整性
            valid_patients = []
            invalid_count = 0

            for patient_id in train_patients:
                if patient_id in self.labels:
                    valid_patients.append(patient_id)
                else:
                    invalid_count += 1
                    if logger:
                        logger.warning(f"患者 {patient_id} 在标签文件中不存在，已跳过")

            if logger:
                logger.info(f"从CSV文件加载训练数据:")
                logger.info(f"  CSV文件路径: {csv_path}")
                logger.info(f"  原始训练患者数: {len(train_patients)}")
                logger.info(f"  有效训练患者数: {len(valid_patients)}")
                if invalid_count > 0:
                    logger.warning(f"  无效患者数: {invalid_count}")

                # 统计正负样本比例
                train_labels = [self.labels[pid] for pid in valid_patients]
                positive_count = sum(train_labels)
                negative_count = len(train_labels) - positive_count
                logger.info(f"  阳性样本: {positive_count} ({positive_count/len(train_labels):.2%})")
                logger.info(f"  阴性样本: {negative_count} ({negative_count/len(train_labels):.2%})")

            return valid_patients

        except Exception as e:
            raise RuntimeError(f"加载CSV文件失败: {str(e)}")

    def resplit_loaded_data(self, train_patients: List[str], train_ratio: float = 0.8,
                           val_ratio: float = 0.2, random_seed: int = 42, logger=None) -> Dict:
        """
        将从CSV加载的训练数据重新分割为训练集和验证集

        Args:
            train_patients: 从CSV加载的训练患者列表
            train_ratio: 训练集比例
            val_ratio: 验证集比例
            random_seed: 随机种子
            logger: 日志记录器

        Returns:
            Dict: 包含分割结果的字典
        """
        if not train_patients:
            raise ValueError("训练患者列表为空")

        # 设置随机种子确保可重现性
        np.random.seed(random_seed)
        random.seed(random_seed)

        if logger:
            logger.info(f"开始重新分割CSV加载的训练数据:")
            logger.info(f"  输入训练患者数: {len(train_patients)}")
            logger.info(f"  训练集比例: {train_ratio}")
            logger.info(f"  验证集比例: {val_ratio}")
            logger.info(f"  随机种子: {random_seed}")

        # 获取标签
        train_labels = [self.labels[pid] for pid in train_patients]
        unique_labels = list(set(train_labels))

        if len(unique_labels) <= 1:
            if logger:
                logger.warning(f"训练数据只包含单一类别: {unique_labels}，无法进行分层分割，将使用随机分割")

            # 随机分割
            np.random.shuffle(train_patients)
            n_total = len(train_patients)
            n_train = int(n_total * train_ratio)

            self.train_patients = train_patients[:n_train]
            self.val_patients = train_patients[n_train:]
            self.test_patients = []
        else:
            # 使用分层分割
            splitter = StratifiedShuffleSplit(n_splits=1, test_size=val_ratio, random_state=random_seed)

            # 执行分割
            train_indices, val_indices = next(splitter.split(train_patients, train_labels))

            self.train_patients = [train_patients[i] for i in train_indices]
            self.val_patients = [train_patients[i] for i in val_indices]
            self.test_patients = []

        # 计算统计信息
        def get_split_stats(patients, split_name):
            if not patients:
                return {
                    'total_patients': 0,
                    'positive_patients': 0,
                    'negative_patients': 0,
                    'positive_ratio': 0.0,
                    'negative_ratio': 0.0
                }

            split_labels = [self.labels[pid] for pid in patients]
            positive_count = sum(split_labels)
            negative_count = len(split_labels) - positive_count
            total_count = len(split_labels)

            return {
                'total_patients': total_count,
                'positive_patients': positive_count,
                'negative_patients': negative_count,
                'positive_ratio': positive_count / total_count if total_count > 0 else 0.0,
                'negative_ratio': negative_count / total_count if total_count > 0 else 0.0
            }

        train_stats = get_split_stats(self.train_patients, 'train')
        val_stats = get_split_stats(self.val_patients, 'val')
        test_stats = get_split_stats(self.test_patients, 'test')

        if logger:
            logger.info(f"重新分割结果:")
            logger.info(f"  训练集: {train_stats['total_patients']} 患者, "
                       f"阳性 {train_stats['positive_patients']} ({train_stats['positive_ratio']:.2%})")
            logger.info(f"  验证集: {val_stats['total_patients']} 患者, "
                       f"阳性 {val_stats['positive_patients']} ({val_stats['positive_ratio']:.2%})")

        return {
            "method": "csv_resplit",
            "splits": {
                'train': train_stats,
                'val': val_stats,
                'test': test_stats,
                'overall': get_split_stats(train_patients, 'overall')
            },
            "cv_folds": [],
            "csv_info": {
                "csv_path": None,  # 将在调用时设置
                "original_train_count": len(train_patients),
                "final_train_count": len(self.train_patients),
                "final_val_count": len(self.val_patients),
                "random_seed": random_seed
            }
        }

    def save_split_info(self, output_dir: str, experiment_name: str, is_csv_direct: bool = False):
        """保存分割信息到JSON文件"""
        import json
        from datetime import datetime

        split_info = {
            'experiment_name': experiment_name,
            'split_method': 'csv_direct' if is_csv_direct else 'csv_resplit',
            'train_patients': self.train_patients,
            'val_patients': self.val_patients,
            'test_patients': self.test_patients,
            'timestamp': datetime.now().isoformat()
        }

        os.makedirs(output_dir, exist_ok=True)
        split_info_path = os.path.join(output_dir, f"{experiment_name}_split_info.json")

        with open(split_info_path, 'w', encoding='utf-8') as f:
            json.dump(split_info, f, indent=2, ensure_ascii=False)

        return split_info_path

    @staticmethod
    def load_split_info(split_info_path: str) -> Dict:
        """从JSON文件加载分割信息"""
        import json

        if not os.path.exists(split_info_path):
            raise FileNotFoundError(f"分割信息文件不存在: {split_info_path}")

        with open(split_info_path, 'r', encoding='utf-8') as f:
            split_info = json.load(f)

        return split_info

    def get_reliable_cv_results(self, cv_metrics: List[float]) -> Dict:
        """
        计算交叉验证的可靠结果，包括置信区间

        Args:
            cv_metrics: 各折的指标列表

        Returns:
            Dict: 包含平均值、标准差、置信区间等的统计信息
        """
        if not cv_metrics:
            return {}

        metrics_array = np.array(cv_metrics)
        mean_val = np.mean(metrics_array)
        std_val = np.std(metrics_array)

        # 计算95%置信区间
        confidence_interval = 1.96 * (std_val / np.sqrt(len(metrics_array)))

        return {
            'mean': mean_val,
            'std': std_val,
            'min': np.min(metrics_array),
            'max': np.max(metrics_array),
            'median': np.median(metrics_array),
            'confidence_interval_95': (mean_val - confidence_interval, mean_val + confidence_interval),
            'raw_scores': cv_metrics,
            'fold_count': len(cv_metrics)
        }


def validate_split_consistency(splitter: EnhancedDataSplitter, num_trials: int = 10) -> Dict:
    """
    验证不同随机种子下的分割一致性，用于评估交叉验证的稳定性

    Args:
        splitter: 数据集分割器
        num_trials: 试验次数

    Returns:
        Dict: 一致性验证结果
    """
    results = []

    for trial in range(num_trials):
        random_seed = 42 + trial * 10  # 不同的随机种子

        # 进行分层分割
        split_result = splitter.split_data(
            method="stratified",
            random_seed=random_seed
        )

        # 记录阳性比例
        train_pos_ratio = split_result["splits"]["train"]["positive_ratio"]
        val_pos_ratio = split_result["splits"]["val"]["positive_ratio"]
        test_pos_ratio = split_result["splits"]["test"]["positive_ratio"]

        results.append({
            'trial': trial + 1,
            'random_seed': random_seed,
            'train_pos_ratio': train_pos_ratio,
            'val_pos_ratio': val_pos_ratio,
            'test_pos_ratio': test_pos_ratio
        })

    # 计算统计信息
    train_ratios = [r['train_pos_ratio'] for r in results]
    val_ratios = [r['val_pos_ratio'] for r in results]
    test_ratios = [r['test_pos_ratio'] for r in results]

    return {
        'results': results,
        'statistics': {
            'train_pos_ratio': {
                'mean': np.mean(train_ratios),
                'std': np.std(train_ratios),
                'min': np.min(train_ratios),
                'max': np.max(train_ratios)
            },
            'val_pos_ratio': {
                'mean': np.mean(val_ratios),
                'std': np.std(val_ratios),
                'min': np.min(val_ratios),
                'max': np.max(val_ratios)
            },
            'test_pos_ratio': {
                'mean': np.mean(test_ratios),
                'std': np.std(test_ratios),
                'min': np.min(test_ratios),
                'max': np.max(test_ratios)
            }
        }
    }


if __name__ == "__main__":
    # 测试增强的数据集分割器
    print("=== 测试增强的数据集分割器 ===")

    splitter = EnhancedDataSplitter("dataset/data", "dataset/label.csv")

    # 测试分层分割
    print("\n--- 分层分割测试 ---")
    result = splitter.split_data(
        method="stratified",
        train_ratio=0.8,
        val_ratio=0.1,
        test_ratio=0.1,
        random_seed=42
    )

    print("分层分割结果:")
    for split_name, stats in result["splits"].items():
        if split_name != 'overall':
            print(f"  {split_name}: {stats['total_patients']} 患者, "
                  f"阳性 {stats['positive_patients']} ({stats['positive_ratio']:.2%})")

    # 测试CSV导出
    print("\n--- CSV导出测试 ---")
    csv_path = splitter.export_split_to_csv("results/test_split.csv", "test_experiment")
    print(f"划分信息已导出到: {csv_path}")

    # 测试CSV加载
    print("\n--- CSV加载测试 ---")
    loaded_splits = EnhancedDataSplitter.load_split_from_csv(csv_path)
    print(f"加载的分割: train={len(loaded_splits['train'])}, "
          f"val={len(loaded_splits['val'])}, test={len(loaded_splits['test'])}")

    # 测试交叉验证
    print("\n--- 交叉验证测试 ---")
    cv_result = splitter.split_data(method="cv", n_folds=5, random_seed=42)
    cv_files = splitter.export_cv_splits_to_csv("results/cv_splits", "cv_test")
    print(f"交叉验证划分已导出到 {len(cv_files)} 个文件")

    # 测试一致性验证
    print("\n--- 分割一致性验证 ---")
    consistency_results = validate_split_consistency(splitter, num_trials=5)
    print("随机种子对分割结果的影响:")
    for stat_name, stats in consistency_results['statistics'].items():
        print(f"  {stat_name}: 均值={stats['mean']:.3f}, 标准差={stats['std']:.3f}, "
              f"范围=[{stats['min']:.3f}, {stats['max']:.3f}]")
