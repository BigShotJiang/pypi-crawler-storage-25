import os
import sys
import time
from typing import Dict, List, Optional, Tuple
import numpy as np
import torch
from tqdm import tqdm
import gc

try:
    # 尝试相对导入（作为包使用时）
    from .preprocessing import ImageProcessor, LabelProcessor, DatasetOrganizer
except ImportError:
    # 如果相对导入失败，尝试绝对导入（直接运行时）
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from preprocessing import ImageProcessor, LabelProcessor, DatasetOrganizer


class MemoryPreloader:
    """
    内存预加载器类

    功能：
    1. 在训练开始前一次性将所有图像数据加载到内存
    2. 训练过程中直接从内存获取数据，避免重复IO操作
    3. 支持分批预加载，控制内存使用
    4. 提供预加载进度监控和错误处理
    """

    def __init__(self,
                 data_path: str,
                 label_path: str,
                 patch_size: Tuple[int, int] = (16, 16),
                 enable_preload: bool = True,
                 batch_preload_size: Optional[int] = None,
                 verbose: bool = True):
        """
        初始化内存预加载器

        Args:
            data_path: 图像数据路径
            label_path: 标签文件路径
            patch_size: 图像补丁大小
            enable_preload: 是否启用预加载
            batch_preload_size: 分批预加载数量，None表示全部加载
            verbose: 是否显示详细信息
        """
        self.data_path = data_path
        self.label_path = label_path
        self.patch_size = patch_size
        self.enable_preload = enable_preload
        self.batch_preload_size = batch_preload_size
        self.verbose = verbose

        # 初始化处理器
        self.image_processor = ImageProcessor(patch_size=patch_size)
        self.label_processor = LabelProcessor(label_path)
        self.organizer = DatasetOrganizer(data_path, self.label_processor)

        # 预加载的数据缓存
        self.preloaded_data: Dict[str, List[np.ndarray]] = {}
        self.preloaded_images: Dict[str, np.ndarray] = {}
        self.preload_stats = {
            'total_images': 0,
            'loaded_images': 0,
            'failed_images': 0,
            'load_time': 0.0,
            'memory_usage_mb': 0.0
        }

        if self.verbose:
            print(f"内存预加载器初始化完成")
            print(f"  数据路径: {data_path}")
            print(f"  标签路径: {label_path}")
            print(f"  补丁大小: {patch_size}")
            print(f"  预加载状态: {'启用' if enable_preload else '禁用'}")

    def get_dataset_statistics(self) -> Dict:
        """获取数据集统计信息"""
        stats = self.organizer.get_dataset_statistics()

        if self.verbose:
            print(f"\n数据集统计信息:")
            print(f"  患者总数: {stats['total_patients']}")
            print(f"  图像总数: {stats['total_images']}")
            print(f"  每个患者图像数: 最小={stats['images_per_patient']['min']}, "
                  f"最大={stats['images_per_patient']['max']}, "
                  f"平均={stats['images_per_patient']['mean']:.2f}")
            print(f"  标签分布: 阴性={stats['label_distribution'][0]}, 阳性={stats['label_distribution'][1]}")

        return stats

    def estimate_memory_usage(self) -> float:
        """
        估算预加载所需的内存使用量（MB）

        Returns:
            预估内存使用量（MB）
        """
        stats = self.organizer.get_dataset_statistics()
        total_images = stats['total_images']

        # 单个补丁的内存使用量
        # float32 = 4字节，16x16像素
        single_patch_size = 16 * 16 * 4  # 字节

        # 每个图像有24个补丁
        bytes_per_image = single_patch_size * 24

        # 总字节数
        total_bytes = total_images * bytes_per_image

        # 转换为MB，考虑Python对象开销（约2倍）
        memory_mb = (total_bytes * 2) / (1024 * 1024)

        if self.verbose:
            print(f"\n内存使用估算:")
            print(f"  图像总数: {total_images}")
            print(f"  单图像大小: {bytes_per_image / 1024:.2f} KB")
            print(f"  预估内存使用: {memory_mb:.2f} MB")

        return memory_mb

    def preload_images(self, patient_ids: Optional[List[str]] = None) -> bool:
        """
        预加载图像数据到内存

        Args:
            patient_ids: 要预加载的患者ID列表，None表示加载所有患者

        Returns:
            是否成功完成预加载
        """
        if not self.enable_preload:
            if self.verbose:
                print("预加载功能已禁用，跳过内存预加载")
            return False

        start_time = time.time()

        # 确定要加载的患者
        if patient_ids is None:
            patient_ids = self.organizer.get_all_patients()

        # 收集所有需要加载的图像路径
        all_image_paths = []
        for patient_id in patient_ids:
            image_files = self.organizer.get_patient_images(patient_id)
            all_image_paths.extend(image_files)

        self.preload_stats['total_images'] = len(all_image_paths)

        if self.verbose:
            print(f"\n开始预加载图像数据...")
            print(f"  患者数量: {len(patient_ids)}")
            print(f"  图像数量: {len(all_image_paths)}")

            if self.batch_preload_size and isinstance(self.batch_preload_size, int):
                print(f"  分批大小: {self.batch_preload_size}")
                print(f"  预计批次数: {(len(all_image_paths) + self.batch_preload_size - 1) // self.batch_preload_size}")
            else:
                print(f"  分批大小: None (一次性加载所有数据)")

        # 分批预加载
        if self.batch_preload_size and isinstance(self.batch_preload_size, int):
            return self._batch_preload(all_image_paths, start_time)
        else:
            return self._single_batch_preload(all_image_paths, start_time)

    def _single_batch_preload(self, image_paths: List[str], start_time: float) -> bool:
        """单批次预加载所有图像"""
        try:
            # 使用tqdm显示进度
            for image_path in tqdm(image_paths, desc="预加载图像", disable=not self.verbose):
                if self._load_single_image(image_path):
                    self.preload_stats['loaded_images'] += 1
                else:
                    self.preload_stats['failed_images'] += 1

                    # 如果失败率太高，给出警告
                    if self.preload_stats['failed_images'] > len(image_paths) * 0.1:
                        print(f"警告: 图像加载失败率过高 ({self.preload_stats['failed_images']}/{len(image_paths)})")

            self._finalize_preload(start_time)
            return True

        except Exception as e:
            print(f"预加载过程中发生错误: {str(e)}")
            return False

    def _batch_preload(self, image_paths: List[str], start_time: float) -> bool:
        """分批预加载图像"""
        total_batches = (len(image_paths) + self.batch_preload_size - 1) // self.batch_preload_size

        for batch_idx in range(total_batches):
            start_idx = batch_idx * self.batch_preload_size
            end_idx = min(start_idx + self.batch_preload_size, len(image_paths))
            batch_paths = image_paths[start_idx:end_idx]

            if self.verbose:
                print(f"\n处理批次 {batch_idx + 1}/{total_batches} ({len(batch_paths)} 张图像)")

            # 加载当前批次
            batch_success = 0
            for image_path in tqdm(batch_paths, desc=f"批次 {batch_idx + 1}", disable=not self.verbose):
                if self._load_single_image(image_path):
                    batch_success += 1
                else:
                    self.preload_stats['failed_images'] += 1

            self.preload_stats['loaded_images'] += batch_success

            if self.verbose:
                print(f"批次 {batch_idx + 1} 完成: 成功 {batch_success}/{len(batch_paths)}")

            # 强制垃圾回收，释放临时内存
            gc.collect()

        self._finalize_preload(start_time)
        return True

    def _load_single_image(self, image_path: str) -> bool:
        """
        加载单个图像到内存

        Args:
            image_path: 图像文件路径

        Returns:
            是否加载成功
        """
        try:
            image = self.image_processor.load_image(image_path)
            normalized_image = self.image_processor.normalize_image(image)
            patches = self.image_processor.process_single_image(image_path)

            if not patches:
                return False

            # 确保数据类型正确
            patches_array = np.array(patches, dtype=np.float32)
            processed_image = np.asarray(normalized_image, dtype=np.float32).reshape(1, normalized_image.shape[0], normalized_image.shape[1])

            # 存储到内存缓存
            self.preloaded_data[image_path] = patches_array
            self.preloaded_images[image_path] = processed_image
            return True

        except Exception as e:
            if self.verbose:
                print(f"加载图像失败 {image_path}: {str(e)}")
            return False

    def _finalize_preload(self, start_time: float):
        """完成预加载，计算统计信息"""
        self.preload_stats['load_time'] = time.time() - start_time
        self.preload_stats['memory_usage_mb'] = self._calculate_memory_usage()

        if self.verbose:
            self._print_preload_summary()

    def _calculate_memory_usage(self) -> float:
        """计算实际内存使用量"""
        try:
            # 简单估算：基于预加载的数据量
            total_elements = sum(len(patches) for patches in self.preloaded_data.values())
            # 每个元素是float32（4字节），加上numpy数组开销
            memory_mb = (total_elements * 4 * 1.5) / (1024 * 1024)
            return memory_mb
        except:
            return 0.0

    def _print_preload_summary(self):
        """打印预加载摘要信息"""
        stats = self.preload_stats

        print(f"\n预加载完成!")
        print(f"  总图像数: {stats['total_images']}")
        print(f"  成功加载: {stats['loaded_images']}")
        print(f"  加载失败: {stats['failed_images']}")
        print(f"  成功率: {stats['loaded_images']/stats['total_images']*100:.2f}%")
        print(f"  加载时间: {stats['load_time']:.2f} 秒")
        print(f"  内存使用: {stats['memory_usage_mb']:.2f} MB")

        if stats['loaded_images'] > 0:
            print(f"  平均速度: {stats['loaded_images']/stats['load_time']:.2f} 图像/秒")

    def get_preloaded_patches(self, image_path: str) -> Optional[np.ndarray]:
        """
        获取预加载的图像补丁

        Args:
            image_path: 图像文件路径

        Returns:
            预处理的补丁数组，如果未预加载则返回None
        """
        if not self.enable_preload:
            return None

        return self.preloaded_data.get(image_path)

    def get_preloaded_image(self, image_path: str) -> Optional[np.ndarray]:
        """获取预加载的标准化图像张量。"""
        if not self.enable_preload:
            return None

        return self.preloaded_images.get(image_path)

    def is_preloaded(self, image_path: str) -> bool:
        """检查图像是否已预加载"""
        return image_path in self.preloaded_data

    def get_preload_statistics(self) -> Dict:
        """获取预加载统计信息"""
        return self.preload_stats.copy()

    def clear_cache(self):
        """清空预加载缓存"""
        self.preloaded_data.clear()
        self.preloaded_images.clear()
        gc.collect()
        if self.verbose:
            print("预加载缓存已清空")


def create_memory_preloader(data_path: str,
                           label_path: str,
                           patch_size: Tuple[int, int] = (16, 16),
                           enable_preload: bool = True,
                           batch_preload_size: Optional[int] = None,
                           verbose: bool = True) -> MemoryPreloader:
    """
    创建内存预加载器的便捷函数

    Args:
        data_path: 图像数据路径
        label_path: 标签文件路径
        patch_size: 图像补丁大小
        enable_preload: 是否启用预加载
        batch_preload_size: 分批预加载数量
        verbose: 是否显示详细信息

    Returns:
        配置好的MemoryPreloader实例
    """
    preloader = MemoryPreloader(
        data_path=data_path,
        label_path=label_path,
        patch_size=patch_size,
        enable_preload=enable_preload,
        batch_preload_size=batch_preload_size,
        verbose=verbose
    )

    return preloader


if __name__ == "__main__":
    # 测试内存预加载器
    print("测试内存预加载器...")

    preloader = create_memory_preloader(
        data_path="dataset/data",
        label_path="dataset/label.csv",
        enable_preload=True,
        verbose=True
    )

    # 获取数据集统计
    stats = preloader.get_dataset_statistics()

    # 估算内存使用
    memory_mb = preloader.estimate_memory_usage()

    # 执行预加载
    if preloader.preload_images():
        print("预加载测试成功!")

        # 测试获取数据
        all_patients = preloader.organizer.get_all_patients()
        if all_patients:
            test_patient = all_patients[0]
            test_images = preloader.organizer.get_patient_images(test_patient)
            if test_images:
                test_image = test_images[0]
                patches = preloader.get_preloaded_patches(test_image)
                if patches is not None:
                    print(f"测试成功: 获取到 {len(patches)} 个补丁")
                    print(f"补丁形状: {patches.shape}")
                else:
                    print("测试失败: 无法获取预加载的补丁")
    else:
        print("预加载测试失败!")
