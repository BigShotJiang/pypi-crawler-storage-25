import os
import glob

import cv2
import numpy as np
import pandas as pd
from typing import List, Tuple, Dict, Optional
import torch
from torch.utils.data import Dataset
from pathlib import Path


class ImageProcessor:
    def __init__(self,
                 patch_size: Tuple[int, int] = (16, 16),
                 normalize: bool = True,
                 mean: float = 0.5,
                 std: float = 0.5):
        self.patch_size = patch_size
        self.normalize = normalize
        self.mean = mean
        self.std = std

    def load_image(self, image_path: str) -> np.ndarray:
        try:
            image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
            if image is None:
                raise ValueError(f"无法加载图像: {image_path}")
            return image
        except Exception as e:
            raise RuntimeError(f"加载图像失败 {image_path}: {str(e)}")

    def crop_to_patches(self, image: np.ndarray) -> List[np.ndarray]:
        height, width = image.shape
        patch_h, patch_w = self.patch_size

        if height % patch_h != 0 or width % patch_w != 0:
            raise ValueError(f"图像尺寸 {height}x{width} 不能被补丁尺寸 {patch_h}x{patch_w} 整除")

        patches = []
        for i in range(0, height, patch_h):
            for j in range(0, width, patch_w):
                patch = image[i:i+patch_h, j:j+patch_w]
                patches.append(patch)

        return patches

    def normalize_image(self, image: np.ndarray) -> np.ndarray:
        image = image.astype(np.float32)
        min_val, max_val = image.min(), image.max()

        # 智能检测数据范围并选择合适的归一化方法
        if max_val <= 1.0:
            # 数据已经是 [0, 1] 范围，直接使用
            normalized = image
        elif max_val <= 255.0 and min_val >= 0:
            if max_val < 10:
                # 可能是预处理过的浮点图像，使用自适应缩放
                # 使用99%分位数作为最大值来避免极端值影响
                img_flat = image.flatten()
                p99 = np.percentile(img_flat, 99)
                if p99 > 0:
                    normalized = image / p99
                else:
                    normalized = image
            else:
                # 标准 [0, 255] 图像，正常归一化
                normalized = image / 255.0
        else:
            # 自定义范围，使用最小-最大归一化
            if max_val > min_val:
                normalized = (image - min_val) / (max_val - min_val)
            else:
                normalized = np.zeros_like(image)

        # 应用标准化
        if self.normalize:
            normalized = (normalized - self.mean) / self.std

        return normalized

    def process_single_image(self, image_path: str) -> List[np.ndarray]:
        image = self.load_image(image_path)
        normalized_image = self.normalize_image(image)
        patches = self.crop_to_patches(normalized_image)
        return patches


class LabelProcessor:
    def __init__(self, label_path: str):
        self.label_path = label_path
        self.labels = self._load_labels()

    def _load_labels(self) -> Dict[str, int]:
        try:
            df = pd.read_csv(self.label_path, header=None)
            labels = {}

            # 检查第一行是否包含标签值
            first_row = df.iloc[0]
            if len(first_row) >= 2 and str(first_row.iloc[0]) in ['0', '1'] and str(first_row.iloc[1]) in ['0', '1']:
                # 格式：第一行是标签值0,1，后续行每行有两个患者ID
                # 第一列的患者ID对应标签0（阴性），第二列的患者ID对应标签1（阳性）

                for _, row in df.iloc[1:].iterrows():
                    # 第一列：阴性样本（标签0）
                    if pd.notna(row.iloc[0]):
                        patient_id = str(row.iloc[0]).strip()
                        if patient_id and patient_id != 'nan':
                            labels[patient_id] = 0

                    # 第二列：阳性样本（标签1）
                    if pd.notna(row.iloc[1]):
                        patient_id = str(row.iloc[1]).strip()
                        if patient_id and patient_id != 'nan':
                            labels[patient_id] = 1

            else:
                # 格式：每行是患者ID和标签值
                for _, row in df.iterrows():
                    if pd.notna(row.iloc[0]) and pd.notna(row.iloc[1]):
                        patient_id = str(row.iloc[0]).strip()
                        if patient_id.lower() == 'patient_id' and str(row.iloc[1]).strip().lower() == 'label':
                            continue
                        label_value = int(row.iloc[1])
                        labels[patient_id] = label_value

            return labels
        except Exception as e:
            raise RuntimeError(f"加载标签文件失败 {self.label_path}: {str(e)}")

    def get_label(self, patient_id: str) -> Optional[int]:
        return self.labels.get(patient_id)

    def get_all_patient_ids(self) -> List[str]:
        return list(self.labels.keys())

    def get_label_distribution(self) -> Dict[int, int]:
        distribution = {0: 0, 1: 0}
        for label in self.labels.values():
            distribution[label] += 1
        return distribution


class DatasetOrganizer:
    def __init__(self, data_path: str, label_processor: LabelProcessor):
        self.data_path = data_path
        self.label_processor = label_processor
        self.patient_images = self._organize_patient_images()

    def _organize_patient_images(self) -> Dict[str, List[str]]:
        patient_images = {}
        image_files = glob.glob(os.path.join(self.data_path, "*.png"))

        for image_file in image_files:
            filename = os.path.basename(image_file)
            patient_id = self._extract_patient_id(filename)

            if patient_id not in patient_images:
                patient_images[patient_id] = []
            patient_images[patient_id].append(image_file)

        for patient_id in list(patient_images.keys()):
            if self.label_processor.get_label(patient_id) is None:
                print(f"警告: 患者ID {patient_id} 没有对应的标签，将被跳过")
                del patient_images[patient_id]

        return patient_images

    def _extract_patient_id(self, filename: str) -> str:
        parts = filename.replace('.png', '').split('_')
        return parts[0]

    def get_patient_images(self, patient_id: str) -> List[str]:
        return self.patient_images.get(patient_id, [])

    def get_all_patients(self) -> List[str]:
        return list(self.patient_images.keys())

    def get_dataset_statistics(self) -> Dict:
        total_patients = len(self.patient_images)
        total_images = sum(len(images) for images in self.patient_images.values())

        label_dist = self.label_processor.get_label_distribution()

        stats = {
            'total_patients': total_patients,
            'total_images': total_images,
            'images_per_patient': {
                'min': min(len(images) for images in self.patient_images.values()) if self.patient_images else 0,
                'max': max(len(images) for images in self.patient_images.values()) if self.patient_images else 0,
                'mean': total_images / total_patients if total_patients > 0 else 0
            },
            'label_distribution': label_dist
        }

        return stats


class MultiAxisDatasetOrganizer:
    """多轴数据组织器，按患者和轴整理图像路径。"""

    def __init__(self,
                 axis_data_paths: Dict[str, str],
                 label_processor: LabelProcessor,
                 active_axes: Optional[List[str]] = None,
                 images_per_axis: Optional[int] = None):
        self.axis_data_paths = axis_data_paths
        self.label_processor = label_processor
        self.active_axes = active_axes or sorted(axis_data_paths.keys())
        self.images_per_axis = images_per_axis
        self.patient_axis_images = self._organize_all_axes()

    def _extract_patient_id(self, filename: str) -> str:
        return filename.replace('.png', '').split('_')[0]

    def _organize_single_axis(self, data_path: str) -> Dict[str, List[str]]:
        patient_images: Dict[str, List[str]] = {}
        image_files = sorted(glob.glob(os.path.join(data_path, "*.png")))

        for image_file in image_files:
            patient_id = self._extract_patient_id(os.path.basename(image_file))
            patient_images.setdefault(patient_id, []).append(image_file)

        return patient_images

    def _organize_all_axes(self) -> Dict[str, Dict[str, List[str]]]:
        axis_patient_maps = {
            axis: self._organize_single_axis(self.axis_data_paths[axis])
            for axis in self.active_axes
        }

        valid_patients = None
        for axis in self.active_axes:
            axis_patients = set(axis_patient_maps[axis].keys())
            valid_patients = axis_patients if valid_patients is None else valid_patients & axis_patients

        patient_axis_images: Dict[str, Dict[str, List[str]]] = {}
        for patient_id in sorted(valid_patients or []):
            if self.label_processor.get_label(patient_id) is None:
                continue

            axis_images: Dict[str, List[str]] = {}
            is_valid = True
            for axis in self.active_axes:
                image_paths = sorted(axis_patient_maps[axis].get(patient_id, []))
                if not image_paths:
                    is_valid = False
                    break
                if self.images_per_axis is not None:
                    image_paths = image_paths[:self.images_per_axis]
                axis_images[axis] = image_paths

            if is_valid:
                patient_axis_images[patient_id] = axis_images

        return patient_axis_images

    def get_patient_axis_images(self, patient_id: str, axis: str) -> List[str]:
        return self.patient_axis_images.get(patient_id, {}).get(axis, [])

    def get_patient_all_axis_images(self, patient_id: str) -> Dict[str, List[str]]:
        return self.patient_axis_images.get(patient_id, {})

    def get_all_patients(self) -> List[str]:
        return sorted(self.patient_axis_images.keys())


def resolve_axis_data_paths(axis_data_paths: Dict[str, str],
                            base_data_path: Optional[str] = None) -> Dict[str, str]:
    """Resolve multi-axis directories against the training data root when needed."""
    resolved_paths: Dict[str, str] = {}

    for axis, configured_path in axis_data_paths.items():
        candidates = [configured_path]

        if base_data_path:
            if not os.path.isabs(configured_path):
                candidates.append(os.path.join(base_data_path, configured_path))
            candidates.append(os.path.join(base_data_path, os.path.basename(configured_path)))

        resolved_path = None
        for candidate in candidates:
            normalized = os.path.normpath(candidate)
            if os.path.exists(normalized):
                resolved_path = normalized
                break

        resolved_paths[axis] = resolved_path or os.path.normpath(configured_path)

    return resolved_paths


def create_patient_splits(patients: List[str],
                         train_ratio: float = 0.8,
                         val_ratio: float = 0.1,
                         test_ratio: float = 0.1,
                         random_seed: int = 42) -> Tuple[List[str], List[str], List[str]]:
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-6, "分割比例之和必须为1"

    np.random.seed(random_seed)
    np.random.shuffle(patients)

    n_patients = len(patients)
    n_train = int(n_patients * train_ratio)
    n_val = int(n_patients * val_ratio)

    train_patients = patients[:n_train]
    val_patients = patients[n_train:n_train + n_val]
    test_patients = patients[n_train + n_val:]

    return train_patients, val_patients, test_patients


def validate_data_consistency(data_path: str, label_path: str) -> bool:
    try:
        label_processor = LabelProcessor(label_path)
        organizer = DatasetOrganizer(data_path, label_processor)

        stats = organizer.get_dataset_statistics()

        print("数据一致性检查结果:")
        print(f"  患者总数: {stats['total_patients']}")
        print(f"  图像总数: {stats['total_images']}")
        print(f"  每个患者图像数: 最小={stats['images_per_patient']['min']}, "
              f"最大={stats['images_per_patient']['max']}, "
              f"平均={stats['images_per_patient']['mean']:.2f}")
        print(f"  标签分布: 阴性={stats['label_distribution'][0]}, 阳性={stats['label_distribution'][1]}")

        if stats['total_patients'] == 0:
            print("错误: 没有有效的患者数据")
            return False

        if stats['images_per_patient']['min'] == 0:
            print("警告: 部分患者没有图像数据")

        return True

    except Exception as e:
        print(f"数据一致性检查失败: {str(e)}")
        return False


if __name__ == "__main__":
    data_path = "dataset/data"
    label_path = "dataset/label.csv"

    if validate_data_consistency(data_path, label_path):
        print("数据一致性检查通过!")

        label_processor = LabelProcessor(label_path)
        organizer = DatasetOrganizer(data_path, label_processor)

        all_patients = organizer.get_all_patients()
        train_patients, val_patients, test_patients = create_patient_splits(all_patients)

        print(f"数据集分割完成:")
        print(f"  训练集: {len(train_patients)} 个患者")
        print(f"  验证集: {len(val_patients)} 个患者")
        print(f"  测试集: {len(test_patients)} 个患者")
    else:
        print("数据一致性检查失败!")
