import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
from itertools import product
from typing import List, Tuple, Optional, Dict
import os
import sys

try:
    # 尝试相对导入（作为包使用时）
    from .preprocessing import ImageProcessor, LabelProcessor, DatasetOrganizer, MultiAxisDatasetOrganizer
    from .memory_preloader import MemoryPreloader
except ImportError:
    # 如果相对导入失败，尝试绝对导入（直接运行时）
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from preprocessing import ImageProcessor, LabelProcessor, DatasetOrganizer, MultiAxisDatasetOrganizer
    from memory_preloader import MemoryPreloader


class ViTDataset(Dataset):
    def __init__(self,
                 patient_ids: List[str],
                 organizer: DatasetOrganizer,
                 image_processor: ImageProcessor,
                 label_processor: LabelProcessor,
                 patch_size: Tuple[int, int] = (16, 16),
                 mode: str = "train",
                 memory_preloader: Optional[MemoryPreloader] = None):
        self.patient_ids = patient_ids
        self.organizer = organizer
        self.image_processor = image_processor
        self.label_processor = label_processor
        self.patch_size = patch_size
        self.mode = mode
        self.memory_preloader = memory_preloader

        self.samples = self._prepare_samples()

        # 统计信息
        self.cache_hits = 0
        self.cache_misses = 0

    def _prepare_samples(self) -> List[Tuple[str, int]]:
        samples = []
        for patient_id in self.patient_ids:
            label = self.label_processor.get_label(patient_id)
            if label is not None:
                image_files = self.organizer.get_patient_images(patient_id)
                for image_file in image_files:
                    samples.append((image_file, label))
        return samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        image_path, label = self.samples[idx]

        try:
            # 首先尝试从预加载缓存获取数据
            patches = None
            if self.memory_preloader is not None:
                preloaded_patches = self.memory_preloader.get_preloaded_patches(image_path)
                if preloaded_patches is not None:
                    patches = preloaded_patches
                    self.cache_hits += 1
                else:
                    self.cache_misses += 1
            else:
                self.cache_misses += 1

            # 如果预加载缓存中没有数据，使用传统方式加载
            if patches is None:
                patches = self.image_processor.process_single_image(image_path)

                if not patches:
                    raise ValueError(f"无法从图像 {image_path} 提取补丁")

                # 确保数据类型正确转换
                patches = np.array(patches, dtype=np.float32)

            # 转换为PyTorch张量
            patches_tensor = torch.from_numpy(patches)
            label_tensor = torch.tensor(label, dtype=torch.float32)

            return patches_tensor, label_tensor

        except Exception as e:
            print(f"处理样本失败 {image_path}: {str(e)}")
            dummy_patches = torch.zeros(24, self.patch_size[0], self.patch_size[1])
            dummy_label = torch.tensor(0.0)
            return dummy_patches, dummy_label

    def get_cache_statistics(self) -> Dict[str, int]:
        """获取缓存统计信息"""
        return {
            'cache_hits': self.cache_hits,
            'cache_misses': self.cache_misses,
            'total_accesses': self.cache_hits + self.cache_misses,
            'cache_hit_rate': self.cache_hits / (self.cache_hits + self.cache_misses) if (self.cache_hits + self.cache_misses) > 0 else 0.0
        }

    def reset_cache_statistics(self):
        """重置缓存统计信息"""
        self.cache_hits = 0
        self.cache_misses = 0


class ViTCollator:
    def __init__(self, max_patches: int = 23):
        self.max_patches = max_patches

    def __call__(self, batch: List[Tuple[torch.Tensor, torch.Tensor]]) -> Tuple[torch.Tensor, torch.Tensor]:
        patches_list = []
        labels_list = []

        for patches, label in batch:
            if patches.dim() == 3:
                n_patches = patches.size(0)
                if n_patches < self.max_patches:
                    padding = torch.zeros(self.max_patches - n_patches,
                                        patches.size(1), patches.size(2))
                    patches = torch.cat([patches, padding], dim=0)
                elif n_patches > self.max_patches:
                    patches = patches[:self.max_patches]

            patches_list.append(patches)
            labels_list.append(label)

        # 将补丁重新组合为原始图像形状
        batch_size = len(patches_list)
        reconstructed_images = []

        for patches in patches_list:
            # 动态重组图像：根据补丁数量计算图像尺寸
            # patches shape: (num_patches, 16, 16)
            num_patches = patches.size(0)
            image = torch.cat([p.unsqueeze(0) for p in patches], dim=0)  # (num_patches, 16, 16)
            image = image.transpose(0, 1).contiguous()  # (16, num_patches, 16)

            # 动态计算图像宽度
            image_width = num_patches * 16
            image = image.reshape(1, 16, image_width)  # (1, 16, image_width)
            reconstructed_images.append(image)

        # 动态计算批次形状
        if reconstructed_images:
            # 检查所有图像是否具有相同的宽度
            widths = [img.shape[2] for img in reconstructed_images]
            if len(set(widths)) > 1:
                print(f"[WARNING] 批次中图像宽度不一致: {set(widths)}")
                # 使用最小宽度避免错误
                min_width = min(widths)
                # 裁剪所有图像到最小宽度
                for i, img in enumerate(reconstructed_images):
                    if img.shape[2] > min_width:
                        reconstructed_images[i] = img[:, :, :min_width]
                final_width = min_width
            else:
                final_width = widths[0]

            patches_batch = torch.stack(reconstructed_images, dim=0)  # (batch_size, 1, 16, final_width)
        else:
            patches_batch = torch.empty(0, 1, 16, 16)  # 空张量作为默认
        labels_batch = torch.stack(labels_list, dim=0)

        return patches_batch, labels_batch


class DataLoaderManager:
    def __init__(self,
                 data_path: str,
                 label_path: str,
                 batch_size: int = 32,
                 num_workers: int = 4,
                 pin_memory: bool = True,
                 patch_size: Tuple[int, int] = (16, 16),
                 train_ratio: float = 0.8,
                 val_ratio: float = 0.1,
                 test_ratio: float = 0.1,
                 random_seed: int = 42,
                 enable_memory_preload: bool = False,
                 preload_batch_size: Optional[int] = None,
                 preload_verbose: bool = True,
                 pre_split_patients: Optional[Dict[str, List[str]]] = None):

        self.batch_size = batch_size
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.patch_size = patch_size
        self.enable_memory_preload = enable_memory_preload
        self.preload_batch_size = preload_batch_size
        self.preload_verbose = preload_verbose

        self.label_processor = LabelProcessor(label_path)
        self.organizer = DatasetOrganizer(data_path, self.label_processor)
        self.image_processor = ImageProcessor(patch_size=patch_size)

        # 使用预分割的患者列表或进行新分割
        if pre_split_patients is not None:
            self.train_patients = pre_split_patients.get('train', [])
            self.val_patients = pre_split_patients.get('val', [])
            self.test_patients = pre_split_patients.get('test', [])
        else:
            all_patients = self.organizer.get_all_patients()
            self.train_patients, self.val_patients, self.test_patients = self._split_patients(
                all_patients, train_ratio, val_ratio, test_ratio, random_seed
            )

        self.collator = ViTCollator(max_patches=23)

        # 初始化内存预加载器
        self.memory_preloader = None
        if self.enable_memory_preload:
            self._initialize_memory_preloader()

    def _initialize_memory_preloader(self):
        """初始化内存预加载器"""
        try:
            self.memory_preloader = MemoryPreloader(
                data_path=self.organizer.data_path,
                label_path=self.label_processor.label_path,
                patch_size=self.patch_size,
                enable_preload=self.enable_memory_preload,
                batch_preload_size=self.preload_batch_size,
                verbose=self.preload_verbose
            )

            # 预加载所有患者数据
            all_patients = self.train_patients + self.val_patients + self.test_patients
            if all_patients:
                self.memory_preloader.preload_images(all_patients)

        except Exception as e:
            print(f"初始化内存预加载器失败: {str(e)}")
            print("将回退到传统数据加载模式")
            self.memory_preloader = None
            self.enable_memory_preload = False

    def _split_patients(self,
                       patients: List[str],
                       train_ratio: float,
                       val_ratio: float,
                       test_ratio: float,
                       random_seed: int) -> Tuple[List[str], List[str], List[str]]:
        np.random.seed(random_seed)
        np.random.shuffle(patients)

        n_patients = len(patients)
        n_train = int(n_patients * train_ratio)
        n_val = int(n_patients * val_ratio)

        train_patients = patients[:n_train]
        val_patients = patients[n_train:n_train + n_val]
        test_patients = patients[n_train + n_val:]

        return train_patients, val_patients, test_patients

    def get_train_dataset(self, memory_preloader: Optional[MemoryPreloader] = None) -> ViTDataset:
        return ViTDataset(
            patient_ids=self.train_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="train",
            memory_preloader=memory_preloader
        )

    def get_val_dataset(self, memory_preloader: Optional[MemoryPreloader] = None) -> ViTDataset:
        return ViTDataset(
            patient_ids=self.val_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="val",
            memory_preloader=memory_preloader
        )

    def get_test_dataset(self, memory_preloader: Optional[MemoryPreloader] = None) -> ViTDataset:
        return ViTDataset(
            patient_ids=self.test_patients,
            organizer=self.organizer,
            image_processor=self.image_processor,
            label_processor=self.label_processor,
            patch_size=self.patch_size,
            mode="test",
            memory_preloader=memory_preloader
        )

    def get_train_dataloader(self) -> DataLoader:
        dataset = self.get_train_dataset(self.memory_preloader)

        # 如果启用预加载，可以减少worker数量，因为数据已经在内存中
        effective_num_workers = 0 if self.enable_memory_preload else self.num_workers

        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=effective_num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=True
        )

    def get_val_dataloader(self) -> DataLoader:
        dataset = self.get_val_dataset(self.memory_preloader)

        # 如果启用预加载，可以减少worker数量
        effective_num_workers = 0 if self.enable_memory_preload else self.num_workers

        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=effective_num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=False
        )

    def get_test_dataloader(self) -> DataLoader:
        dataset = self.get_test_dataset(self.memory_preloader)

        # 如果启用预加载，可以减少worker数量
        effective_num_workers = 0 if self.enable_memory_preload else self.num_workers

        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=effective_num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=False
        )

    def get_dataset_info(self) -> Dict:
        train_dataset = self.get_train_dataset()
        val_dataset = self.get_val_dataset()
        test_dataset = self.get_test_dataset()

        train_labels = [sample[1] for sample in train_dataset.samples]
        val_labels = [sample[1] for sample in val_dataset.samples]
        test_labels = [sample[1] for sample in test_dataset.samples]

        info = {
            'train': {
                'patients': len(self.train_patients),
                'samples': len(train_dataset),
                'positive_samples': sum(train_labels),
                'negative_samples': len(train_labels) - sum(train_labels)
            },
            'val': {
                'patients': len(self.val_patients),
                'samples': len(val_dataset),
                'positive_samples': sum(val_labels),
                'negative_samples': len(val_labels) - sum(val_labels)
            },
            'test': {
                'patients': len(self.test_patients),
                'samples': len(test_dataset),
                'positive_samples': sum(test_labels),
                'negative_samples': len(test_labels) - sum(test_labels)
            }
        }

        return info


class MultiAxisCombinationDataset(Dataset):
    def __init__(self,
                 patient_ids: List[str],
                 organizer: MultiAxisDatasetOrganizer,
                 label_processor: LabelProcessor,
                 active_axes: Optional[List[str]] = None,
                 image_processor: Optional[ImageProcessor] = None):
        self.patient_ids = patient_ids
        self.organizer = organizer
        self.label_processor = label_processor
        self.active_axes = active_axes or organizer.active_axes
        self.image_processor = image_processor or ImageProcessor(patch_size=(16, 16))
        self.samples = self._prepare_samples()

    def _prepare_samples(self):
        samples = []
        for patient_id in self.patient_ids:
            axis_images = self.organizer.get_patient_all_axis_images(patient_id)
            if not axis_images:
                continue

            axis_index_ranges = [range(len(axis_images[axis])) for axis in self.active_axes]
            for combo_index in product(*axis_index_ranges):
                image_paths = {
                    axis: axis_images[axis][image_index]
                    for axis, image_index in zip(self.active_axes, combo_index)
                }
                samples.append((patient_id, combo_index, image_paths))
        return samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx):
        patient_id, combo_index, image_paths = self.samples[idx]
        axis_tensors = {}
        for axis in self.active_axes:
            image = self.image_processor.load_image(image_paths[axis])
            image = self.image_processor.normalize_image(image)
            image = np.asarray(image, dtype=np.float32).reshape(1, image.shape[0], image.shape[1])
            axis_tensors[axis] = torch.from_numpy(image)

        label = self.label_processor.get_label(patient_id)
        label_tensor = torch.tensor(label, dtype=torch.float32)
        return axis_tensors, label_tensor, patient_id, combo_index, image_paths


class MultiAxisCollator:
    def __call__(self, batch):
        axis_batches: Dict[str, List[torch.Tensor]] = {}
        labels = []
        patient_ids = []
        combo_indices = []
        image_paths = []

        for axis_images, label, patient_id, combo_index, sample_paths in batch:
            for axis, tensor in axis_images.items():
                axis_batches.setdefault(axis, []).append(tensor)
            labels.append(label)
            patient_ids.append(patient_id)
            combo_indices.append(combo_index)
            image_paths.append(sample_paths)

        stacked_axis_batches = {
            axis: torch.stack(tensors, dim=0)
            for axis, tensors in axis_batches.items()
        }
        labels_batch = torch.stack(labels, dim=0)
        return stacked_axis_batches, labels_batch, patient_ids, combo_indices, image_paths


class MultiAxisDataLoaderManager:
    def __init__(self,
                 axis_data_paths: Dict[str, str],
                 label_path: str,
                 batch_size: int = 32,
                 num_workers: int = 4,
                 pin_memory: bool = True,
                 active_axes: Optional[List[str]] = None,
                 images_per_axis: int = 4,
                 train_ratio: float = 0.8,
                 val_ratio: float = 0.1,
                 test_ratio: float = 0.1,
                 random_seed: int = 42,
                 enable_memory_preload: bool = False,
                 preload_batch_size: Optional[int] = None,
                 preload_verbose: bool = True,
                 pre_split_patients: Optional[Dict[str, List[str]]] = None):
        self.axis_data_paths = axis_data_paths
        self.label_path = label_path
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.pin_memory = pin_memory
        self.active_axes = active_axes or sorted(axis_data_paths.keys())
        self.images_per_axis = images_per_axis
        self.enable_memory_preload = enable_memory_preload
        self.preload_batch_size = preload_batch_size
        self.preload_verbose = preload_verbose

        self.label_processor = LabelProcessor(label_path)
        self.organizer = MultiAxisDatasetOrganizer(
            axis_data_paths=axis_data_paths,
            label_processor=self.label_processor,
            active_axes=self.active_axes,
            images_per_axis=images_per_axis,
        )
        self.image_processor = ImageProcessor(patch_size=(16, 16))
        self.collator = MultiAxisCollator()

        if pre_split_patients is not None:
            self.train_patients = pre_split_patients.get('train', [])
            self.val_patients = pre_split_patients.get('val', [])
            self.test_patients = pre_split_patients.get('test', [])
        else:
            all_patients = self.organizer.get_all_patients()
            self.train_patients, self.val_patients, self.test_patients = self._split_patients(
                all_patients, train_ratio, val_ratio, test_ratio, random_seed
            )

    def _split_patients(self,
                       patients: List[str],
                       train_ratio: float,
                       val_ratio: float,
                       test_ratio: float,
                       random_seed: int) -> Tuple[List[str], List[str], List[str]]:
        np.random.seed(random_seed)
        shuffled_patients = patients.copy()
        np.random.shuffle(shuffled_patients)

        n_patients = len(shuffled_patients)
        n_train = int(n_patients * train_ratio)
        n_val = int(n_patients * val_ratio)

        train_patients = shuffled_patients[:n_train]
        val_patients = shuffled_patients[n_train:n_train + n_val]
        test_patients = shuffled_patients[n_train + n_val:]
        return train_patients, val_patients, test_patients

    def _build_dataset(self, patient_ids: List[str]) -> MultiAxisCombinationDataset:
        return MultiAxisCombinationDataset(
            patient_ids=patient_ids,
            organizer=self.organizer,
            label_processor=self.label_processor,
            active_axes=self.active_axes,
            image_processor=self.image_processor,
        )

    def get_train_dataloader(self) -> DataLoader:
        return DataLoader(
            self._build_dataset(self.train_patients),
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=True,
        )

    def get_val_dataloader(self) -> DataLoader:
        return DataLoader(
            self._build_dataset(self.val_patients),
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=False,
        )

    def get_test_dataloader(self) -> DataLoader:
        return DataLoader(
            self._build_dataset(self.test_patients),
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=self.pin_memory,
            collate_fn=self.collator,
            drop_last=False,
        )


def create_dataloaders(data_path: str,
                      label_path: str,
                      batch_size: int = 32,
                      num_workers: int = 4,
                      patch_size: Tuple[int, int] = (16, 16),
                      train_ratio: float = 0.8,
                      val_ratio: float = 0.1,
                      test_ratio: float = 0.1) -> Tuple[DataLoader, DataLoader, DataLoader]:
    manager = DataLoaderManager(
        data_path=data_path,
        label_path=label_path,
        batch_size=batch_size,
        num_workers=num_workers,
        patch_size=patch_size,
        train_ratio=train_ratio,
        val_ratio=val_ratio,
        test_ratio=test_ratio
    )

    train_loader = manager.get_train_dataloader()
    val_loader = manager.get_val_dataloader()
    test_loader = manager.get_test_dataloader()

    info = manager.get_dataset_info()
    print("数据集信息:")
    for split, split_info in info.items():
        print(f"  {split.upper()}:")
        print(f"    患者: {split_info['patients']}")
        print(f"    样本: {split_info['samples']}")
        print(f"    阳性: {split_info['positive_samples']}")
        print(f"    阴性: {split_info['negative_samples']}")

    return train_loader, val_loader, test_loader


if __name__ == "__main__":
    train_loader, val_loader, test_loader = create_dataloaders(
        data_path="dataset/data",
        label_path="dataset/label.csv",
        batch_size=8,
        num_workers=0,
        patch_size=(16, 16)
    )

    print(f"训练批次数: {len(train_loader)}")
    print(f"验证批次数: {len(val_loader)}")
    print(f"测试批次数: {len(test_loader)}")

    for batch_idx, (patches, labels) in enumerate(train_loader):
        print(f"批次 {batch_idx}:")
        print(f"  图像补丁形状: {patches.shape}")
        print(f"  标签形状: {labels.shape}")
        print(f"  标签值: {labels[:5]}")
        if batch_idx == 0:
            break
