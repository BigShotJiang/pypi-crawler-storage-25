"""Package-safe training execution wrapper."""

from src.cli.train_impl import execute_train_args
