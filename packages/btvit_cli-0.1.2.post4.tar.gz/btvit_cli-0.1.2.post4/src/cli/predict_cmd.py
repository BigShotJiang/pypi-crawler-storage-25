"""Typer command for simplified checkpoint-driven prediction."""

from typing import Optional

import typer

from src.cli.predict_runner import execute_predict_args


PRED_HELP = (
    "使用训练生成的 checkpoint 执行患者级多轴预测。\n\n"
    "支持两种 --data 输入布局：\n"
    "1. 一个根目录，内部固定包含 data-x/、data-y/、data-z/\n"
    "2. 一个包含 xyz 所有轴 PNG 的平铺目录，文件命名必须为 "
    "{patient_id}_{Z}_{Y}_{X}.png\n\n"
    "--label 接受的 CSV 表头支持 patient_id,label 或 0,1。\n"
    "--thresholds 接受 single float，用于覆盖 checkpoint 中记录的预测阈值。"
)


def execute_predict(**kwargs):
    return execute_predict_args(kwargs)


def predict_command(
    model: str = typer.Option(
        ...,
        "--model",
        help="训练生成的 checkpoint 路径。checkpoint 内需包含完整 config 快照。",
    ),
    data: str = typer.Option(
        ...,
        "--data",
        help=(
            "预测数据目录。支持 data-x/data-y/data-z 根目录，或平铺目录文件名 "
            "{patient_id}_{Z}_{Y}_{X}.png。"
        ),
    ),
    output: str = typer.Option(
        "output",
        "--output",
        help="预测结果输出目录。默认在当前命令目录下生成 output/。",
    ),
    label: Optional[str] = typer.Option(
        None,
        "--label",
        help="可选标签 CSV，表头支持 patient_id,label 或 0,1。",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="显示与 predict.py 一致的实时进度条；未提供时仅在结束后输出总结。",
    ),
    thresholds: Optional[float] = typer.Option(
        None,
        "--thresholds",
        help="Single float prediction threshold override for checkpoint predict_threshold.",
    ),
):
    """执行纯 checkpoint 驱动预测。"""
    execute_predict(
        model=model,
        data=data,
        output=output,
        label=label,
        verbose=verbose,
        thresholds=thresholds,
    )


predict_command.__doc__ = PRED_HELP
