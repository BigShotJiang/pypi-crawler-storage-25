"""Typer command for training."""

from typing import Optional

import typer

from src.cli.train_runner import execute_train_args


def execute_train(**kwargs):
    return execute_train_args(kwargs)


def train_command(
    config_path: str = typer.Option(
        ...,
        "--config",
        help="YAML配置目录路径。目录内应包含训练所需的全部配置文件。",
    ),
    data_path: str = typer.Option(
        "dataset/data",
        "--data",
        help="训练数据目录路径。用于单轴训练输入根目录；多轴训练会结合 multi_axis_config.yaml 中的 axis_data_paths 使用。",
    ),
    label_path: str = typer.Option(
        "dataset/label.csv",
        "--label",
        help="标签CSV路径。表头必须为 patient_id,label。",
    ),
    experiment_name: Optional[str] = typer.Option(
        None,
        "--experiment-name",
        help="实验名称覆盖项。若提供，将覆盖 experiment_config.yaml 中的名称。",
    ),
    random_seed: Optional[int] = typer.Option(
        None,
        "--random-seed",
        help="随机种子覆盖项，仅保留 stratified 训练主线。",
    ),
    epochs: Optional[int] = typer.Option(None, help="训练轮数覆盖项。"),
    batch_size: Optional[int] = typer.Option(None, "--batch-size", help="批次大小覆盖项。"),
    device: Optional[str] = typer.Option(None, help="训练设备覆盖项，如 cpu 或 cuda。"),
    verbose: bool = typer.Option(False, "--verbose", help="显示与 train.py 一致的实时进度条。"),
    resume: bool = typer.Option(
        False,
        "--resume",
        help="恢复训练，默认从 latest_model.pth 继续。",
    ),
    disable_memory_preload: bool = typer.Option(
        False,
        "--disable-memory-preload",
        help="关闭默认启用的 memory preload。",
    ),
    preload_batch_size: Optional[int] = typer.Option(
        None,
        "--preload-batch-size",
        help="预加载批次大小覆盖项。",
    ),
    train_split_csv: Optional[str] = typer.Option(
        None,
        "--train-split-csv",
        help="预分割CSV路径，仅用于 stratified 训练主线。",
    ),
    csv_split_seed: Optional[int] = typer.Option(
        None,
        "--csv-split-seed",
        help="CSV重新划分随机种子。",
    ),
    use_csv_direct: bool = typer.Option(
        False,
        "--use-csv-direct",
        help="直接使用CSV中的 split 结果，不进行重新划分。",
    ),
    pre_model: Optional[str] = typer.Option(None, "--pre-model", help="预训练模型路径。"),
    freeze_layers: Optional[str] = typer.Option(None, "--freeze-layers", help="冻结层配置。"),
    freeze_ratio: Optional[float] = typer.Option(None, "--freeze-ratio", help="冻结比例。"),
    load_weights_only: bool = typer.Option(False, "--load-weights-only", help="仅加载模型权重。"),
    strict_load: bool = typer.Option(False, "--strict-load", help="严格加载预训练权重。"),
    loss_type: Optional[str] = typer.Option(
        None,
        "--loss-type",
        help="损失函数类型: bce, focal, bce_label_smoothing。",
    ),
    focal_alpha: Optional[float] = typer.Option(
        None,
        "--focal-alpha",
        help="Focal Loss alpha (与 --loss-type focal 配合使用)。",
    ),
    focal_gamma: Optional[float] = typer.Option(
        None,
        "--focal-gamma",
        help="Focal Loss gamma (与 --loss-type focal 配合使用)。",
    ),
    label_smoothing: Optional[float] = typer.Option(
        None,
        "--label-smoothing",
        help="标签平滑系数 (与 --loss-type bce_label_smoothing 配合使用)。",
    ),
    pos_weight: Optional[float] = typer.Option(
        None,
        "--pos-weight",
        help="正样本权重。-1=自动计算, >0=手动指定。",
    ),
):
    """训练模型，仅支持 stratified 主线。"""
    execute_train(
        config_path=config_path,
        data_path=data_path,
        label_path=label_path,
        experiment_name=experiment_name,
        random_seed=random_seed,
        epochs=epochs,
        batch_size=batch_size,
        device=device,
        verbose=verbose,
        resume="latest" if resume else None,
        disable_memory_preload=disable_memory_preload,
        preload_batch_size=preload_batch_size,
        train_split_csv=train_split_csv,
        csv_split_seed=csv_split_seed,
        use_csv_direct=use_csv_direct,
        pre_model=pre_model,
        freeze_layers=freeze_layers,
        freeze_ratio=freeze_ratio,
        load_weights_only=load_weights_only,
        strict_load=strict_load,
    )
