"""Shared helpers for CLI commands."""

import shutil
from pathlib import Path


def resolve_output_dir(path: str | None) -> Path:
    if path:
        return Path(path).resolve()
    return Path.cwd().resolve()


def parse_axis_filename(filename: str) -> tuple[str, str, str, str]:
    stem = Path(filename).stem
    parts = stem.split("_")
    if len(parts) < 4:
        raise ValueError(f"invalid png filename: {filename}")
    patient_id = "_".join(parts[:-3])
    z_index, y_index, x_index = parts[-3:]
    if not patient_id:
        raise ValueError(f"invalid patient id in filename: {filename}")
    return patient_id, z_index, y_index, x_index


def infer_axis_from_filename(filename: str) -> str:
    _, z_index, y_index, x_index = parse_axis_filename(filename)
    axis_flags = {
        "z": int(z_index) != 0,
        "y": int(y_index) != 0,
        "x": int(x_index) != 0,
    }
    active_axes = [axis for axis, active in axis_flags.items() if active]
    if len(active_axes) != 1:
        raise ValueError(
            f"cannot infer axis from filename {filename}; exactly one of Z/Y/X indices must be non-zero"
        )
    return active_axes[0]


def normalize_prediction_data_layout(data_root: str, workspace_dir: Path) -> dict[str, str]:
    root = Path(data_root).expanduser().resolve()
    direct_axis_paths = {
        "x": root / "data-x",
        "y": root / "data-y",
        "z": root / "data-z",
    }
    if all(path.is_dir() for path in direct_axis_paths.values()):
        return {axis: str(path) for axis, path in direct_axis_paths.items()}

    png_files = sorted(root.glob("*.png"))
    if not png_files:
        raise FileNotFoundError(f"no png files found under prediction data path: {root}")

    normalized_root = workspace_dir.expanduser().resolve()
    axis_paths = {
        "x": normalized_root / "data-x",
        "y": normalized_root / "data-y",
        "z": normalized_root / "data-z",
    }
    if normalized_root.exists():
        shutil.rmtree(normalized_root)
    for path in axis_paths.values():
        path.mkdir(parents=True, exist_ok=True)

    for png_file in png_files:
        axis = infer_axis_from_filename(png_file.name)
        shutil.copy2(png_file, axis_paths[axis] / png_file.name)

    return {axis: str(path) for axis, path in axis_paths.items()}


MODEL_CONFIG_TEMPLATE = """# model_config.yaml
# Vision Transformer model structure configuration.
model:
  # Model identifier used in logs and reports.
  name: ViTND
  # Input dimensionality. Keep 2 for PNG inputs shaped as 368x16.
  ndim: 2
  # Input image shape as [height, width].
  input_shape: [16, 368]
  # Patch size as [height, width]. Keep aligned with preprocessing.
  patch_size: [16, 16]
  # Binary classification output.
  num_classes: 1
  # Transformer embedding dimension.
  dim: 512
  # Number of transformer encoder blocks.
  depth: 6
  # Number of attention heads.
  heads: 8
  # Hidden dimension inside the MLP block.
  mlp_dim: 2048
  # PNG grayscale channel count.
  channels: 1
  # Per-head hidden size.
  dim_head: 64
  # Dropout applied in transformer blocks.
  dropout: 0.1
  # Dropout applied after patch embedding.
  emb_dropout: 0.1
  # Rotary embedding minimum frequency.
  rope_min_freq: 1.0
  # Rotary embedding maximum frequency.
  rope_max_freq: 10000.0
  # Fraction of rotary frequencies forced to zero.
  rope_p_zero_freqs: 0.0
"""


DATA_CONFIG_TEMPLATE = """# data_config.yaml
# Data loading and memory preload configuration.
data:
  # Pin CPU memory before GPU transfer.
  pin_memory: true
  # Enable memory preload by default. Disable from CLI with --disable-memory-preload.
  enable_memory_preload: true
  # Optional chunk size for staged preload. Null means preload everything at once.
  preload_batch_size: null
  # Whether preload should log detailed progress information.
  preload_verbose: true
"""


TRAINING_CONFIG_TEMPLATE = """# training_config.yaml
# Encoder supervised training configuration. Train split is stratified only.
# Total number of training epochs.
epochs: 100
# Base optimizer learning rate.
learning_rate: 0.001
# L2 weight decay coefficient applied by the optimizer.
weight_decay: 0.01
# Optimizer name.
# Supported: AdamW (recommended), Adam, SGD.
#   AdamW / Adam  -> extra keys: betas, eps  (lr and weight_decay read from above fields)
#   SGD           -> extra keys: momentum, nesterov
optimizer: AdamW
# Learning-rate scheduler. Set empty string to disable.
# Supported schedulers and their scheduler_params keys:
#   CosineAnnealingLR           {T_max, eta_min}
#   CosineAnnealingWarmRestarts {T_0, T_mult, eta_min}
#   StepLR                       {step_size, gamma}
#   ExponentialLR                {gamma}
#   ReduceLROnPlateau            {mode, factor, patience, threshold, min_lr}
#   OneCycleLR                   {total_steps, max_lr, pct_start}
#   MultiStepLR                  {milestones, gamma}
scheduler: CosineAnnealingLR
# Scheduler keyword arguments as YAML inline map. Keys must match the chosen scheduler.
# CosineAnnealingLR:           {T_max: 100, eta_min: 1.0e-6}
# CosineAnnealingWarmRestarts: {T_0: 10, T_mult: 2, eta_min: 1.0e-6}
# StepLR:                       {step_size: 30, gamma: 0.1}
# ExponentialLR:                {gamma: 0.95}
# ReduceLROnPlateau:            {mode: min, factor: 0.1, patience: 5, min_lr: 1.0e-7}
# OneCycleLR:                   {total_steps: 1000, max_lr: 0.01, pct_start: 0.3}
# MultiStepLR:                  {milestones: [30, 60, 90], gamma: 0.1}
scheduler_params: {T_max: 100, eta_min: 1.0e-6}
# Training device.
# Supported: cuda (auto-fallback to cpu if GPU unavailable), cpu, auto.
# Also accepts cuda:0, cuda:1 to target specific GPUs.
device: cuda
# Samples per optimizer update before gradient accumulation.
batch_size: 32
# Number of dataloader worker processes.
num_workers: 8
# Enable mixed-precision training on supported hardware.
mixed_precision: true
# Maximum gradient norm. Set 0.0 to disable clipping.
gradient_clip_val: 1.0
# Number of mini-batches accumulated before optimizer.step().
accumulate_grad_batches: 1
# Emit extra batch-level debug logs during training.
debug_logging: false
# Optional checkpoint path for warm start.
# Example: checkpoints/best_model.pth. Leave empty to train from scratch.
pretrained_model_path: ""
# When true, only model weights are loaded from pretrained_model_path.
load_weights_only: false
# Require checkpoint keys to match the current model exactly.
strict_load: false
# Freezing strategy for transfer learning.
# Supported: none (train all), layers (freeze by name), ratio (freeze by fraction).
freeze_method: none
# Layer selector used when freeze_method=layers.
# Format: comma-separated layer specs. Supports ranges.
#   patch_embedding           -> freeze patch embedding layer
#   pos_embedding             -> freeze positional encoding
#   transformer               -> freeze all transformer blocks
#   transformer:0-2           -> freeze blocks 0 through 2 (inclusive)
#   transformer:0,1,2         -> freeze blocks 0, 1, 2
# Example: patch_embedding,transformer:0-2
freeze_layers: ""
# Fraction of encoder layers frozen when freeze_method=ratio. Range: 0.0 to 1.0.
freeze_ratio: 0.0
# Learning-rate multiplier applied during fine-tuning.
finetune_lr_scale: 1.0
# Enable separate learning rates for different parameter groups.
# When true, mlp_head layers use learning_rate * finetune_lr_scale.
use_differential_lr: false
# Loss function configuration.
# Controls the training loss function type and parameters.
loss:
  # Loss type: bce (default), focal, bce_label_smoothing.
  type: "bce"
  # Focal Loss alpha (used when type=focal).
  focal_alpha: 0.25
  # Focal Loss gamma (used when type=focal).
  focal_gamma: 2.0
  # Label smoothing coefficient (used when type=bce_label_smoothing).
  label_smoothing: 0.1
  # Positive class weight. -1=auto-compute, >0=manual.
  pos_weight: -1

train_split:
  # Split method.
  # Supported: stratified (recommended, CLI default), random, cv, csv_direct, csv_resplit.
  method: stratified
  # Train patient ratio.
  train_ratio: 0.75
  # Validation patient ratio.
  val_ratio: 0.15
  # Test patient ratio. Keep 0.10 unless your experiment design says otherwise.
  test_ratio: 0.10
  # Random seed used by the stratified splitter.
  random_seed: 42
  # Export split CSV to the experiment result directory.
  export_split_info: true
  # Split CSV filename stored in results/.
  split_filename: train_split.csv
  # Optional existing split CSV path.
  # Example: exports/train_split.csv. Leave empty to create a new split.
  train_split_csv_path: ""
  # Random seed used when re-splitting a provided CSV.
  csv_split_random_seed: 42
  # Use the split column from train_split_csv_path directly without re-splitting.
  use_csv_direct: false
"""


EXPERIMENT_CONFIG_TEMPLATE = """# experiment_config.yaml
# Experiment output and logging configuration.
# Experiment name used to create experiments/{name}/.
name: vit_experiment
# Human-readable version tag.
version: "0.1.0"
# Root directory that contains logs/, checkpoints/, and results/.
save_dir: experiments
# These directory fields are auto-expanded inside save_dir/name during runtime.
log_dir: experiments/logs
checkpoint_dir: experiments/checkpoints
result_dir: experiments/results
# Logging frequency by step.
log_every_n_steps: 10
# Validation interval in epochs.
val_check_interval: 1.0
# Reserved compatibility field for legacy single-axis flow.
save_top_k: 1
"""


MULTI_AXIS_CONFIG_TEMPLATE = """# multi_axis_config.yaml
# Multi-axis ViT + KNN validation and prediction configuration.
multi_axis:
  # Enable the multi-axis encoder path.
  enabled: true
  # Default training axis directories. Prediction CLI can also accept a flat mixed directory.
  axis_data_paths:
    x: dataset/data-x
    y: dataset/data-y
    z: dataset/data-z
  # Axes used by the model. Must be a subset of [x, y, z].
  # Example for single-axis: [z]
  active_axes: [x, y, z]
  # Axis voting weights used in KNN weighted voting.
  # Weights are normalized internally; values are relative.
  voting_weights:
    x: 0.3
    y: 0.3
    z: 0.4
  # Whether three axes share a single encoder.
  # true  -> one encoder for all axes (weight sharing).
  # false -> separate encoder per axis.
  shared_encoder: false
  # Number of PNGs sampled per axis during dataset construction.
  images_per_axis: 4
  # K value for KNN.
  knn_k: 5
  # Distance metric for KNN.
  # Supported: cosine (recommended), euclidean.
  knn_metric: cosine
  # Reserved feature export flag. It used to vit pred CLI.(Do not change it without do not use vit pred CLI.)
  save_features: true
  # Reserved feature output directory.
  feature_dir: features/
  # Per-axis loss weights (replaces naive summation).
  # When absent, all axes use weight 1.0.
  axis_loss_weights:
    x: 1.0
    y: 1.0
    z: 1.0
"""


MONITORING_CONFIG_TEMPLATE = """# monitoring_config.yaml
# Early stopping, best-model selection, and patient-level prediction threshold configuration.
monitoring:
  early_stopping:
    # Set false to force full epoch training.
    enabled: true
    # Early-stopping metric.
    # Supported: val_loss, val_auc, val_accuracy, val_f1.
    metric: val_loss
    # Optimization direction.
    # Supported: min (for val_loss), max (for val_auc, val_accuracy, val_f1).
    mode: min
    # Number of non-refresh epochs before stopping.
    patience: 10
    # Refresh threshold. Improvement larger than 0.001 resets patience.
    min_delta: 0.001
  model_selection:
    # Best-model checkpoint selection metric.
    # Supported: predict_accuracy, val_accuracy, val_auc, val_f1, val_loss.
    metric: predict_accuracy
    # Best-model metric direction.
    # Supported: max (for predict_accuracy, val_accuracy, val_auc, val_f1), min (for val_loss).
    mode: max
  # Patient-level probability threshold used during prediction.
  predict_threshold: 0.5
  # When true, train.py / predict.py / vit train / vit pred can show tqdm progress.
  verbose: true
"""


USAGE_TEMPLATE = """# vit CLI Usage

## Commands

`vit train --config <yaml_dir> [--data <dir>] [--label <csv>] [--verbose] [--resume]`

- Uses the simplified stratified-only training flow.
- Memory preload is enabled by default; disable it with `--disable-memory-preload`.
- The encoder is trained with supervised classification, while patient validation uses KNN plus weighted voting.

`vit pred --model <checkpoint> --data <png_dir> [--output <dir>] [--label <csv>] [--thresholds <float>] [--verbose]`

- Pure checkpoint-driven prediction. No `--config` is required.
- Supported `--data` layouts:
  - One root directory that contains `data-x/`, `data-y/`, and `data-z/`
  - One flat directory containing mixed-axis PNG files named `{patient_id}_{Z}_{Y}_{X}.png`
- `--label` CSV supports the headers `patient_id,label` and `0,1`
- `--thresholds` accepts a single float that overrides the checkpoint threshold

`vit get [--path <dir>]`

- Exports the full commented YAML template set and this usage guide to the target directory.

`vit version`

- Prints the package version from `src.__version__`

## YAML Variable Reference

### model_config.yaml
- Defines the ViT encoder structure, patching behavior, and rotary embedding parameters.

### data_config.yaml
- Defines memory preload and pin-memory behavior shared by the data pipeline.

### training_config.yaml
- Defines supervised encoder training hyperparameters and the stratified split configuration.

#### Multi-choice variables in training_config.yaml

| Variable | Supported values | Notes |
|----------|-----------------|-------|
| `optimizer` | `AdamW`, `Adam`, `SGD` | AdamW recommended |
| `scheduler` | `CosineAnnealingLR`, `CosineAnnealingWarmRestarts`, `StepLR`, `ExponentialLR`, `ReduceLROnPlateau`, `OneCycleLR`, `MultiStepLR` | Set `""` to disable. `scheduler_params` keys must match the chosen scheduler. |
| `device` | `cuda`, `cpu`, `auto`, `cuda:N` | Auto-fallback to cpu if CUDA unavailable |
| `freeze_method` | `none`, `layers`, `ratio` | `layers` uses `freeze_layers`; `ratio` uses `freeze_ratio` |
| `train_split.method` | `stratified`, `random`, `cv`, `csv_direct`, `csv_resplit` | CLI forces `stratified` |

### experiment_config.yaml
- Defines experiment naming, output directories, and logging-related fields.

### multi_axis_config.yaml
- Defines axis directories, active axes, voting weights, KNN settings, and shared-encoder behavior.

#### Multi-choice variables in multi_axis_config.yaml

| Variable | Supported values | Notes |
|----------|-----------------|-------|
| `knn_metric` | `cosine`, `euclidean` | cosine recommended |
| `shared_encoder` | `true`, `false` | true = weight sharing across axes |

### monitoring_config.yaml
- Defines early stopping, best-model selection, prediction threshold, and verbosity.

#### Multi-choice variables in monitoring_config.yaml

| Variable | Supported values | Notes |
|----------|-----------------|-------|
| `early_stopping.metric` | `val_loss`, `val_auc`, `val_accuracy`, `val_f1` | `val_loss` recommended |
| `early_stopping.mode` | `min`, `max` | min for val_loss; max for others |
| `model_selection.metric` | `predict_accuracy`, `val_accuracy`, `val_auc`, `val_f1`, `val_loss` | `predict_accuracy` recommended |
| `model_selection.mode` | `max`, `min` | max for most metrics; min for val_loss |

Author: SuShuHeng
Repository: https://github.com/SuShuHeng/Vit-cli
License: Apache2.0
"""


def export_cli_templates(output_dir: str | None) -> Path:
    target_dir = resolve_output_dir(output_dir)
    target_dir.mkdir(parents=True, exist_ok=True)
    templates = {
        "model_config.yaml": MODEL_CONFIG_TEMPLATE,
        "data_config.yaml": DATA_CONFIG_TEMPLATE,
        "training_config.yaml": TRAINING_CONFIG_TEMPLATE,
        "experiment_config.yaml": EXPERIMENT_CONFIG_TEMPLATE,
        "multi_axis_config.yaml": MULTI_AXIS_CONFIG_TEMPLATE,
        "monitoring_config.yaml": MONITORING_CONFIG_TEMPLATE,
        "USAGE.md": USAGE_TEMPLATE,
    }
    for filename, content in templates.items():
        (target_dir / filename).write_text(content, encoding="utf-8")
    return target_dir
