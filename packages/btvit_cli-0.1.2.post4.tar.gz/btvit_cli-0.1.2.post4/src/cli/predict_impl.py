"""Packaged prediction implementation shared by the CLI and legacy script."""

import argparse
import csv
import json
import os
from pathlib import Path
from typing import Dict, Iterable, List, Optional

os.environ.setdefault("MPLCONFIGDIR", "/tmp/matplotlib")

import matplotlib.pyplot as plt
import numpy as np
import torch

from src.cli.utils import normalize_prediction_data_layout
from src.prediction.multi_axis_predictor import MultiAxisPredictor
from src.utils.logger import get_logger


def build_parser():
    parser = argparse.ArgumentParser(
        description="ViT多轴预测脚本。仅支持纯 checkpoint 驱动的患者级 KNN + 加权投票预测。",
    )
    parser.add_argument(
        "--model",
        default=None,
        help="训练生成的 checkpoint 路径。checkpoint 内必须包含 config 快照。",
    )
    parser.add_argument(
        "--data",
        default=None,
        help="预测数据根目录。当前支持一个根目录下固定包含 data-x/、data-y/、data-z/。",
    )
    parser.add_argument(
        "--output",
        default="output",
        help="预测结果输出目录。默认值为当前命令执行目录下的 output。",
    )
    parser.add_argument(
        "--label",
        default=None,
        help="可选标签 CSV。表头支持 patient_id,label 或 0,1；提供后会额外输出 label 与 pass 列。",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="显示与训练脚本一致的实时进度条；未提供时仅在完成后输出总结信息。",
    )
    parser.add_argument(
        "--thresholds",
        type=float,
        default=None,
        help="单一预测阈值，覆盖 checkpoint 中记录的 predict_threshold。",
    )
    return parser


def parse_args(argv=None):
    legacy_checkpoint = None
    legacy_feature_store = None
    legacy_mode = None
    legacy_input = None

    normalized_argv = []
    if argv is None:
        import sys

        argv = sys.argv[1:]
    else:
        argv = list(argv)
    index = 0
    while index < len(argv):
        token = argv[index]
        if token == "--checkpoint" and index + 1 < len(argv):
            legacy_checkpoint = argv[index + 1]
            normalized_argv.extend(["--model", argv[index + 1]])
            index += 2
            continue
        if token == "--feature_store" and index + 1 < len(argv):
            legacy_feature_store = argv[index + 1]
            index += 2
            continue
        if token == "--mode" and index + 1 < len(argv):
            legacy_mode = argv[index + 1]
            index += 2
            continue
        if token == "--input" and index + 1 < len(argv):
            legacy_input = argv[index + 1]
            index += 2
            continue
        normalized_argv.append(token)
        index += 1

    args = build_parser().parse_args(normalized_argv)
    args.checkpoint = legacy_checkpoint or args.model
    args.feature_store = legacy_feature_store
    args.mode = legacy_mode
    args.input = legacy_input
    return args


def normalize_args(raw_args):
    if isinstance(raw_args, argparse.Namespace):
        return raw_args
    if isinstance(raw_args, dict):
        defaults = vars(parse_args([]))
        defaults.update(raw_args)
        return argparse.Namespace(**defaults)
    if raw_args is None:
        return parse_args()
    return parse_args(raw_args)


def resolve_output_dir(path: str) -> Path:
    output_dir = Path(path).expanduser()
    if not output_dir.is_absolute():
        output_dir = Path.cwd() / output_dir
    output_dir.mkdir(parents=True, exist_ok=True)
    return output_dir.resolve()


def resolve_feature_store_path(checkpoint_path: str) -> str:
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    if isinstance(checkpoint, dict):
        for key in ("best_feature_store_path", "latest_feature_store_path", "feature_store_path"):
            candidate = checkpoint.get(key)
            if candidate and os.path.exists(candidate):
                return os.path.abspath(candidate)

    checkpoint_dir = Path(checkpoint_path).resolve().parent
    experiment_dir = checkpoint_dir.parent
    candidates = [
        experiment_dir / "results" / "feature_store_best.npz",
        experiment_dir / "results" / "feature_store_latest.npz",
        experiment_dir / "results" / "feature_store.npz",
    ]
    for candidate in candidates:
        if candidate.exists():
            return str(candidate.resolve())

    raise FileNotFoundError("未找到可用的 feature_store 文件，无法执行 KNN 预测。")


def resolve_axis_data_paths(data_root: str, workspace_dir: Path) -> Dict[str, str]:
    return normalize_prediction_data_layout(data_root, workspace_dir)


def collect_patient_ids(axis_data_paths: Dict[str, str]) -> List[str]:
    patient_sets = []
    for axis_path in axis_data_paths.values():
        patient_ids = set()
        for png_path in Path(axis_path).glob("*.png"):
            parts = png_path.stem.split("_")
            if parts:
                patient_ids.add(parts[0])
        patient_sets.append(patient_ids)

    if not patient_sets:
        return []
    return sorted(set.intersection(*patient_sets))


def load_label_map(label_path: Optional[str]) -> Dict[str, int]:
    if not label_path:
        return {}
    csv_path = Path(label_path).expanduser().resolve()
    if not csv_path.exists():
        raise FileNotFoundError(f"标签文件不存在: {csv_path}")

    with csv_path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.reader(handle)
        header = next(reader, None)
        if header is None:
            return {}

        normalized_header = [cell.strip() for cell in header[:2]]
        if normalized_header == ["patient_id", "label"]:
            label_map = {}
            for row in reader:
                if len(row) < 2:
                    continue
                patient_id = row[0].strip()
                label = row[1].strip()
                if patient_id and label:
                    label_map[patient_id] = int(label)
            return label_map

        if normalized_header == ["0", "1"]:
            label_map = {}
            for row in reader:
                if row and row[0].strip():
                    label_map[row[0].strip()] = 0
                if len(row) > 1 and row[1].strip():
                    label_map[row[1].strip()] = 1
            return label_map

    raise ValueError("标签 CSV 表头必须为 patient_id,label 或 0,1")


def build_prediction_rows(results: Iterable[Dict[str, object]], label_map: Dict[str, int]) -> List[Dict[str, object]]:
    rows = []
    with_labels = bool(label_map)
    for result in results:
        row = {
            "patient_id": result["patient_id"],
            "png_num": result.get("png_num", 0),
            "comb_num": result.get("combo_count", 0),
            "pred_true_comb_num": result.get("pred_true_comb_num", 0),
            "pred_false_comb_num": result.get("pred_false_comb_num", 0),
            "pred_prob": round(float(result.get("predict_acc", 0.0)), 6),
            "pred_result": int(result.get("prediction", 0)),
        }
        if with_labels and result["patient_id"] in label_map:
            label = int(label_map[result["patient_id"]])
            row["label"] = label
            row["pass"] = bool(label == row["pred_result"])
        rows.append(row)
    return rows


def save_prediction_outputs(
    rows: List[Dict[str, object]],
    summary: Dict[str, object],
    output_dir: Path,
) -> Dict[str, str]:
    csv_path = output_dir / "predictions.csv"
    json_path = output_dir / "prediction_summary.json"

    fieldnames = list(rows[0].keys()) if rows else [
        "patient_id",
        "png_num",
        "comb_num",
        "pred_true_comb_num",
        "pred_false_comb_num",
        "pred_prob",
        "pred_result",
    ]

    with csv_path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    with json_path.open("w", encoding="utf-8") as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False, default=str)

    output_paths = {
        "prediction_csv": str(csv_path.resolve()),
        "summary_json": str(json_path.resolve()),
    }
    confusion_matrix_path = save_confusion_matrix(rows, output_dir)
    if confusion_matrix_path is not None:
        output_paths["confusion_matrix_png"] = confusion_matrix_path
    return output_paths


def save_confusion_matrix(rows: List[Dict[str, object]], output_dir: Path) -> Optional[str]:
    labeled_rows = [row for row in rows if "label" in row]
    if not labeled_rows:
        return None

    matrix = np.zeros((2, 2), dtype=int)
    for row in labeled_rows:
        true_label = int(row["label"])
        pred_label = int(row["pred_result"])
        matrix[true_label, pred_label] += 1

    figure, axis = plt.subplots(figsize=(4, 4))
    axis.imshow(matrix, cmap="Blues")
    axis.set_title("Confusion Matrix")
    axis.set_xlabel("Predicted")
    axis.set_ylabel("True")
    axis.set_xticks([0, 1], labels=["0", "1"])
    axis.set_yticks([0, 1], labels=["0", "1"])

    for row_index in range(2):
        for col_index in range(2):
            axis.text(col_index, row_index, str(matrix[row_index, col_index]), ha="center", va="center", color="black")

    figure.tight_layout()
    output_path = output_dir / "confusion_matrix.png"
    figure.savefig(output_path, dpi=150)
    plt.close(figure)
    return str(output_path.resolve())


def execute_predict_args(raw_args):
    args = normalize_args(raw_args)
    if not args.model:
        raise ValueError("--model is required")
    if not args.data:
        raise ValueError("--data is required")
    output_dir = resolve_output_dir(args.output)
    log_dir = output_dir / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = get_logger("predict", str(log_dir), console=False)

    feature_store_path = resolve_feature_store_path(args.model)
    predictor = MultiAxisPredictor(
        checkpoint_path=args.model,
        feature_store_path=feature_store_path,
        threshold=args.thresholds,
        verbose=bool(args.verbose),
    )
    axis_data_paths = resolve_axis_data_paths(args.data, output_dir / "_normalized_axes")
    patient_ids = collect_patient_ids(axis_data_paths)
    label_map = load_label_map(args.label)

    results, summary = predictor.predict_batch(
        patient_ids=patient_ids,
        axis_data_paths=axis_data_paths,
        label_path=args.label,
    )
    rows = build_prediction_rows(results, label_map)
    output_paths = save_prediction_outputs(rows, summary, output_dir)
    logger.info("prediction completed")
    logger.info(f"prediction_csv={output_paths['prediction_csv']}")
    logger.info(f"summary_json={output_paths['summary_json']}")

    print("Prediction completed.")
    print(f"patients: {summary.get('patient_count', 0)}")
    if "predict_accuracy" in summary:
        print(f"predict_accuracy: {summary['predict_accuracy']:.6f}")
    print(f"prediction_csv: {output_paths['prediction_csv']}")
    print(f"summary_json: {output_paths['summary_json']}")
    return 0


def main(argv=None):
    try:
        return execute_predict_args(parse_args(argv))
    except Exception as exc:
        print(f"预测过程中发生错误: {exc}")
        import traceback

        traceback.print_exc()
        return 1
