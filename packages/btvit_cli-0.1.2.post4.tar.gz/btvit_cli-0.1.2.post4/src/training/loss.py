"""Configurable loss functions for multi-axis ViT training.

Provides a factory function ``create_criterion()`` that reads loss configuration
from the config object and returns the appropriate loss module.
Reuses FocalLoss from src.utils.metrics.
"""

from typing import Any, Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..utils.metrics import FocalLoss


class LabelSmoothingBCEWithLogits(nn.Module):
    """Binary cross-entropy with label smoothing, operating on raw logits.

    Smoothed labels: ``y_smooth = y * (1 - smoothing) + (1 - y) * smoothing``
    Prevents the model from becoming overconfident.
    """

    def __init__(self, smoothing: float = 0.1, pos_weight: Optional[float] = None):
        super().__init__()
        self.smoothing = smoothing
        self.pos_weight = pos_weight

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        targets_smooth = targets * (1.0 - self.smoothing) + (1.0 - targets) * self.smoothing
        kwargs: Dict[str, Any] = {"reduction": "mean"}
        if self.pos_weight is not None and self.pos_weight > 0:
            kwargs["pos_weight"] = torch.tensor(self.pos_weight, device=logits.device, dtype=logits.dtype)
        return F.binary_cross_entropy_with_logits(logits, targets_smooth, **kwargs)


def create_criterion(config, pos_weight: Optional[float] = None) -> nn.Module:
    """Factory: create the loss function based on ``config.training.loss`` dict.

    Args:
        config: Config object with ``config.training.loss`` dict.
        pos_weight: Explicit positive class weight. When provided and > 0,
            used for BCE-based losses.

    Returns:
        ``nn.Module`` loss function accepting ``(logits, targets) -> scalar loss``.

    Raises:
        ValueError: If ``loss.type`` is not a supported value.
    """
    loss_config = getattr(getattr(config, "training", None), "loss", None) or {}
    loss_type = loss_config.get("type", "bce")

    if loss_type == "focal":
        alpha = float(loss_config.get("focal_alpha", 1.0))
        gamma = float(loss_config.get("focal_gamma", 2.0))
        return FocalLoss(alpha=alpha, gamma=gamma)

    if loss_type == "bce_label_smoothing":
        smoothing = float(loss_config.get("label_smoothing", 0.1))
        return LabelSmoothingBCEWithLogits(smoothing=smoothing, pos_weight=pos_weight)

    if loss_type == "bce":
        kwargs: Dict[str, Any] = {}
        if pos_weight is not None and pos_weight > 0:
            kwargs["pos_weight"] = torch.tensor([pos_weight])
        return nn.BCEWithLogitsLoss(**kwargs)

    raise ValueError(
        f"Unsupported loss type: {loss_type!r}. "
        "Supported: bce, focal, bce_label_smoothing"
    )
