import json
import os
import shutil
import inspect
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from itertools import product
from typing import Dict, Optional

import numpy as np
import torch
import torch.optim as optim
from torch.amp import GradScaler, autocast
from torch.optim.lr_scheduler import (
    CosineAnnealingLR,
    CosineAnnealingWarmRestarts,
    ExponentialLR,
    MultiStepLR,
    OneCycleLR,
    ReduceLROnPlateau,
    StepLR,
)

from ..model.vit_model import MultiAxisMedicalViT
from ..prediction.feature_store import FeatureStore
from ..prediction.knn import KNNClassifier, weighted_vote_probabilities
from ..prediction.multi_axis_predictor import aggregate_patient_probability
from ..utils.logger import get_logger
from ..utils.metrics import MetricsCalculator
from ..utils.runtime_output import (
    create_training_progress,
    format_final_summary,
    update_training_progress,
)


class MultiAxisTrainer:
    def __init__(self, config, logger=None, save_checkpoints: bool = True, fold_index: Optional[int] = None):
        self.config = config
        self.fold_index = fold_index
        self.logger = logger or get_logger("MultiAxisTrainer", config.experiment.log_dir, console=False)
        self.save_checkpoints = save_checkpoints
        self.device = torch.device(config.training.device)
        self.use_mixed_precision = bool(getattr(config.training, "mixed_precision", False) and self.device.type == "cuda")
        self.active_axes = list(getattr(config.multi_axis, "active_axes", ["x", "y", "z"]))
        self.voting_weights = dict(getattr(config.multi_axis, "voting_weights", {"x": 0.2, "y": 0.2, "z": 0.6}))
        self.predict_threshold = float(getattr(config.monitoring, "predict_threshold", 0.5))
        self.model = self._create_model().to(self.device)
        from .loss import create_criterion
        self.criterion = create_criterion(config)
        self.axis_loss_weights = dict(getattr(config.multi_axis, "axis_loss_weights", {}) or {})
        self.optimizer = self._create_optimizer()
        self.scheduler = self._create_scheduler()
        self.scaler = GradScaler(enabled=self.use_mixed_precision) if getattr(config.training, "mixed_precision", False) else None
        self.best_model_metric = float("-inf")
        self.best_model_epoch = 0
        self.best_val_auc = float("-inf")
        self.best_predict_accuracy = float("-inf")
        self.last_val_auc = 0.0
        self.last_predict_accuracy = 0.0
        self.global_step = 0
        self.resume_epoch = 0
        early_stopping_config = getattr(self.config.monitoring, "early_stopping", {})
        self.early_stopping_state = {
            "counter": 0,
            "best_score": None,
            "enabled": bool(early_stopping_config.get("enabled", True)),
            "metric": early_stopping_config.get("metric", "val_loss"),
            "mode": early_stopping_config.get("mode", "min"),
            "patience": int(early_stopping_config.get("patience", 10)),
            "min_delta": float(early_stopping_config.get("min_delta", 0.001)),
        }
        # Dynamic metric display trackers
        _es_mode = early_stopping_config.get("mode", "min")
        self.last_es_metric = 0.0
        self.best_es_metric = float("-inf") if _es_mode == "max" else float("inf")
        self.last_ms_metric = 0.0
        self.save_features = bool(getattr(config.multi_axis, "save_features", False))
        self.latest_feature_store_path, self.best_feature_store_path = self._resolve_feature_store_paths()

        os.makedirs(self.config.experiment.checkpoint_dir, exist_ok=True)
        os.makedirs(self.config.experiment.result_dir, exist_ok=True)
        os.makedirs(self.config.experiment.log_dir, exist_ok=True)

        # 5 dedicated IO threads: one per file type + state barrier
        self._io = {
            "latest_model": ThreadPoolExecutor(max_workers=1),
            "best_model": ThreadPoolExecutor(max_workers=1),
            "latest_feature": ThreadPoolExecutor(max_workers=1),
            "best_feature": ThreadPoolExecutor(max_workers=1),
            "state": ThreadPoolExecutor(max_workers=1),
        }

    def _create_model(self) -> MultiAxisMedicalViT:
        return MultiAxisMedicalViT(
            active_axes=self.active_axes,
            shared_encoder=getattr(self.config.multi_axis, "shared_encoder", False),
            input_shape=tuple(self.config.model.input_shape),
            patch_size=tuple(self.config.model.patch_size),
            num_classes=getattr(self.config.model, "num_classes", 1),
            dim=getattr(self.config.model, "dim", 512),
            depth=getattr(self.config.model, "depth", 6),
            heads=getattr(self.config.model, "heads", 8),
            mlp_dim=getattr(self.config.model, "mlp_dim", 2048),
            channels=getattr(self.config.model, "channels", 1),
            dim_head=getattr(self.config.model, "dim_head", 64),
            dropout=getattr(self.config.model, "dropout", 0.1),
            emb_dropout=getattr(self.config.model, "emb_dropout", 0.1),
            rope_min_freq=getattr(self.config.model, "rope_min_freq", 1.0),
            rope_max_freq=getattr(self.config.model, "rope_max_freq", 10000.0),
            rope_p_zero_freqs=getattr(self.config.model, "rope_p_zero_freqs", 0.0),
        )

    def _create_optimizer(self):
        optimizer_name = getattr(self.config.training, "optimizer", "AdamW")
        learning_rate = getattr(self.config.training, "learning_rate", 1e-4)
        weight_decay = getattr(self.config.training, "weight_decay", 0.0)
        parameter_group = [{
            "params": [param for param in self.model.parameters() if param.requires_grad],
            "lr": learning_rate,
            "weight_decay": weight_decay,
        }]

        if optimizer_name == "AdamW":
            return optim.AdamW(parameter_group)
        if optimizer_name == "Adam":
            return optim.Adam(parameter_group)
        return optim.SGD(parameter_group)

    def _create_scheduler(self):
        scheduler_name = getattr(self.config.training, "scheduler", "")
        if not scheduler_name:
            return None

        scheduler_params = dict(getattr(self.config.training, "scheduler_params", {}) or {})
        epochs = int(getattr(self.config.training, "epochs", 1))
        if scheduler_name == "CosineAnnealingLR" and "T_max" not in scheduler_params:
            scheduler_params["T_max"] = epochs
        elif scheduler_name == "StepLR" and "step_size" not in scheduler_params:
            scheduler_params["step_size"] = max(1, epochs // 3)
        elif scheduler_name == "OneCycleLR" and "total_steps" not in scheduler_params:
            steps_per_epoch = getattr(self, "steps_per_epoch", None)
            if steps_per_epoch:
                scheduler_params["total_steps"] = epochs * steps_per_epoch
            else:
                return None

        if scheduler_name == "CosineAnnealingLR":
            return CosineAnnealingLR(self.optimizer, **scheduler_params)
        if scheduler_name == "CosineAnnealingWarmRestarts":
            return CosineAnnealingWarmRestarts(self.optimizer, **scheduler_params)
        if scheduler_name == "StepLR":
            return StepLR(self.optimizer, **scheduler_params)
        if scheduler_name == "ExponentialLR":
            return ExponentialLR(self.optimizer, **scheduler_params)
        if scheduler_name == "ReduceLROnPlateau":
            return ReduceLROnPlateau(self.optimizer, **scheduler_params)
        if scheduler_name == "OneCycleLR":
            return OneCycleLR(self.optimizer, **scheduler_params)
        if scheduler_name == "MultiStepLR":
            return MultiStepLR(self.optimizer, **scheduler_params)
        return None

    def _resolve_feature_store_paths(self):
        if not self.save_features:
            return None, None
        feature_dir = getattr(self.config.multi_axis, "feature_dir", "features")
        experiment_dir = os.path.dirname(self.config.experiment.result_dir)
        if not os.path.isabs(feature_dir):
            feature_dir = os.path.join(experiment_dir, feature_dir)
        os.makedirs(feature_dir, exist_ok=True)
        latest_path = os.path.abspath(os.path.join(feature_dir, "feature_store_latest.npz"))
        best_path = os.path.abspath(os.path.join(feature_dir, "feature_store_best.npz"))
        return latest_path, best_path

    def _current_lr(self) -> float:
        if not self.optimizer or not self.optimizer.param_groups:
            return 0.0
        return float(self.optimizer.param_groups[0]["lr"])

    def _display_metric(self, value: float) -> float:
        if value is None or not np.isfinite(value):
            return 0.0
        return float(value)

    def _update_progress(self, progress_bar, epoch: int, total_epochs: int, stage: str, loss: float):
        if progress_bar is None:
            return
        es_config = self.early_stopping_state
        ms_config = getattr(self.config.monitoring, "model_selection", {})
        update_training_progress(
            progress_bar=progress_bar,
            epoch=epoch,
            total_epochs=total_epochs,
            stage=stage,
            patience_current=int(es_config.get("counter", 0)),
            patience_total=int(es_config.get("patience", 0)),
            show_patience=bool(es_config.get("enabled", False)),
            loss=float(loss),
            lr=self._current_lr(),
            es_metric_name=str(es_config.get("metric", "val_loss")),
            es_mode=str(es_config.get("mode", "min")),
            es_last=self._display_metric(self.last_es_metric),
            es_best=self._display_metric(self.best_es_metric),
            ms_metric_name=str(ms_config.get("metric", "predict_accuracy")),
            ms_mode=str(ms_config.get("mode", "max")),
            ms_last=self._display_metric(self.last_ms_metric),
            ms_best=self._display_metric(self.best_model_metric),
            best_epoch=int(self.best_model_epoch),
        )

    def train_epoch(self, train_loader, epoch: int = 0, progress_bar=None) -> Dict[str, float]:
        self.model.train()
        if not hasattr(self, "global_step"):
            self.global_step = 0
        total_epochs = getattr(self.config.training, "epochs", 1)
        accumulate_steps = max(1, int(getattr(self.config.training, "accumulate_grad_batches", 1)))
        total_loss = 0.0
        axis_loss_totals = {axis: 0.0 for axis in self.active_axes}
        num_batches = 0
        total_batches = len(train_loader)
        self.optimizer.zero_grad()

        for batch_idx, (axis_batches, labels, patient_ids, combo_indices, image_paths) in enumerate(train_loader):
            axis_batches = {axis: tensor.to(self.device) for axis, tensor in axis_batches.items()}
            labels = labels.to(self.device).unsqueeze(1)
            should_step = ((batch_idx + 1) % accumulate_steps == 0) or (batch_idx + 1 == total_batches)

            if getattr(self, "use_mixed_precision", False) and self.scaler:
                with autocast(self.device.type, enabled=True):
                    outputs = self.model(axis_batches)
                    axis_losses = {}
                    loss = 0.0
                    for axis in self.active_axes:
                        axis_loss = self.criterion(outputs[axis], labels)
                        axis_losses[axis] = axis_loss
                        w = self.axis_loss_weights.get(axis, 1.0)
                        loss = loss + w * axis_loss

                self.scaler.scale(loss / accumulate_steps).backward()
                if should_step:
                    clip_val = getattr(self.config.training, "gradient_clip_val", 0.0)
                    if clip_val and clip_val > 0:
                        self.scaler.unscale_(self.optimizer)
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), clip_val)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()
                    self.optimizer.zero_grad()
                    self.global_step += 1
                    scheduler = getattr(self, "scheduler", None)
                    if scheduler and isinstance(scheduler, OneCycleLR):
                        scheduler.step()
            else:
                outputs = self.model(axis_batches)

                axis_losses = {}
                loss = 0.0
                for axis in self.active_axes:
                    axis_loss = self.criterion(outputs[axis], labels)
                    axis_losses[axis] = axis_loss
                    w = self.axis_loss_weights.get(axis, 1.0)
                    loss = loss + w * axis_loss

                (loss / accumulate_steps).backward()

                if should_step:
                    clip_val = getattr(self.config.training, "gradient_clip_val", 0.0)
                    if clip_val and clip_val > 0:
                        torch.nn.utils.clip_grad_norm_(self.model.parameters(), clip_val)

                    self.optimizer.step()
                    self.optimizer.zero_grad()
                    self.global_step += 1
                    scheduler = getattr(self, "scheduler", None)
                    if scheduler and isinstance(scheduler, OneCycleLR):
                        scheduler.step()

            num_batches += 1
            total_loss += float(loss.item())
            for axis, axis_loss in axis_losses.items():
                axis_loss_totals[axis] += float(axis_loss.item())

            if progress_bar is not None:
                progress_bar.update(1)
                self._update_progress(
                    progress_bar=progress_bar,
                    epoch=epoch,
                    total_epochs=total_epochs,
                    stage="train",
                    loss=total_loss / num_batches if num_batches else 0.0,
                )

        metrics = {
            "loss": total_loss / num_batches if num_batches else 0.0,
        }
        for axis in self.active_axes:
            metrics[f"axis_loss_{axis}"] = axis_loss_totals[axis] / num_batches if num_batches else 0.0
        return metrics

    def save_checkpoint(self, epoch: int, kind: str = "latest"):
        if not getattr(self, "save_checkpoints", True):
            return None, None

        filename = "latest_model.pth" if kind == "latest" else "best_model.pth"
        checkpoint_path = os.path.join(self.config.experiment.checkpoint_dir, filename)
        # Snapshot state_dict to CPU (independent copies, safe for async write)
        model_state = {k: v.cpu() for k, v in self.model.state_dict().items()}
        checkpoint = {
            "epoch": epoch,
            "global_step": getattr(self, "global_step", 0),
            "model_state_dict": model_state,
            "optimizer_state_dict": self.optimizer.state_dict() if self.optimizer else None,
            "scheduler_state_dict": self.scheduler.state_dict() if self.scheduler else None,
            "scaler_state_dict": self.scaler.state_dict() if self.scaler else None,
            "best_model_metric": getattr(self, "best_model_metric", float("-inf")),
            "best_model_epoch": getattr(self, "best_model_epoch", 0),
            "best_val_auc": getattr(self, "best_val_auc", float("-inf")),
            "best_predict_accuracy": getattr(self, "best_predict_accuracy", float("-inf")),
            "best_es_metric": getattr(self, "best_es_metric", float("-inf")),
            "latest_feature_store_path": getattr(self, "latest_feature_store_path", "") or "",
            "best_feature_store_path": getattr(self, "best_feature_store_path", "") or "",
            "early_stopping_state": getattr(self, "early_stopping_state", {}),
            "config": self.config,
        }
        io_key = f"{kind}_model"
        future = self._io[io_key].submit(self._atomic_torch_save, checkpoint, checkpoint_path)
        return checkpoint_path, future

    @staticmethod
    def _atomic_torch_save(data, final_path):
        tmp_path = final_path + ".tmp"
        torch.save(data, tmp_path)
        os.replace(tmp_path, final_path)

    @staticmethod
    def _atomic_npz_save(payload, final_path):
        tmp_path = final_path + ".tmp"
        np.savez(tmp_path, **payload)
        os.replace(tmp_path, final_path)

    @staticmethod
    def _atomic_write_json(state_data, final_path):
        tmp_path = final_path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as handle:
            json.dump(state_data, handle, indent=2, ensure_ascii=False, default=str)
        os.replace(tmp_path, final_path)

    def save_train_state_json(self,
                              status: str,
                              current_epoch: int,
                              total_epochs: int,
                              last_metrics: Optional[Dict[str, float]] = None,
                              start_time: Optional[datetime] = None,
                              end_time: Optional[datetime] = None,
                              io_barriers: Optional[list] = None):
        latest_path = os.path.join(self.config.experiment.checkpoint_dir, "latest_model.pth")
        best_path = os.path.join(self.config.experiment.checkpoint_dir, "best_model.pth")
        state = {
            "status": status,
            "current_epoch": current_epoch,
            "total_epochs": total_epochs,
            "best_model_metric": getattr(self, "best_model_metric", float("-inf")),
            "best_model_epoch": getattr(self, "best_model_epoch", 0),
            "best_val_auc": getattr(self, "best_val_auc", float("-inf")),
            "best_predict_accuracy": getattr(self, "best_predict_accuracy", float("-inf")),
            "latest_model_path": str(os.path.abspath(latest_path)),
            "best_model_path": str(os.path.abspath(best_path)),
            "feature_store_latest_path": getattr(self, "latest_feature_store_path", "") or "",
            "feature_store_best_path": getattr(self, "best_feature_store_path", "") or "",
            "global_step": getattr(self, "global_step", 0),
            "early_stopping_state": getattr(self, "early_stopping_state", {}),
            "last_metrics": last_metrics or {},
            "resume_epoch": getattr(self, "resume_epoch", 0),
            "start_time": start_time.isoformat(timespec="seconds") if start_time else None,
            "end_time": end_time.isoformat(timespec="seconds") if end_time else None,
        }
        state_path = os.path.join(self.config.experiment.result_dir, "train_state.json")

        def _write_after_barriers(barriers, data, path):
            # Wait for all IO tasks to complete before writing state
            for future in (barriers or []):
                if future is not None:
                    try:
                        future.result()
                    except Exception:
                        pass
            MultiAxisTrainer._atomic_write_json(data, path)

        self._io["state"].submit(_write_after_barriers, io_barriers, state, state_path)
        return state_path

    def load_checkpoint(self, checkpoint_path: str):
        checkpoint = torch.load(checkpoint_path, map_location=self.device, weights_only=False)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        if self.optimizer and checkpoint.get("optimizer_state_dict"):
            self.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
        if self.scheduler and checkpoint.get("scheduler_state_dict"):
            self.scheduler.load_state_dict(checkpoint["scheduler_state_dict"])
        if self.scaler and checkpoint.get("scaler_state_dict"):
            self.scaler.load_state_dict(checkpoint["scaler_state_dict"])
        self.global_step = checkpoint.get("global_step", 0)
        self.best_model_metric = checkpoint.get("best_model_metric", float("-inf"))
        self.best_model_epoch = checkpoint.get("best_model_epoch", 0)
        self.best_val_auc = checkpoint.get("best_val_auc", float("-inf"))
        self.best_predict_accuracy = checkpoint.get("best_predict_accuracy", float("-inf"))
        self.latest_feature_store_path = checkpoint.get("latest_feature_store_path", self.latest_feature_store_path)
        self.best_feature_store_path = checkpoint.get("best_feature_store_path", self.best_feature_store_path)
        self.early_stopping_state = checkpoint.get("early_stopping_state", self.early_stopping_state)
        self.resume_epoch = checkpoint.get("epoch", 0)
        # Restore dynamic metric display trackers
        self.best_es_metric = checkpoint.get("best_es_metric", None)
        if self.best_es_metric is None:
            es_mode = self.early_stopping_state.get("mode", "min")
            self.best_es_metric = float("-inf") if es_mode == "max" else float("inf")
        self.last_es_metric = 0.0
        self.last_ms_metric = 0.0
        return checkpoint

    def resume_from_latest(self):
        checkpoint_path = os.path.join(self.config.experiment.checkpoint_dir, "latest_model.pth")
        if not os.path.exists(checkpoint_path):
            # Check for temp file from incomplete atomic write
            tmp_path = checkpoint_path + ".tmp"
            if os.path.exists(tmp_path):
                raise FileNotFoundError(
                    f"训练被中断: {checkpoint_path} 不完整(存在.tmp文件)。"
                    f"请检查上一个 epoch 的检查点是否可用。"
                )
            raise FileNotFoundError(f"最新checkpoint不存在: {checkpoint_path}")
        checkpoint = self.load_checkpoint(checkpoint_path)
        self.resume_epoch = checkpoint.get("epoch", 0)
        return self.resume_epoch + 1

    def _extract_axis_feature(self, image_processor, axis: str, image_path: str) -> np.ndarray:
        image = image_processor.load_image(image_path)
        image = image_processor.normalize_image(image)
        tensor = torch.from_numpy(np.asarray(image, dtype=np.float32).reshape(1, image.shape[0], image.shape[1]))
        with torch.no_grad():
            features = self.model.extract_features({axis: tensor.unsqueeze(0).to(self.device)})
        return features[axis].squeeze(0).detach().cpu().numpy().astype(np.float32)

    def _batch_extract_features(self, image_processor, axis: str, image_paths: list, batch_size: int = 64) -> list:
        """Batch-extract features for multiple images of the same axis."""
        if not image_paths:
            return []
        all_features = []
        with torch.no_grad():
            for start in range(0, len(image_paths), batch_size):
                batch_paths = image_paths[start:start + batch_size]
                tensors = []
                for path in batch_paths:
                    image = image_processor.load_image(path)
                    image = image_processor.normalize_image(image)
                    tensors.append(
                        torch.from_numpy(
                            np.asarray(image, dtype=np.float32).reshape(1, image.shape[0], image.shape[1])
                        )
                    )
                batch_tensor = torch.stack(tensors).to(self.device)
                features = self.model.extract_features({axis: batch_tensor})
                all_features.append(features[axis].detach().cpu().numpy().astype(np.float32))
        return np.concatenate(all_features, axis=0)

    def _build_feature_store(self, dataset) -> FeatureStore:
        feature_store = FeatureStore(active_axes=self.active_axes)
        # Collect unique (image_path, label) per axis
        axis_entries = {axis: [] for axis in self.active_axes}
        seen_paths = {axis: set() for axis in self.active_axes}

        for patient_id in dataset.patient_ids:
            label = dataset.label_processor.get_label(patient_id)
            if label is None:
                continue
            axis_images = dataset.organizer.get_patient_all_axis_images(patient_id)
            for axis in self.active_axes:
                for image_path in axis_images.get(axis, []):
                    if image_path in seen_paths[axis]:
                        continue
                    axis_entries[axis].append((image_path, int(label)))
                    seen_paths[axis].add(image_path)

        # Batch-extract features per axis
        for axis in self.active_axes:
            entries = axis_entries[axis]
            if not entries:
                continue
            paths = [e[0] for e in entries]
            labels = [e[1] for e in entries]
            features = self._batch_extract_features(dataset.image_processor, axis, paths)
            for feat, label_val, image_path in zip(features, labels, paths):
                feature_store.add(
                    axis=axis,
                    feature=feat,
                    label=label_val,
                    image_id=os.path.abspath(image_path),
                )

        return feature_store

    def _save_feature_store(self, feature_store: FeatureStore, output_path: str) -> str:
        if output_path is None:
            return None
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        payload = {}
        for axis in self.active_axes:
            features, labels = feature_store.get_features(axis)
            payload[f"{axis}_features"] = features
            payload[f"{axis}_labels"] = labels
            payload[f"{axis}_image_ids"] = feature_store.get_image_ids(axis)
        self._latest_feature_future = self._io["latest_feature"].submit(
            self._atomic_npz_save, payload, output_path,
        )
        return os.path.abspath(output_path)

    def _compute_patient_knn_metrics(self, feature_store: FeatureStore, dataset) -> Dict[str, float]:
        knn = KNNClassifier(
            active_axes=self.active_axes,
            k=getattr(self.config.multi_axis, "knn_k", 5),
            metric=getattr(self.config.multi_axis, "knn_metric", "cosine"),
        )
        knn.build_index(feature_store)

        # Phase 1: Collect all unique validation images per axis
        axis_unique_images = {axis: [] for axis in self.active_axes}
        valid_patients = []
        for patient_id in dataset.patient_ids:
            label = dataset.label_processor.get_label(patient_id)
            axis_images = dataset.organizer.get_patient_all_axis_images(patient_id)
            if label is None or not axis_images:
                continue
            if any(not axis_images.get(axis) for axis in self.active_axes):
                continue
            valid_patients.append((patient_id, label, axis_images))
            for axis in self.active_axes:
                for path in axis_images[axis]:
                    if path not in axis_unique_images[axis]:
                        axis_unique_images[axis].append(path)

        # Phase 2: Batch-extract features for all unique images
        axis_features = {}
        for axis in self.active_axes:
            paths = axis_unique_images[axis]
            if not paths:
                continue
            raw_features = self._batch_extract_features(dataset.image_processor, axis, paths)
            axis_features[axis] = {path: feat for path, feat in zip(paths, raw_features)}

        # Phase 3: Compute KNN probabilities using cached features
        patient_probabilities = []
        patient_labels = []
        patient_predictions = []

        for patient_id, label, axis_images in valid_patients:
            cached_axis_probabilities = {axis: {} for axis in self.active_axes}
            combo_probabilities = []

            for combo_paths in product(*(axis_images[axis] for axis in self.active_axes)):
                axis_probabilities = {}
                for axis, image_path in zip(self.active_axes, combo_paths):
                    cached_value = cached_axis_probabilities[axis].get(image_path)
                    if cached_value is None:
                        feature = axis_features[axis][image_path]
                        cached_value = float(knn.predict_proba(axis, feature)[0])
                        cached_axis_probabilities[axis][image_path] = cached_value
                    axis_probabilities[axis] = cached_value

                combo_probabilities.append(
                    weighted_vote_probabilities(axis_probabilities, self.voting_weights)
                )

            patient_probability = aggregate_patient_probability(
                np.asarray(combo_probabilities, dtype=np.float32)
            )
            prediction = int(patient_probability >= self.predict_threshold)
            patient_probabilities.append(patient_probability)
            patient_predictions.append(prediction)
            patient_labels.append(int(label))

        if not patient_labels:
            return {
                "predict_accuracy": 0.0,
                "patient_count": 0,
                "mean_patient_predict_proba": 0.0,
            }

        labels_array = np.asarray(patient_labels, dtype=np.int32)
        predictions_array = np.asarray(patient_predictions, dtype=np.int32)
        probabilities_array = np.asarray(patient_probabilities, dtype=np.float32)
        return {
            "predict_accuracy": float((predictions_array == labels_array).mean()),
            "patient_count": int(labels_array.shape[0]),
            "mean_patient_predict_proba": float(probabilities_array.mean()),
        }

    def _metric_value(self, metrics: Dict[str, float], metric_name: str) -> float:
        alias_map = {
            "val_loss": "loss",
            "val_auc": "auc",
            "val_accuracy": "accuracy",
            "val_f1": "f1",
            "predict_accuracy": "predict_accuracy",
        }
        if metric_name in metrics:
            return float(metrics[metric_name])
        return float(metrics.get(alias_map.get(metric_name, metric_name), 0.0))

    def _is_better(self, current: float, best: float, mode: str) -> bool:
        if best is None or not np.isfinite(best):
            return True
        if mode == "min":
            return current < best
        return current > best

    def _should_stop_early(self, metrics: Dict[str, float]) -> bool:
        if not self.early_stopping_state.get("enabled", False):
            return False

        metric_name = self.early_stopping_state.get("metric", "val_loss")
        mode = self.early_stopping_state.get("mode", "min")
        min_delta = float(self.early_stopping_state.get("min_delta", 0.001))
        score = self._metric_value(metrics, metric_name)
        best_score = self.early_stopping_state.get("best_score")

        improved = False
        if best_score is None:
            improved = True
        elif mode == "min":
            improved = score < float(best_score) - min_delta
        else:
            improved = score > float(best_score) + min_delta

        if improved:
            self.early_stopping_state["best_score"] = score
            self.early_stopping_state["counter"] = 0
            return False

        self.early_stopping_state["counter"] = int(self.early_stopping_state.get("counter", 0)) + 1
        return self.early_stopping_state["counter"] >= int(self.early_stopping_state.get("patience", 0))

    def validate_epoch(self, train_loader, val_loader, epoch: int, progress_bar=None) -> Dict[str, float]:
        self.model.eval()
        total_epochs = getattr(self.config.training, "epochs", 1)
        total_loss = 0.0
        axis_loss_totals = {axis: 0.0 for axis in self.active_axes}
        num_batches = 0
        metrics_calculator = MetricsCalculator()

        with torch.no_grad():
            for axis_batches, labels, patient_ids, combo_indices, image_paths in val_loader:
                axis_batches = {axis: tensor.to(self.device) for axis, tensor in axis_batches.items()}
                labels = labels.to(self.device).unsqueeze(1)
                outputs = self.model(axis_batches)

                loss = 0.0
                axis_logits = []
                for axis in self.active_axes:
                    axis_loss = self.criterion(outputs[axis], labels)
                    axis_loss_totals[axis] += float(axis_loss.item())
                    axis_logits.append(outputs[axis])
                    w = self.axis_loss_weights.get(axis, 1.0)
                    loss = loss + w * axis_loss

                ensemble_logits = torch.stack(axis_logits, dim=0).mean(dim=0)
                metrics_calculator.update(ensemble_logits, labels)
                total_loss += float(loss.item())
                num_batches += 1

                if progress_bar is not None:
                    progress_bar.update(1)
                    self._update_progress(
                        progress_bar=progress_bar,
                        epoch=epoch,
                        total_epochs=total_epochs,
                        stage="val",
                        loss=total_loss / num_batches if num_batches else 0.0,
                    )

        feature_store = self._build_feature_store(train_loader.dataset)
        # KNN validation first (in-memory), then async disk save
        patient_metrics = self._compute_patient_knn_metrics(feature_store, val_loader.dataset)
        if self.save_features:
            self.latest_feature_store_path = self._save_feature_store(
                feature_store,
                self.latest_feature_store_path,
            )
        sample_metrics = metrics_calculator.compute()

        metrics = {
            "loss": total_loss / num_batches if num_batches else 0.0,
            "auc": float(sample_metrics.get("auc", 0.5)),
            "accuracy": float(sample_metrics.get("accuracy", 0.0)),
            "f1": float(sample_metrics.get("f1", 0.0)),
            "predict_accuracy": float(patient_metrics.get("predict_accuracy", 0.0)),
            "patient_count": int(patient_metrics.get("patient_count", 0)),
            "mean_patient_predict_proba": float(patient_metrics.get("mean_patient_predict_proba", 0.0)),
            "val_loss": total_loss / num_batches if num_batches else 0.0,
            "val_auc": float(sample_metrics.get("auc", 0.5)),
            "val_accuracy": float(sample_metrics.get("accuracy", 0.0)),
            "val_f1": float(sample_metrics.get("f1", 0.0)),
        }
        for axis in self.active_axes:
            metrics[f"axis_loss_{axis}"] = axis_loss_totals[axis] / num_batches if num_batches else 0.0
        return metrics

    def train(self, train_loader, val_loader):
        total_epochs = getattr(self.config.training, "epochs", 1)
        start_epoch = getattr(self, "resume_epoch", 0)
        self.steps_per_epoch = len(train_loader)
        if getattr(self.config.training, "scheduler", "") == "OneCycleLR" and self.scheduler is None:
            self.scheduler = self._create_scheduler()
        if not hasattr(self, "latest_feature_store_path"):
            self.latest_feature_store_path, self.best_feature_store_path = self._resolve_feature_store_paths()
        if not hasattr(self, "best_feature_store_path"):
            _, self.best_feature_store_path = self._resolve_feature_store_paths()
        if not hasattr(self, "best_val_auc"):
            self.best_val_auc = float("-inf")
        if not hasattr(self, "best_predict_accuracy"):
            self.best_predict_accuracy = float("-inf")
        train_history = []
        val_history = []
        self._current_train_history = train_history
        start_time = datetime.now()
        batches_per_epoch = len(train_loader) + len(val_loader)
        progress_bar = create_training_progress(
            total_steps=total_epochs * batches_per_epoch,
            verbose=bool(getattr(self.config.monitoring, "verbose", False)),
            initial=start_epoch * batches_per_epoch,
        )
        final_status = "completed"
        current_epoch = start_epoch
        end_time = None
        final_io_futures = []

        self.logger.info(f"training_start={start_time.isoformat(timespec='seconds')}")
        try:
            for epoch_index in range(start_epoch, total_epochs):
                current_epoch = epoch_index + 1
                train_metrics = self.train_epoch(train_loader, current_epoch, progress_bar=progress_bar)
                validate_signature = inspect.signature(self.validate_epoch)
                validate_kwargs = {"progress_bar": progress_bar}
                if "epoch" in validate_signature.parameters:
                    validate_kwargs["epoch"] = current_epoch
                val_metrics = self.validate_epoch(train_loader, val_loader, **validate_kwargs)
                train_history.append(train_metrics)
                val_history.append(val_metrics)

                self.last_val_auc = float(val_metrics.get("val_auc", val_metrics.get("auc", 0.0)))
                self.last_predict_accuracy = float(val_metrics.get("predict_accuracy", 0.0))
                self.best_val_auc = max(self.best_val_auc, self.last_val_auc)
                self.best_predict_accuracy = max(self.best_predict_accuracy, self.last_predict_accuracy)

                # Update dynamic metric display trackers
                es_metric = self.early_stopping_state.get("metric", "val_loss")
                es_mode = self.early_stopping_state.get("mode", "min")
                ms_metric = getattr(self.config.monitoring, "model_selection", {}).get("metric", "predict_accuracy")
                self.last_es_metric = self._metric_value(val_metrics, es_metric)
                if self._is_better(self.last_es_metric, self.best_es_metric, es_mode):
                    self.best_es_metric = self.last_es_metric
                self.last_ms_metric = self._metric_value(val_metrics, ms_metric)

                if self.scheduler and not isinstance(self.scheduler, OneCycleLR):
                    if isinstance(self.scheduler, ReduceLROnPlateau):
                        self.scheduler.step(val_metrics.get("val_loss", val_metrics.get("loss", 0.0)))
                    else:
                        self.scheduler.step()

                selection_config = getattr(self.config.monitoring, "model_selection", {})
                selection_metric = selection_config.get("metric", "predict_accuracy")
                selection_mode = selection_config.get("mode", "max")
                current_score = self._metric_value(val_metrics, selection_metric)

                # Collect IO futures for this epoch (for state barrier)
                epoch_io_futures = []

                if self._is_better(current_score, self.best_model_metric, selection_mode):
                    self.best_model_metric = current_score
                    self.best_model_epoch = current_epoch
                    best_path, best_future = self.save_checkpoint(current_epoch, kind="best")
                    epoch_io_futures.append(best_future)
                    if self.save_features and self.latest_feature_store_path and self.best_feature_store_path:
                        latest_future = getattr(self, "_latest_feature_future", None)

                        def _copy_best_feature(lf=latest_future, src=self.latest_feature_store_path, dst=self.best_feature_store_path):
                            if lf is not None:
                                lf.result()
                            shutil.copy2(src, dst)

                        best_feat_future = self._io["best_feature"].submit(_copy_best_feature)
                        epoch_io_futures.append(best_feat_future)
                else:
                    best_path = os.path.join(self.config.experiment.checkpoint_dir, "best_model.pth")

                latest_path, latest_future = self.save_checkpoint(current_epoch, kind="latest")
                epoch_io_futures.append(latest_future)
                # Include feature save future if present
                feat_future = getattr(self, "_latest_feature_future", None)
                if feat_future is not None:
                    epoch_io_futures.append(feat_future)
                final_io_futures = list(epoch_io_futures)
                self.resume_epoch = current_epoch

                self._update_progress(
                    progress_bar=progress_bar,
                    epoch=current_epoch,
                    total_epochs=total_epochs,
                    stage="val",
                    loss=val_metrics.get("val_loss", val_metrics.get("loss", 0.0)),
                )

                epoch_log = {
                    "epoch": current_epoch,
                    "train_metrics": train_metrics,
                    "val_metrics": val_metrics,
                    "latest_path": latest_path,
                    "best_path": best_path,
                }
                self.logger.info(json.dumps(epoch_log, ensure_ascii=False, default=str))
                self.save_train_state_json(
                    status="running",
                    current_epoch=current_epoch,
                    total_epochs=total_epochs,
                    last_metrics=val_metrics,
                    start_time=start_time,
                    io_barriers=epoch_io_futures,
                )

                if self._should_stop_early(val_metrics):
                    final_status = "early_stopped"
                    break

            end_time = datetime.now()
            self.save_train_state_json(
                status=final_status,
                current_epoch=current_epoch,
                total_epochs=total_epochs,
                last_metrics=val_history[-1] if val_history else {},
                start_time=start_time,
                end_time=end_time,
                io_barriers=final_io_futures,
            )
        except Exception:
            final_status = "interrupted"
            interrupted_at = datetime.now()
            self.save_train_state_json(
                status=final_status,
                current_epoch=current_epoch,
                total_epochs=total_epochs,
                start_time=start_time,
                end_time=interrupted_at,
                io_barriers=[],
            )
            raise
        finally:
            progress_bar.close()
            del self._current_train_history
            # Wait for all pending IO writes to complete
            # ensure train_state.json reflects actual disk state
            for executor in self._io.values():
                executor.shutdown(wait=True)

        summary = {
            "status": final_status,
            "start_time": start_time.isoformat(timespec="seconds"),
            "end_time": end_time.isoformat(timespec="seconds"),
            "elapsed_seconds": round((end_time - start_time).total_seconds(), 3),
            "best_model_epoch": self.best_model_epoch,
            "best_model_metric": round(self._display_metric(self.best_model_metric), 6),
            "best_val_auc": round(self._display_metric(self.best_val_auc), 6),
            "best_predict_acc": round(self._display_metric(self.best_predict_accuracy), 6),
            "latest_epoch": current_epoch,
        }
        paths = {
            "best_model": os.path.abspath(os.path.join(self.config.experiment.checkpoint_dir, "best_model.pth")),
            "latest_model": os.path.abspath(os.path.join(self.config.experiment.checkpoint_dir, "latest_model.pth")),
            "train_state": os.path.abspath(os.path.join(self.config.experiment.result_dir, "train_state.json")),
            "feature_store_latest": self.latest_feature_store_path or "(in-memory only)",
            "feature_store_best": self.best_feature_store_path or "(in-memory only)",
            "log_file": os.path.abspath(getattr(self.logger, "log_file", "")),
        }
        self.final_summary = format_final_summary(summary, paths)
        return train_history, val_history
