import glob
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch

from ..data.preprocessing import ImageProcessor, LabelProcessor
from ..model.vit_model import MultiAxisMedicalViT
from ..prediction.feature_store import FeatureStore
from ..prediction.knn import KNNClassifier, weighted_vote_probabilities
from ..utils.config import load_config
from ..utils.runtime_output import create_prediction_progress


def aggregate_patient_probability(combo_probs: np.ndarray) -> float:
    combo_probs = np.asarray(combo_probs, dtype=np.float32)
    if combo_probs.size == 0:
        return 0.0
    return float(combo_probs.mean())


class MultiAxisPredictor:
    def __init__(self,
                 checkpoint_path: str,
                 feature_store_path: Optional[str] = None,
                 config_path: Optional[str] = None,
                 threshold: Optional[float] = None,
                 device: Optional[str] = None,
                 verbose: bool = False):
        self.checkpoint_path = checkpoint_path
        self.feature_store_path = feature_store_path
        self.checkpoint = self._load_checkpoint()
        self.config = self._resolve_config(config_path)
        self.active_axes = list(getattr(self.config.multi_axis, "active_axes", ["x", "y", "z"]))
        self.voting_weights = dict(getattr(self.config.multi_axis, "voting_weights", {"x": 0.2, "y": 0.2, "z": 0.6}))
        self.threshold = threshold if threshold is not None else getattr(self.config.monitoring, "predict_threshold", 0.5)
        requested_device = device or getattr(self.config.training, "device", "cpu")
        if requested_device == "cuda" and not torch.cuda.is_available():
            requested_device = "cpu"
        self.device = torch.device(requested_device)
        self.verbose = verbose
        self.image_processor = ImageProcessor(patch_size=(16, 16))
        self.model = self._load_model()
        self.feature_store = self._load_feature_store(feature_store_path)
        self.knn = None
        if self.feature_store is not None:
            self.knn = KNNClassifier(
                active_axes=self.active_axes,
                k=getattr(self.config.multi_axis, "knn_k", 5),
                metric=getattr(self.config.multi_axis, "knn_metric", "cosine"),
            )
            self.knn.build_index(self.feature_store)

    def _load_checkpoint(self):
        return torch.load(self.checkpoint_path, map_location="cpu", weights_only=False)

    def _resolve_config(self, config_path: Optional[str]):
        checkpoint = self.checkpoint if isinstance(self.checkpoint, dict) else {}
        checkpoint_config = checkpoint.get("config") or checkpoint.get("config_snapshot")
        if checkpoint_config is not None:
            return checkpoint_config
        if config_path:
            return load_config(config_path)
        raise ValueError("checkpoint does not contain config snapshot; please provide config_path")

    def _load_model(self) -> MultiAxisMedicalViT:
        model = MultiAxisMedicalViT(
            active_axes=self.active_axes,
            shared_encoder=getattr(self.config.multi_axis, "shared_encoder", False),
            input_shape=tuple(self.config.model.input_shape),
            patch_size=tuple(self.config.model.patch_size),
            num_classes=getattr(self.config.model, "num_classes", 1),
            dim=getattr(self.config.model, "dim", 512),
            depth=getattr(self.config.model, "depth", 6),
            heads=getattr(self.config.model, "heads", 8),
            mlp_dim=getattr(self.config.model, "mlp_dim", 2048),
            channels=getattr(self.config.model, "channels", 1),
            dim_head=getattr(self.config.model, "dim_head", 64),
            dropout=getattr(self.config.model, "dropout", 0.1),
            emb_dropout=getattr(self.config.model, "emb_dropout", 0.1),
            rope_min_freq=getattr(self.config.model, "rope_min_freq", 1.0),
            rope_max_freq=getattr(self.config.model, "rope_max_freq", 10000.0),
            rope_p_zero_freqs=getattr(self.config.model, "rope_p_zero_freqs", 0.0),
        ).to(self.device)

        checkpoint = self.checkpoint if isinstance(self.checkpoint, dict) else self.checkpoint
        state_dict = checkpoint.get("model_state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint
        model.load_state_dict(state_dict, strict=False)

        model.eval()
        return model

    def _load_feature_store(self, feature_store_path: Optional[str]) -> Optional[FeatureStore]:
        if not feature_store_path or not os.path.exists(feature_store_path):
            return None

        npz = np.load(feature_store_path, allow_pickle=True)
        store = FeatureStore(active_axes=self.active_axes)
        for axis in self.active_axes:
            features_key = f"{axis}_features"
            labels_key = f"{axis}_labels"
            ids_key = f"{axis}_image_ids"
            if features_key not in npz or labels_key not in npz:
                continue

            features = npz[features_key]
            labels = npz[labels_key]
            image_ids = npz[ids_key] if ids_key in npz else np.asarray([f"{axis}_{idx}" for idx in range(len(labels))])
            for feature, label, image_id in zip(features, labels, image_ids):
                store.add(axis=axis, feature=feature, label=int(label), image_id=str(image_id))
        return store

    def _load_axis_image(self, image_path: str) -> torch.Tensor:
        image = self.image_processor.load_image(image_path)
        image = self.image_processor.normalize_image(image)
        image = np.asarray(image, dtype=np.float32).reshape(1, image.shape[0], image.shape[1])
        return torch.from_numpy(image)

    def _collect_patient_axis_images(self, patient_id: str, axis_data_paths: Dict[str, str]) -> Dict[str, List[str]]:
        axis_images = {}
        for axis in self.active_axes:
            pattern = os.path.join(axis_data_paths[axis], f"{patient_id}_*.png")
            image_paths = sorted(glob.glob(pattern))
            axis_images[axis] = image_paths
        return axis_images

    def _enumerate_combinations(self, axis_images: Dict[str, List[str]]) -> List[Dict[str, str]]:
        if any(not axis_images.get(axis) for axis in self.active_axes):
            return []

        combinations = [{}]
        for axis in self.active_axes:
            next_combinations = []
            for combo in combinations:
                for image_path in axis_images[axis]:
                    new_combo = dict(combo)
                    new_combo[axis] = image_path
                    next_combinations.append(new_combo)
            combinations = next_combinations
        return combinations

    def _predict_combination_probability(self, combo: Dict[str, str]) -> Tuple[float, Dict[str, float]]:
        if self.knn is None:
            raise RuntimeError("feature_store_path is required for multi-axis KNN prediction")

        axis_tensors = {
            axis: self._load_axis_image(combo[axis]).unsqueeze(0).to(self.device)
            for axis in self.active_axes
        }
        with torch.no_grad():
            axis_features = self.model.extract_features(axis_tensors)

        axis_probabilities = {}
        for axis in self.active_axes:
            feature = axis_features[axis].detach().cpu().numpy()
            axis_probabilities[axis] = float(self.knn.predict_proba(axis, feature)[0])

        combo_probability = weighted_vote_probabilities(axis_probabilities, self.voting_weights)
        return combo_probability, axis_probabilities

    def predict_patient(self, patient_id: str, axis_data_paths: Dict[str, str]) -> Dict[str, object]:
        axis_images = self._collect_patient_axis_images(patient_id, axis_data_paths)
        combinations = self._enumerate_combinations(axis_images)
        combo_probabilities = []
        combo_axis_probabilities = []

        for combo in combinations:
            combo_probability, axis_probabilities = self._predict_combination_probability(combo)
            combo_probabilities.append(combo_probability)
            combo_axis_probabilities.append(axis_probabilities)

        patient_predict_proba = aggregate_patient_probability(np.asarray(combo_probabilities, dtype=np.float32))
        prediction = int(patient_predict_proba >= self.threshold)
        axis_image_counts = {axis: len(axis_images.get(axis, [])) for axis in self.active_axes}
        positive_combo_count = sum(int(prob >= self.threshold) for prob in combo_probabilities)
        combo_count = len(combinations)

        return {
            "patient_id": patient_id,
            "patient_predict_proba": patient_predict_proba,
            "predict_acc": patient_predict_proba,
            "predict_threshold": self.threshold,
            "predict_acc_prob": self.threshold,
            "prediction": prediction,
            "combo_count": combo_count,
            "png_num": min(axis_image_counts.values()) if axis_image_counts else 0,
            "axis_image_counts": axis_image_counts,
            "pred_true_comb_num": positive_combo_count,
            "pred_false_comb_num": combo_count - positive_combo_count,
            "combo_probabilities": combo_probabilities,
            "combo_axis_probabilities": combo_axis_probabilities,
        }

    def predict_batch(self,
                      patient_ids: List[str],
                      axis_data_paths: Dict[str, str],
                      label_path: Optional[str] = None) -> Tuple[List[Dict[str, object]], Dict[str, float]]:
        progress_bar = create_prediction_progress(total_steps=len(patient_ids), verbose=self.verbose)
        results = []
        try:
            for patient_id in patient_ids:
                results.append(self.predict_patient(patient_id, axis_data_paths))
                progress_bar.update(1)
        finally:
            progress_bar.close()

        summary = {
            "patient_count": len(results),
            "positive_count": sum(result["prediction"] for result in results),
            "mean_patient_predict_proba": float(np.mean([result["patient_predict_proba"] for result in results])) if results else 0.0,
        }

        if label_path and os.path.exists(label_path):
            label_processor = LabelProcessor(label_path)
            correct = 0
            total = 0
            for result in results:
                true_label = label_processor.get_label(result["patient_id"])
                if true_label is None:
                    continue
                total += 1
                correct += int(true_label == result["prediction"])
            summary["predict_accuracy"] = correct / total if total else 0.0

        return results, summary
