from typing import Dict

import numpy as np


def weighted_vote_probabilities(axis_probs: Dict[str, float], voting_weights: Dict[str, float]) -> float:
    return float(sum(axis_probs[axis] * voting_weights[axis] for axis in axis_probs))


class KNNClassifier:
    def __init__(self, active_axes, k: int = 5, metric: str = "cosine"):
        self.active_axes = active_axes
        self.k = k
        self.metric = metric
        self.index = {}
        self.is_built = False

    def build_index(self, feature_store):
        for axis in self.active_axes:
            features, labels = feature_store.get_features(axis)
            if features.size == 0:
                self.index[axis] = {
                    "features": features,
                    "labels": labels,
                }
                continue

            if self.metric == "cosine":
                norms = np.linalg.norm(features, axis=1, keepdims=True)
                norms = np.maximum(norms, 1e-8)
                normalized = features / norms
            else:
                normalized = features

            self.index[axis] = {
                "features": normalized.astype(np.float32),
                "labels": labels.astype(np.int32),
            }

        self.is_built = True

    def predict_proba(self, axis: str, query_features: np.ndarray) -> np.ndarray:
        if not self.is_built:
            raise RuntimeError("KNN index has not been built")

        query_features = np.asarray(query_features, dtype=np.float32)
        if query_features.ndim == 1:
            query_features = query_features.reshape(1, -1)

        train_features = self.index[axis]["features"]
        train_labels = self.index[axis]["labels"]
        if train_features.size == 0:
            return np.zeros((query_features.shape[0],), dtype=np.float32)

        if self.metric == "cosine":
            norms = np.linalg.norm(query_features, axis=1, keepdims=True)
            norms = np.maximum(norms, 1e-8)
            query_normalized = query_features / norms
            similarities = query_normalized @ train_features.T
            top_k_indices = np.argpartition(-similarities, min(self.k, train_features.shape[0]) - 1, axis=1)[:, :self.k]
        else:
            distances = np.linalg.norm(query_features[:, None, :] - train_features[None, :, :], axis=2)
            top_k_indices = np.argpartition(distances, min(self.k, train_features.shape[0]) - 1, axis=1)[:, :self.k]

        probabilities = []
        for row_indices in top_k_indices:
            probabilities.append(float(train_labels[row_indices].mean()))

        return np.asarray(probabilities, dtype=np.float32)
