from typing import Dict, List, Tuple

import numpy as np


class FeatureStore:
    def __init__(self, active_axes):
        self.active_axes = active_axes
        self._by_axis: Dict[str, Dict[str, Tuple[np.ndarray, int]]] = {
            axis: {} for axis in active_axes
        }

    def add(self, axis: str, feature: np.ndarray, label: int, image_id: str):
        self._by_axis[axis][image_id] = (
            np.asarray(feature, dtype=np.float32),
            int(label),
        )

    def get_features(self, axis: str):
        rows = list(self._by_axis[axis].values())
        if not rows:
            return np.empty((0, 0), dtype=np.float32), np.empty((0,), dtype=np.int32)

        features = np.stack([row[0] for row in rows], axis=0)
        labels = np.asarray([row[1] for row in rows], dtype=np.int32)
        return features, labels

    def get_image_ids(self, axis: str) -> np.ndarray:
        return np.asarray(list(self._by_axis[axis].keys()), dtype=object)
