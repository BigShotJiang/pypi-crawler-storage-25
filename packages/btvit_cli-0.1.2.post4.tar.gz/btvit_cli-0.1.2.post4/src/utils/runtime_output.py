from typing import Dict

from tqdm import tqdm


_SHORT_NAMES = {
    "val_auc": "val_auc",
    "val_loss": "val_loss",
    "val_accuracy": "val_acc",
    "val_f1": "val_f1",
    "predict_accuracy": "predict_acc",
}


def _mode_arrow(mode: str) -> str:
    if mode == "max":
        return "\u2191"
    return "\u2193"


def _short_metric_name(name: str) -> str:
    return _SHORT_NAMES.get(name, name)


def create_training_progress(total_steps: int, verbose: bool, initial: int = 0):
    return tqdm(total=total_steps, initial=initial, disable=not verbose, dynamic_ncols=True)


def create_prediction_progress(total_steps: int, verbose: bool):
    return tqdm(total=total_steps, disable=not verbose, dynamic_ncols=True)


def update_training_progress(progress_bar,
                             epoch: int,
                             total_epochs: int,
                             stage: str,
                             patience_current: int,
                             patience_total: int,
                             show_patience: bool,
                             loss: float,
                             lr: float,
                             es_metric_name: str,
                             es_mode: str,
                             es_last: float,
                             es_best: float,
                             ms_metric_name: str,
                             ms_mode: str,
                             ms_last: float,
                             ms_best: float,
                             best_epoch: int):
    es_short = _short_metric_name(es_metric_name)
    es_arrow = _mode_arrow(es_mode)
    ms_short = _short_metric_name(ms_metric_name)
    ms_arrow = _mode_arrow(ms_mode)

    postfix_parts = [
        f"{epoch}/{total_epochs}",
        stage,
    ]
    if show_patience:
        postfix_parts.append(f"patience({es_short}|{es_arrow}):{patience_current}/{patience_total}")
    postfix_parts.extend([
        f"loss:{loss:.4f}",
        f"lr:{lr:.6g}",
        f"ES({es_short}{es_arrow}):{es_last:.4f}|{es_best:.4f}",
        f"MS({ms_short}{ms_arrow}):{ms_last:.4f}|{ms_best:.4f}",
        f"best_epoch:{best_epoch}|{total_epochs}",
    ])
    if hasattr(progress_bar, "set_postfix_str"):
        progress_bar.set_postfix_str(" ".join(postfix_parts))


def format_final_summary(summary: Dict[str, object], paths: Dict[str, str]) -> str:
    summary_parts = [f"{key}={value}" for key, value in summary.items()]
    path_parts = [f"{key}: {value}" for key, value in paths.items()]
    return "\n".join(summary_parts + path_parts)
