import logging
import os
from datetime import datetime
from typing import Optional
import sys


class Logger:
    def __init__(self,
                 name: str = "ViT",
                 log_dir: str = "experiments/logs",
                 level: int = logging.INFO,
                 console: bool = True):
        self.name = name
        self.log_dir = log_dir
        self.level = level
        self.console = console

        os.makedirs(log_dir, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = os.path.join(log_dir, f"{name}_{timestamp}.log")
        self.log_file = log_file

        logger_name = f"{name}:{os.path.abspath(log_dir)}"
        self.logger = logging.getLogger(logger_name)
        self.logger.setLevel(level)
        self.logger.propagate = False

        for handler in list(self.logger.handlers):
            self.logger.removeHandler(handler)
            handler.close()

        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        self.logger.addHandler(file_handler)

        if console:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(level)
            console_handler.setFormatter(formatter)
            self.logger.addHandler(console_handler)

    def info(self, message: str):
        self.logger.info(message)

    def debug(self, message: str):
        self.logger.debug(message)

    def warning(self, message: str):
        self.logger.warning(message)

    def error(self, message: str):
        self.logger.error(message)

    def critical(self, message: str):
        self.logger.critical(message)

    def log_config(self, config):
        self.info("=" * 50)
        self.info("配置信息")
        self.info("=" * 50)

        config_dict = {
            'model': config.model.__dict__,
            'data': config.data.__dict__,
            'training': config.training.__dict__,
            'experiment': config.experiment.__dict__
        }

        for section_name, section_dict in config_dict.items():
            self.info(f"\n{section_name.upper()} 配置:")
            for key, value in section_dict.items():
                self.info(f"  {key}: {value}")

        self.info("=" * 50)

    def log_metrics(self, metrics: dict, step: Optional[int] = None):
        prefix = f"[Step {step}] " if step is not None else ""
        for key, value in metrics.items():
            self.info(f"{prefix}{key}: {value:.4f}" if isinstance(value, float) else f"{prefix}{key}: {value}")

    def log_model_summary(self, model):
        total_params = sum(p.numel() for p in model.parameters())
        trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

        self.info("=" * 50)
        self.info("模型结构信息")
        self.info("=" * 50)
        self.info(f"模型类型: {type(model).__name__}")
        self.info(f"总参数量: {total_params:,}")
        self.info(f"可训练参数量: {trainable_params:,}")
        self.info(f"模型大小: {total_params * 4 / 1024 / 1024:.2f} MB")
        self.info("=" * 50)


def get_logger(name: str = "ViT",
               log_dir: str = "experiments/logs",
               level: int = logging.INFO,
               console: bool = True) -> Logger:
    return Logger(name, log_dir, level, console)
