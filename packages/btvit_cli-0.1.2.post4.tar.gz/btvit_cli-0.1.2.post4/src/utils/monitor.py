import os
import json
import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List, Optional
from datetime import datetime
import seaborn as sns
from sklearn.metrics import confusion_matrix, roc_curve, auc, precision_recall_curve
import torch

plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial Unicode MS', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False


class TrainingMonitor:
    def __init__(self, experiment_name: str, save_dir: str = "experiments/results"):
        self.experiment_name = experiment_name
        self.save_dir = save_dir
        self.history = {
            'train': [],
            'val': []
        }

        os.makedirs(save_dir, exist_ok=True)

    def log_epoch(self, epoch: int, train_metrics: Dict, val_metrics: Dict):
        self.history['train'].append({
            'epoch': epoch,
            **train_metrics
        })
        self.history['val'].append({
            'epoch': epoch,
            **val_metrics
        })

    def plot_training_curves(self):
        if not self.history['train']:
            print("没有训练历史数据可供绘制")
            return

        metrics = ['loss', 'accuracy', 'precision', 'recall', 'f1', 'auc']
        available_metrics = []

        for metric in metrics:
            if metric in self.history['train'][0] and metric in self.history['val'][0]:
                available_metrics.append(metric)

        if not available_metrics:
            print("没有可用的指标数据")
            return

        n_metrics = len(available_metrics)
        fig, axes = plt.subplots(2, 3, figsize=(15, 10))
        axes = axes.flatten()

        for i, metric in enumerate(available_metrics):
            if i >= len(axes):
                break

            epochs = [entry['epoch'] for entry in self.history['train']]
            train_values = [entry[metric] for entry in self.history['train']]
            val_values = [entry[metric] for entry in self.history['val']]

            axes[i].plot(epochs, train_values, 'b-', label='训练', linewidth=2)
            axes[i].plot(epochs, val_values, 'r-', label='验证', linewidth=2)
            axes[i].set_title(f'{metric.upper()} 曲线')
            axes[i].set_xlabel('Epoch')
            axes[i].set_ylabel(metric.upper())
            axes[i].legend()
            axes[i].grid(True, alpha=0.3)

        for j in range(i + 1, len(axes)):
            axes[j].set_visible(False)

        plt.tight_layout()
        plot_path = os.path.join(self.save_dir, f'{self.experiment_name}_training_curves.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"训练曲线已保存: {plot_path}")

    def plot_loss_comparison(self):
        if not self.history['train'] or 'loss' not in self.history['train'][0]:
            print("没有损失数据可供绘制")
            return

        epochs = [entry['epoch'] for entry in self.history['train']]
        train_losses = [entry['loss'] for entry in self.history['train']]
        val_losses = [entry['loss'] for entry in self.history['val']]

        plt.figure(figsize=(10, 6))
        plt.plot(epochs, train_losses, 'b-', label='训练损失', linewidth=2)
        plt.plot(epochs, val_losses, 'r-', label='验证损失', linewidth=2)
        plt.title('训练和验证损失对比')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        plt.grid(True, alpha=0.3)

        plot_path = os.path.join(self.save_dir, f'{self.experiment_name}_loss_comparison.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"损失对比图已保存: {plot_path}")

    def save_history(self):
        history_path = os.path.join(self.save_dir, f'{self.experiment_name}_history.json')
        with open(history_path, 'w', encoding='utf-8') as f:
            json.dump(self.history, f, indent=2, ensure_ascii=False)
        print(f"训练历史已保存: {history_path}")

    def load_history(self, history_path: str):
        if os.path.exists(history_path):
            with open(history_path, 'r', encoding='utf-8') as f:
                self.history = json.load(f)
            print(f"训练历史已加载: {history_path}")
        else:
            print(f"历史文件不存在: {history_path}")


class EvaluationVisualizer:
    def __init__(self, save_dir: str = "experiments/results"):
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

    def plot_confusion_matrix(self, y_true: np.ndarray, y_pred: np.ndarray,
                             labels: List[str] = None, title: str = "混淆矩阵"):
        if labels is None:
            labels = ['阴性', '阳性']

        cm = confusion_matrix(y_true, y_pred)

        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
                   xticklabels=labels, yticklabels=labels)
        plt.title(title)
        plt.xlabel('预测标签')
        plt.ylabel('真实标签')

        plot_path = os.path.join(self.save_dir, 'confusion_matrix.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"混淆矩阵已保存: {plot_path}")

        return cm

    def plot_roc_curve(self, y_true: np.ndarray, y_scores: np.ndarray,
                      title: str = "ROC曲线"):
        fpr, tpr, thresholds = roc_curve(y_true, y_scores)
        roc_auc = auc(fpr, tpr)

        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, color='darkorange', lw=2,
                label=f'ROC曲线 (AUC = {roc_auc:.2f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('假正率 (FPR)')
        plt.ylabel('真正率 (TPR)')
        plt.title(title)
        plt.legend(loc="lower right")
        plt.grid(True, alpha=0.3)

        plot_path = os.path.join(self.save_dir, 'roc_curve.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"ROC曲线已保存: {plot_path}")

        return roc_auc, fpr, tpr

    def plot_precision_recall_curve(self, y_true: np.ndarray, y_scores: np.ndarray,
                                   title: str = "精确率-召回率曲线"):
        precision, recall, thresholds = precision_recall_curve(y_true, y_scores)
        pr_auc = auc(recall, precision)

        plt.figure(figsize=(8, 6))
        plt.plot(recall, precision, color='blue', lw=2,
                label=f'PR曲线 (AUC = {pr_auc:.2f})')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('召回率 (Recall)')
        plt.ylabel('精确率 (Precision)')
        plt.title(title)
        plt.legend(loc="lower left")
        plt.grid(True, alpha=0.3)

        plot_path = os.path.join(self.save_dir, 'precision_recall_curve.png')
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()

        print(f"PR曲线已保存: {plot_path}")

        return pr_auc, precision, recall

    def create_metrics_summary(self, metrics: Dict[str, float],
                              experiment_name: str = "experiment"):
        summary_text = f"""
# {experiment_name} 实验结果总结

## 评估指标
"""

        metric_names = {
            'accuracy': '准确率',
            'precision': '精确率',
            'recall': '召回率',
            'f1': 'F1分数',
            'auc': 'AUC值',
            'sensitivity': '敏感性',
            'specificity': '特异性',
            'loss': '损失值'
        }

        for key, value in metrics.items():
            metric_name = metric_names.get(key, key.upper())
            if isinstance(value, float):
                summary_text += f"- **{metric_name}**: {value:.4f}\n"
            else:
                summary_text += f"- **{metric_name}**: {value}\n"

        if 'true_positive' in metrics and 'true_negative' in metrics:
            summary_text += f"""
## 混淆矩阵详情
- **真阳性 (TP)**: {metrics['true_positive']}
- **假阳性 (FP)**: {metrics['false_positive']}
- **真阴性 (TN)**: {metrics['true_negative']}
- **假阴性 (FN)**: {metrics['false_negative']}
"""

        summary_text += f"""
## 实验信息
- **实验名称**: {experiment_name}
- **生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

        summary_path = os.path.join(self.save_dir, f'{experiment_name}_summary.md')
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write(summary_text)

        print(f"结果总结已保存: {summary_path}")

        return summary_text


class TensorBoardLogger:
    def __init__(self, log_dir: str, fold_index: Optional[int] = None):
        try:
            from torch.utils.tensorboard import SummaryWriter
            # 如果指定了fold_index，创建分折子目录
            if fold_index is not None:
                self.log_dir = os.path.join(log_dir, f"fold_{fold_index}")
            else:
                self.log_dir = log_dir
            self.writer = SummaryWriter(self.log_dir)
            self.enabled = True
            self.fold_index = fold_index
        except ImportError:
            print("TensorBoard未安装，禁用TensorBoard日志记录")
            self.enabled = False
            self.fold_index = fold_index

    def log_scalar(self, tag: str, value: float, step: int):
        if self.enabled:
            self.writer.add_scalar(tag, value, step)

    def log_scalars(self, main_tag: str, tag_scalar_dict: Dict[str, float], step: int):
        if self.enabled:
            self.writer.add_scalars(main_tag, tag_scalar_dict, step)

    def log_histogram(self, tag: str, values: torch.Tensor, step: int):
        if self.enabled and values is not None and values.numel() > 0:
            try:
                # 检查梯度是否为空或全为0
                if values.grad_fn is not None or (requires_grad := values.requires_grad):
                    # 只记录非空的梯度
                    flattened = values.detach().cpu().flatten()
                    if flattened.numel() > 0 and not torch.isnan(flattened).all() and not torch.isinf(flattened).all():
                        self.writer.add_histogram(tag, flattened, step)
            except Exception as e:
                # 静默处理直方图错误，避免中断训练
                print(f"直方图记录失败 {tag}: {str(e)}")
                pass

    def log_graph(self, model: torch.nn.Module, input_tensor: torch.Tensor):
        if self.enabled:
            try:
                self.writer.add_graph(model, input_tensor)
            except Exception as e:
                print(f"添加计算图失败: {str(e)}")

    def log_images(self, tag: str, images: torch.Tensor, step: int, max_images: int = 8):
        """记录图像到TensorBoard"""
        if self.enabled:
            try:
                # 确保图像在正确的范围内 [0, 1]
                if images.dim() == 5:  # (batch, patches, channels, h, w)
                    # 取前几个patch作为代表
                    images = images[:, :max_images]
                    # 重塑为 (batch*patches, channels, h, w)
                    images = images.view(-1, images.size(-3), images.size(-2), images.size(-1))
                    # 选择前max_images个
                    images = images[:max_images]

                # 标准化到[0,1]范围
                if images.max() > 1.0:
                    images = (images - images.min()) / (images.max() - images.min())

                # 如果是单通道，复制为3通道用于可视化
                if images.size(1) == 1:
                    images = images.repeat(1, 3, 1, 1)

                self.writer.add_images(tag, images, step)
            except Exception as e:
                print(f"添加图像失败: {str(e)}")

    def log_patches_as_grid(self, tag: str, patches: torch.Tensor, step: int, grid_size=(6, 4)):
        """将补丁重新排列为网格并记录"""
        if self.enabled:
            try:
                import torchvision.transforms.functional as F

                # patches: (batch, num_patches, channels, h, w)
                batch_size, num_patches, channels, h, w = patches.shape

                # 选择第一个样本的补丁
                sample_patches = patches[0]  # (num_patches, channels, h, w)

                # 重排补丁为原始图像格式 (23个16x16补丁 -> 16x368图像)
                rows, cols = grid_size
                image_grid = torch.zeros(channels, h * rows, w * cols)

                for i in range(num_patches):
                    row = i // cols
                    col = i % cols
                    if row < rows and col < cols:
                        image_grid[:, row*h:(row+1)*h, col*w:(col+1)*w] = sample_patches[i]

                # 标准化到[0,1]范围
                if image_grid.max() > 1.0:
                    image_grid = (image_grid - image_grid.min()) / (image_grid.max() - image_grid.min())

                # 如果是单通道，复制为3通道
                if image_grid.size(0) == 1:
                    image_grid = image_grid.repeat(3, 1, 1)

                self.writer.add_image(tag, image_grid, step)
            except Exception as e:
                print(f"添加补丁网格失败: {str(e)}")

    def log_learning_rate(self, lr: float, step: int, tag: str = 'Training/LearningRate'):
        """记录学习率到TensorBoard

        Args:
            lr: 当前学习率
            step: 当前步数或epoch
            tag: 记录的标签名称，默认为'Training/LearningRate'
        """
        if self.enabled:
            try:
                # 数据验证
                if not isinstance(lr, (int, float)):
                    print(f"学习率数据类型错误: {type(lr)}, 值: {lr}")
                    return
                if not isinstance(step, (int, float)):
                    print(f"步骤数据类型错误: {type(step)}, 值: {step}")
                    return
                if not isinstance(tag, str):
                    print(f"标签数据类型错误: {type(tag)}, 值: {tag}")
                    return

                # 检查数值有效性
                if not (-float('inf') < lr < float('inf')):
                    print(f"学习率数值无效: {lr}")
                    return

                # # 记录调试信息
                # print(f"记录学习率到TensorBoard: tag='{tag}', lr={lr:.8f}, step={step}")

                # 调用TensorBoard
                self.writer.add_scalar(tag, lr, step)

                # print(f"学习率记录成功: tag='{tag}'")

            except Exception as e:
                print(f"TensorBoard学习率记录失败: tag='{tag}', lr={lr}, step={step}, error={str(e)}")
                # 不重新抛出异常，避免中断训练

    def log_model_stats(self, model: torch.nn.Module, step: int):
        """记录模型统计信息"""
        if self.enabled:
            try:
                total_params = sum(p.numel() for p in model.parameters())
                trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)

                self.writer.add_scalars('Model/Parameters', {
                    'total': total_params,
                    'trainable': trainable_params
                }, step)

                # 计算模型总计算量
                try:
                    from thop import profile
                    sample_input = torch.randn(1, 24, 1, 16, 16).to(next(model.parameters()).device)
                    flops, params = profile(model, inputs=(sample_input,))
                    self.writer.add_scalar('Model/FLOPs', flops, step)
                except ImportError:
                    pass  # thop未安装，跳过FLOPs计算
                except Exception as e:
                    print(f"计算FLOPs失败: {str(e)}")
            except Exception as e:
                print(f"记录模型统计信息失败: {str(e)}")

    def close(self):
        if self.enabled:
            self.writer.close()