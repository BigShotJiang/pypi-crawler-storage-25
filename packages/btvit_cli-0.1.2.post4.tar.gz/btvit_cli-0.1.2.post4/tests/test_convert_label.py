import csv
import importlib.util
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

from src.data.preprocessing import LabelProcessor


PROJECT_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_PATH = PROJECT_ROOT / "tools" / "convert_label.py"
LABEL_PATH = PROJECT_ROOT / "dataset" / "label.csv"
DATA_X_PATH = PROJECT_ROOT / "dataset" / "data-x"


class ConvertLabelFunctionTest(unittest.TestCase):
    def load_module(self):
        self.assertTrue(SCRIPT_PATH.exists(), "tools/convert_label.py should exist")

        spec = importlib.util.spec_from_file_location("convert_label_module", SCRIPT_PATH)
        self.assertIsNotNone(spec)
        self.assertIsNotNone(spec.loader)

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def test_convert_label_writes_standard_rows_from_sample_input(self):
        module = self.load_module()

        with tempfile.TemporaryDirectory() as tmpdir:
            tmp_path = Path(tmpdir)
            input_path = tmp_path / "label-all.csv"
            output_path = tmp_path / "label.csv"

            input_path.write_text(
                "patient_id,1,0,\n"
                "placeholder,POS001,NEG001,\n"
                "placeholder2,POS002,,\n"
                "placeholder3,,NEG002,\n",
                encoding="utf-8",
            )

            module.convert_label(str(input_path), str(output_path))

            with output_path.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.reader(handle))

        self.assertEqual(
            rows,
            [
                ["0", "1"],
                ["POS001", "NEG001"],
                ["POS002", ""],
                ["", "NEG002"],
            ],
        )

class ConvertLabelCliTest(unittest.TestCase):
    def setUp(self):
        self.original_label = LABEL_PATH.read_text(encoding="utf-8")

    def tearDown(self):
        LABEL_PATH.write_text(self.original_label, encoding="utf-8")

    def test_cli_rewrites_repo_label_csv_with_expected_counts(self):
        result = subprocess.run(
            [sys.executable, "tools/convert_label.py"],
            cwd=PROJECT_ROOT,
            capture_output=True,
            text=True,
            check=False,
        )

        self.assertEqual(result.returncode, 0, msg=result.stderr or result.stdout)

        with LABEL_PATH.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.reader(handle))

        labels = LabelProcessor(str(LABEL_PATH)).labels
        positive_count = sum(1 for value in labels.values() if value == 1)
        negative_count = sum(1 for value in labels.values() if value == 0)
        data_x_patients = {path.name.split("_")[0] for path in DATA_X_PATH.glob("*.png")}

        self.assertEqual(rows[0], ["0", "1"])
        self.assertEqual(len(rows), 124)
        self.assertEqual(len(labels), 241)
        self.assertEqual(positive_count, 118)
        self.assertEqual(negative_count, 123)
        self.assertSetEqual(set(labels), data_x_patients)


if __name__ == "__main__":
    unittest.main()
