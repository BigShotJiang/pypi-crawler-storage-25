import tempfile
import unittest
from pathlib import Path

from src.cli.utils import export_cli_templates


class ExportCliTemplatesTests(unittest.TestCase):
    def test_training_config_fields_have_explanatory_comments(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            export_cli_templates(tmp_dir)
            content = (Path(tmp_dir) / "training_config.yaml").read_text(encoding="utf-8")

        lines = content.splitlines()
        fields = [
            "epochs",
            "learning_rate",
            "weight_decay",
            "optimizer",
            "scheduler",
            "scheduler_params",
            "device",
            "batch_size",
            "num_workers",
            "mixed_precision",
            "gradient_clip_val",
            "accumulate_grad_batches",
            "debug_logging",
            "pretrained_model_path",
            "load_weights_only",
            "strict_load",
            "freeze_method",
            "freeze_layers",
            "freeze_ratio",
            "finetune_lr_scale",
            "use_differential_lr",
        ]

        for field in fields:
            field_index = lines.index(next(line for line in lines if line.startswith(f"{field}:")))
            previous_non_empty = next(
                line.strip() for line in reversed(lines[:field_index]) if line.strip()
            )
            self.assertTrue(
                previous_non_empty.startswith("#"),
                msg=f"{field} should be documented by a preceding comment",
            )

    def test_training_config_includes_complete_examples(self) -> None:
        with tempfile.TemporaryDirectory() as tmp_dir:
            export_cli_templates(tmp_dir)
            content = (Path(tmp_dir) / "training_config.yaml").read_text(encoding="utf-8")

        self.assertIn("scheduler_params: {T_max: 100, eta_min: 1.0e-6}", content)
        self.assertIn("Example: checkpoints/best_model.pth", content)
        self.assertIn("Example: patch_embedding,transformer:0-2", content)
        self.assertIn("Example: exports/train_split.csv", content)


if __name__ == "__main__":
    unittest.main()
