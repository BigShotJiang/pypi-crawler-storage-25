import importlib
import sys
import types
import unittest
from unittest import mock

from typer.testing import CliRunner


class CliPredHelpTest(unittest.TestCase):
    def test_vit_pred_help_describes_supported_layouts_and_options(self):
        app = self._load_app()

        runner = CliRunner()
        result = runner.invoke(app, ["pred", "--help"])

        self.assertEqual(result.exit_code, 0)
        self.assertIn("--model", result.stdout)
        self.assertIn("--data", result.stdout)
        self.assertIn("--output", result.stdout)
        self.assertIn("--label", result.stdout)
        self.assertIn("--verbose", result.stdout)
        self.assertIn("--thresholds", result.stdout)
        self.assertNotIn("--config", result.stdout)
        self.assertIn("data-x/", result.stdout)
        self.assertIn("data-y/", result.stdout)
        self.assertIn("data-z/", result.stdout)
        self.assertIn("{patient_id}_{Z}_{Y}_{X}.png", result.stdout)
        self.assertIn("patient_id,label", result.stdout)
        self.assertIn("0,1", result.stdout)
        self.assertIn("single float", result.stdout)

    def _load_app(self):
        fake_matplotlib = types.ModuleType("matplotlib")
        fake_pyplot = types.ModuleType("matplotlib.pyplot")
        fake_numpy = types.ModuleType("numpy")
        fake_torch = types.ModuleType("torch")
        fake_utils_package = types.ModuleType("src.utils")
        fake_utils_package.__path__ = []
        fake_logger_module = types.ModuleType("src.utils.logger")
        fake_logger_module.get_logger = lambda *args, **kwargs: None
        fake_prediction_package = types.ModuleType("src.prediction")
        fake_prediction_package.__path__ = []
        fake_predictor_module = types.ModuleType("src.prediction.multi_axis_predictor")
        fake_predictor_module.MultiAxisPredictor = object

        with mock.patch.dict(
            sys.modules,
            {
                "matplotlib": fake_matplotlib,
                "matplotlib.pyplot": fake_pyplot,
                "numpy": fake_numpy,
                "torch": fake_torch,
                "src.utils": fake_utils_package,
                "src.utils.logger": fake_logger_module,
                "src.prediction": fake_prediction_package,
                "src.prediction.multi_axis_predictor": fake_predictor_module,
            },
        ):
            sys.modules.pop("src.cli.main", None)
            sys.modules.pop("src.cli.predict_cmd", None)
            sys.modules.pop("src.cli.predict_runner", None)
            sys.modules.pop("src.cli.predict_impl", None)
            return importlib.import_module("src.cli.main").app


if __name__ == "__main__":
    unittest.main()
