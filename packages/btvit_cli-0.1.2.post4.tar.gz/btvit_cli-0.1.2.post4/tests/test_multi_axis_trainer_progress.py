import os
import tempfile
import unittest
from types import MethodType, SimpleNamespace

import torch

from src.training.multi_axis_trainer import MultiAxisTrainer


class _DummyLogger:
    log_file = ""

    def info(self, *args, **kwargs):
        return None

    def error(self, *args, **kwargs):
        return None


class _DummyProgressBar:
    def __init__(self):
        self.n = 0

    def update(self, value):
        self.n += value

    def close(self):
        return None


class _DummyLoader:
    def __init__(self, batches):
        self._batches = batches
        self.dataset = SimpleNamespace()

    def __iter__(self):
        return iter(self._batches)

    def __len__(self):
        return len(self._batches)


class _DummyModel(torch.nn.Module):
    def forward(self, axis_batches):
        tensor = next(iter(axis_batches.values()))
        return {"x": tensor.mean(dim=(1, 2, 3)).unsqueeze(1)}


def _build_trainer(temp_dir: str) -> MultiAxisTrainer:
    trainer = MultiAxisTrainer.__new__(MultiAxisTrainer)
    trainer.config = SimpleNamespace(
        training=SimpleNamespace(epochs=100),
        monitoring=SimpleNamespace(
            verbose=True,
            model_selection={"metric": "predict_accuracy", "mode": "max"},
        ),
        experiment=SimpleNamespace(
            result_dir=temp_dir,
            checkpoint_dir=os.path.join(temp_dir, "checkpoints"),
        ),
    )
    trainer.logger = _DummyLogger()
    trainer.model = _DummyModel()
    trainer.criterion = torch.nn.BCEWithLogitsLoss()
    trainer.active_axes = ["x"]
    trainer.device = torch.device("cpu")
    trainer.best_model_metric = float("-inf")
    trainer.best_model_epoch = 0
    trainer.best_val_auc = float("-inf")
    trainer.best_predict_accuracy = float("-inf")
    trainer.last_val_auc = 0.0
    trainer.last_predict_accuracy = 0.0
    trainer.global_step = 0
    trainer.resume_epoch = 1
    trainer.early_stopping_state = {
        "counter": 0,
        "best_score": None,
        "enabled": False,
        "metric": "val_loss",
        "mode": "min",
        "patience": 10,
        "min_delta": 0.001,
    }
    trainer.latest_feature_store_path = os.path.join(temp_dir, "feature_store_latest.npz")
    trainer.best_feature_store_path = os.path.join(temp_dir, "feature_store_best.npz")
    trainer.last_es_metric = 0.0
    trainer.best_es_metric = float("inf")  # min mode default
    trainer.last_ms_metric = 0.0
    trainer.optimizer = None
    trainer.scheduler = None
    trainer.scaler = None
    trainer.save_features = False
    trainer._build_feature_store = MethodType(lambda self, dataset: object(), trainer)
    trainer._save_feature_store = MethodType(lambda self, feature_store, path: path, trainer)
    trainer._compute_patient_knn_metrics = MethodType(
        lambda self, feature_store, dataset: {
            "predict_accuracy": 0.0,
            "patient_count": 0,
            "mean_patient_predict_proba": 0.0,
        },
        trainer,
    )
    return trainer


class MultiAxisTrainerProgressTest(unittest.TestCase):
    def test_validate_epoch_uses_current_epoch_for_progress_updates(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            trainer = _build_trainer(temp_dir)
            trainer._current_train_history = [{"loss": 0.1}]
            progress_bar = _DummyProgressBar()
            recorded_epochs = []

            def record_progress(self, progress_bar, epoch, total_epochs, stage, loss):
                recorded_epochs.append((stage, epoch))

            trainer._update_progress = MethodType(record_progress, trainer)

            train_loader = _DummyLoader([])
            val_loader = _DummyLoader([
                (
                    {"x": torch.ones((1, 1, 2, 2), dtype=torch.float32)},
                    torch.tensor([1.0], dtype=torch.float32),
                    ["patient-1"],
                    [0],
                    ["image-1.png"],
                ),
                (
                    {"x": torch.zeros((1, 1, 2, 2), dtype=torch.float32)},
                    torch.tensor([0.0], dtype=torch.float32),
                    ["patient-2"],
                    [0],
                    ["image-2.png"],
                ),
            ])

            trainer.validate_epoch(train_loader, val_loader, epoch=2, progress_bar=progress_bar)

            self.assertEqual(recorded_epochs, [("val", 2), ("val", 2)])


class DynamicMetricDisplayTest(unittest.TestCase):
    def test_update_progress_passes_dynamic_es_ms_metrics(self):
        """_update_progress should pass ES/MS metric info to update_training_progress."""
        with tempfile.TemporaryDirectory() as temp_dir:
            trainer = _build_trainer(temp_dir)
            trainer.early_stopping_state["metric"] = "val_auc"
            trainer.early_stopping_state["mode"] = "max"
            trainer.config.monitoring.model_selection = {
                "metric": "predict_accuracy",
                "mode": "max",
            }
            trainer.last_es_metric = 0.4522
            trainer.best_es_metric = 0.5099
            trainer.last_ms_metric = 0.4722
            trainer.best_model_metric = 0.5556
            trainer.best_model_epoch = 1

            captured = {}

            def mock_update(progress_bar, **kwargs):
                captured.update(kwargs)

            import src.training.multi_axis_trainer as mat
            original = mat.update_training_progress
            mat.update_training_progress = mock_update
            try:
                trainer._update_progress(
                    progress_bar=_DummyProgressBar(),
                    epoch=5,
                    total_epochs=100,
                    stage="train",
                    loss=0.2166,
                )
                self.assertEqual(captured["es_metric_name"], "val_auc")
                self.assertEqual(captured["es_mode"], "max")
                self.assertAlmostEqual(captured["es_last"], 0.4522)
                self.assertAlmostEqual(captured["es_best"], 0.5099)
                self.assertEqual(captured["ms_metric_name"], "predict_accuracy")
                self.assertEqual(captured["ms_mode"], "max")
                self.assertAlmostEqual(captured["ms_last"], 0.4722)
                self.assertAlmostEqual(captured["ms_best"], 0.5556)
            finally:
                mat.update_training_progress = original


if __name__ == "__main__":
    unittest.main()
