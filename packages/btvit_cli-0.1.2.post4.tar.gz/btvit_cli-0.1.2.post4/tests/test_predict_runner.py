import io
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

from src.cli import predict_impl, predict_runner


class PredictRunnerTests(unittest.TestCase):
    def test_execute_predict_args_uses_packaged_implementation(self):
        raw_args = {"model": "model.pth", "data": "dataset/data"}

        with mock.patch.object(
            predict_runner,
            "load_root_script",
            side_effect=AssertionError("legacy loader should not be used for vit pred"),
            create=True,
        ):
            with mock.patch.object(
                predict_runner,
                "execute_packaged_predict_args",
                return_value=123,
                create=True,
            ) as execute_packaged_predict_args:
                result = predict_runner.execute_predict_args(raw_args)

        self.assertEqual(result, 123)
        execute_packaged_predict_args.assert_called_once_with(raw_args)

    def test_execute_predict_args_logs_prediction_output_paths(self):
        raw_args = {
            "model": "model.pth",
            "data": "dataset/data",
            "output": None,
            "label": None,
            "verbose": False,
            "thresholds": None,
        }
        results = [
            {
                "patient_id": "PAT001",
                "png_num": 4,
                "combo_count": 64,
                "pred_true_comb_num": 48,
                "pred_false_comb_num": 16,
                "predict_acc": 0.75,
                "prediction": 1,
            }
        ]
        summary = {"patient_count": 1}

        with tempfile.TemporaryDirectory() as tmpdir:
            raw_args["output"] = tmpdir
            with mock.patch.object(predict_impl, "resolve_feature_store_path", return_value="feature_store_best.npz"):
                with mock.patch.object(
                    predict_impl,
                    "resolve_axis_data_paths",
                    return_value={"x": "data-x", "y": "data-y", "z": "data-z"},
                ):
                    with mock.patch.object(predict_impl, "collect_patient_ids", return_value=["PAT001"]):
                        with mock.patch.object(predict_impl, "load_label_map", return_value={}):
                            with mock.patch.object(predict_impl, "MultiAxisPredictor") as predictor_cls:
                                predictor_cls.return_value.predict_batch.return_value = (results, summary)

                                with redirect_stdout(io.StringIO()):
                                    result = predict_impl.execute_predict_args(raw_args)

            self.assertEqual(result, 0)

            log_files = list((Path(tmpdir) / "logs").glob("predict_*.log"))
            self.assertEqual(len(log_files), 1)

            log_contents = log_files[0].read_text(encoding="utf-8")
            self.assertIn("prediction completed", log_contents)
            self.assertIn("prediction_csv=", log_contents)
            self.assertIn("summary_json=", log_contents)


if __name__ == "__main__":
    unittest.main()
