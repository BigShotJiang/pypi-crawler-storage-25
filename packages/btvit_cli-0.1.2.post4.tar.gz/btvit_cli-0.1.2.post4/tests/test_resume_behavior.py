import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import torch
from typer.testing import CliRunner

from src.cli.main import app
from src.training.multi_axis_trainer import MultiAxisTrainer


class _FakeProgressBar:
    def update(self, *_args, **_kwargs):
        return None

    def close(self):
        return None


class _FakeLogger:
    log_file = ""

    def info(self, *_args, **_kwargs):
        return None


class _FakeLoader:
    dataset = object()

    def __len__(self):
        return 1


class _DeterministicTrainer(MultiAxisTrainer):
    def __init__(self, config, validation_metrics):
        self._validation_metrics = list(validation_metrics)
        super().__init__(config=config, logger=_FakeLogger())

    def _create_model(self):
        return torch.nn.Linear(1, 1)

    def train_epoch(self, train_loader, epoch=0, progress_bar=None):
        return {"loss": 0.1, "epoch": epoch}

    def validate_epoch(self, train_loader, val_loader, progress_bar=None):
        index = len(getattr(self, "_current_train_history", []))
        return dict(self._validation_metrics[index])


class ResumeBehaviorTests(unittest.TestCase):
    def test_cli_resume_flag_defaults_to_latest_checkpoint(self):
        runner = CliRunner()

        with patch("src.cli.train_cmd.execute_train") as execute_train:
            result = runner.invoke(app, ["train", "--config", "configs/base", "--resume"])

        self.assertEqual(result.exit_code, 0, msg=result.output)
        self.assertEqual(execute_train.call_args.kwargs["resume"], "latest")

    def test_training_state_and_latest_checkpoint_advance_every_epoch(self):
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            config = SimpleNamespace(
                training=SimpleNamespace(
                    device="cpu",
                    mixed_precision=False,
                    optimizer="SGD",
                    learning_rate=0.01,
                    weight_decay=0.0,
                    epochs=2,
                ),
                multi_axis=SimpleNamespace(
                    active_axes=["x"],
                    voting_weights={"x": 1.0},
                    shared_encoder=False,
                ),
                monitoring=SimpleNamespace(
                    predict_threshold=0.5,
                    verbose=False,
                    early_stopping={"enabled": False},
                    model_selection={"metric": "predict_accuracy", "mode": "max"},
                ),
                experiment=SimpleNamespace(
                    checkpoint_dir=str(root / "checkpoints"),
                    result_dir=str(root / "results"),
                    log_dir=str(root / "logs"),
                ),
            )
            trainer = _DeterministicTrainer(
                config=config,
                validation_metrics=[
                    {
                        "loss": 0.5,
                        "val_loss": 0.5,
                        "auc": 0.6,
                        "val_auc": 0.6,
                        "accuracy": 0.6,
                        "val_accuracy": 0.6,
                        "f1": 0.6,
                        "val_f1": 0.6,
                        "predict_accuracy": 0.4,
                    },
                    {
                        "loss": 0.4,
                        "val_loss": 0.4,
                        "auc": 0.8,
                        "val_auc": 0.8,
                        "accuracy": 0.8,
                        "val_accuracy": 0.8,
                        "f1": 0.8,
                        "val_f1": 0.8,
                        "predict_accuracy": 0.9,
                    },
                ],
            )

            with patch("src.training.multi_axis_trainer.create_training_progress", return_value=_FakeProgressBar()), patch(
                "src.training.multi_axis_trainer.update_training_progress", return_value=None
            ):
                trainer.train(_FakeLoader(), _FakeLoader())

            state = json.loads((root / "results" / "train_state.json").read_text(encoding="utf-8"))
            latest_checkpoint = torch.load(
                root / "checkpoints" / "latest_model.pth",
                map_location="cpu",
                weights_only=False,
            )

        self.assertEqual(state["current_epoch"], 2)
        self.assertEqual(state["resume_epoch"], 2)
        self.assertEqual(state["best_model_epoch"], 2)
        self.assertAlmostEqual(state["best_model_metric"], 0.9)
        self.assertEqual(latest_checkpoint["epoch"], 2)
        self.assertEqual(latest_checkpoint["best_model_epoch"], 2)
        self.assertAlmostEqual(latest_checkpoint["best_model_metric"], 0.9)


if __name__ == "__main__":
    unittest.main()
