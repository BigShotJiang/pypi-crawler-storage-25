import tempfile
import unittest
from pathlib import Path


class PredictionConfusionMatrixTest(unittest.TestCase):
    def test_labeled_predictions_generate_confusion_matrix_png(self):
        from predict import save_prediction_outputs

        rows = [
            {"patient_id": "PAT001", "png_num": 4, "comb_num": 64, "pred_true_comb_num": 60, "pred_false_comb_num": 4, "pred_prob": 0.91, "pred_result": 1, "label": 1, "pass": True},
            {"patient_id": "PAT002", "png_num": 4, "comb_num": 64, "pred_true_comb_num": 10, "pred_false_comb_num": 54, "pred_prob": 0.12, "pred_result": 0, "label": 1, "pass": False},
        ]

        with tempfile.TemporaryDirectory() as tmpdir:
            output_paths = save_prediction_outputs(rows=rows, summary={"patient_count": 2}, output_dir=Path(tmpdir))

            self.assertIn("confusion_matrix_png", output_paths)
            self.assertTrue(Path(output_paths["confusion_matrix_png"]).exists())

    def test_unlabeled_predictions_skip_confusion_matrix_png(self):
        from predict import save_prediction_outputs

        rows = [
            {"patient_id": "PAT001", "png_num": 4, "comb_num": 64, "pred_true_comb_num": 60, "pred_false_comb_num": 4, "pred_prob": 0.91, "pred_result": 1},
        ]

        with tempfile.TemporaryDirectory() as tmpdir:
            output_paths = save_prediction_outputs(rows=rows, summary={"patient_count": 1}, output_dir=Path(tmpdir))

            self.assertNotIn("confusion_matrix_png", output_paths)
            self.assertFalse((Path(tmpdir) / "confusion_matrix.png").exists())


if __name__ == "__main__":
    unittest.main()
