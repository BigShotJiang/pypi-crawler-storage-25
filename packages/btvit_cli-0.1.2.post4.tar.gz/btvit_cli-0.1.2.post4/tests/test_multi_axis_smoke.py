import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np
import torch

from src.data.dataset import MultiAxisCombinationDataset
from src.data.preprocessing import LabelProcessor, MultiAxisDatasetOrganizer
from src.model.vit_model import MultiAxisMedicalViT
from src.prediction.feature_store import FeatureStore
from src.prediction.knn import KNNClassifier, weighted_vote_probabilities
from src.prediction.multi_axis_predictor import aggregate_patient_probability


class MultiAxisSmokeTest(unittest.TestCase):
    def test_smoke_pipeline_runs_on_temp_data(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            axis_dirs = {
                "x": root / "data-x",
                "y": root / "data-y",
                "z": root / "data-z",
            }
            for axis_dir in axis_dirs.values():
                axis_dir.mkdir()

            (root / "label.csv").write_text("patient_id,label\nP001,1\n", encoding="utf-8")
            image = np.full((16, 368), 127, dtype=np.uint8)
            for axis, axis_dir in axis_dirs.items():
                for index in range(4):
                    cv2.imwrite(str(axis_dir / f"P001_{axis}_{index}.png"), image)

            label_processor = LabelProcessor(str(root / "label.csv"))
            organizer = MultiAxisDatasetOrganizer(
                {axis: str(path) for axis, path in axis_dirs.items()},
                label_processor,
                active_axes=["x", "y", "z"],
                images_per_axis=4,
            )
            dataset = MultiAxisCombinationDataset(
                patient_ids=organizer.get_all_patients(),
                organizer=organizer,
                label_processor=label_processor,
                active_axes=["x", "y", "z"],
            )
            axis_images, label, patient_id, _, image_paths = dataset[0]

            model = MultiAxisMedicalViT(active_axes=["x", "y", "z"], input_shape=(16, 368), patch_size=(16, 16))
            with torch.no_grad():
                features = model.extract_features(
                    {axis: tensor.unsqueeze(0) for axis, tensor in axis_images.items()}
                )

            feature_store = FeatureStore(active_axes=["x", "y", "z"])
            for axis in ("x", "y", "z"):
                feature_store.add(
                    axis=axis,
                    feature=features[axis].squeeze(0).cpu().numpy(),
                    label=int(label.item()),
                    image_id=image_paths[axis],
                )

            knn = KNNClassifier(active_axes=["x", "y", "z"], k=1, metric="cosine")
            knn.build_index(feature_store)
            axis_probabilities = {
                axis: float(knn.predict_proba(axis, features[axis].squeeze(0).cpu().numpy())[0])
                for axis in ("x", "y", "z")
            }
            combo_probability = weighted_vote_probabilities(axis_probabilities, {"x": 0.2, "y": 0.2, "z": 0.6})
            patient_probability = aggregate_patient_probability(np.array([combo_probability, combo_probability], dtype=np.float32))

        self.assertEqual(patient_id, "P001")
        self.assertEqual(set(features.keys()), {"x", "y", "z"})
        self.assertEqual(len(dataset), 64)
        self.assertAlmostEqual(patient_probability, 1.0)


if __name__ == "__main__":
    unittest.main()
