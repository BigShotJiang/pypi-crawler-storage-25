import tempfile
import unittest
from pathlib import Path

from src.utils.logger import get_logger
from src.utils.runtime_output import (
    create_training_progress,
    update_training_progress,
    _mode_arrow,
    _short_metric_name,
)


class RuntimeOutputTest(unittest.TestCase):
    def test_logger_can_run_without_console_output_and_still_write_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            logger = get_logger("silent_test", log_dir=tmpdir, console=False)
            logger.info("hello")

            log_files = list(Path(tmpdir).glob("*.log"))
            contents = log_files[0].read_text(encoding="utf-8") if log_files else ""

            self.assertEqual(len(log_files), 1)
            self.assertIn("hello", contents)

    def test_same_logger_name_different_dirs_do_not_reuse_previous_file_handler(self):
        with tempfile.TemporaryDirectory() as tmpdir_a, tempfile.TemporaryDirectory() as tmpdir_b:
            logger_a = get_logger("shared_name", log_dir=tmpdir_a, console=False)
            logger_a.info("from_a")

            logger_b = get_logger("shared_name", log_dir=tmpdir_b, console=False)
            logger_b.info("from_b")

            files_a = list(Path(tmpdir_a).glob("*.log"))
            files_b = list(Path(tmpdir_b).glob("*.log"))
            contents_a = files_a[0].read_text(encoding="utf-8") if files_a else ""
            contents_b = files_b[0].read_text(encoding="utf-8") if files_b else ""

            self.assertEqual(len(files_a), 1)
            self.assertEqual(len(files_b), 1)
            self.assertIn("from_a", contents_a)
            self.assertIn("from_b", contents_b)

    def test_training_progress_can_be_disabled(self):
        bar = create_training_progress(total_steps=3, verbose=False)
        try:
            self.assertTrue(getattr(bar, "disable", False))
        finally:
            bar.close()


class RuntimeOutputFormattingTest(unittest.TestCase):
    def test_mode_arrow_max(self):
        self.assertEqual(_mode_arrow("max"), "\u2191")

    def test_mode_arrow_min(self):
        self.assertEqual(_mode_arrow("min"), "\u2193")

    def test_short_metric_name_known(self):
        self.assertEqual(_short_metric_name("val_accuracy"), "val_acc")
        self.assertEqual(_short_metric_name("predict_accuracy"), "predict_acc")
        self.assertEqual(_short_metric_name("val_auc"), "val_auc")
        self.assertEqual(_short_metric_name("val_loss"), "val_loss")
        self.assertEqual(_short_metric_name("val_f1"), "val_f1")

    def test_short_metric_name_unknown_passthrough(self):
        self.assertEqual(_short_metric_name("custom_metric"), "custom_metric")

    def test_update_training_progress_formats_es_ms(self):
        bar = create_training_progress(total_steps=10, verbose=False)
        try:
            update_training_progress(
                progress_bar=bar,
                epoch=5,
                total_epochs=100,
                stage="train",
                patience_current=3,
                patience_total=50,
                show_patience=True,
                loss=0.2166,
                lr=0.00065,
                es_metric_name="val_auc",
                es_mode="max",
                es_last=0.4522,
                es_best=0.5099,
                ms_metric_name="predict_accuracy",
                ms_mode="max",
                ms_last=0.4722,
                ms_best=0.5556,
                best_epoch=1,
            )
        finally:
            bar.close()

    def test_update_training_progress_postfix_string_content(self):
        bar = create_training_progress(total_steps=10, verbose=False)
        try:
            update_training_progress(
                progress_bar=bar,
                epoch=17,
                total_epochs=500,
                stage="train",
                patience_current=14,
                patience_total=50,
                show_patience=True,
                loss=0.2166,
                lr=0.00065,
                es_metric_name="val_auc",
                es_mode="max",
                es_last=0.4522,
                es_best=0.5099,
                ms_metric_name="predict_accuracy",
                ms_mode="max",
                ms_last=0.4722,
                ms_best=0.5556,
                best_epoch=1,
            )
            postfix = bar.postfix
            self.assertIn("17/500", postfix)
            self.assertIn("train", postfix)
            self.assertIn("patience(val_auc|\u2191):14/50", postfix)
            self.assertIn("loss:0.2166", postfix)
            self.assertIn("lr:0.00065", postfix)
            self.assertIn("ES(val_auc\u2191):0.4522|0.5099", postfix)
            self.assertIn("MS(predict_acc\u2191):0.4722|0.5556", postfix)
            self.assertIn("best_epoch:1|500", postfix)
        finally:
            bar.close()

    def test_update_training_progress_min_mode_format(self):
        bar = create_training_progress(total_steps=10, verbose=False)
        try:
            update_training_progress(
                progress_bar=bar,
                epoch=5,
                total_epochs=100,
                stage="val",
                patience_current=3,
                patience_total=10,
                show_patience=True,
                loss=0.2166,
                lr=0.0001,
                es_metric_name="val_loss",
                es_mode="min",
                es_last=0.2166,
                es_best=0.1890,
                ms_metric_name="val_f1",
                ms_mode="max",
                ms_last=0.4722,
                ms_best=0.5556,
                best_epoch=3,
            )
            postfix = bar.postfix
            self.assertIn("patience(val_loss|\u2193):3/10", postfix)
            self.assertIn("ES(val_loss\u2193):0.2166|0.1890", postfix)
            self.assertIn("MS(val_f1\u2191):0.4722|0.5556", postfix)
        finally:
            bar.close()

    def test_update_training_progress_patience_hidden_when_disabled(self):
        bar = create_training_progress(total_steps=10, verbose=False)
        try:
            update_training_progress(
                progress_bar=bar,
                epoch=1,
                total_epochs=10,
                stage="train",
                patience_current=0,
                patience_total=10,
                show_patience=False,
                loss=0.5,
                lr=0.001,
                es_metric_name="val_loss",
                es_mode="min",
                es_last=0.0,
                es_best=0.0,
                ms_metric_name="predict_accuracy",
                ms_mode="max",
                ms_last=0.0,
                ms_best=0.0,
                best_epoch=0,
            )
            postfix = bar.postfix
            self.assertNotIn("patience(", postfix)
            self.assertIn("ES(val_loss\u2193)", postfix)
        finally:
            bar.close()


if __name__ == "__main__":
    unittest.main()
