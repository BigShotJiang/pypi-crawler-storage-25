import unittest

import numpy as np

from src.prediction.feature_store import FeatureStore
from src.prediction.knn import KNNClassifier, weighted_vote_probabilities


class FeatureStoreAndKNNTest(unittest.TestCase):
    def test_feature_store_saves_unique_axis_features(self):
        store = FeatureStore(active_axes=["x", "y", "z"])
        store.add(axis="x", feature=np.array([1.0, 0.0], dtype=np.float32), label=1, image_id="P001_x_0")
        store.add(axis="x", feature=np.array([1.0, 0.0], dtype=np.float32), label=1, image_id="P001_x_0")

        self.assertEqual(store.get_features("x")[0].shape[0], 1)

    def test_knn_predicts_probability_per_axis_and_weighted_vote(self):
        store = FeatureStore(active_axes=["x", "y", "z"])
        store.add("x", np.array([1.0, 0.0], dtype=np.float32), 1, "x1")
        store.add("y", np.array([1.0, 0.0], dtype=np.float32), 1, "y1")
        store.add("z", np.array([0.0, 1.0], dtype=np.float32), 0, "z1")

        knn = KNNClassifier(active_axes=["x", "y", "z"], k=1, metric="cosine")
        knn.build_index(store)

        axis_probs = {
            "x": knn.predict_proba("x", np.array([[1.0, 0.0]], dtype=np.float32))[0],
            "y": knn.predict_proba("y", np.array([[1.0, 0.0]], dtype=np.float32))[0],
            "z": knn.predict_proba("z", np.array([[0.0, 1.0]], dtype=np.float32))[0],
        }
        combo_prob = weighted_vote_probabilities(axis_probs, {"x": 0.2, "y": 0.2, "z": 0.6})

        self.assertAlmostEqual(axis_probs["x"], 1.0)
        self.assertAlmostEqual(axis_probs["y"], 1.0)
        self.assertAlmostEqual(axis_probs["z"], 0.0)
        self.assertAlmostEqual(combo_prob, 0.4)


if __name__ == "__main__":
    unittest.main()
