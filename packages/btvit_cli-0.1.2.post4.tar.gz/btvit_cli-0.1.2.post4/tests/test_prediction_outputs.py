import csv
import tempfile
import unittest
from pathlib import Path


class PredictionOutputsTest(unittest.TestCase):
    def test_default_prediction_csv_uses_approved_schema_and_filenames(self):
        from predict import build_prediction_rows, save_prediction_outputs

        results = [
            {
                "patient_id": "PAT001",
                "png_num": 4,
                "combo_count": 64,
                "pred_true_comb_num": 50,
                "pred_false_comb_num": 14,
                "predict_acc": 0.812345,
                "prediction": 1,
            }
        ]

        with tempfile.TemporaryDirectory() as tmpdir:
            output_paths = save_prediction_outputs(
                rows=build_prediction_rows(results, {}),
                summary={"patient_count": 1},
                output_dir=Path(tmpdir),
            )

            self.assertEqual(Path(output_paths["prediction_csv"]).name, "predictions.csv")
            self.assertEqual(Path(output_paths["summary_json"]).name, "prediction_summary.json")

            with open(output_paths["prediction_csv"], "r", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                self.assertEqual(
                    reader.fieldnames,
                    [
                        "patient_id",
                        "png_num",
                        "comb_num",
                        "pred_true_comb_num",
                        "pred_false_comb_num",
                        "pred_prob",
                        "pred_result",
                    ],
                )

    def test_labeled_prediction_csv_appends_label_and_pass_columns(self):
        from predict import build_prediction_rows, save_prediction_outputs

        results = [
            {
                "patient_id": "PAT001",
                "png_num": 4,
                "combo_count": 64,
                "pred_true_comb_num": 50,
                "pred_false_comb_num": 14,
                "predict_acc": 0.812345,
                "prediction": 1,
            }
        ]

        with tempfile.TemporaryDirectory() as tmpdir:
            output_paths = save_prediction_outputs(
                rows=build_prediction_rows(results, {"PAT001": 1}),
                summary={"patient_count": 1, "predict_accuracy": 1.0},
                output_dir=Path(tmpdir),
            )

            with open(output_paths["prediction_csv"], "r", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle)
                self.assertEqual(
                    reader.fieldnames,
                    [
                        "patient_id",
                        "png_num",
                        "comb_num",
                        "pred_true_comb_num",
                        "pred_false_comb_num",
                        "pred_prob",
                        "pred_result",
                        "label",
                        "pass",
                    ],
                )


if __name__ == "__main__":
    unittest.main()
