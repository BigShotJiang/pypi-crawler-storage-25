import tempfile
import textwrap
import unittest
from pathlib import Path

from src.utils.config import load_config


class MultiAxisConfigTest(unittest.TestCase):
    def write_yaml(self, root: Path, name: str, content: str) -> None:
        (root / name).write_text(textwrap.dedent(content).strip() + "\n", encoding="utf-8")

    def test_load_config_reads_multi_axis_and_monitoring_blocks(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir)
            self.write_yaml(config_dir, "model_config.yaml", "model:\n  input_shape: [16, 368]\n")
            self.write_yaml(config_dir, "data_config.yaml", "data:\n  label_path: dataset/label.csv\n")
            self.write_yaml(config_dir, "training_config.yaml", "epochs: 3\n")
            self.write_yaml(config_dir, "experiment_config.yaml", "name: demo\n")
            self.write_yaml(
                config_dir,
                "multi_axis_config.yaml",
                """
                multi_axis:
                  enabled: true
                  axis_data_paths:
                    x: dataset/data-x
                    y: dataset/data-y
                    z: dataset/data-z
                  active_axes: [x, y, z]
                  voting_weights: {x: 0.2, y: 0.2, z: 0.6}
                  images_per_axis: 4
                  knn_k: 7
                  knn_metric: cosine
                """,
            )
            self.write_yaml(
                config_dir,
                "monitoring_config.yaml",
                """
                monitoring:
                  early_stopping:
                    enabled: false
                    metric: val_auc
                    mode: max
                    patience: 5
                    min_delta: 0.001
                  model_selection:
                    metric: predict_accuracy
                    mode: max
                  predict_threshold: 0.55
                  verbose: true
                """,
            )

            config = load_config(str(config_dir))

        self.assertTrue(config.multi_axis.enabled)
        self.assertEqual(config.multi_axis.images_per_axis, 4)
        self.assertEqual(config.multi_axis.knn_k, 7)
        self.assertEqual(config.monitoring.model_selection["metric"], "predict_accuracy")
        self.assertFalse(config.monitoring.early_stopping["enabled"])
        self.assertEqual(config.monitoring.predict_threshold, 0.55)
        self.assertTrue(config.monitoring.verbose)


if __name__ == "__main__":
    unittest.main()
