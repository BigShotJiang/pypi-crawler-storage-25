import json
import tempfile
import unittest
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from types import MethodType, SimpleNamespace
from unittest.mock import patch

from src.training.multi_axis_trainer import MultiAxisTrainer


class _DummyLogger:
    log_file = ""

    def info(self, _message):
        pass


class _DummyProgress:
    def update(self, _steps):
        pass

    def close(self):
        pass


def _completed_future(result=None):
    future = Future()
    future.set_result(result)
    return future


def _build_trainer(base_dir: Path):
    checkpoint_dir = base_dir / "checkpoints"
    result_dir = base_dir / "results"
    log_dir = base_dir / "logs"
    checkpoint_dir.mkdir()
    result_dir.mkdir()
    log_dir.mkdir()

    trainer = MultiAxisTrainer.__new__(MultiAxisTrainer)
    trainer.config = SimpleNamespace(
        training=SimpleNamespace(epochs=5, scheduler=""),
        monitoring=SimpleNamespace(
            verbose=False,
            model_selection={"metric": "predict_accuracy", "mode": "max"},
        ),
        experiment=SimpleNamespace(
            checkpoint_dir=str(checkpoint_dir),
            result_dir=str(result_dir),
            log_dir=str(log_dir),
        ),
    )
    trainer.logger = _DummyLogger()
    trainer.scheduler = None
    trainer.resume_epoch = 0
    trainer.best_val_auc = float("-inf")
    trainer.best_predict_accuracy = float("-inf")
    trainer.best_model_metric = float("-inf")
    trainer.best_model_epoch = 0
    trainer.global_step = 0
    trainer.save_features = False
    trainer.latest_feature_store_path = None
    trainer.best_feature_store_path = None
    trainer.early_stopping_state = {
        "counter": 0,
        "best_score": 1.0,
        "enabled": True,
        "metric": "val_auc",
        "mode": "max",
        "patience": 1,
        "min_delta": 1e-5,
    }
    trainer._io = {
        "latest_model": ThreadPoolExecutor(max_workers=1),
        "best_model": ThreadPoolExecutor(max_workers=1),
        "latest_feature": ThreadPoolExecutor(max_workers=1),
        "best_feature": ThreadPoolExecutor(max_workers=1),
        "state": ThreadPoolExecutor(max_workers=1),
    }

    def fake_train_epoch(self, train_loader, epoch=0, progress_bar=None):
        return {"loss": 0.1}

    def fake_validate_epoch(self, train_loader, val_loader, epoch=None, progress_bar=None):
        return {
            "loss": 0.2,
            "val_loss": 0.2,
            "auc": 0.4,
            "val_auc": 0.4,
            "accuracy": 0.5,
            "val_accuracy": 0.5,
            "f1": 0.0,
            "val_f1": 0.0,
            "predict_accuracy": 0.6,
        }

    def fake_save_checkpoint(self, epoch, kind="latest"):
        return str(checkpoint_dir / f"{kind}.pth"), _completed_future()

    def fake_update_progress(self, progress_bar, epoch, total_epochs, stage, loss):
        return None

    trainer.train_epoch = MethodType(fake_train_epoch, trainer)
    trainer.validate_epoch = MethodType(fake_validate_epoch, trainer)
    trainer.save_checkpoint = MethodType(fake_save_checkpoint, trainer)
    trainer._update_progress = MethodType(fake_update_progress, trainer)

    return trainer


class MultiAxisTrainerStatePersistenceTest(unittest.TestCase):
    def test_train_persists_final_state_when_early_stop_occurs(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            base_dir = Path(tmpdir)
            trainer = _build_trainer(base_dir)

            with patch(
                "src.training.multi_axis_trainer.create_training_progress",
                return_value=_DummyProgress(),
            ):
                train_history, val_history = trainer.train([None], [None])

            state_path = base_dir / "results" / "train_state.json"
            self.assertEqual(len(train_history), 1)
            self.assertEqual(len(val_history), 1)
            self.assertTrue(state_path.exists())

            train_state = json.loads(state_path.read_text(encoding="utf-8"))
            self.assertEqual(train_state["status"], "early_stopped")
            self.assertEqual(train_state["current_epoch"], 1)


if __name__ == "__main__":
    unittest.main()
