import pytest
import torch
import torch.nn as nn

from src.training.loss import LabelSmoothingBCEWithLogits, create_criterion


class TestLabelSmoothingBCEWithLogits:
    def test_output_is_scalar(self):
        loss_fn = LabelSmoothingBCEWithLogits(smoothing=0.1)
        logits = torch.randn(8, 1)
        targets = torch.randint(0, 2, (8, 1)).float()
        loss = loss_fn(logits, targets)
        assert loss.dim() == 0

    def test_smoothing_changes_loss(self):
        """Label smoothing should change loss value vs plain BCE
        (targets are pulled toward 0.5, increasing loss for overconfident predictions)."""
        loss_fn = LabelSmoothingBCEWithLogits(smoothing=0.1)
        bce_fn = nn.BCEWithLogitsLoss()
        logits = torch.tensor([[5.0], [-5.0], [5.0], [-5.0]])
        targets = torch.tensor([[1.0], [0.0], [1.0], [0.0]])
        smooth_loss = loss_fn(logits, targets)
        bce_loss = bce_fn(logits, targets)
        assert smooth_loss.item() != bce_loss.item()

    def test_zero_smoothing_matches_bce(self):
        loss_fn = LabelSmoothingBCEWithLogits(smoothing=0.0)
        bce_fn = nn.BCEWithLogitsLoss()
        logits = torch.randn(4, 1)
        targets = torch.randint(0, 2, (4, 1)).float()
        assert torch.allclose(loss_fn(logits, targets), bce_fn(logits, targets), atol=1e-6)

    def test_with_pos_weight(self):
        loss_fn = LabelSmoothingBCEWithLogits(smoothing=0.1, pos_weight=2.0)
        logits = torch.randn(8, 1)
        targets = torch.randint(0, 2, (8, 1)).float()
        loss = loss_fn(logits, targets)
        assert loss.dim() == 0
        assert loss.item() > 0


class TestCreateCriterion:
    def _make_config(self, loss_dict=None):
        """Create a mock config object with loss dict."""
        class MockConfig:
            pass
        cfg = MockConfig()
        cfg.training = MockConfig()
        cfg.training.loss = loss_dict or {}
        return cfg

    def test_default_returns_bce(self):
        cfg = self._make_config()
        criterion = create_criterion(cfg)
        assert isinstance(criterion, nn.BCEWithLogitsLoss)

    def test_focal_type(self):
        from src.utils.metrics import FocalLoss
        cfg = self._make_config({"type": "focal", "focal_alpha": 0.25, "focal_gamma": 2.0})
        criterion = create_criterion(cfg)
        assert isinstance(criterion, FocalLoss)

    def test_bce_label_smoothing_type(self):
        cfg = self._make_config({"type": "bce_label_smoothing", "label_smoothing": 0.1})
        criterion = create_criterion(cfg)
        assert isinstance(criterion, LabelSmoothingBCEWithLogits)

    def test_bce_with_pos_weight(self):
        cfg = self._make_config({"type": "bce"})
        criterion = create_criterion(cfg, pos_weight=2.5)
        assert isinstance(criterion, nn.BCEWithLogitsLoss)

    def test_invalid_type_raises(self):
        cfg = self._make_config({"type": "nonexistent"})
        with pytest.raises(ValueError, match="Unsupported loss type"):
            create_criterion(cfg)

    def test_pos_weight_override(self):
        """When pos_weight is passed explicitly, it should be used."""
        cfg = self._make_config({"type": "bce"})
        criterion = create_criterion(cfg, pos_weight=3.0)
        assert isinstance(criterion, nn.BCEWithLogitsLoss)
        pw = criterion.pos_weight
        assert pw is not None
        assert abs(pw.item() - 3.0) < 1e-6


class TestLossConfigRoundTrip:
    def test_config_with_focal_loss(self, tmp_path):
        """Config with loss dict -> trainer uses FocalLoss."""
        import yaml
        from src.utils.config import Config
        from src.utils.metrics import FocalLoss

        config_dir = tmp_path / "cfg"
        config_dir.mkdir()
        with open(config_dir / "training_config.yaml", "w") as f:
            yaml.dump({"loss": {"type": "focal", "focal_alpha": 0.5, "focal_gamma": 3.0}}, f)
        with open(config_dir / "model_config.yaml", "w") as f:
            yaml.dump({"model": {"input_shape": [16, 368], "patch_size": [16, 16]}}, f)
        with open(config_dir / "data_config.yaml", "w") as f:
            yaml.dump({"data": {}}, f)
        with open(config_dir / "multi_axis_config.yaml", "w") as f:
            yaml.dump({"multi_axis": {"enabled": True, "axis_loss_weights": {"x": 1.0, "y": 0.5, "z": 2.0}}}, f)
        with open(config_dir / "experiment_config.yaml", "w") as f:
            yaml.dump({"name": "test", "save_dir": str(tmp_path)}, f)
        with open(config_dir / "monitoring_config.yaml", "w") as f:
            yaml.dump({"monitoring": {}}, f)

        cfg = Config(str(config_dir))
        assert cfg.training.loss["type"] == "focal"
        assert cfg.multi_axis.axis_loss_weights["z"] == 2.0

        criterion = create_criterion(cfg)
        assert isinstance(criterion, FocalLoss)
        assert criterion.alpha == 0.5
        assert criterion.gamma == 3.0

    def test_config_without_loss_defaults_to_bce(self, tmp_path):
        """Config without loss dict -> trainer uses default BCEWithLogitsLoss."""
        import yaml
        from src.utils.config import Config

        config_dir = tmp_path / "cfg"
        config_dir.mkdir()
        with open(config_dir / "training_config.yaml", "w") as f:
            yaml.dump({}, f)
        with open(config_dir / "model_config.yaml", "w") as f:
            yaml.dump({"model": {"input_shape": [16, 368], "patch_size": [16, 16]}}, f)
        with open(config_dir / "data_config.yaml", "w") as f:
            yaml.dump({"data": {}}, f)
        with open(config_dir / "multi_axis_config.yaml", "w") as f:
            yaml.dump({"multi_axis": {"enabled": True}}, f)
        with open(config_dir / "experiment_config.yaml", "w") as f:
            yaml.dump({"name": "test", "save_dir": str(tmp_path)}, f)
        with open(config_dir / "monitoring_config.yaml", "w") as f:
            yaml.dump({"monitoring": {}}, f)

        cfg = Config(str(config_dir))
        assert cfg.training.loss == {}
        criterion = create_criterion(cfg)
        assert isinstance(criterion, nn.BCEWithLogitsLoss)
