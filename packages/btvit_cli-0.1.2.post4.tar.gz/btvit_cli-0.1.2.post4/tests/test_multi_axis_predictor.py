import unittest
from unittest.mock import patch

import numpy as np

import predict
from src.prediction.multi_axis_predictor import MultiAxisPredictor, aggregate_patient_probability


class MultiAxisPredictorTest(unittest.TestCase):
    def test_patient_probability_is_mean_of_combination_probabilities(self):
        combo_probs = np.array([0.2, 0.4, 0.8, 1.0], dtype=np.float32)
        proba = aggregate_patient_probability(combo_probs)

        self.assertAlmostEqual(proba, 0.6)

    def test_parse_args_accepts_multi_axis_feature_store_and_verbose_flags(self):
        args = predict.parse_args([
            "--checkpoint", "best_model.pth",
            "--mode", "image",
            "--input", "sample.png",
            "--feature_store", "features.npz",
            "--verbose",
        ])

        self.assertEqual(args.feature_store, "features.npz")
        self.assertTrue(args.verbose)

    def test_parse_args_keeps_default_thresholds_without_extra_mode_flags(self):
        args = predict.parse_args([
            "--checkpoint", "best_model.pth",
            "--mode", "image",
            "--input", "sample.png",
        ])

        self.assertEqual(args.checkpoint, "best_model.pth")
        self.assertEqual(args.mode, "image")

    def test_predict_batch_uses_verbose_gated_prediction_progress(self):
        calls = []
        updates = []

        class DummyBar:
            def update(self, value):
                updates.append(value)

            def close(self):
                updates.append("closed")

        def fake_progress(total_steps, verbose):
            calls.append((total_steps, verbose))
            return DummyBar()

        predictor = MultiAxisPredictor.__new__(MultiAxisPredictor)
        predictor.verbose = False
        predictor.predict_patient = lambda patient_id, axis_data_paths: {
            "patient_id": patient_id,
            "patient_predict_proba": 0.75,
            "prediction": 1,
        }

        with patch("src.prediction.multi_axis_predictor.create_prediction_progress", side_effect=fake_progress):
            results, summary = MultiAxisPredictor.predict_batch(
                predictor,
                patient_ids=["P001", "P002"],
                axis_data_paths={"x": "/tmp/x", "y": "/tmp/y", "z": "/tmp/z"},
                label_path=None,
            )

        self.assertEqual(calls, [(2, False)])
        self.assertEqual(updates, [1, 1, "closed"])
        self.assertEqual(len(results), 2)
        self.assertEqual(summary["patient_count"], 2)


if __name__ == "__main__":
    unittest.main()
