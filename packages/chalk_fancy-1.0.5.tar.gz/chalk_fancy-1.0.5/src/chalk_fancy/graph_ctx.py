from __future__ import annotations

from contextlib import contextmanager, asynccontextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
import os
from pathlib import Path
import sys
from typing import Any, Dict, Iterator, Optional, Tuple, Awaitable, Callable


@dataclass(frozen=True, slots=True)
class GraphCtx:
    graph: Any = None
    meta: Dict[str, Any] = field(default_factory=dict)


_CURRENT_GRAPH_CTX: ContextVar[Optional[GraphCtx]] = ContextVar(
    "chalk_fancy.current_graph_ctx", default=None
)

_DOTENV_LOADED: bool = False
_REQUESTER: Optional[Callable[[str, str, Dict[str, Any]], Awaitable[Any]]] = None
_DEFAULT_SERVER_URL = "https://ctx-graphics.vercel.app"


def set_requester(
    requester: Callable[[str, str, Dict[str, Any]], Awaitable[Any]],
) -> None:
    """
    Register the parent project's async request function.

    Expected shape (example):
      res = await requester("POST", "https://ctx-graphics.vercel.app/api/ctx", {"ctx_user_id": "..."})
    """
    global _REQUESTER
    _REQUESTER = requester


def _server_url() -> str:
    return (os.getenv("CHALK_FANCY_SERVER_URL") or _DEFAULT_SERVER_URL).rstrip("/")


def _parse_env_line(line: str) -> Optional[Tuple[str, str]]:
    line = line.strip()
    if not line or line.startswith("#"):
        return None
    if line.startswith("export "):
        line = line[len("export ") :].lstrip()
    if "=" not in line:
        return None
    key, value = line.split("=", 1)
    key = key.strip()
    value = value.strip()
    if not key:
        return None
    if (
        len(value) >= 2
        and ((value[0] == value[-1] == '"') or (value[0] == value[-1] == "'"))
    ):
        value = value[1:-1]
    return key, value


def _find_dotenv(start: Path) -> Optional[Path]:
    for p in (start, *start.parents):
        candidate = p / ".env"
        if candidate.is_file():
            return candidate
    return None


def _load_dotenv(*, override: bool = False) -> None:
    global _DOTENV_LOADED
    if _DOTENV_LOADED:
        return
    _DOTENV_LOADED = True

    explicit = os.getenv("CHALK_FANCY_DOTENV_PATH")
    if explicit:
        dotenv = Path(explicit).expanduser()
        if dotenv.is_dir():
            dotenv = dotenv / ".env"
        if not dotenv.is_file():
            return
    else:
        # Prefer parent project's .env: search from CWD and from entry script.
        candidates: list[Path] = [Path.cwd()]
        argv0 = (sys.argv[0] or "").strip()
        if argv0 and argv0 not in ("-c", "-m"):
            try:
                candidates.append(Path(argv0).resolve().parent)
            except OSError:
                pass

        dotenv = None
        for start in candidates:
            dotenv = _find_dotenv(start)
            if dotenv is not None:
                break
        if dotenv is None:
            return

    try:
        content = dotenv.read_text(encoding="utf-8")
    except OSError:
        return

    for raw in content.splitlines():
        parsed = _parse_env_line(raw)
        if parsed is None:
            continue
        key, value = parsed
        if override or key not in os.environ:
            os.environ[key] = value


def get_graph_ctx(*, require: bool = False) -> Optional[GraphCtx]:
    ctx = _CURRENT_GRAPH_CTX.get()
    
    if require and ctx is None:
        raise RuntimeError("Graph context is not initialized in the current context.")
    return ctx


def init_graph_ctx(*, graph: Any = None, **meta: Any) -> GraphCtx:
    """
    Initialize the current graph context for this logical execution context.

    Note: This sets a ContextVar (safe with async tasks/threads when propagated).
    Prefer `graph_context(...)` when you want automatic reset.
    """
    _load_dotenv()
    if "ctx_user_id" not in meta:
        ctx_user_id = os.getenv("CTX_USER_ID") or os.getenv("USER_ID")
        if ctx_user_id:
            meta["ctx_user_id"] = ctx_user_id
    ctx = GraphCtx(graph=graph, meta=dict(meta))
    _CURRENT_GRAPH_CTX.set(ctx)
    return ctx


@contextmanager
def sync_graph_context() -> Iterator[GraphCtx]:
    _load_dotenv()
    ctx_user_id = os.getenv("CTX_USER_ID") or os.getenv("USER_ID")
    if not ctx_user_id:
        raise RuntimeError(
            "Missing CTX_USER_ID. Set CTX_USER_ID in the parent project's .env (or as an environment variable)."
        )
    ctx = GraphCtx(graph=None, meta={"ctx_user_id": ctx_user_id})
    token = _CURRENT_GRAPH_CTX.set(ctx)

    ##
    try:
        yield ctx
    finally:
        _CURRENT_GRAPH_CTX.reset(token)


@asynccontextmanager
async def graph_context() -> Iterator[GraphCtx]:
    async with async_graph_context() as ctx:
        yield ctx


@asynccontextmanager
async def async_graph_context() -> Iterator[GraphCtx]:
    if _REQUESTER is None:
        raise RuntimeError(
            "No requester set. Call set_requester(request) with your project's async request function."
        )

    _load_dotenv()
    ctx_user_id = os.getenv("CTX_USER_ID") or os.getenv("USER_ID")
    if not ctx_user_id:
        raise RuntimeError(
            "Missing CTX_USER_ID. Set CTX_USER_ID in the parent project's .env (or as an environment variable)."
        )
    url = f"{_server_url()}/api/ctx"
    await _REQUESTER("POST", url, {"ctx_user_id": ctx_user_id})

    ctx = GraphCtx(graph=None, meta={"ctx_user_id": ctx_user_id, "ctx_id": None})
    token = _CURRENT_GRAPH_CTX.set(ctx)
    try:
        yield ctx
    finally:
        _CURRENT_GRAPH_CTX.reset(token)
