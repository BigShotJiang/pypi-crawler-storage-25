# chalk-fancy

Minimal Python module that provides a "graph context" initializer.

## Install (editable)

```bash
python -m pip install -e .
```

## Usage

### Load ctx user id from parent project `.env`

In your **parent project** `.env`:

```env
CTX_USER_ID=alice
```

Then:

```python
from chalk_fancy import init_graph_ctx, get_graph_ctx

init_graph_ctx(graph={"id": "g1"})
ctx = get_graph_ctx(require=True)
assert ctx.meta["ctx_user_id"] == "alice"
```

### Scoped context (auto-reset)

```python
from chalk_fancy import sync_graph_context, get_graph_ctx

with sync_graph_context():
    ctx = get_graph_ctx(require=True)
    assert ctx.meta["ctx_user_id"] == "alice"
```

### Create ctx via API (async)

Register your project's `request` once:

```python
from chalk_fancy import set_requester, graph_context, get_graph_ctx

set_requester(request)  # your project's async request(method, path, json)

async with graph_context():
    ctx = get_graph_ctx(require=True)
    print(ctx.meta["ctx_user_id"])
    # ctx.meta["ctx_id"] is always None (response is not inspected)
```

By default, the module calls `https://ctx-graphics.vercel.app/api/ctx`. Override with:

```env
CHALK_FANCY_SERVER_URL=https://your-server
```
