# notion-api-utils — Complete Reference for LLMs

## What This Library Does

`notion-api-utils` converts Python dicts to/from the Notion API's verbose JSON format using declarative schemas. Instead of manually building nested JSON for each property type, you define a `Schema` once and call `to_notion_properties()` or `from_notion_properties()`.

No dependencies. Python 3.7+.

```
pip install notion-api-utils
```

---

## Core Concepts

There are 3 building blocks:

1. `Field` — maps a source dict key to a Notion property name + type
2. `Schema` — a collection of `Field`s
3. `to_notion_properties()` / `from_notion_properties()` — the conversion functions

---

## Imports

```python
from notion_api_utils import (
    Schema, Field, to_notion_properties, from_notion_properties,
    Title, RichText, Number, Select, MultiSelect, Date,
    Checkbox, Email, Url, PhoneNumber, Status, Relation, People, Files,
)
```

---

## Schema & Field

```python
Field(notion_name: str, property_type: type[NotionProperty], source_key: str | None = None)
```

- `notion_name` — the exact Notion property name (e.g. `"Name"`, `"Created At"`)
- `property_type` — one of the type classes listed below
- `source_key` — optional; if the key in your source dict differs from the schema dict key

```python
Schema(fields: dict[str, Field])
```

The dict keys are your logical field names. They are used as lookup keys in the source data (unless `source_key` overrides it).

---

## Converting Dict → Notion JSON

```python
to_notion_properties(data: dict, schema: Schema) -> dict
```

Takes a flat Python dict and returns a dict ready to use as `"properties"` in a Notion API `pages.create` or `pages.update` call.

Missing keys in `data` are silently skipped (no error).

### Example

```python
schema = Schema(fields={
    "name":   Field("Name", Title),
    "email":  Field("Email", Email),
    "age":    Field("Age", Number),
    "status": Field("Status", Select),
    "date":   Field("Created At", Date),
})

data = {"name": "Lucas", "email": "lucas@example.com", "age": 25, "status": "Active", "date": "2026-03-25"}

result = to_notion_properties(data, schema)
```

Output:

```json
{
  "Name": {"title": [{"text": {"content": "Lucas"}}]},
  "Email": {"email": "lucas@example.com"},
  "Age": {"number": 25},
  "Status": {"select": {"name": "Active"}},
  "Created At": {"date": {"start": "2026-03-25"}}
}
```

---

## Converting Notion JSON → Dict

```python
from_notion_properties(properties: dict, schema: Schema) -> dict
```

Takes the `"properties"` dict from a Notion API response and extracts clean Python values using the same schema.

### Example

```python
# Notion API response properties
notion_props = {
    "Name": {"title": [{"text": {"content": "Lucas"}}]},
    "Age": {"number": 25},
    "Status": {"select": {"name": "Active"}},
}

schema = Schema(fields={
    "name":   Field("Name", Title),
    "age":    Field("Age", Number),
    "status": Field("Status", Select),
})

result = from_notion_properties(notion_props, schema)
# {"name": "Lucas", "age": 25, "status": "Active"}
```

---

## All Property Types — Input Format and Output JSON

### Title
- Input: `str`
- JSON: `{"title": [{"text": {"content": "value"}}]}`

### RichText
- Input: `str`
- JSON: `{"rich_text": [{"text": {"content": "value"}}]}`

### Number
- Input: `int | float`
- JSON: `{"number": 42}`

### Select
- Input: `str`
- JSON: `{"select": {"name": "value"}}`

### MultiSelect
- Input: `list[str]`
- JSON: `{"multi_select": [{"name": "A"}, {"name": "B"}]}`

### Date
- Input: `str`, `date`, `datetime`, or `{"start": ..., "end": ...}`
- JSON: `{"date": {"start": "2026-03-25"}}` or `{"date": {"start": "...", "end": "..."}}`
- `date`/`datetime` objects are auto-converted via `.isoformat()`

### Checkbox
- Input: `bool`
- JSON: `{"checkbox": true}`

### Email
- Input: `str`
- JSON: `{"email": "a@b.com"}`

### Url
- Input: `str`
- JSON: `{"url": "https://example.com"}`

### PhoneNumber
- Input: `str`
- JSON: `{"phone_number": "+5511999999999"}`

### Status
- Input: `str`
- JSON: `{"status": {"name": "Done"}}`

### Relation
- Input: `list[str]` (Notion page IDs)
- JSON: `{"relation": [{"id": "page-id-1"}, {"id": "page-id-2"}]}`

### People
- Input: `list[str]` (Notion user IDs)
- JSON: `{"people": [{"object": "user", "id": "user-id"}]}`

### Files
- Input: `list[str]` (external URLs)
- JSON: `{"files": [{"name": "url", "type": "external", "external": {"url": "url"}}]}`

---

## source_key — Remapping Dict Keys

When your source dict uses a different key than your schema key:

```python
schema = Schema(fields={
    "nome": Field("Name", Title, source_key="nome_completo"),
})

data = {"nome_completo": "Lucas"}
to_notion_properties(data, schema)
# {"Name": {"title": [{"text": {"content": "Lucas"}}]}}
```

Without `source_key`, the library looks up `data["nome"]`. With `source_key="nome_completo"`, it looks up `data["nome_completo"]` instead.

---

## Behavior Notes

- Missing keys in the source data are silently skipped — no error, the property is just omitted from the output.
- `Date` accepts both a plain value (used as `start`) and a dict with `start`/`end` keys.
- `Relation`, `People`, and `Files` accept a single string or a list of strings — single strings are auto-wrapped in a list.
- `from_notion_properties` only extracts properties that exist in the schema; unknown Notion properties are ignored.
- `from_notion_properties` returns the schema dict key (not the Notion property name) as the result key.

---

## Full Roundtrip Example

```python
from notion_api_utils import (
    Schema, Field, to_notion_properties, from_notion_properties,
    Title, Number, Select, Date, MultiSelect, Checkbox, Email,
    Url, PhoneNumber, Status, Relation, People, Files, RichText,
)

schema = Schema(fields={
    "name":    Field("Name", Title),
    "bio":     Field("Bio", RichText),
    "age":     Field("Age", Number),
    "status":  Field("Status", Select),
    "tags":    Field("Tags", MultiSelect),
    "date":    Field("Created At", Date),
    "active":  Field("Active", Checkbox),
    "email":   Field("Email", Email),
    "site":    Field("Website", Url),
    "phone":   Field("Phone", PhoneNumber),
    "stage":   Field("Stage", Status),
    "related": Field("Related", Relation),
    "team":    Field("Team", People),
    "docs":    Field("Docs", Files),
})

data = {
    "name": "Lucas",
    "bio": "Developer",
    "age": 25,
    "status": "Active",
    "tags": ["python", "api"],
    "date": {"start": "2026-01-01", "end": "2026-12-31"},
    "active": True,
    "email": "lucas@example.com",
    "site": "https://example.com",
    "phone": "+5511999999999",
    "stage": "In Progress",
    "related": ["page-id-1", "page-id-2"],
    "team": ["user-id-1"],
    "docs": ["https://example.com/file.pdf"],
}

# Dict → Notion JSON
notion_props = to_notion_properties(data, schema)

# Notion JSON → Dict
parsed = from_notion_properties(notion_props, schema)
# parsed == original data (with dates as start-only strings)
```

---

## Integration with Notion API

The output of `to_notion_properties` goes directly into the Notion API request body:

```python
import requests

notion_props = to_notion_properties(data, schema)

response = requests.post(
    "https://api.notion.com/v1/pages",
    headers={
        "Authorization": "Bearer <token>",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
    },
    json={
        "parent": {"database_id": "<database-id>"},
        "properties": notion_props,
    },
)
```

To read back:

```python
response = requests.get(
    "https://api.notion.com/v1/pages/<page-id>",
    headers={
        "Authorization": "Bearer <token>",
        "Notion-Version": "2022-06-28",
    },
)

page = response.json()
parsed = from_notion_properties(page["properties"], schema)
```
