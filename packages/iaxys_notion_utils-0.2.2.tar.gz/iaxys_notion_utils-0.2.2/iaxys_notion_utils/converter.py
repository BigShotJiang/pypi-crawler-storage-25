from typing import Any

from .schema import Schema


def to_notion_properties(data: dict[str, Any], schema: Schema) -> dict[str, dict]:
    """Convert a dict to Notion API properties JSON using a schema."""
    resolved = schema.resolve(data)
    return {name: prop.to_dict() for name, prop in resolved.items()}
