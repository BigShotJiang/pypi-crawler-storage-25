from typing import Any

from .schema import Schema


def _extract_formula(v: dict | None) -> Any:
    if not v:
        return None

    ftype = v.get("type")

    if ftype in ("string", "number", "boolean"):
        return v.get(ftype)

    if ftype == "date":
        return (v.get("date") or {}).get("start")

    return None


def _extract_rollup(v: dict | None) -> Any:
    if not v:
        return None

    rtype = v.get("type")

    if rtype == "array":
        return v.get("array") or []

    if rtype == "number":
        return v.get("number")

    if rtype == "date":
        return (v.get("date") or {}).get("start")

    return None


def _extract_unique_id(v: dict | None) -> str:
    if not v:
        return ""
    return f"{v.get('prefix', '')}{v.get('number', '')}"


def from_notion_properties(
    properties: dict[str, Any], schema: Schema
) -> dict[str, Any]:
    """Extract clean values from Notion API properties JSON using a schema."""
    extractors = {
        "title": lambda v: v[0]["text"]["content"] if v else None,
        "rich_text": lambda v: v[0]["text"]["content"] if v else None,
        "number": lambda v: v,
        "select": lambda v: v["name"] if v else None,
        "multi_select": lambda v: [i["name"] for i in v],
        "date": lambda v: v["start"] if v else None,
        "checkbox": lambda v: v,
        "email": lambda v: v,
        "url": lambda v: v,
        "phone_number": lambda v: v,
        "status": lambda v: v["name"] if v else None,
        "relation": lambda v: [i["id"] for i in v],
        "people": lambda v: [i["id"] for i in v],
        "files": lambda v: [
            f.get("external", {}).get("url") or f.get("file", {}).get("url") for f in v
        ],
        "formula": _extract_formula,
        "rollup": _extract_rollup,
        "unique_id": _extract_unique_id,
        "created_time": lambda v: v,
        "last_edited_time": lambda v: v,
    }

    notion_to_key = {f.notion_name: key for key, f in schema.fields.items()}
    result = {}

    for notion_name, prop in properties.items():
        key = notion_to_key.get(notion_name)
        if key is None:
            continue
        for prop_key, extract in extractors.items():
            if prop_key in prop:
                result[key] = extract(prop[prop_key])
                break

    return result
