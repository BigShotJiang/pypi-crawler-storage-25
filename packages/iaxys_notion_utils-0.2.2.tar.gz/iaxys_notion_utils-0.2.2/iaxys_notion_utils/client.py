from __future__ import annotations

from enum import Enum
from typing import Any

import httpx

BASE_URL = "https://api.notion.com/v1"


class NotionVersion(str, Enum):
    V2022_06_28 = "2022-06-28"
    V2025_09_03 = "2025-09-03"
    V2026_03_11 = "2026-03-11"


class NotionClient:
    """Cliente Notion com suporte sync e async via httpx."""

    def __init__(self, token: str, version: NotionVersion = NotionVersion.V2026_03_11) -> None:
        self._headers = {
            "Authorization": f"Bearer {token}",
            "Notion-Version": version.value,
            "Content-Type": "application/json",
        }

    def _url(self, path: str) -> str:
        return f"{BASE_URL}/{path.lstrip('/')}"

    # ── Sync base ─────────────────────────────────────────────────

    def get(self, path: str, **kwargs: Any) -> dict:
        resp = httpx.get(self._url(path), headers=self._headers, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def post(self, path: str, body: dict | None = None, **kwargs: Any) -> dict:
        resp = httpx.post(self._url(path), headers=self._headers, json=body, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def patch(self, path: str, body: dict | None = None, **kwargs: Any) -> dict:
        resp = httpx.patch(self._url(path), headers=self._headers, json=body, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def delete(self, path: str, **kwargs: Any) -> dict:
        resp = httpx.delete(self._url(path), headers=self._headers, **kwargs)
        resp.raise_for_status()
        return resp.json()

    # ── Async base ────────────────────────────────────────────────

    async def aget(self, path: str, **kwargs: Any) -> dict:
        async with httpx.AsyncClient(headers=self._headers) as c:
            resp = await c.get(self._url(path), **kwargs)
        resp.raise_for_status()
        return resp.json()

    async def apost(self, path: str, body: dict | None = None, **kwargs: Any) -> dict:
        async with httpx.AsyncClient(headers=self._headers) as c:
            resp = await c.post(self._url(path), json=body, **kwargs)
        resp.raise_for_status()
        return resp.json()

    async def apatch(self, path: str, body: dict | None = None, **kwargs: Any) -> dict:
        async with httpx.AsyncClient(headers=self._headers) as c:
            resp = await c.patch(self._url(path), json=body, **kwargs)
        resp.raise_for_status()
        return resp.json()

    async def adelete(self, path: str, **kwargs: Any) -> dict:
        async with httpx.AsyncClient(headers=self._headers) as c:
            resp = await c.delete(self._url(path), **kwargs)
        resp.raise_for_status()
        return resp.json()

    # ── Pagination helper ─────────────────────────────────────────

    def _paginate(
        self, method: str, path: str, body: dict | None = None, **kwargs: Any
    ) -> list[dict]:
        """Coleta todos os resultados paginados de um endpoint."""
        results: list[dict] = []
        start_cursor: str | None = None
        sender = {"get": self.get, "post": self.post, "patch": self.patch}
        while True:
            payload = {**(body or {})}
            if start_cursor:
                payload["start_cursor"] = start_cursor
            if method == "get":
                params = kwargs.pop("params", {})
                if start_cursor:
                    params["start_cursor"] = start_cursor
                data = self.get(path, params=params, **kwargs)
            else:
                data = sender[method](path, body=payload, **kwargs)
            results.extend(data.get("results", []))
            if not data.get("has_more"):
                break
            start_cursor = data.get("next_cursor")
        return results

    # ── Pages ─────────────────────────────────────────────────────

    def create_page(
        self,
        parent: dict,
        properties: dict,
        children: list[dict] | None = None,
        **kwargs: Any,
    ) -> dict:
        body: dict = {"parent": parent, "properties": properties}
        if children:
            body["children"] = children
        body.update(kwargs)
        return self.post("pages", body=body)

    def retrieve_page(self, page_id: str) -> dict:
        return self.get(f"pages/{page_id}")

    def update_page(self, page_id: str, **kwargs: Any) -> dict:
        return self.patch(f"pages/{page_id}", body=kwargs)

    def archive_page(self, page_id: str) -> dict:
        return self.patch(f"pages/{page_id}", body={"in_trash": True})

    def retrieve_page_property(self, page_id: str, property_id: str) -> dict:
        return self.get(f"pages/{page_id}/properties/{property_id}")

    # ── Databases ─────────────────────────────────────────────────

    def create_database(
        self,
        parent: dict,
        title: list[dict],
        initial_data_source: dict,
        **kwargs: Any,
    ) -> dict:
        body: dict = {
            "parent": parent,
            "title": title,
            "initial_data_source": initial_data_source,
        }
        body.update(kwargs)
        return self.post("databases", body=body)

    def retrieve_database(self, database_id: str) -> dict:
        return self.get(f"databases/{database_id}")

    def update_database(self, database_id: str, **kwargs: Any) -> dict:
        return self.patch(f"databases/{database_id}", body=kwargs)

    # ── Data Sources ──────────────────────────────────────────────

    def retrieve_data_source(self, data_source_id: str) -> dict:
        return self.get(f"data_sources/{data_source_id}")

    def create_data_source(
        self, database_id: str, properties: dict, **kwargs: Any
    ) -> dict:
        body: dict = {"database_id": database_id, "properties": properties}
        body.update(kwargs)
        return self.post("data_sources", body=body)

    def update_data_source(self, data_source_id: str, **kwargs: Any) -> dict:
        return self.patch(f"data_sources/{data_source_id}", body=kwargs)

    def query_data_source(
        self,
        data_source_id: str,
        filter: dict | None = None,
        sorts: list[dict] | None = None,
        **kwargs: Any,
    ) -> list[dict]:
        body: dict = {**kwargs}
        if filter:
            body["filter"] = filter
        if sorts:
            body["sorts"] = sorts
        return self._paginate(
            "patch", f"data_sources/{data_source_id}/query", body=body
        )

    # ── Blocks ────────────────────────────────────────────────────

    def retrieve_block(self, block_id: str) -> dict:
        return self.get(f"blocks/{block_id}")

    def update_block(self, block_id: str, **kwargs: Any) -> dict:
        return self.patch(f"blocks/{block_id}", body=kwargs)

    def delete_block(self, block_id: str) -> dict:
        return self.delete(f"blocks/{block_id}")

    def retrieve_block_children(self, block_id: str) -> list[dict]:
        return self._paginate("get", f"blocks/{block_id}/children")

    def append_block_children(self, block_id: str, children: list[dict]) -> dict:
        return self.patch(f"blocks/{block_id}/children", body={"children": children})

    # ── Users ─────────────────────────────────────────────────────

    def list_users(self) -> list[dict]:
        return self._paginate("get", "users")

    def retrieve_user(self, user_id: str) -> dict:
        return self.get(f"users/{user_id}")

    def retrieve_me(self) -> dict:
        return self.get("users/me")

    # ── Comments ──────────────────────────────────────────────────

    def list_comments(self, block_id: str) -> list[dict]:
        return self._paginate("get", "comments", params={"block_id": block_id})

    def retrieve_comment(self, comment_id: str) -> dict:
        return self.get(f"comments/{comment_id}")

    def create_comment(
        self, parent: dict, rich_text: list[dict], **kwargs: Any
    ) -> dict:
        body: dict = {"parent": parent, "rich_text": rich_text}
        body.update(kwargs)
        return self.post("comments", body=body)

    # ── Search ────────────────────────────────────────────────────

    def search(
        self,
        query: str = "",
        filter: dict | None = None,
        sort: dict | None = None,
        **kwargs: Any,
    ) -> list[dict]:
        body: dict = {**kwargs}
        if query:
            body["query"] = query
        if filter:
            body["filter"] = filter
        if sort:
            body["sort"] = sort
        return self._paginate("post", "search", body=body)

    # ── Async high-level ──────────────────────────────────────────

    async def _apaginate(
        self, method: str, path: str, body: dict | None = None, **kwargs: Any
    ) -> list[dict]:
        results: list[dict] = []
        start_cursor: str | None = None
        sender = {"get": self.aget, "post": self.apost, "patch": self.apatch}
        while True:
            payload = {**(body or {})}
            if start_cursor:
                payload["start_cursor"] = start_cursor
            if method == "get":
                params = kwargs.pop("params", {})
                if start_cursor:
                    params["start_cursor"] = start_cursor
                data = await self.aget(path, params=params, **kwargs)
            else:
                data = await sender[method](path, body=payload, **kwargs)
            results.extend(data.get("results", []))
            if not data.get("has_more"):
                break
            start_cursor = data.get("next_cursor")
        return results

    async def acreate_page(
        self,
        parent: dict,
        properties: dict,
        children: list[dict] | None = None,
        **kwargs: Any,
    ) -> dict:
        body: dict = {"parent": parent, "properties": properties}
        if children:
            body["children"] = children
        body.update(kwargs)
        return await self.apost("pages", body=body)

    async def aretrieve_page(self, page_id: str) -> dict:
        return await self.aget(f"pages/{page_id}")

    async def aupdate_page(self, page_id: str, **kwargs: Any) -> dict:
        return await self.apatch(f"pages/{page_id}", body=kwargs)

    async def aarchive_page(self, page_id: str) -> dict:
        return await self.apatch(f"pages/{page_id}", body={"in_trash": True})

    async def aretrieve_page_property(self, page_id: str, property_id: str) -> dict:
        return await self.aget(f"pages/{page_id}/properties/{property_id}")

    async def acreate_database(
        self,
        parent: dict,
        title: list[dict],
        initial_data_source: dict,
        **kwargs: Any,
    ) -> dict:
        body: dict = {
            "parent": parent,
            "title": title,
            "initial_data_source": initial_data_source,
        }
        body.update(kwargs)
        return await self.apost("databases", body=body)

    async def aretrieve_database(self, database_id: str) -> dict:
        return await self.aget(f"databases/{database_id}")

    async def aupdate_database(self, database_id: str, **kwargs: Any) -> dict:
        return await self.apatch(f"databases/{database_id}", body=kwargs)

    async def aretrieve_data_source(self, data_source_id: str) -> dict:
        return await self.aget(f"data_sources/{data_source_id}")

    async def acreate_data_source(
        self, database_id: str, properties: dict, **kwargs: Any
    ) -> dict:
        body: dict = {"database_id": database_id, "properties": properties}
        body.update(kwargs)
        return await self.apost("data_sources", body=body)

    async def aupdate_data_source(self, data_source_id: str, **kwargs: Any) -> dict:
        return await self.apatch(f"data_sources/{data_source_id}", body=kwargs)

    async def aquery_data_source(
        self,
        data_source_id: str,
        filter: dict | None = None,
        sorts: list[dict] | None = None,
        **kwargs: Any,
    ) -> list[dict]:
        body: dict = {**kwargs}
        if filter:
            body["filter"] = filter
        if sorts:
            body["sorts"] = sorts
        return await self._apaginate(
            "patch", f"data_sources/{data_source_id}/query", body=body
        )

    async def aretrieve_block(self, block_id: str) -> dict:
        return await self.aget(f"blocks/{block_id}")

    async def aupdate_block(self, block_id: str, **kwargs: Any) -> dict:
        return await self.apatch(f"blocks/{block_id}", body=kwargs)

    async def adelete_block(self, block_id: str) -> dict:
        return await self.adelete(f"blocks/{block_id}")

    async def aretrieve_block_children(self, block_id: str) -> list[dict]:
        return await self._apaginate("get", f"blocks/{block_id}/children")

    async def aappend_block_children(self, block_id: str, children: list[dict]) -> dict:
        return await self.apatch(
            f"blocks/{block_id}/children", body={"children": children}
        )

    async def alist_users(self) -> list[dict]:
        return await self._apaginate("get", "users")

    async def aretrieve_user(self, user_id: str) -> dict:
        return await self.aget(f"users/{user_id}")

    async def aretrieve_me(self) -> dict:
        return await self.aget("users/me")

    async def alist_comments(self, block_id: str) -> list[dict]:
        return await self._apaginate("get", "comments", params={"block_id": block_id})

    async def aretrieve_comment(self, comment_id: str) -> dict:
        return await self.aget(f"comments/{comment_id}")

    async def acreate_comment(
        self, parent: dict, rich_text: list[dict], **kwargs: Any
    ) -> dict:
        body: dict = {"parent": parent, "rich_text": rich_text}
        body.update(kwargs)
        return await self.apost("comments", body=body)

    async def asearch(
        self,
        query: str = "",
        filter: dict | None = None,
        sort: dict | None = None,
        **kwargs: Any,
    ) -> list[dict]:
        body: dict = {**kwargs}
        if query:
            body["query"] = query
        if filter:
            body["filter"] = filter
        if sort:
            body["sort"] = sort
        return await self._apaginate("post", "search", body=body)
