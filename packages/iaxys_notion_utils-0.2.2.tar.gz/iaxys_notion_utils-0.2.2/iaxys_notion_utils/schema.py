from dataclasses import dataclass, field
from typing import Any

from .types import NotionProperty


@dataclass
class Field:
    """Maps a source key to a Notion property name and type."""
    notion_name: str
    property_type: type[NotionProperty]
    source_key: str | None = None  # defaults to the schema dict key


@dataclass
class Schema:
    """Declarative mapping from source data to Notion properties."""
    fields: dict[str, Field]

    def resolve(self, data: dict[str, Any]) -> dict[str, NotionProperty]:
        result = {}
        for key, f in self.fields.items():
            source = f.source_key or key
            if source not in data:
                continue
            raw = data[source]
            prop = _build_property(f.property_type, raw)
            result[f.notion_name] = prop
        return result


def _build_property(prop_type: type[NotionProperty], raw: Any) -> NotionProperty:
    """Instantiate a NotionProperty from a raw value, handling multi-field types."""
    if prop_type.__dataclass_fields__.keys() == {"value"}:
        return prop_type(value=raw)
    if prop_type.__dataclass_fields__.keys() == {"ids"}:
        return prop_type(ids=raw if isinstance(raw, list) else [raw])
    if prop_type.__dataclass_fields__.keys() == {"urls"}:
        return prop_type(urls=raw if isinstance(raw, list) else [raw])
    if "start" in prop_type.__dataclass_fields__:
        if isinstance(raw, dict):
            return prop_type(**raw)
        return prop_type(start=raw)
    return prop_type(**raw) if isinstance(raw, dict) else prop_type(value=raw)
