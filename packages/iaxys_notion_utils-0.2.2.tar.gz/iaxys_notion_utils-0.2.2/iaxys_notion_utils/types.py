from dataclasses import dataclass
from datetime import date, datetime
from typing import Any


@dataclass
class NotionProperty:
    def to_dict(self) -> dict:
        raise NotImplementedError


@dataclass
class Title(NotionProperty):
    value: str

    def to_dict(self):
        return {"title": [{"text": {"content": self.value}}]}


@dataclass
class RichText(NotionProperty):
    value: str

    def to_dict(self):
        return {"rich_text": [{"text": {"content": self.value}}]}


@dataclass
class Number(NotionProperty):
    value: int | float

    def to_dict(self):
        return {"number": self.value}


@dataclass
class Select(NotionProperty):
    value: str

    def to_dict(self):
        return {"select": {"name": self.value}}


@dataclass
class MultiSelect(NotionProperty):
    value: list[str]

    def to_dict(self):
        return {"multi_select": [{"name": v} for v in self.value]}


@dataclass
class Date(NotionProperty):
    start: date | datetime
    end: date | datetime | None = None

    def to_dict(self):
        fmt = lambda d: d.isoformat() if hasattr(d, "isoformat") else str(d)
        payload: dict[str, Any] = {"start": fmt(self.start)}
        if self.end:
            payload["end"] = fmt(self.end)
        return {"date": payload}


@dataclass
class Checkbox(NotionProperty):
    value: bool

    def to_dict(self):
        return {"checkbox": self.value}


@dataclass
class Email(NotionProperty):
    value: str

    def to_dict(self):
        return {"email": self.value}


@dataclass
class Url(NotionProperty):
    value: str

    def to_dict(self):
        return {"url": self.value}


@dataclass
class PhoneNumber(NotionProperty):
    value: str

    def to_dict(self):
        return {"phone_number": self.value}


@dataclass
class Relation(NotionProperty):
    ids: list[str]

    def to_dict(self):
        return {"relation": [{"id": id} for id in self.ids]}


@dataclass
class People(NotionProperty):
    ids: list[str]

    def to_dict(self):
        return {"people": [{"object": "user", "id": id} for id in self.ids]}


@dataclass
class Files(NotionProperty):
    urls: list[str]

    def to_dict(self):
        return {
            "files": [
                {"name": url, "type": "external", "external": {"url": url}}
                for url in self.urls
            ]
        }


@dataclass
class Status(NotionProperty):
    value: str

    def to_dict(self):
        return {"status": {"name": self.value}}


# ── Read-only types (sem to_dict, apenas extração) ──


@dataclass
class Formula(NotionProperty):
    value: Any = None

    def to_dict(self):
        raise NotImplementedError("Formula is read-only")


@dataclass
class Rollup(NotionProperty):
    value: Any = None

    def to_dict(self):
        raise NotImplementedError("Rollup is read-only")


@dataclass
class UniqueId(NotionProperty):
    value: str = ""

    def to_dict(self):
        raise NotImplementedError("UniqueId is read-only")


@dataclass
class CreatedTime(NotionProperty):
    value: str = ""

    def to_dict(self):
        raise NotImplementedError("CreatedTime is read-only")


@dataclass
class LastEditedTime(NotionProperty):
    value: str = ""

    def to_dict(self):
        raise NotImplementedError("LastEditedTime is read-only")
