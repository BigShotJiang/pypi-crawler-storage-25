import unittest
from datetime import date, datetime

from iaxys_notion_utils import (
    Schema, Field, to_notion_properties,
    Title, RichText, Number, Select, MultiSelect, Date,
    Checkbox, Email, Url, PhoneNumber, Status, Relation, People, Files,
)


class TestTypes(unittest.TestCase):
    def test_title(self):
        self.assertEqual(Title("Hello").to_dict(), {"title": [{"text": {"content": "Hello"}}]})

    def test_rich_text(self):
        self.assertEqual(RichText("text").to_dict(), {"rich_text": [{"text": {"content": "text"}}]})

    def test_number(self):
        self.assertEqual(Number(42).to_dict(), {"number": 42})
        self.assertEqual(Number(3.14).to_dict(), {"number": 3.14})

    def test_select(self):
        self.assertEqual(Select("Active").to_dict(), {"select": {"name": "Active"}})

    def test_multi_select(self):
        self.assertEqual(MultiSelect(["A", "B"]).to_dict(), {"multi_select": [{"name": "A"}, {"name": "B"}]})

    def test_date_string(self):
        self.assertEqual(Date(start="2026-03-25").to_dict(), {"date": {"start": "2026-03-25"}})

    def test_date_with_end(self):
        result = Date(start=date(2026, 1, 1), end=date(2026, 12, 31)).to_dict()
        self.assertEqual(result, {"date": {"start": "2026-01-01", "end": "2026-12-31"}})

    def test_date_datetime(self):
        dt = datetime(2026, 3, 25, 15, 30)
        self.assertEqual(Date(start=dt).to_dict(), {"date": {"start": dt.isoformat()}})

    def test_checkbox(self):
        self.assertEqual(Checkbox(True).to_dict(), {"checkbox": True})
        self.assertEqual(Checkbox(False).to_dict(), {"checkbox": False})

    def test_email(self):
        self.assertEqual(Email("a@b.com").to_dict(), {"email": "a@b.com"})

    def test_url(self):
        self.assertEqual(Url("https://example.com").to_dict(), {"url": "https://example.com"})

    def test_phone_number(self):
        self.assertEqual(PhoneNumber("+5511999999999").to_dict(), {"phone_number": "+5511999999999"})

    def test_status(self):
        self.assertEqual(Status("Done").to_dict(), {"status": {"name": "Done"}})

    def test_relation(self):
        self.assertEqual(Relation(["id1", "id2"]).to_dict(), {"relation": [{"id": "id1"}, {"id": "id2"}]})

    def test_people(self):
        self.assertEqual(People(["u1"]).to_dict(), {"people": [{"object": "user", "id": "u1"}]})

    def test_files(self):
        result = Files(["https://img.png"]).to_dict()
        self.assertEqual(result, {"files": [{"name": "https://img.png", "type": "external", "external": {"url": "https://img.png"}}]})


class TestConverter(unittest.TestCase):
    def test_full_schema(self):
        schema = Schema(fields={
            "name":   Field("Name", Title),
            "email":  Field("Email", Email),
            "age":    Field("Age", Number),
            "status": Field("Status", Select),
            "date":   Field("Created At", Date),
        })
        data = {
            "name": "Lucas",
            "email": "lucas@example.com",
            "age": 25,
            "status": "Active",
            "date": "2026-03-25",
        }
        result = to_notion_properties(data, schema)
        self.assertEqual(result, {
            "Name": {"title": [{"text": {"content": "Lucas"}}]},
            "Email": {"email": "lucas@example.com"},
            "Age": {"number": 25},
            "Status": {"select": {"name": "Active"}},
            "Created At": {"date": {"start": "2026-03-25"}},
        })

    def test_source_key(self):
        schema = Schema(fields={
            "nome": Field("Name", Title, source_key="nome_completo"),
        })
        result = to_notion_properties({"nome_completo": "Lucas"}, schema)
        self.assertEqual(result, {"Name": {"title": [{"text": {"content": "Lucas"}}]}})

    def test_missing_key_is_skipped(self):
        schema = Schema(fields={
            "name": Field("Name", Title),
            "age":  Field("Age", Number),
        })
        result = to_notion_properties({"name": "Lucas"}, schema)
        self.assertEqual(result, {"Name": {"title": [{"text": {"content": "Lucas"}}]}})

    def test_date_dict_input(self):
        schema = Schema(fields={"d": Field("Date", Date)})
        result = to_notion_properties({"d": {"start": "2026-01-01", "end": "2026-12-31"}}, schema)
        self.assertEqual(result, {"Date": {"date": {"start": "2026-01-01", "end": "2026-12-31"}}})

    def test_relation_from_list(self):
        schema = Schema(fields={"r": Field("Rel", Relation)})
        result = to_notion_properties({"r": ["id1", "id2"]}, schema)
        self.assertEqual(result, {"Rel": {"relation": [{"id": "id1"}, {"id": "id2"}]}})

    def test_multi_select(self):
        schema = Schema(fields={"tags": Field("Tags", MultiSelect)})
        result = to_notion_properties({"tags": ["A", "B"]}, schema)
        self.assertEqual(result, {"Tags": {"multi_select": [{"name": "A"}, {"name": "B"}]}})


if __name__ == "__main__":
    unittest.main()
