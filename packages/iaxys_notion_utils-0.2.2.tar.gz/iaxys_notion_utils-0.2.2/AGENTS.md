# AGENTS.md — iaxys-notion-utils

## Identidade

Pacote Python que abstrai a API do Notion. Oferece mapeamento declarativo de schemas, conversão bidirecional de propriedades e um client HTTP (sync + async) com paginação automática.

## Stack

- Python ≥ 3.7
- httpx (HTTP client)
- Hatchling (build)

## Estrutura

```
iaxys_notion_utils/
├── __init__.py        # re-exports públicos
├── types.py           # dataclasses NotionProperty (Title, RichText, Number, Select, Date, etc.)
├── schema.py          # Schema + Field — mapeamento declarativo source → Notion
├── converter.py       # to_notion_properties(data, schema) → dict JSON Notion
├── parser.py          # from_notion_properties(properties, schema) → dict Python
└── client.py          # NotionClient — sync/async com paginação automática
```

## Conceitos-chave

### Schema declarativo

`Schema` contém um dict de `Field`, cada um mapeia uma chave do dict de origem para um nome de propriedade Notion e um tipo (`Title`, `RichText`, `Number`, `Select`, `Date`, etc.). `source_key` opcional permite chave de origem diferente da chave do schema.

### Tipos de propriedade

Cada tipo é um dataclass que implementa `to_dict()` retornando o JSON esperado pela API Notion. Tipos read-only (`Formula`, `Rollup`, `UniqueId`, `CreatedTime`, `LastEditedTime`) levantam `NotImplementedError` no `to_dict()`.

### Conversão bidirecional

- `to_notion_properties(data, schema)` — dict Python → JSON Notion
- `from_notion_properties(properties, schema)` — JSON Notion → dict Python

### NotionClient

Client HTTP com métodos sync (`get`, `post`, `patch`, `delete`) e async (`aget`, `apost`, `apatch`, `adelete`). Paginação automática via `_paginate` / `_apaginate`. Cobre: Pages, Databases, Data Sources, Blocks, Users, Comments, Search.

A partir da versão `2025-09-03`, databases viram containers e as operações de schema/query migraram para `/v1/data_sources`. O client reflete isso:
- `retrieve_database` retorna o container (com lista de `data_sources`)
- `create_database` usa `initial_data_source` para properties
- `query_data_source` substitui `query_database` (`PATCH /v1/data_sources/:id/query`)
- `retrieve_data_source`, `create_data_source`, `update_data_source` para gerenciar data sources
- `create_page` aceita `data_source_id` como parent

## Convenções

- Métodos async prefixados com `a` (ex: `acreate_page`, `aquery_database`)
- Tipos são dataclasses simples, sem Pydantic
- Sem retry/backoff — o client é fino, erros propagam via `httpx`
- Notion API version hardcoded: `2026-03-11`
