# PyRapide: Agent Integration Blueprint

## Causal Traceability for Agentic AI Systems

> *When your agent calls three MCP servers and produces an answer, how do you know which tool call actually contributed to the result? Flat logs cannot answer this. PyRapide can.*

---

## Table of Contents

1. [Why Causal Traceability for Agents?](#1-why-causal-traceability-for-agents)
2. [Quick Setup](#2-quick-setup)
3. [MCP Server Integration](#3-mcp-server-integration)
4. [LLM API Integration](#4-llm-api-integration)
5. [Full Agent Loop: LLM + MCP Together](#5-full-agent-loop-llm--mcp-together)
6. [Multi-Agent Systems](#6-multi-agent-systems)
7. [Real-Time Monitoring with StreamProcessor](#7-real-time-monitoring-with-streamprocessor)
8. [Constraints: Enforcing Agent Behavioral Rules](#8-constraints-enforcing-agent-behavioral-rules)
9. [Debugging and Root Cause Analysis](#9-debugging-and-root-cause-analysis)
10. [Anomaly Detection and Prediction](#10-anomaly-detection-and-prediction)
11. [Visualization](#11-visualization)
12. [Patterns Reference for Agent Systems](#12-patterns-reference-for-agent-systems)
13. [Cookbook: Common Agent Patterns](#13-cookbook-common-agent-patterns)
14. [API Quick Reference](#14-api-quick-reference)

---

## 1. Why Causal Traceability for Agents?

### 1.1 The Problem: Opaque Agent Behavior

Agentic AI systems -- particularly those built on the Model Context Protocol (MCP) -- generate an explosion of asynchronous, distributed events. An agent might call a database server, a file system server, and a web search server simultaneously. When something goes wrong (or right), you need to answer questions like:

- **Which tool call produced the data the LLM used in its final response?**
- **Why did the agent retry that operation three times?**
- **When server A errored, which downstream results were affected?**
- **Are there two agents working on the same data without knowing about each other?**

Traditional logging gives you a flat timeline: event A happened, then B, then C. But in concurrent systems, "A happened before B" does not mean "A caused B." Two independent agents can produce interleaved log entries with no causal relationship at all.

### 1.2 What PyRapide Adds

PyRapide tracks the **causal DAG** (directed acyclic graph) of events, not just a timeline. Every event records *what caused it*, forming a partially ordered set (poset) where:

- Events that are causally related have a defined order
- Events that are independent remain unordered (concurrent)
- The full causal history of any event can be queried at any time

This means you can ask "show me everything that led to this error" and get a precise causal chain, not a haystack of timestamped log entries.

### 1.3 Key Concepts in 60 Seconds

| Concept | What It Is | Why Agents Need It |
|---------|-----------|-------------------|
| **Event** | An immutable occurrence with a name, payload, source, and unique ID | Every tool call, result, LLM request, and response becomes an Event |
| **Poset** | A DAG of events ordered by causality | The structure that tracks "A caused B" relationships |
| **Computation** | A queryable wrapper around a Poset | Your entry point for analysis -- query events, trace chains, find roots |
| **Pattern** | A composable expression for matching events | Detect "tool_call followed by tool_result" or "error with no preceding call" |
| **Constraint** | A rule about what patterns must (or must not) exist | Enforce "every tool call must get a result" in real time |
| **StreamProcessor** | A real-time engine that processes events from multiple sources | Monitor multiple MCP servers concurrently with live constraint checking |

---

## 2. Quick Setup

### 2.1 Installation

```bash
pip install pyrapide
```

For MCP integration (optional):

```bash
pip install pyrapide[mcp]
```

For anomaly detection and prediction (optional):

```bash
pip install pyrapide[ml]
```

### 2.2 Minimal Example

```python
import asyncio
from pyrapide import Event, Computation, queries

# Create events
request = Event(name="llm.request", payload={"prompt": "What is 2+2?"}, source="agent")
tool_call = Event(name="mcp.tool_call", payload={"tool": "calculator"}, source="math-server")
tool_result = Event(name="mcp.tool_result", payload={"result": 4}, source="math-server")
response = Event(name="llm.response", payload={"text": "The answer is 4."}, source="agent")

# Build the causal chain
comp = Computation()
comp.record(request)
comp.record(tool_call, caused_by=[request])
comp.record(tool_result, caused_by=[tool_call])
comp.record(response, caused_by=[tool_result])

# Query it
chain = comp.causal_chain(request, response)
print(f"Causal chain length: {len(chain)}")  # 4

roots = queries.root_causes(comp, response)
print(f"Root cause of response: {[e.name for e in roots]}")  # ['llm.request']

print(f"Are request and response independent? {comp.are_independent(request, response)}")  # False
```

---

## 3. MCP Server Integration

PyRapide ships with first-class support for MCP servers through the `MCPEventAdapter`, which translates MCP protocol events into causally-linked PyRapide events.

### 3.1 Connecting to a Single MCP Server

```python
import asyncio
from pyrapide import MCPEventAdapter, MCPEventTypes, StreamProcessor
from pyrapide.integrations.mcp import MockMCPClient

async def monitor_single_server():
    # Create client and adapter
    client = MockMCPClient("database-server")
    adapter = MCPEventAdapter("database-server", client)

    # Simulate MCP activity
    async def simulate():
        await client.connect()
        await client.call_tool("query_users", {"limit": 10})
        await client.call_tool("insert_record", {"table": "logs", "data": {"msg": "hello"}})
        await client.disconnect()
        await client.close()

    # Process events
    processor = StreamProcessor()
    processor.add_source("db", adapter)

    processor.on_event(lambda e: print(f"[{e.source}] {e.name}: {e.payload}"))

    await asyncio.gather(processor.run(), simulate())
    print(processor.stats)

asyncio.run(monitor_single_server())
```

The adapter translates raw MCP protocol events into PyRapide `Event` objects with these names:

| MCP Operation | PyRapide Event Name | Constant |
|--------------|-------------------|----------|
| Server connect | `mcp.connect` | `MCPEventTypes.CONNECT` |
| Tool invocation | `mcp.tool_call` | `MCPEventTypes.TOOL_CALL` |
| Tool result | `mcp.tool_result` | `MCPEventTypes.TOOL_RESULT` |
| Tool error | `mcp.error` | `MCPEventTypes.ERROR` |
| Resource read | `mcp.resource_read` | `MCPEventTypes.RESOURCE_READ` |
| Server disconnect | `mcp.disconnect` | `MCPEventTypes.DISCONNECT` |

### 3.2 Automatic Causal Linking

The `MCPEventAdapter` automatically tracks the causal relationship between tool calls and their results using a `correlation_id` mechanism. When a tool is called, the adapter stores the call event. When the result arrives with the same `correlation_id`, the result event's metadata includes a `caused_by_id` pointing back to the original call.

```python
# After processing events through the adapter:
for event in processor.computation.events:
    if event.name == MCPEventTypes.TOOL_RESULT:
        call_id = event.metadata.get("caused_by_id", "")
        correlation = event.metadata.get("correlation_id", "")
        print(f"Result for tool '{event.payload['tool']}' was caused by event {call_id}")
```

This means that when you query the causal structure later, you can trace from any tool result back to the exact call that triggered it, even across dozens of concurrent operations.

### 3.3 Pre-Built MCP Patterns

The `MCPPatterns` class provides ready-made patterns for common MCP event matching scenarios:

```python
from pyrapide import MCPPatterns

# Match any tool call
MCPPatterns.tool_call()

# Match a specific tool call
MCPPatterns.tool_call("query_users")

# Match any tool result
MCPPatterns.tool_result()

# Match a complete tool roundtrip (call >> result)
MCPPatterns.tool_roundtrip()

# Match a specific tool's roundtrip
MCPPatterns.tool_roundtrip("query_users")

# Match tool errors
MCPPatterns.tool_error()

# Match server lifecycle (connect >> disconnect)
MCPPatterns.server_lifecycle()
```

Each returns a `Pattern` object that can be composed with other patterns using operators (see [Section 12](#12-patterns-reference-for-agent-systems)).

### 3.4 Multiple MCP Servers

Real agentic systems use multiple MCP servers simultaneously. The `StreamProcessor` handles this natively:

```python
import asyncio
from pyrapide import MCPEventAdapter, MCPPatterns, StreamProcessor, never
from pyrapide.integrations.mcp import MockMCPClient

async def monitor_multi_server():
    # Set up multiple MCP server adapters
    db_client = MockMCPClient("database-server")
    db_adapter = MCPEventAdapter("database-server", db_client)

    ai_client = MockMCPClient("ai-server")
    ai_adapter = MCPEventAdapter("ai-server", ai_client)

    fs_client = MockMCPClient("filesystem-server")
    fs_adapter = MCPEventAdapter("filesystem-server", fs_client)

    # Create processor with all sources
    processor = StreamProcessor()
    processor.add_source("db", db_adapter)
    processor.add_source("ai", ai_adapter)
    processor.add_source("fs", fs_adapter)

    # Forbid tool errors from any server
    processor.enforce(never(MCPPatterns.tool_error(), name="no_errors"))

    # Watch for completed roundtrips
    processor.watch(
        MCPPatterns.tool_roundtrip(),
        lambda m: print(f"Tool roundtrip completed: {m.events[0].payload.get('tool')}")
    )

    # Simulate concurrent activity
    async def simulate():
        await db_client.connect()
        await ai_client.connect()
        await fs_client.connect()

        await asyncio.gather(
            db_client.call_tool("query", {"sql": "SELECT * FROM users"}),
            ai_client.call_tool("embed", {"text": "hello world"}),
            fs_client.call_tool("read_file", {"path": "/data/config.json"}),
        )

        await db_client.disconnect()
        await ai_client.disconnect()
        await fs_client.disconnect()

        await db_client.close()
        await ai_client.close()
        await fs_client.close()

    await asyncio.gather(processor.run(), simulate())

    # Stats break down by source
    print(processor.stats)
    # {
    #   "event_count": 12,
    #   "source_counts": {"db": 4, "ai": 4, "fs": 4},
    #   "violation_count": 0,
    #   "match_count": 3
    # }

asyncio.run(monitor_multi_server())
```

### 3.5 Error Handling

Detect and respond to MCP tool errors in real time:

```python
from pyrapide import MCPPatterns, StreamProcessor, never

processor = StreamProcessor()
# ... add sources ...

# Option 1: Forbid all errors (constraint violation on any error)
processor.enforce(never(MCPPatterns.tool_error(), name="no_tool_errors"))

# Option 2: Forbid errors from a specific tool
processor.enforce(never(
    MCPPatterns.tool_error("critical_operation"),
    name="critical_op_must_not_fail"
))

# React to violations
processor.on_violation(lambda v: print(f"ALERT: {v.description}"))
```

Error events automatically include `caused_by_id` linking them to the failed tool call, so you can trace the causal chain backward from any error to find the original request.

### 3.6 Server Lifecycle Tracking

Monitor when MCP servers connect and disconnect:

```python
from pyrapide import MCPPatterns, StreamProcessor

processor = StreamProcessor()
# ... add sources ...

# Watch for complete server lifecycles
processor.watch(
    MCPPatterns.server_lifecycle(),
    lambda m: print(f"Server completed lifecycle: {m.events[0].payload.get('server')}")
)
```

### 3.7 Adapting Real MCP Clients

The `MCPEventAdapter` works with `MockMCPClient` for testing. To integrate a real MCP SDK client, you need to implement the `EventSource` protocol:

```python
from typing import AsyncIterator
from pyrapide import Event
from pyrapide.runtime.streaming import EventSource

class RealMCPAdapter:
    """Wraps a real MCP SDK client as a PyRapide EventSource."""

    def __init__(self, server_name: str, mcp_session):
        self._server_name = server_name
        self._session = mcp_session
        self._pending_calls = {}  # correlation_id -> Event

    @property
    def name(self) -> str:
        return self._server_name

    async def events(self) -> AsyncIterator[Event]:
        """Translate real MCP protocol messages into PyRapide Events."""
        async for message in self._session.incoming_messages():
            event = self._translate(message)
            if event is not None:
                yield event

    def _translate(self, message) -> Event | None:
        # Map your MCP SDK's message types to PyRapide events
        # The key fields to include:
        #   - name: one of "mcp.tool_call", "mcp.tool_result", etc.
        #   - payload: {"tool": ..., "args": ..., "result": ..., etc.}
        #   - source: self._server_name
        #   - metadata: {"correlation_id": ..., "caused_by_id": ...}
        ...
```

The `EventSource` protocol requires only two things:
1. A `name` property returning a string
2. An `events()` method returning an `AsyncIterator[Event]`

Any object satisfying this protocol can be passed to `processor.add_source()`.

---

## 4. LLM API Integration

PyRapide includes an `LLMEventAdapter` for tracking LLM API interactions with the same causal linking semantics as MCP.

### 4.1 Request/Response Tracking

```python
import asyncio
from pyrapide import LLMEventAdapter, LLMEventTypes, StreamProcessor
from pyrapide.integrations.llm import MockLLMClient

async def track_llm():
    client = MockLLMClient("claude-3")
    adapter = LLMEventAdapter("llm", client)

    processor = StreamProcessor()
    processor.add_source("llm", adapter)

    processor.on_event(lambda e: print(f"  [{e.name}] {e.payload}"))

    async def simulate():
        await client.request("What is the capital of France?")
        await client.close()

    await asyncio.gather(processor.run(), simulate())

asyncio.run(track_llm())
```

**LLM Event Types:**

| LLM Operation | PyRapide Event Name | Constant |
|--------------|-------------------|----------|
| API request sent | `llm.request` | `LLMEventTypes.REQUEST` |
| API response received | `llm.response` | `LLMEventTypes.RESPONSE` |
| Streaming chunk | `llm.stream_chunk` | `LLMEventTypes.STREAM_CHUNK` |
| API error | `llm.error` | `LLMEventTypes.ERROR` |

### 4.2 Streaming Response Tracking

When using streaming, each chunk is a separate event causally linked to the original request:

```python
async def track_streaming():
    client = MockLLMClient("claude-3")
    adapter = LLMEventAdapter("llm", client)

    processor = StreamProcessor()
    processor.add_source("llm", adapter)

    chunks = []
    processor.on_event(lambda e: chunks.append(e) if e.name == LLMEventTypes.STREAM_CHUNK else None)

    async def simulate():
        await client.request("Tell me a story", stream=True, num_chunks=5)
        await client.close()

    await asyncio.gather(processor.run(), simulate())

    # Every chunk has caused_by_id pointing to the request
    for chunk in chunks:
        print(f"Chunk {chunk.payload['index']}: caused by {chunk.metadata['caused_by_id'][:8]}...")
```

### 4.3 Error Handling

```python
from pyrapide import Pattern, never

# Detect LLM API errors
llm_error_pattern = Pattern.match(LLMEventTypes.ERROR)

processor.enforce(never(llm_error_pattern, name="no_llm_errors"))
processor.on_violation(lambda v: print(f"LLM error detected: {v.description}"))
```

---

## 5. Full Agent Loop: LLM + MCP Together

### 5.1 Modeling the Agent Loop

A typical agentic workflow forms this causal chain:

```
LLM Request ──causes──> Tool Call ──causes──> Tool Result ──causes──> LLM Response
     |                      |                      |                      |
     |                      +-- Resource Read -----+                      |
     |                                                                    |
     +-------- The full causal chain is preserved and queryable ----------+
```

The LLM sends a request, which causes one or more MCP tool calls. Each tool call causes a result (or error). The results feed back into the LLM, which produces the final response. PyRapide captures this entire chain as a causal DAG.

### 5.2 Building the Causal Chain Manually

When you control the orchestration logic, you can build the causal chain explicitly:

```python
import asyncio
from pyrapide import Event, Computation, queries, visualization

async def agent_loop():
    comp = Computation()

    # Step 1: LLM decides to call tools
    llm_request = Event(
        name="llm.request",
        payload={"prompt": "Find and summarize the top users"},
        source="orchestrator",
    )
    comp.record(llm_request)

    # Step 2: MCP tool calls (caused by the LLM request)
    db_call = Event(
        name="mcp.tool_call",
        payload={"tool": "query_users", "args": {"sort": "activity", "limit": 5}},
        source="database-server",
    )
    comp.record(db_call, caused_by=[llm_request])

    # Step 3: Tool results (caused by the tool calls)
    db_result = Event(
        name="mcp.tool_result",
        payload={"tool": "query_users", "result": [{"name": "Alice"}, {"name": "Bob"}]},
        source="database-server",
    )
    comp.record(db_result, caused_by=[db_call])

    # Step 4: LLM produces final response (caused by the tool results)
    llm_response = Event(
        name="llm.response",
        payload={"text": "The top users are Alice and Bob."},
        source="orchestrator",
    )
    comp.record(llm_response, caused_by=[db_result])

    # Query the full chain
    chain = comp.causal_chain(llm_request, llm_response)
    print(f"Full chain: {' -> '.join(e.name for e in chain)}")
    # Full chain: llm.request -> mcp.tool_call -> mcp.tool_result -> llm.response

    # Who was ultimately responsible?
    roots = queries.root_causes(comp, llm_response)
    print(f"Root causes: {[e.name for e in roots]}")
    # Root causes: ['llm.request']

    # What was the causal depth?
    print(f"Causal depth: {comp.causal_depth()}")  # 3

    # Visualize
    print(visualization.to_ascii(comp))

asyncio.run(agent_loop())
```

### 5.3 Running with StreamProcessor

For real-time monitoring, feed both LLM and MCP adapters into a single `StreamProcessor`:

```python
import asyncio
from pyrapide import (
    MCPEventAdapter, MCPPatterns, LLMEventAdapter,
    StreamProcessor, must_match, never,
)
from pyrapide.integrations.mcp import MockMCPClient
from pyrapide.integrations.llm import MockLLMClient

async def full_agent_monitoring():
    # Set up MCP servers
    db_client = MockMCPClient("database-server")
    db_adapter = MCPEventAdapter("database-server", db_client)

    # Set up LLM
    llm_client = MockLLMClient("claude-3")
    llm_adapter = LLMEventAdapter("llm", llm_client)

    # Create unified processor
    processor = StreamProcessor()
    processor.add_source("db", db_adapter)
    processor.add_source("llm", llm_adapter)

    # Constraints
    processor.enforce(never(MCPPatterns.tool_error(), name="no_tool_errors"))

    # Watch for completed tool roundtrips
    processor.watch(
        MCPPatterns.tool_roundtrip(),
        lambda m: print(f"Tool roundtrip: {m.events[0].payload.get('tool')}")
    )

    # Simulate the agent loop
    async def simulate():
        await db_client.connect()
        await llm_client.request("Find top users")
        await db_client.call_tool("query_users", {"limit": 5})
        await db_client.disconnect()
        await db_client.close()
        await llm_client.close()

    await asyncio.gather(processor.run(), simulate())

    # Post-run analysis on the full computation
    comp = processor.computation
    print(f"Total events: {len(comp)}")
    print(f"Violations: {processor.stats['violation_count']}")

asyncio.run(full_agent_monitoring())
```

---

## 6. Multi-Agent Systems

### 6.1 Agent Connection Type (`=>`)

PyRapide implements three connection types from the RAPIDE specification. For multi-agent systems, the `agent()` connection is the key primitive:

```python
from pyrapide import connect, pipe, agent, Pattern

# Synchronous: handler called directly (blocks until complete)
sync_conn = connect(Pattern.match("request"), handle_request)

# FIFO pipe: matches queued and processed in order
fifo_conn = pipe(Pattern.match("data.chunk"), process_chunk)

# Agent: each match dispatched as an independent asyncio task
async_conn = agent(Pattern.match("job.submitted"), run_job)
```

The `agent()` connection dispatches each matched event's handler as a separate `asyncio.Task`. This models independent agents that operate concurrently without blocking each other:

```python
import asyncio
from pyrapide import agent, Pattern, Event
from pyrapide.core.computation import Computation
from pyrapide.architecture.connections import AgentConnection

# Create an agent connection
conn = agent(
    Pattern.match("task.assigned"),
    lambda match, comp: print(f"Processing: {match.events[0].payload}")
)

# Dispatch events concurrently
comp = Computation()
event = Event(name="task.assigned", payload={"task_id": 1}, source="coordinator")
comp.record(event)

# Each dispatch creates an independent asyncio.Task
task = await conn.dispatch(event, comp)
```

### 6.2 Architecture for Multi-Agent Systems

Use the `@architecture` decorator to define a system of multiple interacting agents:

```python
from pyrapide import interface, action, architecture, agent, Pattern

@interface
class Planner:
    @action
    async def create_plan(self, goal: str): ...

@interface
class Researcher:
    @action
    async def search(self, query: str): ...

@interface
class Writer:
    @action
    async def draft(self, content: str): ...

@architecture
class MultiAgentSystem:
    planner: Planner
    researcher: Researcher
    writer: Writer

    def connections(self):
        return [
            # Planner dispatches research tasks concurrently
            agent(Pattern.match("plan.research_needed"), self.researcher),
            # Research results trigger writing concurrently
            agent(Pattern.match("research.complete"), self.writer),
        ]
```

### 6.3 Detecting Causal Independence Between Agents

When multiple agents operate concurrently, their events may be causally independent. PyRapide lets you verify this:

```python
from pyrapide import Event, Computation, queries

comp = Computation()

# Agent A's work
a_start = Event(name="agent_a.start", source="agent_a")
a_result = Event(name="agent_a.result", source="agent_a")
comp.record(a_start)
comp.record(a_result, caused_by=[a_start])

# Agent B's work (independent)
b_start = Event(name="agent_b.start", source="agent_b")
b_result = Event(name="agent_b.result", source="agent_b")
comp.record(b_start)
comp.record(b_result, caused_by=[b_start])

# Verify independence
print(comp.are_independent(a_result, b_result))  # True
print(comp.are_independent(a_start, a_result))    # False (a_start caused a_result)

# Find all groups of parallel events
groups = queries.parallel_events(comp)
for group in groups:
    print(f"Parallel group: {[e.name for e in group]}")
    # e.g. Parallel group: ['agent_a.start', 'agent_b.start']

# Check if agents share a common cause
ancestors = queries.common_ancestors(comp, a_result, b_result)
print(f"Shared ancestors: {len(ancestors)}")  # 0 (truly independent)
```

---

## 7. Real-Time Monitoring with StreamProcessor

The `StreamProcessor` is the central runtime component for monitoring agentic systems in real time.

### 7.1 Setup

```python
from pyrapide import StreamProcessor, MCPEventAdapter
from pyrapide.integrations.mcp import MockMCPClient

processor = StreamProcessor()

# Add event sources
client = MockMCPClient("my-server")
adapter = MCPEventAdapter("my-server", client)
processor.add_source("server1", adapter)

# Remove a source if needed
processor.remove_source("server1")
```

### 7.2 The EventSource Protocol

Any object with these two members can be used as an event source:

```python
from typing import AsyncIterator, Protocol, runtime_checkable
from pyrapide import Event

@runtime_checkable
class EventSource(Protocol):
    @property
    def name(self) -> str: ...

    def events(self) -> AsyncIterator[Event]: ...
```

The built-in `InMemoryEventSource` is useful for testing and programmatic event injection:

```python
from pyrapide import InMemoryEventSource, Event

source = InMemoryEventSource("test-source")
await source.put(Event(name="test.event", payload={"key": "value"}))
await source.close()  # Signal no more events
```

Both `MCPEventAdapter` and `LLMEventAdapter` implement this protocol.

### 7.3 Pattern Watches

Register callbacks that fire when specific patterns match:

```python
from pyrapide import MCPPatterns

# Watch for tool errors
processor.watch(
    MCPPatterns.tool_error(),
    lambda match: print(f"ERROR: {match.events[0].payload}")
)

# Watch for completed roundtrips
processor.watch(
    MCPPatterns.tool_roundtrip(),
    lambda match: print(f"Roundtrip complete for {match.events[0].payload.get('tool')}")
)

# Remove a watch by pattern reference
error_pattern = MCPPatterns.tool_error()
processor.watch(error_pattern, my_callback)
processor.unwatch(error_pattern)
```

### 7.4 Event Callbacks

Register a callback for every event regardless of pattern:

```python
processor.on_event(lambda event: print(f"[{event.source}] {event.name}"))
```

Callbacks can be sync or async -- the processor handles both:

```python
async def log_event(event):
    await database.insert(event.to_dict())

processor.on_event(log_event)
```

### 7.5 Sliding Window

For long-running agents, the `window_size` parameter prevents unbounded memory growth:

```python
await processor.run(window_size=10000)  # Keep only the 10,000 most recent events
```

When the computation exceeds `window_size`, the oldest events are evicted. Causal edges between surviving events are preserved, so analysis on the remaining events remains accurate.

The default window size is 10,000 events. Set a larger window if you need longer causal chains, or a smaller one to limit memory usage.

### 7.6 Processing Statistics

```python
stats = processor.stats
print(stats)
# {
#   "event_count": 1234,         # Total events processed
#   "source_counts": {            # Events per source
#       "database-server": 500,
#       "ai-server": 400,
#       "filesystem-server": 334,
#   },
#   "violation_count": 2,         # Total constraint violations
#   "match_count": 150,           # Total pattern watch matches
# }
```

### 7.7 Graceful Shutdown

```python
await processor.stop()
```

This sets the internal stop flag and closes any `InMemoryEventSource` instances. Source consumer tasks are cancelled gracefully.

You can also access the computation after shutdown for post-run analysis:

```python
comp = processor.computation  # The Computation object with all recorded events
```

---

## 8. Constraints: Enforcing Agent Behavioral Rules

Constraints let you define rules about what event patterns must (or must not) exist in your agentic system.

### 8.1 `must_match` -- Requiring Patterns

A `must_match` constraint asserts that a pattern has at least one match in the computation. If the pattern has zero matches, that is a violation.

```python
from pyrapide import must_match, MCPPatterns

# Every computation must contain at least one completed tool roundtrip
roundtrip_required = must_match(
    MCPPatterns.tool_roundtrip(),
    name="at_least_one_roundtrip",
    description="System must complete at least one tool call"
)
```

**Important**: `must_match` checks if the pattern has *any* match, not if *every* call has a result. Use it for "at least one X must exist" requirements.

### 8.2 `never` -- Forbidding Patterns

A `never` constraint asserts that a pattern must never match. Each match is a separate violation.

```python
from pyrapide import never, MCPPatterns

# No tool errors allowed
no_errors = never(
    MCPPatterns.tool_error(),
    name="no_tool_errors",
    description="Tool calls must not produce errors"
)

# No errors from a specific critical tool
no_critical_errors = never(
    MCPPatterns.tool_error("payment_process"),
    name="no_payment_errors",
    description="Payment processing must not fail"
)
```

### 8.3 Custom Constraints with `@constraint`

For complex rules that go beyond simple pattern matching:

```python
from pyrapide import constraint, must_match, never, MCPPatterns, Pattern

@constraint
class AgentSafetyRules:
    name = "agent_safety"
    description = "Safety constraints for the agent system"

    def define(self):
        # Rule 1: No tool errors
        never(MCPPatterns.tool_error(), name="no_errors")

        # Rule 2: Must have at least one successful roundtrip
        must_match(MCPPatterns.tool_roundtrip(), name="has_roundtrip")

# Use as a single constraint object
rules = AgentSafetyRules()
processor.enforce(rules)
```

### 8.4 Real-Time Enforcement via ConstraintMonitor

The `ConstraintMonitor` can be used independently for fine-grained control:

```python
from pyrapide import ConstraintMonitor, never, MCPPatterns, Event

monitor = ConstraintMonitor()
monitor.add_constraint(never(MCPPatterns.tool_error(), name="no_errors"))

# Feed events incrementally
event = Event(name="mcp.error", payload={"tool": "query", "error": "timeout"}, source="db")
violations = monitor.check(event)

for v in violations:
    print(f"Violation: {v.constraint_name} - {v.description}")
    print(f"  Type: {v.violation_type}")
    print(f"  Events: {[e.name for e in v.matched_events]}")

# Check accumulated violations
all_violations = monitor.violations
print(f"Total violations so far: {len(all_violations)}")

# Access the monitor's internal computation
comp = monitor.computation
```

### 8.5 Violation Callbacks and Alerting

When using `StreamProcessor`, register violation callbacks for real-time alerting:

```python
import logging

logger = logging.getLogger("agent_monitor")

def alert_on_violation(violation):
    logger.error(
        f"Constraint violated: {violation.constraint_name}\n"
        f"  Description: {violation.description}\n"
        f"  Events: {[e.name for e in violation.matched_events]}"
    )

processor.on_violation(alert_on_violation)
```

---

## 9. Debugging and Root Cause Analysis

PyRapide's `queries` module provides a toolkit for investigating what went wrong (or right) in an agentic system.

### 9.1 Tracing Causal Chains

Given two events, find the shortest causal path between them:

```python
from pyrapide import queries

# Find the causal chain from request to response
chain = comp.causal_chain(request_event, response_event)
if chain is not None:
    print(" -> ".join(e.name for e in chain))
    # e.g. llm.request -> mcp.tool_call -> mcp.tool_result -> llm.response

# Get the number of causal steps
distance = queries.causal_distance(comp, request_event, response_event)
print(f"Causal distance: {distance}")  # e.g. 3
```

### 9.2 Finding Root Causes

When an error occurs, trace backward to find all originating events:

```python
# Find all root events that causally contributed to this error
roots = queries.root_causes(comp, error_event)
for root in roots:
    print(f"Root cause: {root.name} from {root.source}")
    print(f"  Payload: {root.payload}")
```

`root_causes` returns all events that are both ancestors of the target *and* root events (no causal parents of their own).

### 9.3 Computing Impact Sets

When a tool call fails, find everything that was affected downstream:

```python
# What was affected by this failed tool call?
affected = queries.impact_set(comp, failed_call_event)
print(f"{len(affected)} downstream events were affected")
for event in affected:
    print(f"  Affected: {event.name} ({event.source})")
```

### 9.4 Backward and Forward Slicing

Extract just the relevant sub-computation for focused analysis:

```python
# Backward slice: everything that led to this error
error_history = queries.backward_slice(comp, error_event)
print(f"Error history: {len(error_history)} events")

# Forward slice: everything that happened because of this request
request_impact = queries.forward_slice(comp, request_event)
print(f"Request impact: {len(request_impact)} events")
```

Both functions return a new `Computation` object containing only the relevant events with their causal edges preserved.

### 9.5 Bottleneck Detection

Find events that sit on every causal path from roots to leaves -- these are the critical chokepoints:

```python
bottlenecks = queries.bottleneck_events(comp)
for event in bottlenecks:
    print(f"Bottleneck: {event.name} ({event.source})")
```

In an agentic system, bottleneck events are often the coordination points where multiple agents converge.

### 9.6 Parallel Event Groups

Find groups of events that are causally independent -- they ran concurrently without affecting each other:

```python
groups = queries.parallel_events(comp)
for group in groups:
    print(f"Parallel group ({len(group)} events):")
    for event in group:
        print(f"  {event.name} ({event.source})")
```

This is useful for understanding which operations your agentic system is running concurrently versus sequentially.

---

## 10. Anomaly Detection and Prediction

PyRapide includes machine learning components for detecting unusual patterns and predicting future events in agentic systems.

### 10.1 Training the AnomalyDetector

Train on a set of "normal" computations to establish a baseline:

```python
from pyrapide import AnomalyDetector

detector = AnomalyDetector()

# Train on historical computations from normal agent runs
normal_runs = [comp1, comp2, comp3, ...]  # list[Computation]
detector.learn(normal_runs)
```

The detector learns:
- Which event types are normal
- Which causal pairs (A causes B) are expected
- Timing statistics for each causal relationship

### 10.2 Detecting Anomalies

Run the detector on a new computation to find unusual patterns:

```python
anomalies = detector.detect(new_computation)

for anomaly in sorted(anomalies, key=lambda a: -a.severity):
    print(f"[{anomaly.severity:.1f}] {anomaly.anomaly_type}: {anomaly.description}")
    print(f"  Event: {anomaly.event.name} ({anomaly.event.source})")
```

**Anomaly types:**

| Type | Severity | Meaning |
|------|---------|---------|
| `unseen_event` | 0.9 | An event type that was never observed during training |
| `unusual_cause` | 0.7 | A causal relationship that was never observed during training |
| `timing_anomaly` | Variable | A causal delay that is >3 standard deviations from the training mean |

### 10.3 Training the CausalPredictor

Learn transition probabilities from historical data:

```python
from pyrapide import CausalPredictor

predictor = CausalPredictor()

# Learn from one or more computations
predictor.learn(historical_computation)
```

### 10.4 Predicting Next Events

Given a partial computation, predict what is likely to happen next:

```python
predictions = predictor.predict(
    current_computation,
    horizon=5,                # Return up to 5 predictions
    confidence_threshold=0.1,  # Minimum confidence to include
)

for p in predictions:
    print(f"Predicted: {p.event_name}")
    print(f"  Confidence: {p.confidence:.0%}")
    print(f"  Likely cause: {p.likely_cause}")
    print(f"  Expected delay: {p.expected_delay:.3f}s" if p.expected_delay else "  Expected delay: unknown")
    print(f"  Reasoning: {p.reasoning}")
```

You can also predict from a specific event:

```python
# What is likely to follow this particular event?
predictions = predictor.predict_from_event(some_event)
```

---

## 11. Visualization

PyRapide provides multiple visualization formats for inspecting causal structures.

### 11.1 Text Summary

```python
from pyrapide import visualization

print(visualization.summary(comp))
# Output:
# Computation: 12 events, 11 causal edges, depth 4, 1 root events, 2 leaf events
# Top event types:
#   mcp.tool_call: 4
#   mcp.tool_result: 4
#   llm.request: 2
#   llm.response: 2
# Top sources:
#   database-server: 8
#   orchestrator: 4
```

### 11.2 ASCII Causal Graph

```python
print(visualization.to_ascii(comp))
# Output:
# * [llm.request] (orchestrator) a1b2c3d4
#   +-[mcp.tool_call] (database-server) e5f6g7h8
#     <- llm.request
#     +-[mcp.tool_result] (database-server) i9j0k1l2
#       <- mcp.tool_call
#       +-[llm.response] (orchestrator) m3n4o5p6
#         <- mcp.tool_result
```

### 11.3 Graphviz DOT Export

```python
dot_str = visualization.to_dot(
    comp,
    highlight={error_event},       # Highlight specific events in red
    event_types={"mcp.tool_call", "mcp.tool_result"},  # Filter by type
    max_events=200,                 # Truncate for large computations
)

with open("agent_trace.dot", "w") as f:
    f.write(dot_str)

# Render: dot -Tpng agent_trace.dot -o agent_trace.png
```

### 11.4 Mermaid Diagram Export

```python
mermaid_str = visualization.to_mermaid(
    comp,
    highlight={error_event},
    max_events=100,
)

# Embed in Markdown or use Mermaid Live Editor
print(mermaid_str)
# graph TD
#   n1234["llm.request\norchestrator"]
#   n5678["mcp.tool_call\ndatabase-server"]
#   n1234 --> n5678
#   ...
```

### 11.5 JSON Export

For custom UIs (D3.js, React, dashboards):

```python
data = visualization.to_json(comp)
# {
#   "events": [{"id": "...", "name": "llm.request", "payload": {...}, ...}, ...],
#   "edges": [{"from": "event-id-1", "to": "event-id-2"}, ...],
#   "metadata": {"event_count": 12, "edge_count": 11, "causal_depth": 4}
# }
```

---

## 12. Patterns Reference for Agent Systems

Patterns are composable expressions for matching events in a computation. Every operator returns a new `Pattern` that can be further composed.

### Basic Match

```python
from pyrapide import Pattern, placeholder

# Match by event name
Pattern.match("mcp.tool_call")

# Match by name and payload field
Pattern.match("mcp.tool_call", tool="query_users")

# Match by name and source
Pattern.match("mcp.tool_call", source="database-server")

# Capture a value with placeholder
Pattern.match("mcp.tool_call", tool=placeholder("tool_name"))
# Access captured value: match.bindings["tool_name"]

# Wildcard: match any event
Pattern.match("*")
```

### Sequence (`>>`)

P causally precedes Q (there is a causal path from P to Q):

```python
# Tool call followed (causally) by tool result
call_then_result = Pattern.match("mcp.tool_call") >> Pattern.match("mcp.tool_result")

# Equivalent to:
MCPPatterns.tool_roundtrip()
```

### Immediate Sequence (`.then_immediately()`)

P directly causes Q (no intermediate events):

```python
Pattern.match("mcp.connect").then_immediately(Pattern.match("mcp.tool_call"))
```

### Join (`&`)

Both P and Q match, and they share a common causal ancestor:

```python
# Two results that share a common cause (e.g., the same LLM request)
shared_cause = Pattern.match("mcp.tool_result", tool="query") & Pattern.match("mcp.tool_result", tool="embed")
```

### Independence (`|`)

Both P and Q match, and they are causally independent:

```python
# Two independent agent operations running in parallel
parallel_ops = Pattern.match("agent_a.result") | Pattern.match("agent_b.result")
```

### Disjunction (`.or_()`)

Either P or Q matches:

```python
# Match either a tool error or an LLM error
any_error = MCPPatterns.tool_error().or_(Pattern.match("llm.error"))
```

### Union (`.union()`)

Matches any event matched by P or Q, preserving bindings:

```python
all_calls = MCPPatterns.tool_call().union(Pattern.match("llm.request"))
```

### Guard (`.where()`)

Filter matches by a predicate:

```python
# Only match tool calls where the tool name starts with "admin_"
admin_calls = Pattern.match("mcp.tool_call").where(
    lambda m: m.events[0].payload.get("tool", "").startswith("admin_")
)
```

### Timed (`.timed()`)

Add timing constraints:

```python
from pyrapide import SynchronousClock

clock = SynchronousClock()

# Tool roundtrip must complete within 5 seconds
fast_roundtrip = MCPPatterns.tool_roundtrip().timed(clock, max_duration=5.0)

# Events after a specific time
late_events = Pattern.match("mcp.error").timed(clock, after=10.0)
```

### Repeat (`.repeat()`)

Match zero or more occurrences:

```python
# Collect all tool calls
all_calls = MCPPatterns.tool_call().repeat()
```

---

## 13. Cookbook: Common Agent Patterns

### 13.1 Retry Detection

Detect when an agent retries the same tool call:

```python
from pyrapide import Pattern, Computation, queries

def detect_retries(comp: Computation, tool_name: str) -> list[list]:
    """Find sequences where the same tool was called multiple times."""
    calls = comp.events_by_name("mcp.tool_call")
    tool_calls = [e for e in calls if e.payload.get("tool") == tool_name]

    if len(tool_calls) <= 1:
        return []

    # Group by shared causal ancestry (same originating request)
    retry_groups = []
    for i, call_a in enumerate(tool_calls):
        group = [call_a]
        for call_b in tool_calls[i + 1:]:
            ancestors_a = comp.ancestors(call_a)
            ancestors_b = comp.ancestors(call_b)
            if ancestors_a & ancestors_b:  # Shared ancestor = likely a retry
                group.append(call_b)
        if len(group) > 1:
            retry_groups.append(group)

    return retry_groups
```

### 13.2 Timeout Enforcement

Enforce that tool calls complete within a deadline:

```python
from pyrapide import MCPPatterns, SynchronousClock, never

clock = SynchronousClock()

# Detect roundtrips that take longer than 5 seconds
slow_roundtrip = MCPPatterns.tool_roundtrip().timed(clock, max_duration=5.0)

# Invert: use a never constraint on slow roundtrips if you want to flag them
# Or use a pattern watch to detect them:
processor.watch(slow_roundtrip, lambda m: print("Slow tool call detected!"))
```

### 13.3 Tool Call Auditing

Log every tool call with full context:

```python
import json
from pyrapide import MCPEventTypes

def audit_tool_calls(event):
    if event.name == MCPEventTypes.TOOL_CALL:
        log_entry = {
            "event_id": event.id,
            "tool": event.payload.get("tool"),
            "args": event.payload.get("args"),
            "server": event.source,
            "timestamp": event.timestamp,
            "correlation_id": event.metadata.get("correlation_id", ""),
        }
        print(f"AUDIT: {json.dumps(log_entry)}")

processor.on_event(audit_tool_calls)
```

### 13.4 Cross-Server Dependency Tracking

Trace causal chains that span multiple MCP servers:

```python
from pyrapide import queries

def trace_cross_server(comp, target_event):
    """Show the full cross-server causal history of an event."""
    history = queries.backward_slice(comp, target_event)

    # Group by source
    by_source = {}
    for event in history.events:
        by_source.setdefault(event.source, []).append(event)

    print(f"Event '{target_event.name}' has history spanning {len(by_source)} servers:")
    for source, events in by_source.items():
        print(f"  {source}: {len(events)} events")
        for e in events:
            print(f"    - {e.name}: {e.payload}")
```

### 13.5 Agent Decision Provenance

Given an agent's final output, reconstruct exactly what information it used:

```python
from pyrapide import queries, visualization

def explain_decision(comp, response_event):
    """Explain why the agent produced this particular response."""
    # Get the complete causal history
    history = queries.backward_slice(comp, response_event)

    print(f"Decision provenance for: {response_event.payload}")
    print(f"Based on {len(history)} events:\n")

    # Show the critical path (most direct causal chain)
    roots = queries.root_causes(comp, response_event)
    for root in roots:
        chain = comp.causal_chain(root, response_event)
        if chain:
            print(f"Chain from {root.name}:")
            for step in chain:
                print(f"  -> {step.name} ({step.source}): {step.payload}")
            print()

    # Show the full causal graph
    print("Full causal graph:")
    print(visualization.to_ascii(history))
```

---

## 14. API Quick Reference

### Core

| Symbol | Type | Description |
|--------|------|-------------|
| `Event` | class | Immutable Pydantic model: `id`, `name`, `payload`, `source`, `timestamp`, `metadata` |
| `Poset` | class | Partially ordered set (DAG) of events |
| `Computation` | class | Queryable wrapper around Poset with `record()`, `causal_chain()`, `events_by_name()`, etc. |
| `Clock` | class | Abstract timing source |
| `SynchronousClock` | class | Global synchronous clock |
| `RegularClock` | class | Fixed-period clock with bounded accuracy |
| `SlavedClock` | class | Clock derived from a parent clock |
| `ClockManager` | class | Manages multiple named clocks |

### Types

| Symbol | Type | Description |
|--------|------|-------------|
| `@interface` | decorator | Marks a class as a RAPIDE component interface |
| `@action` | decorator | Marks a method as an event-generating action |
| `@provides` | decorator | Marks a method as externally visible |
| `@requires` | decorator | Marks a method as required but not implemented |
| `@behavior` | decorator | Marks a method as a reactive behavior rule |
| `is_subtype(a, b)` | function | Check structural subtyping |
| `conforms_to(module, iface)` | function | Check if module implements interface |

### Patterns

| Symbol | Type | Description |
|--------|------|-------------|
| `Pattern.match(name, **fields)` | classmethod | Create a basic event pattern |
| `P >> Q` | operator | Sequence: P causally precedes Q |
| `P & Q` | operator | Join: both match with common ancestor |
| `P \| Q` | operator | Independence: both match, causally independent |
| `P.or_(Q)` | method | Disjunction: either matches |
| `P.union(Q)` | method | Union: events from either pattern |
| `P.where(pred)` | method | Guard: filter by predicate |
| `P.timed(clock, ...)` | method | Timing constraints |
| `P.repeat()` | method | Zero or more matches |
| `P.then_immediately(Q)` | method | Immediate sequence |
| `placeholder(name)` | function | Binding variable for captures |
| `PatternMatch` | dataclass | Match result: `.events` tuple, `.bindings` dict |

### Architecture

| Symbol | Type | Description |
|--------|------|-------------|
| `@architecture` | decorator | Marks a class as a system architecture |
| `connect(pattern, handler)` | function | Synchronous connection |
| `pipe(pattern, handler)` | function | FIFO queued connection |
| `agent(pattern, handler)` | function | Independent async connection |

### Constraints

| Symbol | Type | Description |
|--------|------|-------------|
| `must_match(pattern, name=, description=)` | function | Pattern must have at least one match |
| `never(pattern, name=, description=)` | function | Pattern must never match |
| `@constraint` | decorator | Custom constraint class |
| `ConstraintMonitor` | class | Incremental constraint checker |
| `ConstraintViolation` | dataclass | Violation record: `.constraint_name`, `.violation_type`, `.description`, `.matched_events` |

### Executable

| Symbol | Type | Description |
|--------|------|-------------|
| `@module(implements=, serial=)` | decorator | Transforms class into a runnable module |
| `@when(pattern)` | decorator | Reactive handler triggered on pattern match |
| `Engine` | class | Orchestrates module execution: `engine.bind()`, `await engine.run()` |

### Runtime

| Symbol | Type | Description |
|--------|------|-------------|
| `StreamProcessor` | class | Multi-source real-time event processor |
| `InMemoryEventSource` | class | Queue-based event source for testing |

### Integrations

| Symbol | Type | Description |
|--------|------|-------------|
| `MCPEventAdapter` | class | Translates MCP protocol events to PyRapide Events |
| `MCPEventTypes` | class | Constants: `TOOL_CALL`, `TOOL_RESULT`, `ERROR`, `RESOURCE_READ`, `CONNECT`, `DISCONNECT` |
| `MCPPatterns` | class | Pre-built patterns: `tool_call()`, `tool_result()`, `tool_roundtrip()`, `tool_error()`, `server_lifecycle()` |
| `LLMEventAdapter` | class | Translates LLM API events to PyRapide Events |
| `LLMEventTypes` | class | Constants: `REQUEST`, `RESPONSE`, `STREAM_CHUNK`, `ERROR` |

### Analysis

| Symbol | Type | Description |
|--------|------|-------------|
| `queries.root_causes(comp, event)` | function | All root ancestors of an event |
| `queries.impact_set(comp, event)` | function | All descendants of an event |
| `queries.critical_path(comp)` | function | Longest causal chain |
| `queries.causal_distance(comp, a, b)` | function | Shortest causal path length |
| `queries.common_ancestors(comp, a, b)` | function | Shared ancestors of two events |
| `queries.backward_slice(comp, event)` | function | Sub-computation: event + all ancestors |
| `queries.forward_slice(comp, event)` | function | Sub-computation: event + all descendants |
| `queries.parallel_events(comp)` | function | Groups of causally independent events |
| `queries.bottleneck_events(comp)` | function | Events on every root-to-leaf path |
| `queries.event_frequency(comp)` | function | Event counts by name |
| `queries.causal_density(comp)` | function | Ratio of actual to maximum possible edges |
| `visualization.summary(comp)` | function | Text summary of computation |
| `visualization.to_ascii(comp)` | function | ASCII causal graph |
| `visualization.to_dot(comp, ...)` | function | Graphviz DOT export |
| `visualization.to_mermaid(comp, ...)` | function | Mermaid diagram export |
| `visualization.to_json(comp)` | function | JSON export for custom UIs |
| `CausalPredictor` | class | Learns causal patterns, predicts future events |
| `AnomalyDetector` | class | Detects unusual events and timing anomalies |

### Serialization

| Symbol | Type | Description |
|--------|------|-------------|
| `Event.to_dict()` / `Event.from_dict(d)` | method | Event serialization |
| `Computation.to_dict()` / `Computation.from_dict(d)` | method | Computation serialization |

---

## 15. Framework Adapter Templates

> **For AI coding agents (Claude Code, Codex, Cursor, etc.):** If you are helping a user
> integrate PyRapide with an existing agentic framework, go directly to the `INTEGRATION.md`
> file in the relevant subdirectory of `pyrapide/agent_templates/`. Each file is self-contained with
> copy-paste code, event mappings, and full examples.

PyRapide provides drop-in adapters for 8 popular agentic AI frameworks. Each adapter
translates framework-native events into PyRapide's unified event taxonomy with automatic
causal linking -- typically requiring only 1-3 lines of code to add to an existing project.

### Quick Reference

| Framework | Adapter Class | Import Path | Integration | Guide |
|-----------|--------------|-------------|-------------|-------|
| Microsoft AutoGen | `AutoGenAdapter` | `from pyrapide.agent_templates.autogen import AutoGenAdapter` | 2 lines | `pyrapide/agent_templates/autogen/INTEGRATION.md` |
| LangGraph / LangChain | `LangGraphAdapter` | `from pyrapide.agent_templates.langgraph import LangGraphAdapter` | 2 lines | `pyrapide/agent_templates/langgraph/INTEGRATION.md` |
| CrewAI | `CrewAIAdapter` | `from pyrapide.agent_templates.crewai import CrewAIAdapter` | 3 lines | `pyrapide/agent_templates/crewai/INTEGRATION.md` |
| LlamaIndex | `LlamaIndexAdapter` | `from pyrapide.agent_templates.llamaindex import LlamaIndexAdapter` | 2 lines | `pyrapide/agent_templates/llamaindex/INTEGRATION.md` |
| Agno (formerly Phidata) | `AgnoAdapter` | `from pyrapide.agent_templates.agno import AgnoAdapter` | 2 lines | `pyrapide/agent_templates/agno/INTEGRATION.md` |
| OpenAI Swarm | `SwarmAdapter` | `from pyrapide.agent_templates.swarm import SwarmAdapter` | 1 line | `pyrapide/agent_templates/swarm/INTEGRATION.md` |
| MetaGPT | `MetaGPTAdapter` | `from pyrapide.agent_templates.metagpt import MetaGPTAdapter` | 1 line | `pyrapide/agent_templates/metagpt/INTEGRATION.md` |
| FlowiseAI | `FlowiseAdapter` | `from pyrapide.agent_templates.flowise import FlowiseAdapter` | 2 lines | `pyrapide/agent_templates/flowise/INTEGRATION.md` |

### Shared Core Components

All adapters build on these shared abstractions in `pyrapide/agent_templates/core/`:

| Component | Import | Purpose |
|-----------|--------|---------|
| `AgentEventTypes` | `from pyrapide.agent_templates.core import AgentEventTypes` | 17 unified event constants: `agent.tool.call`, `agent.llm.request`, `agent.handoff`, etc. |
| `BaseAgentAdapter` | `from pyrapide.agent_templates.core import BaseAgentAdapter` | Abstract base implementing the `EventSource` protocol for `StreamProcessor` |
| `CausalTracker` | `from pyrapide.agent_templates.core import CausalTracker` | Auto-links events via correlation IDs, scope stacks, and sequential heuristics |
| `AgentPatterns` | `from pyrapide.agent_templates.core import AgentPatterns` | Pre-built patterns: `tool_roundtrip()`, `llm_roundtrip()`, `full_tool_lifecycle()`, `error_cascade()`, etc. |
| `ResultBridge` | `from pyrapide.agent_templates.core import ResultBridge` | Translates PyRapide analysis results to dict, markdown, or Graphviz DOT |

### Unified Event Taxonomy

All 8 adapters normalize framework events into these types:

| Category | Events |
|----------|--------|
| Tool lifecycle | `agent.tool.call`, `agent.tool.result`, `agent.tool.error` |
| LLM lifecycle | `agent.llm.request`, `agent.llm.response`, `agent.llm.stream_chunk`, `agent.llm.error` |
| Agent communication | `agent.message.send`, `agent.handoff` |
| Task lifecycle | `agent.task.start`, `agent.task.end`, `agent.task.error` |
| Agent loop | `agent.step.start`, `agent.step.end` |
| Run lifecycle | `agent.run.start`, `agent.run.end` |

### Universal Integration Pattern

Regardless of framework, the integration follows this structure:

```python
# Step 1: Create the framework-specific adapter
from pyrapide.agent_templates.langgraph import LangGraphAdapter  # or any framework
adapter = LangGraphAdapter("my-app")

# Step 2: Feed into StreamProcessor for real-time monitoring
from pyrapide import StreamProcessor
processor = StreamProcessor()
processor.add_source("langgraph", adapter)

# Step 3: Add constraints and pattern watches
from pyrapide.agent_templates.core import AgentPatterns
from pyrapide import never, must_match

processor.enforce(never(AgentPatterns.tool_error(), name="no_tool_errors"))
processor.enforce(must_match(AgentPatterns.tool_roundtrip(), name="tool_must_complete"))
processor.watch(AgentPatterns.tool_roundtrip(), lambda m: print(f"Tool completed: {m}"))

# Step 4: Run the framework (framework-specific)
# For LangGraph: graph.invoke(input, config={"callbacks": [adapter.callback_handler]})
# For CrewAI: crew.kickoff()
# etc.
await processor.run()

# Step 5: Post-run analysis
from pyrapide import queries, visualization
comp = processor.computation
print(visualization.summary(comp))

# Find root causes of any errors
errors = comp.events_by_name("agent.tool.error")
for err in errors:
    roots = queries.root_causes(comp, err)
    print(f"Error caused by: {[r.name for r in roots]}")
```

### Directory Layout

```
agent_templates/
├── core/                # Shared: AgentEventTypes, BaseAgentAdapter, CausalTracker, AgentPatterns
│   ├── event_types.py   # 17 unified event constants
│   ├── base_adapter.py  # Abstract base with emit(), EventSource protocol
│   ├── causal_tracker.py # 3-mechanism auto-linking (parent, correlation, scope)
│   ├── patterns.py      # 15+ pre-built patterns for agent systems
│   └── result_bridge.py # Analysis result formatting
├── autogen/             # Microsoft AutoGen — INTEGRATION.md + adapter.py + template.py
├── langgraph/           # LangGraph / LangChain — INTEGRATION.md + adapter.py + template.py
├── crewai/              # CrewAI — INTEGRATION.md + adapter.py + template.py
├── llamaindex/          # LlamaIndex — INTEGRATION.md + adapter.py + template.py
├── agno/                # Agno (Phidata) — INTEGRATION.md + adapter.py + template.py
├── swarm/               # OpenAI Swarm — INTEGRATION.md + adapter.py + template.py
├── metagpt/             # MetaGPT — INTEGRATION.md + adapter.py + template.py
├── flowise/             # FlowiseAI — INTEGRATION.md + adapter.py + template.py
└── tests/               # Core tests (no framework dependencies required)
```
