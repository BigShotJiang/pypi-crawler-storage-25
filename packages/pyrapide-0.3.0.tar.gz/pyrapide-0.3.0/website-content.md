# PyRapide Website Content

<!-- This file contains all copy, content, and text for pyrapide.com. It is designed to be consumed by a separate style/layout specification file. Sections are marked with HTML comments indicating their placement context. -->

---

<!-- SECTION: Hero / Above the Fold -->

## Hero

### Headline

Know Why It Happened, Not Just What Happened

### Subheadline

PyRapide is an open-source Python library for modeling, executing, and analyzing causal event-driven architectures. Built on the mathematical foundations of RAPIDE 1.0 from Stanford University, PyRapide gives engineers first-class tools to trace causality, detect patterns, and enforce constraints across distributed systems, MCP servers, and agentic AI workflows.

### Primary CTA

Get Started

### Secondary CTA

View on GitHub (https://github.com/ShaneDolphin/pyrapide)

### Hero Code Snippet

```
    ____        ____              _     __
   / __ \__  __/ __ \____ _____  (_)___/ /__
  / /_/ / / / / /_/ / __ `/ __ \/ / __  / _ \
 / ____/ /_/ / _, _/ /_/ / /_/ / / /_/ /  __/
/_/    \__, /_/ |_|\__,_/ .___/_/\__,_/\___/
      /____/           /_/
        <e1> --causes--> <e2>
         |                 |
         v                 v
        <e3>             <e4> --causes--> <e5>
```

```bash
pip install pyrapide
```

---

<!-- SECTION: Value Proposition / What Is PyRapide -->

## What Is PyRapide?

Most event-driven systems treat events as a flat stream: timestamped entries in a log, ordered by when they happened. PyRapide treats events as a **causal graph**: a directed acyclic structure that captures *why* each event happened, which events caused which other events, and which events are truly independent of one another.

This distinction matters. When you have ten microservices, fifty MCP servers, or a fleet of autonomous agents all generating events concurrently, a timestamp-ordered log cannot answer the question that actually matters: **what caused this failure?**

PyRapide can.

PyRapide provides a complete toolkit for causal event-driven architecture:

- **Define** system components with typed interfaces, actions, and behavioral contracts
- **Connect** components through pattern-matched event routing with three connection semantics (basic, pipe, agent)
- **Constrain** system behavior with declarative rules that specify what must happen and what must never happen
- **Execute** architectures with an async-native engine that tracks full causal history
- **Analyze** the resulting causal computations with queries, visualizations, predictions, and anomaly detection
- **Stream** events from multiple concurrent sources in real time with sliding-window processing

### What Makes It Different

| Traditional Event Systems | PyRapide |
|---|---|
| Events ordered by timestamp | Events ordered by causality |
| Flat logs, sequential streams | Partially ordered event sets (posets / DAGs) |
| Correlation IDs for manual linking | Automatic causal linking built into the computation model |
| After-the-fact log analysis | Real-time constraint monitoring and pattern matching |
| "What happened?" | "Why did it happen?" |

---

<!-- SECTION: Core Concepts Overview -->

## Core Concepts

### Events and Causal History

An `Event` is an immutable, uniquely identified record of something that happened: a tool call, a message, a state change, a sensor reading. Events carry a name, typed payload, source identifier, and timestamp. Crucially, events are linked to their **causes**, forming a causal history rather than a flat log.

```python
from pyrapide import Event

event = Event(
    name="patient.vitals.recorded",
    payload={"heart_rate": 72, "bp_systolic": 120, "bp_diastolic": 80},
    source="icu-monitor-7"
)
```

Events are frozen Pydantic models: immutable, hashable, and serializable. They are compared by their unique ID, not by value.

### Posets: Partially Ordered Event Sets

A `Poset` is a directed acyclic graph (DAG) of events ordered by causality. Unlike a total-order log, a poset captures that some events are **causally independent** -- they happened concurrently with no causal link between them. This is the foundational data structure in PyRapide.

```python
from pyrapide import Event, Poset

poset = Poset()

# A root event with no causes
request = Event(name="api.request", payload={"endpoint": "/data"})
poset.add(request)

# An event caused by the request
db_query = Event(name="db.query", payload={"sql": "SELECT *"})
poset.add(db_query, caused_by=[request])

# Another event also caused by the request (independent of db_query)
cache_check = Event(name="cache.check", payload={"key": "data"})
poset.add(cache_check, caused_by=[request])

# db_query and cache_check are causally independent
assert poset.are_independent(db_query, cache_check)

# Both are caused by request
assert poset.is_ancestor(request, db_query)
assert poset.is_ancestor(request, cache_check)
```

The poset enforces acyclicity: adding a causal link that would create a cycle raises a `CausalCycleError`.

### Computations

A `Computation` wraps a Poset with clock management and high-level query methods. It is the primary result of executing an architecture.

```python
from pyrapide import Computation, Event

comp = Computation()
e1 = Event(name="start", source="main")
e2 = Event(name="process", source="worker")
e3 = Event(name="complete", source="worker")

comp.record(e1)
comp.record(e2, caused_by=[e1])
comp.record(e3, caused_by=[e2])

# Query the computation
print(len(comp))                    # 3
print(comp.causal_depth())          # 2
print(comp.root_events())           # {e1}
print(comp.leaf_events())           # {e3}
print(comp.causal_chain(e1, e3))    # [e1, e2, e3]
```

### Interfaces and Actions

An `@interface` declares the event types a component can produce (actions) and consume (requires). Interfaces define the contract that modules must fulfill.

```python
from pyrapide import interface, action, requires

@interface
class DatabaseService:
    @action
    async def query(self, sql: str, params: dict) -> None: ...

    @action
    async def result(self, data: list) -> None: ...

    @action
    async def error(self, message: str) -> None: ...
```

The `@interface` decorator scans the class for decorated methods and builds an **event alphabet** -- the set of event names this component can produce, namespaced by the interface name (e.g., `DatabaseService.query`).

### Modules

A `@module` implements an interface with concrete behavior. Modules have lifecycle hooks (`start`, `finish`) and reactive handlers (`@when`).

```python
from pyrapide import module, when, get_context, Pattern

@module(implements=DatabaseService)
class PostgresModule:
    async def start(self):
        ctx = get_context(self)
        ctx.generate_event("DatabaseService.query",
                           payload={"sql": "SELECT 1", "params": {}})

    @when(Pattern.match("request.received"))
    async def on_request(self, match):
        ctx = get_context(self)
        event = list(match.events)[0]
        ctx.generate_event("DatabaseService.query",
                           payload={"sql": event.payload["sql"],
                                    "params": event.payload.get("params", {})},
                           caused_by=list(match.events))
```

Modules are checked at decoration time: if a module declares `implements=SomeInterface` but is missing required methods, a `ConformanceError` is raised immediately.

### Architectures and Connections

An `@architecture` composes interfaces into a system. Connections route events between components by pattern matching.

```python
from pyrapide import architecture, interface, action, connect, pipe, agent, Pattern

@interface
class Producer:
    @action
    async def produce(self, item: str) -> None: ...

@interface
class Consumer:
    @action
    async def consume(self, item: str) -> None: ...

@architecture
class Pipeline:
    producer: Producer
    consumer: Consumer

    def connections(self):
        return [
            connect(Pattern.match("Producer.produce"), "consumer"),
        ]
```

PyRapide supports three connection semantics, each with distinct causal behavior:

| Connection | Factory | Semantics |
|---|---|---|
| **Basic** | `connect(pattern, target)` | Synchronous dispatch. Events generated by the handler are directly caused by the triggering event. |
| **Pipe** | `pipe(pattern, target)` | FIFO queue. Events are delivered in order. Each generated event depends on the trigger and on completion of previously queued events. |
| **Agent** | `agent(pattern, target)` | Independent async dispatch. Each match is handled as a separate concurrent task. Generated events are causally dependent on the trigger but temporally independent of other agent-dispatched events. |

### Event Patterns

`Pattern` provides a composable algebra for matching events in a poset. This is the query language for causal event histories.

**Basic patterns** match individual events by name, source, and payload fields:

```python
from pyrapide import Pattern, placeholder

# Match any event named "order.placed"
Pattern.match("order.placed")

# Match with payload constraints
Pattern.match("order.placed", status="pending")

# Match with a placeholder to capture the value
Pattern.match("order.placed", customer=placeholder("cust"))

# Match from a specific source
Pattern.match("order.placed", source="web-frontend")
```

**Composite operators** combine patterns into complex causal queries:

```python
# Causal sequence: P must causally precede Q
placed = Pattern.match("order.placed")
shipped = Pattern.match("order.shipped")
causal_flow = placed >> shipped

# Join: both match and share a common causal ancestor
payment = Pattern.match("payment.processed")
inventory = Pattern.match("inventory.reserved")
coordinated = payment & inventory

# Independence: both match but are causally independent
service_a = Pattern.match("service_a.response")
service_b = Pattern.match("service_b.response")
parallel = service_a | service_b

# Disjunction: either matches
success = Pattern.match("result.success")
failure = Pattern.match("result.failure")
outcome = success.or_(failure)

# Guarded: pattern with a predicate filter
high_value = Pattern.match("order.placed").where(
    lambda m: list(m.events)[0].payload.get("total", 0) > 1000
)

# Timed: pattern with clock-based timing constraints
from pyrapide import SynchronousClock
clock = SynchronousClock("sys")
fast_response = Pattern.match("response").timed(clock, max_duration=5.0)

# Iteration: match all occurrences and combine them
all_errors = Pattern.match("error").repeat()
```

**Pattern operator summary:**

| Operator | Syntax | Meaning |
|---|---|---|
| Sequence | `P >> Q` | P causally precedes Q |
| Immediate Sequence | `P.then_immediately(Q)` | P is a direct cause of Q (no intervening events) |
| Join | `P & Q` | Both match, sharing a common causal ancestor |
| Independence | `P \| Q` | Both match, causally independent |
| Disjunction | `P.or_(Q)` | Either P or Q matches |
| Union | `P.union(Q)` | Any event matching P or Q |
| Guard | `P.where(predicate)` | P matches and predicate returns True |
| Timed | `P.timed(clock, ...)` | P matches within timing constraints |
| Repeat | `P.repeat()` | All occurrences of P, combined into one match |

### Constraints and Monitoring

Constraints declaratively specify behavioral rules for your system. They define what **must** happen and what **must never** happen.

```python
from pyrapide import must_match, never, constraint, Pattern

# Every tool call must eventually produce a result
tool_completes = must_match(
    Pattern.match("mcp.tool_call") >> Pattern.match("mcp.tool_result"),
    name="tool_completion",
    description="Every tool call must produce a result"
)

# Errors must never follow a successful result
no_post_success_error = never(
    Pattern.match("result.success") >> Pattern.match("result.error"),
    name="no_post_success_error",
    description="An error must never follow a successful result"
)
```

The `@constraint` decorator groups related rules into a named constraint set:

```python
@constraint
class MCPSafetyConstraints:
    name = "mcp_safety"
    description = "Safety constraints for MCP server operations"

    def define(self):
        must_match(
            Pattern.match("mcp.tool_call") >> Pattern.match("mcp.tool_result"),
            name="tool_completion"
        )
        never(
            Pattern.match("mcp.error"),
            name="no_errors"
        )
```

The `ConstraintMonitor` checks constraints in real time as events arrive:

```python
from pyrapide import ConstraintMonitor, Event

monitor = ConstraintMonitor()
monitor.add_constraint(tool_completes)
monitor.add_constraint(no_post_success_error)

# Process events one at a time
event = Event(name="mcp.tool_call", payload={"tool": "search"})
violations = monitor.check(event)

# Or monitor an async stream
async for event in event_source:
    violations = monitor.check(event)
    for v in violations:
        print(f"VIOLATION: {v.constraint_name}: {v.description}")
```

### Clocks and Temporal Ordering

PyRapide supports multiple clock types for temporal ordering, following the RAPIDE specification:

```python
from pyrapide import SynchronousClock, RegularClock, SlavedClock, ClockManager

# A synchronous clock where all observers agree on time
wall_clock = SynchronousClock("wall")
wall_clock.tick(1.0)

# A regular clock that ticks at a fixed period
heartbeat = RegularClock("heartbeat", period=0.5, accuracy=0.99)

# A slaved clock derived from a parent
slow_clock = SlavedClock("slow", parent=wall_clock, divisor=10)

# Manage multiple clocks
manager = ClockManager()
manager.register(wall_clock)
manager.register(heartbeat)
```

---

<!-- SECTION: Getting Started Guide -->

## Getting Started

### Prerequisites

- Python 3.11 or higher
- pip (or your preferred Python package manager)

### Installation

```bash
pip install pyrapide
```

PyRapide has minimal core dependencies: `networkx`, `pydantic`, and `typing-extensions`. Optional extras are available:

```bash
# Graphviz visualization support
pip install pyrapide[viz]

# Prediction and anomaly detection (numpy, scikit-learn)
pip install pyrapide[prediction]

# MCP protocol integration
pip install pyrapide[mcp]

# All optional dependencies
pip install pyrapide[viz,prediction,mcp]
```

### Your First Causal Event Architecture

This walkthrough builds a complete system from scratch: defining interfaces, implementing modules, composing an architecture, running it, and inspecting the results.

#### Step 1: Define Interfaces

Interfaces declare what a component can do. Think of them as typed contracts.

```python
from pyrapide import interface, action

@interface
class Sensor:
    """Produces temperature readings."""
    @action
    async def reading(self, temperature: float, unit: str) -> None: ...

@interface
class Alerter:
    """Produces alerts when thresholds are exceeded."""
    @action
    async def alert(self, message: str, severity: str) -> None: ...
```

#### Step 2: Implement Modules

Modules contain the actual behavior. They generate events and react to patterns.

```python
from pyrapide import module, when, get_context, Pattern

@module(implements=Sensor)
class TemperatureSensor:
    async def start(self):
        ctx = get_context(self)
        # Simulate sensor readings
        for temp in [22.0, 23.5, 38.7, 24.1]:
            ctx.generate_event("Sensor.reading",
                               payload={"temperature": temp, "unit": "celsius"})

@module(implements=Alerter)
class ThresholdAlerter:
    @when(Pattern.match("Sensor.reading"))
    async def on_reading(self, match):
        ctx = get_context(self)
        event = list(match.events)[0]
        temp = event.payload["temperature"]
        if temp > 35.0:
            ctx.generate_event("Alerter.alert",
                               payload={"message": f"High temp: {temp}C",
                                        "severity": "warning"},
                               caused_by=list(match.events))
```

#### Step 3: Compose the Architecture

Architectures wire components together with event-pattern connections.

```python
from pyrapide import architecture, connect, Pattern

@architecture
class MonitoringSystem:
    sensor: Sensor
    alerter: Alerter

    def connections(self):
        return [
            connect(Pattern.match("Sensor.reading"), "alerter"),
        ]
```

#### Step 4: Run the Engine

The `Engine` orchestrates the full lifecycle: starting modules, propagating events through connections, dispatching reactive handlers, and collecting the final computation.

```python
import asyncio
from pyrapide import Engine

async def main():
    arch = MonitoringSystem()
    engine = Engine()
    engine.bind(arch, "sensor", TemperatureSensor)
    engine.bind(arch, "alerter", ThresholdAlerter)

    computation = await engine.run(arch, timeout=5.0)
    return computation

computation = asyncio.run(main())
```

#### Step 5: Inspect the Results

Every execution produces a `Computation` -- a full causal history you can query, visualize, and analyze.

```python
from pyrapide import visualization, queries

# Text summary
print(visualization.summary(computation))

# ASCII art of the causal graph
print(visualization.to_ascii(computation))

# Find the critical path (longest causal chain)
crit = queries.critical_path(computation)
print("Critical path:", [e.name for e in crit])

# Find root causes of any alert
alerts = computation.events_by_name("Alerter.alert")
for alert in alerts:
    roots = queries.root_causes(computation, alert)
    print(f"Alert caused by: {[r.name for r in roots]}")
```

#### Step 6: Enforce Constraints

Add runtime behavioral rules.

```python
from pyrapide import must_match, never, Pattern

# Every reading above threshold must produce an alert
safety = must_match(
    Pattern.match("Sensor.reading").where(
        lambda m: list(m.events)[0].payload["temperature"] > 35.0
    ) >> Pattern.match("Alerter.alert"),
    name="high_temp_alert",
    description="High temperature readings must trigger alerts"
)

violations = safety.check(computation)
print(f"Safety violations: {len(violations)}")
```

### Visualization Outputs

PyRapide can render computations in multiple formats:

```python
from pyrapide import visualization

# Graphviz DOT (for rendering with Graphviz tools)
dot_string = visualization.to_dot(computation)

# Mermaid (for embedding in Markdown, GitHub, documentation)
mermaid_string = visualization.to_mermaid(computation)

# JSON (for custom UI frameworks: D3.js, React, etc.)
json_data = visualization.to_json(computation)

# ASCII (for terminal output and logging)
ascii_art = visualization.to_ascii(computation)

# Human-readable summary
summary_text = visualization.summary(computation)
```

---

<!-- SECTION: Streaming and Real-Time Processing -->

## Streaming and Real-Time Processing

PyRapide is built for real-time event processing, not just batch analysis. The `StreamProcessor` consumes events from multiple concurrent sources, applies pattern watches and constraint enforcement in real time, and maintains a configurable sliding window.

```python
import asyncio
from pyrapide import StreamProcessor, InMemoryEventSource, Event, Pattern, never

async def real_time_monitoring():
    processor = StreamProcessor()

    # Add multiple event sources
    source_a = InMemoryEventSource("service-a")
    source_b = InMemoryEventSource("service-b")
    processor.add_source("a", source_a)
    processor.add_source("b", source_b)

    # Watch for specific patterns
    processor.watch(
        Pattern.match("error"),
        callback=lambda match: print(f"Error detected: {match}")
    )

    # Enforce constraints in real time
    processor.enforce(never(
        Pattern.match("system.crash"),
        name="no_crashes"
    ))

    # Handle violations
    processor.on_violation(
        lambda v: print(f"CONSTRAINT VIOLATED: {v.description}")
    )

    # Process events (runs until all sources close)
    await processor.run(window_size=10000)

    print(processor.stats)
    # {'event_count': N, 'source_counts': {...}, 'violation_count': N, 'match_count': N}
```

---

<!-- SECTION: MCP Integration -->

## MCP Server Integration

The agentic AI ecosystem -- particularly Model Context Protocol (MCP) servers -- produces an explosion of asynchronous, distributed events with no built-in causal traceability. PyRapide bridges this gap with the `MCPEventAdapter`, which translates MCP protocol events into causally-linked PyRapide events.

### Why MCP Needs Causal Tracing

When dozens of MCP servers fire tool calls simultaneously, engineers face critical questions that timestamp-ordered logs cannot answer:

- **Which tool call caused this error?** Correlation IDs help, but only for direct request-response pairs. PyRapide tracks the full causal chain across multiple servers and tool invocations.
- **Are my safety constraints being met?** Define rules like "every tool call must produce a result" or "no tool errors allowed" and enforce them in real time.
- **What is the blast radius of this failure?** Use forward slicing to find every downstream event affected by a failing tool call.

### MCP Event Types and Patterns

PyRapide provides built-in event types and pre-built patterns for MCP:

```python
from pyrapide import MCPEventTypes, MCPPatterns

# Event type constants
MCPEventTypes.TOOL_CALL        # "mcp.tool_call"
MCPEventTypes.TOOL_RESULT      # "mcp.tool_result"
MCPEventTypes.RESOURCE_READ    # "mcp.resource_read"
MCPEventTypes.ERROR            # "mcp.error"
MCPEventTypes.CONNECT          # "mcp.connect"
MCPEventTypes.DISCONNECT       # "mcp.disconnect"

# Pre-built patterns
MCPPatterns.tool_call()               # Match any tool call
MCPPatterns.tool_call("search")       # Match a specific tool
MCPPatterns.tool_result()             # Match any tool result
MCPPatterns.tool_roundtrip()          # tool_call >> tool_result sequence
MCPPatterns.tool_error()              # Match any tool error
MCPPatterns.server_lifecycle()        # connect >> disconnect
```

### Multi-Server Monitoring Example

```python
import asyncio
from pyrapide import (
    MCPEventAdapter, MCPPatterns,
    StreamProcessor, must_match, never,
)
from pyrapide.integrations.mcp import MockMCPClient

async def monitor_mcp_servers():
    # Set up adapters for multiple MCP servers
    db_client = MockMCPClient("database-server")
    ai_client = MockMCPClient("ai-server")
    search_client = MockMCPClient("search-server")

    db_adapter = MCPEventAdapter("database-server", db_client)
    ai_adapter = MCPEventAdapter("ai-server", ai_client)
    search_adapter = MCPEventAdapter("search-server", search_client)

    # Define constraints
    no_errors = never(
        MCPPatterns.tool_error(),
        name="no_tool_errors",
        description="No tool errors allowed in production"
    )
    tools_complete = must_match(
        MCPPatterns.tool_roundtrip(),
        name="tool_completion",
        description="Every tool call must produce a result"
    )

    # Set up the stream processor
    processor = StreamProcessor()
    processor.add_source("db", db_adapter)
    processor.add_source("ai", ai_adapter)
    processor.add_source("search", search_adapter)
    processor.enforce(no_errors)
    processor.enforce(tools_complete)

    violations = []
    processor.on_violation(lambda v: violations.append(v))

    # Simulate concurrent server activity
    async def simulate():
        await db_client.connect()
        await ai_client.connect()
        await search_client.connect()

        await db_client.call_tool("query", {"sql": "SELECT * FROM users"})
        await ai_client.call_tool("generate", {"prompt": "Summarize results"})
        await search_client.call_tool("search", {"query": "relevant documents"})

        await db_client.close()
        await ai_client.close()
        await search_client.close()

    await asyncio.gather(simulate(), processor.run())

    print(f"Events processed: {processor.stats['event_count']}")
    print(f"Violations: {len(violations)}")

asyncio.run(monitor_mcp_servers())
```

### LLM Integration

PyRapide also provides an `LLMEventAdapter` for tracing LLM API request/response cycles, including streaming:

```python
from pyrapide import LLMEventAdapter, LLMEventTypes

# LLM event types
LLMEventTypes.REQUEST        # "llm.request"
LLMEventTypes.RESPONSE       # "llm.response"
LLMEventTypes.STREAM_CHUNK   # "llm.stream_chunk"
LLMEventTypes.ERROR          # "llm.error"
```

---

<!-- SECTION: Analysis and Querying -->

## Analysis and Querying

Once you have a `Computation`, PyRapide provides a rich set of analytical tools for understanding the causal structure of your system.

### Causal Queries

```python
from pyrapide import queries

# Find the longest causal chain in the computation
crit_path = queries.critical_path(computation)

# Find all root causes of a specific event
roots = queries.root_causes(computation, target_event)

# Find all downstream effects of an event (blast radius)
impact = queries.impact_set(computation, source_event)

# Measure causal distance between two events
distance = queries.causal_distance(computation, event_a, event_b)

# Find common ancestors of two events
shared = queries.common_ancestors(computation, event_a, event_b)

# Backward slice: all ancestors of a target event
backward = queries.backward_slice(computation, target_event)

# Forward slice: all descendants of a source event
forward = queries.forward_slice(computation, source_event)

# Find groups of causally independent (parallel) events
parallel = queries.parallel_events(computation)

# Find bottleneck events that appear on every root-to-leaf path
bottlenecks = queries.bottleneck_events(computation)

# Count events by name
freq = queries.event_frequency(computation)

# Measure how densely connected the causal graph is
density = queries.causal_density(computation)
```

### Prediction

The `CausalPredictor` learns causal transition patterns from historical computations and predicts likely future events:

```python
from pyrapide import CausalPredictor

predictor = CausalPredictor()

# Learn from historical computations
predictor.learn(historical_computation_1)
predictor.learn(historical_computation_2)

# Predict what happens next given the current state
predictions = predictor.predict(current_computation, horizon=5)
for p in predictions:
    print(f"{p.event_name}: {p.confidence:.0%} confidence")
    print(f"  Likely cause: {p.likely_cause}")
    print(f"  Expected delay: {p.expected_delay:.3f}s")
    print(f"  Reasoning: {p.reasoning}")
```

### Anomaly Detection

The `AnomalyDetector` builds a model of normal causal patterns and flags deviations:

```python
from pyrapide import AnomalyDetector

detector = AnomalyDetector()

# Learn what "normal" looks like from training data
detector.learn([training_comp_1, training_comp_2, training_comp_3])

# Detect anomalies in a new computation
anomalies = detector.detect(new_computation)
for a in anomalies:
    print(f"[{a.anomaly_type}] severity={a.severity:.1f}: {a.description}")
```

The anomaly detector identifies three types of anomalies:

- **Unseen events**: Event types that were never observed during training
- **Unusual causes**: Causal relationships between event types that were never observed during training
- **Timing anomalies**: Causal transitions with timing that deviates significantly (>3 standard deviations) from learned patterns

### Serialization

Computations can be serialized to JSON for storage, transmission, or integration with external tools:

```python
from pyrapide.runtime.serialization import serialize_computation, deserialize_computation

# Save a computation
json_str = serialize_computation(computation, format="json")

# Restore it later
restored = deserialize_computation(json_str, format="json")
```

---

<!-- SECTION: Causal Event-Driven Architecture in Practice -->

## Causal Event-Driven Architecture Across Industries

The core insight of causal event-driven architecture is that **understanding why things happen is more valuable than knowing what happened**. This principle applies across every domain that deals with complex, concurrent, distributed events. Below are concrete examples of how engineers can apply PyRapide's causal event-driven architecture to solve real problems.

### Healthcare: Patient Safety Monitoring

In a hospital ICU, dozens of devices generate events simultaneously: heart monitors, ventilators, IV pumps, medication dispensers. When a patient's condition deteriorates, clinicians need to know the causal chain that led to the crisis, not just that alarms are firing.

```python
from pyrapide import (
    interface, action, architecture, module, when,
    connect, Pattern, must_match, never, get_context, Engine
)

@interface
class VitalMonitor:
    @action
    async def vitals(self, heart_rate: int, bp: int, spo2: float) -> None: ...

@interface
class MedicationPump:
    @action
    async def dose_administered(self, drug: str, dose_mg: float) -> None: ...

@interface
class ClinicalAlert:
    @action
    async def alert(self, condition: str, severity: str, chain: list) -> None: ...

@architecture
class ICUMonitoring:
    vitals: VitalMonitor
    meds: MedicationPump
    alerts: ClinicalAlert

    def connections(self):
        return [
            connect(Pattern.match("VitalMonitor.vitals"), "alerts"),
            connect(Pattern.match("MedicationPump.dose_administered"), "alerts"),
        ]

    def constraints(self):
        return [
            # Every critical vital reading must trigger an alert
            must_match(
                Pattern.match("VitalMonitor.vitals").where(
                    lambda m: list(m.events)[0].payload.get("spo2", 100) < 90
                ) >> Pattern.match("ClinicalAlert.alert"),
                name="hypoxia_alert",
                description="SpO2 below 90% must trigger a clinical alert"
            ),
            # A medication dose must never follow another dose of the same drug
            # within the causal chain without a vitals check in between
            never(
                Pattern.match("MedicationPump.dose_administered")
                    .then_immediately(Pattern.match("MedicationPump.dose_administered")),
                name="double_dose_prevention",
                description="Consecutive doses without vital sign verification are forbidden"
            ),
        ]
```

**What causal tracing enables**: When a patient codes, the attending physician can trace backward from the critical event through the full causal chain -- seeing not just that BP dropped, but that the drop was caused by a specific medication interaction that followed an automated dosage adjustment. The `backward_slice` query gives the complete causal history leading to any event.

### Finance: Transaction Fraud Detection

Financial systems process millions of transactions concurrently across payment networks, clearinghouses, and compliance engines. Fraudulent patterns involve specific *causal sequences* -- not just co-occurrence, but causation.

```python
@interface
class PaymentGateway:
    @action
    async def transaction(self, amount: float, currency: str,
                          merchant: str, card_hash: str) -> None: ...

@interface
class RiskEngine:
    @action
    async def risk_score(self, score: float, factors: list) -> None: ...
    @action
    async def fraud_flag(self, reason: str, confidence: float) -> None: ...

@interface
class ComplianceEngine:
    @action
    async def aml_check(self, status: str, details: dict) -> None: ...

@architecture
class PaymentProcessing:
    gateway: PaymentGateway
    risk: RiskEngine
    compliance: ComplianceEngine

    def connections(self):
        return [
            connect(Pattern.match("PaymentGateway.transaction"), "risk"),
            connect(Pattern.match("PaymentGateway.transaction"), "compliance"),
            connect(Pattern.match("RiskEngine.fraud_flag"), "compliance"),
        ]

    def constraints(self):
        return [
            # Every transaction must be risk-scored
            must_match(
                Pattern.match("PaymentGateway.transaction")
                    >> Pattern.match("RiskEngine.risk_score"),
                name="mandatory_risk_check"
            ),
            # A fraud flag must never be ignored (must lead to AML check)
            must_match(
                Pattern.match("RiskEngine.fraud_flag")
                    >> Pattern.match("ComplianceEngine.aml_check"),
                name="fraud_followup"
            ),
        ]
```

**What causal tracing enables**: When investigators analyze suspicious transactions, they can use `forward_slice` to see every downstream consequence of a flagged transaction -- which compliance checks it triggered, which accounts were frozen, and whether the causal chain was complete. `parallel_events` reveals which transactions were truly independent versus part of a coordinated pattern.

### Government: Inter-Agency Incident Response

Government incident response involves multiple agencies generating events simultaneously: emergency dispatch, law enforcement, medical services, infrastructure monitoring. Understanding causal dependencies between agency actions is critical for after-action review and accountability.

```python
@interface
class DispatchCenter:
    @action
    async def incident_reported(self, type: str, location: str,
                                 severity: int) -> None: ...
    @action
    async def unit_dispatched(self, unit_id: str, eta_minutes: int) -> None: ...

@interface
class FieldUnit:
    @action
    async def on_scene(self, unit_id: str, assessment: str) -> None: ...
    @action
    async def status_update(self, unit_id: str, status: str) -> None: ...

@interface
class CommandCenter:
    @action
    async def situation_report(self, summary: str, resources: list) -> None: ...
    @action
    async def escalation(self, level: int, reason: str) -> None: ...

@architecture
class IncidentResponse:
    dispatch: DispatchCenter
    field: FieldUnit
    command: CommandCenter

    def connections(self):
        return [
            connect(Pattern.match("DispatchCenter.incident_reported"), "field"),
            connect(Pattern.match("DispatchCenter.incident_reported"), "command"),
            connect(Pattern.match("FieldUnit.on_scene"), "command"),
            connect(Pattern.match("FieldUnit.status_update"), "command"),
        ]

    def constraints(self):
        return [
            # Every incident must result in a unit dispatch
            must_match(
                Pattern.match("DispatchCenter.incident_reported")
                    >> Pattern.match("DispatchCenter.unit_dispatched"),
                name="dispatch_required"
            ),
            # Every dispatch must result in an on-scene arrival
            must_match(
                Pattern.match("DispatchCenter.unit_dispatched")
                    >> Pattern.match("FieldUnit.on_scene"),
                name="arrival_required"
            ),
            # Severity 5 incidents must trigger command escalation
            must_match(
                Pattern.match("DispatchCenter.incident_reported").where(
                    lambda m: list(m.events)[0].payload.get("severity", 0) >= 5
                ) >> Pattern.match("CommandCenter.escalation"),
                name="critical_escalation"
            ),
        ]
```

**What causal tracing enables**: In after-action review, investigators can trace the full causal history from initial report through every dispatch, field response, and command decision. `bottleneck_events` reveals single points of failure in the response chain. `causal_distance` quantifies how many steps separated the incident report from the final resolution.

### Education: Learning Analytics and Adaptive Curriculum

Educational platforms generate events from student interactions, assessment engines, content delivery systems, and AI tutors. Causal event analysis reveals which pedagogical interventions actually cause learning outcomes versus which are merely correlated.

```python
@interface
class LearningPlatform:
    @action
    async def content_viewed(self, student_id: str, module: str,
                              duration_sec: int) -> None: ...
    @action
    async def exercise_completed(self, student_id: str, score: float) -> None: ...

@interface
class AITutor:
    @action
    async def hint_provided(self, student_id: str, topic: str) -> None: ...
    @action
    async def explanation_generated(self, student_id: str, concept: str) -> None: ...

@interface
class AssessmentEngine:
    @action
    async def quiz_result(self, student_id: str, score: float,
                           mastery_level: str) -> None: ...

@architecture
class AdaptiveLearning:
    platform: LearningPlatform
    tutor: AITutor
    assessment: AssessmentEngine

    def connections(self):
        return [
            connect(Pattern.match("LearningPlatform.content_viewed"), "tutor"),
            connect(Pattern.match("LearningPlatform.exercise_completed"), "assessment"),
            connect(Pattern.match("AITutor.hint_provided"), "assessment"),
        ]
```

**What causal tracing enables**: By analyzing the causal graph, the platform can determine that a student's improved quiz score was *caused by* a specific AI tutor hint rather than simply correlated with content viewing time. The `CausalPredictor` learns which intervention sequences are most likely to produce mastery, enabling truly adaptive curriculum design. `root_causes` analysis for low assessment scores traces back to the specific content modules or missing prerequisites that caused difficulty.

### Manufacturing: Predictive Maintenance and Quality Control

Manufacturing lines produce thousands of sensor events per second. Causal event analysis links equipment behavior to product quality in real time.

```python
@interface
class MachineSensor:
    @action
    async def reading(self, machine_id: str, metric: str,
                       value: float) -> None: ...

@interface
class QualityInspector:
    @action
    async def inspection(self, batch_id: str, pass_fail: str,
                          defects: list) -> None: ...

@interface
class MaintenanceSystem:
    @action
    async def anomaly_detected(self, machine_id: str,
                                 anomaly_type: str) -> None: ...
    @action
    async def maintenance_scheduled(self, machine_id: str,
                                      priority: str) -> None: ...

@architecture
class SmartFactory:
    sensors: MachineSensor
    quality: QualityInspector
    maintenance: MaintenanceSystem

    def connections(self):
        return [
            connect(Pattern.match("MachineSensor.reading"), "maintenance"),
            connect(Pattern.match("MachineSensor.reading"), "quality"),
            connect(Pattern.match("MaintenanceSystem.anomaly_detected"), "maintenance"),
        ]

    def constraints(self):
        return [
            # Every anomaly must lead to scheduled maintenance
            must_match(
                Pattern.match("MaintenanceSystem.anomaly_detected")
                    >> Pattern.match("MaintenanceSystem.maintenance_scheduled"),
                name="anomaly_response"
            ),
            # A quality failure must never follow a known unresolved anomaly
            never(
                Pattern.match("MaintenanceSystem.anomaly_detected")
                    >> Pattern.match("QualityInspector.inspection").where(
                        lambda m: list(m.events)[0].payload.get("pass_fail") == "fail"
                    ),
                name="no_production_during_anomaly"
            ),
        ]
```

**What causal tracing enables**: When a batch fails quality inspection, engineers trace backward through the causal graph to the specific sensor readings that preceded the defect. The `AnomalyDetector` learns normal sensor-to-quality causal patterns and flags deviations before they cause defects. `impact_set` shows the full downstream blast radius of any equipment anomaly.

### Autonomous Agents and Multi-Agent Orchestration

When multiple AI agents collaborate on a task -- each calling tools, making decisions, and producing outputs -- causal tracing is essential for understanding agent behavior, debugging failures, and maintaining human oversight.

```python
@interface
class PlannerAgent:
    @action
    async def plan_created(self, task: str, steps: list) -> None: ...
    @action
    async def step_delegated(self, step: str, target_agent: str) -> None: ...

@interface
class ExecutorAgent:
    @action
    async def step_started(self, step: str) -> None: ...
    @action
    async def tool_invoked(self, tool: str, args: dict) -> None: ...
    @action
    async def step_completed(self, step: str, result: dict) -> None: ...

@interface
class ReviewerAgent:
    @action
    async def review(self, assessment: str, approved: bool) -> None: ...

@architecture
class AgentTeam:
    planner: PlannerAgent
    executor: ExecutorAgent
    reviewer: ReviewerAgent

    def connections(self):
        return [
            connect(Pattern.match("PlannerAgent.step_delegated"), "executor"),
            connect(Pattern.match("ExecutorAgent.step_completed"), "reviewer"),
            connect(Pattern.match("ReviewerAgent.review"), "planner"),
        ]

    def constraints(self):
        return [
            # Every delegated step must be completed
            must_match(
                Pattern.match("PlannerAgent.step_delegated")
                    >> Pattern.match("ExecutorAgent.step_completed"),
                name="step_completion"
            ),
            # Every completed step must be reviewed
            must_match(
                Pattern.match("ExecutorAgent.step_completed")
                    >> Pattern.match("ReviewerAgent.review"),
                name="mandatory_review"
            ),
            # A tool must never be invoked without a preceding plan step
            never(
                Pattern.match("ExecutorAgent.tool_invoked").where(
                    lambda m: not any(
                        e.name == "PlannerAgent.step_delegated"
                        for e in m.events
                    )
                ),
                name="no_unplanned_tool_use"
            ),
        ]
```

**What causal tracing enables**: When an agent team produces an incorrect output, engineers trace the causal chain from the final output backward through every tool invocation, delegation, and planning step to understand exactly where the process broke down. Constraints like "every tool invocation must be traceable to a plan step" enforce human-controllable agent behavior at the architectural level.

---

<!-- SECTION: API Reference -->

## API Reference

All public symbols are available from the top-level `pyrapide` package:

```python
import pyrapide
print(pyrapide.__version__)
```

### Core

| Symbol | Description |
|---|---|
| `Event` | Immutable causal event with unique ID, name, payload, source, and timestamp |
| `Poset` | Partially ordered set of events (directed acyclic graph) |
| `Computation` | High-level wrapper around a Poset with query methods and clock management |
| `Clock` | Base clock type for temporal ordering |
| `SynchronousClock` | Clock where all observers agree on time |
| `RegularClock` | Synchronous clock that ticks at a fixed period |
| `SlavedClock` | Clock derived from a parent clock by a divisor |
| `ClockManager` | Manages multiple clocks for a computation |
| `CausalCycleError` | Raised when adding a causal edge would create a cycle |

### Types

| Symbol | Description |
|---|---|
| `interface` | Decorator: transforms a class into a RAPIDE interface type |
| `action` | Decorator: marks a method as an event-generating action |
| `provides` | Decorator: marks a method as part of the externally visible interface |
| `requires` | Decorator: marks a method as required but not implemented |
| `behavior` | Decorator: marks a method as a reactive behavior rule |
| `is_subtype(candidate, target)` | Check if candidate provides all operations of target |
| `conforms_to(module_class, interface_class)` | Check if module implements all required methods |

### Patterns

| Symbol | Description |
|---|---|
| `Pattern` | Base class for all event patterns |
| `Pattern.match(name, ...)` | Create a basic pattern matching events by name and payload fields |
| `BasicPattern` | Matches individual events by name, source, and payload |
| `PatternMatch` | Result of a pattern match: matched events and bound values |
| `placeholder(name)` | Create a binding variable for capturing matched values |
| `P >> Q` | Sequence: P must causally precede Q |
| `P.then_immediately(Q)` | Immediate sequence: P is a direct cause of Q |
| `P & Q` | Join: both match with a common causal ancestor |
| `P \| Q` | Independence: both match but are causally independent |
| `P.or_(Q)` | Disjunction: either P or Q matches |
| `P.union(Q)` | Union of P and Q |
| `P.where(predicate)` | Guarded pattern: filter by predicate |
| `P.timed(clock, ...)` | Timed pattern: timing constraints relative to a clock |
| `P.repeat()` | Iteration: match all occurrences, combined |

### Architecture

| Symbol | Description |
|---|---|
| `architecture` | Decorator: transforms a class into a RAPIDE architecture |
| `connect(pattern, target)` | Create a synchronous (basic) connection |
| `pipe(pattern, target)` | Create a FIFO pipe connection |
| `agent(pattern, target)` | Create an independent async (agent) connection |

### Constraints

| Symbol | Description |
|---|---|
| `Constraint` | Base class for all constraints |
| `MustMatch` | Constraint requiring a pattern to match |
| `Never` | Constraint forbidding a pattern from matching |
| `must_match(pattern, ...)` | Factory: create a must-match constraint |
| `never(pattern, ...)` | Factory: create a never constraint |
| `constraint` | Decorator: group constraint rules into a named set |
| `ConstraintViolation` | Record of a constraint violation |
| `ConstraintMonitor` | Real-time constraint checker for live event streams |

### Executable

| Symbol | Description |
|---|---|
| `module(implements=..., serial=...)` | Decorator: transforms a class into a RAPIDE module |
| `when(pattern)` | Decorator: marks a method as a reactive handler |
| `get_context(module_instance)` | Get the ModuleContext for a module instance |

### Runtime

| Symbol | Description |
|---|---|
| `Engine` | Central execution engine for PyRapide architectures |
| `StreamProcessor` | Real-time multi-source event processor with sliding window |
| `InMemoryEventSource` | Simple event source backed by an asyncio queue |

### Integrations

| Symbol | Description |
|---|---|
| `MCPEventAdapter` | Translates MCP protocol events into causally-linked PyRapide events |
| `MCPEventTypes` | MCP protocol event type constants |
| `MCPPatterns` | Pre-built pattern library for common MCP event patterns |
| `LLMEventAdapter` | Translates LLM API events into causally-linked PyRapide events |
| `LLMEventTypes` | LLM API event type constants |

### Analysis

| Symbol | Description |
|---|---|
| `queries.critical_path(comp)` | Longest causal chain in the computation |
| `queries.root_causes(comp, event)` | All root events that are ancestors of the target |
| `queries.impact_set(comp, event)` | All downstream descendants of an event |
| `queries.causal_distance(comp, a, b)` | Shortest causal path length between two events |
| `queries.common_ancestors(comp, a, b)` | Events that are ancestors of both a and b |
| `queries.backward_slice(comp, event)` | Computation of all ancestors of a target event |
| `queries.forward_slice(comp, event)` | Computation of all descendants of a source event |
| `queries.parallel_events(comp)` | Groups of mutually causally independent events |
| `queries.bottleneck_events(comp)` | Events on every root-to-leaf path |
| `queries.event_frequency(comp)` | Event counts by name |
| `queries.causal_density(comp)` | Ratio of actual to maximum possible causal edges |
| `visualization.to_dot(comp, ...)` | Graphviz DOT string |
| `visualization.to_mermaid(comp, ...)` | Mermaid flowchart string |
| `visualization.to_json(comp)` | JSON-serializable dict for custom UIs |
| `visualization.to_ascii(comp)` | ASCII art for terminal output |
| `visualization.summary(comp)` | Human-readable text summary |
| `CausalPredictor` | Learns causal patterns and predicts future events |
| `AnomalyDetector` | Detects anomalies by comparing against learned patterns |

---

<!-- SECTION: Architecture Overview (Package Structure) -->

## Package Architecture

```
pyrapide/
  core/           Core primitives: Event, Poset, Computation, Clock, exceptions
  types/          RAPIDE type system: interfaces, actions, subtype conformance
  patterns/       Causal event pattern algebra: basic, composite, guarded, timed
  architecture/   Architecture definitions: composition, connections, bindings, maps
  constraints/    Constraint enforcement: monitors, filters, conformance checks
  executable/     Module lifecycle: @module, @when reactive handlers, processes
  runtime/        Execution engine, event scheduling, streaming, serialization
  integrations/   MCP and LLM protocol adapters with mock clients
  analysis/       Queries, visualization (DOT/Mermaid/ASCII/JSON), prediction, anomaly detection
  utils/          Internal utilities (ID generation)
```

The package is organized around the RAPIDE specification's layered concepts:

1. **Core** defines the fundamental data structures: events, posets, and computations
2. **Types** define component interfaces and their contracts
3. **Patterns** provide the composable query language for matching events in causal graphs
4. **Architectures** compose interfaces into systems with typed connections
5. **Constraints** specify and enforce behavioral rules
6. **Executables** implement behavior with lifecycle hooks and reactive handlers
7. **Runtime** orchestrates everything: the engine, scheduler, and streaming processor
8. **Integrations** bridge external protocols (MCP, LLM) into the causal event model
9. **Analysis** provides tools for querying, visualizing, predicting, and detecting anomalies

---

<!-- SECTION: History -->

## History

### The Origins: RAPIDE at Stanford (1990s)

PyRapide traces its intellectual lineage to **RAPIDE** (Rapid Prototyping for Application Domain-specific Integrated Environments), an architecture description language developed at Stanford University's Computer Systems Laboratory during the 1990s.

RAPIDE was created by **David C. Luckham** and his research team, including **John Kenney**, **Larry Augustin**, **James Vera**, and **Doug Bryan**. Their work was motivated by a fundamental observation: distributed systems produce complex patterns of concurrent events, and understanding those systems requires capturing not just *what* events occurred, but the **causal relationships** between them.

The key insight that distinguished RAPIDE from other architecture description languages of its era was the **partially ordered event set (poset)** as the primary computational artifact. Where other systems produced flat event traces ordered by timestamps, RAPIDE produced directed acyclic graphs that captured the true causal structure of a computation. Two events could be ordered by causality (one caused the other), temporally ordered (one happened before the other on a given clock), or **causally independent** (they had no causal relationship and happened concurrently).

This was a profound contribution. The poset representation made it possible to distinguish between events that merely happened around the same time and events that were actually causally related -- a distinction that timestamp-ordered logs fundamentally cannot make.

RAPIDE was formally specified across seven reference manuals covering:

- **Types**: Interface types with actions, services, and behavioral contracts
- **Architectures**: Compositional system structure with three connection semantics (basic, pipe, agent)
- **Patterns**: A composable algebra for matching events in posets, including sequence, join, independence, and disjunction operators
- **Constraints**: Declarative rules specifying required and forbidden event patterns
- **Executables**: Reactive programming constructs with causal event generation semantics
- **Predefined Types**: A complete type system including clocks, records, sets, and maps
- **Overview**: The unified computation model based on causal and temporal preorders

Key publications from the RAPIDE project:

- Luckham, D.C. et al. *"Specification and Analysis of System Architecture Using Rapide."* IEEE Transactions on Software Engineering, 1995.
- Luckham, D.C. and Vera, J. *"An Event-Based Architecture Definition Language."* IEEE Transactions on Software Engineering, 1995.
- Luckham, D.C. *"The Power of Events: An Introduction to Complex Event Processing in Distributed Enterprise Systems."* Addison-Wesley, 2002.

### From RAPIDE to PyRapide (2026)

Nearly three decades after RAPIDE's original development, the problems it was designed to solve have become exponentially more relevant. The explosion of agentic AI systems -- particularly Model Context Protocol (MCP) servers -- has created a new generation of distributed, concurrent, event-driven architectures that desperately need causal traceability.

When dozens or hundreds of MCP servers fire events simultaneously, when AI agents call tools across multiple services, when autonomous systems make decisions based on asynchronous inputs -- these are precisely the scenarios where understanding causal relationships is critical for debugging, accountability, safety, and human oversight.

PyRapide was created to bring RAPIDE's rigorous mathematical foundations to modern Python. It is not a port or wrapper of the original RAPIDE codebase. It is a ground-up reimplementation that adapts RAPIDE's core semantics -- causal event posets, interface types, architecture composition, pattern-based constraints, and reactive module execution -- to idiomatic modern Python with:

- **async/await** for native asynchronous execution
- **Pydantic models** for validated, immutable events
- **Python decorators** for declarative interface, module, and architecture definitions
- **Operator overloading** for the pattern algebra (`>>`, `&`, `|`)
- **NetworkX** for the underlying graph data structures
- **Streaming-first design** for real-time event processing
- **Built-in MCP and LLM protocol adapters** for immediate integration with the agentic AI ecosystem

---

<!-- SECTION: Acknowledgments / Stanford Team -->

## Acknowledgments

### The Stanford RAPIDE Team

PyRapide would not exist without the pioneering work of the RAPIDE research team at Stanford University's Computer Systems Laboratory and Program Analysis and Verification Group. Their foundational contributions to event-based architecture description languages in the 1990s laid the theoretical and practical groundwork that PyRapide builds upon today.

We gratefully acknowledge:

**David C. Luckham** -- Principal investigator and the driving force behind the RAPIDE project. Professor Luckham's vision that causal event relationships, not mere temporal ordering, are the fundamental structure worth capturing in distributed systems has proven prescient. His subsequent work on Complex Event Processing (CEP) further extended these ideas into industry practice. His book *"The Power of Events"* (Addison-Wesley, 2002) remains an essential reference for anyone working with event-driven architectures.

**John Kenney** -- Co-designer of the RAPIDE architecture description language and contributor to the formal specification of RAPIDE's type system and architecture composition semantics.

**Larry Augustin** -- Contributor to the RAPIDE toolset and the practical implementation of the RAPIDE execution environment at Stanford.

**James Vera** -- Co-author of the foundational paper on event-based architecture definition languages and contributor to RAPIDE's pattern and constraint subsystems.

**Doug Bryan** -- Contributor to the RAPIDE project's implementation and the development of the RAPIDE pattern language.

The RAPIDE team demonstrated that it was possible to build practical tools for causal event analysis on a rigorous mathematical foundation. Their work on partially ordered event sets, the distinction between causal and temporal ordering, composable event pattern algebras, and declarative constraint languages established the conceptual framework that remains as relevant today -- in the era of MCP servers and autonomous AI agents -- as it was for the distributed systems of the 1990s.

We are honored to carry their ideas forward into a new generation of engineering tools.

---

<!-- SECTION: Contributing / Open Source -->

## Contributing

PyRapide is open source under the **MIT License**. We welcome contributions from developers, researchers, and practitioners across all experience levels.

### How to Contribute

```bash
# Clone the repository
git clone https://github.com/ShaneDolphin/pyrapide.git
cd PyRapide

# Set up the development environment
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"

# Run the test suite
pytest tests/ -v

# Type check
mypy pyrapide/ --ignore-missing-imports

# Lint
ruff check pyrapide/
```

### Development Workflow

PyRapide follows a strict test-first development process:

1. **Write tests first.** Create or update tests in `tests/` that describe the expected behavior.
2. **Confirm tests fail.** Run `pytest tests/ -v` and verify the new tests fail for the right reason.
3. **Implement.** Write the minimal code to make all tests pass.
4. **Confirm zero regressions.** Run the full suite -- every existing test must still pass.
5. **Type check and lint.** Run `mypy` and `ruff`. Both must report zero errors.

### Code Standards

- Python 3.11+ features: type unions with `|`, `match` statements where appropriate
- `from __future__ import annotations` for forward reference support
- Frozen Pydantic models for events -- never mutate them
- `async def` for any function that might need to `await`
- Every public class and function must have a docstring with a one-line summary, description, and usage example

### What to Contribute

- **New event source adapters**: Kafka, Redis Streams, AWS EventBridge, webhook endpoints
- **New visualization backends**: Interactive web-based graph renderers, timeline views
- **New pattern operators**: Custom pattern types for domain-specific matching
- **Performance improvements**: Optimized pattern matching for large posets
- **Documentation**: Tutorials, guides, examples for specific domains and use cases
- **Bug reports and fixes**: File issues at [https://github.com/ShaneDolphin/pyrapide/issues](https://github.com/ShaneDolphin/pyrapide/issues)

### Repository

- **Source Code**: [https://github.com/ShaneDolphin/pyrapide](https://github.com/ShaneDolphin/pyrapide)
- **Issues**: [https://github.com/ShaneDolphin/pyrapide/issues](https://github.com/ShaneDolphin/pyrapide/issues)
- **License**: [MIT License](https://github.com/ShaneDolphin/pyrapide/blob/main/LICENSE)

---

<!-- SECTION: Footer -->

## Footer Content

PyRapide is open source under the MIT License.

Built on the foundations of RAPIDE 1.0, developed at Stanford University by David Luckham and team.

[GitHub](https://github.com/ShaneDolphin/pyrapide) | [Issues](https://github.com/ShaneDolphin/pyrapide/issues) | [PyPI](https://pypi.org/project/pyrapide/)

Copyright 2026 Shane Morris.

---

<!-- SECTION: SEO / Meta Content -->

## Meta Content

### Page Title
PyRapide -- Causal Event-Driven Architecture for Python

### Meta Description
PyRapide is an open-source Python library for modeling, executing, and analyzing causal event-driven architectures. Built on Stanford's RAPIDE 1.0, it provides first-class tools for tracing causality, detecting patterns, and enforcing constraints across distributed systems, MCP servers, and agentic AI workflows.

### Keywords
pyrapide, causal event-driven architecture, event-driven, causal, poset, partially ordered set, event patterns, constraint monitoring, MCP, model context protocol, agentic AI, distributed systems, event processing, complex event processing, architecture description language, RAPIDE, Stanford, Python, open source
