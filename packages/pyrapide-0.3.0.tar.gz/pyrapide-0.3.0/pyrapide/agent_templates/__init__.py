"""PyRapide Agent Templates — Framework adapters for agentic AI systems.

Provides drop-in adapters that let users of AutoGen, LangGraph, CrewAI,
LlamaIndex, Agno, OpenAI Swarm, MetaGPT, and FlowiseAI instrument their
existing projects with PyRapide causal event tracking in 1-3 lines of code.

Quick start::

    from pyrapide.agent_templates.core import AgentEventTypes, AgentPatterns, BaseAgentAdapter

For framework-specific adapters::

    from pyrapide.agent_templates.langgraph import LangGraphAdapter
    from pyrapide.agent_templates.autogen import AutoGenAdapter
    # etc.
"""

__version__ = "0.1.0"
