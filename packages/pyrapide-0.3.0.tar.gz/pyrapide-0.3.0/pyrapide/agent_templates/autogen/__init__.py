"""PyRapide adapter for Microsoft AutoGen.

Provides ``AutoGenAdapter`` which hooks into an AutoGen runtime via
``InterventionHandler`` to emit causal events for every agent message,
publication, and LLM response.

Usage::

    from pyrapide.agent_templates.autogen import AutoGenAdapter

    adapter = AutoGenAdapter("my-autogen-app", runtime=runtime)
"""

from pyrapide.agent_templates.autogen.adapter import AutoGenAdapter

__all__ = ["AutoGenAdapter"]
