# AutoGen + PyRapide Integration

> **Navigation**: [Main Docs](../../pyrapide-agent-documentation.md) | **AutoGen** | [LangGraph](../langgraph/INTEGRATION.md) | [CrewAI](../crewai/INTEGRATION.md) | [LlamaIndex](../llamaindex/INTEGRATION.md)

## Quick Start

```python
from autogen_core import SingleThreadedAgentRuntime
from pyrapide.agent_templates.autogen import AutoGenAdapter

runtime = SingleThreadedAgentRuntime()
adapter = AutoGenAdapter("my-agents", runtime=runtime)

# Events are captured via InterventionHandler — iterate or use StreamProcessor
async for event in adapter.events():
    print(event.name, event.payload)
```

## Prerequisites

```bash
pip install pyrapide autogen-agentchat autogen-ext[openai]
```

## How It Works

The adapter registers an `autogen_core.InterventionHandler` on the `SingleThreadedAgentRuntime`. This handler intercepts every `send`, `publish`, and `response` flowing through the runtime and translates each into a PyRapide `Event` with automatic causal linking.

Causal relationships are inferred by the `CausalTracker`: tool calls are linked to the LLM response that triggered them, LLM requests after tool use are linked to the preceding tool result, and handoffs are linked to the LLM decision that initiated them. All events are emitted through an async queue implementing the `EventSource` protocol, so the adapter plugs directly into `StreamProcessor`.

## Event Mapping

| AutoGen Event | PyRapide Event | Causal Link |
|---|---|---|
| `InterventionHandler.on_send()` | `agent.message.send` (AGENT_MESSAGE) | Scope or inferred from last LLM_RESPONSE |
| `ToolCallRequestEvent` (stream) | `agent.tool.call` (TOOL_CALL) | Caused by most recent LLM_RESPONSE |
| `ToolCallExecutionEvent` (stream) | `agent.tool.result` (TOOL_RESULT) | Caused by matching TOOL_CALL |
| `InterventionHandler.on_response()` | `agent.llm.response` (LLM_RESPONSE) | Caused by preceding LLM_REQUEST or TOOL_RESULT |
| `HandoffMessage` | `agent.handoff` (AGENT_HANDOFF) | Caused by most recent LLM_RESPONSE |

## Full Example

```python
import asyncio
from autogen_agentchat.agents import AssistantAgent
from autogen_agentchat.teams import RoundRobinGroupChat
from autogen_agentchat.conditions import TextMentionTermination
from autogen_ext.models.openai import OpenAIChatCompletionClient
from pyrapide.agent_templates.autogen import AutoGenAdapter

async def main():
    model_client = OpenAIChatCompletionClient(model="gpt-4o-mini")
    assistant = AssistantAgent(
        name="assistant",
        model_client=model_client,
        system_message="You are helpful. End replies with TERMINATE.",
    )

    termination = TextMentionTermination("TERMINATE")
    team = RoundRobinGroupChat(
        participants=[assistant], termination_condition=termination,
    )

    # --- PyRapide: 2 lines ---
    adapter = AutoGenAdapter("autogen-demo")
    collected = []

    async def collect():
        async for event in adapter.events():
            collected.append(event)

    task = asyncio.create_task(collect())
    result = await team.run(task="What are Newton's three laws?")
    await adapter.close()
    await task

    # --- Inspect causal graph ---
    comp = adapter.computation
    print(f"{len(comp)} events tracked")
    for ev in comp.topological_order():
        print(f"  {ev.name:<30} id={ev.id[:8]}")

asyncio.run(main())
```

## Adding Constraints

```python
from pyrapide.agent_templates.core.patterns import AgentPatterns
from pyrapide.constraints.pattern_constraints import MustMatch, Never

# Every tool call must produce a result
must_complete = MustMatch(
    AgentPatterns.tool_roundtrip(),
    name="tool-must-complete",
    description="Every tool call must have a corresponding result",
)

# No cascading errors
no_cascade = Never(
    AgentPatterns.error_cascade(),
    name="no-error-cascade",
    description="Errors must not cause further errors",
)

# Check constraints against the computation
from pyrapide.constraints.conformance import check_conformance
violations = check_conformance(adapter.computation, [must_complete, no_cascade])
for v in violations:
    print(f"VIOLATION: {v.constraint_name} -- {v.description}")
```

## Post-Run Analysis

```python
from pyrapide.analysis import queries, visualization

comp = adapter.computation

# Find root causes of any event
error_events = [e for e in comp.events if "error" in e.name]
for err in error_events:
    roots = queries.root_causes(comp, err)
    print(f"Error {err.id[:8]} caused by: {[r.name for r in roots]}")

# Critical path through the agent run
path = queries.critical_path(comp)
print("Critical path:", [e.name for e in path])

# Visualize the causal DAG
dot_graph = visualization.to_dot(comp)          # Graphviz DOT format
mermaid = visualization.to_mermaid(comp)         # Mermaid flowchart
ascii_art = visualization.to_ascii(comp)         # Terminal-friendly
print(visualization.summary(comp))               # Text summary
```

## API Reference

```python
class AutoGenAdapter(BaseAgentAdapter):
    def __init__(self, name: str, runtime: SingleThreadedAgentRuntime | None = None) -> None
        """Create adapter. If runtime is provided, handler is auto-registered."""

    @property
    def callback_handler(self) -> InterventionHandler
        """The InterventionHandler instance. Created on first access."""

    @property
    def computation(self) -> Computation
        """The internal Computation containing all recorded events."""

    @property
    def tracker(self) -> CausalTracker
        """The CausalTracker managing event relationships."""

    def emit(self, event_type, payload, *, parent_id=None, correlation_id=None, source=None, metadata=None) -> Event
        """Create, record, and enqueue a PyRapide Event."""

    async def events(self) -> AsyncIterator[Event]
        """Yield events as they are emitted. Implements EventSource protocol."""

    async def close(self) -> None
        """Signal that no more events will be produced."""
```

## Troubleshooting

| Issue | Fix |
|---|---|
| `ImportError: autogen-core` | Run `pip install autogen-core` |
| No events captured | Ensure `runtime` is passed to `AutoGenAdapter`, or manually call `runtime.add_intervention_handler(adapter.callback_handler)` |
| Events missing causal links | Tool call events from `ToolCallRequestEvent` stream events require the adapter to see the prior LLM_RESPONSE; ensure the handler is registered before the conversation starts |
| `close()` hangs | Always `await adapter.close()` after the agent run completes to signal the event iterator to stop |
| Duplicate events | Do not register the `callback_handler` on the runtime AND pass `runtime=` to the constructor; pick one |

## Related Files

- [`agent_templates/autogen/adapter.py`](adapter.py) -- AutoGenAdapter implementation
- [`agent_templates/autogen/template.py`](template.py) -- Runnable example
- [`agent_templates/core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`agent_templates/core/event_types.py`](../core/event_types.py) -- AgentEventTypes constants
- [`agent_templates/core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker engine
- [`agent_templates/core/patterns.py`](../core/patterns.py) -- AgentPatterns library
- [`pyrapide-agent-documentation.md`](../../pyrapide-agent-documentation.md) -- Full PyRapide agent docs
