"""AutoGen + PyRapide integration template.

This runnable example shows how to instrument a standard AutoGen
multi-agent setup with PyRapide causal event tracking.

Prerequisites::

    pip install pyrapide autogen-agentchat autogen-ext[openai]

Overview
--------
AutoGen uses a runtime-based architecture where agents communicate via
message passing.  PyRapide hooks into this via an ``InterventionHandler``
that observes every ``send``, ``publish``, and ``response`` on the runtime.

The integration requires **two lines of code**:

1. Create the adapter::

       adapter = AutoGenAdapter("my-app", runtime=runtime)

2. Start producing events (happens automatically when you iterate)::

       async for event in adapter.events():
           print(event)

That's it -- all inter-agent messages and LLM responses are now tracked
with full causal lineage.
"""

from __future__ import annotations

import asyncio


async def main() -> None:
    """Run a simple AutoGen agent with PyRapide instrumentation."""

    # --- Standard AutoGen setup -------------------------------------------

    from autogen_agentchat.agents import AssistantAgent
    from autogen_agentchat.teams import RoundRobinGroupChat
    from autogen_agentchat.conditions import TextMentionTermination
    from autogen_ext.models.openai import OpenAIChatCompletionClient

    model_client = OpenAIChatCompletionClient(model="gpt-4o-mini")

    assistant = AssistantAgent(
        name="assistant",
        model_client=model_client,
        system_message=(
            "You are a helpful assistant. When you have answered the "
            "user's question completely, end your reply with TERMINATE."
        ),
    )

    termination = TextMentionTermination("TERMINATE")
    team = RoundRobinGroupChat(
        participants=[assistant],
        termination_condition=termination,
    )

    # --- PyRapide instrumentation (2 lines) --------------------------------

    from pyrapide.agent_templates.autogen import AutoGenAdapter

    adapter = AutoGenAdapter("autogen-demo")

    # --- Run the conversation ----------------------------------------------

    # Consume events in the background while the team runs.
    collected_events: list = []

    async def collect_events() -> None:
        async for event in adapter.events():
            collected_events.append(event)
            print(f"  [{event.name}] source={event.source} | {event.id[:8]}")

    event_task = asyncio.create_task(collect_events())

    # Run the team conversation
    result = await team.run(task="What are the three laws of thermodynamics?")

    # Signal the adapter that we're done
    await adapter.close()
    await event_task

    # --- Inspect results ---------------------------------------------------

    print(f"\nCollected {len(collected_events)} PyRapide events:")
    for ev in collected_events:
        meta = ev.metadata or {}
        parent = meta.get("parent_id", "root")[:8] if meta.get("parent_id") else "root"
        print(f"  {ev.name:<30} parent={parent:<10} id={ev.id[:8]}")

    # Access the full causal computation graph
    computation = adapter.computation
    print(f"\nComputation has {len(computation)} events with causal links.")


if __name__ == "__main__":
    asyncio.run(main())
