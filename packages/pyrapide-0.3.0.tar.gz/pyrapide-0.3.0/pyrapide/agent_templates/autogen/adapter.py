"""AutoGen adapter for PyRapide causal event tracking.

Hooks into an AutoGen ``SingleThreadedAgentRuntime`` via
``autogen_core.InterventionHandler`` to translate inter-agent
messages, publications, and responses into unified PyRapide events.

All framework imports are lazy (inside methods) so this module can be
imported even when ``autogen_core`` is not installed.
"""

from __future__ import annotations

import logging
from typing import Any

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)


class AutoGenAdapter(BaseAgentAdapter):
    """Instrument an AutoGen runtime with PyRapide causal tracking.

    Parameters
    ----------
    name:
        Human-readable adapter name (appears in event ``source`` fields).
    runtime:
        An ``autogen_core.SingleThreadedAgentRuntime`` instance.  If
        provided, the intervention handler is registered automatically
        when ``_install_hooks()`` runs.  You can also retrieve the
        handler via ``callback_handler`` and register it yourself.

    Example::

        from autogen_core import SingleThreadedAgentRuntime
        from pyrapide.agent_templates.autogen import AutoGenAdapter

        runtime = SingleThreadedAgentRuntime()
        adapter = AutoGenAdapter("demo", runtime=runtime)
        # hooks are installed lazily on first iteration, or:
        adapter._install_hooks()
    """

    def __init__(self, name: str, runtime: Any | None = None) -> None:
        super().__init__(name, framework_instance=runtime)
        self._handler: Any | None = None

    # -- Public API --------------------------------------------------------

    @property
    def callback_handler(self) -> Any:
        """Return the ``InterventionHandler`` instance.

        Creates the handler on first access so it can be used even when
        hooks have not been formally installed (e.g. manual registration
        on a runtime).
        """
        if self._handler is None:
            self._handler = self._create_handler()
        return self._handler

    # -- Hook installation -------------------------------------------------

    def _install_hooks(self) -> None:
        """Create and register the intervention handler on the runtime.

        If no runtime was passed at construction time, the handler is
        still created and available via ``callback_handler`` for manual
        registration.
        """
        handler = self.callback_handler  # ensures creation

        runtime = self._framework_instance
        if runtime is not None:
            try:
                runtime.add_intervention_handler(handler)
                logger.info(
                    "PyRapide: registered AutoGen InterventionHandler on %s",
                    type(runtime).__name__,
                )
            except Exception:
                logger.exception(
                    "PyRapide: failed to register InterventionHandler"
                )
        else:
            logger.debug(
                "PyRapide: no runtime provided; use adapter.callback_handler "
                "to register the InterventionHandler manually."
            )

    def _uninstall_hooks(self) -> None:
        """Best-effort removal of the intervention handler."""
        runtime = self._framework_instance
        if runtime is not None and self._handler is not None:
            try:
                if hasattr(runtime, "remove_intervention_handler"):
                    runtime.remove_intervention_handler(self._handler)
            except Exception:
                logger.debug("PyRapide: could not remove intervention handler")
        self._handler = None

    # -- Internal ----------------------------------------------------------

    def _create_handler(self) -> Any:
        """Build an ``InterventionHandler`` subclass bound to this adapter.

        The import of ``autogen_core`` happens here (lazy) so that the
        module can be imported without requiring the framework.
        """
        try:
            from autogen_core import InterventionHandler
        except ImportError as exc:
            raise ImportError(
                "AutoGenAdapter requires the 'autogen-core' package. "
                "Install it with: pip install autogen-core"
            ) from exc

        adapter = self  # capture for inner class

        class _PyRapideInterventionHandler(InterventionHandler):
            """Translates AutoGen runtime events into PyRapide events."""

            async def on_send(
                self,
                message: Any,
                *,
                sender: Any,
                recipient: Any,
            ) -> Any:
                """Intercept direct agent-to-agent sends."""
                adapter.emit(
                    AgentEventTypes.AGENT_MESSAGE,
                    {
                        "framework": "autogen",
                        "framework_event_type": "send",
                        "sender": _agent_id(sender),
                        "recipient": _agent_id(recipient),
                        "message_type": type(message).__name__,
                        "message": _safe_repr(message),
                    },
                    source=_agent_id(sender),
                )
                return message

            async def on_publish(
                self,
                message: Any,
                *,
                sender: Any,
            ) -> Any:
                """Intercept topic publications."""
                adapter.emit(
                    AgentEventTypes.AGENT_MESSAGE,
                    {
                        "framework": "autogen",
                        "framework_event_type": "publish",
                        "sender": _agent_id(sender),
                        "message_type": type(message).__name__,
                        "message": _safe_repr(message),
                    },
                    source=_agent_id(sender),
                )
                return message

            async def on_response(
                self,
                message: Any,
                *,
                sender: Any,
                recipient: Any,
            ) -> Any:
                """Intercept responses flowing back to the caller."""
                adapter.emit(
                    AgentEventTypes.LLM_RESPONSE,
                    {
                        "framework": "autogen",
                        "framework_event_type": "response",
                        "sender": _agent_id(sender),
                        "recipient": _agent_id(recipient),
                        "message_type": type(message).__name__,
                        "message": _safe_repr(message),
                    },
                    source=_agent_id(sender),
                )
                return message

        return _PyRapideInterventionHandler()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _agent_id(agent: Any) -> str:
    """Extract a stable string identifier from an AutoGen agent or AgentId."""
    if hasattr(agent, "key"):
        return str(agent.key)
    if hasattr(agent, "type"):
        return str(agent.type)
    return str(agent)


def _safe_repr(obj: Any, max_len: int = 500) -> str:
    """Return a truncated repr that won't blow up event payloads."""
    try:
        text = repr(obj)
    except Exception:
        text = f"<{type(obj).__name__}>"
    if len(text) > max_len:
        return text[: max_len - 3] + "..."
    return text
