"""Bidirectional result translation between PyRapide analysis and framework-native formats.

Provides generic analysis methods that work for any framework, plus
extension points for framework-specific output formats.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from pyrapide.analysis import queries, visualization
from pyrapide.core.computation import Computation
from pyrapide.core.event import Event


@dataclass
class AnalysisResult:
    """Structured result of a PyRapide causal analysis."""

    computation: Computation
    target_event: Event | None = None
    root_causes: frozenset[Event] = field(default_factory=frozenset)
    causal_chain: list[Event] | None = None
    critical_path: list[Event] = field(default_factory=list)
    bottlenecks: list[Event] = field(default_factory=list)
    parallel_groups: list[frozenset[Event]] = field(default_factory=list)
    event_frequency: dict[str, int] = field(default_factory=dict)
    causal_density: float = 0.0

    # -- Generic output formats ------------------------------------------------

    def as_dict(self) -> dict[str, Any]:
        """Plain Python dict representation."""
        result: dict[str, Any] = {
            "event_count": len(self.computation),
            "causal_density": self.causal_density,
            "event_frequency": self.event_frequency,
            "critical_path": [
                {"name": e.name, "source": e.source, "id": e.id}
                for e in self.critical_path
            ],
            "bottlenecks": [
                {"name": e.name, "source": e.source, "id": e.id}
                for e in self.bottlenecks
            ],
            "parallel_group_count": len(self.parallel_groups),
        }
        if self.target_event is not None:
            result["target"] = {
                "name": self.target_event.name,
                "source": self.target_event.source,
                "id": self.target_event.id,
            }
            result["root_causes"] = [
                {"name": e.name, "source": e.source, "id": e.id}
                for e in self.root_causes
            ]
        if self.causal_chain is not None:
            result["causal_chain"] = [
                {"name": e.name, "source": e.source, "id": e.id}
                for e in self.causal_chain
            ]
        return result

    def as_markdown(self) -> str:
        """Human-readable markdown summary."""
        lines = ["# PyRapide Causal Analysis\n"]
        lines.append(f"**Events:** {len(self.computation)}")
        lines.append(f"**Causal density:** {self.causal_density:.3f}\n")

        if self.critical_path:
            lines.append("## Critical Path")
            lines.append(" -> ".join(f"`{e.name}`" for e in self.critical_path))
            lines.append("")

        if self.target_event and self.root_causes:
            lines.append(f"## Root Causes of `{self.target_event.name}`")
            for e in self.root_causes:
                lines.append(f"- `{e.name}` ({e.source})")
            lines.append("")

        if self.causal_chain:
            lines.append("## Causal Chain")
            for i, e in enumerate(self.causal_chain):
                prefix = "  " * i + ("-> " if i > 0 else "")
                lines.append(f"{prefix}`{e.name}` ({e.source})")
            lines.append("")

        if self.bottlenecks:
            lines.append("## Bottleneck Events")
            for e in self.bottlenecks:
                lines.append(f"- `{e.name}` ({e.source})")
            lines.append("")

        if self.event_frequency:
            lines.append("## Event Frequency")
            for name, count in sorted(self.event_frequency.items(), key=lambda x: -x[1]):
                lines.append(f"- `{name}`: {count}")

        return "\n".join(lines)

    def as_dot(self) -> str:
        """Graphviz DOT representation of the computation."""
        highlight = set()
        if self.target_event:
            highlight = {self.target_event} | self.root_causes
        return visualization.to_dot(self.computation, highlight=highlight)


class ResultBridge:
    """Runs standard PyRapide analysis and returns structured results.

    Use directly for generic analysis, or subclass in framework-specific
    adapters to add ``as_langgraph_state()``, ``as_autogen_message()``, etc.
    """

    def analyze(
        self,
        computation: Computation,
        target: Event | None = None,
    ) -> AnalysisResult:
        """Run a comprehensive causal analysis.

        Parameters
        ----------
        computation:
            The computation to analyze.
        target:
            Optional target event for root-cause and chain analysis.
        """
        root_causes = frozenset[Event]()
        causal_chain: list[Event] | None = None

        if target is not None:
            root_causes = queries.root_causes(computation, target)
            # Find chain from earliest root to target
            if root_causes:
                for root in root_causes:
                    chain = computation.causal_chain(root, target)
                    if chain is not None:
                        if causal_chain is None or len(chain) > len(causal_chain):
                            causal_chain = chain

        return AnalysisResult(
            computation=computation,
            target_event=target,
            root_causes=root_causes,
            causal_chain=causal_chain,
            critical_path=queries.critical_path(computation),
            bottlenecks=queries.bottleneck_events(computation),
            parallel_groups=queries.parallel_events(computation),
            event_frequency=queries.event_frequency(computation),
            causal_density=queries.causal_density(computation),
        )
