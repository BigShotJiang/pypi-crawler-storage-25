"""Core abstractions for PyRapide agentic framework integration.

This module provides the unified event taxonomy, causal tracking engine,
abstract adapter base class, pattern library, and result bridge that all
framework-specific adapters build on.
"""

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.causal_tracker import CausalTracker
from pyrapide.agent_templates.core.event_types import ALL_EVENT_TYPES, AgentEventTypes
from pyrapide.agent_templates.core.patterns import AgentPatterns
from pyrapide.agent_templates.core.result_bridge import AnalysisResult, ResultBridge

__all__ = [
    "AgentEventTypes",
    "ALL_EVENT_TYPES",
    "BaseAgentAdapter",
    "CausalTracker",
    "AgentPatterns",
    "AnalysisResult",
    "ResultBridge",
]
