"""Abstract base class for all framework adapters.

Implements the ``EventSource`` protocol so that any adapter can be plugged
directly into ``StreamProcessor.add_source()``.  Subclasses override
``_install_hooks()`` to wire into their framework's observability system
and call ``self.emit()`` to produce PyRapide events.
"""

from __future__ import annotations

import asyncio
from typing import Any, AsyncIterator

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event

from pyrapide.agent_templates.core.causal_tracker import CausalTracker
from pyrapide.agent_templates.core.event_types import ALL_EVENT_TYPES


class BaseAgentAdapter:
    """Abstract base for all agentic framework adapters.

    Implements the ``EventSource`` protocol (``name`` property + ``events()``
    async iterator) so it can be used directly with ``StreamProcessor``.

    Subclasses must override ``_install_hooks()`` to register listeners
    within their framework.  From those listeners, call ``self.emit()``
    to translate framework events into PyRapide events.

    Example usage (from any adapter)::

        adapter = SomeFrameworkAdapter("my-app", framework_instance=obj)
        processor = StreamProcessor()
        processor.add_source("framework", adapter)
        await processor.run()
    """

    def __init__(self, name: str, framework_instance: Any = None) -> None:
        self._name = name
        self._framework_instance = framework_instance
        self._tracker = CausalTracker()
        self._queue: asyncio.Queue[Event | None] = asyncio.Queue()
        self._hooks_installed = False

    # -- EventSource protocol --------------------------------------------------

    @property
    def name(self) -> str:
        """Source name used by ``StreamProcessor`` for stats and identification."""
        return self._name

    async def events(self) -> AsyncIterator[Event]:
        """Yield events as they are emitted.  Implements the ``EventSource`` protocol."""
        if not self._hooks_installed:
            self._install_hooks()
            self._hooks_installed = True

        while True:
            item = await self._queue.get()
            if item is None:
                break
            yield item

    # -- Public API ------------------------------------------------------------

    @property
    def tracker(self) -> CausalTracker:
        """The causal tracker managing event relationships."""
        return self._tracker

    @property
    def computation(self) -> Computation:
        """Shortcut to the tracker's internal computation."""
        return self._tracker.computation

    def emit(
        self,
        event_type: str,
        payload: dict[str, Any],
        *,
        parent_id: str | None = None,
        correlation_id: str | None = None,
        source: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Event:
        """Create a PyRapide Event, register it with the causal tracker, and enqueue it.

        Parameters
        ----------
        event_type:
            One of the ``AgentEventTypes`` constants.
        payload:
            Framework-specific data.  Should always include ``framework`` and
            ``framework_event_type`` keys for traceability.
        parent_id:
            Explicit parent event ID (if the framework provides one).
        correlation_id:
            Shared ID linking related events (request/response pairs).
        source:
            Override the event source (defaults to ``self.name``).
        metadata:
            Additional metadata dict merged into the event.
        """
        if event_type not in ALL_EVENT_TYPES:
            raise ValueError(
                f"Unknown event type {event_type!r}. "
                f"Use AgentEventTypes constants."
            )

        meta: dict[str, Any] = {}
        if correlation_id:
            meta["correlation_id"] = correlation_id
        if parent_id:
            meta["parent_id"] = parent_id
        if metadata:
            meta.update(metadata)

        event = Event(
            name=event_type,
            payload=payload,
            source=source or self._name,
            metadata=meta,
        )

        # Register in the causal tracker
        self._tracker.record(event, parent_id=parent_id, correlation_id=correlation_id)

        # Enqueue for the EventSource consumer
        self._queue.put_nowait(event)

        return event

    def emit_scope_start(
        self,
        event_type: str,
        payload: dict[str, Any],
        **kwargs: Any,
    ) -> Event:
        """Emit an event and push it as the current scope.

        Use for ``RUN_START``, ``TASK_START``, ``STEP_START``.
        """
        event = self.emit(event_type, payload, **kwargs)
        self._tracker.push_scope(event)
        return event

    def emit_scope_end(
        self,
        event_type: str,
        payload: dict[str, Any],
        **kwargs: Any,
    ) -> Event:
        """Pop the current scope and emit the end event.

        Use for ``RUN_END``, ``TASK_END``, ``STEP_END``.
        """
        self._tracker.pop_scope()
        return self.emit(event_type, payload, **kwargs)

    async def close(self) -> None:
        """Signal that no more events will be produced."""
        if self._hooks_installed:
            self._uninstall_hooks()
            self._hooks_installed = False
        await self._queue.put(None)

    # -- Subclass hooks --------------------------------------------------------

    def _install_hooks(self) -> None:
        """Install framework-specific listeners/callbacks.

        Override in subclasses.  Call ``self.emit()`` from within
        the installed listeners to translate framework events.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement _install_hooks()"
        )

    def _uninstall_hooks(self) -> None:
        """Remove previously installed hooks.  Override in subclasses."""
        pass
