"""Pre-built pattern library for common agentic event patterns.

Mirrors ``MCPPatterns`` from ``pyrapide.integrations.mcp`` but uses
the unified ``AgentEventTypes`` taxonomy so patterns work across all
framework adapters.
"""

from __future__ import annotations

from pyrapide.patterns.base import Pattern

from pyrapide.agent_templates.core.event_types import AgentEventTypes


class AgentPatterns:
    """Pre-built pattern library for agentic systems.

    Every method returns a composable ``Pattern`` that can be used with
    ``StreamProcessor.watch()``, ``StreamProcessor.enforce()``,
    ``must_match()``, ``never()``, or any PyRapide pattern operator.
    """

    # -- Tool patterns ---------------------------------------------------------

    @staticmethod
    def tool_call(tool_name: str | None = None) -> Pattern:
        """Match any tool call, optionally filtered by tool name."""
        if tool_name is not None:
            return Pattern.match(AgentEventTypes.TOOL_CALL, tool_name=tool_name)
        return Pattern.match(AgentEventTypes.TOOL_CALL)

    @staticmethod
    def tool_result(tool_name: str | None = None) -> Pattern:
        """Match any tool result, optionally filtered by tool name."""
        if tool_name is not None:
            return Pattern.match(AgentEventTypes.TOOL_RESULT, tool_name=tool_name)
        return Pattern.match(AgentEventTypes.TOOL_RESULT)

    @staticmethod
    def tool_error(tool_name: str | None = None) -> Pattern:
        """Match any tool error, optionally filtered by tool name."""
        if tool_name is not None:
            return Pattern.match(AgentEventTypes.TOOL_ERROR, tool_name=tool_name)
        return Pattern.match(AgentEventTypes.TOOL_ERROR)

    @staticmethod
    def tool_roundtrip(tool_name: str | None = None) -> Pattern:
        """Match a tool_call >> tool_result sequence."""
        return AgentPatterns.tool_call(tool_name) >> AgentPatterns.tool_result(tool_name)

    @staticmethod
    def tool_error_after_call(tool_name: str | None = None) -> Pattern:
        """Match a tool_call >> tool_error sequence."""
        return AgentPatterns.tool_call(tool_name) >> AgentPatterns.tool_error(tool_name)

    # -- LLM patterns ----------------------------------------------------------

    @staticmethod
    def llm_request() -> Pattern:
        """Match any LLM request."""
        return Pattern.match(AgentEventTypes.LLM_REQUEST)

    @staticmethod
    def llm_response() -> Pattern:
        """Match any LLM response."""
        return Pattern.match(AgentEventTypes.LLM_RESPONSE)

    @staticmethod
    def llm_error() -> Pattern:
        """Match any LLM error."""
        return Pattern.match(AgentEventTypes.LLM_ERROR)

    @staticmethod
    def llm_roundtrip() -> Pattern:
        """Match an llm_request >> llm_response sequence."""
        return AgentPatterns.llm_request() >> AgentPatterns.llm_response()

    # -- Composite lifecycle patterns ------------------------------------------

    @staticmethod
    def full_tool_lifecycle() -> Pattern:
        """Match the full agent tool-use cycle: llm_request >> tool_call >> tool_result >> llm_response."""
        return (
            AgentPatterns.llm_request()
            >> AgentPatterns.tool_call()
            >> AgentPatterns.tool_result()
            >> AgentPatterns.llm_response()
        )

    # -- Agent communication patterns ------------------------------------------

    @staticmethod
    def agent_handoff() -> Pattern:
        """Match any agent handoff event."""
        return Pattern.match(AgentEventTypes.AGENT_HANDOFF)

    @staticmethod
    def handoff_chain() -> Pattern:
        """Match two consecutive handoffs (multi-hop delegation)."""
        return AgentPatterns.agent_handoff() >> AgentPatterns.agent_handoff()

    @staticmethod
    def agent_message() -> Pattern:
        """Match any agent message."""
        return Pattern.match(AgentEventTypes.AGENT_MESSAGE)

    # -- Scope patterns --------------------------------------------------------

    @staticmethod
    def agent_step() -> Pattern:
        """Match a step_start >> step_end sequence."""
        return Pattern.match(AgentEventTypes.STEP_START) >> Pattern.match(AgentEventTypes.STEP_END)

    @staticmethod
    def task_lifecycle() -> Pattern:
        """Match a task_start >> task_end sequence."""
        return Pattern.match(AgentEventTypes.TASK_START) >> Pattern.match(AgentEventTypes.TASK_END)

    @staticmethod
    def run_lifecycle() -> Pattern:
        """Match a run_start >> run_end sequence."""
        return Pattern.match(AgentEventTypes.RUN_START) >> Pattern.match(AgentEventTypes.RUN_END)

    # -- Error patterns --------------------------------------------------------

    @staticmethod
    def any_error() -> Pattern:
        """Match any error event (tool, LLM, or task)."""
        return (
            AgentPatterns.tool_error()
            .or_(AgentPatterns.llm_error())
            .or_(Pattern.match(AgentEventTypes.TASK_ERROR))
        )

    @staticmethod
    def error_cascade() -> Pattern:
        """Match any error causally preceded by another error."""
        return AgentPatterns.any_error() >> AgentPatterns.any_error()
