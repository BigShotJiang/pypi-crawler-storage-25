"""Automatic causal linking engine for agentic framework events.

Tracks causal relationships between events using three complementary mechanisms:

1. **Explicit parent_id** — caller specifies which event caused this one
2. **Correlation groups** — events sharing a correlation_id are auto-linked
3. **Scope stack** — nested scopes (run > task > step) auto-parent child events

Also applies heuristic rules for sequential causality within a scope:
- TOOL_CALL is caused by the most recent LLM_RESPONSE (LLM decided to call)
- LLM_REQUEST after a tool is caused by the most recent TOOL_RESULT
- AGENT_HANDOFF is caused by the most recent LLM_RESPONSE
"""

from __future__ import annotations

from typing import Any

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event

from pyrapide.agent_templates.core.event_types import AgentEventTypes


class CausalTracker:
    """Tracks causal relationships between events across agentic frameworks.

    This is the core engine that all framework adapters delegate to. It
    maintains an internal ``Computation`` and provides three causal-linking
    mechanisms to handle the full spectrum of framework observability levels.
    """

    def __init__(self) -> None:
        self._computation = Computation()
        self._correlation_groups: dict[str, list[Event]] = {}
        self._scope_stack: list[Event] = []
        self._events_by_id: dict[str, Event] = {}
        self._last_by_type: dict[str, Event] = {}

    @property
    def computation(self) -> Computation:
        """The internal computation containing all recorded events."""
        return self._computation

    def record(
        self,
        event: Event,
        parent_id: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        """Record an event with automatic causal linking.

        Determines causal parents using this priority order:

        1. Explicit ``parent_id`` (if provided and known)
        2. Correlation group (if ``correlation_id`` matches a previous event)
        3. Inferred sequential cause (heuristic based on event type)
        4. Current scope (if a scope is active and no other parent found)
        """
        self._events_by_id[event.id] = event
        caused_by: list[Event] = []

        # Mechanism 1: explicit parent
        if parent_id and parent_id in self._events_by_id:
            caused_by.append(self._events_by_id[parent_id])

        # Mechanism 2: correlation group
        if correlation_id:
            group = self._correlation_groups.get(correlation_id)
            if group:
                # Link to the first (root) event in the correlation group
                if not caused_by:
                    caused_by.append(group[0])
                group.append(event)
            else:
                self._correlation_groups[correlation_id] = [event]

        # Mechanism 3: inferred sequential causality (if no explicit link yet)
        if not caused_by:
            inferred = self._infer_parent(event)
            if inferred is not None:
                caused_by.append(inferred)

        # Mechanism 4: scope stack fallback
        if not caused_by and self._scope_stack:
            caused_by.append(self._scope_stack[-1])

        self._computation.record(event, caused_by=caused_by or None)
        self._last_by_type[event.name] = event

    def push_scope(self, event: Event) -> None:
        """Push a scope event onto the stack.

        All subsequent events without an explicit parent will be parented
        to this scope event. Used for RUN_START, TASK_START, STEP_START.
        """
        self._scope_stack.append(event)

    def pop_scope(self) -> Event | None:
        """Pop the current scope and return it, or None if stack is empty."""
        if self._scope_stack:
            return self._scope_stack.pop()
        return None

    @property
    def current_scope(self) -> Event | None:
        """The currently active scope event, or None."""
        return self._scope_stack[-1] if self._scope_stack else None

    def reset(self) -> None:
        """Clear all internal state."""
        self._computation = Computation()
        self._correlation_groups.clear()
        self._scope_stack.clear()
        self._events_by_id.clear()
        self._last_by_type.clear()

    def _infer_parent(self, event: Event) -> Event | None:
        """Apply heuristic rules to infer a causal parent.

        Rules:
        - TOOL_CALL <- most recent LLM_RESPONSE (LLM decided to invoke tool)
        - LLM_REQUEST <- most recent TOOL_RESULT (re-inference after tool)
        - AGENT_HANDOFF <- most recent LLM_RESPONSE (LLM decided to hand off)
        - TOOL_ERROR <- most recent TOOL_CALL (error from the call)
        """
        name = event.name

        if name == AgentEventTypes.TOOL_CALL:
            return self._last_by_type.get(AgentEventTypes.LLM_RESPONSE)

        if name == AgentEventTypes.LLM_REQUEST:
            # Prefer TOOL_RESULT as parent (re-inference), fall back to TOOL_ERROR
            return (
                self._last_by_type.get(AgentEventTypes.TOOL_RESULT)
                or self._last_by_type.get(AgentEventTypes.TOOL_ERROR)
            )

        if name == AgentEventTypes.AGENT_HANDOFF:
            return self._last_by_type.get(AgentEventTypes.LLM_RESPONSE)

        if name == AgentEventTypes.TOOL_ERROR:
            return self._last_by_type.get(AgentEventTypes.TOOL_CALL)

        return None
