"""Unified event type constants for all agentic AI frameworks.

These constants normalize the diverse event vocabularies of AutoGen, LangGraph,
CrewAI, LlamaIndex, Agno, OpenAI Swarm, MetaGPT, and FlowiseAI into a single
taxonomy that PyRapide can pattern-match against.
"""


class AgentEventTypes:
    """Unified event type constants for agentic framework integration.

    Naming convention: ``agent.<category>.<action>``

    Every framework adapter emits events using only these constants,
    regardless of the framework's native event vocabulary.
    """

    # Tool lifecycle
    TOOL_CALL = "agent.tool.call"
    TOOL_RESULT = "agent.tool.result"
    TOOL_ERROR = "agent.tool.error"

    # LLM lifecycle
    LLM_REQUEST = "agent.llm.request"
    LLM_RESPONSE = "agent.llm.response"
    LLM_STREAM = "agent.llm.stream_chunk"
    LLM_ERROR = "agent.llm.error"

    # Agent communication
    AGENT_MESSAGE = "agent.message.send"
    AGENT_HANDOFF = "agent.handoff"

    # Task lifecycle
    TASK_START = "agent.task.start"
    TASK_END = "agent.task.end"
    TASK_ERROR = "agent.task.error"

    # Agent loop (single iteration)
    STEP_START = "agent.step.start"
    STEP_END = "agent.step.end"

    # Run lifecycle (full execution)
    RUN_START = "agent.run.start"
    RUN_END = "agent.run.end"


# All event type strings for validation
ALL_EVENT_TYPES: frozenset[str] = frozenset(
    v for k, v in vars(AgentEventTypes).items()
    if not k.startswith("_") and isinstance(v, str)
)
