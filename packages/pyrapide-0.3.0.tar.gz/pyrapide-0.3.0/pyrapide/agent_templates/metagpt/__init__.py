"""PyRapide adapter for MetaGPT.

Provides ``MetaGPTAdapter`` which monkey-patches MetaGPT's ``Role``,
``Action``, and ``Environment`` classes to emit causal events for every
agent step, action execution, and message publication.

Usage::

    from pyrapide.agent_templates.metagpt import MetaGPTAdapter

    adapter = MetaGPTAdapter("my-metagpt-app").patch()
"""

from pyrapide.agent_templates.metagpt.adapter import MetaGPTAdapter

__all__ = ["MetaGPTAdapter"]
