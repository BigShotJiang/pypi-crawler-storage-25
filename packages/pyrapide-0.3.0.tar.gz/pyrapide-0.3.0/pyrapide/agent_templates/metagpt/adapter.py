"""MetaGPT adapter for PyRapide causal event tracking.

Hooks into MetaGPT by monkey-patching ``Role.run``, ``Action.run``, and
``Environment.publish_message`` to translate agent steps, action executions,
and inter-agent messages into unified PyRapide events.

All framework imports are lazy (inside methods) so this module can be
imported even when ``metagpt`` is not installed.
"""

from __future__ import annotations

import logging
import uuid
from typing import Any

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)


class MetaGPTAdapter(BaseAgentAdapter):
    """Instrument a MetaGPT application with PyRapide causal tracking.

    The adapter works by monkey-patching core MetaGPT classes so that
    every role step, action execution, and environment message is recorded
    as a PyRapide event with full causal lineage.

    Parameters
    ----------
    name:
        Human-readable adapter name (appears in event ``source`` fields).

    Example::

        from pyrapide.agent_templates.metagpt import MetaGPTAdapter

        adapter = MetaGPTAdapter("demo").patch()

        # ... run your MetaGPT roles/environment ...

        comp = adapter.computation
        print(f"Captured {len(comp)} events")

        # Restore originals when done
        adapter.unpatch()
    """

    def __init__(self, name: str) -> None:
        super().__init__(name, framework_instance=None)
        self._original_role_run: Any | None = None
        self._original_action_run: Any | None = None
        self._original_env_publish: Any | None = None
        self._patched = False

    # -- Public API --------------------------------------------------------

    def patch(self) -> MetaGPTAdapter:
        """Monkey-patch MetaGPT classes to emit PyRapide events.

        Returns ``self`` for chaining::

            adapter = MetaGPTAdapter("demo").patch()

        Raises
        ------
        ImportError
            If ``metagpt`` is not installed.
        """
        if self._patched:
            return self

        try:
            from metagpt.roles.role import Role
            from metagpt.actions.action import Action
            from metagpt.environment import Environment
        except ImportError as exc:
            raise ImportError(
                "MetaGPTAdapter requires the 'metagpt' package. "
                "Install it with: pip install metagpt"
            ) from exc

        # Save originals
        self._original_role_run = Role.run
        self._original_action_run = Action.run
        self._original_env_publish = Environment.publish_message

        adapter = self

        # --- Wrap Role.run ---------------------------------------------------

        async def _wrapped_role_run(role_self: Any, *args: Any, **kwargs: Any) -> Any:
            role_name = getattr(role_self, "name", type(role_self).__name__)
            correlation = str(uuid.uuid4())

            adapter.emit_scope_start(
                AgentEventTypes.STEP_START,
                {
                    "framework": "metagpt",
                    "framework_event_type": "role.run.start",
                    "role_name": role_name,
                    "role_class": type(role_self).__name__,
                },
                correlation_id=correlation,
                source=role_name,
            )

            try:
                result = await adapter._original_role_run(role_self, *args, **kwargs)
            except Exception:
                adapter.emit_scope_end(
                    AgentEventTypes.STEP_END,
                    {
                        "framework": "metagpt",
                        "framework_event_type": "role.run.error",
                        "role_name": role_name,
                        "error": True,
                    },
                    correlation_id=correlation,
                    source=role_name,
                )
                raise

            adapter.emit_scope_end(
                AgentEventTypes.STEP_END,
                {
                    "framework": "metagpt",
                    "framework_event_type": "role.run.end",
                    "role_name": role_name,
                },
                correlation_id=correlation,
                source=role_name,
            )
            return result

        Role.run = _wrapped_role_run  # type: ignore[assignment]

        # --- Wrap Action.run -------------------------------------------------

        async def _wrapped_action_run(action_self: Any, *args: Any, **kwargs: Any) -> Any:
            action_name = getattr(action_self, "name", type(action_self).__name__)
            correlation = str(uuid.uuid4())

            adapter.emit(
                AgentEventTypes.TOOL_CALL,
                {
                    "framework": "metagpt",
                    "framework_event_type": "action.run.start",
                    "tool_name": action_name,
                    "action_class": type(action_self).__name__,
                    "args": _safe_repr(args),
                    "kwargs": _safe_repr(kwargs),
                },
                correlation_id=correlation,
                source=action_name,
            )

            try:
                result = await adapter._original_action_run(action_self, *args, **kwargs)
            except Exception as exc:
                adapter.emit(
                    AgentEventTypes.TOOL_ERROR,
                    {
                        "framework": "metagpt",
                        "framework_event_type": "action.run.error",
                        "tool_name": action_name,
                        "action_class": type(action_self).__name__,
                        "error": str(exc),
                        "error_type": type(exc).__name__,
                    },
                    correlation_id=correlation,
                    source=action_name,
                )
                raise

            adapter.emit(
                AgentEventTypes.TOOL_RESULT,
                {
                    "framework": "metagpt",
                    "framework_event_type": "action.run.end",
                    "tool_name": action_name,
                    "action_class": type(action_self).__name__,
                    "result": _safe_repr(result),
                },
                correlation_id=correlation,
                source=action_name,
            )
            return result

        Action.run = _wrapped_action_run  # type: ignore[assignment]

        # --- Wrap Environment.publish_message --------------------------------

        def _wrapped_env_publish(env_self: Any, message: Any, *args: Any, **kwargs: Any) -> Any:
            sender = _extract_sender(message)
            adapter.emit(
                AgentEventTypes.AGENT_MESSAGE,
                {
                    "framework": "metagpt",
                    "framework_event_type": "environment.publish_message",
                    "sender": sender,
                    "message_type": type(message).__name__,
                    "message": _safe_repr(message),
                },
                source=sender,
            )
            return adapter._original_env_publish(env_self, message, *args, **kwargs)

        Environment.publish_message = _wrapped_env_publish  # type: ignore[assignment]

        self._patched = True
        logger.info("PyRapide: patched MetaGPT Role, Action, and Environment")
        return self

    def unpatch(self) -> None:
        """Restore the original MetaGPT methods.

        Safe to call multiple times or when not patched.
        """
        if not self._patched:
            return

        try:
            from metagpt.roles.role import Role
            from metagpt.actions.action import Action
            from metagpt.environment import Environment
        except ImportError:
            self._patched = False
            return

        if self._original_role_run is not None:
            Role.run = self._original_role_run  # type: ignore[assignment]
        if self._original_action_run is not None:
            Action.run = self._original_action_run  # type: ignore[assignment]
        if self._original_env_publish is not None:
            Environment.publish_message = self._original_env_publish  # type: ignore[assignment]

        self._patched = False
        self._original_role_run = None
        self._original_action_run = None
        self._original_env_publish = None
        logger.info("PyRapide: restored original MetaGPT methods")

    # -- Hook installation (BaseAgentAdapter interface) --------------------

    def _install_hooks(self) -> None:
        """Install hooks by patching MetaGPT classes."""
        self.patch()

    def _uninstall_hooks(self) -> None:
        """Remove hooks by restoring original methods."""
        self.unpatch()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_sender(message: Any) -> str:
    """Extract a sender identifier from a MetaGPT Message object."""
    if hasattr(message, "role"):
        return str(message.role)
    if hasattr(message, "sent_from"):
        return str(message.sent_from)
    return "unknown"


def _safe_repr(obj: Any, max_len: int = 500) -> str:
    """Return a truncated repr that won't blow up event payloads."""
    try:
        text = repr(obj)
    except Exception:
        text = f"<{type(obj).__name__}>"
    if len(text) > max_len:
        return text[: max_len - 3] + "..."
    return text
