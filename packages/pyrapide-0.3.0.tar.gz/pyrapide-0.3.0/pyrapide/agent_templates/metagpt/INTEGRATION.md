# PyRapide + MetaGPT Integration

> Causal event tracking for MetaGPT via monkey-patching Role.run, Action.run, and Environment.publish_message.

**Docs:** [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) | **Siblings:** [agno](../agno/INTEGRATION.md) | [swarm](../swarm/INTEGRATION.md) | [flowise](../flowise/INTEGRATION.md)

---

## Quick Start

```python
from pyrapide.agent_templates.metagpt import MetaGPTAdapter

adapter = MetaGPTAdapter("metagpt").patch()

# All Role steps, Action executions, and Environment messages are now tracked.
# Run your MetaGPT roles/environment as usual -- events captured automatically.

# When done, restore originals:
adapter.unpatch()

# Analyze causal graph
comp = adapter.computation
for event in comp.events:
    print(event.name, event.payload)
```

---

## Prerequisites

```bash
pip install pyrapide metagpt
```

---

## How It Works

MetaGPTAdapter uses monkey-patching to intercept three core MetaGPT methods at the class level. `Role.run()` is wrapped to emit `STEP_START`/`STEP_END` scope events for each role execution. `Action.run()` is wrapped to emit `TOOL_CALL`/`TOOL_RESULT` (or `TOOL_ERROR` on exception) for each action. `Environment.publish_message()` is wrapped to emit `AGENT_MESSAGE` for every inter-role message.

Calling `.patch()` installs all three patches and returns `self` for chaining. Calling `.unpatch()` restores the original methods. The adapter saves references to the originals, so patching and unpatching is safe to repeat. All patches are global (class-level), meaning every Role, Action, and Environment instance in the process is instrumented.

---

## Event Mapping

| MetaGPT Method | PyRapide Event | Causal Link |
|---|---|---|
| `Role.run()` entry | `agent.step.start` | Scope push -- becomes parent of nested action events |
| `Role.run()` exit | `agent.step.end` | Scope pop -- closes the role step scope |
| `Action.run()` entry | `agent.tool.call` | Child of current role scope |
| `Action.run()` exit (success) | `agent.tool.result` | Child of current role scope, correlated to its TOOL_CALL |
| `Action.run()` exit (exception) | `agent.tool.error` | Child of current role scope, correlated to its TOOL_CALL |
| `Environment.publish_message()` | `agent.message.send` | Child of current scope; captures sender from message |

---

## Full Example

```python
import asyncio
from metagpt.roles.role import Role
from metagpt.actions.action import Action
from metagpt.environment import Environment
from metagpt.schema import Message
from pyrapide.agent_templates.metagpt import MetaGPTAdapter
from pyrapide import queries

class WriteCode(Action):
    name: str = "WriteCode"
    async def run(self, instruction: str, **kwargs):
        return f"def solve(): return 42  # from: {instruction}"

class ReviewCode(Action):
    name: str = "ReviewCode"
    async def run(self, code: str, **kwargs):
        return f"LGTM: {code[:50]}"

class Coder(Role):
    name: str = "Coder"
    actions: list = [WriteCode]

class Reviewer(Role):
    name: str = "Reviewer"
    actions: list = [ReviewCode]

async def main():
    adapter = MetaGPTAdapter("metagpt-demo").patch()

    env = Environment()
    coder = Coder()
    reviewer = Reviewer()
    env.add_roles([coder, reviewer])

    env.publish_message(Message(content="Write a sorting function", role="User"))

    # Run roles (events captured automatically via patches)
    await coder.run()
    await reviewer.run()

    # Analyze
    comp = adapter.computation
    print(f"Captured {len(comp.events)} events")
    for ev in comp.events:
        print(f"  {ev.name}: {ev.payload.get('framework_event_type')}")

    # Trace causal chain from last event
    if comp.events:
        chain = queries.causal_chain(comp, comp.events[-1])
        print("\nCausal chain:")
        for step in chain:
            print(f"  <- {step.name} ({step.source})")

    adapter.unpatch()
    await adapter.close()

asyncio.run(main())
```

---

## Adding Constraints

```python
from pyrapide import must_match, never, Pattern

# Every action call must produce a result or error
must_match(
    adapter.computation,
    Pattern("agent.tool.call") >> (Pattern("agent.tool.result") | Pattern("agent.tool.error")),
    "Every action must resolve",
)

# Role steps should always contain at least one action
must_match(
    adapter.computation,
    Pattern("agent.step.start") >> Pattern("agent.tool.call"),
    "Every role step should execute at least one action",
)

# No orphan messages (messages outside a role step scope)
never(
    adapter.computation,
    Pattern("agent.message.send") & ~Pattern("agent.step.start").before(),
    "Message sent outside any role step",
)
```

---

## Post-Run Analysis

```python
comp = adapter.computation

# Find which roles caused errors
errors = [e for e in comp.events if e.name == "agent.tool.error"]
for err in errors:
    causes = queries.root_causes(comp, err)
    role = err.payload.get("tool_name", "unknown")
    print(f"Action '{role}' failed. Root causes: {[c.name for c in causes]}")

# Map the full role-action-message graph
steps = [e for e in comp.events if e.name == "agent.step.start"]
for step in steps:
    children = queries.direct_effects(comp, step)
    print(f"Role '{step.payload.get('role_name')}' triggered:")
    for child in children:
        print(f"  -> {child.name} ({child.payload.get('framework_event_type')})")

# Visualize
from pyrapide import visualize
visualize.to_dot(comp, output="metagpt_trace.png")
visualize.to_json(comp, output="metagpt_trace.json")
```

---

## API Reference

```python
class MetaGPTAdapter(BaseAgentAdapter):
    def __init__(self, name: str) -> None
        # name: human-readable adapter name (appears in event source)

    def patch(self) -> MetaGPTAdapter
        # Monkey-patch Role.run, Action.run, Environment.publish_message.
        # Returns self for chaining: adapter = MetaGPTAdapter("x").patch()
        # Raises ImportError if metagpt is not installed.

    def unpatch(self) -> None
        # Restore original MetaGPT methods. Safe to call multiple times.

    # Inherited from BaseAgentAdapter:
    @property
    def computation(self) -> Computation
    @property
    def tracker(self) -> CausalTracker
    def emit(self, event_type, payload, ...) -> Event
    def emit_scope_start(self, event_type, payload, ...) -> Event
    def emit_scope_end(self, event_type, payload, ...) -> Event
    async def events(self) -> AsyncIterator[Event]  # EventSource protocol
    async def close(self) -> None
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `ImportError: metagpt` | Run `pip install metagpt` |
| No events captured | Verify `.patch()` was called before running roles; check that `adapter._patched` is `True` |
| Events from unrelated roles | Patches are class-level (global); all Role/Action/Environment instances are instrumented |
| `unpatch()` not restoring originals | Ensure no other code also monkey-patched the same methods after `patch()` |
| Async errors in wrapped methods | The adapter preserves `async def` signatures; ensure your event loop is running |
| Missing sender on messages | The adapter reads `message.role` or `message.sent_from`; ensure messages carry sender info |

---

## Related Files

- [`adapter.py`](./adapter.py) -- MetaGPTAdapter implementation with patch/unpatch
- [`template.py`](./template.py) -- runnable example script
- [`core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`core/event_types.py`](../core/event_types.py) -- unified AgentEventTypes constants
- [`core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker scope management
- [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) -- full PyRapide docs
