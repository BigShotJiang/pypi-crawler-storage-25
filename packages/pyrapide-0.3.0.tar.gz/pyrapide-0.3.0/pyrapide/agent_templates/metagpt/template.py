"""MetaGPT + PyRapide integration template.

This runnable example shows how to instrument a MetaGPT multi-agent
setup with PyRapide causal event tracking.

Prerequisites::

    pip install pyrapide metagpt

Overview
--------
MetaGPT uses a role-based architecture where ``Role`` instances execute
``Action`` instances and communicate via ``Environment.publish_message``.
PyRapide hooks into this by monkey-patching these three classes to emit
events for every role step, action execution, and message publication.

The integration requires **two lines of code**:

1. Create and patch the adapter::

       adapter = MetaGPTAdapter("my-app").patch()

2. Run your MetaGPT roles as usual -- events are captured automatically.

When you are done, call ``adapter.unpatch()`` to restore the originals.
"""

from __future__ import annotations

import asyncio


async def main() -> None:
    """Run a simple MetaGPT role with PyRapide instrumentation."""

    # --- Standard MetaGPT setup -------------------------------------------

    from metagpt.roles.role import Role
    from metagpt.actions.action import Action
    from metagpt.schema import Message

    class SummarizeAction(Action):
        name: str = "Summarize"

        async def run(self, instruction: str) -> str:
            return f"Summary of: {instruction}"

    class SummarizerRole(Role):
        name: str = "Summarizer"
        profile: str = "Summarizer"

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.set_actions([SummarizeAction()])

    # --- PyRapide instrumentation (2 lines) --------------------------------

    from pyrapide.agent_templates.metagpt import MetaGPTAdapter

    adapter = MetaGPTAdapter("metagpt-demo").patch()

    # --- Run the role ------------------------------------------------------

    role = SummarizerRole()
    collected_events: list = []

    async def collect_events() -> None:
        async for event in adapter.events():
            collected_events.append(event)
            print(f"  [{event.name}] source={event.source} | {event.id[:8]}")

    event_task = asyncio.create_task(collect_events())

    try:
        msg = Message(content="Explain quantum computing in simple terms.")
        role.put_message(msg)
        await role.run()
    finally:
        await adapter.close()
        await event_task

    # --- Inspect results ---------------------------------------------------

    print(f"\nCollected {len(collected_events)} PyRapide events:")
    for ev in collected_events:
        meta = ev.metadata or {}
        parent = meta.get("parent_id", "root")[:8] if meta.get("parent_id") else "root"
        print(f"  {ev.name:<30} parent={parent:<10} id={ev.id[:8]}")

    computation = adapter.computation
    print(f"\nComputation has {len(computation)} events with causal links.")

    # Restore originals
    adapter.unpatch()


if __name__ == "__main__":
    asyncio.run(main())
