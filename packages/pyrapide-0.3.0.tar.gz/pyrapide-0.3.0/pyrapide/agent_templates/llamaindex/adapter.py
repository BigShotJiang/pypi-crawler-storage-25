"""LlamaIndex adapter for PyRapide causal event tracking.

Hooks into the LlamaIndex root Dispatcher event handler system to capture
LLM calls, tool invocations, queries, and retrieval operations. Events are
translated into the unified PyRapide ``AgentEventTypes`` taxonomy.

All LlamaIndex imports are lazy (inside methods) so that users who do not
have ``llama-index`` installed can still import this module without errors.
"""

from __future__ import annotations

import logging
from typing import Any

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)

# Mapping from LlamaIndex event class names to (event_type, is_scope_start, is_scope_end)
_EVENT_MAP: dict[str, tuple[str, bool, bool]] = {
    "AgentToolCallEvent": (AgentEventTypes.TOOL_CALL, False, False),
    "LLMChatStartEvent": (AgentEventTypes.LLM_REQUEST, False, False),
    "LLMPredictStartEvent": (AgentEventTypes.LLM_REQUEST, False, False),
    "LLMChatEndEvent": (AgentEventTypes.LLM_RESPONSE, False, False),
    "LLMPredictEndEvent": (AgentEventTypes.LLM_RESPONSE, False, False),
    "QueryStartEvent": (AgentEventTypes.TASK_START, True, False),
    "QueryEndEvent": (AgentEventTypes.TASK_END, False, True),
    "RetrievalStartEvent": (AgentEventTypes.TOOL_CALL, False, False),
    "RetrievalEndEvent": (AgentEventTypes.TOOL_RESULT, False, False),
}

# LLM events that should carry a correlation_id derived from the span
_LLM_CORRELATED_EVENTS = frozenset({
    "LLMChatStartEvent",
    "LLMPredictStartEvent",
    "LLMChatEndEvent",
    "LLMPredictEndEvent",
})


class LlamaIndexAdapter(BaseAgentAdapter):
    """Adapter that translates LlamaIndex Dispatcher events into PyRapide events.

    Registers a custom ``BaseEventHandler`` on the LlamaIndex root dispatcher.
    Each LlamaIndex event is mapped to the corresponding ``AgentEventTypes``
    constant and emitted through the standard ``BaseAgentAdapter.emit()`` path.

    Parameters
    ----------
    name:
        Human-readable name for this adapter instance, used as the event
        source identifier.

    Example::

        from pyrapide.agent_templates.llamaindex import LlamaIndexAdapter

        adapter = LlamaIndexAdapter("rag-pipeline")
        adapter.attach()

        # Now run your LlamaIndex queries as usual; events are captured
        # automatically via the root dispatcher.
        index.as_query_engine().query("What is PyRapide?")
    """

    def __init__(self, name: str) -> None:
        super().__init__(name, framework_instance=None)
        self._handler: Any = None
        self._dispatcher: Any = None

    def attach(self) -> None:
        """Convenience method to install hooks immediately.

        Equivalent to calling the internal ``_install_hooks()`` but exposed
        as a public API for explicit, non-streaming usage.
        """
        if not self._hooks_installed:
            self._install_hooks()
            self._hooks_installed = True

    def _install_hooks(self) -> None:
        """Register a PyRapide event handler on the LlamaIndex root dispatcher."""
        # Lazy imports -- llama-index may not be installed
        try:
            import llama_index.core.instrumentation as instrument
            from llama_index.core.instrumentation.event_handlers import (
                BaseEventHandler,
            )
        except ImportError as exc:
            raise ImportError(
                "LlamaIndex is required for LlamaIndexAdapter. "
                "Install it with: pip install llama-index"
            ) from exc

        adapter_ref = self  # prevent closure over 'self' name conflicts

        class _PyRapideEventHandler(BaseEventHandler):
            """Inner handler registered on the LlamaIndex root dispatcher."""

            @classmethod
            def class_name(cls) -> str:
                return "PyRapideEventHandler"

            def handle(self, event: Any, **kwargs: Any) -> None:
                """Translate a LlamaIndex event into a PyRapide event."""
                event_class = event.class_name()
                mapping = _EVENT_MAP.get(event_class)
                if mapping is None:
                    logger.debug(
                        "LlamaIndexAdapter: unmapped event %s", event_class
                    )
                    return

                event_type, is_scope_start, is_scope_end = mapping

                payload: dict[str, Any] = {
                    "framework": "llamaindex",
                    "framework_event_type": event_class,
                }

                # Attach serialisable event data when available
                if hasattr(event, "dict"):
                    try:
                        payload["event_data"] = event.dict()
                    except Exception:
                        payload["event_data"] = str(event)
                elif hasattr(event, "model_dump"):
                    try:
                        payload["event_data"] = event.model_dump()
                    except Exception:
                        payload["event_data"] = str(event)

                # Build keyword arguments for emit
                emit_kwargs: dict[str, Any] = {}

                # Correlate LLM request/response pairs via span_id
                if event_class in _LLM_CORRELATED_EVENTS:
                    span_id = getattr(event, "span_id", None)
                    if span_id is not None:
                        emit_kwargs["correlation_id"] = str(span_id)

                # Tag retrieval events for clarity
                if event_class == "RetrievalStartEvent":
                    payload["tool_name"] = "rag_retrieval"
                    payload["description"] = "RAG document retrieval"
                elif event_class == "RetrievalEndEvent":
                    nodes = getattr(event, "nodes", None)
                    if nodes is not None:
                        payload["num_nodes"] = len(nodes)

                # Dispatch through the appropriate emit method
                if is_scope_start:
                    adapter_ref.emit_scope_start(event_type, payload, **emit_kwargs)
                elif is_scope_end:
                    adapter_ref.emit_scope_end(event_type, payload, **emit_kwargs)
                else:
                    adapter_ref.emit(event_type, payload, **emit_kwargs)

        # Get the root dispatcher and register our handler
        self._dispatcher = instrument.get_dispatcher()
        self._handler = _PyRapideEventHandler()
        self._dispatcher.add_event_handler(self._handler)

        logger.info(
            "LlamaIndexAdapter '%s': handler registered on root dispatcher",
            self._name,
        )

    def _uninstall_hooks(self) -> None:
        """Remove the event handler from the LlamaIndex root dispatcher."""
        if self._dispatcher is not None and self._handler is not None:
            try:
                handlers = self._dispatcher.event_handlers
                if self._handler in handlers:
                    handlers.remove(self._handler)
                    logger.info(
                        "LlamaIndexAdapter '%s': handler removed from root dispatcher",
                        self._name,
                    )
            except Exception:
                logger.warning(
                    "LlamaIndexAdapter '%s': failed to remove handler",
                    self._name,
                    exc_info=True,
                )
        self._handler = None
        self._dispatcher = None
