"""Runnable example: LlamaIndex + PyRapide causal event tracking.

Demonstrates how to attach the ``LlamaIndexAdapter`` to a LlamaIndex
query pipeline and observe the resulting PyRapide events.

Requirements::

    pip install pyrapide llama-index

Usage::

    python -m agent_templates.llamaindex.template
"""

from __future__ import annotations

import asyncio
import json


async def main() -> None:
    """Run a simple LlamaIndex query with PyRapide instrumentation."""
    # -- Framework imports (lazy at function scope) ----------------------------
    try:
        from llama_index.core import Document, VectorStoreIndex
    except ImportError:
        print(
            "This example requires llama-index.\n"
            "Install it with: pip install llama-index"
        )
        return

    from pyrapide.agent_templates.llamaindex import LlamaIndexAdapter

    # -- Set up the adapter ----------------------------------------------------
    adapter = LlamaIndexAdapter("llamaindex-demo")
    adapter.attach()

    # -- Build a minimal in-memory index ---------------------------------------
    documents = [
        Document(text="PyRapide is a Python library for causal event tracking."),
        Document(text="LlamaIndex provides a data framework for LLM applications."),
        Document(text="Agents use tools to interact with external systems."),
    ]
    index = VectorStoreIndex.from_documents(documents)
    query_engine = index.as_query_engine()

    # -- Run a query (events are captured automatically) -----------------------
    print("Running query...")
    response = query_engine.query("What is PyRapide?")
    print(f"Response: {response}\n")

    # -- Inspect captured events -----------------------------------------------
    print("=" * 60)
    print("Captured PyRapide Events")
    print("=" * 60)
    computation = adapter.computation
    for event in computation.events:
        print(
            json.dumps(
                {
                    "id": event.id[:12],
                    "type": event.name,
                    "source": event.source,
                    "payload_keys": list(event.payload.keys()),
                },
                indent=2,
            )
        )
    print(f"\nTotal events: {len(computation.events)}")

    # -- Clean up --------------------------------------------------------------
    await adapter.close()
    print("Done.")


if __name__ == "__main__":
    asyncio.run(main())
