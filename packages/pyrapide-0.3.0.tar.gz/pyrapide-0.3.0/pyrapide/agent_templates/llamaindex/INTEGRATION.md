# LlamaIndex + PyRapide Integration

> **Navigation**: [Main Docs](../../pyrapide-agent-documentation.md) | [AutoGen](../autogen/INTEGRATION.md) | [LangGraph](../langgraph/INTEGRATION.md) | [CrewAI](../crewai/INTEGRATION.md) | **LlamaIndex**

## Quick Start

```python
from pyrapide.agent_templates.llamaindex import LlamaIndexAdapter

adapter = LlamaIndexAdapter("my-agent")
adapter.attach()  # Attaches to root dispatcher — captures all events globally

# Now run your LlamaIndex code as usual; events are captured automatically
response = query_engine.query("What is PyRapide?")
```

## Prerequisites

```bash
pip install pyrapide llama-index
```

## How It Works

The adapter registers a custom `BaseEventHandler` on the LlamaIndex root `Dispatcher` via `llama_index.core.instrumentation`. Once attached, every instrumented LlamaIndex operation -- LLM calls, retrievals, queries, and agent tool use -- fires an event that the handler translates into a PyRapide `Event`.

LLM request/response pairs are correlated using the `span_id` from LlamaIndex events as the `correlation_id`. Query start/end events push and pop scopes on the `CausalTracker`, so all events within a query are automatically nested under the query scope. Retrieval operations are mapped as tool calls (treating RAG retrieval as a tool), enabling unified analysis across retrieval and agent tool use.

## Event Mapping

| LlamaIndex Event | PyRapide Event | Causal Link |
|---|---|---|
| `AgentToolCallEvent` | `agent.tool.call` (TOOL_CALL) | Caused by most recent LLM_RESPONSE |
| `LLMChatStartEvent` | `agent.llm.request` (LLM_REQUEST) | `correlation_id=span_id`, caused by TOOL_RESULT if re-inference |
| `LLMChatEndEvent` | `agent.llm.response` (LLM_RESPONSE) | `correlation_id=span_id`, paired with LLM_REQUEST |
| `LLMPredictStartEvent` | `agent.llm.request` (LLM_REQUEST) | `correlation_id=span_id` |
| `LLMPredictEndEvent` | `agent.llm.response` (LLM_RESPONSE) | `correlation_id=span_id` |
| `QueryStartEvent` | `agent.task.start` (TASK_START) | Scope push -- all nested events parented here |
| `QueryEndEvent` | `agent.task.end` (TASK_END) | Scope pop |
| `RetrievalStartEvent` | `agent.tool.call` (TOOL_CALL) | RAG retrieval mapped as tool; `tool_name=rag_retrieval` |
| `RetrievalEndEvent` | `agent.tool.result` (TOOL_RESULT) | Paired with RetrievalStartEvent; includes `num_nodes` |

## Full Example

```python
import asyncio
from llama_index.core import Document, VectorStoreIndex
from pyrapide.agent_templates.llamaindex import LlamaIndexAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

# --- PyRapide: 2 lines ---
adapter = LlamaIndexAdapter("rag-pipeline")
adapter.attach()

# --- Standard LlamaIndex setup ---
documents = [
    Document(text="PyRapide is a Python library for causal event tracking."),
    Document(text="LlamaIndex provides a data framework for LLM applications."),
    Document(text="Agents use tools to interact with external systems."),
]
index = VectorStoreIndex.from_documents(documents)
query_engine = index.as_query_engine()

# Events are captured automatically via the root dispatcher
response = query_engine.query("What is PyRapide?")
print(f"Response: {response}\n")

# --- Inspect causal graph ---
comp = adapter.computation
print(f"{len(comp.events)} events tracked\n")

for event in comp.topological_order():
    corr = (event.metadata or {}).get("correlation_id", "")[:8]
    print(f"  {event.name:<30} corr={corr:<10} id={event.id[:8]}")

# Find retrieval events
retrievals = [e for e in comp.events if e.name == AgentEventTypes.TOOL_RESULT
              and e.payload.get("framework_event_type") == "RetrievalEndEvent"]
for r in retrievals:
    print(f"  Retrieved {r.payload.get('num_nodes', '?')} nodes")

async def cleanup():
    await adapter.close()

asyncio.run(cleanup())
```

## Adding Constraints

```python
from pyrapide.agent_templates.core.patterns import AgentPatterns
from pyrapide.constraints.pattern_constraints import MustMatch, Never
from pyrapide.patterns.base import Pattern
from pyrapide.agent_templates.core.event_types import AgentEventTypes

# Every LLM call must get a response
must_respond = MustMatch(
    AgentPatterns.llm_roundtrip(),
    name="llm-must-respond",
    description="Every LLM request must receive a response",
)

# Retrieval must return results (tool_call -> tool_result for RAG)
must_retrieve = MustMatch(
    AgentPatterns.tool_roundtrip(),
    name="retrieval-must-complete",
    description="Every retrieval must return results",
)

# No errors allowed during queries
no_errors = Never(
    AgentPatterns.any_error(),
    name="no-query-errors",
    description="Queries must complete without errors",
)

from pyrapide.constraints.conformance import check_conformance
violations = check_conformance(adapter.computation, [must_respond, must_retrieve, no_errors])
for v in violations:
    print(f"VIOLATION: {v.constraint_name} -- {v.description}")
```

## Post-Run Analysis

```python
from pyrapide.analysis import queries, visualization

comp = adapter.computation

# Trace the causal chain from query to response
if comp.events:
    final = comp.events[-1]
    roots = queries.root_causes(comp, final)
    print(f"Response rooted in: {[r.name for r in roots]}")

# Backward slice: everything that contributed to a specific event
llm_response = [e for e in comp.events if e.name == "agent.llm.response"][-1]
slice_comp = queries.backward_slice(comp, llm_response)
print(f"Backward slice: {len(slice_comp)} events contributed to LLM response")

# Forward slice: everything affected by the retrieval
retrieval = [e for e in comp.events if e.name == "agent.tool.call"][0]
impact = queries.forward_slice(comp, retrieval)
print(f"Retrieval impacted {len(impact)} downstream events")

# Event frequency breakdown
freq = queries.event_frequency(comp)
for name, count in sorted(freq.items(), key=lambda x: -x[1]):
    print(f"  {name}: {count}")

# Visualization
print(visualization.to_ascii(comp))               # Terminal output
dot = visualization.to_dot(comp)                   # Graphviz DOT
mermaid = visualization.to_mermaid(comp)           # Mermaid diagram
print(visualization.summary(comp))                 # Text summary
json_data = visualization.to_json(comp)            # JSON for custom UIs
```

## API Reference

```python
class LlamaIndexAdapter(BaseAgentAdapter):
    def __init__(self, name: str) -> None
        """Create adapter. Call attach() to register on the root dispatcher."""

    def attach(self) -> None
        """Register the event handler on the LlamaIndex root dispatcher.
        Captures all events globally from this point forward."""

    @property
    def computation(self) -> Computation
        """The internal Computation containing all recorded events."""

    @property
    def tracker(self) -> CausalTracker
        """The CausalTracker managing event relationships."""

    def emit(self, event_type, payload, *, parent_id=None, correlation_id=None, source=None, metadata=None) -> Event
        """Create, record, and enqueue a PyRapide Event."""

    async def events(self) -> AsyncIterator[Event]
        """Yield events as they are emitted. Implements EventSource protocol.
        Calls attach() automatically if not already attached."""

    async def close(self) -> None
        """Signal that no more events will be produced. Removes handler from dispatcher."""
```

## Troubleshooting

| Issue | Fix |
|---|---|
| `ImportError: llama-index` | Run `pip install llama-index` |
| No events captured | Call `adapter.attach()` before any LlamaIndex operations; it must be attached before queries run |
| Missing LLM events | Ensure your LLM class is instrumented (most `llama-index` built-in LLMs are); custom LLMs may not fire dispatcher events |
| `span_id` is None | Some older LlamaIndex versions do not populate `span_id` on all events; upgrade to `llama-index >= 0.11` |
| Retrieval events missing | `RetrievalStartEvent`/`RetrievalEndEvent` require the retriever to use LlamaIndex's instrumentation layer; custom retrievers may need manual event emission |
| Global capture too broad | The handler attaches to the root dispatcher and captures all events in the process; use event filtering in post-analysis if you need to isolate specific pipelines |

## Related Files

- [`agent_templates/llamaindex/adapter.py`](adapter.py) -- LlamaIndexAdapter implementation
- [`agent_templates/llamaindex/template.py`](template.py) -- Runnable example
- [`agent_templates/core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`agent_templates/core/event_types.py`](../core/event_types.py) -- AgentEventTypes constants
- [`agent_templates/core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker engine
- [`agent_templates/core/patterns.py`](../core/patterns.py) -- AgentPatterns library
- [`pyrapide-agent-documentation.md`](../../pyrapide-agent-documentation.md) -- Full PyRapide agent docs
