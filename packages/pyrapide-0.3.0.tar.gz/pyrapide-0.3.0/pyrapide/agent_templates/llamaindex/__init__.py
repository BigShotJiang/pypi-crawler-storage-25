"""PyRapide adapter for LlamaIndex.

Provides ``LlamaIndexAdapter`` which hooks into the LlamaIndex root
Dispatcher event system to emit causal events for LLM calls, tool
invocations, queries, and retrieval operations.

Usage::

    from pyrapide.agent_templates.llamaindex import LlamaIndexAdapter

    adapter = LlamaIndexAdapter("my-llamaindex-app")
    adapter.attach()
"""

from pyrapide.agent_templates.llamaindex.adapter import LlamaIndexAdapter

__all__ = ["LlamaIndexAdapter"]
