# PyRapide + Agno Integration

> Causal event tracking for Agno (formerly Phidata) agents via pre/post hooks and RunEvent stream.

**Docs:** [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) | **Siblings:** [swarm](../swarm/INTEGRATION.md) | [metagpt](../metagpt/INTEGRATION.md) | [flowise](../flowise/INTEGRATION.md)

---

## Quick Start

```python
from agno.agent import Agent
from pyrapide.agent_templates.agno import AgnoAdapter

agent = Agent(name="my-agent", model="gpt-4o", tools=[my_tool])
adapter = AgnoAdapter("my-agent", agent=agent)

# Hook mode: run the agent normally -- events captured automatically
response = agent.run("Summarize this document")

# Stream mode: process RunEvent objects from an async stream
async for event in agent.run_stream("Summarize this"):
    adapter.on_event(event)

# Analyze causal graph
comp = adapter.computation
for event in comp.events:
    print(event.name, event.payload)
```

---

## Prerequisites

```bash
pip install pyrapide agno
```

---

## How It Works

AgnoAdapter supports two integration modes. In **hook mode**, passing an Agno `Agent` instance to the constructor installs `pre_hook` and `post_hook` callbacks on the agent and wraps each tool function with emit decorators. Events are captured automatically whenever the agent runs.

In **stream mode**, you call `adapter.on_event(run_event)` for each `RunEvent` yielded by `agent.run_stream()`. The adapter maps the event's type string (e.g. `"RunStarted"`) to a PyRapide `AgentEventTypes` constant and records it in the causal DAG. Both modes can be combined for comprehensive coverage.

---

## Event Mapping

| Agno RunEvent | PyRapide Event | Causal Link |
|---|---|---|
| `RunStarted` | `agent.run.start` | Scope push -- becomes parent of all nested events |
| `RunCompleted` | `agent.run.end` | Scope pop -- closes the run scope |
| `ToolCallStarted` | `agent.tool.call` | Child of current scope (run or step) |
| `ToolCallCompleted` | `agent.tool.result` | Child of current scope, correlated to its TOOL_CALL |
| `ToolCallFailed` | `agent.tool.error` | Child of current scope |
| `LLMRequestStarted` | `agent.llm.request` | Child of current scope |
| `LLMRequestCompleted` | `agent.llm.response` | Child of current scope, correlated to its LLM_REQUEST |
| `AgentMessage` | `agent.message.send` | Child of current scope |
| `StepStarted` | `agent.step.start` | Scope push -- nested inside run scope |
| `StepCompleted` | `agent.step.end` | Scope pop -- closes the step scope |

---

## Full Example

```python
import asyncio
from agno.agent import Agent
from pyrapide.agent_templates.agno import AgnoAdapter
from pyrapide import queries

def get_weather(city: str) -> str:
    """Get weather for a city."""
    return f"Sunny, 22C in {city}"

def get_time(timezone: str = "UTC") -> str:
    """Get current time."""
    return f"14:30 {timezone}"

async def main():
    agent = Agent(
        name="WeatherBot",
        model="gpt-4o-mini",
        tools=[get_weather, get_time],
        instructions="You provide weather and time information.",
    )
    adapter = AgnoAdapter("weather-demo", agent=agent)

    # Hook mode: events captured via pre/post hooks and tool wrappers
    response = agent.run("What is the weather in Paris?")

    # Stream mode: capture RunEvent objects
    async for run_event in agent.run_stream("What time is it in Tokyo?"):
        adapter.on_event(run_event)

    # Analyze
    comp = adapter.computation
    print(f"Captured {len(comp.events)} events")
    for ev in comp.events:
        print(f"  {ev.name}: {ev.payload.get('framework_event_type')}")

    await adapter.close()

asyncio.run(main())
```

---

## Adding Constraints

```python
from pyrapide import must_match, never, Pattern

# Every tool call must produce a result or error
must_match(
    adapter.computation,
    Pattern("agent.tool.call") >> (Pattern("agent.tool.result") | Pattern("agent.tool.error")),
    "Every tool call must have a result or error",
)

# LLM errors should never occur without a preceding request
never(
    adapter.computation,
    Pattern("agent.llm.error") & ~Pattern("agent.llm.request").before(),
    "LLM error without a preceding request",
)
```

---

## Post-Run Analysis

```python
comp = adapter.computation

# Find root causes of any errors
errors = [e for e in comp.events if "error" in e.name]
for err in errors:
    causes = queries.root_causes(comp, err)
    print(f"Error {err.id[:12]} caused by: {[c.name for c in causes]}")

# Visualize the causal graph
from pyrapide import visualize
visualize.to_dot(comp, output="agno_trace.png")
visualize.to_json(comp, output="agno_trace.json")

# Trace a specific event's full causal chain
event = comp.events[-1]
chain = queries.causal_chain(comp, event)
for step in chain:
    print(f"  {step.name} ({step.source})")
```

---

## API Reference

```python
class AgnoAdapter(BaseAgentAdapter):
    def __init__(self, name: str, agent: Any = None) -> None
        # name:  human-readable adapter name (appears in event source)
        # agent: optional Agno Agent instance (enables hook mode)

    def on_event(self, run_event: Any) -> None
        # Process an Agno RunEvent and emit the corresponding PyRapide event.
        # Use with agent.run_stream() for stream mode.

    # Inherited from BaseAgentAdapter:
    @property
    def computation(self) -> Computation    # access the causal DAG
    @property
    def tracker(self) -> CausalTracker      # access the causal tracker
    def emit(self, event_type, payload, ...) -> Event
    def emit_scope_start(self, event_type, payload, ...) -> Event
    def emit_scope_end(self, event_type, payload, ...) -> Event
    async def events(self) -> AsyncIterator[Event]  # EventSource protocol
    async def close(self) -> None
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `ImportError: agno` | Run `pip install agno` |
| No events captured (hook mode) | Verify you passed the `agent=` parameter to `AgnoAdapter()` |
| No events captured (stream mode) | Ensure you call `adapter.on_event(event)` for each `RunEvent` |
| Unmapped event type logged | The adapter logs unknown Agno event types at DEBUG level; these are safely ignored |
| `pre_hook`/`post_hook` conflict | If the agent already has hooks, the adapter saves and chains them; check for overwritten references |
| Events not showing causal links | Ensure `emit_scope_start`/`emit_scope_end` are paired; mismatched scopes break the DAG |

---

## Related Files

- [`adapter.py`](./adapter.py) -- AgnoAdapter implementation
- [`template.py`](./template.py) -- runnable example script
- [`core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`core/event_types.py`](../core/event_types.py) -- unified AgentEventTypes constants
- [`core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker scope management
- [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) -- full PyRapide docs
