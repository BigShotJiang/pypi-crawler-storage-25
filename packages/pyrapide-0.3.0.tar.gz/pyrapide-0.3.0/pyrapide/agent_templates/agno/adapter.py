"""Agno adapter for PyRapide causal event tracking.

Hooks into Agno agents via pre/post hooks and RunEvent stream processing
to capture run lifecycle, tool invocations, and LLM interactions. Events
are translated into the unified PyRapide ``AgentEventTypes`` taxonomy.

All Agno imports are lazy (inside methods) so that users who do not have
``agno`` installed can still import this module without errors.
"""

from __future__ import annotations

import functools
import logging
from typing import Any, Callable

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)

# Mapping from Agno RunEvent type strings to AgentEventTypes
_RUN_EVENT_MAP: dict[str, str] = {
    "RunStarted": AgentEventTypes.RUN_START,
    "RunCompleted": AgentEventTypes.RUN_END,
    "RunFailed": AgentEventTypes.TASK_ERROR,
    "ToolCallStarted": AgentEventTypes.TOOL_CALL,
    "ToolCallCompleted": AgentEventTypes.TOOL_RESULT,
    "ToolCallFailed": AgentEventTypes.TOOL_ERROR,
    "LLMRequestStarted": AgentEventTypes.LLM_REQUEST,
    "LLMRequestCompleted": AgentEventTypes.LLM_RESPONSE,
    "LLMRequestFailed": AgentEventTypes.LLM_ERROR,
    "AgentMessage": AgentEventTypes.AGENT_MESSAGE,
    "StepStarted": AgentEventTypes.STEP_START,
    "StepCompleted": AgentEventTypes.STEP_END,
    "ReasoningStarted": AgentEventTypes.STEP_START,
    "ReasoningCompleted": AgentEventTypes.STEP_END,
}


class AgnoAdapter(BaseAgentAdapter):
    """Adapter that translates Agno agent events into PyRapide events.

    Supports two integration modes:

    1. **Hook mode**: Pass an Agno ``Agent`` instance to register pre/post
       hooks and tool wrappers directly on the agent.
    2. **Stream mode**: Use ``on_event()`` to process ``RunEvent`` objects
       from an Agno event stream.

    Both modes can be combined for comprehensive coverage.

    Parameters
    ----------
    name:
        Human-readable name for this adapter instance.
    agent:
        Optional Agno ``Agent`` instance. If provided, hooks and tool
        wrappers are installed automatically.

    Example::

        from agno.agent import Agent
        from pyrapide.agent_templates.agno import AgnoAdapter

        agent = Agent(model="gpt-4o", tools=[...])
        adapter = AgnoAdapter("my-agent", agent=agent)

        # Hook mode: events are captured automatically
        response = agent.run("Summarize this document")

        # Stream mode: process events from a stream
        async for event in agent.run_stream("Summarize this"):
            adapter.on_event(event)
    """

    def __init__(self, name: str, agent: Any = None) -> None:
        super().__init__(name, framework_instance=agent)
        self._original_tools: dict[str, Callable[..., Any]] = {}
        self._pre_hook: Any = None
        self._post_hook: Any = None

    def _install_hooks(self) -> None:
        """Register pre/post hooks and tool wrappers on the Agno agent."""
        agent = self._framework_instance
        if agent is None:
            logger.info(
                "AgnoAdapter '%s': no agent provided, using stream-only mode. "
                "Call on_event() to process RunEvent objects.",
                self._name,
            )
            return

        self._install_run_hooks(agent)
        self._wrap_tools(agent)

        logger.info(
            "AgnoAdapter '%s': hooks installed on agent", self._name
        )

    def _install_run_hooks(self, agent: Any) -> None:
        """Register pre_hook and post_hook on the agent for run lifecycle."""
        adapter_ref = self

        def pre_hook(agent_instance: Any, message: Any, **kwargs: Any) -> None:
            """Emit RUN_START before the agent processes a message."""
            adapter_ref.emit_scope_start(
                AgentEventTypes.RUN_START,
                {
                    "framework": "agno",
                    "framework_event_type": "pre_hook",
                    "agent_name": getattr(agent_instance, "name", str(agent_instance)),
                    "message": str(message) if message else None,
                },
            )

        def post_hook(
            agent_instance: Any, message: Any, response: Any, **kwargs: Any
        ) -> None:
            """Emit RUN_END after the agent finishes processing."""
            payload: dict[str, Any] = {
                "framework": "agno",
                "framework_event_type": "post_hook",
                "agent_name": getattr(agent_instance, "name", str(agent_instance)),
            }
            if response is not None:
                payload["response_preview"] = str(response)[:500]
            adapter_ref.emit_scope_end(AgentEventTypes.RUN_END, payload)

        # Attach hooks to the agent
        if hasattr(agent, "pre_hook"):
            self._pre_hook = agent.pre_hook
        agent.pre_hook = pre_hook

        if hasattr(agent, "post_hook"):
            self._post_hook = agent.post_hook
        agent.post_hook = post_hook

    def _wrap_tools(self, agent: Any) -> None:
        """Wrap each tool in the agent's tool list with emit decorators."""
        tools = getattr(agent, "tools", None)
        if not tools:
            return

        adapter_ref = self

        for i, tool in enumerate(tools):
            if not callable(tool):
                continue

            tool_name = getattr(tool, "__name__", None) or getattr(
                tool, "name", f"tool_{i}"
            )
            self._original_tools[tool_name] = tool

            @functools.wraps(tool)
            def instrumented_tool(
                *args: Any,
                _orig_tool: Callable[..., Any] = tool,
                _tool_name: str = tool_name,
                **kwargs: Any,
            ) -> Any:
                adapter_ref.emit(
                    AgentEventTypes.TOOL_CALL,
                    {
                        "framework": "agno",
                        "framework_event_type": "tool_call",
                        "tool_name": _tool_name,
                        "args": str(args)[:500] if args else None,
                        "kwargs": str(kwargs)[:500] if kwargs else None,
                    },
                )
                try:
                    result = _orig_tool(*args, **kwargs)
                    adapter_ref.emit(
                        AgentEventTypes.TOOL_RESULT,
                        {
                            "framework": "agno",
                            "framework_event_type": "tool_result",
                            "tool_name": _tool_name,
                            "result_preview": str(result)[:500] if result else None,
                        },
                    )
                    return result
                except Exception as exc:
                    adapter_ref.emit(
                        AgentEventTypes.TOOL_ERROR,
                        {
                            "framework": "agno",
                            "framework_event_type": "tool_error",
                            "tool_name": _tool_name,
                            "error": str(exc),
                            "error_type": type(exc).__name__,
                        },
                    )
                    raise

            tools[i] = instrumented_tool

    def on_event(self, run_event: Any) -> None:
        """Process an Agno RunEvent and emit the corresponding PyRapide event.

        Use this method when consuming events from an Agno stream::

            async for event in agent.run_stream("query"):
                adapter.on_event(event)

        Parameters
        ----------
        run_event:
            An Agno ``RunEvent`` (or any object with an ``event`` attribute
            that contains a type string, or a ``type`` attribute directly).
        """
        # Determine the event type string from the RunEvent
        event_type_str = None
        if hasattr(run_event, "event"):
            event_type_str = str(run_event.event)
        elif hasattr(run_event, "type"):
            event_type_str = str(run_event.type)
        elif isinstance(run_event, str):
            event_type_str = run_event
        else:
            logger.debug(
                "AgnoAdapter: could not determine event type from %r",
                run_event,
            )
            return

        mapped_type = _RUN_EVENT_MAP.get(event_type_str)
        if mapped_type is None:
            logger.debug(
                "AgnoAdapter: unmapped Agno event type '%s'", event_type_str
            )
            return

        payload: dict[str, Any] = {
            "framework": "agno",
            "framework_event_type": event_type_str,
        }

        # Attach data from the run_event if available
        if hasattr(run_event, "data"):
            try:
                data = run_event.data
                if hasattr(data, "dict"):
                    payload["event_data"] = data.dict()
                elif hasattr(data, "model_dump"):
                    payload["event_data"] = data.model_dump()
                elif isinstance(data, dict):
                    payload["event_data"] = data
                else:
                    payload["event_data"] = str(data)[:1000]
            except Exception:
                payload["event_data"] = str(run_event)[:1000]

        # Use scope methods for run/step lifecycle events
        if mapped_type in (AgentEventTypes.RUN_START, AgentEventTypes.STEP_START):
            self.emit_scope_start(mapped_type, payload)
        elif mapped_type in (AgentEventTypes.RUN_END, AgentEventTypes.STEP_END):
            self.emit_scope_end(mapped_type, payload)
        else:
            self.emit(mapped_type, payload)

    def _uninstall_hooks(self) -> None:
        """Restore original hooks and tools on the agent."""
        agent = self._framework_instance
        if agent is None:
            return

        # Restore original hooks
        if self._pre_hook is not None:
            agent.pre_hook = self._pre_hook
            self._pre_hook = None
        elif hasattr(agent, "pre_hook"):
            agent.pre_hook = None

        if self._post_hook is not None:
            agent.post_hook = self._post_hook
            self._post_hook = None
        elif hasattr(agent, "post_hook"):
            agent.post_hook = None

        # Restore original tools
        tools = getattr(agent, "tools", None)
        if tools and self._original_tools:
            for i, tool in enumerate(tools):
                original_name = getattr(tool, "__wrapped__", None)
                if original_name is None:
                    original_name = getattr(tool, "__name__", None)
                if original_name and original_name in self._original_tools:
                    tools[i] = self._original_tools[original_name]

        self._original_tools.clear()
        logger.info("AgnoAdapter '%s': hooks removed from agent", self._name)
