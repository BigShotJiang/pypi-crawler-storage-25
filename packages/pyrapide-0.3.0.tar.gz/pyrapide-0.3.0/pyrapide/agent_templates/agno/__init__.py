"""PyRapide adapter for Agno.

Provides ``AgnoAdapter`` which hooks into Agno agents via pre/post hooks
and RunEvent streams to emit causal events for runs, tool calls, and
LLM interactions.

Usage::

    from pyrapide.agent_templates.agno import AgnoAdapter

    adapter = AgnoAdapter("my-agno-app", agent=my_agent)
"""

from pyrapide.agent_templates.agno.adapter import AgnoAdapter

__all__ = ["AgnoAdapter"]
