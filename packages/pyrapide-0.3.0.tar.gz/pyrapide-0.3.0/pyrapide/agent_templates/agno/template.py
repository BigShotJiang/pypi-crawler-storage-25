"""Runnable example: Agno + PyRapide causal event tracking.

Demonstrates how to use the ``AgnoAdapter`` with an Agno agent in both
hook mode and stream mode to observe PyRapide causal events.

Requirements::

    pip install pyrapide agno

Usage::

    python -m agent_templates.agno.template
"""

from __future__ import annotations

import asyncio
import json


async def main() -> None:
    """Run an Agno agent with PyRapide instrumentation."""
    # -- Framework imports (lazy at function scope) ----------------------------
    try:
        from agno.agent import Agent
    except ImportError:
        print(
            "This example requires agno.\n"
            "Install it with: pip install agno"
        )
        return

    from pyrapide.agent_templates.agno import AgnoAdapter

    # -- Define a simple tool --------------------------------------------------
    def get_weather(city: str) -> str:
        """Get the current weather for a city (mock implementation)."""
        return f"The weather in {city} is sunny and 22C."

    def get_time(timezone: str = "UTC") -> str:
        """Get the current time in a timezone (mock implementation)."""
        return f"The current time in {timezone} is 14:30."

    # -- Create the agent and adapter ------------------------------------------
    agent = Agent(
        name="WeatherBot",
        model="gpt-4o-mini",
        tools=[get_weather, get_time],
        instructions="You are a helpful assistant that provides weather information.",
    )

    adapter = AgnoAdapter("agno-demo", agent=agent)

    # -- Hook mode: events captured via pre/post hooks and tool wrappers -------
    print("Running agent (hook mode)...")
    try:
        response = agent.run("What is the weather in Paris?")
        print(f"Response: {response}\n")
    except Exception as exc:
        print(f"Agent run failed (expected if no API key): {exc}\n")

    # -- Inspect captured events -----------------------------------------------
    print("=" * 60)
    print("Captured PyRapide Events (Hook Mode)")
    print("=" * 60)
    computation = adapter.computation
    for event in computation.events:
        print(
            json.dumps(
                {
                    "id": event.id[:12],
                    "type": event.name,
                    "source": event.source,
                    "framework_event": event.payload.get("framework_event_type"),
                },
                indent=2,
            )
        )
    print(f"\nTotal events: {len(computation.events)}")

    # -- Stream mode example (shown conceptually) ------------------------------
    print("\n--- Stream Mode (conceptual) ---")
    print(
        "In stream mode, process events from agent.run_stream():\n"
        "\n"
        "    adapter = AgnoAdapter('stream-demo')\n"
        "    async for event in agent.run_stream('query'):\n"
        "        adapter.on_event(event)\n"
    )

    # -- Clean up --------------------------------------------------------------
    await adapter.close()
    print("Done.")


if __name__ == "__main__":
    asyncio.run(main())
