"""OpenAI Swarm adapter for PyRapide causal event tracking.

Provides a subclass wrapper around the Swarm client that emits causal
events for run lifecycle, tool calls, function results, and agent handoffs.
Events are translated into the unified PyRapide ``AgentEventTypes`` taxonomy.

All Swarm imports are lazy (inside methods) so that users who do not have
``openai-swarm`` installed can still import this module without errors.
"""

from __future__ import annotations

import functools
import logging
from typing import Any, Callable

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)


class SwarmAdapter(BaseAgentAdapter):
    """Adapter that wraps OpenAI Swarm to emit PyRapide causal events.

    Unlike hook-based adapters, Swarm integration works by providing an
    instrumented subclass of ``swarm.Swarm``. The adapter intercepts
    ``run()``, ``handle_tool_calls()``, and ``handle_function_result()``
    to emit the corresponding events.

    Parameters
    ----------
    name:
        Human-readable name for this adapter instance.

    Example::

        from pyrapide.agent_templates.swarm import SwarmAdapter

        adapter = SwarmAdapter("my-swarm-app")
        client = adapter.create_instrumented_client(api_key="sk-...")

        # Use client exactly like swarm.Swarm -- events are captured
        response = client.run(agent=triage_agent, messages=[...])
    """

    def __init__(self, name: str) -> None:
        super().__init__(name, framework_instance=None)

    def _install_hooks(self) -> None:
        """No-op for Swarm -- hooks are structural, not registered.

        Instrumentation is applied when ``create_instrumented_client()``
        or ``wrap_functions()`` is called.
        """
        pass

    def create_instrumented_client(self, **kwargs: Any) -> Any:
        """Create and return an instrumented Swarm client.

        The returned client is a subclass of ``swarm.Swarm`` that emits
        PyRapide events around ``run()``, ``handle_tool_calls()``, and
        ``handle_function_result()``.

        Parameters
        ----------
        **kwargs:
            Keyword arguments forwarded to the ``swarm.Swarm`` constructor
            (e.g. ``client``, ``api_key``).

        Returns
        -------
        InstrumentedSwarm
            A Swarm client with built-in PyRapide event emission.

        Raises
        ------
        ImportError
            If the ``swarm`` package is not installed.
        """
        try:
            from swarm import Swarm
        except ImportError as exc:
            raise ImportError(
                "OpenAI Swarm is required for SwarmAdapter. "
                "Install it with: pip install openai-swarm"
            ) from exc

        adapter = self

        class InstrumentedSwarm(Swarm):
            """Swarm subclass that emits PyRapide events."""

            _pyrapide_adapter: SwarmAdapter = adapter

            def run(
                self,
                agent: Any = None,
                messages: list[dict[str, Any]] | None = None,
                **run_kwargs: Any,
            ) -> Any:
                """Run with RUN_START/RUN_END events around the execution."""
                agent_name = getattr(agent, "name", "unknown")
                msg_count = len(messages) if messages else 0

                self._pyrapide_adapter.emit_scope_start(
                    AgentEventTypes.RUN_START,
                    {
                        "framework": "swarm",
                        "framework_event_type": "run_start",
                        "agent_name": agent_name,
                        "message_count": msg_count,
                    },
                )

                try:
                    result = super().run(
                        agent=agent, messages=messages, **run_kwargs
                    )

                    response_agent = getattr(result, "agent", None)
                    response_agent_name = getattr(
                        response_agent, "name", "unknown"
                    )
                    response_msgs = getattr(result, "messages", [])

                    self._pyrapide_adapter.emit_scope_end(
                        AgentEventTypes.RUN_END,
                        {
                            "framework": "swarm",
                            "framework_event_type": "run_end",
                            "final_agent": response_agent_name,
                            "response_message_count": len(response_msgs),
                        },
                    )
                    return result

                except Exception as exc:
                    self._pyrapide_adapter.emit_scope_end(
                        AgentEventTypes.RUN_END,
                        {
                            "framework": "swarm",
                            "framework_event_type": "run_error",
                            "error": str(exc),
                            "error_type": type(exc).__name__,
                        },
                    )
                    raise

            def handle_tool_calls(
                self,
                tool_calls: Any,
                functions: list[Callable[..., Any]] | None = None,
                **hc_kwargs: Any,
            ) -> Any:
                """Emit TOOL_CALL/TOOL_RESULT around each tool call."""
                if tool_calls:
                    for tc in tool_calls:
                        func_name = getattr(
                            getattr(tc, "function", None), "name", "unknown"
                        )
                        func_args = getattr(
                            getattr(tc, "function", None), "arguments", ""
                        )
                        self._pyrapide_adapter.emit(
                            AgentEventTypes.TOOL_CALL,
                            {
                                "framework": "swarm",
                                "framework_event_type": "tool_call",
                                "tool_name": func_name,
                                "tool_call_id": getattr(tc, "id", None),
                                "arguments": str(func_args)[:500],
                            },
                        )

                result = super().handle_tool_calls(
                    tool_calls, functions=functions, **hc_kwargs
                )

                # Emit TOOL_RESULT for the batch
                if tool_calls:
                    result_messages = result if isinstance(result, list) else [result]
                    for msg in result_messages:
                        tool_call_id = (
                            msg.get("tool_call_id")
                            if isinstance(msg, dict)
                            else getattr(msg, "tool_call_id", None)
                        )
                        content = (
                            msg.get("content", "")
                            if isinstance(msg, dict)
                            else getattr(msg, "content", "")
                        )
                        self._pyrapide_adapter.emit(
                            AgentEventTypes.TOOL_RESULT,
                            {
                                "framework": "swarm",
                                "framework_event_type": "tool_result",
                                "tool_call_id": tool_call_id,
                                "result_preview": str(content)[:500],
                            },
                        )

                return result

            def handle_function_result(self, result: Any, debug: bool = False) -> Any:
                """Detect agent handoffs from function results."""
                # Lazy import to check if result is an Agent
                try:
                    from swarm import Agent
                except ImportError:
                    Agent = None

                if Agent is not None and isinstance(result, Agent):
                    self._pyrapide_adapter.emit(
                        AgentEventTypes.AGENT_HANDOFF,
                        {
                            "framework": "swarm",
                            "framework_event_type": "agent_handoff",
                            "target_agent": getattr(result, "name", "unknown"),
                        },
                    )

                return super().handle_function_result(result, debug=debug)

        return InstrumentedSwarm(**kwargs)

    def wrap_functions(self, agent: Any) -> None:
        """Wrap each function in an Agent's functions list with emit decorators.

        This provides fine-grained per-function instrumentation in addition
        to the batch-level instrumentation from ``handle_tool_calls()``.

        Parameters
        ----------
        agent:
            A ``swarm.Agent`` instance whose ``functions`` list will be
            wrapped in-place.
        """
        functions = getattr(agent, "functions", None)
        if not functions:
            logger.debug(
                "SwarmAdapter: agent has no functions to wrap"
            )
            return

        adapter = self

        for i, func in enumerate(functions):
            if not callable(func):
                continue

            func_name = getattr(func, "__name__", f"function_{i}")

            @functools.wraps(func)
            def instrumented_func(
                *args: Any,
                _orig_func: Callable[..., Any] = func,
                _func_name: str = func_name,
                **kwargs: Any,
            ) -> Any:
                adapter.emit(
                    AgentEventTypes.TOOL_CALL,
                    {
                        "framework": "swarm",
                        "framework_event_type": "function_call",
                        "tool_name": _func_name,
                        "args": str(args)[:500] if args else None,
                        "kwargs": str(kwargs)[:500] if kwargs else None,
                    },
                )
                try:
                    result = _orig_func(*args, **kwargs)

                    # Check for agent handoff
                    is_agent = False
                    try:
                        from swarm import Agent

                        is_agent = isinstance(result, Agent)
                    except ImportError:
                        pass

                    if is_agent:
                        adapter.emit(
                            AgentEventTypes.AGENT_HANDOFF,
                            {
                                "framework": "swarm",
                                "framework_event_type": "function_handoff",
                                "source_function": _func_name,
                                "target_agent": getattr(
                                    result, "name", "unknown"
                                ),
                            },
                        )
                    else:
                        adapter.emit(
                            AgentEventTypes.TOOL_RESULT,
                            {
                                "framework": "swarm",
                                "framework_event_type": "function_result",
                                "tool_name": _func_name,
                                "result_preview": str(result)[:500]
                                if result
                                else None,
                            },
                        )
                    return result

                except Exception as exc:
                    adapter.emit(
                        AgentEventTypes.TOOL_ERROR,
                        {
                            "framework": "swarm",
                            "framework_event_type": "function_error",
                            "tool_name": _func_name,
                            "error": str(exc),
                            "error_type": type(exc).__name__,
                        },
                    )
                    raise

            functions[i] = instrumented_func

        logger.info(
            "SwarmAdapter '%s': wrapped %d functions on agent '%s'",
            self._name,
            len(functions),
            getattr(agent, "name", "unknown"),
        )

    def _uninstall_hooks(self) -> None:
        """No-op -- structural instrumentation cannot be reverted.

        Once an instrumented client or wrapped functions are in use,
        they continue to emit events until they are garbage collected.
        """
        pass
