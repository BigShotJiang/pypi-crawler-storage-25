# PyRapide + OpenAI Swarm Integration

> Causal event tracking for OpenAI Swarm via InstrumentedSwarm subclass.

**Docs:** [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) | **Siblings:** [agno](../agno/INTEGRATION.md) | [metagpt](../metagpt/INTEGRATION.md) | [flowise](../flowise/INTEGRATION.md)

**Note:** OpenAI Swarm is deprecated in favor of the OpenAI Agents SDK. This adapter remains available for existing Swarm-based projects.

---

## Quick Start

```python
from swarm import Agent
from pyrapide.agent_templates.swarm import SwarmAdapter

adapter = SwarmAdapter("my-swarm")
client = adapter.create_instrumented_client(api_key="sk-...")

# Use client exactly like swarm.Swarm -- events captured automatically
triage_agent = Agent(name="Triage", functions=[transfer_to_sales])
response = client.run(agent=triage_agent, messages=[{"role": "user", "content": "Hello"}])

# Optional: wrap individual agent functions for fine-grained tracking
adapter.wrap_functions(triage_agent)

# Analyze causal graph
comp = adapter.computation
for event in comp.events:
    print(event.name, event.payload)
```

---

## Prerequisites

```bash
pip install pyrapide openai-swarm
```

---

## How It Works

SwarmAdapter creates an `InstrumentedSwarm` -- a subclass of `swarm.Swarm` that intercepts `run()`, `handle_tool_calls()`, and `handle_function_result()`. The instrumented client is a drop-in replacement: pass it everywhere you would use a regular Swarm client.

The `run()` method emits `RUN_START`/`RUN_END` scope events. Inside each run, `handle_tool_calls()` emits `TOOL_CALL` and `TOOL_RESULT` for every tool invocation. When `handle_function_result()` detects that a function returned an `Agent` instance (Swarm's handoff mechanism), it emits `AGENT_HANDOFF`. For even finer control, `wrap_functions(agent)` instruments each function in an agent's `functions` list individually.

---

## Event Mapping

| Swarm Event | PyRapide Event | Causal Link |
|---|---|---|
| `run()` entry | `agent.run.start` | Scope push -- becomes parent of all nested events |
| `run()` exit | `agent.run.end` | Scope pop -- closes the run scope |
| `handle_tool_calls()` per tool | `agent.tool.call` | Child of run scope, one per tool call in the batch |
| `handle_tool_calls()` result | `agent.tool.result` | Child of run scope, correlated to its TOOL_CALL |
| `handle_function_result()` returning `Agent` | `agent.handoff` | Child of run scope; signals agent transfer |
| Tool raises exception | `agent.tool.error` | Child of run scope |

---

## Full Example

```python
import asyncio
from swarm import Agent
from pyrapide.agent_templates.swarm import SwarmAdapter
from pyrapide import queries

def transfer_to_sales():
    """Transfer to the sales agent."""
    return sales_agent

def transfer_to_support():
    """Transfer to the support agent."""
    return support_agent

def lookup_order(order_id: str) -> str:
    """Look up an order by ID."""
    return f"Order {order_id}: shipped, arriving tomorrow."

def check_inventory(product: str) -> str:
    """Check product inventory."""
    return f"'{product}' is in stock (42 units)."

sales_agent = Agent(name="Sales", functions=[check_inventory])
support_agent = Agent(name="Support", functions=[lookup_order])
triage_agent = Agent(
    name="Triage",
    instructions="Route customers to Sales or Support.",
    functions=[transfer_to_sales, transfer_to_support],
)

async def main():
    adapter = SwarmAdapter("swarm-demo")

    # Wrap functions for per-function tracking
    adapter.wrap_functions(triage_agent)
    adapter.wrap_functions(sales_agent)
    adapter.wrap_functions(support_agent)

    # Create instrumented client and run
    client = adapter.create_instrumented_client()
    response = client.run(
        agent=triage_agent,
        messages=[{"role": "user", "content": "Check on order #12345"}],
    )

    # Analyze
    comp = adapter.computation
    print(f"Final agent: {response.agent.name}")
    print(f"Captured {len(comp.events)} events")

    # Show causal graph
    for event in comp.events:
        parents = comp.parents_of(event)
        parent_str = ", ".join(p.id[:8] for p in parents) if parents else "root"
        print(f"  {event.id[:8]} {event.name} <- [{parent_str}]")

    await adapter.close()

asyncio.run(main())
```

---

## Adding Constraints

```python
from pyrapide import must_match, never, Pattern

# Every tool call must produce a result, error, or handoff
must_match(
    adapter.computation,
    Pattern("agent.tool.call") >> (
        Pattern("agent.tool.result") | Pattern("agent.tool.error") | Pattern("agent.handoff")
    ),
    "Every tool call must resolve",
)

# Agent handoffs should never happen without a preceding tool call
never(
    adapter.computation,
    Pattern("agent.handoff") & ~Pattern("agent.tool.call").before(),
    "Handoff without a preceding tool call",
)
```

---

## Post-Run Analysis

```python
comp = adapter.computation

# Find all handoff events and their causal chains
handoffs = [e for e in comp.events if e.name == "agent.handoff"]
for h in handoffs:
    chain = queries.causal_chain(comp, h)
    print(f"Handoff to {h.payload['target_agent']}:")
    for step in chain:
        print(f"  <- {step.name} ({step.source})")

# Root cause analysis for errors
errors = [e for e in comp.events if "error" in e.name]
for err in errors:
    causes = queries.root_causes(comp, err)
    print(f"Error root causes: {[c.name for c in causes]}")

# Visualize
from pyrapide import visualize
visualize.to_dot(comp, output="swarm_trace.png")
visualize.to_json(comp, output="swarm_trace.json")
```

---

## API Reference

```python
class SwarmAdapter(BaseAgentAdapter):
    def __init__(self, name: str) -> None
        # name: human-readable adapter name (appears in event source)

    def create_instrumented_client(self, **kwargs) -> InstrumentedSwarm
        # Returns a swarm.Swarm subclass with built-in event emission.
        # **kwargs forwarded to Swarm() constructor (e.g. api_key, client).

    def wrap_functions(self, agent: swarm.Agent) -> None
        # Wrap each function in agent.functions with emit decorators.
        # Provides per-function TOOL_CALL/TOOL_RESULT/TOOL_ERROR events.

    # Inherited from BaseAgentAdapter:
    @property
    def computation(self) -> Computation
    @property
    def tracker(self) -> CausalTracker
    def emit(self, event_type, payload, ...) -> Event
    async def events(self) -> AsyncIterator[Event]  # EventSource protocol
    async def close(self) -> None
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `ImportError: swarm` | Run `pip install openai-swarm` |
| No events from `run()` | Ensure you use `adapter.create_instrumented_client()`, not `swarm.Swarm()` directly |
| No per-function events | Call `adapter.wrap_functions(agent)` before running the client |
| Handoffs not detected | The adapter checks `isinstance(result, Agent)` -- ensure your handoff functions return `Agent` instances |
| Cannot uninstall hooks | Swarm instrumentation is structural (subclass-based) and cannot be reverted at runtime |
| Deprecation warning | Swarm is deprecated; consider migrating to the OpenAI Agents SDK |

---

## Related Files

- [`adapter.py`](./adapter.py) -- SwarmAdapter and InstrumentedSwarm implementation
- [`template.py`](./template.py) -- runnable example script
- [`core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`core/event_types.py`](../core/event_types.py) -- unified AgentEventTypes constants
- [`core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker scope management
- [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) -- full PyRapide docs
