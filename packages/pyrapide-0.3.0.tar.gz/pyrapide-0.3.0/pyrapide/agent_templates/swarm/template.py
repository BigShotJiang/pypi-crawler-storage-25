"""Runnable example: OpenAI Swarm + PyRapide causal event tracking.

Demonstrates how to use the ``SwarmAdapter`` to create an instrumented
Swarm client and observe PyRapide causal events for runs, tool calls,
and agent handoffs.

Requirements::

    pip install pyrapide openai-swarm

Usage::

    python -m agent_templates.swarm.template
"""

from __future__ import annotations

import asyncio
import json


async def main() -> None:
    """Run an OpenAI Swarm workflow with PyRapide instrumentation."""
    # -- Framework imports (lazy at function scope) ----------------------------
    try:
        from swarm import Agent
    except ImportError:
        print(
            "This example requires openai-swarm.\n"
            "Install it with: pip install openai-swarm"
        )
        return

    from pyrapide.agent_templates.swarm import SwarmAdapter

    # -- Define tools and agents -----------------------------------------------
    def transfer_to_sales() -> Agent:
        """Transfer the conversation to the sales agent."""
        return sales_agent

    def transfer_to_support() -> Agent:
        """Transfer the conversation to the support agent."""
        return support_agent

    def lookup_order(order_id: str) -> str:
        """Look up an order by ID (mock implementation)."""
        return f"Order {order_id}: shipped, arriving tomorrow."

    def check_inventory(product: str) -> str:
        """Check inventory for a product (mock implementation)."""
        return f"Product '{product}' is in stock (42 units available)."

    # Define the agents
    sales_agent = Agent(
        name="Sales",
        instructions="You help customers with purchases and product inquiries.",
        functions=[check_inventory],
    )

    support_agent = Agent(
        name="Support",
        instructions="You help customers with order issues and returns.",
        functions=[lookup_order],
    )

    triage_agent = Agent(
        name="Triage",
        instructions=(
            "You route customers to the right department. "
            "Transfer to Sales for purchases, Support for order issues."
        ),
        functions=[transfer_to_sales, transfer_to_support],
    )

    # -- Create the adapter and instrumented client ----------------------------
    adapter = SwarmAdapter("swarm-demo")

    # Wrap individual agent functions for fine-grained tracking
    adapter.wrap_functions(triage_agent)
    adapter.wrap_functions(sales_agent)
    adapter.wrap_functions(support_agent)

    # Create the instrumented Swarm client
    print("Creating instrumented Swarm client...")
    try:
        client = adapter.create_instrumented_client()
    except ImportError:
        print("Could not create Swarm client (package not installed).")
        return

    # -- Run the workflow (events are captured automatically) -------------------
    print("Running Swarm workflow...")
    messages = [{"role": "user", "content": "I want to check on my order #12345"}]
    try:
        response = client.run(agent=triage_agent, messages=messages)
        print(f"Final agent: {response.agent.name}")
        for msg in response.messages:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if content:
                print(f"  [{role}]: {content[:100]}")
        print()
    except Exception as exc:
        print(f"Swarm run failed (expected if no API key): {exc}\n")

    # -- Inspect captured events -----------------------------------------------
    print("=" * 60)
    print("Captured PyRapide Events")
    print("=" * 60)
    computation = adapter.computation
    for event in computation.events:
        print(
            json.dumps(
                {
                    "id": event.id[:12],
                    "type": event.name,
                    "source": event.source,
                    "framework_event": event.payload.get("framework_event_type"),
                    "detail": (
                        event.payload.get("tool_name")
                        or event.payload.get("agent_name")
                        or event.payload.get("target_agent")
                    ),
                },
                indent=2,
            )
        )
    print(f"\nTotal events: {len(computation.events)}")

    # -- Show causal relationships ---------------------------------------------
    if computation.events:
        print("\n--- Causal Graph ---")
        for event in computation.events:
            parents = computation.parents_of(event)
            if parents:
                parent_ids = ", ".join(p.id[:12] for p in parents)
                print(f"  {event.id[:12]} ({event.name}) <- [{parent_ids}]")
            else:
                print(f"  {event.id[:12]} ({event.name}) <- [root]")

    # -- Clean up --------------------------------------------------------------
    await adapter.close()
    print("\nDone.")


if __name__ == "__main__":
    asyncio.run(main())
