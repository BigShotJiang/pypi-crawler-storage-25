"""PyRapide adapter for OpenAI Swarm.

Provides ``SwarmAdapter`` which wraps the Swarm client to emit causal
events for runs, tool calls, function results, and agent handoffs.

Usage::

    from pyrapide.agent_templates.swarm import SwarmAdapter

    adapter = SwarmAdapter("my-swarm-app")
    client = adapter.create_instrumented_client()
"""

from pyrapide.agent_templates.swarm.adapter import SwarmAdapter

__all__ = ["SwarmAdapter"]
