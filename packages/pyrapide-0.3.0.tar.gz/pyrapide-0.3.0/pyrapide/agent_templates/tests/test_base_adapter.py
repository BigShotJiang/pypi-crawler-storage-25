"""Tests for agent_templates.core.base_adapter.BaseAgentAdapter."""

from __future__ import annotations

import asyncio
from typing import Any

import pytest

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes


class StubAdapter(BaseAgentAdapter):
    """Minimal concrete adapter for testing the base class."""

    def __init__(self, name: str = "test-adapter") -> None:
        super().__init__(name)
        self.hooks_installed_count = 0
        self.hooks_uninstalled_count = 0

    def _install_hooks(self) -> None:
        self.hooks_installed_count += 1

    def _uninstall_hooks(self) -> None:
        self.hooks_uninstalled_count += 1


class TestEmit:
    """Tests for BaseAgentAdapter.emit()."""

    def test_emit_creates_event_with_correct_fields(self) -> None:
        adapter = StubAdapter()
        event = adapter.emit(
            AgentEventTypes.TOOL_CALL,
            {"tool_name": "search", "query": "hello"},
            source="my-agent",
            metadata={"extra_key": "extra_val"},
        )

        assert isinstance(event, Event)
        assert event.name == AgentEventTypes.TOOL_CALL
        assert event.payload["tool_name"] == "search"
        assert event.payload["query"] == "hello"
        assert event.source == "my-agent"
        assert event.metadata["extra_key"] == "extra_val"

    def test_emit_uses_adapter_name_as_default_source(self) -> None:
        adapter = StubAdapter("my-adapter")
        event = adapter.emit(AgentEventTypes.LLM_REQUEST, {"model": "gpt-4"})

        assert event.source == "my-adapter"

    def test_emit_stores_correlation_id_in_metadata(self) -> None:
        adapter = StubAdapter()
        event = adapter.emit(
            AgentEventTypes.TOOL_CALL,
            {},
            correlation_id="corr-123",
        )

        assert event.metadata["correlation_id"] == "corr-123"

    def test_emit_stores_parent_id_in_metadata(self) -> None:
        adapter = StubAdapter()
        parent = adapter.emit(AgentEventTypes.LLM_REQUEST, {})
        child = adapter.emit(
            AgentEventTypes.LLM_RESPONSE,
            {},
            parent_id=parent.id,
        )

        assert child.metadata["parent_id"] == parent.id

    def test_emit_with_invalid_event_type_raises(self) -> None:
        adapter = StubAdapter()
        with pytest.raises(ValueError, match="Unknown event type"):
            adapter.emit("invalid.event.type", {})

    def test_emit_registers_event_in_computation(self) -> None:
        adapter = StubAdapter()
        event = adapter.emit(AgentEventTypes.RUN_START, {})

        assert event in adapter.computation.events

    def test_emit_enqueues_event(self) -> None:
        adapter = StubAdapter()
        adapter.emit(AgentEventTypes.TOOL_CALL, {})

        assert not adapter._queue.empty()
        item = adapter._queue.get_nowait()
        assert isinstance(item, Event)
        assert item.name == AgentEventTypes.TOOL_CALL


class TestScopeEmit:
    """Tests for emit_scope_start() and emit_scope_end()."""

    def test_scope_start_pushes_scope(self) -> None:
        adapter = StubAdapter()
        event = adapter.emit_scope_start(AgentEventTypes.RUN_START, {})

        assert adapter.tracker.current_scope is event

    def test_scope_end_pops_scope(self) -> None:
        adapter = StubAdapter()
        adapter.emit_scope_start(AgentEventTypes.RUN_START, {})
        adapter.emit_scope_end(AgentEventTypes.RUN_END, {})

        assert adapter.tracker.current_scope is None

    def test_nested_scope_management(self) -> None:
        adapter = StubAdapter()
        run_start = adapter.emit_scope_start(AgentEventTypes.RUN_START, {})
        step_start = adapter.emit_scope_start(AgentEventTypes.STEP_START, {})

        assert adapter.tracker.current_scope is step_start

        adapter.emit_scope_end(AgentEventTypes.STEP_END, {})
        assert adapter.tracker.current_scope is run_start

        adapter.emit_scope_end(AgentEventTypes.RUN_END, {})
        assert adapter.tracker.current_scope is None

    def test_events_within_scope_are_parented(self) -> None:
        adapter = StubAdapter()
        scope = adapter.emit_scope_start(AgentEventTypes.RUN_START, {})
        child = adapter.emit(AgentEventTypes.AGENT_MESSAGE, {})

        comp = adapter.computation
        assert comp.is_ancestor(scope, child)


class TestEventsIterator:
    """Tests for the events() async iterator."""

    @pytest.mark.asyncio
    async def test_events_yields_emitted_events(self) -> None:
        adapter = StubAdapter()

        async def producer() -> None:
            adapter.emit(AgentEventTypes.RUN_START, {"step": 1})
            adapter.emit(AgentEventTypes.RUN_END, {"step": 2})
            await adapter.close()

        collected: list[Event] = []

        async def consumer() -> None:
            async for event in adapter.events():
                collected.append(event)

        await asyncio.gather(producer(), consumer())

        assert len(collected) == 2
        assert collected[0].name == AgentEventTypes.RUN_START
        assert collected[1].name == AgentEventTypes.RUN_END

    @pytest.mark.asyncio
    async def test_events_stops_on_close(self) -> None:
        adapter = StubAdapter()

        async def producer() -> None:
            adapter.emit(AgentEventTypes.TOOL_CALL, {})
            await adapter.close()

        collected: list[Event] = []

        async def consumer() -> None:
            async for event in adapter.events():
                collected.append(event)

        await asyncio.gather(producer(), consumer())

        # After close, the iterator should have stopped
        assert len(collected) == 1

    @pytest.mark.asyncio
    async def test_events_installs_hooks_on_first_call(self) -> None:
        adapter = StubAdapter()
        assert adapter.hooks_installed_count == 0

        async def run() -> None:
            adapter.emit(AgentEventTypes.RUN_START, {})
            await adapter.close()

        async def consume() -> None:
            async for _ in adapter.events():
                pass

        await asyncio.gather(run(), consume())

        assert adapter.hooks_installed_count == 1


class TestComputationProperty:
    """Tests for the computation property."""

    def test_computation_returns_tracker_computation(self) -> None:
        adapter = StubAdapter()
        assert isinstance(adapter.computation, Computation)

    def test_computation_accumulates_events(self) -> None:
        adapter = StubAdapter()
        adapter.emit(AgentEventTypes.LLM_REQUEST, {})
        adapter.emit(AgentEventTypes.LLM_RESPONSE, {})
        adapter.emit(AgentEventTypes.TOOL_CALL, {})

        assert len(adapter.computation) == 3


class TestClose:
    """Tests for the close() method."""

    @pytest.mark.asyncio
    async def test_close_uninstalls_hooks(self) -> None:
        adapter = StubAdapter()
        adapter._hooks_installed = True

        await adapter.close()

        assert adapter.hooks_uninstalled_count == 1
        assert not adapter._hooks_installed

    @pytest.mark.asyncio
    async def test_close_enqueues_none_sentinel(self) -> None:
        adapter = StubAdapter()
        await adapter.close()

        item = adapter._queue.get_nowait()
        assert item is None


class TestNameProperty:
    """Tests for the name property."""

    def test_name_returns_adapter_name(self) -> None:
        adapter = StubAdapter("my-adapter")
        assert adapter.name == "my-adapter"
