"""Tests for agent_templates.core.event_types."""

from __future__ import annotations

import pytest

from pyrapide.agent_templates.core.event_types import AgentEventTypes, ALL_EVENT_TYPES


class TestAgentEventTypes:
    """Verify the AgentEventTypes constants and ALL_EVENT_TYPES set."""

    def _all_constants(self) -> list[tuple[str, str]]:
        """Return all (attr_name, value) pairs from AgentEventTypes."""
        return [
            (k, v)
            for k, v in vars(AgentEventTypes).items()
            if not k.startswith("_") and isinstance(v, str)
        ]

    def test_all_constants_are_strings(self) -> None:
        """Every public constant must be a str."""
        for attr_name, value in self._all_constants():
            assert isinstance(value, str), (
                f"AgentEventTypes.{attr_name} is {type(value).__name__}, expected str"
            )

    def test_all_constants_are_unique(self) -> None:
        """No two constants may share the same string value."""
        values = [v for _, v in self._all_constants()]
        assert len(values) == len(set(values)), (
            f"Duplicate values found: {[v for v in values if values.count(v) > 1]}"
        )

    def test_all_event_types_contains_all_constants(self) -> None:
        """ALL_EVENT_TYPES must include every public constant."""
        for attr_name, value in self._all_constants():
            assert value in ALL_EVENT_TYPES, (
                f"AgentEventTypes.{attr_name} = {value!r} is missing from ALL_EVENT_TYPES"
            )

    def test_all_event_types_has_no_extras(self) -> None:
        """ALL_EVENT_TYPES must not contain values beyond the defined constants."""
        constant_values = {v for _, v in self._all_constants()}
        extras = ALL_EVENT_TYPES - constant_values
        assert not extras, f"ALL_EVENT_TYPES contains unexpected values: {extras}"

    def test_all_event_types_is_frozenset(self) -> None:
        """ALL_EVENT_TYPES must be immutable."""
        assert isinstance(ALL_EVENT_TYPES, frozenset)

    def test_naming_convention(self) -> None:
        """Every constant must follow the 'agent.*' naming convention."""
        for attr_name, value in self._all_constants():
            assert value.startswith("agent."), (
                f"AgentEventTypes.{attr_name} = {value!r} does not start with 'agent.'"
            )

    def test_naming_convention_three_parts(self) -> None:
        """Every constant must have at least three dot-separated segments."""
        for attr_name, value in self._all_constants():
            parts = value.split(".")
            assert len(parts) >= 3, (
                f"AgentEventTypes.{attr_name} = {value!r} has fewer than 3 segments"
            )

    def test_expected_constants_present(self) -> None:
        """Verify the minimum set of expected constants exists."""
        expected = [
            "TOOL_CALL", "TOOL_RESULT", "TOOL_ERROR",
            "LLM_REQUEST", "LLM_RESPONSE", "LLM_STREAM", "LLM_ERROR",
            "AGENT_MESSAGE", "AGENT_HANDOFF",
            "TASK_START", "TASK_END", "TASK_ERROR",
            "STEP_START", "STEP_END",
            "RUN_START", "RUN_END",
        ]
        for name in expected:
            assert hasattr(AgentEventTypes, name), (
                f"AgentEventTypes is missing expected constant {name}"
            )

    def test_constant_count(self) -> None:
        """Sanity check: there should be at least 16 event types."""
        assert len(ALL_EVENT_TYPES) >= 16
