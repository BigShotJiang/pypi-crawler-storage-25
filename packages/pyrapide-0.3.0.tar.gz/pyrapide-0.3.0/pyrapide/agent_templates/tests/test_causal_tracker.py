"""Tests for agent_templates.core.causal_tracker.CausalTracker."""

from __future__ import annotations

import pytest

from pyrapide.core.event import Event

from pyrapide.agent_templates.core.causal_tracker import CausalTracker
from pyrapide.agent_templates.core.event_types import AgentEventTypes


class TestExplicitParentLinking:
    """Mechanism 1: explicit parent_id."""

    def test_explicit_parent_creates_causal_link(self, tracker: CausalTracker) -> None:
        parent = Event(name=AgentEventTypes.LLM_REQUEST, payload={}, source="test")
        child = Event(name=AgentEventTypes.LLM_RESPONSE, payload={}, source="test")

        tracker.record(parent)
        tracker.record(child, parent_id=parent.id)

        comp = tracker.computation
        assert comp.is_ancestor(parent, child)

    def test_explicit_parent_unknown_id_ignored(self, tracker: CausalTracker) -> None:
        """An unknown parent_id should not crash -- the event is still recorded."""
        event = Event(name=AgentEventTypes.LLM_REQUEST, payload={}, source="test")
        tracker.record(event, parent_id="nonexistent-id")

        assert event in tracker.computation.events

    def test_explicit_parent_takes_priority_over_inference(self, tracker: CausalTracker) -> None:
        """Explicit parent_id should be used even if inference would suggest another."""
        llm_resp = Event(name=AgentEventTypes.LLM_RESPONSE, payload={}, source="test")
        explicit_parent = Event(name=AgentEventTypes.STEP_START, payload={}, source="test")
        tool_call = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")

        tracker.record(llm_resp)
        tracker.record(explicit_parent)
        tracker.record(tool_call, parent_id=explicit_parent.id)

        comp = tracker.computation
        # The explicit parent should be the ancestor, not the inferred LLM_RESPONSE
        assert comp.is_ancestor(explicit_parent, tool_call)


class TestCorrelationGroupLinking:
    """Mechanism 2: correlation_id groups."""

    def test_first_event_in_group_is_root(self, tracker: CausalTracker) -> None:
        first = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")
        second = Event(name=AgentEventTypes.TOOL_RESULT, payload={}, source="test")

        tracker.record(first, correlation_id="grp1")
        tracker.record(second, correlation_id="grp1")

        comp = tracker.computation
        assert comp.is_ancestor(first, second)

    def test_multiple_events_in_group_parent_to_root(self, tracker: CausalTracker) -> None:
        root = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        child1 = Event(name=AgentEventTypes.STEP_START, payload={}, source="test")
        child2 = Event(name=AgentEventTypes.STEP_END, payload={}, source="test")

        tracker.record(root, correlation_id="run-1")
        tracker.record(child1, correlation_id="run-1")
        tracker.record(child2, correlation_id="run-1")

        comp = tracker.computation
        assert comp.is_ancestor(root, child1)
        assert comp.is_ancestor(root, child2)

    def test_separate_correlation_groups_independent(self, tracker: CausalTracker) -> None:
        a1 = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")
        a2 = Event(name=AgentEventTypes.TOOL_RESULT, payload={}, source="test")
        b1 = Event(name=AgentEventTypes.LLM_REQUEST, payload={}, source="test")
        b2 = Event(name=AgentEventTypes.LLM_RESPONSE, payload={}, source="test")

        tracker.record(a1, correlation_id="grp-a")
        tracker.record(b1, correlation_id="grp-b")
        tracker.record(a2, correlation_id="grp-a")
        tracker.record(b2, correlation_id="grp-b")

        comp = tracker.computation
        assert comp.is_ancestor(a1, a2)
        assert comp.is_ancestor(b1, b2)
        assert comp.are_independent(a1, b1)


class TestScopeStack:
    """Mechanism 3: scope stack auto-parenting."""

    def test_events_within_scope_parented_to_scope_event(self, tracker: CausalTracker) -> None:
        scope = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        child = Event(name=AgentEventTypes.AGENT_MESSAGE, payload={}, source="test")

        tracker.record(scope)
        tracker.push_scope(scope)
        tracker.record(child)

        comp = tracker.computation
        assert comp.is_ancestor(scope, child)

    def test_nested_scopes(self, tracker: CausalTracker) -> None:
        run_start = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        step_start = Event(name=AgentEventTypes.STEP_START, payload={}, source="test")
        inner_event = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")

        tracker.record(run_start)
        tracker.push_scope(run_start)
        tracker.record(step_start)
        tracker.push_scope(step_start)
        tracker.record(inner_event)

        comp = tracker.computation
        # inner_event should be parented to step_start (innermost scope)
        assert comp.is_ancestor(step_start, inner_event)
        # step_start should be parented to run_start (outer scope)
        assert comp.is_ancestor(run_start, step_start)

    def test_pop_scope_returns_correct_event(self, tracker: CausalTracker) -> None:
        scope = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        tracker.record(scope)
        tracker.push_scope(scope)

        popped = tracker.pop_scope()
        assert popped is scope

    def test_pop_empty_scope_returns_none(self, tracker: CausalTracker) -> None:
        assert tracker.pop_scope() is None

    def test_current_scope_reflects_stack(self, tracker: CausalTracker) -> None:
        assert tracker.current_scope is None

        scope1 = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        tracker.record(scope1)
        tracker.push_scope(scope1)
        assert tracker.current_scope is scope1

        scope2 = Event(name=AgentEventTypes.STEP_START, payload={}, source="test")
        tracker.record(scope2)
        tracker.push_scope(scope2)
        assert tracker.current_scope is scope2

        tracker.pop_scope()
        assert tracker.current_scope is scope1


class TestInferredSequentialCausality:
    """Mechanism 4: heuristic inference rules."""

    def test_tool_call_caused_by_llm_response(self, tracker: CausalTracker) -> None:
        llm_resp = Event(name=AgentEventTypes.LLM_RESPONSE, payload={}, source="test")
        tool_call = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")

        tracker.record(llm_resp)
        tracker.record(tool_call)

        comp = tracker.computation
        assert comp.is_ancestor(llm_resp, tool_call)

    def test_llm_request_caused_by_tool_result(self, tracker: CausalTracker) -> None:
        tool_result = Event(name=AgentEventTypes.TOOL_RESULT, payload={}, source="test")
        llm_req = Event(name=AgentEventTypes.LLM_REQUEST, payload={}, source="test")

        tracker.record(tool_result)
        tracker.record(llm_req)

        comp = tracker.computation
        assert comp.is_ancestor(tool_result, llm_req)

    def test_agent_handoff_caused_by_llm_response(self, tracker: CausalTracker) -> None:
        llm_resp = Event(name=AgentEventTypes.LLM_RESPONSE, payload={}, source="test")
        handoff = Event(name=AgentEventTypes.AGENT_HANDOFF, payload={}, source="test")

        tracker.record(llm_resp)
        tracker.record(handoff)

        comp = tracker.computation
        assert comp.is_ancestor(llm_resp, handoff)

    def test_tool_error_caused_by_tool_call(self, tracker: CausalTracker) -> None:
        tool_call = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")
        tool_error = Event(name=AgentEventTypes.TOOL_ERROR, payload={}, source="test")

        tracker.record(tool_call)
        tracker.record(tool_error)

        comp = tracker.computation
        assert comp.is_ancestor(tool_call, tool_error)

    def test_llm_request_falls_back_to_tool_error(self, tracker: CausalTracker) -> None:
        """If no TOOL_RESULT exists, LLM_REQUEST should infer from TOOL_ERROR."""
        tool_error = Event(name=AgentEventTypes.TOOL_ERROR, payload={}, source="test")
        llm_req = Event(name=AgentEventTypes.LLM_REQUEST, payload={}, source="test")

        tracker.record(tool_error)
        tracker.record(llm_req)

        comp = tracker.computation
        assert comp.is_ancestor(tool_error, llm_req)


class TestMultipleMechanismsCombined:
    """Test interactions between all causal linking mechanisms."""

    def test_explicit_parent_with_scope_active(self, tracker: CausalTracker) -> None:
        """Explicit parent should take precedence over scope."""
        scope = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        parent = Event(name=AgentEventTypes.LLM_RESPONSE, payload={}, source="test")
        child = Event(name=AgentEventTypes.AGENT_MESSAGE, payload={}, source="test")

        tracker.record(scope)
        tracker.push_scope(scope)
        tracker.record(parent)
        tracker.record(child, parent_id=parent.id)

        comp = tracker.computation
        assert comp.is_ancestor(parent, child)

    def test_correlation_with_scope_active(self, tracker: CausalTracker) -> None:
        """Correlation should take precedence over scope when set."""
        scope = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        corr_root = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")
        corr_child = Event(name=AgentEventTypes.TOOL_RESULT, payload={}, source="test")

        tracker.record(scope)
        tracker.push_scope(scope)
        tracker.record(corr_root, correlation_id="pair-1")
        tracker.record(corr_child, correlation_id="pair-1")

        comp = tracker.computation
        assert comp.is_ancestor(corr_root, corr_child)

    def test_full_agent_loop(self, tracker: CausalTracker) -> None:
        """Simulate a realistic agent loop: run > step > llm > tool > llm."""
        run = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        tracker.record(run)
        tracker.push_scope(run)

        step = Event(name=AgentEventTypes.STEP_START, payload={}, source="test")
        tracker.record(step)
        tracker.push_scope(step)

        llm_req = Event(name=AgentEventTypes.LLM_REQUEST, payload={}, source="test")
        tracker.record(llm_req)

        llm_resp = Event(name=AgentEventTypes.LLM_RESPONSE, payload={}, source="test")
        tracker.record(llm_resp)

        tool_call = Event(name=AgentEventTypes.TOOL_CALL, payload={}, source="test")
        tracker.record(tool_call)

        tool_result = Event(name=AgentEventTypes.TOOL_RESULT, payload={}, source="test")
        tracker.record(tool_result)

        tracker.pop_scope()
        step_end = Event(name=AgentEventTypes.STEP_END, payload={}, source="test")
        tracker.record(step_end)

        tracker.pop_scope()
        run_end = Event(name=AgentEventTypes.RUN_END, payload={}, source="test")
        tracker.record(run_end)

        comp = tracker.computation
        assert len(comp) == 8

        # Scope relationships
        assert comp.is_ancestor(run, step)
        assert comp.is_ancestor(step, llm_req)

        # Inferred causality
        assert comp.is_ancestor(llm_resp, tool_call)

    def test_reset_clears_all_state(self, tracker: CausalTracker) -> None:
        event = Event(name=AgentEventTypes.RUN_START, payload={}, source="test")
        tracker.record(event)
        tracker.push_scope(event)

        assert len(tracker.computation) == 1
        assert tracker.current_scope is event

        tracker.reset()

        assert len(tracker.computation) == 0
        assert tracker.current_scope is None
