"""Shared fixtures for agent_templates tests."""

from __future__ import annotations

import pytest

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event

from pyrapide.agent_templates.core.causal_tracker import CausalTracker
from pyrapide.agent_templates.core.event_types import AgentEventTypes


@pytest.fixture
def tracker() -> CausalTracker:
    """Return a fresh CausalTracker."""
    return CausalTracker()


@pytest.fixture
def computation_with_tool_roundtrip() -> Computation:
    """Return a Computation containing an LLM request/response plus tool call/result.

    Causal structure (using explicit parents and inference)::

        run_start (scope)
          llm_request  (scoped to run_start)
            llm_response  (explicit parent: llm_request)
              tool_call  (inferred: most recent LLM_RESPONSE)
                tool_result  (explicit parent: tool_call)
                  llm_request_2  (inferred: most recent TOOL_RESULT)
                    llm_response_2  (explicit parent: llm_request_2)

    This is the canonical "LLM decides to call a tool" pattern.
    """
    tracker = CausalTracker()

    # Use a scope so all events have at least a scope parent
    run_start = Event(
        name=AgentEventTypes.RUN_START,
        payload={"framework": "test"},
        source="test",
    )
    tracker.record(run_start)
    tracker.push_scope(run_start)

    llm_req = Event(
        name=AgentEventTypes.LLM_REQUEST,
        payload={"framework": "test", "model": "gpt-4"},
        source="test",
    )
    tracker.record(llm_req)

    llm_resp = Event(
        name=AgentEventTypes.LLM_RESPONSE,
        payload={"framework": "test", "content": "I'll search for that."},
        source="test",
    )
    tracker.record(llm_resp, parent_id=llm_req.id)

    tool_call = Event(
        name=AgentEventTypes.TOOL_CALL,
        payload={"framework": "test", "tool_name": "web_search", "args": {"q": "weather"}},
        source="test",
    )
    # Inferred: TOOL_CALL caused by most recent LLM_RESPONSE
    tracker.record(tool_call)

    tool_result = Event(
        name=AgentEventTypes.TOOL_RESULT,
        payload={"framework": "test", "tool_name": "web_search", "result": "Sunny, 72F"},
        source="test",
    )
    tracker.record(tool_result, parent_id=tool_call.id)

    llm_req_2 = Event(
        name=AgentEventTypes.LLM_REQUEST,
        payload={"framework": "test", "model": "gpt-4"},
        source="test",
    )
    # Inferred: LLM_REQUEST caused by most recent TOOL_RESULT
    tracker.record(llm_req_2)

    llm_resp_2 = Event(
        name=AgentEventTypes.LLM_RESPONSE,
        payload={"framework": "test", "content": "The weather is sunny."},
        source="test",
    )
    tracker.record(llm_resp_2, parent_id=llm_req_2.id)

    tracker.pop_scope()

    return tracker.computation


@pytest.fixture
def computation_with_errors() -> Computation:
    """Return a Computation containing tool_error, llm_error, and task_error events.

    Causal structure::

        tool_call -> tool_error
        llm_request -> llm_error
        task_start -> task_error
    """
    tracker = CausalTracker()

    tool_call = Event(
        name=AgentEventTypes.TOOL_CALL,
        payload={"framework": "test", "tool_name": "db_query"},
        source="test",
    )
    tracker.record(tool_call)

    tool_error = Event(
        name=AgentEventTypes.TOOL_ERROR,
        payload={"framework": "test", "tool_name": "db_query", "error": "timeout"},
        source="test",
    )
    tracker.record(tool_error)

    llm_req = Event(
        name=AgentEventTypes.LLM_REQUEST,
        payload={"framework": "test"},
        source="test",
    )
    tracker.record(llm_req)

    llm_error = Event(
        name=AgentEventTypes.LLM_ERROR,
        payload={"framework": "test", "error": "rate_limited"},
        source="test",
    )
    tracker.record(llm_error)

    task_start = Event(
        name=AgentEventTypes.TASK_START,
        payload={"framework": "test"},
        source="test",
    )
    tracker.record(task_start)
    tracker.push_scope(task_start)

    task_error = Event(
        name=AgentEventTypes.TASK_ERROR,
        payload={"framework": "test", "error": "failed"},
        source="test",
    )
    tracker.record(task_error)

    return tracker.computation


@pytest.fixture
def computation_with_scopes() -> Computation:
    """Return a Computation with nested run > step scopes and events inside them.

    Causal structure::

        run_start
            step_start
                tool_call
                    tool_result  (explicit parent: tool_call)
            step_end  (explicit parent: step_start)
        run_end  (explicit parent: run_start)
    """
    tracker = CausalTracker()

    run_start = Event(
        name=AgentEventTypes.RUN_START,
        payload={"framework": "test"},
        source="test",
    )
    tracker.record(run_start)
    tracker.push_scope(run_start)

    step_start = Event(
        name=AgentEventTypes.STEP_START,
        payload={"framework": "test"},
        source="test",
    )
    tracker.record(step_start)
    tracker.push_scope(step_start)

    tool_call = Event(
        name=AgentEventTypes.TOOL_CALL,
        payload={"framework": "test", "tool_name": "calculator"},
        source="test",
    )
    tracker.record(tool_call)

    tool_result = Event(
        name=AgentEventTypes.TOOL_RESULT,
        payload={"framework": "test", "tool_name": "calculator", "result": "42"},
        source="test",
    )
    tracker.record(tool_result, parent_id=tool_call.id)

    tracker.pop_scope()  # pop step_start

    step_end = Event(
        name=AgentEventTypes.STEP_END,
        payload={"framework": "test"},
        source="test",
    )
    tracker.record(step_end, parent_id=step_start.id)

    tracker.pop_scope()  # pop run_start

    run_end = Event(
        name=AgentEventTypes.RUN_END,
        payload={"framework": "test"},
        source="test",
    )
    tracker.record(run_end, parent_id=run_start.id)

    return tracker.computation
