"""Tests for agent_templates.core.patterns.AgentPatterns."""

from __future__ import annotations

import pytest

from pyrapide.core.computation import Computation
from pyrapide.core.event import Event
from pyrapide.patterns.base import Pattern, PatternMatch

from pyrapide.agent_templates.core.causal_tracker import CausalTracker
from pyrapide.agent_templates.core.event_types import AgentEventTypes
from pyrapide.agent_templates.core.patterns import AgentPatterns


class TestPatternReturnsPattern:
    """Every AgentPatterns method must return a Pattern instance."""

    def test_tool_call_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.tool_call(), Pattern)

    def test_tool_result_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.tool_result(), Pattern)

    def test_tool_error_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.tool_error(), Pattern)

    def test_tool_roundtrip_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.tool_roundtrip(), Pattern)

    def test_tool_error_after_call_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.tool_error_after_call(), Pattern)

    def test_llm_request_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.llm_request(), Pattern)

    def test_llm_response_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.llm_response(), Pattern)

    def test_llm_error_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.llm_error(), Pattern)

    def test_llm_roundtrip_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.llm_roundtrip(), Pattern)

    def test_full_tool_lifecycle_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.full_tool_lifecycle(), Pattern)

    def test_agent_handoff_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.agent_handoff(), Pattern)

    def test_handoff_chain_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.handoff_chain(), Pattern)

    def test_agent_message_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.agent_message(), Pattern)

    def test_agent_step_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.agent_step(), Pattern)

    def test_task_lifecycle_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.task_lifecycle(), Pattern)

    def test_run_lifecycle_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.run_lifecycle(), Pattern)

    def test_any_error_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.any_error(), Pattern)

    def test_error_cascade_returns_pattern(self) -> None:
        assert isinstance(AgentPatterns.error_cascade(), Pattern)


class TestToolRoundtripPattern:
    """AgentPatterns.tool_roundtrip() matches tool_call >> tool_result."""

    def test_matches_in_computation(self, computation_with_tool_roundtrip: Computation) -> None:
        pattern = AgentPatterns.tool_roundtrip()
        matches = pattern.match_in(computation_with_tool_roundtrip._poset)

        assert len(matches) >= 1
        # Each match should contain at least one TOOL_CALL and one TOOL_RESULT
        for m in matches:
            event_names = {e.name for e in m.events}
            assert AgentEventTypes.TOOL_CALL in event_names
            assert AgentEventTypes.TOOL_RESULT in event_names

    def test_no_match_without_causal_link(self) -> None:
        """Two unrelated events should not match the sequence pattern."""
        tracker = CausalTracker()

        call = Event(
            name=AgentEventTypes.TOOL_CALL,
            payload={"tool_name": "a"},
            source="test",
        )
        result = Event(
            name=AgentEventTypes.TOOL_RESULT,
            payload={"tool_name": "a"},
            source="test",
        )

        # Record without causal link (independent events)
        tracker.record(call)
        tracker.record(result)

        pattern = AgentPatterns.tool_roundtrip()
        comp = tracker.computation

        # Without a causal link, the >> (sequence) pattern should not match
        # because SequencePattern requires is_ancestor to be true.
        # However, both events are independent roots here, so no ancestor link.
        matches = pattern.match_in(comp._poset)
        assert len(matches) == 0


class TestLLMRoundtripPattern:
    """AgentPatterns.llm_roundtrip() matches llm_request >> llm_response."""

    def test_matches_in_computation(self, computation_with_tool_roundtrip: Computation) -> None:
        pattern = AgentPatterns.llm_roundtrip()
        matches = pattern.match_in(computation_with_tool_roundtrip._poset)

        # The fixture has llm_request and llm_response with a causal path between them
        assert len(matches) >= 1
        for m in matches:
            event_names = {e.name for e in m.events}
            assert AgentEventTypes.LLM_REQUEST in event_names
            assert AgentEventTypes.LLM_RESPONSE in event_names

    def test_no_match_in_empty_computation(self) -> None:
        comp = Computation()
        pattern = AgentPatterns.llm_roundtrip()
        matches = pattern.match_in(comp._poset)
        assert len(matches) == 0


class TestAnyErrorPattern:
    """AgentPatterns.any_error() matches tool_error, llm_error, and task_error."""

    def test_matches_tool_error(self, computation_with_errors: Computation) -> None:
        pattern = AgentPatterns.any_error()
        matches = pattern.match_in(computation_with_errors._poset)

        matched_names = {e.name for m in matches for e in m.events}
        assert AgentEventTypes.TOOL_ERROR in matched_names

    def test_matches_llm_error(self, computation_with_errors: Computation) -> None:
        pattern = AgentPatterns.any_error()
        matches = pattern.match_in(computation_with_errors._poset)

        matched_names = {e.name for m in matches for e in m.events}
        assert AgentEventTypes.LLM_ERROR in matched_names

    def test_matches_task_error(self, computation_with_errors: Computation) -> None:
        pattern = AgentPatterns.any_error()
        matches = pattern.match_in(computation_with_errors._poset)

        matched_names = {e.name for m in matches for e in m.events}
        assert AgentEventTypes.TASK_ERROR in matched_names

    def test_matches_all_three_error_types(self, computation_with_errors: Computation) -> None:
        pattern = AgentPatterns.any_error()
        matches = pattern.match_in(computation_with_errors._poset)

        matched_names = {e.name for m in matches for e in m.events}
        assert matched_names == {
            AgentEventTypes.TOOL_ERROR,
            AgentEventTypes.LLM_ERROR,
            AgentEventTypes.TASK_ERROR,
        }

    def test_no_match_without_errors(self, computation_with_tool_roundtrip: Computation) -> None:
        pattern = AgentPatterns.any_error()
        matches = pattern.match_in(computation_with_tool_roundtrip._poset)
        assert len(matches) == 0


class TestToolCallWithName:
    """AgentPatterns.tool_call(tool_name=...) filters by payload."""

    def test_matches_specific_tool_name(self) -> None:
        tracker = CausalTracker()

        search_call = Event(
            name=AgentEventTypes.TOOL_CALL,
            payload={"tool_name": "web_search"},
            source="test",
        )
        calc_call = Event(
            name=AgentEventTypes.TOOL_CALL,
            payload={"tool_name": "calculator"},
            source="test",
        )

        tracker.record(search_call)
        tracker.record(calc_call)

        pattern = AgentPatterns.tool_call(tool_name="web_search")
        matches = pattern.match_in(tracker.computation._poset)

        assert len(matches) == 1
        assert matches[0].events[0].payload["tool_name"] == "web_search"

    def test_no_match_for_wrong_tool_name(self) -> None:
        tracker = CausalTracker()

        call = Event(
            name=AgentEventTypes.TOOL_CALL,
            payload={"tool_name": "calculator"},
            source="test",
        )
        tracker.record(call)

        pattern = AgentPatterns.tool_call(tool_name="web_search")
        matches = pattern.match_in(tracker.computation._poset)
        assert len(matches) == 0

    def test_unfiltered_matches_all(self) -> None:
        tracker = CausalTracker()

        for name in ["search", "calc", "db"]:
            ev = Event(
                name=AgentEventTypes.TOOL_CALL,
                payload={"tool_name": name},
                source="test",
            )
            tracker.record(ev)

        pattern = AgentPatterns.tool_call()
        matches = pattern.match_in(tracker.computation._poset)
        assert len(matches) == 3


class TestScopePatterns:
    """Test scope-related patterns with actual computation data."""

    def test_agent_step_matches(self, computation_with_scopes: Computation) -> None:
        pattern = AgentPatterns.agent_step()
        matches = pattern.match_in(computation_with_scopes._poset)

        assert len(matches) >= 1
        for m in matches:
            event_names = {e.name for e in m.events}
            assert AgentEventTypes.STEP_START in event_names
            assert AgentEventTypes.STEP_END in event_names

    def test_run_lifecycle_matches(self, computation_with_scopes: Computation) -> None:
        pattern = AgentPatterns.run_lifecycle()
        matches = pattern.match_in(computation_with_scopes._poset)

        assert len(matches) >= 1
        for m in matches:
            event_names = {e.name for e in m.events}
            assert AgentEventTypes.RUN_START in event_names
            assert AgentEventTypes.RUN_END in event_names

    def test_tool_roundtrip_within_scope(self, computation_with_scopes: Computation) -> None:
        pattern = AgentPatterns.tool_roundtrip()
        matches = pattern.match_in(computation_with_scopes._poset)

        assert len(matches) >= 1
