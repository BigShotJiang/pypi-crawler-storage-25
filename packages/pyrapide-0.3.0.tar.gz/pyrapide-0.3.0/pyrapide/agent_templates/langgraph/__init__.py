"""PyRapide adapter for LangGraph / LangChain.

Provides ``LangGraphAdapter`` which hooks into LangGraph via
``langchain_core.callbacks.BaseCallbackHandler`` to emit causal events
for LLM calls, tool invocations, and chain steps.

Usage::

    from pyrapide.agent_templates.langgraph import LangGraphAdapter

    adapter = LangGraphAdapter("my-langgraph-app")
    graph.invoke(input, config={"callbacks": [adapter.callback_handler]})
"""

from pyrapide.agent_templates.langgraph.adapter import LangGraphAdapter

__all__ = ["LangGraphAdapter"]
