"""LangGraph + PyRapide integration template.

This runnable example shows how to instrument a LangGraph agent with
PyRapide causal event tracking.

Prerequisites::

    pip install pyrapide langgraph langchain-openai

Overview
--------
LangGraph builds on LangChain's callback system.  PyRapide provides a
``BaseCallbackHandler`` that translates every LLM call, tool invocation,
and chain step into a unified causal event stream.

The integration requires **two lines of code**:

1. Create the adapter::

       adapter = LangGraphAdapter("my-app")

2. Pass the callback handler in the graph config::

       graph.invoke(input, config={"callbacks": [adapter.callback_handler]})

All LLM requests/responses, tool calls/results, and chain steps are
automatically tracked with full causal lineage.
"""

from __future__ import annotations

import asyncio


async def main() -> None:
    """Run a simple LangGraph ReAct agent with PyRapide instrumentation."""

    # --- Standard LangGraph setup -----------------------------------------

    from langchain_openai import ChatOpenAI
    from langgraph.prebuilt import create_react_agent
    from langchain_core.tools import tool

    @tool
    def get_weather(city: str) -> str:
        """Get the current weather for a city."""
        # Stub for demonstration
        return f"The weather in {city} is 72F and sunny."

    @tool
    def get_population(city: str) -> str:
        """Get the population of a city."""
        # Stub for demonstration
        return f"The population of {city} is approximately 4.7 million."

    llm = ChatOpenAI(model="gpt-4o-mini")
    graph = create_react_agent(llm, tools=[get_weather, get_population])

    # --- PyRapide instrumentation (2 lines) --------------------------------

    from pyrapide.agent_templates.langgraph import LangGraphAdapter

    adapter = LangGraphAdapter("langgraph-demo")

    # --- Run the agent -----------------------------------------------------

    result = graph.invoke(
        {"messages": [("user", "What's the weather and population of Seattle?")]},
        config={"callbacks": [adapter.callback_handler]},
    )

    # --- Inspect results ---------------------------------------------------

    # Print the agent's final answer
    final_message = result["messages"][-1]
    print(f"Agent response: {final_message.content}\n")

    # Access the causal computation graph
    computation = adapter.computation
    print(f"Computation has {len(computation)} events with causal links.\n")

    # Walk the event history
    print("Event trace:")
    for event in computation:
        meta = event.metadata or {}
        corr = meta.get("correlation_id", "")[:8]
        print(
            f"  {event.name:<30} "
            f"corr={corr:<10} "
            f"id={event.id[:8]}"
        )

    # Find all tool calls
    from pyrapide.agent_templates.core.event_types import AgentEventTypes

    tool_events = [
        e for e in computation
        if e.name == AgentEventTypes.TOOL_CALL
    ]
    print(f"\nTool calls made: {len(tool_events)}")
    for te in tool_events:
        print(f"  - {te.payload.get('tool_name')}: {te.payload.get('input', '')[:80]}")


if __name__ == "__main__":
    asyncio.run(main())
