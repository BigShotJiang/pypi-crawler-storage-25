"""LangGraph / LangChain adapter for PyRapide causal event tracking.

Hooks into LangGraph via ``langchain_core.callbacks.BaseCallbackHandler``
to translate LLM requests, tool calls, and chain steps into unified
PyRapide events with automatic causal linking.

All framework imports are lazy (inside methods) so this module can be
imported even when ``langchain_core`` is not installed.
"""

from __future__ import annotations

import logging
from typing import Any

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)


class LangGraphAdapter(BaseAgentAdapter):
    """Instrument a LangGraph application with PyRapide causal tracking.

    Parameters
    ----------
    name:
        Human-readable adapter name (appears in event ``source`` fields).

    Usage::

        from pyrapide.agent_templates.langgraph import LangGraphAdapter

        adapter = LangGraphAdapter("my-app")
        result = graph.invoke(
            {"messages": [("user", "Hello")]},
            config={"callbacks": [adapter.callback_handler]},
        )

    The adapter creates a ``langchain_core.callbacks.BaseCallbackHandler``
    subclass that translates LangChain callbacks into PyRapide events:

    - ``on_llm_start``   -> ``LLM_REQUEST``
    - ``on_llm_end``     -> ``LLM_RESPONSE``
    - ``on_tool_start``  -> ``TOOL_CALL``
    - ``on_tool_end``    -> ``TOOL_RESULT``
    - ``on_tool_error``  -> ``TOOL_ERROR``
    - ``on_chain_start`` -> ``STEP_START`` (scope push)
    - ``on_chain_end``   -> ``STEP_END``   (scope pop)
    """

    def __init__(self, name: str) -> None:
        super().__init__(name, framework_instance=None)
        self._handler: Any | None = None

    # -- Public API --------------------------------------------------------

    @property
    def callback_handler(self) -> Any:
        """Return the ``BaseCallbackHandler`` instance.

        Creates the handler on first access.  Pass this to LangGraph::

            config={"callbacks": [adapter.callback_handler]}
        """
        if self._handler is None:
            self._handler = self._create_handler()
        return self._handler

    # -- Hook installation -------------------------------------------------

    def _install_hooks(self) -> None:
        """Ensure the callback handler is created.

        For LangGraph the handler is passed explicitly via ``config``,
        so there is no global registration step.  This method ensures
        the handler exists so ``callback_handler`` can be used immediately
        after ``events()`` is first awaited.
        """
        _ = self.callback_handler
        logger.info(
            "PyRapide: LangGraph callback handler ready. "
            "Pass adapter.callback_handler in your graph config."
        )

    def _uninstall_hooks(self) -> None:
        """Release the callback handler reference."""
        self._handler = None

    # -- Internal ----------------------------------------------------------

    def _create_handler(self) -> Any:
        """Build a ``BaseCallbackHandler`` subclass bound to this adapter.

        The import of ``langchain_core`` happens here (lazy) so that the
        module can be imported without requiring the framework.
        """
        try:
            from langchain_core.callbacks import BaseCallbackHandler
        except ImportError as exc:
            raise ImportError(
                "LangGraphAdapter requires the 'langchain-core' package. "
                "Install it with: pip install langchain-core"
            ) from exc

        adapter = self  # capture for inner class

        class _PyRapideCallbackHandler(BaseCallbackHandler):
            """Translates LangChain callbacks into PyRapide events."""

            # -- LLM lifecycle ---------------------------------------------

            def on_llm_start(
                self,
                serialized: dict[str, Any],
                prompts: list[str],
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Emit LLM_REQUEST when an LLM call begins."""
                adapter.emit(
                    AgentEventTypes.LLM_REQUEST,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "llm_start",
                        "model": serialized.get("id", [None])[-1]
                        if isinstance(serialized.get("id"), list)
                        else serialized.get("name", "unknown"),
                        "prompts": prompts[:3],  # cap for payload size
                        "invocation_params": _extract_params(kwargs),
                    },
                    correlation_id=str(run_id),
                )

            def on_llm_end(
                self,
                response: Any,
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Emit LLM_RESPONSE when an LLM call completes."""
                adapter.emit(
                    AgentEventTypes.LLM_RESPONSE,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "llm_end",
                        "generations": _safe_generations(response),
                        "llm_output": _safe_llm_output(response),
                    },
                    correlation_id=str(run_id),
                )

            def on_llm_error(
                self,
                error: BaseException,
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Emit LLM_ERROR when an LLM call fails."""
                adapter.emit(
                    AgentEventTypes.LLM_ERROR,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "llm_error",
                        "error_type": type(error).__name__,
                        "error_message": str(error)[:500],
                    },
                    correlation_id=str(run_id),
                )

            # -- Tool lifecycle --------------------------------------------

            def on_tool_start(
                self,
                serialized: dict[str, Any],
                input_str: str,
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Emit TOOL_CALL when a tool invocation begins."""
                adapter.emit(
                    AgentEventTypes.TOOL_CALL,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "tool_start",
                        "tool_name": serialized.get("name", "unknown"),
                        "tool_description": serialized.get("description", ""),
                        "input": input_str[:1000],
                    },
                    correlation_id=str(run_id),
                )

            def on_tool_end(
                self,
                output: Any,
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Emit TOOL_RESULT when a tool invocation succeeds."""
                adapter.emit(
                    AgentEventTypes.TOOL_RESULT,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "tool_end",
                        "output": str(output)[:1000],
                    },
                    correlation_id=str(run_id),
                )

            def on_tool_error(
                self,
                error: BaseException,
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Emit TOOL_ERROR when a tool invocation fails."""
                adapter.emit(
                    AgentEventTypes.TOOL_ERROR,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "tool_error",
                        "error_type": type(error).__name__,
                        "error_message": str(error)[:500],
                    },
                    correlation_id=str(run_id),
                )

            # -- Chain lifecycle (scope tracking) --------------------------

            def on_chain_start(
                self,
                serialized: dict[str, Any],
                inputs: dict[str, Any],
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Emit STEP_START and push a scope for nested events."""
                adapter.emit_scope_start(
                    AgentEventTypes.STEP_START,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "chain_start",
                        "chain_name": serialized.get("name", "unknown"),
                        "chain_id": serialized.get("id", [])[-1]
                        if isinstance(serialized.get("id"), list)
                        else str(serialized.get("id", "")),
                        "input_keys": list(inputs.keys())
                        if isinstance(inputs, dict)
                        else [],
                    },
                    correlation_id=str(run_id),
                )

            def on_chain_end(
                self,
                outputs: dict[str, Any],
                *,
                run_id: Any,
                **kwargs: Any,
            ) -> None:
                """Pop the scope and emit STEP_END."""
                adapter.emit_scope_end(
                    AgentEventTypes.STEP_END,
                    {
                        "framework": "langgraph",
                        "framework_event_type": "chain_end",
                        "output_keys": list(outputs.keys())
                        if isinstance(outputs, dict)
                        else [],
                    },
                    correlation_id=str(run_id),
                )

        return _PyRapideCallbackHandler()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_params(kwargs: dict[str, Any]) -> dict[str, Any]:
    """Extract safe invocation params from kwargs."""
    params = kwargs.get("invocation_params", {})
    if not isinstance(params, dict):
        return {}
    # Only keep serializable, non-sensitive keys
    safe_keys = {"model", "model_name", "temperature", "max_tokens", "top_p"}
    return {k: v for k, v in params.items() if k in safe_keys}


def _safe_generations(response: Any) -> list[str]:
    """Extract generation text from an LLMResult without crashing."""
    try:
        results = []
        for gen_list in response.generations:
            for gen in gen_list:
                results.append(gen.text[:500] if gen.text else "")
        return results[:5]  # cap
    except Exception:
        return []


def _safe_llm_output(response: Any) -> dict[str, Any]:
    """Extract safe llm_output metadata from an LLMResult."""
    try:
        output = response.llm_output or {}
        if not isinstance(output, dict):
            return {}
        safe_keys = {
            "token_usage", "model_name", "model",
            "system_fingerprint",
        }
        return {k: v for k, v in output.items() if k in safe_keys}
    except Exception:
        return {}
