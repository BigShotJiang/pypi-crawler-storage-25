# LangGraph + PyRapide Integration

> **Navigation**: [Main Docs](../../pyrapide-agent-documentation.md) | [AutoGen](../autogen/INTEGRATION.md) | **LangGraph** | [CrewAI](../crewai/INTEGRATION.md) | [LlamaIndex](../llamaindex/INTEGRATION.md)

## Quick Start

```python
from pyrapide.agent_templates.langgraph import LangGraphAdapter

adapter = LangGraphAdapter("my-graph")
result = graph.invoke(
    {"messages": [("user", "Hello")]},
    config={"callbacks": [adapter.callback_handler]},
)
```

## Prerequisites

```bash
pip install pyrapide langgraph langchain-openai
```

## How It Works

The adapter creates a `langchain_core.callbacks.BaseCallbackHandler` subclass that LangGraph invokes at every lifecycle point: LLM start/end, tool start/end/error, and chain start/end. Each callback translates the LangChain event into a PyRapide `Event` and records it in the `CausalTracker`.

LangChain's `run_id` (a UUID assigned to each callback invocation) is used as the `correlation_id`, which automatically links request/response pairs. Chain start/end callbacks push and pop scopes on the tracker, so all events within a chain step are causally nested under their parent chain. The heuristic engine also links tool calls to the LLM response that triggered them.

## Event Mapping

| LangChain Callback | PyRapide Event | Causal Link |
|---|---|---|
| `on_llm_start(run_id)` | `agent.llm.request` (LLM_REQUEST) | `correlation_id=str(run_id)`, caused by TOOL_RESULT if re-inference |
| `on_llm_end(run_id)` | `agent.llm.response` (LLM_RESPONSE) | `correlation_id=str(run_id)`, paired with LLM_REQUEST |
| `on_llm_error(run_id)` | `agent.llm.error` (LLM_ERROR) | `correlation_id=str(run_id)` |
| `on_tool_start(run_id)` | `agent.tool.call` (TOOL_CALL) | `correlation_id=str(run_id)`, caused by most recent LLM_RESPONSE |
| `on_tool_end(run_id)` | `agent.tool.result` (TOOL_RESULT) | `correlation_id=str(run_id)`, paired with TOOL_CALL |
| `on_tool_error(run_id)` | `agent.tool.error` (TOOL_ERROR) | `correlation_id=str(run_id)`, caused by TOOL_CALL |
| `on_chain_start(run_id)` | `agent.step.start` (STEP_START) | Scope push -- all nested events parented here |
| `on_chain_end(run_id)` | `agent.step.end` (STEP_END) | Scope pop |

## Full Example

```python
import asyncio
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_core.tools import tool
from pyrapide.agent_templates.langgraph import LangGraphAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

@tool
def get_weather(city: str) -> str:
    """Get current weather for a city."""
    return f"72F and sunny in {city}."

@tool
def get_population(city: str) -> str:
    """Get population of a city."""
    return f"{city} has ~4.7 million people."

llm = ChatOpenAI(model="gpt-4o-mini")
graph = create_react_agent(llm, tools=[get_weather, get_population])

# --- PyRapide: 2 lines ---
adapter = LangGraphAdapter("weather-agent")
result = graph.invoke(
    {"messages": [("user", "Weather and population of Seattle?")]},
    config={"callbacks": [adapter.callback_handler]},
)

# --- Inspect causal graph ---
comp = adapter.computation
print(f"{len(comp)} events tracked\n")

for event in comp.topological_order():
    corr = (event.metadata or {}).get("correlation_id", "")[:8]
    print(f"  {event.name:<30} corr={corr:<10} id={event.id[:8]}")

tool_calls = [e for e in comp.events if e.name == AgentEventTypes.TOOL_CALL]
print(f"\nTool calls: {len(tool_calls)}")
for tc in tool_calls:
    print(f"  - {tc.payload.get('tool_name')}: {tc.payload.get('input', '')[:60]}")
```

## Adding Constraints

```python
from pyrapide.agent_templates.core.patterns import AgentPatterns
from pyrapide.constraints.pattern_constraints import MustMatch, Never

# Every LLM request must get a response
must_respond = MustMatch(
    AgentPatterns.llm_roundtrip(),
    name="llm-must-respond",
    description="Every LLM request must receive a response",
)

# Tool calls must not produce errors
no_tool_errors = Never(
    AgentPatterns.tool_error_after_call(),
    name="no-tool-errors",
    description="Tool calls must succeed without errors",
)

# Full tool lifecycle: LLM -> tool_call -> tool_result -> LLM
must_complete_cycle = MustMatch(
    AgentPatterns.full_tool_lifecycle(),
    name="full-tool-cycle",
)

from pyrapide.constraints.conformance import check_conformance
violations = check_conformance(adapter.computation, [must_respond, no_tool_errors])
for v in violations:
    print(f"VIOLATION: {v.constraint_name} -- {v.description}")
```

## Post-Run Analysis

```python
from pyrapide.analysis import queries, visualization

comp = adapter.computation

# Root cause analysis: trace any event back to its origins
target = [e for e in comp.events if e.name == "agent.llm.response"][-1]
roots = queries.root_causes(comp, target)
print(f"Final response caused by: {[r.name for r in roots]}")

# Impact analysis: what did a tool call affect?
tool_event = [e for e in comp.events if e.name == "agent.tool.call"][0]
affected = queries.impact_set(comp, tool_event)
print(f"Tool call impacted {len(affected)} downstream events")

# Causal distance between two events
dist = queries.causal_distance(comp, tool_event, target)
print(f"Causal distance from tool call to response: {dist}")

# Visualization
print(visualization.to_ascii(comp))              # Terminal output
dot = visualization.to_dot(comp)                  # Graphviz DOT
mermaid = visualization.to_mermaid(comp)          # Mermaid diagram
json_data = visualization.to_json(comp)           # JSON for custom UIs
print(visualization.summary(comp))                # Text summary
```

## API Reference

```python
class LangGraphAdapter(BaseAgentAdapter):
    def __init__(self, name: str) -> None
        """Create adapter. No runtime reference needed."""

    @property
    def callback_handler(self) -> BaseCallbackHandler
        """The LangChain callback handler. Pass in config={"callbacks": [...]}.
        Created on first access."""

    @property
    def computation(self) -> Computation
        """The internal Computation containing all recorded events."""

    @property
    def tracker(self) -> CausalTracker
        """The CausalTracker managing event relationships."""

    def emit(self, event_type, payload, *, parent_id=None, correlation_id=None, source=None, metadata=None) -> Event
        """Create, record, and enqueue a PyRapide Event."""

    async def events(self) -> AsyncIterator[Event]
        """Yield events as they are emitted. Implements EventSource protocol."""

    async def close(self) -> None
        """Signal that no more events will be produced."""
```

## Troubleshooting

| Issue | Fix |
|---|---|
| `ImportError: langchain-core` | Run `pip install langchain-core` |
| No events captured | Ensure you pass `config={"callbacks": [adapter.callback_handler]}` to `graph.invoke()` or `graph.stream()` |
| Missing tool events | Verify tools are registered with `@tool` decorator from `langchain_core.tools` |
| Chain events too noisy | Filter by event type: `[e for e in comp.events if e.name != AgentEventTypes.STEP_START]` |
| `correlation_id` not linking pairs | Each `run_id` is unique per invocation; check that LLM start and end share the same `run_id` in LangChain's callback system |
| Async graphs | The callback handler works with both `graph.invoke()` and `graph.ainvoke()`; use `await adapter.close()` when done |

## Related Files

- [`agent_templates/langgraph/adapter.py`](adapter.py) -- LangGraphAdapter implementation
- [`agent_templates/langgraph/template.py`](template.py) -- Runnable example
- [`agent_templates/core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`agent_templates/core/event_types.py`](../core/event_types.py) -- AgentEventTypes constants
- [`agent_templates/core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker engine
- [`agent_templates/core/patterns.py`](../core/patterns.py) -- AgentPatterns library
- [`pyrapide-agent-documentation.md`](../../pyrapide-agent-documentation.md) -- Full PyRapide agent docs
