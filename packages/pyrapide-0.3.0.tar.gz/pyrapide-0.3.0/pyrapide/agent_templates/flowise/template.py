"""FlowiseAI + PyRapide integration template.

This runnable example shows how to instrument a FlowiseAI chatflow
with PyRapide causal event tracking.

Prerequisites::

    pip install pyrapide aiohttp

Overview
--------
FlowiseAI is a hosted drag-and-drop LLM orchestration platform that
exposes chatflows via a REST API.  Unlike Python-native frameworks,
there are no classes to monkey-patch.  Instead, the ``FlowiseAdapter``
drives the HTTP interaction itself, POSTing to the prediction endpoint
with streaming enabled and translating SSE responses into PyRapide
events.

The integration requires **three lines of code**:

1. Create the adapter with your Flowise connection details::

       adapter = FlowiseAdapter("my-app", base_url=..., chatflow_id=...)

2. Send a message and iterate over events::

       async for event in adapter.send_message("Hello!"):
           print(event)

That's it -- all tool calls, LLM tokens, agent reasoning steps, and
run lifecycle events are tracked with full causal lineage.
"""

from __future__ import annotations

import asyncio


async def main() -> None:
    """Run a simple Flowise prediction with PyRapide instrumentation."""

    # --- Configuration (update these for your Flowise instance) -----------

    FLOWISE_BASE_URL = "http://localhost:3000"
    FLOWISE_CHATFLOW_ID = "your-chatflow-id-here"
    FLOWISE_API_KEY = None  # set if your instance requires auth

    # --- PyRapide instrumentation (3 lines) --------------------------------

    from pyrapide.agent_templates.flowise import FlowiseAdapter

    adapter = FlowiseAdapter(
        "flowise-demo",
        base_url=FLOWISE_BASE_URL,
        chatflow_id=FLOWISE_CHATFLOW_ID,
        api_key=FLOWISE_API_KEY,
    )

    # --- Send a message and collect events --------------------------------

    collected_events: list = []

    print("Sending message to Flowise chatflow...")

    async for event in adapter.send_message("What is the capital of France?"):
        collected_events.append(event)
        print(f"  [{event.name}] source={event.source} | {event.id[:8]}")

    # --- Inspect results ---------------------------------------------------

    print(f"\nCollected {len(collected_events)} PyRapide events:")
    for ev in collected_events:
        meta = ev.metadata or {}
        parent = meta.get("parent_id", "root")[:8] if meta.get("parent_id") else "root"
        print(f"  {ev.name:<30} parent={parent:<10} id={ev.id[:8]}")

    # Access the full causal computation graph
    computation = adapter.computation
    print(f"\nComputation has {len(computation)} events with causal links.")

    # Signal done
    await adapter.close()


if __name__ == "__main__":
    asyncio.run(main())
