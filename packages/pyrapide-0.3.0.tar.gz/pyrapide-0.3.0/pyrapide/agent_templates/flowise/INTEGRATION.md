# PyRapide + FlowiseAI Integration

> Causal event tracking for FlowiseAI via REST API + SSE event stream (HTTP consumer, no Python hooks).

**Docs:** [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) | **Siblings:** [agno](../agno/INTEGRATION.md) | [swarm](../swarm/INTEGRATION.md) | [metagpt](../metagpt/INTEGRATION.md)

**Note:** FlowiseAI is a visual/no-code tool, not a Python library. This adapter communicates via HTTP, not Python hooks.

---

## Quick Start

```python
import asyncio
from pyrapide.agent_templates.flowise import FlowiseAdapter

adapter = FlowiseAdapter(
    "flowise",
    base_url="http://localhost:3000",
    chatflow_id="abc123",
    api_key="optional-api-key",  # omit if Flowise has no auth
)

# Send a message and stream PyRapide events
async def main():
    async for event in adapter.send_message("What is the weather?"):
        print(event.name, event.payload)

asyncio.run(main())
```

---

## Prerequisites

```bash
pip install pyrapide aiohttp  # aiohttp recommended; falls back to urllib
```

A running FlowiseAI instance is required. The adapter connects to the Flowise prediction API endpoint at `{base_url}/api/v1/prediction/{chatflow_id}`.

---

## How It Works

FlowiseAdapter POSTs to the Flowise prediction endpoint with `streaming: True` and parses the response as a Server-Sent Events (SSE) stream. Each SSE event type is mapped to one or more PyRapide events with causal lineage.

The adapter tries `aiohttp` first for true async streaming. If `aiohttp` is not installed, it falls back to `urllib.request` with synchronous line-by-line parsing. The `send_message()` method is an async generator that yields PyRapide `Event` objects as they arrive from the SSE stream. All events within a single `send_message()` call share a correlation ID.

---

## Event Mapping

| Flowise SSE Event | PyRapide Event | Causal Link |
|---|---|---|
| `start` | `agent.run.start` | Scope push -- becomes parent of all subsequent events |
| `token` | `agent.llm.stream_chunk` | Child of run scope; one event per streamed token |
| `usedTools` (per tool) | `agent.tool.call` + `agent.tool.result` | Paired events per tool; child of run scope |
| `agentReasoning` (per step) | `agent.step.start` + `agent.step.end` | Scope push/pop per reasoning step; nested in run scope |
| `end` | `agent.run.end` | Scope pop -- closes the run scope |
| Unknown event type | `agent.message.send` | Fallback for unrecognized SSE event types |

---

## Full Example

```python
import asyncio
from pyrapide.agent_templates.flowise import FlowiseAdapter
from pyrapide import queries

async def main():
    adapter = FlowiseAdapter(
        "flowise-demo",
        base_url="http://localhost:3000",
        chatflow_id="your-chatflow-id",
        api_key="your-api-key",
    )

    # Stream events from a Flowise prediction
    collected = []
    async for event in adapter.send_message("Summarize the Q3 report"):
        collected.append(event)
        print(f"  {event.name}: {event.payload.get('framework_event_type')}")

    # Analyze the causal graph
    comp = adapter.computation
    print(f"\nCaptured {len(comp.events)} events")

    # Find all tool calls and their results
    tool_calls = [e for e in comp.events if e.name == "agent.tool.call"]
    for tc in tool_calls:
        tool_name = tc.payload.get("tool_name", "unknown")
        effects = queries.direct_effects(comp, tc)
        results = [e for e in effects if e.name == "agent.tool.result"]
        print(f"Tool '{tool_name}': {len(results)} result(s)")

    # Count streamed tokens
    tokens = [e for e in comp.events if e.name == "agent.llm.stream_chunk"]
    print(f"Streamed {len(tokens)} tokens")

    await adapter.close()

asyncio.run(main())
```

---

## Adding Constraints

```python
from pyrapide import must_match, never, Pattern

# Every run must complete (start must be followed by end)
must_match(
    adapter.computation,
    Pattern("agent.run.start") >> Pattern("agent.run.end"),
    "Every Flowise run must complete",
)

# Tool calls from usedTools must always have results
must_match(
    adapter.computation,
    Pattern("agent.tool.call") >> Pattern("agent.tool.result"),
    "Every tool call must produce a result",
)

# No tokens should arrive after the run ends
never(
    adapter.computation,
    Pattern("agent.run.end") >> Pattern("agent.llm.stream_chunk"),
    "Tokens after run end",
)
```

---

## Post-Run Analysis

```python
comp = adapter.computation

# Root cause analysis for missing results
errors = [e for e in comp.events if "error" in e.name]
for err in errors:
    causes = queries.root_causes(comp, err)
    print(f"Error root causes: {[c.name for c in causes]}")

# Trace the full causal chain of the final event
if comp.events:
    chain = queries.causal_chain(comp, comp.events[-1])
    print("Causal chain to final event:")
    for step in chain:
        print(f"  <- {step.name} ({step.payload.get('framework_event_type')})")

# Visualize the Flowise execution trace
from pyrapide import visualize
visualize.to_dot(comp, output="flowise_trace.png")
visualize.to_json(comp, output="flowise_trace.json")
```

---

## API Reference

```python
class FlowiseAdapter(BaseAgentAdapter):
    def __init__(
        self,
        name: str,
        base_url: str,
        chatflow_id: str,
        api_key: str | None = None,
    ) -> None
        # name:        human-readable adapter name (appears in event source)
        # base_url:    Flowise server URL (e.g. "http://localhost:3000")
        # chatflow_id: the chatflow to invoke
        # api_key:     optional API key for authenticated instances

    async def send_message(
        self,
        message: str,
        *,
        override_config: dict | None = None,
    ) -> AsyncIterator[Event]
        # POST to the prediction endpoint, stream SSE, yield PyRapide events.
        # override_config: optional Flowise override configuration dict.

    @property
    def prediction_url(self) -> str
        # Full URL: {base_url}/api/v1/prediction/{chatflow_id}

    # Inherited from BaseAgentAdapter:
    @property
    def computation(self) -> Computation
    @property
    def tracker(self) -> CausalTracker
    def emit(self, event_type, payload, ...) -> Event
    def emit_scope_start(self, event_type, payload, ...) -> Event
    def emit_scope_end(self, event_type, payload, ...) -> Event
    async def events(self) -> AsyncIterator[Event]  # EventSource protocol
    async def close(self) -> None
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `ImportError: aiohttp` | Run `pip install aiohttp`; the adapter falls back to urllib but aiohttp is recommended |
| Connection refused | Verify Flowise is running at `base_url` and the chatflow ID is correct |
| 401 Unauthorized | Pass `api_key=` to the constructor if your Flowise instance requires authentication |
| No events yielded | Check that the chatflow has streaming enabled; non-streaming responses are not parsed |
| Missing tool events | Flowise only emits `usedTools` SSE if the chatflow uses tool-calling agents |
| `agentReasoning` not appearing | Only multi-agent chatflows with sequential agents emit reasoning steps |
| Tokens arrive but no run.end | Possible network interruption; the SSE stream may have been cut off |

---

## Related Files

- [`adapter.py`](./adapter.py) -- FlowiseAdapter implementation with SSE parsing
- [`template.py`](./template.py) -- runnable example script
- [`core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`core/event_types.py`](../core/event_types.py) -- unified AgentEventTypes constants
- [`core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker scope management
- [pyrapide-agent-documentation.md](../../pyrapide-agent-documentation.md) -- full PyRapide docs
