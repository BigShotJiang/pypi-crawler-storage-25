"""PyRapide adapter for FlowiseAI.

Provides ``FlowiseAdapter`` which integrates with a FlowiseAI instance
via its REST API and SSE event stream, translating prediction responses
into PyRapide causal events.

Usage::

    from pyrapide.agent_templates.flowise import FlowiseAdapter

    adapter = FlowiseAdapter(
        "my-flowise-app",
        base_url="http://localhost:3000",
        chatflow_id="abc-123",
    )
"""

from pyrapide.agent_templates.flowise.adapter import FlowiseAdapter

__all__ = ["FlowiseAdapter"]
