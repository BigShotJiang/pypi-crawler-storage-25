"""FlowiseAI adapter for PyRapide causal event tracking.

Integrates with a FlowiseAI instance via its REST API and SSE event
stream.  Unlike most adapters, Flowise is a hosted service rather than
a Python library, so there are no monkey-patches or callback hooks.
Instead, this adapter drives the HTTP interaction and translates SSE
responses into PyRapide events.

All framework imports are lazy (inside methods) so this module can be
imported even when ``aiohttp`` is not installed.
"""

from __future__ import annotations

import json
import logging
import uuid
from typing import Any, AsyncIterator

from pyrapide.core.event import Event

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)


class FlowiseAdapter(BaseAgentAdapter):
    """Instrument a FlowiseAI chatflow with PyRapide causal tracking.

    Communicates with a Flowise instance over HTTP, streaming the
    prediction response as SSE events that are translated into PyRapide
    events with causal lineage.

    Parameters
    ----------
    name:
        Human-readable adapter name (appears in event ``source`` fields).
    base_url:
        The Flowise server URL (e.g. ``http://localhost:3000``).
    chatflow_id:
        The chatflow to invoke.
    api_key:
        Optional API key for authenticated Flowise instances.

    Example::

        from pyrapide.agent_templates.flowise import FlowiseAdapter

        adapter = FlowiseAdapter(
            "flowise-demo",
            base_url="http://localhost:3000",
            chatflow_id="abc-123",
        )
        async for event in adapter.send_message("Hello!"):
            print(event.name, event.payload)
    """

    def __init__(
        self,
        name: str,
        base_url: str,
        chatflow_id: str,
        api_key: str | None = None,
    ) -> None:
        super().__init__(name, framework_instance=None)
        self._base_url = base_url.rstrip("/")
        self._chatflow_id = chatflow_id
        self._api_key = api_key

    # -- Public API --------------------------------------------------------

    @property
    def prediction_url(self) -> str:
        """The full URL for the prediction endpoint."""
        return f"{self._base_url}/api/v1/prediction/{self._chatflow_id}"

    async def send_message(
        self,
        message: str,
        *,
        override_config: dict[str, Any] | None = None,
    ) -> AsyncIterator[Event]:
        """Send a message to the chatflow and yield PyRapide events.

        This is the primary entry point.  It POSTs to the Flowise
        prediction endpoint with streaming enabled and translates the
        SSE response into a stream of PyRapide events.

        Parameters
        ----------
        message:
            The user message to send.
        override_config:
            Optional Flowise override configuration dict.

        Yields
        ------
        Event
            PyRapide events representing the Flowise execution.
        """
        body: dict[str, Any] = {
            "question": message,
            "streaming": True,
        }
        if override_config:
            body["overrideConfig"] = override_config

        correlation = str(uuid.uuid4())

        async for event in self._stream_prediction(body, correlation):
            yield event

    # -- Hook installation (no-op for REST-based adapter) ------------------

    def _install_hooks(self) -> None:
        """No-op: Flowise is a REST service with no Python hooks."""
        pass

    # -- Internal: SSE streaming -------------------------------------------

    async def _stream_prediction(
        self,
        body: dict[str, Any],
        correlation: str,
    ) -> AsyncIterator[Event]:
        """POST to the prediction endpoint and parse the SSE stream.

        Tries ``aiohttp`` first for true async streaming, then falls
        back to ``urllib.request`` with synchronous line-by-line parsing.
        """
        try:
            async for event in self._stream_with_aiohttp(body, correlation):
                yield event
        except ImportError:
            logger.debug(
                "aiohttp not available, falling back to urllib"
            )
            for event in self._stream_with_urllib(body, correlation):
                yield event

    async def _stream_with_aiohttp(
        self,
        body: dict[str, Any],
        correlation: str,
    ) -> AsyncIterator[Event]:
        """Stream prediction using aiohttp (preferred)."""
        import aiohttp  # lazy import

        headers = self._build_headers()

        async with aiohttp.ClientSession() as session:
            async with session.post(
                self.prediction_url,
                json=body,
                headers=headers,
            ) as response:
                response.raise_for_status()

                buffer = ""
                async for chunk in response.content.iter_any():
                    buffer += chunk.decode("utf-8", errors="replace")
                    while "\n\n" in buffer:
                        raw_event, buffer = buffer.split("\n\n", 1)
                        for event in self._parse_sse_event(raw_event.strip(), correlation):
                            yield event

                # Handle any remaining data in buffer
                if buffer.strip():
                    for event in self._parse_sse_event(buffer.strip(), correlation):
                        yield event

    def _stream_with_urllib(
        self,
        body: dict[str, Any],
        correlation: str,
    ) -> list[Event]:
        """Stream prediction using urllib (fallback)."""
        import urllib.request  # lazy import

        headers = self._build_headers()
        data = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(
            self.prediction_url,
            data=data,
            headers=headers,
            method="POST",
        )

        events: list[Event] = []
        with urllib.request.urlopen(req) as response:
            buffer = ""
            for line_bytes in response:
                line = line_bytes.decode("utf-8", errors="replace")
                buffer += line
                if buffer.endswith("\n\n"):
                    for event in self._parse_sse_event(buffer.strip(), correlation):
                        events.append(event)
                    buffer = ""

            if buffer.strip():
                for event in self._parse_sse_event(buffer.strip(), correlation):
                    events.append(event)

        return events

    # -- Internal: SSE parsing ---------------------------------------------

    def _parse_sse_event(
        self,
        raw: str,
        correlation: str,
    ) -> list[Event]:
        """Parse a single SSE event block into zero or more PyRapide events.

        Flowise SSE format::

            event: <event_type>
            data: <json_data>

        Recognised event types:
        - ``start`` -> RUN_START scope
        - ``token`` -> LLM_STREAM
        - ``usedTools`` -> TOOL_CALL + TOOL_RESULT per tool
        - ``agentReasoning`` -> STEP_START/STEP_END per reasoning step
        - ``end`` -> RUN_END scope
        """
        event_type = ""
        data_lines: list[str] = []

        for line in raw.splitlines():
            if line.startswith("event:"):
                event_type = line[len("event:"):].strip()
            elif line.startswith("data:"):
                data_lines.append(line[len("data:"):].strip())
            elif line.startswith(":"):
                continue  # SSE comment

        data_str = "\n".join(data_lines)
        data = self._try_parse_json(data_str)

        results: list[Event] = []

        if event_type == "start":
            ev = self.emit_scope_start(
                AgentEventTypes.RUN_START,
                {
                    "framework": "flowise",
                    "framework_event_type": "start",
                    "chatflow_id": self._chatflow_id,
                    "data": data,
                },
                correlation_id=correlation,
            )
            results.append(ev)

        elif event_type == "token":
            ev = self.emit(
                AgentEventTypes.LLM_STREAM,
                {
                    "framework": "flowise",
                    "framework_event_type": "token",
                    "token": data_str if isinstance(data, str) else data,
                },
                correlation_id=correlation,
            )
            results.append(ev)

        elif event_type == "usedTools":
            tools = data if isinstance(data, list) else [data] if data else []
            for tool in tools:
                tool_name = (
                    tool.get("tool", "unknown")
                    if isinstance(tool, dict)
                    else str(tool)
                )
                tool_input = (
                    tool.get("toolInput", {})
                    if isinstance(tool, dict)
                    else {}
                )
                tool_output = (
                    tool.get("toolOutput", "")
                    if isinstance(tool, dict)
                    else ""
                )

                tool_correlation = str(uuid.uuid4())

                call_ev = self.emit(
                    AgentEventTypes.TOOL_CALL,
                    {
                        "framework": "flowise",
                        "framework_event_type": "usedTools.call",
                        "tool_name": tool_name,
                        "tool_input": tool_input,
                    },
                    correlation_id=tool_correlation,
                )
                results.append(call_ev)

                result_ev = self.emit(
                    AgentEventTypes.TOOL_RESULT,
                    {
                        "framework": "flowise",
                        "framework_event_type": "usedTools.result",
                        "tool_name": tool_name,
                        "tool_output": _safe_repr(tool_output),
                    },
                    correlation_id=tool_correlation,
                )
                results.append(result_ev)

        elif event_type == "agentReasoning":
            steps = data if isinstance(data, list) else [data] if data else []
            for step in steps:
                agent_name = (
                    step.get("agentName", "agent")
                    if isinstance(step, dict)
                    else "agent"
                )
                step_messages = (
                    step.get("messages", [])
                    if isinstance(step, dict)
                    else []
                )

                step_correlation = str(uuid.uuid4())

                start_ev = self.emit_scope_start(
                    AgentEventTypes.STEP_START,
                    {
                        "framework": "flowise",
                        "framework_event_type": "agentReasoning.start",
                        "agent_name": agent_name,
                        "messages": step_messages,
                    },
                    correlation_id=step_correlation,
                    source=agent_name,
                )
                results.append(start_ev)

                end_ev = self.emit_scope_end(
                    AgentEventTypes.STEP_END,
                    {
                        "framework": "flowise",
                        "framework_event_type": "agentReasoning.end",
                        "agent_name": agent_name,
                    },
                    correlation_id=step_correlation,
                    source=agent_name,
                )
                results.append(end_ev)

        elif event_type == "end":
            ev = self.emit_scope_end(
                AgentEventTypes.RUN_END,
                {
                    "framework": "flowise",
                    "framework_event_type": "end",
                    "chatflow_id": self._chatflow_id,
                    "data": data,
                },
                correlation_id=correlation,
            )
            results.append(ev)

        elif event_type and data is not None:
            # Unknown event type -- emit as a generic agent message
            ev = self.emit(
                AgentEventTypes.AGENT_MESSAGE,
                {
                    "framework": "flowise",
                    "framework_event_type": event_type,
                    "data": data,
                },
                correlation_id=correlation,
            )
            results.append(ev)

        return results

    # -- Internal: helpers -------------------------------------------------

    def _build_headers(self) -> dict[str, str]:
        """Build HTTP headers for the prediction request."""
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }
        if self._api_key:
            headers["Authorization"] = f"Bearer {self._api_key}"
        return headers

    @staticmethod
    def _try_parse_json(text: str) -> Any:
        """Attempt to parse text as JSON, returning the raw string on failure."""
        if not text:
            return None
        try:
            return json.loads(text)
        except (json.JSONDecodeError, ValueError):
            return text


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_repr(obj: Any, max_len: int = 500) -> str:
    """Return a truncated repr that won't blow up event payloads."""
    try:
        text = repr(obj)
    except Exception:
        text = f"<{type(obj).__name__}>"
    if len(text) > max_len:
        return text[: max_len - 3] + "..."
    return text
