# CrewAI + PyRapide Integration

> **Navigation**: [Main Docs](../../pyrapide-agent-documentation.md) | [AutoGen](../autogen/INTEGRATION.md) | [LangGraph](../langgraph/INTEGRATION.md) | **CrewAI** | [LlamaIndex](../llamaindex/INTEGRATION.md)

## Quick Start

```python
from crewai import Crew
from pyrapide.agent_templates.crewai import CrewAIAdapter

adapter = CrewAIAdapter("my-crew")
crew = Crew(
    agents=[...], tasks=[...],
    step_callback=adapter.on_step,
    task_callback=adapter.on_task,
)
result = crew.kickoff()
```

## Prerequisites

```bash
pip install pyrapide crewai crewai-tools
```

## How It Works

The adapter hooks into CrewAI through two mechanisms. First, it registers global `before_tool_call` and `after_tool_call` hooks via CrewAI's hook system, which automatically capture every tool invocation across all agents in the process. Second, the `on_step` and `on_task` callbacks are passed directly to the `Crew` constructor to track agent reasoning steps and task completions.

The `CausalTracker` links events using heuristic rules: tool calls are parented to the most recent LLM response (the LLM decided to call the tool), and LLM requests after tool use are parented to the preceding tool result. Step and task events provide scope boundaries. The global tool hooks are installed lazily on first iteration of `adapter.events()`, or explicitly via `adapter._install_hooks()`.

## Event Mapping

| CrewAI Event | PyRapide Event | Causal Link |
|---|---|---|
| `@before_tool_call(tool_name, tool_input)` | `agent.tool.call` (TOOL_CALL) | Caused by most recent LLM_RESPONSE |
| `@after_tool_call(tool_name, tool_input, tool_output)` | `agent.tool.result` (TOOL_RESULT) | Caused by matching TOOL_CALL |
| `step_callback(output)` with `AgentAction` | `agent.step.start` (STEP_START) | Scope context for nested events |
| `step_callback(output)` with `AgentFinish` | `agent.step.end` (STEP_END) | Closes current step scope |
| `task_callback(output)` | `agent.task.end` (TASK_END) | Captures task completion with result metadata |
| Crew `kickoff()` | `agent.run.start` (RUN_START) | Root scope for entire crew execution |

## Full Example

```python
import asyncio
from crewai import Agent, Crew, Process, Task
from crewai_tools import SerperDevTool
from pyrapide.agent_templates.crewai import CrewAIAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

search_tool = SerperDevTool()

researcher = Agent(
    role="Senior Research Analyst",
    goal="Find the latest trends in AI agent frameworks.",
    backstory="Expert AI researcher specializing in agent ecosystems.",
    verbose=True,
    tools=[search_tool],
)

writer = Agent(
    role="Technical Writer",
    goal="Create a concise summary of findings.",
    backstory="Skilled writer who distills complex topics.",
    verbose=True,
)

research_task = Task(
    description="Research the current state of AI agent frameworks in 2025.",
    expected_output="A structured research summary.",
    agent=researcher,
)

write_task = Task(
    description="Write a 200-word executive summary from the research.",
    expected_output="A polished 200-word summary.",
    agent=writer,
)

# --- PyRapide: 3 lines ---
adapter = CrewAIAdapter("research-crew")
crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    process=Process.sequential,
    step_callback=adapter.on_step,
    task_callback=adapter.on_task,
)

async def run():
    collected = []
    async def collect():
        async for event in adapter.events():
            collected.append(event)

    task = asyncio.create_task(collect())
    result = crew.kickoff()
    await adapter.close()
    await task

    comp = adapter.computation
    print(f"{len(comp)} events tracked")

    tool_calls = [e for e in comp.events if e.name == AgentEventTypes.TOOL_CALL]
    print(f"Tool calls: {len(tool_calls)}")
    for tc in tool_calls:
        print(f"  - {tc.payload.get('tool_name')}")

    task_ends = [e for e in comp.events if e.name == AgentEventTypes.TASK_END]
    print(f"Tasks completed: {len(task_ends)}")

asyncio.run(run())
```

## Adding Constraints

```python
from pyrapide.agent_templates.core.patterns import AgentPatterns
from pyrapide.constraints.pattern_constraints import MustMatch, Never

# Every tool call must produce a result (no orphaned calls)
must_complete = MustMatch(
    AgentPatterns.tool_roundtrip(),
    name="tool-must-complete",
    description="Every tool call must produce a result",
)

# Tasks must complete (task_start -> task_end)
must_finish_tasks = MustMatch(
    AgentPatterns.task_lifecycle(),
    name="tasks-must-finish",
    description="Every task must reach completion",
)

# No error cascades across agents
no_cascade = Never(
    AgentPatterns.error_cascade(),
    name="no-error-cascade",
    description="Errors must not propagate into further errors",
)

from pyrapide.constraints.conformance import check_conformance
violations = check_conformance(adapter.computation, [must_complete, must_finish_tasks, no_cascade])
for v in violations:
    print(f"VIOLATION: {v.constraint_name} -- {v.description}")
```

## Post-Run Analysis

```python
from pyrapide.analysis import queries, visualization

comp = adapter.computation

# Which tool calls led to the final task output?
task_end = [e for e in comp.events if e.name == "agent.task.end"][-1]
roots = queries.root_causes(comp, task_end)
print(f"Task result caused by {len(roots)} root events")

# Critical path through the crew execution
path = queries.critical_path(comp)
print("Critical path:", " -> ".join(e.name for e in path))

# Find parallel (concurrent) work across agents
parallel = queries.parallel_events(comp)
for group in parallel:
    print(f"  Concurrent: {[e.name for e in group]}")

# Bottleneck detection
bottlenecks = queries.bottleneck_events(comp)
print(f"Bottleneck events: {[e.name for e in bottlenecks]}")

# Visualization
print(visualization.to_ascii(comp))
print(visualization.summary(comp))
dot = visualization.to_dot(comp)                  # Graphviz DOT
mermaid = visualization.to_mermaid(comp)          # Mermaid diagram
```

## API Reference

```python
class CrewAIAdapter(BaseAgentAdapter):
    def __init__(self, name: str) -> None
        """Create adapter. Tool hooks are registered lazily."""

    def on_step(self, step_output: Any) -> None
        """Pass as step_callback to Crew(). Emits STEP_START or STEP_END
        depending on whether output is AgentAction or AgentFinish."""

    def on_task(self, task_output: Any) -> None
        """Pass as task_callback to Crew(). Emits TASK_END with task metadata."""

    @property
    def computation(self) -> Computation
        """The internal Computation containing all recorded events."""

    @property
    def tracker(self) -> CausalTracker
        """The CausalTracker managing event relationships."""

    def emit(self, event_type, payload, *, parent_id=None, correlation_id=None, source=None, metadata=None) -> Event
        """Create, record, and enqueue a PyRapide Event."""

    async def events(self) -> AsyncIterator[Event]
        """Yield events as they are emitted. Implements EventSource protocol.
        Installs global tool hooks on first iteration."""

    async def close(self) -> None
        """Signal that no more events will be produced. Unregisters tool hooks."""
```

## Troubleshooting

| Issue | Fix |
|---|---|
| `ImportError: crewai` | Run `pip install crewai` |
| No tool events captured | Tool hooks are installed lazily on first `events()` iteration; call `adapter._install_hooks()` explicitly before `crew.kickoff()` if not using the async iterator |
| Steps missing | Ensure `step_callback=adapter.on_step` is passed to the `Crew` constructor |
| Tasks missing | Ensure `task_callback=adapter.on_task` is passed to the `Crew` constructor |
| `close()` hangs | Always `await adapter.close()` after `crew.kickoff()` returns to terminate the event iterator |
| Hook conflicts | Only one `CrewAIAdapter` should register global tool hooks per process; multiple adapters will receive duplicate events |

## Related Files

- [`agent_templates/crewai/adapter.py`](adapter.py) -- CrewAIAdapter implementation
- [`agent_templates/crewai/template.py`](template.py) -- Runnable example
- [`agent_templates/core/base_adapter.py`](../core/base_adapter.py) -- BaseAgentAdapter base class
- [`agent_templates/core/event_types.py`](../core/event_types.py) -- AgentEventTypes constants
- [`agent_templates/core/causal_tracker.py`](../core/causal_tracker.py) -- CausalTracker engine
- [`agent_templates/core/patterns.py`](../core/patterns.py) -- AgentPatterns library
- [`pyrapide-agent-documentation.md`](../../pyrapide-agent-documentation.md) -- Full PyRapide agent docs
