"""CrewAI + PyRapide integration template.

This runnable example shows how to instrument a CrewAI crew with
PyRapide causal event tracking.

Prerequisites::

    pip install pyrapide crewai crewai-tools

Overview
--------
CrewAI orchestrates multiple agents working together on tasks.
PyRapide hooks in via two mechanisms:

1. **Global tool hooks** -- automatically capture every tool call and
   result across all agents (registered by the adapter).

2. **Step and task callbacks** -- passed to the ``Crew`` constructor to
   capture agent reasoning steps and task completions.

The integration requires **three lines of code**:

1. Create the adapter::

       adapter = CrewAIAdapter("my-crew")

2. Pass callbacks to the Crew::

       crew = Crew(
           ...,
           step_callback=adapter.on_step,
           task_callback=adapter.on_task,
       )

3. (Optional) Install tool hooks explicitly before kickoff::

       adapter._install_hooks()

All tool calls, agent steps, and task completions are automatically
tracked with full causal lineage.
"""

from __future__ import annotations

import asyncio


async def main() -> None:
    """Run a simple CrewAI crew with PyRapide instrumentation."""

    # --- Standard CrewAI setup --------------------------------------------

    from crewai import Agent, Crew, Process, Task
    from crewai_tools import SerperDevTool

    search_tool = SerperDevTool()

    researcher = Agent(
        role="Senior Research Analyst",
        goal="Find and summarize the latest trends in AI agent frameworks.",
        backstory=(
            "You are an expert AI researcher who specializes in "
            "analyzing agent framework ecosystems."
        ),
        verbose=True,
        tools=[search_tool],
    )

    writer = Agent(
        role="Technical Writer",
        goal="Create a concise summary of the research findings.",
        backstory=(
            "You are a skilled technical writer who excels at "
            "distilling complex topics into clear prose."
        ),
        verbose=True,
    )

    research_task = Task(
        description=(
            "Research the current state of AI agent frameworks in 2025. "
            "Focus on AutoGen, LangGraph, and CrewAI. Identify key "
            "trends, strengths, and limitations."
        ),
        expected_output="A structured research summary with key findings.",
        agent=researcher,
    )

    write_task = Task(
        description=(
            "Using the research findings, write a 200-word executive "
            "summary suitable for a technical blog post."
        ),
        expected_output="A polished 200-word summary.",
        agent=writer,
    )

    # --- PyRapide instrumentation (3 lines) --------------------------------

    from pyrapide.agent_templates.crewai import CrewAIAdapter

    adapter = CrewAIAdapter("crewai-demo")

    crew = Crew(
        agents=[researcher, writer],
        tasks=[research_task, write_task],
        process=Process.sequential,
        verbose=True,
        step_callback=adapter.on_step,
        task_callback=adapter.on_task,
    )

    # --- Run the crew ------------------------------------------------------

    # Collect events in the background
    collected_events: list = []

    async def collect_events() -> None:
        async for event in adapter.events():
            collected_events.append(event)
            print(f"  [{event.name}] {event.payload.get('framework_event_type', '')}")

    event_task = asyncio.create_task(collect_events())

    # Kickoff runs synchronously in CrewAI
    result = crew.kickoff()

    # Signal done and wait for event collection to finish
    await adapter.close()
    await event_task

    # --- Inspect results ---------------------------------------------------

    print(f"\nCrew result:\n{result}\n")
    print(f"Collected {len(collected_events)} PyRapide events:\n")

    for ev in collected_events:
        payload = ev.payload
        event_detail = payload.get("tool_name") or payload.get("step_type", "")
        print(
            f"  {ev.name:<30} "
            f"detail={event_detail:<20} "
            f"id={ev.id[:8]}"
        )

    # Access the causal computation graph
    computation = adapter.computation
    print(f"\nComputation has {len(computation)} events with causal links.")

    # Analyze tool usage
    from pyrapide.agent_templates.core.event_types import AgentEventTypes

    tool_calls = [
        e for e in computation
        if e.name == AgentEventTypes.TOOL_CALL
    ]
    print(f"Total tool calls: {len(tool_calls)}")
    for tc in tool_calls:
        print(f"  - {tc.payload.get('tool_name')}")

    task_ends = [
        e for e in computation
        if e.name == AgentEventTypes.TASK_END
    ]
    print(f"Tasks completed: {len(task_ends)}")


if __name__ == "__main__":
    asyncio.run(main())
