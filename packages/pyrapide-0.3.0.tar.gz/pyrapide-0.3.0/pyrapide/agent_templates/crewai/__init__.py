"""PyRapide adapter for CrewAI.

Provides ``CrewAIAdapter`` which hooks into CrewAI via its tool hook
system and step/task callbacks to emit causal events for every tool
invocation, step, and task lifecycle event.

Usage::

    from pyrapide.agent_templates.crewai import CrewAIAdapter

    adapter = CrewAIAdapter("my-crewai-app")
    crew = Crew(
        ...,
        step_callback=adapter.on_step,
        task_callback=adapter.on_task,
    )
"""

from pyrapide.agent_templates.crewai.adapter import CrewAIAdapter

__all__ = ["CrewAIAdapter"]
