"""CrewAI adapter for PyRapide causal event tracking.

Hooks into CrewAI via its global tool hook system and step/task
callbacks to translate crew execution events into unified PyRapide
events with automatic causal linking.

All framework imports are lazy (inside methods) so this module can be
imported even when ``crewai`` is not installed.
"""

from __future__ import annotations

import logging
from typing import Any

from pyrapide.agent_templates.core.base_adapter import BaseAgentAdapter
from pyrapide.agent_templates.core.event_types import AgentEventTypes

logger = logging.getLogger(__name__)


class CrewAIAdapter(BaseAgentAdapter):
    """Instrument a CrewAI crew with PyRapide causal tracking.

    Parameters
    ----------
    name:
        Human-readable adapter name (appears in event ``source`` fields).

    The adapter provides two integration points:

    **Tool hooks** (automatic via ``_install_hooks``)::

        Registers global before/after tool call hooks that emit
        ``TOOL_CALL`` and ``TOOL_RESULT`` events automatically for
        every tool invocation across all agents in the process.

    **Step and task callbacks** (manual via ``on_step`` / ``on_task``)::

        Pass these to the ``Crew`` constructor to track agent steps
        and task lifecycle events::

            crew = Crew(
                agents=[...],
                tasks=[...],
                step_callback=adapter.on_step,
                task_callback=adapter.on_task,
            )

    Example::

        from pyrapide.agent_templates.crewai import CrewAIAdapter

        adapter = CrewAIAdapter("my-crew")
        crew = Crew(
            agents=[researcher, writer],
            tasks=[research_task, write_task],
            step_callback=adapter.on_step,
            task_callback=adapter.on_task,
        )
        result = crew.kickoff()
    """

    def __init__(self, name: str) -> None:
        super().__init__(name, framework_instance=None)
        self._hooks_registered = False
        self._before_hook_fn: Any | None = None
        self._after_hook_fn: Any | None = None

    # -- Public callback API -----------------------------------------------

    def on_step(self, step_output: Any) -> None:
        """Callback for CrewAI ``step_callback``.

        Pass this method directly to the ``Crew`` constructor::

            Crew(..., step_callback=adapter.on_step)

        Emits a ``STEP_START`` / ``STEP_END`` pair.  CrewAI invokes
        ``step_callback`` once per agent step with the step output.

        Parameters
        ----------
        step_output:
            The ``AgentFinish`` or ``AgentAction`` output from CrewAI.
        """
        step_data = self._extract_step_data(step_output)

        if step_data.get("step_type") == "action":
            # An intermediate agent action (tool use decision)
            self.emit(
                AgentEventTypes.STEP_START,
                {
                    "framework": "crewai",
                    "framework_event_type": "step_action",
                    **step_data,
                },
            )
        else:
            # A final agent output for this step
            self.emit(
                AgentEventTypes.STEP_END,
                {
                    "framework": "crewai",
                    "framework_event_type": "step_finish",
                    **step_data,
                },
            )

    def on_task(self, task_output: Any) -> None:
        """Callback for CrewAI ``task_callback``.

        Pass this method directly to the ``Crew`` constructor::

            Crew(..., task_callback=adapter.on_task)

        Emits a ``TASK_END`` event.  CrewAI invokes ``task_callback``
        once per completed task with the task output.

        Parameters
        ----------
        task_output:
            The ``TaskOutput`` from CrewAI containing the task result.
        """
        task_data = self._extract_task_data(task_output)

        self.emit(
            AgentEventTypes.TASK_END,
            {
                "framework": "crewai",
                "framework_event_type": "task_complete",
                **task_data,
            },
        )

    # -- Hook installation -------------------------------------------------

    def _install_hooks(self) -> None:
        """Register global tool hooks via CrewAI's hook system.

        Registers ``before_tool_call`` and ``after_tool_call`` hooks
        that emit ``TOOL_CALL`` and ``TOOL_RESULT`` events for every
        tool invocation across all agents.
        """
        if self._hooks_registered:
            return

        try:
            from crewai.hooks import (
                register_before_tool_call_hook,
                register_after_tool_call_hook,
            )
        except ImportError as exc:
            raise ImportError(
                "CrewAIAdapter requires the 'crewai' package. "
                "Install it with: pip install crewai"
            ) from exc

        adapter = self  # capture for closures

        def _before_tool_call(tool_name: str, tool_input: Any) -> None:
            """Emit TOOL_CALL before each tool invocation."""
            adapter.emit(
                AgentEventTypes.TOOL_CALL,
                {
                    "framework": "crewai",
                    "framework_event_type": "before_tool_call",
                    "tool_name": str(tool_name),
                    "tool_input": _safe_repr(tool_input),
                },
            )

        def _after_tool_call(
            tool_name: str, tool_input: Any, tool_output: Any
        ) -> None:
            """Emit TOOL_RESULT after each successful tool invocation."""
            adapter.emit(
                AgentEventTypes.TOOL_RESULT,
                {
                    "framework": "crewai",
                    "framework_event_type": "after_tool_call",
                    "tool_name": str(tool_name),
                    "tool_input": _safe_repr(tool_input),
                    "tool_output": _safe_repr(tool_output),
                },
            )

        register_before_tool_call_hook(_before_tool_call)
        register_after_tool_call_hook(_after_tool_call)

        self._before_hook_fn = _before_tool_call
        self._after_hook_fn = _after_tool_call
        self._hooks_registered = True

        logger.info("PyRapide: registered CrewAI global tool hooks.")

    def _uninstall_hooks(self) -> None:
        """Best-effort removal of registered tool hooks."""
        if not self._hooks_registered:
            return

        try:
            from crewai.hooks import (
                unregister_before_tool_call_hook,
                unregister_after_tool_call_hook,
            )

            if self._before_hook_fn is not None:
                unregister_before_tool_call_hook(self._before_hook_fn)
            if self._after_hook_fn is not None:
                unregister_after_tool_call_hook(self._after_hook_fn)
        except (ImportError, AttributeError):
            logger.debug(
                "PyRapide: could not unregister CrewAI tool hooks "
                "(unregister API may not be available)."
            )

        self._before_hook_fn = None
        self._after_hook_fn = None
        self._hooks_registered = False

    # -- Internal ----------------------------------------------------------

    def _extract_step_data(self, step_output: Any) -> dict[str, Any]:
        """Extract structured data from a CrewAI step output.

        Handles both ``AgentAction`` and ``AgentFinish`` types
        without importing them at module level.
        """
        data: dict[str, Any] = {}

        try:
            # AgentAction has: tool, tool_input, log
            if hasattr(step_output, "tool"):
                data["step_type"] = "action"
                data["tool"] = str(step_output.tool)
                data["tool_input"] = _safe_repr(step_output.tool_input)
                data["log"] = str(getattr(step_output, "log", ""))[:500]
            # AgentFinish has: return_values, log
            elif hasattr(step_output, "return_values"):
                data["step_type"] = "finish"
                return_values = step_output.return_values
                if isinstance(return_values, dict):
                    data["output"] = _safe_repr(
                        return_values.get("output", return_values)
                    )
                else:
                    data["output"] = _safe_repr(return_values)
                data["log"] = str(getattr(step_output, "log", ""))[:500]
            else:
                # Unknown step output type -- capture what we can
                data["step_type"] = "unknown"
                data["raw"] = _safe_repr(step_output)
        except Exception:
            data["step_type"] = "error"
            data["raw"] = _safe_repr(step_output)

        return data

    def _extract_task_data(self, task_output: Any) -> dict[str, Any]:
        """Extract structured data from a CrewAI TaskOutput."""
        data: dict[str, Any] = {}

        try:
            if hasattr(task_output, "description"):
                data["task_description"] = str(task_output.description)[:500]
            if hasattr(task_output, "raw"):
                data["raw_output"] = str(task_output.raw)[:1000]
            if hasattr(task_output, "summary"):
                data["summary"] = str(task_output.summary)[:500]
            if hasattr(task_output, "agent"):
                data["agent"] = str(task_output.agent)[:100]
            if hasattr(task_output, "pydantic"):
                data["has_structured_output"] = task_output.pydantic is not None
            if hasattr(task_output, "json_dict"):
                data["has_json_output"] = task_output.json_dict is not None
        except Exception:
            data["raw"] = _safe_repr(task_output)

        return data


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _safe_repr(obj: Any, max_len: int = 500) -> str:
    """Return a truncated repr that won't blow up event payloads."""
    try:
        text = repr(obj)
    except Exception:
        text = f"<{type(obj).__name__}>"
    if len(text) > max_len:
        return text[: max_len - 3] + "..."
    return text
