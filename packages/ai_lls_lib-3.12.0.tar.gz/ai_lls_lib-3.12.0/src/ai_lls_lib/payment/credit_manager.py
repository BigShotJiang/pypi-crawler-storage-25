"""Credit balance management with DynamoDB."""

import logging
import os
from datetime import UTC, datetime
from decimal import Decimal
from typing import TYPE_CHECKING, Any

try:
    import boto3
    from botocore.exceptions import ClientError

    HAS_BOTO3 = True
except ImportError:
    boto3 = None  # type: ignore[assignment]
    HAS_BOTO3 = False

if TYPE_CHECKING:
    from mypy_boto3_dynamodb.service_resource import Table

logger = logging.getLogger(__name__)


class InsufficientCreditsError(Exception):
    """Raised when user has insufficient credits for an operation."""

    def __init__(self, credits_required: int, credits_available: int):
        self.credits_required = credits_required
        self.credits_available = credits_available
        super().__init__(
            f"Insufficient credits: required {credits_required}, available {credits_available}"
        )


class CreditManager:
    """
    Manages user credit balances in DynamoDB CreditsTable.
    """

    table: "Table | None"

    def __init__(self, table_name: str | None = None):
        """Initialize with DynamoDB table."""
        if not HAS_BOTO3 or not boto3:
            raise RuntimeError("boto3 is required for CreditManager")

        self.dynamodb = boto3.resource("dynamodb")
        self.table_name = table_name if table_name else os.environ["CREDITS_TABLE"]

        try:
            self.table = self.dynamodb.Table(self.table_name)
        except Exception as e:
            logger.error(f"Failed to connect to DynamoDB table {self.table_name}: {e}")
            self.table = None

    def get_balance(self, user_id: str) -> int:
        """Get current credit balance for a user."""
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            response = self.table.get_item(Key={"user_id": user_id})
            if "Item" in response:
                credits_val = response["Item"].get("credits", 0)
                # DynamoDB returns Decimal for numbers - convert safely
                if credits_val is None:
                    return 0
                return int(Decimal(str(credits_val)))
            return 0
        except ClientError as e:
            logger.error(f"Error getting balance for {user_id}: {e}")
            return 0

    def add_credits(self, user_id: str, amount: int) -> int:
        """Add credits to user balance and return new balance."""
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            response = self.table.update_item(
                Key={"user_id": user_id},
                UpdateExpression="ADD credits :amount SET updated_at = :now",
                ExpressionAttributeValues={
                    ":amount": Decimal(amount),
                    ":now": datetime.now(UTC).isoformat(),
                },
                ReturnValues="ALL_NEW",
            )
            attrs = response.get("Attributes", {})
            credits_val = attrs.get("credits", 0)
            # DynamoDB returns Decimal for numbers - convert safely
            if credits_val is None:
                return 0
            return int(Decimal(str(credits_val)))
        except ClientError as e:
            logger.error(f"Error adding credits for {user_id}: {e}")
            raise

    def deduct_credits(self, user_id: str, amount: int) -> bool:
        """
        Deduct credits from user balance.
        Returns True if successful, False if insufficient balance.
        """
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            # Conditional update - only deduct if balance >= amount
            self.table.update_item(
                Key={"user_id": user_id},
                UpdateExpression="ADD credits :negative_amount SET updated_at = :now",
                ConditionExpression="credits >= :amount",
                ExpressionAttributeValues={
                    ":negative_amount": Decimal(-amount),
                    ":amount": Decimal(amount),
                    ":now": datetime.now(UTC).isoformat(),
                },
            )
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                logger.info(f"Insufficient credits for {user_id}")
                return False
            logger.error(f"Error deducting credits for {user_id}: {e}")
            raise

    def set_credits(self, user_id: str, credits: int, reason: str | None = None) -> int:
        """Set user credit balance to an exact value and return new balance."""
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            if reason:
                logger.info(f"Setting credits for {user_id} to {credits}: {reason}")

            response = self.table.update_item(
                Key={"user_id": user_id},
                UpdateExpression="SET credits = :credits, updated_at = :now",
                ExpressionAttributeValues={
                    ":credits": Decimal(credits),
                    ":now": datetime.now(UTC).isoformat(),
                },
                ReturnValues="ALL_NEW",
            )
            attrs = response.get("Attributes", {})
            credits_val = attrs.get("credits", 0)
            if credits_val is None:
                return 0
            return int(Decimal(str(credits_val)))
        except ClientError as e:
            logger.error(f"Error setting credits for {user_id}: {e}")
            raise

    def set_subscription_state(
        self,
        user_id: str,
        status: str,
        stripe_customer_id: str | None = None,
        stripe_subscription_id: str | None = None,
    ) -> None:
        """Update subscription state in CreditsTable."""
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            update_expr = "SET subscription_status = :status, updated_at = :now"
            expr_values = {":status": status, ":now": datetime.now(UTC).isoformat()}

            if stripe_customer_id:
                update_expr += ", stripe_customer_id = :customer_id"
                expr_values[":customer_id"] = stripe_customer_id

            if stripe_subscription_id:
                update_expr += ", stripe_subscription_id = :subscription_id"
                expr_values[":subscription_id"] = stripe_subscription_id

            self.table.update_item(
                Key={"user_id": user_id},
                UpdateExpression=update_expr,
                ExpressionAttributeValues=expr_values,
            )
        except ClientError as e:
            logger.error(f"Error updating subscription state for {user_id}: {e}")
            raise

    def get_user_payment_info(self, user_id: str) -> dict[str, Any]:
        """Get user's payment-related information."""
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            response = self.table.get_item(Key={"user_id": user_id})
            if "Item" in response:
                item = response["Item"]
                credits_val = item.get("credits", 0)
                # DynamoDB returns Decimal for numbers - convert safely
                credits_int = 0 if credits_val is None else int(Decimal(str(credits_val)))
                return {
                    "credits": credits_int,
                    "stripe_customer_id": item.get("stripe_customer_id"),
                    "stripe_subscription_id": item.get("stripe_subscription_id"),
                    "subscription_status": item.get("subscription_status"),
                }
            return {
                "credits": 0,
                "stripe_customer_id": None,
                "stripe_subscription_id": None,
                "subscription_status": None,
            }
        except ClientError as e:
            logger.error(f"Error getting payment info for {user_id}: {e}")
            return {
                "credits": 0,
                "stripe_customer_id": None,
                "stripe_subscription_id": None,
                "subscription_status": None,
            }

    def has_unlimited_access(self, user_id: str) -> bool:
        """Check if user has unlimited access via active subscription."""
        info = self.get_user_payment_info(user_id)
        return info.get("subscription_status") == "active"

    def set_stripe_customer_id(self, user_id: str, stripe_customer_id: str) -> None:
        """Store Stripe customer ID for a user."""
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            self.table.update_item(
                Key={"user_id": user_id},
                UpdateExpression="SET stripe_customer_id = :customer_id, updated_at = :now",
                ExpressionAttributeValues={
                    ":customer_id": stripe_customer_id,
                    ":now": datetime.now(UTC).isoformat(),
                },
            )
            logger.info(f"Stored Stripe customer ID {stripe_customer_id} for user {user_id}")
        except ClientError as e:
            logger.error(f"Error storing Stripe customer ID for {user_id}: {e}")
            raise

    def idempotent_credit_grant(self, user_id: str, amount: int, payment_intent_id: str) -> bool:
        """Grant credits only if payment_intent_id hasn't been processed before.

        Uses DynamoDB conditional update with a processed_payments string set
        to prevent double-crediting.

        Returns True if credits were granted, False if already processed.
        """
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            self.table.update_item(
                Key={"user_id": user_id},
                UpdateExpression=(
                    "ADD credits :amount, processed_payments :pid_set SET updated_at = :now"
                ),
                ConditionExpression="NOT contains(processed_payments, :pid)",
                ExpressionAttributeValues={
                    ":amount": Decimal(amount),
                    ":pid_set": {payment_intent_id},
                    ":pid": payment_intent_id,
                    ":now": datetime.now(UTC).isoformat(),
                },
            )
            logger.info(f"Granted {amount} credits to {user_id} for payment {payment_intent_id}")
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                logger.info(f"Payment {payment_intent_id} already processed for {user_id}")
                return False
            logger.error(f"Error granting credits for {user_id}: {e}")
            raise

    def grant_first_card_bonus(self, user_id: str, bonus_amount: int = 700) -> dict[str, Any]:
        """Grant one-time credit bonus on first card save.

        Uses conditional update on first_card_bonus_granted flag to prevent
        duplicate grants.

        Returns dict with granted status, credits_added, and message.
        """
        if not self.table:
            raise RuntimeError(f"DynamoDB table {self.table_name} not accessible")

        try:
            self.table.update_item(
                Key={"user_id": user_id},
                UpdateExpression=(
                    "SET first_card_bonus_granted = :true_val, updated_at = :now ADD credits :bonus"
                ),
                ConditionExpression=(
                    "attribute_not_exists(first_card_bonus_granted) "
                    "OR first_card_bonus_granted = :false_val"
                ),
                ExpressionAttributeValues={
                    ":true_val": True,
                    ":false_val": False,
                    ":bonus": Decimal(bonus_amount),
                    ":now": datetime.now(UTC).isoformat(),
                },
            )
            logger.info(f"Granted {bonus_amount} first-card bonus to {user_id}")
            return {
                "granted": True,
                "credits_added": bonus_amount,
                "message": f"First card bonus of {bonus_amount} credits granted",
            }
        except ClientError as e:
            if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
                logger.info(f"First card bonus already granted for {user_id}")
                return {
                    "granted": False,
                    "credits_added": 0,
                    "message": "First card bonus already granted",
                }
            logger.error(f"Error granting first card bonus for {user_id}: {e}")
            raise

    def check_and_deduct(self, user_id: str, amount: int) -> dict[str, Any]:
        """Check unlimited access, then check balance, then deduct credits.

        Returns dict with deducted status, amount, unlimited flag, and balance.
        Raises InsufficientCreditsError if balance is insufficient.
        """
        if self.has_unlimited_access(user_id):
            return {"deducted": False, "amount": 0, "unlimited": True, "balance": 0}

        balance = self.get_balance(user_id)
        if balance < amount:
            raise InsufficientCreditsError(credits_required=amount, credits_available=balance)

        success = self.deduct_credits(user_id, amount)
        if not success:
            # Race condition: balance changed between check and deduct
            balance = self.get_balance(user_id)
            raise InsufficientCreditsError(credits_required=amount, credits_available=balance)

        new_balance = self.get_balance(user_id)
        return {
            "deducted": True,
            "amount": amount,
            "unlimited": False,
            "balance": new_balance,
        }
