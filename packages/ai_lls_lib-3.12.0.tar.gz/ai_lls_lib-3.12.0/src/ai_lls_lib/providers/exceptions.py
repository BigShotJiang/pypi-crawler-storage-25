"""Exception classes for verification providers."""


class ProviderError(ValueError):
    """Raised when an upstream verification provider fails.

    Extends ValueError for backward compatibility with existing
    error handlers. Carries an optional HTTP status code from the
    upstream response so callers can distinguish client errors from
    server/network failures.
    """

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code
