"""Type validation helpers."""
