from __future__ import annotations

from argparse import ArgumentParser, Namespace
import sys
from typing import TYPE_CHECKING

from .debug import _print_debug_info

if TYPE_CHECKING:
    from .info import ExitCode, _BumpType, _Version


def _debug_info() -> ExitCode:  # pragma: no cover
    """CLI command to print debug information."""
    from .info import ExitCode

    _print_debug_info()
    return ExitCode.SUCCESS


def bump_version(b: _BumpType) -> ExitCode:
    """Bump the version of the current package.

    Args:
        b: The type of bump ("major", "minor", or "patch").
        v: A Version instance representing the current version.

    Returns:
        An ExitCode indicating success or failure.
    """
    from .info import _VALIDS, METADATA, ExitCode

    v: _Version = METADATA.version_tuple
    if b not in _VALIDS:
        print(f"Invalid argument '{b}'. Use one of: {', '.join(_VALIDS)}.")
        return ExitCode.FAILURE

    if v == (0, 0, 0):
        print("Current version is 0.0.0, cannot bump version.")
        return ExitCode.FAILURE
    try:
        new_version: _Version = v.new_version(b)
        print(str(new_version))
        return ExitCode.SUCCESS
    except ValueError:
        print(f"Invalid version tuple: {v}")
        return ExitCode.FAILURE


def _version(name: bool = False) -> ExitCode:  # pragma: no cover
    """CLI command to get the current version of the package."""
    from .info import METADATA, ExitCode

    print(f"{METADATA.name} {METADATA.version}" if name else METADATA.version)
    return ExitCode.SUCCESS


def _to_args(args: list[str]) -> Namespace:  # pragma: no cover
    """Convert a list of arguments into a Namespace object."""
    from .info import METADATA

    parser = ArgumentParser(prog=METADATA.name, description="Lazy Bear CLI")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("debug", help="Print debug information")
    version_parser: ArgumentParser = subparsers.add_parser("version", help="Get the current version")
    version_parser.add_argument("--name", action="store_true", help="Include the package name in the output")
    bump_parser: ArgumentParser = subparsers.add_parser("bump", help="Bump the version of the package")
    bump_parser.add_argument("bump_type", choices=["major", "minor", "patch"], help="Type of version bump")
    return parser.parse_args(args)


def main(args: list[str] | None = None) -> ExitCode:
    """Entry point for the CLI application.

    This function is executed when you type `lazy_bear` or `python -m lazy_bear`.

    Parameters:
        args: Arguments passed from the command line.

    Returns:
        An exit code.
    """
    if args is None:
        args = sys.argv[1:]
    arguments = _to_args(args)

    from .info import ExitCode

    command: str = arguments.command
    match command:
        case "debug":
            return _debug_info()
        case "version":
            return _version(name=arguments.name)
        case "bump":
            return bump_version(arguments.bump_type)
        case _:  # pragma: no cover
            print(f"Unknown command: {command}", file=sys.stderr)
            return ExitCode.FAILURE


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))

# ruff: noqa: PLC0415
