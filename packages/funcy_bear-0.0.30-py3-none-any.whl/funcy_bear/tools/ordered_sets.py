"""Ordered Sets package.

Simply an Ordered Set and a Frozen Ordered Set
"""

from __future__ import annotations

from collections.abc import Callable, Iterable
from typing import Final, NoReturn, Self, overload


def _immutable(self, *args, **kwargs) -> NoReturn:  # noqa: ANN001, ARG001
    raise TypeError("This data structure is immutable and cannot be modified.")


NOT_FOUND: Final = -1


class OrderedSet[K](dict[K, None]):
    """A set that preserves the order of insertion."""

    def __init__(self, *items: K | Iterable[K]) -> None:
        """Initialize the OrderedSet with the given items."""
        if len(items) == 1 and not isinstance(items[0], (str, bytes)) and isinstance(items[0], Iterable):
            items: Iterable[K] = items[0]  # ty:ignore[invalid-assignment]
        for item in items:
            dict.__setitem__(self, item, None)

    def add(self, key: K) -> None:
        """Add a key to the set."""
        dict.__setitem__(self, key, None)

    def discard(self, key: K) -> None:
        """Remove a key from the set if it exists."""
        self.pop(key, None)

    def index(self, key: K) -> int:
        """Return the index of a key in the set.

        Args:
            key: The key to find the index of.

        Returns:
            The index of the key if found, otherwise -1.
        """
        if key not in self:
            return NOT_FOUND
        for i, k in enumerate(self.keys()):
            if k == key:
                return i
        return NOT_FOUND

    def intersection(self, other: Iterable[K]) -> OrderedSet[K]:
        """Return a new OrderedSet containing elements common to both sets."""
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        temp: OrderedSet[K] = OrderedSet()
        for key in self:
            if key in other:
                temp.add(key)
        return temp

    def difference(self, other: Iterable[K]) -> OrderedSet[K]:
        """Return a new OrderedSet containing elements in this set but not in the other."""
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        temp: OrderedSet[K] = OrderedSet()
        for key in self:
            if key not in other:
                temp.add(key)
        return temp

    def __and__(self, other: Iterable[K]) -> OrderedSet[K]:
        """Return the intersection of this set and another.

        This is the same as the `intersection` method, but allows using the `&` operator for convenience.
        """
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        temp: OrderedSet[K] = OrderedSet()
        for key in self:
            if key in other:
                temp.add(key)
        return temp

    def __iand__(self, other: Iterable[K]) -> Self:
        """Update this set to the intersection of itself and another.

        This modifies the set in place, removing any elements that are not in the other set. It allows using the `&=` operator for convenience.
        """
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        keys_to_remove: list[K] = [key for key in self if key not in other]
        for key in keys_to_remove:
            self.discard(key)
        return self

    def __or__(self, other: Iterable[K]) -> OrderedSet[K]:  # type: ignore[override]
        """Return the union of this set and another.

        This is the same as the `union` method, but allows using the `|` operator for convenience.
        """
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        temp: OrderedSet[K] = OrderedSet(self)
        for key in other:
            temp.add(key)
        return temp

    def __ior__(self, other: Iterable[K]) -> Self:  # ty:ignore[invalid-method-override]
        """Update this set to the union of itself and another.

        This modifies the set in place, adding any elements from the other set that are not already present. It allows using the `|=` operator for convenience.
        """
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        for key in other:
            self.add(key)
        return self

    def __xor__(self, other: Iterable[K]) -> OrderedSet[K]:
        """Return the symmetric difference of this set and another.

        This is the same as the `symmetric_difference` method, but allows using the `^` operator for convenience.
        """
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        temp: OrderedSet[K] = OrderedSet()
        for key in self:
            if key not in other:
                temp.add(key)
        for key in other:
            if key not in self:
                temp.add(key)
        return temp

    def __ixor__(self, other: Iterable[K]) -> Self:
        """Update this set to the symmetric difference of itself and another.

        This modifies the set in place, adding any elements from the other set that are not already present and removing any elements that are present in both sets. It allows using the `^=` operator for convenience.
        """
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        keys_to_remove: list[K] = [key for key in self if key in other]
        for key in keys_to_remove:
            self.discard(key)
        for key in other:
            if key not in self:
                self.add(key)
        return self

    def __sub__(self, other: Iterable[K]) -> OrderedSet[K]:
        """Return the difference of this set and another.

        This is the same as the `difference` method, but allows using the `-` operator for convenience.
        """
        return self.difference(other)

    def __isub__(self, other: Iterable[K]) -> Self:
        """Update this set to the difference of itself and another.

        This modifies the set in place, removing any elements from the other set that are present in this set. It allows using the `-=` operator for convenience.
        """
        if not isinstance(other, (set | frozenset | dict)):
            other: set[K] = set(other)
        for k in [key for key in self if key in other]:
            self.discard(k)
        return self

    def __repr__(self) -> str:
        return f"OrderedSet({list(self.keys())})".replace("[", "{").replace("]", "}")

    @overload
    def to(self, o: type[list]) -> list[K]: ...
    @overload
    def to(self, o: type[set]) -> set[K]: ...
    @overload
    def to(self, o: type[frozenset]) -> frozenset[K]: ...
    @overload
    def to(self, o: type[tuple]) -> tuple[K, ...]: ...
    def to(self, o: type) -> list[K] | set[K] | frozenset[K] | tuple[K, ...]:
        """Convert this OrderedSet to a different set type."""
        if o is list:
            return list(self)
        if o is tuple:
            return tuple(self)
        if o is set:
            return set(self)
        if o is frozenset:
            return frozenset(self)
        raise TypeError(f"Unsupported type for conversion: {o}")

    def to_list(self) -> list[K]:
        """Convert this OrderedSet to a list."""
        return list(self)

    def to_tuple(self) -> tuple[K, ...]:
        """Convert this OrderedSet to a tuple."""
        return tuple(self)

    def to_set(self) -> set[K]:
        """Convert this OrderedSet to a set."""
        return set(self)

    def to_frozenset(self) -> frozenset[K]:
        """Convert this OrderedSet to a frozenset."""
        return frozenset(self)


class FrozenOrderedSet[K](OrderedSet[K]):
    """An immutable version of OrderedSet."""

    def __init__(self, *items: K | Iterable[K]) -> None:
        """Initialize the FrozenOrderedSet with the given items."""
        self._cache_hash: int | None = None
        if len(items) == 1 and not isinstance(items[0], (str, bytes)) and isinstance(items[0], Iterable):
            items = items[0]  # ty:ignore[invalid-assignment]
        for item in items:
            dict.__setitem__(self, item, None)

    # fmt: off
    add:         Callable[..., NoReturn]     = _immutable
    discard:     Callable[..., NoReturn]     = _immutable
    clear:       Callable[..., NoReturn]     = _immutable
    update:      Callable[..., NoReturn]     = _immutable
    pop:         Callable[..., NoReturn]     = _immutable
    __setitem__: Callable[..., NoReturn]     = _immutable
    __delitem__: Callable[..., NoReturn]     = _immutable
    # fmt: o

    def intersection(self, other: Iterable[K]) -> FrozenOrderedSet[K]:
        """Return a new FrozenOrderedSet containing elements common to both sets."""
        if not isinstance(other, (set | frozenset | dict)):
            other = set(other)
        temp: FrozenOrderedSet[K] = FrozenOrderedSet()
        for key in self:
            if key in other:
                dict.__setitem__(temp, key, None)
        return temp

    def difference(self, other: Iterable[K]) -> FrozenOrderedSet[K]:
        """Return a new FrozenOrderedSet containing elements in this set but not in the other."""
        if not isinstance(other, (set | frozenset | dict)):
            other = set(other)
        temp: FrozenOrderedSet[K] = FrozenOrderedSet()
        for key in self:
            if key not in other:
                dict.__setitem__(temp, key, None)
        return temp

    def __and__(self, other: Iterable[K]) -> FrozenOrderedSet[K]:
        """Return the intersection of this set and another."""
        return self.intersection(other)

    def __or__(self, other: Iterable[K]) -> FrozenOrderedSet[Self | K]:  # ty:ignore[invalid-method-override]
        """Return the union of this set and another."""
        if not isinstance(other, (set | frozenset | dict)):
            other = set(other)
        temp: FrozenOrderedSet[Self | K] = FrozenOrderedSet(self)  # ty:ignore[invalid-assignment]
        for key in other:
            if key not in temp:
                dict.__setitem__(temp, key, None)
        return temp

    def __xor__(self, other: Iterable[K]) -> FrozenOrderedSet[K]:
        """Return the symmetric difference of this set and another."""
        if not isinstance(other, (set | frozenset | dict)):
            other = set(other)
        temp: FrozenOrderedSet[K] = FrozenOrderedSet()
        for key in self:
            if key not in other:
                dict.__setitem__(temp, key, None)
        for key in other:
            if key not in self:
                dict.__setitem__(temp, key, None)
        return temp

    def __sub__(self, other: Iterable[K]) -> FrozenOrderedSet[K]:
        """Return the difference of this set and another."""
        if not isinstance(other, (set | frozenset | dict)):
            other = set(other)
        temp: FrozenOrderedSet[K] = FrozenOrderedSet()
        for key in self:
            if key not in other:
                dict.__setitem__(temp, key, None)
        return temp

    def __repr__(self) -> str:
        return f"FrozenOrderedSet({list(self.keys())})".replace("[", "{").replace("]", "}")

    @property
    def cached_hash(self) -> int:
        """Return the cached hash value, computing it if necessary."""
        if self._cache_hash is None:
            self._cache_hash = hash(tuple(self.keys()))
        return self._cache_hash

    def __hash__(self) -> int:
        return self.cached_hash

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, (FrozenOrderedSet, OrderedSet)):
            return NotImplemented
        if isinstance(other, FrozenOrderedSet):
            return self.cached_hash == other.cached_hash
        return self.cached_hash == hash(tuple(other.keys()))


__all__: list[str] = ["FrozenOrderedSet", "OrderedSet"]
