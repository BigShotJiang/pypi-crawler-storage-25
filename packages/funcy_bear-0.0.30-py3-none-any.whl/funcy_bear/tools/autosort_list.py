"""An AutoSort implementation."""

from __future__ import annotations

from collections.abc import Callable, Iterable, MutableSequence
from typing import TYPE_CHECKING, Any

from lazy_bear import lazy

if TYPE_CHECKING:
    from bisect import bisect_left, bisect_right, insort

    from funcy_bear.ops.func_stuffs import identity
else:
    bisect_left, bisect_right, insort = lazy("bisect", "bisect_left", "bisect_right", "insort")
    identity = lazy("funcy_bear.ops.func_stuffs", "identity")


class AutoSort[T](MutableSequence):
    """An implementation of a sorted object list that maintains order on insertions."""

    __slots__: tuple = ("_key", "_list")

    def __init__(self, iterable: list[T] | None = None, key: Callable[[T], Any] = identity) -> None:
        """Initialize the AutoSort with an optional iterable and key function.

        Args:
            iterable (list[T] | None): An optional iterable to initialize the sorted list.
            key (Callable[[T], Any]): A function to extract a comparison key from each list
                element. Defaults to the identity function.
        """
        self._list: list[T] = []
        self._key: Callable[[T], Any] = key

        if iterable is not None:
            self.update(iterable=iterable)

    def update(self, iterable: Iterable[T]) -> None:
        """Update the sorted list with multiple values."""
        self._list.extend(iterable)
        self._list.sort(key=self._key)

    def extend(self, values: Iterable[T]) -> None:
        """Extend the sorted list with multiple values."""
        self._list.extend(values)
        self._list.sort(key=self._key)

    def insert(self, index: int, value: T) -> None:  # noqa: ARG002
        """Insert a value into the sorted list (ignores index)."""
        insort(self._list, value, key=self._key)

    def append(self, value: T) -> None:
        """Insert a value into the sorted list."""
        insort(self._list, value, key=self._key)

    def remove(self, value: T) -> None:
        """Remove a value from the sorted list."""
        self._list.remove(value)

    def bisect_left(self, value: T) -> int:
        """Find the insertion point for value in the sorted list to maintain order (left)."""
        return bisect_left(self._list, value, key=self._key)

    def bisect_right(self, value: T) -> int:
        """Find the insertion point for value in the sorted list to maintain order (right)."""
        return bisect_right(self._list, value, key=self._key)

    def pop_tail(self) -> T | None:
        """Pop and return the last item in the sorted list, or None if empty."""
        if self.empty:
            return None
        return self._list.pop()

    def pop_head(self) -> T | None:
        """Pop and return the first item in the sorted list, or None if empty."""
        if self.empty:
            return None
        return self._list.pop(0)

    def clear(self) -> None:
        """Clear the sorted list."""
        self._list.clear()

    @property
    def head(self) -> T | None:
        """Get the first item in the sorted list, or None if empty."""
        if self.empty:
            return None
        return self._list[0]

    @property
    def tail(self) -> T | None:
        """Get the last item in the sorted list, or None if empty."""
        if self.empty:
            return None
        return self._list[-1]

    @property
    def empty(self) -> bool:
        """Check if the sorted list is empty."""
        return len(self) == 0

    def __len__(self) -> int:
        """Get the length of the sorted list."""
        return len(self._list)

    def __bool__(self) -> bool:
        """Check if the sorted list is non-empty."""
        return not self.empty

    def __getitem__(self, index: int) -> T:  # type: ignore[override]
        """Get an item by index."""
        return self._list.__getitem__(index)

    def __setitem__(self, index: int, value: T) -> None:  # type: ignore[override]
        raise NotImplementedError("Setting items by index is not supported in AutoSort.")
        # del self._list[index]
        # insort(self._list, value, key=self._key)

    def __delitem__(self, index: int) -> None:  # type: ignore[override]
        """Delete an item by index."""
        raise NotImplementedError("Deleting items by index is not supported in AutoSort.")

    def get_all(self) -> list[T]:
        """Get the internal list."""
        return self._list
