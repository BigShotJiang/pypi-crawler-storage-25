r"""A way to declartively write out your Regex Patterns without compiling them upfront.

The stdlib re already caches patterns but this is a way to lazily compile patterns when
they are needed instead of having to create more manual lazy access approaches.

Example:
    from funcy_bear.tools.lazy_regex import LazyPattern
    class LazyRegex:
        stub1 = LazyPattern(r"[^\w\s-]")
        stub2 = LazyPattern(r"[-_\s]+")
        snake = LazyPattern(
            r'''
                    (?<=[a-z])      # preceded by lowercase
                    (?=[A-Z])       # followed by uppercase
                    |               # OR
                    (?<=[A-Z])      # preceded by uppercase
                    (?=[A-Z][a-z])  # followed by uppercase, then lowercase
                ''',
            flags=X,
        )

    value = LazyRegex.stub1.sub(ch.EMPTY_STRING, value.lower())
    print(LazyRegex.stub2.sub(sep, value).strip("-_"))
    print(LazyRegex.snake.sub("_", value).lower())
"""

from __future__ import annotations

from dataclasses import dataclass, field
from re import Pattern, compile as re_compile

type RawPattern = str


@dataclass(slots=True, repr=False)
class LazyPattern:
    """A descriptor for lazy regex compilation."""

    raw: RawPattern
    flags: int = 0
    name: str = field(init=False)

    def __set_name__(self, owner: type, name: str) -> None:
        self.name = name

    def __get__(self, instance: object, owner: type) -> Pattern[str]:
        compiled: Pattern[str] = re_compile(self.raw, self.flags)
        setattr(owner, self.name, compiled)
        return compiled
