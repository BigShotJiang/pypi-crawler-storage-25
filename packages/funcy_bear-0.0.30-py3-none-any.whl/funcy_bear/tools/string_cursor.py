"""String cursor for scanning through a string one character at a time."""

from frozen_cub.string_cursor import StringCursor

__all__ = ["StringCursor"]
