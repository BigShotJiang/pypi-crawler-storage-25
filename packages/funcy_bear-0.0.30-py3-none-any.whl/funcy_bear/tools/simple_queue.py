"""A simple queue implementation."""

from frozen_cub.simple_queue import SimpooQueue

__all__ = ["SimpooQueue"]
