"""Generic flag bitfields that round-trip through Pydantic as readable strings.

`Flags[T]` is a thin BaseModel wrapper around an `IntFlag` value of type T.
On disk it serializes as a comma-separated list of flag names; in memory it
behaves like a typed bitfield with set/unset/test/clear/get_all helpers.

Discovery of the parameter T happens in three places, in priority order:
  1. Explicit:                Flags[ExitFlag](obj_type_=ExitFlag, ...)
  2. Inline construction:     Flags[ExitFlag]()  — captured by __class_getitem__
  3. Pydantic field metadata: as a field on a parent BaseModel; we look at
                               cls.__pydantic_generic_metadata__["args"]

ContextVar scopes the inline-construction trick to a single instantiation so
threads/async tasks don't pollute each other.
"""

from __future__ import annotations

from contextvars import ContextVar
from enum import IntFlag, auto
from typing import Any, Self, cast

from pydantic import BaseModel, Field, field_serializer, field_validator, model_validator


class BaseFlag(IntFlag):
    """Base class for all flag enums in the engine."""

    @classmethod
    def serialize(cls, flag: BaseFlag) -> str:
        """A user-friendly name for this flag, e.g. `FOUND_KEY` → `found key`."""
        return flag.name.lower().replace("_", " ") if flag.name is not None else str(flag.value)

    @classmethod
    def deserialize(cls, s: str) -> Self:
        """Parse a flag from a user-friendly string, e.g. `found key` → `FOUND_KEY`."""
        s = s.lower().replace(" ", "_").strip()
        for flag in cls:
            if flag.name and flag.name.lower() == s:
                return flag
        raise ValueError(f"Unknown {cls.__name__} flag: {s!r}")


def _parse_flag_string[T: BaseFlag](flag_cls: type[T], raw: str) -> T:
    """Convert a comma-separated string of flag names to a bitfield."""
    value: T = flag_cls(0)
    for piece in raw.split(","):
        cleaned: str = piece.strip()
        if cleaned:
            value |= flag_cls.deserialize(cleaned)
    return value


# Set transiently by `__class_getitem__` so model validation can discover T even
# before Pydantic's __pydantic_generic_metadata__ is populated for this site.
_obj_type_ctx: ContextVar[type[BaseFlag] | None] = ContextVar("_flags_obj_type_ctx", default=None)


class Flags[T: BaseFlag = BaseFlag](BaseModel):
    """A typed bitfield of flags.  Generic over a specific BaseFlag enum.

    Construction patterns that all work:
      - `Flags[ExitFlag]()`                                     — empty bitfield
      - `Flags[ExitFlag](value="locked, hidden")`               — string parsed
      - `Flags[ExitFlag](value=ExitFlag.LOCKED | ExitFlag.HIDDEN)` — explicit value
      - `Flags[ExitFlag](obj_type_=ExitFlag, value=...)`        — fully explicit

    As a field on another BaseModel:
      class MyModel(BaseModel):
          flags: Flags[ExitFlag] = Field(default_factory=Flags[ExitFlag])
    """

    obj_type_: type[T] | None = Field(default=None, repr=False, exclude=True)
    """The enum class this bitfield is over.  Resolved in priority order:
    explicit kwarg → ContextVar (set by __class_getitem__) → Pydantic generic metadata."""
    value: T = Field(default=cast("T", 0))
    """The bitfield itself.  Accepts a comma-separated string at construction time
    (`value="locked, hidden"`) and is serialized back to that form on dump."""

    @classmethod
    def __class_getitem__(cls, item: Any) -> Any:
        """Capture T for the next instantiation via ContextVar."""
        if isinstance(item, type) and issubclass(item, BaseFlag):
            _obj_type_ctx.set(item)
        return super().__class_getitem__(item)

    @model_validator(mode="before")
    @classmethod
    def _resolve_obj_type(cls, values: Any) -> Any:
        """Fill obj_type_ from explicit > ContextVar > generic metadata.

        Runs first so the value-coercion validator below has a flag class to work with.
        """
        if not isinstance(values, dict):
            return values
        if values.get("obj_type_") is not None:
            return values
        ctx_type: type[BaseFlag] | None = _obj_type_ctx.get()
        if ctx_type is not None:
            values["obj_type_"] = ctx_type
            return values
        meta: dict[str, Any] = getattr(cls, "__pydantic_generic_metadata__", {})
        args: tuple[type, ...] = meta.get("args", ())
        if args and isinstance(args[0], type) and issubclass(args[0], BaseFlag):
            values["obj_type_"] = args[0]
        return values

    @field_validator("value", mode="before")
    @classmethod
    def _coerce_value(cls, v: Any, info: Any) -> Any:
        """Convert a string `value` into the correct IntFlag bitfield."""
        if isinstance(v, str):
            obj_type: type[BaseFlag] | None = (info.data.get("obj_type_") if info.data else None) or _obj_type_ctx.get()
            if obj_type is None:
                meta: dict[str, Any] = getattr(cls, "__pydantic_generic_metadata__", {})
                args: tuple[type, ...] = meta.get("args", ())
                if args and isinstance(args[0], type) and issubclass(args[0], BaseFlag):
                    obj_type = args[0]
            if obj_type is None:
                raise TypeError("Flags has no obj_type — cannot parse string value.")
            return _parse_flag_string(obj_type, v)
        return v

    @field_serializer("value", mode="plain")
    def _serialize_value(self, _value: T) -> str:
        """Serialize the bitfield as a comma-separated list of flag names."""
        active: tuple[T, ...] = self.get_all()
        if not active:
            return ""
        return ", ".join(self.obj_type.serialize(flag) for flag in active)

    @property
    def obj_type(self) -> type[T]:
        """The enum class this bitfield is over.  Raises if it was never resolved."""
        if self.obj_type_ is None:
            raise TypeError(
                "Flags has no obj_type — construct as Flags[YourFlag]() or pass obj_type_=YourFlag explicitly."
            )
        return self.obj_type_

    def set(self, flag: T) -> None:
        """Turn a flag on."""
        self.value |= flag

    def unset(self, flag: T) -> None:
        """Turn a flag off."""
        self.value &= ~flag

    def test(self, flag: T) -> bool:
        """True if every bit in `flag` is currently set."""
        return (self.value & flag) == flag

    def clear(self) -> None:
        """Turn all flags off."""
        self.value = self.obj_type(0)

    def get_all(self) -> tuple[T, ...]:
        """Return every individual flag that is currently set."""
        return tuple(flag for flag in self.obj_type if flag.value != 0 and self.test(flag))


if __name__ == "__main__":
    # Smoke tests covering all four construction paths + round-trip.

    class TestFlag(BaseFlag):
        NONE = 0
        A = auto()
        B = auto()
        C = auto()

    print("--- 1. Inline Flags[TestFlag]() ---")
    f1: Flags[TestFlag] = Flags[TestFlag]()
    f1.set(TestFlag.A)
    f1.set(TestFlag.C)
    print("  active:", f1.get_all())
    print("  dump:  ", f1.model_dump())
    print("  json:  ", f1.model_dump_json())
    print()

    print("--- 2. Round-trip through JSON as a field on a parent ---")

    class FlagsHolder(BaseModel):
        flags: Flags[TestFlag] = Field(default_factory=Flags[TestFlag])

    holder = FlagsHolder()
    holder.flags.set(TestFlag.B)
    holder.flags.set(TestFlag.A)
    blob: str = holder.model_dump_json()
    print("  serialized:", blob)
    rehydrated = FlagsHolder.model_validate_json(blob)
    print("  A set:", rehydrated.flags.test(TestFlag.A))
    print("  B set:", rehydrated.flags.test(TestFlag.B))
    print("  C set:", rehydrated.flags.test(TestFlag.C))
    print("  active:", rehydrated.flags.get_all())
    print()

    print("--- 3. String value at construction ---")
    f3: Flags[TestFlag] = Flags[TestFlag](value="a, c")  # type: ignore[arg-type]  # validator coerces
    print("  active:", f3.get_all())
    print()

    print("--- 4. Explicit obj_type_ + IntFlag value ---")
    f4 = Flags[TestFlag](obj_type_=TestFlag, value=TestFlag.A | TestFlag.B)
    print("  active:", f4.get_all())
