"""Funcy Bear: A collection of functional programming utilities."""

from funcy_bear._internal.cli import main
from funcy_bear._internal.info import METADATA

__version__: str = METADATA.version

__all__: list[str] = ["METADATA", "__version__", "main"]
