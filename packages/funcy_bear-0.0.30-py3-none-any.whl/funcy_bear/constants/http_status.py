"""HTTP status code constants and enumeration."""

from http import HTTPStatus as HTTPStatusCode

# I used to have my own stupid version of the above here and got rid of it

__all__ = ["HTTPStatusCode"]
