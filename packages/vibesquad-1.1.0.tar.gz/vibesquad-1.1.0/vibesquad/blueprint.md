# 📜 Master Blueprint: The VibeSquad Core Standard

This document defines the **Global Standard** and **Supreme Constitution** for all projects managed by the `VibeSquad`. All agents must strictly adhere to these rules. The VibeSquad will immediately reject any output that violates these standards.

---

## 🏗️ 1. Architecture & Tech Stack

- **Primary Backend:** PHP (Laravel) or Node.js (TypeScript). Chosen by the Commander based on project scope.
- **Frontend:** React with Tailwind CSS (Mandatory).
- **Design System:** Modern, Clean, and Professional UI. Focus on high-quality typography and whitespace.
- **Database:** PostgreSQL (Relational) as default, Redis for caching.
- **Infrastructure:** Docker-based containerization with GitHub Actions for CI/CD.

## 🛡️ 2. Security Protocol (Critical)

- **Zero Trust Policy:** All user inputs must be strictly filtered and validated.
- **Auth/Authz:** JWT-based authentication with mandatory per-logic permission checks.
- **Data Protection:** Passwords must be hashed using Argon2id. Sensitive data must reside in `.env` files.
- **Evidence-Based QA:** Every security patch must be proven with visual evidence (screenshots) or detailed test logs.

## 📝 3. Coding Standards & Documentation

- **Primary Language:** All code comments, technical docs, and user-facing reports must be in **English**.
- **Modularity:** Functions must follow the Single Responsibility Principle. Components must be reusable and atomic.
- **Git Strategy:** Direct pushes to `main` are prohibited. Feature-branch workflow is mandatory. Merge only after passing QA.

## 🤝 4. Orchestration Protocol (Agent Handoff)

- **Handoff Rule:** Every phase (Plan → Arch → Dev) must generate a `handsoff.md` to preserve context.
- **Task Management:** The `project-manager-senior` must finalize `tasklist.md` and receive Commander/KSC approval before execution.
- **QA Loop Integrity:** Developers must request validation from `EvidenceQA`. A maximum of 3 retries is allowed before escalation.

---

## 🎨 5. Philosophy & UI/UX Vision

- **Aesthetic:** Minimalist and Modern. Prioritize clarity and ease of use over decorative elements.
- **Performance:** High-performance rendering. Avoid heavy or excessive animations that hinder UX.
- **Scalability:** Design for future growth, prioritizing code readability for sustainable maintenance.
- **Core Value:** "Rapid MVP development with rock-solid security from Day 1."

---

**Last Updated:** 2026-03-27
**Authority:** VibeSquad (authorized by KSC)
