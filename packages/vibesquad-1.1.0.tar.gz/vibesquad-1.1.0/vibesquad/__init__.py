from .commander import VibeSquad

__version__ = "1.1.0"
__all__ = ["VibeSquad"]
