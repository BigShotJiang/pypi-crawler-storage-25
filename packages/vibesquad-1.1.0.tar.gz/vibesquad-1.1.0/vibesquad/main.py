import sys
import datetime
import yaml
import os
from dotenv import load_dotenv
from .commander import VibeSquad

# Load environment variables from .env file
load_dotenv()

def load_registry(file_path):
    """Load the agent list from the YAML registry file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    except FileNotFoundError:
        # Return default value if file is missing
        return {"agents": []}

def main():
    # 1. Initialize System Components
    # Automatically find the path to agent_registry.yaml within the package.
    base_dir = os.path.dirname(__file__)
    registry_file = os.path.join(base_dir, "agent_registry.yaml")
    
    commander = VibeSquad()
    registry = load_registry(registry_file)
    
    print("========================================")
    print("      VIBESQUAD SYSTEM v1.1.0 ONLINE    ")
    print("  Status: Operational (Free Tier)       ")
    print(f"  Time: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("========================================\n")
    print("Ready for orchestration. Type your command (e.g., '.vis/plan').")
    print("Type 'exit' or 'quit' to terminate.\n")

    while True:
        try:
            user_input = input("CMD >> ").strip()
            
            if user_input.lower() in ['exit', 'quit']:
                print("\n[System] Orchestration terminated. Goodbye.")
                break
            
            if not user_input:
                continue

            # 3. Process Command
            start_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            
            # The handle_input method must exist in commander.py.
            if hasattr(commander, 'handle_input'):
                response = commander.handle_input(user_input)
                
                # MVP: Add Certified Prompt Header
                if "### [SYSTEM COMMAND:" in response or "### [SYSTEM COMMAND: AUTHORIZED BY VIBESQUAD]" in response:
                    print("\n" + "-" * 50)
                    print("  📜 VIBESQUAD CERTIFIED PROMPT GENERATED  ")
                    print("-" * 50)

                print(f"\n{response}\n")
            else:
                # Safety mechanism in case method is missing
                print(f"\n[VibeSquad] Echo: {user_input} (Logic not implemented)\n")

            # 4. Simulation of Pipeline Completion (MVP: .vis/test command)
            if ".vis/test" in user_input.lower():
                print("[System] Running VibeSquad Pipeline Simulation...")
                # Fetch actual stats from blueprint (simulated)
                dummy_stats = {
                    'backend': 'PHP Laravel (Relational)', 
                    'tasks': 7, 
                    'pass_rate': '100% (Visual Evidence Verified)'
                }
                
                # Execute after checking for generate_final_report method existence
                if hasattr(commander, 'generate_final_report'):
                    report = commander.generate_final_report("VIBESQUAD_PROTOTYPE", start_time, dummy_stats)
                    print(f"\n{report}\n")
                else:
                    print("\n[System] Simulation error: Reporting module not found.\n")

        except KeyboardInterrupt:
            print("\n\n[System] Interrupted by user. Shutting down.")
            sys.exit()
        except Exception as e:
            # Output detailed information on error
            print(f"\n❌ [Critical Error] {type(e).__name__}: {str(e)}")

if __name__ == "__main__":
    main()
