import os
import yaml

class VibeSquad:
    def __init__(self, custom_blueprint=None):
        self.base_dir = os.path.dirname(os.path.abspath(__file__)) # Strengthen with absolute path [cite: 2026-03-22]
    
        # [Debugging Output] Verify the actual path seen by Python
        print(f"\n🔍 [Debug] Searching in: {self.base_dir}")
        print(f"📂 [Debug] Files found there: {os.listdir(self.base_dir)}")
    
        self.registry = self._load_registry()
        self.blueprint = self._load_blueprint()

    def get_ai_config(self):
        """
        Retrieves AI provider configurations from environment variables.
        """
        return {
            "openai": os.getenv("OPENAI_API_KEY"),
            "anthropic": os.getenv("ANTHROPIC_API_KEY"),
            "google": os.getenv("GOOGLE_API_KEY"),
            "local": {
                "base_url": os.getenv("LOCAL_AI_BASE_URL", "http://localhost:11434"),
                "api_key": os.getenv("LOCAL_AI_API_KEY")
            }
        }
    
    def _load_registry(self):
        # Path to agent_registry.yaml within the package folder
        path = os.path.join(self.base_dir, "agent_registry.yaml")
        if not os.path.exists(path):
            return {"agents": []} # Return empty list if file doesn't exist
            
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
                return data if data else {"agents": []}
        except Exception:
            return {"agents": []} # Prevent program crash on error
        
    def _load_blueprint(self):
        path = os.path.join(self.base_dir, "blueprint.md")
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception:
            return "Standards: Minimalism, Security, Modern UI." 
        
    def handle_input(self, user_input):
        # 1. .vis/ Prefix Handling (MVP Specification Compliance)
        command_text = user_input.lower().strip()
        if not command_text.startswith(".vis/"):
             return f"[VibeSquad] Analyzing request: '{user_input}'. No specific command assigned yet."
        
        command_text = command_text.replace(".vis/", "")

        # 2. AI Provider Selection Handling
        provider = "default"
        if command_text.startswith("local"):
            provider = "Local AI (Ollama/LocalAI)"
            command_text = command_text.replace("local", "").strip()
        elif command_text.startswith("gpt"):
            provider = "OpenAI GPT"
            command_text = command_text.replace("gpt", "").strip()
        elif command_text.startswith("claude"):
            provider = "Anthropic Claude"
            command_text = command_text.replace("claude", "").strip()
        elif command_text.startswith("gemini"):
            provider = "Google Gemini"
            command_text = command_text.replace("gemini", "").strip()

        # 3. Agent Matching based on User Keywords (Simple Orchestration)
        target_agent = None

        if "plan" in command_text or "structure" in command_text:
            target_agent = self._find_agent("architect")
        elif "ui" in command_text or "design" in command_text:
            target_agent = self._find_agent("arch_ux")
        elif "secure" in command_text or "check" in command_text:
            target_agent = self._find_agent("qa_evidence")
        elif "pm" in command_text or "manage" in command_text:
            target_agent = self._find_agent("pm_senior")

        # 4. Result Return (MVP: Generate and return final certified prompt)
        if target_agent:
            # 1. Status message generation
            status_msg = (f"[VibeSquad] Matching Agent Found: **{target_agent['role']}**\n"
                          f"Specialty: {target_agent['specialty']}\n"
                          f"AI Engine: {provider}\n"
                          f"Action: Forwarding request to {target_agent['id']}...")
            
            # 2. Certified prompt generation
            certified_prompt = self.craft_agent_prompt(target_agent['id'], provider=provider)
            
            # 3. Final combination
            return f"{status_msg}\n\n{certified_prompt}"
        
        return f"[VibeSquad] Command recognized but no specific agent assigned for: '{command_text}'."

    def _find_agent(self, agent_id):
        for agent in self.registry.get('agents', []):
            if agent['id'] == agent_id:
                return agent
        return None

    def craft_agent_prompt(self, agent_id, provider="default"):
        """
        Generates the final 'Commander Certified Prompt' to be delivered to the AI.
        """
        agent = next((a for a in self.registry['agents'] if a['id'] == agent_id), None)
        
        if not agent:
            return "You are a general assistant under vibesquad protocols."

        # Combine agent info + Master Blueprint
        final_prompt = f"""
### [SYSTEM COMMAND: AUTHORIZED BY VIBESQUAD]
**Your Role:** {agent['role']}
**Specialty:** {agent['specialty']}
**Assigned AI Engine:** {provider}

**Mandatory Engineering Standards (Master Blueprint):**
{self.blueprint}

**Current Task Directive:**
Execute the following request while strictly adhering to the standards above.
No redundant code. Secure by design. Minimalist UI. [cite: 2026-03-22]
--------------------------------------------------
"""
        return final_prompt
    
    # Example internal to vibesquad/commander.py
    def generate_final_report(self, project_name, start_time, stats):
        return (
        f"--- 📋 FINAL ORCHESTRATION REPORT: {project_name} ---\n"
        f"Start Time: {start_time}\n"
        f"Backend Stack: {stats.get('backend')}\n"
        f"Tasks Completed: {stats.get('tasks')}\n"
        f"Security Pass Rate: {stats.get('pass_rate')}\n"
        "--- Status: MISSION SUCCESSFUL ---"
    )
