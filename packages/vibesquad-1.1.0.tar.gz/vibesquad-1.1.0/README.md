# 🚀 VibeSquad (vibesquad)

**The Supreme Orchestrator for High-Performance 1-Person Development Loops.**

`VibeSquad` is a framework-agnostic orchestrator agent designed to manage multiple AI specialists (Agents) while enforcing strict minimalist standards, security, and modern UI/UX principles.

---

## ⚡ Quick Start (3-Minute Setup)

### 1. Installation

Install the package directly from your local source:

```bash
git clone https://github.com/your-username/vibesquad.git
cd vibesquad
pip install -e .
```

### 2. Basic Usage (Python)

You can integrate VibeSquad into any AI agent system or use it as a standalone prompt generator.

```python
from vibesquad import VibeSquad

# Initialize the VibeSquad
commander = VibeSquad()

# 1. Get the Master Blueprint (System Instructions)
# (Logic: commander.blueprint contains the content)
print("VibeSquad Master Blueprint Loaded Successfully!")
```

### 3. Command Interface

Run the built-in terminal interface to start orchestrating:

```bash
dotcom
```

---

## 🏛️ Core Standards (The Master Blueprint)

When VibeSquad orchestrates a project, it strictly enforces the following rules defined in the `blueprint.md`:

### 🎨 1. Modern UI/UX Standards

- **Minimalist Design**: Zero clutter, focus on core user intent.
- **Tailwind-First**: Direct, utility-first styling for speed and consistency.
- **Performance**: Optimized assets and fast load times.

### 🛡️ 2. Security & Engineering

- **Secure by Design**: Input validation, CSRF protection, and secure API handling as defaults.
- **PHP Laravel / Modern Stacks**: Leveraging robust frameworks for backend stability.
- **Scalable Architecture**: Clean code structure that grows with your project.

### ⚙️ 3. 1-Person Dev Optimization

- **Unified Vision**: Planning, Development, and QA are synchronized under one command.
- **Auto-Documentation**: Every phase generates standardized reports for future maintenance.

---

## 📂 Project Structure

- `vibesquad/`: Core logic and built-in Master Blueprint.
- `examples/`: Ready-to-use scripts for various frameworks.
- `tests/`: Reliability check suite.

---

## 📜 License

Distributed under the **MIT License**. See `LICENSE` for more information.

---

## 🤝 Contributing

Authorized by **KSC**. For contributions or bug reports, please open an issue in the repository.
