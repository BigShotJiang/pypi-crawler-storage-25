# tests/test_core.py
from dotcom_commander import DotComCommander

def test_blueprint_loading():
    commander = DotComCommander()
    assert "Master Blueprint" in commander.get_instructions()

def test_version():
    import dotcom_commander
    assert dotcom_commander.__version__ == "1.0.0"