"""Tool-loop state machine shared by Anthropic + OpenAI integrations.

Why this module exists
----------------------
A drop-in integration (``patch_anthropic`` / ``patch_openai``) only sees
the HTTP boundary — one span per ``messages.create`` /
``chat.completions.create`` call. On its own that gives N sibling root
traces per tool loop, no tool spans, and the live dashboard gives up
(because each trace immediately reports ``has_root_span=TRUE`` so the
backend flips ``is_live=false``).

This state machine stitches those calls into one trace that streams
live:

1. **Synthetic agent-run root.** On the first call we open an
   ``AGENT``-kind root span and keep it open. Every LLM span becomes
   its child. The root is only emitted *after* the terminal turn, so
   the backend's ``has_root_span=FALSE`` window stretches across the
   whole loop and ``is_live=true`` stays on.
2. **Tool-result stitching.** When a new call carries ``tool_result``
   blocks for a ``tool_use_id`` we recorded last turn, we emit a
   retroactive ``tool:<name>`` child span with the real duration
   (response-of-previous-turn → start-of-this-turn), and we push the
   prior LLM span into context so the new call lands under the same
   ``trace_id``.
3. **Process-exit safety.** An ``atexit`` hook closes any lingering
   agent-run so broken/abandoned loops still produce a complete trace.
   ``client.shutdown()`` reaches the same path through
   ``force_close_agent_run``, so explicit shutdowns emit the root
   before draining the transport.

Provider close policy
---------------------
``close_agent_run(terminal, error)`` is the shared per-call close
hook. Anthropic passes ``terminal=True`` on ``end_turn`` /
``stop_sequence`` / ``max_tokens`` so one tool loop == one trace --
this is the long-standing behaviour and it's what the dashboard's live
banner is tuned for. OpenAI passes ``terminal=False`` always and
relies on ``force_close_agent_run`` from ``atexit`` / shutdown to
close the root, so multiple independent ``.parse()`` / ``.create()``
calls in the same process stitch into one trace instead of producing
N single-span traces. Providers are free to pick whichever behaviour
matches their call pattern; the state machine supports both.

Provider-neutral contract
-------------------------
The state machine consumes **normalised** tool-use records:

    ToolUse = {"id": str, "name": str, "input": dict}

The Anthropic/OpenAI wrappers parse their native response shapes into
this form and back.
"""
from __future__ import annotations

import atexit
import logging
import random
import threading
import time
from collections import OrderedDict
from contextvars import ContextVar
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from ..client import get_client, get_tracer
from ..context import reset_current_span, set_current_span
from ..provider import Span, _hex_to_uuid, _safe_json
from ..types import SpanKind, SpanStatus

logger = logging.getLogger("staso")

# Cap pending-tool registry to avoid unbounded growth in long-lived
# processes. Normal tool loops pop entries as they consume them.
_MAX_ENTRIES = 2000


@dataclass
class _PendingTool:
    name: str
    tool_input: dict[str, Any]
    start_time: float
    parent_trace_id: str
    parent_span_id: str
    agent_name: str
    agent_id: str
    session_id: str
    user_id: str


_LOCK = threading.Lock()
_PENDING_TOOLS: "OrderedDict[str, _PendingTool]" = OrderedDict()

# One synthetic agent-run root per ContextVar context. Sync code in a
# single thread shares one context, so a typical agent gets exactly one.
_AGENT_RUN_SPAN: ContextVar[Span | None] = ContextVar(
    "_staso_agent_run_span", default=None
)
# Token for the matching ``set_current_span(agent_run)`` so we can
# cleanly restore the caller's prior parent when the run closes. Without
# this the ended (non-recording) agent_run would linger in context and
# force subsequent spans into the NOOP path.
_AGENT_RUN_TOKEN: ContextVar[Any] = ContextVar(
    "_staso_agent_run_token", default=None
)


# ── Ghost parent (used by tool-result stitching) ────────────────────


class _GhostParent:
    """Span-like stub — only carries ``trace_id`` / ``span_id`` so
    ``Tracer.start_span`` can attach a child. The real prior span has
    already ended and been GC'd by the time we need it."""

    __slots__ = ("trace_id", "span_id", "_recording")

    def __init__(self, trace_id: str, span_id: str) -> None:
        self.trace_id = trace_id
        self.span_id = span_id
        self._recording = True


# ── Synthetic agent-run root ────────────────────────────────────────


def ensure_agent_run(label: str) -> Span | None:
    """Open the synthetic agent-run root if one isn't active.

    Called at the start of the FIRST LLM call in a loop (i.e. when
    ``before_llm_call`` didn't find a continuation). Subsequent calls
    see the existing root and reuse it.

    Returns the active root span, or ``None`` when tracing is disabled
    (so the caller can short-circuit).
    """
    existing = _AGENT_RUN_SPAN.get(None)
    if existing is not None and getattr(existing, "_recording", False):
        return existing

    tracer = get_tracer()
    span = tracer.start_span(label, kind=SpanKind.AGENT)
    if not getattr(span, "_recording", True):
        return None

    _AGENT_RUN_SPAN.set(span)
    # Push into the span context so the imminent LLM span becomes a
    # child (inherits trace_id + sets parent_span_id). Keep the token
    # so close_agent_run() can cleanly restore the caller's prior
    # parent instead of leaving our ended root lingering.
    token = set_current_span(span)
    _AGENT_RUN_TOKEN.set(token)
    return span


def close_agent_run(*, terminal: bool, error: BaseException | None = None) -> None:
    """Close the synthetic agent-run root if one is active.

    Emits the root span (which the backend reads as the trace's
    completion signal). Called when the LLM signals a terminal
    ``stop_reason`` / ``finish_reason`` or when the call errors.

    ``terminal=False, error=None`` is a no-op — keeps the root open for
    the next turn. OpenAI wrappers rely on this to chain multiple
    independent ``.parse()`` / ``.create()`` calls into one trace per
    process: they always pass ``terminal=False`` and let
    ``force_close_agent_run`` (via atexit / shutdown) emit the root.
    """
    if not terminal and error is None:
        return
    _end_and_reset(error=error)


def force_close_agent_run() -> None:
    """Close any lingering agent-run unconditionally.

    Call from ``client.shutdown()`` (before transport drain) or user
    code that wants to explicitly end the current trace — e.g. between
    discrete workflow phases that should appear as separate traces.
    After this returns the next LLM call opens a fresh agent-run.
    Idempotent: second call is a no-op when there's no active run.
    """
    _end_and_reset(error=None)


def _end_and_reset(*, error: BaseException | None) -> None:
    span = _AGENT_RUN_SPAN.get(None)
    if span is None:
        return
    try:
        if error is not None:
            span.record_exception(error)
        span.end()
    finally:
        token = _AGENT_RUN_TOKEN.get(None)
        if token is not None:
            try:
                reset_current_span(token)
            except Exception:
                logger.debug(
                    "staso: agent-run context reset failed", exc_info=True
                )
            _AGENT_RUN_TOKEN.set(None)
        _AGENT_RUN_SPAN.set(None)


def _force_close_on_exit() -> None:
    """atexit hook — close any lingering agent-run so trace liveness
    doesn't hang indefinitely on unclean shutdowns."""
    try:
        force_close_agent_run()
    except Exception:
        logger.debug("staso: atexit agent-run close failed", exc_info=True)


atexit.register(_force_close_on_exit)


# ── Retroactive tool-span emission ──────────────────────────────────


def _emit_retroactive_tool_span(
    pending: _PendingTool,
    tool_use_id: str,
    end_time: float,
    output_content: Any,
) -> None:
    """Enqueue a completed ``tool:<name>`` span directly onto the
    transport. Start time is in the past (the prior response
    timestamp), so we build the dict by hand rather than going through
    the normal Span lifecycle."""
    client = get_client()
    if not client or not getattr(client, "_transport", None):
        return

    span_id = _hex_to_uuid(format(random.getrandbits(64), "016x"))
    duration_ms = max(0.0, (end_time - pending.start_time) * 1000)
    ts = datetime.fromtimestamp(pending.start_time, tz=timezone.utc).isoformat()

    input_payload = {
        "tool_name": pending.name,
        "tool_input": pending.tool_input,
        "tool_use_id": tool_use_id,
    }
    output_payload: dict[str, Any] = {}
    if output_content is not None:
        output_payload["content"] = output_content

    span_dict: dict[str, Any] = {
        "trace_id": pending.parent_trace_id,
        "span_id": span_id,
        "parent_span_id": pending.parent_span_id,
        "name": f"tool:{pending.name}",
        "kind": SpanKind.TOOL.value,
        "timestamp": ts,
        "duration_ms": round(duration_ms, 2),
        "status": SpanStatus.OK.value,
        "model": "",
        "input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "input": _safe_json(input_payload),
        "output": _safe_json(output_payload) if output_payload else "",
        "attributes": _safe_json({"tool_name": pending.name, "auto_captured": True}),
        "error_message": None,
        "session_id": pending.session_id,
        "agent_name": pending.agent_name,
        "agent_id": pending.agent_id,
        "user_id": pending.user_id,
    }
    client._transport.enqueue(span_dict)


# ── Public state machine API ────────────────────────────────────────


def before_llm_call(tool_results: list[tuple[str, Any]] | None) -> Any:
    """Run before the outbound LLM HTTP request.

    ``tool_results`` is a normalised list of ``(tool_use_id, content)``
    pairs extracted from the call's ``messages[-1]`` by the provider
    wrapper (empty/None if this isn't a continuation).

    For each id we recognise:
      * emit a retroactive ``tool:<name>`` span (real duration)
      * remember the first matching parent ``(trace_id, span_id)`` so
        the imminent LLM span can be stitched under it

    Returns a context token (pass to ``after_llm_call``) when we pushed
    a ghost parent; ``None`` otherwise.
    """
    if not tool_results:
        return None

    now = time.time()
    parent_trace_id: str | None = None
    parent_span_id: str | None = None

    with _LOCK:
        for tool_use_id, result_content in tool_results:
            pending = _PENDING_TOOLS.pop(tool_use_id, None)
            if pending is None:
                continue
            if parent_trace_id is None:
                parent_trace_id = pending.parent_trace_id
                parent_span_id = pending.parent_span_id
            try:
                _emit_retroactive_tool_span(
                    pending, tool_use_id, now, result_content
                )
            except Exception:
                logger.debug(
                    "staso: retroactive tool-span emission failed", exc_info=True
                )

    if parent_trace_id is None or parent_span_id is None:
        return None

    # If there's already an active agent_run, we don't need the ghost —
    # the LLM span will naturally parent under it (same trace_id). But
    # we DO want the LLM span to parent specifically under the prior
    # LLM (so the tree reads: agent_run → LLM1 → tools+LLM2 → …), not
    # directly under agent_run. So we push the ghost regardless.
    ghost = _GhostParent(parent_trace_id, parent_span_id)
    return set_current_span(ghost)


def after_llm_call(ghost_token: Any) -> None:
    """Reset the ghost-parent context pushed by ``before_llm_call``."""
    if ghost_token is None:
        return
    try:
        reset_current_span(ghost_token)
    except Exception:
        logger.debug("staso: ghost-parent reset failed", exc_info=True)


def record_tool_uses(span: Any, tool_uses: list[dict[str, Any]]) -> None:
    """Register every tool invocation from a response so the next call
    can stitch under this span + retro-emit ``tool:<name>`` children.

    ``tool_uses`` is a list of ``{"id", "name", "input"}`` dicts,
    parsed out of the provider's response shape by the caller.
    """
    if not tool_uses:
        return

    trace_id = getattr(span, "trace_id", "") or ""
    parent_span_id = getattr(span, "span_id", "") or ""
    if not trace_id or not parent_span_id:
        return

    agent_name = getattr(span, "agent_name", "") or ""
    agent_id = getattr(span, "agent_id", "") or ""
    session_id = getattr(span, "session_id", "") or ""
    user_id = getattr(span, "user_id", "") or ""

    now = time.time()
    to_register: list[tuple[str, _PendingTool]] = []
    for tu in tool_uses:
        if not isinstance(tu, dict):
            continue
        tool_use_id = tu.get("id")
        if not tool_use_id:
            continue
        name = tu.get("name") or "unknown"
        raw_input = tu.get("input")
        if isinstance(raw_input, dict):
            tool_input: dict[str, Any] = dict(raw_input)
        elif raw_input is None:
            tool_input = {}
        else:
            tool_input = {"value": raw_input}
        to_register.append(
            (
                tool_use_id,
                _PendingTool(
                    name=name,
                    tool_input=tool_input,
                    start_time=now,
                    parent_trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    agent_name=agent_name,
                    agent_id=agent_id,
                    session_id=session_id,
                    user_id=user_id,
                ),
            )
        )

    if not to_register:
        return

    with _LOCK:
        for tool_use_id, pending in to_register:
            _PENDING_TOOLS[tool_use_id] = pending
            _PENDING_TOOLS.move_to_end(tool_use_id)
        while len(_PENDING_TOOLS) > _MAX_ENTRIES:
            _PENDING_TOOLS.popitem(last=False)


def _reset_for_tests() -> None:
    """Wipe state between test cases. Not part of the public API."""
    with _LOCK:
        _PENDING_TOOLS.clear()
    _AGENT_RUN_SPAN.set(None)
    _AGENT_RUN_TOKEN.set(None)
