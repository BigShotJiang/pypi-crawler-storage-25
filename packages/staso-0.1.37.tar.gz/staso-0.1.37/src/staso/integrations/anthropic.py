"""Zero-code-change instrumentation for the Anthropic Python SDK."""
from __future__ import annotations

import functools
import json
import logging
import time
from typing import Any

from ..client import get_client, get_tracer
from ..context import reset_current_span, set_current_span
from ..guard import GuardBlocked
from ..types import (
    ANTHROPIC_KEY_CONTENT,
    ANTHROPIC_KEY_MESSAGES,
    ANTHROPIC_KEY_MODEL,
    ANTHROPIC_KEY_SYSTEM,
    ANTHROPIC_KEY_TOOLS,
    META_CACHE_CREATION_TOKENS,
    META_CACHE_READ_TOKENS,
    META_MAX_TOKENS,
    META_PROVIDER,
    META_RESPONSE_ID,
    META_STOP_REASON,
    META_STOP_SEQUENCES,
    META_TEMPERATURE,
    META_THINKING,
    META_TIME_TO_FIRST_TOKEN,
    META_TOOL_CHOICE,
    META_TOP_K,
    META_TOP_P,
    SpanKind,
    SpanStatus,
)
from ._guard_common import evaluate_and_enforce
from ._streaming import (
    AsyncMessageStreamManagerProxy,
    AsyncStreamProxy,
    MessageStreamManagerProxy,
    StreamProxy,
)
from ._tool_loop_state import (
    after_llm_call as _tool_loop_after,
    before_llm_call as _tool_loop_before,
    close_agent_run as _tool_loop_close_run,
    ensure_agent_run as _tool_loop_open_run,
    record_tool_uses as _tool_loop_record,
)

logger = logging.getLogger("staso")

# See openai.py for the idempotency story. Same marker, same rationale.
_STASO_PATCH_MARKER = "_staso_patched"
_patched = False


def _build_tool_use_refs(
    live_content: Any,
    content_dicts: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Zip live Anthropic content blocks with their serialised dict copies so
    the shared guard helper can read names/inputs from the dicts and mutate
    the live objects on ``modify``."""
    live_blocks = list(live_content) if live_content else []
    refs: list[dict[str, Any]] = []
    for idx, block in enumerate(content_dicts):
        if not isinstance(block, dict) or block.get("type") != "tool_use":
            continue
        name = block.get("name", "unknown")
        inp = block.get("input") or {}
        if not isinstance(inp, dict):
            inp = {"value": inp}
        ref = None
        if idx < len(live_blocks):
            live = live_blocks[idx]
            if getattr(live, "type", None) == "tool_use":
                ref = live
        refs.append({"name": name, "input": inp, "ref": ref})
    return refs


def _apply_anthropic_modify(ref: Any, modified_input: dict[str, Any]) -> None:
    """Rewrite the live Anthropic ``ToolUseBlock.input`` in place so the
    caller's agent loop dispatches the modified arguments."""
    if ref is None:
        return
    try:
        ref.input = modified_input
    except Exception:
        logger.debug("staso: anthropic tool_use mutation failed", exc_info=True)


def _safe_json(obj: Any) -> str:
    try:
        return json.dumps(obj, default=str)
    except (TypeError, ValueError, OverflowError):
        return "{}"


def _dump_content(content: Any) -> list[dict]:
    """Extract content blocks from an Anthropic response as serializable dicts."""
    if not content:
        return []
    result = []
    for block in content:
        if hasattr(block, "model_dump"):
            result.append(block.model_dump())
        elif isinstance(block, dict):
            result.append(block)
        else:
            result.append({"type": "unknown", "value": str(block)})
    return result


def patch_anthropic() -> None:
    """Monkey-patch ``anthropic.resources.Messages.create`` (sync and async)
    to automatically emit LLM spans with comprehensive data capture.

    Safe to call multiple times -- only patches once.
    """
    global _patched
    if _patched:
        return

    try:
        from anthropic.resources import AsyncMessages, Messages
    except ImportError:
        raise ImportError(
            "anthropic package is required for this integration. "
            "Install it with: pip install 'staso[anthropic]'"
        )

    _wrap_sync(Messages)
    _wrap_async(AsyncMessages)
    _wrap_stream_sync(Messages)
    _wrap_stream_async(AsyncMessages)
    _patched = True
    logger.debug("staso: anthropic SDK patched")


def _extract_model(args: tuple, kwargs: dict) -> str:
    return str(kwargs.get("model", args[0] if args else ""))


_ROOT_LABEL_MAX = 60
_TOOL_LIST_MAX = 3

# Stop reasons that END the tool loop (and therefore close the
# synthetic agent-run root). ``tool_use`` means "model wants more
# tools" — loop continues.
_TERMINAL_STOP_REASONS = frozenset(
    {"end_turn", "stop_sequence", "max_tokens"}
)


def _extract_anthropic_tool_uses(content_dicts: list[dict]) -> list[dict]:
    """Pull ``tool_use`` blocks out of an Anthropic response into the
    normalised ``{"id","name","input"}`` form the state machine wants."""
    out: list[dict] = []
    for b in content_dicts:
        if not isinstance(b, dict) or b.get("type") != "tool_use":
            continue
        out.append(
            {
                "id": b.get("id"),
                "name": b.get("name") or "unknown",
                "input": b.get("input") or {},
            }
        )
    return out


def _extract_anthropic_tool_results(messages: Any) -> list[tuple[str, Any]]:
    """Pull ``tool_result`` blocks from the LAST user message into
    ``(tool_use_id, content)`` pairs. Anthropic's continuation signal
    is a user message whose ``content`` is a list containing at least
    one ``{"type":"tool_result"}`` block."""
    if not isinstance(messages, list) or not messages:
        return []
    last = messages[-1]
    if not isinstance(last, dict) or last.get("role") != "user":
        return []
    content = last.get("content")
    if not isinstance(content, list):
        return []
    out: list[tuple[str, Any]] = []
    for b in content:
        if not isinstance(b, dict) or b.get("type") != "tool_result":
            continue
        tuid = b.get("tool_use_id")
        if tuid:
            out.append((tuid, b.get("content")))
    return out


def _first_user_text(messages: Any) -> str:
    """Return the first user message's text content. Handles string and
    block-list forms. Returns empty string if there is no readable text."""
    if not isinstance(messages, list):
        return ""
    for m in messages:
        if not isinstance(m, dict) or m.get("role") != "user":
            continue
        content = m.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            for b in content:
                if isinstance(b, dict) and b.get("type") == "text":
                    t = b.get("text")
                    if isinstance(t, str) and t.strip():
                        return t
        return ""
    return ""


def _derive_root_label(messages: Any, model: str) -> str:
    """Label for the first LLM call in a loop (or a single-shot call).

    Prefers the first markdown heading in the user's prompt, else the
    first non-empty line, trimmed to a reasonable length. Falls back to
    ``chat: <model>`` if nothing useful is available.
    """
    text = _first_user_text(messages).strip()
    if not text:
        return f"chat: {model}" if model else "anthropic.messages.create"

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith("#"):
            label = stripped.lstrip("#").strip()
            if label:
                return label[:_ROOT_LABEL_MAX]
        # No heading yet — first non-empty line wins
        return stripped[:_ROOT_LABEL_MAX]

    return f"chat: {model}" if model else "anthropic.messages.create"


def _derive_child_label(response: Any) -> str:
    """Label for a continuation LLM call: reflects what the response
    asked for (more tools) or whether it closed out (reply)."""
    stop_reason = getattr(response, "stop_reason", "") or ""
    content = getattr(response, "content", None) or []
    tool_names: list[str] = []
    for b in content:
        if getattr(b, "type", None) == "tool_use":
            name = getattr(b, "name", None) or "?"
            tool_names.append(str(name))

    if stop_reason == "tool_use" and tool_names:
        shown = tool_names[:_TOOL_LIST_MAX]
        extra = len(tool_names) - len(shown)
        suffix = f", …+{extra}" if extra > 0 else ""
        return f"chat:tool_use({', '.join(shown)}{suffix})"
    if stop_reason in ("end_turn", "stop_sequence", "max_tokens"):
        return "chat:reply"
    if stop_reason:
        return f"chat:{stop_reason}"
    return "chat"


def _capture_input(model: str, kwargs: dict) -> dict:
    """Build the span input dict from request kwargs."""
    inp: dict[str, Any] = {
        ANTHROPIC_KEY_MODEL: model,
    }

    # System prompt (full, not truncated)
    system = kwargs.get("system")
    if system is not None:
        inp[ANTHROPIC_KEY_SYSTEM] = system

    # Tool definitions
    tools = kwargs.get("tools")
    if tools:
        inp[ANTHROPIC_KEY_TOOLS] = tools

    # Conditionally include messages
    client = get_client()
    if client and client.config.capture_messages:
        messages = kwargs.get("messages")
        if messages:
            inp[ANTHROPIC_KEY_MESSAGES] = messages

    return inp


def _capture_metadata(kwargs: dict) -> dict[str, Any]:
    """Extract request parameters into metadata dict."""
    meta: dict[str, Any] = {META_PROVIDER: "anthropic"}

    _optional_keys = [
        ("temperature", META_TEMPERATURE),
        ("max_tokens", META_MAX_TOKENS),
        ("top_p", META_TOP_P),
        ("top_k", META_TOP_K),
        ("stop_sequences", META_STOP_SEQUENCES),
        ("tool_choice", META_TOOL_CHOICE),
        ("thinking", META_THINKING),
    ]
    for kwarg_key, meta_key in _optional_keys:
        val = kwargs.get(kwarg_key)
        if val is not None:
            meta[meta_key] = val

    return meta


def _capture_response(span: Any, response: Any) -> None:
    """Extract response data onto span fields.

    Tool name extraction: tool names appear as ToolUseBlock.name within
    response.content blocks. They are captured via _dump_content() which
    serializes all content blocks (text, tool_use, thinking, etc.) into
    the span output dict under ANTHROPIC_KEY_CONTENT.
    """
    # Output: full content blocks
    content = getattr(response, "content", None)
    content_dicts = _dump_content(content)
    span.output = {ANTHROPIC_KEY_CONTENT: content_dicts}

    # Tool-loop state machine: record tool_use ids so the next
    # messages.create can (a) stitch itself under this span's trace_id
    # and (b) retroactively emit tool:<name> child spans.
    _tool_loop_record(span, _extract_anthropic_tool_uses(content_dicts))

    # Response metadata
    stop_reason = getattr(response, "stop_reason", None)
    if stop_reason:
        span.metadata[META_STOP_REASON] = stop_reason

    response_id = getattr(response, "id", None)
    if response_id:
        span.metadata[META_RESPONSE_ID] = response_id

    # Token usage
    usage = getattr(response, "usage", None)
    if usage:
        span.input_tokens = getattr(usage, "input_tokens", 0) or 0
        span.output_tokens = getattr(usage, "output_tokens", 0) or 0
        span.total_tokens = span.input_tokens + span.output_tokens

        # Cache token breakdown
        cache_read = getattr(usage, "cache_read_input_tokens", None)
        if cache_read:
            span.metadata[META_CACHE_READ_TOKENS] = cache_read

        cache_creation = getattr(usage, "cache_creation_input_tokens", None)
        if cache_creation:
            span.metadata[META_CACHE_CREATION_TOKENS] = cache_creation

    # Thinking detection
    if content:
        has_thinking = any(getattr(b, "type", None) == "thinking" for b in content)
        if has_thinking:
            span.metadata["has_thinking"] = True

    # Guard enforcement — raises GuardBlocked on enforce-mode blocks. Must
    # propagate so the caller's tool dispatch loop never sees a blocked
    # response.
    refs = _build_tool_use_refs(content, content_dicts)
    if refs:
        evaluate_and_enforce(refs, span, apply_modify=_apply_anthropic_modify)


def _wrap_sync(cls: type) -> None:
    original = cls.create
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        if kwargs.get("stream"):
            # Streaming: manual span lifecycle
            span = tracer.start_span("anthropic.messages.create", kind=SpanKind.LLM)
            span.model = model
            span.input = _capture_input(model, kwargs)
            span.metadata.update(_capture_metadata(kwargs))
            token = set_current_span(span)
            start_time = time.time()
            try:
                stream = original(self, *args, **kwargs)
                return StreamProxy(stream, span, start_time, token)
            except Exception as exc:
                span.record_exception(exc)
                span.end()
                reset_current_span(token)
                raise
        else:
            messages = kwargs.get("messages")
            tool_results = _extract_anthropic_tool_results(messages)
            ghost_token = _tool_loop_before(tool_results)
            # First call in a loop (no continuation): open the
            # synthetic agent-run root so the trace streams LIVE (the
            # backend treats "no root span yet" as is_live=true).
            if ghost_token is None:
                _tool_loop_open_run(_derive_root_label(messages, model))
            # LLM span starts with a structural placeholder name; the
            # final name is set from the response below.
            span_name = "chat"
            terminal = False
            errored: BaseException | None = None
            try:
                with tracer.start_as_current_span(
                    span_name, kind=SpanKind.LLM
                ) as span:
                    span.model = model
                    span.input = _capture_input(model, kwargs)
                    span.metadata.update(_capture_metadata(kwargs))
                    try:
                        response = original(self, *args, **kwargs)
                        _capture_response(span, response)
                        span.name = _derive_child_label(response)
                        stop_reason = (
                            getattr(response, "stop_reason", "") or ""
                        )
                        terminal = stop_reason in _TERMINAL_STOP_REASONS
                        span.status = SpanStatus.OK
                        return response
                    except BaseException as exc:
                        errored = exc
                        span.record_exception(exc)
                        raise
            finally:
                _tool_loop_after(ghost_token)
                # Close the synthetic agent-run root when the model
                # signals end_turn (or on any error). That emits the
                # root and flips the trace to "complete" in the UI.
                _tool_loop_close_run(terminal=terminal, error=errored)

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.create = _traced  # type: ignore[assignment]


def _wrap_async(cls: type) -> None:
    original = cls.create
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    async def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        if kwargs.get("stream"):
            span = tracer.start_span("anthropic.messages.create", kind=SpanKind.LLM)
            span.model = model
            span.input = _capture_input(model, kwargs)
            span.metadata.update(_capture_metadata(kwargs))
            token = set_current_span(span)
            start_time = time.time()
            try:
                stream = await original(self, *args, **kwargs)
                return AsyncStreamProxy(stream, span, start_time, token)
            except Exception as exc:
                span.record_exception(exc)
                span.end()
                reset_current_span(token)
                raise
        else:
            messages = kwargs.get("messages")
            tool_results = _extract_anthropic_tool_results(messages)
            ghost_token = _tool_loop_before(tool_results)
            if ghost_token is None:
                _tool_loop_open_run(_derive_root_label(messages, model))
            span_name = "chat"
            terminal = False
            errored: BaseException | None = None
            try:
                with tracer.start_as_current_span(
                    span_name, kind=SpanKind.LLM
                ) as span:
                    span.model = model
                    span.input = _capture_input(model, kwargs)
                    span.metadata.update(_capture_metadata(kwargs))
                    try:
                        response = await original(self, *args, **kwargs)
                        _capture_response(span, response)
                        span.name = _derive_child_label(response)
                        stop_reason = (
                            getattr(response, "stop_reason", "") or ""
                        )
                        terminal = stop_reason in _TERMINAL_STOP_REASONS
                        span.status = SpanStatus.OK
                        return response
                    except BaseException as exc:
                        errored = exc
                        span.record_exception(exc)
                        raise
            finally:
                _tool_loop_after(ghost_token)
                _tool_loop_close_run(terminal=terminal, error=errored)

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.create = _traced  # type: ignore[assignment]


def _wrap_stream_sync(cls: type) -> None:
    """Patch Messages.stream to wrap with MessageStreamManagerProxy."""
    if not hasattr(cls, "stream"):
        return
    original = cls.stream
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        span = tracer.start_span("anthropic.messages.stream", kind=SpanKind.LLM)
        span.model = model
        span.input = _capture_input(model, kwargs)
        span.metadata.update(_capture_metadata(kwargs))
        token = set_current_span(span)
        start_time = time.time()

        try:
            manager = original(self, *args, **kwargs)
            return MessageStreamManagerProxy(manager, span, start_time, token)
        except Exception as exc:
            span.record_exception(exc)
            span.end()
            reset_current_span(token)
            raise

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.stream = _traced  # type: ignore[assignment]


def _wrap_stream_async(cls: type) -> None:
    """Patch AsyncMessages.stream."""
    if not hasattr(cls, "stream"):
        return
    original = cls.stream
    if getattr(original, _STASO_PATCH_MARKER, False):
        return

    @functools.wraps(original)
    def _traced(self: Any, *args: Any, **kwargs: Any) -> Any:
        tracer = get_tracer()
        model = _extract_model(args, kwargs)

        span = tracer.start_span("anthropic.messages.stream", kind=SpanKind.LLM)
        span.model = model
        span.input = _capture_input(model, kwargs)
        span.metadata.update(_capture_metadata(kwargs))
        token = set_current_span(span)
        start_time = time.time()

        try:
            manager = original(self, *args, **kwargs)
            return AsyncMessageStreamManagerProxy(manager, span, start_time, token)
        except Exception as exc:
            span.record_exception(exc)
            span.end()
            reset_current_span(token)
            raise

    setattr(_traced, _STASO_PATCH_MARKER, True)
    _traced._staso_original = original  # type: ignore[attr-defined]
    cls.stream = _traced  # type: ignore[assignment]
