---
name: maya-geometry
description: "Maya geometry creation and modification tools — create spheres, cubes, cylinders; bevel, extrude, and merge polygon components. Use when working with 3D geometry in Maya scenes."
license: MIT
compatibility: Maya 2022+, Python 3.7+
allowed-tools: Bash Read Write
metadata:
  category: modeling
  dcc_vendor: Autodesk
tags: [maya, geometry, creation, modeling]
dcc: maya
version: "1.0.0"
tools:
  - name: create_sphere
    description: Create a polygon sphere with the given radius and subdivisions
    input_schema:
      type: object
      properties:
        radius:
          type: number
          description: Sphere radius in Maya units
          default: 1.0
        subdivisionsX:
          type: integer
          description: Subdivisions around the equator
          default: 20
        subdivisionsY:
          type: integer
          description: Subdivisions from pole to pole
          default: 20
    read_only: false
    destructive: false
    idempotent: false
    source_file: scripts/create_sphere.py

  - name: bevel_edges
    description: Apply bevel to selected polygon edges
    input_schema:
      type: object
      properties:
        offset:
          type: number
          description: Bevel offset distance
          default: 0.1
        segments:
          type: integer
          description: Number of bevel segments
          default: 1
    read_only: false
    destructive: false
    idempotent: false
    source_file: scripts/bevel_edges.py
---

# Maya Geometry Tools

Tools for creating and modifying 3D geometry inside Maya.

## Tools

### `maya_geometry__create_sphere`
Create a UV sphere with configurable radius and subdivisions.

### `maya_geometry__bevel_edges`
Apply a bevel operation to currently selected polygon edges.

## Prerequisites

- Autodesk Maya 2022 or later
- Python interpreter accessible from Maya's script editor

## Notes

All scripts use Maya's Python API (`import maya.cmds as mc`). They must be
run inside a Maya process — either directly or via the DeferredExecutor bridge.
