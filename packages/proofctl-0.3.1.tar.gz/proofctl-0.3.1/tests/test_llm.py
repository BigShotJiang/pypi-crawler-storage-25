"""Tests for PROOFCTL-LLM-* — LLM integration guardrails."""
from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.llm_integration import LLMChecker
from proofctl.models import Severity

_P = Path("ai_feature.py")
_checker = LLMChecker()


def _check(src: str):
    tree = ast.parse(src)
    return _checker.check(_P, src, tree)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# LLM-001 — Prompt injection
# ══════════════════════════════════════════════════════════════════════════════


def test_llm001_fstring_in_user_content():
    src = """
response = client.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "system", "content": "You are helpful."},
        {"role": "user", "content": f"Answer this: {user_input}"},
    ],
)
"""
    f = _find(_check(src), "PROOFCTL-LLM-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_llm001_concat_in_content():
    src = """
response = client.chat.completions.create(
    model="claude-3-5-sonnet-20241022",
    messages=[{"role": "user", "content": "Process: " + user_data}],
)
"""
    f = _find(_check(src), "PROOFCTL-LLM-001")
    assert len(f) == 1


def test_llm001_static_content_clean():
    src = """
response = client.chat.completions.create(
    model="gpt-4",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "What is the capital of France?"},
    ],
    max_tokens=100,
)
"""
    assert "PROOFCTL-LLM-001" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# LLM-002 — Missing max_tokens
# ══════════════════════════════════════════════════════════════════════════════


def test_llm002_openai_no_max_tokens():
    src = """
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Tell me about Python."}],
)
"""
    f = _find(_check(src), "PROOFCTL-LLM-002")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_llm002_anthropic_no_max_tokens():
    src = """
response = client.messages.create(
    model="claude-3-5-sonnet-20241022",
    messages=[{"role": "user", "content": "Hello"}],
)
"""
    f = _find(_check(src), "PROOFCTL-LLM-002")
    assert len(f) == 1


def test_llm002_litellm_no_max_tokens():
    src = """
import litellm
response = litellm.completion(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hi"}],
)
"""
    f = _find(_check(src), "PROOFCTL-LLM-002")
    assert len(f) == 1


def test_llm002_with_max_tokens_clean():
    src = """
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello"}],
    max_tokens=500,
)
"""
    assert "PROOFCTL-LLM-002" not in _ids(_check(src))


def test_llm002_max_completion_tokens_clean():
    src = """
response = client.chat.completions.create(
    model="gpt-4o",
    messages=[{"role": "user", "content": "Hello"}],
    max_completion_tokens=1024,
)
"""
    assert "PROOFCTL-LLM-002" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# LLM-003 — LLM call inside loop
# ══════════════════════════════════════════════════════════════════════════════


def test_llm003_call_in_for_loop():
    src = """
for item in items:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": item}],
        max_tokens=100,
    )
"""
    f = _find(_check(src), "PROOFCTL-LLM-003")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_llm003_call_in_while_loop():
    src = """
while pending:
    r = client.chat.completions.create(
        model="gpt-4",
        messages=msgs,
        max_tokens=200,
    )
    pending = pending[1:]
"""
    f = _find(_check(src), "PROOFCTL-LLM-003")
    assert len(f) == 1


def test_llm003_call_outside_loop_clean():
    src = """
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello"}],
    max_tokens=100,
)
"""
    assert "PROOFCTL-LLM-003" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# LLM-004 — PII variable in LLM prompt
# ══════════════════════════════════════════════════════════════════════════════


def test_llm004_email_in_prompt():
    src = """
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": f"Process this user: {email}"}],
    max_tokens=100,
)
"""
    f = _find(_check(src), "PROOFCTL-LLM-004")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "email" in f[0].message


def test_llm004_ssn_in_prompt():
    src = """
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": f"Verify SSN: {ssn}"}],
    max_tokens=100,
)
"""
    f = _find(_check(src), "PROOFCTL-LLM-004")
    assert len(f) == 1


def test_llm004_non_pii_variable_clean():
    src = """
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": f"Summarise: {document_text}"}],
    max_tokens=500,
)
"""
    assert "PROOFCTL-LLM-004" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# LLM-005 — Unbounded agentic loop
# ══════════════════════════════════════════════════════════════════════════════


def test_llm005_while_true_with_llm_no_guard():
    src = """
while True:
    thought = client.chat.completions.create(
        model="gpt-4",
        messages=history,
        max_tokens=500,
    )
    history.append(thought)
"""
    f = _find(_check(src), "PROOFCTL-LLM-005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_llm005_while_true_with_iter_guard_clean():
    src = """
step = 0
while True:
    thought = client.chat.completions.create(
        model="gpt-4",
        messages=history,
        max_tokens=500,
    )
    history.append(thought)
    step += 1
    if step >= 10:
        break
"""
    assert "PROOFCTL-LLM-005" not in _ids(_check(src))


def test_llm005_bounded_for_loop_clean():
    """for-loop with range is already bounded — should not fire."""
    src = """
for step in range(10):
    thought = client.chat.completions.create(
        model="gpt-4",
        messages=history,
        max_tokens=500,
    )
"""
    assert "PROOFCTL-LLM-005" not in _ids(_check(src))


def test_llm005_while_true_without_llm_not_flagged():
    """while True: without an LLM call should not fire LLM-005."""
    src = """
while True:
    data = queue.get()
    process(data)
    if done:
        break
"""
    assert "PROOFCTL-LLM-005" not in _ids(_check(src))
