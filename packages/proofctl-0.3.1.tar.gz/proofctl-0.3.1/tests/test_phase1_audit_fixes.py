"""Regression tests for AUDIT_AND_ROADMAP Phase 0 + Phase 1 fixes.

Each test corresponds to a finding in AUDIT_AND_ROADMAP.md:
  C-1: --no-pypi must disable PyPI lookups
  C-2: rule registry must catalogue every rule emitted by checkers
  C-4: __version__ must be importable and non-empty
  C-6: --output with terminal format must write a non-empty file
  C-7: single-file scan must return findings for that file
"""
from __future__ import annotations

import re
from pathlib import Path

import pytest

from proofctl import __version__
from proofctl.config import ProofctlConfig
from proofctl.engine import run_check
from proofctl.registry import RULES, family_tokens, families_help_string
from proofctl.reporters.terminal import TerminalReporter
from proofctl.models import Finding, Severity


# ── C-4: single-source version ────────────────────────────────────────────────

def test_c4_version_importable_and_nonempty():
    assert isinstance(__version__, str)
    assert __version__
    # Either a real semver from importlib.metadata or our dev fallback.
    assert re.match(r"^\d+\.\d+\.\d+", __version__) or __version__.startswith("0.0.0+dev")


# ── C-1: --no-pypi must short-circuit PyPI calls ──────────────────────────────

def test_c1_no_pypi_disables_pypi_lookups(tmp_path, monkeypatch):
    """When config.check_pypi=False, urllib.request.urlopen must never be called.

    Mocks urlopen to raise; if the checker reaches it, the test fails.
    """
    # File with an obvious "not on PyPI" import that would otherwise trigger
    # a live PyPI lookup.
    (tmp_path / "code.py").write_text("import this_pkg_does_not_exist_anywhere_xyz\n")

    import urllib.request as _urlreq

    def _explode(*args, **kwargs):
        raise AssertionError("urlopen called despite check_pypi=False")

    monkeypatch.setattr(_urlreq, "urlopen", _explode)

    cfg = ProofctlConfig()
    cfg.check_pypi = False

    findings = run_check(tmp_path, cfg, families=["I"])
    # No assertion needed on the findings themselves — the assertion lives in
    # the monkey-patched urlopen. Reaching this line means it wasn't called.
    assert isinstance(findings, list)


# ── C-2: registry must catalogue every emitted rule_id ────────────────────────

def test_c2_registry_covers_every_rule_id_in_source():
    """Walk every proofctl source file for PROOFCTL-XXX references; each must
    appear in RULES. This includes engine.py, which emits PROOFCTL-INTERNAL-001."""
    pkg_dir = Path(__file__).parent.parent / "proofctl"
    pat = re.compile(r"PROOFCTL-[A-Z]+(?:-[A-Z]+)?-[A-Z]?\d+")
    used: set[str] = set()
    for src in list((pkg_dir / "checkers").rglob("*.py")) + [pkg_dir / "engine.py"]:
        used.update(pat.findall(src.read_text(encoding="utf-8")))

    missing = used - set(RULES)
    assert not missing, f"Rules referenced in source but missing from registry: {sorted(missing)}"


def test_c2_registry_has_every_family():
    """Every family token referenced in source must have a label."""
    from proofctl.registry import FAMILY_LABELS
    for tok in family_tokens():
        assert tok in FAMILY_LABELS, f"Family token {tok!r} has no human-readable label"


def test_c3_families_help_includes_every_family():
    help_str = families_help_string()
    for tok in family_tokens():
        assert f"{tok} " in help_str or f"{tok}," in help_str, (
            f"Family token {tok!r} missing from --families help text"
        )


def test_c2_severity_overrides_match_real_rules():
    """Every entry in _DYNAMIC_SEVERITY_OVERRIDES must point at a rule that exists."""
    from proofctl.registry import _DYNAMIC_SEVERITY_OVERRIDES
    for rule_id in _DYNAMIC_SEVERITY_OVERRIDES:
        assert rule_id in RULES, f"Override targets nonexistent rule {rule_id}"


# ── C-6: --output with terminal format produces a non-empty file ──────────────

def test_c6_terminal_reporter_renders_to_string_when_output_set(tmp_path):
    findings = [Finding(
        file="auth.py", line=1, col=0,
        rule_id="PROOFCTL-Q-001", rule_name="Mutable default",
        severity=Severity.ERROR,
        message="shared list", hint="use None",
        authority="Python Gotchas", docs_url="",
    )]
    out_file = tmp_path / "report.txt"
    reporter = TerminalReporter()
    content = reporter.render(findings, output=out_file)
    assert content, "render() with output= must return non-empty captured text"
    # Rich output contains box-drawing chars (│ ─), the 📖 emoji, and ✓ —
    # Path.write_text defaults to the platform locale (cp1252 on Windows
    # CI), which can't encode them. Force utf-8 to mirror what the CLI
    # itself does in proofctl/cli.py.
    out_file.write_text(content, encoding="utf-8")
    assert out_file.stat().st_size > 0
    assert "PROOFCTL-Q-001" in out_file.read_text(encoding="utf-8")


def test_c6_terminal_reporter_returns_empty_string_for_no_findings_with_output(tmp_path):
    out_file = tmp_path / "clean.txt"
    reporter = TerminalReporter()
    content = reporter.render([], output=out_file)
    # No findings → "✓ No findings." rendered, non-empty content
    assert "No findings" in content


# ── C-7: single-file scan returns findings for that file ──────────────────────

def test_fail_on_error_with_only_warnings_exits_zero(tmp_path, monkeypatch):
    """`--fail-on ERROR` must exit 0 when only WARNING/INFO findings exist.

    Help text says: "Exit non-zero only if findings at this severity or above
    exist." A WARNING-only run should not fail an ERROR-gated CI step.
    """
    (tmp_path / "code.py").write_text(
        # Q-003 emits WARNING (Any annotation), no ERROR-severity findings.
        "from typing import Any\n"
        "x: Any = 1\n"
        "y: Any = 2\n"
        "z: Any = 3\n"
        "w: Any = 4\n"
    )

    import subprocess, sys
    result = subprocess.run(
        [sys.executable, "-m", "proofctl.cli", "check", str(tmp_path),
         "--no-pypi", "--fail-on", "ERROR", "--format", "json"],
        capture_output=True, text=True,
    )
    # If WARNING findings cause exit 1, this assertion fails (the original bug).
    assert result.returncode == 0, (
        f"Expected exit 0 (WARNINGs only, --fail-on ERROR); got {result.returncode}.\n"
        f"stderr: {result.stderr[:500]}"
    )


def test_c7_single_file_scan_returns_findings(tmp_path):
    """A single-file scan of /repo/src/api/auth.py must return Q-001 findings."""
    target = tmp_path / "src" / "api" / "auth.py"
    target.parent.mkdir(parents=True)
    target.write_text("def login(user, perms=[]):\n    pass\n")
    sibling = tmp_path / "src" / "api" / "other.py"
    sibling.write_text("def helper(items=[]):\n    pass\n")

    # Single-file scan: scan_root = file's parent, then filter to the file.
    scan_root = target.parent
    findings = run_check(scan_root, ProofctlConfig(), families=["Q"])
    rel = str(target.relative_to(scan_root))
    file_findings = [f for f in findings if f.file == rel]

    assert any(f.rule_id == "PROOFCTL-Q-001" for f in file_findings), (
        f"Expected PROOFCTL-Q-001 in single-file findings, got: "
        f"{[(f.rule_id, f.file) for f in file_findings]}"
    )
