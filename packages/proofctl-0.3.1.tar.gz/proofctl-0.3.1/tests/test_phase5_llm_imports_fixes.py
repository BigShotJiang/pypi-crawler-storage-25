"""Regression tests for AUDIT_AND_ROADMAP Phase 5 — LLM and imports fixes.

Covers:
  H-23  LLM-001: detect prompt injection when `messages=<Name>` resolves to a
        list literal assigned earlier in the function or module.
  H-24  LLM-005: silence runaway-loop finding when the body contains a
        defensive guard (`if cnt > MAX: return/break`, deadline guards,
        defensive `return` somewhere in the loop body).
  H-26  MethodChecker emits an INFO PROOFCTL-M-001 disabled-notice when mypy
        is missing instead of silently doing nothing.
  H-27  DependencyChecker reads the broader manifest set: Pipfile,
        poetry.lock, uv.lock, environment.yml, setup.py, setup.cfg, and walks
        the subtree for nested pyproject.toml / requirements*.txt.
"""
from __future__ import annotations

import ast
import shutil
from pathlib import Path

from proofctl.checkers.imports import DependencyChecker, MethodChecker
from proofctl.checkers.llm_integration import LLMChecker
from proofctl.models import Severity


# ═══════════════════════════════════════════════════════════════════════════════
# H-23 — LLM-001 detects messages built as a variable
# ═══════════════════════════════════════════════════════════════════════════════


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def test_h23_llm001_detects_module_level_messages_variable():
    src = '''
import openai
messages = [
    {"role": "system", "content": f"system: {user_input}"},
    {"role": "user", "content": "hi"},
]
openai.ChatCompletion.create(model="gpt-4", messages=messages, max_tokens=200)
'''
    tree = ast.parse(src)
    findings = LLMChecker().check(Path("test.py"), src, tree)
    assert "PROOFCTL-LLM-001" in _ids(findings), (
        f"LLM-001 should fire for module-level messages variable; got {_ids(findings)}"
    )


def test_h23_llm001_detects_function_level_messages_variable():
    src = '''
def call_llm(client, user_input):
    messages = [
        {"role": "system", "content": f"Hello {user_input}"},
    ]
    return client.chat.completions.create(
        model="gpt-4",
        messages=messages,
        max_tokens=200,
    )
'''
    tree = ast.parse(src)
    findings = LLMChecker().check(Path("test.py"), src, tree)
    assert "PROOFCTL-LLM-001" in _ids(findings)


def test_h23_llm001_clean_when_messages_variable_is_safe():
    """A variable list with only constant content should NOT fire LLM-001."""
    src = '''
def call_llm(client):
    messages = [
        {"role": "system", "content": "you are a helpful assistant"},
    ]
    return client.chat.completions.create(
        model="gpt-4",
        messages=messages,
        max_tokens=200,
    )
'''
    tree = ast.parse(src)
    findings = LLMChecker().check(Path("test.py"), src, tree)
    assert "PROOFCTL-LLM-001" not in _ids(findings)


# ═══════════════════════════════════════════════════════════════════════════════
# H-24 — LLM-005 silenced by defensive guards
# ═══════════════════════════════════════════════════════════════════════════════


def test_h24_llm005_silenced_by_defensive_return_in_loop():
    src = '''
def agent(client):
    cnt = 0
    while True:
        cnt += 1
        if cnt > 100:
            return
        client.chat.completions.create(model="gpt-4", messages=[], max_tokens=100)
'''
    tree = ast.parse(src)
    findings = LLMChecker().check(Path("test.py"), src, tree)
    assert "PROOFCTL-LLM-005" not in _ids(findings), (
        f"LLM-005 should be silenced by `if cnt > MAX: return`; got {findings}"
    )


def test_h24_llm005_silenced_by_deadline_guard():
    src = '''
import time
def agent(client, deadline):
    while True:
        if time.time() > deadline:
            break
        client.chat.completions.create(model="gpt-4", messages=[], max_tokens=100)
'''
    tree = ast.parse(src)
    findings = LLMChecker().check(Path("test.py"), src, tree)
    assert "PROOFCTL-LLM-005" not in _ids(findings)


def test_h24_llm005_silenced_by_lt_max_iters_guard():
    """`if step >= MAX: break` style — counter-based break should be tolerated."""
    src = '''
MAX_ITERS = 25
def agent(client):
    step = 0
    while True:
        client.chat.completions.create(model="gpt-4", messages=[], max_tokens=100)
        step += 1
        if step >= MAX_ITERS:
            break
'''
    tree = ast.parse(src)
    findings = LLMChecker().check(Path("test.py"), src, tree)
    assert "PROOFCTL-LLM-005" not in _ids(findings)


def test_h24_llm005_still_fires_on_truly_unguarded_while_true():
    src = '''
def agent(client):
    while True:
        client.chat.completions.create(model="gpt-4", messages=[], max_tokens=100)
'''
    tree = ast.parse(src)
    findings = LLMChecker().check(Path("test.py"), src, tree)
    assert "PROOFCTL-LLM-005" in _ids(findings)


# ═══════════════════════════════════════════════════════════════════════════════
# H-26 — MethodChecker emits INFO when mypy is missing
# ═══════════════════════════════════════════════════════════════════════════════


def test_h26_method_checker_emits_info_when_mypy_missing(monkeypatch, tmp_path):
    monkeypatch.setattr(
        shutil,
        "which",
        lambda name: None if name == "mypy" else "/bin/" + name,
    )
    py = tmp_path / "x.py"
    py.write_text("x = 1\n")
    findings = MethodChecker().check(tmp_path, [py])
    matched = [
        f for f in findings
        if f.rule_id == "PROOFCTL-M-001" and f.severity == Severity.INFO
    ]
    assert matched, (
        "Expected an INFO-level M-001 disabled-notice when mypy is missing; "
        f"got {findings}"
    )
    assert "mypy" in matched[0].message.lower()


def test_h26_method_checker_returns_empty_when_no_python_files(monkeypatch, tmp_path):
    """Empty file list = nothing to check, so no disabled-notice either."""
    monkeypatch.setattr(shutil, "which", lambda name: None)
    findings = MethodChecker().check(tmp_path, [])
    assert findings == []


# ═══════════════════════════════════════════════════════════════════════════════
# H-27 — DependencyChecker reads broader manifest set
# ═══════════════════════════════════════════════════════════════════════════════


def _i002_for(findings):
    return [f for f in findings if f.rule_id == "PROOFCTL-I-002"]


def test_h27_dep_checker_reads_pipfile(tmp_path):
    (tmp_path / "Pipfile").write_text(
        "[[source]]\n"
        "url = 'https://pypi.org/simple'\n"
        "[packages]\n"
        "boto4 = '*'\n"
        "requests = '>=2.0'\n"
    )
    findings = DependencyChecker().check(tmp_path, [])
    matched = _i002_for(findings)
    assert any("boto4" in f.message for f in matched), (
        f"Expected I-002 for boto4 in Pipfile; got {findings}"
    )


def test_h27_dep_checker_reads_poetry_lock(tmp_path):
    (tmp_path / "poetry.lock").write_text(
        '[[package]]\n'
        'name = "boto4"\n'
        'version = "1.0.0"\n'
        'description = "fake"\n'
        'category = "main"\n'
        '\n'
        '[[package]]\n'
        'name = "requests"\n'
        'version = "2.31.0"\n'
        'description = "real"\n'
        'category = "main"\n'
    )
    findings = DependencyChecker().check(tmp_path, [])
    matched = _i002_for(findings)
    assert any("boto4" in f.message for f in matched)


def test_h27_dep_checker_reads_uv_lock(tmp_path):
    (tmp_path / "uv.lock").write_text(
        '[[package]]\n'
        'name = "boto4"\n'
        'version = "1.0.0"\n'
    )
    findings = DependencyChecker().check(tmp_path, [])
    assert any("boto4" in f.message for f in _i002_for(findings))


def test_h27_dep_checker_reads_environment_yml(tmp_path):
    (tmp_path / "environment.yml").write_text(
        "name: env\n"
        "channels:\n"
        "  - defaults\n"
        "dependencies:\n"
        "  - python=3.11\n"
        "  - boto4=1.0\n"
        "  - numpy=1.20\n"
    )
    findings = DependencyChecker().check(tmp_path, [])
    assert any("boto4" in f.message for f in _i002_for(findings))


def test_h27_dep_checker_reads_setup_py(tmp_path):
    (tmp_path / "setup.py").write_text(
        "from setuptools import setup\n"
        "setup(\n"
        "    name='demo',\n"
        "    install_requires=[\n"
        "        'boto4>=1.0',\n"
        "        'requests',\n"
        "    ],\n"
        ")\n"
    )
    findings = DependencyChecker().check(tmp_path, [])
    assert any("boto4" in f.message for f in _i002_for(findings))


def test_h27_dep_checker_reads_setup_cfg(tmp_path):
    (tmp_path / "setup.cfg").write_text(
        "[metadata]\n"
        "name = demo\n"
        "\n"
        "[options]\n"
        "install_requires =\n"
        "    boto4>=1.0\n"
        "    requests\n"
    )
    findings = DependencyChecker().check(tmp_path, [])
    assert any("boto4" in f.message for f in _i002_for(findings))


def test_h27_dep_checker_walks_monorepo_subprojects(tmp_path):
    """A nested pyproject.toml in a sub-project should be picked up too."""
    sub = tmp_path / "services" / "ingest"
    sub.mkdir(parents=True)
    (sub / "pyproject.toml").write_text(
        "[project]\n"
        'name = "ingest"\n'
        "dependencies = [\n"
        '    "boto4>=1.0",\n'
        "]\n"
    )
    findings = DependencyChecker().check(tmp_path, [])
    assert any(
        "boto4" in f.message and str(sub) in f.file
        for f in _i002_for(findings)
    )


def test_h27_dep_checker_does_not_crash_on_malformed_files(tmp_path):
    """Best-effort parsing: malformed files should be skipped, not crash."""
    (tmp_path / "Pipfile").write_text(":::not valid TOML at all:::\n[packages\n")
    (tmp_path / "poetry.lock").write_text("garbage in == garbage out\n[[")
    (tmp_path / "environment.yml").write_text("just a plain text file\n")
    (tmp_path / "setup.py").write_text("def(((( malformed python\n")
    (tmp_path / "setup.cfg").write_text("not a valid config\n[[[[\n")
    # Should complete without raising.
    findings = DependencyChecker().check(tmp_path, [])
    # We accept any number of findings (including zero) — the contract is "no crash".
    assert isinstance(findings, list)
