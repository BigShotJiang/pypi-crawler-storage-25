"""Tests for PROOFCTL-SECRET-* — secret detection rules."""
from __future__ import annotations

from pathlib import Path

from proofctl.checkers.secrets import SecretChecker
from proofctl.models import Severity

_checker = SecretChecker()


def _check(src: str, name: str = "config.txt"):
    return _checker.check(Path(name), src)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ── SECRET-001: AWS access key ────────────────────────────────────────────────

def test_s001_positive():
    src = 'access_key = "AKIAIOSFODNN7EXAMPLE"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s001_clean():
    src = 'access_key = "${AWS_ACCESS_KEY}"\n'
    assert "PROOFCTL-SECRET-001" not in _ids(_check(src))


# ── SECRET-002: AWS secret key ────────────────────────────────────────────────

def test_s002_positive():
    src = 'aws_secret_access_key = "wJalrXUtnFEMICK7MDENGbPxRfiCYEXAMPLEKEY1"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-002")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s002_clean():
    src = 'aws_secret_access_key = "${var.aws_secret}"\n'
    assert "PROOFCTL-SECRET-002" not in _ids(_check(src))


# ── SECRET-003: GitHub token ──────────────────────────────────────────────────

def test_s003_positive():
    src = 'token: ghp_' + 'A' * 40 + '\n'
    f = _find(_check(src), "PROOFCTL-SECRET-003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s003_clean():
    src = 'token: ${GITHUB_TOKEN}\n'
    assert "PROOFCTL-SECRET-003" not in _ids(_check(src))


# ── SECRET-004: Slack token ───────────────────────────────────────────────────

def test_s004_positive():
    src = 'slack = "xoxb-12345-67890-abcdefghij"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-004")
    assert len(f) == 1


def test_s004_clean():
    src = 'slack = "${SLACK_TOKEN}"\n'
    assert "PROOFCTL-SECRET-004" not in _ids(_check(src))


# ── SECRET-005: Private key ───────────────────────────────────────────────────

def test_s005_positive():
    src = "-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQ...\n"
    f = _find(_check(src), "PROOFCTL-SECRET-005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s005_clean():
    src = "# Use openssl to generate a private key\n"
    assert "PROOFCTL-SECRET-005" not in _ids(_check(src))


# ── SECRET-006: JWT ───────────────────────────────────────────────────────────

def test_s006_positive():
    jwt = (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
        "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4ifQ."
        "SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
    )
    src = f'jwt = "{jwt}"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-006")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s006_clean():
    src = 'jwt = "eyJ..."\n'  # truncated/placeholder
    assert "PROOFCTL-SECRET-006" not in _ids(_check(src))


# ── SECRET-007: Generic high-entropy assignment ───────────────────────────────

def test_s007_positive():
    src = 'password = "Xq7vKp3mZw9LrT2nB8sFhJdC"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s007_clean_placeholder():
    src = 'password = "changeme"\n'
    assert "PROOFCTL-SECRET-007" not in _ids(_check(src))


def test_s007_clean_envref():
    src = 'password = "${DB_PASSWORD}"\n'
    assert "PROOFCTL-SECRET-007" not in _ids(_check(src))


def test_s007_clean_low_entropy():
    src = 'password = "aaaaaaaa"\n'
    assert "PROOFCTL-SECRET-007" not in _ids(_check(src))


# ── SECRET-008: Google API key ────────────────────────────────────────────────

def test_s008_positive():
    src = 'GOOGLE_API_KEY = "AIza' + 'A' * 35 + '"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-008")
    assert len(f) == 1


def test_s008_clean():
    src = 'GOOGLE_API_KEY = "${GOOGLE_KEY}"\n'
    assert "PROOFCTL-SECRET-008" not in _ids(_check(src))


# ── SECRET-009: Stripe key ────────────────────────────────────────────────────

def test_s009_positive():
    src = 'stripe = "sk_live_' + '1' * 30 + '"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-009")
    assert len(f) == 1


def test_s009_clean():
    src = 'stripe = "${STRIPE_KEY}"\n'
    assert "PROOFCTL-SECRET-009" not in _ids(_check(src))


# ── SECRET-010: Terraform admin password ──────────────────────────────────────

def test_s010_positive():
    src = 'administrator_login_password = "Aa12345678"\n'
    f = _find(_check(src), "PROOFCTL-SECRET-010")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s010_clean_envref():
    src = 'administrator_login_password = "${var.admin_password}"\n'
    assert "PROOFCTL-SECRET-010" not in _ids(_check(src))


# ── infrastructure: binary skip, lockfile skip, dedup ─────────────────────────

def test_skip_binary_file():
    # Null byte in first 1024 → binary
    src = "AKIAIOSFODNN7EXAMPLE\x00\x00\x00binary garbage"
    assert _check(src, "blob.dat") == []


def test_skip_lockfile():
    src = 'access_key = "AKIAIOSFODNN7EXAMPLE"\n'
    assert _check(src, "package-lock.json") == []
    assert _check(src, "yarn.lock") == []
    assert _check(src, "Cargo.lock") == []


def test_skip_min_js():
    src = 'k="AKIAIOSFODNN7EXAMPLE"'
    assert _check(src, "app.min.js") == []


def test_dedup_same_value_one_finding():
    # An AWS access key embedded in a 'password = "..."' assignment should
    # fire SECRET-001 (most specific) once, not also SECRET-007.
    src = 'password = "AKIAIOSFODNN7EXAMPLE"\n'
    findings = _check(src)
    rule_ids = _ids(findings)
    assert "PROOFCTL-SECRET-001" in rule_ids
    # SECRET-007 must not also fire on the same value
    assert "PROOFCTL-SECRET-007" not in rule_ids


# ── SECRET-011: Plaintext credentials in kind: Secret YAML ────────────────────

def test_s011_positive_data():
    src = (
        "apiVersion: v1\n"
        "kind: Secret\n"
        "metadata:\n"
        "  name: db-creds\n"
        "type: Opaque\n"
        "data:\n"
        "  password: cGFzc3dvcmQxMjM=\n"
    )
    f = _find(_check(src, "secret.yaml"), "PROOFCTL-SECRET-011")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "db-creds" in f[0].message


def test_s011_positive_string_data():
    src = (
        "apiVersion: v1\n"
        "kind: Secret\n"
        "metadata:\n"
        "  name: api-key\n"
        "stringData:\n"
        "  token: real-plaintext-token\n"
    )
    f = _find(_check(src, "secret.yaml"), "PROOFCTL-SECRET-011")
    assert len(f) == 1
    assert "api-key" in f[0].message


def test_s011_clean_value_from():
    # A Pod/Deployment that references a Secret via valueFrom.secretKeyRef
    # is the correct externalized pattern — should NOT fire.
    src = (
        "apiVersion: v1\n"
        "kind: Pod\n"
        "metadata:\n"
        "  name: web\n"
        "spec:\n"
        "  containers:\n"
        "    - name: app\n"
        "      env:\n"
        "        - name: DB_PASSWORD\n"
        "          valueFrom:\n"
        "            secretKeyRef:\n"
        "              name: db-creds\n"
        "              key: password\n"
    )
    assert "PROOFCTL-SECRET-011" not in _ids(_check(src, "pod.yaml"))


def test_s011_skip_configmap():
    src = (
        "apiVersion: v1\n"
        "kind: ConfigMap\n"
        "metadata:\n"
        "  name: cfg\n"
        "data:\n"
        "  setting: value\n"
    )
    assert "PROOFCTL-SECRET-011" not in _ids(_check(src, "cm.yaml"))


def test_s011_multidoc():
    src = (
        "apiVersion: v1\n"
        "kind: ConfigMap\n"
        "metadata:\n"
        "  name: cfg\n"
        "data:\n"
        "  foo: bar\n"
        "---\n"
        "apiVersion: v1\n"
        "kind: Secret\n"
        "metadata:\n"
        "  name: real-secret\n"
        "data:\n"
        "  pw: c2VjcmV0\n"
        "---\n"
        "apiVersion: v1\n"
        "kind: Secret\n"
        "metadata:\n"
        "  name: empty-secret\n"
        "data: {}\n"
    )
    f = _find(_check(src, "multi.yaml"), "PROOFCTL-SECRET-011")
    # First doc is ConfigMap, second is real Secret with data, third has empty data.
    assert len(f) == 1
    assert "real-secret" in f[0].message


def test_s011_skip_tests_path():
    src = (
        "apiVersion: v1\n"
        "kind: Secret\n"
        "metadata:\n"
        "  name: db-creds\n"
        "data:\n"
        "  password: cGFzc3dvcmQ=\n"
    )
    assert "PROOFCTL-SECRET-011" not in _ids(
        _check(src, "/repo/tests/fixtures/secret.yaml")
    )


# ── SECRET-012: Secret-shaped env assignment inside heredoc ───────────────────

def test_s012_positive_user_data():
    src = (
        'resource "aws_instance" "web" {\n'
        '  user_data = <<EOF\n'
        '#!/bin/bash\n'
        'export DEPLOY_TOKEN=abc12345defgh67890\n'
        'EOF\n'
        '}\n'
    )
    f = _find(_check(src, "ec2.tf"), "PROOFCTL-SECRET-012")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s012_clean_envref_in_heredoc():
    src = (
        'user_data = <<EOF\n'
        '#!/bin/bash\n'
        'export API_KEY=${MY_KEY}\n'
        'EOF\n'
    )
    assert "PROOFCTL-SECRET-012" not in _ids(_check(src, "ec2.tf"))


def test_s012_skip_no_secret_shaped_content():
    src = (
        'user_data = <<EOF\n'
        '#!/bin/bash\n'
        'echo "hello world"\n'
        'systemctl restart nginx\n'
        'EOF\n'
    )
    assert "PROOFCTL-SECRET-012" not in _ids(_check(src, "ec2.tf"))


def test_s012_dedup_with_secret_001():
    # If SECRET-001 already fired on the same line (raw AKIA pattern matches
    # line-wise inside heredoc), SECRET-012 should NOT also fire.
    src = (
        'user_data = <<EOF\n'
        'export AWS_ACCESS_KEY_ID=AKIAIOSFODNN7EXAMPLE\n'
        'EOF\n'
    )
    findings = _check(src, "ec2.tf")
    rids = _ids(findings)
    assert "PROOFCTL-SECRET-001" in rids
    assert "PROOFCTL-SECRET-012" not in rids
