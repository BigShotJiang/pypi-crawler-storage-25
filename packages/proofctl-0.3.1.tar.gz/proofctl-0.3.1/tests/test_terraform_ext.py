"""Tests for extended Terraform rules:
  - TF-AZ-001..012  Azure rules
  - TF-G026..031    GCP extended rules
  - TF-A011..014    AWS extended rules
  - TF-T014..015    General Terraform extended rules
"""
from __future__ import annotations

from pathlib import Path

import pytest

from proofctl.checkers.terraform import TerraformChecker
from proofctl.models import Severity

_P = Path("test.tf")
_checker = TerraformChecker()


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-001 — Storage account public blob access
# ══════════════════════════════════════════════════════════════════════════════


def test_az001_public_blob_access_true():
    src = """
resource "azurerm_storage_account" "bad" {
  name                     = "badsa"
  allow_blob_public_access = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "bad" in f[0].message


def test_az001_public_blob_access_false_clean():
    src = """
resource "azurerm_storage_account" "ok" {
  name                     = "goodsa"
  allow_blob_public_access = false
}
"""
    assert "PROOFCTL-TF-AZ001" not in _ids(_checker.check(_P, src))


def test_az001_absent_not_flagged():
    # Absent means provider default — per spec, only flag explicit true
    src = """
resource "azurerm_storage_account" "neutral" {
  name = "neutralsa"
}
"""
    assert "PROOFCTL-TF-AZ001" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-002 — Storage account missing network_rules default_action = Deny
# ══════════════════════════════════════════════════════════════════════════════


def test_az002_no_network_rules():
    src = """
resource "azurerm_storage_account" "bad" {
  name = "mysa"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ002")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az002_network_rules_allow_not_deny():
    src = """
resource "azurerm_storage_account" "bad" {
  name = "mysa"
  network_rules {
    default_action = "Allow"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ002")
    assert len(f) == 1


def test_az002_network_rules_deny_clean():
    src = """
resource "azurerm_storage_account" "ok" {
  name = "mysa"
  network_rules {
    default_action = "Deny"
    ip_rules       = ["1.2.3.4"]
  }
}
"""
    assert "PROOFCTL-TF-AZ002" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-003 — SQL Server public network access
# ══════════════════════════════════════════════════════════════════════════════


def test_az003_mssql_public_access_true():
    src = """
resource "azurerm_mssql_server" "bad" {
  name                          = "mysql"
  public_network_access_enabled = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az003_sql_server_public_access_true():
    src = """
resource "azurerm_sql_server" "bad" {
  name                          = "mysql"
  public_network_access_enabled = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ003")
    assert len(f) == 1


def test_az003_mssql_public_access_false_clean():
    src = """
resource "azurerm_mssql_server" "ok" {
  name                          = "mysql"
  public_network_access_enabled = false
}
"""
    assert "PROOFCTL-TF-AZ003" not in _ids(_checker.check(_P, src))


def test_az003_absent_not_flagged():
    # Absent — don't over-flag
    src = """
resource "azurerm_mssql_server" "neutral" {
  name = "mysql"
}
"""
    assert "PROOFCTL-TF-AZ003" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-004 — PostgreSQL/MySQL SSL enforcement disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_az004_postgresql_ssl_disabled():
    src = """
resource "azurerm_postgresql_server" "bad" {
  name                   = "pg"
  ssl_enforcement_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "azurerm_postgresql_server" in f[0].message


def test_az004_mysql_ssl_disabled():
    src = """
resource "azurerm_mysql_server" "bad" {
  name                   = "mysql"
  ssl_enforcement_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ004")
    assert len(f) == 1


def test_az004_postgresql_ssl_enabled_clean():
    src = """
resource "azurerm_postgresql_server" "ok" {
  name                   = "pg"
  ssl_enforcement_enabled = true
}
"""
    assert "PROOFCTL-TF-AZ004" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-005 — AKS API server IP restrictions absent
# ══════════════════════════════════════════════════════════════════════════════


def test_az005_aks_no_ip_ranges():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name = "mycluster"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az005_aks_null_ip_ranges():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = null
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ005")
    assert len(f) == 1


def test_az005_aks_empty_list():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = []
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ005")
    assert len(f) == 1


def test_az005_aks_ip_ranges_set_clean():
    src = """
resource "azurerm_kubernetes_cluster" "ok" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = ["10.0.0.0/8"]
}
"""
    assert "PROOFCTL-TF-AZ005" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-006 — AKS RBAC disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_az006_rbac_disabled():
    src = """
resource "azurerm_kubernetes_cluster" "bad" {
  name                            = "mycluster"
  role_based_access_control_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ006")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az006_rbac_enabled_clean():
    src = """
resource "azurerm_kubernetes_cluster" "ok" {
  name                            = "mycluster"
  role_based_access_control_enabled = true
  api_server_authorized_ip_ranges   = ["10.0.0.0/8"]
}
"""
    assert "PROOFCTL-TF-AZ006" not in _ids(_checker.check(_P, src))


def test_az006_rbac_absent_not_flagged():
    # Absent means provider default (true in newer versions) — don't over-flag
    src = """
resource "azurerm_kubernetes_cluster" "neutral" {
  name                            = "mycluster"
  api_server_authorized_ip_ranges = ["10.0.0.0/8"]
}
"""
    assert "PROOFCTL-TF-AZ006" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-007 — Key Vault purge protection disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_az007_purge_protection_absent():
    src = """
resource "azurerm_key_vault" "bad" {
  name     = "mykv"
  sku_name = "standard"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az007_purge_protection_false():
    src = """
resource "azurerm_key_vault" "bad" {
  name                    = "mykv"
  purge_protection_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ007")
    assert len(f) == 1


def test_az007_purge_protection_true_clean():
    src = """
resource "azurerm_key_vault" "ok" {
  name                          = "mykv"
  purge_protection_enabled      = true
  soft_delete_retention_days    = 30
}
"""
    assert "PROOFCTL-TF-AZ007" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-008 — Key Vault key missing expiration_date
# ══════════════════════════════════════════════════════════════════════════════


def test_az008_key_no_expiration():
    src = """
resource "azurerm_key_vault_key" "bad" {
  name         = "mykey"
  key_vault_id = azurerm_key_vault.kv.id
  key_type     = "RSA"
  key_size     = 2048
  key_opts     = ["decrypt", "encrypt"]
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ008")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az008_key_with_expiration_clean():
    src = """
resource "azurerm_key_vault_key" "ok" {
  name            = "mykey"
  key_vault_id    = azurerm_key_vault.kv.id
  key_type        = "RSA"
  key_size        = 2048
  key_opts        = ["decrypt", "encrypt"]
  expiration_date = "2026-12-31T00:00:00Z"
}
"""
    assert "PROOFCTL-TF-AZ008" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-009 — Monitor log profile retention < 90 days
# ══════════════════════════════════════════════════════════════════════════════


def test_az009_log_profile_retention_30_days():
    src = """
resource "azurerm_monitor_log_profile" "bad" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 30
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ009")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "30" in f[0].message


def test_az009_log_profile_retention_0_days():
    src = """
resource "azurerm_monitor_log_profile" "bad" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 0
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ009")
    assert len(f) == 1


def test_az009_log_profile_retention_365_days_clean():
    src = """
resource "azurerm_monitor_log_profile" "ok" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 365
  }
}
"""
    assert "PROOFCTL-TF-AZ009" not in _ids(_checker.check(_P, src))


def test_az009_log_profile_retention_90_days_clean():
    src = """
resource "azurerm_monitor_log_profile" "ok" {
  name = "myprofile"
  retention_policy {
    enabled = true
    days    = 90
  }
}
"""
    assert "PROOFCTL-TF-AZ009" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-010 — Overly broad Azure role assignment / wildcard role definition
# ══════════════════════════════════════════════════════════════════════════════


def test_az010_owner_at_subscription_scope():
    src = """
resource "azurerm_role_assignment" "bad" {
  scope                = "/subscriptions/00000000-0000-0000-0000-000000000000"
  role_definition_name = "Owner"
  principal_id         = "some-principal-id"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ010")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az010_contributor_at_subscription_scope():
    src = """
resource "azurerm_role_assignment" "bad" {
  scope                = "/subscriptions/00000000-0000-0000-0000-000000000000"
  role_definition_name = "Contributor"
  principal_id         = "some-principal-id"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ010")
    assert len(f) == 1


def test_az010_owner_at_resource_group_clean():
    src = """
resource "azurerm_role_assignment" "ok" {
  scope                = "/subscriptions/00000000/resourceGroups/my-rg"
  role_definition_name = "Owner"
  principal_id         = "some-principal-id"
}
"""
    assert "PROOFCTL-TF-AZ010" not in _ids(_checker.check(_P, src))


def test_az010_reader_at_subscription_clean():
    src = """
resource "azurerm_role_assignment" "ok" {
  scope                = "/subscriptions/00000000-0000-0000-0000-000000000000"
  role_definition_name = "Reader"
  principal_id         = "some-principal-id"
}
"""
    assert "PROOFCTL-TF-AZ010" not in _ids(_checker.check(_P, src))


def test_az010_role_definition_wildcard_actions():
    src = """
resource "azurerm_role_definition" "bad" {
  name  = "super-admin"
  scope = "/subscriptions/00000000"
  permissions {
    actions = ["*"]
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ010")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az010_role_definition_scoped_actions_clean():
    src = """
resource "azurerm_role_definition" "ok" {
  name  = "limited"
  scope = "/subscriptions/00000000"
  permissions {
    actions = ["Microsoft.Storage/storageAccounts/read"]
  }
}
"""
    assert "PROOFCTL-TF-AZ010" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-011 — App Service allows HTTP
# ══════════════════════════════════════════════════════════════════════════════


def test_az011_app_service_https_only_absent():
    src = """
resource "azurerm_app_service" "bad" {
  name                = "myapp"
  resource_group_name = "rg"
  app_service_plan_id = "plan-id"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ011")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az011_linux_web_app_https_false():
    src = """
resource "azurerm_linux_web_app" "bad" {
  name                = "myapp"
  https_only          = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ011")
    assert len(f) == 1


def test_az011_windows_web_app_https_false():
    src = """
resource "azurerm_windows_web_app" "bad" {
  name                = "myapp"
  https_only          = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ011")
    assert len(f) == 1


def test_az011_https_only_true_clean():
    src = """
resource "azurerm_linux_web_app" "ok" {
  name       = "myapp"
  https_only = true
}
"""
    assert "PROOFCTL-TF-AZ011" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ-012 — VM missing encryption at host
# ══════════════════════════════════════════════════════════════════════════════


def test_az012_linux_vm_no_encryption_at_host():
    src = """
resource "azurerm_linux_virtual_machine" "bad" {
  name           = "myvm"
  admin_username = "admin"
  size           = "Standard_D2s_v3"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ012")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_az012_windows_vm_encryption_false():
    src = """
resource "azurerm_windows_virtual_machine" "bad" {
  name                      = "myvm"
  encryption_at_host_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ012")
    assert len(f) == 1


def test_az012_linux_vm_encryption_enabled_clean():
    src = """
resource "azurerm_linux_virtual_machine" "ok" {
  name                      = "myvm"
  admin_username            = "admin"
  encryption_at_host_enabled = true
}
"""
    assert "PROOFCTL-TF-AZ012" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G026 — IAM binding with allUsers / allAuthenticatedUsers
# ══════════════════════════════════════════════════════════════════════════════


def test_g026_all_users_member():
    src = """
resource "google_project_iam_member" "bad" {
  project = "my-project"
  role    = "roles/storage.objectViewer"
  member  = "allUsers"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G026")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g026_all_authenticated_users():
    src = """
resource "google_project_iam_binding" "bad" {
  project = "my-project"
  role    = "roles/viewer"
  members = ["allAuthenticatedUsers"]
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G026")
    assert len(f) == 1


def test_g026_specific_member_clean():
    src = """
resource "google_project_iam_member" "ok" {
  project = "my-project"
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:sa@project.iam.gserviceaccount.com"
}
"""
    assert "PROOFCTL-TF-G026" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G027 — Cloud Function with ALLOW_ALL ingress
# ══════════════════════════════════════════════════════════════════════════════


def test_g027_cloud_function_allow_all():
    src = """
resource "google_cloudfunctions_function" "bad" {
  name             = "my-func"
  ingress_settings = "ALLOW_ALL"
  runtime          = "python39"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G027")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g027_cloud_function_internal_only_clean():
    src = """
resource "google_cloudfunctions_function" "ok" {
  name             = "my-func"
  ingress_settings = "ALLOW_INTERNAL_ONLY"
  runtime          = "python39"
}
"""
    assert "PROOFCTL-TF-G027" not in _ids(_checker.check(_P, src))


def test_g027_cloud_function_no_ingress_setting_clean():
    # Absent = provider default (ALLOW_ALL is explicit, absence is not flagged)
    src = """
resource "google_cloudfunctions_function" "neutral" {
  name    = "my-func"
  runtime = "python39"
}
"""
    assert "PROOFCTL-TF-G027" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G028 — Cloud Run IAM with allUsers
# ══════════════════════════════════════════════════════════════════════════════


def test_g028_cloud_run_all_users_member():
    src = """
resource "google_cloud_run_service_iam_member" "bad" {
  service  = "my-service"
  location = "us-central1"
  role     = "roles/run.invoker"
  member   = "allUsers"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G028")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g028_cloud_run_all_users_binding():
    src = """
resource "google_cloud_run_service_iam_binding" "bad" {
  service  = "my-service"
  location = "us-central1"
  role     = "roles/run.invoker"
  members  = ["allUsers"]
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G028")
    assert len(f) == 1


def test_g028_cloud_run_specific_member_clean():
    src = """
resource "google_cloud_run_service_iam_member" "ok" {
  service  = "my-service"
  location = "us-central1"
  role     = "roles/run.invoker"
  member   = "serviceAccount:sa@project.iam.gserviceaccount.com"
}
"""
    assert "PROOFCTL-TF-G028" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G029 — Subnetwork missing VPC Flow Logs
# ══════════════════════════════════════════════════════════════════════════════


def test_g029_subnetwork_no_log_config():
    src = """
resource "google_compute_subnetwork" "bad" {
  name          = "my-subnet"
  ip_cidr_range = "10.0.0.0/24"
  region        = "us-central1"
  network       = "default"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G029")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g029_subnetwork_with_log_config_clean():
    src = """
resource "google_compute_subnetwork" "ok" {
  name          = "my-subnet"
  ip_cidr_range = "10.0.0.0/24"
  region        = "us-central1"
  network       = "default"
  log_config {
    aggregation_interval = "INTERVAL_5_SEC"
    flow_sampling        = 0.5
    metadata             = "INCLUDE_ALL_METADATA"
  }
}
"""
    assert "PROOFCTL-TF-G029" not in _ids(_checker.check(_P, src))


def test_g029_proxy_subnet_not_flagged():
    src = """
resource "google_compute_subnetwork" "proxy" {
  name          = "proxy-subnet"
  ip_cidr_range = "10.0.1.0/24"
  purpose       = "INTERNAL_HTTPS_LOAD_BALANCER"
  network       = "default"
}
"""
    assert "PROOFCTL-TF-G029" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G030 — BigQuery dataset with public access
# ══════════════════════════════════════════════════════════════════════════════


def test_g030_bigquery_all_authenticated_users():
    src = """
resource "google_bigquery_dataset" "bad" {
  dataset_id = "my_dataset"
  access {
    role          = "READER"
    special_group = "allAuthenticatedUsers"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G030")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g030_bigquery_all_users():
    src = """
resource "google_bigquery_dataset" "bad" {
  dataset_id = "my_dataset"
  access {
    role          = "READER"
    special_group = "allUsers"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G030")
    assert len(f) == 1


def test_g030_bigquery_specific_user_clean():
    src = """
resource "google_bigquery_dataset" "ok" {
  dataset_id = "my_dataset"
  access {
    role          = "READER"
    user_by_email = "analyst@example.com"
  }
}
"""
    assert "PROOFCTL-TF-G030" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G031 — Pub/Sub topic without CMEK
# ══════════════════════════════════════════════════════════════════════════════


def test_g031_pubsub_no_kms():
    src = """
resource "google_pubsub_topic" "bad" {
  name = "my-topic"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G031")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g031_pubsub_with_kms_clean():
    src = """
resource "google_pubsub_topic" "ok" {
  name         = "my-topic"
  kms_key_name = "projects/my-project/locations/us/keyRings/my-ring/cryptoKeys/my-key"
}
"""
    assert "PROOFCTL-TF-G031" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A011 — No aws_cloudtrail resource
# ══════════════════════════════════════════════════════════════════════════════


def test_a011_no_cloudtrail_with_aws_resources():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A011")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a011_with_cloudtrail_clean():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_cloudtrail" "main" {
  name                          = "main"
  s3_bucket_name                = "my-bucket"
  is_multi_region_trail         = true
  enable_log_file_validation    = true
}
"""
    assert "PROOFCTL-TF-A011" not in _ids(_checker.check(_P, src))


def test_a011_no_aws_resources_no_flag():
    # No aws_* resources at all — don't fire
    src = """
resource "google_compute_instance" "vm" {
  name = "my-vm"
}
"""
    assert "PROOFCTL-TF-A011" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A012 — aws_vpc without aws_flow_log
# ══════════════════════════════════════════════════════════════════════════════


def test_a012_vpc_no_flow_log():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A012")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a012_vpc_with_flow_log_clean():
    src = """
resource "aws_vpc" "main" {
  cidr_block = "10.0.0.0/16"
}

resource "aws_flow_log" "main" {
  iam_role_arn    = aws_iam_role.flow_log.arn
  log_destination = aws_cloudwatch_log_group.flow_log.arn
  traffic_type    = "ALL"
  vpc_id          = aws_vpc.main.id
}
"""
    assert "PROOFCTL-TF-A012" not in _ids(_checker.check(_P, src))


def test_a012_no_vpc_no_flag():
    src = """
resource "aws_s3_bucket" "data" {
  bucket = "my-data"
}
"""
    assert "PROOFCTL-TF-A012" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A013 — ECR repository mutable tags / scan_on_push disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_a013_ecr_mutable_tags():
    src = """
resource "aws_ecr_repository" "bad" {
  name                 = "my-repo"
  image_tag_mutability = "MUTABLE"
  image_scanning_configuration {
    scan_on_push = true
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A013")
    assert any("mutable" in fi.message.lower() for fi in f)


def test_a013_ecr_scan_disabled():
    src = """
resource "aws_ecr_repository" "bad" {
  name                 = "my-repo"
  image_tag_mutability = "IMMUTABLE"
  image_scanning_configuration {
    scan_on_push = false
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A013")
    assert any("scan_on_push" in fi.message for fi in f)


def test_a013_ecr_immutable_with_scan_clean():
    src = """
resource "aws_ecr_repository" "ok" {
  name                 = "my-repo"
  image_tag_mutability = "IMMUTABLE"
  image_scanning_configuration {
    scan_on_push = true
  }
}
"""
    # Should not flag mutability; may still flag scan_on_push due to scan_on_push = true being present
    mutable_findings = [
        fi for fi in _find(_checker.check(_P, src), "PROOFCTL-TF-A013")
        if "mutable" in fi.message.lower()
    ]
    assert len(mutable_findings) == 0


# ══════════════════════════════════════════════════════════════════════════════
# TF-A014 — Lambda hardcoded secret in env vars
# ══════════════════════════════════════════════════════════════════════════════


def test_a014_lambda_hardcoded_secret():
    src = """
resource "aws_lambda_function" "bad" {
  function_name = "my-func"
  handler       = "index.handler"
  runtime       = "python3.9"
  role          = aws_iam_role.lambda_role.arn
  environment {
    variables = {
      API_KEY = "hardcoded_secret_value_here"
    }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A014")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a014_lambda_secret_manager_ref_clean():
    src = """
resource "aws_lambda_function" "ok" {
  function_name = "my-func"
  handler       = "index.handler"
  runtime       = "python3.9"
  role          = aws_iam_role.lambda_role.arn
  environment {
    variables = {
      API_KEY = data.aws_secretsmanager_secret_version.key.secret_string
    }
  }
}
"""
    assert "PROOFCTL-TF-A014" not in _ids(_checker.check(_P, src))


def test_a014_lambda_no_environment_clean():
    src = """
resource "aws_lambda_function" "ok" {
  function_name = "my-func"
  handler       = "index.handler"
  runtime       = "python3.9"
  role          = aws_iam_role.lambda_role.arn
}
"""
    assert "PROOFCTL-TF-A014" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-T014 — No terraform required_version constraint
# ══════════════════════════════════════════════════════════════════════════════


from proofctl.checkers.terraform import TerraformDirChecker

_dir_checker = TerraformDirChecker()


_RES_VPC = 'resource "aws_vpc" "{name}" {{\n  cidr_block = "10.0.0.0/16"\n}}\n'
_TERRAFORM_BLOCK = 'terraform {\n  required_version = ">= 1.0"\n}\n'


def test_t014_module_fires_when_no_required_version(tmp_path):
    (tmp_path / "main.tf").write_text(_RES_VPC.format(name="main"))
    findings = _dir_checker.check(tmp_path, [tmp_path / "main.tf"])
    f = _find(findings, "PROOFCTL-TF-T014")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_t014_clean_when_required_version_in_same_file(tmp_path):
    (tmp_path / "main.tf").write_text(_TERRAFORM_BLOCK + _RES_VPC.format(name="main"))
    assert "PROOFCTL-TF-T014" not in _ids(
        _dir_checker.check(tmp_path, [tmp_path / "main.tf"])
    )


def test_t014_clean_when_required_version_in_sibling_versions_tf(tmp_path):
    """The bug we fixed: main.tf has resources, versions.tf has the constraint."""
    (tmp_path / "main.tf").write_text(_RES_VPC.format(name="main"))
    (tmp_path / "versions.tf").write_text(_TERRAFORM_BLOCK)
    files = [tmp_path / "main.tf", tmp_path / "versions.tf"]
    assert "PROOFCTL-TF-T014" not in _ids(_dir_checker.check(tmp_path, files))


def test_t014_no_resources_no_flag(tmp_path):
    (tmp_path / "vars.tf").write_text(
        'variable "region" {\n  type = string\n}\n'
    )
    assert "PROOFCTL-TF-T014" not in _ids(
        _dir_checker.check(tmp_path, [tmp_path / "vars.tf"])
    )


def test_t014_module_block_alone_fires(tmp_path):
    (tmp_path / "main.tf").write_text(
        'module "vpc" {\n  source = "./vpc"\n}\n'
    )
    f = _find(_dir_checker.check(tmp_path, [tmp_path / "main.tf"]), "PROOFCTL-TF-T014")
    assert len(f) == 1


def test_t014_fires_once_per_module(tmp_path):
    """Multiple .tf files in one dir should produce one T014, not many."""
    for name in ("main.tf", "vpc.tf", "iam.tf"):
        (tmp_path / name).write_text(_RES_VPC.format(name=name[:-3]))
    files = sorted(tmp_path.glob("*.tf"))
    f = _find(_dir_checker.check(tmp_path, files), "PROOFCTL-TF-T014")
    assert len(f) == 1


def test_t014_skipped_in_test_fixture_dir(tmp_path):
    test_dir = tmp_path / "test" / "fixtures" / "vpc"
    test_dir.mkdir(parents=True)
    (test_dir / "main.tf").write_text(
        'resource "aws_vpc" "x" { cidr_block = "10.0.0.0/16" }\n'
    )
    assert "PROOFCTL-TF-T014" not in _ids(
        _dir_checker.check(tmp_path, [test_dir / "main.tf"])
    )


# ══════════════════════════════════════════════════════════════════════════════
# TF-T015 — Sensitive output without sensitive = true
# ══════════════════════════════════════════════════════════════════════════════


def test_t015_password_output_not_sensitive():
    src = """
output "db_password" {
  value = aws_db_instance.main.password
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T015")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_t015_secret_output_not_sensitive():
    src = """
output "api_secret" {
  value = data.aws_secretsmanager_secret_version.app.secret_string
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T015")
    assert len(f) == 1


def test_t015_token_output_sensitive_true_clean():
    src = """
output "auth_token" {
  value     = aws_cognito_user_pool_client.app.client_secret
  sensitive = true
}
"""
    assert "PROOFCTL-TF-T015" not in _ids(_checker.check(_P, src))


def test_t015_non_sensitive_output_name_clean():
    src = """
output "vpc_id" {
  value = aws_vpc.main.id
}
"""
    assert "PROOFCTL-TF-T015" not in _ids(_checker.check(_P, src))


def test_t015_key_output_not_sensitive():
    src = """
output "encryption_key" {
  value = aws_kms_key.main.arn
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T015")
    assert len(f) == 1


def test_t015_key_age_days_is_not_sensitive():
    """max_key_age_days is a numeric duration, not a sensitive value (FP regression)."""
    src = """
output "max_key_age_days" {
  value = 90
}
"""
    assert "PROOFCTL-TF-T015" not in _ids(_checker.check(_P, src))


def test_t015_key_count_is_not_sensitive():
    src = """
output "key_rotation_days" {
  value = 30
}
"""
    assert "PROOFCTL-TF-T015" not in _ids(_checker.check(_P, src))


def test_t015_key_name_still_fires():
    """Output 'key_name' references a key resource — should still be flagged."""
    src = """
output "kms_key_name" {
  value = google_kms_crypto_key.main.name
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T015")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Test-fixture path skip: T009 / T012 / T014 must NOT fire in test/fixture dirs
# ══════════════════════════════════════════════════════════════════════════════


def test_t009_skipped_in_test_dir():
    src = 'output "x" {\n  value = "y"\n}\n'
    p = Path("modules/network/test/setup/outputs.tf")
    assert "PROOFCTL-TF-T009" not in _ids(_checker.check(p, src))


def test_t009_skipped_in_fixtures_dir():
    src = 'variable "v" {\n  type = string\n}\n'
    p = Path("test/fixtures/simple/main.tf")
    assert "PROOFCTL-TF-T009" not in _ids(_checker.check(p, src))


def test_t009_still_fires_in_normal_dir():
    src = 'variable "v" {\n  type = string\n}\n'
    p = Path("modules/network/main.tf")
    f = _find(_checker.check(p, src), "PROOFCTL-TF-T009")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO  # demoted from WARNING


def test_t012_skipped_in_test_fixtures():
    src = 'module "x" {\n  source = "../../../examples/foo"\n}\n'
    p = Path("test/fixtures/foo/main.tf")
    assert "PROOFCTL-TF-T012" not in _ids(_checker.check(p, src))


def test_t012_still_fires_outside_test_dirs():
    src = 'module "x" {\n  source = "../../../examples/foo"\n}\n'
    p = Path("modules/eks/main.tf")
    assert "PROOFCTL-TF-T012" in _ids(_checker.check(p, src))


def test_t014_file_level_does_not_fire():
    """T014 moved to dir-level — file-level returns nothing."""
    src = 'resource "aws_vpc" "v" {\n  cidr_block = "10.0.0.0/16"\n}\n'
    p = Path("modules/network/main.tf")
    assert "PROOFCTL-TF-T014" not in _ids(_checker.check(p, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A015 — AWS KMS key rotation not enabled
# ══════════════════════════════════════════════════════════════════════════════


def test_a015_kms_no_rotation_attribute_fires():
    src = """
resource "aws_kms_key" "logs" {
  description             = "log key"
  deletion_window_in_days = 7
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A015")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a015_kms_rotation_false_fires():
    src = """
resource "aws_kms_key" "logs" {
  description           = "log key"
  enable_key_rotation   = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A015")
    assert len(f) == 1


def test_a015_kms_rotation_true_clean():
    src = """
resource "aws_kms_key" "logs" {
  description           = "log key"
  enable_key_rotation   = true
}
"""
    assert "PROOFCTL-TF-A015" not in _ids(_checker.check(_P, src))


def test_a015_alias_not_flagged():
    src = """
resource "aws_kms_alias" "logs" {
  name          = "alias/logs"
  target_key_id = "abc"
}
"""
    assert "PROOFCTL-TF-A015" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A016 — AWS IAM policy with wildcard Action / Resource
# ══════════════════════════════════════════════════════════════════════════════


def test_a016_user_policy_wildcard_resource():
    src = '''
resource "aws_iam_user_policy" "bad" {
  name = "excess"
  user = "x"
  policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [{
    "Action": ["ec2:*", "s3:*"],
    "Effect": "Allow",
    "Resource": "*"
  }]
}
EOF
}
'''
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A016")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert 'Resource = "*"' in f[0].message


def test_a016_role_policy_wildcard_action_list():
    src = '''
resource "aws_iam_role_policy" "bad" {
  name = "x"
  role = "y"
  policy = <<EOF
{ "Statement": [{ "Action": ["*"], "Resource": "arn:aws:s3:::known" }] }
EOF
}
'''
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A016")
    assert len(f) == 1
    assert 'Action = "*"' in f[0].message


def test_a016_role_policy_wildcard_action_str():
    src = '''
resource "aws_iam_policy" "bad" {
  name   = "x"
  policy = <<EOF
{ "Statement": [{ "Action": "*", "Resource": "arn:aws:s3:::known" }] }
EOF
}
'''
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A016")
    assert len(f) == 1


def test_a016_scoped_policy_clean():
    src = '''
resource "aws_iam_role_policy" "ok" {
  name = "x"
  role = "y"
  policy = <<EOF
{ "Statement": [{ "Action": ["s3:GetObject"], "Resource": "arn:aws:s3:::data/*" }] }
EOF
}
'''
    assert "PROOFCTL-TF-A016" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G019 — GCS versioning not enabled (absent or explicit false)
# ══════════════════════════════════════════════════════════════════════════════


def test_g019_versioning_absent_fires():
    """Bucket with no versioning block should be flagged (CKV_GCP_78 parity)."""
    src = """
resource "google_storage_bucket" "bad" {
  name     = "my-bucket"
  location = "US"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G019")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g019_versioning_enabled_false_fires():
    src = """
resource "google_storage_bucket" "bad" {
  name     = "my-bucket"
  location = "US"
  versioning {
    enabled = false
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G019")
    assert len(f) == 1


def test_g019_versioning_enabled_true_clean():
    src = """
resource "google_storage_bucket" "ok" {
  name     = "my-bucket"
  location = "US"
  versioning {
    enabled = true
  }
}
"""
    assert "PROOFCTL-TF-G019" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G027 — Cloud Function Gen2 with ALLOW_ALL ingress
# ══════════════════════════════════════════════════════════════════════════════


def test_g027_gen2_allow_all_in_service_config():
    src = """
resource "google_cloudfunctions2_function" "bad" {
  name     = "my-func"
  location = "us-central1"
  service_config {
    ingress_settings = "ALLOW_ALL"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G027")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g027_gen2_internal_only_clean():
    src = """
resource "google_cloudfunctions2_function" "ok" {
  name     = "my-func"
  location = "us-central1"
  service_config {
    ingress_settings = "ALLOW_INTERNAL_ONLY"
  }
}
"""
    assert "PROOFCTL-TF-G027" not in _ids(_checker.check(_P, src))


def test_g027_gen2_no_ingress_setting_clean():
    # Absent = not explicitly ALLOW_ALL — not flagged
    src = """
resource "google_cloudfunctions2_function" "neutral" {
  name     = "my-func"
  location = "us-central1"
  service_config {
    max_instance_count = 3
  }
}
"""
    assert "PROOFCTL-TF-G027" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G032 — GCS bucket access logging not configured
# ══════════════════════════════════════════════════════════════════════════════


def test_g032_bucket_no_logging():
    """Bucket without logging block should be flagged (CKV_GCP_62 parity)."""
    src = """
resource "google_storage_bucket" "bad" {
  name     = "my-bucket"
  location = "US"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G032")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g032_bucket_with_logging_clean():
    src = """
resource "google_storage_bucket" "ok" {
  name     = "my-bucket"
  location = "US"
  logging {
    log_bucket = "my-log-bucket"
  }
}
"""
    assert "PROOFCTL-TF-G032" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G033 — Subnetwork private_ip_google_access not enabled
# ══════════════════════════════════════════════════════════════════════════════


def test_g033_subnet_no_private_google_access():
    """Subnet without private_ip_google_access should be flagged (CKV_GCP_74 parity)."""
    src = """
resource "google_compute_subnetwork" "bad" {
  name          = "my-subnet"
  ip_cidr_range = "10.0.0.0/24"
  region        = "us-central1"
  network       = "default"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G033")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g033_subnet_explicit_false():
    src = """
resource "google_compute_subnetwork" "bad" {
  name                     = "my-subnet"
  ip_cidr_range            = "10.0.0.0/24"
  region                   = "us-central1"
  network                  = "default"
  private_ip_google_access = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G033")
    assert len(f) == 1


def test_g033_subnet_enabled_clean():
    src = """
resource "google_compute_subnetwork" "ok" {
  name                     = "my-subnet"
  ip_cidr_range            = "10.0.0.0/24"
  region                   = "us-central1"
  network                  = "default"
  private_ip_google_access = true
}
"""
    assert "PROOFCTL-TF-G033" not in _ids(_checker.check(_P, src))


def test_g033_proxy_subnet_not_flagged():
    """INTERNAL_HTTPS_LOAD_BALANCER subnets don't support private_ip_google_access."""
    src = """
resource "google_compute_subnetwork" "proxy" {
  name          = "proxy-subnet"
  ip_cidr_range = "10.0.1.0/24"
  purpose       = "INTERNAL_HTTPS_LOAD_BALANCER"
  network       = "default"
}
"""
    assert "PROOFCTL-TF-G033" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A017 — RDS storage_encrypted not true
# ══════════════════════════════════════════════════════════════════════════════


def test_a017_db_instance_unencrypted():
    src = """
resource "aws_db_instance" "bad" {
  storage_encrypted = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A017")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a017_cluster_encrypted_clean():
    src = """
resource "aws_rds_cluster" "ok" {
  storage_encrypted = true
}
"""
    assert "PROOFCTL-TF-A017" not in _ids(_checker.check(_P, src))


def test_a017_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" {
  bucket = "x"
}
"""
    assert "PROOFCTL-TF-A017" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A018 — RDS using default KMS key
# ══════════════════════════════════════════════════════════════════════════════


def test_a018_no_kms_key_id():
    src = """
resource "aws_db_instance" "bad" {
  storage_encrypted = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A018")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a018_with_kms_key_id_clean():
    src = """
resource "aws_rds_cluster" "ok" {
  storage_encrypted = true
  kms_key_id        = "arn:aws:kms:us-east-1:111:key/abc"
}
"""
    assert "PROOFCTL-TF-A018" not in _ids(_checker.check(_P, src))


def test_a018_storage_encrypted_false_skipped():
    # When storage_encrypted = false, A017 fires; A018 should not duplicate.
    src = """
resource "aws_db_instance" "bad" {
  storage_encrypted = false
}
"""
    assert "PROOFCTL-TF-A018" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A019 — RDS IAM auth not enabled
# ══════════════════════════════════════════════════════════════════════════════


def test_a019_no_iam_auth():
    src = """
resource "aws_db_instance" "bad" {
  storage_encrypted = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A019")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a019_iam_auth_enabled_clean():
    src = """
resource "aws_db_instance" "ok" {
  storage_encrypted                   = true
  iam_database_authentication_enabled = true
}
"""
    assert "PROOFCTL-TF-A019" not in _ids(_checker.check(_P, src))


def test_a019_cluster_not_flagged():
    # A019 only applies to aws_db_instance.
    src = """
resource "aws_rds_cluster" "c" {
  storage_encrypted = true
}
"""
    assert "PROOFCTL-TF-A019" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A020 — RDS deletion_protection disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_a020_deletion_protection_false():
    src = """
resource "aws_db_instance" "bad" {
  deletion_protection = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A020")
    assert len(f) == 1


def test_a020_deletion_protection_true_clean():
    src = """
resource "aws_rds_cluster" "ok" {
  deletion_protection = true
}
"""
    assert "PROOFCTL-TF-A020" not in _ids(_checker.check(_P, src))


def test_a020_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" {
  bucket = "x"
}
"""
    assert "PROOFCTL-TF-A020" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A021 — RDS backup_retention_period missing or zero
# ══════════════════════════════════════════════════════════════════════════════


def test_a021_no_backup_retention():
    src = """
resource "aws_db_instance" "bad" {
  storage_encrypted = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A021")
    assert len(f) == 1


def test_a021_zero_retention_flagged():
    src = """
resource "aws_rds_cluster" "bad" {
  backup_retention_period = 0
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A021")
    assert len(f) == 1


def test_a021_seven_days_clean():
    src = """
resource "aws_db_instance" "ok" {
  backup_retention_period = 7
}
"""
    assert "PROOFCTL-TF-A021" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A022 — RDS publicly_accessible
# ══════════════════════════════════════════════════════════════════════════════


def test_a022_publicly_accessible_true():
    src = """
resource "aws_db_instance" "bad" {
  publicly_accessible = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A022")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a022_publicly_accessible_false_clean():
    src = """
resource "aws_db_instance" "ok" {
  publicly_accessible = false
}
"""
    assert "PROOFCTL-TF-A022" not in _ids(_checker.check(_P, src))


def test_a022_irrelevant_resource():
    src = """
resource "aws_instance" "vm" {
  ami = "ami-1"
}
"""
    assert "PROOFCTL-TF-A022" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A023 — Aurora cluster missing CW logs export
# ══════════════════════════════════════════════════════════════════════════════


def test_a023_no_logs_exports():
    src = """
resource "aws_rds_cluster" "bad" {
  storage_encrypted = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A023")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_a023_logs_exports_set_clean():
    src = """
resource "aws_rds_cluster" "ok" {
  enabled_cloudwatch_logs_exports = ["audit", "error"]
}
"""
    assert "PROOFCTL-TF-A023" not in _ids(_checker.check(_P, src))


def test_a023_db_instance_not_flagged():
    # A023 only applies to aws_rds_cluster (Aurora).
    src = """
resource "aws_db_instance" "x" {
  storage_encrypted = true
}
"""
    assert "PROOFCTL-TF-A023" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G034 — Legacy ABAC not explicitly disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_g034_no_legacy_abac_attr():
    src = """
resource "google_container_cluster" "c" {
  name     = "demo"
  location = "us-central1"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G034")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g034_explicit_false_clean():
    src = """
resource "google_container_cluster" "c" {
  enable_legacy_abac = false
}
"""
    assert "PROOFCTL-TF-G034" not in _ids(_checker.check(_P, src))


def test_g034_irrelevant_resource():
    src = """
resource "google_compute_instance" "vm" {
  name = "x"
}
"""
    assert "PROOFCTL-TF-G034" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G035 — GKE private nodes not enabled
# ══════════════════════════════════════════════════════════════════════════════


def test_g035_no_private_cluster_config():
    src = """
resource "google_container_cluster" "c" {
  name = "demo"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G035")
    assert len(f) == 1


def test_g035_private_nodes_true_clean():
    src = """
resource "google_container_cluster" "c" {
  private_cluster_config {
    enable_private_nodes = true
  }
}
"""
    assert "PROOFCTL-TF-G035" not in _ids(_checker.check(_P, src))


def test_g035_irrelevant_resource():
    src = """
resource "google_storage_bucket" "b" {
  name = "x"
}
"""
    assert "PROOFCTL-TF-G035" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G036 — GKE legacy metadata endpoints reachable
# ══════════════════════════════════════════════════════════════════════════════


def test_g036_no_metadata():
    src = """
resource "google_container_cluster" "c" {
  name = "demo"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G036")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g036_endpoints_disabled_clean():
    src = """
resource "google_container_node_pool" "np" {
  node_config {
    metadata = {
      disable-legacy-endpoints = "true"
    }
  }
}
"""
    assert "PROOFCTL-TF-G036" not in _ids(_checker.check(_P, src))


def test_g036_irrelevant_resource():
    src = """
resource "google_compute_disk" "d" {
  name = "x"
}
"""
    assert "PROOFCTL-TF-G036" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G037 — GKE node shielded config incomplete
# ══════════════════════════════════════════════════════════════════════════════


def test_g037_no_shielded_config():
    src = """
resource "google_container_node_pool" "np" {
  name = "p1"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G037")
    assert len(f) == 1


def test_g037_full_shielded_clean():
    src = """
resource "google_container_node_pool" "np" {
  node_config {
    shielded_instance_config {
      enable_secure_boot          = true
      enable_integrity_monitoring = true
    }
    metadata = {
      disable-legacy-endpoints = "true"
    }
    service_account = "dedicated@proj.iam.gserviceaccount.com"
  }
}
"""
    assert "PROOFCTL-TF-G037" not in _ids(_checker.check(_P, src))


def test_g037_irrelevant_resource():
    src = """
resource "aws_instance" "vm" {
  ami = "ami-1"
}
"""
    assert "PROOFCTL-TF-G037" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G038 — GKE release_channel not pinned
# ══════════════════════════════════════════════════════════════════════════════


def test_g038_no_release_channel():
    src = """
resource "google_container_cluster" "c" {
  name = "demo"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G038")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_g038_regular_channel_clean():
    src = """
resource "google_container_cluster" "c" {
  release_channel {
    channel = "REGULAR"
  }
}
"""
    assert "PROOFCTL-TF-G038" not in _ids(_checker.check(_P, src))


def test_g038_irrelevant_resource():
    src = """
resource "google_storage_bucket" "b" {
  name = "x"
}
"""
    assert "PROOFCTL-TF-G038" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G040 — GKE shielded nodes not enabled
# ══════════════════════════════════════════════════════════════════════════════


def test_g040_no_shielded_nodes_attr():
    src = """
resource "google_container_cluster" "c" {
  name = "demo"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G040")
    assert len(f) == 1


def test_g040_shielded_nodes_true_clean():
    src = """
resource "google_container_cluster" "c" {
  enable_shielded_nodes = true
}
"""
    assert "PROOFCTL-TF-G040" not in _ids(_checker.check(_P, src))


def test_g040_irrelevant_resource():
    src = """
resource "google_compute_network" "n" {
  name = "x"
}
"""
    assert "PROOFCTL-TF-G040" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G041 — GKE node uses default service account
# ══════════════════════════════════════════════════════════════════════════════


def test_g041_default_sa_string():
    src = """
resource "google_container_node_pool" "np" {
  node_config {
    service_account = "default"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G041")
    assert len(f) == 1


def test_g041_dedicated_sa_clean():
    src = """
resource "google_container_node_pool" "np" {
  node_config {
    service_account = "gke-nodes@proj.iam.gserviceaccount.com"
  }
}
"""
    assert "PROOFCTL-TF-G041" not in _ids(_checker.check(_P, src))


def test_g041_irrelevant_resource():
    src = """
resource "aws_instance" "vm" {
  ami = "ami-1"
}
"""
    assert "PROOFCTL-TF-G041" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A016 (extension) — data "aws_iam_policy_document" wildcards
# ══════════════════════════════════════════════════════════════════════════════


def test_a016_data_policy_document_wildcard_actions():
    src = """
data "aws_iam_policy_document" "bad" {
  statement {
    actions   = ["*"]
    resources = ["arn:aws:s3:::mybucket"]
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A016")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a016_data_policy_document_wildcard_resources_deny_clean():
    src = """
data "aws_iam_policy_document" "ok" {
  statement {
    effect    = "Deny"
    actions   = ["*"]
    resources = ["*"]
  }
}
"""
    assert "PROOFCTL-TF-A016" not in _ids(_checker.check(_P, src))


def test_a016_data_policy_document_scoped_clean():
    src = """
data "aws_iam_policy_document" "ok" {
  statement {
    actions   = ["s3:GetObject"]
    resources = ["arn:aws:s3:::mybucket/*"]
  }
}
"""
    assert "PROOFCTL-TF-A016" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A024 — Public ingress on sensitive ports
# ══════════════════════════════════════════════════════════════════════════════


def test_a024_sg_rule_public_ssh():
    src = """
resource "aws_security_group_rule" "bad" {
  type        = "ingress"
  from_port   = 22
  to_port     = 22
  protocol    = "tcp"
  cidr_blocks = ["0.0.0.0/0"]
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A024")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a024_inline_ingress_public_rdp():
    src = """
resource "aws_security_group" "bad" {
  name = "x"
  ingress {
    from_port   = 3389
    to_port     = 3389
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A024")
    assert len(f) == 1


def test_a024_internal_ingress_clean():
    src = """
resource "aws_security_group_rule" "ok" {
  type        = "ingress"
  from_port   = 22
  to_port     = 22
  protocol    = "tcp"
  cidr_blocks = ["10.0.0.0/8"]
}
"""
    assert "PROOFCTL-TF-A024" not in _ids(_checker.check(_P, src))


def test_a024_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" {
  bucket = "x"
}
"""
    assert "PROOFCTL-TF-A024" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A025 — EKS public endpoint open to internet
# ══════════════════════════════════════════════════════════════════════════════


def test_a025_eks_public_endpoint_open():
    src = """
resource "aws_eks_cluster" "bad" {
  name = "c"
  vpc_config {
    endpoint_public_access = true
    public_access_cidrs    = ["0.0.0.0/0"]
  }
  encryption_config {
    resources = ["secrets"]
    provider { key_arn = "k" }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A025")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a025_eks_restricted_cidrs_clean():
    src = """
resource "aws_eks_cluster" "ok" {
  name = "c"
  vpc_config {
    endpoint_public_access = true
    public_access_cidrs    = ["1.2.3.4/32"]
  }
  encryption_config {
    resources = ["secrets"]
    provider { key_arn = "k" }
  }
}
"""
    assert "PROOFCTL-TF-A025" not in _ids(_checker.check(_P, src))


def test_a025_irrelevant_resource():
    src = """
resource "aws_instance" "vm" { ami = "ami-1" }
"""
    assert "PROOFCTL-TF-A025" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A027 — Neptune storage encryption
# ══════════════════════════════════════════════════════════════════════════════


def test_a027_neptune_unencrypted():
    src = """
resource "aws_neptune_cluster" "bad" {
  cluster_identifier = "x"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A027")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a027_neptune_encrypted_clean():
    src = """
resource "aws_neptune_cluster" "ok" {
  cluster_identifier = "x"
  storage_encrypted  = true
}
"""
    assert "PROOFCTL-TF-A027" not in _ids(_checker.check(_P, src))


def test_a027_irrelevant_resource():
    src = """
resource "aws_db_instance" "x" { engine = "mysql" }
"""
    assert "PROOFCTL-TF-A027" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A029 — DynamoDB SSE
# ══════════════════════════════════════════════════════════════════════════════


def test_a029_dynamodb_no_sse():
    src = """
resource "aws_dynamodb_table" "bad" {
  name = "t"
  hash_key = "id"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A029")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_a029_dynamodb_sse_enabled_clean():
    src = """
resource "aws_dynamodb_table" "ok" {
  name = "t"
  hash_key = "id"
  server_side_encryption {
    enabled = true
  }
}
"""
    assert "PROOFCTL-TF-A029" not in _ids(_checker.check(_P, src))


def test_a029_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" { bucket = "x" }
"""
    assert "PROOFCTL-TF-A029" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A030 — ElastiCache at-rest encryption
# ══════════════════════════════════════════════════════════════════════════════


def test_a030_elasticache_no_at_rest_encryption():
    src = """
resource "aws_elasticache_replication_group" "bad" {
  replication_group_id = "x"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A030")
    assert len(f) == 1


def test_a030_elasticache_at_rest_encrypted_clean():
    src = """
resource "aws_elasticache_replication_group" "ok" {
  replication_group_id        = "x"
  at_rest_encryption_enabled  = true
}
"""
    assert "PROOFCTL-TF-A030" not in _ids(_checker.check(_P, src))


def test_a030_irrelevant_resource():
    src = """
resource "aws_db_instance" "x" { engine = "mysql" }
"""
    assert "PROOFCTL-TF-A030" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A031 — SQS/SNS KMS encryption
# ══════════════════════════════════════════════════════════════════════════════


def test_a031_sqs_no_kms():
    src = """
resource "aws_sqs_queue" "bad" {
  name = "q"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A031")
    assert len(f) == 1


def test_a031_sns_with_kms_clean():
    src = """
resource "aws_sns_topic" "ok" {
  name              = "t"
  kms_master_key_id = "alias/aws/sns"
}
"""
    assert "PROOFCTL-TF-A031" not in _ids(_checker.check(_P, src))


def test_a031_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" { bucket = "x" }
"""
    assert "PROOFCTL-TF-A031" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A034 — Policy directly on user
# ══════════════════════════════════════════════════════════════════════════════


def test_a034_user_policy_attachment():
    src = """
resource "aws_iam_user_policy_attachment" "bad" {
  user       = "alice"
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A034")
    assert len(f) == 1


def test_a034_group_policy_attachment_clean():
    src = """
resource "aws_iam_group_policy_attachment" "ok" {
  group      = "devs"
  policy_arn = "arn:aws:iam::aws:policy/ReadOnlyAccess"
}
"""
    assert "PROOFCTL-TF-A034" not in _ids(_checker.check(_P, src))


def test_a034_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" { bucket = "x" }
"""
    assert "PROOFCTL-TF-A034" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A035 — Wildcard Principal in assume_role_policy
# ══════════════════════════════════════════════════════════════════════════════


def test_a035_role_wildcard_principal():
    src = '''
resource "aws_iam_role" "bad" {
  name = "r"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      "Principal" : "*"
      Action = "sts:AssumeRole"
    }]
  })
}
'''
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A035")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a035_role_scoped_principal_clean():
    src = '''
resource "aws_iam_role" "ok" {
  name = "r"
  assume_role_policy = jsonencode({
    Statement = [{
      Effect = "Allow"
      "Principal" : { "Service" : "ec2.amazonaws.com" }
      Action = "sts:AssumeRole"
    }]
  })
}
'''
    assert "PROOFCTL-TF-A035" not in _ids(_checker.check(_P, src))


def test_a035_irrelevant_resource():
    src = """
resource "aws_iam_user" "u" { name = "x" }
"""
    assert "PROOFCTL-TF-A035" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A036 — CloudTrail log file validation
# ══════════════════════════════════════════════════════════════════════════════


def test_a036_cloudtrail_no_log_validation():
    src = """
resource "aws_cloudtrail" "bad" {
  name           = "t"
  s3_bucket_name = "x"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A036")
    assert len(f) == 1


def test_a036_cloudtrail_validated_clean():
    src = """
resource "aws_cloudtrail" "ok" {
  name                          = "t"
  s3_bucket_name                = "x"
  enable_log_file_validation    = true
}
"""
    assert "PROOFCTL-TF-A036" not in _ids(_checker.check(_P, src))


def test_a036_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" { bucket = "x" }
"""
    assert "PROOFCTL-TF-A036" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A037 — CloudTrail multi-region
# ══════════════════════════════════════════════════════════════════════════════


def test_a037_cloudtrail_single_region():
    src = """
resource "aws_cloudtrail" "bad" {
  name           = "t"
  s3_bucket_name = "x"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A037")
    assert len(f) == 1


def test_a037_cloudtrail_multi_region_clean():
    src = """
resource "aws_cloudtrail" "ok" {
  name                  = "t"
  s3_bucket_name        = "x"
  is_multi_region_trail = true
}
"""
    assert "PROOFCTL-TF-A037" not in _ids(_checker.check(_P, src))


def test_a037_irrelevant_resource():
    src = """
resource "aws_s3_bucket" "b" { bucket = "x" }
"""
    assert "PROOFCTL-TF-A037" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-A038 — Default SG with rules
# ══════════════════════════════════════════════════════════════════════════════


def test_a038_default_sg_with_rules():
    src = """
resource "aws_default_security_group" "bad" {
  vpc_id = "vpc-1"
  ingress {
    from_port = 0
    to_port   = 65535
    protocol  = "-1"
    self      = true
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A038")
    assert len(f) == 1


def test_a038_default_sg_empty_clean():
    src = """
resource "aws_default_security_group" "ok" {
  vpc_id = "vpc-1"
}
"""
    assert "PROOFCTL-TF-A038" not in _ids(_checker.check(_P, src))


def test_a038_irrelevant_resource():
    src = """
resource "aws_security_group" "x" { name = "y" }
"""
    assert "PROOFCTL-TF-A038" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G042 — google_compute_firewall public source
# ══════════════════════════════════════════════════════════════════════════════


def test_g042_firewall_public_allow():
    src = """
resource "google_compute_firewall" "bad" {
  name          = "fw"
  network       = "default"
  source_ranges = ["0.0.0.0/0"]
  allow {
    protocol = "tcp"
    ports    = ["22"]
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G042")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g042_firewall_internal_clean():
    src = """
resource "google_compute_firewall" "ok" {
  name          = "fw"
  network       = "default"
  source_ranges = ["10.0.0.0/8"]
  allow {
    protocol = "tcp"
  }
}
"""
    assert "PROOFCTL-TF-G042" not in _ids(_checker.check(_P, src))


def test_g042_firewall_public_deny_clean():
    src = """
resource "google_compute_firewall" "deny_only" {
  name          = "fw"
  network       = "default"
  source_ranges = ["0.0.0.0/0"]
  deny {
    protocol = "tcp"
  }
}
"""
    assert "PROOFCTL-TF-G042" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G043 — Cloud SQL require SSL
# ══════════════════════════════════════════════════════════════════════════════


def test_g043_cloudsql_no_ssl():
    src = """
resource "google_sql_database_instance" "bad" {
  name             = "x"
  database_version = "POSTGRES_14"
  settings {
    tier = "db-f1-micro"
    ip_configuration {
      require_ssl = false
    }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G043")
    assert len(f) == 1


def test_g043_cloudsql_ssl_required_clean():
    src = """
resource "google_sql_database_instance" "ok" {
  name = "x"
  settings {
    ip_configuration {
      require_ssl = true
    }
  }
}
"""
    assert "PROOFCTL-TF-G043" not in _ids(_checker.check(_P, src))


def test_g043_irrelevant_resource():
    src = """
resource "google_storage_bucket" "b" { name = "x" location = "US" }
"""
    assert "PROOFCTL-TF-G043" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G044 — Cloud SQL authorized_networks 0.0.0.0/0
# ══════════════════════════════════════════════════════════════════════════════


def test_g044_cloudsql_open_internet():
    src = """
resource "google_sql_database_instance" "bad" {
  name = "x"
  settings {
    ip_configuration {
      authorized_networks {
        name  = "all"
        value = "0.0.0.0/0"
      }
    }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G044")
    assert len(f) == 1


def test_g044_cloudsql_restricted_clean():
    src = """
resource "google_sql_database_instance" "ok" {
  name = "x"
  settings {
    ip_configuration {
      authorized_networks {
        name  = "office"
        value = "1.2.3.4/32"
      }
    }
  }
}
"""
    assert "PROOFCTL-TF-G044" not in _ids(_checker.check(_P, src))


def test_g044_irrelevant_resource():
    src = """
resource "google_storage_bucket" "b" { name = "x" location = "US" }
"""
    assert "PROOFCTL-TF-G044" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G045 — can_ip_forward
# ══════════════════════════════════════════════════════════════════════════════


def test_g045_compute_can_ip_forward():
    src = """
resource "google_compute_instance" "bad" {
  name           = "vm"
  machine_type   = "n1-standard-1"
  can_ip_forward = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G045")
    assert len(f) == 1


def test_g045_compute_no_ip_forward_clean():
    src = """
resource "google_compute_instance" "ok" {
  name           = "vm"
  machine_type   = "n1-standard-1"
  can_ip_forward = false
}
"""
    assert "PROOFCTL-TF-G045" not in _ids(_checker.check(_P, src))


def test_g045_irrelevant_resource():
    src = """
resource "aws_instance" "vm" { ami = "ami-1" }
"""
    assert "PROOFCTL-TF-G045" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-G046 — Compute instance with public IP
# ══════════════════════════════════════════════════════════════════════════════


def test_g046_compute_public_ip():
    src = """
resource "google_compute_instance" "bad" {
  name         = "vm"
  machine_type = "n1-standard-1"
  network_interface {
    network = "default"
    access_config {
    }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G046")
    assert len(f) == 1


def test_g046_compute_private_only_clean():
    src = """
resource "google_compute_instance" "ok" {
  name         = "vm"
  machine_type = "n1-standard-1"
  network_interface {
    network = "default"
  }
}
"""
    assert "PROOFCTL-TF-G046" not in _ids(_checker.check(_P, src))


def test_g046_irrelevant_resource():
    src = """
resource "aws_instance" "vm" { ami = "ami-1" }
"""
    assert "PROOFCTL-TF-G046" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ013 — NSG inbound from internet on sensitive port
# ══════════════════════════════════════════════════════════════════════════════


def test_az013_nsr_open_ssh():
    src = """
resource "azurerm_network_security_rule" "bad" {
  name                       = "ssh"
  direction                  = "Inbound"
  access                     = "Allow"
  protocol                   = "Tcp"
  source_port_range          = "*"
  destination_port_range     = "22"
  source_address_prefix      = "*"
  destination_address_prefix = "*"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ013")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_az013_nsg_inline_rule_open_rdp():
    src = """
resource "azurerm_network_security_group" "bad" {
  name = "n"
  security_rule {
    name                       = "rdp"
    direction                  = "Inbound"
    access                     = "Allow"
    protocol                   = "Tcp"
    source_port_range          = "*"
    destination_port_range     = "3389"
    source_address_prefix      = "Internet"
    destination_address_prefix = "*"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ013")
    assert len(f) == 1


def test_az013_internal_inbound_clean():
    src = """
resource "azurerm_network_security_rule" "ok" {
  name                       = "ssh-int"
  direction                  = "Inbound"
  access                     = "Allow"
  protocol                   = "Tcp"
  source_port_range          = "*"
  destination_port_range     = "22"
  source_address_prefix      = "10.0.0.0/8"
  destination_address_prefix = "*"
}
"""
    assert "PROOFCTL-TF-AZ013" not in _ids(_checker.check(_P, src))


def test_az013_irrelevant_resource():
    src = """
resource "azurerm_storage_account" "x" { name = "y" }
"""
    assert "PROOFCTL-TF-AZ013" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# TF-AZ014 — Managed disk CMK
# ══════════════════════════════════════════════════════════════════════════════


def test_az014_managed_disk_no_cmk():
    src = """
resource "azurerm_managed_disk" "bad" {
  name                 = "d"
  storage_account_type = "Premium_LRS"
  create_option        = "Empty"
  disk_size_gb         = 32
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-AZ014")
    assert len(f) == 1


def test_az014_managed_disk_with_des_clean():
    src = """
resource "azurerm_managed_disk" "ok" {
  name                   = "d"
  storage_account_type   = "Premium_LRS"
  create_option          = "Empty"
  disk_size_gb           = 32
  disk_encryption_set_id = "/subscriptions/.../diskEncryptionSets/des1"
}
"""
    assert "PROOFCTL-TF-AZ014" not in _ids(_checker.check(_P, src))


def test_az014_irrelevant_resource():
    src = """
resource "azurerm_storage_account" "x" { name = "y" }
"""
    assert "PROOFCTL-TF-AZ014" not in _ids(_checker.check(_P, src))
