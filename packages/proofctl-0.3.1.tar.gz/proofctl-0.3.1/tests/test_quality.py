from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.quality import QualityChecker
from proofctl.models import Severity


def _check(source: str, any_threshold: int = 3) -> list:
    path = Path("test.py")
    try:
        tree = ast.parse(source)
    except SyntaxError:
        tree = None
    return QualityChecker(any_threshold=any_threshold).check(path, source, tree)


def _rules(source: str, **kw) -> set[str]:
    return {f.rule_id for f in _check(source, **kw)}


# ── Q-001 Mutable default ─────────────────────────────────────────────────────

def test_q001_list_default():
    assert "PROOFCTL-Q-001" in _rules("def f(x=[]): pass\n")


def test_q001_dict_default():
    assert "PROOFCTL-Q-001" in _rules("def f(x={}): pass\n")


def test_q001_set_default():
    assert "PROOFCTL-Q-001" in _rules("def f(x=set()): pass\n")


def test_q001_call_mutable_default():
    assert "PROOFCTL-Q-001" in _rules("def f(x=list()): pass\n")


def test_q001_none_default_ok():
    assert "PROOFCTL-Q-001" not in _rules("def f(x=None): pass\n")


def test_q001_immutable_default_ok():
    assert "PROOFCTL-Q-001" not in _rules('def f(x="hello"): pass\n')


def test_q001_int_default_ok():
    assert "PROOFCTL-Q-001" not in _rules("def f(x=0): pass\n")


def test_q001_is_error():
    findings = [f for f in _check("def f(x=[]): pass\n") if f.rule_id == "PROOFCTL-Q-001"]
    assert findings[0].severity == Severity.ERROR


def test_q001_fixable():
    findings = [f for f in _check("def f(x=[]): pass\n") if f.rule_id == "PROOFCTL-Q-001"]
    assert findings[0].fixable is True


def test_q001_async_function():
    assert "PROOFCTL-Q-001" in _rules("async def f(x=[]): pass\n")


# ── Q-002 Broad except ────────────────────────────────────────────────────────

def test_q002_bare_except():
    src = "try:\n    x()\nexcept:\n    pass\n"
    assert "PROOFCTL-Q-002" in _rules(src)


def test_q002_bare_except_is_error():
    src = "try:\n    x()\nexcept:\n    pass\n"
    findings = [f for f in _check(src) if f.rule_id == "PROOFCTL-Q-002"]
    assert findings[0].severity == Severity.ERROR


def test_q002_broad_exception_with_pass():
    src = "try:\n    x()\nexcept Exception:\n    pass\n"
    assert "PROOFCTL-Q-002" in _rules(src)


def test_q002_broad_with_reraise_ok():
    src = (
        "try:\n"
        "    x()\n"
        "except Exception as e:\n"
        "    logger.error(e)\n"
        "    raise\n"
    )
    assert "PROOFCTL-Q-002" not in _rules(src)


def test_q002_specific_exception_ok():
    src = "try:\n    x()\nexcept ValueError as e:\n    handle(e)\n"
    assert "PROOFCTL-Q-002" not in _rules(src)


def test_q002_multiple_specific_ok():
    src = "try:\n    x()\nexcept (ValueError, KeyError):\n    pass\n"
    assert "PROOFCTL-Q-002" not in _rules(src)


# ── Q-003 Any overuse ─────────────────────────────────────────────────────────

def test_q003_any_over_threshold():
    src = (
        "from typing import Any\n"
        "def f(x: Any, y: Any) -> Any:\n"
        "    z: Any = x\n"
        "    return z\n"
    )
    assert "PROOFCTL-Q-003" in _rules(src, any_threshold=3)


def test_q003_any_under_threshold_ok():
    src = "from typing import Any\ndef f(x: Any): pass\n"
    assert "PROOFCTL-Q-003" not in _rules(src, any_threshold=3)


def test_q003_type_ignore_without_reason():
    src = "x = bad_import()  # type: ignore\n"
    assert "PROOFCTL-Q-003" in _rules(src)


def test_q003_type_ignore_with_code_ok():
    src = "x = bad_import()  # type: ignore[import-untyped]\n"
    assert "PROOFCTL-Q-003" not in _rules(src)


def test_q003_type_ignore_with_comment_ok():
    src = "x = bad_import()  # type: ignore  # external lib has no stubs\n"
    assert "PROOFCTL-Q-003" not in _rules(src)
