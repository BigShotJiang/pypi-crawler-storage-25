"""Regression tests for AUDIT_AND_ROADMAP Phase 5 — placeholders/leakage/variants.

Covers H-19 (placeholders), H-20 / H-21 (leakage), H-22 (variants).
"""
from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.placeholders import PlaceholderChecker
from proofctl.checkers.leakage import LeakageChecker
from proofctl.checkers.variants import VariantChecker
from proofctl.models import Severity


def _placeholder_findings(src: str) -> list:
    tree = ast.parse(src)
    return PlaceholderChecker().check(Path("test.py"), src, tree)


def _leakage_findings(src: str, **kwargs) -> list:
    tree = ast.parse(src)
    return LeakageChecker(**kwargs).check(Path("test.py"), src, tree)


# ── H-19: P-001 ignores async generators with yield ───────────────────────────

def test_h19_async_generator_with_yield_not_flagged():
    src = (
        "async def stream():\n"
        "    yield 1\n"
    )
    findings = _placeholder_findings(src)
    assert all(f.rule_id != "PROOFCTL-P-001" for f in findings), (
        f"async generator with yield should not be P-001; got {findings}"
    )


def test_h19_async_generator_with_yield_from_not_flagged():
    src = (
        "async def stream(src):\n"
        "    yield from src\n"
    )
    findings = _placeholder_findings(src)
    assert all(f.rule_id != "PROOFCTL-P-001" for f in findings)


def test_h19_async_function_with_pass_still_flagged():
    """Sanity check: an async function that's truly empty still trips P-001."""
    src = (
        "async def todo() -> int:\n"
        "    pass\n"
    )
    findings = _placeholder_findings(src)
    assert any(f.rule_id == "PROOFCTL-P-001" for f in findings), (
        "async def with bare `pass` and concrete return type must still flag"
    )


def test_h19_async_function_yield_in_nested_helper_still_flagged():
    """A `yield` inside a nested helper must NOT make the outer async-def look
    like a generator. The outer function whose only statement is `raise
    NotImplementedError` should still flag P-001 even though a nested
    function contains a `yield`.
    """
    # We use `_contains_yield` directly — _classify_body requires a single
    # statement body so we can't put both `def inner` and `pass` inline.
    # Instead test the helper: it must report False on a function whose only
    # yield is in a nested scope.
    from proofctl.checkers.placeholders import _contains_yield
    src = (
        "async def outer():\n"
        "    def inner():\n"
        "        yield 1\n"
        "    raise NotImplementedError\n"
    )
    tree = ast.parse(src)
    outer = tree.body[0]
    assert isinstance(outer, ast.AsyncFunctionDef)
    assert _contains_yield(outer) is False, (
        "yield in nested helper must not make outer scope a generator"
    )


# ── H-19: typing.overload stubs not flagged ───────────────────────────────────

def test_h19_typing_overload_stub_not_flagged():
    src = (
        "import typing\n"
        "@typing.overload\n"
        "def f(x: int) -> int: ...\n"
        "@typing.overload\n"
        "def f(x: str) -> str: ...\n"
        "def f(x): return x\n"
    )
    findings = _placeholder_findings(src)
    p001 = [f for f in findings if f.rule_id == "PROOFCTL-P-001"]
    assert len(p001) == 0, f"P-001 should skip @typing.overload stubs; got {p001}"


def test_h19_bare_overload_stub_still_supported():
    """Existing behaviour: `from typing import overload; @overload` still skipped."""
    src = (
        "from typing import overload\n"
        "@overload\n"
        "def f(x: int) -> int: ...\n"
        "def f(x): return x\n"
    )
    findings = _placeholder_findings(src)
    p001 = [f for f in findings if f.rule_id == "PROOFCTL-P-001"]
    assert p001 == []


# ── H-20: L-001 .push / .length demoted to INFO by default ────────────────────

def test_h20_l001_push_is_info_by_default():
    src = "x.push(item)\n"
    findings = _leakage_findings(src)
    push_findings = [
        f for f in findings
        if f.rule_id == "PROOFCTL-L-001" and ".push" in f.message
    ]
    assert push_findings, "the .push leakage finding should still be emitted"
    assert all(f.severity == Severity.INFO for f in push_findings), (
        f"by default .push must be INFO; got {[f.severity for f in push_findings]}"
    )


def test_h20_l001_length_is_info_by_default():
    src = "n = obj.length\n"
    findings = _leakage_findings(src)
    length_findings = [
        f for f in findings
        if f.rule_id == "PROOFCTL-L-001" and ".length" in f.message
    ]
    assert length_findings
    assert all(f.severity == Severity.INFO for f in length_findings)


def test_h20_l001_strict_idioms_promotes_to_error():
    src = "x.push(item)\n"
    findings = _leakage_findings(src, l001_strict_idioms=True)
    push_findings = [
        f for f in findings
        if f.rule_id == "PROOFCTL-L-001" and ".push" in f.message
    ]
    assert push_findings
    assert all(f.severity == Severity.ERROR for f in push_findings)


def test_h20_l001_other_idioms_remain_error():
    """`null` / `undefined` (other L-001 sub-rules) must stay ERROR even in
    default mode — only .push and .length are downgraded."""
    src = "x = null\n"
    findings = _leakage_findings(src)
    null_findings = [
        f for f in findings
        if f.rule_id == "PROOFCTL-L-001" and "null" in f.message
    ]
    assert null_findings
    assert all(f.severity == Severity.ERROR for f in null_findings)


# ── H-21: L-002 pair by suffix ────────────────────────────────────────────────

def test_h21_l002_only_fires_on_matched_pairs():
    src = (
        "class C:\n"
        "    def getFoo(self): pass\n"
        "    def setFoo(self, v): pass\n"
        "    def getBar(self): pass\n"
        "    def setBar(self, v): pass\n"
    )
    findings = _leakage_findings(src)
    assert any(f.rule_id == "PROOFCTL-L-002" for f in findings)


def test_h21_l002_does_not_fire_on_unrelated_get_set():
    src = (
        "class C:\n"
        "    def getInfo(self): pass\n"
        "    def setColor(self, v): pass\n"
    )
    findings = _leakage_findings(src)
    assert all(f.rule_id != "PROOFCTL-L-002" for f in findings), (
        "unrelated getInfo + setColor should not trip the Java getter/setter rule"
    )


def test_h21_l002_does_not_fire_on_only_getters():
    """Read-only API (get* without matching set*) should not be flagged as
    Java getter/setter pattern."""
    src = (
        "class C:\n"
        "    def getOne(self): pass\n"
        "    def getTwo(self): pass\n"
        "    def getThree(self): pass\n"
    )
    findings = _leakage_findings(src)
    assert all(f.rule_id != "PROOFCTL-L-002" for f in findings)


def test_h21_l002_requires_at_least_two_pairs():
    """One matched pair on its own is borderline — current behaviour requires
    at least two getter/setter method names (i.e. one full pair)."""
    src = (
        "class C:\n"
        "    def getFoo(self): pass\n"
        "    def setFoo(self, v): pass\n"
    )
    findings = _leakage_findings(src)
    # One matched pair = 2 method names — this is on the threshold and should
    # fire (matches existing test_l002_getter_setter_pair behaviour).
    assert any(f.rule_id == "PROOFCTL-L-002" for f in findings)


# ── H-22: V-002 handles >20 files via hash buckets ────────────────────────────

def test_h22_v002_no_silent_cap_at_20_files(tmp_path):
    """Create 25 nearly-identical files. The original 20-file cap meant
    duplicates past the cap were silently missed."""
    template = (
        "def f():\n"
        "    a = 1\n"
        "    b = 2\n"
        "    c = 3\n"
        "    return a + b + c\n"
    ) * 8  # Make it long enough to clear min_lines=30 default.
    for i in range(25):
        (tmp_path / f"mod{i}.py").write_text(template)
    py_files = list(tmp_path.glob("*.py"))
    findings = VariantChecker().check(tmp_path, py_files)
    flagged_files = {f.file for f in findings if f.rule_id == "PROOFCTL-V-002"}
    # The audit asserts files past index 20 must be eligible to surface.
    last_five_names = {f"mod{i}.py" for i in range(20, 25)}
    surfaced = {Path(p).name for p in flagged_files}
    assert surfaced & last_five_names, (
        f"files past the original 20-cap must be eligible; surfaced={surfaced}"
    )


def test_h22_v002_dissimilar_files_not_flagged(tmp_path):
    """Hash-bucketing must not produce false positives across genuinely
    dissimilar files."""
    a = (
        "def alpha():\n"
        "    " + "\n    ".join(f"x{i} = {i}" for i in range(40)) + "\n"
        "    return x0\n"
    )
    b = (
        "class Beta:\n"
        "    def __init__(self):\n"
        "        " + "\n        ".join(
            f"self.attr_{i} = 'val_{i}_text'" for i in range(40)
        ) + "\n"
    )
    (tmp_path / "alpha.py").write_text(a)
    (tmp_path / "beta.py").write_text(b)
    py_files = list(tmp_path.glob("*.py"))
    findings = VariantChecker().check(tmp_path, py_files)
    v002 = [f for f in findings if f.rule_id == "PROOFCTL-V-002"]
    assert v002 == [], f"genuinely different files must not be flagged; got {v002}"


def test_h22_v002_still_fires_on_two_dupes(tmp_path):
    """Sanity: bucketing must not break the simple 2-file case."""
    template = (
        "def f():\n"
        "    a = 1\n"
        "    b = 2\n"
        "    c = 3\n"
        "    return a + b + c\n"
    ) * 8
    (tmp_path / "one.py").write_text(template)
    (tmp_path / "two.py").write_text(template)
    py_files = list(tmp_path.glob("*.py"))
    findings = VariantChecker().check(tmp_path, py_files)
    v002 = [f for f in findings if f.rule_id == "PROOFCTL-V-002"]
    assert len(v002) >= 1, f"expected at least one V-002 for 2 dupes; got {v002}"
