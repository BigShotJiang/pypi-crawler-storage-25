"""Regression tests for AUDIT_AND_ROADMAP Phase 3 (HCL parser hardening).

Covers:
  C-10: even-backslash check for escaped-quote handling in `_strip_comment`
  C-11: strict heredoc end-marker matching (no `rstrip("-~")`)
  C-12: brace counter respects string state and `${}` interpolations
  C-13: `_t004` port parse handles variable references without crashing
  HCL HIGH: `_v004` URL-decode, `_g004` canonical default-SA, `_ai002` skips comments
  HCL MEDIUM: `_has_lifecycle_attr` strips comments
"""
from __future__ import annotations

from pathlib import Path

import pytest

from proofctl.checkers.hcl_utils import (
    HclBlock,
    _brace_delta,
    _is_escaped,
    _strip_comment,
    parse_blocks,
)
from proofctl.checkers.terraform import TerraformChecker
from proofctl.config import ProofctlConfig
from proofctl.engine import run_check


# ── C-10: escaped-quote handling ──────────────────────────────────────────────

def test_c10_is_escaped_recognises_odd_run():
    # \" — single backslash before quote → escaped
    assert _is_escaped(r'"\""', 2) is True


def test_c10_is_escaped_recognises_even_run():
    # \\" — escaped backslash followed by an unescaped quote → not escaped
    line = r'"\\""'  # opens, escaped backslash, closes, opens again
    # Index 3 is the quote that closes the string after the escaped backslash
    assert _is_escaped(line, 3) is False


def test_c10_strip_comment_does_not_eat_string_with_escaped_backslash():
    """The previous one-char lookback treated the closing quote in
    `password = "my\\\\\\"secret#actualpassword"` as escaped, so `#` looked
    like the start of a comment and tokenisation broke. The fix counts the
    run of backslashes."""
    line = 'password = "my\\\\\\"secret#actualpassword"  # real comment'
    stripped = _strip_comment(line)
    # The `#` inside the string must NOT be treated as a comment start.
    assert "secret#actualpassword" in stripped
    # The trailing real comment IS stripped.
    assert "real comment" not in stripped


def test_c10_strip_comment_simple_escaped_quote_still_works():
    """Sanity: a single `\\"` inside a string keeps the string open."""
    line = 'msg = "say \\"hi\\" please"  # comment'
    stripped = _strip_comment(line)
    assert "comment" not in stripped
    assert 'say \\"hi\\"' in stripped


# ── C-11: heredoc end-marker matching ─────────────────────────────────────────

def test_c11_heredoc_strict_end_only_label_alone_terminates():
    """A line `EOF~~~` must NOT terminate a heredoc opened with `<<EOF`.
    The previous `rstrip("-~")` accepted any line whose stripped suffix
    matched the label."""
    src = '''locals {
  policy = <<EOF
{
  "trailing_tilde_in_body": "EOF~~~"
}
EOF
}
resource "aws_s3_bucket" "after" {
  bucket = "test"
}
'''
    blocks = parse_blocks(src)
    # If the heredoc was prematurely closed at `EOF~~~`, the brace counter
    # would have desynced and we'd lose either the `locals` or the
    # `aws_s3_bucket` block.
    kinds = sorted((b.kind, b.label1) for b in blocks)
    assert ("locals", "") in kinds
    assert ("resource", "aws_s3_bucket") in kinds


def test_c11_indented_heredoc_end_with_leading_whitespace_works():
    """`<<-EOF` form allows the end label to be indented; we must still close it."""
    src = '''locals {
  policy = <<-EOF
    {"hello": "world"}
    EOF
}
resource "aws_s3_bucket" "after" {
  bucket = "x"
}
'''
    blocks = parse_blocks(src)
    kinds = sorted((b.kind, b.label1) for b in blocks)
    assert ("resource", "aws_s3_bucket") in kinds


# ── C-12: brace counter handles ${} interpolations ────────────────────────────

@pytest.mark.parametrize("line,expected", [
    ('a = "x${count.index}y"', 0),         # interpolation inside string
    ('tags = { Name = "x${i}" }', 0),       # block with interpolation
    ('description = "value with } brace"', 0),
    ('foo = bar', 0),
    ('resource "x" "y" {', 1),
    ('}', -1),
    ('resource "x" "y" { foo = "bar" }', 0),  # single-line block
])
def test_c12_brace_delta(line: str, expected: int):
    assert _brace_delta(line) == expected


def test_c12_block_parser_handles_interpolation_in_tags():
    """A nested map with string interpolations was the audit's worry case."""
    src = '''resource "aws_instance" "x" {
  tags = {
    Name = "ec2-${var.env}-app"
    Env  = var.env
  }
}
'''
    blocks = parse_blocks(src)
    assert len(blocks) == 1
    assert blocks[0].kind == "resource"
    assert blocks[0].label2 == "x"


# ── C-13: _t004 port parse stays defensive on variable refs ───────────────────

def test_c13_t004_no_crash_on_variable_port(tmp_path):
    """`from_port = var.ssh_port` must not crash _t004; the rule should
    silently skip blocks where ports aren't literal."""
    (tmp_path / "main.tf").write_text(
        'resource "aws_security_group_rule" "open" {\n'
        '  type        = "ingress"\n'
        '  from_port   = var.ssh_port\n'
        '  to_port     = var.ssh_port\n'
        '  cidr_blocks = ["0.0.0.0/0"]\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    # No PROOFCTL-INTERNAL-001 (would mean a checker crashed).
    assert all(f.rule_id != "PROOFCTL-INTERNAL-001" for f in findings), (
        f"engine crashed: {[(f.rule_id, f.message) for f in findings if f.rule_id == 'PROOFCTL-INTERNAL-001']}"
    )


def test_c13_t004_still_fires_on_literal_sensitive_port(tmp_path):
    """Sanity: a literal sensitive port + 0.0.0.0/0 still triggers T-004."""
    (tmp_path / "main.tf").write_text(
        'resource "aws_security_group_rule" "open" {\n'
        '  type        = "ingress"\n'
        '  from_port   = 22\n'
        '  to_port     = 22\n'
        '  cidr_blocks = ["0.0.0.0/0"]\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert any(f.rule_id == "PROOFCTL-TF-T004" for f in findings)


# ── HCL HIGH: _v004 URL-decode ────────────────────────────────────────────────

def test_v004_percent_encoded_semver_recognised_as_immutable(tmp_path):
    """`?ref=v1%2E2%2E3` must decode to `v1.2.3` and pass the semver check."""
    (tmp_path / "main.tf").write_text(
        'module "x" {\n'
        '  source = "git::https://github.com/foo/bar.git?ref=v1%2E2%2E3"\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert all(f.rule_id != "PROOFCTL-TF-V004" for f in findings), (
        f"V-004 should accept percent-encoded semver; got: {[(f.rule_id, f.message) for f in findings]}"
    )


def test_v004_branch_ref_still_flagged(tmp_path):
    """A branch ref (mutable) is still flagged."""
    (tmp_path / "main.tf").write_text(
        'module "x" {\n'
        '  source = "git::https://github.com/foo/bar.git?ref=main"\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert any(f.rule_id == "PROOFCTL-TF-V004" for f in findings)


# ── HCL HIGH: _g004 canonical default-SA suffix ───────────────────────────────

def test_g004_canonical_default_sa_email_recognised(tmp_path):
    """The fully-qualified default-SA email
    `<projnum>-compute@developer.gserviceaccount.com` must trigger G-004
    when paired with cloud-platform scope."""
    (tmp_path / "main.tf").write_text(
        'resource "google_compute_instance" "x" {\n'
        '  service_account {\n'
        '    email  = "123456-compute@developer.gserviceaccount.com"\n'
        '    scopes = ["cloud-platform"]\n'
        '  }\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert any(f.rule_id == "PROOFCTL-TF-G004" for f in findings)


def test_g004_dedicated_sa_does_not_trigger(tmp_path):
    """A non-default SA email must not fire G-004."""
    (tmp_path / "main.tf").write_text(
        'resource "google_compute_instance" "x" {\n'
        '  service_account {\n'
        '    email  = "my-app-sa@my-project.iam.gserviceaccount.com"\n'
        '    scopes = ["cloud-platform"]\n'
        '  }\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert all(f.rule_id != "PROOFCTL-TF-G004" for f in findings)


# ── HCL HIGH: _ai002 ignores comment lines ────────────────────────────────────

def test_ai002_ignores_aws_region_in_comment(tmp_path):
    """A `# was us-east-1` migration note must not trigger AI-002 inside a
    GCP-context file."""
    (tmp_path / "main.tf").write_text(
        '# Migrated from us-east-1 to us-central1 on 2026-01-15\n'
        'resource "google_compute_instance" "x" {\n'
        '  zone = "us-central1-a"\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert all(f.rule_id != "PROOFCTL-TF-AI-002" for f in findings), (
        f"AI-002 should ignore comments; got: {[(f.rule_id, f.message) for f in findings]}"
    )


def test_ai002_still_fires_on_real_aws_region_in_gcp_file(tmp_path):
    """Sanity: a non-comment AWS region in a GCP file still fires AI-002."""
    (tmp_path / "main.tf").write_text(
        'resource "google_compute_instance" "x" {\n'
        '  zone = "us-east-1"\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    assert any(f.rule_id == "PROOFCTL-TF-AI-002" for f in findings)


# ── HCL MEDIUM: _has_lifecycle_attr strips comments ───────────────────────────

def test_has_lifecycle_attr_ignores_brace_in_comment(tmp_path):
    """A `}` inside a comment must not be counted as ending the lifecycle block."""
    (tmp_path / "main.tf").write_text(
        'resource "aws_s3_bucket" "x" {\n'
        '  bucket = "stateful"\n'
        '  lifecycle {\n'
        '    # the closing brace below is real, this comment has } in it\n'
        '    prevent_destroy = true\n'
        '  }\n'
        '}\n'
    )
    findings = run_check(tmp_path, ProofctlConfig(), families=["TF"])
    # If the lifecycle scope was prematurely ended by the `}` in the comment,
    # `_has_lifecycle_attr(b, "prevent_destroy")` would have returned False
    # and a "stateful resource without prevent_destroy" finding would surface.
    # Confirm we DON'T see that finding.
    msgs = [f.message for f in findings]
    assert not any("prevent_destroy" in m and "stateful" in m.lower() for m in msgs), (
        f"unexpected stateful finding: {msgs}"
    )
