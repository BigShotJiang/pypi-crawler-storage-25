"""Tests for K8s and GHA YAML rules (YAML-009 through YAML-021, GHA-001 through GHA-006)."""
from __future__ import annotations

from pathlib import Path

from proofctl.checkers.yaml_checker import YamlRulesChecker
from proofctl.models import Severity

_checker = YamlRulesChecker()
_K8S_PATH = Path("k8s/deployment.yaml")
_GHA_PATH = Path(".github/workflows/ci.yaml")


def _check(src: str, path: Path = _K8S_PATH):
    return _checker.check(path, src)


def _rules(src: str, path: Path = _K8S_PATH) -> set[str]:
    return {f.rule_id for f in _check(src, path)}


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ── shared headers ────────────────────────────────────────────────────────────

_DEPLOY_HEADER = (
    "apiVersion: apps/v1\n"
    "kind: Deployment\n"
    "metadata:\n"
    "  name: myapp\n"
    "spec:\n"
    "  template:\n"
    "    spec:\n"
)

_POD_HEADER = (
    "apiVersion: v1\n"
    "kind: Pod\n"
    "metadata:\n"
    "  name: mypod\n"
    "spec:\n"
)

# A "secure" container block that satisfies all security rules — used as base
_SECURE_CONTAINER = (
    "      - name: app\n"
    "        image: nginx:1.27@sha256:" + "a" * 64 + "\n"
    "        securityContext:\n"
    "          runAsNonRoot: true\n"
    "          allowPrivilegeEscalation: false\n"
    "          readOnlyRootFilesystem: true\n"
    "          seccompProfile:\n"
    "            type: RuntimeDefault\n"
    "          capabilities:\n"
    "            drop: [ALL]\n"
    "        livenessProbe:\n"
    "          httpGet:\n"
    "            path: /healthz\n"
    "            port: 8080\n"
    "        readinessProbe:\n"
    "          httpGet:\n"
    "            path: /ready\n"
    "            port: 8080\n"
    "        resources:\n"
    "          limits:\n"
    "            cpu: 500m\n"
    "            memory: 256Mi\n"
)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-009 — runAsNonRoot
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml009_no_security_context():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-009")
    assert len(f) >= 1
    assert all(x.severity == Severity.WARNING for x in f)


def test_yaml009_run_as_non_root_missing():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          allowPrivilegeEscalation: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-009")
    assert len(f) >= 1


def test_yaml009_run_as_non_root_false_is_error():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          runAsNonRoot: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-009")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)


def test_yaml009_run_as_non_root_true_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        + _SECURE_CONTAINER
        + "      automountServiceAccountToken: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-009")
    assert len(f) == 0


# ══════════════════════════════════════════════════════════════════════════════
# YAML-010 — allowPrivilegeEscalation
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml010_no_security_context():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-010")
    assert len(f) >= 1
    assert all(x.severity == Severity.ERROR for x in f)


def test_yaml010_explicitly_true_is_error():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          allowPrivilegeEscalation: true\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-010")
    assert len(f) >= 1
    assert all(x.severity == Severity.ERROR for x in f)


def test_yaml010_set_false_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        + _SECURE_CONTAINER
        + "      automountServiceAccountToken: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-010")
    assert len(f) == 0


# ══════════════════════════════════════════════════════════════════════════════
# YAML-011 — readOnlyRootFilesystem
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml011_no_security_context():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-011")
    assert len(f) >= 1
    assert all(x.severity == Severity.WARNING for x in f)


def test_yaml011_explicitly_false():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          readOnlyRootFilesystem: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-011")
    assert len(f) >= 1


def test_yaml011_set_true_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        + _SECURE_CONTAINER
        + "      automountServiceAccountToken: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-011")
    assert len(f) == 0


# ══════════════════════════════════════════════════════════════════════════════
# YAML-012 — capabilities
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml012_no_drop_all():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          capabilities:\n"
        "            drop: [NET_BIND_SERVICE]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-012")
    assert len(f) >= 1
    assert any("does not drop ALL" in x.message for x in f)


def test_yaml012_dangerous_cap_added():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          capabilities:\n"
        "            drop: [ALL]\n"
        "            add: [SYS_ADMIN]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-012")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)
    assert any("SYS_ADMIN" in x.message for x in f)


def test_yaml012_drop_all_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        + _SECURE_CONTAINER
        + "      automountServiceAccountToken: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-012")
    assert len(f) == 0


def test_yaml012_all_dangerous_caps_flagged():
    """Each dangerous capability should produce an ERROR."""
    for cap in ("SYS_ADMIN", "NET_ADMIN", "SYS_PTRACE", "SYS_MODULE", "DAC_OVERRIDE", "DAC_READ_SEARCH"):
        src = (
            _DEPLOY_HEADER
            + "      containers:\n"
            "      - name: app\n"
            "        image: nginx:1.27\n"
            "        securityContext:\n"
            "          capabilities:\n"
            "            drop: [ALL]\n"
            f"            add: [{cap}]\n"
        )
        f = _find(_check(src), "PROOFCTL-YAML-012")
        errors = [x for x in f if x.severity == Severity.ERROR]
        assert len(errors) >= 1, f"Expected ERROR for dangerous cap {cap}"


# ══════════════════════════════════════════════════════════════════════════════
# YAML-013 — seccompProfile
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml013_no_seccomp_profile():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          runAsNonRoot: true\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-013")
    assert len(f) >= 1


def test_yaml013_unconfined_type():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        securityContext:\n"
        "          seccompProfile:\n"
        "            type: Unconfined\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-013")
    assert len(f) >= 1


def test_yaml013_runtime_default_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        + _SECURE_CONTAINER
        + "      automountServiceAccountToken: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-013")
    assert len(f) == 0


# ══════════════════════════════════════════════════════════════════════════════
# YAML-014 — automountServiceAccountToken
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml014_token_not_disabled():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-014")
    assert len(f) >= 1
    assert all(x.severity == Severity.WARNING for x in f)


def test_yaml014_explicitly_true():
    src = (
        _DEPLOY_HEADER
        + "      automountServiceAccountToken: true\n"
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-014")
    assert len(f) >= 1


def test_yaml014_set_false_clean():
    src = (
        _DEPLOY_HEADER
        + "      automountServiceAccountToken: false\n"
        + "      containers:\n"
        + _SECURE_CONTAINER
    )
    f = _find(_check(src), "PROOFCTL-YAML-014")
    assert len(f) == 0


def test_yaml014_not_triggered_for_non_workload():
    """ConfigMap kind should not trigger YAML-014."""
    src = (
        "apiVersion: v1\n"
        "kind: ConfigMap\n"
        "metadata:\n"
        "  name: myconfig\n"
        "data:\n"
        "  key: value\n"
    )
    assert "PROOFCTL-YAML-014" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-015 — cluster-admin ClusterRoleBinding
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml015_cluster_admin_binding():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRoleBinding\n"
        "metadata:\n"
        "  name: bad-binding\n"
        "roleRef:\n"
        "  apiGroup: rbac.authorization.k8s.io\n"
        "  kind: ClusterRole\n"
        "  name: cluster-admin\n"
        "subjects:\n"
        "- kind: ServiceAccount\n"
        "  name: myapp\n"
        "  namespace: default\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-015")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "bad-binding" in f[0].message


def test_yaml015_non_cluster_admin_clean():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRoleBinding\n"
        "metadata:\n"
        "  name: safe-binding\n"
        "roleRef:\n"
        "  apiGroup: rbac.authorization.k8s.io\n"
        "  kind: ClusterRole\n"
        "  name: view\n"
        "subjects:\n"
        "- kind: ServiceAccount\n"
        "  name: myapp\n"
        "  namespace: default\n"
    )
    assert "PROOFCTL-YAML-015" not in _rules(src)


def test_yaml015_not_triggered_for_rolebinding():
    """Regular RoleBinding should not trigger YAML-015."""
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: RoleBinding\n"
        "metadata:\n"
        "  name: bad-binding\n"
        "roleRef:\n"
        "  kind: ClusterRole\n"
        "  name: cluster-admin\n"
    )
    assert "PROOFCTL-YAML-015" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-016 — RBAC wildcard
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml016_wildcard_verbs():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: Role\n"
        "metadata:\n"
        "  name: bad-role\n"
        "rules:\n"
        "- apiGroups: ['']\n"
        "  resources: [pods]\n"
        "  verbs: ['*']\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-016")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)


def test_yaml016_wildcard_resources():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRole\n"
        "metadata:\n"
        "  name: bad-role\n"
        "rules:\n"
        "- apiGroups: ['']\n"
        "  resources: ['*']\n"
        "  verbs: [get, list]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-016")
    assert len(f) >= 1


def test_yaml016_specific_permissions_clean():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: Role\n"
        "metadata:\n"
        "  name: safe-role\n"
        "rules:\n"
        "- apiGroups: ['']\n"
        "  resources: [pods]\n"
        "  verbs: [get, list, watch]\n"
    )
    assert "PROOFCTL-YAML-016" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-017 — privilege escalation verbs
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml017_escalate_verb():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRole\n"
        "metadata:\n"
        "  name: bad-role\n"
        "rules:\n"
        "- apiGroups: [rbac.authorization.k8s.io]\n"
        "  resources: [clusterroles]\n"
        "  verbs: [escalate]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-017")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)


def test_yaml017_bind_verb():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRole\n"
        "metadata:\n"
        "  name: bad-role\n"
        "rules:\n"
        "- apiGroups: [rbac.authorization.k8s.io]\n"
        "  resources: [clusterrolebindings]\n"
        "  verbs: [bind]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-017")
    assert len(f) >= 1


def test_yaml017_impersonate_verb():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRole\n"
        "metadata:\n"
        "  name: bad-role\n"
        "rules:\n"
        "- apiGroups: ['']\n"
        "  resources: [users]\n"
        "  verbs: [impersonate]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-017")
    assert len(f) >= 1


def test_yaml017_safe_verbs_clean():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: Role\n"
        "metadata:\n"
        "  name: safe-role\n"
        "rules:\n"
        "- apiGroups: ['']\n"
        "  resources: [pods]\n"
        "  verbs: [get, list, watch, create, update, delete]\n"
    )
    assert "PROOFCTL-YAML-017" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-018 — missing probes
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml018_no_probes():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-018")
    assert len(f) >= 1
    assert all(x.severity == Severity.WARNING for x in f)


def test_yaml018_only_liveness_no_readiness():
    """Missing both probes triggers the rule; having either one suppresses it."""
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        livenessProbe:\n"
        "          httpGet:\n"
        "            path: /healthz\n"
        "            port: 8080\n"
    )
    # Having a livenessProbe means NOT (both absent), so rule should not fire
    f = _find(_check(src), "PROOFCTL-YAML-018")
    assert len(f) == 0


def test_yaml018_both_probes_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        + _SECURE_CONTAINER
        + "      automountServiceAccountToken: false\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-018")
    assert len(f) == 0


# ══════════════════════════════════════════════════════════════════════════════
# YAML-020 — Ingress without TLS
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml020_no_tls():
    src = (
        "apiVersion: networking.k8s.io/v1\n"
        "kind: Ingress\n"
        "metadata:\n"
        "  name: my-ingress\n"
        "spec:\n"
        "  rules:\n"
        "  - host: example.com\n"
        "    http:\n"
        "      paths:\n"
        "      - path: /\n"
        "        pathType: Prefix\n"
        "        backend:\n"
        "          service:\n"
        "            name: my-svc\n"
        "            port:\n"
        "              number: 80\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-020")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "my-ingress" in f[0].message


def test_yaml020_empty_tls_list():
    src = (
        "apiVersion: networking.k8s.io/v1\n"
        "kind: Ingress\n"
        "metadata:\n"
        "  name: my-ingress\n"
        "spec:\n"
        "  tls: []\n"
        "  rules:\n"
        "  - host: example.com\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-020")
    assert len(f) == 1


def test_yaml020_with_tls_clean():
    src = (
        "apiVersion: networking.k8s.io/v1\n"
        "kind: Ingress\n"
        "metadata:\n"
        "  name: my-ingress\n"
        "spec:\n"
        "  tls:\n"
        "  - hosts:\n"
        "    - example.com\n"
        "    secretName: tls-secret\n"
        "  rules:\n"
        "  - host: example.com\n"
    )
    assert "PROOFCTL-YAML-020" not in _rules(src)


def test_yaml020_not_triggered_for_non_ingress():
    """A Service manifest should not trigger YAML-020."""
    src = (
        "apiVersion: v1\n"
        "kind: Service\n"
        "metadata:\n"
        "  name: my-svc\n"
        "spec:\n"
        "  selector:\n"
        "    app: myapp\n"
    )
    assert "PROOFCTL-YAML-020" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-021 — plaintext secret in env value
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml021_plaintext_password_in_env():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        env:\n"
        "        - name: PASSWORD\n"
        "          value: supersecret123\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-021")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)
    assert any("PASSWORD" in x.message for x in f)


def test_yaml021_api_key_in_env():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        env:\n"
        "        - name: API_KEY\n"
        "          value: abcdef123456\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-021")
    assert len(f) >= 1


def test_yaml021_secret_key_ref_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        env:\n"
        "        - name: PASSWORD\n"
        "          valueFrom:\n"
        "            secretKeyRef:\n"
        "              name: my-secret\n"
        "              key: password\n"
    )
    assert "PROOFCTL-YAML-021" not in _rules(src)


def test_yaml021_non_secret_key_in_env_clean():
    """Env vars with non-secret names should not trigger the rule."""
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27\n"
        "        env:\n"
        "        - name: APP_PORT\n"
        "          value: \"8080\"\n"
    )
    assert "PROOFCTL-YAML-021" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# GHA-001 — script injection
# ══════════════════════════════════════════════════════════════════════════════

def test_gha001_issue_title_injection():
    src = (
        "on: issues\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  process:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - uses: actions/checkout@" + "a" * 40 + "\n"
        "    - run: echo ${{ github.event.issue.title }}\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-001")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)


def test_gha001_head_ref_injection():
    src = (
        "on: pull_request\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  check:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - run: git checkout ${{ github.head_ref }}\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-001")
    assert len(f) >= 1


def test_gha001_safe_context_clean():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - uses: actions/checkout@" + "a" * 40 + "\n"
        "    - run: echo ${{ github.sha }}\n"
    )
    assert "PROOFCTL-YAML-GHA-001" not in _rules(src, _GHA_PATH)


def test_gha001_env_var_pattern_clean():
    """Using env var intermediary instead of direct interpolation is safe."""
    src = (
        "on: issues\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  process:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - env:\n"
        "        TITLE: ${{ github.event.issue.title }}\n"
        "      run: echo \"$TITLE\"\n"
    )
    assert "PROOFCTL-YAML-GHA-001" not in _rules(src, _GHA_PATH)


# ══════════════════════════════════════════════════════════════════════════════
# GHA-002 — pull_request_target unsafe checkout
# ══════════════════════════════════════════════════════════════════════════════

def test_gha002_prt_unsafe_checkout():
    src = (
        "on:\n"
        "  pull_request_target:\n"
        "    types: [opened]\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - uses: actions/checkout@" + "a" * 40 + "\n"
        "      with:\n"
        "        ref: ${{ github.event.pull_request.head.sha }}\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-002")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)


def test_gha002_prt_safe_no_checkout():
    """pull_request_target without a checkout of the PR head is safe."""
    src = (
        "on:\n"
        "  pull_request_target:\n"
        "    types: [labeled]\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  label-check:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - uses: actions/checkout@" + "a" * 40 + "\n"
    )
    assert "PROOFCTL-YAML-GHA-002" not in _rules(src, _GHA_PATH)


def test_gha002_regular_pr_checkout_clean():
    """Regular pull_request + checkout is safe (no trigger match)."""
    src = (
        "on: pull_request\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - uses: actions/checkout@" + "a" * 40 + "\n"
        "      with:\n"
        "        ref: ${{ github.event.pull_request.head.sha }}\n"
    )
    assert "PROOFCTL-YAML-GHA-002" not in _rules(src, _GHA_PATH)


# ══════════════════════════════════════════════════════════════════════════════
# GHA-003 — missing or write-all permissions
# ══════════════════════════════════════════════════════════════════════════════

def test_gha003_no_permissions_block():
    src = (
        "on: push\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-003")
    assert len(f) >= 1
    assert all(x.severity == Severity.WARNING for x in f)


def test_gha003_write_all_permissions():
    src = (
        "on: push\n"
        "permissions: write-all\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-003")
    assert len(f) >= 1
    assert all(x.severity == Severity.WARNING for x in f)


def test_gha003_minimal_permissions_clean():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    assert "PROOFCTL-YAML-GHA-003" not in _rules(src, _GHA_PATH)


# ══════════════════════════════════════════════════════════════════════════════
# GHA-004 — secrets in job/workflow env
# ══════════════════════════════════════════════════════════════════════════════

def test_gha004_secret_in_job_env():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    env:\n"
        "      MY_TOKEN: ${{ secrets.GH_TOKEN }}\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-004")
    assert len(f) >= 1
    assert all(x.severity == Severity.WARNING for x in f)


def test_gha004_secret_in_workflow_env():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "env:\n"
        "  GLOBAL_TOKEN: ${{ secrets.GLOBAL_SECRET }}\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-004")
    assert len(f) >= 1


def test_gha004_step_env_is_not_flagged():
    """Secrets in step-level env are NOT flagged by GHA-004 — scoped correctly."""
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - name: deploy\n"
        "      env:\n"
        "        TOKEN: ${{ secrets.GH_TOKEN }}\n"
        "      run: echo $TOKEN\n"
    )
    assert "PROOFCTL-YAML-GHA-004" not in _rules(src, _GHA_PATH)


def test_gha004_non_secret_env_clean():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    env:\n"
        "      NODE_ENV: production\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    assert "PROOFCTL-YAML-GHA-004" not in _rules(src, _GHA_PATH)


# ══════════════════════════════════════════════════════════════════════════════
# GHA-005 — ACTIONS_ALLOW_UNSECURE_COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

def test_gha005_unsecure_commands_true():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    env:\n"
        "      ACTIONS_ALLOW_UNSECURE_COMMANDS: 'true'\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-005")
    assert len(f) >= 1
    assert any(x.severity == Severity.ERROR for x in f)


def test_gha005_not_set_clean():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    assert "PROOFCTL-YAML-GHA-005" not in _rules(src, _GHA_PATH)


def test_gha005_set_false_clean():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 15\n"
        "    env:\n"
        "      ACTIONS_ALLOW_UNSECURE_COMMANDS: 'false'\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    assert "PROOFCTL-YAML-GHA-005" not in _rules(src, _GHA_PATH)


# ══════════════════════════════════════════════════════════════════════════════
# GHA-006 — missing timeout-minutes on jobs
# ══════════════════════════════════════════════════════════════════════════════

def test_gha006_no_timeout():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-006")
    assert len(f) >= 1
    assert all(x.severity == Severity.INFO for x in f)
    assert any("build" in x.message for x in f)


def test_gha006_multiple_jobs_no_timeout():
    """Each job without timeout should produce a separate finding."""
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "    - run: make build\n"
        "  test:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "    - run: make test\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-GHA-006")
    assert len(f) == 2


def test_gha006_with_timeout_clean():
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    timeout-minutes: 30\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    assert "PROOFCTL-YAML-GHA-006" not in _rules(src, _GHA_PATH)


def test_gha006_content_detection_without_gha_path():
    """GHA rules should fire even without .github/workflows path when content is GHA-like."""
    src = (
        "on: push\n"
        "permissions:\n"
        "  contents: read\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "    - run: echo hello\n"
    )
    # Use a non-GHA path — content-based detection should still work
    f = _find(_check(src, Path("my-workflow.yaml")), "PROOFCTL-YAML-GHA-006")
    assert len(f) >= 1


# ══════════════════════════════════════════════════════════════════════════════
# YAML-022 — Workload in default namespace
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml022_namespace_absent_fires():
    src = (
        "apiVersion: apps/v1\n"
        "kind: Deployment\n"
        "metadata:\n"
        "  name: myapp\n"
        "spec: {}\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-022")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_yaml022_explicit_default_fires():
    src = (
        "apiVersion: v1\n"
        "kind: Pod\n"
        "metadata:\n"
        "  name: mypod\n"
        "  namespace: default\n"
        "spec: {}\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-022")
    assert len(f) == 1
    assert "default namespace" in f[0].message


def test_yaml022_dedicated_namespace_clean():
    src = (
        "apiVersion: apps/v1\n"
        "kind: Deployment\n"
        "metadata:\n"
        "  name: myapp\n"
        "  namespace: production\n"
        "spec: {}\n"
    )
    assert "PROOFCTL-YAML-022" not in _rules(src)


def test_yaml022_non_workload_irrelevant():
    src = (
        "apiVersion: v1\n"
        "kind: ConfigMap\n"
        "metadata:\n"
        "  name: settings\n"
        "data:\n"
        "  k: v\n"
    )
    assert "PROOFCTL-YAML-022" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-023 — Image not pinned to digest
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml023_tagged_no_digest_fires():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.25\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-023")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_yaml023_digest_pinned_clean():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:1.27@sha256:" + "a" * 64 + "\n"
    )
    assert "PROOFCTL-YAML-023" not in _rules(src)


def test_yaml023_latest_defers_to_yaml006():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: nginx:latest\n"
    )
    rules = _rules(src)
    assert "PROOFCTL-YAML-006" in rules
    assert "PROOFCTL-YAML-023" not in rules


def test_yaml023_localhost_skipped():
    src = (
        _DEPLOY_HEADER
        + "      containers:\n"
        "      - name: app\n"
        "        image: localhost:5000/myimg:1.0\n"
    )
    assert "PROOFCTL-YAML-023" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-024 — runAsUser is root or low UID
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml024_runasuser_zero_error():
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
        "    securityContext:\n"
        "      runAsUser: 0\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-024")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml024_low_uid_warning():
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
        "    securityContext:\n"
        "      runAsUser: 1000\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-024")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_yaml024_high_uid_clean():
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
        "    securityContext:\n"
        "      runAsUser: 10001\n"
    )
    assert "PROOFCTL-YAML-024" not in _rules(src)


def test_yaml024_absent_does_not_fire():
    """Absence of runAsUser is YAML-009's territory, not YAML-024's."""
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
    )
    assert "PROOFCTL-YAML-024" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-025 — RBAC wildcard apiGroups / cluster-admin grant
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml025_wildcard_apigroups_fires():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRole\n"
        "metadata:\n"
        "  name: too-broad\n"
        "rules:\n"
        "- apiGroups: [\"*\"]\n"
        "  resources: [\"pods\"]\n"
        "  verbs: [\"get\"]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-025")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml025_cluster_admin_binding_fires():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: ClusterRoleBinding\n"
        "metadata:\n"
        "  name: oops\n"
        "roleRef:\n"
        "  apiGroup: rbac.authorization.k8s.io\n"
        "  kind: ClusterRole\n"
        "  name: cluster-admin\n"
        "subjects:\n"
        "- kind: ServiceAccount\n"
        "  name: app\n"
        "  namespace: default\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-025")
    assert len(f) == 1
    assert "cluster-admin" in f[0].message


def test_yaml025_scoped_role_clean():
    src = (
        "apiVersion: rbac.authorization.k8s.io/v1\n"
        "kind: Role\n"
        "metadata:\n"
        "  name: pod-reader\n"
        "  namespace: app\n"
        "rules:\n"
        "- apiGroups: [\"\"]\n"
        "  resources: [\"pods\"]\n"
        "  verbs: [\"get\", \"list\"]\n"
    )
    assert "PROOFCTL-YAML-025" not in _rules(src)


def test_yaml025_non_rbac_irrelevant():
    src = (
        "apiVersion: v1\n"
        "kind: ConfigMap\n"
        "metadata:\n"
        "  name: m\n"
        "  namespace: kube-system\n"
        "data: {}\n"
    )
    assert "PROOFCTL-YAML-025" not in _rules(src)


# ══════════════════════════════════════════════════════════════════════════════
# YAML-026 — capabilities.drop missing NET_RAW (and not ALL)
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml026_drop_partial_fires():
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
        "    securityContext:\n"
        "      capabilities:\n"
        "        drop: [\"CHOWN\"]\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-026")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_yaml026_drop_all_clean():
    """drop: [ALL] satisfies YAML-026 (and YAML-012)."""
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
        "    securityContext:\n"
        "      capabilities:\n"
        "        drop: [\"ALL\"]\n"
    )
    assert "PROOFCTL-YAML-026" not in _rules(src)


def test_yaml026_drop_includes_net_raw_clean():
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
        "    securityContext:\n"
        "      capabilities:\n"
        "        drop: [\"CHOWN\", \"NET_RAW\"]\n"
    )
    assert "PROOFCTL-YAML-026" not in _rules(src)


def test_yaml026_no_caps_block_irrelevant():
    """Containers with no capabilities block are YAML-012 territory, not YAML-026."""
    src = (
        _POD_HEADER
        + "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
    )
    assert "PROOFCTL-YAML-026" not in _rules(src)
