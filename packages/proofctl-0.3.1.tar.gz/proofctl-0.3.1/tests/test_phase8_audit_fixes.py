"""Regression tests for AUDIT_AND_ROADMAP Phase 8 fixes + test gaps.

Covers:
- JSON schema_version + stable field order (1.6 reporters).
- HTML reporter output sanity + schema_version meta tag.
- Single-file sub-path scan (audit C-7 regression lock-in).
- --changed-only end-to-end with a real (tiny) git repo.
- Fixer multi-line literal failure path (apply_fixes_detailed.skipped).
- TerminalReporter accepts an injected Console.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from pathlib import Path

import pytest

from proofctl.config import ProofctlConfig
from proofctl.engine import run_check
from proofctl.fixer import apply_fixes_detailed
from proofctl.models import Finding, Severity
from proofctl.reporters.html_reporter import HtmlReporter
from proofctl.reporters.json_reporter import JsonReporter, SCHEMA_VERSION
from proofctl.reporters.terminal import TerminalReporter


def _run(cmd: list[str], cwd: Path | None = None) -> subprocess.CompletedProcess:
    """Invoke the proofctl CLI in a subprocess.

    NOTE: Per phase1 test conventions we do NOT pass cwd by default — proofctl
    discovers the project root from the explicit path argument. Passing cwd
    can cause silent no-ops when the package is installed editable (the inner
    Python's import path differs).
    """
    kwargs: dict = {"capture_output": True, "text": True}
    if cwd is not None:
        kwargs["cwd"] = cwd
    return subprocess.run(
        [sys.executable, "-m", "proofctl.cli"] + cmd,
        **kwargs,
    )


# ---------------------------------------------------------------------------
# JSON reporter — schema_version + stable field order
# ---------------------------------------------------------------------------

def _make_finding(**overrides) -> Finding:
    base = dict(
        file="x.py",
        line=1,
        col=0,
        rule_id="PROOFCTL-Q-001",
        rule_name="Mutable default argument",
        severity=Severity.ERROR,
        message="msg",
        hint="hint",
        authority="PEP 8",
        docs_url="https://example.invalid/q-001",
        fixable=True,
    )
    base.update(overrides)
    return Finding(**base)


def test_json_has_schema_version():
    out = JsonReporter().render([_make_finding()])
    data = json.loads(out)
    assert data["schema_version"] == SCHEMA_VERSION == 1


def test_json_top_level_key_order():
    out = JsonReporter().render([_make_finding()])
    data = json.loads(out)
    assert list(data.keys()) == ["schema_version", "summary", "findings"]


def test_json_summary_field_order():
    out = JsonReporter().render(
        [
            _make_finding(severity=Severity.ERROR),
            _make_finding(severity=Severity.WARNING, line=2),
            _make_finding(severity=Severity.INFO, line=3),
        ]
    )
    summary = json.loads(out)["summary"]
    assert list(summary.keys()) == ["total", "ERROR", "WARNING", "INFO"]
    assert summary["total"] == 3
    assert summary["ERROR"] == 1
    assert summary["WARNING"] == 1
    assert summary["INFO"] == 1


def test_json_finding_field_order():
    out = JsonReporter().render([_make_finding()])
    finding = json.loads(out)["findings"][0]
    expected = [
        "file",
        "line",
        "col",
        "rule_id",
        "rule_name",
        "severity",
        "message",
        "hint",
        "authority",
        "docs_url",
        "fixable",
    ]
    assert list(finding.keys()) == expected


def test_json_empty_findings_still_has_schema_and_zero_summary():
    out = JsonReporter().render([])
    data = json.loads(out)
    assert data["schema_version"] == 1
    assert data["summary"] == {"total": 0, "ERROR": 0, "WARNING": 0, "INFO": 0}
    assert data["findings"] == []


# ---------------------------------------------------------------------------
# HTML reporter
# ---------------------------------------------------------------------------

def test_html_contains_schema_version_meta():
    html_out = HtmlReporter().render([])
    assert 'name="proofctl:schema_version"' in html_out
    assert 'content="1"' in html_out


def test_cli_html_output_writes_non_empty_file(tmp_path):
    """In-process invocation via Typer's CliRunner — avoids subprocess
    PYTHONPATH/cwd surprises while still exercising the full CLI plumbing
    (arg parsing, reporter selection, --output write path)."""
    from typer.testing import CliRunner
    from proofctl.cli import app

    (tmp_path / "x.py").write_text("def f(items=[]):\n    pass\n")
    report = tmp_path / "report.html"

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "check",
            str(tmp_path),
            "--no-pypi",
            "--format",
            "html",
            "--output",
            str(report),
        ],
    )

    # exit 2 when ERRORs exist is fine; the file must have been written.
    assert report.exists(), (
        f"report.html missing.\n"
        f"exit_code={result.exit_code}\n"
        f"stdout={result.stdout!r}\n"
        f"exception={result.exception!r}"
    )
    text = report.read_text(encoding="utf-8")
    assert text.strip(), "html report file is empty"
    assert "<html" in text.lower()
    assert 'name="proofctl:schema_version"' in text


# ---------------------------------------------------------------------------
# Single-file sub-path scan (audit C-7 regression lock-in)
# ---------------------------------------------------------------------------

def test_single_file_subpath_scan_returns_findings(tmp_path):
    target = tmp_path / "src" / "api" / "auth.py"
    target.parent.mkdir(parents=True)
    target.write_text("def login(user, perms=[]):\n    pass\n")

    findings = run_check(target.parent, ProofctlConfig(), families=["Q"])
    rel = str(target.relative_to(target.parent))
    file_findings = [f for f in findings if f.file == rel]
    assert any(f.rule_id == "PROOFCTL-Q-001" for f in file_findings), (
        f"Expected PROOFCTL-Q-001; got: {[(f.rule_id, f.file) for f in file_findings]}"
    )


# ---------------------------------------------------------------------------
# --changed-only end-to-end against a real tiny git repo
# ---------------------------------------------------------------------------

def _git_available() -> bool:
    try:
        subprocess.run(
            ["git", "--version"], capture_output=True, check=True, timeout=5
        )
        return True
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        return False


@pytest.mark.skipif(not _git_available(), reason="git not available on PATH")
def test_changed_only_end_to_end(tmp_path):
    subprocess.run(["git", "init", "-q"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.email", "t@t"], cwd=tmp_path, check=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=tmp_path, check=True)
    subprocess.run(
        ["git", "config", "commit.gpgsign", "false"], cwd=tmp_path, check=True
    )
    # Pre-existing file — should be excluded by --changed-only after commit.
    (tmp_path / "old.py").write_text("def g(items=[]):\n    pass\n")
    subprocess.run(["git", "add", "-A"], cwd=tmp_path, check=True)
    subprocess.run(["git", "commit", "-q", "-m", "init"], cwd=tmp_path, check=True)

    # New file with a Q-001 finding — should be included.
    (tmp_path / "new.py").write_text("def f(items=[]):\n    pass\n")
    subprocess.run(["git", "add", "-A"], cwd=tmp_path, check=True)

    # In-process via CliRunner — the engine inspects git from the scan_root
    # passed via the path argument, so we don't need to chdir.
    from typer.testing import CliRunner
    from proofctl.cli import app

    runner = CliRunner()
    result = runner.invoke(
        app,
        [
            "check",
            str(tmp_path),
            "--no-pypi",
            "--changed-only",
            "--format",
            "json",
        ],
    )
    # Exit code 2 (ERRORs) or 0 (no findings) — both are non-error from the
    # CliRunner perspective; we only assert on JSON contents.
    assert result.stdout, (
        f"empty stdout; exit={result.exit_code} exc={result.exception!r}"
    )
    # The CLI may print a status line before the JSON — extract the JSON object.
    match = re.search(r"\{.*\}", result.stdout, re.DOTALL)
    assert match, f"no JSON in stdout: {result.stdout!r}"
    data = json.loads(match.group(0))

    files = {f["file"] for f in data["findings"]}
    # Only the changed/new file should be scanned.
    assert any(p.endswith("new.py") for p in files), files
    assert not any(p.endswith("old.py") for p in files), files


# ---------------------------------------------------------------------------
# Fixer: multi-line literal default is reported as skipped
# ---------------------------------------------------------------------------

def test_fixer_multiline_default_skipped(tmp_path):
    """The fixer must report multi-line literal defaults as skipped (not crash,
    not silently rewrite). The engine normally marks these `fixable=False` so
    they never reach the fixer — but if a caller supplies `fixable=True` (e.g.
    a future plugin that wants to attempt the fix), the fixer's own multi-line
    guard must trigger and surface a skipped_details entry.
    """
    src = tmp_path / "ml.py"
    src.write_text(
        "def f(\n"
        "    items=[\n"
        "        1,\n"
        "        2,\n"
        "    ],\n"
        "):\n"
        "    return items\n"
    )
    # Build a synthetic Q-001 finding with fixable=True targeting the
    # multi-line default. The fixer's internal "single-line only" guard
    # should reject it cleanly.
    f = Finding(
        file="ml.py",
        line=2,
        col=10,
        rule_id="PROOFCTL-Q-001",
        rule_name="Mutable default argument",
        severity=Severity.ERROR,
        message="multi-line default",
        hint="",
        authority="",
        docs_url="",
        fixable=True,  # force the fixer to attempt the rewrite
    )
    result = apply_fixes_detailed([f], tmp_path)
    assert result.skipped > 0, (
        f"expected skipped>0 for multi-line default; got {result.skipped}, "
        f"succeeded={result.succeeded}"
    )
    assert result.skipped_details, "skipped_details should be populated"
    file_label, line_no, arg_name = result.skipped_details[0]
    assert file_label.endswith("ml.py")
    assert isinstance(line_no, int) and line_no >= 1
    assert arg_name == "items"
    # Multi-line literal must NOT have been rewritten on disk.
    assert "items=[" in src.read_text()


# ---------------------------------------------------------------------------
# TerminalReporter accepts an injected Console (output ordering)
# ---------------------------------------------------------------------------

def test_terminal_reporter_accepts_injected_console():
    """Audit 1.6 — render() must accept a Console parameter so the engine and
    reporter share a single sink and ordering stays deterministic in pipes.
    """
    import io as _io
    from rich.console import Console

    buf = _io.StringIO()
    injected = Console(file=buf, force_terminal=False, no_color=True, width=120)

    TerminalReporter().render([], console_=injected)
    rendered = buf.getvalue()
    assert "No findings" in rendered, rendered


def test_terminal_reporter_no_console_param_still_works(capsys):
    """Backwards-compatibility: callers that don't pass console_ keep working."""
    TerminalReporter().render([])
    captured = capsys.readouterr()
    # Module-level console writes to stdout by default; either stream is fine,
    # but the reporter should not raise.
    assert "No findings" in (captured.out + captured.err)
