"""Tests for PROOFCTL-DF-* — Dockerfile rules."""
from __future__ import annotations

from pathlib import Path

from proofctl.checkers.dockerfile import DockerfileRulesChecker
from proofctl.models import Severity

_P = Path("Dockerfile")
_checker = DockerfileRulesChecker()


def _check(src: str):
    return _checker.check(_P, src)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# DF-001 — Unpinned base image
# ══════════════════════════════════════════════════════════════════════════════

def test_df001_latest_tag():
    src = "FROM python:latest\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_df001_no_tag():
    src = "FROM ubuntu\nCMD bash\n"
    f = _find(_check(src), "PROOFCTL-DF-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_df001_tag_no_digest():
    src = "FROM python:3.12-slim\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-001")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_df001_digest_pinned_clean():
    src = (
        "FROM python:3.12@sha256:" + "a" * 64 + "\n"
        "CMD python app.py\n"
    )
    assert "PROOFCTL-DF-001" not in _ids(_check(src))


def test_df001_scratch_clean():
    src = "FROM scratch\nCOPY binary /binary\nENTRYPOINT [\"/binary\"]\n"
    assert "PROOFCTL-DF-001" not in _ids(_check(src))


def test_df001_multistage_alias_clean():
    src = (
        "FROM python:3.12 AS builder\n"
        "RUN pip install .\n"
        "FROM builder\n"
        "CMD python app.py\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-001")
    # Only the first FROM should fire (tag without digest), not the stage alias
    assert len(f) == 1
    assert "builder" not in f[0].message


def test_df001_platform_flag():
    src = "FROM --platform=linux/amd64 node:20\nCMD node server.js\n"
    f = _find(_check(src), "PROOFCTL-DF-001")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_df001_platform_flag_with_digest_clean():
    """--platform combined with a digest-pinned image must be clean."""
    digest = "a" * 64
    src = f"FROM --platform=linux/amd64 python:3.12@sha256:{digest}\nCMD python app.py\n"
    assert "PROOFCTL-DF-001" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-002 — Running as root
# ══════════════════════════════════════════════════════════════════════════════

def test_df002_no_user_instruction():
    src = "FROM python:3.12\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-002")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_df002_user_root():
    src = "FROM python:3.12\nUSER root\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-002")
    assert len(f) == 1


def test_df002_user_zero():
    src = "FROM python:3.12\nUSER 0\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-002")
    assert len(f) == 1


def test_df002_non_root_user_clean():
    src = "FROM python:3.12\nUSER appuser\nCMD python app.py\n"
    assert "PROOFCTL-DF-002" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-003 — ADD for local files
# ══════════════════════════════════════════════════════════════════════════════

def test_df003_add_local_path():
    src = "FROM python:3.12\nADD ./app /app\nUSER app\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-003")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_df003_add_url_clean():
    src = "FROM python:3.12\nADD https://example.com/file.tar.gz /tmp/\nUSER app\nCMD bash\n"
    assert "PROOFCTL-DF-003" not in _ids(_check(src))


def test_df003_add_archive_clean():
    src = "FROM python:3.12\nADD archive.tar.gz /app/\nUSER app\nCMD bash\n"
    assert "PROOFCTL-DF-003" not in _ids(_check(src))


def test_df003_copy_clean():
    src = "FROM python:3.12\nCOPY . /app\nUSER app\nCMD python app.py\n"
    assert "PROOFCTL-DF-003" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-004 — apt-get without --no-install-recommends
# ══════════════════════════════════════════════════════════════════════════════

def test_df004_apt_get_without_flag():
    src = (
        "FROM ubuntu:22.04\n"
        "RUN apt-get update && apt-get install -y curl\n"
        "USER app\nCMD bash\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-004")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_df004_apt_get_with_flag_clean():
    src = (
        "FROM ubuntu:22.04\n"
        "RUN apt-get update && apt-get install -y --no-install-recommends curl\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-004" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-005 — Secret in ENV or ARG
# ══════════════════════════════════════════════════════════════════════════════

def test_df005_env_secret_key():
    src = "FROM python:3.12\nENV SECRET_KEY=abc123\nUSER app\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_df005_env_password():
    src = "FROM python:3.12\nENV PASSWORD=hunter2\nUSER app\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-005")
    assert len(f) == 1


def test_df005_arg_api_key():
    src = "FROM python:3.12\nARG API_KEY\nUSER app\nCMD python app.py\n"
    f = _find(_check(src), "PROOFCTL-DF-005")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_df005_non_secret_env_clean():
    src = "FROM python:3.12\nENV APP_PORT=8080\nUSER app\nCMD python app.py\n"
    assert "PROOFCTL-DF-005" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-006 — Missing HEALTHCHECK
# ══════════════════════════════════════════════════════════════════════════════

def test_df006_missing_healthcheck():
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "USER app\n"
        "CMD [\"python\", \"app.py\"]\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-006")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_df006_has_healthcheck_clean():
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "USER app\n"
        "HEALTHCHECK --interval=30s CMD curl -f http://localhost/ || exit 1\n"
        "CMD [\"python\", \"app.py\"]\n"
    )
    assert "PROOFCTL-DF-006" not in _ids(_check(src))


def test_df006_no_cmd_no_flag():
    """A Dockerfile with no CMD/ENTRYPOINT doesn't need a HEALTHCHECK."""
    src = "FROM python:3.12\nRUN pip install requests\n"
    assert "PROOFCTL-DF-006" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-007 — curl|sh / wget|sh remote script execution
# ══════════════════════════════════════════════════════════════════════════════

def test_df007_curl_pipe_sh():
    src = "FROM ubuntu:22.04\nRUN curl -fsSL https://example.com/install.sh | sh\nUSER app\nCMD bash\n"
    f = _find(_check(src), "PROOFCTL-DF-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_df007_wget_pipe_bash():
    src = "FROM ubuntu:22.04\nRUN wget -qO- https://get.example.com | bash\nUSER app\nCMD bash\n"
    f = _find(_check(src), "PROOFCTL-DF-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_df007_curl_pipe_python():
    src = "FROM ubuntu:22.04\nRUN curl https://bootstrap.example.com | python3\nUSER app\nCMD bash\n"
    f = _find(_check(src), "PROOFCTL-DF-007")
    assert len(f) == 1


def test_df007_wget_pipe_perl():
    src = "FROM ubuntu:22.04\nRUN wget -O- https://example.com/setup.pl | perl\nUSER app\nCMD bash\n"
    f = _find(_check(src), "PROOFCTL-DF-007")
    assert len(f) == 1


def test_df007_clean_no_pipe():
    """RUN with curl but no shell pipe is clean."""
    src = (
        "FROM ubuntu:22.04\n"
        "RUN curl -fsSL https://example.com/install.sh -o /tmp/install.sh "
        "&& sha256sum -c /tmp/install.sh.sha256 && sh /tmp/install.sh\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-007" not in _ids(_check(src))


def test_df007_clean_no_curl_wget():
    """RUN that pipes something else entirely is clean."""
    src = "FROM ubuntu:22.04\nRUN cat /etc/hosts | grep localhost\nUSER app\nCMD bash\n"
    assert "PROOFCTL-DF-007" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-008 — ADD <url> without checksum verification
# ══════════════════════════════════════════════════════════════════════════════

def test_df008_add_url_no_checksum():
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "USER app\nCMD bash\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-008")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "https://example.com/tool.tar.gz" in f[0].message


def test_df008_add_url_buildkit_checksum_clean():
    src = (
        "FROM ubuntu:22.04\n"
        "ADD --checksum=sha256:abc123 https://example.com/tool.tar.gz /tmp/\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" not in _ids(_check(src))


def test_df008_add_url_followed_by_sha256sum_clean():
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "RUN sha256sum -c /tmp/tool.tar.gz.sha256\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" not in _ids(_check(src))


def test_df008_add_url_followed_by_gpg_verify_clean():
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "RUN gpg --verify /tmp/tool.tar.gz.sig /tmp/tool.tar.gz\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" not in _ids(_check(src))


def test_df008_add_local_file_not_flagged():
    """ADD for a local path is DF-003 territory, not DF-008."""
    src = "FROM ubuntu:22.04\nADD ./local.tar.gz /tmp/\nUSER app\nCMD bash\n"
    assert "PROOFCTL-DF-008" not in _ids(_check(src))


def test_df008_verify_outside_window_flags():
    """Phase 6 fix: walking the full RUN continuation chain (until a
    non-RUN instruction) means sha256sum verification any number of
    RUN steps after the ADD now suppresses the finding. The OLD
    behaviour capped the lookahead at 3 instructions and therefore
    flagged this — that was the bug fixed in Phase 6 of the audit."""
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "RUN echo step1\n"
        "RUN echo step2\n"
        "RUN echo step3\n"
        "RUN sha256sum -c /tmp/tool.tar.gz.sha256\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-009 — COPY . before dependency installation
# ══════════════════════════════════════════════════════════════════════════════

def test_df009_copy_dot_before_pip_install():
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "RUN pip install -r requirements.txt\n"
        "CMD python app.py\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-009")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_df009_copy_dot_before_npm_install():
    src = (
        "FROM node:20\n"
        "COPY . /app\n"
        "RUN npm install\n"
        "CMD node server.js\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-009")
    assert len(f) == 1


def test_df009_copy_dot_before_poetry_install():
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "RUN poetry install\n"
        "CMD python -m app\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-009")
    assert len(f) == 1


def test_df009_clean_dep_files_first():
    """Copy requirements first, install, then copy full source — correct pattern."""
    src = (
        "FROM python:3.12\n"
        "COPY requirements.txt /app/requirements.txt\n"
        "RUN pip install -r /app/requirements.txt\n"
        "COPY . /app\n"
        "CMD python app.py\n"
    )
    assert "PROOFCTL-DF-009" not in _ids(_check(src))


def test_df009_clean_no_dep_install():
    """COPY . with no dependency install at all — no finding."""
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "CMD python app.py\n"
    )
    assert "PROOFCTL-DF-009" not in _ids(_check(src))


def test_df009_clean_copy_specific_file():
    """COPY of a specific file (not '.') before install — clean."""
    src = (
        "FROM python:3.12\n"
        "COPY requirements.txt .\n"
        "RUN pip install -r requirements.txt\n"
        "CMD python app.py\n"
    )
    assert "PROOFCTL-DF-009" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# DF-010 — Missing OCI image labels
# ══════════════════════════════════════════════════════════════════════════════

def test_df010_missing_oci_labels():
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "USER app\n"
        "CMD [\"python\", \"app.py\"]\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-010")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_df010_missing_labels_with_entrypoint():
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "ENTRYPOINT [\"python\", \"app.py\"]\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-010")
    assert len(f) == 1


def test_df010_has_oci_label_clean():
    src = (
        "FROM python:3.12\n"
        "LABEL org.opencontainers.image.source=https://github.com/org/repo\n"
        "COPY . /app\n"
        "USER app\n"
        "CMD [\"python\", \"app.py\"]\n"
    )
    assert "PROOFCTL-DF-010" not in _ids(_check(src))


def test_df010_non_oci_label_still_flags():
    """A LABEL present but without OCI prefix should still trigger the rule."""
    src = (
        "FROM python:3.12\n"
        "LABEL maintainer=\"team@example.com\"\n"
        "COPY . /app\n"
        "USER app\n"
        "CMD [\"python\", \"app.py\"]\n"
    )
    f = _find(_check(src), "PROOFCTL-DF-010")
    assert len(f) == 1


def test_df010_no_cmd_no_entrypoint_clean():
    """Build-only image with no CMD/ENTRYPOINT should not be flagged."""
    src = (
        "FROM python:3.12\n"
        "RUN pip install build\n"
    )
    assert "PROOFCTL-DF-010" not in _ids(_check(src))
