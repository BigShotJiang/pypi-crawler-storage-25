from __future__ import annotations

import ast
from pathlib import Path

import pytest

from proofctl.checkers.security import SecurityChecker
from proofctl.models import Severity

_P = Path("module.py")
_checker = SecurityChecker()


def _parse(src: str) -> ast.Module:
    return ast.parse(src)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


def _check(src: str):
    tree = _parse(src)
    return _checker.check(_P, src, tree)


# ══════════════════════════════════════════════════════════════════════════════
# S-001 — SQL injection via string formatting
# ══════════════════════════════════════════════════════════════════════════════


def test_s001_fstring_in_execute():
    src = """
cursor.execute(f"SELECT * FROM users WHERE id = {user_id}")
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s001_format_in_execute():
    src = """
cursor.execute("SELECT * FROM users WHERE name = '{}'".format(name))
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1


def test_s001_percent_in_execute():
    src = """
cursor.execute("DELETE FROM sessions WHERE token = '%s'" % token)
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1


def test_s001_concat_in_execute():
    src = """
cursor.execute("UPDATE users SET name = '" + name + "' WHERE id = 1")
"""
    f = _find(_check(src), "PROOFCTL-S-001")
    assert len(f) == 1


def test_s001_parameterised_clean():
    src = """
cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
"""
    assert "PROOFCTL-S-001" not in _ids(_check(src))


def test_s001_literal_query_clean():
    src = """
cursor.execute("SELECT 1")
"""
    assert "PROOFCTL-S-001" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-002 — Command injection
# ══════════════════════════════════════════════════════════════════════════════


def test_s002_subprocess_run_shell_fstring():
    src = """
import subprocess
subprocess.run(f"ls {user_dir}", shell=True)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s002_subprocess_call_variable():
    src = """
import subprocess
subprocess.call(cmd, shell=True)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1


def test_s002_os_system_variable():
    src = """
import os
os.system(user_command)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1


def test_s002_list_form_no_shell_clean():
    src = """
import subprocess
subprocess.run(["ls", user_dir])
"""
    assert "PROOFCTL-S-002" not in _ids(_check(src))


def test_s002_shell_true_literal_clean():
    src = """
import subprocess
subprocess.run("ls -la /tmp", shell=True)
"""
    assert "PROOFCTL-S-002" not in _ids(_check(src))


def test_s002_subprocess_getoutput_variable_flagged():
    # getoutput / getstatusoutput always shell out; flag on non-literal first arg.
    # See AUDIT C-9.
    src = """
import subprocess
out = subprocess.getoutput(user_cmd)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s002_subprocess_getstatusoutput_variable_flagged():
    src = """
import subprocess
status, out = subprocess.getstatusoutput(user_cmd)
"""
    f = _find(_check(src), "PROOFCTL-S-002")
    assert len(f) == 1


def test_s002_subprocess_getoutput_literal_clean():
    src = """
import subprocess
out = subprocess.getoutput("uname -a")
"""
    assert "PROOFCTL-S-002" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-003 — Unsafe deserialization
# ══════════════════════════════════════════════════════════════════════════════


def test_s003_pickle_loads():
    src = """
import pickle
obj = pickle.loads(data)
"""
    f = _find(_check(src), "PROOFCTL-S-003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s003_pickle_load():
    src = """
import pickle
with open("data.pkl", "rb") as fh:
    obj = pickle.load(fh)
"""
    f = _find(_check(src), "PROOFCTL-S-003")
    assert len(f) == 1


def test_s003_yaml_load_no_loader():
    src = """
import yaml
config = yaml.load(data)
"""
    f = _find(_check(src), "PROOFCTL-S-003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s003_yaml_load_with_safe_loader_clean():
    src = """
import yaml
config = yaml.load(data, Loader=yaml.SafeLoader)
"""
    assert "PROOFCTL-S-003" not in _ids(_check(src))


def test_s003_yaml_safe_load_clean():
    src = """
import yaml
config = yaml.safe_load(data)
"""
    assert "PROOFCTL-S-003" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-004 — Weak cryptographic primitive
# ══════════════════════════════════════════════════════════════════════════════


def test_s004_hashlib_md5():
    src = """
import hashlib
digest = hashlib.md5(data).hexdigest()
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s004_hashlib_sha1():
    src = """
import hashlib
h = hashlib.sha1(data)
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s004_random_for_token():
    src = """
import random, string
token = ''.join(random.choice(string.ascii_letters) for _ in range(32))
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "token" in f[0].message


def test_s004_random_for_password():
    src = """
import random
password = random.randint(100000, 999999)
"""
    f = _find(_check(src), "PROOFCTL-S-004")
    assert len(f) == 1


def test_s004_hashlib_sha256_clean():
    src = """
import hashlib
digest = hashlib.sha256(data).hexdigest()
"""
    assert "PROOFCTL-S-004" not in _ids(_check(src))


def test_s004_secrets_module_clean():
    src = """
import secrets
token = secrets.token_urlsafe(32)
"""
    assert "PROOFCTL-S-004" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-005 — eval / exec on non-literal
# ══════════════════════════════════════════════════════════════════════════════


def test_s005_eval_variable():
    src = """
result = eval(user_input)
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s005_exec_fstring():
    src = """
exec(f"x = {value}")
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 1


def test_s005_eval_literal_not_flagged():
    # eval() on a constant literal is gated out — too noisy in test/util code,
    # and harmless without dynamic input. See AUDIT C-8.
    src = """
result = eval("1 + 2")
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 0


def test_s005_compile_literal_not_flagged():
    # compile() on a literal is the safe primitive used to build sanitised AST.
    src = """
code = compile("1 + 2", "<string>", "eval")
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 0


def test_s005_compile_variable_flagged():
    src = """
code = compile(user_src, "<string>", "exec")
"""
    f = _find(_check(src), "PROOFCTL-S-005")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# S-006 — Missing HTTP timeout
# ══════════════════════════════════════════════════════════════════════════════


def test_s006_requests_get_no_timeout():
    src = """
import requests
resp = requests.get(url)
"""
    f = _find(_check(src), "PROOFCTL-S-006")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s006_requests_post_no_timeout():
    src = """
import requests
resp = requests.post(url, json=payload)
"""
    f = _find(_check(src), "PROOFCTL-S-006")
    assert len(f) == 1


def test_s006_requests_with_timeout_clean():
    src = """
import requests
resp = requests.get(url, timeout=30)
"""
    assert "PROOFCTL-S-006" not in _ids(_check(src))


def test_s006_httpx_no_timeout():
    src = """
import httpx
resp = httpx.post(url, json=data)
"""
    f = _find(_check(src), "PROOFCTL-S-006")
    assert len(f) == 1


def test_s006_httpx_with_timeout_clean():
    src = """
import httpx
resp = httpx.get(url, timeout=10.0)
"""
    assert "PROOFCTL-S-006" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-014 — TLS verification disabled
# ══════════════════════════════════════════════════════════════════════════════


def test_s014_requests_verify_false():
    src = """
import requests
r = requests.post(url, data=payload, verify=False)
"""
    f = _find(_check(src), "PROOFCTL-S-014")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s014_session_verify_false():
    src = """
import requests
s = requests.Session()
s.get(url, verify=False)
"""
    assert len(_find(_check(src), "PROOFCTL-S-014")) == 1


def test_s014_default_verify_clean():
    src = """
import requests
r = requests.get(url, timeout=5)
"""
    assert "PROOFCTL-S-014" not in _ids(_check(src))


def test_s014_verify_true_clean():
    src = """
import requests
r = requests.get(url, timeout=5, verify=True)
"""
    assert "PROOFCTL-S-014" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-015 — random.* used for security-sensitive value
# ══════════════════════════════════════════════════════════════════════════════


def test_s015_random_choice_for_token():
    src = """
import random, string
loaded_token = ''.join(random.choice(string.ascii_lowercase) for _ in range(8))
"""
    f = _find(_check(src), "PROOFCTL-S-015")
    assert len(f) >= 1
    assert f[0].severity == Severity.WARNING


def test_s015_random_in_password_function():
    src = """
import random
def generate_password():
    return random.choices('abc', k=8)
"""
    assert len(_find(_check(src), "PROOFCTL-S-015")) >= 1


def test_s015_random_for_non_sensitive_clean():
    src = """
import random
pick = random.choice(['heads', 'tails'])
"""
    assert "PROOFCTL-S-015" not in _ids(_check(src))


def test_s015_secrets_for_token_clean():
    src = """
import secrets
api_token = secrets.token_hex(16)
"""
    assert "PROOFCTL-S-015" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-016 — subprocess with partial executable path
# ══════════════════════════════════════════════════════════════════════════════


def test_s016_partial_path_string():
    src = """
import subprocess
subprocess.run('ls -la', shell=False)
"""
    # shell=False with a string is unusual but bandit still flags name-only command.
    # Our detector checks the literal arg.
    f = _find(_check(src), "PROOFCTL-S-016")
    # Note: shell=False with a single string is rejected at runtime by subprocess,
    # so most real callers use a list. Keep this as a list-based check.
    src2 = """
import subprocess
subprocess.run(['ls', '-la'])
"""
    f2 = _find(_check(src2), "PROOFCTL-S-016")
    assert len(f2) == 1
    assert f2[0].severity == Severity.WARNING


def test_s016_partial_path_check_output():
    src = """
import subprocess
subprocess.check_output(['curl', '-X', 'POST', url])
"""
    f = _find(_check(src), "PROOFCTL-S-016")
    assert len(f) == 1


def test_s016_full_path_clean():
    src = """
import subprocess
subprocess.run(['/usr/bin/ls', '-la'])
"""
    assert "PROOFCTL-S-016" not in _ids(_check(src))


def test_s016_common_tool_is_info():
    src = """
import subprocess
subprocess.run(['python', '-m', 'pytest'])
"""
    f = _find(_check(src), "PROOFCTL-S-016")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_s016_shell_true_skipped():
    # S-002 covers shell=True; S-016 must not double-fire.
    src = """
import subprocess
subprocess.run('ls -la', shell=True)
"""
    assert "PROOFCTL-S-016" not in _ids(_check(src))
