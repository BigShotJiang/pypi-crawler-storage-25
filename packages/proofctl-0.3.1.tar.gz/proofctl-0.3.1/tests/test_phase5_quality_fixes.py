"""Regression tests for AUDIT_AND_ROADMAP Phase 5 (quality.py) fixes.

Covers:
  H-16 — Q-002 broad-except wider catch (INFO tier for arbitrary recovery)
  H-17 — Q-005 cyclomatic complexity counts match/case
  H-18 — Q-007 parameter count includes keyword-only arguments
  Q-009 — print() skip for examples/, scripts/, samples/, demo/, shebang,
          .ipynb, and __main__ guards
  Q-001 — fixable=False for multi-line literal defaults
  Q-008 — exempt setattr() and module-level @dataclass constructor calls
"""
from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.quality import QualityChecker
from proofctl.models import Severity


def _check(src: str, path: str = "module.py", **kw) -> list:
    tree = ast.parse(src)
    return QualityChecker(**kw).check(Path(path), src, tree)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _q(findings, rule_id: str) -> list:
    return [f for f in findings if f.rule_id == rule_id]


# ── H-16: Q-002 — broad except as INFO when no re-raise ────────────────────


def test_h16_broad_except_arbitrary_recovery_emits_info():
    """`except Exception:` with multi-statement non-reraise body now flags as INFO."""
    src = (
        "def f():\n"
        "    try:\n"
        "        do_thing()\n"
        "    except Exception:\n"
        "        a = 1\n"
        "        b = 2\n"
        "        return None\n"
    )
    findings = _q(_check(src), "PROOFCTL-Q-002")
    assert findings, "Q-002 must fire on broad-except without re-raise"
    assert any(f.severity == Severity.INFO for f in findings)


def test_h16_broad_except_with_pass_still_warning():
    """Tier 1 (pass body) preserves WARNING severity."""
    src = "try:\n    x()\nexcept Exception:\n    pass\n"
    findings = _q(_check(src), "PROOFCTL-Q-002")
    assert findings and findings[0].severity == Severity.WARNING


def test_h16_broad_except_with_reraise_still_clean():
    """Re-raise inside the handler suppresses the rule entirely."""
    src = (
        "try:\n"
        "    x()\n"
        "except Exception as e:\n"
        "    log(e)\n"
        "    raise\n"
    )
    assert "PROOFCTL-Q-002" not in _ids(_check(src))


def test_h16_bare_except_remains_error():
    """Bare except: severity unchanged (ERROR)."""
    src = "try:\n    x()\nexcept:\n    pass\n"
    findings = _q(_check(src), "PROOFCTL-Q-002")
    assert findings and findings[0].severity == Severity.ERROR


# ── H-17: Q-005 — match/case adds to complexity ────────────────────────────


def test_h17_match_case_counts_toward_complexity():
    """A 12-arm match/case must trip the default complexity threshold (>10)."""
    arms = "\n".join(f"        case {i}: return {i}" for i in range(1, 13))
    src = f"def f(x):\n    match x:\n{arms}\n"
    findings = _q(_check(src), "PROOFCTL-Q-005")
    assert len(findings) == 1, f"expected Q-005 on 12-arm match; got {findings}"


def test_h17_small_match_case_clean():
    """A 2-arm match/case stays well under the default threshold."""
    src = (
        "def f(x):\n"
        "    match x:\n"
        "        case 1: return 'one'\n"
        "        case _: return 'other'\n"
    )
    assert "PROOFCTL-Q-005" not in _ids(_check(src))


# ── H-18: Q-007 — kwonly args counted ──────────────────────────────────────


def test_h18_kwonly_args_counted_for_q007():
    src = "def f(self, *, a, b, c, d, e, f, g, h):\n    pass\n"
    findings = _q(_check(src), "PROOFCTL-Q-007")
    assert len(findings) == 1, "Q-007 must count kwonly args (was missing self+8 kwonly)"


def test_h18_kwonly_mixed_with_positional():
    """Positional + kwonly together must combine."""
    # warn=3 → 4 total params (2 positional + 2 kwonly) > 3 fires.
    src = "def f(a, b, *, c, d):\n    pass\n"
    findings = _q(_check(src, param_warn=3, param_error=10), "PROOFCTL-Q-007")
    assert len(findings) == 1


# ── Q-009: path-based skips ────────────────────────────────────────────────


def test_q009_skipped_in_examples_dir():
    findings = _check("print('hi')\n", path="examples/demo.py")
    assert all(f.rule_id != "PROOFCTL-Q-009" for f in findings)


def test_q009_skipped_in_scripts_dir():
    findings = _check("print('hi')\n", path="scripts/run.py")
    assert all(f.rule_id != "PROOFCTL-Q-009" for f in findings)


def test_q009_skipped_in_samples_dir():
    findings = _check("print('hi')\n", path="samples/foo.py")
    assert all(f.rule_id != "PROOFCTL-Q-009" for f in findings)


def test_q009_skipped_when_shebang_present():
    src = "#!/usr/bin/env python3\nprint('hi')\n"
    findings = _check(src, path="bin/run.py")
    assert all(f.rule_id != "PROOFCTL-Q-009" for f in findings)


def test_q009_skipped_inside_main_guard():
    """print() inside `if __name__ == '__main__':` should not flag."""
    src = (
        "def main():\n"
        "    return 0\n"
        "if __name__ == '__main__':\n"
        "    print('starting')\n"
        "    main()\n"
    )
    findings = _check(src, path="proofctl/cli.py")
    assert all(f.rule_id != "PROOFCTL-Q-009" for f in findings)


def test_q009_still_flags_normal_module():
    """Sanity: production module without skip conditions still flags."""
    findings = _check("print('hi')\n", path="proofctl/core.py")
    assert "PROOFCTL-Q-009" in _ids(findings)


# ── Q-001: multi-line default → fixable=False ──────────────────────────────


def test_q001_single_line_default_remains_fixable():
    findings = _q(_check("def f(x=[]): pass\n"), "PROOFCTL-Q-001")
    assert findings and findings[0].fixable is True


def test_q001_multi_line_default_not_fixable():
    """Multi-line literal default: fixer cannot rewrite, so advertise honestly."""
    src = (
        "def f(\n"
        "    x={\n"
        "        'a': 1,\n"
        "        'b': 2,\n"
        "    },\n"
        "):\n"
        "    return x\n"
    )
    findings = _q(_check(src), "PROOFCTL-Q-001")
    assert findings, "Q-001 must still fire on multi-line mutable default"
    assert findings[0].fixable is False


# ── Q-008: setattr / dataclass exemptions ──────────────────────────────────


def test_q008_setattr_third_arg_exempt():
    """setattr(obj, 'flag', True) is a data write, not a flag-arg pattern."""
    src = "setattr(obj, 'flag', True)\n"
    assert "PROOFCTL-Q-008" not in _ids(_check(src))


def test_q008_setattr_with_false_also_exempt():
    src = "setattr(obj, 'enabled', False)\n"
    assert "PROOFCTL-Q-008" not in _ids(_check(src))


def test_q008_dataclass_constructor_positional_bool_exempt():
    """Boolean positional args to a @dataclass-decorated class init are field values."""
    src = (
        "from dataclasses import dataclass\n"
        "\n"
        "@dataclass\n"
        "class Config:\n"
        "    enabled: bool\n"
        "    verbose: bool\n"
        "\n"
        "cfg = Config(True, False)\n"
    )
    assert "PROOFCTL-Q-008" not in _ids(_check(src))


def test_q008_dataclasses_dataclass_qualified_form_exempt():
    """`@dataclasses.dataclass` (not the bare import) is also recognised."""
    src = (
        "import dataclasses\n"
        "\n"
        "@dataclasses.dataclass\n"
        "class C:\n"
        "    x: bool\n"
        "\n"
        "c = C(True)\n"
    )
    assert "PROOFCTL-Q-008" not in _ids(_check(src))


def test_q008_non_dataclass_call_still_flags():
    """Sanity: a regular function call with bool positional still fires."""
    src = "process(data, True)\n"
    assert "PROOFCTL-Q-008" in _ids(_check(src))


def test_q008_setattr_two_arg_not_exempt():
    """setattr() exemption requires the 3-arg form; weird 2-arg call should still flag."""
    # 2-arg setattr is invalid Python at runtime, but lints shouldn't blanket-exempt.
    src = "setattr(True, 'x')\n"
    # The first positional arg `True` would normally trip Q-008 because the
    # exemption only applies to the canonical 3-arg setattr signature.
    assert "PROOFCTL-Q-008" in _ids(_check(src))
