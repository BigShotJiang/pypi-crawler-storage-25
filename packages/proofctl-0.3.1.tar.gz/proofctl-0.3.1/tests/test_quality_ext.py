"""Tests for Q-005 through Q-009 (quality checker extensions)."""
from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.quality import QualityChecker
from proofctl.models import Severity

_P = Path("module.py")
_checker = QualityChecker(
    complexity_warn=5,   # low thresholds to keep tests concise
    complexity_error=10,
    func_len_warn=10,
    func_len_error=20,
    param_warn=3,
    param_error=5,
)


def _check(src: str):
    tree = ast.parse(src)
    return _checker.check(_P, src, tree)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# Q-005 — Cyclomatic complexity
# ══════════════════════════════════════════════════════════════════════════════


def test_q005_high_complexity():
    src = """
def decide(a, b, c, d, e, f):
    if a:
        return 1
    elif b:
        return 2
    elif c:
        return 3
    elif d:
        return 4
    elif e:
        return 5
    elif f:
        return 6
    return 0
"""
    # 7 branches → complexity = 8 > warn threshold of 5
    f = _find(_check(src), "PROOFCTL-Q-005")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_q005_complexity_error_threshold():
    # Build a function with >10 branches to hit error threshold
    branches = "\n".join(f"    elif x == {i}:\n        return {i}" for i in range(12))
    src = f"def big(x):\n    if x == 0:\n        return 0\n{branches}\n    return -1\n"
    f = _find(_check(src), "PROOFCTL-Q-005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_q005_simple_function_clean():
    src = """
def add(a, b):
    return a + b
"""
    assert "PROOFCTL-Q-005" not in _ids(_check(src))


def test_q005_nested_function_counted_separately():
    src = """
def outer(x):
    def inner(y):
        if y > 0:
            return y
        elif y < 0:
            return -y
        elif y == 0:
            return 0
        elif y > 100:
            return 100
        elif y < -100:
            return -100
        return y
    return inner(x)
"""
    # outer has complexity 1 (no branches) — should not fire for outer
    # inner has complexity 6 — should fire for inner only
    f = _find(_check(src), "PROOFCTL-Q-005")
    assert len(f) == 1
    assert f[0].message.startswith("'inner'")


# ══════════════════════════════════════════════════════════════════════════════
# Q-006 — Function too long
# ══════════════════════════════════════════════════════════════════════════════


def test_q006_long_function_warning():
    # 12-line body > warn threshold of 10
    body_lines = "\n".join(f"    x_{i} = {i}" for i in range(12))
    src = f"def long_func():\n{body_lines}\n    return x_0\n"
    f = _find(_check(src), "PROOFCTL-Q-006")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_q006_very_long_function_error():
    body_lines = "\n".join(f"    x_{i} = {i}" for i in range(22))
    src = f"def huge_func():\n{body_lines}\n    return x_0\n"
    f = _find(_check(src), "PROOFCTL-Q-006")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_q006_short_function_clean():
    src = """
def greet(name):
    return f"Hello, {name}"
"""
    assert "PROOFCTL-Q-006" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# Q-007 — Too many parameters
# ══════════════════════════════════════════════════════════════════════════════


def test_q007_too_many_params_warning():
    src = """
def process(a, b, c, d):
    return a + b + c + d
"""
    # 4 params > warn threshold of 3
    f = _find(_check(src), "PROOFCTL-Q-007")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_q007_too_many_params_error():
    src = """
def process(a, b, c, d, e, f):
    return a
"""
    # 6 params > error threshold of 5
    f = _find(_check(src), "PROOFCTL-Q-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_q007_self_not_counted():
    src = """
class Foo:
    def method(self, a, b, c, d):
        pass
"""
    # 4 params but self excluded → 4 > warn threshold of 3
    f = _find(_check(src), "PROOFCTL-Q-007")
    assert len(f) == 1


def test_q007_within_threshold_clean():
    src = """
def fetch(url, headers, timeout):
    pass
"""
    # exactly 3 params = warn threshold (not >), so no finding
    assert "PROOFCTL-Q-007" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# Q-008 — Boolean flag argument
# ══════════════════════════════════════════════════════════════════════════════


def test_q008_bool_positional_arg():
    src = """
result = process(data, True)
"""
    f = _find(_check(src), "PROOFCTL-Q-008")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_q008_false_positional_arg():
    src = """
render(template, False)
"""
    f = _find(_check(src), "PROOFCTL-Q-008")
    assert len(f) == 1


def test_q008_bool_keyword_arg_clean():
    """Keyword bool args are fine — they are self-documenting."""
    src = """
result = process(data, reverse=True)
"""
    assert "PROOFCTL-Q-008" not in _ids(_check(src))


def test_q008_assert_true_clean():
    """assertTrue(x) is a testing idiom — should not flag."""
    src = """
self.assertTrue(condition)
self.assertFalse(other)
"""
    assert "PROOFCTL-Q-008" not in _ids(_check(src))


def test_q008_assert_prefix_skipped():
    """Any assert* method (assertIs, assertIn, etc.) must not be flagged."""
    src = """
self.assertIs(result, True)
self.assertIn(True, [True, False])
self.assertRaises(ValueError, func, True)
"""
    assert "PROOFCTL-Q-008" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# Q-009 — print() in production code
# ══════════════════════════════════════════════════════════════════════════════


def test_q009_print_flagged():
    src = """
def handle_request(req):
    print(f"Received: {req}")
    return process(req)
"""
    f = _find(_check(src), "PROOFCTL-Q-009")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_q009_multiple_prints():
    src = """
print("Starting...")
result = compute()
print(f"Done: {result}")
"""
    f = _find(_check(src), "PROOFCTL-Q-009")
    assert len(f) == 2


def test_q009_logging_clean():
    src = """
import logging
logger = logging.getLogger(__name__)

def handle():
    logger.info("Starting")
    logger.debug("Details")
"""
    assert "PROOFCTL-Q-009" not in _ids(_check(src))


def test_q009_skipped_in_test_directory():
    """print() inside a tests/ directory must not be flagged."""
    import ast as _ast
    from proofctl.checkers.quality import QualityChecker
    test_path = Path("tests/test_utils.py")
    src = 'print("debugging in test")\n'
    tree = _ast.parse(src)
    findings = QualityChecker().check(test_path, src, tree)
    assert all(f.rule_id != "PROOFCTL-Q-009" for f in findings)


def test_q009_skipped_for_test_prefixed_file():
    """print() in test_foo.py must not be flagged."""
    import ast as _ast
    from proofctl.checkers.quality import QualityChecker
    test_path = Path("test_utils.py")
    src = 'print("debug")\n'
    tree = _ast.parse(src)
    findings = QualityChecker().check(test_path, src, tree)
    assert all(f.rule_id != "PROOFCTL-Q-009" for f in findings)
