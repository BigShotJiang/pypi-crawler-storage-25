from __future__ import annotations

import ast
import textwrap

from proofctl.fixer import _fix_mutable_defaults


def _fix(src: str) -> str:
    src = textwrap.dedent(src)
    tree = ast.parse(src)
    new_src, _result = _fix_mutable_defaults(src, tree)
    return new_src


# ── basic cases ───────────────────────────────────────────────────────────────

def test_list_default_replaced_with_none():
    result = _fix("""\
        def f(x, items=[]):
            return items
        """)
    assert "items=None" in result or "items = None" in result
    assert "items=[]" not in result


def test_sentinel_inserted():
    result = _fix("""\
        def f(x, items=[]):
            return items
        """)
    assert "if items is None:" in result
    assert "items = []" in result


def test_dict_default():
    result = _fix("""\
        def f(opts={}):
            return opts
        """)
    assert "opts=None" in result or "opts = None" in result
    assert "if opts is None:" in result
    assert "opts = {}" in result


def test_set_default():
    result = _fix("""\
        def f(seen=set()):
            pass
        """)
    assert "if seen is None:" in result
    assert "seen = set()" in result


def test_sentinel_after_docstring():
    result = _fix('''\
        def f(items=[]):
            """Does something."""
            return items
        ''')
    lines = result.splitlines()
    doc_idx = next(i for i, l in enumerate(lines) if '"""' in l)
    sentinel_idx = next(i for i, l in enumerate(lines) if "if items is None:" in l)
    assert sentinel_idx > doc_idx, "sentinel must come after docstring"


def test_sentinel_before_first_statement():
    result = _fix("""\
        def f(items=[]):
            x = 1
            return x
        """)
    lines = result.splitlines()
    sentinel_idx = next(i for i, l in enumerate(lines) if "if items is None:" in l)
    stmt_idx = next(i for i, l in enumerate(lines) if "x = 1" in l)
    assert sentinel_idx < stmt_idx


def test_indentation_preserved():
    src = "class A:\n    def f(self, items=[]):\n        return items\n"
    result = _fix(src)
    for line in result.splitlines():
        if "if items is None:" in line:
            assert line.startswith("        "), f"wrong indent: {line!r}"


def test_multiple_mutable_defaults_same_function():
    result = _fix("""\
        def f(a=[], b={}):
            return a, b
        """)
    assert "if a is None:" in result
    assert "if b is None:" in result
    assert "a = []" in result
    assert "b = {}" in result


def test_multiple_functions():
    result = _fix("""\
        def f(x=[]):
            return x

        def g(y={}):
            return y
        """)
    assert "if x is None:" in result
    assert "if y is None:" in result


def test_no_mutable_default_unchanged():
    src = "def f(x, y=None):\n    return x\n"
    assert _fix(src) == src


def test_async_function():
    result = _fix("""\
        async def fetch(items=[]):
            return items
        """)
    assert "items=None" in result or "items = None" in result
    assert "if items is None:" in result


def test_kwonly_default():
    result = _fix("""\
        def f(*, tags=[]):
            return tags
        """)
    assert "if tags is None:" in result
    assert "tags = []" in result


def test_nested_function():
    result = _fix("""\
        def outer():
            def inner(x=[]):
                return x
            return inner
        """)
    assert "if x is None:" in result


def test_result_parses_as_valid_python():
    src = textwrap.dedent("""\
        def process(items=[], opts={}):
            \"\"\"Process items.\"\"\"
            return items, opts
        """)
    result = _fix(src)
    # Must parse without error
    ast.parse(result)


def test_fix_does_not_duplicate_on_clean_file():
    """Running fix twice should produce the same result as running it once."""
    src = textwrap.dedent("""\
        def f(items=[]):
            return items
        """)
    once = _fix(src)
    tree2 = ast.parse(once)
    twice, _ = _fix_mutable_defaults(once, tree2)
    assert once == twice
