from __future__ import annotations

from pathlib import Path

import pytest

from proofctl.checkers.hcl_utils import HclBlock, parse_blocks
from proofctl.checkers.terraform import TerraformChecker, TerraformDirChecker
from proofctl.models import Severity

_P = Path("test.tf")
_checker = TerraformChecker()


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# hcl_utils — parser
# ══════════════════════════════════════════════════════════════════════════════


def test_parse_blocks_basic():
    src = """
resource "aws_instance" "web" {
  ami           = "ami-123"
  instance_type = "t3.micro"
}
variable "region" {
  description = "AWS region"
}
"""
    blocks = parse_blocks(src)
    assert len(blocks) == 2
    assert blocks[0].kind == "resource"
    assert blocks[0].label1 == "aws_instance"
    assert blocks[0].label2 == "web"
    assert blocks[1].kind == "variable"
    assert blocks[1].label1 == "region"


def test_parse_blocks_nested_returns_outer():
    src = """
resource "google_container_cluster" "main" {
  name = "my-cluster"
  private_cluster_config {
    enable_private_nodes = true
  }
}
"""
    blocks = parse_blocks(src)
    assert len(blocks) == 1
    assert blocks[0].kind == "resource"


def test_parse_blocks_heredoc_ignored():
    src = """
locals {
  policy = <<EOF
resource "fake" "this_is_inside_heredoc" {
}
EOF
}
"""
    blocks = parse_blocks(src)
    assert len(blocks) == 1
    assert blocks[0].kind == "locals"


def test_block_attr_returns_value_and_line():
    src = """
resource "aws_s3_bucket" "b" {
  bucket = "my-bucket"
}
"""
    block = parse_blocks(src)[0]
    result = block.attr("bucket")
    assert result is not None
    val, lineno = result
    assert val.strip('"') == "my-bucket"
    assert lineno == 3


def test_block_has_attr():
    src = 'resource "x" "y" {\n  foo = "bar"\n}\n'
    b = parse_blocks(src)[0]
    assert b.has_attr("foo")
    assert not b.has_attr("baz")


def test_block_nested():
    src = """
resource "google_container_cluster" "c" {
  name = "c"
  private_cluster_config {
    enable_private_nodes = true
  }
}
"""
    b = parse_blocks(src)[0]
    nested = b.nested("private_cluster_config")
    assert len(nested) == 1
    assert nested[0].kind == "private_cluster_config"


def test_block_any_line_matches():
    src = 'resource "x" "y" {\n  enable_private_nodes = false\n}\n'
    b = parse_blocks(src)[0]
    assert b.any_line_matches(r'enable_private_nodes\s*=\s*false') is not None
    assert b.any_line_matches(r'enable_private_nodes\s*=\s*true') is None


# ══════════════════════════════════════════════════════════════════════════════
# Group T — General Terraform
# ══════════════════════════════════════════════════════════════════════════════


def test_t001_empty_resource():
    src = 'resource "aws_instance" "bad" {\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_t001_non_empty_resource_clean():
    src = 'resource "aws_instance" "ok" {\n  ami = "ami-123"\n}\n'
    assert "PROOFCTL-TF-T001" not in _ids(_checker.check(_P, src))


def test_t002_useless_interpolation():
    src = 'resource "x" "y" {\n  region = "${var.region}"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T002")
    assert len(f) == 1


def test_t002_complex_expression_not_flagged():
    # Ternary inside "${...}" should NOT fire
    src = 'resource "x" "y" {\n  key = "${var.x != "" ? var.x : var.y}"\n}\n'
    assert "PROOFCTL-TF-T002" not in _ids(_checker.check(_P, src))


def test_t002_direct_reference_clean():
    src = 'resource "x" "y" {\n  region = var.region\n}\n'
    assert "PROOFCTL-TF-T002" not in _ids(_checker.check(_P, src))


def test_t003_missing_version():
    src = """
terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
    }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_t003_with_version_clean():
    src = """
terraform {
  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 5.0"
    }
  }
}
"""
    assert "PROOFCTL-TF-T003" not in _ids(_checker.check(_P, src))


def test_t004_open_ingress():
    src = """
resource "aws_security_group" "bad" {
  ingress {
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_t004_non_sensitive_port_not_flagged():
    # Port 443 (HTTPS) with 0.0.0.0/0 is NOT flagged as it's in _SENSITIVE_PORTS?
    # Actually 443 is NOT in _SENSITIVE_PORTS so should be clean.
    src = """
resource "aws_security_group" "ok" {
  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}
"""
    assert "PROOFCTL-TF-T004" not in _ids(_checker.check(_P, src))


def test_t005_hardcoded_secret():
    src = 'resource "aws_db_instance" "db" {\n  password = "supersecret123"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T005")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_t005_variable_reference_clean():
    src = 'resource "aws_db_instance" "db" {\n  password = var.db_password\n}\n'
    assert "PROOFCTL-TF-T005" not in _ids(_checker.check(_P, src))


def test_t005_short_value_not_flagged():
    # Value < 6 chars (e.g. empty or very short) should not fire
    src = 'resource "x" "y" {\n  password = ""\n}\n'
    assert "PROOFCTL-TF-T005" not in _ids(_checker.check(_P, src))


def test_t006_iam_wildcard():
    src = """
resource "aws_iam_policy" "bad" {
  policy = jsonencode({
    Statement = [{
      actions   = ["*"]
      resources = ["*"]
    }]
  })
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T006")
    assert len(f) >= 1


def test_t009_missing_description():
    src = 'variable "bucket_name" {\n  type = string\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T009")
    assert len(f) == 1


def test_t009_with_description_clean():
    src = 'variable "region" {\n  description = "AWS region"\n  default = "us-east-1"\n}\n'
    assert "PROOFCTL-TF-T009" not in _ids(_checker.check(_P, src))


def test_t012_deep_local_module_path():
    src = 'module "vpc" {\n  source = "../../../shared/vpc"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-T012")
    assert len(f) == 1


def test_t012_git_source_not_flagged():
    src = 'module "vpc" {\n  source = "git::https://github.com/org/modules.git?ref=v1.0"\n}\n'
    assert "PROOFCTL-TF-T012" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# Group M — Mechanics
# ══════════════════════════════════════════════════════════════════════════════


def test_m002_ignore_changes_all():
    src = """
resource "aws_instance" "w" {
  lifecycle {
    ignore_changes = all
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-M002")
    assert len(f) == 1


def test_m002_specific_ignore_changes_clean():
    src = """
resource "aws_instance" "w" {
  lifecycle {
    ignore_changes = [tags]
  }
}
"""
    assert "PROOFCTL-TF-M002" not in _ids(_checker.check(_P, src))


def test_m003_provisioner():
    src = """
resource "aws_instance" "w" {
  provisioner "remote-exec" {
    inline = ["echo hello"]
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-M003")
    assert len(f) == 1


def test_m004_null_resource():
    src = 'resource "null_resource" "wait" {\n  triggers = {}\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-M004")
    assert len(f) == 1


def test_m005_terraform_remote_state():
    src = 'data "terraform_remote_state" "network" {\n  backend = "gcs"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-M005")
    assert len(f) == 1


def test_m006_depends_on_module():
    src = 'module "app" {\n  source = "./app"\n  depends_on = [module.vpc]\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-M006")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Group V — Lifecycle
# ══════════════════════════════════════════════════════════════════════════════


def test_v001_force_destroy_prod():
    src = """
resource "aws_s3_bucket" "assets_prod" {
  bucket        = "my-prod-bucket"
  force_destroy = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-V001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_v001_force_destroy_dev_not_flagged():
    src = """
resource "aws_s3_bucket" "assets_dev" {
  bucket        = "my-dev-bucket"
  force_destroy = true
}
"""
    assert "PROOFCTL-TF-V001" not in _ids(_checker.check(_P, src))


def test_v003_missing_prevent_destroy():
    src = 'resource "aws_s3_bucket" "data" {\n  bucket = "my-data"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-V003")
    assert len(f) == 1


def test_v003_with_prevent_destroy_clean():
    src = """
resource "aws_s3_bucket" "data" {
  bucket = "my-data"
  lifecycle {
    prevent_destroy = true
  }
}
"""
    assert "PROOFCTL-TF-V003" not in _ids(_checker.check(_P, src))


def test_v004_git_no_ref():
    src = 'module "m" {\n  source = "git::https://github.com/org/mod.git"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-V004")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_v004_git_mutable_ref_named_branch():
    src = 'module "m" {\n  source = "git::https://github.com/org/mod.git?ref=main"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-V004")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "main" in f[0].message


def test_v004_git_mutable_ref_arbitrary_branch():
    """Any non-SHA / non-semver ref is mutable — catches feature/*, release/*, etc."""
    src = 'module "m" {\n  source = "git::https://github.com/org/mod.git?ref=feature/my-thing"\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-V004")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_v004_git_sha_ref_clean():
    sha = "a" * 40
    src = f'module "m" {{\n  source = "git::https://github.com/org/mod.git?ref={sha}"\n}}\n'
    assert "PROOFCTL-TF-V004" not in _ids(_checker.check(_P, src))


def test_v004_git_semver_ref_clean():
    src = 'module "m" {\n  source = "git::https://github.com/org/mod.git?ref=v1.2.3"\n}\n'
    assert "PROOFCTL-TF-V004" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# Group G — GCP (AI-slop headline rules)
# ══════════════════════════════════════════════════════════════════════════════


def test_g007_hallucinated_deletion_protection_enabled():
    """G-007 is the key AI-slop pattern: TF attribute is deletion_protection,
    but AI writes deletion_protection_enabled (the API field name) which is silently ignored."""
    src = """
resource "google_sql_database_instance" "main" {
  name             = "db"
  database_version = "POSTGRES_14"
  deletion_protection_enabled = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "silently ignored" in f[0].message


def test_g007_correct_attribute_clean():
    src = """
resource "google_sql_database_instance" "main" {
  name                = "db"
  deletion_protection = true
}
"""
    assert "PROOFCTL-TF-G007" not in _ids(_checker.check(_P, src))


def test_g011_workload_identity_node_pool_gap():
    """G-011: cluster has workload_identity_config but node pool lacks GKE_METADATA."""
    src = """
resource "google_container_cluster" "main" {
  name = "my-cluster"
  workload_identity_config {
    workload_pool = "my-project.svc.id.goog"
  }
}

resource "google_container_node_pool" "nodes" {
  name    = "default-pool"
  cluster = google_container_cluster.main.name
  node_config {
    machine_type = "e2-standard-4"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G011")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR
    assert "workload_metadata_config" in f[0].hint


def test_g011_node_pool_has_gke_metadata_clean():
    src = """
resource "google_container_cluster" "main" {
  name = "my-cluster"
  workload_identity_config {
    workload_pool = "my-project.svc.id.goog"
  }
}

resource "google_container_node_pool" "nodes" {
  name    = "default-pool"
  cluster = google_container_cluster.main.name
  node_config {
    workload_metadata_config {
      mode = "GKE_METADATA"
    }
  }
}
"""
    assert "PROOFCTL-TF-G011" not in _ids(_checker.check(_P, src))


def test_g011_no_cluster_wi_no_flag():
    """No workload_identity_config on cluster → G-011 should not fire."""
    src = """
resource "google_container_cluster" "main" {
  name = "my-cluster"
}

resource "google_container_node_pool" "nodes" {
  name    = "default-pool"
  cluster = google_container_cluster.main.name
  node_config {}
}
"""
    assert "PROOFCTL-TF-G011" not in _ids(_checker.check(_P, src))


def test_g001_serial_port():
    src = """
resource "google_compute_instance" "bad" {
  name = "vm"
  metadata = {
    "enable-serial-port" = "true"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G001")
    assert len(f) == 1


def test_g006_public_ip_sql():
    src = """
resource "google_sql_database_instance" "bad" {
  name = "db"
  settings {
    ip_configuration {
      ipv4_enabled = true
    }
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G006")
    assert len(f) == 1


def test_g012_legacy_abac():
    src = """
resource "google_container_cluster" "bad" {
  name               = "cluster"
  enable_legacy_abac = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G012")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g020_sa_key_resource():
    src = 'resource "google_service_account_key" "bad" {\n  service_account_id = google_service_account.sa.name\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G020")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_g021_broad_role_owner():
    src = """
resource "google_project_iam_member" "bad" {
  project = "my-project"
  role    = "roles/owner"
  member  = "user:admin@example.com"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G021")
    assert len(f) == 1


def test_g021_narrow_role_clean():
    src = """
resource "google_project_iam_member" "ok" {
  project = "my-project"
  role    = "roles/storage.objectViewer"
  member  = "serviceAccount:sa@project.iam.gserviceaccount.com"
}
"""
    assert "PROOFCTL-TF-G021" not in _ids(_checker.check(_P, src))


def test_g017_public_access_not_enforced():
    src = """
resource "google_storage_bucket" "bad" {
  name     = "my-bucket"
  location = "US"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G017")
    assert len(f) == 1


def test_g017_public_access_enforced_clean():
    src = """
resource "google_storage_bucket" "ok" {
  name                        = "my-bucket"
  location                    = "US"
  public_access_prevention    = "enforced"
  uniform_bucket_level_access = true
  lifecycle {
    prevent_destroy = true
  }
}
"""
    assert "PROOFCTL-TF-G017" not in _ids(_checker.check(_P, src))


# ══════════════════════════════════════════════════════════════════════════════
# Group A — AWS
# ══════════════════════════════════════════════════════════════════════════════


def test_a001_imdsv2_optional():
    src = """
resource "aws_instance" "bad" {
  ami           = "ami-123"
  instance_type = "t3.micro"
  metadata_options {
    http_tokens = "optional"
  }
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_a001_imdsv2_required_clean():
    src = """
resource "aws_instance" "ok" {
  ami           = "ami-123"
  instance_type = "t3.micro"
  metadata_options {
    http_tokens   = "required"
    http_endpoint = "enabled"
  }
}
"""
    assert "PROOFCTL-TF-A001" not in _ids(_checker.check(_P, src))


def test_a003_rds_skip_final_snapshot():
    src = """
resource "aws_db_instance" "bad" {
  identifier         = "mydb"
  skip_final_snapshot = true
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A003")
    assert len(f) >= 1


def test_a004_rds_no_backup():
    src = """
resource "aws_db_instance" "bad" {
  identifier             = "mydb"
  backup_retention_period = 0
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A004")
    assert len(f) == 1


def test_a007_ebs_not_encrypted():
    src = 'resource "aws_ebs_volume" "bad" {\n  availability_zone = "us-east-1a"\n  size = 20\n}\n'
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A007")
    assert len(f) == 1


def test_a007_ebs_encrypted_clean():
    src = 'resource "aws_ebs_volume" "ok" {\n  availability_zone = "us-east-1a"\n  encrypted = true\n}\n'
    assert "PROOFCTL-TF-A007" not in _ids(_checker.check(_P, src))


def test_a009_elasticache_no_tls():
    src = """
resource "aws_elasticache_replication_group" "bad" {
  replication_group_id     = "my-cache"
  transit_encryption_enabled = false
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-A009")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# Cross-file: TerraformDirChecker
# ══════════════════════════════════════════════════════════════════════════════


def test_m001_sg_inline_and_standalone(tmp_path):
    """M-001 fires when an SG has inline ingress AND a standalone rule references it."""
    sg_file = tmp_path / "sg.tf"
    sg_file.write_text("""
resource "aws_security_group" "web" {
  name = "web"
  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["10.0.0.0/8"]
  }
}
""")
    rule_file = tmp_path / "rules.tf"
    rule_file.write_text("""
resource "aws_security_group_rule" "extra" {
  type              = "ingress"
  security_group_id = aws_security_group.web.id
  from_port         = 443
  to_port           = 443
  protocol          = "tcp"
  cidr_blocks       = ["10.0.0.0/8"]
}
""")
    dir_checker = TerraformDirChecker()
    findings = dir_checker.check(tmp_path, [sg_file, rule_file])
    f = [x for x in findings if x.rule_id == "PROOFCTL-TF-M001"]
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_m001_standalone_only_clean(tmp_path):
    """Only standalone aws_security_group_rule, no inline — no M-001."""
    sg_file = tmp_path / "sg.tf"
    sg_file.write_text('resource "aws_security_group" "web" {\n  name = "web"\n}\n')
    rule_file = tmp_path / "rules.tf"
    rule_file.write_text("""
resource "aws_security_group_rule" "http" {
  type              = "ingress"
  security_group_id = aws_security_group.web.id
  from_port         = 80
  to_port           = 80
  protocol          = "tcp"
  cidr_blocks       = ["10.0.0.0/8"]
}
""")
    dir_checker = TerraformDirChecker()
    findings = dir_checker.check(tmp_path, [sg_file, rule_file])
    assert "PROOFCTL-TF-M001" not in [f.rule_id for f in findings]


def test_a002_s3_missing_public_access_block(tmp_path):
    """A-002 fires when a bucket has no companion aws_s3_bucket_public_access_block."""
    tf = tmp_path / "main.tf"
    tf.write_text('resource "aws_s3_bucket" "data" {\n  bucket = "my-data"\n}\n')
    dir_checker = TerraformDirChecker()
    findings = dir_checker.check(tmp_path, [tf])
    f = [x for x in findings if x.rule_id == "PROOFCTL-TF-A002"]
    assert len(f) == 1


def test_a002_s3_with_public_access_block_clean(tmp_path):
    tf = tmp_path / "main.tf"
    tf.write_text("""
resource "aws_s3_bucket" "data" {
  bucket = "my-data"
}

resource "aws_s3_bucket_public_access_block" "data" {
  bucket                  = aws_s3_bucket.data.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}
""")
    dir_checker = TerraformDirChecker()
    findings = dir_checker.check(tmp_path, [tf])
    assert "PROOFCTL-TF-A002" not in [f.rule_id for f in findings]


# ══════════════════════════════════════════════════════════════════════════════
# Group G — KMS (G-023, G-024, G-025)
# ══════════════════════════════════════════════════════════════════════════════


def test_g023_rotation_period_absent():
    src = """
resource "google_kms_crypto_key" "my_key" {
  name     = "my-key"
  key_ring = google_kms_key_ring.keyring.id
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G023")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g023_rotation_period_over_90_days():
    src = """
resource "google_kms_crypto_key" "my_key" {
  name            = "my-key"
  key_ring        = google_kms_key_ring.keyring.id
  rotation_period = "10000000s"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G023")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g023_rotation_period_90_days_clean():
    src = """
resource "google_kms_crypto_key" "my_key" {
  name            = "my-key"
  key_ring        = google_kms_key_ring.keyring.id
  rotation_period = "7776000s"
}
"""
    assert "PROOFCTL-TF-G023" not in _ids(_checker.check(_P, src))


def test_g024_kms_missing_prevent_destroy():
    src = """
resource "google_kms_crypto_key" "my_key" {
  name     = "my-key"
  key_ring = google_kms_key_ring.keyring.id
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G024")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g024_kms_with_prevent_destroy_clean():
    src = """
resource "google_kms_crypto_key" "my_key" {
  name     = "my-key"
  key_ring = google_kms_key_ring.keyring.id

  lifecycle {
    prevent_destroy = true
  }
}
"""
    assert "PROOFCTL-TF-G024" not in _ids(_checker.check(_P, src))


def test_g025_destroy_duration_absent():
    """G-025 fires when destroy_scheduled_duration is not set — GCP defaults to 24h."""
    src = """
resource "google_kms_crypto_key" "my_key" {
  name     = "my-key"
  key_ring = google_kms_key_ring.keyring.id
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G025")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "24h" in f[0].message


def test_g025_destroy_duration_too_short():
    src = """
resource "google_kms_crypto_key" "my_key" {
  name                       = "my-key"
  key_ring                   = google_kms_key_ring.keyring.id
  destroy_scheduled_duration = "86400s"
}
"""
    f = _find(_checker.check(_P, src), "PROOFCTL-TF-G025")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_g025_destroy_duration_7_days_clean():
    src = """
resource "google_kms_crypto_key" "my_key" {
  name                       = "my-key"
  key_ring                   = google_kms_key_ring.keyring.id
  destroy_scheduled_duration = "604800s"
}
"""
    assert "PROOFCTL-TF-G025" not in _ids(_checker.check(_P, src))
