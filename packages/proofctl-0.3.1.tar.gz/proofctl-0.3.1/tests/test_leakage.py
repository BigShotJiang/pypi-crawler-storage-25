from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.leakage import LeakageChecker
from proofctl.models import Severity


def _check(source: str) -> list:
    path = Path("test.py")
    try:
        tree = ast.parse(source)
    except SyntaxError:
        tree = None
    return LeakageChecker().check(path, source, tree)


def _rules(source: str) -> set[str]:
    return {f.rule_id for f in _check(source)}


# ── L-001 JavaScript ──────────────────────────────────────────────────────────

def test_l001_null_identifier():
    assert "PROOFCTL-L-001" in _rules("if x is null: pass\n")


def test_l001_undefined_identifier():
    assert "PROOFCTL-L-001" in _rules("if x is undefined: pass\n")


def test_l001_length_attribute():
    assert "PROOFCTL-L-001" in _rules("if arr.length > 0: pass\n")


def test_l001_push_method():
    assert "PROOFCTL-L-001" in _rules("items.push(x)\n")


def test_l001_console_log():
    assert "PROOFCTL-L-001" in _rules("console.log('hello')\n")


def test_l001_console_warn():
    assert "PROOFCTL-L-001" in _rules("console.warn('oops')\n")


def test_l001_typeof_regex():
    assert "PROOFCTL-L-001" in _rules("if typeof x == 'string': pass\n")


def test_l001_triple_equals_regex():
    src = "x === y\n"
    assert "PROOFCTL-L-001" in _rules(src)


def test_l001_arrow_function_regex():
    src = "handler = x => x + 1\n"
    assert "PROOFCTL-L-001" in _rules(src)


def test_l001_const_declaration_regex():
    src = "const result = get_data()\n"
    assert "PROOFCTL-L-001" in _rules(src)


def test_l001_var_declaration_regex():
    src = "var x = 5\n"
    assert "PROOFCTL-L-001" in _rules(src)


def test_l001_js_in_python_string_not_flagged():
    """const/var/=== inside a Python string should never be flagged — html_reporter pattern."""
    src = (
        'script = """\n'
        '<script>\n'
        'const rows = Array.from(document.querySelectorAll("tr"));\n'
        'var x = 5;\n'
        'if (a === b) { return; }\n'
        'const fn = x => x + 1;\n'
        '</script>\n'
        '"""\n'
    )
    assert "PROOFCTL-L-001" not in _rules(src)


def test_l001_none_not_flagged():
    assert "PROOFCTL-L-001" not in _rules("if x is None: pass\n")


def test_l001_len_not_flagged():
    assert "PROOFCTL-L-001" not in _rules("if len(arr) > 0: pass\n")


def test_l001_append_not_flagged():
    assert "PROOFCTL-L-001" not in _rules("items.append(x)\n")


# ── L-002 Java ────────────────────────────────────────────────────────────────

def test_l002_equals():
    assert "PROOFCTL-L-002" in _rules("if a.equals(b): pass\n")


def test_l002_to_string():
    assert "PROOFCTL-L-002" in _rules("label = obj.toString()\n")


def test_l002_size():
    assert "PROOFCTL-L-002" in _rules("if items.size() > 0: pass\n")


def test_l002_system_out_println():
    assert "PROOFCTL-L-002" in _rules("System.out.println('hi')\n")


def test_l002_getter_setter_pair():
    src = (
        "class User:\n"
        "    def getName(self): return self._name\n"
        "    def setName(self, v): self._name = v\n"
        "    def getEmail(self): return self._email\n"
        "    def setEmail(self, v): self._email = v\n"
    )
    assert "PROOFCTL-L-002" in _rules(src)


def test_l002_property_not_flagged():
    src = (
        "class User:\n"
        "    @property\n"
        "    def name(self): return self._name\n"
        "    @name.setter\n"
        "    def name(self, v): self._name = v\n"
    )
    assert "PROOFCTL-L-002" not in _rules(src)


def test_l002_python_equality_not_flagged():
    assert "PROOFCTL-L-002" not in _rules("if a == b: pass\n")


# ── L-003 Go ──────────────────────────────────────────────────────────────────

def test_l003_nil():
    assert "PROOFCTL-L-003" in _rules("if err is nil: pass\n")


def test_l003_fmt_println():
    assert "PROOFCTL-L-003" in _rules("fmt.Println('done')\n")


def test_l003_fmt_printf():
    assert "PROOFCTL-L-003" in _rules("fmt.Printf('%s', x)\n")


def test_l003_none_not_flagged():
    assert "PROOFCTL-L-003" not in _rules("if err is None: pass\n")


# ── severity ──────────────────────────────────────────────────────────────────

def test_js_syntax_leakage_is_error():
    findings = _check("const x = 5\n")
    assert all(f.severity == Severity.ERROR for f in findings if f.rule_id == "PROOFCTL-L-001")


def test_java_getter_setter_is_warning():
    src = (
        "class A:\n"
        "    def getFoo(self): return 1\n"
        "    def setFoo(self, v): pass\n"
        "    def getBar(self): return 2\n"
        "    def setBar(self, v): pass\n"
    )
    findings = _check(src)
    l002 = [f for f in findings if f.rule_id == "PROOFCTL-L-002"]
    assert l002[0].severity == Severity.WARNING
