from __future__ import annotations

from pathlib import Path

import pytest

from proofctl.checkers.variants import VariantChecker


def _check(root: Path, py_files: list[Path], **kw) -> list:
    return VariantChecker(**kw).check(root, py_files)


def _rules(root: Path, py_files: list[Path], **kw) -> set[str]:
    return {f.rule_id for f in _check(root, py_files, **kw)}


# ── V-001 Variant files ───────────────────────────────────────────────────────

def test_v001_v2_suffix(tmp_path):
    base = tmp_path / "service.py"
    variant = tmp_path / "service_v2.py"
    base.write_text("def f(): return 1\n")
    variant.write_text("def f(): return 2\n")
    rules = _rules(tmp_path, [base, variant])
    assert "PROOFCTL-V-001" in rules


def test_v001_new_suffix(tmp_path):
    base = tmp_path / "processor.py"
    variant = tmp_path / "processor_new.py"
    base.write_text("x = 1\n")
    variant.write_text("x = 2\n")
    assert "PROOFCTL-V-001" in _rules(tmp_path, [base, variant])


def test_v001_fixed_suffix(tmp_path):
    base = tmp_path / "handler.py"
    variant = tmp_path / "handler_fixed.py"
    base.write_text("x = 1\n")
    variant.write_text("x = 2\n")
    assert "PROOFCTL-V-001" in _rules(tmp_path, [base, variant])


def test_v001_old_suffix(tmp_path):
    base = tmp_path / "utils.py"
    variant = tmp_path / "utils_old.py"
    base.write_text("x = 1\n")
    variant.write_text("x = 2\n")
    assert "PROOFCTL-V-001" in _rules(tmp_path, [base, variant])


def test_v001_no_variant_ok(tmp_path):
    base = tmp_path / "service.py"
    other = tmp_path / "payment.py"
    base.write_text("x = 1\n")
    other.write_text("y = 2\n")
    assert "PROOFCTL-V-001" not in _rules(tmp_path, [base, other])


def test_v001_test_prefix_not_flagged(tmp_path):
    base = tmp_path / "service.py"
    test = tmp_path / "test_service.py"
    base.write_text("x = 1\n")
    test.write_text("def test_x(): pass\n")
    assert "PROOFCTL-V-001" not in _rules(tmp_path, [base, test])


def test_v001_migrations_dir_skipped(tmp_path):
    mig_dir = tmp_path / "migrations"
    mig_dir.mkdir()
    f1 = mig_dir / "0001_initial.py"
    f2 = mig_dir / "0002_add_field.py"
    f1.write_text("x = 1\n")
    f2.write_text("y = 2\n")
    # These don't match variant patterns, so should not be flagged regardless
    assert "PROOFCTL-V-001" not in _rules(tmp_path, [f1, f2])


def test_v001_finding_message(tmp_path):
    base = tmp_path / "svc.py"
    variant = tmp_path / "svc_new.py"
    base.write_text("x = 1\n")
    variant.write_text("x = 2\n")
    findings = _check(tmp_path, [base, variant])
    v001 = [f for f in findings if f.rule_id == "PROOFCTL-V-001"]
    assert v001
    assert "svc_new.py" in v001[0].message
    assert "svc.py" in v001[0].message


# ── V-002 Near-duplicate ──────────────────────────────────────────────────────

def _large_similar_pair(tmp_path, similarity: float = 0.95):
    """Creates two large files with high token similarity."""
    lines_a = ["x = 1", "y = 2", "z = 3"] * 15 + [f"a_{i} = {i}" for i in range(10)]
    lines_b = lines_a[:] + ["extra_b = True"]

    f1 = tmp_path / "module_a.py"
    f2 = tmp_path / "module_b.py"
    f1.write_text("\n".join(lines_a) + "\n")
    f2.write_text("\n".join(lines_b) + "\n")
    return f1, f2


def test_v002_similar_files_flagged(tmp_path):
    f1, f2 = _large_similar_pair(tmp_path)
    rules = _rules(tmp_path, [f1, f2], similarity_threshold=0.80, min_lines=5)
    assert "PROOFCTL-V-002" in rules


def test_v002_dissimilar_files_ok(tmp_path):
    f1 = tmp_path / "auth.py"
    f2 = tmp_path / "billing.py"
    f1.write_text("\n".join([f"auth_{i} = {i}" for i in range(40)]))
    f2.write_text("\n".join([f"bill_{i} = {i}" for i in range(40)]))
    rules = _rules(tmp_path, [f1, f2], similarity_threshold=0.80, min_lines=5)
    assert "PROOFCTL-V-002" not in rules


def test_v002_small_files_skipped(tmp_path):
    f1 = tmp_path / "a.py"
    f2 = tmp_path / "b.py"
    f1.write_text("x = 1\n" * 5)
    f2.write_text("x = 1\n" * 5)
    # Both are under min_lines=30, should not be compared
    rules = _rules(tmp_path, [f1, f2], similarity_threshold=0.80, min_lines=30)
    assert "PROOFCTL-V-002" not in rules


def test_v002_test_source_pair_skipped(tmp_path):
    f1, _ = _large_similar_pair(tmp_path)
    test_f = tmp_path / "test_module_a.py"
    test_f.write_text(f1.read_text())  # identical content
    rules = _rules(tmp_path, [f1, test_f], similarity_threshold=0.80, min_lines=5)
    assert "PROOFCTL-V-002" not in rules
