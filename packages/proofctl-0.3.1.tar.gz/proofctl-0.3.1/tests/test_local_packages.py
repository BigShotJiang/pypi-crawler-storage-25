"""Tests for `_local_packages` — deep-tree discovery of importable packages.

The original implementation only walked the project root and `src/`, which
caused PROOFCTL-I-001 to fire on legitimate private packages nested under
sub-trees (e.g. Airflow monorepos with `orchestration/dags/<pkg>/__init__.py`).

These tests pin down the new subtree-walking behaviour and the safety rails
(skip dirs, depth cap, symlink loop protection).
"""
from __future__ import annotations

import os
from pathlib import Path

import pytest

from proofctl.checkers.imports import _local_packages, _PKG_SCAN_MAX_DEPTH


def _mkpkg(root: Path, *parts: str) -> Path:
    """Create a Python package directory at root/parts/__init__.py."""
    pkg_dir = root.joinpath(*parts)
    pkg_dir.mkdir(parents=True, exist_ok=True)
    (pkg_dir / "__init__.py").write_text("")
    return pkg_dir


def _clear_cache():
    """The function is lru_cache-wrapped; clear between tests so tmp_path
    isolation isn't defeated by accidental cache hits across runs."""
    _local_packages.cache_clear()


def test_top_level_package_discovered(tmp_path):
    _clear_cache()
    _mkpkg(tmp_path, "myapp")
    assert "myapp" in _local_packages(tmp_path)


def test_src_layout_package_discovered(tmp_path):
    _clear_cache()
    _mkpkg(tmp_path, "src", "myapp")
    assert "myapp" in _local_packages(tmp_path)


def test_deeply_nested_package_discovered(tmp_path):
    """Regression: data_team layout — orchestration/dags/<pkg>/__init__.py."""
    _clear_cache()
    _mkpkg(tmp_path, "orchestration", "dags", "airflow_ip_taskgroups")
    _mkpkg(tmp_path, "orchestration", "dags", "reports_delivery")
    _mkpkg(tmp_path, "orchestration", "dags", "ip_run_output")
    pkgs = _local_packages(tmp_path)
    assert "airflow_ip_taskgroups" in pkgs
    assert "reports_delivery" in pkgs
    assert "ip_run_output" in pkgs


def test_top_level_module_discovered(tmp_path):
    _clear_cache()
    (tmp_path / "myscript.py").write_text("x = 1\n")
    assert "myscript" in _local_packages(tmp_path)


def test_init_only_counts_at_top_level(tmp_path):
    """A bare .py at depth>0 is a module, not a package — don't add its name.
    The previous code also followed this rule; preserving it."""
    _clear_cache()
    sub = tmp_path / "subdir"
    sub.mkdir()
    (sub / "helper.py").write_text("x = 1\n")
    assert "helper" not in _local_packages(tmp_path)


# ── safety rails ──────────────────────────────────────────────────────────────

def test_venv_packages_ignored(tmp_path):
    """A package vendored under .venv must not be treated as first-party."""
    _clear_cache()
    _mkpkg(tmp_path, ".venv", "lib", "python3.11", "site-packages", "requests")
    assert "requests" not in _local_packages(tmp_path)


def test_node_modules_ignored(tmp_path):
    _clear_cache()
    _mkpkg(tmp_path, "node_modules", "some_python_pkg")
    assert "some_python_pkg" not in _local_packages(tmp_path)


def test_pycache_ignored(tmp_path):
    _clear_cache()
    _mkpkg(tmp_path, "__pycache__", "fakepkg")
    assert "fakepkg" not in _local_packages(tmp_path)


def test_egg_info_ignored(tmp_path):
    _clear_cache()
    pkg = tmp_path / "proofctl.egg-info"
    pkg.mkdir()
    (pkg / "__init__.py").write_text("")
    assert "proofctl.egg-info" not in _local_packages(tmp_path)


def test_hidden_directories_skipped(tmp_path):
    """Hidden dirs other than .github are caches/IDE state — skip."""
    _clear_cache()
    _mkpkg(tmp_path, ".idea", "fakepkg")
    _mkpkg(tmp_path, ".vscode", "fakepkg2")
    pkgs = _local_packages(tmp_path)
    assert "fakepkg" not in pkgs
    assert "fakepkg2" not in pkgs


def test_symlink_loop_does_not_hang(tmp_path):
    """A symlink that points back into the tree must not trigger infinite recursion."""
    _clear_cache()
    _mkpkg(tmp_path, "real_pkg")
    # Create a symlink: tmp_path/loop -> tmp_path
    loop = tmp_path / "loop"
    try:
        os.symlink(tmp_path, loop)
    except (OSError, NotImplementedError):
        pytest.skip("symlinks not supported on this platform")
    # Should complete without recursion error.
    pkgs = _local_packages(tmp_path)
    assert "real_pkg" in pkgs


def test_depth_cap_does_not_explode(tmp_path):
    """Going deeper than _PKG_SCAN_MAX_DEPTH is silently truncated, not crashed."""
    _clear_cache()
    deep = tmp_path
    for i in range(_PKG_SCAN_MAX_DEPTH + 4):
        deep = deep / f"d{i}"
    deep.mkdir(parents=True)
    (deep / "__init__.py").write_text("")
    # Doesn't crash. Package at exactly depth N may or may not be found
    # (since it's beyond the cap), but the call must return.
    pkgs = _local_packages(tmp_path)
    assert isinstance(pkgs, frozenset)


def test_cache_avoids_repeated_walks(tmp_path):
    """Calling twice with the same root must hit the lru_cache."""
    _clear_cache()
    _mkpkg(tmp_path, "myapp")
    pkgs1 = _local_packages(tmp_path)
    pkgs2 = _local_packages(tmp_path)
    assert pkgs1 is pkgs2  # identity, not just equality — confirms cache hit


# ── integration with PROOFCTL-I-001 ───────────────────────────────────────────

def test_namespace_package_without_init_discovered(tmp_path):
    """PEP 420 namespace package — directory contains .py files but no
    __init__.py. Common in Airflow projects where dags_folder is on sys.path
    and DAG sub-directories are imported without __init__.py."""
    _clear_cache()
    pkg = tmp_path / "orchestration" / "dags" / "airflow_ip_taskgroups"
    pkg.mkdir(parents=True)
    (pkg / "hdm.py").write_text("def build(): pass\n")
    (pkg / "pre_hdm.py").write_text("def build(): pass\n")
    pkgs = _local_packages(tmp_path)
    assert "airflow_ip_taskgroups" in pkgs


def test_namespace_package_with_hyphen_name_skipped(tmp_path):
    """A directory like `schema-migrations/` containing .py files must not
    be added — its name is not a valid Python identifier so it can never
    appear as an import target."""
    _clear_cache()
    pkg = tmp_path / "database" / "schema-migrations"
    pkg.mkdir(parents=True)
    (pkg / "run.py").write_text("x = 1\n")
    pkgs = _local_packages(tmp_path)
    assert "schema-migrations" not in pkgs
    assert "schema_migrations" not in pkgs


def test_namespace_package_with_only_subdirs_not_added(tmp_path):
    """A directory whose `.py` files all live deeper than the immediate
    children is NOT added — keeps the false-negative surface narrow."""
    _clear_cache()
    pkg = tmp_path / "topdir"
    pkg.mkdir()
    nested = pkg / "deep" / "deeper"
    nested.mkdir(parents=True)
    (nested / "module.py").write_text("x = 1\n")
    # `topdir` has no direct .py — only via a 2-level descent. Don't add.
    pkgs = _local_packages(tmp_path)
    assert "topdir" not in pkgs
    # `deeper` (which directly contains module.py) IS added.
    assert "deeper" in pkgs


def test_i001_airflow_layout_no_false_positive(tmp_path):
    """End-to-end: an Airflow-style layout with no __init__.py files must
    not produce I-001 findings against the private namespace packages."""
    _clear_cache()
    (tmp_path / "pyproject.toml").write_text("[project]\nname='data_team'\n")
    pkg = tmp_path / "orchestration" / "dags" / "airflow_ip_taskgroups"
    pkg.mkdir(parents=True)
    (pkg / "hdm.py").write_text("def build(): pass\n")
    importer = tmp_path / "orchestration" / "dags" / "hdm.py"
    importer.write_text("from airflow_ip_taskgroups import build\n")

    from proofctl.engine import run_check
    from proofctl.config import ProofctlConfig
    cfg = ProofctlConfig()
    cfg.check_pypi = False
    findings = run_check(tmp_path, cfg, families=["I"])
    rule_ids = [f.rule_id for f in findings]
    assert "PROOFCTL-I-001" not in rule_ids, (
        f"namespace package import should not trigger I-001; got {rule_ids}"
    )


def test_i001_no_false_positive_on_nested_local_package(tmp_path):
    """End-to-end: a file importing a deeply-nested local package must not
    trigger PROOFCTL-I-001 even with PyPI lookups disabled."""
    _clear_cache()
    # Layout mirrors data_team:
    #   tmp_path/pyproject.toml
    #   tmp_path/orchestration/dags/airflow_ip_taskgroups/__init__.py
    #   tmp_path/orchestration/dags/hdm.py   (imports airflow_ip_taskgroups)
    (tmp_path / "pyproject.toml").write_text("[project]\nname='x'\n")
    _mkpkg(tmp_path, "orchestration", "dags", "airflow_ip_taskgroups")
    importer = tmp_path / "orchestration" / "dags" / "hdm.py"
    importer.write_text("from airflow_ip_taskgroups import build\n")

    from proofctl.engine import run_check
    from proofctl.config import ProofctlConfig

    cfg = ProofctlConfig()
    cfg.check_pypi = False  # don't even try PyPI; relying on local discovery
    findings = run_check(tmp_path, cfg, families=["I"])
    rule_ids = [f.rule_id for f in findings]
    assert "PROOFCTL-I-001" not in rule_ids, (
        f"Expected I-001 NOT to fire on local nested package; got: {rule_ids}"
    )
