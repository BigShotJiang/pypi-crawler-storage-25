"""Extended security checker tests — rules PROOFCTL-S-007 through S-013."""
from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.security import SecurityChecker
from proofctl.models import Severity

_P = Path("module.py")
_checker = SecurityChecker()


def _parse(src: str) -> ast.Module:
    return ast.parse(src)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


def _check(src: str):
    tree = _parse(src)
    return _checker.check(_P, src, tree)


# ══════════════════════════════════════════════════════════════════════════════
# S-007 — JWT algorithm confusion / signature bypass
# ══════════════════════════════════════════════════════════════════════════════


def test_s007_verify_signature_false():
    src = """
import jwt
payload = jwt.decode(token, options={"verify_signature": False})
"""
    f = _find(_check(src), "PROOFCTL-S-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s007_verify_exp_false():
    src = """
import jwt
payload = jwt.decode(token, key, options={"verify_exp": False})
"""
    f = _find(_check(src), "PROOFCTL-S-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s007_algorithms_none():
    src = """
import jwt
payload = jwt.decode(token, key, algorithms=["none"])
"""
    f = _find(_check(src), "PROOFCTL-S-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s007_algorithms_list_with_none():
    src = """
import jwt
payload = jwt.decode(token, key, algorithms=["HS256", "none"])
"""
    f = _find(_check(src), "PROOFCTL-S-007")
    assert len(f) == 1


def test_s007_jose_verify_signature_false():
    src = """
from jose import jwt
payload = jwt.decode(token, key, options={"verify_signature": False})
"""
    # jose.jwt.decode chain still ends with decode on a jwt attribute
    f = _find(_check(src), "PROOFCTL-S-007")
    assert len(f) == 1


def test_s007_clean_hs256_only():
    src = """
import jwt
payload = jwt.decode(token, secret, algorithms=["HS256"])
"""
    assert "PROOFCTL-S-007" not in _ids(_check(src))


def test_s007_clean_verify_signature_true():
    src = """
import jwt
payload = jwt.decode(token, secret, options={"verify_signature": True}, algorithms=["HS256"])
"""
    assert "PROOFCTL-S-007" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-008 — Path traversal via user-supplied path to open()
# ══════════════════════════════════════════════════════════════════════════════


def test_s008_open_request_args_get():
    src = """
f = open(request.args.get("filename"))
"""
    f = _find(_check(src), "PROOFCTL-S-008")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s008_open_request_form_subscript():
    src = """
f = open(request.form["file"])
"""
    f = _find(_check(src), "PROOFCTL-S-008")
    assert len(f) == 1


def test_s008_open_request_GET_get():
    src = """
f = open(request.GET.get("path"))
"""
    f = _find(_check(src), "PROOFCTL-S-008")
    assert len(f) == 1


def test_s008_open_path_param():
    # Phase-4 audit (H-14): S-008 now requires a tainted source rather than a
    # bare path-like parameter name. Use request.args.get(...) to taint the var.
    src = """
def read_file(request):
    filename = request.args.get("filename")
    return open(filename).read()
"""
    f = _find(_check(src), "PROOFCTL-S-008")
    assert len(f) == 1


def test_s008_open_filepath_param():
    # Phase-4 audit (H-14): tainted via os.environ propagated through os.path.join.
    src = """
import os
def serve():
    file_path = os.path.join("/srv", os.environ["TARGET"])
    with open(file_path) as fh:
        return fh.read()
"""
    f = _find(_check(src), "PROOFCTL-S-008")
    assert len(f) == 1


def test_s008_clean_literal_path():
    src = """
f = open("/etc/hosts")
"""
    assert "PROOFCTL-S-008" not in _ids(_check(src))


def test_s008_clean_safe_variable():
    src = """
safe_path = os.path.join(BASE_DIR, name)
f = open(safe_path)
"""
    assert "PROOFCTL-S-008" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-009 — Insecure UUID for security-sensitive values
# ══════════════════════════════════════════════════════════════════════════════


def test_s009_uuid1_for_token():
    src = """
import uuid
token = uuid.uuid1()
"""
    f = _find(_check(src), "PROOFCTL-S-009")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s009_uuid3_for_session_id():
    src = """
import uuid
session_id = uuid.uuid3(uuid.NAMESPACE_DNS, name)
"""
    f = _find(_check(src), "PROOFCTL-S-009")
    assert len(f) == 1


def test_s009_uuid1_for_api_key():
    src = """
import uuid
api_key = uuid.uuid1()
"""
    f = _find(_check(src), "PROOFCTL-S-009")
    assert len(f) == 1


def test_s009_uuid1_direct_import_for_secret():
    src = """
from uuid import uuid1
secret = uuid1()
"""
    f = _find(_check(src), "PROOFCTL-S-009")
    assert len(f) == 1


def test_s009_clean_uuid4_for_token():
    src = """
import uuid
token = uuid.uuid4()
"""
    assert "PROOFCTL-S-009" not in _ids(_check(src))


def test_s009_clean_uuid1_for_non_sensitive():
    src = """
import uuid
record_id = uuid.uuid1()
"""
    assert "PROOFCTL-S-009" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-010 — Secret value leaked into logs
# ══════════════════════════════════════════════════════════════════════════════


def test_s010_logging_fstring_with_password():
    src = """
import logging
logging.info(f"User password: {password}")
"""
    f = _find(_check(src), "PROOFCTL-S-010")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s010_logging_fstring_with_token():
    src = """
import logging
logging.debug(f"token={token}")
"""
    f = _find(_check(src), "PROOFCTL-S-010")
    assert len(f) == 1


def test_s010_logging_os_environ():
    src = """
import logging, os
logging.error(os.environ)
"""
    f = _find(_check(src), "PROOFCTL-S-010")
    assert len(f) == 1


def test_s010_logging_os_getenv_secret():
    src = """
import logging, os
logging.info(os.getenv("SECRET_KEY"))
"""
    f = _find(_check(src), "PROOFCTL-S-010")
    assert len(f) == 1


def test_s010_logger_error_with_secret_name():
    src = """
import logging
logger = logging.getLogger(__name__)
logger.error(api_key)
"""
    f = _find(_check(src), "PROOFCTL-S-010")
    assert len(f) == 1


def test_s010_clean_logging_safe_message():
    src = """
import logging
logging.info(f"User {user_id} logged in")
"""
    assert "PROOFCTL-S-010" not in _ids(_check(src))


def test_s010_clean_logging_literal():
    src = """
import logging
logging.info("Server started")
"""
    assert "PROOFCTL-S-010" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-011 — Insecure cipher mode via cryptography.hazmat
# ══════════════════════════════════════════════════════════════════════════════


def test_s011_ecb_mode():
    src = """
from cryptography.hazmat.primitives.ciphers import modes
cipher = modes.ECB()
"""
    f = _find(_check(src), "PROOFCTL-S-011")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s011_arc4():
    src = """
from cryptography.hazmat.primitives.ciphers import algorithms
cipher = algorithms.ARC4(key)
"""
    f = _find(_check(src), "PROOFCTL-S-011")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_s011_tripledes():
    src = """
from cryptography.hazmat.primitives.ciphers import algorithms
cipher = algorithms.TripleDES(key)
"""
    f = _find(_check(src), "PROOFCTL-S-011")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s011_clean_aes():
    src = """
from cryptography.hazmat.primitives.ciphers import algorithms, modes
cipher = algorithms.AES(key)
mode = modes.GCM(iv)
"""
    assert "PROOFCTL-S-011" not in _ids(_check(src))


def test_s011_clean_cbc():
    src = """
from cryptography.hazmat.primitives.ciphers import modes
mode = modes.CBC(iv)
"""
    assert "PROOFCTL-S-011" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-012 — Regex injection / ReDoS
# ══════════════════════════════════════════════════════════════════════════════


def test_s012_re_compile_variable():
    src = """
import re
pattern = re.compile(user_input)
"""
    f = _find(_check(src), "PROOFCTL-S-012")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s012_re_search_variable():
    src = """
import re
m = re.search(pattern, text)
"""
    f = _find(_check(src), "PROOFCTL-S-012")
    assert len(f) == 1


def test_s012_re_match_variable():
    src = """
import re
m = re.match(user_pattern, data)
"""
    f = _find(_check(src), "PROOFCTL-S-012")
    assert len(f) == 1


def test_s012_re_sub_variable():
    src = """
import re
result = re.sub(pattern, repl, text)
"""
    f = _find(_check(src), "PROOFCTL-S-012")
    assert len(f) == 1


def test_s012_clean_literal_pattern():
    src = r"""
import re
m = re.search(r"\d+", text)
"""
    assert "PROOFCTL-S-012" not in _ids(_check(src))


def test_s012_clean_re_compile_literal():
    src = r"""
import re
pattern = re.compile(r"^\w+$")
"""
    assert "PROOFCTL-S-012" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# S-013 — Open redirect
# ══════════════════════════════════════════════════════════════════════════════


def test_s013_redirect_request_args_get():
    src = """
from flask import redirect, request
return redirect(request.args.get("next"))
"""
    f = _find(_check(src), "PROOFCTL-S-013")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_s013_redirect_request_GET_get():
    src = """
from django.shortcuts import redirect
from django.http import HttpRequest
def view(request):
    return redirect(request.GET.get("next"))
"""
    f = _find(_check(src), "PROOFCTL-S-013")
    assert len(f) == 1


def test_s013_HttpResponseRedirect_request_POST():
    src = """
from django.http import HttpResponseRedirect
url = request.POST.get("return_url")
return HttpResponseRedirect(request.POST.get("return_url"))
"""
    f = _find(_check(src), "PROOFCTL-S-013")
    assert len(f) == 1


def test_s013_redirect_next_variable():
    src = """
from flask import redirect
next_url = request.args.get("next")
return redirect(next_url)
"""
    f = _find(_check(src), "PROOFCTL-S-013")
    assert len(f) == 1


def test_s013_redirect_return_url_variable():
    src = """
from flask import redirect
return redirect(return_url)
"""
    f = _find(_check(src), "PROOFCTL-S-013")
    assert len(f) == 1


def test_s013_clean_redirect_literal():
    src = """
from flask import redirect
return redirect("/dashboard")
"""
    assert "PROOFCTL-S-013" not in _ids(_check(src))


def test_s013_clean_redirect_safe_variable():
    src = """
from flask import redirect
destination = get_safe_url(next_hop)
return redirect(destination)
"""
    assert "PROOFCTL-S-013" not in _ids(_check(src))
