"""Regression tests for AUDIT_AND_ROADMAP Phase 4 (security.py tightening).

Each test corresponds to an audit item:
  H-11  dead `_pending_random` list removed (no behavioural test — covered indirectly)
  H-12  attribute-target detection for random / UUID / secret-leak rules
  H-13  S-006 timeout: sessions, aiohttp, urllib, urllib3
  H-14  S-008 path-traversal taint analysis
  H-15  S-012 regex skipped for module-level constants

  Medium 6   S-003 from-import loads/load
  Medium 7   S-004 pycryptodome / cryptography.hazmat MD5/SHA1
  Medium 8   S-007 jwt.decode(verify=False) legacy form
  Medium 9   S-013 RedirectResponse / werkzeug.utils.redirect
  Medium 10  S-010 logger extra={"token": secret}
"""
from __future__ import annotations

import ast
from pathlib import Path

from proofctl.checkers.security import SecurityChecker


def _check(src: str) -> list:
    tree = ast.parse(src)
    return SecurityChecker().check(Path("test.py"), src, tree)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _by_id(findings, rule_id: str) -> list:
    return [f for f in findings if f.rule_id == rule_id]


# ─────────────────────────────────────────────────────────────────────────────
# H-11: dead _pending_random list removed.
# ─────────────────────────────────────────────────────────────────────────────


def test_h11_random_for_token_still_fires():
    """Ensure removing _pending_random did not regress the basic case."""
    src = "import random\ntoken = random.random()\n"
    assert "PROOFCTL-S-004" in _ids(_check(src))


def test_h11_no_double_fire_on_random_token():
    """Should fire exactly once even after the dead-code path was removed."""
    src = "import random\napi_key = random.randint(0, 999)\n"
    assert len(_by_id(_check(src), "PROOFCTL-S-004")) == 1


# ─────────────────────────────────────────────────────────────────────────────
# H-12: attribute-target random / UUID / secret detection.
# ─────────────────────────────────────────────────────────────────────────────


def test_h12_random_to_self_token_flagged():
    src = (
        "import random\n"
        "class C:\n"
        "    def f(self):\n"
        "        self.token = random.random()\n"
    )
    f = _by_id(_check(src), "PROOFCTL-S-004")
    assert len(f) >= 1


def test_h12_random_to_obj_attr_flagged():
    src = (
        "import random\n"
        "obj.api_key = random.choice(pool)\n"
    )
    f = _by_id(_check(src), "PROOFCTL-S-004")
    assert len(f) >= 1


def test_h12_uuid1_to_self_attr_flagged():
    src = (
        "import uuid\n"
        "class A:\n"
        "    def make(self):\n"
        "        self.session_id = uuid.uuid1()\n"
    )
    f = _by_id(_check(src), "PROOFCTL-S-009")
    assert len(f) >= 1


def test_h12_uuid_attribute_target_non_sensitive_clean():
    src = (
        "import uuid\n"
        "class A:\n"
        "    def make(self):\n"
        "        self.record_id = uuid.uuid1()\n"
    )
    assert "PROOFCTL-S-009" not in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# H-13: S-006 timeout — session vars, aiohttp, urllib, urllib3.
# ─────────────────────────────────────────────────────────────────────────────


def test_h13_requests_session_get_no_timeout():
    src = (
        "import requests\n"
        "session = requests.Session()\n"
        "r = session.get('https://example.com')\n"
    )
    assert "PROOFCTL-S-006" in _ids(_check(src))


def test_h13_requests_session_get_with_timeout_clean():
    src = (
        "import requests\n"
        "session = requests.Session()\n"
        "r = session.get('https://example.com', timeout=10)\n"
    )
    assert "PROOFCTL-S-006" not in _ids(_check(src))


def test_h13_httpx_client_post_no_timeout():
    src = (
        "import httpx\n"
        "client = httpx.Client()\n"
        "r = client.post('https://example.com', json={})\n"
    )
    assert "PROOFCTL-S-006" in _ids(_check(src))


def test_h13_httpx_async_client_no_timeout():
    src = (
        "import httpx\n"
        "client = httpx.AsyncClient()\n"
        "r = client.get('https://example.com')\n"
    )
    assert "PROOFCTL-S-006" in _ids(_check(src))


def test_h13_aiohttp_session_no_timeout():
    src = (
        "import aiohttp\n"
        "session = aiohttp.ClientSession()\n"
        "r = session.get('https://example.com')\n"
    )
    assert "PROOFCTL-S-006" in _ids(_check(src))


def test_h13_urllib_request_urlopen_no_timeout():
    src = (
        "import urllib.request\n"
        "r = urllib.request.urlopen('https://example.com')\n"
    )
    assert "PROOFCTL-S-006" in _ids(_check(src))


def test_h13_urllib_urlopen_with_timeout_clean():
    src = (
        "import urllib.request\n"
        "r = urllib.request.urlopen('https://example.com', timeout=30)\n"
    )
    assert "PROOFCTL-S-006" not in _ids(_check(src))


def test_h13_urllib3_pool_request_no_timeout():
    src = (
        "import urllib3\n"
        "pool = urllib3.PoolManager()\n"
        "r = pool.request('GET', 'https://example.com')\n"
    )
    assert "PROOFCTL-S-006" in _ids(_check(src))


def test_h13_session_attribute_assignment():
    """`self.session = requests.Session()` then `self.session.get(...)`."""
    src = (
        "import requests\n"
        "class C:\n"
        "    def __init__(self):\n"
        "        self.session = requests.Session()\n"
        "    def fetch(self):\n"
        "        return self.session.get('https://example.com')\n"
    )
    assert "PROOFCTL-S-006" in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# H-14: S-008 path-traversal taint analysis.
# ─────────────────────────────────────────────────────────────────────────────


def test_h14_bare_filename_param_no_longer_fires():
    """The old bare-name regex should no longer trigger without taint."""
    src = (
        "def read(filename):\n"
        "    return open(filename).read()\n"
    )
    assert "PROOFCTL-S-008" not in _ids(_check(src))


def test_h14_request_param_tainted_open_fires():
    src = (
        "def view(request):\n"
        "    name = request.args.get('f')\n"
        "    return open(name).read()\n"
    )
    assert "PROOFCTL-S-008" in _ids(_check(src))


def test_h14_os_environ_taint_through_join():
    src = (
        "import os\n"
        "p = os.path.join('/srv', os.environ['NAME'])\n"
        "open(p).read()\n"
    )
    assert "PROOFCTL-S-008" in _ids(_check(src))


def test_h14_sys_argv_taint():
    src = (
        "import sys\n"
        "p = sys.argv[1]\n"
        "open(p)\n"
    )
    assert "PROOFCTL-S-008" in _ids(_check(src))


def test_h14_clean_internal_var_no_finding():
    """A locally-constructed safe path should NOT fire."""
    src = (
        "BASE = '/srv/data'\n"
        "p = BASE + '/static/log.txt'\n"
        "open(p)\n"
    )
    assert "PROOFCTL-S-008" not in _ids(_check(src))


def test_h14_taint_propagates_through_pathlib():
    src = (
        "from pathlib import Path\n"
        "def view(request):\n"
        "    name = request.form['file']\n"
        "    p = Path(name)\n"
        "    open(p).read()\n"
    )
    assert "PROOFCTL-S-008" in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# H-15: S-012 regex skipped for module-level constants.
# ─────────────────────────────────────────────────────────────────────────────


def test_h15_module_constant_pattern_skipped():
    src = (
        "import re\n"
        "EMAIL_RE = r'[a-z]+@[a-z]+\\.com'\n"
        "re.match(EMAIL_RE, 'a@b.com')\n"
    )
    assert "PROOFCTL-S-012" not in _ids(_check(src))


def test_h15_local_variable_pattern_still_fires():
    """Patterns built dynamically in functions are still flagged."""
    src = (
        "import re\n"
        "def f(user):\n"
        "    pattern = build(user)\n"
        "    re.match(pattern, 'x')\n"
    )
    assert "PROOFCTL-S-012" in _ids(_check(src))


def test_h15_user_supplied_pattern_still_fires():
    src = (
        "import re\n"
        "def view(request):\n"
        "    re.match(request.args.get('p'), 'x')\n"
    )
    assert "PROOFCTL-S-012" in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# Medium 6: S-003 from-import loads/load.
# ─────────────────────────────────────────────────────────────────────────────


def test_med6_from_pickle_import_loads():
    src = (
        "from pickle import loads\n"
        "obj = loads(data)\n"
    )
    assert "PROOFCTL-S-003" in _ids(_check(src))


def test_med6_from_marshal_import_load():
    src = (
        "from marshal import load\n"
        "obj = load(fh)\n"
    )
    assert "PROOFCTL-S-003" in _ids(_check(src))


def test_med6_unrelated_loads_clean():
    """`from json import loads` must not be flagged."""
    src = (
        "from json import loads\n"
        "obj = loads(data)\n"
    )
    assert "PROOFCTL-S-003" not in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# Medium 7: S-004 pycryptodome / cryptography.hazmat MD5.
# ─────────────────────────────────────────────────────────────────────────────


def test_med7_pycryptodome_md5_new_flagged():
    src = (
        "from Crypto.Hash import MD5\n"
        "h = Crypto.Hash.MD5.new()\n"
    )
    assert "PROOFCTL-S-004" in _ids(_check(src))


def test_med7_cryptography_hashes_md5_flagged():
    src = (
        "from cryptography.hazmat.primitives import hashes\n"
        "h = hashes.MD5()\n"
    )
    assert "PROOFCTL-S-004" in _ids(_check(src))


def test_med7_cryptography_hashes_sha256_clean():
    src = (
        "from cryptography.hazmat.primitives import hashes\n"
        "h = hashes.SHA256()\n"
    )
    assert "PROOFCTL-S-004" not in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# Medium 8: S-007 jwt.decode(verify=False) legacy form.
# ─────────────────────────────────────────────────────────────────────────────


def test_med8_jwt_decode_verify_false():
    src = (
        "import jwt\n"
        "p = jwt.decode(token, verify=False)\n"
    )
    assert "PROOFCTL-S-007" in _ids(_check(src))


def test_med8_jwt_decode_verify_true_clean():
    src = (
        "import jwt\n"
        "p = jwt.decode(token, key, algorithms=['HS256'])\n"
    )
    assert "PROOFCTL-S-007" not in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# Medium 9: S-013 RedirectResponse / werkzeug.utils.redirect.
# ─────────────────────────────────────────────────────────────────────────────


def test_med9_redirect_response_starlette():
    src = (
        "from starlette.responses import RedirectResponse\n"
        "def view(request):\n"
        "    return RedirectResponse(request.args.get('next'))\n"
    )
    assert "PROOFCTL-S-013" in _ids(_check(src))


def test_med9_werkzeug_utils_redirect():
    src = (
        "import werkzeug.utils\n"
        "def view(request):\n"
        "    return werkzeug.utils.redirect(request.args.get('next'))\n"
    )
    assert "PROOFCTL-S-013" in _ids(_check(src))


# ─────────────────────────────────────────────────────────────────────────────
# Medium 10: S-010 logger extra={"token": secret_value}.
# ─────────────────────────────────────────────────────────────────────────────


def test_med10_logger_extra_kwarg_with_secret_key():
    src = (
        "import logging\n"
        "logger = logging.getLogger(__name__)\n"
        "logger.info('msg', extra={'token': value})\n"
    )
    assert "PROOFCTL-S-010" in _ids(_check(src))


def test_med10_logger_extra_kwarg_with_secret_value():
    src = (
        "import logging\n"
        "logger = logging.getLogger(__name__)\n"
        "logger.info('msg', extra={'context': password})\n"
    )
    assert "PROOFCTL-S-010" in _ids(_check(src))


def test_med10_logger_extra_kwarg_clean():
    src = (
        "import logging\n"
        "logger = logging.getLogger(__name__)\n"
        "logger.info('msg', extra={'user_id': uid, 'request_id': rid})\n"
    )
    assert "PROOFCTL-S-010" not in _ids(_check(src))
