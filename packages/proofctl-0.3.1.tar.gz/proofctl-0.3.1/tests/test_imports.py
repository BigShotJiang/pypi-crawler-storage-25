from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from proofctl.checkers.imports import (
    DependencyChecker,
    _parse_requirements,
    _parse_pyproject_deps,
    _suspicious_variant_of,
)
from proofctl.models import Severity


def _check_deps(content: str, filename: str = "requirements.txt") -> list:
    path = Path(filename)
    checker = DependencyChecker()
    # Write to a temp path — checker reads from real filesystem
    import tempfile, os
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=os.path.basename(filename),
        delete=False, encoding="utf-8"
    ) as f:
        f.write(content)
        tmp = Path(f.name)
    try:
        return checker._check_dep_file(tmp)
    finally:
        tmp.unlink(missing_ok=True)


def _rules(findings: list) -> set[str]:
    return {f.rule_id for f in findings}


# ── _suspicious_variant_of ────────────────────────────────────────────────────
# True positives: AI hallucination patterns that SHOULD be flagged

def test_variant_python_prefix_popular():
    assert _suspicious_variant_of("python-openai") == "openai"

def test_variant_python_prefix_requests():
    assert _suspicious_variant_of("python-requests") == "requests"

def test_variant_python_prefix_flask():
    assert _suspicious_variant_of("python-flask") == "flask"

def test_variant_trailing_python():
    assert _suspicious_variant_of("openai-python") == "openai"

def test_variant_trailing_py():
    assert _suspicious_variant_of("anthropic-py") == "anthropic"

def test_variant_utils_suffix():
    assert _suspicious_variant_of("openai-utils") == "openai"

def test_variant_extras_suffix():
    assert _suspicious_variant_of("pydantic-extras") == "pydantic"

def test_variant_helpers_suffix():
    assert _suspicious_variant_of("fastapi-helpers") == "fastapi"

def test_variant_enhanced_suffix():
    assert _suspicious_variant_of("langchain-enhanced") == "langchain"

def test_variant_extended_suffix():
    assert _suspicious_variant_of("sqlalchemy-extended") == "sqlalchemy"

def test_variant_digit_increment():
    # boto4 is the classic hallucination — predecessor boto3 is in popular set
    assert _suspicious_variant_of("boto4") == "boto3"

def test_variant_multi_hyphen_extras():
    # langchain-community-extras: rpartition gives base=langchain-community, suffix=extras
    # langchain-community is NOT in popular set → should not flag (avoids false positive on community)
    result = _suspicious_variant_of("langchain-community-extras")
    assert result is None  # base "langchain-community" not in popular

# False positives: legitimate packages that must NOT be flagged

def test_no_fp_python_dateutil():
    # python-dateutil is the canonical PyPI name — 'dateutil' not in popular set
    assert _suspicious_variant_of("python-dateutil") is None

def test_no_fp_python_dotenv():
    # python-dotenv is canonical — 'dotenv' not in popular set
    assert _suspicious_variant_of("python-dotenv") is None

def test_no_fp_python_slugify():
    assert _suspicious_variant_of("python-slugify") is None

def test_no_fp_python_multipart():
    assert _suspicious_variant_of("python-multipart") is None

def test_no_fp_python_jose():
    assert _suspicious_variant_of("python-jose") is None

def test_no_fp_requests_toolbelt():
    # 'toolbelt' is not in _SUSPICIOUS_SUFFIXES
    assert _suspicious_variant_of("requests-toolbelt") is None

def test_no_fp_flask_login():
    # 'login' is not in _SUSPICIOUS_SUFFIXES
    assert _suspicious_variant_of("flask-login") is None

def test_no_fp_flask_cors():
    assert _suspicious_variant_of("flask-cors") is None

def test_no_fp_pytest_mock():
    assert _suspicious_variant_of("pytest-mock") is None

def test_no_fp_pytest_cov():
    assert _suspicious_variant_of("pytest-cov") is None

def test_no_fp_pytest_asyncio():
    assert _suspicious_variant_of("pytest-asyncio") is None

def test_no_fp_sqlalchemy_utils():
    # sqlalchemy-utils is a real, popular package — it's in _POPULAR_PACKAGES
    assert _suspicious_variant_of("sqlalchemy-utils") is None

def test_no_fp_django_rest_framework():
    # 'rest-framework' after rpartition gives suffix 'framework', not suspicious
    assert _suspicious_variant_of("django-rest-framework") is None

def test_no_fp_celery_beat():
    assert _suspicious_variant_of("celery-beat") is None

def test_no_fp_factory_boy():
    # factory-boy is a real package and is in _POPULAR_PACKAGES
    assert _suspicious_variant_of("factory-boy") is None

def test_no_fp_popular_package_itself():
    # Popular packages must never be flagged as their own variant
    assert _suspicious_variant_of("requests") is None
    assert _suspicious_variant_of("openai") is None
    assert _suspicious_variant_of("flask") is None

def test_no_fp_digit_no_predecessor():
    # requests3: predecessor is requests2, which is NOT in popular set
    assert _suspicious_variant_of("requests3") is None

def test_no_fp_numpy2():
    # numpy1 not in popular → not flagged via digit rule
    assert _suspicious_variant_of("numpy2") is None


# ── _parse_requirements ───────────────────────────────────────────────────────

def test_parse_req_plain():
    deps = _parse_requirements("requests\n")
    assert deps[0][0] == "requests"
    assert deps[0][1] is None


def test_parse_req_pinned():
    deps = _parse_requirements("requests==2.31.0\n")
    assert deps[0][0] == "requests"
    assert "==" in deps[0][1]


def test_parse_req_constrained():
    deps = _parse_requirements("requests>=2.0\n")
    assert deps[0][0] == "requests"
    assert deps[0][1] == ">=2.0"


def test_parse_req_with_extras():
    deps = _parse_requirements("typer[all]>=0.12\n")
    assert deps[0][0] == "typer"


def test_parse_req_skips_comments():
    deps = _parse_requirements("# this is a comment\nrequests\n")
    assert len(deps) == 1
    assert deps[0][0] == "requests"


def test_parse_req_skips_flags():
    deps = _parse_requirements("-r other.txt\nrequests\n")
    assert len(deps) == 1


# ── _parse_pyproject_deps ─────────────────────────────────────────────────────

def test_parse_pyproject_simple():
    txt = textwrap.dedent("""\
        [project]
        dependencies = [
            "requests",
            "typer>=0.12",
        ]
    """)
    deps = _parse_pyproject_deps(txt)
    names = [d[0] for d in deps]
    assert "requests" in names
    assert "typer" in names


def test_parse_pyproject_pinned():
    txt = 'dependencies = [\n    "boto4==1.0.0",\n]\n'
    deps = _parse_pyproject_deps(txt)
    assert deps[0][0] == "boto4"
    assert "==" in deps[0][1]


# ── DependencyChecker (I-002) ─────────────────────────────────────────────────

def test_i002_known_hallucination_unpinned():
    findings = _check_deps("boto4\n")
    assert any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_known_hallucination_severity_error_when_unpinned():
    findings = _check_deps("boto4\n")
    i002 = [f for f in findings if f.rule_id == "PROOFCTL-I-002"]
    assert i002[0].severity == Severity.ERROR


def test_i002_known_hallucination_severity_warning_when_pinned():
    findings = _check_deps("boto4==1.0.0\n")
    i002 = [f for f in findings if f.rule_id == "PROOFCTL-I-002"]
    assert i002[0].severity == Severity.WARNING


def test_i002_real_package_not_flagged():
    findings = _check_deps("requests==2.31.0\n")
    assert not any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_real_package_unpinned_not_flagged():
    findings = _check_deps("flask\n")
    assert not any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_confusion_variant_flagged():
    findings = _check_deps("python-openai\n")
    assert any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_openai_utils_flagged():
    findings = _check_deps("openai-utils\n")
    assert any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_pyproject_toml_flagged():
    content = 'dependencies = [\n    "boto4",\n]\n'
    findings = _check_deps(content, filename="pyproject.toml")
    assert any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_line_number_correct():
    content = "requests==2.31.0\nboto4\n"
    findings = _check_deps(content)
    i002 = [f for f in findings if f.rule_id == "PROOFCTL-I-002"]
    assert i002[0].line == 2


def test_i002_multiple_flagged():
    content = "boto4\nopenai-utils\nrequests\n"
    findings = [f for f in _check_deps(content) if f.rule_id == "PROOFCTL-I-002"]
    assert len(findings) == 2


def test_i002_pattern_match_not_in_static_list():
    # flask-extras is NOT in _HIGH_RISK_DEPS static list — caught by pattern matching
    findings = _check_deps("flask-extras\n")
    assert any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_pattern_match_digit_increment():
    findings = _check_deps("boto4\n")
    # boto4 is in static list AND matches digit pattern — either path works
    assert any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_no_fp_python_dotenv():
    findings = _check_deps("python-dotenv==1.0.0\n")
    assert not any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_no_fp_flask_login():
    findings = _check_deps("flask-login\n")
    assert not any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_no_fp_requests_toolbelt():
    findings = _check_deps("requests-toolbelt\n")
    assert not any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_no_fp_sqlalchemy_utils():
    findings = _check_deps("sqlalchemy-utils\n")
    assert not any(f.rule_id == "PROOFCTL-I-002" for f in findings)


def test_i002_extra_high_risk():
    import tempfile, os
    checker = DependencyChecker(extra_high_risk=["my-fake-lib"])
    content = "my-fake-lib\n"
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".txt", delete=False, encoding="utf-8"
    ) as f:
        f.write(content)
        tmp = Path(f.name)
    try:
        findings = checker._check_dep_file(tmp)
    finally:
        tmp.unlink(missing_ok=True)
    assert any(f.rule_id == "PROOFCTL-I-002" for f in findings)
