"""Regression tests for AUDIT_AND_ROADMAP Phase 6 — DF/YAML/SH hardening.

Section 1.5 of the audit identified false positives and false negatives in
the Dockerfile, YAML/K8s/GHA, and shell-script checkers. This module covers
each finding with at least one focused regression test.
"""
from __future__ import annotations

from pathlib import Path

from proofctl.checkers.dockerfile import DockerfileRulesChecker
from proofctl.checkers.shell_checker import ShellRulesChecker
from proofctl.checkers.yaml_checker import YamlRulesChecker


# ── helpers ──────────────────────────────────────────────────────────────────


def _df(src: str) -> list:
    return DockerfileRulesChecker().check(Path("Dockerfile"), src)


def _yaml(src: str, name: str = "test.yaml") -> list:
    return YamlRulesChecker().check(Path(name), src)


def _sh(src: str, name: str = "test.sh") -> list:
    return ShellRulesChecker().check(Path(name), src)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


# ════════════════════════════════════════════════════════════════════════════
# DF-001: SHA-384 / SHA-512 digests are valid OCI image-spec digests
# ════════════════════════════════════════════════════════════════════════════


def test_df001_accepts_sha384_digest():
    src = "FROM nginx:1.25@sha384:" + "a" * 96 + "\nCMD nginx\n"
    assert "PROOFCTL-DF-001" not in _ids(_df(src))


def test_df001_accepts_sha512_digest():
    src = "FROM nginx:1.25@sha512:" + "a" * 128 + "\nCMD nginx\n"
    assert "PROOFCTL-DF-001" not in _ids(_df(src))


def test_df001_still_accepts_sha256_digest():
    """Backward-compat — broadening the regex must not regress sha256."""
    src = "FROM python:3.12@sha256:" + "a" * 64 + "\nCMD python\n"
    assert "PROOFCTL-DF-001" not in _ids(_df(src))


def test_df001_rejects_short_sha384():
    """sha384 with the wrong digest length must not silently pass."""
    src = "FROM nginx:1.25@sha384:" + "a" * 64 + "\nCMD nginx\n"
    assert "PROOFCTL-DF-001" in _ids(_df(src))


def test_df001_still_fires_on_unpinned_latest():
    src = "FROM nginx:latest\nCMD nginx\n"
    assert "PROOFCTL-DF-001" in _ids(_df(src))


# ════════════════════════════════════════════════════════════════════════════
# DF-008: walk full RUN continuation chain for sha256/sha512/gpg verification
# ════════════════════════════════════════════════════════════════════════════


def test_df008_sha512sum_in_chain_clears():
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "RUN sha512sum -c /tmp/tool.tar.gz.sha512\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" not in _ids(_df(src))


def test_df008_gpg_verify_in_chain_clears():
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "RUN gpg --verify /tmp/tool.tar.gz.sig /tmp/tool.tar.gz\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" not in _ids(_df(src))


def test_df008_verification_far_down_the_chain_clears():
    """Verification more than 3 RUN instructions later still counts now."""
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "RUN echo step1\n"
        "RUN echo step2\n"
        "RUN echo step3\n"
        "RUN echo step4\n"
        "RUN sha256sum -c /tmp/tool.tar.gz.sha256\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" not in _ids(_df(src))


def test_df008_no_verification_anywhere_still_flags():
    src = (
        "FROM ubuntu:22.04\n"
        "ADD https://example.com/tool.tar.gz /tmp/tool.tar.gz\n"
        "RUN tar xzf /tmp/tool.tar.gz -C /opt\n"
        "USER app\nCMD bash\n"
    )
    assert "PROOFCTL-DF-008" in _ids(_df(src))


# ════════════════════════════════════════════════════════════════════════════
# DF-009: multi-stage builds — only flag broad COPY in the FINAL stage
# ════════════════════════════════════════════════════════════════════════════


def test_df009_multistage_builder_copy_dot_clean():
    """Builder stage doing COPY . then pip install is the canonical
    multi-stage pattern — must not fire."""
    src = (
        "FROM python:3.12 AS builder\n"
        "COPY . /src\n"
        "RUN pip install /src\n"
        "FROM python:3.12-slim\n"
        "COPY --from=builder /usr/local/lib/python3.12 /usr/local/lib/python3.12\n"
        "USER nobody\n"
        "CMD python -m app\n"
    )
    assert "PROOFCTL-DF-009" not in _ids(_df(src))


def test_df009_single_stage_still_flags():
    src = (
        "FROM python:3.12\n"
        "COPY . /app\n"
        "RUN pip install -r requirements.txt\n"
        "CMD python app.py\n"
    )
    assert "PROOFCTL-DF-009" in _ids(_df(src))


def test_df009_multistage_final_stage_flagged():
    """If the FINAL stage has COPY . before pip install, still flag."""
    src = (
        "FROM python:3.12 AS builder\n"
        "RUN echo build\n"
        "FROM python:3.12-slim\n"
        "COPY . /app\n"
        "RUN pip install -r /app/requirements.txt\n"
        "CMD python app.py\n"
    )
    assert "PROOFCTL-DF-009" in _ids(_df(src))


# ════════════════════════════════════════════════════════════════════════════
# YAML — anchor / alias resolution for K8s securityContext rules
# ════════════════════════════════════════════════════════════════════════════


def test_yaml_anchor_securitycontext_not_flagged():
    """An anchored securityContext re-used via alias must satisfy the
    runAsNonRoot/allowPrivilegeEscalation/readOnlyRootFilesystem rules
    just as if it had been written inline."""
    src = (
        "apiVersion: v1\n"
        "kind: Pod\n"
        "metadata:\n"
        "  name: anchored\n"
        "spec:\n"
        "  _sc: &sc\n"
        "    runAsNonRoot: true\n"
        "    allowPrivilegeEscalation: false\n"
        "    readOnlyRootFilesystem: true\n"
        "    seccompProfile:\n"
        "      type: RuntimeDefault\n"
        "    capabilities:\n"
        "      drop: [ALL]\n"
        "  containers:\n"
        "  - name: c\n"
        "    image: busybox:1.36\n"
        "    securityContext: *sc\n"
    )
    found = set(_ids(_yaml(src)))
    for rid in (
        "PROOFCTL-YAML-009",
        "PROOFCTL-YAML-010",
        "PROOFCTL-YAML-011",
        "PROOFCTL-YAML-012",
        "PROOFCTL-YAML-013",
    ):
        assert rid not in found, f"anchor false-positive: {rid} fired"


# ════════════════════════════════════════════════════════════════════════════
# YAML — _DupKeyLoader state must reset between docs in a multi-doc stream
# ════════════════════════════════════════════════════════════════════════════


def test_yaml_dup_key_multi_doc_clean_second_doc():
    """Doc 1 has a duplicate key, doc 2 is clean. Doc 2 must not inherit
    findings from doc 1."""
    src = (
        "foo: 1\n"
        "foo: 2\n"
        "---\n"
        "bar: 1\n"
        "baz: 2\n"
    )
    findings = _yaml(src)
    dup_findings = [f for f in findings if f.rule_id == "PROOFCTL-YAML-002"]
    # Exactly one finding — for doc 1's `foo` duplicate.
    assert len(dup_findings) == 1


def test_yaml_dup_key_multi_doc_each_doc_independent():
    """Both docs duplicate independent keys — both must be reported."""
    src = (
        "foo: 1\n"
        "foo: 2\n"
        "---\n"
        "bar: 1\n"
        "bar: 2\n"
    )
    findings = _yaml(src)
    dup_findings = [f for f in findings if f.rule_id == "PROOFCTL-YAML-002"]
    assert len(dup_findings) == 2


# ════════════════════════════════════════════════════════════════════════════
# YAML — capability matching is case-insensitive
# ════════════════════════════════════════════════════════════════════════════


def test_yaml_capabilities_lowercase_dangerous_caught():
    """Lowercase `sys_admin` in capabilities.add must still be flagged
    as a dangerous capability."""
    src = (
        "apiVersion: v1\n"
        "kind: Pod\n"
        "metadata:\n"
        "  name: low\n"
        "spec:\n"
        "  containers:\n"
        "  - name: c\n"
        "    image: busybox:1.36\n"
        "    securityContext:\n"
        "      runAsNonRoot: true\n"
        "      allowPrivilegeEscalation: false\n"
        "      readOnlyRootFilesystem: true\n"
        "      seccompProfile:\n"
        "        type: RuntimeDefault\n"
        "      capabilities:\n"
        "        drop: [ALL]\n"
        "        add:\n"
        "          - sys_admin\n"
    )
    findings = _yaml(src)
    yaml012 = [f for f in findings if f.rule_id == "PROOFCTL-YAML-012"]
    # The dangerous-cap branch must fire even though the input was lowercase.
    assert any("sys_admin" in f.message.lower() for f in yaml012)


def test_yaml_capabilities_lowercase_drop_all_satisfies():
    """Lowercase `all` in capabilities.drop must satisfy the drop-all
    requirement (no YAML-012 'does not drop ALL' finding)."""
    src = (
        "apiVersion: v1\n"
        "kind: Pod\n"
        "metadata:\n"
        "  name: low\n"
        "spec:\n"
        "  containers:\n"
        "  - name: c\n"
        "    image: busybox:1.36\n"
        "    securityContext:\n"
        "      runAsNonRoot: true\n"
        "      allowPrivilegeEscalation: false\n"
        "      readOnlyRootFilesystem: true\n"
        "      seccompProfile:\n"
        "        type: RuntimeDefault\n"
        "      capabilities:\n"
        "        drop: [all]\n"
    )
    findings = _yaml(src)
    drop_findings = [
        f for f in findings
        if f.rule_id == "PROOFCTL-YAML-012" and "does not drop" in f.message
    ]
    assert drop_findings == []


# ════════════════════════════════════════════════════════════════════════════
# SH-001: shebang accepts trailing arguments
# ════════════════════════════════════════════════════════════════════════════


def test_sh001_accepts_shebang_with_args():
    src = "#!/bin/bash -euxo pipefail\necho hi\n"
    assert "PROOFCTL-SH-001" not in _ids(_sh(src))


def test_sh001_accepts_env_bash_with_args():
    src = "#!/usr/bin/env bash\necho hi\n"
    assert "PROOFCTL-SH-001" not in _ids(_sh(src))


def test_sh001_still_flags_missing_shebang():
    src = "echo hi\n"
    assert "PROOFCTL-SH-001" in _ids(_sh(src))


# ════════════════════════════════════════════════════════════════════════════
# SH-005: guarded rm -rf "/$VAR" must not fire
# ════════════════════════════════════════════════════════════════════════════


def test_sh005_inline_double_bracket_guard_clean():
    src = (
        "#!/bin/bash\n"
        "set -euo pipefail\n"
        '[[ -n "$TARGET" ]] && rm -rf "/$TARGET"\n'
    )
    assert "PROOFCTL-SH-005" not in _ids(_sh(src))


def test_sh005_preceding_if_guard_clean():
    src = (
        "#!/bin/bash\n"
        "set -euo pipefail\n"
        'if [ -n "$TARGET" ]; then\n'
        '  rm -rf "/$TARGET"\n'
        "fi\n"
    )
    assert "PROOFCTL-SH-005" not in _ids(_sh(src))


def test_sh005_unguarded_still_flags():
    src = (
        "#!/bin/bash\n"
        "set -euo pipefail\n"
        'rm -rf "/$TARGET"\n'
    )
    assert "PROOFCTL-SH-005" in _ids(_sh(src))


def test_sh005_guard_for_different_var_still_flags():
    """Guarding a *different* variable than the one used in rm -rf
    must not silence the finding."""
    src = (
        "#!/bin/bash\n"
        "set -euo pipefail\n"
        '[[ -n "$OTHER" ]] && rm -rf "/$TARGET"\n'
    )
    assert "PROOFCTL-SH-005" in _ids(_sh(src))
