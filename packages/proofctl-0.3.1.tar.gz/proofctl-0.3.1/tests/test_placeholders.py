from __future__ import annotations

import ast
from pathlib import Path

import pytest

from proofctl.checkers.placeholders import PlaceholderChecker
from proofctl.models import Severity


def _check(source: str, **kw) -> list:
    path = Path("test.py")
    try:
        tree = ast.parse(source)
    except SyntaxError:
        tree = None
    return PlaceholderChecker(**kw).check(path, source, tree)


def _rules(source: str, **kw) -> set[str]:
    return {f.rule_id for f in _check(source, **kw)}


# ── P-001 ─────────────────────────────────────────────────────────────────────

def test_p001_pass_body():
    findings = _check("def process(x):\n    pass\n")
    assert any(f.rule_id == "PROOFCTL-P-001" for f in findings)


def test_p001_ellipsis_body():
    findings = _check("def process(x):\n    ...\n")
    assert any(f.rule_id == "PROOFCTL-P-001" for f in findings)


def test_p001_raise_not_implemented():
    src = 'def process(x):\n    raise NotImplementedError("TODO")\n'
    findings = _check(src)
    assert any(f.rule_id == "PROOFCTL-P-001" for f in findings)


def test_p001_docstring_only():
    src = 'def process(x):\n    """Processes x."""\n'
    findings = _check(src)
    assert any(f.rule_id == "PROOFCTL-P-001" for f in findings)
    assert findings[0].severity == Severity.WARNING


def test_p001_pass_is_error():
    findings = _check("def f():\n    pass\n")
    p001 = [f for f in findings if f.rule_id == "PROOFCTL-P-001"]
    assert p001[0].severity == Severity.ERROR


def test_p001_implemented_not_flagged():
    src = "def f():\n    return 42\n"
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_return_none_with_optional_annotation_not_flagged():
    """Hook methods that declare -> str | None should not be flagged."""
    src = "def _primary_tool(self) -> str | None:\n    return None\n"
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_return_none_no_annotation_not_flagged():
    """Without an annotation we can't tell if None is wrong — don't flag."""
    src = "def get_cached():\n    return None\n"
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_return_none_concrete_annotation_flagged():
    """If the annotation promises float but body is just `return None`, flag it."""
    src = "def compute(x: int) -> float:\n    return None\n"
    assert "PROOFCTL-P-001" in _rules(src)


def test_p001_abstractmethod_not_flagged():
    src = (
        "from abc import ABC, abstractmethod\n"
        "class Base(ABC):\n"
        "    @abstractmethod\n"
        "    def f(self):\n"
        "        ...\n"
    )
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_protocol_not_flagged():
    src = (
        "from typing import Protocol\n"
        "class Repo(Protocol):\n"
        "    def find(self, id: int): ...\n"
    )
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_overload_not_flagged():
    src = (
        "from typing import overload\n"
        "class F:\n"
        "    @overload\n"
        "    def f(self, x: int) -> int: ...\n"
    )
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_init_not_flagged():
    src = "class A:\n    def __init__(self):\n        pass\n"
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_async_function():
    src = "async def fetch():\n    pass\n"
    assert "PROOFCTL-P-001" in _rules(src)


def test_p001_nested_function():
    src = "def outer():\n    def inner():\n        pass\n    return inner\n"
    assert "PROOFCTL-P-001" in _rules(src)


def test_p001_line_number():
    src = "\n\ndef late():\n    pass\n"
    findings = [f for f in _check(src) if f.rule_id == "PROOFCTL-P-001"]
    assert findings[0].line == 3


# ── P-002 ─────────────────────────────────────────────────────────────────────

def test_p002_todo_flagged():
    src = "x = 1  # TODO: finish this\n"
    assert "PROOFCTL-P-002" in _rules(src)


def test_p002_fixme_flagged():
    src = "# FIXME: this is broken\n"
    assert "PROOFCTL-P-002" in _rules(src)


def test_p002_no_comment_not_flagged():
    src = "x = 1\n"
    assert "PROOFCTL-P-002" not in _rules(src)


def test_p002_allowed_format_skipped():
    src = "# TODO(#123): tracked issue\n"
    checker = PlaceholderChecker(todo_allowed_formats=[r"TODO\(#\d+\)"])
    path = Path("test.py")
    tree = ast.parse(src)
    findings = checker.check(path, src, tree)
    assert not any(f.rule_id == "PROOFCTL-P-002" for f in findings)


def test_p002_excluded_path_skipped():
    src = "# TODO: skip me\n"
    checker = PlaceholderChecker(todo_exclude_paths=["test.py"])
    path = Path("test.py")
    tree = ast.parse(src)
    findings = checker.check(path, src, tree)
    assert not any(f.rule_id == "PROOFCTL-P-002" for f in findings)


# ── P-003 ─────────────────────────────────────────────────────────────────────

def test_p003_commented_code_flagged():
    src = (
        "x = 1\n"
        "# result = do_thing()\n"
        "# if result:\n"
        "#     return result\n"
        "y = 2\n"
    )
    assert "PROOFCTL-P-003" in _rules(src)


def test_p003_prose_comment_not_flagged():
    src = (
        "# This function processes payments.\n"
        "# It takes an amount and returns a receipt.\n"
        "# The receipt is a dict with status and tx_id.\n"
    )
    assert "PROOFCTL-P-003" not in _rules(src)


def test_p003_two_lines_not_flagged():
    src = "# x = 1\n# y = 2\n"
    assert "PROOFCTL-P-003" not in _rules(src)


# ── P-001 → Any annotation (A-08) ────────────────────────────────────────────

def test_p001_return_none_any_annotation_not_flagged():
    """-> Any includes None as a valid return — should not flag."""
    src = "from typing import Any\ndef fetch(key: str) -> Any:\n    return None\n"
    assert "PROOFCTL-P-001" not in _rules(src)


def test_p001_return_none_typing_any_attribute_not_flagged():
    """typing.Any attribute reference should also be skipped."""
    import ast as _ast
    from pathlib import Path as _Path
    from proofctl.checkers.placeholders import PlaceholderChecker
    src = "import typing\ndef fetch() -> typing.Any:\n    return None\n"
    tree = _ast.parse(src)
    checker = PlaceholderChecker()
    findings = checker.check(_Path("mod.py"), src, tree)
    assert all(f.rule_id != "PROOFCTL-P-001" for f in findings)


# ── P-002 path exclusion component check (A-07) ──────────────────────────────

def test_p002_similar_dirname_not_excluded():
    """'other_migrations' must not be excluded when 'migrations/' is configured."""
    import ast as _ast
    from pathlib import Path as _Path
    from proofctl.checkers.placeholders import PlaceholderChecker
    src = "x = 1  # TODO fix this\n"
    tree = _ast.parse(src)
    checker = PlaceholderChecker(todo_exclude_paths=["migrations/"])
    path = _Path("other_migrations") / "mod.py"
    findings = checker.check(path, src, tree)
    # Should NOT be excluded — different directory name
    p002 = [f for f in findings if f.rule_id == "PROOFCTL-P-002"]
    assert len(p002) == 1


def test_p002_exact_dirname_excluded():
    """Files inside 'migrations/' must be excluded from P-002."""
    import ast as _ast
    from pathlib import Path as _Path
    from proofctl.checkers.placeholders import PlaceholderChecker
    src = "x = 1  # TODO fix this\n"
    tree = _ast.parse(src)
    checker = PlaceholderChecker(todo_exclude_paths=["migrations/"])
    path = _Path("migrations") / "0001_initial.py"
    findings = checker.check(path, src, tree)
    assert all(f.rule_id != "PROOFCTL-P-002" for f in findings)
