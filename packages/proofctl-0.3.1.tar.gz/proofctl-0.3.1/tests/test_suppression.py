from __future__ import annotations

import ast
from pathlib import Path

from proofctl.engine import _load_suppressions, _is_suppressed
from proofctl.models import Finding, Severity


def _finding(rule_id: str, line: int, file: str = "test.py") -> Finding:
    return Finding(
        file=file,
        line=line,
        col=0,
        rule_id=rule_id,
        rule_name="Test",
        severity=Severity.ERROR,
        message="test",
    )


# ── _load_suppressions ────────────────────────────────────────────────────────

def test_load_no_suppressions():
    assert _load_suppressions("x = 1\n") == {}


def test_load_single_rule():
    src = "x = 1  # proofctl: ignore[PROOFCTL-P-001]\n"
    supps = _load_suppressions(src)
    assert supps == {1: {"PROOFCTL-P-001"}}


def test_load_multiple_rules_comma_separated():
    src = "x = 1  # proofctl: ignore[PROOFCTL-P-001, PROOFCTL-L-001]\n"
    supps = _load_suppressions(src)
    assert supps[1] == {"PROOFCTL-P-001", "PROOFCTL-L-001"}


def test_load_extra_whitespace():
    src = "x = 1  #  proofctl:  ignore[ PROOFCTL-P-001 ]\n"
    supps = _load_suppressions(src)
    assert "PROOFCTL-P-001" in supps[1]


def test_load_multiline():
    src = "x = 1\ny = 2  # proofctl: ignore[PROOFCTL-Q-001]\nz = 3\n"
    supps = _load_suppressions(src)
    assert 2 in supps
    assert 1 not in supps
    assert 3 not in supps


def test_load_line_numbers_correct():
    src = "\n\nx = 1  # proofctl: ignore[PROOFCTL-P-001]\n"
    supps = _load_suppressions(src)
    assert 3 in supps


# ── _is_suppressed ────────────────────────────────────────────────────────────

def test_is_suppressed_matching_rule():
    f = _finding("PROOFCTL-P-001", 1)
    supps = {"test.py": {1: {"PROOFCTL-P-001"}}}
    assert _is_suppressed(f, supps)


def test_is_not_suppressed_different_rule():
    f = _finding("PROOFCTL-P-002", 1)
    supps = {"test.py": {1: {"PROOFCTL-P-001"}}}
    assert not _is_suppressed(f, supps)


def test_is_not_suppressed_different_line():
    f = _finding("PROOFCTL-P-001", 2)
    supps = {"test.py": {1: {"PROOFCTL-P-001"}}}
    assert not _is_suppressed(f, supps)


def test_is_not_suppressed_different_file():
    f = _finding("PROOFCTL-P-001", 1, file="other.py")
    supps = {"test.py": {1: {"PROOFCTL-P-001"}}}
    assert not _is_suppressed(f, supps)


def test_is_not_suppressed_no_line():
    f = Finding(
        file="test.py", line=None, col=0,
        rule_id="PROOFCTL-P-001", rule_name="X",
        severity=Severity.ERROR, message="x",
    )
    supps = {"test.py": {1: {"PROOFCTL-P-001"}}}
    assert not _is_suppressed(f, supps)


def test_multiple_rules_one_matches():
    f = _finding("PROOFCTL-L-001", 5)
    supps = {"test.py": {5: {"PROOFCTL-P-001", "PROOFCTL-L-001", "PROOFCTL-Q-002"}}}
    assert _is_suppressed(f, supps)


def test_empty_suppressions():
    f = _finding("PROOFCTL-P-001", 1)
    assert not _is_suppressed(f, {})


# ── Line-adjacency edge cases (A-39) ─────────────────────────────────────────

def test_suppress_comment_on_line_before_not_suppressed():
    """# proofctl: ignore on line N must NOT suppress a finding on line N+1."""
    f = _finding("PROOFCTL-P-001", line=2)  # finding is on line 2
    # suppress is on line 1 — should NOT match
    supps = {"test.py": {1: {"PROOFCTL-P-001"}}}
    assert not _is_suppressed(f, supps)


def test_suppress_comment_on_line_after_not_suppressed():
    """# proofctl: ignore on line N+1 must NOT suppress a finding on line N."""
    f = _finding("PROOFCTL-P-001", line=1)
    supps = {"test.py": {2: {"PROOFCTL-P-001"}}}
    assert not _is_suppressed(f, supps)


def test_suppress_exact_line_match():
    """Suppress on the exact same line as the finding must suppress it."""
    f = _finding("PROOFCTL-P-001", line=5)
    supps = {"test.py": {5: {"PROOFCTL-P-001"}}}
    assert _is_suppressed(f, supps)


def test_load_suppress_extracts_correct_line_numbers():
    """Verify line numbers in inline suppression map are 1-based and exact."""
    src = "x = 1\ny = 2  # proofctl: ignore[PROOFCTL-S-001]\nz = 3\n"
    supps = _load_suppressions(src)
    assert 2 in supps
    assert 1 not in supps
    assert 3 not in supps
