"""Tests for PROOFCTL-YAML-* — YAML rules."""
from __future__ import annotations

from pathlib import Path

from proofctl.checkers.yaml_checker import YamlRulesChecker
from proofctl.models import Severity

_checker = YamlRulesChecker()


def _check(src: str, path: Path | None = None):
    return _checker.check(path or Path("config.yaml"), src)


def _ids(findings) -> list[str]:
    return [f.rule_id for f in findings]


def _find(findings, rule_id: str):
    return [f for f in findings if f.rule_id == rule_id]


# ══════════════════════════════════════════════════════════════════════════════
# YAML-001 — Hardcoded secret value
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml001_password_hardcoded():
    src = "database:\n  password: hunter2\n"
    f = _find(_check(src), "PROOFCTL-YAML-001")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml001_api_key_hardcoded():
    src = "api_key: sk-" + "a" * 48 + "\n"
    f = _find(_check(src), "PROOFCTL-YAML-001")
    assert len(f) == 1


def test_yaml001_env_var_ref_clean():
    src = "database:\n  password: ${DB_PASSWORD}\n"
    assert "PROOFCTL-YAML-001" not in _ids(_check(src))


def test_yaml001_placeholder_clean():
    src = "database:\n  password: <your-password-here>\n"
    assert "PROOFCTL-YAML-001" not in _ids(_check(src))


def test_yaml001_github_token_value():
    src = "token: ghp_" + "A" * 36 + "\n"
    f = _find(_check(src), "PROOFCTL-YAML-001")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# YAML-002 — Duplicate keys
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml002_duplicate_key():
    src = "key: value1\nkey: value2\n"
    f = _find(_check(src), "PROOFCTL-YAML-002")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "key" in f[0].message


def test_yaml002_no_duplicate_clean():
    src = "key1: value1\nkey2: value2\n"
    assert "PROOFCTL-YAML-002" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# YAML-003 — K8s privileged: true
# ══════════════════════════════════════════════════════════════════════════════

_K8S_HEADER = "apiVersion: v1\nkind: Pod\n"


def test_yaml003_privileged_true():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27\n"
        "    securityContext:\n"
        "      privileged: true\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 100m\n"
        "        memory: 128Mi\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-003")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml003_privileged_false_clean():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27\n"
        "    securityContext:\n"
        "      privileged: false\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 100m\n"
        "        memory: 128Mi\n"
    )
    assert "PROOFCTL-YAML-003" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# YAML-004 — K8s hostNetwork: true
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml004_host_network():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  hostNetwork: true\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 100m\n"
        "        memory: 128Mi\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-004")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_yaml004_no_host_network_clean():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 100m\n"
        "        memory: 128Mi\n"
    )
    assert "PROOFCTL-YAML-004" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# YAML-005 — K8s missing resource limits
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml005_no_resources():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-005")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING
    assert "app" in f[0].message


def test_yaml005_requests_only_no_limits():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27\n"
        "    resources:\n"
        "      requests:\n"
        "        cpu: 100m\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-005")
    assert len(f) == 1


def test_yaml005_with_limits_clean():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 500m\n"
        "        memory: 256Mi\n"
    )
    assert "PROOFCTL-YAML-005" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# YAML-006 — Image using latest tag (K8s + Compose)
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml006_k8s_image_latest():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:latest\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 100m\n"
        "        memory: 128Mi\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-006")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml006_k8s_image_no_tag():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 100m\n"
        "        memory: 128Mi\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-006")
    assert len(f) == 1


def test_yaml006_k8s_image_digest_clean():
    src = (
        _K8S_HEADER
        + "spec:\n"
        "  containers:\n"
        "  - name: app\n"
        "    image: nginx:1.27@sha256:" + "a" * 64 + "\n"
        "    resources:\n"
        "      limits:\n"
        "        cpu: 100m\n"
        "        memory: 128Mi\n"
    )
    assert "PROOFCTL-YAML-006" not in _ids(_check(src))


def test_yaml006_compose_image_latest():
    src = "services:\n  web:\n    image: nginx:latest\n"
    f = _find(_check(src), "PROOFCTL-YAML-006")
    assert len(f) == 1


# ══════════════════════════════════════════════════════════════════════════════
# YAML-007 — GitHub Actions uses: not pinned to SHA
# ══════════════════════════════════════════════════════════════════════════════

_GHA_PATH = Path(".github/workflows/ci.yml")


def test_yaml007_action_mutable_tag():
    src = (
        "on: push\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "    - uses: actions/checkout@v4\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-007")
    assert len(f) == 1
    assert f[0].severity == Severity.INFO


def test_yaml007_action_main_branch():
    src = (
        "on: push\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "    - uses: some-org/some-action@main\n"
    )
    f = _find(_check(src, _GHA_PATH), "PROOFCTL-YAML-007")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml007_action_sha_pinned_clean():
    sha = "a" * 40
    src = (
        "on: push\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        f"    - uses: actions/checkout@{sha}\n"
    )
    assert "PROOFCTL-YAML-007" not in _ids(_check(src, _GHA_PATH))


def test_yaml007_local_action_clean():
    src = (
        "on: push\n"
        "jobs:\n"
        "  build:\n"
        "    runs-on: ubuntu-latest\n"
        "    steps:\n"
        "    - uses: ./.github/actions/my-local-action\n"
    )
    assert "PROOFCTL-YAML-007" not in _ids(_check(src, _GHA_PATH))


def test_yaml007_not_fired_for_non_gha_file():
    """Non-GHA YAML content (K8s manifest) must not trigger YAML-007."""
    src = (
        "apiVersion: apps/v1\n"
        "kind: Deployment\n"
        "metadata:\n"
        "  name: app\n"
        "spec:\n"
        "  replicas: 1\n"
    )
    assert "PROOFCTL-YAML-007" not in _ids(_check(src, Path("config.yaml")))


# ══════════════════════════════════════════════════════════════════════════════
# YAML-008 — Docker Compose privileged: true
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml008_compose_privileged():
    src = (
        "services:\n"
        "  sidecar:\n"
        "    image: alpine:3.19\n"
        "    privileged: true\n"
    )
    f = _find(_check(src), "PROOFCTL-YAML-008")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml008_compose_not_privileged_clean():
    src = (
        "services:\n"
        "  web:\n"
        "    image: nginx:1.27\n"
    )
    assert "PROOFCTL-YAML-008" not in _ids(_check(src))


# ══════════════════════════════════════════════════════════════════════════════
# Additional edge-case tests
# ══════════════════════════════════════════════════════════════════════════════

def test_yaml002_nested_duplicate_keys():
    """Duplicate keys inside nested mappings must be detected."""
    src = (
        "database:\n"
        "  host: localhost\n"
        "  host: prod.db.internal\n"  # duplicate inside nested mapping
    )
    f = _find(_check(src), "PROOFCTL-YAML-002")
    assert len(f) == 1
    assert f[0].message is not None


def test_yaml007_semver_tag_is_info():
    """@v4 (semver) is the GitHub-recommended form — INFO, not ERROR."""
    src = "on: push\njobs:\n  build:\n    steps:\n      - uses: actions/checkout@v4\n"
    path = Path(".github/workflows/ci.yml")
    f = _find(_check(src, path), "PROOFCTL-YAML-007")
    assert len(f) == 1
    assert f[0].severity.name == "INFO"


def test_yaml007_branch_main_is_error():
    """@main (branch) should be ERROR — supply chain risk."""
    src = "on: push\njobs:\n  build:\n    steps:\n      - uses: actions/checkout@main\n"
    path = Path(".github/workflows/ci.yml")
    f = _find(_check(src, path), "PROOFCTL-YAML-007")
    assert len(f) == 1
    assert f[0].severity.name == "ERROR"


def test_yaml001_short_value_below_threshold_clean():
    """Values shorter than 6 chars assigned to secret keys should not trigger."""
    src = "config:\n  password: abc\n"  # 3 chars — below threshold
    assert "PROOFCTL-YAML-001" not in _ids(_check(src))


def test_yaml001_env_var_reference_clean():
    """Env-var references like ${DB_PASSWORD} must never trigger."""
    src = "database:\n  password: ${DB_PASSWORD}\n"
    assert "PROOFCTL-YAML-001" not in _ids(_check(src))


# ── YAML-019 hostPath mount ───────────────────────────────────────────────────


def test_yaml019_hostpath_root_is_error():
    src = """
apiVersion: v1
kind: Pod
metadata:
  name: bad
spec:
  volumes:
    - name: host-root
      hostPath:
        path: /
"""
    f = _find(_check(src), "PROOFCTL-YAML-019")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml019_hostpath_docker_sock_is_error():
    src = """
apiVersion: v1
kind: Pod
metadata:
  name: bad
spec:
  volumes:
    - name: docker
      hostPath:
        path: /var/run/docker.sock
"""
    f = _find(_check(src), "PROOFCTL-YAML-019")
    assert len(f) == 1
    assert f[0].severity == Severity.ERROR


def test_yaml019_hostpath_arbitrary_dir_is_warning():
    src = """
apiVersion: v1
kind: Pod
metadata:
  name: maybe-ok
spec:
  volumes:
    - name: data
      hostPath:
        path: /data/app
"""
    f = _find(_check(src), "PROOFCTL-YAML-019")
    assert len(f) == 1
    assert f[0].severity == Severity.WARNING


def test_yaml019_no_hostpath_clean():
    src = """
apiVersion: v1
kind: Pod
metadata:
  name: ok
spec:
  volumes:
    - name: cache
      emptyDir: {}
"""
    assert "PROOFCTL-YAML-019" not in _ids(_check(src))
