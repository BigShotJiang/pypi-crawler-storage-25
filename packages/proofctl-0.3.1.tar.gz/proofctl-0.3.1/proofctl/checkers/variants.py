from __future__ import annotations

import collections
import hashlib
import io
import re
import tokenize
from pathlib import Path

from ..models import Finding, Severity
from .base import DirectoryChecker

# Suffix patterns that signal AI try-fail-try drafts
_VARIANT_SUFFIXES = re.compile(
    r"^(.+?)(?:_v\d+|_new|_fixed|_working|_old|_backup|_bak|_temp|_tmp|_copy|_\d+|_[0-9]{8})\.py$",
    re.IGNORECASE,
)

# Paths to skip for variant detection (numbered migrations etc.)
_SKIP_DIRS = frozenset({"migrations", "alembic", "versions", "archive", "old", "deprecated"})


def _token_multiset(source: str) -> collections.Counter:
    counter: collections.Counter = collections.Counter()
    try:
        for tok in tokenize.generate_tokens(io.StringIO(source).readline):
            if tok.type not in (
                tokenize.COMMENT,
                tokenize.NL,
                tokenize.NEWLINE,
                tokenize.ENCODING,
                tokenize.ENDMARKER,
            ):
                counter[tok.string] += 1
    except tokenize.TokenError:
        pass
    return counter


def _bucket_keys(counter: collections.Counter, threshold: float) -> list[str]:
    """Hash-bucket keys for cheap near-duplicate pre-filtering (H-22).

    Two files with Jaccard similarity >= `threshold` must share at least one
    of these bucket keys; files that share none cannot meet the threshold,
    so we skip the expensive pairwise comparison.

    The signature: pick the K most common tokens, hash each one alongside a
    rounded total-token-count band. As long as both files agree on at least
    one of the top-K tokens *and* land in adjacent count bands, they share a
    key.  Adjacent bands are emitted so callers don't miss a match across a
    band boundary.
    """
    if not counter:
        return []
    total = sum(counter.values())
    # Band width: files whose token totals differ by more than ~1 - threshold
    # cannot possibly reach `threshold` Jaccard similarity, but we use a
    # generous band (max(8, 20% of total)) to avoid edge effects.
    band = max(8, int(total * (1.0 - threshold)))
    band_idx = total // band
    # Pick the top-K most frequent tokens — these are the "shape" of the file
    # and any near-duplicate must share most of them.
    K = 5
    top_tokens = [t for t, _ in counter.most_common(K)]
    if not top_tokens:
        return []
    keys: list[str] = []
    for tok in top_tokens:
        h_tok = hashlib.blake2b(tok.encode("utf-8"), digest_size=8).hexdigest()
        for offset in (-1, 0, 1):
            keys.append(f"{h_tok}:{band_idx + offset}")
    return keys


def _jaccard(a: collections.Counter, b: collections.Counter) -> float:
    intersection = sum((a & b).values())
    union = sum((a | b).values())
    return intersection / union if union > 0 else 0.0


class VariantChecker(DirectoryChecker):
    def __init__(self, similarity_threshold: float = 0.80, min_lines: int = 30) -> None:
        self._threshold = similarity_threshold
        self._min_lines = min_lines

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        findings: list[Finding] = []
        findings.extend(self._v001(root, py_files))
        findings.extend(self._v002(root, py_files))
        return findings

    def _v001(self, root: Path, py_files: list[Path]) -> list[Finding]:
        """Files that look like successive drafts of the same module."""
        # Group by directory
        by_dir: dict[Path, list[Path]] = collections.defaultdict(list)
        for f in py_files:
            by_dir[f.parent].append(f)

        findings = []
        for directory, files in by_dir.items():
            # Skip known non-variant directories
            if any(part in _SKIP_DIRS for part in directory.parts):
                continue

            stems = {f.stem: f for f in files}
            reported: set[frozenset] = set()

            for f in files:
                m = _VARIANT_SUFFIXES.match(f.name)
                if not m:
                    continue
                base_stem = m.group(1)
                if base_stem in stems:
                    pair = frozenset({f, stems[base_stem]})
                    if pair in reported:
                        continue
                    reported.add(pair)

                    rel_variant = str(f.relative_to(root))
                    rel_base = str(stems[base_stem].relative_to(root))
                    findings.append(Finding(
                        file=rel_variant,
                        line=None,
                        col=None,
                        rule_id="PROOFCTL-V-001",
                        rule_name="Variant file debris",
                        severity=Severity.WARNING,
                        message=(
                            f"'{f.name}' looks like a draft of '{stems[base_stem].name}' "
                            f"— both exist in {f.parent.name}/"
                        ),
                        hint=(
                            f"Delete '{f.name}' if '{rel_base}' is the canonical version. "
                            "Git history preserves the content."
                        ),
                        authority="Pragmatic Programmer – Don't Leave Broken Windows",
                        docs_url="https://pragprog.com/titles/tpp20/the-pragmatic-programmer-20th-anniversary-edition/",
                    ))

        return findings

    def _v002(self, root: Path, py_files: list[Path]) -> list[Finding]:
        """Files in the same directory with suspiciously similar token content."""
        by_dir: dict[Path, list[Path]] = collections.defaultdict(list)
        for f in py_files:
            # Only check files large enough to be meaningful
            try:
                lines = f.read_text(encoding="utf-8", errors="replace").count("\n")
            except OSError:
                continue
            if lines >= self._min_lines:
                by_dir[f.parent].append(f)

        findings = []
        for directory, files in by_dir.items():
            if any(part in _SKIP_DIRS for part in directory.parts):
                continue
            if len(files) < 2:
                continue

            # Tokenise every file (cheap) and compute per-file bucket keys.
            tokens: dict[Path, collections.Counter] = {}
            for f in files:
                try:
                    source = f.read_text(encoding="utf-8", errors="replace")
                    tokens[f] = _token_multiset(source)
                except OSError:
                    pass

            # H-22: hash-bucket pre-pass replaces the old 20-file cap.
            # Build buckets keyed by (rounded-size-band, top-token-hash).
            # Only files that share a bucket are eligible for the expensive
            # Jaccard comparison.
            buckets: dict[str, list[Path]] = collections.defaultdict(list)
            for f in files:
                if f not in tokens:
                    continue
                for key in _bucket_keys(tokens[f], self._threshold):
                    buckets[key].append(f)

            reported: set[frozenset] = set()
            for bucket_files in buckets.values():
                if len(bucket_files) < 2:
                    continue
                for i, f1 in enumerate(bucket_files):
                    for f2 in bucket_files[i + 1:]:
                        if f1 not in tokens or f2 not in tokens:
                            continue
                        # Skip test/source pairs
                        if f1.stem.startswith("test_") != f2.stem.startswith("test_"):
                            continue
                        pair = frozenset({f1, f2})
                        if pair in reported:
                            continue
                        sim = _jaccard(tokens[f1], tokens[f2])
                        if sim >= self._threshold:
                            reported.add(pair)
                            findings.append(Finding(
                                file=str(f1.relative_to(root)),
                                line=None,
                                col=None,
                                rule_id="PROOFCTL-V-002",
                                rule_name="Near-duplicate file",
                                severity=Severity.INFO,
                                message=(
                                    f"'{f1.name}' and '{f2.name}' are {sim:.0%} similar "
                                    f"(threshold: {self._threshold:.0%})"
                                ),
                                hint=(
                                    f"Review whether '{f1.name}' and '{f2.name}' are "
                                    "both needed or if one is an abandoned draft."
                                ),
                                authority="Clean Code – Duplication is the root of all evil",
                                docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
                            ))

        return findings
