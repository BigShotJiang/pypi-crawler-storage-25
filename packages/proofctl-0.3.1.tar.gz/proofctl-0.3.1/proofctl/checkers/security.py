"""Security checker — rules PROOFCTL-S-*

AI models introduce these vulnerabilities at high rates (Veracode 2024: 2.7× higher
density than human-written code). All rules are AST-based for precision.

S-001  SQL injection — string interpolation/concatenation in .execute() calls
S-002  Command injection — subprocess/os.system with shell=True + variable arg
S-003  Unsafe deserialization — pickle.loads(), yaml.load() without SafeLoader
S-004  Weak cryptographic primitive — MD5, SHA1, or random module for secrets
S-005  eval() / exec() on non-literal input (arbitrary code execution)
S-006  Missing timeout on outbound HTTP requests (requests / httpx)
S-007  JWT algorithm confusion / signature bypass
S-008  Path traversal via user-supplied path to open()
S-009  Insecure UUID for security-sensitive values
S-010  Secret value leaked into logs
S-011  Insecure cipher mode via cryptography.hazmat
S-012  Regex injection (ReDoS)
S-013  Open redirect
S-014  TLS verification disabled (verify=False on requests/httpx)
S-015  random.* used for security-sensitive value (assignment-target heuristic)
S-016  subprocess called with a partial-path executable (PATH manipulation)
"""
from __future__ import annotations

import ast
import re
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker

# ── constants ─────────────────────────────────────────────────────────────────

_SQL_EXECUTE_ATTRS = frozenset({
    "execute", "executemany", "executescript", "mogrify",
    "raw", "rawquery", "query",
})

_SUBPROCESS_FUNCS = frozenset({
    "call", "run", "Popen", "check_call", "check_output",
})

# These always invoke a shell — flag on any non-literal first arg, no shell=True needed.
_SUBPROCESS_ALWAYS_SHELL = frozenset({"getoutput", "getstatusoutput"})

_HTTP_METHODS = frozenset({
    "get", "post", "put", "patch", "delete", "head", "options", "request",
})

_HTTP_CLIENTS = frozenset({"requests", "httpx"})

# Variable/function names that suggest security-sensitive context
_SEC_NAME_RE = re.compile(
    r"\b(?:token|secret|key|password|passwd|pwd|nonce|salt|otp|pin|"
    r"credential|auth_code|api_key|access_key|session_id|csrf)\b",
    re.IGNORECASE,
)


# ── AST helpers ───────────────────────────────────────────────────────────────

def _is_literal(node: ast.expr) -> bool:
    return isinstance(node, ast.Constant)


def _is_interpolated(node: ast.expr) -> bool:
    """True if node is an f-string, .format() call, % operator, or + concat."""
    if isinstance(node, ast.JoinedStr):
        return any(not isinstance(v, ast.Constant) for v in node.values)
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Attribute) and node.func.attr == "format":
            return True
    if isinstance(node, ast.BinOp):
        if isinstance(node.op, ast.Mod):
            return True
        if isinstance(node.op, ast.Add):
            return not (_is_literal(node.left) and _is_literal(node.right))
    return False


def _kwarg_is_true(call: ast.Call, name: str) -> bool:
    for kw in call.keywords:
        if kw.arg == name:
            return isinstance(kw.value, ast.Constant) and kw.value.value is True
    return False


def _kwarg_is_false(call: ast.Call, name: str) -> bool:
    for kw in call.keywords:
        if kw.arg == name:
            return isinstance(kw.value, ast.Constant) and kw.value.value is False
    return False


def _has_kwarg(call: ast.Call, *names: str) -> bool:
    kw_names = {kw.arg for kw in call.keywords}
    return bool(kw_names & set(names))


def _attr_chain(node: ast.expr) -> list[str]:
    """['requests', 'get'] from requests.get(...)"""
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if isinstance(node, ast.Name):
        parts.append(node.id)
    return list(reversed(parts))


def _call_attr(call: ast.Call) -> str | None:
    """Return last attribute name of the call, e.g. 'execute'."""
    if isinstance(call.func, ast.Attribute):
        return call.func.attr
    if isinstance(call.func, ast.Name):
        return call.func.id
    return None


def _assign_target_name(target: ast.expr) -> str:
    """Extract the relevant name from an assignment target.

    For ast.Name → its id.
    For ast.Attribute → the final attribute (e.g., self.token → 'token').
    Otherwise → empty string.
    """
    if isinstance(target, ast.Name):
        return target.id
    if isinstance(target, ast.Attribute):
        # Walk to the leaf attribute (already the last in chain since attr is leaf).
        return target.attr
    return ""


# ── Visitors ──────────────────────────────────────────────────────────────────

class _S001Visitor(ast.NodeVisitor):
    """SQL injection via string interpolation in .execute() calls."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        if _call_attr(node) in _SQL_EXECUTE_ATTRS and node.args:
            arg = node.args[0]
            if _is_interpolated(arg):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-001",
                    rule_name="SQL injection via string formatting",
                    severity=Severity.ERROR,
                    message=(
                        f"String interpolation in .{_call_attr(node)}() "
                        "call — SQL injection risk"
                    ),
                    hint="Use parameterised queries: cursor.execute(sql, (value,))",
                    authority="OWASP A03:2021 – Injection / CWE-89",
                    docs_url="https://owasp.org/Top10/A03_2021-Injection/",
                ))
        self.generic_visit(node)


class _S002Visitor(ast.NodeVisitor):
    """Command injection: subprocess with shell=True + non-literal command."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        is_subprocess = (
            len(chain) == 2
            and chain[0] == "subprocess"
            and chain[1] in _SUBPROCESS_FUNCS
        )
        is_subprocess_always_shell = (
            len(chain) == 2
            and chain[0] == "subprocess"
            and chain[1] in _SUBPROCESS_ALWAYS_SHELL
        )
        is_os_system = chain == ["os", "system"] or chain == ["os", "popen"]

        if is_subprocess and _kwarg_is_true(node, "shell"):
            cmd = node.args[0] if node.args else None
            if cmd is not None and not _is_literal(cmd):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-002",
                    rule_name="Command injection via shell=True",
                    severity=Severity.ERROR,
                    message=(
                        f"subprocess.{chain[1]}(..., shell=True) with a "
                        "non-literal command — shell injection risk"
                    ),
                    hint=(
                        "Pass a list of arguments without shell=True: "
                        "subprocess.run(['cmd', arg1, arg2])"
                    ),
                    authority="CWE-78 – OS Command Injection",
                    docs_url="https://cwe.mitre.org/data/definitions/78.html",
                ))

        # subprocess.getoutput / getstatusoutput always shell out — no shell= kwarg.
        if is_subprocess_always_shell and node.args and not _is_literal(node.args[0]):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-002",
                rule_name="Command injection via subprocess shell helper",
                severity=Severity.ERROR,
                message=(
                    f"subprocess.{chain[1]}() with a non-literal command — "
                    "this helper always invokes a shell"
                ),
                hint=(
                    "Use subprocess.run(['cmd', arg], capture_output=True) with a list argument; "
                    "getoutput / getstatusoutput cannot be made safe without input sanitisation."
                ),
                authority="CWE-78 – OS Command Injection",
                docs_url="https://cwe.mitre.org/data/definitions/78.html",
            ))

        if is_os_system and node.args and not _is_literal(node.args[0]):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-002",
                rule_name="Command injection via os.system",
                severity=Severity.ERROR,
                message=(
                    f"os.{chain[1]}() with a non-literal command — "
                    "shell injection risk"
                ),
                hint="Use subprocess.run(['cmd', arg]) with a list argument.",
                authority="CWE-78 – OS Command Injection",
                docs_url="https://cwe.mitre.org/data/definitions/78.html",
            ))
        self.generic_visit(node)


class _S003Visitor(ast.NodeVisitor):
    """Unsafe deserialization: pickle.loads / yaml.load without SafeLoader."""

    _PICKLE_MODULES = frozenset({"pickle", "marshal", "_pickle"})
    _UNSAFE_FUNCS = frozenset({"loads", "load"})

    def __init__(self, path: Path, tree: ast.Module | None = None):
        self.path = path
        self.findings: list[Finding] = []
        # Bare names imported from pickle/marshal — e.g. {"loads", "load"} → "pickle"
        self._imported_unsafe: dict[str, str] = {}
        if tree is not None:
            self._collect_imports(tree)

    def _collect_imports(self, tree: ast.Module) -> None:
        """Scan top-level imports for `from pickle import loads/load` patterns."""
        for stmt in ast.walk(tree):
            if isinstance(stmt, ast.ImportFrom) and stmt.module in self._PICKLE_MODULES:
                for alias in stmt.names:
                    bound = alias.asname or alias.name
                    if alias.name in self._UNSAFE_FUNCS:
                        self._imported_unsafe[bound] = stmt.module

    def _flag_pickle(self, node: ast.Call, label: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-003",
            rule_name="Unsafe deserialization",
            severity=Severity.ERROR,
            message=(
                f"{label}() deserialises arbitrary Python objects "
                "— remote code execution if input is untrusted"
            ),
            hint="Use json.loads() or msgpack. Never deserialise untrusted pickle data.",
            authority="OWASP A08:2021 – Software and Data Integrity / CWE-502",
            docs_url="https://owasp.org/Top10/A08_2021-Software_and_Data_Integrity_Failures/",
        ))

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)

        # pickle.loads / pickle.load / marshal.loads
        if (
            len(chain) == 2
            and chain[0] in self._PICKLE_MODULES
            and chain[1] in self._UNSAFE_FUNCS
        ):
            self._flag_pickle(node, ".".join(chain))

        # `from pickle import loads; loads(x)` — bare-name call
        elif len(chain) == 1 and chain[0] in self._imported_unsafe:
            module = self._imported_unsafe[chain[0]]
            self._flag_pickle(node, f"{module}.{chain[0]}")

        # yaml.load() without Loader=SafeLoader
        if len(chain) == 2 and chain[0] == "yaml" and chain[1] == "load":
            safe_loader_names = {"SafeLoader", "CSafeLoader", "BaseLoader"}
            has_safe_loader = any(
                kw.arg == "Loader"
                and isinstance(kw.value, ast.Attribute)
                and kw.value.attr in safe_loader_names
                or kw.arg == "Loader"
                and isinstance(kw.value, ast.Name)
                and kw.value.id in safe_loader_names
                for kw in node.keywords
            )
            if not has_safe_loader:
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-003",
                    rule_name="Unsafe YAML deserialization",
                    severity=Severity.ERROR,
                    message="yaml.load() without Loader=yaml.SafeLoader can execute arbitrary Python",
                    hint="Use yaml.safe_load(data) or yaml.load(data, Loader=yaml.SafeLoader).",
                    authority="CWE-502 – Deserialization of Untrusted Data",
                docs_url="https://cwe.mitre.org/data/definitions/502.html",
                ))

        self.generic_visit(node)


class _S004Visitor(ast.NodeVisitor):
    """Weak crypto: MD5/SHA1 via hashlib; random module for security-sensitive values."""

    _RANDOM_FUNCS = frozenset(
        {"choice", "randint", "random", "randbytes", "sample", "randrange", "shuffle"}
    )

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)

        # hashlib.md5() / hashlib.sha1() / hashlib.new("md5")
        if len(chain) == 2 and chain[0] == "hashlib":
            if chain[1] == "md5":
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-004",
                    rule_name="Weak hash algorithm: MD5",
                    severity=Severity.ERROR,
                    message="hashlib.md5() is cryptographically broken",
                    hint="Use hashlib.sha256() or hashlib.sha3_256() for integrity; use bcrypt/argon2 for passwords.",
                    authority="NIST SP 800-131A / CWE-327",
                    docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-131Ar2.pdf",
                ))
            elif chain[1] == "sha1":
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-004",
                    rule_name="Weak hash algorithm: SHA-1",
                    severity=Severity.WARNING,
                    message="hashlib.sha1() is deprecated for security use",
                    hint="Upgrade to SHA-256 or SHA-3. SHA-1 is collision-vulnerable (SHAttered attack).",
                    authority="NIST SP 800-131A / CWE-327",
                    docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-131Ar2.pdf",
                ))
            elif chain[1] == "new" and node.args:
                algo = node.args[0]
                if isinstance(algo, ast.Constant) and str(algo.value).lower() in ("md5", "sha1", "sha-1"):
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=node.lineno,
                        col=node.col_offset,
                        rule_id="PROOFCTL-S-004",
                        rule_name=f"Weak hash algorithm: {algo.value}",
                        severity=Severity.ERROR,
                        message=f'hashlib.new("{algo.value}") uses a weak algorithm',
                        hint="Use hashlib.new('sha256') or stronger.",
                        authority="CWE-327",
                        docs_url="https://cwe.mitre.org/data/definitions/327.html",
                    ))

        # pycryptodome: Crypto.Hash.MD5.new() / Crypto.Hash.SHA1.new()
        # cryptography.hazmat.primitives.hashes.MD5() / hashes.SHA1()
        if chain:
            # Crypto.Hash.MD5.new() — chain ends with [..., 'MD5', 'new']
            if len(chain) >= 3 and chain[0] == "Crypto" and chain[1] == "Hash" and chain[-1] == "new":
                algo = chain[-2]
                if algo.upper() in ("MD5", "SHA1"):
                    sev = Severity.ERROR if algo.upper() == "MD5" else Severity.WARNING
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=node.lineno,
                        col=node.col_offset,
                        rule_id="PROOFCTL-S-004",
                        rule_name=f"Weak hash algorithm: {algo.upper()} (pycryptodome)",
                        severity=sev,
                        message=f"Crypto.Hash.{algo}.new() uses a weak hash algorithm",
                        hint="Use SHA-256 or stronger: Crypto.Hash.SHA256.new().",
                        authority="NIST SP 800-131A / CWE-327",
                        docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-131Ar2.pdf",
                    ))
            # cryptography.hazmat.primitives.hashes.MD5() / .SHA1()
            if (
                "hashes" in chain
                and chain[-1] in ("MD5", "SHA1")
            ):
                algo = chain[-1]
                sev = Severity.ERROR if algo == "MD5" else Severity.WARNING
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-004",
                    rule_name=f"Weak hash algorithm: {algo} (cryptography.hazmat)",
                    severity=sev,
                    message=f"hashes.{algo}() is a weak/deprecated hash algorithm",
                    hint="Use hashes.SHA256() or hashes.SHA3_256().",
                    authority="NIST SP 800-131A / CWE-327",
                    docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-131Ar2.pdf",
                ))

        self.generic_visit(node)

    def _check_random_in_value(self, value: ast.expr, target_name: str, owner_lineno: int) -> None:
        """Walk an assignment RHS and flag any random.* call when target is sensitive."""
        if not _SEC_NAME_RE.search(target_name):
            return
        for val_node in ast.walk(value):
            if isinstance(val_node, ast.Call):
                chain = _attr_chain(val_node.func)
                if (
                    len(chain) == 2
                    and chain[0] == "random"
                    and chain[1] in self._RANDOM_FUNCS
                ):
                    self.findings.append(Finding(
                        file=str(self.path),
                        line=val_node.lineno,
                        col=val_node.col_offset,
                        rule_id="PROOFCTL-S-004",
                        rule_name="Insecure random for security value",
                        severity=Severity.ERROR,
                        message=(
                            f"random.{chain[1]}() used to generate "
                            f'"{target_name}" — not cryptographically secure'
                        ),
                        hint="Use the secrets module: secrets.token_hex(), secrets.token_urlsafe().",
                        authority="CWE-338 – Use of Cryptographically Weak PRNG",
                        docs_url="https://cwe.mitre.org/data/definitions/338.html",
                    ))

    def visit_Assign(self, node: ast.Assign) -> None:
        self.generic_visit(node)
        # H-12: handle both ast.Name and ast.Attribute targets.
        for t in node.targets:
            target_name = _assign_target_name(t)
            if target_name:
                self._check_random_in_value(node.value, target_name, node.lineno)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        self.generic_visit(node)
        target_name = _assign_target_name(node.target)
        if target_name:
            self._check_random_in_value(node.value, target_name, node.lineno)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        self.generic_visit(node)
        if node.value is None:
            return
        target_name = _assign_target_name(node.target)
        if target_name:
            self._check_random_in_value(node.value, target_name, node.lineno)


class _S005Visitor(ast.NodeVisitor):
    """eval() / exec() on non-literal input."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        name = node.func.id if isinstance(node.func, ast.Name) else None
        if name in ("eval", "exec", "compile") and node.args and not _is_literal(node.args[0]):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-005",
                rule_name="Code execution from dynamic input",
                severity=Severity.ERROR,
                message=f"{name}() with non-literal input executes arbitrary code",
                hint="Avoid eval/exec on dynamic input. Use ast.literal_eval() for safe data parsing.",
                authority="CWE-94 – Code Injection / OWASP A03:2021",
                docs_url="https://cwe.mitre.org/data/definitions/94.html",
            ))
        self.generic_visit(node)


class _S006Visitor(ast.NodeVisitor):
    """Missing timeout on outbound HTTP calls.

    Catches:
      - requests.X(...) / httpx.X(...) (direct module call)
      - session.X(...) where session was assigned from requests.Session() / httpx.Client() /
        httpx.AsyncClient() / aiohttp.ClientSession()
      - urllib.request.urlopen(url) without timeout=
      - urllib3.PoolManager().request(...) without timeout=
    """

    _SESSION_FACTORIES = frozenset({
        ("requests", "Session"),
        ("httpx", "Client"),
        ("httpx", "AsyncClient"),
        ("aiohttp", "ClientSession"),
    })

    def __init__(self, path: Path, tree: ast.Module | None = None):
        self.path = path
        self.findings: list[Finding] = []
        # variable name → factory (e.g. "session" → "requests.Session")
        self._session_vars: dict[str, str] = {}
        # variable name → True if assigned from urllib3.PoolManager()
        self._pool_managers: set[str] = set()
        if tree is not None:
            self._collect_session_vars(tree)

    def _collect_session_vars(self, tree: ast.Module) -> None:
        for stmt in ast.walk(tree):
            if isinstance(stmt, (ast.Assign, ast.AnnAssign)):
                value = stmt.value
                if value is None:
                    continue
                # Unwrap context-manager-style chained calls? — keep simple: direct call.
                if not isinstance(value, ast.Call):
                    continue
                chain = _attr_chain(value.func)
                # Identify session factory
                key: tuple[str, str] | None = None
                if len(chain) == 2:
                    key = (chain[0], chain[1])
                elif len(chain) == 1:
                    # `from requests import Session; s = Session()` — best-effort: name only
                    pass
                if key in self._SESSION_FACTORIES:
                    factory = ".".join(key)
                    targets = stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]
                    for t in targets:
                        if isinstance(t, ast.Name):
                            self._session_vars[t.id] = factory
                        elif isinstance(t, ast.Attribute):
                            # self.session = requests.Session() → tracks attr name
                            self._session_vars[t.attr] = factory

                # urllib3.PoolManager()
                if chain == ["urllib3", "PoolManager"]:
                    targets = stmt.targets if isinstance(stmt, ast.Assign) else [stmt.target]
                    for t in targets:
                        if isinstance(t, ast.Name):
                            self._pool_managers.add(t.id)
                        elif isinstance(t, ast.Attribute):
                            self._pool_managers.add(t.attr)

    def _flag(self, node: ast.Call, who: str, *, hint: str | None = None) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-006",
            rule_name="HTTP request without timeout",
            severity=Severity.WARNING,
            message=(
                f"{who} has no timeout — hangs forever if the remote server stalls"
            ),
            hint=hint or "Add timeout=: e.g. requests.get(url, timeout=30)",
            authority="Release It! – Stability Patterns / CWE-400",
            docs_url="https://cwe.mitre.org/data/definitions/400.html",
        ))

    def _is_session_var(self, node: ast.expr) -> str | None:
        """If node is a Name or self.<attr> matching a tracked session var, return factory label."""
        if isinstance(node, ast.Name) and node.id in self._session_vars:
            return self._session_vars[node.id]
        if isinstance(node, ast.Attribute) and node.attr in self._session_vars:
            return self._session_vars[node.attr]
        return None

    def _is_pool_manager(self, node: ast.expr) -> bool:
        if isinstance(node, ast.Name) and node.id in self._pool_managers:
            return True
        if isinstance(node, ast.Attribute) and node.attr in self._pool_managers:
            return True
        # Inline: urllib3.PoolManager().request(...)
        if isinstance(node, ast.Call):
            return _attr_chain(node.func) == ["urllib3", "PoolManager"]
        return False

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)

        # Direct: requests.get(...) / httpx.post(...)
        if (
            len(chain) == 2
            and chain[0] in _HTTP_CLIENTS
            and chain[1] in _HTTP_METHODS
            and not _has_kwarg(node, "timeout")
        ):
            self._flag(node, f"{chain[0]}.{chain[1]}()")

        # urllib.request.urlopen(...) — chain ['urllib', 'request', 'urlopen']
        # or ['urllib2', 'urlopen']
        is_urlopen = (
            chain == ["urllib", "request", "urlopen"]
            or chain == ["urllib2", "urlopen"]
            or (len(chain) == 1 and chain[0] == "urlopen")  # from urllib.request import urlopen
        )
        if is_urlopen and not _has_kwarg(node, "timeout"):
            self._flag(
                node,
                "urllib.request.urlopen()",
                hint="Pass timeout=: urlopen(url, timeout=30)",
            )

        # Method call on a tracked session/client variable: session.get(...) etc.
        if isinstance(node.func, ast.Attribute) and node.func.attr in _HTTP_METHODS:
            owner = node.func.value
            factory = self._is_session_var(owner)
            if factory and not _has_kwarg(node, "timeout"):
                self._flag(
                    node,
                    f"{factory}().{node.func.attr}()",
                    hint=(
                        "Add timeout= to the session call, or set a default on the "
                        "session/client (e.g. httpx.Client(timeout=30))."
                    ),
                )

        # urllib3 PoolManager: pool.request("GET", url) without timeout=
        if isinstance(node.func, ast.Attribute) and node.func.attr == "request":
            owner = node.func.value
            if self._is_pool_manager(owner) and not _has_kwarg(node, "timeout"):
                self._flag(
                    node,
                    "urllib3.PoolManager().request()",
                    hint="Pass timeout=: pool.request('GET', url, timeout=30)",
                )

        self.generic_visit(node)


class _S007Visitor(ast.NodeVisitor):
    """JWT algorithm confusion / signature bypass."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _flag(self, node: ast.Call, detail: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-007",
            rule_name="JWT signature verification bypass",
            severity=Severity.ERROR,
            message=f"jwt.decode() with {detail} — signature verification bypassed",
            hint="Never disable JWT signature verification. Use algorithms=['HS256'] with a verified secret.",
            authority="OWASP A02:2021 – Cryptographic Failures / CWE-347",
            docs_url="https://owasp.org/Top10/A02_2021-Cryptographic_Failures/",
        ))

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        # Match jwt.decode(...) or jose.jwt.decode(...)
        is_jwt_decode = (
            (len(chain) == 2 and chain[0] == "jwt" and chain[1] == "decode")
            or (len(chain) == 3 and chain[0] == "jose" and chain[1] == "jwt" and chain[2] == "decode")
            or (len(chain) == 1 and chain[0] == "decode")  # from jwt import decode
        )
        if is_jwt_decode:
            for kw in node.keywords:
                # legacy PyJWT: jwt.decode(token, verify=False)
                if (
                    kw.arg == "verify"
                    and isinstance(kw.value, ast.Constant)
                    and kw.value.value is False
                ):
                    self._flag(node, "verify=False")
                # Check options={"verify_signature": False} or {"verify_exp": False}
                if kw.arg == "options" and isinstance(kw.value, ast.Dict):
                    for k, v in zip(kw.value.keys, kw.value.values):
                        if (
                            isinstance(k, ast.Constant)
                            and k.value in ("verify_signature", "verify_exp")
                            and isinstance(v, ast.Constant)
                            and v.value is False
                        ):
                            self._flag(node, f'options={{"{k.value}": False}}')
                # Check algorithms=[..., "none", ...]
                if kw.arg == "algorithms" and isinstance(kw.value, ast.List):
                    has_none = any(
                        isinstance(elt, ast.Constant) and str(elt.value).lower() == "none"
                        for elt in kw.value.elts
                    )
                    if has_none:
                        self._flag(node, 'algorithms=[..., "none", ...]')
        self.generic_visit(node)


class _S008Visitor(ast.NodeVisitor):
    """Path traversal via tainted user input flowing to open().

    Uses simple intra-procedural taint analysis:
      - Function parameters named `request` / `req` / `environ` are tainted.
      - Assignments from `os.environ[...]`, `os.getenv(...)`, `sys.argv[...]`,
        `request.args[...]`, `request.form.get(...)`, `request.GET`, `request.POST`,
        `request.json`, `request.body` etc. produce tainted variables.
      - Calls like `os.path.join(tainted, ...)` propagate the taint.
    """

    _REQUEST_ATTRS = frozenset({"args", "form", "json", "GET", "POST", "data", "body"})
    _REQUEST_GET_ATTRS = frozenset({"args", "form", "GET", "POST"})
    _TAINTED_PARAM_NAMES = frozenset({"request", "req", "environ", "flask_request"})
    _PROPAGATING_CALLS = frozenset({
        ("os", "path", "join"),
        ("os", "path", "abspath"),
        ("os", "path", "normpath"),
        ("os", "path", "expanduser"),
        ("pathlib", "Path"),
        ("Path",),  # `Path(tainted)` after `from pathlib import Path`
    })

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []
        # Set of variable names that are tainted in current scope.
        # We do whole-module analysis via visit_FunctionDef / visit_AsyncFunctionDef.
        self._tainted: set[str] = set()

    # ── taint propagation helpers ──────────────────────────────────────────────

    def _expr_is_request_source(self, node: ast.expr) -> bool:
        """True if node directly reads from request data."""
        # request.args, request.form, request.json, request.body, request.GET, request.POST
        if isinstance(node, ast.Attribute):
            if (
                isinstance(node.value, ast.Name)
                and node.value.id in self._TAINTED_PARAM_NAMES
                and node.attr in self._REQUEST_ATTRS
            ):
                return True
            # flask.request.args etc.
            if (
                isinstance(node.value, ast.Attribute)
                and node.value.attr == "request"
                and node.attr in self._REQUEST_ATTRS
            ):
                return True
        # request.args.get("x") / request.form.get("x")
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "get":
                obj = node.func.value
                if (
                    isinstance(obj, ast.Attribute)
                    and obj.attr in self._REQUEST_GET_ATTRS
                ):
                    inner = obj.value
                    if isinstance(inner, ast.Name) and inner.id in self._TAINTED_PARAM_NAMES:
                        return True
                    if isinstance(inner, ast.Attribute) and inner.attr == "request":
                        return True
        # request.args["x"], request.form["x"], etc.
        if isinstance(node, ast.Subscript):
            obj = node.value
            if (
                isinstance(obj, ast.Attribute)
                and obj.attr in self._REQUEST_ATTRS
            ):
                inner = obj.value
                if isinstance(inner, ast.Name) and inner.id in self._TAINTED_PARAM_NAMES:
                    return True
                if isinstance(inner, ast.Attribute) and inner.attr == "request":
                    return True
        # os.environ[...] / os.environ.get(...) / os.getenv(...)
        if isinstance(node, ast.Subscript):
            chain = _attr_chain(node.value)
            if chain == ["os", "environ"]:
                return True
        if isinstance(node, ast.Call):
            chain = _attr_chain(node.func)
            if chain in (["os", "getenv"], ["os", "environ", "get"]):
                return True
        # sys.argv[...] / sys.argv subscript
        if isinstance(node, ast.Subscript):
            chain = _attr_chain(node.value)
            if chain == ["sys", "argv"]:
                return True
        return False

    def _expr_taint(self, node: ast.expr) -> bool:
        """Recursively check if expression is tainted."""
        if self._expr_is_request_source(node):
            return True
        # bare Name → check tainted set
        if isinstance(node, ast.Name) and node.id in self._tainted:
            return True
        # Attribute access on a tainted base
        if isinstance(node, ast.Attribute):
            if isinstance(node.value, ast.Name) and node.value.id in self._tainted:
                return True
        # f-strings or BinOp over tainted parts
        if isinstance(node, ast.JoinedStr):
            return any(self._expr_taint(v) for v in node.values if isinstance(v, ast.expr))
        if isinstance(node, ast.FormattedValue):
            return self._expr_taint(node.value)
        if isinstance(node, ast.BinOp):
            return self._expr_taint(node.left) or self._expr_taint(node.right)
        # Call: propagating funcs (os.path.join, str(), Path())
        if isinstance(node, ast.Call):
            chain = _attr_chain(node.func)
            chain_t = tuple(chain)
            if chain_t in self._PROPAGATING_CALLS:
                return any(self._expr_taint(a) for a in node.args)
            # str(tainted), bytes(tainted)
            if chain == ["str"] or chain == ["bytes"]:
                return any(self._expr_taint(a) for a in node.args)
            # tainted.format(...) / tainted.replace(...) / tainted.strip()
            if isinstance(node.func, ast.Attribute):
                return self._expr_taint(node.func.value)
        # Subscript on tainted base
        if isinstance(node, ast.Subscript):
            return self._expr_taint(node.value)
        return False

    # ── visitors ──────────────────────────────────────────────────────────────

    def _process_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        """Process a function: seed taint from parameters, walk body in order."""
        outer = self._tainted
        self._tainted = set(outer)  # carry module-level taint into the function

        # Seed: any parameter named `request`/`req`/`environ` is itself tainted
        # (its attribute access returns tainted data).
        for arg in node.args.args + node.args.kwonlyargs:
            if arg.arg in self._TAINTED_PARAM_NAMES:
                self._tainted.add(arg.arg)

        for stmt in node.body:
            self._walk_statement(stmt)

        self._tainted = outer

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._process_function(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._process_function(node)

    def visit_Module(self, node: ast.Module) -> None:
        # Walk top-level statements in order so that taint propagates through
        # straight-line module-level assignments.
        for stmt in node.body:
            self._walk_statement(stmt)

    def _walk_statement(self, stmt: ast.stmt) -> None:
        # Update tainted-name set first
        if isinstance(stmt, ast.Assign):
            if self._expr_taint(stmt.value):
                for t in stmt.targets:
                    if isinstance(t, ast.Name):
                        self._tainted.add(t.id)
        elif isinstance(stmt, ast.AnnAssign) and stmt.value is not None:
            if self._expr_taint(stmt.value):
                if isinstance(stmt.target, ast.Name):
                    self._tainted.add(stmt.target.id)
        elif isinstance(stmt, (ast.FunctionDef, ast.AsyncFunctionDef)):
            self._process_function(stmt)
            return
        elif isinstance(stmt, ast.ClassDef):
            for inner in stmt.body:
                self._walk_statement(inner)
            return

        # Scan for open() calls in this statement and any nested scopes.
        for sub in ast.walk(stmt):
            if isinstance(sub, ast.Call):
                self._maybe_flag_open(sub)
            # Recurse into nested function/class? No — _walk_statement handles those.

    def _maybe_flag_open(self, call: ast.Call) -> None:
        chain = _attr_chain(call.func)
        is_open = chain == ["open"] or (len(chain) == 1 and chain[0] == "open")
        if not is_open or not call.args:
            return
        arg0 = call.args[0]
        if self._expr_taint(arg0):
            self.findings.append(Finding(
                file=str(self.path),
                line=call.lineno,
                col=call.col_offset,
                rule_id="PROOFCTL-S-008",
                rule_name="Path traversal via tainted input",
                severity=Severity.ERROR,
                message="open() called with a path derived from user input — path traversal risk",
                hint=(
                    "Validate and sanitise file paths: use os.path.basename(), "
                    "pathlib.Path(...).resolve(), or restrict to an allowed directory."
                ),
                authority="OWASP A01:2021 – Broken Access Control / CWE-22",
                docs_url="https://owasp.org/Top10/A01_2021-Broken_Access_Control/",
            ))


class _S009Visitor(ast.NodeVisitor):
    """Insecure UUID for security-sensitive values."""

    _INSECURE_UUID_FUNCS = frozenset({"uuid1", "uuid3"})

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _flag(self, node: ast.Call, func_name: str, target_name: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-009",
            rule_name="Insecure UUID for security-sensitive value",
            severity=Severity.ERROR,
            message=(
                f"uuid.{func_name}() used for '{target_name}' — "
                "uuid1 is time-based (guessable), uuid3 is MD5-based"
            ),
            hint="Use uuid.uuid4() or secrets.token_hex() for security-sensitive identifiers.",
            authority="CWE-338 – Use of Cryptographically Weak PRNG",
            docs_url="https://cwe.mitre.org/data/definitions/338.html",
        ))

    def _check_targets(self, targets: list[ast.expr], value: ast.expr) -> None:
        for t in targets:
            target_name = _assign_target_name(t)
            if not target_name or not _SEC_NAME_RE.search(target_name):
                continue
            for val_node in ast.walk(value):
                if not isinstance(val_node, ast.Call):
                    continue
                chain = _attr_chain(val_node.func)
                if len(chain) == 2 and chain[0] == "uuid" and chain[1] in self._INSECURE_UUID_FUNCS:
                    self._flag(val_node, chain[1], target_name)
                elif len(chain) == 1 and chain[0] in self._INSECURE_UUID_FUNCS:
                    self._flag(val_node, chain[0], target_name)

    def visit_Assign(self, node: ast.Assign) -> None:
        self._check_targets(list(node.targets), node.value)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            self._check_targets([node.target], node.value)
        self.generic_visit(node)


class _S010Visitor(ast.NodeVisitor):
    """Secret value leaked into logs."""

    _LOG_ATTRS = frozenset({
        "debug", "info", "warning", "warn", "error", "critical", "exception", "log",
    })
    # Looser pattern for env var names like SECRET_KEY, API_TOKEN (no \b needed)
    _ENV_VAR_SECRET_RE = re.compile(
        r"(?i)(password|passwd|secret|token|credential|private|api.key|auth.token|access.key)",
    )

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _flag(self, node: ast.Call, name: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-010",
            rule_name="Secret leaked into log",
            severity=Severity.WARNING,
            message=f"Logging call may expose secret '{name}' — visible in log aggregators and monitoring",
            hint="Never log credential values. Log only non-sensitive metadata.",
            authority="OWASP A09:2021 – Security Logging and Monitoring Failures / CWE-532",
            docs_url="https://owasp.org/Top10/A09_2021-Security_Logging_and_Monitoring_Failures/",
        ))

    def _is_logging_call(self, node: ast.Call) -> bool:
        chain = _attr_chain(node.func)
        if not chain:
            return False
        return chain[-1] in self._LOG_ATTRS

    def _fstring_has_secret(self, node: ast.JoinedStr) -> str | None:
        """Return the first secret name found inside the f-string, or None."""
        for value in ast.walk(node):
            if isinstance(value, ast.Name) and _SEC_NAME_RE.search(value.id):
                return value.id
            if isinstance(value, ast.Attribute) and _SEC_NAME_RE.search(value.attr):
                return value.attr
        return None

    def _is_os_environ(self, node: ast.expr) -> bool:
        chain = _attr_chain(node)
        return chain == ["os", "environ"]

    def _is_os_getenv_secret(self, node: ast.expr) -> str | None:
        """Return key name if node is os.getenv('SECRET_*') with a secret key."""
        if not isinstance(node, ast.Call):
            return None
        chain = _attr_chain(node.func)
        if chain not in (["os", "getenv"], ["os", "environ", "get"]):
            return None
        if node.args and isinstance(node.args[0], ast.Constant):
            key = str(node.args[0].value)
            if _SEC_NAME_RE.search(key) or self._ENV_VAR_SECRET_RE.search(key):
                return key
        return None

    def _check_arg(self, node: ast.Call, arg: ast.expr) -> bool:
        """Inspect a single argument (positional/var-kwarg). Return True if flagged."""
        # f-string containing a secret variable
        if isinstance(arg, ast.JoinedStr):
            name = self._fstring_has_secret(arg)
            if name:
                self._flag(node, name)
                return True
        # os.environ passed directly
        if self._is_os_environ(arg):
            self._flag(node, "os.environ")
            return True
        # os.getenv("SECRET_KEY") or os.environ.get("SECRET_KEY")
        key = self._is_os_getenv_secret(arg)
        if key:
            self._flag(node, key)
            return True
        # bare Name or Attribute matching a secret name
        if isinstance(arg, ast.Name) and _SEC_NAME_RE.search(arg.id):
            self._flag(node, arg.id)
            return True
        if isinstance(arg, ast.Attribute) and _SEC_NAME_RE.search(arg.attr):
            self._flag(node, arg.attr)
            return True
        return False

    def _check_extra_dict(self, node: ast.Call, extra: ast.expr) -> bool:
        """Check `extra={"token": secret_value}` kwarg values for secrets."""
        if not isinstance(extra, ast.Dict):
            return False
        for k, v in zip(extra.keys, extra.values):
            # secret-named key — flag regardless of value
            if isinstance(k, ast.Constant) and isinstance(k.value, str) and _SEC_NAME_RE.search(k.value):
                self._flag(node, k.value)
                return True
            # secret value (Name / Attribute / fstring containing secret)
            if isinstance(v, ast.Name) and _SEC_NAME_RE.search(v.id):
                self._flag(node, v.id)
                return True
            if isinstance(v, ast.Attribute) and _SEC_NAME_RE.search(v.attr):
                self._flag(node, v.attr)
                return True
            if isinstance(v, ast.JoinedStr):
                name = self._fstring_has_secret(v)
                if name:
                    self._flag(node, name)
                    return True
        return False

    def visit_Call(self, node: ast.Call) -> None:
        if not self._is_logging_call(node):
            self.generic_visit(node)
            return

        # Positional args + var-kwarg expansion
        all_args = list(node.args) + [kw.value for kw in node.keywords if kw.arg is None]

        flagged = False
        for arg in all_args:
            if self._check_arg(node, arg):
                flagged = True
                break

        # logger.info("...", extra={"token": secret}) — check extra= kwarg
        if not flagged:
            for kw in node.keywords:
                if kw.arg == "extra":
                    if self._check_extra_dict(node, kw.value):
                        flagged = True
                        break

        self.generic_visit(node)


class _S011Visitor(ast.NodeVisitor):
    """Insecure cipher mode via cryptography.hazmat."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        if not chain:
            self.generic_visit(node)
            return
        last = chain[-1]

        if last == "ECB":
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-011",
                rule_name="Insecure cipher mode: ECB",
                severity=Severity.ERROR,
                message="ECB mode is deterministic — identical plaintext blocks produce identical ciphertext",
                hint="Use AES-256-GCM: from cryptography.hazmat.primitives.ciphers.aead import AESGCM",
                authority="NIST SP 800-131A / CWE-327",
                docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-131Ar2.pdf",
            ))
        elif last == "ARC4":
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-011",
                rule_name="Insecure cipher: RC4 (ARC4)",
                severity=Severity.ERROR,
                message="RC4 (ARC4) is broken — do not use for any security purpose",
                hint="Use AES-256-GCM: from cryptography.hazmat.primitives.ciphers.aead import AESGCM",
                authority="NIST SP 800-131A / CWE-327",
                docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-131Ar2.pdf",
            ))
        elif last in ("TripleDES", "3DES"):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-S-011",
                rule_name="Deprecated cipher: 3DES/TripleDES",
                severity=Severity.WARNING,
                message="3DES/TripleDES is deprecated (NIST 2023)",
                hint="Use AES-256-GCM: from cryptography.hazmat.primitives.ciphers.aead import AESGCM",
                authority="NIST SP 800-131A / CWE-327",
                docs_url="https://nvlpubs.nist.gov/nistpubs/SpecialPublications/NIST.SP.800-131Ar2.pdf",
            ))

        self.generic_visit(node)


class _S012Visitor(ast.NodeVisitor):
    """Regex injection / ReDoS — non-literal pattern passed to re functions.

    Skips patterns that resolve to module-level string constants (e.g.
    ``EMAIL_RE = r"..."`` then ``re.match(EMAIL_RE, x)``) — these are not
    user-supplied and triggering on them is a high false-positive source.
    """

    _RE_FUNCS = frozenset({"compile", "match", "search", "fullmatch", "findall", "sub", "subn"})

    def __init__(self, path: Path, tree: ast.Module | None = None):
        self.path = path
        self.findings: list[Finding] = []
        # Names of module-level string constants (assigned to a Constant).
        self._module_string_constants: set[str] = set()
        if tree is not None:
            self._collect_module_constants(tree)

    def _collect_module_constants(self, tree: ast.Module) -> None:
        for stmt in tree.body:
            # `NAME = "literal"` or `NAME: str = "literal"`
            if isinstance(stmt, ast.Assign):
                if isinstance(stmt.value, ast.Constant):
                    for t in stmt.targets:
                        if isinstance(t, ast.Name):
                            self._module_string_constants.add(t.id)
            elif isinstance(stmt, ast.AnnAssign):
                if (
                    stmt.value is not None
                    and isinstance(stmt.value, ast.Constant)
                    and isinstance(stmt.target, ast.Name)
                ):
                    self._module_string_constants.add(stmt.target.id)

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        if len(chain) == 2 and chain[0] == "re" and chain[1] in self._RE_FUNCS:
            if node.args and not isinstance(node.args[0], ast.Constant):
                arg0 = node.args[0]
                # Skip if the pattern resolves to a module-level constant.
                if (
                    isinstance(arg0, ast.Name)
                    and arg0.id in self._module_string_constants
                ):
                    self.generic_visit(node)
                    return
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-012",
                    rule_name="Regex injection / ReDoS",
                    severity=Severity.WARNING,
                    message=(
                        f"re.{chain[1]}() called with a non-literal pattern — "
                        "regex injection / ReDoS risk if pattern is user-supplied"
                    ),
                    hint="Validate or sanitise user-supplied regex patterns. Consider re.escape() for literal matching.",
                    authority="CWE-1333 – Inefficient Regular Expression Complexity",
                    docs_url="https://cwe.mitre.org/data/definitions/1333.html",
                ))
        self.generic_visit(node)


class _S013Visitor(ast.NodeVisitor):
    """Open redirect via unvalidated URL from user input."""

    _REDIRECT_FUNCS = frozenset({
        "redirect",
        "HttpResponseRedirect",
        "RedirectResponse",  # Starlette / FastAPI
    })
    _REQUEST_GET_ATTRS = frozenset({"args", "form", "GET", "POST"})
    _UNSAFE_NAMES = re.compile(
        r"(?i)\b(next|redirect_url|return_url|next_url|callback_url)\b"
    )

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _is_request_url(self, node: ast.expr) -> bool:
        """True if node is request.args.get(...), request.GET.get(...) etc."""
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "get":
                obj = node.func.value
                if (
                    isinstance(obj, ast.Attribute)
                    and obj.attr in self._REQUEST_GET_ATTRS
                    and isinstance(obj.value, ast.Name)
                    and obj.value.id == "request"
                ):
                    return True
        return False

    def _is_unsafe_name(self, node: ast.expr) -> bool:
        return isinstance(node, ast.Name) and bool(self._UNSAFE_NAMES.search(node.id))

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        func_name = chain[-1] if chain else None
        # werkzeug.utils.redirect — chain ends with 'redirect' (already covered);
        # also explicitly accept ['werkzeug', 'utils', 'redirect'].
        is_redirect = (
            func_name in self._REDIRECT_FUNCS
            or chain == ["werkzeug", "utils", "redirect"]
        )
        if is_redirect and node.args:
            arg0 = node.args[0]
            if self._is_request_url(arg0) or self._is_unsafe_name(arg0):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-013",
                    rule_name="Open redirect",
                    severity=Severity.WARNING,
                    message="redirect() called with an unvalidated URL from user input — open redirect risk",
                    hint="Validate redirect URLs against an allowlist of trusted domains before redirecting.",
                    authority="OWASP A01:2021 – Broken Access Control / CWE-601",
                    docs_url="https://owasp.org/Top10/A01_2021-Broken_Access_Control/",
                ))
        self.generic_visit(node)


class _S014Visitor(ast.NodeVisitor):
    """TLS verification disabled — verify=False on a requests/httpx call."""

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        for kw in node.keywords:
            if kw.arg != "verify":
                continue
            if not isinstance(kw.value, ast.Constant):
                continue
            v = kw.value.value
            if v is False or v == 0:
                attr = _call_attr(node) or "<call>"
                self.findings.append(Finding(
                    file=str(self.path),
                    line=node.lineno,
                    col=node.col_offset,
                    rule_id="PROOFCTL-S-014",
                    rule_name="TLS certificate verification disabled",
                    severity=Severity.ERROR,
                    message=(
                        f"{attr}(..., verify=False) — TLS certificate verification "
                        "disabled, allows MITM attacks"
                    ),
                    hint="Remove verify=False. Use a trusted CA bundle or pin certificates.",
                    authority="OWASP A02:2021 – Cryptographic Failures / CWE-295",
                    docs_url="https://cwe.mitre.org/data/definitions/295.html",
                ))
                break
        self.generic_visit(node)


class _S015Visitor(ast.NodeVisitor):
    """random.* used for a security-sensitive value.

    Fires when a random.* call appears on the RHS of an assignment whose target
    name matches the security-name pattern, OR when the call is the return value
    of a function whose name matches the same pattern.
    """

    _RANDOM_FUNCS = frozenset({
        "choice", "choices", "sample", "random", "randint",
        "randrange", "uniform", "getrandbits",
    })

    _SENSITIVE_RE = re.compile(
        r"(?i)(password|passwd|pwd|secret|api_?key|access_?token|"
        r"auth_?token|nonce|salt|csrf|session_?id|token)"
    )

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def _is_random_call(self, node: ast.expr) -> str | None:
        if not isinstance(node, ast.Call):
            return None
        chain = _attr_chain(node.func)
        if len(chain) == 2 and chain[0] == "random" and chain[1] in self._RANDOM_FUNCS:
            return chain[1]
        return None

    def _flag(self, call: ast.Call, fn: str, target: str) -> None:
        self.findings.append(Finding(
            file=str(self.path),
            line=call.lineno,
            col=call.col_offset,
            rule_id="PROOFCTL-S-015",
            rule_name="Insecure random for security-sensitive value",
            severity=Severity.WARNING,
            message=(
                f"random.{fn}() used for '{target}' — random module is not "
                "cryptographically secure"
            ),
            hint="Use the secrets module: secrets.token_hex(), secrets.choice(), secrets.randbelow().",
            authority="CWE-330 – Use of Insufficiently Random Values",
            docs_url="https://cwe.mitre.org/data/definitions/330.html",
        ))

    def _scan_value(self, value: ast.expr, target_name: str) -> None:
        if not self._SENSITIVE_RE.search(target_name):
            return
        for node in ast.walk(value):
            fn = self._is_random_call(node)
            if fn:
                self._flag(node, fn, target_name)

    def visit_Assign(self, node: ast.Assign) -> None:
        for t in node.targets:
            name = _assign_target_name(t)
            if name:
                self._scan_value(node.value, name)
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        if node.value is not None:
            name = _assign_target_name(node.target)
            if name:
                self._scan_value(node.value, name)
        self.generic_visit(node)

    def _process_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if self._SENSITIVE_RE.search(node.name):
            for sub in ast.walk(node):
                if isinstance(sub, ast.Return) and sub.value is not None:
                    fn = self._is_random_call(sub.value)
                    if fn:
                        self._flag(sub.value, fn, node.name)
                    else:
                        # Walk into expressions like ''.join(random.choice(..) for _)
                        for inner in ast.walk(sub.value):
                            fn = self._is_random_call(inner)
                            if fn:
                                self._flag(inner, fn, node.name)
                                break
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._process_function(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._process_function(node)


class _S016Visitor(ast.NodeVisitor):
    """subprocess called with a partial-path executable name.

    Detects subprocess.run/call/Popen/check_output/check_call/getoutput/getstatusoutput
    where the first arg (or list[0]) is a literal command without '/' — vulnerable
    to PATH manipulation. Common stdlib/dev tools fire INFO; everything else WARNING.
    """

    _FUNCS = frozenset({
        "run", "call", "Popen", "check_output", "check_call",
        "getoutput", "getstatusoutput",
    })

    _COMMON_TOOLS = frozenset({
        "python", "python3", "pip", "pip3", "node", "npm",
        "git", "make", "bash", "sh", "pytest", "coverage",
    })

    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_Call(self, node: ast.Call) -> None:
        chain = _attr_chain(node.func)
        if not (len(chain) == 2 and chain[0] == "subprocess" and chain[1] in self._FUNCS):
            self.generic_visit(node)
            return

        # S-002 already covers shell=True; skip that case to avoid double-firing.
        if _kwarg_is_true(node, "shell"):
            self.generic_visit(node)
            return

        if not node.args:
            self.generic_visit(node)
            return

        first = node.args[0]
        cmd: str | None = None
        if isinstance(first, ast.Constant) and isinstance(first.value, str):
            cmd = first.value
        elif isinstance(first, ast.List) and first.elts:
            head = first.elts[0]
            if isinstance(head, ast.Constant) and isinstance(head.value, str):
                cmd = head.value

        if cmd is None or "/" in cmd or not cmd:
            self.generic_visit(node)
            return

        # Skip if it looks like an absolute Windows path or has any path separator.
        if "\\" in cmd:
            self.generic_visit(node)
            return

        sev = Severity.INFO if cmd in self._COMMON_TOOLS else Severity.WARNING
        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id="PROOFCTL-S-016",
            rule_name="subprocess with partial executable path",
            severity=sev,
            message=(
                f"subprocess.{chain[1]}() invokes '{cmd}' by name — "
                "PATH manipulation can substitute a malicious binary"
            ),
            hint="Use a full path: subprocess.run(['/usr/bin/" + cmd + "', ...]).",
            authority="CWE-426 – Untrusted Search Path",
            docs_url="https://cwe.mitre.org/data/definitions/426.html",
        ))
        self.generic_visit(node)


# ── Checker ───────────────────────────────────────────────────────────────────

class SecurityChecker(FileChecker):
    """PROOFCTL-S-* — security vulnerabilities AI models introduce at high rates."""

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        if tree is None:
            return []

        out: list[Finding] = []

        # Visitors that need module-level pre-scans.
        v003 = _S003Visitor(path, tree=tree)
        v003.visit(tree)
        out.extend(v003.findings)

        v006 = _S006Visitor(path, tree=tree)
        v006.visit(tree)
        out.extend(v006.findings)

        v012 = _S012Visitor(path, tree=tree)
        v012.visit(tree)
        out.extend(v012.findings)

        for Visitor in (
            _S001Visitor,
            _S002Visitor,
            _S004Visitor,
            _S005Visitor,
            _S007Visitor,
            _S008Visitor,
            _S009Visitor,
            _S010Visitor,
            _S011Visitor,
            _S013Visitor,
            _S014Visitor,
            _S015Visitor,
            _S016Visitor,
        ):
            v = Visitor(path)
            v.visit(tree)
            out.extend(v.findings)
        return out
