from __future__ import annotations

import ast
from abc import ABC, abstractmethod
from pathlib import Path

from ..models import Finding


class FileChecker(ABC):
    """Runs once per Python file. Receives path, raw source, and parsed AST (None on SyntaxError)."""

    @abstractmethod
    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        ...


class DirectoryChecker(ABC):
    """Runs once per scan root. Used for cross-file analysis."""

    @abstractmethod
    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        ...


class HclFileChecker(ABC):
    """Runs once per HCL file (.tf, .tfvars, .hcl).

    Subclasses declare which extensions they handle via the `extensions` class
    variable.  An empty tuple means "run on all HCL files".
    """

    extensions: tuple[str, ...] = ()

    @abstractmethod
    def check(self, path: Path, source: str) -> list[Finding]:
        ...


class HclDirChecker(ABC):
    """Runs once per scan root for cross-file HCL analysis."""

    @abstractmethod
    def check(self, root: Path, hcl_files: list[Path]) -> list[Finding]:
        ...


class DockerfileChecker(ABC):
    """Runs on Dockerfile* files (pure text, no AST)."""

    @abstractmethod
    def check(self, path: Path, source: str) -> list[Finding]:
        ...


class YamlFileChecker(ABC):
    """Runs on .yml / .yaml files (parsed via PyYAML)."""

    @abstractmethod
    def check(self, path: Path, source: str) -> list[Finding]:
        ...


class ShellFileChecker(ABC):
    """Runs on shell script files (.sh, .bash, .zsh, .ksh)."""

    extensions: tuple[str, ...] = (".sh", ".bash", ".zsh", ".ksh")

    @abstractmethod
    def check(self, path: Path, source: str) -> list[Finding]:
        ...
