from __future__ import annotations

import re
from dataclasses import dataclass, field

# Matches the header of a block: keyword (label1)? (label2)? {
# Labels may be quoted ("aws_vpc") or bare (aws_vpc). Terraform tolerates the
# bare form on `resource <type> "name"`, e.g. terragoat's `resource aws_vpc`.
_BLOCK_HEADER_RE = re.compile(
    r'^\s*(\w+)'                            # kind
    r'(?:\s+(?:"([^"]*)"|([A-Za-z_]\w*)))?' # optional label1: quoted or bare ident
    r'(?:\s+(?:"([^"]*)"|([A-Za-z_]\w*)))?' # optional label2: quoted or bare ident
    r'\s*\{'                                # opening brace
)

_HEREDOC_START_RE = re.compile(r'<<[-~]?(\w+)\s*$')


@dataclass
class HclBlock:
    kind: str
    label1: str
    label2: str
    start_line: int      # 1-based, line of the block header
    end_line: int        # 1-based, line of the closing brace
    raw_lines: list[str] = field(repr=False)

    # ── Attribute helpers ────────────────────────────────────────────────────

    def attr(self, name: str) -> tuple[str, int] | None:
        """Return (raw_value_str, abs_lineno) for the first `name = …` in this block."""
        pat = re.compile(rf'^\s*{re.escape(name)}\s*=\s*(.*?)(?:\s*#.*)?$')
        for i, line in enumerate(self.raw_lines):
            m = pat.match(line)
            if m:
                return m.group(1).strip(), self.start_line + i
        return None

    def has_attr(self, name: str) -> bool:
        return self.attr(name) is not None

    def attr_value(self, name: str) -> str | None:
        r = self.attr(name)
        return r[0] if r else None

    def attr_line(self, name: str) -> int | None:
        r = self.attr(name)
        return r[1] if r else None

    # ── Nested block helpers ─────────────────────────────────────────────────

    def nested(self, kind: str) -> list[HclBlock]:
        """Directly nested blocks of the given kind."""
        inner = _parse(self.raw_lines, base=self.start_line, skip_outer=True)
        return [b for b in inner if b.kind == kind]

    def has_nested(self, kind: str) -> bool:
        return bool(self.nested(kind))

    # ── Raw text helpers ─────────────────────────────────────────────────────

    def any_line_matches(self, pattern: str, flags: int = 0) -> int | None:
        """Return abs 1-based lineno of first matching line, or None."""
        pat = re.compile(pattern, flags)
        for i, line in enumerate(self.raw_lines):
            if pat.search(line):
                return self.start_line + i
        return None

    def contains(self, pattern: str, flags: int = 0) -> bool:
        return self.any_line_matches(pattern, flags) is not None


# ── Parser ───────────────────────────────────────────────────────────────────


def parse_blocks(source: str) -> list[HclBlock]:
    """Parse top-level HCL blocks from *source*, returning a flat list."""
    return _parse(source.splitlines(), base=1, skip_outer=False)


def _is_escaped(line: str, idx: int) -> bool:
    """True if `line[idx]` is preceded by an odd run of backslashes.

    Counting the run is the only correct way to tell `\\"` (escaped backslash
    followed by an unescaped quote) from `\"` (escaped quote). The previous
    one-character lookback `line[i-1] == '\\\\'` got this wrong: in
    `password = "my\\\\\\"secret"`, it treated the closing quote as escaped
    and tokenisation silently broke for every rule that walked block bodies.
    """
    n = 0
    j = idx - 1
    while j >= 0 and line[j] == "\\":
        n += 1
        j -= 1
    return n % 2 == 1


def _strip_comment(line: str) -> str:
    in_str = False
    i = 0
    while i < len(line):
        c = line[i]
        if c == '"' and not _is_escaped(line, i):
            in_str = not in_str
        if not in_str:
            if c == '#':
                return line[:i]
            if c == '/' and i + 1 < len(line) and line[i + 1] == '/':
                return line[:i]
        i += 1
    return line


def _brace_delta(line: str) -> int:
    s = _strip_comment(line)
    opens = closes = 0
    in_str = False
    i = 0
    while i < len(s):
        c = s[i]
        if in_str and c == "\\" and i + 1 < len(s):
            i += 2  # skip escaped character (e.g. \" inside a string)
            continue
        if c == '"':
            in_str = not in_str
        elif not in_str:
            if c == '{':
                opens += 1
            elif c == '}':
                closes += 1
        i += 1
    return opens - closes


def _parse(lines: list[str], base: int, skip_outer: bool) -> list[HclBlock]:
    """
    Parse HCL blocks from *lines*.

    base:        1-based absolute line number of lines[0].
    skip_outer:  True when lines is the raw_lines of a parent block — we skip
                 the first and last lines (header / closing brace).
    """
    blocks: list[HclBlock] = []
    depth = 0
    block_start_idx: int | None = None
    block_kind = block_label1 = block_label2 = ""
    heredoc_end: str | None = None

    start = 1 if skip_outer else 0
    end = len(lines) - (1 if skip_outer else 0)

    for i in range(start, end):
        line = lines[i]
        lineno = base + i

        # ── heredoc passthrough ──
        if heredoc_end:
            # The end label must appear on a line of its own (whitespace either
            # side allowed for `<<-` indented heredocs). The previous loose
            # `rstrip("-~")` matched lines like `EOF~~~` as terminators, which
            # could prematurely close a heredoc whose body legitimately ended
            # with `~`. C-11 fix: strict whole-line match after .strip().
            if line.strip() == heredoc_end:
                heredoc_end = None
            continue
        hm = _HEREDOC_START_RE.search(line)
        if hm:
            heredoc_end = hm.group(1)

        delta = _brace_delta(line)

        if depth == 0 and delta > 0:
            m = _BLOCK_HEADER_RE.match(line)
            if m:
                block_kind = m.group(1)
                # group 2 = quoted label1, group 3 = bare label1
                block_label1 = m.group(2) or m.group(3) or ""
                # group 4 = quoted label2, group 5 = bare label2
                block_label2 = m.group(4) or m.group(5) or ""
                block_start_idx = i
                depth += delta
                if depth == 0:
                    # Single-line block (opened and closed on same line)
                    blocks.append(HclBlock(
                        kind=block_kind, label1=block_label1, label2=block_label2,
                        start_line=lineno, end_line=lineno,
                        raw_lines=lines[i:i + 1],
                    ))
                    block_start_idx = None
            continue  # pragma: no cover

        if depth > 0:
            depth += delta
            if depth <= 0:
                depth = 0
                if block_start_idx is not None:
                    blocks.append(HclBlock(
                        kind=block_kind, label1=block_label1, label2=block_label2,
                        start_line=base + block_start_idx,
                        end_line=lineno,
                        raw_lines=lines[block_start_idx:i + 1],
                    ))
                    block_start_idx = None

    return blocks
