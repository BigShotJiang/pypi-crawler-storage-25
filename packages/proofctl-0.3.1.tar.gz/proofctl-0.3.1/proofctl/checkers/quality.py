from __future__ import annotations

import ast
import re
from pathlib import Path
from typing import Iterator

from ..models import Finding, Severity
from .base import FileChecker, DirectoryChecker

_MUTABLE_TYPES = frozenset({"list", "dict", "set", "defaultdict", "OrderedDict", "Counter"})
_ANY_IGNORE_RE = re.compile(r"#\s*type:\s*ignore(?!\s*\[)(?!\s*#)")
_TEST_PATH_COMPONENTS = frozenset({"tests", "test"})
_TEST_FILE_RE = re.compile(r"^(test_.+|.+_test)\.py$")
_Q009_SKIP_PATH_COMPONENTS = frozenset({"examples", "scripts", "samples", "demo"})


def _is_test_file(path: Path) -> bool:
    return (
        any(p in _TEST_PATH_COMPONENTS for p in path.parts)
        or bool(_TEST_FILE_RE.match(path.name))
    )


def _is_mutable_default(node: ast.expr) -> bool:
    if isinstance(node, (ast.List, ast.Dict, ast.Set)):
        return True
    if isinstance(node, ast.Call):
        func = node.func
        name = func.id if isinstance(func, ast.Name) else (
            func.attr if isinstance(func, ast.Attribute) else None
        )
        if name in _MUTABLE_TYPES:
            return True
    return False


class _Q001Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        args = node.args
        # defaults align to the LAST N positional args; kw_defaults align to kwargs
        defaults = args.defaults
        kwdefaults = [d for d in (args.kw_defaults or []) if d is not None]

        all_defaults = list(defaults) + list(kwdefaults)
        for default in all_defaults:
            if _is_mutable_default(default):
                type_name = (
                    type(default).__name__
                    if isinstance(default, (ast.List, ast.Dict, ast.Set))
                    else (default.func.id if isinstance(default.func, ast.Name) else "mutable")
                )
                # Sync `fixable` with fixer.py capability: the auto-fixer can only
                # rewrite single-line default expressions. Multi-line literals
                # (e.g. nested dict/list spanning several lines) are skipped by
                # the fixer (see proofctl/fixer.py: `default_node.lineno ==
                # default_node.end_lineno`). Advertise this honestly to avoid
                # `--fix` reporting "fixable" findings it cannot resolve.
                end_lineno = getattr(default, "end_lineno", default.lineno)
                is_single_line = end_lineno is None or end_lineno == default.lineno
                self.findings.append(Finding(
                    file=str(self.path),
                    line=default.lineno,
                    col=default.col_offset,
                    rule_id="PROOFCTL-Q-001",
                    rule_name="Mutable default argument",
                    severity=Severity.ERROR,
                    message=(
                        f"'{node.name}' has a mutable {type_name} default argument — "
                        "shared across all calls"
                    ),
                    hint="Use None as default and initialize inside the function body.",
                    authority="Python Gotchas – Mutable Default Arguments",
                    docs_url="https://docs.python-guide.org/writing/gotchas/#mutable-default-arguments",
                    fixable=is_single_line,
                ))


class _Q002Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        bare = node.type is None
        broad = (
            node.type is not None
            and isinstance(node.type, ast.Name)
            and node.type.id in ("Exception", "BaseException")
        )
        if not (bare or broad):
            self.generic_visit(node)
            return

        # Check if body is just pass / just a log call
        body = node.body
        is_suppressed = (
            len(body) == 1
            and isinstance(body[0], ast.Pass)
        )
        is_log_only = (
            len(body) == 1
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Call)
        )
        # Re-raise within the handler scope (not nested function/class bodies)
        has_raise = self._handler_reraises(node)

        if has_raise:
            self.generic_visit(node)
            return

        if bare:
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.ERROR
            msg = "Bare except: catches KeyboardInterrupt, SystemExit, and all exceptions silently"
            hint = "Catch specific exceptions: except (ValueError, KeyError) as e:"
        elif is_suppressed or is_log_only:
            # Tier 1 (WARNING): obvious swallow — body is `pass` or a single call (likely log).
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.WARNING
            msg = "Broad except Exception with no re-raise swallows all errors"
            hint = "Catch specific exceptions or re-raise: except Exception as e: ... raise"
        else:
            # Tier 2 (INFO, H-16): any other broad-except that doesn't re-raise.
            # Catches the wider "swallows but does five lines of dummy recovery"
            # pattern that the WARNING tier misses.
            rule_id = "PROOFCTL-Q-002"
            sev = Severity.INFO
            msg = (
                "Broad except Exception without re-raise — recovery code may be "
                "hiding real failures"
            )
            hint = (
                "Catch specific exceptions, or re-raise after handling: "
                "except Exception: ... raise"
            )

        self.findings.append(Finding(
            file=str(self.path),
            line=node.lineno,
            col=node.col_offset,
            rule_id=rule_id,
            rule_name="Broad exception handler",
            severity=sev,
            message=msg,
            hint=hint,
            authority="OWASP A10:2025 – Mishandling of Exceptional Conditions",
            docs_url="https://owasp.org/www-community/vulnerabilities/Improper_Error_Handling",
        ))
        self.generic_visit(node)

    @staticmethod
    def _handler_reraises(handler: ast.ExceptHandler) -> bool:
        """Return True if the handler body re-raises (raise at handler scope).

        Walks the body excluding nested function/class definitions whose
        `raise` statements would not propagate out of the handler when reached.
        """
        for stmt in handler.body:
            for node in _walk_no_nested(stmt):
                if isinstance(node, ast.Raise):
                    return True
        return False


class _Q003Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.any_uses: list[ast.AST] = []

    def visit_Name(self, node: ast.Name) -> None:
        if node.id == "Any":
            self.any_uses.append(node)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr == "Any":
            self.any_uses.append(node)
        self.generic_visit(node)


class _AbstractClassInfo:
    def __init__(self, node: ast.ClassDef, file: str):
        self.node = node
        self.file = file
        self.name = node.name
        self.bases: set[str] = set()
        for base in node.bases:
            if isinstance(base, ast.Name):
                self.bases.add(base.id)
            elif isinstance(base, ast.Attribute):
                self.bases.add(base.attr)
        self.has_abstract_method = any(
            "abstractmethod" in {
                d.id if isinstance(d, ast.Name) else
                d.attr if isinstance(d, ast.Attribute) else ""
                for d in n.decorator_list
            }
            for n in ast.walk(node)
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
        )
        self.is_abc = (
            "ABC" in self.bases
            or "Protocol" in self.bases
            or self.has_abstract_method
        )


# ── Q-005: cyclomatic complexity ──────────────────────────────────────────────

def _walk_no_nested(node: ast.AST) -> Iterator[ast.AST]:
    """Yield all descendant nodes, not descending into nested function/class defs."""
    yield node
    for child in ast.iter_child_nodes(node):
        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue  # nested scope — counted separately
        yield from _walk_no_nested(child)


def _cyclomatic_complexity(func: ast.FunctionDef | ast.AsyncFunctionDef) -> int:
    complexity = 1
    # `ast.Match` / `ast.match_case` exist on Python 3.10+. Reference via
    # getattr so this module still imports cleanly on older interpreters.
    match_node = getattr(ast, "Match", None)
    match_case_node = getattr(ast, "match_case", None)
    for node in _walk_no_nested(func):
        if node is func:
            continue
        if isinstance(node, (ast.If, ast.While, ast.For, ast.AsyncFor)):
            complexity += 1
        elif isinstance(node, ast.ExceptHandler):
            complexity += 1
        elif isinstance(node, ast.BoolOp):
            complexity += len(node.values) - 1
        elif isinstance(node, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
            complexity += 1
        # H-17: count match/case statements toward complexity.
        # `match` itself adds 1 (the dispatch decision); each `case` arm adds 1
        # (each is a distinct execution path).
        elif match_node is not None and isinstance(node, match_node):
            complexity += 1
        elif match_case_node is not None and isinstance(node, match_case_node):
            complexity += 1
    return complexity


class _Q005Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_threshold: int, error_threshold: int):
        self.path = path
        self.warn = warn_threshold
        self.error = error_threshold
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        cc = _cyclomatic_complexity(node)
        if cc > self.warn:
            sev = Severity.ERROR if cc > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-005",
                rule_name="High cyclomatic complexity",
                severity=sev,
                message=f"'{node.name}' has cyclomatic complexity {cc} (threshold: {self.warn})",
                hint=(
                    "Break the function into smaller, single-purpose functions. "
                    "Each branch is a candidate for extraction."
                ),
                authority="Clean Code Ch. 3 – Functions / McCabe 1976",
                docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-006: function too long ──────────────────────────────────────────────────

class _Q006Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_lines: int, error_lines: int):
        self.path = path
        self.warn = warn_lines
        self.error = error_lines
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        if node.end_lineno is None:
            return
        length = node.end_lineno - node.lineno
        if length > self.warn:
            sev = Severity.ERROR if length > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-006",
                rule_name="Function too long",
                severity=sev,
                message=f"'{node.name}' is {length} lines long (threshold: {self.warn})",
                hint="Extract logical sub-steps into well-named helper functions.",
                authority="Clean Code Ch. 3 – Functions should be small",
                docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-007: too many function parameters ──────────────────────────────────────

class _Q007Visitor(ast.NodeVisitor):
    def __init__(self, path: Path, warn_params: int, error_params: int):
        self.path = path
        self.warn = warn_params
        self.error = error_params
        self.findings: list[Finding] = []

    def _check(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        args = node.args
        params = list(args.posonlyargs) + list(args.args)
        # Remove self / cls for methods
        if params and params[0].arg in ("self", "cls"):
            params = params[1:]
        # H-18: keyword-only arguments are real parameters too — `def f(*, a, b,
        # c, d, e, f, g, h)` is just as overloaded as a positional version.
        params += list(args.kwonlyargs)
        count = len(params)
        if count > self.warn:
            sev = Severity.ERROR if count > self.error else Severity.WARNING
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-007",
                rule_name="Too many function parameters",
                severity=sev,
                message=f"'{node.name}' has {count} parameters (threshold: {self.warn})",
                hint=(
                    "Group related parameters into a dataclass or config object. "
                    "Clean Code: ideal is 0–2 args; >3 needs justification."
                ),
                authority="Clean Code Ch. 3 – Function Arguments",
                docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
            ))

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check(node)
        self.generic_visit(node)


# ── Q-008: boolean flag argument ─────────────────────────────────────────────

def _collect_dataclass_names(tree: ast.Module) -> set[str]:
    """Return names of module-level classes decorated with @dataclass.

    Recognises both `@dataclass` (bare) and `@dataclasses.dataclass`, with or
    without arguments (e.g. `@dataclass(frozen=True)`).
    """
    names: set[str] = set()
    for node in tree.body:
        if not isinstance(node, ast.ClassDef):
            continue
        for dec in node.decorator_list:
            target = dec.func if isinstance(dec, ast.Call) else dec
            if isinstance(target, ast.Name) and target.id == "dataclass":
                names.add(node.name)
                break
            if (
                isinstance(target, ast.Attribute)
                and target.attr == "dataclass"
                and isinstance(target.value, ast.Name)
                and target.value.id == "dataclasses"
            ):
                names.add(node.name)
                break
    return names


class _Q008Visitor(ast.NodeVisitor):
    """Flag True/False passed as a *positional* argument — indicates a function does two things."""

    def __init__(self, path: Path, dataclass_names: frozenset[str] = frozenset()):
        self.path = path
        self.findings: list[Finding] = []
        self._dataclass_names = dataclass_names

    def visit_Call(self, node: ast.Call) -> None:
        # Skip common false positives: bool(), int(), str(), print(), assert*
        _SKIP = frozenset({"bool", "int", "str", "float", "print", "append", "assertEqual", "assertTrue", "assertFalse"})
        func_name = (
            node.func.id if isinstance(node.func, ast.Name)
            else node.func.attr if isinstance(node.func, ast.Attribute)
            else None
        )
        if func_name in _SKIP or (func_name and func_name.startswith("assert")):
            self.generic_visit(node)
            return

        # `setattr(obj, "flag", True)` — the third positional argument is the
        # value being assigned, not a behaviour-changing flag. The flag-arg
        # anti-pattern is about *function* boolean arguments, not data writes.
        if (
            isinstance(node.func, ast.Name)
            and node.func.id == "setattr"
            and len(node.args) == 3
        ):
            self.generic_visit(node)
            return

        # Constructor call to a module-level @dataclass class: positional bool
        # arguments here are field values, not flag-arguments. Dataclass init
        # signatures mirror the field declaration order, so the flag-arg
        # anti-pattern doesn't apply.
        if (
            isinstance(node.func, ast.Name)
            and node.func.id in self._dataclass_names
        ):
            self.generic_visit(node)
            return

        for arg in node.args:
            if isinstance(arg, ast.Constant) and isinstance(arg.value, bool):
                self.findings.append(Finding(
                    file=str(self.path),
                    line=arg.lineno,
                    col=arg.col_offset,
                    rule_id="PROOFCTL-Q-008",
                    rule_name="Boolean flag argument",
                    severity=Severity.WARNING,
                    message=(
                        f"Boolean literal passed as positional argument to "
                        f"'{func_name or 'function'}' — signals the function does two things"
                    ),
                    hint=(
                        "Split into two clearly named functions, or use a keyword argument: "
                        "func(reverse=True)."
                    ),
                    authority="Clean Code Ch. 3 – Flag Arguments",
                    docs_url="https://www.oreilly.com/library/view/clean-code-a/9780136083238/",
                ))
                break  # one finding per call site
        self.generic_visit(node)


# ── Q-009: print() in production code ────────────────────────────────────────

class _Q009Visitor(ast.NodeVisitor):
    def __init__(self, path: Path):
        self.path = path
        self.findings: list[Finding] = []
        # Track whether we're descending into an `if __name__ == "__main__":`
        # block — prints inside the script entry-point are conventionally fine.
        self._in_main_guard_depth = 0

    @staticmethod
    def _is_main_guard(node: ast.If) -> bool:
        test = node.test
        if not isinstance(test, ast.Compare):
            return False
        if len(test.ops) != 1 or not isinstance(test.ops[0], ast.Eq):
            return False
        left, right = test.left, test.comparators[0]
        # Match either side: `__name__ == "__main__"` or `"__main__" == __name__`.
        def _is_dunder(n: ast.expr) -> bool:
            return isinstance(n, ast.Name) and n.id == "__name__"

        def _is_main(n: ast.expr) -> bool:
            return isinstance(n, ast.Constant) and n.value == "__main__"

        return (_is_dunder(left) and _is_main(right)) or (_is_main(left) and _is_dunder(right))

    def visit_If(self, node: ast.If) -> None:
        if self._is_main_guard(node):
            self._in_main_guard_depth += 1
            try:
                self.generic_visit(node)
            finally:
                self._in_main_guard_depth -= 1
            return
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        if (
            self._in_main_guard_depth == 0
            and isinstance(node.func, ast.Name)
            and node.func.id == "print"
        ):
            self.findings.append(Finding(
                file=str(self.path),
                line=node.lineno,
                col=node.col_offset,
                rule_id="PROOFCTL-Q-009",
                rule_name="print() in production code",
                severity=Severity.INFO,
                message="print() used in production code — output goes to stdout unstructured",
                hint="Use logging.info() / logging.debug() so output is structured and level-filtered.",
                authority="12-Factor App XI – Logs / Google SRE Book",
                docs_url="https://12factor.net/logs",
            ))
        self.generic_visit(node)


def _q009_should_skip(path: Path, source: str) -> bool:
    """Return True if Q-009 should not run for this file.

    Skips: example/script/sample/demo directories, runnable scripts (shebang),
    and Jupyter notebooks (`.ipynb`).
    """
    if any(part in _Q009_SKIP_PATH_COMPONENTS for part in path.parts):
        return True
    if path.suffix == ".ipynb":
        return True
    if source.startswith("#!"):
        return True
    return False


# ── Main checker ──────────────────────────────────────────────────────────────

class QualityChecker(FileChecker):
    def __init__(
        self,
        any_threshold: int = 3,
        complexity_warn: int = 10,
        complexity_error: int = 20,
        func_len_warn: int = 50,
        func_len_error: int = 100,
        param_warn: int = 5,
        param_error: int = 7,
    ) -> None:
        self._any_threshold = any_threshold
        self._complexity_warn = complexity_warn
        self._complexity_error = complexity_error
        self._func_len_warn = func_len_warn
        self._func_len_error = func_len_error
        self._param_warn = param_warn
        self._param_error = param_error

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        findings: list[Finding] = []
        if tree is not None:
            v1 = _Q001Visitor(path)
            v1.visit(tree)
            findings.extend(v1.findings)

            v2 = _Q002Visitor(path)
            v2.visit(tree)
            findings.extend(v2.findings)

            findings.extend(self._q003_ast(path, tree))

            v5 = _Q005Visitor(path, self._complexity_warn, self._complexity_error)
            v5.visit(tree)
            findings.extend(v5.findings)

            v6 = _Q006Visitor(path, self._func_len_warn, self._func_len_error)
            v6.visit(tree)
            findings.extend(v6.findings)

            v7 = _Q007Visitor(path, self._param_warn, self._param_error)
            v7.visit(tree)
            findings.extend(v7.findings)

            dataclass_names = frozenset(_collect_dataclass_names(tree))
            v8 = _Q008Visitor(path, dataclass_names=dataclass_names)
            v8.visit(tree)
            findings.extend(v8.findings)

            if not _is_test_file(path) and not _q009_should_skip(path, source):
                v9 = _Q009Visitor(path)
                v9.visit(tree)
                findings.extend(v9.findings)

        findings.extend(self._q003_type_ignore(path, source))
        return findings

    def _q003_ast(self, path: Path, tree: ast.Module) -> list[Finding]:
        v = _Q003Visitor(path)
        v.visit(tree)
        count = len(v.any_uses)
        if count > self._any_threshold:
            first = v.any_uses[0]
            return [Finding(
                file=str(path),
                line=getattr(first, "lineno", None),
                col=getattr(first, "col_offset", None),
                rule_id="PROOFCTL-Q-003",
                rule_name="Excessive Any type usage",
                severity=Severity.INFO,
                message=f"File uses Any {count} times (threshold: {self._any_threshold})",
                hint="Replace Any with specific types to maintain type safety.",
                authority="Effective Python Item 90 – Consider Static Analysis",
                docs_url="https://effectivepython.com/",
            )]
        return []

    def _q003_type_ignore(self, path: Path, source: str) -> list[Finding]:
        findings = []
        for lineno, line in enumerate(source.splitlines(), start=1):
            m = _ANY_IGNORE_RE.search(line)
            if m:
                findings.append(Finding(
                    file=str(path),
                    line=lineno,
                    col=m.start(),
                    rule_id="PROOFCTL-Q-003",
                    rule_name="Unexplained type: ignore",
                    severity=Severity.WARNING,
                    message="# type: ignore without a reason or error code",
                    hint="Add an error code: # type: ignore[import-untyped]",
                    authority="mypy docs – type: ignore comments",
                    docs_url="https://mypy.readthedocs.io/en/stable/inline_config.html#per-line-configuration",
                ))
        return findings


class AbstractionChecker(DirectoryChecker):
    """PROOFCTL-Q-004: Abstract classes with only one concrete implementation."""

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        abstract_classes: dict[str, _AbstractClassInfo] = {}
        all_classes: dict[str, list[str]] = {}  # class_name -> list of base names

        # TODO(perf): re-parses every Python file from disk even though the
        # engine already parsed each tree once for FileChecker passes. Proper
        # fix requires extending the DirectoryChecker API to receive parsed
        # trees from the engine; deferred to a separate PR.
        # Audit reference: AUDIT_AND_ROADMAP.md §1.3 — AbstractionChecker re-parse.
        for path in py_files:
            try:
                source = path.read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source)
            except (OSError, SyntaxError):
                continue

            for node in ast.walk(tree):
                if not isinstance(node, ast.ClassDef):
                    continue
                info = _AbstractClassInfo(node, str(path))
                if info.is_abc:
                    abstract_classes[info.name] = info
                else:
                    base_names = list(info.bases)
                    all_classes[info.name] = base_names

        findings = []
        for abc_name, abc_info in abstract_classes.items():
            if "Protocol" in abc_info.bases:
                continue
            implementors = [
                name for name, bases in all_classes.items()
                if abc_name in bases
            ]
            if len(implementors) == 1:
                findings.append(Finding(
                    file=abc_info.file,
                    line=abc_info.node.lineno,
                    col=abc_info.node.col_offset,
                    rule_id="PROOFCTL-Q-004",
                    rule_name="Single-implementation abstraction",
                    severity=Severity.INFO,
                    message=(
                        f"Abstract class '{abc_name}' has exactly one concrete "
                        f"implementation ('{implementors[0]}')"
                    ),
                    hint=(
                        "If no second implementation is planned, simplify to a "
                        "concrete class. YAGNI."
                    ),
                    authority="A Philosophy of Software Design – Deep Modules",
                    docs_url="https://web.stanford.edu/~ouster/cgi-bin/book.php",
                ))
        return findings
