from __future__ import annotations

import ast
import functools
import json
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker, DirectoryChecker

_CACHE_DIR = Path.home() / ".cache" / "proofctl" / "pypi"
_CACHE_TTL = 86_400  # 24 hours
_PYPI_TIMEOUT = 3    # seconds

# Packages known to be frequent AI hallucination targets
_HIGH_RISK_NAMES: frozenset[str] = frozenset({
    "boto4", "aiohttp-extras", "langchain-enhanced", "openai-utils",
    "anthropic-client", "fastapi-helpers", "requests-async",
    "sqlalchemy-utils-extended", "pydantic-extras", "flask-utils",
    "django-extras", "numpy-utils", "pandas-extras", "torch-utils",
    "tensorflow-extras", "scikit-learn-utils", "celery-extras",
})

# requirements.txt line: optional extras, then version specifier, then env markers / comments
_REQ_LINE_RE = re.compile(
    r"^\s*([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)"  # PEP 508 name
    r"(\[.*?\])?"                                         # optional extras
    r"\s*([~<>=!][^\s;#]*)?"                              # optional version specifier
)


def _parse_requirements(text: str) -> list[tuple[str, str | None, int]]:
    """Parse requirements.txt; returns (name, version_spec_or_None, lineno)."""
    results = []
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("-"):
            continue
        m = _REQ_LINE_RE.match(stripped)
        if m:
            results.append((m.group(1), m.group(4) or None, lineno))
    return results


def _parse_pyproject_deps(text: str) -> list[tuple[str, str | None, int]]:
    """Lightweight parser for [project] dependencies in pyproject.toml."""
    results = []
    in_deps = False
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if re.match(r"^dependencies\s*=\s*\[", stripped):
            in_deps = True
            continue
        if in_deps:
            if stripped.startswith("]"):
                in_deps = False
                continue
            # Quoted dep string: "boto4>=1.0" or 'boto4'
            m = re.match(r'["\']([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)(\[.*?\])?([^"\']*)["\']', stripped)
            if m:
                name = m.group(1)
                spec = m.group(4).strip() or None
                results.append((name, spec, lineno))
    return results


def _parse_pipfile(text: str) -> list[tuple[str, str | None, int]]:
    """Parse a Pipfile (`[packages]` and `[dev-packages]`) for dep names.

    Falls back to a line-based parser if `tomllib` rejects the file.  Best-effort
    — line numbers are accurate for the line-based pass; the tomllib pass uses
    section line numbers as a fallback.
    """
    results: list[tuple[str, str | None, int]] = []

    # Line-based scan first (gives real line numbers, very forgiving).
    section: str | None = None
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            section = stripped[1:-1].strip().lower()
            continue
        if section in ("packages", "dev-packages"):
            # name = "*" / name = ">=1.0"  /  name = { version = "*", ... }
            m = re.match(
                r'^([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)\s*=\s*(.*)$',
                stripped,
            )
            if not m:
                continue
            name = m.group(1)
            rhs = m.group(3).strip()
            spec: str | None = None
            qm = re.match(r'^["\']([^"\']*)["\']', rhs)
            if qm:
                spec = qm.group(1).strip() or None
                if spec == "*":
                    spec = None
            else:
                # Inline table: { version = "1.2.3", ... } — pull version out.
                vm = re.search(r'version\s*=\s*["\']([^"\']*)["\']', rhs)
                if vm:
                    spec = vm.group(1).strip() or None
            results.append((name, spec, lineno))
    return results


def _parse_poetry_lock(text: str) -> list[tuple[str, str | None, int]]:
    """Parse poetry.lock — `[[package]]` arrays each with a `name = "..."` field.

    Line-based to preserve line numbers without a TOML parser dependency.
    """
    results: list[tuple[str, str | None, int]] = []
    in_pkg = False
    pkg_name: str | None = None
    pkg_version: str | None = None
    pkg_lineno = 0
    for lineno, line in enumerate(text.splitlines(), start=1):
        stripped = line.strip()
        if stripped == "[[package]]":
            # Flush previous package (if any) before starting a new one.
            if pkg_name:
                results.append((pkg_name, pkg_version, pkg_lineno))
            in_pkg = True
            pkg_name = None
            pkg_version = None
            pkg_lineno = lineno
            continue
        if stripped.startswith("[") and stripped != "[[package]]":
            # Top-level / metadata sections terminate the current package.
            if in_pkg and pkg_name:
                results.append((pkg_name, pkg_version, pkg_lineno))
            in_pkg = False
            pkg_name = None
            pkg_version = None
            continue
        if not in_pkg:
            continue
        m = re.match(r'^name\s*=\s*["\']([^"\']+)["\']', stripped)
        if m:
            pkg_name = m.group(1)
            pkg_lineno = lineno
            continue
        m = re.match(r'^version\s*=\s*["\']([^"\']+)["\']', stripped)
        if m:
            pkg_version = "==" + m.group(1)
    if in_pkg and pkg_name:
        results.append((pkg_name, pkg_version, pkg_lineno))
    return results


def _parse_uv_lock(text: str) -> list[tuple[str, str | None, int]]:
    """uv.lock uses the same `[[package]] / name = "..."` shape as poetry.lock."""
    return _parse_poetry_lock(text)


def _parse_environment_yml(text: str) -> list[tuple[str, str | None, int]]:
    """Parse a conda environment.yml `dependencies:` list.

    Recognises entries like `numpy=1.20`, `numpy==1.20`, `numpy>=1.20`, and
    nested pip blocks (`- pip:`).  Best-effort, line-based — avoids a hard
    dependency on PyYAML for this code path even though it's already a project
    dep, because environment.yml may include conda-only constructs that PyYAML
    treats as plain strings anyway.
    """
    results: list[tuple[str, str | None, int]] = []
    in_deps = False
    for lineno, raw in enumerate(text.splitlines(), start=1):
        stripped = raw.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if re.match(r"^dependencies\s*:\s*$", stripped):
            in_deps = True
            continue
        if in_deps and re.match(r"^[A-Za-z_][A-Za-z0-9_-]*\s*:\s*", stripped) and not raw.lstrip().startswith("-"):
            # New top-level key — exit dependencies block.
            in_deps = False
            continue
        if not in_deps:
            continue
        if not stripped.startswith("-"):
            continue
        item = stripped[1:].strip()
        if not item or item.endswith(":"):
            # Sub-key like `pip:` — keep walking inside it.
            continue
        # Strip surrounding quotes.
        if (item.startswith('"') and item.endswith('"')) or (
            item.startswith("'") and item.endswith("'")
        ):
            item = item[1:-1]
        m = re.match(
            r"^([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)\s*([=<>!~][^\s]*)?",
            item,
        )
        if m:
            name = m.group(1)
            spec = m.group(3) or None
            results.append((name, spec, lineno))
    return results


def _parse_setup_py(text: str) -> list[tuple[str, str | None, int]]:
    """Best-effort: walk an AST looking for `install_requires=[...]` literal lists.

    Skips dynamic constructions; never crashes on malformed input.
    """
    results: list[tuple[str, str | None, int]] = []
    try:
        tree = ast.parse(text)
    except SyntaxError:
        return results
    for node in ast.walk(tree):
        if not isinstance(node, ast.keyword):
            continue
        if node.arg not in ("install_requires", "tests_require", "extras_require"):
            continue
        value = node.value
        if isinstance(value, ast.List):
            for elt in value.elts:
                if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                    parsed = _parse_requirements(elt.value)
                    for name, spec, _ in parsed:
                        results.append((name, spec, getattr(elt, "lineno", 0)))
        elif isinstance(value, ast.Dict):
            # extras_require={"dev": ["pytest", ...]}
            for v in value.values:
                if isinstance(v, ast.List):
                    for elt in v.elts:
                        if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                            parsed = _parse_requirements(elt.value)
                            for name, spec, _ in parsed:
                                results.append((name, spec, getattr(elt, "lineno", 0)))
    return results


def _parse_setup_cfg(text: str) -> list[tuple[str, str | None, int]]:
    """Parse `[options] install_requires` block of a setup.cfg.

    Line-based — preserves line numbers and avoids configparser quirks around
    multi-line indented values.
    """
    results: list[tuple[str, str | None, int]] = []
    section: str | None = None
    in_install = False
    base_indent: int | None = None
    for lineno, raw in enumerate(text.splitlines(), start=1):
        stripped = raw.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith(";"):
            continue
        sec = re.match(r"^\[([^\]]+)\]\s*$", stripped)
        if sec:
            section = sec.group(1).strip().lower()
            in_install = False
            base_indent = None
            continue
        if section == "options" and re.match(r"^install_requires\s*=", stripped):
            in_install = True
            base_indent = None
            # Same-line value: `install_requires = pkg1; pkg2`
            after = stripped.split("=", 1)[1].strip()
            if after:
                m = re.match(
                    r"^([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)\s*([~<>=!][^\s;#]*)?",
                    after,
                )
                if m:
                    results.append((m.group(1), m.group(3) or None, lineno))
            continue
        if in_install:
            indent = len(raw) - len(raw.lstrip())
            if indent == 0:
                in_install = False
                continue
            if base_indent is None:
                base_indent = indent
            if indent < base_indent:
                in_install = False
                continue
            m = re.match(
                r"^([A-Za-z0-9]([A-Za-z0-9._-]*[A-Za-z0-9])?)\s*([~<>=!][^\s;#]*)?",
                stripped,
            )
            if m:
                results.append((m.group(1), m.group(3) or None, lineno))
    return results

# mypy error patterns indicating phantom method calls
_MYPY_ATTR_RE = re.compile(
    r'^(.+):(\d+):\s+error:\s+(?:Item\s+"[^"]+"\s+of\s+)?"([^"]+)"\s+has\s+no\s+attribute\s+"([^"]+)"'
    r'|^(.+):(\d+):\s+error:\s+Module\s+"[^"]+"\s+has\s+no\s+attribute\s+"([^"]+)"'
)


def _normalize_pkg_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


# ── I-002 pattern matching ────────────────────────────────────────────────────

# Popular packages whose canonical PyPI name is the short form (no python- prefix).
# Only include packages where the base name alone is the correct PyPI identifier
# so that legitimate python-X packages (python-dateutil, python-dotenv, etc.)
# are NOT flagged — their base names (dateutil, dotenv) are absent from this set.
_POPULAR_PACKAGES: frozenset[str] = frozenset({
    # HTTP / web clients
    "requests", "httpx", "aiohttp", "urllib3",
    # Web frameworks
    "flask", "django", "fastapi", "starlette", "tornado", "sanic",
    # ASGI / WSGI servers
    "uvicorn", "gunicorn",
    # Data science
    "numpy", "pandas", "scipy", "matplotlib", "seaborn", "plotly",
    # ML / AI — highest hallucination density
    "torch", "tensorflow", "keras", "transformers", "openai", "anthropic",
    "langchain", "cohere", "datasets",
    # Databases / ORMs
    "sqlalchemy", "sqlalchemy-utils", "alembic",
    "pymongo", "redis", "psycopg2", "asyncpg", "motor", "pymysql",
    "elasticsearch",
    # Cloud
    "boto3",
    # Task queues
    "celery", "rq",
    # Validation / config
    "pydantic", "attrs", "marshmallow",
    # CLI / UI
    "click", "typer", "rich",
    # Auth / crypto
    "cryptography", "passlib", "bcrypt", "pyjwt", "authlib",
    # Testing
    "pytest", "hypothesis", "faker", "factory-boy",
    # Tooling
    "mypy", "ruff", "black", "isort", "bandit",
    # Serialization
    "orjson", "ujson",
    # Misc popular
    "pillow", "loguru", "tenacity", "jinja2", "pyyaml", "paramiko",
})

# Suffixes that carry no semantic meaning and that AI appends to real package names.
# Kept intentionally tight: words like "login", "cors", "mock", "toolbelt" are
# used in legitimate packages (flask-login, flask-cors, pytest-mock, requests-toolbelt)
# and must NOT appear here.
_SUSPICIOUS_SUFFIXES: frozenset[str] = frozenset({
    "utils", "extras", "helpers", "enhanced", "extended",
    "new", "plus", "pro",
})


def _suspicious_variant_of(name: str) -> str | None:
    """Return the probable real base package if name matches a hallucination pattern.

    Returns None when the name appears legitimate.  Four patterns checked:
      1. python-{X}   where X is a standalone popular package
      2. {X}-python / {X}-py
      3. {X}-{meaningless_suffix}  where suffix is in _SUSPICIOUS_SUFFIXES
      4. {X}{N}  where {X}{N-1} is a known popular package (e.g. boto4 → boto3)
    """
    n = _normalize_pkg_name(name)

    # Already a known popular package — not a variant.
    if n in _POPULAR_PACKAGES:
        return None

    # Pattern 1: python-{X} where X is a standalone popular package.
    # Intentionally excludes python-dateutil / python-dotenv because 'dateutil'
    # and 'dotenv' are not in _POPULAR_PACKAGES.
    if n.startswith("python-"):
        base = n[7:]
        if base in _POPULAR_PACKAGES:
            return base

    # Pattern 2: {X}-python or {X}-py
    for trailing in ("python", "py"):
        if n.endswith(f"-{trailing}"):
            base = n[:-(len(trailing) + 1)]
            if base in _POPULAR_PACKAGES:
                return base

    # Pattern 3: {X}-{suffix} where suffix is in _SUSPICIOUS_SUFFIXES.
    # rpartition splits at the LAST hyphen, so multi-hyphen names like
    # langchain-community-extras split as ("langchain-community", "extras").
    base, sep, suffix = n.rpartition("-")
    if sep and suffix in _SUSPICIOUS_SUFFIXES and base in _POPULAR_PACKAGES:
        return base

    # Pattern 4: digit-incremented variant.
    # Only flag when the predecessor name is explicitly in _POPULAR_PACKAGES
    # (prevents false positives from arbitrary numeric suffixes).
    m = re.match(r"^([a-z][a-z0-9-]*)(\d+)$", n)
    if m:
        base_name, digit = m.group(1), int(m.group(2))
        prev = f"{base_name}{digit - 1}"
        if prev in _POPULAR_PACKAGES:
            return prev

    return None


# Static fallback list: packages that don't fit the structural patterns above
# but are confirmed hallucination targets (keeps pattern rules tight).
_HIGH_RISK_DEPS: frozenset[str] = frozenset(
    _normalize_pkg_name(n) for n in _HIGH_RISK_NAMES
)


def _pypi_exists(name: str) -> bool | None:
    """Returns True if the package exists on PyPI, False if not, None on network error."""
    normalized = _normalize_pkg_name(name)
    cache_file = _CACHE_DIR / f"{normalized}.json"

    if cache_file.exists():
        try:
            data = json.loads(cache_file.read_text())
            if time.time() - data["ts"] < _CACHE_TTL:
                return data["exists"]
        except (json.JSONDecodeError, KeyError):
            pass

    try:
        from .. import __version__
        req = urllib.request.Request(
            f"https://pypi.org/simple/{normalized}/",
            headers={"User-Agent": f"proofctl/{__version__} (AI slop linter; security research)"},
        )
        urllib.request.urlopen(req, timeout=_PYPI_TIMEOUT)
        exists = True
    except urllib.error.HTTPError as e:
        exists = e.code != 404
    except Exception:
        return None  # network unavailable — skip, don't false-positive

    _CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file.write_text(json.dumps({"exists": exists, "ts": time.time()}))
    return exists


def _stdlib_names() -> frozenset[str]:
    if hasattr(sys, "stdlib_module_names"):
        return frozenset(sys.stdlib_module_names)
    # Fallback for Python < 3.10: common stdlib modules
    return frozenset({
        "abc", "ast", "asyncio", "builtins", "collections", "contextlib",
        "copy", "dataclasses", "datetime", "enum", "fnmatch", "functools",
        "hashlib", "http", "importlib", "inspect", "io", "itertools", "json",
        "logging", "math", "operator", "os", "pathlib", "pickle", "platform",
        "queue", "random", "re", "shutil", "signal", "socket", "sqlite3",
        "string", "struct", "subprocess", "sys", "tempfile", "textwrap",
        "threading", "time", "traceback", "types", "typing", "unittest",
        "urllib", "uuid", "warnings", "weakref", "xml", "zipfile",
        "_thread", "__future__",
    })


# Directories never worth descending into when looking for local packages.
# These are scanner / vendor / virtualenv folders, not first-party code.
_PKG_SCAN_SKIP_DIRS: frozenset[str] = frozenset({
    ".venv", "venv", ".env",
    "node_modules",
    ".git", ".hg", ".svn",
    "__pycache__",
    "dist", "build",
    ".terraform", ".terragrunt-cache",
    ".tox", ".nox",
    ".pytest_cache", ".mypy_cache", ".ruff_cache",
    "site-packages",
})

# Cap the recursion depth so a runaway symlink or pathological repo can't lock
# the scanner. 8 is enough for monorepos (e.g. orchestration/dags/<pkg>/__init__.py
# is depth 3).
_PKG_SCAN_MAX_DEPTH = 8

# Files / directories that mark a project root for `_i001` local-package
# discovery. Kept broad on purpose: a monorepo with Airflow DAGs frequently has
# none of pyproject.toml / setup.py at the repo root, but always has `.git/`.
_PROJECT_ROOT_MARKERS: tuple[str, ...] = (
    "pyproject.toml", "setup.py", "setup.cfg",
    ".git",
    "Pipfile", "Pipfile.lock",
    "poetry.lock", "uv.lock",
    "requirements.txt", "requirements-dev.txt",
    "tox.ini",
    "environment.yml",
    ".proofctl.yaml",   # the user's own marker
)


@functools.lru_cache(maxsize=32)
def _local_packages(root: Path) -> frozenset[str]:
    """Importable Python package/module names anywhere in the project.

    A directory under `root` is treated as a local package when **all** of:
      - its name is a valid Python identifier (filters out `schema-migrations`
        and similar that can never appear as an import),
      - it is not in the vendor / cache / virtualenv skip set,
      - it either contains an `__init__.py` (regular package) **or** at least
        one direct `.py` file (PEP 420 namespace package — common in Airflow
        projects where `dags_folder` is on `sys.path` and DAG sub-directories
        are imported without `__init__.py`).

    Bare top-level `.py` files at the project root are also recorded as
    importable modules.

    The walk skips common vendor / cache / virtualenv directories, never
    follows symlinks, and caps recursion at `_PKG_SCAN_MAX_DEPTH`.
    Results are cached per-root so a 500-file scan walks the tree once.

    Why we add namespace packages even without an `__init__.py`:
    Airflow's standard layout has `<dags_folder>/<pkg>/<module>.py` with
    `<dags_folder>` on `sys.path`; `from <pkg> import …` resolves at runtime
    even though `<pkg>` is just a plain directory. Without this branch every
    such directory triggered a false PROOFCTL-I-001.

    Trade-off: a directory whose name matches a real PyPI package will now
    shadow that package in the hallucination check (false-negative rather
    than false-positive). We accept that — the previous noise made the rule
    unusable on namespace-package layouts, and the identifier + py-file
    filters keep the false-negative surface narrow.
    """
    names: set[str] = set()
    visited: set[Path] = set()

    def _has_direct_py_file(p: Path) -> bool:
        try:
            for c in p.iterdir():
                if c.is_file() and not c.is_symlink() and c.suffix == ".py":
                    return True
        except (OSError, PermissionError):
            return False
        return False

    def _walk(path: Path, depth: int) -> None:
        if depth > _PKG_SCAN_MAX_DEPTH:
            return
        try:
            real = path.resolve()
        except OSError:
            return
        if real in visited:
            return  # symlink loop guard
        visited.add(real)
        try:
            children = list(path.iterdir())
        except (OSError, PermissionError):
            return
        for child in children:
            if child.is_symlink():
                continue
            if child.is_dir():
                if child.name in _PKG_SCAN_SKIP_DIRS:
                    continue
                if child.name.endswith(".egg-info"):
                    continue
                if child.name.startswith(".") and child.name not in {".github"}:
                    # Skip hidden directories — they're caches, IDE state, etc.
                    continue
                if child.name.isidentifier():
                    if (child / "__init__.py").exists() or _has_direct_py_file(child):
                        names.add(child.name)
                _walk(child, depth + 1)
            elif depth == 0 and child.suffix == ".py" and child.name != "__init__.py":
                # Bare top-level modules (e.g. `setup.py`-adjacent scripts).
                names.add(child.stem)

    _walk(root, 0)
    return frozenset(names)


def _extract_imports(tree: ast.Module) -> list[tuple[str, int, int]]:
    """Returns (top-level package name, lineno, col_offset) for every import."""
    imports = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                pkg = alias.name.split(".")[0]
                imports.append((pkg, node.lineno, node.col_offset))
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.level == 0:  # skip relative imports
                pkg = node.module.split(".")[0]
                imports.append((pkg, node.lineno, node.col_offset))
    return imports


class ImportChecker(FileChecker):
    def __init__(
        self,
        local_namespaces: list[str] | None = None,
        extra_indexes: list[str] | None = None,
        check_pypi: bool = True,
        scan_root: Path | None = None,
    ) -> None:
        self._local_namespaces = tuple(local_namespaces or [])
        self._check_pypi = check_pypi
        self._stdlib = _stdlib_names()
        # Engine plumbs its own scan root in; falls back to walking-up
        # heuristic when used standalone (e.g. unit tests).
        self._scan_root = scan_root

    def check(self, path: Path, source: str, tree: ast.Module | None) -> list[Finding]:
        findings: list[Finding] = []
        if tree is not None:
            findings.extend(self._i001(path, tree))
        return findings

    def _i001(self, path: Path, tree: ast.Module) -> list[Finding]:
        # Determine the project root for local-package discovery. Priority order:
        #   1. The engine's scan root, if plumbed in (`self._scan_root`).
        #   2. Walk up looking for any standard project marker. We accept a wide
        #      set so monorepos without pyproject.toml (e.g. Airflow data
        #      pipelines, data-team monorepos) still resolve correctly.
        #   3. Fall back to the file's parent directory.
        if self._scan_root is not None:
            root = self._scan_root
        else:
            root = path.parent
            candidate = root
            for _ in range(8):  # max 8 levels up
                if any(
                    (candidate / marker).exists()
                    for marker in _PROJECT_ROOT_MARKERS
                ):
                    root = candidate
                    break
                if candidate.parent == candidate:
                    break
                candidate = candidate.parent
        local = _local_packages(root)

        findings = []
        seen: set[str] = set()

        for pkg, lineno, col in _extract_imports(tree):
            if pkg in seen:
                continue
            seen.add(pkg)

            if pkg in self._stdlib:
                continue
            if pkg in local:
                continue
            if self._local_namespaces and pkg.startswith(self._local_namespaces):
                continue

            if not self._check_pypi:
                continue

            exists = _pypi_exists(pkg)
            if exists is False:
                findings.append(Finding(
                    file=str(path),
                    line=lineno,
                    col=col,
                    rule_id="PROOFCTL-I-001",
                    rule_name="Hallucinated import",
                    severity=Severity.ERROR,
                    message=f"Package '{pkg}' not found on PyPI — possible AI hallucination",
                    hint=(
                        f"Verify '{pkg}' exists and is spelled correctly. "
                        "If it's a private package, add it to local_namespaces in .proofctl.yaml."
                    ),
                    authority="Slopsquatting research — AI-hallucinated package names",
                ))

        return findings


class DependencyChecker(DirectoryChecker):
    """PROOFCTL-I-002: Hallucination-prone package name in project dependency files."""

    def __init__(self, extra_high_risk: list[str] | None = None) -> None:
        extra = frozenset(_normalize_pkg_name(p) for p in (extra_high_risk or []))
        self._high_risk = _HIGH_RISK_DEPS | extra

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        findings = []
        for dep_file in self._find_dep_files(root):
            findings.extend(self._check_dep_file(dep_file))
        return findings

    def _find_dep_files(self, root: Path) -> list[Path]:
        files: list[Path] = []
        # Top-level (cheap, always included).
        files.extend(root.glob("requirements*.txt"))
        files.extend(root.glob("requirements/*.txt"))

        # Walk the subtree for every supported manifest type. Reuses the same
        # skip-set as the local-package walker so we don't descend into venvs,
        # caches, or vendored deps. Cap at the same depth.
        manifest_names: frozenset[str] = frozenset({
            "pyproject.toml", "Pipfile", "poetry.lock", "uv.lock",
            "environment.yml", "environment.yaml",
            "setup.py", "setup.cfg",
        })
        # Names matched as glob patterns within each visited directory.
        manifest_globs: tuple[str, ...] = ("requirements*.txt",)

        seen: set[Path] = set()

        def _add(p: Path) -> None:
            try:
                key = p.resolve()
            except OSError:
                return
            if key in seen:
                return
            seen.add(key)
            files.append(p)

        for f in list(files):
            _add(f)

        def _walk(path: Path, depth: int) -> None:
            if depth > _PKG_SCAN_MAX_DEPTH:
                return
            try:
                children = list(path.iterdir())
            except (OSError, PermissionError):
                return
            for child in children:
                if child.is_symlink():
                    continue
                if child.is_dir():
                    if child.name in _PKG_SCAN_SKIP_DIRS:
                        continue
                    if child.name.endswith(".egg-info"):
                        continue
                    if child.name.startswith(".") and child.name not in {".github"}:
                        continue
                    _walk(child, depth + 1)
                else:
                    if child.name in manifest_names:
                        _add(child)
                    else:
                        for pat in manifest_globs:
                            if child.match(pat):
                                _add(child)
                                break

        _walk(root, 0)
        return files

    def _check_dep_file(self, path: Path) -> list[Finding]:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []

        name = path.name
        try:
            if name == "pyproject.toml":
                deps = _parse_pyproject_deps(text)
            elif name == "Pipfile":
                deps = _parse_pipfile(text)
            elif name == "poetry.lock":
                deps = _parse_poetry_lock(text)
            elif name == "uv.lock":
                deps = _parse_uv_lock(text)
            elif name in ("environment.yml", "environment.yaml"):
                deps = _parse_environment_yml(text)
            elif name == "setup.py":
                deps = _parse_setup_py(text)
            elif name == "setup.cfg":
                deps = _parse_setup_cfg(text)
            elif path.suffix == ".toml":
                # Other TOML manifests at non-standard names — try project deps.
                deps = _parse_pyproject_deps(text)
            else:
                deps = _parse_requirements(text)
        except Exception:
            # Best-effort: never crash on a malformed manifest.
            return []

        findings = []
        for name, spec, lineno in deps:
            normalized = _normalize_pkg_name(name)

            # Static list: confirmed hallucination targets that don't fit patterns.
            if normalized in self._high_risk:
                reason = "matches known AI-hallucination-prone package list"
            else:
                # Structural pattern matching: broader coverage, no network needed.
                base_pkg = _suspicious_variant_of(name)
                if base_pkg is None:
                    continue
                reason = f"looks like a hallucinated variant of '{base_pkg}'"

            is_pinned = spec is not None and "==" in spec
            sev = Severity.WARNING if is_pinned else Severity.ERROR
            findings.append(Finding(
                file=str(path),
                line=lineno,
                col=0,
                rule_id="PROOFCTL-I-002",
                rule_name="High-risk dependency name",
                severity=sev,
                message=(
                    f"'{name}' {reason}"
                    + (" (pinned)" if is_pinned else " — unpinned, squatting risk")
                ),
                hint=(
                    f"Verify '{name}' is the intended package. "
                    "AI models commonly hallucinate plausible-sounding package names."
                ),
                authority="Slopsquatting research — AI-hallucinated package names",
            ))
        return findings


class MethodChecker(DirectoryChecker):
    """PROOFCTL-M-001: Phantom method calls detected by a single mypy invocation.

    Running mypy once on all files is orders of magnitude faster than once per
    file: mypy's startup and import-resolution cost is paid once, not N times.
    """

    def check(self, root: Path, py_files: list[Path]) -> list[Finding]:
        if not py_files:
            return []
        if not shutil.which("mypy"):
            # Surface the disabled state as a single INFO finding so CI users
            # don't silently lose phantom-method coverage.
            return [self._mypy_missing_finding(root)]
        try:
            return self._run_mypy(py_files)
        except FileNotFoundError:
            return [self._mypy_missing_finding(root)]

    def _mypy_missing_finding(self, root: Path) -> Finding:
        return Finding(
            file=str(root),
            line=None,
            col=None,
            rule_id="PROOFCTL-M-001",
            rule_name="Phantom method check disabled",
            severity=Severity.INFO,
            message=(
                "M-001 disabled — mypy not installed; install proofctl[dev] or "
                "pip install mypy to enable phantom-method detection"
            ),
            hint="pip install mypy   # or: pip install proofctl[dev]",
            authority="mypy attr-defined — AI calls methods that don't exist",
            docs_url="https://mypy.readthedocs.io/en/stable/error_codes.html",
        )

    def _run_mypy(self, py_files: list[Path]) -> list[Finding]:
        try:
            result = subprocess.run(
                [
                    "mypy",
                    "--ignore-missing-imports",
                    "--no-error-summary",
                    "--no-pretty",
                    *[str(p) for p in py_files],
                ],
                capture_output=True,
                text=True,
                timeout=300,
            )
        except subprocess.TimeoutExpired:
            return []
        except FileNotFoundError:
            raise
        except OSError:
            return []

        # Index scoped files for quick membership check after path normalisation.
        scoped = {str(p.resolve()) for p in py_files}

        findings = []
        for line in result.stdout.splitlines():
            m = _MYPY_ATTR_RE.match(line)
            if not m:
                continue

            if m.group(1):
                file_path, lineno_str = m.group(1), m.group(2)
                obj_type, attr = m.group(3), m.group(4)
                msg = f"'{obj_type}' has no attribute '{attr}'"
            else:
                file_path, lineno_str = m.group(5), m.group(6)
                attr = m.group(7)
                msg = f"Module has no attribute '{attr}'"

            # Skip findings for files outside the scan scope (e.g. installed libs).
            try:
                if str(Path(file_path).resolve()) not in scoped:
                    continue
            except OSError:
                continue

            try:
                lineno = int(lineno_str)
            except ValueError:
                lineno = None

            findings.append(Finding(
                file=file_path,
                line=lineno,
                col=None,
                rule_id="PROOFCTL-M-001",
                rule_name="Phantom method call",
                severity=Severity.ERROR,
                message=msg,
                hint="Check the library's documentation for the correct method name.",
                authority="mypy attr-defined — AI calls methods that don't exist",
                docs_url="https://mypy.readthedocs.io/en/stable/error_codes.html",
            ))

        return findings
