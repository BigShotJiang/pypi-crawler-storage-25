"""Secret detection — PROOFCTL-SECRET-* rules. Scans any text file."""
from __future__ import annotations

import math
import re
from pathlib import Path

from ..models import Finding, Severity
from .base import FileChecker

# ── allowlists ────────────────────────────────────────────────────────────────

_SKIP_SUFFIXES = (
    ".lock", ".min.js", ".bundle.js", ".map",
)
_SKIP_NAMES = frozenset({
    "package-lock.json", "yarn.lock", "Cargo.lock", "go.sum", "pnpm-lock.yaml",
    "composer.lock", "Pipfile.lock", "poetry.lock",
})

_PLACEHOLDER_VALUES = frozenset({
    "changeme", "change-me", "change_me", "your-password-here",
    "your_password_here", "yourpassword", "password", "passw0rd",
    "xxx", "xxxx", "xxxxx", "xxxxxx", "placeholder", "todo", "tbd",
    "example", "sample", "secret", "your-secret-here", "redacted",
    "default", "test", "testing", "dummy", "fake", "none", "null",
    "<password>", "<secret>", "<value>", "n/a", "na",
})

# ── patterns ──────────────────────────────────────────────────────────────────

_PAT_AWS_KEY = re.compile(r"AKIA[A-Z0-9]{16}")
_PAT_AWS_SECRET = re.compile(
    r"""aws_secret(_access)?_key\s*=\s*["']([A-Za-z0-9/+=]{40})["']""",
    re.IGNORECASE,
)
_PAT_GITHUB = re.compile(r"gh[pousr]_[A-Za-z0-9]{36,}")
_PAT_SLACK = re.compile(r"xox[bpoars]-[A-Za-z0-9-]+")
_PAT_PRIVKEY = re.compile(r"-----BEGIN [A-Z ]*PRIVATE KEY-----")
_PAT_JWT = re.compile(r"eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{20,}")
_PAT_GENERIC = re.compile(
    r"""(?P<key>password|passwd|pwd|secret|api[_-]?key|access[_-]?token|auth[_-]?token)"""
    r"""\s*[:=]\s*["'](?P<val>[^"'$\{]{8,})["']""",
    re.IGNORECASE,
)
_PAT_GOOGLE = re.compile(r"AIza[0-9A-Za-z_-]{35}")
_PAT_STRIPE = re.compile(r"(?:sk|pk)_(?:test|live)_[0-9a-zA-Z]{24,}")
_PAT_TF_ADMIN = re.compile(
    r"""(?P<key>administrator_login_password|admin_password|root_password)"""
    r"""\s*=\s*"(?P<val>[^"$\{][^"]{4,})\"""",
)

_ENV_REF_RE = re.compile(r"^\s*[\$\{][^\s]+[\}]?\s*$|^\$[A-Z_][A-Z0-9_]*$|^\$\{[^}]+\}$")

# SECRET-011: kind: Secret YAML detection
_PAT_K8S_KIND_SECRET = re.compile(r'^\s*kind\s*:\s*["\']?Secret["\']?\s*(#.*)?$')
_PAT_YAML_DOC_SEP = re.compile(r'^---\s*(#.*)?$')
_PAT_K8S_NAME = re.compile(r'^\s{2,}name\s*:\s*["\']?([A-Za-z0-9._-]+)["\']?\s*(#.*)?$')
_PAT_K8S_DATA_KEY = re.compile(r'^(\s*)(data|stringData)\s*:\s*(#.*)?$')
# Match indented "key: value" lines under data:/stringData:
_PAT_K8S_DATA_ENTRY = re.compile(
    r'^(\s+)([A-Za-z0-9._-]+)\s*:\s*(.*?)\s*(?:#.*)?$'
)
_K8S_SKIP_PATH_TOKENS = ("/tests/", "/fixtures/", "/testdata/")

# SECRET-012: heredoc tracking + secret-shaped env assignment inside heredoc
_PAT_HEREDOC_OPEN = re.compile(r'<<[-~]?(\w+)\s*$')
_PAT_HEREDOC_SECRET = re.compile(
    r'(?:export\s+)?([A-Z][A-Z0-9_]*(?:_KEY|_TOKEN|_SECRET|_PASSWORD|_PASSWD))'
    r'\s*=\s*([^\s"\']+|"[^"]+"|\'[^\']+\')'
)


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq: dict[str, int] = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in freq.values())


def _is_placeholder(val: str) -> bool:
    low = val.lower().strip()
    if low in _PLACEHOLDER_VALUES:
        return True
    # Entirely lowercase + dashes/underscores looks like placeholder text
    if re.fullmatch(r"[a-z][a-z0-9_\-]*", val) and any(
        tok in low for tok in ("change", "your", "placeholder", "example", "sample")
    ):
        return True
    return False


def _is_env_ref(val: str) -> bool:
    return bool(_ENV_REF_RE.match(val)) or "${" in val or val.startswith("$(")


def _is_binary(data: bytes) -> bool:
    if not data:
        return False
    if b"\x00" in data:
        return True
    text_chars = bytes(range(32, 127)) + b"\n\r\t\f\b"
    nonprint = sum(1 for b in data if b not in text_chars)
    return (nonprint / len(data)) > 0.30


def _should_skip(path: Path) -> bool:
    name = path.name
    if name in _SKIP_NAMES:
        return True
    for suf in _SKIP_SUFFIXES:
        if name.endswith(suf):
            return True
    # *.lock.json
    if name.endswith(".lock.json"):
        return True
    return False


# ── rule fns ──────────────────────────────────────────────────────────────────

def _mk(path: Path, line: int, rid: str, name: str, sev: Severity, msg: str) -> Finding:
    return Finding(
        file=str(path),
        line=line,
        col=0,
        rule_id=rid,
        rule_name=name,
        severity=sev,
        message=msg,
        hint="Move secret to env var, secret manager, or runtime injection. Never commit credentials.",
        authority="OWASP ASVS V2 / CWE-798 – Use of Hard-coded Credentials",
        docs_url="https://cwe.mitre.org/data/definitions/798.html",
    )


def _scan_line(path: Path, lineno: int, line: str) -> list[Finding]:
    out: list[Finding] = []
    # Track (rule_priority, secret_value) so most-specific rule wins per value.
    # Keyed by value text → (priority, Finding)
    by_value: dict[str, tuple[int, Finding]] = {}

    def _claim(value: str, priority: int, finding: Finding) -> None:
        existing = by_value.get(value)
        if existing is None or priority < existing[0]:
            by_value[value] = (priority, finding)

    # SECRET-001: AWS access key
    for m in _PAT_AWS_KEY.finditer(line):
        v = m.group(0)
        _claim(v, 1, _mk(path, lineno, "PROOFCTL-SECRET-001",
                         "AWS access key ID", Severity.ERROR,
                         f"Hardcoded AWS access key ID detected ({v[:8]}…)"))

    # SECRET-002: AWS secret key
    for m in _PAT_AWS_SECRET.finditer(line):
        v = m.group(2)
        _claim(v, 2, _mk(path, lineno, "PROOFCTL-SECRET-002",
                         "AWS secret access key", Severity.ERROR,
                         "Hardcoded AWS secret access key detected"))

    # SECRET-003: GitHub token
    for m in _PAT_GITHUB.finditer(line):
        v = m.group(0)
        _claim(v, 3, _mk(path, lineno, "PROOFCTL-SECRET-003",
                         "GitHub token", Severity.ERROR,
                         f"Hardcoded GitHub token detected ({v[:7]}…)"))

    # SECRET-004: Slack token
    for m in _PAT_SLACK.finditer(line):
        v = m.group(0)
        _claim(v, 4, _mk(path, lineno, "PROOFCTL-SECRET-004",
                         "Slack token", Severity.ERROR,
                         f"Hardcoded Slack token detected ({v[:6]}…)"))

    # SECRET-005: Private key marker
    for m in _PAT_PRIVKEY.finditer(line):
        v = m.group(0)
        _claim(v, 5, _mk(path, lineno, "PROOFCTL-SECRET-005",
                         "Private key", Severity.ERROR,
                         "Private key block detected"))

    # SECRET-006: JWT (warning — often in tests/docs)
    for m in _PAT_JWT.finditer(line):
        v = m.group(0)
        _claim(v, 6, _mk(path, lineno, "PROOFCTL-SECRET-006",
                         "JWT token", Severity.WARNING,
                         f"JWT token detected ({v[:12]}…) — confirm not a real credential"))

    # SECRET-008: Google API key
    for m in _PAT_GOOGLE.finditer(line):
        v = m.group(0)
        _claim(v, 8, _mk(path, lineno, "PROOFCTL-SECRET-008",
                         "Google API key", Severity.ERROR,
                         f"Hardcoded Google API key detected ({v[:8]}…)"))

    # SECRET-009: Stripe key
    for m in _PAT_STRIPE.finditer(line):
        v = m.group(0)
        _claim(v, 9, _mk(path, lineno, "PROOFCTL-SECRET-009",
                         "Stripe API key", Severity.ERROR,
                         f"Hardcoded Stripe key detected ({v[:8]}…)"))

    # SECRET-010: Terraform/HCL admin password
    for m in _PAT_TF_ADMIN.finditer(line):
        v = m.group("val")
        if _is_env_ref(v) or _is_placeholder(v):
            continue
        _claim(v, 10, _mk(path, lineno, "PROOFCTL-SECRET-010",
                          "Hardcoded admin password", Severity.ERROR,
                          f"Hardcoded admin password in '{m.group('key')}' assignment"))

    # SECRET-007: Generic high-entropy assignment (lowest priority — fires last)
    for m in _PAT_GENERIC.finditer(line):
        v = m.group("val")
        if _is_env_ref(v) or _is_placeholder(v):
            continue
        if v.islower() and len(v) <= 16 and re.fullmatch(r"[a-z0-9_\-]+", v):
            # Looks like a slug/placeholder — skip
            continue
        if _shannon_entropy(v) < 3.5:
            continue
        _claim(v, 7, _mk(path, lineno, "PROOFCTL-SECRET-007",
                         "Hardcoded credential assignment", Severity.ERROR,
                         f"Likely hardcoded {m.group('key')} assignment"))

    out.extend(f for _, f in by_value.values())
    return out


# ── SECRET-011: kind: Secret YAML ─────────────────────────────────────────────

def _scan_k8s_secrets(path: Path, source: str) -> list[Finding]:
    """Scan YAML for `kind: Secret` documents with plaintext data:/stringData:.

    Fires once per Secret document on the line of `kind: Secret`.
    Also fires on multi-doc YAML (--- separators) per document.
    """
    name_str = str(path).replace("\\", "/").lower()
    if any(tok in name_str for tok in _K8S_SKIP_PATH_TOKENS):
        return []
    # Restrict to plausible YAML files (cheap guard — main.yaml, *.yml, *.yaml).
    if not (path.name.endswith(".yaml") or path.name.endswith(".yml")):
        return []

    lines = source.splitlines()
    out: list[Finding] = []

    # Collect document slices (line ranges) using --- separators.
    doc_starts: list[int] = [0]
    for idx, line in enumerate(lines):
        if idx > 0 and _PAT_YAML_DOC_SEP.match(line):
            doc_starts.append(idx + 1)
    doc_starts.append(len(lines))

    for di in range(len(doc_starts) - 1):
        start, end = doc_starts[di], doc_starts[di + 1]
        kind_line = -1
        secret_name = "<unnamed>"
        # Find kind: Secret in this doc
        for i in range(start, end):
            if _PAT_K8S_KIND_SECRET.match(lines[i]):
                kind_line = i
                break
        if kind_line < 0:
            continue

        # Find metadata.name (best-effort; first 'name:' under metadata or any 'name:' line).
        for i in range(start, end):
            mn = _PAT_K8S_NAME.match(lines[i])
            if mn:
                secret_name = mn.group(1)
                break

        # Walk for data:/stringData: blocks and check for any non-empty entries.
        i = start
        leaked = False
        while i < end:
            line = lines[i]
            mkey = _PAT_K8S_DATA_KEY.match(line)
            if not mkey:
                i += 1
                continue
            base_indent = len(mkey.group(1))
            j = i + 1
            while j < end:
                child = lines[j]
                if not child.strip() or child.lstrip().startswith("#"):
                    j += 1
                    continue
                child_indent = len(child) - len(child.lstrip())
                if child_indent <= base_indent:
                    break
                me = _PAT_K8S_DATA_ENTRY.match(child)
                if me:
                    val = me.group(3).strip()
                    # Strip simple quoting
                    if (val.startswith('"') and val.endswith('"')) or (
                        val.startswith("'") and val.endswith("'")
                    ):
                        val = val[1:-1]
                    # Skip empty / null / valueFrom-style references / pipe-block markers
                    if not val or val in ("''", '""', "null", "~"):
                        j += 1
                        continue
                    if val in ("|", ">", "|-", ">-", "|+", ">+"):
                        # Block scalar follows — treat as a real value if any next
                        # non-empty indented line exists.
                        k = j + 1
                        has_content = False
                        while k < end:
                            nxt = lines[k]
                            if not nxt.strip():
                                k += 1
                                continue
                            nxt_indent = len(nxt) - len(nxt.lstrip())
                            if nxt_indent <= child_indent:
                                break
                            has_content = True
                            break
                        if has_content:
                            leaked = True
                            break
                        j += 1
                        continue
                    if val.startswith("valueFrom") or val.startswith("&") or val.startswith("*"):
                        j += 1
                        continue
                    # Otherwise: a real plaintext value (b64 or stringData).
                    leaked = True
                    break
                j += 1
            if leaked:
                break
            i = j

        if leaked:
            out.append(Finding(
                file=str(path),
                line=kind_line + 1,
                col=0,
                rule_id="PROOFCTL-SECRET-011",
                rule_name="Plaintext credentials in Kubernetes Secret manifest",
                severity=Severity.ERROR,
                message=(
                    f"Kubernetes Secret '{secret_name}' has plaintext credentials "
                    "in data:/stringData:"
                ),
                hint=(
                    "Use external secret store: ExternalSecrets, Sealed Secrets, "
                    "or valueFrom.secretKeyRef from a properly-managed Secret "
                    "outside the manifest."
                ),
                authority="OWASP ASVS V2 / CWE-798 – Use of Hard-coded Credentials",
                docs_url="https://cwe.mitre.org/data/definitions/798.html",
            ))
    return out


# ── SECRET-012: secret-shaped env assignment inside heredoc ───────────────────

def _scan_heredoc_secrets(
    path: Path, source: str, already_fired_lines: set[int]
) -> list[Finding]:
    """Detect FOO_KEY/_TOKEN/_SECRET/_PASSWORD=value inside <<EOF heredocs."""
    out: list[Finding] = []
    heredoc_end: str | None = None
    for i, line in enumerate(source.splitlines(), start=1):
        if heredoc_end is None:
            hm = _PAT_HEREDOC_OPEN.search(line)
            if hm:
                heredoc_end = hm.group(1)
            continue
        # Inside heredoc
        stripped = line.strip()
        if stripped == heredoc_end or stripped.rstrip("-~") == heredoc_end:
            heredoc_end = None
            continue
        if i in already_fired_lines:
            continue
        m = _PAT_HEREDOC_SECRET.search(line)
        if not m:
            continue
        key = m.group(1)
        val = m.group(2)
        if (val.startswith('"') and val.endswith('"')) or (
            val.startswith("'") and val.endswith("'")
        ):
            val = val[1:-1]
        if len(val) < 8:
            continue
        if _is_env_ref(val) or val.startswith("$"):
            continue
        if _is_placeholder(val):
            continue
        out.append(Finding(
            file=str(path),
            line=i,
            col=0,
            rule_id="PROOFCTL-SECRET-012",
            rule_name="Secret in heredoc body",
            severity=Severity.ERROR,
            message=f"Hardcoded secret-shaped assignment '{key}=...' inside heredoc",
            hint=(
                "Heredocs (e.g. user_data) are committed to state and version "
                "control. Inject via EC2 Instance Metadata, SSM Parameter Store, "
                "Secrets Manager, or a templated runtime variable."
            ),
            authority="OWASP ASVS V2 / CWE-798 – Use of Hard-coded Credentials",
            docs_url="https://cwe.mitre.org/data/definitions/798.html",
        ))
    return out


# ── main checker ──────────────────────────────────────────────────────────────

class SecretChecker(FileChecker):
    """Scans any text file for hardcoded secrets."""

    extensions: tuple[str, ...] = ()

    def check(self, path: Path, source: str, tree=None) -> list[Finding]:  # type: ignore[override]
        if _should_skip(path):
            return []
        # Binary sniff using the source's first 1024 chars encoded back.
        head_bytes = source[:1024].encode("utf-8", errors="replace")
        if _is_binary(head_bytes):
            return []

        findings: list[Finding] = []
        for i, line in enumerate(source.splitlines(), start=1):
            if not line:
                continue
            findings.extend(_scan_line(path, i, line))

        # SECRET-011: K8s Secret YAML
        findings.extend(_scan_k8s_secrets(path, source))

        # SECRET-012: heredoc secrets (skip lines where SECRET-001..010 already fired)
        already = {f.line for f in findings if f.rule_id != "PROOFCTL-SECRET-011"}
        findings.extend(_scan_heredoc_secrets(path, source, already))

        return findings
