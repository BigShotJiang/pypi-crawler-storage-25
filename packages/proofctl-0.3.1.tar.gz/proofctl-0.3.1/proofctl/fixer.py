from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import Finding

from .checkers.quality import _is_mutable_default


@dataclass
class FixResult:
    """Outcome of an auto-fix run.

    `succeeded` is the count of mutable defaults the fixer rewrote and guarded.
    `skipped` is the count of mutable defaults the fixer recognised but could
    not safely rewrite (currently: multi-line literal defaults).  Surfacing
    skipped fixes prevents the original H-7 bug — a count of "fixed" that
    silently included defaults the fixer left untouched, with sentinel guards
    inserted that referenced the still-mutable original signature.
    """
    succeeded: int = 0
    skipped: int = 0
    skipped_details: list[tuple[str, int, str]] = None  # (file, line, arg_name)

    def __post_init__(self) -> None:
        if self.skipped_details is None:
            self.skipped_details = []

    @property
    def total(self) -> int:
        return self.succeeded + self.skipped


def apply_fixes(findings: list[Finding], root: Path) -> int:
    """Backwards-compatible wrapper. Returns the *succeeded* count only.

    Callers who want the full breakdown (succeeded vs skipped) should call
    `apply_fixes_detailed` instead.
    """
    return apply_fixes_detailed(findings, root).succeeded


def apply_fixes_detailed(findings: list[Finding], root: Path) -> FixResult:
    """Apply auto-fixes for fixable findings in-place; return a FixResult."""
    fixable = [f for f in findings if f.fixable and f.rule_id == "PROOFCTL-Q-001"]
    result = FixResult()
    if not fixable:
        return result

    by_file: dict[str, list[Finding]] = {}
    for f in fixable:
        by_file.setdefault(f.file, []).append(f)

    for rel_path in by_file:
        abs_path = (root / rel_path) if not Path(rel_path).is_absolute() else Path(rel_path)
        try:
            source = abs_path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(abs_path))
        except (OSError, SyntaxError):
            continue

        new_source, file_result = _fix_mutable_defaults(source, tree, rel_path)
        if new_source != source:
            abs_path.write_text(new_source, encoding="utf-8")
        result.succeeded += file_result.succeeded
        result.skipped += file_result.skipped
        result.skipped_details.extend(file_result.skipped_details)

    return result


# ── internal helpers ──────────────────────────────────────────────────────────

def _is_docstring(stmt: ast.stmt) -> bool:
    return (
        isinstance(stmt, ast.Expr)
        and isinstance(stmt.value, ast.Constant)
        and isinstance(stmt.value.value, str)
    )


def _fix_mutable_defaults(source: str, tree: ast.Module, file_label: str = "<source>") -> tuple[str, FixResult]:
    """Rewrite source so every mutable default becomes None + a sentinel guard.

    Returns the (possibly-modified) source plus a FixResult describing how
    many defaults were rewritten vs skipped. Multi-line literal defaults are
    skipped because rewriting them safely requires preserving the surrounding
    expression structure — and the sentinel guard would reference invalid
    source if the rewrite failed silently (the original H-7 bug).

    Processing order guarantees correctness:
    - We collect all orig_src values from the *original* source string before
      modifying anything (ast.get_source_segment always reads original source).
    - Within each file we work bottom-up by function start line so any line
      insertions for lower functions don't shift the positions of higher ones.
    - Within each function we replace defaults right-to-left so earlier
      replacements don't shift later column offsets on the same line.
    """
    result = FixResult()
    lines = source.splitlines(keepends=True)

    # Collect (func_node, [(arg_name, default_node, orig_src), ...])
    func_fixes: list[tuple[ast.FunctionDef | ast.AsyncFunctionDef, list]] = []

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        fixes_for_func: list[tuple[str, ast.expr, str]] = []
        args = node.args

        # Positional defaults align to the LAST N positional args
        offset = len(args.args) - len(args.defaults)
        for i, default in enumerate(args.defaults):
            if _is_mutable_default(default):
                arg_name = args.args[offset + i].arg
                orig_src = ast.get_source_segment(source, default)
                if orig_src:
                    fixes_for_func.append((arg_name, default, orig_src))

        # Keyword-only defaults
        for arg, default in zip(args.kwonlyargs, args.kw_defaults):
            if default is not None and _is_mutable_default(default):
                orig_src = ast.get_source_segment(source, default)
                if orig_src:
                    fixes_for_func.append((arg.arg, default, orig_src))

        if fixes_for_func:
            func_fixes.append((node, fixes_for_func))

    if not func_fixes:
        return source, result

    # Bottom-up by function start line
    func_fixes.sort(key=lambda x: x[0].lineno, reverse=True)

    for func_node, fixes_list in func_fixes:
        # Pre-classify each default into single-line (rewriteable) or
        # multi-line (skipped). Only single-line defaults get sentinel guards.
        rewriteable: list[tuple[str, ast.expr, str]] = []
        for arg_name, default_node, orig_src in fixes_list:
            if default_node.lineno == default_node.end_lineno:
                rewriteable.append((arg_name, default_node, orig_src))
            else:
                result.skipped += 1
                result.skipped_details.append((file_label, default_node.lineno, arg_name))

        if not rewriteable:
            continue

        # --- Step 1: replace each rewriteable default with None, right-to-left ---
        rewriteable.sort(key=lambda x: (x[1].lineno, x[1].col_offset), reverse=True)
        for _arg_name, default_node, _orig in rewriteable:
            dl = default_node.lineno - 1
            dc = default_node.col_offset
            dec = default_node.end_col_offset
            line = lines[dl]
            lines[dl] = line[:dc] + "None" + line[dec:]

        # --- Step 2: insert sentinel guards (only for fixes we actually made) ---
        body = func_node.body
        first_stmt = body[0]

        if _is_docstring(first_stmt):
            insert_at = first_stmt.end_lineno  # already the next 0-based index
        else:
            insert_at = first_stmt.lineno - 1

        body_line = lines[first_stmt.lineno - 1]
        indent_str = body_line[: len(body_line) - len(body_line.lstrip())]

        rewriteable.sort(key=lambda x: (x[1].lineno, x[1].col_offset))
        sentinel_lines: list[str] = []
        for arg_name, _default_node, orig_src in rewriteable:
            sentinel_lines.append(f"{indent_str}if {arg_name} is None:\n")
            sentinel_lines.append(f"{indent_str}    {arg_name} = {orig_src}\n")

        for i, sl in enumerate(sentinel_lines):
            lines.insert(insert_at + i, sl)

        result.succeeded += len(rewriteable)

    return "".join(lines), result
