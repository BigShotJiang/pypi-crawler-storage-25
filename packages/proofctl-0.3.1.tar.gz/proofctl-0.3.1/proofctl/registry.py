"""Single source of truth for the proofctl rule catalogue.

Every rule is extracted at import time from `proofctl/checkers/*.py` by walking
each module's AST and collecting `Finding(...)` and `_f(...)` constructions.
The registry powers:
  - `proofctl rules` (CLI listing)
  - `--families` help text (family tokens)
  - tests that assert every emitted rule_id is documented

Rules with computed severity (e.g. `sev = Severity.ERROR if cond else WARNING`)
are listed in `_DYNAMIC_SEVERITY_OVERRIDES` so the registry surfaces a
sensible default — the highest severity the rule can fire at.

If you add a new checker rule, no registry change is required.  If your rule
uses a computed severity, add an entry to `_DYNAMIC_SEVERITY_OVERRIDES`.
"""
from __future__ import annotations

import ast
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from .models import Severity

# Human-readable label for each family token. The token is what users pass to
# `--families`; the label is shown in `proofctl rules`.
FAMILY_LABELS: dict[str, str] = {
    "P":        "Placeholders",
    "L":        "Cross-language leakage",
    "Q":        "Code quality",
    "I":        "Imports",
    "M":        "Phantom methods (mypy)",
    "V":        "Variant files / near-duplicates",
    "S":        "Security (Python)",
    "LLM":      "LLM integration",
    "TF":       "Terraform / HCL",
    "TG":       "Terragrunt",
    "DF":       "Dockerfile",
    "YAML":     "YAML / Kubernetes / GitHub Actions",
    "SH":       "Shell scripts",
    "SECRET":   "Hardcoded secrets",
    "INTERNAL": "Engine internal",
}

# Families that exist for plumbing reasons but shouldn't clutter user-facing
# lists. `proofctl rules --family INTERNAL` still works for debugging.
_HIDDEN_FAMILIES: frozenset[str] = frozenset({"INTERNAL"})

# Default severities for rules whose Finding(...) construction uses a computed
# expression rather than a literal Severity.X. Listed as the worst case the rule
# can fire at, since that is what `proofctl rules` should communicate.
_DYNAMIC_SEVERITY_OVERRIDES: dict[str, Severity] = {
    "PROOFCTL-DF-001":   Severity.ERROR,    # ERROR for :latest, WARNING for tag-without-digest
    "PROOFCTL-DF-005":   Severity.ERROR,    # ERROR for ENV, WARNING for ARG
    "PROOFCTL-I-002":    Severity.ERROR,    # ERROR/WARNING by category
    "PROOFCTL-P-001":    Severity.ERROR,    # ERROR for empty body, WARNING for `...`
    "PROOFCTL-Q-005":    Severity.WARNING,  # graduated by complexity score
    "PROOFCTL-Q-006":    Severity.WARNING,  # graduated by length
    "PROOFCTL-Q-007":    Severity.WARNING,  # graduated by param count
    "PROOFCTL-YAML-007": Severity.ERROR,    # ERROR for branch refs, WARNING for semver
}

# Manual metadata for rules whose Finding(...) is built via helper methods that
# don't take rule_id as a literal (e.g. rule_id pulled from a lookup table).
# Audited against the source; keep in sync if helpers change.
_MANUAL_METADATA: dict[str, tuple[str, Severity]] = {
    "PROOFCTL-L-001":    ("JavaScript idiom in Python",   Severity.ERROR),
    "PROOFCTL-L-002":    ("Java idiom in Python",         Severity.WARNING),
    "PROOFCTL-L-003":    ("Go idiom in Python",           Severity.WARNING),
    "PROOFCTL-Q-002":    ("Broad exception handler",      Severity.WARNING),
    "PROOFCTL-YAML-006": ("Unpinned image tag",           Severity.ERROR),
}


@dataclass(frozen=True)
class RuleSpec:
    rule_id: str
    rule_name: str
    severity: Severity
    family: str
    family_label: str
    source: str  # filename of the checker that emits it (informational)


def _const_str(node: ast.AST | None) -> str | None:
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _severity_label(node: ast.AST | None) -> str | None:
    """Returns 'ERROR' for `Severity.ERROR`, else None."""
    if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name) and node.value.id == "Severity":
        return node.attr
    return None


def _is_finding_call(call: ast.Call) -> str | None:
    """'finding' for Finding(...), 'helper' for _f(...) or self._f(...), else None."""
    fn = call.func
    if isinstance(fn, ast.Name):
        if fn.id == "Finding":
            return "finding"
        if fn.id == "_f":
            return "helper"
    if isinstance(fn, ast.Attribute) and fn.attr == "_f":
        return "helper"
    return None


def _scan_module(src_file: Path) -> Iterable[tuple[str, str | None, str | None]]:
    """Yield (rule_id, rule_name, severity_label) for each Finding/_f in this file."""
    tree = ast.parse(src_file.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        kind = _is_finding_call(node)
        if not kind:
            continue
        kw = {k.arg: k.value for k in node.keywords if k.arg}
        rule_id = rule_name = severity = None
        if kind == "helper":
            consts = [a for a in node.args if _const_str(a) is not None]
            for i, a in enumerate(consts):
                s = _const_str(a)
                if s and s.startswith("PROOFCTL-"):
                    rule_id = s
                    if i + 1 < len(consts):
                        rule_name = _const_str(consts[i + 1])
                    break
            if not rule_id:
                rule_id = _const_str(kw.get("rule_id"))
                rule_name = _const_str(kw.get("rule_name"))
            for a in node.args:
                lbl = _severity_label(a)
                if lbl:
                    severity = lbl
                    break
            if not severity:
                severity = _severity_label(kw.get("severity"))
        else:  # Finding(...)
            rule_id = _const_str(kw.get("rule_id"))
            rule_name = _const_str(kw.get("rule_name"))
            severity = _severity_label(kw.get("severity"))
        if rule_id:
            yield rule_id, rule_name, severity


_RULE_ID_RE = re.compile(r"PROOFCTL-[A-Z]+(?:-[A-Z]+)?-[A-Z]?\d+")


def _build_registry() -> dict[str, RuleSpec]:
    pkg_dir = Path(__file__).parent
    checkers_dir = pkg_dir / "checkers"
    # The engine emits PROOFCTL-INTERNAL-001 via _internal_finding, so include
    # it in the scan even though it doesn't live under checkers/.
    extra_modules = [pkg_dir / "engine.py"]
    raw: dict[str, dict] = {}
    sev_order = {"INFO": 0, "WARNING": 1, "ERROR": 2}

    scan_targets: list[Path] = list(checkers_dir.rglob("*.py")) + extra_modules
    # Pass 1: AST-based extraction of (rule_id, rule_name, severity) triples.
    for src_file in sorted(scan_targets):
        if src_file.name.startswith("__"):
            continue
        for rule_id, rule_name, severity in _scan_module(src_file):
            entry = raw.get(rule_id)
            if entry is None:
                raw[rule_id] = {
                    "rule_name": rule_name,
                    "severity": severity,
                    "source": src_file.name,
                }
            else:
                if not entry["rule_name"] and rule_name:
                    entry["rule_name"] = rule_name
                if severity and sev_order.get(severity, 0) > sev_order.get(entry["severity"] or "INFO", 0):
                    entry["severity"] = severity

    # Pass 2: scan every checker file for `PROOFCTL-…` literals so rules emitted
    # through helpers (e.g. quality.py Q-002 via a variable, leakage.py via a
    # _find() helper) still appear in the registry.
    for src_file in sorted(scan_targets):
        if src_file.name.startswith("__"):
            continue
        text = src_file.read_text(encoding="utf-8")
        for rule_id in set(_RULE_ID_RE.findall(text)):
            if rule_id not in raw:
                raw[rule_id] = {"rule_name": None, "severity": None, "source": src_file.name}

    registry: dict[str, RuleSpec] = {}
    for rule_id, meta in raw.items():
        family = rule_id.split("-")[1]

        # Resolve rule_name: AST-extracted → manual override → rule_id fallback
        rule_name = meta["rule_name"]
        if not rule_name and rule_id in _MANUAL_METADATA:
            rule_name = _MANUAL_METADATA[rule_id][0]
        if not rule_name:
            rule_name = rule_id

        # Resolve severity: AST-extracted → dynamic override → manual override → WARNING
        if meta["severity"]:
            severity = Severity.from_str(meta["severity"])
        elif rule_id in _DYNAMIC_SEVERITY_OVERRIDES:
            severity = _DYNAMIC_SEVERITY_OVERRIDES[rule_id]
        elif rule_id in _MANUAL_METADATA:
            severity = _MANUAL_METADATA[rule_id][1]
        else:
            severity = Severity.WARNING

        registry[rule_id] = RuleSpec(
            rule_id=rule_id,
            rule_name=rule_name,
            severity=severity,
            family=family,
            family_label=FAMILY_LABELS.get(family, family),
            source=meta["source"],
        )
    return registry


# Built once at import time. Walk a few-hundred-line file is ~ms-scale.
RULES: dict[str, RuleSpec] = _build_registry()


def family_tokens(*, include_hidden: bool = False) -> list[str]:
    """All family tokens that have at least one rule, in alphabetical order.

    Hidden families (currently: INTERNAL) are omitted unless explicitly
    requested. They still resolve through `RULES[…]` so explicit filtering
    by `proofctl rules --family INTERNAL` continues to work.
    """
    toks = {spec.family for spec in RULES.values()}
    if not include_hidden:
        toks -= _HIDDEN_FAMILIES
    return sorted(toks)


def is_hidden_family(token: str) -> bool:
    return token in _HIDDEN_FAMILIES


def families_help_string() -> str:
    """Human-readable list of user-facing families for `--families` help."""
    parts = [f"{tok} ({FAMILY_LABELS[tok]})" for tok in family_tokens() if tok in FAMILY_LABELS]
    return "Comma-separated rule families: " + ", ".join(parts) + ". Default: all."
