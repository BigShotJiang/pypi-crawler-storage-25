"""Baseline persistence + change detection.

Older versions used `(rule_id, file, message)` as the fingerprint, which broke
the moment a message embedded numerics ("complexity 23", "17 parameters") —
a trivial edit that nudged the number defeated the match and the finding
re-surfaced as "new". The H-10 fix is to *normalise* the message before
hashing: strip embedded numbers and quoted identifiers so semantically
identical findings collide regardless of their printed values.

The baseline file is versioned via `schema_version`. Loaders accept both
`schema_version: 1` (legacy fingerprint) and the current `schema_version: 2`
(normalised fingerprint), so existing baselines continue to suppress findings
they previously suppressed — at the cost of a one-time false-new flush when
the baseline is regenerated. New baselines are always written at v2.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import Finding

_BASELINE_FILE = ".proofctl-baseline.json"
_SCHEMA_VERSION = 2

# Strip embedded digits and quoted identifiers so messages with the same shape
# but different numbers/names collide. Examples that all reduce to the same
# normalised form:
#   "'visit_Call' has cyclomatic complexity 23 (threshold: 10)"
#   "'do_thing'    has cyclomatic complexity 41 (threshold: 10)"
_NUMBER_RE = re.compile(r"\b\d+(?:\.\d+)?\b")
_QUOTED_RE = re.compile(r"['\"`][^'\"`]*['\"`]")


_WHITESPACE_RE = re.compile(r"\s+")


def _normalise_message(msg: str) -> str:
    """Reduce a message to its structural shape for stable matching.

    Strips embedded numbers, quoted identifiers, and collapses runs of
    whitespace so cosmetic message changes don't defeat the baseline.
    """
    msg = _QUOTED_RE.sub("'X'", msg)
    msg = _NUMBER_RE.sub("N", msg)
    msg = _WHITESPACE_RE.sub(" ", msg)
    return msg.strip()


def _fingerprint_v2(f: Finding) -> tuple[str, str, str]:
    return (f.rule_id, f.file, _normalise_message(f.message))


def _fingerprint_v1(f: Finding) -> tuple[str, str, str]:
    """Legacy fingerprint — kept so v1 baselines keep working until regenerated."""
    return (f.rule_id, f.file, f.message)


def save_baseline(findings: list[Finding], root: Path) -> Path:
    from . import __version__
    baseline_path = root / _BASELINE_FILE
    data = {
        "schema_version": _SCHEMA_VERSION,
        "created": datetime.now(timezone.utc).isoformat(),
        "proofctl_version": __version__,
        "count": len(findings),
        "findings": [
            {"rule_id": f.rule_id, "file": f.file, "message": f.message}
            for f in findings
        ],
    }
    baseline_path.write_text(json.dumps(data, indent=2))
    return baseline_path


def load_baseline(root: Path) -> dict | None:
    """Returns the parsed baseline dict, or None if missing/unparseable.

    The shape is `{"schema_version": int, "findings": [...]}`. Legacy
    baselines (no schema_version field) are treated as schema_version 1.
    """
    baseline_path = root / _BASELINE_FILE
    if not baseline_path.exists():
        return None
    try:
        data = json.loads(baseline_path.read_text())
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict) or "findings" not in data:
        return None
    data.setdefault("schema_version", 1)
    return data


def filter_new_findings(findings: list[Finding], baseline: dict | list[dict]) -> list[Finding]:
    """Return only findings not accounted for in the baseline.

    Backwards-compat: if `baseline` is a bare list, treat it as the legacy
    `data["findings"]` form (schema 1).

    Each baseline entry suppresses N occurrences of the matching fingerprint.
    """
    if isinstance(baseline, list):
        baseline_findings = baseline
        schema = 1
    else:
        baseline_findings = baseline.get("findings", [])
        schema = baseline.get("schema_version", 1)

    fingerprint = _fingerprint_v2 if schema >= 2 else _fingerprint_v1

    def _key_from_dict(b: dict) -> tuple[str, str, str]:
        if schema >= 2:
            return (b["rule_id"], b["file"], _normalise_message(b["message"]))
        return (b["rule_id"], b["file"], b["message"])

    baseline_counts: Counter[tuple] = Counter(_key_from_dict(b) for b in baseline_findings)
    result: list[Finding] = []
    seen: Counter[tuple] = Counter()
    for f in findings:
        key = fingerprint(f)
        if seen[key] < baseline_counts[key]:
            seen[key] += 1
        else:
            result.append(f)
    return result
