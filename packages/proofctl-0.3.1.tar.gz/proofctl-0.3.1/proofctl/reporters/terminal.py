from __future__ import annotations

import io
from collections import Counter
from pathlib import Path

from rich import box
from rich.console import Console
from rich.padding import Padding
from rich.table import Table
from rich.text import Text

from ..models import Finding, Severity

_BADGE: dict[Severity, tuple[str, str]] = {
    Severity.ERROR:   ("bold white on red",        "ERROR"),
    Severity.WARNING: ("bold black on yellow",      "WARNING"),
    Severity.INFO:    ("bold white on grey50",      "INFO"),
}

_SEV_STYLE: dict[Severity, str] = {
    Severity.ERROR:   "bold red",
    Severity.WARNING: "bold yellow",
    Severity.INFO:    "dim",
}

# Default stdout console used when no console is injected. Retained as a
# module-level default for backward compatibility, but engine/CLI code should
# pass a Console explicitly to keep ordering deterministic in piped scenarios
# (see AUDIT 1.6 — Reporters: console unification).
console = Console(highlight=False)


def _location(f: Finding) -> str:
    if f.line:
        return f"{f.file}:{f.line}"
    return f.file


class TerminalReporter:
    def render(
        self,
        findings: list[Finding],
        output: Path | None = None,
        console_: Console | None = None,
    ) -> str:
        """Render findings to the terminal, or capture to a string when `output` is set.

        When `output` is provided, the reporter renders into an in-memory Console
        and returns the captured text (with ANSI styling stripped) so the caller
        can write it to disk. Otherwise, prints via the supplied `console_`
        (or the module-level default) and returns "".

        Passing an explicit `console_` lets callers share a single Console with
        the engine so stdout/stderr ordering stays deterministic when output is
        piped — the audit identified non-deterministic ordering as a defect.
        """
        if output is not None:
            buf = io.StringIO()
            target = Console(file=buf, force_terminal=False, no_color=True, width=120, highlight=False)
        else:
            target = console_ if console_ is not None else console

        if not findings:
            target.print(Padding("[bold green]✓  No findings.[/bold green]", (1, 2)))
            return buf.getvalue() if output is not None else ""

        target.print()

        sorted_findings = sorted(
            findings, key=lambda x: (-x.severity, x.file, x.line or 0)
        )

        table = Table(
            box=box.ROUNDED,
            show_header=True,
            show_edge=True,
            show_lines=True,
            header_style="bold",
            padding=(0, 1),
            expand=True,
        )
        table.add_column("Severity", no_wrap=True,    min_width=11, max_width=13)
        table.add_column("Rule",     no_wrap=True,    ratio=2, min_width=22)
        table.add_column("Family",   overflow="fold", ratio=2)
        table.add_column("Location", overflow="fold", ratio=3)
        table.add_column("Message",  overflow="fold", ratio=5)

        for f in sorted_findings:
            badge_style, badge_label = _BADGE[f.severity]
            sev_cell = Text(f"  {badge_label}  ", style=badge_style)
            msg_cell = Text(f.message)
            if f.hint:
                msg_cell.append(f"\n→ {f.hint}", style="dim")
            if f.authority:
                auth_style = f"italic dim link {f.docs_url}" if f.docs_url else "italic dim"
                msg_cell.append(f"\n📖 {f.authority}", style=auth_style)
            table.add_row(
                sev_cell,
                Text(f.rule_id, style="bold"),
                Text(f.rule_name, style="dim"),
                Text(_location(f), style=_SEV_STYLE[f.severity]),
                msg_cell,
            )

        target.print(Padding(table, (0, 2)))
        target.print()

        # Summary bar
        counts = Counter(f.severity for f in findings)
        total = len(findings)
        bar = Text(f"  {total} finding{'s' if total != 1 else ''}    ")
        for sev in reversed(Severity):
            if not counts[sev]:
                continue
            badge_style, badge_label = _BADGE[sev]
            bar.append(f"  {badge_label}  ", style=badge_style)
            bar.append(f"  {counts[sev]}   ", style="bold")
        target.print(bar)
        target.print()

        return buf.getvalue() if output is not None else ""
