from __future__ import annotations

import json
from collections import Counter

from ..models import Finding, Severity

# Bumped in lockstep with documented JSON schema changes. Consumers can branch
# on this field. Start at 1 since this is the first formally-stable schema.
SCHEMA_VERSION = 1

# Stable field order for each finding object. Matches the order documented in
# the README and used by external tooling.
_FINDING_FIELDS = (
    "file",
    "line",
    "col",
    "rule_id",
    "rule_name",
    "severity",
    "message",
    "hint",
    "authority",
    "docs_url",
    "fixable",
)


class JsonReporter:
    def render(self, findings: list[Finding]) -> str:
        counts = Counter(f.severity for f in findings)

        # Stable summary order: total, ERROR, WARNING, INFO (matches README).
        summary = {
            "total": len(findings),
            "ERROR": counts[Severity.ERROR],
            "WARNING": counts[Severity.WARNING],
            "INFO": counts[Severity.INFO],
        }

        serialisable = []
        for f in findings:
            d = {
                "file": f.file,
                "line": f.line,
                "col": f.col,
                "rule_id": f.rule_id,
                "rule_name": f.rule_name,
                "severity": f.severity.label(),
                "message": f.message,
                "hint": f.hint,
                "authority": f.authority,
                "docs_url": f.docs_url,
                "fixable": f.fixable,
            }
            serialisable.append(d)

        payload = {
            "schema_version": SCHEMA_VERSION,
            "summary": summary,
            "findings": serialisable,
        }
        return json.dumps(payload, indent=2)
