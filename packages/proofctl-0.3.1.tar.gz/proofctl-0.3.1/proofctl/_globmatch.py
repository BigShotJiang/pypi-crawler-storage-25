"""Tiny gitignore-style glob matcher (no external deps).

Supports the patterns proofctl users actually write in `.proofctl.yaml`:

  **              any subtree
  **/X/**         X anywhere in the tree (default exclude shape)
  X/**            X and everything under it
  **/X            any path ending in X
  *.ext           basename-only match anywhere
  a/**/b          arbitrary depth between a and b
  [Cc]hars        character classes

Patterns are matched against POSIX-style relative paths
(forward-slash separators). Cross-platform safety lives upstream:
the engine converts every path through `Path.as_posix()` before matching.

Why not use `fnmatch.fnmatch`?  It treats `**` as the same thing as `*`, which
is wrong for users typing `**/.venv/**`.  Why not vendor `pathspec`?  An 80-line
matcher covering this dialect needs no third-party code and no version skew.
"""
from __future__ import annotations

import re
from typing import Callable

_DOUBLESTAR = "\x00DOUBLESTAR\x00"  # placeholder we substitute contextually


def _compile_one(pattern: str) -> re.Pattern[str]:
    """Translate a single gitignore-style pattern to an anchored regex."""
    pat = pattern.strip().rstrip("/")
    has_slash = "/" in pat
    parts = pat.split("/")

    encoded: list[str] = []
    for part in parts:
        if part == "**":
            encoded.append(_DOUBLESTAR)
            continue

        # Translate the segment's wildcards. We don't use re.escape() because
        # we have to preserve the meaning of *, ?, and [ ] character classes.
        out: list[str] = []
        j = 0
        while j < len(part):
            ch = part[j]
            if ch == "*":
                out.append("[^/]*")
            elif ch == "?":
                out.append("[^/]")
            elif ch == "[":
                end = part.find("]", j + 1)
                if end == -1:
                    out.append(re.escape(ch))
                else:
                    cls = part[j + 1 : end]
                    if cls.startswith("!"):
                        cls = "^" + cls[1:]
                    out.append("[" + cls + "]")
                    j = end
            else:
                out.append(re.escape(ch))
            j += 1
        encoded.append("".join(out))

    body = "/".join(encoded)

    # Expand the `**` placeholder according to its position. Order matters —
    # leading/trailing/middle cases produce different regex than a bare `**`.
    body = re.sub(rf"^{re.escape(_DOUBLESTAR)}/", "(?:.*/)?", body)
    body = re.sub(rf"/{re.escape(_DOUBLESTAR)}$", "(?:/.*)?", body)
    body = body.replace(f"/{_DOUBLESTAR}/", "/(?:.*/)?")
    body = body.replace(_DOUBLESTAR, ".*")

    if not has_slash:
        # No slash → match a basename anywhere in the tree.
        return re.compile(rf"(?:^|.*/){body}$")
    return re.compile(rf"^{body}$")


def compile_globs(patterns: list[str]) -> Callable[[str], bool]:
    """Compile a list of patterns into a single fast `match(rel_path) -> bool`.

    `rel_path` must be POSIX-style (forward slashes); callers pass
    `Path.as_posix()`.
    """
    if not patterns:
        return lambda _rel: False
    compiled = [_compile_one(p) for p in patterns if p.strip()]
    if not compiled:
        return lambda _rel: False

    def _match(rel: str) -> bool:
        for r in compiled:
            if r.match(rel):
                return True
        return False

    return _match
