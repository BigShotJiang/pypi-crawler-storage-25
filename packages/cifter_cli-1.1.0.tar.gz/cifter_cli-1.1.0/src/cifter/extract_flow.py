from __future__ import annotations

from tree_sitter import Node

from cifter.model import ExtractedLine, ExtractionResult, InlineHighlightSpan, TrackPath
from cifter.omission import attach_omission_markers
from cifter.parser import ParsedSource, function_body, node_text
from cifter.tree_helpers import case_body_container, container_statements, else_clause

CONTROL_TYPES = {"if_statement", "switch_statement", "case_statement", "for_statement", "while_statement", "do_statement", "goto_statement", "break_statement", "continue_statement", "return_statement", "labeled_statement"}
STATEMENT_TYPES = {"expression_statement", "declaration", "goto_statement", "break_statement", "continue_statement", "return_statement"}
def extract_flow_node(parsed: ParsedSource, function_node: Node, tracks: tuple[TrackPath, ...], *, include_highlights: bool = False) -> ExtractionResult:
    body = function_body(function_node)
    keep: set[int] = set()
    highlights: dict[int, set[InlineHighlightSpan]] = {}
    _keep_range(keep, function_node.start_point.row + 1, body.start_point.row + 1)
    keep.add(body.end_point.row + 1)
    _collect_from_container(parsed, body, keep, highlights, tracks, include_highlights)
    line_numbers = sorted(keep)
    lines = tuple(
        ExtractedLine(
            line_no=line_no,
            text=parsed.source.line_text(line_no),
            highlights=tuple(
                sorted(
                    highlights.get(line_no, ()),
                    key=lambda highlight: (
                        highlight.start_column,
                        highlight.end_column,
                        highlight.kind,
                    ),
                )
            ),
        )
        for line_no in line_numbers
    )
    lines = attach_omission_markers(parsed.source, lines)
    return ExtractionResult(span=parsed.source.span_for_lines(line_numbers), lines=lines)


def _collect_from_container(parsed: ParsedSource, container: Node, keep: set[int], highlights: dict[int, set[InlineHighlightSpan]], tracks: tuple[TrackPath, ...], include_highlights: bool) -> None:
    for statement in container_statements(container):
        _collect_statement(parsed, statement, keep, highlights, tracks, include_highlights)


def _collect_statement(parsed: ParsedSource, statement: Node, keep: set[int], highlights: dict[int, set[InlineHighlightSpan]], tracks: tuple[TrackPath, ...], include_highlights: bool) -> None:
    track_matches = _collect_track_matches(parsed, statement, tracks)
    if include_highlights:
        _record_track_highlights(parsed, track_matches, highlights)
    if statement.type == "switch_statement":
        _collect_container_statement(
            parsed,
            statement,
            statement.named_children[-1],
            keep,
            highlights,
            tracks,
            include_highlights,
        )
        return
    if statement.type == "case_statement":
        _collect_case_statement(parsed, statement, keep, highlights, tracks, include_highlights)
        return
    if statement.type == "if_statement":
        _collect_if_chain(parsed, statement, keep, highlights, tracks, include_highlights)
        return
    if statement.type in {"for_statement", "while_statement"}:
        _collect_container_statement(
            parsed,
            statement,
            statement.named_children[-1],
            keep,
            highlights,
            tracks,
            include_highlights,
        )
        return
    if statement.type == "do_statement":
        keep.update({statement.start_point.row + 1, statement.end_point.row + 1})
        _collect_nested_statement(
            parsed,
            statement.named_children[0],
            keep,
            highlights,
            tracks,
            include_highlights,
            keep_closing=True,
        )
        return
    if statement.type == "labeled_statement":
        keep.add(statement.start_point.row + 1)
        _collect_statement(
            parsed, statement.named_children[-1], keep, highlights, tracks, include_highlights
        )
        return
    if statement.type in CONTROL_TYPES:
        _keep_range(keep, statement.start_point.row + 1, statement.end_point.row + 1)
        return
    if statement.type in STATEMENT_TYPES and track_matches:
        _keep_range(keep, statement.start_point.row + 1, statement.end_point.row + 1)


def _collect_if_chain(parsed: ParsedSource, if_node: Node, keep: set[int], highlights: dict[int, set[InlineHighlightSpan]], tracks: tuple[TrackPath, ...], include_highlights: bool) -> None:
    consequence = if_node.named_children[1]
    _keep_range(keep, if_node.start_point.row + 1, consequence.start_point.row + 1)
    _collect_nested_statement(
        parsed, consequence, keep, highlights, tracks, include_highlights, keep_closing=True
    )

    clause = else_clause(if_node)
    if clause is None:
        return
    alternative = clause.named_children[-1]
    _keep_range(keep, clause.start_point.row + 1, alternative.start_point.row + 1)
    if alternative.type == "if_statement":
        _collect_if_chain(parsed, alternative, keep, highlights, tracks, include_highlights)
        return
    _collect_nested_statement(
        parsed, alternative, keep, highlights, tracks, include_highlights, keep_closing=True
    )


def _collect_case_statement(parsed: ParsedSource, statement: Node, keep: set[int], highlights: dict[int, set[InlineHighlightSpan]], tracks: tuple[TrackPath, ...], include_highlights: bool) -> None:
    keep.add(statement.start_point.row + 1)
    body = case_body_container(statement)
    if body is statement:
        _collect_from_container(parsed, body, keep, highlights, tracks, include_highlights)
        return
    keep.update({body.start_point.row + 1, body.end_point.row + 1})
    _collect_from_container(parsed, body, keep, highlights, tracks, include_highlights)


def _collect_container_statement(parsed: ParsedSource, statement: Node, body: Node, keep: set[int], highlights: dict[int, set[InlineHighlightSpan]], tracks: tuple[TrackPath, ...], include_highlights: bool) -> None:
    _keep_range(keep, statement.start_point.row + 1, body.start_point.row + 1)
    _collect_nested_statement(
        parsed, body, keep, highlights, tracks, include_highlights, keep_closing=True
    )


def _collect_nested_statement(parsed: ParsedSource, statement: Node, keep: set[int], highlights: dict[int, set[InlineHighlightSpan]], tracks: tuple[TrackPath, ...], include_highlights: bool, *, keep_closing: bool = False) -> None:
    if statement.type != "compound_statement":
        _collect_statement(parsed, statement, keep, highlights, tracks, include_highlights)
        return
    if keep_closing:
        keep.add(statement.end_point.row + 1)
    _collect_from_container(parsed, statement, keep, highlights, tracks, include_highlights)


def _record_track_highlights(parsed: ParsedSource, matches: tuple[Node, ...], highlights: dict[int, set[InlineHighlightSpan]]) -> None:
    for match in matches:
        for line_no, start_column, end_column in parsed.source.inline_spans_for_byte_range(
            match.start_byte,
            match.end_byte,
        ):
            line_highlights = highlights.setdefault(line_no, set())
            line_highlights.add(
                InlineHighlightSpan(
                    start_column=start_column,
                    end_column=end_column,
                    kind="track_match",
                )
            )


def _collect_track_matches(parsed: ParsedSource, node: Node, tracks: tuple[TrackPath, ...]) -> tuple[Node, ...]:
    if not tracks:
        return ()
    normalized_tracks = {track.normalized for track in tracks}
    matches: list[Node] = []
    seen: set[tuple[int, int]] = set()
    stack = [node]
    while stack:
        current = stack.pop()
        candidate = _track_candidate_text(parsed, current)
        if candidate is not None and candidate in normalized_tracks:
            key = (current.start_byte, current.end_byte)
            if key not in seen:
                seen.add(key)
                matches.append(current)
        stack.extend(reversed(current.named_children))
    return tuple(matches)


def _track_candidate_text(parsed: ParsedSource, node: Node) -> str | None:
    if node.type == "field_expression":
        return "".join(node_text(parsed.source, node).split())
    if (
        node.type == "identifier"
        and node.parent is not None
        and node.parent.type != "field_expression"
    ):
        return node_text(parsed.source, node)
    return None


def _keep_range(keep: set[int], start_line: int, end_line: int) -> None: keep.update(range(start_line, end_line + 1))
