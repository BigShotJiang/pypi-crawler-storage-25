from typing import Callable

import torch
from torch.func import jacrev

from vicentin.utils.logging import info, debug, warn


def _fletcher_reeves(g_new, g_old, d, y):
    return torch.dot(g_new, g_new) / (torch.dot(g_old, g_old) + 1e-12)


def _polak_ribiere(g_new, g_old, d, y):
    return torch.dot(g_new, y) / (torch.dot(g_old, g_old) + 1e-12)


def _hestenes_stiefel(g_new, g_old, d, y):
    return torch.dot(g_new, y) / (torch.dot(d, y) + 1e-12)


def _dai_yuan(g_new, g_old, d, y):
    return torch.dot(g_new, g_new) / (torch.dot(d, y) + 1e-12)


BETA_METHODS = {
    "fletcher-reeves": _fletcher_reeves,
    "polak-ribiere": _polak_ribiere,
    "hestenes-stiefel": _hestenes_stiefel,
    "dai-yuan": _dai_yuan,
}


def ncg_line_search(x, f, grad_x, d, gamma):
    f_x = f(x)
    slope = torch.dot(grad_x, d)
    next_x = x + gamma * d
    while True:
        if f(next_x) <= f_x + 0.1 * gamma * slope or gamma < 1e-12:
            debug(f"Line search: gamma={gamma:.4e} after {iters} shrinks")
            break
        gamma /= 2
        next_x = x + gamma * d
    return next_x, gamma * 1.2


def ncg(
    f: Callable,
    x0: torch.Tensor,
    method: str = "polak-ribiere",
    max_iter: int = 100,
    tol: float = 1e-6,
    epsilon: float = 1e-8,
    return_loss: bool = False,
):
    x = x0.clone().detach()
    loss = []

    info(f"Starting Nonlinear CG [Torch] on {x.device} using {method}")

    beta_func = BETA_METHODS[method]
    grad_f = jacrev(f)

    g_old = grad_f(x)
    if isinstance(g_old, (list, tuple)):
        g_old = g_old[0]
    d = -g_old
    gamma = 1

    for i in range(max_iter):
        with torch.no_grad():
            x_new, gamma = ncg_line_search(x, f, g_old, d, gamma)

        f_val = f(x_new)
        loss.append(f_val.item())

        g_new = grad_f(x_new)
        if isinstance(g_new, (list, tuple)):
            g_new = g_new[0]

        g_norm = torch.linalg.norm(g_new).item()
        f_delta = torch.abs(f(x) - f_val).item()

        info(f"Iter {i}: f(x)={f_val.item():.6e} | Grad Norm={g_norm:.4e}")

        if f_delta < tol or g_norm < epsilon:
            info("NCG converged successfully.")
            x = x_new
            break

        y = g_new - g_old
        beta = torch.clamp(beta_func(g_new, g_old, d, y), min=0)
        d = -g_new + beta * d

        if (i + 1) % x.numel() == 0:
            debug("NCG: Periodic direction reset")
            d = -g_new

        x, g_old = x_new, g_new

    return (x, loss) if return_loss else x
