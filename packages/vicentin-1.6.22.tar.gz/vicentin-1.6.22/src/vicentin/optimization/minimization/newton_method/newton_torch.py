from typing import Callable, Optional

import torch
from torch.func import jacrev, hessian
from torch.linalg import norm, solve

from vicentin.utils.logging import info, debug, warn


def backtrack_line_search(
    f: Callable,
    r: Callable,
    x: torch.Tensor,
    delta_x: torch.Tensor,
    w: torch.Tensor,
    delta_w: torch.Tensor,
    alpha: float,
    beta: float,
):
    y = r(x, w).item()
    t = 1
    iters = 0

    while True:
        f_x = f(x + t * delta_x)
        infeasible = torch.isnan(f_x) or torch.isinf(f_x)
        feasible = not infeasible

        if feasible:
            lipschitz = (
                r(x + t * delta_x, w + t * delta_w).item()
                <= (1 - alpha * t) * y
            )

            if lipschitz:
                debug(f"Line search converged: t={t:.4e} after {iters} shrinks")
                break

        t *= beta
        iters += 1

        if t < 1e-12:
            warn("Line search failed to find feasible step; returning t=0")
            return 0

    return t


def default_solver(
    hess_f: Callable,
    grad_f: Callable,
    x: torch.Tensor,
    w: torch.Tensor,
    A: torch.Tensor,
    b: torch.Tensor,
):
    grad = grad_f(x).to(dtype=x.dtype, device=x.device)
    H = hess_f(x).to(dtype=x.dtype, device=x.device)

    min_svd = torch.linalg.svdvals(H).min()
    if min_svd < 1e-12:
        debug(
            f"Hessian near-singular (min_svd={min_svd:.2e}). Applying jitter."
        )
        H = H + 1e-8 * torch.eye(H.shape[-1], device=x.device, dtype=x.dtype)

    g = grad + A.T @ w
    h = A @ x - b

    inv_H_A = solve(H, A.T)
    inv_H_g = solve(H, g)

    S = -A @ inv_H_A

    delta_w = solve(S, A @ inv_H_g - h)
    delta_x = solve(H, -A.T @ delta_w - g)

    decrement_squared = delta_x @ H @ delta_x

    debug(
        f"Linear system solved. Newton decrement squared: {decrement_squared:.4e}"
    )
    return delta_x, delta_w, decrement_squared


def newton_step(
    f: Callable,
    grad_f: Callable,
    hess_f: Callable,
    r: Callable,
    x: torch.Tensor,
    w: torch.Tensor,
    A: torch.Tensor,
    b: torch.Tensor,
    alpha: float = 0.25,
    beta: float = 0.5,
    linear_solver: Optional[Callable] = None,
):
    if linear_solver is None:
        linear_solver = default_solver

    delta_x, delta_w, decrement_squared = linear_solver(
        hess_f, grad_f, x, w, A, b
    )

    t = backtrack_line_search(f, r, x, delta_x, w, delta_w, alpha, beta)

    x = x + t * delta_x
    w = w + t * delta_w

    return x, w, decrement_squared


def newton(
    f: Callable,
    x0: torch.Tensor,
    equality: Optional[tuple] = None,
    max_iter: int = 100,
    tol: float = 1e-8,
    epsilon: float = 1e-4,
    alpha: float = 0.25,
    beta: float = 0.5,
    linear_solver: Optional[Callable] = None,
    return_dual: bool = False,
    return_loss: bool = False,
):
    x = x0.clone().detach()
    i = 0
    loss = []

    grad_f_raw = jacrev(f)
    hess_f_raw = hessian(f)

    def grad_f(x):
        g = grad_f_raw(x)
        if isinstance(g, (list, tuple)):
            return g[0]
        return g

    def hess_f(x):
        H = hess_f_raw(x)
        if isinstance(H, (list, tuple)):
            return H[0]
        return H

    device = x.device
    dtype = x.dtype

    if equality is None:
        A = torch.empty((0, x.numel()), device=device, dtype=dtype)
        b = torch.empty(0, device=device, dtype=dtype)
        w = torch.empty(0, device=device, dtype=dtype)
    else:
        A, b = equality
        w = torch.zeros(A.shape[0], device=device, dtype=dtype)

        info(f"Initialized with {A.shape[0]} equality constraints.")

    r = lambda x, w: norm(
        torch.cat([grad_f(x).view(-1) + A.T @ w, A @ x.view(-1) - b])
    )

    with torch.no_grad():
        y_new = f(x).item()

    info(f"Starting solver with {max_iter=} on {device}")

    while True:
        y = y_new
        if y == torch.inf:
            raise ValueError(f"Reached infeasible point: {x}.")

        with torch.no_grad():
            x, w, decrement_squared = newton_step(
                f, grad_f, hess_f, r, x, w, A, b, alpha, beta, linear_solver
            )

            y_new = f(x).item()
            r_val = r(x, w).item()

        loss.append(y_new)

        feasible = torch.isclose(A @ x.view(-1), b).all()

        info(
            f"Iter {i}: f(x)={y_new:.6e}, Residual={r_val:.4e}, Feasible={feasible}"
        )

        if (not feasible and r_val <= epsilon) or (
            feasible and decrement_squared <= 2 * epsilon
        ):
            info("Success: Convergence reached via Newton decrement/residual.")
            break

        if abs(y_new - y) < tol:
            info("Success: Convergence reached via function value tolerance.")
            break

        i += 1

        if i >= max_iter:
            warn(
                f"Warning: Reached max_iter ({max_iter}) without full convergence."
            )
            break

    output = [x]

    if return_dual:
        debug("Appending dual solution to return")
        output.append(w)

    if return_loss:
        debug("Appending losses to return")
        output.append(loss)

    if len(output) == 1:
        return output[0]

    return output
