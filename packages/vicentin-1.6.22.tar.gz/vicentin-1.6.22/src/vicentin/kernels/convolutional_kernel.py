from typing import Any, Optional

from vicentin.kernels import Kernel
from vicentin.utils import Dispatcher
from vicentin.utils.logging import debug

disp_patches = Dispatcher()

try:
    from numpy.lib.stride_tricks import as_strided

    def extract_patches_np(X, image_shape, patch_size):
        N = X.shape[0]
        H, W, C = image_shape
        pH, pW = patch_size

        X_reshaped = X.reshape(N, H, W, C)

        out_H = H - pH + 1
        out_W = W - pW + 1

        shape = (N, out_H, out_W, pH, pW, C)
        strides = (
            X_reshaped.strides[0],
            X_reshaped.strides[1],
            X_reshaped.strides[2],
            X_reshaped.strides[1],
            X_reshaped.strides[2],
            X_reshaped.strides[3],
        )

        patches = as_strided(X_reshaped, shape=shape, strides=strides)

        num_patches = out_H * out_W
        patch_dim = pH * pW * C

        return patches.reshape(N, num_patches, patch_dim)

    disp_patches.register("numpy", extract_patches_np)
except ModuleNotFoundError:
    pass

try:
    import torch.nn.functional as F

    def extract_patches_torch(X, image_shape, patch_size):
        N = X.shape[0]
        H, W, C = image_shape
        pH, pW = patch_size

        X_reshaped = X.reshape(N, H, W, C).permute(0, 3, 1, 2)

        patches = F.unfold(X_reshaped, kernel_size=patch_size)
        return patches.transpose(1, 2)

    disp_patches.register("torch", extract_patches_torch)
except ModuleNotFoundError:
    pass


class ConvolutionalKernel(Kernel):
    def __init__(
        self,
        base_kernel: Kernel,
        image_shape: tuple = (32, 32, 3),
        patch_size: tuple = (5, 5),
        **kwargs,
    ):
        self.base_kernel = base_kernel
        self.image_shape = image_shape
        self.patch_size = patch_size

        kwargs.setdefault("chunk_size", base_kernel.chunk_size)
        super().__init__(None, **kwargs)

        if base_kernel.X is not None:
            self.set_X(base_kernel.X)

    def set_X(self, X: Any):
        ctx = disp_patches.detect_backend(X)
        patches_X = disp_patches(ctx, X, self.image_shape, self.patch_size)

        flat_patches = patches_X.reshape(-1, patches_X.shape[-1])

        self.base_kernel.set_X(flat_patches)
        self.num_patches = patches_X.shape[1]

        self.X = self.base_kernel.X
        self.N = self.base_kernel.N
        self.backend = self.base_kernel.backend

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        ctx = disp_patches.detect_backend(x)

        patches_x = disp_patches(ctx, x, self.image_shape, self.patch_size)
        N_x = patches_x.shape[0]
        flat_x = patches_x.reshape(-1, patches_x.shape[-1])

        if y is None or y is self.X:
            flat_y = None
            N_y = self.N
        else:
            patches_y = disp_patches(ctx, y, self.image_shape, self.patch_size)
            N_y = patches_y.shape[0]
            flat_y = patches_y.reshape(-1, patches_y.shape[-1])

        K_patches = self.base_kernel(flat_x, flat_y)

        K_reshaped = K_patches.reshape(
            N_x, self.num_patches, N_y, self.num_patches
        )

        if "torch" in ctx.backend:
            return K_reshaped.sum(dim=(1, 3))
        else:
            return K_reshaped.sum(axis=(1, 3))

    def __repr__(self):
        return f"ConvolutionalKernel(base={self.base_kernel!r}, patch_size={self.patch_size})"
