from typing import Any, Optional

from vicentin.kernels import Kernel
from vicentin.utils import Dispatcher

disp_cos = Dispatcher()

try:
    import numpy as np

    def np_cosine(x, y):
        if y is None:
            y = x

        x_norm = x / np.linalg.norm(x, axis=1, keepdims=True)
        y_norm = y / np.linalg.norm(y, axis=1, keepdims=True)

        return x_norm @ y_norm.T

    disp_cos.register("numpy", np_cosine)
except ModuleNotFoundError:
    pass

try:
    import torch.nn.functional as F

    def torch_cosine(x, y):
        if y is None:
            y = x

        x_norm = F.normalize(x, p=2, dim=1)
        y_norm = F.normalize(y, p=2, dim=1)

        return x_norm @ y_norm.T

    disp_cos.register("torch", torch_cosine)
except ModuleNotFoundError:
    pass


class CosineKernel(Kernel):
    def __init__(self, X: Optional[Any] = None, **kwargs):
        super().__init__(X, **kwargs)

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        ctx = disp_cos.detect_backend(x)
        ctx.verbose = False

        if getattr(x, "ndim", 1) == 1:
            x = x[None, :]
        if y is not None and getattr(y, "ndim", 1) == 1:
            y = y[None, :]

        return disp_cos(ctx, x, y).squeeze()

    def __repr__(self):
        return f"CosineKernel(alpha={self._alpha:.2e})"
