from typing import Any, Optional

from vicentin.kernels import Kernel
from vicentin.utils import Dispatcher

disp_hik = Dispatcher()

try:
    import numpy as np

    def np_hik(x, y):
        if y is None:
            y = x
        res = np.zeros((x.shape[0], y.shape[0]), dtype=x.dtype)
        for i in range(x.shape[0]):
            res[i, :] = np.minimum(x[i], y).sum(axis=-1)
        return res

    disp_hik.register("numpy", np_hik)
except ModuleNotFoundError:
    pass

try:
    import torch

    def torch_hik(x, y):
        if y is None:
            y = x
        res = torch.zeros(
            (x.shape[0], y.shape[0]), dtype=x.dtype, device=x.device
        )
        for i in range(x.shape[0]):
            res[i, :] = torch.minimum(x[i], y).sum(dim=-1)
        return res

    disp_hik.register("torch", torch_hik)
except ModuleNotFoundError:
    pass


class HistogramIntersectionKernel(Kernel):
    def __init__(self, X: Optional[Any] = None, **kwargs):
        super().__init__(X, **kwargs)

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        ctx = disp_hik.detect_backend(x)
        ctx.verbose = False

        if getattr(x, "ndim", 1) == 1:
            x = x[None, :]
        if y is not None and getattr(y, "ndim", 1) == 1:
            y = y[None, :]

        return disp_hik(ctx, x, y).squeeze()

    def __repr__(self):
        return f"HistogramIntersectionKernel(alpha={self._alpha:.2e})"
