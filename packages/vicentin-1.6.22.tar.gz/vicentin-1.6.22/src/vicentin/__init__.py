import importlib.metadata

from .data_structures import *
from .utils import setup_logging

try:
    __version__ = importlib.metadata.version("vicentin")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"
