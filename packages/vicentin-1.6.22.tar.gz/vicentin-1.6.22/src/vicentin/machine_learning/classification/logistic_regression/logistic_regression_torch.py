from itertools import combinations

import torch

from vicentin.kernels import SubsetKernel
from vicentin.machine_learning.regression import RidgeRegression
from vicentin.utils.logging import debug, info


def _train_binary(X_kernel, y, lambda_orig, max_iter, tol, is_primal):
    if is_primal:
        N = X_kernel.shape[0]
        dtype = X_kernel.dtype
        device = X_kernel.device
    else:
        N = X_kernel.N
        dtype = X_kernel.X.dtype
        device = X_kernel.X.device

    m = torch.zeros((N, 1), dtype=dtype, device=device)
    y = y.reshape(-1, 1) if y.ndim == 1 else y

    weights = None
    ridge_model = RidgeRegression(lambda_=lambda_orig, backend="torch")

    for i in range(max_iter):
        m_prev = m.clone()

        W = torch.sigmoid(m) * torch.sigmoid(-m)
        z = m + y * (1 + torch.exp(-y * m))

        ridge_model.fit(X_kernel, z, W=W)

        X_pred = X_kernel if is_primal else X_kernel.X
        m = ridge_model.predict(X_pred).reshape(-1, 1)

        diff = (m - m_prev).abs().max().item()
        debug(f"Logistic Iteration {i+1}/{max_iter}, Diff: {diff:.6f}")

        if diff < tol:
            info(f"Logistic Regression converged in {i+1} iterations.")
            break

    weights = ridge_model.weights

    if is_primal and not ridge_model.is_primal:
        weights = X_kernel.T @ weights

    return weights


def logistic_regression(
    X_kernel, y, lambda_orig, max_iter, tol, is_primal, strategy="ovo"
):
    y = y.flatten()
    classes = torch.unique(y).int()
    classes_list = classes.tolist()
    info(f"Torch Classes detected: {classes_list}")

    X = X_kernel if is_primal else X_kernel.X

    if len(classes) == 2:
        y_bin = torch.where(
            y == classes[0],
            torch.tensor(-1, dtype=y.dtype, device=y.device),
            torch.tensor(1, dtype=y.dtype, device=y.device),
        )
        weights = _train_binary(
            X_kernel, y_bin, lambda_orig, max_iter, tol, is_primal
        )
        mask = torch.ones_like(y, dtype=torch.bool)
        return {
            "classes": classes,
            "models": [(weights, mask)],
            "strategy": "binary",
        }

    models = []
    if strategy == "ovo":
        info(
            f"Executing One-vs-One strategy ({len(list(combinations(classes, 2)))} pairs)"
        )

        for c1, c2 in combinations(classes_list, 2):
            debug(f"Training OvO pair: {c1} vs {c2}")

            mask = (y == c1) | (y == c2)
            y_bin = torch.where(
                y[mask] == c1,
                torch.tensor(-1, dtype=y.dtype, device=y.device),
                torch.tensor(1, dtype=y.dtype, device=y.device),
            )

            if is_primal:
                X_sub = X_kernel[mask]
            else:
                X_sub = SubsetKernel(X_kernel, mask)

            weights = _train_binary(
                X_sub, y_bin, lambda_orig, max_iter, tol, is_primal
            )
            models.append((weights, mask))

    elif strategy == "ovr":
        info(f"Executing One-vs-Rest ({len(classes_list)} classes)")

        for c in classes_list:
            debug(f"Training OvR for class: {c}")

            mask = torch.ones_like(y, dtype=torch.bool)
            y_bin = torch.where(
                y == c,
                torch.tensor(1, dtype=y.dtype, device=y.device),
                torch.tensor(-1, dtype=y.dtype, device=y.device),
            )
            weights = _train_binary(
                X_kernel, y_bin, lambda_orig, max_iter, tol, is_primal
            )
            models.append((weights, mask))

    return {"classes": classes, "models": models, "strategy": strategy}


def predict(model_data, kernel, X_test, is_primal):
    classes = model_data["classes"]
    models = model_data["models"]
    strategy = model_data["strategy"]
    device = X_test.device

    def get_pred(weights, mask):
        if is_primal:
            return X_test @ weights
        else:
            weights_full = torch.zeros(
                (kernel.N, 1), dtype=weights.dtype, device=device
            )
            weights_full[mask] = weights
            return kernel.apply(X_test, weights_full)

    if strategy == "binary":
        info("Prediction using binary strategy")
        pred = get_pred(models[0][0], models[0][1]).flatten()
        return torch.where(pred < 0, classes[0], classes[1])

    if strategy == "ovr":
        info("Prediction using OvR strategy")

        scores = torch.empty(
            (X_test.shape[0], len(classes)), device=device, dtype=X_test.dtype
        )

        for i, (weights, mask) in enumerate(models):
            debug(f"Running model {i}")
            scores[:, i] = get_pred(weights, mask).flatten()

        return classes[torch.argmax(scores, dim=1)]

    if strategy == "ovo":
        info("Prediction using OvO strategy")

        votes = torch.zeros(
            (X_test.shape[0], len(classes)), device=device, dtype=torch.int32
        )
        idx = 0

        for i, c1 in enumerate(classes):
            for j, c2 in enumerate(classes[i + 1 :], i + 1):
                debug(f"Running model for classes {c1} and {c2}")

                weights, mask = models[idx]
                pred = get_pred(weights, mask).flatten()
                votes[pred < 0, i] += 1
                votes[pred >= 0, j] += 1
                idx += 1

        return classes[torch.argmax(votes, dim=1)]
