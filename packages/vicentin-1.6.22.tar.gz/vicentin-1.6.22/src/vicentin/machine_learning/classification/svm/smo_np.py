import numpy as np


def SMO(
    X: np.ndarray,
    y: np.ndarray,
    kernel,
    C: float,
    tol: float = 1e-3,
    max_passes: int = 5,
    is_l2: bool = False,
):
    n = X.shape[0]
    alphas = np.zeros(n)
    b = 0.0

    if is_l2:
        C_bound = np.inf
        l2_shift = 1.0 / (2 * C)
    else:
        C_bound = C
        l2_shift = 0.0

    E = -y.astype(float).copy()
    eps = 1e-8

    def take_step(i, j):
        nonlocal b, E

        if i == j:
            return 0

        alpha_i, alpha_j = alphas[i], alphas[j]
        y_i, y_j = y[i], y[j]
        E_i, E_j = E[i], E[j]

        if y_i != y_j:
            L = max(0.0, alpha_j - alpha_i)
            H = min(C_bound, C_bound + alpha_j - alpha_i)
        else:
            L = max(0.0, alpha_i + alpha_j - C_bound)
            H = min(C_bound, alpha_i + alpha_j)

        if abs(L - H) < eps:
            return 0

        row_i = kernel[i]
        row_j = kernel[j]

        K_ii = row_i[i]
        K_jj = row_j[j]
        K_ij = row_i[j]

        eta = 2.0 * K_ij - (K_ii + l2_shift) - (K_jj + l2_shift)

        if eta >= 0:
            return 0

        new_alpha_j = np.clip(alpha_j - (y_j * (E_i - E_j)) / eta, L, H)

        if abs(new_alpha_j - alpha_j) < 1e-7:
            return 0

        new_alpha_i = alpha_i + y_i * y_j * (alpha_j - new_alpha_j)

        delta_alpha_i = new_alpha_i - alpha_i
        delta_alpha_j = new_alpha_j - alpha_j

        b1 = (
            b
            - E_i
            - y_i * delta_alpha_i * (K_ii + l2_shift)
            - y_j * delta_alpha_j * K_ij
        )
        b2 = (
            b
            - E_j
            - y_i * delta_alpha_i * K_ij
            - y_j * delta_alpha_j * (K_jj + l2_shift)
        )

        b_old = b
        if eps < new_alpha_i < C_bound - eps:
            b = b1
        elif eps < new_alpha_j < C_bound - eps:
            b = b2
        else:
            b = (b1 + b2) / 2.0

        E += (
            y_i * delta_alpha_i * row_i
            + y_j * delta_alpha_j * row_j
            + (b - b_old)
        )

        if is_l2:
            E[i] += y_i * delta_alpha_i * l2_shift
            E[j] += y_j * delta_alpha_j * l2_shift

        alphas[i], alphas[j] = new_alpha_i, new_alpha_j
        return 1

    def examine_example(i):
        y_i = y[i]
        alpha_i = alphas[i]
        E_i = E[i]
        r_i = E_i * y_i

        if (r_i < -tol and alpha_i < C_bound - eps) or (
            r_i > tol and alpha_i > eps
        ):
            non_bound_idx = np.where((alphas > eps) & (alphas < C_bound - eps))[
                0
            ]

            if len(non_bound_idx) > 1:
                if E_i >= 0:
                    j = non_bound_idx[np.argmin(E[non_bound_idx])]
                else:
                    j = non_bound_idx[np.argmax(E[non_bound_idx])]
                if take_step(i, j):
                    return 1

                np.random.shuffle(non_bound_idx)
                for j in non_bound_idx:
                    if take_step(i, j):
                        return 1

            all_idx = np.arange(n)
            np.random.shuffle(all_idx)
            for j in all_idx:
                if take_step(i, j):
                    return 1
        return 0

    num_changed = 0
    examine_all = True
    max_iterations = max(2_000, max_passes * 10)
    iterations = 0

    while (num_changed > 0 or examine_all) and iterations < max_iterations:
        num_changed = 0
        if examine_all:
            for i in range(n):
                num_changed += examine_example(i)
        else:
            non_bound_idx = np.where((alphas > eps) & (alphas < C_bound - eps))[
                0
            ]
            for i in non_bound_idx:
                num_changed += examine_example(i)

        if examine_all:
            examine_all = False
        elif num_changed == 0:
            examine_all = True

        iterations += 1

    return alphas * y, b
