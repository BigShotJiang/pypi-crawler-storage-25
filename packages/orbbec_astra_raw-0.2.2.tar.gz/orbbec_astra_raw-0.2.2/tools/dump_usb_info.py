import usb.core
import usb.util
import usb.backend.libusb1

LIBUSB_PATH = "/opt/homebrew/opt/libusb/lib/libusb-1.0.0.dylib"

backend = usb.backend.libusb1.get_backend(find_library=lambda name: LIBUSB_PATH)

if backend is None:
    print("Failed to load libusb backend")
    raise SystemExit(1)

VID = 0x2BC5
PID = 0x0403

dev = usb.core.find(idVendor=VID, idProduct=PID, backend=backend)

if dev is None:
    print("Depth device not found")
    raise SystemExit(1)

print("Found device:")
print(dev)

for cfg in dev:
    print(f"\nConfiguration: {cfg.bConfigurationValue}")
    for intf in cfg:
        print(
            f"  Interface {intf.bInterfaceNumber}, "
            f"AltSetting {intf.bAlternateSetting}, "
            f"Class 0x{intf.bInterfaceClass:02X}, "
            f"SubClass 0x{intf.bInterfaceSubClass:02X}, "
            f"Protocol 0x{intf.bInterfaceProtocol:02X}"
        )
        for ep in intf:
            direction = "IN" if usb.util.endpoint_direction(ep.bEndpointAddress) == usb.util.ENDPOINT_IN else "OUT"
            transfer = usb.util.endpoint_type(ep.bmAttributes)
            transfer_name = {
                usb.util.ENDPOINT_TYPE_CTRL: "CONTROL",
                usb.util.ENDPOINT_TYPE_ISO: "ISO",
                usb.util.ENDPOINT_TYPE_BULK: "BULK",
                usb.util.ENDPOINT_TYPE_INTR: "INTERRUPT",
            }.get(transfer, f"UNKNOWN({transfer})")

            print(
                f"    Endpoint 0x{ep.bEndpointAddress:02X}, "
                f"{direction}, {transfer_name}, "
                f"MaxPacketSize={ep.wMaxPacketSize}"
            )