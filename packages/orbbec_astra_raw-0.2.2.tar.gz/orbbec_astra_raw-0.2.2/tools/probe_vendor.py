"""
Probe the vendor EP0 control transfer path on device 2BC5:0403.

This tests bmRequestType=0x40 (OUT) → 0xC0 (IN), bRequest=0, wValue=0, wIndex=0
which is the transport used by VendorUsbDevicePort in OrbbecSDK v2.

Tries both MG magic (0x4d47) and BRBO magic (0x4F425242) payloads.
Run this before the full driver to confirm whether the transport works.
"""

import sys, struct
sys.path.insert(0, __file__.rsplit("/tools", 1)[0])

import usb.core, usb.util
from astra_depth.platform import get_backend
from astra_depth.protocol import build_request, parse_response, Opcode, MAGIC_REQ, MAGIC_RESP

VID, PID = 0x2BC5, 0x0403
BRBO_MAGIC = 0x4F425242  # legacy "BRBO" request magic (v1 OpenNI protocol)


def hex_dump(data, n=64):
    data = bytes(data)
    s = " ".join(f"{b:02X}" for b in data[:n])
    return s + (f"  ...({len(data)}B)" if len(data) > n else "")


def build_brbo_get_version():
    """Legacy v1 GetVersion: 4B magic | 2B size=0 | 2B opcode=1 | 2B msgId=1 | 2B checksum=0"""
    return struct.pack("<IHHHH", BRBO_MAGIC, 0, 0x0001, 1, 0)


def try_vendor(dev, label, send_pkt, recv_len=64, timeout=3000):
    print(f"\n  [{label}]  send {len(send_pkt)} bytes")
    print(f"    TX: {hex_dump(send_pkt, 16)}")
    try:
        dev.ctrl_transfer(0x40, 0, 0, 0, bytes(send_pkt), timeout)
        print("    OUT (0x40) OK")
    except usb.core.USBError as e:
        print(f"    OUT (0x40) FAILED: {e}")
        return None

    try:
        raw = bytes(dev.ctrl_transfer(0xC0, 0, 0, 0, recv_len, timeout))
        print(f"    IN  (0xC0) OK  →  {hex_dump(raw)}")
        resp = parse_response(raw)
        if resp:
            print(f"    Parsed MG response: opcode=0x{resp['opcode']:02X}  "
                  f"error=0x{resp['error']:04X}  ok={resp['ok']}")
        else:
            # Check for BRBO response magic
            if len(raw) >= 2 and struct.unpack_from("<H", raw)[0] == 0x4252:
                print("    Looks like BRBO response (magic=0x4252 'BR')")
            else:
                print("    Response magic unrecognised — raw data above")
        return raw
    except usb.core.USBError as e:
        print(f"    IN  (0xC0) FAILED: {e}")
        return None


def main():
    print(f"Vendor EP0 Probe — {VID:04X}:{PID:04X}")
    print(f"  MG  magic: 0x{MAGIC_REQ:04X}  →  {hex_dump(struct.pack('<H', MAGIC_REQ))}")
    print(f"  BRBO magic: 0x{BRBO_MAGIC:08X}")

    backend = get_backend()
    dev = usb.core.find(idVendor=VID, idProduct=PID, backend=backend)
    if dev is None:
        sys.exit(f"Device {VID:04X}:{PID:04X} not found")
    print("  Found device")

    try:
        dev.set_configuration()
        print("  set_configuration() OK")
    except usb.core.USBError as e:
        print(f"  set_configuration() skipped: {e}")

    mg_pkt   = build_request(Opcode.GET_PROTOCOL_VER, req_id=1)
    brbo_pkt = build_brbo_get_version()

    print("\n=== MG protocol (magic 0x4D47) ===")
    mg_raw = try_vendor(dev, "GET_PROTOCOL_VER", mg_pkt)

    print("\n=== BRBO protocol (magic BRBO) ===")
    brbo_raw = try_vendor(dev, "GetVersion v1", brbo_pkt)

    # Summary
    print("\n" + "="*60)
    if mg_raw and any(b != 0 for b in mg_raw):
        resp = parse_response(mg_raw)
        if resp:
            print("✓ MG protocol WORKS — driver is using the right payload format")
        else:
            print("? Vendor transport works but MG response magic mismatch")
            print("  Device may use a pre-MG protocol. Check raw bytes above.")
    elif brbo_raw and any(b != 0 for b in brbo_raw):
        print("? BRBO protocol got a non-zero response — may be the right path")
    else:
        print("✗ Both transfers got all-zero or failed responses")
        print("  Device may need a different protocol version or init sequence")

    usb.util.dispose_resources(dev)
    print("Done.")


if __name__ == "__main__":
    main()
