"""
Shows 4 different K values side by side so you can see which one
gives the correct depth scale for your scene.

Also shows raw Y10 grayscale (no conversion) so we can see the actual data.

Run:  python tools/tune_k.py
Press Q to quit, S to save /tmp/tune_k.png
"""
import sys, pathlib, time, threading, queue
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import numpy as np
import cv2

from astra_depth.platform import get_backend
from astra_depth.openni_init import run_init
from astra_depth.frame import FRAME_SYNC, _Y10_SIZE, _unpack_y10
import usb.core, usb.util

backend = get_backend()
dev = usb.core.find(idVendor=0x2BC5, idProduct=0x0403, backend=backend)
if dev is None:
    sys.exit("Camera not found")
try: dev.set_configuration()
except: pass
try: usb.util.claim_interface(dev, 0)
except: pass

print("Init…")
run_init(dev)

frame_q = queue.Queue(maxsize=2)
SYNC = FRAME_SYNC

def _reader():
    buf = b''
    while True:
        try:
            chunk = bytes(dev.read(0x81, 65536, 500))
            if chunk: buf += chunk
        except Exception as e:
            if getattr(e,'errno',None)==32 or 'pipe' in str(e).lower():
                try: usb.util.clear_halt(dev, 0x81)
                except: run_init(dev); buf=b''
            time.sleep(0.005); continue
        while True:
            idx = buf.find(SYNC)
            if idx < 0:
                if len(buf) > 3: buf = buf[-3:]
                break
            if idx > 0: buf = buf[idx:]
            if len(buf) < 4 + _Y10_SIZE: break
            try: frame_q.put_nowait(buf[4:4+_Y10_SIZE])
            except queue.Full: pass
            buf = buf[4+_Y10_SIZE:]

threading.Thread(target=_reader, daemon=True).start()

PW, PH = 320, 240

def make_panel(disp, K, title):
    """Convert Y10 disparity with given K to depth mm, show JET colormap."""
    depth = np.zeros(disp.shape, np.float32)
    v = disp > 0
    if v.any() and K > 0:
        depth[v] = K / disp[v].astype(np.float32)
    valid = (depth >= 300) & (depth <= 5000)
    d8 = np.zeros(disp.shape, np.uint8)
    if valid.any():
        lo, hi = 300.0, 5000.0
        d8[valid] = np.clip(255-(depth[valid]-lo)*255/(hi-lo), 0, 255).astype(np.uint8)
    col = cv2.applyColorMap(cv2.dilate(d8, cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(7,7))),
                            cv2.COLORMAP_JET)
    col[d8 == 0] = 0
    col = cv2.resize(col, (PW, PH))
    pct = 100*valid.sum()/disp.size
    mn  = int(depth[valid].min()) if valid.any() else 0
    mx  = int(depth[valid].max()) if valid.any() else 0
    cv2.rectangle(col,(0,0),(PW-1,28),(0,0,0),-1)
    cv2.putText(col, title, (4,14), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,220,180), 1)
    cv2.putText(col, f"{mn}-{mx}mm {pct:.0f}%", (4,26), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (150,150,150), 1)
    return col

def raw_panel(disp):
    """Show raw Y10 grayscale: high disparity (close) = bright."""
    mx = int(disp.max())
    u8 = (disp.astype(np.float32)*255/mx).astype(np.uint8) if mx else np.zeros((480,640),np.uint8)
    col = cv2.cvtColor(u8, cv2.COLOR_GRAY2BGR)
    col = cv2.resize(col, (PW, PH))
    cv2.putText(col, f"Raw Y10 (close=bright)", (4,14), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,220,180), 1)
    cv2.putText(col, f"max={mx}  nonzero={(disp>0).sum()*100//disp.size}%",
                (4,26), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (150,150,150), 1)
    return col

print("Streaming. Q=quit  S=save  (show 4 K values + raw)")
fc = 0
while True:
    try:
        raw = frame_q.get(timeout=2.0)
    except queue.Empty:
        print("waiting…"); continue

    fc += 1
    disp = _unpack_y10(raw)

    row0 = np.hstack([
        raw_panel(disp),
        make_panel(disp,  85_500, "K=85k (sub×2)"),
        make_panel(disp, 171_000, "K=171k (sub×4)"),
        make_panel(disp, 342_000, "K=342k (sub×8)"),
    ])
    row1_label = np.zeros((PH, PW*4, 3), np.uint8)
    cv2.putText(row1_label, f"Frame #{fc}  —  Point camera at your face from 1m away",
                (8, PH//2), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (200,200,200), 1)
    cv2.putText(row1_label, "The correct K shows red face, blue/green background",
                (8, PH//2+24), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (150,150,150), 1)

    grid = np.vstack([row0, row1_label])
    cv2.imshow("K Tuning — Q quit  S save", grid)
    key = cv2.waitKey(1) & 0xFF
    if key == ord('q'): break
    if key == ord('s'):
        cv2.imwrite('/tmp/tune_k.png', grid)
        print(f"Saved /tmp/tune_k.png")

cv2.destroyAllWindows()
usb.util.dispose_resources(dev)
