"""
Parse the UVC VideoControl class-specific descriptors on 2BC5:0501
to find the actual Extension Unit (XU) unit IDs and GUIDs.

Must be run as root on macOS:
  sudo .venv/bin/python tools/dump_uvc_xu.py

The unit IDs found here are what we need to pass to probe_xu_unit.py.
"""

import sys, struct
sys.path.insert(0, __file__.rsplit("/tools", 1)[0])

import usb.core, usb.util
from astra_depth.platform import get_backend

VID, PID = 0x2BC5, 0x0501

# UVC class-specific descriptor subtypes
_VC_SUBTYPES = {
    0x01: "VC_HEADER",
    0x02: "INPUT_TERMINAL",
    0x03: "OUTPUT_TERMINAL",
    0x04: "SELECTOR_UNIT",
    0x05: "PROCESSING_UNIT",
    0x06: "EXTENSION_UNIT",
    0x07: "ENCODING_UNIT",
}

# Known Orbbec XU GUIDs
_KNOWN_GUIDS = {
    bytes.fromhex("a15157a5c5f34e5a8d5a6854b8fa2716"): "OB_COMMON_XU (v2 SDK unit 4)",
    bytes.fromhex("cb6c60c94c594da25caf47cc0c465995"): "OB_G330_XU (v2 SDK unit 3)",
}


def format_guid(raw_bytes):
    """Format 16-byte GUID in Windows mixed-endian notation."""
    d1 = struct.unpack_from("<I", raw_bytes, 0)[0]
    d2 = struct.unpack_from("<H", raw_bytes, 4)[0]
    d3 = struct.unpack_from("<H", raw_bytes, 6)[0]
    d4 = raw_bytes[8:16].hex()
    return f"{{{d1:08X}-{d2:04X}-{d3:04X}-{d4[:4].upper()}-{d4[4:].upper()}}}"


def main():
    print(f"Parsing UVC descriptors for {VID:04X}:{PID:04X}")

    backend = get_backend()
    dev = usb.core.find(idVendor=VID, idProduct=PID, backend=backend)
    if dev is None:
        sys.exit(f"Device {VID:04X}:{PID:04X} not found")

    print("Found device")
    dev.set_configuration()

    for iface_idx in [0]:
        try:
            dev.detach_kernel_driver(iface_idx)
            print(f"detach_kernel_driver({iface_idx}) OK")
        except Exception:
            pass

    # Read full configuration descriptor (includes class-specific embedded descriptors)
    try:
        config_desc = bytes(dev.ctrl_transfer(0x80, 0x06, 0x0200, 0, 4096, timeout=5000))
        print(f"Config descriptor: {len(config_desc)} bytes\n")
    except Exception as e:
        sys.exit(f"Could not read config descriptor: {e}")

    xu_units = []
    i = 0
    while i < len(config_desc) - 2:
        bLength    = config_desc[i]
        bDescType  = config_desc[i + 1]
        bSubType   = config_desc[i + 2] if len(config_desc) > i + 2 else 0

        if bLength == 0:
            break

        if bDescType == 0x24:  # CS_INTERFACE
            name = _VC_SUBTYPES.get(bSubType, f"UNKNOWN_0x{bSubType:02X}")
            if bSubType == 0x06:  # EXTENSION_UNIT
                unit_id       = config_desc[i + 3]
                guid_raw      = bytes(config_desc[i + 4 : i + 20])
                bNumControls  = config_desc[i + 20] if i + 20 < len(config_desc) else 0
                bNrInPins     = config_desc[i + 21] if i + 21 < len(config_desc) else 0

                known = _KNOWN_GUIDS.get(guid_raw, "UNKNOWN")
                print(f"  EXTENSION_UNIT  unit_id={unit_id}")
                print(f"    GUID bytes:  {guid_raw.hex()}")
                print(f"    GUID:        {format_guid(guid_raw)}")
                print(f"    Controls:    {bNumControls}   InPins: {bNrInPins}")
                print(f"    Known as:    {known}")
                xu_units.append((unit_id, guid_raw))
            elif bSubType in (0x02, 0x03, 0x04, 0x05):
                unit_id = config_desc[i + 3] if i + 3 < len(config_desc) else 0
                print(f"  {name}  id={unit_id}")

        i += bLength

    usb.util.dispose_resources(dev)

    print(f"\n{'='*60}")
    print(f"Found {len(xu_units)} Extension Unit(s):")
    for uid, guid in xu_units:
        print(f"  unit_id={uid}  GUID={format_guid(guid)}")

    if xu_units:
        print(f"\nNext step:")
        print(f"  sudo .venv/bin/python tools/probe_xu_unit.py {xu_units[0][0]}")


if __name__ == "__main__":
    main()
