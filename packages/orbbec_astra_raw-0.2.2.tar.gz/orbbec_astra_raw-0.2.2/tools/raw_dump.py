"""
Dump ~3 MB of raw bulk bytes to /tmp/astra_raw.bin then analyze it.

This answers two questions definitively:
1. Are there frame headers / sync bytes we should be parsing?
2. Does Y11 (422400) or Y16 (614400) produce a better image?

Run:  python tools/raw_dump.py
"""
import sys, pathlib, time
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import numpy as np

from astra_depth.platform import get_backend
from astra_depth.openni_init import run_init, _Y11_FRAME
import usb.core, usb.util

# ── Open + init ────────────────────────────────────────────────────────────────
backend = get_backend()
dev = usb.core.find(idVendor=0x2BC5, idProduct=0x0403, backend=backend)
if dev is None:
    sys.exit("Camera not found")
try:
    dev.set_configuration()
except Exception:
    pass
try:
    usb.util.claim_interface(dev, 0)
except Exception:
    pass

print("Init…")
run_init(dev)

# ── Capture 3 MB raw bytes immediately ────────────────────────────────────────
TARGET = 3 * 1024 * 1024   # 3 MB
print(f"Capturing {TARGET//1024//1024} MB of raw bytes…")
buf = b''
deadline = time.monotonic() + 15
while len(buf) < TARGET and time.monotonic() < deadline:
    try:
        chunk = bytes(dev.read(0x81, 65536, 1000))
        if chunk:
            buf += chunk
    except Exception:
        pass

usb.util.dispose_resources(dev)
print(f"Got {len(buf)} bytes")

# ── Save raw bytes ─────────────────────────────────────────────────────────────
with open('/tmp/astra_raw.bin', 'wb') as f:
    f.write(buf)
print("Saved to /tmp/astra_raw.bin")

# ── Scan for repeated sync patterns ───────────────────────────────────────────
print("\n--- First 64 bytes (hex) ---")
print(' '.join(f'{b:02x}' for b in buf[:64]))

print("\n--- Checking for frame markers ---")
# Check if any 4-byte sequence repeats at regular intervals (= frame header magic)
candidates = {}
window = 3_000_000  // 2
step   = 1000
for pos in range(0, min(len(buf)-4, window), step):
    magic = buf[pos:pos+4]
    if magic not in candidates:
        candidates[magic] = []
    candidates[magic].append(pos)

# Find sequences that repeat at suspiciously regular intervals
print("Sequences repeating at regular intervals (possible frame headers):")
found_any = False
for magic, positions in candidates.items():
    if len(positions) < 3:
        continue
    diffs = [positions[i+1]-positions[i] for i in range(len(positions)-1)]
    avg   = sum(diffs)/len(diffs)
    var   = max(diffs)-min(diffs)
    if var < avg * 0.05 and 300_000 < avg < 700_000:  # tight clustering, frame-size range
        print(f"  {magic.hex()} appears every ~{avg:.0f} bytes ({len(positions)} times) → likely frame header!")
        found_any = True

if not found_any:
    print("  None found — stream is likely raw pixels with no frame headers")

# ── Try Y11 (422400) vs Y16 (614400) decoding ─────────────────────────────────
try:
    import cv2
    PIXELS = 640 * 480

    def try_y11_le(data, off=0):
        """Little-endian Y11"""
        raw = np.frombuffer(data[off:off+_Y11_FRAME], dtype=np.uint8).astype(np.uint32)
        idx = np.arange(PIXELS, dtype=np.uint32)
        bp  = idx * 11;  bi = (bp>>3).astype(np.intp);  bo = (bp&7).astype(np.uint32)
        n = len(raw)
        b0=raw[np.minimum(bi,n-1)]; b1=raw[np.minimum(bi+1,n-1)]; b2=raw[np.minimum(bi+2,n-1)]
        combined = b0|(b1<<8)|(b2<<16)
        return ((combined>>bo)&0x7FF).astype(np.uint16).reshape(480,640)

    def try_y11_be(data, off=0):
        """Big-endian Y11 (matches SDK y11ToY16)"""
        raw = np.frombuffer(data[off:off+_Y11_FRAME], dtype=np.uint8).astype(np.uint32)
        idx = np.arange(PIXELS, dtype=np.uint32)
        bp  = idx * 11;  bi = (bp>>3).astype(np.intp);  bo = (bp&7).astype(np.uint32)
        n = len(raw)
        b0=raw[np.minimum(bi,n-1)]; b1=raw[np.minimum(bi+1,n-1)]; b2=raw[np.minimum(bi+2,n-1)]
        combined = (b0<<16)|(b1<<8)|b2
        return ((combined>>(13-bo))&0x7FF).astype(np.uint16).reshape(480,640)

    def try_y16(data, off=0):
        """Y16 — 614400 bytes/frame, 2 bytes/pixel"""
        Y16 = 614400
        return np.frombuffer(data[off:off+Y16], dtype='<u2').reshape(480,640)

    def show(name, frame):
        valid = (frame>0)&(frame<=2047)
        pct   = 100*valid.sum()/frame.size
        mn    = int(frame[valid].min()) if valid.any() else 0
        mx    = int(frame[valid].max()) if valid.any() else 0
        print(f"  {name}: valid={pct:.1f}%  range={mn}-{mx}mm  p50={np.median(frame[valid]).astype(int) if valid.any() else 0}mm")
        norm = np.zeros(frame.shape,np.float32)
        if valid.any():
            lo,hi = float(frame[valid].min()), float(frame[valid].max())
            if hi>lo: norm[valid]=1-(frame[valid].astype(np.float32)-lo)/(hi-lo)
        img = cv2.applyColorMap((norm*255).astype(np.uint8),cv2.COLORMAP_JET)
        img[~valid]=0
        return img

    print("\n--- Decoding comparison (offset 0) ---")
    imgs = []
    for name, fn in [("Y11-LE", try_y11_le), ("Y11-BE", try_y11_be)]:
        frame = fn(buf, 0)
        img   = show(name, frame)
        imgs.append((name, img))

    if len(buf) >= 614400:
        frame = try_y16(buf, 0)
        img   = show("Y16   ", frame)
        imgs.append(("Y16", img))

    print("\n--- Decoding comparison (offset 422400 = skip 1 Y11 frame) ---")
    for name, fn in [("Y11-LE+1", try_y11_le), ("Y11-BE+1", try_y11_be)]:
        frame = fn(buf, _Y11_FRAME)
        show(name, frame)

    # Save comparison images
    panels = []
    for name, img in imgs:
        p = cv2.resize(img, (640,480))
        cv2.putText(p, name, (8,24), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)
        panels.append(p)
    combined = np.hstack(panels)
    cv2.imwrite('/tmp/astra_decode_compare.png', combined)
    print("\nSaved comparison to /tmp/astra_decode_compare.png")
    print("Open that file to visually compare Y11-LE vs Y11-BE vs Y16.")

except ImportError:
    print("OpenCV not available — skipping image comparison")
