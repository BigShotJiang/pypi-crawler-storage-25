import usb.core
import usb.util
import usb.backend.libusb1

LIBUSB_PATH = "/opt/homebrew/opt/libusb/lib/libusb-1.0.0.dylib"
backend = usb.backend.libusb1.get_backend(find_library=lambda name: LIBUSB_PATH)

if backend is None:
    raise SystemExit("Failed to load libusb backend")

TARGETS = [
    (0x2BC5, 0x0403, "Depth/IR device"),
    (0x2BC5, 0x0501, "Color/UVC device"),
]

for vid, pid, label in TARGETS:
    print("\n" + "=" * 80)
    print(f"{label}: {vid:04X}:{pid:04X}")
    print("=" * 80)

    dev = usb.core.find(idVendor=vid, idProduct=pid, backend=backend)

    if dev is None:
        print("Not found")
        continue

    print(dev)

    for cfg in dev:
        print(f"\nConfiguration: {cfg.bConfigurationValue}")
        for intf in cfg:
            print(
                f"  Interface {intf.bInterfaceNumber}, "
                f"AltSetting {intf.bAlternateSetting}, "
                f"Class 0x{intf.bInterfaceClass:02X}, "
                f"SubClass 0x{intf.bInterfaceSubClass:02X}, "
                f"Protocol 0x{intf.bInterfaceProtocol:02X}"
            )
            for ep in intf:
                direction = "IN" if usb.util.endpoint_direction(ep.bEndpointAddress) == usb.util.ENDPOINT_IN else "OUT"
                transfer = usb.util.endpoint_type(ep.bmAttributes)
                transfer_name = {
                    usb.util.ENDPOINT_TYPE_CTRL: "CONTROL",
                    usb.util.ENDPOINT_TYPE_ISO: "ISO",
                    usb.util.ENDPOINT_TYPE_BULK: "BULK",
                    usb.util.ENDPOINT_TYPE_INTR: "INTERRUPT",
                }.get(transfer, f"UNKNOWN({transfer})")

                print(
                    f"    Endpoint 0x{ep.bEndpointAddress:02X}, "
                    f"{direction}, {transfer_name}, "
                    f"MaxPacketSize={ep.wMaxPacketSize}"
                )