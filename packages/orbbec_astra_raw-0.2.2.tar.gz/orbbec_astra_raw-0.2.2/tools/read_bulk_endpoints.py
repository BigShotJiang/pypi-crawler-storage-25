print("SCRIPT STARTED")

import time
import usb.core
import usb.util
import usb.backend.libusb1

print("Imports OK")

LIBUSB_PATH = "/opt/homebrew/opt/libusb/lib/libusb-1.0.0.dylib"
VID = 0x2BC5
PID = 0x0403

backend = usb.backend.libusb1.get_backend(find_library=lambda name: LIBUSB_PATH)
print("Backend object:", backend)

if backend is None:
    raise SystemExit("Failed to load libusb backend")

def hex_bytes(data, limit=64):
    data = bytes(data)
    shown = data[:limit]
    s = " ".join(f"{b:02X}" for b in shown)
    if len(data) > limit:
        s += f" ... ({len(data)} bytes total)"
    return s

print("Looking for device...")
dev = usb.core.find(idVendor=VID, idProduct=PID, backend=backend)
print("Device object:", dev)

if dev is None:
    raise SystemExit("Device not found")

print("Found device")

try:
    dev.set_configuration()
    print("set_configuration() OK")
except Exception as e:
    print("set_configuration() failed:", repr(e))

print("Getting active configuration...")
cfg = dev.get_active_configuration()
print("Active configuration:", cfg)

try:
    intf = cfg[(0, 0)]
    print("Interface (0,0):", intf)
except Exception as e:
    print("Failed to access interface (0,0):", repr(e))
    raise

try:
    usb.util.claim_interface(dev, 0)
    print("claim_interface(0) OK")
except Exception as e:
    print("claim_interface(0) failed:", repr(e))

for ep in [0x81, 0x82]:
    print(f"\n--- Probing endpoint 0x{ep:02X} ---")
    for i in range(5):
        print(f"Attempt {i+1} on 0x{ep:02X}")
        try:
            data = dev.read(ep, 512, timeout=500)
            print(f"Read {len(data)} bytes from 0x{ep:02X}: {hex_bytes(data)}")
        except usb.core.USBTimeoutError:
            print(f"Read timeout on 0x{ep:02X}")
        except usb.core.USBError as e:
            print(f"USBError on 0x{ep:02X}: {repr(e)}")
        except Exception as e:
            print(f"Other error on 0x{ep:02X}: {repr(e)}")
        time.sleep(0.1)

print("Releasing interface...")
try:
    usb.util.release_interface(dev, 0)
    print("release_interface OK")
except Exception as e:
    print("release_interface failed:", repr(e))

print("Disposing resources...")
usb.util.dispose_resources(dev)
print("Done")
