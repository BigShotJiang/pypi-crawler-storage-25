"""
Probe whether UVC Extension Unit (XU) control transfers reach the Orbbec devices.

This is the critical first test before using the full driver.

Tests performed:
  1. Open UVC device (2BC5:0501) — try GET_PROTOCOL_VER via XU on interface 0
  2. Open depth device (2BC5:0403) — try same command on interface 0
  3. For each: try without claiming, then with claiming (requires detach_kernel_driver)
  4. Also try legacy BRBO magic to detect OpenNI-era firmware
  5. Try probing the XU unit on device 0x0501 interface 1 (VideoStreaming)

A successful XU response confirms the control path is usable.
Any response (even an error code) proves the XU endpoint is reachable.

Expected outcome:
  - At least one combination returns non-zero bytes from xu_get
  - Ideally: parse_response() returns a valid dict (magic=0x4252)
"""

import sys
import struct
import usb.core
import usb.util

sys.path.insert(0, __file__.rsplit("/tools", 1)[0])

from astra_depth.platform import get_backend
from astra_depth.uvc_xu import xu_set, xu_get, XU_UNIT_ID
from astra_depth.protocol import (
    build_request, parse_response, Opcode,
    MAGIC_REQ, MAGIC_RESP,
)

VID       = 0x2BC5
PID_UVC   = 0x0501
PID_DEPTH = 0x0403

# Legacy OpenNI magic (ASTRA_PRO_DRIVER_RESEARCH.md §3.2)
MAGIC_LEGACY_REQ = 0x4F425242  # "OBRB" — 4-byte magic for v1 protocol


def hex_dump(data, limit=64):
    data = bytes(data)
    s = " ".join(f"{b:02X}" for b in data[:limit])
    if len(data) > limit:
        s += f"  ... ({len(data)} total bytes)"
    return s


def build_legacy_get_version():
    """OpenNI v1 GetVersion command (opcode 0x0001, magic BRBO)."""
    return struct.pack('<IHHHH', MAGIC_LEGACY_REQ, 0, 0x0001, 1, 0)


def try_xu(dev, iface, label, req_pkt, recv_len=64):
    print(f"\n  [{label}] XU on interface {iface}, unit {XU_UNIT_ID}")
    try:
        xu_set(dev, req_pkt, iface=iface, timeout=2000)
        print(f"    xu_set OK ({len(req_pkt)} bytes sent)")
    except usb.core.USBError as e:
        print(f"    xu_set FAILED: {e}")
        return None

    try:
        raw = xu_get(dev, recv_len, iface=iface, timeout=2000)
        print(f"    xu_get OK → {hex_dump(raw)}")
        resp = parse_response(raw)
        if resp:
            print(f"    Parsed response: opcode={resp['opcode']:#04x}  "
                  f"error={resp['error']:#06x}  ok={resp['ok']}")
        else:
            print("    Raw bytes don't match MAGIC_RESP — device may use different protocol")
        return raw
    except usb.core.USBError as e:
        print(f"    xu_get FAILED: {e}")
        return None


def probe_device(pid, label, backend):
    print(f"\n{'='*60}")
    print(f"  {label}: {VID:04X}:{pid:04X}")
    print(f"{'='*60}")

    dev = usb.core.find(idVendor=VID, idProduct=pid, backend=backend)
    if dev is None:
        print("  NOT FOUND")
        return

    print("  Found device")

    try:
        dev.set_configuration()
        print("  set_configuration() OK")
    except usb.core.USBError as e:
        print(f"  set_configuration() skipped: {e}")

    # Build test packets
    v2_pkt = build_request(Opcode.GET_PROTOCOL_VER, req_id=1)
    legacy_pkt = build_legacy_get_version()

    for iface in [0, 1]:
        print(f"\n  --- Without claiming interface {iface} ---")
        try_xu(dev, iface, "v2-MG-proto",     v2_pkt,     recv_len=64)
        try_xu(dev, iface, "v1-BRBO-proto",   legacy_pkt, recv_len=64)

        print(f"\n  --- After claiming interface {iface} ---")
        claimed = False
        try:
            if dev.is_kernel_driver_active(iface):
                dev.detach_kernel_driver(iface)
                print(f"  detach_kernel_driver({iface}) OK")
            usb.util.claim_interface(dev, iface)
            claimed = True
            print(f"  claim_interface({iface}) OK")
        except usb.core.USBError as e:
            print(f"  claim_interface({iface}) FAILED: {e}")

        if claimed:
            try_xu(dev, iface, "v2-MG-proto",   v2_pkt,     recv_len=64)
            try_xu(dev, iface, "v1-BRBO-proto", legacy_pkt, recv_len=64)
            try:
                usb.util.release_interface(dev, iface)
            except Exception:
                pass

    usb.util.dispose_resources(dev)


def main():
    print("Astra Pro XU Probe")
    print(f"  Request magic (v2): 0x{MAGIC_REQ:04X}  →  bytes {hex_dump(struct.pack('<H', MAGIC_REQ))}")
    print(f"  Response magic:     0x{MAGIC_RESP:04X}  →  bytes {hex_dump(struct.pack('<H', MAGIC_RESP))}")

    backend = get_backend()
    if backend is None:
        print("ERROR: Could not load libusb backend")
        sys.exit(1)

    probe_device(PID_UVC,   "Color/UVC device  ", backend)
    probe_device(PID_DEPTH, "Depth/IR device   ", backend)

    print(f"\n{'='*60}")
    print("Done.")
    print("If both xu_set and xu_get succeeded on any device/interface,")
    print("the XU control path is usable — run the full driver next.")
    print("If all failed, the host OS is blocking class-specific control transfers.")


if __name__ == "__main__":
    main()
