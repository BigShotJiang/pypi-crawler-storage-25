"""
Shows all available cameras side-by-side so you can identify which
index is the Orbbec Astra Pro color camera.

Run:  python tools/scan_color.py
Press Q to quit.  The Astra Pro color camera is the one showing the
same scene as the depth sensor (not your MacBook's front FaceTime camera).
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))

import numpy as np
import cv2

PW, PH = 480, 360   # display size per panel

caps = {}
for i in range(8):
    cap = cv2.VideoCapture(i)
    if cap.isOpened():
        # Try to set max resolution so we can see native capabilities
        cap.set(cv2.CAP_PROP_FRAME_WIDTH,  1280)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT,  960)
        w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        print(f"Camera {i}: {w}×{h}")
        caps[i] = cap
    else:
        cap.release()

if not caps:
    sys.exit("No cameras found")

print(f"\nFound cameras: {list(caps.keys())}")
print("The Astra Pro color camera supports 1280×960 (most built-in cameras don't).")
print("Press Q to quit.\n")

while True:
    panels = []
    for idx, cap in caps.items():
        ok, frame = cap.read()
        if not ok:
            frame = np.zeros((PH, PW, 3), np.uint8)
        else:
            frame = cv2.resize(frame, (PW, PH))
        w_actual = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        h_actual = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        cv2.rectangle(frame, (0,0), (PW-1, 26), (0,0,0), -1)
        cv2.putText(frame, f"Camera {idx}  ({w_actual}x{h_actual})",
                    (6, 18), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 220, 180), 1)
        panels.append(frame)

    # Arrange in a row
    grid = np.hstack(panels)
    cv2.imshow("Camera Scanner — Q to quit", grid)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

for cap in caps.values():
    cap.release()
cv2.destroyAllWindows()
