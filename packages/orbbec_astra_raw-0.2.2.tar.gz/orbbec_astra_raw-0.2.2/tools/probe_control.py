import usb.core
import usb.util
import usb.backend.libusb1

LIBUSB_PATH = "/opt/homebrew/opt/libusb/lib/libusb-1.0.0.dylib"
VID = 0x2BC5
PID = 0x0403

backend = usb.backend.libusb1.get_backend(find_library=lambda name: LIBUSB_PATH)
if backend is None:
    raise SystemExit("Failed to load libusb backend")

def hex_bytes(data, limit=64):
    data = bytes(data)
    shown = data[:limit]
    s = " ".join(f"{b:02X}" for b in shown)
    if len(data) > limit:
        s += f" ... ({len(data)} bytes total)"
    return s

dev = usb.core.find(idVendor=VID, idProduct=PID, backend=backend)
if dev is None:
    raise SystemExit("Device not found")

print("Found device")

try:
    dev.set_configuration()
    print("set_configuration() OK")
except Exception as e:
    print("set_configuration() failed:", repr(e))

try:
    usb.util.claim_interface(dev, 0)
    print("claim_interface(0) OK")
except Exception as e:
    print("claim_interface(0) failed:", repr(e))

tests = [
    ("STD_GET_STATUS_DEVICE", 0x80, 0x00, 0x0000, 0x0000, 2),
    ("STD_GET_DESCRIPTOR_DEVICE", 0x80, 0x06, 0x0100, 0x0000, 18),
    ("VENDOR_IN_0", 0xC0, 0x00, 0x0000, 0x0000, 64),
    ("VENDOR_IN_1", 0xC0, 0x01, 0x0000, 0x0000, 64),
    ("VENDOR_IN_2", 0xC0, 0x02, 0x0000, 0x0000, 64),
    ("VENDOR_IN_3", 0xC0, 0x03, 0x0000, 0x0000, 64),
    ("VENDOR_IN_4", 0xC0, 0x04, 0x0000, 0x0000, 64),
]

for name, bmRequestType, bRequest, wValue, wIndex, wLength in tests:
    print(f"\n=== {name} ===")
    print(
        f"bmRequestType=0x{bmRequestType:02X}, "
        f"bRequest=0x{bRequest:02X}, "
        f"wValue=0x{wValue:04X}, "
        f"wIndex=0x{wIndex:04X}, "
        f"wLength={wLength}"
    )
    try:
        data = dev.ctrl_transfer(
            bmRequestType=bmRequestType,
            bRequest=bRequest,
            wValue=wValue,
            wIndex=wIndex,
            data_or_wLength=wLength,
            timeout=1000,
        )
        print("Response:", hex_bytes(data))
    except usb.core.USBError as e:
        print("USBError:", repr(e))
    except Exception as e:
        print("Other error:", repr(e))

print("\nReleasing interface...")
try:
    usb.util.release_interface(dev, 0)
except Exception:
    pass

usb.util.dispose_resources(dev)
print("Done")