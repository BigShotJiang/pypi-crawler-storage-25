"""
Probe XU on device 2BC5:0501 with a SPECIFIC unit ID found from the UVC descriptor.

Usage: sudo .venv/bin/python tools/probe_xu_unit.py <unit_id>
Example: sudo .venv/bin/python tools/probe_xu_unit.py 3

Run probe_xu.py first (as sudo) to get the STALL, then run this script after
finding the correct unit_id from the UVC VideoControl class-specific descriptor.
"""

import sys, struct
sys.path.insert(0, __file__.rsplit("/tools", 1)[0])

import usb.core, usb.util
from astra_depth.platform import get_backend
from astra_depth.protocol import build_request, parse_response, Opcode, build_set_property, Property

VID, PID = 0x2BC5, 0x0501

UNIT_ID = int(sys.argv[1]) if len(sys.argv) > 1 else 3

# Try all control selectors 1-8 (the Astra Pro XU units have 8 and 24 controls)
# Also include Orbbec v2 SDK control IDs for reference
_CTRL_IDS_TO_TRY = list(range(1, 9))

_CTRL_BUFSIZES = {1: 512, 2: 64, 3: 1024}  # v2 SDK mapping; for unknown XUs use 64


def hex_dump(data, n=64):
    data = bytes(data)
    return " ".join(f"{b:02X}" for b in data[:n]) + (f"  ...({len(data)}B)" if len(data) > n else "")


def xu_set(dev, ctrl_id, payload, iface=0, unit=UNIT_ID, timeout=3000):
    bufsize = _CTRL_BUFSIZES.get(ctrl_id, 64)
    padded = bytes(payload).ljust(bufsize, b'\x00')[:bufsize]
    dev.ctrl_transfer(0x21, 0x01, ctrl_id << 8, (unit << 8) | iface, padded, timeout)


def xu_get(dev, ctrl_id, iface=0, unit=UNIT_ID, timeout=3000):
    bufsize = _CTRL_BUFSIZES.get(ctrl_id, 64)
    return bytes(dev.ctrl_transfer(0xa1, 0x81, ctrl_id << 8,
                                   (unit << 8) | iface, bufsize, timeout))


def main():
    print(f"Testing XU unit_id={UNIT_ID} on {VID:04X}:{PID:04X}")
    backend = get_backend()
    dev = usb.core.find(idVendor=VID, idProduct=PID, backend=backend)
    if dev is None:
        sys.exit("Device not found")

    dev.set_configuration()
    for iface in [0, 1]:
        try:
            dev.detach_kernel_driver(iface)
            print(f"detach_kernel_driver({iface}) OK")
        except Exception:
            pass
        try:
            usb.util.claim_interface(dev, iface)
            print(f"claim_interface({iface}) OK")
        except Exception as e:
            print(f"claim_interface({iface}) failed: {e}")

    req = build_request(Opcode.GET_PROTOCOL_VER, req_id=1)
    print(f"\nTesting GET_PROTOCOL_VER via XU unit={UNIT_ID} (all ctrl selectors 1-8)")
    working = []
    for ctrl_id in _CTRL_IDS_TO_TRY:
        bufsize = _CTRL_BUFSIZES.get(ctrl_id, 64)
        for iface in [0]:
            try:
                xu_set(dev, ctrl_id, req, iface=iface)
                raw = xu_get(dev, ctrl_id, iface=iface)
                resp = parse_response(raw)
                if resp:
                    print(f"  ctrl={ctrl_id} buf={bufsize} iface={iface}: *** MG RESPONSE! *** "
                          f"opcode=0x{resp['opcode']:02X} error=0x{resp['error']:04X}")
                    working.append((ctrl_id, iface))
                else:
                    nz = [i for i, b in enumerate(raw) if b != 0]
                    if nz:
                        print(f"  ctrl={ctrl_id} buf={bufsize} iface={iface}: non-zero data at {nz[:6]} → {hex_dump(raw, 24)}")
                    else:
                        print(f"  ctrl={ctrl_id} buf={bufsize} iface={iface}: all zeros")
            except usb.core.USBError as e:
                errno = getattr(e, 'errno', '?')
                print(f"  ctrl={ctrl_id} buf={bufsize} iface={iface}: {type(e).__name__}({errno}) {e}")

    if working:
        print(f"\n✓ Working: {working}")
        ctrl_id, iface = working[0]
        print(f"\nTrying START_DEPTH_STREAM via ctrl={ctrl_id} iface={iface}...")
        pkt = build_set_property(Property.START_DEPTH_STREAM, 1, req_id=2)
        try:
            xu_set(dev, ctrl_id, pkt, iface=iface)
            raw = xu_get(dev, ctrl_id, iface=iface)
            resp = parse_response(raw)
            print(f"  START_DEPTH_STREAM: ok={resp['ok'] if resp else None} → {hex_dump(raw, 12)}")

            import time; time.sleep(0.5)
            print("\nChecking EP 0x82 on 2BC5:0403 for bulk depth data...")
            depth_dev = usb.core.find(idVendor=0x2BC5, idProduct=0x0403, backend=get_backend())
            if depth_dev:
                depth_dev.set_configuration()
                try: usb.util.claim_interface(depth_dev, 0)
                except: pass
                for attempt in range(5):
                    try:
                        data = bytes(depth_dev.read(0x82, 65536, timeout=1000))
                        print(f"  *** EP 0x82 GOT {len(data)} bytes! *** {hex_dump(data, 32)}")
                        break
                    except usb.core.USBTimeoutError:
                        print(f"  Attempt {attempt+1}: EP 0x82 timeout")
                usb.util.dispose_resources(depth_dev)
        except usb.core.USBError as e:
            print(f"  FAILED: {e}")
    else:
        print("\n✗ No working ctrl/iface combination found.")

    usb.util.dispose_resources(dev)


if __name__ == "__main__":
    main()
