/*
 * Minimal Orbbec depth capture — no OpenCV, no display.
 * Starts depth pipeline, captures 3 frames, prints raw hex, exits.
 *
 * Build (from astra-driver root on Linux x64):
 *   g++ -std=c++11 tools/minimal_depth.cpp \
 *       -I SDKs/OrbbecSDK/include \
 *       -L SDKs/OrbbecSDK/lib/linux_x64 \
 *       -lOrbbecSDK -Wl,-rpath,SDKs/OrbbecSDK/lib/linux_x64 \
 *       -o minimal_depth
 *
 * Run (with usbmon capturing in another terminal):
 *   sudo modprobe usbmon
 *   sudo ./minimal_depth
 */

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include "libobsensor/h/Context.h"
#include "libobsensor/h/Device.h"
#include "libobsensor/h/Pipeline.h"
#include "libobsensor/h/Frame.h"
#include "libobsensor/h/Error.h"

static void check(ob_error *err, const char *label) {
    if (err) {
        fprintf(stderr, "ERROR [%s]: %s\n", label, ob_error_get_message(err));
        ob_delete_error(err);
        exit(1);
    }
}

int main() {
    ob_error *err = nullptr;

    fprintf(stderr, "Creating context...\n");
    ob_context *ctx = ob_create_context(&err);
    check(err, "create_context");

    fprintf(stderr, "Querying device list...\n");
    ob_device_list *devlist = ob_query_device_list(ctx, &err);
    check(err, "query_device_list");

    uint32_t count = ob_device_list_get_count(devlist, &err);
    check(err, "get_count");
    fprintf(stderr, "Found %u device(s)\n", count);
    if (count == 0) {
        fprintf(stderr, "No Orbbec device found.\n");
        return 1;
    }

    ob_device *dev = ob_device_list_get_device(devlist, 0, &err);
    check(err, "get_device");

    ob_device_info *info = ob_device_get_device_info(dev, &err);
    check(err, "get_device_info");
    fprintf(stderr, "Device: %s  FW: %s  SN: %s\n",
        ob_device_info_get_name(info, &err),
        ob_device_info_get_firmware_version(info, &err),
        ob_device_info_get_serial_number(info, &err));
    ob_delete_device_info(info, &err);

    fprintf(stderr, "Creating pipeline...\n");
    ob_pipeline *pipe = ob_create_pipeline_with_device(dev, &err);
    check(err, "create_pipeline");

    ob_config *cfg = ob_create_config(&err);
    check(err, "create_config");

    /* Enable depth stream */
    ob_config_enable_video_stream(cfg, OB_STREAM_DEPTH, 640, 480, 30, OB_FORMAT_Y11, &err);
    if (err) {
        fprintf(stderr, "Y11 stream not available, trying Z16...\n");
        ob_delete_error(err); err = nullptr;
        ob_config_enable_video_stream(cfg, OB_STREAM_DEPTH, 640, 480, 30, OB_FORMAT_Z16, &err);
        check(err, "enable_stream_z16");
    }

    fprintf(stderr, "Starting pipeline...\n");
    ob_pipeline_start_with_config(pipe, cfg, &err);
    check(err, "pipeline_start");

    fprintf(stderr, "Waiting for frames...\n");
    for (int i = 0; i < 5; i++) {
        ob_frame_set *frameset = ob_pipeline_wait_for_frame_set(pipe, 2000, &err);
        if (err || !frameset) {
            fprintf(stderr, "  Frame %d: timeout or error\n", i+1);
            if (err) { ob_delete_error(err); err = nullptr; }
            continue;
        }

        ob_frame *depth = ob_frameset_get_depth_frame(frameset, &err);
        if (err || !depth) {
            fprintf(stderr, "  Frame %d: no depth frame\n", i+1);
            if (err) { ob_delete_error(err); err = nullptr; }
            ob_delete_frame_set(frameset, &err);
            continue;
        }

        uint32_t dsize = ob_frame_get_data_size(depth, &err);
        const void *ddata = ob_frame_get_data(depth, &err);
        uint64_t ts = ob_frame_get_timestamp_us(depth, &err);

        fprintf(stderr, "  Frame %d: %u bytes  ts=%llu us\n",
                i+1, dsize, (unsigned long long)ts);

        /* Print first 32 bytes as hex */
        const uint8_t *p = (const uint8_t*)ddata;
        fprintf(stderr, "  First 32 bytes: ");
        for (uint32_t j = 0; j < 32 && j < dsize; j++)
            fprintf(stderr, "%02X ", p[j]);
        fprintf(stderr, "\n");

        /* Print to stdout for piping */
        fwrite(ddata, 1, dsize < 1024 ? dsize : 1024, stdout);
        fflush(stdout);

        ob_delete_frame(depth, &err);
        ob_delete_frame_set(frameset, &err);

        if (i >= 2) break;
    }

    fprintf(stderr, "Stopping pipeline...\n");
    ob_pipeline_stop(pipe, &err);
    ob_delete_pipeline(pipe, &err);
    ob_delete_config(cfg, &err);
    ob_delete_device(dev, &err);
    ob_delete_device_list(devlist, &err);
    ob_delete_context(ctx, &err);

    fprintf(stderr, "Done.\n");
    return 0;
}
