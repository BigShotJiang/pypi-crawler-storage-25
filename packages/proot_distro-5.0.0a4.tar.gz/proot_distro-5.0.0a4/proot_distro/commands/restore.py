import os
import shutil
import stat
import sys
import tarfile
from concurrent.futures import ThreadPoolExecutor, as_completed

from proot_distro.constants import DISTRO_CONFIGS_DIR, INSTALLED_ROOTFS_DIR
from proot_distro.colors import C, msg


# Magic-byte signatures used to identify compressed streams.
_MAGIC_COMPRESS = (
    (b'\x1f\x8b',      'gz'),   # gzip
    (b'BZh',           'bz2'),  # bzip2
    (b'\xfd7zXZ\x00',  'xz'),   # xz
)

# Regular files up to this size are pre-read into memory by the main thread
# and written by a worker.  Larger files are streamed from tar in the main thread.
_BUFFER_THRESHOLD = 4 << 20  # 4 MiB


def _detect_compression(header: bytes) -> str:
    """Return the tarfile compression mode inferred from *header* magic bytes.

    Returns the mode string ('gz', 'bz2', 'xz') on a match, or '' if the
    header does not match any known compressed format (plain tar or unknown).
    """
    for magic, mode in _MAGIC_COMPRESS:
        if header.startswith(magic):
            return mode
    return ''


# ---------------------------------------------------------------------------
# Worker functions — called from thread-pool threads.
# ---------------------------------------------------------------------------

def _write_reg(dest: str, data: bytes, mode: int) -> None:
    with open(dest, 'wb') as fh:
        fh.write(data)
    try:
        os.chmod(dest, stat.S_IMODE(mode))
    except OSError:
        pass


def _make_dir(dest: str, mode: int) -> None:
    os.makedirs(dest, exist_ok=True)
    try:
        os.chmod(dest, stat.S_IMODE(mode))
    except OSError:
        pass


def _make_symlink(dest: str, target: str) -> None:
    os.symlink(target, dest)


def _make_hardlink(dest: str, link_src: str) -> None:
    try:
        os.link(link_src, dest)
    except OSError:
        pass


# ---------------------------------------------------------------------------
# Main-thread helpers.
# ---------------------------------------------------------------------------

def _remove_existing(dest: str, member: tarfile.TarInfo) -> None:
    """Remove any existing filesystem entry at *dest* before extraction."""
    try:
        if os.path.islink(dest) or os.path.isfile(dest):
            os.remove(dest)
        elif os.path.isdir(dest) and not member.isdir():
            shutil.rmtree(dest)
    except OSError:
        pass


def _route(member: tarfile.TarInfo,
           configs_parent: str, configs_base: str,
           rootfs_parent: str, rootfs_base: str):
    """Return *(dest_root, dest)* for *member*, or *(None, None)* to skip."""
    name = member.name.lstrip('/')
    if name.startswith(configs_base + '/') or name == configs_base:
        dest_root = configs_parent
    elif name.startswith(rootfs_base + '/') or name == rootfs_base:
        dest_root = rootfs_parent
    else:
        return None, None
    return dest_root, os.path.join(dest_root, name)


def command_restore(args, configs: dict) -> None:
    tarball = getattr(args, "tarball", None)

    if tarball:
        if not os.path.exists(tarball):
            msg()
            msg(f"{C['BRED']}Error: file '{C['YELLOW']}{tarball}{C['BRED']}' does not exist.{C['RST']}")
            msg()
            sys.exit(1)
        if os.path.isdir(tarball):
            msg()
            msg(f"{C['BRED']}Error: path '{C['YELLOW']}{tarball}{C['BRED']}' is a directory.{C['RST']}")
            msg()
            sys.exit(1)
    else:
        if sys.stdin.isatty():
            from proot_distro.commands.help import _HELP_COMMANDS
            msg()
            msg(f"{C['BRED']}Error: tarball file path is not specified and it looks like nothing is being piped via stdin either.{C['RST']}")
            _HELP_COMMANDS["restore"]()
            sys.exit(1)

    configs_parent = os.path.dirname(DISTRO_CONFIGS_DIR)
    configs_base   = os.path.basename(DISTRO_CONFIGS_DIR)
    rootfs_parent  = os.path.dirname(INSTALLED_ROOTFS_DIR)
    rootfs_base    = os.path.basename(INSTALLED_ROOTFS_DIR)

    os.makedirs(DISTRO_CONFIGS_DIR, exist_ok=True)
    os.makedirs(INSTALLED_ROOTFS_DIR, exist_ok=True)

    msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Extracting distribution plug-in and rootfs from the tarball...{C['RST']}")

    use_tty = sys.stderr.isatty()
    done = 0

    def _on_entry(total: int) -> None:
        nonlocal done
        done += 1
        if not use_tty:
            return
        pfx = f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}"
        if total:
            pct = done * 100 // total
            bar = "#" * (pct // 5) + "-" * (20 - pct // 5)
            sys.stderr.write(f"\r{pfx}[{bar}] {pct:3d}%  {done} / {total} files{C['RST']}")
        else:
            sys.stderr.write(f"\r{pfx}{done} files extracted...{C['RST']}")
        sys.stderr.flush()

    try:
        if tarball:
            # Detect compression from the first few bytes of the file.
            with open(tarball, 'rb') as fh:
                header = fh.read(6)
            comp = _detect_compression(header)
            # Use the detected mode; fall back to tarfile auto-detection when
            # the header is not recognised (covers plain tar and exotic formats).
            tar_mode = f'r:{comp}' if comp else 'r:*'
            open_kwargs = dict(name=tarball, mode=tar_mode)
        else:
            # Peek at the first bytes of stdin without consuming them.
            # BufferedReader.peek() fills the internal buffer and returns up to
            # n bytes without advancing the read position.
            header = sys.stdin.buffer.peek(6)[:6]
            comp = _detect_compression(header)
            tar_mode = f'r|{comp}'   # 'r|gz', 'r|bz2', 'r|xz', or 'r|'
            open_kwargs = dict(fileobj=sys.stdin.buffer, mode=tar_mode)

        with tarfile.open(**open_kwargs) as tf:
            # Seekable file: pre-collect members for an accurate total count.
            # Streaming stdin: iterate on-the-fly; total is unknown (counter only).
            if tarball:
                all_members = [m for m in tf.getmembers()
                               if not (m.isblk() or m.ischr() or m.isfifo())]
                total = len(all_members)
            else:
                all_members = tf   # lazy iterator
                total = 0

            with ThreadPoolExecutor() as executor:
                futures = []

                for member in all_members:
                    if not tarball and (member.isblk() or member.ischr() or member.isfifo()):
                        continue

                    dest_root, dest = _route(member,
                                             configs_parent, configs_base,
                                             rootfs_parent, rootfs_base)
                    if dest is None:
                        continue

                    _remove_existing(dest, member)

                    if member.isdir():
                        futures.append(executor.submit(_make_dir, dest, member.mode))

                    elif member.issym():
                        parent = os.path.dirname(dest)
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        futures.append(executor.submit(_make_symlink, dest, member.linkname))

                    elif member.islnk():
                        link_src = os.path.join(dest_root, member.linkname.lstrip('/'))
                        parent = os.path.dirname(dest)
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        futures.append(executor.submit(_make_hardlink, dest, link_src))

                    elif member.isreg():
                        fobj = tf.extractfile(member)
                        if fobj is None:
                            continue
                        parent = os.path.dirname(dest)
                        if parent:
                            os.makedirs(parent, exist_ok=True)
                        if member.size <= _BUFFER_THRESHOLD:
                            # Read into memory; let a worker write it.
                            data = fobj.read()
                            fobj.close()
                            futures.append(executor.submit(_write_reg, dest, data, member.mode))
                        else:
                            # Stream large file in the main thread to avoid
                            # buffering it entirely in memory.
                            try:
                                with open(dest, 'wb') as out:
                                    while True:
                                        chunk = fobj.read(1 << 17)  # 128 KiB
                                        if not chunk:
                                            break
                                        out.write(chunk)
                                try:
                                    os.chmod(dest, stat.S_IMODE(member.mode))
                                except OSError:
                                    pass
                            finally:
                                fobj.close()
                            _on_entry(total)  # progress for large file immediately

                # Drain all queued write tasks; update progress as each finishes.
                for fut in as_completed(futures):
                    fut.result()
                    _on_entry(total)

        if use_tty:
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        msg(f"{C['BLUE']}[{C['GREEN']}*{C['BLUE']}] {C['CYAN']}Finished.{C['RST']}")

    except (OSError, tarfile.TarError) as exc:
        if use_tty:
            sys.stderr.write("\r\033[K")
            sys.stderr.flush()
        msg(f"{C['BLUE']}[{C['RED']}!{C['BLUE']}] {C['CYAN']}Failed to restore distribution: {exc}{C['RST']}")
        msg()
        msg(f"{C['BRED']}The tarball may be corrupted or was not created by PRoot-Distro.{C['RST']}")
        msg()
        sys.exit(1)
