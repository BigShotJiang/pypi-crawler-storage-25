"""Ghostty terminal backend.

Ghostty's macOS AppleScript API exposes stable terminal ids and text/key
injection. It does not currently expose a terminal pid or tty, so freeform
surface registration first writes a title marker from the wrapper tty, resolves
the matching Ghostty terminal id, then revalidates later by terminal-id
existence. Focus/cwd matching remains only a fallback when no local id is
available.
"""

from __future__ import annotations

import subprocess
import time

_run_process = subprocess.run
_TITLE_PREFIX = "mycel:"
_APPLESCRIPT_TIMEOUT_SECONDS = 5


class GhosttyTerminal:
    def ensure_group_container(self, group_id: str) -> str:
        raise RuntimeError("Ghostty group orchestration is not supported yet")

    def spawn_in_container(
        self,
        container_ref: str,
        role: str,
        role_index: int,
        cwd: str,
        cmd: str,
    ) -> str:
        raise RuntimeError("Ghostty group orchestration is not supported yet")

    def close_group_container(self, container_ref: str) -> None:
        raise RuntimeError("Ghostty group orchestration is not supported yet")

    def send_text(self, target_id: str, text: str) -> None:
        _run_applescript(
            _find_terminal_handler()
            + """
on run argv
  set targetId to item 1 of argv
  set payload to item 2 of argv
  tell application "Ghostty"
    input text payload to my mycelTargetTerminal(targetId)
  end tell
end run
""",
            target_id,
            text,
        )
        time.sleep(2)
        self.send_key(target_id, "enter")

    def send_key(self, target_id: str, key: str) -> None:
        key_map = {"escape": "escape", "enter": "enter", "ctrl-c": "ctrl-c"}
        key_name = key_map.get(key, key)
        _run_applescript(
            _find_terminal_handler()
            + """
on run argv
  set targetId to item 1 of argv
  set keyName to item 2 of argv
  tell application "Ghostty"
    send key keyName to my mycelTargetTerminal(targetId)
  end tell
end run
""",
            target_id,
            key_name,
        )

    def read_screen(self, target_id: str) -> str:
        raise RuntimeError("Ghostty screen read is not supported yet")

    def close(self, target_id: str) -> None:
        raise RuntimeError("Ghostty close is not supported yet")

    def prepare_freeform_surface(self, local_id: str) -> None:
        _write_title_marker(local_id)

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        if local_id:
            try:
                matches = [
                    terminal
                    for terminal in _list_terminals()
                    if terminal.name == _title_marker(local_id)
                ]
            except (OSError, subprocess.SubprocessError):
                return None
            if len(matches) == 1:
                return matches[0].terminal_id
            return None
        try:
            process_cwd = _process_cwd(pid)
            if process_cwd is None:
                return None
            focused = _focused_terminal()
            if focused is not None and _same_path(focused.cwd, process_cwd):
                return focused.terminal_id
            matches = [
                terminal
                for terminal in _list_terminals()
                if _same_path(terminal.cwd, process_cwd)
            ]
        except (OSError, subprocess.SubprocessError):
            return None
        if len(matches) == 1:
            return matches[0].terminal_id
        return None

    def target_exists(self, target_id: str) -> bool:
        try:
            return any(
                terminal.terminal_id == target_id for terminal in _list_terminals()
            )
        except (OSError, subprocess.SubprocessError):
            return False


class _GhosttyTerminalRef:
    def __init__(self, terminal_id: str, cwd: str, name: str) -> None:
        self.terminal_id = terminal_id
        self.cwd = cwd
        self.name = name


def _focused_terminal() -> _GhosttyTerminalRef | None:
    return _parse_terminal_row(
        _run_applescript(
            """
tell application "Ghostty"
  set mycelSep to ASCII character 9
  set mycelTerm to focused terminal of selected tab of front window
  return ((id of mycelTerm) as text) & mycelSep & (working directory of mycelTerm) & mycelSep & (name of mycelTerm)
end tell
"""
        )
    )


def _list_terminals() -> list[_GhosttyTerminalRef]:
    output = _run_applescript(
        """
tell application "Ghostty"
  set mycelRows to {}
  set mycelSep to ASCII character 9
  repeat with mycelWindow in windows
    repeat with mycelTab in tabs of mycelWindow
      repeat with mycelTerm in terminals of mycelTab
        set end of mycelRows to (((id of mycelTerm) as text) & mycelSep & (working directory of mycelTerm) & mycelSep & (name of mycelTerm))
      end repeat
    end repeat
  end repeat
  set AppleScript's text item delimiters to linefeed
  return mycelRows as text
end tell
"""
    )
    terminals: list[_GhosttyTerminalRef] = []
    for line in output.splitlines():
        terminal = _parse_terminal_row(line)
        if terminal is not None:
            terminals.append(terminal)
    return terminals


def _parse_terminal_row(row: str) -> _GhosttyTerminalRef | None:
    terminal_id, sep, rest = row.partition("\t")
    cwd, sep2, name = rest.partition("\t")
    if not sep or not sep2 or not terminal_id:
        return None
    return _GhosttyTerminalRef(terminal_id=terminal_id, cwd=cwd, name=name)


def _process_cwd(pid: int) -> str | None:
    result = _run_process(
        ["lsof", "-a", "-p", str(pid), "-d", "cwd", "-Fn"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        return None
    for line in result.stdout.splitlines():
        if line.startswith("n"):
            return line[1:]
    return None


def _same_path(left: str, right: str) -> bool:
    if not left or not right:
        return False
    from pathlib import Path

    return Path(left).expanduser().resolve() == Path(right).expanduser().resolve()


def _title_marker(local_id: str) -> str:
    return f"{_TITLE_PREFIX}{local_id}"


def _write_title_marker(local_id: str) -> None:
    marker = _title_marker(local_id)
    with open("/dev/tty", "wb", buffering=0) as tty:
        tty.write(f"\033]0;{marker}\007".encode("utf-8"))


def _find_terminal_handler() -> str:
    return """
on mycelTargetTerminal(targetId)
  tell application "Ghostty"
    repeat with mycelWindow in windows
      repeat with mycelTab in tabs of mycelWindow
        repeat with mycelTerm in terminals of mycelTab
          if ((id of mycelTerm) as text) is targetId then return mycelTerm
        end repeat
      end repeat
    end repeat
  end tell
  error "Ghostty terminal not found: " & targetId
end mycelTargetTerminal
"""


def _run_applescript(script: str, *args: str) -> str:
    try:
        result = _run_process(
            ["osascript", "-", *args],
            input=script,
            capture_output=True,
            text=True,
            check=True,
            timeout=_APPLESCRIPT_TIMEOUT_SECONDS,
        )
    except subprocess.TimeoutExpired as exc:
        raise subprocess.SubprocessError(
            "Ghostty AppleScript timed out; check macOS Automation permission "
            "for the controlling process and confirm a logged-in GUI session is active."
        ) from exc
    return result.stdout.strip()
