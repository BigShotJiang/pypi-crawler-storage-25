"""`cel group <group_id> worker ...` verb dispatch."""

from __future__ import annotations

import json

import typer

from mycel_cli.group._cli.authority import authorize_operation
from mycel_cli.group._cli.chat_transport import (
    ScopedUnreadConflict,
    addressed_inbox_bodies,
    describe_group_route,
    user_id_for,
    group_chat_for,
    mark_group_read,
    unread_bodies_from_sender,
)
from mycel_cli.group._cli.contracts import (
    build_contract_metadata,
    build_worker_bootstrap_prompt_v1,
    build_worker_contract_v1,
)
from mycel_cli.group._cli.identity_binding import RoleIdentity, require_role_identity
from mycel_cli.group._cli.identity_env import build_user_env
from mycel_cli.group._cli.membership import ensure_role_chat_member
from mycel_cli.group._cli.helpers import (
    dispatch_command,
    extract_named_option,
    generate_session_id,
    parse_name_path_update,
    reject_unknown_args,
    require_group_active,
    require_workers_enabled,
    resolve_session_id_by_prefix_or_fail,
    validate_spawn_path_or_fail,
)
from mycel_cli.group._cli import spawn as _spawn_mod
from mycel_cli.group._state.groups import group_terminal_type, mutate_group
from mycel_cli.group._state.messages import write_and_index_message
from mycel_cli.group._state.roles import (
    add_worker,
    find_supervisor,
    find_worker,
    iter_workers,
    remove_worker,
    update_role,
)
from mycel_cli.group.worker import resolve_worker, worker_cache_from_info
from mycel_cli.group.workflow_policy import OperationName


def _register_existing_session(
    group_id: str,
    group: dict,
    *,
    existing_session: str,
    identity: RoleIdentity,
    name: str | None,
    path: str | None,
) -> None:
    authorize_operation(OperationName.WORKER_CREATE, group_id=group_id)
    require_group_active(group_id, group)
    require_workers_enabled(group_id, group, command="worker create")
    if identity.agent_type == "codex":
        info = resolve_worker(
            existing_session,
            group_terminal_type(group),
            agent_type=identity.agent_type,
        )
        if info.thread_id is None:
            info.thread_id = existing_session
    else:
        info = resolve_worker(existing_session, group_terminal_type(group))
    if identity.agent_type == "codex":
        has_identity = bool(info.thread_id or info.jsonl_path)
    else:
        has_identity = info.jsonl_path is not None
    if not has_identity:
        typer.echo(
            f"session 不存在或尚未产生对话记录: '{existing_session}'",
            err=True,
        )
        raise typer.Exit(1)
    ensure_role_chat_member(group_id, identity.local_id)
    add_worker(
        group_id,
        existing_session,
        cache=worker_cache_from_info(info),
        name=name,
        path=path,
        contract=None,
        agent_type=identity.agent_type,
        local_id=identity.local_id,
        bootstrapped=True,
    )
    typer.echo(f"Worker '{existing_session}' 已创建。")


def _spawn_new_worker(
    group_id: str,
    group: dict,
    *,
    identity: RoleIdentity,
    name: str | None,
    path: str | None,
) -> None:
    authorize_operation(OperationName.WORKER_CREATE, group_id=group_id)
    require_group_active(group_id, group)
    require_workers_enabled(group_id, group, command="worker create")
    validate_spawn_path_or_fail(path)
    ensure_role_chat_member(group_id, identity.local_id)
    session = generate_session_id()
    append_system_prompt = build_worker_contract_v1()
    bootstrap_prompt = build_worker_bootstrap_prompt_v1(group_id, session, name)
    contract = build_contract_metadata(
        "worker",
        append_system_prompt,
        bootstrap_prompt,
        agent_type=identity.agent_type,
    )
    user_env = build_user_env(
        group_id=group_id,
        user_session=session,
        local_id=identity.local_id,
    )
    terminal_type = group_terminal_type(group)

    def register_spawned_worker(target_id: str | None) -> None:
        cache = {"target_id": target_id} if target_id else None
        add_worker(
            group_id,
            session,
            cache=cache,
            name=name,
            path=path,
            contract=contract,
            agent_type=identity.agent_type,
            local_id=identity.local_id,
        )

    def rollback_worker() -> None:
        remove_worker(group_id, session)

    cache, _info = _spawn_mod.spawn_and_wait_for_ready(
        session,
        path,
        agent_type=identity.agent_type,
        local_id=identity.local_id,
        terminal_type=terminal_type,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        role="worker",
        group_id=group_id,
        user_env=user_env,
        on_spawned=register_spawned_worker,
        on_failure=rollback_worker,
    )
    update_role(
        group_id,
        session,
        role="worker",
        cache=cache,
        name=name,
        path=path,
        contract=contract,
        agent_type=identity.agent_type,
        local_id=identity.local_id,
    )
    typer.echo(f"Worker '{session}' 已创建。")


def _cmd_create(group_id: str, group: dict, payload: list[str]) -> None:
    identity_raw, rest = extract_named_option(payload, "--agent")
    name, rest = extract_named_option(rest, "--name")
    path, rest = extract_named_option(rest, "--path")
    existing_session, rest = extract_named_option(rest, "--session")
    reject_unknown_args(rest)
    identity = require_role_identity(identity_raw)

    if existing_session is not None:
        _register_existing_session(
            group_id,
            group,
            existing_session=existing_session,
            identity=identity,
            name=name,
            path=path,
        )
    else:
        _spawn_new_worker(group_id, group, identity=identity, name=name, path=path)


def _cmd_list(group: dict) -> None:
    workers = iter_workers(group)
    if not workers:
        typer.echo("(无 worker)")
        return
    typer.echo("\n".join(worker["session"] for worker in workers))


def _cmd_show(group: dict, payload: list[str]) -> None:
    if not payload:
        typer.echo("worker_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_session_id_by_prefix_or_fail(
        group=group,
        role="worker",
        raw_id=payload[0],
        id_label="worker_id",
    )
    worker = find_worker(group, resolved)
    if worker is None:
        typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(worker, ensure_ascii=False, indent=2))


def _cmd_update(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.WORKER_UPDATE, group_id=group_id)
    worker_id, name, path = parse_name_path_update(payload, id_label="worker_id")
    resolved = resolve_session_id_by_prefix_or_fail(
        group=group,
        role="worker",
        raw_id=worker_id,
        id_label="worker_id",
    )
    worker = find_worker(group, resolved)
    if worker is None:
        typer.echo(f"Worker '{worker_id}' 不存在", err=True)
        raise typer.Exit(1)
    with mutate_group(group_id) as locked_group:
        locked_worker = find_worker(locked_group, resolved)
        if locked_worker is None:
            typer.echo(f"Worker '{worker_id}' 不存在", err=True)
            raise typer.Exit(1)
        if name is not None:
            locked_worker["name"] = name
        if path is not None:
            locked_worker["path"] = path
    typer.echo(f"Worker '{resolved}' 已更新。")


def _cmd_remove(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.WORKER_REMOVE, group_id=group_id)
    if not payload:
        typer.echo("worker_id is required", err=True)
        raise typer.Exit(2)
    resolved = resolve_session_id_by_prefix_or_fail(
        group=group,
        role="worker",
        raw_id=payload[0],
        id_label="worker_id",
    )
    worker = find_worker(group, resolved)
    if worker is None:
        typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    _spawn_mod.kill_and_close_worker(worker, group)
    if not remove_worker(group_id, resolved):
        typer.echo(f"Worker '{payload[0]}' 不存在", err=True)
        raise typer.Exit(1)
    from mycel_cli.group._workflow import memory_state

    memory_state.purge_worker(group_id, resolved)
    typer.echo(f"Worker '{resolved}' 已删除。")


def _current_worker(group_id: str, group: dict) -> dict:
    from mycel_cli.group._cli.identity_env import resolve_current_user_session

    session = resolve_current_user_session(group_id)
    if session is None:
        typer.echo(
            "worker commands must run inside a cel-managed worker session.", err=True
        )
        raise typer.Exit(1)
    worker = find_worker(group, session)
    if worker is None:
        typer.echo(
            f"当前 user '{session}' 不是 group '{group_id}' 的 worker。", err=True
        )
        raise typer.Exit(1)
    return worker


def _supervisor_or_fail(group: dict) -> dict:
    supervisor = find_supervisor(group)
    if supervisor is None:
        typer.echo("Supervisor not found in group", err=True)
        raise typer.Exit(1)
    return supervisor


def _cmd_read(group_id: str, group: dict) -> None:
    authorize_operation(OperationName.WORKER_READ, group_id=group_id)
    worker = _current_worker(group_id, group)
    supervisor = _supervisor_or_fail(group)
    try:
        contents = unread_bodies_from_sender(
            group_id=group_id, viewer=worker, sender=supervisor
        )
    except ScopedUnreadConflict as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1) from exc
    if not contents:
        typer.echo("暂无可读 supervisor 消息", err=True)
        raise typer.Exit(1)
    typer.echo("\n".join(contents))


def _cmd_mark_read(group_id: str, group: dict) -> None:
    authorize_operation(OperationName.WORKER_READ, group_id=group_id)
    worker = _current_worker(group_id, group)
    _supervisor_or_fail(group)
    mark_group_read(group_id=group_id, viewer=worker)
    typer.echo(f"Worker chat cursor advanced for group '{group_id}'.")


def _cmd_inbox(group_id: str, group: dict) -> None:
    authorize_operation(OperationName.WORKER_READ, group_id=group_id)
    worker = _current_worker(group_id, group)
    supervisor = _supervisor_or_fail(group)
    contents = addressed_inbox_bodies(
        group_id=group_id,
        viewer=worker,
        excluded_senders=[worker, supervisor],
    )
    if not contents:
        typer.echo("Worker inbox 暂无可读消息", err=True)
        raise typer.Exit(1)
    typer.echo("\n".join(contents))


def _cmd_send(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.WORKER_SEND, group_id=group_id)
    if len(payload) != 1:
        typer.echo("worker send takes exactly one message argument", err=True)
        raise typer.Exit(2)
    worker = _current_worker(group_id, group)
    supervisor = _supervisor_or_fail(group)
    client, chat_id = group_chat_for(
        group_id=group_id, sender=worker, recipient=supervisor
    )
    client.messages.send(
        chat_id,
        payload[0],
        delivery_scope="addressed",
        addressed_to_user_ids=[user_id_for(supervisor)],
    )
    write_and_index_message(
        group_id,
        role="worker",
        session=str(worker["session"]),
        event_type="send",
        content=payload[0],
    )
    typer.echo("已发送到 supervisor。")
    typer.echo(
        describe_group_route(chat_id=chat_id, sender=worker, recipient=supervisor)
    )


def dispatch(
    group_id: str, group: dict, command: str | None, payload: list[str]
) -> None:
    dispatch_command(
        command,
        {
            "create": lambda: _cmd_create(group_id, group, payload),
            "list": lambda: _cmd_list(group),
            "show": lambda: _cmd_show(group, payload),
            "update": lambda: _cmd_update(group_id, group, payload),
            "remove": lambda: _cmd_remove(group_id, group, payload),
            "read": lambda: _cmd_read(group_id, group),
            "inbox": lambda: _cmd_inbox(group_id, group),
            "mark-read": lambda: _cmd_mark_read(group_id, group),
            "send": lambda: _cmd_send(group_id, group, payload),
        },
    )
