"""Unit tests for Oracle ODBC connection configuration."""

import pytest

from data_exchange_agent.config.sections.connections.connection_registry import (
    ConnectionRegistry,
)
from data_exchange_agent.config.sections.connections.dialects.oracle.config import (
    DEFAULT_ORACLE_PORT,
    OracleConnectionConfig,
    OracleConnectionMode,
)


class TestOracleConnectionString:
    """Tests for Oracle ODBC connection string formatting."""

    def test_basic_ez_connect(self):
        cfg = OracleConnectionConfig(
            database="ORCLPDB1",
            username="scott",
            password="tiger",
            host="db.example.com",
            port=1521,
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
        )
        cs = cfg.connection_string
        assert "DRIVER={Oracle in instantclient_21_1}" in cs
        assert "DBQ=//db.example.com:1521/ORCLPDB1" in cs
        assert "UID=scott" in cs
        assert "PWD=tiger" in cs

    def test_default_port(self):
        cfg = OracleConnectionConfig(
            database="XEPDB1",
            username="u",
            password="p",
            host="127.0.0.1",
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
        )
        assert cfg.port == DEFAULT_ORACLE_PORT
        assert ":1521/" in cfg.connection_string

    def test_tns_alias_mode(self):
        cfg = OracleConnectionConfig(
            oracle_connection_mode=OracleConnectionMode.TNS_ALIAS,
            tns_name="PROD_DB",
            username="u",
            password="p",
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
        )
        assert "DBQ=PROD_DB" in cfg.connection_string

    def test_connect_descriptor_mode(self):
        desc = "(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=h)(PORT=1521))" "(CONNECT_DATA=(SERVICE_NAME=s)))"
        cfg = OracleConnectionConfig(
            oracle_connection_mode=OracleConnectionMode.CONNECT_DESCRIPTOR,
            connect_descriptor=desc,
            username="u",
            password="p",
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
        )
        assert f"DBQ={desc}" in cfg.connection_string

    def test_wallet_attributes(self):
        cfg = OracleConnectionConfig(
            database="ORCLPDB1",
            username="u",
            password="p",
            host="h",
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
            wallet_directory="/secure/wallet",
            wallet_password="wp",
        )
        cs = cfg.connection_string
        assert "MY_WALLET_DIRECTORY=/secure/wallet" in cs
        assert "MY_WALLET_PASSWORD=wp" in cs

    def test_extra_options_appended(self):
        cfg = OracleConnectionConfig(
            database="ORCLPDB1",
            username="u",
            password="p",
            host="h",
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
            extra_options={"LDAP_AUTHENTICATION": "true"},
        )
        assert "LDAP_AUTHENTICATION=true" in cfg.connection_string

    def test_from_config_dict(self):
        cfg = OracleConnectionConfig.from_config_dict(
            database="ORCLPDB1",
            username="u",
            host="host.example.com",
            password="p",
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
            oracle_connection_mode="basic",
        )
        assert "//host.example.com:1521/ORCLPDB1" in cfg.connection_string


class TestOracleValidation:
    """Validation rules for Oracle modes."""

    def test_basic_requires_database(self):
        with pytest.raises(ValueError, match="database"):
            OracleConnectionConfig(
                database="",
                username="u",
                password="p",
                host="h",
                odbc_driver="Oracle in instantclient_21_1",
                auto_detect_driver=False,
            )

    def test_tns_requires_tns_name(self):
        with pytest.raises(ValueError, match="tns_name"):
            OracleConnectionConfig(
                oracle_connection_mode=OracleConnectionMode.TNS_ALIAS,
                username="u",
                password="p",
                odbc_driver="Oracle in instantclient_21_1",
                auto_detect_driver=False,
            )

    def test_invalid_mode_string(self):
        with pytest.raises(ValueError, match="oracle_connection_mode"):
            OracleConnectionConfig.from_config_dict(
                oracle_connection_mode="ldap_only",
                username="u",
                password="p",
                odbc_driver="Oracle in instantclient_21_1",
                auto_detect_driver=False,
            )


class TestOracleConnectionRegistry:
    """Oracle is registered under connection name ``oracle``."""

    def test_oracle_registered(self):
        assert ConnectionRegistry.is_registered("oracle")

    def test_create_from_dict(self):
        cfg = ConnectionRegistry.create(
            "oracle",
            database="ORCLPDB1",
            username="u",
            host="127.0.0.1",
            password="p",
            odbc_driver="Oracle in instantclient_21_1",
            auto_detect_driver=False,
        )
        assert isinstance(cfg, OracleConnectionConfig)
        assert "ORCLPDB1" in cfg.connection_string
