"""Unit tests for Teradata ODBC connection configuration."""

import os
import tempfile
import warnings
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError

from data_exchange_agent.config.sections.connections.connection_registry import (
    ConnectionRegistry,
)
from data_exchange_agent.config.sections.connections.dialects.teradata import (
    DEFAULT_TERADATA_ODBC_DRIVER,
    DEFAULT_TERADATA_PORT,
    TPT_DEFAULT_CHARSET,
    TeradataConnectionConfig,
    TptConfig,
    WriteNosConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType


@pytest.fixture
def mock_available_drivers():
    """Available ODBC drivers seen by ``shared.odbc.driver_utils``."""
    return [
        "Teradata Database ODBC Driver 17.20",
        "Teradata Database ODBC Driver 16.20",
    ]


@pytest.fixture
def patched_pyodbc(mock_available_drivers):
    """Patch ``_get_pyodbc`` so driver auto-detection is deterministic."""
    with patch("shared.odbc.driver_utils._get_pyodbc") as mock_get_pyodbc:
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = mock_available_drivers
        mock_get_pyodbc.return_value = mock_pyodbc
        yield mock_pyodbc


@pytest.fixture
def patched_pyodbc_no_teradata_driver():
    """ODBC drivers exist, but none are Teradata (auto-detect must fail fast)."""
    with patch("shared.odbc.driver_utils._get_pyodbc") as mock_get_pyodbc:
        mock_pyodbc = MagicMock()
        mock_pyodbc.drivers.return_value = ["ODBC Driver 18 for SQL Server"]
        mock_get_pyodbc.return_value = mock_pyodbc
        yield mock_pyodbc


class TestTeradataConnectionString:
    """Tests for Teradata ODBC connection string formatting."""

    def test_basic_connection_string_uses_host_as_dbc_name(self, patched_pyodbc):
        cfg = TeradataConnectionConfig(
            host="tdcop.example.com",
            port=1025,
            database="tpcds",
            username="dbc",
            password="secret",
        )
        cs = cfg.connection_string
        assert "DRIVER={Teradata Database ODBC Driver 17.20}" in cs
        assert "DBCName=tdcop.example.com" in cs
        assert "UID=dbc" in cs
        assert "PWD=secret" in cs
        assert "Database=tpcds" in cs
        assert "PortNumber=1025" in cs

    def test_dbc_name_override(self, patched_pyodbc):
        cfg = TeradataConnectionConfig(
            host="10.0.0.1",
            dbc_name="MYTDSYS",
            port=1025,
            database="tpcds",
            username="u",
            password="p",
        )
        assert "DBCName=MYTDSYS" in cfg.connection_string
        assert "DBCName=10.0.0.1" not in cfg.connection_string

    def test_extra_options_appended(self, patched_pyodbc):
        cfg = TeradataConnectionConfig(
            host="h",
            database="d",
            username="u",
            password="p",
            extra_options={"UseUnicode": "1"},
        )
        cs = cfg.connection_string
        assert "UseUnicode=1" in cs

    def test_authentication_appended(self, patched_pyodbc):
        cfg = TeradataConnectionConfig(
            host="h",
            database="d",
            username="u",
            password="p",
            authentication="LDAP",
        )
        assert "AuthMech=LDAP" in cfg.connection_string

    def test_from_config_dict_merges_extra_options_kwargs(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="tpcds",
            username="u",
            host="td.example.com",
            password="p",
            UseUnicode="1",
            MechanismName="LDAP",
        )
        cs = cfg.connection_string
        assert "UseUnicode=1" in cs
        assert "MechanismName=LDAP" in cs

    def test_from_config_dict_legacy_driver_name_maps_to_odbc_driver(self, patched_pyodbc):
        """TOML historically used ``driver_name`` for the ODBC driver label."""
        mock_available_drivers = patched_pyodbc.drivers.return_value
        legacy_label = "Teradata Database ODBC Driver 20.00"
        mock_available_drivers.append(legacy_label)

        with pytest.warns(DeprecationWarning, match="driver_name.*deprecated"):
            cfg = TeradataConnectionConfig.from_config_dict(
                database="tpcds",
                username="u",
                host="td.example.com",
                password="p",
                driver_name=legacy_label,
            )

        cs = cfg.connection_string
        assert f"DRIVER={{{legacy_label}}}" in cs
        assert "driver_name=" not in cs

    def test_connection_registry_create_accepts_legacy_driver_name(self, patched_pyodbc):
        mock_available_drivers = patched_pyodbc.drivers.return_value
        legacy_label = "Teradata Database ODBC Driver 20.00"
        mock_available_drivers.append(legacy_label)

        with pytest.warns(DeprecationWarning, match="driver_name.*deprecated"):
            cfg = ConnectionRegistry.create(
                "teradata",
                database="tpcds",
                username="u",
                host="td.example.com",
                password="p",
                driver_name=legacy_label,
            )

        assert isinstance(cfg, TeradataConnectionConfig)
        assert f"DRIVER={{{legacy_label}}}" in cfg.connection_string
        assert "driver_name=" not in cfg.connection_string

    def test_from_config_dict_odbc_driver_wins_over_legacy_driver_name(self, patched_pyodbc):
        mock_available_drivers = patched_pyodbc.drivers.return_value
        preferred = "Teradata Database ODBC Driver 17.20"
        ignored = "Teradata Database ODBC Driver 16.20"
        assert preferred in mock_available_drivers
        assert ignored in mock_available_drivers

        with warnings.catch_warnings(record=True) as recorded:
            warnings.simplefilter("always")
            cfg = TeradataConnectionConfig.from_config_dict(
                database="tpcds",
                username="u",
                host="td.example.com",
                password="p",
                odbc_driver=preferred,
                driver_name=ignored,
            )

        assert any("both `odbc_driver` and legacy `driver_name`" in str(w.message) for w in recorded)
        assert f"DRIVER={{{preferred}}}" in cfg.connection_string
        assert "driver_name=" not in cfg.connection_string

    def test_from_config_dict_connection_kind_driver_name_ignored(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="tpcds",
            username="u",
            host="td.example.com",
            password="p",
            driver_name=ConnectionType.TERADATA.value,
        )
        assert cfg.odbc_driver == DEFAULT_TERADATA_ODBC_DRIVER
        assert "driver_name=" not in cfg.connection_string

    def test_defaults_from_constants(self, patched_pyodbc):
        cfg = TeradataConnectionConfig(
            host="localhost",
            database="db",
            username="u",
        )
        assert cfg.port == DEFAULT_TERADATA_PORT
        assert cfg.driver_name == ConnectionType.TERADATA
        assert cfg.odbc_driver == DEFAULT_TERADATA_ODBC_DRIVER


class TestTeradataDriverResolution:
    """Fails fast when auto-detect cannot find a Teradata ODBC driver."""

    def test_auto_detect_raises_when_no_teradata_driver(self, patched_pyodbc_no_teradata_driver):
        with pytest.raises(ValidationError, match="No Teradata ODBC driver"):
            TeradataConnectionConfig(
                host="h",
                database="d",
                username="u",
                password="p",
                auto_detect_driver=True,
            )

    def test_from_config_dict_accepts_driver_name_as_odbc_alias(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            driver_name="Teradata Database ODBC Driver 16.20",
        )
        assert cfg.odbc_driver == "Teradata Database ODBC Driver 16.20"

    def test_from_config_dict_odbc_driver_overrides_driver_name(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            odbc_driver="Teradata Database ODBC Driver 16.20",
            driver_name="Teradata Database ODBC Driver 17.20",
        )
        assert cfg.odbc_driver == "Teradata Database ODBC Driver 16.20"


class TestTeradataConnectionRegistry:
    """Teradata is registered under connection name 'teradata'."""

    def test_teradata_registered(self):
        assert ConnectionRegistry.is_registered("teradata")

    def test_create_from_dict(self, patched_pyodbc):
        cfg = ConnectionRegistry.create(
            "teradata",
            database="tpcds",
            username="u",
            host="h",
            password="p",
        )
        assert isinstance(cfg, TeradataConnectionConfig)
        assert "Database=tpcds" in cfg.connection_string


class TestWriteNosConfigBuildLocation:
    """Tests for ``WriteNosConfig.build_location``."""

    @pytest.mark.parametrize(
        "scheme,host,container,relative_path,expected",
        [
            (
                "/s3/",
                "mybucket.s3.amazonaws.com",
                "exports",
                "wf_1/tbl_2/partition_0/",
                "/s3/mybucket.s3.amazonaws.com/exports/wf_1/tbl_2/partition_0/",
            ),
            (
                "/az/",
                "myaccount.blob.core.windows.net",
                "td-nos-exports",
                "wf_1/tbl_2/partition_0/",
                "/az/myaccount.blob.core.windows.net/td-nos-exports/wf_1/tbl_2/partition_0/",
            ),
            (
                "/gs/",
                "storage.googleapis.com",
                "my-gcs-bucket",
                "wf_1/tbl_2/partition_0/",
                "/gs/storage.googleapis.com/my-gcs-bucket/wf_1/tbl_2/partition_0/",
            ),
        ],
    )
    def test_supports_all_three_clouds(self, scheme, host, container, relative_path, expected):
        cfg = WriteNosConfig(
            location_scheme=scheme,
            location_host=host,
            location_container=container,
        )
        assert cfg.build_location(relative_path) == expected

    def test_strips_extra_slashes(self):
        cfg = WriteNosConfig(
            location_scheme="//s3//",
            location_host="//host//",
            location_container="//bucket//",
        )
        assert cfg.build_location("//some/path//") == "/s3/host/bucket/some/path/"

    def test_empty_relative_path_without_container_is_host_root(self):
        cfg = WriteNosConfig(
            location_scheme="/s3/",
            location_host="host",
            location_container="",
        )
        assert cfg.build_location("") == "/s3/host/"

    def test_empty_container_skips_segment_before_relative_path(self):
        cfg = WriteNosConfig(
            location_scheme="/s3/",
            location_host="mybucket.s3.amazonaws.com",
            location_container="",
        )
        assert (
            cfg.build_location("task_results/wf/tbl/data/full_table/")
            == "/s3/mybucket.s3.amazonaws.com/task_results/wf/tbl/data/full_table/"
        )


class TestWriteNosConfigBuildQuery:
    """Validates ``WriteNosConfig.build_write_nos_query`` for all three credential modes."""

    def _base_kwargs(self) -> dict:
        return {
            "location_scheme": "/az/",
            "location_host": "host",
            "location_container": "bucket",
        }

    def test_function_mapping_mode_omits_authorization(self):
        cfg = WriteNosConfig(
            **self._base_kwargs(),
            function_mapping="nos_util.WRITE_NOS_FM",
            access_id="should_be_ignored",
            access_key="should_be_ignored",
            authorization_name="ignored_too",
        )
        sql = cfg.build_write_nos_query("SELECT * FROM t", "/az/host/bucket/path/")
        # Function mapping wins; AUTHORIZATION must NOT be present.
        assert "FROM nos_util.WRITE_NOS_FM" in sql
        assert "AUTHORIZATION" not in sql
        assert "should_be_ignored" not in sql
        assert "LOCATION('/az/host/bucket/path/')" in sql
        assert "STOREDAS('PARQUET')" in sql
        assert "COMPRESSION('SNAPPY')" in sql
        assert "MAXOBJECTSIZE('16MB')" in sql
        assert "OVERWRITE('FALSE')" in sql
        assert "MANIFESTONLY" not in sql
        assert "MANIFESTFILE" not in sql

    def test_named_authorization_mode(self):
        cfg = WriteNosConfig(
            **self._base_kwargs(),
            authorization_name="nos_util.DefAuth_Write",
        )
        sql = cfg.build_write_nos_query("SELECT * FROM t", "/az/host/bucket/path/")
        assert "FROM WRITE_NOS" in sql
        assert "AUTHORIZATION('nos_util.DefAuth_Write')" in sql
        assert "OVERWRITE('FALSE')" in sql
        assert "MANIFESTONLY" not in sql
        assert "MANIFESTFILE" not in sql

    def test_inline_credentials_mode(self):
        cfg = WriteNosConfig(
            **self._base_kwargs(),
            access_id="my_account",
            access_key="my_secret",
        )
        sql = cfg.build_write_nos_query("SELECT * FROM t", "/az/host/bucket/path/")
        assert "FROM WRITE_NOS" in sql
        assert 'AUTHORIZATION(\'{"Access_ID":"my_account"' in sql
        assert '"Access_Key":"my_secret"}\')' in sql
        assert "OVERWRITE('FALSE')" in sql
        assert "MANIFESTONLY" not in sql
        assert "MANIFESTFILE" not in sql

    def test_inline_credentials_escapes_single_quote_for_sql_literal(self):
        """Apostrophe in secret must not break AUTHORIZATION('...'); SQL doubles ''."""
        cfg = WriteNosConfig(
            **self._base_kwargs(),
            access_id="id",
            access_key="sec'ret",
        )
        sql = cfg.build_write_nos_query("SELECT 1", "/az/host/bucket/p/")
        assert "AUTHORIZATION(" in sql
        assert "sec''ret" in sql

    def test_named_authorization_takes_precedence_over_inline(self):
        cfg = WriteNosConfig(
            **self._base_kwargs(),
            authorization_name="nos_util.DefAuth_Write",
            access_id="ignored",
            access_key="ignored",
        )
        sql = cfg.build_write_nos_query("SELECT 1", "/az/host/bucket/p/")
        assert "AUTHORIZATION('nos_util.DefAuth_Write')" in sql
        assert "ignored" not in sql

    def test_no_credentials_renders_no_authorization_clause(self):
        cfg = WriteNosConfig(**self._base_kwargs())
        sql = cfg.build_write_nos_query("SELECT 1", "/az/host/bucket/p/")
        assert "AUTHORIZATION" not in sql

    def test_row_export_uses_overwrite_false_for_manifest_contract(self):
        """OVERWRITE TRUE on this TD stack chains to MANIFESTONLY and a 2-col ON clause; row export uses FALSE."""
        cfg = WriteNosConfig(**self._base_kwargs())
        sql = cfg.build_write_nos_query("SELECT 1", "/az/host/bucket/p/")
        assert "OVERWRITE('FALSE')" in sql
        assert "MANIFESTONLY" not in sql
        assert "MANIFESTFILE" not in sql


class TestTeradataFromConfigDictWriteNos:
    """``from_config_dict`` parses ``write_nos_*`` kwargs."""

    def test_no_write_nos_kwargs_yields_no_config(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
        )
        assert cfg.write_nos_config is None

    def test_scheme_and_host_without_container_enables_write_nos(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            write_nos_location_scheme="/s3/",
            write_nos_location_host="mybucket.s3.us-west-2.amazonaws.com",
        )
        assert cfg.write_nos_config is not None
        assert cfg.write_nos_config.location_container == ""
        assert (
            cfg.write_nos_config.build_location("task_results/workflows/1/tables/2/data/full_table/")
            == "/s3/mybucket.s3.us-west-2.amazonaws.com/task_results/workflows/1/tables/2/data/full_table/"
        )

    def test_empty_string_write_nos_location_container_strips_to_optional(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            write_nos_location_scheme="/s3/",
            write_nos_location_host="host",
            write_nos_location_container="   ",
        )
        assert cfg.write_nos_config is not None
        assert cfg.write_nos_config.location_container == ""

    def test_function_mapping_mode_via_from_config_dict(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            write_nos_location_scheme="/az/",
            write_nos_location_host="myaccount.blob.core.windows.net",
            write_nos_location_container="td-nos-exports",
            write_nos_function_mapping="nos_util.WRITE_NOS_FM",
        )
        assert cfg.write_nos_config is not None
        assert cfg.write_nos_config.function_mapping == "nos_util.WRITE_NOS_FM"
        assert cfg.write_nos_config.location_scheme == "/az/"

    def test_inline_credentials_mode_via_from_config_dict(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            write_nos_location_scheme="/s3/",
            write_nos_location_host="bucket.s3.amazonaws.com",
            write_nos_location_container="exports",
            write_nos_access_id="AKIA...",
            write_nos_access_key="secret",
        )
        assert cfg.write_nos_config is not None
        assert cfg.write_nos_config.access_id == "AKIA..."
        assert cfg.write_nos_config.access_key == "secret"

    def test_named_authorization_mode_via_from_config_dict(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            write_nos_location_scheme="/gs/",
            write_nos_location_host="storage.googleapis.com",
            write_nos_location_container="my-gcs-bucket",
            write_nos_authorization_name="nos_util.DefAuth_Write",
        )
        assert cfg.write_nos_config is not None
        assert cfg.write_nos_config.authorization_name == "nos_util.DefAuth_Write"


class TestTptConfig:
    """``TptConfig`` helpers."""

    def test_effective_log_directory_fallback(self):
        cfg = TptConfig(output_directory="/out")
        assert cfg.effective_log_directory == os.path.normpath(os.path.expanduser("/out"))

    def test_effective_log_directory_explicit(self):
        cfg = TptConfig(output_directory="/out", log_directory="/logs")
        assert cfg.effective_log_directory == os.path.normpath(os.path.expanduser("/logs"))

    def test_expanduser_tilde_paths(self):
        cfg = TptConfig(output_directory="~/dea-out", log_directory="~/dea-log")
        assert cfg.output_directory.endswith("dea-out")
        assert not cfg.output_directory.startswith("~")
        assert cfg.log_directory.endswith("dea-log")
        assert not cfg.log_directory.startswith("~")


class TestTeradataFromConfigDictTpt:
    """``from_config_dict`` parses ``tpt_*`` kwargs."""

    def test_tpt_internal_work_directories_always_configured(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
        )
        assert cfg.tpt_config is not None
        base = os.path.join(tempfile.gettempdir(), "data-exchange-agent", "tpt")
        assert cfg.tpt_config.output_directory == os.path.join(base, "output")
        assert cfg.tpt_config.log_directory == os.path.join(base, "logs")
        assert cfg.tpt_config.charset == TPT_DEFAULT_CHARSET

    def test_tpt_optional_delimiter_and_sessions_override(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            tpt_delimiter="^",
            tpt_max_sessions=8,
        )
        assert cfg.tpt_config is not None
        base = os.path.join(tempfile.gettempdir(), "data-exchange-agent", "tpt")
        assert cfg.tpt_config.output_directory == os.path.join(base, "output")
        assert cfg.tpt_config.log_directory == os.path.join(base, "logs")
        assert cfg.tpt_config.delimiter == "^"
        assert cfg.tpt_config.max_sessions == 8
        assert cfg.tpt_config.charset == TPT_DEFAULT_CHARSET

    def test_use_tpt_for_bulk_false_omits_tpt_config(self, patched_pyodbc):
        cfg = TeradataConnectionConfig.from_config_dict(
            database="d",
            username="u",
            host="h",
            password="p",
            use_tpt_for_bulk=False,
        )
        assert cfg.tpt_config is None
