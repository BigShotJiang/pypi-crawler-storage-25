"""
Tests for the data_validation package (handler, helpers, row/cell validators).

Covers pure helper functions, I/O utilities, and handler routing logic.
"""

import csv
import json
import os
import shutil
import tempfile

import pytest
from unittest.mock import MagicMock, Mock, patch
from contextlib import contextmanager

try:
    from data_exchange_agent.constants import profiler_steps
    from data_exchange_agent.tasks.data_validation.handler import (
        DataValidationHandler,
        FetchResult,
    )
    from data_exchange_agent.tasks.data_validation.helpers import (
        CSV_DELIMITER,
        _needs_temporary_table_flag,
        adapt_sdv_result,
        build_row_table_context,
        resolve_object_type,
        resolve_platform,
    )
    from data_exchange_agent.tasks.data_validation.row_validation import (
        RowValidationHandler,
        _align_row_hash_buffers,
        _fetch_row_hash_chunk_if_active,
        _strip_trailing_same_key,
        _take_prefix_strictly_before_key,
    )
    from data_exchange_agent.tasks.execution_profiler import ExecutionProfiler

    HANDLER_AVAILABLE = True
except ImportError:
    HANDLER_AVAILABLE = False

try:
    import pandas as pd

    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

try:
    from snowflake.snowflake_data_validation.public import ObjectType, Origin, Platform

    SDV_AVAILABLE = True
except ImportError:
    SDV_AVAILABLE = False

try:
    import pyodbc  # noqa: F401

    PYODBC_AVAILABLE = True
except (ImportError, OSError):
    PYODBC_AVAILABLE = False


SKIP_MSG = "data_validation handler or SDV library not available"


# =========================================================================
# Group A: Pure / static functions (no mocking required)
# =========================================================================


class TestDatabaseEngines:
    """Tests for database_engines module functions."""

    def test_is_database_engine_supported(self):
        from data_exchange_agent.data_sources.database_engines import (
            DatabaseEngine,
            is_database_engine_supported,
        )

        assert is_database_engine_supported(DatabaseEngine.ORACLE) is True
        assert is_database_engine_supported(DatabaseEngine.SNOWFLAKE) is True

    def test_get_database_engine_from_string(self):
        from data_exchange_agent.data_sources.database_engines import (
            DatabaseEngine,
            get_database_engine_from_string,
        )

        assert get_database_engine_from_string("oracle") == DatabaseEngine.ORACLE
        assert get_database_engine_from_string("SQLSERVER") == DatabaseEngine.SQLSERVER

    def test_get_database_engine_from_string_invalid(self):
        from data_exchange_agent.data_sources.database_engines import (
            get_database_engine_from_string,
        )

        with pytest.raises(ValueError, match="Unsupported database engine"):
            get_database_engine_from_string("nosql_db")


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestLoadDatatypesMappings:
    """Tests for helpers.load_datatypes_mappings."""

    def test_returns_empty_dict_for_nonexistent_mapping(self):
        from data_exchange_agent.tasks.data_validation.helpers import (
            load_datatypes_mappings,
        )

        with patch(
            "data_exchange_agent.tasks.data_validation.helpers._templates_path",
            return_value="/nonexistent/path",
        ):
            result = load_datatypes_mappings(Platform.REDSHIFT)

        assert result == {}


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestResolvePlatform:
    """Tests for helpers.resolve_platform."""

    def test_known_platforms(self):
        assert resolve_platform("redshift") == Platform.REDSHIFT
        assert resolve_platform("snowflake") == Platform.SNOWFLAKE
        assert resolve_platform("sqlserver") == Platform.SQLSERVER
        assert resolve_platform("sql_server") == Platform.SQLSERVER
        assert resolve_platform("teradata") == Platform.TERADATA

    def test_case_insensitive(self):
        assert resolve_platform("Redshift") == Platform.REDSHIFT
        assert resolve_platform("SNOWFLAKE") == Platform.SNOWFLAKE

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown platform"):
            resolve_platform("mysql")


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestAdaptSdvResult:
    """Tests for helpers.adapt_sdv_result."""

    def test_empty_dataframe_returns_expected_columns(self):
        df = adapt_sdv_result(pd.DataFrame(), "my_table")
        assert list(df.columns) == [
            "VALIDATION_TYPE",
            "TABLE_NAME",
            "COLUMN_VALIDATED",
            "EVALUATION_CRITERIA",
            "SOURCE_VALUE",
            "SNOWFLAKE_VALUE",
            "STATUS",
            "COMMENTS",
        ]
        assert len(df) == 0

    def test_table_column_renamed(self):
        raw = pd.DataFrame(
            {
                "VALIDATION_TYPE": ["schema"],
                "TABLE": ["src_table"],
                "COLUMN_VALIDATED": ["col1"],
                "EVALUATION_CRITERIA": ["type_match"],
                "SOURCE_VALUE": ["INT"],
                "SNOWFLAKE_VALUE": ["NUMBER"],
                "STATUS": ["FAILURE"],
                "COMMENTS": [""],
            }
        )
        result = adapt_sdv_result(raw, "src_table")
        assert "TABLE_NAME" in result.columns
        assert "TABLE" not in result.columns
        assert result["TABLE_NAME"].iloc[0] == "src_table"

    def test_missing_columns_filled(self):
        raw = pd.DataFrame({"VALIDATION_TYPE": ["metrics"], "STATUS": ["SUCCESS"]})
        result = adapt_sdv_result(raw, "t")
        assert result["TABLE_NAME"].iloc[0] == "t"
        assert result["COMMENTS"].iloc[0] == ""

    def test_table_name_injected_when_missing(self):
        raw = pd.DataFrame(
            {
                "VALIDATION_TYPE": ["schema"],
                "COLUMN_VALIDATED": ["c"],
                "EVALUATION_CRITERIA": ["e"],
                "SOURCE_VALUE": ["s"],
                "SNOWFLAKE_VALUE": ["t"],
                "STATUS": ["OK"],
                "COMMENTS": [""],
            }
        )
        result = adapt_sdv_result(raw, "injected")
        assert result["TABLE_NAME"].iloc[0] == "injected"


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestBuildRowTableContext:
    """Tests for helpers.build_row_table_context."""

    def test_three_part_fqn(self):
        ctx = build_row_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.SOURCE,
            table_fqn="db.schema.tbl",
            columns=[],
            index_column_list=["id"],
            chunk_number=2,
            max_failed_rows_number=50,
            row_count=100,
        )
        assert ctx.database_name == "db"
        assert ctx.schema_name == "schema"
        assert ctx.table_name == "tbl"
        assert ctx.row_count == 100
        assert ctx.chunk_number == 2

    def test_two_part_fqn(self):
        ctx = build_row_table_context(
            platform=Platform.REDSHIFT,
            origin=Origin.TARGET,
            table_fqn="schema.tbl",
            columns=[],
            index_column_list=[],
            chunk_number=1,
            max_failed_rows_number=100,
        )
        assert ctx.database_name == ""
        assert ctx.schema_name == "schema"
        assert ctx.table_name == "tbl"

    def test_oracle_two_part_fqn(self):
        ctx = build_row_table_context(
            platform=Platform.ORACLE,
            origin=Origin.SOURCE,
            table_fqn="HR.EMPLOYEES",
            columns=[],
            index_column_list=["id"],
            chunk_number=1,
            max_failed_rows_number=50,
        )
        assert ctx.database_name == ""
        assert ctx.schema_name == "HR"
        assert ctx.table_name == "EMPLOYEES"
        assert ctx.fully_qualified_name == "HR.EMPLOYEES"

    def test_oracle_three_part_fqn_drops_leading_segment(self):
        ctx = build_row_table_context(
            platform=Platform.ORACLE,
            origin=Origin.SOURCE,
            table_fqn="CONNECT.HR.EMPLOYEES",
            columns=[],
            index_column_list=["id"],
            chunk_number=1,
            max_failed_rows_number=50,
        )
        assert ctx.database_name == ""
        assert ctx.schema_name == "HR"
        assert ctx.table_name == "EMPLOYEES"
        assert ctx.fully_qualified_name == "HR.EMPLOYEES"

    def test_one_part_fqn(self):
        ctx = build_row_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.SOURCE,
            table_fqn="just_table",
            columns=[],
            index_column_list=[],
            chunk_number=1,
            max_failed_rows_number=100,
        )
        assert ctx.database_name == ""
        assert ctx.schema_name == ""
        assert ctx.table_name == "just_table"


# =========================================================================
# Group B: I/O functions (minimal mocking)
# =========================================================================


@pytest.mark.skipif(not HANDLER_AVAILABLE, reason=SKIP_MSG)
class TestCleanupTempDir:
    """Tests for DataValidationHandler._cleanup_temp_dir."""

    def test_removes_directory_and_contents(self):
        d = tempfile.mkdtemp()
        open(os.path.join(d, "file.txt"), "w").close()
        DataValidationHandler._cleanup_temp_dir(d)
        assert not os.path.exists(d)

    def test_nonexistent_directory_does_not_raise(self):
        DataValidationHandler._cleanup_temp_dir("/tmp/nonexistent_dir_xyz_abc")


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestWriteL3Csv:
    """Tests for DataValidationHandler._write_l3_csv."""

    def _make_handler(self):
        return DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )

    def test_csv_prepends_workflow_and_metadata_ids(self):
        handler = self._make_handler()
        d = tempfile.mkdtemp()
        try:
            path = handler._write_l3_csv(d, "test.csv", [["a", "b"], ["c", "d"]], 42, 7)
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.reader(f, delimiter=CSV_DELIMITER)
                rows = list(reader)
            assert len(rows) == 2
            assert rows[0][:2] == ["42", "7"]
            assert rows[0][2:] == ["a", "b"]
            assert rows[1][:2] == ["42", "7"]
        finally:
            shutil.rmtree(d)

    def test_empty_data_produces_empty_file(self):
        handler = self._make_handler()
        d = tempfile.mkdtemp()
        try:
            path = handler._write_l3_csv(d, "empty.csv", [], 1, 1)
            with open(path, encoding="utf-8") as f:
                assert f.read() == ""
        finally:
            shutil.rmtree(d)


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestWriteResultCsv:
    """Tests for DataValidationHandler._write_result_csv."""

    def _make_handler(self):
        return DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )

    def test_csv_includes_orchestration_columns(self):
        handler = self._make_handler()
        df = pd.DataFrame(
            {
                "VALIDATION_TYPE": ["schema"],
                "TABLE_NAME": ["t"],
                "STATUS": ["SUCCESS"],
            }
        )
        path = handler._write_result_csv(df, 10, 20)
        try:
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.reader(f, delimiter=CSV_DELIMITER)
                rows = list(reader)
            assert len(rows) == 1
            assert rows[0][0] == "10"
            assert rows[0][1] == "20"
            assert rows[0][2] == "schema"
        finally:
            shutil.rmtree(os.path.dirname(path))

    def test_csv_includes_partition_number_when_set(self):
        handler = self._make_handler()
        df = pd.DataFrame(
            {
                "VALIDATION_TYPE": ["metrics"],
                "TABLE_NAME": ["t"],
                "STATUS": ["SUCCESS"],
            }
        )
        path = handler._write_result_csv(df, 1, 2, partition_number=3)
        try:
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.reader(f, delimiter=CSV_DELIMITER)
                rows = list(reader)
            assert rows[0][2] == "3"
        finally:
            shutil.rmtree(os.path.dirname(path))


# =========================================================================
# Group C: Handler methods (require mocking)
# =========================================================================


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestHandleRouting:
    """Tests for DataValidationHandler.handle() dispatch logic."""

    def _make_handler(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        h._row_validator = Mock()
        h._cell_validator = Mock()
        return h

    def test_row_mode_dispatches_to_row_validator(self):
        h = self._make_handler()
        h._row_validator.handle.return_value = {"status": "success"}
        task = {
            "payload": {
                "validation_type": "row",
                "row_validation_mode": "row",
                "table_name": "t",
            }
        }
        result = h.handle(task)
        h._row_validator.handle.assert_called_once()
        assert result["status"] == "success"

    def test_cell_mode_dispatches_to_cell_validator(self):
        h = self._make_handler()
        h._cell_validator.handle.return_value = {"status": "success"}
        task = {
            "payload": {
                "validation_type": "row",
                "row_validation_mode": "cell",
                "table_name": "t",
            }
        }
        result = h.handle(task)
        h._cell_validator.handle.assert_called_once()
        assert result["status"] == "success"

    def test_unknown_type_returns_error(self):
        h = self._make_handler()
        h._run_source_query = Mock(return_value=pd.DataFrame())
        h._run_target_query = Mock(return_value=pd.DataFrame())
        task = {
            "payload": {
                "validation_type": "nonexistent",
                "table_name": "t",
                "source_query": "",
                "target_query": "",
            }
        }
        result = h.handle(task)
        assert result["status"] == "error"
        assert "Unknown validation_type" in result["details"]

    def test_schema_type_calls_validate_schema(self):
        h = self._make_handler()
        h._run_source_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._run_target_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._upload_to_stage = Mock()
        with patch.object(h, "_validate_schema_sdv") as mock_val:
            mock_val.return_value = pd.DataFrame(
                {
                    "VALIDATION_TYPE": ["schema"],
                    "TABLE_NAME": ["t"],
                    "COLUMN_VALIDATED": ["A"],
                    "EVALUATION_CRITERIA": [""],
                    "SOURCE_VALUE": [""],
                    "SNOWFLAKE_VALUE": [""],
                    "STATUS": ["SUCCESS"],
                    "COMMENTS": [""],
                }
            )
            task = {
                "payload": {
                    "validation_type": "schema",
                    "table_name": "t",
                    "source_query": "SELECT 1",
                    "target_query": "SELECT 1",
                    "source_platform": "redshift",
                }
            }
            result = h.handle(task)
        mock_val.assert_called_once()
        assert result["status"] == "success"

    def test_schema_with_explicit_datatypes_mappings_skips_load(self):
        h = self._make_handler()
        h._run_source_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._run_target_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._upload_to_stage = Mock()
        with (
            patch.object(h, "_validate_schema_sdv") as mock_val,
            patch(
                "data_exchange_agent.tasks.data_validation.handler.load_datatypes_mappings",
            ) as mock_load,
        ):
            mock_val.return_value = pd.DataFrame(
                {
                    "VALIDATION_TYPE": ["schema"],
                    "TABLE_NAME": ["t"],
                    "COLUMN_VALIDATED": ["A"],
                    "EVALUATION_CRITERIA": [""],
                    "SOURCE_VALUE": [""],
                    "SNOWFLAKE_VALUE": [""],
                    "STATUS": ["SUCCESS"],
                    "COMMENTS": [""],
                }
            )
            task = {
                "payload": {
                    "validation_type": "schema",
                    "table_name": "t",
                    "source_query": "SELECT 1",
                    "target_query": "SELECT 1",
                    "source_platform": "redshift",
                    "datatypes_mappings": {"int": "NUMBER"},
                }
            }
            result = h.handle(task)
        mock_load.assert_not_called()
        assert result["status"] == "success"

    def test_metrics_type_calls_validate_metrics(self):
        h = self._make_handler()
        h._run_source_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._run_target_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._upload_to_stage = Mock()
        with patch.object(h, "_validate_metrics_sdv") as mock_val:
            mock_val.return_value = pd.DataFrame(
                {
                    "VALIDATION_TYPE": ["metrics"],
                    "TABLE_NAME": ["t"],
                    "COLUMN_VALIDATED": ["A"],
                    "EVALUATION_CRITERIA": [""],
                    "SOURCE_VALUE": [""],
                    "SNOWFLAKE_VALUE": [""],
                    "STATUS": ["SUCCESS"],
                    "COMMENTS": [""],
                }
            )
            task = {
                "payload": {
                    "validation_type": "metrics",
                    "table_name": "t",
                    "source_query": "SELECT 1",
                    "target_query": "SELECT 1",
                    "source_platform": "redshift",
                }
            }
            result = h.handle(task)
        mock_val.assert_called_once()
        assert result["status"] == "success"


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not SDV_AVAILABLE or not PANDAS_AVAILABLE,
    reason=SKIP_MSG,
)
class TestBatchedMetricsExecution:
    """Tests for _run_batched_queries and batched dispatch in handle()."""

    def _make_handler(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        h._row_validator = Mock()
        h._cell_validator = Mock()
        return h

    def test_batched_queries_concat_results(self):
        h = self._make_handler()
        wide_a = pd.DataFrame([[1]], columns=["c0_m0"])
        wide_b = pd.DataFrame([[2]], columns=["c0_m0"])
        h._run_source_query = Mock(side_effect=[wide_a, wide_b])
        h._run_target_query = Mock(side_effect=[wide_a.copy(), wide_b.copy()])

        shape_a = {"cells": [["A", "min"]], "all_metrics": ["min"]}
        shape_b = {"cells": [["B", "min"]], "all_metrics": ["min"]}
        task = {"payload": {}}
        src_fetch, tgt_fetch = h._run_batched_queries(
            [
                {"query": "SELECT src1", "result_shape": shape_a},
                {"query": "SELECT src2", "result_shape": shape_b},
            ],
            [
                {"query": "SELECT tgt1", "result_shape": shape_a},
                {"query": "SELECT tgt2", "result_shape": shape_b},
            ],
            task,
        )
        assert len(src_fetch.dataframe) == 2
        assert len(tgt_fetch.dataframe) == 2
        assert list(src_fetch.dataframe["COLUMN_VALIDATED"]) == ["A", "B"]
        assert list(src_fetch.dataframe["min"]) == ["1", "2"]
        assert isinstance(src_fetch.elapsed_ms, int) and src_fetch.elapsed_ms >= 0
        assert isinstance(tgt_fetch.elapsed_ms, int) and tgt_fetch.elapsed_ms >= 0

    def test_handle_dispatches_to_batched_when_batches_present(self):
        h = self._make_handler()
        h._upload_to_stage = Mock()
        src_df = pd.DataFrame({"COLUMN_VALIDATED": ["A"], "V": [1]})
        tgt_df = pd.DataFrame({"COLUMN_VALIDATED": ["A"], "V": [1]})
        h._run_batched_queries = Mock(
            return_value=(
                FetchResult(dataframe=src_df, elapsed_ms=0),
                FetchResult(dataframe=tgt_df, elapsed_ms=0),
            )
        )
        with patch.object(h, "_validate_metrics_sdv") as mock_val:
            mock_val.return_value = pd.DataFrame(
                {
                    "VALIDATION_TYPE": ["metrics"],
                    "TABLE_NAME": ["t"],
                    "COLUMN_VALIDATED": ["A"],
                    "EVALUATION_CRITERIA": [""],
                    "SOURCE_VALUE": [""],
                    "SNOWFLAKE_VALUE": [""],
                    "STATUS": ["SUCCESS"],
                    "COMMENTS": [""],
                }
            )
            task = {
                "payload": {
                    "validation_type": "metrics",
                    "table_name": "t",
                    "source_query": "SELECT 1",
                    "target_query": "SELECT 1",
                    "source_platform": "redshift",
                    "source_query_batches": [
                        {
                            "query": "SELECT b1",
                            "result_shape": {
                                "cells": [["A", "min"]],
                                "all_metrics": ["min"],
                            },
                        },
                        {
                            "query": "SELECT b2",
                            "result_shape": {
                                "cells": [["A", "min"]],
                                "all_metrics": ["min"],
                            },
                        },
                    ],
                    "target_query_batches": [
                        {
                            "query": "SELECT b1",
                            "result_shape": {
                                "cells": [["A", "min"]],
                                "all_metrics": ["min"],
                            },
                        },
                        {
                            "query": "SELECT b2",
                            "result_shape": {
                                "cells": [["A", "min"]],
                                "all_metrics": ["min"],
                            },
                        },
                    ],
                }
            }
            result = h.handle(task)
        h._run_batched_queries.assert_called_once()
        assert result["status"] == "success"

    def test_handle_falls_back_to_single_query_without_batches(self):
        h = self._make_handler()
        h._run_source_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._run_target_query = Mock(return_value=pd.DataFrame({"A": [1]}))
        h._upload_to_stage = Mock()
        with patch.object(h, "_validate_metrics_sdv") as mock_val:
            mock_val.return_value = pd.DataFrame(
                {
                    "VALIDATION_TYPE": ["metrics"],
                    "TABLE_NAME": ["t"],
                    "COLUMN_VALIDATED": ["A"],
                    "EVALUATION_CRITERIA": [""],
                    "SOURCE_VALUE": [""],
                    "SNOWFLAKE_VALUE": [""],
                    "STATUS": ["SUCCESS"],
                    "COMMENTS": [""],
                }
            )
            task = {
                "payload": {
                    "validation_type": "metrics",
                    "table_name": "t",
                    "source_query": "SELECT 1",
                    "target_query": "SELECT 1",
                    "source_platform": "redshift",
                }
            }
            result = h.handle(task)
        h._run_source_query.assert_called_once()
        h._run_target_query.assert_called_once()
        assert result["status"] == "success"


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not SDV_AVAILABLE or not PANDAS_AVAILABLE,
    reason=SKIP_MSG,
)
class TestGetTargetColumnMetadata:
    """Tests for RowValidationHandler._get_target_column_metadata."""

    def _make_row_handler(self):
        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        return RowValidationHandler(parent)

    def test_returns_columns_from_information_schema(self):
        rv = self._make_row_handler()
        rv._parent._run_target_query = Mock(
            return_value=pd.DataFrame(
                {
                    "COLUMN_NAME": ["ID", "NAME"],
                    "DATA_TYPE": ["NUMBER", "VARCHAR"],
                }
            )
        )
        result = rv._get_target_column_metadata("db.schema.tbl", [])
        assert len(result) == 2
        assert result[0].name == "ID"
        assert result[0].data_type == "NUMBER"

    def test_falls_back_on_empty_result(self):
        rv = self._make_row_handler()
        rv._parent._run_target_query = Mock(return_value=pd.DataFrame())
        fallback = [Mock(name="col1")]
        result = rv._get_target_column_metadata("db.schema.tbl", fallback)
        assert result is fallback

    def test_falls_back_on_exception(self):
        rv = self._make_row_handler()
        rv._parent._run_target_query = Mock(side_effect=RuntimeError("boom"))
        fallback = [Mock(name="col1")]
        result = rv._get_target_column_metadata("db.schema.tbl", fallback)
        assert result is fallback

    def test_single_part_fqn_returns_fallback(self):
        rv = self._make_row_handler()
        fallback = [Mock(name="col1")]
        result = rv._get_target_column_metadata("just_table", fallback)
        assert result is fallback


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not SDV_AVAILABLE or not PANDAS_AVAILABLE,
    reason=SKIP_MSG,
)
class TestRowValidationHandleEntry:
    """Tests for RowValidationHandler.handle entry-point validation."""

    def _make_row_handler(self):
        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        return RowValidationHandler(parent)

    def test_missing_index_column_list_returns_error(self):
        rv = self._make_row_handler()
        result = rv.handle(
            {},
            {
                "table_name": "t",
                "index_column_list": [],
            },
        )
        assert result["status"] == "error"
        assert "index_column_list" in result["details"]


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not SDV_AVAILABLE or not PANDAS_AVAILABLE,
    reason=SKIP_MSG,
)
class TestRunRowHashPipeline:
    """Tests for RowValidationHandler._run_row_hash_pipeline workflow (inline SELECT path)."""

    def _make_cursor_returning(self, rows):
        """Return a cursor mock that yields ``rows`` once then EOF forever."""
        from itertools import chain, repeat

        cursor = MagicMock()
        cursor.fetchmany.side_effect = chain([rows], repeat([]))
        return cursor

    def _make_pipeline_params(self, source_ctx, target_ctx, source_conn=None):
        """Create RowHashPipelineParams with mocked contexts."""
        from data_exchange_agent.tasks.data_validation.helpers import RowHashPipelineParams

        return RowHashPipelineParams(
            source_conn=source_conn if source_conn is not None else MagicMock(),
            source_ctx=source_ctx,
            target_ctx=target_ctx,
            index_column_list=["ID"],
            target_index_column_list=["ID"],
            source_table_fqn="db.sch.tbl",
            target_table_fqn="db.sch.tbl",
            table_name="tbl",
            workflow_id=1,
            table_metadata_id=1,
            target_id="@stage/path",
            max_failed_rows=100,
        )

    def _make_source_ctx(self):
        """Create a mocked source context."""
        ctx = Mock()
        ctx.database_name = "db"
        ctx.schema_name = "sch"
        ctx.table_name = "tbl"
        ctx.platform = Mock(value="snowflake")
        ctx.columns_to_validate = []
        ctx.use_column_groups = False
        ctx.column_groups = None
        return ctx

    def _make_target_ctx(self):
        """Create a mocked target context."""
        ctx = Mock()
        ctx.database_name = "db"
        ctx.schema_name = "sch"
        ctx.table_name = "tbl"
        ctx.platform = Mock(value="snowflake")
        return ctx

    @staticmethod
    def _make_cursor_mock(rows):
        """
        Return a mock cursor whose fetchmany yields *rows* once then empty.

        Rows must be sorted by index key (ascending) so the streaming
        merge in ``compare_md5_rows`` works correctly.

        ``fetchmany`` is invoked repeatedly per batch window; after the first
        non-empty batch, further calls return ``[]`` forever (EOF).
        """
        from itertools import chain, repeat

        cursor = Mock()
        cursor.fetchmany = Mock(side_effect=chain([rows], repeat([])))
        cursor.execute = Mock()
        cursor.close = Mock()
        return cursor

    def _make_row_handler(self, source_rows=None, target_rows=None):
        """
        Create a RowValidationHandler with mocked parent.

        *source_rows* / *target_rows* are lists of tuples that the
        corresponding cursor's ``fetchmany`` will return.  Each tuple
        should contain ``(key, md5_hash)`` for a single index column.
        """
        source_cursor = self._make_cursor_mock(source_rows or [])
        target_cursor = self._make_cursor_mock(target_rows or [])

        @contextmanager
        def _ctx_get_cursor(**_kw):
            yield target_cursor

        sf_ds = Mock()
        sf_ds.get_cursor = _ctx_get_cursor

        source_conn = Mock()
        source_conn.cursor = Mock(return_value=source_cursor)

        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=sf_ds,
            source_connections_config={},
        )
        parent._execute_source_statement_on_conn = Mock()
        parent._execute_target_statement = Mock()
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/test.csv")
        parent._cleanup_temp_dir = Mock()
        parent._ensure_query_tag = Mock()
        parent._refresh_result_pipes = Mock()

        rv = RowValidationHandler(parent)
        rv._source_conn = source_conn
        return rv, source_conn

    def test_all_rows_match_returns_valid(self):
        """When all row hashes match, summary_is_valid is True."""
        rv, src_conn = self._make_row_handler(
            source_rows=[(1, "abc")],
            target_rows=[(1, "abc")],
        )
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = src_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            result = rv._run_row_hash_pipeline(params)

        assert result["status"] == "success"
        assert "0 diffs" in result["details"]
        summary_call = rv._parent._write_l3_csv.call_args_list[1]
        summary_data = summary_call[0][2][0]
        is_valid = summary_data[8]
        assert is_valid is True

    def test_parallel_row_hash_pipeline_calls_execute_on_source_and_target(self):
        """Parallel producers each run ``execute`` on their own cursor (thread-local)."""
        source_cursor = self._make_cursor_mock([(1, "abc")])
        target_cursor = self._make_cursor_mock([(1, "abc")])

        @contextmanager
        def _ctx_get_cursor(**_kw):
            yield target_cursor

        sf_ds = Mock()
        sf_ds.get_cursor = _ctx_get_cursor
        source_conn = Mock()
        source_conn.cursor = Mock(return_value=source_cursor)

        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=sf_ds,
            source_connections_config={},
        )
        parent._execute_source_statement_on_conn = Mock()
        parent._execute_target_statement = Mock()
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/test.csv")
        parent._cleanup_temp_dir = Mock()
        parent._ensure_query_tag = Mock()
        parent._refresh_result_pipes = Mock()

        rv = RowValidationHandler(parent)
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = source_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            rv._run_row_hash_pipeline(params)

        source_cursor.execute.assert_called_once()
        target_cursor.execute.assert_called_once()

    def test_hash_mismatch_returns_invalid(self):
        """When row hashes differ, summary_is_valid is False."""
        rv, src_conn = self._make_row_handler(
            source_rows=[(1, "abc")],
            target_rows=[(1, "xyz")],
        )
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = src_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            result = rv._run_row_hash_pipeline(params)

        assert result["status"] == "success"
        assert "1 diffs" in result["details"]
        summary_call = rv._parent._write_l3_csv.call_args_list[1]
        summary_data = summary_call[0][2][0]
        is_valid = summary_data[8]
        assert is_valid is False

    def test_missing_target_row_detected(self):
        """Rows in source but not target show as NOT_FOUND_TARGET."""
        rv, src_conn = self._make_row_handler(
            source_rows=[(1, "abc"), (2, "def")],
            target_rows=[(1, "abc")],
        )
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = src_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            result = rv._run_row_hash_pipeline(params)

        assert result["status"] == "success"
        assert result["total"] == 1
        diffs_call = rv._parent._write_l3_csv.call_args_list[0]
        diffs_data = diffs_call[0][2]
        assert len(diffs_data) == 1
        assert diffs_data[0][2] == "NOT_FOUND_TARGET"

    def test_uploads_only_diffs_and_summary(self):
        """Verify only 2 CSV files are uploaded."""
        rv, src_conn = self._make_row_handler(
            source_rows=[(1, "abc")],
            target_rows=[(1, "abc")],
        )
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = src_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            rv._run_row_hash_pipeline(params)

        csv_calls = rv._parent._write_l3_csv.call_args_list
        filenames = [call[0][1] for call in csv_calls]
        assert "diffs.csv" in filenames
        assert "summary.csv" in filenames
        assert len(filenames) == 2

        upload_calls = rv._parent._upload_to_stage.call_args_list
        upload_paths = [call[0][1] for call in upload_calls]
        assert "@stage/path/diffs" in upload_paths
        assert "@stage/path/summary" in upload_paths
        assert len(upload_paths) == 2

    def test_execution_profile_records_row_hash_pipeline_steps(self):
        """Profiler JSON includes per-side fetch wall timings and compare-rows."""
        rv, src_conn = self._make_row_handler(
            source_rows=[(1, "abc")],
            target_rows=[(1, "abc")],
        )
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = src_conn
        profiler = ExecutionProfiler()
        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            rv._run_row_hash_pipeline(params, profiler=profiler)

        profile = json.loads(profiler.to_json())
        by_name = {name: ms for name, ms in profile}
        assert profiler_steps.EXECUTE_SOURCE_QUERY in by_name
        assert profiler_steps.EXECUTE_TARGET_QUERY in by_name
        assert profiler_steps.FETCH_SOURCE_RESULTS in by_name
        assert profiler_steps.FETCH_TARGET_RESULTS in by_name
        assert profiler_steps.COMPARE_ROWS in by_name
        assert by_name[profiler_steps.COMPARE_ROWS] >= 0

    def test_batched_pipeline_multi_chunk_matches_single_stream(self):
        """Split cursor data across fetchmany chunks; counts match one-shot merge."""
        from itertools import chain, repeat

        from snowflake.snowflake_data_validation.validation.row_data_validator import (
            compare_md5_rows,
        )

        src_all = [((i,), str(i * 7)) for i in range(1, 9)]
        tgt_all = list(src_all)
        source_cursor = Mock()
        source_cursor.fetchmany = Mock(
            side_effect=chain([src_all[:4], src_all[4:]], repeat([])),
        )
        source_cursor.execute = Mock()
        source_cursor.close = Mock()
        source_cursor.arraysize = 20_000
        target_cursor = Mock()
        target_cursor.fetchmany = Mock(
            side_effect=chain([tgt_all[:3], tgt_all[3:]], repeat([])),
        )
        target_cursor.execute = Mock()
        target_cursor.arraysize = 20_000

        @contextmanager
        def _ctx_get_cursor(**_kw):
            yield target_cursor

        sf_ds = Mock()
        sf_ds.get_cursor = _ctx_get_cursor
        source_conn = Mock()
        source_conn.cursor = Mock(return_value=source_cursor)
        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=sf_ds,
            source_connections_config={},
        )
        parent._execute_source_statement_on_conn = Mock()
        parent._execute_target_statement = Mock()
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/test.csv")
        parent._cleanup_temp_dir = Mock()
        parent._ensure_query_tag = Mock()
        parent._refresh_result_pipes = Mock()
        rv = RowValidationHandler(parent)
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = source_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            result = rv._run_row_hash_pipeline(params)

        full_diffs, sc, tc = compare_md5_rows(iter(src_all), iter(tgt_all), max_diffs=100)
        assert result["status"] == "success"
        assert sc == len(src_all) and tc == len(tgt_all)
        assert len(full_diffs) == 0

    def test_fast_forward_source_lower_first_chunk_matches_single_stream(self):
        """When the first source keys are all below the first target keys, batched merge matches one-shot."""
        from itertools import chain, repeat

        from snowflake.snowflake_data_validation.validation.row_data_validator import (
            compare_md5_rows,
        )

        src_all = [((i,), f"h{i}") for i in range(1, 6)]
        tgt_all = [((i,), f"h{i}") for i in range(10, 13)]
        golden, gsc, gtc = compare_md5_rows(iter(src_all), iter(tgt_all), max_diffs=100)

        source_cursor = Mock()
        source_cursor.fetchmany = Mock(side_effect=chain([src_all], repeat([])))
        source_cursor.execute = Mock()
        source_cursor.close = Mock()
        source_cursor.arraysize = 20_000
        target_cursor = Mock()
        target_cursor.fetchmany = Mock(side_effect=chain([tgt_all], repeat([])))
        target_cursor.execute = Mock()
        target_cursor.close = Mock()
        target_cursor.arraysize = 20_000

        @contextmanager
        def _ctx_get_cursor(**_kw):
            yield target_cursor

        sf_ds = Mock()
        sf_ds.get_cursor = _ctx_get_cursor
        source_conn = Mock()
        source_conn.cursor = Mock(return_value=source_cursor)
        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=sf_ds,
            source_connections_config={},
        )
        parent._execute_source_statement_on_conn = Mock()
        parent._execute_target_statement = Mock()
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/test.csv")
        parent._cleanup_temp_dir = Mock()
        parent._ensure_query_tag = Mock()
        parent._refresh_result_pipes = Mock()
        rv = RowValidationHandler(parent)
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = source_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            result = rv._run_row_hash_pipeline(params)

        assert result["status"] == "success"
        assert result["total"] == len(golden)
        assert gsc == len(src_all) and gtc == len(tgt_all)

    def test_fast_forward_target_lower_first_chunk_matches_single_stream(self):
        """Symmetric: first target keys are all below first source keys."""
        from itertools import chain, repeat

        from snowflake.snowflake_data_validation.validation.row_data_validator import (
            compare_md5_rows,
        )

        src_all = [((i,), f"h{i}") for i in range(10, 13)]
        tgt_all = [((i,), f"h{i}") for i in range(1, 6)]
        golden, gsc, gtc = compare_md5_rows(iter(src_all), iter(tgt_all), max_diffs=100)

        source_cursor = Mock()
        source_cursor.fetchmany = Mock(side_effect=chain([src_all], repeat([])))
        source_cursor.execute = Mock()
        source_cursor.close = Mock()
        source_cursor.arraysize = 20_000
        target_cursor = Mock()
        target_cursor.fetchmany = Mock(side_effect=chain([tgt_all], repeat([])))
        target_cursor.execute = Mock()
        target_cursor.close = Mock()
        target_cursor.arraysize = 20_000

        @contextmanager
        def _ctx_get_cursor(**_kw):
            yield target_cursor

        sf_ds = Mock()
        sf_ds.get_cursor = _ctx_get_cursor
        source_conn = Mock()
        source_conn.cursor = Mock(return_value=source_cursor)
        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=sf_ds,
            source_connections_config={},
        )
        parent._execute_source_statement_on_conn = Mock()
        parent._execute_target_statement = Mock()
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/test.csv")
        parent._cleanup_temp_dir = Mock()
        parent._ensure_query_tag = Mock()
        parent._refresh_result_pipes = Mock()
        rv = RowValidationHandler(parent)
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = source_conn

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            result = rv._run_row_hash_pipeline(params)

        assert result["status"] == "success"
        assert result["total"] == len(golden)
        assert gsc == len(src_all) and gtc == len(tgt_all)

    def test_max_failed_rows_zero_skips_merge_batches(self):
        """No fetchmany after execute when max_failed_rows is 0 (remaining diffs cap)."""
        from itertools import chain, repeat

        source_cursor = Mock()
        source_cursor.fetchmany = Mock(side_effect=chain([[(1, "a")]], repeat([])))
        source_cursor.execute = Mock()
        source_cursor.close = Mock()
        source_cursor.arraysize = 20_000
        target_cursor = Mock()
        target_cursor.fetchmany = Mock(side_effect=chain([[(1, "a")]], repeat([])))
        target_cursor.execute = Mock()
        target_cursor.arraysize = 20_000

        @contextmanager
        def _ctx_get_cursor(**_kw):
            yield target_cursor

        sf_ds = Mock()
        sf_ds.get_cursor = _ctx_get_cursor
        source_conn = Mock()
        source_conn.cursor = Mock(return_value=source_cursor)
        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=sf_ds,
            source_connections_config={},
        )
        parent._execute_source_statement_on_conn = Mock()
        parent._execute_target_statement = Mock()
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/test.csv")
        parent._cleanup_temp_dir = Mock()
        parent._ensure_query_tag = Mock()
        parent._refresh_result_pipes = Mock()
        rv = RowValidationHandler(parent)
        source_ctx = self._make_source_ctx()
        target_ctx = self._make_target_ctx()
        params = self._make_pipeline_params(source_ctx, target_ctx)
        params.source_conn = source_conn
        params.max_failed_rows = 0

        with patch("data_exchange_agent.tasks.data_validation.row_validation.generate_row_md5_select_query") as mock_gen:
            mock_gen.return_value = Mock(query_string="SELECT ...")
            rv._run_row_hash_pipeline(params)

        source_cursor.fetchmany.assert_not_called()
        target_cursor.fetchmany.assert_not_called()


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not SDV_AVAILABLE or not PANDAS_AVAILABLE,
    reason=SKIP_MSG,
)
class TestBatchedRowHashHelpers:
    """Pure helpers for batched row-hash merge windows."""

    def test_strip_trailing_same_key_defers_suffix_when_not_exhausted(self):
        rows = [((1,), "a"), ((2,), "b"), ((2,), "c")]
        work, tail = _strip_trailing_same_key(rows, has_reached_cursor_end=False)
        assert work == [((1,), "a")]
        assert tail == [((2,), "b"), ((2,), "c")]

    def test_strip_trailing_same_key_when_exhausted_keeps_trailing_group(self):
        rows = [((1,), "a"), ((2,), "b"), ((2,), "c")]
        work, tail = _strip_trailing_same_key(rows, has_reached_cursor_end=True)
        assert work == rows and tail == []

    def test_take_prefix_strictly_before_key_splits_at_bound(self):
        rows = [((1,), "a"), ((3,), "b"), ((5,), "c")]
        pre, rest = _take_prefix_strictly_before_key(rows, (4,))
        assert pre == [((1,), "a"), ((3,), "b")]
        assert rest == [((5,), "c")]

    def test_take_prefix_strictly_before_key_empty_or_all_before(self):
        assert _take_prefix_strictly_before_key([], (1,)) == ([], [])
        rows = [((1,), "a"), ((2,), "b")]
        assert _take_prefix_strictly_before_key(rows, (1,)) == ([], rows)
        assert _take_prefix_strictly_before_key(rows, (99,)) == (rows, [])

    def test_align_min_last_key_moves_roll_to_defer(self):
        work_s = [((1,), "a"), ((2,), "b")]
        work_t = [((1,), "a")] + [((k,), "x") for k in range(2, 8)]
        source_core, target_core, source_roll, target_roll = _align_row_hash_buffers(
            work_s, work_t, source_cursor_exhausted=False, target_cursor_exhausted=False
        )
        assert source_core == work_s
        assert target_core == [((1,), "a"), ((2,), "x")]
        assert target_roll == [((k,), "x") for k in range(3, 8)]
        assert source_roll == []

    def test_fetch_row_hash_chunk_consumes_cursor_until_empty(self):
        from itertools import chain, repeat

        big = [(i, "x") for i in range(30)]
        cursor = Mock()
        cursor.fetchmany = Mock(side_effect=chain([big[:10]], [[]], repeat([])))
        chunk = _fetch_row_hash_chunk_if_active(
            cursor,
            has_reached_cursor_end=False,
            profiler=ExecutionProfiler(),
            fetch_step=profiler_steps.FETCH_SOURCE_RESULTS,
        )
        assert len(chunk) == 10
        assert chunk[0][0] == (0,)
        assert cursor.fetchmany.call_count >= 1

    def test_fetch_row_hash_chunk_skips_when_already_exhausted(self):
        cursor = Mock()
        cursor.fetchmany = Mock(return_value=[(1, "a")])
        chunk = _fetch_row_hash_chunk_if_active(
            cursor,
            has_reached_cursor_end=True,
            profiler=ExecutionProfiler(),
            fetch_step=profiler_steps.FETCH_SOURCE_RESULTS,
        )
        assert chunk == []
        cursor.fetchmany.assert_not_called()


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not SDV_AVAILABLE or not PANDAS_AVAILABLE,
    reason=SKIP_MSG,
)
class TestCellValidationHandle:
    """Tests for CellValidationHandler.handle."""

    def test_uppercases_target_columns_and_uploads(self):
        from data_exchange_agent.tasks.data_validation.cell_validation import (
            CellValidationHandler,
        )

        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"redshift": Mock(connection_string="fake")},
        )
        parent._upload_to_stage = Mock()

        source_df = pd.DataFrame({"ID": [1, 2], "NAME": ["a", "b"]})
        target_df = pd.DataFrame({"id": [1, 2], "name": ["a", "b"]})

        parent._run_source_query = Mock(return_value=source_df)
        parent._run_target_query = Mock(return_value=target_df)

        mock_validation = Mock()
        mock_validation.is_valid = True
        mock_validation.results_dataframe = pd.DataFrame()

        cv = CellValidationHandler(parent)
        with patch(
            "data_exchange_agent.tasks.data_validation.cell_validation.validate_cell",
            return_value=(mock_validation, []),
        ):
            result = cv.handle(
                {"payload": {"source_platform": "redshift"}},
                {
                    "table_name": "t",
                    "source_query": "SELECT 1",
                    "target_query": "SELECT 1",
                    "source_platform": "redshift",
                    "index_column_list": ["ID"],
                },
            )

        assert result["status"] == "success"
        assert result["total"] == 0
        parent._upload_to_stage.assert_called_once()

    def test_non_empty_diffs_are_vectorized_to_csv(self):
        from data_exchange_agent.tasks.data_validation.cell_validation import (
            CellValidationHandler,
        )

        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"redshift": Mock(connection_string="fake")},
        )
        source_df = pd.DataFrame({"ID": [1, 2], "NAME": ["a", "b"]})
        target_df = pd.DataFrame({"id": [1, 2], "name": ["a", "x"]})
        parent._run_source_query = Mock(return_value=source_df)
        parent._run_target_query = Mock(return_value=target_df)
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/diffs.csv")
        parent._cleanup_temp_dir = Mock()

        mock_validation = Mock()
        mock_validation.is_valid = False
        mock_validation.results_dataframe = pd.DataFrame(
            {
                "ROW": [1, 2],
                "COLUMN": ["col_a", "col_b"],
                "SOURCE_VALUE": ["src1", "src2"],
                "TARGET_VALUE": ["tgt1", "tgt2"],
            }
        )

        cv = CellValidationHandler(parent)
        with patch(
            "data_exchange_agent.tasks.data_validation.cell_validation.validate_cell",
            return_value=(mock_validation, []),
        ):
            result = cv.handle(
                {"payload": {"source_platform": "redshift"}},
                {
                    "table_name": "t",
                    "source_query": "SELECT 1",
                    "target_query": "SELECT 1",
                    "source_platform": "redshift",
                    "index_column_list": ["ID"],
                },
            )

        assert result["status"] == "success"
        assert result["total"] == 2

        call_args = parent._write_l3_csv.call_args
        diffs_data = call_args[0][2]
        assert len(diffs_data) == 2
        assert diffs_data[0][0] == "t"
        assert diffs_data[0][2] == "col_a"

    def test_duplicate_index_keys_succeeds_with_dup_info(self):
        """Duplicate index keys are filtered out and reported alongside cell diffs."""
        from data_exchange_agent.constants import task_keys
        from data_exchange_agent.tasks.data_validation.cell_validation import (
            CellValidationHandler,
        )

        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"redshift": Mock(connection_string="fake")},
        )
        parent._upload_to_stage = Mock()
        parent._write_l3_csv = Mock(return_value="/tmp/diffs.csv")
        parent._cleanup_temp_dir = Mock()
        parent._refresh_result_pipes = Mock()

        # Source has duplicate ID=1; target is clean.
        source_df = pd.DataFrame({"ID": [1, 1, 2], "NAME": ["a", "a_dup", "b"]})
        target_df = pd.DataFrame({"id": [1, 2], "name": ["a", "b"]})
        parent._run_source_query = Mock(return_value=source_df)
        parent._run_target_query = Mock(return_value=target_df)

        cv = CellValidationHandler(parent)
        result = cv.handle(
            {"payload": {"source_platform": "redshift"}},
            {
                "table_name": "t",
                "source_query": "SELECT 1",
                "target_query": "SELECT 1",
                "source_platform": "redshift",
                "index_column_list": ["ID"],
            },
        )

        assert result[task_keys.STATUS] == "success"
        # Diffs CSV and row-diffs CSV should both be written and uploaded.
        assert parent._write_l3_csv.call_count >= 1
        assert parent._upload_to_stage.call_count >= 1


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestValidateSchemaSDV:
    """Tests for DataValidationHandler._validate_schema_sdv."""

    def test_delegates_to_sdv_and_adapts_result(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        source_df = pd.DataFrame({"ID": [1], "NAME": ["a"]})
        target_df = pd.DataFrame({"ID": [1], "NAME": ["a"]})

        mock_validation = Mock()
        mock_validation.is_valid = True
        mock_validation.results_dataframe = pd.DataFrame(
            {
                "VALIDATION_TYPE": ["schema"],
                "TABLE_NAME": ["t"],
                "COLUMN_VALIDATED": ["ID"],
                "EVALUATION_CRITERIA": ["DATA_TYPE"],
                "SOURCE_VALUE": ["int"],
                "SNOWFLAKE_VALUE": ["NUMBER"],
                "STATUS": ["SUCCESS"],
            }
        )
        table_ctx = Mock()

        with patch(
            "data_exchange_agent.tasks.data_validation.handler.validate_schema",
            return_value=mock_validation,
        ) as mock_vs:
            result = h._validate_schema_sdv(source_df, target_df, table_ctx, {}, {}, "t")
            mock_vs.assert_called_once()

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestValidateMetricsSDV:
    """Tests for DataValidationHandler._validate_metrics_sdv."""

    def test_delegates_to_sdv_and_adapts_result(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        source_df = pd.DataFrame({"ID": [1, 2, 3]})
        target_df = pd.DataFrame({"ID": [1, 2, 3]})

        mock_validation = Mock()
        mock_validation.is_valid = True
        mock_validation.results_dataframe = pd.DataFrame(
            {
                "VALIDATION_TYPE": ["metrics"],
                "TABLE_NAME": ["t"],
                "COLUMN_VALIDATED": ["ID"],
                "EVALUATION_CRITERIA": ["SUM"],
                "SOURCE_VALUE": ["6"],
                "SNOWFLAKE_VALUE": ["6"],
                "STATUS": ["SUCCESS"],
            }
        )
        table_ctx = Mock()

        with patch(
            "data_exchange_agent.tasks.data_validation.handler.validate_metrics",
            return_value=mock_validation,
        ) as mock_vm:
            result = h._validate_metrics_sdv(source_df, target_df, table_ctx, {}, 0.001, "t")
            mock_vm.assert_called_once()

        assert isinstance(result, pd.DataFrame)
        assert len(result) == 1

    def test_uppercases_column_validated_when_present(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        source_df = pd.DataFrame({"COLUMN_VALIDATED": ["id", "name"], "VALUE": [6, 3]})
        target_df = pd.DataFrame({"COLUMN_VALIDATED": ["id", "name"], "VALUE": [6, 3]})

        mock_validation = Mock()
        mock_validation.is_valid = True
        mock_validation.results_dataframe = pd.DataFrame()
        table_ctx = Mock()

        with patch(
            "data_exchange_agent.tasks.data_validation.handler.validate_metrics",
            return_value=mock_validation,
        ):
            h._validate_metrics_sdv(source_df, target_df, table_ctx, {}, 0.001, "t")


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestRunTargetQuery:
    """Tests for DataValidationHandler._run_target_query."""

    def test_returns_empty_dataframe_for_empty_query(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        result = h._run_target_query("")
        assert isinstance(result, pd.DataFrame)
        assert result.empty

    def test_executes_query_and_returns_dataframe(self):
        mock_cursor = Mock()
        mock_cursor.description = [("COL_A",), ("COL_B",)]
        mock_cursor.fetchmany.side_effect = [[(1, "x"), (2, "y")], []]

        mock_ds = Mock()
        mock_ds.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_ds.get_cursor.return_value.__exit__ = Mock(return_value=False)

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
        )
        result = h._run_target_query("SELECT 1")
        assert len(result) == 2
        assert list(result.columns) == ["COL_A", "COL_B"]


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestUploadToStage:
    """Tests for DataValidationHandler._upload_to_stage."""

    def test_executes_put_command(self):
        mock_cursor = Mock()
        mock_ds = Mock()
        mock_ds.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_ds.get_cursor.return_value.__exit__ = Mock(return_value=False)

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
        )
        h._upload_to_stage("/tmp/file.csv", "stage/path")
        mock_cursor.execute.assert_called_once()
        assert "PUT" in mock_cursor.execute.call_args[0][0]


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestRunSourceQuery:
    """Tests for DataValidationHandler._run_source_query."""

    def test_returns_empty_dataframe_for_empty_query(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        result = h._run_source_query("", {})
        assert isinstance(result, pd.DataFrame)
        assert result.empty

    def test_raises_for_unknown_engine(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"redshift": Mock()},
        )
        task = {"payload": {"source_platform": "oracle"}}
        with pytest.raises(ValueError, match="Engine 'oracle'.*not found"):
            h._run_source_query("SELECT 1", task)

    @pytest.mark.skipif(not PYODBC_AVAILABLE, reason="pyodbc not loadable")
    @patch("pyodbc.connect")
    @patch("data_exchange_agent.tasks.data_validation.handler.register_output_converters_for_odbc_engine")
    def test_executes_query_via_odbc(self, mock_register, mock_connect):
        mock_cursor = Mock()
        mock_cursor.description = [("COL_A",), ("COL_B",)]
        mock_cursor.fetchmany.side_effect = [[("v1", "v2")], []]
        mock_conn = Mock()
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn

        mock_cfg = Mock()
        mock_cfg.connection_string = "DSN=test"

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"sqlserver": mock_cfg},
        )
        task = {"payload": {"source_platform": "sqlserver"}}
        result = h._run_source_query("SELECT 1", task)

        assert list(result.columns) == ["COL_A", "COL_B"]
        assert len(result) == 1
        mock_conn.close.assert_called_once()

    @patch("data_exchange_agent.tasks.data_validation.handler.open_source_connection")
    def test_run_source_query_normalizes_teradata_payload_casing(self, mock_open):
        """Orchestrator sends ``Teradata``; config keys are lowercase (``teradata``)."""
        mock_cursor = Mock()
        mock_cursor.description = [("ID",)]
        mock_cursor.fetchmany.side_effect = [[(1,)], []]
        mock_conn = Mock()
        mock_conn.cursor.return_value = mock_cursor
        mock_open.return_value = mock_conn

        mock_cfg = Mock()
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"teradata": mock_cfg},
        )
        task = {"payload": {"source_platform": "Teradata"}}
        result = h._run_source_query("SELECT 1", task)

        mock_open.assert_called_once_with("teradata", mock_cfg)
        assert list(result.columns) == ["ID"]
        assert len(result) == 1
        mock_conn.close.assert_called_once()


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not PANDAS_AVAILABLE or not PYODBC_AVAILABLE,
    reason=SKIP_MSG,
)
class TestOpenSourceConnection:
    """Tests for DataValidationHandler._open_source_connection."""

    @patch("pyodbc.connect")
    @patch(
        "data_exchange_agent.tasks.data_validation.handler.is_pyodbc_connection",
        return_value=True,
    )
    @patch("data_exchange_agent.tasks.data_validation.handler.register_output_converters_for_odbc_engine")
    def test_returns_connection(self, mock_register, mock_is_pyodbc, mock_connect):
        mock_conn = Mock()
        mock_connect.return_value = mock_conn
        mock_cfg = Mock()
        mock_cfg.connection_string = "DSN=test"

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"sqlserver": mock_cfg},
        )
        task = {"payload": {"source_platform": "sqlserver"}}
        conn = h._open_source_connection(task)

        assert conn is mock_conn
        mock_register.assert_called_once_with("sqlserver", mock_conn)

    @patch("pyodbc.connect")
    @patch(
        "data_exchange_agent.tasks.data_validation.handler.is_pyodbc_connection",
        return_value=True,
    )
    @patch("data_exchange_agent.tasks.data_validation.handler.register_output_converters_for_odbc_engine")
    def test_executes_use_database_command(self, mock_register, mock_is_pyodbc, mock_connect):
        mock_cursor = Mock()
        mock_conn = Mock()
        mock_conn.cursor.return_value = mock_cursor
        mock_connect.return_value = mock_conn
        mock_cfg = Mock()
        mock_cfg.connection_string = "DSN=test"

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"sqlserver": mock_cfg},
        )
        task = {
            "payload": {
                "source_platform": "sqlserver",
                "use_database_command": "USE mydb",
            }
        }
        h._open_source_connection(task)

        mock_cursor.execute.assert_called_once_with("USE mydb")
        mock_cursor.close.assert_called_once()


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestExecuteTargetStatement:
    """Tests for DataValidationHandler._execute_target_statement."""

    def test_executes_statement_via_cursor(self):
        mock_cursor = Mock()
        mock_ds = Mock()
        mock_ds.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_ds.get_cursor.return_value.__exit__ = Mock(return_value=False)

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
        )
        h._execute_target_statement("CREATE TABLE t (id INT)")
        mock_cursor.execute.assert_called_once_with("CREATE TABLE t (id INT)")


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestGetTargetRowCount:
    """Tests for DataValidationHandler._get_target_row_count."""

    def test_returns_row_count(self):
        mock_cursor = Mock()
        mock_cursor.fetchone.return_value = (42,)
        mock_ds = Mock()
        mock_ds.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_ds.get_cursor.return_value.__exit__ = Mock(return_value=False)

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
        )
        assert h._get_target_row_count("db.schema.table") == 42

    def test_returns_zero_for_none_result(self):
        mock_cursor = Mock()
        mock_cursor.fetchone.return_value = None
        mock_ds = Mock()
        mock_ds.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_ds.get_cursor.return_value.__exit__ = Mock(return_value=False)

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
        )
        assert h._get_target_row_count("db.schema.table") == 0


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestExecuteSourceStatementOnConn:
    """Tests for DataValidationHandler._execute_source_statement_on_conn."""

    def test_executes_and_closes_cursor(self):
        mock_conn = Mock()
        mock_cursor = Mock()
        mock_conn.cursor.return_value = mock_cursor

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        h._execute_source_statement_on_conn(mock_conn, "DROP TABLE tmp")
        mock_cursor.execute.assert_called_once_with("DROP TABLE tmp")
        mock_cursor.close.assert_called_once()


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestRunSourceQueryOnConn:
    """Tests for DataValidationHandler._run_source_query_on_conn."""

    def test_returns_dataframe_with_uppercased_columns(self):
        mock_conn = Mock()
        mock_cursor = Mock()
        mock_cursor.description = [("col_a",), ("col_b",)]
        mock_cursor.fetchmany.side_effect = [[(1, "x"), (2, "y")], []]
        mock_conn.cursor.return_value = mock_cursor

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        result = h._run_source_query_on_conn(mock_conn, "SELECT 1")
        assert list(result.columns) == ["COL_A", "COL_B"]
        assert len(result) == 2
        mock_cursor.close.assert_called_once()


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not SDV_AVAILABLE or not PANDAS_AVAILABLE,
    reason=SKIP_MSG,
)
class TestSourceColumnReordering:
    """Tests for source-column reordering to match target ordinal position."""

    def _make_row_handler(self):
        parent = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        return RowValidationHandler(parent)

    def test_columns_reordered_to_match_target(self):
        """Source columns must be sorted by target ordinal position."""
        from snowflake.snowflake_data_validation.public import ColumnMetadata

        source_unordered = [
            ColumnMetadata(
                name="B",
                data_type="VARCHAR",
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
            ColumnMetadata(
                name="A",
                data_type="NUMBER",
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
            ColumnMetadata(
                name="C",
                data_type="DATE",
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
        ]
        target_columns = [
            ColumnMetadata(
                name="A",
                data_type="NUMBER",
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
            ColumnMetadata(
                name="B",
                data_type="VARCHAR",
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
            ColumnMetadata(
                name="C",
                data_type="DATE",
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
        ]

        target_col_order = {col.name.upper(): i for i, col in enumerate(target_columns)}
        sorted_columns = sorted(
            source_unordered,
            key=lambda c: target_col_order.get(c.name.upper(), len(target_col_order)),
        )

        assert [c.name for c in sorted_columns] == ["A", "B", "C"]

    def test_columns_with_missing_target_entry_sort_last(self):
        """Source columns not present in target should sort to the end."""
        from snowflake.snowflake_data_validation.public import ColumnMetadata

        source_unordered = [
            ColumnMetadata(
                name="EXTRA",
                data_type="VARCHAR",
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
            ColumnMetadata(
                name="A",
                data_type="NUMBER",
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
        ]
        target_columns = [
            ColumnMetadata(
                name="A",
                data_type="NUMBER",
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
        ]

        target_col_order = {col.name.upper(): i for i, col in enumerate(target_columns)}
        sorted_columns = sorted(
            source_unordered,
            key=lambda c: target_col_order.get(c.name.upper(), len(target_col_order)),
        )

        assert sorted_columns[0].name == "A"
        assert sorted_columns[1].name == "EXTRA"

    def test_case_insensitive_ordering(self):
        """Column name matching for ordering should be case-insensitive."""
        from snowflake.snowflake_data_validation.public import ColumnMetadata

        source_unordered = [
            ColumnMetadata(
                name="col_b",
                data_type="VARCHAR",
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
            ColumnMetadata(
                name="col_a",
                data_type="NUMBER",
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
        ]
        target_columns = [
            ColumnMetadata(
                name="COL_A",
                data_type="NUMBER",
                nullable=False,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
            ColumnMetadata(
                name="COL_B",
                data_type="VARCHAR",
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            ),
        ]

        target_col_order = {col.name.upper(): i for i, col in enumerate(target_columns)}
        sorted_columns = sorted(
            source_unordered,
            key=lambda c: target_col_order.get(c.name.upper(), len(target_col_order)),
        )

        assert [c.name for c in sorted_columns] == ["col_a", "col_b"]


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestGetRowCountOnConn:
    """Tests for DataValidationHandler._get_row_count_on_conn."""

    def test_returns_count(self):
        mock_conn = Mock()
        mock_cursor = Mock()
        mock_cursor.fetchone.return_value = (100,)
        mock_conn.cursor.return_value = mock_cursor

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        assert h._get_row_count_on_conn(mock_conn, "db.t") == 100
        mock_cursor.close.assert_called_once()

    def test_returns_zero_when_no_row(self):
        mock_conn = Mock()
        mock_cursor = Mock()
        mock_cursor.fetchone.return_value = None
        mock_conn.cursor.return_value = mock_cursor

        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        assert h._get_row_count_on_conn(mock_conn, "db.t") == 0


@pytest.mark.skipif(not HANDLER_AVAILABLE, reason=SKIP_MSG)
class TestEnsureQueryTag:
    """Tests for DataValidationHandler._ensure_query_tag."""

    def test_sets_tag_when_present(self):
        mock_ds = Mock()
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
            query_tag='{"task": "t1"}',
        )
        h._ensure_query_tag()
        mock_ds.set_query_tag.assert_called_once_with('{"task": "t1"}')

    def test_noop_when_no_tag(self):
        mock_ds = Mock()
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
        )
        h._ensure_query_tag()
        mock_ds.set_query_tag.assert_not_called()


@pytest.mark.skipif(not HANDLER_AVAILABLE, reason=SKIP_MSG)
class TestResolveSourceEngineConfigKey:
    """Tests for DataValidationHandler._resolve_source_engine_config_key."""

    def test_resolves_known_engine(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"sqlserver": Mock()},
        )
        assert h._resolve_source_engine_config_key("SqlServer") == "sqlserver"

    def test_raises_for_empty_platform(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        with pytest.raises(ValueError, match="source_platform is empty"):
            h._resolve_source_engine_config_key("")

    def test_raises_for_unknown_platform(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        with pytest.raises(ValueError, match="Unsupported source_platform"):
            h._resolve_source_engine_config_key("mongodb")

    def test_raises_when_engine_not_in_config(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"redshift": Mock()},
        )
        with pytest.raises(ValueError, match="not found in source connections"):
            h._resolve_source_engine_config_key("sqlserver")


@pytest.mark.skipif(not HANDLER_AVAILABLE or not PANDAS_AVAILABLE, reason=SKIP_MSG)
class TestHandleExceptionReturnsError:
    """Tests for error handling in the handle() method."""

    def test_exception_in_source_query_returns_error(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={"redshift": Mock()},
        )
        h._run_source_query = Mock(side_effect=RuntimeError("connection refused"))
        h._run_target_query = Mock(return_value=pd.DataFrame())
        task = {
            "payload": {
                "validation_type": "schema",
                "table_name": "t",
                "source_query": "SELECT 1",
                "target_query": "SELECT 1",
                "source_platform": "redshift",
            }
        }
        result = h.handle(task)
        assert result["status"] == "error"
        assert "connection refused" in result["details"]


@pytest.mark.skipif(not HANDLER_AVAILABLE, reason=SKIP_MSG)
class TestHandlerInit:
    """Tests for DataValidationHandler initialization."""

    def test_stores_query_tag(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
            query_tag='{"t": 1}',
        )
        assert h._query_tag == '{"t": 1}'

    def test_default_no_query_tag(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        assert h._query_tag is None

    def test_creates_row_and_cell_validators(self):
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=Mock(),
            source_connections_config={},
        )
        assert h._row_validator is not None
        assert h._cell_validator is not None


@pytest.mark.skipif(not HANDLER_AVAILABLE, reason=SKIP_MSG)
class TestRefreshResultPipes:
    """Tests for ``DataValidationHandler._refresh_result_pipes``."""

    def _make_handler_with_cursor(self):
        mock_cursor = Mock()
        mock_ds = Mock()
        mock_ds.get_cursor.return_value.__enter__ = Mock(return_value=mock_cursor)
        mock_ds.get_cursor.return_value.__exit__ = Mock(return_value=False)
        h = DataValidationHandler(
            logger=Mock(),
            snowflake_datasource=mock_ds,
            source_connections_config={},
        )
        return h, mock_cursor

    def test_none_payload_skips_refresh(self):
        h, mock_cursor = self._make_handler_with_cursor()
        h._refresh_result_pipes(None)
        mock_cursor.execute.assert_not_called()

    def test_empty_list_skips_refresh(self):
        h, mock_cursor = self._make_handler_with_cursor()
        h._refresh_result_pipes([])
        mock_cursor.execute.assert_not_called()

    def test_issues_one_refresh_per_pipe(self):
        h, mock_cursor = self._make_handler_with_cursor()
        h._refresh_result_pipes(
            [
                {"pipe_name": "DB.T.PIPE_A", "stage_prefix": "42/1/row/p0/diffs/"},
                {"pipe_name": "DB.T.PIPE_B", "stage_prefix": "42/1/row/p0/summary/"},
            ]
        )
        assert mock_cursor.execute.call_count == 2
        statements = [c[0][0] for c in mock_cursor.execute.call_args_list]
        assert any("ALTER PIPE DB.T.PIPE_A REFRESH PREFIX='42/1/row/p0/diffs/'" in s for s in statements)
        assert any("ALTER PIPE DB.T.PIPE_B REFRESH PREFIX='42/1/row/p0/summary/'" in s for s in statements)

    def test_skips_entries_with_missing_fields(self):
        h, mock_cursor = self._make_handler_with_cursor()
        h._refresh_result_pipes(
            [
                {"pipe_name": "DB.T.PIPE_A"},
                {"stage_prefix": "42/1/row/p0/diffs/"},
                {"pipe_name": "DB.T.PIPE_B", "stage_prefix": "42/1/row/p0/summary/"},
            ]
        )
        assert mock_cursor.execute.call_count == 1
        assert "DB.T.PIPE_B" in mock_cursor.execute.call_args[0][0]

    def test_continues_after_individual_failure(self):
        h, mock_cursor = self._make_handler_with_cursor()
        mock_cursor.execute.side_effect = [
            RuntimeError("snowflake timeout"),
            None,
        ]
        h._refresh_result_pipes(
            [
                {"pipe_name": "DB.T.PIPE_A", "stage_prefix": "a/"},
                {"pipe_name": "DB.T.PIPE_B", "stage_prefix": "b/"},
            ]
        )
        assert mock_cursor.execute.call_count == 2


try:
    from data_exchange_agent.tasks.data_validation.helpers import build_table_context

    BUILD_TABLE_CONTEXT_AVAILABLE = True
except ImportError:
    BUILD_TABLE_CONTEXT_AVAILABLE = False


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestResolveObjectType:
    """Tests for helpers.resolve_object_type."""

    def test_table_maps_to_enum(self):
        assert resolve_object_type("TABLE") == ObjectType.TABLE

    def test_view_maps_to_enum(self):
        assert resolve_object_type("VIEW") == ObjectType.VIEW

    def test_case_insensitive(self):
        assert resolve_object_type("table") == ObjectType.TABLE
        assert resolve_object_type("View") == ObjectType.VIEW

    def test_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown object_type"):
            resolve_object_type("MATERIALIZED_VIEW")


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestNeedsTemporaryTableFlag:
    """Tests for helpers._needs_temporary_table_flag."""

    def test_view_teradata_true(self):
        assert _needs_temporary_table_flag(ObjectType.VIEW, Platform.TERADATA) is True

    @pytest.mark.parametrize(
        "platform",
        [Platform.REDSHIFT, Platform.SNOWFLAKE, Platform.SQLSERVER],
    )
    def test_view_non_teradata_false(self, platform):
        assert _needs_temporary_table_flag(ObjectType.VIEW, platform) is False

    @pytest.mark.parametrize(
        "platform",
        [
            Platform.REDSHIFT,
            Platform.SNOWFLAKE,
            Platform.SQLSERVER,
            Platform.TERADATA,
        ],
    )
    def test_table_any_platform_false(self, platform):
        assert _needs_temporary_table_flag(ObjectType.TABLE, platform) is False


@pytest.mark.skipif(
    not HANDLER_AVAILABLE or not BUILD_TABLE_CONTEXT_AVAILABLE or not SDV_AVAILABLE,
    reason=SKIP_MSG,
)
class TestBuildTableContextObjectType:
    """Tests for helpers.build_table_context object_type / is_temporary_table."""

    def test_default_table_not_temporary(self):
        ctx = build_table_context(platform=Platform.SNOWFLAKE, table_name="sch.tbl")
        assert ctx.object_type == ObjectType.TABLE
        assert ctx.is_temporary_table is False

    def test_view_teradata_sets_temporary_flag(self):
        ctx = build_table_context(
            platform=Platform.TERADATA,
            table_name="sch.v",
            object_type=ObjectType.VIEW,
        )
        assert ctx.object_type == ObjectType.VIEW
        assert ctx.is_temporary_table is True

    def test_view_snowflake_not_temporary(self):
        ctx = build_table_context(
            platform=Platform.SNOWFLAKE,
            table_name="sch.v",
            object_type=ObjectType.VIEW,
        )
        assert ctx.object_type == ObjectType.VIEW
        assert ctx.is_temporary_table is False


@pytest.mark.skipif(not HANDLER_AVAILABLE or not SDV_AVAILABLE, reason=SKIP_MSG)
class TestBuildRowTableContextObjectType:
    """Tests for helpers.build_row_table_context object_type / is_temporary_table."""

    def test_default_table_not_temporary(self):
        ctx = build_row_table_context(
            platform=Platform.SNOWFLAKE,
            origin=Origin.SOURCE,
            table_fqn="db.schema.tbl",
            columns=[],
            index_column_list=["id"],
            chunk_number=1,
            max_failed_rows_number=50,
        )
        assert ctx.object_type == ObjectType.TABLE
        assert ctx.is_temporary_table is False

    def test_view_teradata_temporary_and_object_type(self):
        ctx = build_row_table_context(
            platform=Platform.TERADATA,
            origin=Origin.SOURCE,
            table_fqn="db.schema.v",
            columns=[],
            index_column_list=["id"],
            chunk_number=1,
            max_failed_rows_number=50,
            object_type=ObjectType.VIEW,
        )
        assert ctx.object_type == ObjectType.VIEW
        assert ctx.is_temporary_table is True
