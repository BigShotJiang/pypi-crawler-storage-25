"""
DEA data_validation task wraps in MigrationTracker with the right step.

Closes the historical gap where ``_process_data_validation_task`` was the only
DEA task path NOT wrapped in a MigrationTracker. After this work it emits
``log_migration_start`` on entry and either ``log_migration_success`` or
``log_migration_failure`` on exit, both carrying ``extra.step``,
``validation_level``, and (for L3) ``row_validation_mode``.
"""

import threading

from unittest.mock import Mock, patch

import pytest

import data_exchange_agent.tasks.manager as manager_mod

from data_exchange_agent.constants import task_keys
from shared.telemetry.current_step import clear_current_step


def _make_manager() -> manager_mod.TaskManager:
    with patch.object(manager_mod.TaskManager, "__init__", lambda self, **kw: None):
        m = manager_mod.TaskManager()
    m.logger = Mock()
    m.task_source_adapter = Mock()
    m.snowflake_datasource = Mock()
    m.source_connections_config = {"sqlserver": Mock()}
    m.target_connections_config = {}
    m.lease_refresher = Mock()
    m.stop_workers = False
    m._stop_event = threading.Event()
    m._pull_lock = threading.Semaphore(2)
    m._throttle_lock = threading.Lock()
    m._last_empty_pull_time = 0.0
    m.task_fetch_interval = 5
    m._contention_counts = {}
    m._local_results_directory = None
    return m


def _task(validation_type: str, row_mode: str | None = None) -> dict:
    payload = {"validation_type": validation_type, "workflow_id": 7253}
    if row_mode:
        payload["row_validation_mode"] = row_mode
    return {
        task_keys.ID: "task-1",
        task_keys.ENGINE: "sqlserver",
        task_keys.WORKFLOW_ID: 7253,
        task_keys.PAYLOAD: payload,
    }


def _run(validation_type: str, row_mode: str | None, handler_result) -> Mock:
    """Invoke the DV task with a mocked client + handler. Returns the client mock."""
    m = _make_manager()
    m._handle_success = Mock()
    m._handle_error = Mock()
    mock_client = Mock()
    mock_client.is_enabled.return_value = True
    mock_handler = Mock()
    if isinstance(handler_result, Exception):
        mock_handler.handle.side_effect = handler_result
    else:
        mock_handler.handle.return_value = handler_result
    with (
        patch(
            "shared.telemetry.helpers.get_telemetry_client",
            return_value=mock_client,
        ),
        patch(
            "data_exchange_agent.tasks.manager.DataValidationHandler",
            return_value=mock_handler,
        ),
    ):
        m._process_data_validation_task(_task(validation_type, row_mode))
    return mock_client


@pytest.fixture(autouse=True)
def _clean_step():
    clear_current_step()
    yield
    clear_current_step()


@pytest.mark.parametrize(
    "validation_type, row_mode, expected_step",
    [
        ("schema", None, "l1_schema"),
        ("metrics", None, "l2_metrics"),
        ("row", "row", "l3_row"),
        ("row", "cell", "l3_cell"),
        ("row", "hybrid", "l3_hybrid"),
    ],
    ids=["l1_schema", "l2_metrics", "l3_row", "l3_cell", "l3_hybrid"],
)
def test_success_emits_correct_step(
    validation_type: str, row_mode: str | None, expected_step: str
) -> None:
    """Each validation_type / row_mode combo tags the emitted event with the expected step."""
    client = _run(validation_type, row_mode, {task_keys.STATUS: "success"})

    assert client.log_migration_start.called
    assert client.log_migration_success.called
    extra = client.log_migration_success.call_args.kwargs.get("extra") or {}
    assert extra["validation_level"] == validation_type
    assert extra["step"] == expected_step
    if row_mode:
        assert extra["row_validation_mode"] == row_mode


def test_handler_error_status_emits_failure_with_step() -> None:
    """A handler returning ``status="error"`` triggers ``log_migration_failure`` carrying the step."""
    client = _run(
        "metrics",
        None,
        {task_keys.STATUS: "error", task_keys.DETAILS: "metrics mismatch"},
    )
    assert client.log_migration_failure.called
    extra = client.log_migration_failure.call_args.kwargs.get("extra") or {}
    assert extra["validation_level"] == "metrics"
    assert extra["step"] == "l2_metrics"


def test_handler_exception_emits_failure_with_step() -> None:
    """A raising handler still triggers ``log_migration_failure`` with the step+row_mode tagged."""
    client = _run("row", "cell", RuntimeError("validation crashed"))
    assert client.log_migration_failure.called
    extra = client.log_migration_failure.call_args.kwargs.get("extra") or {}
    assert extra["validation_level"] == "row"
    assert extra["row_validation_mode"] == "cell"
    assert extra["step"] == "l3_cell"
