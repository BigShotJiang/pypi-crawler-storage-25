"""Tests for the ExecutionProfiler class."""

import json
import unittest
from unittest.mock import patch

from data_exchange_agent.tasks.execution_profiler import ExecutionProfiler, Stopwatch

_MODULE = "data_exchange_agent.tasks.execution_profiler.time.monotonic"


class TestExecutionProfiler(unittest.TestCase):
    """Test ExecutionProfiler."""

    def test_empty_profiler_returns_empty_list(self):
        profiler = ExecutionProfiler()
        result = json.loads(profiler.to_json())
        self.assertEqual(result, [])

    @patch(_MODULE, side_effect=[0.0, 0.010])
    def test_single_step(self, _mock):
        profiler = ExecutionProfiler()
        profiler.step("Step A")
        profiler.finish()

        result = json.loads(profiler.to_json())
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][0], "Step A")
        self.assertGreaterEqual(result[0][1], 5)

    @patch(_MODULE, side_effect=[0.0, 0.010, 0.010, 0.025])
    def test_multiple_sequential_steps(self, _mock):
        profiler = ExecutionProfiler()
        profiler.step("Step 1")
        profiler.step("Step 2")
        profiler.finish()

        result = json.loads(profiler.to_json())
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0][0], "Step 1")
        self.assertEqual(result[1][0], "Step 2")
        self.assertGreaterEqual(result[0][1], 5)
        self.assertGreaterEqual(result[1][1], 5)

    @patch(_MODULE, side_effect=[0.0, 0.010, 0.010, 0.010])
    def test_step_auto_ends_previous(self, _mock):
        profiler = ExecutionProfiler()
        profiler.step("First")
        profiler.step("Second")
        profiler.finish()

        result = json.loads(profiler.to_json())
        self.assertEqual(len(result), 2)
        self.assertEqual(result[0][0], "First")
        self.assertGreaterEqual(result[0][1], 5)

    def test_record_adds_step_directly(self):
        profiler = ExecutionProfiler()
        profiler.record("Parallel Fetch A", 1500)
        profiler.record("Parallel Fetch B", 2000)

        result = json.loads(profiler.to_json())
        self.assertEqual(result, [["Parallel Fetch A", 1500], ["Parallel Fetch B", 2000]])

    @patch(_MODULE, side_effect=[0.0, 0.010])
    def test_mixed_step_and_record(self, _mock):
        profiler = ExecutionProfiler()
        profiler.record("Fetch Source", 100)
        profiler.record("Fetch Target", 200)
        profiler.step("Compare")
        profiler.finish()

        result = json.loads(profiler.to_json())
        self.assertEqual(len(result), 3)
        self.assertEqual(result[0], ["Fetch Source", 100])
        self.assertEqual(result[1], ["Fetch Target", 200])
        self.assertEqual(result[2][0], "Compare")

    @patch(_MODULE, side_effect=[0.0, 0.010])
    def test_to_json_calls_finish(self, _mock):
        profiler = ExecutionProfiler()
        profiler.step("Open Step")
        result = json.loads(profiler.to_json())
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0][0], "Open Step")

    def test_to_json_idempotent(self):
        profiler = ExecutionProfiler()
        profiler.record("Step", 42)
        first = profiler.to_json()
        second = profiler.to_json()
        self.assertEqual(first, second)

    def test_finish_without_step_is_safe(self):
        profiler = ExecutionProfiler()
        profiler.finish()
        result = json.loads(profiler.to_json())
        self.assertEqual(result, [])

    def test_step_returns_self_for_chaining(self):
        profiler = ExecutionProfiler()
        returned = profiler.step("A")
        self.assertIs(returned, profiler)

    def test_json_format_matches_spec(self):
        """Verify the output matches [["name", ms], ...] format."""
        profiler = ExecutionProfiler()
        profiler.record("Download", 1004)
        profiler.record("Upload", 2153)

        raw = profiler.to_json()
        parsed = json.loads(raw)
        self.assertIsInstance(parsed, list)
        for entry in parsed:
            self.assertIsInstance(entry, list)
            self.assertEqual(len(entry), 2)
            self.assertIsInstance(entry[0], str)
            self.assertIsInstance(entry[1], int)


class TestStopwatch(unittest.TestCase):
    """Test the Stopwatch context manager."""

    @patch(_MODULE, side_effect=[0.0, 0.250])
    def test_records_elapsed_ms_on_exit(self, _mock):
        with Stopwatch() as sw:
            pass
        self.assertEqual(sw.elapsed_ms, 250)

    def test_elapsed_ms_defaults_to_zero_before_stop(self):
        sw = Stopwatch()
        self.assertEqual(sw.elapsed_ms, 0)

    @patch(_MODULE, side_effect=[0.0, 0.005])
    def test_elapsed_ms_is_integer(self, _mock):
        with Stopwatch() as sw:
            pass
        self.assertIsInstance(sw.elapsed_ms, int)

    @patch(_MODULE, side_effect=[0.0, 0.010])
    def test_returns_self_for_as_binding(self, _mock):
        sw = Stopwatch()
        with sw as bound:
            self.assertIs(bound, sw)

    @patch(_MODULE, side_effect=[0.0, 0.125])
    def test_stop_returns_elapsed_ms_and_freezes_it(self, _mock):
        sw = Stopwatch()
        returned = sw.stop()
        self.assertEqual(returned, 125)
        self.assertEqual(sw.elapsed_ms, 125)


class TestMeasure(unittest.TestCase):
    """Test the ExecutionProfiler.measure() context manager."""

    @patch(_MODULE, side_effect=[0.0, 0.100])
    def test_records_single_entry_on_exit(self, _mock):
        profiler = ExecutionProfiler()
        with profiler.measure("Step X"):
            pass

        result = json.loads(profiler.to_json())
        self.assertEqual(result, [["Step X", 100]])

    @patch(_MODULE, side_effect=[0.0, 0.050])
    def test_yields_stopwatch_for_inspection(self, _mock):
        profiler = ExecutionProfiler()
        with profiler.measure("Step X") as sw:
            self.assertIsInstance(sw, Stopwatch)
        self.assertEqual(sw.elapsed_ms, 50)

    @patch(_MODULE, side_effect=[0.0, 0.125, 0.125, 0.375])
    def test_multiple_measures_produce_distinct_entries(self, _mock):
        profiler = ExecutionProfiler()
        with profiler.measure("A"):
            pass
        with profiler.measure("B"):
            pass

        result = json.loads(profiler.to_json())
        self.assertEqual(result, [["A", 125], ["B", 250]])


class TestAccumulate(unittest.TestCase):
    """Test the ExecutionProfiler.accumulate() context manager."""

    @patch(_MODULE, side_effect=[0.0, 0.125, 0.125, 0.375, 0.375, 0.5])
    def test_multiple_calls_sum_into_single_entry(self, _mock):
        profiler = ExecutionProfiler()
        with profiler.accumulate("fetch"):
            pass
        with profiler.accumulate("fetch"):
            pass
        with profiler.accumulate("fetch"):
            pass

        result = json.loads(profiler.to_json())
        self.assertEqual(result, [["fetch", 125 + 250 + 125]])

    @patch(_MODULE, side_effect=[0.0, 0.125, 0.125, 0.25])
    def test_separate_accumulators_are_independent(self, _mock):
        profiler = ExecutionProfiler()
        with profiler.accumulate("src"):
            pass
        with profiler.accumulate("tgt"):
            pass

        result = json.loads(profiler.to_json())
        self.assertEqual(sorted(result), [["src", 125], ["tgt", 125]])

    @patch(_MODULE, side_effect=[0.0, 0.125])
    def test_to_json_is_idempotent_for_accumulators(self, _mock):
        profiler = ExecutionProfiler()
        with profiler.accumulate("step"):
            pass

        first = profiler.to_json()
        second = profiler.to_json()
        self.assertEqual(first, second)

    def test_no_entries_when_accumulator_unused(self):
        profiler = ExecutionProfiler()
        result = json.loads(profiler.to_json())
        self.assertEqual(result, [])


if __name__ == "__main__":
    unittest.main()
