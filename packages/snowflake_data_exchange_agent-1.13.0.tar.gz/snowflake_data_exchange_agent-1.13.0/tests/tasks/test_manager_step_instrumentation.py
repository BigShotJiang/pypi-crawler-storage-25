"""
Tests that DEA movement instrumentation tags step + sub_step on failure.

When ``_process_data_movement_task`` fails inside the EXTRACT (export-data)
phase, the failure event surfaced by ``MigrationTracker`` MUST carry
``step="extract"`` and ``sub_step="export-data"`` in its ``extra`` dict so
dashboards can answer "which phase of which task crashed".
"""

import threading
import unittest

from unittest.mock import Mock, patch

import data_exchange_agent.tasks.manager as manager_mod

from data_exchange_agent.constants import task_keys
from shared.telemetry.current_step import clear_current_step


def _make_manager() -> manager_mod.TaskManager:
    """Create a TaskManager with mocked DI dependencies (matches helpers test style)."""
    with patch.object(manager_mod.TaskManager, "__init__", lambda self, **kw: None):
        m = manager_mod.TaskManager()
    m.logger = Mock()
    m.task_source_adapter = Mock()
    m.snowflake_datasource = Mock()
    m.source_connections_config = {"sqlserver": Mock()}
    m.target_connections_config = {}
    m.lease_refresher = Mock()
    m.stop_workers = False
    m._stop_event = threading.Event()
    m._pull_lock = threading.Semaphore(2)
    m._throttle_lock = threading.Lock()
    m._last_empty_pull_time = 0.0
    m.task_fetch_interval = 5
    m._contention_counts = {}
    m._local_results_directory = None
    return m


def _movement_task() -> dict:
    return {
        task_keys.ID: "task-1",
        task_keys.ENGINE: "sqlserver",
        task_keys.STATEMENT: "SELECT 1",
        task_keys.TARGET_TYPE: "snowflake_stage",
        task_keys.TARGET_ID: "0",
        task_keys.WORKFLOW_ID: 7253,
    }


class TestMovementStepInstrumentation(unittest.TestCase):
    """Failure inside EXTRACT (export-data) tags step=extract / sub_step=export-data."""

    def setUp(self) -> None:
        clear_current_step()

    def tearDown(self) -> None:
        clear_current_step()

    def test_failure_during_export_records_extract_step(self):
        m = _make_manager()
        m._handle_odbc_error = Mock()

        # The data source returned from DataSourceRegistry.create raises in export_data.
        exploding_ds = Mock()
        exploding_ds.export_data.side_effect = RuntimeError("export broke")

        mock_client = Mock()
        mock_client.is_enabled.return_value = True

        with (
            patch(
                "shared.telemetry.helpers.get_telemetry_client",
                return_value=mock_client,
            ),
            patch(
                "data_exchange_agent.tasks.manager.DataSourceRegistry"
            ) as mock_registry,
            patch(
                "data_exchange_agent.tasks.manager.build_actual_results_folder_path",
                return_value="/tmp/dea-test",
            ),
            patch.object(m, "_resolve_data_source_type", return_value="odbc"),
        ):
            mock_registry.create.return_value = exploding_ds
            m._process_data_movement_task(_movement_task())

        # MigrationTracker should have emitted a failure (via tracker.log_failure
        # which routes to log_migration_failure on the underlying client).
        assert (
            mock_client.log_migration_failure.called
        ), "expected log_migration_failure to be called once on extract failure"

        # Inspect the most recent failure call's extra.
        call_kwargs = mock_client.log_migration_failure.call_args.kwargs
        extra = call_kwargs.get("extra") or {}
        assert (
            extra.get("step") == "extract"
        ), f"expected step='extract', got step={extra.get('step')!r} (full extra={extra!r})"
        assert extra.get("sub_step") == "export-data", (
            f"expected sub_step='export-data', got sub_step={extra.get('sub_step')!r} "
            f"(full extra={extra!r})"
        )

    def test_failure_during_resolve_records_init_step(self):
        m = _make_manager()
        m._handle_error = Mock()

        mock_client = Mock()
        mock_client.is_enabled.return_value = True

        # Make data source creation blow up so we fail during INIT/resolve-data-source.
        with (
            patch(
                "shared.telemetry.helpers.get_telemetry_client",
                return_value=mock_client,
            ),
            patch(
                "data_exchange_agent.tasks.manager.DataSourceRegistry"
            ) as mock_registry,
            patch(
                "data_exchange_agent.tasks.manager.build_actual_results_folder_path",
                return_value="/tmp/dea-test",
            ),
            patch.object(m, "_resolve_data_source_type", return_value="odbc"),
        ):
            mock_registry.create.side_effect = RuntimeError("cannot create data source")
            m._process_data_movement_task(_movement_task())

        assert mock_client.log_migration_failure.called
        extra = mock_client.log_migration_failure.call_args.kwargs.get("extra") or {}
        assert (
            extra.get("step") == "init"
        ), f"expected step='init', got step={extra.get('step')!r} (full extra={extra!r})"
        assert (
            extra.get("sub_step") == "resolve-data-source"
        ), f"expected sub_step='resolve-data-source', got sub_step={extra.get('sub_step')!r}"
