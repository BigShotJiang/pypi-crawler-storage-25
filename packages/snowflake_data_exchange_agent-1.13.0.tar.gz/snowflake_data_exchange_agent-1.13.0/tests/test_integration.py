import json
import threading
import unittest

from unittest.mock import MagicMock

from data_exchange_agent.queues.deque_task_queue import DequeTaskQueue
from data_exchange_agent.servers.flask_app import FlaskApp


class MockDataSource:
    """Mock data source for integration testing."""

    def __init__(self, test_data=None):
        self.test_data = test_data or []
        self.connection_created = False

    def create_connection(self):
        self.connection_created = True
        return "mock_connection"

    def execute_statement(self, statement: str, results_folder_path: str = None):
        return iter(self.test_data)

    def close_connection(self):
        pass


class TestIntegration(unittest.TestCase):
    """Integration tests for data_exchange_agent components."""

    def test_deque_task_queue_integration(self):
        """Test DequeTaskQueue integration with concurrent access."""
        task_queue = DequeTaskQueue()

        def add_tasks(start_id, count):
            for i in range(count):
                task = {"id": f"task_{start_id + i}", "data": f"data_{start_id + i}"}
                task_queue.add_task(task)

        threads = []
        for i in range(3):
            thread = threading.Thread(target=add_tasks, args=(i * 10, 5))
            threads.append(thread)
            thread.start()

        for thread in threads:
            thread.join()

        self.assertEqual(task_queue.get_queue_size(), 15)

        retrieved_tasks = []
        while True:
            task = task_queue.get_task()
            if task is None:
                break
            retrieved_tasks.append(task)

        self.assertEqual(len(retrieved_tasks), 15)
        self.assertEqual(task_queue.get_queue_size(), 0)

    def test_flask_app_integration(self):
        """Test Flask app integration with dependency injection."""
        from dependency_injector import providers

        from data_exchange_agent.container import _Container

        # Create and wire the container
        container = _Container()
        container.wire(modules=["data_exchange_agent.servers.flask_app"])

        # Create mock task manager for integration test
        mock_task_manager = MagicMock()

        mock_program_config = MagicMock()
        mock_program_config.__getitem__.side_effect = lambda key: {
            "application.max_parallel_tasks": 8,
            "application.task_fetch_interval": 60,
            "application.debug_mode": True,
            "server.host": "127.0.0.1",
            "server.port": 8000,
            "connections.source": {
                "test_engine": {
                    "driver_name": "sqlserver",
                    "host": "localhost",
                    "port": 1433,
                    "database": "test",
                    "username": "test",
                    "password": "test",
                },
            },
            "connections.target": {
                "test_bucket": {
                    "bucket": "test",
                    "region": "us-west-2",
                },
            },
        }[key]

        with container.task_manager.override(providers.Object(mock_task_manager)):
            flask_app = FlaskApp()
            app = flask_app.create_app(program_config=mock_program_config)

            with app.test_client() as client:
                response = client.get("/health")
                self.assertEqual(response.status_code, 200)
                data = json.loads(response.data)
                self.assertEqual(data["status"], "healthy")
                self.assertEqual(data["service"], "data_exchange_agent")

        container.unwire()


if __name__ == "__main__":
    unittest.main()
