"""Schema-stability tests for ODBCDataSource batch writing."""

from __future__ import annotations

import os
import tempfile
from decimal import Decimal

import pyarrow as pa
import pyarrow.parquet as pq

from data_exchange_agent.data_sources.odbc_data_source import ODBCDataSource
from data_exchange_agent.data_sources.odbc_schema import schema_from_description


def _description(name: str, type_code, precision: int | None, scale: int | None):
    """Build a DB-API 2.0 7-tuple description entry."""
    return (name, type_code, None, None, precision, scale, True)


class TestSchemaFromDescriptionDecimals:
    """``schema_from_description`` maps DECIMAL/NUMERIC metadata like production."""

    def test_decimal_string_type_code_uses_declared_precision(self):
        description = [_description("total_amount", "DECIMAL", 5, 2)]

        column_types, _ = schema_from_description(description)

        assert column_types == [pa.decimal128(5, 2)]

    def test_python_decimal_type_code_uses_declared_precision(self):
        description = [_description("amount", Decimal, 10, 4)]

        column_types, _ = schema_from_description(description)

        assert column_types == [pa.decimal128(10, 4)]

    def test_non_decimal_string_type_codes_return_none(self):
        description = [
            _description("id", "INTEGER", None, None),
            _description("name", "VARCHAR", 128, None),
        ]

        column_types, _ = schema_from_description(description)

        assert column_types == [None, None]

    def test_huge_precision_uses_decimal256(self):
        description = [_description("big", "NUMERIC", 50, 4)]

        column_types, _ = schema_from_description(description)

        assert column_types == [pa.decimal256(50, 4)]

    def test_invalid_metadata_returns_none(self):
        description = [_description("ratio", "DECIMAL", 0, None)]

        column_types, _ = schema_from_description(description)

        assert column_types == [None]


class TestWriteChunksDecimalSchemaStability:
    """End-to-end test: two batches with different magnitudes write to one Parquet file."""

    class _FakeCursor:
        """Cursor stub that yields successive batches and exposes description."""

        def __init__(self, description, batches):
            self.description = description
            self._batches = list(batches)

        def fetchmany(self, size):
            if not self._batches:
                return []
            return self._batches.pop(0)

    def test_decimal_precision_drift_between_batches_writes_consistent_file(self):
        """
        Stable schema across batches with different DECIMAL widths.

        Reproduces the production failure where batch 1 had Decimal('1234.56')
        (PyArrow infers ``decimal(6,2)``) and batch 2 had Decimal('1.23')
        (PyArrow would infer ``decimal(3,2)`` and crash). With
        ``cursor.description`` declaring ``decimal(10,2)``, both batches
        share that schema and the Parquet file writes successfully.
        """
        description = [
            ("order_id", "INTEGER", None, None, None, None, True),
            ("total_amount", "DECIMAL", None, None, 10, 2, True),
        ]
        cursor = self._FakeCursor(
            description=description,
            batches=[
                [(1, Decimal("1234.56")), (2, Decimal("9999.99"))],
                [(3, Decimal("1.23"))],
            ],
        )
        ds = ODBCDataSource.__new__(ODBCDataSource)
        ds.logger = _NullLogger()  # type: ignore[attr-defined]

        with tempfile.TemporaryDirectory() as tmp:
            output_file = os.path.join(tmp, "out.parquet")

            ds._write_chunks_to_single_parquet(cursor, output_file, batch_size=100)

            table = pq.read_table(output_file)

        assert table.num_rows == 3
        assert table.schema.field("total_amount").type == pa.decimal128(10, 2)
        assert table.column("order_id").to_pylist() == [1, 2, 3]
        assert table.column("total_amount").to_pylist() == [
            Decimal("1234.56"),
            Decimal("9999.99"),
            Decimal("1.23"),
        ]


class _NullLogger:
    def info(self, *args, **kwargs):
        return None

    def error(self, *args, **kwargs):
        return None

    def warning(self, *args, **kwargs):
        return None
