"""
Comprehensive test suite for the WriteNosDataSource class.

This test class validates the Teradata WRITE_NOS data source implementation,
including connection handling, statement execution, database switching, and
credential sanitization.
"""

import unittest

from unittest.mock import MagicMock, Mock, patch

from data_exchange_agent.data_sources.write_nos_data_source import (
    WriteNosDataSource,
    _sanitize_write_nos_statement,
)


class TestSanitizeWriteNosStatement(unittest.TestCase):
    """Validates AUTHORIZATION redaction from WRITE_NOS statements before logging."""

    def test_sanitize_inline_authorization_json(self):
        statement = (
            "SELECT * FROM WRITE_NOS (\n"
            "    ON ( SELECT 1 )\n"
            "    USING\n"
            "    LOCATION('/az/host/bucket/path/')\n"
            '    AUTHORIZATION(\'{"Access_ID":"acct","Access_Key":"secret"}\')\n'
            "    STOREDAS('PARQUET')\n"
            ") AS d"
        )
        result = _sanitize_write_nos_statement(statement)
        self.assertIn("AUTHORIZATION('***')", result)
        self.assertNotIn("acct", result)
        self.assertNotIn("secret", result)

    def test_sanitize_named_authorization_object(self):
        statement = (
            "SELECT * FROM WRITE_NOS ("
            "ON ( SELECT 1 ) USING "
            "LOCATION('/s3/host/bucket/p/') "
            "AUTHORIZATION('nos_util.DefAuth_Write') "
            "STOREDAS('PARQUET'))"
        )
        result = _sanitize_write_nos_statement(statement)
        self.assertIn("AUTHORIZATION('***')", result)
        self.assertNotIn("nos_util.DefAuth_Write", result)

    def test_sanitize_double_quoted_authorization(self):
        statement = 'WRITE_NOS USING AUTHORIZATION("nos_util.AuthA")'
        result = _sanitize_write_nos_statement(statement)
        self.assertIn("AUTHORIZATION('***')", result)
        self.assertNotIn("nos_util.AuthA", result)

    def test_sanitize_preserves_other_content(self):
        statement = (
            "SELECT * FROM WRITE_NOS (\n"
            "    ON ( SELECT id, name FROM ecommerce.customers )\n"
            "    USING\n"
            "    LOCATION('/az/host/bucket/wf_1/tbl_2/partition_0/')\n"
            "    AUTHORIZATION('nos_util.DefAuth_Write')\n"
            "    STOREDAS('PARQUET')\n"
            "    MAXOBJECTSIZE('16MB')\n"
            ") AS d"
        )
        result = _sanitize_write_nos_statement(statement)
        self.assertIn("LOCATION('/az/host/bucket/wf_1/tbl_2/partition_0/')", result)
        self.assertIn("STOREDAS('PARQUET')", result)
        self.assertIn("MAXOBJECTSIZE('16MB')", result)
        self.assertIn("ecommerce.customers", result)

    def test_sanitize_case_insensitive(self):
        for keyword in ("authorization", "Authorization", "AUTHORIZATION"):
            statement = f"WRITE_NOS USING {keyword}('secret')"
            result = _sanitize_write_nos_statement(statement)
            self.assertNotIn("secret", result, f"Failed for keyword: {keyword}")

    def test_sanitize_statement_without_authorization(self):
        statement = "SELECT * FROM users WHERE id = 1"
        result = _sanitize_write_nos_statement(statement)
        self.assertEqual(result, statement)


def _make_data_source(
    *,
    statement: str = "SELECT * FROM WRITE_NOS (...) AS d",
    use_database_command: str | None = None,
):
    """Build a WriteNosDataSource against mocked logger / program_config."""
    mock_logger = Mock()
    mock_program_config = Mock()
    mock_connection_config = Mock()
    mock_connection_config.connection_string = "Driver={Test};Server=test"
    mock_program_config.__getitem__ = Mock(return_value={"teradata": mock_connection_config})

    return (
        WriteNosDataSource(
            engine="teradata",
            statement=statement,
            use_database_command=use_database_command,
            logger=mock_logger,
            program_config=mock_program_config,
        ),
        mock_logger,
    )


class TestWriteNosDataSourceProperties(unittest.TestCase):
    """Validates property surface."""

    def test_statement_property(self):
        ds, _ = _make_data_source(statement="WRITE_NOS_SQL")
        self.assertEqual(ds.statement, "WRITE_NOS_SQL")

    def test_results_folder_path_defaults_to_empty(self):
        ds, _ = _make_data_source()
        self.assertEqual(ds.results_folder_path, "")

    def test_base_file_name_default(self):
        ds, _ = _make_data_source()
        self.assertEqual(ds.base_file_name, "result")


class TestWriteNosDataSourceExportData(unittest.TestCase):
    """Validates ``export_data`` execution behavior."""

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_export_data_executes_write_nos_command(self, mock_get_pyodbc):
        mock_pyodbc = MagicMock()
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_pyodbc.connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor
        mock_get_pyodbc.return_value = mock_pyodbc

        ds, _ = _make_data_source(statement="WRITE_NOS_SQL")

        result = ds.export_data()

        self.assertTrue(result)
        mock_pyodbc.connect.assert_called_once()
        mock_cursor.execute.assert_called_once_with("WRITE_NOS_SQL")
        # Metadata result set should be drained.
        mock_cursor.fetchall.assert_called_once()
        mock_cursor.close.assert_called_once()
        mock_connection.close.assert_called_once()

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_export_data_handles_connection_error(self, mock_get_pyodbc):
        mock_pyodbc = MagicMock()
        mock_pyodbc.connect.side_effect = Exception("Connection failed")
        mock_get_pyodbc.return_value = mock_pyodbc

        ds, mock_logger = _make_data_source()

        with self.assertRaises(Exception) as ctx:
            ds.export_data()

        self.assertIn("Connection failed", str(ctx.exception))
        mock_logger.error.assert_called()

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_export_data_handles_execution_error(self, mock_get_pyodbc):
        mock_pyodbc = MagicMock()
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_pyodbc.connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor
        mock_cursor.execute.side_effect = Exception("WRITE_NOS denied")
        mock_get_pyodbc.return_value = mock_pyodbc

        ds, mock_logger = _make_data_source()

        with self.assertRaises(Exception) as ctx:
            ds.export_data()

        self.assertIn("WRITE_NOS denied", str(ctx.exception))
        mock_logger.error.assert_called()
        # Connection should be closed even on error.
        mock_connection.close.assert_called_once()

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_export_data_tolerates_no_result_set(self, mock_get_pyodbc):
        """ProgrammingError from ``fetchall`` (no result set) must not fail the task."""

        # Build a synthetic ProgrammingError type that lives on the mocked
        # pyodbc module and matches what the production code catches.
        class FakeProgrammingError(Exception):
            pass

        mock_pyodbc = MagicMock()
        mock_pyodbc.ProgrammingError = FakeProgrammingError
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_pyodbc.connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor
        mock_cursor.fetchall.side_effect = FakeProgrammingError("No results")
        mock_get_pyodbc.return_value = mock_pyodbc

        ds, _ = _make_data_source()

        result = ds.export_data()

        self.assertTrue(result)
        mock_cursor.close.assert_called_once()
        mock_connection.close.assert_called_once()


class TestWriteNosDataSourceDatabaseSwitching(unittest.TestCase):
    """Validates ``use_database_command`` handling."""

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_executes_database_switch_command(self, mock_get_pyodbc):
        mock_pyodbc = MagicMock()
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_pyodbc.connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor
        mock_get_pyodbc.return_value = mock_pyodbc

        ds, _ = _make_data_source(
            statement="WRITE_NOS_SQL",
            use_database_command='DATABASE "ecommerce"',
        )

        ds.export_data()

        calls = mock_cursor.execute.call_args_list
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0][0][0], 'DATABASE "ecommerce"')
        self.assertEqual(calls[1][0][0], "WRITE_NOS_SQL")

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_skips_database_switch_when_no_command(self, mock_get_pyodbc):
        mock_pyodbc = MagicMock()
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_pyodbc.connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor
        mock_get_pyodbc.return_value = mock_pyodbc

        ds, _ = _make_data_source(
            statement="WRITE_NOS_SQL",
            use_database_command=None,
        )

        ds.export_data()

        calls = mock_cursor.execute.call_args_list
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][0][0], "WRITE_NOS_SQL")

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_database_switch_error_propagates(self, mock_get_pyodbc):
        mock_pyodbc = MagicMock()
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_pyodbc.connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor
        mock_cursor.execute.side_effect = Exception("Database not found")
        mock_get_pyodbc.return_value = mock_pyodbc

        ds, mock_logger = _make_data_source(
            use_database_command='DATABASE "nonexistent"',
        )

        with self.assertRaises(Exception) as ctx:
            ds.export_data()

        self.assertIn("Database not found", str(ctx.exception))
        mock_logger.error.assert_called()


class TestWriteNosDataSourceLogging(unittest.TestCase):
    """Validates that secrets in the rendered statement are not logged."""

    @patch("data_exchange_agent.data_sources.write_nos_data_source._get_pyodbc")
    def test_logs_redacted_authorization(self, mock_get_pyodbc):
        mock_pyodbc = MagicMock()
        mock_connection = MagicMock()
        mock_cursor = MagicMock()
        mock_pyodbc.connect.return_value = mock_connection
        mock_connection.cursor.return_value = mock_cursor
        mock_get_pyodbc.return_value = mock_pyodbc

        secret_payload = 'AUTHORIZATION(\'{"Access_ID":"acct","Access_Key":"hunter2"}\')'
        statement = (
            f"SELECT * FROM WRITE_NOS ( ON ( SELECT 1 ) USING "
            f"LOCATION('/az/host/bucket/path/') {secret_payload} "
            f"STOREDAS('PARQUET') ) AS d"
        )

        ds, mock_logger = _make_data_source(statement=statement)

        ds.export_data()

        for call in mock_logger.info.call_args_list:
            log_message = str(call)
            self.assertNotIn("hunter2", log_message)
            self.assertNotIn("acct", log_message)


class TestWriteNosDataSourceRegistration(unittest.TestCase):
    """Validates that WriteNosDataSource is registered in the registry."""

    def test_write_nos_data_source_is_registered(self):
        from data_exchange_agent.constants.data_source_types import DataSourceType
        from data_exchange_agent.data_sources import DataSourceRegistry

        self.assertTrue(DataSourceRegistry.is_registered(DataSourceType.WRITE_NOS))

    def test_get_write_nos_data_source_class(self):
        from data_exchange_agent.constants.data_source_types import DataSourceType
        from data_exchange_agent.data_sources import (
            DataSourceRegistry,
            WriteNosDataSource as RegisteredCls,
        )

        result = DataSourceRegistry.get(DataSourceType.WRITE_NOS)
        self.assertEqual(result, RegisteredCls)


if __name__ == "__main__":
    unittest.main()
