"""
Unit tests for :class:`TptDataSource`.

These tests mock out the Teradata connection (column-name introspection),
``tbuild`` execution, and the CSV → Parquet conversion so the suite can run on
machines without TTU installed.
"""

from __future__ import annotations

import os
import unittest

from unittest.mock import MagicMock, Mock, patch

from data_exchange_agent.constants.data_source_types import DataSourceType


class _FakeTptConfig:
    """Minimal stand-in for :class:`TptConfig` used in tests."""

    def __init__(self, output_directory: str, log_directory: str | None = None) -> None:
        self.output_directory = output_directory
        self.log_directory = log_directory
        self.delimiter = "|"
        self.charset = "UTF8"
        self.max_sessions = 4

    @property
    def effective_log_directory(self) -> str:
        return self.log_directory or self.output_directory


class _FakeTeradataConnectionConfig:
    """Minimal stand-in matching the attribute surface used by TptDataSource."""

    def __init__(self, tpt_config: _FakeTptConfig | None) -> None:
        self.host = "td-host"
        self.dbc_name = None
        self.username = "user"
        self.password = "pwd"
        self.tpt_config = tpt_config


@patch(
    "data_exchange_agent.config.sections.connections.dialects.teradata.TeradataConnectionConfig",
    _FakeTeradataConnectionConfig,
)
@patch(
    "data_exchange_agent.config.sections.connections.dialects.teradata.TptConfig",
    _FakeTptConfig,
)
class TestTptDataSourceConstruction(unittest.TestCase):
    """Validation of TptDataSource constructor wiring."""

    def _build(self, tpt_config: _FakeTptConfig | None, **kwargs):
        from data_exchange_agent.data_sources.tpt_data_source import TptDataSource

        mock_logger = Mock()
        connection_config = _FakeTeradataConnectionConfig(tpt_config=tpt_config)
        program_config = MagicMock()
        program_config.__getitem__ = Mock(return_value={"teradata": connection_config})

        return TptDataSource(
            engine="teradata",
            statement="SELECT id, value FROM db.t",
            results_folder_path=kwargs.pop("results_folder_path", "/tmp/results"),
            base_file_name=kwargs.pop("base_file_name", "result"),
            logger=mock_logger,
            program_config=program_config,
            **kwargs,
        )

    def test_requires_tpt_config(self):
        with self.assertRaises(ValueError) as ctx:
            self._build(tpt_config=None)
        self.assertIn("TPT configuration", str(ctx.exception))

    def test_requires_teradata_connection_config(self):
        from data_exchange_agent.data_sources.tpt_data_source import TptDataSource

        program_config = MagicMock()
        program_config.__getitem__ = Mock(return_value={"teradata": object()})

        with self.assertRaises(ValueError) as ctx:
            TptDataSource(
                engine="teradata",
                statement="SELECT 1",
                logger=Mock(),
                program_config=program_config,
            )
        self.assertIn("TeradataConnectionConfig", str(ctx.exception))

    def test_properties_are_initialized(self):
        ds = self._build(
            tpt_config=_FakeTptConfig(output_directory="/tmp/tpt"),
            results_folder_path="/tmp/results",
            base_file_name="task_42_result",
        )
        self.assertEqual(ds.statement, "SELECT id, value FROM db.t")
        self.assertEqual(ds.results_folder_path, "/tmp/results")
        self.assertEqual(ds.base_file_name, "task_42_result")


@patch(
    "data_exchange_agent.config.sections.connections.dialects.teradata.TeradataConnectionConfig",
    _FakeTeradataConnectionConfig,
)
@patch(
    "data_exchange_agent.config.sections.connections.dialects.teradata.TptConfig",
    _FakeTptConfig,
)
class TestTptDataSourceExportFlow(unittest.TestCase):
    """End-to-end flow with all external boundaries mocked."""

    def _build_data_source(self, tmp_path):
        from data_exchange_agent.data_sources.tpt_data_source import TptDataSource

        results_dir = os.path.join(tmp_path, "results")
        os.makedirs(results_dir, exist_ok=True)

        log_dir = os.path.join(tmp_path, "logs")
        tpt_config = _FakeTptConfig(
            output_directory=os.path.join(tmp_path, "out"),
            log_directory=log_dir,
        )

        connection_config = _FakeTeradataConnectionConfig(tpt_config=tpt_config)
        program_config = MagicMock()
        program_config.__getitem__ = Mock(return_value={"teradata": connection_config})

        return (
            TptDataSource(
                engine="teradata",
                statement="SELECT id, value FROM db.t",
                results_folder_path=results_dir,
                base_file_name="task_1_result",
                logger=Mock(),
                program_config=program_config,
            ),
            results_dir,
            log_dir,
        )

    @patch("data_exchange_agent.data_sources.tpt_data_source.shutil.which", return_value="/usr/bin/tbuild")
    @patch("data_exchange_agent.data_sources.tpt_data_source.subprocess.run")
    @patch("data_exchange_agent.data_sources.teradata_connection.open_teradata_connection")
    def test_export_data_runs_tbuild_and_converts_to_parquet(
        self,
        mock_open_conn,
        mock_run,
        _mock_which,
    ):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp_path:
            ds, results_dir, _log_dir = self._build_data_source(tmp_path)

            # Column-name introspection: pretend Teradata says 2 columns.
            mock_cursor = MagicMock()
            mock_cursor.description = [("id",), ("value",)]
            mock_conn = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            mock_open_conn.return_value = mock_conn

            # tbuild "writes" the delimited file we expect — emulate this side effect.
            delimited_path = os.path.join(results_dir, "task_1_result.txt")

            def _fake_tbuild(*_args, **_kwargs):
                with open(delimited_path, "w", encoding="utf-8") as fh:
                    fh.write("1|hello\n2|world\n")
                return MagicMock(returncode=0, stdout="", stderr="")

            mock_run.side_effect = _fake_tbuild

            with patch.object(ds, "_convert_delimited_to_parquet") as mock_convert:
                ok = ds.export_data()

            self.assertTrue(ok)
            mock_open_conn.assert_called_once()
            mock_run.assert_called_once()
            args, _kwargs = mock_run.call_args
            command = args[0]
            self.assertTrue(command[0].endswith("tbuild"))
            self.assertIn("-f", command)
            self.assertIn("-j", command)
            self.assertIn("-L", command)
            mock_convert.assert_called_once()
            args, _kwargs = mock_convert.call_args
            self.assertEqual(args[0], delimited_path)
            self.assertEqual(args[1], ["id", "value"])
            self.assertEqual(len(args[2]), 2)

    def test_export_select_statement_casts_all_columns_to_varchar(self):
        """TPT EXPORT schema is VARCHAR; casts avoid TPT12108 and RDBMS 3798."""
        import tempfile

        from data_exchange_agent.data_sources.tpt_data_source import (
            _compute_export_varchar_width,
        )

        with tempfile.TemporaryDirectory() as tmp_path:
            ds, _results_dir, _log_dir = self._build_data_source(tmp_path)
            cols = ["id", "col with space"]
            width = _compute_export_varchar_width(len(cols))
            sql = ds._export_select_statement(cols, width)
            self.assertIn(f'CAST("id" AS VARCHAR({width})) AS "id"', sql)
            self.assertIn(
                f'CAST("col with space" AS VARCHAR({width})) ' f'AS "col with space"',
                sql,
            )
            self.assertIn("FROM (\nSELECT id, value FROM db.t\n) AS dea_tpt_inner", sql)

    def test_compute_export_varchar_width_keeps_row_under_cap(self):
        """Row size budget keeps total declared width below Teradata's ~64 KB cap."""
        from data_exchange_agent.data_sources.tpt_data_source import (
            _TPT_PER_COLUMN_MAX,
            _TPT_PER_COLUMN_MIN,
            _TPT_ROW_BUDGET_CHARS,
            _compute_export_varchar_width,
        )

        for n in (1, 6, 30, 250):
            w = _compute_export_varchar_width(n)
            self.assertGreaterEqual(w, _TPT_PER_COLUMN_MIN)
            self.assertLessEqual(w, _TPT_PER_COLUMN_MAX)
            # Total may equal budget for very wide tables, never exceed it
            # when the budget divides cleanly.
            self.assertLessEqual(w * n, max(_TPT_ROW_BUDGET_CHARS, _TPT_PER_COLUMN_MIN * n))

    @patch("data_exchange_agent.data_sources.tpt_data_source.shutil.which", return_value="/usr/bin/tbuild")
    @patch("data_exchange_agent.data_sources.tpt_data_source.subprocess.run")
    @patch("data_exchange_agent.data_sources.teradata_connection.open_teradata_connection")
    def test_export_data_raises_when_tbuild_fails(
        self,
        mock_open_conn,
        mock_run,
        _mock_which,
    ):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp_path:
            ds, _results_dir, _log_dir = self._build_data_source(tmp_path)

            mock_cursor = MagicMock()
            mock_cursor.description = [("id",)]
            mock_conn = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            mock_open_conn.return_value = mock_conn

            mock_run.return_value = MagicMock(
                returncode=12,
                stdout="",
                stderr="TPT_INFRA: Connection failed",
            )

            with self.assertRaises(RuntimeError) as ctx:
                ds.export_data()
            self.assertIn("exit code 12", str(ctx.exception))


class TestTptDataSourceRegistration(unittest.TestCase):
    """The data source registry should know about TPT."""

    def test_tpt_is_registered(self):
        from data_exchange_agent.data_sources import DataSourceRegistry

        self.assertTrue(DataSourceRegistry.is_registered(DataSourceType.TPT))

    def test_get_tpt_data_source_class(self):
        from data_exchange_agent.data_sources import (
            DataSourceRegistry,
            TptDataSource,
        )

        self.assertEqual(DataSourceRegistry.get(DataSourceType.TPT), TptDataSource)


if __name__ == "__main__":
    unittest.main()
