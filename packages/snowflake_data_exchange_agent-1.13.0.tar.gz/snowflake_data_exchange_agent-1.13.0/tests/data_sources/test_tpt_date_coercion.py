"""Unit tests for Teradata TPT delimited date/timestamp coercion."""

from __future__ import annotations

import datetime as dt
import tempfile
import unittest

import pyarrow as pa

from data_exchange_agent.data_sources.tpt_data_source import (
    TptDataSource,
    _parse_tpt_date_string,
    _parse_tpt_timestamp_string,
)


class TestTptDateParsing(unittest.TestCase):
    """Parse slash-formatted Teradata TPT date strings."""

    def test_parse_yy_mm_dd(self) -> None:
        self.assertEqual(_parse_tpt_date_string("25/12/31"), dt.date(2025, 12, 31))
        self.assertEqual(_parse_tpt_date_string("24/06/01"), dt.date(2024, 6, 1))
        self.assertEqual(_parse_tpt_date_string("00/01/01"), dt.date(2000, 1, 1))

    def test_parse_iso_date(self) -> None:
        self.assertEqual(_parse_tpt_date_string("2025-12-31"), dt.date(2025, 12, 31))
        self.assertEqual(_parse_tpt_date_string("2024-06-01"), dt.date(2024, 6, 1))

    def test_parse_timestamp_with_fraction(self) -> None:
        parsed = _parse_tpt_timestamp_string("25/12/31 23:59:59.999")
        self.assertEqual(parsed, dt.datetime(2025, 12, 31, 23, 59, 59, 999000))

    def test_parse_timestamp_with_iso_date(self) -> None:
        parsed = _parse_tpt_timestamp_string("2025-12-31 23:59:59.999")
        self.assertEqual(parsed, dt.datetime(2025, 12, 31, 23, 59, 59, 999000))


class TestTptDelimitedToParquetCoercion(unittest.TestCase):
    """TPT CSV rows become typed Parquet columns (not plain strings)."""

    def test_date_and_timestamp_columns_are_typed(self) -> None:
        from unittest.mock import Mock

        from data_exchange_agent.config.sections.connections.dialects.teradata import (
            TptConfig,
        )

        tpt_config = TptConfig(
            output_directory="/tmp/tpt-out",
            delimiter="|",
            max_sessions=1,
            log_directory="/tmp/tpt-logs",
        )
        ds = TptDataSource.__new__(TptDataSource)
        ds.logger = Mock()
        ds._results_folder_path = ""
        ds._base_file_name = "task_result"
        ds._tpt_config = tpt_config

        with tempfile.TemporaryDirectory() as tmp_dir:
            delimited_path = f"{tmp_dir}/task_result.txt"
            with open(delimited_path, "w", encoding="utf-8") as handle:
                handle.write(
                    "1|24/06/01|2024-06-01 14:30:00.123\n" "2|2000-01-01|2000-01-01 00:00:00.000\n" "3|25/12/31|2025-12-31 23:59:59.999\n"
                )

            column_names = ["ID", "DT", "DTTM2"]
            column_types = [pa.int64(), pa.date32(), pa.timestamp("us")]
            ds._results_folder_path = tmp_dir
            ds._convert_delimited_to_parquet(delimited_path, column_names, column_types)

            parquet_path = f"{tmp_dir}/task_result_001.parquet"
            table = pa.parquet.read_table(parquet_path)
            self.assertEqual(table.schema.field("DT").type, pa.date32())
            self.assertEqual(table.schema.field("DTTM2").type, pa.timestamp("us"))
            self.assertEqual(len(table), 3)
            self.assertEqual(table.column("DT")[0].as_py(), dt.date(2024, 6, 1))
            self.assertEqual(table.column("DT")[2].as_py(), dt.date(2025, 12, 31))
            self.assertEqual(
                table.column("DTTM2")[2].as_py(),
                dt.datetime(2025, 12, 31, 23, 59, 59, 999000),
            )


if __name__ == "__main__":
    unittest.main()
