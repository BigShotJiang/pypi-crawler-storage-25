"""
Unit tests for the ODBC `cursor.description` -> `pa.Schema` mapper.

These tests pin down the contract the parquet-writing code in
`ODBCDataSource` relies on: source DDL precision and scale propagate to
PyArrow decimals, declared Python types map to fixed PyArrow types, and
unknown type codes fall back to None so the caller can decide whether to
infer per-batch.
"""

import datetime as dt
import unittest

from decimal import Decimal

import pyarrow as pa

from data_exchange_agent.data_sources.odbc_schema import (
    field_type_from_description,
    schema_from_description,
)


class TestFieldTypeFromDescription(unittest.TestCase):
    """Map a single (type_code, precision, scale) triple to a `pa.DataType`."""

    def test_decimal_uses_declared_precision_and_scale(self):
        result = field_type_from_description(Decimal, precision=38, scale=6)
        self.assertEqual(result, pa.decimal128(38, 6))

    def test_decimal_missing_precision_falls_back_to_38(self):
        # Some drivers report precision=0 for computed decimal expressions;
        # 38 is the canonical maximum that fits any declared SQL DECIMAL.
        result = field_type_from_description(Decimal, precision=None, scale=6)
        self.assertEqual(result, pa.decimal128(38, 6))

    def test_decimal_missing_scale_defaults_to_zero(self):
        result = field_type_from_description(Decimal, precision=10, scale=None)
        self.assertEqual(result, pa.decimal128(10, 0))

    def test_decimal_precision_over_38_uses_decimal256(self):
        result = field_type_from_description(Decimal, precision=50, scale=4)
        self.assertEqual(result, pa.decimal256(50, 4))

    def test_string_numeric_type_code_with_ddl_uses_decimal256(self):
        result = field_type_from_description("NUMERIC", precision=50, scale=4)
        self.assertEqual(result, pa.decimal256(50, 4))

    def test_bool(self):
        self.assertEqual(
            field_type_from_description(bool, precision=None, scale=None),
            pa.bool_(),
        )

    def test_string(self):
        self.assertEqual(
            field_type_from_description(str, precision=None, scale=None),
            pa.string(),
        )

    def test_integer(self):
        self.assertEqual(
            field_type_from_description(int, precision=None, scale=None),
            pa.int64(),
        )

    def test_float(self):
        self.assertEqual(
            field_type_from_description(float, precision=None, scale=None),
            pa.float64(),
        )

    def test_bytes(self):
        self.assertEqual(
            field_type_from_description(bytes, precision=None, scale=None),
            pa.binary(),
        )

    def test_datetime(self):
        self.assertEqual(
            field_type_from_description(dt.datetime, precision=None, scale=None),
            pa.timestamp("us"),
        )

    def test_date(self):
        self.assertEqual(
            field_type_from_description(dt.date, precision=None, scale=None),
            pa.date32(),
        )

    def test_time(self):
        self.assertEqual(
            field_type_from_description(dt.time, precision=None, scale=None),
            pa.time64("us"),
        )

    def test_unknown_type_code_returns_none_for_fallback(self):
        # Some driver-specific types (geography, hierarchyid, custom UDTs)
        # don't have a Python class we can map. The mapper signals "unknown"
        # by returning None so the caller can fall back to per-batch
        # inference for that one column rather than failing the whole table.
        class _UnknownDriverType:
            pass

        result = field_type_from_description(
            _UnknownDriverType, precision=None, scale=None
        )
        self.assertIsNone(result)

    def test_none_type_code_returns_none(self):
        # Defensive: a missing type_code shouldn't crash the mapper.
        result = field_type_from_description(None, precision=None, scale=None)
        self.assertIsNone(result)


class TestSchemaFromDescription(unittest.TestCase):
    """Build a parallel (types, names) pair from a full `cursor.description`."""

    def test_empty_description(self):
        column_types, column_names = schema_from_description([])
        self.assertEqual(column_types, [])
        self.assertEqual(column_names, [])

    def test_preserves_column_order(self):
        description = [
            ("Z", str, None, None, None, None, True),
            ("A", int, None, None, None, None, True),
            ("M", bool, None, None, None, None, True),
        ]
        column_types, column_names = schema_from_description(description)
        self.assertEqual(column_names, ["Z", "A", "M"])
        self.assertEqual(column_types, [pa.string(), pa.int64(), pa.bool_()])

    def test_shipment_shaped_description(self):
        # Mirrors the production SHIPMENT failure: sparse-NULL columns plus
        # decimals with declared precision/scale from the source DDL.
        description = [
            ("EXCHANGE_RATE", Decimal, None, None, 38, 6, True),
            ("TOTAL_WEIGHT_STANDARD", Decimal, None, None, 38, 5, True),
            ("IS_ARCHIVEABLE", bool, None, None, None, None, True),
            ("AUDIT_CATEGORY", str, None, None, None, None, True),
            ("PAYMENT_TERMS", int, None, None, None, None, True),
        ]
        column_types, column_names = schema_from_description(description)

        self.assertEqual(
            column_names,
            [
                "EXCHANGE_RATE",
                "TOTAL_WEIGHT_STANDARD",
                "IS_ARCHIVEABLE",
                "AUDIT_CATEGORY",
                "PAYMENT_TERMS",
            ],
        )
        self.assertEqual(
            column_types,
            [
                pa.decimal128(38, 6),
                pa.decimal128(38, 5),
                pa.bool_(),
                pa.string(),
                pa.int64(),
            ],
        )

    def test_unknown_type_yields_none_in_types_list(self):
        # Unknown type codes leave a None placeholder so the caller can
        # infer per-batch for that one column without losing column ordering.
        class _CustomGeographyType:
            pass

        description = [
            ("ID", int, None, None, None, None, False),
            ("LOCATION", _CustomGeographyType, None, None, None, None, True),
            ("NAME", str, None, None, None, None, True),
        ]
        column_types, column_names = schema_from_description(description)

        self.assertEqual(column_names, ["ID", "LOCATION", "NAME"])
        self.assertEqual(column_types[0], pa.int64())
        self.assertIsNone(column_types[1])
        self.assertEqual(column_types[2], pa.string())

    def test_short_tuple_description_is_tolerated(self):
        """
        Defensive: malformed mock cursors with sub-7-tuple entries still parse.

        Real DB-API 2.0 drivers always return 7-tuples, but defensive parsing
        keeps the writer functional when callers pass abbreviated descriptions
        (e.g. legacy unit-test mocks). Missing fields default to ``None`` so
        the column falls back to per-batch inference.
        """
        description = [
            ("just_a_name",),
            ("name_and_type", int),
        ]
        column_types, column_names = schema_from_description(description)

        self.assertEqual(column_names, ["just_a_name", "name_and_type"])
        self.assertIsNone(column_types[0])  # no type info -> infer
        self.assertEqual(column_types[1], pa.int64())  # type info preserved


if __name__ == "__main__":
    unittest.main()
