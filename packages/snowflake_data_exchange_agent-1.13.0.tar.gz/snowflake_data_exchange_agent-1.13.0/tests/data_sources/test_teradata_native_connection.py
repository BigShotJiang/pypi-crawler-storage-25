"""Unit tests for the teradata_connection auto-detect module."""

from __future__ import annotations

import importlib
import types
from unittest.mock import MagicMock, patch


from data_exchange_agent.config.sections.connections.dialects.teradata import (
    DEFAULT_TERADATA_ODBC_DRIVER,
    TeradataConnectionConfig,
)
from data_exchange_agent.data_sources.teradata_connection import (
    is_teradatasql_available,
    open_source_connection,
    open_teradata_connection,
)


def _make_td_config(**overrides) -> TeradataConnectionConfig:
    """Build a minimal TeradataConnectionConfig for tests."""
    defaults = dict(
        host="10.0.0.1",
        database="testdb",
        username="user",
        password="pass",
        auto_detect_driver=False,
        odbc_driver=DEFAULT_TERADATA_ODBC_DRIVER,
    )
    defaults.update(overrides)
    return TeradataConnectionConfig(**defaults)


# ---------------------------------------------------------------------------
# is_teradatasql_available
# ---------------------------------------------------------------------------


class TestIsTeradatasqlAvailable:
    """Tests for the cached import check."""

    def test_returns_true_when_importable(self):
        is_teradatasql_available.cache_clear()
        fake_module = types.ModuleType("teradatasql")
        with patch.dict("sys.modules", {"teradatasql": fake_module}):
            assert is_teradatasql_available() is True

    def test_returns_false_when_not_importable(self):
        is_teradatasql_available.cache_clear()
        with patch.dict("sys.modules", {"teradatasql": None}):
            # Setting a module to None in sys.modules causes ImportError
            assert is_teradatasql_available() is False

    def test_result_is_cached(self):
        is_teradatasql_available.cache_clear()
        fake_module = types.ModuleType("teradatasql")
        with patch.dict("sys.modules", {"teradatasql": fake_module}):
            first = is_teradatasql_available()
        # Even after removing the fake module, cached value persists
        assert is_teradatasql_available() is first
        is_teradatasql_available.cache_clear()


# ---------------------------------------------------------------------------
# open_teradata_connection
# ---------------------------------------------------------------------------


class TestOpenTeradataConnection:
    """Tests for the connection factory."""

    def test_uses_teradatasql_when_available(self):
        is_teradatasql_available.cache_clear()
        mock_td = MagicMock()
        mock_conn = MagicMock()
        mock_td.connect.return_value = mock_conn

        with patch.dict("sys.modules", {"teradatasql": mock_td}):
            config = _make_td_config()
            conn = open_teradata_connection(config)

        mock_td.connect.assert_called_once_with(
            host="10.0.0.1",
            dbs_port="1025",
            user="user",
            password="pass",
            database="testdb",
            logmech="TD2",
        )
        assert conn is mock_conn
        assert mock_conn.autocommit is True
        is_teradatasql_available.cache_clear()

    def test_uses_dbc_name_over_host_when_set(self):
        is_teradatasql_available.cache_clear()
        mock_td = MagicMock()
        mock_conn = MagicMock()
        mock_td.connect.return_value = mock_conn

        with patch.dict("sys.modules", {"teradatasql": mock_td}):
            config = _make_td_config(dbc_name="td-cop-alias")
            conn = open_teradata_connection(config)

        mock_td.connect.assert_called_once_with(
            host="td-cop-alias",
            dbs_port="1025",
            user="user",
            password="pass",
            database="testdb",
            logmech="TD2",
        )
        assert conn is mock_conn
        is_teradatasql_available.cache_clear()

    def test_passes_custom_port(self):
        is_teradatasql_available.cache_clear()
        mock_td = MagicMock()
        mock_conn = MagicMock()
        mock_td.connect.return_value = mock_conn

        with patch.dict("sys.modules", {"teradatasql": mock_td}):
            config = _make_td_config(port=9999)
            conn = open_teradata_connection(config)

        mock_td.connect.assert_called_once_with(
            host="10.0.0.1",
            dbs_port="9999",
            user="user",
            password="pass",
            database="testdb",
            logmech="TD2",
        )
        assert conn is mock_conn
        is_teradatasql_available.cache_clear()

    def test_falls_back_to_pyodbc(self):
        is_teradatasql_available.cache_clear()
        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        mock_pyodbc.connect.return_value = mock_conn

        with patch.dict("sys.modules", {"teradatasql": None}):
            with patch(
                "data_exchange_agent.data_sources.teradata_connection.is_teradatasql_available",
                return_value=False,
            ):
                with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
                    # Re-import to pick up the mock
                    import data_exchange_agent.data_sources.teradata_connection as mod

                    importlib.reload(mod)
                    config = _make_td_config()
                    conn = mod.open_teradata_connection(config)

        mock_pyodbc.connect.assert_called_once_with(config.connection_string)
        assert conn is mock_conn
        assert mock_conn.autocommit is True
        is_teradatasql_available.cache_clear()
        importlib.reload(mod)

    def test_sets_autocommit_for_teradatasql(self):
        is_teradatasql_available.cache_clear()
        mock_td = MagicMock()
        mock_conn = MagicMock()
        mock_td.connect.return_value = mock_conn

        with patch.dict("sys.modules", {"teradatasql": mock_td}):
            config = _make_td_config()
            open_teradata_connection(config)

        assert mock_conn.autocommit is True
        is_teradatasql_available.cache_clear()


# ---------------------------------------------------------------------------
# is_pyodbc_connection
# ---------------------------------------------------------------------------


class TestIsPyodbcConnection:
    """Tests for the pyodbc type check."""

    def test_returns_true_for_pyodbc_connection(self):
        class FakePyodbcConnection:
            pass

        mock_pyodbc = MagicMock()
        mock_pyodbc.Connection = FakePyodbcConnection
        mock_conn = FakePyodbcConnection()

        with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
            import data_exchange_agent.data_sources.teradata_connection as mod

            importlib.reload(mod)
            result = mod.is_pyodbc_connection(mock_conn)

        assert result is True
        importlib.reload(mod)

    def test_returns_false_for_non_pyodbc_connection(self):
        mock_pyodbc = MagicMock()

        class FakeConnection:
            pass

        mock_pyodbc.Connection = FakeConnection

        fake_conn = MagicMock()

        with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
            import data_exchange_agent.data_sources.teradata_connection as mod

            importlib.reload(mod)
            result = mod.is_pyodbc_connection(fake_conn)

        assert result is False
        importlib.reload(mod)

    def test_returns_false_when_pyodbc_not_installed(self):
        with patch.dict("sys.modules", {"pyodbc": None}):
            import data_exchange_agent.data_sources.teradata_connection as mod

            importlib.reload(mod)
            result = mod.is_pyodbc_connection(MagicMock())

        assert result is False
        importlib.reload(mod)


# ---------------------------------------------------------------------------
# ODBCDataSource integration (output converter guard)
# ---------------------------------------------------------------------------


class TestODBCDataSourceTeradataPath:
    """Verify that register_output_converters_for_odbc_engine is skipped for teradatasql."""

    @patch("data_exchange_agent.data_sources.odbc_data_source.open_source_connection")
    @patch(
        "data_exchange_agent.data_sources.odbc_data_source.is_pyodbc_connection",
        return_value=False,
    )
    @patch(
        "data_exchange_agent.data_sources.odbc_data_source.register_output_converters_for_odbc_engine"
    )
    def test_output_converters_skipped_for_teradatasql(self, mock_register, mock_is_pyodbc, mock_open_src):
        mock_conn = MagicMock()
        mock_open_src.return_value = mock_conn

        # Build a minimal ODBCDataSource with mocked dependencies
        from data_exchange_agent.data_sources.odbc_data_source import ODBCDataSource

        td_config = _make_td_config()
        mock_logger = MagicMock()
        mock_program_config = MagicMock()
        mock_program_config.__getitem__ = MagicMock(return_value={"teradata": td_config})

        ds = ODBCDataSource.__new__(ODBCDataSource)
        ds.logger = mock_logger
        ds._statement = "SELECT 1"
        ds._results_folder_path = "/tmp/test"
        ds._base_file_name = "result"
        ds._batch_size = 100
        ds._use_database_command = None
        ds._engine = "teradata"
        ds._source_connection_config = td_config
        ds._ODBCDataSource__connection_string = td_config.connection_string

        # Simulate the connection path in export_data
        mock_cursor = MagicMock()
        mock_cursor.description = [("col1",)]
        mock_cursor.fetchmany.return_value = []
        mock_conn.cursor.return_value = mock_cursor

        with patch("data_exchange_agent.data_sources.odbc_data_source.get_permitted_sql_command_type") as mock_sql_type:
            from data_exchange_agent.data_sources.sql_command_type import SQLCommandType

            mock_sql_type.return_value = SQLCommandType.SELECT
            ds.export_data()

        mock_register.assert_not_called()


class TestOpenSourceConnection:
    """Tests for the open_source_connection dispatch function."""

    @patch("data_exchange_agent.data_sources.teradata_connection.open_teradata_connection")
    def test_teradata_engine_dispatches_to_open_teradata_connection(self, mock_open_td):
        mock_conn = MagicMock()
        mock_open_td.return_value = mock_conn
        config = _make_td_config()

        result = open_source_connection("teradata", config)

        mock_open_td.assert_called_once_with(config)
        assert result is mock_conn

    def test_non_teradata_engine_uses_pyodbc(self):
        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        mock_pyodbc.connect.return_value = mock_conn

        mock_config = MagicMock()
        mock_config.connection_string = "DSN=test"

        with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
            result = open_source_connection("sqlserver", mock_config)

        mock_pyodbc.connect.assert_called_once_with("DSN=test")
        assert result is mock_conn

    @patch("data_exchange_agent.data_sources.oracle_connection.open_oracle_connection")
    def test_oracle_engine_dispatches_to_open_oracle_connection(self, mock_open_ora):
        from data_exchange_agent.config.sections.connections.dialects.oracle.config import (
            OracleConnectionConfig,
        )

        mock_conn = MagicMock()
        mock_open_ora.return_value = mock_conn
        config = OracleConnectionConfig(
            database="XE",
            username="u",
            password="p",
            host="h",
            port=1521,
            odbc_driver="Oracle 23 ODBC driver",
            auto_detect_driver=False,
        )

        result = open_source_connection("oracle", config)

        mock_open_ora.assert_called_once_with(config)
        assert result is mock_conn
