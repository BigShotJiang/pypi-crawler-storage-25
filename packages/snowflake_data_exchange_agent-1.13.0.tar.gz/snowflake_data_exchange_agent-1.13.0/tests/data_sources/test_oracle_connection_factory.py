"""Tests for :mod:`data_exchange_agent.data_sources.oracle_connection` (driver selection)."""

from __future__ import annotations

import os
import threading
from unittest.mock import MagicMock, call, patch

import pytest

from data_exchange_agent.config.sections.connections.dialects.oracle.config import (
    OracleConnectionConfig,
)
from data_exchange_agent.data_sources.oracle_connection import (
    _TNS_ADMIN_LOCK,
    _connect_with_retry,
    is_oracledb_available,
    open_oracle_connection,
    open_oracle_odbc_connection,
)


def _minimal_oracle_config(**kwargs: object) -> OracleConnectionConfig:
    defaults: dict[str, object] = {
        "database": "XE",
        "username": "u",
        "password": "p",
        "host": "h",
        "port": 1521,
        "odbc_driver": "Oracle 23 ODBC driver",
        "auto_detect_driver": False,
        "oracledb_preferred": False,
    }
    defaults.update(kwargs)
    return OracleConnectionConfig(**defaults)


class TestOpenOracleOdbcConnectionAlias:
    """``open_oracle_odbc_connection`` must be an alias for ``open_oracle_connection``."""

    def test_alias_is_same_object(self) -> None:
        assert open_oracle_odbc_connection is open_oracle_connection


class TestOracledbPath:
    """Tests for the oracledb-preferred code path."""

    def test_uses_oracledb_when_preferred(self) -> None:
        is_oracledb_available.cache_clear()
        mock_oracledb = MagicMock()
        mock_conn = MagicMock()
        mock_oracledb.connect.return_value = mock_conn
        mock_oracledb.is_thin_mode.return_value = True

        cfg = _minimal_oracle_config(oracledb_preferred=True)

        with patch.dict("sys.modules", {"oracledb": mock_oracledb}):
            conn = open_oracle_connection(cfg)

        assert conn is mock_conn
        mock_oracledb.connect.assert_called_once_with(user="u", password="p", dsn="h:1521/XE")
        is_oracledb_available.cache_clear()

    def test_falls_back_to_pyodbc_when_oracledb_import_fails(self) -> None:
        is_oracledb_available.cache_clear()
        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        mock_pyodbc.connect.return_value = mock_conn

        cfg = _minimal_oracle_config(oracledb_preferred=True)

        with patch.dict("sys.modules", {"oracledb": None}):
            with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
                conn = open_oracle_connection(cfg)

        assert conn is mock_conn
        is_oracledb_available.cache_clear()

    def test_falls_back_to_pyodbc_when_oracledb_connect_raises(self) -> None:
        is_oracledb_available.cache_clear()
        mock_oracledb = MagicMock()
        mock_oracledb.connect.side_effect = Exception("ORA-01017")
        mock_oracledb.is_thin_mode.return_value = True

        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        mock_pyodbc.connect.return_value = mock_conn

        cfg = _minimal_oracle_config(oracledb_preferred=True)

        with patch.dict("sys.modules", {"oracledb": mock_oracledb, "pyodbc": mock_pyodbc}):
            conn = open_oracle_connection(cfg)

        assert conn is mock_conn
        is_oracledb_available.cache_clear()


class TestPyodbcPath:
    """Tests for the pyodbc fallback code path."""

    def test_calls_pyodbc_with_ansi_true(self) -> None:
        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        mock_pyodbc.connect.return_value = mock_conn

        cfg = _minimal_oracle_config(oracledb_preferred=False)

        with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
            conn = open_oracle_connection(cfg)

        assert conn is mock_conn
        mock_pyodbc.connect.assert_called_once_with(cfg.build_connection_string(), ansi=True)

    def test_sets_autocommit_true(self) -> None:
        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        mock_pyodbc.connect.return_value = mock_conn

        cfg = _minimal_oracle_config(oracledb_preferred=False)

        with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
            open_oracle_connection(cfg)

        assert mock_conn.autocommit is True

    def test_sets_tns_admin_only_during_connect(self) -> None:
        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        seen_tns: dict[str, str | None] = {}

        def capture_connect(_conn_str: str, **_kw: object) -> MagicMock:
            seen_tns["during"] = os.environ.get("TNS_ADMIN")
            return mock_conn

        mock_pyodbc.connect.side_effect = capture_connect
        cfg = _minimal_oracle_config(tns_admin="/net/admin", oracledb_preferred=False)

        with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
            with patch.dict(os.environ, {}, clear=True):
                open_oracle_connection(cfg)
                seen_tns["after"] = os.environ.get("TNS_ADMIN")

        assert seen_tns["during"] == "/net/admin"
        assert seen_tns["after"] is None

    def test_restores_existing_tns_admin_after_connect(self) -> None:
        mock_pyodbc = MagicMock()
        mock_pyodbc.connect.return_value = MagicMock()
        cfg = _minimal_oracle_config(tns_admin="/new/admin", oracledb_preferred=False)

        with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
            with patch.dict(os.environ, {"TNS_ADMIN": "/old/admin"}):
                open_oracle_connection(cfg)
                assert os.environ["TNS_ADMIN"] == "/old/admin"


class TestRetryLogic:
    """Tests for :func:`_connect_with_retry`."""

    def test_succeeds_on_first_attempt(self) -> None:
        mock_conn = MagicMock()
        result = _connect_with_retry(lambda: mock_conn, max_attempts=3)
        assert result is mock_conn

    def test_retries_on_transient_failure(self) -> None:
        mock_conn = MagicMock()
        attempts: list[int] = []

        def flaky() -> MagicMock:
            attempts.append(1)
            if len(attempts) < 2:
                raise OSError("transient")
            return mock_conn

        with patch("data_exchange_agent.data_sources.oracle_connection.time.sleep"):
            result = _connect_with_retry(flaky, max_attempts=3, delay=0.01)

        assert result is mock_conn
        assert len(attempts) == 2

    def test_raises_after_max_attempts(self) -> None:
        def always_fail() -> None:
            raise OSError("always fails")

        with patch("data_exchange_agent.data_sources.oracle_connection.time.sleep"):
            with pytest.raises(OSError, match="always fails"):
                _connect_with_retry(always_fail, max_attempts=3, delay=0.01)

    def test_sleeps_with_exponential_backoff(self) -> None:
        call_count = 0

        def fail_twice() -> MagicMock:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise OSError("fail")
            return MagicMock()

        with patch("data_exchange_agent.data_sources.oracle_connection.time.sleep") as mock_sleep:
            _connect_with_retry(fail_twice, max_attempts=3, delay=1.0, multiplier=2.0)

        assert mock_sleep.call_count == 2
        assert mock_sleep.call_args_list == [call(1.0), call(2.0)]


class TestTNSAdminLock:
    """Verify that _TNS_ADMIN_LOCK serialises concurrent TNS_ADMIN mutations."""

    def test_lock_is_module_level_threading_lock(self) -> None:
        assert isinstance(_TNS_ADMIN_LOCK, type(threading.Lock()))


class TestOpenOracleConnectionDispatch:
    """Tests for :func:`open_oracle_connection` when driven by :func:`is_oracledb_available`."""

    def test_falls_back_to_pyodbc_when_oracledb_unavailable(self) -> None:
        mock_pyodbc = MagicMock()
        mock_conn = MagicMock()
        mock_pyodbc.connect.return_value = mock_conn
        cfg = _minimal_oracle_config(oracledb_preferred=True)

        with patch(
            "data_exchange_agent.data_sources.oracle_connection.is_oracledb_available",
            return_value=False,
        ):
            with patch.dict("sys.modules", {"pyodbc": mock_pyodbc}):
                conn = open_oracle_connection(cfg)

        assert conn is mock_conn
        mock_pyodbc.connect.assert_called_once_with(cfg.build_connection_string(), ansi=True)

    def test_uses_oracledb_when_available(self) -> None:
        is_oracledb_available.cache_clear()
        mock_conn = MagicMock()
        mock_oracledb = MagicMock()
        mock_oracledb.connect.return_value = mock_conn
        cfg = _minimal_oracle_config(oracledb_preferred=True)

        with patch(
            "data_exchange_agent.data_sources.oracle_connection.is_oracledb_available",
            return_value=True,
        ):
            with patch.dict("sys.modules", {"oracledb": mock_oracledb}):
                conn = open_oracle_connection(cfg)

        assert conn is mock_conn
        mock_oracledb.connect.assert_called_once_with(
            user="u",
            password="p",
            dsn="h:1521/XE",
        )
        assert mock_conn.autocommit is True
        is_oracledb_available.cache_clear()
