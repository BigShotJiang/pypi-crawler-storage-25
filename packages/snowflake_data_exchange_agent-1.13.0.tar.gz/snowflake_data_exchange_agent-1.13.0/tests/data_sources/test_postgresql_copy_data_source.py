import os
import tempfile
import unittest
from unittest.mock import Mock, patch

from data_exchange_agent.config.sections.connections.dialects.postgresql.config import (
    PostgresqlConnectionConfig,
)
from data_exchange_agent.constants import config_keys
from data_exchange_agent.constants.connection_types import ConnectionType
from data_exchange_agent.data_sources.base import BaseDataSource
from data_exchange_agent.data_sources.postgresql_copy_data_source import (
    PostgresqlCopyDataSource,
)


class TestPostgresqlCopyDataSourceInit(unittest.TestCase):
    """Tests for PostgresqlCopyDataSource construction."""

    def test_instantiates_as_base_data_source(self) -> None:
        cfg = PostgresqlConnectionConfig(
            driver_name=ConnectionType.POSTGRESQL,
            database="db", username="u", host="h", password="p",
            port=5432, auto_detect_driver=False, use_copy=True,
        )
        mock_pc = Mock()
        mock_pc.__getitem__ = Mock(side_effect=lambda k: {"pg": cfg} if k == config_keys.CONNECTIONS__SOURCE else (_ for _ in ()).throw(KeyError(k)))

        ds = PostgresqlCopyDataSource(
            engine="pg",
            statement="SELECT 1",
            results_folder_path="/tmp/test",
            logger=Mock(),
            program_config=mock_pc,
        )
        self.assertIsInstance(ds, BaseDataSource)
        self.assertEqual(ds.statement, "SELECT 1")


class TestPostgresqlCopyDataSourceBuildCommand(unittest.TestCase):
    """Tests for PostgresqlCopyDataSource._build_psql_command output."""

    def test_command_structure(self) -> None:
        cfg = PostgresqlConnectionConfig(
            driver_name=ConnectionType.POSTGRESQL,
            database="sandbox", username="postgres", host="localhost",
            password="postgres", port=5434, auto_detect_driver=False, use_copy=True,
        )
        mock_pc = Mock()
        mock_pc.__getitem__ = Mock(side_effect=lambda k: {"pg": cfg} if k == config_keys.CONNECTIONS__SOURCE else (_ for _ in ()).throw(KeyError(k)))

        ds = PostgresqlCopyDataSource(
            engine="pg",
            statement="SELECT * FROM t",
            results_folder_path="/tmp/test",
            logger=Mock(),
            program_config=mock_pc,
        )
        cmd = ds._build_psql_command("/tmp/test/result_001.csv")
        self.assertEqual(cmd[0], "psql")
        self.assertTrue(cmd[1].startswith("postgresql://"))
        self.assertIn("-w", cmd)
        self.assertIn("-c", cmd)
        # The last -c value should be the \copy command
        last_c_idx = len(cmd) - 1 - cmd[::-1].index("-c")
        copy_arg = cmd[last_c_idx + 1]
        self.assertTrue(copy_arg.startswith("\\copy"))

    def test_includes_use_database_command(self) -> None:
        cfg = PostgresqlConnectionConfig(
            driver_name=ConnectionType.POSTGRESQL,
            database="db", username="u", host="h", password="p",
            port=5432, auto_detect_driver=False, use_copy=True,
        )
        mock_pc = Mock()
        mock_pc.__getitem__ = Mock(side_effect=lambda k: {"pg": cfg} if k == config_keys.CONNECTIONS__SOURCE else (_ for _ in ()).throw(KeyError(k)))

        ds = PostgresqlCopyDataSource(
            engine="pg",
            statement="SELECT 1",
            results_folder_path="/tmp/test",
            use_database_command="SET search_path TO public;",
            logger=Mock(),
            program_config=mock_pc,
        )
        cmd = ds._build_psql_command("/tmp/test/out.csv")
        # Should have two -c flags
        c_indices = [i for i, v in enumerate(cmd) if v == "-c"]
        self.assertEqual(len(c_indices), 2)
        self.assertEqual(cmd[c_indices[0] + 1], "SET search_path TO public;")
        self.assertTrue(cmd[c_indices[1] + 1].startswith("\\copy"))


class TestPostgresqlCopyExportPsqlNotFound(unittest.TestCase):
    """Tests for behavior when psql is missing from PATH."""

    def test_raises_when_psql_not_on_path(self) -> None:
        cfg = PostgresqlConnectionConfig(
            driver_name=ConnectionType.POSTGRESQL,
            database="db", username="u", host="h", password="p",
            port=5432, auto_detect_driver=False, use_copy=True,
        )
        mock_pc = Mock()
        mock_pc.__getitem__ = Mock(side_effect=lambda k: {"pg": cfg} if k == config_keys.CONNECTIONS__SOURCE else (_ for _ in ()).throw(KeyError(k)))

        tmp = tempfile.mkdtemp()
        ds = PostgresqlCopyDataSource(
            engine="pg",
            statement="SELECT 1",
            results_folder_path=tmp,
            logger=Mock(),
            program_config=mock_pc,
        )

        with patch("data_exchange_agent.data_sources.postgresql_copy_data_source.subprocess.run") as mock_run:
            mock_run.side_effect = FileNotFoundError("No such file: psql")
            with self.assertRaises(Exception) as ctx:
                ds.export_data()
            self.assertIn("psql utility is not installed", str(ctx.exception))

        os.rmdir(tmp)


class TestPostgresqlCopyExportFailure(unittest.TestCase):
    """Tests for behavior when the psql subprocess exits non-zero."""

    def test_raises_on_nonzero_exit(self) -> None:
        cfg = PostgresqlConnectionConfig(
            driver_name=ConnectionType.POSTGRESQL,
            database="db", username="u", host="h", password="p",
            port=5432, auto_detect_driver=False, use_copy=True,
        )
        mock_pc = Mock()
        mock_pc.__getitem__ = Mock(side_effect=lambda k: {"pg": cfg} if k == config_keys.CONNECTIONS__SOURCE else (_ for _ in ()).throw(KeyError(k)))

        tmp = tempfile.mkdtemp()
        ds = PostgresqlCopyDataSource(
            engine="pg",
            statement="SELECT 1",
            results_folder_path=tmp,
            logger=Mock(),
            program_config=mock_pc,
        )

        mock_process = Mock()
        mock_process.stdout = iter([""])
        mock_process.stderr = iter(["psql: error: FATAL: password authentication failed\n"])
        mock_process.wait.return_value = 2

        with patch("data_exchange_agent.data_sources.postgresql_copy_data_source.subprocess.run"):
            with patch("data_exchange_agent.data_sources.postgresql_copy_data_source.subprocess.Popen", return_value=mock_process):
                with self.assertRaises(Exception) as ctx:
                    ds.export_data()
                self.assertIn("return code 2", str(ctx.exception))
                self.assertIn("password authentication failed", str(ctx.exception))

        os.rmdir(tmp)


class TestRewriteRecordDelimiter(unittest.TestCase):
    """Tests for the CSV record delimiter rewrite pass."""

    def _make_ds(self) -> PostgresqlCopyDataSource:
        cfg = PostgresqlConnectionConfig(
            driver_name=ConnectionType.POSTGRESQL,
            database="db", username="u", host="h", password="p",
            port=5432, auto_detect_driver=False, use_copy=True,
        )
        mock_pc = Mock()
        mock_pc.__getitem__ = Mock(
            side_effect=lambda k: {"pg": cfg} if k == config_keys.CONNECTIONS__SOURCE else (_ for _ in ()).throw(KeyError(k))
        )
        return PostgresqlCopyDataSource(
            engine="pg",
            statement="SELECT 1",
            results_folder_path=tempfile.mkdtemp(),
            logger=Mock(),
            program_config=mock_pc,
        )

    def test_replaces_newline_terminators_with_record_separator(self) -> None:
        ds = self._make_ds()
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False, encoding="utf-8", newline="") as f:
            f.write("col1\x1fcol2\ncol3\x1fcol4\n")
            path = f.name
        try:
            ds._rewrite_record_delimiter(path)
            with open(path, "rb") as f:
                content = f.read()
            self.assertEqual(content, b"col1\x1fcol2\x1ecol3\x1fcol4\x1e")
        finally:
            os.unlink(path)

    def test_embedded_newline_in_quoted_field_is_preserved(self) -> None:
        ds = self._make_ds()
        # psql \copy quotes fields containing newlines using double-quote doubling
        with tempfile.NamedTemporaryFile(mode="w", suffix=".csv", delete=False, encoding="utf-8", newline="") as f:
            f.write('id\x1f"value with\nnewline"\n')
            path = f.name
        try:
            ds._rewrite_record_delimiter(path)
            with open(path, encoding="utf-8", newline="") as f:
                content = f.read()
            # Record terminator becomes \x1e; field with embedded \n stays quoted (csv writer quotes \n-containing fields)
            self.assertEqual(content, 'id\x1f"value with\nnewline"\x1e')
        finally:
            os.unlink(path)
