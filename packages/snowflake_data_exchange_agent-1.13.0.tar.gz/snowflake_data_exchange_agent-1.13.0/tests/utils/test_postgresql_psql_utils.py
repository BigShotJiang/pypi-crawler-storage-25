import unittest

from data_exchange_agent.utils.postgresql_psql_utils import (
    build_connection_uri,
    build_copy_command,
    mask_uri_password,
)


class TestBuildConnectionUri(unittest.TestCase):
    """Tests for build_connection_uri."""

    def test_percent_encodes_special_chars(self) -> None:
        uri = build_connection_uri(
            host="localhost",
            port=5432,
            dbname="mydb",
            user="user@domain",
            password="p@ss:word/slash",
            sslmode=None,
        )
        self.assertIn("user%40domain", uri)
        self.assertIn("p%40ss%3Aword%2Fslash", uri)
        self.assertNotIn("@domain", uri.split("@")[0].split("//")[1])

    def test_appends_sslmode_query_param(self) -> None:
        uri = build_connection_uri(
            host="pg.example.com",
            port=5433,
            dbname="prod",
            user="u",
            password="p",
            sslmode="require",
        )
        self.assertTrue(uri.endswith("?sslmode=require"))

    def test_no_sslmode_when_none(self) -> None:
        uri = build_connection_uri(
            host="h",
            port=5432,
            dbname="d",
            user="u",
            password="p",
            sslmode=None,
        )
        self.assertNotIn("?sslmode=require", uri)


class TestBuildCopyCommand(unittest.TestCase):
    """Tests for build_copy_command."""

    def test_wraps_select_in_copy(self) -> None:
        cmd = build_copy_command("SELECT a, b FROM t;", "/tmp/out.csv")
        self.assertTrue(cmd.startswith("\\copy ("))
        self.assertIn("SELECT a, b FROM t", cmd)
        self.assertNotIn("FROM t;", cmd)
        self.assertIn("TO '/tmp/out.csv'", cmd)

    def test_includes_format_options(self) -> None:
        cmd = build_copy_command("SELECT 1", "/tmp/x.csv")
        self.assertIn("FORMAT csv", cmd)
        self.assertIn("DELIMITER E'\\x1f'", cmd)
        self.assertIn("QUOTE '\"'", cmd)
        self.assertIn("ESCAPE '\"'", cmd)
        self.assertIn("NULL ''", cmd)


class TestMaskUriPassword(unittest.TestCase):
    """Tests for mask_uri_password."""

    def test_handles_special_chars_in_password(self) -> None:
        cmd = ["psql", "postgresql://u:p%40ss%3Aw@host:5432/db", "-w"]
        masked = mask_uri_password(cmd)
        self.assertIn("u:***@host", masked)
        self.assertNotIn("p%40ss", masked)
