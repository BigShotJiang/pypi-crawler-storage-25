"""
Queue implementations for task management.

This package contains queue implementations for managing and processing
tasks in the data exchange agent.
"""
