from __future__ import annotations

from urllib.parse import quote


_FIELD_DELIMITER = r"\x1f"


def build_connection_uri(
    *,
    host: str,
    port: int,
    dbname: str,
    user: str,
    password: str,
    sslmode: str | None,
) -> str:
    """Build a postgresql:// URI with percent-encoded credentials."""
    uri = f"postgresql://{quote(user, safe='')}:{quote(password, safe='')}@{host}:{port}/{quote(dbname, safe='')}"
    if sslmode:
        uri += f"?sslmode={quote(sslmode, safe='')}"
    return uri


def build_copy_command(select_sql: str, output_path: str) -> str:
    r"""Build the psql \copy meta-command string."""
    body = select_sql.strip().rstrip(";")
    return (
        f"\\copy ({body}) TO '{output_path}' "
        f"WITH (FORMAT csv, DELIMITER E'{_FIELD_DELIMITER}', QUOTE '\"', ESCAPE '\"', NULL '')"
    )


def mask_uri_password(cmd: list[str]) -> str:
    """Return the command as a string with the URI password replaced by ***."""
    masked = []
    for part in cmd:
        if part.startswith("postgresql://") and ":" in part and "@" in part:
            scheme_end = part.index("://") + 3
            at_pos = part.index("@", scheme_end)
            colon_pos = part.index(":", scheme_end)
            masked_part = part[:colon_pos + 1] + "***" + part[at_pos:]
            masked.append(masked_part)
        else:
            masked.append(part)
    return " ".join(masked)
