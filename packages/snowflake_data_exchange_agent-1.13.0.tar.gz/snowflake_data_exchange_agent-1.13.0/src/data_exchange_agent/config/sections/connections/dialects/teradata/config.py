"""Teradata ODBC connection configuration."""

import logging
import warnings

from pydantic import Field, PrivateAttr

from data_exchange_agent.config.sections.connections.dialects.teradata.tpt import (
    TPT_DEFAULT_FIELD_DELIMITER,
    TptConfig,
    _default_tpt_output_and_log_directories,
)
from data_exchange_agent.config.sections.connections.dialects.teradata.write_nos import (
    WriteNosConfig,
)
from data_exchange_agent.config.sections.connections.transports.odbc.base import (
    BaseODBCConnectionConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType


logger = logging.getLogger(__name__)


def _coerce_use_tpt_for_bulk(value: object, *, default: bool = True) -> bool:
    """Interpret ``use_tpt_for_bulk`` from TOML or programmatic kwargs."""
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, int | float):
        return bool(int(value))
    s = str(value).strip().lower()
    if s in ("0", "false", "no", "off", ""):
        return False
    if s in ("1", "true", "yes", "on"):
        return True
    return default


# Connection string template for Teradata ODBC.
# Keyword names follow the Teradata ODBC driver documentation:
# https://docs.teradata.com/r/Teradata-Tools-and-Utilities-Connection-Reference
TERADATA_CONNECTION_STRING = (
    "DRIVER={{{driver}}};" "DBCName={host};" "UID={user};" "PWD={password};" "Database={database};" "PortNumber={port}"
)

# Default Teradata port
DEFAULT_TERADATA_PORT = 1025

# Default ODBC driver for Teradata
DEFAULT_TERADATA_ODBC_DRIVER = "Teradata Database ODBC Driver 17.20"

# Vendor substring in ODBC driver names (pyodbc lists names like "Teradata Database ODBC Driver 17.20").
TERADATA_ODBC_DRIVER_NAME_SUBSTRING = "Teradata"

# Driver name fragments in order of preference (newest first)
_TERADATA_DRIVER_PREFERENCES = [
    DEFAULT_TERADATA_ODBC_DRIVER,
    "Teradata Database ODBC Driver 17.10",
    "Teradata Database ODBC Driver 17.00",
    "Teradata Database ODBC Driver 16.20",
]


def _get_best_teradata_driver(available_drivers: list[str]) -> str | None:
    """
    Pick the best Teradata ODBC driver from a list of available drivers.

    Checks the preference list first (newest to oldest), then falls back
    to any driver whose name contains the Teradata vendor substring.

    Args:
        available_drivers: List of all ODBC driver names on the system.

    Returns:
        The best Teradata driver name, or None if none found.

    """
    for preferred in _TERADATA_DRIVER_PREFERENCES:
        if preferred in available_drivers:
            return preferred

    # Fallback: any driver whose name contains the Teradata vendor substring
    for driver in available_drivers:
        if TERADATA_ODBC_DRIVER_NAME_SUBSTRING in driver:
            return driver

    return None


class TeradataConnectionConfig(BaseODBCConnectionConfig):
    """
    Configuration class for Teradata ODBC connection settings.

    Supports standard username/password authentication via ODBC,
    with optional authentication mechanism selection (TD2, LDAP, KRB5).

    References:
        - https://docs.teradata.com/r/Teradata-Tools-and-Utilities-Connection-Reference
        - https://docs.teradata.com/r/Enterprise_IntelliFlex_VMware/Teradata-ODBC-Driver-for-Presto

    """

    # Override parent fields with Teradata-specific defaults
    driver_name: str = Field(default=ConnectionType.TERADATA, description="Driver name")
    host: str = Field(default="localhost", description="Database host address (DBC name)")
    port: int = Field(
        default=DEFAULT_TERADATA_PORT,
        ge=1,
        le=65535,
        description="Database port number",
    )
    username: str = Field(default="", description="Database username")
    password: str = Field(default="", description="Database password")

    # Teradata-specific fields
    requested_odbc_driver: str | None = Field(
        default=None,
        alias="odbc_driver",
        description="ODBC driver name (auto-detected if not specified)",
    )
    auto_detect_driver: bool = Field(default=True, description="Auto-detect the best available ODBC driver")
    authentication: str | None = Field(
        default=None,
        description="Authentication mechanism (TD2, LDAP, KRB5)",
    )
    dbc_name: str | None = Field(
        default=None,
        description="Teradata DBCName / COP alias; defaults to host when omitted",
    )
    write_nos_config: WriteNosConfig | None = Field(
        default=None,
        exclude=True,  # Don't include in serialization
        description="Optional configuration for WRITE_NOS export operations",
    )
    tpt_config: TptConfig | None = Field(
        default=None,
        exclude=True,  # Don't include in serialization
        description="TPT export configuration including DEA-managed work directories (from_config_dict)",
    )

    # Private attributes for internal state
    _resolved_odbc_driver: str = PrivateAttr()

    @property
    def odbc_driver(self) -> str:
        """Get the resolved ODBC driver name."""
        return self._resolved_odbc_driver

    def model_post_init(self, __context: object) -> None:
        """Resolve the ODBC driver name after field validation."""
        self._resolved_odbc_driver = self._select_odbc_driver(self.requested_odbc_driver, self.auto_detect_driver)

    def build_connection_string(self) -> str:
        """Build the ODBC connection string for Teradata."""
        dbc = self.dbc_name if self.dbc_name is not None else self.host
        connection_string = TERADATA_CONNECTION_STRING.format(
            driver=self._resolved_odbc_driver,
            host=dbc,
            port=self.port,
            database=self.database,
            user=self.username,
            password=self.password,
        )

        # Add authentication mechanism if specified
        if self.authentication:
            connection_string += f";AuthMech={self.authentication}"

        # Add extra options
        for key, value in self.extra_options.items():
            stripped_key = str(key).strip()
            stripped_value = str(value).strip()
            connection_string += f";{stripped_key}={stripped_value}"

        return connection_string

    @classmethod
    def from_config_dict(
        cls,
        database: str,
        username: str,
        host: str = "localhost",
        password: str = "",
        port: int = DEFAULT_TERADATA_PORT,
        odbc_driver: str | None = None,
        driver_name: str | None = None,
        auto_detect_driver: bool = True,
        authentication: str | None = None,
        dbc_name: str | None = None,
        tpt_delimiter: str = TPT_DEFAULT_FIELD_DELIMITER,
        tpt_max_sessions: int = 4,
        write_nos_location_scheme: str | None = None,
        write_nos_location_host: str | None = None,
        write_nos_location_container: str | None = None,
        write_nos_access_id: str | None = None,
        write_nos_access_key: str | None = None,
        write_nos_function_mapping: str | None = None,
        write_nos_authorization_name: str | None = None,
        use_tpt_for_bulk: bool = True,
        **extra_options: str | int | float | bool,
    ) -> "TeradataConnectionConfig":
        """
        Create a TeradataConnectionConfig from a flat configuration dictionary.

        This factory method is used by the TOML configuration loader to construct
        a TeradataConnectionConfig from flat parameters read from the configuration file.

        Args:
            database: Database name
            username: Username for the database
            host: Hostname / DBC name (default: localhost)
            password: Password
            port: Port number (default: 1025)
            odbc_driver: ODBC driver name (optional)
            driver_name: Deprecated. Former TOML key for the ODBC driver string; use ``odbc_driver``.
                The value ``teradata`` (connection type) is ignored for ODBC selection.
            auto_detect_driver: Whether to auto-detect the ODBC driver (default: True)
            authentication: Authentication mechanism (TD2, LDAP, KRB5) (optional)
            dbc_name: DBC name or host override for the connection string (optional)
            tpt_delimiter: TPT field delimiter (default: ASCII File Separator, U+001C)
            tpt_max_sessions: Maximum TPT sessions (default: 4)
            write_nos_location_scheme: Cloud storage scheme (``/s3/``, ``/az/``, ``/gs/``)
            write_nos_location_host: Cloud storage host
            write_nos_location_container: Optional path segment after host (often a prefix
                inside the bucket). Omit or leave empty when the stage is at bucket root.
            write_nos_access_id: Cloud storage access ID (inline credentials mode)
            write_nos_access_key: Cloud storage access key (inline credentials mode)
            write_nos_function_mapping: Teradata function mapping name (preferred mode)
            write_nos_authorization_name: Teradata AUTHORIZATION object name
            use_tpt_for_bulk: When false, omit ``TptConfig`` so Teradata bulk extraction uses ODBC
                (typed Parquet dates). Default true (TPT used when configured).
            **extra_options: Extra options to add to the ODBC connection string

        Returns:
            TeradataConnectionConfig: Configured connection instance

        """
        extra_opts = dict(extra_options)
        if "use_tpt_for_bulk" in extra_opts:
            use_tpt_for_bulk = _coerce_use_tpt_for_bulk(extra_opts.pop("use_tpt_for_bulk"), default=use_tpt_for_bulk)
        for legacy_tpt_path_key in ("tpt_output_directory", "tpt_log_directory"):
            if legacy_tpt_path_key in extra_opts:
                extra_opts.pop(legacy_tpt_path_key)
                warnings.warn(
                    "Teradata connection config: "
                    f"{legacy_tpt_path_key!r} is no longer used; DEA manages TPT output and log directories.",
                    UserWarning,
                    stacklevel=2,
                )
        # Legacy callers may put ``driver_name`` only in the catch-all mapping (not observed from TOML, but safe).
        if "driver_name" in extra_opts:
            orphaned = extra_opts.pop("driver_name")
            if driver_name is None and orphaned is not None:
                driver_name = str(orphaned)

        resolved_odbc_driver = odbc_driver
        if driver_name is not None:
            legacy = str(driver_name).strip()
            connection_kind_only = legacy in (
                ConnectionType.TERADATA.value,
                str(ConnectionType.TERADATA),
            )
            if not connection_kind_only:
                if resolved_odbc_driver is None:
                    resolved_odbc_driver = driver_name
                    warnings.warn(
                        "Teradata connection config: `driver_name` for the ODBC driver is deprecated; " "use `odbc_driver` instead.",
                        DeprecationWarning,
                        stacklevel=2,
                    )
                elif str(resolved_odbc_driver).strip() != legacy:
                    warnings.warn(
                        "Teradata connection config specifies both `odbc_driver` and legacy `driver_name`; "
                        f"using `odbc_driver`={resolved_odbc_driver!r}.",
                        UserWarning,
                        stacklevel=2,
                    )

        tpt_config: TptConfig | None = None
        if use_tpt_for_bulk:
            default_tpt_output_directory, default_tpt_log_directory = _default_tpt_output_and_log_directories()
            tpt_config = TptConfig(
                output_directory=default_tpt_output_directory,
                delimiter=tpt_delimiter,
                max_sessions=tpt_max_sessions,
                log_directory=default_tpt_log_directory,
            )
            logger.info(
                "TPT local directories: output=%s, logs=%s, max_sessions=%d",
                default_tpt_output_directory,
                default_tpt_log_directory,
                tpt_max_sessions,
            )
        else:
            logger.info("Teradata bulk extraction will use ODBC (use_tpt_for_bulk=false); " "TPT work directories are not configured.")

        write_nos_config: WriteNosConfig | None = None
        if write_nos_location_scheme and write_nos_location_host:
            container_raw = write_nos_location_container
            container_str = (container_raw or "").strip()
            write_nos_config = WriteNosConfig(
                location_scheme=write_nos_location_scheme,
                location_host=write_nos_location_host,
                location_container=container_str,
                access_id=write_nos_access_id,
                access_key=write_nos_access_key,
                function_mapping=write_nos_function_mapping,
                authorization_name=write_nos_authorization_name,
            )
            logger.info(
                "WRITE_NOS configuration enabled: scheme=%s, host=%s, container=%s",
                write_nos_location_scheme,
                write_nos_location_host,
                container_str or "(none)",
            )

        return cls(
            driver_name=ConnectionType.TERADATA,
            username=username,
            password=password,
            database=database,
            host=host,
            port=port,
            odbc_driver=resolved_odbc_driver,
            auto_detect_driver=auto_detect_driver,
            authentication=authentication,
            dbc_name=dbc_name,
            write_nos_config=write_nos_config,
            tpt_config=tpt_config,
            extra_options=extra_opts,
        )

    def _select_odbc_driver(self, requested_driver: str | None, auto_detect: bool) -> str:
        """
        Select the appropriate ODBC driver for Teradata.

        When auto_detect is enabled, validates driver availability using
        pyodbc and falls back to the best available Teradata driver.

        Args:
            requested_driver: The driver requested by the user (can be None)
            auto_detect: Whether to validate driver availability

        Returns:
            str: The ODBC driver name to use

        """
        if not auto_detect:
            driver = requested_driver or DEFAULT_TERADATA_ODBC_DRIVER
            logger.debug("Using Teradata ODBC driver without validation: %s", driver)
            return driver

        from shared.odbc.driver_utils import get_all_odbc_drivers, is_driver_available

        if requested_driver:
            if is_driver_available(requested_driver):
                logger.info("Using requested Teradata ODBC driver: %s", requested_driver)
                return requested_driver
            logger.warning(
                "Requested Teradata ODBC driver '%s' not found. " "Attempting auto-detection.",
                requested_driver,
            )

        # Auto-detect: scan for any Teradata driver on the system
        all_drivers = get_all_odbc_drivers()
        best = _get_best_teradata_driver(all_drivers)
        if best:
            logger.info("Auto-detected Teradata ODBC driver: %s", best)
            return best

        other_hint = ""
        if all_drivers:
            sample = ", ".join(repr(d) for d in all_drivers[:8])
            suffix = " ..." if len(all_drivers) > 8 else ""
            other_hint = f" ODBC drivers currently registered on this host (non-exhaustive): {sample}{suffix}."
        missing_requested = ""
        if requested_driver:
            missing_requested = f" Configured driver {requested_driver!r} is not registered or not loadable."

        raise ValueError(
            "No Teradata ODBC driver could be resolved."
            f"{missing_requested}{other_hint}"
            " Install the Teradata ODBC driver (Teradata Tools and Utilities / ODBC driver package)"
            " for your OS, ensure it is registered with the ODBC driver manager (on Linux/macOS,"
            ' run `odbcinst -q -d` and confirm a name containing "Teradata"), then either keep'
            " `auto_detect_driver = true` (default) or set `odbc_driver` under [connections.source.teradata]"
            " to that exact driver name. If a driver is installed but not listed, check ODBCINI / ODBCSYSINI"
            " and unixODBC `odbcinst.ini` paths."
        )

    def _repr_fields(self) -> str:
        """Get string representation of fields (for use in __repr__)."""
        base_repr = super()._repr_fields()
        dbc = self.dbc_name if self.dbc_name is not None else self.host
        prefix = f"dbc_name={dbc!r}"
        if self.authentication:
            prefix = f"authentication={self.authentication!r}, {prefix}"
        return f"{prefix}, {base_repr}"
