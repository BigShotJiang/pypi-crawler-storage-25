"""Teradata Parallel Transporter (TPT) export configuration (not ODBC-specific)."""

import os
import tempfile

from dataclasses import dataclass


# ASCII File Separator (FS, U+001C). Default TPT export field delimiter (single-byte).
TPT_DEFAULT_FIELD_DELIMITER = "\x1c"

# TPT EXPORT character set (fixed; not exposed in connection config).
TPT_DEFAULT_CHARSET = "UTF8"


def _default_tpt_output_and_log_directories() -> tuple[str, str]:
    """
    Return DEA-managed TPT work directories under the process temp folder.

    Not user-configurable; avoids requiring writable host paths in customer TOML.
    """
    base = os.path.join(tempfile.gettempdir(), "data-exchange-agent", "tpt")
    output_directory = os.path.join(base, "output")
    log_directory = os.path.join(base, "logs")
    return output_directory, log_directory


@dataclass(kw_only=True)
class TptConfig:
    """
    Configuration for Teradata Parallel Transporter (TPT) export operations.

    Local output and log directories are chosen by the DEA (under the host temp
    directory); they are not customer-facing settings.

    """

    output_directory: str
    """Local directory where TPT writes exported files (managed by DEA)."""

    delimiter: str = TPT_DEFAULT_FIELD_DELIMITER
    """Field delimiter for exported delimited text (default: ASCII File Separator U+001C; single-byte for Parquet conversion)."""

    max_sessions: int = 4
    """Maximum parallel TPT sessions."""

    charset: str = TPT_DEFAULT_CHARSET
    """Character set for the TPT EXPORT operator (fixed; see ``TPT_DEFAULT_CHARSET``)."""

    log_directory: str | None = None
    """Directory for TPT job logs; defaults to ``output_directory`` when omitted."""

    def __post_init__(self) -> None:
        """Expand ``~`` and normalize paths (TOML strings do not shell-expand)."""
        self.output_directory = os.path.normpath(os.path.expanduser(self.output_directory))
        if self.log_directory is not None:
            self.log_directory = os.path.normpath(os.path.expanduser(self.log_directory))

    @property
    def effective_log_directory(self) -> str:
        """Return the log directory, falling back to ``output_directory``."""
        return self.log_directory or self.output_directory
