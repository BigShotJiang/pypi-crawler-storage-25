"""Azure Synapse Analytics ODBC connection configuration."""

import logging

from typing import Literal

from pydantic import Field, model_validator

from data_exchange_agent.config.sections.connections.transports.odbc.base import (
    BaseODBCConnectionConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType


logger = logging.getLogger(__name__)

DEFAULT_AZURE_SYNAPSE_PORT = 1433
DEFAULT_AZURE_SYNAPSE_ODBC_DRIVER = "ODBC Driver 18 for SQL Server"

AzureSynapseAuthMode = Literal["sql_auth", "azure_ad"]

_SQL_AUTH_TEMPLATE = (
    "DRIVER={{{driver}}};"
    "SERVER={host},{port};"
    "DATABASE={database};"
    "UID={uid};"
    "PWD={pwd};"
    "Encrypt=yes;"
    "TrustServerCertificate=no"
)

_AZURE_AD_TEMPLATE = (
    "DRIVER={{{driver}}};"
    "SERVER={host},{port};"
    "DATABASE={database};"
    "Authentication=ActiveDirectoryServicePrincipal;"
    "UID={uid};"
    "PWD={pwd};"
    "Encrypt=yes;"
    "TrustServerCertificate=no"
)


class AzureSynapseConnectionConfig(BaseODBCConnectionConfig):
    """
    Configuration for Azure Synapse Analytics ODBC connections.

    Supports two authentication modes:

    - ``sql_auth`` (default) — SQL authentication with username/password.
    - ``azure_ad`` — Azure AD service principal with client_id/client_secret.

    References:
        https://learn.microsoft.com/en-us/azure/synapse-analytics/sql/connect-overview

    """

    driver_name: str = Field(
        default=ConnectionType.AZURE_SYNAPSE, description="Driver name"
    )
    host: str = Field(
        default="localhost",
        description="Synapse workspace SQL endpoint",
    )
    port: int = Field(
        default=DEFAULT_AZURE_SYNAPSE_PORT,
        ge=1,
        le=65535,
        description="Database port number",
    )
    database: str = Field(..., description="Dedicated SQL pool name")
    username: str | None = Field(
        default=None,
        description="SQL auth username (required for sql_auth mode)",
    )
    password: str | None = Field(
        default=None,
        description="SQL auth password (required for sql_auth mode)",
    )

    mode: AzureSynapseAuthMode = Field(
        default="sql_auth",
        description=(
            "Authentication mode: 'sql_auth' (username/password) "
            "or 'azure_ad' (service principal)."
        ),
    )
    client_id: str | None = Field(
        default=None,
        description="Azure AD application (client) ID for azure_ad mode",
    )
    client_secret: str | None = Field(
        default=None,
        description="Azure AD client secret for azure_ad mode",
    )
    odbc_driver: str | None = Field(
        default=None,
        description=(
            f"ODBC driver name override. "
            f"Defaults to '{DEFAULT_AZURE_SYNAPSE_ODBC_DRIVER}'."
        ),
    )

    @model_validator(mode="after")
    def validate_azure_synapse_config(self) -> "AzureSynapseConnectionConfig":
        """Validate authentication fields based on the chosen mode."""
        if self.mode == "sql_auth":
            if not self.username or not self.username.strip():
                raise ValueError(
                    "username is required for sql_auth mode. "
                    "Set mode='azure_ad' to use service principal authentication."
                )
            if not self.password:
                raise ValueError(
                    "password is required for sql_auth mode. "
                    "Set mode='azure_ad' to use service principal authentication."
                )
        elif self.mode == "azure_ad":
            if not self.client_id or not self.client_id.strip():
                raise ValueError("client_id is required for azure_ad mode.")
            if not self.client_secret:
                raise ValueError("client_secret is required for azure_ad mode.")
        return self

    def build_connection_string(self) -> str:
        """Build the ODBC connection string for Azure Synapse."""
        driver = self.odbc_driver or DEFAULT_AZURE_SYNAPSE_ODBC_DRIVER

        if self.mode == "azure_ad":
            connection_string = _AZURE_AD_TEMPLATE.format(
                driver=driver,
                host=self.host,
                port=self.port,
                database=self.database,
                uid=self.client_id or "",
                pwd=self.client_secret or "",
            )
        else:
            connection_string = _SQL_AUTH_TEMPLATE.format(
                driver=driver,
                host=self.host,
                port=self.port,
                database=self.database,
                uid=self.username or "",
                pwd=self.password or "",
            )

        for key, value in self.extra_options.items():
            connection_string += f";{str(key).strip()}={str(value).strip()}"

        return connection_string

    def _repr_fields(self) -> str:
        """Get string representation of fields (for use in __repr__)."""
        base_repr = super()._repr_fields()
        return f"mode={self.mode}, {base_repr}"
