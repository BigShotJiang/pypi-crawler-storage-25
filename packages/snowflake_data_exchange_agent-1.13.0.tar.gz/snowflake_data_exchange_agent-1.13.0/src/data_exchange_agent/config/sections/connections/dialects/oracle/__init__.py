"""Oracle ODBC-backed connection configuration."""
