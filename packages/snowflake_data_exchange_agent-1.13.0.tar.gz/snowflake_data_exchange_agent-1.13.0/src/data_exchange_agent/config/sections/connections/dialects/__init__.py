"""Per-dialect connection configuration (ODBC-backed engines)."""

# Import for side effects: registers ConnectionRegistry entries.
from . import register as _register_odbc_dialects
