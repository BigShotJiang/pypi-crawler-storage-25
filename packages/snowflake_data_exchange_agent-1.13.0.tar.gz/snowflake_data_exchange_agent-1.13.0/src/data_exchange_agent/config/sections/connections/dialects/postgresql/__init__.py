"""PostgreSQL ODBC-backed connection configuration."""
