"""Connection transports (e.g. ODBC) shared across dialects."""
