"""Teradata connection and native export configuration."""

from data_exchange_agent.config.sections.connections.dialects.teradata.config import (
    DEFAULT_TERADATA_ODBC_DRIVER,
    DEFAULT_TERADATA_PORT,
    TERADATA_ODBC_DRIVER_NAME_SUBSTRING,
    TeradataConnectionConfig,
)
from data_exchange_agent.config.sections.connections.dialects.teradata.tpt import (
    TPT_DEFAULT_CHARSET,
    TPT_DEFAULT_FIELD_DELIMITER,
    TptConfig,
)
from data_exchange_agent.config.sections.connections.dialects.teradata.write_nos import (
    WRITE_NOS_COMPRESSION,
    WRITE_NOS_MAX_OBJECT_SIZE,
    WRITE_NOS_OVERWRITE,
    WRITE_NOS_STORED_AS,
    WriteNosConfig,
)


__all__ = [
    "DEFAULT_TERADATA_ODBC_DRIVER",
    "DEFAULT_TERADATA_PORT",
    "TERADATA_ODBC_DRIVER_NAME_SUBSTRING",
    "TPT_DEFAULT_CHARSET",
    "TPT_DEFAULT_FIELD_DELIMITER",
    "WRITE_NOS_COMPRESSION",
    "WRITE_NOS_MAX_OBJECT_SIZE",
    "WRITE_NOS_OVERWRITE",
    "WRITE_NOS_STORED_AS",
    "TeradataConnectionConfig",
    "TptConfig",
    "WriteNosConfig",
]
