"""Shared ODBC transport configuration (connection string base types)."""

from data_exchange_agent.config.sections.connections.transports.odbc.base import (
    BaseODBCConnectionConfig,
)


__all__ = ["BaseODBCConnectionConfig"]
