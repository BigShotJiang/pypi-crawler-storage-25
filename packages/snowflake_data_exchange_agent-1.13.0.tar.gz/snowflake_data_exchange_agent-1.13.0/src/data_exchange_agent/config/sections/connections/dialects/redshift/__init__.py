"""Amazon Redshift ODBC-backed connection configuration."""
