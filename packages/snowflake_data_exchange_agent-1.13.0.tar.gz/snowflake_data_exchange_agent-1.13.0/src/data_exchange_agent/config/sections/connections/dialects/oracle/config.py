"""Oracle ODBC connection configuration."""

import logging

from enum import StrEnum
from typing import Self

from pydantic import Field, PrivateAttr, model_validator

from data_exchange_agent.config.sections.connections.transports.odbc.base import (
    BaseODBCConnectionConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType


logger = logging.getLogger(__name__)

DEFAULT_ORACLE_PORT = 1521
DEFAULT_ORACLE_ODBC_DRIVER = "Oracle in instantclient_21_1"


class OracleConnectionMode(StrEnum):
    """How the ODBC layer resolves the Oracle net service (DBQ)."""

    BASIC = "basic"
    TNS_ALIAS = "tns_alias"
    CONNECT_DESCRIPTOR = "connect_descriptor"


class OracleConnectionConfig(BaseODBCConnectionConfig):
    """
    Configuration for Oracle Database connections.

    Connections use ``oracledb`` by default (set ``oracledb_preferred = false`` to
    force ``pyodbc``).  The ODBC connection string / driver fields are used only on
    the ``pyodbc`` path.

    Three modes:

    - ``basic`` — EZ Connect ``//host:port/service`` (``database`` is the service name).
    - ``tns_alias`` — ``DBQ`` is a name resolved via ``tnsnames.ora`` (optionally set
      ``tns_admin`` so ``TNS_ADMIN`` is applied when opening the connection).
    - ``connect_descriptor`` — ``DBQ`` is a full connect descriptor string (often
      starting with ``(DESCRIPTION=...)``).

    Wallet-based TLS and LDAP-related attributes vary by driver build; use
    ``wallet_directory`` / ``wallet_password`` for common Oracle ODBC attributes,
    or pass driver-specific keys through ``extra_options``.
    """

    driver_name: str = Field(
        default=ConnectionType.ORACLE.value,
        description="Logical connection type identifier",
    )
    database: str = Field(
        default="",
        description="SERVICE_NAME for basic EZ Connect; may be empty for tns_alias/connect_descriptor",
    )
    host: str = Field(default="localhost", description="Host for basic EZ Connect mode")
    port: int = Field(
        default=DEFAULT_ORACLE_PORT,
        ge=1,
        le=65535,
        description="Listener port (basic mode)",
    )
    username: str = Field(default="", description="Oracle username")
    password: str = Field(default="", description="Oracle password")

    oracle_connection_mode: OracleConnectionMode = Field(
        default=OracleConnectionMode.BASIC,
        description="How DBQ is built (basic EZ Connect, TNS alias, or full descriptor)",
    )
    requested_odbc_driver: str | None = Field(
        default=None,
        alias="odbc_driver",
        description="Exact ODBC driver name from pyodbc.drivers(); defaults if omitted",
    )
    auto_detect_driver: bool = Field(
        default=True,
        description="When false, use requested_odbc_driver without substituting default",
    )

    tns_name: str | None = Field(
        default=None,
        description="TNS alias for tns_alias mode (DBQ value)",
    )
    connect_descriptor: str | None = Field(
        default=None,
        description="Full connect descriptor for connect_descriptor mode",
    )
    tns_admin: str | None = Field(
        default=None,
        description=(
            "Directory containing tnsnames.ora; when set, TNS_ADMIN is set for the "
            "duration of pyodbc.connect (tns_alias or LDAP naming)."
        ),
    )
    wallet_directory: str | None = Field(
        default=None,
        description="Optional wallet directory (MY_WALLET_DIRECTORY in connection string)",
    )
    wallet_password: str | None = Field(
        default=None,
        description="Optional wallet password when required by the ODBC driver",
    )
    oracledb_preferred: bool = Field(
        default=True,
        description=(
            "Try oracledb before falling back to pyodbc. "
            "Set to false to force the pyodbc path."
        ),
    )

    _resolved_odbc_driver: str = PrivateAttr()

    def model_post_init(self, __context: object) -> None:
        """Resolve ODBC driver label after field validation."""
        self._resolved_odbc_driver = self._select_odbc_driver(
            self.requested_odbc_driver,
            self.auto_detect_driver,
        )

    @model_validator(mode="after")
    def validate_odbc_config(self) -> Self:
        """Validate Oracle-specific rules; host checks apply only to basic mode."""
        mode = self.oracle_connection_mode
        if mode == OracleConnectionMode.BASIC:
            err = self._validate_required_field(self.database, "database")
            if err:
                raise ValueError(err)
            self._validate_host()
        elif mode == OracleConnectionMode.TNS_ALIAS:
            err = self._validate_required_field(self.tns_name, "tns_name")
            if err:
                raise ValueError(err)
        elif mode == OracleConnectionMode.CONNECT_DESCRIPTOR:
            err = self._validate_required_field(
                self.connect_descriptor, "connect_descriptor"
            )
            if err:
                raise ValueError(err)
        else:
            raise ValueError(f"Unsupported oracle_connection_mode: {mode!r}")
        self._validate_extra_options()
        return self

    def _build_dbq(self) -> str:
        if self.oracle_connection_mode == OracleConnectionMode.BASIC:
            return f"//{self.host}:{self.port}/{self.database}"
        if self.oracle_connection_mode == OracleConnectionMode.TNS_ALIAS:
            name = self.tns_name
            if name is None:
                raise RuntimeError("tns_name is unset")
            return name.strip()
        desc = self.connect_descriptor
        if desc is None:
            raise RuntimeError("connect_descriptor is unset")
        return desc.strip()

    def build_connection_string(self) -> str:
        """Build the ODBC connection string for Oracle."""
        dbq = self._build_dbq()
        parts = [
            f"DRIVER={{{self._resolved_odbc_driver}}}",
            f"DBQ={dbq}",
            f"UID={self.username}",
            f"PWD={self.password}",
        ]
        connection_string = ";".join(parts)

        if self.wallet_directory and str(self.wallet_directory).strip():
            connection_string += f";MY_WALLET_DIRECTORY={self.wallet_directory.strip()}"
        if self.wallet_password is not None and str(self.wallet_password).strip():
            connection_string += f";MY_WALLET_PASSWORD={self.wallet_password.strip()}"

        for key, value in self.extra_options.items():
            stripped_key = str(key).strip()
            stripped_value = str(value).strip()
            connection_string += f";{stripped_key}={stripped_value}"

        return connection_string

    @classmethod
    def from_config_dict(
        cls,
        database: str = "",
        username: str = "",
        password: str = "",
        host: str = "localhost",
        port: int = DEFAULT_ORACLE_PORT,
        odbc_driver: str | None = None,
        auto_detect_driver: bool = True,
        oracle_connection_mode: str = OracleConnectionMode.BASIC.value,
        tns_name: str | None = None,
        connect_descriptor: str | None = None,
        tns_admin: str | None = None,
        wallet_directory: str | None = None,
        wallet_password: str | None = None,
        oracledb_preferred: bool = True,
        **extra_options: str | int | float | bool,
    ) -> "OracleConnectionConfig":
        """
        Build config from flat TOML-style keys (used by ConnectionRegistry.create).

        Unknown keys are collected into ``extra_options``.
        """
        try:
            mode = OracleConnectionMode(str(oracle_connection_mode).lower())
        except ValueError as e:
            allowed = ", ".join(repr(m.value) for m in OracleConnectionMode)
            raise ValueError(f"oracle_connection_mode must be one of {allowed}; got {oracle_connection_mode!r}") from e
        return cls(
            driver_name=ConnectionType.ORACLE.value,
            username=username,
            password=password,
            database=database,
            host=host,
            port=port,
            odbc_driver=odbc_driver,
            auto_detect_driver=auto_detect_driver,
            oracle_connection_mode=mode,
            tns_name=tns_name,
            connect_descriptor=connect_descriptor,
            tns_admin=tns_admin,
            wallet_directory=wallet_directory,
            wallet_password=wallet_password,
            oracledb_preferred=oracledb_preferred,
            extra_options=dict(extra_options),
        )

    def _select_odbc_driver(
        self, requested_driver: str | None, auto_detect: bool
    ) -> str:
        if requested_driver is not None:
            if not auto_detect:
                logger.debug(
                    "Using explicitly specified Oracle ODBC driver without substitution: %s",
                    requested_driver,
                )
                return requested_driver
            logger.info("Using requested Oracle ODBC driver: %s", requested_driver)
            return requested_driver

        logger.info(
            "No Oracle ODBC driver specified; using default label %s " "(override with odbc_driver to match pyodbc.drivers())",
            DEFAULT_ORACLE_ODBC_DRIVER,
        )
        return DEFAULT_ORACLE_ODBC_DRIVER

    def _repr_fields(self) -> str:
        base = super()._repr_fields()
        return (
            f"oracle_connection_mode={self.oracle_connection_mode}, "
            f"tns_admin={'***' if self.tns_admin else None}, "
            f"wallet_directory={self.wallet_directory!r}, "
            f"{base}"
        )
