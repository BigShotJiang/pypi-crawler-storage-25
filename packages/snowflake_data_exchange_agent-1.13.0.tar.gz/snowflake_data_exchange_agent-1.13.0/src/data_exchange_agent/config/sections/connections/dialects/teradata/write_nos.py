"""Teradata WRITE_NOS export configuration (not ODBC-specific)."""

import json

from dataclasses import dataclass


# WRITE_NOS output options (fixed; not exposed in connection config).
WRITE_NOS_STORED_AS = "PARQUET"
WRITE_NOS_COMPRESSION = "SNAPPY"
WRITE_NOS_MAX_OBJECT_SIZE = "16MB"
# On several Vantage releases, OVERWRITE('TRUE') requires MANIFESTONLY('TRUE'),
# which in turn expects a two-column ON clause (object name + size) — not the
# row-export shape from the orchestrator. Use FALSE for normal SELECT ... exports;
# use a fresh target_id prefix or clear the object path before re-runs.
WRITE_NOS_OVERWRITE = "FALSE"


@dataclass(kw_only=True)
class WriteNosConfig:
    """
    Configuration for Teradata WRITE_NOS export operations.

    WRITE_NOS is a Teradata table function that exports data directly from
    Teradata to cloud object storage (S3, Azure Blob, GCS) as Parquet files.
    The DEA wraps the orchestrator-provided SELECT query with WRITE_NOS syntax
    using these settings.

    Three credential modes are supported (in order of precedence):

    1. Function mapping (``function_mapping``) — credentials are hidden inside a
       Teradata function mapping defined ahead of time.
    2. Named AUTHORIZATION object (``authorization_name``) — credentials are
       held in a Teradata AUTHORIZATION object created ahead of time.
    3. Inline credentials (``access_id`` + ``access_key``) — credentials are
       embedded in the SQL via ``AUTHORIZATION('{...}')``. Use only when the
       previous two are not available; secrets are redacted in logs.

    Output format, compression, max object size, and overwrite are fixed (see module
    constants ``WRITE_NOS_*``); they are not configurable via DEA TOML.

    """

    location_scheme: str
    """Cloud storage URI scheme: ``/s3/`` for AWS S3, ``/az/`` for Azure Blob,
    ``/gs/`` for GCS."""

    location_host: str
    """
    Cloud storage host (without scheme or container).

    e.g. ``myaccount.blob.core.windows.net`` (Azure),
         ``mybucket.s3.amazonaws.com`` (S3).
    """

    location_container: str = ""
    """
    Path segment after ``host`` before the orchestrator relative path (e.g. bucket
    name for Azure/GCS, or an S3 key prefix inside the bucket). Leave empty when the
    Snowflake external stage URL is the bucket root and Teradata should write
    ``task_results/...`` directly under that root.
    """

    access_id: str | None = None
    """Cloud storage access ID (storage account name for Azure, Access Key ID
    for S3). Used only with inline credentials."""

    access_key: str | None = None
    """Cloud storage access key / secret. Used only with inline credentials."""

    function_mapping: str | None = None
    """
    Fully-qualified Teradata function mapping name (e.g.
    ``nos_util.WRITE_NOS_FM``). When set, the function mapping is used instead
    of direct ``WRITE_NOS`` with inline credentials. The mapping must be
    pre-created on Teradata.
    """

    authorization_name: str | None = None
    """
    Named Teradata AUTHORIZATION object (e.g. ``nos_util.DefAuth_Write``).
    When set, ``WRITE_NOS`` uses ``AUTHORIZATION(authorization_name)`` instead
    of inline credentials. The authorization must be pre-created on Teradata.
    """

    def build_location(self, relative_path: str) -> str:
        """
        Build the full cloud storage location URI for WRITE_NOS.

        Args:
            relative_path: Path appended after the optional ``location_container``
                segment (e.g. ``task_results/workflows/1/...``).

        Returns:
            Full WRITE_NOS ``LOCATION`` string
            (e.g. ``/az/host/container/path/``).

        """
        scheme = self.location_scheme.strip("/")
        host = self.location_host.strip("/")
        container = (
            self.location_container.strip("/") if self.location_container else ""
        )
        rel = relative_path.strip("/")
        parts: list[str] = [f"/{scheme}", host]
        if container:
            parts.append(container)
        if rel:
            parts.append(rel)
        return "/".join(parts) + "/"

    def build_write_nos_query(self, select_query: str, location: str) -> str:
        """
        Build a complete WRITE_NOS SELECT statement.

        Renders one of three credential modes — function mapping, named
        AUTHORIZATION, or inline access_id/access_key — based on which fields
        are populated. Function mapping wins over named AUTHORIZATION which
        wins over inline credentials.

        Args:
            select_query: The inner SELECT query to export.
            location: Full cloud storage URI from :meth:`build_location`.

        Returns:
            Complete WRITE_NOS SQL statement.

        """
        function_name = self.function_mapping or "WRITE_NOS"

        using_clauses = [
            f"LOCATION('{location}')",
            f"STOREDAS('{WRITE_NOS_STORED_AS}')",
            f"COMPRESSION('{WRITE_NOS_COMPRESSION}')",
            f"MAXOBJECTSIZE('{WRITE_NOS_MAX_OBJECT_SIZE}')",
            f"OVERWRITE('{WRITE_NOS_OVERWRITE}')",
        ]

        if not self.function_mapping:
            if self.authorization_name:
                using_clauses.insert(1, f"AUTHORIZATION('{self.authorization_name}')")
            elif self.access_id and self.access_key:
                auth_payload = {
                    "Access_ID": self.access_id,
                    "Access_Key": self.access_key,
                }
                auth_json = json.dumps(auth_payload, separators=(",", ":"))
                auth_sql_literal = auth_json.replace("'", "''")
                using_clauses.insert(1, f"AUTHORIZATION('{auth_sql_literal}')")

        using_block = "\n    ".join(using_clauses)

        return (
            f"SELECT * FROM {function_name} (\n"
            f"    ON ( {select_query} )\n"
            f"    USING\n"
            f"    {using_block}\n"
            f") AS d"
        )
