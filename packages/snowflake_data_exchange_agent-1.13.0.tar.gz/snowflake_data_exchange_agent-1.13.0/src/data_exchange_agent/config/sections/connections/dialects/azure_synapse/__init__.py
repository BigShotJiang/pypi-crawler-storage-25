"""Azure Synapse Analytics dialect connection configuration."""
