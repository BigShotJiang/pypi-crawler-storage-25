"""Register ODBC-backed dialect connection config classes."""

from data_exchange_agent.config.sections.connections.connection_registry import (
    ConnectionRegistry,
)
from data_exchange_agent.config.sections.connections.dialects.azure_synapse.config import (
    AzureSynapseConnectionConfig,
)
from data_exchange_agent.config.sections.connections.dialects.oracle.config import (
    OracleConnectionConfig,
)
from data_exchange_agent.config.sections.connections.dialects.postgresql.config import (
    PostgresqlConnectionConfig,
)
from data_exchange_agent.config.sections.connections.dialects.redshift.config import (
    RedshiftConnectionConfig,
)
from data_exchange_agent.config.sections.connections.dialects.sqlserver.config import (
    SQLServerConnectionConfig,
)
from data_exchange_agent.config.sections.connections.dialects.teradata.config import (
    TeradataConnectionConfig,
)
from data_exchange_agent.constants.connection_types import ConnectionType


ConnectionRegistry.register(ConnectionType.SQLSERVER, SQLServerConnectionConfig)
ConnectionRegistry.register(ConnectionType.REDSHIFT, RedshiftConnectionConfig)
ConnectionRegistry.register(ConnectionType.POSTGRESQL, PostgresqlConnectionConfig)
ConnectionRegistry.register(ConnectionType.TERADATA, TeradataConnectionConfig)
ConnectionRegistry.register(ConnectionType.ORACLE, OracleConnectionConfig)
ConnectionRegistry.register(ConnectionType.AZURE_SYNAPSE, AzureSynapseConnectionConfig)
