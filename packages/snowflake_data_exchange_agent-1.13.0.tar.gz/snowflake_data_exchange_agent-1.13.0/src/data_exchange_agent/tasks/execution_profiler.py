"""Lightweight step-level profiler for task execution profile."""

from __future__ import annotations

import json
import time

from collections.abc import Iterator
from contextlib import contextmanager


class Stopwatch:
    """
    Stopwatch that exposes elapsed time in integer milliseconds.

    Centralizes the ``time.monotonic()`` + ``int((... ) * 1000)`` conversion so
    callers never need to write that arithmetic inline. The clock starts at
    construction; ``elapsed_ms`` is frozen on :meth:`stop` (or implicitly when
    used as a ``with`` block exits), so the same instance works both
    imperatively and as a scoped context manager.

    Usage::

        # Imperative (spanning early returns / try/finally):
        sw = Stopwatch()
        do_work()
        logger.info(f"elapsed_ms={sw.stop()}")

        # Scoped:
        with Stopwatch() as sw:
            do_work()
        logger.info(f"elapsed_ms={sw.elapsed_ms}")
    """

    __slots__ = ("_t0", "elapsed_ms")

    def __init__(self) -> None:
        """Start the clock at construction; ``elapsed_ms`` is 0 until stopped."""
        self._t0: float = time.monotonic()
        self.elapsed_ms: int = 0

    def __enter__(self) -> Stopwatch:
        """Return self for ``as`` binding (clock already started in ``__init__``)."""
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        """Freeze ``elapsed_ms`` to the time since construction."""
        self.stop()

    def stop(self) -> int:
        """Snapshot the time since construction into ``elapsed_ms`` and return it."""
        self.elapsed_ms = int((time.monotonic() - self._t0) * 1000)
        return self.elapsed_ms


class ExecutionProfiler:
    """
    Records named step durations for task execution profile.

    Step names should come from
    :mod:`data_exchange_agent.constants.profiler_steps` — that module is the
    single source of truth for the kebab-case identifiers emitted into the
    JSON profile.

    Usage for sequential steps::

        from data_exchange_agent.constants import profiler_steps

        profiler = ExecutionProfiler()
        profiler.step(profiler_steps.EXPORT_DATA)
        export_data()
        profiler.step(profiler_steps.UPLOAD_DATA)
        upload_data()
        profiler.finish()
        print(profiler.to_json())
        # [["export-data", 1004], ["upload-data", 2153]]

    Usage for scoped one-shot steps (recorded once on exit)::

        with profiler.measure(profiler_steps.WRITE_RESULTS):
            write_results()

    Usage for steps that run many times in a loop (summed into one entry)::

        for batch in batches:
            with profiler.accumulate(profiler_steps.COMPARE_ROWS):
                compare(batch)
        # On finish(), a single ("compare-rows", total_ms) entry is emitted.
    """

    def __init__(self) -> None:
        """Initialize an empty profiler with no recorded steps."""
        self._steps: list[tuple[str, int]] = []
        self._current_step: str | None = None
        self._step_start: float | None = None
        self._accumulators: dict[str, int] = {}

    def step(self, name: str) -> ExecutionProfiler:
        """End the previous step (if any) and start a new one."""
        self._end_current()
        self._current_step = name
        self._step_start = time.monotonic()
        return self

    def _end_current(self) -> None:
        if self._current_step is not None and self._step_start is not None:
            elapsed_ms = int((time.monotonic() - self._step_start) * 1000)
            self._steps.append((self._current_step, elapsed_ms))
            self._current_step = None
            self._step_start = None

    def record(self, name: str, duration_ms: int) -> None:
        """Directly record a step with a known duration (for parallel steps)."""
        self._steps.append((name, duration_ms))

    @contextmanager
    def measure(self, name: str) -> Iterator[Stopwatch]:
        """
        Time a code block and ``record`` it as a single profiler entry on exit.

        Use for one-shot scoped measurements that should appear exactly once in
        the profile (e.g. writing a result file, executing a single query).
        """
        sw = Stopwatch()
        with sw:
            yield sw
        self.record(name, sw.elapsed_ms)

    @contextmanager
    def accumulate(self, name: str) -> Iterator[Stopwatch]:
        """
        Time a code block and add its duration to a running total for *name*.

        The accumulated total is flushed as a single ``(name, total_ms)`` entry
        on the next call to :meth:`finish` (and therefore :meth:`to_json`). Use
        for steps that execute many times inside a loop (per-batch fetches,
        per-batch comparisons) when the consumer only cares about the aggregate.
        """
        sw = Stopwatch()
        with sw:
            yield sw
        self._accumulators[name] = self._accumulators.get(name, 0) + sw.elapsed_ms

    def _flush_accumulators(self) -> None:
        if not self._accumulators:
            return
        for name, total_ms in self._accumulators.items():
            self._steps.append((name, total_ms))
        self._accumulators.clear()

    def finish(self) -> None:
        """End the last open step (if any) and flush accumulated totals."""
        self._end_current()
        self._flush_accumulators()

    def to_json(self) -> str:
        """Serialize as JSON: ``[["Step Name", duration_ms], ...]``."""
        self.finish()
        return json.dumps(self._steps)
