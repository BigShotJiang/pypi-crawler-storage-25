import tempfile

from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Any

from data_exchange_agent.constants import profiler_steps, task_keys
from data_exchange_agent.data_sources.teradata_connection import DBAPICursor
from data_exchange_agent.tasks.data_validation.handler import DataValidationHandler
from data_exchange_agent.tasks.data_validation.helpers import (
    PAYLOAD_COLUMNS_METADATA,
    PAYLOAD_CUSTOM_NORMALIZATIONS_SOURCE,
    PAYLOAD_CUSTOM_NORMALIZATIONS_TARGET,
    PAYLOAD_INDEX_COLUMN_LIST,
    PAYLOAD_MAX_FAILED_ROWS_NUMBER,
    PAYLOAD_OBJECT_TYPE,
    PAYLOAD_PARTITION_NUMBER,
    PAYLOAD_RESULT_PIPES,
    PAYLOAD_SOURCE_PLATFORM,
    PAYLOAD_SOURCE_TABLE_FQN,
    PAYLOAD_SOURCE_WHERE_CLAUSE,
    PAYLOAD_TABLE_METADATA_ID,
    PAYLOAD_TABLE_NAME,
    PAYLOAD_TARGET_ID,
    PAYLOAD_TARGET_INDEX_COLUMN_LIST,
    PAYLOAD_TARGET_TABLE_FQN,
    PAYLOAD_TARGET_WHERE_CLAUSE,
    PAYLOAD_WORKFLOW_ID,
    RowHashPipelineParams,
    TaskResult,
    build_row_table_context,
    get_custom_override,
    resolve_object_type,
    resolve_platform,
)
from data_exchange_agent.tasks.execution_profiler import ExecutionProfiler, Stopwatch
from snowflake.connector.cursor import SnowflakeCursor
from snowflake.snowflake_data_validation.public import (
    ColumnMetadata,
    ObjectType,
    Origin,
    Platform,
    TableContext,
    generate_row_md5_select_query,
)
from snowflake.snowflake_data_validation.public.model.generated_query import (
    GeneratedQuery,
)
from snowflake.snowflake_data_validation.utils.column_grouping import (
    compute_unified_column_groups,
)
from snowflake.snowflake_data_validation.utils.constants import (
    MAX_CONCAT_LENGTH,
    Result,
)
from snowflake.snowflake_data_validation.validation.row_data_validator import (
    RowDiff,
    compare_md5_rows,
    normalize_index_key,
)


# Max rows to fetch from a cursor at once
_ROW_HASH_FETCH_BATCH_SIZE = 50_000

# Max rows to read from each cursor per outer window (before strip/align).
_ROW_HASH_MERGE_WINDOW_ROWS = 50_000

RECORD_WITH_KEY_AND_HASH = tuple[tuple, str]


def _fetch_row_hash_chunk_if_active(
    cursor: DBAPICursor | SnowflakeCursor,
    has_reached_cursor_end: bool,
    profiler: ExecutionProfiler,
    fetch_step: str,
) -> list[RECORD_WITH_KEY_AND_HASH]:
    """Read up to ``_ROW_HASH_MERGE_WINDOW_ROWS`` rows from *cursor* (already executed) unless the cursor is already drained."""
    if has_reached_cursor_end:
        return []
    out: list[RECORD_WITH_KEY_AND_HASH] = []
    while len(out) < _ROW_HASH_MERGE_WINDOW_ROWS:
        batch_size = min(
            _ROW_HASH_FETCH_BATCH_SIZE, _ROW_HASH_MERGE_WINDOW_ROWS - len(out)
        )
        if batch_size <= 0:
            break

        with profiler.accumulate(fetch_step):
            raw = cursor.fetchmany(batch_size)

        if not raw:
            break

        for row in raw:
            # In case of simple key, just get first element. In case of composite key, get everything except the last element (hash)
            raw_key = tuple(row[:-1]) if len(row) > 2 else (row[0],)
            record: RECORD_WITH_KEY_AND_HASH = (
                normalize_index_key(raw_key),
                str(row[-1]),
            )
            out.append(record)
            if len(out) >= _ROW_HASH_MERGE_WINDOW_ROWS:
                break
    return out


def _strip_trailing_same_key(
    rows: list[RECORD_WITH_KEY_AND_HASH],
    *,
    has_reached_cursor_end: bool,
) -> tuple[list[RECORD_WITH_KEY_AND_HASH], list[RECORD_WITH_KEY_AND_HASH]]:
    """
    Split *rows* into ``(work, tail)``.

    *tail* is the maximal suffix whose keys all equal the last row's key in
    *rows*. When *has_reached_cursor_end* is True (no more rows will arrive
    from the cursor), the trailing run is complete, so *tail* is empty and
    *work* is all of *rows*.
    """
    if not rows:
        return [], []
    if has_reached_cursor_end:
        return rows, []
    last_key = rows[-1][0]
    idx = len(rows) - 1
    while idx >= 0 and rows[idx][0] == last_key:
        idx -= 1
    return rows[: idx + 1], rows[idx + 1 :]


def _take_prefix_strictly_before_key(
    rows: list[RECORD_WITH_KEY_AND_HASH],
    bound_key: tuple,
) -> tuple[list[RECORD_WITH_KEY_AND_HASH], list[RECORD_WITH_KEY_AND_HASH]]:
    """Return ``(prefix, rest)`` where *prefix* has keys ``< bound_key`` and *rest* is the remainder."""
    if not rows:
        return [], []
    i = 0
    while i < len(rows) and rows[i][0] < bound_key:
        i += 1
    return rows[:i], rows[i:]


def _align_row_hash_buffers(
    source_work: list[RECORD_WITH_KEY_AND_HASH],
    target_work: list[RECORD_WITH_KEY_AND_HASH],
    *,
    source_cursor_exhausted: bool,
    target_cursor_exhausted: bool,
) -> tuple[
    list[RECORD_WITH_KEY_AND_HASH],
    list[RECORD_WITH_KEY_AND_HASH],
    list[RECORD_WITH_KEY_AND_HASH],
    list[RECORD_WITH_KEY_AND_HASH],
]:
    """
    Build merge-safe cores and roll-back rows for one ``compare_md5_rows`` call.

    Returns ``(source_core, target_core, source_align_roll, target_align_roll)``
    where the *_roll* lists contain rows whose keys lie strictly above the
    shared cut key and must be carried into the next iteration. The caller
    appends the strip *tail* after the roll when building next carryover.
    """
    if not source_work and not target_work:
        return [], [], [], []

    if not source_work and source_cursor_exhausted:
        return [], target_work, [], []

    if not target_work and target_cursor_exhausted:
        return source_work, [], [], []

    if not source_work or not target_work:
        return [], [], source_work, target_work

    k_cut = min(source_work[-1][0], target_work[-1][0])
    source_core, source_roll = _split_rows_at_key_exclusive(source_work, k_cut)
    target_core, target_roll = _split_rows_at_key_exclusive(target_work, k_cut)
    return source_core, target_core, source_roll, target_roll


def _split_rows_at_key_exclusive(
    rows: list[RECORD_WITH_KEY_AND_HASH],
    k: tuple,
) -> tuple[list[RECORD_WITH_KEY_AND_HASH], list[RECORD_WITH_KEY_AND_HASH]]:
    """Return ``(core, roll)`` where *core* has keys ``<= k`` and *roll* has keys ``> k``."""
    if not rows:
        return [], []
    i = len(rows)
    while i > 0 and rows[i - 1][0] > k:
        i -= 1
    return rows[:i], rows[i:]


@dataclass(frozen=True)
class ComparisonResult:
    """Outcome of comparing source and target row-hash streams."""

    differences: list[RowDiff]
    source_rows_compared: int
    target_rows_compared: int


@dataclass(frozen=True)
class FastForwardResult:
    """Result of fast-forwarding one side past rows that cannot match the other."""

    new_records: list[RECORD_WITH_KEY_AND_HASH]
    rows_compared: int


class RowValidationHandler:
    """Encapsulates L3 row-by-row hash validation logic."""

    def __init__(self, parent: DataValidationHandler) -> None:
        """Initialize with a reference to the parent handler."""
        self._parent = parent

    @property
    def logger(self):
        """Return the parent handler's logger."""
        return self._parent.logger

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def handle(
        self,
        task: dict[str, Any],
        payload: dict[str, Any],
        *,
        profiler: ExecutionProfiler | None = None,
    ) -> TaskResult:
        """Execute the full row-hash pipeline for row-by-row validation."""
        if profiler is None:
            profiler = ExecutionProfiler()

        table_name = payload.get(PAYLOAD_TABLE_NAME, "unknown")
        workflow_id = payload.get(PAYLOAD_WORKFLOW_ID, 0)
        table_metadata_id = payload.get(PAYLOAD_TABLE_METADATA_ID, 0)
        partition_number = payload.get(PAYLOAD_PARTITION_NUMBER)
        target_id = payload.get(PAYLOAD_TARGET_ID, "")
        source_platform_str = payload.get(PAYLOAD_SOURCE_PLATFORM, "")
        source_table_fqn = payload.get(PAYLOAD_SOURCE_TABLE_FQN, table_name)
        target_table_fqn = payload.get(PAYLOAD_TARGET_TABLE_FQN, table_name)
        index_column_list = payload.get(PAYLOAD_INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            payload.get(PAYLOAD_TARGET_INDEX_COLUMN_LIST) or index_column_list
        )
        max_failed_rows = payload.get(PAYLOAD_MAX_FAILED_ROWS_NUMBER) or 100
        columns_metadata_raw = payload.get(PAYLOAD_COLUMNS_METADATA) or []
        source_where_clause = payload.get(PAYLOAD_SOURCE_WHERE_CLAUSE) or ""
        target_where_clause = payload.get(PAYLOAD_TARGET_WHERE_CLAUSE) or ""
        object_type_str = payload.get(PAYLOAD_OBJECT_TYPE, ObjectType.TABLE.name)
        source_object_type = resolve_object_type(object_type_str)
        custom_normalizations_source = (
            get_custom_override(payload, PAYLOAD_CUSTOM_NORMALIZATIONS_SOURCE) or []
        )
        custom_normalizations_target = (
            get_custom_override(payload, PAYLOAD_CUSTOM_NORMALIZATIONS_TARGET) or []
        )

        log_prefix = self._log_prefix(table_name, partition_number)

        if not index_column_list:
            self.logger.error(
                f"{log_prefix} requires index_column_list for {table_name}"
            )
            return {
                task_keys.STATUS: "error",
                task_keys.DETAILS: "Missing index_column_list",
            }

        source_platform = resolve_platform(source_platform_str)

        source_columns_unordered = [
            ColumnMetadata(
                name=c["name"],
                data_type=c["data_type"],
                nullable=True,
                is_primary_key=False,
                calculated_column_size_in_bytes=0,
                properties={},
            )
            for c in columns_metadata_raw
        ]

        handle_sw = Stopwatch()
        self.logger.info(
            f"{log_prefix} START "
            f"(source={source_table_fqn} -> target={target_table_fqn}, "
            f"source_platform={source_platform.value}, "
            f"workflow_id={workflow_id}, table_metadata_id={table_metadata_id}, "
            f"index_cols={index_column_list}, max_failed_rows={max_failed_rows}, "
            f"source_columns={len(source_columns_unordered)})"
        )

        # Parallel setup: fetch target column metadata + open source connection
        self.logger.info(
            f"{log_prefix} step=setup START "
            f"(open source connection || fetch target column metadata)"
        )
        with Stopwatch() as setup_sw, ThreadPoolExecutor(max_workers=1) as pool:
            source_conn_future = pool.submit(self._parent._open_source_connection, task)
            target_columns = self._get_target_column_metadata(
                target_table_fqn, source_columns_unordered
            )
            source_conn = source_conn_future.result()
        self.logger.info(
            f"{log_prefix} step=setup DONE "
            f"elapsed_ms={setup_sw.elapsed_ms} "
            f"(target_columns={len(target_columns)})"
        )

        target_col_order = {col.name.upper(): i for i, col in enumerate(target_columns)}
        source_columns = sorted(
            source_columns_unordered,
            key=lambda c: target_col_order.get(c.name.upper(), len(target_col_order)),
        )

        if custom_normalizations_source:
            self.logger.info(
                f"{log_prefix} applying {len(custom_normalizations_source)} custom "
                f"normalization(s) for source: {custom_normalizations_source}"
            )
        if custom_normalizations_target:
            self.logger.info(
                f"{log_prefix} applying {len(custom_normalizations_target)} custom "
                f"normalization(s) for target: {custom_normalizations_target}"
            )

        _default_limit = MAX_CONCAT_LENGTH.get(Platform.SNOWFLAKE, 13_421_772)
        effective_concat_limit = min(
            MAX_CONCAT_LENGTH.get(source_platform, _default_limit),
            MAX_CONCAT_LENGTH.get(Platform.SNOWFLAKE, _default_limit),
        )

        with Stopwatch() as ctx_sw:
            source_ctx = build_row_table_context(
                platform=source_platform,
                origin=Origin.SOURCE,
                table_fqn=source_table_fqn,
                columns=source_columns,
                index_column_list=index_column_list,
                chunk_number=1,
                max_failed_rows_number=max_failed_rows,
                row_count=0,
                where_clause=source_where_clause,
                max_concat_length=effective_concat_limit,
                object_type=source_object_type,
                custom_normalizations=custom_normalizations_source,
            )
            target_ctx = build_row_table_context(
                platform=Platform.SNOWFLAKE,
                origin=Origin.TARGET,
                table_fqn=target_table_fqn,
                columns=target_columns,
                index_column_list=target_index_column_list,
                chunk_number=1,
                max_failed_rows_number=max_failed_rows,
                row_count=0,
                where_clause=target_where_clause,
                max_concat_length=effective_concat_limit,
                object_type=source_object_type,
                custom_normalizations=custom_normalizations_target,
            )

            unified = compute_unified_column_groups(
                source_ctx.columns_to_validate,
                target_ctx.columns_to_validate,
                effective_concat_limit,
            )
            if unified is not None:
                source_ctx.column_groups, target_ctx.column_groups = unified
        self.logger.info(
            f"{log_prefix} step=build_contexts DONE "
            f"elapsed_ms={ctx_sw.elapsed_ms} "
            f"(effective_concat_limit={effective_concat_limit}, "
            f"source_cols={len(source_ctx.columns_to_validate)}, "
            f"target_cols={len(target_ctx.columns_to_validate)}, "
            f"use_column_groups={source_ctx.use_column_groups}, "
            f"unified_groups={unified is not None})"
        )

        if not source_ctx.index_column_collection:
            available = ", ".join(sorted(c.name for c in source_columns)) or "(none)"
            self.logger.error(
                f"{log_prefix} no index columns resolved for source "
                f"{source_table_fqn}: index_column_list={index_column_list} does not "
                f"match any L1 schema column. Available columns: {available}."
            )
            return {
                task_keys.STATUS: "error",
                task_keys.DETAILS: (
                    f"index_column_list {index_column_list!r} does not match L1 columns for {source_table_fqn}"
                ),
            }
        if not target_ctx.index_column_collection:
            available = ", ".join(sorted(c.name for c in target_columns)) or "(none)"
            self.logger.error(
                f"{log_prefix} no index columns resolved for target "
                f"{target_table_fqn}: target_index_column_list={target_index_column_list}. "
                f"Available columns: {available}."
            )
            return {
                task_keys.STATUS: "error",
                task_keys.DETAILS: (
                    f"target_index_column_list {target_index_column_list!r} does not match target columns for {target_table_fqn}"
                ),
            }

        pipeline_params = RowHashPipelineParams(
            source_conn=source_conn,
            source_ctx=source_ctx,
            target_ctx=target_ctx,
            index_column_list=index_column_list,
            target_index_column_list=target_index_column_list,
            source_table_fqn=source_table_fqn,
            target_table_fqn=target_table_fqn,
            table_name=table_name,
            workflow_id=workflow_id,
            table_metadata_id=table_metadata_id,
            target_id=target_id,
            max_failed_rows=max_failed_rows,
            result_pipes=payload.get(PAYLOAD_RESULT_PIPES),
            partition_number=partition_number,
        )
        try:
            result = self._run_row_hash_pipeline(pipeline_params, profiler=profiler)
            self.logger.info(
                f"{log_prefix} END status={result.get(task_keys.STATUS)} total_elapsed_ms={handle_sw.stop()}"
            )
            return result
        finally:
            source_conn.close()

    @staticmethod
    def _log_prefix(table_name: str, partition_number: int | None) -> str:
        """Return a consistent log prefix for a row-hash validation run."""
        if partition_number is not None:
            return f"RowHash[{table_name} part={partition_number}]"
        return f"RowHash[{table_name}]"

    # ------------------------------------------------------------------
    # Row-hash pipeline
    # ------------------------------------------------------------------

    def _run_row_hash_pipeline(
        self,
        params: RowHashPipelineParams,
        *,
        profiler: ExecutionProfiler | None = None,
    ) -> TaskResult:
        """
        Execute the inline row-hash pipeline.

        Opens two row-hash ``SELECT`` cursors (ordered by index key), then
        repeatedly parallel-fetches row windows, applies strip/align, and
        calls ``compare_md5_rows`` on each merge-safe core until both cursors
        are drained.
        """
        if profiler is None:
            profiler = ExecutionProfiler()

        comparison_result: ComparisonResult = (
            self._submit_queries_and_execute_comparison(params, profiler)
        )
        task_result = self._write_and_upload_results(
            params, comparison_result, profiler
        )
        return task_result

    def _submit_queries_and_execute_comparison(
        self, params: RowHashPipelineParams, profiler: ExecutionProfiler
    ) -> ComparisonResult:
        with self._parent.snowflake_datasource.get_cursor(
            dict_cursor=False
        ) as target_context_manager:
            # Prepare source cursor
            source_cursor = params.source_conn.cursor()
            source_cursor.arraysize = _ROW_HASH_FETCH_BATCH_SIZE

            # Prepare target cursor
            self._parent._ensure_query_tag()
            target_context_manager = self._parent.snowflake_datasource.get_cursor(
                dict_cursor=False
            )
            target_cursor = target_context_manager.__enter__()
            target_cursor.arraysize = _ROW_HASH_FETCH_BATCH_SIZE

            # Execute queries and compare
            try:
                log_prefix = self._log_prefix(
                    params.table_name, params.partition_number
                )
                self.logger.info(f"{log_prefix} step=submit_queries START")
                self._submit_queries(
                    params,
                    source_cursor,
                    target_cursor,
                    params.source_ctx,
                    params.target_ctx,
                    profiler,
                )
                result = self._compare_in_batches(
                    params, source_cursor, target_cursor, profiler
                )
                return result
            finally:
                source_cursor.close()

    def _submit_queries(
        self,
        params: RowHashPipelineParams,
        source_cursor: DBAPICursor,
        target_cursor: SnowflakeCursor,
        source_table_context: TableContext,
        target_table_context: TableContext,
        profiler: ExecutionProfiler,
    ):
        log_prefix = self._log_prefix(params.table_name, params.partition_number)
        self.logger.info(f"{log_prefix} step=submit_queries START")
        source_query: GeneratedQuery = generate_row_md5_select_query(
            source_table_context, order_by=True
        )
        target_query: GeneratedQuery = generate_row_md5_select_query(
            target_table_context, order_by=True
        )

        # We define a closure that will be called in a separate thread, so that we execute source and target queries in parallel
        def _execute_in_source_and_return_ms() -> int:
            with Stopwatch() as sw:
                source_cursor.execute(source_query.query_string)
            return sw.elapsed_ms

        # Execute both queries in parallel. The source query runs on a thread pool worker, while the target
        # query runs on the current thread so it can reuse the thread-local Snowflake "get_cursor".
        with ThreadPoolExecutor(max_workers=1) as exec_pool:
            # Future returns the elapsed time (ms) for the source-side execute() call.
            source_execution_time_ms_future = exec_pool.submit(
                _execute_in_source_and_return_ms
            )

            try:
                with profiler.measure(profiler_steps.EXECUTE_TARGET_QUERY):
                    target_cursor.execute(target_query.query_string)
            finally:
                source_execution_time_ms = source_execution_time_ms_future.result()
                profiler.record(
                    profiler_steps.EXECUTE_SOURCE_QUERY, source_execution_time_ms
                )
        self.logger.info(f"{log_prefix} step=submit_queries DONE")

    def _compare_in_batches(
        self,
        params: RowHashPipelineParams,
        source_cursor: DBAPICursor,
        target_cursor: SnowflakeCursor,
        profiler: ExecutionProfiler,
    ) -> ComparisonResult:
        log_prefix = self._log_prefix(params.table_name, params.partition_number)
        self.logger.info(f"{log_prefix} step=compare-in-batches START")
        max_failed_rows = params.max_failed_rows

        # Algorithm variables
        window_index = 0
        all_diffs: list[RowDiff] = []
        source_cursor_exhausted: bool = False
        target_cursor_exhausted: bool = False
        source_carryover: list[RECORD_WITH_KEY_AND_HASH] = []
        target_carryover: list[RECORD_WITH_KEY_AND_HASH] = []
        total_source_rows_compared = 0
        total_target_rows_compared = 0
        while True:
            self.logger.info(
                f"{log_prefix} step=compare-in-batches (window index = {window_index}) START"
            )
            # Check stop conditions
            remaining_diff_budget = max_failed_rows - len(all_diffs)
            if remaining_diff_budget <= 0:
                break
            if (
                source_cursor_exhausted
                and target_cursor_exhausted
                and not source_carryover
                and not target_carryover
            ):
                break

            # Fetch next chunks
            self.logger.info(
                f"{log_prefix} step=fetch-next-chunks (window index = {window_index}) START"
            )
            source_chunk, target_chunk = self._fetch_next_chunks(
                source_cursor,
                target_cursor,
                source_cursor_exhausted,
                target_cursor_exhausted,
                profiler,
            )
            self.logger.info(
                f"{log_prefix} step=fetch-next-chunks (window index {window_index}) DONE"
            )

            # Mark cursors as exhausted on the first empty chunk
            if not source_chunk and not source_cursor_exhausted:
                source_cursor_exhausted = True
            if not target_chunk and not target_cursor_exhausted:
                target_cursor_exhausted = True

            # Build per-side buffers from carryover + this window's chunk,
            # then peel off any trailing same-key run that may straddle the
            # window boundary (deferred to next iteration via *tail*).
            source_buffer = source_carryover + source_chunk
            target_buffer = target_carryover + target_chunk
            source_carryover = []
            target_carryover = []
            source_work, source_tail = _strip_trailing_same_key(
                source_buffer, has_reached_cursor_end=source_cursor_exhausted
            )
            target_work, target_tail = _strip_trailing_same_key(
                target_buffer, has_reached_cursor_end=target_cursor_exhausted
            )

            # Fast-forward each side past the other side's next key
            source_fast_forward_result = self._fast_forward(
                all_diffs, source_work, target_work, max_failed_rows, profiler
            )
            source_work = source_fast_forward_result.new_records
            total_source_rows_compared += source_fast_forward_result.rows_compared
            target_fast_forward_result = self._fast_forward(
                all_diffs, target_work, source_work, max_failed_rows, profiler
            )
            target_work = target_fast_forward_result.new_records
            total_target_rows_compared += target_fast_forward_result.rows_compared

            if (
                max_failed_rows - len(all_diffs)
            ) <= 0:  # Fast-forward adds mismatches, so we check if need to stop here
                break

            # If at least one active side is empty, push everything back into
            # carryover and fetch another window.
            both_empty = not source_work and not target_work
            source_empty = (
                not source_work and not source_cursor_exhausted and target_work
            )
            target_empty = (
                not target_work and not target_cursor_exhausted and source_work
            )
            if both_empty or source_empty or target_empty:
                source_carryover = source_work + source_tail
                target_carryover = target_work + target_tail
                window_index += 1
                continue

            # Align both work buffers at k_cut = min(last source key, last target key)
            (
                source_aligned_core,
                target_aligned_core,
                source_align_roll,
                target_align_roll,
            ) = _align_row_hash_buffers(
                source_work,
                target_work,
                source_cursor_exhausted=source_cursor_exhausted,
                target_cursor_exhausted=target_cursor_exhausted,
            )

            source_carryover = source_align_roll + source_tail
            target_carryover = target_align_roll + target_tail

            if not source_aligned_core and not target_aligned_core:
                window_index += 1
                continue

            remaining_diff_budget = max_failed_rows - len(all_diffs)
            if remaining_diff_budget <= 0:
                break

            # Run the actual key-by-key merge over the aligned cores
            self.logger.info(
                f"{log_prefix} step=compare-rows (window index = {window_index}) START"
            )
            with profiler.accumulate(profiler_steps.COMPARE_ROWS):
                batch_diffs, source_rows_compared, target_rows_compared = (
                    compare_md5_rows(
                        iter(source_aligned_core),
                        iter(target_aligned_core),
                        max_diffs=remaining_diff_budget,
                    )
                )
            self.logger.info(
                f"{log_prefix} step=compare-rows (window index {window_index}) DONE"
            )
            total_source_rows_compared += source_rows_compared
            total_target_rows_compared += target_rows_compared
            all_diffs.extend(batch_diffs)
            self.logger.info(
                f"{log_prefix} step=compare-in-batches (window index = {window_index}) DONE"
            )
            window_index += 1

        self.logger.info(f"{log_prefix} step=compare-in-batches DONE")
        return ComparisonResult(
            differences=all_diffs,
            source_rows_compared=total_source_rows_compared,
            target_rows_compared=total_target_rows_compared,
        )

    def _fetch_next_chunks(
        self,
        source_cursor: DBAPICursor,
        target_cursor: SnowflakeCursor,
        source_cursor_exhausted: bool,
        target_cursor_exhausted: bool,
        profiler: ExecutionProfiler,
    ) -> tuple[list[RECORD_WITH_KEY_AND_HASH], list[RECORD_WITH_KEY_AND_HASH]]:
        with ThreadPoolExecutor(max_workers=2) as pool:
            source_future = pool.submit(
                _fetch_row_hash_chunk_if_active,
                source_cursor,
                source_cursor_exhausted,
                profiler,
                profiler_steps.FETCH_SOURCE_RESULTS,
            )
            target_future = pool.submit(
                _fetch_row_hash_chunk_if_active,
                target_cursor,
                target_cursor_exhausted,
                profiler,
                profiler_steps.FETCH_TARGET_RESULTS,
            )
            source_chunk = source_future.result()
            target_chunk = target_future.result()
            return source_chunk, target_chunk

    def _fast_forward(
        self,
        all_diffs: list[RowDiff],
        rows_to_fast_forward: list[RECORD_WITH_KEY_AND_HASH],
        other_side_rows: list[RECORD_WITH_KEY_AND_HASH],
        max_failed_rows: int,
        profiler: ExecutionProfiler,
    ) -> FastForwardResult:
        rows_compared = 0
        if not other_side_rows:
            return FastForwardResult(
                new_records=rows_to_fast_forward, rows_compared=rows_compared
            )
        other_side_next_key = other_side_rows[0][0]
        while True:
            # Stop if there are no more records on either side (or if we have enough failed rows)
            remaining_diff_budget = max_failed_rows - len(all_diffs)
            if (
                not rows_to_fast_forward
                or not other_side_rows
                or remaining_diff_budget <= 0
            ):
                break

            # Stop if fast-forward has caught up (the next row on this side
            # is no longer strictly below the other side's next key).
            fast_forward_next_key = rows_to_fast_forward[0][0]
            if fast_forward_next_key >= other_side_next_key:
                break

            # Do fast-forward: slice off the rows strictly below the other
            # side's next key and emit one-sided diffs for them.
            rows_below_other_key, rows_to_fast_forward = (
                _take_prefix_strictly_before_key(
                    rows_to_fast_forward, other_side_next_key
                )
            )
            if not rows_below_other_key:
                break
            with profiler.accumulate(profiler_steps.COMPARE_ROWS):
                diffs, rows_compared, _ = compare_md5_rows(
                    iter(rows_below_other_key),
                    iter([]),
                    max_diffs=remaining_diff_budget,
                )
            all_diffs.extend(diffs)

        return FastForwardResult(
            new_records=rows_to_fast_forward, rows_compared=rows_compared
        )

    def _write_and_upload_results(
        self,
        params: RowHashPipelineParams,
        comparison_results: ComparisonResult,
        profiler: ExecutionProfiler,
    ) -> TaskResult:
        log_prefix = self._log_prefix(params.table_name, params.partition_number)
        # Extract from params
        target_id = params.target_id
        workflow_id = params.workflow_id
        table_metadata_id = params.table_metadata_id
        diffs = comparison_results.differences

        # Summary values
        rows_not_found_in_target = sum(
            1 for d in diffs if d.result == Result.NOT_FOUND_TARGET.value
        )
        rows_not_found_in_source = sum(
            1 for d in diffs if d.result == Result.NOT_FOUND_SOURCE.value
        )
        rows_with_differences = sum(
            1 for d in diffs if d.result == Result.FAILURE.value
        )
        total_diff_rows = len(diffs)
        total_rows_compared = (
            comparison_results.source_rows_compared
            + comparison_results.target_rows_compared
        )

        row_level_has_issues = total_diff_rows > 0
        summary_is_valid = not row_level_has_issues
        chunks_with_differences = 1 if total_diff_rows > 0 else 0

        self.logger.info(f"{log_prefix} step=write_results START")
        with profiler.measure(profiler_steps.WRITE_RESULTS):
            # Prepare data for diffs.csv
            diffs_data = self._build_diffs_csv_data(
                diffs,
                params.index_column_list,
                params.target_index_column_list,
                params.source_table_fqn,
                params.target_table_fqn,
                params.source_ctx.object_type.value,
            )

            # Prepare data for summary.csv
            summary_data = [
                [
                    params.table_name,
                    1,  # total_chunks (always 1 in new pipeline)
                    1 - chunks_with_differences,  # chunks without differences
                    chunks_with_differences,
                    total_rows_compared,
                    rows_not_found_in_target,
                    rows_not_found_in_source,
                    rows_with_differences,
                    summary_is_valid,
                ]
            ]

            temp_dir = tempfile.mkdtemp()
            diffs_path = self._parent._write_l3_csv(
                temp_dir, "diffs.csv", diffs_data, workflow_id, table_metadata_id
            )
            summary_path = self._parent._write_l3_csv(
                temp_dir, "summary.csv", summary_data, workflow_id, table_metadata_id
            )
        self.logger.info(f"{log_prefix} step=write_results DONE")

        self.logger.info(f"{log_prefix} step=upload_results START")
        with profiler.measure(profiler_steps.UPLOAD_RESULTS):
            self._parent._upload_to_stage(diffs_path, f"{target_id}/diffs")
            self._parent._upload_to_stage(summary_path, f"{target_id}/summary")
            self._parent._refresh_result_pipes(params.result_pipes)
            self._parent._cleanup_temp_dir(temp_dir)
        self.logger.info(f"{log_prefix} step=upload_results DONE")
        return {
            task_keys.STATUS: "success",
            task_keys.DETAILS: (
                f"Row validation: {total_diff_rows} diffs "
                f"({total_rows_compared} rows compared)"
            ),
            task_keys.TOTAL: total_diff_rows,
        }

    # ------------------------------------------------------------------
    # CSV building
    # ------------------------------------------------------------------

    @staticmethod
    def _build_diffs_csv_data(
        diffs: list[RowDiff],
        index_column_list: list[str],
        target_index_column_list: list[str],
        source_table_fqn: str,
        target_table_fqn: str,
        object_type: str = ObjectType.TABLE.name,
    ) -> list[list]:
        """Convert RowDiff list into CSV row data for upload."""
        rows: list[list] = []
        for d in diffs:
            if d.source_index_values is not None:
                src_vals = ", ".join(
                    f"{col}={val}"
                    for col, val in zip(
                        index_column_list, d.source_index_values, strict=False
                    )
                )
            else:
                src_vals = "N/A"
            if d.target_index_values is not None:
                tgt_vals = ", ".join(
                    f"{col}={val}"
                    for col, val in zip(
                        target_index_column_list, d.target_index_values, strict=False
                    )
                )
            else:
                tgt_vals = "N/A"
            rows.append(
                [
                    source_table_fqn,
                    object_type,
                    d.result,
                    src_vals,
                    tgt_vals,
                    target_table_fqn,
                ]
            )
        return rows

    def _get_target_column_metadata(
        self,
        target_table_fqn: str,
        fallback_columns: list[ColumnMetadata],
    ) -> list[ColumnMetadata]:
        """Query Snowflake information_schema for the target table's native column types."""
        parts = target_table_fqn.split(".")
        if len(parts) == 3:
            tgt_db, tgt_schema, tgt_table = parts
        elif len(parts) == 2:
            tgt_db, tgt_schema, tgt_table = "", parts[0], parts[1]
        else:
            return fallback_columns

        prefix = f"{tgt_db}." if tgt_db else ""
        query = (
            f"SELECT column_name, data_type "
            f"FROM {prefix}information_schema.columns "
            f"WHERE table_schema = '{tgt_schema.upper()}' "
            f"AND table_name = '{tgt_table.upper()}' "
            f"ORDER BY ordinal_position"
        )
        try:
            df = self._parent._run_target_query(query)
            if df.empty:
                self.logger.warning(
                    f"No columns found in information_schema for {target_table_fqn}, falling back to source column types"
                )
                return fallback_columns

            columns = []
            for _, row in df.iterrows():
                col_name = row.get("COLUMN_NAME", row.get("column_name", ""))
                data_type = row.get("DATA_TYPE", row.get("data_type", ""))
                if col_name and data_type:
                    columns.append(
                        ColumnMetadata(
                            name=col_name,
                            data_type=data_type,
                            nullable=True,
                            is_primary_key=False,
                            calculated_column_size_in_bytes=0,
                            properties={},
                        )
                    )
            return columns if columns else fallback_columns
        except Exception as e:
            self.logger.warning(
                f"Failed to get target column metadata for {target_table_fqn}: {e}, falling back to source column types"
            )
            return fallback_columns
