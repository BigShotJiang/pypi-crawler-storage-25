"""
L3 cell-by-cell validation handler.

Compares individual cell values between source and target using the Polars-based
``validate_cell`` function from the SDV library.
"""

from __future__ import annotations

import tempfile

from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING, Any

import pandas as pd
import polars as pl

from data_exchange_agent.constants import profiler_steps, task_keys
from data_exchange_agent.tasks.data_validation.helpers import (
    PAYLOAD_INDEX_COLUMN_LIST,
    PAYLOAD_MAX_COLUMNS_PER_CELL_BATCH,
    PAYLOAD_MAX_FAILED_ROWS_NUMBER,
    PAYLOAD_OBJECT_TYPE,
    PAYLOAD_RESULT_PIPES,
    PAYLOAD_SOURCE_PLATFORM,
    PAYLOAD_SOURCE_QUERY,
    PAYLOAD_SOURCE_TABLE_FQN,
    PAYLOAD_TABLE_METADATA_ID,
    PAYLOAD_TABLE_NAME,
    PAYLOAD_TARGET_ID,
    PAYLOAD_TARGET_INDEX_COLUMN_LIST,
    PAYLOAD_TARGET_QUERY,
    PAYLOAD_TARGET_TABLE_FQN,
    PAYLOAD_WORKFLOW_ID,
    TaskResult,
    build_table_context,
    resolve_object_type,
    resolve_platform,
)
from data_exchange_agent.tasks.execution_profiler import ExecutionProfiler
from snowflake.snowflake_data_validation.public import (
    DuplicateKeyInfo,
    QueryExecutionResult,
    validate_cell,
)


_CELL_BATCH_SIZE = 5_000

# Default maximum columns per cell-validation batch (vertical partitioning).
# When a DataFrame has more columns than this, the handler splits non-index
# columns into batches and runs validate_cell per batch.
DEFAULT_MAX_COLUMNS_PER_CELL_BATCH = 50

if TYPE_CHECKING:
    from data_exchange_agent.tasks.data_validation.handler import (
        DataValidationHandler,
    )


def chunk_column_names(
    columns: list[str],
    max_per_batch: int,
    index_columns: list[str] | None = None,
) -> list[list[str]]:
    """
    Split *columns* into batches of at most *max_per_batch* for vertical partitioning.

    When *index_columns* is provided, those columns are prepended to every
    batch (they are needed for row matching) and excluded from the regular
    column pool so they are not compared redundantly.

    Returns a single-element list containing all columns when batching is
    unnecessary (column count <= *max_per_batch* or *max_per_batch* <= 0).
    """
    if max_per_batch <= 0 or len(columns) <= max_per_batch:
        return [columns]

    index_set: set[str] = set()
    index_list: list[str] = []
    if index_columns:
        index_set = {c.casefold() for c in index_columns}
        index_list = [c for c in columns if c.casefold() in index_set]

    non_index = [c for c in columns if c.casefold() not in index_set]

    effective_batch = max_per_batch - len(index_list)
    if effective_batch <= 0:
        return [columns]

    batches: list[list[str]] = []
    for i in range(0, len(non_index), effective_batch):
        chunk = non_index[i : i + effective_batch]
        batches.append(index_list + chunk)

    return batches if batches else [columns]


class CellValidationHandler:
    """Encapsulates L3 cell-by-cell validation logic."""

    def __init__(self, parent: DataValidationHandler) -> None:
        """Initialize with a reference to the parent handler."""
        self._parent = parent

    @property
    def logger(self):
        """Return the parent handler's logger."""
        return self._parent.logger

    def handle(
        self,
        task: dict[str, Any],
        payload: dict[str, Any],
        *,
        profiler: ExecutionProfiler | None = None,
    ) -> TaskResult:
        """Execute cell-by-cell validation using Polars-based comparison."""
        if profiler is None:
            profiler = ExecutionProfiler()

        table_name = payload.get(PAYLOAD_TABLE_NAME, "unknown")
        workflow_id = payload.get(PAYLOAD_WORKFLOW_ID, 0)
        table_metadata_id = payload.get(PAYLOAD_TABLE_METADATA_ID, 0)
        source_query = payload.get(PAYLOAD_SOURCE_QUERY, "")
        target_query = payload.get(PAYLOAD_TARGET_QUERY, "")
        target_id = payload.get(PAYLOAD_TARGET_ID, "")
        source_platform_str = payload.get(PAYLOAD_SOURCE_PLATFORM, "")
        index_column_list = payload.get(PAYLOAD_INDEX_COLUMN_LIST) or []
        target_index_column_list = (
            payload.get(PAYLOAD_TARGET_INDEX_COLUMN_LIST) or index_column_list
        )
        max_failed_rows = payload.get(PAYLOAD_MAX_FAILED_ROWS_NUMBER) or 100
        max_cols_batch = (
            payload.get(PAYLOAD_MAX_COLUMNS_PER_CELL_BATCH)
            or DEFAULT_MAX_COLUMNS_PER_CELL_BATCH
        )

        object_type_str = payload.get(PAYLOAD_OBJECT_TYPE, "TABLE")
        source_object_type = resolve_object_type(object_type_str)

        source_platform = resolve_platform(source_platform_str)
        table_ctx = build_table_context(
            source_platform, table_name, object_type=source_object_type
        )

        source_table_fqn = payload.get(PAYLOAD_SOURCE_TABLE_FQN, table_name)
        target_table_fqn = payload.get(PAYLOAD_TARGET_TABLE_FQN, table_name)

        self.logger.info(f"Starting cell validation for {table_name}")

        with ThreadPoolExecutor(max_workers=2) as pool:
            source_future = pool.submit(
                self._parent._timed_source_query, source_query, task
            )
            target_future = pool.submit(self._parent._timed_target_query, target_query)
            source_fetch = source_future.result()
            target_fetch = target_future.result()
            profiler.record(profiler_steps.FETCH_SOURCE_DATA, source_fetch.elapsed_ms)
            profiler.record(profiler_steps.FETCH_TARGET_DATA, target_fetch.elapsed_ms)
            source_df = source_fetch.dataframe
            target_df = target_fetch.dataframe

        target_df.columns = [c.upper() for c in target_df.columns]

        self.logger.info(
            f"Cell validation DataFrames: source={source_df.shape}, "
            f"target={target_df.shape}"
        )

        profiler.step(profiler_steps.CONVERT_TO_POLARS)
        source_pl = pl.from_pandas(source_df)
        target_pl = pl.from_pandas(target_df)

        index_cols = (
            [c.upper() for c in index_column_list] if index_column_list else None
        )
        target_index_cols = (
            [c.upper() for c in target_index_column_list]
            if target_index_column_list
            else None
        )

        # Vertical partitioning: split columns into batches when the table is
        # wider than max_cols_batch.  Each batch includes the index columns so
        # that validate_cell can match rows, but only the non-index columns in
        # that batch are compared.
        src_col_chunks = chunk_column_names(
            source_pl.columns, max_cols_batch, index_columns=index_cols
        )
        tgt_col_chunks = chunk_column_names(
            target_pl.columns, max_cols_batch, index_columns=target_index_cols
        )

        if len(src_col_chunks) > 1:
            self.logger.info(
                f"Vertical partitioning: {len(src_col_chunks)} column batches "
                f"(max_cols_batch={max_cols_batch})"
            )

        profiler.step(profiler_steps.CELL_COMPARISON)
        all_diffs: list[pd.DataFrame] = []
        all_dup_infos: list[DuplicateKeyInfo] = []
        for chunk_idx, (src_chunk_cols, tgt_chunk_cols) in enumerate(
            zip(src_col_chunks, tgt_col_chunks, strict=False)
        ):
            src_chunk = source_pl.select(src_chunk_cols)
            tgt_chunk = target_pl.select(tgt_chunk_cols)

            if len(src_col_chunks) > 1:
                self.logger.info(
                    f"Column batch {chunk_idx + 1}/{len(src_col_chunks)}: "
                    f"{len(src_chunk_cols)} source cols, {len(tgt_chunk_cols)} target cols"
                )

            if index_cols:
                chunk_diffs, chunk_dups = self._batched_cell_validation(
                    src_chunk,
                    tgt_chunk,
                    table_ctx,
                    index_cols,
                    target_index_cols,
                    max_failed_rows - sum(len(d) for d in all_diffs),
                )
            else:
                chunk_diffs, chunk_dups = self._single_cell_validation(
                    src_chunk,
                    tgt_chunk,
                    table_ctx,
                    index_cols,
                    target_index_cols,
                    max_failed_rows - sum(len(d) for d in all_diffs),
                )

            all_diffs.extend(chunk_diffs)
            all_dup_infos.extend(chunk_dups)

            if sum(len(d) for d in all_diffs) >= max_failed_rows:
                self.logger.info(
                    f"Reached max_failed_rows ({max_failed_rows}) during column batch "
                    f"{chunk_idx}, stopping vertical partitioning"
                )
                break

        total_diffs = sum(len(d) for d in all_diffs)
        self.logger.info(f"Cell validation for {table_name}: diffs={total_diffs}")

        diffs_data = self._build_diffs_data(all_diffs, table_name, max_failed_rows)

        profiler.step(profiler_steps.UPLOAD_RESULTS)
        temp_dir = tempfile.mkdtemp()
        diffs_path = self._parent._write_l3_csv(
            temp_dir, "diffs.csv", diffs_data, workflow_id, table_metadata_id
        )
        self._parent._upload_to_stage(diffs_path, f"{target_id}/diffs")

        if all_dup_infos:
            row_diffs_data = self._build_row_diffs_from_dup_infos(
                all_dup_infos,
                index_column_list,
                source_table_fqn,
                target_table_fqn,
                object_type_str,
            )
            row_diffs_path = self._parent._write_l3_csv(
                temp_dir,
                "row_diffs.csv",
                row_diffs_data,
                workflow_id,
                table_metadata_id,
            )
            self._parent._upload_to_stage(row_diffs_path, f"{target_id}/diffs")
            self.logger.info(
                f"Uploaded {len(row_diffs_data)} duplicate-key row diff(s) "
                f"to ROW_VALIDATION_RESULTS for {table_name}"
            )

        self._parent._refresh_result_pipes(payload.get(PAYLOAD_RESULT_PIPES))
        self._parent._cleanup_temp_dir(temp_dir)
        profiler.finish()

        self.logger.info(
            f"Cell validation complete for {table_name}: "
            f"{total_diffs} diffs uploaded"
        )
        return {
            task_keys.STATUS: "success",
            task_keys.DETAILS: (
                f"Cell validation: {total_diffs} diffs for {table_name}"
            ),
            task_keys.TOTAL: total_diffs,
        }

    # ------------------------------------------------------------------
    # Validation strategies
    # ------------------------------------------------------------------

    def _single_cell_validation(
        self,
        source_pl: pl.DataFrame,
        target_pl: pl.DataFrame,
        table_ctx: Any,
        index_cols: list[str] | None,
        target_index_cols: list[str] | None,
        max_failed_rows: int,
    ) -> tuple[list[pd.DataFrame], list[DuplicateKeyInfo]]:
        """Run a single validate_cell call (no index columns / positional)."""
        validation, dup_infos = validate_cell(
            QueryExecutionResult(dataframe=source_pl),
            QueryExecutionResult(dataframe=target_pl),
            table_ctx,
            index_columns=index_cols,
            target_index_columns=target_index_cols,
        )
        if validation.results_dataframe.empty:
            return [], dup_infos
        return [validation.results_dataframe.head(max_failed_rows)], dup_infos

    def _batched_cell_validation(
        self,
        source_pl: pl.DataFrame,
        target_pl: pl.DataFrame,
        table_ctx: Any,
        index_cols: list[str],
        target_index_cols: list[str] | None,
        max_failed_rows: int,
    ) -> tuple[list[pd.DataFrame], list[DuplicateKeyInfo]]:
        """Sort by key columns, partition into batches, and validate each."""
        target_index_cols = target_index_cols or index_cols

        source_pl = source_pl.sort(index_cols)
        target_pl = target_pl.sort(target_index_cols)

        src_key = source_pl.select(pl.struct(index_cols).alias("_key"))["_key"]

        boundaries = src_key.gather_every(_CELL_BATCH_SIZE, offset=_CELL_BATCH_SIZE)

        if boundaries.is_empty():
            self.logger.info("Data fits in a single batch, no splitting needed")
            return self._single_cell_validation(
                source_pl,
                target_pl,
                table_ctx,
                index_cols,
                target_index_cols,
                max_failed_rows,
            )

        source_pl = source_pl.with_columns(
            boundaries.search_sorted(src_key, side="right").alias("_batch")
        )

        tgt_key = target_pl.select(pl.struct(target_index_cols).alias("_key"))["_key"]
        tgt_key = tgt_key.struct.rename_fields(index_cols)

        target_pl = target_pl.with_columns(
            boundaries.search_sorted(tgt_key, side="right").alias("_batch")
        )

        batch_ids = sorted(
            set(source_pl["_batch"].unique().to_list())
            | set(target_pl["_batch"].unique().to_list())
        )

        self.logger.info(f"Cell validation split into {len(batch_ids)} batches")

        all_diffs: list[pd.DataFrame] = []
        all_dup_infos: list[DuplicateKeyInfo] = []
        for batch_id in batch_ids:
            src_batch = source_pl.filter(pl.col("_batch") == batch_id).drop("_batch")
            tgt_batch = target_pl.filter(pl.col("_batch") == batch_id).drop("_batch")

            self.logger.info(
                f"Batch {batch_id}: source={src_batch.height}, "
                f"target={tgt_batch.height}"
            )

            validation, dup_infos = validate_cell(
                QueryExecutionResult(dataframe=src_batch),
                QueryExecutionResult(dataframe=tgt_batch),
                table_ctx,
                index_columns=index_cols,
                target_index_columns=target_index_cols,
            )

            if not validation.results_dataframe.empty:
                all_diffs.append(validation.results_dataframe)
            all_dup_infos.extend(dup_infos)

            if sum(len(d) for d in all_diffs) >= max_failed_rows:
                self.logger.info(
                    f"Reached max_failed_rows ({max_failed_rows}), "
                    "stopping cell batches"
                )
                break

        return all_diffs, all_dup_infos

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_row_diffs_from_dup_infos(
        dup_infos: list[DuplicateKeyInfo],
        index_column_list: list[str],
        source_table_fqn: str,
        target_table_fqn: str,
        object_type: str = "TABLE",
    ) -> list[list]:
        """
        Convert duplicate key info into row-validation diffs CSV rows.

        Each duplicate key is written as a ``DUPLICATE_SOURCE`` or
        ``DUPLICATE_TARGET`` row in the same format used by
        ``RowValidationHandler._build_diffs_csv_data``, so the results
        end up in ``ROW_VALIDATION_RESULTS`` regardless of whether the
        validation ran in hybrid or pure cell mode.
        """
        rows: list[list] = []
        for info in dup_infos:
            result = f"DUPLICATE_{info.side.upper()}"
            for key_dict in info.sample_duplicate_keys:
                vals = ", ".join(
                    f"{col}={key_dict.get(col, 'N/A')}" for col in index_column_list
                )
                if info.side == "source":
                    src_vals = vals
                    tgt_vals = "N/A"
                else:
                    src_vals = "N/A"
                    tgt_vals = vals
                rows.append(
                    [
                        source_table_fqn,
                        object_type,
                        result,
                        src_vals,
                        tgt_vals,
                        target_table_fqn,
                    ]
                )
        return rows

    @staticmethod
    def _build_diffs_data(
        all_diffs: list[pd.DataFrame],
        table_name: str,
        max_failed_rows: int,
    ) -> list[list]:
        """Concat accumulated diffs, cap to *max_failed_rows*, return rows."""
        if not all_diffs:
            return []

        combined = pd.concat(all_diffs, ignore_index=True)
        capped = combined.head(max_failed_rows)

        diffs_df = pd.DataFrame(
            {
                "table": table_name,
                "row_num": capped["ROW"].fillna(0),
                "column": capped["COLUMN"].fillna(""),
                "source_value": capped["SOURCE_VALUE"].fillna("").astype(str),
                "target_value": capped["TARGET_VALUE"].fillna("").astype(str),
            }
        )
        return diffs_df.values.tolist()
