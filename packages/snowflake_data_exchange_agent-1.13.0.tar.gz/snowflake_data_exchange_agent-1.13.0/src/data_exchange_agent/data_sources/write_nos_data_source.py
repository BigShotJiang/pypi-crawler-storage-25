"""
Teradata WRITE_NOS data source implementation.

This module provides a specialized data source for executing Teradata WRITE_NOS
statements. WRITE_NOS exports data directly from Teradata to cloud object
storage (S3, Azure Blob, GCS) as Parquet. The DEA executes the WRITE_NOS SQL
via ODBC; Teradata writes the files and returns metadata rows (NodeId, AmpId,
ObjectName, etc.) which we consume and discard.
"""

from __future__ import annotations

import re

from typing import TYPE_CHECKING, Any

from dependency_injector.wiring import Provide, inject

from data_exchange_agent.constants import config_keys, container_keys
from data_exchange_agent.data_sources.base import BaseDataSource
from data_exchange_agent.utils.sf_logger import SFLogger


if TYPE_CHECKING:
    import pyodbc  # pylint: disable=import-error

    from data_exchange_agent.config.manager import ConfigManager
    from data_exchange_agent.config.sections.connections.transports.odbc.base import (
        BaseODBCConnectionConfig,
    )


def _get_pyodbc() -> Any:
    """Lazily import pyodbc to avoid loading unixODBC at module import time."""
    import pyodbc

    return pyodbc


# Pattern to redact AUTHORIZATION('...') for safe logging.
#
# Group 1 captures the AUTHORIZATION( prefix (including any whitespace) so it
# can be preserved during substitution. Group 2 captures the opening quote
# character; the back-reference ``\2`` then matches the same quote at the end.
# Using a back-reference (instead of a character class) is important because
# the quoted argument is often a JSON object whose body contains the *other*
# quote character (e.g. ``AUTHORIZATION('{"Access_ID":"...","Access_Key":"..."}'`` —
# single-quoted outer, double-quoted inner). DOTALL lets the body span lines
# in pretty-printed statements.
_AUTHORIZATION_PATTERN = re.compile(
    r"(AUTHORIZATION\s*\(\s*)(['\"]).*?\2",
    re.IGNORECASE | re.DOTALL,
)


def _sanitize_write_nos_statement(statement: str) -> str:
    """
    Redact credentials from a WRITE_NOS statement for safe logging.

    Replaces ``AUTHORIZATION('...')`` with a masked placeholder so that
    inline access keys, secrets, or named authorization references are never
    written to log files.

    Args:
        statement: The raw WRITE_NOS SQL statement.

    Returns:
        The statement with the AUTHORIZATION value redacted.

    """
    return _AUTHORIZATION_PATTERN.sub(r"\1'***'", statement)


class WriteNosDataSource(BaseDataSource):
    """
    Data source for Teradata WRITE_NOS operations.

    This class executes Teradata WRITE_NOS statements which write data directly
    to cloud object storage (S3, Azure Blob, or GCS). Unlike standard data
    sources, WRITE_NOS does not stream result data to the agent; Teradata
    writes Parquet files to the configured location and returns a small
    metadata result set.

    This implementation:
    - Executes the WRITE_NOS statement via ODBC
    - Consumes the metadata result set (NodeId, AmpId, ObjectName, etc.) so the
      operation completes cleanly
    - Does NOT create local Parquet files
    - Returns success after command execution

    The full WRITE_NOS statement (including ``AUTHORIZATION``) is built by
    :class:`~data_exchange_agent.config.sections.connections.dialects.teradata.WriteNosConfig`
    in ``TaskManager._prepare_write_nos_statement``.

    """

    @property
    def statement(self) -> str:
        """The WRITE_NOS statement to execute."""
        return self._statement

    @property
    def results_folder_path(self) -> str:
        """The path to the results folder (unused for WRITE_NOS)."""
        return self._results_folder_path

    @property
    def base_file_name(self) -> str:
        """The base file name (unused for WRITE_NOS)."""
        return self._base_file_name

    @inject
    def __init__(  # pylint: disable=unused-argument
        self,
        engine: str,
        statement: str,
        results_folder_path: str | None = None,
        base_file_name: str = "result",
        suggested_batch_size: int | None = None,
        database: str | None = None,
        use_database_command: str | None = None,
        logger: SFLogger = Provide[container_keys.SF_LOGGER],
        program_config: ConfigManager = Provide[container_keys.PROGRAM_CONFIG],
    ) -> None:
        """
        Initialize a new WriteNosDataSource.

        Args:
            engine: The database engine type (should be ``teradata``).
            statement: The WRITE_NOS SQL statement to execute.
            results_folder_path: Unused for WRITE_NOS (kept for interface compatibility).
            base_file_name: Unused for WRITE_NOS (kept for interface compatibility).
            suggested_batch_size: Unused for WRITE_NOS.
            database: Database name (kept for API compatibility).
            use_database_command: Pre-built SQL command to switch the active
                database before executing the statement (e.g.,
                ``DATABASE "ecommerce"`` for Teradata). Generated by the
                orchestrator via the platform's query builder. When ``None``,
                no database switching is performed.
            logger: The logger instance.
            program_config: The program configuration manager.

        """
        self.logger: SFLogger = logger
        self._statement: str = statement
        # WRITE_NOS writes directly to cloud storage; no local results folder
        # is needed.
        self._results_folder_path: str = results_folder_path or ""
        self._base_file_name: str = base_file_name
        self._use_database_command: str | None = use_database_command
        source_connections_config: dict[str, BaseODBCConnectionConfig] = program_config[config_keys.CONNECTIONS__SOURCE]

        self.__connection_string: str = source_connections_config[engine].connection_string

    def export_data(self) -> bool:
        """
        Execute the WRITE_NOS statement.

        Connects to Teradata, optionally runs ``use_database_command``,
        executes WRITE_NOS, and consumes the metadata result set so the
        operation completes cleanly. Teradata writes Parquet files to the
        cloud location embedded in the statement.

        Returns:
            ``True`` if the WRITE_NOS statement executed successfully.

        Raises:
            Exception: If the connection or execution fails.

        """
        pyodbc = _get_pyodbc()
        conn: pyodbc.Connection | None = None
        try:
            self.logger.info("Connecting to Teradata for WRITE_NOS operation")
            conn = pyodbc.connect(self.__connection_string)
        except Exception as e:
            self.logger.error(f"Error creating a connection to Teradata. Error: {e}")
            raise

        if self._use_database_command:
            self._switch_database(conn)

        try:
            self.logger.info(f"Executing WRITE_NOS: {_sanitize_write_nos_statement(self.statement)}")
            cursor = conn.cursor()
            cursor.execute(self.statement)
            # Consume the metadata result set (NodeId, AmpId, ObjectName, ...)
            # so the operation completes. Teradata returns one row per AMP.
            try:
                cursor.fetchall()
            except pyodbc.ProgrammingError:
                # Some drivers/result configurations don't expose a result set
                # for WRITE_NOS; treat that as a successful no-op.
                pass
            cursor.close()
            self.logger.info("WRITE_NOS command executed successfully. Data written to cloud.")
        except Exception as e:
            self.logger.error(f"Error executing WRITE_NOS command. Error: {e}")
            raise
        finally:
            if conn:
                conn.close()

        return True

    def _switch_database(self, conn: pyodbc.Connection) -> None:
        """
        Execute the pre-built database-switch command on the connection.

        The command is generated by the orchestrator's platform query builder
        and passed through the task payload, so this method is completely
        dialect-agnostic.

        Args:
            conn: Active ODBC connection.

        Raises:
            Exception: If the database-switch command fails.

        """
        assert self._use_database_command is not None  # Caller guarantees this

        try:
            self.logger.info(f"Executing database switch command: {self._use_database_command}")
            cursor = conn.cursor()
            cursor.execute(self._use_database_command)
            cursor.close()
            conn.commit()
        except Exception as e:
            self.logger.error(f"Error executing database switch command " f"'{self._use_database_command}'. Error: {e}")
            raise
