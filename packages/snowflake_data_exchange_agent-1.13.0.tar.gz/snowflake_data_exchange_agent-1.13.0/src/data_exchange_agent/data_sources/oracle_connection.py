"""
Oracle connections via ``oracledb`` (preferred) or ``pyodbc`` (fallback).

Tries the pure-Python ``oracledb`` driver in thin mode first (no Oracle Instant
Client or ODBC install required for typical EZ Connect). Falls back to
``pyodbc`` with an ODBC connection string when ``oracledb`` is not available or
disabled. Both drivers are DB-API 2.0 compliant for the subset used by the DEA.

Dispatch from multi-engine callers lives in
:func:`data_exchange_agent.data_sources.teradata_connection.open_source_connection`.
"""

from __future__ import annotations

import functools
import logging
import os
import threading
import time

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from data_exchange_agent.config.sections.connections.dialects.oracle.config import (
    OracleConnectionMode,
)
from data_exchange_agent.data_sources.teradata_connection import DBAPIConnection


if TYPE_CHECKING:
    from data_exchange_agent.config.sections.connections.dialects.oracle.config import (
        OracleConnectionConfig,
    )

logger = logging.getLogger(__name__)


@functools.lru_cache(maxsize=1)
def is_oracledb_available() -> bool:
    """Return True if the ``oracledb`` package can be imported."""
    try:
        import oracledb  # noqa: F401

        return True
    except ImportError:
        return False


def _dsn_for_oracledb(config: OracleConnectionConfig) -> str:
    """Build a connect ``dsn`` for oracledb (EZ Connect, TNS alias, or descriptor)."""
    mode = config.oracle_connection_mode
    if mode == OracleConnectionMode.BASIC:
        return f"{config.host}:{config.port}/{config.database}"
    if mode == OracleConnectionMode.TNS_ALIAS:
        name = config.tns_name
        if not name:
            raise RuntimeError("tns_name is unset")
        return name.strip()
    desc = config.connect_descriptor
    if not desc:
        raise RuntimeError("connect_descriptor is unset")
    return desc.strip()


def _oracledb_connect_with_optional_tns_admin(
    connect_kwargs: dict[str, Any],
    tns_admin: str,
) -> DBAPIConnection:
    """Call ``oracledb.connect`` with ``TNS_ADMIN`` set for the duration of the call."""
    import oracledb

    prev = os.environ.get("TNS_ADMIN")
    os.environ["TNS_ADMIN"] = tns_admin
    try:
        return oracledb.connect(**connect_kwargs)  # type: ignore[no-any-return]
    finally:
        if prev is None:
            os.environ.pop("TNS_ADMIN", None)
        else:
            os.environ["TNS_ADMIN"] = prev


def _open_oracle_oracledb_connection(config: OracleConnectionConfig) -> DBAPIConnection:
    import oracledb

    dsn = _dsn_for_oracledb(config)
    logger.info(
        "Opening Oracle connection via oracledb (thin) dsn=%s host=%s",
        dsn if config.oracle_connection_mode == OracleConnectionMode.BASIC else "<non-basic>",
        config.host,
    )

    connect_kwargs: dict[str, Any] = {
        "user": config.username,
        "password": config.password,
        "dsn": dsn,
    }
    wallet_dir = config.wallet_directory
    if wallet_dir and str(wallet_dir).strip():
        connect_kwargs["wallet_location"] = str(wallet_dir).strip()
    wallet_pw = config.wallet_password
    if wallet_pw is not None and str(wallet_pw).strip():
        connect_kwargs["wallet_password"] = str(wallet_pw).strip()

    if config.extra_options:
        logger.debug(
            "Oracle oracledb path ignores ODBC-only extra_options: %s",
            tuple(config.extra_options.keys()),
        )

    tns_admin = config.tns_admin if isinstance(config.tns_admin, str) else None
    if tns_admin and str(tns_admin).strip():
        conn = _oracledb_connect_with_optional_tns_admin(connect_kwargs, str(tns_admin).strip())
    else:
        conn = oracledb.connect(**connect_kwargs)

    try:
        conn.autocommit = True
    except AttributeError:
        pass
    return conn  # type: ignore[no-any-return]


# Serialise TNS_ADMIN mutations so concurrent workers sharing the same process
# cannot race and pick up a wrong TNS_ADMIN value (pyodbc path only).
_TNS_ADMIN_LOCK = threading.Lock()


def _connect_with_retry(
    fn: Callable[[], DBAPIConnection],
    max_attempts: int = 3,
    delay: float = 1.0,
    multiplier: float = 2.0,
) -> DBAPIConnection:
    """
    Call ``fn()`` up to ``max_attempts`` times with exponential back-off.

    Args:
        fn: Zero-argument callable that opens and returns a connection.
        max_attempts: Maximum number of attempts before re-raising.
        delay: Initial wait in seconds between attempts.
        multiplier: Factor applied to ``delay`` after each failure.

    Returns:
        The connection returned by ``fn``.

    Raises:
        Exception: The last exception raised by ``fn`` after all attempts are exhausted.

    """
    last_exc: Exception | None = None
    current_delay = delay
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except Exception as exc:
            last_exc = exc
            if attempt < max_attempts:
                logger.warning(
                    "Oracle connect attempt %d/%d failed (%s); retrying in %.1fs",
                    attempt,
                    max_attempts,
                    exc,
                    current_delay,
                )
                time.sleep(current_delay)
                current_delay *= multiplier
            else:
                logger.error(
                    "Oracle connect failed after %d attempts: %s",
                    max_attempts,
                    exc,
                )
    raise last_exc  # type: ignore[misc]


def _pyodbc_connect(config: OracleConnectionConfig) -> DBAPIConnection:
    """Open a connection using ``pyodbc``, with ``ansi=True`` and ``autocommit=True``."""
    import pyodbc

    tns_admin = getattr(config, "tns_admin", None)
    tns_admin = str(tns_admin).strip() if tns_admin and str(tns_admin).strip() else None

    connection_string = config.build_connection_string()

    with _TNS_ADMIN_LOCK:
        prev = os.environ.get("TNS_ADMIN")
        if tns_admin:
            os.environ["TNS_ADMIN"] = tns_admin
            logger.debug("Set TNS_ADMIN=%s for Oracle pyodbc connection", tns_admin)
        try:
            # ansi=True avoids ORA-24374 on Oracle ODBC 19.x where SQLExecDirectW
            # (Unicode) is not fully supported on macOS.
            conn = pyodbc.connect(connection_string, ansi=True)  # type: ignore[return-value]
            # autocommit=True prevents implicit transaction state issues between
            # consecutive cursor executions.
            conn.autocommit = True
            return conn
        finally:
            if tns_admin:
                if prev is None:
                    os.environ.pop("TNS_ADMIN", None)
                else:
                    os.environ["TNS_ADMIN"] = prev


def open_oracle_connection(config: OracleConnectionConfig) -> DBAPIConnection:
    """
    Open an Oracle database connection.

    When ``config.oracledb_preferred`` is ``True`` (default), tries ``oracledb``
    first if :func:`is_oracledb_available` is true, otherwise falls back to
    ``pyodbc``. If the thin connection fails, falls back to ``pyodbc``.
    When ``oracledb_preferred`` is ``False``, uses ``pyodbc`` only.

    Both successful paths use retry with exponential back-off.

    ``pyodbc`` path extras:

    - ``ansi=True`` to avoid ORA-24374 on Oracle ODBC 19.x on macOS.
    - ``autocommit=True`` to prevent implicit transaction state issues.
    - Thread-safe ``TNS_ADMIN`` mutation via a module-level lock.

    Args:
        config: Oracle connection configuration from TOML / registry.

    Returns:
        A DB-API 2.0 connection.

    Raises:
        ConnectionError: If no driver path can establish a connection.

    """
    oracledb_preferred = getattr(config, "oracledb_preferred", True)

    def _pyodbc_with_retry() -> DBAPIConnection:
        return _connect_with_retry(lambda: _pyodbc_connect(config))

    if not oracledb_preferred:
        try:
            return _pyodbc_with_retry()
        except Exception as exc:
            raise ConnectionError(f"Failed to open Oracle connection: {exc}") from exc

    if not is_oracledb_available():
        logger.debug("oracledb not installed; using Oracle ODBC (pyodbc)")
        try:
            return _pyodbc_with_retry()
        except Exception as exc:
            raise ConnectionError(f"Failed to open Oracle connection: {exc}") from exc

    try:
        return _connect_with_retry(lambda: _open_oracle_oracledb_connection(config))
    except Exception as oracledb_exc:
        logger.warning("oracledb connection failed (%s); falling back to pyodbc", oracledb_exc)
        try:
            return _pyodbc_with_retry()
        except Exception as exc:
            raise ConnectionError(f"Failed to open Oracle connection: {exc}") from exc


# Backward-compatible alias used by open_source_connection.
open_oracle_odbc_connection = open_oracle_connection
