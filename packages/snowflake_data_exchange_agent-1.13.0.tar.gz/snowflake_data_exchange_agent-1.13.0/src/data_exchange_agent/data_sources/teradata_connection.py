"""
Teradata connection factory with auto-detection of teradatasql.

Tries the pure-Python ``teradatasql`` driver first (no ODBC install required).
Falls back to ``pyodbc`` with an ODBC connection string when ``teradatasql``
is not available.  Both drivers are DB-API 2.0 compliant, so the returned
connection object exposes the same cursor interface.

Oracle uses the same pattern in
:mod:`data_exchange_agent.data_sources.oracle_connection` (``oracledb``
preferred, ODBC fallback).
"""

from __future__ import annotations

import functools
import logging

from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, Protocol


if TYPE_CHECKING:
    from data_exchange_agent.config.sections.connections.dialects.teradata import (
        TeradataConnectionConfig,
    )
    from data_exchange_agent.config.sections.connections.transports.odbc.base import (
        BaseODBCConnectionConfig,
    )

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# DB-API 2.0 structural protocols
# ---------------------------------------------------------------------------


class DBAPICursor(Protocol):
    """
    Structural type for a DB-API 2.0 cursor.

    Covers the subset of the spec used by ODBCDataSource and
    DataValidationHandler (execute, fetch*, description, arraysize).
    Both ``pyodbc.Cursor`` and ``teradatasql`` cursors satisfy this.
    """

    arraysize: int
    description: Sequence[tuple[str, ...]] | None

    def execute(self, operation: str, /) -> None: ...  # noqa: D102
    def fetchone(self) -> tuple[Any, ...] | None: ...  # noqa: D102
    def fetchall(self) -> list[tuple[Any, ...]]: ...  # noqa: D102
    def fetchmany(self, size: int = ..., /) -> list[tuple[Any, ...]]: ...  # noqa: D102
    def close(self) -> None: ...  # noqa: D102


class DBAPIConnection(Protocol):
    """
    Structural type for a DB-API 2.0 connection.

    Covers ``cursor()``, ``close()``, and the ``autocommit`` attribute
    used by the Teradata DDL path.  Both ``pyodbc.Connection`` and
    ``teradatasql.TeradataConnection`` satisfy this.
    """

    autocommit: bool

    def cursor(self) -> DBAPICursor: ...  # noqa: D102
    def close(self) -> None: ...  # noqa: D102


# ---------------------------------------------------------------------------
# Runtime helpers
# ---------------------------------------------------------------------------


@functools.lru_cache(maxsize=1)
def is_teradatasql_available() -> bool:
    """Return True if the ``teradatasql`` package can be imported."""
    try:
        import teradatasql  # noqa: F401

        return True
    except ImportError:
        return False


def open_teradata_connection(config: TeradataConnectionConfig) -> DBAPIConnection:
    """
    Open a Teradata connection, preferring teradatasql over pyodbc.

    Args:
        config: Teradata connection configuration (carries host, user,
                password, database and the ODBC connection string as fallback).

    Returns:
        A DB-API 2.0 connection (either ``teradatasql.TeradataConnection``
        or ``pyodbc.Connection``).

    """
    if is_teradatasql_available():
        import teradatasql

        host = config.dbc_name if config.dbc_name is not None else config.host
        logger.info(
            "Opening Teradata connection via teradatasql (native) to %s",
            host,
        )
        conn = teradatasql.connect(
            host=host,
            dbs_port=str(config.port),
            user=config.username,
            password=config.password,
            database=config.database or "DBC",
            logmech="TD2",
        )
        conn.autocommit = True
        return conn  # type: ignore[return-value]

    import pyodbc

    logger.info(
        "teradatasql not available; falling back to ODBC for %s",
        config.host,
    )
    conn = pyodbc.connect(config.connection_string)
    # Teradata requires COMMIT after DDL (CREATE VOLATILE TABLE).
    # Without autocommit pyodbc uses implicit transactions, causing
    # error -3932 on the statement following the DDL.
    conn.autocommit = True
    return conn  # type: ignore[return-value]


def open_source_connection(engine: str, config: BaseODBCConnectionConfig) -> DBAPIConnection:
    """
    Open a source database connection using the appropriate driver.

    For Teradata, delegates to :func:`open_teradata_connection` (teradatasql
    preferred, ODBC fallback). For Oracle, delegates to
    :func:`data_exchange_agent.data_sources.oracle_connection.open_oracle_connection`
    (oracledb preferred, ODBC fallback). For all other engines, connects via pyodbc.

    Args:
        engine: Engine identifier (e.g. ``"teradata"``, ``"oracle"``, ``"sqlserver"``).
        config: The connection configuration for *engine*.

    Returns:
        A DB-API 2.0 connection.

    """
    from data_exchange_agent.data_sources.database_engines import DatabaseEngine

    if engine == DatabaseEngine.TERADATA:
        td_config: TeradataConnectionConfig = config  # type: ignore[assignment]
        return open_teradata_connection(td_config)

    if engine == DatabaseEngine.ORACLE:
        from data_exchange_agent.data_sources.oracle_connection import (
            open_oracle_connection,
        )

        return open_oracle_connection(config)  # type: ignore[arg-type]

    import pyodbc

    return pyodbc.connect(config.connection_string)  # type: ignore[return-value]


def is_pyodbc_connection(conn: DBAPIConnection) -> bool:
    """Return True if *conn* is a ``pyodbc.Connection`` instance."""
    try:
        import pyodbc

        return isinstance(conn, pyodbc.Connection)
    except ImportError:
        return False
