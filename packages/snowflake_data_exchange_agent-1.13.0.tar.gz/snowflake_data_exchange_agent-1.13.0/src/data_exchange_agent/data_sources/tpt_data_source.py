"""
Teradata Parallel Transporter (TPT) data source implementation.

Used when the orchestrator emits a task with ``target_type = "tpt"``.
The worker introspects column names, builds a TPT EXPORT script, runs
``tbuild``, converts delimited output to Parquet, then uploads like ODBC.

The Parquet filename follows ``{base_file_name}_001.parquet`` like
:class:`~data_exchange_agent.data_sources.odbc_data_source.ODBCDataSource`.
"""

from __future__ import annotations

import datetime as dt
import os
import shutil
import subprocess
import tempfile
import uuid

from typing import TYPE_CHECKING, Any

from dependency_injector.wiring import Provide, inject

from data_exchange_agent.constants import config_keys, container_keys
from data_exchange_agent.data_sources.base import BaseDataSource
from data_exchange_agent.utils.sf_logger import SFLogger


# Lazy imports avoid circular import via ``data_sources/__init__.py``.
if TYPE_CHECKING:
    from data_exchange_agent.config.manager import ConfigManager
    from data_exchange_agent.config.sections.connections.dialects.teradata import (
        TeradataConnectionConfig,
        TptConfig,
    )


_DEFAULT_TBUILD_EXECUTABLE = "tbuild"
_MAX_JOB_NAME_LEN = 30

# Teradata caps a row at ~64 KB across all columns.  We size each VARCHAR column
# so the *declared* row width stays below this cap (the actual data is far smaller
# but Teradata rejects the SELECT with RDBMS error 3798 if the declared row size
# exceeds the limit, so per-column widths must be picked relative to column count).
_TPT_ROW_BUDGET_CHARS = 60000
_TPT_PER_COLUMN_MAX = 8000
_TPT_PER_COLUMN_MIN = 256


def _compute_export_varchar_width(num_columns: int) -> int:
    """Per-column ``VARCHAR(N)`` width that keeps the row under Teradata's ~64 KB cap."""
    n = max(1, num_columns)
    width = _TPT_ROW_BUDGET_CHARS // n
    return max(_TPT_PER_COLUMN_MIN, min(_TPT_PER_COLUMN_MAX, width))


def _resolve_tbuild_executable() -> str:
    """Return the configured ``tbuild`` executable path."""
    return os.environ.get("TPT_TBUILD_EXECUTABLE") or _DEFAULT_TBUILD_EXECUTABLE


def _safe_job_name(base_file_name: str) -> str:
    """Build a TPT-safe job name from ``base_file_name``."""
    cleaned = "".join(c if c.isalnum() else "_" for c in base_file_name).strip("_")
    if not cleaned:
        cleaned = "EXPORT"
    cleaned = cleaned.upper()[:_MAX_JOB_NAME_LEN]
    return f"DEA_{cleaned}"


def _quote_for_tpt(value: str) -> str:
    """Escape a value for inclusion inside a TPT single-quoted attribute."""
    return value.replace("'", "''")


def _quote_teradata_identifier(name: str) -> str:
    """Double-quote a Teradata column name; double any embedded quote characters."""
    return '"' + str(name).replace('"', '""') + '"'


def _expand_two_digit_year(year: int) -> int:
    """Map Teradata-style 2-digit years to a 4-digit calendar year."""
    if year >= 100:
        return year
    return 2000 + year if year < 70 else 1900 + year


def _parse_tpt_date_string(value: str) -> dt.date:
    """Parse a Teradata TPT delimited date (``YY/MM/DD`` or ``YYYY-MM-DD``)."""
    text = value.strip()
    if not text:
        raise ValueError("Empty date value")

    if "-" in text:
        for fmt in ("%Y-%m-%d", "%y-%m-%d"):
            try:
                return dt.datetime.strptime(text, fmt).date()
            except ValueError:
                continue

    if "/" in text:
        parts = text.split("/")
        if len(parts) == 3:
            year, month, day = (int(part) for part in parts)
            return dt.date(_expand_two_digit_year(year), month, day)

    raise ValueError(f"Unrecognized TPT date value: {value!r}")


def _parse_tpt_time_string(value: str) -> dt.time:
    """Parse a Teradata TPT delimited time (``HH:MM:SS`` or with fractional seconds)."""
    text = value.strip()
    for fmt in ("%H:%M:%S.%f", "%H:%M:%S"):
        try:
            return dt.datetime.strptime(text, fmt).time()
        except ValueError:
            continue
    raise ValueError(f"Unrecognized TPT time value: {value!r}")


def _parse_tpt_timestamp_string(value: str) -> dt.datetime:
    """Parse a Teradata TPT delimited timestamp (``YY/MM/DD HH:MM:SS[.fff]``)."""
    text = value.strip()
    if not text:
        raise ValueError("Empty timestamp value")
    if " " in text:
        date_part, time_part = text.split(" ", 1)
    else:
        date_part, time_part = text, "00:00:00"
    return dt.datetime.combine(_parse_tpt_date_string(date_part), _parse_tpt_time_string(time_part))


class TptDataSource(BaseDataSource):
    """Run a Teradata TPT export job and emit a Parquet file."""

    @property
    def statement(self) -> str:
        """The SELECT query wrapped by the TPT EXPORT operator."""
        return self._statement

    @property
    def results_folder_path(self) -> str:
        """The path to the results folder (TPT writes intermediate files here)."""
        return self._results_folder_path

    @property
    def base_file_name(self) -> str:
        """The base file name used for the Parquet artifact."""
        return self._base_file_name

    @inject
    def __init__(  # pylint: disable=unused-argument
        self,
        engine: str,
        statement: str,
        results_folder_path: str | None = None,
        base_file_name: str = "result",
        suggested_batch_size: int | None = None,
        database: str | None = None,
        use_database_command: str | None = None,
        logger: SFLogger = Provide[container_keys.SF_LOGGER],
        program_config: ConfigManager = Provide[container_keys.PROGRAM_CONFIG],
    ) -> None:
        """
        Initialize a new TptDataSource.

        Args:
            engine: Database engine type (must be ``teradata``).
            statement: The SELECT query to export via TPT.
            results_folder_path: Local directory where the Parquet artifact is written.
            base_file_name: Prefix for the generated Parquet file.
            suggested_batch_size: Unused (interface compatibility).
            database: Default database name (API compatibility).
            use_database_command: Optional ``DATABASE`` command for column probe.
            logger: The logger instance.
            program_config: The program configuration manager.

        """
        from data_exchange_agent.config.sections.connections.dialects.teradata import (
            TeradataConnectionConfig,
        )

        self.logger: SFLogger = logger
        self._statement = statement
        self._results_folder_path = results_folder_path or ""
        self._base_file_name = base_file_name
        self._use_database_command = use_database_command

        source_connections_config: dict[str, Any] = program_config[config_keys.CONNECTIONS__SOURCE]
        connection_config = source_connections_config.get(engine)
        if not isinstance(connection_config, TeradataConnectionConfig):
            raise ValueError(
                "TptDataSource requires a TeradataConnectionConfig for engine " f"'{engine}', got {type(connection_config).__name__}"
            )
        if connection_config.tpt_config is None:
            raise ValueError(
                "TPT extraction strategy requires TPT configuration in the DEA "
                "config.  Add 'tpt_output_directory' (and optionally "
                "'tpt_delimiter', 'tpt_max_sessions', 'tpt_charset', "
                "'tpt_log_directory') to the [connections.source.teradata] "
                "section."
            )

        self._connection_config: TeradataConnectionConfig = connection_config
        self._tpt_config: TptConfig = connection_config.tpt_config

    def export_data(self) -> bool:
        """Execute the TPT export job and convert its output to Parquet."""
        if not self._results_folder_path:
            raise ValueError("TptDataSource requires a non-empty results_folder_path")

        os.makedirs(self._results_folder_path, exist_ok=True)
        os.makedirs(self._tpt_config.effective_log_directory, exist_ok=True)

        column_names, column_types = self._introspect_column_schema()
        delimited_output = os.path.join(self._results_folder_path, f"{self._base_file_name}.txt")
        script_text = self._build_tpt_script(
            column_names=column_names,
            output_file_path=delimited_output,
        )

        script_path = self._write_script_to_temp_file(script_text)
        try:
            self._run_tbuild(script_path)
            try:
                self._convert_delimited_to_parquet(delimited_output, column_names, column_types)
            finally:
                try:
                    if os.path.isfile(delimited_output):
                        os.remove(delimited_output)
                except OSError:
                    self.logger.debug(f"Could not remove delimited file '{delimited_output}' after conversion.")
        finally:
            try:
                os.remove(script_path)
            except OSError:
                self.logger.debug(f"Could not remove TPT script '{script_path}' (continuing).")

        return True

    def _introspect_column_schema(
        self,
    ) -> tuple[list[str], list[Any]]:
        """Run a ``WHERE 1=0`` probe to learn column names and Arrow types."""
        from data_exchange_agent.data_sources.odbc_schema import schema_from_description
        from data_exchange_agent.data_sources.teradata_connection import (
            open_teradata_connection,
        )

        probe_query = f"SELECT * FROM ({self._statement}) AS dea_tpt_probe WHERE 1=0"
        self.logger.info("Introspecting TPT column names via probe query (no data fetched).")

        conn = open_teradata_connection(self._connection_config)
        try:
            if self._use_database_command:
                cursor = conn.cursor()
                cursor.execute(self._use_database_command)
                cursor.close()

            cursor = conn.cursor()
            try:
                cursor.execute(probe_query)
                description = cursor.description or []
            finally:
                cursor.close()
        finally:
            conn.close()

        if not description:
            raise RuntimeError("Teradata returned no column metadata for the TPT SELECT probe; " "cannot build a TPT schema.")

        column_types, column_names = schema_from_description(description)
        return column_names, column_types

    def _export_select_statement(self, column_names: list[str], varchar_width: int) -> str:
        """
        Build the SELECT embedded in the TPT EXPORT operator.

        Teradata raises **TPT12108** if the EXPORT schema (all ``VARCHAR``) does
        not match the raw types returned by the user's query, and **RDBMS 3798**
        if the total declared row size exceeds the ~64 KB row cap.  Casting every
        projected column to ``VARCHAR(varchar_width)`` (matching the schema width
        sized for the column count) aligns the stream with the schema while
        keeping the row under Teradata's limit.
        """
        inner = self._statement.strip().rstrip(";")
        cast_lines = ",\n    ".join(
            f"CAST({_quote_teradata_identifier(name)} AS VARCHAR({varchar_width})) " f"AS {_quote_teradata_identifier(name)}"
            for name in column_names
        )
        return f"SELECT\n    {cast_lines}\n" f"FROM (\n{inner}\n) AS dea_tpt_inner"

    def _build_tpt_script(
        self,
        column_names: list[str],
        output_file_path: str,
    ) -> str:
        """Build a complete TPT job script."""
        host = self._connection_config.dbc_name or self._connection_config.host
        username = self._connection_config.username
        password = self._connection_config.password
        delimiter = self._tpt_config.delimiter
        charset = self._tpt_config.charset
        max_sessions = self._tpt_config.max_sessions

        directory_path, file_name = os.path.split(output_file_path)
        if not directory_path:
            directory_path = "."

        varchar_width = _compute_export_varchar_width(len(column_names))
        schema_def = ",\n".join(f'        "{c}" VARCHAR({varchar_width})' for c in column_names)
        select_stmt = _quote_for_tpt(self._export_select_statement(column_names, varchar_width))
        job_name = _safe_job_name(self._base_file_name)

        return f"""DEFINE JOB {job_name}
DESCRIPTION 'DEA TPT export job'
(
    DEFINE SCHEMA EXPORT_SCHEMA
    (
{schema_def}
    );

    DEFINE OPERATOR EXPORT_OPERATOR
    TYPE EXPORT
    SCHEMA EXPORT_SCHEMA
    ATTRIBUTES
    (
        VARCHAR TdpId          = '{_quote_for_tpt(host)}',
        VARCHAR UserName       = '{_quote_for_tpt(username)}',
        VARCHAR UserPassword   = '{_quote_for_tpt(password)}',
        VARCHAR SelectStmt     = '{select_stmt}',
        INTEGER MaxSessions    = {max_sessions},
        VARCHAR CharSet        = '{charset}'
    );

    DEFINE OPERATOR FILE_WRITER
    TYPE DATACONNECTOR CONSUMER
    SCHEMA EXPORT_SCHEMA
    ATTRIBUTES
    (
        VARCHAR DirectoryPath  = '{_quote_for_tpt(directory_path)}',
        VARCHAR FileName       = '{_quote_for_tpt(file_name)}',
        VARCHAR Format         = 'DELIMITED',
        VARCHAR TextDelimiter  = '{delimiter}',
        VARCHAR OpenMode       = 'Write',
        VARCHAR IndicatorMode  = 'N'
    );

    APPLY TO OPERATOR (FILE_WRITER)
    SELECT * FROM OPERATOR (EXPORT_OPERATOR);
);"""

    def _write_script_to_temp_file(self, script_text: str) -> str:
        """Write the TPT script under the log directory and return its path."""
        log_dir = self._tpt_config.effective_log_directory
        os.makedirs(log_dir, exist_ok=True)
        unique = uuid.uuid4().hex[:8]
        with tempfile.NamedTemporaryFile(
            "w",
            delete=False,
            suffix=".tpt",
            prefix=f"dea_tpt_{unique}_",
            dir=log_dir,
            encoding="utf-8",
        ) as fh:
            fh.write(script_text)
            return fh.name

    def _run_tbuild(self, script_path: str) -> None:
        """Invoke ``tbuild`` with the generated script."""
        executable = _resolve_tbuild_executable()
        if shutil.which(executable) is None and not os.path.isabs(executable):
            raise RuntimeError(
                f"TPT executable '{executable}' was not found on PATH.  "
                "Install Teradata Tools and Utilities (TTU) on the worker, "
                "or set the TPT_TBUILD_EXECUTABLE environment variable to the "
                "absolute path of ``tbuild``."
            )

        job_name = _safe_job_name(self._base_file_name)
        command = [
            executable,
            "-f",
            script_path,
            "-j",
            job_name,
            "-L",
            self._tpt_config.effective_log_directory,
        ]
        self.logger.info(f"Running TPT job '{job_name}' via: {' '.join(command)}")

        completed = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
        )
        if completed.stdout:
            self.logger.debug(f"tbuild stdout:\n{completed.stdout}")
        if completed.stderr:
            self.logger.debug(f"tbuild stderr:\n{completed.stderr}")

        if completed.returncode != 0:
            raise RuntimeError(
                f"TPT job '{job_name}' failed with exit code {completed.returncode}. "
                f"Inspect logs in {self._tpt_config.effective_log_directory}.  "
                f"stderr: {completed.stderr.strip()[:500]}"
            )

        self.logger.info(f"TPT job '{job_name}' completed successfully.")

    def _coerce_tpt_string_column(
        self,
        values: Any,
        target_type: Any,
    ) -> Any:
        """Coerce a TPT VARCHAR column to the Arrow type from the ODBC probe."""
        import pyarrow as pa

        if target_type is None or pa.types.is_string(target_type):
            return values

        raw_values = values.to_pylist()
        if pa.types.is_date32(target_type):
            parsed = [None if v is None or v == "" else _parse_tpt_date_string(str(v)) for v in raw_values]
            return pa.array(parsed, type=target_type)
        if pa.types.is_timestamp(target_type):
            parsed = [None if v is None or v == "" else _parse_tpt_timestamp_string(str(v)) for v in raw_values]
            return pa.array(parsed, type=target_type)
        if pa.types.is_time64(target_type):
            parsed = [None if v is None or v == "" else _parse_tpt_time_string(str(v)) for v in raw_values]
            return pa.array(parsed, type=target_type)

        string_array = pa.array(
            [None if v is None or v == "" else str(v) for v in raw_values],
            type=pa.string(),
        )
        return string_array.cast(target_type)

    def _convert_delimited_to_parquet(
        self,
        delimited_path: str,
        column_names: list[str],
        column_types: list[Any],
    ) -> None:
        """Convert TPT's delimited output to a single Parquet file."""
        import pyarrow as pa  # local import keeps module load cheap
        import pyarrow.csv as pacsv
        import pyarrow.parquet as pq

        if not os.path.isfile(delimited_path):
            raise RuntimeError(f"TPT did not produce the expected output file '{delimited_path}'.")

        parquet_path = os.path.join(self._results_folder_path, f"{self._base_file_name}_001.parquet")
        self.logger.info(f"Converting TPT delimited output to Parquet: {delimited_path} -> {parquet_path}")

        delimiter_byte = self._tpt_config.delimiter.encode("utf-8")
        if len(delimiter_byte) != 1:
            raise ValueError("TPT delimiter must be a single byte for Parquet conversion; " f"got {self._tpt_config.delimiter!r}.")

        read_options = pacsv.ReadOptions(column_names=column_names)
        parse_options = pacsv.ParseOptions(delimiter=self._tpt_config.delimiter)
        convert_options = pacsv.ConvertOptions(
            column_types={name: pa.string() for name in column_names},
            null_values=[""],
            strings_can_be_null=True,
        )

        table = pacsv.read_csv(
            delimited_path,
            read_options=read_options,
            parse_options=parse_options,
            convert_options=convert_options,
        )

        typed_columns: list[Any] = []
        for index, name in enumerate(column_names):
            target_type = column_types[index] if index < len(column_types) else None
            typed_columns.append(self._coerce_tpt_string_column(table.column(name), target_type))

        typed_table = pa.table({column_names[i]: typed_columns[i] for i in range(len(column_names))})
        pq.write_table(typed_table, parquet_path)
