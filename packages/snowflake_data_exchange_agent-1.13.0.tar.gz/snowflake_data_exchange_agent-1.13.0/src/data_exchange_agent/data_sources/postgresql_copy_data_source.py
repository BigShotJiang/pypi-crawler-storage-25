from __future__ import annotations

import csv
import os
import subprocess
import threading

from typing import TYPE_CHECKING

from dependency_injector.wiring import Provide, inject


if TYPE_CHECKING:
    from data_exchange_agent.config.manager import ConfigManager
    from data_exchange_agent.config.sections.connections.dialects.postgresql.config import (
        PostgresqlConnectionConfig,
    )

from data_exchange_agent.constants import config_keys, container_keys
from data_exchange_agent.constants.paths import build_actual_results_folder_path
from data_exchange_agent.data_sources.base import BaseDataSource
from data_exchange_agent.utils.postgresql_psql_utils import (
    build_connection_uri,
    build_copy_command,
    mask_uri_password,
)
from data_exchange_agent.utils.sf_logger import SFLogger


class PostgresqlCopyDataSource(BaseDataSource):
    r"""
    A PostgreSQL bulk-export data source using psql.

    Runs the psql client-side `\copy` meta-command in a subprocess. Unlike SQL
    `COPY ... TO filesystem`, `\copy` streams results to CSV on the worker
    machine where psql runs, not into a server-side path on PostgreSQL hosts.

    The lifecycle mirrors ``BCPDataSource``. Output uses delimiter settings
    compatible with CSV_FILE_FORMAT (field ``\x1f``, record ``\x1e`` after an
    optional rewrite step).

    Attributes:
        statement (str): The SQL statement to execute
        results_folder_path (str): The path to the results folder
        base_file_name (str): The base file name for output files

    """

    @property
    def statement(self) -> str:
        """The statement to execute."""
        return self._statement

    @property
    def results_folder_path(self) -> str:
        """The path to the results folder."""
        return self._results_folder_path

    @property
    def base_file_name(self) -> str:
        """The base file name."""
        return self._base_file_name

    @inject
    def __init__(
        self,
        engine: str,
        statement: str,
        results_folder_path: str | None = None,
        base_file_name: str = "result",
        suggested_batch_size: int | None = None,
        database: str | None = None,
        use_database_command: str | None = None,
        logger: SFLogger = Provide[container_keys.SF_LOGGER],
        program_config: ConfigManager = Provide[container_keys.PROGRAM_CONFIG],
    ) -> None:
        """
        Initialize a new PostgresqlCopyDataSource.

        Args:
            engine (str): The database engine type
            statement (str): The SQL statement to execute
            results_folder_path (str | None): The path to the results folder. If
                None, uses the default actual results folder path
            base_file_name (str): The base file name for output files
            suggested_batch_size (int | None): Not used by this data source;
                accepted for API compatibility with other data sources
            database (str | None): Optional database name override. When
                provided, overrides the database from the connection
                configuration
            use_database_command (str | None): Optional session-level SQL
                executed on the connection before export
            logger (SFLogger): The logger instance
            program_config (ConfigManager): The program configuration manager

        """
        self.logger: SFLogger = logger
        self._statement = statement
        self._results_folder_path = (
            build_actual_results_folder_path()
            if results_folder_path is None
            else results_folder_path
        )
        self._base_file_name = base_file_name
        self._use_database_command = use_database_command

        source_map: dict[str, PostgresqlConnectionConfig] = program_config[
            config_keys.CONNECTIONS__SOURCE
        ]
        cfg = source_map[engine]
        self._host = cfg.host
        self._port = cfg.port
        self._database = database if database else cfg.database
        self._username = cfg.username
        self._password = cfg.password
        self._sslmode = cfg.ssl_mode.strip().lower() if cfg.ssl_mode and cfg.ssl_mode.strip() else None

    def export_data(self) -> bool:
        """
        Export data using psql (client-side copy to CSV on this host).

        Returns:
            bool: True if the data was exported successfully

        Raises:
            Exception: If psql is not on PATH or the subprocess exits non-zero

        """
        os.makedirs(self.results_folder_path, exist_ok=True)
        output_file = os.path.join(self.results_folder_path, f"{self.base_file_name}_001.csv")

        psql_cmd = self._build_psql_command(output_file)

        masked_cmd = mask_uri_password(psql_cmd)
        self.logger.info(f"Executing psql command: {masked_cmd}")

        # Check that psql is available
        try:
            subprocess.run(["psql", "--version"], capture_output=True, text=True, check=True)
        except (FileNotFoundError, subprocess.CalledProcessError) as e:
            raise Exception(
                "psql utility is not installed or not available in PATH. "
                "Install postgresql-client."
            ) from e

        # Run the psql process
        process = subprocess.Popen(
            psql_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )

        stdout_lines: list[str] = []
        stderr_lines: list[str] = []

        def read_stdout():
            if process.stdout is None:
                return
            for line in process.stdout:
                line = line.rstrip()
                if line:
                    self.logger.info(f"psql: {line}")
                    stdout_lines.append(line)

        def read_stderr():
            if process.stderr is None:
                return
            for line in process.stderr:
                line = line.rstrip()
                if line:
                    self.logger.error(f"psql stderr: {line}")
                    stderr_lines.append(line)

        stdout_thread = threading.Thread(target=read_stdout, daemon=True, name="psql-stdout")
        stderr_thread = threading.Thread(target=read_stderr, daemon=True, name="psql-stderr")

        stdout_thread.start()
        stderr_thread.start()

        stdout_thread.join()
        stderr_thread.join()

        return_code = process.wait()

        if return_code != 0:
            stderr_text = "\n".join(stderr_lines)
            error_message = (
                f"psql command failed with return code {return_code}.\n"
                f"Command: {masked_cmd}\n"
                f"Stderr: {stderr_text}"
            )
            self.logger.error(error_message)
            raise Exception(error_message)

        self.logger.info("PostgreSQL COPY export completed successfully.")
        self._rewrite_record_delimiter(output_file)
        return True

    def _rewrite_record_delimiter(self, file_path: str) -> None:
        r"""Re-parse exported CSV and rewrite using \x1e as record delimiter to match CSV_FILE_FORMAT."""
        tmp_path = file_path + ".tmp"
        try:
            with (
                open(file_path, encoding="utf-8", newline="") as src,
                open(tmp_path, "w", encoding="utf-8", newline="") as dst,
            ):
                reader = csv.reader(src, delimiter="\x1f", quotechar='"', doublequote=True)
                writer = csv.writer(dst, delimiter="\x1f", quotechar='"', doublequote=True, lineterminator="\x1e")
                writer.writerows(reader)
            os.replace(tmp_path, file_path)
        except Exception:
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
            raise

    def _build_psql_command(self, output_file: str) -> list[str]:
        """Build the psql command as a list for subprocess."""
        uri = build_connection_uri(
            host=self._host,
            port=self._port,
            dbname=self._database,
            user=self._username,
            password=self._password,
            sslmode=self._sslmode,
        )

        cmd = ["psql", uri, "-w"]

        # Session SQL runs first on the same connection
        if self._use_database_command:
            cmd.extend(["-c", self._use_database_command])

        # The \copy meta-command
        copy_cmd = build_copy_command(self._statement, output_file)
        cmd.extend(["-c", copy_cmd])

        return cmd
