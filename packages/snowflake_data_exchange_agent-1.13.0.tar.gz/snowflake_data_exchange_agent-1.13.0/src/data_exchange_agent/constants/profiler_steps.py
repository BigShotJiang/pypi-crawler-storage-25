"""
Canonical names for :class:`ExecutionProfiler` steps.

Every step label emitted by the DEA into the profiler's JSON profile
lives here so callers share a single source of truth and downstream
consumers (dashboards, ``QUERY_HISTORY`` joins, analytics) can key on
stable identifiers.

Values are ``kebab-case`` — compact, URL/metric friendly, and easy to
group in log aggregators without quoting.

Usage::

    from data_exchange_agent.constants import profiler_steps

    profiler.step(profiler_steps.COMPARE)
    profiler.record(profiler_steps.FETCH_SOURCE_DATA, elapsed_ms)
"""

# Data export / upload (tasks/manager.py)
RESOLVE_DATA_SOURCE = "resolve-data-source"
EXPORT_DATA = "export-data"
UPLOAD_DATA = "upload-data"

# L1 schema validation and L2 metrics validation
# (data_validation/handler.py). The fetch steps here represent the
# single-shot ``SELECT`` that pulls the schema / metrics rows for
# comparison -- one per side.
FETCH_SOURCE_DATA = "fetch-source-data"
FETCH_TARGET_DATA = "fetch-target-data"
COMPARE = "compare"
UPLOAD_RESULTS = "upload-results"

# L3 cell validation (data_validation/cell_validation.py)
CONVERT_TO_POLARS = "convert-to-polars"
CELL_COMPARISON = "cell-comparison"

# L3 row-by-row hash validation (data_validation/row_validation.py)
EXECUTE_SOURCE_QUERY = "execute-source-query"
EXECUTE_TARGET_QUERY = "execute-target-query"
FETCH_SOURCE_RESULTS = "fetch-source-results"
FETCH_TARGET_RESULTS = "fetch-target-results"
COMPARE_ROWS = "compare-rows"
WRITE_RESULTS = "write-results"
