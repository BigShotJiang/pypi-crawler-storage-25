"""Task-related constants."""

ENGINE = "engine"
DATABASE = "database"
STATEMENT = "statement"
TARGET_TYPE = "target_type"
TARGET_ID = "target_id"
ID = "id"
WORKFLOW_ID = "workflow_id"
PAYLOAD = "payload"
STATUS = "status"
DETAILS = "details"
ERROR_CODE = "error_code"
TOTAL = "total"
SUGGESTED_BATCH_SIZE = "suggested_batch_size"
IS_BULK_OPERATION = "is_bulk_operation"
USE_DATABASE_COMMAND = "use_database_command"
EXTRACTION_STRATEGY = "extraction_strategy"

# Task kind discriminator
KIND = "kind"

# Task kinds
DATA_MOVEMENT = "data_movement"
DATA_VALIDATION = "data_validation"


class ErrorCodes:
    """
    Structured error codes returned in ``TaskResult.error_code``.

    Lets the orchestrator branch on specific validation failure modes without
    having to parse the human-readable ``details`` string.
    """

    DUPLICATE_INDEX_KEYS = "DUPLICATE_INDEX_KEYS"


# Target type values (match TargetType enum in orchestrator)
class TargetTypeValues:
    """Constants for target_type field values."""

    SNOWFLAKE_STAGE = "snowflake:stage"
    S3_UNLOAD = "s3:unload"
    WRITE_NOS = "write_nos"
    TPT = "tpt"
    NONE = "none"
    S3 = "s3"
    BLOB = "blob"
