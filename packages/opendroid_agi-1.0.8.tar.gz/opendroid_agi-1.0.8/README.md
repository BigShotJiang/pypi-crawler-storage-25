<div align="center">

<img src="./docs/opendroid_hero_banner.png" alt="OpenDroid Autonomous Mobile Agent" width="800" />

<h1>📱 OpenDroid Framework </h1>
<h3> The Most Advanced, Autonomous, Single-Click Mobile Agent on Earth. </h3>

**Move over Desktop Agents. The Future of AI is Mobile.** 

[![Open Source](https://img.shields.io/badge/Open%20Source-MIT-blue.svg)](LICENSE)
[![PyPI version](https://badge.fury.io/py/opendroid-agi.svg)](#)
[![Security Layer](https://img.shields.io/badge/Security-Enterprise%20Guardrails-purple.svg)](#)
[![OS Compat](https://img.shields.io/badge/OS-Termux%20Native%20%7C%20Windows%20%7C%20Mac-blueviolet)](#)

<p>
  <a href="#quick-start-global-installation">Global PyPI Installation</a> •
  <a href="#mcp-servers--claude-code">Claude Code & Cursor</a> •
  <a href="#enterprise-scale-use-cases">Enterprise QA</a> •
  <a href="#opendroid-vs-openclaw">Why vs OpenClaw?</a>
</p>

</div>

---

## 🛑 Important Notification for AI Operators

> **Important: Zero Desktop Hardware Required**
> Frameworks like OpenClaw require you to purchase a Mac Mini to act as the Gateway. OpenDroid is explicitly engineered to compile and run natively *inside* an old Android phone via Termux. The phone acts as both the AI Brain and the Physical Hands.

> **Security Warning: Financial Asset Intercept**
> You must adhere to the `TERMS_AND_POLICIES.md`. OpenDroid is equipped with Hardcoded Financial Intercepts (`guardrails.py`). If the LLM accesses a banking app, OpenDroid will trigger a **FATAL SECURITY INTERCEPT**.

---

## ⚡ Quick Start: Global Installation 

OpenDroid is officially released as a global Python package! You can deploy it anywhere using standard pip logic without ever cloning the repository.

**Install the framework globally:**
```bash
pip install opendroid-agi
```

**Launch the Cyberpunk Terminal Interface:**
```bash
opendroid
```
*This command executes the interactive `cli.py` system, allowing you to instantly boot the 3D Dashboards, Background WhatsApp readers, or the DroidBuddy Tamagotchi right from your command line.*

### Method 2: The Native Android Pocket Server (Termux)
You want to run the whole server on an old Android phone you throw in your backpack? 

*   📥 Download [Termux](https://f-droid.org/en/packages/com.termux/) and [Termux:API](https://f-droid.org/en/packages/com.termux.api/) from F-Droid.
*   Paste this single command to bootstrap the universe:
```bash
curl -sL https://raw.githubusercontent.com/py811332-a11y/OpenDroid/main/install_termux.sh | bash
```

---

## 🤖 Real-World Command Examples

What can OpenDroid actually do? It executes human-level logic using MultiModal Vision bounding boxes.

*   `"Check my emails, summarize unread ones, and text the summary to David on WhatsApp."`
*   `"Open Uber, Ola, and Rapido. Find the cheapest fare to the Airport right now, and order it."`
*   `"Open Instagram, find the latest post from @Nike, and double tap to like."`

---

## 🔌 The MCP Server (Connect Claude Code & Cursor)

OpenDroid isn't just an isolated agent; it exposes a standardized **Model Context Protocol (MCP)** instance running on `localhost:8000`.

This means **Desktop AI systems can now touch the physical world.**
If you use tools like Anthropic's **Claude Code** terminal, **Cursor IDE**, or OpenAI **Codex**, you can write a system prompt that says:
*   *"Run the test suite. If the server crashes, use the OpenDroid MCP to physically text my smartphone and wake me up."*

---

## 🏢 Enterprise-Scale Use Cases

Why should multinational corporations deploy OpenDroid fleets instead of relying on standard test automation frameworks?

### 1. The Autonomous App Vulnerability Fuzzer (SecOps)
OpenDroid contains `vulnerability_finder.py`. You point OpenDroid at your proprietary Android App. It uses Vision AI to dynamically locate every text field. It aggressively injects malicious payloads (Cross-Site Scripting, Buffer Overflows, SQL Injections) attempting to crash the logic. It is an autonomous Android penetration-testing unit.

### 2. Physical Competitor Analysis & Scraping
Your enterprise can set up a "Device Farm" of 50 Android phones running OpenDroid `telemetry.py` arrays. You can autonomously open native competitor apps (Airbnb or Uber)—which block standard web scrapers like Puppeteer—read pricing, and dump the competitive intelligence directly to Datadog.

### 3. Native Shopify & WordPress Administration
Run `shopify_bridge.py`. OpenDroid will physically open your Android Shopify application, use Vision AI to select "Unfulfilled Orders," and process logistics manually without you ever having to configure broken REST/GraphQL webhooks.

---

## 👑 OpenDroid vs. OpenClaw

| Metric | OpenClaw | OpenDroid |
| :--- | :--- | :--- |
| **Bot Detection Override** | Fails. Cloudflare instantly detects Puppeteer instances. | **Perfect.** OS-level `adb input tap` on native Android apps. Undetectable. |
| **Hardware Required** | Minimum $500 Desktop/Mac. | **$0.** An old cracked Android phone from 2018. |
| **Communications Layer** | $100/mo Twilio API required. | **$0 Native.** `whatsapp_bridge.py` naturally intercepts Android push notifications. |
| **Tamagotchi AI Empathy** | Non-Existent. | Full SQLite `DroidBuddy` memory mapping tracks Happiness and physically jiggles your Android OS grid if it gets lonely. |

---

*Built by the Open-Source Community. The 10,000 Star Standard.*  
**Welcome to the Autonomous AGI Era.**
