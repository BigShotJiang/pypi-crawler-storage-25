import unittest
import os
from opendroid.security import PIIRedactor

class TestSecurityRedactor(unittest.TestCase):
    def setUp(self):
        self.redactor = PIIRedactor()
        
    def test_xml_parsing_graceful_fail(self):
        """If Android UI XML is corrupted, redactor should not crash the agent."""
        bad_xml = "<node> << corrupted"
        # Should return the original image path without crashing
        result = self.redactor.redact_image("dummy.png", bad_xml)
        self.assertEqual(result, "dummy.png")

if __name__ == '__main__':
    unittest.main()
