import unittest
from opendroid.core.adb import ADBController

class TestADBController(unittest.TestCase):
    """
    Standard PyTest/Unittest suite to prove to Enterprise users 
    that the core architecture is stable and regression-tested.
    """
    def setUp(self):
        # We don't want to actually click a physical device during CI testing, 
        # so in a real setup we mock the subprocess.
        self.adb = ADBController()
        
    def test_adb_initialization(self):
        """Ensure ADB Controller boots and validates methods."""
        self.assertIsNotNone(self.adb)
        
    def test_screencap_method_exists(self):
        """Ensure the vision dependency hook isn't broken."""
        self.assertTrue(hasattr(self.adb, 'screencap'))
        self.assertTrue(callable(getattr(self.adb, 'screencap')))

if __name__ == '__main__':
    unittest.main()
