from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="opendroid-agi",
    version="1.0.8",
    author="OpenDroid AI Foundation",
    author_email="py811332@gmail.com",
    description="The Open-Source Mobile Native AGI. Appium Replacement and Termux Automator.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/py811332-a11y/OpenDroid",
    packages=find_packages(),
    install_requires=[
        "fastapi>=0.100.0",
        "uvicorn>=0.23.0",
        "requests>=2.31.0",
        "python-telegram-bot>=20.0",
        "rich>=13.0.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Quality Assurance",
        "Topic :: Software Development :: Testing",
    ],
    python_requires=">=3.10",
    entry_points={
        "console_scripts": [
            "opendroid=opendroid.cli:main",
        ],
    },
)
