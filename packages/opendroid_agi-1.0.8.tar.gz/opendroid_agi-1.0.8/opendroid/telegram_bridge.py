import os
import asyncio
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from opendroid.agent import OpenDroidAgent

class TelegramBridge:
    """
    Real, functioning Telegram Bridge. Connects OpenDroid to your DMs 24/7.
    """
    def __init__(self, bot_token=None):
        self.token = bot_token or os.getenv("TELEGRAM_BOT_TOKEN")
        self.agent = OpenDroidAgent()

    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        await update.message.reply_text("🤖 OpenDroid Native Gateway Online. What can I automate for you today?")

    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        goal = update.message.text
        await update.message.reply_text(f"📱 Processing OS Intent: {goal}...")
        
        # Dispatch to the multimodal hardware agent
        try:
            # Trigger the AI to manipulate the Android phone
            self.agent.run(goal)
            
            # Read the last screenshot from the device and send it back to Telegram
            with open("./screen.png", "rb") as photo:
                await update.message.reply_photo(photo=photo, caption="✅ OS Action Completed.")
        except Exception as e:
            await update.message.reply_text(f"⚠️ AGI Hardware Error: {str(e)}")

    def start_polling(self):
        if not self.token:
            print("⚠️ [Comms] Telegram Token missing. Skipping Telegram Bridge.")
            return

        print(f"📱 [Comms] Telegram Bridge Activated. OpenDroid is listening.")
        app = ApplicationBuilder().token(self.token).build()
        app.add_handler(CommandHandler("start", self.start_command))
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
        
        app.run_polling()

if __name__ == "__main__":
    bridge = TelegramBridge()
    bridge.start_polling()
