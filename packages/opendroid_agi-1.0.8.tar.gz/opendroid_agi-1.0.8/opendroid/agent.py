import os
import json
import time
import base64
import requests
import PIL.Image

from opendroid.core.adb import ADBController
from opendroid.core.guardrails import SecurityGuardrail
from opendroid.memory import ActionMemory
from opendroid.security import PIIRedactor
from opendroid.tools.agent_tools import search_web
from opendroid.config import Config

import google.generativeai as genai
import anthropic
from openai import OpenAI

class OpenDroidAgent:
    def __init__(self, use_local_model=False):
        self.adb = ADBController()
        self.use_local_model = use_local_model
        
        self.memory = ActionMemory()
        self.redactor = PIIRedactor()
        self.guardrail = SecurityGuardrail()
        
        # Priority System: OpenAI -> Claude -> Gemini -> Local
        if self.use_local_model:
            self.active_llm = "ollama"
            self.ollama_endpoint = Config.OLLAMA_ENDPOINT
            print("💻 [Init] AI Node: Ollama/Llava (100% Offline Secured)")
            
        elif Config.OPENAI_KEY:
            self.active_llm = "openai"
            self.openai_client = OpenAI(api_key=Config.OPENAI_KEY)
            print("☁️ [Init] AI Node: OpenAI GPT-4o (Vision & Tools)")
            
        elif Config.ANTHROPIC_KEY:
            self.active_llm = "claude"
            self.anthropic_client = anthropic.Anthropic(api_key=Config.ANTHROPIC_KEY)
            print("☁️ [Init] AI Node: Anthropic Claude 3.5 Sonnet (Enterprise)")
            
        elif Config.GEMINI_KEY:
            self.active_llm = "gemini"
            genai.configure(api_key=Config.GEMINI_KEY)
            self.model = genai.GenerativeModel("gemini-1.5-pro")
            print("☁️ [Init] AI Node: Google Gemini 1.5 Pro")
        else:
            raise Exception("No API Keys found! Please configure .env or run with --local")

    def call_ollama_vision(self, prompt, b64_image):
        payload = {"model": "llava", "prompt": prompt, "images": [b64_image], "stream": False, "format": "json"}
        res = requests.post(self.ollama_endpoint, json=payload)
        res.raise_for_status()
        return res.json()["response"]

    def analyze_screen_with_vision(self, goal, chat_history=""):
        img_path = self.adb.screencap()
        xml_dump = self.adb.get_ui_dump()
        safe_img_path = self.redactor.redact_image(img_path, xml_dump)
        
        with open(safe_img_path, "rb") as f:
            b64_image = base64.b64encode(f.read()).decode('utf-8')
            
        system_prompt = f"""
        You are OpenDroid, a hyper-intelligent conversational Mobile AI Coordinator.
        Current chat history and remembered price data: {chat_history}
        User Goal: "{goal}".
        
        You have the ability to rapidly compare items across multiple apps. 
        If you need to switch apps, you can use action: open_app.
        
        Analyze the Android screen and return strict JSON for the next physical action:
        - {{"thought": "...", "action": "tap", "x": 400, "y": 150}}
        - {{"action": "open_app", "package": "com.olacabs.customer"}}
        - {{"action": "search", "query": "uber promos"}}
        - {{"action": "chat", "message": "I found the price on Uber is $15, switching to Ola to check."}}
        """
        
        print(f"🧠 {self.active_llm.title()} Core Analyzing Screen...")
        
        if self.active_llm == "ollama":
            return self.call_ollama_vision(system_prompt, b64_image)
            
        elif self.active_llm == "openai":
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": "You output strict JSON actions."},
                    {"role": "user", "content": [
                        {"type": "text", "text": system_prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64_image}"}}
                    ]}
                ],
                max_tokens=600
            )
            return response.choices[0].message.content

        elif self.active_llm == "claude":
            response = self.anthropic_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=600,
                system="You output strictly JSON actions.",
                messages=[{"role": "user", "content": [
                    {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": b64_image}},
                    {"type": "text", "text": system_prompt}
                ]}]
            )
            return response.content[0].text
            
        elif self.active_llm == "gemini":
            image = PIL.Image.open(safe_img_path)
            response = self.model.generate_content([system_prompt, image])
            return response.text

    def run(self, goal):
        print(f"🚀 Launching Conversational OpenDroid Agent...")
        chat_context = ""
        actions_taken = []
        
        for step in range(Config.MAX_AGENT_LOOPS):
            time.sleep(2)
            
            # --- 🛡️ THE MAX LEVEL SAFETY GUARDRAIL ---
            current_app = self.adb.get_current_app()
            is_safe = self.guardrail.assert_safe_environment(current_app)
            if not is_safe:
                self.adb.home() # Instantly kick it out to home screen
                print("🛑 Safety Protocol Triggered. Bailing Out.")
                break
            
            try:
                raw_json = self.analyze_screen_with_vision(goal, chat_context)
                res = raw_json.replace("```json", "").replace("```", "").strip()
                data = json.loads(res)
                
                print(f"💡 Thought: {data.get('thought')}")
                action = data.get("action")
                
                if action == "tap":
                    x, y = data.get("x", 500), data.get("y", 500)
                    print(f"👉 Tapping UI ({x}, {y})")
                    self.adb.tap(int(x), int(y))
                    
                elif action == "open_app":
                    pkg = data.get("package")
                    self.adb.open_app(pkg)
                    
                elif action == "chat":
                    msg = data.get("message", "")
                    print(f"💬 [💬 AI Chat to User]: {msg}")
                    chat_context += f"AI: {msg}\n"
                    
                elif action == "search":
                    query = data.get("query", goal)
                    chat_context += f"Search Result: {search_web(query)}\n"
                    
                elif action == "done":
                    print("✅ Sequence Complete!")
                    break 
                    
            except Exception as e:
                print(f"⚠️ Agent Overload/Error: {e}")
                break
