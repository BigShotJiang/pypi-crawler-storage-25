import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Centralized configuration object for OpenDroid Ecosystem."""
    
    # Provider API Keys
    OPENAI_KEY = os.getenv("OPENAI_API_KEY", "")
    ANTHROPIC_KEY = os.getenv("ANTHROPIC_API_KEY", "")
    GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")
    
    # Dashboard Settings
    DASHBOARD_PORT = int(os.getenv("DASHBOARD_PORT", 5173))
    API_PORT = int(os.getenv("API_PORT", 8000))
    
    # Core Engine Tuning
    VISION_DOWNSCALE_RATIO = float(os.getenv("VISION_DOWNSCALE_RATIO", 0.5))
    MAX_AGENT_LOOPS = int(os.getenv("MAX_AGENT_LOOPS", 20))
    OLLAMA_ENDPOINT = os.getenv("OLLAMA_ENDPOINT", "http://localhost:11434/api/generate")
    ACTOR_CRITIC_ENABLED = os.getenv("ACTOR_CRITIC_ENABLED", "True").lower() == "true"
