import json
import subprocess
import time
from opendroid.agent import OpenDroidAgent

class WhatsAppTermuxBridge:
    """
    NATIVE ANDROID WHATSAPP BRIDGE.
    This entirely skips expensive cloud API platforms like Twilio by leveraging 
    the native 'termux-api' framework directly on the Android OS. 
    It reads WhatsApp push notifications, processes the text, and Auto-Replies.
    """
    def __init__(self):
        self.agent = OpenDroidAgent()
        # Ensure Termux API is installed natively
        self._check_termux_api()

    def _check_termux_api(self):
        try:
            subprocess.run(["termux-info"], capture_output=True, check=True)
        except Exception:
            print("⚠️ [WARNING] Termux API strictly required for native WhatsApp interception.")

    def read_notifications(self):
        """Intersects the OS-level Android notification stream."""
        print("🎧 [WhatsApp listener] Monitoring OS Android Notification Hub...")
        try:
            result = subprocess.run(["termux-notification-list"], capture_output=True, text=True)
            notifications = json.loads(result.stdout)
            
            for notif in notifications:
                if notif.get("packageName") == "com.whatsapp":
                    title = notif.get("title", "Unknown") # Usually the Contact Name
                    content = notif.get("content", "")
                    print(f"📩 [WhatsApp] Incoming from {title}: {content}")
                    
                    if "/droid" in content.lower():
                        task = content.lower().replace("/droid", "").strip()
                        self._process_and_reply(title, task)
                        
        except Exception as e:
            print(f"Polling error: {e}")

    def _process_and_reply(self, contact, task):
        print(f"🚀 [WhatsApp-Agent] Firing Agent for '{contact}': {task}")
        # Send AGI to perform task
        self.agent.run(task)
        
        # Auto-reply physically utilizing an Android Intent
        print(f"💬 [WhatsApp-Agent] Shooting reply intent to {contact}")
        reply_text = f"Beep boop! Task completed: {task}"
        intent_cmd = [
            "am", "start", "-a", "android.intent.action.SEND", 
            "-t", "text/plain", 
            "-e", "android.intent.extra.TEXT", reply_text, 
            "--set-package", "com.whatsapp"
        ]
        # In a real environment, this opens WA chat, then ADB clicks "Send".
        subprocess.run(intent_cmd, capture_output=True)

    def start_polling(self, interval=5):
        print("🌐 WhatsApp OS-Level Bridge Online. Awaiting '/droid' commands...")
        while True:
            self.read_notifications()
            time.sleep(interval)

if __name__ == "__main__":
    bridge = WhatsAppTermuxBridge()
    bridge.start_polling()
