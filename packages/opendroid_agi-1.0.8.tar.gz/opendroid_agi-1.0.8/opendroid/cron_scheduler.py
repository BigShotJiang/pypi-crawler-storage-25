import time
from opendroid.agent import OpenDroidAgent

class CronScheduler:
    """
    Proactive AF.
    This runs 24/7 in the background on your host machine.
    """
    def __init__(self):
        self.agent = OpenDroidAgent()

    def start_heartbeat(self):
        print("💓 [Background] 24/7 Proactive Cron Scheduler Started.")
        
        while True:
            # Wake up every 4 hours
            time.sleep(60 * 60 * 4) 
            
            print("💓 [Background] Waking up. Processing Background Life Tasks.")
            # Example Proactive Action
            self.agent.run("Open Gmail, check for any urgent emails from my Boss, and text me a summary on Telegram.")
