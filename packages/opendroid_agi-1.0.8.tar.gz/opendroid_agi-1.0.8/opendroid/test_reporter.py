import xml.etree.ElementTree as ET
import time
import os

class EnterpriseTestReporter:
    def __init__(self, output_file="test_report.xml"):
        self.output_file = output_file
        self.tests = []

    def log_test(self, test_name, success, error_message=None):
        self.tests.append({
            "name": test_name,
            "success": success,
            "time": time.time(),
            "error": error_message
        })
        print(f"📊 [QA] Logged Test: {test_name} | Passed: {success}")

    def generate_junit_xml(self):
        """Generates a standard JUnit XML file for CI/CD pipelines (Jenkins, GitHub Actions)."""
        testsuites = ET.Element("testsuites")
        testsuite = ET.SubElement(testsuites, "testsuite", name="OpenDroid Automated UI Tests", tests=str(len(self.tests)))

        for test in self.tests:
            testcase = ET.SubElement(testsuite, "testcase", name=test["name"])
            if not test["success"]:
                failure = ET.SubElement(testcase, "failure", message="UI Action Failed")
                failure.text = test["error"]

        tree = ET.ElementTree(testsuites)
        tree.write(self.output_file, encoding="utf-8", xml_declaration=True)
        print(f"📁 [CI/CD] JUnit XML report generated at {self.output_file}")
