import os
import json
import hashlib

class ActionMemory:
    """
    App Memory (Fast Paths):
    When a task is successfully run with vision, we save the exact prompt hash
    to a local cache of ADB commands. Future requests skip the LLM.
    """
    def __init__(self, cache_file="./memory_cache.json"):
        self.cache_file = cache_file
        self.memory = self._load()

    def _load(self):
        if os.path.exists(self.cache_file):
            with open(self.cache_file, "r") as f:
                return json.load(f)
        return {}

    def _save(self):
        with open(self.cache_file, "w") as f:
            json.dump(self.memory, f, indent=4)

    def get_fast_path(self, goal):
        goal_hash = hashlib.md5(goal.lower().strip().encode()).hexdigest()
        return self.memory.get(goal_hash, None)

    def save_fast_path(self, goal, actions):
        goal_hash = hashlib.md5(goal.lower().strip().encode()).hexdigest()
        self.memory[goal_hash] = actions
        self._save()
        print(f"📦 [Memory] Saved Fast Path for goal: '{goal}'")
