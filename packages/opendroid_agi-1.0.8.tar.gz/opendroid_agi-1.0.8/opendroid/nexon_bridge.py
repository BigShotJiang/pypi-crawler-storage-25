import requests
import json
from fastapi import FastAPI
from pydantic import BaseModel
from opendroid.agent import OpenDroidAgent

app = FastAPI()
agent = OpenDroidAgent()

class NexonCommand(BaseModel):
    goal: str
    require_screenshot: bool = True

@app.post("/nexon/execute")
async def execute_mobile_command(command: NexonCommand):
    """
    The secure Webhook that NEXON calls when it needs a physical mobile action performed.
    """
    print(f"🔗 [NEXON BRIDGE] Received top-level command from NEXON Ambient Core: '{command.goal}'")
    
    # Delegate the heavy lifting to the OpenDroid Vision/ADB loop
    try:
        agent.run(command.goal)
        
        # After execution, send a success signal back to the NEXON brain
        return {
            "status": "success",
            "message": f"Mobile action completed for: {command.goal}",
            "screenshot_path": "./screen.png" if command.require_screenshot else None
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}

if __name__ == "__main__":
    import uvicorn
    # Boots the bridge on port 8000 so NEXON (running on 18789) can talk to it seamlessly.
    print("🔌 Starting OpenDroid <-> NEXON Bridge on port 8000...")
    uvicorn.run(app, host="127.0.0.1", port=8000)
