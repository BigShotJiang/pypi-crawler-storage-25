﻿"""Branding, theme constants, and interactive UI helpers for the provenant CLI."""

from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import click
from rich.console import Console, Group
from rich.panel import Panel
from rich.progress import ProgressColumn, Task
from rich.prompt import Prompt
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from provenant.core.ingestion.languages.registry import REGISTRY as _LANG_REGISTRY

# ---------------------------------------------------------------------------
# Brand / theme
# ---------------------------------------------------------------------------

BRAND = "#7C3AED"
BRAND_STYLE = f"bold {BRAND}"
DIM = "dim"
OK = "green"
WARN = "yellow"
ERR = "bold red"

# ---------------------------------------------------------------------------
# ASCII-safe wordmark. Avoids box-drawing/block glyphs because Windows
# terminals often run under legacy code pages during first install.
# ---------------------------------------------------------------------------

_LOGO = (
    "   ____  _____ ____      _  _____ _   _ __  __ \n"
    "  / ___||_   _||  _ \   / \|_   _|| | | ||  \/  |\n"
    "  \___ \ | |  | |_) | / _ \ | |  | |_| || |\/| |\n"
    "   ___) || |  |  _ < / ___ \| |  |  _  || |  | |\n"
    "  |____/ |_|  |_| \_/_/   \_\_|  |_| |_||_|  |_|"
)

def _get_logo() -> str:
    return _LOGO


def print_banner(console: Console, repo_name: str | None = None) -> None:
    """Print the provenant logo, tagline, and optional repo name."""
    import sys
    import io
    from provenant.cli import __version__

    # Force UTF-8 on Windows so box/block chars render correctly
    if hasattr(sys.stdout, "buffer") and sys.stdout.encoding.lower() != "utf-8":
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

    console.print()
    console.out(_get_logo(), style=BRAND_STYLE, highlight=False)
    console.print(
        f"  [dim]codebase intelligence for developers and AI[/dim]  [dim]v{__version__}[/dim]"
    )
    if repo_name:
        console.print()
        console.print(f"  Repository: [bold]{repo_name}[/bold]")
    console.print()


# ---------------------------------------------------------------------------
# Quick repo pre-scan (fast, no AST)
# ---------------------------------------------------------------------------


@dataclass
class RepoScanInfo:
    """Lightweight repo stats collected before mode selection."""

    total_files: int = 0
    language_counts: dict[str, int] = field(default_factory=dict)
    total_commits: int = 0
    test_file_count: int = 0
    infra_file_count: int = 0
    submodule_count: int = 0
    large_dirs: list[tuple[str, int]] = field(default_factory=list)
    """(dir_name, file_count) for dirs with >50 files - used for exclude suggestions."""


_TEST_PATTERNS = {"test_", "_test.", ".test.", "tests/", "test/", "__tests__/", "spec/"}
_INFRA_NAMES = {"dockerfile", "makefile", "jenkinsfile", "terraform", ".tf", ".sh", ".bash"}
# Derived from the centralised LanguageRegistry, supplemented with
# display-only languages (HTML, CSS) not tracked by the pipeline.
_LANG_MAP: dict[str, list[str]] = {
    spec.display_name: sorted(spec.extensions)
    for spec in _LANG_REGISTRY.all_specs()
    if spec.extensions and spec.tag != "unknown"
}
# C and C++ are shown together in the CLI scan
_LANG_MAP["C/C++"] = sorted(
    (_LANG_REGISTRY.get("c") or _LANG_REGISTRY.get("cpp")).extensions  # type: ignore[union-attr]
    | (_LANG_REGISTRY.get("cpp") or _LANG_REGISTRY.get("c")).extensions  # type: ignore[union-attr]
)
_LANG_MAP.pop("C", None)
_LANG_MAP.pop("C++", None)
# Display-only languages not in the pipeline
_LANG_MAP["HTML"] = [".html", ".htm"]
_LANG_MAP["CSS"] = [".css", ".scss", ".sass", ".less"]
_EXT_TO_LANG: dict[str, str] = {}
for _lang, _exts in _LANG_MAP.items():
    for _ext in _exts:
        _EXT_TO_LANG[_ext] = _lang

_SKIP_DIRS = {
    "node_modules",
    ".venv",
    "venv",
    "__pycache__",
    "dist",
    "build",
    ".next",
    "target",
    "vendor",
    ".git",
    ".hg",
    "env",
    ".tox",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
    "site-packages",
}


def quick_repo_scan(repo_path: Path) -> RepoScanInfo:
    """Fast pre-scan: count files, detect languages, count git commits.

    No AST parsing - just ``os.walk`` + extension histogram + ``git rev-list --count``.
    Typically completes in <2s even on large repos.
    """
    info = RepoScanInfo()
    dir_counts: dict[str, int] = {}

    for dirpath, dirnames, filenames in os.walk(repo_path):
        # Prune heavy/irrelevant directories in-place
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS and not d.startswith(".")]

        rel_dir = os.path.relpath(dirpath, repo_path)
        top_dir = rel_dir.split(os.sep)[0] if rel_dir != "." else "."

        for fname in filenames:
            info.total_files += 1
            lower = fname.lower()
            ext = os.path.splitext(lower)[1]

            # Language detection
            lang = _EXT_TO_LANG.get(ext)
            if lang:
                info.language_counts[lang] = info.language_counts.get(lang, 0) + 1

            # Test file detection
            full_rel = os.path.join(rel_dir, lower).replace("\\", "/")
            if any(p in full_rel for p in _TEST_PATTERNS):
                info.test_file_count += 1

            # Infra file detection
            if lower in _INFRA_NAMES or ext in _INFRA_NAMES:
                info.infra_file_count += 1

            # Track top-level dir sizes for exclude suggestions
            if top_dir != ".":
                dir_counts[top_dir] = dir_counts.get(top_dir, 0) + 1

    # Large dirs (>50 files) sorted by size
    info.large_dirs = sorted(
        [(d, c) for d, c in dir_counts.items() if c > 50],
        key=lambda x: -x[1],
    )

    # Git commit count (fast)
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", "HEAD"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            info.total_commits = int(result.stdout.strip())
    except Exception:
        pass

    # Submodule count
    gitmodules = repo_path / ".gitmodules"
    if gitmodules.exists():
        try:
            content = gitmodules.read_text(encoding="utf-8", errors="ignore")
            info.submodule_count = content.count("[submodule ")
        except Exception:
            pass

    return info


def print_scan_summary(console: Console, scan: RepoScanInfo) -> None:
    """Print a compact pre-scan summary below the banner."""
    # File count + language count
    lang_count = len(
        [
            name
            for name, c in scan.language_counts.items()
            if c > 0 and name not in ("JSON", "YAML", "Markdown", "HTML", "CSS")
        ]
    )

    parts = [f"[bold]{scan.total_files:,}[/bold] files"]
    if lang_count:
        parts.append(f"[bold]{lang_count}[/bold] languages")
    if scan.total_commits:
        parts.append(f"[bold]{scan.total_commits:,}[/bold] commits")

    header_line = " * ".join(parts)

    # Top languages (source code only, top 4)
    source_langs = {
        lang: count
        for lang, count in scan.language_counts.items()
        if lang not in ("JSON", "YAML", "Markdown", "HTML", "CSS")
    }
    total_source = sum(source_langs.values()) or 1
    top_langs = sorted(source_langs.items(), key=lambda x: -x[1])[:4]
    lang_parts = [f"{lang} {count / total_source:.0%}" for lang, count in top_langs]
    if len(source_langs) > 4:
        lang_parts.append(f"+{len(source_langs) - 4} more")
    lang_line = ", ".join(lang_parts) if lang_parts else "no source files detected"

    # Rough wall-time estimate so users know what they're committing to.
    # Calibrated against ~700-file Python+TS repos: traverse+parse+graph
    # comes in around 2 min/1k source files, plus ~1 min/100 LLM pages.
    # We surface a range, not a point, to set honest expectations.
    src_files = sum(source_langs.values()) or scan.total_files
    ingest_min = max(1, round(src_files / 500))
    ingest_max = max(2, round(src_files / 250))
    eta_line = (
        f"~{ingest_min}-{ingest_max} min ingestion"
        " * LLM generation depends on model + page count"
    )

    body = (
        f"  {header_line}\n"
        f"  [dim]{lang_line}[/dim]\n"
        f"  [dim]{eta_line}[/dim]"
    )

    console.print(
        Panel(
            body,
            border_style="dim",
            padding=(0, 1),
        )
    )
    console.print()


# ---------------------------------------------------------------------------
# Phase headers
# ---------------------------------------------------------------------------


def print_phase_header(
    console: Console,
    num: int,
    total: int,
    title: str,
    subtitle: str = "",
) -> None:
    """Print a styled phase separator."""
    console.print()
    console.print(
        Rule(
            f"[{BRAND}]Phase {num} of {total}[/] * [bold]{title}[/bold]",
            style=DIM,
        )
    )
    if subtitle:
        console.print(f"  [dim]{subtitle}[/dim]")
    console.print()


# ---------------------------------------------------------------------------
# Provider metadata - order matters (gemini first = default)
# ---------------------------------------------------------------------------

_PROVIDER_DEFAULTS: dict[str, str] = {
    "gemini": "gemini-3.1-flash-lite-preview",
    "openai": "gpt-4.1",
    "anthropic": "claude-sonnet-4-6",
    "deepseek": "deepseek-v4-flash",
    "ollama": "llama3.2",
    "openrouter": "anthropic/claude-sonnet-4.6",
    "litellm": "groq/llama-3.1-70b-versatile",
}

_PROVIDER_ENV: dict[str, str] = {
    "gemini": "GEMINI_API_KEY",
    "openai": "OPENAI_API_KEY",
    "anthropic": "ANTHROPIC_API_KEY",
    "deepseek": "DEEPSEEK_API_KEY",
    "ollama": "OLLAMA_BASE_URL",
    "openrouter": "OPENROUTER_API_KEY",
}

_PROVIDER_SIGNUP: dict[str, str] = {
    "gemini": "https://aistudio.google.com/apikey",
    "openai": "https://platform.openai.com/api-keys",
    "anthropic": "https://console.anthropic.com/settings/keys",
    "deepseek": "https://platform.deepseek.com/api_keys",
    "ollama": "https://ollama.com/download",
    "openrouter": "https://openrouter.ai/keys",
}

_MODEL_PROMPT_REJECT = {"y", "yes", "n", "no", "true", "false"}

_MODEL_DISPLAY_LIMIT = 12

_GENERATION_MODEL_EXCLUDES = (
    "embedding",
    "embed",
    "whisper",
    "tts",
    "audio",
    "image",
    "vision",
    "moderation",
    "rerank",
)

_GENERATION_MODEL_PREFIXES = (
    "gpt",
    "o1",
    "o3",
    "o4",
    "chatgpt",
    "gemini",
    "claude",
    "deepseek",
    "llama",
    "mistral",
    "qwen",
    "anthropic/",
    "openai/",
    "google/",
    "meta-llama/",
)


# ---------------------------------------------------------------------------
# .env persistence - save/load API keys in .provenant/.env
# ---------------------------------------------------------------------------


def load_dotenv(repo_path: Path) -> None:
    """Load ``<repo>/.provenant/.env`` into ``os.environ`` (without overwriting).

    Supports ``export KEY=value``, quoted values (``KEY="value"``, ``KEY='value'``),
    and inline comments (``KEY=value  # comment``).
    """
    env_file = repo_path / ".provenant" / ".env"
    if not env_file.exists():
        return
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # Support `export KEY=value`
        if line.startswith("export "):
            line = line[len("export "):].lstrip()
        if "=" not in line:
            continue
        key, _, raw_value = line.partition("=")
        key = key.strip()
        # Strip inline comments from the value (e.g. "sk-xxx  # my key")
        raw_value = raw_value.strip()
        if "#" in raw_value:
            # Only strip if # is preceded by whitespace (avoid stripping # in URLs)
            hash_idx = raw_value.find(" #")
            if hash_idx == -1:
                hash_idx = raw_value.find("\t#")
            if hash_idx >= 0:
                raw_value = raw_value[:hash_idx].rstrip()
        # Strip matching surrounding quotes
        value = _strip_quotes(raw_value)
        # Don't overwrite existing env vars (explicit env takes priority)
        if key and value and key not in os.environ:
            os.environ[key] = value


def _strip_quotes(value: str) -> str:
    """Strip one pair of matching surrounding single or double quotes."""
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
        return value[1:-1]
    return value


def _save_key_to_dotenv(repo_path: Path, env_var: str, value: str) -> None:
    """Append or update a key in ``<repo>/.provenant/.env``."""
    env_dir = repo_path / ".provenant"
    env_dir.mkdir(parents=True, exist_ok=True)
    env_file = env_dir / ".env"

    # Read existing lines
    existing_lines: list[str] = []
    found = False
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            stripped = line.strip()
            if stripped.startswith(f"{env_var}="):
                existing_lines.append(f"{env_var}={value}")
                found = True
            else:
                existing_lines.append(line)

    if not found:
        existing_lines.append(f"{env_var}={value}")

    env_file.write_text("\n".join(existing_lines) + "\n", encoding="utf-8")

    # Ensure .provenant/.env is gitignored
    _ensure_gitignored(repo_path)


def _ensure_gitignored(repo_path: Path) -> None:
    """Add ``.provenant/.env`` to ``.gitignore`` if not already present."""
    gitignore = repo_path / ".gitignore"
    pattern = ".provenant/.env"

    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
        if pattern in content:
            return
        # Append to existing file
        if not content.endswith("\n"):
            content += "\n"
        content += f"\n# provenant API keys (local)\n{pattern}\n"
        gitignore.write_text(content, encoding="utf-8")
    else:
        gitignore.write_text(
            f"# provenant API keys (local)\n{pattern}\n",
            encoding="utf-8",
        )


# ---------------------------------------------------------------------------
# Interactive mode selection
# ---------------------------------------------------------------------------


def interactive_mode_select(console: Console) -> str:
    """Let the user choose full / index-only / advanced.

    Returns ``"full"``, ``"index_only"``, or ``"advanced"``.
    """
    body = Text()
    body.append("  [1]", style=BRAND_STYLE)
    body.append("  Full documentation  ", style="bold")
    body.append("(recommended)\n", style="dim")
    body.append("       Generate wiki pages, architecture diagrams, and API\n")
    body.append("       docs using an AI provider.\n\n")

    body.append("  [2]", style=BRAND_STYLE)
    body.append("  Index only  ", style="bold")
    body.append("(no LLM, no cost)\n", style="dim")
    body.append("       Dependency graph, git history, dead code analysis.\n")
    body.append("       Perfect for MCP-powered AI coding assistants.\n\n")

    body.append("  [3]", style=BRAND_STYLE)
    body.append("  Advanced\n", style="bold")
    body.append("       Full documentation with extra configuration\n")
    body.append("       (commit limit, exclude patterns, concurrency)")

    console.print(
        Panel(
            body,
            title="[bold]How would you like to document this repo[/bold]",
            border_style=BRAND,
            padding=(1, 2),
        )
    )

    choice = Prompt.ask(
        "  Select mode",
        choices=["1", "2", "3"],
        default="1",
        console=console,
    )
    return {"1": "full", "2": "index_only", "3": "advanced"}[choice]


# ---------------------------------------------------------------------------
# Interactive provider selection (+ inline API key entry + save)
# ---------------------------------------------------------------------------


def _detect_provider_status() -> dict[str, str]:
    """Return {provider: env_var_name} for providers whose key is set."""
    status: dict[str, str] = {}
    for prov, env_var in _PROVIDER_ENV.items():
        if prov == "gemini":
            if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"):
                status[prov] = env_var
        elif os.environ.get(env_var):
            status[prov] = env_var
    return status


def _provider_secret(provider: str) -> str | None:
    if provider == "gemini":
        return os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if provider == "ollama":
        return os.environ.get("OLLAMA_BASE_URL")
    env_var = _PROVIDER_ENV.get(provider)
    return os.environ.get(env_var or "") if env_var else None


def _looks_like_generation_model(model: str) -> bool:
    m = model.lower()
    if any(token in m for token in _GENERATION_MODEL_EXCLUDES):
        return False
    return any(m.startswith(prefix) for prefix in _GENERATION_MODEL_PREFIXES)


def _sort_models_for_docs(provider: str, models: list[str], default_model: str) -> list[str]:
    seen: set[str] = set()
    filtered = []
    for model in models:
        if not model or model in seen:
            continue
        seen.add(model)
        if _looks_like_generation_model(model):
            filtered.append(model)

    if not filtered:
        filtered = [m for m in models if m and m not in seen]

    preferred_fragments = {
        "gemini": ("flash-lite", "flash", "pro"),
        "openai": ("gpt-4.1", "gpt-4o-mini", "gpt-4o", "o4-mini", "o3-mini"),
        "anthropic": ("haiku", "sonnet", "opus"),
        "deepseek": ("flash", "chat", "reasoner"),
        "openrouter": ("flash", "haiku", "mini", "sonnet"),
        "ollama": ("llama3.2", "llama3.1", "qwen", "mistral"),
    }.get(provider, ())

    def rank(model: str) -> tuple[int, str]:
        if model == default_model:
            return (0, model)
        low = model.lower()
        for idx, fragment in enumerate(preferred_fragments, 1):
            if fragment in low:
                return (idx, model)
        return (len(preferred_fragments) + 1, model)

    return sorted(filtered, key=rank)


def _list_accessible_models(provider: str) -> list[str]:
    """Best-effort model listing for providers that expose it.

    Returns an empty list when the SDK/API cannot list models. Validation
    later still catches bad custom names.
    """
    secret = _provider_secret(provider)
    if provider != "ollama" and not secret:
        return []

    try:
        if provider == "openai":
            from openai import OpenAI

            client = OpenAI(
                api_key=secret,
                base_url=os.environ.get("OPENAI_BASE_URL"),
                timeout=10.0,
            )
            return sorted(m.id for m in client.models.list().data if getattr(m, "id", None))

        if provider == "anthropic":
            from anthropic import Anthropic

            client = Anthropic(api_key=secret, timeout=10.0)
            page = client.models.list()
            return sorted(m.id for m in getattr(page, "data", []) if getattr(m, "id", None))

        if provider == "gemini":
            from google import genai

            client = genai.Client(api_key=secret)
            models = []
            for model in client.models.list():
                name = getattr(model, "name", "") or ""
                if name.startswith("models/"):
                    name = name.split("/", 1)[1]
                actions = getattr(model, "supported_actions", None) or getattr(
                    model, "supportedActions", None
                )
                if actions and "generateContent" not in actions:
                    continue
                if name:
                    models.append(name)
            return sorted(models)

        if provider == "openrouter":
            import httpx

            headers = {"Authorization": f"Bearer {secret}"} if secret else {}
            resp = httpx.get(
                "https://openrouter.ai/api/v1/models",
                headers=headers,
                timeout=10.0,
            )
            resp.raise_for_status()
            data = resp.json().get("data", [])
            return sorted(m.get("id", "") for m in data if m.get("id"))

        if provider == "deepseek":
            from openai import OpenAI

            client = OpenAI(
                api_key=secret,
                base_url=os.environ.get("DEEPSEEK_BASE_URL") or "https://api.deepseek.com",
                timeout=10.0,
            )
            return sorted(m.id for m in client.models.list().data if getattr(m, "id", None))

        if provider == "ollama":
            import httpx

            base_url = (secret or "http://localhost:11434").rstrip("/")
            resp = httpx.get(f"{base_url}/api/tags", timeout=5.0)
            resp.raise_for_status()
            return sorted(m.get("name", "") for m in resp.json().get("models", []) if m.get("name"))
    except Exception:
        return []

    return []


def prompt_model_select(
    console: Console,
    provider: str,
    default_model: str,
    model_flag: str | None,
) -> str:
    if model_flag:
        return model_flag

    console.print(
        "  [dim]Smaller is fine: Provenant is calibrated for flash-lite / nano / "
        "haiku / 8B-class Ollama. Bigger models usually cost more without "
        "improving docs.[/dim]"
    )

    with console.status("  Checking models available to this key...", spinner="dots"):
        available = _list_accessible_models(provider)

    ranked = _sort_models_for_docs(provider, available, default_model)
    shown = ranked[:_MODEL_DISPLAY_LIMIT]

    if shown:
        console.print("  Available models for this key:")
        for idx, model in enumerate(shown, 1):
            suffix = " [dim](default)[/dim]" if model == default_model else ""
            console.print(f"    [{idx}] [{BRAND}]{model}[/{BRAND}]{suffix}")
        console.print("    [custom] Type another model id")
        default_choice = str(shown.index(default_model) + 1) if default_model in shown else "1"
        while True:
            raw = click.prompt("  Select model", default=default_choice).strip()
            lowered = raw.lower()
            if lowered in _MODEL_PROMPT_REJECT:
                console.print(
                    f"  [{WARN}]Model must be a model id or a number from the list. "
                    "Press Enter to accept the default.[/]"
                )
                continue
            if raw.isdigit() and 1 <= int(raw) <= len(shown):
                return shown[int(raw) - 1]
            if raw:
                return raw

    console.print(
        f"  [dim]Could not list models. Press Enter to use the default: {default_model}[/dim]"
    )
    while True:
        model = click.prompt(f"  Model id", default=default_model).strip()
        if model.lower() in _MODEL_PROMPT_REJECT:
            console.print(
                f"  [{WARN}]Enter a model id (e.g. gpt-4o) or press Enter for default.[/]"
            )
            continue
        return model


def interactive_provider_select(
    console: Console,
    model_flag: str | None,
    *,
    repo_path: Path | None = None,
) -> tuple[str, str]:
    """Show provider table, handle selection + inline key entry + save.

    Returns ``(provider_name, model_name)``.
    """
    providers = list(_PROVIDER_ENV.keys())  # gemini first
    detected = _detect_provider_status()

    # --- provider table ---
    table = Table(
        show_header=True,
        box=None,
        padding=(0, 2),
        title="[bold]Provider Setup[/bold]",
        title_style="",
    )
    table.add_column("#", style=BRAND_STYLE, width=4)
    table.add_column("Provider", style="bold", min_width=12)
    table.add_column("Status", min_width=16)
    table.add_column("Default Model", style="dim")

    for idx, prov in enumerate(providers, 1):
        status_text = f"[{OK}]OK key set[/]" if prov in detected else "[dim]no key[/dim]"
        default_model = _PROVIDER_DEFAULTS.get(prov, "")
        # Mark gemini as recommended
        label = prov
        if prov == "gemini":
            label = f"{prov} [dim](recommended)[/dim]"
        table.add_row(f"[{idx}]", label, status_text, default_model)

    console.print()
    console.print(table)
    console.print()

    # --- selection ---
    valid_choices = [str(i) for i in range(1, len(providers) + 1)]
    # Default: first detected provider, or gemini (index 1)
    default_idx = "1"
    for idx, prov in enumerate(providers, 1):
        if prov in detected:
            default_idx = str(idx)
            break

    chosen_idx = Prompt.ask(
        "  Select provider",
        choices=valid_choices,
        default=default_idx,
        console=console,
    )
    chosen = providers[int(chosen_idx) - 1]

    # --- inline API key entry if missing ---
    if chosen not in detected:
        env_var = _PROVIDER_ENV[chosen]
        signup_url = _PROVIDER_SIGNUP.get(chosen, "")
        console.print()
        console.print(f"  [bold]{chosen}[/bold] requires [cyan]{env_var}[/cyan].")
        if signup_url:
            console.print(f"  Get your API key here: [{BRAND}]{signup_url}[/]")
        console.print()
        key = _prompt_api_key(console, chosen, env_var, repo_path=repo_path)
        if not key:
            console.print(f"  [{WARN}]Skipped. Please select another provider.[/]")
            return interactive_provider_select(console, model_flag, repo_path=repo_path)

        # If this is an OpenAI-compatible third-party key (not a real sk- key),
        # prompt for the base URL so validation routes to the right endpoint.
        if chosen == "openai" and not key.startswith("sk-"):
            console.print(
                "  [dim]This looks like a third-party OpenAI-compatible key "
                "(Fireworks, Yotta, Together, etc.).[/dim]"
            )
            base_url = click.prompt(
                "  Enter the provider base URL",
                default="",
                show_default=False,
                prompt_suffix=" (e.g. https://gateway.yottalabs.ai/api/maas): ",
            ).strip()
            if base_url:
                os.environ["OPENAI_BASE_URL"] = base_url
                if repo_path is not None and (repo_path / ".provenant" / ".env").exists():
                    _save_key_to_dotenv(repo_path, "OPENAI_BASE_URL", base_url)
                console.print(f"  [{OK}]OK Base URL set[/]")
                console.print()

    # --- model ---
    default_model = _PROVIDER_DEFAULTS.get(chosen, "")
    model = prompt_model_select(console, chosen, default_model, model_flag)

    if not model_flag and _is_flagship_model(model):
        console.print(
            f"  [{WARN}]Note:[/] [dim]'{model}' works, but flash-lite / haiku / "
            "nano produce equivalent docs at ~10x lower cost on most repos.[/]"
        )

    return chosen, model


_FLAGSHIP_MODEL_TOKENS = (
    "opus", "gpt-4o", "gpt-5", "-pro", "sonnet-4-7", "sonnet-4-6",
    "ultra", "o1", "o3",
)


def _is_flagship_model(model: str) -> bool:
    """Heuristic: True if the model name suggests a flagship-tier model."""
    if not model:
        return False
    m = model.lower()
    return any(tok in m for tok in _FLAGSHIP_MODEL_TOKENS)


def _prompt_api_key(
    console: Console,
    provider: str,
    env_var: str,
    *,
    repo_path: Path | None = None,
) -> str | None:
    """Prompt for an API key, set env var, and optionally save to .provenant/.env.

    Returns the key, or ``None`` if the user pressed Enter without typing.
    """
    key = click.prompt(
        "  Paste your API key (hidden)",
        default="",
        hide_input=True,
        show_default=False,
    )
    key = key.strip()
    if not key:
        return None

    os.environ[env_var] = key
    console.print(f"  [{OK}]OK Key set for this session[/]")

    # Offer to save for future runs
    if repo_path is not None:
        save = click.confirm(
            "  Save key to .provenant/.env for future runs? (auto-gitignored)",
            default=True,
        )
        if save:
            _save_key_to_dotenv(repo_path, env_var, key)
            console.print(f"  [{OK}]OK Saved to .provenant/.env[/]")
    console.print()

    return key


# ---------------------------------------------------------------------------
# Advanced configuration
# ---------------------------------------------------------------------------


def interactive_advanced_config(
    console: Console,
    scan: RepoScanInfo | None = None,
) -> dict[str, Any]:
    """Prompt for advanced init options, grouped into logical sections.

    When *scan* is provided, uses it for smart defaults and contextual hints
    (file counts, suggested exclude patterns, etc.).

    Returns a dict with keys matching init_command kwargs:
    ``commit_limit``, ``follow_renames``, ``skip_tests``, ``skip_infra``,
    ``concurrency``, ``exclude``, ``test_run``, ``embedder``,
    ``include_submodules``.

    Editor integration prompts are intentionally not asked here so that full and
    advanced modes stay aligned. Editor setup owns those prompts after mode
    selection.
    """
    console.print()
    console.print(
        Rule(
            f"[{BRAND}]Advanced Configuration[/]",
            style=DIM,
        )
    )

    result: dict[str, Any] = {}

    # ── Scope ─────────────────────────────────────────────────────────────
    console.print()
    console.print(f"  [{BRAND}]Scope[/]")
    console.print("  [dim]Choose what to include in the analysis[/dim]")
    console.print()

    test_hint = f" ({scan.test_file_count:,} found)" if scan and scan.test_file_count else ""
    result["skip_tests"] = click.confirm(
        f"  Skip test filesx{test_hint}",
        default=False,
    )

    infra_hint = f" ({scan.infra_file_count:,} found)" if scan and scan.infra_file_count else ""
    result["skip_infra"] = click.confirm(
        f"  Skip infrastructure filesx{infra_hint} (Dockerfile, CI, Makefile)",
        default=False,
    )

    if scan and scan.submodule_count:
        result["include_submodules"] = click.confirm(
            f"  Include git submodulesx ({scan.submodule_count} found)",
            default=False,
        )
    else:
        result["include_submodules"] = False

    # ── Exclude Patterns ──────────────────────────────────────────────────
    console.print()
    console.print(f"  [{BRAND}]Exclude Patterns[/]")

    # Show suggestions from large dirs
    if scan and scan.large_dirs:
        suggestions = scan.large_dirs[:5]
        console.print("  [dim]Large directories detected:[/dim]")
        for dirname, count in suggestions:
            console.print(f"    [dim]{dirname}/[/dim] [dim]({count:,} files)[/dim]")
        console.print()

    console.print("  [dim]Gitignore-style patterns, comma-separated or one per line.[/dim]")
    console.print("  [dim]Press Enter with empty input to finish.[/dim]")
    patterns: list[str] = []
    seen_patterns: set[str] = set()
    while True:
        raw = click.prompt("  Pattern", default="", show_default=False)
        raw = raw.strip()
        if not raw:
            break
        # Support comma-separated input; dedupe so re-pasting / re-entering
        # the same suggestions doesn't bloat the summary panel.
        for part in raw.split(","):
            part = part.strip()
            if part and part not in seen_patterns:
                seen_patterns.add(part)
                patterns.append(part)
    result["exclude"] = tuple(patterns)

    # ── Git Analysis ──────────────────────────────────────────────────────
    console.print()
    console.print(f"  [{BRAND}]Git Analysis[/]")
    commit_hint = ""
    if scan and scan.total_commits:
        commit_hint = f" [dim](repo has ~{scan.total_commits:,} total commits)[/dim]"
    console.print(f"  [dim]Controls how deeply git history is analyzed[/dim]{commit_hint}")
    console.print()

    # Smart default based on repo size
    default_limit = 500
    if scan:
        if scan.total_files < 500:
            default_limit = 1000
        elif scan.total_files > 5000:
            default_limit = 200

    val = click.prompt(
        "  Max commits per file",
        default=default_limit,
        type=int,
    )
    val = max(1, min(val, 5000))
    result["commit_limit"] = val

    result["follow_renames"] = click.confirm(
        "  Track files across git renamesx (slower but more accurate)",
        default=False,
    )

    # ── Generation ────────────────────────────────────────────────────────
    console.print()
    console.print(f"  [{BRAND}]Generation[/]")
    console.print("  [dim]LLM page generation settings[/dim]")
    console.print()

    # Smart concurrency default
    default_concurrency = 5
    if scan and scan.total_files < 200:
        default_concurrency = 8
    elif scan and scan.total_files > 5000:
        default_concurrency = 3

    result["concurrency"] = click.prompt(
        "  Max concurrent LLM calls",
        default=default_concurrency,
        type=int,
    )

    result["reasoning"] = click.prompt(
        "  Reasoning mode",
        default="auto",
        type=click.Choice(["auto", "off", "minimal"]),
    )

    # Embedder selection
    detected_embedder = _resolve_embedder_from_env()
    embedder_choices = ["gemini", "openai", "mock"]
    result["embedder"] = click.prompt(
        "  Embedder for RAG",
        default=detected_embedder,
        type=click.Choice(embedder_choices),
    )

    result["test_run"] = click.confirm(
        "  Test runx (full ingestion; LLM page generation limited to top 10 files for quick validation)",
        default=False,
    )

    # ── Summary ───────────────────────────────────────────────────────────
    console.print()
    summary = Table(box=None, padding=(0, 2), show_header=False)
    summary.add_column("Option", style="dim")
    summary.add_column("Value", style="bold")
    summary.add_row("Skip tests", "yes" if result["skip_tests"] else "no")
    summary.add_row("Skip infra", "yes" if result["skip_infra"] else "no")
    if result["include_submodules"]:
        summary.add_row("Include submodules", "yes")
    summary.add_row("Commit limit", str(result["commit_limit"]))
    summary.add_row("Follow renames", "yes" if result["follow_renames"] else "no")
    summary.add_row("Concurrency", str(result["concurrency"]))
    summary.add_row("Reasoning", result["reasoning"])
    summary.add_row("Embedder", result["embedder"])
    if patterns:
        if len(patterns) <= 5:
            summary.add_row("Exclude", ", ".join(patterns))
        else:
            # Bullet-list when many patterns - comma-joined wraps unreadably.
            summary.add_row("Exclude", "\n".join(f"- {p}" for p in patterns))
    summary.add_row("Test run", "yes" if result["test_run"] else "no")

    console.print(
        Panel(
            summary,
            title="[bold]Configuration Summary[/bold]",
            border_style=BRAND,
            padding=(0, 1),
        )
    )
    console.print()
    return result


def _resolve_embedder_from_env() -> str:
    """Auto-detect embedder from env vars (for advanced config default)."""
    if os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"):
        return "gemini"
    if os.environ.get("OPENAI_API_KEY"):
        return "openai"
    return "mock"


# ---------------------------------------------------------------------------
# Index-only confirmation screen
# ---------------------------------------------------------------------------


def print_index_only_intro(console: Console, has_provider: bool = False) -> None:
    """Show what index-only mode will do before starting."""
    lines = [
        "  [green]OK[/] Parse all source files (AST)",
        "  [green]OK[/] Build dependency graph (PageRank, communities)",
        "  [green]OK[/] Index git history (hotspots, ownership, co-changes)",
        "  [green]OK[/] Detect dead code",
        "  [green]OK[/] Extract architectural decisions",
        "  [green]OK[/] Set up MCP server for AI assistants",
    ]
    if has_provider:
        lines.append(
            "  [green]OK[/] [dim]Decision extraction enhanced (provider key detected)[/dim]"
        )
    lines.append("")
    lines.append("  [dim]No LLM calls. No cost.[/dim]")

    console.print(
        Panel(
            "\n".join(lines),
            title="[bold]Index Only[/bold]",
            border_style=BRAND,
            padding=(1, 1),
        )
    )
    console.print()


# ---------------------------------------------------------------------------
# Analysis summary panel (shown between analysis and generation)
# ---------------------------------------------------------------------------


def build_analysis_summary_panel(
    *,
    file_count: int,
    symbol_count: int,
    graph_nodes: int,
    graph_edges: int,
    dead_unreachable: int = 0,
    dead_unused: int = 0,
    dead_lines: int = 0,
    decision_count: int = 0,
    git_files: int = 0,
    hotspot_count: int = 0,
    community_count: int = 0,
    lang_summary: str = "",
) -> Panel:
    """Compact analysis-complete interstitial shown before generation."""
    lines: list[str] = []
    lines.append(
        f"  [bold]{file_count:,}[/bold] files * "
        f"[bold]{symbol_count:,}[/bold] symbols"
        + (f" * [bold]{community_count}[/bold] communities" if community_count else "")
    )
    if lang_summary:
        lines.append(f"  [dim]{lang_summary}[/dim]")
    lines.append("")
    lines.append(
        f"  Graph    [bold]{graph_nodes:,}[/bold] nodes * [bold]{graph_edges:,}[/bold] edges"
    )
    if git_files:
        lines.append(
            f"  Git      [bold]{git_files:,}[/bold] files indexed"
            + (f" * [bold]{hotspot_count}[/bold] hotspots" if hotspot_count else "")
        )
    if dead_unreachable or dead_unused:
        lines.append(
            f"  Dead     [bold]{dead_unreachable}[/bold] unreachable * "
            f"[bold]{dead_unused}[/bold] unused exports"
            + (f" * ~{dead_lines:,} lines" if dead_lines else "")
        )
    if decision_count:
        lines.append(f"  Decisions [bold]{decision_count}[/bold] extracted")

    return Panel(
        "\n".join(lines),
        title="[bold]Analysis Complete[/bold]",
        border_style=BRAND,
        padding=(1, 1),
    )


# ---------------------------------------------------------------------------
# Completion panels
# ---------------------------------------------------------------------------


def build_completion_panel(
    title: str,
    metrics: list[tuple[str, str]],
    *,
    next_steps: list[tuple[str, str]] | None = None,
) -> Panel:
    """Build a bordered summary panel.

    *metrics* is a list of ``(label, value)`` pairs.
    *next_steps* is an optional list of ``(command, description)`` pairs.
    """
    table = Table(box=None, padding=(0, 2), show_header=False)
    table.add_column("Metric", style="dim", min_width=20)
    table.add_column("Value", style="bold")

    for label, value in metrics:
        table.add_row(label, value)

    parts: list[Any] = [table]

    if next_steps:
        parts.append(Text(""))
        parts.append(Text("  What's next:", style="bold"))
        for cmd, desc in next_steps:
            parts.append(Text(f"  {cmd:<28}{desc}", style="dim"))

    return Panel(
        Group(*parts),
        title=f"[bold]{title}[/bold]",
        border_style=BRAND,
        padding=(1, 1),
    )


def build_contextual_next_steps(
    *,
    index_only: bool,
    dead_unreachable: int = 0,
    dead_unused: int = 0,
    hotspot_count: int = 0,
    decision_count: int = 0,
    top_hotspot: str = "",
) -> list[tuple[str, str]]:
    """Build next-step suggestions based on what the analysis actually found."""
    steps: list[tuple[str, str]] = []

    if index_only:
        steps.append(("provenant mcp .", "start MCP server for AI assistants"))
        steps.append(("provenant init --provider gemini", "generate full documentation"))
    else:
        steps.append(("provenant mcp .", "start MCP server for AI assistants"))
        steps.append(("provenant search <query>", "search the generated wiki"))

    if dead_unreachable + dead_unused > 0:
        steps.append(
            ("provenant dead-code", f"explore {dead_unreachable + dead_unused} dead code findings")
        )

    if hotspot_count > 0 and top_hotspot:
        steps.append((f"provenant risk {top_hotspot}", "assess risk for top hotspot"))

    if decision_count > 0:
        steps.append(("provenant decisions", f"browse {decision_count} architectural decisions"))

    if not steps:
        steps.append(("provenant mcp .", "start MCP server for AI assistants"))
        steps.append(("provenant search <query>", "search the index"))

    return steps


# ---------------------------------------------------------------------------
# Workspace: interactive repo selection
# ---------------------------------------------------------------------------


def interactive_repo_select(
    console: Console,
    repos: list[Any],
) -> list[Any]:
    """Display discovered repos and let the user pick which ones to index.

    *repos* is a list of :class:`~provenant.core.workspace.scanner.DiscoveredRepo`.
    Returns the selected subset in original order.
    """
    # Build display table
    table = Table(
        show_header=True,
        box=None,
        padding=(0, 2),
        title="[bold]Discovered Repositories[/bold]",
        title_style="",
    )
    table.add_column("#", style=BRAND_STYLE, width=4)
    table.add_column("Repository", style="bold", min_width=16)
    table.add_column("Path", style="dim", min_width=20)
    table.add_column("Status", min_width=14)

    for idx, repo in enumerate(repos, 1):
        status = f"[{OK}]indexed[/]" if repo.has_provenant else "[dim]new[/dim]"
        if repo.is_submodule:
            status += " [dim](submodule)[/dim]"
        table.add_row(f"[{idx}]", repo.name, str(repo.path.name), status)

    console.print()
    console.print(table)
    console.print()

    # Selection prompt with retry
    while True:
        raw = Prompt.ask(
            "  Select repos to index",
            default="all",
            console=console,
        )
        raw = raw.strip().lower()

        if raw == "all":
            return list(repos)
        if raw == "none":
            return []

        selected = _parse_selection(raw, len(repos))
        if selected is not None:
            return [repos[i] for i in selected]

        console.print(
            f"  [{WARN}]Invalid selection. Use numbers (1,2,3), ranges (1-3), 'all', or 'none'.[/]"
        )


def _parse_selection(raw: str, count: int) -> list[int] | None:
    """Parse a comma-separated selection string into zero-based indices.

    Supports: ``"1,2,3"``, ``"1-3"``, ``"1,3-5"``, ``"1-3,5"``.
    Returns ``None`` on invalid input.
    """
    indices: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            bounds = part.split("-", 1)
            try:
                lo, hi = int(bounds[0]), int(bounds[1])
            except ValueError:
                return None
            if lo < 1 or hi > count or lo > hi:
                return None
            indices.extend(range(lo - 1, hi))
        else:
            try:
                num = int(part)
            except ValueError:
                return None
            if num < 1 or num > count:
                return None
            indices.append(num - 1)

    if not indices:
        return None

    # Deduplicate while preserving order
    seen: set[int] = set()
    result: list[int] = []
    for i in indices:
        if i not in seen:
            seen.add(i)
            result.append(i)
    return result


def interactive_primary_select(
    console: Console,
    repos: list[Any],
) -> str:
    """Ask which repo is the primary/default. Returns the alias.

    *repos* is the list of selected :class:`DiscoveredRepo` objects.
    """
    if len(repos) == 1:
        return repos[0].alias

    console.print()
    for idx, repo in enumerate(repos, 1):
        console.print(f"  [{BRAND_STYLE}][{idx}][/] {repo.name}")
    console.print()

    choices = [str(i) for i in range(1, len(repos) + 1)]
    chosen = Prompt.ask(
        "  Which is your primary repox",
        choices=choices,
        default="1",
        console=console,
    )
    return repos[int(chosen) - 1].alias


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------


def format_elapsed(seconds: float) -> str:
    """Format seconds as ``Xm Ys`` or ``X.Ys``."""
    if seconds >= 60:
        m = int(seconds) // 60
        s = int(seconds) % 60
        return f"{m}m {s}s"
    return f"{seconds:.1f}s"


# ---------------------------------------------------------------------------
# Rich progress helpers
# ---------------------------------------------------------------------------


class MaybeCountColumn(ProgressColumn):
    """Progress column that shows ``completed/total`` when total is known,
    or just ``completed`` when total is ``None`` (indeterminate phase).

    This prevents the ugly ``1214/None`` display that appears for phases
    like file traversal and dead-code detection whose total is not known
    upfront.
    """

    def render(self, task: Task) -> Text:
        if task.total is None:
            return Text(str(int(task.completed)), style="progress.download")
        return Text(
            f"{int(task.completed)}/{int(task.total)}",
            style="progress.download",
        )


# ---------------------------------------------------------------------------
# Rich progress callback - implements core ProgressCallback protocol
# ---------------------------------------------------------------------------

_PHASE_LABELS: dict[str, str] = {
    "traverse": "Discovering files",
    "parse": "Parsing source code",
    "graph": "Building dependency graph",
    "graph.imports": "  Resolving imports",
    "graph.heritage": "  Resolving inheritance",
    "graph.calls": "  Resolving call graph",
    "graph.metrics": "  Computing PageRank",
    "graph.communities": "  Detecting communities",
    "graph.flows": "  Tracing data flows",
    "git": "Reading git history",
    "co_change": "Computing co-change graph",
    "dead_code": "Detecting dead code",
    "decisions": "Extracting design decisions",
    "generation": "Generating wiki",
}


class RichProgressCallback:
    """Adapter that implements ``provenant.core.pipeline.ProgressCallback``
    using a Rich ``Progress`` instance for terminal display.

    Usage::

        from rich.progress import Progress
        with Progress(...) as progress_bar:
            callback = RichProgressCallback(progress_bar, console)
            result = run_async(run_pipeline(..., progress=callback))
    """

    def __init__(self, progress: Any, console: Console) -> None:
        self._progress = progress
        self._console = console
        self._tasks: dict[str, Any] = {}

    def on_phase_start(self, phase: str, total: int | None) -> None:
        label = _PHASE_LABELS.get(phase, f"{phase}...")
        # If phase already has a task, update its total and make visible
        if phase in self._tasks:
            self._progress.update(self._tasks[phase], total=total, visible=True)
        else:
            self._tasks[phase] = self._progress.add_task(label, total=total, visible=True, cost=0.0)

    def on_item_done(self, phase: str) -> None:
        if phase in self._tasks:
            self._progress.advance(self._tasks[phase])

    def on_phase_done(self, phase: str) -> None:
        """Mark a phase task as fully complete and hide it from the live
        display, so the phase-summary lines that follow aren't interleaved
        with stale progress bars (issue: phantom/duplicated progress bars).
        """
        task_id = self._tasks.get(phase)
        if task_id is None:
            return
        try:
            task = next(
                (t for t in self._progress.tasks if t.id == task_id), None
            )
            if task is not None and task.total is not None:
                self._progress.update(task_id, completed=task.total, visible=False)
            else:
                self._progress.update(task_id, visible=False)
        except Exception:
            pass

    def on_message(self, level: str, text: str) -> None:
        style_map = {"info": OK, "warning": WARN, "error": ERR}
        style = style_map.get(level, "")
        # Insight lines (indented with ->) get special formatting
        if text.lstrip().startswith("->"):
            line = f"  [dim]{text}[/dim]"
        elif style:
            line = f"  [{style}]{text}[/{style}]"
        else:
            line = f"  {text}"

        # Print under the Live lock so the line lands cleanly above the
        # progress region instead of interleaving with still-rendering
        # spinners (issue: phase summary lines interleaved with bars).
        live = getattr(self._progress, "live", None)
        if live is not None:
            try:
                with live._lock:
                    self._progress.console.print(line)
                self._progress.refresh()
                return
            except Exception:
                pass
        self._progress.console.print(line)

    def set_cost(self, total_cost: float) -> None:
        """Update the live cost display on all active progress tasks."""
        for task_id in self._tasks.values():
            try:
                self._progress.update(task_id, cost=total_cost)
            except Exception:
                pass
