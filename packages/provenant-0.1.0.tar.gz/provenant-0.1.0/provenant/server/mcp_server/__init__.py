"""provenant MCP Server — 7 tools for AI coding assistants.

Exposes the full provenant wiki as queryable tools via the MCP protocol.
Supports both stdio transport (Claude Code, Cursor, Cline) and SSE transport
(web-based MCP clients).

Usage:
    provenant mcp --transport stdio  # for Claude Code / Cursor / Cline
    provenant mcp --transport sse    # for web-based clients
"""

from __future__ import annotations

import sys
from typing import Any

# --- Import submodules in dependency order (triggers tool registration) ---
from provenant.server.mcp_server import _state
from provenant.server.mcp_server._helpers import (
    _build_origin_story,
    _compute_alignment,
    _get_repo,
    _is_path,
)
from provenant.server.mcp_server._server import (
    create_mcp_server,
    mcp,
    run_mcp,
)
from provenant.server.mcp_server._graph_utils import (  # used by routers/graph.py
    build_visual_context as _build_visual_context,
)
from provenant.server.mcp_server.tool_answer import provenant_ask
from provenant.server.mcp_server.tool_context import provenant_context
from provenant.server.mcp_server.tool_dead_code import provenant_dead_code
from provenant.server.mcp_server.tool_overview import provenant_overview
from provenant.server.mcp_server.tool_risk import provenant_risk
from provenant.server.mcp_server.tool_search import provenant_search
from provenant.server.mcp_server.tool_why import provenant_why

# ---------------------------------------------------------------------------
# Backward-compatible access to _state globals.
#
# Test fixtures and some internal code do:
#     import provenant.server.mcp_server as mcp_mod
#     mcp_mod._session_factory = factory        # write
#     await mcp_mod._vector_store.search(...)    # read
#
# We proxy reads via module __getattr__ (PEP 562) and writes via a custom
# module __class__ override so that all mutations go to _state.
# ---------------------------------------------------------------------------

_STATE_NAMES = frozenset(
    {
        "_session_factory",
        "_vector_store",
        "_decision_store",
        "_fts",
        "_repo_path",
        "_vector_store_ready",
        "_registry",
        "_workspace_root",
        "_cross_repo_enricher",
    }
)


def __getattr__(name: str) -> Any:
    if name in _STATE_NAMES:
        return getattr(_state, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


_Module = type(sys.modules[__name__])


class _WritableModule(_Module):
    def __setattr__(self, name: str, value: Any) -> None:
        if name in _STATE_NAMES:
            setattr(_state, name, value)
        else:
            super().__setattr__(name, value)


sys.modules[__name__].__class__ = _WritableModule

__all__ = [
    "_build_origin_story",
    "_build_visual_context",
    "_compute_alignment",
    "_get_repo",
    "_is_path",
    "create_mcp_server",
    "provenant_ask",
    "provenant_context",
    "provenant_dead_code",
    "provenant_overview",
    "provenant_risk",
    "provenant_why",
    "mcp",
    "run_mcp",
    "provenant_search",
]
