from setuptools import setup, find_packages
import pathlib

here = pathlib.Path(__file__).parent
readme = (here / "README.md").read_text(encoding="utf-8")

setup(
    name="Codexify",
    version="0.1.4",
    author="maksalmaz",
    description="Text converter with built-in hashing",
    long_description=readme,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.8",
    license="MIT",
)
