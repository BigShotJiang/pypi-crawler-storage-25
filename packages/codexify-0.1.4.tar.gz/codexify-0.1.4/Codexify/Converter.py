import string

nums = string.digits
letts = string.ascii_lowercase + string.ascii_uppercase
SUPPORTED_HASH_ALGORITHMS = ("codex32", "codex64")

class Converter:
    def __init__(self):
        self.converted = ""

    def convert_text(self, text: str):
        self.converted = ""
        for c in text:
            if c in nums:
                i = nums.index(c)
                self.converted += nums[i]
            else:
                i = None
                self.converted += c

            if i is not None and i < len(letts):
                self.converted += letts[i]
            else:
                self.converted += c

        return self.converted

    def hash_text(self, text: str, algorithm: str = "codex64") -> str:
        if algorithm == "codex32":
            return self._hash_codex32(text)
        if algorithm == "codex64":
            return self._hash_codex64(text)

        raise ValueError(
            f"Unsupported hash algorithm: {algorithm}. "
            f"Available: {', '.join(SUPPORTED_HASH_ALGORITHMS)}"
        )

    def available_hash_algorithms(self):
        return list(SUPPORTED_HASH_ALGORITHMS)

    def _hash_codex32(self, text: str) -> str:
        # FNV-1a 32-bit implemented locally without external hashing libraries.
        hash_value = 2166136261
        for byte in text.encode("utf-8"):
            hash_value ^= byte
            hash_value = (hash_value * 16777619) % (1 << 32)
        return f"{hash_value:08x}"

    def _hash_codex64(self, text: str) -> str:
        # FNV-1a 64-bit implemented locally without external hashing libraries.
        hash_value = 14695981039346656037
        for byte in text.encode("utf-8"):
            hash_value ^= byte
            hash_value = (hash_value * 1099511628211) % (1 << 64)
        return f"{hash_value:016x}"
