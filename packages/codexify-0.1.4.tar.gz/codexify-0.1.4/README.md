# Codexify

Codexify is a small Python library that converts characters in a string using a simple custom transformation.
It can be used for encoding digits, generating mixed output (letters + numbers), building your own text-processing logic, and hashing text with its own built-in algorithms.
---
### Installation
```bash
pip install codexify
```
### Usage
```python
from Codexify import *

conv = Converter()
result = conv.convert_text("a1b2c3")
hashed = conv.hash_text("hello world")

print(result)
print(hashed)
```
---
## Features

- Converts numeric characters based on their index

- Keeps non-numeric characters unchanged

- Hashes text with built-in `codex64` by default

- Supports built-in hash algorithms: `codex32` and `codex64`

- Lightweight and simple to use

### Hash Example
```python
from Codexify import Converter

conv = Converter()

print(conv.hash_text("secret"))
print(conv.hash_text("secret", "codex32"))
print(conv.available_hash_algorithms())
```
