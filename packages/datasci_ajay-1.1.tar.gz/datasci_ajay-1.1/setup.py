from setuptools import setup
from Cython.Build import cythonize

setup(
    name="datasci-ajay",
    version="1.1",
    # ext_modules=cythonize("datasci/eda.py"),
    packages=["datasci"],

    # Eska use eda.py ko .pyd me krne ke liye, jb .pyd create ho jaaye tb comment kro.
    # ext_modules=cythonize( 
    #     "datasci/eda.py",
    #     compiler_directives={
    #         'language_level': "3"
    #     }
    # ),

    install_requires=[
        "numpy",
        "pandas",
        "matplotlib",
        "seaborn"
    ],

    package_data={
        "datasci": ["*.pyd"]
    },

    include_package_data=True,

    author="Ajay Sah",
    description="EDA + Data Science utilities",
)