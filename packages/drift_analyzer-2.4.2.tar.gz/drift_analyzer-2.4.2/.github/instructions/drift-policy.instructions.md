---
applyTo: "**"
description: "Drift Policy — Bindende Arbeitsregeln für alle Dateien. MUSS gelesen werden bevor Änderungen an Drift-Code, Analyselogik, Ergebnisformaten oder Features vorgenommen werden."
---

# Drift — Policy (bindend für alle Dateioperationen)

Vollständige Policy: `POLICY.md` im Workspace-Root.
Kurzfassung der Kern-Verbote und Anforderungen:

## PFLICHT-GATE: Zulässigkeitsprüfung — immer zuerst ausführen und ausgeben

Vor jeder Umsetzung dieses Format sichtbar ausgeben:

```
### Drift Policy Gate
- Aufgabe: [Kurzbeschreibung in einem Satz]
- Zulassungskriterium erfüllt: [JA / NEIN] → [Unsicherheit / Signal / Glaubwürdigkeit / Handlungsfähigkeit / Trend / Einführbarkeit]
- Ausschlusskriterium ausgelöst: [JA / NEIN] → [falls JA: welches]
- Roadmap-Phase: [1 / 2 / 3 / 4] — blockiert durch höhere Phase: [JA / NEIN]
- Betrifft Signal/Architektur (§18): [JA / NEIN] → falls JA: Audit-Artefakte aktualisiert: [welche]
- Entscheidung: [ZULÄSSIG / ABBRUCH]
- Begründung: [ein Satz]
```

Bei **ABBRUCH**: keine Umsetzung, stattdessen Erklärung + Gegenvorschlag.
Das Gate darf **niemals übersprungen** werden.

---

## Vor jeder Änderung prüfen

**Ist die Aufgabe zulässig?** Sie muss mindestens eines erfüllen:
- reduziert eine zentrale Unsicherheit
- verbessert die Signalqualität oder Glaubwürdigkeit
- erhöht die Handlungsfähigkeit
- verbessert Trendfähigkeit oder Einführbarkeit

**Ist die Aufgabe unzulässig?** Sofort abbrechen, wenn sie ausschließlich erzeugt:
- mehr Ausgabe ohne Erkenntniswert
- mehr Komplexität ohne klaren Nutzen
- ein Feature, dessen Beitrag nicht klar benennbar ist

## Pflicht bei Code-Änderungen an Analyseergebnissen

Jedes Ergebnis/Befund benötigt zwingend:
1. technische Nachvollziehbarkeit
2. Reproduzierbarkeit  
3. eindeutige Ursachenzuordnung
4. nachvollziehbare Begründung
5. erkennbare nächste Maßnahme

Fehlt eines dieser fünf Elemente → Änderung ist **unzulässig**.

## Prioritätsbindung

Reihenfolge ist nicht verhandelbar:
`Glaubwürdigkeit > Signalpräzision > Verständlichkeit > FP/FN-Reduktion > Einführbarkeit > Trend > Features`

## Risk-Audit-Pflicht (Policy §18)

Bei Änderungen an Signalen, Input-Pfaden, Output-Kanälen oder Trust Boundaries sind Audit-Aktualisierungen **vor Merge Pflicht**:

| Änderung | Pflicht-Aktualisierung |
|----------|------------------------|
| Neues/geändertes Signal | FMEA (FP + FN Eintrag) + FTA (FT-1/FT-2 prüfen) + Risk Register |
| Neuer Input-/Output-Pfad | STRIDE (S/T/R/I/D/E für betroffene Trust Boundary) + Risk Register |
| Precision/Recall Δ > 5% | FMEA (RPNs neu berechnen) + Risk Register (Messwerte) |

Die vier Audit-Artefakte unter `audit_results/` dürfen **nicht gelöscht** werden.

## Entscheidungsdokumentation (ADR-Pflicht)

Änderungen an Signalen, Scoring-Logik, Output-Formaten oder Architektur-Boundaries erfordern ein ADR unter `decisions/` **vor** Implementierung.
Ausgenommen: Bugfixes und reine Refactorings.
Agent-Entwürfe erhalten Status `proposed` — nur der Maintainer setzt `accepted`.
Ein Agent, der signalrelevante Änderungen ohne Audit-Update vornimmt, **verletzt diese Policy**.
Pre-Push-Hook und CI erzwingen die Einhaltung automatisch.
