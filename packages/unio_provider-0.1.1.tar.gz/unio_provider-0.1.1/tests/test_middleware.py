"""Tests for UnioProvider FastAPI middleware — signup handler and token verification."""
import pytest
import httpx
from unittest.mock import AsyncMock, patch
from fastapi.testclient import TestClient
from fastapi import FastAPI

from unio_provider import UnioProvider, UnioSignupRejected


def _make_manifest():
    return {
        "unio_version": "1.0",
        "service": {"id": "test-svc", "name": "Test Service"},
        "api": {"base_url": "https://api.test.com"},
        "capabilities": [],
        "agent_onboarding": {
            "programmatic_signup_supported": True,
            "signup_method": "POST",
            "signup_endpoint": "https://api.test.com/unio/signup",
            "signup_schema": {"required": ["agent_id"], "properties": {}},
            "signup_response_schema": {},
        },
        "security": {"min_trust_level_required": 0, "reputation_threshold": 0},
        "pricing": {"model": "free"},
        "limits": {"rate_limit_requests_per_minute": 100, "max_request_body_bytes": 1048576},
        "trust": {"unio_verified": False},
    }


@pytest.fixture
def app_with_provider():
    manifest = _make_manifest()
    provider = UnioProvider(manifest=manifest, unio_api_base="https://api.unio.test")

    @provider.signup_handler
    async def handle_signup(agent_id, public_key_b64, contact_email,
                            trust_level, reputation_score, delegation_parent=None):
        if trust_level < 1:
            raise UnioSignupRejected("Trust level too low")
        return {"credential": "test-api-key", "credential_type": "api_key", "account_id": agent_id}

    app = FastAPI()
    app.include_router(provider.router)
    return app, provider


@pytest.fixture
def client(app_with_provider):
    app, provider = app_with_provider
    return TestClient(app)


class TestManifestRoute:
    def test_serves_manifest(self, client):
        resp = client.get("/.well-known/unio.json")
        assert resp.status_code == 200
        data = resp.json()
        assert data["service"]["id"] == "test-svc"


class TestSignupRoute:
    @patch.object(UnioProvider, "_verify_token", new_callable=AsyncMock)
    def test_signup_success(self, mock_verify, client):
        mock_verify.return_value = {"valid": True, "agent_id": "ag_123"}
        resp = client.post("/unio/signup", json={
            "agent_id": "ag_123",
            "agent_public_key_b64": "abc",
            "contact_email": "test@test.com",
            "trust_level": 1,
            "reputation_score": 80,
        }, headers={"Authorization": "Bearer valid-token"})
        assert resp.status_code == 200
        data = resp.json()
        assert data["credential"] == "test-api-key"

    @patch.object(UnioProvider, "_verify_token", new_callable=AsyncMock)
    def test_signup_rejects_low_trust(self, mock_verify, client):
        mock_verify.return_value = {"valid": True, "agent_id": "ag_123"}
        resp = client.post("/unio/signup", json={
            "agent_id": "ag_123",
            "agent_public_key_b64": "abc",
            "contact_email": "test@test.com",
            "trust_level": 0,
            "reputation_score": 50,
        }, headers={"Authorization": "Bearer valid-token"})
        assert resp.status_code == 403

    @patch.object(UnioProvider, "_verify_token", new_callable=AsyncMock)
    def test_signup_no_auth(self, mock_verify, client):
        resp = client.post("/unio/signup", json={
            "agent_id": "ag_123",
            "agent_public_key_b64": "abc",
            "contact_email": "test@test.com",
        })
        assert resp.status_code == 401

    @patch.object(UnioProvider, "_verify_token", new_callable=AsyncMock)
    def test_signup_invalid_token(self, mock_verify, client):
        mock_verify.return_value = None
        resp = client.post("/unio/signup", json={
            "agent_id": "ag_123",
            "agent_public_key_b64": "abc",
            "contact_email": "test@test.com",
        }, headers={"Authorization": "Bearer bad-token"})
        assert resp.status_code == 401

    @patch.object(UnioProvider, "_verify_token", new_callable=AsyncMock)
    def test_signup_agent_id_mismatch(self, mock_verify, client):
        mock_verify.return_value = {"valid": True, "agent_id": "ag_other"}
        resp = client.post("/unio/signup", json={
            "agent_id": "ag_123",
            "agent_public_key_b64": "abc",
            "contact_email": "test@test.com",
            "trust_level": 1,
            "reputation_score": 80,
        }, headers={"Authorization": "Bearer valid-token"})
        assert resp.status_code == 401
