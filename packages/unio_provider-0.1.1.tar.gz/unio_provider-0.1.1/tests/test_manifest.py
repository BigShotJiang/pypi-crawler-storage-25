"""Tests for ManifestBuilder."""
import json
import pytest
from unio_provider.manifest import ManifestBuilder, _slugify


class TestSlugify:
    def test_lowercase(self):
        assert _slugify("My Service") == "my-service"

    def test_special_chars(self):
        assert _slugify("Hello, World!") == "hello-world"

    def test_consecutive_hyphens(self):
        assert _slugify("A---B") == "a-b"

    def test_leading_trailing(self):
        assert _slugify("--test--") == "test"


class TestManifestBuilderFromOpenAPI:
    def test_basic_spec(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "Resend", "description": "Email API", "version": "v1"},
            "servers": [{"url": "https://api.resend.com"}],
            "paths": {
                "/emails": {
                    "post": {
                        "tags": ["send_email"],
                        "summary": "Send Email",
                        "description": "Send a transactional email",
                        "requestBody": {
                            "content": {
                                "application/json": {
                                    "schema": {"type": "object", "required": ["to"]}
                                }
                            }
                        },
                    }
                }
            },
        }
        builder = ManifestBuilder.from_openapi_dict(spec)
        manifest = builder.build()

        assert manifest["service"]["id"] == "resend"
        assert manifest["service"]["name"] == "Resend"
        assert manifest["api"]["base_url"] == "https://api.resend.com"
        assert manifest["api"]["openapi_url"] == "https://api.resend.com/openapi.json"
        assert len(manifest["capabilities"]) == 1
        assert manifest["capabilities"][0]["id"] == "send-email"

    def test_multiple_tags(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "My API"},
            "servers": [{"url": "https://api.example.com"}],
            "paths": {
                "/users": {
                    "get": {"tags": ["users"], "summary": "List users"},
                    "post": {"tags": ["users"], "summary": "Create user"},
                },
                "/posts": {
                    "get": {"tags": ["posts"], "summary": "List posts"},
                },
            },
        }
        builder = ManifestBuilder.from_openapi_dict(spec)
        manifest = builder.build()
        # One capability per unique tag
        cap_ids = [c["id"] for c in manifest["capabilities"]]
        assert "users" in cap_ids
        assert "posts" in cap_ids

    def test_no_servers(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "Test"},
            "paths": {},
        }
        builder = ManifestBuilder.from_openapi_dict(spec)
        manifest = builder.build()
        assert manifest["api"]["base_url"] == ""

    def test_chained_builders(self):
        spec = {
            "openapi": "3.0.0",
            "info": {"title": "Test"},
            "servers": [{"url": "https://api.test.com"}],
            "paths": {},
        }
        manifest = (ManifestBuilder.from_openapi_dict(spec)
                    .service(category="email", tags=["email"])
                    .security(min_trust_level_required=1)
                    .pricing(model="usage_based")
                    .signup_endpoint("https://api.test.com/unio/signup")
                    .build())
        assert manifest["service"]["category"] == "email"
        assert manifest["security"]["min_trust_level_required"] == 1
        assert manifest["pricing"]["model"] == "usage_based"
        assert manifest["agent_onboarding"]["signup_endpoint"] == "https://api.test.com/unio/signup"

    def test_to_json(self):
        spec = {"openapi": "3.0.0", "info": {"title": "Test"}, "paths": {}}
        builder = ManifestBuilder.from_openapi_dict(spec)
        json_str = builder.to_json()
        data = json.loads(json_str)
        assert data["service"]["id"] == "test"
