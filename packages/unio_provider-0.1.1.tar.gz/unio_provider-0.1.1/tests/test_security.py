"""Tests for trust_level and reputation_score handling in provider signup."""
import pytest
from unittest.mock import AsyncMock, patch
from fastapi.testclient import TestClient
from fastapi import FastAPI

from unio_provider import UnioProvider, UnioSignupRejected


def _make_manifest():
    return {
        "unio_version": "1.0",
        "service": {"id": "test-svc", "name": "Test Service"},
        "api": {"base_url": "https://api.test.com"},
        "capabilities": [],
        "agent_onboarding": {
            "programmatic_signup_supported": True,
            "signup_method": "POST",
            "signup_endpoint": "https://api.test.com/unio/signup",
            "signup_schema": {"required": ["agent_id"], "properties": {}},
            "signup_response_schema": {},
        },
        "security": {"min_trust_level_required": 0, "reputation_threshold": 0},
        "pricing": {"model": "free"},
        "limits": {"rate_limit_requests_per_minute": 100, "max_request_body_bytes": 1048576},
        "trust": {"unio_verified": False},
    }


class TestSecurityGating:
    @patch.object(UnioProvider, "_verify_token", new_callable=AsyncMock)
    def test_trust_level_passed_to_handler(self, mock_verify):
        """Verify trust_level and reputation_score are passed through to the handler."""
        mock_verify.return_value = {"valid": True, "agent_id": "ag_123"}
        received = {}

        manifest = _make_manifest()
        provider = UnioProvider(manifest=manifest, unio_api_base="https://api.unio.test")

        @provider.signup_handler
        async def handle_signup(agent_id, public_key_b64, contact_email,
                                trust_level, reputation_score, delegation_parent=None):
            received["trust_level"] = trust_level
            received["reputation_score"] = reputation_score
            return {"credential": "key", "credential_type": "api_key", "account_id": agent_id}

        app = FastAPI()
        app.include_router(provider.router)
        client = TestClient(app)

        client.post("/unio/signup", json={
            "agent_id": "ag_123",
            "agent_public_key_b64": "abc",
            "contact_email": "test@test.com",
            "trust_level": 2,
            "reputation_score": 75,
        }, headers={"Authorization": "Bearer token"})

        assert received["trust_level"] == 2
        assert received["reputation_score"] == 75

    @patch.object(UnioProvider, "_verify_token", new_callable=AsyncMock)
    def test_handler_can_gate_by_reputation(self, mock_verify):
        """Provider handler can reject agents with low reputation."""
        mock_verify.return_value = {"valid": True, "agent_id": "ag_123"}

        manifest = _make_manifest()
        provider = UnioProvider(manifest=manifest, unio_api_base="https://api.unio.test")

        @provider.signup_handler
        async def handle_signup(agent_id, public_key_b64, contact_email,
                                trust_level, reputation_score, delegation_parent=None):
            if reputation_score < 30:
                raise UnioSignupRejected("Reputation too low")
            return {"credential": "key", "credential_type": "api_key", "account_id": agent_id}

        app = FastAPI()
        app.include_router(provider.router)
        client = TestClient(app)

        resp = client.post("/unio/signup", json={
            "agent_id": "ag_123",
            "agent_public_key_b64": "abc",
            "contact_email": "test@test.com",
            "trust_level": 3,
            "reputation_score": 20,
        }, headers={"Authorization": "Bearer token"})
        assert resp.status_code == 403
