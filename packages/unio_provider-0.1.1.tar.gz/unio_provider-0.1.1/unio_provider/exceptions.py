"""Custom exceptions for unio-provider."""


class UnioSignupRejected(Exception):
    """Raised by a signup handler to reject an agent registration."""
    def __init__(self, reason: str = "Agent rejected"):
        self.reason = reason
        super().__init__(reason)


class UnioConfigError(Exception):
    """Raised when the provider is misconfigured."""
    pass


class InvalidManifestError(Exception):
    """Raised when the generated manifest fails schema validation."""
    pass
