"""UnioProvider — main class combining manifest, validation, and FastAPI router."""
from __future__ import annotations

from typing import Any, Callable, Awaitable

from .manifest import ManifestBuilder
from .validator import validate_manifest, validate_or_raise
from .middleware.fastapi import UnioProvider as _FastAPIProvider
from .exceptions import UnioSignupRejected, UnioConfigError, InvalidManifestError


def create_provider(
    manifest: dict[str, Any] | None = None,
    manifest_builder: ManifestBuilder | None = None,
    unio_api_base: str | None = None,
    validate: bool = True,
) -> _FastAPIProvider:
    """Create a UnioProvider from a manifest dict or ManifestBuilder.

    If validate=True, validates the manifest against the Unio schema first.
    """
    if manifest_builder is not None:
        manifest = manifest_builder.build()
    if manifest is None:
        raise UnioConfigError("Either manifest or manifest_builder must be provided")
    if validate:
        validate_or_raise(manifest)
    return _FastAPIProvider(manifest=manifest, unio_api_base=unio_api_base)
