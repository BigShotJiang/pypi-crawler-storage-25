"""HMAC-signed webhook event emitter — stub for future implementation."""
