"""Validate a generated manifest against the Unio JSON Schema."""
from __future__ import annotations

import json
from pathlib import Path

from jsonschema import Draft7Validator, ValidationError

from .exceptions import InvalidManifestError

_SCHEMA_PATH = Path(__file__).resolve().parent.parent.parent.parent / "spec" / "schema" / "v1.json"
_schema_cache: dict | None = None


def _load_schema() -> dict:
    global _schema_cache
    if _schema_cache is None:
        # Try bundled schema first, then relative path
        bundled = Path(__file__).resolve().parent / "schema" / "v1.json"
        path = bundled if bundled.exists() else _SCHEMA_PATH
        with open(path) as f:
            _schema_cache = json.load(f)
    return _schema_cache


def validate_manifest(manifest: dict) -> list[dict]:
    """Validate manifest against Unio schema. Returns list of error dicts."""
    schema = _load_schema()
    validator = Draft7Validator(schema)
    errors = []
    for err in sorted(validator.iter_errors(manifest), key=lambda e: list(e.path)):
        field = ".".join(str(p) for p in err.path) or "(root)"
        errors.append({"field": field, "message": err.message})
    return errors


def validate_or_raise(manifest: dict) -> None:
    """Validate manifest, raising InvalidManifestError if invalid."""
    errors = validate_manifest(manifest)
    if errors:
        raise InvalidManifestError(f"Manifest validation failed: {errors}")
