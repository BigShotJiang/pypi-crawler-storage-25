"""ManifestBuilder: OpenAPI 3.x → unio.json manifest generator."""
from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from .exceptions import InvalidManifestError


_SLUG_RE = re.compile(r"[^a-z0-9-]")


def _slugify(title: str) -> str:
    """Convert a title to a service slug: lowercase, hyphens, no leading/trailing hyphens."""
    slug = _SLUG_RE.sub("-", title.lower()).strip("-")
    # Remove consecutive hyphens
    while "--" in slug:
        slug = slug.replace("--", "-")
    return slug


def _method_map(openapi_method: str) -> str:
    return openapi_method.upper()


class ManifestBuilder:
    """Build a unio.json manifest from an OpenAPI 3.x spec."""

    def __init__(self) -> None:
        self._manifest: dict[str, Any] = {
            "unio_version": "1.0",
            "service": {},
            "capabilities": [],
            "api": {},
            "agent_onboarding": {
                "programmatic_signup_supported": True,
                "signup_method": "POST",
                "signup_endpoint": "",
                "signup_schema": {
                    "required": ["agent_id", "agent_public_key_b64", "contact_email"],
                    "properties": {
                        "agent_id": "ULID string — globally unique agent identifier",
                        "agent_public_key_b64": "Ed25519 public key, base64url encoded",
                        "contact_email": "Human operator email for billing and abuse",
                        "trust_level": "integer 0-3 — Unio behavioral trust score",
                        "reputation_score": "integer 0-100 — Unio aggregate reputation",
                        "delegation_parent": "optional — parent agent_id for delegated sub-agents",
                    },
                },
                "signup_response_schema": {
                    "credential": "API key — stored by agent in OS keychain, never by Unio",
                    "credential_type": "api_key | bearer_token",
                    "account_id": "Provider-side account ID",
                    "scopes": ["list of granted capability IDs"],
                },
            },
            "security": {
                "min_trust_level_required": 0,
                "reputation_threshold": 0,
                "allow_delegated_agents": True,
                "max_delegation_depth": 2,
                "rate_limit_per_agent_rpm": 100,
            },
            "pricing": {"model": "free"},
            "limits": {
                "rate_limit_requests_per_minute": 100,
                "max_request_body_bytes": 1048576,
            },
            "trust": {"unio_verified": False},
        }

    @classmethod
    def from_openapi(cls, path: str | Path) -> ManifestBuilder:
        """Read an OpenAPI 3.x spec and build a unio.json manifest."""
        path = Path(path)
        with open(path) as f:
            spec = json.load(f)
        return cls._from_spec(spec)

    @classmethod
    def from_openapi_dict(cls, spec: dict) -> ManifestBuilder:
        """Build from an already-parsed OpenAPI dict."""
        return cls._from_spec(spec)

    @classmethod
    def _from_spec(cls, spec: dict) -> ManifestBuilder:
        builder = cls()

        # Service identity
        info = spec.get("info", {})
        title = info.get("title", "unknown")
        builder._manifest["service"]["id"] = _slugify(title)
        builder._manifest["service"]["name"] = title
        builder._manifest["service"]["description"] = info.get("description", "")
        builder._manifest["service"]["homepage"] = ""
        builder._manifest["service"]["category"] = ""
        builder._manifest["service"]["tags"] = []

        # API connection
        servers = spec.get("servers", [])
        base_url = servers[0]["url"] if servers else ""
        builder._manifest["api"]["base_url"] = base_url
        builder._manifest["api"]["openapi_url"] = f"{base_url}/openapi.json"
        builder._manifest["api"]["version"] = spec.get("info", {}).get("version", "v1")
        builder._manifest["api"]["auth_header"] = "Authorization"
        builder._manifest["api"]["auth_scheme"] = "Bearer"

        # Capabilities from paths
        capabilities = []
        seen_tags: set[str] = set()
        paths = spec.get("paths", {})
        for path, methods in paths.items():
            for method, operation in methods.items():
                if method.lower() not in ("get", "post", "put", "patch", "delete"):
                    continue
                # Use first tag as capability id, or generate from operationId
                tags = operation.get("tags", [])
                cap_id = tags[0] if tags else operation.get("operationId", f"{method}_{path}")
                cap_id = _slugify(str(cap_id))

                # One capability per unique tag
                if cap_id in seen_tags:
                    continue
                seen_tags.add(cap_id)

                cap = {
                    "id": cap_id,
                    "name": operation.get("summary", cap_id),
                    "description": operation.get("description", operation.get("summary", cap_id)),
                    "method": _method_map(method),
                    "path": path,
                    "tags": tags or [cap_id],
                    "input_schema": operation.get("requestBody", {}).get("content", {}).get("application/json", {}).get("schema", {}),
                    "example_request": {},
                    "example_response": {},
                    "health_check": False,
                }
                capabilities.append(cap)

        builder._manifest["capabilities"] = capabilities
        return builder

    def service(self, **kwargs) -> ManifestBuilder:
        """Override service fields."""
        self._manifest["service"].update(kwargs)
        return self

    def security(self, **kwargs) -> ManifestBuilder:
        """Override security fields."""
        self._manifest["security"].update(kwargs)
        return self

    def pricing(self, **kwargs) -> ManifestBuilder:
        """Override pricing fields."""
        self._manifest["pricing"].update(kwargs)
        return self

    def limits(self, **kwargs) -> ManifestBuilder:
        """Override limits fields."""
        self._manifest["limits"].update(kwargs)
        return self

    def trust(self, **kwargs) -> ManifestBuilder:
        """Override trust fields."""
        self._manifest["trust"].update(kwargs)
        return self

    def signup_endpoint(self, url: str) -> ManifestBuilder:
        """Set the signup endpoint URL."""
        self._manifest["agent_onboarding"]["signup_endpoint"] = url
        return self

    def build(self) -> dict[str, Any]:
        """Return the built manifest dict."""
        return self._manifest

    def to_json(self, indent: int = 2) -> str:
        """Return the manifest as a JSON string."""
        return json.dumps(self._manifest, indent=indent)
