"""FastAPI middleware for unio-provider — manifest serving, signup handler, and token verification."""
from __future__ import annotations

import asyncio
import os
from typing import Any, Callable, Awaitable

import httpx
from fastapi import APIRouter, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from ..exceptions import UnioSignupRejected

# Live API Gateway URL is the default until a custom domain is registered.
# Override via UNIO_API_BASE env var when targeting a different deployment.
_UNIO_API_BASE = os.environ.get(
    "UNIO_API_BASE",
    "https://xza0g37re9.execute-api.ap-south-1.amazonaws.com/prod",
)


class SignupRequest(BaseModel):
    agent_id: str
    agent_public_key_b64: str
    contact_email: str
    trust_level: int = 0
    reputation_score: int = 50
    delegation_parent: str | None = None


class UnioProvider:
    """Main provider class — wraps a FastAPI router with Unio routes."""

    def __init__(
        self,
        manifest: dict[str, Any],
        unio_api_base: str | None = None,
    ) -> None:
        self.manifest = manifest
        self.unio_api_base = unio_api_base or _UNIO_API_BASE
        self._signup_handler: Callable[..., Awaitable[dict]] | None = None
        self.router = APIRouter()
        self._setup_routes()

    def _setup_routes(self) -> None:
        @self.router.get("/.well-known/unio.json")
        async def serve_manifest():
            return JSONResponse(content=self.manifest)

        @self.router.post("/unio/signup")
        async def handle_signup(body: SignupRequest, authorization: str = Header(default=None)):
            # Verify the agent's unio_token with Unio Auth service
            if not authorization:
                raise HTTPException(status_code=401, detail="Missing authorization token")
            token = authorization.replace("Bearer ", "")

            verified = await self._verify_token(token)
            if not verified or not verified.get("valid"):
                raise HTTPException(status_code=401, detail="Invalid or expired unio_token")

            # Verify the agent_id in the body matches the token subject
            if verified.get("agent_id") != body.agent_id:
                raise HTTPException(status_code=401, detail="Agent ID mismatch")

            if self._signup_handler is None:
                raise HTTPException(status_code=501, detail="No signup handler registered")

            try:
                result = await self._signup_handler(
                    agent_id=body.agent_id,
                    public_key_b64=body.agent_public_key_b64,
                    contact_email=body.contact_email,
                    trust_level=body.trust_level,
                    reputation_score=body.reputation_score,
                    delegation_parent=body.delegation_parent,
                )
                return JSONResponse(content=result)
            except UnioSignupRejected as e:
                raise HTTPException(status_code=403, detail=e.reason)

    async def _verify_token(self, token: str) -> dict | None:
        """Call Unio's POST /v1/auth/verify to validate the agent's token."""
        try:
            async with httpx.AsyncClient(timeout=5.0) as client:
                resp = await client.post(
                    f"{self.unio_api_base}/v1/auth/verify",
                    json={"unio_token": token},
                )
                if resp.status_code == 200:
                    return resp.json()
        except httpx.HTTPError:
            pass
        return None

    def signup_handler(self, func: Callable[..., Awaitable[dict]]) -> Callable[..., Awaitable[dict]]:
        """Decorator to register the signup handler."""
        self._signup_handler = func
        return func
