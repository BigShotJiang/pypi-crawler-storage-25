# unio-provider

SDK for integrating your service with the Unio agent network.

## Quick Start (10 lines)

```python
from unio_provider import ManifestBuilder, UnioProvider

# Build manifest from your OpenAPI spec
manifest = (ManifestBuilder.from_openapi("openapi.json")
    .service(category="email", tags=["email", "smtp"])
    .security(min_trust_level_required=0, reputation_threshold=0)
    .signup_endpoint("https://api.yourservice.com/unio/signup")
    .build())

# Create provider with auto-validation
provider = UnioProvider(manifest=manifest)

# Register your signup handler
@provider.signup_handler
async def create_agent_account(agent_id, public_key_b64, contact_email,
                                trust_level, reputation_score, delegation_parent=None):
    # Gate access by trust_level / reputation_score
    if trust_level < 1:
        raise UnioSignupRejected("Trust level too low")
    api_key = create_account(agent_id, contact_email)
    return {"credential": api_key, "credential_type": "api_key", "account_id": agent_id}

# Mount on your FastAPI app
from fastapi import FastAPI
app = FastAPI()
app.include_router(provider.router)
```

Your service now serves `/.well-known/unio.json` and handles `POST /unio/signup` with automatic token verification.

## Installation

```bash
pip install unio-provider
```

## Features

- **ManifestBuilder.from_openapi()** — Generate unio.json from any OpenAPI 3.x spec
- **Token verification** — Every signup request is verified against Unio Auth
- **Trust & reputation gating** — Providers receive `trust_level` and `reputation_score` in the signup handler
- **Schema validation** — Generated manifests are validated against the Unio JSON Schema

## License

Apache-2.0
