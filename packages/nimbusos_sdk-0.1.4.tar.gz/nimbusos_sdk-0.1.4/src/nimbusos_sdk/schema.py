from __future__ import annotations

import importlib
from pathlib import Path
import sys
from typing import Any


PACKAGED_SCHEMA_ROOT = Path(__file__).resolve().parent / "_schema"

TOPIC_MESSAGE_TYPES: dict[str, str] = {
    "camera": "CameraJpegMessage",
    "live_camera": "CameraJpegMessage",
    "state": "StateMessage",
    "telemetry": "TelemetryMessage",
    "waypoint_status": "WaypointStatusMessage",
}


def ensure_generated_schema_on_path() -> None:
    if not _packaged_schema_exists():
        raise RuntimeError(
            "Missing packaged generated schema. Refresh "
            "nimbusos_sdk/_schema from NimbusOS/schema/generated before building."
        )

    schema_root = str(PACKAGED_SCHEMA_ROOT)
    if schema_root not in sys.path:
        sys.path.insert(0, schema_root)


def _packaged_schema_exists() -> bool:
    return (PACKAGED_SCHEMA_ROOT / "droneforge" / "schema").exists()


def load_message_class(class_name: str) -> type[Any]:
    ensure_generated_schema_on_path()
    try:
        module = importlib.import_module(f"droneforge.schema.{class_name}")
        loaded = getattr(module, class_name)
    except Exception as exc:
        raise RuntimeError(f"Unable to load generated FlatBuffer class {class_name}") from exc

    return loaded


def decode_payload(topic: str, payload: bytes) -> tuple[Any, str]:
    class_name = TOPIC_MESSAGE_TYPES.get(topic)
    if class_name is None:
        raise ValueError(f"unsupported SDK subscription topic: {topic}")

    message_class = load_message_class(class_name)
    try:
        return message_class.GetRootAs(payload, 0), class_name
    except Exception as exc:
        raise RuntimeError(f"Unable to decode {topic} as {class_name}") from exc
