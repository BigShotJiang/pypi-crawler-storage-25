from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class WaypointStatus:
    seq: int
    t_ns: int
    current_waypoint_seq: int
    command_seq: int
    waypoint_index: int
    active: bool
    reached: bool
    held: bool
    distance_m: float


def decode_waypoint_status(message: Any) -> WaypointStatus:
    decoded = message.decoded
    return WaypointStatus(
        seq=_required_int(message.seq, "seq"),
        t_ns=_required_int(message.t_ns, "t_ns"),
        current_waypoint_seq=decoded.CurrentWaypointSeq(),
        command_seq=decoded.CommandSeq(),
        waypoint_index=decoded.WaypointIndex(),
        active=decoded.Active(),
        reached=decoded.Reached(),
        held=decoded.Held(),
        distance_m=decoded.DistanceM(),
    )


def _required_int(value: int | None, name: str) -> int:
    if value is None:
        raise ValueError(f"waypoint status message missing {name}")
    return value
