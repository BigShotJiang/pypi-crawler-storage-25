from __future__ import annotations

import asyncio
import os
import time
import unittest
from collections import defaultdict

import fluxera


def process_identity(delay: float) -> int:
    time.sleep(delay)
    return os.getpid()


def process_finished_at(delay: float) -> float:
    time.sleep(delay)
    return time.time()


def process_sleep(delay: float) -> None:
    time.sleep(delay)


async def wait_for_async(predicate, *, timeout: float = 2.0, interval: float = 0.01) -> None:
    deadline = time.perf_counter() + timeout
    while time.perf_counter() < deadline:
        if predicate():
            return
        await asyncio.sleep(interval)
    raise AssertionError("Timed out waiting for condition.")


class _FlakyConsumer(fluxera.Consumer):
    def __init__(self, broker: "_FlakyStubBroker", queue_name: str, base: fluxera.Consumer) -> None:
        self._broker = broker
        self._queue_name = queue_name
        self._base = base

    async def receive(self, *, limit: int, timeout: float | None) -> list[fluxera.Delivery]:
        if self._broker.receive_failures[self._queue_name] == 0:
            self._broker.receive_failures[self._queue_name] += 1
            raise self._broker.failure_factory()
        return await self._base.receive(limit=limit, timeout=timeout)

    async def ack(self, delivery: fluxera.Delivery) -> None:
        await self._base.ack(delivery)

    async def reject(self, delivery: fluxera.Delivery, *, requeue: bool = False) -> None:
        await self._base.reject(delivery, requeue=requeue)

    async def extend_lease(self, delivery: fluxera.Delivery, *, seconds: float) -> None:
        await self._base.extend_lease(delivery, seconds=seconds)

    async def close(self) -> None:
        await self._base.close()


class _FlakyStubBroker(fluxera.StubBroker):
    def __init__(self, failure_factory) -> None:
        super().__init__()
        self.failure_factory = failure_factory
        self.receive_failures: defaultdict[str, int] = defaultdict(int)

    async def open_consumer(self, queue_name: str, *, prefetch: int = 1) -> fluxera.Consumer:
        base = await super().open_consumer(queue_name, prefetch=prefetch)
        return _FlakyConsumer(self, queue_name, base)


class _RedeliverOnceConsumer(fluxera.Consumer):
    def __init__(self, base: fluxera.Consumer) -> None:
        self._base = base
        self._tagged = False

    async def receive(self, *, limit: int, timeout: float | None) -> list[fluxera.Delivery]:
        deliveries = await self._base.receive(limit=limit, timeout=timeout)
        if deliveries and not self._tagged:
            deliveries[0].redelivered = True
            self._tagged = True
        return deliveries

    async def ack(self, delivery: fluxera.Delivery) -> None:
        await self._base.ack(delivery)

    async def reject(self, delivery: fluxera.Delivery, *, requeue: bool = False) -> None:
        await self._base.reject(delivery, requeue=requeue)

    async def extend_lease(self, delivery: fluxera.Delivery, *, seconds: float) -> None:
        await self._base.extend_lease(delivery, seconds=seconds)

    async def close(self) -> None:
        await self._base.close()


class _RedeliverOnceStubBroker(fluxera.StubBroker):
    async def open_consumer(self, queue_name: str, *, prefetch: int = 1) -> fluxera.Consumer:
        base = await super().open_consumer(queue_name, prefetch=prefetch)
        return _RedeliverOnceConsumer(base)


class StubBrokerWorkerTests(unittest.IsolatedAsyncioTestCase):
    async def test_get_current_worker_state_is_none_outside_actor(self) -> None:
        self.assertIsNone(fluxera.get_current_worker_state())

    async def test_current_worker_state_available_for_async_actor(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        seen: list[fluxera.CurrentWorkerState] = []

        @fluxera.actor
        async def observe_async() -> None:
            state = fluxera.get_current_worker_state()
            self.assertIsNotNone(state)
            assert state is not None
            seen.append(state)

        async with fluxera.Worker(broker, concurrency=1):
            await observe_async.send()
            await broker.join(observe_async.queue_name)

        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0].actor_name, observe_async.actor_name)
        self.assertEqual(seen[0].queue_name, observe_async.queue_name)
        self.assertEqual(seen[0].attempt, 0)
        self.assertTrue(seen[0].is_first_attempt)
        self.assertFalse(seen[0].is_retry)
        self.assertFalse(seen[0].redelivered)
        self.assertEqual(seen[0].execution_mode, "async")

    async def test_current_worker_state_available_for_thread_actor(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        seen: list[fluxera.CurrentWorkerState] = []

        @fluxera.actor
        def observe_thread() -> None:
            state = fluxera.get_current_worker_state()
            assert state is not None
            seen.append(state)

        async with fluxera.Worker(broker, concurrency=1, thread_concurrency=1):
            await observe_thread.send()
            await broker.join(observe_thread.queue_name)

        self.assertEqual(len(seen), 1)
        self.assertEqual(seen[0].execution_mode, "thread")
        self.assertEqual(seen[0].attempt, 0)

    async def test_current_worker_state_tracks_retry_attempt(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        attempts: list[int] = []

        @fluxera.actor(max_retries=1)
        async def flaky() -> None:
            state = fluxera.get_current_worker_state()
            self.assertIsNotNone(state)
            assert state is not None
            attempts.append(state.attempt)
            if state.attempt == 0:
                raise RuntimeError("retry once")

        async with fluxera.Worker(broker, concurrency=1):
            await flaky.send()
            await broker.join(flaky.queue_name)

        self.assertEqual(attempts, [0, 1])

    async def test_async_worker_processes_many_messages_concurrently(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)

        active = 0
        max_active = 0
        lock = asyncio.Lock()

        @fluxera.actor
        async def sleeper(delay: float) -> None:
            nonlocal active, max_active

            async with lock:
                active += 1
                max_active = max(max_active, active)

            await asyncio.sleep(delay)

            async with lock:
                active -= 1

        async with fluxera.Worker(broker, concurrency=20):
            for _ in range(20):
                await sleeper.send(0.05)

            await broker.join(sleeper.queue_name)

        self.assertGreaterEqual(max_active, 10)

    async def test_sync_actor_uses_thread_offload_by_default(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)

        active = 0
        max_active = 0

        @fluxera.actor
        def blocking(delay: float) -> None:
            nonlocal active, max_active
            active += 1
            max_active = max(max_active, active)
            try:
                time.sleep(delay)
            finally:
                active -= 1

        start = time.perf_counter()
        async with fluxera.Worker(broker, concurrency=4):
            for _ in range(4):
                await blocking.send(0.05)

            await broker.join(blocking.queue_name)

        elapsed = time.perf_counter() - start
        self.assertLess(elapsed, 0.15)
        self.assertGreaterEqual(max_active, 2)

    async def test_process_actor_runs_in_process_pool(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        identify = fluxera.actor(
            broker=broker,
            actor_name="identify",
            queue_name="cpu",
            execution="process",
        )(process_identity)

        worker = fluxera.Worker(broker, concurrency=2, process_concurrency=2)
        start = time.perf_counter()
        await worker.start()
        try:
            await identify.send(0.05)
            await identify.send(0.05)
            await broker.join(identify.queue_name)
        finally:
            await worker.stop()

        elapsed = time.perf_counter() - start
        pids = [record.result for record in worker.records.values() if record.delivery.actor_name == "identify"]
        self.assertEqual(len(pids), 2)
        self.assertTrue(all(pid != os.getpid() for pid in pids))
        self.assertLess(elapsed, 0.24)

    async def test_process_lane_does_not_block_while_async_lane_is_full(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        io_completed: list[float] = []

        @fluxera.actor(queue_name="mixed")
        async def io_wait(delay: float) -> None:
            await asyncio.sleep(delay)
            io_completed.append(time.time())

        cpu_task = fluxera.actor(
            broker=broker,
            actor_name="cpu_task",
            queue_name="mixed",
            execution="process",
        )(process_finished_at)

        worker = fluxera.Worker(
            broker,
            async_concurrency=2,
            thread_concurrency=1,
            process_concurrency=1,
        )
        await worker.start()
        try:
            await io_wait.send(0.2)
            await io_wait.send(0.2)
            await cpu_task.send(0.05)
            await broker.join(io_wait.queue_name)
        finally:
            await worker.stop()

        cpu_finished = max(record.result for record in worker.records.values() if record.delivery.actor_name == "cpu_task")
        self.assertEqual(len(io_completed), 2)
        self.assertLess(cpu_finished, min(io_completed))

    async def test_process_timeout_recycles_slot_for_next_task(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        slow = fluxera.actor(
            broker=broker,
            actor_name="slow_process",
            queue_name="cpu",
            execution="process",
            timeout=50,
        )(process_sleep)
        fast = fluxera.actor(
            broker=broker,
            actor_name="fast_process",
            queue_name="cpu",
            execution="process",
        )(process_identity)

        worker = fluxera.Worker(broker, process_concurrency=1)
        await worker.start()
        try:
            await slow.send(0.2)
            await broker.join(slow.queue_name)

            start = time.perf_counter()
            await fast.send(0.01)
            await broker.join(fast.queue_name)
            elapsed = time.perf_counter() - start
        finally:
            await worker.stop()

        self.assertLess(elapsed, 0.20)
        self.assertEqual(len(broker.dead_letters), 1)
        self.assertEqual(broker.dead_letters[0].failure_kind, "timeout")
        self.assertEqual(broker.dead_letters[0].actor_name, "slow_process")
        fast_records = [record for record in worker.records.values() if record.delivery.actor_name == "fast_process"]
        self.assertEqual(len(fast_records), 1)
        self.assertNotEqual(fast_records[0].result, os.getpid())

    async def test_process_shutdown_cancellation_requeues_by_default(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        sleeper = fluxera.actor(
            broker=broker,
            actor_name="process_sleeper",
            queue_name="cpu",
            execution="process",
        )(process_sleep)

        worker = fluxera.Worker(broker, process_concurrency=1)
        await worker.start()
        await sleeper.send(0.5)

        start = time.perf_counter()
        await worker.stop(timeout=0.01)
        elapsed = time.perf_counter() - start

        self.assertLess(elapsed, 0.25)
        self.assertEqual(broker.queue_objects[sleeper.queue_name].qsize(), 1)
        self.assertEqual(broker.dead_letters, [])

    async def test_retry_policy_retries_then_succeeds(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        attempts = 0

        @fluxera.actor(max_retries=2)
        async def flaky() -> None:
            nonlocal attempts
            attempts += 1
            if attempts < 3:
                raise RuntimeError("try again")

        worker = fluxera.Worker(broker, concurrency=4)
        await worker.start()
        try:
            await flaky.send()
            await broker.join(flaky.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(attempts, 3)
        self.assertEqual(broker.dead_letters, [])
        latest_record = worker.records[next(iter(worker.records))]
        self.assertEqual(latest_record.attempt, 2)
        self.assertEqual(latest_record.state, "succeeded")

    async def test_timeout_policy_retries_then_dead_letters(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        attempts = 0

        @fluxera.actor(timeout=10, max_retries=1, retry_on_timeout=True)
        async def too_slow() -> None:
            nonlocal attempts
            attempts += 1
            await asyncio.sleep(0.05)

        worker = fluxera.Worker(broker, concurrency=2)
        await worker.start()
        try:
            await too_slow.send()
            await broker.join(too_slow.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(attempts, 2)
        self.assertEqual(len(broker.dead_letters), 1)
        self.assertEqual(broker.dead_letters[0].failure_kind, "timeout")
        self.assertEqual(broker.dead_letters[0].attempt, 1)
        self.assertEqual(broker.dead_letters[0].max_retries, 1)
        latest_record = worker.records[next(iter(worker.records))]
        self.assertEqual(latest_record.attempt, 1)
        self.assertEqual(latest_record.final_action, "reject")

    async def test_shutdown_cancellation_requeues_by_default(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        started = asyncio.Event()
        release = asyncio.Event()

        @fluxera.actor
        async def hanging() -> None:
            started.set()
            await release.wait()

        worker = fluxera.Worker(broker, concurrency=1)
        await worker.start()
        await hanging.send()
        await started.wait()
        await worker.stop(timeout=0.01)

        self.assertEqual(broker.queue_objects[hanging.queue_name].qsize(), 1)
        self.assertEqual(broker.dead_letters, [])

    async def test_throws_prevents_retry_and_dead_letters_immediately(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        attempts = 0

        @fluxera.actor(max_retries=3, throws=(ValueError,))
        async def never_retry() -> None:
            nonlocal attempts
            attempts += 1
            raise ValueError("stop")

        worker = fluxera.Worker(broker, concurrency=2)
        await worker.start()
        try:
            await never_retry.send()
            await broker.join(never_retry.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(attempts, 1)
        self.assertEqual(len(broker.dead_letters), 1)
        self.assertEqual(broker.dead_letters[0].exception_type, "ValueError")

    async def test_rate_limit_exceeded_defers_without_consuming_retry_budget(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        attempts = 0
        completions = 0

        @fluxera.actor(max_retries=0, rate_limit_defer_ms=5)
        async def eventually_runs() -> None:
            nonlocal attempts, completions
            attempts += 1
            if attempts < 3:
                raise fluxera.RateLimitExceeded("busy")
            completions += 1

        worker = fluxera.Worker(broker, concurrency=1, poll_timeout=0.01)
        await worker.start()
        try:
            message = await eventually_runs.send()
            await broker.join(eventually_runs.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(attempts, 3)
        self.assertEqual(completions, 1)
        self.assertEqual(broker.dead_letters, [])
        history = worker.record_history[message.message_id]
        self.assertEqual(len(history), 3)
        self.assertTrue(all(record.attempt == 0 for record in history))
        self.assertEqual(history[0].final_action, "defer")
        self.assertEqual(history[1].final_action, "defer")
        self.assertEqual(history[2].final_action, "ack")

    async def test_on_redelivered_callback_runs_for_recovered_delivery(self) -> None:
        broker = _RedeliverOnceStubBroker()
        fluxera.set_broker(broker)
        events: list[fluxera.OutcomeContext] = []

        def on_redelivered(context: fluxera.OutcomeContext) -> None:
            events.append(context)

        @fluxera.actor(on_redelivered=on_redelivered)
        async def recovered() -> None:
            return None

        worker = fluxera.Worker(broker, concurrency=1)
        await worker.start()
        try:
            await recovered.send()
            await broker.join(recovered.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].event, "redelivered")
        self.assertTrue(events[0].redelivered)
        self.assertEqual(events[0].actor_name, recovered.actor_name)

    async def test_on_worker_lost_callback_runs_for_recovered_delivery(self) -> None:
        broker = _RedeliverOnceStubBroker()
        fluxera.set_broker(broker)
        events: list[fluxera.OutcomeContext] = []

        def on_worker_lost(context: fluxera.OutcomeContext) -> None:
            events.append(context)

        @fluxera.actor(on_worker_lost=on_worker_lost)
        async def recovered() -> None:
            return None

        worker = fluxera.Worker(broker, concurrency=1)
        await worker.start()
        try:
            await recovered.send()
            await broker.join(recovered.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].event, "worker_lost")
        self.assertTrue(events[0].redelivered)
        self.assertEqual(events[0].actor_name, recovered.actor_name)

    async def test_worker_default_on_worker_lost_callback_runs_for_recovered_delivery(self) -> None:
        broker = _RedeliverOnceStubBroker()
        fluxera.set_broker(broker)
        events: list[fluxera.OutcomeContext] = []

        def on_worker_lost(context: fluxera.OutcomeContext) -> None:
            events.append(context)

        @fluxera.actor
        async def recovered() -> None:
            return None

        worker = fluxera.Worker(broker, concurrency=1, on_worker_lost=on_worker_lost)
        await worker.start()
        try:
            await recovered.send()
            await broker.join(recovered.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(len(events), 1)
        self.assertEqual(events[0].event, "worker_lost")
        self.assertTrue(events[0].redelivered)
        self.assertEqual(events[0].actor_name, recovered.actor_name)

    async def test_redelivery_policy_fail_dead_letters_without_running_actor(self) -> None:
        broker = _RedeliverOnceStubBroker()
        fluxera.set_broker(broker)
        runs = 0
        failure_kinds: list[str | None] = []

        async def on_failure(context: fluxera.OutcomeContext) -> None:
            failure_kinds.append(context.failure_kind)

        @fluxera.actor(redelivery_policy="fail", on_failure=on_failure)
        async def recovered() -> None:
            nonlocal runs
            runs += 1

        worker = fluxera.Worker(broker, concurrency=1)
        await worker.start()
        try:
            await recovered.send()
            await broker.join(recovered.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(runs, 0)
        self.assertEqual(failure_kinds, ["worker_lost"])
        self.assertEqual(len(broker.dead_letters), 1)
        self.assertEqual(broker.dead_letters[0].failure_kind, "worker_lost")

    async def test_worker_default_redelivery_policy_fail_dead_letters_without_running_actor(self) -> None:
        broker = _RedeliverOnceStubBroker()
        fluxera.set_broker(broker)
        runs = 0

        @fluxera.actor
        async def recovered() -> None:
            nonlocal runs
            runs += 1

        worker = fluxera.Worker(broker, concurrency=1, default_redelivery_policy="fail")
        await worker.start()
        try:
            await recovered.send()
            await broker.join(recovered.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(runs, 0)
        self.assertEqual(len(broker.dead_letters), 1)
        self.assertEqual(broker.dead_letters[0].failure_kind, "worker_lost")

    async def test_retry_when_controls_retry_schedule(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        attempts = 0

        def retry_when(attempt: int, exc: BaseException, record: fluxera.TaskRecord) -> bool:
            self.assertIsInstance(exc, RuntimeError)
            self.assertEqual(attempt, record.attempt)
            return attempt < 1

        @fluxera.actor(max_retries=5, retry_when=retry_when)
        async def controlled_retry() -> None:
            nonlocal attempts
            attempts += 1
            raise RuntimeError("try again")

        worker = fluxera.Worker(broker, concurrency=2)
        await worker.start()
        try:
            await controlled_retry.send()
            await broker.join(controlled_retry.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(attempts, 2)
        self.assertEqual(len(broker.dead_letters), 1)
        self.assertEqual(broker.dead_letters[0].attempt, 1)

    async def test_invalid_retry_when_moves_message_to_invalid_configuration_dead_letter(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)

        def invalid_retry_when(attempt: int, exc: BaseException, record: fluxera.TaskRecord) -> str:
            del attempt, exc, record
            return "yes"

        @fluxera.actor(max_retries=5, retry_when=invalid_retry_when)
        async def invalid_retry() -> None:
            raise RuntimeError("boom")

        worker = fluxera.Worker(broker, concurrency=2)
        await worker.start()
        try:
            await invalid_retry.send()
            await broker.join(invalid_retry.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(len(broker.dead_letters), 1)
        self.assertEqual(broker.dead_letters[0].failure_kind, "invalid_configuration")

    async def test_success_and_failure_hooks_receive_contexts(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        success_results: list[int] = []
        failure_types: list[str | None] = []

        def on_success(context: fluxera.OutcomeContext) -> None:
            success_results.append(context.result)

        async def on_failure(context: fluxera.OutcomeContext) -> None:
            failure_types.append(context.exception_type)

        @fluxera.actor(on_success=on_success)
        async def succeed(value: int) -> int:
            return value + 1

        @fluxera.actor(max_retries=0, on_failure=on_failure)
        async def fail() -> None:
            raise RuntimeError("boom")

        worker = fluxera.Worker(broker, concurrency=4)
        await worker.start()
        try:
            await succeed.send(3)
            await fail.send()
            await broker.join(succeed.queue_name)
            await broker.join(fail.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(success_results, [4])
        self.assertEqual(failure_types, ["RuntimeError"])

    async def test_retry_exhausted_and_dead_letter_callbacks_dispatch(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        retry_exhausted_payloads: list[dict[str, object]] = []
        dead_letter_ids: list[str] = []

        @fluxera.actor(queue_name="callbacks")
        async def capture_retry_exhausted(payload: dict[str, object]) -> None:
            retry_exhausted_payloads.append(payload)

        def on_dead_lettered(context: fluxera.DeadLetterContext) -> None:
            dead_letter_ids.append(context.record.dead_letter_id)

        @fluxera.actor(
            queue_name="callbacks",
            max_retries=0,
            on_retry_exhausted="capture_retry_exhausted",
            on_dead_lettered=on_dead_lettered,
        )
        async def fail_terminally() -> None:
            raise RuntimeError("terminal")

        worker = fluxera.Worker(broker, concurrency=4)
        await worker.start()
        try:
            await fail_terminally.send()
            await broker.join(fail_terminally.queue_name)
            await broker.join(capture_retry_exhausted.queue_name)
        finally:
            await worker.stop()

        self.assertEqual(len(retry_exhausted_payloads), 1)
        self.assertEqual(retry_exhausted_payloads[0]["event"], "retry_exhausted")
        self.assertEqual(retry_exhausted_payloads[0]["failure_kind"], "exception")
        self.assertEqual(dead_letter_ids, [retry_exhausted_payloads[0]["dead_letter_id"]])

    async def test_consumer_transient_receive_errors_are_retried(self) -> None:
        broker = _FlakyStubBroker(lambda: OSError("temporary socket issue"))
        fluxera.set_broker(broker)
        processed: list[int] = []

        @fluxera.actor(queue_name="recover")
        async def recover_task(value: int) -> None:
            processed.append(value)

        worker = fluxera.Worker(broker, concurrency=1, prefetch=1, poll_timeout=0.01)
        await worker.start()
        try:
            await recover_task.send(7)
            await asyncio.wait_for(broker.join(recover_task.queue_name), timeout=2.0)
            await wait_for_async(lambda: processed == [7], timeout=2.0)
        finally:
            await worker.stop()

        self.assertEqual(broker.receive_failures[recover_task.queue_name], 1)
        self.assertEqual(processed, [7])

    async def test_consumer_task_crash_is_supervised_and_restarted(self) -> None:
        broker = _FlakyStubBroker(lambda: RuntimeError("unexpected receive crash"))
        fluxera.set_broker(broker)
        processed: list[int] = []

        @fluxera.actor(queue_name="restart")
        async def restart_task(value: int) -> None:
            processed.append(value)

        worker = fluxera.Worker(broker, concurrency=1, prefetch=1, poll_timeout=0.01)
        await worker.start()
        try:
            await wait_for_async(lambda: broker.receive_failures[restart_task.queue_name] == 1, timeout=2.0)
            await restart_task.send(9)
            await asyncio.wait_for(broker.join(restart_task.queue_name), timeout=2.0)
            await wait_for_async(lambda: processed == [9], timeout=2.0)
        finally:
            await worker.stop()

        self.assertEqual(broker.receive_failures[restart_task.queue_name], 1)
        self.assertEqual(processed, [9])

    async def test_revision_control_plane_bootstraps_and_promotes(self) -> None:
        broker = fluxera.StubBroker()

        self.assertEqual(await broker.ensure_serving_revision("default", "rev-a"), "rev-a")
        self.assertEqual(await broker.get_serving_revision("default"), "rev-a")
        self.assertFalse(
            await broker.promote_serving_revision(
                "default",
                "rev-c",
                expected_revision="rev-b",
            )
        )
        self.assertTrue(
            await broker.promote_serving_revision(
                "default",
                "rev-b",
                expected_revision="rev-a",
            )
        )
        self.assertEqual(await broker.get_serving_revision("default"), "rev-b")

        await broker.register_worker_revision(
            worker_id="stub-worker",
            worker_revision="rev-b",
            queue_states={"default": "accepting"},
        )
        self.assertEqual(broker.worker_revisions["stub-worker"], "rev-b")
        self.assertEqual(broker.worker_queue_states["stub-worker"], {"default": "accepting"})

        await broker.unregister_worker_revision(worker_id="stub-worker", queue_names={"default"})
        self.assertNotIn("stub-worker", broker.worker_revisions)
        self.assertNotIn("stub-worker", broker.worker_queue_states)

    async def test_revision_promotion_drains_unstarted_backlog_to_new_worker(self) -> None:
        broker = fluxera.StubBroker()
        fluxera.set_broker(broker)
        started = asyncio.Event()
        release = asyncio.Event()

        @fluxera.actor(queue_name="rollout")
        async def rollout_task(label: str) -> str:
            if label == "block":
                started.set()
                await release.wait()
            return label

        old_worker = fluxera.Worker(
            broker,
            queues={rollout_task.queue_name},
            async_concurrency=1,
            thread_concurrency=0,
            process_concurrency=0,
            max_in_flight=2,
            prefetch=2,
            worker_revision="rev-old",
            worker_id="stub-old",
            revision_poll_interval=0.01,
        )
        new_worker = fluxera.Worker(
            broker,
            queues={rollout_task.queue_name},
            async_concurrency=1,
            thread_concurrency=0,
            process_concurrency=0,
            max_in_flight=2,
            prefetch=2,
            worker_revision="rev-new",
            worker_id="stub-new",
            revision_poll_interval=0.01,
        )
        await old_worker.start()
        await new_worker.start()
        try:
            blocked = await rollout_task.send("block")
            queued = await rollout_task.send("queued")
            await started.wait()
            await wait_for_async(lambda: broker.queue_objects[rollout_task.queue_name].qsize() == 0)

            self.assertTrue(
                await broker.promote_serving_revision(
                    rollout_task.queue_name,
                    "rev-new",
                    expected_revision="rev-old",
                )
            )
            await wait_for_async(lambda: old_worker.queue_states.get(rollout_task.queue_name) == "draining")
            await wait_for_async(lambda: new_worker.queue_states.get(rollout_task.queue_name) == "accepting")

            release.set()
            await broker.join(rollout_task.queue_name)
            await wait_for_async(
                lambda: queued.message_id in new_worker.records
                and new_worker.records[queued.message_id].state == "succeeded"
            )
        finally:
            await old_worker.stop()
            await new_worker.stop()

        self.assertIn(blocked.message_id, old_worker.records)
        self.assertIn(queued.message_id, new_worker.records)
        self.assertNotIn(queued.message_id, old_worker.records)
