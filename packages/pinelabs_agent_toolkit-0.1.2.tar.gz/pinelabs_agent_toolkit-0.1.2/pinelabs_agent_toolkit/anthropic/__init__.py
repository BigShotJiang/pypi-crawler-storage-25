"""Anthropic Messages API adapter for the Pine Labs Agent Toolkit.

Returns Pine Labs operations as Anthropic tool blocks (``{"name", "description",
"input_schema"}``) plus a ``handle_tool_use`` helper that runs a single
``tool_use`` block from a Claude response and returns the string content
to send back as a ``tool_result``.

Example
-------
.. code-block:: python

    import anthropic
    from pinelabs_agent_toolkit.anthropic import PinelabsAgentToolkit

    toolkit = PinelabsAgentToolkit(
        environment="https://pluraluat.v2.pinepg.in",
        client_id="<client-id>",
        client_secret="<client-secret>",
    )
    client = anthropic.Anthropic()
    messages = [{"role": "user", "content": "Create a 500 INR order."}]
    while True:
        resp = client.messages.create(
            model="claude-3-5-sonnet-latest",
            max_tokens=1024,
            tools=toolkit.get_tools(),
            messages=messages,
        )
        messages.append({"role": "assistant", "content": resp.content})
        tool_uses = [b for b in resp.content if b.type == "tool_use"]
        if not tool_uses:
            break
        results = [
            {
                "type": "tool_result",
                "tool_use_id": b.id,
                "content": toolkit.handle_tool_use(b.name, b.input),
            }
            for b in tool_uses
        ]
        messages.append({"role": "user", "content": results})
"""
from __future__ import annotations

from typing import Any, List

from ..shared import ALL_TOOLS, Pinelabs, ToolDefinition


class PinelabsAgentToolkit:
    """Pine Labs tools for Anthropic Messages API."""

    def __init__(
        self,
        *,
        environment: str,
        client_id: str,
        client_secret: str,
    ) -> None:
        self._client = Pinelabs(
            environment=environment,
            client_id=client_id,
            client_secret=client_secret,
        )
        self._tools: List[ToolDefinition] = list(ALL_TOOLS)

    def get_tools(self) -> List[dict]:
        """Return Pine Labs operations as Anthropic tool blocks."""
        return [
            {
                "name": td.name,
                "description": td.description,
                "input_schema": _json_schema(td),
            }
            for td in self._tools
        ]

    def handle_tool_use(self, name: str, input: Any) -> str:
        """Run a Claude ``tool_use`` block; returns ``tool_result`` content."""
        td = _find(self._tools, name)
        payload = input if isinstance(input, dict) else {}
        return td.execute(self._client, payload)


def _json_schema(td: ToolDefinition) -> dict:
    schema = td.parameters.model_json_schema(by_alias=True)
    schema.pop("title", None)
    return schema


def _find(tools: List[ToolDefinition], name: str) -> ToolDefinition:
    for td in tools:
        if td.name == name:
            return td
    raise KeyError(f"Unknown Pine Labs tool: {name!r}")
