"""Pydantic AI adapter for the Pine Labs Agent Toolkit.

Pine Labs tool models are already pydantic, so this adapter is a thin shim:
each tool becomes a ``pydantic_ai.Tool`` whose function takes the
auto-generated pydantic model as its sole argument.

Example
-------
.. code-block:: python

    from pydantic_ai import Agent
    from pinelabs_agent_toolkit.pydantic_ai import PinelabsAgentToolkit

    toolkit = PinelabsAgentToolkit(
        environment="https://pluraluat.v2.pinepg.in",
        client_id="<client-id>",
        client_secret="<client-secret>",
    )
    agent = Agent("openai:gpt-4o", tools=toolkit.get_tools())
    result = agent.run_sync("Create a 500 INR order with reference ord-1.")
"""
from __future__ import annotations

from typing import Any, List

from ..shared import ALL_TOOLS, Pinelabs, ToolDefinition


class PinelabsAgentToolkit:
    """Pine Labs tools for Pydantic AI."""

    def __init__(
        self,
        *,
        environment: str,
        client_id: str,
        client_secret: str,
    ) -> None:
        self._client = Pinelabs(
            environment=environment,
            client_id=client_id,
            client_secret=client_secret,
        )
        self._tools: List[ToolDefinition] = list(ALL_TOOLS)

    def get_tools(self) -> List[Any]:
        """Return Pine Labs operations as ``pydantic_ai.Tool`` instances."""
        try:
            from pydantic_ai import Tool  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover — import-guarded path
            raise ImportError(
                "pydantic-ai is not installed. Run "
                "`pip install 'pinelabs-agent-toolkit[pydantic-ai]'`."
            ) from exc

        client = self._client
        out: List[Any] = []
        for td in self._tools:
            out.append(_build_tool(Tool, td, client))
        return out


def _build_tool(Tool: Any, td: ToolDefinition, client: Pinelabs) -> Any:
    parameters = td.parameters

    def _run(**kwargs: Any) -> str:
        # Pydantic AI passes the LLM's tool args as kwargs. We let the
        # generated model do strict validation (extra="forbid") then dispatch.
        validated = parameters.model_validate(kwargs)
        return td.execute(client, validated.model_dump(by_alias=True, exclude_none=True))

    return Tool(
        function=_run,
        name=td.name,
        description=td.description,
    )
