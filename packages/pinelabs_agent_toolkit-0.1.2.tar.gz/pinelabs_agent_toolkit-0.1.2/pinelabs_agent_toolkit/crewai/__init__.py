"""CrewAI adapter for the Pine Labs Agent Toolkit.

CrewAI tools are class-based: each tool subclasses ``crewai.tools.BaseTool``
with a pydantic ``args_schema`` and a ``_run`` method. We dynamically build
one subclass per Pine Labs operation.

Mutating operations (creates / updates / refunds) disable result caching so
the agent never reuses stale outputs across runs.

Example
-------
.. code-block:: python

    from crewai import Agent
    from pinelabs_agent_toolkit.crewai import PinelabsAgentToolkit

    toolkit = PinelabsAgentToolkit(
        environment="https://pluraluat.v2.pinepg.in",
        client_id="<client-id>",
        client_secret="<client-secret>",
    )
    payments_agent = Agent(
        role="Payments Specialist",
        goal="Manage Pine Labs payments.",
        backstory="...",
        tools=toolkit.get_tools(),
    )
"""
from __future__ import annotations

from typing import Any, List, Type

from ..shared import ALL_TOOLS, Pinelabs, ToolDefinition

# HTTP verbs that mutate state — caching results across agent runs would be
# unsafe for these.
_MUTATING_METHODS = frozenset({"POST", "PUT", "PATCH", "DELETE"})


class PinelabsAgentToolkit:
    """Pine Labs tools for CrewAI."""

    def __init__(
        self,
        *,
        environment: str,
        client_id: str,
        client_secret: str,
    ) -> None:
        self._client = Pinelabs(
            environment=environment,
            client_id=client_id,
            client_secret=client_secret,
        )
        self._tools: List[ToolDefinition] = list(ALL_TOOLS)

    def get_tools(self) -> List[Any]:
        """Return Pine Labs operations as ``BaseTool`` instances."""
        try:
            from crewai.tools import BaseTool  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover — import-guarded path
            raise ImportError(
                "crewai is not installed. Run "
                "`pip install 'pinelabs-agent-toolkit[crewai]'`."
            ) from exc

        client = self._client
        return [_build_crewai_tool(BaseTool, td, client) for td in self._tools]


def _build_crewai_tool(BaseTool: Type[Any], td: ToolDefinition, client: Pinelabs) -> Any:
    parameters = td.parameters
    is_mutating = td.method.upper() in _MUTATING_METHODS

    def _run(self: Any, **kwargs: Any) -> str:
        validated = parameters.model_validate(kwargs)
        return td.execute(client, validated.model_dump(by_alias=True, exclude_none=True))

    attrs: dict = {
        "name": td.name,
        "description": td.description,
        "args_schema": parameters,
        "_run": _run,
    }
    if is_mutating:
        # Disable per-call caching for mutating ops.
        attrs["cache_function"] = staticmethod(lambda *_args, **_kwargs: False)

    cls_name = f"{td.name}Tool"
    return type(cls_name, (BaseTool,), attrs)()
