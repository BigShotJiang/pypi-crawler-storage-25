"""Framework-agnostic tool definition.

Each framework adapter (openai, langchain, pydantic_ai, crewai, anthropic)
converts these into a framework-specific tool format. The generated entries
live in ``pinelabs_agent_toolkit.generated.tools_generated``.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, List, Type

from pydantic import BaseModel


@dataclass(frozen=True)
class ToolDefinition:
    """A framework-agnostic description of a Pine Labs operation."""

    #: Function name surfaced to the LLM (preserves the npm tool name).
    name: str
    #: Description shown to the LLM — informs when to call this tool.
    description: str
    #: Pydantic model describing the tool's input. Uses
    #: ``ConfigDict(extra="forbid")`` so the LLM cannot smuggle extra fields.
    parameters: Type[BaseModel]
    #: Source ``operationId`` from the OpenAPI spec.
    operation_id: str
    #: OpenAPI tag (matches the snake_case sub-client attr on ``PinelabsApi``).
    tag: str
    #: HTTP method (informational).
    method: str
    #: HTTP path template (informational).
    path: str
    #: Path parameter names.
    path_params: List[str] = field(default_factory=list)
    #: Query parameter names.
    query_params: List[str] = field(default_factory=list)
    #: Whether the operation has a request body.
    has_body: bool = False
    #: Execute the tool against a Pine Labs SDK client. Returns a JSON string.
    execute: Callable[[Any, dict], str] = field(default=lambda c, p: "")
