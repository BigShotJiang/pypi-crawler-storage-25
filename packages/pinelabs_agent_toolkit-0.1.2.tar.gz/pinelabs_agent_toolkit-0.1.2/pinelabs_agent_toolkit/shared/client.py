"""Authenticated Pine Labs SDK client with automatic OAuth2 token caching.

The official :mod:`pinelabs` SDK accepts a token supplier callback that fires
on **every** request, including the OAuth ``/api/auth/v1/token`` call itself.
A naive supplier would recurse infinitely. We avoid recursion entirely by
spinning up a *separate* bootstrap ``PinelabsApi`` client (with a fixed empty
token) just to call ``authentication.generate_token``. The main client's
supplier never re-enters the auth path.

This is the same recipe documented in ``sdks/python/README.md`` — exposed here
as a reusable building block for the agent toolkit.
"""
from __future__ import annotations

import threading
import time
from typing import Any, Dict, Literal, Optional, TypedDict

from pinelabs import PinelabsApi


# Pine Labs base URLs (without the ``/api`` suffix the SDK appends itself).
pinelabs_environment: Dict[str, str] = {
    "UAT": "https://pluraluat.v2.pinepg.in",
    "PROD": "https://api.pluralpay.in",
}

PinelabsEnvironment = Literal[
    "https://pluraluat.v2.pinepg.in",
    "https://api.pluralpay.in",
]


class PinelabsClientOptions(TypedDict, total=False):
    """Constructor arguments for :class:`Pinelabs`."""

    environment: str
    client_id: str
    client_secret: str
    refresh_skew_seconds: float


_DEFAULT_SKEW_SECONDS = 30.0


class Pinelabs(PinelabsApi):
    """Pine Labs SDK with automatic OAuth2 client_credentials token refresh.

    Example
    -------
    >>> from pinelabs_agent_toolkit.shared import Pinelabs, pinelabs_environment
    >>> client = Pinelabs(
    ...     environment=pinelabs_environment["UAT"],
    ...     client_id="<client-id>",
    ...     client_secret="<client-secret>",
    ... )
    >>> client.orders.create_order(...)  # doctest: +SKIP
    """

    def __init__(
        self,
        *,
        environment: str,
        client_id: str,
        client_secret: str,
        refresh_skew_seconds: float = _DEFAULT_SKEW_SECONDS,
        **kwargs: Any,
    ) -> None:
        self._client_id = client_id
        self._client_secret = client_secret
        self._refresh_skew_seconds = refresh_skew_seconds
        self._cached_token: Optional[str] = None
        self._cached_expiry: float = 0.0
        self._lock = threading.Lock()
        # Bootstrap client used *only* for the auth call. It has no token
        # supplier, so it cannot recurse.
        self._auth_client = PinelabsApi(
            base_url=f"{environment}/api",
            token="",
        )
        super().__init__(
            base_url=f"{environment}/api",
            token=self._get_access_token,
            **kwargs,
        )

    def _get_access_token(self) -> str:
        with self._lock:
            now = time.time()
            if (
                self._cached_token
                and now + self._refresh_skew_seconds < self._cached_expiry
            ):
                return self._cached_token
            response = self._auth_client.authentication.generate_token(
                client_id=self._client_id,
                client_secret=self._client_secret,
                grant_type="client_credentials",
            )
            self._cached_token = _extract(response, "access_token") or ""
            expires_at = _extract(response, "expires_at")
            expires_in = _extract(response, "expires_in")
            if expires_at:
                # ISO-8601; tolerate both "+00:00" and naive forms.
                from datetime import datetime

                try:
                    self._cached_expiry = datetime.fromisoformat(
                        str(expires_at).replace("Z", "+00:00")
                    ).timestamp()
                except ValueError:
                    self._cached_expiry = now + float(expires_in or 300)
            else:
                self._cached_expiry = now + float(expires_in or 300)
            return self._cached_token


def _extract(response: Any, attr: str) -> Any:
    """Pull a field off a pydantic model, dataclass, or dict response."""
    if response is None:
        return None
    if isinstance(response, dict):
        return response.get(attr)
    return getattr(response, attr, None)
