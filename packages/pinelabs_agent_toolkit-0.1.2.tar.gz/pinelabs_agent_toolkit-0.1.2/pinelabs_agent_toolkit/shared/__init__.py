"""Shared core for the Pine Labs Agent Toolkit.

Re-exports the authenticated SDK client (:class:`Pinelabs`), the framework-
agnostic :class:`ToolDefinition`, and the auto-generated tool catalogue
(``ALL_TOOLS``).
"""
from .client import (
    Pinelabs,
    PinelabsClientOptions,
    PinelabsEnvironment,
    pinelabs_environment,
)
from .tool_definition import ToolDefinition

# Re-export the generated catalogue. Imported lazily here so a user who
# only wants `Pinelabs` without the full tool list (e.g. for a custom
# adapter) can still import the client.
from ..generated.tools_generated import ALL_TOOLS

__all__ = [
    "ALL_TOOLS",
    "Pinelabs",
    "PinelabsClientOptions",
    "PinelabsEnvironment",
    "ToolDefinition",
    "pinelabs_environment",
]
