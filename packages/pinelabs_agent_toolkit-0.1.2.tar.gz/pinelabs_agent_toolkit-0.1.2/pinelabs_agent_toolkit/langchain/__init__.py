"""LangChain adapter for the Pine Labs Agent Toolkit.

Exposes Pine Labs operations as ``langchain_core.tools.StructuredTool``
instances. Each tool's argument schema is a pydantic model, so LangChain's
function-calling agents can call them with full type validation.

Example
-------
.. code-block:: python

    from langchain_openai import ChatOpenAI
    from langgraph.prebuilt import create_react_agent
    from pinelabs_agent_toolkit.langchain import PinelabsAgentToolkit

    toolkit = PinelabsAgentToolkit(
        environment="https://pluraluat.v2.pinepg.in",
        client_id="<client-id>",
        client_secret="<client-secret>",
    )
    agent = create_react_agent(ChatOpenAI(model="gpt-4o"), toolkit.get_tools())
"""
from __future__ import annotations

from typing import Any, List

from ..shared import ALL_TOOLS, Pinelabs, ToolDefinition


class PinelabsAgentToolkit:
    """Pine Labs tools for LangChain."""

    def __init__(
        self,
        *,
        environment: str,
        client_id: str,
        client_secret: str,
    ) -> None:
        self._client = Pinelabs(
            environment=environment,
            client_id=client_id,
            client_secret=client_secret,
        )
        self._tools: List[ToolDefinition] = list(ALL_TOOLS)

    def get_tools(self) -> List[Any]:
        """Return Pine Labs operations as ``StructuredTool`` instances."""
        try:
            from langchain_core.tools import StructuredTool  # type: ignore[import-not-found]
        except ImportError as exc:  # pragma: no cover — import-guarded path
            raise ImportError(
                "langchain-core is not installed. Run "
                "`pip install 'pinelabs-agent-toolkit[langchain]'`."
            ) from exc

        client = self._client
        out: List[Any] = []
        for td in self._tools:
            out.append(_build_structured_tool(StructuredTool, td, client))
        return out


def _build_structured_tool(StructuredTool: Any, td: ToolDefinition, client: Pinelabs) -> Any:
    parameters = td.parameters

    def _run(**kwargs: Any) -> str:
        return td.execute(client, kwargs)

    return StructuredTool.from_function(
        func=_run,
        name=td.name,
        description=td.description,
        args_schema=parameters,
    )
