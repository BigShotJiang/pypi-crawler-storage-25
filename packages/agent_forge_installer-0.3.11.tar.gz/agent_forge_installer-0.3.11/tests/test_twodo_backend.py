from __future__ import annotations

from datetime import datetime
import os
from pathlib import Path

import pytest

from agentforge.twodo.archive import load_archive, unpack_archive
from agentforge.twodo.backend import TwoDoBackend, render_note_block, split_note_block


def test_twodo_backend_roundtrip_local_store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Roundtrip task",
        notes="human note",
        due_at=datetime(2026, 4, 15, 9, 30),
        recurrence_rule="daily",
        priority="high",
        tags=["#project/agentforge"],
        actor_id="architect",
        prompt="Run the task",
        prompt_ref="prompt.md",
    )

    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.title == "Roundtrip task"
    assert fetched.list_name == "architect"
    assert fetched.due_at == datetime(2026, 4, 15, 9, 30)
    assert fetched.recurrence_rule == "daily"
    assert fetched.priority == "high"
    assert fetched.tags == ["#project/agentforge"]
    assert fetched.prompt == "Run the task"
    assert fetched.prompt_ref == "prompt.md"

    payload = unpack_archive(load_archive(fetched.path))
    assert payload["title"] == "Roundtrip task"
    assert payload["caluid"] == fetched.list_id
    assert payload["notes"].startswith("human note")


def test_twodo_backend_parses_real_reference_task_when_available() -> None:
    root = Path("/home/agentforge/Dropbox/Apps/2Do")
    sample = root / "tod" / "o_u_k_cc565be8d94148b4b7cf1bfa0c4ec3bf_p__i_0f9e7ccd10a643a680d5103847583d5f_d_.tod"
    if not sample.exists() or not os.access(sample, os.R_OK):
        pytest.skip("Real 2Do Dropbox sample is not available in this environment.")

    backend = TwoDoBackend(Path("/home/agentforge/AgentForge"))
    task = backend.read_task("0f9e7ccd10a643a680d5103847583d5f")
    assert task is not None
    assert task.title == "Testing before Agent forge"
    assert task.notes == "91827"
    assert task.due_at is not None  # live task — don't assert specific date, it can be rescheduled
    assert task.list_name == "Inbox"
    assert task.locations
    assert task.alarms


def test_twodo_backend_reads_real_lists_and_groups_when_available() -> None:
    root = Path("/home/agentforge/Dropbox/Apps/2Do")
    col_dir = root / "col"
    cal_dir = root / "cal"
    if not col_dir.exists() or not cal_dir.exists():
        pytest.skip("Real 2Do Dropbox metadata is not available in this environment.")

    backend = TwoDoBackend(Path("/home/agentforge/AgentForge"))
    lists = backend.read_lists()
    groups = backend.read_groups()

    assert any(item.title == "Inbox" for item in lists)
    assert any(item.title == "Taches" for item in lists)
    assert groups
    assert "LISTS" in groups.values()


def test_note_block_roundtrip_preserves_agentforge_fields() -> None:
    rendered = render_note_block(
        "human note",
        actor_id="architect",
        prompt="Do the thing",
        prompt_ref="prompt.md",
        tags=["#project/agentforge"],
        last_completed_at=datetime(2026, 4, 15, 12, 30),
        next_run_override=datetime(2026, 4, 15, 18, 0),
    )
    human, metadata = split_note_block(rendered)
    assert human == "human note"
    assert metadata["actor_id"] == "architect"
    assert metadata["prompt"] == "Do the thing"
    assert metadata["prompt_ref"] == "prompt.md"
    assert metadata["tags"] == "#project/agentforge"
    assert metadata["last_completed_at"] == "2026-04-15T12:30"
    assert metadata["next_run_override"] == "2026-04-15T18:00"


def test_complete_task_monthly_advances_without_drift(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)
    created = backend.create_task(
        list_name="architect",
        title="Monthly task",
        due_at=datetime(2026, 1, 31, 9, 0),
        recurrence_rule="monthly",
        actor_id="architect",
    )
    assert backend.complete_task(created.task_id, completed_at=datetime(2026, 1, 31, 9, 5))
    fetched = backend.read_task(created.task_id)
    assert fetched is not None
    assert fetched.is_completed is False
    assert fetched.due_at == datetime(2026, 2, 28, 9, 0)
    assert fetched.last_completed_at == datetime(2026, 1, 31, 9, 5)


def test_twodo_backend_omits_empty_locations(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="No location task",
        notes="human note",
        actor_id="architect",
    )

    payload = unpack_archive(load_archive(created.path))
    assert "locations" not in payload


def test_twodo_backend_drops_legacy_raw_locations(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AGENTFORGE_2DO_ROOT", str(tmp_path / "2do"))
    backend = TwoDoBackend(tmp_path)

    created = backend.create_task(
        list_name="architect",
        title="Legacy location task",
        notes="human note",
        actor_id="architect",
    )
    created.raw["locations"] = []
    backend._write_task(created)

    payload = unpack_archive(load_archive(created.path))
    assert "locations" not in payload
