"""Task service backed by 2Do archives."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)

from agentforge.paths import resolve_vault_root
from agentforge.twodo.backend import TwoDoBackend


DEFAULT_READY_WINDOW_MINUTES = 60
HEARTBEAT_WINDOW_MINUTES = 15


@dataclass(slots=True)
class TaskRecord:
    task_id: str
    title: str
    status: str
    assignee_kind: str
    assignee_id: str
    due_at: datetime | None
    schedule_type: str
    recurrence_rule: str | None
    next_run_at: datetime | None
    last_completed_at: datetime | None
    ready_window_minutes: int
    priority: str
    tags: list[str]
    prompt_ref: str | None
    notes: str
    source: str
    source_path: str | None
    source_line: int
    created_at: datetime | None
    updated_at: datetime | None

    @property
    def can_execute(self) -> bool:
        return self.assignee_kind == "agent"


class TaskService:
    def __init__(self, root: Path) -> None:
        self.root = root
        self.backend = TwoDoBackend(root)

    def _legacy_tasks_path(self, actor_id: str, *, kind: str | None = None) -> Path:
        actor, resolved_kind = self.ensure_actor(actor_id)
        actual_kind = kind or resolved_kind
        if actual_kind == "agent":
            return resolve_vault_root(self.root) / "Agents" / actor / "tasks.md"
        return resolve_vault_root(self.root) / "Actors" / actor / "tasks.md"

    def _cleanup_legacy_tasks_view(self, actor_id: str, *, kind: str | None = None) -> Path:
        path = self._legacy_tasks_path(actor_id, kind=kind)
        if path.exists():
            logger.warning("Removing legacy tasks.md for %s — ensure tasks were migrated to 2Do", actor_id)
            path.unlink()
        return path

    def ensure_actor(self, actor_id: str) -> tuple[str, str]:
        actor = actor_id.strip().lstrip("@").lower()
        actor_kind = "agent" if (self.root / "agents" / actor / "config.json").exists() else "human"
        return actor, actor_kind

    def bootstrap_actor(self, actor_id: str) -> None:
        actor, kind = self.ensure_actor(actor_id)
        # resolve_list is idempotent: returns existing list if found, creates only when absent.
        self.backend.resolve_list(actor, create=True)
        self._cleanup_legacy_tasks_view(actor, kind=kind)

    def _to_record(self, actor_id: str, task) -> TaskRecord:
        schedule_type = "recurring" if task.recurrence_rule else "one_shot"
        next_run_at = task.next_run_override or task.due_at
        if task.next_run_override is None and task.due_at is not None and schedule_type == "one_shot":
            next_run_at = task.due_at - timedelta(minutes=DEFAULT_READY_WINDOW_MINUTES)
        return TaskRecord(
            task_id=task.task_id,
            title=task.title,
            status="done" if task.is_completed else "open",
            assignee_kind="agent" if (self.root / "agents" / actor_id / "config.json").exists() else "human",
            assignee_id=actor_id,
            due_at=task.due_at,
            schedule_type=schedule_type,
            recurrence_rule=task.recurrence_rule,
            next_run_at=next_run_at,
            last_completed_at=task.last_completed_at,
            ready_window_minutes=DEFAULT_READY_WINDOW_MINUTES,
            priority=task.priority,
            tags=task.tags,
            prompt_ref=task.prompt_ref,
            notes=task.prompt or task.notes,
            source="2do",
            source_path=str(task.path) if task.path else None,
            source_line=0,
            created_at=task.created_at,
            updated_at=task.updated_at,
        )

    def list_tasks(self, actor_id: str, *, status: str | None = None) -> list[TaskRecord]:
        actor, _ = self.ensure_actor(actor_id)
        self.bootstrap_actor(actor)
        tasks = []
        for task in self.backend.read_tasks(include_completed=True):
            if (task.list_name or "").strip().lower() != actor:
                continue
            record = self._to_record(actor, task)
            if status and record.status != status:
                continue
            tasks.append(record)
        tasks.sort(key=lambda item: (item.next_run_at or datetime.max, item.title.lower()))
        return tasks

    def create_task(
        self,
        *,
        assignee_id: str,
        title: str,
        due_at: datetime | None = None,
        recurrence_rule: str | None = None,
        priority: str = "medium",
        tags: list[str] | None = None,
        prompt_ref: str | None = None,
        notes: str = "",
        source: str = "manual",
        ready_window_minutes: int = DEFAULT_READY_WINDOW_MINUTES,
    ) -> str:
        actor, _ = self.ensure_actor(assignee_id)
        prompt = None
        if prompt_ref:
            actor_base = resolve_vault_root(self.root) / "Agents" / actor
            candidate = actor_base / prompt_ref
            if candidate.exists():
                prompt = candidate.read_text(encoding="utf-8").strip()
        task = self.backend.create_task(
            list_name=actor,
            title=title,
            notes=notes,
            due_at=due_at,
            recurrence_rule=recurrence_rule,
            priority=priority,
            tags=tags or [],
            actor_id=actor,
            prompt=prompt,
            prompt_ref=prompt_ref,
        )
        self._cleanup_legacy_tasks_view(actor)
        return task.task_id

    def update_task(
        self,
        task_id: str,
        *,
        title: str | None = None,
        recurrence_rule: str | None = None,
        prompt_ref: str | None = None,
        due_at: datetime | None = None,
        priority: str | None = None,
        tags: list[str] | None = None,
        notes: str | None = None,
    ) -> bool:
        prompt = None
        actor = None
        if prompt_ref:
            existing = self.backend.read_task(task_id)
            if existing:
                actor = (existing.actor_id or existing.list_name or "").strip().lower() or None
            if actor:
                actor_base = resolve_vault_root(self.root) / "Agents" / actor
                candidate = actor_base / prompt_ref
                if candidate.exists():
                    prompt = candidate.read_text(encoding="utf-8").strip()
        updated = self.backend.update_task(
            task_id,
            title=title,
            notes=notes,
            due_at=due_at,
            recurrence_rule=recurrence_rule,
            priority=priority,
            tags=tags,
            prompt=prompt,
            prompt_ref=prompt_ref,
        )
        if updated:
            task = self.backend.read_task(task_id)
            if task and task.list_name:
                self._cleanup_legacy_tasks_view(task.list_name)
        return updated

    def _is_actionable(self, task: TaskRecord, now: datetime) -> bool:
        if task.status != "open":
            return False
        if task.due_at is None:
            return False
        window = HEARTBEAT_WINDOW_MINUTES if task.schedule_type == "recurring" else task.ready_window_minutes
        return now >= (task.due_at - timedelta(minutes=window))

    def select_actionable(self, actor_id: str, *, now: datetime | None = None, limit: int = 8) -> list[TaskRecord]:
        now = now or datetime.now().replace(second=0, microsecond=0)
        items = [item for item in self.list_tasks(actor_id) if self._is_actionable(item, now)]
        items.sort(key=lambda task: (task.next_run_at or datetime.max, {"high": 0, "medium": 1, "low": 2}.get(task.priority, 1), task.title.lower()))
        return items[:limit]

    def render_heartbeat_payload(self, actor_id: str, *, now: datetime | None = None, limit: int = 8) -> str:
        actor, kind = self.ensure_actor(actor_id)
        if kind != "agent":
            return ""
        tasks = self.select_actionable(actor, now=now, limit=limit)
        if not tasks:
            return ""
        lines = ["## Relevant Structured Tasks", ""]
        for task in tasks:
            lines.append(f"### TASK {task.task_id} — {task.title}")
            lines.append(f"reason:: {'recurring run' if task.schedule_type == 'recurring' else 'ready window'}")
            if task.due_at:
                lines.append(f"scheduled_for:: {task.due_at.strftime('%Y-%m-%d %H:%M')}")
            if task.prompt_ref:
                lines.append(f"prompt_ref:: {task.prompt_ref}")
            if task.tags:
                lines.append(f"tags:: {' '.join(task.tags)}")
            lines.append("")
            lines.append(task.notes or task.title)
            lines.append("")
            lines.append(f"After completing this task, output exactly: TASK_DONE {task.task_id}")
            lines.append(f"If you intentionally skip it for now, output exactly: TASK_SKIP {task.task_id}")
            lines.append("")
        return "\n".join(lines).rstrip()

    def complete_task(self, task_id: str, *, result: str = "done", completed_at: datetime | None = None) -> bool:
        completed = self.backend.complete_task(task_id, completed_at=completed_at)
        if completed:
            task = self.backend.read_task(task_id)
            if task and task.list_name:
                self._cleanup_legacy_tasks_view(task.list_name)
        return completed

    def defer_task(self, task_id: str, *, deferred_until: datetime | None = None, reason: str = "skip") -> bool:
        target = deferred_until or (datetime.now().replace(second=0, microsecond=0) + timedelta(minutes=30))
        deferred = self.backend.defer_task(task_id, due_at=target)
        if deferred:
            task = self.backend.read_task(task_id)
            if task and task.list_name:
                self._cleanup_legacy_tasks_view(task.list_name)
        return deferred

    def cleanup_legacy_tasks_view(self, actor_id: str) -> Path:
        actor, kind = self.ensure_actor(actor_id)
        return self._cleanup_legacy_tasks_view(actor, kind=kind)
