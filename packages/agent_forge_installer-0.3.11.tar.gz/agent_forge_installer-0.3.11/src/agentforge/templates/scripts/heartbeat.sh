#!/usr/bin/env bash
# heartbeat.sh — Dynamic multi-agent cron runner
# Discovers agents from agents/*/ and runs their scheduled cron tasks.
# Called by OS cron every minute (or every N minutes).
# Each cron task defines its own schedule via config.json.
set -euo pipefail
export TZ=America/Montreal

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
LOG="$AGENTFORGE_ROOT/logs/heartbeat.log"
TODAY=$(date +%Y-%m-%d)
NOW=$(date +%H:%M)

mkdir -p "$AGENTFORGE_ROOT/logs"
echo "[$TODAY $NOW] === Heartbeat starting ===" >> "$LOG"

# Source environment
[ -f "$AGENTFORGE_ROOT/.env" ] && set -a && source "$AGENTFORGE_ROOT/.env" && set +a

CLAUDE_BIN="$AGENTFORGE_RUNTIME_ROOT/.local/bin/claude"
PYTHON_BIN="$AGENTFORGE_RUNTIME_ROOT/.venv/bin/python3"
[ -x "$PYTHON_BIN" ] || PYTHON_BIN="python3"

# ---------------------------------------------------------------------------
# Helper: build prompt stack and invoke claude for a cron task
# ---------------------------------------------------------------------------
run_cron_task() {
    local agent_dir="$1"
    local task_md="$2"
    local model="${3:-haiku}"
    local max_budget="${4:-0.5}"
    local agent_name
    agent_name=$(basename "$agent_dir")
    local agent_vault_dir="$AGENTFORGE_ROOT/vault/Agents/$agent_name"
    local soul_file="$agent_vault_dir/soul.md"
    local memory_file="$agent_vault_dir/memory.md"
    local daily_dir="$agent_vault_dir/daily"
    [ -f "$soul_file" ] || { [ -f "$agent_dir/soul.md" ] && soul_file="$agent_dir/soul.md"; }
    [ -f "$memory_file" ] || { [ -f "$agent_dir/memory.md" ] && memory_file="$agent_dir/memory.md"; }
    [ -d "$daily_dir" ] || { [ -d "$agent_dir/daily" ] && daily_dir="$agent_dir/daily"; }

    mkdir -p "$agent_dir/logs" "$daily_dir"

    local log_file="$agent_dir/logs/cron.log"

    # Derive config_file from task_md location
    local config_file
    config_file="$(dirname "$task_md")/config.json"

    # Build prompt stack using system/user separation to avoid greeting responses.
    # System context (--append-system-prompt): identity, shared rules, memory — sets WHO the agent is.
    # User message (-p): the task only — sets WHAT to do right now.
    # This prevents Claude (especially sonnet) from treating identity context as a conversation
    # starter and responding with greetings instead of executing the task.

    local system_context=""
    if [ -f "$AGENTFORGE_ROOT/vault/Agents/_team/CLAUDE.md" ]; then
        system_context+="$(cat "$AGENTFORGE_ROOT/vault/Agents/_team/CLAUDE.md")"$'\n\n'
    elif [ -f "$AGENTFORGE_ROOT/agents/shared/CLAUDE.md" ]; then
        system_context+="$(cat "$AGENTFORGE_ROOT/agents/shared/CLAUDE.md")"$'\n\n'
    fi
    if [ -f "$AGENTFORGE_ROOT/vault/Agents/_team/memory.md" ]; then
        system_context+="## Shared Knowledge"$'\n'"$(cat "$AGENTFORGE_ROOT/vault/Agents/_team/memory.md")"$'\n\n'
    elif [ -f "$AGENTFORGE_ROOT/agents/shared/memory.md" ]; then
        system_context+="## Shared Knowledge"$'\n'"$(cat "$AGENTFORGE_ROOT/agents/shared/memory.md")"$'\n\n'
    fi
    [ -f "$soul_file" ] && system_context+="## Soul"$'\n'"$(cat "$soul_file")"$'\n\n'
    [ -f "$memory_file" ] && system_context+="## Memory"$'\n'"$(cat "$memory_file")"

    local task_prompt=""
    [ -f "$task_md" ] && task_prompt+=$'## TÂCHE À EXÉCUTER\n\n'"$(cat "$task_md")"$'\n\n**Exécute immédiatement et complètement les instructions ci-dessus. Ne réponds pas de manière conversationnelle. Ne demande pas de confirmation. Effectue toutes les étapes.**'

    # SPECIAL HANDLING for daily_consolidation: include yesterday's daily log
    local cron_name
    cron_name=$(basename "$(dirname "$task_md")")
    if [ "$cron_name" = "daily_consolidation" ]; then
        local yesterday
        yesterday=$(date -d yesterday +%Y-%m-%d)
        local daily_log="$daily_dir/$yesterday.md"
        if [ -f "$daily_log" ] && [ -s "$daily_log" ]; then
            task_prompt+=$'\n\n'"## Yesterday's Daily Log ($yesterday)"$'\n\n'"$(cat "$daily_log")"$'\n\n'"## Output Format Instructions"$'\n'"After reviewing the above, output ONLY a markdown list of durable facts to consolidate, formatted as:"$'\n'"- [fact 1]"$'\n'"- [fact 2]"$'\n'"..."$'\n'$'\n'"If no durable facts found, output: CONSOLIDATION_OK (nothing new)"$'\n'"If consolidation complete, output: CONSOLIDATION_OK"
        else
            task_prompt+=$'\n\n'"No daily log found for $yesterday. Output exactly: CONSOLIDATION_SKIP"
        fi
    fi

    # SPECIAL HANDLING for proactive_check: inject todos and pending tasks
    if [ "$cron_name" = "proactive_check" ]; then
        local tasks_dir="$agent_dir/tasks"
        local inject_context=""
        local todo_context=""

        todo_context=$("$PYTHON_BIN" -m agentforge.todo_cli due --root "$AGENTFORGE_ROOT" --agent "$agent_name" --limit 8 2>/dev/null || true)
        if [ -n "$todo_context" ]; then
            inject_context+=$'\n\n'"$todo_context"
        fi

        if [ -d "$tasks_dir" ]; then
            local pending_tasks=""
            for task_file in "$tasks_dir"/*.json; do
                [ -f "$task_file" ] || continue
                pending_tasks+="$(cat "$task_file")"$'\n'
            done
            if [ -n "$pending_tasks" ]; then
                inject_context+=$'\n\n## Delegated Tasks (JSON)\n\n'"$pending_tasks"
            fi
        fi

        if [ -n "$inject_context" ]; then
            task_prompt+="$inject_context"
        fi
    fi

    # Inject agent env vars
    export AGENT_NAME="$agent_name"
    export AGENT_DIR="$agent_dir"
    export HOME="$AGENTFORGE_RUNTIME_ROOT"

    echo "[$TODAY $NOW] Running cron $cron_name for $agent_name (model=$model)" >> "$log_file"

    local response
    response=$("$CLAUDE_BIN" -p \
        --model "$model" \
        --dangerously-skip-permissions \
        --output-format text \
        --max-budget-usd "$max_budget" \
        --append-system-prompt "$system_context" \
        "$task_prompt" 2>&1) || true

    echo "[$TODAY $NOW] Response: ${response:0:500}" >> "$log_file"
    echo "---" >> "$log_file"

    # Write canary output — proof that this cron ran successfully
    local canary_file="$agent_dir/cron/$cron_name/.canary"
    mkdir -p "$(dirname "$canary_file")"
    echo "$(date --iso-8601=seconds) $cron_name OK" >> "$canary_file"

    # SPECIAL HANDLING for daily_consolidation: parse response and write to memory.md
    if [ "$cron_name" = "daily_consolidation" ]; then
        if echo "$response" | grep -q "CONSOLIDATION_OK\|CONSOLIDATION_SKIP"; then
            # Valid consolidation response
            if ! echo "$response" | grep -q "nothing new\|CONSOLIDATION_SKIP"; then
                # Has facts to consolidate; extract and append to memory.md
                local facts
                facts=$(echo "$response" | sed -n '/^- /p' | head -20)
                if [ -n "$facts" ]; then
                    {
                        echo ""
                        echo "## $(date +%Y-%m-%d)"
                        echo "$facts"
                    } >> "$memory_file"
                    echo "[$TODAY $NOW] Consolidated $(echo "$facts" | wc -l) facts to memory.md" >> "$log_file"
                fi
            fi
        fi
    fi

    # Alert if Claude flagged an issue
    if echo "$response" | grep -q "⚠️ ALERTE:"; then
        local alert_detail
        alert_detail=$(echo "$response" | grep -o "⚠️ ALERTE:.*" | head -1)
        "$AGENTFORGE_RUNTIME_ROOT/scripts/telegram_send.sh" heartbeat "$alert_detail" 2>/dev/null || true
        echo "[$TODAY $NOW] Alert sent: $alert_detail" >> "$log_file"
    fi

    # Delivery confirmation: alert on silent failure if expected
    if [ -f "$config_file" ]; then
        local expects_signal
        expects_signal=$(python3 -c "
import json
try:
    d = json.load(open('$config_file'))
    print(str(d.get('expects_completion_signal', False)).lower())
except: print('false')
" 2>/dev/null || echo "false")
        if [ "$expects_signal" = "true" ]; then
            if ! echo "$response" | grep -qE "TASK_DONE|TASK_SKIP"; then
                local fail_msg="⚠️ Silent failure: $agent_name/$cron_name — no TASK_DONE/TASK_SKIP signal received. Response: ${response:0:300}"
                "$AGENTFORGE_RUNTIME_ROOT/scripts/telegram_send.sh" dev "$fail_msg" 2>/dev/null || true
                echo "[$TODAY $NOW] SILENT FAILURE: no completion signal for $cron_name" >> "$log_file"
            fi
        fi
    fi
}

# ---------------------------------------------------------------------------
# Helper: check if a scheduled cron should run now
# schedule format: "MINUTE HOUR DOM MON DOW" (standard cron)
# Returns 0 (should run) or 1 (skip)
# Uses a .last_run file per agent to avoid duplicate execution within the same minute
# ---------------------------------------------------------------------------
cron_schedule_matches() {
    local cron_dir="$1"
    local agent_name="$2"
    local config_file="$cron_dir/config.json"

    [ -f "$config_file" ] || return 1

    # Check enabled
    local enabled
    enabled=$(python3 -c "
import json, sys
try:
    d = json.load(open('$config_file'))
    print(str(d.get('enabled', True)).lower())
except: print('false')
" 2>/dev/null || echo "false")
    [ "$enabled" = "true" ] || return 1

    # Get schedule
    local schedule
    schedule=$(python3 -c "
import json
try:
    d = json.load(open('$config_file'))
    print(d.get('schedule', ''))
except: print('')
" 2>/dev/null || echo "")
    [ -n "$schedule" ] || return 1

    # Check last run to avoid duplicate execution per agent
    local last_run_file="$cron_dir/.last_run.$agent_name"
    local current_min
    current_min=$(date +%Y%m%d%H%M)
    if [ -f "$last_run_file" ] && [ "$(cat "$last_run_file")" = "$current_min" ]; then
        return 1
    fi

    # Check if schedule matches current time
    local matches
    matches=$(python3 - << PYEOF
from datetime import datetime
import sys

schedule = "$schedule"
now = datetime.now()
parts = schedule.split()
if len(parts) != 5:
    print("no")
    sys.exit(0)

def field_match(field, value, max_val=None):
    if field == '*':
        return True
    if field.startswith('*/'):
        step = int(field[2:])
        return value % step == 0
    try:
        return int(field) == value
    except:
        return False

minute_s, hour_s, dom_s, mon_s, dow_s = parts
# cron dow: 0=Sunday, 1=Monday... 6=Saturday
# Python weekday: 0=Monday... 6=Sunday → convert: Sun=0
py_dow = (now.weekday() + 1) % 7  # Mon=1, ..., Sat=6, Sun=0

ok = (field_match(minute_s, now.minute) and
      field_match(hour_s, now.hour) and
      field_match(dom_s, now.day) and
      field_match(mon_s, now.month) and
      field_match(dow_s, py_dow))

print("yes" if ok else "no")
PYEOF
)
    [ "$matches" = "yes" ] || return 1

    # Mark as ran this minute
    echo "$current_min" > "$last_run_file"
    return 0
}

# ---------------------------------------------------------------------------
# Helper: check if heartbeat (interval-based) should run
# config uses interval_minutes instead of schedule
# ---------------------------------------------------------------------------
heartbeat_should_run() {
    local cron_dir="$1"
    local agent_name="$2"
    local config_file="$cron_dir/config.json"

    [ -f "$config_file" ] || return 1

    local enabled
    enabled=$(python3 -c "
import json
try:
    d = json.load(open('$config_file'))
    print(str(d.get('enabled', True)).lower())
except: print('false')
" 2>/dev/null || echo "false")
    [ "$enabled" = "true" ] || return 1

    local interval_minutes
    interval_minutes=$(python3 -c "
import json
try:
    d = json.load(open('$config_file'))
    print(d.get('interval_minutes', 60))
except: print(60)
" 2>/dev/null || echo "60")

    # Check last run (per-agent)
    local last_run_file="$cron_dir/.last_run.$agent_name"
    local now_epoch
    now_epoch=$(date +%s)

    if [ -f "$last_run_file" ]; then
        local last_epoch
        last_epoch=$(cat "$last_run_file" 2>/dev/null || echo "0")
        local elapsed=$(( (now_epoch - last_epoch) / 60 ))
        if [ "$elapsed" -lt "$interval_minutes" ]; then
            return 1
        fi
    fi

    # Mark as ran now
    echo "$now_epoch" > "$last_run_file"
    return 0
}

# ---------------------------------------------------------------------------
# Helper: get a string config value from JSON
# ---------------------------------------------------------------------------
get_json_str() {
    local file="$1"
    local key="$2"
    local default="$3"
    python3 -c "
import json
try:
    print(json.load(open('$file')).get('$key', '$default'))
except: print('$default')
" 2>/dev/null || echo "$default"
}

# ---------------------------------------------------------------------------
# Main: iterate over all agents
# ---------------------------------------------------------------------------
for agent_dir in "$AGENTFORGE_ROOT/agents/"/*/; do
    agent_name=$(basename "$agent_dir")

    # Skip special dirs
    case "$agent_name" in
        shared|_template) continue ;;
    esac

    # Skip if no config (not a real agent)
    [ -f "$agent_dir/config.json" ] || continue

    echo "[$TODAY $NOW] Processing agent: $agent_name" >> "$LOG"

    # 1. Run ROOT built-in crons (apply to ALL agents)
    if [ -d "$AGENTFORGE_ROOT/cron" ]; then
        for root_cron_dir in "$AGENTFORGE_ROOT/cron/"/*/; do
            cron_name=$(basename "$root_cron_dir")
            task_md="$root_cron_dir/task.md"
            [ -f "$task_md" ] || continue

            # Check for per-agent config override
            agent_override="$agent_dir/cron/$cron_name/config.json"
            if [ -f "$agent_override" ]; then
                effective_config_dir="$agent_dir/cron/$cron_name"
            else
                effective_config_dir="$root_cron_dir"
            fi

            if cron_schedule_matches "$effective_config_dir" "$agent_name"; then
                model=$(get_json_str "$effective_config_dir/config.json" "model" "haiku")
                budget=$(get_json_str "$effective_config_dir/config.json" "max_budget_usd" "0.5")
                echo "[$TODAY $NOW] Root cron: $cron_name for $agent_name" >> "$LOG"
                run_cron_task "$agent_dir" "$task_md" "$model" "$budget"
            fi
        done
    fi

    # 2. Run per-agent crons (heartbeat + instance-defined crons)
    if [ -d "$agent_dir/cron" ]; then
        for cron_dir in "$agent_dir/cron/"/*/; do
            cron_name=$(basename "$cron_dir")
            task_md="$cron_dir/task.md"
            config_file="$cron_dir/config.json"

            [ -f "$task_md" ] || continue
            [ -f "$config_file" ] || continue

            # Heartbeat uses interval_minutes; other crons use schedule
            if [ "$cron_name" = "heartbeat" ]; then
                if heartbeat_should_run "$cron_dir" "$agent_name"; then
                    model=$(get_json_str "$config_file" "model" "haiku")
                    budget=$(get_json_str "$config_file" "max_budget_usd" "0.5")
                    run_cron_task "$agent_dir" "$task_md" "$model" "$budget"
                fi
            else
                if cron_schedule_matches "$cron_dir" "$agent_name"; then
                    model=$(get_json_str "$config_file" "model" "haiku")
                    budget=$(get_json_str "$config_file" "max_budget_usd" "0.5")
                    run_cron_task "$agent_dir" "$task_md" "$model" "$budget"
                fi
            fi
        done
    fi
done

echo "[$TODAY $NOW] === Heartbeat done ===" >> "$LOG"
