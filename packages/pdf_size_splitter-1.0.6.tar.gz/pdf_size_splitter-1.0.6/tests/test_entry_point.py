import pytest
import os
import sys
from io import StringIO
from unittest.mock import patch

# 実行時にパスを追加して、スクリプト直接実行でも動作するようにする
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_main_no_output_messages(tmp_path, capsys):
    """Unixスタイル準拠：開始・終了メッセージが出力されないことを確認"""
    from pdf_size_splitter import main

    # Given: テスト用のPDFと出力ディレクトリ
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    output_dir = str(tmp_path)
    max_size = 10000

    # When: main関数を実行（コマンドライン引数をモック）
    with patch('sys.argv', ['pdf_size_splitter.py', input_pdf, str(max_size), '-o', output_dir]):
        main()

    # Then: 標準出力に開始・終了メッセージが出力されていないこと
    captured = capsys.readouterr()
    assert "分割処理を開始します" not in captured.out
    assert "分割が完了しました" not in captured.out

def test_main_value_error(tmp_path, capsys):
    """ValueErrorが発生した場合、エラーメッセージが出力され、exitコード1で終了することを確認"""
    from pdf_size_splitter import main

    # Given: 存在しないファイル
    input_pdf = "non_existent.pdf"
    output_dir = str(tmp_path)
    max_size = 10000

    # When: main関数を実行
    with patch('sys.argv', ['pdf_size_splitter.py', input_pdf, str(max_size), '-o', output_dir]):
        with pytest.raises(SystemExit) as exc_info:
            main()

    # Then: exitコードが1であること
    assert exc_info.value.code == 1

    # Then: 標準エラー出力にエラーメッセージが出力されていること
    captured = capsys.readouterr()
    assert "エラー:" in captured.err

def test_main_unexpected_error(tmp_path, capsys):
    """予期せぬエラーが発生した場合、エラーメッセージが出力され、exitコード1で終了することを確認"""
    from pdf_size_splitter import main

    # Given: split_pdf_by_sizeをモックして予期せぬエラーを発生させる
    input_pdf = os.path.join("tests", "test_data", "three_pages.pdf")
    output_dir = str(tmp_path)
    max_size = 10000

    # When: split_pdf_by_sizeが予期せぬエラーを発生させるようにモック
    with patch('sys.argv', ['pdf_size_splitter.py', input_pdf, str(max_size), '-o', output_dir]):
        with patch('pdf_size_splitter.split_pdf_by_size', side_effect=RuntimeError("予期せぬエラー")):
            with pytest.raises(SystemExit) as exc_info:
                main()

    # Then: exitコードが1であること
    assert exc_info.value.code == 1

    # Then: 標準エラー出力にエラーメッセージが出力されていること
    captured = capsys.readouterr()
    assert "予期せぬエラーが発生しました" in captured.err
