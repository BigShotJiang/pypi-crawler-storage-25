import argparse
import sys
import os

# 実行時にパスを追加して、スクリプト直接実行でも動作するようにする
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.splitter import split_pdf_by_size

def main():
    parser = argparse.ArgumentParser(description="PDFファイルを指定したサイズ（バイト）で分割するツール")
    parser.add_argument("input_pdf", help="分割したいPDFファイルのパス")
    parser.add_argument("max_size", type=int, help="分割する上限サイズ（バイト単位）")
    parser.add_argument("-o", "--output", default=".", help="出力先のディレクトリ（デフォルトは現在のディレクトリ）")
    parser.add_argument("-v", "--verbose", action="store_true", help="詳細な進捗情報を表示する")

    args = parser.parse_args()

    try:
        split_pdf_by_size(args.input_pdf, args.max_size, args.output, args.verbose)
    except ValueError as e:
        print(f"エラー: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"予期せぬエラーが発生しました: {e}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
