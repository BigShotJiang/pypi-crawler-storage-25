import os
from pypdf import PdfReader
from pypdf.errors import PdfStreamError, PdfReadError, FileNotDecryptedError
from .pdf_extraction import extract_pages
from .split_logic import find_split_point

def split_pdf_by_size(input_pdf, max_size, output_dir, verbose=False):
    # ファイル存在チェック
    if not os.path.exists(input_pdf):
        raise ValueError("ファイルが存在しません")

    # ファイル読み取り権限チェック
    if not os.access(input_pdf, os.R_OK):
        raise ValueError("ファイルを読み取る権限がありません")

    # ディレクトリ存在チェック
    if not os.path.isdir(output_dir):
        raise ValueError("出力先ディレクトリが存在しません")

    # 上限サイズのチェック
    if max_size <= 0:
        raise ValueError("上限サイズは1以上の数値を指定してください")

    try:
        reader = PdfReader(input_pdf)
    except (PdfStreamError, PdfReadError) as e:
        raise ValueError("無効なPDFファイルです")

    try:
        total_pages = len(reader.pages)
    except FileNotDecryptedError:
        raise ValueError("暗号化されたPDFファイルはサポートされていません")

    total_file_size = os.path.getsize(input_pdf)

    # 指定サイズ以下の場合は分割不要
    if total_file_size <= max_size:
        if verbose:
            print(f"処理をスキップします: {input_pdf}（サイズ{total_file_size}バイトは上限{max_size}バイト以下）")
        return

    if verbose:
        print(f"処理を開始します: {input_pdf}")

    base_name = os.path.splitext(os.path.basename(input_pdf))[0]

    start_page = 0
    part_number = 1

    while start_page < total_pages:
        # 上限に収まる終了ページを見つける
        end_page = find_split_point(input_pdf, start_page, max_size)

        # 該当ページを抽出してファイルに保存
        pdf_data = extract_pages(input_pdf, start_page, end_page)
        output_filename = os.path.join(output_dir, f"{base_name}_part{part_number}.pdf")

        with open(output_filename, "wb") as f:
            f.write(pdf_data)

        if verbose:
            page_count = end_page - start_page + 1
            print(f"生成中: {output_filename} (ページ {start_page + 1}-{end_page + 1}, {page_count}ページ)")

        # 次の分割へ進む
        start_page = end_page + 1
        part_number += 1

    if verbose:
        print(f"完了しました: {part_number - 1}個のファイルを生成しました")
