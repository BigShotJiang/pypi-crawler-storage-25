import time
from dataclasses import asdict, dataclass
from email.utils import parsedate_to_datetime
from http.cookies import Morsel
from typing import Any


def _expires_from_morsel(morsel: Morsel[str]) -> float | None:
    max_age_raw = morsel.get("max-age")
    if max_age_raw is not None and max_age_raw != "":
        try:
            age_sec = int(str(max_age_raw).strip(), 10)
        except (TypeError, ValueError):
            pass
        else:
            return time.time() + float(age_sec)

    raw = morsel.get("expires")
    if raw in (None, ""):
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    s = str(raw).strip()
    try:
        return float(s)
    except ValueError:
        pass
    try:
        dt = parsedate_to_datetime(s)
    except (TypeError, ValueError):
        return None
    if dt is None:
        return None
    return dt.timestamp()


@dataclass
class UniversalCookie:
    name: str
    value: str
    domain: str
    path: str = "/"
    expires: float | None = None
    http_only: bool = False
    secure: bool = False
    same_site: str | None = None

    @classmethod
    def from_playwright(cls, cookie: dict[str, Any]) -> "UniversalCookie":
        expires = cookie.get("expires")
        if expires == -1:
            expires = None

        return cls(
            name=cookie["name"],
            value=cookie["value"],
            domain=cookie.get("domain", ""),
            path=cookie.get("path", "/"),
            expires=expires,
            http_only=cookie.get("httpOnly", False),
            secure=cookie.get("secure", False),
            same_site=cookie.get("sameSite"),
        )

    @classmethod
    def from_playwright_any(cls, cookie: Any) -> "UniversalCookie":
        """Элемент из ``context.cookies()``: dict или объект с атрибутами Playwright."""
        if isinstance(cookie, dict):
            return cls.from_playwright(dict(cookie))
        return cls.from_playwright(
            {
                "name": getattr(cookie, "name", ""),
                "value": getattr(cookie, "value", ""),
                "domain": getattr(cookie, "domain", ""),
                "path": getattr(cookie, "path", "/"),
                "expires": getattr(cookie, "expires", None),
                "httpOnly": getattr(cookie, "httpOnly", False),
                "secure": getattr(cookie, "secure", False),
                "sameSite": getattr(cookie, "sameSite", None),
            }
        )

    def to_playwright(self) -> dict[str, Any]:
        cookie: dict[str, Any] = {
            "name": self.name,
            "value": self.value,
            "domain": self.domain,
            "path": self.path or "/",
            "httpOnly": self.http_only,
            "secure": self.secure,
            "sameSite": self.same_site or "Lax",
            "expires": self.expires if self.expires is not None else -1,
        }
        return cookie

    @classmethod
    def from_db(cls, row: dict[str, Any]) -> "UniversalCookie":
        return cls(
            name=row["name"],
            value=row["value"],
            domain=row["domain"],
            path=row.get("path") or "/",
            expires=row.get("expires"),
            http_only=bool(row.get("http_only", False)),
            secure=bool(row.get("secure", False)),
            same_site=row.get("same_site"),
        )

    def to_db(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_aiohttp_morsel(cls, morsel: Morsel[str]) -> "UniversalCookie":
        same_site = morsel.get("samesite") or morsel.get("SameSite")
        if same_site:
            same_site = str(same_site)

        return cls(
            name=morsel.key,
            value=morsel.value,
            domain=str(morsel.get("domain") or ""),
            path=str(morsel.get("path") or "/"),
            expires=_expires_from_morsel(morsel),
            http_only=bool(morsel.get("httponly")),
            secure=bool(morsel.get("secure")),
            same_site=same_site,
        )
