# App events в tp_common: `AppEventService`

Ниже — описание модуля **`tp_common.kafka.app_event`**: асинхронный сервис для записи и чтения **app-events** в Kafka. Сообщение — это **весь JSON тела записи** (одна Pydantic-модель), без обёртки «data» и без пары `before` / `after`, как в CDC. Такой контракт удобен для **исходящих событий к приложениям и интеграциям**: доменная схема задаётся наследником `BaseAppEventMessage`, а топик выводится из **пространства имён** и опционального **сегмента получателя**.

Подключение к брокеру — через **`KafkaConnector`** и **`aiokafka`**. Публичный API, пакетное чтение, long-poll и контракт **одна партиция на подписанный топик** — в docstring модуля `app_event.py` и в примерах каталога `tp_common/kafka/app_event/examples/`.

---

## Назначение и форма сообщения

**App-event** — событие «для клиента»: результат обработки, уведомление, снимок состояния в форме, удобной потребителю. В Kafka лежит JSON, который целиком парсится в ваш класс сообщения (например `TaskAppEventMessage` в примерах или собственный `AppEventMessage` в сервисе).

Базовый слой **`BaseAppEventMessage`** задаёт общие поля: `timestamp` (UTC), `schema_version`, обязательный **`event_type`**, конфиг `extra="allow"` для мягких миграций. Наследник добавляет доменные поля и при необходимости ужесточает `model_config`.

---

## Топик: `EVENT_NAMESPACE` и `service_name`

Наследник **`AppEventService`** обязан задать классовые атрибуты:

- **`EVENT_NAMESPACE`** — префикс пространства имён (строка топика или его корень);
- **`MESSAGE_CLASS`** — тип сообщения (подкласс `BaseAppEventMessage`).

При создании экземпляра можно передать **`service_name`**: тогда чтение/подписка по умолчанию идут на топик **`EVENT_NAMESPACE.<service_name>`**. Если сегмент не задан (пустая строка / `None`), используется только **`EVENT_NAMESPACE`**.

При **`publish(message, target_service_name=...)`** запись уходит в топик с сегментом **`target_service_name`**, если он непустой; иначе используется сегмент экземпляра (`service_name` из конструктора). Так один продюсер может адресовать разные «витрины» подписчиков в рамках одного `EVENT_NAMESPACE`.

---

## Схема 1. Поток app-events

```mermaid
flowchart LR
  SVC["Сервис приложения\n(AppEventService)"]
  P["publish(message,\ntarget_service_name?)"]
  T0["EVENT_NAMESPACE"]
  T1["EVENT_NAMESPACE.client_a"]
  T2["EVENT_NAMESPACE.client_b"]
  SVC --> P
  P --> T0
  P --> T1
  P --> T2
  T0 --> R["Подписчики / HTTP API"]
  T1 --> R
  T2 --> R
```

Чтение выполняется тем же классом сервиса: задаётся `consumer_group`, при необходимости **`service_name`**, затем контекст **`subscription()`** и методы пакетного чтения (см. код и примеры).

---

## Схема 2. Тело сообщения в Kafka

```mermaid
flowchart TB
  subgraph BA["BaseAppEventMessage и наследник"]
    direction TB
    et["event_type, timestamp, schema_version, …"]
    dom["доменные поля наследника"]
    et --- dom
  end
```

Тело записи в топике — один JSON-объект, соответствующий модели **`MESSAGE_CLASS`**.

---

## Схема 3. Выбор топика при `publish`

```mermaid
flowchart TD
  A["publish(message, target_service_name?)"]
  B{"effective = target_service_name\nили service_name экземпляра"}
  C["Топик = EVENT_NAMESPACE"]
  D["Топик = EVENT_NAMESPACE.<effective>"]
  A --> B
  B -->|"пусто / не задано"| C
  B -->|"непустая строка"| D
```

---

## Практические замечания

- **`retry_enabled`**: по умолчанию включены бесконечные повторы через `@retry_forever` на операциях Kafka; для **FastAPI** и других HTTP-обработчиков часто передают **`False`**, чтобы при падении брокера не зависать в ретраях (см. пример `01_fast_api` в `kafka/app_event/examples/`).
- Расширять контракт сообщения лучше через новые поля и **`schema_version`**, согласуя читателей; жёсткое `extra="forbid"` на наследнике включайте, когда нужен строгий контроль полей.
