"""Сервис app-событий: запись/чтение результатов (JSON тела сообщения), service_name."""

from tp_common.kafka.app_event.app_event import AppEventBatchItem, AppEventService
from tp_common.kafka.app_event.schemas import BaseAppEventMessage

__all__ = ["AppEventBatchItem", "AppEventService", "BaseAppEventMessage"]
