"""
Сервис для отправки и чтения результатов обработки с поддержкой суффикса топика ``service_name``.

Тело сообщения — весь JSON (модель MESSAGE_CLASS без обёртки data). Поддерживает:
- чтение с явным ``next_offset`` (seek + commit позиции, пачка без финального commit);
- чтение с **сохранённого в брокере смещения consumer group** (в терминах Kafka — «committed offset» группы: не путать с тем, что пачка «коммитится» здесь — после пачки новый offset в брокер **не** записывается);
- long-poll по ``read_timeout_sec``;
- контракт **одна партиция** на подписанный топик;
- имя топика: ``EVENT_NAMESPACE`` или ``EVENT_NAMESPACE.<service_name>`` — сегмент задаётся
  при ``publish(..., service_name=...)`` и при ``subscription(service_name=...)``, один экземпляр
  сервиса может работать с разными топиками.

**HTTP long-poll:** рекомендуемый контракт тела ответа — ``BaseAppEventMessagesResponse``
(``messages`` + ``nextOffset``). Поле ``nextOffset`` задаёт **сервер**; клиент в следующем запросе
передаёт его в query как есть (см. ``docs/batch_read_and_offsets.md``, примеры ``01_fast_api`` / ``03_read_events_api_client``).
Внутри обработчика по-прежнему используется пачка ``AppEventBatchItem`` (``message`` + ``offset``) из ``read_*_ready``.

**Пакетное чтение** (сценарии А/Б) нужно вызывать при уже запущенной подписке. Рекомендуемый
паттерн — контекст ``subscription()`` и методы ``*_ready`` (они ждут assignment партиций)::

    async with service:
        async with service.subscription(service_name="my_reader"):
            items = await service.read_from_committed_ready(
                limit=100,
                read_timeout_sec=25.0,
            )
            # или: await service.read_from_next_offset_ready(next_offset, ...)

Без ``async with service.subscription():`` consumer не подписан и не стартован — чтение не сработает.

Схема сценариев, commit и роли клиента/сервера для long-poll: ``docs/batch_read_and_offsets.md``.
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass
from typing import Any, ClassVar, Literal, TypeVar, cast

from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from aiokafka.structs import TopicPartition
from pydantic import ValidationError

from tp_common.decorators.decorator_retry_forever import retry_forever
from tp_common.kafka.app_event.schemas import BaseAppEventMessage
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_logger.tp_logging import TpLogger

logger = logging.getLogger(__name__)

MessageT = TypeVar("MessageT", bound=BaseAppEventMessage)

# Пауза между getone после появления первого сообщения — «тишина» конца пачки.
_BATCH_READ_IDLE_SLICE_SEC = 0.5


@dataclass(frozen=True, slots=True)
class AppEventBatchItem[MessageT: BaseAppEventMessage]:
    """Элемент пакетного чтения: распарсенное сообщение и offset записи Kafka."""

    message: MessageT
    offset: int


def _normalize_topic_service_name(name: str | None) -> str | None:
    """None / пустая строка → базовый топик ``EVENT_NAMESPACE``; иначе непустой сегмент без пробелов по краям."""
    if name is None:
        return None
    s = name.strip()
    return s or None


def _value_to_dict(value: bytes | str | dict[str, Any]) -> dict[str, Any]:
    """Парсит value из Kafka в словарь. Ожидается JSON-объект (тело сообщения)."""
    if isinstance(value, dict):
        return value
    if isinstance(value, bytes):
        data = json.loads(value.decode("utf-8"))
    elif isinstance(value, str):
        data = json.loads(value)
    else:
        raise TypeError(f"Неподдерживаемый тип value: {type(value).__name__}")
    if not isinstance(data, dict):
        raise ValueError("JSON не является объектом")
    return data


def _require_single_assigned_partition(consumer: AIOKafkaConsumer) -> TopicPartition:
    """Ожидается ровно одна назначенная партиция (продуктовый контракт)."""
    parts = consumer.assignment()
    n = len(parts)
    if n != 1:
        raise ValueError(
            f"Ожидается ровно одна назначенная партиция топика, получено: {n}"
        )
    return next(iter(parts))


class _AsyncPopMessage[MessageT: BaseAppEventMessage]:
    """Async контекст: при входе — pop(); при успешном выходе — commit()."""

    __slots__ = ("_event", "_timeout", "_message")

    def __init__(
        self,
        event: AppEventService[MessageT],
        timeout: float,
    ) -> None:
        self._event = event
        self._timeout = timeout
        self._message: MessageT | None = None

    async def __aenter__(self) -> MessageT | None:
        self._message = await self._event._pop(timeout=self._timeout)
        return self._message

    async def __aexit__(
        self,
        exc_type: Any,
        exc_val: Any,
        exc_tb: Any,
    ) -> Literal[False]:
        if exc_type is None and self._message is not None:
            await self._event._commit()
        return False


class AppEventService[MessageT: BaseAppEventMessage]:
    """
    Асинхронный сервис для записи и чтения результатов (тело сообщения — JSON модели MESSAGE_CLASS).

    Один сервис пишет в топик (publish), другой читает (pop/subscription).
    Наследник задаёт EVENT_NAMESPACE и MESSAGE_CLASS (схема сообщения = весь JSON).

    Пакетное чтение рассчитано на топик с **одной партицией**; иначе — ValueError.

    Для ``read_from_committed_ready`` / ``read_from_next_offset_ready`` сначала откройте
    ``async with service.subscription(service_name=...)``, затем вызывайте метод внутри блока
    (см. модульный docstring).

    Публичный API: ``subscription``, ``publish``, ``pop``, ``read_from_committed_ready``,
    ``read_from_next_offset_ready``, ``close`` и контекстный менеджер сервиса (``async with service``).
    """

    EVENT_NAMESPACE: ClassVar[str]
    MESSAGE_CLASS: ClassVar[type[BaseAppEventMessage]]

    def __init__(
        self,
        connector: KafkaConnector,
        logger: TpLogger,
        *,
        consumer_group: str | None = None,
        schema_alert_interval_seconds: float = 600,
        schema_alert_callback: (
            Callable[[str], None] | Callable[[str], Awaitable[None]] | None
        ) = None,
        skip_on_parse_error: bool = False,
        retry_enabled: bool = True,
    ) -> None:
        """
        connector: фабрика/настройки подключения к Kafka (consumer и producer).
        logger: логгер сервиса.
        consumer_group: идентификатор группы консьюмера; нужен для чтения и подписки.
        schema_alert_interval_seconds: пауза в секундах между повторными оповещениями
            после остановки из-за несовпадения схемы сообщений.
        schema_alert_callback: опционально — синхронный или async вызов со строкой
            сообщения об ошибке схемы (вместе с циклом Critical в логе).
        skip_on_parse_error: при True при ошибке парсинга JSON/модели коммитим offset
            и читаем следующие записи.
        retry_enabled: при True (по умолчанию) методы с ``@retry_forever`` повторяют
            операции Kafka при сбоях. В FastAPI и других HTTP-обработчиках обычно
            передают False, чтобы при проблемах с брокером не зависать в бесконечных
            ретраях и вернуть ошибку клиенту (см. пример ``01_fast_api``).
        """
        self.connector = connector
        self.consumer_group = consumer_group
        self._active_topic_service_name: str | None = None

        self._consumer: AIOKafkaConsumer | None = None
        self._producer: AIOKafkaProducer | None = None
        self._last_message: Any | None = None

        self._schema_alert_interval_seconds = schema_alert_interval_seconds
        self._schema_alert_callback = schema_alert_callback
        self._skip_on_parse_error = skip_on_parse_error

        self.logger = logger
        self._msg_cls = cast(type[MessageT], self.__class__.MESSAGE_CLASS)

        self.retry_enabled = retry_enabled

    @property
    def topic_name(self) -> str:
        """Текущий топик подписки (для логов); вне ``subscription()`` — базовый ``EVENT_NAMESPACE``."""
        return self._topic_for_service_name(self._active_topic_service_name)

    def _topic_for_service_name(self, service_name: str | None) -> str:
        """Имя топика: EVENT_NAMESPACE или EVENT_NAMESPACE.<service_name>."""
        segment = _normalize_topic_service_name(service_name)
        if segment is None:
            return self.__class__.EVENT_NAMESPACE
        return f"{self.__class__.EVENT_NAMESPACE}.{segment}"

    # --- Consumer / подписка ---

    @retry_forever(
        start_message="Подписка на топик Kafka: {topic_name}",
        error_message="Ошибка при подписке на топик Kafka {topic_name}: {e}",
    )
    async def _sub(self) -> None:
        """Подписывается на топик и запускает consumer."""
        topic = self._topic_for_service_name(self._active_topic_service_name)
        consumer = await self._get_consumer()
        consumer.subscribe([topic])
        await consumer.start()

    async def _unsub(self) -> None:
        """Отписывается от топика и останавливает consumer."""
        if self._consumer is not None:
            with suppress(Exception):
                await self._consumer.stop()

    async def close(self) -> None:
        """Закрывает consumer и producer, освобождает соединения."""
        self._last_message = None
        if self._consumer is not None:
            with suppress(Exception):
                await self._consumer.stop()
            self._consumer = None
        if self._producer is not None:
            with suppress(Exception):
                await self._producer.stop()
            self._producer = None

    async def __aenter__(self) -> AppEventService[MessageT]:
        """Вход в контекст: возвращает self. При выходе вызывается close()."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> Literal[False]:
        """Выход из контекста: закрывает consumer и producer."""
        await self.close()
        return False

    @asynccontextmanager
    async def subscription(
        self,
        *,
        service_name: str | None = None,
    ) -> AsyncGenerator[None]:
        """
        Async контекст: при входе — подписка и ``consumer.start()``, при выходе — остановка.

        service_name: сегмент топика ``EVENT_NAMESPACE.<service_name>``; ``None`` / пусто — только
            ``EVENT_NAMESPACE``.

        Внутри блока вызывайте пакетное чтение, например::

            async with service.subscription(service_name="my_reader"):
                items = await service.read_from_committed_ready(...)
                # или read_from_next_offset_ready(next_offset, ...)
        """
        self._active_topic_service_name = _normalize_topic_service_name(service_name)
        await self._sub()
        try:
            yield
        finally:
            await self._unsub()
            self._active_topic_service_name = None
            await self.close()

    @retry_forever(
        start_message="Коммит последнего сообщения в Kafka, топик {topic_name}",
        error_message="Ошибка при коммите в Kafka, топик {topic_name}: {e}",
    )
    async def _commit(self) -> None:
        """Коммитит последнее прочитанное сообщение в Kafka."""
        if self._last_message and self._consumer:
            await self._consumer.commit()

    @retry_forever(
        start_message="Коммит сообщения в Kafka без стартового лога, топик {topic_name}",
        error_message="Ошибка при коммите в Kafka, топик {topic_name}: {e}",
    )
    async def _commit_silent(self) -> None:
        """Коммитит без лога старта."""
        if self._last_message and self._consumer:
            await self._consumer.commit()

    @retry_forever(
        start_message="Смещение consumer в конец топика {topic_name} (seek_to_end)",
        error_message="Ошибка при смещении в конец топика {topic_name}: {e}",
    )
    async def _seek_to_end(self) -> None:
        """
        Переводит offset consumer group на конец топика (одна партиция).
        Вызывать внутри ``subscription()`` после назначения партиций.
        """
        consumer = await self._get_consumer()
        for _ in range(50):
            parts = consumer.assignment()
            if parts:
                tp = _require_single_assigned_partition(consumer)
                await consumer.seek_to_end(tp)
                next_offset = await consumer.position(tp)
                await consumer.commit({tp: next_offset})
                self.logger.info(
                    "Смещение выполнено до конца топика (топик: %s, next_offset=%s)",
                    self._topic_for_service_name(self._active_topic_service_name),
                    next_offset,
                )
                return
            await asyncio.sleep(0.1)
        self.logger.warning(
            "Смещение в конец топика не выполнено: партиции ещё не назначены"
        )

    async def _wait_for_assignment(self, timeout_sec: float = 15.0) -> bool:
        """
        Ждёт назначения партиций консьюмеру (топик должен существовать).
        Возвращает True, если партиции назначены, False при таймауте.
        """
        consumer = await self._get_consumer()
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout_sec
        while loop.time() < deadline:
            if consumer.assignment():
                return True
            await asyncio.sleep(0.1)
        return False

    @retry_forever(
        start_message=None,
        error_message="Ошибка доставки в Kafka: {e}",
    )
    async def publish(
        self,
        message: MessageT,
        *,
        service_name: str | None = None,
    ) -> None:
        """
        Отправляет сообщение в топик (JSON = model_dump сообщения).
        service_name: сегмент ``EVENT_NAMESPACE.<service_name>``; ``None`` / пусто — ``EVENT_NAMESPACE``.
        """
        value = message.model_dump_json().encode("utf-8")
        topic = self._topic_for_service_name(service_name)
        self.logger.debug("Отправка сообщения в Kafka в топик %s", topic)
        producer = await self._get_producer()
        try:
            await producer.send_and_wait(topic, value=value)
        except Exception as e:
            self.logger.error(
                "Ошибка доставки сообщения в Kafka, топик %s: %s",
                topic,
                e,
            )
            raise

    def pop(self, timeout: float = 60) -> _AsyncPopMessage[MessageT]:
        """
        Async контекст: при входе — чтение одного сообщения с таймаутом;
        при успешном выходе — commit().
        """
        return _AsyncPopMessage[MessageT](self, timeout)

    @retry_forever(
        start_message="Чтение сообщения из Kafka из топика {topic_name}",
        error_message="Ошибка при чтении из Kafka, топик {topic_name}: {e}",
    )
    async def _pop(self, timeout: float = 60) -> MessageT | None:
        """Читает одно сообщение из топика (ожидается JSON тела сообщения)."""
        consumer = await self._get_consumer()

        while True:
            try:
                msg = await asyncio.wait_for(
                    consumer.getone(),
                    timeout=timeout,
                )
            except TimeoutError:
                return None
            except Exception as e:
                self.logger.warning("Ошибка Kafka при чтении: %s", e)
                continue

            if msg.value is None:
                self.logger.warning("Получено сообщение с пустым payload (value)")
                continue

            self._last_message = msg

            try:
                raw = _value_to_dict(msg.value)
                parsed = self._msg_cls.model_validate(raw)
            except (ValidationError, TypeError, ValueError, json.JSONDecodeError):
                if self._skip_on_parse_error:
                    self.logger.warning(
                        "Ошибка парсинга сообщения. Пропускаем.",
                        exc_info=True,
                    )
                    await self._commit_silent()
                    continue
                self.logger.critical(
                    "Ошибка парсинга сообщения. Останавливаем обработку.",
                    exc_info=True,
                )
                await self._unsub()
                await self.close()
                await self._run_schema_mismatch_alert_loop()
                return None

            return parsed

    async def _read_batch_parsed(
        self,
        consumer: AIOKafkaConsumer,
        *,
        limit: int | None,
        read_timeout_sec: float,
        idle_slice_sec: float = _BATCH_READ_IDLE_SLICE_SEC,
    ) -> list[AppEventBatchItem[MessageT]]:
        """
        Читает пачку: до первого сообщения ждёт до read_timeout_sec;
        после первого — пауза idle_slice_sec без новых сообщений завершает чтение.
        Не выполняет commit после пачки.

        При ``skip_on_parse_error`` невалидное сообщение коммитится (как в ``_pop``),
        чтобы группа не застревала на старой схеме в логе.
        """
        _require_single_assigned_partition(consumer)
        result: list[AppEventBatchItem[MessageT]] = []

        while True:
            if limit is not None and len(result) >= limit:
                break
            timeout = read_timeout_sec if not result else idle_slice_sec
            try:
                msg = await asyncio.wait_for(
                    consumer.getone(),
                    timeout=timeout,
                )
            except TimeoutError:
                break

            if msg.value is None:
                continue

            self._last_message = msg
            try:
                raw = _value_to_dict(msg.value)
                parsed = self._msg_cls.model_validate(raw)
            except (ValidationError, TypeError, ValueError, json.JSONDecodeError):
                if self._skip_on_parse_error:
                    self.logger.warning(
                        "Ошибка парсинга сообщения при пакетном чтении. Пропускаем.",
                        exc_info=True,
                    )
                    await self._commit_silent()
                    continue
                raise

            result.append(AppEventBatchItem(message=parsed, offset=msg.offset))

        return result

    async def _read_from_committed(
        self,
        *,
        limit: int | None = None,
        read_timeout_sec: float = 25.0,
        idle_slice_sec: float = _BATCH_READ_IDLE_SLICE_SEC,
    ) -> list[AppEventBatchItem[MessageT]]:
        """
        Сценарий Б: читает с текущего **сохранённого в брокере смещения группы** (Kafka: committed offset), **без** seek по запросу и **без** записи offset после пачки.
        Ожидается ровно одна назначенная партиция. Только внутри активной ``subscription()``.
        """
        consumer = await self._get_consumer()
        return await self._read_batch_parsed(
            consumer,
            limit=limit,
            read_timeout_sec=read_timeout_sec,
            idle_slice_sec=idle_slice_sec,
        )

    @retry_forever(
        start_message="Чтение событий из топика {topic_name} (смещение группы)",
        error_message="Ошибка чтения событий (смещение группы), топик {topic_name}: {e}",
        max_errors=5,
    )
    async def read_from_committed_ready(
        self,
        *,
        limit: int | None = None,
        read_timeout_sec: float = 25.0,
        assignment_timeout_sec: float = 15.0,
        idle_slice_sec: float = _BATCH_READ_IDLE_SLICE_SEC,
    ) -> list[AppEventBatchItem[MessageT]]:
        """
        Сценарий Б: ждёт назначения партиций, затем читает пачку со **сохранённого смещения группы** в брокере.

        Вызывать **только** внутри ``async with service.subscription(service_name=...):``, например::

            async with service.subscription(service_name="my_reader"):
                items = await service.read_from_committed_ready(limit=100)
        """
        if not await self._wait_for_assignment(timeout_sec=assignment_timeout_sec):
            raise TimeoutError("Партиции не назначены в отведённое время")
        return await self._read_from_committed(
            limit=limit,
            read_timeout_sec=read_timeout_sec,
            idle_slice_sec=idle_slice_sec,
        )

    async def _read_from_next_offset(
        self,
        next_offset: int,
        *,
        limit: int | None = None,
        read_timeout_sec: float = 25.0,
        idle_slice_sec: float = _BATCH_READ_IDLE_SLICE_SEC,
    ) -> list[AppEventBatchItem[MessageT]]:
        """
        Сценарий А: seek на next_offset, commit позиции, затем пачка без финального commit.
        Только внутри активной ``subscription()``.
        """
        consumer = await self._get_consumer()
        tp = _require_single_assigned_partition(consumer)
        consumer.seek(tp, next_offset)
        await consumer.commit({tp: next_offset})
        self.logger.info(
            "Смещение к next_offset=%s выполнено (топик: %s)",
            next_offset,
            self._topic_for_service_name(self._active_topic_service_name),
        )
        return await self._read_batch_parsed(
            consumer,
            limit=limit,
            read_timeout_sec=read_timeout_sec,
            idle_slice_sec=idle_slice_sec,
        )

    @retry_forever(
        start_message="Чтение событий из топика {topic_name} (next_offset)",
        error_message="Ошибка чтения событий (next_offset), топик {topic_name}: {e}",
        max_errors=5,
    )
    async def read_from_next_offset_ready(
        self,
        next_offset: int,
        *,
        limit: int | None = None,
        read_timeout_sec: float = 25.0,
        assignment_timeout_sec: float = 15.0,
        idle_slice_sec: float = _BATCH_READ_IDLE_SLICE_SEC,
    ) -> list[AppEventBatchItem[MessageT]]:
        """
        Сценарий А: ждёт assignment, затем seek+commit и пачка.

        Вызывать **только** внутри ``async with service.subscription(service_name=...):``, например::

            async with service.subscription(service_name="my_reader"):
                items = await service.read_from_next_offset_ready(0, limit=100)
        """
        if not await self._wait_for_assignment(timeout_sec=assignment_timeout_sec):
            raise TimeoutError("Партиции не назначены в отведённое время")
        return await self._read_from_next_offset(
            next_offset,
            limit=limit,
            read_timeout_sec=read_timeout_sec,
            idle_slice_sec=idle_slice_sec,
        )

    # --- Парсинг ---

    def _message_from_value(self, value: bytes | str | dict[str, Any]) -> MessageT:
        """Парсит value (JSON тела сообщения) в MessageT."""
        raw = _value_to_dict(value)
        return self._msg_cls.model_validate(raw)

    async def _handle_schema_mismatch(self, exc: Exception | None = None) -> None:
        """При несовпадении схем — Critical, отписка, alert loop."""
        self.logger.critical(
            "Несовпадение схем. Останавливаем обработку.%s",
            "" if exc is None else f" {exc!s}",
            exc_info=exc is not None,
        )
        await self._unsub()
        await self.close()
        await self._run_schema_mismatch_alert_loop()

    async def _run_schema_mismatch_alert_loop(self) -> None:
        """Цикл Critical и schema_alert_callback после остановки из-за схемы."""
        msg = (
            "Схема сообщений не соответствует ожидаемой. Обработка событий остановлена."
        )
        while True:
            self.logger.critical(msg)
            if self._schema_alert_callback:
                try:
                    if inspect.iscoroutinefunction(self._schema_alert_callback):
                        await self._schema_alert_callback(msg)
                    else:
                        self._schema_alert_callback(msg)
                except Exception as e:
                    self.logger.exception(
                        "Ошибка при вызове callback оповещения: %s", e
                    )
            await asyncio.sleep(self._schema_alert_interval_seconds)

    async def _get_consumer(self) -> AIOKafkaConsumer:
        """Возвращает async consumer; при первом вызове создаёт через connector."""
        if self.connector is None:
            raise ValueError("connector не задан")
        if not self.consumer_group or not str(self.consumer_group).strip():
            raise ValueError("consumer_group должен быть непустой строкой")
        if self._consumer is None:
            self.connector.set_logger(self.logger)
            self._consumer = self.connector.get_async_consumer(
                group_id=self.consumer_group,
                enable_auto_commit=False,
                auto_offset_reset="earliest",
            )
        return self._consumer

    async def _get_producer(self) -> AIOKafkaProducer:
        """Возвращает async producer; при первом вызове создаёт и запускает через connector."""
        if self._producer is None:
            self.connector.set_logger(self.logger)
            producer = self.connector.get_async_producer()
            await producer.start()
            self._producer = producer
        return self._producer

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if not hasattr(cls, "EVENT_NAMESPACE") or not isinstance(
            getattr(cls, "EVENT_NAMESPACE", None), str
        ):
            raise TypeError(
                f"{cls.__name__} должен определить EVENT_NAMESPACE (непустая строка)"
            )
        namespace = cls.EVENT_NAMESPACE
        if not namespace or not namespace.strip():
            raise TypeError(
                f"{cls.__name__}.EVENT_NAMESPACE не должен быть пустой строкой"
            )
        if not hasattr(cls, "MESSAGE_CLASS"):
            raise TypeError(f"{cls.__name__} должен определить MESSAGE_CLASS")
