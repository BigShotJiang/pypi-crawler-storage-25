# Пакетное чтение app-events: смещения и commit

Документ описывает `AppEventService.read_from_committed_ready` / `read_from_next_offset_ready` в [`app_event.py`](../app_event.py) и рекомендуемый **HTTP** контракт на базе [`BaseAppEventMessagesResponse`](../../../route/schemes.py) (пример: `examples/01_fast_api.py`).

**Слово «committed» в Kafka:** у consumer group в брокере хранится **сохранённое смещение** (в документации Kafka — *committed offset*). Это **не** значит «сервер сейчас коммитит прочитанную пачку»: в сценарии Б после чтения пачки новое смещение в брокер **не записывается**. Путаница обычно из‑за одного корня *commit*.

## Что такое offset: FastAPI vs Kafka

| | **FastAPI / HTTP** | **Kafka** |
|---|-------------------|-----------|
| **Query `offset`** | Имя параметра в строке запроса (`?offset=45`). Число клиент **не выдумывает**: копирует из поля **`nextOffset`** предыдущего JSON-ответа (если оно не `null`). Это **не** пагинация списка (`skip/limit` другого стиля). | То же число, что передаётся в **`seek(partition, offset)`** перед чтением: номер записи в **логе одной партиции**, с которой консьюмер продолжит выборку. |
| **Поле ответа `nextOffset`** | Имя в JSON; **«следующий»** после последней записи, попавшей в пачку: `lastRecordOffset + 1`, либо `null` при пустой пачке. | Соответствует «продолжить чтение **после** последнего отданного сообщения»; совпадает с договорённостью, какую позицию клиент должен прислать в следующем запросе в query `offset`. |

Итого: в одном round-trip **имена разные намеренно** — в ответе подчёркивается *следующая* позиция (`nextOffset`), в запросе — короткое имя параметра (`offset`), без путаницы с пагинацией, если описать это в OpenAPI.

## Два сценария на уровне Kafka

| | **Сценарий Б — без query `offset`** | **Сценарий А — с query `offset`** |
|---|------------------------------|----------------------------------|
| **Вызов** | `read_from_committed_ready(...)` | `read_from_next_offset_ready(offset, ...)` |
| **Стартовая позиция** | С **сохранённого в брокере** смещения consumer group | `seek(tp, offset)` |
| **Запись смещения в брокер до чтения** | Нет | **Да:** `commit({tp: offset})` перед чтением пачки |
| **Запись смещения после пачки** | **Нет** | **Нет** |
| **Типичный HTTP** | Запрос **без** `offset` | Запрос **`offset=N`**, **N = прошлый `nextOffset`** |

Consumer с `enable_auto_commit=False` — после `getone` группа сама не двигается.

## HTTP: сервер задаёт `nextOffset`, клиент передаёт его как `offset`

1. **Сервер** в теле ответа отдаёт `messages` и `nextOffset` (или `nextOffset: null`).
2. **Клиент** подставляет в следующий запрос **`?offset=<то же число, что nextOffset>`**; при `null` параметр **не** передаёт.

## Зачем сценарий А

После сценария Б **сохранённое смещение группы** в брокере под прочитанную пачку **не** сдвигается. При серии HTTP-запросов без передачи `offset` из ответа возможны повторные чтения (см. `examples/04_read_events_api_client_wrong_no_offset.py`). Сценарий А **записывает в брокер** позицию через `seek` + `commit` до чтения.

## Схема последовательности (HTTP long-poll)

```mermaid
sequenceDiagram
    participant C as Клиент
    participant API as HTTP API
    participant S as AppEventService
    participant K as Kafka (consumer group)

    Note over C,K: Первый long-poll (смещение группы)
    C->>API: GET без offset
    API->>S: read_from_committed_ready
    S->>K: чтение с сохранённого смещения группы
    K-->>S: пусто или записи
    S-->>API: items
    API-->>C: messages=[...], nextOffset=null или N (сервер)

    Note over C,K: Следующие запросы
    C->>API: GET offset=N (N = прошлый nextOffset)
    API->>S: read_from_next_offset_ready(N)
    S->>K: seek(N) + commit(N)
    S->>K: чтение пачки
    K-->>S: ...
    API-->>C: messages=[...], nextOffset=N2 (снова от сервера)
```

## Реализация на сервере (пример)

- есть сообщения в пачке → `nextOffset = offset_последнего_в_пачке + 1`;
- пачка пустая → **`nextOffset: null`**; следующий запрос **без** `offset` продолжит со смещения группы (уже выставленного при сценарии А).

## Детали кода Kafka

- Пачка: `_read_batch_parsed` — без записи offset в брокер в конце.
- Сценарий А: `_read_from_next_offset` — `seek` + запись offset в брокер (`commit`), затем пачка.

## См. также

- `../examples/http_event_schemas.py` — `ExampleEventsResponse`.
- `../examples/03_read_events_api_client.py` — `offset=response.next_offset`.
- `../examples/04_read_events_api_client_wrong_no_offset.py` — без `offset` в цикле.
