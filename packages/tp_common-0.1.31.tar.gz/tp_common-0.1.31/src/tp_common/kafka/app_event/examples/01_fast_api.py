"""
Пример FastAPI: чтение app-events из Kafka (одна партиция на топик).

Эндпоинт GET /events:
  - без query ``offset`` — чтение с **сохранённого в Kafka смещения consumer group**;
  - с query ``offset`` — seek + commit на эту позицию, затем пачка (значение = поле ``nextOffset`` из прошлого ответа).

Ответ: ``BaseAppEventMessagesResponse`` — ``messages`` и ``nextOffset`` (сервер). В следующем запросе то же число передаётся в query как ``offset`` (см. ``03_read_events_api_client``).

Запуск API (из корня репозитория, чтобы импортировался пакет)::

  set PYTHONPATH=src
  python -m tp_common.kafka.app_event.examples.01_fast_api

  # или: uvicorn tp_common.kafka.app_event.examples.01_fast_api:app --host 127.0.0.1 --port 8002

Поток сообщений (отдельный терминал), ``TaskAppEventMessage`` → ``example.events.my_client``::

  python -m tp_common.kafka.app_event.examples.02_publish_simulated_events

HTTP-клиент к этому API (модуль ``app_event_example_http_client``; без Kafka у процесса клиента)::

  python -m tp_common.kafka.app_event.examples.03_read_events_api_client
  # учебный контрпример без next_offset (сравнение с 03):
  python -m tp_common.kafka.app_event.examples.04_read_events_api_client_wrong_no_offset

Секреты и параметры — в ``settings.py`` и ``.env`` (шаблон ``env.example`` в этом каталоге).

При недоступном Kafka эндпоинт /events быстро вернёт 500, если в конфиге не включены повторы
(``APP_EVENT_EXAMPLE_KAFKA_RETRY``).

Примеры curl (топик зафиксирован в ``TaskAppEvent``: example.events.my_client)::

  curl "http://127.0.0.1:8002/events?limit=100"
  curl "http://127.0.0.1:8002/events?offset=0&limit=100"
"""

import logging
import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from http import HTTPStatus

from fastapi import Depends, FastAPI, HTTPException, Query

from tp_common.exceptions.exceptions import TpException
from tp_common.kafka.app_event.examples.http_event_schemas import (
    ExampleEventsResponse,
    ExampleTaskEventMessageBody,
)
from tp_common.kafka.app_event.examples.settings import get_app_event_examples_settings
from tp_common.kafka.app_event.examples.task_app_event import (
    TaskAppEvent,
    create_task_app_event_service,
    make_example_kafka_connector,
)
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_fastapi.middleware import TpMiddleware
from tp_common.tp_logger.fastapi_integration import get_request_logger
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory

logging.basicConfig(level=logging.INFO)
logger_factory = TpLoggerFactory(env=EnvironmentType.LOCAL)
logger = logger_factory.get_logger("app_event_example_api")


class EventReadException(TpException):
    """Ошибка чтения событий из Kafka (таймаут, сбой и т.д.)."""

    def __init__(
        self,
        *,
        trace_id: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message="Internal Server Error",
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            trace_id=trace_id,
        )


def get_kafka_connector() -> KafkaConnector:
    return make_example_kafka_connector(logger)


@asynccontextmanager
async def lifespan(application: FastAPI) -> AsyncGenerator[None]:
    application.state.log_factory = logger_factory
    yield


app = FastAPI(
    title="App events API (Kafka)",
    description="Чтение app-events: query offset (= прошлый nextOffset); ответ messages + nextOffset.",
    lifespan=lifespan,
)
app.add_middleware(TpMiddleware)


@app.get(
    "/events",
    summary="Список сообщений (смещение группы или query offset)",
    description="Без query offset — сценарий Б: чтение со сохранённого смещения группы (read_from_committed_ready). "
    "С offset — сценарий А (read_from_next_offset_ready); значение = поле nextOffset из предыдущего ответа. "
    "Топик с одной партицией. 422 — неверное число партиций и т.п.",
    response_model=ExampleEventsResponse,
)
async def events_list(
    request_logger: TpLogger = Depends(get_request_logger),
    offset: int | None = Query(
        default=None,
        ge=0,
        description="То же число, что в поле nextOffset предыдущего ответа (сценарий А). Если не задан — сценарий Б.",
    ),
    limit: int | None = Query(
        default=None,
        ge=1,
        le=10_000,
        description="Максимум сообщений в ответе (без ограничения, если не задан).",
    ),
    timeout: float = Query(
        default=25.0,
        ge=1.0,
        le=120.0,
        description="Максимум секунд ожидания первого сообщения (long poll).",
    ),
) -> ExampleEventsResponse:
    connector = get_kafka_connector()
    async with create_task_app_event_service(
        connector,
        request_logger,
        retry_enabled=get_app_event_examples_settings().kafka_retry_forever,
    ) as service:
        try:
            async with service.subscription(
                service_name=TaskAppEvent.TOPIC_SERVICE_NAME
            ):
                if offset is not None:
                    items = await service.read_from_next_offset_ready(
                        offset,
                        limit=limit,
                        read_timeout_sec=timeout,
                        assignment_timeout_sec=15.0,
                    )
                else:
                    items = await service.read_from_committed_ready(
                        limit=limit,
                        read_timeout_sec=timeout,
                        assignment_timeout_sec=15.0,
                    )
            messages = [
                ExampleTaskEventMessageBody.model_validate(it.message.model_dump())
                for it in items
            ]
            next_out = items[-1].offset + 1 if items else None

            return ExampleEventsResponse(messages=messages, next_offset=next_out)
        except ValueError as e:
            raise HTTPException(status_code=422, detail=str(e)) from e
        except Exception as e:
            request_logger.exception(
                "Чтение событий не удалось (исчерпаны повторы или ошибка): %s", e
            )
            raise EventReadException(trace_id=request_logger.trace_id) from e


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


def main() -> None:
    """Запуск uvicorn (``python -m ...01_fast_api``); host/port из ``settings`` / ``.env``."""
    import uvicorn

    s = get_app_event_examples_settings()
    uvicorn.run(
        "tp_common.kafka.app_event.examples.01_fast_api:app",
        host=s.api_host,
        port=s.api_port,
        reload=False,
    )


if __name__ == "__main__":
    main()
