"""
**Учебный контрпример:** в цикле **игнорируется** ``nextOffset`` из ответа и каждый раз
запрашивается только сценарий Б (без query ``nextOffset``).

У API каждый вызов — отдельный жизненный цикл consumer; без передачи ``nextOffset`` из ответа
снова включается чтение **только** со смещения группы (без nextOffset из ответа), что даёт дубликаты и рассинхрон.

Корректная реализация: подставлять ``response.next_offset`` в query ``offset`` (``03_read_events_api_client``).

  python -m tp_common.kafka.app_event.examples.04_read_events_api_client_wrong_no_offset
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys

import aiohttp

from tp_common.kafka.app_event.examples.app_event_example_http_client import (
    AppEventExampleApiClient,
)
from tp_common.kafka.app_event.examples.settings import get_app_event_examples_settings

logger = logging.getLogger(__name__)


async def run_client_wrong() -> None:
    s = get_app_event_examples_settings()
    base = s.resolved_http_base_url
    logger.info("Базовый URL API: %s", base)
    logger.warning(
        "Контрпример: в цикле не передаётся offset из ответа nextOffset (см. описание модуля)."
    )
    async with AppEventExampleApiClient(base_url=base) as client:
        while True:
            response = await client.fetch_events(
                offset=None,
                limit=s.fetch_limit,
                read_timeout_sec=s.fetch_read_timeout_sec,
            )
            for msg in response.messages:
                line = msg.model_dump(mode="json")
                print(json.dumps(line, ensure_ascii=False))


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    try:
        asyncio.run(run_client_wrong())
    except KeyboardInterrupt:
        print("", file=sys.stderr)
    except aiohttp.ClientResponseError as e:
        print(f"HTTP {e.status}: {e.message}", file=sys.stderr)
        sys.exit(1)
    except aiohttp.ClientError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
