"""Сервис и схема сообщения для демо ``TaskAppEvent`` (топик ``example.events.my_client``)."""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from tp_common.kafka.app_event.app_event import AppEventService
from tp_common.kafka.app_event.examples.settings import get_app_event_examples_settings
from tp_common.kafka.app_event.schemas import BaseAppEventMessage
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_logger.tp_logging import TpLogger


def make_example_kafka_connector(logger: TpLogger) -> KafkaConnector:
    """``KafkaConnector``: URL из единого конфига (``settings`` / ``.env``)."""

    url = get_app_event_examples_settings().require_kafka_broker_url()

    return KafkaConnector(url, logger=logger)


class TaskAppEventMessage(BaseAppEventMessage):
    """

    Тело Kafka для ``TaskAppEvent`` — отдельная схема, не ``ExampleResultMessage``.

    ``message_kind`` — дискриминатор схемы; ``event_type`` — в базовом ``BaseAppEventMessage``.

    """

    message_kind: Literal["task_app_event"] = Field(
        default="task_app_event",
        description="Дискриминатор схемы TaskAppEvent.",
    )

    sequence: int

    job_id: str

    payload_kb: int = Field(ge=0, le=1_048_576)

    ok: bool


class TaskAppEvent(AppEventService[TaskAppEventMessage]):
    """

    Демо-наследник ``AppEventService``. Сегмент топика для примеров — ``TOPIC_SERVICE_NAME``:
    ``EVENT_NAMESPACE.<TOPIC_SERVICE_NAME>``.
    """

    EVENT_NAMESPACE = "microservice.events.tasks"

    MESSAGE_CLASS = TaskAppEventMessage

    TOPIC_SERVICE_NAME = "tp-service"


def create_task_app_event_service(
    connector: KafkaConnector,
    logger: TpLogger,
    consumer_group: str = "main",
    retry_enabled: bool = True,
    skip_on_parse_error: bool = True,
) -> TaskAppEvent:
    service = TaskAppEvent(
        connector=connector,
        logger=logger,
        consumer_group=consumer_group,
        skip_on_parse_error=skip_on_parse_error,
    )
    service.retry_enabled = retry_enabled
    return service
