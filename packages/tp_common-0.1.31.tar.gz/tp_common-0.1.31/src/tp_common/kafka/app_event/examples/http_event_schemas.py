"""Общие схемы HTTP long-poll для примеров ``01_fast_api`` и ``app_event_example_http_client``."""

from __future__ import annotations

from tp_common.kafka.app_event.examples.task_app_event import TaskAppEventMessage
from tp_common.route.schemes import BaseAppEventMessagesResponse, BaseResponse


class ExampleTaskEventMessageBody(BaseResponse, TaskAppEventMessage):
    """Тело одного события в ответе ``GET /events`` (алиасы camelCase через ``BaseResponse``)."""


class ExampleEventsResponse(BaseAppEventMessagesResponse[ExampleTaskEventMessageBody]):
    """Ответ ``GET /events``: ``messages`` + ``nextOffset`` (сервер); в следующем запросе — query ``offset``."""
