"""
Единый конфиг примеров ``app_event``: секреты и параметры из окружения и ``.env``.

Ищется первый файл ``.env`` при подъёме от каталога этого модуля к корню диска
(обычно корень репозитория ``tp-common``). Скопируйте ``env.example`` → ``.env`` и заполните.

Переменные окружения (все опциональны, кроме сценариев с Kafka — там нужен ``KAFKA_URL`` или ``TP_KAFKA_URL``):

- ``KAFKA_URL`` / ``TP_KAFKA_URL`` — брокер (для ``01_fast_api``, ``02_publish``, ``make_example_kafka_connector``).
- ``APP_EVENT_EXAMPLE_API_HOST``, ``APP_EVENT_EXAMPLE_API_PORT`` — bind uvicorn в ``01_fast_api.main``.
- ``APP_EVENT_EXAMPLE_KAFKA_RETRY`` — ``1``/``true`` включает бесконечные ретраи Kafka в ``01_fast_api``.
- ``APP_EVENT_EXAMPLE_PUBLISH_COUNT``, ``APP_EVENT_EXAMPLE_PUBLISH_RATE`` — сценарий ``02_publish``.
- ``APP_EVENT_EXAMPLE_HTTP_BASE`` — базовый URL для ``03_read``; пусто → ``http://{host}:{port}``.
- ``APP_EVENT_EXAMPLE_FETCH_LIMIT``, ``APP_EVENT_EXAMPLE_FETCH_TIMEOUT``, ``APP_EVENT_EXAMPLE_NEXT_OFFSET`` — HTTP-клиенты ``03_read`` / ``04_read_wrong`` (``03`` передаёт в query ``offset`` значение ``nextOffset`` из ответа; ``04`` — контрпример без ``offset``).
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import AliasChoices, Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


def _find_dotenv_path() -> Path | None:
    root = Path(__file__).resolve().parent
    for _ in range(14):
        candidate = root / ".env"
        if candidate.is_file():
            return candidate
        parent = root.parent
        if parent == root:
            break
        root = parent
    return None


_DOTENV = _find_dotenv_path()


class AppEventExamplesSettings(BaseSettings):
    model_config = (
        SettingsConfigDict(
            env_file=_DOTENV,
            env_file_encoding="utf-8",
            extra="ignore",
        )
        if _DOTENV is not None
        else SettingsConfigDict(
            env_file_encoding="utf-8",
            extra="ignore",
        )
    )

    kafka_broker_url: str = Field(
        default="",
        validation_alias=AliasChoices("KAFKA_URL", "TP_KAFKA_URL"),
        description="Подключение к Kafka для примеров.",
    )

    api_host: str = Field(
        default="127.0.0.1",
        validation_alias="APP_EVENT_EXAMPLE_API_HOST",
    )
    api_port: int = Field(
        default=8002,
        ge=1,
        le=65535,
        validation_alias="APP_EVENT_EXAMPLE_API_PORT",
    )

    kafka_retry_forever: bool = Field(
        default=False,
        validation_alias="APP_EVENT_EXAMPLE_KAFKA_RETRY",
    )

    publish_count: int = Field(
        default=5,
        ge=1,
        validation_alias="APP_EVENT_EXAMPLE_PUBLISH_COUNT",
    )
    publish_msg_per_sec: float = Field(
        default=10.0,
        ge=0,
        validation_alias="APP_EVENT_EXAMPLE_PUBLISH_RATE",
    )

    http_client_base_url: str = Field(
        default="",
        validation_alias="APP_EVENT_EXAMPLE_HTTP_BASE",
    )

    fetch_limit: int = Field(
        default=10,
        ge=1,
        validation_alias="APP_EVENT_EXAMPLE_FETCH_LIMIT",
    )
    fetch_read_timeout_sec: float = Field(
        default=25.0,
        ge=1.0,
        validation_alias="APP_EVENT_EXAMPLE_FETCH_TIMEOUT",
    )
    fetch_next_offset: int | None = Field(
        default=None,
        validation_alias="APP_EVENT_EXAMPLE_NEXT_OFFSET",
    )

    @field_validator("fetch_next_offset", mode="before")
    @classmethod
    def _fetch_next_offset(cls, v: object) -> int | None:
        if v is None or v == "":
            return None
        i = v if isinstance(v, int) else int(str(v).strip())
        if i < 0:
            raise ValueError("APP_EVENT_EXAMPLE_NEXT_OFFSET must be >= 0")
        return i

    @field_validator("kafka_retry_forever", mode="before")
    @classmethod
    def _bool_from_env(cls, v: object) -> bool:
        if isinstance(v, bool):
            return v
        if v is None or v == "":
            return False
        return str(v).strip().lower() in ("1", "true", "yes", "on")

    @property
    def resolved_http_base_url(self) -> str:
        raw = self.http_client_base_url.strip()
        if raw:
            return raw.rstrip("/")
        return f"http://{self.api_host}:{self.api_port}"

    def require_kafka_broker_url(self) -> str:
        url = self.kafka_broker_url.strip()
        if not url:
            raise RuntimeError(
                "Задайте KAFKA_URL или TP_KAFKA_URL в .env (см. env.example в каталоге examples) "
                "или в окружении процесса."
            )
        return url


@lru_cache
def get_app_event_examples_settings() -> AppEventExamplesSettings:
    return AppEventExamplesSettings()


# Удобный алиас для импорта
app_event_examples_settings = get_app_event_examples_settings()
