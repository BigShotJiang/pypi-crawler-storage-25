"""
Корректный цикл чтения через HTTP: значение из поля ответа ``nextOffset`` в следующем запросе
передаётся в query как ``offset`` (без самостоятельного пересчёта по ``messages``).

Клиент: ``app_event_example_http_client``.

  python -m tp_common.kafka.app_event.examples.03_read_events_api_client
"""

from __future__ import annotations

import asyncio
import json
import logging
import sys

import aiohttp

from tp_common.kafka.app_event.examples.app_event_example_http_client import (
    AppEventExampleApiClient,
)
from tp_common.kafka.app_event.examples.settings import get_app_event_examples_settings

logger = logging.getLogger(__name__)


async def run_client() -> None:
    s = get_app_event_examples_settings()
    base = s.resolved_http_base_url
    logger.info("Базовый URL API: %s", base)

    resume: int | None = s.fetch_next_offset

    async with AppEventExampleApiClient(base_url=base) as client:
        while True:
            response = await client.fetch_events(
                offset=resume,
                limit=s.fetch_limit,
                read_timeout_sec=s.fetch_read_timeout_sec,
            )

            for msg in response.messages:
                line = msg.model_dump(mode="json")
                print(json.dumps(line, ensure_ascii=False))

            resume = response.next_offset


def main() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )

    try:
        asyncio.run(run_client())

    except KeyboardInterrupt:
        print("", file=sys.stderr)

    except aiohttp.ClientResponseError as e:
        print(f"HTTP {e.status}: {e.message}", file=sys.stderr)

        sys.exit(1)

    except aiohttp.ClientError as e:
        print(str(e), file=sys.stderr)

        sys.exit(1)


if __name__ == "__main__":
    main()
