"""HTTP-клиент к демо ``01_fast_api`` (GET /events), без прямого доступа к Kafka."""

from __future__ import annotations

import logging

import aiohttp
from aiohttp import ClientTimeout

from tp_common.kafka.app_event.examples.http_event_schemas import ExampleEventsResponse

logger = logging.getLogger(__name__)


class AppEventExampleApiClient:
    """Long-poll запросы к ``GET /events``."""

    def __init__(
        self,
        base_url: str,
        *,
        session: aiohttp.ClientSession | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._own_session = session is None
        self._session = session

    async def __aenter__(self) -> AppEventExampleApiClient:
        if self._session is None:
            self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *exc: object) -> None:
        if self._own_session and self._session is not None:
            await self._session.close()
            self._session = None

    def _client_timeout(self, read_timeout_sec: float) -> ClientTimeout:
        return ClientTimeout(total=min(600.0, max(60.0, read_timeout_sec + 45.0)))

    async def fetch_events(
        self,
        *,
        offset: int | None = None,
        limit: int | None = None,
        read_timeout_sec: float = 25.0,
        trace_id: str | None = None,
    ) -> ExampleEventsResponse:
        """Возвращает ответ API; ``offset`` в query = поле ``nextOffset`` из прошлого ответа."""
        assert self._session is not None
        params: dict[str, str | int | float] = {"timeout": read_timeout_sec}
        if offset is not None:
            params["offset"] = offset
        if limit is not None:
            params["limit"] = limit
        headers: dict[str, str] = {}
        if trace_id:
            headers["X-Trace-Id"] = trace_id

        logger.info("GET %s/events params=%s", self._base_url, params)

        async with self._session.get(
            f"{self._base_url}/events",
            params=params,
            headers=headers,
            timeout=self._client_timeout(read_timeout_sec),
        ) as resp:
            resp.raise_for_status()
            raw = await resp.json()
        if not isinstance(raw, dict):
            raise TypeError(f"ожидался JSON-объект, получено: {type(raw).__name__}")
        return ExampleEventsResponse.model_validate(raw)
