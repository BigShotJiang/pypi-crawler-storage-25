"""
Имитация потока: публикация ``TaskAppEventMessage`` в ``example.events.my_client``.

Параметры и секреты — ``settings.py`` + ``.env`` (шаблон ``env.example``).

  python -m tp_common.kafka.app_event.examples.02_publish_simulated_events
"""

from __future__ import annotations

import asyncio
import random
import sys
import uuid

from tp_common.kafka.app_event.examples.settings import get_app_event_examples_settings
from tp_common.kafka.app_event.examples.task_app_event import (
    TaskAppEvent,
    TaskAppEventMessage,
    create_task_app_event_service,
    make_example_kafka_connector,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory


def _build_message(seq: int) -> TaskAppEventMessage:
    return TaskAppEventMessage(
        event_type=random.choice(("created", "updated", "processed", "retry")),
        sequence=seq,
        job_id=str(uuid.uuid4()),
        payload_kb=random.randint(1, 512),
        ok=random.random() > 0.05,
    )


async def run_publish() -> None:
    s = get_app_event_examples_settings()
    factory = TpLoggerFactory(env=EnvironmentType.LOCAL)
    log = factory.get_logger("publish_simulated_events")
    connector = make_example_kafka_connector(log)

    service = create_task_app_event_service(connector, log, retry_enabled=False)

    interval = 1.0 / s.publish_msg_per_sec if s.publish_msg_per_sec > 0 else 0.0
    seq = 0

    async with service:
        log.info(
            "Публикация %s сообщений в example.events.my_client (~%.2f msg/s)",
            s.publish_count,
            s.publish_msg_per_sec,
        )
        for _ in range(s.publish_count):
            seq += 1
            await service.publish(
                _build_message(seq),
                service_name=TaskAppEvent.TOPIC_SERVICE_NAME,
            )
            if interval > 0:
                await asyncio.sleep(interval * random.uniform(0.85, 1.15))


def main() -> None:
    try:
        asyncio.run(run_publish())
    except KeyboardInterrupt:
        print("Остановлено.", file=sys.stderr)
    except RuntimeError as e:
        print(e, file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
