"""
Пример запроса к BspAvtodorClient: get_tariffs.

Переменные окружения:
  AVTODOR_KEYCLOAK_URL или KEYCLOAK_URL — обязательно,
    https://client_id:client_secret@keycloak.host
  AVTODOR_URL   — опционально, по умолчанию как у клиента
  ENV_TYPE       — опционально, LOCAL | DEV | … (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):
  set AVTODOR_KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.avtodor.examples.get_tariffs
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.avtodor.examples.create_client import create_avtodor_client
from tp_common.clients.bsp.avtodor.request import TariffsRequest


async def _run() -> None:
    try:
        client = create_avtodor_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    try:
        async with client:
            resp = await client.get_tariffs(TariffsRequest(limit=5))
            print(
                json.dumps(resp.model_dump(mode="json"), indent=2, ensure_ascii=False)
            )
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        raise SystemExit(1) from e


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
