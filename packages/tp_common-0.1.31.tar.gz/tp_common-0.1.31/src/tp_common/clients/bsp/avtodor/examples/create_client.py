"""Создание BspAvtodorClient для примеров (переменные окружения, .env рядом с примерами)."""

from __future__ import annotations

import os
from pathlib import Path

from tp_common.clients.bsp.avtodor.client import BspAvtodorClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory
from tp_common.utils import find_env_file, load_env_file


def create_avtodor_client(
    *,
    keycloak_url: str | None = None,
    avtodor_url: str | None = None,
    logger_name: str = "bsp_avtodor_examples",
) -> BspAvtodorClient:
    """Собирает клиент из окружения.

    Переменные:
      AVTODOR_KEYCLOAK_URL или KEYCLOAK_URL — URL Keycloak с учётными данными.
    """
    _env_path = find_env_file(anchor=Path(__file__))
    if _env_path:
        load_env_file(_env_path)

    url = keycloak_url or os.getenv("AVTODOR_KEYCLOAK_URL", "").strip()
    if not url:
        raise ValueError(
            "Укажите AVTODOR_KEYCLOAK_URL, например:\n"
            "  https://my_client:secret@keycloak.example.com"
        )

    logger = TpLoggerFactory(EnvironmentType.DEV).get_logger(
        logger_name, use_queue=False
    )

    return BspAvtodorClient(
        logger=logger,
        keycloak_url=url,
        env_type=EnvironmentType.DEV,
        avtodor_url=avtodor_url,
    )
