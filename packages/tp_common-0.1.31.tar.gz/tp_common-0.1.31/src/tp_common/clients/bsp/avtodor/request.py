"""Схемы запросов клиента bsp-avtodor.

Зеркалят `bsp-avtodor/src/api/v1/tariffs/request.py` (камуфлокс-паттерн —
схемы дублируются между сервисом и клиентом). Любое изменение API в
сервисе синхронно правится здесь.
"""

from __future__ import annotations

import uuid
from enum import StrEnum

from pydantic import Field

from tp_common.route.schemes import BaseQueryRequest, BaseRequest


class RoadCode(StrEnum):
    """Код дороги Автодор-ТР. Источник истины — справочник `roads` в БД сервиса."""

    M_1 = "m_1"
    M_3 = "m_3"
    M_4 = "m_4"
    M_11 = "m_11"
    M_12 = "m_12"
    CKAD = "ckad"
    A_289 = "a_289"
    BYPASS_TOLYATTI = "bypass_tolyatti"
    BYPASS_UFA = "bypass_ufa"


class VehicleClass(StrEnum):
    """Категория ТС Автодора (по высоте + числу осей)."""

    CLASS_1 = "class_1"
    CLASS_2 = "class_2"
    CLASS_3 = "class_3"
    CLASS_4 = "class_4"


class DayPattern(StrEnum):
    """Паттерн дней недели тарифа (ПН-ВС, ПН-ЧТ и т.п.)."""

    MON_SUN = "mon_sun"
    MON_THU = "mon_thu"
    FRI_SUN = "fri_sun"
    SUN_ONLY = "sun_only"
    MON_THU_ONLY = "mon_thu_only"
    FRI_ONLY = "fri_only"
    SAT_ONLY = "sat_only"
    SAT_SUN = "sat_sun"


class PaymentMethod(StrEnum):
    TRANSPONDER = "transponder"
    REGULAR = "regular"


class TariffsSortBy(StrEnum):
    PRICE_RUB = "price_rub"
    PARSED_AT = "parsed_at"


class TariffsRequest(BaseQueryRequest[TariffsSortBy]):
    """GET /v1/tariffs — фильтры + пагинация + сортировка.

    Поведение фильтра по дороге:
      - `road_code` отдаёт тарифы по всем участкам этой дороги;
      - `segment_id` — точечный фильтр, имеет приоритет над `road_code`.
    """

    road_code: RoadCode | None = None
    segment_id: uuid.UUID | None = None
    vehicle_class: VehicleClass | None = None
    day_pattern: DayPattern | None = None
    payment_method: PaymentMethod | None = None


class EventsRequest(BaseRequest):
    """GET /v1/events — long-poll чтение app-событий тарифов.

    Сценарий А: ``next_offset`` → seek + пачка. Сценарий Б: без ``next_offset``.
    """

    next_offset: int | None = Field(
        default=None,
        ge=0,
        description="Offset следующей читаемой записи (сценарий А). Без него — сценарий Б.",
    )
    limit: int | None = Field(
        default=None,
        ge=1,
        le=10_000,
        description="Максимальное количество сообщений в ответе.",
    )
    timeout: float = Field(
        default=25.0,
        ge=1.0,
        le=120.0,
        description="Максимальное время ожидания сообщений в секундах.",
    )
    road_code: RoadCode | None = Field(
        default=None, description="Фильтр по коду дороги (post-Kafka)."
    )
    vehicle_class: VehicleClass | None = Field(
        default=None, description="Фильтр по категории ТС (post-Kafka)."
    )
    day_pattern: DayPattern | None = Field(
        default=None, description="Фильтр по паттерну дней недели (post-Kafka)."
    )
    payment_method: PaymentMethod | None = Field(
        default=None, description="Фильтр по способу оплаты (post-Kafka)."
    )
