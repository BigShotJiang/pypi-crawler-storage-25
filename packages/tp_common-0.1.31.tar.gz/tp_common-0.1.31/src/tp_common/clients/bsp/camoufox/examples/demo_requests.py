"""
Пример вызовов CamoufoxClient (launch / close / clear).

Переменные окружения:
  KEYCLOAK_URL  — обязательно, https://client_id:client_secret@keycloak.host
  CAMOUFOX_URL  — опционально, по умолчанию как у клиента
  ENV_TYPE      — опционально, LOCAL | DEV | … (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):
  set KEYCLOAK_URL=...
  python -m tp_common.clients.bsp_camoufox.examples.demo_requests
"""

from __future__ import annotations

import asyncio
import os
import sys
import uuid
from pathlib import Path

from tp_common.clients.bsp.camoufox.client import CamoufoxClient
from tp_common.clients.bsp.camoufox.request import (
    BrowserLaunchRequest,
    BrowserName,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory
from tp_common.utils import find_env_file, load_env_file

_env_path = find_env_file(anchor=Path(__file__))
if _env_path:
    load_env_file(_env_path)


def _parse_env_type(value: str | None) -> EnvironmentType:
    raw = (value or "").strip().upper()
    if not raw:
        return EnvironmentType.LOCAL
    try:
        return EnvironmentType[raw]
    except KeyError:
        return EnvironmentType.LOCAL


async def _run() -> None:
    keycloak_url = os.getenv("KEYCLOAK_URL", "").strip()
    if not keycloak_url:
        print(
            "Укажите KEYCLOAK_URL, например:\n"
            "  https://my_client:secret@keycloak.example.com",
            file=sys.stderr,
        )
        raise SystemExit(2)

    os.getenv("CAMOUFOX_URL", "").strip()
    env_type = _parse_env_type(os.getenv("ENV_TYPE"))
    logger = TpLoggerFactory(env_type).get_logger(
        "bsp_camoufox_examples", use_queue=False
    )

    browser_id = uuid.UUID("fc4e39a5-b97d-4997-b22d-3eca226ce009")

    # Только https: при запросе на http часто следует редирект на https, aiohttp при
    # редиректе сбрасывает Authorization — сервер видит Missing Authorization header.
    client = CamoufoxClient(logger=logger, keycloak_url=keycloak_url, env_type=env_type)

    async with client:
        launch_req = BrowserLaunchRequest(
            browser_id=browser_id,
            browser=BrowserName.CAMOUFOX,
        )
        launched = await client.launch_browser(launch_req)
        print("launch_browser ->", launched.model_dump())


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
