"""Схемы ответов HTTP-клиента bsp-mos-account."""

from __future__ import annotations

import uuid
from datetime import datetime
from enum import StrEnum

from pydantic import Field, RootModel

from tp_common.clients.bsp.mos_account.request import AuthErrorName, AuthStatus
from tp_common.kafka.app_event.schemas import BaseAppEventMessage
from tp_common.route.schemes import (
    BaseAppEventMessagesResponse,
    BaseQueryResponse,
    BaseResponse,
)


class Account(BaseResponse):
    """Аккаунт mos.ru (как ``domain.account.schemes.Account``)."""

    account_id: uuid.UUID = Field(..., description="Идентификатор аккаунта")
    login: str = Field(..., description="Логин кабинета")
    password: str = Field(..., description="Пароль кабинета")
    proxy: str | None = Field(None, description="Прокси для исполнения запросов")
    auth_status: AuthStatus = Field(
        ...,
        description="Статус авторизации главного портала (источник — platform main)",
    )
    error_name: AuthErrorName | None = Field(
        None, description="Машинное имя ошибки (дублирует platform main)"
    )
    error_message: str | None = Field(None, description="Сообщение об ошибке")
    next_retry_at: datetime | None = Field(
        None, description="Запланированная дата следующей попытки авторизации"
    )


class AccountsResponse(BaseQueryResponse[Account]):
    """Список аккаунтов с ``total`` для пагинации."""


class UpdateSuccessResponse(BaseResponse):
    """Ответ PATCH ``/accounts/{account_id}`` — успех без тела сущности."""


class Cookie(BaseResponse):
    """Cookie аккаунта (элемент GET ``/accounts/{account_id}/cookies``)."""

    name: str
    value: str
    domain: str
    path: str = "/"
    expires: float | None = None
    http_only: bool = False
    secure: bool = False
    same_site: str | None = None


class AccountCookies(RootModel[list[Cookie]]):
    """Все cookies аккаунта — корень ответа JSON-массив."""


class AccountEventType(StrEnum):
    """Семантика app-event аккаунта (топик ``accounts.events.v1``)."""

    AUTH_SUCCESS = "auth_success"
    AUTH_ERROR = "auth_error"
    AUTH_WRONG_PASSWORD = "auth_wrong_password"
    COOKIES_UPDATED = "cookies_updated"


class AccountEventMessage(BaseAppEventMessage):
    """Один элемент ``messages`` в ответе GET ``/events/accounts``.

    ``event_type`` — строка из ``AccountEventType`` (базовый тип ``str`` в ``BaseAppEventMessage``).
    """

    account_id: uuid.UUID


class AccountEventsResponse(BaseAppEventMessagesResponse[AccountEventMessage]):
    """Long-poll: ``messages`` + ``nextOffset``."""
