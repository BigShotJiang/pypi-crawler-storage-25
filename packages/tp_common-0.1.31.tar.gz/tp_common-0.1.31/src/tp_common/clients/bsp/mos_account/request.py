"""Схемы запросов HTTP-клиента bsp-mos-account."""

from __future__ import annotations

import uuid
from enum import StrEnum
from typing import Self

from pydantic import Field, model_validator

from tp_common.route.schemes import (
    BaseAppEventMessagesQueryParams,
    BaseQueryRequest,
    BaseRequest,
)


class AuthStatus(StrEnum):
    """Статус авторизации (дублирует platform main)."""

    ERROR = "error"
    READY = "ready"
    IN_PROGRESS = "in_progress"
    AUTHENTICATING = "authenticating"
    EXPIRED = "expired"
    INVALID_CREDENTIALS = "invalid_credentials"
    UNKNOWN = "unknown"


class AuthErrorName(StrEnum):
    INVALID_CREDENTIALS = "invalid_credentials"
    ACCOUNT_BLOCKED = "account_blocked"
    CAPTCHA_REQUIRED = "captcha_required"
    MFA_REQUIRED = "mfa_required"
    PORTAL_UNAVAILABLE = "portal_unavailable"
    PROXY_ERROR = "proxy_error"
    TIMEOUT = "timeout"
    COOKIES_EXPIRED = "cookies_expired"
    SESSION_INVALIDATED = "session_invalidated"
    UNKNOWN = "unknown"


class AccountSortField(StrEnum):
    ACCOUNT_ID = "account_id"
    LOGIN = "login"
    PASSWORD = "password"
    AUTH_STATUS = "auth_status"
    ERROR_NAME = "error_name"
    ERROR_MESSAGE = "error_message"
    NEXT_RETRY_AT = "next_retry_at"
    PROXY = "proxy"


class AccountsRequest(BaseQueryRequest[AccountSortField]):
    """GET ``/accounts`` — фильтры, пагинация и сортировка."""

    account_id: uuid.UUID | None = Field(None, description="Фильтр по account_id")
    login: str | None = Field(None, description="Фильтр по логину")
    auth_status: AuthStatus | None = Field(
        None, description="Фильтр по статусу авторизации (дубль main)"
    )
    error_message: str | None = Field(None, description="Фильтр по error_message")
    proxy: str | None = Field(None, description="Фильтр по proxy")


class AccountCreateRequest(BaseRequest):
    """POST ``/accounts``. Платформа main создаётся на сервере всегда."""

    login: str = Field(description="Логин кабинета", max_length=255)
    password: str = Field(description="Пароль кабинета", max_length=255)
    proxy: str | None = Field(
        default=None,
        max_length=255,
        description="Прокси: протокол://логин:пароль@IP-адрес:порт",
    )
    enable_rnis: bool | None = Field(
        default=None,
        description="Подключить авторизацию RNIS",
    )
    enable_ovga: bool | None = Field(
        default=None,
        description="Подключить авторизацию OVGA",
    )

    @model_validator(mode="after")
    def validate_secondary_platforms(self) -> Self:
        if not self.enable_rnis and not self.enable_ovga:
            msg = "Нужно включить хотя бы одну платформу: enable_rnis или enable_ovga"
            raise ValueError(msg)
        return self


class AccountUpdateRequest(BaseRequest):
    """PATCH ``/accounts/{account_id}`` — все поля опциональны."""

    password: str | None = Field(None, max_length=255, description="Пароль")
    proxy: str | None = Field(None, max_length=255, description="Прокси")


class AccountEventsRequest(BaseAppEventMessagesQueryParams):
    """Query GET ``/events/accounts`` (long-poll Kafka ``bsp-mos-account.events.v1``)."""
