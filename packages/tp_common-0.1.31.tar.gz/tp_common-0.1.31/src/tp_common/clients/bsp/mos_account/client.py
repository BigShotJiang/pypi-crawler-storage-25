"""HTTP-клиент bsp-mos-account (``/api/v1``)."""

from __future__ import annotations

import uuid

from tp_common.clients.bsp.mos_account.request import (
    AccountCreateRequest,
    AccountEventsRequest,
    AccountsRequest,
    AccountUpdateRequest,
)
from tp_common.clients.bsp.mos_account.response import (
    Account,
    AccountCookies,
    AccountEventsResponse,
    AccountsResponse,
    UpdateSuccessResponse,
)
from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class BspMosAccountClient(KeycloakClient):
    """Клиент bsp-mos-account: пути и модели; Bearer и retry — в ``KeycloakClient``.

    Пути: ``/accounts`` (GET, POST), ``/accounts/{id}`` (PATCH),
    ``/accounts/{id}/cookies`` (GET), ``/accounts/{id}/auth-retry`` (POST),
    ``/events/accounts`` (long-poll).
    """

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        mos_account_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        base_url = self._build_base_url(
            mos_account_url=mos_account_url, env_type=env_type
        )
        super().__init__(
            base_url=base_url,
            logger=logger,
            audience="bsp-mos-account",
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    @classmethod
    def _build_base_url(
        cls, *, mos_account_url: str | None, env_type: EnvironmentType
    ) -> str:
        base = (mos_account_url or cls._base_url_by_env_type(env_type)).rstrip("/")
        return f"{base}{cls._api_version_path().rstrip('/')}/"

    @staticmethod
    def _api_version_path() -> str:
        return "/v1"

    @staticmethod
    def _base_url_by_env_type(env_type: EnvironmentType) -> str:
        match env_type:
            case EnvironmentType.STAGING:
                return "https://mos-account.bsp-staging.bz/api"
            case EnvironmentType.PROD:
                return "https://bsp.8525.ru/mos-account/api"
            case EnvironmentType.LOCAL:
                return "http://mos-account.bz/api"
            case _:
                return "https://mos-account.bsp-dev.bz/api"

    async def get_accounts(self, request: AccountsRequest) -> AccountsResponse:
        """GET ``/accounts`` — список с фильтрами и пагинацией."""
        return await self.get(
            uri="/accounts",
            response_schema=AccountsResponse,
            params=request,
        )

    async def get_account(self, account_id: uuid.UUID) -> Account:
        """GET ``/accounts?account_id=…`` — один аккаунт по ID."""
        response = await self.get_accounts(
            AccountsRequest(account_id=account_id)  # pyright: ignore[reportCallIssue]
        )
        if not response.items:
            msg = f"Account not found: {account_id}"
            raise ValueError(msg)
        return response.items[0]

    async def create_account(self, request: AccountCreateRequest) -> Account:
        """POST ``/accounts`` — создать аккаунт."""
        return await self.post(
            uri="/accounts",
            response_schema=Account,
            json=request.model_dump(mode="json", exclude_none=True, by_alias=True),
        )

    async def update_account(
        self,
        account_id: uuid.UUID,
        request: AccountUpdateRequest,
    ) -> UpdateSuccessResponse:
        """PATCH ``/accounts/{account_id}`` — обновить переданные поля."""
        return await self.patch(
            uri=f"/accounts/{account_id}",
            response_schema=UpdateSuccessResponse,
            json=request.model_dump(mode="json", exclude_unset=True, by_alias=True),
        )

    async def get_account_cookies(self, account_id: uuid.UUID) -> AccountCookies:
        """GET ``/accounts/{account_id}/cookies`` — все cookies аккаунта из БД."""
        return await self.get(
            uri=f"/accounts/{account_id}/cookies",
            response_schema=AccountCookies,
        )

    async def schedule_auth_retry(self, account_id: uuid.UUID) -> Account:
        """POST ``/accounts/{account_id}/auth-retry`` — сброс ``next_retry_at`` для воркера."""
        return await self.post(
            uri=f"/accounts/{account_id}/auth-retry",
            response_schema=Account,
        )

    async def get_account_events(
        self,
        request: AccountEventsRequest,
        *,
        http_timeout: float = 120.0,
    ) -> AccountEventsResponse:
        """GET ``/events/accounts`` — long-poll app-событий аккаунтов.

        В следующем запросе задайте ``AccountEventsRequest.offset`` равным прошлому
        ``nextOffset``, либо опустите поле — чтение с сохранённого смещения consumer group.
        """
        return await self.get(
            uri="/events/accounts",
            response_schema=AccountEventsResponse,
            params=request,
            timeout=http_timeout,
        )
