"""
Пример: POST ``/accounts`` — создание аккаунта.

Запуск:

  python -m tp_common.clients.bsp.mos_account.examples.create_account
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.mos_account.examples.create_client import (
    create_mos_account_client,
)
from tp_common.clients.bsp.mos_account.request import AccountCreateRequest


async def _run() -> None:
    try:
        client = create_mos_account_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    async with client:
        account = await client.create_account(
            AccountCreateRequest(
                login="79130858525",
                password="*",
                enable_rnis=True,
                enable_ovga=False,
            )
        )
        print(json.dumps(account.model_dump(mode="json"), indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
