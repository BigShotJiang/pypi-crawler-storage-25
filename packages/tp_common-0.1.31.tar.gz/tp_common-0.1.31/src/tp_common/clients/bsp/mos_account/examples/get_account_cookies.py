"""
Пример: GET ``/accounts/{account_id}/cookies`` — cookies аккаунта.

Переменные окружения:
  MOS_ACCOUNT_KEYCLOAK_URL или KEYCLOAK_URL — обязательно
  MOS_ACCOUNT_URL, ENV_TYPE — опционально
  ACCOUNT_ID — UUID аккаунта (обязательно)

Запуск (из корня репозитория, PYTHONPATH=src):

  python -m tp_common.clients.bsp.mos_account.examples.get_account_cookies
"""

from __future__ import annotations

import asyncio
import json
import sys
import uuid

from tp_common.clients.bsp.mos_account.examples.create_client import (
    create_mos_account_client,
)


async def _run() -> None:
    account_id = uuid.UUID("660a6f61-eb4f-4cf7-98c9-7847d58d7570")

    try:
        client = create_mos_account_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    async with client:
        cookies = await client.get_account_cookies(account_id)
        print(
            json.dumps(
                cookies.model_dump(mode="json"),
                indent=2,
                ensure_ascii=False,
            )
        )


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
