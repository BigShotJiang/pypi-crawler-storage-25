"""
Пример: GET ``/events/accounts`` — long-poll событий аккаунтов.

Запуск:

  python -m tp_common.clients.bsp.mos_account.examples.get_events
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.mos_account.examples.create_client import (
    create_mos_account_client,
)
from tp_common.clients.bsp.mos_account.request import AccountEventsRequest


async def _run() -> None:
    try:
        client = create_mos_account_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    async with client:
        resp = await client.get_account_events(AccountEventsRequest(limit=5))
        print(json.dumps(resp.model_dump(mode="json"), indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
