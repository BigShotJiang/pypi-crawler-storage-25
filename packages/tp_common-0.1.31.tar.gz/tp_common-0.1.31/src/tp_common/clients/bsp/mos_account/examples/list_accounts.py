"""
Пример: GET ``/accounts`` — список аккаунтов с пагинацией.

Переменные окружения:
  MOS_ACCOUNT_KEYCLOAK_URL или KEYCLOAK_URL — обязательно
  MOS_ACCOUNT_URL, ENV_TYPE — опционально

Запуск (из корня репозитория, PYTHONPATH=src):

  python -m tp_common.clients.bsp.mos_account.examples.list_accounts
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.mos_account.examples.create_client import (
    create_mos_account_client,
)
from tp_common.clients.bsp.mos_account.request import AccountsRequest


async def _run() -> None:
    try:
        client = create_mos_account_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    async with client:
        resp = await client.get_accounts(AccountsRequest(limit=5))  # pyright: ignore[reportCallIssue]

        print(json.dumps(resp.model_dump(mode="json"), indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
