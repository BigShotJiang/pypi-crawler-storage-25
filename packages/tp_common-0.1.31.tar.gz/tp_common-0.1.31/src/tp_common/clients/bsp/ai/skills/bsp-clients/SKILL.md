---
name: bsp-clients
description: Use when creating or modifying BSP service clients in tp-common (BspAvtodorClient, BspMosAccountClient, CamoufoxClient, MosPassClient), when calling BSP service APIs from other services, when implementing get_events long-poll endpoints, or when the user asks about "клиент к сервису", "как вызвать API автодора/мосаккаунта/камуфокса/моспасса", "создать клиент для bsp-*". Provides exact constructors, URL mapping, event handling patterns, and examples for all BSP clients.
---

# BSP Clients

Guide for creating and using BSP service clients in `tp-common`.

## Client Structure

Every client inherits from `KeycloakClient` and follows this pattern:

```
clients/bsp/<service>/
├── __init__.py
├── client.py      # Client class + URL mapping
├── request.py     # Request schemas
├── response.py    # Response schemas
└── examples/      # Usage examples
```

## Creating a New Client

```python
from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.tp_logging import TpLogger


class XxxClient(KeycloakClient):
    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        xxx_url: str | None = None,         # None → auto from env_type
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        base_url = self._build_base_url(xxx_url=xxx_url, env_type=env_type)
        super().__init__(
            base_url=base_url,
            logger=logger,
            audience="bsp-xxx",
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    @classmethod
    def _build_base_url(cls, *, xxx_url: str | None, env_type: EnvironmentType) -> str:
        return (xxx_url or cls._base_url_by_env_type(env_type)).rstrip("/") + "/"

    @staticmethod
    def _base_url_by_env_type(env_type: EnvironmentType) -> str:
        match env_type:
            case EnvironmentType.PROD:
                return "https://bsp.8525.ru/xxx/"
            case EnvironmentType.STAGING:
                return "https://bsp-xxx.bsp-staging.bz/"
            case EnvironmentType.DEV:
                return "https://bsp-xxx.bsp-dev.bz/"
            case _:
                return "http://127.0.0.0:8085/"
```

## API Methods

```python
# GET with response schema
async def get_xxx(self, request: XxxRequest) -> XxxResponse:
    return await self.get(uri="/xxx", response_schema=XxxResponse, params=request)

# POST with JSON body
async def create_xxx(self, request: XxxCreateRequest) -> Xxx:
    return await self.post(uri="/xxx/add", response_schema=Xxx, json=request)

# PATCH
async def update_xxx(self, id: uuid.UUID, request: XxxUpdateRequest) -> Xxx:
    return await self.patch(uri=f"/xxx/{id}", response_schema=Xxx, json=request)
```