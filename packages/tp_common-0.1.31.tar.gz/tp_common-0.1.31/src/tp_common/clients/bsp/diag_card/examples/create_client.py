"""Создание BspDiagCardClient для примеров (переменные окружения, .env рядом с примерами)."""

from __future__ import annotations

import os
from pathlib import Path

from tp_common.clients.bsp.diag_card.client import BspDiagCardClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLoggerFactory
from tp_common.utils import find_env_file, load_env_file


def _env_type_from_os() -> EnvironmentType:
    raw = os.getenv("ENV_TYPE", "").strip().lower()
    if not raw:
        return EnvironmentType.DEV
    try:
        return EnvironmentType(raw)
    except ValueError:
        return EnvironmentType.DEV


def create_diag_card_client(
    *,
    keycloak_url: str | None = None,
    diag_card_url: str | None = None,
    logger_name: str = "bsp_diag_card_examples",
) -> BspDiagCardClient:
    """Собирает HTTP-клиент к bsp-diag-card из окружения.

    Переменные:
      DIAG_CARD_KEYCLOAK_URL или KEYCLOAK_URL — URL Keycloak с учётными данными в userinfo.
      DIAG_CARD_URL — опционально, иначе базовый URL по ``ENV_TYPE`` (как у клиента).
      ENV_TYPE — опционально: local | dev | staging | prod (по умолчанию dev).
    """
    _env_path = find_env_file(anchor=Path(__file__))
    if _env_path:
        load_env_file(_env_path)

    url = (
        keycloak_url
        or os.getenv("DIAG_CARD_KEYCLOAK_URL", "").strip()
        or os.getenv("KEYCLOAK_URL", "").strip()
    )
    if not url:
        raise ValueError(
            "Укажите DIAG_CARD_KEYCLOAK_URL или KEYCLOAK_URL, например:\n"
            "  https://my_client:secret@keycloak.example.com"
        )

    resolved_diag_url = diag_card_url
    if resolved_diag_url is None:
        from_env = os.getenv("DIAG_CARD_URL", "").strip()
        resolved_diag_url = from_env or None

    env_type = _env_type_from_os()
    logger = TpLoggerFactory(env_type).get_logger(logger_name, use_queue=False)

    return BspDiagCardClient(
        logger=logger,
        keycloak_url=url,
        env_type=env_type,
        diag_card_url=resolved_diag_url,
    )
