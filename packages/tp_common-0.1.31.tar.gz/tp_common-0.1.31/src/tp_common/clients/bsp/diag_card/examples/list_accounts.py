"""
Пример запроса к BspDiagCardClient: GET ``/account`` — список аккаунтов (с пагинацией до конца).

Переменные окружения:
  DIAG_CARD_KEYCLOAK_URL или KEYCLOAK_URL — обязательно,
    https://client_id:client_secret@keycloak.host
  DIAG_CARD_URL — опционально, по умолчанию как у клиента для ``ENV_TYPE``
  ENV_TYPE — опционально, local | dev | staging | prod (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):

  set DIAG_CARD_KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.diag_card.examples.list_accounts
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.diag_card.examples.create_client import (
    create_diag_card_client,
)
from tp_common.clients.bsp.diag_card.request import AccountsListRequest


async def _run() -> None:
    try:
        client = create_diag_card_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    limit = 500
    offset = 0
    all_rows: list[dict[str, object]] = []

    async with client:
        while True:
            batch = await client.list_accounts(
                AccountsListRequest(limit=limit, offset=offset)
            )
            for acc in batch:
                all_rows.append(acc.model_dump(mode="json"))
            if len(batch) < limit:
                break
            offset += limit

    print(json.dumps(all_rows, indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
