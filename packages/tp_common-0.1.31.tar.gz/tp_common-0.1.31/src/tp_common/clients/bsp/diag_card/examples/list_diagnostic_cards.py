"""
Пример запроса к BspDiagCardClient: GET ``/diagnostic-cards``.

Список диагностических карт (``items``, ``total``). Параметр query ``vin`` опционален:
без аргумента — все карты; с VIN — фильтр по 17 символам.

Переменные окружения:
  DIAG_CARD_KEYCLOAK_URL или KEYCLOAK_URL — обязательно,
    https://client_id:client_secret@keycloak.host
  DIAG_CARD_URL — опционально, по умолчанию как у клиента для ``ENV_TYPE``
  ENV_TYPE — опционально, local | dev | staging | prod (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):

  set DIAG_CARD_KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.diag_card.examples.list_diagnostic_cards
  python -m tp_common.clients.bsp.diag_card.examples.list_diagnostic_cards WBAZZZ123456789012
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.diag_card.examples.create_client import (
    create_diag_card_client,
)
from tp_common.clients.bsp.diag_card.request import DiagnosticCardsVinFilter


async def _run() -> None:
    try:
        client = create_diag_card_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    if len(sys.argv) >= 2:
        filters = DiagnosticCardsVinFilter(vin=sys.argv[1])
    else:
        filters = DiagnosticCardsVinFilter(vin=None)

    async with client:
        result = await client.list_diagnostic_cards(filters)

    print(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
