"""Тела запросов и query-фильтры HTTP-клиента bsp-diag-card."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, field_validator
from pydantic.alias_generators import to_camel

from tp_common.route.schemes import BaseAppEventMessagesQueryParams


class ApiModel(BaseModel):
    model_config = ConfigDict(alias_generator=to_camel, populate_by_name=True)


class AccountStatus(StrEnum):
    IN_WORK = "in_work"
    IDLE = "idle"


class TaskStatus(StrEnum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    ABANDONED = "abandoned"


class DcOperatorStatus(StrEnum):
    ACTIVE = "active"
    PAUSED = "paused"
    CANCELLED = "cancelled"


def _normalize_vin(value: str) -> str:
    vin = value.strip().upper()
    if len(vin) != 17:
        msg = "VIN must contain exactly 17 characters"
        raise ValueError(msg)
    return vin


class AccountCreateRequest(ApiModel):
    email: str = Field(
        ...,
        description="E-mail аккаунта; уникален в сервисе (на стороне API нормализуется).",
    )
    cookies: str = Field(
        ...,
        description="Строка Cookie для провайдеров (допустима пустая строка).",
    )

    password: str = Field(...)


class AccountReplaceRequest(ApiModel):
    cookies: str = Field(
        ...,
        description="Строка Cookie для провайдеров (допустима пустая строка).",
    )
    status: AccountStatus = Field(
        ...,
        description="Статус использования аккаунта воркером.",
    )
    next_usage_at: datetime | None = Field(
        ...,
        description="Время следующего использования; null — аккаунт не использовать.",
    )


class AccountsListRequest(ApiModel):
    limit: int = Field(default=100, ge=1, le=500)
    offset: int = Field(default=0, ge=0)
    status: AccountStatus | None = None


# ---------------------------------------------------------------------------
# Транспорт (``/vehicle``)
# ---------------------------------------------------------------------------


class VehicleVinFilter(ApiModel):
    """Фильтр query GET ``/vehicle`` — выборка ТС по VIN (17 символов)."""

    vin: str = Field(
        ...,
        min_length=17,
        max_length=17,
        description="VIN транспортного средства (17 символов).",
    )

    @field_validator("vin")
    @classmethod
    def normalize_vin(cls, value: str) -> str:
        return _normalize_vin(value)


VehicleByVinRequest = VehicleVinFilter


class VehicleSyncRequest(ApiModel):
    vins: list[str] = Field(default_factory=list)

    @field_validator("vins")
    @classmethod
    def normalize_vins(cls, value: list[str]) -> list[str]:
        return list({_normalize_vin(vin) for vin in value})


class VehicleEnsureTaskRequest(ApiModel):
    """Тело POST ``/vehicles/ensure`` (как ``VehicleEnsureTaskRequest`` в bsp-diag-card)."""

    vin: str = Field(min_length=17, max_length=17)

    @field_validator("vin")
    @classmethod
    def normalize_vin(cls, value: str) -> str:
        return _normalize_vin(value)


# ---------------------------------------------------------------------------
# Диагностические карты (``/diagnostic-cards``)
# ---------------------------------------------------------------------------


class DiagnosticCardsVinFilter(ApiModel):
    """Фильтр query GET ``/diagnostic-cards`` по VIN (опционально)."""

    vin: str | None = Field(
        None,
        description="VIN (17 символов); без параметра — без фильтра по VIN.",
    )

    @field_validator("vin")
    @classmethod
    def normalize_vin(cls, value: str | None) -> str | None:
        if value is None:
            return None
        stripped = value.strip()
        if not stripped:
            return None
        return _normalize_vin(stripped)


DiagnosticCardsByVinRequest = DiagnosticCardsVinFilter


# ---------------------------------------------------------------------------
# Задачи и события
# ---------------------------------------------------------------------------


class TaskEventsRequest(BaseAppEventMessagesQueryParams):
    """Параметры long-poll GET ``/events/tasks`` (bsp-diag-card): offset / limit / timeout."""
