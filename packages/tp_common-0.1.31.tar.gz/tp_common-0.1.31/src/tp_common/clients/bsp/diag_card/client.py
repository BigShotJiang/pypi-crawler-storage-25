from __future__ import annotations

import uuid

from tp_common.clients.bsp.diag_card.request import (
    AccountCreateRequest,
    AccountReplaceRequest,
    AccountsListRequest,
    DiagnosticCardsVinFilter,
    TaskEventsRequest,
    VehicleEnsureTaskRequest,
    VehicleSyncRequest,
    VehicleVinFilter,
)
from tp_common.clients.bsp.diag_card.response import (
    AccountResponse,
    AccountsResponse,
    DiagnosticCardsResponse,
    TaskEventsResponse,
    TaskStatisticsResponse,
    VehicleEnsureTaskResponse,
    VehicleFullResponse,
    VehicleOperatorResponse,
    VehicleResponse,
    VehicleStatisticsResponse,
    VehicleSyncResponse,
)
from tp_common.keycloak.client import KeycloakClient
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class BspDiagCardClient(KeycloakClient):
    """HTTP-клиент к bsp-diag-card (``/api/v1``).

    Пути: ``/account`` (POST: ``email`` + ``cookies``), ``/vehicles`` (query ``vin``, ``/by-vin/{vin}``, ``/{vehicle_id}``, ``/sync``, ``/ensure``),
    ``/diagnostic-cards``, ``/diagnostic-card-operators/{operator_id}``, ``/events/tasks``,
    ``/statistics/tasks``, ``/statistics/vehicles``.
    """

    def __init__(
        self,
        *,
        keycloak_url: str | None = None,
        logger: TpLogger,
        diag_card_url: str | None = None,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 3,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = False,
    ) -> None:
        resolved_base_url = self._build_base_url(
            diag_card_url=diag_card_url, env_type=env_type
        )
        super().__init__(
            base_url=resolved_base_url,
            logger=logger,
            audience="bsp-diag-card",
            keycloak_oauth=keycloak_oauth,
            keycloak_url=keycloak_url,
            env_type=env_type,
            max_retries=max_retries,
            token_min_ttl_s=token_min_ttl_s,
            verify_ssl=verify_ssl,
        )

    @classmethod
    def _build_base_url(
        cls, *, diag_card_url: str | None, env_type: EnvironmentType
    ) -> str:
        base = (diag_card_url or cls._base_url_by_env_type(env_type)).rstrip("/")
        return f"{base}{cls._api_version_path().rstrip('/')}/"

    @staticmethod
    def _api_version_path() -> str:
        return "/v1"

    @staticmethod
    def _base_url_by_env_type(env_type: EnvironmentType) -> str:
        match env_type:
            case EnvironmentType.STAGING:
                return "https://diag-card.bsp-staging.bz/api"
            case EnvironmentType.PROD:
                return "https://bsp.8525.ru/diag-card/api"
            case _:
                return "https://diag-card.bsp-dev.bz/api"

    async def list_accounts(
        self, request: AccountsListRequest
    ) -> list[AccountResponse]:
        response = await self.get(
            "/account",
            AccountsResponse,
            params=request,
        )
        return response.root

    async def get_account(self, account_id: uuid.UUID) -> AccountResponse:
        return await self.get(f"/account/{account_id}", AccountResponse)

    async def create_account(self, request: AccountCreateRequest) -> AccountResponse:
        return await self.post(
            "/account",
            AccountResponse,
            body=request,
        )

    async def replace_account(
        self, account_id: uuid.UUID, request: AccountReplaceRequest
    ) -> AccountResponse:
        return await self.put(
            f"/account/{account_id}",
            AccountResponse,
            body=request,
        )

    async def get_vehicle(
        self,
        filters: VehicleVinFilter,
    ) -> VehicleResponse:
        """GET ``/vehicle`` с query-параметром ``vin``."""
        return await self.get(
            "/vehicles",
            VehicleResponse,
            params=filters,
        )

    async def get_vehicle_full_by_vin(self, vin: str) -> VehicleFullResponse:
        """GET ``/vehicles/by-vin/{vin}`` — полная схема с оператором (VIN 17 символов).

        Пример относительного пути после нормализации VIN: ``/vehicles/by-vin/WBAZZZ123456789012``.
        """
        normalized = VehicleVinFilter(vin=vin).vin
        return await self.get(
            f"/vehicles/by-vin/{normalized}",
            VehicleFullResponse,
        )

    async def get_vehicle_by_id(self, vehicle_id: uuid.UUID) -> VehicleFullResponse:
        """GET ``/vehicles/{vehicle_id}`` — полная схема с оператором."""
        return await self.get(f"/vehicles/{vehicle_id}", VehicleFullResponse)

    async def list_diagnostic_cards(
        self,
        filters: DiagnosticCardsVinFilter,
    ) -> DiagnosticCardsResponse:
        """GET ``/diagnostic-cards``: список карт (``items``, ``total``); query ``vin`` опционален.

        Примеры относительного пути: ``/diagnostic-cards`` (без фильтра);
        с VIN в query: ``/diagnostic-cards?vin=WBAZZZ123456789012``.
        """
        return await self.get(
            "/diagnostic-cards",
            DiagnosticCardsResponse,
            params=filters,
        )

    async def get_diagnostic_card_operator(
        self, operator_id: int
    ) -> VehicleOperatorResponse:
        """GET ``/diagnostic-card-operators/{operator_id}`` (контактные поля оператора всегда заполнены в API)."""
        return await self.get(
            f"/diagnostic-card-operators/{operator_id}",
            VehicleOperatorResponse,
        )

    async def sync_vehicles(self, request: VehicleSyncRequest) -> VehicleSyncResponse:
        """POST ``/vehicles/sync``."""
        return await self.post(
            "/vehicles/sync",
            VehicleSyncResponse,
            body=request,
        )

    async def ensure_vehicle_task(
        self, request: VehicleEnsureTaskRequest
    ) -> VehicleEnsureTaskResponse:
        """POST ``/vehicles/ensure``: при отсутствии ТС по VIN создаёт запись и привязку к сервису из Bearer; незавершённую задачу поднимает по приоритету, иначе создаёт новую pending."""
        return await self.post(
            "/vehicles/ensure",
            VehicleEnsureTaskResponse,
            body=request,
        )

    async def poll_task_events(
        self,
        request: TaskEventsRequest,
    ) -> TaskEventsResponse:
        """Long-poll событий по задачам: GET ``/events/tasks``; ``service_id`` из Bearer.

        В следующем запросе задайте ``TaskEventsRequest.offset`` равным прошлому ``nextOffset``,
        либо опустите поле — чтение с сохранённого смещения consumer group. Алиасы query:
        ``offset``, ``nextOffset``, ``next_offset``.
        """
        return await self.get(
            "/events/tasks",
            TaskEventsResponse,
            params=request,
            timeout=120,
        )

    async def get_tasks_statistics(self) -> TaskStatisticsResponse:
        """GET ``/statistics/tasks`` — агрегаты по задачам (таблица ``tasks``)."""
        return await self.get("/statistics/tasks", TaskStatisticsResponse)

    async def get_vehicles_statistics(self) -> VehicleStatisticsResponse:
        """GET ``/statistics/vehicles`` — агрегаты по ТС и связанным сущностям."""
        return await self.get("/statistics/vehicles", VehicleStatisticsResponse)
