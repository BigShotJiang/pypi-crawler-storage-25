"""
Пример: POST ``/account`` — создание учётной записи воркера diag-card (сущность «аккаунт» в сервисе).

HTTP-клиент собирается в ``create_client.create_diag_card_client`` — это отдельно от этого шага.

Переменные окружения:
  DIAG_CARD_KEYCLOAK_URL или KEYCLOAK_URL — обязательно
  DIAG_CARD_URL, ENV_TYPE — как в ``create_client``
  DIAG_CARD_ACCOUNT_EMAIL — e-mail (обязателен, если не передан первым аргументом)
  DIAG_CARD_ACCOUNT_COOKIES — опционально, строка Cookie (по умолчанию пустая)

Запуск (из корня репозитория, с PYTHONPATH=src):

  set DIAG_CARD_KEYCLOAK_URL=...
  set DIAG_CARD_ACCOUNT_EMAIL=user@example.com
  python -m tp_common.clients.bsp.diag_card.examples.create_account

Аргументы: ``email`` [``cookies``] — перекрывают переменные окружения.

  python -m tp_common.clients.bsp.diag_card.examples.create_account user@example.com "session=..."
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.diag_card.examples.create_client import (
    create_diag_card_client,
)
from tp_common.clients.bsp.diag_card.request import AccountCreateRequest


async def _run() -> None:
    try:
        client = create_diag_card_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    email = "front-gold@mail.ru"
    password = "*****"

    cookies = "_ym_uid=1775819654982550527;"

    async with client:
        acc = await client.create_account(
            AccountCreateRequest(email=email, cookies=cookies, password=password)
        )

    print(json.dumps(acc.model_dump(mode="json"), indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
