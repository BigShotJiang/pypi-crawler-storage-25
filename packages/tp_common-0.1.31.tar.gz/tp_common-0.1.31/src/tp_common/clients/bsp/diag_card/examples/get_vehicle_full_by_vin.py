"""
Пример запроса к BspDiagCardClient: GET ``/vehicles/by-vin/{vin}``.

Полная карточка ТС с оператором; VIN в URL — ровно 17 символов (нормализация как в ``VehicleVinFilter``).

Переменные окружения:
  DIAG_CARD_KEYCLOAK_URL или KEYCLOAK_URL — обязательно,
    https://client_id:client_secret@keycloak.host
  DIAG_CARD_URL — опционально, по умолчанию как у клиента для ``ENV_TYPE``
  ENV_TYPE — опционально, local | dev | staging | prod (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):

  set DIAG_CARD_KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.diag_card.examples.get_vehicle_full_by_vin WBAZZZ123456789012
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.diag_card.examples.create_client import (
    create_diag_card_client,
)


async def _run() -> None:
    vin = "X0V6712A5C0000008"

    try:
        client = create_diag_card_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    async with client:
        result = await client.get_vehicle_full_by_vin(vin)

    print(json.dumps(result.model_dump(mode="json"), indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
