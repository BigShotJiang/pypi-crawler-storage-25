"""
Пример запроса к BspDiagCardClient: GET ``/statistics/tasks`` и ``/statistics/vehicles``.

Переменные окружения:
  DIAG_CARD_KEYCLOAK_URL или KEYCLOAK_URL — обязательно,
    https://client_id:client_secret@keycloak.host
  DIAG_CARD_URL — опционально, по умолчанию как у клиента для ``ENV_TYPE``
  ENV_TYPE — опционально, local | dev | staging | prod (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):

  set DIAG_CARD_KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.diag_card.examples.statistics
"""

from __future__ import annotations

import asyncio
import json
import sys

from tp_common.clients.bsp.diag_card.examples.create_client import (
    create_diag_card_client,
)


async def _run() -> None:
    try:
        client = create_diag_card_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    async with client:
        tasks_stats = await client.get_tasks_statistics()
        vehicles_stats = await client.get_vehicles_statistics()

    out = {
        "tasks": tasks_stats.model_dump(mode="json"),
        "vehicles": vehicles_stats.model_dump(mode="json"),
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
