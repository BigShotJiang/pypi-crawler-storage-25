"""Ответы HTTP-клиента bsp-diag-card."""

from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import Field, RootModel, field_validator

from tp_common.clients.bsp.diag_card.request import (
    AccountStatus,
    ApiModel,
    DcOperatorStatus,
    TaskStatus,
)
from tp_common.kafka.app_event import BaseAppEventMessage
from tp_common.route.schemes import (
    BaseAppEventMessagesResponse,
    BaseQueryResponse,
    BaseResponse,
)


class AccountResponse(ApiModel):
    account_id: uuid.UUID
    email: str
    cookies: str
    status: AccountStatus
    next_usage_at: datetime | None
    created_at: datetime
    updated_at: datetime


class AccountsResponse(RootModel[list[AccountResponse]]):
    pass


class VehicleDiagnosticCardResponse(ApiModel):
    card_id: uuid.UUID
    card_number: str = Field(
        ...,
        max_length=255,
        description=(
            "Номер ДК/ЕАИСТО строкой цифр; в API bsp-diag-card соответствует "
            "``diagnostic_cards.card_number`` (VARCHAR(255), не integer)."
        ),
    )
    task_id: uuid.UUID
    vin: str
    start_date: date
    end_date: date
    odometer_value: int
    operator_id: int
    created_at: datetime
    updated_at: datetime

    @field_validator("card_number", mode="before")
    @classmethod
    def _card_number_coerce_str(cls, value: object) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, bool):
            msg = "card_number: unexpected bool"
            raise ValueError(msg)
        if isinstance(value, int):
            return str(value)
        msg = f"card_number: expected str or int, got {type(value).__name__}"
        raise ValueError(msg)


class VehicleResponse(ApiModel):
    vehicle_id: uuid.UUID
    vin: str
    next_retry_at: datetime | None
    diagnostic_cards: list[VehicleDiagnosticCardResponse] = Field(default_factory=list)


class VehicleSyncResponse(ApiModel):
    added: int
    deleted: int


class VehicleOperatorResponse(ApiModel):
    operator_id: int
    status: DcOperatorStatus
    name: str
    address_line: str
    phone_number: str
    email: str
    website: str | None
    cancelled_date: date | None


class VehicleDiagnosticCardWithOperatorResponse(VehicleDiagnosticCardResponse):
    operator: VehicleOperatorResponse | None = None


class VehicleFullResponse(ApiModel):
    vehicle_id: uuid.UUID
    vin: str
    next_retry_at: datetime | None
    diagnostic_cards: list[VehicleDiagnosticCardWithOperatorResponse]


class DiagnosticCardsResponse(BaseQueryResponse[VehicleDiagnosticCardResponse]):
    """Ответ GET ``/diagnostic-cards`` (``items`` + ``total``)."""


class VehicleEnsureTaskResponse(BaseResponse):
    """Ответ POST ``/vehicles/ensure`` (как ``VehicleEnsureTaskResponse`` в bsp-diag-card)."""

    task_id: uuid.UUID
    vin: str
    priority: int
    status: TaskStatus
    started_at: datetime | None
    completed_at: datetime | None
    error_message: str | None
    created_at: datetime
    updated_at: datetime


class AppTaskEventMessage(BaseAppEventMessage):
    """Тело app-event задачи (как ``TaskAppEventMessage`` в bsp-diag-card / Kafka)."""

    task_id: uuid.UUID
    vin: str = Field(description="VIN транспортного средства")


class TaskEventMessage(BaseResponse, AppTaskEventMessage):
    """Один элемент ``messages`` в ответе GET ``/events/tasks``."""


class TaskEventsResponse(BaseAppEventMessagesResponse[TaskEventMessage]):
    pass


# ---------------------------------------------------------------------------
# Статистика (``/statistics/tasks``, ``/statistics/vehicles``)
# ---------------------------------------------------------------------------


class TaskStatusCountItem(ApiModel):
    status: TaskStatus
    count: int


class TaskPriorityBucketItem(ApiModel):
    bucket: str
    count: int


class TaskVinTopItem(ApiModel):
    vin: str
    task_count: int


class TaskStatisticsResponse(ApiModel):
    total_tasks: int
    distinct_vins_with_tasks: int
    by_status: list[TaskStatusCountItem]
    unfinished_tasks: int
    tasks_with_started_at: int
    tasks_with_completed_at: int
    tasks_with_error_message: int
    priority_min: int | None
    priority_max: int | None
    priority_avg: float | None
    by_priority_bucket: list[TaskPriorityBucketItem]
    created_at_min: datetime | None
    created_at_max: datetime | None
    updated_at_min: datetime | None
    updated_at_max: datetime | None
    started_at_min: datetime | None
    started_at_max: datetime | None
    completed_at_min: datetime | None
    completed_at_max: datetime | None
    avg_completion_duration_sec: float | None
    top_vins_by_task_count: list[TaskVinTopItem]
    tasks_vin_not_in_vehicles: int


class VehicleServiceIdCountItem(ApiModel):
    service_id: str
    links_count: int


class VehicleStatisticsResponse(ApiModel):
    total_vehicles: int
    next_retry_at_null_count: int
    next_retry_at_set_count: int
    next_retry_at_min: datetime | None
    next_retry_at_max: datetime | None
    due_for_retry_now_count: int
    created_at_min: datetime | None
    created_at_max: datetime | None
    updated_at_min: datetime | None
    updated_at_max: datetime | None
    diagnostic_cards_total: int
    distinct_vins_with_diagnostic_cards: int
    diagnostic_cards_vin_not_in_vehicles: int
    vehicles_with_diagnostic_cards: int
    vehicles_without_diagnostic_cards: int
    avg_diagnostic_cards_per_vehicle: float | None
    vehicle_services_links_total: int
    distinct_vehicle_ids_in_vehicle_services: int
    vehicle_services_by_service_id: list[VehicleServiceIdCountItem]
    vehicles_with_any_task: int
    vehicles_without_tasks: int
    vehicles_with_unfinished_task: int
    total_tasks_for_existing_vehicles: int
    unfinished_tasks_for_existing_vehicles: int
