"""
Пример запроса к MosPassClient: list_tasks.

Переменные окружения:
  MOS_PASS_KEYCLOAK_URL или KEYCLOAK_URL — обязательно,
    https://client_id:client_secret@keycloak.host
  MOS_PASS_URL   — опционально, по умолчанию как у клиента
  ENV_TYPE       — опционально, LOCAL | DEV | … (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):
  set MOS_PASS_KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.mos_pass.examples.demo_requests
"""

from __future__ import annotations

import asyncio
import sys

from tp_common.clients.bsp.mos_pass.examples.create_client import create_mos_pass_client
from tp_common.clients.bsp.mos_pass.request import TasksRequest


async def _run() -> None:
    try:
        client = create_mos_pass_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    try:
        async with client:
            resp = await client.list_tasks(TasksRequest(is_completed=False))
            print("list_tasks ->", resp.model_dump())
    except Exception:
        ...


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
