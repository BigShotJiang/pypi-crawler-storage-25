"""Схемы ответов клиента bsp-mos-pass (зеркало ``bsp-mos-pass/src/api/v1/*/response.py``).

События задач: ``GET /events/tasks`` (``service_id`` из Keycloak) — ``TaskEventsResponse``.
ТС: ``POST /vehicles/retry-at/reset`` — ``retry_at`` в «сейчас», ``VehicleRetryAtResetResponse.updated``.
"""

from __future__ import annotations

import uuid
from datetime import date, datetime

from pydantic import BaseModel, ConfigDict, Field, RootModel

from tp_common.clients.bsp.mos_pass.request import (
    PassAllowedZone,
    PassSeries,
    PassStatus,
    TaskStatus,
    TimeOfDay,
)
from tp_common.route.schemes import (
    BaseAppEventMessagesResponse,
    BaseQueryResponse,
    BaseResponse,
)


class PassFull(BaseResponse):
    pass_id: uuid.UUID
    pass_foreign_id: int = Field(
        description="Идентификатор пропуска во внешней системе (t.mos.ru)"
    )
    pass_uuid: uuid.UUID
    time_of_day: TimeOfDay
    reg_number: str
    series: PassSeries
    number: str
    allowed_zone: PassAllowedZone
    start_date: date
    end_date: date
    cancel_date: date | None
    pass_type: str
    pass_status: PassStatus
    change_date: datetime | None
    drivers: str


class PassesResponse(BaseQueryResponse[PassFull]):
    """Список пропусков."""


class Task(BaseResponse):
    task_id: int
    vehicle_id: uuid.UUID | None
    reg_number: str | None
    number: str | None
    series: PassSeries | None
    found_all: int
    found_new: int
    found_cancel: int
    priority: int
    last_used_at: datetime | None
    completed_at: datetime | None
    task_status: TaskStatus
    updated_at: datetime
    created_at: datetime


class TasksResponse(BaseQueryResponse[Task]):
    """Список задач."""


class Vehicle(BaseResponse):
    vehicle_id: uuid.UUID
    reg_number: str
    priority: int
    retry_at: datetime
    created_at: datetime
    updated_at: datetime


class VehicleResponse(Vehicle):
    """Ответ PATCH /vehicles/retry-task."""


class VehiclesResponse(RootModel[list[Vehicle]]):
    """Массовое создание ТС: массив в корне JSON."""


class VehicleSyncResponse(BaseResponse):
    added: int
    deleted: int


class VehicleRetryAtResetResponse(BaseResponse):
    """Ответ ``POST /vehicles/retry-at/reset`` (число ТС с выставленным ``retry_at``)."""

    updated: int


class MosPassTaskAppEventPayload(BaseModel):
    """Поля тела app-event задачи (как ``AppTaskEventMessage`` в Kafka)."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    timestamp: datetime
    schema_version: str = "1"
    event_type: str
    reg_number: str
    task_id: uuid.UUID


class TaskEventMessage(BaseResponse, MosPassTaskAppEventPayload):
    """Один элемент массива ``messages`` в ответе ``GET /events/tasks/{service_id}``."""


class TaskEventsResponse(BaseAppEventMessagesResponse[TaskEventMessage]):
    """Long-poll: ``messages`` + ``nextOffset`` (зеркало ``bsp-mos-pass`` ``TaskEventsResponse``)."""
