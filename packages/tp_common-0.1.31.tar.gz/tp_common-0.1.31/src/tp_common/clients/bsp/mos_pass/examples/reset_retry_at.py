"""
Пример запроса к MosPassClient: reset_vehicles_retry_at (POST /vehicles/retry-at/reset).

Ставит ``retry_at`` в текущий момент для всех ТС сервиса (Keycloak), чтобы планировщик поставил задачи.

Переменные окружения:
  MOS_PASS_KEYCLOAK_URL или KEYCLOAK_URL — обязательно,
    https://client_id:client_secret@keycloak.host
  MOS_PASS_URL   — опционально, по умолчанию как у клиента
  ENV_TYPE       — опционально, LOCAL | DEV | … (см. EnvironmentType)

Запуск (из корня репозитория, с PYTHONPATH=src):
  set MOS_PASS_KEYCLOAK_URL=...
  python -m tp_common.clients.bsp.mos_pass.examples.reset_retry_at
"""

from __future__ import annotations

import asyncio
import sys

from tp_common.clients.bsp.mos_pass.examples.create_client import create_mos_pass_client


async def _run() -> None:
    try:
        client = create_mos_pass_client()
    except ValueError as e:
        print(e, file=sys.stderr)
        raise SystemExit(2) from e

    async with client:
        resp = await client.reset_vehicles_retry_at()
        print("vehicles/retry-at/reset ->", resp.model_dump())


def main() -> None:
    asyncio.run(_run())


if __name__ == "__main__":
    main()
