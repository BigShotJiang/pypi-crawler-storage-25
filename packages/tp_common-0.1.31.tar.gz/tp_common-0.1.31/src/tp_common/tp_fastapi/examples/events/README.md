# Пример: Events (Kafka) в FastAPI

Пример API для чтения app-events из Kafka: long-polling эндпоинт с опциональным `next_offset`.

## Что показывает

- Подключение к Kafka через `KafkaConnector` и `TpFastapiEventsExampleService` (`tp_common.tp_fastapi.examples.events.service`) — наследник `TaskAppEvent`, сообщения `TaskAppEventMessage`, топик `example.events.my_client`.
- Эндпоинт `GET /events` с параметрами: опциональный `next_offset`, `limit`, `timeout`. Источник зафиксирован в коде (`example.events.my_client`).
- Без `next_offset` — `read_from_committed_ready`; с `next_offset` — `read_from_next_offset_ready`.
- Ответ: массив `{ "payload": {...}, "offset": <int> }`. Следующий запрос сценария А: `next_offset = offset + 1`.
- Топик с **одной партицией**; иначе 422.
- TpLogger и trace_id в запросе (middleware, `get_request_logger`).
- Наследование от `TPException`: `EventReadException` с фиксированным message/status_code и передачей `trace_id` при ошибке чтения.

## Запуск

Нужен доступный Kafka.

```bash
uvicorn tp_common.tp_fastapi.examples.events.app:app --reload --port 8000
```

## Примеры запросов

```bash
curl "http://127.0.0.1:8000/events?limit=100"
curl "http://127.0.0.1:8000/events?next_offset=0&limit=100"
```

Альтернативный пример рядом с модулем `app_event` (секреты в одном `.env`, см. `tp_common/kafka/app_event/examples/env.example` и `settings.py`):

```bash
uvicorn tp_common.kafka.app_event.examples.01_fast_api:app --host 127.0.0.1 --port 8002
```
