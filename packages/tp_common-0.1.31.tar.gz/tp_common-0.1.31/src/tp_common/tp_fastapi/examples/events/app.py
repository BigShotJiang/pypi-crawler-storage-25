"""
Пример: использование events (Kafka) в FastAPI.

Эндпоинт GET /events возвращает список сообщений в формате ``{payload, offset}``.
  - без ``next_offset`` — чтение с последней committed позиции;
  - с ``next_offset`` — seek + commit на эту позицию, затем пачка.
  - 200: массив объектов, может быть пустым; 422: неверный контракт (например не одна партиция);
  - 500: ошибка (Kafka/таймаут); в логе trace_id.

Топик должен иметь **одну партицию** (контракт AppEventService).

Запуск (Kafka должен быть доступен):
  uvicorn tp_common.tp_fastapi.examples.events.app:app --reload --port 8000

Примеры запроса (топик зафиксирован: example.events.my_client):
  curl "http://127.0.0.1:8000/events?limit=100"
  curl "http://127.0.0.1:8000/events?next_offset=0&limit=100"
"""

import logging
import os
import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from http import HTTPStatus

from fastapi import Depends, FastAPI, HTTPException, Query
from fastapi.responses import JSONResponse, Response

from tp_common.exceptions.exceptions import TpException
from tp_common.kafka.app_event.examples.task_app_event import TaskAppEvent
from tp_common.kafka.connector import KafkaConnector
from tp_common.tp_fastapi.examples.events.service import create_task_app_event_service
from tp_common.tp_fastapi.middleware import TpMiddleware
from tp_common.tp_logger.fastapi_integration import get_request_logger
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory

logging.basicConfig(level=logging.INFO)
logger_factory = TpLoggerFactory(env=EnvironmentType.LOCAL)
logger = logger_factory.get_logger("example_api")


class EventReadException(TpException):
    """Ошибка чтения событий из Kafka (таймаут, сбой и т.д.)."""

    def __init__(
        self,
        *,
        trace_id: uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message="Internal Server Error",
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            trace_id=trace_id,
        )


def get_kafka_connector() -> KafkaConnector:
    url = os.environ.get("KAFKA_URL", "plaintext://localhost:9092")
    return KafkaConnector(url, logger=logger)


@asynccontextmanager
async def lifespan(application: FastAPI) -> AsyncGenerator[None]:
    application.state.log_factory = logger_factory
    yield


app = FastAPI(
    title="Example Events API (Kafka)",
    description="Эндпоинт /events — список сообщений (payload + offset), опционально next_offset.",
    lifespan=lifespan,
)
app.add_middleware(TpMiddleware)


@app.get(
    "/events",
    summary="Список сообщений из Kafka",
    description="Без next_offset — сценарий Б (committed). С next_offset — сценарий А. "
    "Для следующего запроса сценария А: next_offset = offset + 1 из последнего элемента. "
    "500 — ошибка после повторов (Kafka/таймаут и т.д.), в логе trace_id. "
    "timeout — максимум секунд ожидания первого сообщения (по умолчанию 25).",
)
async def events_list(
    request_logger: TpLogger = Depends(get_request_logger),
    next_offset: int | None = Query(
        default=None,
        ge=0,
        description="Offset следующей читаемой записи (сценарий А). Если не задан — сценарий Б.",
    ),
    limit: int | None = Query(
        default=None,
        ge=1,
        le=10_000,
        description="Максимум сообщений в ответе (без ограничения, если не задан).",
    ),
    timeout: float = Query(
        default=25.0,
        ge=1.0,
        le=120.0,
        description="Максимум секунд ожидания чтения из Kafka (таймаут запроса).",
    ),
) -> Response:
    connector = get_kafka_connector()
    async with create_task_app_event_service(
        connector,
        request_logger,
    ) as service:
        try:
            async with service.subscription(
                service_name=TaskAppEvent.TOPIC_SERVICE_NAME,
            ):
                if next_offset is not None:
                    items = await service.read_from_next_offset_ready(
                        next_offset,
                        limit=limit,
                        read_timeout_sec=timeout,
                        assignment_timeout_sec=15.0,
                    )
                else:
                    items = await service.read_from_committed_ready(
                        limit=limit,
                        read_timeout_sec=timeout,
                        assignment_timeout_sec=15.0,
                    )
            body = [
                {
                    "payload": it.message.model_dump(mode="json"),
                    "offset": it.offset,
                }
                for it in items
            ]
            return JSONResponse(content=body)
        except ValueError as e:
            raise HTTPException(status_code=422, detail=str(e)) from e
        except Exception as e:
            request_logger.exception(
                "Чтение событий не удалось (исчерпаны повторы или ошибка): %s", e
            )
            raise EventReadException(trace_id=request_logger.trace_id) from e


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}
