"""Сервис примера FastAPI events: тот же контракт, что ``TaskAppEvent``."""

from __future__ import annotations

from tp_common.kafka.app_event.examples.task_app_event import (
    TaskAppEvent,
    create_task_app_event_service,
)

__all__ = ["TpFastapiEventsExampleService", "create_task_app_event_service"]


class TpFastapiEventsExampleService(TaskAppEvent):
    """Демо-API читает ``TaskAppEventMessage`` из топика ``EVENT_NAMESPACE.<TOPIC_SERVICE_NAME>``."""

    # Экземпляр в примере API — через ``create_task_app_event_service`` (см. ``events/app.py``).
