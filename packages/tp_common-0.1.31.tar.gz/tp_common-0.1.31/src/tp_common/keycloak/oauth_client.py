from __future__ import annotations

import asyncio
import base64
import json
import time
from dataclasses import dataclass
from typing import Any

import aiohttp

from tp_common.base_client.client import BaseClient
from tp_common.keycloak.exceptions import (
    KeycloakInvalidConfiguration,
    KeycloakTokenMissingAccessToken,
    KeycloakTokenResponseInvalid,
)
from tp_common.keycloak.utils import resolve_realm
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger
from tp_common.utils import parse_url_with_auth


@dataclass(frozen=True)
class KeycloakTokenResponse:
    """Ответ Keycloak с access-токеном и опциональным сроком из JWT."""

    access_token: str
    expires_at: int | None = None


def _basic_auth_header(client_id: str, client_secret: str) -> str:
    raw = f"{client_id}:{client_secret}".encode()
    return "Basic " + base64.b64encode(raw).decode("ascii")


def _clean_json_prefix(text: str) -> str:
    """Обрезать префикс до первого «{» в ответе."""
    idx = text.find("{")
    return text[idx:] if idx >= 0 else text


def _parse_json_loose(text: str) -> dict[str, Any]:
    cleaned = _clean_json_prefix(text).strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as exc:
        raise KeycloakTokenResponseInvalid(
            "Keycloak response is not valid JSON"
        ) from exc
    if not isinstance(data, dict):
        raise KeycloakTokenResponseInvalid("Keycloak response is not a JSON object")
    return data


def _jwt_payload_unverified(token: str) -> dict[str, Any] | None:
    """Payload JWT без проверки подписи."""
    try:
        _, payload_b64, _ = token.split(".", 2)
    except ValueError:
        return None
    padded = payload_b64 + "=" * (-len(payload_b64) % 4)
    try:
        payload = json.loads(base64.urlsafe_b64decode(padded))
    except Exception:  # noqa: BLE001
        return None
    return payload if isinstance(payload, dict) else None


def _decode_jwt_exp_unverified(token: str) -> int | None:
    """Читает exp из JWT без проверки подписи."""
    payload = _jwt_payload_unverified(token)
    if not payload:
        return None
    exp = payload.get("exp")
    return int(exp) if isinstance(exp, (int, float)) else None


class KeycloakOAuthClient(BaseClient):
    """HTTP-клиент к Keycloak token endpoint: client_credentials и token exchange."""

    TOKEN_URI_TEMPLATE = "/realms/{realm}/protocol/openid-connect/token"

    def __init__(
        self,
        keycloak_url: str,
        logger: TpLogger,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 5,
        verify_ssl: bool = True,
    ) -> None:
        base_url, client_id, client_secret = parse_url_with_auth(keycloak_url)
        if not client_id or not client_secret:
            raise KeycloakInvalidConfiguration(
                "keycloak_url must include client_id and client_secret, "
                "e.g. https://client_id:client_secret@keycloak.host"
            )
        super().__init__(
            base_url=base_url,
            logger=logger,
            verify_ssl=verify_ssl,
            retry_on_proxy_error=True,
            max_retries=max_retries,
        )
        self._client_id = client_id
        self._client_secret = client_secret
        self._env_type = env_type
        self._service_token_cache: dict[
            tuple[str, str, str], KeycloakTokenResponse
        ] = {}
        self._service_token_lock = asyncio.Lock()

    def clear_service_token(self, *, audience: str) -> None:
        """Сбросить закешированный сервисный токен."""
        realm = resolve_realm(self._env_type)
        cache_key = (realm, self._client_id, audience)
        self._service_token_cache.pop(cache_key, None)

    @staticmethod
    def _parse_token_response(
        data: dict[str, Any],
        *,
        missing_access_token_message: str,
    ) -> KeycloakTokenResponse:
        token = str(data.get("access_token") or "")
        if not token:
            raise KeycloakTokenMissingAccessToken(missing_access_token_message)
        exp = _decode_jwt_exp_unverified(token)
        return KeycloakTokenResponse(access_token=token, expires_at=exp)

    @staticmethod
    def _is_cached_token_valid(
        cached: KeycloakTokenResponse,
        *,
        min_ttl_s: int,
    ) -> bool:
        if cached.expires_at is None:
            return False
        now = int(time.time())
        return cached.expires_at > now + min_ttl_s

    async def get_service_token(
        self,
        audience: str,
        min_ttl_s: int = 30,
    ) -> KeycloakTokenResponse:
        """Вернуть токен для вызова целевого API."""
        realm = resolve_realm(self._env_type)
        cache_key = (realm, self._client_id, audience)

        cached = self._service_token_cache.get(cache_key)
        if cached is not None and self._is_cached_token_valid(
            cached, min_ttl_s=min_ttl_s
        ):
            return cached

        async with self._service_token_lock:
            cached = self._service_token_cache.get(cache_key)
            if cached is not None and self._is_cached_token_valid(
                cached, min_ttl_s=min_ttl_s
            ):
                return cached

            base = await self._get_client_credentials_token()
            final = await self._exchange_token(
                subject_token=base.access_token,
                audience=audience,
            )
            self._service_token_cache[cache_key] = final
            return final

    async def _get_client_credentials_token(self) -> KeycloakTokenResponse:
        """Токен client_credentials без кеширования."""
        client_id = self._client_id
        client_secret = self._client_secret
        realm = resolve_realm(self._env_type)
        uri = self.TOKEN_URI_TEMPLATE.format(realm=realm)
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": _basic_auth_header(client_id, client_secret),
        }
        form = aiohttp.FormData()
        form.add_field("grant_type", "client_credentials")

        resp = await self.post_response(uri, headers=headers, data=form)
        raw_text = resp.text()
        data = _parse_json_loose(raw_text)
        return self._parse_token_response(
            data,
            missing_access_token_message="Keycloak token response has no access_token",
        )

    async def _exchange_token(
        self,
        *,
        subject_token: str,
        audience: str,
    ) -> KeycloakTokenResponse:
        """Token exchange."""
        client_id = self._client_id
        client_secret = self._client_secret
        realm = resolve_realm(self._env_type)
        uri = self.TOKEN_URI_TEMPLATE.format(realm=realm)
        headers = {
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": _basic_auth_header(client_id, client_secret),
        }
        form = aiohttp.FormData()
        form.add_field("grant_type", "urn:ietf:params:oauth:grant-type:token-exchange")
        form.add_field("subject_token", subject_token)
        form.add_field(
            "subject_token_type", "urn:ietf:params:oauth:token-type:access_token"
        )
        form.add_field("audience", audience)

        resp = await self.post_response(uri, headers=headers, data=form)
        raw_text = resp.text()
        data = _parse_json_loose(raw_text)
        return self._parse_token_response(
            data,
            missing_access_token_message="Keycloak exchange response has no access_token",
        )
