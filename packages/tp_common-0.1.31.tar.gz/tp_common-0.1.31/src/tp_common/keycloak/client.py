from __future__ import annotations

from typing import Any, Literal

from tp_common.base_client.client import BaseClient, BodySchema, ClientResponse
from tp_common.base_client.exceptions import ClientAuthorizationException
from tp_common.keycloak.exceptions import KeycloakMissingOAuthDependency
from tp_common.keycloak.oauth_client import KeycloakOAuthClient
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger


class KeycloakClient(BaseClient):
    """
    Базовый HTTP-клиент к API, защищённому Keycloak service token.

    Перед запросом подставляет Bearer; при ответе 401 очищает кеш и повторяет запрос
    один раз. Ответ 403 не повторяется (проблема прав, а не токена).
    """

    def __init__(
        self,
        *,
        base_url: str,
        logger: TpLogger,
        audience: str,
        keycloak_oauth: KeycloakOAuthClient | None = None,
        keycloak_url: str | None = None,
        env_type: EnvironmentType = EnvironmentType.LOCAL,
        max_retries: int = 5,
        token_min_ttl_s: int = 30,
        verify_ssl: bool = True,
    ) -> None:
        super().__init__(
            base_url.rstrip("/"),
            logger,
            None,
            None,
            verify_ssl,
            retry_on_proxy_error=True,
            max_retries=max_retries,
        )
        if keycloak_oauth is not None:
            self._keycloak_oauth = keycloak_oauth
            self._owns_keycloak_oauth = False
        elif keycloak_url is not None:
            self._keycloak_oauth = KeycloakOAuthClient(
                keycloak_url,
                logger,
                env_type=env_type,
                max_retries=max_retries,
                verify_ssl=verify_ssl,
            )
            self._owns_keycloak_oauth = True
        else:
            raise KeycloakMissingOAuthDependency()
        self._audience = audience
        self._token_min_ttl_s = token_min_ttl_s

    async def close(self) -> None:
        await super().close()
        if self._owns_keycloak_oauth:
            await self._keycloak_oauth.close()

    async def _headers_with_bearer(
        self, headers: dict[str, Any] | None
    ) -> dict[str, Any]:
        token_result = await self._keycloak_oauth.get_service_token(
            self._audience,
            min_ttl_s=self._token_min_ttl_s,
        )
        merged: dict[str, Any] = dict(headers or {})
        merged["Authorization"] = f"Bearer {token_result.access_token}"
        return merged

    async def _make_request_response(
        self,
        method: Literal["GET", "POST", "PUT", "DELETE", "PATCH"],
        uri: str,
        headers: dict[str, Any] | None = None,
        params: BodySchema | None = None,
        json: dict[str, Any] | list[Any] | None = None,
        body: BodySchema | None = None,
        data: Any | None = None,
        timeout: float | None = None,
    ) -> ClientResponse:
        hdr = await self._headers_with_bearer(headers)
        try:
            return await super()._make_request_response(
                method=method,
                uri=uri,
                headers=hdr,
                params=params,
                json=json,
                body=body,
                data=data,
                timeout=timeout,
            )
        except ClientAuthorizationException as exc:
            if exc.status_code != 401:
                raise
            self.logger.warning(
                "Ответ 401 от API: сброс токена и повтор запроса один раз",
            )
            self._keycloak_oauth.clear_service_token(audience=self._audience)
            hdr = await self._headers_with_bearer(headers)
            return await super()._make_request_response(
                method=method,
                uri=uri,
                headers=hdr,
                params=params,
                json=json,
                body=body,
                data=data,
                timeout=timeout,
            )
