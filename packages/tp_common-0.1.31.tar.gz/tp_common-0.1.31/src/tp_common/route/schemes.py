from enum import Enum
from typing import TypeVar

from dplex.internal.sort import Order
from pydantic import AliasChoices, BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel

itemsT = TypeVar("itemsT")
messageT = TypeVar("messageT")
SortFieldT = TypeVar("SortFieldT", bound=Enum)


class BaseResponse(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
        validate_by_alias=True,
        serialize_by_alias=True,
    )


class BaseRequest(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        validate_by_name=True,
        validate_by_alias=True,
        serialize_by_alias=True,
        populate_by_name=True,
    )


class BaseQueryResponse[itemsT](BaseResponse):
    items: list[itemsT]
    total: int


class BaseAppEventMessagesResponse[messageT](BaseResponse):
    """Ответ long-poll выдачи app-events: пачка сообщений и смещение для следующего запроса."""

    messages: list[messageT]
    next_offset: int | None = Field(
        default=None,
        description=(
            "Смещение **следующей** записи в партиции (Kafka: позиция, с которой продолжить чтение после "
            "последней отданной в этой пачке). **Задаёт только сервер**; имя в JSON ответа — ``nextOffset``. "
            "Клиент в следующем запросе подставляет то же число в query-параметр ``offset`` (не считает сам по "
            "``messages``). ``null`` — в query ``offset`` не передают; чтение со смещения группы в брокере."
        ),
    )


class BaseAppEventMessagesQueryParams(BaseRequest):
    """Query long-poll выдачи app-events: пара к ``BaseAppEventMessagesResponse`` (смещение из ``nextOffset``)."""

    offset: int | None = Field(
        default=None,
        ge=0,
        validation_alias=AliasChoices("offset", "nextOffset", "next_offset"),
        description=(
            "Позиция продолжения чтения в логе партиции: то же число, что пришло в теле ответа в поле ``nextOffset`` "
            "(см. ``BaseAppEventMessagesResponse.next_offset``). Без параметра — чтение с сохранённого смещения "
            "consumer group в Kafka."
        ),
    )
    limit: int | None = Field(
        default=None,
        ge=1,
        le=10_000,
        description="Максимум сообщений в ответе.",
    )
    timeout: float = Field(
        default=25.0,
        ge=1.0,
        le=120.0,
        description=(
            "Секунды: ожидание назначения партиций и long-poll до первого сообщения в пачке."
        ),
    )


class BaseQueryRequest[SortFieldT: Enum](BaseRequest):
    model_config = ConfigDict(use_enum_values=True)

    limit: int | None = Field(
        default=100,
        ge=1,
        le=300,
        description="Максимальное количество объектов в списке",
    )
    offset: int = Field(default=0, ge=0, description="Смещение от начала списка")
    sort: Order = Field(default=Order.DESC, description="Направление сортировки")

    sort_by: SortFieldT | None = Field(
        default=None,
        description="Поле сортировки (Enum, подставляется в наследнике)",
    )
