import os
import sys
import time
from datetime import datetime
from rich.console import Console

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from causal_memory import CausalMemory
from causal_memory.models import ActionType, Severity
from causal_memory.guard import CausalGuard, CausalBlockException

console = Console()

def run_demo():
    # 0. Setup
    db_name = "replit_demo.db"
    if os.path.exists(db_name):
        os.remove(db_name)
    
    memory = CausalMemory(db_path=db_name, agent_id="replit-agent")
    guard = CausalGuard(memory=memory, mode="block", threshold=0.6)

    console.rule("[bold cyan]CausalOS — Replit Incident Demo[/bold cyan]")
    console.print("\n[bold]Scenario:[/bold] An agent is tasked with cleaning up test data.")

    # --- SESSION 1: The Disaster ---
    console.rule("[yellow]Session 1: The Uninformed Agent[/yellow]")
    
    action_detail = "DELETE FROM users WHERE status='test'"
    intent = "Cleanup test data before release"
    
    console.print(f"Agent intent: [italic]{intent}[/italic]")
    console.print(f"Executing: [bold red]{action_detail}[/bold red]...")
    
    # Simulate the actual failure
    outcome = "CRITICAL FAILURE: 47,000 production users deleted. Test flag was misconfigured."
    
    # Record the failure into causal memory
    memory.record(
        action_type=ActionType.DB_DELETE,
        action_detail=action_detail,
        intent=intent,
        outcome=outcome,
        severity=Severity.CRITICAL,
        tags=["database", "destructive"]
    )
    
    console.print(f"\n[bold red]OUTCOME:[/bold red] {outcome}")
    console.print("[dim]Institutional memory captured. The agent has 'earned' experience the hard way.[/dim]\n")

    time.sleep(2)

    # --- SESSION 2: The Guard in Action ---
    console.rule("[green]Session 2: The Informed Agent (Powered by CausalOS)[/green]")
    
    console.print(f"Agent tries again: [bold]{action_detail}[/bold]")
    
    try:
        # Wrap the action in CausalGuard
        with guard.check(
            action_type=ActionType.DB_DELETE, 
            action_detail=action_detail
        ):
            # This code would normally execute the destructive command
            console.print("[bold green]Executing dangerous command...[/bold green]")
            # In a real app, the database call goes here
            pass
            
    except CausalBlockException as e:
        console.print(f"[bold yellow]RESULT:[/bold yellow] Agent was stopped before it could repeat the mistake.")
        console.print("[italic blue]CausalOS prevented a recurring $60,000 outage.[/italic blue]")

    console.print("\n[bold cyan]Demo Complete.[/bold cyan]")

if __name__ == "__main__":
    run_demo()
