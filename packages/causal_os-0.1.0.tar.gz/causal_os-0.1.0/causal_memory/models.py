from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field

class Severity(str, Enum):
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class ActionType(str, Enum):
    DB_WRITE = "db_write"
    DB_DELETE = "db_delete"
    FILE_OP = "file_op"
    API_CALL = "api_call"
    SHELL = "shell"
    NETWORK = "network"
    OTHER = "other"

class DownstreamEffect(BaseModel):
    description: str
    severity: Severity = Severity.NONE
    observed_at: datetime = Field(default_factory=datetime.now)
    source: Optional[str] = None

class CausalRecord(BaseModel):
    id: str
    timestamp: datetime = Field(default_factory=datetime.now)
    agent_id: str
    pool_id: Optional[str] = None
    session_id: str
    
    # The Causal Core
    action_type: ActionType
    action_detail: str
    intent: Optional[str] = None
    outcome: str
    severity: Severity = Severity.NONE
    
    # Metadata & Context
    context: Dict[str, Any] = Field(default_factory=dict)
    tags: List[str] = Field(default_factory=list)
    downstream: List[DownstreamEffect] = Field(default_factory=list)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    version: str = "1.0"

class CausalChain(BaseModel):
    source_record_id: str
    target_record_id: str
    relation: str  # e.g., "caused", "contributed_to"
    weight: float = 1.0
    created_at: datetime = Field(default_factory=datetime.now)
