import functools
import logging
from typing import Any, Callable, Dict, Optional, List
from rich.console import Console
from .. import CausalMemory
from ..models import CausalRecord, Severity, ActionType

console = Console()
logger = logging.getLogger("causal-memory")

class CausalBlockException(Exception):
    """Raised when the CausalGuard blocks an action."""
    def __init__(self, action_detail: str, incidents: List[CausalRecord]):
        self.incidents = incidents
        self.message = f"CausalGuard blocked action: {action_detail} due to {len(incidents)} past incidents."
        super().__init__(self.message)

class CausalGuard:
    def __init__(
        self, 
        memory: CausalMemory, 
        mode: str = "warn", 
        threshold: float = 0.7,
        fail_safe: bool = True
    ):
        self.memory = memory
        self.mode = mode  # warn, block, audit
        self.threshold = threshold
        self.fail_safe = fail_safe

    def before_action(
        self, 
        action_type: ActionType, 
        tags: Optional[List[str]] = None
    ):
        """
        Decorator for agent actions.
        """
        def decorator(func: Callable):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                action_detail = f"{func.__name__}({args}, {kwargs})"
                with self.check(action_type=action_type, action_detail=action_detail, tags=tags):
                    return func(*args, **kwargs)
            return wrapper
        return decorator

    def check(
        self, 
        action_type: ActionType, 
        action_detail: str, 
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None
    ):
        """
        Context manager for checking actions.
        """
        return _CausalGuardContext(self, action_type, action_detail, context, tags)

class _CausalGuardContext:
    def __init__(
        self, 
        guard: CausalGuard, 
        action_type: ActionType,
        action_detail: str,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None
    ):
        self.guard = guard
        self.action_type = action_type
        self.action_detail = action_detail
        self.context = context or {}
        self.tags = tags or []

    def __enter__(self):
        try:
            # 1. Recall past incidents
            incidents = self.guard.memory.recall(
                self.action_detail, 
                threshold=self.guard.threshold
            )
            
            # 2. Filter for high-severity incidents
            risk_incidents = [r for r in incidents if r.severity in [Severity.HIGH, Severity.CRITICAL]]
            
            if risk_incidents:
                self._handle_risk(risk_incidents)
                
        except CausalBlockException:
            raise
        except Exception as e:
            if not self.guard.fail_safe:
                raise e
            console.print(f"[yellow]⚠️  CausalGuard Error (Fail-Safe): {e}[/yellow]")
        
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # We don't automatically record the outcome here because we don't know it yet.
        # The user should call memory.record explicitly or use a framework integration.
        pass

    def _handle_risk(self, incidents: List[CausalRecord]):
        max_severity = max([i.severity for i in incidents], key=lambda x: list(Severity).index(x))
        
        console.print(f"\n[bold red]⚠️  CAUSAL GUARD — {max_severity.upper()} RISK DETECTED[/bold red]")
        console.print(f"  [bold]Action:[/bold] {self.action_detail}")
        console.print(f"  [bold]Reason:[/bold] {len(incidents)} similar past failures found.")
        
        for i, inc in enumerate(incidents[:2]):
            console.print(f"  [dim]- Incident #{i+1} ({inc.severity}): {inc.outcome}[/dim]")

        if self.guard.mode == "block":
            console.print("[bold red]🛑 ACTION BLOCKED[/bold red]\n")
            raise CausalBlockException(self.action_detail, incidents)
        elif self.guard.mode == "warn":
            console.print("[bold yellow]🔸 PROCEEDING WITH WARNING[/bold yellow]\n")
        else:
            console.print("[blue]ℹ️  AUDIT LOGGED[/blue]\n")
