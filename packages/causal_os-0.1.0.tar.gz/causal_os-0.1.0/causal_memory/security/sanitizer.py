from typing import Any, Dict, List, Union

SENSITIVE_KEYWORDS = {
    "api_key", "secret", "token", "password", "key", 
    "authorization", "credential", "auth", "access_key",
    "private_key", "pwd", "bearer"
}

class CausalSanitizer:
    @staticmethod
    def sanitize(data: Any) -> Any:
        """
        Recursively scrubs sensitive keys from dictionaries and nested lists.
        """
        if isinstance(data, dict):
            new_dict = {}
            for k, v in data.items():
                if any(kw in k.lower() for kw in SENSITIVE_KEYWORDS):
                    new_dict[k] = "[REDACTED]"
                else:
                    new_dict[k] = CausalSanitizer.sanitize(v)
            return new_dict
        elif isinstance(data, list):
            return [CausalSanitizer.sanitize(item) for item in data]
        else:
            return data
