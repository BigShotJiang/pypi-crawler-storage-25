try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.messages import BaseMessage
    from langchain_core.outputs import LLMResult
except ImportError:
    raise ImportError(
        "Could not import langchain-core. Please install it with "
        "`pip install causal-os[langchain]` to use this integration."
    )

from typing import Any, Dict, List, Optional
from ... import CausalMemory
from ...models import ActionType, Severity

class CausalMemoryCallback(BaseCallbackHandler):
    """
    LangChain callback handler that records LLM tool calls and outcomes 
    into CausalMemory.
    """
    def __init__(self, memory: CausalMemory):
        self.memory = memory
        self._current_run_id: Optional[str] = None

    def on_llm_start(
        self, serialized: Dict[str, Any], prompts: List[str], **kwargs: Any
    ) -> Any:
        # Pre-action recall logic could go here if we wanted to block the LLM 
        # before it even generates, but typically we guard tool execution.
        pass

    def on_tool_start(
        self, serialized: Dict[str, Any], input_str: str, **kwargs: Any
    ) -> Any:
        # Before a tool runs, we could check the guard here
        # For simplicity in v1, we focus on recording the outcome
        pass

    def on_tool_end(self, output: str, **kwargs: Any) -> Any:
        # After tool execution, record the result
        self.memory.record(
            action_type=ActionType.API_CALL,
            action_detail=kwargs.get("name", "unknown_tool"),
            outcome=output,
            severity=Severity.NONE, # Default to None, user can update later
            tags=["langchain", "tool_call"]
        )

    def on_llm_error(self, error: Exception, **kwargs: Any) -> Any:
        self.memory.record(
            action_type=ActionType.OTHER,
            action_detail="llm_generation",
            outcome=f"LLM Error: {str(error)}",
            severity=Severity.HIGH,
            tags=["error", "llm"]
        )
