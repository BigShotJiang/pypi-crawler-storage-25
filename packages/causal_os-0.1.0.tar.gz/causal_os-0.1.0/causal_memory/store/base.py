from abc import ABC, abstractmethod
from typing import List, Optional
from ..models import CausalRecord, CausalChain

class BaseStore(ABC):
    @abstractmethod
    def save_record(self, record: CausalRecord) -> None:
        """Persist a new causal record."""
        pass

    @abstractmethod
    def get_record(self, record_id: str) -> Optional[CausalRecord]:
        """Retrieve a record by its unique ID."""
        pass

    @abstractmethod
    def search_records(self, agent_id: Optional[str] = None, pool_id: Optional[str] = None, limit: int = 100) -> List[CausalRecord]:
        """List records with optional filtering."""
        pass

    @abstractmethod
    def add_chain(self, chain_id: str, source_id: str, target_id: str, relation: str) -> None:
        """Connect two records in the causal graph."""
        pass

    @abstractmethod
    def save_downstream(self, record_id: str, description: str, severity: str) -> None:
        """Append a downstream effect to an existing record."""
        pass
