import sqlite3
import json
from typing import List, Optional, Dict, Any
from datetime import datetime
from .base import BaseStore
from ..models import CausalRecord, CausalChain, DownstreamEffect, Severity, ActionType

class SQLiteStore(BaseStore):
    def __init__(self, db_path: str = "causal.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("""
                CREATE TABLE IF NOT EXISTS records (
                    id TEXT PRIMARY KEY,
                    timestamp TEXT,
                    agent_id TEXT,
                    pool_id TEXT,
                    session_id TEXT,
                    action_type TEXT,
                    action_detail TEXT,
                    intent TEXT,
                    outcome TEXT,
                    severity TEXT,
                    context TEXT,
                    tags TEXT,
                    downstream TEXT,
                    metadata TEXT,
                    version TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS edges (
                    id TEXT PRIMARY KEY,
                    source_id TEXT,
                    target_id TEXT,
                    relation TEXT,
                    weight REAL,
                    created_at TEXT,
                    FOREIGN KEY(source_id) REFERENCES records(id),
                    FOREIGN KEY(target_id) REFERENCES records(id)
                )
            """)
            conn.commit()

    def save_record(self, record: CausalRecord) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO records (
                    id, timestamp, agent_id, pool_id, session_id,
                    action_type, action_detail, intent, outcome, severity,
                    context, tags, downstream, metadata, version
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                record.id,
                record.timestamp.isoformat(),
                record.agent_id,
                record.pool_id,
                record.session_id,
                record.action_type.value,
                record.action_detail,
                record.intent,
                record.outcome,
                record.severity.value,
                json.dumps(record.context),
                json.dumps(record.tags),
                json.dumps([de.model_dump() for de in record.downstream]),
                json.dumps(record.metadata),
                record.version
            ))
            conn.commit()

    def get_record(self, record_id: str) -> Optional[CausalRecord]:
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute("SELECT * FROM records WHERE id = ?", (record_id,)).fetchone()
            if row:
                return self._row_to_record(row)
        return None

    def search_records(self, agent_id: Optional[str] = None, pool_id: Optional[str] = None, limit: int = 100) -> List[CausalRecord]:
        query = "SELECT * FROM records"
        params = []
        where_clauses = []
        if agent_id:
            where_clauses.append("agent_id = ?")
            params.append(agent_id)
        if pool_id:
            where_clauses.append("pool_id = ?")
            params.append(pool_id)
        
        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)
        
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)
        
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(query, tuple(params)).fetchall()
            return [self._row_to_record(row) for row in rows]

    def add_chain(self, chain_id: str, source_id: str, target_id: str, relation: str) -> None:
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO edges (id, source_id, target_id, relation, weight, created_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (chain_id, source_id, target_id, relation, 1.0, datetime.now().isoformat()))
            conn.commit()

    def save_downstream(self, record_id: str, description: str, severity: str) -> None:
        record = self.get_record(record_id)
        if not record:
            return
        
        effect = DownstreamEffect(
            description=description,
            severity=Severity(severity),
            observed_at=datetime.now()
        )
        record.downstream.append(effect)
        self.save_record(record)

    def _row_to_record(self, row: sqlite3.Row) -> CausalRecord:
        return CausalRecord(
            id=row['id'],
            timestamp=datetime.fromisoformat(row['timestamp']),
            agent_id=row['agent_id'],
            pool_id=row['pool_id'],
            session_id=row['session_id'],
            action_type=ActionType(row['action_type']),
            action_detail=row['action_detail'],
            intent=row['intent'],
            outcome=row['outcome'],
            severity=Severity(row['severity']),
            context=json.loads(row['context']),
            tags=json.loads(row['tags']),
            downstream=[DownstreamEffect(**de) for de in json.loads(row['downstream'])],
            metadata=json.loads(row['metadata']),
            version=row['version']
        )
