import os
import socket
import sys
import uuid
import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
from .models import CausalRecord, ActionType, Severity, DownstreamEffect
from .store.sqlite import SQLiteStore
from .vector.engine import VectorEngine
from .security.sanitizer import CausalSanitizer

logger = logging.getLogger("causal-memory")

class CausalMemory:
    def __init__(
        self, 
        db_path: str = "causal.db", 
        agent_id: Optional[str] = None,
        pool_id: Optional[str] = None,
        shared: bool = False,
        fail_safe: bool = True
    ):
        self.store = SQLiteStore(db_path)
        self.vector_engine = VectorEngine()
        self.agent_id = agent_id or self._generate_default_agent_id()
        self.pool_id = pool_id
        self.shared = shared
        self.fail_safe = fail_safe
        self.session_id = str(uuid.uuid4())

    def _generate_default_agent_id(self) -> str:
        try:
            hostname = socket.gethostname()
            script_name = os.path.basename(sys.argv[0])
            return f"{hostname}:{script_name}"
        except Exception:
            return "unknown-agent"

    def record(
        self,
        action_type: ActionType,
        action_detail: str,
        outcome: str,
        intent: Optional[str] = None,
        severity: Severity = Severity.NONE,
        context: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> CausalRecord:
        try:
            # Sanitize context before creating record
            clean_context = CausalSanitizer.sanitize(context or {})
            
            record = CausalRecord(
                id=str(uuid.uuid4()),
                agent_id=self.agent_id,
                pool_id=self.pool_id,
                session_id=self.session_id,
                action_type=action_type,
                action_detail=action_detail,
                intent=intent,
                outcome=outcome,
                severity=severity,
                context=clean_context,
                tags=tags or [],
                metadata=metadata or {}
            )
            self.store.save_record(record)
            return record
        except Exception as e:
            if self.fail_safe:
                logger.warning(f"⚠️ CausalMemory failed to record: {e}")
                return None # Return empty or mock? PRD says do not block.
            raise e

    def recall(
        self,
        action_detail: str,
        top_k: int = 5,
        threshold: float = 0.6
    ) -> List[CausalRecord]:
        try:
            # 1. Fetch relevant pool/agent records
            records = self.store.search_records(
                agent_id=None if self.shared else self.agent_id,
                pool_id=self.pool_id,
                limit=1000
            )
            
            if not records:
                return []

            # 2. Compute similarity
            query_vec = self.vector_engine.embed(action_detail)
            scored_records = []
            
            for rec in records:
                rec_vec = self.vector_engine.embed(rec.action_detail)
                score = self.vector_engine.similarity(query_vec, rec_vec)
                if score >= threshold:
                    scored_records.append((score, rec))
            
            # 3. Sort and return
            scored_records.sort(key=lambda x: x[0], reverse=True)
            return [rec for score, rec in scored_records[:top_k]]

        except Exception as e:
            if self.fail_safe:
                logger.warning(f"⚠️ CausalMemory failed to recall: {e}")
                return []
            raise e

    def append_downstream(self, record_id: str, description: str, severity: Severity) -> None:
        try:
            self.store.save_downstream(record_id, description, severity.value)
        except Exception as e:
            if self.fail_safe:
                logger.warning(f"⚠️ CausalMemory failed to append downstream: {e}")
            else:
                raise e
