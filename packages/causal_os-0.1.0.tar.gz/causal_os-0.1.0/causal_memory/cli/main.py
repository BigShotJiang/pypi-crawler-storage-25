import argparse
import sys
from rich.console import Console
from rich.table import Table
from rich.tree import Tree
from .. import CausalMemory
from ..models import Severity

console = Console()

def main():
    parser = argparse.ArgumentParser(description="CausalOS CLI — Audit and inspect agent causal memory.")
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Command: recall
    recall_parser = subparsers.add_parser("recall", help="Recall past incidents for a query.")
    recall_parser.add_argument("query", type=str, help="The action description to recall.")
    recall_parser.add_argument("--db", type=str, default="causal.db", help="Path to causal database.")

    # Command: view
    view_parser = subparsers.add_parser("view", help="View the causal graph as a tree.")
    view_parser.add_argument("--db", type=str, default="causal.db", help="Path to causal database.")
    view_parser.add_argument("--agent", type=str, help="Filter by agent_id.")

    args = parser.parse_args()

    if args.command == "recall":
        do_recall(args)
    elif args.command == "view":
        do_view(args)
    else:
        parser.print_help()

def do_recall(args):
    memory = CausalMemory(db_path=args.db)
    console.print(f"Searching for incidents similar to: [bold cyan]'{args.query}'[/bold cyan]...")
    
    incidents = memory.recall(args.query, top_k=5)
    
    if not incidents:
        console.print("[yellow]No similar incidents found.[/yellow]")
        return

    table = Table(title="Relevant Causal Records")
    table.add_column("Severity", justify="right")
    table.add_column("Action", style="cyan")
    table.add_column("Outcome", style="magenta")
    table.add_column("Timestamp", style="dim")

    for inc in incidents:
        color = "white"
        if inc.severity == Severity.CRITICAL: color = "bold red"
        elif inc.severity == Severity.HIGH: color = "red"
        elif inc.severity == Severity.MEDIUM: color = "yellow"

        table.add_row(
            f"[{color}]{inc.severity.upper()}[/{color}]",
            inc.action_detail,
            inc.outcome,
            inc.timestamp.strftime("%Y-%m-%d %H:%M")
        )

    console.print(table)

def do_view(args):
    memory = CausalMemory(db_path=args.db)
    records = memory.store.search_records(agent_id=args.agent, limit=100)
    
    if not records:
        console.print("No records found in database.")
        return

    tree = Tree(f"🌲 [bold]Causal Graph[/bold] ({args.db})")
    
    # Simple grouping by session for the V1 view
    sessions = {}
    for r in records:
        if r.session_id not in sessions:
            sessions[r.session_id] = []
        sessions[r.session_id].append(r)

    for session_id, session_records in sessions.items():
        sess_node = tree.add(f"📁 [dim]Session: {session_id[:8]}[/dim]")
        for r in session_records:
            color = "white"
            if r.severity == Severity.CRITICAL: color = "red"
            
            node = sess_node.add(f"[{color}]{r.action_type.value.upper()}[/{color}]: {r.action_detail}")
            node.add(f"[italic dim]→ {r.outcome}[/italic dim]")
            
            for de in r.downstream:
                node.add(f"[bold yellow]↳ Downstream:[/bold yellow] {de.description} ([dim]{de.severity}[/dim])")

    console.print(tree)

if __name__ == "__main__":
    main()
