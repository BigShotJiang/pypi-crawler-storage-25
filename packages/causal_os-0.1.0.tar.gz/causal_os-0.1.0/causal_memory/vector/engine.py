import os
import shutil
import numpy as np
import onnxruntime as ort
import urllib.request
from pathlib import Path
from typing import List, Optional
from rich.progress import Progress, DownloadColumn, TextColumn, TransferSpeedColumn, TimeRemainingColumn

MODEL_URL = "https://huggingface.co/sentence-transformers/all-MiniLM-L6-v2/resolve/main/onnx/model.onnx"
DEFAULT_MODEL_DIR = Path.home() / ".causal_memory" / "models"

class VectorEngine:
    def __init__(self, model_path: Optional[str] = None):
        self.model_path = Path(model_path or os.getenv("CAUSAL_MEMORY_MODEL_PATH") or (DEFAULT_MODEL_DIR / "model.onnx"))
        self.session = None
        self._ensure_model_exists()
        self._load_session()

    def _ensure_model_exists(self):
        if self.model_path.exists():
            return

        self.model_path.parent.mkdir(parents=True, exist_ok=True)
        print(f"📥 Downloading causal embedding model to {self.model_path}...")
        
        with Progress(
            TextColumn("[progress.description]{task.description}"),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
        ) as progress:
            task = progress.add_task("Downloading model", total=None)
            
            def report_progress(block_num, block_size, total_size):
                if progress.tasks[task].total is None and total_size > 0:
                    progress.update(task, total=total_size)
                progress.update(task, completed=block_num * block_size)

            urllib.request.urlretrieve(MODEL_URL, self.model_path, reporthook=report_progress)
        
        print("✅ Download complete.")

    def _load_session(self):
        # We need the tokenizer too for a real implementation, 
        # but for a simplified v1 (just text -> vec) we'll assume basic tokenization 
        # or use a pre-processed approach if possible.
        # Actually, for sentence-transformers, we need the ONNX model AND the vocabulary.
        # Let's pivot slightly to use a lightweight ONNX wrapper if available or implement basic tokenization.
        self.session = ort.InferenceSession(str(self.model_path))

    def embed(self, text: str) -> np.ndarray:
        # Mocking the actual embedding logic for now as onnx-only tokenization is complex
        # In a real implementation, we'd bundle a basic tokenizer or use a 1-file implementation
        # For this draft, we'll return a deterministic random vector based on hash for testing retrieval
        # until the real tokenizer is integrated in Phase 2.
        state = np.random.RandomState(abs(hash(text)) % (2**32))
        return state.randn(384).astype(np.float32)

    def similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        if norm1 == 0 or norm2 == 0:
            return 0.0
        return float(np.dot(vec1, vec2) / (norm1 * norm2))
