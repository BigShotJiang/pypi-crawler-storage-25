"""Tests for certisigma.hash utilities."""
import hashlib
import os
import tempfile

import pytest

from certisigma.hash import hash_file, hash_bytes, hash_string


class TestHashBytes:
    def test_empty(self):
        expected = hashlib.sha256(b"").hexdigest()
        assert hash_bytes(b"") == expected

    def test_known_value(self):
        data = b"hello world"
        expected = hashlib.sha256(data).hexdigest()
        assert hash_bytes(data) == expected

    def test_bytearray(self):
        data = bytearray(b"test data")
        expected = hashlib.sha256(data).hexdigest()
        assert hash_bytes(data) == expected

    def test_memoryview(self):
        data = b"memoryview test"
        expected = hashlib.sha256(data).hexdigest()
        assert hash_bytes(memoryview(data)) == expected

    def test_returns_64_hex(self):
        result = hash_bytes(b"anything")
        assert len(result) == 64
        assert all(c in "0123456789abcdef" for c in result)

    def test_rejects_string(self):
        with pytest.raises(TypeError, match="Expected bytes-like"):
            hash_bytes("not bytes")  # type: ignore

    def test_rejects_int(self):
        with pytest.raises(TypeError, match="Expected bytes-like"):
            hash_bytes(42)  # type: ignore


class TestHashFile:
    def test_small_file(self, tmp_path):
        f = tmp_path / "test.txt"
        content = b"hello file"
        f.write_bytes(content)
        expected = hashlib.sha256(content).hexdigest()
        assert hash_file(str(f)) == expected

    def test_path_object(self, tmp_path):
        f = tmp_path / "test.bin"
        content = os.urandom(256)
        f.write_bytes(content)
        expected = hashlib.sha256(content).hexdigest()
        assert hash_file(f) == expected

    def test_large_file_chunked(self, tmp_path):
        f = tmp_path / "large.bin"
        content = os.urandom(100_000)
        f.write_bytes(content)
        expected = hashlib.sha256(content).hexdigest()
        assert hash_file(str(f)) == expected

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty"
        f.write_bytes(b"")
        expected = hashlib.sha256(b"").hexdigest()
        assert hash_file(str(f)) == expected

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            hash_file("/nonexistent/path/file.txt")

    def test_directory_raises(self, tmp_path):
        with pytest.raises(IsADirectoryError):
            hash_file(str(tmp_path))


class TestHashString:
    """Tests for hash_string() — UTF-8 string hashing."""

    CROSS_SDK_VECTOR = "SN-2026-001234"
    CROSS_SDK_EXPECTED = hashlib.sha256(b"SN-2026-001234").hexdigest()

    def test_known_vector(self):
        assert hash_string(self.CROSS_SDK_VECTOR) == self.CROSS_SDK_EXPECTED

    def test_empty_string(self):
        expected = hashlib.sha256(b"").hexdigest()
        assert hash_string("") == expected

    def test_equals_hash_bytes_utf8(self):
        text = "hello world"
        assert hash_string(text) == hash_bytes(text.encode("utf-8"))

    def test_unicode(self):
        text = "Zurigo \u2014 \u00e4\u00f6\u00fc"
        expected = hashlib.sha256(text.encode("utf-8")).hexdigest()
        assert hash_string(text) == expected

    def test_emoji(self):
        text = "\U0001f512\U0001f511"
        expected = hashlib.sha256(text.encode("utf-8")).hexdigest()
        assert hash_string(text) == expected

    def test_no_trailing_newline(self):
        assert hash_string("SN-001") != hash_string("SN-001\n")

    def test_returns_64_hex(self):
        result = hash_string("anything")
        assert len(result) == 64
        assert all(c in "0123456789abcdef" for c in result)

    def test_deterministic(self):
        assert hash_string("test") == hash_string("test")

    def test_rejects_bytes(self):
        with pytest.raises(TypeError, match="Expected str"):
            hash_string(b"not a string")  # type: ignore

    def test_rejects_int(self):
        with pytest.raises(TypeError, match="Expected str"):
            hash_string(42)  # type: ignore

    def test_rejects_none(self):
        with pytest.raises(TypeError, match="Expected str"):
            hash_string(None)  # type: ignore
