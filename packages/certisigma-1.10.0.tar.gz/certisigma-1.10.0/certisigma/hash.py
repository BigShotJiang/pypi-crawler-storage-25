"""
CertiSigma SDK — SHA-256 hashing utilities.

Standalone functions for computing SHA-256 hashes in the format expected
by the CertiSigma attestation API (64-char lowercase hex).

Usage:
    from certisigma import hash_file, hash_bytes, hash_string

    file_hash = hash_file("/path/to/document.pdf")
    data_hash = hash_bytes(b"raw content")
    str_hash  = hash_string("SN-2026-001234")

    # Then attest or verify
    client.attest(file_hash)
    client.verify(data_hash)
    client.attest_string("SN-2026-001234")
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Union

CHUNK_SIZE = 8192


def hash_file(path: Union[str, Path]) -> str:
    """
    Compute the SHA-256 hash of a file.

    Reads the file in 8 KiB chunks for constant memory usage regardless of
    file size.

    Args:
        path: Filesystem path to the file.

    Returns:
        64-character lowercase hex string (SHA-256 digest).

    Raises:
        FileNotFoundError: If the file does not exist.
        IsADirectoryError: If the path is a directory.
    """
    sha = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
            sha.update(chunk)
    return sha.hexdigest()


def hash_bytes(data: Union[bytes, bytearray, memoryview]) -> str:
    """
    Compute the SHA-256 hash of raw bytes.

    Args:
        data: Bytes-like object to hash.

    Returns:
        64-character lowercase hex string (SHA-256 digest).

    Raises:
        TypeError: If data is not a bytes-like object.
    """
    if not isinstance(data, (bytes, bytearray, memoryview)):
        raise TypeError(f"Expected bytes-like object, got {type(data).__name__}")
    return hashlib.sha256(data).hexdigest()


def hash_string(text: str) -> str:
    """
    Compute the SHA-256 hash of a UTF-8 encoded string.

    Canonical form: the string is encoded as UTF-8 with no BOM, no trailing
    newline, and no normalization. The caller is responsible for any
    preprocessing (trimming, case folding, etc.) before calling this function.

    This is the recommended way to attest identifiers, serial numbers, or any
    non-file content without creating temporary files.

    .. warning::
        SHA-256 of short, predictable strings (e.g. serial numbers with known
        patterns) can be reversed via brute-force. The hash protects integrity,
        not confidentiality. If confidentiality is needed, concatenate a secret
        salt before hashing or use client-side encryption for metadata.

    Args:
        text: The string to hash.

    Returns:
        64-character lowercase hex string (SHA-256 digest).

    Raises:
        TypeError: If text is not a str.

    Examples:
        >>> hash_string("SN-2026-001234")
        'b9c37...'
        >>> hash_string("SN-2026-001234") == hash_bytes(b"SN-2026-001234")
        True
    """
    if not isinstance(text, str):
        raise TypeError(f"Expected str, got {type(text).__name__}")
    return hashlib.sha256(text.encode("utf-8")).hexdigest()
