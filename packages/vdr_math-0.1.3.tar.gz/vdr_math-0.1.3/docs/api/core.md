# vdr.core

::: vdr.core
