# vdr.linalg

::: vdr.linalg
