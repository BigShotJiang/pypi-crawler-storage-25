ADD = "add"
DIVIDE = "divide"
