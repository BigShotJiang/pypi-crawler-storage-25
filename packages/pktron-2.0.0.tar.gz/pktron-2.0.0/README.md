# PKTron AI Quantum Lab

### AI-Powered Quantum Simulation for Every Scientist — From Circuits to Cosmology in One Interactive Lab, Pakistan's 1st Quantum AI Powered Simulation Framework.

**PKTron AI Quantum Lab** is a comprehensive, AI-assisted quantum computing platform
built entirely in Python. Whether you are a student, researcher, or engineer, PKTron
gives you everything you need to build, simulate, analyse, and understand quantum
systems — no real quantum hardware required.

From simple 2-qubit circuits to 100 Qubit fault-tolerant surface codes, quantum finance models,
molecular chemistry simulations, and an AI assistant that explains every step —
PKTron is the one platform that covers it all.

---

## Install
```
pip install pktron
```

## Optional Extras
```
pip install pktron[gpu]   # GPU acceleration via CuPy
pip install pktron[ml]    # Quantum ML via PyTorch
pip install pktron[full]  # Everything
```

---

## Quick Start
```python
from pktron import QuantumCircuit

qc = QuantumCircuit(2)
qc.h(0)
qc.cnot(0, 1)
print(qc.get_state())
```

---

## Why PKTron AI Quantum Lab?

| Feature | PKTron |
|---|---|
| AI Quantum Assistant | Yes — explains circuits step by step |
| Fault-Tolerant Codes | Repetition, Steane, Surface Code |
| Quantum Finance | Portfolio, Risk, Fraud, QKD |
| Scientific Domains | Physics, Chemistry, Biology, Cosmology |
| Noise + Mitigation | ZNE, PEC, REM fully integrated |
| Algorithms | 15+ including Shor, HHL, Grover, VQE |
| Memory Safe | Runs on free Google Colab (12 GB) |
| GPU Support | Optional via CuPy |

---

## What PKTron AI Quantum Lab Can Do

### AI-Powered Features
- AI Quantum Assistant — explains what every gate and circuit does in plain English
- Step-by-step simulation engine — watch your circuit execute one gate at a time
- Quantum Debugger — find and fix errors in your circuits interactively
- Auto Backend Optimiser — automatically picks the best simulator for your circuit

### Core Simulation
- Statevector simulator (memory-safe, up to 22 qubits on standard hardware)
- Density matrix simulator with full Kraus noise support
- MPS tensor network simulator with adaptive bond dimensions
- Fast statevector engine with sparse zero-skipping
- GPU acceleration via CuPy (optional)

### Noise and Error Handling
- Depolarising, bit-flip, phase-flip, and readout noise models
- Zero-Noise Extrapolation (ZNE) error mitigation
- Probabilistic Error Cancellation (PEC)
- Readout Error Mitigation (REM)

### Fault-Tolerant Quantum Computing
- Repetition Code
- Steane [[7,1,3]] Code
- Surface Code with full syndrome measurement and correction
- Logical qubit wrapper

### Quantum Algorithms (15+)
- VQE — Variational Quantum Eigensolver
- QAOA — Quantum Approximate Optimisation
- Grover's search algorithm
- Shor's factoring algorithm (full implementation)
- HHL quantum linear system solver
- Deutsch-Jozsa algorithm
- Bernstein-Vazirani algorithm
- Simon's algorithm
- Quantum Counting
- Quantum Walks (discrete and continuous-time)
- Quantum Principal Component Analysis (qPCA)
- Quantum GAN (QGAN)
- Quantum SVM (QSVM)
- Quantum Neural Networks (QNN)
- Advanced Algorithms Extension Module

### Quantum Finance
- VQE portfolio optimisation
- Quantum Monte Carlo risk analysis
- VQC fraud detection
- Grover anomaly search
- BB84 Quantum Key Distribution (QKD)
- Unified QuantumFinance API

### Scientific Domains
- Physics: quantum harmonic oscillator, spin chains, Ising model
- Chemistry: molecular VQE, bond dissociation, quantum phase estimation
- Biology: protein folding optimisation, DNA sequence alignment
- Cosmology: dark matter simulation, cosmic inflation modelling
- Scientific Algorithms: quantum annealing, adiabatic evolution

### Autonomous Quantum Experimentation (AQEF)
- Adaptive Quantum Execution Engine with feedback loop
- Noise Intelligence Module — detects error-heavy qubits automatically
- Experiment Manager with full logging and history
- Backend Abstraction Layer
- Quantum Strategy Engine
- Real-time visualisation dashboard
- GHZ Scaling Engine
- Reproducibility and snapshot system

### Developer Tools
- Circuit transpiler with full PassManager
- Performance profiler
- Circuit animation engine
- Hardware emulator
- Qiskit compatibility layer
- Plugin system
- Quantum Cryptography Suite

---

## Example: AI Assistant Explaining a Circuit
```python
from pktron import QuantumCircuit, AIQuantumAssistant

qc = QuantumCircuit(2)
qc.h(0)
qc.cnot(0, 1)

ai = AIQuantumAssistant()
ai.explain(qc)
# Output:
# Step 1: H gate on qubit 0 — puts qubit into superposition (50% |0>, 50% |1>)
# Step 2: CNOT gate — entangles qubit 0 and qubit 1, creating a Bell state
# Final state: (|00> + |11>) / sqrt(2)
```

---

## Example: VQE for H2 Molecule
```python
from pktron import QuantumCircuit
from pktron.quantum_info_v2 import Pauli, Statevector
import numpy as np

def ansatz(thetas):
    qc = QuantumCircuit(2)
    qc.ry(thetas[0], 0)
    qc.ry(thetas[1], 1)
    qc.cnot(0, 1)
    return qc

thetas = np.array([0.1, 0.2])
sv = Statevector(ansatz(thetas).get_state())
energy = float(np.real(Pauli('ZZ').expectation_value(sv)))
print(f"H2 Ground State Energy: {energy:.4f}")
```

---

## Example: Surface Code Error Correction
```python
from pktron.fault_tolerant import SurfaceCode

sc = SurfaceCode(distance=3)
state = sc.encode_logical_zero()
state = sc.add_error(state, error_qubit=2, error_type='X')
syndrome = sc.measure_syndrome(state)
print(f"Syndrome detected: {syndrome}")
```

---

## Example: Quantum Finance
```python
from pktron.finance import QuantumFinance

qf = QuantumFinance()
portfolio = qf.optimise_portfolio(returns=[0.1, 0.2, 0.15], risk=0.05)
print(portfolio)
```

---

## Example: Quantum Cosmology
```python
from pktron.cosmology import CosmologySimulator

sim = CosmologySimulator()
result = sim.dark_matter_simulation(n_qubits=4, steps=10)
print(result.summary())
```

---

## License

MIT License — free to use, modify, and distribute.

---

*PKTron AI Quantum Lab — Making quantum computing accessible to every scientist,
student, and researcher on the planet.*
