
from .api import AdvancedQuantum
from .grover             import grover_search, build_oracle, amplitude_amplification
from .qaoa               import run_qaoa, build_qaoa_circuit, optimize_qaoa
from .vqe                import run_vqe, run_adapt_vqe, run_sampling_vqe
from .qpe                import qpe, iterative_qpe, hamiltonian_qpe
from .amplitude_estimation import (amplitude_estimation,
                                    iterative_amplitude_estimation,
                                    mle_amplitude_estimation)
from .time_evolution     import trotter_evolution, varqrte, varqite
from .qml                import build_qnn, train_qnn, quantum_kernel, quantum_kernel_matrix
from .qft                import qft, inverse_qft
from .state_prep         import basis_encoding, amplitude_encoding, angle_encoding
from .variational        import (parameter_shift_gradient,
                                  optimize_parameters, variational_loop)

# ── Phase 7 Extensions ───────────────────────────────────────────────────────
try:
    from .hi_vqe import (run_he_vqe, run_hi_vqe, run_spsa_vqe,
                          run_adapt_vqe_plus, spsa_optimize)
except Exception as _e:
    print(f"[PKTron] hi_vqe not loaded: {_e}")

try:
    from .hamil_sim import (suzuki_trotter2, qdrift,
                             qubitization_walk_eigenphases,
                             landau_zener_dynamics, tully_surface_hopping)
except Exception as _e:
    print(f"[PKTron] hamil_sim not loaded: {_e}")

try:
    from .block_encoding import (block_encode_dense, fable_block_encode,
                                  lcu_block_encode, qsvt_apply,
                                  pauli_decompose)
except Exception as _e:
    print(f"[PKTron] block_encoding not loaded: {_e}")

try:
    from .enhanced_qpe import (textbook_qpe, iterative_qpe,
                                hadamard_test_qpe, robust_qpe,
                                scaled_qpe_large,
                                HamiltonianPhaseEstimation)
except Exception as _e:
    print(f"[PKTron] enhanced_qpe not loaded: {_e}")
