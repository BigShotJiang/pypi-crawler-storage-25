
"""PKTron Physics — Thermodynamics"""
import numpy as np
_R = np.float32

R_GAS = _R(8.314)   # J/(mol K)
k_B   = _R(1.380649e-23)

def celsius_to_kelvin(C): return _R(C)+_R(273.15)
def kelvin_to_celsius(K): return _R(K)-_R(273.15)
def fahrenheit_to_celsius(F): return (_R(F)-_R(32))*_R(5)/_R(9)

def ideal_gas_pressure(n, T, V):
    """PV = nRT  -> P"""
    return _R(n)*R_GAS*_R(T)/_R(V)

def ideal_gas_volume(n, T, P):
    return _R(n)*R_GAS*_R(T)/_R(P)

def heat_capacity(Q, m, delta_T):
    """c = Q / (m * dT)"""
    return _R(Q)/(_R(m)*_R(delta_T))

def heat_transfer(m, c, delta_T):
    """Q = m * c * dT"""
    return _R(m)*_R(c)*_R(delta_T)

def thermal_efficiency(T_hot, T_cold):
    """Carnot efficiency eta = 1 - T_cold/T_hot"""
    return float(1 - _R(T_cold)/_R(T_hot))

def entropy_change(Q, T):
    """dS = Q / T"""
    return _R(Q)/_R(T)

def boltzmann_energy(T, dof=3):
    """Average thermal energy = (dof/2)*k_B*T"""
    return float(_R(dof)*_R(0.5)*k_B*_R(T))

def rms_speed(M_molar, T, R=8.314):
    """v_rms = sqrt(3RT/M)  M in kg/mol"""
    return float(np.sqrt(3*_R(R)*_R(T)/_R(M_molar)))

def stefan_boltzmann_flux(T, emissivity=1.0, sigma=5.67e-8):
    """Radiated power per unit area P = eps*sigma*T^4"""
    return float(_R(emissivity)*_R(sigma)*_R(T)**4)

def blackbody_peak_wavelength(T):
    """Wien displacement law  lambda_max = b/T"""
    b = _R(2.898e-3)
    return float(b/_R(T))
