
"""PKTron Physics — Electromagnetism"""
import numpy as np
_R = np.float32

k_e    = _R(8.9875e9)   # Coulomb constant
eps0   = _R(8.854e-12)  # permittivity of free space
mu0    = _R(4*np.pi*1e-7)  # permeability of free space
c      = _R(3e8)

def coulomb_force(q1, q2, r):
    return float(k_e*_R(q1)*_R(q2)/_R(r)**2)

def electric_field(q, r):
    return float(k_e*_R(q)/_R(r)**2)

def electric_potential(q, r):
    return float(k_e*_R(q)/_R(r))

def capacitance(Q, V):
    return float(_R(Q)/_R(V))

def ohms_law_voltage(I, R):
    return float(_R(I)*_R(R))

def ohms_law_current(V, R):
    return float(_R(V)/_R(R))

def power_dissipated(V, I):
    return float(_R(V)*_R(I))

def series_resistance(*Rs):
    return float(sum(_R(r) for r in Rs))

def parallel_resistance(*Rs):
    inv = sum(1/_R(r) for r in Rs)
    return float(1/inv)

def magnetic_force(q, v, B, angle_deg=90.0):
    return float(_R(q)*_R(v)*_R(B)*np.sin(np.radians(_R(angle_deg))))

def magnetic_field_wire(I, r, mu0=4*np.pi*1e-7):
    return float(_R(mu0)*_R(I)/(_R(2)*_R(np.pi)*_R(r)))

def faraday_emf(dPhi, dt):
    return float(-_R(dPhi)/_R(dt))

def lc_resonant_frequency(L, C):
    return float(1/(_R(2)*_R(np.pi)*np.sqrt(_R(L)*_R(C))))
