"""Tests for ops auth subcommands — one test per user-facing command."""

import pytest
from unittest.mock import patch

from opensees_cli.auth import app as auth_app
from opensees_cli.main import app


def _patch_password(*passwords):
    """Return a side_effect iterator for _ask_password calls."""
    it = iter(passwords)
    return lambda *a, **kw: next(it)


class TestSignup:
    def test_signup_success(self, cli_runner, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/signup", json={
            "message": "Account created. Check your email.",
            "destination": "u@t.com",
        })
        with patch("opensees_cli.auth._ask_password", side_effect=_patch_password("Pass1!", "Pass1!")):
            result = cli_runner.invoke(app, ["auth", "signup", "-e", "u@t.com"])
        assert result.exit_code == 0
        assert "Account created" in result.output
        assert "ops auth confirm" in result.output
        assert "ops auth resend-code" in result.output

    def test_signup_password_mismatch(self, cli_runner, patch_httpx, mock_router):
        with patch("opensees_cli.auth._ask_password", side_effect=_patch_password("Pass1!", "Pass2!")):
            result = cli_runner.invoke(app, ["auth", "signup", "-e", "u@t.com"])
        assert result.exit_code == 1
        assert "do not match" in result.output

    def test_signup_already_logged_in(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        result = cli_runner.invoke(app, ["auth", "signup", "-e", "u@t.com"])
        assert result.exit_code == 0
        assert "Already logged in" in result.output


class TestConfirm:
    def test_confirm_success(self, cli_runner, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/confirm", json={"message": "Email verified."})
        result = cli_runner.invoke(app, ["auth", "confirm", "-e", "u@t.com", "-c", "123456"])
        assert result.exit_code == 0
        assert "verified" in result.output.lower()


class TestResendCode:
    def test_resend_code_success(self, cli_runner, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/resend-code", json={"message": "Code resent."})
        result = cli_runner.invoke(app, ["auth", "resend-code", "-e", "u@t.com"])
        assert result.exit_code == 0
        assert "resent" in result.output.lower()
        assert "ops auth confirm" in result.output


class TestLogin:
    def test_login_success(self, cli_runner, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/login", json={
            "access_token": "at",
            "refresh_token": "rt",
            "id_token": "id",
            "is_admin": False,
        })
        with patch("opensees_cli.auth._ask_password", return_value="Pass1!"):
            result = cli_runner.invoke(app, ["auth", "login", "-e", "u@t.com"])
        assert result.exit_code == 0
        assert "Logged in" in result.output

    def test_login_bad_credentials(self, cli_runner, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/login", status=400, json={"error": "Incorrect username or password."})
        with patch("opensees_cli.auth._ask_password", return_value="wrong"):
            result = cli_runner.invoke(app, ["auth", "login", "-e", "u@t.com"])
        assert result.exit_code == 1
        assert "Incorrect" in result.output


class TestLogout:
    def test_logout_success(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/logout", json={})
        result = cli_runner.invoke(app, ["auth", "logout"])
        assert result.exit_code == 0
        assert "Logged out" in result.output

    def test_logout_not_logged_in(self, cli_runner, patch_httpx, mock_router):
        result = cli_runner.invoke(app, ["auth", "logout"])
        assert result.exit_code == 0
        assert "Not logged in" in result.output


class TestAuthStatus:
    def test_auth_status_logged_in(self, cli_runner, logged_in_creds):
        result = cli_runner.invoke(app, ["auth", "status"])
        assert result.exit_code == 0
        assert "user@test.com" in result.output

    def test_auth_status_not_logged_in(self, cli_runner):
        result = cli_runner.invoke(app, ["auth", "status"])
        assert result.exit_code == 0
        assert "Not logged in" in result.output


class TestForgotPassword:
    def test_forgot_password(self, cli_runner, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/forgot-password", json={"message": "Reset code sent."})
        result = cli_runner.invoke(app, ["auth", "forgot-password", "-e", "u@t.com"])
        assert result.exit_code == 0
        assert "Reset code sent" in result.output


class TestResetPassword:
    def test_reset_password(self, cli_runner, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/reset-password", json={"message": "Password reset."})
        with patch("opensees_cli.auth._ask_password", side_effect=_patch_password("New1!", "New1!")):
            result = cli_runner.invoke(app, ["auth", "reset-password", "-e", "u@t.com", "-c", "000000"])
        assert result.exit_code == 0
        assert "Password reset" in result.output

    def test_reset_password_mismatch(self, cli_runner, patch_httpx, mock_router):
        with patch("opensees_cli.auth._ask_password", side_effect=_patch_password("New1!", "Old2!")):
            result = cli_runner.invoke(app, ["auth", "reset-password", "-e", "u@t.com", "-c", "000000"])
        assert result.exit_code == 1
        assert "do not match" in result.output


class TestChangePassword:
    def test_change_password(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/change-password", json={"message": "Password changed."})
        with patch("opensees_cli.auth._ask_password", side_effect=_patch_password("Old1!", "New1!", "New1!")):
            result = cli_runner.invoke(app, ["auth", "change-password"])
        assert result.exit_code == 0
        assert "Password changed" in result.output

    def test_change_password_mismatch(self, cli_runner, logged_in_creds, patch_httpx, mock_router):
        with patch("opensees_cli.auth._ask_password", side_effect=_patch_password("Old1!", "New1!", "Wrong!")):
            result = cli_runner.invoke(app, ["auth", "change-password"])
        assert result.exit_code == 1
        assert "do not match" in result.output
