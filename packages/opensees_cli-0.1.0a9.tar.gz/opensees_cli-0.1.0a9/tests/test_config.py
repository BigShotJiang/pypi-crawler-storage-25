"""Tests for opensees_cli.config — save/load/clear with isolated paths."""

from opensees_cli.config import (
    save_credentials,
    load_credentials,
    clear_credentials,
    get_access_token,
    get_refresh_token,
    get_api_url,
    is_admin,
)


class TestCredentials:
    def test_save_and_load(self):
        save_credentials(
            access_token="at",
            refresh_token="rt",
            id_token="id",
            email="a@b.com",
            is_admin=True,
        )
        creds = load_credentials()
        assert creds is not None
        assert creds["access_token"] == "at"
        assert creds["refresh_token"] == "rt"
        assert creds["id_token"] == "id"
        assert creds["email"] == "a@b.com"
        assert creds["is_admin"] is True

    def test_load_empty(self):
        assert load_credentials() is None

    def test_clear(self):
        save_credentials(access_token="at", refresh_token="rt")
        clear_credentials()
        assert load_credentials() is None

    def test_clear_nonexistent(self):
        clear_credentials()

    def test_get_access_token(self):
        assert get_access_token() is None
        save_credentials(access_token="tok", refresh_token="r")
        assert get_access_token() == "tok"

    def test_get_refresh_token(self):
        assert get_refresh_token() is None
        save_credentials(access_token="a", refresh_token="rt2")
        assert get_refresh_token() == "rt2"

    def test_is_admin_false_when_no_creds(self):
        assert is_admin() is False

    def test_is_admin_true(self):
        save_credentials(access_token="a", refresh_token="r", is_admin=True)
        assert is_admin() is True

    def test_is_admin_false(self):
        save_credentials(access_token="a", refresh_token="r", is_admin=False)
        assert is_admin() is False


class TestApiUrl:
    def test_default(self, monkeypatch):
        monkeypatch.delenv("OPENSEES_API_URL", raising=False)
        url = get_api_url()
        assert url.startswith("https://")

    def test_env_override(self, monkeypatch):
        monkeypatch.setenv("OPENSEES_API_URL", "https://custom.example/v1")
        assert get_api_url() == "https://custom.example/v1"
