"""Tests for opensees_cli.api — _parse, ApiError, 401 refresh path."""

import json

import httpx
import pytest

from opensees_cli.api import ApiError, _parse, post, get, upload_file, fetch_s3_range


class TestParse:
    def test_200_json(self):
        req = httpx.Request("GET", "https://x/")
        resp = httpx.Response(200, json={"ok": True}, request=req)
        assert _parse(resp) == {"ok": True}

    def test_200_no_json(self):
        req = httpx.Request("GET", "https://x/")
        resp = httpx.Response(200, content=b"not json", request=req)
        assert _parse(resp) == {}

    def test_400_with_json_error(self):
        req = httpx.Request("GET", "https://x/")
        body = {"error": "bad request", "code": "bad_param"}
        resp = httpx.Response(400, json=body, request=req)
        with pytest.raises(ApiError) as exc_info:
            _parse(resp)
        assert exc_info.value.status == 400
        assert exc_info.value.code == "bad_param"
        assert "bad request" in exc_info.value.message

    def test_401_no_json(self):
        req = httpx.Request("GET", "https://x/")
        resp = httpx.Response(401, content=b"", request=req)
        with pytest.raises(ApiError) as exc_info:
            _parse(resp)
        assert exc_info.value.status == 401

    def test_429_quota_code(self):
        req = httpx.Request("GET", "https://x/")
        body = {"error": "Runtime quota exceeded", "code": "quota_runtime"}
        resp = httpx.Response(429, json=body, request=req)
        with pytest.raises(ApiError) as exc_info:
            _parse(resp)
        assert exc_info.value.status == 429
        assert exc_info.value.code == "quota_runtime"


class TestApiError:
    def test_fields(self):
        e = ApiError("msg", status=429, code="submit_locked")
        assert e.message == "msg"
        assert e.status == 429
        assert e.code == "submit_locked"
        assert str(e) == "msg"


class TestPost401Refresh:
    def test_refresh_on_401(self, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/refresh", json={
            "access_token": "new-access",
            "id_token": "new-id",
        })

        original_handle = mock_router.handle
        first_call = True

        def switching_handle(request):
            nonlocal first_call
            path = httpx.URL(str(request.url)).raw_path.decode().split("?")[0]
            if path == "/prod/test" and first_call:
                first_call = False
                mock_router._calls.append({"method": request.method, "url": str(request.url), "content": request.content})
                return httpx.Response(
                    401,
                    json={"error": "Unauthorized"},
                    headers={"content-type": "application/json"},
                    request=request,
                )
            if path == "/prod/test":
                mock_router._calls.append({"method": request.method, "url": str(request.url), "content": request.content})
                return httpx.Response(
                    200,
                    json={"result": "ok"},
                    headers={"content-type": "application/json"},
                    request=request,
                )
            return original_handle(request)

        mock_router.handle = switching_handle
        result = post("/test", {"key": "val"})
        assert result == {"result": "ok"}


class TestPost400AuthErrorRefresh:
    def test_refresh_on_400_auth_error(self, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/refresh", json={
            "access_token": "new-access",
            "id_token": "new-id",
        })

        original_handle = mock_router.handle
        first_call = True

        def switching_handle(request):
            nonlocal first_call
            path = httpx.URL(str(request.url)).raw_path.decode().split("?")[0]
            if path == "/prod/test" and first_call:
                first_call = False
                return httpx.Response(
                    400,
                    json={"error": "Invalid or expired session.", "code": "auth_error"},
                    headers={"content-type": "application/json"},
                    request=request,
                )
            if path == "/prod/test":
                return httpx.Response(
                    200,
                    json={"result": "ok"},
                    headers={"content-type": "application/json"},
                    request=request,
                )
            return original_handle(request)

        mock_router.handle = switching_handle
        result = post("/test", {"key": "val"})
        assert result == {"result": "ok"}


class TestGet400AuthErrorRefresh:
    def test_refresh_on_400_auth_error(self, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("POST", "/prod/auth/refresh", json={
            "access_token": "new-access",
            "id_token": "new-id",
        })

        original_handle = mock_router.handle
        first_call = True

        def switching_handle(request):
            nonlocal first_call
            path = httpx.URL(str(request.url)).raw_path.decode().split("?")[0]
            if path == "/prod/auth/me" and first_call:
                first_call = False
                return httpx.Response(
                    400,
                    json={"error": "Invalid or expired session.", "code": "auth_error"},
                    headers={"content-type": "application/json"},
                    request=request,
                )
            if path == "/prod/auth/me":
                return httpx.Response(
                    200,
                    json={"email": "u@t.com", "quota": {}},
                    headers={"content-type": "application/json"},
                    request=request,
                )
            return original_handle(request)

        mock_router.handle = switching_handle
        result = get("/auth/me")
        assert result["email"] == "u@t.com"


class TestGet:
    def test_get_happy(self, logged_in_creds, patch_httpx, mock_router):
        mock_router.add("GET", "/prod/auth/me", json={"email": "u@t.com"})
        result = get("/auth/me")
        assert result["email"] == "u@t.com"


class TestUploadFile:
    def test_upload_success(self, patch_httpx, mock_router):
        mock_router.add_any_url("PUT", status=200)
        upload_file("https://s3.example.com/upload?sig=abc", b"content", "text/plain")

    def test_upload_failure(self, patch_httpx, mock_router):
        mock_router.add_any_url("PUT", status=500)
        with pytest.raises(ApiError):
            upload_file("https://s3.example.com/upload?sig=abc", b"content", "text/plain")


class TestFetchS3Range:
    def test_200_returns_data(self, patch_httpx, mock_router):
        mock_router.add_any_url("GET", status=200, content=b"hello world")
        data, complete = fetch_s3_range("https://s3.example.com/stdout?sig=abc")
        assert data == b"hello world"
        assert complete is True

    def test_404_returns_empty(self, patch_httpx, mock_router):
        mock_router.add_any_url("GET", status=404)
        data, complete = fetch_s3_range("https://s3.example.com/stdout?sig=abc")
        assert data == b""
        assert complete is False
