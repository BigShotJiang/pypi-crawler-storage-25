"""Authentication CLI commands."""

import sys
from typing import Any, Dict, Optional, Sequence

import typer
from rich.console import Console

from opensees_cli import api, config

console = Console()

_CONFIRM_CLI_HINT = (
    "[dim]Use [bold]ops auth confirm[/bold] to confirm the verification code.[/dim]"
)
_RESEND_CLI_HINT = (
    "[dim]If you did not receive the email, use [bold]ops auth resend-code[/bold] "
    "to send a new code.[/dim]"
)


def _print_verification_hints_if_absent(r: Dict[str, Any], *, include_resend: bool) -> None:
    msg = r.get("message") or ""
    if "ops auth confirm" not in msg:
        console.print(_CONFIRM_CLI_HINT)
    if include_resend and "resend-code" not in msg:
        console.print(_RESEND_CLI_HINT)


def _ask_password(label: str = "Password") -> str:
    """Prompt for a password showing * for each keystroke."""
    # Important: use a single output mechanism for the prompt line.
    # Mixing Rich's Console output with direct sys.stdout writes can cause the
    # next prompt to appear indented because Rich's cursor tracking doesn't see
    # the raw writes.
    #
    # Also: when stdin isn't a real TTY (tests/CI/IDE runners), termios/tty raw
    # mode can fail. In that case fall back to a standard hidden prompt.
    if not sys.stdin.isatty():
        import getpass
        # getpass prints to stderr by default; keep the label consistent.
        return getpass.getpass(f"{label}: ")

    def _prompt_prefix() -> None:
        # Force column-0 start even if the terminal is mid-line.
        sys.stdout.write("\r")
        sys.stdout.write(f"{label}: ")
        sys.stdout.flush()

    def _prompt_newline() -> None:
        # Normalize line ending + return to column 0.
        sys.stdout.write("\r\n")
        sys.stdout.flush()

    if sys.platform == "win32":
        import msvcrt
        _prompt_prefix()
        chars = []
        while True:
            ch = msvcrt.getwch()
            if ch in ("\r", "\n"):
                _prompt_newline()
                break
            if ch == "\x03":
                raise KeyboardInterrupt
            if ch in ("\x08", "\x7f"):
                if chars:
                    chars.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
                continue
            chars.append(ch)
            sys.stdout.write("*")
            sys.stdout.flush()
        return "".join(chars)
    else:
        import tty
        import termios
        _prompt_prefix()
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        chars = []
        try:
            tty.setraw(fd)
            while True:
                ch = sys.stdin.read(1)
                if ch in ("\r", "\n"):
                    _prompt_newline()
                    break
                if ch == "\x03":
                    raise KeyboardInterrupt
                if ch in ("\x08", "\x7f"):
                    if chars:
                        chars.pop()
                        sys.stdout.write("\b \b")
                        sys.stdout.flush()
                    continue
                chars.append(ch)
                sys.stdout.write("*")
                sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        return "".join(chars)


def _to_local(iso_str: str) -> str:
    """Convert an ISO 8601 UTC timestamp to a local time string."""
    from datetime import datetime, timezone
    try:
        s = str(iso_str).strip()
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        local_dt = dt.astimezone()
        return local_dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return iso_str


def _to_local_date(iso_str: str) -> str:
    """Convert an ISO 8601 instant to a local calendar date (YYYY-MM-DD)."""
    from datetime import datetime, timezone
    try:
        s = str(iso_str).strip()
        if s.endswith("Z"):
            s = s[:-1] + "+00:00"
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone().strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        return str(iso_str)


def _fmt_duration(seconds: float) -> str:
    """Format seconds as human-readable duration."""
    seconds = max(0.0, seconds)
    if seconds < 60:
        return f"{seconds:.2f}s"
    whole = int(seconds)
    frac = seconds - whole
    m, s_int = divmod(whole, 60)
    s = s_int + frac
    if m < 60:
        return f"{m}m {s:.2f}s"
    h, m = divmod(m, 60)
    return f"{h}h {m}m"


def _fmt_bytes(n: float) -> str:
    """Format bytes as a human-readable size."""
    n = max(0, n)
    if n < 1024:
        return f"{n:.0f} B"
    n /= 1024
    if n < 1024:
        return f"{n:.1f} KB"
    n /= 1024
    if n < 1024:
        return f"{n:.1f} MB"
    n /= 1024
    return f"{n:.1f} GB"


def _fmt_bytes_precise(n: float) -> str:
    """Format bytes with extra precision to distinguish from a rounded neighbor."""
    n = max(0, n)
    if n < 1024:
        return f"{n:.0f} B"
    n /= 1024
    if n < 1024:
        return f"{n:.2f} KB"
    n /= 1024
    if n < 1024:
        return f"{n:.2f} MB"
    n /= 1024
    return f"{n:.2f} GB"


def print_quota(q: dict) -> None:
    """Print quota info to the console."""
    max_rt = q.get("max_monthly_runtime", 0)
    used = q.get("monthly_runtime_used", 0)
    reserved = q.get("monthly_runtime_reserved", 0)
    committed = used + reserved
    remaining = q.get("monthly_runtime_remaining", 0)
    pct = (committed / max_rt * 100) if max_rt else 0
    rt_color = "green" if pct < 75 else ("yellow" if pct < 90 else "red")

    max_st = q.get("max_monthly_storage", 0)
    st_used = q.get("storage_used", 0)
    st_remaining = max(0, max_st - st_used)
    st_pct = (st_used / max_st * 100) if max_st else 0
    st_color = "green" if st_pct < 75 else ("yellow" if st_pct < 90 else "red")

    console.print(f"  Concurrent tasks: {q.get('max_concurrent_runs', '-')}")
    console.print(f"  Tasks/analysis:   {q.get('max_tasks_per_analysis', '-')}")
    console.print(f"  Max task timeout: {_fmt_duration(q['max_task_timeout']) if q.get('max_task_timeout') else '-'}")
    console.print(f"  Max storage/task: {_fmt_bytes(q['max_storage_per_task']) if q.get('max_storage_per_task') else '-'}")
    if reserved > 0:
        console.print(
            f"  Monthly runtime:  [{rt_color}]{_fmt_duration(used)} settled"
            f" + {_fmt_duration(reserved)} in-flight[/{rt_color}]"
            f" / {_fmt_duration(max_rt)} ({pct:.0f}% committed)"
        )
    else:
        console.print(f"  Monthly runtime:  [{rt_color}]{_fmt_duration(used)}[/{rt_color}] / {_fmt_duration(max_rt)} ({pct:.0f}% used)")
    console.print(f"  Runtime left:     {_fmt_duration(remaining)}")
    if q.get("next_reset_at"):
        console.print(f"  Next cycle:       {_to_local_date(q['next_reset_at'])}")
    else:
        console.print("  Next cycle:       [dim]—[/dim]")
    console.print(f"  Storage:          [{st_color}]{_fmt_bytes(st_used)}[/{st_color}] / {_fmt_bytes(max_st)} ({st_pct:.0f}% used)")
    st_left_str = _fmt_bytes(st_remaining)
    if st_left_str == _fmt_bytes(max_st) and st_remaining < max_st:
        st_left_str = _fmt_bytes_precise(st_remaining)
    console.print(f"  Storage left:     {st_left_str}")


def print_me(
    r: Dict[str, Any],
    *,
    open_sees_py_lines: Optional[Sequence[str]] = None,
) -> None:
    """Print a /auth/me response (used by ``ops status``).

    ``open_sees_py_lines`` are Rich-markup strings without the leading indent;
    they are printed after last activity and before the server ``CLI version``
    line (when present).
    """
    console.print(f"  Email:        [bold]{r.get('email', '')}[/bold]")
    console.print(f"  Admin:        {'[yellow]yes[/yellow]' if r.get('is_admin') else 'no'}")
    console.print(f"  Enabled:      {'[green]yes[/green]' if r.get('is_enabled') else '[red]no[/red]'}")
    signup_raw = r.get("signup_at") or r.get("created_at")
    if signup_raw:
        console.print(f"  Signup time:  {_to_local(signup_raw)}")
    else:
        console.print("  Signup time:  [dim]—[/dim]")
    if r.get("last_login_at"):
        console.print(f"  Last login:   {_to_local(r['last_login_at'])}")
    if r.get("last_activity_at"):
        console.print(f"  Last active:  {_to_local(r['last_activity_at'])}")
    if open_sees_py_lines:
        for line in open_sees_py_lines:
            console.print(f"  {line}")
    if r.get("last_cli_version"):
        console.print(f"  CLI version:  {r['last_cli_version']}")

    q = r.get("quota")
    if q:
        console.print()
        print_quota(q)


app = typer.Typer(
    help="Account management.",
)


def _is_logged_in() -> bool:
    creds = config.load_credentials()
    return bool(creds and creds.get("access_token"))


def _print_auth_help() -> None:
    logged_in = _is_logged_in()
    console.print("[bold]ops auth[/bold] — Account management\n")

    if logged_in:
        creds = config.load_credentials() or {}
        console.print(f"  Logged in as [green]{creds.get('email', '')}[/green]\n")
        console.print("[bold]Commands:[/bold]\n")
        console.print("  [bold]ops status[/bold] (top-level)   Account details & quota")
        console.print("  [bold]ops auth change-password[/bold]   Change your password")
        console.print("  [bold]ops auth logout[/bold]            Log out")
    else:
        console.print("  Not logged in.\n")
        console.print("[bold]Commands:[/bold]\n")
        console.print("  [bold]ops auth signup[/bold]            Create a new account")
        console.print("  [bold]ops auth login[/bold]             Log in")
        console.print("  [bold]ops auth confirm[/bold]           Verify your email")
        console.print("  [bold]ops auth resend-code[/bold]       Resend verification code")
        console.print("  [bold]ops auth forgot-password[/bold]   Request a password reset")
        console.print("  [bold]ops auth reset-password[/bold]    Reset password with code")

    console.print()
    console.print("[dim]Run any command with --help for more details.[/dim]")


@app.callback(invoke_without_command=True)
def _auth_callback(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is None:
        _print_auth_help()
        raise typer.Exit(0)


@app.command()
def signup(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Create a new account."""
    api.require_no_login()
    if not email:
        email = typer.prompt("Email")
    password = _ask_password()
    confirm_pw = _ask_password("Confirm password")
    if password != confirm_pw:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)

    try:
        r = api.post("/auth/signup", {"email": email, "password": password}, auth=False)
        console.print(f"[green]{r.get('message', 'Account created.')}[/green]")
        _print_verification_hints_if_absent(r, include_resend=True)
        if r.get("destination"):
            console.print(f"Code sent to [bold]{r['destination']}[/bold]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command()
def confirm(
    email: Optional[str] = typer.Option(None, "--email", "-e"),
    code: Optional[str] = typer.Option(None, "--code", "-c"),
):
    """Verify your email with the code sent to your inbox."""
    api.require_no_login()
    if not email:
        email = typer.prompt("Email")
    if not code:
        code = typer.prompt("Verification code")

    try:
        r = api.post("/auth/confirm", {"email": email, "code": code}, auth=False)
        console.print(f"[green]{r.get('message', 'Email verified.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("resend-code")
def resend_code(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Resend the email verification code."""
    api.require_no_login()
    if not email:
        email = typer.prompt("Email")

    try:
        r = api.post("/auth/resend-code", {"email": email}, auth=False)
        console.print(f"[green]{r.get('message', 'Code resent.')}[/green]")
        _print_verification_hints_if_absent(r, include_resend=False)
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command()
def login(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Log in to your account."""
    if not email:
        email = typer.prompt("Email")
    password = _ask_password()

    try:
        from opensees_cli import __version__
        r = api.post(
            "/auth/login",
            {"email": email, "password": password, "cli_version": __version__},
            auth=False,
        )
        config.save_credentials(
            access_token=r["access_token"],
            refresh_token=r["refresh_token"],
            id_token=r.get("id_token"),
            email=email,
            is_admin=r.get("is_admin", False),
        )
        console.print(f"[green]Logged in as [bold]{email}[/bold][/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command()
def logout():
    """Log out of your account."""
    api.require_login()
    token = config.get_access_token()
    if token:
        try:
            api.post("/auth/logout", {"access_token": token}, auth=False)
        except Exception:
            pass
    config.clear_credentials()
    console.print("[green]Logged out.[/green]")


@app.command()
def status():
    """Show current login status."""
    creds = config.load_credentials()
    if not creds or not creds.get("access_token"):
        console.print("Not logged in. Run [bold]ops auth login[/bold]")
        raise typer.Exit(0)
    console.print(f"Logged in as [bold]{creds.get('email', 'unknown')}[/bold]")


@app.command("forgot-password")
def forgot_password(email: Optional[str] = typer.Option(None, "--email", "-e")):
    """Request a password reset code."""
    if not email:
        email = typer.prompt("Email")

    try:
        r = api.post("/auth/forgot-password", {"email": email}, auth=False)
        console.print(f"[green]{r.get('message', 'Reset code sent.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("reset-password")
def reset_password(
    email: Optional[str] = typer.Option(None, "--email", "-e"),
    code: Optional[str] = typer.Option(None, "--code", "-c"),
):
    """Reset your password using the emailed code."""
    if not email:
        email = typer.prompt("Email")
    if not code:
        code = typer.prompt("Reset code")
    new_password = _ask_password("New password")
    confirm_pw = _ask_password("Confirm new password")
    if new_password != confirm_pw:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)

    try:
        r = api.post(
            "/auth/reset-password",
            {"email": email, "code": code, "new_password": new_password},
            auth=False,
        )
        console.print(f"[green]{r.get('message', 'Password reset.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)


@app.command("change-password")
def change_password():
    """Change your password (must be logged in)."""
    api.require_login()
    old_password = _ask_password("Current password")
    new_password = _ask_password("New password")
    confirm_pw = _ask_password("Confirm new password")
    if new_password != confirm_pw:
        console.print("[red]Passwords do not match.[/red]")
        raise typer.Exit(1)

    try:
        r = api.post("/auth/change-password", {
            "old_password": old_password,
            "new_password": new_password,
        })
        console.print(f"[green]{r.get('message', 'Password changed.')}[/green]")
    except api.ApiError as e:
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)
