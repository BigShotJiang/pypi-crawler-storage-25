"""Local credential storage.

Credentials are stored in ~/.opensees/credentials.json.

Optional env files (``export``-style ``KEY=value`` lines) are merged before reads:
  1. First ``.env`` found walking upward from ``Path.cwd()`` (repo root when you run ``ops`` there).
  2. ``~/.opensees/.env`` (keys only set if not already in the process environment).
  3. Path from ``OPENSEES_ENV_FILE`` if set (same non-override rule, evaluated first).
"""

import json
import os
import re
import sys
from pathlib import Path
from typing import Any, Dict, Optional

CONFIG_DIR = Path.home() / ".opensees"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"

_DOTENV_LOADED = False
_ENV_LINE_RE = re.compile(
    r"^\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$",
)


def _strip_env_value(raw: str) -> str:
    s = raw.strip()
    if len(s) >= 2 and ((s[0] == s[-1] == '"') or (s[0] == s[-1] == "'")):
        return s[1:-1]
    if s.startswith('"') and s.endswith('"'):
        return s[1:-1]
    if s.startswith("'") and s.endswith("'"):
        return s[1:-1]
    return s


def _load_env_file(path: Path) -> None:
    """Set ``os.environ`` keys from a dotenv-style file (does not override existing vars)."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        m = _ENV_LINE_RE.match(line)
        if not m:
            continue
        key, val_raw = m.group(1), m.group(2)
        if key in os.environ:
            continue
        val = _strip_env_value(val_raw)
        os.environ[key] = val


def _maybe_load_dotenv_files() -> None:
    """Load optional ``.env`` files once (see module docstring)."""
    global _DOTENV_LOADED
    if _DOTENV_LOADED:
        return
    _DOTENV_LOADED = True
    # Tests control env via monkeypatch; do not pull in a developer's repo ``.env``.
    if "pytest" in sys.modules:
        return

    explicit = os.environ.get("OPENSEES_ENV_FILE", "").strip()
    if explicit:
        p = Path(explicit).expanduser()
        if p.is_file():
            _load_env_file(p)

    d = Path.cwd()
    for _ in range(12):
        candidate = d / ".env"
        if candidate.is_file():
            _load_env_file(candidate)
            break
        if d.parent == d:
            break
        d = d.parent

    home_env = CONFIG_DIR / ".env"
    if home_env.is_file():
        _load_env_file(home_env)

# Default API base URL — baked into the release.
# Override for development: set OPENSEES_API_URL env var.
DEFAULT_API_URL = "https://qjnct7etj7.execute-api.us-west-2.amazonaws.com/prod"


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    # Restrict permissions on the directory
    CONFIG_DIR.chmod(0o700)


# ---------------------------------------------------------------------------
# Credentials (tokens)
# ---------------------------------------------------------------------------

def save_credentials(
    access_token: str,
    refresh_token: str,
    id_token: Optional[str] = None,
    email: Optional[str] = None,
    is_admin: bool = False,
) -> None:
    _ensure_dir()
    data = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "id_token": id_token,
        "email": email,
        "is_admin": is_admin,
    }
    CREDENTIALS_FILE.write_text(json.dumps(data, indent=2))
    CREDENTIALS_FILE.chmod(0o600)


def is_admin() -> bool:
    """Best-effort hint from last login or refresh. **Not authoritative** — the API checks Cognito groups."""
    creds = load_credentials()
    return bool(creds and creds.get("is_admin"))


def load_credentials() -> Optional[Dict[str, Any]]:
    if not CREDENTIALS_FILE.exists():
        return None
    try:
        return json.loads(CREDENTIALS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def clear_credentials() -> None:
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def get_access_token() -> Optional[str]:
    creds = load_credentials()
    return creds.get("access_token") if creds else None


def get_refresh_token() -> Optional[str]:
    creds = load_credentials()
    return creds.get("refresh_token") if creds else None


def get_api_url() -> str:
    _maybe_load_dotenv_files()
    return os.environ.get("OPENSEES_API_URL") or DEFAULT_API_URL
