"""HTTP client for the OpenSees CLI REST API.

Handles auth headers and automatic token refresh when the server reports an
expired session (HTTP 401, or HTTP 400 with code ``auth_error`` — e.g. /auth/me).
"""

from typing import Any, Dict, Optional

import httpx

from opensees_cli import __version__
from opensees_cli.config import (
    get_access_token,
    get_api_url,
    get_refresh_token,
    load_credentials,
    save_credentials,
)

TIMEOUT = 30.0


class ApiError(Exception):
    def __init__(self, message: str, status: int = 0, code: Optional[str] = None):
        self.message = message
        self.status = status
        self.code = code
        super().__init__(message)


def _not_logged_in() -> None:
    """Print a login prompt and exit."""
    from rich.console import Console
    c = Console()
    c.print("Not logged in. To get started:\n")
    c.print("  [bold]ops auth signup[/bold]    Create a new account")
    c.print("  [bold]ops auth login[/bold]     Log in to an existing account")
    raise SystemExit(0)


def require_login() -> None:
    """Exit early if the user has no stored credentials."""
    if not load_credentials() or not load_credentials().get("access_token"):
        _not_logged_in()


def require_no_login() -> None:
    """Exit early if the user is already logged in."""
    from rich.console import Console
    creds = load_credentials()
    if creds and creds.get("access_token"):
        Console().print(
            f"Already logged in as [bold]{creds.get('email', '')}[/bold]. "
            "Run [bold]ops auth logout[/bold] first."
        )
        raise SystemExit(0)


def _url(path: str) -> str:
    return f"{get_api_url().rstrip('/')}{path}"


def _headers(token: Optional[str] = None) -> Dict[str, str]:
    h: Dict[str, str] = {"Content-Type": "application/json", "User-Agent": f"opensees_cli/{__version__}"}
    if token is not None:
        if token:
            h["Authorization"] = f"Bearer {token}"
        return h
    creds = load_credentials() or {}
    id_tok = creds.get("id_token")
    access_tok = creds.get("access_token")
    if id_tok:
        h["Authorization"] = f"Bearer {id_tok}"
    if access_tok:
        h["X-Access-Token"] = access_tok
    return h


def _parse(resp: httpx.Response) -> Dict[str, Any]:
    try:
        data = resp.json()
    except Exception:
        if resp.status_code >= 400:
            # Non-JSON error bodies are common behind proxies/API gateways.
            msg = f"HTTP {resp.status_code}"
            try:
                text = (resp.text or "").strip()
                if text:
                    msg = text[:300]
            except Exception:
                pass
            raise ApiError(msg, resp.status_code)
        return {}
    if resp.status_code >= 400:
        # Backends vary in error shape. Prefer specific fields when available.
        msg = (
            data.get("error")
            or data.get("message")
            or data.get("detail")
            or data.get("details")
            or data.get("errors")
            or f"HTTP {resp.status_code}"
        )
        if not isinstance(msg, str):
            try:
                import json as _json
                msg = _json.dumps(msg)
            except Exception:
                msg = str(msg)
        raise ApiError(
            msg,
            resp.status_code,
            data.get("code"),
        )
    return data


def _me_is_admin_after_token_update() -> Optional[bool]:
    """GET /auth/me with current headers only — no automatic refresh (avoids recursion from _try_refresh)."""
    try:
        resp = httpx.get(_url("/auth/me"), headers=_headers(), timeout=TIMEOUT)
        if resp.status_code != 200:
            return None
        body = resp.json()
        if isinstance(body, dict) and "is_admin" in body:
            return bool(body["is_admin"])
        return None
    except Exception:
        return None


def _try_refresh() -> bool:
    rt = get_refresh_token()
    if not rt:
        return False
    try:
        data = post("/auth/refresh", {"refresh_token": rt}, auth=False)
        creds = load_credentials() or {}
        save_credentials(
            access_token=data["access_token"],
            refresh_token=creds.get("refresh_token", rt),
            id_token=data.get("id_token"),
            email=creds.get("email"),
            is_admin=creds.get("is_admin", False),
        )
        # Source of truth for admin is Cognito groups via /auth/me (fixes stale cached is_admin).
        fresh_admin = _me_is_admin_after_token_update()
        if fresh_admin is not None:
            creds = load_credentials() or {}
            save_credentials(
                access_token=creds["access_token"],
                refresh_token=creds.get("refresh_token", rt),
                id_token=creds.get("id_token"),
                email=creds.get("email"),
                is_admin=fresh_admin,
            )
        return True
    except Exception:
        return False


def _needs_auth_refresh(resp: httpx.Response) -> bool:
    """True if the response likely means an expired access token (refresh may recover)."""
    if resp.status_code == 401:
        return True
    if resp.status_code != 400:
        return False
    try:
        data = resp.json()
        return data.get("code") == "auth_error"
    except Exception:
        return False


def post(path: str, body: Dict[str, Any], auth: bool = True) -> Dict[str, Any]:
    hdrs = _headers() if auth else _headers(token="")
    resp = httpx.post(_url(path), json=body, headers=hdrs, timeout=TIMEOUT)
    if auth and _needs_auth_refresh(resp):
        if _try_refresh():
            resp = httpx.post(_url(path), json=body, headers=_headers(), timeout=TIMEOUT)
        else:
            _not_logged_in()
    return _parse(resp)


def get(path: str, params: Optional[Dict[str, Any]] = None, auth: bool = True) -> Dict[str, Any]:
    hdrs = _headers() if auth else _headers(token="")
    resp = httpx.get(_url(path), params=params, headers=hdrs, timeout=TIMEOUT)
    if auth and _needs_auth_refresh(resp):
        if _try_refresh():
            resp = httpx.get(_url(path), params=params, headers=_headers(), timeout=TIMEOUT)
        else:
            _not_logged_in()
    return _parse(resp)


def upload_file(presigned_url: str, file_bytes: bytes, content_type: str = "text/x-python") -> None:
    """Upload raw bytes to a remote URL."""
    resp = httpx.put(
        presigned_url,
        content=file_bytes,
        headers={"Content-Type": content_type},
        timeout=60.0,
        follow_redirects=True,
    )
    if not (200 <= resp.status_code < 300):
        raise ApiError(f"Upload failed (HTTP {resp.status_code})", resp.status_code)


def fetch_s3_range(presigned_url: str, start_byte: int = 0) -> tuple[bytes, bool]:
    """GET bytes from a presigned S3 URL using Range header.

    Returns (data, is_complete):
      - data: bytes from start_byte onward (empty if object doesn't exist yet)
      - is_complete: False if the object doesn't exist (404) or range is unsatisfiable
    """
    headers = {}
    if start_byte > 0:
        headers["Range"] = f"bytes={start_byte}-"
    try:
        resp = httpx.get(presigned_url, headers=headers, timeout=10.0)
    except httpx.TimeoutException:
        return b"", False
    except httpx.RequestError:
        return b"", False
    if resp.status_code == 404 or resp.status_code == 403:
        return b"", False
    if resp.status_code == 416:
        # Range not satisfiable — no new data since last read
        return b"", True
    if resp.status_code in (200, 206):
        return resp.content, True
    return b"", False
