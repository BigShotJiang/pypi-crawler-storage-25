"""Allow ``python -m opensees_cli`` as a fallback when ``ops`` is not on PATH."""

import sys

from opensees_cli.main import app
from opensees_cli.path_setup import ensure_path

# ``set-path`` runs its own forced PATH flow; skip the one-time check here so we
# do not prompt twice.
if len(sys.argv) < 2 or sys.argv[1] != "set-path":
    ensure_path()
app()
