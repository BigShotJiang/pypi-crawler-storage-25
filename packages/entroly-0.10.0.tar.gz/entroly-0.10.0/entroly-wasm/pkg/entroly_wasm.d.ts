/* tslint:disable */
/* eslint-disable */

export class WasmEntrolyEngine {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Advance the turn counter and apply Ebbinghaus decay.
     */
    advance_turn(): void;
    /**
     * Analyze codebase health (A-F grade).
     */
    analyze_health(): any;
    /**
     * Clear EGSC cache.
     */
    cache_clear(): void;
    /**
     * Cache hit rate.
     */
    cache_hit_rate(): number;
    /**
     * Cache empty check.
     */
    cache_is_empty(): boolean;
    /**
     * Cache entry count.
     */
    cache_len(): number;
    /**
     * Classify a task query.
     */
    classify_task(query: string): any;
    /**
     * Clear all fragments and reset engine.
     */
    clear(): void;
    /**
     * Dependency graph stats.
     */
    dep_graph_stats(): any;
    /**
     * Detect entropy anomalies.
     */
    entropy_anomalies(): any;
    /**
     * Explain why each fragment was selected/excluded in last optimization.
     */
    explain_selection(): any;
    /**
     * Export all fragments as JSON.
     */
    export_fragments(): any;
    /**
     * Export full engine state as JSON string.
     */
    export_state(): any;
    /**
     * Get fragment count.
     */
    fragment_count(): number;
    /**
     * Get the current turn number.
     */
    get_turn(): number;
    /**
     * Hierarchical context compression.
     */
    hierarchical_compress(token_budget: number, query: string): any;
    /**
     * Import engine state from JSON string.
     */
    import_state(json_str: string): any;
    /**
     * Ingest a context fragment into the engine.
     * Pipeline: tokens → SimHash → dedup → entropy → criticality → depgraph → store
     */
    ingest(content: string, source: string, token_count: number, is_pinned: boolean): any;
    /**
     * Create a new Entroly engine with default parameters.
     */
    constructor();
    /**
     * Full optimization pipeline: IOS + PRISM + Channel Coding + Resonance + Causal.
     */
    optimize(token_budget: number, query: string): any;
    /**
     * Query manifold stats.
     */
    query_manifold_stats(): any;
    /**
     * Semantic recall of relevant fragments.
     */
    recall(query: string, top_k: number): any;
    /**
     * Record failed outcome for specific fragment IDs.
     */
    record_failure(fragment_ids_json: string): void;
    /**
     * Record a continuous reward signal.
     */
    record_reward(fragment_ids_json: string, reward: number): void;
    /**
     * Record successful outcome for specific fragment IDs.
     */
    record_success(fragment_ids_json: string): void;
    /**
     * Remove a fragment by ID.
     */
    remove(fragment_id: string): boolean;
    /**
     * Scan a fragment for security vulnerabilities.
     */
    scan_fragment(fragment_id: string): any;
    /**
     * Score context utilization from LLM response.
     */
    score_utilization(response: string): any;
    /**
     * Security report for all fragments.
     */
    security_report(): any;
    /**
     * Semantic dedup report.
     */
    semantic_dedup_report(): any;
    /**
     * Set cost-per-token directly.
     */
    set_cache_cost_per_token(cost: number): void;
    /**
     * Enable/disable channel coding.
     */
    set_channel_coding_enabled(enabled: boolean): void;
    /**
     * Set exploration rate.
     */
    set_exploration_rate(rate: number): void;
    /**
     * Set cost model from model name.
     */
    set_model(model_name: string): void;
    /**
     * Enable/disable query personas.
     */
    set_query_personas_enabled(enabled: boolean): void;
    /**
     * Set scoring weights (normalized to sum=1.0).
     */
    set_weights(w_recency: number, w_frequency: number, w_semantic: number, w_entropy: number): void;
    /**
     * Get full engine statistics as JSON.
     */
    stats(): any;
}
