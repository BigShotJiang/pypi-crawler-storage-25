/* @ts-self-types="./entroly_wasm.d.ts" */

class WasmEntrolyEngine {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmEntrolyEngineFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmentrolyengine_free(ptr, 0);
    }
    /**
     * Advance the turn counter and apply Ebbinghaus decay.
     */
    advance_turn() {
        wasm.wasmentrolyengine_advance_turn(this.__wbg_ptr);
    }
    /**
     * Analyze codebase health (A-F grade).
     * @returns {any}
     */
    analyze_health() {
        const ret = wasm.wasmentrolyengine_analyze_health(this.__wbg_ptr);
        return ret;
    }
    /**
     * Clear EGSC cache.
     */
    cache_clear() {
        wasm.wasmentrolyengine_cache_clear(this.__wbg_ptr);
    }
    /**
     * Cache hit rate.
     * @returns {number}
     */
    cache_hit_rate() {
        const ret = wasm.wasmentrolyengine_cache_hit_rate(this.__wbg_ptr);
        return ret;
    }
    /**
     * Cache empty check.
     * @returns {boolean}
     */
    cache_is_empty() {
        const ret = wasm.wasmentrolyengine_cache_is_empty(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Cache entry count.
     * @returns {number}
     */
    cache_len() {
        const ret = wasm.wasmentrolyengine_cache_len(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Classify a task query.
     * @param {string} query
     * @returns {any}
     */
    classify_task(query) {
        const ptr0 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_classify_task(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Clear all fragments and reset engine.
     */
    clear() {
        wasm.wasmentrolyengine_clear(this.__wbg_ptr);
    }
    /**
     * Dependency graph stats.
     * @returns {any}
     */
    dep_graph_stats() {
        const ret = wasm.wasmentrolyengine_dep_graph_stats(this.__wbg_ptr);
        return ret;
    }
    /**
     * Detect entropy anomalies.
     * @returns {any}
     */
    entropy_anomalies() {
        const ret = wasm.wasmentrolyengine_entropy_anomalies(this.__wbg_ptr);
        return ret;
    }
    /**
     * Explain why each fragment was selected/excluded in last optimization.
     * @returns {any}
     */
    explain_selection() {
        const ret = wasm.wasmentrolyengine_explain_selection(this.__wbg_ptr);
        return ret;
    }
    /**
     * Export all fragments as JSON.
     * @returns {any}
     */
    export_fragments() {
        const ret = wasm.wasmentrolyengine_export_fragments(this.__wbg_ptr);
        return ret;
    }
    /**
     * Export full engine state as JSON string.
     * @returns {any}
     */
    export_state() {
        const ret = wasm.wasmentrolyengine_export_state(this.__wbg_ptr);
        return ret;
    }
    /**
     * Get fragment count.
     * @returns {number}
     */
    fragment_count() {
        const ret = wasm.wasmentrolyengine_fragment_count(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Get the current turn number.
     * @returns {number}
     */
    get_turn() {
        const ret = wasm.wasmentrolyengine_get_turn(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * Hierarchical context compression.
     * @param {number} token_budget
     * @param {string} query
     * @returns {any}
     */
    hierarchical_compress(token_budget, query) {
        const ptr0 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_hierarchical_compress(this.__wbg_ptr, token_budget, ptr0, len0);
        return ret;
    }
    /**
     * Import engine state from JSON string.
     * @param {string} json_str
     * @returns {any}
     */
    import_state(json_str) {
        const ptr0 = passStringToWasm0(json_str, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_import_state(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Ingest a context fragment into the engine.
     * Pipeline: tokens → SimHash → dedup → entropy → criticality → depgraph → store
     * @param {string} content
     * @param {string} source
     * @param {number} token_count
     * @param {boolean} is_pinned
     * @returns {any}
     */
    ingest(content, source, token_count, is_pinned) {
        const ptr0 = passStringToWasm0(content, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(source, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_ingest(this.__wbg_ptr, ptr0, len0, ptr1, len1, token_count, is_pinned);
        return ret;
    }
    /**
     * Create a new Entroly engine with default parameters.
     */
    constructor() {
        const ret = wasm.wasmentrolyengine_new();
        this.__wbg_ptr = ret >>> 0;
        WasmEntrolyEngineFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Full optimization pipeline: IOS + PRISM + Channel Coding + Resonance + Causal.
     * @param {number} token_budget
     * @param {string} query
     * @returns {any}
     */
    optimize(token_budget, query) {
        const ptr0 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_optimize(this.__wbg_ptr, token_budget, ptr0, len0);
        return ret;
    }
    /**
     * Query manifold stats.
     * @returns {any}
     */
    query_manifold_stats() {
        const ret = wasm.wasmentrolyengine_query_manifold_stats(this.__wbg_ptr);
        return ret;
    }
    /**
     * Semantic recall of relevant fragments.
     * @param {string} query
     * @param {number} top_k
     * @returns {any}
     */
    recall(query, top_k) {
        const ptr0 = passStringToWasm0(query, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_recall(this.__wbg_ptr, ptr0, len0, top_k);
        return ret;
    }
    /**
     * Record failed outcome for specific fragment IDs.
     * @param {string} fragment_ids_json
     */
    record_failure(fragment_ids_json) {
        const ptr0 = passStringToWasm0(fragment_ids_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.wasmentrolyengine_record_failure(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Record a continuous reward signal.
     * @param {string} fragment_ids_json
     * @param {number} reward
     */
    record_reward(fragment_ids_json, reward) {
        const ptr0 = passStringToWasm0(fragment_ids_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.wasmentrolyengine_record_reward(this.__wbg_ptr, ptr0, len0, reward);
    }
    /**
     * Record successful outcome for specific fragment IDs.
     * @param {string} fragment_ids_json
     */
    record_success(fragment_ids_json) {
        const ptr0 = passStringToWasm0(fragment_ids_json, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.wasmentrolyengine_record_success(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Remove a fragment by ID.
     * @param {string} fragment_id
     * @returns {boolean}
     */
    remove(fragment_id) {
        const ptr0 = passStringToWasm0(fragment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_remove(this.__wbg_ptr, ptr0, len0);
        return ret !== 0;
    }
    /**
     * Scan a fragment for security vulnerabilities.
     * @param {string} fragment_id
     * @returns {any}
     */
    scan_fragment(fragment_id) {
        const ptr0 = passStringToWasm0(fragment_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_scan_fragment(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Score context utilization from LLM response.
     * @param {string} response
     * @returns {any}
     */
    score_utilization(response) {
        const ptr0 = passStringToWasm0(response, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmentrolyengine_score_utilization(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Security report for all fragments.
     * @returns {any}
     */
    security_report() {
        const ret = wasm.wasmentrolyengine_security_report(this.__wbg_ptr);
        return ret;
    }
    /**
     * Semantic dedup report.
     * @returns {any}
     */
    semantic_dedup_report() {
        const ret = wasm.wasmentrolyengine_semantic_dedup_report(this.__wbg_ptr);
        return ret;
    }
    /**
     * Set cost-per-token directly.
     * @param {number} cost
     */
    set_cache_cost_per_token(cost) {
        wasm.wasmentrolyengine_set_cache_cost_per_token(this.__wbg_ptr, cost);
    }
    /**
     * Enable/disable channel coding.
     * @param {boolean} enabled
     */
    set_channel_coding_enabled(enabled) {
        wasm.wasmentrolyengine_set_channel_coding_enabled(this.__wbg_ptr, enabled);
    }
    /**
     * Set exploration rate.
     * @param {number} rate
     */
    set_exploration_rate(rate) {
        wasm.wasmentrolyengine_set_exploration_rate(this.__wbg_ptr, rate);
    }
    /**
     * Set cost model from model name.
     * @param {string} model_name
     */
    set_model(model_name) {
        const ptr0 = passStringToWasm0(model_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.wasmentrolyengine_set_model(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * Enable/disable query personas.
     * @param {boolean} enabled
     */
    set_query_personas_enabled(enabled) {
        wasm.wasmentrolyengine_set_query_personas_enabled(this.__wbg_ptr, enabled);
    }
    /**
     * Set scoring weights (normalized to sum=1.0).
     * @param {number} w_recency
     * @param {number} w_frequency
     * @param {number} w_semantic
     * @param {number} w_entropy
     */
    set_weights(w_recency, w_frequency, w_semantic, w_entropy) {
        wasm.wasmentrolyengine_set_weights(this.__wbg_ptr, w_recency, w_frequency, w_semantic, w_entropy);
    }
    /**
     * Get full engine statistics as JSON.
     * @returns {any}
     */
    stats() {
        const ret = wasm.wasmentrolyengine_stats(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) WasmEntrolyEngine.prototype[Symbol.dispose] = WasmEntrolyEngine.prototype.free;
exports.WasmEntrolyEngine = WasmEntrolyEngine;

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_throw_81fc77679af83bc6: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg_parse_545d11396395fbbd: function() { return handleError(function (arg0, arg1) {
            const ret = JSON.parse(getStringFromWasm0(arg0, arg1));
            return ret;
        }, arguments); },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./entroly_wasm_bg.js": import0,
    };
}

const WasmEntrolyEngineFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmentrolyengine_free(ptr >>> 0, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
function decodeText(ptr, len) {
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

const wasmPath = `${__dirname}/entroly_wasm_bg.wasm`;
const wasmBytes = require('fs').readFileSync(wasmPath);
const wasmModule = new WebAssembly.Module(wasmBytes);
let wasm = new WebAssembly.Instance(wasmModule, __wbg_get_imports()).exports;
wasm.__wbindgen_start();
