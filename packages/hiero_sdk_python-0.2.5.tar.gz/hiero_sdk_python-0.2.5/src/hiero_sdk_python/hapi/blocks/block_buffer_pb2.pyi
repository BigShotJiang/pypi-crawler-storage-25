from ..block.stream import block_pb2 as _block_pb2
from ..services import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BufferedBlock(_message.Message):
    __slots__ = ("block_number", "closed_timestamp", "is_proof_sent", "is_acknowledged", "block", "opened_timestamp")
    BLOCK_NUMBER_FIELD_NUMBER: _ClassVar[int]
    CLOSED_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    IS_PROOF_SENT_FIELD_NUMBER: _ClassVar[int]
    IS_ACKNOWLEDGED_FIELD_NUMBER: _ClassVar[int]
    BLOCK_FIELD_NUMBER: _ClassVar[int]
    OPENED_TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    block_number: int
    closed_timestamp: _timestamp_pb2.Timestamp
    is_proof_sent: bool
    is_acknowledged: bool
    block: _block_pb2.Block
    opened_timestamp: _timestamp_pb2.Timestamp
    def __init__(self, block_number: _Optional[int] = ..., closed_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., is_proof_sent: bool = ..., is_acknowledged: bool = ..., block: _Optional[_Union[_block_pb2.Block, _Mapping]] = ..., opened_timestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
