from ....services import basic_types_pb2 as _basic_types_pb2
from ....streams import contract_action_pb2 as _contract_action_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ContractSlotUsage(_message.Message):
    __slots__ = ("contract_id", "written_slot_keys", "slot_reads")
    CONTRACT_ID_FIELD_NUMBER: _ClassVar[int]
    WRITTEN_SLOT_KEYS_FIELD_NUMBER: _ClassVar[int]
    SLOT_READS_FIELD_NUMBER: _ClassVar[int]
    contract_id: _basic_types_pb2.ContractID
    written_slot_keys: WrittenSlotKeys
    slot_reads: _containers.RepeatedCompositeFieldContainer[SlotRead]
    def __init__(self, contract_id: _Optional[_Union[_basic_types_pb2.ContractID, _Mapping]] = ..., written_slot_keys: _Optional[_Union[WrittenSlotKeys, _Mapping]] = ..., slot_reads: _Optional[_Iterable[_Union[SlotRead, _Mapping]]] = ...) -> None: ...

class WrittenSlotKeys(_message.Message):
    __slots__ = ("keys",)
    KEYS_FIELD_NUMBER: _ClassVar[int]
    keys: _containers.RepeatedScalarFieldContainer[bytes]
    def __init__(self, keys: _Optional[_Iterable[bytes]] = ...) -> None: ...

class SlotRead(_message.Message):
    __slots__ = ("index", "key", "read_value")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    READ_VALUE_FIELD_NUMBER: _ClassVar[int]
    index: int
    key: bytes
    read_value: bytes
    def __init__(self, index: _Optional[int] = ..., key: _Optional[bytes] = ..., read_value: _Optional[bytes] = ...) -> None: ...

class ExecutedInitcode(_message.Message):
    __slots__ = ("contract_id", "initcode_bookends", "explicit_initcode")
    CONTRACT_ID_FIELD_NUMBER: _ClassVar[int]
    INITCODE_BOOKENDS_FIELD_NUMBER: _ClassVar[int]
    EXPLICIT_INITCODE_FIELD_NUMBER: _ClassVar[int]
    contract_id: _basic_types_pb2.ContractID
    initcode_bookends: InitcodeBookends
    explicit_initcode: bytes
    def __init__(self, contract_id: _Optional[_Union[_basic_types_pb2.ContractID, _Mapping]] = ..., initcode_bookends: _Optional[_Union[InitcodeBookends, _Mapping]] = ..., explicit_initcode: _Optional[bytes] = ...) -> None: ...

class InitcodeBookends(_message.Message):
    __slots__ = ("deploy_bytecode", "metadata_bytecode")
    DEPLOY_BYTECODE_FIELD_NUMBER: _ClassVar[int]
    METADATA_BYTECODE_FIELD_NUMBER: _ClassVar[int]
    deploy_bytecode: bytes
    metadata_bytecode: bytes
    def __init__(self, deploy_bytecode: _Optional[bytes] = ..., metadata_bytecode: _Optional[bytes] = ...) -> None: ...

class EvmTransactionLog(_message.Message):
    __slots__ = ("contract_id", "data", "topics")
    CONTRACT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TOPICS_FIELD_NUMBER: _ClassVar[int]
    contract_id: _basic_types_pb2.ContractID
    data: bytes
    topics: _containers.RepeatedScalarFieldContainer[bytes]
    def __init__(self, contract_id: _Optional[_Union[_basic_types_pb2.ContractID, _Mapping]] = ..., data: _Optional[bytes] = ..., topics: _Optional[_Iterable[bytes]] = ...) -> None: ...

class EvmTraceData(_message.Message):
    __slots__ = ("contract_actions", "contract_slot_usages", "error_details", "executed_initcode", "logs")
    CONTRACT_ACTIONS_FIELD_NUMBER: _ClassVar[int]
    CONTRACT_SLOT_USAGES_FIELD_NUMBER: _ClassVar[int]
    ERROR_DETAILS_FIELD_NUMBER: _ClassVar[int]
    EXECUTED_INITCODE_FIELD_NUMBER: _ClassVar[int]
    LOGS_FIELD_NUMBER: _ClassVar[int]
    contract_actions: _containers.RepeatedCompositeFieldContainer[_contract_action_pb2.ContractAction]
    contract_slot_usages: _containers.RepeatedCompositeFieldContainer[ContractSlotUsage]
    error_details: str
    executed_initcode: ExecutedInitcode
    logs: _containers.RepeatedCompositeFieldContainer[EvmTransactionLog]
    def __init__(self, contract_actions: _Optional[_Iterable[_Union[_contract_action_pb2.ContractAction, _Mapping]]] = ..., contract_slot_usages: _Optional[_Iterable[_Union[ContractSlotUsage, _Mapping]]] = ..., error_details: _Optional[str] = ..., executed_initcode: _Optional[_Union[ExecutedInitcode, _Mapping]] = ..., logs: _Optional[_Iterable[_Union[EvmTransactionLog, _Mapping]]] = ...) -> None: ...
