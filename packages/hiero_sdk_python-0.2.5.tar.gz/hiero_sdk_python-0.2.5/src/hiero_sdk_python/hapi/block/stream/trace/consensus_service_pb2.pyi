from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class SubmitMessageTraceData(_message.Message):
    __slots__ = ("sequence_number", "running_hash")
    SEQUENCE_NUMBER_FIELD_NUMBER: _ClassVar[int]
    RUNNING_HASH_FIELD_NUMBER: _ClassVar[int]
    sequence_number: int
    running_hash: bytes
    def __init__(self, sequence_number: _Optional[int] = ..., running_hash: _Optional[bytes] = ...) -> None: ...
