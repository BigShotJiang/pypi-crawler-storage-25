from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class UtilPrngOutput(_message.Message):
    __slots__ = ("prng_bytes", "prng_number")
    PRNG_BYTES_FIELD_NUMBER: _ClassVar[int]
    PRNG_NUMBER_FIELD_NUMBER: _ClassVar[int]
    prng_bytes: bytes
    prng_number: int
    def __init__(self, prng_bytes: _Optional[bytes] = ..., prng_number: _Optional[int] = ...) -> None: ...
