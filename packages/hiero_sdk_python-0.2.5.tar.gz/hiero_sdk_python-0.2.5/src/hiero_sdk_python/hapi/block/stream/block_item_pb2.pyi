from ...block.stream import block_proof_pb2 as _block_proof_pb2
from ...block.stream import record_file_item_pb2 as _record_file_item_pb2
from ...block.stream.input import event_metadata_pb2 as _event_metadata_pb2
from ...block.stream.input import round_header_pb2 as _round_header_pb2
from ...block.stream.output import block_header_pb2 as _block_header_pb2
from ...block.stream.output import state_changes_pb2 as _state_changes_pb2
from ...block.stream.output import transaction_output_pb2 as _transaction_output_pb2
from ...block.stream.output import transaction_result_pb2 as _transaction_result_pb2
from ...block.stream.trace import trace_data_pb2 as _trace_data_pb2
from ...block.stream.output import block_footer_pb2 as _block_footer_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SubMerkleTree(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ITEM_TYPE_UNSPECIFIED: _ClassVar[SubMerkleTree]
    PREVIOUS_BLOCK_ROOT: _ClassVar[SubMerkleTree]
    PREVIOUS_ROOTS_TREE: _ClassVar[SubMerkleTree]
    PREVIOUS_BLOCK_START_STATE: _ClassVar[SubMerkleTree]
    CONSENSUS_HEADER_ITEMS: _ClassVar[SubMerkleTree]
    INPUT_ITEMS_TREE: _ClassVar[SubMerkleTree]
    OUTPUT_ITEMS_TREE: _ClassVar[SubMerkleTree]
    STATE_CHANGE_ITEMS_TREE: _ClassVar[SubMerkleTree]
    TRACE_DATA_ITEMS_TREE: _ClassVar[SubMerkleTree]
    FUTURE_1: _ClassVar[SubMerkleTree]
    FUTURE_2: _ClassVar[SubMerkleTree]
    FUTURE_3: _ClassVar[SubMerkleTree]
    FUTURE_4: _ClassVar[SubMerkleTree]
    FUTURE_5: _ClassVar[SubMerkleTree]
    FUTURE_6: _ClassVar[SubMerkleTree]
    FUTURE_7: _ClassVar[SubMerkleTree]
    FUTURE_8: _ClassVar[SubMerkleTree]
ITEM_TYPE_UNSPECIFIED: SubMerkleTree
PREVIOUS_BLOCK_ROOT: SubMerkleTree
PREVIOUS_ROOTS_TREE: SubMerkleTree
PREVIOUS_BLOCK_START_STATE: SubMerkleTree
CONSENSUS_HEADER_ITEMS: SubMerkleTree
INPUT_ITEMS_TREE: SubMerkleTree
OUTPUT_ITEMS_TREE: SubMerkleTree
STATE_CHANGE_ITEMS_TREE: SubMerkleTree
TRACE_DATA_ITEMS_TREE: SubMerkleTree
FUTURE_1: SubMerkleTree
FUTURE_2: SubMerkleTree
FUTURE_3: SubMerkleTree
FUTURE_4: SubMerkleTree
FUTURE_5: SubMerkleTree
FUTURE_6: SubMerkleTree
FUTURE_7: SubMerkleTree
FUTURE_8: SubMerkleTree

class BlockItem(_message.Message):
    __slots__ = ("block_header", "event_header", "round_header", "signed_transaction", "transaction_result", "transaction_output", "state_changes", "filtered_single_item", "block_proof", "record_file", "trace_data", "block_footer", "redacted_item")
    BLOCK_HEADER_FIELD_NUMBER: _ClassVar[int]
    EVENT_HEADER_FIELD_NUMBER: _ClassVar[int]
    ROUND_HEADER_FIELD_NUMBER: _ClassVar[int]
    SIGNED_TRANSACTION_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_RESULT_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_OUTPUT_FIELD_NUMBER: _ClassVar[int]
    STATE_CHANGES_FIELD_NUMBER: _ClassVar[int]
    FILTERED_SINGLE_ITEM_FIELD_NUMBER: _ClassVar[int]
    BLOCK_PROOF_FIELD_NUMBER: _ClassVar[int]
    RECORD_FILE_FIELD_NUMBER: _ClassVar[int]
    TRACE_DATA_FIELD_NUMBER: _ClassVar[int]
    BLOCK_FOOTER_FIELD_NUMBER: _ClassVar[int]
    REDACTED_ITEM_FIELD_NUMBER: _ClassVar[int]
    block_header: _block_header_pb2.BlockHeader
    event_header: _event_metadata_pb2.EventHeader
    round_header: _round_header_pb2.RoundHeader
    signed_transaction: bytes
    transaction_result: _transaction_result_pb2.TransactionResult
    transaction_output: _transaction_output_pb2.TransactionOutput
    state_changes: _state_changes_pb2.StateChanges
    filtered_single_item: FilteredSingleItem
    block_proof: _block_proof_pb2.BlockProof
    record_file: _record_file_item_pb2.RecordFileItem
    trace_data: _trace_data_pb2.TraceData
    block_footer: _block_footer_pb2.BlockFooter
    redacted_item: RedactedItem
    def __init__(self, block_header: _Optional[_Union[_block_header_pb2.BlockHeader, _Mapping]] = ..., event_header: _Optional[_Union[_event_metadata_pb2.EventHeader, _Mapping]] = ..., round_header: _Optional[_Union[_round_header_pb2.RoundHeader, _Mapping]] = ..., signed_transaction: _Optional[bytes] = ..., transaction_result: _Optional[_Union[_transaction_result_pb2.TransactionResult, _Mapping]] = ..., transaction_output: _Optional[_Union[_transaction_output_pb2.TransactionOutput, _Mapping]] = ..., state_changes: _Optional[_Union[_state_changes_pb2.StateChanges, _Mapping]] = ..., filtered_single_item: _Optional[_Union[FilteredSingleItem, _Mapping]] = ..., block_proof: _Optional[_Union[_block_proof_pb2.BlockProof, _Mapping]] = ..., record_file: _Optional[_Union[_record_file_item_pb2.RecordFileItem, _Mapping]] = ..., trace_data: _Optional[_Union[_trace_data_pb2.TraceData, _Mapping]] = ..., block_footer: _Optional[_Union[_block_footer_pb2.BlockFooter, _Mapping]] = ..., redacted_item: _Optional[_Union[RedactedItem, _Mapping]] = ...) -> None: ...

class FilteredItemHash(_message.Message):
    __slots__ = ("item_hash", "filtered_path")
    ITEM_HASH_FIELD_NUMBER: _ClassVar[int]
    FILTERED_PATH_FIELD_NUMBER: _ClassVar[int]
    item_hash: bytes
    filtered_path: int
    def __init__(self, item_hash: _Optional[bytes] = ..., filtered_path: _Optional[int] = ...) -> None: ...

class FilteredSingleItem(_message.Message):
    __slots__ = ("item_hash", "tree")
    ITEM_HASH_FIELD_NUMBER: _ClassVar[int]
    TREE_FIELD_NUMBER: _ClassVar[int]
    item_hash: bytes
    tree: SubMerkleTree
    def __init__(self, item_hash: _Optional[bytes] = ..., tree: _Optional[_Union[SubMerkleTree, str]] = ...) -> None: ...

class FilteredMerkleSubTree(_message.Message):
    __slots__ = ("subtree_root_hash", "tree", "filtered_leaf_count")
    SUBTREE_ROOT_HASH_FIELD_NUMBER: _ClassVar[int]
    TREE_FIELD_NUMBER: _ClassVar[int]
    FILTERED_LEAF_COUNT_FIELD_NUMBER: _ClassVar[int]
    subtree_root_hash: bytes
    tree: SubMerkleTree
    filtered_leaf_count: int
    def __init__(self, subtree_root_hash: _Optional[bytes] = ..., tree: _Optional[_Union[SubMerkleTree, str]] = ..., filtered_leaf_count: _Optional[int] = ...) -> None: ...

class RedactedItem(_message.Message):
    __slots__ = ("item_hash", "signed_transaction_hash", "tree")
    ITEM_HASH_FIELD_NUMBER: _ClassVar[int]
    SIGNED_TRANSACTION_HASH_FIELD_NUMBER: _ClassVar[int]
    TREE_FIELD_NUMBER: _ClassVar[int]
    item_hash: bytes
    signed_transaction_hash: bytes
    tree: SubMerkleTree
    def __init__(self, item_hash: _Optional[bytes] = ..., signed_transaction_hash: _Optional[bytes] = ..., tree: _Optional[_Union[SubMerkleTree, str]] = ...) -> None: ...
