from ....block.stream.trace import smart_contract_service_pb2 as _smart_contract_service_pb2
from ....block.stream.trace import consensus_service_pb2 as _consensus_service_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TraceData(_message.Message):
    __slots__ = ("evm_trace_data", "submit_message_trace_data")
    EVM_TRACE_DATA_FIELD_NUMBER: _ClassVar[int]
    SUBMIT_MESSAGE_TRACE_DATA_FIELD_NUMBER: _ClassVar[int]
    evm_trace_data: _smart_contract_service_pb2.EvmTraceData
    submit_message_trace_data: _consensus_service_pb2.SubmitMessageTraceData
    def __init__(self, evm_trace_data: _Optional[_Union[_smart_contract_service_pb2.EvmTraceData, _Mapping]] = ..., submit_message_trace_data: _Optional[_Union[_consensus_service_pb2.SubmitMessageTraceData, _Mapping]] = ...) -> None: ...
