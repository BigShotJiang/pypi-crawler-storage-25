from ....services import basic_types_pb2 as _basic_types_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class CreateScheduleOutput(_message.Message):
    __slots__ = ("schedule_id", "scheduled_transaction_id")
    SCHEDULE_ID_FIELD_NUMBER: _ClassVar[int]
    SCHEDULED_TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    schedule_id: _basic_types_pb2.ScheduleID
    scheduled_transaction_id: _basic_types_pb2.TransactionID
    def __init__(self, schedule_id: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., scheduled_transaction_id: _Optional[_Union[_basic_types_pb2.TransactionID, _Mapping]] = ...) -> None: ...

class DeleteScheduleOutput(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SignScheduleOutput(_message.Message):
    __slots__ = ("scheduled_transaction_id",)
    SCHEDULED_TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    scheduled_transaction_id: _basic_types_pb2.TransactionID
    def __init__(self, scheduled_transaction_id: _Optional[_Union[_basic_types_pb2.TransactionID, _Mapping]] = ...) -> None: ...
