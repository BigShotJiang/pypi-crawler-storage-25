from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class RoundHeader(_message.Message):
    __slots__ = ("round_number",)
    ROUND_NUMBER_FIELD_NUMBER: _ClassVar[int]
    round_number: int
    def __init__(self, round_number: _Optional[int] = ...) -> None: ...
