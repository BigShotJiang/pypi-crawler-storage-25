from ...services import basic_types_pb2 as _basic_types_pb2
from ...services import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class EventCore(_message.Message):
    __slots__ = ("creator_node_id", "birth_round", "time_created", "coin")
    CREATOR_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    BIRTH_ROUND_FIELD_NUMBER: _ClassVar[int]
    TIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    COIN_FIELD_NUMBER: _ClassVar[int]
    creator_node_id: int
    birth_round: int
    time_created: _timestamp_pb2.Timestamp
    coin: int
    def __init__(self, creator_node_id: _Optional[int] = ..., birth_round: _Optional[int] = ..., time_created: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., coin: _Optional[int] = ...) -> None: ...
