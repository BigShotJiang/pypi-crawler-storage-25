from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GossipEventWindow(_message.Message):
    __slots__ = ("latestConsensusRound", "ancientThreshold", "expiredThreshold")
    LATESTCONSENSUSROUND_FIELD_NUMBER: _ClassVar[int]
    ANCIENTTHRESHOLD_FIELD_NUMBER: _ClassVar[int]
    EXPIREDTHRESHOLD_FIELD_NUMBER: _ClassVar[int]
    latestConsensusRound: int
    ancientThreshold: int
    expiredThreshold: int
    def __init__(self, latestConsensusRound: _Optional[int] = ..., ancientThreshold: _Optional[int] = ..., expiredThreshold: _Optional[int] = ...) -> None: ...

class GossipSyncData(_message.Message):
    __slots__ = ("window", "tips", "skipSendingEvents")
    WINDOW_FIELD_NUMBER: _ClassVar[int]
    TIPS_FIELD_NUMBER: _ClassVar[int]
    SKIPSENDINGEVENTS_FIELD_NUMBER: _ClassVar[int]
    window: GossipEventWindow
    tips: _containers.RepeatedScalarFieldContainer[bytes]
    skipSendingEvents: bool
    def __init__(self, window: _Optional[_Union[GossipEventWindow, _Mapping]] = ..., tips: _Optional[_Iterable[bytes]] = ..., skipSendingEvents: bool = ...) -> None: ...
