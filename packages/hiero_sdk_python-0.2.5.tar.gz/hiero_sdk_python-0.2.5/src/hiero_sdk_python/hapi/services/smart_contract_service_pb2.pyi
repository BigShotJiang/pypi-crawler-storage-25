from ..services import transaction_response_pb2 as _transaction_response_pb2
from ..services import query_pb2 as _query_pb2
from ..services import response_pb2 as _response_pb2
from ..services import transaction_pb2 as _transaction_pb2
from google.protobuf import descriptor as _descriptor
from typing import ClassVar as _ClassVar

DESCRIPTOR: _descriptor.FileDescriptor
