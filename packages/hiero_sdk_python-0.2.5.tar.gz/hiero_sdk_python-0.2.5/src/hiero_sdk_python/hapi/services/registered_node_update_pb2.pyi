from google.protobuf import wrappers_pb2 as _wrappers_pb2
from ..services import basic_types_pb2 as _basic_types_pb2
from ..services import registered_service_endpoint_pb2 as _registered_service_endpoint_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RegisteredNodeUpdateTransactionBody(_message.Message):
    __slots__ = ("registered_node_id", "admin_key", "description", "service_endpoint")
    REGISTERED_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    ADMIN_KEY_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SERVICE_ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    registered_node_id: int
    admin_key: _basic_types_pb2.Key
    description: _wrappers_pb2.StringValue
    service_endpoint: _containers.RepeatedCompositeFieldContainer[_registered_service_endpoint_pb2.RegisteredServiceEndpoint]
    def __init__(self, registered_node_id: _Optional[int] = ..., admin_key: _Optional[_Union[_basic_types_pb2.Key, _Mapping]] = ..., description: _Optional[_Union[_wrappers_pb2.StringValue, _Mapping]] = ..., service_endpoint: _Optional[_Iterable[_Union[_registered_service_endpoint_pb2.RegisteredServiceEndpoint, _Mapping]]] = ...) -> None: ...
