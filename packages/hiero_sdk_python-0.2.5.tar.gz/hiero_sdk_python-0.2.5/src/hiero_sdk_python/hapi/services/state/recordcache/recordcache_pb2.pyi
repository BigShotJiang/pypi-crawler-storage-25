from ....services import basic_types_pb2 as _basic_types_pb2
from ....services import transaction_record_pb2 as _transaction_record_pb2
from ....services import response_code_pb2 as _response_code_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TransactionRecordEntry(_message.Message):
    __slots__ = ("node_id", "payer_account_id", "transaction_record")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    PAYER_ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_RECORD_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    payer_account_id: _basic_types_pb2.AccountID
    transaction_record: _transaction_record_pb2.TransactionRecord
    def __init__(self, node_id: _Optional[int] = ..., payer_account_id: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., transaction_record: _Optional[_Union[_transaction_record_pb2.TransactionRecord, _Mapping]] = ...) -> None: ...

class TransactionReceiptEntry(_message.Message):
    __slots__ = ("node_id", "transaction_id", "status")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    TRANSACTION_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    transaction_id: _basic_types_pb2.TransactionID
    status: _response_code_pb2.ResponseCodeEnum
    def __init__(self, node_id: _Optional[int] = ..., transaction_id: _Optional[_Union[_basic_types_pb2.TransactionID, _Mapping]] = ..., status: _Optional[_Union[_response_code_pb2.ResponseCodeEnum, str]] = ...) -> None: ...

class TransactionReceiptEntries(_message.Message):
    __slots__ = ("entries",)
    ENTRIES_FIELD_NUMBER: _ClassVar[int]
    entries: _containers.RepeatedCompositeFieldContainer[TransactionReceiptEntry]
    def __init__(self, entries: _Optional[_Iterable[_Union[TransactionReceiptEntry, _Mapping]]] = ...) -> None: ...
