from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RosterState(_message.Message):
    __slots__ = ("candidate_roster_hash", "round_roster_pairs", "transplant_in_progress")
    CANDIDATE_ROSTER_HASH_FIELD_NUMBER: _ClassVar[int]
    ROUND_ROSTER_PAIRS_FIELD_NUMBER: _ClassVar[int]
    TRANSPLANT_IN_PROGRESS_FIELD_NUMBER: _ClassVar[int]
    candidate_roster_hash: bytes
    round_roster_pairs: _containers.RepeatedCompositeFieldContainer[RoundRosterPair]
    transplant_in_progress: bool
    def __init__(self, candidate_roster_hash: _Optional[bytes] = ..., round_roster_pairs: _Optional[_Iterable[_Union[RoundRosterPair, _Mapping]]] = ..., transplant_in_progress: bool = ...) -> None: ...

class RoundRosterPair(_message.Message):
    __slots__ = ("round_number", "active_roster_hash")
    ROUND_NUMBER_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_ROSTER_HASH_FIELD_NUMBER: _ClassVar[int]
    round_number: int
    active_roster_hash: bytes
    def __init__(self, round_number: _Optional[int] = ..., active_roster_hash: _Optional[bytes] = ...) -> None: ...
