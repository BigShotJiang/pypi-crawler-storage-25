from ....services import basic_types_pb2 as _basic_types_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Roster(_message.Message):
    __slots__ = ("roster_entries",)
    ROSTER_ENTRIES_FIELD_NUMBER: _ClassVar[int]
    roster_entries: _containers.RepeatedCompositeFieldContainer[RosterEntry]
    def __init__(self, roster_entries: _Optional[_Iterable[_Union[RosterEntry, _Mapping]]] = ...) -> None: ...

class RosterEntry(_message.Message):
    __slots__ = ("node_id", "weight", "gossip_ca_certificate", "gossip_endpoint")
    NODE_ID_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    GOSSIP_CA_CERTIFICATE_FIELD_NUMBER: _ClassVar[int]
    GOSSIP_ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    node_id: int
    weight: int
    gossip_ca_certificate: bytes
    gossip_endpoint: _containers.RepeatedCompositeFieldContainer[_basic_types_pb2.ServiceEndpoint]
    def __init__(self, node_id: _Optional[int] = ..., weight: _Optional[int] = ..., gossip_ca_certificate: _Optional[bytes] = ..., gossip_endpoint: _Optional[_Iterable[_Union[_basic_types_pb2.ServiceEndpoint, _Mapping]]] = ...) -> None: ...
