from ....services import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BlockInfo(_message.Message):
    __slots__ = ("last_block_number", "first_cons_time_of_last_block", "block_hashes", "cons_time_of_last_handled_txn", "migration_records_streamed", "first_cons_time_of_current_block", "last_used_cons_time", "last_interval_process_time")
    LAST_BLOCK_NUMBER_FIELD_NUMBER: _ClassVar[int]
    FIRST_CONS_TIME_OF_LAST_BLOCK_FIELD_NUMBER: _ClassVar[int]
    BLOCK_HASHES_FIELD_NUMBER: _ClassVar[int]
    CONS_TIME_OF_LAST_HANDLED_TXN_FIELD_NUMBER: _ClassVar[int]
    MIGRATION_RECORDS_STREAMED_FIELD_NUMBER: _ClassVar[int]
    FIRST_CONS_TIME_OF_CURRENT_BLOCK_FIELD_NUMBER: _ClassVar[int]
    LAST_USED_CONS_TIME_FIELD_NUMBER: _ClassVar[int]
    LAST_INTERVAL_PROCESS_TIME_FIELD_NUMBER: _ClassVar[int]
    last_block_number: int
    first_cons_time_of_last_block: _timestamp_pb2.Timestamp
    block_hashes: bytes
    cons_time_of_last_handled_txn: _timestamp_pb2.Timestamp
    migration_records_streamed: bool
    first_cons_time_of_current_block: _timestamp_pb2.Timestamp
    last_used_cons_time: _timestamp_pb2.Timestamp
    last_interval_process_time: _timestamp_pb2.Timestamp
    def __init__(self, last_block_number: _Optional[int] = ..., first_cons_time_of_last_block: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., block_hashes: _Optional[bytes] = ..., cons_time_of_last_handled_txn: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., migration_records_streamed: bool = ..., first_cons_time_of_current_block: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., last_used_cons_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., last_interval_process_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...
