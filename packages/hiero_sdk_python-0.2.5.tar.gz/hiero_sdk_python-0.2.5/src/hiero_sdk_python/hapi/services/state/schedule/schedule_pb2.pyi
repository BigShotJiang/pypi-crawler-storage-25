from ....services import basic_types_pb2 as _basic_types_pb2
from ....services import timestamp_pb2 as _timestamp_pb2
from ....services import schedulable_transaction_body_pb2 as _schedulable_transaction_body_pb2
from ....services import transaction_pb2 as _transaction_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Schedule(_message.Message):
    __slots__ = ("schedule_id", "deleted", "executed", "wait_for_expiry", "memo", "scheduler_account_id", "payer_account_id", "admin_key", "schedule_valid_start", "provided_expiration_second", "calculated_expiration_second", "resolution_time", "scheduled_transaction", "original_create_transaction", "signatories")
    SCHEDULE_ID_FIELD_NUMBER: _ClassVar[int]
    DELETED_FIELD_NUMBER: _ClassVar[int]
    EXECUTED_FIELD_NUMBER: _ClassVar[int]
    WAIT_FOR_EXPIRY_FIELD_NUMBER: _ClassVar[int]
    MEMO_FIELD_NUMBER: _ClassVar[int]
    SCHEDULER_ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    PAYER_ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    ADMIN_KEY_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_VALID_START_FIELD_NUMBER: _ClassVar[int]
    PROVIDED_EXPIRATION_SECOND_FIELD_NUMBER: _ClassVar[int]
    CALCULATED_EXPIRATION_SECOND_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_TIME_FIELD_NUMBER: _ClassVar[int]
    SCHEDULED_TRANSACTION_FIELD_NUMBER: _ClassVar[int]
    ORIGINAL_CREATE_TRANSACTION_FIELD_NUMBER: _ClassVar[int]
    SIGNATORIES_FIELD_NUMBER: _ClassVar[int]
    schedule_id: _basic_types_pb2.ScheduleID
    deleted: bool
    executed: bool
    wait_for_expiry: bool
    memo: str
    scheduler_account_id: _basic_types_pb2.AccountID
    payer_account_id: _basic_types_pb2.AccountID
    admin_key: _basic_types_pb2.Key
    schedule_valid_start: _timestamp_pb2.Timestamp
    provided_expiration_second: int
    calculated_expiration_second: int
    resolution_time: _timestamp_pb2.Timestamp
    scheduled_transaction: _schedulable_transaction_body_pb2.SchedulableTransactionBody
    original_create_transaction: _transaction_pb2.TransactionBody
    signatories: _containers.RepeatedCompositeFieldContainer[_basic_types_pb2.Key]
    def __init__(self, schedule_id: _Optional[_Union[_basic_types_pb2.ScheduleID, _Mapping]] = ..., deleted: bool = ..., executed: bool = ..., wait_for_expiry: bool = ..., memo: _Optional[str] = ..., scheduler_account_id: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., payer_account_id: _Optional[_Union[_basic_types_pb2.AccountID, _Mapping]] = ..., admin_key: _Optional[_Union[_basic_types_pb2.Key, _Mapping]] = ..., schedule_valid_start: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., provided_expiration_second: _Optional[int] = ..., calculated_expiration_second: _Optional[int] = ..., resolution_time: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., scheduled_transaction: _Optional[_Union[_schedulable_transaction_body_pb2.SchedulableTransactionBody, _Mapping]] = ..., original_create_transaction: _Optional[_Union[_transaction_pb2.TransactionBody, _Mapping]] = ..., signatories: _Optional[_Iterable[_Union[_basic_types_pb2.Key, _Mapping]]] = ...) -> None: ...

class ScheduleList(_message.Message):
    __slots__ = ("schedules",)
    SCHEDULES_FIELD_NUMBER: _ClassVar[int]
    schedules: _containers.RepeatedCompositeFieldContainer[Schedule]
    def __init__(self, schedules: _Optional[_Iterable[_Union[Schedule, _Mapping]]] = ...) -> None: ...

class ScheduleIdList(_message.Message):
    __slots__ = ("schedule_ids",)
    SCHEDULE_IDS_FIELD_NUMBER: _ClassVar[int]
    schedule_ids: _containers.RepeatedCompositeFieldContainer[_basic_types_pb2.ScheduleID]
    def __init__(self, schedule_ids: _Optional[_Iterable[_Union[_basic_types_pb2.ScheduleID, _Mapping]]] = ...) -> None: ...

class ScheduledCounts(_message.Message):
    __slots__ = ("number_scheduled", "number_processed")
    NUMBER_SCHEDULED_FIELD_NUMBER: _ClassVar[int]
    NUMBER_PROCESSED_FIELD_NUMBER: _ClassVar[int]
    number_scheduled: int
    number_processed: int
    def __init__(self, number_scheduled: _Optional[int] = ..., number_processed: _Optional[int] = ...) -> None: ...

class ScheduledOrder(_message.Message):
    __slots__ = ("expiry_second", "order_number")
    EXPIRY_SECOND_FIELD_NUMBER: _ClassVar[int]
    ORDER_NUMBER_FIELD_NUMBER: _ClassVar[int]
    expiry_second: int
    order_number: int
    def __init__(self, expiry_second: _Optional[int] = ..., order_number: _Optional[int] = ...) -> None: ...
