from ....services import basic_types_pb2 as _basic_types_pb2
from ....services import hook_types_pb2 as _hook_types_pb2
from google.protobuf import wrappers_pb2 as _wrappers_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class HookType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EVM_HOOK: _ClassVar[HookType]
EVM_HOOK: HookType

class EvmHookState(_message.Message):
    __slots__ = ("hook_id", "type", "extension_point", "hook_contract_id", "admin_key", "first_contract_storage_key", "previous_hook_id", "next_hook_id", "num_storage_slots")
    HOOK_ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    EXTENSION_POINT_FIELD_NUMBER: _ClassVar[int]
    HOOK_CONTRACT_ID_FIELD_NUMBER: _ClassVar[int]
    ADMIN_KEY_FIELD_NUMBER: _ClassVar[int]
    FIRST_CONTRACT_STORAGE_KEY_FIELD_NUMBER: _ClassVar[int]
    PREVIOUS_HOOK_ID_FIELD_NUMBER: _ClassVar[int]
    NEXT_HOOK_ID_FIELD_NUMBER: _ClassVar[int]
    NUM_STORAGE_SLOTS_FIELD_NUMBER: _ClassVar[int]
    hook_id: _basic_types_pb2.HookId
    type: HookType
    extension_point: _hook_types_pb2.HookExtensionPoint
    hook_contract_id: _basic_types_pb2.ContractID
    admin_key: _basic_types_pb2.Key
    first_contract_storage_key: bytes
    previous_hook_id: _wrappers_pb2.Int64Value
    next_hook_id: _wrappers_pb2.Int64Value
    num_storage_slots: int
    def __init__(self, hook_id: _Optional[_Union[_basic_types_pb2.HookId, _Mapping]] = ..., type: _Optional[_Union[HookType, str]] = ..., extension_point: _Optional[_Union[_hook_types_pb2.HookExtensionPoint, str]] = ..., hook_contract_id: _Optional[_Union[_basic_types_pb2.ContractID, _Mapping]] = ..., admin_key: _Optional[_Union[_basic_types_pb2.Key, _Mapping]] = ..., first_contract_storage_key: _Optional[bytes] = ..., previous_hook_id: _Optional[_Union[_wrappers_pb2.Int64Value, _Mapping]] = ..., next_hook_id: _Optional[_Union[_wrappers_pb2.Int64Value, _Mapping]] = ..., num_storage_slots: _Optional[int] = ...) -> None: ...

class EvmHookSlotKey(_message.Message):
    __slots__ = ("hook_id", "key")
    HOOK_ID_FIELD_NUMBER: _ClassVar[int]
    KEY_FIELD_NUMBER: _ClassVar[int]
    hook_id: _basic_types_pb2.HookId
    key: bytes
    def __init__(self, hook_id: _Optional[_Union[_basic_types_pb2.HookId, _Mapping]] = ..., key: _Optional[bytes] = ...) -> None: ...
