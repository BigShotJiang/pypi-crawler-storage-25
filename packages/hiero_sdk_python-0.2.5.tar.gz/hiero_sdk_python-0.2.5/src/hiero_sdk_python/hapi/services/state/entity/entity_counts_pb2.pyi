from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class EntityCounts(_message.Message):
    __slots__ = ("num_accounts", "num_aliases", "num_tokens", "num_token_relations", "num_nfts", "num_airdrops", "num_staking_infos", "num_topics", "num_files", "num_nodes", "num_schedules", "num_contract_storage_slots", "num_contract_bytecodes", "num_hooks", "num_evm_hook_storage_slots")
    NUM_ACCOUNTS_FIELD_NUMBER: _ClassVar[int]
    NUM_ALIASES_FIELD_NUMBER: _ClassVar[int]
    NUM_TOKENS_FIELD_NUMBER: _ClassVar[int]
    NUM_TOKEN_RELATIONS_FIELD_NUMBER: _ClassVar[int]
    NUM_NFTS_FIELD_NUMBER: _ClassVar[int]
    NUM_AIRDROPS_FIELD_NUMBER: _ClassVar[int]
    NUM_STAKING_INFOS_FIELD_NUMBER: _ClassVar[int]
    NUM_TOPICS_FIELD_NUMBER: _ClassVar[int]
    NUM_FILES_FIELD_NUMBER: _ClassVar[int]
    NUM_NODES_FIELD_NUMBER: _ClassVar[int]
    NUM_SCHEDULES_FIELD_NUMBER: _ClassVar[int]
    NUM_CONTRACT_STORAGE_SLOTS_FIELD_NUMBER: _ClassVar[int]
    NUM_CONTRACT_BYTECODES_FIELD_NUMBER: _ClassVar[int]
    NUM_HOOKS_FIELD_NUMBER: _ClassVar[int]
    NUM_EVM_HOOK_STORAGE_SLOTS_FIELD_NUMBER: _ClassVar[int]
    num_accounts: int
    num_aliases: int
    num_tokens: int
    num_token_relations: int
    num_nfts: int
    num_airdrops: int
    num_staking_infos: int
    num_topics: int
    num_files: int
    num_nodes: int
    num_schedules: int
    num_contract_storage_slots: int
    num_contract_bytecodes: int
    num_hooks: int
    num_evm_hook_storage_slots: int
    def __init__(self, num_accounts: _Optional[int] = ..., num_aliases: _Optional[int] = ..., num_tokens: _Optional[int] = ..., num_token_relations: _Optional[int] = ..., num_nfts: _Optional[int] = ..., num_airdrops: _Optional[int] = ..., num_staking_infos: _Optional[int] = ..., num_topics: _Optional[int] = ..., num_files: _Optional[int] = ..., num_nodes: _Optional[int] = ..., num_schedules: _Optional[int] = ..., num_contract_storage_slots: _Optional[int] = ..., num_contract_bytecodes: _Optional[int] = ..., num_hooks: _Optional[int] = ..., num_evm_hook_storage_slots: _Optional[int] = ...) -> None: ...
