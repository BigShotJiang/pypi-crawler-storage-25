from ....services.state.history import history_types_pb2 as _history_types_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class HistoryProofKeyPublicationTransactionBody(_message.Message):
    __slots__ = ("proof_key", "wraps_message", "construction_id", "phase")
    PROOF_KEY_FIELD_NUMBER: _ClassVar[int]
    WRAPS_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    CONSTRUCTION_ID_FIELD_NUMBER: _ClassVar[int]
    PHASE_FIELD_NUMBER: _ClassVar[int]
    proof_key: bytes
    wraps_message: bytes
    construction_id: int
    phase: _history_types_pb2.WrapsPhase
    def __init__(self, proof_key: _Optional[bytes] = ..., wraps_message: _Optional[bytes] = ..., construction_id: _Optional[int] = ..., phase: _Optional[_Union[_history_types_pb2.WrapsPhase, str]] = ...) -> None: ...
