from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class RegisteredServiceEndpoint(_message.Message):
    __slots__ = ("ip_address", "domain_name", "port", "requires_tls", "block_node", "mirror_node", "rpc_relay")
    class BlockNodeEndpoint(_message.Message):
        __slots__ = ("endpoint_api",)
        class BlockNodeApi(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            OTHER: _ClassVar[RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi]
            STATUS: _ClassVar[RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi]
            PUBLISH: _ClassVar[RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi]
            SUBSCRIBE_STREAM: _ClassVar[RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi]
            STATE_PROOF: _ClassVar[RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi]
        OTHER: RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi
        STATUS: RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi
        PUBLISH: RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi
        SUBSCRIBE_STREAM: RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi
        STATE_PROOF: RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi
        ENDPOINT_API_FIELD_NUMBER: _ClassVar[int]
        endpoint_api: RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi
        def __init__(self, endpoint_api: _Optional[_Union[RegisteredServiceEndpoint.BlockNodeEndpoint.BlockNodeApi, str]] = ...) -> None: ...
    class MirrorNodeEndpoint(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    class RpcRelayEndpoint(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    IP_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    DOMAIN_NAME_FIELD_NUMBER: _ClassVar[int]
    PORT_FIELD_NUMBER: _ClassVar[int]
    REQUIRES_TLS_FIELD_NUMBER: _ClassVar[int]
    BLOCK_NODE_FIELD_NUMBER: _ClassVar[int]
    MIRROR_NODE_FIELD_NUMBER: _ClassVar[int]
    RPC_RELAY_FIELD_NUMBER: _ClassVar[int]
    ip_address: bytes
    domain_name: str
    port: int
    requires_tls: bool
    block_node: RegisteredServiceEndpoint.BlockNodeEndpoint
    mirror_node: RegisteredServiceEndpoint.MirrorNodeEndpoint
    rpc_relay: RegisteredServiceEndpoint.RpcRelayEndpoint
    def __init__(self, ip_address: _Optional[bytes] = ..., domain_name: _Optional[str] = ..., port: _Optional[int] = ..., requires_tls: bool = ..., block_node: _Optional[_Union[RegisteredServiceEndpoint.BlockNodeEndpoint, _Mapping]] = ..., mirror_node: _Optional[_Union[RegisteredServiceEndpoint.MirrorNodeEndpoint, _Mapping]] = ..., rpc_relay: _Optional[_Union[RegisteredServiceEndpoint.RpcRelayEndpoint, _Mapping]] = ...) -> None: ...
