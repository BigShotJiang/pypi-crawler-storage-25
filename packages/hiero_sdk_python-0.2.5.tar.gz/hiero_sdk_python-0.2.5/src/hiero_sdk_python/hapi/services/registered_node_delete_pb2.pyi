from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class RegisteredNodeDeleteTransactionBody(_message.Message):
    __slots__ = ("registered_node_id",)
    REGISTERED_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    registered_node_id: int
    def __init__(self, registered_node_id: _Optional[int] = ...) -> None: ...
