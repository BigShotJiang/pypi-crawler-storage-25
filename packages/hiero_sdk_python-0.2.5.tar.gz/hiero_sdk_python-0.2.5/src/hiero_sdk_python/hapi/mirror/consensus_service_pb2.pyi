from ..services import basic_types_pb2 as _basic_types_pb2
from ..services import timestamp_pb2 as _timestamp_pb2
from ..services import consensus_submit_message_pb2 as _consensus_submit_message_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConsensusTopicQuery(_message.Message):
    __slots__ = ("topicID", "consensusStartTime", "consensusEndTime", "limit")
    TOPICID_FIELD_NUMBER: _ClassVar[int]
    CONSENSUSSTARTTIME_FIELD_NUMBER: _ClassVar[int]
    CONSENSUSENDTIME_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    topicID: _basic_types_pb2.TopicID
    consensusStartTime: _timestamp_pb2.Timestamp
    consensusEndTime: _timestamp_pb2.Timestamp
    limit: int
    def __init__(self, topicID: _Optional[_Union[_basic_types_pb2.TopicID, _Mapping]] = ..., consensusStartTime: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., consensusEndTime: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., limit: _Optional[int] = ...) -> None: ...

class ConsensusTopicResponse(_message.Message):
    __slots__ = ("consensusTimestamp", "message", "runningHash", "sequenceNumber", "runningHashVersion", "chunkInfo")
    CONSENSUSTIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    RUNNINGHASH_FIELD_NUMBER: _ClassVar[int]
    SEQUENCENUMBER_FIELD_NUMBER: _ClassVar[int]
    RUNNINGHASHVERSION_FIELD_NUMBER: _ClassVar[int]
    CHUNKINFO_FIELD_NUMBER: _ClassVar[int]
    consensusTimestamp: _timestamp_pb2.Timestamp
    message: bytes
    runningHash: bytes
    sequenceNumber: int
    runningHashVersion: int
    chunkInfo: _consensus_submit_message_pb2.ConsensusMessageChunkInfo
    def __init__(self, consensusTimestamp: _Optional[_Union[_timestamp_pb2.Timestamp, _Mapping]] = ..., message: _Optional[bytes] = ..., runningHash: _Optional[bytes] = ..., sequenceNumber: _Optional[int] = ..., runningHashVersion: _Optional[int] = ..., chunkInfo: _Optional[_Union[_consensus_submit_message_pb2.ConsensusMessageChunkInfo, _Mapping]] = ...) -> None: ...
