from ..services import basic_types_pb2 as _basic_types_pb2
from ..services import timestamp_pb2 as _timestamp_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AddressBookQuery(_message.Message):
    __slots__ = ("file_id", "limit")
    FILE_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    file_id: _basic_types_pb2.FileID
    limit: int
    def __init__(self, file_id: _Optional[_Union[_basic_types_pb2.FileID, _Mapping]] = ..., limit: _Optional[int] = ...) -> None: ...
