import os
import asyncio
import logging
from typing import Dict, Any, Optional, Iterator, AsyncIterator, List, Type, Set
from ..entry.http import BaseHttpClient
from ..utils.exceptions import (
    ModelNotSupportedError,
    MissingParameterError,
    ModelAPIError,
    AuthenticationError,
    ContentFilteredError,
    ModelBusinessError,
    TimeoutError as CNLLMTimeoutError,
    NetworkError,
    RateLimitError,
    InvalidRequestError,
    ServerError,
    InvalidURLError
)
from ..utils.stream import StreamHandler, AsyncStreamHandler
from .accumulators.single_accumulator import NonStreamAccumulator, StreamAccumulator
from ..utils.validator import ParamValidator
from .param_registry import validate_for_scope, resolve_default

logger = logging.getLogger(__name__)

_ADAPTER_REGISTRY: Dict[str, Type] = {}


class BaseAdapter:
    ADAPTER_NAME: str = ""
    CONFIG_DIR: str = ""

    _class_config: Dict[str, Any] = None
    _supported_models: list = []
    _model_params: Dict[str, set] = {}

    @classmethod
    def _register(cls):
        _ADAPTER_REGISTRY[cls.ADAPTER_NAME] = cls

    @classmethod
    def get_supported_models(cls) -> list:
        cls._load_class_config()
        return cls._supported_models

    @classmethod
    def get_adapter_name_for_model(cls, model: str) -> Optional[str]:
        for adapter_name, adapter_class in _ADAPTER_REGISTRY.items():
            if model in adapter_class.get_supported_models():
                return adapter_name
        for adapter_name, adapter_class in _ADAPTER_REGISTRY.items():
            config = adapter_class._load_class_config()
            mapping = config.get("model_mapping", {})
            if isinstance(mapping, dict):
                if "chat" in mapping:
                    mapping = mapping["chat"]
            if isinstance(mapping, dict):
                for short_name, vendor_name in mapping.items():
                    actual_name = vendor_name if isinstance(vendor_name, str) else vendor_name.get("model") if isinstance(vendor_name, dict) else None
                    if actual_name == model:
                        return adapter_name
        return None

    @classmethod
    def get_adapter_class(cls, adapter_name: str):
        return _ADAPTER_REGISTRY.get(adapter_name)

    @classmethod
    def get_all_adapter_names(cls) -> list:
        return list(_ADAPTER_REGISTRY.keys())

    def __init__(
        self,
        api_key: str,
        model: str,
        timeout: int = None,
        max_retries: int = None,
        retry_delay: float = None,
        base_url: str = None,
        fallback_models: Optional[Dict[str, Optional[str]]] = None,
        drop_params: str = "warn",
        protocol: str = None,
        **kwargs
    ):
        self.api_key = api_key
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.fallback_models = fallback_models or {}
        self.drop_params = drop_params
        self.protocol = protocol
        self._raw_response = None
        self._cnllm_extra = {}
        self._last_adapter = None
        self._config = self._load_config()
        self._validator = ParamValidator(self.CONFIG_DIR, adapter_type="chat")
        self.base_url = self._validator.validate_base_url(base_url, protocol=self.protocol)
        if self.timeout is None:
            self.timeout = resolve_default("chat", "timeout") or 30
        if self.max_retries is None:
            self.max_retries = resolve_default("chat", "max_retries") or 3
        if self.retry_delay is None:
            self.retry_delay = resolve_default("chat", "retry_delay") or 1.0

    @classmethod
    def _load_class_config(cls) -> Dict[str, Any]:
        if cls._class_config is not None:
            return cls._class_config

        config_path = os.path.join(
            os.path.dirname(__file__),
            "..", "..", "configs", cls.CONFIG_DIR, f"request_{cls.ADAPTER_NAME}.yaml"
        )
        try:
            import yaml
            with open(config_path, 'r', encoding='utf-8') as f:
                cls._class_config = yaml.safe_load(f) or {}
                mapping = cls._class_config.get("model_mapping", {})
                if isinstance(mapping, dict):
                    if "chat" in mapping:
                        mapping = mapping["chat"]
                cls._supported_models = list(mapping.keys()) if mapping else []
                return cls._class_config
        except FileNotFoundError:
            logger.warning(f"Config file not found: {config_path}, using empty config")
            cls._class_config = {}
            cls._supported_models = []
            return {}
        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            cls._class_config = {}
            cls._supported_models = []
            return {}

    def _load_config(self) -> Dict[str, Any]:
        return self._load_class_config()

    def _get_optional_fields(self) -> Dict[str, Any]:
        fields = self._config.get("optional_fields", {})
        if not isinstance(fields, dict):
            return {}
        protocol = getattr(self, 'protocol', None)
        if not protocol:
            return fields
        result = {}
        for key, config in fields.items():
            if isinstance(config, dict):
                fp = config.get("protocol")
                if fp and fp != protocol:
                    continue
            result[key] = config
        return result

    def _get_protocol_excluded_params(self) -> Set[str]:
        """返回因 protocol 不匹配而被排除的可选参数集合，用于 validate_for_scope 的 A.6 过滤"""
        fields = self._config.get("optional_fields", {})
        if not isinstance(fields, dict):
            return set()
        protocol = getattr(self, 'protocol', None)
        if not protocol:
            return set()
        excluded = set()
        for key, config in fields.items():
            if isinstance(config, dict):
                fp = config.get("protocol")
                if fp and fp != protocol:
                    excluded.add(key)
        return excluded

    def _get_config_value(self, *keys, default=None):
        value = self._config
        for key in keys:
            if isinstance(value, dict):
                value = value.get(key)
            else:
                return default
            if value is None:
                return default
        return value if value is not None else default

    def _validate_one_of(self, params: Dict[str, Any]) -> None:
        self._validator.validate_one_of(params)

    def get_vendor_model(self, model: str) -> str:
        mapping = self._get_config_value("model_mapping", default={})
        if isinstance(mapping, dict):
            if "chat" in mapping:
                mapping = mapping["chat"]
        entry = mapping.get(model, model)
        if isinstance(entry, dict):
            return entry.get("model", model)
        return entry

    def get_api_path(self) -> str:
        """获取 API 路径，根据 protocol 或 adapter_type 选择层级的 path"""
        return self._validator.get_api_path(protocol=self.protocol)

    def get_yaml_base_url_default(self) -> str:
        """读取 YAML 中 base_url 的 default 值（未经 validate_base_url 处理）。

        给 BaseHttpClient._build_url 规则5使用，判断用户 URL 是否需要补全。
        """
        base_url_config = self._get_config_value("optional_fields", "base_url", default={})
        if not isinstance(base_url_config, dict):
            return ""
        protocol = getattr(self, 'protocol', None)
        if protocol and protocol in base_url_config:
            pcfg = base_url_config[protocol]
            if isinstance(pcfg, dict):
                return pcfg.get("default", "")
        type_config = base_url_config.get(self._validator.adapter_type, {})
        if isinstance(type_config, dict):
            return type_config.get("default", "")
        return ""

    def get_header_mappings(self) -> Dict[str, str]:
        mappings = {}
        sections = ["required_fields", "optional_fields", "one_of"]
        for section in sections:
            fields = self._get_config_value(section, default={})
            if isinstance(fields, dict):
                if section == "one_of":
                    for group_fields in fields.values():
                        if isinstance(group_fields, dict):
                            self._process_header_mappings(group_fields, mappings)
                        elif isinstance(group_fields, list):
                            for f in group_fields:
                                if isinstance(f, str):
                                    mappings[f] = f
                else:
                    self._process_header_mappings(fields, mappings)
        return mappings

    def _process_header_mappings(self, fields: Dict, mappings: Dict) -> None:
        for field_name, field_config in fields.items():
            if isinstance(field_config, dict) and field_config.get("skip"):
                if field_config.get("head"):
                    mappings[field_name] = field_config["head"]
                else:
                    mappings[field_name] = field_name

    def _get_skip_fields(self) -> set:
        """获取所有声明了 skip: true 的字段名（来自 required_fields / optional_fields / one_of）"""
        skip_fields = set()
        for section in ["required_fields"]:
            fields = self._get_config_value(section, default={})
            if isinstance(fields, dict):
                for field_name, field_config in fields.items():
                    if isinstance(field_config, dict) and field_config.get("skip"):
                        skip_fields.add(field_name)
        fields = self._get_optional_fields()
        if isinstance(fields, dict):
            for field_name, field_config in fields.items():
                if isinstance(field_config, dict) and field_config.get("skip"):
                    skip_fields.add(field_name)
        one_of = self._get_config_value("one_of", default={})
        if isinstance(one_of, dict):
            for group in one_of.values():
                if isinstance(group, dict):
                    for field_name, field_config in group.items():
                        if isinstance(field_config, dict) and field_config.get("skip"):
                            skip_fields.add(field_name)
        return skip_fields

    def _filter_model_params(self, params: Dict[str, Any], model: str) -> Dict[str, Any]:
        """从 params 中移除当前模型不支持的参数（黑名单语义）"""
        if not self._model_params or model not in self._model_params:
            return params
        unsupported = self._model_params[model]
        filtered = dict(params)
        for key in unsupported:
            if key in filtered:
                msg = f"参数 {key!r} 不被模型 {model!r} 支持，已忽略"
                if self.drop_params == "strict":
                    from ..utils.exceptions import InvalidRequestError
                    raise InvalidRequestError(
                        message=f"{msg}。可设置 drop_params='warn' 警告并忽略，或 drop_params='ignore' 静默忽略",
                        provider=self.ADAPTER_NAME
                    )
                elif self.drop_params == "warn":
                    logger.warning(msg)
                del filtered[key]
        return filtered

    def _build_payload(self, params: Dict[str, Any]) -> Dict[str, Any]:
        model = params.get("model") or self.model
        params = self._filter_model_params(params, model)
        vendor_model = self.get_vendor_model(model)

        payload = {
            "model": vendor_model,
        }

        skip_fields = self._get_skip_fields()
        optional_fields = self._get_optional_fields()

        for key, value in params.items():
            if key == "model":
                continue
            if value is None:
                continue
            if key in skip_fields:
                continue
            field_config = optional_fields.get(key, key)
            if isinstance(field_config, dict):
                if field_config.get("skip"):
                    continue
                transform = field_config.get("transform")
                if transform and value in transform:
                    value = transform[value]
                mapped_key = field_config.get("map", key)
            else:
                if field_config == "__skip__":
                    continue
                mapped_key = field_config if field_config else key
            payload[mapped_key] = value

        return payload

    def create_completion(
        self,
        messages: List[Dict[str, str]] = None,
        prompt: str = None,
        model: str = None,
        temperature: float = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        if messages is None and prompt is not None:
            messages = [{"role": "user", "content": prompt}]

        if model is not None:
            self._validator.validate_model(model)
        else:
            model = self.model

        params = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
            **kwargs
        }

        protocol_vendor_yaml = dict(self._config or {})
        proto_fields = self._get_optional_fields()
        if proto_fields:
            protocol_vendor_yaml["optional_fields"] = proto_fields
        protocol_excluded = self._get_protocol_excluded_params()
        params = validate_for_scope(
            params=params,
            scope="chat",
            vendor_yaml=protocol_vendor_yaml,
            drop_params=self.drop_params,
            protocol_excluded_params=protocol_excluded,
        )
        self._validate_one_of(params)

        payload = self._build_payload(params)

        api_path = self.get_api_path()
        client = BaseHttpClient(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
            retry_delay=self.retry_delay,
            provider=self.ADAPTER_NAME,
            header_mappings=self.get_header_mappings(),
            yaml_default=self.get_yaml_base_url_default(),
        )

        extra_headers = {}
        for user_key, header_key in self.get_header_mappings().items():
            if user_key in params and params[user_key]:
                extra_headers[header_key] = params[user_key]

        try:
            if stream:
                return self._handle_stream(client, api_path, payload, extra_headers)
            else:
                raw_resp = client.post(api_path, payload, extra_headers)
                self._check_response_error(raw_resp)

                responder = self._get_responder()
                accumulator = NonStreamAccumulator(raw_resp, self, responder)
                result = accumulator.process()

                return result
        except (AuthenticationError, ContentFilteredError, ModelBusinessError, CNLLMTimeoutError, NetworkError, RateLimitError, InvalidRequestError, ServerError, InvalidURLError):
            raise
        except Exception as e:
            error_msg = getattr(e, 'message', str(e))
            raise ModelAPIError(
                f"{self.ADAPTER_NAME} API 请求失败: {error_msg}",
                provider=self.ADAPTER_NAME
            )

    def _handle_stream(self, client: BaseHttpClient, api_path: str, payload: Dict[str, Any], extra_headers: Dict[str, str] = None) -> Iterator[Dict[str, Any]]:
        self._raw_response = {}
        self._cnllm_extra = {}
        chunks_iterator = StreamHandler.handle_stream(client, api_path, payload, extra_headers)
        first = next(chunks_iterator)
        from itertools import chain
        chunks_iterator = chain([first], chunks_iterator)
        accumulator = StreamAccumulator(chunks_iterator, self)
        return iter(accumulator)

    def _to_openai_format(self, raw: Dict[str, Any], model: str) -> Dict[str, Any]:
        raise NotImplementedError("子类必须实现 _to_openai_format")

    def _to_openai_stream_format(self, raw: Dict[str, Any], model: str = None) -> Dict[str, Any]:
        return self._do_to_openai_stream_format(raw, model or self.model)

    def _do_to_openai_stream_format(self, raw: Dict[str, Any], model: str) -> Dict[str, Any]:
        raise NotImplementedError("子类必须实现 _do_to_openai_stream_format")

    def _get_responder(self) -> Optional[Any]:
        return None

    def _check_response_error(self, raw_response: Dict[str, Any]) -> None:
        responder = self._get_responder()
        if responder:
            responder.check_error(raw_response, self.ADAPTER_NAME)

    def _accumulate_extra_fields(self, result: Dict[str, Any]) -> None:
        delta = result.get("choices", [{}])[0].get("delta", {}) if result.get("choices") else {}
        
        reasoning_content = result.get("_thinking") or delta.get("reasoning_content")
        if reasoning_content:
            if "_thinking" not in self._cnllm_extra:
                self._cnllm_extra["_thinking"] = ""
            self._cnllm_extra["_thinking"] += reasoning_content

        content = delta.get("content") or ""
        if content:
            if "_still" not in self._cnllm_extra:
                self._cnllm_extra["_still"] = ""
            self._cnllm_extra["_still"] += content

        tool_calls = delta.get("tool_calls")
        if tool_calls:
            if "_tools" not in self._cnllm_extra:
                self._cnllm_extra["_tools"] = {}
            tools_dict: Dict[int, Dict[str, Any]] = self._cnllm_extra["_tools"]
            for tc in tool_calls:
                idx = tc.get("index", len(tools_dict))
                if idx in tools_dict:
                    existing = tools_dict[idx]
                    for k, v in tc.items():
                        if k == "function" and isinstance(v, dict) and "function" in existing:
                            fn_existing = existing["function"]
                            for fk, fv in v.items():
                                if fk == "arguments" and "arguments" in fn_existing:
                                    fn_existing["arguments"] += fv
                                else:
                                    fn_existing[fk] = fv
                        else:
                            existing[k] = v
                else:
                    tools_dict[idx] = dict(tc)
        usage = result.get("usage")
        if usage:
            self._cnllm_extra["_usage"] = usage

    async def acreate_completion(
        self,
        messages: List[Dict[str, str]] = None,
        prompt: str = None,
        model: str = None,
        temperature: float = None,
        max_tokens: Optional[int] = None,
        stream: bool = False,
        **kwargs
    ) -> Dict[str, Any]:
        if messages is None and prompt is not None:
            messages = [{"role": "user", "content": prompt}]

        if model is not None:
            self._validator.validate_model(model)
        else:
            model = self.model

        params = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
            **kwargs
        }

        protocol_vendor_yaml = dict(self._config or {})
        proto_fields = self._get_optional_fields()
        if proto_fields:
            protocol_vendor_yaml["optional_fields"] = proto_fields
        protocol_excluded = self._get_protocol_excluded_params()
        params = validate_for_scope(
            params=params,
            scope="chat",
            vendor_yaml=protocol_vendor_yaml,
            drop_params=self.drop_params,
            protocol_excluded_params=protocol_excluded,
        )
        self._validate_one_of(params)

        payload = self._build_payload(params)

        api_path = self.get_api_path()
        client = BaseHttpClient(
            api_key=self.api_key,
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
            retry_delay=self.retry_delay,
            provider=self.ADAPTER_NAME,
            header_mappings=self.get_header_mappings(),
            yaml_default=self.get_yaml_base_url_default(),
        )

        extra_headers = {}
        for user_key, header_key in self.get_header_mappings().items():
            if user_key in params and params[user_key]:
                extra_headers[header_key] = params[user_key]

        try:
            if stream:
                return self._ahandle_stream(client, api_path, payload, extra_headers)
            else:
                raw_resp = await client.apost(api_path, payload, extra_headers)
                self._raw_response = raw_resp
                self._check_response_error(raw_resp)
                return raw_resp
        except (AuthenticationError, ContentFilteredError, ModelBusinessError, CNLLMTimeoutError, NetworkError, RateLimitError, InvalidRequestError, ServerError, InvalidURLError):
            raise
        except Exception as e:
            error_msg = getattr(e, 'message', str(e))
            raise ModelAPIError(
                f"{self.ADAPTER_NAME} API 请求失败: {error_msg}",
                provider=self.ADAPTER_NAME
            )

    async def _ahandle_stream(self, client: BaseHttpClient, api_path: str, payload: Dict[str, Any], extra_headers: Dict[str, str] = None) -> AsyncIterator[Dict[str, Any]]:
        if not self._cnllm_extra:
            self._cnllm_extra = {}
        ait = AsyncStreamHandler.ahandle_stream(client, api_path, payload, extra_headers)
        first = await ait.__anext__()
        yield first
        async for raw_chunk in ait:
            yield raw_chunk