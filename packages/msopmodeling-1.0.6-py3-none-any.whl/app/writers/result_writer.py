#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2025 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------
import json
import logging
import sys

from tilesim.api.operator_api.op_latency_predict import save_optimization_hints_csv

logger = logging.getLogger(__name__)


class ResultWriter:
    """统一管理预测结果的 JSON 输出与优化建议的 CSV 输出。"""

    def __init__(self, output_path: str | None):
        """
        Args:
            output_path: 结果 JSON 文件路径；为 None 时输出到 stdout。
        """
        self._output_path = output_path

    def write_results(self, results: dict) -> None:
        """将结果字典序列化为 JSON 写入文件或 stdout。

        Args:
            results: predict_batch 返回的结果字典。
        """
        output_str = json.dumps(results, indent=2, ensure_ascii=False)
        if self._output_path:
            with open(self._output_path, "w", encoding="utf-8") as f:
                f.write(output_str)
            logger.info("Results written to: %s", self._output_path)
        else:
            print(output_str)

    def write_hints(self, hints_map: dict) -> None:
        """将优化建议保存为 CSV 文件，每个 OP 一个文件。

        Args:
            hints_map: predict_batch 返回的优化建议字典。
        """
        for op_id, hints in hints_map.items():
            csv_path = f"optimization_hints_{op_id}.csv"
            save_optimization_hints_csv(hints, csv_path)
            logger.info("Optimization hints saved to: %s", csv_path)
