#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2025 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------
import argparse
import logging
import sys


class CliArgumentParser:
    """封装 CLI 参数解析与日志初始化。"""

    def parse(self) -> argparse.Namespace:
        """定义并解析命令行参数，返回 Namespace。"""
        parser = argparse.ArgumentParser(
            prog="msopmodeling",
            description="Ascend Operator Performance Modeling Tool",
        )
        parser.add_argument(
            "-i", "--input",
            required=True,
            help="Input configuration JSON file path",
        )
        parser.add_argument(
            "-o", "--output",
            default=None,
            help="Output result JSON file path, defaults to standard output",
        )
        parser.add_argument(
            "-s", "--soc-type",
            choices=["910B1", "910B4"],
            default="910B4",
            help="SoC type, default: 910B4",
        )
        parser.add_argument(
            "-v", "--verbose",
            action="store_true",
            help="Enable verbose debug logging",
        )
        return parser.parse_args()

    def setup_logging(self, verbose: bool) -> None:
        """初始化日志，verbose=True 时输出 DEBUG 级别。"""
        level = logging.DEBUG if verbose else logging.ERROR
        root_logger = logging.getLogger()
        root_logger.setLevel(logging.DEBUG)

        root_logger.handlers.clear()

        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)

        formatter = logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        console_handler.setFormatter(formatter)

        root_logger.addHandler(console_handler)
