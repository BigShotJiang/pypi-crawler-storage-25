#!/usr/bin/python3
# -*- coding: utf-8 -*-
# -------------------------------------------------------------------------
# This file is part of the MindStudio project.
# Copyright (c) 2025 Huawei Technologies Co.,Ltd.
#
# MindStudio is licensed under Mulan PSL v2.
# You can use this software according to the terms and conditions of the Mulan PSL v2.
# You may obtain a copy of Mulan PSL v2 at:
#
#          http://license.coscl.org.cn/MulanPSL2
#
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
# EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
# MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
# See the Mulan PSL v2 for more details.
# -------------------------------------------------------------------------
import json
import logging
import os
import sys

logger = logging.getLogger(__name__)

_SRC_DIR = os.path.dirname(os.path.abspath(__file__))
_ARC_CONFIG_DIR = os.path.join(_SRC_DIR, "tilesim", "core", "config", "arc_config")


def _setup_path() -> None:
    """将 tilesim 包目录加入 sys.path。

    tilesim 内部文件使用 "from api.xxx" / "from core.xxx" 的裸路径导入，
    需要将 tilesim 包目录本身加入 sys.path 才能解析这些导入。
    """
    tilesim_dir = os.path.join(_SRC_DIR, "tilesim")
    if tilesim_dir not in sys.path:
        sys.path.insert(0, tilesim_dir)


def run() -> int:
    """主运行逻辑，返回进程退出码（0=成功，非 0=失败）。"""
    _setup_path()

    # 延迟导入：app 子模块依赖 tilesim，须在 _setup_path() 之后导入
    from app.cli.argument_parser import CliArgumentParser
    from app.config.config_loader import ConfigLoader
    from app.writers.result_writer import ResultWriter
    from app.service.prediction_service import PredictionService

    cli = CliArgumentParser()
    args = cli.parse()
    cli.setup_logging(args.verbose)
    logger.debug("参数: %s", args)

    if not args.input:
        logger.error("请通过 -i 指定输入 JSON 文件路径")
        return 1

    loader = ConfigLoader(arc_config_dir=_ARC_CONFIG_DIR)
    try:
        configs = loader.load(args.input)
    except FileNotFoundError as e:
        logger.error(str(e))
        return 1
    except json.JSONDecodeError as e:
        logger.error("输入 JSON 解析失败: %s", e)
        return 1

    if args.soc_type:
        try:
            configs = loader.apply_soc_type(configs, args.soc_type)
            logger.info("soc-type=%s → accelerator 已覆盖", args.soc_type)
        except FileNotFoundError as e:
            logger.error("%s", e)
            return 1

    service = PredictionService()
    results, hints_map, failed_ids = service.predict_batch(configs)

    writer = ResultWriter(output_path=args.output)
    writer.write_results(results)
    writer.write_hints(hints_map)

    if failed_ids:
        logger.error("以下 OP 预测失败: %s", ", ".join(failed_ids))
        return 1

    return 0


def main() -> None:
    """whl 安装后的 CLI 入口点（msopmodeling 命令）。"""
    sys.exit(run())


if __name__ == "__main__":
    main()
