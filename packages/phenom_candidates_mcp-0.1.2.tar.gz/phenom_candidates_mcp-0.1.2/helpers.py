def build_candidate_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v2/candidates?candidateId={candidate_id}"


def build_experiences_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/experiences"


def build_educations_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/educations"


def build_skills_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/skills"


def build_awards_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/awards"


def build_certifications_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/certifications"


def build_address_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/address"


def build_recommendations_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/recommendations"


def build_additional_fields_url(api_base_url: str, candidate_id: str) -> str:
    return f"{api_base_url}/v1/candidates/{candidate_id}/additional-fields"


def format_api_error(status_code: int, message: str, endpoint: str) -> str:
    return f"HTTP {status_code} error from {endpoint}: {message}"
