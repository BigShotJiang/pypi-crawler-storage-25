import httpx

from config import Config
from errors import AuthenticationError, NotFoundError, PhenomApiError
from helpers import build_candidate_url, build_educations_url, build_experiences_url, build_skills_url, build_awards_url, build_certifications_url, build_address_url, build_recommendations_url, build_additional_fields_url
from token_manager import TokenManager


class PhenomClient:
    def __init__(
        self,
        token_manager: TokenManager,
        config: Config,
        http_client: httpx.AsyncClient | None = None,
    ):
        self._token_manager = token_manager
        self._config = config
        self._http_client = http_client or httpx.AsyncClient()

    async def get_candidate(self, candidate_id: str) -> dict:
        url = build_candidate_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_experiences(self, candidate_id: str) -> list:
        url = build_experiences_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_educations(self, candidate_id: str) -> list:
        url = build_educations_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_skills(self, candidate_id: str) -> list:
        url = build_skills_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_awards(self, candidate_id: str) -> list:
        url = build_awards_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_certifications(self, candidate_id: str) -> list:
        url = build_certifications_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_address(self, candidate_id: str) -> dict:
        url = build_address_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_recommendations(self, candidate_id: str) -> list:
        url = build_recommendations_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    async def get_candidate_additional_fields(self, candidate_id: str) -> dict:
        url = build_additional_fields_url(self._config.api_base_url, candidate_id)
        return await self._request_with_retry(
            url,
            headers_builder=self._auth_headers,
        )

    def _auth_headers(self, token: str) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {token}",
            "x-ph-userId": self._config.user_id,
        }

    async def _request_with_retry(
        self,
        url: str,
        headers_builder,
    ):
        token = await self._token_manager.get_token()
        response = await self._http_client.get(url, headers=headers_builder(token))

        if response.status_code == 401:
            self._token_manager.clear_token()
            token = await self._token_manager.refresh_token()
            response = await self._http_client.get(url, headers=headers_builder(token))

            if response.status_code == 401:
                raise AuthenticationError(
                    status_code=401,
                    message=response.text,
                    endpoint=url,
                )

        if response.status_code == 404:
            raise NotFoundError(
                status_code=404,
                message=response.text,
                endpoint=url,
            )

        if response.status_code >= 400:
            raise PhenomApiError(
                status_code=response.status_code,
                message=response.text,
                endpoint=url,
            )

        return response.json()
