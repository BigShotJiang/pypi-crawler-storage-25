import json
import sys
from typing import Any, Callable, Coroutine

from mcp.server.fastmcp import FastMCP

from config import load_config
from errors import AuthenticationError, NotFoundError, PhenomApiError
from token_manager import TokenManager
from phenom_client import PhenomClient

mcp_server = FastMCP(name="phenom-candidates-mcp")

token_manager: TokenManager | None = None
phenom_client: PhenomClient | None = None


async def _call_api(resource: str, fn: Callable[..., Coroutine[Any, Any, Any]], *args: Any) -> str:
    if phenom_client is None:
        return "Server not initialized"
    try:
        data = await fn(*args)
        return json.dumps(data)
    except NotFoundError as e:
        raise ValueError(f"{resource} not found: {e}") from e
    except AuthenticationError as e:
        raise ValueError(f"Authentication error: {e}") from e
    except PhenomApiError as e:
        raise ValueError(str(e)) from e
    except Exception as e:
        raise ValueError(f"Failed to get {resource}: {e}") from e


@mcp_server.tool(name="get-candidate", description="Retrieve a candidate's profile by their unique candidate ID")
async def get_candidate(candidate_id: str) -> str:
    return await _call_api("Candidate", phenom_client.get_candidate, candidate_id)


@mcp_server.tool(name="get-candidate-experiences", description="Retrieve a candidate's work experience history")
async def get_candidate_experiences(candidate_id: str) -> str:
    return await _call_api("Candidate experiences", phenom_client.get_candidate_experiences, candidate_id)


@mcp_server.tool(name="get-candidate-educations", description="Retrieve a candidate's education records")
async def get_candidate_educations(candidate_id: str) -> str:
    return await _call_api("Candidate educations", phenom_client.get_candidate_educations, candidate_id)


@mcp_server.tool(name="get-candidate-skills", description="Retrieve a candidate's skills list")
async def get_candidate_skills(candidate_id: str) -> str:
    return await _call_api("Candidate skills", phenom_client.get_candidate_skills, candidate_id)


@mcp_server.tool(name="get-candidate-awards", description="Retrieve a candidate's awards and honors")
async def get_candidate_awards(candidate_id: str) -> str:
    return await _call_api("Candidate awards", phenom_client.get_candidate_awards, candidate_id)


@mcp_server.tool(name="get-candidate-certifications", description="Retrieve a candidate's professional certifications")
async def get_candidate_certifications(candidate_id: str) -> str:
    return await _call_api("Candidate certifications", phenom_client.get_candidate_certifications, candidate_id)


@mcp_server.tool(name="get-candidate-address", description="Retrieve a candidate's address information")
async def get_candidate_address(candidate_id: str) -> str:
    return await _call_api("Candidate address", phenom_client.get_candidate_address, candidate_id)


@mcp_server.tool(name="get-candidate-recommendations", description="Retrieve recommendations received by a candidate")
async def get_candidate_recommendations(candidate_id: str) -> str:
    return await _call_api("Candidate recommendations", phenom_client.get_candidate_recommendations, candidate_id)


@mcp_server.tool(name="get-candidate-additional-fields", description="Retrieve a candidate's additional/custom fields")
async def get_candidate_additional_fields(candidate_id: str) -> str:
    return await _call_api("Candidate additional fields", phenom_client.get_candidate_additional_fields, candidate_id)


def main() -> None:
    global token_manager, phenom_client
    try:
        config = load_config()
    except ValueError as e:
        print(str(e), file=sys.stderr)
        sys.exit(1)

    token_manager = TokenManager(config)
    phenom_client = PhenomClient(token_manager, config)
    mcp_server.run(transport="stdio")


if __name__ == "__main__":
    main()
