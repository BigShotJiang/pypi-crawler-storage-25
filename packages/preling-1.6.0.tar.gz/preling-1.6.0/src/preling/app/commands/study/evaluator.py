from dataclasses import dataclass
import unicodedata

from openai import OpenAI
from pydantic import BaseModel, ValidationError

from preling.db import get_session
from preling.db.models import EvaluationCache, Sentence, Word
from preling.utils.strings import normalize

__all__ = [
    'evaluate',
    'SentenceEvaluation',
    'WordEvaluation',
]

TEMPERATURE = 0.0


@dataclass
class WordEvaluation:
    word: str
    word_data: Word
    is_correct: bool | None
    llm_translation: str | None


@dataclass
class SentenceEvaluation:
    is_correct: bool
    llm_translation: str
    back_translation: str | None
    words: list[WordEvaluation]


class WordOutput(BaseModel):
    word_number: int
    lowercased_word: str
    word: str
    llm_translation: str
    learner_translation: str | None
    correctly_translated: bool | None


class SentenceAnalysis(BaseModel):
    back_translation: str | None
    words: list[WordOutput]


class SentenceOutput(BaseModel):
    llm_translation: str
    correctly_translated: bool
    analysis: SentenceAnalysis | None


def normalize_spelling(word: str) -> str:
    return unicodedata.normalize('NFC', word.strip())


def generate_prompt(language: str, sentence: Sentence, translation: str) -> str:
    """
    Generate a prompt for the LLM to evaluate an English translation of a sentence
    from the specified source language.
    """
    return '\n'.join([
        f"A learner of the language with code `{language}` has attempted to translate "
        f"the following sentence from this language into English:",
        f"`{sentence.sentence}`",
        f"Their translation is:",
        f"`{translation}`",
        f"Determine whether the learner's translation is correct. The translation is correct if "
        f"it conveys the same essential meaning as the original sentence, even if the grammatical "
        f"structure, word order, or specific word choices differ from a literal translation. "
        f"Also, provide your own translation that you consider perfect. It may match the learner's "
        f"version, or differ, even if you deem the learner's attempt correct but see room for "
        f"minor improvements.",
        f"If the learner's translation is fully correct, set `analysis` to null and skip all "
        f"further analysis.",
        f"Otherwise, provide `analysis` with your detailed evaluation:",
        f"- A back-translation of the learner's translation into the original language.",
        f"- For each word in the list below:",
        *[
            f"{word_number}) {entry.word.word.lower()}"
            for word_number, entry in enumerate(sentence.word_entries, start=1)
        ],
        f"  - Your own translation of the word into English within the context of the sentence.",
        f"  - Whether the learner's translation of the word is correct—that is, whether the "
        f"meaning conveyed by the word (lexical and/or grammatical) is reflected in the learner's "
        f"translation of the full sentence. The learner does NOT need to use the exact same English "
        f"word or phrasing—what matters is whether the learner understood the word, i.e. whether "
        f"its meaning is present somewhere in their translation, possibly expressed through a "
        f"different grammatical construction (e.g. \"my friend\" and \"a friend of mine\" both "
        f"convey possession; a relative clause without \"whom\" can still convey the same meaning "
        f"as one with \"whom\"). You may return null if it's unclear from the learner's "
        f"translation whether they understood the word correctly.",
    ])


def build_evaluation(sentence_analysis: SentenceOutput, sentence: Sentence, translation: str) -> SentenceEvaluation:
    """Build a `SentenceEvaluation` from the LLM's analysis of the sentence and its words."""
    if sentence_analysis.analysis is None:
        return SentenceEvaluation(
            is_correct=True,
            llm_translation=sentence_analysis.llm_translation,
            back_translation=None,
            words=[
                WordEvaluation(
                    word=entry.word.word,
                    word_data=entry.word,
                    is_correct=True,
                    llm_translation=None,
                )
                for entry in sentence.word_entries
            ],
        )
    analysis = sentence_analysis.analysis
    is_correct = (sentence_analysis.correctly_translated
                  or normalize(sentence_analysis.llm_translation) == normalize(translation)
                  or normalize(analysis.back_translation or '') == normalize(sentence.sentence))
    return SentenceEvaluation(
        is_correct=is_correct,
        llm_translation=sentence_analysis.llm_translation,
        back_translation=analysis.back_translation,
        words=[
            WordEvaluation(
                word=word.word,
                word_data=sentence.word_entries[word.word_number - 1].word,
                is_correct=is_correct or word.correctly_translated,  # the order is important due to nullability
                llm_translation=word.llm_translation,
            )
            for word in analysis.words
            if 1 <= word.word_number <= len(sentence.word_entries)
            and (normalize_spelling(sentence.word_entries[word.word_number - 1].word.word.lower()) ==
                 normalize_spelling(word.lowercased_word))
        ],
    )


def request(sentence: Sentence, language: str, translation: str, model: str, api_key: str) -> SentenceOutput:
    """Request the LLM to evaluate the translation of a sentence."""
    return OpenAI(api_key=api_key).responses.parse(
        model=model,
        temperature=TEMPERATURE,
        text_format=SentenceOutput,
        input=generate_prompt(language, sentence, translation),
        service_tier='priority',
    ).output_parsed


def cached_request(sentence: Sentence, language: str, translation: str, model: str, api_key: str) -> SentenceOutput:
    """Request the LLM to evaluate the translation of a sentence, using cache if available."""
    with get_session(language) as session:
        if cached := session.query(EvaluationCache).filter(
            EvaluationCache.sentence_id == sentence.id,
            EvaluationCache.model == model,
            EvaluationCache.translation == translation,
        ).limit(1).first():
            try:
                return SentenceOutput.model_validate_json(cached.evaluation)
            except ValidationError:
                session.delete(cached)
                session.flush()
        output = request(sentence, language, translation, model, api_key)
        session.add(EvaluationCache(
            sentence_id=sentence.id,
            model=model,
            translation=translation,
            evaluation=output.model_dump_json(),
        ))
        return output


def evaluate(sentence: Sentence, language: str, translation: str, model: str, api_key: str) -> SentenceEvaluation:
    """Evaluate the translation of a sentence from the specified language into English using an LLM."""
    return build_evaluation(cached_request(sentence, language, translation, model, api_key), sentence, translation)
