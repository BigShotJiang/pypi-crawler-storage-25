r1 = """
n_customer = 1000
p_purchase = 0.3
poss_out = [0, 1]
customer_visit = np.random.choice(poss_out, size=n_customer, p=[1 - p_purchase, p_purchase])
mean = np.mean(customer_visit)
variance = np.var(customer_visit)
print(f"Mean: {mean}")
print(f"Variance: {variance}")
plt.hist(customer_visit, bins=[-0.5, 0.5, 1.5], density=True, alpha=0.7, color='yellow', edgecolor='black')
plt.xlabel('Customer Action')
plt.ylabel('Purchase Probability')
plt.xticks([0, 1], ['No Purchase (0)', 'Purchase (1)'])
plt.title('Distribution of Customer Purchases')
plt.grid(axis='y', alpha=0.7)
plt.show()
-------------------
n_customer = 50
p_purchase = np.random.random()
poss_out = np.arange(0, n_customer + 1)
pmf = binom.pmf(poss_out, n_customer, p_purchase)
plt.figure(figsize=(50,20))
plt.bar(poss_out, pmf, color='lightblue', edgecolor='black')
plt.xlabel('Number of Purchases')
plt.ylabel('Purchase Probability')
plt.xticks(poss_out)
plt.title('Probability Mass Function of Purchases')
plt.show()
mode = drama_out[np.argmax(pmf)] if 'drama_out' in locals() else poss_out[np.argmax(pmf)]
print(f"Random probability of purchase: {p_purchase:.4f}")
print(f"Expected number of purchases: {n_customer * p_purchase:.2f}")
print(f"Most likely number of purchases: {mode}")
print(f"Probability of most likely outcome: {pmf[mode]:.4f}")
-------------------
avg_check = 10
p_check_8 = poisson.pmf(8, avg_check)
print(f"P(X = 8): {p_check_8}")
p_check_more_15 = 1 - poisson.cdf(15, avg_check)
print(f"P(X > 15): {p_check_more_15}")
poss_out = np.arange(0, 26)
pmf = poisson.pmf(poss_out, avg_check)
plt.figure(figsize=(10, 5))
plt.bar(poss_out, pmf, color='lightblue', edgecolor='black')
plt.xlabel('Number of Checkouts per Hour')
plt.ylabel('Probability Mass Function')
plt.xticks(poss_out)
plt.title('Probability Mass Function of Checkouts')
plt.show()
-------------------
n_interaction = 10
p_success = 0.25
p_success_4 = geom.pmf(4, p_success)
print(f"P(first success on 4th interaction): {p_success_4}")
poss_out = np.arange(1, n_interaction + 1)
pmf = geom.pmf(poss_out, p_success)
plt.stem(poss_out, pmf)
plt.xlabel("Interaction Number")
plt.ylabel("Probability")
plt.title("Geometric Distribution: First Successful Response")
plt.show()
-------------------
lam = 3
poss_out = np.arange(0, 15)
pmf = poisson.pmf(poss_out, lam)
plt.stem(poss_out, pmf)
plt.xlabel("Number of Defective Items")
plt.ylabel("Probability")
plt.title("Poisson Distribution of Defective Items per Day")
plt.show()
"""

r2 = """
X = np.random.randint(800, 5000, size=100)
epsilon = np.random.normal(0, 50000, 100)
y = 150 * X + epsilon
print(X)
print(y)
-------------------
df = pd.DataFrame({'Square Foot': X, 'Price': y})
df.loc[df.sample(5).index, 'Price'] = np.nan
df['Price'] = df['Price'].fillna(df['Price'].median())
df['Location'] = np.random.choice(['Urban', 'Suburban', 'Rural'], size=len(df))
df = pd.get_dummies(df, columns=['Location'])
print(df.head())
-------------------
plt.figure(figsize=(10, 6))
sns.heatmap(df.corr(), annot=True, cmap='coolwarm', linewidths=0.5)
plt.title('Correlation Matrix Heatmap')
plt.figure(figsize=(20, 5))
plt.subplot(1, 2, 1)
plt.hist(df['Price'], bins=10, alpha=0.7, color='yellow', edgecolor='black')
plt.xlabel('Price')
plt.ylabel('Frequency')
plt.title('Distribution of Prices')
plt.subplot(1, 2, 2)
sns.scatterplot(x='Square Foot', y='Price', data=df)
plt.title('Square Foot vs Price')
plt.show()
"""

r3 = """
cols = ['','']
data = pd.read_csv("wine.data", names=cols)
X = data.drop('class', axis=1)
-------------------
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
pca = PCA()
X_pca = pca.fit_transform(X_scaled)
print("Explained Variance Ratio of Each PC:")
for i, var in enumerate(pca.explained_variance_ratio_):
  print(f"PC {i+1}: {var:.4f}")
-------------------
plt.scatter(X_scaled[:, 0], X_scaled[:, 1], alpha=0.5, color='gray', label='Data Points')
colors = ['red', 'green', 'blue']
for i, color in enumerate(colors):
    v = pca.components_[i, :2] * 5
    plt.plot([0, v[0]], [0, v[1]], color=color, label=f'PC{i+1}')
plt.xlabel("Alcohol (Scaled)")
plt.ylabel("Malic Acid (Scaled)")
plt.title("Data Scatter with First 3 Principal Components")
plt.legend()
plt.show()
"""

r4 = """
n = 10000
p = 0.7
X = np.random.binomial(1, p, n)
cumulative_avg = np.cumsum(X) / np.arange(1, n + 1)
plt.plot(cumulative_avg, label="Cumulative Average (A_n)")
plt.axhline(y=p, linestyle='--', color='red', label="True Probability (p = 0.7)")
plt.xlabel("Number of Trials (n)")
plt.ylabel("Cumulative Average")
plt.title("Law of Large Numbers (Bernoulli Trials)")
plt.legend()
plt.show()
-------------------
m = 1000
k_values = [1, 2, 5, 30]
mu_die = 3.5
var_die = 35 / 12
plt.figure(figsize=(20, 6))
for i, k in enumerate(k_values, 1):
    samples = np.random.randint(1, 7, size=(m, k))
    sample_means = np.mean(samples, axis=1)
    plt.subplot(1, 4, i)
    plt.hist(sample_means, bins=30, density=True, color='lightgreen', edgecolor='black')
    plt.title(f"k = {k}")
    plt.xlabel("Sample Mean")
    plt.ylabel("Density")
    if k == 30:
        x = np.linspace(min(sample_means), max(sample_means), 100)
        sigma_k = np.sqrt(var_die / k)
        plt.plot(x, stats.norm.pdf(x, mu_die, sigma_k), color='red', label="Normal PDF")
        plt.legend()
plt.tight_layout()
plt.show()
-------------------
lambda_val = 0.5
sample_size = 50
num_samples = 500
sample_means = np.mean(
    np.random.exponential(scale=1/lambda_val, size=(num_samples, sample_size)),
    axis=1
)
mu = 1 / lambda_val
sigma = (1 / lambda_val) / np.sqrt(sample_size)
plt.figure(figsize=(6, 6))
stats.probplot(sample_means, dist="norm", sparams=(mu, sigma), plot=plt)
plt.title("Q-Q Plot of Sample Means vs Normal Distribution")
plt.grid()
plt.show()
-------------------
levels = 100
p_right = 0.5
num_balls = 5000
trials = np.random.binomial(1, p_right, size=(num_balls, levels))
final_positions = np.sum(trials, axis=1)
plt.figure(figsize=(8, 5))
plt.hist(final_positions, bins=30, density=True, alpha=0.6, color='blue')
mu = levels * p_right
sigma = np.sqrt(levels * p_right * (1 - p_right))
x = np.linspace(mu - 4*sigma, mu + 4*sigma, 200)
plt.plot(x, stats.norm.pdf(x, mu, sigma), linewidth=2, color='red', label="Normal Curve")
plt.xlabel("Final Position (Number of Right Moves)")
plt.ylabel("Probability Density")
plt.title("Digital Galton Board: Binomial vs Normal Distribution")
plt.grid()
plt.legend()
plt.show()
"""

from .xh import read as xh
from .xh import ln, fix, explain
xh.ln = ln
xh.fix = fix
xh.explain = explain
