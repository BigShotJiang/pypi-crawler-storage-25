import requests
import pandas as pd
import os

BASE_URL = "https://xhline.vercel.app"
_last_code = ""

def read(prompt, mode="code"):
    global _last_code
    try:
        r = requests.post(f"{BASE_URL}/generate", json={"prompt": prompt, "mode": mode})
        res = r.json().get("code", "# No result found")
        if mode == "code":
            _last_code = res
        return res
    except Exception as e:
        return f"# Error: {e}"

def ln(filename, prompt):
    if not os.path.exists(filename):
        return f"# Error: File '{filename}' not found."
    
    try:
        ext = os.path.splitext(filename)[1].lower()
        if ext == '.csv':
            df = pd.read_csv(filename)
        elif ext in ['.xls', '.xlsx']:
            df = pd.read_excel(filename)
        elif ext == '.json':
            df = pd.read_json(filename)
        else:
            return f"# Error: Unsupported file type '{ext}'"

        context = f"Dataset Summary:\nColumns: {list(df.columns)}\nFirst 5 rows:\n{df.head().to_string()}\n\n"
        full_prompt = f"{context}Task: {prompt}"
        
        return read(full_prompt)
    except Exception as e:
        return f"# Error reading file: {e}"

def fix(error_msg):
    global _last_code
    prompt = f"Code: {_last_code}\nError: {error_msg}"
    return read(prompt, mode="fix")

def explain(prompt_or_code=None):
    global _last_code
    # If no prompt is given, explain the last generated code
    target = prompt_or_code if prompt_or_code else _last_code
    return read(target, mode="explain")
