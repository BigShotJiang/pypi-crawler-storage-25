# xhline

A simple Python package that provides an `xhline` module.

## Installation

```bash
pip install xhline
```

## Usage

```python
from xhline import r1
print(r1)
```
## Available Modules
```
- r1
- r2
- r3
- r4
- xh
```