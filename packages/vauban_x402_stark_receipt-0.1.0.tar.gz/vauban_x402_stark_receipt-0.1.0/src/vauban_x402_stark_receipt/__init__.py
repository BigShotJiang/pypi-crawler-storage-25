"""
vauban-x402-stark-receipt
=========================
Python reference runner for JCS (RFC 8785) canonical preimage discipline
in the x402 STARK Receipt Format Extension.

IETF draft: draft-vauban-x402-stark-receipts
Sister crate: vauban-x402-jcs-conformance (Rust, crates.io)
License: Apache 2.0
"""

from __future__ import annotations

import base64
import hashlib
from typing import Union

import rfc8785

__version__ = "0.1.0"
__all__ = [
    "jcs_canonical_bytes",
    "jcs_hash",
    "jcs_sha256",
    "validate_pair_invariant",
]

# Types that can be JCS-serialised (mirrors RFC 8785 Section 3 scope).
JcsValue = Union[dict, list, str, int, float, bool, None]


def jcs_canonical_bytes(body: JcsValue) -> bytes:
    """Return the JCS-canonical (RFC 8785) UTF-8 byte representation of *body*.

    Key ordering is deterministic (lexicographic Unicode code-point order);
    whitespace is suppressed; floating-point values follow ECMAScript serialisation.

    Args:
        body: Any JSON-compatible value (dict, list, str, int, float, bool, None).

    Returns:
        UTF-8 encoded JCS-canonical bytes.

    Example::

        >>> jcs_canonical_bytes({"b": 2, "a": 1})
        b'{"a":1,"b":2}'
    """
    return rfc8785.dumps(body)


def jcs_sha256(body: JcsValue) -> str:
    """Return the SHA-256 digest of the JCS-canonical preimage as ``"sha256:<hex64>"``.

    The prefix ``sha256:`` is part of the canonical digest format defined in
    draft-vauban-x402-stark-receipts Section 4.2.

    Args:
        body: Any JSON-compatible value.

    Returns:
        Lowercase hex digest with ``sha256:`` prefix ; 70 characters total.

    Example::

        >>> d = jcs_sha256({"a": 1})
        >>> d.startswith("sha256:")
        True
        >>> len(d)
        70
    """
    canonical = jcs_canonical_bytes(body)
    hex_digest = hashlib.sha256(canonical).hexdigest()
    return f"sha256:{hex_digest}"


def jcs_hash(body: JcsValue) -> tuple[str, str]:
    """Return ``(base64_canonical, sha256_digest)`` for *body*.

    The first element is the Base64 (standard alphabet, with padding) encoding
    of the JCS-canonical bytes ; usable as the ``jcs_preimage`` field in a STARK
    receipt.  The second element is the ``sha256:`` prefixed hex digest.

    Args:
        body: Any JSON-compatible value.

    Returns:
        A 2-tuple ``(b64_str, "sha256:<hex64>")``.

    Example::

        >>> b64, digest = jcs_hash({"amount": 100})
        >>> import base64, json
        >>> base64.b64decode(b64) == b'{"amount":100}'
        True
    """
    canonical = jcs_canonical_bytes(body)
    b64 = base64.b64encode(canonical).decode("ascii")
    hex_digest = hashlib.sha256(canonical).hexdigest()
    return b64, f"sha256:{hex_digest}"


def validate_pair_invariant(left: JcsValue, right: JcsValue) -> bool:
    """Check that *left* and *right* produce distinct SHA-256 digests.

    The pair invariant is a basic sanity check from draft-vauban-x402-stark-receipts
    Section 4.3: two semantically different payment objects MUST NOT hash to the
    same digest.  Returns True when digests differ (invariant holds), False when
    they collide (invariant violated ; indicates a serialisation bug).

    Args:
        left: First JSON-compatible value.
        right: Second JSON-compatible value.

    Returns:
        True if digests are distinct, False if they collide.

    Example::

        >>> validate_pair_invariant({"a": 1}, {"a": 2})
        True
        >>> validate_pair_invariant({"a": 1}, {"a": 1})
        False
    """
    return jcs_sha256(left) != jcs_sha256(right)
