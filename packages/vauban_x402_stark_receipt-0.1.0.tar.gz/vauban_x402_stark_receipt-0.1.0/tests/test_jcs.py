"""
Tests for vauban-x402-stark-receipt ; mirrors vauban-x402-jcs-conformance Rust crate test suite.

Covers: RFC 8785 canonical ordering, SHA-256 format, pair invariant, array order,
unicode distinctions, optional null, deep nesting, and edge types.
"""

import base64
import hashlib

import pytest

from vauban_x402_stark_receipt import (
    jcs_canonical_bytes,
    jcs_hash,
    jcs_sha256,
    validate_pair_invariant,
)


# ---------------------------------------------------------------------------
# jcs_canonical_bytes
# ---------------------------------------------------------------------------


def test_rfc8785_key_order():
    """RFC 8785 Section 3.2.3: keys sorted by Unicode code-point order."""
    result = jcs_canonical_bytes({"b": 2, "a": 1})
    assert result == b'{"a":1,"b":2}'


def test_rfc8785_no_whitespace():
    """JCS output must be compact; no spaces or newlines."""
    result = jcs_canonical_bytes({"key": "value", "n": 42})
    assert b" " not in result
    assert b"\n" not in result


def test_rfc8785_string_value():
    """Plain string passes through as JSON string."""
    result = jcs_canonical_bytes("hello")
    assert result == b'"hello"'


def test_rfc8785_integer_value():
    """Integer serialised without decimal point."""
    result = jcs_canonical_bytes(42)
    assert result == b"42"


def test_rfc8785_null_value():
    """None serialised as JSON null."""
    result = jcs_canonical_bytes(None)
    assert result == b"null"


def test_rfc8785_boolean_values():
    """True/False serialised as JSON true/false (lowercase)."""
    assert jcs_canonical_bytes(True) == b"true"
    assert jcs_canonical_bytes(False) == b"false"


# ---------------------------------------------------------------------------
# jcs_sha256
# ---------------------------------------------------------------------------


def test_sha256_prefix_format():
    """Digest string always starts with 'sha256:' and is 71 chars total."""
    d = jcs_sha256({"a": 1})
    assert d.startswith("sha256:")
    assert len(d) == 71  # len("sha256:") == 7 + 64 hex chars


def test_sha256_hex_lowercase():
    """Hex portion must be lowercase."""
    d = jcs_sha256({"x": 99})
    hex_part = d[7:]  # len("sha256:") == 7
    assert hex_part == hex_part.lower()
    assert len(hex_part) == 64


def test_sha256_deterministic():
    """Same input always produces the same digest."""
    body = {"amount": 100, "currency": "STRK", "nonce": "abc"}
    assert jcs_sha256(body) == jcs_sha256(body)


def test_sha256_key_order_invariant():
    """Key insertion order must not affect the digest."""
    a = jcs_sha256({"b": 2, "a": 1})
    b = jcs_sha256({"a": 1, "b": 2})
    assert a == b


def test_sha256_cross_check_with_stdlib():
    """Cross-validate against manual hashlib.sha256 of the canonical bytes."""
    body = {"amount": 500, "to": "0xdeadbeef"}
    canonical = jcs_canonical_bytes(body)
    expected_hex = hashlib.sha256(canonical).hexdigest()
    assert jcs_sha256(body) == f"sha256:{expected_hex}"


# ---------------------------------------------------------------------------
# jcs_hash
# ---------------------------------------------------------------------------


def test_jcs_hash_returns_tuple():
    """jcs_hash returns a 2-tuple (b64, sha256_digest)."""
    result = jcs_hash({"x": 1})
    assert isinstance(result, tuple)
    assert len(result) == 2


def test_jcs_hash_b64_decodes_to_canonical():
    """First element base64-decodes to the JCS-canonical bytes."""
    body = {"amount": 100}
    b64, _ = jcs_hash(body)
    decoded = base64.b64decode(b64)
    assert decoded == jcs_canonical_bytes(body)


def test_jcs_hash_digest_matches_sha256():
    """Second element matches jcs_sha256."""
    body = {"foo": "bar", "n": 7}
    _, digest = jcs_hash(body)
    assert digest == jcs_sha256(body)


# ---------------------------------------------------------------------------
# array ordering
# ---------------------------------------------------------------------------


def test_array_order_is_significant():
    """Array element order is preserved; [1,2] != [2,1]."""
    assert jcs_sha256([1, 2]) != jcs_sha256([2, 1])


def test_array_canonical_bytes():
    """Arrays serialised in original order."""
    result = jcs_canonical_bytes([3, 1, 2])
    assert result == b"[3,1,2]"


# ---------------------------------------------------------------------------
# unicode
# ---------------------------------------------------------------------------


def test_unicode_nfc_vs_nfd_distinct():
    """NFC and NFD forms produce different JCS bytes and digests.

    JCS does NOT normalise Unicode ; the bytes are serialised as-is.
    Two strings that look identical but differ in normalisation form
    must produce distinct digests.
    """
    import unicodedata

    # U+00E9 LATIN SMALL LETTER E WITH ACUTE (NFC, single code point)
    nfc = unicodedata.normalize("NFC", "é")
    # e + U+0301 COMBINING ACUTE ACCENT (NFD, two code points)
    nfd = unicodedata.normalize("NFD", "é")

    assert nfc != nfd, "Pre-condition: NFC and NFD must differ at byte level"
    assert jcs_sha256({"k": nfc}) != jcs_sha256({"k": nfd})


# ---------------------------------------------------------------------------
# optional null field
# ---------------------------------------------------------------------------


def test_optional_null_field_included():
    """A field set to null is included in JCS output; absent key is excluded."""
    with_null = jcs_canonical_bytes({"a": 1, "b": None})
    without_key = jcs_canonical_bytes({"a": 1})
    assert with_null != without_key
    assert b'"b":null' in with_null


# ---------------------------------------------------------------------------
# deep nesting
# ---------------------------------------------------------------------------


def test_nested_deep_sort():
    """Keys sorted at every nesting level, not just top-level."""
    body = {"z": {"d": 4, "c": 3}, "a": {"b": 2, "a": 1}}
    canonical = jcs_canonical_bytes(body)
    # Top-level: "a" before "z"; inner levels also sorted
    assert canonical == b'{"a":{"a":1,"b":2},"z":{"c":3,"d":4}}'


# ---------------------------------------------------------------------------
# pair invariant
# ---------------------------------------------------------------------------


def test_pair_invariant_holds_for_distinct_values():
    """Different objects must have distinct digests."""
    assert validate_pair_invariant({"a": 1}, {"a": 2}) is True


def test_pair_invariant_fails_for_equal_values():
    """Equal objects produce equal digests; invariant returns False."""
    assert validate_pair_invariant({"a": 1}, {"a": 1}) is False


def test_pair_invariant_key_order_agnostic():
    """Different key insertion orders but same content -> invariant False."""
    assert validate_pair_invariant({"a": 1, "b": 2}, {"b": 2, "a": 1}) is False
