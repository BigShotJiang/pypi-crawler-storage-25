# vauban-x402-stark-receipt

Python reference runner for JCS canonical preimage discipline in the x402 STARK Receipt Format
Extension ([draft-vauban-x402-stark-receipts](https://datatracker.ietf.org/doc/draft-vauban-x402-stark-receipts/)).

Mirrors the Rust crate [`vauban-x402-jcs-conformance`](https://crates.io/crates/vauban-x402-jcs-conformance)
v0.1.0 API shape. Pure Python ; no Rust toolchain required.

## Install

```
pip install vauban-x402-stark-receipt
```

## API

```python
from vauban_x402_stark_receipt import jcs_canonical_bytes, jcs_hash, jcs_sha256, validate_pair_invariant

# JCS-canonical UTF-8 bytes (RFC 8785)
raw = jcs_canonical_bytes({"b": 2, "a": 1})
# b'{"a":1,"b":2}'

# Canonical preimage + digest
b64, digest = jcs_hash({"amount": 100, "currency": "STRK"})
# ("eyJhbW91bnQ...", "sha256:abcdef...")

# Digest only
d = jcs_sha256({"amount": 100})
# "sha256:abcdef..."

# Pair invariant: left and right produce distinct digests
ok = validate_pair_invariant({"a": 1}, {"a": 2})
# True
```

## Provenance

- IETF I-D: `draft-vauban-x402-stark-receipts` ; JCS preimage discipline, Section 4.2
- Sister crate: `vauban-x402-jcs-conformance` on crates.io (Rust reference, Apache 2.0)
- JCS implementation: [`rfc8785`](https://pypi.org/project/rfc8785/) by Trail of Bits

## License

Apache 2.0 ; see LICENSE.
