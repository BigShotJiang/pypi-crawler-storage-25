# jupyterlab-anticheat

A JupyterLab extension that **blocks copy-paste in code cells** to prevent cheating during university programming exams. Students are required to type code manually, reinforcing genuine learning.

## Features

- Blocks `Ctrl+V` / `Cmd+V` keyboard paste in code cells
- Blocks **drag-and-drop** of code into cells
- Blocks **right-click → Paste** from the context menu
- Shows a clear red notification message to the student
- Works in **Anaconda JupyterLab** and **web-hosted JupyterLab** (both run in a browser)
- Instructor can enable/disable via Command Palette or Settings
- Configurable block message via Settings

## Installation

```bash
cd jupyterlab-anticheat
pip install -e .
jupyter labextension develop --overwrite .
```

See `install.txt` for full step-by-step instructions.

## Instructor Controls

Open the Command Palette (`Ctrl+Shift+C`) and search for **AntiCheat** to:

- Enable paste blocking (Exam Mode)
- Disable paste blocking
- Toggle paste blocking

## Settings

Go to **Settings → Advanced Settings Editor → AntiCheat Exam Extension** to configure:

- `enabled` — turn blocking on or off (default: `true`)
- `message` — customize the message shown when paste is blocked

## How It Works

The extension registers event listeners at the document level using **capture phase** (`addEventListener(..., true)`), which means it intercepts events before JupyterLab's editor (CodeMirror) can process them. It checks whether the target element is inside a code cell and, if so, cancels the event and displays a notification.

## Limitations

- A technically advanced student could open browser DevTools and disable the extension from the console. For high-stakes exams, combine with browser lockdown tools.
- Does not block paste in Markdown cells (intentional — Markdown editing is not exam content).

## License

MIT
