"""jupyterlab-anticheat — blocks copy-paste in code cells during exams."""

import os
from pathlib import Path

HERE = Path(__file__).parent.resolve()

try:
    from ._version import __version__
except ImportError:
    import importlib.metadata
    try:
        __version__ = importlib.metadata.version("jupyterlab_anticheat")
    except importlib.metadata.PackageNotFoundError:
        __version__ = "unknown"


def _jupyter_labextension_paths():
    """JupyterLab 4.x prebuilt extension."""
    return [{"src": str(HERE / "labextension"), "dest": "jupyterlab-anticheat"}]


def _jupyter_nbextension_paths():
    """Classic Jupyter Notebook extension."""
    return [{
        "section": "notebook",
        "src": str(HERE / "nbextension"),
        "dest": "jupyterlab_anticheat",
        "require": "jupyterlab_anticheat/main",
    }]


def _jupyter_config_path():
    """Tell Jupyter where our auto-enable config lives."""
    return [str(HERE / "jupyter_config")]
