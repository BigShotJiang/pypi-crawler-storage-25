define(['base/js/namespace', 'base/js/events'], function (Jupyter, events) {
    'use strict';

    function showBanner() {
        var existing = document.getElementById('anticheat-banner');
        if (existing) { clearTimeout(existing._timer); existing.remove(); }
        var banner = document.createElement('div');
        banner.id = 'anticheat-banner';
        banner.style.cssText = [
            'position:fixed', 'top:0', 'left:50%', 'transform:translateX(-50%)',
            'background:#c00', 'color:#fff', 'padding:10px 32px',
            'font-size:15px', 'font-weight:bold',
            'border-radius:0 0 10px 10px', 'z-index:99999',
            'box-shadow:0 2px 8px rgba(0,0,0,0.4)'
        ].join(';');
        banner.textContent = '\u26d4 Paste is disabled during this exam';
        document.body.appendChild(banner);
        banner._timer = setTimeout(function () { banner.remove(); }, 2500);
    }

    function blockOnCell(cell) {
        if (!cell || cell.cell_type !== 'code') return;
        var cm = cell.code_mirror;
        if (!cm || cm._anticheatBlocked) return;
        cm._anticheatBlocked = true;

        cm.on('paste', function (cm, e) {
            e.preventDefault();
            e.stopPropagation();
            showBanner();
            return false;
        });

        cm.on('keydown', function (cm, e) {
            if ((e.ctrlKey || e.metaKey) && (e.key === 'v' || e.keyCode === 86)) {
                e.preventDefault();
                e.stopPropagation();
                showBanner();
                return false;
            }
        });

        var wrapper = cm.getWrapperElement();
        wrapper.addEventListener('drop', function (e) {
            e.preventDefault();
            e.stopPropagation();
            showBanner();
        }, true);

        wrapper.addEventListener('contextmenu', function (e) {
            e.preventDefault();
            e.stopPropagation();
            showBanner();
        }, true);
    }

    function blockAllCells() {
        if (!Jupyter.notebook) return;
        Jupyter.notebook.get_cells().forEach(function (cell) {
            blockOnCell(cell);
        });
    }

    function load_ipython_extension() {
        blockAllCells();

        events.on('create.Cell', function (event, data) {
            blockOnCell(data.cell);
        });

        events.on('notebook_loaded.Notebook', function () {
            blockAllCells();
        });

        events.on('select.Cell', function () {
            blockAllCells();
        });
    }

    return { load_ipython_extension: load_ipython_extension };
});
