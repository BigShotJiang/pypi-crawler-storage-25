import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';

import { INotebookTracker } from '@jupyterlab/notebook';
import { ICommandPalette } from '@jupyterlab/apputils';
import { ISettingRegistry } from '@jupyterlab/settingregistry';

const PLUGIN_ID = 'jupyterlab-anticheat:plugin';
const BLOCKED_MESSAGE = '⛔ Paste is disabled during this exam. Please type the code manually.';

let isBlocked = true;
let notificationTimeout: ReturnType<typeof setTimeout> | null = null;

function showBlockedMessage(cell: Element | null): void {
  const existingMsg = document.getElementById('anticheat-blocked-msg');
  if (existingMsg) existingMsg.remove();
  if (notificationTimeout) clearTimeout(notificationTimeout);

  const msg = document.createElement('div');
  msg.id = 'anticheat-blocked-msg';
  msg.textContent = BLOCKED_MESSAGE;
  msg.style.cssText = `
    position: fixed;
    bottom: 24px;
    left: 50%;
    transform: translateX(-50%);
    background: #d32f2f;
    color: #ffffff;
    padding: 12px 24px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 600;
    z-index: 99999;
    box-shadow: 0 4px 16px rgba(0,0,0,0.3);
    pointer-events: none;
    letter-spacing: 0.01em;
    max-width: 90vw;
    text-align: center;
    animation: anticheat-fadein 0.2s ease;
  `;
  document.body.appendChild(msg);

  notificationTimeout = setTimeout(() => {
    if (msg.parentNode) {
      msg.style.opacity = '0';
      msg.style.transition = 'opacity 0.4s ease';
      setTimeout(() => msg.remove(), 400);
    }
  }, 3000);
}

function isInsideCodeCell(target: EventTarget | null): boolean {
  if (!target || !(target instanceof Element)) return false;
  return (
    target.closest('.jp-CodeCell') !== null ||
    target.closest('.jp-CodeMirrorEditor') !== null ||
    target.closest('.CodeMirror') !== null ||
    target.closest('.cm-editor') !== null ||
    target.closest('.jp-InputArea') !== null
  );
}

function blockPaste(event: ClipboardEvent): void {
  if (!isBlocked) return;
  if (!isInsideCodeCell(event.target)) return;
  event.preventDefault();
  event.stopPropagation();
  showBlockedMessage(
    event.target instanceof Element
      ? event.target.closest('.jp-CodeCell')
      : null
  );
}

function blockDrop(event: DragEvent): void {
  if (!isBlocked) return;
  if (!isInsideCodeCell(event.target)) return;
  const types = event.dataTransfer?.types ?? [];
  const hasText =
    types.includes('text/plain') ||
    types.includes('text') ||
    types.includes('application/vnd.jupyter.cells');
  if (!hasText) return;
  event.preventDefault();
  event.stopPropagation();
  showBlockedMessage(
    event.target instanceof Element
      ? event.target.closest('.jp-CodeCell')
      : null
  );
}

function blockKeyboardPaste(event: KeyboardEvent): void {
  if (!isBlocked) return;
  if (!isInsideCodeCell(event.target)) return;
  const isV = event.key === 'v' || event.key === 'V';
  const isPasteShortcut = (event.ctrlKey || event.metaKey) && isV;
  if (!isPasteShortcut) return;
  event.preventDefault();
  event.stopPropagation();
  showBlockedMessage(
    event.target instanceof Element
      ? event.target.closest('.jp-CodeCell')
      : null
  );
}

function injectStyles(): void {
  const style = document.createElement('style');
  style.id = 'anticheat-styles';
  style.textContent = `
    @keyframes anticheat-fadein {
      from { opacity: 0; transform: translateX(-50%) translateY(10px); }
      to   { opacity: 1; transform: translateX(-50%) translateY(0); }
    }
    .jp-CodeCell.anticheat-active .jp-InputArea-editor {
      outline: 2px solid #d32f2f22;
    }
  `;
  document.head.appendChild(style);
}

function attachBlockers(): void {
  document.addEventListener('paste', blockPaste, true);
  document.addEventListener('drop', blockDrop, true);
  document.addEventListener('keydown', blockKeyboardPaste, true);
}

function detachBlockers(): void {
  document.removeEventListener('paste', blockPaste, true);
  document.removeEventListener('drop', blockDrop, true);
  document.removeEventListener('keydown', blockKeyboardPaste, true);
}

const plugin: JupyterFrontEndPlugin<void> = {
  id: PLUGIN_ID,
  autoStart: true,
  requires: [INotebookTracker],
  optional: [ICommandPalette, ISettingRegistry],
  activate: (
    app: JupyterFrontEnd,
    tracker: INotebookTracker,
    palette: ICommandPalette | null,
    settingRegistry: ISettingRegistry | null
  ) => {
    console.log('[anticheat] JupyterLab AntiCheat extension activated');

    injectStyles();

    if (settingRegistry) {
      settingRegistry
        .load(PLUGIN_ID)
        .then(settings => {
          const updateSettings = (): void => {
            isBlocked = settings.get('enabled').composite as boolean;
            if (isBlocked) {
              attachBlockers();
            } else {
              detachBlockers();
            }
          };
          settings.changed.connect(updateSettings);
          updateSettings();
        })
        .catch(() => {
          attachBlockers();
        });
    } else {
      attachBlockers();
    }

    const enableCommand = 'anticheat:enable';
    const disableCommand = 'anticheat:disable';
    const toggleCommand = 'anticheat:toggle';

    app.commands.addCommand(enableCommand, {
      label: 'AntiCheat: Enable Paste Blocking (Exam Mode)',
      execute: () => {
        isBlocked = true;
        attachBlockers();
        console.log('[anticheat] Paste blocking ENABLED');
      }
    });

    app.commands.addCommand(disableCommand, {
      label: 'AntiCheat: Disable Paste Blocking',
      execute: () => {
        isBlocked = false;
        detachBlockers();
        console.log('[anticheat] Paste blocking DISABLED');
      }
    });

    app.commands.addCommand(toggleCommand, {
      label: 'AntiCheat: Toggle Paste Blocking',
      execute: () => {
        if (isBlocked) {
          app.commands.execute(disableCommand);
        } else {
          app.commands.execute(enableCommand);
        }
      }
    });

    if (palette) {
      palette.addItem({ command: enableCommand, category: 'AntiCheat Exam Mode' });
      palette.addItem({ command: disableCommand, category: 'AntiCheat Exam Mode' });
      palette.addItem({ command: toggleCommand, category: 'AntiCheat Exam Mode' });
    }
  }
};

export default plugin;
