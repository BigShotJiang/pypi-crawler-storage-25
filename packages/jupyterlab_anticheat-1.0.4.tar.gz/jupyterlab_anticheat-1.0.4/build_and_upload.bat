@echo off
title JupyterLab AntiCheat - Build and Upload to PyPI
echo.
echo ================================================
echo   JupyterLab AntiCheat - Build and Upload
echo ================================================
echo.

echo Adding Anaconda to PATH so 'jupyter' command is found...
set PATH=%USERPROFILE%\anaconda3\Scripts;%USERPROFILE%\anaconda3;%USERPROFILE%\AppData\Local\anaconda3\Scripts;%USERPROFILE%\AppData\Local\anaconda3;C:\ProgramData\Anaconda3\Scripts;C:\ProgramData\Anaconda3;%PATH%
echo.

echo [1/4] Installing Python build tools...
pip install hatchling hatch-jupyter-builder build twine
echo.

echo [2/4] Installing Node.js dependencies...
call npm install
echo.

echo [3/4] Building Python wheel...
if exist dist rmdir /s /q dist
python -m build --no-isolation
echo.

echo ================================================
echo [4/4] Uploading to PyPI...
echo ================================================
twine upload --config-file .pypirc --verbose dist/*

echo.
echo ================================================
echo   Done! Check above for any errors.
echo ================================================
pause
