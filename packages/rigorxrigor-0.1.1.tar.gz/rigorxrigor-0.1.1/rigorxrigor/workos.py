"""WorkOS AuthKit PKCE flow and token refresh for the RigorXRigor CLI."""
from __future__ import annotations

import base64
import hashlib
import os
import secrets
import time
from typing import Any

import httpx


WORKOS_CLIENT_ID = os.environ.get(
    "WORKOS_CLIENT_ID",
    "client_01K0X9AG0Y6M4ZXHQBYQ5A7NRT",
)
WORKOS_API_BASE = os.environ.get("WORKOS_API_BASE", "https://api.workos.com")

REFRESH_MARGIN_SECONDS = 5 * 60


# ----------------------------------------------------------------------------
# PKCE
# ----------------------------------------------------------------------------


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def generate_code_verifier() -> str:
    return _b64url(secrets.token_bytes(32))


def code_challenge_for(verifier: str) -> str:
    return _b64url(hashlib.sha256(verifier.encode("ascii")).digest())


def authorize_url(
    redirect_uri: str,
    code_challenge: str,
    state: str | None = None,
    screen_hint: str | None = None,
) -> str:
    from urllib.parse import urlencode

    params = {
        "client_id": WORKOS_CLIENT_ID,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "provider": "authkit",
    }
    if state:
        params["state"] = state
    if screen_hint:
        params["screen_hint"] = screen_hint
    return f"{WORKOS_API_BASE}/user_management/authorize?{urlencode(params)}"


# ----------------------------------------------------------------------------
# Token exchange
# ----------------------------------------------------------------------------


def exchange_code_for_tokens(code: str, code_verifier: str) -> dict[str, Any]:
    """POST to WorkOS /user_management/authenticate with grant_type=authorization_code."""
    resp = httpx.post(
        f"{WORKOS_API_BASE}/user_management/authenticate",
        json={
            "code": code,
            "client_id": WORKOS_CLIENT_ID,
            "grant_type": "authorization_code",
            "code_verifier": code_verifier,
        },
        timeout=30.0,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"WorkOS token exchange failed ({resp.status_code}): {resp.text[:300]}")
    return resp.json()


def refresh_access_token(refresh_token: str) -> dict[str, Any]:
    resp = httpx.post(
        f"{WORKOS_API_BASE}/user_management/authenticate",
        json={
            "client_id": WORKOS_CLIENT_ID,
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        },
        timeout=30.0,
    )
    if resp.status_code != 200:
        raise RuntimeError(f"WorkOS token refresh failed ({resp.status_code}): {resp.text[:300]}")
    return resp.json()


def is_token_stale(expires_at: float) -> bool:
    """True if the token expires within the refresh margin."""
    return expires_at - time.time() < REFRESH_MARGIN_SECONDS
