"""rigorxrigor: pip-installable CLI for the RigorXRigor cloud API."""
__version__ = "0.1.1"
