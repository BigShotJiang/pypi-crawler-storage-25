"""rigorxrigor: pip-installable CLI talking to the cloud API.

Exit codes (mirrors the local rxr tool):
    0   verified / success
    1   not verified
    2   usage error
    3   backend / auth error
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from . import __version__, config
from . import client as api
from . import login as login_mod
from .client import AuthMissing, BackendError


def _configure_stdio() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")


# ----------------------------------------------------------------------------
# Output helpers
# ----------------------------------------------------------------------------


def _err(msg: str) -> None:
    print(msg, file=sys.stderr)


def _print_json(obj: Any) -> None:
    json.dump(obj, sys.stdout, separators=(",", ":"), ensure_ascii=False)
    sys.stdout.write("\n")


def _truncate(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 3] + "..."


# ----------------------------------------------------------------------------
# Auth subcommands
# ----------------------------------------------------------------------------


def cmd_login(args: argparse.Namespace) -> int:
    try:
        auth = login_mod.login(
            open_browser=not args.no_browser,
            timeout_seconds=args.timeout,
            screen_hint="sign-in",
        )
    except RuntimeError as exc:
        _err(f"login failed: {exc}")
        return 3
    email = auth.user.get("email", "(unknown)")
    print(f"signed in as {email}")
    return 0


def cmd_signup(args: argparse.Namespace) -> int:
    try:
        auth = login_mod.login(
            open_browser=not args.no_browser,
            timeout_seconds=args.timeout,
            screen_hint="sign-up",
        )
    except RuntimeError as exc:
        _err(f"signup failed: {exc}")
        return 3
    email = auth.user.get("email", "(unknown)")
    print(f"signed in as {email}")
    return 0


def cmd_logout(_: argparse.Namespace) -> int:
    config.clear()
    print("signed out")
    return 0


def cmd_whoami(args: argparse.Namespace) -> int:
    try:
        profile = api.me()
    except AuthMissing as exc:
        _err(str(exc))
        return 3
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(profile)
        return 0
    print(f"{profile.get('email', '?')}  (workos:{profile.get('workos_user_id', '?')})")
    sub = "active" if profile.get("subscription_active") else "inactive"
    print(f"subscription: {sub}")
    print(f"server: {config.server_url()}")
    return 0


def cmd_config(args: argparse.Namespace) -> int:
    if args.set_server:
        a = config.load()
        if a is None:
            _err("not signed in; run `rigorxrigor login` first")
            return 3
        a.server = args.set_server
        config.save(a)
        print(f"server set to {a.server}")
        return 0
    a = config.load()
    print(f"server   : {config.server_url()}")
    if a:
        print(f"signed in: yes ({a.user.get('email', '?')})")
        print(f"auth file: {config.auth_path()}")
    else:
        print("signed in: no")
    return 0


def cmd_status(_: argparse.Namespace) -> int:
    try:
        health = api.health()
    except Exception as exc:
        _err(f"server: error ({exc})")
        return 3
    print(f"server: {config.server_url()}")
    print(f"health: {health.get('status', 'ok')}")
    auth = config.load()
    if auth and auth.access_token:
        print(f"signed in: yes ({auth.user.get('email', '?')})")
    else:
        print("signed in: no")
    return 0


# ----------------------------------------------------------------------------
# Catalogue / search subcommands
# ----------------------------------------------------------------------------


def cmd_search(args: argparse.Namespace) -> int:
    try:
        result = api.search(args.query, limit=args.limit)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    hits = result.get("results", [])
    if not hits:
        print("no results")
        return 0
    for h in hits:
        mark = "OK" if h.get("is_true") else "NO"
        print(f"{h['id']:<18} {mark} {_truncate(h.get('name', ''), 42):<42} {h.get('area', '')}")
    return 0


def cmd_rag(args: argparse.Namespace) -> int:
    try:
        result = api.rag(args.query, limit=args.limit, hops=args.hops)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    hits = result.get("hits", [])
    ctx = result.get("context", [])
    print(f"# {len(hits)} hits, {len(ctx)} context items")
    for h in hits:
        print(f"hit  {h['id']:<18} {_truncate(h.get('name', ''), 42)}")
    for c in ctx[: args.limit * (args.hops + 1)]:
        via = c.get("via")
        via_s = f" via={via}" if via else ""
        print(f"ctx  {c['id']:<18} d={c.get('depth', 0)}  {_truncate(c.get('name', ''), 38)}{via_s}")
    if args.save:
        api.save_query("rag", {"q": args.query, "limit": args.limit, "hops": args.hops}, label=args.save)
        print(f"saved as: {args.save}")
    return 0


def cmd_show(args: argparse.Namespace) -> int:
    try:
        result = api.show_node(args.id)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    node = result.get("node", {})
    print(f"id:    {node.get('id', args.id)}")
    print(f"name:  {node.get('name', '')}")
    print(f"label: {node.get('label', '')}")
    print(f"area:  {node.get('area', '')}")
    print(f"true:  {node.get('is_true')}")
    if node.get("minimal_explanation"):
        print()
        print(node["minimal_explanation"])
    return 0


def cmd_ops(args: argparse.Namespace) -> int:
    try:
        result = api.list_operators(tier=args.tier)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    for op in result.get("operators", []):
        print(f"{op['id']:<18} tier={op.get('tier', 0)} arity={op.get('arity', '?')}  {op.get('name', '')}")
    return 0


def cmd_stats(args: argparse.Namespace) -> int:
    try:
        result = api.graph_stats()
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0
    for k, v in result.items():
        print(f"{k}: {v if not isinstance(v, dict) else json.dumps(v)}")
    return 0


# ----------------------------------------------------------------------------
# Verify
# ----------------------------------------------------------------------------


def cmd_verify(args: argparse.Namespace) -> int:
    try:
        result = api.verify(args.equation, samples=args.samples, tolerance=args.tolerance)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0 if result.get("verified") else 1
    verified = result.get("verified")
    status = "OK" if verified else "NO"
    raw_residual = result.get("max_residual")
    max_residual = float(raw_residual) if raw_residual is not None else float("nan")
    print(
        f'{status} max_res={max_residual:.2e} '
        f'method="{result.get("method", "")}" form="{result.get("equation", args.equation)}"'
    )
    return 0 if verified else 1


# ----------------------------------------------------------------------------
# Prove (passes raw .mg source through to the cloud)
# ----------------------------------------------------------------------------


def cmd_prove(args: argparse.Namespace) -> int:
    try:
        with open(args.path, "r", encoding="utf-8") as f:
            source = f.read()
    except OSError as exc:
        _err(f"error: cannot read {args.path}: {exc}")
        return 2
    try:
        result = api.prove(source, no_diagnosis=args.no_diagnosis, stop_at_fail=args.stop_at_fail)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3
    if args.json:
        _print_json(result)
        return 0 if result.get("ok") else 1
    for s in result.get("steps", []):
        st = s.get("status", "?")
        print(f"step {s.get('ordinal'):>2}  {st:<8}  {s.get('label', '')}  res={s.get('residual', '')}")
    return 0 if result.get("ok") else 1


# ----------------------------------------------------------------------------
# Workspace: ingests + saved queries
# ----------------------------------------------------------------------------


def cmd_ingest(args: argparse.Namespace) -> int:
    """Add an equation to the user's per-user ingest workspace.

    Two modes:
      --latex '<expr>'     : direct latex string
      <path>               : read latex from a .tex/.md/.txt file (one equation
                             per line; lines starting with `%` are skipped).
    """
    items: list[str] = []
    if args.latex:
        items.append(args.latex)
    elif args.path:
        try:
            with open(args.path, "r", encoding="utf-8") as f:
                for raw in f:
                    line = raw.strip()
                    if not line or line.startswith("%") or line.startswith("#"):
                        continue
                    items.append(line)
        except OSError as exc:
            _err(f"error: cannot read {args.path}: {exc}")
            return 2
    else:
        _err("error: pass either --latex '<expr>' or a file path")
        return 2

    if not items:
        _err("error: nothing to ingest")
        return 2

    created: list[dict] = []
    for latex in items:
        # Best-effort: verify first so the stored row reflects truth.
        verified = False
        residual: float | None = None
        try:
            v = api.verify(latex)
            verified = bool(v.get("verified"))
            residual = float(v.get("max_residual", 0.0))
        except BackendError:
            pass

        try:
            row = api.create_ingest({
                "latex": latex,
                "source_path": args.path,
                "verified": verified,
                "residual": residual,
                "label": args.label,
            })
        except BackendError as exc:
            _err(f"error: {exc}")
            return 3
        created.append(row)

    if args.json:
        _print_json(created if len(created) > 1 else created[0])
        return 0
    for row in created:
        mark = "OK" if row.get("verified") else "NO"
        print(f"#{row['id']:<5} {mark} {_truncate(row.get('latex', ''), 60)}")
    return 0


def cmd_saved_queries(args: argparse.Namespace) -> int:
    """List, save (programmatically), or delete saved queries."""
    if args.delete is not None:
        try:
            api.delete("/api/me/saved-queries/" + str(args.delete))
        except BackendError as exc:
            _err(f"error: {exc}")
            return 3
        print(f"deleted #{args.delete}")
        return 0

    try:
        rows = api.list_saved_queries(kind=args.kind)
    except BackendError as exc:
        _err(f"error: {exc}")
        return 3

    if args.json:
        _print_json(rows)
        return 0
    if not rows:
        print("no saved queries")
        return 0
    for r in rows:
        label = r.get("label") or "(unlabeled)"
        q = json.dumps(r.get("query", {}))
        print(f"#{r['id']:<5} {r.get('kind', '?'):<8} {_truncate(label, 30):<30} {_truncate(q, 60)}")
    return 0


# ----------------------------------------------------------------------------
# Argparse setup
# ----------------------------------------------------------------------------


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="rigorxrigor",
        description="Cloud CLI for the RigorXRigor knowledge graph.",
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    sub = p.add_subparsers(dest="cmd", required=True)

    # auth
    sp = sub.add_parser("login", help="Sign in via your browser (PKCE to WorkOS).")
    sp.add_argument("--no-browser", action="store_true", help="Print the auth URL instead of opening it.")
    sp.add_argument("--timeout", type=int, default=300, help="Login timeout in seconds (default 300).")
    sp.set_defaults(func=cmd_login)

    sp = sub.add_parser("signup", help="Create a free account via your browser (PKCE to WorkOS).")
    sp.add_argument("--no-browser", action="store_true", help="Print the signup URL instead of opening it.")
    sp.add_argument("--timeout", type=int, default=300, help="Signup timeout in seconds (default 300).")
    sp.set_defaults(func=cmd_signup)

    sp = sub.add_parser("logout", help="Forget local credentials.")
    sp.set_defaults(func=cmd_logout)

    sp = sub.add_parser("whoami", help="Show signed-in identity + subscription.")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_whoami)

    sp = sub.add_parser("config", help="View or update CLI config.")
    sp.add_argument("--set-server", metavar="URL", help="Override the API server URL.")
    sp.set_defaults(func=cmd_config)

    sp = sub.add_parser("status", help="Show API health and local sign-in state.")
    sp.set_defaults(func=cmd_status)

    # catalogue
    sp = sub.add_parser("search", help="Keyword + hybrid search over the catalogue.")
    sp.add_argument("query")
    sp.add_argument("-n", "--limit", type=int, default=20)
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_search)

    sp = sub.add_parser("rag", help="Retrieval-augmented context pack with BFS expansion.")
    sp.add_argument("query")
    sp.add_argument("-k", "--limit", type=int, default=8)
    sp.add_argument("-H", "--hops", type=int, default=1)
    sp.add_argument("--save", metavar="LABEL", help="Save the query under LABEL in your workspace.")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_rag)

    sp = sub.add_parser("show", help="Show a single node by id.")
    sp.add_argument("id")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_show)

    sp = sub.add_parser("ops", help="List operators (optionally by tier).")
    sp.add_argument("--tier", type=int, default=None)
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_ops)

    sp = sub.add_parser("stats", help="Graph statistics.")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_stats)

    # verify / prove
    sp = sub.add_parser("verify", help="Verify a mathematical equation numerically.")
    sp.add_argument("equation")
    sp.add_argument("--samples", type=int, default=10)
    sp.add_argument("--tolerance", type=float, default=1e-6)
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_verify)

    sp = sub.add_parser("prove", help="Lint a `.mg` proof file step-by-step.")
    sp.add_argument("path")
    sp.add_argument("--no-diagnosis", action="store_true")
    sp.add_argument("--stop-at-fail", action="store_true")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_prove)

    # workspace
    sp = sub.add_parser("ingest", help="Add equation(s) to your per-user workspace.")
    sp.add_argument("path", nargs="?", help="File of equations, one per line. Omit to use --latex.")
    sp.add_argument("--latex", help="A single LaTeX equation to ingest.")
    sp.add_argument("--label", help="Optional label for the ingest row(s).")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_ingest)

    sp = sub.add_parser("saved-queries", help="List or delete saved queries.")
    sp.add_argument("--kind", choices=["rag", "search", "discover", "verify", "prove"], default=None)
    sp.add_argument("--delete", type=int, metavar="ID", help="Delete the saved query with this id.")
    sp.add_argument("--json", action="store_true")
    sp.set_defaults(func=cmd_saved_queries)

    return p


def main(argv: list[str] | None = None) -> int:
    _configure_stdio()
    parser = _build_parser()
    args = parser.parse_args(argv)
    try:
        return int(args.func(args))
    except AuthMissing as exc:
        _err(str(exc))
        return 3
    except KeyboardInterrupt:
        _err("aborted")
        return 130


if __name__ == "__main__":
    sys.exit(main())
