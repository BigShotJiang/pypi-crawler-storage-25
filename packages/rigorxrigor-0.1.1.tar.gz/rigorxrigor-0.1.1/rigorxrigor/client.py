"""HTTP client for the RigorXRigor cloud API.

Handles auth token discovery, refresh, and the actual REST calls. Every method
that hits the API will:
1. Resolve a valid access token (refreshing if stale).
2. Inject `Authorization: Bearer ...`.
3. On 401, attempt one refresh + retry.
4. On other errors, raise BackendError so the CLI can render them.
"""
from __future__ import annotations

import time
from typing import Any

import httpx

from . import config, workos
from .config import StoredAuth


class BackendError(Exception):
    """Non-2xx response from the API."""

    def __init__(self, status: int, message: str, payload: Any | None = None) -> None:
        super().__init__(f"{status}: {message}")
        self.status = status
        self.message = message
        self.payload = payload


class AuthMissing(Exception):
    """No valid auth available; user must run `rigorxrigor login`."""


def _resolve_auth() -> StoredAuth | None:
    """Return credentials from the local RigorXRigor auth store."""
    return config.load()


def get_valid_token(*, force_refresh: bool = False) -> str:
    """Return a usable access token, refreshing if stale. Raise AuthMissing
    if no credentials are available at all."""
    auth = _resolve_auth()
    if auth is None or not auth.access_token:
        raise AuthMissing("not signed in; run `rigorxrigor login`")
    if not force_refresh and not workos.is_token_stale(auth.expires_at):
        return auth.access_token
    if not auth.refresh_token:
        raise AuthMissing("token expired and no refresh_token available; run `rigorxrigor login`")
    try:
        refreshed = workos.refresh_access_token(auth.refresh_token)
    except RuntimeError as exc:
        raise AuthMissing(f"token refresh failed; run `rigorxrigor login`: {exc}") from exc
    auth.access_token = refreshed["access_token"]
    auth.refresh_token = refreshed.get("refresh_token") or auth.refresh_token
    auth.expires_at = time.time() + float(refreshed.get("expires_in", 3600))
    if "user" in refreshed:
        auth.user = refreshed["user"]
    config.save(auth)
    return auth.access_token


# ---------------------------------------------------------------------------
# HTTP plumbing
# ---------------------------------------------------------------------------


def _base_url() -> str:
    return config.server_url().rstrip("/")


def _request(method: str, path: str, *, params: dict | None = None, json_body: Any = None) -> Any:
    url = _base_url() + path
    token = get_valid_token()
    headers = {"Authorization": f"Bearer {token}"}
    with httpx.Client(timeout=60.0) as client:
        resp = client.request(method, url, headers=headers, params=params, json=json_body)
        if resp.status_code == 401:
            # The backend is authoritative; force a refresh even if local expiry
            # metadata says the token should still be usable.
            try:
                token = get_valid_token(force_refresh=True)
            except AuthMissing:
                raise BackendError(401, "unauthorized")
            headers["Authorization"] = f"Bearer {token}"
            resp = client.request(method, url, headers=headers, params=params, json=json_body)
        if resp.status_code >= 400:
            payload: Any | None = None
            try:
                payload = resp.json()
                detail = payload.get("detail") or payload.get("message") or payload.get("error") or resp.text
            except Exception:
                detail = resp.text
            if resp.status_code == 402 and isinstance(payload, dict):
                required = payload.get("credits_required")
                remaining = payload.get("credits_remaining")
                billing_url = payload.get("billing_url") or "https://app.rigorxrigor.com/billing"
                detail = (
                    f"insufficient credits: this request needs {required} credits, "
                    f"but you have {remaining}. Buy credits or manage billing: {billing_url}"
                )
            raise BackendError(resp.status_code, str(detail)[:500], payload=payload)
        if resp.status_code == 204:
            return None
        return resp.json()


def get(path: str, **params: Any) -> Any:
    return _request("GET", path, params=params or None)


def post(path: str, body: Any = None) -> Any:
    return _request("POST", path, json_body=body or {})


def delete(path: str) -> Any:
    return _request("DELETE", path)


# ---------------------------------------------------------------------------
# Endpoint shortcuts
# ---------------------------------------------------------------------------


def me() -> dict:
    return get("/api/me")


def health() -> dict:
    """Public; doesn't need a token, but we use the helper for consistency.
    Calls without a token if none is set."""
    url = _base_url() + "/health"
    with httpx.Client(timeout=10.0) as client:
        return client.get(url).json()


def verify(equation: str, samples: int = 10, tolerance: float = 1e-6) -> dict:
    return post("/verify", {"equation": equation, "samples": samples, "tolerance": tolerance})


def search(q: str, limit: int = 20) -> dict:
    return get("/search", q=q, limit=limit)


def rag(q: str, limit: int = 8, hops: int = 1) -> dict:
    return get("/rag/query", q=q, limit=limit, hops=hops)


def show_node(node_id: str) -> dict:
    return get(f"/nodes/{node_id}")


def list_nodes(**filters: Any) -> dict:
    return get("/nodes", **{k: v for k, v in filters.items() if v is not None})


def list_operators(tier: int | None = None) -> dict:
    if tier is None:
        return get("/operators")
    return get("/operators", tier=tier)


def graph_stats() -> dict:
    return get("/graph/stats")


def prove(source: str, **kwargs: Any) -> dict:
    return post("/v1/prove", {"source": source, **kwargs})


def discover(payload: dict) -> dict:
    return post("/v1/discover", payload)


# ---------------------------------------------------------------------------
# Per-user workspace
# ---------------------------------------------------------------------------


def list_saved_queries(kind: str | None = None) -> list[dict]:
    return get("/api/me/saved-queries", **({"kind": kind} if kind else {}))


def save_query(kind: str, query: dict, label: str | None = None) -> dict:
    return post("/api/me/saved-queries", {"kind": kind, "query": query, "label": label})


def list_ingests() -> list[dict]:
    return get("/api/me/ingests")


def create_ingest(payload: dict) -> dict:
    return post("/api/me/ingests", payload)
