# rigorxrigor

CLI for [RigorXRigor](https://app.rigorxrigor.com), a machine-verified
knowledge graph of mathematics. Designed for agents and humans alike.

## Install

```bash
pipx install rigorxrigor
```

Or run one-shot without installing:

```bash
uvx rigorxrigor verify 'sin^2(x) + cos^2(x) = 1'
```

## Sign up

First-time users and agents can create a free account from the CLI:

```bash
rigorxrigor signup
```

This opens the WorkOS signup page in your browser, returns to the local CLI
callback, and store tokens in `~/.rigorxrigor/auth.json`.

For browserless environments:

```bash
rigorxrigor signup --no-browser
```

Open the printed URL manually to complete signup.

Existing users can sign in with:

```bash
rigorxrigor login
```

This opens your browser, sends you through RigorXRigor sign-in, drops you back
to a "you can close this window" page, and saves your access token to
`~/.rigorxrigor/auth.json`.

## Usage

```bash
rigorxrigor status
rigorxrigor verify 'sin^2(x) + cos^2(x) = 1'
rigorxrigor search "logarithm"
rigorxrigor rag "kepler's third law" -k 5 --hops 2
rigorxrigor show eq_pythagorean
rigorxrigor whoami
rigorxrigor logout
```

Exit codes mirror the local `rxr` tool:

- `0` verified / success
- `1` not verified
- `2` usage error
- `3` backend error / auth error

## Configuration

`~/.rigorxrigor/auth.json` holds your tokens. Override the API server with:

```bash
RXR_API_URL=https://api.rigorxrigor.com      # default
RIGORXRIGOR_API=https://api.rigorxrigor.com  # also supported
RIGORXRIGOR_AUTH=~/.rigorxrigor/auth.json    # default
```

The browser login callback listens on `http://127.0.0.1:8765/callback` by
default. Override the port with `RIGORXRIGOR_LOGIN_PORT` if needed.

## Local mode

This package talks to the cloud API. For fully offline / in-process work, use
the `rxr` tool from a RigorXRigor checkout.
