#!/usr/bin/env python3
"""rxr — RigorXRigor command-line interface.

Designed to be called by LLMs, so output is compact and line-oriented:
the default format is one line per row, no indented JSON, no tables
unless you ask. Use --json to get machine-readable output.

Subcommands:
    verify <equation>           Check an equation (LaTeX by default)
    reduce <op_id>              Print an operator's canonical reduction
    search <query>              Find equations/operators by name/tag
    rag <query>                 Retrieval-augmented context pack
    show <id>                   Print a single node's detail
    ops [--tier N]              List operators
    latex2eml <latex>           Show just the conversion
    stats                       Graph statistics

Exit codes:
    0   verified (for `verify`) or success
    1   not verified
    2   usage / input error
    3   backend error

The CLI prefers a running server at 127.0.0.1:$RXR_PORT (default
8890); if the server is unreachable it imports the in-tree modules and
runs the logic in-process. Either path produces identical output.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import warnings
from collections import Counter
from pathlib import Path
from typing import Any

# Quiet sympy's antlr deprecation chatter — the CLI is for LLMs.
warnings.filterwarnings("ignore")

# --- Path bootstrap so `rxr` can be called from anywhere ------------------
HERE = Path(__file__).resolve().parent
WORKFLOW = HERE.parent
SERVER_DIR = WORKFLOW / "server"
if str(SERVER_DIR) not in sys.path:
    sys.path.insert(0, str(SERVER_DIR))


PORT = int(os.environ.get("RXR_PORT", "8890"))
BASE = f"http://127.0.0.1:{PORT}"


# --- Tiny HTTP helper (urllib, no requests dependency) --------------------
def _http_get(path: str, timeout: float = 2.0) -> Any | None:
    import urllib.request
    try:
        with urllib.request.urlopen(BASE + path, timeout=timeout) as r:
            return json.loads(r.read())
    except Exception:
        return None


def _http_post(path: str, body: dict, timeout: float = 30.0) -> Any | None:
    import urllib.request
    try:
        req = urllib.request.Request(
            BASE + path,
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read())
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read())
        except Exception:
            return {"error": str(e)}
    except Exception:
        return None


def _server_up() -> bool:
    import urllib.request
    try:
        urllib.request.urlopen(BASE + "/", timeout=0.6).read()
        return True
    except Exception:
        return False


# --- In-process fallback --------------------------------------------------
_local_store: Any | None = None


def _local():
    """Return (store, eqdb, modules) — imported once and cached."""
    global _local_store
    if _local_store is not None:
        return _local_store
    from graph_store import GraphStore  # type: ignore
    from equation_db import EquationDB  # type: ignore
    from operators import load_catalogue, merge_into  # type: ignore
    data_dir = WORKFLOW / "data"
    store = GraphStore(data_dir)
    merge_into(store, load_catalogue(data_dir))
    eqdb = EquationDB(store)
    _local_store = (store, eqdb)
    return _local_store


# --- Formatting helpers ---------------------------------------------------
def _fmt_hit(h: dict) -> str:
    mark = "✓" if h.get("is_true") else "✗"
    return f"{h['id']:<16} {mark} {h.get('name','')[:42]:<42} {h.get('area','')}"


def _fmt_operator(o: dict) -> str:
    tier = o.get("tier", 0)
    red = o.get("eml_reduction") or ""
    return f"{o['id']:<16} tier={tier} depth={o.get('eml_depth', 0)}  {o['name']:<32} {red}"


def _print_json(obj: Any) -> None:
    json.dump(obj, sys.stdout, separators=(",", ":"), ensure_ascii=False)
    sys.stdout.write("\n")


def _candidate_formula_for_node(node: dict[str, Any]) -> str:
    node_id = node.get("id")
    pack_id = node.get("pack_id")
    if not node_id or not pack_id:
        return ""
    candidates_path = WORKFLOW / "data" / "packs_staging" / pack_id / "candidates.jsonl"
    if not candidates_path.exists():
        return ""
    try:
        with candidates_path.open("r", encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                cand = json.loads(line)
                if cand.get("id") == node_id:
                    return str(cand.get("formula") or cand.get("latex") or "")
    except Exception:
        return ""
    return ""


# --- Subcommands ----------------------------------------------------------
def cmd_verify(args: argparse.Namespace) -> int:
    original_equation = args.equation
    equation = args.equation
    fmt = args.format
    # "canonical" is the supported public name for the internal s-expr format.
    if fmt == "canonical":
        fmt = "eml"

    auto_detected = fmt == "auto"
    # Auto-detect LaTeX vs EML unless explicitly told otherwise. Rule:
    #   * backslashes / braces → LaTeX
    #   * a stored node id (no spaces, no parens) → pass through as EML
    #   * starts with a bare lowercase word followed by "(" + no top-level
    #     infix → EML s-expr
    #   * otherwise → assume LaTeX (user typed math naturally)
    if fmt == "auto":
        if any(c in equation for c in "\\{}"):
            fmt = "latex"
        elif _ambiguous_eml_infix(equation) and not _has_top_level_relation(equation):
            print(
                "error: ambiguous format: function-call syntax with top-level infix "
                "operator. Pass -f canonical for EML or -f latex for infix math.",
                file=sys.stderr,
            )
            return 2
        elif _ambiguous_eml_infix(equation):
            # Common natural-math equation form, e.g. `sin(x)/x = 1`.
            # The top-level relation makes the user's intent clear enough to
            # route through the infix parser in auto mode.
            fmt = "latex"
        elif _looks_like_eml(equation):
            fmt = "eml"
        elif "(" not in equation and "=" not in equation:
            # treat short tokens (e.g. "id_pyth") as node ids, which /verify
            # endpoint resolves — feed straight through as EML-path input
            fmt = "eml"
        else:
            fmt = "latex"

    try:
        bindings = _parse_bindings(getattr(args, "bind", None))
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if fmt == "latex":
        from latex_eml import infix_to_eml_string, latex_to_eml_string  # type: ignore
        try:
            equation = (
                latex_to_eml_string(equation)
                if any(c in equation for c in "\\{}")
                else infix_to_eml_string(equation)
            )
        except Exception as exc:
            print(f"error: math parse: {exc}", file=sys.stderr)
            return 2
    elif fmt == "eml" and _has_top_level_infix_math(equation):
        # Be forgiving: users often read "-f eml" as "verify this equation
        # in the EML system", not "I promise the RHS is already canonical
        # s-expression syntax". Canonical inputs like add(a,b) pass through;
        # infix inputs are normalized first so they do not produce a
        # misleading NO with zero residuals.
        from latex_eml import infix_to_eml_string  # type: ignore
        try:
            equation = infix_to_eml_string(equation)
        except Exception as exc:
            print(f"error: eml/infix parse: {exc}", file=sys.stderr)
            return 2

    # Parse per-variable domain overrides: `x=lo,hi` repeatable.
    domain_overrides: dict[str, tuple[float, float]] = {}
    for spec in (getattr(args, "domain", None) or []):
        if "=" not in spec:
            print(f"error: --domain expects var=lo,hi (got {spec!r})", file=sys.stderr)
            return 2
        var, rng_s = spec.split("=", 1)
        var = var.strip()
        parts = rng_s.split(",")
        if len(parts) != 2:
            print(f"error: --domain range must be lo,hi (got {spec!r})", file=sys.stderr)
            return 2
        try:
            lo = float(parts[0])
            hi = float(parts[1])
        except ValueError:
            print(f"error: --domain bounds must be numeric (got {spec!r})", file=sys.stderr)
            return 2
        if lo > hi:
            lo, hi = hi, lo
        domain_overrides[var] = (lo, hi)

    # Phase 2A.5: --assume var:domain (repeatable). Each entry becomes a
    # ``Node.assumptions``-shaped dict that flows through both numeric
    # and symbolic verifiers. Validate eagerly via parse_assumptions so
    # an unknown domain produces a clear CLI error before HTTP/server
    # round-trips.
    cli_assumptions: list[dict[str, str]] = []
    for spec in (getattr(args, "assume", None) or []):
        if ":" not in spec:
            print(f"error: --assume expects var:domain (got {spec!r})", file=sys.stderr)
            return 2
        var, domain = spec.split(":", 1)
        var = var.strip()
        domain = domain.strip()
        if not var or not domain:
            print(f"error: --assume both var and domain required (got {spec!r})", file=sys.stderr)
            return 2
        cli_assumptions.append({"var": var, "in": domain})
    if cli_assumptions:
        try:
            from domains import parse_assumptions  # type: ignore
            parse_assumptions(cli_assumptions)
        except Exception as exc:  # noqa: BLE001
            print(f"error: --assume {exc}", file=sys.stderr)
            return 2

    # If the user supplied explicit domains, bypass verify_equation and run the
    # numeric sampling loop ourselves so we can override ranges per variable.
    if domain_overrides and not args.symbolic:
        try:
            from verify import (  # type: ignore
                parse,
                split_relation,
                evaluate,
                EvalContext,
                find_free_vars,
                sample_env,
                _relation_satisfied,
            )
            import random
        except Exception as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 3
        try:
            lhs_s, rhs_s, relation = split_relation(equation)
            lhs = parse(lhs_s)
            rhs = parse(rhs_s)
        except Exception as exc:
            print(f"error: parse: {exc}", file=sys.stderr)
            return 2
        free = (find_free_vars(lhs) | find_free_vars(rhs)) - set(bindings)
        rng = random.Random(7)
        max_residual = 0.0
        all_ok = True
        tested = 0
        counterexample: dict[str, Any] | None = None
        _sym_map = {"eq": "=", "le": "<=", "ge": ">=", "lt": "<", "gt": ">"}
        # Assumption-derived sample ranges flow into this manual sampling
        # loop too: --assume fills in any var not pinned by --domain.
        assumption_domain: dict[str, tuple[float, float]] = {}
        if cli_assumptions:
            try:
                from domains import merge_sample_domain  # type: ignore
                assumption_domain = merge_sample_domain(cli_assumptions, None)
            except Exception:  # noqa: BLE001
                assumption_domain = {}
        for _ in range(max(1, args.samples)):
            env = sample_env(free, sample_domain=assumption_domain or None, rng=rng)
            for var, (lo, hi) in domain_overrides.items():
                if var in free:
                    env[var] = rng.uniform(lo, hi)
            env.update(bindings)
            ctx_l = EvalContext(env=dict(env), trace=[])
            ctx_r = EvalContext(env=dict(env), trace=[])
            try:
                lv_raw = evaluate(lhs, ctx_l)
                rv_raw = evaluate(rhs, ctx_r)
                if isinstance(lv_raw, complex) or isinstance(rv_raw, complex):
                    lv = complex(lv_raw)
                    rv = complex(rv_raw)
                else:
                    lv = float(lv_raw)
                    rv = float(rv_raw)
            except Exception:
                all_ok = False
                max_residual = float("inf")
                tested += 1
                continue
            ok, residual = _relation_satisfied(lv, rv, relation, args.tolerance)
            if not ok:
                all_ok = False
                if counterexample is None:
                    lv_out = [lv.real, lv.imag] if isinstance(lv, complex) else lv
                    rv_out = [rv.real, rv.imag] if isinstance(rv, complex) else rv
                    counterexample = {
                        "env": dict(env),
                        "lhs": lv_out,
                        "rhs": rv_out,
                        "relation": relation,
                        "relation_symbol": _sym_map[relation],
                    }
            max_residual = max(max_residual, residual)
            tested += 1
        _sym = _sym_map[relation]
        method_suffix = "" if relation == "eq" else f" ({_sym})"
        result = {
            "equation": equation,
            "verified": all_ok,
            "method": f"canonical numeric sampling (domain override){method_suffix}",
            "samples_tested": tested,
            "residuals": [],
            "max_residual": max_residual,
            "free_vars": sorted(free),
            "relation": relation,
        }
        if counterexample is not None:
            result["counterexample"] = counterexample
        if args.json:
            _print_json(result)
            return 0 if all_ok else 1
        status = "OK" if all_ok else "NO"
        print(f"{status} max_res={max_residual:.2e} form=\"{equation}\"")
        if counterexample is not None:
            env_str = " ".join(f"{k}={v:g}" if isinstance(v, (int, float)) else f"{k}={v}"
                               for k, v in counterexample["env"].items())
            print(f"  counterexample: {env_str} -> {counterexample['lhs']} {_sym} {counterexample['rhs']}")
        return 0 if all_ok else 1

    # Prefer server, fall back to in-process.
    def _looks_like_parse_error(r: Any) -> bool:
        if not isinstance(r, dict):
            return False
        if "verified" in r:
            return False
        detail = str(r.get("detail") or r.get("error") or "")
        return "verify failed" in detail or "trailing tokens" in detail or "bad expression" in detail

    def _attempt(eq: str) -> Any | None:
        body = {"equation": eq, "samples": args.samples, "tolerance": args.tolerance}
        if bindings:
            body["bindings"] = bindings
        # Phase 2A.5: forward CLI assumptions through both server and
        # in-process paths. Server-side, the /verify and /verify/symbolic
        # endpoints already merge req.assumptions with any matched-node
        # assumptions (request wins on conflict).
        if cli_assumptions:
            body["assumptions"] = cli_assumptions
        if args.symbolic:
            if _server_up():
                r = _http_post("/verify/symbolic", body)
                if r is not None:
                    return r
            try:
                from symbolic import verify_symbolic  # type: ignore
                r = verify_symbolic(eq, assumptions=cli_assumptions or None)
                r["equation"] = eq
                return r
            except Exception as exc:
                return {"error": str(exc)}
        if _server_up():
            r = _http_post("/verify", body)
            if r is not None:
                return r
        try:
            from verify import verify_equation  # type: ignore
            return verify_equation(
                eq,
                samples=args.samples,
                tolerance=args.tolerance,
                assumptions=cli_assumptions or None,
                bindings=bindings or None,
            )
        except Exception as exc:
            return {"error": str(exc)}

    result = _attempt(equation)

    # If auto-detection picked EML but the parser rejected it (e.g. `exp(a)/(...)` —
    # starts like an EML call but uses infix `/`), fall back to LaTeX.
    if auto_detected and fmt == "eml" and _looks_like_parse_error(result):
        try:
            from latex_eml import infix_to_eml_string  # type: ignore
            converted = infix_to_eml_string(original_equation)
        except Exception:
            converted = None
        if converted and converted != original_equation:
            fallback = _attempt(converted)
            if isinstance(fallback, dict) and "verified" in fallback:
                equation = converted
                result = fallback
                fmt = "latex"  # display only; actual submission already happened

    if not isinstance(result, dict) or ("verified" not in result and "error" in result):
        err = (result or {}).get("error") or (result or {}).get("detail") or "verify failed"
        print(f"error: {err}", file=sys.stderr)
        return 3

    if args.json:
        _print_json(result)
        return 0 if result.get("verified") else 1

    verified = result.get("verified")
    method = (result.get("method") or "").lower()
    eq_display = result.get("equation", equation)
    if method.startswith("definition") or method.startswith("symbolic-definition"):
        # Definitional short-circuit: the LHS is a dependent variable that
        # doesn't appear on the RHS, so we accept the equation as a
        # definition rather than sampling it. Print a distinct OK line so
        # this is obvious during debugging / auditing.
        status = "OK" if verified else "NO"
        dep = result.get("dependent_var") or ""
        dep_note = f" dep={dep}" if dep else ""
        print(f"{status} def  form=\"{eq_display}\"{dep_note}")
        print("  warn: trivial definition shape; verification proves nothing about the RHS")
    elif "symbolic" in method or "simplify" in method:
        status = "OK" if verified else ("??" if verified is None else "NO")
        residual = result.get("residual") or ""
        note = result.get("notes") or ""
        extras = f" {note}" if note else ""
        print(f"{status} sym  form=\"{eq_display}\"  residual={residual}{extras}")
    else:
        max_res = result.get("max_residual", 0.0)
        status = "OK" if verified else "NO"
        notes = result.get("notes") or ""
        extras = f" {notes}" if notes else ""
        print(f"{status} max_res={max_res:.2e} form=\"{eq_display}\"{extras}")
        # Surface the concrete counterexample on a violated inequality —
        # cheaper than parsing residuals out of the JSON.
        if not verified and isinstance(result.get("counterexample"), dict):
            cex = result["counterexample"]
            env_str = " ".join(f"{k}={v:g}" if isinstance(v, (int, float)) else f"{k}={v}"
                               for k, v in (cex.get("env") or {}).items())
            sym = cex.get("relation_symbol") or "?"
            lhs_v = cex.get("lhs")
            rhs_v = cex.get("rhs")
            print(f"  counterexample: {env_str} -> {lhs_v} {sym} {rhs_v}")
    return 0 if verified else 1


def _parse_bindings(specs: list[str] | None) -> dict[str, float]:
    bindings: dict[str, float] = {}
    from latex_eml import infix_to_eml_string  # type: ignore
    from verify import EvalContext, evaluate, find_free_vars, parse  # type: ignore

    for spec in specs or []:
        if "=" not in spec:
            raise ValueError(f"--bind expects NAME=VALUE (got {spec!r})")
        name, value_s = spec.split("=", 1)
        name = name.strip()
        if not name:
            raise ValueError(f"--bind name is empty in {spec!r}")
        try:
            eml = infix_to_eml_string(value_s)
            tree = parse(eml)
            missing = find_free_vars(tree)
            if missing:
                raise ValueError(
                    f"--bind value may contain only numeric arithmetic in {spec!r}; "
                    f"found symbols: {', '.join(sorted(missing))}"
                )
            bindings[name] = float(evaluate(tree, EvalContext(env={}, trace=[], strict_symbols=True)))
        except ValueError:
            raise
        except Exception as exc:  # noqa: BLE001
            raise ValueError(f"--bind value could not be evaluated in {spec!r}: {exc}") from None
    return bindings


def _local_solve(expression: str, solve_for: str, bindings: dict[str, float], units: dict[str, str], notes: str) -> dict[str, Any]:
    """Algebraically solve expression for solve_for using sympy."""
    try:
        import sympy  # noqa: PLC0415
    except ImportError as exc:
        raise ValueError(f"sympy is required for --solve-for: {exc}") from exc

    if "=" not in expression:
        raise ValueError("--solve-for requires an equation containing '='")

    lhs_str, rhs_str = expression.split("=", 1)
    lhs_str = lhs_str.strip().replace("^", "**")
    rhs_str = rhs_str.strip().replace("^", "**")

    try:
        lhs_sym = sympy.sympify(lhs_str)
        rhs_sym = sympy.sympify(rhs_str)
    except Exception as exc:
        raise ValueError(f"sympy parse failed: {exc}") from exc

    sym_var = sympy.Symbol(solve_for)
    eq_expr = lhs_sym - rhs_sym

    if sym_var not in eq_expr.free_symbols:
        raise ValueError(f"variable {solve_for!r} does not appear in the equation")

    solutions = sympy.solve(eq_expr, sym_var)
    if not solutions:
        raise ValueError(f"no solution found for {solve_for!r}")

    sol_strs = [str(s) for s in solutions]
    numeric = None
    if solutions:
        sub_map = {sympy.Symbol(k): v for k, v in bindings.items()}
        substituted = solutions[0].subs(sub_map)
        if not substituted.free_symbols:
            try:
                numeric = float(substituted.evalf())
            except Exception:
                pass

    value: Any = numeric if numeric is not None else (sol_strs[0] if len(solutions) == 1 else sol_strs)
    solved_notes = notes + (f"; solved for {solve_for}" if notes else f"solved for {solve_for}")
    if len(solutions) > 1:
        solved_notes += f"; {len(solutions)} solutions found"

    return {
        "expression": expression,
        "evaluated": expression,
        "value": value,
        "bindings": bindings,
        "target": solve_for,
        "solved": True,
        "all_solutions": sol_strs,
        "notes": solved_notes,
        "units": units,
    }


def _local_calculate(
    expression: str,
    bindings: dict[str, float],
    target: str | None,
    *,
    allow_partial: bool = False,
    caller_units: dict[str, str] | None = None,
    solve_for: str | None = None,
) -> dict[str, Any]:
    import re
    from verify import EvalContext, evaluate, find_free_vars, parse, split_relation  # type: ignore

    store, _ = _local()
    notes = ""
    node_units: dict[str, str] = {}
    node = store.get_node(expression)
    if node is not None:
        formula = (
            str(node.get("formula") or "")
            or _candidate_formula_for_node(node)
            or str(node.get("eml_form") or "")
            or str(node.get("label") or "")
        )
        if not formula:
            raise ValueError(f"node {expression} has no calculable formula")
        notes = f"resolved {expression} -> {node.get('name')}"
        node_units = node.get("units") or {}
        expression_for_eval = formula
    else:
        expression_for_eval = expression
    units: dict[str, str] = {**node_units, **(caller_units or {})}

    if solve_for:
        return _local_solve(expression_for_eval, solve_for, bindings, units, notes)

    if not _looks_like_eml(expression_for_eval) and (
        _has_top_level_relation(expression_for_eval)
        or _has_top_level_infix_math(expression_for_eval)
        or any(c in expression_for_eval for c in "*/^()")
    ):
        if any(c in expression_for_eval for c in "\\{}"):
            from latex_eml import latex_to_eml_string  # type: ignore
            expression_for_eval = latex_to_eml_string(expression_for_eval)
        else:
            from latex_eml import infix_to_eml_string  # type: ignore
            expression_for_eval = infix_to_eml_string(expression_for_eval)

    def _eval(expr: str) -> Any:
        return evaluate(parse(expr), EvalContext(env=dict(bindings), trace=[], strict_symbols=True))

    def _partial(expr: str, selected_target: str | None) -> dict[str, Any] | None:
        missing = sorted(v for v in find_free_vars(parse(expr)) if v not in bindings)
        if not missing:
            return None
        if not allow_partial:
            raise ValueError(
                "missing bindings: "
                + ", ".join(missing)
                + " (add -b NAME=VALUE or pass --partial)"
            )
        return {
            "expression": expression,
            "evaluated": expression_for_eval,
            "value": expr,
            "bindings": bindings,
            "target": selected_target,
            "missing_symbols": missing,
            "partial": True,
            "notes": notes,
            "units": units,
        }

    try:
        lhs_s, rhs_s, _rel = split_relation(expression_for_eval)
    except ValueError:
        partial = _partial(expression_for_eval, target)
        if partial is not None:
            return partial
        return {
            "expression": expression,
            "evaluated": expression_for_eval,
            "value": _eval(expression_for_eval),
            "bindings": bindings,
            "target": target,
            "notes": notes,
            "units": units,
        }

    lhs_value = None
    rhs_value = None
    try:
        lhs_value = _eval(lhs_s)
        rhs_value = _eval(rhs_s)
    except Exception:
        pass

    selected = rhs_s
    selected_target = target
    if target:
        lowered = target.lower()
        if lowered in {"lhs", "left"}:
            selected = lhs_s
        elif lowered in {"rhs", "right"}:
            selected = rhs_s
        elif lhs_s.strip() == target:
            selected = rhs_s
        elif rhs_s.strip() == target:
            selected = lhs_s
        else:
            raise ValueError(f"target {target!r} does not match relation sides")
    elif re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", lhs_s.strip()):
        selected_target = lhs_s.strip()

    partial = _partial(selected, selected_target)
    if partial is not None:
        return partial

    residual = None
    if lhs_value is not None and rhs_value is not None:
        try:
            residual = float(abs(lhs_value - rhs_value))
        except Exception:
            residual = None
    return {
        "expression": expression,
        "evaluated": expression_for_eval,
        "value": _eval(selected),
        "bindings": bindings,
        "target": selected_target,
        "lhs": lhs_value,
        "rhs": rhs_value,
        "residual": residual,
        "notes": notes,
        "units": units,
    }


def _parse_units(specs: list[str] | None) -> dict[str, str]:
    units: dict[str, str] = {}
    for spec in specs or []:
        if ":" not in spec:
            raise ValueError(f"--unit expects VAR:UNIT (got {spec!r})")
        var, unit = spec.split(":", 1)
        var = var.strip()
        if not var:
            raise ValueError(f"--unit variable name is empty in {spec!r}")
        units[var] = unit.strip()
    return units


def cmd_calc(args: argparse.Namespace) -> int:
    try:
        bindings = _parse_bindings(args.bind)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    try:
        caller_units = _parse_units(getattr(args, "unit", None))
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    solve_for: str | None = getattr(args, "solve_for", None) or None
    body = {
        "expression": args.expression,
        "bindings": bindings,
        "target": args.target,
        "allow_partial": args.partial,
        "units": caller_units,
    }
    if solve_for:
        body["solve_for"] = solve_for
    result: Any | None = None
    if _server_up():
        result = _http_post("/calculate", body)
    if result is None:
        try:
            result = _local_calculate(
                args.expression, bindings, args.target,
                allow_partial=args.partial, caller_units=caller_units, solve_for=solve_for,
            )
        except Exception as exc:  # noqa: BLE001
            print(f"error: calculate failed: {exc}", file=sys.stderr)
            return 2
    if not isinstance(result, dict) or "value" not in result:
        err = (result or {}).get("error") or (result or {}).get("detail") or "calculate failed"
        if isinstance(err, dict):
            missing = err.get("missing_symbols") or []
            msg = err.get("message") or err.get("error") or "calculate failed"
            if missing:
                msg = f"{msg}; missing: {', '.join(missing)}"
            err = msg
        print(f"error: {err}", file=sys.stderr)
        return 3
    if args.json:
        _print_json(result)
        return 0
    target = result.get("target")
    label = f"{target} = " if target else "value = "
    result_units: dict[str, str] = result.get("units") or {}
    target_unit = result_units.get(target) if target else None
    unit_suffix = f"  [{target_unit}]" if target_unit else ""
    print(f"{label}{result.get('value')}{unit_suffix}")
    if result.get("solved") and result.get("all_solutions") and len(result["all_solutions"]) > 1:
        print(f"  all solutions: {', '.join(result['all_solutions'])}")
    if result.get("partial") and result.get("missing_symbols"):
        print(f"  missing: {', '.join(result.get('missing_symbols') or [])}")
    if args.show_formula:
        print(f"  form: {result.get('evaluated')}")
    if result.get("residual") is not None:
        print(f"  residual: {result.get('residual')}")
    if result.get("notes"):
        print(f"  note: {result.get('notes')}")
    if result_units and not target_unit:
        unit_strs = ", ".join(f"{k}: {v}" for k, v in result_units.items())
        print(f"  units: {unit_strs}")
    return 0


def _looks_like_eml(s: str) -> bool:
    """Heuristic: starts with a lowercase function call AND has no top-level
    infix operators. An EML s-expression uses prefix-only syntax
    (`div(a,b)`, not `a/b`), so a top-level `+`, `-`, `*`, `/`, or `^` at
    depth zero means it's infix math, not EML — route to LaTeX instead.
    """
    import re
    if not re.match(r"^\s*[a-z_]+\s*\(", s):
        return False
    depth = 0
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and ch in "+-*/^":
            return False
    return True


def _ambiguous_eml_infix(s: str) -> bool:
    """Function-call-looking input with a top-level infix operator.

    Historically `sin(x)/x` was silently routed through the LaTeX path.
    That can be surprising for callers who intended canonical/EML syntax,
    so auto mode now asks for an explicit `-f` on this shape.
    """
    import re
    if any(c in s for c in "\\{}"):
        return False
    if not re.match(r"^\s*[A-Za-z_][A-Za-z_0-9]*\s*\(", s):
        return False
    depth = 0
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and ch in "*/^":
            return True
    return False


def _has_top_level_relation(s: str) -> bool:
    depth = 0
    for ch in s:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and ch in "=<>~":
            return True
    return False


def _has_top_level_infix_math(s: str) -> bool:
    """Detect natural infix math in an otherwise EML-mode input.

    Top-level relation symbols are allowed; top-level arithmetic on either
    side means the user typed infix math (e.g. ``T = a + b``), so the CLI
    should canonicalize it before handing it to the EML verifier.
    """
    relation_pos: int | None = None
    depth = 0
    for i, ch in enumerate(s):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif depth == 0 and ch in "=<>~":
            relation_pos = i
            break

    parts = [s] if relation_pos is None else [s[:relation_pos], s[relation_pos + 1:]]
    for part in parts:
        depth = 0
        prev_nonspace = ""
        for ch in part:
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif depth == 0 and ch in "+*/^":
                return True
            elif depth == 0 and ch == "-" and prev_nonspace not in ("", "(", ","):
                return True
            if not ch.isspace():
                prev_nonspace = ch
    return False


def cmd_reduce(args: argparse.Namespace) -> int:
    op_id = args.op_id
    node: Any | None = None
    if _server_up():
        node = _http_get(f"/operators/{op_id}")
    if node is None:
        store, _ = _local()
        raw = store.get_node(op_id)
        if raw is None or raw.get("kind") != "operator":
            print(f"error: operator {op_id} not found", file=sys.stderr)
            return 2
        node = {
            "id": raw["id"],
            "name": raw["name"],
            "eml_reduction": raw.get("eml_reduction"),
            "eml_form": raw.get("eml_form", ""),
            "reduction_proof": raw.get("reduction_proof", []),
            "verifiable": raw.get("verifiable", "none"),
        }
    if args.json:
        _print_json(node)
        return 0
    red = node.get("eml_reduction") or "(none)"
    proof = ",".join(node.get("reduction_proof") or []) or "(none)"
    print(f"{node['id']} {node['name']}")
    print(f"  reduction: {red}")
    print(f"  proof:     {proof}")
    print(f"  identity:  {node.get('eml_form','')}")
    return 0


def cmd_search(args: argparse.Namespace) -> int:
    hits: list | None = None
    if _server_up():
        data = _http_get(f"/search?q={_url_quote(args.query)}&limit={args.limit}")
        if data is not None:
            hits = data.get("results", [])
    if hits is None:
        from app import _score  # type: ignore
        store, _ = _local()
        scored = []
        for n in store.all_nodes():
            if n.get("superseded_by"):
                continue
            s, why = _score(n, args.query) if args.query else (1.0, "")
            if args.query and s <= 0:
                continue
            scored.append({
                "id": n["id"],
                "name": n.get("name", ""),
                "area": n.get("area", ""),
                "is_true": bool(n.get("is_true", True)),
                "score": s,
            })
        scored.sort(key=lambda r: r["score"], reverse=True)
        hits = scored[: args.limit]
    if args.json:
        _print_json(hits)
        return 0
    if not hits:
        print("(no matches)")
        return 0
    for h in hits:
        print(_fmt_hit(h))
    return 0


def cmd_rag(args: argparse.Namespace) -> int:
    data: Any | None = None
    if _server_up():
        data = _http_get(f"/rag/query?q={_url_quote(args.query)}&limit={args.limit}&hops={args.hops}")
    if data is None:
        # Simplified in-process: reuse search
        from app import _search_hits  # type: ignore
        store, eqdb = _local()
        hits = _search_hits(args.query, limit=args.limit)
        context = []
        for h in hits:
            for item in store.bfs(h.id, max_depth=args.hops):
                n = store.get_node(item["id"]) or {}
                if n.get("superseded_by") and n.get("id") != h.id:
                    continue
                context.append({
                    "id": n.get("id"),
                    "name": n.get("name", ""),
                    "via": item.get("via"),
                    "depth": item.get("depth", 0),
                })
        data = {"hits": [h.model_dump() if hasattr(h, "model_dump") else h for h in hits], "context": context}
    if args.json:
        _print_json(data)
        return 0
    for h in data.get("hits", []):
        print(_fmt_hit(h))
    if data.get("context"):
        print("---")
        for c in data["context"][: args.limit * 3]:
            via = c.get("via") or ""
            print(f"  ^{c.get('depth','?')} {c.get('id'):<16} {c.get('name','')[:40]:<40} via={via}")
    return 0


def cmd_show(args: argparse.Namespace) -> int:
    node: Any | None = None
    if _server_up():
        node = _http_get(f"/nodes/{args.id}")
        if node is not None:
            node = node.get("node", node)
    if node is None:
        store, _ = _local()
        node = store.get_node(args.id)
    if node is None:
        print(f"error: {args.id} not found", file=sys.stderr)
        return 2
    if args.json:
        _print_json(node)
        return 0
    print(f"{node['id']} {node.get('name','')}")
    print(f"  kind:       {node.get('kind','equation')}")
    print(f"  area:       {node.get('area','')}")
    print(f"  verifiable: {node.get('verifiable','none')}")
    if node.get("superseded_by"):
        print(f"  superseded: {node.get('superseded_by')}")
    if node.get("label"):
        print(f"  label:      {node['label']}")
    formula = node.get("formula") or _candidate_formula_for_node(node)
    if formula and formula != node.get("label"):
        print(f"  formula:    {formula}")
    if node.get("eml_form"):
        print(f"  eml:        {node['eml_form']}")
    if node.get("eml_reduction"):
        print(f"  reduction:  {node['eml_reduction']}")
    if node.get("minimal_explanation"):
        print(f"  note:       {node['minimal_explanation']}")
    return 0


def cmd_bridges(args: argparse.Namespace) -> int:
    path = (
        f"/graph/bridges/{_url_quote(args.id)}?limit={args.limit}"
        f"&provenance={args.provenance}"
    )
    data: Any | None = None
    if _server_up():
        data = _http_get(path)
    if data is None:
        from app import graph_bridges  # type: ignore
        try:
            data = graph_bridges(
                args.id,
                limit=args.limit,
                min_shared=1,
                exclude_same_area=True,
                provenance=args.provenance,
            )
        except Exception as exc:  # noqa: BLE001
            print(f"error: {exc}", file=sys.stderr)
            return 2
    if args.json:
        _print_json(data)
        return 0
    print(
        f"{data.get('node_id')} bridges={len(data.get('bridges', []))} "
        f"curated={data.get('curated_count', 0)} auto={data.get('auto_count', 0)}"
    )
    for b in data.get("bridges", []):
        node = b.get("node", {})
        print(
            f"  {node.get('id',''):<16} {b.get('provenance',''):<7} "
            f"shared={b.get('shared_count',0)} {node.get('area',''):<18} "
            f"{node.get('name','')[:42]}"
        )
    return 0


def cmd_ops(args: argparse.Namespace) -> int:
    data: Any | None = None
    if _server_up():
        path = "/operators" + (f"?tier={args.tier}" if args.tier is not None else "")
        data = _http_get(path)
    if data is None:
        from operators import load_catalogue, operators_only, tier_of  # type: ignore
        nodes = operators_only(load_catalogue(WORKFLOW / "data"))
        rows = [
            {
                "id": n["id"],
                "name": n["name"],
                "tier": tier_of(n),
                "eml_depth": n.get("eml_depth", 0),
                "eml_reduction": n.get("eml_reduction"),
            }
            for n in nodes
            if args.tier is None or tier_of(n) == args.tier
        ]
        rows.sort(key=lambda r: (r["tier"], r["id"]))
        data = {"operators": rows}
    if args.json:
        _print_json(data)
        return 0
    for o in data["operators"]:
        print(_fmt_operator(o))
    return 0


def cmd_latex2eml(args: argparse.Namespace) -> int:
    from latex_eml import latex_to_eml_string  # type: ignore
    try:
        print(latex_to_eml_string(args.latex))
        return 0
    except Exception as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


def cmd_ingest(args: argparse.Namespace) -> int:
    """Scan a .tex/.md/plain-text file for equations and verify them.

    Extracts equations from common delimiters (\\begin{equation}..\\end,
    \\[..\\], $$..$$, \\begin{align*}..\\end), runs each through
    latex_to_eml, then verify_equation, and prints a compact per-equation
    report. If --out is given, verified equations are written as a JSON
    array of node stubs the user can append to equations.json.

    Phase 3B.0 additions:
      * Failed-parse triage — every read / latex-parse / verify failure
        writes a structured record under ``data/ingested/_triage/records/``
        rather than being silently dropped.
      * Claim classifier — every verified row is tagged
        ``definition`` / ``theorem`` / ``model`` / ``approximation``.
        The tag is printed in verbose mode and stamped on committed
        nodes via ``domain_tags`` (``claim:<kind>``).
      * Source-identity dedup — DOI / arXiv / sha256 are extracted and
        the canonical key is checked against
        ``data/ingested/_triage/source_ledger.jsonl``. A second ingest
        of the same paper under a different filename refuses with
        exit code 4 (override with ``--force-source``).
      * Near-duplicate dry-run report — when ``--commit`` is NOT set,
        every verified row is matched against the existing catalogue
        and probable duplicates are reported per row.
      * ``--accept-definition`` guard — definition-shaped commits are
        skipped unless the flag is passed.
    """
    from pathlib import Path
    from ingest_pipeline import (  # type: ignore
        build_dedup_index,
        build_node,
        extract_equations,
        find_duplicate,
        register_in_index,
    )
    from ingest_triage import (  # type: ignore
        SourceIdentity,
        check_source_seen,
        classify_claim,
        claim_kind_tag,
        extract_source_identity,
        find_near_duplicates,
        is_definition_method,
        load_definition_glossary,
        record_source_seen,
        write_triage_record,
    )
    from multimodal_ingest import (  # type: ignore
        SourceRef,
        append_figure_artifact,
        append_table_artifact,
        extract_figure_artifacts_from_text,
        extract_table_artifacts_from_text,
    )

    data_dir = Path(os.environ.get("RXR_DATA", WORKFLOW / "data"))

    path = Path(args.path)
    if not path.exists():
        print(f"error: file not found: {path}", file=sys.stderr)
        write_triage_record(
            data_dir=data_dir,
            stage="read",
            reason="file not found",
            source=path,
            details={"errno": "ENOENT"},
        )
        return 2
    try:
        src = path.read_text()
    except Exception as exc:
        print(f"error: read failed: {path}: {exc}", file=sys.stderr)
        write_triage_record(
            data_dir=data_dir,
            stage="read",
            reason=f"read failed: {exc}",
            source=path,
            details={"exception": str(exc)},
        )
        return 2

    identity = extract_source_identity(path, src)
    prior = check_source_seen(identity, data_dir=data_dir)
    if prior is not None and not getattr(args, "force_source", False):
        # Same paper under a different filename — refuse the second run.
        print(
            f"error: source already ingested under {prior.get('first_path')!r} "
            f"(key={identity.key}); rerun with --force-source to override.",
            file=sys.stderr,
        )
        write_triage_record(
            data_dir=data_dir,
            stage="dedup",
            reason="source already ingested under a different filename",
            source=identity,
            details={"prior_path": prior.get("first_path"),
                     "prior_first_seen": prior.get("first_seen"),
                     "prior_node_ids": prior.get("node_ids", [])},
        )
        return 4

    is_latex_source = path.suffix.lower() in {".tex", ".latex", ".sty"}
    extracted = extract_equations(src, is_latex=is_latex_source)

    if not extracted:
        print("(no equations found)")
        write_triage_record(
            data_dir=data_dir,
            stage="extract",
            reason="no equations found in source",
            source=identity,
            details={"is_latex_source": is_latex_source,
                     "source_size_bytes": len(src)},
        )
        return 0

    from latex_eml import latex_to_eml_string  # type: ignore
    from verify import verify_equation  # type: ignore

    verified_rows: list[dict] = []
    counts = {"extracted": 0, "parsed": 0, "verified": 0,
              "triaged": 0, "definitions_skipped": 0}
    classification_counts: dict[str, int] = {
        "definition": 0, "theorem": 0, "model": 0, "approximation": 0,
    }
    for kind, latex, context in extracted:
        counts["extracted"] += 1
        try:
            eml_text = latex_to_eml_string(latex)
        except Exception as exc:
            counts["triaged"] += 1
            write_triage_record(
                data_dir=data_dir,
                stage="parse",
                reason=f"latex_to_eml failed: {exc}",
                source=identity,
                details={"latex": latex, "extracted_kind": kind,
                         "exception": str(exc)},
            )
            if args.verbose:
                print(f"skip ({kind}) latex-parse: {latex[:60]}... [{exc}]")
            continue
        counts["parsed"] += 1
        try:
            result = verify_equation(eml_text, samples=args.samples, tolerance=args.tolerance)
        except Exception as exc:
            counts["triaged"] += 1
            write_triage_record(
                data_dir=data_dir,
                stage="verify",
                reason=f"verify_equation raised: {exc}",
                source=identity,
                details={"latex": latex, "eml": eml_text,
                         "extracted_kind": kind, "exception": str(exc)},
            )
            if args.verbose:
                print(f"skip ({kind}) verify: {latex[:60]}... [{exc}]")
            continue
        mark = "OK" if result["verified"] else "NO"
        method = str(result.get("method", "") or "")
        claim_kind = classify_claim(
            eml=eml_text, method=method, context=context, nearby_text=src,
        )
        if result["verified"]:
            counts["verified"] += 1
            classification_counts[claim_kind] = classification_counts.get(claim_kind, 0) + 1
            verified_rows.append({
                "latex": latex,
                "eml": eml_text,
                "max_residual": result["max_residual"],
                "method": method,
                "context": context,
                "claim_kind": claim_kind,
                "dependent_var": result.get("dependent_var"),
            })
        if not args.quiet:
            max_res = result.get("max_residual", 0.0)
            method_suffix = f" method={method}" if args.verbose and method else ""
            claim_suffix = f" claim={claim_kind}" if args.verbose else ""
            print(f"{mark} max_res={max_res:.2e}{method_suffix}{claim_suffix}  {latex[:70]}")

    if args.out and verified_rows:
        out_path = Path(args.out)
        out_path.write_text(json.dumps(verified_rows, indent=2, ensure_ascii=False))
        print(f"wrote {len(verified_rows)} verified equations to {out_path}")

    # ----- Phase 3B.0 near-duplicate dry-run report ---------------------
    # Always run when there are verified rows. In dry-run (no --commit)
    # this is the only output that flags likely duplicates; in commit
    # mode it's printed before commit so the operator can ctrl-C.
    near_dup_hits: list[dict] = []
    if verified_rows:
        # Build a dedup index against the entire current store. Cheap —
        # mirrors what the commit path already does.
        eq_path_for_dedup = data_dir / "equations.json"
        payload_for_dedup: dict = {"nodes": []}
        if eq_path_for_dedup.exists():
            try:
                payload_for_dedup = json.loads(eq_path_for_dedup.read_text())
            except Exception:
                payload_for_dedup = {"nodes": []}
        nodes_for_dedup = list(payload_for_dedup.get("nodes", []))
        for other in (
            "operators.json", "axioms.json", "theorems.json",
            "complex_ops.json", "matrix_ops.json", "probability_ops.json",
            "inequality_ops.json", "ode_ops.json", "vector_calc_ops.json",
            "partial_deriv_ops.json", "distributions.json",
        ):
            other_path = data_dir / other
            if not other_path.exists():
                continue
            try:
                other_payload = json.loads(other_path.read_text())
                nodes_for_dedup.extend(other_payload.get("nodes", []))
            except Exception:
                pass
        dedup_indices = build_dedup_index(nodes_for_dedup)
        for row in verified_rows:
            hits = find_near_duplicates(row["eml"], row.get("method", ""), dedup_indices)
            for h in hits:
                near_dup_hits.append({
                    "latex": row["latex"],
                    "eml": h.candidate_eml,
                    "existing_id": h.existing_id,
                    "match_kind": h.match_kind,
                    "claim_kind": row["claim_kind"],
                })
        if near_dup_hits and not args.quiet:
            print()
            print(f"near-duplicate report ({len(near_dup_hits)} match(es)):")
            for h in near_dup_hits[:10]:
                print(
                    f"  near-dup {h['match_kind']}={h['existing_id']}"
                    f" claim={h['claim_kind']}  {h['latex'][:60]}"
                )

    committed = 0
    duplicates = 0
    commit_path: Path | None = None
    if args.commit and verified_rows:
        eq_path = data_dir / "equations.json"
        payload = json.loads(eq_path.read_text())
        nodes = payload.get("nodes", [])

        # Collect all existing ids across every data file so we don't clash.
        existing_ids: set[str] = {n.get("id") for n in nodes if isinstance(n, dict)}
        for other in (
            "operators.json", "axioms.json", "theorems.json",
            "complex_ops.json", "matrix_ops.json",
        ):
            other_path = data_dir / other
            if other_path.exists():
                try:
                    other_payload = json.loads(other_path.read_text())
                    for n in other_payload.get("nodes", []):
                        if isinstance(n, dict) and n.get("id"):
                            existing_ids.add(n["id"])
                except Exception:
                    pass

        def _next_id(counter: int) -> tuple[str, int]:
            while True:
                counter += 1
                candidate = f"ingested_{counter}"
                if candidate not in existing_ids:
                    return candidate, counter

        counter = 0
        source_file = str(path)
        indices = build_dedup_index(nodes)
        committed_ids: list[str] = []
        glossary_symbols = load_definition_glossary(data_dir)

        for row in verified_rows:
            latex = row["latex"]
            eml_text = row["eml"]
            method = row.get("method", "")
            row_claim = row.get("claim_kind", "model")
            dep_var = str(row.get("dependent_var") or "").strip()
            is_definition_row = row_claim == "definition" or str(method).startswith("definition")

            # Definition-shape guard. Without --accept-definition,
            # definition-classified rows are skipped (not the whole
            # commit aborted). Operators see a per-row skip line so
            # they can rerun with the flag if they meant to accept.
            if (
                is_definition_row
                and not getattr(args, "accept_definition", False)
            ):
                counts["definitions_skipped"] += 1
                if not args.quiet:
                    print(
                        f"skip claim=definition needs_flag=--accept-definition"
                        f"  {latex[:70]}"
                    )
                write_triage_record(
                    data_dir=data_dir,
                    stage="commit",
                    reason="definition-shape commit refused without --accept-definition",
                    source=identity,
                    details={"latex": latex, "eml": eml_text, "method": method},
                )
                continue
            if is_definition_row:
                known_lhs = bool(dep_var and dep_var in glossary_symbols)
                justification = str(getattr(args, "definition_justification", "") or "").strip()
                if not known_lhs and not justification:
                    counts["definitions_skipped"] += 1
                    if not args.quiet:
                        print(
                            "skip claim=definition needs_flag="
                            "--definition-justification  "
                            f"{latex[:70]}"
                        )
                    write_triage_record(
                        data_dir=data_dir,
                        stage="commit",
                        reason=(
                            "definition-shape commit refused without glossary "
                            "match or --definition-justification"
                        ),
                        source=identity,
                        details={
                            "latex": latex,
                            "eml": eml_text,
                            "method": method,
                            "dependent_var": dep_var,
                        },
                    )
                    continue

            duplicate_of = find_duplicate(eml_text, method, indices)
            if duplicate_of is not None:
                duplicates += 1
                if not args.quiet:
                    print(f"skip duplicate_of={duplicate_of} committed=0  {latex[:70]}")
                continue

            node_id, counter = _next_id(counter)
            existing_ids.add(node_id)
            node = build_node(row, source_file, node_id)
            # Stamp the claim classification + canonical source identity
            # on the committed node. Stored via domain_tags + source so
            # no schema bump is required.
            node.setdefault("domain_tags", []).append(claim_kind_tag(row_claim))
            node.setdefault("source", {}).update({
                "doi": identity.doi,
                "arxiv": identity.arxiv,
                "sha256": identity.sha256,
                "key": identity.key,
            })
            if is_definition_row and getattr(args, "definition_justification", None):
                node.setdefault("source", {})["definition_justification"] = str(
                    args.definition_justification
                ).strip()
            if is_definition_row and dep_var:
                node.setdefault("source", {})["dependent_var"] = dep_var
            nodes.append(node)
            register_in_index(node_id, eml_text, method, indices)
            committed += 1
            committed_ids.append(node_id)

        payload["nodes"] = nodes
        eq_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
        commit_path = eq_path

        # Record the source identity in the ledger only after a real
        # commit happened. Dry-run / definition-only-skipped runs do
        # NOT seal the ledger, so the operator can rerun with the
        # right flags.
        if committed > 0:
            record_source_seen(
                identity,
                data_dir=data_dir,
                node_ids=committed_ids,
            )

        # Re-run the edge builder so the graph index refreshes. The helper
        # script uses hard-coded repo paths, so when running against a tmp
        # data dir (RXR_DATA set) we skip it silently — tests only
        # care that nodes were appended.
        if os.environ.get("RXR_DATA") in (None, str(WORKFLOW / "data")):
            import subprocess
            try:
                subprocess.run(
                    ["python3", str(WORKFLOW / "scripts" / "build_edges.py")],
                    check=False,
                    capture_output=True,
                )
            except Exception:
                pass

        # Best-effort live-reload on a running server; tolerate missing route.
        if _server_up():
            _http_post("/admin/reload", {})

    # ----- Phase 6A.1 multimodal heuristic extraction -------------------
    # Independent of equation verification — runs only when --tables /
    # --figures is set. Always writes audit artifacts under
    # data/ingested/_multimodal/, both in dry-run and commit paths
    # (mirrors the 6A.0 / triage convention that audit JSONL is always
    # safe to write). Catalogue commit semantics are unchanged.
    tables_count = 0
    figures_count = 0
    if getattr(args, "tables", False) or getattr(args, "figures", False):
        source_ref = SourceRef(
            path=identity.path,
            sha256=identity.sha256,
            doi=identity.doi,
            arxiv=identity.arxiv,
            key=identity.key,
        )
        if getattr(args, "tables", False):
            try:
                table_artifacts = extract_table_artifacts_from_text(
                    src, source_ref,
                )
            except Exception as exc:
                table_artifacts = []
                if args.verbose:
                    print(f"warn: table heuristic failed: {exc}")
            for art in table_artifacts:
                try:
                    append_table_artifact(art, data_dir=data_dir)
                    tables_count += 1
                except Exception as exc:
                    if args.verbose:
                        print(f"warn: append_table_artifact failed: {exc}")
        if getattr(args, "figures", False):
            try:
                figure_artifacts = extract_figure_artifacts_from_text(
                    src, source_ref,
                )
            except Exception as exc:
                figure_artifacts = []
                if args.verbose:
                    print(f"warn: figure heuristic failed: {exc}")
            for art in figure_artifacts:
                try:
                    append_figure_artifact(art, data_dir=data_dir)
                    figures_count += 1
                except Exception as exc:
                    if args.verbose:
                        print(f"warn: append_figure_artifact failed: {exc}")

    print()
    summary = (
        f"extracted={counts['extracted']} "
        f"parsed={counts['parsed']} "
        f"verified={counts['verified']}"
    )
    if counts["triaged"]:
        summary += f" triaged={counts['triaged']}"
    if classification_counts:
        cls_str = " ".join(
            f"{k}={v}" for k, v in sorted(classification_counts.items()) if v > 0
        )
        if cls_str:
            summary += f" classes=[{cls_str}]"
    if near_dup_hits:
        summary += f" near_duplicates={len(near_dup_hits)}"
    if getattr(args, "tables", False):
        summary += f" tables={tables_count}"
    if getattr(args, "figures", False):
        summary += f" figures={figures_count}"
    if args.commit:
        summary += f" committed={committed}"
        if duplicates:
            summary += f" duplicates={duplicates}"
        if counts["definitions_skipped"]:
            summary += f" definitions_skipped={counts['definitions_skipped']}"
        if commit_path is not None:
            summary += f" path={commit_path}"
    summary += f" source_key={identity.key}"
    print(summary)

    return 0 if counts["verified"] > 0 else 1


def _pack_data_dir() -> Path:
    return Path(os.environ.get("RXR_DATA", WORKFLOW / "data"))


def cmd_pack_create(args: argparse.Namespace) -> int:
    from pack_pipeline import create_pack, PackError  # type: ignore
    try:
        manifest = create_pack(
            _pack_data_dir(),
            args.pack_id,
            title=args.title or args.pack_id,
            source_corpus=args.source_corpus or "",
            reviewer=args.reviewer,
        )
    except (PackError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(manifest, indent=2))
    else:
        print(f"created pack {manifest['id']} status={manifest['status']}")
    return 0


def cmd_pack_ingest(args: argparse.Namespace) -> int:
    from pack_pipeline import ingest_into_pack, PackError  # type: ignore
    try:
        result = ingest_into_pack(
            _pack_data_dir(),
            args.pack_id,
            Path(args.corpus),
            dry_run=args.dry_run,
            accept_definition=args.accept_definition,
            definition_justification=getattr(args, "definition_justification", "") or "",
            force_source=args.force_source,
            samples=args.samples,
            tolerance=args.tolerance,
        )
    except (PackError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(result, indent=2, default=str))
    else:
        c = result["counts"]
        print(
            f"pack={args.pack_id} dry_run={args.dry_run} "
            f"files={c['files']} extracted={c['extracted']} verified={c['verified']} "
            f"committed={c['committed']} duplicates={c['duplicates']} "
            f"verify_failures={c['verify_failures']} near_duplicates={c['near_duplicates']}"
        )
    return 0


def cmd_pack_validate(args: argparse.Namespace) -> int:
    from pack_pipeline import validate_pack, PackError  # type: ignore
    try:
        report = validate_pack(_pack_data_dir(), args.pack_id)
    except (PackError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        s = report["summary"]
        verdict = "PASS" if report["passed"] else "FAIL"
        print(
            f"{verdict} pack={args.pack_id} nodes={s['node_count']} "
            f"verify_failures={s['verify_failures']} duplicates={s['duplicates']} "
            f"id_collisions={s['id_collisions']} "
            f"definitions_missing_justification={s['definitions_missing_justification']}"
        )
    return 0 if report["passed"] else 1


def cmd_pack_promote(args: argparse.Namespace) -> int:
    from pack_pipeline import (  # type: ignore
        PackError, PackPromotionRefused, promote_pack,
    )
    try:
        manifest = promote_pack(_pack_data_dir(), args.pack_id)
    except PackPromotionRefused as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except (PackError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    # Best-effort: notify a running server so search picks up new nodes.
    if _server_up():
        _http_post("/admin/reload", {})
    if args.json:
        print(json.dumps(manifest, indent=2))
    else:
        print(f"promoted pack={manifest['id']} status={manifest['status']}")
    return 0


def cmd_pack_rollback(args: argparse.Namespace) -> int:
    from pack_pipeline import PackError, rollback_pack  # type: ignore
    try:
        manifest = rollback_pack(_pack_data_dir(), args.pack_id)
    except (PackError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if _server_up():
        _http_post("/admin/reload", {})
    if args.json:
        print(json.dumps(manifest, indent=2))
    else:
        print(f"rolled back pack={manifest['id']} status={manifest['status']}")
    return 0


def cmd_pack_status(args: argparse.Namespace) -> int:
    from pack_pipeline import (  # type: ignore
        PackError, list_packs_summary, pack_status,
    )
    data_dir = _pack_data_dir()
    if args.pack_id:
        try:
            data = pack_status(data_dir, args.pack_id)
        except (PackError, ValueError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        if args.json:
            print(json.dumps(data, indent=2))
        else:
            m = data["manifest"]
            counts = m.get("counts", {})
            print(
                f"pack={m['id']} status={m['status']} enabled={data['enabled']} "
                f"nodes={counts.get('nodes', 0)} "
                f"verify_failures={counts.get('verify_failures', 0)} "
                f"duplicates={counts.get('duplicates', 0)}"
            )
        return 0
    rows = list_packs_summary(data_dir)
    if args.json:
        print(json.dumps(rows, indent=2))
    else:
        if not rows:
            print("(no packs)")
        for m in rows:
            counts = m.get("counts", {})
            print(
                f"{m['id']:<32} {m['status']:<12} enabled={m.get('enabled')} "
                f"nodes={counts.get('nodes', 0)} "
                f"verify_failures={counts.get('verify_failures', 0)}"
            )
    return 0


def cmd_pack_review(args: argparse.Namespace) -> int:
    from pack_llm_review import (  # type: ignore
        PackReviewError,
        build_claude_review_command,
        run_claude_review,
        write_pack_review,
    )

    prompt_path = Path(args.prompt_file)
    if not prompt_path.exists():
        print(f"error: prompt file not found: {prompt_path}", file=sys.stderr)
        return 2
    prompt = prompt_path.read_text()

    if args.dry_run:
        cmd = build_claude_review_command(prompt, claude_bin=args.claude_bin)
        payload = {
            "pack_id": args.pack_id,
            "role": args.role,
            "node_id": args.node_id,
            "command": cmd,
            "uses_api_key": False,
            "uses_budget_cap": False,
        }
        if args.json:
            print(json.dumps(payload, indent=2))
        else:
            print(" ".join(json.dumps(part) if part == "" else part for part in cmd))
        return 0

    try:
        result = run_claude_review(prompt, claude_bin=args.claude_bin)
        path = write_pack_review(
            _pack_data_dir(),
            args.pack_id,
            role=args.role,
            node_id=args.node_id,
            payload={
                "pack_id": args.pack_id,
                "role": args.role,
                "node_id": args.node_id,
                "prompt_file": str(prompt_path),
                **result,
            },
        )
    except (PackReviewError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps({"review_path": str(path), **result}, indent=2))
    else:
        review = result.get("review", {})
        print(
            f"review={review.get('decision', '?')} "
            f"confidence={review.get('confidence', '?')} path={path}"
        )
    return 0


def cmd_discover(args: argparse.Namespace) -> int:
    """Run symbolic regression over a CSV or inline data source."""
    from discover import discover  # type: ignore

    data_arg = args.data
    if data_arg == "-":
        data_arg = sys.stdin.read()
    elif not Path(data_arg).exists() and "\n" not in data_arg:
        print(f"error: data file not found: {data_arg}", file=sys.stderr)
        return 2

    x_cols = [c.strip() for c in (args.x or "").split(",") if c.strip()]
    if not x_cols:
        print("error: --x must be a non-empty comma-separated list", file=sys.stderr)
        return 2
    if not args.y:
        print("error: --y required", file=sys.stderr)
        return 2

    # `fit-purity` is a CLI shortcut for reweighting; the discover() engine
    # doesn't know the name — we translate it to explicit weights and pass
    # a base objective of `match` so the rest of the ranking pipeline
    # (graph bonus, novelty bonus) behaves sanely.
    discover_objective = args.objective
    weights: dict[str, float] | None = None
    if args.objective == "fit-purity":
        discover_objective = "match"
        weights = {"fit": 0.98, "simplicity": 0.01, "robustness": 0.01}

    try:
        result = discover(
            data_arg,
            y_col=args.y,
            x_cols=x_cols,
            max_depth=args.max_depth,
            max_size=args.max_size,
            budget=args.budget,
            alphabet=args.alphabet,
            objective=discover_objective,
            weights=weights,
            top=args.top,
            seed=args.seed,
            graph_filter=args.graph_filter,
            novelty_only=args.novelty_only,
            deep_match=args.deep_match,
            deep_match_retry=getattr(args, "deep_match_retry", False),
        )
    except Exception as exc:  # noqa: BLE001
        print(f"error: {exc}", file=sys.stderr)
        return 3

    # --commit-novel flow: append fit candidates with graph_node=null and
    # high robustness to data/equations.json as discovered_N nodes.
    committed = 0
    commit_path: Path | None = None
    if args.commit_novel and result.candidates:
        data_dir = Path(os.environ.get("RXR_DATA", WORKFLOW / "data"))
        eq_path = data_dir / "equations.json"
        payload = json.loads(eq_path.read_text())
        nodes = payload.get("nodes", [])

        existing_ids: set[str] = {n.get("id") for n in nodes if isinstance(n, dict)}
        for other in (
            "operators.json", "axioms.json", "theorems.json",
            "complex_ops.json", "matrix_ops.json",
            "partial_deriv_ops.json", "vector_calc_ops.json",
            "probability_ops.json", "inequality_ops.json", "ode_ops.json",
        ):
            other_path = data_dir / other
            if other_path.exists():
                try:
                    other_payload = json.loads(other_path.read_text())
                    for n in other_payload.get("nodes", []):
                        if isinstance(n, dict) and n.get("id"):
                            existing_ids.add(n["id"])
                except Exception:
                    pass

        def _next_id(counter: int) -> tuple[str, int]:
            while True:
                counter += 1
                candidate = f"discovered_{counter}"
                if candidate not in existing_ids:
                    return candidate, counter

        counter = 0
        for cand in result.candidates:
            if cand.graph_node is not None:
                continue
            if cand.robustness < 0.99:
                continue
            nid, counter = _next_id(counter)
            existing_ids.add(nid)
            eq_text = f"{args.y} = {cand.eml}"
            nodes.append({
                "id": nid,
                "kind": "equation",
                "name": f"Discovered: {cand.eml[:50]}",
                "area": "discovered",
                "difficulty": "graduate",
                "is_true": True,
                "arity": None,
                "label": cand.latex,
                "eml_form": eq_text,
                "eml_tree": ["eq", args.y, cand.eml_tree],
                "eml_reduction": None,
                "reduction_proof": [],
                "verifiable": "numeric",
                "minimal_explanation": f"Auto-discovered from dataset (r2={cand.scores.get('fit', 0):.4f}, robustness={cand.robustness:.3f}).",
                "domain_tags": ["discovered"],
                "equivalent_to": [],
                "derived_from": [],
                "approximations": [],
                "failures": [],
                "failure_mode": "",
                "eml_depth": 0,
                "source": {
                    "discoverer": {
                        "backend": result.summary.get("backend"),
                        "alphabet": args.alphabet,
                        "budget": args.budget,
                        "max_depth": args.max_depth,
                        "seed": args.seed,
                    },
                    "dataset": str(data_arg)[:200],
                    "r2": cand.scores.get("fit", 0.0),
                    "robustness": cand.robustness,
                },
            })
            committed += 1
        payload["nodes"] = nodes
        eq_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))
        commit_path = eq_path
        if os.environ.get("RXR_DATA") in (None, str(WORKFLOW / "data")):
            import subprocess
            try:
                subprocess.run(
                    [sys.executable, str(WORKFLOW / "scripts" / "build_edges.py")],
                    check=False,
                    capture_output=True,
                )
            except Exception:
                pass
        if _server_up():
            _http_post("/admin/reload", {})

    if args.output == "json" or args.json:
        payload = result.to_dict()
        payload["committed"] = committed
        if commit_path is not None:
            payload["commit_path"] = str(commit_path)
        _print_json(payload)
        return 0

    if not result.candidates:
        print("(no candidates found)")
        return 1
    for c in result.candidates:
        graph_tag = c.graph_node or "NEW"
        r2 = c.scores.get("fit", 0.0)
        size = _size_of(c.eml_tree)
        print(f"{c.rank}\t{graph_tag}\t{c.score:.4f}\t{r2:.4f}\t{size}\t{c.eml}")
    if committed:
        tail = f"  committed={committed}"
        if commit_path is not None:
            tail += f" path={commit_path}"
        print(tail)
    return 0


def _size_of(tree: Any) -> int:
    if isinstance(tree, list):
        return 1 + sum(_size_of(a) for a in tree[1:])
    return 1


def cmd_prove(args: argparse.Namespace) -> int:
    """Lint a .mg proof file: verify each step against its parents."""
    from pathlib import Path as _Path
    path = _Path(args.file)
    if not path.exists():
        print(f"error: proof file not found: {path}", file=sys.stderr)
        return 2
    source = path.read_text()

    try:
        from prove import prove_source, prove_result_to_dict  # type: ignore
    except Exception as exc:  # noqa: BLE001
        print(f"error: {exc}", file=sys.stderr)
        return 3

    fmt = "eml" if args.format == "canonical" else args.format
    try:
        result = prove_source(
            source,
            format=fmt,
            stop_at_fail=args.stop_at_fail,
            lint_only=args.lint_only,
            no_diagnosis=args.no_diagnosis,
        )
    except Exception as exc:  # noqa: BLE001
        print(f"error: {exc}", file=sys.stderr)
        return 3

    if args.output == "json" or args.json:
        _print_json(prove_result_to_dict(result))
    else:
        _print_prove_text(result, verbose=args.verbose, no_diagnosis=args.no_diagnosis)

    # Exit codes
    # Parse error ⇒ note starts with "parse_error:"
    for note in result.notes:
        if note.startswith("parse_error:"):
            return 2
    if not result.ok:
        return 1
    return 0


def _prove_glyphs():
    try:
        import sys as _sys
        if _sys.stdout.isatty():
            return "✓", "✗"  # ✓, ✗
    except Exception:
        pass
    return "OK", "NO"


def _print_prove_text(result: Any, *, verbose: bool, no_diagnosis: bool) -> None:
    ok_mark, fail_mark = _prove_glyphs()
    if result.notes:
        for note in result.notes:
            print(f"! {note}")
        if any(n.startswith("parse_error:") for n in result.notes):
            return

    n_ok = sum(1 for s in result.steps if s.status == "verified")
    n_fail = sum(1 for s in result.steps if s.status == "failed")
    n_skip = sum(1 for s in result.steps if s.status == "skipped")
    total = len(result.steps)

    # Header
    print(f"proof: {len(result.givens)} given, {total} steps")
    if result.givens and verbose:
        for g in result.givens:
            print(f"  given {g['label']}: {g['equation']}")

    for step in result.steps:
        label = step.label
        parents_s = ",".join(step.parents) if step.parents else "-"
        if step.status == "verified":
            print(f"{ok_mark} step {label:<4} [{parents_s}]  {step.equation_text}")
        elif step.status == "failed":
            print(f"{fail_mark} step {label:<4} [{parents_s}]  {step.equation_text}")
            print(f"    your step: {step.equation_text}")
            print(f"    expected:  {step.expected if step.expected else 'null'}")
            print(f"    residual:  {step.residual}")
            if not no_diagnosis:
                diag = step.diagnosis
                if diag:
                    msg = diag.get("message", "unrecognised")
                    print(f"    diagnosis: {msg}")
                else:
                    print(f"    diagnosis: pending v2 classifier")
                print(f"    suggested: {step.suggested if step.suggested else 'null'}")
            if step.numeric_check:
                nc = step.numeric_check
                print(
                    f"    numeric:   ok={nc.get('verified')} max_res={nc.get('max_residual', 0):.2e}"
                    f"  samples={nc.get('samples', 0)}"
                )
        else:  # skipped
            print(f"- step {label:<4} [skipped]  {step.equation_text}")

    print(f"summary: {n_ok} verified, {n_fail} failed, {n_skip} skipped "
          f"({result.duration_s:.2f}s)")


def cmd_reindex(args: argparse.Namespace) -> int:
    """Rebuild the hybrid retrieval index (dense + sparse)."""
    # Prefer hitting the running server so we swap in-place without a restart.
    if _server_up():
        res = _http_post("/admin/retrieval/rebuild", {}, timeout=600.0)
        if res is not None and res.get("rebuilt"):
            if args.json:
                _print_json(res)
                return 0
            print(
                f"rebuilt docs={res.get('num_docs','?')} "
                f"model={res.get('model_name','?')} "
                f"embed={res.get('embed_seconds','?')}s"
            )
            return 0
        if res is not None:
            print(f"error: {res.get('error','rebuild failed')}", file=sys.stderr)
            return 3

    # Fallback: run the build script in-process.
    import subprocess
    script = WORKFLOW / "scripts" / "build_embeddings.py"
    if not script.exists():
        print(f"error: {script} not found", file=sys.stderr)
        return 3
    rc = subprocess.call([sys.executable, str(script)])
    return rc


def cmd_eval_retrieval(args: argparse.Namespace) -> int:
    """Benchmark legacy substring vs hybrid retrieval over the gold set."""
    gold_path = Path(args.gold or (WORKFLOW / "data" / "eval" / "gold_queries.json"))
    if not gold_path.exists():
        print(f"error: gold file not found: {gold_path}", file=sys.stderr)
        return 2

    from retrieval.eval import (  # type: ignore
        evaluate,
        hybrid_search_fn,
        legacy_search_fn,
        load_gold,
    )

    gold = load_gold(gold_path)
    store, _ = _local()

    baseline = evaluate("substring", legacy_search_fn(store), gold)

    hybrid_result = None
    index_dir = WORKFLOW / "data" / "index"
    if (index_dir / "manifest.json").exists():
        from retrieval.pipeline import HybridRetriever  # type: ignore
        retriever = HybridRetriever.load(index_dir)
        hybrid_result = evaluate("hybrid", hybrid_search_fn(retriever), gold)

    if args.json:
        payload: dict[str, Any] = {"baseline": baseline.to_dict()}
        if hybrid_result is not None:
            payload["hybrid"] = hybrid_result.to_dict()
        _print_json(payload)
    else:
        print(baseline.summary_line())
        if hybrid_result is not None:
            print(hybrid_result.summary_line())
        else:
            print("hybrid: no index built (run `rxr reindex`)")

    # Persist a dated snapshot so regressions are visible.
    if args.record:
        import time as _t
        record_dir = WORKFLOW / "data" / "eval"
        record_dir.mkdir(parents=True, exist_ok=True)
        stamp = _t.strftime("%Y%m%d_%H%M%S")
        snap: dict[str, Any] = {"baseline": baseline.to_dict()}
        if hybrid_result is not None:
            snap["hybrid"] = hybrid_result.to_dict()
        (record_dir / f"run_{stamp}.json").write_text(json.dumps(snap, indent=2))

    return 0 if (hybrid_result is None or hybrid_result.mrr >= baseline.mrr) else 1


def cmd_solve_ode(args: argparse.Namespace) -> int:
    """Solve an ODE via sympy.dsolve and numerically cross-check the solution."""
    ics: dict[str, float] = {}
    for spec in (args.ic or []):
        if "=" not in spec:
            print(f"error: --ic expects 'y(0)=1' form (got {spec!r})", file=sys.stderr)
            return 2
        k, v = spec.split("=", 1)
        try:
            ics[k.strip()] = float(v)
        except ValueError:
            print(f"error: --ic value must be numeric (got {spec!r})", file=sys.stderr)
            return 2

    data: Any | None = None
    if _server_up():
        data = _http_post("/v1/ode/solve", {"ode": args.ode, "ics": ics, "func_name": args.func, "var_name": args.var})
    if data is None:
        from ode_solver import solve_ode  # type: ignore
        try:
            data = solve_ode(args.ode, func_name=args.func, var_name=args.var, ics=ics)
        except Exception as exc:  # noqa: BLE001
            print(f"error: {exc}", file=sys.stderr)
            return 3

    if args.json:
        _print_json(data)
        return 0 if data.get("ok") else 1

    if not data.get("ok"):
        print(f"NO {data.get('notes','dsolve failed')}")
        return 1
    num = data.get("numeric") or {}
    status = "OK" if num.get("verified") else "??"
    residual = num.get("max_residual")
    print(f"{status} {args.func}({args.var}) = {data.get('solution','?')}")
    if residual is not None:
        print(f"   numeric: max_res={residual:.2e}  samples={num.get('samples_tested','?')}")
    if data.get("ics"):
        print(f"   ics: {data['ics']}")
    return 0 if num.get("verified", True) else 1


def cmd_stats(args: argparse.Namespace) -> int:
    data: Any | None = None
    if _server_up():
        data = _http_get("/graph/stats")
    if data is None:
        store, _ = _local()
        from public_view import is_hidden  # type: ignore
        nodes = [
            n
            for n in store.all_nodes()
            if not is_hidden(n.get("id", "")) and not n.get("superseded_by")
        ]
        keep = {n["id"] for n in nodes}
        visible_edges = [
            e
            for e in store.all_edges()
            if e.get("source") in keep and e.get("target") in keep
        ]
        domains = Counter((n.get("area") or "unknown") for n in nodes)
        difficulties = Counter((n.get("difficulty") or "unknown") for n in nodes)
        depth_hist = Counter(str(n.get("eml_depth", 0)) for n in nodes)
        true_count = sum(1 for n in nodes if n.get("is_true"))
        data = {
            "num_nodes": len(nodes),
            "num_edges": len(visible_edges),
            "true_count": true_count,
            "false_count": len(nodes) - true_count,
            "domains": dict(domains),
            "difficulties": dict(difficulties),
            "eml_depth_hist": dict(depth_hist),
        }
    if args.json:
        _print_json(data)
        return 0
    print(f"nodes={data['num_nodes']} edges={data['num_edges']} true={data['true_count']} false={data['false_count']}")
    for area, count in sorted(data.get("domains", {}).items()):
        print(f"  {area}: {count}")
    return 0


# --- Arg parsing ----------------------------------------------------------
def _url_quote(s: str) -> str:
    from urllib.parse import quote
    return quote(s)


# Resolved lazily from server/discover.py so adding an alphabet over there
# automatically updates the CLI's accepted values.
def _alphabet_choices() -> list[str]:
    try:
        from discover import ALPHABETS  # type: ignore
        return list(ALPHABETS.keys())
    except Exception:
        return ["eml-core", "eml-extended"]


ALPHABETS_CHOICES = _alphabet_choices()


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="rxr",
        description="RigorXRigor CLI — equation verification + graph RAG for LLMs.",
    )
    p.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("verify", help="verify an equation")
    sp.add_argument("equation")
    sp.add_argument("-f", "--format", choices=["auto", "latex", "canonical", "eml"], default="auto",
                    help="'canonical' is the supported name; 'eml' is kept as a silent alias.")
    sp.add_argument("-s", "--samples", type=int, default=10)
    sp.add_argument("-t", "--tolerance", type=float, default=1e-6)
    sp.add_argument(
        "-b", "--bind",
        action="append",
        default=None,
        metavar="NAME=VALUE",
        help="numeric binding for a variable (repeatable; VALUE may be numeric arithmetic)",
    )
    sp.add_argument("--symbolic", action="store_true", help="use sympy symbolic simplification instead of numeric sampling")
    sp.add_argument(
        "-d", "--domain",
        action="append",
        default=None,
        metavar="VAR=LO,HI",
        help="sample variable VAR uniformly in [LO, HI] (repeatable, e.g. -d x=-0.9,0.9)",
    )
    sp.add_argument(
        "--assume",
        action="append",
        default=None,
        metavar="VAR:DOMAIN",
        help=("declare VAR is in DOMAIN for both numeric sampling and symbolic "
              "assumption injection (repeatable; e.g. --assume x:positive_real "
              "--assume n:natural). Domain values: real, positive_real, "
              "nonneg_real, negative_real, integer, positive_integer, natural, "
              "unit_interval, probability, complex (plus aliases R+/Z+/[0,1]/...)."),
    )
    sp.set_defaults(handler=cmd_verify)

    sp = sub.add_parser("calc", aliases=["calculate"], help="evaluate a formula/expression with numeric bindings")
    sp.add_argument("expression")
    sp.add_argument(
        "-b", "--bind",
        action="append",
        default=None,
        metavar="NAME=VALUE",
        help="numeric binding for a variable (repeatable; VALUE may be numeric arithmetic)",
    )
    sp.add_argument("--target", default=None, help="for relations, evaluate RHS/LHS or the named dependent variable")
    sp.add_argument("--partial", action="store_true", help="return the unevaluated expression plus missing bindings")
    sp.add_argument("--show-formula", action="store_true", help="print the normalized formula used")
    sp.add_argument(
        "--unit",
        action="append",
        default=None,
        metavar="VAR:UNIT",
        help="declare unit for a variable (repeatable, e.g. --unit F:N --unit m:kg); echoed in output",
    )
    sp.add_argument(
        "--solve-for",
        default=None,
        metavar="VAR",
        help="algebraically solve the equation for VAR using sympy (requires an equation with '=')",
    )
    sp.set_defaults(handler=cmd_calc)

    sp = sub.add_parser("reduce", help="show an operator's canonical reduction")
    sp.add_argument("op_id")
    sp.set_defaults(handler=cmd_reduce)

    sp = sub.add_parser("search", help="text search over the graph")
    sp.add_argument("query")
    sp.add_argument("-n", "--limit", type=int, default=10)
    sp.set_defaults(handler=cmd_search)

    sp = sub.add_parser("rag", help="retrieval-augmented context pack")
    sp.add_argument("query")
    sp.add_argument("-k", "--limit", type=int, default=5)
    sp.add_argument("-H", "--hops", type=int, default=2)
    sp.set_defaults(handler=cmd_rag)

    sp = sub.add_parser("show", help="print a node's detail card")
    sp.add_argument("id")
    sp.set_defaults(handler=cmd_show)

    sp = sub.add_parser("bridges", help="show cross-area graph bridges for a node")
    sp.add_argument("id")
    sp.add_argument("--limit", type=int, default=20)
    sp.add_argument("--provenance", choices=["curated", "auto", "all"], default="all")
    sp.set_defaults(handler=cmd_bridges)

    sp = sub.add_parser("ops", help="list operators (optionally filter by tier)")
    sp.add_argument("--tier", type=int, default=None)
    sp.set_defaults(handler=cmd_ops)

    sp = sub.add_parser("canonicalize", aliases=["latex2eml"], help="convert LaTeX to the canonical s-expression form")
    sp.add_argument("latex")
    sp.set_defaults(handler=cmd_latex2eml)

    sp = sub.add_parser("stats", help="graph statistics")
    sp.set_defaults(handler=cmd_stats)

    sp = sub.add_parser("discover", help="symbolic regression: search for short expressions that fit data")
    sp.add_argument("data", help="CSV file path, '-' for stdin, or literal CSV text")
    sp.add_argument("--y", required=True, help="name of the dependent column")
    sp.add_argument("--x", required=True, help="comma-separated list of independent columns")
    sp.add_argument("--max-depth", type=int, default=5, dest="max_depth")
    sp.add_argument("--max-size", type=int, default=25, dest="max_size")
    sp.add_argument("--budget", type=int, default=5000)
    sp.add_argument("--alphabet", default="eml-extended", choices=list(ALPHABETS_CHOICES))
    sp.add_argument("--objective", default="match", choices=["match", "novel", "fit-purity"],
                    help="'match' (default) weights fit+simplicity; 'novel' favors non-catalogue forms; "
                         "'fit-purity' leans heavily on fit (w_fit=0.9, w_simp=0.1) for pure-form recovery.")
    sp.add_argument("--top", type=int, default=10)
    sp.add_argument("--seed", type=int, default=7)
    sp.add_argument("--output", default="text", choices=["text", "json"])
    sp.add_argument("--graph-filter", action="store_true", dest="graph_filter",
                    help="match candidates against the catalogue and surface known-equation hits")
    sp.add_argument("--novelty-only", action="store_true", dest="novelty_only",
                    help="drop candidates that match a known catalogue node")
    sp.add_argument("--commit-novel", action="store_true", dest="commit_novel",
                    help="append novel high-robustness candidates to data/equations.json as discovered_N nodes")
    sp.add_argument("--deep-match", action="store_true", dest="deep_match", default=True,
                    help="run sympy-backed symbolic-equivalence check on top novel candidates (Phase 3 Tier E); default on")
    sp.add_argument("--no-deep-match", action="store_false", dest="deep_match",
                    help="disable deep_match for speed")
    sp.add_argument("--deep-match-retry", action="store_true", dest="deep_match_retry",
                    help="re-run deep_match with 10x per-candidate budget on previously timed-out candidates")
    sp.set_defaults(handler=cmd_discover)

    sp = sub.add_parser("prove", help="lint a .mg proof file step by step")
    sp.add_argument("file", help="path to a .mg proof file")
    sp.add_argument("-f", "--format", choices=["auto", "latex", "canonical", "eml"], default="auto",
                    help="'canonical' is the supported name; 'eml' is kept as a silent alias.")
    stop_group = sp.add_mutually_exclusive_group()
    stop_group.add_argument("--stop-at-fail", action="store_true", default=True,
                            dest="stop_at_fail",
                            help="stop after the first failing step (default)")
    stop_group.add_argument("--run-all", action="store_false", dest="stop_at_fail",
                            help="evaluate every step even after a failure")
    sp.add_argument("--output", choices=["text", "json"], default="text")
    sp.add_argument("-v", "--verbose", action="store_true")
    sp.add_argument("--lint-only", action="store_true",
                    help="parse only, don't verify")
    sp.add_argument("--no-diagnosis", action="store_true",
                    help="skip the Phase-2 diagnostic classifier (Phase 1 default behaviour)")
    sp.set_defaults(handler=cmd_prove)

    sp = sub.add_parser("solve-ode", help="solve an ODE via sympy.dsolve and numerically verify")
    sp.add_argument("ode", help="ODE in text form, e.g. \"y' = y\" or \"y'' + y = 0\"")
    sp.add_argument("--func", default="y", help="unknown function name (default: y)")
    sp.add_argument("--var", default="x", help="independent variable name (default: x)")
    sp.add_argument("--ic", action="append", default=None, metavar="Y(X0)=V",
                    help="initial condition, e.g. --ic 'y(0)=1' (repeatable)")
    sp.set_defaults(handler=cmd_solve_ode)

    sp = sub.add_parser("reindex", help="rebuild the hybrid retrieval index (dense + sparse)")
    sp.set_defaults(handler=cmd_reindex)

    sp = sub.add_parser("eval-retrieval", help="evaluate retrieval recall on the gold query set")
    sp.add_argument("--gold", default=None, help="path to gold_queries.json (default: data/eval/gold_queries.json)")
    sp.add_argument("--record", action="store_true", help="persist a dated snapshot under data/eval/")
    sp.set_defaults(handler=cmd_eval_retrieval)

    pack_parser = sub.add_parser(
        "pack",
        help="versioned data-pack lifecycle (create / ingest / validate / promote / rollback / status)",
    )
    pack_sub = pack_parser.add_subparsers(dest="pack_cmd", required=True)

    sp_create = pack_sub.add_parser("create", help="create a new pack scaffold")
    sp_create.add_argument("pack_id")
    sp_create.add_argument("--title", default="")
    sp_create.add_argument("--source-corpus", default="", dest="source_corpus")
    sp_create.add_argument("--reviewer", default=None)
    sp_create.set_defaults(handler=cmd_pack_create)

    sp_ingest = pack_sub.add_parser("ingest", help="ingest a corpus file or directory into a pack")
    sp_ingest.add_argument("pack_id")
    sp_ingest.add_argument("corpus", help=".tex / .md file, or a directory of them")
    sp_ingest.add_argument("--dry-run", action="store_true", dest="dry_run")
    sp_ingest.add_argument("--accept-definition", action="store_true", dest="accept_definition")
    sp_ingest.add_argument(
        "--definition-justification",
        default="",
        dest="definition_justification",
        metavar="TEXT",
        help=(
            "Required with --accept-definition for definition-shape rows. "
            "Stored on the committed node's source provenance and read by "
            "validate_pack. Without it definition rows are skipped to "
            "match safer legacy ingest behavior."
        ),
    )
    sp_ingest.add_argument("--force-source", action="store_true", dest="force_source")
    sp_ingest.add_argument("-s", "--samples", type=int, default=5)
    sp_ingest.add_argument("-t", "--tolerance", type=float, default=1e-6)
    sp_ingest.set_defaults(handler=cmd_pack_ingest)

    sp_validate = pack_sub.add_parser("validate", help="run all gates and write reports/quality.json")
    sp_validate.add_argument("pack_id")
    sp_validate.set_defaults(handler=cmd_pack_validate)

    sp_promote = pack_sub.add_parser("promote", help="enable a validated pack")
    sp_promote.add_argument("pack_id")
    sp_promote.set_defaults(handler=cmd_pack_promote)

    sp_rollback = pack_sub.add_parser("rollback", help="disable an enabled pack atomically")
    sp_rollback.add_argument("pack_id")
    sp_rollback.set_defaults(handler=cmd_pack_rollback)

    sp_status = pack_sub.add_parser("status", help="show pack manifest summary")
    sp_status.add_argument("pack_id", nargs="?", default=None)
    sp_status.set_defaults(handler=cmd_pack_status)

    sp_review = pack_sub.add_parser("review", help="run a Claude Code structured review for a pack candidate")
    sp_review.add_argument("pack_id")
    sp_review.add_argument("--prompt-file", required=True, help="bounded review prompt file")
    sp_review.add_argument("--node-id", default="pack", help="candidate node id, or 'pack' for batch review")
    sp_review.add_argument(
        "--role",
        choices=("extractor", "skeptic"),
        default="skeptic",
        help="two-pass review role",
    )
    sp_review.add_argument("--claude-bin", default="claude", help="Claude Code executable")
    sp_review.add_argument(
        "--dry-run",
        action="store_true",
        help="print the Claude command without running auth or review",
    )
    sp_review.set_defaults(handler=cmd_pack_review)

    sp = sub.add_parser("ingest", help="extract & verify equations from a .tex or .md file")
    sp.add_argument("path")
    sp.add_argument("-s", "--samples", type=int, default=5)
    sp.add_argument("-t", "--tolerance", type=float, default=1e-6)
    sp.add_argument("--out", help="write verified equations to this JSON file")
    sp.add_argument(
        "--commit",
        action="store_true",
        help="append verified equations to data/equations.json as ingested_* nodes",
    )
    sp.add_argument(
        "--accept-definition",
        action="store_true",
        dest="accept_definition",
        help=(
            "Phase 3B.0: required to commit definition-shaped claims "
            "(LHS is a bare dependent variable). Without the flag, "
            "definition rows are skipped during --commit."
        ),
    )
    sp.add_argument(
        "--definition-justification",
        default="",
        dest="definition_justification",
        metavar="TEXT",
        help=(
            "Required with --accept-definition for novel definition LHS "
            "symbols that are not listed in data/definition_glossary.json. "
            "Stored in node source provenance."
        ),
    )
    sp.add_argument(
        "--force-source",
        action="store_true",
        dest="force_source",
        help=(
            "Phase 3B.0: bypass the source-identity dedup ledger and "
            "proceed even when this paper (matched by DOI / arXiv / "
            "sha256) was already ingested under a different filename."
        ),
    )
    sp.add_argument(
        "--tables",
        action="store_true",
        help=(
            "Phase 6A.1: heuristically extract LaTeX \\begin{table} blocks "
            "and append rows to data/ingested/_multimodal/tables.jsonl. "
            "Stdlib only — no PDF / OCR. Always written, both in dry-run "
            "and --commit paths."
        ),
    )
    sp.add_argument(
        "--figures",
        action="store_true",
        help=(
            "Phase 6A.1: heuristically extract LaTeX \\begin{figure} blocks "
            "and append rows to data/ingested/_multimodal/figures.jsonl. "
            "Stdlib only — no PDF / OCR. Always written, both in dry-run "
            "and --commit paths."
        ),
    )
    sp.add_argument("-v", "--verbose", action="store_true")
    sp.add_argument("-q", "--quiet", action="store_true")
    sp.set_defaults(handler=cmd_ingest)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    # Thread --json through into subcommand namespace.
    args.json = getattr(args, "json", False)
    return args.handler(args)


if __name__ == "__main__":
    raise SystemExit(main())
