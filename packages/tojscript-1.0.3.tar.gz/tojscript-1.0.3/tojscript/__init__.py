from colorama import Fore, Style, init
init()
import re
import sys
import codecs

# 🎨 Цвета
colors = {
    "сабз": Fore.GREEN,
    "сурх": Fore.RED,
    "зард": Fore.YELLOW,
    "кабуд": Fore.BLUE,
    "норинҷӣ": Fore.LIGHTYELLOW_EX,
    "reset": Style.RESET_ALL
}

def toj_print(*args):
    text = ""
    color = ""
    for arg in args:
        if isinstance(arg, str):
            clean = arg.strip("/")
            if clean in colors:
                color = colors[clean]
                continue
        text += str(arg) + " "
    if color:
        print(color + text.strip() + colors["reset"])
    else:
        print(text.strip())

def brb(a, b): return a == b
def nbr(a, b): return a != b

def fakt(n):
    n = int(n)
    if n < 0: print("Хато: адад бояд мусбат бошад"); exit()
    result = 1
    for i in range(1, n + 1): result *= i
    return result

def fibonachi(n):
    n = int(n)
    if n <= 0: print("Хато: адад бояд > 0 бошад"); exit()
    a, b = 0, 1
    for _ in range(n - 1): a, b = b, a + b
    return b

def musb(x): return abs(int(x))

def darozi(x):
    try: return len(x)
    except: print("Хато: дарозӣ танҳо барои сатр ё рӯйхат аст"); exit()

def ilova(arr, x): arr.append(x); return arr
def pok(arr, i): return arr[i]
def калон(s): return str(s).upper()
def хурд(s): return str(s).lower()
def min_tj(*args): return min(*args)
def max_tj(*args): return max(*args)

_input_buffer = []
def toj_input(prompt=""):
    global _input_buffer
    while not _input_buffer:
        line = input(prompt)
        parts = line.split()
        if len(parts) > 1:
            _input_buffer = parts
        else:
            return line.strip()
    return _input_buffer.pop(0)

TOJ_GLOBALS = {
    "toj_print": toj_print, "brb": brb, "nbr": nbr,
    "fakt": fakt, "fibonachi": fibonachi, "musb": musb,
    "darozi": darozi, "ilova": ilova, "pok": pok,
    "калон": калон, "хурд": хурд,
    "min_tj": min_tj, "max_tj": max_tj,
    "toj_input": toj_input, "input": toj_input, "print": print
}

def toj_to_python(code):
    # убираем строки import tojscript
    code = re.sub(r'^\s*import\s+tojscript\s*$', '', code, flags=re.MULTILINE)

    translations = {
        "агар": "if", "дигар": "else", "чоп": "toj_print",
        "ворид": "toj_input", "барои": "for", "дар": "in",
        "функсия": "def", "баргардон": "return",
        "бутун": "int", "сатр": "str",
        "брб": "brb", "нбр": "nbr", "факт": "fakt",
        "фибоначи": "fibonachi", "мусб": "musb",
        "дарозӣ": "darozi", "мин": "min_tj", "макс": "max_tj",
    }

    lines = code.split("\n")
    new_lines = []
    indent = 0

    for line in lines:
        stripped = line.strip()
        stripped = re.sub(r'(\w+)\.дарозӣ', r'darozi(\1)', stripped)
        stripped = re.sub(r'(\w+)\.калон\(\)', r'калон(\1)', stripped)
        stripped = re.sub(r'(\w+)\.хурд\(\)', r'хурд(\1)', stripped)

        if not stripped:
            continue

        while stripped.startswith("}"):
            indent = max(indent - 1, 0)
            stripped = stripped[1:].strip()

        if not stripped:
            continue

        if stripped.startswith("оғоз()"):
            new_lines.append("    " * indent + "if True:")
            indent += 1
            continue

        if stripped == "{":
            indent += 1
            continue

        for toj, py in translations.items():
            stripped = re.sub(rf'\b{toj}\s*\(', f'{py}(', stripped)

        if "{" in stripped:
            stripped = stripped.replace("{", ":").replace("::", ":")
            new_lines.append("    " * indent + stripped)
            indent += 1
        else:
            new_lines.append("    " * indent + stripped)

    return "\n".join(new_lines)

def runs(code):
    """Запуск таджикского кода из строки"""
    python_code = toj_to_python(code)
    try:
        exec(python_code, {**TOJ_GLOBALS, **locals()})
    except Exception as e:
        print("Хато:", e)

def run(filename):
    """Запуск .toj или .py файла"""
    with open(filename, "r", encoding="utf-8") as f:
        code = f.read()
    python_code = toj_to_python(code)
    try:
        exec(python_code, {**TOJ_GLOBALS, **locals()})
    except Exception as e:
        print("Хато:", e)

# 🔥 Хук: если запускают .py файл с таджикским кодом
class TojImportHook:
    def find_module(self, name, path=None):
        if name == "tojscript":
            return self
        return None
    def load_module(self, name):
        import types
        mod = types.ModuleType(name)
        mod.run = run
        mod.runs = runs
        mod.toj_to_python = toj_to_python
        sys.modules[name] = mod
        return mod

sys.meta_path.insert(0, TojImportHook())

def main():
    if len(sys.argv) > 1:
        filename = sys.argv[1]
        run(filename)
    else:
        run("main.toj")

if __name__ == "__main__":
    main()
