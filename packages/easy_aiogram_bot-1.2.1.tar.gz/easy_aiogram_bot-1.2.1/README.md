# easyaiogram

🚀 **easyaiogram** is a lightweight and beginner-friendly wrapper built on top of **Aiogram 3.x**.

It helps you create Telegram bots faster with clean decorators, simple keyboard helpers, callback handlers, and less boilerplate code.

---

## ✨ Features

- ⚡ Easy bot initialization
- 🧩 Command handlers
- 💬 Text handlers
- 🔎 Contains text handlers
- 🧪 Regex handlers
- 🔘 Callback query handlers
- ⌨️ Reply keyboard generator
- 📲 Inline keyboard generator
- 📤 Message, photo, and document helpers
- 🚀 Simple `start()` and `run()` methods

---

## 📦 Installation

    pip install easyaiogram

---

## 🚀 Quick Start

    from easyaiogram import EasyAiogram
    from aiogram.types import Message, CallbackQuery

    bot = EasyAiogram(token="YOUR_BOT_TOKEN")

    menu = bot.make_buttons(["Features", "GitHub", "Support"], row_width=2)
    inline_menu = bot.make_inline_buttons(["Profile", "Settings", "Help"], row_width=2)

    @bot.on_command("start")
    async def start(message: Message):
        await message.answer("Welcome to easyaiogram!", reply_markup=menu)

    @bot.on_text("features")
    async def features(message: Message):
        await message.answer("easyaiogram makes Aiogram easier and cleaner.")

    @bot.on_contains("help")
    async def help_handler(message: Message):
        await message.answer("How can I help you?")

    @bot.on_regex(r"^\d+$")
    async def number_handler(message: Message):
        await message.answer("You sent a number.")

    @bot.on_callback("btn:1")
    async def profile_callback(callback: CallbackQuery):
        await callback.answer("Profile clicked!")

    if __name__ == "__main__":
        bot.start()

---

## 🧠 Usage

### Create Bot

    from easyaiogram import EasyAiogram

    bot = EasyAiogram(token="YOUR_BOT_TOKEN")

### Command Handler

    @bot.on_command("start")
    async def start(message):
        await message.answer("Hello!")

### Text Handler

    @bot.on_text("hello")
    async def hello(message):
        await message.answer("Hi!")

### Contains Handler

    @bot.on_contains("help")
    async def help_handler(message):
        await message.answer("How can I help you?")

### Regex Handler

    @bot.on_regex(r"^\d+$")
    async def number_handler(message):
        await message.answer("You sent a number.")

### Callback Handler

    @bot.on_callback("btn:1")
    async def callback_handler(callback):
        await callback.answer("Button clicked!")

---

## ⌨️ Reply Keyboard

    menu = bot.make_buttons(
        ["Profile", "Settings", "Help"],
        row_width=2
    )

    await message.answer("Choose:", reply_markup=menu)

---

## 🔘 Inline Keyboard

    inline_menu = bot.make_inline_buttons(
        ["Profile", "Settings", "Help"],
        row_width=2
    )

    await message.answer("Choose:", reply_markup=inline_menu)

Default callback data:

    btn:1
    btn:2
    btn:3

Custom callback prefix:

    inline_menu = bot.make_inline_buttons(
        ["Profile", "Settings", "Help"],
        row_width=2,
        callback_prefix="menu"
    )

Generated callback data:

    menu:1
    menu:2
    menu:3

---

## 📤 Helper Methods

    await bot.send(chat_id, "Hello!")
    await bot.answer(message, "Hello!")
    await bot.reply(message, "Reply text")
    await bot.edit_callback(callback, "Updated text")
    await bot.send_photo(chat_id, photo="photo_url")
    await bot.send_document(chat_id, document="file_url")

---

## ▶️ Start Bot

    bot.start()

or:

    bot.run()

---

## 🔥 Why easyaiogram?

Standard Aiogram requires more setup:

    import asyncio
    from aiogram import Bot, Dispatcher

    bot = Bot("TOKEN")
    dp = Dispatcher()

    async def main():
        await dp.start_polling(bot)

    asyncio.run(main())

With easyaiogram:

    from easyaiogram import EasyAiogram

    bot = EasyAiogram("TOKEN")
    bot.start()

---

## 📌 Requirements

- Python 3.10+
- Aiogram 3.x

---

## 📄 License

MIT License

---

Made with ❤️ for Python and Telegram bot developers.