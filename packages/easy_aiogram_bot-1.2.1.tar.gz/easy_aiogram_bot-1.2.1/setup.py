from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="easy-aiogram-bot",
    version="1.2.1",
    author="MikioNatsu",
    author_email="alonenestgaming@gmail.com",
    description="Advanced, lightweight wrapper for Aiogram 3.x with inline buttons and regex support.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "aiogram>=3.0.0",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.8',
)
