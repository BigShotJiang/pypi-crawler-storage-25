from .core import EasyAiogram

__all__ = ["EasyAiogram"]
