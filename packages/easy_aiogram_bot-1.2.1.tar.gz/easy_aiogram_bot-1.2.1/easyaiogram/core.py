import asyncio
import re
from typing import Callable, Iterable, Any

from aiogram import Bot, Dispatcher, Router, F
from aiogram.client.default import DefaultBotProperties
from aiogram.filters import Command
from aiogram.types import (
    Message,
    CallbackQuery,
    ReplyKeyboardMarkup,
    InlineKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardButton,
)


class EasyAiogram:
    def __init__(
        self,
        token: str,
        parse_mode: str = "HTML",
        disable_web_page_preview: bool = True,
    ):
        """
        Easy and lightweight wrapper over Aiogram 3.x.
        """
        self.bot = Bot(
            token=token,
            default=DefaultBotProperties(
                parse_mode=parse_mode,
                link_preview_is_disabled=disable_web_page_preview,
            ),
        )
        self.dp = Dispatcher()
        self.router = Router()
        self.dp.include_router(self.router)

    # -----------------------------
    # Handlers
    # -----------------------------
    def on_command(self, cmd: str):
        """
        Decorator for Telegram commands like /start, /help, etc.
        """
        def decorator(func):
            self.router.message(Command(cmd))(func)
            return func
        return decorator

    def on_text(self, text: str):
        """
        Decorator for exact text messages. Case-insensitive matching.
        """
        target = text.casefold()

        def text_filter(message: Message) -> bool:
            return bool(message.text) and message.text.casefold() == target

        def decorator(func):
            self.router.message(text_filter)(func)
            return func
        return decorator

    def on_contains(self, text: str):
        """
        Decorator for messages that contain the given text. Case-insensitive.
        """
        target = text.casefold()

        def contains_filter(message: Message) -> bool:
            return bool(message.text) and target in message.text.casefold()

        def decorator(func):
            self.router.message(contains_filter)(func)
            return func
        return decorator

    def on_regex(self, pattern: str):
        """
        Decorator for regex-based message matching.
        """
        compiled = re.compile(pattern, re.IGNORECASE)

        def regex_filter(message: Message) -> bool:
            return bool(message.text) and bool(compiled.search(message.text))

        def decorator(func):
            self.router.message(regex_filter)(func)
            return func
        return decorator

    def on_callback(self, data: str):
        """
        Decorator for inline keyboard callback data.
        """
        def decorator(func):
            self.router.callback_query(F.data == data)(func)
            return func
        return decorator

    # -----------------------------
    # Keyboards
    # -----------------------------
    def make_buttons(
        self,
        texts: Iterable[str],
        row_width: int = 2,
        resize_keyboard: bool = True,
        one_time_keyboard: bool = False,
        selective: bool = False,
    ) -> ReplyKeyboardMarkup:
        """
        Create reply keyboard from a list of button texts.
        """
        keyboard = []
        row = []

        for text in texts:
            row.append(KeyboardButton(text=text))
            if len(row) >= row_width:
                keyboard.append(row)
                row = []

        if row:
            keyboard.append(row)

        return ReplyKeyboardMarkup(
            keyboard=keyboard,
            resize_keyboard=resize_keyboard,
            one_time_keyboard=one_time_keyboard,
            selective=selective,
        )

    def make_inline_buttons(
        self,
        texts: Iterable[str],
        row_width: int = 2,
        callback_prefix: str = "btn",
    ) -> InlineKeyboardMarkup:
        """
        Create inline keyboard from a list of button texts.
        Callback data will be generated automatically.
        """
        keyboard = []
        row = []

        for i, text in enumerate(texts, start=1):
            button = InlineKeyboardButton(
                text=text,
                callback_data=f"{callback_prefix}:{i}",
            )
            row.append(button)

            if len(row) >= row_width:
                keyboard.append(row)
                row = []

        if row:
            keyboard.append(row)

        return InlineKeyboardMarkup(inline_keyboard=keyboard)

    # -----------------------------
    # Helpers
    # -----------------------------
    async def send(self, chat_id: int, text: str, **kwargs: Any):
        return await self.bot.send_message(chat_id=chat_id, text=text, **kwargs)

    async def reply(self, message: Message, text: str, **kwargs: Any):
        return await message.reply(text, **kwargs)

    async def answer(self, message: Message, text: str, **kwargs: Any):
        return await message.answer(text, **kwargs)

    async def edit_callback(self, callback: CallbackQuery, text: str, **kwargs: Any):
        return await callback.message.edit_text(text, **kwargs)

    async def send_photo(self, chat_id: int, photo: str, caption: str = None, **kwargs: Any):
        return await self.bot.send_photo(chat_id=chat_id, photo=photo, caption=caption, **kwargs)

    async def send_document(self, chat_id: int, document: str, caption: str = None, **kwargs: Any):
        return await self.bot.send_document(chat_id=chat_id, document=document, caption=caption, **kwargs)

    # -----------------------------
    # Start bot
    # -----------------------------
    def start(self):
        """
        Start polling with asyncio.run().
        """
        print("🚀 easyaiogram is running...")
        asyncio.run(self.dp.start_polling(self.bot))

    def run(self):
        """
        Alias for start().
        """
        self.start()
