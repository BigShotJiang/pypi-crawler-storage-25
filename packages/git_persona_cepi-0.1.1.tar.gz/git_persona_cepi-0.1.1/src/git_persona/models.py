"""Data models for git-persona."""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class CommitData:
    """A single commit event."""

    sha: str
    message: str
    timestamp: datetime
    repo_name: str
    repo_language: str | None = None
    additions: int = 0
    deletions: int = 0

    @property
    def total_changes(self) -> int:
        return self.additions + self.deletions

    @property
    def subject(self) -> str:
        """First line of the commit message."""
        return self.message.split("\n")[0].strip()


@dataclass
class RepoInfo:
    """Metadata for a GitHub repository."""

    name: str
    full_name: str
    primary_language: str | None
    is_fork: bool
    stars: int
    commit_count: int = 0


@dataclass
class UserProfile:
    """GitHub user profile data."""

    username: str
    total_repos: int
    account_age_days: int
    followers: int
    name: str | None = None


@dataclass
class CollectionResult:
    """Raw collection output passed to analyzers."""

    user: UserProfile
    commits: list[CommitData] = field(default_factory=list)
    repos: list[RepoInfo] = field(default_factory=list)
    analysis_days: int = 90
    is_deep_scan: bool = False

    @property
    def total_commits(self) -> int:
        return len(self.commits)

    @property
    def date_range(self) -> tuple[datetime | None, datetime | None]:
        if not self.commits:
            return None, None
        times = [c.timestamp for c in self.commits]
        return min(times), max(times)
