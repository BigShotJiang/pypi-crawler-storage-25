"""Ratio analyzer: Pioneer (P) vs Repairman (R)."""

import re
from collections import Counter

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.models import CommitData

# Keyword patterns per category (matched against commit subject, case-insensitive)
_PATTERNS: dict[str, re.Pattern] = {
    "feature": re.compile(
        r"\b(feat|feature|add|implement|new|create|introduce|support|enable)\b",
        re.IGNORECASE,
    ),
    "fix": re.compile(
        r"\b(fix|bug|patch|hotfix|resolve|repair|correct|revert|workaround)\b",
        re.IGNORECASE,
    ),
    "refactor": re.compile(
        r"\b(refactor|clean|cleanup|rename|move|extract|reorganize|restructure|simplify)\b",
        re.IGNORECASE,
    ),
    "docs": re.compile(
        r"\b(doc|docs|readme|changelog|comment|licence|license)\b",
        re.IGNORECASE,
    ),
    "test": re.compile(
        r"\b(test|spec|coverage|assert)\b",
        re.IGNORECASE,
    ),
    "chore": re.compile(
        r"\b(chore|ci|build|release|version|bump|dep|dependency|dependencies|upgrade|update)\b",
        re.IGNORECASE,
    ),
}


def _classify(subject: str) -> str:
    for category, pattern in _PATTERNS.items():
        if pattern.search(subject):
            return category
    return "other"


class RatioAnalyzer:
    def analyze(self, commits: list[CommitData]) -> AnalysisMetrics:
        if not commits:
            return AnalysisMetrics(
                axis_score=AxisScore("P/R", "Pioneer", "Repairman", 0.5),
                raw={},
            )

        counts: Counter[str] = Counter(_classify(c.subject) for c in commits)
        total = len(commits)

        feature_n = counts["feature"]
        fix_n = counts["fix"]
        classifiable = feature_n + fix_n

        # repairman_ratio: 1.0 = all fixes, 0.0 = all features
        if classifiable == 0:
            repairman_ratio = 0.5
        else:
            repairman_ratio = fix_n / classifiable

        return AnalysisMetrics(
            axis_score=AxisScore("P/R", "Pioneer", "Repairman", repairman_ratio),
            raw={
                "feature_ratio": round(feature_n / total, 3),
                "fix_ratio": round(fix_n / total, 3),
                "refactor_ratio": round(counts["refactor"] / total, 3),
                "docs_ratio": round(counts["docs"] / total, 3),
                "test_ratio": round(counts["test"] / total, 3),
                "chore_ratio": round(counts["chore"] / total, 3),
                "other_ratio": round(counts["other"] / total, 3),
                "category_counts": dict(counts),
            },
        )
