"""Message style analyzer: Verbose (V) vs Terse (T)."""

import re
import statistics

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.models import CommitData

# Conventional commit prefixes (feat, fix, docs, …)
_CONVENTIONAL = re.compile(
    r"^(feat|fix|docs|style|refactor|perf|test|chore|build|ci|revert)(\(.+?\))?!?:",
    re.IGNORECASE,
)

# Basic Unicode emoji range + common text emoji patterns
_EMOJI = re.compile(
    r"[\U0001F300-\U0001FFFF\U00002600-\U000027BF\U0000231A-\U0000231B]"
    r"|:[a-z_]+:",
    re.UNICODE,
)

# Frustration / informal markers
_FRUSTRATION = re.compile(
    r"\b(fuck|shit|wip|todo|fixme|hack|ugly|crap|wtf|omg)\b",
    re.IGNORECASE,
)

# Threshold: median subject length above this → "Verbose"
VERBOSE_THRESHOLD = 50


class MessageStyleAnalyzer:
    def analyze(self, commits: list[CommitData]) -> AnalysisMetrics:
        if not commits:
            return AnalysisMetrics(
                axis_score=AxisScore("V/T", "Verbose", "Terse", 0.5),
                raw={},
            )

        subjects = [c.subject for c in commits]
        lengths = [len(s) for s in subjects]
        median_len = statistics.median(lengths)

        emoji_count = sum(bool(_EMOJI.search(s)) for s in subjects)
        conventional_count = sum(bool(_CONVENTIONAL.match(s)) for s in subjects)
        frustration_count = sum(bool(_FRUSTRATION.search(s)) for s in subjects)
        allcaps_count = sum(
            1 for s in subjects if s == s.upper() and s.strip() and not s.isdigit()
        )

        total = len(subjects)
        # terse_ratio: 1.0 = very short messages (Terse), 0.0 = long messages (Verbose)
        # Map median length [0, 100+] → [1.0, 0.0]
        terse_ratio = max(0.0, 1.0 - median_len / 100.0)

        return AnalysisMetrics(
            axis_score=AxisScore("V/T", "Verbose", "Terse", terse_ratio),
            raw={
                "median_subject_length": round(median_len, 1),
                "mean_subject_length": round(statistics.mean(lengths), 1),
                "emoji_ratio": round(emoji_count / total, 3),
                "conventional_commit_ratio": round(conventional_count / total, 3),
                "frustration_ratio": round(frustration_count / total, 3),
                "allcaps_ratio": round(allcaps_count / total, 3),
                "total_commits": total,
            },
        )
