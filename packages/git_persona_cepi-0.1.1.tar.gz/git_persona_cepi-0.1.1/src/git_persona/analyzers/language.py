"""Language analyzer: technology stack profile."""

from collections import Counter

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.models import CommitData

# Broad language categories
_CATEGORIES: dict[str, list[str]] = {
    "systems": ["C", "C++", "Rust", "Go", "Assembly", "Zig"],
    "web_frontend": ["JavaScript", "TypeScript", "HTML", "CSS", "Vue", "Svelte"],
    "web_backend": ["Python", "Ruby", "PHP", "Java", "Kotlin", "Scala", "Elixir", "Go"],
    "data_science": ["Python", "R", "Julia", "MATLAB", "Jupyter Notebook"],
    "mobile": ["Swift", "Kotlin", "Dart", "Objective-C"],
    "devops": ["Shell", "Dockerfile", "HCL", "Makefile", "PowerShell"],
    "functional": ["Haskell", "OCaml", "Elixir", "Erlang", "Clojure", "F#"],
}


def _dominant_category(lang_counts: Counter) -> str:
    category_scores: Counter[str] = Counter()
    total = sum(lang_counts.values())
    if total == 0:
        return "unknown"
    for lang, count in lang_counts.items():
        for category, members in _CATEGORIES.items():
            if lang in members:
                category_scores[category] += count
    if not category_scores:
        return "polyglot"
    return category_scores.most_common(1)[0][0]


class LanguageAnalyzer:
    def analyze(self, commits: list[CommitData]) -> AnalysisMetrics:
        lang_counts: Counter[str] = Counter(
            c.repo_language for c in commits if c.repo_language
        )
        total = sum(lang_counts.values())

        if total == 0:
            return AnalysisMetrics(
                axis_score=AxisScore("L/L", "Specialist", "Polyglot", 0.5),
                raw={"top_languages": [], "dominant_category": "unknown"},
            )

        top3 = lang_counts.most_common(3)
        langs_above_5pct = sum(1 for _, c in lang_counts.items() if c / total >= 0.05)
        polyglot_score = min(1.0, (langs_above_5pct - 1) / 4.0)  # 1 lang→0, 5+→1

        return AnalysisMetrics(
            axis_score=AxisScore("L/L", "Specialist", "Polyglot", polyglot_score),
            raw={
                "top_languages": [
                    {"language": lang, "ratio": round(count / total, 3)}
                    for lang, count in top3
                ],
                "distinct_languages": len(lang_counts),
                "langs_above_5pct": langs_above_5pct,
                "dominant_category": _dominant_category(lang_counts),
                "language_counts": dict(lang_counts.most_common(10)),
            },
        )
