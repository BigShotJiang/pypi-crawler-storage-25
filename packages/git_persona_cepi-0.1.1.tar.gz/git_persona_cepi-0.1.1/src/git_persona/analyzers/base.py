"""Base types shared by all analyzers."""

from dataclasses import dataclass, field
from typing import Any, Protocol

from git_persona.models import CommitData


@dataclass
class AxisScore:
    """Represents where a user falls on one personality axis.

    value: float in [0.0, 1.0]
      0.0 = fully at left_pole
      1.0 = fully at right_pole
      0.5 = perfectly in the middle
    """

    axis: str           # e.g. "S/B"
    left_pole: str      # e.g. "Surgeon"
    right_pole: str     # e.g. "Bulldozer"
    value: float        # 0.0–1.0
    label: str = ""     # e.g. "S" or "B"

    def __post_init__(self) -> None:
        self.value = max(0.0, min(1.0, self.value))
        if not self.label:
            self.label = self.right_pole[0] if self.value >= 0.5 else self.left_pole[0]


@dataclass
class AnalysisMetrics:
    """Container for all analysis output from one analyzer."""

    axis_score: AxisScore
    raw: dict[str, Any] = field(default_factory=dict)


class Analyzer(Protocol):
    def analyze(self, commits: list[CommitData]) -> AnalysisMetrics: ...
