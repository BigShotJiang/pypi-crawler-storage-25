"""Timing analyzer: Morning Lark (M) vs Night Owl (N)."""

from collections import Counter
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.models import CommitData

# Hours considered "daytime" (inclusive start, exclusive end)
DAY_START = 6   # 06:00
DAY_END = 18    # 18:00


class TimingAnalyzer:
    def __init__(self, timezone: str | None = None) -> None:
        self._tz: ZoneInfo | None = None
        if timezone:
            try:
                self._tz = ZoneInfo(timezone)
            except (ZoneInfoNotFoundError, KeyError):
                pass  # fall back to UTC

    def analyze(self, commits: list[CommitData]) -> AnalysisMetrics:
        if not commits:
            return AnalysisMetrics(
                axis_score=AxisScore("M/N", "Morning Lark", "Night Owl", 0.5),
                raw={},
            )

        hours: list[int] = []
        weekday_counts: Counter[int] = Counter()

        for c in commits:
            ts = c.timestamp.astimezone(self._tz) if self._tz else c.timestamp
            hours.append(ts.hour)
            weekday_counts[ts.weekday()] += 1  # 0=Mon … 6=Sun

        hour_counts = Counter(hours)
        total = len(hours)

        day_commits = sum(1 for h in hours if DAY_START <= h < DAY_END)
        night_commits = total - day_commits
        night_ratio = night_commits / total  # 0.0 = all-day, 1.0 = all-night

        weekend_commits = weekday_counts[5] + weekday_counts[6]
        weekend_ratio = weekend_commits / total

        peak_hour = max(hour_counts, key=hour_counts.get)  # type: ignore[arg-type]

        return AnalysisMetrics(
            axis_score=AxisScore("M/N", "Morning Lark", "Night Owl", night_ratio),
            raw={
                "peak_hour": peak_hour,
                "night_ratio": round(night_ratio, 3),
                "weekend_ratio": round(weekend_ratio, 3),
                "hour_distribution": dict(sorted(hour_counts.items())),
                "weekday_distribution": {
                    ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][d]: c
                    for d, c in sorted(weekday_counts.items())
                },
            },
        )
