"""Size analyzer: Surgeon (S) vs Bulldozer (B)."""

import statistics

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.models import CommitData

ATOMIC_THRESHOLD = 50     # lines changed → "atomic" commit
MEGA_THRESHOLD = 500      # lines changed → "mega" commit


class SizeAnalyzer:
    def analyze(self, commits: list[CommitData]) -> AnalysisMetrics:
        # Only use commits that have stats (i.e., were sampled for detail)
        sized = [c for c in commits if c.total_changes > 0]

        if not sized:
            return AnalysisMetrics(
                axis_score=AxisScore("S/B", "Surgeon", "Bulldozer", 0.5),
                raw={"note": "no commit size data available"},
            )

        sizes = [c.total_changes for c in sized]
        median_size = statistics.median(sizes)
        p90 = sorted(sizes)[int(len(sizes) * 0.9)]
        atomic_count = sum(1 for s in sizes if s <= ATOMIC_THRESHOLD)
        mega_count = sum(1 for s in sizes if s >= MEGA_THRESHOLD)
        total = len(sizes)

        # bulldozer_ratio: 1.0 = very large commits, 0.0 = very small commits
        # Map median size [0, 500+] → [0.0, 1.0], clamp at 500
        bulldozer_ratio = min(1.0, median_size / 500.0)

        return AnalysisMetrics(
            axis_score=AxisScore("S/B", "Surgeon", "Bulldozer", bulldozer_ratio),
            raw={
                "median_lines_changed": round(median_size, 1),
                "p90_lines_changed": p90,
                "atomic_ratio": round(atomic_count / total, 3),
                "mega_ratio": round(mega_count / total, 3),
                "sampled_commits": total,
            },
        )
