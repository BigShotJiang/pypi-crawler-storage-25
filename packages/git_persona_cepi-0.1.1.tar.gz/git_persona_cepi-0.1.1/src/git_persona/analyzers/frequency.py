"""Frequency analyzer: commit cadence and consistency metrics."""

import statistics
from collections import Counter
from datetime import date, timedelta

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.models import CommitData


class FrequencyAnalyzer:
    """Computes commit frequency and consistency.

    No axis score is produced (frequency is used as raw context in the report),
    so we emit a neutral axis score and expose all metrics via `raw`.
    """

    def analyze(self, commits: list[CommitData]) -> AnalysisMetrics:
        if not commits:
            return AnalysisMetrics(
                axis_score=AxisScore("F/F", "Sporadic", "Consistent", 0.5),
                raw={},
            )

        dates = sorted({c.timestamp.date() for c in commits})
        total_days = (dates[-1] - dates[0]).days + 1
        active_days = len(dates)
        total_commits = len(commits)

        commits_per_day = total_commits / max(total_days, 1)

        # Longest active streak (consecutive days with at least one commit)
        longest_streak = _longest_streak(dates)

        # Longest gap (days between consecutive active days)
        longest_gap = _longest_gap(dates)

        # Daily commit counts for coefficient of variation
        date_set = set(dates)
        daily_counts = [
            sum(1 for c in commits if c.timestamp.date() == d)
            for d in dates
        ]
        if len(daily_counts) >= 2:
            mean_daily = statistics.mean(daily_counts)
            std_daily = statistics.stdev(daily_counts)
            cv = std_daily / mean_daily if mean_daily > 0 else 0.0
        else:
            cv = 0.0

        # consistency_ratio: 1.0 = very consistent, 0.0 = very bursty
        # Low CV → consistent; high CV → sporadic (CV >1.5 is considered maximally bursty)
        consistency_ratio = max(0.0, 1.0 - min(cv / 1.5, 1.0))

        return AnalysisMetrics(
            axis_score=AxisScore("F/F", "Sporadic", "Consistent", consistency_ratio),
            raw={
                "total_commits": total_commits,
                "active_days": active_days,
                "total_span_days": total_days,
                "commits_per_active_day": round(total_commits / active_days, 2),
                "commits_per_calendar_day": round(commits_per_day, 3),
                "longest_streak_days": longest_streak,
                "longest_gap_days": longest_gap,
                "consistency_cv": round(cv, 3),
            },
        )


def _longest_streak(sorted_dates: list[date]) -> int:
    if not sorted_dates:
        return 0
    best = current = 1
    for i in range(1, len(sorted_dates)):
        if (sorted_dates[i] - sorted_dates[i - 1]).days == 1:
            current += 1
            best = max(best, current)
        else:
            current = 1
    return best


def _longest_gap(sorted_dates: list[date]) -> int:
    if len(sorted_dates) < 2:
        return 0
    return max(
        (sorted_dates[i] - sorted_dates[i - 1]).days
        for i in range(1, len(sorted_dates))
    )
