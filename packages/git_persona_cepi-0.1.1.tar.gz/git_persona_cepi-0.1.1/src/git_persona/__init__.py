"""git-persona: GitHub commit history analyzer and engineer personality diagnosis."""

__version__ = "0.1.0"
