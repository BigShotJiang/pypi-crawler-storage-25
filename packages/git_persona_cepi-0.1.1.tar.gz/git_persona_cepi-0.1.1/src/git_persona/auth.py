"""GitHub authentication: resolve a personal access token from multiple sources."""

import os
import subprocess


class AuthError(Exception):
    """Raised when no GitHub token can be resolved."""


def get_github_token(token: str | None = None) -> str:
    """Resolve a GitHub personal access token.

    Resolution order:
    1. Explicit --token CLI argument
    2. GITHUB_TOKEN environment variable
    3. `gh auth token` subprocess call (requires GitHub CLI)

    Returns the token string.
    Raises AuthError if no token is found.
    """
    if token:
        return token

    env_token = os.environ.get("GITHUB_TOKEN")
    if env_token:
        return env_token

    try:
        result = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            gh_token = result.stdout.strip()
            if gh_token:
                return gh_token
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    raise AuthError(
        "No GitHub token found. Provide one via:\n"
        "  --token YOUR_TOKEN\n"
        "  GITHUB_TOKEN environment variable\n"
        "  GitHub CLI: gh auth login"
    )


def validate_token_scopes(token: str, headers: dict) -> list[str]:
    """Parse X-OAuth-Scopes header and warn if 'repo' scope is missing.

    Returns the list of scopes present.
    """
    scopes_header = headers.get("x-oauth-scopes", "")
    scopes = [s.strip() for s in scopes_header.split(",") if s.strip()]
    return scopes
