"""CEPI personality type classifier: 16 engineer archetypes."""

from dataclasses import dataclass, field

from git_persona.analyzers.base import AnalysisMetrics, AxisScore


@dataclass
class PersonalityType:
    code: str           # e.g. "SNRT"
    name: str           # e.g. "The Midnight Firefighter"
    emoji: str
    description: str    # 2-3 sentence flavour text
    strengths: list[str]
    blind_spots: list[str]
    verdict: str        # One-liner punchline


# ---------------------------------------------------------------------------
# All 16 types  (axis order: S/B · M/N · P/R · V/T)
# ---------------------------------------------------------------------------
_TYPES: dict[str, PersonalityType] = {
    "SMPV": PersonalityType(
        code="SMPV", name="The Disciplined Documenter", emoji="📖",
        description=(
            "You write tidy, atomic commits with rich messages before the sun sets. "
            "Your pull requests are a pleasure to review — clean diffs, clear context, "
            "and no mysterious mega-changes. Future-you will be very grateful."
        ),
        strengths=["Crystal-clear commit history", "Easy to bisect bugs", "Excellent code reviewer"],
        blind_spots=["Might over-document trivial changes", "Can slow down in fast-moving sprints"],
        verdict="Your git log is a love letter to the next engineer.",
    ),
    "SMPT": PersonalityType(
        code="SMPT", name="The Silent Craftsman", emoji="🪚",
        description=(
            "Small commits, concise messages, and daylight hours — you are the artisan "
            "of the engineering world. You let the code speak for itself and rarely "
            "need to explain your choices twice."
        ),
        strengths=["Highly focused work sessions", "Lean, targeted commits", "Fast to merge"],
        blind_spots=["Commit messages can be cryptic to newcomers", "May skip important context"],
        verdict="A commit from you is like a scalpel — precise and efficient.",
    ),
    "SMRV": PersonalityType(
        code="SMRV", name="The Methodical Guardian", emoji="🛡️",
        description=(
            "You keep the codebase healthy one careful fix at a time, always during "
            "business hours with detailed explanations. Bugs fear you; tech debt knows "
            "your name. You are the unsung hero of production stability."
        ),
        strengths=["Excellent bug-hunting instincts", "Reliable on-call engineer", "Strong documentation habits"],
        blind_spots=["May under-invest in new features", "Can get stuck in maintenance mode"],
        verdict="The codebase sleeps soundly knowing you're on watch.",
    ),
    "SMRT": PersonalityType(
        code="SMRT", name="The Quiet Fixer", emoji="🔧",
        description=(
            "Small patches, short messages, regular hours. You fix things fast and "
            "move on — no fanfare, no lengthy explanations. The bug tracker empties "
            "mysteriously when you're around."
        ),
        strengths=["High fix velocity", "Low noise in the commit log", "Dependable in crises"],
        blind_spots=["Others may not know what you fixed or why", "Context lost over time"],
        verdict="You fix bugs the way ninjas solve problems — silently and completely.",
    ),
    "SNPV": PersonalityType(
        code="SNPV", name="The Meticulous Architect", emoji="🏛️",
        description=(
            "Late nights, precise commits, ambitious features, and thorough write-ups — "
            "you build systems with the care of an architect designing a cathedral. "
            "Every decision is documented, every edge case considered."
        ),
        strengths=["Deep system thinking", "Excellent async communicator", "Highly reviewable work"],
        blind_spots=["May over-engineer solutions", "Long nights can lead to burnout"],
        verdict="Your architecture diagrams have their own commit history.",
    ),
    "SNPT": PersonalityType(
        code="SNPT", name="The Midnight Builder", emoji="🌙",
        description=(
            "When the office goes dark, you come alive. Small focused commits, "
            "minimal ceremony — you ship features in the quiet hours when the "
            "world isn't watching and Slack is finally silent."
        ),
        strengths=["Deep focus in off-peak hours", "High feature output", "Self-directed"],
        blind_spots=["Commits can lack context for daytime reviewers", "Risk of timezone isolation"],
        verdict="Your best code was written while everyone else was asleep.",
    ),
    "SNRV": PersonalityType(
        code="SNRV", name="The Night Watch", emoji="🦉",
        description=(
            "You patrol the codebase after dark, hunting bugs with surgical precision "
            "and leaving detailed incident reports. Your fix commits read like post-mortems — "
            "thorough, analytical, and deeply informative."
        ),
        strengths=["Root-cause analysis expert", "Writes fixes others can learn from", "Calm under pressure"],
        blind_spots=["Feature work is often deprioritised", "Can overthink simple bugs"],
        verdict="You are the reason production doesn't crash at 3 AM.",
    ),
    "SNRT": PersonalityType(
        code="SNRT", name="The Shadow Debugger", emoji="🕵️",
        description=(
            "Midnight, minimal messages, maximum fixes. You materialise in the git log "
            "like a ghost, resolve the issue, and vanish before anyone asks questions. "
            "The bug was there; now it isn't."
        ),
        strengths=["Fast incident response", "Calm nocturnal focus", "No-nonsense problem solver"],
        blind_spots=["Zero audit trail for future engineers", "Fixes can be hard to understand"],
        verdict="Forensics teams would love your diffs. Your commit messages, not so much.",
    ),
    "BMPV": PersonalityType(
        code="BMPV", name="The Bold Visionary", emoji="🚀",
        description=(
            "Big sweeping changes, rich commit messages, new features built in daylight "
            "for all to see. You think in systems and ship in chapters. Your PRs "
            "require reading time and a coffee."
        ),
        strengths=["Big-picture thinking", "Moves entire systems forward", "Excellent context-setting"],
        blind_spots=["Large diffs are hard to review", "Risk of big-bang failures"],
        verdict="Your PRs have a table of contents.",
    ),
    "BMPT": PersonalityType(
        code="BMPT", name="The Move-Fast Shipper", emoji="⚡",
        description=(
            "Large commits, short messages, new features all day. You optimise for "
            "velocity above all else. 'Works on my machine' might as well be your "
            "commit message template."
        ),
        strengths=["Extremely high output", "Unblocks teams quickly", "Bias to action"],
        blind_spots=["Reviews are painful", "Tech debt accumulates fast", "Future-you suffers"],
        verdict="Your commit history says 'ship it' in 47 different languages.",
    ),
    "BMRV": PersonalityType(
        code="BMRV", name="The Refactoring Tornado", emoji="🌪️",
        description=(
            "Massive diffs, detailed explanations, and a relentless drive to fix "
            "everything that's wrong with the codebase — during work hours no less. "
            "You leave the code significantly better than you found it, if reviewers "
            "can survive the PR."
        ),
        strengths=["Dramatically improves code quality", "Thorough understanding of the system", "Documents rationale"],
        blind_spots=["PRs can be overwhelming", "Others may fear merging your branches"],
        verdict="The codebase before and after you are barely the same codebase.",
    ),
    "BMRT": PersonalityType(
        code="BMRT", name="The Emergency Responder", emoji="🚨",
        description=(
            "When production is on fire, you show up in daylight with a massive patch "
            "and a brief message. You fix first, explain later — sometimes much later. "
            "The incident graph shows a cliff; your commit is the cliff."
        ),
        strengths=["Decisive under pressure", "Can fix complex issues in one sweep", "Reliable in crises"],
        blind_spots=["Large patches can introduce new bugs", "Post-incident docs rarely written"],
        verdict="Your hotfix commit has 800 changed lines and the message says 'fix'.",
    ),
    "BNPV": PersonalityType(
        code="BNPV", name="The Moonlight Innovator", emoji="✨",
        description=(
            "After midnight, large ambitious changes, detailed write-ups. You build "
            "the features that redefine the product while the rest of the world sleeps. "
            "Your PRs are treatises. Your test coverage is philosophy."
        ),
        strengths=["Visionary feature work", "Deep nocturnal focus", "Self-documenting changes"],
        blind_spots=["PRs opened at 2 AM get reviewed at 11 AM with confusion", "Burnout risk is high"],
        verdict="You push the future, one late-night mega-commit at a time.",
    ),
    "BNPT": PersonalityType(
        code="BNPT", name="The Caffeine-Powered Steamroller", emoji="☕",
        description=(
            "Large commits, terse messages, new features, and the clock says 2 AM. "
            "You are powered by caffeine and spite for your future code-reviewer self. "
            "Velocity is your religion. Sleep is optional."
        ),
        strengths=["Insane output in short windows", "Ships things nobody thought possible", "Fearless"],
        blind_spots=["'add stuff' is not a commit message", "Morning-team inherits the chaos"],
        verdict="Your commit history is a cautionary tale and an inspiration simultaneously.",
    ),
    "BNRV": PersonalityType(
        code="BNRV", name="The Nocturnal Caretaker", emoji="🌿",
        description=(
            "Large, thorough fixes committed after midnight with detailed explanations — "
            "you are the guardian of quality who works in the shadows. The codebase "
            "is better for your presence, even if nobody sees you arrive."
        ),
        strengths=["Comprehensive fixes", "Thorough documentation of intent", "Night-shift reliability"],
        blind_spots=["Large fix PRs are risky", "Reviewers miss the context without async communication"],
        verdict="You fix things thoroughly at night, so others can sleep during the day.",
    ),
    "BNRT": PersonalityType(
        code="BNRT", name="The Midnight Firefighter", emoji="🔥",
        description=(
            "2 AM, 500 lines changed, commit message: 'fix'. You thrive on crisis, "
            "operate in darkness, and leave the fire extinguished with minimal paperwork. "
            "The on-call rotation loves you. The code reviewer does not."
        ),
        strengths=["Extraordinary crisis response", "High-pressure performance", "Gets things unblocked fast"],
        blind_spots=["Zero paper trail", "Large nocturnal patches carry risk", "Future engineers cry"],
        verdict="Legend has it your git blame says 'fix' on every critical line.",
    ),
}


_TYPES_JA: dict[str, PersonalityType] = {
    "SMPV": PersonalityType(
        code="SMPV", name="几帳面なドキュメント職人", emoji="📖",
        description=(
            "日が暮れる前に、整然とした細かいコミットと丁寧なメッセージを残す。"
            "あなたのプルリクエストはレビューの喜び——クリーンなdiff、明確なコンテキスト、謎の大規模変更もなし。"
            "未来のあなたが深く感謝するだろう。"
        ),
        strengths=["水晶のように明確なコミット履歴", "バグのbisectが容易", "優秀なコードレビュアー"],
        blind_spots=["些細な変更も過剰ドキュメント化しがち", "スプリントが速い局面では遅れることも"],
        verdict="あなたのgit logは、次のエンジニアへのラブレターだ。",
    ),
    "SMPT": PersonalityType(
        code="SMPT", name="寡黙な職人", emoji="🪚",
        description=(
            "小さいコミット、簡潔なメッセージ、昼間の作業時間——あなたはエンジニアリング界の職人だ。"
            "コードが語るに任せ、説明を求められることはほとんどない。"
        ),
        strengths=["高集中の作業セッション", "無駄のない的確なコミット", "マージが速い"],
        blind_spots=["コミットメッセージが新参者には暗号的", "重要なコンテキストを省きがち"],
        verdict="あなたのコミットはメスのようだ——精確で効率的。",
    ),
    "SMRV": PersonalityType(
        code="SMRV", name="規律正しき守護者", emoji="🛡️",
        description=(
            "業務時間中に、丁寧な説明を添えながら一つずつ慎重に修正してコードベースを健全に保つ。"
            "バグはあなたを恐れ、技術的負債はあなたの名を知っている。"
            "あなたは本番の安定性を支える縁の下の力持ちだ。"
        ),
        strengths=["卓越したバグ発見能力", "信頼できるオンコールエンジニア", "強固なドキュメント習慣"],
        blind_spots=["新機能への投資が不足しがち", "メンテナンスモードから抜け出せないことも"],
        verdict="コードベースはあなたが見張っていることを知って、安心して眠っている。",
    ),
    "SMRT": PersonalityType(
        code="SMRT", name="静かな修理屋", emoji="🔧",
        description=(
            "小さいパッチ、短いメッセージ、定時作業。あなたはさっさと直して次に進む——派手さも長い説明も不要。"
            "あなたがいるとバグトラッカーが不思議と空になっていく。"
        ),
        strengths=["高い修正速度", "コミットログのノイズが少ない", "危機時の頼もしさ"],
        blind_spots=["何を、なぜ直したか他の人が知らない", "時間とともにコンテキストが失われる"],
        verdict="あなたはバグを忍者のように解決する——静かに、完璧に。",
    ),
    "SNPV": PersonalityType(
        code="SNPV", name="緻密なアーキテクト", emoji="🏛️",
        description=(
            "深夜、精確なコミット、野心的な機能、そして徹底した記録——"
            "あなたは大聖堂を設計する建築家の配慮でシステムを構築する。"
            "すべての決定がドキュメント化され、すべてのエッジケースが考慮される。"
        ),
        strengths=["深いシステム思考", "非同期コミュニケーションの達人", "レビューしやすい高品質な仕事"],
        blind_spots=["過剰設計になりがち", "深夜作業が続くとバーンアウトのリスク"],
        verdict="あなたのアーキテクチャ図には専用のコミット履歴がある。",
    ),
    "SNPT": PersonalityType(
        code="SNPT", name="深夜のビルダー", emoji="🌙",
        description=(
            "オフィスが暗くなると、あなたは目覚める。小さく集中したコミット、最小限の儀式——"
            "世界が見ていない静かな時間に機能を出荷し、Slackはついに沈黙する。"
        ),
        strengths=["閑散時間帯の深い集中", "高い機能出力", "自律性が高い"],
        blind_spots=["昼間のレビュアーにはコンテキストが不足", "タイムゾーン孤立のリスク"],
        verdict="あなたの最高のコードは、全員が寝ている間に書かれた。",
    ),
    "SNRV": PersonalityType(
        code="SNRV", name="夜の番人", emoji="🦉",
        description=(
            "暗くなってからコードベースを巡回し、外科的精度でバグを狩り、詳細なインシデントレポートを残す。"
            "あなたの修正コミットはポストモーテムのように読める——徹底的で、分析的で、深く情報に富んでいる。"
        ),
        strengths=["根本原因分析の専門家", "他者が学べる修正を書く", "プレッシャー下でも冷静"],
        blind_spots=["新機能開発が後回しになりがち", "単純なバグを考えすぎることも"],
        verdict="あなたが存在する理由は、午前3時に本番がクラッシュしないためだ。",
    ),
    "SNRT": PersonalityType(
        code="SNRT", name="影のデバッガー", emoji="🕵️",
        description=(
            "深夜、最小限のメッセージ、最大限の修正。あなたはgit logに幽霊のように現れ、"
            "問題を解決し、誰かが質問する前に消える。バグはあった。今はない。"
        ),
        strengths=["迅速なインシデント対応", "穏やかな夜間集中力", "実直な問題解決者"],
        blind_spots=["未来のエンジニアへの監査証跡ゼロ", "修正内容が理解しにくいことも"],
        verdict="フォレンジックチームはあなたのdiffを愛するだろう。コミットメッセージは、それほどでも。",
    ),
    "BMPV": PersonalityType(
        code="BMPV", name="大胆なビジョナリー", emoji="🚀",
        description=(
            "大きな変更、豊富なコミットメッセージ、昼間に公開で構築される新機能。"
            "あなたはシステムで考え、章で出荷する。あなたのPRにはコーヒーと読む時間が必要だ。"
        ),
        strengths=["大局的思考", "システム全体を前進させる", "優れたコンテキスト設定"],
        blind_spots=["大きなdiffはレビューが困難", "大規模な変更が一気に失敗するリスク"],
        verdict="あなたのPRには目次がある。",
    ),
    "BMPT": PersonalityType(
        code="BMPT", name="爆速シッパー", emoji="⚡",
        description=(
            "大きなコミット、短いメッセージ、一日中新機能。あなたは速度を最優先に最適化する。"
            "「自分のマシンでは動く」があなたのコミットメッセージのテンプレートと言っても過言ではない。"
        ),
        strengths=["極めて高いアウトプット", "チームの障害を素早く取り除く", "行動への強いバイアス"],
        blind_spots=["レビューが苦痛", "技術的負債が急速に蓄積", "未来の自分が苦しむ"],
        verdict="あなたのコミット履歴は47の言語で「とにかくリリース」と語っている。",
    ),
    "BMRV": PersonalityType(
        code="BMRV", name="リファクタリング竜巻", emoji="🌪️",
        description=(
            "巨大なdiff、詳細な説明、業務時間中にコードベースの問題を徹底的に修正する。"
            "レビュアーがPRを生き延びられれば、あなたはコードを大幅に改善して去る。"
        ),
        strengths=["コード品質を劇的に改善", "システムの深い理解", "根拠を丁寧にドキュメント化"],
        blind_spots=["PRが圧倒的な量になりがち", "他者があなたのブランチをマージすることを恐れる"],
        verdict="あなたの前後のコードベースは、ほぼ別物だ。",
    ),
    "BMRT": PersonalityType(
        code="BMRT", name="緊急対応隊員", emoji="🚨",
        description=(
            "本番が炎上すると、昼間に巨大なパッチと短いメッセージで現れる。"
            "直してから説明する——時にはずっと後で。インシデントグラフに崖が現れる；あなたのコミットがその崖だ。"
        ),
        strengths=["プレッシャー下での決断力", "複雑な問題を一気に修正できる", "危機時の頼もしさ"],
        blind_spots=["大きなパッチが新たなバグを生む可能性", "インシデント後のドキュメントがほぼ書かれない"],
        verdict="あなたのhotfixコミットは800行変更で、メッセージは「fix」。",
    ),
    "BNPV": PersonalityType(
        code="BNPV", name="月光のイノベーター", emoji="✨",
        description=(
            "深夜、大きな野心的変更、詳細な記録。世界の残りが眠っている間に、製品を再定義する機能を構築する。"
            "あなたのPRは論文だ。テストカバレッジは哲学だ。"
        ),
        strengths=["先見的な機能開発", "深い夜間集中", "自己ドキュメント化された変更"],
        blind_spots=["午前2時に開いたPRは午前11時に混乱してレビューされる", "バーンアウトリスクが高い"],
        verdict="あなたは深夜の大規模コミットで未来を押し進める。",
    ),
    "BNPT": PersonalityType(
        code="BNPT", name="カフェイン駆動ローラー", emoji="☕",
        description=(
            "大きなコミット、ぶっきらぼうなメッセージ、新機能、時計は午前2時。"
            "あなたはカフェインと未来のレビュアーへの反骨精神で動いている。速度があなたの宗教。睡眠はオプション。"
        ),
        strengths=["短時間での狂気的なアウトプット", "誰も可能と思わなかったものを出荷", "無謀なまでの勇気"],
        blind_spots=["「add stuff」はコミットメッセージではない", "朝のチームがカオスを引き継ぐ"],
        verdict="あなたのコミット履歴は戒めであり、同時に伝説だ。",
    ),
    "BNRV": PersonalityType(
        code="BNRV", name="夜型の管理人", emoji="🌿",
        description=(
            "深夜に大きく徹底的な修正を詳細な説明とともにコミット——あなたは影で働く品質の守護者だ。"
            "誰があなたが来るのを見ていなくても、コードベースはあなたの存在で良くなる。"
        ),
        strengths=["包括的な修正", "意図の徹底したドキュメント化", "夜間シフトの信頼性"],
        blind_spots=["大きな修正PRはリスクが高い", "非同期コミュニケーションなしにはレビュアーがコンテキストを見失う"],
        verdict="あなたは夜中に徹底的に直す。だから他の人が昼間に眠れる。",
    ),
    "BNRT": PersonalityType(
        code="BNRT", name="深夜の消防士", emoji="🔥",
        description=(
            "午前2時、500行変更、コミットメッセージ:「fix」。あなたは危機で輝き、闇の中で動き、"
            "最小限の書類で火を消して去る。オンコールローテーションはあなたを愛している。コードレビュアーはそうでもない。"
        ),
        strengths=["異常な危機対応力", "高プレッシャー下でのパフォーマンス", "素早いブロック解除"],
        blind_spots=["証跡ゼロ", "大きな深夜パッチはリスクを抱える", "未来のエンジニアが泣く"],
        verdict="git blameは、すべての重要な行に「fix」と表示すると言われている。",
    ),
}


def get_personality_type(code: str, lang: str = "en") -> PersonalityType:
    """Return the PersonalityType for *code* in the requested language."""
    types = _TYPES_JA if lang == "ja" else _TYPES
    return types.get(code, types.get("SNPT", next(iter(types.values()))))


@dataclass
class ClassificationResult:
    type: PersonalityType
    axis_scores: dict[str, AxisScore]
    type_code: str


def classify(metrics: dict[str, AnalysisMetrics]) -> ClassificationResult:
    """Map analyzer results to a CEPI personality type.

    Expected keys in metrics: 'timing', 'size', 'ratio', 'message_style'.
    The frequency and language analyzers contribute only to raw stats.
    """
    scores: dict[str, AxisScore] = {
        name: m.axis_score for name, m in metrics.items()
    }

    s_b = scores.get("size", AxisScore("S/B", "Surgeon", "Bulldozer", 0.5))
    m_n = scores.get("timing", AxisScore("M/N", "Morning Lark", "Night Owl", 0.5))
    p_r = scores.get("ratio", AxisScore("P/R", "Pioneer", "Repairman", 0.5))
    v_t = scores.get("message_style", AxisScore("V/T", "Verbose", "Terse", 0.5))

    code = s_b.label + m_n.label + p_r.label + v_t.label
    personality = _TYPES.get(code, _TYPES["SNPT"])  # fallback to a valid type

    return ClassificationResult(
        type=personality,
        axis_scores={
            "S/B": s_b,
            "M/N": m_n,
            "P/R": p_r,
            "V/T": v_t,
        },
        type_code=code,
    )
