"""GitHub API data collector with pagination, rate limiting, and caching."""

import time
from datetime import datetime, timedelta, timezone
from typing import Any

import httpx
from rich.progress import BarColumn, Progress, SpinnerColumn, TaskProgressColumn, TextColumn

from git_persona.cache import cache_get, cache_set
from git_persona.models import CollectionResult, CommitData, RepoInfo, UserProfile

GITHUB_API = "https://api.github.com"
# Max commit-detail requests per collection run (to stay within rate limit)
COMMIT_DETAIL_SAMPLE_SIZE = 200
RATE_LIMIT_PAUSE_THRESHOLD = 100


class CollectorError(Exception):
    """Raised when data collection fails unrecoverably."""


class GitHubCollector:
    def __init__(self, token: str, use_cache: bool = True):
        self._headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        self._use_cache = use_cache
        self._client: httpx.Client | None = None

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def collect_all(
        self,
        username: str,
        days: int = 90,
        deep: bool = False,
        is_self: bool = False,
    ) -> CollectionResult:
        """Orchestrate full data collection with a progress display."""
        since: datetime | None = None
        if not deep:
            since = datetime.now(tz=timezone.utc) - timedelta(days=days)

        with httpx.Client(headers=self._headers, timeout=30) as client:
            self._client = client

            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TaskProgressColumn(),
                transient=True,
            ) as progress:
                # 1. User profile
                t_user = progress.add_task("Fetching user profile…", total=1)
                user = self._get_user_profile(username)
                progress.update(t_user, completed=1)

                # 2. Repos
                t_repos = progress.add_task("Fetching repositories…", total=None)
                repos = self._get_user_repos(username, is_self=is_self)
                progress.update(t_repos, total=len(repos), completed=len(repos))

                # 3. Commits per repo
                all_commits: list[CommitData] = []
                t_commits = progress.add_task("Fetching commits…", total=len(repos))
                for repo in repos:
                    commits = self._get_repo_commits(username, repo.full_name, since)
                    for c in commits:
                        c.repo_language = repo.primary_language
                    repo.commit_count = len(commits)
                    all_commits.extend(commits)
                    progress.advance(t_commits)

                # 4. Commit stats (sampled)
                if all_commits:
                    sample = _sample(all_commits, COMMIT_DETAIL_SAMPLE_SIZE)
                    t_stats = progress.add_task(
                        f"Fetching commit stats (sample of {len(sample)})…",
                        total=len(sample),
                    )
                    for commit in sample:
                        self._enrich_commit_stats(commit)
                        progress.advance(t_stats)

            self._client = None

        return CollectionResult(
            user=user,
            commits=all_commits,
            repos=repos,
            analysis_days=days,
            is_deep_scan=deep,
        )

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _get(self, url: str, params: dict | None = None) -> Any:
        """GET with rate-limit awareness and retry on 429/403."""
        assert self._client is not None
        for attempt in range(3):
            resp = self._client.get(url, params=params)
            remaining = int(resp.headers.get("x-ratelimit-remaining", "999"))
            if remaining < RATE_LIMIT_PAUSE_THRESHOLD:
                reset_at = int(resp.headers.get("x-ratelimit-reset", "0"))
                wait = max(0, reset_at - int(time.time())) + 1
                time.sleep(min(wait, 60))

            if resp.status_code == 429 or resp.status_code == 403:
                time.sleep(2 ** attempt)
                continue
            if resp.status_code in (404, 409):
                return None
            resp.raise_for_status()
            return resp.json()
        raise CollectorError(f"Failed after retries: GET {url}")

    def _get_paginated(self, url: str, params: dict | None = None) -> list[Any]:
        """Fetch all pages of a paginated GitHub endpoint."""
        results: list[Any] = []
        page = 1
        per_page = 100
        base_params = {**(params or {}), "per_page": per_page}

        while True:
            cache_key = f"{url}?page={page}&{'&'.join(f'{k}={v}' for k, v in sorted(base_params.items()))}"
            cached = cache_get(cache_key) if self._use_cache else None
            if cached is not None:
                data = cached
            else:
                assert self._client is not None
                full_params = {**base_params, "page": page}
                for attempt in range(3):
                    resp = self._client.get(url, params=full_params)
                    remaining = int(resp.headers.get("x-ratelimit-remaining", "999"))
                    if remaining < RATE_LIMIT_PAUSE_THRESHOLD:
                        reset_at = int(resp.headers.get("x-ratelimit-reset", "0"))
                        wait = max(0, reset_at - int(time.time())) + 1
                        time.sleep(min(wait, 60))
                    if resp.status_code in (429, 403):
                        time.sleep(2 ** attempt)
                        continue
                    if resp.status_code in (404, 409):
                        # 404 = not found; 409 = empty repository (no commits yet)
                        return results
                    resp.raise_for_status()
                    data = resp.json()
                    break
                else:
                    raise CollectorError(f"Failed after retries: GET {url} page={page}")
                if self._use_cache:
                    cache_set(cache_key, data)

            if not data:
                break
            results.extend(data)
            if len(data) < per_page:
                break
            page += 1

        return results

    def _get_user_profile(self, username: str) -> UserProfile:
        cache_key = f"user_profile:{username}"
        cached = cache_get(cache_key) if self._use_cache else None
        if cached:
            return _user_from_dict(cached)

        data = self._get(f"{GITHUB_API}/users/{username}")
        if data is None:
            raise CollectorError(f"User '{username}' not found on GitHub.")

        if self._use_cache:
            cache_set(cache_key, data)
        return _user_from_dict(data)

    def _get_user_repos(self, username: str, is_self: bool = False) -> list[RepoInfo]:
        if is_self:
            # owner,organization_member captures both private repos and org repos
            url = f"{GITHUB_API}/user/repos"
            params = {"affiliation": "owner,organization_member", "sort": "updated"}
        else:
            url = f"{GITHUB_API}/users/{username}/repos"
            params = {"type": "owner", "sort": "updated"}
        raw = self._get_paginated(url, params=params)
        return [_repo_from_dict(r) for r in raw if not r.get("fork", False)]

    def _get_repo_commits(
        self,
        username: str,
        full_repo_name: str,
        since: datetime | None,
    ) -> list[CommitData]:
        params: dict[str, Any] = {}
        if since:
            params["since"] = since.isoformat()

        raw = self._get_paginated(
            f"{GITHUB_API}/repos/{full_repo_name}/commits",
            params=params,
        )
        # Filter client-side: keep commits whose linked GitHub account matches the username.
        # Server-side ?author= filter misses commits where git email ≠ GitHub account email.
        # If GitHub can't link the commit to any account (author=null), include it only for
        # repos the user owns (full_repo_name starts with username/).
        is_own_repo = full_repo_name.lower().startswith(username.lower() + "/")
        result = []
        for d in raw:
            author_node = d.get("author")  # GitHub user linked to this commit (may be null)
            if author_node is not None:
                if author_node.get("login", "").lower() == username.lower():
                    result.append(_commit_from_dict(d, full_repo_name))
            elif is_own_repo:
                # Can't determine author — include since it's the user's own repo
                result.append(_commit_from_dict(d, full_repo_name))
        return result

    def _enrich_commit_stats(self, commit: CommitData) -> None:
        """Fetch additions/deletions for a single commit (modifies in-place)."""
        cache_key = f"commit_stats:{commit.repo_name}:{commit.sha}"
        cached = cache_get(cache_key) if self._use_cache else None
        if cached:
            commit.additions = cached.get("additions", 0)
            commit.deletions = cached.get("deletions", 0)
            return

        data = self._get(f"{GITHUB_API}/repos/{commit.repo_name}/commits/{commit.sha}")
        if data and "stats" in data:
            stats = data["stats"]
            commit.additions = stats.get("additions", 0)
            commit.deletions = stats.get("deletions", 0)
            if self._use_cache:
                cache_set(cache_key, {"additions": commit.additions, "deletions": commit.deletions})


# ------------------------------------------------------------------
# Parsing helpers
# ------------------------------------------------------------------

def _user_from_dict(d: dict) -> UserProfile:
    created_at = datetime.fromisoformat(d["created_at"].replace("Z", "+00:00"))
    age_days = (datetime.now(tz=timezone.utc) - created_at).days
    return UserProfile(
        username=d["login"],
        total_repos=d.get("public_repos", 0),
        account_age_days=age_days,
        followers=d.get("followers", 0),
        name=d.get("name"),
    )


def _repo_from_dict(d: dict) -> RepoInfo:
    return RepoInfo(
        name=d["name"],
        full_name=d["full_name"],
        primary_language=d.get("language"),
        is_fork=d.get("fork", False),
        stars=d.get("stargazers_count", 0),
    )


def _commit_from_dict(d: dict, repo_full_name: str) -> CommitData:
    raw_ts = d["commit"]["author"]["date"]
    ts = datetime.fromisoformat(raw_ts.replace("Z", "+00:00"))
    return CommitData(
        sha=d["sha"],
        message=d["commit"]["message"],
        timestamp=ts,
        repo_name=repo_full_name,
    )


def _sample(items: list, n: int) -> list:
    """Return up to n evenly-spaced items from the list."""
    if len(items) <= n:
        return items
    step = len(items) / n
    return [items[int(i * step)] for i in range(n)]
