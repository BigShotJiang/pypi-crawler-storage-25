"""CLI entry point for git-persona."""

import click
import httpx
from rich.console import Console

from git_persona.auth import AuthError, get_github_token
from git_persona.analyzers.timing import TimingAnalyzer
from git_persona.analyzers.message_style import MessageStyleAnalyzer
from git_persona.analyzers.size import SizeAnalyzer
from git_persona.analyzers.ratio import RatioAnalyzer
from git_persona.analyzers.frequency import FrequencyAnalyzer
from git_persona.analyzers.language import LanguageAnalyzer
from git_persona.collector import GitHubCollector
from git_persona.personality import classify
from git_persona.report import build_json_report, render_report

console = Console()

GITHUB_API = "https://api.github.com"


@click.group()
@click.version_option()
def main():
    """git-persona: Analyze your GitHub commits and discover your engineer personality."""


@main.command()
@click.option("--token", envvar="GITHUB_TOKEN", help="GitHub personal access token.")
@click.option("--username", default=None, help="GitHub username to analyze (default: authenticated user).")
@click.option("--days", default=90, show_default=True, help="Number of days of history to analyze.")
@click.option("--deep", is_flag=True, default=False, help="Analyze full commit history (ignores --days).")
@click.option("--no-cache", is_flag=True, default=False, help="Bypass local cache and fetch fresh data.")
@click.option(
    "--output",
    type=click.Choice(["terminal", "json"], case_sensitive=False),
    default="terminal",
    show_default=True,
    help="Output format.",
)
@click.option("--timezone", default=None, help="Timezone for time analysis (e.g. 'Asia/Tokyo'). Defaults to UTC.")
@click.option("--no-color", is_flag=True, default=False, help="Disable colored output.")
@click.option(
    "--lang",
    type=click.Choice(["en", "ja"], case_sensitive=False),
    default="en",
    show_default=True,
    help="Output language (en / ja).",
)
def analyze(token, username, days, deep, no_cache, output, timezone, no_color, lang):
    """Fetch your GitHub commit history and generate your engineer personality diagnosis."""
    global console
    if no_color:
        console = Console(no_color=True)

    # Resolve token
    try:
        resolved_token = get_github_token(token)
    except AuthError as e:
        console.print(f"[bold red]Authentication Error:[/bold red] {e}")
        raise SystemExit(1)

    # Verify token and get authenticated user
    headers = {
        "Authorization": f"Bearer {resolved_token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    try:
        with httpx.Client(headers=headers, timeout=30) as client:
            resp = client.get(f"{GITHUB_API}/user")
            resp.raise_for_status()
            user_data = resp.json()
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            console.print("[bold red]Error:[/bold red] Invalid or expired GitHub token.")
        else:
            console.print(f"[bold red]GitHub API Error:[/bold red] {e}")
        raise SystemExit(1)
    except httpx.RequestError as e:
        console.print(f"[bold red]Network Error:[/bold red] {e}")
        raise SystemExit(1)

    resolved_username = username or user_data["login"]

    if output == "terminal":
        console.print(
            f"[bold green]✓[/bold green] Authenticated as [bold]{user_data['login']}[/bold]"
        )
        console.print(
            f"[dim]Analyzing:[/dim] [bold]{resolved_username}[/bold] | "
            f"Period: [bold]{'all history' if deep else f'last {days} days'}[/bold]"
        )
        console.print()

    # Collect commits
    collector = GitHubCollector(token=resolved_token, use_cache=not no_cache)
    try:
        collection = collector.collect_all(
            username=resolved_username,
            days=days,
            deep=deep,
            is_self=(username is None),  # use /user/repos for own account (includes private)
        )
    except Exception as e:
        console.print(f"[bold red]Collection Error:[/bold red] {e}")
        raise SystemExit(1)

    if not collection.commits:
        console.print("[yellow]No commits found in the specified time range.[/yellow]")
        raise SystemExit(0)

    # Run all analyzers
    commits = collection.commits
    metrics = {
        "timing": TimingAnalyzer(timezone=timezone).analyze(commits),
        "message_style": MessageStyleAnalyzer().analyze(commits),
        "size": SizeAnalyzer().analyze(commits),
        "ratio": RatioAnalyzer().analyze(commits),
        "frequency": FrequencyAnalyzer().analyze(commits),
        "language": LanguageAnalyzer().analyze(commits),
    }

    # Classify personality
    result = classify(metrics)

    # Output
    if output == "json":
        click.echo(build_json_report(result, collection, metrics, lang=lang))
    else:
        render_report(result, collection, metrics, console, lang=lang)
