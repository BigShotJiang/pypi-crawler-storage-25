"""Rich terminal report renderer for git-persona."""

import json
from typing import Any

from rich.columns import Columns
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from git_persona.analyzers.base import AnalysisMetrics
from git_persona.models import CollectionResult
from git_persona.personality import ClassificationResult, get_personality_type

_UI = {
    "en": {
        "axes_title": "Personality Axes",
        "strengths_title": "Strengths & Blind Spots",
        "strengths_label": "Strengths",
        "blind_spots_label": "Blind Spots",
        "activity_title": "Commit Activity",
        "languages_title": "Top Languages",
        "verdict_label": "Verdict: ",
        "stat_total": "Total commits  ",
        "stat_active": "Active days  ",
        "stat_peak": "Peak hour  ",
        "stat_streak": "Longest streak  ",
        "stat_gap": "Longest gap  ",
        "stat_cpd": "Commits/day  ",
        "stat_days": " days",
        "footer_analyzed": "  Analyzed ",
        "footer_apostrophe": "'s ",
        "footer_commits": " commits across ",
        "footer_repos": " repositories",
        "axis_poles": {
            "Surgeon": "Surgeon", "Bulldozer": "Bulldozer",
            "Morning Lark": "Morning Lark", "Night Owl": "Night Owl",
            "Pioneer": "Pioneer", "Repairman": "Repairman",
            "Verbose": "Verbose", "Terse": "Terse",
            "Sporadic": "Sporadic", "Consistent": "Consistent",
            "Specialist": "Specialist", "Polyglot": "Polyglot",
        },
    },
    "ja": {
        "axes_title": "パーソナリティ軸",
        "strengths_title": "強み & 盲点",
        "strengths_label": "強み",
        "blind_spots_label": "盲点",
        "activity_title": "コミット活動",
        "languages_title": "使用言語",
        "verdict_label": "診断: ",
        "stat_total": "総コミット  ",
        "stat_active": "アクティブ日数  ",
        "stat_peak": "ピーク時間  ",
        "stat_streak": "最長連続  ",
        "stat_gap": "最長間隔  ",
        "stat_cpd": "コミット/日  ",
        "stat_days": "日",
        "footer_analyzed": "  ",
        "footer_apostrophe": "の",
        "footer_commits": "コミットを",
        "footer_repos": "リポジトリで分析",
        "axis_poles": {
            "Surgeon": "外科医", "Bulldozer": "ブルドーザー",
            "Morning Lark": "朝型", "Night Owl": "夜型",
            "Pioneer": "開拓者", "Repairman": "修理屋",
            "Verbose": "饒舌", "Terse": "簡潔",
            "Sporadic": "不規則", "Consistent": "規則的",
            "Specialist": "スペシャリスト", "Polyglot": "多言語使い",
        },
    },
}

# Bar rendering
_BAR_WIDTH = 20
_BAR_FULL = "█"
_BAR_EMPTY = "░"


def _bar(value: float, width: int = _BAR_WIDTH) -> str:
    """Render a simple ASCII progress bar (value in [0, 1])."""
    filled = round(value * width)
    return _BAR_FULL * filled + _BAR_EMPTY * (width - filled)


def render_report(
    result: ClassificationResult,
    collection: CollectionResult,
    metrics: dict[str, AnalysisMetrics],
    console: Console,
    lang: str = "en",
) -> None:
    """Print the full personality report to *console*."""
    ui = _UI.get(lang, _UI["en"])
    pt = get_personality_type(result.type_code, lang)
    poles = ui["axis_poles"]

    # ── Header card ────────────────────────────────────────────────────────
    header_lines = [
        Text.assemble(
            (f"{pt.emoji}  ", ""),
            (pt.name, "bold white"),
            ("  ", ""),
            (f"[{result.type_code}]", "dim"),
        ),
        Text(""),
        Text(pt.description, style="italic"),
        Text(""),
        Text.assemble((ui["verdict_label"], "bold yellow"), (pt.verdict, "yellow")),
    ]
    header_content = Text("\n").join(header_lines)
    console.print(Panel(header_content, border_style="bold cyan", padding=(1, 2)))
    console.print()

    # ── Axis breakdown ──────────────────────────────────────────────────────
    console.print(Rule(f"[bold]{ui['axes_title']}[/bold]", style="cyan"))
    console.print()

    axis_table = Table.grid(padding=(0, 1))
    axis_table.add_column(justify="right", min_width=10)   # axis label
    axis_table.add_column(justify="right", min_width=12)   # left pole
    axis_table.add_column(min_width=_BAR_WIDTH)            # bar
    axis_table.add_column(justify="left", min_width=12)    # right pole
    axis_table.add_column(justify="right", min_width=5)    # pct

    for axis_key, score in result.axis_scores.items():
        pct = round(score.value * 100)
        if score.value < 0.5:
            left_style = "bold green"
            right_style = "dim"
        elif score.value > 0.5:
            left_style = "dim"
            right_style = "bold green"
        else:
            left_style = right_style = "bold green"

        axis_table.add_row(
            Text(axis_key, style="bold cyan"),
            Text(poles.get(score.left_pole, score.left_pole), style=left_style),
            Text(_bar(score.value), style="green"),
            Text(poles.get(score.right_pole, score.right_pole), style=right_style),
            Text(f"{pct}%", style="dim"),
        )

    console.print(axis_table)
    console.print()

    # ── Strengths & Blind Spots ─────────────────────────────────────────────
    console.print(Rule(f"[bold]{ui['strengths_title']}[/bold]", style="cyan"))
    console.print()

    str_table = Table.grid(padding=(0, 2))
    str_table.add_column(min_width=35)
    str_table.add_column(min_width=35)

    strengths_text = Text()
    strengths_text.append(f"{ui['strengths_label']}\n", style="bold green")
    for s in pt.strengths:
        strengths_text.append(f"  ✓ {s}\n", style="green")

    blind_spots_text = Text()
    blind_spots_text.append(f"{ui['blind_spots_label']}\n", style="bold red")
    for b in pt.blind_spots:
        blind_spots_text.append(f"  ✗ {b}\n", style="red")

    str_table.add_row(strengths_text, blind_spots_text)
    console.print(str_table)
    console.print()

    # ── Commit stats ────────────────────────────────────────────────────────
    freq = metrics.get("frequency")
    if freq and freq.raw:
        console.print(Rule(f"[bold]{ui['activity_title']}[/bold]", style="cyan"))
        console.print()
        r = freq.raw
        stats_table = Table.grid(padding=(0, 3))
        stats_table.add_column()
        stats_table.add_column()
        stats_table.add_column()

        timing = metrics.get("timing")
        peak_hour = timing.raw.get("peak_hour", "?") if timing else "?"

        stats_table.add_row(
            Text.assemble((ui["stat_total"], "dim"), (str(r.get("total_commits", "?")), "bold")),
            Text.assemble((ui["stat_active"], "dim"), (str(r.get("active_days", "?")), "bold")),
            Text.assemble((ui["stat_peak"], "dim"), (f"{peak_hour:02d}:00" if isinstance(peak_hour, int) else str(peak_hour), "bold")),
        )
        stats_table.add_row(
            Text.assemble((ui["stat_streak"], "dim"), (f"{r.get('longest_streak_days', '?')}{ui['stat_days']}", "bold")),
            Text.assemble((ui["stat_gap"], "dim"), (f"{r.get('longest_gap_days', '?')}{ui['stat_days']}", "bold")),
            Text.assemble((ui["stat_cpd"], "dim"), (str(r.get("commits_per_active_day", "?")), "bold")),
        )
        console.print(stats_table)
        console.print()

    # ── Language breakdown ──────────────────────────────────────────────────
    lang_metrics = metrics.get("language")
    if lang_metrics and lang_metrics.raw.get("top_languages"):
        console.print(Rule(f"[bold]{ui['languages_title']}[/bold]", style="cyan"))
        console.print()
        lang_table = Table.grid(padding=(0, 1))
        lang_table.add_column(min_width=16, justify="right")
        lang_table.add_column(min_width=_BAR_WIDTH)
        lang_table.add_column(min_width=5, justify="right")

        for entry in lang_metrics.raw["top_languages"]:
            name = entry["language"]
            ratio = entry["ratio"]
            lang_table.add_row(
                Text(name, style="bold"),
                Text(_bar(ratio), style="blue"),
                Text(f"{round(ratio * 100)}%", style="dim"),
            )
        console.print(lang_table)
        console.print()

    # ── Footer ──────────────────────────────────────────────────────────────
    user = collection.user
    display_name = user.name or user.username
    console.print(
        Text.assemble(
            (ui["footer_analyzed"], "dim"),
            (display_name, "bold"),
            (ui["footer_apostrophe"], "dim"),
            (str(collection.total_commits), "bold"),
            (ui["footer_commits"], "dim"),
            (str(len(collection.repos)), "bold"),
            (ui["footer_repos"], "dim"),
        )
    )
    console.print()


def build_json_report(
    result: ClassificationResult,
    collection: CollectionResult,
    metrics: dict[str, AnalysisMetrics],
    lang: str = "en",
) -> str:
    """Serialize analysis results to a JSON string."""
    pt = get_personality_type(result.type_code, lang)
    payload: dict[str, Any] = {
        "username": collection.user.username,
        "personality": {
            "code": result.type_code,
            "name": pt.name,
            "emoji": pt.emoji,
            "description": pt.description,
            "strengths": pt.strengths,
            "blind_spots": pt.blind_spots,
            "verdict": pt.verdict,
        },
        "axes": {
            axis: {
                "value": round(score.value, 4),
                "label": score.label,
                "left_pole": score.left_pole,
                "right_pole": score.right_pole,
            }
            for axis, score in result.axis_scores.items()
        },
        "stats": {
            name: m.raw
            for name, m in metrics.items()
        },
        "collection": {
            "total_commits": collection.total_commits,
            "total_repos": len(collection.repos),
            "analysis_days": collection.analysis_days,
            "is_deep_scan": collection.is_deep_scan,
        },
    }
    return json.dumps(payload, indent=2, default=str)
