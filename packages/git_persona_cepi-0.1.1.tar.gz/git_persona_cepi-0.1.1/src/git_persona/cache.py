"""Local file-based JSON cache for GitHub API responses."""

import hashlib
import json
import time
from pathlib import Path
from typing import Any

from platformdirs import user_cache_dir

CACHE_TTL_SECONDS = 3600  # 1 hour


def _cache_dir() -> Path:
    path = Path(user_cache_dir("git-persona"))
    path.mkdir(parents=True, exist_ok=True)
    return path


def _cache_path(key: str) -> Path:
    hashed = hashlib.sha256(key.encode()).hexdigest()[:16]
    return _cache_dir() / f"{hashed}.json"


def cache_get(key: str) -> Any | None:
    """Return cached value for key, or None if missing or expired."""
    path = _cache_path(key)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if time.time() - data["ts"] > CACHE_TTL_SECONDS:
            path.unlink(missing_ok=True)
            return None
        return data["value"]
    except (json.JSONDecodeError, KeyError, OSError):
        return None


def cache_set(key: str, value: Any) -> None:
    """Write value to cache with current timestamp."""
    path = _cache_path(key)
    try:
        path.write_text(
            json.dumps({"ts": time.time(), "value": value}),
            encoding="utf-8",
        )
    except OSError:
        pass  # Cache write failure is non-fatal


def cache_clear() -> int:
    """Delete all cache files. Returns number of files removed."""
    removed = 0
    for f in _cache_dir().glob("*.json"):
        try:
            f.unlink()
            removed += 1
        except OSError:
            pass
    return removed
