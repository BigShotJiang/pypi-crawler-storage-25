"""Tests for RatioAnalyzer."""

from datetime import datetime, timezone

from git_persona.analyzers.ratio import RatioAnalyzer
from git_persona.models import CommitData

_TS = datetime(2024, 1, 1, tzinfo=timezone.utc)


def _commit(message: str) -> CommitData:
    return CommitData(sha="x", message=message, timestamp=_TS, repo_name="r/r")


class TestRatioAnalyzerEmpty:
    def test_empty_returns_neutral(self):
        result = RatioAnalyzer().analyze([])
        assert result.axis_score.value == 0.5


class TestPioneerScore:
    def test_all_feature_commits_score_near_zero(self):
        commits = [
            _commit("feat: add login"),
            _commit("add new endpoint"),
            _commit("implement oauth"),
            _commit("create user model"),
        ]
        result = RatioAnalyzer().analyze(commits)
        assert result.axis_score.value < 0.1
        assert result.axis_score.label == "P"

    def test_feature_ratio_is_high(self):
        commits = [_commit("feat: add feature") for _ in range(10)]
        result = RatioAnalyzer().analyze(commits)
        assert result.raw["feature_ratio"] == 1.0


class TestRepairmanScore:
    def test_all_fix_commits_score_near_one(self):
        commits = [
            _commit("fix: resolve null pointer"),
            _commit("bug: fix login crash"),
            _commit("hotfix: patch security issue"),
        ]
        result = RatioAnalyzer().analyze(commits)
        assert result.axis_score.value > 0.9
        assert result.axis_score.label == "R"

    def test_fix_ratio_is_high(self):
        commits = [_commit("fix: resolve issue") for _ in range(5)]
        result = RatioAnalyzer().analyze(commits)
        assert result.raw["fix_ratio"] == 1.0


class TestCategoryClassification:
    def test_refactor_classified(self):
        commits = [_commit("refactor: extract helper"), _commit("clean up unused code")]
        result = RatioAnalyzer().analyze(commits)
        assert result.raw["refactor_ratio"] > 0

    def test_docs_classified(self):
        commits = [_commit("docs: update readme"), _commit("update changelog")]
        result = RatioAnalyzer().analyze(commits)
        assert result.raw["docs_ratio"] > 0

    def test_test_commits_classified(self):
        # Use "coverage" keyword which is unambiguously in the test pattern
        commits = [_commit("test: coverage for auth module")]
        result = RatioAnalyzer().analyze(commits)
        assert result.raw["test_ratio"] > 0

    def test_chore_classified(self):
        commits = [_commit("chore: bump version"), _commit("ci: update pipeline")]
        result = RatioAnalyzer().analyze(commits)
        assert result.raw["chore_ratio"] > 0

    def test_unclassifiable_is_other(self):
        commits = [_commit("wip"), _commit("xyz")]
        result = RatioAnalyzer().analyze(commits)
        assert result.raw["other_ratio"] > 0

    def test_category_counts_present(self):
        commits = [_commit("fix: bug")]
        result = RatioAnalyzer().analyze(commits)
        assert "category_counts" in result.raw


class TestMixedRatio:
    def test_half_feature_half_fix(self):
        commits = (
            [_commit("feat: add feature")] * 5
            + [_commit("fix: resolve bug")] * 5
        )
        result = RatioAnalyzer().analyze(commits)
        assert 0.45 <= result.axis_score.value <= 0.55
