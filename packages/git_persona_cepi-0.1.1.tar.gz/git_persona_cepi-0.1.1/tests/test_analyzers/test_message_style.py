"""Tests for MessageStyleAnalyzer."""

from datetime import datetime, timezone

import pytest

from git_persona.analyzers.message_style import MessageStyleAnalyzer
from git_persona.models import CommitData

_TS = datetime(2024, 1, 1, tzinfo=timezone.utc)


def _commit(message: str) -> CommitData:
    return CommitData(sha="x", message=message, timestamp=_TS, repo_name="r/r")


class TestMessageStyleEmpty:
    def test_empty_returns_neutral(self):
        result = MessageStyleAnalyzer().analyze([])
        assert result.axis_score.value == 0.5


class TestVerboseScore:
    def test_long_messages_score_near_zero(self):
        commits = [_commit("This is a very detailed and thorough description of the change made") for _ in range(5)]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.axis_score.value < 0.4
        assert result.axis_score.label == "V"

    def test_short_messages_score_near_one(self):
        commits = [_commit("fix") for _ in range(5)]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.axis_score.value > 0.9
        assert result.axis_score.label == "T"


class TestConventionalCommits:
    def test_conventional_commits_detected(self):
        commits = [
            _commit("feat: add login page"),
            _commit("fix: resolve null pointer"),
            _commit("docs: update readme"),
        ]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["conventional_commit_ratio"] == 1.0

    def test_non_conventional_commits_zero_ratio(self):
        commits = [_commit("updated some stuff"), _commit("changes")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["conventional_commit_ratio"] == 0.0

    def test_scoped_conventional_commit_detected(self):
        commits = [_commit("feat(auth): add oauth support")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["conventional_commit_ratio"] == 1.0


class TestEmojiDetection:
    def test_emoji_detected(self):
        commits = [_commit("🐛 fix bug"), _commit("✨ add feature")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["emoji_ratio"] == 1.0

    def test_no_emoji(self):
        commits = [_commit("fix bug"), _commit("add feature")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["emoji_ratio"] == 0.0


class TestFrustrationDetection:
    def test_wip_detected(self):
        commits = [_commit("WIP: not done yet")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["frustration_ratio"] == 1.0

    def test_fixme_detected(self):
        commits = [_commit("FIXME: this is broken")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["frustration_ratio"] == 1.0

    def test_clean_messages_zero_frustration(self):
        commits = [_commit("feat: add new endpoint"), _commit("refactor: extract helper")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["frustration_ratio"] == 0.0


class TestRawMetrics:
    def test_median_length_is_computed(self):
        commits = [_commit("short"), _commit("a much longer commit message here")]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["median_subject_length"] > 0

    def test_total_commits_matches(self):
        commits = [_commit(f"commit {i}") for i in range(7)]
        result = MessageStyleAnalyzer().analyze(commits)
        assert result.raw["total_commits"] == 7
