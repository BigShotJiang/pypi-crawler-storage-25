"""Tests for SizeAnalyzer."""

from datetime import datetime, timezone

from git_persona.analyzers.size import ATOMIC_THRESHOLD, MEGA_THRESHOLD, SizeAnalyzer
from git_persona.models import CommitData

_TS = datetime(2024, 1, 1, tzinfo=timezone.utc)


def _commit(additions: int = 0, deletions: int = 0) -> CommitData:
    return CommitData(
        sha="x", message="msg", timestamp=_TS, repo_name="r/r",
        additions=additions, deletions=deletions,
    )


class TestSizeAnalyzerEmpty:
    def test_empty_returns_neutral(self):
        result = SizeAnalyzer().analyze([])
        assert result.axis_score.value == 0.5

    def test_all_zero_stats_returns_neutral(self):
        commits = [_commit(0, 0) for _ in range(5)]
        result = SizeAnalyzer().analyze(commits)
        assert result.axis_score.value == 0.5
        assert "no commit size data" in result.raw.get("note", "")


class TestSurgeonScore:
    def test_small_commits_score_near_zero(self):
        commits = [_commit(10, 5) for _ in range(10)]  # 15 lines each
        result = SizeAnalyzer().analyze(commits)
        assert result.axis_score.value < 0.1
        assert result.axis_score.label == "S"

    def test_atomic_ratio_high_for_small_commits(self):
        commits = [_commit(20, 10) for _ in range(10)]  # 30 lines, under threshold
        result = SizeAnalyzer().analyze(commits)
        assert result.raw["atomic_ratio"] == 1.0


class TestBulldozerScore:
    def test_large_commits_score_near_one(self):
        commits = [_commit(300, 200) for _ in range(10)]  # 500 lines each
        result = SizeAnalyzer().analyze(commits)
        assert result.axis_score.value >= 1.0 or result.axis_score.value > 0.9
        assert result.axis_score.label == "B"

    def test_mega_ratio_high_for_large_commits(self):
        commits = [_commit(400, 200) for _ in range(5)]  # 600 lines, above threshold
        result = SizeAnalyzer().analyze(commits)
        assert result.raw["mega_ratio"] == 1.0


class TestSizeRawMetrics:
    def test_median_lines_computed(self):
        commits = [_commit(10, 5), _commit(100, 50), _commit(50, 25)]
        result = SizeAnalyzer().analyze(commits)
        assert result.raw["median_lines_changed"] > 0

    def test_p90_is_at_least_median(self):
        commits = [_commit(i * 10, 0) for i in range(1, 11)]
        result = SizeAnalyzer().analyze(commits)
        assert result.raw["p90_lines_changed"] >= result.raw["median_lines_changed"]

    def test_sampled_commits_count(self):
        commits = [_commit(10, 5) for _ in range(8)]
        result = SizeAnalyzer().analyze(commits)
        assert result.raw["sampled_commits"] == 8

    def test_mixed_atomic_and_mega(self):
        small = [_commit(10, 0) for _ in range(5)]   # atomic
        large = [_commit(400, 200) for _ in range(5)]  # mega
        result = SizeAnalyzer().analyze(small + large)
        assert result.raw["atomic_ratio"] == 0.5
        assert result.raw["mega_ratio"] == 0.5
