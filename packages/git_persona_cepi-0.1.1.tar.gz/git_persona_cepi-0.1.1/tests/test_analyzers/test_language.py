"""Tests for LanguageAnalyzer."""

from datetime import datetime, timezone

from git_persona.analyzers.language import LanguageAnalyzer
from git_persona.models import CommitData

_TS = datetime(2024, 1, 1, tzinfo=timezone.utc)


def _commit(language: str | None) -> CommitData:
    return CommitData(sha="x", message="msg", timestamp=_TS, repo_name="r/r", repo_language=language)


class TestLanguageAnalyzerEmpty:
    def test_no_commits_returns_neutral(self):
        result = LanguageAnalyzer().analyze([])
        assert result.axis_score.value == 0.5

    def test_all_none_language_returns_neutral(self):
        commits = [_commit(None) for _ in range(5)]
        result = LanguageAnalyzer().analyze(commits)
        assert result.raw["dominant_category"] == "unknown"


class TestTopLanguages:
    def test_top_language_is_dominant(self):
        commits = [_commit("Python")] * 8 + [_commit("JavaScript")] * 2
        result = LanguageAnalyzer().analyze(commits)
        assert result.raw["top_languages"][0]["language"] == "Python"

    def test_top_languages_max_three(self):
        langs = ["Python", "Go", "Rust", "TypeScript", "Ruby"]
        commits = [_commit(l) for l in langs * 2]
        result = LanguageAnalyzer().analyze(commits)
        assert len(result.raw["top_languages"]) <= 3

    def test_ratios_sum_to_at_most_one(self):
        commits = [_commit("Python")] * 5 + [_commit("Go")] * 3 + [_commit("Rust")] * 2
        result = LanguageAnalyzer().analyze(commits)
        total = sum(lang["ratio"] for lang in result.raw["top_languages"])
        assert total <= 1.01  # allow float rounding


class TestPolyglotScore:
    def test_single_language_scores_near_zero(self):
        commits = [_commit("Python")] * 10
        result = LanguageAnalyzer().analyze(commits)
        assert result.axis_score.value == 0.0
        assert result.axis_score.label == "S"  # Specialist

    def test_many_languages_scores_higher(self):
        langs = ["Python", "Go", "Rust", "TypeScript", "Ruby"]
        commits = [_commit(l) for l in langs * 4]  # 4 commits per language = 20% each
        result = LanguageAnalyzer().analyze(commits)
        assert result.axis_score.value > 0.5


class TestDominantCategory:
    def test_python_is_data_science_or_web_backend(self):
        commits = [_commit("Python")] * 10
        result = LanguageAnalyzer().analyze(commits)
        assert result.raw["dominant_category"] in ("data_science", "web_backend")

    def test_rust_is_systems(self):
        commits = [_commit("Rust")] * 10
        result = LanguageAnalyzer().analyze(commits)
        assert result.raw["dominant_category"] == "systems"

    def test_javascript_is_web_frontend(self):
        commits = [_commit("JavaScript")] * 10
        result = LanguageAnalyzer().analyze(commits)
        assert result.raw["dominant_category"] == "web_frontend"

    def test_distinct_languages_count(self):
        commits = [_commit("Python"), _commit("Go"), _commit("Rust")]
        result = LanguageAnalyzer().analyze(commits)
        assert result.raw["distinct_languages"] == 3
