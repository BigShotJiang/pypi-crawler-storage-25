"""Tests for TimingAnalyzer."""

from datetime import datetime, timezone

import pytest

from git_persona.analyzers.timing import TimingAnalyzer
from git_persona.models import CommitData


def _commit(hour: int, weekday_offset: int = 0) -> CommitData:
    """Create a commit at a specific UTC hour on a fixed Monday + offset days."""
    # 2024-01-01 is a Monday
    from datetime import date, timedelta
    day = date(2024, 1, 1) + timedelta(days=weekday_offset)
    ts = datetime(day.year, day.month, day.day, hour, 0, 0, tzinfo=timezone.utc)
    return CommitData(sha="x", message="msg", timestamp=ts, repo_name="r/r")


class TestTimingAnalyzerEmpty:
    def test_empty_commits_returns_neutral(self):
        result = TimingAnalyzer().analyze([])
        assert result.axis_score.value == 0.5


class TestTimingAnalyzerNightOwl:
    def test_all_night_commits_score_near_one(self):
        commits = [_commit(hour=23) for _ in range(10)]
        result = TimingAnalyzer().analyze(commits)
        assert result.axis_score.value > 0.9
        assert result.axis_score.label == "N"

    def test_midnight_commits_are_night(self):
        commits = [_commit(hour=0) for _ in range(5)]
        result = TimingAnalyzer().analyze(commits)
        assert result.axis_score.value > 0.9


class TestTimingAnalyzerMorningLark:
    def test_all_morning_commits_score_near_zero(self):
        commits = [_commit(hour=9) for _ in range(10)]
        result = TimingAnalyzer().analyze(commits)
        assert result.axis_score.value < 0.1
        assert result.axis_score.label == "M"


class TestTimingAnalyzerRawMetrics:
    def test_peak_hour_is_correct(self):
        commits = [_commit(hour=14)] * 5 + [_commit(hour=22)] * 2
        result = TimingAnalyzer().analyze(commits)
        assert result.raw["peak_hour"] == 14

    def test_weekend_ratio_is_correct(self):
        # weekday_offset=5 → Saturday, =6 → Sunday
        weekday_commits = [_commit(hour=10, weekday_offset=i) for i in range(5)]
        weekend_commits = [_commit(hour=10, weekday_offset=5), _commit(hour=10, weekday_offset=6)]
        all_commits = weekday_commits + weekend_commits
        result = TimingAnalyzer().analyze(all_commits)
        assert abs(result.raw["weekend_ratio"] - 2 / 7) < 0.01

    def test_hour_distribution_keys_are_ints(self):
        commits = [_commit(hour=10), _commit(hour=22)]
        result = TimingAnalyzer().analyze(commits)
        for key in result.raw["hour_distribution"]:
            assert isinstance(key, int)

    def test_weekday_distribution_has_day_names(self):
        commits = [_commit(hour=10)]
        result = TimingAnalyzer().analyze(commits)
        assert "Mon" in result.raw["weekday_distribution"]


class TestTimingAnalyzerMixed:
    def test_half_day_half_night(self):
        day = [_commit(hour=10) for _ in range(5)]
        night = [_commit(hour=22) for _ in range(5)]
        result = TimingAnalyzer().analyze(day + night)
        assert 0.45 <= result.axis_score.value <= 0.55
