"""Tests for FrequencyAnalyzer."""

from datetime import datetime, timedelta, timezone

from git_persona.analyzers.frequency import FrequencyAnalyzer, _longest_gap, _longest_streak
from git_persona.models import CommitData


def _commit(day_offset: int, hour: int = 10) -> CommitData:
    ts = datetime(2024, 1, 1, hour, 0, 0, tzinfo=timezone.utc) + timedelta(days=day_offset)
    return CommitData(sha=f"sha_{day_offset}_{hour}", message="msg", timestamp=ts, repo_name="r/r")


class TestFrequencyAnalyzerEmpty:
    def test_empty_returns_neutral(self):
        result = FrequencyAnalyzer().analyze([])
        assert result.axis_score.value == 0.5
        assert result.raw == {}


class TestFrequencyRawMetrics:
    def test_total_commits_correct(self):
        commits = [_commit(i) for i in range(10)]
        result = FrequencyAnalyzer().analyze(commits)
        assert result.raw["total_commits"] == 10

    def test_active_days_correct(self):
        commits = [_commit(0), _commit(0), _commit(1), _commit(3)]
        result = FrequencyAnalyzer().analyze(commits)
        assert result.raw["active_days"] == 3  # days 0, 1, 3

    def test_total_span_days(self):
        commits = [_commit(0), _commit(9)]
        result = FrequencyAnalyzer().analyze(commits)
        assert result.raw["total_span_days"] == 10

    def test_single_commit_span_is_one(self):
        result = FrequencyAnalyzer().analyze([_commit(0)])
        assert result.raw["total_span_days"] == 1

    def test_commits_per_active_day(self):
        # 4 commits on 2 days
        commits = [_commit(0), _commit(0), _commit(5), _commit(5)]
        result = FrequencyAnalyzer().analyze(commits)
        assert result.raw["commits_per_active_day"] == 2.0


class TestLongestStreak:
    def test_no_dates(self):
        from datetime import date
        assert _longest_streak([]) == 0

    def test_single_date(self):
        from datetime import date
        assert _longest_streak([date(2024, 1, 1)]) == 1

    def test_consecutive_dates(self):
        from datetime import date
        dates = [date(2024, 1, i) for i in range(1, 6)]
        assert _longest_streak(dates) == 5

    def test_streak_with_gap(self):
        from datetime import date
        dates = [date(2024, 1, 1), date(2024, 1, 2), date(2024, 1, 5), date(2024, 1, 6), date(2024, 1, 7)]
        assert _longest_streak(dates) == 3

    def test_all_separate_days(self):
        from datetime import date
        dates = [date(2024, 1, 1), date(2024, 1, 3), date(2024, 1, 5)]
        assert _longest_streak(dates) == 1

    def test_streak_reflected_in_result(self):
        commits = [_commit(i) for i in range(7)]  # 7 consecutive days
        result = FrequencyAnalyzer().analyze(commits)
        assert result.raw["longest_streak_days"] == 7


class TestLongestGap:
    def test_single_date_returns_zero(self):
        from datetime import date
        assert _longest_gap([date(2024, 1, 1)]) == 0

    def test_gap_computed_correctly(self):
        from datetime import date
        dates = [date(2024, 1, 1), date(2024, 1, 10)]
        assert _longest_gap(dates) == 9

    def test_gap_reflected_in_result(self):
        commits = [_commit(0), _commit(20)]
        result = FrequencyAnalyzer().analyze(commits)
        assert result.raw["longest_gap_days"] == 20


class TestConsistency:
    def test_very_consistent_scores_high(self):
        # 1 commit per day for 30 days
        commits = [_commit(i) for i in range(30)]
        result = FrequencyAnalyzer().analyze(commits)
        assert result.axis_score.value > 0.8

    def test_bursty_scores_low(self):
        # 20 commits on day 0, then nothing for 29 days
        commits = [_commit(0, hour=h % 24) for h in range(20)] + [_commit(29)]
        result = FrequencyAnalyzer().analyze(commits)
        assert result.axis_score.value < 0.5
