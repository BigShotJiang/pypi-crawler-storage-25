"""Shared test fixtures for git-persona."""

import pytest


@pytest.fixture
def github_user_response():
    """Minimal GitHub /user API response."""
    return {
        "login": "testuser",
        "id": 12345,
        "name": "Test User",
        "public_repos": 10,
        "followers": 5,
        "created_at": "2020-01-01T00:00:00Z",
    }
