"""Tests for personality classifier."""

import pytest

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.personality import PersonalityType, ClassificationResult, classify, _TYPES


def _metrics(s_val: float, m_val: float, p_val: float, v_val: float) -> dict[str, AnalysisMetrics]:
    return {
        "size": AnalysisMetrics(axis_score=AxisScore("S/B", "Surgeon", "Bulldozer", s_val), raw={}),
        "timing": AnalysisMetrics(axis_score=AxisScore("M/N", "Morning", "Night", m_val), raw={}),
        "ratio": AnalysisMetrics(axis_score=AxisScore("P/R", "Pioneer", "Repairman", p_val), raw={}),
        "message_style": AnalysisMetrics(axis_score=AxisScore("V/T", "Verbose", "Terse", v_val), raw={}),
    }


class TestAllTypesExist:
    def test_sixteen_types_defined(self):
        assert len(_TYPES) == 16

    def test_all_expected_codes_present(self):
        expected = {
            "SMPV", "SMPT", "SMRV", "SMRT",
            "SNPV", "SNPT", "SNRV", "SNRT",
            "BMPV", "BMPT", "BMRV", "BMRT",
            "BNPV", "BNPT", "BNRV", "BNRT",
        }
        assert set(_TYPES.keys()) == expected

    @pytest.mark.parametrize("code,pt", list(_TYPES.items()))
    def test_all_types_have_required_fields(self, code, pt):
        assert pt.code == code
        assert pt.name
        assert pt.emoji
        assert pt.description
        assert len(pt.strengths) >= 1
        assert len(pt.blind_spots) >= 1
        assert pt.verdict


class TestClassify:
    def test_returns_classification_result(self):
        result = classify(_metrics(0.0, 0.0, 0.0, 0.0))
        assert isinstance(result, ClassificationResult)

    def test_axis_scores_present(self):
        result = classify(_metrics(0.0, 0.0, 0.0, 0.0))
        assert set(result.axis_scores.keys()) == {"S/B", "M/N", "P/R", "V/T"}

    # All 16 exact type mappings
    @pytest.mark.parametrize("s,m,p,v,expected_code", [
        (0.0, 0.0, 0.0, 0.0, "SMPV"),  # Surgeon, Morning, Pioneer, Verbose
        (0.0, 0.0, 0.0, 1.0, "SMPT"),  # Surgeon, Morning, Pioneer, Terse
        (0.0, 0.0, 1.0, 0.0, "SMRV"),  # Surgeon, Morning, Repairman, Verbose
        (0.0, 0.0, 1.0, 1.0, "SMRT"),  # Surgeon, Morning, Repairman, Terse
        (0.0, 1.0, 0.0, 0.0, "SNPV"),  # Surgeon, Night, Pioneer, Verbose
        (0.0, 1.0, 0.0, 1.0, "SNPT"),  # Surgeon, Night, Pioneer, Terse
        (0.0, 1.0, 1.0, 0.0, "SNRV"),  # Surgeon, Night, Repairman, Verbose
        (0.0, 1.0, 1.0, 1.0, "SNRT"),  # Surgeon, Night, Repairman, Terse
        (1.0, 0.0, 0.0, 0.0, "BMPV"),  # Bulldozer, Morning, Pioneer, Verbose
        (1.0, 0.0, 0.0, 1.0, "BMPT"),  # Bulldozer, Morning, Pioneer, Terse
        (1.0, 0.0, 1.0, 0.0, "BMRV"),  # Bulldozer, Morning, Repairman, Verbose
        (1.0, 0.0, 1.0, 1.0, "BMRT"),  # Bulldozer, Morning, Repairman, Terse
        (1.0, 1.0, 0.0, 0.0, "BNPV"),  # Bulldozer, Night, Pioneer, Verbose
        (1.0, 1.0, 0.0, 1.0, "BNPT"),  # Bulldozer, Night, Pioneer, Terse
        (1.0, 1.0, 1.0, 0.0, "BNRV"),  # Bulldozer, Night, Repairman, Verbose
        (1.0, 1.0, 1.0, 1.0, "BNRT"),  # Bulldozer, Night, Repairman, Terse
    ])
    def test_type_code_mapping(self, s, m, p, v, expected_code):
        result = classify(_metrics(s, m, p, v))
        assert result.type_code == expected_code
        assert result.type.code == expected_code

    def test_empty_metrics_returns_fallback(self):
        """Missing keys should fall back to neutral (0.5) and a valid type."""
        result = classify({})
        assert result.type_code in _TYPES
        assert isinstance(result.type, PersonalityType)

    def test_partial_metrics_accepted(self):
        """Only some analyzers provided — should still produce a valid result."""
        metrics = {
            "size": AnalysisMetrics(axis_score=AxisScore("S/B", "Surgeon", "Bulldozer", 0.0), raw={}),
        }
        result = classify(metrics)
        assert result.type_code in _TYPES

    def test_boundary_value_exactly_half_is_right_pole(self):
        """At exactly 0.5, label resolves to the right pole's first letter."""
        result = classify(_metrics(0.5, 0.5, 0.5, 0.5))
        # All axes at 0.5 → all labels are right pole (B, N, R, T)
        assert result.type_code == "BNRT"

    def test_type_code_matches_type_code_field(self):
        result = classify(_metrics(0.0, 1.0, 0.0, 1.0))
        assert result.type_code == result.type.code
