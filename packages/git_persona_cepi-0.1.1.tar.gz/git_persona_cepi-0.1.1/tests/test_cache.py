"""Tests for git_persona.cache module."""

import time
from unittest.mock import patch

from git_persona.cache import CACHE_TTL_SECONDS, cache_clear, cache_get, cache_set


class TestCacheGetSet:
    def test_set_and_get_returns_value(self):
        cache_set("test_key_1", {"hello": "world"})
        result = cache_get("test_key_1")
        assert result == {"hello": "world"}

    def test_missing_key_returns_none(self):
        assert cache_get("nonexistent_key_xyz") is None

    def test_expired_entry_returns_none(self):
        cache_set("expiry_key", "some_value")
        # Simulate TTL expiry by patching time.time to return future
        with patch("git_persona.cache.time") as mock_time:
            mock_time.time.return_value = time.time() + CACHE_TTL_SECONDS + 1
            result = cache_get("expiry_key")
        assert result is None

    def test_fresh_entry_not_expired(self):
        cache_set("fresh_key", [1, 2, 3])
        result = cache_get("fresh_key")
        assert result == [1, 2, 3]

    def test_overwrite_existing_key(self):
        cache_set("overwrite_key", "first")
        cache_set("overwrite_key", "second")
        assert cache_get("overwrite_key") == "second"

    def test_none_value_can_be_cached(self):
        # None is a valid JSON value
        cache_set("none_key", None)
        # cache_get returns None both for "not found" and for cached None
        # This is acceptable behavior for this use case
        result = cache_get("none_key")
        # Either None means "not cached" - that's fine
        assert result is None

    def test_list_value(self):
        cache_set("list_key", [{"a": 1}, {"b": 2}])
        assert cache_get("list_key") == [{"a": 1}, {"b": 2}]

    def test_different_keys_are_independent(self):
        cache_set("key_a", "value_a")
        cache_set("key_b", "value_b")
        assert cache_get("key_a") == "value_a"
        assert cache_get("key_b") == "value_b"


class TestCacheClear:
    def test_clear_removes_all_entries(self):
        cache_set("clear_test_1", "x")
        cache_set("clear_test_2", "y")
        removed = cache_clear()
        assert removed >= 0  # may include entries from other tests
        # After clear, newly set keys should work fine
        cache_set("after_clear", "z")
        assert cache_get("after_clear") == "z"
