"""Tests for git_persona.collector module."""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import httpx
import pytest

from git_persona.collector import (
    CollectorError,
    GitHubCollector,
    _commit_from_dict,
    _repo_from_dict,
    _sample,
    _user_from_dict,
)
from git_persona.models import CollectionResult


# ---------------------------------------------------------------------------
# Fixtures: realistic GitHub API response shapes
# ---------------------------------------------------------------------------

USER_RESPONSE = {
    "login": "octocat",
    "name": "The Octocat",
    "public_repos": 8,
    "followers": 100,
    "created_at": "2020-01-01T00:00:00Z",
}

REPO_RESPONSE = [
    {
        "name": "Hello-World",
        "full_name": "octocat/Hello-World",
        "language": "Python",
        "fork": False,
        "stargazers_count": 42,
    },
]

COMMITS_RESPONSE = [
    {
        "sha": "abc123",
        "author": {"login": "octocat"},
        "commit": {
            "author": {"date": "2024-03-01T10:00:00Z"},
            "message": "feat: add new feature",
        },
    },
    {
        "sha": "def456",
        "author": {"login": "octocat"},
        "commit": {
            "author": {"date": "2024-03-02T22:00:00Z"},
            "message": "fix: resolve bug",
        },
    },
]

COMMIT_DETAIL_RESPONSE = {
    "sha": "abc123",
    "stats": {"additions": 50, "deletions": 10},
}


def _make_response(json_data, status_code=200):
    """Create a mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data
    resp.headers = {"x-ratelimit-remaining": "4999", "x-ratelimit-reset": "0"}
    if status_code >= 400:
        resp.raise_for_status.side_effect = httpx.HTTPStatusError(
            message=f"HTTP {status_code}",
            request=MagicMock(),
            response=resp,
        )
    else:
        resp.raise_for_status.return_value = None
    return resp


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

class TestUserFromDict:
    def test_parses_username(self):
        u = _user_from_dict(USER_RESPONSE)
        assert u.username == "octocat"

    def test_parses_repo_count(self):
        u = _user_from_dict(USER_RESPONSE)
        assert u.total_repos == 8

    def test_parses_followers(self):
        u = _user_from_dict(USER_RESPONSE)
        assert u.followers == 100

    def test_account_age_is_positive(self):
        u = _user_from_dict(USER_RESPONSE)
        assert u.account_age_days > 0


class TestRepoFromDict:
    def test_parses_name(self):
        r = _repo_from_dict(REPO_RESPONSE[0])
        assert r.name == "Hello-World"

    def test_parses_language(self):
        r = _repo_from_dict(REPO_RESPONSE[0])
        assert r.primary_language == "Python"

    def test_is_fork_false(self):
        r = _repo_from_dict(REPO_RESPONSE[0])
        assert r.is_fork is False

    def test_parses_stars(self):
        r = _repo_from_dict(REPO_RESPONSE[0])
        assert r.stars == 42


class TestCommitFromDict:
    def test_parses_sha(self):
        c = _commit_from_dict(COMMITS_RESPONSE[0], "octocat/Hello-World")
        assert c.sha == "abc123"

    def test_parses_message(self):
        c = _commit_from_dict(COMMITS_RESPONSE[0], "octocat/Hello-World")
        assert c.message == "feat: add new feature"

    def test_parses_timestamp_as_utc(self):
        c = _commit_from_dict(COMMITS_RESPONSE[0], "octocat/Hello-World")
        assert c.timestamp.tzinfo is not None
        assert c.timestamp.hour == 10

    def test_sets_repo_name(self):
        c = _commit_from_dict(COMMITS_RESPONSE[0], "octocat/Hello-World")
        assert c.repo_name == "octocat/Hello-World"


# ---------------------------------------------------------------------------
# _sample helper
# ---------------------------------------------------------------------------

class TestSample:
    def test_returns_all_when_under_limit(self):
        items = list(range(10))
        assert _sample(items, 20) == items

    def test_returns_exactly_n_when_over_limit(self):
        items = list(range(1000))
        result = _sample(items, 50)
        assert len(result) == 50

    def test_empty_list(self):
        assert _sample([], 10) == []

    def test_single_item(self):
        assert _sample([42], 10) == [42]

    def test_preserves_order(self):
        items = list(range(100))
        result = _sample(items, 10)
        assert result == sorted(result)


# ---------------------------------------------------------------------------
# GitHubCollector integration (mocked HTTP)
# ---------------------------------------------------------------------------

class TestGitHubCollector:
    def _build_collector(self, use_cache=False) -> GitHubCollector:
        return GitHubCollector(token="fake_token", use_cache=use_cache)

    def _setup_client_mock(self, mock_client_cls, side_effects: list):
        """Assign sequential return values to client.get()."""
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.side_effect = side_effects
        mock_client_cls.return_value = mock_client
        return mock_client

    def test_collect_all_returns_collection_result(self):
        collector = self._build_collector()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)

            # REPO_RESPONSE has 1 item (<100), so paginator breaks after page 1 — no extra empty page call.
            # COMMITS_RESPONSE has 2 items (<100), same behaviour.
            mock_client.get.side_effect = [
                _make_response(USER_RESPONSE),                    # /users/octocat
                _make_response(REPO_RESPONSE),                    # repos page1 (1 item → breaks)
                _make_response(COMMITS_RESPONSE),                 # commits page1 (2 items → breaks)
                _make_response(COMMIT_DETAIL_RESPONSE),           # commit detail abc123
                _make_response({**COMMIT_DETAIL_RESPONSE, "sha": "def456"}),  # commit detail def456
            ]
            mock_client_cls.return_value = mock_client

            result = collector.collect_all("octocat", days=90)

        assert isinstance(result, CollectionResult)
        assert result.user.username == "octocat"
        assert len(result.repos) == 1
        assert len(result.commits) == 2

    def test_commits_have_repo_language_set(self):
        collector = self._build_collector()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.side_effect = [
                _make_response(USER_RESPONSE),
                _make_response(REPO_RESPONSE),
                _make_response(COMMITS_RESPONSE),
                _make_response(COMMIT_DETAIL_RESPONSE),
                _make_response({**COMMIT_DETAIL_RESPONSE, "sha": "def456"}),
            ]
            mock_client_cls.return_value = mock_client

            result = collector.collect_all("octocat", days=90)

        for commit in result.commits:
            assert commit.repo_language == "Python"

    def test_commit_stats_are_enriched(self):
        collector = self._build_collector()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.side_effect = [
                _make_response(USER_RESPONSE),
                _make_response(REPO_RESPONSE),
                _make_response(COMMITS_RESPONSE),
                _make_response(COMMIT_DETAIL_RESPONSE),            # abc123: +50 -10
                _make_response({**COMMIT_DETAIL_RESPONSE, "sha": "def456",
                                 "stats": {"additions": 5, "deletions": 2}}),
            ]
            mock_client_cls.return_value = mock_client

            result = collector.collect_all("octocat", days=90)

        first = next(c for c in result.commits if c.sha == "abc123")
        assert first.additions == 50
        assert first.deletions == 10

    def test_empty_repo_list_returns_no_commits(self):
        collector = self._build_collector()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.side_effect = [
                _make_response(USER_RESPONSE),
                _make_response([]),   # no repos
            ]
            mock_client_cls.return_value = mock_client

            result = collector.collect_all("octocat", days=90)

        assert result.total_commits == 0
        assert result.repos == []

    def test_404_on_user_raises_collector_error(self):
        collector = self._build_collector()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.return_value = _make_response({}, status_code=404)
            mock_client.get.return_value.raise_for_status.return_value = None
            # Simulate _get returning None for 404
            mock_client.get.return_value.status_code = 404
            mock_client_cls.return_value = mock_client

            with pytest.raises(CollectorError, match="not found"):
                collector.collect_all("ghost_user", days=90)

    def test_is_self_uses_user_repos_endpoint(self):
        """is_self=True should call /user/repos (includes private repos)."""
        collector = self._build_collector()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.side_effect = [
                _make_response(USER_RESPONSE),
                _make_response(REPO_RESPONSE),    # /user/repos page1
                _make_response(COMMITS_RESPONSE),
                _make_response(COMMIT_DETAIL_RESPONSE),
                _make_response({**COMMIT_DETAIL_RESPONSE, "sha": "def456"}),
            ]
            mock_client_cls.return_value = mock_client

            collector.collect_all("octocat", days=90, is_self=True)

        calls = [str(call) for call in mock_client.get.call_args_list]
        assert any("/user/repos" in c for c in calls)

    def test_date_range_reflects_commits(self):
        collector = self._build_collector()

        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.side_effect = [
                _make_response(USER_RESPONSE),
                _make_response(REPO_RESPONSE),
                _make_response(COMMITS_RESPONSE),
                _make_response(COMMIT_DETAIL_RESPONSE),
                _make_response({**COMMIT_DETAIL_RESPONSE, "sha": "def456"}),
            ]
            mock_client_cls.return_value = mock_client

            result = collector.collect_all("octocat", days=90)

        earliest, latest = result.date_range
        assert earliest is not None
        assert latest is not None
        assert earliest <= latest


# ---------------------------------------------------------------------------
# Client-side author filtering in _get_repo_commits
# ---------------------------------------------------------------------------

class TestGetRepoCommitsFiltering:
    """Tests for client-side author filtering logic."""

    def _build_collector(self) -> GitHubCollector:
        return GitHubCollector(token="fake_token", use_cache=False)

    def _run_collect(self, mock_client_cls, commit_list, username="octocat"):
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.get.side_effect = [
            _make_response({"login": username, "name": "X", "public_repos": 1,
                            "followers": 0, "created_at": "2020-01-01T00:00:00Z"}),
            _make_response([{
                "name": "Hello-World",
                "full_name": f"{username}/Hello-World",
                "language": "Python",
                "fork": False,
                "stargazers_count": 0,
            }]),
            _make_response(commit_list),
            # no stat calls needed if commit_list is empty
            *[_make_response({"sha": c["sha"], "stats": {"additions": 0, "deletions": 0}})
              for c in commit_list if (c.get("author") or {}).get("login", "").lower() == username.lower()
              or c.get("author") is None],
        ]
        mock_client_cls.return_value = mock_client
        collector = self._build_collector()
        return collector.collect_all(username, days=90)

    def test_matching_author_login_is_included(self):
        commits = [{
            "sha": "aaa",
            "author": {"login": "octocat"},
            "commit": {"author": {"date": "2024-01-01T00:00:00Z"}, "message": "hi"},
        }]
        with patch("httpx.Client") as mock_client_cls:
            result = self._run_collect(mock_client_cls, commits)
        assert len(result.commits) == 1
        assert result.commits[0].sha == "aaa"

    def test_different_author_login_is_excluded(self):
        commits = [{
            "sha": "bbb",
            "author": {"login": "someoneelse"},
            "commit": {"author": {"date": "2024-01-01T00:00:00Z"}, "message": "hi"},
        }]
        with patch("httpx.Client") as mock_client_cls:
            result = self._run_collect(mock_client_cls, commits)
        assert len(result.commits) == 0

    def test_null_author_on_own_repo_is_included(self):
        """Commits with no GitHub user link on own repos should be included."""
        commits = [{
            "sha": "ccc",
            "author": None,
            "commit": {"author": {"date": "2024-01-01T00:00:00Z"}, "message": "hi"},
        }]
        with patch("httpx.Client") as mock_client_cls:
            result = self._run_collect(mock_client_cls, commits)
        assert len(result.commits) == 1

    def test_null_author_on_foreign_repo_is_excluded(self):
        """Commits with no GitHub user link on repos not owned by the user are excluded."""
        collector = self._build_collector()
        foreign_repo = "otheruser/project"
        commits = [{
            "sha": "ddd",
            "author": None,
            "commit": {"author": {"date": "2024-01-01T00:00:00Z"}, "message": "hi"},
        }]
        with patch("httpx.Client") as mock_client_cls:
            mock_client = MagicMock()
            mock_client.__enter__ = MagicMock(return_value=mock_client)
            mock_client.__exit__ = MagicMock(return_value=False)
            mock_client.get.side_effect = [
                _make_response({"login": "octocat", "name": "X", "public_repos": 1,
                                "followers": 0, "created_at": "2020-01-01T00:00:00Z"}),
                _make_response([{
                    "name": "project",
                    "full_name": foreign_repo,
                    "language": "Python",
                    "fork": False,
                    "stargazers_count": 0,
                }]),
                _make_response(commits),
            ]
            mock_client_cls.return_value = mock_client
            result = collector.collect_all("octocat", days=90)
        assert len(result.commits) == 0

    def test_case_insensitive_login_match(self):
        """Author login matching should be case-insensitive."""
        commits = [{
            "sha": "eee",
            "author": {"login": "OctoCat"},  # different case
            "commit": {"author": {"date": "2024-01-01T00:00:00Z"}, "message": "hi"},
        }]
        with patch("httpx.Client") as mock_client_cls:
            result = self._run_collect(mock_client_cls, commits)
        assert len(result.commits) == 1
