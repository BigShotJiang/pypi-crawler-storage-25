"""Tests for report rendering."""

import json
from datetime import datetime, timezone

from rich.console import Console

from git_persona.analyzers.base import AnalysisMetrics, AxisScore
from git_persona.models import CollectionResult, CommitData, RepoInfo, UserProfile
from git_persona.personality import ClassificationResult, _TYPES
from git_persona.report import build_json_report, render_report

_TS = datetime(2024, 1, 15, 22, 0, 0, tzinfo=timezone.utc)


def _make_collection(n_commits: int = 5) -> CollectionResult:
    user = UserProfile(username="testuser", total_repos=3, account_age_days=365, followers=10, name="Test User")
    commits = [
        CommitData(sha=f"s{i}", message="feat: add feature", timestamp=_TS, repo_name="r/r", additions=10, deletions=2)
        for i in range(n_commits)
    ]
    repos = [RepoInfo(name="repo1", full_name="u/repo1", primary_language="Python", is_fork=False, stars=5)]
    return CollectionResult(user=user, commits=commits, repos=repos, analysis_days=90)


def _make_metrics() -> dict[str, AnalysisMetrics]:
    return {
        "timing": AnalysisMetrics(
            axis_score=AxisScore("M/N", "Morning", "Night", 0.8),
            raw={"peak_hour": 23, "weekend_ratio": 0.2, "hour_distribution": {}, "weekday_distribution": {}},
        ),
        "message_style": AnalysisMetrics(
            axis_score=AxisScore("V/T", "Verbose", "Terse", 0.3),
            raw={},
        ),
        "size": AnalysisMetrics(
            axis_score=AxisScore("S/B", "Surgeon", "Bulldozer", 0.1),
            raw={},
        ),
        "ratio": AnalysisMetrics(
            axis_score=AxisScore("P/R", "Pioneer", "Repairman", 0.2),
            raw={},
        ),
        "frequency": AnalysisMetrics(
            axis_score=AxisScore("F/F", "Sporadic", "Consistent", 0.7),
            raw={
                "total_commits": 5,
                "active_days": 4,
                "total_span_days": 30,
                "commits_per_active_day": 1.25,
                "commits_per_calendar_day": 0.17,
                "longest_streak_days": 3,
                "longest_gap_days": 10,
                "consistency_cv": 0.4,
            },
        ),
        "language": AnalysisMetrics(
            axis_score=AxisScore("L/L", "Specialist", "Polyglot", 0.0),
            raw={
                "top_languages": [
                    {"language": "Python", "ratio": 0.8},
                    {"language": "TypeScript", "ratio": 0.2},
                ],
                "distinct_languages": 2,
                "dominant_category": "web_backend",
            },
        ),
    }


def _make_result(metrics: dict[str, AnalysisMetrics]) -> ClassificationResult:
    from git_persona.personality import classify
    return classify(metrics)


class TestRenderReport:
    def test_renders_without_error(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)  # must not raise

    def test_output_contains_type_code(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)
        text = con.export_text()
        assert result.type_code in text

    def test_output_contains_personality_name(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)
        text = con.export_text()
        assert result.type.name in text

    def test_output_contains_verdict(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)
        text = con.export_text()
        assert result.type.verdict in text

    def test_output_contains_language(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)
        text = con.export_text()
        assert "Python" in text

    def test_renders_with_no_frequency_data(self):
        metrics = _make_metrics()
        metrics["frequency"] = AnalysisMetrics(
            axis_score=AxisScore("F/F", "Sporadic", "Consistent", 0.5), raw={}
        )
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)  # must not raise

    def test_renders_with_no_language_data(self):
        metrics = _make_metrics()
        metrics["language"] = AnalysisMetrics(
            axis_score=AxisScore("L/L", "Specialist", "Polyglot", 0.0),
            raw={"top_languages": [], "distinct_languages": 0, "dominant_category": "unknown"},
        )
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)  # must not raise

    def test_renders_axis_poles(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        con = Console(record=True, width=120)
        render_report(result, collection, metrics, con)
        text = con.export_text()
        # At least some axis labels should appear
        assert any(pole in text for pole in ["Surgeon", "Bulldozer", "Morning", "Night", "Pioneer", "Repairman"])


class TestBuildJsonReport:
    def test_returns_valid_json(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        payload = json.loads(build_json_report(result, collection, metrics))
        assert isinstance(payload, dict)

    def test_json_contains_personality_fields(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        payload = json.loads(build_json_report(result, collection, metrics))
        assert "personality" in payload
        p = payload["personality"]
        assert p["code"] == result.type_code
        assert "name" in p
        assert "emoji" in p
        assert "description" in p
        assert "strengths" in p
        assert "blind_spots" in p
        assert "verdict" in p

    def test_json_contains_axes(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        payload = json.loads(build_json_report(result, collection, metrics))
        assert "axes" in payload
        assert set(payload["axes"].keys()) == {"S/B", "M/N", "P/R", "V/T"}

    def test_json_contains_stats(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        payload = json.loads(build_json_report(result, collection, metrics))
        assert "stats" in payload

    def test_json_collection_fields(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection(n_commits=7)
        payload = json.loads(build_json_report(result, collection, metrics))
        assert payload["collection"]["total_commits"] == 7
        assert payload["collection"]["total_repos"] == 1
        assert payload["username"] == "testuser"

    def test_json_axis_value_is_float(self):
        metrics = _make_metrics()
        result = _make_result(metrics)
        collection = _make_collection()
        payload = json.loads(build_json_report(result, collection, metrics))
        for axis_data in payload["axes"].values():
            assert isinstance(axis_data["value"], float)
