"""Tests for the CLI entry point."""

from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

import httpx
import pytest
from click.testing import CliRunner

from git_persona.cli import main
from git_persona.models import CollectionResult, CommitData, RepoInfo, UserProfile


def _fake_collection() -> CollectionResult:
    """Minimal CollectionResult for CLI tests."""
    user = UserProfile(username="testuser", total_repos=2, account_age_days=100, followers=1, name="Test User")
    ts = datetime(2024, 1, 15, 10, 0, tzinfo=timezone.utc)
    commits = [
        CommitData(sha="abc", message="feat: thing", timestamp=ts, repo_name="r/r", additions=5, deletions=1)
    ]
    repos = [RepoInfo(name="r", full_name="r/r", primary_language="Python", is_fork=False, stars=0)]
    return CollectionResult(user=user, commits=commits, repos=repos)


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def mock_user_response():
    return {
        "login": "testuser",
        "name": "Test User",
        "public_repos": 10,
        "followers": 5,
        "created_at": "2020-01-01T00:00:00Z",
    }


class TestAnalyzeCommand:
    def _make_httpx_response(self, json_data: dict, status_code: int = 200):
        """Create a mock httpx Response."""
        response = MagicMock(spec=httpx.Response)
        response.status_code = status_code
        response.json.return_value = json_data
        if status_code >= 400:
            response.raise_for_status.side_effect = httpx.HTTPStatusError(
                message=f"HTTP {status_code}",
                request=MagicMock(),
                response=response,
            )
        else:
            response.raise_for_status.return_value = None
        return response

    def test_analyze_with_valid_token(self, runner, mock_user_response):
        mock_resp = self._make_httpx_response(mock_user_response)
        with patch("git_persona.auth.get_github_token", return_value="fake_token"):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.return_value = mock_resp
                mock_client_cls.return_value = mock_client
                with patch("git_persona.cli.GitHubCollector") as mock_collector_cls:
                    mock_collector = MagicMock()
                    mock_collector.collect_all.return_value = _fake_collection()
                    mock_collector_cls.return_value = mock_collector

                    result = runner.invoke(main, ["analyze", "--token", "fake_token"])

        assert result.exit_code == 0
        assert "testuser" in result.output

    def test_analyze_auth_error_exits_with_code_1(self, runner):
        from git_persona.auth import AuthError

        with patch("git_persona.auth.get_github_token", side_effect=AuthError("no token")):
            result = runner.invoke(main, ["analyze"])

        assert result.exit_code == 1
        assert "Authentication Error" in result.output

    def test_analyze_invalid_token_exits_with_code_1(self, runner):
        mock_resp = self._make_httpx_response({}, status_code=401)
        with patch("git_persona.auth.get_github_token", return_value="bad_token"):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.return_value = mock_resp
                mock_client_cls.return_value = mock_client

                result = runner.invoke(main, ["analyze", "--token", "bad_token"])

        assert result.exit_code == 1
        assert "Invalid" in result.output or "expired" in result.output

    def test_analyze_network_error_exits_with_code_1(self, runner):
        with patch("git_persona.auth.get_github_token", return_value="fake_token"):
            with patch("httpx.Client") as mock_client_cls:
                mock_client = MagicMock()
                mock_client.__enter__ = MagicMock(return_value=mock_client)
                mock_client.__exit__ = MagicMock(return_value=False)
                mock_client.get.side_effect = httpx.RequestError("connection failed")
                mock_client_cls.return_value = mock_client

                result = runner.invoke(main, ["analyze", "--token", "fake_token"])

        assert result.exit_code == 1
        assert "Network Error" in result.output

    def test_help_output(self, runner):
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "git-persona" in result.output.lower() or "analyze" in result.output

    def test_analyze_help_output(self, runner):
        result = runner.invoke(main, ["analyze", "--help"])
        assert result.exit_code == 0
        assert "--token" in result.output
        assert "--days" in result.output
        assert "--deep" in result.output
