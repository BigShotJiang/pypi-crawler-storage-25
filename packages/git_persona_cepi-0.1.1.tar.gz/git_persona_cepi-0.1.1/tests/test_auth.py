"""Tests for git_persona.auth module."""

import subprocess
from unittest.mock import MagicMock, patch

import pytest

from git_persona.auth import AuthError, get_github_token, validate_token_scopes


class TestGetGithubToken:
    def test_explicit_token_returned_directly(self):
        token = get_github_token(token="explicit_token_123")
        assert token == "explicit_token_123"

    def test_env_var_used_when_no_explicit_token(self, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "env_token_456")
        token = get_github_token(token=None)
        assert token == "env_token_456"

    def test_explicit_token_takes_priority_over_env(self, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "env_token_456")
        token = get_github_token(token="explicit_token_123")
        assert token == "explicit_token_123"

    def test_gh_cli_used_as_fallback(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "gh_cli_token_789\n"
        with patch("subprocess.run", return_value=mock_result) as mock_run:
            token = get_github_token(token=None)
            assert token == "gh_cli_token_789"
            mock_run.assert_called_once_with(
                ["gh", "auth", "token"],
                capture_output=True,
                text=True,
                timeout=10,
            )

    def test_gh_cli_nonzero_exit_falls_through_to_error(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        with patch("subprocess.run", return_value=mock_result):
            with pytest.raises(AuthError) as exc_info:
                get_github_token(token=None)
        assert "No GitHub token found" in str(exc_info.value)

    def test_gh_cli_not_installed_falls_through_to_error(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        with patch("subprocess.run", side_effect=FileNotFoundError):
            with pytest.raises(AuthError) as exc_info:
                get_github_token(token=None)
        assert "gh auth login" in str(exc_info.value)

    def test_gh_cli_timeout_falls_through_to_error(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="gh", timeout=10)):
            with pytest.raises(AuthError):
                get_github_token(token=None)

    def test_gh_cli_empty_output_falls_through_to_error(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "   \n"
        with patch("subprocess.run", return_value=mock_result):
            with pytest.raises(AuthError):
                get_github_token(token=None)

    def test_no_token_anywhere_raises_auth_error(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        with patch("subprocess.run", side_effect=FileNotFoundError):
            with pytest.raises(AuthError) as exc_info:
                get_github_token(token=None)
        error_msg = str(exc_info.value)
        assert "--token" in error_msg
        assert "GITHUB_TOKEN" in error_msg


class TestValidateTokenScopes:
    def test_parses_multiple_scopes(self):
        scopes = validate_token_scopes("token", {"x-oauth-scopes": "repo, user, gist"})
        assert "repo" in scopes
        assert "user" in scopes
        assert "gist" in scopes

    def test_empty_scopes_header(self):
        scopes = validate_token_scopes("token", {"x-oauth-scopes": ""})
        assert scopes == []

    def test_missing_scopes_header(self):
        scopes = validate_token_scopes("token", {})
        assert scopes == []

    def test_single_scope(self):
        scopes = validate_token_scopes("token", {"x-oauth-scopes": "repo"})
        assert scopes == ["repo"]
