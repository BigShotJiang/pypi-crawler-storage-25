# git-persona

GitHubのコミット履歴からエンジニアの仕事スタイルを16タイプに診断するCLIツール。

**Analyze your GitHub commit history and discover your Engineer Personality Diagnosis.**

```
╭────────────────────────────────────────────────────────────────╮
│                                                                │
│  🕵️  The Shadow Debugger  [SNRT]                               │
│                                                                │
│  Midnight, minimal messages, maximum fixes. You materialise   │
│  in the git log like a ghost, resolve the issue, and vanish   │
│  before anyone asks questions.                                 │
│                                                                │
│  Verdict: Forensics teams would love your diffs.              │
│           Your commit messages, not so much.                  │
│                                                                │
╰────────────────────────────────────────────────────────────────╯
```

---

## インストール / Installation

```bash
pip install git-persona-cepi
```

---

## 使い方 / Usage

### GitHubトークンの取得

1. https://github.com/settings/tokens を開く
2. **Generate new token (classic)** をクリック
3. `repo` スコープにチェックを入れてトークンを発行
4. 発行されたトークン（`ghp_` で始まる文字列）をコピー

> **gh CLI を使っている場合はトークン不要です。** `gh auth login` 済みなら `git-persona analyze` だけで動きます。

### 基本の使い方

```bash
# 自分のアカウントを診断（プライベートリポジトリも含む）
git-persona analyze --token ghp_XXXXXXXXXX

# gh CLI でログイン済みならトークン不要
git-persona analyze

# 日本語で出力
git-persona analyze --lang ja

# 他のユーザーを診断
git-persona analyze --username torvalds

# 全コミット履歴を対象にする（デフォルトは直近90日）
git-persona analyze --deep

# JSON形式で出力
git-persona analyze --output json
```

---

## 診断タイプ / Personality Types

4つの軸から16タイプを判定します：

| 軸 | 左極 | 右極 |
|----|------|------|
| **S/B** | Surgeon（小さく精密なコミット） | Bulldozer（大きな変更セット） |
| **M/N** | Morning Lark（昼型） | Night Owl（夜型） |
| **P/R** | Pioneer（新機能志向） | Repairman（修正・保守志向） |
| **V/T** | Verbose（詳細なメッセージ） | Terse（簡潔なメッセージ） |

例：`SNRT` = Shadow Debugger、`BMPV` = Bold Visionary、`BNPT` = Caffeine-Powered Steamroller

---

## オプション一覧 / Options

```
--token TEXT              GitHubパーソナルアクセストークン
--username TEXT           診断対象のGitHubユーザー名（省略時: 自分）
--days INTEGER            分析対象の日数 [デフォルト: 90]
--deep                    全コミット履歴を対象にする（--days を無視）
--no-cache                キャッシュを使わず最新データを取得
--output [terminal|json]  出力形式 [デフォルト: terminal]
--lang [en|ja]            出力言語 [デフォルト: en]
--timezone TEXT           時間分析に使うタイムゾーン（例: Asia/Tokyo）
--no-color                カラー出力を無効にする
```

---

## License

MIT
