# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.7] - 2026-03-02

# Changed
Renamed Actor => User


## [0.1.2] - 2026-02-17

### Added

- Comprehensive docstrings and type hints to all modules
- Module-level documentation for better code understanding
- Improved error handling in CLI with better error messages
- Package `__init__.py` with proper exports
- Code comments explaining functionality throughout
- Support for branch create/delete events without PR title field

### Changed

- Improved CLI argument parser with better help text and choices validation
- Enhanced email validation with clearer error messages
- Better structured template generation code

### Fixed

- Title field now correctly skipped for branch_create and branch_delete events
- Improved type safety with proper type hints

## [0.1.1] - Improvements

* Code cleanup

## [0.1.0] - Initial Release

### Added

- Basic email sending functionality via SMTP
- Support for GitHub event notifications:
  - Branch created
  - Branch deleted
  - New pull request
  - Pull request merged
  - Merge conflict detected
- CLI interface for GitHub Actions integration
- HTML email templates with color-coded headers
- Support for CC recipients
- Configurable SMTP settings
