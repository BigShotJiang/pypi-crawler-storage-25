"""Email sending functionality for GitHub email alerts.

This module provides functionality to send HTML emails via SMTP,
specifically designed for GitHub Actions notifications.
"""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import List


def send_email(
    smtp_host: str,
    smtp_port: int,
    email_user: str,
    email_pass: str,
    to_list: List[str],
    cc_list: List[str],
    subject: str,
    body: str,
) -> None:
    """Send an HTML email via SMTP.

    Creates and sends an HTML email message using the provided SMTP configuration.
    Supports both TO and CC recipients. Uses TLS encryption for secure transmission.

    Args:
        smtp_host: SMTP server hostname (e.g., 'smtp.gmail.com').
        smtp_port: SMTP server port number (typically 587 for TLS).
        email_user: Email address to authenticate with SMTP server.
        email_pass: Password or app-specific password for SMTP authentication.
        to_list: List of primary recipient email addresses.
        cc_list: List of CC recipient email addresses (can be empty).
        subject: Email subject line.
        body: HTML email body content.

    Raises:
        smtplib.SMTPException: If SMTP server connection or authentication fails.
        smtplib.SMTPRecipientsRefused: If any recipient addresses are invalid.
        ValueError: If to_list is empty.

    Example:
        >>> send_email(
        ...     smtp_host="smtp.gmail.com",
        ...     smtp_port=587,
        ...     email_user="sender@example.com",
        ...     email_pass="password",
        ...     to_list=["recipient@example.com"],
        ...     cc_list=["cc@example.com"],
        ...     subject="Test Email",
        ...     body="<html><body><h1>Hello</h1></body></html>"
        ... )
    """
    # Validate that at least one recipient is provided
    if not to_list:
        raise ValueError("At least one recipient email address is required")

    # Create multipart message container
    msg = MIMEMultipart()
    msg["From"] = email_user
    msg["To"] = ", ".join(to_list)

    # Add CC recipients if provided
    if cc_list:
        msg["Cc"] = ", ".join(cc_list)

    msg["Subject"] = subject

    # Attach HTML body to the message
    msg.attach(MIMEText(body, "html"))

    # Combine all recipients for sending
    recipients = to_list + cc_list

    # Connect to SMTP server and send email
    with smtplib.SMTP(smtp_host, smtp_port) as server:
        # Enable TLS encryption
        server.starttls()
        # Authenticate with SMTP server
        server.login(email_user, email_pass)
        # Send the email to all recipients
        server.sendmail(email_user, recipients, msg.as_string())
