"""
ContextManager: unified entry point.
Wraps an OpenAI-compatible client and manages:
  - Continuous history list: old turns are in-place compressed summaries,
    recent turns are verbatim — cache-friendly
  - Core memory: persistent user profile (passive judge at compression + session end)
  - Lazy compression: only when context >= 50% of model window

Why in-place compression achieves high cache hit rates:
  Turn N   sends: [system+core] + [_history[0..N-1]] + [current_N]
  Turn N+1 sends: [system+core] + [_history[0..N-1], u_N, a_N] + [current_N+1]
  Prefix [system+core] + [_history[0..N-1]] is identical → cached
  After compression: 1 miss, then new stable prefix re-establishes cache.
"""

import logging
import sqlite3
import threading
import time
from typing import Any

from openai import OpenAI

logger = logging.getLogger("chatmem")

from .compressor import Compressor
from .config import ContextConfig
from .memory.core_memory import CoreMemory
from .memory.recent_memory import RecentMemory
from .memory.forgetting import ForgettingManager
from .memory.consolidation import ConsolidationTask


COMPRESS_THRESHOLD = 0.50     # trigger compression at 50% full
VERBATIM_TAIL = 20            # always keep last N turns verbatim after compression
IDLE_SESSION_TIMEOUT = 3600   # seconds of inactivity before auto end_session (1 hour)


class ContextManager:
    """
    Drop-in wrapper around an OpenAI-compatible client.
    Usage:
        cm = ContextManager.create(api_key=..., db_path=..., config=config)
        response = cm.chat(messages)   # replaces client.chat.completions.create
    """

    def __init__(
        self,
        client: OpenAI,
        api_key: str,
        db_path: str = "chatmem.db",
        core_db_path: str | None = None,
        use_prompt_cache: bool = False,
        verbatim_tail: int = VERBATIM_TAIL,
        idle_session_timeout: int = IDLE_SESSION_TIMEOUT,
        keep_verbatim_on_end: int = 50,
        config: ContextConfig | None = None,
    ):
        self.client = client
        self.api_key = api_key
        self.use_prompt_cache = use_prompt_cache
        self.verbatim_tail = verbatim_tail
        self.idle_session_timeout = idle_session_timeout
        self.keep_verbatim_on_end = keep_verbatim_on_end

        cfg = config or ContextConfig()
        self.model = cfg.llm.model
        self.context_window = cfg.llm.context_window
        self._extra_body = cfg.llm.extra_body
        self._excluded_params = cfg.llm.excluded_params
        compress_model = cfg.llm.compress_model or cfg.llm.model

        _provider = getattr(cfg.llm, "provider", "openai") or "openai"
        self.compressor = Compressor(
            api_key=api_key,
            model=compress_model,
            base_url=cfg.llm.base_url,
            extra_body=cfg.llm.extra_body,
            provider=_provider,
        )
        self.db_path = db_path
        # core_memory uses core_db_path if provided (shared across sessions/projects)
        _core_db = core_db_path or db_path
        self.core_memory = CoreMemory(
            _core_db, api_key,
            model=compress_model,
            base_url=cfg.llm.base_url,
            dimensions=cfg.dimensions,
            extra_body=cfg.llm.extra_body,
            provider=_provider,
        )
        self.recent_memory = RecentMemory(db_path, self.compressor, inject_token_cap=None)
        self.forgetting = ForgettingManager(self.core_memory)
        self.consolidation = ConsolidationTask(
            self.recent_memory, self.core_memory, api_key,
            model=compress_model, base_url=cfg.llm.base_url,
            extra_body=cfg.llm.extra_body,
            provider=_provider,
        )

        # Continuous history: role+content messages, old turns may be compressed summaries
        # Internal key _is_summary=True marks summary messages; stripped before API calls.
        self._history: list[dict] = []
        self._turn_count = 0

        # Persist and restore session history across process restarts
        self._init_session_db()
        self._restore_history()
        self._session_count = self._load_session_count()
        self._last_context_tokens: int = 0
        self._last_chat_time: float = 0.0
        self._compress_pending: bool = False  # set True after compression → triggers full resync

    @classmethod
    def create(
        cls,
        api_key: str | None = None,
        db_path: str = "chatmem.db",
        core_db_path: str | None = None,
        config: ContextConfig | None = None,
        **kwargs,
    ) -> "ContextManager":
        """
        Factory method. All LLM settings come from config (or defaults).
        API key resolution order: explicit api_key > config.llm.api_key > config.llm.api_key_env.

        Examples:
            # Key from code
            cm = ContextManager.create(api_key="sk-...", config=config)

            # Key from config.json (api_key field)
            cm = ContextManager.create(config=ContextConfig.from_json("config.json"))

            # Key from env var named in config.json (api_key_env: "OPENAI_API_KEY")
            cm = ContextManager.create(config=ContextConfig.from_json("config.json"))
        """
        cfg = config or ContextConfig()
        key = api_key or cfg.llm.resolve_api_key()
        if not key:
            raise ValueError(
                "API key required. Pass api_key=, or set config.llm.api_key / config.llm.api_key_env."
            )
        provider = getattr(cfg.llm, "provider", "openai") or "openai"
        if provider == "anthropic":
            try:
                from ..llm import make_adapter
                client = make_adapter(cfg).chat  # _OpenAIShim
            except ImportError:
                # standalone chatmem use — fall back to OpenAI SDK
                client = OpenAI(api_key=key, base_url=cfg.llm.base_url)
        else:
            client = OpenAI(api_key=key, base_url=cfg.llm.base_url)
        return cls(client=client, api_key=key, db_path=db_path,
                   core_db_path=core_db_path, config=cfg, **kwargs)

    # ------------------------------------------------------------------
    # Main entry point
    # ------------------------------------------------------------------

    def chat(
        self,
        messages: list[dict],
        **kwargs,
    ) -> Any:
        """
        Drop-in replacement for client.chat.completions.create.
        Builds enriched context from memory tiers before calling LLM.

        Post-turn processing is synchronous so that _history is fully updated
        (including any in-place compression) before the next _build_context call.
        Only forgetting decay runs in the background (doesn't affect prefix).
        """
        now = time.time()
        if self._last_chat_time > 0 and (now - self._last_chat_time) > self.idle_session_timeout:
            logger.info(
                "[session] resumed after %.0fs idle — history preserved (%d msgs)",
                now - self._last_chat_time,
                len(self._history),
            )
        self._last_chat_time = now

        enriched = self._build_context(messages)

        if self._extra_body:
            merged = dict(self._extra_body)
            merged.update(kwargs.get("extra_body") or {})
            kwargs["extra_body"] = merged

        if kwargs.get("stream"):
            return self._chat_stream(messages, enriched, **kwargs)

        response = self.client.chat.completions.create(
            model=self.model,
            messages=enriched,
            **kwargs,
        )

        assistant_text = response.choices[0].message.content or ""
        user_text = messages[-1].get("content", "") if messages else ""

        self._post_turn(user_text, assistant_text, messages)

        return response

    def _chat_stream(self, messages: list[dict], enriched: list[dict], **kwargs):
        """
        Streaming variant: yields chunks as they arrive, then calls _post_turn.
        Returns a generator — callers iterate it exactly like the SDK stream.
        """
        stream = self.client.chat.completions.create(
            model=self.model,
            messages=enriched,
            **kwargs,
        )
        collected: list[str] = []
        for chunk in stream:
            if chunk.choices and chunk.choices[0].delta.content:
                collected.append(chunk.choices[0].delta.content)
            yield chunk

        assistant_text = "".join(collected)
        user_text = messages[-1].get("content", "") if messages else ""
        self._post_turn(user_text, assistant_text, messages)

    async def achat(self, messages: list[dict], **kwargs) -> Any:
        """
        Async drop-in replacement for async OpenAI client usage.
        _post_turn (which may compress via LLM) runs in a thread to avoid blocking the event loop.
        """
        import asyncio
        from openai import AsyncOpenAI

        if not hasattr(self, "_async_client"):
            base_url = str(self.client.base_url).rstrip("/") if self.client.base_url else None
            self._async_client = AsyncOpenAI(api_key=self.api_key, base_url=base_url)

        now = time.time()
        if self._last_chat_time > 0 and (now - self._last_chat_time) > self.idle_session_timeout:
            logger.info(
                "[session] resumed after %.0fs idle — history preserved (%d msgs)",
                now - self._last_chat_time,
                len(self._history),
            )
        self._last_chat_time = now

        enriched = self._build_context(messages)
        response = await self._async_client.chat.completions.create(
            model=self.model,
            messages=enriched,
            **kwargs,
        )

        assistant_text = response.choices[0].message.content or ""
        user_text = messages[-1].get("content", "") if messages else ""
        # _post_turn may call LLM (compression) — run in thread to avoid blocking loop
        await asyncio.to_thread(self._post_turn, user_text, assistant_text, messages)
        return response

    # ------------------------------------------------------------------
    # Context assembly
    # ------------------------------------------------------------------

    def _build_context(self, messages: list[dict]) -> list[dict]:
        """
        Assemble: [system+core(cached)] + [_history] + [current]

        _history is the full conversation with old turns as in-place summaries.
        This mirrors baseline's growing prefix → high cache hit rate.
        """
        result = []

        system_msg = None
        non_system = messages
        if messages and messages[0].get("role") == "system":
            system_msg = messages[0]
            non_system = messages[1:]

        core_str = self.core_memory.to_context_string()
        recent_str = self.recent_memory.get_for_context()

        prefix_parts = []
        if system_msg:
            prefix_parts.append(system_msg["content"])
        if core_str:
            prefix_parts.append(core_str)
        if recent_str:
            prefix_parts.append(f"[Session History Summary]\n{recent_str}")

        if prefix_parts:
            msg = {"role": "system", "content": "\n\n".join(prefix_parts)}
            if self.use_prompt_cache:
                msg["cache_control"] = {"type": "ephemeral"}
            result.append(msg)

        for msg in self._history:
            result.append({"role": msg["role"], "content": msg["content"]})

        if non_system:
            result.extend(non_system)

        from .token_counter import count_messages_tokens
        total_tokens = count_messages_tokens(result)
        self._last_context_tokens = total_tokens
        logger.debug(
            "[context] turn=%d  history_msgs=%d  total=%d tokens",
            self._turn_count + 1,
            len(self._history),
            total_tokens,
        )

        return result

    # ------------------------------------------------------------------
    # Post-turn processing
    # ------------------------------------------------------------------

    def _post_turn(
        self, user_text: str, assistant_text: str, original_messages: list[dict]
    ):
        """Synchronous post-turn processing."""
        self._turn_count += 1
        turn_id = self._turn_count

        if user_text:
            self._history.append({"role": "user", "content": user_text})
        if assistant_text:
            self._history.append({"role": "assistant", "content": assistant_text})

        self._maybe_compress(turn_id)
        self._persist_history()

        if self._turn_count % 10 == 0:
            threading.Thread(
                target=self.forgetting.run_decay, daemon=True
            ).start()

    def _maybe_compress(self, turn_id: int):
        """Trigger compression when estimated full context size exceeds COMPRESS_THRESHOLD."""
        if self._last_context_tokens > 0:
            total = self._last_context_tokens
        else:
            from .token_counter import count_messages_tokens, count_tokens
            total = (count_messages_tokens(self._history)
                     + count_tokens(self.core_memory.to_context_string()))

        logger.debug(
            "[tokens] turn=%d  total=%d  threshold=%d",
            turn_id, total,
            int(self.context_window * COMPRESS_THRESHOLD),
        )
        if total >= self.context_window * COMPRESS_THRESHOLD:
            logger.info("[compress] triggered at turn=%d  total_tokens=%d", turn_id, total)
            self._compress_old_turns(turn_id)

    def _compress_old_turns(self, turn_id: int):
        """
        In-place compression of old history turns (triggered at 50% context window).
        Old turns replaced with a structured summary in _history.
        Keeps last verbatim_tail turns intact for quality.
        """
        tail_size = self.verbatim_tail * 2  # user+assistant pairs
        if len(self._history) <= tail_size:
            return

        old = self._history[:-tail_size]
        tail = self._history[-tail_size:]

        combined_text = "\n".join(
            f"{m['role']}: {m.get('content', '')}" for m in old
        )
        summary = self.compressor.compress_for_session_context(combined_text)

        summary_msg = {
            "role": "system",
            "content": f"[Conversation Summary]\n{summary}",
            "_is_summary": True,
        }
        self._history = [summary_msg] + tail
        self._compress_pending = True  # history rebuilt → next persist must do full resync

        threading.Thread(
            target=self._run_judge, args=(summary,), daemon=True
        ).start()

        logger.info(
            "[compress] done  old_msgs=%d → summary  tail_kept=%d  summary=%r",
            len(old), len(tail) // 2, summary[:80],
        )

    # ------------------------------------------------------------------
    # Session persistence (single-session continuity across restarts)
    # ------------------------------------------------------------------

    def _init_session_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS active_session (
                    seq INTEGER PRIMARY KEY,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    is_summary INTEGER DEFAULT 0,
                    created_at REAL NOT NULL
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS metadata (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                )
            """)

    @staticmethod
    def _serialize_content(content) -> str:
        """Serialize content to string for SQLite storage."""
        if isinstance(content, (list, dict)):
            import json as _json
            return _json.dumps(content, ensure_ascii=False)
        return content or ""

    @staticmethod
    def _deserialize_content(content: str):
        """Deserialize content from SQLite — restore list/dict if JSON."""
        import json as _json
        try:
            parsed = _json.loads(content)
            if isinstance(parsed, (list, dict)):
                return parsed
        except (ValueError, TypeError):
            pass
        return content

    def _restore_history(self):
        """Load persisted _history from DB on startup."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT role, content, is_summary FROM active_session ORDER BY seq"
            ).fetchall()
        for role, content, is_summary in rows:
            msg = {"role": role, "content": self._deserialize_content(content)}
            if is_summary:
                msg["_is_summary"] = True
            self._history.append(msg)
        self._persisted_seq = len(self._history)  # already in DB
        if self._history:
            self._turn_count = sum(
                1 for m in self._history
                if m["role"] == "user" and not m.get("_is_summary")
            )
            logger.info(
                "[session] restored history from DB: %d msgs, ~%d turns",
                len(self._history), self._turn_count,
            )

    def _persist_history(self):
        """Incrementally persist new history rows; full resync only after compression."""
        now = time.time()
        with sqlite3.connect(self.db_path) as conn:
            if self._compress_pending:
                # Compression rebuilt _history from scratch — full resync required
                conn.execute("DELETE FROM active_session")
                conn.executemany(
                    "INSERT INTO active_session (seq, role, content, is_summary, created_at) VALUES (?, ?, ?, ?, ?)",
                    [
                        (seq, msg["role"], self._serialize_content(msg["content"]),
                         1 if msg.get("_is_summary") else 0, now)
                        for seq, msg in enumerate(self._history)
                    ],
                )
                self._persisted_seq = len(self._history)
                self._compress_pending = False
            else:
                # Incremental: only append rows that aren't in DB yet
                new_msgs = self._history[self._persisted_seq:]
                if new_msgs:
                    conn.executemany(
                        "INSERT INTO active_session (seq, role, content, is_summary, created_at) VALUES (?, ?, ?, ?, ?)",
                        [
                            (self._persisted_seq + i, msg["role"], self._serialize_content(msg["content"]),
                             1 if msg.get("_is_summary") else 0, now)
                            for i, msg in enumerate(new_msgs)
                        ],
                    )
                    self._persisted_seq = len(self._history)

    def _run_judge(self, text: str):
        """
        Passive judge: extract core memory facts from text.
        Only called at compression events and session end.
        """
        try:
            written = self.core_memory.judge_and_update(text)
            for e in written:
                logger.info("[core] judge wrote  key=%r  dim=%s  value=%r",
                            e["key"], e.get("dimension"), e["value"][:60])
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def _load_session_count(self) -> int:
        with sqlite3.connect(self.db_path) as conn:
            row = conn.execute(
                "SELECT value FROM metadata WHERE key='session_count'"
            ).fetchone()
        return int(row[0]) if row else 0

    def _save_session_count(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT OR REPLACE INTO metadata (key, value) VALUES ('session_count', ?)",
                (str(self._session_count),),
            )

    def end_session(self):
        """
        Call when a session ends.
        Saves session summary to recent_memory, runs passive judge, then resets.
        """
        self._session_count += 1
        self._save_session_count()

        if self._session_count % 5 == 0:
            threading.Thread(
                target=self._run_consolidation, daemon=True
            ).start()

        if self._history:
            summary_blocks = [m["content"] for m in self._history if m.get("_is_summary")]

            verbatim_msgs = [m for m in self._history if not m.get("_is_summary")]
            if verbatim_msgs:
                verbatim_text = "\n".join(
                    f"{m['role']}: {m.get('content', '')}" for m in verbatim_msgs
                )
                tail_summary = self.compressor.compress_for_session_context(verbatim_text)
                summary_blocks.append(tail_summary)

            if summary_blocks:
                combined_summary = "\n\n".join(summary_blocks)
                self.recent_memory.add(
                    turn_id=self._turn_count,
                    compressed_content=combined_summary,
                )
                logger.info(
                    "[session] saved to recent_memory  turn=%d  blocks=%d",
                    self._turn_count, len(summary_blocks),
                )

            if verbatim_msgs:
                remaining = "\n".join(
                    f"{m['role']}: {m.get('content', '')}" for m in verbatim_msgs
                )
                self._run_judge(remaining)

        # Keep last N verbatim messages so the next session can resume with context
        verbatim_tail = [m for m in self._history if not m.get("_is_summary")]
        kept = verbatim_tail[-self.keep_verbatim_on_end:] if self.keep_verbatim_on_end > 0 else []

        self._history = kept
        self._turn_count = sum(1 for m in kept if m["role"] == "user")
        self._last_context_tokens = 0
        self._compress_pending = True  # force full resync with kept tail
        self._persisted_seq = 0
        self._persist_history()

    def _run_consolidation(self):
        try:
            self.consolidation.run()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Convenience: direct core memory write (user-triggered)
    # ------------------------------------------------------------------

    def remember(self, key: str, value: str, dimension: str = "preferences"):
        """User-triggered: 'remember this'. Synchronous write to core memory."""
        self.core_memory.set(key, value, dimension=dimension, stability=50.0)

    # ------------------------------------------------------------------
    # Conversation navigation
    # ------------------------------------------------------------------

    def list_turns(self) -> list[dict]:
        """
        Return a list of verbatim user turns in the current session.
        Each item: {"index": int, "user": str, "assistant": str, "in_summary": False}
        Compressed (summarised) turns are excluded — they can't be rewound to.
        """
        verbatim = [m for m in self._history if not m.get("_is_summary")]
        turns = []
        i = 0
        while i < len(verbatim):
            msg = verbatim[i]
            if msg["role"] == "user":
                user_text = msg["content"] if isinstance(msg["content"], str) else str(msg["content"])
                assistant_text = ""
                if i + 1 < len(verbatim) and verbatim[i + 1]["role"] == "assistant":
                    assistant_text = verbatim[i + 1]["content"]
                    i += 2
                else:
                    i += 1
                turns.append({
                    "index": len(turns),
                    "user": user_text[:120],
                    "assistant": assistant_text[:120] if isinstance(assistant_text, str) else "",
                })
            else:
                i += 1
        return turns

    def rewind_to(self, turn_index: int):
        """
        Rewind conversation to just after the Nth user turn (0-indexed).
        Discards all messages after that turn and re-persists to DB.
        Raises IndexError if turn_index is out of range.
        """
        turns = self.list_turns()
        if not turns:
            raise IndexError("No turns to rewind to")
        if turn_index < 0 or turn_index >= len(turns):
            raise IndexError(f"Turn {turn_index} out of range (0–{len(turns) - 1})")

        # Identify cut point in verbatim messages
        verbatim = [m for m in self._history if not m.get("_is_summary")]
        summaries = [m for m in self._history if m.get("_is_summary")]

        # Walk verbatim to find end of target turn (user + optional assistant)
        user_count = -1
        cut = 0
        i = 0
        while i < len(verbatim):
            msg = verbatim[i]
            if msg["role"] == "user":
                user_count += 1
                cut = i + 1  # include this user message
                if i + 1 < len(verbatim) and verbatim[i + 1]["role"] == "assistant":
                    cut = i + 2  # include assistant response too
                    i += 2
                else:
                    i += 1
                if user_count == turn_index:
                    break
            else:
                i += 1

        new_verbatim = verbatim[:cut]
        self._history = summaries + new_verbatim
        self._turn_count = turn_index + 1

        # Force full DB resync
        self._compress_pending = True
        self._persist_history()
        logger.info("[rewind] rewound to turn %d, history now %d msgs", turn_index, len(self._history))
