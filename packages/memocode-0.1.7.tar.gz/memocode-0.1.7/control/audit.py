"""
Audit log: persists every agent run to SQLite for traceability and rollback.
"""
from __future__ import annotations
import json
import os
import sqlite3
import time


class AuditLog:
    def __init__(self, db_path: str):
        self.db_path = db_path
        self._init_db()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._conn() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS audit_runs (
                    id         INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts         REAL    NOT NULL,
                    project    TEXT    NOT NULL DEFAULT '',
                    user_input TEXT    NOT NULL,
                    goal       TEXT    NOT NULL,
                    tasks      TEXT    NOT NULL,
                    success    INTEGER NOT NULL,
                    log        TEXT    NOT NULL,
                    backups    TEXT    NOT NULL DEFAULT '{}'
                )
            """)
            # Migrate: add project column if missing (existing DBs)
            try:
                conn.execute("ALTER TABLE audit_runs ADD COLUMN project TEXT NOT NULL DEFAULT ''")
            except Exception:
                pass

    def record(
        self,
        user_input: str,
        goal: str,
        tasks: list,
        success: bool,
        log: list[dict],
        project: str = "",
    ):
        """Write one completed run to the audit log."""
        backups: dict[str, str] = {}
        for entry in log:
            backups.update(entry.get("backups", {}))

        tasks_data = [
            {"id": t.id, "tool": t.tool, "args": t.args, "description": t.description}
            for t in tasks
        ]
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO audit_runs (ts, project, user_input, goal, tasks, success, log, backups) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (
                    time.time(),
                    project,
                    user_input,
                    goal,
                    json.dumps(tasks_data, ensure_ascii=False),
                    1 if success else 0,
                    json.dumps(log, ensure_ascii=False),
                    json.dumps(backups, ensure_ascii=False),
                ),
            )

    def recent(self, limit: int = 20, project: str | None = None) -> list[dict]:
        """Return most recent runs, newest first. Optionally filter by project."""
        with self._conn() as conn:
            if project is not None:
                rows = conn.execute(
                    "SELECT * FROM audit_runs WHERE project = ? ORDER BY ts DESC LIMIT ?",
                    (project, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM audit_runs ORDER BY ts DESC LIMIT ?", (limit,)
                ).fetchall()
        return [dict(r) for r in rows]

    def runs_with_backups(self, project: str | None = None) -> list[dict]:
        """Return runs that have backup files available, optionally filtered by project."""
        runs = self.recent(50, project=project)
        result = []
        for run in runs:
            backups = json.loads(run["backups"])
            available = {orig: bp for orig, bp in backups.items() if os.path.exists(bp)}
            if available:
                run["available_backups"] = available
                result.append(run)
        return result
