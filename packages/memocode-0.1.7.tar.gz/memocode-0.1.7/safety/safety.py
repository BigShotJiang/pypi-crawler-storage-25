"""
Zero-trust safety layer.

Decision engine (linear, no enumeration):
  DENY  — write to critical system path, or fork bomb structural pattern
  ALLOW — read-only operation (file_read; shell with no write indicators and no critical paths)
  SCOPE — paths found → check trusted zone:
             any critical path            → DENY
             all in trusted zone          → ALLOW (backup writes)
             any outside trusted zone     → ASK, no "always" (cross-boundary)
          no paths + write indicators     → ASK, "always" ok (uncertain write)
          no paths + no write indicators  → ALLOW (ps, echo, date, ls…)

Trusted zone = work_dir + config allowed_paths
Write indicators (structural syntax, not command names): >  >>  -i  --in-place
"""
from __future__ import annotations
import os
import re
from dataclasses import dataclass, field

# Paths where any write is catastrophic — hard deny
_CRITICAL = frozenset([
    "/", "/etc", "/bin", "/sbin", "/usr",
    "/lib", "/lib64", "/boot", "/root", "/dev",
])

# Structural write syntax (not command names)
_WRITE_RE = re.compile(r"(>{1,2}(?!=)|(?<!\w)-i\b|--in-place\b)")

# Backup triggers: destructive file ops without write syntax markers
_BACKUP_RE = re.compile(r"\b(rm|mv)\b")

# Script/interpreter execution detection
_INTERPRETER_RE = re.compile(
    r"\b(python3?|bash|sh|zsh|node|ruby|perl)\s+([\./~]\S+\.(?:py|sh|js|rb|pl|zsh|bash)|(?!-)\S+\.(?:py|sh|js|rb|pl))\b"
)

# Fork bomb structural pattern
_FORK_BOMB_RE = re.compile(r":\(\)\s*\{.*?:\s*\|\s*:.*?\}", re.DOTALL)


@dataclass
class SafetyResult:
    violation: bool
    reason: str = ""
    requires_confirmation: bool = False
    reversible: bool = True
    backup_paths: list[str] = field(default_factory=list)
    operation_class: str = ""   # key for policy memory
    can_always: bool = True     # False for cross-boundary ops
    script_path: str = ""       # set when interpreter execution detected


def _is_critical(path: str) -> bool:
    p = os.path.normpath(path)
    if p in _CRITICAL:
        return True
    return any(p.startswith(c + "/") for c in _CRITICAL if c != "/")


def _in_zone(path: str, zone: list[str]) -> bool:
    p = os.path.normpath(path)
    return any(p == z or p.startswith(z + "/") for z in zone)


def _extract_paths(command: str, work_dir: str | None = None) -> list[str]:
    """Extract absolute, ~, and relative (./ ../) paths from a shell command."""
    raw = re.findall(r"(?<!\w)(~?/[^\s\"'\\;|&><*?{}]+|\.\.?/[^\s\"'\\;|&><*?{}]+)", command)
    result = []
    for p in raw:
        if p.startswith("~") or os.path.isabs(p):
            ep = os.path.normpath(os.path.expanduser(p))
        else:
            # relative path (./foo, ../foo) — resolve against work_dir or cwd
            base = work_dir or os.getcwd()
            ep = os.path.normpath(os.path.join(base, p))
        if not ep.startswith(("/proc/", "/sys/")):
            result.append(ep)
    return result


def check(task, work_dir: str | None = None,
          allowed_paths: list[str] | None = None) -> SafetyResult:
    """
    Zero-trust check. work_dir and allowed_paths define the trusted zone.
    Returns SafetyResult describing the decision.
    """
    tool: str = getattr(task, "tool", "")

    # Build trusted zone
    zone: list[str] = []
    if work_dir:
        zone.append(os.path.normpath(work_dir))
    for p in (allowed_paths or []):
        zone.append(os.path.normpath(p))

    # ── read-only file tools: always safe ─────────────────────────────
    if tool in ("file_read", "grep", "glob"):
        return SafetyResult(violation=False, reversible=True,
                            operation_class=tool)

    # ── file_edit ──────────────────────────────────────────────────────
    if tool == "file_edit":
        raw = task.args.get("path", "")
        if raw:
            expanded = os.path.expanduser(raw)
            if not os.path.isabs(expanded):
                expanded = os.path.join(work_dir or os.getcwd(), expanded)
            path = os.path.normpath(expanded)
        else:
            path = ""
        if path and _is_critical(path):
            return SafetyResult(violation=True, reversible=False,
                                reason=f"Edit to critical path: {path}")
        backup = [path] if path and os.path.isfile(path) else []
        if zone and path and not _in_zone(path, zone):
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=False,
                reason=f"Edit outside trusted zone: {path}",
                operation_class="file_edit:outside",
            )
        return SafetyResult(violation=False, reversible=True,
                            backup_paths=backup,
                            operation_class="file_edit:zone")

    # ── file_write ─────────────────────────────────────────────────────
    if tool == "file_write":
        raw = task.args.get("path", "")
        if raw:
            expanded = os.path.expanduser(raw)
            if not os.path.isabs(expanded):
                expanded = os.path.join(work_dir or os.getcwd(), expanded)
            path = os.path.normpath(expanded)
        else:
            path = ""
        if path and _is_critical(path):
            return SafetyResult(violation=True, reversible=False,
                                reason=f"Write to critical path: {path}")
        backup = [path] if path and os.path.isfile(path) else []
        if zone and path and not _in_zone(path, zone):
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=False,
                reason=f"Write outside trusted zone: {path}",
                operation_class="file_write:outside",
            )
        return SafetyResult(violation=False, reversible=True,
                            backup_paths=backup,
                            operation_class="file_write:zone")

    # ── shell_exec ─────────────────────────────────────────────────────
    command: str = task.args.get("command", "") if hasattr(task, "args") else ""
    if not command:
        return SafetyResult(violation=False, operation_class="shell:empty")

    # Fork bomb
    if _FORK_BOMB_RE.search(command):
        return SafetyResult(violation=True, reversible=False,
                            reason="Fork bomb pattern detected")

    paths = _extract_paths(command, work_dir=work_dir)
    has_write = bool(_WRITE_RE.search(command))
    is_destructive = has_write or bool(_BACKUP_RE.search(command))

    # Write/destructive op on critical path → hard deny
    # Read on critical path → fall through to zone check (→ ASK, out of zone)
    if is_destructive and any(_is_critical(p) for p in paths):
        return SafetyResult(violation=True, reversible=False,
                            reason="Destructive operation on critical system path")

    # Glob/brace expansion in command — paths are unresolvable at check time
    if re.search(r"[*?\[\]{]", command) and is_destructive:
        return SafetyResult(
            violation=False, requires_confirmation=True,
            reversible=False, can_always=True,
            reason="Destructive operation with glob/pattern expansion (target unknown until runtime)",
            operation_class="shell:destructive:glob",
        )

    # No paths extracted
    if not paths:
        if has_write:
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=True,
                reason="Write operation with unresolvable target path",
                operation_class="shell:write:no_path",
            )
        if _BACKUP_RE.search(command):
            # rm/mv with glob or variable — can't extract target, ask
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=True,
                reason="Destructive operation with unresolvable target (glob/variable)",
                operation_class="shell:destructive:no_path",
            )
        # Reads/status commands (ps, ls, echo, date, …) — allow
        return SafetyResult(violation=False, reversible=True,
                            operation_class="shell:read")

    # Paths found — check trusted zone
    if zone:
        outside = [p for p in paths if not _in_zone(p, zone)]
        if outside:
            return SafetyResult(
                violation=False, requires_confirmation=True,
                reversible=False, can_always=False,
                reason=f"Paths outside trusted zone: {', '.join(outside)}",
                operation_class="shell:outside",
            )

    # Script/interpreter execution — show content before allowing
    m = _INTERPRETER_RE.search(command)
    if m:
        script = os.path.normpath(os.path.expanduser(m.group(2)))
        if not os.path.isabs(script) and work_dir:
            script = os.path.normpath(os.path.join(work_dir, script))
        return SafetyResult(
            violation=False, requires_confirmation=True,
            reversible=True, can_always=False,
            reason=f"Script execution: {script}",
            operation_class="shell:script",
            script_path=script,
        )

    # All paths in trusted zone (or no zone configured)
    backup_paths = paths if is_destructive else []
    op_class = "shell:write:zone" if is_destructive else "shell:read"
    return SafetyResult(violation=False, reversible=True,
                        backup_paths=backup_paths, operation_class=op_class)
