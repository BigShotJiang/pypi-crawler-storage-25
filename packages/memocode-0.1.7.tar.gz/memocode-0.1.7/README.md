# Mcode

Personal AI coding agent with memory, planning, and tool execution.

## Features

- **Interactive CLI** - Chat with the AI agent in a REPL
- **Memory System** - Persistent conversation memory with consolidation and forgetting
- **Project Management** - Manage multiple projects with separate contexts
- **Tool Execution** - Execute shell commands and file operations safely
- **Safety Controls** - Backup and rollback protection for file modifications

## Installation

```bash
pip install -e .
```

## Usage

```bash
mcode                    # Start the agent
python3 run.py           # Or run directly

# Options
--verbose                # Enable verbose output
--dry-run                # Dry run mode (no actual changes)
--project <name>         # Start with a specific project
```

## Commands

| Command | Description |
|---------|-------------|
| `/quit` | Exit the agent |
| `/end` | End session and save to memory |
| `/project list` | List all projects |
| `/project new <name>` | Create a new project |
| `/project switch <name>` | Switch to a project |
| `/profile set <key> <value>` | Set a profile entry |
| `!<command>` | Run shell command directly |
| `@<path>` | Attach file contents to message |

## Project Structure

```
mcode/
├── run.py              # Main entry point
├── control/            # Core agent logic
│   ├── brain.py        # Main brain logic
│   ├── planner.py      # Planning module
│   ├── llm.py          # LLM interface
│   ├── project_manager.py
│   ├── audit.py        # Audit logging
│   ├── fmt.py          # Formatting
│   └── chatmem/        # Memory system
├── tools/              # Tool implementations
│   ├── file.py         # File operations
│   ├── shell.py        # Shell commands
│   └── registry.py     # Tool registry
└── safety/             # Safety features
    ├── backup.py       # Backup system
    └── policy.py       # Safety policies
```

## Requirements

- Python 3.11+
- openai
- rich
- prompt_toolkit
