// io_utils.rs
use anyhow::Result;
use serde::{Serialize, de::DeserializeOwned};
use std::fs;

pub fn save_bin<T: Serialize>(path: &str, value: &T) -> Result<()> {
    let bytes = bincode::serialize(value)?;
    if let Some(parent) = std::path::Path::new(path).parent() {
        if !parent.as_os_str().is_empty() { fs::create_dir_all(parent)?; }
    }
    fs::write(path, &bytes)?;
    Ok(())
}

pub fn load_bin<T: DeserializeOwned>(path: &str) -> Result<T> {
    let bytes = fs::read(path)?;
    Ok(bincode::deserialize(&bytes)?)
}
