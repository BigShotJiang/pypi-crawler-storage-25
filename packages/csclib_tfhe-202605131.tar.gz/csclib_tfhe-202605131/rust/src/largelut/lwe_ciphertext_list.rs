use tfhe::core_crypto::prelude::*;

use crate::{algorithms::TFHE_PARAMS, largelut::calibration_method::LargeLUT};
//use crate::largelut::calibration_method::PublicParams;


/* 
pub fn lwe_ciphertext_vec_to_lwe_ciphertext_list(public_params: &LargeLUT, lwe_ciphertext_vec: &Vec<LweCiphertextOwned<u64>>) -> LweCiphertextListOwned<u64> {
    let mut lwe_ciphertext_list = LweCiphertextList::new(
        0u64,
        LweSize(public_params.parameter_set.polynomial_size.0 + 1),
        LweCiphertextCount(lwe_ciphertext_vec.len()),
        public_params.parameter_set.ciphertext_modulus,
    );
    for i in 0..lwe_ciphertext_vec.len() {
        for j in 0..public_params.parameter_set.polynomial_size.0+1 {
            lwe_ciphertext_list.as_mut()[i*(public_params.parameter_set.polynomial_size.0+1)+j] = lwe_ciphertext_vec[i].as_ref()[j];
        }
    }
    return lwe_ciphertext_list;
}
*/

// pub fn lwe_ciphertext_list_to_lwe_ciphertext_vec<Scalar>(lwe_ciphertext_list: &LweCiphertextListOwned<u64>) -> Vec<LweCiphertext<Scalar>> {
//     let mut lwe_ciphertext_vec: Vec<LweCiphertext<Vec<Scalar>>> = Vec::new();
//     let polynomial_size = PARAMS.polynomial_size();
//     let ciphertext_modulus = PARAMS.ciphertext_modulus();
//     for i in 0..lwe_ciphertext_list.ciphertext_count().0 {
//         let mut lwe_ciphertext = LweCiphertext::new(
//             Scalar::ZERO,
//             LweSize(polynomial_size.0 + 1),
//             ciphertext_modulus,
//         );
//         for j in 0..polynomial_size.0+1 {
//             lwe_ciphertext.as_mut()[j] = lwe_ciphertext_list.as_ref()[i*(polynomial_size.0+1)+j];
//         }
//         lwe_ciphertext_vec.push(lwe_ciphertext);
//     }


//     // let mut input_ciphertext_chunk_vec: Vec<LweCiphertext<Vec<Scalar>>> = Vec::new();
//             // for i in 0..input_ciphertext_list_chunk.lwe_ciphertext_count().0 {
//             //     let mut input_ciphertext_chunk_i = LweCiphertext::new(
//             //         Scalar::ZERO,
//             //         input_ciphertext_list_chunk.lwe_size(),
//             //         input_ciphertext_list_chunk.ciphertext_modulus(),
//             //     );
//             //     for j in 0..input_ciphertext_list_chunk.lwe_size().0 {
//             //         input_ciphertext_chunk_i.as_mut()[j] = input_ciphertext_list_chunk.as_ref()[i * input_ciphertext_list_chunk.lwe_size().0 + j];
//             //     }
//             //     input_ciphertext_chunk_vec.push(input_ciphertext_chunk_i);
//             // }

//     return lwe_ciphertext_vec;
// }

pub fn lwe_ciphertext_vec_to_lwe_ciphertext_list(/*public_params: &LargeLUT,*/ lwe_ciphertext_vec: &Vec<LweCiphertextOwned<u64>>) -> LweCiphertextListOwned<u64> {
TFHE_PARAMS.with(|params| {
    //let parameter_set = params.borrow();
    let parameter_set = params;
    let mut lwe_ciphertext_list = LweCiphertextList::new(
        0u64,
        LweSize(parameter_set.polynomial_size.0 + 1),
        LweCiphertextCount(lwe_ciphertext_vec.len()),
        parameter_set.ciphertext_modulus,
    );
    for i in 0..lwe_ciphertext_vec.len() {
        for j in 0..parameter_set.polynomial_size.0+1 {
            lwe_ciphertext_list.as_mut()[i*(parameter_set.polynomial_size.0+1)+j] = lwe_ciphertext_vec[i].as_ref()[j];
        }
    }
    lwe_ciphertext_list
})
}
