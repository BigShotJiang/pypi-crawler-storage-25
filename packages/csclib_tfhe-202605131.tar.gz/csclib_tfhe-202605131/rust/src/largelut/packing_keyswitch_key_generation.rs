use tfhe::core_crypto::prelude::*;
//use tfhe::core_crypto::commons::math::decomposition::{DecompositionLevel, DecompositionTerm};
use tfhe::core_crypto::commons::math::decomposition::{DecompositionLevel};
use tfhe::core_crypto::commons::math::random::{Distribution, Uniform};

use crate::algorithms::{TFHE_PARAMS, TfheParam};
use crate::largelut::ioutils::*;
use crate::largelut::basic::ENCRYPTION_GENERATOR;
//use crate::print;
use std::path::Path;
use crate::largelut::basic::MyDecompositionTerm as DecompositionTerm;
//use crate::largelut::calibration_method::PublicParams;

use crate::algorithms::blog;

pub fn negacyclic_index_and_sign_usize(i: usize, k: i64, n: usize) -> (usize, i32) {
    let t = i as i64 + k;
    let q = t.div_euclid(n as i64);           // wrap 回数（負でもOK）
    let r = t.rem_euclid(n as i64) as usize;  // 0..N-1
    let sign = if (q & 1) == 0 { 1 } else { -1 };
    (r, sign)
}



pub fn allocate_and_generate_new_lwe_packing_keyswitch_key_prefixsum<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    decomp_base_log: DecompositionBaseLog,
    decomp_level_count: DecompositionLevelCount,
    noise_distribution: NoiseDistribution,
    ciphertext_modulus: CiphertextModulus<Scalar>,
    generator: &mut EncryptionRandomGenerator<Gen>,
    ohe_size: usize,
) -> LwePackingKeyswitchKeyOwned<Scalar>
where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    let mut new_lwe_packing_keyswitch_key = LwePackingKeyswitchKeyOwned::new(
        Scalar::ZERO,
        decomp_base_log,
        decomp_level_count,
        input_lwe_sk.lwe_dimension(),
        output_glwe_sk.glwe_dimension(),
        output_glwe_sk.polynomial_size(),
        ciphertext_modulus,
    );

    generate_lwe_packing_keyswitch_key_prefixsum(
        input_lwe_sk,
        output_glwe_sk,
        &mut new_lwe_packing_keyswitch_key,
        noise_distribution,
        generator,
        ohe_size,
    );

    new_lwe_packing_keyswitch_key
}


pub fn generate_lwe_packing_keyswitch_key_prefixsum<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    KSKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    lwe_packing_keyswitch_key: &mut LwePackingKeyswitchKey<KSKeyCont>,
    noise_distribution: NoiseDistribution,
    generator: &mut EncryptionRandomGenerator<Gen>,
    ohe_size: usize,
) where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    KSKeyCont: ContainerMut<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    assert!(
        lwe_packing_keyswitch_key.input_key_lwe_dimension() == input_lwe_sk.lwe_dimension(),
        "The destination LwePackingKeyswitchKey input LweDimension is not equal \
    to the input LweSecretKey LweDimension. Destination: {:?}, input: {:?}",
        lwe_packing_keyswitch_key.input_key_lwe_dimension(),
        input_lwe_sk.lwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_glwe_dimension() == output_glwe_sk.glwe_dimension(),
        "The destination LwePackingKeyswitchKey output LweDimension is not equal \
    to the output GlweSecretKey GlweDimension. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_glwe_dimension(),
        output_glwe_sk.glwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_polynomial_size() == output_glwe_sk.polynomial_size(),
        "The destination LwePackingKeyswitchKey output PolynomialSize is not equal \
        to the output GlweSecretKey PolynomialSize. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_polynomial_size(),
        output_glwe_sk.polynomial_size()
    );

    let decomp_base_log = lwe_packing_keyswitch_key.decomposition_base_log();
    let decomp_level_count = lwe_packing_keyswitch_key.decomposition_level_count();
    let polynomial_size = lwe_packing_keyswitch_key.output_polynomial_size();
    let ciphertext_modulus = lwe_packing_keyswitch_key.ciphertext_modulus();
    assert!(ciphertext_modulus.is_compatible_with_native_modulus());

    // The plaintexts used to encrypt a key element will be stored in this buffer
    let mut decomposition_plaintexts_buffer = PlaintextListOwned::new(
        Scalar::ZERO,
        PlaintextCount(decomp_level_count.0 * polynomial_size.0),
    );

    // 新実装
    let box_size = polynomial_size.0 / ohe_size;


    for (element_index, mut packing_keyswitch_key_block) in lwe_packing_keyswitch_key.iter_mut().enumerate() {
    for (level, mut messages) in (1..=decomp_level_count.0)
        .map(DecompositionLevel)
        .rev()
        .zip(decomposition_plaintexts_buffer.chunks_exact_mut(polynomial_size.0))
    {
        // まず全係数ゼロ
        for c in messages.iter_mut() {
            *c.0 = Scalar::ZERO;
        }
        // for j in 0..polynomial_size.0 {
        //     let p_j =  (j as u64) / b_arr[l];
        //     let t_j: u64 = ((2 * p_j + 1) * b_arr[l-1]) / 2;
        //     let (idx, sign) = negacyclic_index_and_sign(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
        //     let sk_elem = input_lwe_sk.as_ref()[idx];


        //     let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
        //         .to_recomposition_summand()
        //         .wrapping_div(
        //             ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
        //         );


        //     // nega-cyclic の符号（奇数回 wrap → 負）
        //     if sign < 0 {
        //         val = val.wrapping_neg();
        //     }
        //     *messages.get_mut(j).0 = val; // X^j の係数へ
        // }
        for j in 0..ohe_size {
            let extracted_degree_j = (box_size as f64 / 2 as f64).ceil() as usize + j*box_size - 1;
            for k in j+1..ohe_size {
                for l in 0..box_size {
                    let (idx, sign) = negacyclic_index_and_sign_usize(element_index, extracted_degree_j as i64, input_lwe_sk.lwe_dimension().0);
                    let sk_elem = input_lwe_sk.as_ref()[idx];


                    let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                        .to_recomposition_summand()
                        .wrapping_div(
                            ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                        );


                    // nega-cyclic の符号（奇数回 wrap → 負）
                    if sign < 0 {
                        val = val.wrapping_neg();
                    }
                    let tmp = messages.get_mut(k*box_size+l).0.clone();
                    *messages.get_mut(k*box_size+l).0 = tmp + val; // X^j の係数へ
                }
            }
        }
    }

    // 暗号化はそのまま
    encrypt_glwe_ciphertext_list(
        output_glwe_sk,
        &mut packing_keyswitch_key_block,
        &decomposition_plaintexts_buffer,
        noise_distribution,
        generator,
    );
}


}

