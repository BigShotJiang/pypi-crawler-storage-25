use tfhe::core_crypto::prelude::*;

use crate::algorithms::{TFHE_PARAMS, lwe_decrypt_debug};
use crate::print::glwe_print;
use crate::{LargeLUTparams};
use crate::largelut::packing_keyswitch::par_keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext_with_thread_count_and_section;

pub fn rotate_left_negacyclic<T>(coeffs: &mut [T], k: usize)
where
    T: UnsignedInteger, // wrapping_neg を使うため
{
    let n = coeffs.len();
    if n == 0 { return; }
    let k = k % n;
    if k == 0 { return; }

    // 左に k 回転
    coeffs.rotate_left(k);

    // 末尾 k 個を符号反転（ネガサイクリック：前から末尾に送られた分を反転）
    for c in &mut coeffs[n - k..] {
        *c = c.wrapping_neg();
    }
}



use crate::largelut::lwe_ciphertext_list::lwe_ciphertext_vec_to_lwe_ciphertext_list;

pub fn large_ohe(public_params: &LargeLUTparams, onehot_lut: &GlweCiphertext<Vec<u64>>, calibrated_selector_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> GlweCiphertext<Vec<u64>> {

    let l = public_params.w_arr.len();

    let mut onehot_lut = onehot_lut.clone();
    //print!("input\n",);
    //glwe_print(&onehot_lut, 0, false);
    let mut calibrated_selector_keyswitched = calibrated_selector_keyswitched.clone();
TFHE_PARAMS.with(|params| {
    //let parameter_set = params.borrow();
    let parameter_set = params;
    for i in (0..l-1).rev() {
        // x_i+1 の BR
        //let x = calibrated_selector_keyswitched[i+1].as_mut().iter().next().unwrap();
        //print!("selector1 {} {:x}\n", i+1, *x);
        lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[i+1]);
        //let x = calibrated_selector_keyswitched[i+1].as_mut().iter().next().unwrap();
        //print!("selector2 {} {:x}\n", i+1, *x);
        modulus_switch_multi_bit_blind_rotate_assign(
            &calibrated_selector_keyswitched[i+1],
            &mut onehot_lut,
            &parameter_set.multi_bit_bsk,
            parameter_set.thread_count,
            //ThreadCount(1), // debug
            true,
        );
        //print!("x_{} after BR\n", i+1);
        //glwe_print(&onehot_lut, 0, false);

        //////////////////////////////////////////////////////////

        // S_i+1=(i+2)*2^{D_{i}}箇所のSE．前半は (i+1)*2^{D_{i}-1}箇所，後半は (i+3)*2^{D_{i}-1}箇所
        let mut candidate: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for j in 0..(i+2)*2_u32.pow(public_params.d_arr[i] as u32) as usize {
            let mut extracted_lwe = LweCiphertext::new(
                0u64,
                LweSize(parameter_set.polynomial_size.0 + 1),
                parameter_set.ciphertext_modulus,
            );
            extract_lwe_sample_from_glwe_ciphertext(
                    &onehot_lut,
                    &mut extracted_lwe,
                    // LUTとOHEでSEの位置が違う?
                    // MonomialDegree(j * public_params.b_arr[i+1] as usize + public_params.b_arr[i+1] as usize / 2), 
                    MonomialDegree(j * public_params.b_arr[i+1] as usize +(public_params.b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1), // original
                );
            //if j < (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize {
            if j < (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i] as usize { // debug
                
                lwe_ciphertext_opposite_assign(&mut extracted_lwe);
            }
            candidate.push(extracted_lwe);


        }
        // candidate の PKS
        let mut candidate_glwe = GlweCiphertext::new(
            0u64,
            parameter_set.glwe_dimension.to_glwe_size(),
            parameter_set.polynomial_size,
            parameter_set.ciphertext_modulus,
        );
        let candidate_list = lwe_ciphertext_vec_to_lwe_ciphertext_list(/*&public_params,*/ &candidate);
        par_keyswitch_lwe_ciphertext_list_and_pack_redundantly_in_glwe_ciphertext_with_thread_count_and_section(
            /*&public_params,*/
            &parameter_set.pksk,
            &candidate_list,
            &mut candidate_glwe,
            parameter_set.thread_count,
            LweCiphertextCount(public_params.b_arr[i] as usize),
            0,
            false        
        );
        
        //////////////////////////////////////////////////////////

        let (mut mask, mut body) = candidate_glwe.get_mut_mask_and_body();
        // マスク側（k 本の多項式）
        for mut poly in mask.as_mut_polynomial_list().iter_mut() {

            // negacyclic:
            rotate_left_negacyclic::<u64>(poly.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i] as usize);
        }

        // 本文
        rotate_left_negacyclic::<u64>(body.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i] as usize);
        onehot_lut = candidate_glwe;
        //print!("x_{} new lut\n", i+1);
        //glwe_print(&onehot_lut, 0, false);


    }
    // x_0 の BR
    //let x = calibrated_selector_keyswitched[0].as_mut().iter().next().unwrap();
    //print!("selector1 {} {:x}\n", 0, *x);
    lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[0]);
    //let x = calibrated_selector_keyswitched[0].as_mut().iter().next().unwrap();
    //print!("selector2 {} {:x}\n", 0, *x);
    //print!("selector {} {}\n", 0, lwe_decrypt_debug(&calibrated_selector_keyswitched[0]));
    modulus_switch_multi_bit_blind_rotate_assign(
        &calibrated_selector_keyswitched[0],
        &mut onehot_lut,
        &parameter_set.multi_bit_bsk,
        //public_params.thread_count,
        parameter_set.thread_count,
        //ThreadCount(1), // debug
        true,
    );
    //print!("x_0 after BR\n");
    //glwe_print(&onehot_lut, 0, false);
});

    return onehot_lut;
}


use crate::largelut::calibration_method::{make_onehot_lut, make_onehot_lut2};
use crate::largelut::calibration_method::large_lut_decomp_calibrate;
pub fn get_onehot_vector(public_params: &LargeLUTparams, message: &Vec<LweCiphertextOwned<u64>>) 
-> GlweCiphertext<Vec<u64>> {
        let ctx_onehot_vector = make_onehot_lut(&public_params);
        // let start_calibrate_time = Instant::now();
        //let message_calibrated_keyswitched = calibrate(&public_params, &message);
        let message_calibrated_keyswitched = large_lut_decomp_calibrate(&message, public_params.width, &public_params);
        // let end_calibrate_time = Instant::now();
        // print!("calibrate time:\n{:?}\n", end_calibrate_time.duration_since(start_calibrate_time));
        //let l = public_params.w_arr.len();
        let ctx_onehot_vector_result = large_ohe(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched);
        return ctx_onehot_vector_result;
}



use crate::algorithms::glwe_sample_extract;

pub fn glwe_to_vector(public_params: &LargeLUTparams, glwe: &GlweCiphertext<Vec<u64>>) 
-> Vec<LweCiphertextOwned<u64>> {

    TFHE_PARAMS.with(|param| {
        //let parameter_set = param.borrow();
        let parameter_set = param;

        let divided_box_size = (parameter_set.polynomial_size.0 as u32 / 2_u32.pow(public_params.w_arr.iter().sum())) as usize;

        let mut extracted_lwe_list: Vec<LweCiphertextOwned<u64>> = Vec::new();
        for i in 0..parameter_set.polynomial_size.0/divided_box_size {
            // SE
            let extracted_lwe = glwe_sample_extract(&glwe, (divided_box_size as f64 / 2 as f64).ceil() as usize + i*divided_box_size - 1);
            extracted_lwe_list.push(extracted_lwe);
        }
    
        extracted_lwe_list
    })
}

