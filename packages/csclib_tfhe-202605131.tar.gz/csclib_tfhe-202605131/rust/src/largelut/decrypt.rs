use tfhe::core_crypto::prelude::*;

use crate::largelut::calibration_method::LargeLUTparams;
//use keygen::*;

//use crate::largelut::calibration_method::PublicParams;

use crate::algorithms::TFHE_PARAMS;

pub fn correctness_check (public_params: &LargeLUTparams, big_lwe_sk: &LweSecretKey<Vec<u64>>, lwe: &LweCiphertextOwned<u64>, true_result: u64) {
TFHE_PARAMS.with(|param| {
    //let parameter_set = param.borrow();
    let parameter_set = param;
    let modulus = parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64;
    let delta = (1_u64 << 63) / (modulus as u64);
    let rounding_bit = delta >> 1;

    let lwe_list_plaintext: Plaintext<u64> =
        decrypt_lwe_ciphertext(&big_lwe_sk, &lwe);
    let lwe_list_result: u64 =
        //(lwe_list_plaintext.0.wrapping_add((lwe_list_plaintext.0 & rounding_bit) << 1) / delta) % public_params.parameter_set.message_modulus as u64;
        (lwe_list_plaintext.0.wrapping_add((lwe_list_plaintext.0 & rounding_bit) << 1) / delta) % modulus as u64;
    print!("{} ", lwe_list_result);
    if lwe_list_result == true_result {
        print!("correct\n");
    } else {
        print!("wrong\n");
    }
})
}

/* 
pub fn print_glwe(public_params: &LargeLUT, big_lwe_sk: &LweSecretKey<Vec<u64>>, glwe: &GlweCiphertext<Vec<u64>>, divided_box_size: usize) {
    let mut extracted_lwe_list: Vec<LweCiphertextOwned<u64>> = Vec::new();
    for i in 0..public_params.parameter_set.polynomial_size.0/divided_box_size {
        // SE
        let mut extracted_lwe = LweCiphertext::new(
            0u64,
            LweSize(public_params.parameter_set.polynomial_size.0 + 1),
            public_params.parameter_set.ciphertext_modulus,
        );
        extract_lwe_sample_from_glwe_ciphertext(
            &glwe,
            &mut extracted_lwe,
            // MonomialDegree(divided_box_size/2 + i*divided_box_size - 1),
            MonomialDegree((divided_box_size as f64 / 2 as f64).ceil() as usize + i*divided_box_size - 1),

        );
        extracted_lwe_list.push(extracted_lwe);
    }
    print_lwe_list(&public_params, &big_lwe_sk, &extracted_lwe_list);
}

pub fn print_lwe_list (public_params: &LargeLUT, big_lwe_sk: &LweSecretKey<Vec<u64>>, lwe_list: &Vec<LweCiphertextOwned<u64>>) {
    let modulus = public_params.parameter_set.message_modulus as u64 * public_params.parameter_set.carry_modulus as u64;
    let delta = (1_u64 << 63) / (modulus as u64); 
    let rounding_bit = delta >> 1;

    let arr_len = lwe_list.len();
    for i in 0..arr_len {
        let lwe_list_plaintext: Plaintext<u64> =
            decrypt_lwe_ciphertext(&big_lwe_sk, &lwe_list[i]);
        let lwe_list_result: u64 =
            //(lwe_list_plaintext.0.wrapping_add((lwe_list_plaintext.0 & rounding_bit) << 1) / delta) % public_params.parameter_set.message_modulus as u64;
            (lwe_list_plaintext.0.wrapping_add((lwe_list_plaintext.0 & rounding_bit) << 1) / delta) % modulus as u64;
        print!("{} ", lwe_list_result);
    }
    print!("\n");
}
*/

use crate::algorithms::glwe_sample_extract;
use crate::algorithms::lwe_decrypt;

pub fn decrypt_glwe_to_vector(public_params: &LargeLUTparams, /*big_lwe_sk: &LweSecretKey<Vec<u64>>,*/ glwe: &GlweCiphertext<Vec<u64>>, /*divided_box_size: usize*/) 
-> Vec<u64> {

    let length = 1 << public_params.width as usize;

TFHE_PARAMS.with(|param| {
    //let parameter_set = param.borrow();
    let parameter_set = param;

    let divided_box_size = (parameter_set.polynomial_size.0 as u32 / 2_u32.pow(public_params.w_arr.iter().sum())) as usize;
    //let delta = (1_u64 << 63) / (public_params.parameter_set.message_modulus.0 as u64 * public_params.parameter_set.carry_modulus.0 as u64); 
    //let rounding_bit = delta >> 1;

    let mut decrypt_vec: Vec<u64> = Vec::new();
    
    let mut extracted_lwe_list: Vec<LweCiphertextOwned<u64>> = Vec::new();
    //for i in 0..parameter_set.polynomial_size.0/divided_box_size {
    for i in 0..length {
        // SE
/*
        let mut extracted_lwe = LweCiphertext::new(
            0u64,
            LweSize(public_params.parameter_set.polynomial_size.0 + 1),
            public_params.parameter_set.ciphertext_modulus,
        );
        extract_lwe_sample_from_glwe_ciphertext(
            &glwe,
            &mut extracted_lwe,
            // LUTとOHEでSEの位置が違う?
            MonomialDegree((divided_box_size as f64 / 2 as f64).ceil() as usize + i*divided_box_size - 1),
            // MonomialDegree(divided_box_size/2 + i*divided_box_size),
        );
*/
        let extracted_lwe = glwe_sample_extract(&glwe, (divided_box_size as f64 / 2 as f64).ceil() as usize + i*divided_box_size - 1);
        extracted_lwe_list.push(extracted_lwe);
    }
    
    let arr_len = extracted_lwe_list.len();
    for i in 0..arr_len {
        //let lwe_list_plaintext: Plaintext<u64> =
        //    decrypt_lwe_ciphertext(&big_lwe_sk, &extracted_lwe_list[i]);
        //let lwe_list_result: u64 =
        //    (lwe_list_plaintext.0.wrapping_add((lwe_list_plaintext.0 & rounding_bit) << 1) / delta) % public_params.parameter_set.message_modulus.0 as u64;
        let lwe_list_result = lwe_decrypt(&extracted_lwe_list[i]);
        decrypt_vec.push(lwe_list_result);
    }
    decrypt_vec
})
}

