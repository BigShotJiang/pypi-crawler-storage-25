

use tfhe::core_crypto::prelude::*;
use tfhe::core_crypto::algorithms::slice_algorithms::*;
use rayon::prelude::*;

pub fn par_glwe_to_lwe<
    Scalar,
    InputCont,
    OutputCont,
>(
    input_glwe: &GlweCiphertext<InputCont>,
    output_lwe_list: &mut LweCiphertextList<OutputCont>,
    thread_count: ThreadCount,
    nth_vec: Vec<usize>,
) where
    Scalar: UnsignedInteger + Send + Sync,
    InputCont: Container<Element = Scalar> + Sync,
    OutputCont: ContainerMut<Element = Scalar>,
{
    let in_lwe_dim = input_glwe
        .glwe_size()
        .to_glwe_dimension()
        .to_equivalent_lwe_dimension(input_glwe.polynomial_size());

    let out_lwe_dim = output_lwe_list.lwe_size().to_lwe_dimension();

    assert_eq!(
        in_lwe_dim, out_lwe_dim,
        "Mismatch between equivalent LweDimension of input ciphertext and output ciphertext. \
        Got {in_lwe_dim:?} for input and {out_lwe_dim:?} for output.",
    );

    assert!(
        input_glwe.polynomial_size().0 <= output_lwe_list.lwe_ciphertext_count().0,
        "The output LweCiphertextList does not have enough space ({:?}) \
    to extract all input GlweCiphertext coefficients ({})",
        output_lwe_list.lwe_ciphertext_count(),
        input_glwe.polynomial_size().0
    );

    assert_eq!(
        input_glwe.ciphertext_modulus(),
        output_lwe_list.ciphertext_modulus(),
        "Mismatched moduli between input_glwe ({:?}) and output_lwe ({:?})",
        input_glwe.ciphertext_modulus(),
        output_lwe_list.ciphertext_modulus()
    );

    let polynomial_size = input_glwe.polynomial_size();
    let (glwe_mask, glwe_body) = input_glwe.get_mask_and_body();

    let thread_count = thread_count.0.min(rayon::current_num_threads());
    let chunk_size = polynomial_size.0.div_ceil(thread_count);

    glwe_body
        .as_ref()
        .par_chunks(chunk_size)
        .zip(output_lwe_list.par_chunks_mut(chunk_size))
        .enumerate()
        .for_each(
            |(chunk_idx, (glwe_body_chunk, mut output_lwe_list_chunk))| {
                for (coeff_idx, (glwe_coeff, mut output_lwe)) in glwe_body_chunk
                    .iter()
                    .zip(output_lwe_list_chunk.iter_mut())
                    .enumerate()
                {
                    
                    let nth = chunk_idx * chunk_size + coeff_idx;
                    if nth_vec.contains(&nth) == false {
                        continue;
                    }
                    // print!("nth: {}\n", nth);

                    let (mut lwe_mask, lwe_body) = output_lwe.get_mut_mask_and_body();

                    // We copy the body
                    *lwe_body.data = *glwe_coeff;

                    // We copy the mask (each polynomial is in the wrong order)
                    lwe_mask.as_mut().copy_from_slice(glwe_mask.as_ref());

                    // We compute the number of elements which must be
                    // turned into their opposite
                    let opposite_count = input_glwe.polynomial_size().0 - nth - 1;
                    let ciphertext_modulus = input_glwe.ciphertext_modulus();

                    if ciphertext_modulus.is_compatible_with_native_modulus() {
                        // We loop through the polynomials
                        for lwe_mask_poly in lwe_mask
                            .as_mut()
                            .chunks_exact_mut(input_glwe.polynomial_size().0)
                        {
                            // We reverse the polynomial
                            lwe_mask_poly.reverse();
                            // We compute the opposite of the proper coefficients
                            slice_wrapping_opposite_assign(&mut lwe_mask_poly[0..opposite_count]);
                            // We rotate the polynomial properly
                            lwe_mask_poly.rotate_left(opposite_count);
                        }
                    } else {
                        let modulus: Scalar = ciphertext_modulus.get_custom_modulus().cast_into();
                        // We loop through the polynomials
                        for lwe_mask_poly in lwe_mask
                            .as_mut()
                            .chunks_exact_mut(input_glwe.polynomial_size().0)
                        {
                            // We reverse the polynomial
                            lwe_mask_poly.reverse();
                            // We compute the opposite of the proper coefficients
                            slice_wrapping_opposite_assign_custom_mod(
                                &mut lwe_mask_poly[0..opposite_count],
                                modulus,
                            );
                            // We rotate the polynomial properly
                            lwe_mask_poly.rotate_left(opposite_count);
                        }
                    }
                }
            },
        );
}