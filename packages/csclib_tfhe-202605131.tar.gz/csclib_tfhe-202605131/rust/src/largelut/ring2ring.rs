use tfhe::core_crypto::prelude::*;
use std::time::*;

use crate::algorithms::TFHE_PARAMS;
use crate::largelut::calibration_method::*;
use crate::algorithms::*;
use crate::largelut::basic::MyDecompositionTerm as DecompositionTerm;

pub fn large_lut_ring2ring(public_params: &LargeLUTparams, large_lut: &GlweCiphertext<Vec<u64>>, message_calibrated_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> LweCiphertextOwned<u64>{
    let mut large_lut = large_lut.clone();

TFHE_PARAMS.with(|param| {
    //let parameter_set = param.borrow();
    let parameter_set = param;

    let l = public_params.w_arr.len();

    for i in 1..l {
        // message_i の BR
        let start_br = Instant::now();
        modulus_switch_multi_bit_blind_rotate_assign(
            &message_calibrated_keyswitched[i-1],
            &mut large_lut,
            &parameter_set.multi_bit_bsk,
            public_params.thread_count,
            true,
        );
        let duration_br = start_br.elapsed();
        println!("Time elapsed in BR for large lut: {:?}", duration_br);

        let start_rotate = Instant::now();
        let (mut mask, mut body) = large_lut.get_mut_mask_and_body();

        // マスク側（k 本の多項式）
        for mut poly in mask.as_mut_polynomial_list().iter_mut() {

            // negacyclic:
            rotate_right_negacyclic::<u64>(poly.as_mut(), i*(public_params.b_arr[l -1] as usize)/2);
        }

        // 本文
        rotate_right_negacyclic::<u64>(body.as_mut(), i*(public_params.b_arr[l -1] as usize)/2);
        let duration_rotate = start_rotate.elapsed();
        println!("Time elapsed in rotate for large lut: {:?}", duration_rotate);

        // if i == public_params.l -1 {
            // print!("{}-th ring2ring PKS :\n", i);
            // print_glwe(&public_params, &public_params.secret_key, &large_lut, 1);
        // }

        
        // keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
        //     &public_params,
        //     &public_params.pksk_ring2ring_arr[i-1],
        //     &large_lut.clone(),
        //     &mut large_lut,
        //     i,
        // );

        let start_pks = Instant::now();

        if l == 4 {
/*
            par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                &public_params,
                &PKSK_RING_KEY4.with(|p| {
                    let pksk_ring_key = p.borrow();
                    pksk_ring_key[i-1].clone() // 遅い!!!
                }),
            &large_lut.clone(),
            &mut large_lut,
                i,
            );
*/
            PKSK_RING_KEY4.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        } else if l == 3 {
            PKSK_RING_KEY3.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        } else if l == 2 {
            PKSK_RING_KEY2.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        } else if l == 1 {
            PKSK_RING_KEY1.with(|p| {
                let pksk_ring_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
                    &public_params,
                    &pksk_ring_key[i-1],
            &large_lut.clone(),
            &mut large_lut,
                   i,
                );
            });
        }
         
        
/* 
        par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring(
            &public_params,
            &public_params.pksk_ring2ring_arr[i-1], // ここで使うだけ
                    &large_lut.clone(),
            &mut large_lut,
            i,
        );
*/
        let duration_pks = start_pks.elapsed();
        println!("Time elapsed in PKS for large lut: {:?}", duration_pks);




        // print_glwe(&public_params, &public_params.secret_key, &large_lut, 1);


        
    }

    let start_br = Instant::now();
    // message_L-1 の BR
    modulus_switch_multi_bit_blind_rotate_assign(
        &message_calibrated_keyswitched[l-1],
        &mut large_lut,
        &parameter_set.multi_bit_bsk,
        public_params.thread_count,
        true,
    );
    let duration_br = start_br.elapsed();
    println!("Time elapsed in BR for large lut (L-1): {:?}", duration_br);

    // let (mut mask, mut body) = large_lut.get_mut_mask_and_body();

    // // マスク側（k 本の多項式）
    // for mut poly in mask.as_mut_polynomial_list().iter_mut() {

    //     // negacyclic:
    //     rotate_right_negacyclic::<u64>(poly.as_mut(), public_params.l*(public_params.b_arr[public_params.l -1] as usize)/2);
    // }

    // // 本文
    // rotate_right_negacyclic::<u64>(body.as_mut(), public_params.l*(public_params.b_arr[public_params.l -1] as usize)/2);

    // SE
    let mut z = LweCiphertext::new(
        0u64,
        LweSize(parameter_set.polynomial_size.0 + 1),
        parameter_set.ciphertext_modulus,
    );
    extract_lwe_sample_from_glwe_ciphertext(
        &large_lut,
        &mut z,
        MonomialDegree(public_params.b_arr[l -1] as usize / 2),
    );
    // extract_lwe_sample_from_glwe_ciphertext(
    //     &large_lut,
    //     &mut z,
    //     MonomialDegree(public_params.b_arr[public_params.l -1] as usize / 2 + public_params.b_arr[public_params.l -1] as usize * ((public_params.l-1)/2) * (1u64 << public_params.w_arr[public_params.l -1]) as usize),
    // );
    return z;
})
}

pub fn compute_ring2ringkeys(parameter_set: &TfheParam, s_arr: &Vec<u64>, b_arr: &Vec<u64>, l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    let pksk_slice: &[u64] = parameter_set.pksk.as_ref();

    let server_side_key_computing = false;
    let mut pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new(); // 今回は使わないので空でOK
/*
        pksk_ring2ring_arr = load_bin(
            &format!("../../keygen/keys/pksk_ring2ring_{}_{}.bin", parameter_set.message_modulus.0, l)
        ).unwrap();
        pksk_ring2ring_onehot_encode_arr = load_bin(
            &format!("../../keygen/keys/pksk_ring2ring_onehot_encode_{}_{}.bin", parameter_set.message_modulus.0, l)
        ).unwrap();
 */
        pksk_ring2ring_arr = generate_ring2ring_keys(&parameter_set, l);
    return pksk_ring2ring_arr;

}

use std::cell::RefCell;
thread_local!(
    pub static PKSK_RING_KEY4: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(4);
        RefCell::new(pksk_ring2ring_arr)
    };
);
thread_local!(
    pub static PKSK_RING_KEY3: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(3);
        RefCell::new(pksk_ring2ring_arr)
    };
);
thread_local!(
    pub static PKSK_RING_KEY2: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(2);
        RefCell::new(pksk_ring2ring_arr)
    };
);
thread_local!(
    pub static PKSK_RING_KEY1: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_arr = generate_ring2ring_keys2(1);
        RefCell::new(pksk_ring2ring_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY4: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(4);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY3: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(3);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY2: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(2);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);

thread_local!(
    pub static PKSK_RING_ONEHOT_KEY1: RefCell<Vec<LwePackingKeyswitchKeyOwned<u64>>> = {
        let pksk_ring2ring_onehot_arr = generate_ring2ring_prefixsum_keys2(1);
        RefCell::new(pksk_ring2ring_onehot_arr)
    };
);


use crate::largelut::packing_keyswitch::par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode;
use crate::largelut::onehot_encode::rotate_left_negacyclic;
pub fn large_ohe_ring2ring(public_params: &LargeLUTparams, onehot_lut: &GlweCiphertext<Vec<u64>>, calibrated_selector_keyswitched: &Vec<LweCiphertextOwned<u64>>) 
-> GlweCiphertext<Vec<u64>> {

    let l = public_params.w_arr.len();

    let mut onehot_lut = onehot_lut.clone();
    let mut calibrated_selector_keyswitched = calibrated_selector_keyswitched.clone();
    for i in (0..l-1).rev() {
        // x_i+1 の BR
        lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[i+1]);
        TFHE_PARAMS.with(|params| {
            //let parameter_set = params.borrow();
            let parameter_set = params;
        modulus_switch_multi_bit_blind_rotate_assign(
            &calibrated_selector_keyswitched[i+1],
            &mut onehot_lut,
            &parameter_set.multi_bit_bsk,
            public_params.thread_count,
            true,
        );
        });

        let (mut mask, mut body) = onehot_lut.get_mut_mask_and_body();
        // マスク側（k 本の多項式）
        for mut poly in mask.as_mut_polynomial_list().iter_mut() {

            // negacyclic:
            rotate_left_negacyclic::<u64>(poly.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i+1] as usize); // 正しい
            //print!("b_arr[{i}] {} {}\n", public_params.b_arr[i],public_params.b_arr[i+1]);
            //print!("d_arr[{i}] {} {}\n", public_params.d_arr[i],public_params.d_arr[i+1]);
        }

        // 本文
        rotate_left_negacyclic::<u64>(body.as_mut(), (i+1)*2_u32.pow(public_params.d_arr[i] as u32 - 1) as usize * public_params.b_arr[i+1] as usize); // 正しい

        /////////////////////////////////////////////////////////////

        if l == 4 {
            PKSK_RING_ONEHOT_KEY4.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        } else if l == 3 {
            PKSK_RING_ONEHOT_KEY3.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        }else if l == 2 {
            PKSK_RING_ONEHOT_KEY2.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        }else if l == 1 {
            PKSK_RING_ONEHOT_KEY1.with(|p| {
                let pksk_ring_onehot_key = p.borrow();
                par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring_onehot_encode(
                    &public_params,
                    &pksk_ring_onehot_key[i],
                    &onehot_lut.clone(),
                    &mut onehot_lut,
                i,
               );
            });
        }

        /////////////////////////////////////////////////////////////


    }
    // x_0 の BR
    TFHE_PARAMS.with(|params| {
        //let parameter_set = params.borrow();
        let parameter_set = params;
        lwe_ciphertext_opposite_assign(&mut calibrated_selector_keyswitched[0]);
        modulus_switch_multi_bit_blind_rotate_assign(
            &calibrated_selector_keyswitched[0],
            &mut onehot_lut,
            &parameter_set.multi_bit_bsk,
            parameter_set.thread_count,
            true,
        );
    });


    return onehot_lut;
}

use tfhe::core_crypto::prelude::*;
use tfhe::core_crypto::commons::math::decomposition::{DecompositionLevel};
use tfhe::core_crypto::commons::math::random::{Distribution, Uniform};

pub fn allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    decomp_base_log: DecompositionBaseLog,
    decomp_level_count: DecompositionLevelCount,
    noise_distribution: NoiseDistribution,
    ciphertext_modulus: CiphertextModulus<Scalar>,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    s_arr: &Vec<u64>,
    i: usize,
) -> LwePackingKeyswitchKeyOwned<Scalar>
where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    let mut new_lwe_packing_keyswitch_key = LwePackingKeyswitchKeyOwned::new(
        Scalar::ZERO,
        decomp_base_log,
        decomp_level_count,
        input_lwe_sk.lwe_dimension(),
        output_glwe_sk.glwe_dimension(),
        output_glwe_sk.polynomial_size(),
        ciphertext_modulus,
    );

    generate_lwe_packing_keyswitch_key_ring2ring(
        input_lwe_sk,
        output_glwe_sk,
        &mut new_lwe_packing_keyswitch_key,
        noise_distribution,
        generator,
        b_arr,
        s_arr,
        i
    );

    new_lwe_packing_keyswitch_key
}

use crate::largelut::packing_keyswitch_key_generation::negacyclic_index_and_sign_usize;
use crate::largelut::packing_keyswitch::negacyclic_index_and_sign;

pub fn generate_lwe_packing_keyswitch_key_ring2ring<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    KSKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    lwe_packing_keyswitch_key: &mut LwePackingKeyswitchKey<KSKeyCont>,
    noise_distribution: NoiseDistribution,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    s_arr: &Vec<u64>,
    i: usize,
) where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    KSKeyCont: ContainerMut<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    assert!(
        lwe_packing_keyswitch_key.input_key_lwe_dimension() == input_lwe_sk.lwe_dimension(),
        "The destination LwePackingKeyswitchKey input LweDimension is not equal \
    to the input LweSecretKey LweDimension. Destination: {:?}, input: {:?}",
        lwe_packing_keyswitch_key.input_key_lwe_dimension(),
        input_lwe_sk.lwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_glwe_dimension() == output_glwe_sk.glwe_dimension(),
        "The destination LwePackingKeyswitchKey output LweDimension is not equal \
    to the output GlweSecretKey GlweDimension. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_glwe_dimension(),
        output_glwe_sk.glwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_polynomial_size() == output_glwe_sk.polynomial_size(),
        "The destination LwePackingKeyswitchKey output PolynomialSize is not equal \
        to the output GlweSecretKey PolynomialSize. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_polynomial_size(),
        output_glwe_sk.polynomial_size()
    );

    let decomp_base_log = lwe_packing_keyswitch_key.decomposition_base_log();
    let decomp_level_count = lwe_packing_keyswitch_key.decomposition_level_count();
    let polynomial_size = lwe_packing_keyswitch_key.output_polynomial_size();
    let ciphertext_modulus = lwe_packing_keyswitch_key.ciphertext_modulus();
    assert!(ciphertext_modulus.is_compatible_with_native_modulus());

    // The plaintexts used to encrypt a key element will be stored in this buffer
    let mut decomposition_plaintexts_buffer = PlaintextListOwned::new(
        Scalar::ZERO,
        PlaintextCount(decomp_level_count.0 * polynomial_size.0),
    );

    // 新実装
    //print!("b_arr={}, s_arr={}\n", b_arr.len(), s_arr.len());
    let degree_d: usize = b_arr[i] as usize * s_arr[i-1] as usize;

    for (element_index, mut packing_keyswitch_key_block) in lwe_packing_keyswitch_key.iter_mut().enumerate() {
        for (level, mut messages) in (1..=decomp_level_count.0)
            .map(DecompositionLevel)
            .rev()
            .zip(decomposition_plaintexts_buffer.chunks_exact_mut(polynomial_size.0))
        {
            // まず全係数ゼロ
            for c in messages.iter_mut() {
                *c.0 = Scalar::ZERO;
            }
            for j in 0..degree_d {
                let p_j =  (j as u64) / b_arr[i];
                // t_jは正になるはず
                // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2  + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
                let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2;
                let (idx, sign) = negacyclic_index_and_sign_usize(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
                let sk_elem = input_lwe_sk.as_ref()[idx];
                // if i == l-1 {
                //     // if element_index == 0{
                //         print!("j={}, p_j={}, t_j={}, idx={}, sign={}\n", j, p_j, t_j, idx, sign);
                //     // }
                // }

                //let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                    .to_recomposition_summand()
                    .wrapping_div(
                        ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                    );


                // nega-cyclic の符号（奇数回 wrap → 負）
                if sign < 0 {
                    val = val.wrapping_neg();
                }
                *messages.get_mut(j).0 = val; // X^j の係数へ
            }
        }

        // 暗号化はそのまま
        encrypt_glwe_ciphertext_list(
            output_glwe_sk,
            &mut packing_keyswitch_key_block,
            &decomposition_plaintexts_buffer,
            noise_distribution,
            generator,
        );
    }


}



pub fn allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring_onehot_encode<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    decomp_base_log: DecompositionBaseLog,
    decomp_level_count: DecompositionLevelCount,
    noise_distribution: NoiseDistribution,
    ciphertext_modulus: CiphertextModulus<Scalar>,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    //s_arr: &Vec<u64>,
    d_arr: &Vec<u64>,
    i: usize,
) -> LwePackingKeyswitchKeyOwned<Scalar>
where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    let mut new_lwe_packing_keyswitch_key = LwePackingKeyswitchKeyOwned::new(
        Scalar::ZERO,
        decomp_base_log,
        decomp_level_count,
        input_lwe_sk.lwe_dimension(),
        output_glwe_sk.glwe_dimension(),
        output_glwe_sk.polynomial_size(),
        ciphertext_modulus,
    );

    generate_lwe_packing_keyswitch_key_ring2ring_onehot_encode(
        input_lwe_sk,
        output_glwe_sk,
        &mut new_lwe_packing_keyswitch_key,
        noise_distribution,
        generator,
        b_arr,
        //s_arr, // 正しい?
        d_arr,
        i
    );

    new_lwe_packing_keyswitch_key
}


pub fn generate_lwe_packing_keyswitch_key_ring2ring_onehot_encode<
    Scalar,
    NoiseDistribution,
    InputKeyCont,
    OutputKeyCont,
    KSKeyCont,
    Gen,
>(
    input_lwe_sk: &LweSecretKey<InputKeyCont>,
    output_glwe_sk: &GlweSecretKey<OutputKeyCont>,
    lwe_packing_keyswitch_key: &mut LwePackingKeyswitchKey<KSKeyCont>,
    noise_distribution: NoiseDistribution,
    generator: &mut EncryptionRandomGenerator<Gen>,
    b_arr: &Vec<u64>,
    d_arr: &Vec<u64>,
    i: usize,
) where
    Scalar: Encryptable<Uniform, NoiseDistribution>,
    NoiseDistribution: Distribution,
    InputKeyCont: Container<Element = Scalar>,
    OutputKeyCont: Container<Element = Scalar>,
    KSKeyCont: ContainerMut<Element = Scalar>,
    Gen: ByteRandomGenerator,
{
    assert!(
        lwe_packing_keyswitch_key.input_key_lwe_dimension() == input_lwe_sk.lwe_dimension(),
        "The destination LwePackingKeyswitchKey input LweDimension is not equal \
    to the input LweSecretKey LweDimension. Destination: {:?}, input: {:?}",
        lwe_packing_keyswitch_key.input_key_lwe_dimension(),
        input_lwe_sk.lwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_glwe_dimension() == output_glwe_sk.glwe_dimension(),
        "The destination LwePackingKeyswitchKey output LweDimension is not equal \
    to the output GlweSecretKey GlweDimension. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_glwe_dimension(),
        output_glwe_sk.glwe_dimension()
    );
    assert!(
        lwe_packing_keyswitch_key.output_key_polynomial_size() == output_glwe_sk.polynomial_size(),
        "The destination LwePackingKeyswitchKey output PolynomialSize is not equal \
        to the output GlweSecretKey PolynomialSize. Destination: {:?}, output: {:?}",
        lwe_packing_keyswitch_key.output_key_polynomial_size(),
        output_glwe_sk.polynomial_size()
    );

    let decomp_base_log = lwe_packing_keyswitch_key.decomposition_base_log();
    let decomp_level_count = lwe_packing_keyswitch_key.decomposition_level_count();
    let polynomial_size = lwe_packing_keyswitch_key.output_polynomial_size();
    let ciphertext_modulus = lwe_packing_keyswitch_key.ciphertext_modulus();
    assert!(ciphertext_modulus.is_compatible_with_native_modulus());

    // The plaintexts used to encrypt a key element will be stored in this buffer
    let mut decomposition_plaintexts_buffer = PlaintextListOwned::new(
        Scalar::ZERO,
        PlaintextCount(decomp_level_count.0 * polynomial_size.0),
    );

    // 新実装


    for (element_index, mut packing_keyswitch_key_block) in lwe_packing_keyswitch_key.iter_mut().enumerate() {
    for (level, mut messages) in (1..=decomp_level_count.0)
        .map(DecompositionLevel)
        .rev()
        .zip(decomposition_plaintexts_buffer.chunks_exact_mut(polynomial_size.0))
    {
        // まず全係数ゼロ
        for c in messages.iter_mut() {
            *c.0 = Scalar::ZERO;
        }
        // for j in 0..degree_d {
        //     let p_j =  (j as u64) / b_arr[i];
        //     // t_jは正になるはず
        //     // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2  + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
        //     let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2;
        //     let (idx, sign) = negacyclic_index_and_sign(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
        //     let sk_elem = input_lwe_sk.as_ref()[idx];

        //     let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
        //         .to_recomposition_summand()
        //         .wrapping_div(
        //             ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
        //         );


        //     // nega-cyclic の符号（奇数回 wrap → 負）
        //     if sign < 0 {
        //         val = val.wrapping_neg();
        //     }
        //     *messages.get_mut(j).0 = val; // X^j の係数へ
        // }
        //for j in 0..((i+3)*2_u32.pow(d_arr[i] as u32 - 1) as usize) {
        for j in 0..((i+3)*(1<<(d_arr[i] as u32 - 1)) as usize) {
            //print!("i={}, d_arr[i]={} j={}\n", i, d_arr[i], j);
            let t_j = j * b_arr[i+1] as usize +(b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1;
            for k in 0..b_arr[i] as usize {
                let (idx, sign) = negacyclic_index_and_sign_usize(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
                let sk_elem = input_lwe_sk.as_ref()[idx];


                let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                    .to_recomposition_summand()
                    .wrapping_div(
                        ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                );


                // nega-cyclic の符号（奇数回 wrap → 負）
                if sign < 0 {
                    val = val.wrapping_neg();
                }
                *messages.get_mut(j*b_arr[i] as usize + k).0 = val; // X^j の係数へ
            }
        }

        for j in 0..((i+1)*2_u32.pow(d_arr[i] as u32 - 1) as usize) {
            let t_j = polynomial_size.0 + (j - (i+1)*2_u32.pow(d_arr[i] as u32 - 1) as usize) * b_arr[i+1] as usize +(b_arr[i+1] as f64 / 2 as f64).ceil() as usize  - 1;
            for k in 0..b_arr[i] as usize {
                let (idx, sign) = negacyclic_index_and_sign_usize(element_index, t_j as i64, input_lwe_sk.lwe_dimension().0);
                let sk_elem = input_lwe_sk.as_ref()[idx];


                let mut val = DecompositionTerm::new(level, decomp_base_log, sk_elem)
                    .to_recomposition_summand()
                    .wrapping_div(
                        ciphertext_modulus.get_power_of_two_scaling_to_native_torus()
                );


                // nega-cyclic の符号（奇数回 wrap → 負）
                if sign < 0 {
                    val = val.wrapping_neg();
                }
                *messages.get_mut(polynomial_size.0 + (j - (i+1)*2_u32.pow(d_arr[i] as u32 - 1) as usize) * b_arr[i] as usize + k).0 = val; // X^j の係数へ
            }
        }
    }

    // 暗号化はそのまま
    encrypt_glwe_ciphertext_list(
        output_glwe_sk,
        &mut packing_keyswitch_key_block,
        &decomposition_plaintexts_buffer,
        noise_distribution,
        generator,
    );
}


}

use std::path::Path;
use crate::largelut::calibration_method::compute_arrays;
pub fn generate_ring2ring_keys(parameter_set: &TfheParam, l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;

    if l == 1 {
        let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, 1);
        let path = Path::new(&s);
        let pksk_ring2ring_arr =
        if path.is_file() == false {
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new();
            save_bin(&s, &pksk_ring2ring_arr).unwrap();

            pksk_ring2ring_arr
        } else {
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();

            pksk_ring2ring_arr            
        };
        return pksk_ring2ring_arr
    }

    let w = (blog(modulus-1)+1) as u32;
    //let delta = (1_u64 << 63) / (parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64);
    //let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);
    let limit = ((1u64 << w) - 1).min((blog(parameter_set.polynomial_size.0 as u64 -1)+1) as u64);

    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    while sum <= limit && i < l as u64 {
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }


    let mut d_arr = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }


    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    // b_arr = B / 2^{D_i}
    let b_arr: Vec<u64> = d_arr
        .iter()
        .map(|&di| (parameter_set.polynomial_size.0 / modulus as usize) as u64 / (1u64 << di))
        .collect();

    // s_arr = (i+1) * 2^{D_{i-1}}  （i = 1,...,L-1）
    let s_arr: Vec<u64> = (1..w_arr.len())
        .map(|i| (i as u64 + 1) * (1u64 << d_arr[i - 1]))
        .collect();

    ENCRYPTION_GENERATOR.with(|g| {
        let mut encryption_generator = g.borrow_mut();
        let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        let x =
        if path.is_file() == false {
            print!("Generating ring2ring keys for {}...\n", l);
            //print!("b_arr={:?}, s_arr={:?}\n", b_arr, s_arr);
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = (1..l).map(|i| {
                allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring(
                    &parameter_set.big_lwe_sk,
                    &parameter_set.glwe_sk,
                    parameter_set.ks_base_log,
                    parameter_set.ks_level,
                    parameter_set.glwe_noise_distribution,
                    parameter_set.ciphertext_modulus,
                    &mut encryption_generator,
                    &b_arr,
                    &s_arr,
                    i,
                )
            }).collect();

            let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
            if save_bin(&s,&pksk_ring2ring_arr,).is_err() {
                panic!("Failed to save ring2ring keys");
            }

            pksk_ring2ring_arr
        } else {
            print!("Loading ring2ring keys for {} {}...\n", modulus, l);
            let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
            let pksk_ring2ring_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();

            pksk_ring2ring_arr
        };
        x
    })
}

pub fn generate_ring2ring_onehot_encode_keys(parameter_set: &TfheParam, l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    if l == 1 {
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, 1);
        let path = Path::new(&s);
        let pksk_ring2ring_onehot_encode_arr =
        if path.is_file() == false {
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = Vec::new();
            save_bin(&s,&pksk_ring2ring_onehot_encode_arr).unwrap();
            pksk_ring2ring_onehot_encode_arr
        } else {
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();
            pksk_ring2ring_onehot_encode_arr            
        };
        return pksk_ring2ring_onehot_encode_arr
    }

    let w = (blog(modulus-1)+1) as u32;
    //let delta = (1_u64 << 63) / (parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64);
    //let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);
    let limit = ((1u64 << w) - 1).min((blog(parameter_set.polynomial_size.0 as u64 -1)+1) as u64);

    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    while sum <= limit && i < l as u64 {
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }


    let mut d_arr = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }


    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    // b_arr = B / 2^{D_i}
    let b_arr: Vec<u64> = d_arr
        .iter()
        .map(|&di| (parameter_set.polynomial_size.0 / modulus as usize) as u64 / (1u64 << di))
        .collect();

    // s_arr = (i+1) * 2^{D_{i-1}}  （i = 1,...,L-1）
    let s_arr: Vec<u64> = (1..w_arr.len())
        .map(|i| (i as u64 + 1) * (1u64 << d_arr[i - 1]))
        .collect();

    ENCRYPTION_GENERATOR.with(|g| {
        let mut encryption_generator = g.borrow_mut();
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        let x =
        if path.is_file() == false {
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = (0..l-1).map(|i| {
                allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring_onehot_encode(
                    &parameter_set.big_lwe_sk,
                    &parameter_set.glwe_sk,
                    parameter_set.ks_base_log,
                    parameter_set.ks_level,
                    parameter_set.glwe_noise_distribution,
                    parameter_set.ciphertext_modulus,
                    &mut encryption_generator,
                    &b_arr,
                    &d_arr,
                    i,
                )
            }).collect();

            save_bin(&s,&pksk_ring2ring_onehot_encode_arr,).unwrap();
            pksk_ring2ring_onehot_encode_arr
        } else {
            print!("Loading ring2ring keys for {} {}...\n", modulus, l);
            let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l);
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = load_bin(&s).unwrap();
            pksk_ring2ring_onehot_encode_arr
        };
        x
    })
}

pub fn generate_ring2ring_keys2(l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    TFHE_PARAMS.with(|params| {
        //let parameter_set = &params.borrow();
        let parameter_set = &params;
        generate_ring2ring_keys(parameter_set, l)
    })
}

use crate::largelut::packing_keyswitch_key_generation::allocate_and_generate_new_lwe_packing_keyswitch_key_prefixsum;

pub fn generate_ring2ring_prefixsum_keys(/*parameter_set: &TfheParam,*/ l: usize) -> LwePackingKeyswitchKeyOwned<u64> {
    print!("ring2ring prefixsum key for {}...\n", l);
TFHE_PARAMS.with(|params| {
    //let parameter_set = &params.borrow();
    let parameter_set = &params;
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
    let w = (parameter_set.message_modulus as f64).log2().floor() as u32;
    //let w = (blog(modulus-1)+1) as u32;
    //let delta = (1_u64 << 63) / (parameter_set.message_modulus as u64 * parameter_set.carry_modulus as u64);
    let limit = ((1u64 << w) - 1).min((parameter_set.polynomial_size.0 as f64).log2().floor() as u64);

    let mut w_arr = Vec::new();
    let mut sum = 0u64;
    let mut i = 0u64;

    while sum <= limit && i < l as u64 {
        let wi = if i == 0 { w } else { w - 1 - (i as f64).log2().floor() as u32 };
        if wi == 0 || sum + wi as u64 > limit { break; }
        w_arr.push(wi);
        sum += wi as u64;
        i += 1;
    }


    let mut d_arr = vec![0u64; w_arr.len()]; // D_i を u64 で
    let mut acc: u64 = 0;

    for i in (0..w_arr.len()).rev() {
        d_arr[i] = acc;          // D_i = sum_{ell=i+1}^{L-1} W_ell
        acc += w_arr[i] as u64; // 次回に向けて累積
    }

    let s = format!("keys/pksk_prefixsum_{}_{}.bin", modulus, l);
    let path = Path::new(&s);
    let pksk_prefixsum = if path.is_file() == false {
        ENCRYPTION_GENERATOR.with(|g| {
            let mut encryption_generator = g.borrow_mut();
            let pksk_prefixsum: LwePackingKeyswitchKeyOwned<u64> =  allocate_and_generate_new_lwe_packing_keyswitch_key_prefixsum(
                &parameter_set.big_lwe_sk,
                &parameter_set.glwe_sk,
                parameter_set.ks_base_log, // default is 3
                parameter_set.ks_level,
                // DecompositionLevelCount(9), // default is 5
                parameter_set.glwe_noise_distribution,
                parameter_set.ciphertext_modulus,
                &mut encryption_generator,
                2_u32.pow(w_arr.iter().sum::<u32>()) as usize,
            );
            save_bin(&s, &pksk_prefixsum).unwrap();
            pksk_prefixsum
        })
    } else {
        load_bin(&s).unwrap()
    };
    pksk_prefixsum
})
}

use crate::{LargeLUTparams, print};
pub fn generate_ring2ring_prefixsum_keys2(/*public_params: &LargeLUTparams,*/ l: usize) -> Vec<LwePackingKeyswitchKeyOwned<u64>> {
    print!("generating ring2ring prefixsum key for {}...\n", l);
TFHE_PARAMS.with(|params| {
    //let parameter_set = &params.borrow();
    let parameter_set = &params;
    let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;

    let (w_arr, d_arr, b_arr, s_arr) = compute_arrays(l, &parameter_set);

    ENCRYPTION_GENERATOR.with(|g| {
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l); // !!!
        let path = Path::new(&s);
        if path.is_file() == false {
            print!("Generating ring2ring onehot encode keys for {}...\n", l);
            let mut encryption_generator = g.borrow_mut();
            let pksk_ring2ring_onehot_encode_arr: Vec<LwePackingKeyswitchKeyOwned<u64>> = (0..l-1).map(|i| {
                allocate_and_generate_new_lwe_packing_keyswitch_key_ring2ring_onehot_encode(
                    &parameter_set.big_lwe_sk,
                    &parameter_set.glwe_sk,
                    parameter_set.ks_base_log,
                    parameter_set.ks_level,
                    parameter_set.glwe_noise_distribution,
                    parameter_set.ciphertext_modulus,
                    &mut encryption_generator,
                    &b_arr,
                    &d_arr,
                    i,
                )
            }).collect();
            save_bin(&s,&pksk_ring2ring_onehot_encode_arr,).unwrap();
            pksk_ring2ring_onehot_encode_arr
        } else {
            print!("loading ring2ring onehot encode keys for {}...\n", l);
            let pksk_ring2ring_onehot_encode_arr = load_bin(&s).unwrap();
            pksk_ring2ring_onehot_encode_arr
        }
    })
})
}

pub fn is_ring2ring_keys_available(l: usize) -> bool {
    TFHE_PARAMS.with(|params| {
        //let parameter_set = &params.borrow();
        let parameter_set = &params;
        let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
        let s = format!("keys/pksk_ring2ring_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        if path.is_file() == true {
            true
        } else {
            false
        }
    })
}

pub fn is_onehot_encode_keys_available(l: usize) -> bool {
    TFHE_PARAMS.with(|params| {
        //let parameter_set = &params.borrow();
        let parameter_set = &params;
        let modulus = parameter_set.message_modulus * parameter_set.carry_modulus;
        let s = format!("keys/pksk_ring2ring_onehot_encode_{}_{}.bin", modulus, l);
        let path = Path::new(&s);
        if path.is_file() == true {
            true
        } else {
            false
        }
    })
}

pub fn keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring<Scalar, KeyCont, InputCont, OutputCont>(
    public_params: &LargeLUTparams,
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_glwe_ciphertext: &GlweCiphertext<InputCont>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    i: usize,
) where
    Scalar: UnsignedInteger,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{
    
    // We reset the output
    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let degree_d: usize = public_params.b_arr[i] as usize * public_params.s_arr[i-1] as usize;
    for j in 0..degree_d {
        let p_j =  (j as u64) / public_params.b_arr[i];
        // t_jは正になるはず
        // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2 + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
        let t_j: u64 = ((2 * p_j + 1) * public_params.b_arr[i-1]) / 2;
        // if i == l-1 {
        //     print!("t_j: {}\n", t_j);
        // }
        output_glwe_ciphertext.get_mut_body().as_mut()[j] = input_glwe_ciphertext.get_body().as_ref()[t_j as usize];
    }

    // We instantiate a decomposer
    let decomposer = SignedDecomposer::new(
        lwe_pksk.decomposition_base_log(),
        lwe_pksk.decomposition_level_count(),
    );

    // 新しい実装
    for (element_index, keyswitch_key_block) in
        lwe_pksk.iter().enumerate()
    {
        // We decompose
        let (idx, sign) = negacyclic_index_and_sign(-1*element_index as i64, 0 as i64, input_glwe_ciphertext.polynomial_size().0);
        let mut mask_elem = input_glwe_ciphertext.as_ref()[idx];
        if sign < 0 {
            mask_elem = mask_elem.wrapping_neg();
        }
        let rounded = decomposer.closest_representable(mask_elem);
        let decomp = decomposer.decompose(rounded);

        // Loop over the number of levels:
        // We compute the multiplication of a ciphertext from the private functional
        // keyswitching key with a piece of the decomposition and subtract it to the buffer
        for (level_key_cipher, decomposed) in keyswitch_key_block.iter().zip(decomp) {
            slice_wrapping_sub_scalar_mul_assign(
                output_glwe_ciphertext.as_mut(),
                level_key_cipher.as_ref(),
                decomposed.value(),
            );
        }
    }

}

use tfhe::core_crypto::algorithms::slice_algorithms::*;
use rayon::prelude::*;

pub fn par_keyswitch_lwe_ciphertext_into_glwe_ciphertext_ring2ring<
    Scalar, KeyCont, InputCont, OutputCont
>( 
    public_params: &LargeLUTparams,
    lwe_pksk: &LwePackingKeyswitchKey<KeyCont>,
    input_glwe_ciphertext: &GlweCiphertext<InputCont>,
    output_glwe_ciphertext: &mut GlweCiphertext<OutputCont>,
    i: usize,
) where
    // 変更: 並列化のために Send + Sync を要求
    Scalar: UnsignedInteger + Send + Sync,
    KeyCont: Container<Element = Scalar>,
    InputCont: Container<Element = Scalar>,
    OutputCont: ContainerMut<Element = Scalar>,
{
    output_glwe_ciphertext.as_mut().fill(Scalar::ZERO);
    let degree_d: usize = public_params.b_arr[i] as usize * public_params.s_arr[i-1] as usize;
    for j in 0..degree_d {
        let p_j =  (j as u64) / public_params.b_arr[i];
        // t_jは正になるはず
        // let t_j: u64 = ((2 * p_j + 1) * b_arr[i-1]) / 2 + (((i-1)/2) as u64 * (1u64 << w_arr[i-1]) * b_arr[l-1]) as u64;
        let t_j: u64 = ((2 * p_j + 1) * public_params.b_arr[i-1]) / 2;
        // if i == l-1 {
        //     print!("t_j: {}\n", t_j);
        // }
        output_glwe_ciphertext.get_mut_body().as_mut()[j] = input_glwe_ciphertext.get_body().as_ref()[t_j as usize];
    }
    
    // We instantiate a decomposer
    // let decomposer: SignedDecomposer<Scalar> = SignedDecomposer::new(
    //     lwe_pksk.decomposition_base_log(),
    //     lwe_pksk.decomposition_level_count(),
    // );

    // Don't go above the current number of threads
    let thread_count = public_params.thread_count.0.min(rayon::current_num_threads());
    
    // let mut input_glwe_ciphertext_mask_reversed_negated: LweCiphertext<Vec<Scalar>> = LweCiphertext::new(
    //     Scalar::ZERO,
    //     LweSize(input_glwe_ciphertext.polynomial_size().0+1),
    //     input_glwe_ciphertext.ciphertext_modulus(),
    // );

    let mut input_glwe_ciphertext_mask_reversed_negated = GlweCiphertext::new(
            Scalar::ZERO,
            input_glwe_ciphertext.glwe_size(),
            input_glwe_ciphertext.polynomial_size(),
            input_glwe_ciphertext.ciphertext_modulus(),
    );

    
    for i in 0..input_glwe_ciphertext.polynomial_size().0 {
        // We decompose
        let (idx, sign) = negacyclic_index_and_sign(-1*i as i64, 0 as i64, input_glwe_ciphertext.polynomial_size().0);
        input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[i] = input_glwe_ciphertext.get_mask().as_ref()[idx];
        if sign < 0 {
            input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[i] = input_glwe_ciphertext_mask_reversed_negated.get_mut_mask().as_mut()[i].wrapping_neg();
        }
    }

    let mut intermediate_accumulators: Vec<GlweCiphertext<Vec<Scalar>>> = Vec::with_capacity(thread_count);

    // Smallest chunk_size such that thread_count * chunk_size >= input_lwe_size
    let chunk_size = input_glwe_ciphertext_mask_reversed_negated.polynomial_size().0.div_ceil(thread_count);

  

    // lwe_pksk.par_chunks(chunk_size).zip(
    //     input_glwe_ciphertext_mask_reversed_negated
    //     .get_mask()
    //     .as_ref()
    //     .par_chunks(chunk_size),
    // ).map(|(pksk_block_chunk, input_mask_reversed_negated_element_chunk)| {
    //     let mut buffer = GlweCiphertext::new(
    //         Scalar::ZERO,
    //         input_glwe_ciphertext.glwe_size(),
    //         input_glwe_ciphertext.polynomial_size(),
    //         input_glwe_ciphertext.ciphertext_modulus(),
    //     );

    //     for (pksk_block, &input_mask_reversed_negated_element) in pksk_block_chunk.iter()
    //             .zip(input_mask_reversed_negated_element_chunk.iter())
    //         {
    //             let decomposition_iter = decomposer.decompose(input_mask_reversed_negated_element);
    //             // Loop over the levels
    //             for (level_key_ciphertext, decomposed) in
    //                 pksk_block.iter().zip(decomposition_iter)
    //             {
    //                 slice_wrapping_sub_scalar_mul_assign(
    //                     buffer.as_mut(),
    //                     level_key_ciphertext.as_ref(),
    //                     decomposed.value(),
    //                 );
    //             }
    //         }
    //     buffer
    // }).collect_into_vec(&mut intermediate_accumulators);

    // 1) KSK をブロック列に“所有化”
    let ksk_blocks: Vec<_> = lwe_pksk.iter().collect();

    // 2) 入力マスクは素のスライスに（temporary/lifetime回避）
    let mask_view = input_glwe_ciphertext_mask_reversed_negated.get_mask();
    let a_slice: &[Scalar] = mask_view.as_ref();
    
    // クロージャ外に“数値だけ”退避（これらは Copy なので Sync は要らない）
    let glwe_size    = input_glwe_ciphertext.glwe_size();
    let poly_size    = input_glwe_ciphertext.polynomial_size();
    let ct_modulus   = input_glwe_ciphertext.ciphertext_modulus();

    // decomposer も中で都度作る（または base_log/level_count だけ外に出す）
    let base_log     = lwe_pksk.decomposition_base_log();
    let level_count  = lwe_pksk.decomposition_level_count();

    ksk_blocks
    .par_chunks(chunk_size)
    .zip(a_slice.par_chunks(chunk_size))
    .map(move |(pksk_block_chunk, a_chunk)| {
        // ここで input_glwe_ciphertext を参照しない！
        let mut buffer = GlweCiphertext::new(
            Scalar::ZERO,
            glwe_size,
            poly_size,
            ct_modulus,
        );

        // スレッドローカル decomposer
        let decomposer = SignedDecomposer::<Scalar>::new(base_log, level_count);

        for (pksk_block, &a_i) in pksk_block_chunk.iter().zip(a_chunk.iter()) {
            let rounded = decomposer.closest_representable(a_i);
            let decomp  = decomposer.decompose(rounded);

            for (lvl_ct, d) in pksk_block.iter().zip(decomp) {
                slice_wrapping_sub_scalar_mul_assign(
                    buffer.as_mut(),
                    lvl_ct.as_ref(),
                    d.value(),
                );
            }
        }
        buffer
    })
    .collect_into_vec(&mut intermediate_accumulators);


    let reduced = intermediate_accumulators
    .par_iter_mut()
    .reduce_with(|lhs, rhs| {
        lhs.as_mut()
            .iter_mut()
            .zip(rhs.as_ref().iter())
            .for_each(|(dst, &src)| *dst = (*dst).wrapping_add(src));

        lhs
    })
    .unwrap();

    output_glwe_ciphertext
        .get_mut_mask()
        .as_mut()
        .copy_from_slice(reduced.get_mask().as_ref());
    // let reduced_ksed_body = *reduced.get_body().data;

    // // Add the reduced body of the keyswitch to the output body to complete the keyswitch
    // *output_glwe_ciphertext.get_mut_body().data =
    //     (*output_glwe_ciphertext.get_mut_body().data).wrapping_add(reduced_ksed_body);

    // 入力（加算元）の借用：一時を束縛して寿命を延ばす
    let in_body_view = reduced.get_body();      // <- ここが生きている間 in_body は有効
    let in_body: &[Scalar] = in_body_view.as_ref();

    // 出力（加算先）の借用：同様に束縛
    let mut out_body_view = output_glwe_ciphertext.get_mut_body();
    let out_body: &mut [Scalar] = out_body_view.as_mut();

    // 要素ごとに wrapping_add（mod 加算）
    out_body
        .iter_mut()
        .zip(in_body.iter())
        .for_each(|(dst, &src)| *dst = dst.wrapping_add(src));
}


use crate::largelut::onehot_encode::large_ohe;
pub fn get_onehot_vector2(public_params: &LargeLUTparams, message: &Vec<LweCiphertextOwned<u64>>, b: &LweCiphertextOwned<u64>) 
-> GlweCiphertext<Vec<u64>> {
        let ctx_onehot_vector = make_onehot_lut2(&public_params, b);
        // let start_calibrate_time = Instant::now();
        //let message_calibrated_keyswitched = calibrate(&public_params, &message);
        let message_calibrated_keyswitched = large_lut_decomp_calibrate(&message, public_params.width, &public_params);
        // let end_calibrate_time = Instant::now();
        // print!("calibrate time:\n{:?}\n", end_calibrate_time.duration_since(start_calibrate_time));
        let l = public_params.w_arr.len();
        //let ctx_onehot_vector_result = large_ohe(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched); // old
        let ctx_onehot_vector_result = if is_onehot_encode_keys_available(l) {
            large_ohe_ring2ring(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched) // new
        } else {
            large_ohe(&public_params, &ctx_onehot_vector, &message_calibrated_keyswitched) // old
        };
        return ctx_onehot_vector_result;
}

//use crate::largelut::calibration_method::make_onehot_lut2;
use crate::largelut::onehot_encode::glwe_to_vector;
pub fn lwe_onehot2_calibrated(public_params: &LargeLUTparams, message_calibrated: &Vec<LweCiphertextOwned<u64>>, b: &LweCiphertext<Vec<u64>>) -> Vec<LweCiphertextOwned<u64>> {

    //let ctx_onehot_vector_result = get_onehot_vector2(public_params, &message_enc, &b);
    let ctx_onehot_vector = make_onehot_lut2(&public_params, b);
    //let ctx_onehot_vector_result = large_ohe(&public_params, &ctx_onehot_vector, &message_calibrated); // old
    let ctx_onehot_vector_result = large_ohe_ring2ring(&public_params, &ctx_onehot_vector, &message_calibrated); // new

    let v = glwe_to_vector(public_params, &ctx_onehot_vector_result);
    return v;
}

pub fn lwe_onehot2(public_params: &LargeLUTparams, message_enc: &Vec<LweCiphertextOwned<u64>>, b: &LweCiphertext<Vec<u64>>) -> Vec<LweCiphertextOwned<u64>> {

    let ctx_onehot_vector_result = get_onehot_vector2(public_params, &message_enc, &b);
    let v = glwe_to_vector(public_params, &ctx_onehot_vector_result);
    return v;
}

