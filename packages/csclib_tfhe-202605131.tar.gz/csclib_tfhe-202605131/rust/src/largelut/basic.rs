use std::cell::RefCell;
use tfhe::core_crypto::prelude::*;
use tfhe::core_crypto::commons::math::decomposition::{DecompositionLevel};


use crate::algorithms::TfheParam;

////////////////////////////////////////////////////////////////////////////////////
/// 共通の乱数生成器
/// 初めて必要になった時に実行される．
////////////////////////////////////////////////////////////////////////////////////
thread_local!(
    pub static ENCRYPTION_GENERATOR: RefCell<EncryptionRandomGenerator<DefaultRandomGenerator>> = {
        print!("Initializing PRNG...\n"); 
        let mut boxed_seeder = new_seeder();
        let seeder = boxed_seeder.as_mut();
        let encryption_generator = EncryptionRandomGenerator::<DefaultRandomGenerator>::new(seeder.seed(), seeder);
        RefCell::new(encryption_generator)
    }   
);

use tfhe::shortint::parameters::{PARAM_MESSAGE_2_CARRY_2_KS_PBS};
use tfhe::shortint::parameters::v1_4::{V1_4_PARAM_MESSAGE_4_CARRY_0_KS_PBS_GAUSSIAN_2M128};
thread_local!(
    pub static TFHE_PARAMS: RefCell<TfheParam> = {
        //let tfhe_params = TfheParam::new_params(PARAM_MESSAGE_2_CARRY_2_KS_PBS);
        let tfhe_params = TfheParam::new_params(V1_4_PARAM_MESSAGE_4_CARRY_0_KS_PBS_GAUSSIAN_2M128);
        RefCell::new(tfhe_params)
    }   
);


pub struct MyDecompositionTerm<T>
where
    T: UnsignedInteger,
{
    level: usize,
    base_log: usize,
    value: T,
}

impl<T> MyDecompositionTerm<T>
where
    T: UnsignedInteger,
{
    // Creates a new decomposition term.
    pub fn new(level: DecompositionLevel, base_log: DecompositionBaseLog, value: T) -> Self {
        Self {
            level: level.0,
            base_log: base_log.0,
            value,
        }
    }

    pub fn to_recomposition_summand(&self) -> T {
        let shift: usize = <T as Numeric>::BITS - self.base_log * self.level;
        self.value << shift
    }

    pub fn value(&self) -> T {
        self.value
    }

    pub fn level(&self) -> DecompositionLevel {
        DecompositionLevel(self.level)
    }
}
