"""src/base/loci_store — ChromaDB Wing/Room abstraction for MemShān.

Implements the Method of Loci spatial metaphor:
  Wing  = top-level namespace  (e.g. "work", "personal", "long_term")
  Room  = ChromaDB collection, named "{wing}__{room}"  (double-underscore)
"""

import chromadb


class LociStore:
    """ChromaDB-backed spatial memory store using Wings and Rooms.

    Single Responsibility: persist and retrieve embedding chunks inside
    wing/room-namespaced ChromaDB collections.
    Dependency Inversion: accepts any chromadb.ClientAPI implementation
    so callers (and tests) can inject an ephemeral or persistent client.
    """

    _SEPARATOR: str = "__"

    def __init__(self, client: chromadb.ClientAPI) -> None:
        """Initialise the store with a ChromaDB client.

        Args:
            client: A chromadb client (EphemeralClient, PersistentClient, etc.).

        Raises:
            ValueError: If *client* is None.
        """
        if client is None:
            raise ValueError("ChromaDB client must not be None.")
        self._client: chromadb.ClientAPI = client

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _collection_name(self, wing: str, room: str) -> str:
        """Return the ChromaDB collection name for a Wing/Room pair."""
        return f"{wing}{self._SEPARATOR}{room}"

    def _get_or_create(self, wing: str, room: str) -> chromadb.Collection:
        """Get or lazily create the ChromaDB collection for a Wing/Room."""
        return self._client.get_or_create_collection(
            name=self._collection_name(wing, room),
            metadata={"hnsw:space": "cosine"},
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def upsert(
        self,
        wing: str,
        room: str,
        chunk_id: str,
        text: str,
        embedding: list[float],
        metadata: dict,
    ) -> None:
        """Insert or update a chunk in the specified Wing/Room.

        Args:
            wing:      Wing namespace.
            room:      Room name within the wing.
            chunk_id:  Unique identifier for this chunk (used as ChromaDB ID).
            text:      Raw text content of the chunk.
            embedding: Pre-computed float embedding vector.
            metadata:  Arbitrary key-value metadata to store alongside the chunk.
                       An empty dict is permitted; ChromaDB will store no metadata.
        """
        collection = self._get_or_create(wing, room)
        # ChromaDB >= 0.6 rejects empty metadata dicts; omit the key when empty.
        upsert_kwargs: dict = {
            "ids": [chunk_id],
            "documents": [text],
            "embeddings": [embedding],
        }
        if metadata:
            upsert_kwargs["metadatas"] = [metadata]
        collection.upsert(**upsert_kwargs)

    def query(
        self,
        wing: str,
        room: str,
        query_embedding: list[float],
        top_k: int,
    ) -> list[dict]:
        """Semantic similarity search in a Wing/Room.

        Args:
            wing:            Wing namespace.
            room:            Room name within the wing.
            query_embedding: Float vector to search against.
            top_k:           Maximum number of results to return.

        Returns:
            A list of result dicts, each with keys:
            ``id``, ``text``, ``metadata``, ``distance``.
            Ordered by ascending distance (most similar first).
            Returns an empty list if the room contains no chunks.
        """
        collection = self._get_or_create(wing, room)
        count = collection.count()
        if count == 0:
            return []
        actual_k = min(top_k, count)
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=actual_k,
            include=["documents", "metadatas", "distances"],
        )
        output: list[dict] = []
        ids: list[str] = results["ids"][0]
        documents: list[str] = results["documents"][0]
        metadatas: list[dict] = results["metadatas"][0]
        distances: list[float] = results["distances"][0]
        for i, cid in enumerate(ids):
            output.append(
                {
                    "id": cid,
                    "text": documents[i],
                    "metadata": metadatas[i] or {},
                    "distance": distances[i],
                }
            )
        return output

    def list_rooms(self) -> list[dict]:
        """Enumerate all Wings and Rooms currently in the store.

        Returns:
            A list of dicts with keys ``wing``, ``room``, and ``count``
            (number of chunks stored in that room).
            Collections whose names do not contain the wing/room separator
            are silently excluded.
        """
        collection_names = self._client.list_collections()
        rooms: list[dict] = []
        for col_name in collection_names:
            name: str = str(col_name)
            if self._SEPARATOR not in name:
                continue
            wing, room = name.split(self._SEPARATOR, 1)
            collection = self._client.get_collection(name)
            rooms.append({"wing": wing, "room": room, "count": collection.count()})
        return rooms

    def get_by_ids(
        self,
        wing: str,
        room: str,
        ids: list[str],
    ) -> list[dict]:
        """Retrieve specific chunks by their IDs from a Wing/Room.

        Args:
            wing: Wing namespace.
            room: Room name within the wing.
            ids:  List of chunk IDs to retrieve. An empty list returns [].

        Returns:
            A list of dicts for each found chunk, each with keys:
            ``id``, ``text``, ``metadata``.
            Chunks whose IDs are not found are silently omitted.
        """
        if not ids:
            return []
        collection = self._get_or_create(wing, room)
        results = collection.get(ids=ids, include=["documents", "metadatas"])
        output: list[dict] = []
        for i, cid in enumerate(results["ids"]):
            output.append(
                {
                    "id": cid,
                    "text": results["documents"][i],
                    "metadata": results["metadatas"][i] or {},
                }
            )
        return output
