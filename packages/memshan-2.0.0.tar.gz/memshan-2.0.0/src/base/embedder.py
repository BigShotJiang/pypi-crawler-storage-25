"""src/base/embedder — Sentence-transformer embedding wrapper for MemShān."""

from sentence_transformers import SentenceTransformer


class Embedder:
    """Thin wrapper around SentenceTransformer; loads the model once on construction.

    Single Responsibility: convert text (single or batch) into float vectors.
    Dependency Inversion: callers depend on this abstraction, not on the
    sentence-transformers SDK directly.
    """

    def __init__(self, model_name: str) -> None:
        """Load and cache the embedding model.

        Args:
            model_name: A sentence-transformers model identifier
                        (e.g. "all-MiniLM-L6-v2").

        Raises:
            ValueError: If *model_name* is empty.
            RuntimeError: If the model cannot be loaded.
        """
        if not model_name:
            raise ValueError("model_name must not be empty.")
        try:
            self._model: SentenceTransformer = SentenceTransformer(model_name)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to load embedding model '{model_name}': {exc}"
            ) from exc

    def embed(self, text: str) -> list[float]:
        """Embed a single text string and return a float vector.

        Args:
            text: The text to embed.

        Returns:
            A list of floats representing the embedding.
        """
        return self._model.encode(text).tolist()

    def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """Embed a list of text strings and return a list of float vectors.

        Args:
            texts: The texts to embed. May be empty.

        Returns:
            A list of embedding vectors, one per input text.
        """
        if not texts:
            return []
        vectors = self._model.encode(texts)
        return [vec.tolist() for vec in vectors]
