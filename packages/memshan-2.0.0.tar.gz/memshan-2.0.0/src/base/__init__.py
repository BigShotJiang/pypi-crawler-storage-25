"""src/base — Method of Loci base layer for MemShān (ChromaDB Wings/Rooms)."""
