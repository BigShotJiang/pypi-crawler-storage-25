"""src/pipeline — Unified retrieval pipeline for MemShān."""
