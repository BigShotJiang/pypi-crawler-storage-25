"""src/pipeline/retrieval.py — Phase 7: Unified Retrieval Pipeline.

RetrievalPipeline composes all four MemShān layers into a single store/retrieve
interface:

  Layer 0 (Base)   — LociStore + Embedder  (ChromaDB vector store)
  Layer 1 (Major)  — PhoneticEncoder       (numeric precision tags)
  Layer 2 (Songs)  — KnowledgeGraph        (context trail expansion)

store() flow
------------
1. PhoneticEncoder.extract_and_tag(text)  → phonetic metadata tags
2. Embedder.embed(text)                   → chunk embedding
3. LociStore.upsert(...)                  → persist chunk
4. KnowledgeGraph.add_chunk_node(...)     → register node
5. LociStore.query(...)                   → find near-neighbours already stored
6. KnowledgeGraph.add_edge(..., "SEMANTIC") for each neighbour below threshold

retrieve() flow
---------------
1. PhoneticEncoder.extract_and_tag(query)  → phonetic tags (attached to result)
2. Embedder.embed(query)                   → query embedding
3. LociStore.query(...)                    → top-K semantic hits
4. KnowledgeGraph.get_neighbors(hit_id)    → graph-expanded IDs
5. LociStore.get_by_ids(...)               → fetch expanded chunks (distance=None)
6. Merge + deduplicate + re-rank → return top_k results
"""

from __future__ import annotations

from src.base.embedder import Embedder
from src.base.loci_store import LociStore
from src.layers.major_system.phonetic_encoder import PhoneticEncoder
from src.layers.songlines.knowledge_graph import KnowledgeGraph

# Distance threshold below which two chunks are considered semantically similar.
# Cosine distance in ChromaDB: 0.0 = identical, 2.0 = opposite.
_SEMANTIC_THRESHOLD: float = 0.3

# Default number of neighbours to consider when building SEMANTIC edges.
_NEIGHBOUR_K: int = 5

# Default top-K for retrieval when the caller does not specify.
_DEFAULT_TOP_K: int = 10


class RetrievalPipeline:
    """Compose all MemShān layers into a unified store / retrieve interface.

    SOLID compliance
    ----------------
    S — Single responsibility: orchestrate the four layers; no layer logic.
    O — New layers can be added without modifying existing store/retrieve paths.
    L — No subclasses; designed for substitution of any injected dependency.
    I — Narrow interface: two public methods (store, retrieve).
    D — All four dependencies injected via constructor; no concrete imports
        in business methods beyond the four ABCs/classes.
    """

    def __init__(
        self,
        loci_store: LociStore,
        embedder: Embedder,
        graph: KnowledgeGraph,
        encoder: PhoneticEncoder,
        semantic_threshold: float = _SEMANTIC_THRESHOLD,
        neighbour_k: int = _NEIGHBOUR_K,
        default_top_k: int = _DEFAULT_TOP_K,
    ) -> None:
        """Initialise the pipeline with all required layer dependencies.

        Args:
            loci_store:         ChromaDB-backed vector store (Layer 0).
            embedder:           Sentence-transformer embedding wrapper (Layer 0).
            graph:              NetworkX knowledge graph (Layer 2).
            encoder:            Major System phonetic encoder (Layer 1).
            semantic_threshold: Cosine distance below which a SEMANTIC edge is
                                added between two chunks (default 0.3).
            neighbour_k:        Number of nearest neighbours to inspect when
                                building SEMANTIC edges during store() (default 5).
            default_top_k:      Fallback top-K used by retrieve() when the caller
                                passes top_k=None (default 10).

        Raises:
            ValueError: If any injected dependency is None, or if numeric
                        parameters are out of range.
        """
        if loci_store is None:
            raise ValueError("loci_store must not be None.")
        if embedder is None:
            raise ValueError("embedder must not be None.")
        if graph is None:
            raise ValueError("graph must not be None.")
        if encoder is None:
            raise ValueError("encoder must not be None.")
        if not (0.0 <= semantic_threshold <= 2.0):
            raise ValueError(
                f"semantic_threshold must be in [0.0, 2.0], got {semantic_threshold}."
            )
        if neighbour_k < 1:
            raise ValueError(f"neighbour_k must be >= 1, got {neighbour_k}.")
        if default_top_k < 1:
            raise ValueError(f"default_top_k must be >= 1, got {default_top_k}.")

        self._store: LociStore = loci_store
        self._embedder: Embedder = embedder
        self._graph: KnowledgeGraph = graph
        self._encoder: PhoneticEncoder = encoder
        self._semantic_threshold: float = semantic_threshold
        self._neighbour_k: int = neighbour_k
        self._default_top_k: int = default_top_k

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def store(
        self,
        wing: str,
        room: str,
        chunk_id: str,
        text: str,
        metadata: dict | None = None,
    ) -> None:
        """Store a text chunk through all pipeline layers.

        Steps:
            1. Extract phonetic tags from *text* via PhoneticEncoder.
            2. Merge tags into *metadata* (lists serialised as comma-joined strings
               for ChromaDB compatibility).
            3. Embed *text* via Embedder.
            4. Upsert chunk into LociStore.
            5. Register chunk node in KnowledgeGraph.
            6. Query existing neighbours; add SEMANTIC edges for near matches.

        Args:
            wing:      Wing namespace for the LociStore room.
            room:      Room name within the wing.
            chunk_id:  Unique identifier for this memory chunk.
            text:      Raw text to store and embed.
            metadata:  Optional caller-supplied metadata dict.  Phonetic tags
                       are merged in; the original dict is not mutated.
        """
        base_meta: dict = dict(metadata) if metadata else {}

        # Step 1 — phonetic encoding
        tag_result: dict = self._encoder.extract_and_tag(text)
        # Serialise lists as comma-joined strings (ChromaDB metadata must be primitives)
        phonetic_str = ",".join(tag_result["phonetic_tags"])
        numeric_str = ",".join(tag_result["numeric_tokens"])
        if phonetic_str:
            base_meta["phonetic_tags"] = phonetic_str
        if numeric_str:
            base_meta["numeric_tokens"] = numeric_str

        # Step 2 — embed
        embedding: list[float] = self._embedder.embed(text)

        # Step 3 — persist to vector store
        self._store.upsert(wing, room, chunk_id, text, embedding, base_meta)

        # Step 4 — register in knowledge graph
        self._graph.add_chunk_node(chunk_id, base_meta)

        # Step 5 — build SEMANTIC edges to existing near-neighbours
        neighbours: list[dict] = self._store.query(
            wing, room, embedding, self._neighbour_k
        )
        for neighbour in neighbours:
            nid: str = neighbour["id"]
            dist: float = neighbour["distance"]
            if nid != chunk_id and dist <= self._semantic_threshold:
                self._graph.add_edge(chunk_id, nid, "SEMANTIC", weight=1.0 - dist)

    def retrieve(
        self,
        query: str,
        wing: str,
        room: str,
        top_k: int | None = None,
    ) -> list[dict]:
        """Retrieve the most relevant chunks for *query* using all pipeline layers.

        Steps:
            1. Extract phonetic tags from *query* (attached to result metadata).
            2. Embed *query*.
            3. Semantic search in LociStore → initial top-K hits.
            4. Graph expansion: for each hit, fetch neighbours from KnowledgeGraph.
            5. Fetch expanded chunks from LociStore (distance assigned as None).
            6. Merge, deduplicate, sort by distance (None → sorted last), return top_k.

        Args:
            query:  Natural-language query string.
            wing:   Wing namespace to search.
            room:   Room name within the wing.
            top_k:  Maximum number of results to return.
                    Defaults to the pipeline's ``default_top_k`` when None.

        Returns:
            A list of result dicts (up to *top_k*), each containing:
            ``id``, ``text``, ``metadata``, ``distance``, ``phonetic_tags``.
            The list is ordered by ascending distance (most similar first);
            graph-expanded chunks without a distance appear at the end.
        """
        k: int = top_k if top_k is not None else self._default_top_k

        # Step 1 — phonetic tags for the query (informational, added to each result)
        query_tags: dict = self._encoder.extract_and_tag(query)

        # Step 2 — embed query
        query_embedding: list[float] = self._embedder.embed(query)

        # Step 3 — semantic search
        hits: list[dict] = self._store.query(wing, room, query_embedding, k)

        # Step 4+5 — graph expansion
        seen_ids: set[str] = {h["id"] for h in hits}
        expanded_ids: list[str] = []
        for hit in hits:
            for neighbour_id in self._graph.get_neighbors(hit["id"]):
                if neighbour_id not in seen_ids:
                    seen_ids.add(neighbour_id)
                    expanded_ids.append(neighbour_id)

        expanded_chunks: list[dict] = []
        if expanded_ids:
            raw_expanded = self._store.get_by_ids(wing, room, expanded_ids)
            for chunk in raw_expanded:
                chunk["distance"] = None  # no vector distance for graph-expanded items
                expanded_chunks.append(chunk)

        # Step 6 — merge, sort, slice
        all_results: list[dict] = hits + expanded_chunks

        def _sort_key(r: dict) -> tuple:
            d = r.get("distance")
            # None distances sort after all real distances
            return (1, 0.0) if d is None else (0, d)

        all_results.sort(key=_sort_key)

        # Attach query phonetic tags to every result
        for result in all_results:
            result["phonetic_tags"] = query_tags["phonetic_tags"]

        return all_results[:k]

    # ------------------------------------------------------------------
    # Read-only configuration properties (used by MCP metrics tools)
    # ------------------------------------------------------------------

    @property
    def semantic_threshold(self) -> float:
        """Return the cosine distance threshold for SEMANTIC edge creation."""
        return self._semantic_threshold

    @property
    def neighbour_k(self) -> int:
        """Return the number of neighbours inspected during store()."""
        return self._neighbour_k

    @property
    def default_top_k(self) -> int:
        """Return the default top-K used by retrieve() when top_k is None."""
        return self._default_top_k

    @property
    def encoder(self) -> PhoneticEncoder:
        """Return the PhoneticEncoder instance used by this pipeline."""
        return self._encoder
