"""
src/config.py — MemShān central configuration.

Reads all settings from environment variables (via .env).
Provides a factory ``get_llm_client()`` that returns the correct
``LLMClient`` implementation based on ``LLM_PROVIDER``.

Design notes
------------
- Single Responsibility : owns all env-to-Python mapping; nothing else.
- Open/Closed           : new providers added by extending the factory
                          without modifying existing branches.
- Dependency Inversion  : factory returns the ``LLMClient`` ABC — callers
                          never depend on a concrete provider class.
- No secrets in source  : all values come exclusively from the .env file.
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

# ``LLMClient`` imported at call-site inside the factory to avoid a circular
# dependency at module load time (the concrete clients import ``Settings``).
# Business logic must only ever import ``LLMClient`` from ``src.llm.client``.

_SUPPORTED_PROVIDERS = frozenset({"ollama", "openai", "gemini", "anthropic"})


class Settings(BaseSettings):
    """Pydantic BaseSettings for MemShān.

    All fields are read from environment variables.  Defaults are safe
    for a fully-offline Ollama setup; no key is required in that case.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ── LLM provider ──────────────────────────────────────────────────────────
    llm_provider: str = Field(default="ollama", alias="LLM_PROVIDER")

    # ── Ollama ────────────────────────────────────────────────────────────────
    ollama_base_url: str = Field(
        default="http://localhost:11434", alias="OLLAMA_BASE_URL"
    )
    ollama_model: str = Field(default="llama3.2", alias="OLLAMA_MODEL")

    # ── OpenAI ────────────────────────────────────────────────────────────────
    openai_api_key: str | None = Field(default=None, alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4o-mini", alias="OPENAI_MODEL")

    # ── Google Gemini ─────────────────────────────────────────────────────────
    gemini_api_key: str | None = Field(default=None, alias="GEMINI_API_KEY")
    gemini_model: str = Field(default="gemini-2.5-flash", alias="GEMINI_MODEL")

    # ── Anthropic ─────────────────────────────────────────────────────────────
    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY")
    anthropic_model: str = Field(
        default="claude-3-haiku-20240307", alias="ANTHROPIC_MODEL"
    )

    # ── ChromaDB ──────────────────────────────────────────────────────────────
    chroma_persist_dir: str = Field(
        default="./data/chroma", alias="CHROMA_PERSIST_DIR"
    )

    # ── Embeddings ────────────────────────────────────────────────────────────
    embedding_model: str = Field(
        default="all-MiniLM-L6-v2", alias="EMBEDDING_MODEL"
    )

    # ── Retrieval ─────────────────────────────────────────────────────────────
    default_top_k: int = Field(default=5, alias="DEFAULT_TOP_K")

    # ── Factory ───────────────────────────────────────────────────────────────
    def get_llm_client(self) -> "LLMClient":  # noqa: F821  (defined in llm.client)
        """Return the concrete ``LLMClient`` for the configured provider.

        Raises
        ------
        ValueError
            If ``llm_provider`` is not one of the supported values, or if
            the required API key for the chosen provider is absent.
        """
        provider = self.llm_provider.lower().strip()

        if provider not in _SUPPORTED_PROVIDERS:
            raise ValueError(
                f"Unsupported LLM_PROVIDER '{provider}'. "
                f"Choose one of: {sorted(_SUPPORTED_PROVIDERS)}"
            )

        # Late imports keep the concrete adapters isolated in src/llm/
        if provider == "ollama":
            from src.llm.ollama_client import OllamaClient  # noqa: PLC0415

            return OllamaClient(
                base_url=self.ollama_base_url,
                model=self.ollama_model,
            )

        if provider == "openai":
            from src.llm.openai_client import OpenAIClient  # noqa: PLC0415

            return OpenAIClient(
                api_key=self.openai_api_key,
                model=self.openai_model,
            )

        if provider == "gemini":
            from src.llm.gemini_client import GeminiClient  # noqa: PLC0415

            return GeminiClient(
                api_key=self.gemini_api_key,
                model=self.gemini_model,
            )

        # provider == "anthropic"
        from src.llm.anthropic_client import AnthropicClient  # noqa: PLC0415

        return AnthropicClient(
            api_key=self.anthropic_api_key,
            model=self.anthropic_model,
        )
