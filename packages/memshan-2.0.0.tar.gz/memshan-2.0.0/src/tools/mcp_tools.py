"""src/tools/mcp_tools.py — Phase 8: MCP Tool Layer.

All tools are thin adapters.  No business logic lives here.
Each tool validates inputs, delegates to the injected pipeline layer,
and returns serialisable Python types (dict / list / str / int / bool).

Tool categories
---------------
  A — Configuration & Inspection : get_server_status, list_rooms,
                                    get_pipeline_config
  B — Storage & Retrieval        : store_memory, retrieve_memory,
                                    add_context_trail, get_context_trail,
                                    snapshot_session
  C — Metrics & Measurement      : get_recall_stats, get_graph_stats,
                                    get_compression_stats, get_latency_report

SOLID compliance
----------------
S — Thin adapter only; no business logic.
O — New tools added without touching existing ones.
L — No subclasses; tools are plain callables.
I — Each tool has a narrow, single-purpose interface.
D — All dependencies injected via configure(); never instantiated here.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from mcp.server.fastmcp import FastMCP

if TYPE_CHECKING:
    from src.base.embedder import Embedder
    from src.base.loci_store import LociStore
    from src.config import Settings
    from src.layers.pao.snapshot import SessionSnapshot
    from src.layers.songlines.knowledge_graph import KnowledgeGraph
    from src.pipeline.retrieval import RetrievalPipeline

# ---------------------------------------------------------------------------
# MCP server instance — imported and started by src.server
# ---------------------------------------------------------------------------

mcp: FastMCP = FastMCP("MemShān")

# ---------------------------------------------------------------------------
# Module-level singletons (set once by configure(); never re-created in tools)
# ---------------------------------------------------------------------------

_pipeline: RetrievalPipeline | None = None
_graph: KnowledgeGraph | None = None
_snapshot: SessionSnapshot | None = None
_loci_store: LociStore | None = None
_embedder: Embedder | None = None
_settings: Settings | None = None

# MemShān application version
_VERSION: str = "2.0"


# ---------------------------------------------------------------------------
# Dependency injection
# ---------------------------------------------------------------------------


def configure(
    pipeline: RetrievalPipeline,
    graph: KnowledgeGraph,
    snapshot: SessionSnapshot,
    loci_store: LociStore,
    embedder: Embedder,
    settings: Settings,
) -> None:
    """Inject all runtime dependencies into the tool layer.

    Called exactly once by ``src.server`` before ``mcp.run()``.

    Args:
        pipeline:   Unified retrieval pipeline (Layers 0–2).
        graph:      Songlines knowledge graph (Layer 2).
        snapshot:   PAO session snapshot archiver (Layer 3).
        loci_store: ChromaDB Wing/Room store (Layer 0).
        embedder:   Sentence-transformer embedding utility (Layer 0).
        settings:   Application configuration from .env.
    """
    global _pipeline, _graph, _snapshot, _loci_store, _embedder, _settings
    _pipeline = pipeline
    _graph = graph
    _snapshot = snapshot
    _loci_store = loci_store
    _embedder = embedder
    _settings = settings


# ---------------------------------------------------------------------------
# Internal guards and validators
# ---------------------------------------------------------------------------


def _require_configured() -> None:
    """Raise RuntimeError if configure() has not been called yet."""
    if _pipeline is None:
        raise RuntimeError(
            "MCP tools are not configured. Call configure() before use."
        )


def _validate_str(value: str, name: str) -> None:
    """Raise ValueError if *value* is empty or blank."""
    if not value or not value.strip():
        raise ValueError(f"'{name}' must be a non-empty string.")


# ===========================================================================
# Category A — Configuration & Inspection
# ===========================================================================


@mcp.tool()
def get_server_status() -> dict:
    """Return current MemShān server configuration and runtime status.

    Returns a dict with version, LLM provider, embedding model, ChromaDB
    directory, and the three retrieval threshold parameters.
    """
    _require_configured()
    return {
        "version": _VERSION,
        "llm_provider": _settings.llm_provider,
        "embedding_model": _settings.embedding_model,
        "chroma_persist_dir": _settings.chroma_persist_dir,
        "semantic_threshold": _pipeline.semantic_threshold,
        "neighbour_k": _pipeline.neighbour_k,
        "default_top_k": _pipeline.default_top_k,
    }


@mcp.tool()
def list_rooms() -> list[dict]:
    """Enumerate all Wings and Rooms with their document counts.

    Returns a list of dicts, each with keys ``wing``, ``room``, ``count``.
    """
    _require_configured()
    return _loci_store.list_rooms()


@mcp.tool()
def get_pipeline_config() -> dict:
    """Return the retrieval pipeline's tunable configuration.

    Returns ``semantic_threshold``, ``neighbour_k``, and ``default_top_k``.
    """
    _require_configured()
    return {
        "semantic_threshold": _pipeline.semantic_threshold,
        "neighbour_k": _pipeline.neighbour_k,
        "default_top_k": _pipeline.default_top_k,
    }


# ===========================================================================
# Category B — Storage & Retrieval
# ===========================================================================


@mcp.tool()
def store_memory(
    wing: str,
    room: str,
    chunk_id: str,
    text: str,
    metadata: dict | None = None,
) -> dict:
    """Ingest a text chunk through all four pipeline layers.

    Runs phonetic tagging (Layer 1), embedding (Layer 0), ChromaDB upsert
    (Layer 0), graph node registration (Layer 2), and SEMANTIC edge creation
    (Layer 2).

    Args:
        wing:      Wing namespace (e.g. ``"work"``).
        room:      Room name within the wing.
        chunk_id:  Unique identifier for this memory chunk.
        text:      Raw text to store and embed.
        metadata:  Optional caller-supplied metadata dict.

    Returns:
        Dict with ``stored``, ``chunk_id``, ``phonetic_tags``, and
        ``graph_edges_added``.
    """
    _require_configured()
    _validate_str(wing, "wing")
    _validate_str(room, "room")
    _validate_str(chunk_id, "chunk_id")
    _validate_str(text, "text")

    edges_before: int = _graph._graph.number_of_edges()
    _pipeline.store(wing, room, chunk_id, text, metadata)
    edges_after: int = _graph._graph.number_of_edges()

    # Extract phonetic tags — stateless and safe to call a second time
    tag_result: dict = _pipeline.encoder.extract_and_tag(text)

    return {
        "stored": True,
        "chunk_id": chunk_id,
        "phonetic_tags": tag_result["phonetic_tags"],
        "graph_edges_added": edges_after - edges_before,
    }


@mcp.tool()
def retrieve_memory(
    query: str,
    wing: str,
    room: str,
    top_k: int = 5,
) -> list[dict]:
    """Retrieve the most relevant chunks for *query*.

    Performs semantic similarity search followed by knowledge-graph expansion,
    returning up to *top_k* results with the original stored text preserved
    exactly (zero data loss).

    Args:
        query:  Natural-language query string.
        wing:   Wing namespace to search.
        room:   Room name within the wing.
        top_k:  Maximum number of results (default 5).

    Returns:
        List of result dicts each with ``id``, ``text``, ``distance``,
        ``metadata``, and ``phonetic_tags``.
    """
    _require_configured()
    _validate_str(query, "query")
    _validate_str(wing, "wing")
    _validate_str(room, "room")
    if top_k < 1:
        raise ValueError(f"top_k must be >= 1, got {top_k}.")

    results: list[dict] = _pipeline.retrieve(query, wing, room, top_k=top_k)
    return [
        {
            "id": r["id"],
            "text": r["text"],
            "distance": r.get("distance"),
            "metadata": r.get("metadata", {}),
            "phonetic_tags": r.get("phonetic_tags", []),
        }
        for r in results
    ]


@mcp.tool()
def add_context_trail(from_id: str, to_id: str, label: str = "manual link") -> dict:
    """Manually link two chunk IDs with a MANUAL edge in the knowledge graph.

    The edge is always stored with edge_type ``MANUAL``.  The *label*
    parameter is an optional human-readable description of the relationship.

    Args:
        from_id: Source chunk or concept node ID.
        to_id:   Target chunk or concept node ID.
        label:   Human-readable description of the relationship.

    Returns:
        Dict with ``linked``, ``from_id``, ``to_id``, ``edge_type``,
        ``label``.
    """
    _require_configured()
    _validate_str(from_id, "from_id")
    _validate_str(to_id, "to_id")
    _validate_str(label, "label")

    _graph.add_edge(from_id, to_id, "MANUAL", weight=1.0)
    return {
        "linked": True,
        "from_id": from_id,
        "to_id": to_id,
        "edge_type": "MANUAL",
        "label": label,
    }


@mcp.tool()
def get_context_trail(from_id: str, to_id: str) -> dict:
    """Return the shortest directed path between two nodes in the graph.

    Args:
        from_id: Source node ID.
        to_id:   Target node ID.

    Returns:
        Dict with ``from_id``, ``to_id``, ``trail`` (list of node IDs),
        and ``length``.  ``trail`` is empty when no path exists.
    """
    _require_configured()
    _validate_str(from_id, "from_id")
    _validate_str(to_id, "to_id")

    trail: list[str] = _graph.get_trail(from_id, to_id)
    return {
        "from_id": from_id,
        "to_id": to_id,
        "trail": trail,
        "length": len(trail),
    }


@mcp.tool()
def snapshot_session(
    session_id: str,
    exchanges: list[str],
    wing: str = "long_term",
    room: str = "sessions",
) -> dict:
    """PAO-compress a session log into SAO triplets and archive it.

    Uses spaCy dependency parsing (with LLM fallback) to extract
    Subject-Action-Object triplets from *exchanges*, then stores each
    triplet as a compressed chunk in the specified Wing/Room.

    Args:
        session_id: Unique identifier for this session.
        exchanges:  List of text exchanges (turns) to compress.
        wing:       Target Wing for archival (default ``"long_term"``).
        room:       Target Room within the wing (default ``"sessions"``).

    Returns:
        Dict with ``archived``, ``session_id``, ``chunk_ids``, and
        ``triplets_stored``.
    """
    _require_configured()
    _validate_str(session_id, "session_id")
    _validate_str(wing, "wing")
    _validate_str(room, "room")
    if not isinstance(exchanges, list):
        raise ValueError("'exchanges' must be a list of strings.")

    chunk_ids: list[str] = _snapshot.snapshot_session(
        session_id, exchanges, wing, room
    )
    return {
        "archived": True,
        "session_id": session_id,
        "chunk_ids": chunk_ids,
        "triplets_stored": len(chunk_ids),
    }


# ===========================================================================
# Category C — Metrics & Measurement
# ===========================================================================


@mcp.tool()
def get_recall_stats(wing: str, room: str, sample_size: int = 20) -> dict:
    """Probe retrieval recall accuracy for a Wing/Room.

    Samples up to *sample_size* chunks from the room by running a
    neutral probe query via the embedder, then re-retrieves each chunk
    using its own stored text and checks whether it ranks first.  This
    measures the KPI for Faithfulness / Groundedness and the KRA for
    Amnesia-Proof Persistence.

    Args:
        wing:        Wing namespace to probe.
        room:        Room name within the wing.
        sample_size: Number of chunks to sample (default 20).

    Returns:
        Dict with ``sample_size``, ``recalled``, ``recall_accuracy_pct``,
        ``avg_distance``, ``kpi_faithfulness_met``, ``kra_amnesia_proof_met``.
    """
    _require_configured()
    _validate_str(wing, "wing")
    _validate_str(room, "room")
    if sample_size < 1:
        raise ValueError(f"sample_size must be >= 1, got {sample_size}.")

    rooms: list[dict] = _loci_store.list_rooms()
    room_info: dict | None = next(
        (r for r in rooms if r["wing"] == wing and r["room"] == room), None
    )

    if room_info is None or room_info["count"] == 0:
        return {
            "sample_size": 0,
            "recalled": 0,
            "recall_accuracy_pct": 0.0,
            "avg_distance": None,
            "kpi_faithfulness_met": False,
            "kra_amnesia_proof_met": False,
        }

    actual_sample: int = min(sample_size, room_info["count"])

    # Use a neutral probe embedding to draw a representative sample of chunks
    probe_embedding: list[float] = _embedder.embed(
        "memory recall knowledge information"
    )
    candidates: list[dict] = _loci_store.query(
        wing, room, probe_embedding, actual_sample
    )

    recalled: int = 0
    total_distance: float = 0.0
    distance_count: int = 0

    for chunk in candidates:
        results: list[dict] = _pipeline.retrieve(
            chunk["text"], wing, room, top_k=1
        )
        if results and results[0]["id"] == chunk["id"]:
            recalled += 1
            dist = results[0].get("distance")
            if dist is not None:
                total_distance += dist
                distance_count += 1

    recall_pct: float = (recalled / actual_sample * 100.0) if actual_sample > 0 else 0.0
    avg_dist: float | None = (total_distance / distance_count) if distance_count > 0 else None

    return {
        "sample_size": actual_sample,
        "recalled": recalled,
        "recall_accuracy_pct": round(recall_pct, 2),
        "avg_distance": round(avg_dist, 4) if avg_dist is not None else None,
        "kpi_faithfulness_met": recall_pct >= 95.0,
        "kra_amnesia_proof_met": recall_pct >= 95.0,
    }


@mcp.tool()
def get_graph_stats() -> dict:
    """Return knowledge graph topology statistics.

    Inspects the underlying NetworkX DiGraph to count nodes, edges, and
    the breakdown of SEMANTIC vs MANUAL edges.  Reports average edge
    density per node.

    Returns:
        Dict with ``nodes``, ``edges``, ``semantic_edges``,
        ``manual_edges``, ``avg_edges_per_node``.
    """
    _require_configured()
    g = _graph._graph
    nodes: int = g.number_of_nodes()
    edges: int = g.number_of_edges()

    semantic_edges: int = sum(
        1 for _, _, data in g.edges(data=True)
        if data.get("edge_type") == "SEMANTIC"
    )
    manual_edges: int = sum(
        1 for _, _, data in g.edges(data=True)
        if data.get("edge_type") == "MANUAL"
    )
    avg_edges_per_node: float = round(edges / nodes, 4) if nodes > 0 else 0.0

    return {
        "nodes": nodes,
        "edges": edges,
        "semantic_edges": semantic_edges,
        "manual_edges": manual_edges,
        "avg_edges_per_node": avg_edges_per_node,
    }


@mcp.tool()
def get_compression_stats(wing: str, room: str) -> dict:
    """Measure PAO compression ratio for a Wing/Room.

    Samples stored SAO triplets from the given room, counts their total
    word count (compressed form), then estimates the raw session size
    by applying the PAO expansion model (one triplet ≈ 15-word sentence).
    Reports whether the KPI (≥ 5:1) and KRA (TKD ≥ 3×) thresholds are met.

    Args:
        wing: Wing namespace of the PAO archive.
        room: Room name within the wing.

    Returns:
        Dict with ``raw_token_estimate``, ``compressed_token_estimate``,
        ``compression_ratio``, ``kpi_compression_met``, ``kra_tkd_met``.
    """
    _require_configured()
    _validate_str(wing, "wing")
    _validate_str(room, "room")

    # Sample PAO triplet chunks from the room
    probe_embedding: list[float] = _embedder.embed(
        "subject action object session triplet archive"
    )
    sample: list[dict] = _loci_store.query(wing, room, probe_embedding, 50)

    if not sample:
        return {
            "raw_token_estimate": 0,
            "compressed_token_estimate": 0,
            "compression_ratio": 0.0,
            "kpi_compression_met": False,
            "kra_tkd_met": False,
        }

    # Compressed word count from sampled triplets
    sampled_words: int = sum(len(c["text"].split()) for c in sample)

    # Extrapolate to total room size
    rooms: list[dict] = _loci_store.list_rooms()
    room_info: dict | None = next(
        (r for r in rooms if r["wing"] == wing and r["room"] == room), None
    )
    total_chunks: int = room_info["count"] if room_info else len(sample)
    scale: float = total_chunks / len(sample)
    compressed_total: int = max(1, int(sampled_words * scale))

    # Raw estimate: each SAO triplet compresses ~15 words of original session text
    _PAO_EXPANSION_FACTOR: int = 15
    raw_total: int = compressed_total * _PAO_EXPANSION_FACTOR

    ratio: float = raw_total / compressed_total if compressed_total > 0 else 0.0

    return {
        "raw_token_estimate": raw_total,
        "compressed_token_estimate": compressed_total,
        "compression_ratio": round(ratio, 2),
        "kpi_compression_met": ratio >= 5.0,
        "kra_tkd_met": ratio >= 3.0,
    }


@mcp.tool()
def get_latency_report() -> dict:
    """Return retrieval latency report.

    Note: Returns a placeholder until Phase 11 (PulseGuard) is complete.

    Returns:
        Dict with ``status`` key when PulseGuard is unavailable, or
        ``p50_ms``, ``p95_ms``, ``p99_ms``, ``kpi_latency_met`` once active.
    """
    # PulseGuard not yet implemented — return graceful placeholder
    return {"status": "PulseGuard not yet active"}
