"""src/tools — MCP Tool Layer (Phase 8)."""
