"""src/server.py — Phase 9: MemShān MCP Server Entry Point.

Wires all layers together and starts the MCP server.

Boot sequence
-------------
1. Load Settings from .env.
2. Construct Embedder, ChromaDB PersistentClient, LociStore.
3. Construct KnowledgeGraph; load GraphML from disk if it exists.
4. Construct PhoneticEncoder, LLMClient, SessionSnapshot, RetrievalPipeline.
5. Call mcp_tools.configure() to inject all dependencies.
6. Call mcp.run() to start serving MCP requests.

SOLID compliance
----------------
S — Single responsibility: bootstrap and wire; no business logic.
O — New layers added to _build_dependencies; no modification to run().
L — No subclasses; run() is the sole public surface.
I — Narrow interface: one public function (run).
D — Depends on abstractions (LLMClient, LociStore) not concretions.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import chromadb

from src.tools.mcp_tools import configure, mcp

if TYPE_CHECKING:
    from src.base.embedder import Embedder
    from src.base.loci_store import LociStore
    from src.config import Settings
    from src.layers.major_system.phonetic_encoder import PhoneticEncoder
    from src.layers.pao.snapshot import SessionSnapshot
    from src.layers.songlines.knowledge_graph import KnowledgeGraph
    from src.llm.client import LLMClient
    from src.pipeline.retrieval import RetrievalPipeline

# Path for persisting the knowledge graph alongside ChromaDB data
_GRAPH_FILENAME: str = "graph.graphml"


def _build_dependencies(settings: Settings) -> tuple:
    """Construct all layer dependencies from *settings*.

    Returns
    -------
    tuple
        ``(pipeline, graph, snapshot, loci_store, embedder, encoder)``
    """
    from src.base.embedder import Embedder
    from src.base.loci_store import LociStore
    from src.layers.major_system.phonetic_encoder import PhoneticEncoder
    from src.layers.pao.snapshot import SessionSnapshot
    from src.layers.songlines.knowledge_graph import KnowledgeGraph
    from src.pipeline.retrieval import RetrievalPipeline

    # Layer 0 — Base: embedding + vector store
    embedder: Embedder = Embedder(settings.embedding_model)
    client: chromadb.ClientAPI = chromadb.PersistentClient(
        path=settings.chroma_persist_dir
    )
    loci_store: LociStore = LociStore(client)

    # Layer 2 — Songlines: knowledge graph (load from disk if available)
    graph: KnowledgeGraph = KnowledgeGraph()
    graph_path: Path = Path(settings.chroma_persist_dir) / _GRAPH_FILENAME
    if graph_path.exists():
        graph.load(str(graph_path))

    # Layer 1 — Major System: phonetic encoder
    encoder: PhoneticEncoder = PhoneticEncoder()

    # Layer 3 — PAO: LLM client + session snapshot
    llm: LLMClient = settings.get_llm_client()
    snapshot: SessionSnapshot = SessionSnapshot(loci_store, embedder, graph, llm)

    # Unified retrieval pipeline (Layers 0-2)
    pipeline: RetrievalPipeline = RetrievalPipeline(
        loci_store, embedder, graph, encoder
    )

    return pipeline, graph, snapshot, loci_store, embedder, encoder


def run() -> None:
    """Initialise all dependencies and start the MCP server.

    This is the sole public entry point.  Called by ``main.py``.
    """
    from src.config import Settings

    settings: Settings = Settings()

    pipeline, graph, snapshot, loci_store, embedder, encoder = (
        _build_dependencies(settings)
    )

    configure(pipeline, graph, snapshot, loci_store, embedder, settings)

    mcp.run()


if __name__ == "__main__":  # pragma: no cover
    run()
