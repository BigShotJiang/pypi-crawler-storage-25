"""src/layers/major_system/phonetic_encoder — Layer 1: Major System.

Converts digit sequences found in text into phonetic consonant tags using the
standard Major System mapping.  These tags are attached to ChromaDB chunk
metadata so numeric values can be retrieved with precision alongside semantic
similarity search.

Standard Major System digit → consonant mapping:

    0 → s / z
    1 → t / d
    2 → n
    3 → m
    4 → r
    5 → l
    6 → sh / ch / j
    7 → k / g
    8 → f / v
    9 → p / b
"""

import re


# ---------------------------------------------------------------------------
# Encoding table — digit → canonical consonant (first sound listed per digit)
# ---------------------------------------------------------------------------
_DIGIT_TO_CONSONANT: dict[str, str] = {
    "0": "s",
    "1": "t",
    "2": "n",
    "3": "m",
    "4": "r",
    "5": "l",
    "6": "sh",
    "7": "k",
    "8": "f",
    "9": "p",
}

# Pattern that identifies contiguous digit sequences in arbitrary text
_DIGIT_PATTERN: re.Pattern = re.compile(r"\d+")


class PhoneticEncoder:
    """Convert digit sequences in text to phonetic consonant tags (Major System).

    Single Responsibility: apply the Major System mnemonic encoding to numbers,
    producing tags that can be stored as ChromaDB metadata for precise
    numeric recall.

    This class is stateless — all methods are pure functions of their inputs.
    """

    def encode_number(self, number_str: str) -> str:
        """Encode a contiguous digit string to its phonetic consonant sequence.

        Each digit is mapped to a single consonant (or digraph) using the
        standard Major System table.  Non-digit characters in *number_str*
        are silently skipped.

        Args:
            number_str: A string containing digit characters (e.g. ``"42"``).

        Returns:
            The concatenated phonetic consonants (e.g. ``"rn"`` for ``"42"``).
            Returns an empty string if *number_str* contains no digits.

        Examples:
            ``encode_number("42")``  → ``"rn"``
            ``encode_number("10")``  → ``"ts"``
            ``encode_number("6")``   → ``"sh"``
        """
        return "".join(
            _DIGIT_TO_CONSONANT[ch] for ch in number_str if ch in _DIGIT_TO_CONSONANT
        )

    def extract_and_tag(self, text: str) -> dict:
        """Find all digit sequences in *text* and return their phonetic tags.

        Scans the input for contiguous runs of digits using a regex, encodes
        each run with :meth:`encode_number`, and returns a dict suitable for
        merging directly into ChromaDB chunk metadata.

        Args:
            text: Arbitrary text that may contain zero or more digit sequences.

        Returns:
            A dict with two keys:

            - ``"phonetic_tags"``  — ``list[str]``: one phonetic string per
              digit sequence found, in left-to-right order.
            - ``"numeric_tokens"`` — ``list[str]``: the raw digit sequences
              extracted, in the same order.

            Both lists are empty when *text* contains no digits.

        Examples:
            ``extract_and_tag("meeting at 42 days and 10 hours")``
            → ``{"phonetic_tags": ["rn", "ts"], "numeric_tokens": ["42", "10"]}``

            ``extract_and_tag("no numbers here")``
            → ``{"phonetic_tags": [], "numeric_tokens": []}``
        """
        numeric_tokens: list[str] = _DIGIT_PATTERN.findall(text)
        phonetic_tags: list[str] = [self.encode_number(tok) for tok in numeric_tokens]
        return {"phonetic_tags": phonetic_tags, "numeric_tokens": numeric_tokens}
