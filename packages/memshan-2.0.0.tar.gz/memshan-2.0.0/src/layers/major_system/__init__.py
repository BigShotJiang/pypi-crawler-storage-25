"""src/layers/major_system — Layer 1: Major System (Numerical Precision)."""
