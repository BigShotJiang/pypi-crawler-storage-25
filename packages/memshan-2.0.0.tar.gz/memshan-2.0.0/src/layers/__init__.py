"""src/layers — Optimisation layers for MemShān (Major System, Songlines, PAO)."""
