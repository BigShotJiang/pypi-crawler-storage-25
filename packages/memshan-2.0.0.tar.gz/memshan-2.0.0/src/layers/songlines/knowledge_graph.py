"""src/layers/songlines/knowledge_graph.py — Layer 2: Songlines (Contextual Continuity).

KnowledgeGraph wraps a NetworkX directed graph and persists it as GraphML.

Node types
----------
- ``chunk``   — a stored memory chunk (chunk_id, wing, room, text_preview, …)
- ``concept`` — a named entity or SAO subject/object extracted from text

Edge types
----------
- ``SEQUENTIAL``  — chunk stored shortly after another in the same session
- ``SEMANTIC``    — two chunks share cosine similarity above threshold
- ``SAO_SUBJECT`` — a chunk's subject links to a concept node
- ``SAO_OBJECT``  — a chunk's object links to a concept node
- ``MANUAL``      — a user-defined trail via the ``add_context_trail`` MCP tool
"""

from __future__ import annotations

from pathlib import Path

import networkx as nx

# ---------------------------------------------------------------------------
# Module-level constants (immutable — no global mutable state)
# ---------------------------------------------------------------------------

_VALID_EDGE_TYPES: frozenset[str] = frozenset(
    {"SEQUENTIAL", "SEMANTIC", "SAO_SUBJECT", "SAO_OBJECT", "MANUAL"}
)


class KnowledgeGraph:
    """Directed knowledge graph for recording and traversing context trails.

    SOLID compliance
    ----------------
    S — Manages graph structure only; no LLM, no ChromaDB, no embedding logic.
    O — New edge/node types can be added without modifying existing methods.
    L — No subclasses yet; designed to be subclassed without breaking callers.
    I — Small, focused public interface; callers see only what they need.
    D — No concrete dependencies injected; NetworkX imported but not injected
        (acceptable: it's an infrastructure lib with no test-time swap needed).
    """

    def __init__(self) -> None:
        self._graph: nx.DiGraph = nx.DiGraph()

    # ------------------------------------------------------------------
    # Node management
    # ------------------------------------------------------------------

    def add_chunk_node(self, chunk_id: str, metadata: dict) -> None:
        """Add (or update) a chunk node, merging *metadata* as node attributes.

        GraphML serialisation requires all attribute values to be primitive
        types (str, int, float, bool). Callers are responsible for flattening
        complex values before calling this method.
        """
        self._graph.add_node(chunk_id, node_type="chunk", **metadata)

    def add_concept_node(self, concept: str) -> None:
        """Add (or update) a concept node identified by *concept* string."""
        self._graph.add_node(concept, node_type="concept")

    # ------------------------------------------------------------------
    # Edge management
    # ------------------------------------------------------------------

    def add_edge(
        self,
        from_id: str,
        to_id: str,
        edge_type: str,
        weight: float = 1.0,
    ) -> None:
        """Add a directed edge from *from_id* to *to_id*.

        Args:
            from_id:   Source node identifier.
            to_id:     Target node identifier.
            edge_type: Must be one of the recognised edge type constants.
            weight:    Numeric edge weight (default 1.0).

        Raises:
            ValueError: If *edge_type* is not a recognised type.
        """
        if edge_type not in _VALID_EDGE_TYPES:
            raise ValueError(
                f"Invalid edge_type: {edge_type!r}. "
                f"Must be one of {sorted(_VALID_EDGE_TYPES)}."
            )
        self._graph.add_edge(from_id, to_id, edge_type=edge_type, weight=weight)

    # ------------------------------------------------------------------
    # Graph traversal
    # ------------------------------------------------------------------

    def get_neighbors(self, node_id: str, depth: int = 1) -> list[str]:
        """Return all nodes reachable from *node_id* within *depth* hops.

        Only follows directed edges (successors). Returns an empty list when
        *node_id* is absent from the graph or has no outgoing edges.
        """
        if node_id not in self._graph:
            return []
        reachable = nx.single_source_shortest_path_length(
            self._graph, node_id, cutoff=depth
        )
        return [n for n in reachable if n != node_id]

    def get_trail(self, from_id: str, to_id: str) -> list[str]:
        """Return the shortest directed path between *from_id* and *to_id*.

        Returns an empty list when no path exists or when either node is
        absent from the graph.
        """
        try:
            return list(nx.shortest_path(self._graph, from_id, to_id))
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return []

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self, path: str) -> None:
        """Serialise the graph to GraphML at *path*, creating parent dirs."""
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        nx.write_graphml(self._graph, path)

    def load(self, path: str) -> None:
        """Replace the current graph by loading a GraphML file from *path*."""
        self._graph = nx.read_graphml(path)
