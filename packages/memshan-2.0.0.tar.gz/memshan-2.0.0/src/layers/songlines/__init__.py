"""src/layers/songlines — Layer 2: Songlines (Contextual Continuity / NetworkX)."""
