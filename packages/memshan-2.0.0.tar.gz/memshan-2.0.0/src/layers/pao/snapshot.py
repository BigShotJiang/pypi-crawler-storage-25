"""src/layers/pao/snapshot.py — Layer 3: PAO System (Episodic Compression).

SessionSnapshot compresses session logs into Subject-Action-Object (SAO) triplets
and archives them into the ``long_term`` Wing of the Loci Store.

Extraction strategy (tried in order)
-------------------------------------
1. **spaCy dependency parse** — fast, local, no LLM cost.
   Extracts (nsubj → ROOT verb → dobj/pobj) triples from each sentence.
2. **LLM fallback** — when spaCy yields fewer than 1 triplet, call
   ``LLMClient.complete()`` with a structured JSON prompt.
"""

from __future__ import annotations

import json
import uuid

import spacy

from src.base.embedder import Embedder
from src.base.loci_store import LociStore
from src.layers.songlines.knowledge_graph import KnowledgeGraph
from src.llm.client import LLMClient

# ---------------------------------------------------------------------------
# Module-level constants
# ---------------------------------------------------------------------------

_LLM_SYSTEM_PROMPT: str = (
    "You are a knowledge extraction assistant. "
    "Extract Subject-Action-Object triplets from the text. "
    "Return ONLY a JSON array of objects with keys "
    "'subject', 'action', 'object'. No prose, no markdown."
)

_LLM_USER_TEMPLATE: str = (
    "Extract SAO triplets from the following text:\n\n{text}\n\n"
    "Return only a JSON array."
)


class SessionSnapshot:
    """Compresses session logs into SAO triplets and archives them.

    SOLID compliance
    ----------------
    S — Handles only PAO compression + archival; no server/transport logic.
    O — Extend extraction strategies via subclass; do not modify this class.
    L — Substitutable wherever a snapshot service is expected.
    I — Narrow interface: two public methods only.
    D — All dependencies injected via constructor; no concrete imports in
        business logic (``LLMClient`` ABC used, not a concrete provider).
    """

    def __init__(
        self,
        loci_store: LociStore,
        embedder: Embedder,
        graph: KnowledgeGraph,
        llm: LLMClient,
    ) -> None:
        """Initialise with all required layer dependencies.

        Args:
            loci_store: ChromaDB Wing/Room abstraction for archival.
            embedder:   Sentence-transformer embedding utility.
            graph:      Songlines knowledge graph for context trails.
            llm:        LLM client for triplet extraction fallback.

        Raises:
            ValueError: If any dependency is None.
        """
        if loci_store is None:
            raise ValueError("loci_store must not be None.")
        if embedder is None:
            raise ValueError("embedder must not be None.")
        if graph is None:
            raise ValueError("graph must not be None.")
        if llm is None:
            raise ValueError("llm must not be None.")

        self._store: LociStore = loci_store
        self._embedder: Embedder = embedder
        self._graph: KnowledgeGraph = graph
        self._llm: LLMClient = llm
        self._nlp = spacy.load("en_core_web_sm")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def extract_triplets(self, text: str) -> list[dict]:
        """Extract SAO triplets from *text*.

        Tries spaCy dependency parsing first. Falls back to the LLM when
        spaCy yields zero triplets.

        Args:
            text: Raw text to analyse.

        Returns:
            A list of dicts, each with keys ``subject``, ``action``, ``object``.
            Returns an empty list if both strategies yield nothing.
        """
        triplets = self._extract_with_spacy(text)
        if not triplets:
            triplets = self._extract_with_llm(text)
        return triplets

    def snapshot_session(
        self,
        session_id: str,
        exchanges: list[str],
        wing: str = "long_term",
        room: str = "sessions",
    ) -> list[str]:
        """Compress *exchanges* into SAO triplets and archive them.

        Steps:
        1. Concatenate *exchanges* into one full session text.
        2. Call ``extract_triplets()`` to get SAO triplets.
        3. For each triplet: embed the textual form and upsert into LociStore.
        4. Add a chunk node to the KnowledgeGraph.
        5. Add SAO_SUBJECT and SAO_OBJECT edges to concept nodes.

        Args:
            session_id: Unique identifier for this session (used as a
                        chunk_id prefix).
            exchanges:  List of text exchanges making up the session.
            wing:       Target Wing in the Loci Store (default ``long_term``).
            room:       Target Room in the Loci Store (default ``sessions``).

        Returns:
            List of chunk_ids for the stored triplets. Empty list if no
            triplets were extracted.
        """
        if not exchanges:
            return []

        full_text = " ".join(exchanges)
        triplets = self.extract_triplets(full_text)

        chunk_ids: list[str] = []
        for triplet in triplets:
            chunk_id = f"{session_id}_{uuid.uuid4().hex[:8]}"
            triplet_text = (
                f"{triplet['subject']} {triplet['action']} {triplet['object']}"
            )
            embedding = self._embedder.embed(triplet_text)
            metadata = {
                "session_id": session_id,
                "subject": triplet["subject"],
                "action": triplet["action"],
                "object": triplet["object"],
            }
            self._store.upsert(
                wing=wing,
                room=room,
                chunk_id=chunk_id,
                text=triplet_text,
                embedding=embedding,
                metadata=metadata,
            )
            self._graph.add_chunk_node(chunk_id, metadata)
            self._graph.add_concept_node(triplet["subject"])
            self._graph.add_concept_node(triplet["object"])
            self._graph.add_edge(chunk_id, triplet["subject"], "SAO_SUBJECT")
            self._graph.add_edge(chunk_id, triplet["object"], "SAO_OBJECT")
            chunk_ids.append(chunk_id)

        return chunk_ids

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _extract_with_spacy(self, text: str) -> list[dict]:
        """Use spaCy dependency parsing to extract SAO triplets.

        For each sentence, looks for a token that is the ROOT verb, then
        finds its nsubj (subject) and dobj/pobj (object) dependents.

        Returns:
            List of ``{"subject", "action", "object"}`` dicts.
        """
        doc = self._nlp(text)
        triplets: list[dict] = []

        for sent in doc.sents:
            subject: str | None = None
            action: str | None = None
            obj: str | None = None

            for token in sent:
                if token.dep_ == "ROOT":
                    action = token.lemma_
                    for child in token.children:
                        if child.dep_ == "nsubj":
                            subject = child.text
                        elif child.dep_ in ("dobj", "pobj"):
                            obj = child.text

            if subject and action and obj:
                triplets.append(
                    {"subject": subject, "action": action, "object": obj}
                )

        return triplets

    def _extract_with_llm(self, text: str) -> list[dict]:
        """Use the LLM to extract SAO triplets when spaCy yields nothing.

        Sends a structured JSON extraction prompt; parses the response as a
        JSON array. Returns an empty list on any parse failure.

        Returns:
            List of ``{"subject", "action", "object"}`` dicts, or ``[]``.
        """
        prompt = _LLM_USER_TEMPLATE.format(text=text)
        try:
            response = self._llm.complete(prompt, system=_LLM_SYSTEM_PROMPT)
            raw = json.loads(response)
            if not isinstance(raw, list):
                return []
            result: list[dict] = []
            for item in raw:
                if (
                    isinstance(item, dict)
                    and "subject" in item
                    and "action" in item
                    and "object" in item
                ):
                    result.append(
                        {
                            "subject": str(item["subject"]),
                            "action": str(item["action"]),
                            "object": str(item["object"]),
                        }
                    )
            return result
        except (json.JSONDecodeError, Exception):
            return []
