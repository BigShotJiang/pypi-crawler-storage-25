"""src/layers/pao — Layer 3: PAO System (Episodic Compression / SAO triplets)."""
