"""
src/llm/client.py — Abstract base class for all LLM provider adapters.

Design notes (SOLID)
--------------------
- Single Responsibility : defines *only* the contract for text completion.
- Open/Closed           : new providers add a new subclass — this file never changes.
- Liskov Substitution   : every concrete adapter is fully substitutable here.
- Interface Segregation : one narrow method (``complete``) — no fat interface.
- Dependency Inversion  : all business logic (retrieval, snapshot) imports this
                          ABC only, never a concrete provider class.
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class LLMClient(ABC):
    """Contract that every LLM provider adapter must satisfy.

    Callers must depend on this class exclusively — never on a concrete
    implementation.  The factory in ``src.config.Settings.get_llm_client``
    is the single place that resolves a concrete adapter.
    """

    @abstractmethod
    def complete(self, prompt: str, *, system: str | None = None) -> str:
        """Send *prompt* to the LLM and return the text completion.

        Parameters
        ----------
        prompt:
            The user-facing text to send to the model.
        system:
            Optional system/instruction message.  Providers that do not
            support a dedicated system role should prepend it to the prompt.

        Returns
        -------
        str
            The model's text response, stripped of leading/trailing whitespace.

        Raises
        ------
        RuntimeError
            If the provider is unreachable or returns a non-2xx response.
        """
