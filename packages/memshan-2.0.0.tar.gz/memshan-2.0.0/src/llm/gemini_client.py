"""
src/llm/gemini_client.py — Google Gemini LLM adapter.

Uses the ``google-genai`` SDK (``from google import genai``).
Raises ``ValueError`` at construction time if the API key is absent.

Design notes (SOLID)
--------------------
- Single Responsibility : Gemini SDK transport only.
- Liskov Substitution   : fully substitutable for ``LLMClient``.
- Dependency Inversion  : receives ``api_key`` and ``model`` via constructor.
"""

from __future__ import annotations

import google.genai as genai
from google.genai import types

from src.llm.client import LLMClient


class GeminiClient(LLMClient):
    """``LLMClient`` implementation backed by Google Gemini.

    Parameters
    ----------
    api_key:
        Gemini API key (``AIza...``).  Must be non-empty.
    model:
        Model name, e.g. ``gemini-2.5-flash``.

    Raises
    ------
    ValueError
        At construction time if *api_key* is ``None`` or empty.
    """

    def __init__(self, api_key: str | None, model: str) -> None:
        if not api_key:
            raise ValueError(
                "GEMINI_API_KEY is required when LLM_PROVIDER=gemini. "
                "Add it to your .env file."
            )
        self._model = model
        self._client = genai.Client(api_key=api_key)

    def complete(self, prompt: str, *, system: str | None = None) -> str:
        """Send *prompt* to Gemini and return the text completion.

        Parameters
        ----------
        prompt:
            User prompt.
        system:
            Optional system instruction passed to the model via
            ``GenerateContentConfig.system_instruction``.

        Returns
        -------
        str
            Stripped text from the first candidate.

        Raises
        ------
        RuntimeError
            If the Gemini API returns an error.
        """
        config: types.GenerateContentConfig | None = (
            types.GenerateContentConfig(system_instruction=system)
            if system
            else None
        )

        try:
            response = self._client.models.generate_content(
                model=self._model,
                contents=prompt,
                config=config,
            )
        except Exception as exc:
            raise RuntimeError(f"Gemini API error: {exc}") from exc

        return response.text.strip()
