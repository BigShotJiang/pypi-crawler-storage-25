"""
src/llm/anthropic_client.py — Anthropic Claude LLM adapter.

Uses the official ``anthropic`` SDK.  Raises ``ValueError`` at construction
time if the API key is absent.

Design notes (SOLID)
--------------------
- Single Responsibility : Anthropic SDK transport only.
- Liskov Substitution   : fully substitutable for ``LLMClient``.
- Dependency Inversion  : receives ``api_key`` and ``model`` via constructor.
"""

from __future__ import annotations

import anthropic

from src.llm.client import LLMClient

_MAX_TOKENS = 1024


class AnthropicClient(LLMClient):
    """``LLMClient`` implementation backed by Anthropic Claude.

    Parameters
    ----------
    api_key:
        Anthropic API key (``sk-ant-...``).  Must be non-empty.
    model:
        Model name, e.g. ``claude-3-5-haiku-latest``.

    Raises
    ------
    ValueError
        At construction time if *api_key* is ``None`` or empty.
    """

    def __init__(self, api_key: str | None, model: str) -> None:
        if not api_key:
            raise ValueError(
                "ANTHROPIC_API_KEY is required when LLM_PROVIDER=anthropic. "
                "Add it to your .env file."
            )
        self._model = model
        self._client = anthropic.Anthropic(api_key=api_key)

    def complete(self, prompt: str, *, system: str | None = None) -> str:
        """Send *prompt* to Claude and return the text completion.

        Parameters
        ----------
        prompt:
            User prompt.
        system:
            Optional system message passed to the ``system`` parameter of
            ``messages.create``.

        Returns
        -------
        str
            Stripped text of the first content block.

        Raises
        ------
        RuntimeError
            If the Anthropic API returns an error.
        """
        kwargs: dict = {
            "model": self._model,
            "max_tokens": _MAX_TOKENS,
            "messages": [{"role": "user", "content": prompt}],
        }
        if system:
            kwargs["system"] = system

        try:
            response = self._client.messages.create(**kwargs)
        except anthropic.AnthropicError as exc:
            raise RuntimeError(f"Anthropic API error: {exc}") from exc

        return response.content[0].text.strip()
