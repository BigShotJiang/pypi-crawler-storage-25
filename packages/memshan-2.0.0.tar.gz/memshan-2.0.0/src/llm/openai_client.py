"""
src/llm/openai_client.py — OpenAI LLM adapter.

Uses the ``openai`` SDK (>=1.0).  Raises ``ValueError`` at construction time
if the API key is absent, so failures surface immediately rather than at
first call.

Design notes (SOLID)
--------------------
- Single Responsibility : OpenAI SDK transport only.
- Liskov Substitution   : fully substitutable for ``LLMClient``.
- Dependency Inversion  : receives ``api_key`` and ``model`` via constructor.
"""

from __future__ import annotations

import openai

from src.llm.client import LLMClient


class OpenAIClient(LLMClient):
    """``LLMClient`` implementation backed by the OpenAI API.

    Parameters
    ----------
    api_key:
        OpenAI API key (``sk-...``).  Must be non-empty.
    model:
        Model name, e.g. ``gpt-4o-mini``.

    Raises
    ------
    ValueError
        At construction time if *api_key* is ``None`` or empty.
    """

    def __init__(self, api_key: str | None, model: str) -> None:
        if not api_key:
            raise ValueError(
                "OPENAI_API_KEY is required when LLM_PROVIDER=openai. "
                "Add it to your .env file."
            )
        self._model = model
        self._client = openai.OpenAI(api_key=api_key)

    def complete(self, prompt: str, *, system: str | None = None) -> str:
        """Send *prompt* to OpenAI and return the text completion.

        Parameters
        ----------
        prompt:
            User prompt.
        system:
            Optional system message sent as the ``system`` role.

        Returns
        -------
        str
            Stripped text from the first choice.

        Raises
        ------
        RuntimeError
            If the OpenAI API returns an error.
        """
        messages: list[dict] = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        try:
            response = self._client.chat.completions.create(
                model=self._model,
                messages=messages,
            )
        except openai.OpenAIError as exc:
            raise RuntimeError(f"OpenAI API error: {exc}") from exc

        content = response.choices[0].message.content or ""
        return content.strip()
