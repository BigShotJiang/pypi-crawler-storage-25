"""
src/llm/ollama_client.py — Ollama LLM adapter (default local provider).

POSTs to the Ollama HTTP API at ``/api/generate``.  No API key required.
Fully offline — the recommended default for MemShān.

Design notes (SOLID)
--------------------
- Single Responsibility : HTTP transport to Ollama only.
- Liskov Substitution   : fully substitutable for ``LLMClient``.
- Dependency Inversion  : injects ``base_url`` and ``model`` via constructor
                          (received from ``Settings`` — no direct env reads).
"""

from __future__ import annotations

import httpx

from src.llm.client import LLMClient

_GENERATE_PATH = "/api/generate"
_TIMEOUT_SECONDS = 120.0


class OllamaClient(LLMClient):
    """``LLMClient`` implementation backed by a local Ollama instance.

    Parameters
    ----------
    base_url:
        Base URL of the Ollama server, e.g. ``http://localhost:11434``.
    model:
        Ollama model tag to use, e.g. ``llama3.2``.

    Raises
    ------
    RuntimeError
        Raised at *call time* (inside ``complete``) if Ollama is unreachable
        or returns a non-2xx response.
    """

    def __init__(self, base_url: str, model: str) -> None:
        self._base_url = base_url.rstrip("/")
        self._model = model

    def complete(self, prompt: str, *, system: str | None = None) -> str:
        """Send *prompt* to Ollama and return the text response.

        Parameters
        ----------
        prompt:
            User prompt text.
        system:
            Optional system instruction.  Prepended to the prompt if provided
            (Ollama's ``/api/generate`` endpoint does not have a dedicated
            system field in all versions).

        Returns
        -------
        str
            Stripped text completion from the model.

        Raises
        ------
        RuntimeError
            If the HTTP request fails or Ollama returns a non-2xx status.
        """
        full_prompt = f"{system}\n\n{prompt}" if system else prompt
        payload: dict = {
            "model": self._model,
            "prompt": full_prompt,
            "stream": False,
        }

        try:
            response = httpx.post(
                f"{self._base_url}{_GENERATE_PATH}",
                json=payload,
                timeout=_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
        except httpx.ConnectError as exc:
            raise RuntimeError(
                f"Ollama is unreachable at '{self._base_url}'. "
                "Ensure Ollama is running: https://ollama.com"
            ) from exc
        except httpx.HTTPStatusError as exc:
            raise RuntimeError(
                f"Ollama returned HTTP {exc.response.status_code}: "
                f"{exc.response.text}"
            ) from exc
        except httpx.RequestError as exc:
            raise RuntimeError(
                f"Ollama request failed: {exc}"
            ) from exc

        data = response.json()
        return str(data.get("response", "")).strip()
