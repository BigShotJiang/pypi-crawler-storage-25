"""tests/test_ollama_client.py — Unit tests for OllamaClient.

Covers:
- src/llm/ollama_client.py (OllamaClient)

All HTTP calls are mocked — no real network traffic is made.
One class per file — Separation of Concerns principle.
"""

from __future__ import annotations

import httpx
import pytest

from src.llm.ollama_client import OllamaClient


class TestOllamaClient:

    # ── helpers ───────────────────────────────────────────────────────────────

    @staticmethod
    def _mock_post(mocker, response_text: str):
        """Return a mocker patch for httpx.post with a canned Ollama reply."""
        mock_resp = mocker.MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.return_value = {"response": response_text}
        return mocker.patch("httpx.post", return_value=mock_resp)

    # ── positive ──────────────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_complete_strips_whitespace_from_response(self, mocker):
        """complete() strips leading/trailing whitespace from Ollama response."""
        self._mock_post(mocker, "  hello world  ")
        client = OllamaClient(base_url="http://localhost:11434", model="llama3.2")
        assert client.complete("What is AI?") == "hello world"

    @pytest.mark.positive
    def test_complete_with_system_prepends_to_prompt(self, mocker):
        """System prompt is prepended to the user prompt in the payload."""
        mock_post = self._mock_post(mocker, "answer")
        client = OllamaClient(base_url="http://localhost:11434", model="llama3.2")
        client.complete("question", system="You are helpful.")

        payload = mock_post.call_args.kwargs["json"]
        assert "You are helpful." in payload["prompt"]
        assert "question" in payload["prompt"]

    # ── negative ──────────────────────────────────────────────────────────────

    @pytest.mark.negative
    def test_connect_error_raises_runtime_error(self, mocker):
        """ConnectError is wrapped in RuntimeError with helpful Ollama message."""
        mocker.patch("httpx.post", side_effect=httpx.ConnectError("refused"))
        client = OllamaClient(base_url="http://localhost:11434", model="llama3.2")
        with pytest.raises(RuntimeError, match="Ollama is unreachable"):
            client.complete("prompt")

    @pytest.mark.negative
    def test_http_status_error_raises_runtime_error(self, mocker):
        """Non-2xx HTTP response is wrapped in RuntimeError with status code."""
        req = httpx.Request("POST", "http://localhost:11434/api/generate")
        resp = httpx.Response(503, request=req)
        exc = httpx.HTTPStatusError("503 error", request=req, response=resp)
        mocker.patch("httpx.post", side_effect=exc)

        client = OllamaClient(base_url="http://localhost:11434", model="llama3.2")
        with pytest.raises(RuntimeError, match="503"):
            client.complete("prompt")

    @pytest.mark.negative
    def test_request_error_raises_runtime_error(self, mocker):
        """Generic httpx.RequestError is wrapped in RuntimeError."""
        mocker.patch("httpx.post", side_effect=httpx.RequestError("timeout"))
        client = OllamaClient(base_url="http://localhost:11434", model="llama3.2")
        with pytest.raises(RuntimeError, match="Ollama request failed"):
            client.complete("prompt")

    # ── edge ──────────────────────────────────────────────────────────────────

    @pytest.mark.edge
    def test_missing_response_key_returns_empty_string(self, mocker):
        """Absent 'response' key in JSON returns '' without crashing."""
        mock_resp = mocker.MagicMock()
        mock_resp.raise_for_status.return_value = None
        mock_resp.json.return_value = {}
        mocker.patch("httpx.post", return_value=mock_resp)
        client = OllamaClient(base_url="http://localhost:11434", model="llama3.2")
        assert client.complete("prompt") == ""

    @pytest.mark.edge
    def test_base_url_trailing_slash_is_normalised(self, mocker):
        """Trailing slash in base_url is stripped so the path never doubles."""
        mock_post = self._mock_post(mocker, "ok")
        client = OllamaClient(base_url="http://localhost:11434/", model="llama3.2")
        client.complete("prompt")
        url: str = mock_post.call_args.args[0]
        assert url == "http://localhost:11434/api/generate"
