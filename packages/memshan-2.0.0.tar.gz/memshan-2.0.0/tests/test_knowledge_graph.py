"""tests/test_knowledge_graph.py — Unit tests for KnowledgeGraph.

Coverage targets: 100% line + branch.
Scenarios: Positive, Negative, Edge.
"""

from __future__ import annotations

import os

import pytest

from src.layers.songlines.knowledge_graph import KnowledgeGraph


class TestKnowledgeGraph:
    """Unit tests for the Songlines KnowledgeGraph."""

    # ------------------------------------------------------------------
    # Fixtures
    # ------------------------------------------------------------------

    @pytest.fixture()
    def graph(self) -> KnowledgeGraph:
        """Return a fresh, empty KnowledgeGraph for each test."""
        return KnowledgeGraph()

    # ------------------------------------------------------------------
    # Positive — happy-path tests
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_add_chunk_node_stores_node_type(self, graph: KnowledgeGraph) -> None:
        """add_chunk_node sets node_type='chunk' on the created node."""
        graph.add_chunk_node("c1", {"wing": "work", "room": "projects"})
        data = graph._graph.nodes["c1"]
        assert data["node_type"] == "chunk"

    @pytest.mark.positive
    def test_add_chunk_node_stores_metadata(self, graph: KnowledgeGraph) -> None:
        """add_chunk_node merges metadata dict as node attributes."""
        graph.add_chunk_node("c1", {"wing": "work", "room": "projects"})
        data = graph._graph.nodes["c1"]
        assert data["wing"] == "work"
        assert data["room"] == "projects"

    @pytest.mark.positive
    def test_add_concept_node_stores_node_type(self, graph: KnowledgeGraph) -> None:
        """add_concept_node creates a node with node_type='concept'."""
        graph.add_concept_node("Python")
        data = graph._graph.nodes["Python"]
        assert data["node_type"] == "concept"

    @pytest.mark.positive
    def test_add_edge_sequential(self, graph: KnowledgeGraph) -> None:
        """SEQUENTIAL edge is added without error."""
        graph.add_chunk_node("c1", {})
        graph.add_chunk_node("c2", {})
        graph.add_edge("c1", "c2", "SEQUENTIAL")
        assert graph._graph.has_edge("c1", "c2")
        assert graph._graph["c1"]["c2"]["edge_type"] == "SEQUENTIAL"

    @pytest.mark.positive
    def test_add_edge_semantic(self, graph: KnowledgeGraph) -> None:
        """SEMANTIC edge is added with correct weight."""
        graph.add_chunk_node("c1", {})
        graph.add_chunk_node("c2", {})
        graph.add_edge("c1", "c2", "SEMANTIC", weight=0.92)
        assert graph._graph["c1"]["c2"]["weight"] == pytest.approx(0.92)

    @pytest.mark.positive
    def test_add_edge_sao_subject(self, graph: KnowledgeGraph) -> None:
        """SAO_SUBJECT edge is recognised as valid."""
        graph.add_chunk_node("c1", {})
        graph.add_concept_node("Agent")
        graph.add_edge("c1", "Agent", "SAO_SUBJECT")
        assert graph._graph.has_edge("c1", "Agent")

    @pytest.mark.positive
    def test_add_edge_sao_object(self, graph: KnowledgeGraph) -> None:
        """SAO_OBJECT edge is recognised as valid."""
        graph.add_chunk_node("c1", {})
        graph.add_concept_node("Memory")
        graph.add_edge("c1", "Memory", "SAO_OBJECT")
        assert graph._graph.has_edge("c1", "Memory")

    @pytest.mark.positive
    def test_add_edge_manual(self, graph: KnowledgeGraph) -> None:
        """MANUAL edge is recognised as valid."""
        graph.add_chunk_node("c1", {})
        graph.add_chunk_node("c2", {})
        graph.add_edge("c1", "c2", "MANUAL")
        assert graph._graph["c1"]["c2"]["edge_type"] == "MANUAL"

    @pytest.mark.positive
    def test_get_neighbors_depth_one_returns_direct_successors(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_neighbors(depth=1) returns direct successors only."""
        graph.add_chunk_node("A", {})
        graph.add_chunk_node("B", {})
        graph.add_chunk_node("C", {})
        graph.add_edge("A", "B", "SEQUENTIAL")
        graph.add_edge("B", "C", "SEQUENTIAL")
        result = graph.get_neighbors("A", depth=1)
        assert result == ["B"]

    @pytest.mark.positive
    def test_get_neighbors_depth_two_returns_two_hops(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_neighbors(depth=2) returns nodes reachable in up to 2 hops."""
        graph.add_chunk_node("A", {})
        graph.add_chunk_node("B", {})
        graph.add_chunk_node("C", {})
        graph.add_edge("A", "B", "SEQUENTIAL")
        graph.add_edge("B", "C", "SEQUENTIAL")
        result = graph.get_neighbors("A", depth=2)
        assert set(result) == {"B", "C"}

    @pytest.mark.positive
    def test_get_neighbors_fan_out(self, graph: KnowledgeGraph) -> None:
        """get_neighbors returns all direct successors for a fan-out node."""
        graph.add_chunk_node("A", {})
        graph.add_chunk_node("B", {})
        graph.add_chunk_node("C", {})
        graph.add_edge("A", "B", "SEMANTIC")
        graph.add_edge("A", "C", "SEMANTIC")
        result = graph.get_neighbors("A", depth=1)
        assert set(result) == {"B", "C"}

    @pytest.mark.positive
    def test_get_trail_returns_shortest_path(self, graph: KnowledgeGraph) -> None:
        """get_trail returns the ordered shortest path between two nodes."""
        graph.add_chunk_node("A", {})
        graph.add_chunk_node("B", {})
        graph.add_chunk_node("C", {})
        graph.add_edge("A", "B", "SEQUENTIAL")
        graph.add_edge("B", "C", "SEQUENTIAL")
        assert graph.get_trail("A", "C") == ["A", "B", "C"]

    @pytest.mark.positive
    def test_save_creates_graphml_file(
        self, graph: KnowledgeGraph, tmp_path
    ) -> None:
        """save() writes a file at the specified path."""
        graph.add_chunk_node("c1", {"wing": "work"})
        file_path = str(tmp_path / "graph.graphml")
        graph.save(file_path)
        assert os.path.isfile(file_path)

    @pytest.mark.positive
    def test_load_restores_nodes_and_edges(
        self, graph: KnowledgeGraph, tmp_path
    ) -> None:
        """load() restores nodes and edges from a previously saved GraphML file."""
        graph.add_chunk_node("c1", {"wing": "work"})
        graph.add_concept_node("Agent")
        graph.add_edge("c1", "Agent", "SAO_SUBJECT")
        file_path = str(tmp_path / "graph.graphml")
        graph.save(file_path)

        fresh = KnowledgeGraph()
        fresh.load(file_path)
        assert "c1" in fresh._graph
        assert "Agent" in fresh._graph
        assert fresh._graph.has_edge("c1", "Agent")

    @pytest.mark.positive
    def test_add_edge_default_weight_is_one(self, graph: KnowledgeGraph) -> None:
        """add_edge uses weight=1.0 when no weight is supplied."""
        graph.add_chunk_node("c1", {})
        graph.add_chunk_node("c2", {})
        graph.add_edge("c1", "c2", "MANUAL")
        assert graph._graph["c1"]["c2"]["weight"] == pytest.approx(1.0)

    # ------------------------------------------------------------------
    # Negative — error / failure conditions
    # ------------------------------------------------------------------

    @pytest.mark.negative
    def test_add_edge_invalid_type_raises_value_error(
        self, graph: KnowledgeGraph
    ) -> None:
        """add_edge raises ValueError for an unrecognised edge_type."""
        graph.add_chunk_node("c1", {})
        graph.add_chunk_node("c2", {})
        with pytest.raises(ValueError, match="Invalid edge_type"):
            graph.add_edge("c1", "c2", "UNKNOWN_TYPE")

    @pytest.mark.negative
    def test_get_trail_no_path_returns_empty(self, graph: KnowledgeGraph) -> None:
        """get_trail returns [] when both nodes exist but no directed path connects them."""
        graph.add_chunk_node("A", {})
        graph.add_chunk_node("B", {})
        # Nodes exist, but there is no edge A→B
        result = graph.get_trail("A", "B")
        assert result == []

    @pytest.mark.negative
    def test_get_trail_missing_source_returns_empty(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_trail returns [] when the source node is not in the graph."""
        graph.add_chunk_node("B", {})
        result = graph.get_trail("nonexistent", "B")
        assert result == []

    @pytest.mark.negative
    def test_get_trail_missing_target_returns_empty(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_trail returns [] when the target node is not in the graph."""
        graph.add_chunk_node("A", {})
        result = graph.get_trail("A", "nonexistent")
        assert result == []

    # ------------------------------------------------------------------
    # Edge — boundary values, empty inputs, single items
    # ------------------------------------------------------------------

    @pytest.mark.edge
    def test_get_neighbors_unknown_node_returns_empty(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_neighbors returns [] immediately for a node not in the graph."""
        result = graph.get_neighbors("ghost_node")
        assert result == []

    @pytest.mark.edge
    def test_get_neighbors_isolated_node_returns_empty(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_neighbors returns [] for a node in the graph with no outgoing edges."""
        graph.add_chunk_node("lonely", {})
        result = graph.get_neighbors("lonely")
        assert result == []

    @pytest.mark.edge
    def test_get_trail_same_node_returns_singleton(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_trail(a, a) returns [a] — a node reaches itself in 0 hops."""
        graph.add_chunk_node("A", {})
        result = graph.get_trail("A", "A")
        assert result == ["A"]

    @pytest.mark.edge
    def test_save_creates_parent_directories(
        self, graph: KnowledgeGraph, tmp_path
    ) -> None:
        """save() creates intermediate directories when they do not exist."""
        nested = str(tmp_path / "deep" / "nested" / "graph.graphml")
        graph.add_chunk_node("c1", {})
        graph.save(nested)
        assert os.path.isfile(nested)

    @pytest.mark.edge
    def test_add_chunk_node_with_empty_metadata(
        self, graph: KnowledgeGraph
    ) -> None:
        """add_chunk_node accepts an empty metadata dict without error."""
        graph.add_chunk_node("c1", {})
        assert "c1" in graph._graph
        assert graph._graph.nodes["c1"]["node_type"] == "chunk"

    @pytest.mark.edge
    def test_add_chunk_node_update_overwrites_attributes(
        self, graph: KnowledgeGraph
    ) -> None:
        """Calling add_chunk_node a second time updates the node attributes."""
        graph.add_chunk_node("c1", {"wing": "work"})
        graph.add_chunk_node("c1", {"wing": "personal"})
        assert graph._graph.nodes["c1"]["wing"] == "personal"

    @pytest.mark.edge
    def test_get_neighbors_does_not_include_source(
        self, graph: KnowledgeGraph
    ) -> None:
        """get_neighbors never includes the source node itself in the result."""
        graph.add_chunk_node("A", {})
        graph.add_chunk_node("B", {})
        graph.add_edge("A", "B", "SEQUENTIAL")
        result = graph.get_neighbors("A", depth=1)
        assert "A" not in result
