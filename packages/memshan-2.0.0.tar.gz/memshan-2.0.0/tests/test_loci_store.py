"""tests/test_loci_store.py — Unit tests for src/base/loci_store.LociStore.

Uses chromadb.Client() (in-memory, no disk writes).
Coverage targets: 100% line + branch.
Scenarios: Positive, Negative, Edge.
"""

from collections.abc import Generator

import chromadb
import pytest

from src.base.loci_store import LociStore

# ---------------------------------------------------------------------------
# Shared fixture — fresh in-memory store per test, with cleanup on teardown
# ---------------------------------------------------------------------------

_DIM = 4  # small embedding dimension for speed


@pytest.fixture()
def store() -> Generator[LociStore, None, None]:
    """Return a LociStore backed by a shared in-memory ChromaDB client.

    Yields the store, then deletes ALL collections after each test so that
    tests are fully isolated despite ChromaDB sharing a backing store.
    """
    client = chromadb.Client()
    loci = LociStore(client)
    yield loci
    # Teardown: remove all collections so the next test starts clean.
    for col_name in client.list_collections():
        client.delete_collection(str(col_name))


def _vec(value: float = 0.1) -> list[float]:
    """Return a unit embedding vector of length _DIM."""
    return [value] * _DIM


# ---------------------------------------------------------------------------
# Test class
# ---------------------------------------------------------------------------


class TestLociStore:
    """Unit tests for the LociStore Wing/Room abstraction."""

    # ------------------------------------------------------------------
    # Positive — happy-path tests
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_upsert_stores_chunk(self, store: LociStore) -> None:
        """upsert() stores a chunk that can be retrieved with get_by_ids."""
        store.upsert("work", "notes", "c1", "hello", _vec(), {"src": "test"})
        results = store.get_by_ids("work", "notes", ["c1"])

        assert len(results) == 1
        assert results[0]["id"] == "c1"
        assert results[0]["text"] == "hello"
        assert results[0]["metadata"]["src"] == "test"

    @pytest.mark.positive
    def test_query_returns_matching_chunk(self, store: LociStore) -> None:
        """query() returns the stored chunk for a matching embedding."""
        store.upsert("work", "tasks", "t1", "buy milk", _vec(0.5), {"tag": "errand"})
        results = store.query("work", "tasks", _vec(0.5), top_k=1)

        assert len(results) == 1
        assert results[0]["id"] == "t1"
        assert results[0]["text"] == "buy milk"
        assert results[0]["metadata"]["tag"] == "errand"

    @pytest.mark.positive
    def test_query_result_contains_required_keys(self, store: LociStore) -> None:
        """Each result dict from query() contains id, text, metadata, distance."""
        store.upsert("wing", "room", "x1", "content", _vec(), {})
        result = store.query("wing", "room", _vec(), top_k=1)[0]

        assert "id" in result
        assert "text" in result
        assert "metadata" in result
        assert "distance" in result

    @pytest.mark.positive
    def test_list_rooms_returns_correct_wing_and_room(self, store: LociStore) -> None:
        """list_rooms() includes the wing and room created via upsert."""
        store.upsert("personal", "ideas", "i1", "idea one", _vec(), {})
        rooms = store.list_rooms()

        assert any(r["wing"] == "personal" and r["room"] == "ideas" for r in rooms)

    @pytest.mark.positive
    def test_list_rooms_count_reflects_upserts(self, store: LociStore) -> None:
        """list_rooms() count equals the number of chunks upserted."""
        store.upsert("work", "docs", "d1", "doc 1", _vec(0.1), {})
        store.upsert("work", "docs", "d2", "doc 2", _vec(0.2), {})
        rooms = store.list_rooms()

        work_docs = next(
            r for r in rooms if r["wing"] == "work" and r["room"] == "docs"
        )
        assert work_docs["count"] == 2

    @pytest.mark.positive
    def test_get_by_ids_returns_subset_of_chunks(self, store: LociStore) -> None:
        """get_by_ids() returns only the requested IDs from a larger collection."""
        store.upsert("w", "r", "a", "alpha", _vec(0.1), {})
        store.upsert("w", "r", "b", "beta", _vec(0.2), {})
        store.upsert("w", "r", "c", "gamma", _vec(0.3), {})

        results = store.get_by_ids("w", "r", ["a", "c"])
        ids = {r["id"] for r in results}

        assert ids == {"a", "c"}

    @pytest.mark.positive
    def test_query_top_k_limits_results(self, store: LociStore) -> None:
        """query() returns at most top_k results."""
        for i in range(5):
            store.upsert("w", "r", f"id{i}", f"text {i}", _vec(i * 0.1 + 0.1), {})

        results = store.query("w", "r", _vec(0.3), top_k=3)

        assert len(results) <= 3

    # ------------------------------------------------------------------
    # Negative — error / failure conditions
    # ------------------------------------------------------------------

    @pytest.mark.negative
    def test_none_client_raises_value_error(self) -> None:
        """LociStore(None) raises ValueError at construction time."""
        with pytest.raises(ValueError, match="ChromaDB client must not be None"):
            LociStore(None)  # type: ignore[arg-type]

    @pytest.mark.negative
    def test_query_empty_room_returns_empty_list(self, store: LociStore) -> None:
        """query() on an empty room returns an empty list (no exception)."""
        results = store.query("empty_wing", "empty_room", _vec(), top_k=5)
        assert results == []

    @pytest.mark.negative
    def test_get_by_ids_nonexistent_id_returns_empty(self, store: LociStore) -> None:
        """get_by_ids() for IDs that don't exist returns an empty list."""
        results = store.get_by_ids("w", "r", ["ghost1", "ghost2"])
        assert results == []

    # ------------------------------------------------------------------
    # Edge — boundary values, empty inputs, single items
    # ------------------------------------------------------------------

    @pytest.mark.edge
    def test_upsert_replaces_existing_chunk(self, store: LociStore) -> None:
        """Upserting the same chunk_id replaces the previous document."""
        store.upsert("w", "r", "dup", "original text", _vec(), {"v": 1})
        store.upsert("w", "r", "dup", "updated text", _vec(), {"v": 2})

        results = store.get_by_ids("w", "r", ["dup"])
        assert len(results) == 1
        assert results[0]["text"] == "updated text"
        assert results[0]["metadata"]["v"] == 2

    @pytest.mark.edge
    def test_list_rooms_excludes_non_separator_collections(
        self, store: LociStore
    ) -> None:
        """Collections without __ in their name are excluded from list_rooms()."""
        # Create a bare ChromaDB collection that bypasses the wing/room pattern
        store._client.get_or_create_collection("nodoubleusc")
        store.upsert("valid", "room", "v1", "text", _vec(), {})

        rooms = store.list_rooms()
        names = [r["wing"] + r["room"] for r in rooms]

        assert not any("nodoubleusc" in n for n in names)
        assert any(r["wing"] == "valid" for r in rooms)

    @pytest.mark.edge
    def test_query_top_k_exceeds_count_returns_all(self, store: LociStore) -> None:
        """query() with top_k > stored count returns all available chunks."""
        store.upsert("w", "r", "only", "sole chunk", _vec(), {})
        results = store.query("w", "r", _vec(), top_k=100)

        assert len(results) == 1
        assert results[0]["id"] == "only"

    @pytest.mark.edge
    def test_list_rooms_empty_store_returns_empty_list(
        self, store: LociStore
    ) -> None:
        """list_rooms() returns [] when no collections have been created."""
        assert store.list_rooms() == []

    @pytest.mark.edge
    def test_get_by_ids_empty_ids_returns_empty(self, store: LociStore) -> None:
        """get_by_ids() with an empty id list returns an empty list."""
        store.upsert("w", "r", "c1", "some text", _vec(), {})
        results = store.get_by_ids("w", "r", [])
        assert results == []
