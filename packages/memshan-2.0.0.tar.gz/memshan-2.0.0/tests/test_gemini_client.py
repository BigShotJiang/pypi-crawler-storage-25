"""tests/test_gemini_client.py — Unit tests for GeminiClient.

Covers:
- src/llm/gemini_client.py (GeminiClient)

All SDK calls are mocked — no real network traffic is made.
One class per file — Separation of Concerns principle.
"""

from __future__ import annotations

import pytest

from src.llm.gemini_client import GeminiClient


class TestGeminiClient:

    # ── helpers ───────────────────────────────────────────────────────────────

    def _build_client(self, mocker, response_text: str = "gemini response"):
        """Patch google.genai.Client and return (GeminiClient, mock_client)."""
        mock_client_cls = mocker.patch("google.genai.Client")
        mock_genai_client = mock_client_cls.return_value
        mock_resp = mocker.MagicMock()
        mock_resp.text = response_text
        mock_genai_client.models.generate_content.return_value = mock_resp
        client = GeminiClient(api_key="AI-abc", model="gemini-2.5-flash")
        return client, mock_genai_client

    # ── negative — construction-time errors ───────────────────────────────────

    @pytest.mark.negative
    def test_none_api_key_raises_value_error(self):
        """None api_key raises ValueError at construction."""
        with pytest.raises(ValueError, match="GEMINI_API_KEY is required"):
            GeminiClient(api_key=None, model="gemini-2.5-flash")

    @pytest.mark.negative
    def test_empty_api_key_raises_value_error(self):
        """Empty-string api_key raises ValueError at construction."""
        with pytest.raises(ValueError, match="GEMINI_API_KEY is required"):
            GeminiClient(api_key="", model="gemini-2.5-flash")

    # ── positive ──────────────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_complete_strips_whitespace(self, mocker):
        """complete() strips whitespace from Gemini response.text."""
        client, _ = self._build_client(mocker, "  gemini says hi  ")
        assert client.complete("Tell me something") == "gemini says hi"

    @pytest.mark.positive
    def test_complete_with_system_passes_config_kwarg(self, mocker):
        """System content is passed as GenerateContentConfig.system_instruction."""
        client, mock_genai_client = self._build_client(mocker)
        client.complete("user question", system="You are concise.")

        call_kwargs = mock_genai_client.models.generate_content.call_args.kwargs
        assert call_kwargs["contents"] == "user question"
        assert call_kwargs["config"] is not None

    # ── negative ──────────────────────────────────────────────────────────────

    @pytest.mark.negative
    def test_generate_content_exception_raises_runtime_error(self, mocker):
        """Any exception from generate_content is wrapped in RuntimeError."""
        client, mock_genai_client = self._build_client(mocker)
        mock_genai_client.models.generate_content.side_effect = Exception("quota exceeded")
        with pytest.raises(RuntimeError, match="Gemini API error"):
            client.complete("prompt")

    # ── edge ──────────────────────────────────────────────────────────────────

    @pytest.mark.edge
    def test_complete_without_system_passes_none_config(self, mocker):
        """Without system, config=None is passed to generate_content."""
        client, mock_genai_client = self._build_client(mocker)
        client.complete("only prompt")

        call_kwargs = mock_genai_client.models.generate_content.call_args.kwargs
        assert call_kwargs["contents"] == "only prompt"
        assert call_kwargs["config"] is None
