"""tests/test_snapshot.py — Unit tests for SessionSnapshot.

Coverage targets: 100% line + branch.
Scenarios: Positive, Negative, Edge.

All external dependencies are mocked:
- spacy.load        — returns a mock NLP pipeline
- LLMClient.complete — mocked via mocker.patch.object
- Embedder.embed     — mocked via mocker.patch.object
- LociStore.upsert   — mocked via mocker.patch.object
- KnowledgeGraph     — methods mocked via mocker.patch.object
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from src.base.embedder import Embedder
from src.base.loci_store import LociStore
from src.layers.pao.snapshot import SessionSnapshot
from src.layers.songlines.knowledge_graph import KnowledgeGraph
from src.llm.client import LLMClient


# ---------------------------------------------------------------------------
# Helpers — build a fake spaCy token / sentence
# ---------------------------------------------------------------------------


def _make_spacy_token(text: str, dep: str, lemma: str, children=None):
    """Build a minimal mock spaCy token."""
    tok = MagicMock()
    tok.text = text
    tok.dep_ = dep
    tok.lemma_ = lemma
    tok.children = children or []
    return tok


def _make_spacy_doc(sentences: list[list]):
    """Build a mock spaCy Doc whose `sents` attribute yields mock sentences.

    Each element in *sentences* is a list of mock tokens.
    """
    doc = MagicMock()
    sent_mocks = []
    for tokens in sentences:
        sent = MagicMock()
        sent.__iter__ = MagicMock(return_value=iter(tokens))
        sent_mocks.append(sent)
    doc.sents = sent_mocks
    return doc


class TestSessionSnapshot:
    """Unit tests for the PAO SessionSnapshot."""

    # ------------------------------------------------------------------
    # Fixtures
    # ------------------------------------------------------------------

    @pytest.fixture()
    def mock_llm(self) -> MagicMock:
        llm = MagicMock(spec=LLMClient)
        return llm

    @pytest.fixture()
    def mock_embedder(self) -> MagicMock:
        emb = MagicMock(spec=Embedder)
        emb.embed.return_value = [0.1, 0.2, 0.3]
        return emb

    @pytest.fixture()
    def mock_store(self) -> MagicMock:
        return MagicMock(spec=LociStore)

    @pytest.fixture()
    def mock_graph(self) -> MagicMock:
        return MagicMock(spec=KnowledgeGraph)

    @pytest.fixture()
    def snapshot(
        self,
        mock_store: MagicMock,
        mock_embedder: MagicMock,
        mock_graph: MagicMock,
        mock_llm: MagicMock,
    ) -> SessionSnapshot:
        """Return a SessionSnapshot with all deps mocked; spaCy load also mocked."""
        with patch("src.layers.pao.snapshot.spacy") as mock_spacy:
            mock_nlp = MagicMock()
            mock_nlp.return_value = _make_spacy_doc([])
            mock_spacy.load.return_value = mock_nlp
            snap = SessionSnapshot(mock_store, mock_embedder, mock_graph, mock_llm)
            snap._nlp = mock_nlp  # expose for per-test overrides
        return snap

    # ------------------------------------------------------------------
    # Positive — constructor
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_init_succeeds_with_valid_deps(
        self,
        mock_store: MagicMock,
        mock_embedder: MagicMock,
        mock_graph: MagicMock,
        mock_llm: MagicMock,
    ) -> None:
        """SessionSnapshot constructs without error when all deps are valid."""
        with patch("src.layers.pao.snapshot.spacy") as mock_spacy:
            mock_spacy.load.return_value = MagicMock()
            snap = SessionSnapshot(mock_store, mock_embedder, mock_graph, mock_llm)
        assert snap is not None

    # ------------------------------------------------------------------
    # Negative — constructor validation
    # ------------------------------------------------------------------

    @pytest.mark.negative
    def test_init_raises_on_none_loci_store(
        self,
        mock_embedder: MagicMock,
        mock_graph: MagicMock,
        mock_llm: MagicMock,
    ) -> None:
        with patch("src.layers.pao.snapshot.spacy"):
            with pytest.raises(ValueError, match="loci_store"):
                SessionSnapshot(None, mock_embedder, mock_graph, mock_llm)

    @pytest.mark.negative
    def test_init_raises_on_none_embedder(
        self,
        mock_store: MagicMock,
        mock_graph: MagicMock,
        mock_llm: MagicMock,
    ) -> None:
        with patch("src.layers.pao.snapshot.spacy"):
            with pytest.raises(ValueError, match="embedder"):
                SessionSnapshot(mock_store, None, mock_graph, mock_llm)

    @pytest.mark.negative
    def test_init_raises_on_none_graph(
        self,
        mock_store: MagicMock,
        mock_embedder: MagicMock,
        mock_llm: MagicMock,
    ) -> None:
        with patch("src.layers.pao.snapshot.spacy"):
            with pytest.raises(ValueError, match="graph"):
                SessionSnapshot(mock_store, mock_embedder, None, mock_llm)

    @pytest.mark.negative
    def test_init_raises_on_none_llm(
        self,
        mock_store: MagicMock,
        mock_embedder: MagicMock,
        mock_graph: MagicMock,
    ) -> None:
        with patch("src.layers.pao.snapshot.spacy"):
            with pytest.raises(ValueError, match="llm"):
                SessionSnapshot(mock_store, mock_embedder, mock_graph, None)

    # ------------------------------------------------------------------
    # Positive — spaCy extraction
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_extract_triplets_uses_spacy_when_triplets_found(
        self, snapshot: SessionSnapshot
    ) -> None:
        """extract_triplets returns spaCy triplets when spaCy finds subject+verb+object."""
        subject_tok = _make_spacy_token("Alice", "nsubj", "Alice")
        object_tok = _make_spacy_token("memory", "dobj", "memory")
        root_tok = _make_spacy_token("stores", "ROOT", "store", children=[subject_tok, object_tok])
        doc = _make_spacy_doc([[subject_tok, object_tok, root_tok]])
        snapshot._nlp.return_value = doc

        result = snapshot.extract_triplets("Alice stores memory")

        assert len(result) == 1
        assert result[0]["subject"] == "Alice"
        assert result[0]["action"] == "store"
        assert result[0]["object"] == "memory"

    @pytest.mark.positive
    def test_extract_triplets_uses_pobj_as_object(
        self, snapshot: SessionSnapshot
    ) -> None:
        """extract_triplets accepts pobj (prepositional object) as the triplet object."""
        subject_tok = _make_spacy_token("Bob", "nsubj", "Bob")
        object_tok = _make_spacy_token("bank", "pobj", "bank")
        root_tok = _make_spacy_token("runs", "ROOT", "run", children=[subject_tok, object_tok])
        doc = _make_spacy_doc([[subject_tok, object_tok, root_tok]])
        snapshot._nlp.return_value = doc

        result = snapshot.extract_triplets("Bob runs to the bank")

        assert len(result) == 1
        assert result[0]["object"] == "bank"

    @pytest.mark.positive
    def test_extract_triplets_multiple_sentences(
        self, snapshot: SessionSnapshot
    ) -> None:
        """extract_triplets returns one triplet per sentence when each has S+V+O."""
        def _make_full_sentence(subj, verb, obj, dep="dobj"):
            s = _make_spacy_token(subj, "nsubj", subj)
            o = _make_spacy_token(obj, dep, obj)
            r = _make_spacy_token(verb, "ROOT", verb, children=[s, o])
            return [s, o, r]

        doc = _make_spacy_doc([
            _make_full_sentence("Alice", "store", "memory"),
            _make_full_sentence("Bob", "retrieve", "data"),
        ])
        snapshot._nlp.return_value = doc

        result = snapshot.extract_triplets("Alice stores memory. Bob retrieves data.")
        assert len(result) == 2

    # ------------------------------------------------------------------
    # Positive — LLM fallback
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_extract_triplets_falls_back_to_llm_when_spacy_finds_nothing(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """extract_triplets calls LLM when spaCy returns no triplets."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])  # no sentences with S+V+O
        mock_llm.complete.return_value = (
            '[{"subject": "AI", "action": "learns", "object": "context"}]'
        )

        result = snapshot.extract_triplets("some text")

        mock_llm.complete.assert_called_once()
        assert len(result) == 1
        assert result[0]["subject"] == "AI"
        assert result[0]["action"] == "learns"
        assert result[0]["object"] == "context"

    @pytest.mark.positive
    def test_extract_triplets_llm_returns_multiple_triplets(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """LLM fallback correctly parses multiple triplets from the JSON response."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = (
            '[{"subject": "A", "action": "b", "object": "C"},'
            '{"subject": "D", "action": "e", "object": "F"}]'
        )

        result = snapshot.extract_triplets("some text")
        assert len(result) == 2

    # ------------------------------------------------------------------
    # Positive — snapshot_session
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_snapshot_session_returns_chunk_ids(
        self,
        snapshot: SessionSnapshot,
        mock_store: MagicMock,
        mock_embedder: MagicMock,
        mock_graph: MagicMock,
    ) -> None:
        """snapshot_session returns one chunk_id per extracted triplet."""
        subject_tok = _make_spacy_token("Agent", "nsubj", "Agent")
        object_tok = _make_spacy_token("memory", "dobj", "memory")
        root_tok = _make_spacy_token("stores", "ROOT", "store", children=[subject_tok, object_tok])
        doc = _make_spacy_doc([[subject_tok, object_tok, root_tok]])
        snapshot._nlp.return_value = doc

        ids = snapshot.snapshot_session("sess1", ["Agent stores memory"])

        assert len(ids) == 1
        assert ids[0].startswith("sess1_")

    @pytest.mark.positive
    def test_snapshot_session_calls_upsert(
        self,
        snapshot: SessionSnapshot,
        mock_store: MagicMock,
        mock_embedder: MagicMock,
        mock_graph: MagicMock,
    ) -> None:
        """snapshot_session calls loci_store.upsert once per triplet."""
        subject_tok = _make_spacy_token("X", "nsubj", "X")
        object_tok = _make_spacy_token("Y", "dobj", "Y")
        root_tok = _make_spacy_token("does", "ROOT", "do", children=[subject_tok, object_tok])
        doc = _make_spacy_doc([[subject_tok, object_tok, root_tok]])
        snapshot._nlp.return_value = doc

        snapshot.snapshot_session("sess1", ["X does Y"])

        mock_store.upsert.assert_called_once()

    @pytest.mark.positive
    def test_snapshot_session_calls_graph_methods(
        self,
        snapshot: SessionSnapshot,
        mock_store: MagicMock,
        mock_graph: MagicMock,
    ) -> None:
        """snapshot_session adds chunk node, concept nodes, and SAO edges to graph."""
        subject_tok = _make_spacy_token("Sys", "nsubj", "Sys")
        object_tok = _make_spacy_token("data", "dobj", "data")
        root_tok = _make_spacy_token("reads", "ROOT", "read", children=[subject_tok, object_tok])
        doc = _make_spacy_doc([[subject_tok, object_tok, root_tok]])
        snapshot._nlp.return_value = doc

        snapshot.snapshot_session("sess1", ["Sys reads data"])

        mock_graph.add_chunk_node.assert_called_once()
        assert mock_graph.add_concept_node.call_count == 2  # subject + object
        assert mock_graph.add_edge.call_count == 2  # SAO_SUBJECT + SAO_OBJECT

    @pytest.mark.positive
    def test_snapshot_session_uses_custom_wing_and_room(
        self,
        snapshot: SessionSnapshot,
        mock_store: MagicMock,
    ) -> None:
        """snapshot_session passes custom wing/room through to loci_store.upsert."""
        subject_tok = _make_spacy_token("A", "nsubj", "A")
        object_tok = _make_spacy_token("B", "dobj", "B")
        root_tok = _make_spacy_token("does", "ROOT", "do", children=[subject_tok, object_tok])
        snapshot._nlp.return_value = _make_spacy_doc([[subject_tok, object_tok, root_tok]])

        snapshot.snapshot_session("s1", ["A does B"], wing="work", room="archive")

        call_kwargs = mock_store.upsert.call_args.kwargs
        assert call_kwargs["wing"] == "work"
        assert call_kwargs["room"] == "archive"

    @pytest.mark.positive
    def test_snapshot_session_embeds_triplet_text(
        self,
        snapshot: SessionSnapshot,
        mock_embedder: MagicMock,
    ) -> None:
        """snapshot_session calls embedder.embed with the triplet text."""
        subject_tok = _make_spacy_token("A", "nsubj", "A")
        object_tok = _make_spacy_token("B", "dobj", "B")
        root_tok = _make_spacy_token("does", "ROOT", "do", children=[subject_tok, object_tok])
        snapshot._nlp.return_value = _make_spacy_doc([[subject_tok, object_tok, root_tok]])

        snapshot.snapshot_session("s1", ["A does B"])

        mock_embedder.embed.assert_called_once_with("A do B")

    # ------------------------------------------------------------------
    # Negative — LLM fallback failure modes
    # ------------------------------------------------------------------

    @pytest.mark.negative
    def test_extract_triplets_returns_empty_on_invalid_llm_json(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """_extract_with_llm returns [] when the LLM returns malformed JSON."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = "NOT VALID JSON {{{"

        result = snapshot.extract_triplets("text")
        assert result == []

    @pytest.mark.negative
    def test_extract_triplets_returns_empty_on_llm_non_list_response(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """_extract_with_llm returns [] when the LLM JSON is not an array."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = '{"subject": "A", "action": "b", "object": "C"}'

        result = snapshot.extract_triplets("text")
        assert result == []

    @pytest.mark.negative
    def test_extract_triplets_skips_llm_items_missing_keys(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """_extract_with_llm skips LLM items that lack required keys."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = (
            '[{"subject": "A"}, {"subject": "B", "action": "c", "object": "D"}]'
        )

        result = snapshot.extract_triplets("text")
        assert len(result) == 1
        assert result[0]["subject"] == "B"

    @pytest.mark.negative
    def test_extract_triplets_returns_empty_on_llm_exception(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """_extract_with_llm returns [] when LLM.complete raises an exception."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.side_effect = RuntimeError("LLM unreachable")

        result = snapshot.extract_triplets("text")
        assert result == []

    # ------------------------------------------------------------------
    # Negative — spaCy incomplete sentences
    # ------------------------------------------------------------------

    @pytest.mark.negative
    def test_extract_triplets_skips_sentence_without_object(
        self, snapshot: SessionSnapshot
    ) -> None:
        """_extract_with_spacy skips sentences that have subject + root but no object."""
        subject_tok = _make_spacy_token("Alice", "nsubj", "Alice")
        # ROOT has no dobj/pobj child
        root_tok = _make_spacy_token("runs", "ROOT", "run", children=[subject_tok])
        doc = _make_spacy_doc([[subject_tok, root_tok]])
        snapshot._nlp.return_value = doc

        # spaCy yields nothing → LLM fallback returns [] too
        with patch.object(snapshot, "_extract_with_llm", return_value=[]):
            result = snapshot.extract_triplets("Alice runs")
        assert result == []

    @pytest.mark.negative
    def test_extract_triplets_skips_sentence_without_subject(
        self, snapshot: SessionSnapshot
    ) -> None:
        """_extract_with_spacy skips sentences that have root + object but no subject."""
        object_tok = _make_spacy_token("memory", "dobj", "memory")
        root_tok = _make_spacy_token("stores", "ROOT", "store", children=[object_tok])
        doc = _make_spacy_doc([[object_tok, root_tok]])
        snapshot._nlp.return_value = doc

        with patch.object(snapshot, "_extract_with_llm", return_value=[]):
            result = snapshot.extract_triplets("stores memory")
        assert result == []

    # ------------------------------------------------------------------
    # Edge — boundary values, empty inputs
    # ------------------------------------------------------------------

    @pytest.mark.edge
    def test_snapshot_session_empty_exchanges_returns_empty(
        self, snapshot: SessionSnapshot
    ) -> None:
        """snapshot_session returns [] immediately when exchanges is empty."""
        result = snapshot.snapshot_session("sess1", [])
        assert result == []

    @pytest.mark.edge
    def test_snapshot_session_no_triplets_extracted_returns_empty(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """snapshot_session returns [] when both spaCy and LLM find no triplets."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = "[]"

        result = snapshot.snapshot_session("sess1", ["nothing useful here"])
        assert result == []

    @pytest.mark.edge
    def test_extract_triplets_empty_string(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """extract_triplets handles empty string without error."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = "[]"

        result = snapshot.extract_triplets("")
        assert result == []

    @pytest.mark.edge
    def test_snapshot_session_single_exchange(
        self,
        snapshot: SessionSnapshot,
        mock_store: MagicMock,
        mock_graph: MagicMock,
        mock_llm: MagicMock,
    ) -> None:
        """snapshot_session works correctly with a single-element exchanges list."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = (
            '[{"subject": "AI", "action": "learns", "object": "facts"}]'
        )

        ids = snapshot.snapshot_session("s1", ["AI learns facts from context"])
        assert len(ids) == 1

    @pytest.mark.edge
    def test_extract_triplets_llm_coerces_values_to_str(
        self, snapshot: SessionSnapshot, mock_llm: MagicMock
    ) -> None:
        """_extract_with_llm casts all triplet values to str."""
        snapshot._nlp.return_value = _make_spacy_doc([[]])
        mock_llm.complete.return_value = (
            '[{"subject": 42, "action": true, "object": null}]'
        )

        result = snapshot.extract_triplets("text")
        assert len(result) == 1
        assert result[0]["subject"] == "42"
        assert result[0]["action"] == "True"
        assert result[0]["object"] == "None"
