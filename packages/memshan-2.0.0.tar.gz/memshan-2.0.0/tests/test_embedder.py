"""tests/test_embedder.py — Unit tests for src/base/embedder.Embedder.

Coverage targets: 100% line + branch.
Scenarios: Positive, Negative, Edge.
"""

import numpy as np
import pytest

from src.base.embedder import Embedder


class TestEmbedder:
    """Unit tests for the Embedder wrapper class."""

    # ------------------------------------------------------------------
    # Positive — happy-path tests
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_embed_returns_list_of_floats(self, mocker) -> None:
        """embed() returns a flat list[float] of the model dimension."""
        mock_model = mocker.MagicMock()
        mock_model.encode.return_value = np.array([0.1, 0.2, 0.3])
        mocker.patch("src.base.embedder.SentenceTransformer", return_value=mock_model)

        embedder = Embedder("all-MiniLM-L6-v2")
        result = embedder.embed("hello world")

        assert isinstance(result, list)
        assert len(result) == 3
        assert all(isinstance(v, float) for v in result)

    @pytest.mark.positive
    def test_embed_calls_encode_with_text(self, mocker) -> None:
        """embed() passes the text string directly to model.encode."""
        mock_model = mocker.MagicMock()
        mock_model.encode.return_value = np.array([0.5])
        mocker.patch("src.base.embedder.SentenceTransformer", return_value=mock_model)

        embedder = Embedder("all-MiniLM-L6-v2")
        embedder.embed("test sentence")

        mock_model.encode.assert_called_once_with("test sentence")

    @pytest.mark.positive
    def test_embed_batch_returns_list_of_vectors(self, mocker) -> None:
        """embed_batch() returns one float vector per input text."""
        mock_model = mocker.MagicMock()
        mock_model.encode.return_value = np.array([[0.1, 0.2], [0.3, 0.4]])
        mocker.patch("src.base.embedder.SentenceTransformer", return_value=mock_model)

        embedder = Embedder("all-MiniLM-L6-v2")
        result = embedder.embed_batch(["hello", "world"])

        assert isinstance(result, list)
        assert len(result) == 2
        assert all(isinstance(vec, list) for vec in result)
        assert all(isinstance(v, float) for v in result[0])

    @pytest.mark.positive
    def test_embed_batch_calls_encode_with_list(self, mocker) -> None:
        """embed_batch() passes the full list to model.encode in one call."""
        mock_model = mocker.MagicMock()
        mock_model.encode.return_value = np.array([[0.1], [0.2]])
        mocker.patch("src.base.embedder.SentenceTransformer", return_value=mock_model)

        embedder = Embedder("all-MiniLM-L6-v2")
        embedder.embed_batch(["a", "b"])

        mock_model.encode.assert_called_once_with(["a", "b"])

    # ------------------------------------------------------------------
    # Negative — error / failure conditions
    # ------------------------------------------------------------------

    @pytest.mark.negative
    def test_empty_model_name_raises_value_error(self, mocker) -> None:
        """Embedder("") raises ValueError before any model is loaded."""
        mocker.patch("src.base.embedder.SentenceTransformer")

        with pytest.raises(ValueError, match="model_name must not be empty"):
            Embedder("")

    @pytest.mark.negative
    def test_model_load_failure_raises_runtime_error(self, mocker) -> None:
        """RuntimeError is raised when SentenceTransformer fails to load."""
        mocker.patch(
            "src.base.embedder.SentenceTransformer",
            side_effect=OSError("model file not found"),
        )

        with pytest.raises(RuntimeError, match="Failed to load embedding model"):
            Embedder("nonexistent-model")

    # ------------------------------------------------------------------
    # Edge — boundary values, empty inputs, single items
    # ------------------------------------------------------------------

    @pytest.mark.edge
    def test_embed_batch_empty_list_returns_empty(self, mocker) -> None:
        """embed_batch([]) returns [] without calling model.encode."""
        mock_model = mocker.MagicMock()
        mocker.patch("src.base.embedder.SentenceTransformer", return_value=mock_model)

        embedder = Embedder("all-MiniLM-L6-v2")
        result = embedder.embed_batch([])

        assert result == []
        mock_model.encode.assert_not_called()

    @pytest.mark.edge
    def test_embed_empty_string(self, mocker) -> None:
        """embed("") is valid; model result is returned as-is."""
        mock_model = mocker.MagicMock()
        mock_model.encode.return_value = np.array([0.0, 0.0])
        mocker.patch("src.base.embedder.SentenceTransformer", return_value=mock_model)

        embedder = Embedder("all-MiniLM-L6-v2")
        result = embedder.embed("")

        assert isinstance(result, list)
        assert result == [0.0, 0.0]

    @pytest.mark.edge
    def test_embed_batch_single_item(self, mocker) -> None:
        """embed_batch with a single-element list returns a list of one vector."""
        mock_model = mocker.MagicMock()
        mock_model.encode.return_value = np.array([[0.7, 0.8, 0.9]])
        mocker.patch("src.base.embedder.SentenceTransformer", return_value=mock_model)

        embedder = Embedder("model")
        result = embedder.embed_batch(["only one"])

        assert len(result) == 1
        assert result[0] == pytest.approx([0.7, 0.8, 0.9])
