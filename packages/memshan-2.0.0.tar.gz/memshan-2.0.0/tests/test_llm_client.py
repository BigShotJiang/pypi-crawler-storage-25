"""tests/test_llm_client.py — Unit tests for the LLMClient abstract base class.

Covers:
- src/llm/client.py (LLMClient ABC)

One class per file — Separation of Concerns principle.
"""

from __future__ import annotations

import pytest

from src.llm.client import LLMClient


class TestLLMClientABC:

    @pytest.mark.negative
    def test_cannot_instantiate_abstract_class(self):
        """LLMClient is abstract and cannot be directly instantiated."""
        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            LLMClient()  # type: ignore[abstract]

    @pytest.mark.edge
    def test_abstract_method_body_is_reachable(self):
        """Calling LLMClient.complete directly covers the abstract method body."""

        class _Stub(LLMClient):
            def complete(self, prompt: str, *, system: str | None = None) -> str:
                # Invoke parent body to achieve 100 % coverage of client.py
                return LLMClient.complete(self, prompt, system=system) or ""  # type: ignore[return-value]

        result = _Stub().complete("hi", system="be brief")
        assert result == ""
