"""tests/test_gemini_live.py — Live integration tests for GeminiClient.

These tests make REAL network calls to the Google Gemini API.
They are excluded from the default ``pytest tests/`` run and must be invoked
explicitly:

    pytest tests/test_gemini_live.py -v -m integration --override-ini="addopts="

Skip conditions (checked at runtime via fixtures):
- Skipped if ``GEMINI_API_KEY`` is absent from the environment or ``.env``.

Uses ``GEMINI_MODEL`` env var (default: ``gemini-2.5-flash``).

One class per file — Separation of Concerns principle.
"""

from __future__ import annotations

import os

import pytest
from dotenv import load_dotenv

load_dotenv()

from src.llm.gemini_client import GeminiClient

_GEMINI_API_KEY: str | None = os.getenv("GEMINI_API_KEY")
_GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")


@pytest.mark.integration
class TestGeminiLive:
    """Live tests that call the Google Gemini API.

    Skipped automatically when ``GEMINI_API_KEY`` is not set.
    """

    @pytest.fixture(autouse=True)
    def _require_gemini_key(self):
        """Skip the entire class if GEMINI_API_KEY is absent."""
        if not _GEMINI_API_KEY:
            pytest.skip(
                "GEMINI_API_KEY is not set. "
                "Add it to your .env file to run Gemini live tests."
            )

    # ── positive ──────────────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_complete_returns_non_empty_string(self):
        """A basic prompt returns a non-empty string from the live Gemini model."""
        client = GeminiClient(api_key=_GEMINI_API_KEY, model=_GEMINI_MODEL)
        result = client.complete("Reply with exactly one word: hello")
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.positive
    def test_complete_with_system_prompt_returns_string(self):
        """Combining a system instruction with a user prompt returns a string."""
        client = GeminiClient(api_key=_GEMINI_API_KEY, model=_GEMINI_MODEL)
        result = client.complete(
            "What is 2 + 2?",
            system="You are a concise assistant. Respond with a single number only.",
        )
        assert isinstance(result, str)
        assert len(result) > 0

    # ── edge ──────────────────────────────────────────────────────────────────

    @pytest.mark.edge
    def test_complete_with_single_word_prompt_returns_string(self):
        """A one-word prompt still produces a valid string response."""
        client = GeminiClient(api_key=_GEMINI_API_KEY, model=_GEMINI_MODEL)
        result = client.complete("Hello")
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.edge
    def test_complete_result_is_stripped(self):
        """The returned string has no leading or trailing whitespace."""
        client = GeminiClient(api_key=_GEMINI_API_KEY, model=_GEMINI_MODEL)
        result = client.complete("Say the word: test")
        assert result == result.strip()
