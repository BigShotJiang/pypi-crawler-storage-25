"""tests/test_server.py — Unit tests for src/server.py (Phase 9).

Coverage target: 100% line + branch for src/server.py

Strategy
--------
- All heavy constructors (Embedder, PersistentClient, SessionSnapshot,
  RetrievalPipeline) are mocked so tests are fast and have no I/O.
- The graph.load() branch (graph file exists vs not exists) is tested
  by toggling Path.exists via mocker.patch.

Markers:
  @pytest.mark.positive — happy-path
  @pytest.mark.negative — error/failure conditions
  @pytest.mark.edge     — boundary values (graph file present/absent)
"""

from __future__ import annotations

import pytest


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _patch_all(mocker) -> dict:
    """Patch every constructor and function called inside src.server.

    Heavy src.* imports are local inside server functions (TYPE_CHECKING guard),
    so they must be patched at their source modules, not at src.server.
    chromadb, configure, mcp, and Path are imported at server module level and
    can be patched via src.server.

    Returns a dict of all mocks keyed by short name.
    """
    m = {}

    # Settings — local import inside run(); patch at source module
    m["Settings"] = mocker.patch("src.config.Settings")
    m["settings"] = m["Settings"].return_value
    m["settings"].embedding_model = "all-MiniLM-L6-v2"
    m["settings"].chroma_persist_dir = "./data/chroma"
    m["settings"].get_llm_client.return_value = mocker.MagicMock()

    # Layer constructors — local imports inside _build_dependencies(); patch at source
    m["Embedder"] = mocker.patch("src.base.embedder.Embedder")
    m["PersistentClient"] = mocker.patch("src.server.chromadb.PersistentClient")
    m["LociStore"] = mocker.patch("src.base.loci_store.LociStore")
    m["KnowledgeGraph"] = mocker.patch(
        "src.layers.songlines.knowledge_graph.KnowledgeGraph"
    )
    m["PhoneticEncoder"] = mocker.patch(
        "src.layers.major_system.phonetic_encoder.PhoneticEncoder"
    )
    m["SessionSnapshot"] = mocker.patch("src.layers.pao.snapshot.SessionSnapshot")
    m["RetrievalPipeline"] = mocker.patch(
        "src.pipeline.retrieval.RetrievalPipeline"
    )

    # configure + mcp.run — imported at module level in src.server
    m["configure"] = mocker.patch("src.server.configure")
    m["mcp_run"] = mocker.patch("src.server.mcp.run")

    # Path.exists — imported at module level in src.server
    m["path_exists"] = mocker.patch("src.server.Path.exists", return_value=False)

    return m


# ===========================================================================
# _build_dependencies
# ===========================================================================


class TestBuildDependencies:
    """Tests for the _build_dependencies() private function."""

    @pytest.mark.positive
    def test_build_dependencies_returns_six_tuple(self, mocker, tmp_path):
        m = _patch_all(mocker)
        m["settings"].chroma_persist_dir = str(tmp_path)

        from src.server import _build_dependencies
        result = _build_dependencies(m["settings"])

        assert len(result) == 6

    @pytest.mark.positive
    def test_build_dependencies_constructs_embedder_with_model(self, mocker, tmp_path):
        m = _patch_all(mocker)
        m["settings"].chroma_persist_dir = str(tmp_path)
        m["settings"].embedding_model = "my-model"

        from src.server import _build_dependencies
        _build_dependencies(m["settings"])

        m["Embedder"].assert_called_once_with("my-model")

    @pytest.mark.positive
    def test_build_dependencies_constructs_persistent_client(self, mocker, tmp_path):
        m = _patch_all(mocker)
        m["settings"].chroma_persist_dir = str(tmp_path)

        from src.server import _build_dependencies
        _build_dependencies(m["settings"])

        m["PersistentClient"].assert_called_once_with(path=str(tmp_path))

    @pytest.mark.positive
    def test_build_dependencies_calls_get_llm_client(self, mocker, tmp_path):
        m = _patch_all(mocker)
        m["settings"].chroma_persist_dir = str(tmp_path)

        from src.server import _build_dependencies
        _build_dependencies(m["settings"])

        m["settings"].get_llm_client.assert_called_once()

    @pytest.mark.edge
    def test_build_dependencies_loads_graph_when_file_exists(self, mocker, tmp_path):
        """When graph.graphml exists on disk, graph.load() must be called."""
        m = _patch_all(mocker)
        m["settings"].chroma_persist_dir = str(tmp_path)
        m["path_exists"].return_value = True

        from src.server import _build_dependencies
        _build_dependencies(m["settings"])

        mock_graph_instance = m["KnowledgeGraph"].return_value
        mock_graph_instance.load.assert_called_once()

    @pytest.mark.edge
    def test_build_dependencies_skips_graph_load_when_file_absent(self, mocker, tmp_path):
        """When graph.graphml does not exist, graph.load() must NOT be called."""
        m = _patch_all(mocker)
        m["settings"].chroma_persist_dir = str(tmp_path)
        m["path_exists"].return_value = False

        from src.server import _build_dependencies
        _build_dependencies(m["settings"])

        mock_graph_instance = m["KnowledgeGraph"].return_value
        mock_graph_instance.load.assert_not_called()

    @pytest.mark.positive
    def test_build_dependencies_wires_snapshot_with_llm(self, mocker, tmp_path):
        m = _patch_all(mocker)
        m["settings"].chroma_persist_dir = str(tmp_path)
        mock_llm = mocker.MagicMock()
        m["settings"].get_llm_client.return_value = mock_llm

        from src.server import _build_dependencies
        _build_dependencies(m["settings"])

        call_kwargs = m["SessionSnapshot"].call_args
        # Fourth positional arg to SessionSnapshot must be the LLM client
        args = call_kwargs[0]
        assert args[3] is mock_llm


# ===========================================================================
# run()
# ===========================================================================


class TestRun:
    """Tests for the run() public entry point."""

    @pytest.mark.positive
    def test_run_calls_configure_then_mcp_run(self, mocker):
        m = _patch_all(mocker)

        from src.server import run
        run()

        m["configure"].assert_called_once()
        m["mcp_run"].assert_called_once()

    @pytest.mark.positive
    def test_run_passes_settings_to_configure(self, mocker):
        m = _patch_all(mocker)
        mock_settings_instance = m["settings"]

        from src.server import run
        run()

        call_args = m["configure"].call_args[0]
        # 6th argument to configure() is settings
        assert call_args[5] is mock_settings_instance

    @pytest.mark.negative
    def test_run_propagates_settings_error(self, mocker):
        """If Settings() raises ValueError, run() must propagate it."""
        m = _patch_all(mocker)
        m["Settings"].side_effect = ValueError("bad config")

        from src.server import run
        with pytest.raises(ValueError, match="bad config"):
            run()

    @pytest.mark.negative
    def test_run_propagates_llm_error(self, mocker):
        """If get_llm_client() raises, run() must propagate it."""
        m = _patch_all(mocker)
        m["settings"].get_llm_client.side_effect = ValueError("unknown provider")

        from src.server import run
        with pytest.raises(ValueError, match="unknown provider"):
            run()
