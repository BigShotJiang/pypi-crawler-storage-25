"""tests/test_ollama_live.py — Live integration tests for OllamaClient.

These tests make REAL network calls to a locally running Ollama instance.
They are excluded from the default ``pytest tests/`` run and must be invoked
explicitly:

    pytest tests/test_ollama_live.py -v -m integration --override-ini="addopts="

Skip conditions (checked at runtime via fixtures):
- Skipped if no Ollama server is reachable at ``OLLAMA_BASE_URL``.
- Skipped if no text-generation model is loaded (embedding-only Ollama skipped).

The model is auto-discovered from ``GET /api/tags`` so the test always uses
what is actually available — no hard-coded model names.

One class per file — Separation of Concerns principle.
"""

from __future__ import annotations

import os
from typing import Optional

import httpx
import pytest
from dotenv import load_dotenv

load_dotenv()

from src.llm.ollama_client import OllamaClient

_OLLAMA_BASE_URL: str = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
_EMBED_KEYWORDS = ("embed", "embedding")


def _find_ollama_text_model() -> Optional[str]:
    """Return the first loaded Ollama text-generation model name, or None."""
    try:
        resp = httpx.get(f"{_OLLAMA_BASE_URL}/api/tags", timeout=5.0)
        resp.raise_for_status()
    except Exception:
        return None

    models: list[dict] = resp.json().get("models", [])
    for entry in models:
        name: str = entry.get("name", "")
        if not any(kw in name.lower() for kw in _EMBED_KEYWORDS):
            return name
    return None


@pytest.mark.integration
class TestOllamaLive:
    """Live tests that call a locally running Ollama instance.

    Skipped automatically when no Ollama server is reachable at
    ``OLLAMA_BASE_URL``, or when no text-generation model is loaded.
    """

    @pytest.fixture(autouse=True)
    def _require_ollama(self):
        """Skip the entire class if no text-generation model is available."""
        model = _find_ollama_text_model()
        if model is None:
            pytest.skip(
                f"No text-generation model found at '{_OLLAMA_BASE_URL}'. "
                "Start Ollama and pull a model: ollama pull gemma3"
            )
        self._model = model

    # ── positive ──────────────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_complete_returns_non_empty_string(self):
        """A basic prompt returns a non-empty string from the live model."""
        client = OllamaClient(base_url=_OLLAMA_BASE_URL, model=self._model)
        result = client.complete("Reply with exactly one word: hello")
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.positive
    def test_complete_with_system_prompt_returns_string(self):
        """Combining a system prompt with a user prompt returns a string."""
        client = OllamaClient(base_url=_OLLAMA_BASE_URL, model=self._model)
        result = client.complete(
            "What is 2 + 2?",
            system="You are a concise assistant. Respond with a single number only.",
        )
        assert isinstance(result, str)
        assert len(result) > 0

    # ── edge ──────────────────────────────────────────────────────────────────

    @pytest.mark.edge
    def test_complete_with_empty_prompt_returns_string(self):
        """An empty prompt does not crash — Ollama returns some string."""
        client = OllamaClient(base_url=_OLLAMA_BASE_URL, model=self._model)
        result = client.complete("")
        assert isinstance(result, str)

    @pytest.mark.edge
    def test_complete_result_is_stripped(self):
        """The returned string has no leading or trailing whitespace."""
        client = OllamaClient(base_url=_OLLAMA_BASE_URL, model=self._model)
        result = client.complete("Say the word: test")
        assert result == result.strip()
