"""tests/test_anthropic_client.py — Unit tests for AnthropicClient.

Covers:
- src/llm/anthropic_client.py (AnthropicClient)

All SDK calls are mocked — no real network traffic is made.
One class per file — Separation of Concerns principle.
"""

from __future__ import annotations

import anthropic
import pytest

from src.llm.anthropic_client import AnthropicClient


class TestAnthropicClient:

    # ── helpers ───────────────────────────────────────────────────────────────

    def _build_client(self, mocker, response_text: str = "claude response"):
        """Patch anthropic.Anthropic and return (AnthropicClient, mock_inst)."""
        mock_cls = mocker.patch("anthropic.Anthropic")
        mock_inst = mock_cls.return_value
        mock_response = mocker.MagicMock()
        mock_response.content[0].text = response_text
        mock_inst.messages.create.return_value = mock_response
        client = AnthropicClient(api_key="sk-ant-key", model="claude-3-haiku-20240307")
        return client, mock_inst

    # ── negative — construction-time errors ───────────────────────────────────

    @pytest.mark.negative
    def test_none_api_key_raises_value_error(self):
        """None api_key raises ValueError at construction."""
        with pytest.raises(ValueError, match="ANTHROPIC_API_KEY is required"):
            AnthropicClient(api_key=None, model="claude-3-haiku-20240307")

    @pytest.mark.negative
    def test_empty_api_key_raises_value_error(self):
        """Empty-string api_key raises ValueError at construction."""
        with pytest.raises(ValueError, match="ANTHROPIC_API_KEY is required"):
            AnthropicClient(api_key="", model="claude-3-haiku-20240307")

    # ── positive ──────────────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_complete_strips_whitespace(self, mocker):
        """complete() strips whitespace from Anthropic response content text."""
        client, _ = self._build_client(mocker, "  claude response  ")
        assert client.complete("Say something") == "claude response"

    @pytest.mark.positive
    def test_complete_with_system_passes_system_kwarg(self, mocker):
        """System prompt is forwarded as the 'system' kwarg to messages.create."""
        client, mock_inst = self._build_client(mocker)
        client.complete("user msg", system="Be precise.")

        call_kwargs = mock_inst.messages.create.call_args.kwargs
        assert call_kwargs["system"] == "Be precise."
        assert call_kwargs["messages"] == [{"role": "user", "content": "user msg"}]

    @pytest.mark.positive
    def test_complete_sends_correct_model_and_max_tokens(self, mocker):
        """messages.create receives the configured model and max_tokens."""
        client, mock_inst = self._build_client(mocker)
        client.complete("prompt")

        call_kwargs = mock_inst.messages.create.call_args.kwargs
        assert call_kwargs["model"] == "claude-3-haiku-20240307"
        assert call_kwargs["max_tokens"] == 1024

    # ── negative ──────────────────────────────────────────────────────────────

    @pytest.mark.negative
    def test_anthropic_error_raises_runtime_error(self, mocker):
        """AnthropicError from the SDK is wrapped in RuntimeError."""
        client, mock_inst = self._build_client(mocker)
        mock_inst.messages.create.side_effect = anthropic.AnthropicError("rate limit")
        with pytest.raises(RuntimeError, match="Anthropic API error"):
            client.complete("prompt")

    # ── edge ──────────────────────────────────────────────────────────────────

    @pytest.mark.edge
    def test_complete_without_system_omits_system_kwarg(self, mocker):
        """Without system prompt, 'system' key is absent from messages.create."""
        client, mock_inst = self._build_client(mocker)
        client.complete("only prompt")

        call_kwargs = mock_inst.messages.create.call_args.kwargs
        assert "system" not in call_kwargs
