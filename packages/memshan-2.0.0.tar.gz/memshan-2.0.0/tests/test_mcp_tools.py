"""tests/test_mcp_tools.py — Unit tests for Phase 8 MCP Tool Layer.

Coverage targets: 100% line + branch for src/tools/mcp_tools.py
                  and src/tools/__init__.py

Test classes
------------
  TestConfigTools            — get_server_status, list_rooms, get_pipeline_config
  TestStorageRetrievalTools  — store_memory, retrieve_memory, add_context_trail,
                               get_context_trail, snapshot_session
  TestMetricsTools           — get_recall_stats, get_graph_stats,
                               get_compression_stats, get_latency_report

All pipeline, graph, snapshot, loci_store, and embedder dependencies are mocked.
No real HTTP calls, no real ChromaDB disk writes, no real model inference.
"""

from __future__ import annotations

import networkx as nx
import pytest

import src.tools.mcp_tools as _module
from src.tools.mcp_tools import (
    add_context_trail,
    configure,
    get_compression_stats,
    get_context_trail,
    get_graph_stats,
    get_latency_report,
    get_pipeline_config,
    get_recall_stats,
    get_server_status,
    list_rooms,
    retrieve_memory,
    snapshot_session,
    store_memory,
)

# ---------------------------------------------------------------------------
# Shared dummy data
# ---------------------------------------------------------------------------

_DUMMY_EMBEDDING: list[float] = [0.1, 0.2, 0.3]

_DUMMY_ROOMS: list[dict] = [
    {"wing": "work", "room": "projects", "count": 10},
    {"wing": "personal", "room": "notes", "count": 5},
]

_DUMMY_CHUNKS: list[dict] = [
    {"id": "c1", "text": "ChromaDB stores embeddings.", "metadata": {}, "distance": 0.1},
    {"id": "c2", "text": "NetworkX records the graph.", "metadata": {}, "distance": 0.2},
]


# ---------------------------------------------------------------------------
# Auto-use fixture: reset all module-level singletons before each test
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_singletons(mocker):
    """Patch every singleton to None before each test for isolation."""
    mocker.patch.object(_module, "_pipeline", None)
    mocker.patch.object(_module, "_graph", None)
    mocker.patch.object(_module, "_snapshot", None)
    mocker.patch.object(_module, "_loci_store", None)
    mocker.patch.object(_module, "_embedder", None)
    mocker.patch.object(_module, "_settings", None)


# ---------------------------------------------------------------------------
# Shared fixture: fully configured mocks
# ---------------------------------------------------------------------------


@pytest.fixture()
def mocks(mocker):
    """Return a dict of all mocked singletons, already injected via configure()."""
    mock_pipeline = mocker.MagicMock()
    mock_graph = mocker.MagicMock()
    mock_snapshot = mocker.MagicMock()
    mock_loci_store = mocker.MagicMock()
    mock_embedder = mocker.MagicMock()
    mock_settings = mocker.MagicMock()

    # Set readable attributes on pipeline mock
    mock_pipeline.semantic_threshold = 0.3
    mock_pipeline.neighbour_k = 5
    mock_pipeline.default_top_k = 10

    # Set settings readable fields
    mock_settings.llm_provider = "ollama"
    mock_settings.embedding_model = "all-MiniLM-L6-v2"
    mock_settings.chroma_persist_dir = "./data/chroma"

    # Default embedder behaviour
    mock_embedder.embed.return_value = _DUMMY_EMBEDDING

    # Default loci_store behaviour
    mock_loci_store.list_rooms.return_value = _DUMMY_ROOMS

    # Default graph — attach a real DiGraph for stats tests
    fake_graph = nx.DiGraph()
    fake_graph.add_node("c1")
    fake_graph.add_node("c2")
    fake_graph.add_edge("c1", "c2", edge_type="SEMANTIC", weight=0.9)
    mock_graph._graph = fake_graph

    configure(
        mock_pipeline,
        mock_graph,
        mock_snapshot,
        mock_loci_store,
        mock_embedder,
        mock_settings,
    )

    return {
        "pipeline": mock_pipeline,
        "graph": mock_graph,
        "snapshot": mock_snapshot,
        "loci_store": mock_loci_store,
        "embedder": mock_embedder,
        "settings": mock_settings,
    }


# ===========================================================================
# Category A — Configuration & Inspection
# ===========================================================================


class TestConfigTools:
    """Tests for get_server_status, list_rooms, get_pipeline_config."""

    # ── get_server_status ──────────────────────────────────────────────────

    @pytest.mark.positive
    def test_get_server_status_returns_expected_keys(self, mocks):
        result = get_server_status()

        assert result["version"] == "2.0"
        assert result["llm_provider"] == "ollama"
        assert result["embedding_model"] == "all-MiniLM-L6-v2"
        assert result["chroma_persist_dir"] == "./data/chroma"
        assert result["semantic_threshold"] == 0.3
        assert result["neighbour_k"] == 5
        assert result["default_top_k"] == 10

    @pytest.mark.negative
    def test_get_server_status_not_configured_raises(self):
        with pytest.raises(RuntimeError, match="not configured"):
            get_server_status()

    @pytest.mark.edge
    def test_get_server_status_custom_threshold(self, mocks):
        mocks["pipeline"].semantic_threshold = 0.7
        result = get_server_status()
        assert result["semantic_threshold"] == 0.7

    # ── list_rooms ─────────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_list_rooms_returns_all_rooms(self, mocks):
        result = list_rooms()
        assert len(result) == 2
        assert result[0]["wing"] == "work"
        assert result[1]["room"] == "notes"

    @pytest.mark.negative
    def test_list_rooms_not_configured_raises(self):
        with pytest.raises(RuntimeError, match="not configured"):
            list_rooms()

    @pytest.mark.edge
    def test_list_rooms_empty_store(self, mocks):
        mocks["loci_store"].list_rooms.return_value = []
        result = list_rooms()
        assert result == []

    # ── get_pipeline_config ────────────────────────────────────────────────

    @pytest.mark.positive
    def test_get_pipeline_config_returns_all_keys(self, mocks):
        result = get_pipeline_config()
        assert set(result.keys()) == {"semantic_threshold", "neighbour_k", "default_top_k"}

    @pytest.mark.negative
    def test_get_pipeline_config_not_configured_raises(self):
        with pytest.raises(RuntimeError, match="not configured"):
            get_pipeline_config()

    @pytest.mark.edge
    def test_get_pipeline_config_zero_neighbours_reflects_value(self, mocks):
        # Pipeline validation would reject zero, but mock allows it for interface test
        mocks["pipeline"].neighbour_k = 1
        result = get_pipeline_config()
        assert result["neighbour_k"] == 1


# ===========================================================================
# Category B — Storage & Retrieval
# ===========================================================================


class TestStorageRetrievalTools:
    """Tests for store_memory, retrieve_memory, add_context_trail,
    get_context_trail, snapshot_session."""

    # ── store_memory ───────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_store_memory_success(self, mocks):
        mocks["pipeline"].store.return_value = None
        mocks["pipeline"].encoder.extract_and_tag.return_value = {
            "phonetic_tags": ["tf", "mn"],
            "numeric_tokens": [],
        }
        # Freeze edge count on the fake graph
        mocks["graph"]._graph.add_node("new")

        result = store_memory("work", "projects", "c1", "Test text.")

        assert result["stored"] is True
        assert result["chunk_id"] == "c1"
        assert result["phonetic_tags"] == ["tf", "mn"]
        assert isinstance(result["graph_edges_added"], int)
        mocks["pipeline"].store.assert_called_once_with(
            "work", "projects", "c1", "Test text.", None
        )

    @pytest.mark.negative
    def test_store_memory_empty_wing_raises(self, mocks):
        with pytest.raises(ValueError, match="'wing'"):
            store_memory("", "room", "c1", "text")

    @pytest.mark.negative
    def test_store_memory_empty_room_raises(self, mocks):
        with pytest.raises(ValueError, match="'room'"):
            store_memory("wing", "   ", "c1", "text")

    @pytest.mark.negative
    def test_store_memory_empty_chunk_id_raises(self, mocks):
        with pytest.raises(ValueError, match="'chunk_id'"):
            store_memory("wing", "room", "", "text")

    @pytest.mark.negative
    def test_store_memory_empty_text_raises(self, mocks):
        with pytest.raises(ValueError, match="'text'"):
            store_memory("wing", "room", "c1", "")

    @pytest.mark.edge
    def test_store_memory_with_none_metadata_passes_none(self, mocks):
        mocks["pipeline"].encoder.extract_and_tag.return_value = {
            "phonetic_tags": [],
            "numeric_tokens": [],
        }
        result = store_memory("w", "r", "c1", "text", metadata=None)
        assert result["stored"] is True
        mocks["pipeline"].store.assert_called_once_with("w", "r", "c1", "text", None)

    # ── retrieve_memory ────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_retrieve_memory_returns_normalised_results(self, mocks):
        mocks["pipeline"].retrieve.return_value = [
            {
                "id": "c1",
                "text": "ChromaDB stores embeddings.",
                "distance": 0.1,
                "metadata": {"key": "val"},
                "phonetic_tags": ["kr"],
            }
        ]
        results = retrieve_memory("vector database", "work", "projects", top_k=1)

        assert len(results) == 1
        assert results[0]["id"] == "c1"
        assert results[0]["text"] == "ChromaDB stores embeddings."
        assert results[0]["distance"] == 0.1
        assert results[0]["metadata"] == {"key": "val"}
        assert results[0]["phonetic_tags"] == ["kr"]

    @pytest.mark.negative
    def test_retrieve_memory_empty_query_raises(self, mocks):
        with pytest.raises(ValueError, match="'query'"):
            retrieve_memory("", "wing", "room")

    @pytest.mark.negative
    def test_retrieve_memory_top_k_zero_raises(self, mocks):
        with pytest.raises(ValueError, match="top_k"):
            retrieve_memory("q", "wing", "room", top_k=0)

    @pytest.mark.edge
    def test_retrieve_memory_empty_result_list(self, mocks):
        mocks["pipeline"].retrieve.return_value = []
        results = retrieve_memory("query", "w", "r", top_k=5)
        assert results == []

    @pytest.mark.edge
    def test_retrieve_memory_missing_optional_fields_default(self, mocks):
        # Result missing optional metadata / phonetic_tags keys
        mocks["pipeline"].retrieve.return_value = [{"id": "c1", "text": "hello", "distance": 0.5}]
        results = retrieve_memory("q", "w", "r")
        assert results[0]["metadata"] == {}
        assert results[0]["phonetic_tags"] == []

    # ── add_context_trail ──────────────────────────────────────────────────

    @pytest.mark.positive
    def test_add_context_trail_calls_graph_add_edge(self, mocks):
        result = add_context_trail("c1", "c2", "extends")

        mocks["graph"].add_edge.assert_called_once_with("c1", "c2", "MANUAL", weight=1.0)
        assert result["linked"] is True
        assert result["from_id"] == "c1"
        assert result["to_id"] == "c2"
        assert result["edge_type"] == "MANUAL"
        assert result["label"] == "extends"

    @pytest.mark.negative
    def test_add_context_trail_empty_from_id_raises(self, mocks):
        with pytest.raises(ValueError, match="'from_id'"):
            add_context_trail("", "c2")

    @pytest.mark.negative
    def test_add_context_trail_empty_to_id_raises(self, mocks):
        with pytest.raises(ValueError, match="'to_id'"):
            add_context_trail("c1", "")

    @pytest.mark.edge
    def test_add_context_trail_default_label(self, mocks):
        result = add_context_trail("c1", "c2")
        assert result["label"] == "manual link"

    # ── get_context_trail ──────────────────────────────────────────────────

    @pytest.mark.positive
    def test_get_context_trail_returns_path(self, mocks):
        mocks["graph"].get_trail.return_value = ["c1", "c3", "c2"]

        result = get_context_trail("c1", "c2")

        assert result["from_id"] == "c1"
        assert result["to_id"] == "c2"
        assert result["trail"] == ["c1", "c3", "c2"]
        assert result["length"] == 3

    @pytest.mark.negative
    def test_get_context_trail_empty_from_id_raises(self, mocks):
        with pytest.raises(ValueError, match="'from_id'"):
            get_context_trail("", "c2")

    @pytest.mark.edge
    def test_get_context_trail_no_path_returns_empty_trail(self, mocks):
        mocks["graph"].get_trail.return_value = []
        result = get_context_trail("c1", "c99")
        assert result["trail"] == []
        assert result["length"] == 0

    # ── snapshot_session ───────────────────────────────────────────────────

    @pytest.mark.positive
    def test_snapshot_session_archives_triplets(self, mocks):
        mocks["snapshot"].snapshot_session.return_value = ["sid_abc1", "sid_abc2"]

        result = snapshot_session(
            "session_001",
            ["CEO opened meeting.", "Board approved budget."],
            "long_term",
            "sessions",
        )

        assert result["archived"] is True
        assert result["session_id"] == "session_001"
        assert result["triplets_stored"] == 2
        assert len(result["chunk_ids"]) == 2
        mocks["snapshot"].snapshot_session.assert_called_once_with(
            "session_001",
            ["CEO opened meeting.", "Board approved budget."],
            "long_term",
            "sessions",
        )

    @pytest.mark.negative
    def test_snapshot_session_empty_session_id_raises(self, mocks):
        with pytest.raises(ValueError, match="'session_id'"):
            snapshot_session("", ["text"])

    @pytest.mark.negative
    def test_snapshot_session_non_list_exchanges_raises(self, mocks):
        with pytest.raises(ValueError, match="'exchanges'"):
            snapshot_session("sid", "not a list")

    @pytest.mark.edge
    def test_snapshot_session_empty_exchanges_returns_zero(self, mocks):
        mocks["snapshot"].snapshot_session.return_value = []
        result = snapshot_session("sid", [])
        assert result["triplets_stored"] == 0
        assert result["chunk_ids"] == []


# ===========================================================================
# Category C — Metrics & Measurement
# ===========================================================================


class TestMetricsTools:
    """Tests for get_recall_stats, get_graph_stats,
    get_compression_stats, get_latency_report."""

    # ── get_recall_stats ───────────────────────────────────────────────────

    @pytest.mark.positive
    def test_get_recall_stats_full_recall(self, mocks):
        mocks["loci_store"].list_rooms.return_value = [
            {"wing": "w", "room": "r", "count": 2}
        ]
        mocks["loci_store"].query.return_value = _DUMMY_CHUNKS
        mocks["pipeline"].retrieve.side_effect = [
            [{"id": "c1", "text": "ChromaDB stores embeddings.", "distance": 0.1}],
            [{"id": "c2", "text": "NetworkX records the graph.", "distance": 0.2}],
        ]

        result = get_recall_stats("w", "r", sample_size=2)

        assert result["sample_size"] == 2
        assert result["recalled"] == 2
        assert result["recall_accuracy_pct"] == 100.0
        assert result["kpi_faithfulness_met"] is True
        assert result["kra_amnesia_proof_met"] is True
        assert result["avg_distance"] == 0.15

    @pytest.mark.negative
    def test_get_recall_stats_invalid_sample_size_raises(self, mocks):
        with pytest.raises(ValueError, match="sample_size"):
            get_recall_stats("w", "r", sample_size=0)

    @pytest.mark.negative
    def test_get_recall_stats_empty_wing_raises(self, mocks):
        with pytest.raises(ValueError, match="'wing'"):
            get_recall_stats("", "r")

    @pytest.mark.edge
    def test_get_recall_stats_room_not_found_returns_zeros(self, mocks):
        mocks["loci_store"].list_rooms.return_value = []
        result = get_recall_stats("w", "r")
        assert result["sample_size"] == 0
        assert result["recalled"] == 0
        assert result["recall_accuracy_pct"] == 0.0
        assert result["kpi_faithfulness_met"] is False

    @pytest.mark.edge
    def test_get_recall_stats_empty_room_returns_zeros(self, mocks):
        mocks["loci_store"].list_rooms.return_value = [
            {"wing": "w", "room": "r", "count": 0}
        ]
        result = get_recall_stats("w", "r")
        assert result["sample_size"] == 0
        assert result["avg_distance"] is None

    @pytest.mark.edge
    def test_get_recall_stats_partial_recall_no_avg_dist_when_zero(self, mocks):
        """When a chunk is not recalled, distance contribution is skipped."""
        mocks["loci_store"].list_rooms.return_value = [
            {"wing": "w", "room": "r", "count": 1}
        ]
        mocks["loci_store"].query.return_value = [
            {"id": "c1", "text": "text", "distance": 0.5}
        ]
        # retrieve returns a DIFFERENT id — not recalled
        mocks["pipeline"].retrieve.return_value = [
            {"id": "c99", "text": "other", "distance": 0.9}
        ]
        result = get_recall_stats("w", "r", sample_size=1)
        assert result["recalled"] == 0
        assert result["avg_distance"] is None
        assert result["kpi_faithfulness_met"] is False

    @pytest.mark.edge
    def test_get_recall_stats_recalled_chunk_with_none_distance(self, mocks):
        """Graph-expanded chunks with distance=None are recalled but don't add to avg."""
        mocks["loci_store"].list_rooms.return_value = [
            {"wing": "w", "room": "r", "count": 1}
        ]
        mocks["loci_store"].query.return_value = [
            {"id": "c1", "text": "text", "distance": 0.1}
        ]
        mocks["pipeline"].retrieve.return_value = [
            {"id": "c1", "text": "text", "distance": None}
        ]
        result = get_recall_stats("w", "r", sample_size=1)
        assert result["recalled"] == 1
        assert result["avg_distance"] is None  # distance=None → not summed

    # ── get_graph_stats ────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_get_graph_stats_with_edges(self, mocks):
        g = nx.DiGraph()
        g.add_node("a")
        g.add_node("b")
        g.add_node("c")
        g.add_edge("a", "b", edge_type="SEMANTIC", weight=0.9)
        g.add_edge("a", "c", edge_type="MANUAL", weight=1.0)
        mocks["graph"]._graph = g

        result = get_graph_stats()

        assert result["nodes"] == 3
        assert result["edges"] == 2
        assert result["semantic_edges"] == 1
        assert result["manual_edges"] == 1
        assert result["avg_edges_per_node"] == round(2 / 3, 4)

    @pytest.mark.negative
    def test_get_graph_stats_not_configured_raises(self):
        with pytest.raises(RuntimeError, match="not configured"):
            get_graph_stats()

    @pytest.mark.edge
    def test_get_graph_stats_empty_graph(self, mocks):
        mocks["graph"]._graph = nx.DiGraph()
        result = get_graph_stats()
        assert result["nodes"] == 0
        assert result["edges"] == 0
        assert result["avg_edges_per_node"] == 0.0

    # ── get_compression_stats ──────────────────────────────────────────────

    @pytest.mark.positive
    def test_get_compression_stats_with_sample(self, mocks):
        # 3 triplets, each 3 words → 9 compressed words total in sample
        # Room has 9 chunks, sample has 3 → scale = 3 → compressed_total = 9
        # raw = 9 × 15 = 135, ratio = 15.0
        mocks["loci_store"].query.return_value = [
            {"id": "c1", "text": "CEO opened meeting", "metadata": {}, "distance": 0.1},
            {"id": "c2", "text": "Board approved budget", "metadata": {}, "distance": 0.2},
            {"id": "c3", "text": "Team reported progress", "metadata": {}, "distance": 0.3},
        ]
        # 3 chunks sampled, room count = 3 → scale = 1.0 → compressed_total = 9
        mocks["loci_store"].list_rooms.return_value = [
            {"wing": "lt", "room": "sessions", "count": 3}
        ]

        result = get_compression_stats("lt", "sessions")

        assert result["compressed_token_estimate"] == 9
        assert result["raw_token_estimate"] == 135
        assert result["compression_ratio"] == 15.0
        assert result["kpi_compression_met"] is True   # 15 >= 5
        assert result["kra_tkd_met"] is True            # 15 >= 3

    @pytest.mark.negative
    def test_get_compression_stats_empty_wing_raises(self, mocks):
        with pytest.raises(ValueError, match="'wing'"):
            get_compression_stats("", "sessions")

    @pytest.mark.edge
    def test_get_compression_stats_no_sample_returns_zeros(self, mocks):
        mocks["loci_store"].query.return_value = []
        result = get_compression_stats("lt", "empty")
        assert result["compressed_token_estimate"] == 0
        assert result["compression_ratio"] == 0.0
        assert result["kpi_compression_met"] is False
        assert result["kra_tkd_met"] is False

    @pytest.mark.edge
    def test_get_compression_stats_room_not_in_list_uses_sample_len(self, mocks):
        """When room is not in list_rooms, falls back to len(sample) as total."""
        mocks["loci_store"].query.return_value = [
            {"id": "c1", "text": "A B C", "metadata": {}, "distance": 0.1},
        ]
        mocks["loci_store"].list_rooms.return_value = []  # room absent

        result = get_compression_stats("x", "y")
        # sample=1, total_chunks=1, scale=1, compressed=3, raw=45, ratio=15
        assert result["compression_ratio"] == 15.0
        assert result["compressed_token_estimate"] == 3

    # ── get_latency_report ─────────────────────────────────────────────────

    @pytest.mark.positive
    def test_get_latency_report_returns_stub(self, mocks):
        result = get_latency_report()
        assert result == {"status": "PulseGuard not yet active"}

    @pytest.mark.edge
    def test_get_latency_report_works_without_configured_deps(self):
        # This tool does NOT need the pipeline — it's a pure stub
        result = get_latency_report()
        assert "status" in result
