"""tests/test_pipeline.py — Unit tests for RetrievalPipeline (Phase 7).

Coverage targets: 100% line + branch for src/pipeline/retrieval.py
                  and src/pipeline/__init__.py

Markers used:
  @pytest.mark.positive — happy-path tests
  @pytest.mark.negative — error/failure conditions
  @pytest.mark.edge     — boundary values, empty inputs, None, extremes
"""

import pytest

from src.base.embedder import Embedder
from src.base.loci_store import LociStore
from src.layers.major_system.phonetic_encoder import PhoneticEncoder
from src.layers.songlines.knowledge_graph import KnowledgeGraph
from src.pipeline.retrieval import RetrievalPipeline


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_DUMMY_EMBEDDING: list[float] = [0.1, 0.2, 0.3]


def _make_pipeline(
    mocker,
    *,
    store_query_return: list[dict] | None = None,
    store_get_by_ids_return: list[dict] | None = None,
    graph_neighbors_return: list[str] | None = None,
    embed_return: list[float] | None = None,
    semantic_threshold: float = 0.3,
    neighbour_k: int = 5,
    default_top_k: int = 10,
) -> tuple[RetrievalPipeline, object, object, object, object]:
    """Build a RetrievalPipeline with all four dependencies mocked.

    Returns (pipeline, mock_store, mock_embedder, mock_graph, mock_encoder).
    """
    mock_store = mocker.MagicMock(spec=LociStore)
    mock_embedder = mocker.MagicMock(spec=Embedder)
    mock_graph = mocker.MagicMock(spec=KnowledgeGraph)
    mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

    mock_embedder.embed.return_value = embed_return or _DUMMY_EMBEDDING
    mock_store.query.return_value = store_query_return or []
    mock_store.get_by_ids.return_value = store_get_by_ids_return or []
    mock_graph.get_neighbors.return_value = graph_neighbors_return or []
    mock_encoder.extract_and_tag.return_value = {
        "phonetic_tags": [],
        "numeric_tokens": [],
    }

    pipeline = RetrievalPipeline(
        loci_store=mock_store,
        embedder=mock_embedder,
        graph=mock_graph,
        encoder=mock_encoder,
        semantic_threshold=semantic_threshold,
        neighbour_k=neighbour_k,
        default_top_k=default_top_k,
    )
    return pipeline, mock_store, mock_embedder, mock_graph, mock_encoder


# ===========================================================================
# Positive tests
# ===========================================================================


class TestRetrievalPipelinePositive:
    """Happy-path tests for RetrievalPipeline."""

    @pytest.mark.positive
    def test_store_calls_upsert(self, mocker) -> None:
        """store() must call loci_store.upsert with correct args."""
        pipeline, mock_store, mock_embedder, mock_graph, mock_encoder = _make_pipeline(
            mocker
        )
        pipeline.store("work", "notes", "c1", "hello world", {"author": "alice"})

        mock_embedder.embed.assert_called_once_with("hello world")
        mock_store.upsert.assert_called_once()
        call_args = mock_store.upsert.call_args
        assert call_args.args[0] == "work"   # wing
        assert call_args.args[1] == "notes"  # room
        assert call_args.args[2] == "c1"     # chunk_id
        assert call_args.args[3] == "hello world"  # text

    @pytest.mark.positive
    def test_store_adds_chunk_node_to_graph(self, mocker) -> None:
        """store() must register the chunk in the knowledge graph."""
        pipeline, _, _, mock_graph, _ = _make_pipeline(mocker)
        pipeline.store("work", "notes", "c1", "hello world")

        mock_graph.add_chunk_node.assert_called_once()
        call_args = mock_graph.add_chunk_node.call_args
        assert call_args.args[0] == "c1"

    @pytest.mark.positive
    def test_store_merges_caller_metadata(self, mocker) -> None:
        """store() must merge caller metadata and phonetic tags into upsert."""
        pipeline, mock_store, _, _, mock_encoder = _make_pipeline(mocker)
        mock_encoder.extract_and_tag.return_value = {
            "phonetic_tags": ["ts"],
            "numeric_tokens": ["10"],
        }

        pipeline.store("w", "r", "c1", "meeting at 10am", {"source": "calendar"})

        upsert_meta = mock_store.upsert.call_args.args[5]
        assert upsert_meta["source"] == "calendar"
        assert upsert_meta["phonetic_tags"] == "ts"
        assert upsert_meta["numeric_tokens"] == "10"

    @pytest.mark.positive
    def test_store_does_not_mutate_original_metadata(self, mocker) -> None:
        """store() must not modify the dict passed by the caller."""
        pipeline, _, _, _, _ = _make_pipeline(mocker)
        original = {"key": "value"}
        pipeline.store("w", "r", "c1", "text", original)
        assert original == {"key": "value"}

    @pytest.mark.positive
    def test_store_adds_semantic_edge_for_nearby_neighbour(self, mocker) -> None:
        """store() must add a SEMANTIC edge when a neighbour's distance is within threshold."""
        close_neighbour = {"id": "n1", "text": "near", "metadata": {}, "distance": 0.1}
        pipeline, _, _, mock_graph, _ = _make_pipeline(
            mocker, store_query_return=[close_neighbour], semantic_threshold=0.3
        )

        pipeline.store("w", "r", "c1", "text")

        mock_graph.add_edge.assert_called_once_with("c1", "n1", "SEMANTIC", weight=pytest.approx(0.9))

    @pytest.mark.positive
    def test_store_skips_semantic_edge_for_distant_neighbour(self, mocker) -> None:
        """store() must NOT add a SEMANTIC edge when distance exceeds threshold."""
        far_neighbour = {"id": "n2", "text": "far", "metadata": {}, "distance": 0.5}
        pipeline, _, _, mock_graph, _ = _make_pipeline(
            mocker, store_query_return=[far_neighbour], semantic_threshold=0.3
        )

        pipeline.store("w", "r", "c1", "text")

        mock_graph.add_edge.assert_not_called()

    @pytest.mark.positive
    def test_store_skips_self_semantic_edge(self, mocker) -> None:
        """store() must skip adding a SEMANTIC edge to the chunk itself."""
        self_result = {"id": "c1", "text": "same", "metadata": {}, "distance": 0.0}
        pipeline, _, _, mock_graph, _ = _make_pipeline(
            mocker, store_query_return=[self_result]
        )

        pipeline.store("w", "r", "c1", "text")

        mock_graph.add_edge.assert_not_called()

    @pytest.mark.positive
    def test_retrieve_returns_semantic_hits(self, mocker) -> None:
        """retrieve() must return top-K semantic hits from loci_store."""
        hit = {"id": "c1", "text": "hello", "metadata": {}, "distance": 0.1}
        pipeline, mock_store, _, _, _ = _make_pipeline(
            mocker, store_query_return=[hit]
        )

        results = pipeline.retrieve("hello", "w", "r", top_k=5)

        mock_store.query.assert_called_once()
        assert len(results) == 1
        assert results[0]["id"] == "c1"
        assert results[0]["distance"] == 0.1

    @pytest.mark.positive
    def test_retrieve_expands_graph_neighbours(self, mocker) -> None:
        """retrieve() must fetch graph-expanded chunks and append them."""
        hit = {"id": "c1", "text": "hit", "metadata": {}, "distance": 0.1}
        expanded = {"id": "c2", "text": "expanded", "metadata": {}}
        pipeline, mock_store, _, mock_graph, _ = _make_pipeline(
            mocker,
            store_query_return=[hit],
            graph_neighbors_return=["c2"],
            store_get_by_ids_return=[expanded],
        )

        results = pipeline.retrieve("query", "w", "r", top_k=10)

        mock_graph.get_neighbors.assert_called_once_with("c1")
        mock_store.get_by_ids.assert_called_once_with("w", "r", ["c2"])
        assert len(results) == 2
        assert results[0]["id"] == "c1"   # direct hit first (lower distance)
        assert results[1]["id"] == "c2"   # graph-expanded last (distance=None)

    @pytest.mark.positive
    def test_retrieve_attaches_query_phonetic_tags(self, mocker) -> None:
        """retrieve() must attach phonetic_tags to every result."""
        hit = {"id": "c1", "text": "meeting at 42", "metadata": {}, "distance": 0.1}
        pipeline, _, _, _, mock_encoder = _make_pipeline(
            mocker, store_query_return=[hit]
        )
        mock_encoder.extract_and_tag.return_value = {
            "phonetic_tags": ["rn"],
            "numeric_tokens": ["42"],
        }

        results = pipeline.retrieve("42 days", "w", "r")

        assert results[0]["phonetic_tags"] == ["rn"]

    @pytest.mark.positive
    def test_retrieve_uses_default_top_k_when_none(self, mocker) -> None:
        """retrieve() must use default_top_k when top_k=None."""
        pipeline, mock_store, _, _, _ = _make_pipeline(mocker, default_top_k=7)

        pipeline.retrieve("q", "w", "r", top_k=None)

        call_args = mock_store.query.call_args
        assert call_args.args[3] == 7

    @pytest.mark.positive
    def test_retrieve_deduplicates_expanded_ids(self, mocker) -> None:
        """retrieve() must not fetch the same expanded ID twice."""
        hit1 = {"id": "c1", "text": "h1", "metadata": {}, "distance": 0.1}
        hit2 = {"id": "c2", "text": "h2", "metadata": {}, "distance": 0.2}
        # Both hits have "c3" as a neighbour — c3 should only be fetched once
        pipeline, mock_store, _, mock_graph, _ = _make_pipeline(
            mocker,
            store_query_return=[hit1, hit2],
            store_get_by_ids_return=[],
        )
        mock_graph.get_neighbors.side_effect = [["c3"], ["c3"]]

        pipeline.retrieve("q", "w", "r", top_k=10)

        # get_by_ids should only be called with ["c3"] (deduplicated)
        mock_store.get_by_ids.assert_called_once_with("w", "r", ["c3"])

    @pytest.mark.positive
    def test_retrieve_deduplicates_hit_ids_from_graph(self, mocker) -> None:
        """retrieve() must not include direct hit IDs in the graph expansion fetch."""
        hit = {"id": "c1", "text": "h1", "metadata": {}, "distance": 0.1}
        # Graph neighbour is c1 itself — already in hits, must not be re-fetched
        pipeline, mock_store, _, mock_graph, _ = _make_pipeline(
            mocker,
            store_query_return=[hit],
            graph_neighbors_return=["c1"],
        )

        pipeline.retrieve("q", "w", "r")

        mock_store.get_by_ids.assert_not_called()

    @pytest.mark.positive
    def test_store_no_metadata_argument(self, mocker) -> None:
        """store() with metadata=None must default to an empty metadata dict."""
        pipeline, mock_store, _, _, _ = _make_pipeline(mocker)
        pipeline.store("w", "r", "c1", "text")

        upsert_meta = mock_store.upsert.call_args.args[5]
        # Should be a dict (possibly empty, possibly phonetic enriched)
        assert isinstance(upsert_meta, dict)

    @pytest.mark.positive
    def test_retrieve_sorted_by_distance_ascending(self, mocker) -> None:
        """retrieve() results must be sorted ascending by distance."""
        hit1 = {"id": "c1", "text": "a", "metadata": {}, "distance": 0.8}
        hit2 = {"id": "c2", "text": "b", "metadata": {}, "distance": 0.2}
        pipeline, _, _, _, _ = _make_pipeline(mocker, store_query_return=[hit1, hit2])

        results = pipeline.retrieve("q", "w", "r", top_k=10)

        assert results[0]["id"] == "c2"
        assert results[1]["id"] == "c1"

    @pytest.mark.positive
    def test_retrieve_respects_top_k_limit(self, mocker) -> None:
        """retrieve() must return at most top_k results."""
        hits = [
            {"id": f"c{i}", "text": f"t{i}", "metadata": {}, "distance": 0.1 * i}
            for i in range(8)
        ]
        pipeline, _, _, _, _ = _make_pipeline(mocker, store_query_return=hits)

        results = pipeline.retrieve("q", "w", "r", top_k=3)

        assert len(results) == 3


# ===========================================================================
# Negative tests
# ===========================================================================


class TestRetrievalPipelineNegative:
    """Error condition tests for RetrievalPipeline constructor."""

    @pytest.mark.negative
    def test_none_loci_store_raises(self, mocker) -> None:
        mock_embedder = mocker.MagicMock(spec=Embedder)
        mock_graph = mocker.MagicMock(spec=KnowledgeGraph)
        mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

        with pytest.raises(ValueError, match="loci_store must not be None"):
            RetrievalPipeline(
                loci_store=None,
                embedder=mock_embedder,
                graph=mock_graph,
                encoder=mock_encoder,
            )

    @pytest.mark.negative
    def test_none_embedder_raises(self, mocker) -> None:
        mock_store = mocker.MagicMock(spec=LociStore)
        mock_graph = mocker.MagicMock(spec=KnowledgeGraph)
        mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

        with pytest.raises(ValueError, match="embedder must not be None"):
            RetrievalPipeline(
                loci_store=mock_store,
                embedder=None,
                graph=mock_graph,
                encoder=mock_encoder,
            )

    @pytest.mark.negative
    def test_none_graph_raises(self, mocker) -> None:
        mock_store = mocker.MagicMock(spec=LociStore)
        mock_embedder = mocker.MagicMock(spec=Embedder)
        mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

        with pytest.raises(ValueError, match="graph must not be None"):
            RetrievalPipeline(
                loci_store=mock_store,
                embedder=mock_embedder,
                graph=None,
                encoder=mock_encoder,
            )

    @pytest.mark.negative
    def test_none_encoder_raises(self, mocker) -> None:
        mock_store = mocker.MagicMock(spec=LociStore)
        mock_embedder = mocker.MagicMock(spec=Embedder)
        mock_graph = mocker.MagicMock(spec=KnowledgeGraph)

        with pytest.raises(ValueError, match="encoder must not be None"):
            RetrievalPipeline(
                loci_store=mock_store,
                embedder=mock_embedder,
                graph=mock_graph,
                encoder=None,
            )

    @pytest.mark.negative
    def test_invalid_semantic_threshold_below_zero_raises(self, mocker) -> None:
        mock_store = mocker.MagicMock(spec=LociStore)
        mock_embedder = mocker.MagicMock(spec=Embedder)
        mock_graph = mocker.MagicMock(spec=KnowledgeGraph)
        mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

        with pytest.raises(ValueError, match="semantic_threshold"):
            RetrievalPipeline(
                loci_store=mock_store,
                embedder=mock_embedder,
                graph=mock_graph,
                encoder=mock_encoder,
                semantic_threshold=-0.1,
            )

    @pytest.mark.negative
    def test_invalid_semantic_threshold_above_two_raises(self, mocker) -> None:
        mock_store = mocker.MagicMock(spec=LociStore)
        mock_embedder = mocker.MagicMock(spec=Embedder)
        mock_graph = mocker.MagicMock(spec=KnowledgeGraph)
        mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

        with pytest.raises(ValueError, match="semantic_threshold"):
            RetrievalPipeline(
                loci_store=mock_store,
                embedder=mock_embedder,
                graph=mock_graph,
                encoder=mock_encoder,
                semantic_threshold=2.1,
            )

    @pytest.mark.negative
    def test_invalid_neighbour_k_raises(self, mocker) -> None:
        mock_store = mocker.MagicMock(spec=LociStore)
        mock_embedder = mocker.MagicMock(spec=Embedder)
        mock_graph = mocker.MagicMock(spec=KnowledgeGraph)
        mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

        with pytest.raises(ValueError, match="neighbour_k"):
            RetrievalPipeline(
                loci_store=mock_store,
                embedder=mock_embedder,
                graph=mock_graph,
                encoder=mock_encoder,
                neighbour_k=0,
            )

    @pytest.mark.negative
    def test_invalid_default_top_k_raises(self, mocker) -> None:
        mock_store = mocker.MagicMock(spec=LociStore)
        mock_embedder = mocker.MagicMock(spec=Embedder)
        mock_graph = mocker.MagicMock(spec=KnowledgeGraph)
        mock_encoder = mocker.MagicMock(spec=PhoneticEncoder)

        with pytest.raises(ValueError, match="default_top_k"):
            RetrievalPipeline(
                loci_store=mock_store,
                embedder=mock_embedder,
                graph=mock_graph,
                encoder=mock_encoder,
                default_top_k=0,
            )


# ===========================================================================
# Edge tests
# ===========================================================================


class TestRetrievalPipelineEdge:
    """Boundary, empty-input, and extreme-value tests."""

    @pytest.mark.edge
    def test_retrieve_empty_store_returns_empty_list(self, mocker) -> None:
        """retrieve() must return [] when LociStore returns no hits."""
        pipeline, _, _, _, _ = _make_pipeline(mocker, store_query_return=[])

        results = pipeline.retrieve("q", "w", "r", top_k=5)

        assert results == []

    @pytest.mark.edge
    def test_retrieve_no_graph_neighbours_returns_only_hits(self, mocker) -> None:
        """retrieve() must work when graph returns no neighbours."""
        hit = {"id": "c1", "text": "hit", "metadata": {}, "distance": 0.1}
        pipeline, mock_store, _, _, _ = _make_pipeline(
            mocker,
            store_query_return=[hit],
            graph_neighbors_return=[],
        )

        results = pipeline.retrieve("q", "w", "r", top_k=5)

        mock_store.get_by_ids.assert_not_called()
        assert len(results) == 1

    @pytest.mark.edge
    def test_store_with_empty_text_no_phonetic_tags(self, mocker) -> None:
        """store() with text containing no digits must not add phonetic metadata."""
        pipeline, mock_store, _, _, mock_encoder = _make_pipeline(mocker)
        mock_encoder.extract_and_tag.return_value = {
            "phonetic_tags": [],
            "numeric_tokens": [],
        }

        pipeline.store("w", "r", "c1", "no numbers here")

        upsert_meta = mock_store.upsert.call_args.args[5]
        assert "phonetic_tags" not in upsert_meta
        assert "numeric_tokens" not in upsert_meta

    @pytest.mark.edge
    def test_retrieve_top_k_one(self, mocker) -> None:
        """retrieve() with top_k=1 must return at most one result."""
        hits = [
            {"id": "c1", "text": "a", "metadata": {}, "distance": 0.1},
            {"id": "c2", "text": "b", "metadata": {}, "distance": 0.2},
        ]
        pipeline, _, _, _, _ = _make_pipeline(mocker, store_query_return=hits)

        results = pipeline.retrieve("q", "w", "r", top_k=1)

        assert len(results) == 1
        assert results[0]["id"] == "c1"

    @pytest.mark.edge
    def test_semantic_threshold_at_boundary_zero(self, mocker) -> None:
        """semantic_threshold=0.0 is a valid boundary value (constructor must not raise)."""
        pipeline, _, _, _, _ = _make_pipeline(mocker, semantic_threshold=0.0)
        assert pipeline is not None

    @pytest.mark.edge
    def test_semantic_threshold_at_boundary_two(self, mocker) -> None:
        """semantic_threshold=2.0 is a valid boundary value (constructor must not raise)."""
        pipeline, _, _, _, _ = _make_pipeline(mocker, semantic_threshold=2.0)
        assert pipeline is not None

    @pytest.mark.edge
    def test_neighbour_k_minimum_one(self, mocker) -> None:
        """neighbour_k=1 is the minimum valid value (constructor must not raise)."""
        pipeline, _, _, _, _ = _make_pipeline(mocker, neighbour_k=1)
        assert pipeline is not None

    @pytest.mark.edge
    def test_default_top_k_minimum_one(self, mocker) -> None:
        """default_top_k=1 is the minimum valid value (constructor must not raise)."""
        pipeline, _, _, _, _ = _make_pipeline(mocker, default_top_k=1)
        assert pipeline is not None

    @pytest.mark.edge
    def test_retrieve_expanded_chunks_sorted_after_hits(self, mocker) -> None:
        """Graph-expanded chunks (distance=None) must always appear after scored hits."""
        hit = {"id": "c1", "text": "h1", "metadata": {}, "distance": 0.9}
        expanded = {"id": "c2", "text": "e1", "metadata": {}}
        pipeline, _, _, mock_graph, _ = _make_pipeline(
            mocker,
            store_query_return=[hit],
            graph_neighbors_return=["c2"],
            store_get_by_ids_return=[expanded],
        )

        results = pipeline.retrieve("q", "w", "r", top_k=10)

        # hit has distance 0.9 (real), expanded has None — expanded goes last
        assert results[0]["id"] == "c1"
        assert results[1]["id"] == "c2"
        assert results[1]["distance"] is None

    @pytest.mark.edge
    def test_store_multiple_phonetic_tags_comma_joined(self, mocker) -> None:
        """store() must join multiple phonetic tags with commas."""
        pipeline, mock_store, _, _, mock_encoder = _make_pipeline(mocker)
        mock_encoder.extract_and_tag.return_value = {
            "phonetic_tags": ["ts", "rn"],
            "numeric_tokens": ["10", "42"],
        }

        pipeline.store("w", "r", "c1", "10 items and 42 days")

        upsert_meta = mock_store.upsert.call_args.args[5]
        assert upsert_meta["phonetic_tags"] == "ts,rn"
        assert upsert_meta["numeric_tokens"] == "10,42"


# ===========================================================================
# Property tests (Phase 8 additions — read-only configuration exposure)
# ===========================================================================


class TestRetrievalPipelineProperties:
    """Tests for the three read-only configuration properties and encoder property."""

    @pytest.mark.positive
    def test_semantic_threshold_property_returns_value(self, mocker) -> None:
        pipeline, _, _, _, _ = _make_pipeline(mocker, semantic_threshold=0.45)
        assert pipeline.semantic_threshold == 0.45

    @pytest.mark.positive
    def test_neighbour_k_property_returns_value(self, mocker) -> None:
        pipeline, _, _, _, _ = _make_pipeline(mocker, neighbour_k=7)
        assert pipeline.neighbour_k == 7

    @pytest.mark.positive
    def test_default_top_k_property_returns_value(self, mocker) -> None:
        pipeline, _, _, _, _ = _make_pipeline(mocker, default_top_k=3)
        assert pipeline.default_top_k == 3

    @pytest.mark.positive
    def test_encoder_property_returns_injected_encoder(self, mocker) -> None:
        pipeline, _, _, _, mock_encoder = _make_pipeline(mocker)
        assert pipeline.encoder is mock_encoder

