"""tests/test_openai_client.py — Unit tests for OpenAIClient.

Covers:
- src/llm/openai_client.py (OpenAIClient)

All SDK calls are mocked — no real network traffic is made.
One class per file — Separation of Concerns principle.
"""

from __future__ import annotations

import openai
import pytest

from src.llm.openai_client import OpenAIClient


class TestOpenAIClient:

    # ── helpers ───────────────────────────────────────────────────────────────

    def _build_client(self, mocker, content: str | None = "result"):
        """Patch openai.OpenAI and return (OpenAIClient, mock_openai_instance)."""
        mock_cls = mocker.patch("openai.OpenAI")
        mock_inst = mock_cls.return_value
        mock_response = mocker.MagicMock()
        mock_response.choices[0].message.content = content
        mock_inst.chat.completions.create.return_value = mock_response
        client = OpenAIClient(api_key="sk-test", model="gpt-4o-mini")
        return client, mock_inst

    # ── negative — construction-time errors ───────────────────────────────────

    @pytest.mark.negative
    def test_none_api_key_raises_value_error(self):
        """None api_key raises ValueError at construction."""
        with pytest.raises(ValueError, match="OPENAI_API_KEY is required"):
            OpenAIClient(api_key=None, model="gpt-4o-mini")

    @pytest.mark.negative
    def test_empty_api_key_raises_value_error(self):
        """Empty-string api_key raises ValueError at construction."""
        with pytest.raises(ValueError, match="OPENAI_API_KEY is required"):
            OpenAIClient(api_key="", model="gpt-4o-mini")

    # ── positive ──────────────────────────────────────────────────────────────

    @pytest.mark.positive
    def test_complete_strips_whitespace(self, mocker):
        """complete() strips leading/trailing whitespace from the API content."""
        mock_cls = mocker.patch("openai.OpenAI")
        mock_inst = mock_cls.return_value
        mock_response = mocker.MagicMock()
        mock_response.choices[0].message.content = "  hello  "
        mock_inst.chat.completions.create.return_value = mock_response
        client = OpenAIClient(api_key="sk-test", model="gpt-4o-mini")
        assert client.complete("Say hi") == "hello"

    @pytest.mark.positive
    def test_complete_with_system_sends_system_role_message(self, mocker):
        """System prompt is prepended as a 'system' role message."""
        client, mock_inst = self._build_client(mocker)
        client.complete("user msg", system="Be brief.")

        messages = mock_inst.chat.completions.create.call_args.kwargs["messages"]
        assert messages[0] == {"role": "system", "content": "Be brief."}
        assert messages[1] == {"role": "user", "content": "user msg"}

    @pytest.mark.positive
    def test_complete_without_system_sends_user_message_only(self, mocker):
        """Without system, only the user message is in the messages list."""
        client, mock_inst = self._build_client(mocker)
        client.complete("user msg")

        messages = mock_inst.chat.completions.create.call_args.kwargs["messages"]
        assert len(messages) == 1
        assert messages[0]["role"] == "user"

    # ── negative ──────────────────────────────────────────────────────────────

    @pytest.mark.negative
    def test_openai_error_raises_runtime_error(self, mocker):
        """OpenAIError from the SDK is wrapped in RuntimeError."""
        mock_cls = mocker.patch("openai.OpenAI")
        mock_inst = mock_cls.return_value
        mock_inst.chat.completions.create.side_effect = openai.OpenAIError("quota")
        client = OpenAIClient(api_key="sk-test", model="gpt-4o-mini")
        with pytest.raises(RuntimeError, match="OpenAI API error"):
            client.complete("prompt")

    # ── edge ──────────────────────────────────────────────────────────────────

    @pytest.mark.edge
    def test_none_content_returns_empty_string(self, mocker):
        """content=None from the API is handled gracefully as ''."""
        client, _ = self._build_client(mocker, content=None)
        assert client.complete("prompt") == ""
