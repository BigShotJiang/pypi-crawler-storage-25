"""
tests/test_config.py — Unit tests for src/config.py.

Coverage targets: 100% line AND branch.

Scenarios
---------
Positive : correct defaults, provider switching, field reading.
Negative : unsupported provider raises ValueError; late-import failures
           propagate from concrete client constructors.
Edge     : provider string casing, whitespace, boundary int values.
"""

from __future__ import annotations

import pytest

from src.config import Settings, _SUPPORTED_PROVIDERS


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_settings(**overrides) -> Settings:
    """Build a Settings instance with all env loading bypassed."""
    return Settings.model_construct(**overrides)


# ─────────────────────────────────────────────────────────────────────────────
# Positive tests
# ─────────────────────────────────────────────────────────────────────────────

class TestDefaults:
    @pytest.mark.positive
    def test_llm_provider_default(self) -> None:
        s = _make_settings()
        assert s.llm_provider == "ollama"

    @pytest.mark.positive
    def test_ollama_base_url_default(self) -> None:
        s = _make_settings()
        assert s.ollama_base_url == "http://localhost:11434"

    @pytest.mark.positive
    def test_ollama_model_default(self) -> None:
        s = _make_settings()
        assert s.ollama_model == "llama3.2"

    @pytest.mark.positive
    def test_openai_model_default(self) -> None:
        s = _make_settings()
        assert s.openai_model == "gpt-4o-mini"

    @pytest.mark.positive
    def test_gemini_model_default(self) -> None:
        s = _make_settings()
        assert s.gemini_model == "gemini-2.5-flash"

    @pytest.mark.positive
    def test_anthropic_model_default(self) -> None:
        s = _make_settings()
        assert s.anthropic_model == "claude-3-haiku-20240307"

    @pytest.mark.positive
    def test_chroma_persist_dir_default(self) -> None:
        s = _make_settings()
        assert s.chroma_persist_dir == "./data/chroma"

    @pytest.mark.positive
    def test_embedding_model_default(self) -> None:
        s = _make_settings()
        assert s.embedding_model == "all-MiniLM-L6-v2"

    @pytest.mark.positive
    def test_default_top_k_default(self) -> None:
        s = _make_settings()
        assert s.default_top_k == 5

    @pytest.mark.positive
    def test_api_keys_default_to_none(self) -> None:
        s = _make_settings()
        assert s.openai_api_key is None
        assert s.gemini_api_key is None
        assert s.anthropic_api_key is None


class TestSupportedProviders:
    @pytest.mark.positive
    def test_supported_providers_set(self) -> None:
        assert _SUPPORTED_PROVIDERS == {"ollama", "openai", "gemini", "anthropic"}


class TestGetLlmClientFactory:
    @pytest.mark.positive
    def test_returns_ollama_client(self, mocker) -> None:
        mock_cls = mocker.MagicMock()
        mocker.patch.dict(
            "sys.modules",
            {"src.llm.ollama_client": mocker.MagicMock(OllamaClient=mock_cls)},
        )
        s = _make_settings(llm_provider="ollama",
                           ollama_base_url="http://localhost:11434",
                           ollama_model="llama3.2")
        client = s.get_llm_client()
        mock_cls.assert_called_once_with(
            base_url="http://localhost:11434", model="llama3.2"
        )
        assert client is mock_cls.return_value

    @pytest.mark.positive
    def test_returns_openai_client(self, mocker) -> None:
        mock_cls = mocker.MagicMock()
        mocker.patch.dict(
            "sys.modules",
            {"src.llm.openai_client": mocker.MagicMock(OpenAIClient=mock_cls)},
        )
        s = _make_settings(llm_provider="openai",
                           openai_api_key="sk-test",
                           openai_model="gpt-4o-mini")
        client = s.get_llm_client()
        mock_cls.assert_called_once_with(api_key="sk-test", model="gpt-4o-mini")
        assert client is mock_cls.return_value

    @pytest.mark.positive
    def test_returns_gemini_client(self, mocker) -> None:
        mock_cls = mocker.MagicMock()
        mocker.patch.dict(
            "sys.modules",
            {"src.llm.gemini_client": mocker.MagicMock(GeminiClient=mock_cls)},
        )
        s = _make_settings(llm_provider="gemini",
                           gemini_api_key="AI-test",
                           gemini_model="gemini-2.5-flash")
        client = s.get_llm_client()
        mock_cls.assert_called_once_with(api_key="AI-test", model="gemini-2.5-flash")
        assert client is mock_cls.return_value

    @pytest.mark.positive
    def test_returns_anthropic_client(self, mocker) -> None:
        mock_cls = mocker.MagicMock()
        mocker.patch.dict(
            "sys.modules",
            {"src.llm.anthropic_client": mocker.MagicMock(AnthropicClient=mock_cls)},
        )
        s = _make_settings(llm_provider="anthropic",
                           anthropic_api_key="sk-ant-test",
                           anthropic_model="claude-3-haiku-20240307")
        client = s.get_llm_client()
        mock_cls.assert_called_once_with(
            api_key="sk-ant-test", model="claude-3-haiku-20240307"
        )
        assert client is mock_cls.return_value


# ─────────────────────────────────────────────────────────────────────────────
# Negative tests
# ─────────────────────────────────────────────────────────────────────────────

class TestGetLlmClientErrors:
    @pytest.mark.negative
    def test_unsupported_provider_raises_value_error(self) -> None:
        s = _make_settings(llm_provider="unknown_llm")
        with pytest.raises(ValueError, match="Unsupported LLM_PROVIDER"):
            s.get_llm_client()

    @pytest.mark.negative
    def test_empty_provider_raises_value_error(self) -> None:
        s = _make_settings(llm_provider="")
        with pytest.raises(ValueError, match="Unsupported LLM_PROVIDER"):
            s.get_llm_client()

    @pytest.mark.negative
    def test_unsupported_provider_message_lists_valid_options(self) -> None:
        s = _make_settings(llm_provider="grok")
        with pytest.raises(ValueError) as exc_info:
            s.get_llm_client()
        msg = str(exc_info.value)
        for name in sorted(_SUPPORTED_PROVIDERS):
            assert name in msg


# ─────────────────────────────────────────────────────────────────────────────
# Edge tests
# ─────────────────────────────────────────────────────────────────────────────

class TestEdgeCases:
    @pytest.mark.edge
    def test_provider_uppercase_is_normalised(self, mocker) -> None:
        """Provider matching must be case-insensitive via .lower()."""
        mock_cls = mocker.MagicMock()
        mocker.patch.dict(
            "sys.modules",
            {"src.llm.ollama_client": mocker.MagicMock(OllamaClient=mock_cls)},
        )
        s = _make_settings(llm_provider="OLLAMA",
                           ollama_base_url="http://localhost:11434",
                           ollama_model="llama3.2")
        s.get_llm_client()
        mock_cls.assert_called_once()

    @pytest.mark.edge
    def test_provider_with_leading_trailing_whitespace(self, mocker) -> None:
        """Provider matching strips whitespace via .strip()."""
        mock_cls = mocker.MagicMock()
        mocker.patch.dict(
            "sys.modules",
            {"src.llm.ollama_client": mocker.MagicMock(OllamaClient=mock_cls)},
        )
        s = _make_settings(llm_provider="  ollama  ",
                           ollama_base_url="http://localhost:11434",
                           ollama_model="llama3.2")
        s.get_llm_client()
        mock_cls.assert_called_once()

    @pytest.mark.edge
    def test_default_top_k_minimum_value(self) -> None:
        s = _make_settings(default_top_k=1)
        assert s.default_top_k == 1

    @pytest.mark.edge
    def test_default_top_k_large_value(self) -> None:
        s = _make_settings(default_top_k=1000)
        assert s.default_top_k == 1000

    @pytest.mark.edge
    def test_openai_api_key_empty_string_stored_as_given(self) -> None:
        """Empty string is distinct from None — provider must handle it."""
        s = _make_settings(openai_api_key="")
        assert s.openai_api_key == ""

    @pytest.mark.edge
    def test_chroma_persist_dir_custom_path(self) -> None:
        s = _make_settings(chroma_persist_dir="/tmp/custom_chroma")
        assert s.chroma_persist_dir == "/tmp/custom_chroma"
