"""tests/test_phonetic_encoder.py — Unit tests for PhoneticEncoder.

Coverage targets: 100% line + branch.
Scenarios: Positive, Negative, Edge.
"""

import pytest

from src.layers.major_system.phonetic_encoder import PhoneticEncoder


class TestPhoneticEncoder:
    """Unit tests for the Major System PhoneticEncoder."""

    # ------------------------------------------------------------------
    # Fixtures
    # ------------------------------------------------------------------

    @pytest.fixture()
    def encoder(self) -> PhoneticEncoder:
        """Return a fresh PhoneticEncoder instance."""
        return PhoneticEncoder()

    # ------------------------------------------------------------------
    # Positive — happy-path tests
    # ------------------------------------------------------------------

    @pytest.mark.positive
    def test_encode_single_digit_zero(self, encoder: PhoneticEncoder) -> None:
        """0 maps to 's'."""
        assert encoder.encode_number("0") == "s"

    @pytest.mark.positive
    def test_encode_single_digit_one(self, encoder: PhoneticEncoder) -> None:
        """1 maps to 't'."""
        assert encoder.encode_number("1") == "t"

    @pytest.mark.positive
    def test_encode_single_digit_two(self, encoder: PhoneticEncoder) -> None:
        """2 maps to 'n'."""
        assert encoder.encode_number("2") == "n"

    @pytest.mark.positive
    def test_encode_single_digit_three(self, encoder: PhoneticEncoder) -> None:
        """3 maps to 'm'."""
        assert encoder.encode_number("3") == "m"

    @pytest.mark.positive
    def test_encode_single_digit_four(self, encoder: PhoneticEncoder) -> None:
        """4 maps to 'r'."""
        assert encoder.encode_number("4") == "r"

    @pytest.mark.positive
    def test_encode_single_digit_five(self, encoder: PhoneticEncoder) -> None:
        """5 maps to 'l'."""
        assert encoder.encode_number("5") == "l"

    @pytest.mark.positive
    def test_encode_single_digit_six(self, encoder: PhoneticEncoder) -> None:
        """6 maps to 'sh'."""
        assert encoder.encode_number("6") == "sh"

    @pytest.mark.positive
    def test_encode_single_digit_seven(self, encoder: PhoneticEncoder) -> None:
        """7 maps to 'k'."""
        assert encoder.encode_number("7") == "k"

    @pytest.mark.positive
    def test_encode_single_digit_eight(self, encoder: PhoneticEncoder) -> None:
        """8 maps to 'f'."""
        assert encoder.encode_number("8") == "f"

    @pytest.mark.positive
    def test_encode_single_digit_nine(self, encoder: PhoneticEncoder) -> None:
        """9 maps to 'p'."""
        assert encoder.encode_number("9") == "p"

    @pytest.mark.positive
    def test_encode_two_digit_number(self, encoder: PhoneticEncoder) -> None:
        """42 → 'rn' (4→r, 2→n)."""
        assert encoder.encode_number("42") == "rn"

    @pytest.mark.positive
    def test_encode_multi_digit_number(self, encoder: PhoneticEncoder) -> None:
        """1942 → 'tprn' (1→t, 9→p, 4→r, 2→n)."""
        assert encoder.encode_number("1942") == "tprn"

    @pytest.mark.positive
    def test_encode_six_produces_digraph(self, encoder: PhoneticEncoder) -> None:
        """A number containing 6 produces the two-character tag 'sh'."""
        result = encoder.encode_number("16")
        assert result == "tsh"

    @pytest.mark.positive
    def test_extract_and_tag_single_number(self, encoder: PhoneticEncoder) -> None:
        """Single number in text is extracted and tagged correctly."""
        result = encoder.extract_and_tag("version 42")
        assert result == {"phonetic_tags": ["rn"], "numeric_tokens": ["42"]}

    @pytest.mark.positive
    def test_extract_and_tag_multiple_numbers(self, encoder: PhoneticEncoder) -> None:
        """Multiple numbers in text are each extracted and tagged."""
        result = encoder.extract_and_tag("meeting at 42 days and 10 hours")
        assert result == {"phonetic_tags": ["rn", "ts"], "numeric_tokens": ["42", "10"]}

    @pytest.mark.positive
    def test_extract_and_tag_preserves_order(self, encoder: PhoneticEncoder) -> None:
        """Tags and tokens are returned in left-to-right order."""
        result = encoder.extract_and_tag("3 frogs and 7 cats")
        assert result["numeric_tokens"] == ["3", "7"]
        assert result["phonetic_tags"] == ["m", "k"]

    @pytest.mark.positive
    def test_extract_and_tag_returns_dict_with_correct_keys(
        self, encoder: PhoneticEncoder
    ) -> None:
        """Result always contains both 'phonetic_tags' and 'numeric_tokens' keys."""
        result = encoder.extract_and_tag("any text 5")
        assert "phonetic_tags" in result
        assert "numeric_tokens" in result

    # ------------------------------------------------------------------
    # Negative — error / failure conditions
    # ------------------------------------------------------------------

    @pytest.mark.negative
    def test_encode_number_skips_non_digits(self, encoder: PhoneticEncoder) -> None:
        """Non-digit characters in number_str are silently skipped."""
        # Only the digit '4' is encoded; hyphen is ignored
        assert encoder.encode_number("4-2") == "rn"

    @pytest.mark.negative
    def test_extract_and_tag_no_numbers_in_text(
        self, encoder: PhoneticEncoder
    ) -> None:
        """Text with no digits returns empty lists for both keys."""
        result = encoder.extract_and_tag("no numbers here at all")
        assert result == {"phonetic_tags": [], "numeric_tokens": []}

    # ------------------------------------------------------------------
    # Edge — boundary values, empty inputs, single items, zero
    # ------------------------------------------------------------------

    @pytest.mark.edge
    def test_encode_number_empty_string(self, encoder: PhoneticEncoder) -> None:
        """encode_number('') returns empty string."""
        assert encoder.encode_number("") == ""

    @pytest.mark.edge
    def test_encode_number_all_sixes(self, encoder: PhoneticEncoder) -> None:
        """666 → 'shshsh' — digraph repeated per digit."""
        assert encoder.encode_number("666") == "shshsh"

    @pytest.mark.edge
    def test_encode_number_zero_only(self, encoder: PhoneticEncoder) -> None:
        """'0' maps to 's', not an empty string."""
        assert encoder.encode_number("0") == "s"

    @pytest.mark.edge
    def test_extract_and_tag_empty_string(self, encoder: PhoneticEncoder) -> None:
        """extract_and_tag('') returns empty lists."""
        result = encoder.extract_and_tag("")
        assert result == {"phonetic_tags": [], "numeric_tokens": []}

    @pytest.mark.edge
    def test_extract_and_tag_only_digits(self, encoder: PhoneticEncoder) -> None:
        """Text that is purely digits is treated as one numeric token."""
        result = encoder.extract_and_tag("123")
        assert result == {"phonetic_tags": ["tnm"], "numeric_tokens": ["123"]}

    @pytest.mark.edge
    def test_extract_and_tag_adjacent_numbers(self, encoder: PhoneticEncoder) -> None:
        """Two numbers separated by a space are treated as two tokens."""
        result = encoder.extract_and_tag("1 2")
        assert result == {"phonetic_tags": ["t", "n"], "numeric_tokens": ["1", "2"]}

    @pytest.mark.edge
    def test_extract_and_tag_number_at_start_and_end(
        self, encoder: PhoneticEncoder
    ) -> None:
        """Numbers at very start and end of string are both captured."""
        result = encoder.extract_and_tag("7 in the middle 3")
        assert result["numeric_tokens"] == ["7", "3"]
        assert result["phonetic_tags"] == ["k", "m"]
