# contsql

Minimal DuckDB SQL agent. Soru sor, SQL üret, çalıştır, göster.

## Kullanım

```bash
# Tek soru
python contsql.py ~/projects/ews_v511/ews_dashboard/db/ews.duckdb "en riskli 10 firma"

# İnteraktif mod
python contsql.py ~/projects/ews_v511/ews_dashboard/db/ews.duckdb

# Trace açık
python contsql.py ~/projects/ews_v511/ews_dashboard/db/ews.duckdb --trace "firma adedi"

# Farklı model
python contsql.py ~/db.duckdb --model qwen3-coder "kaç tablo var"
```

## Gereksinimler

- Python 3.10+
- `duckdb`, `requests`
- Ollama çalışıyor olmalı (localhost:11434)
- Model yüklü: `cont-local` (default) veya `CONTSQL_MODEL` env var

## Env vars

- `OLLAMA_HOST` — Ollama URL (default: http://localhost:11434)
- `CONTSQL_MODEL` — Model adı (default: cont-local)
- `CONTSQL_TIMEOUT` — LLM timeout saniye (default: 120)

## Domain bilgisi

`domain_notes.txt` dosyası DB dizininde veya contsql dizininde varsa
system prompt'a eklenir. Yoksa sadece schema ile çalışır.

## Güvenlik

- Connection: `read_only=True`
- SQL: sadece SELECT/WITH (defense-in-depth)
- Banned: INSERT, UPDATE, DELETE, DROP, ALTER, CREATE, TRUNCATE, EXEC

## Bilinen sınırlamalar

- Multi-turn yok — her soru bağımsız
- Chat history tutulmaz
- Sadece DuckDB (PostgreSQL/MySQL desteklenmiyor)
- Model SQL üretemezse retry mekanizması yok
- ews_skor VARCHAR — TRY_CAST gerekebilir
