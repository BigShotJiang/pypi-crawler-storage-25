// Obsidian [[wikilinks]] in doc comments are intentional — they link to
// design and reference docs in docs/. Rustdoc doesn't understand them.
#![allow(rustdoc::broken_intra_doc_links)]

//! `luci-core` — shared types, traits, and error handling for Luci.
//!
//! This crate is the foundation of the Luci workspace. Every other crate
//! depends on it. It contains no business logic — only type definitions,
//! trait interfaces, and error types.
//!
//! See [[architecture-overview]] for the crate dependency graph.

mod doc_id;
mod error;
mod field_id;
mod score;
mod scorer;
mod segment_id;

pub use doc_id::{DocId, NO_MORE_DOCS};
pub use error::{LuciError, Result};
pub use field_id::FieldId;
pub use score::ScoreMode;
pub use scorer::{Scorer, TwoPhaseIterator};
pub use segment_id::SegmentId;
