/// Controls whether and how scoring is performed during query execution.
///
/// Propagated from the query context down through `Weight` →
/// `ScorerSupplier` → `Scorer`. Implementations use this to skip expensive
/// scoring work when scores aren't needed. See [[architecture-query-execution#ScoreMode]].
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScoreMode {
    /// Full scoring required. Default for `must`/`should` clauses.
    Complete,

    /// No scores needed. Used in filter context (`filter`/`must_not`).
    /// Implementations skip TF lookup, BM25 computation, and norm loading.
    CompleteNoScores,

    /// Only top-K scores needed. Enables WAND/MaxScore optimizations:
    /// skip documents whose max possible contribution cannot enter the
    /// top-K heap. See [[architecture-query-execution#Disjunction Execution (Should Clauses)]].
    TopScores,
}

impl ScoreMode {
    /// Whether this mode requires score computation.
    pub fn needs_scores(self) -> bool {
        matches!(self, ScoreMode::Complete | ScoreMode::TopScores)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn complete_needs_scores() {
        assert!(ScoreMode::Complete.needs_scores());
    }

    #[test]
    fn complete_no_scores_does_not_need_scores() {
        assert!(!ScoreMode::CompleteNoScores.needs_scores());
    }

    #[test]
    fn top_scores_needs_scores() {
        assert!(ScoreMode::TopScores.needs_scores());
    }
}
