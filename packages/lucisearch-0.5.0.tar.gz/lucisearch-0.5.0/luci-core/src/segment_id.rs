/// Globally unique segment identifier.
///
/// Assigned by the `IndexWriter` on segment creation. `u64` provides
/// global uniqueness across the index's lifetime. See [[architecture-storage-format#Root Metadata]]
/// for how segment IDs map to block extents.
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct SegmentId(pub u64);

impl SegmentId {
    pub const fn new(id: u64) -> Self {
        Self(id)
    }

    pub const fn as_u64(self) -> u64 {
        self.0
    }
}

impl std::fmt::Display for SegmentId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ordering() {
        assert!(SegmentId(0) < SegmentId(1));
    }

    #[test]
    fn as_u64_round_trips() {
        assert_eq!(SegmentId::new(999).as_u64(), 999);
    }
}
