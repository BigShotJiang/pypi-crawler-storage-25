/// Index into the schema's field list.
///
/// Assigned sequentially when fields are added to the schema. `u16` limits
/// to 65,535 fields per index — well beyond practical use (Elasticsearch
/// recommends < 1,000). See [[architecture-api-surface#Schema and Mappings]].
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct FieldId(pub u16);

impl FieldId {
    pub const fn new(id: u16) -> Self {
        Self(id)
    }

    pub const fn as_u16(self) -> u16 {
        self.0
    }
}

impl std::fmt::Display for FieldId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ordering() {
        assert!(FieldId(0) < FieldId(1));
        assert!(FieldId(1) < FieldId(100));
    }

    #[test]
    fn as_u16_round_trips() {
        assert_eq!(FieldId::new(7).as_u16(), 7);
    }
}
