//! Python bindings for the Luci search engine via PyO3.

mod results;

#[cfg(feature = "mimalloc")]
#[global_allocator]
static GLOBAL: mimalloc::MiMalloc = mimalloc::MiMalloc;

use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;

use luci_analysis::config::AnalysisConfig;
use luci_core::LuciError;
use luci_index::index::Index as RustIndex;
use luci_mapping::Mapping;

/// Convert a LuciError to the appropriate Python exception.
/// Maps Rust error variants to the Python exception hierarchy
/// defined in luci/__init__.py.
fn to_py_err(e: LuciError) -> PyErr {
    match &e {
        LuciError::InvalidQuery(_) => PyValueError::new_err(format!("{e}")),
        LuciError::UnsupportedQuery(_) => PyValueError::new_err(format!("{e}")),
        LuciError::WriterLocked => PyRuntimeError::new_err(format!("{e}")),
        LuciError::TransactionActive => PyRuntimeError::new_err(format!("{e}")),
        LuciError::QueryBehaviorDifference { .. } => PyValueError::new_err(format!("{e}")),
        LuciError::IndexNotFound(_) => PyValueError::new_err(format!("{e}")),
        LuciError::IndexCorrupted(_) => PyValueError::new_err(format!("{e}")),
        LuciError::SchemaConflict { .. } => PyValueError::new_err(format!("{e}")),
        LuciError::Io(io_err) => PyRuntimeError::new_err(format!("I/O error: {io_err}")),
    }
}

/// A Luci search index.
///
/// Create or open an index, add documents, commit, and search.
///
/// Example::
///
///     index = Index.create("data.luci", {
///         "properties": {
///             "title": {"type": "text"},
///             "tag": {"type": "keyword"},
///         }
///     })
///     index.add({"title": "hello world", "tag": "greeting"})
///     results = index.search({"match": {"title": "hello"}})
///
///     # Or fully dynamic (no mapping needed):
///     index = Index.create("data.luci")
///
///     # Open existing (mappings loaded from disk):
///     index = Index.open("data.luci")
#[pyclass(frozen)]
struct Index {
    inner: RustIndex,
}

#[pymethods]
impl Index {
    /// Create a new index at the given path.
    ///
    /// Args:
    ///     path: File path for the index (e.g. ``"data.luci"``).
    ///     mapping: Optional ES-compatible mapping/settings dict. Accepted formats:
    ///
    ///         - ``{"properties": {"title": {"type": "text"}}}`` (mappings only)
    ///         - ``{"mappings": {"properties": ...}}`` (explicit mappings key)
    ///         - ``{"settings": {"analysis": ...}, "mappings": {"properties": ...}}``
    ///           (settings with custom analyzers + mappings)
    ///
    ///         If omitted, all field types are inferred dynamically.
    ///     memory_budget: Memory budget in bytes before auto-flush to a new
    ///         segment. Smaller values produce more segments (better query
    ///         parallelism, more merge work). Default: 64 MB (67108864).
    ///         Not persisted — applies only to this session's writes.
    #[staticmethod]
    #[pyo3(signature = (path, mapping=None, memory_budget=None, write_timeout=None))]
    fn create(
        path: &str,
        mapping: Option<PyObject>,
        memory_budget: Option<usize>,
        write_timeout: Option<f64>,
        py: Python<'_>,
    ) -> PyResult<Self> {
        let inner = match mapping {
            Some(m) => {
                let mapping_json = py_to_json(m, py)?;

                // Extract analysis settings if present
                let analysis_config = mapping_json
                    .get("settings")
                    .and_then(|s| s.get("analysis"))
                    .map(|a| AnalysisConfig::from_json(a))
                    .transpose()
                    .map_err(|e| {
                        PyValueError::new_err(format!("invalid analysis settings: {e}"))
                    })?;

                // Parse mappings (from "mappings" key or the whole dict)
                let mapping = Mapping::from_json(&mapping_json)
                    .map_err(|e| PyValueError::new_err(format!("invalid mapping: {e}")))?;

                RustIndex::create_with_settings(path, mapping, analysis_config)
            }
            None => RustIndex::create(path),
        }
        .map_err(to_py_err)?;
        if let Some(budget) = memory_budget {
            inner.set_memory_budget(budget);
        }
        if let Some(t) = write_timeout {
            inner.set_write_timeout(std::time::Duration::from_secs_f64(t));
        }
        Ok(Self { inner })
    }

    /// Open an existing index.
    ///
    /// Mappings are loaded from the index file automatically.
    ///
    /// Args:
    ///     path: File path for the index.
    ///     memory_budget: Memory budget in bytes before auto-flush to a new
    ///         segment. Default: 64 MB (67108864).
    ///         Not persisted — applies only to this session's writes.
    #[staticmethod]
    #[pyo3(signature = (path, memory_budget=None, write_timeout=None))]
    fn open(
        path: &str,
        memory_budget: Option<usize>,
        write_timeout: Option<f64>,
    ) -> PyResult<Self> {
        let inner = RustIndex::open(path).map_err(to_py_err)?;
        if let Some(budget) = memory_budget {
            inner.set_memory_budget(budget);
        }
        if let Some(t) = write_timeout {
            inner.set_write_timeout(std::time::Duration::from_secs_f64(t));
        }
        Ok(Self { inner })
    }

    /// Add a single document to the index. Auto-commits.
    ///
    /// The document is immediately searchable after this returns.
    /// For adding multiple documents, use :meth:`bulk` instead.
    ///
    /// Args:
    ///     doc: A dict representing the document.
    ///     write_timeout: Per-operation timeout in seconds. Overrides the
    ///         session default for this call only.
    #[pyo3(signature = (doc, write_timeout=None))]
    fn add(&self, doc: PyObject, write_timeout: Option<f64>, py: Python<'_>) -> PyResult<()> {
        if let Some(t) = write_timeout {
            self.inner
                .set_write_timeout(std::time::Duration::from_secs_f64(t));
        }
        let doc_json = py_to_json(doc, py)?;
        self.inner.add(doc_json).map_err(to_py_err)?;
        Ok(())
    }

    /// Add multiple documents in a single call.
    ///
    /// Faster than calling :meth:`add` in a loop — reduces FFI overhead
    /// from one call per document to one call per batch. Fails fast on the
    /// first invalid document.
    ///
    /// Args:
    ///     docs: A list of dicts, each representing a document.
    ///     write_timeout: Per-operation timeout in seconds. Overrides the
    ///         session default for this call only.
    ///
    /// Returns:
    ///     ``{"took": <ms>, "count": <n>}``
    ///
    /// Raises:
    ///     ValueError: If ``docs`` is not a list, or if any document is invalid.
    #[pyo3(signature = (docs, write_timeout=None))]
    fn bulk(
        &self,
        docs: PyObject,
        write_timeout: Option<f64>,
        py: Python<'_>,
    ) -> PyResult<PyObject> {
        if let Some(t) = write_timeout {
            self.inner
                .set_write_timeout(std::time::Duration::from_secs_f64(t));
        }
        let list = docs
            .downcast_bound::<pyo3::types::PyList>(py)
            .map_err(|_| PyValueError::new_err("bulk() requires a list of documents"))?;
        let mut json_docs = Vec::with_capacity(list.len());
        for (i, item) in list.iter().enumerate() {
            let doc_json: serde_json::Value = pythonize::depythonize(&item)
                .map_err(|e| PyValueError::new_err(format!("bulk item {i}: {e}")))?;
            json_docs.push(doc_json);
        }
        let result = self.inner.bulk(json_docs).map_err(to_py_err)?;
        json_to_py(&result, py)
    }

    /// Force-merge all segments down to at most ``max_segments``.
    ///
    /// Call after bulk indexing to optimize for query performance.
    ///
    /// Args:
    ///     max_segments: Target number of segments (default: 1).
    #[pyo3(signature = (max_segments=1))]
    fn force_merge(&self, max_segments: usize) -> PyResult<()> {
        self.inner.force_merge(max_segments).map_err(to_py_err)?;
        Ok(())
    }

    /// Search the index.
    ///
    /// Returns a lazy ``SearchResults`` object. Nothing is materialized until
    /// accessed — source decompression, JSON parsing, aggregation serialization,
    /// and highlight generation happen on first access via dict-style keys.
    ///
    /// See [[strategy-lazy-materialization]].
    ///
    /// Args:
    ///     query: ES-compatible query dict, e.g.
    ///         ``{"match": {"title": "hello"}}`` or
    ///         ``{"query": {"match": {"title": "hello"}}, "size": 10}``
    ///     size: Maximum number of results (default 10).
    ///
    /// Returns:
    ///     A ``SearchResults`` with dict-like access: ``["hits"]``,
    ///     ``["total_hits"]``, ``["aggregations"]``.
    #[pyo3(signature = (query, size=10))]
    fn search(&self, query: PyObject, size: usize, py: Python<'_>) -> PyResult<PyObject> {
        use luci_index::search::SourceFilter;

        let query_json = py_to_json(query, py)?;

        // Extract source_filter and fields config for deferred retrieval.
        let source_filter = if let Some(obj) = query_json.as_object() {
            luci_index::index::parse_source_filter(obj.get("_source"))
        } else {
            SourceFilter::Enabled
        };
        let requested_fields: Option<Vec<String>> = query_json
            .as_object()
            .and_then(|obj| obj.get("fields"))
            .and_then(|v| v.as_array())
            .map(|arr| {
                arr.iter()
                    .filter_map(|v| v.as_str().map(String::from))
                    .collect()
            });

        // Source and fields are not materialized in Rust.
        // SearchHit retrieves them on demand via Searcher's Tier 2 API.
        let expr =
            luci_index::search::expression::parse_search(query_json, size).map_err(to_py_err)?;
        let results = self.inner.search(&expr).map_err(to_py_err)?;

        let lazy = results::SearchResults::new(results, source_filter, requested_fields);
        Ok(Py::new(py, lazy)?.into_any().into())
    }

    /// Get a document by its `_id`. Returns None if not found.
    fn get(&self, id: &str, py: Python<'_>) -> PyResult<Option<PyObject>> {
        let source = self.inner.get(id).map_err(to_py_err)?;
        match source {
            Some(s) => {
                let mut obj = serde_json::Map::new();
                obj.insert("_id".into(), serde_json::json!(id));
                obj.insert("_source".into(), s);
                json_to_py(&serde_json::Value::Object(obj), py).map(Some)
            }
            None => Ok(None),
        }
    }

    /// Delete a document by its `_id`. Returns true if found and deleted.
    fn delete(&self, id: &str) -> PyResult<bool> {
        self.inner
            .delete(id)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Update a document by its `_id` with a partial doc merge.
    fn update(&self, id: &str, doc: PyObject, py: Python<'_>) -> PyResult<bool> {
        let partial = py_to_json(doc, py)?;
        self.inner
            .update(id, partial)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Delete all documents matching a query. Returns count deleted.
    fn delete_by_query(&self, query: PyObject, py: Python<'_>) -> PyResult<u64> {
        let query_json = py_to_json(query, py)?;
        self.inner
            .delete_by_query(query_json)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Count documents matching a query.
    fn count(&self, query: PyObject, py: Python<'_>) -> PyResult<u64> {
        let query_json = py_to_json(query, py)?;
        self.inner
            .count(query_json)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Number of buffered (uncommitted) documents.
    fn buffered_doc_count(&self) -> u32 {
        self.inner.buffered_doc_count()
    }

    /// Set the timeout for acquiring the cross-process write lock.
    ///
    /// When multiple processes write to the same ``.luci`` file, the
    /// second writer blocks until the first finishes. This sets how
    /// long to wait before raising ``RuntimeError``.
    ///
    /// Args:
    ///     timeout_secs: Timeout in seconds (default: 5.0).
    #[pyo3(signature = (timeout_secs=5.0))]
    fn set_write_timeout(&self, timeout_secs: f64) {
        self.inner
            .set_write_timeout(std::time::Duration::from_secs_f64(timeout_secs));
    }

    /// Create a transaction for batched writes with explicit commit control.
    ///
    /// Use as an async context manager::
    ///
    ///     async with index.transaction() as txn:
    ///         txn.add({"title": "doc 1"})
    ///         txn.add({"title": "doc 2"})
    ///         # commits on clean exit, discards on exception
    ///
    /// While a transaction is open, ``index.add()`` and ``index.bulk()``
    /// from other threads will block until the transaction completes.
    fn transaction(slf: Py<Self>) -> Transaction {
        Transaction {
            index: slf,
            buffer: Vec::new(),
            active: false,
        }
    }
}

/// Transaction operation buffered for commit.
enum TransactionOp {
    Add(serde_json::Value),
}

/// A transaction for batched writes with explicit commit control.
///
/// Created via :meth:`Index.transaction`. Use as a sync context manager.
/// Documents are buffered and flushed to the engine on commit.
/// On exception, the buffer is discarded (rollback).
///
/// For async usage, wrap the blocking calls with ``asyncio.to_thread``
/// (see the ``AsyncTransaction`` helper in ``luci/__init__.py``).
///
/// See [[architecture-concurrency-transactions]].
#[pyclass(unsendable)]
struct Transaction {
    index: Py<Index>,
    buffer: Vec<TransactionOp>,
    active: bool,
}

#[pymethods]
impl Transaction {
    /// Add a document to the transaction buffer.
    ///
    /// The document is not visible until the transaction commits.
    fn add(&mut self, doc: PyObject, py: Python<'_>) -> PyResult<()> {
        if !self.active {
            return Err(PyRuntimeError::new_err(
                "transaction is not active — use 'with index.transaction() as txn'",
            ));
        }
        let doc_json = py_to_json(doc, py)?;
        self.buffer.push(TransactionOp::Add(doc_json));
        Ok(())
    }

    /// Enter the transaction context. Acquires exclusive write access.
    fn __enter__(mut slf: PyRefMut<'_, Self>) -> PyResult<Py<Self>> {
        let py = slf.py();
        let index = slf.index.clone_ref(py);
        let idx = index.borrow(py);
        idx.inner.begin_transaction().map_err(to_py_err)?;
        slf.active = true;
        Ok(slf.into())
    }

    /// Exit the transaction context.
    ///
    /// On clean exit: flushes buffered ops and commits.
    /// On exception: discards buffer (rollback).
    #[pyo3(signature = (exc_type, _exc_val, _exc_tb))]
    fn __exit__(
        &mut self,
        py: Python<'_>,
        exc_type: Option<PyObject>,
        _exc_val: Option<PyObject>,
        _exc_tb: Option<PyObject>,
    ) -> PyResult<bool> {
        let index = self.index.clone_ref(py);
        let idx = index.borrow(py);
        let buffer = std::mem::take(&mut self.buffer);
        self.active = false;

        let result = if exc_type.is_some() {
            // Rollback: discard buffered docs
            idx.inner.txn_rollback();
            Ok(())
        } else {
            // Commit: flush buffer to writer, then commit
            for op in buffer {
                match op {
                    TransactionOp::Add(doc) => {
                        idx.inner.txn_add(doc).map_err(to_py_err)?;
                    }
                }
            }
            idx.inner.txn_commit().map_err(to_py_err)
        };

        // Always release the transaction lock
        idx.inner.end_transaction();
        result?;
        Ok(false) // Don't suppress the exception
    }
}

/// Convert a Python object to serde_json::Value via JSON serialization.
/// Convert a Python object to serde_json::Value via pythonize (no JSON string).
fn py_to_json(obj: PyObject, py: Python<'_>) -> PyResult<serde_json::Value> {
    pythonize::depythonize(obj.bind(py))
        .map_err(|e| PyValueError::new_err(format!("depythonize failed: {e}")))
}

/// Convert a serde_json::Value to a Python object via pythonize (no JSON string).
fn json_to_py(val: &serde_json::Value, py: Python<'_>) -> PyResult<PyObject> {
    pythonize::pythonize(py, val)
        .map(|v| v.unbind())
        .map_err(|e| PyValueError::new_err(format!("pythonize failed: {e}")))
}

/// Configure the number of threads used for parallel search.
///
/// Must be called before any search operation. Can only be called once
/// per process. If not called, defaults to the number of available CPUs.
#[pyfunction]
#[pyo3(signature = (num_threads))]
fn set_num_threads(num_threads: usize) -> PyResult<()> {
    luci_index::set_num_threads(num_threads).map_err(|e| PyValueError::new_err(format!("{e}")))
}

/// Python module initialization.
#[pymodule]
fn _luci(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<Index>()?;
    m.add_class::<Transaction>()?;
    m.add_class::<results::SearchResults>()?;
    m.add_class::<results::SearchHit>()?;
    m.add_function(wrap_pyfunction!(set_num_threads, m)?)?;
    Ok(())
}
