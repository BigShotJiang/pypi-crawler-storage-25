use pyo3::exceptions::{PyKeyError, PyValueError};
/// Python SDK search result types built on the Rust public API.
///
/// `SearchResults` wraps the Rust `search::results::SearchResults` which
/// owns `Arc<SegmentStore>`. `Hit` objects produced by iteration access
/// the Rust `Hit` API for lazy source/field retrieval.
///
/// See [[architecture-scoring-materialization-separation]].
use pyo3::prelude::*;

use luci_index::search::SourceFilter;
use luci_index::search::segment_store::SegmentStore;

/// Python search results. Wraps the Rust SearchResults directly.
///
/// Dict-like access: `results["hits"]`, `results["total_hits"]`,
/// `results["aggregations"]`.
#[pyclass(unsendable)]
pub struct SearchResults {
    /// The Rust SearchResults (owns Arc<SegmentStore> for lazy retrieval).
    inner: luci_index::search::results::SearchResults,

    /// Source/field config for lazy retrieval on hits.
    source_filter: SourceFilter,
    requested_fields: Option<Vec<String>>,

    /// Cached Python objects.
    cached_hits: Option<PyObject>,
    cached_aggs: Option<PyObject>,
    cached_total: Option<PyObject>,
}

unsafe impl Send for SearchResults {}

impl SearchResults {
    pub fn new(
        inner: luci_index::search::results::SearchResults,
        source_filter: SourceFilter,
        requested_fields: Option<Vec<String>>,
    ) -> Self {
        Self {
            inner,
            source_filter,
            requested_fields,
            cached_hits: None,
            cached_aggs: None,
            cached_total: None,
        }
    }
}

#[pymethods]
impl SearchResults {
    fn __getitem__(&mut self, key: &str, py: Python<'_>) -> PyResult<PyObject> {
        match key {
            "hits" => self.get_hits(py),
            "total_hits" => self.get_total_hits(py),
            "aggregations" => self.get_aggs(py),
            _ => Err(PyKeyError::new_err(key.to_string())),
        }
    }

    fn __contains__(&self, key: &str) -> bool {
        match key {
            "hits" | "total_hits" => true,
            "aggregations" => !self.inner.aggregations().is_empty(),
            _ => false,
        }
    }

    fn keys(&self) -> Vec<&str> {
        let mut k = vec!["hits", "total_hits"];
        if !self.inner.aggregations().is_empty() {
            k.push("aggregations");
        }
        k
    }

    fn get(&mut self, key: &str, default: Option<PyObject>, py: Python<'_>) -> PyResult<PyObject> {
        match self.__getitem__(key, py) {
            Ok(v) => Ok(v),
            Err(_) => Ok(default.unwrap_or_else(|| py.None())),
        }
    }

    fn __len__(&self) -> usize {
        if self.inner.aggregations().is_empty() {
            2
        } else {
            3
        }
    }

    fn __repr__(&self) -> String {
        format!(
            "SearchResults(total_hits={}, hits={}, aggregations={})",
            self.inner.total_hits().value,
            self.inner.len(),
            self.inner.aggregations().len(),
        )
    }
}

impl SearchResults {
    fn get_hits(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        if let Some(cached) = &self.cached_hits {
            return Ok(cached.clone_ref(py));
        }

        let hits_list = pyo3::types::PyList::empty(py);

        for i in 0..self.inner.len() {
            let hit = self.inner.hit(i).unwrap();
            let py_hit = SearchHit::from_hit(
                &hit,
                self.inner.store(),
                &self.source_filter,
                &self.requested_fields,
            );
            let py_obj = Py::new(py, py_hit)?;
            hits_list.append(py_obj)?;
        }

        let obj = hits_list.into_any().unbind();
        self.cached_hits = Some(obj.clone_ref(py));
        Ok(obj)
    }

    fn get_total_hits(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        if let Some(cached) = &self.cached_total {
            return Ok(cached.clone_ref(py));
        }
        let json = self.inner.total_hits().to_json();
        let obj = pythonize::pythonize(py, &json)
            .map(|v| v.unbind())
            .map_err(|e| PyValueError::new_err(format!("{e}")))?;
        self.cached_total = Some(obj.clone_ref(py));
        Ok(obj)
    }

    fn get_aggs(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        if let Some(cached) = &self.cached_aggs {
            return Ok(cached.clone_ref(py));
        }
        if self.inner.aggregations().is_empty() {
            return Err(PyKeyError::new_err("aggregations"));
        }

        let mut aggs_json = serde_json::Map::new();
        for (name, agg_result) in self.inner.aggregations() {
            aggs_json.insert(name.clone(), agg_result.to_json());
        }
        let aggs_py = pythonize::pythonize(py, &serde_json::Value::Object(aggs_json))
            .map(|v| v.unbind())
            .map_err(|e| PyValueError::new_err(format!("pythonize aggs: {e}")))?;
        self.cached_aggs = Some(aggs_py.clone_ref(py));
        Ok(aggs_py)
    }
}

/// A single search hit with lazy field access.
///
/// `_score` and `_doc_id` are immediate. `_source` and `fields` are
/// retrieved on demand via the SegmentStore's Reader.
#[pyclass(unsendable)]
pub struct SearchHit {
    score: f32,
    doc_id: luci_core::DocId,
    segment_id: luci_core::SegmentId,

    /// Raw pointer to SegmentStore for lazy retrieval.
    store: *const SegmentStore,

    /// Retrieval config.
    source_filter: SourceFilter,
    requested_fields: Option<Vec<String>>,

    /// Eager data from the scoring phase.
    sort_values: Option<Vec<luci_index::search::SortValue>>,
    explanation_value: Option<luci_index::search::Explanation>,
    inner_hits_value: Option<std::collections::HashMap<String, serde_json::Value>>,
    highlight_value: Option<serde_json::Map<String, serde_json::Value>>,

    /// Cached Python objects.
    cached_source: Option<PyObject>,
    cached_fields: Option<PyObject>,
    cached_sort: Option<PyObject>,
    cached_explanation: Option<PyObject>,
    cached_inner_hits: Option<PyObject>,
    cached_highlight: Option<PyObject>,
}

unsafe impl Send for SearchHit {}

impl SearchHit {
    pub fn from_hit(
        hit: &luci_index::search::results::Hit<'_>,
        store: &std::sync::Arc<SegmentStore>,
        source_filter: &SourceFilter,
        requested_fields: &Option<Vec<String>>,
    ) -> Self {
        Self {
            score: hit.score(),
            doc_id: hit.doc_id(),
            segment_id: hit.segment_id(),
            store: std::sync::Arc::as_ptr(store),
            source_filter: source_filter.clone(),
            requested_fields: requested_fields.clone(),
            sort_values: hit.sort_values().map(|sv| sv.to_vec()),
            explanation_value: hit.explain(),
            inner_hits_value: hit.inner_hits(),
            highlight_value: None, // highlight is now lazy per-field via Hit.highlight(field)
            cached_source: None,
            cached_fields: None,
            cached_sort: None,
            cached_explanation: None,
            cached_inner_hits: None,
            cached_highlight: None,
        }
    }
}

#[pymethods]
impl SearchHit {
    fn __getitem__(&mut self, key: &str, py: Python<'_>) -> PyResult<PyObject> {
        match key {
            "_score" => Ok(self.score.into_pyobject(py)?.into_any().unbind()),
            "_doc_id" => Ok(self.doc_id.as_u32().into_pyobject(py)?.into_any().unbind()),
            "_source" => self.get_source(py),
            "fields" => self.get_fields(py),
            "sort" => self.get_sort(py),
            "_explanation" => self.get_explanation(py),
            "inner_hits" => self.get_inner_hits(py),
            "highlight" => self.get_highlight(py),
            _ => Err(PyKeyError::new_err(key.to_string())),
        }
    }

    fn __contains__(&self, key: &str) -> bool {
        match key {
            "_score" | "_doc_id" => true,
            "_source" => !matches!(self.source_filter, SourceFilter::Disabled),
            "fields" => self
                .requested_fields
                .as_ref()
                .is_some_and(|f| !f.is_empty()),
            "sort" => self.sort_values.is_some(),
            "_explanation" => self.explanation_value.is_some(),
            "inner_hits" => self.inner_hits_value.is_some(),
            "highlight" => self.highlight_value.as_ref().is_some_and(|h| !h.is_empty()),
            _ => false,
        }
    }

    fn keys(&self) -> Vec<&str> {
        let mut k = vec!["_score", "_doc_id"];
        if !matches!(self.source_filter, SourceFilter::Disabled) {
            k.push("_source");
        }
        if self
            .requested_fields
            .as_ref()
            .is_some_and(|f| !f.is_empty())
        {
            k.push("fields");
        }
        if self.sort_values.is_some() {
            k.push("sort");
        }
        if self.explanation_value.is_some() {
            k.push("_explanation");
        }
        if self.inner_hits_value.is_some() {
            k.push("inner_hits");
        }
        if self.highlight_value.as_ref().is_some_and(|h| !h.is_empty()) {
            k.push("highlight");
        }
        k
    }

    fn get(&mut self, key: &str, default: Option<PyObject>, py: Python<'_>) -> PyResult<PyObject> {
        match self.__getitem__(key, py) {
            Ok(v) => Ok(v),
            Err(_) => Ok(default.unwrap_or_else(|| py.None())),
        }
    }

    fn __len__(&self) -> usize {
        self.keys().len()
    }

    fn __repr__(&self) -> String {
        format!(
            "SearchHit(_score={}, _doc_id={})",
            self.score,
            self.doc_id.as_u32()
        )
    }
}

impl SearchHit {
    fn pythonize_cached<T: serde::Serialize>(
        cached: &mut Option<PyObject>,
        value: &Option<T>,
        py: Python<'_>,
    ) -> PyResult<PyObject> {
        if let Some(c) = cached {
            return Ok(c.clone_ref(py));
        }
        match value {
            Some(v) => {
                let obj = pythonize::pythonize(py, v)
                    .map(|v| v.unbind())
                    .map_err(|e| PyValueError::new_err(format!("{e}")))?;
                *cached = Some(obj.clone_ref(py));
                Ok(obj)
            }
            None => Ok(py.None()),
        }
    }

    fn get_source(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        if let Some(cached) = &self.cached_source {
            return Ok(cached.clone_ref(py));
        }
        let store = unsafe { &*self.store };
        let reader = luci_index::search::reader::Reader::new(store);
        let source = match &self.source_filter {
            SourceFilter::Disabled => None,
            SourceFilter::Enabled => reader.get_source(self.segment_id, self.doc_id),
            filter => reader
                .get_source(self.segment_id, self.doc_id)
                .and_then(|v| luci_index::search::filter_source(&v, filter)),
        };
        let obj = match source {
            Some(v) => pythonize::pythonize(py, &v)
                .map(|v| v.unbind())
                .map_err(|e| PyValueError::new_err(format!("{e}")))?,
            None => py.None(),
        };
        self.cached_source = Some(obj.clone_ref(py));
        Ok(obj)
    }

    fn get_fields(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        if let Some(cached) = &self.cached_fields {
            return Ok(cached.clone_ref(py));
        }
        let obj = match &self.requested_fields {
            Some(names) if !names.is_empty() => {
                let store = unsafe { &*self.store };
                let reader = luci_index::search::reader::Reader::new(store);
                let fields = reader.retrieve_fields(self.segment_id, self.doc_id, names);
                if fields.is_empty() {
                    py.None()
                } else {
                    pythonize::pythonize(py, &fields)
                        .map(|v| v.unbind())
                        .map_err(|e| PyValueError::new_err(format!("{e}")))?
                }
            }
            _ => py.None(),
        };
        self.cached_fields = Some(obj.clone_ref(py));
        Ok(obj)
    }

    fn get_sort(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        if let Some(c) = &self.cached_sort {
            return Ok(c.clone_ref(py));
        }
        match &self.sort_values {
            Some(vals) => {
                let arr: Vec<serde_json::Value> = vals.iter().map(|sv| sv.to_json()).collect();
                let obj = pythonize::pythonize(py, &arr)
                    .map(|v| v.unbind())
                    .map_err(|e| PyValueError::new_err(format!("{e}")))?;
                self.cached_sort = Some(obj.clone_ref(py));
                Ok(obj)
            }
            None => Ok(py.None()),
        }
    }

    fn get_explanation(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        if let Some(c) = &self.cached_explanation {
            return Ok(c.clone_ref(py));
        }
        match &self.explanation_value {
            Some(exp) => {
                let json = exp.to_json();
                let obj = pythonize::pythonize(py, &json)
                    .map(|v| v.unbind())
                    .map_err(|e| PyValueError::new_err(format!("{e}")))?;
                self.cached_explanation = Some(obj.clone_ref(py));
                Ok(obj)
            }
            None => Ok(py.None()),
        }
    }

    fn get_inner_hits(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        Self::pythonize_cached(&mut self.cached_inner_hits, &self.inner_hits_value, py)
    }

    fn get_highlight(&mut self, py: Python<'_>) -> PyResult<PyObject> {
        Self::pythonize_cached(&mut self.cached_highlight, &self.highlight_value, py)
    }
}
