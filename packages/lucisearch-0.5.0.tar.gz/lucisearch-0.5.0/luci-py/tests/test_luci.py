"""Tests for the luci Python bindings."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from pathlib import Path

import pytest

import luci


@pytest.fixture
def index(tmp_path: Path) -> luci.Index:
    """Create a temporary index with the standard test mapping."""
    return luci.Index.create(
        str(tmp_path / "idx"),
        {
            "properties": {
                "title": {"type": "text"},
                "body": {"type": "text"},
                "tag": {"type": "keyword"},
                "price": {"type": "float"},
            },
        },
    )


def test_create_and_search(index: luci.Index) -> None:
    """Search returns matching documents with correct source."""
    index.add({"title": "hello world", "tag": "greeting"})

    results = index.search({"match": {"title": "hello"}})
    assert results["total_hits"]["value"] == 1
    assert results["hits"][0]["_source"]["title"] == "hello world"


def test_term_query(index: luci.Index) -> None:
    """Term query matches exact keyword values."""
    index.bulk(
        [
            {"title": "A", "tag": "tech"},
            {"title": "B", "tag": "pets"},
            {"title": "C", "tag": "tech"},
        ],
    )

    results = index.search({"term": {"tag": "tech"}})
    assert results["total_hits"]["value"] == 2


def test_bool_query(index: luci.Index) -> None:
    """Bool query combines must and filter clauses."""
    index.bulk(
        [
            {"title": "search engine", "tag": "tech"},
            {"title": "search tips", "tag": "blog"},
            {"title": "database design", "tag": "tech"},
        ],
    )

    results = index.search(
        {
            "bool": {
                "must": [{"match": {"title": "search"}}],
                "filter": [{"term": {"tag": "tech"}}],
            },
        },
    )
    assert results["total_hits"]["value"] == 1


def test_aggregations(index: luci.Index) -> None:
    """Aggregations compute correct bucket counts and metric values."""
    index.bulk(
        [
            {"title": "A", "tag": "tech", "price": 10.0},
            {"title": "B", "tag": "tech", "price": 20.0},
            {"title": "C", "tag": "pets", "price": 5.0},
        ],
    )

    results = index.search(
        {
            "query": {"match_all": {}},
            "aggs": {
                "by_tag": {"terms": {"field": "tag"}},
                "avg_price": {"avg": {"field": "price"}},
            },
            "size": 0,
        },
    )

    assert "aggregations" in results
    aggs = cast("dict[str, Any]", results["aggregations"])

    avg_val = cast("float", aggs["avg_price"]["value"])
    assert abs(avg_val - 11.67) < 1.0

    buckets = cast("list[dict[str, Any]]", aggs["by_tag"]["buckets"])
    tag_counts = {b["key"]: b["doc_count"] for b in buckets}
    assert tag_counts["tech"] == 2
    assert tag_counts["pets"] == 1


def test_phrase_query(index: luci.Index) -> None:
    """Phrase query matches exact word order."""
    index.bulk(
        [
            {"body": "the quick brown fox"},
            {"body": "brown quick fox"},
        ],
    )

    results = index.search({"match_phrase": {"body": "quick brown"}})
    assert results["total_hits"]["value"] == 1


def test_open_existing(tmp_path: Path) -> None:
    """Opening an existing index loads persisted mappings."""
    idx_path = str(tmp_path / "idx")
    index = luci.Index.create(
        idx_path,
        {"properties": {"title": {"type": "text"}}},
    )
    index.add({"title": "persistent doc"})

    idx2 = luci.Index.open(idx_path)
    results = idx2.search({"match": {"title": "persistent"}})
    assert results["total_hits"]["value"] == 1


def test_vector_search(tmp_path: Path) -> None:
    """Hybrid text + vector search returns correct results via RRF."""
    mapping = {
        "properties": {
            "title": {"type": "text"},
            "embedding": {"type": "dense_vector", "dims": 4},
        },
    }
    index = luci.Index.create(str(tmp_path / "idx"), mapping)

    index.bulk(
        [
            {"title": "search", "embedding": [1.0, 0.0, 0.0, 0.0]},
            {"title": "database", "embedding": [0.0, 1.0, 0.0, 0.0]},
            {"title": "cat", "embedding": [0.0, 0.0, 1.0, 0.0]},
        ],
    )

    results = index.search(
        {
            "query": {"match": {"title": "search"}},
            "knn": {
                "field": "embedding",
                "query_vector": [0.9, 0.1, 0.0, 0.0],
                "k": 3,
                "num_candidates": 5,
            },
            "size": 3,
        },
    )
    assert results["total_hits"]["value"] >= 1
    assert results["hits"][0]["_doc_id"] == 0
