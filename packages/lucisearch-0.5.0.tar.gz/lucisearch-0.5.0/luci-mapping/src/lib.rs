// Obsidian [[wikilinks]] in doc comments are intentional — they link to
// design and reference docs in docs/. Rustdoc doesn't understand them.
#![allow(rustdoc::broken_intra_doc_links)]

//! `luci-mapping` — field types, mappings, and dynamic field detection.
//!
//! This crate defines how fields are indexed: which fields exist, what types
//! they have, and how unknown fields are handled. Mappings are instructions
//! to the indexing pipeline, not structural constraints on documents.
//!
//! See [[architecture-api-surface#Schema and Mappings]] for the full design.

mod dynamic;
mod field_type;
mod mapping;
mod mapping_def;

pub use dynamic::detect_field_type;
pub use field_type::FieldType;
pub use mapping::FieldMapping;
pub use mapping_def::{DynamicMode, Mapping, MappingBuilder};
