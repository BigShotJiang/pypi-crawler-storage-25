//! Integration tests for search highlighting.
//!
//! See [[feature-search-highlight]].

use luci_index::index::Index;
use luci_index::search::SourceFilter;
use luci_index::search::expression::parse_search;
use luci_index::search::highlight::{HighlightConfig, HighlightFieldConfig, HighlightOrder};
use luci_mapping::{FieldType, Mapping};
use serde_json::json;

fn test_dir(name: &str) -> std::path::PathBuf {
    let dir = std::env::temp_dir().join(format!("luci_highlight_{}_{name}", std::process::id()));
    let _ = std::fs::remove_dir_all(&dir);
    dir
}

fn cleanup(path: &std::path::Path) {
    let _ = std::fs::remove_dir_all(path);
}

fn setup_index(name: &str) -> (Index, std::path::PathBuf) {
    let path = test_dir(name);
    let schema = Mapping::builder()
        .field("title", FieldType::Text)
        .field("body", FieldType::Text)
        .build();
    let index = Index::create_with_mapping(&path, schema).unwrap();
    index
        .bulk(vec![
            json!({
                "title": "Search Engine Architecture",
                "body": "A search engine indexes documents for fast retrieval."
            }),
            json!({
                "title": "Database Design",
                "body": "Databases store data in tables. Search is done via SQL queries."
            }),
            json!({
                "title": "Information Retrieval",
                "body": "Modern search engines use inverted indexes and BM25 scoring."
            }),
        ])
        .unwrap();
    (index, path)
}

#[test]
fn highlight_basic() {
    let (index, path) = setup_index("basic");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    assert!(results.len() >= 1);
    for hit in results.iter() {
        let hl = hit.highlight("body").expect("highlight should be present");
        let body_frags = hl.get("body").expect("body should be highlighted");
        let frags = body_frags.as_array().unwrap();
        assert!(!frags.is_empty());
        let frag_text = frags[0].as_str().unwrap();
        assert!(
            frag_text.contains("<em>"),
            "fragment should contain <em> tag: {frag_text}"
        );
        assert!(
            frag_text.contains("</em>"),
            "fragment should contain </em> tag: {frag_text}"
        );
    }
    cleanup(&path);
}

#[test]
fn highlight_multiple_terms() {
    let (index, path) = setup_index("multi_terms");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search engine"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let hit = results.hit(0).unwrap();
    let hl = hit.highlight("body").unwrap();
    let frag_text = hl["body"].as_array().unwrap()[0].as_str().unwrap();
    assert!(
        frag_text.contains("<em>"),
        "should highlight search: {frag_text}"
    );
    // Both terms should be highlighted
    let em_count = frag_text.matches("<em>").count();
    assert!(
        em_count >= 2,
        "should highlight both terms, got {em_count} highlights: {frag_text}"
    );
    cleanup(&path);
}

#[test]
fn highlight_custom_tags() {
    let (index, path) = setup_index("custom_tags");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 5,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<strong>".to_string()],
        post_tags: vec!["</strong>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    let hit = results.hit(0).unwrap();
    let hl = hit.highlight_with_config(&config).unwrap();
    let frag_text = hl["body"].as_array().unwrap()[0].as_str().unwrap();
    assert!(
        frag_text.contains("<strong>"),
        "should use custom pre_tag: {frag_text}"
    );
    assert!(
        frag_text.contains("</strong>"),
        "should use custom post_tag: {frag_text}"
    );
    assert!(
        !frag_text.contains("<em>"),
        "should not use default tag: {frag_text}"
    );
    cleanup(&path);
}

#[test]
fn highlight_per_field_tags() {
    let (index, path) = setup_index("per_field_tags");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 5,
            no_match_size: 0,
            pre_tags: Some(vec!["<mark>".to_string()]),
            post_tags: Some(vec!["</mark>".to_string()]),
        }],
        pre_tags: vec!["<b>".to_string()],
        post_tags: vec!["</b>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    let hit = results.hit(0).unwrap();
    let hl = hit.highlight_with_config(&config).unwrap();
    let frag_text = hl["body"].as_array().unwrap()[0].as_str().unwrap();
    assert!(
        frag_text.contains("<mark>"),
        "should use per-field tag: {frag_text}"
    );
    assert!(
        !frag_text.contains("<b>"),
        "should not use global tag: {frag_text}"
    );
    cleanup(&path);
}

#[test]
fn highlight_full_field() {
    let (index, path) = setup_index("full_field");
    let expr = parse_search(
        json!({
            "query": {"match": {"title": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "title".to_string(),
            fragment_size: 150,
            number_of_fragments: 0,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    let hit = results.hit(0).unwrap();
    let hl = hit.highlight_with_config(&config).unwrap();
    let frags = hl["title"].as_array().unwrap();
    assert_eq!(frags.len(), 1, "full field mode returns single fragment");
    let frag_text = frags[0].as_str().unwrap();
    // Should contain the full title with highlights
    assert!(
        frag_text.contains("<em>Search</em>"),
        "should preserve original case: {frag_text}"
    );
    assert!(
        frag_text.contains("Engine Architecture"),
        "should return full field: {frag_text}"
    );
    cleanup(&path);
}

#[test]
fn highlight_number_of_fragments() {
    let path = test_dir("num_frags");
    let schema = Mapping::builder().field("body", FieldType::Text).build();
    let index = Index::create_with_mapping(&path, schema).unwrap();
    // Long body with many match opportunities
    index.add(json!({
        "body": "The search engine processes queries efficiently. A good search algorithm uses inverted indexes. The search results are ranked by relevance. Every search system needs good recall. This is about search technology."
    })).unwrap();

    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 2,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    let hit = results.hit(0).unwrap();
    let hl = hit.highlight_with_config(&config).unwrap();
    let frags = hl["body"].as_array().unwrap();
    assert!(
        frags.len() <= 2,
        "should return at most 2 fragments, got {}",
        frags.len()
    );
    cleanup(&path);
}

#[test]
fn highlight_no_match_size() {
    let (index, path) = setup_index("no_match_size");
    // Query matches on title, but we ask for body highlight with no_match_size
    let expr = parse_search(
        json!({
            "query": {"match": {"title": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 5,
            no_match_size: 50,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: false,
        order: HighlightOrder::None,
    };

    // The hit for "Search Engine Architecture" has body text; title matches "search"
    // With require_field_match: false, body should also get highlighted since "search" appears in body
    let hit = results.hit(0).unwrap();
    let hl = hit.highlight_with_config(&config).unwrap();
    assert!(hl.contains_key("body"), "body should be in highlight");
    cleanup(&path);
}

#[test]
fn highlight_require_field_match_true() {
    let (index, path) = setup_index("rfm_true");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "title".to_string(),
            fragment_size: 150,
            number_of_fragments: 5,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    // Query targets body, highlight requests title — should not highlight
    for hit in results.iter() {
        let hl = hit.highlight_with_config(&config);
        if let Some(hl) = hl {
            assert!(
                !hl.contains_key("title"),
                "title should not be highlighted when require_field_match=true and query targets body"
            );
        }
    }
    cleanup(&path);
}

#[test]
fn highlight_require_field_match_false() {
    let (index, path) = setup_index("rfm_false");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "title".to_string(),
            fragment_size: 150,
            number_of_fragments: 5,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: false,
        order: HighlightOrder::None,
    };

    // "Search Engine Architecture" has "search" in the title
    let hit = results
        .iter()
        .find(|h| {
            h.source()
                .and_then(|s| {
                    s.get("title")
                        .and_then(|t| t.as_str())
                        .map(|t| t.contains("Search"))
                })
                .unwrap_or(false)
        })
        .expect("should find the Search Engine doc");

    let hl = hit
        .highlight_with_config(&config)
        .expect("highlight should be present");
    assert!(
        hl.contains_key("title"),
        "title should be highlighted with require_field_match=false"
    );
    let frag = hl["title"].as_array().unwrap()[0].as_str().unwrap();
    assert!(
        frag.contains("<em>"),
        "title should contain highlight tag: {frag}"
    );
    cleanup(&path);
}

#[test]
fn highlight_bool_query() {
    let (index, path) = setup_index("bool_query");
    let expr = parse_search(
        json!({
            "query": {
                "bool": {
                    "must": [
                        {"match": {"body": "search"}},
                        {"match": {"title": "architecture"}}
                    ]
                }
            }
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![
            HighlightFieldConfig {
                field: "body".to_string(),
                fragment_size: 150,
                number_of_fragments: 5,
                no_match_size: 0,
                pre_tags: None,
                post_tags: None,
            },
            HighlightFieldConfig {
                field: "title".to_string(),
                fragment_size: 150,
                number_of_fragments: 5,
                no_match_size: 0,
                pre_tags: None,
                post_tags: None,
            },
        ],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    assert!(!results.is_empty());
    let hit = results.hit(0).unwrap();
    let hl = hit.highlight_with_config(&config).unwrap();
    // body should highlight "search"
    let body_frag = hl["body"].as_array().unwrap()[0].as_str().unwrap();
    assert!(
        body_frag.to_lowercase().contains("<em>"),
        "body should highlight: {body_frag}"
    );
    // title should highlight "architecture"
    let title_frag = hl["title"].as_array().unwrap()[0].as_str().unwrap();
    assert!(
        title_frag.to_lowercase().contains("<em>"),
        "title should highlight: {title_frag}"
    );
    cleanup(&path);
}

#[test]
fn highlight_phrase_query() {
    let (index, path) = setup_index("phrase");
    let expr = parse_search(
        json!({
            "query": {"match_phrase": {"body": "search engine"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    assert!(!results.is_empty());
    let hit = results.hit(0).unwrap();
    let hl = hit.highlight("body").unwrap();
    let frag = hl["body"].as_array().unwrap()[0].as_str().unwrap();
    // Both terms should be individually highlighted
    assert!(
        frag.contains("<em>"),
        "should highlight phrase terms: {frag}"
    );
    cleanup(&path);
}

#[test]
fn highlight_term_query() {
    let path = test_dir("term_query");
    let schema = Mapping::builder()
        .field("status", FieldType::Keyword)
        .field("body", FieldType::Text)
        .build();
    let index = Index::create_with_mapping(&path, schema).unwrap();
    index
        .add(json!({"status": "active", "body": "This is active content."}))
        .unwrap();

    let expr = parse_search(
        json!({
            "query": {"term": {"body": "active"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    assert!(!results.is_empty());
    let hit = results.hit(0).unwrap();
    let hl = hit.highlight("body").unwrap();
    let frag = hl["body"].as_array().unwrap()[0].as_str().unwrap();
    assert!(
        frag.contains("<em>active</em>"),
        "should highlight exact term: {frag}"
    );
    cleanup(&path);
}

#[test]
fn highlight_not_requested() {
    let (index, path) = setup_index("not_requested");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    // In the lazy API, highlight is always available on demand.
    // Verify that requesting highlight on a field with no query terms
    // (require_field_match=true, querying body but requesting title highlight)
    // returns None or a map without the field.
    for hit in results.iter() {
        let hl = hit.highlight("title");
        if let Some(map) = hl {
            assert!(
                !map.contains_key("title"),
                "title should not be highlighted when query targets body with require_field_match=true"
            );
        }
    }
    cleanup(&path);
}

#[test]
fn highlight_source_disabled() {
    let (index, path) = setup_index("source_disabled");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    // When _source is disabled via source_filtered, highlight still works
    // because highlight loads source independently from the doc store.
    for hit in results.iter() {
        assert!(
            hit.source_filtered(&SourceFilter::Disabled).is_none(),
            "_source should be absent"
        );
        // Highlight should still work
        assert!(
            hit.highlight("body").is_some(),
            "highlight should still work with _source disabled"
        );
    }
    cleanup(&path);
}

#[test]
fn highlight_preserves_case() {
    let (index, path) = setup_index("preserves_case");
    let expr = parse_search(
        json!({
            "query": {"match": {"title": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "title".to_string(),
            fragment_size: 150,
            number_of_fragments: 0,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    let hit = results
        .iter()
        .find(|h| {
            h.source()
                .and_then(|s| {
                    s.get("title")
                        .and_then(|t| t.as_str())
                        .map(|t| t.starts_with("Search"))
                })
                .unwrap_or(false)
        })
        .expect("should find the Search Engine doc");

    let hl = hit.highlight_with_config(&config).unwrap();
    let frag = hl["title"].as_array().unwrap()[0].as_str().unwrap();
    // Original case "Search" should be preserved, not lowercased "search"
    assert!(
        frag.contains("<em>Search</em>"),
        "original case should be preserved: {frag}"
    );
    cleanup(&path);
}

#[test]
fn highlight_adjacent_terms() {
    let (index, path) = setup_index("adjacent");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search engine"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 0,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    let hit = results
        .iter()
        .find(|h| {
            h.source()
                .and_then(|s| {
                    s.get("body")
                        .and_then(|t| t.as_str())
                        .map(|t| t.contains("search engine"))
                })
                .unwrap_or(false)
        })
        .expect("should find doc with 'search engine'");

    let hl = hit.highlight_with_config(&config).unwrap();
    let frag = hl["body"].as_array().unwrap()[0].as_str().unwrap();
    // Tags should not merge: "<em>search</em> <em>engine</em>"
    assert!(
        frag.contains("<em>search</em> <em>engine</em>"),
        "adjacent terms should be individually tagged: {frag}"
    );
    cleanup(&path);
}

#[test]
fn highlight_source_filtered() {
    let (index, path) = setup_index("source_filtered");
    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let source_filter = SourceFilter::Fields(vec!["title".to_string()]);

    for hit in results.iter() {
        // Source should only have title
        if let Some(src) = hit.source_filtered(&source_filter) {
            assert!(
                !src.as_object().unwrap().contains_key("body"),
                "body should be filtered from _source"
            );
        }
        // But highlight should still work on body (uses unfiltered source)
        if let Some(hl) = hit.highlight("body") {
            if hl.contains_key("body") {
                let frag = hl["body"].as_array().unwrap()[0].as_str().unwrap();
                assert!(
                    frag.contains("<em>"),
                    "body should be highlighted from unfiltered source"
                );
            }
        }
    }
    cleanup(&path);
}

#[test]
fn highlight_multi_match() {
    let (index, path) = setup_index("multi_match");
    let expr = parse_search(
        json!({
            "query": {"multi_match": {"query": "search", "fields": ["title", "body"]}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![
            HighlightFieldConfig {
                field: "title".to_string(),
                fragment_size: 150,
                number_of_fragments: 5,
                no_match_size: 0,
                pre_tags: None,
                post_tags: None,
            },
            HighlightFieldConfig {
                field: "body".to_string(),
                fragment_size: 150,
                number_of_fragments: 5,
                no_match_size: 0,
                pre_tags: None,
                post_tags: None,
            },
        ],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::None,
    };

    // At least one hit should have highlights in both fields
    let hit = results
        .iter()
        .find(|h| {
            h.source()
                .and_then(|s| {
                    s.get("title")
                        .and_then(|t| t.as_str())
                        .map(|t| t.contains("Search"))
                })
                .unwrap_or(false)
        })
        .expect("should find doc");

    let hl = hit.highlight_with_config(&config).unwrap();
    assert!(hl.contains_key("title"), "title should be highlighted");
    assert!(hl.contains_key("body"), "body should be highlighted");
    cleanup(&path);
}

#[test]
fn highlight_order_score() {
    let path = test_dir("order_score");
    let schema = Mapping::builder().field("body", FieldType::Text).build();
    let index = Index::create_with_mapping(&path, schema).unwrap();
    index.add(json!({
        "body": "The search engine processes queries efficiently. Databases store records. A good search algorithm uses inverted indexes for search. The results are ranked."
    })).unwrap();

    let expr = parse_search(
        json!({
            "query": {"match": {"body": "search"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    // Order by score: fragment with more matches should come first
    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 3,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: true,
        order: HighlightOrder::Score,
    };

    let hit = results.hit(0).unwrap();
    let hl = hit.highlight_with_config(&config).unwrap();
    let frags = hl["body"].as_array().unwrap();
    if frags.len() >= 2 {
        // First fragment should have >= as many highlights as subsequent ones
        let count0 = frags[0].as_str().unwrap().matches("<em>").count();
        let count1 = frags[1].as_str().unwrap().matches("<em>").count();
        assert!(
            count0 >= count1,
            "first fragment should have more/equal matches ({count0}) than second ({count1})"
        );
    }
    cleanup(&path);
}

#[test]
fn highlight_empty_field() {
    let path = test_dir("empty_field");
    let schema = Mapping::builder()
        .field("title", FieldType::Text)
        .field("body", FieldType::Text)
        .build();
    let index = Index::create_with_mapping(&path, schema).unwrap();
    index
        .add(json!({
            "title": "Test",
            "body": ""
        }))
        .unwrap();

    let expr = parse_search(
        json!({
            "query": {"match": {"title": "test"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 5,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: false,
        order: HighlightOrder::None,
    };

    // Empty body field should not appear in highlight
    for hit in results.iter() {
        if let Some(hl) = hit.highlight_with_config(&config) {
            assert!(
                !hl.contains_key("body"),
                "empty field should not be in highlight"
            );
        }
    }
    cleanup(&path);
}

#[test]
fn highlight_missing_field() {
    let path = test_dir("missing_field");
    let schema = Mapping::builder()
        .field("title", FieldType::Text)
        .field("body", FieldType::Text)
        .build();
    let index = Index::create_with_mapping(&path, schema).unwrap();
    index
        .add(json!({
            "title": "Test"
            // body is missing entirely
        }))
        .unwrap();

    let expr = parse_search(
        json!({
            "query": {"match": {"title": "test"}}
        }),
        10,
    )
    .unwrap();
    let results = index.search(&expr).unwrap();

    let config = HighlightConfig {
        fields: vec![HighlightFieldConfig {
            field: "body".to_string(),
            fragment_size: 150,
            number_of_fragments: 5,
            no_match_size: 0,
            pre_tags: None,
            post_tags: None,
        }],
        pre_tags: vec!["<em>".to_string()],
        post_tags: vec!["</em>".to_string()],
        require_field_match: false,
        order: HighlightOrder::None,
    };

    for hit in results.iter() {
        if let Some(hl) = hit.highlight_with_config(&config) {
            assert!(
                !hl.contains_key("body"),
                "missing field should not be in highlight"
            );
        }
    }
    cleanup(&path);
}
