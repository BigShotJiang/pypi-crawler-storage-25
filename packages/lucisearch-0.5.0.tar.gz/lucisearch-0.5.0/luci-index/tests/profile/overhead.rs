//! Infrastructure overhead profiling: storage reopen, JSON parsing, top-K collection.

use super::harness::*;
use luci_index::search::expression::parse_search;
use serde_json::json;

use std::time::Instant;

const ITERS: usize = 50;

/// Measure the per-query overhead of Index::search().
#[test]
fn index_search_reopen_cost() {
    println!("\n=== Overhead: Index.search() Cost ===\n");

    let (path, index) = build_text_corpus("reopen_cost", 10_000);

    let expr = parse_search(json!({"term": {"tag": "tech"}}), 10).unwrap();

    // Measure search via the Index facade
    let mut times = Vec::new();
    for _ in 0..ITERS {
        let start = Instant::now();
        let _ = index.search(&expr).unwrap();
        times.push(start.elapsed());
    }
    times.sort();
    let p50 = times[times.len() / 2];

    println!("Index.search():  p50={:.1}us", p50.as_micros() as f64);

    cleanup(&path);
}

/// Measure query JSON parsing overhead (isolated from search).
#[test]
fn json_parsing_overhead() {
    println!("\n=== Overhead: JSON Query Parsing ===\n");

    let queries = vec![
        ("simple_term", json!({"term": {"tag": "tech"}})),
        (
            "bool_2clause",
            json!({"bool": {"must": [{"match": {"title": "doc"}}, {"term": {"tag": "tech"}}]}}),
        ),
        (
            "complex_bool",
            json!({"bool": {
                "must": [{"match": {"title": "document"}}],
                "should": [{"match": {"body": "content"}}],
                "must_not": [{"term": {"tag": "sports"}}],
                "filter": [{"exists": {"field": "price"}}]
            }}),
        ),
        (
            "nested",
            json!({"nested": {"path": "offers", "query": {"bool": {"must": [
                {"term": {"offers.seller": "alice"}},
                {"term": {"offers.price": "100"}}
            ]}}}}),
        ),
    ];

    for (name, query) in &queries {
        let mut times = Vec::new();
        for _ in 0..1_000 {
            let start = Instant::now();
            let _ast = luci_index::query::parser::parse_query(query).unwrap();
            times.push(start.elapsed());
        }
        times.sort();
        let p50 = times[times.len() / 2];
        println!("{name:<20} p50={:.1}us", p50.as_micros() as f64);
    }
}
