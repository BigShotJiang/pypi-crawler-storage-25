//! Geospatial query profiling.

use super::harness::*;
use serde_json::json;

const WARMUP: usize = 3;
const ITERS: usize = 20;

#[test]
fn geo_distance_scaling() {
    println!("\n=== Geo: Distance Query Scaling ===\n");

    print_measurement_header();
    for &count in &[1_000, 5_000, 10_000, 50_000] {
        let (path, mut index) = build_geo_corpus(&format!("geo_dist_{count}"), count);

        let m = measure_query(
            &format!("geo_distance ({count} docs)"),
            &mut index,
            json!({"geo_distance": {"distance": "50km", "location": {"lat": 40.7, "lon": -74.0}}}),
            10,
            WARMUP,
            ITERS,
        );
        print_measurement(&m);
        // Geo distance on 50K docs should be under 50ms p99 (linear scan)
        m.assert_p99_under_ms(50);
        cleanup(&path);
    }
}

#[test]
fn geo_bbox_scaling() {
    println!("\n=== Geo: Bounding Box Query Scaling ===\n");

    print_measurement_header();
    for &count in &[1_000, 5_000, 10_000, 50_000] {
        let (path, mut index) = build_geo_corpus(&format!("geo_bbox_{count}"), count);

        let m = measure_query(
            &format!("geo_bbox ({count} docs)"),
            &mut index,
            json!({"geo_bounding_box": {"location": {
                "top_left": {"lat": 41.0, "lon": -74.5},
                "bottom_right": {"lat": 40.4, "lon": -73.5}
            }}}),
            10,
            WARMUP,
            ITERS,
        );
        print_measurement(&m);
        cleanup(&path);
    }
}

#[test]
fn geo_radius_selectivity() {
    println!("\n=== Geo: Distance Query by Radius (10K docs) ===\n");

    let (path, mut index) = build_geo_corpus("geo_radius", 10_000);

    print_measurement_header();
    for &radius_km in &[1, 10, 50, 100, 500, 5_000] {
        let m = measure_query(
            &format!("{radius_km}km radius"),
            &mut index,
            json!({"geo_distance": {"distance": format!("{radius_km}km"), "location": {"lat": 40.7, "lon": -74.0}}}),
            100,
            WARMUP,
            ITERS,
        );
        print_measurement(&m);
    }
    cleanup(&path);
}
