//! Luci profiling suite.
//!
//! Organized by area: indexing, search, aggregations, vector, geo, hybrid,
//! merge, nested, overhead.
//!
//! **IMPORTANT:** Run each test in isolation for accurate measurements.
//! Running the full suite concurrently causes resource contention that
//! inflates tail latencies (p99 can spike 40x under concurrent load).
//! Regression assertions are calibrated against isolated execution.
//!
//! Run a specific test (recommended):
//!   cargo test -p luci-index --test profile --release search::basic_queries -- --nocapture
//!   cargo test -p luci-index --test profile --release aggregations::metric_aggs -- --nocapture
//!   cargo test -p luci-index --test profile --release vector::knn_latency -- --nocapture
//!
//! Run all tests in an area:
//!   cargo test -p luci-index --test profile --release search -- --nocapture
//!
//! Run entire suite (for reporting only — assertions may fail under contention):
//!   cargo test -p luci-index --test profile --release -- --nocapture

mod aggregations;
mod geo;
mod harness;
mod hybrid;
mod indexing;
mod merge;
mod nested;
mod overhead;
mod search;
mod storage;
mod vector;
