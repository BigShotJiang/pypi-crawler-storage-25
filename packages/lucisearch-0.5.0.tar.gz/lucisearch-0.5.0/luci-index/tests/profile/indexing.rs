//! Indexing throughput and memory profiling.

use super::harness::*;
use luci_index::index::Index;
use serde_json::json;
use std::time::Instant;

#[test]
fn throughput_scaling() {
    println!("\n=== Indexing Throughput ===\n");

    for &count in &[1_000, 5_000, 10_000, 50_000] {
        let path = profile_dir(&format!("idx_tp_{count}"));
        let mem_before = memory_usage_kb();

        let index = Index::create_with_mapping(&path, text_schema()).unwrap();
        let tags = ["tech", "science", "sports", "politics", "entertainment"];
        let docs: Vec<serde_json::Value> = (0..count)
            .map(|i| {
                let tag = tags[i % tags.len()];
                json!({
                    "title": format!("document number {i} about {tag} topics"),
                    "body": format!("this is the body text for document {i} covering {tag} related content"),
                    "tag": tag,
                    "price": (i as f64 % 100.0) + 0.99,
                })
            })
            .collect();
        let start = Instant::now();
        index.bulk(docs).unwrap();
        let add_elapsed = start.elapsed();
        let commit_elapsed = std::time::Duration::ZERO;
        let total = start.elapsed();
        let mem_after = memory_usage_kb();
        let mem_delta = mem_after.saturating_sub(mem_before);

        println!(
            "{count:>6} docs: add={:.0}ms commit={:.0}ms total={:.0}ms ({:.0} docs/s) mem={mem_delta}KB",
            add_elapsed.as_millis(),
            commit_elapsed.as_millis(),
            total.as_millis(),
            count as f64 / total.as_secs_f64()
        );

        cleanup(&path);
    }
}

#[test]
fn memory_per_doc() {
    println!("\n=== Memory Per Document ===\n");

    let path = profile_dir("mem_per_doc");
    let mem_before = memory_usage_kb();
    let index = Index::create_with_mapping(&path, text_schema()).unwrap();
    let tags = ["a", "b", "c", "d", "e"];

    for &checkpoint in &[1_000, 5_000, 10_000, 25_000, 50_000] {
        let prev = if checkpoint == 1_000 {
            0
        } else {
            [1_000, 5_000, 10_000, 25_000, 50_000]
                .iter()
                .take_while(|&&c| c < checkpoint)
                .last()
                .copied()
                .unwrap_or(0)
        };
        let docs: Vec<serde_json::Value> = (prev..checkpoint)
            .map(|i| {
                json!({
                    "title": format!("document {i}"),
                    "body": format!("body text for document {i} with some more words"),
                    "tag": tags[i % tags.len()],
                    "price": (i as f64 % 100.0),
                })
            })
            .collect();
        index.bulk(docs).unwrap();

        let mem_now = memory_usage_kb();
        let delta = mem_now.saturating_sub(mem_before);
        let per_doc = delta as f64 / checkpoint as f64;
        println!("{checkpoint:>6} docs: RSS={mem_now}KB  delta={delta}KB  ({per_doc:.1}KB/doc)");
    }

    let disk = disk_usage_bytes(&path);
    println!(
        "\nDisk: {:.1}MB total, {:.0} bytes/doc",
        disk as f64 / 1_048_576.0,
        disk as f64 / 50_000.0
    );
    cleanup(&path);
}
