//! Columnar storage for fast field access.
//!
//! Stores per-field column data for keyword, numeric, and boolean fields.
//! Enables fast aggregations and sorting without touching the document store.
//!
//! See [[columnar-storage]] and [[feature-aggregations-v010#Step 1]].

pub mod reader;
pub mod writer;
