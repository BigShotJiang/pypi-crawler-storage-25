//! Geospatial support: geo_point/geo_shape storage, spatial queries.
//!
//! See [[geospatial]], [[feature-geo-shape]], and [[feature-geo-shape|milestone-6]].

pub mod geo;
pub mod query;
pub mod shape;
