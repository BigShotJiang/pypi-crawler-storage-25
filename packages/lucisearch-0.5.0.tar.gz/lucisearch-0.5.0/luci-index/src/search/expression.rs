//! SearchExpression: the top-level search request DSL.
//!
//! A composable description of a search request: what to match (query),
//! what to compute (aggregations), how to order (sort), and how to
//! paginate (size, from, search_after, collapse).
//!
//! Consumers build expressions directly (Rust) or parse them from JSON
//! at the edge (Python SDK, CLI).
//!
//! See [[architecture-scoring-materialization-separation]].

use crate::agg::AggregationExpression;
use crate::search::{SortField, SortValue, TrackTotalHits};

/// A complete search request.
///
/// The engine's native search input. `Index.search()` takes this.
/// JSON parsing at the edge (`SearchExpression::from_json`) produces this.
pub struct SearchExpression {
    /// The query — the user's intent. Compiled to BoundQuery at search time.
    /// None means match_all.
    pub(crate) query: Option<crate::query::ast::QueryExpression>,
    /// kNN query (optional, fused with text query via RRF).
    pub(crate) knn: Option<KnnQuery>,
    /// Named aggregation definitions.
    pub(crate) aggs: Vec<(String, AggregationExpression)>,
    /// Maximum hits to return.
    pub(crate) size: usize,
    /// Pagination offset.
    pub(crate) from: usize,
    /// Sort specification. None = sort by score.
    pub(crate) sort: Option<Vec<SortField>>,
    /// Field collapse (deduplication by field value).
    pub(crate) collapse: Option<String>,
    /// Keyset pagination cursor.
    pub(crate) search_after: Option<Vec<SortValue>>,
    /// Total hits tracking mode.
    pub(crate) track_total_hits: TrackTotalHits,
    /// Rescore specification (optional second-pass re-ranking).
    pub(crate) rescore: Option<RescoreSpec>,
}

/// kNN query specification.
pub struct KnnQuery {
    pub field: String,
    pub query_vector: Vec<f32>,
    pub k: usize,
    pub num_candidates: usize,
}

/// Rescore specification for second-pass re-ranking.
pub struct RescoreSpec {
    pub(crate) query: Box<dyn crate::query::Query>,
    pub window_size: usize,
    pub query_weight: f32,
    pub rescore_query_weight: f32,
    pub score_mode: crate::search::RescoreScoreMode,
}

impl SearchExpression {
    /// Create a new expression with defaults (match_all, size=10).
    pub fn new() -> Self {
        Self {
            query: None,
            knn: None,
            aggs: Vec::new(),
            size: 10,
            from: 0,
            sort: None,
            collapse: None,
            search_after: None,
            track_total_hits: TrackTotalHits::Exact,
            rescore: None,
        }
    }

    /// Set the scoring query.
    /// Set the query expression.
    pub fn query(mut self, query: crate::query::ast::QueryExpression) -> Self {
        self.query = Some(query);
        self
    }

    /// Add a named aggregation.
    pub fn agg(mut self, name: impl Into<String>, agg: AggregationExpression) -> Self {
        self.aggs.push((name.into(), agg));
        self
    }

    /// Set the maximum number of hits to return.
    pub fn size(mut self, size: usize) -> Self {
        self.size = size;
        self
    }

    /// Set the pagination offset.
    pub fn from(mut self, from: usize) -> Self {
        self.from = from;
        self
    }

    /// Set the sort specification.
    pub fn sort(mut self, sort: Vec<SortField>) -> Self {
        self.sort = Some(sort);
        self
    }

    /// Set the collapse field.
    pub fn collapse(mut self, field: impl Into<String>) -> Self {
        self.collapse = Some(field.into());
        self
    }

    /// Set the search_after cursor.
    pub fn search_after(mut self, cursor: Vec<SortValue>) -> Self {
        self.search_after = Some(cursor);
        self
    }

    /// Set total hits tracking mode.
    pub fn track_total_hits(mut self, mode: TrackTotalHits) -> Self {
        self.track_total_hits = mode;
        self
    }

    /// Set a kNN query.
    pub fn knn(mut self, knn: KnnQuery) -> Self {
        self.knn = Some(knn);
        self
    }

    /// Set a rescore specification.
    pub fn rescore(mut self, rescore: RescoreSpec) -> Self {
        self.rescore = Some(rescore);
        self
    }
}

impl Default for SearchExpression {
    fn default() -> Self {
        Self::new()
    }
}

/// Parse an ES-compatible JSON search request into a SearchExpression.
///
/// This is the edge parser — converts the JSON wire format into the
/// engine's native expression type. Called by Python SDK and CLI.
///
/// Accepts both bare queries (`{"match": {...}}`) and structured
/// requests (`{"query": {...}, "aggs": {...}, "size": 10}`).
pub fn parse_search(
    json: serde_json::Value,
    default_size: usize,
) -> Result<SearchExpression, luci_core::LuciError> {
    SearchExpression::from_json(json, default_size)
}

impl SearchExpression {
    /// Parse an ES-compatible JSON search request.
    ///
    /// Accepts both bare queries (`{"match": {...}}`) and structured
    /// requests (`{"query": {...}, "aggs": {...}, "size": 10}`).
    pub fn from_json(
        json: serde_json::Value,
        default_size: usize,
    ) -> Result<SearchExpression, luci_core::LuciError> {
        use crate::query::parser::parse_query;
        use luci_core::LuciError;

        let is_structured = json.is_object()
            && (json.get("query").is_some()
                || json.get("knn").is_some()
                || json.get("aggs").is_some()
                || json.get("aggregations").is_some()
                || json.get("size").is_some()
                || json.get("from").is_some()
                || json.get("sort").is_some()
                || json.get("search_after").is_some()
                || json.get("collapse").is_some()
                || json.get("track_total_hits").is_some()
                || json.get("rescore").is_some());

        let mut expr = SearchExpression::new();

        if is_structured {
            // Parse query
            if let Some(q) = json.get("query") {
                expr.query = Some(parse_query(q)?);
            }

            // Parse kNN
            if let Some(knn_json) = json.get("knn") {
                let field = knn_json
                    .get("field")
                    .and_then(|v| v.as_str())
                    .ok_or_else(|| LuciError::InvalidQuery("knn requires 'field'".into()))?;
                let query_vector: Vec<f32> = knn_json
                    .get("query_vector")
                    .and_then(|v| v.as_array())
                    .ok_or_else(|| LuciError::InvalidQuery("knn requires 'query_vector'".into()))?
                    .iter()
                    .filter_map(|v| v.as_f64().map(|f| f as f32))
                    .collect();
                let k = knn_json.get("k").and_then(|v| v.as_u64()).unwrap_or(10) as usize;
                let num_candidates = knn_json
                    .get("num_candidates")
                    .and_then(|v| v.as_u64())
                    .unwrap_or(k as u64 * 2) as usize;
                expr.knn = Some(KnnQuery {
                    field: field.to_string(),
                    query_vector,
                    k,
                    num_candidates,
                });
            }

            // Parse aggregations
            if let Some(aggs_json) = json.get("aggs").or_else(|| json.get("aggregations")) {
                expr.aggs = crate::agg::parser::parse_aggs(aggs_json)?;
            }

            // Parse size/from
            expr.size = json
                .get("size")
                .and_then(|v| v.as_u64())
                .map(|v| v as usize)
                .unwrap_or(default_size);
            expr.from = json
                .get("from")
                .and_then(|v| v.as_u64())
                .map(|v| v as usize)
                .unwrap_or(0);

            // Parse sort
            expr.sort = crate::index::parse_sort(json.get("sort"));
            expr.search_after = crate::index::parse_search_after(json.get("search_after"));

            // Parse collapse
            expr.collapse = json
                .get("collapse")
                .and_then(|v| v.get("field"))
                .and_then(|v| v.as_str())
                .map(String::from);

            // Parse track_total_hits
            expr.track_total_hits = match json.get("track_total_hits") {
                Some(serde_json::Value::Bool(true)) | None => TrackTotalHits::Exact,
                Some(serde_json::Value::Bool(false)) => TrackTotalHits::Disabled,
                Some(serde_json::Value::Number(n)) => TrackTotalHits::UpTo(n.as_u64().unwrap_or(0)),
                _ => TrackTotalHits::Exact,
            };

            // Parse rescore
            if let Some(rescore_val) = json.get("rescore") {
                let rescore_obj = rescore_val.get("query").or(Some(rescore_val));
                if let Some(rq) = rescore_obj.and_then(|o| o.get("rescore_query")) {
                    let rescore_query: Box<dyn crate::query::Query> = Box::new(parse_query(rq)?);
                    let window_size = rescore_val
                        .get("window_size")
                        .and_then(|v| v.as_u64())
                        .map(|v| v as usize)
                        .unwrap_or(10);
                    let query_weight = rescore_val
                        .get("query")
                        .and_then(|o| o.get("query_weight"))
                        .and_then(|v| v.as_f64())
                        .map(|v| v as f32)
                        .unwrap_or(1.0);
                    let rescore_query_weight = rescore_val
                        .get("query")
                        .and_then(|o| o.get("rescore_query_weight"))
                        .and_then(|v| v.as_f64())
                        .map(|v| v as f32)
                        .unwrap_or(1.0);
                    let score_mode = match rescore_val
                        .get("query")
                        .and_then(|o| o.get("score_mode"))
                        .and_then(|v| v.as_str())
                    {
                        Some("multiply") => crate::search::RescoreScoreMode::Multiply,
                        Some("avg") => crate::search::RescoreScoreMode::Avg,
                        Some("max") => crate::search::RescoreScoreMode::Max,
                        Some("min") => crate::search::RescoreScoreMode::Min,
                        _ => crate::search::RescoreScoreMode::Total,
                    };
                    expr.rescore = Some(RescoreSpec {
                        query: rescore_query,
                        window_size,
                        query_weight,
                        rescore_query_weight,
                        score_mode,
                    });
                }
            }
        } else {
            // Bare query — the entire JSON is the query
            expr.query = Some(parse_query(&json)?);
            expr.size = default_size;
        }

        Ok(expr)
    }
}
