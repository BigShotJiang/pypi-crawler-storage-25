//! New search result types: SearchResults, HitRef, Hit.
//!
//! `SearchResults` owns `Arc<SegmentStore>` and the scored hit references.
//! `Hit` borrows from `SearchResults` and provides lazy content access
//! via Reader. Source, fields, explain, and inner_hits are lazy.
//! Everything is lazy: source, fields, explain, highlight, inner_hits.
//!
//! See [[architecture-scoring-materialization-separation]].

use std::sync::Arc;

use luci_core::{DocId, SegmentId};

use crate::search::SortValue;
use crate::search::reader::Reader;
use crate::search::segment_store::SegmentStore;

/// Internal per-hit bookkeeping. Stores scored address + collector
/// metadata + eagerly computed fields.
///
/// `pub(crate)` — consumers see `Hit`, not `HitRef`.
#[derive(Clone, Debug)]
pub(crate) struct HitRef {
    pub doc_id: DocId,
    pub segment_id: SegmentId,
    pub score: f32,
    pub sort_values: Option<Vec<SortValue>>,
    pub collapse_key: Option<serde_json::Value>,
}

/// Search results with lazy content access.
///
/// Owns an `Arc<SegmentStore>` to keep the segment data alive for
/// lazy retrieval.
pub struct SearchResults {
    hits: Vec<HitRef>,
    total_hits: crate::search::TotalHits,
    aggregations: std::collections::HashMap<String, crate::agg::AggregationResult>,
    store: Arc<SegmentStore>,
    /// The query expression (for lazy explain and highlight).
    query: Option<crate::query::ast::QueryExpression>,
}

impl SearchResults {
    pub(crate) fn new(
        hits: Vec<HitRef>,
        total_hits: crate::search::TotalHits,
        aggregations: std::collections::HashMap<String, crate::agg::AggregationResult>,
        store: Arc<SegmentStore>,
        query: Option<crate::query::ast::QueryExpression>,
    ) -> Self {
        Self {
            hits,
            total_hits,
            aggregations,
            store,
            query,
        }
    }

    /// Iterate over hits, yielding `Hit` handles with lazy content access.
    pub fn iter(&self) -> impl Iterator<Item = Hit<'_>> {
        self.hits.iter().map(move |hr| Hit {
            hit_ref: hr,
            store: &self.store,
            query: self.query.as_ref(),
        })
    }

    /// Get a hit by index.
    pub fn hit(&self, index: usize) -> Option<Hit<'_>> {
        self.hits.get(index).map(|hr| Hit {
            hit_ref: hr,
            store: &self.store,
            query: self.query.as_ref(),
        })
    }

    /// Number of hits in this page.
    pub fn len(&self) -> usize {
        self.hits.len()
    }

    /// Whether there are no hits.
    pub fn is_empty(&self) -> bool {
        self.hits.is_empty()
    }

    /// Total hits metadata (count + relation).
    pub fn total_hits(&self) -> &crate::search::TotalHits {
        &self.total_hits
    }

    /// Aggregation results (empty if none requested).
    pub fn aggregations(
        &self,
    ) -> &std::collections::HashMap<String, crate::agg::AggregationResult> {
        &self.aggregations
    }

    /// Access the store (for FFI layers that need the raw pointer).
    pub fn store(&self) -> &Arc<SegmentStore> {
        &self.store
    }
}

/// A single search hit with lazy content access.
///
/// The consumer sees this as a complete result. `source()`, `fields()`,
/// `explain()`, and `inner_hits()` retrieve content on demand.
/// All content access is lazy — nothing is eagerly materialized.
pub struct Hit<'a> {
    hit_ref: &'a HitRef,
    store: &'a SegmentStore,
    query: Option<&'a crate::query::ast::QueryExpression>,
}

impl<'a> Hit<'a> {
    /// Relevance score.
    pub fn score(&self) -> f32 {
        self.hit_ref.score
    }

    /// Document ID (segment-local).
    pub fn doc_id(&self) -> DocId {
        self.hit_ref.doc_id
    }

    /// Segment ID.
    pub fn segment_id(&self) -> SegmentId {
        self.hit_ref.segment_id
    }

    /// Sort values (present for sorted search).
    pub fn sort_values(&self) -> Option<&[SortValue]> {
        self.hit_ref.sort_values.as_deref()
    }

    /// Collapse key (present for collapsed search).
    pub fn collapse_key(&self) -> Option<&serde_json::Value> {
        self.hit_ref.collapse_key.as_ref()
    }

    /// Retrieve the document source. Lazy: LZ4 decompress + JSON parse
    /// happens on this call, not during search.
    pub fn source(&self) -> Option<serde_json::Value> {
        let reader = Reader::new(self.store);
        reader.get_source(self.hit_ref.segment_id, self.hit_ref.doc_id)
    }

    /// Retrieve the document source with filtering applied.
    pub fn source_filtered(
        &self,
        filter: &crate::search::SourceFilter,
    ) -> Option<serde_json::Value> {
        use crate::search::SourceFilter;
        match filter {
            SourceFilter::Disabled => None,
            SourceFilter::Enabled => self.source(),
            f => {
                let source = self.source()?;
                crate::search::filter_source(&source, f)
            }
        }
    }

    /// Retrieve typed field values from the columnar store. Lazy.
    pub fn fields(&self, names: &[String]) -> serde_json::Map<String, serde_json::Value> {
        let reader = Reader::new(self.store);
        reader.retrieve_fields(self.hit_ref.segment_id, self.hit_ref.doc_id, names)
    }

    /// Raw source bytes (LZ4-decompressed, unparsed). Lazy.
    pub fn source_bytes(&self) -> Option<Vec<u8>> {
        let reader = Reader::new(self.store);
        reader.get_source_bytes(self.hit_ref.segment_id, self.hit_ref.doc_id)
    }

    /// Explain this hit's score. Lazy: creates a BoundQuery from the
    /// stored query and walks the scorer tree for this document.
    pub fn explain(&self) -> Option<crate::search::Explanation> {
        use crate::query::Query as _;
        let query = self.query?;
        let searcher = crate::search::searcher::Searcher::new(self.store);
        let weight = query.bind(&searcher, luci_core::ScoreMode::Complete).ok()?;
        let segment = self
            .store
            .segments()
            .iter()
            .find(|s| s.segment_id() == self.hit_ref.segment_id)?;
        weight.explain(segment, self.hit_ref.doc_id).ok()
    }

    /// Generate highlight fragments for a field. Lazy: extracts query terms
    /// from the stored query, loads source from doc store, re-analyzes with
    /// the field's analyzer, and returns fragments with matched terms.
    pub fn highlight(&self, field: &str) -> Option<serde_json::Map<String, serde_json::Value>> {
        let config = crate::search::highlight::HighlightConfig {
            fields: vec![crate::search::highlight::HighlightFieldConfig {
                field: field.to_string(),
                fragment_size: 150,
                number_of_fragments: 5,
                no_match_size: 0,
                pre_tags: None,
                post_tags: None,
            }],
            pre_tags: vec!["<em>".to_string()],
            post_tags: vec!["</em>".to_string()],
            require_field_match: true,
            order: crate::search::highlight::HighlightOrder::None,
        };
        self.highlight_with_config(&config)
    }

    /// Generate highlight fragments using a custom [`HighlightConfig`].
    /// Lazy: extracts query terms from the stored query, loads source from
    /// the doc store, re-analyzes with the field's analyzer, and returns
    /// fragments with matched terms wrapped in the configured tags.
    ///
    /// See [[feature-search-highlight]].
    pub fn highlight_with_config(
        &self,
        config: &crate::search::highlight::HighlightConfig,
    ) -> Option<serde_json::Map<String, serde_json::Value>> {
        let query = self.query?;
        let searcher = crate::search::searcher::Searcher::new(self.store);
        let query_terms = crate::search::highlight::extract_query_terms(query, &searcher);
        let reader = Reader::new(self.store);
        let source = reader.get_source(self.hit_ref.segment_id, self.hit_ref.doc_id)?;
        crate::search::highlight::highlight_hit(
            &source,
            config,
            &query_terms,
            self.store.analyzers(),
            self.store.mapping(),
        )
    }

    /// Inner hits from nested queries. Lazy: extracts InnerHitSpecs from
    /// the stored query, re-runs nested scorers within this doc's child
    /// block, and extracts nested source from the parent document.
    pub fn inner_hits(&self) -> Option<std::collections::HashMap<String, serde_json::Value>> {
        use luci_core::NO_MORE_DOCS;
        use std::cmp::Ordering;

        let query = self.query?;
        let searcher = crate::search::searcher::Searcher::new(self.store);
        let specs = crate::index::extract_inner_hit_specs(query, &searcher);
        if specs.is_empty() {
            return None;
        }

        let segment = self
            .store
            .segments()
            .iter()
            .find(|s| s.segment_id() == self.hit_ref.segment_id)?;
        let parent_bitset = segment.parent_bitset()?;
        let parent_doc = self.hit_ref.doc_id.as_u32() as usize;

        let child_start = parent_doc + 1;
        let child_end = (child_start..parent_bitset.len())
            .find(|&i| parent_bitset[i])
            .unwrap_or(parent_bitset.len());

        if child_start >= child_end {
            return None;
        }

        let reader = Reader::new(self.store);
        let parent_source = reader.get_source(self.hit_ref.segment_id, self.hit_ref.doc_id);

        let mut inner_hits_map = std::collections::HashMap::new();

        for spec in &specs {
            let supplier = match spec.weight.scorer_supplier(segment) {
                Ok(Some(s)) => s,
                _ => continue,
            };
            let mut scorer = match supplier.scorer() {
                Ok(s) => s,
                Err(_) => continue,
            };

            scorer.advance(luci_core::DocId::new(child_start as u32));
            let mut matches: Vec<(u32, f32)> = Vec::new();
            while scorer.doc_id() != NO_MORE_DOCS {
                let doc = scorer.doc_id().as_u32();
                if doc >= child_end as u32 {
                    break;
                }
                matches.push((doc, scorer.score()));
                scorer.next();
            }

            if matches.is_empty() {
                continue;
            }

            matches.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(Ordering::Equal));
            let total = matches.len();
            let page: Vec<_> = matches
                .into_iter()
                .skip(spec.config.from)
                .take(spec.config.size)
                .collect();

            let inner_hit_docs: Vec<serde_json::Value> = page
                .iter()
                .map(|(child_doc, score)| {
                    let offset = (*child_doc as usize).saturating_sub(child_start);
                    let nested_source = parent_source
                        .as_ref()
                        .and_then(|ps| ps.get(&spec.path))
                        .and_then(|arr| arr.as_array())
                        .and_then(|a| a.get(offset))
                        .cloned();
                    serde_json::json!({
                        "_nested": { "field": spec.path, "offset": offset },
                        "_score": score,
                        "_source": nested_source,
                    })
                })
                .collect();

            inner_hits_map.insert(
                spec.name.clone(),
                serde_json::json!({
                    "hits": {
                        "total": { "value": total, "relation": "eq" },
                        "hits": inner_hit_docs,
                    }
                }),
            );
        }

        if inner_hits_map.is_empty() {
            None
        } else {
            Some(inner_hits_map)
        }
    }
}
