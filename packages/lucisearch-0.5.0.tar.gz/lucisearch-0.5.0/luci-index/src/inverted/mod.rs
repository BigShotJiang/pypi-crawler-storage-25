//! Inverted index structures: posting lists, term dictionary, field norms.
//!
//! See [[inverted-index]] and [[architecture-segment-layout]].

pub mod norms;
pub mod postings;
pub mod term_dict;
