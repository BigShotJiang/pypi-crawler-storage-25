//! Convert [`QueryExpression`] trees to executable [`Query`] objects.
//!
//! Bridges the JSON parser output to the execution pipeline.

use crate::query::Query;
use crate::query::ast::QueryExpression;
use crate::query::boolean::BoolQuery;
use crate::query::constant_score::ConstantScoreQuery;
use crate::query::exists::ExistsQuery;
use crate::query::match_query::MatchQuery;
use crate::query::phrase::MatchPhraseQuery;
use crate::query::prefix::PrefixQuery;
use crate::query::range::RangeQuery;
use crate::query::term::TermQuery;

/// Convert a parsed [`QueryExpression`] tree into an executable [`Query`] trait object.
#[allow(dead_code)] // used in unit tests and available for future callers
pub(crate) fn ast_to_query(ast: &QueryExpression) -> Box<dyn Query> {
    match ast {
        QueryExpression::Term { field, value } => Box::new(TermQuery {
            field: field.clone(),
            value: value.clone(),
        }),

        QueryExpression::Terms { field, values } => {
            // Rewrite to Bool { should: [TermQuery * N] }
            let should: Vec<Box<dyn Query>> = values
                .iter()
                .map(|v| -> Box<dyn Query> {
                    Box::new(TermQuery {
                        field: field.clone(),
                        value: v.clone(),
                    })
                })
                .collect();
            Box::new(BoolQuery {
                must: vec![],
                should,
                must_not: vec![],
                filter: vec![],
            })
        }

        QueryExpression::Match {
            field,
            query,
            analyzer,
        } => Box::new(MatchQuery {
            field: field.clone(),
            query_text: query.clone(),
            analyzer: analyzer.clone(),
        }),

        QueryExpression::MatchPhrase {
            field,
            query,
            analyzer,
        } => Box::new(MatchPhraseQuery {
            field: field.clone(),
            query_text: query.clone(),
            analyzer: analyzer.clone(),
        }),

        QueryExpression::Bool {
            must,
            should,
            must_not,
            filter,
        } => Box::new(BoolQuery {
            must: must.iter().map(ast_to_query).collect(),
            should: should.iter().map(ast_to_query).collect(),
            must_not: must_not.iter().map(ast_to_query).collect(),
            filter: filter.iter().map(ast_to_query).collect(),
        }),

        QueryExpression::MatchBoolPrefix {
            field,
            query,
            analyzer,
        } => {
            // Rewrite: analyze text, all tokens → term queries, last → prefix
            let registry = luci_analysis::AnalyzerRegistry::new();
            let analyzer_name = analyzer.as_deref().unwrap_or("standard");
            let analyzed = registry.get(analyzer_name).analyze(query);
            let tokens: Vec<String> = analyzed.into_iter().map(|t| t.text).collect();
            if tokens.is_empty() {
                Box::new(MatchNoneQuery)
            } else {
                let mut should: Vec<Box<dyn Query>> = Vec::new();
                for (i, token) in tokens.iter().enumerate() {
                    if i == tokens.len() - 1 {
                        should.push(Box::new(PrefixQuery {
                            field: field.clone(),
                            value: token.clone(),
                        }));
                    } else {
                        should.push(Box::new(TermQuery {
                            field: field.clone(),
                            value: token.clone(),
                        }));
                    }
                }
                Box::new(BoolQuery {
                    must: vec![],
                    should,
                    must_not: vec![],
                    filter: vec![],
                })
            }
        }

        QueryExpression::DisMax {
            queries,
            tie_breaker,
        } => Box::new(crate::query::dis_max::DisMaxQuery {
            queries: queries.iter().map(ast_to_query).collect(),
            tie_breaker: *tie_breaker,
        }),

        QueryExpression::Exists { field } => Box::new(ExistsQuery {
            field: field.clone(),
        }),

        QueryExpression::Prefix { field, value } => Box::new(PrefixQuery {
            field: field.clone(),
            value: value.clone(),
        }),

        QueryExpression::ConstantScore { query, boost } => Box::new(ConstantScoreQuery {
            inner: ast_to_query(query),
            boost: *boost,
        }),

        QueryExpression::Nested {
            path,
            query,
            inner_hits,
        } => Box::new(crate::query::nested::NestedQuery {
            path: path.clone(),
            inner: ast_to_query(query),
            inner_hits: inner_hits.clone(),
        }),

        QueryExpression::GeoDistance {
            field,
            lat,
            lon,
            distance,
        } => {
            let distance_km = crate::query::parser::parse_distance_km(distance);
            Box::new(crate::spatial::query::GeoDistanceQuery {
                field: field.clone(),
                center: crate::spatial::geo::GeoPoint::new(*lat, *lon),
                distance_km,
            })
        }

        QueryExpression::GeoBoundingBox {
            field,
            top_left_lat,
            top_left_lon,
            bottom_right_lat,
            bottom_right_lon,
        } => Box::new(crate::spatial::query::GeoBoundingBoxQuery {
            field: field.clone(),
            top_left: crate::spatial::geo::GeoPoint::new(*top_left_lat, *top_left_lon),
            bottom_right: crate::spatial::geo::GeoPoint::new(*bottom_right_lat, *bottom_right_lon),
        }),

        QueryExpression::GeoShape {
            field,
            shape,
            relation,
        } => {
            let query_geom = crate::spatial::shape::parse_geojson(&shape.json)
                .unwrap_or(::geo::Geometry::Point(::geo::Point::new(0.0, 0.0)));
            let query_bbox =
                crate::spatial::shape::compute_bbox(&query_geom).unwrap_or((0.0, 0.0, 0.0, 0.0));
            Box::new(crate::spatial::query::GeoShapeQuery {
                field: field.clone(),
                query_shape: query_geom,
                query_bbox,
                relation: relation.clone(),
            })
        }

        QueryExpression::Range {
            field,
            gte,
            gt,
            lte,
            lt,
        } => Box::new(RangeQuery {
            field: field.clone(),
            gte: *gte,
            gt: *gt,
            lte: *lte,
            lt: *lt,
        }),

        QueryExpression::Boost { query, boost } => Box::new(crate::query::boost::BoostQuery {
            inner: ast_to_query(query),
            boost: *boost,
        }),

        QueryExpression::ScriptScore {
            query,
            script,
            params,
        } => Box::new(crate::query::script_score::ScriptScoreQuery {
            query: ast_to_query(query),
            script: script.clone(),
            params: params.clone(),
        }),

        QueryExpression::FunctionScore {
            query,
            functions,
            score_mode,
            boost_mode,
        } => Box::new(crate::query::function_score::FunctionScoreQuery {
            query: ast_to_query(query),
            functions: functions.clone(),
            score_mode: score_mode.clone(),
            boost_mode: boost_mode.clone(),
        }),

        QueryExpression::Boosting {
            positive,
            negative,
            negative_boost,
        } => Box::new(crate::query::boosting::BoostingQuery {
            positive: ast_to_query(positive),
            negative: ast_to_query(negative),
            negative_boost: *negative_boost,
        }),

        QueryExpression::Fuzzy {
            field,
            value,
            fuzziness,
        } => Box::new(crate::query::fuzzy::FuzzyQuery {
            field: field.clone(),
            value: value.clone(),
            fuzziness: *fuzziness,
        }),

        QueryExpression::Regexp { field, value } => Box::new(crate::query::regexp::RegexpQuery {
            field: field.clone(),
            pattern: value.clone(),
        }),

        QueryExpression::Wildcard { field, value } => {
            Box::new(crate::query::wildcard::WildcardQuery {
                field: field.clone(),
                pattern: value.clone(),
            })
        }

        QueryExpression::MultiMatch {
            fields,
            query,
            analyzer,
        } => {
            let should: Vec<Box<dyn Query>> = fields
                .iter()
                .map(|f| -> Box<dyn Query> {
                    Box::new(MatchQuery {
                        field: f.clone(),
                        query_text: query.clone(),
                        analyzer: analyzer.clone(),
                    })
                })
                .collect();
            Box::new(BoolQuery {
                must: vec![],
                should,
                must_not: vec![],
                filter: vec![],
            })
        }

        QueryExpression::SpanTerm { field, value } => Box::new(crate::query::span::SpanTermQuery {
            field: field.clone(),
            value: value.clone(),
        }),

        QueryExpression::SpanNear {
            field,
            terms,
            slop,
            in_order,
        } => Box::new(crate::query::span::SpanNearQuery {
            field: field.clone(),
            terms: terms.clone(),
            slop: *slop,
            in_order: *in_order,
        }),

        QueryExpression::SpanNot { include, exclude } => {
            Box::new(crate::query::span::SpanNotQuery {
                include: ast_to_query(include),
                exclude: ast_to_query(exclude),
            })
        }

        QueryExpression::SpanFirst { query, end } => Box::new(crate::query::span::SpanFirstQuery {
            inner: ast_to_query(query),
            end: *end,
        }),

        QueryExpression::MatchAll => Box::new(MatchAllQuery),

        QueryExpression::MatchNone => Box::new(MatchNoneQuery),
    }
}

/// Matches all documents with score 1.0.
pub struct MatchAllQuery;

impl Query for MatchAllQuery {
    fn bind(
        &self,
        _searcher: &crate::search::searcher::Searcher,
        _score_mode: luci_core::ScoreMode,
    ) -> luci_core::Result<Box<dyn crate::query::BoundQuery>> {
        Ok(Box::new(BoundMatchAllQuery))
    }
}

struct BoundMatchAllQuery;

impl crate::query::BoundQuery for BoundMatchAllQuery {
    fn is_match_all(&self) -> bool {
        true
    }

    fn scorer_supplier(
        &self,
        reader: &crate::segment::reader::SegmentReader,
    ) -> luci_core::Result<Option<Box<dyn crate::query::ScorerSupplier>>> {
        let doc_count = reader.doc_count();
        if doc_count == 0 {
            return Ok(None);
        }
        Ok(Some(Box::new(MatchAllScorerSupplier { doc_count })))
    }
}

struct MatchAllScorerSupplier {
    doc_count: u32,
}

impl crate::query::ScorerSupplier for MatchAllScorerSupplier {
    fn cost(&self) -> u64 {
        self.doc_count as u64
    }

    fn scorer(self: Box<Self>) -> luci_core::Result<Box<dyn luci_core::Scorer>> {
        Ok(Box::new(MatchAllScorer {
            current: 0,
            doc_count: self.doc_count,
        }))
    }
}

struct MatchAllScorer {
    current: u32,
    doc_count: u32,
}

impl luci_core::Scorer for MatchAllScorer {
    fn doc_id(&self) -> luci_core::DocId {
        if self.current < self.doc_count {
            luci_core::DocId::new(self.current)
        } else {
            luci_core::NO_MORE_DOCS
        }
    }
    fn next(&mut self) -> luci_core::DocId {
        self.current += 1;
        self.doc_id()
    }
    fn advance(&mut self, target: luci_core::DocId) -> luci_core::DocId {
        self.current = target.as_u32();
        self.doc_id()
    }
    fn score(&mut self) -> f32 {
        1.0
    }
    fn two_phase(&mut self) -> Option<&mut dyn luci_core::TwoPhaseIterator> {
        None
    }
}

pub struct MatchNoneQuery;

impl Query for MatchNoneQuery {
    fn bind(
        &self,
        _searcher: &crate::search::searcher::Searcher,
        _score_mode: luci_core::ScoreMode,
    ) -> luci_core::Result<Box<dyn crate::query::BoundQuery>> {
        Ok(Box::new(BoundMatchNoneQuery))
    }
}

struct BoundMatchNoneQuery;

impl crate::query::BoundQuery for BoundMatchNoneQuery {
    fn scorer_supplier(
        &self,
        _reader: &crate::segment::reader::SegmentReader,
    ) -> luci_core::Result<Option<Box<dyn crate::query::ScorerSupplier>>> {
        Ok(None)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::query::ast::QueryExpression;

    #[test]
    fn convert_term() {
        let ast = QueryExpression::Term {
            field: "f".into(),
            value: "v".into(),
        };
        let _query = ast_to_query(&ast); // should not panic
    }

    #[test]
    fn convert_bool_nested() {
        let ast = QueryExpression::Bool {
            must: vec![QueryExpression::Term {
                field: "a".into(),
                value: "1".into(),
            }],
            should: vec![QueryExpression::Match {
                field: "b".into(),
                query: "hello".into(),
                analyzer: None,
            }],
            must_not: vec![],
            filter: vec![QueryExpression::Exists { field: "c".into() }],
        };
        let _query = ast_to_query(&ast);
    }

    #[test]
    fn convert_all_types() {
        let types = vec![
            QueryExpression::Term {
                field: "f".into(),
                value: "v".into(),
            },
            QueryExpression::Terms {
                field: "f".into(),
                values: vec!["a".into(), "b".into()],
            },
            QueryExpression::Match {
                field: "f".into(),
                query: "q".into(),
                analyzer: None,
            },
            QueryExpression::MatchPhrase {
                field: "f".into(),
                query: "q".into(),
                analyzer: None,
            },
            QueryExpression::Exists { field: "f".into() },
            QueryExpression::Prefix {
                field: "f".into(),
                value: "p".into(),
            },
            QueryExpression::ConstantScore {
                query: Box::new(QueryExpression::MatchAll),
                boost: 1.0,
            },
            QueryExpression::MatchAll,
            QueryExpression::MatchNone,
        ];
        for ast in &types {
            let _q = ast_to_query(ast);
        }
    }
}
