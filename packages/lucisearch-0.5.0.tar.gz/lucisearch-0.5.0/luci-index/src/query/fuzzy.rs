//! Fuzzy query: match terms within edit distance (Levenshtein).
//!
//! Uses the `levenshtein_automata` crate to build a DFA that accepts
//! all terms within the specified edit distance. Each term is tested
//! against the DFA in O(term_length) instead of O(m×n) DP.
//!
//! See [[elasticsearch-parity]] and [[optimization-wildcard-fuzzy-queries]].

use levenshtein_automata::LevenshteinAutomatonBuilder;
use luci_core::{Result, ScoreMode};

use crate::query::boolean::BoolQuery;
use crate::query::term::TermQuery;
use crate::query::{BoundQuery, Query};
use crate::search::searcher::Searcher;

/// Fuzzy query: find terms within Levenshtein edit distance.
pub struct FuzzyQuery {
    pub field: String,
    pub value: String,
    pub fuzziness: u32,
}

impl Query for FuzzyQuery {
    fn bind(&self, searcher: &Searcher, score_mode: ScoreMode) -> Result<Box<dyn BoundQuery>> {
        let max_dist = self.fuzziness.min(2) as u8;

        // Build the Levenshtein DFA and search the FST term dictionary.
        // The FST walks in lockstep with the DFA, pruning entire subtrees
        // where the DFA enters a dead state — O(matching terms) not O(all terms).
        let builder = LevenshteinAutomatonBuilder::new(max_dist, true);
        let dfa = builder.build_dfa(&self.value);

        let mut matching_terms: Vec<String> = Vec::new();
        for segment in searcher.segments() {
            let field_id = match segment
                .header()
                .fields
                .iter()
                .find(|f| f.field_name == self.field)
                .map(|f| f.field_id)
            {
                Some(id) => id,
                None => continue,
            };

            for (term, _) in segment.automaton_search(field_id, &dfa) {
                if !matching_terms.contains(&term) {
                    matching_terms.push(term);
                }
            }
        }

        if matching_terms.is_empty() {
            return crate::query::convert::MatchNoneQuery.bind(searcher, score_mode);
        }

        let should: Vec<Box<dyn Query>> = matching_terms
            .into_iter()
            .map(|term| -> Box<dyn Query> {
                Box::new(TermQuery {
                    field: self.field.clone(),
                    value: term,
                })
            })
            .collect();

        BoolQuery {
            must: vec![],
            should,
            must_not: vec![],
            filter: vec![],
        }
        .bind(searcher, score_mode)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::segment::builder::SegmentBuilder;
    use crate::segment::reader::SegmentReader;
    use luci_analysis::Token;
    use luci_core::{FieldId, SegmentId};
    use luci_mapping::{FieldType, Mapping};

    #[test]
    fn fuzzy_query_basic() {
        let schema = Mapping::builder().field("tag", FieldType::Keyword).build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);
        for tag in &["technology", "technlogy", "techology", "science", "tennis"] {
            builder.add_document(
                &[(FieldId::new(0), vec![Token::new(*tag, 0, tag.len(), 0)])],
                b"{}",
            );
        }
        let reader = SegmentReader::open(builder.build()).unwrap();
        let store = crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        );
        let searcher = Searcher::new(&store);

        let results = searcher.search_query(
            &FuzzyQuery {
                field: "tag".into(),
                value: "technology".into(),
                fuzziness: 1,
            },
            10,
            0,
        );
        assert_eq!(results.total_hits.value, 3); // technology (0), technlogy (1), techology (1)
    }

    #[test]
    fn fuzzy_query_fuzziness_2() {
        let schema = Mapping::builder().field("tag", FieldType::Keyword).build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);
        for tag in &["apple", "aple", "apples", "apply", "orange"] {
            builder.add_document(
                &[(FieldId::new(0), vec![Token::new(*tag, 0, tag.len(), 0)])],
                b"{}",
            );
        }
        let reader = SegmentReader::open(builder.build()).unwrap();
        let store = crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        );
        let searcher = Searcher::new(&store);

        let results = searcher.search_query(
            &FuzzyQuery {
                field: "tag".into(),
                value: "apple".into(),
                fuzziness: 2,
            },
            10,
            0,
        );
        // apple(0), aple(1), apples(1), apply(2)
        assert_eq!(results.total_hits.value, 4);
    }

    #[test]
    fn fuzzy_no_matches() {
        let schema = Mapping::builder().field("tag", FieldType::Keyword).build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);
        builder.add_document(
            &[(FieldId::new(0), vec![Token::new("hello", 0, 5, 0)])],
            b"{}",
        );
        let reader = SegmentReader::open(builder.build()).unwrap();
        let store = crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        );
        let searcher = Searcher::new(&store);

        let results = searcher.search_query(
            &FuzzyQuery {
                field: "tag".into(),
                value: "xyz".into(),
                fuzziness: 1,
            },
            10,
            0,
        );
        assert_eq!(results.total_hits.value, 0);
    }

    #[test]
    fn fuzzy_first_char_substitution() {
        // Test that fuzzy matches work even when the first character differs
        let schema = Mapping::builder().field("tag", FieldType::Keyword).build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);
        for tag in &["cat", "bat", "hat", "dog"] {
            builder.add_document(
                &[(FieldId::new(0), vec![Token::new(*tag, 0, tag.len(), 0)])],
                b"{}",
            );
        }
        let reader = SegmentReader::open(builder.build()).unwrap();
        let store = crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        );
        let searcher = Searcher::new(&store);

        let results = searcher.search_query(
            &FuzzyQuery {
                field: "tag".into(),
                value: "cat".into(),
                fuzziness: 1,
            },
            10,
            0,
        );
        // cat(0), bat(1), hat(1) — first-char substitution
        assert_eq!(results.total_hits.value, 3);
    }
}
