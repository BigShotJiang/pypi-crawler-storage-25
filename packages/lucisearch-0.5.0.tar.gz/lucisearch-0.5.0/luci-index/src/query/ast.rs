//! Query expression types — the output of JSON parsing and input to execution.
//!
//! See [[query-dsl]] and [[architecture-query-execution#Step 3]].

/// Configuration for inner_hits on nested queries.
/// See [[feature-search-inner-hits]].
#[derive(Clone, Debug, PartialEq)]
pub struct InnerHitsConfig {
    pub name: Option<String>,
    pub size: usize,
    pub from: usize,
}

/// Typed query expression. Each variant maps to an ES-compatible query type.
#[derive(Clone, Debug, PartialEq)]
pub enum QueryExpression {
    /// Exact term match on a field (no analysis).
    Term { field: String, value: String },

    /// Match any of a set of exact values.
    Terms { field: String, values: Vec<String> },

    /// Full-text match: analyze query text, build bool of term queries.
    Match {
        field: String,
        query: String,
        analyzer: Option<String>,
    },

    /// Phrase match: terms must appear in order at consecutive positions.
    MatchPhrase {
        field: String,
        query: String,
        analyzer: Option<String>,
    },

    /// Match bool prefix: analyzes text, all tokens become term queries
    /// except the last which becomes a prefix query. Rewrites to bool/should.
    MatchBoolPrefix {
        field: String,
        query: String,
        analyzer: Option<String>,
    },

    /// Boolean combination of sub-queries.
    Bool {
        must: Vec<QueryExpression>,
        should: Vec<QueryExpression>,
        must_not: Vec<QueryExpression>,
        filter: Vec<QueryExpression>,
    },

    /// Disjunction max: return the score from the best-matching sub-query,
    /// plus tie_breaker * sum of other matching scores.
    DisMax {
        queries: Vec<QueryExpression>,
        tie_breaker: f32,
    },

    /// Field exists (has a non-null value).
    Exists { field: String },

    /// Prefix match on a field's terms.
    Prefix { field: String, value: String },

    /// Wrap a query in filter context with a constant score.
    ConstantScore {
        query: Box<QueryExpression>,
        boost: f32,
    },

    /// Nested query: search within nested document arrays.
    Nested {
        path: String,
        query: Box<QueryExpression>,
        inner_hits: Option<InnerHitsConfig>,
    },

    /// Geographic distance query.
    GeoDistance {
        field: String,
        lat: f64,
        lon: f64,
        distance: String, // e.g. "10km"
    },

    /// Geographic bounding box query.
    GeoBoundingBox {
        field: String,
        top_left_lat: f64,
        top_left_lon: f64,
        bottom_right_lat: f64,
        bottom_right_lon: f64,
    },

    /// Geographic shape query with spatial relation.
    ///
    /// See [[feature-geo-shape]] and [[de-9im]].
    GeoShape {
        field: String,
        shape: GeoShapeValue,
        relation: SpatialRelation,
    },

    /// Numeric range query on a field.
    Range {
        field: String,
        gte: Option<f64>,
        gt: Option<f64>,
        lte: Option<f64>,
        lt: Option<f64>,
    },

    /// Boost wrapper: multiplies inner query's score by a factor.
    Boost {
        query: Box<QueryExpression>,
        boost: f32,
    },

    /// Script score: compiled expression-based custom scoring.
    ScriptScore {
        query: Box<QueryExpression>,
        script: String,
        params: std::collections::HashMap<String, f64>,
    },

    /// Function score: modify query scores with scoring functions.
    FunctionScore {
        query: Box<QueryExpression>,
        functions: Vec<ScoreFunction>,
        score_mode: FunctionScoreMode,
        boost_mode: FunctionBoostMode,
    },

    /// Boosting: positive query with score demotion for negative matches.
    Boosting {
        positive: Box<QueryExpression>,
        negative: Box<QueryExpression>,
        negative_boost: f32,
    },

    /// Fuzzy match: terms within edit distance.
    Fuzzy {
        field: String,
        value: String,
        fuzziness: u32,
    },

    /// Regexp match on term dictionary.
    Regexp { field: String, value: String },

    /// Wildcard match: * (any chars) and ? (single char).
    Wildcard { field: String, value: String },

    /// Multi-field match: search the same query across multiple fields.
    MultiMatch {
        fields: Vec<String>,
        query: String,
        analyzer: Option<String>,
    },

    /// Span term: single term with position awareness.
    SpanTerm { field: String, value: String },

    /// Span near: terms within slop positions, optionally ordered.
    SpanNear {
        field: String,
        terms: Vec<String>,
        slop: u32,
        in_order: bool,
    },

    /// Span not: include query minus exclude query.
    SpanNot {
        include: Box<QueryExpression>,
        exclude: Box<QueryExpression>,
    },

    /// Span first: match within first N positions.
    SpanFirst {
        query: Box<QueryExpression>,
        end: u32,
    },

    /// Match all documents.
    MatchAll,

    /// Match no documents.
    MatchNone,
}

/// A scoring function for function_score queries.
#[derive(Clone, Debug, PartialEq)]
pub enum ScoreFunction {
    /// Multiply score by a constant weight.
    Weight(f32),
    /// Score based on a numeric field's value.
    FieldValueFactor {
        field: String,
        factor: f32,
        modifier: FieldValueModifier,
        missing: f64,
    },
    /// Random score (deterministic per seed + doc).
    RandomScore { seed: u64 },
}

/// Modifier for field_value_factor.
#[derive(Clone, Debug, PartialEq)]
pub enum FieldValueModifier {
    None,
    Log1p,
    Log2p,
    Ln1p,
    Ln2p,
    Sqrt,
    Square,
    Reciprocal,
}

/// How to combine multiple function scores.
#[derive(Clone, Debug, PartialEq)]
pub enum FunctionScoreMode {
    Multiply,
    Sum,
    Avg,
    First,
    Max,
    Min,
}

/// How to combine the function result with the query score.
#[derive(Clone, Debug, PartialEq)]
pub enum FunctionBoostMode {
    Multiply,
    Replace,
    Sum,
    Avg,
    Max,
    Min,
}

/// Spatial relation for geo_shape queries.
///
/// Supports the full [[ogc-simple-features]] / [[de-9im]] predicate set.
#[derive(Clone, Debug, PartialEq)]
pub enum SpatialRelation {
    /// Query and document shapes share any area or boundary (default).
    Intersects,
    /// Document shape is entirely inside the query shape.
    Within,
    /// Document shape entirely contains the query shape.
    Contains,
    /// Query and document shapes share no area or boundary.
    Disjoint,
    /// Shapes meet at boundary but don't overlap interiors.
    Touches,
    /// Interiors intersect but neither contains the other.
    Crosses,
    /// Shared interior area, same dimension, neither contains the other.
    Overlaps,
    /// Geometries are topologically identical.
    Equals,
    /// Like Contains but includes boundary contact.
    Covers,
    /// Like Within but includes boundary contact.
    CoveredBy,
    /// Interior of document shape contains all of query shape (strict).
    ContainsProperly,
}

/// A parsed GeoJSON shape for use in geo_shape queries.
#[derive(Clone, Debug, PartialEq)]
pub struct GeoShapeValue {
    /// The raw GeoJSON shape object (type + coordinates).
    pub json: serde_json::Value,
}

impl QueryExpression {
    /// Convenience constructor for a bool query.
    pub fn bool_query(
        must: Vec<QueryExpression>,
        should: Vec<QueryExpression>,
        must_not: Vec<QueryExpression>,
        filter: Vec<QueryExpression>,
    ) -> Self {
        Self::Bool {
            must,
            should,
            must_not,
            filter,
        }
    }
}

impl super::Query for QueryExpression {
    /// Bind this query expression to index statistics, producing a BoundQuery.
    ///
    /// Recursively compiles the expression tree into executable form,
    /// binding to the Searcher's index-level statistics (IDF, avg field
    /// lengths, etc.). Each variant directly constructs the concrete query
    /// struct and binds it, bypassing the `ast_to_query` indirection.
    /// Sub-queries bind recursively via `QueryExpression::bind`.
    fn bind(
        &self,
        searcher: &crate::search::searcher::Searcher,
        score_mode: luci_core::ScoreMode,
    ) -> luci_core::Result<Box<dyn super::BoundQuery>> {
        match self {
            // --- Simple term-level queries ---
            QueryExpression::Term { field, value } => crate::query::term::TermQuery {
                field: field.clone(),
                value: value.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::Terms { field, values } => {
                // Rewrite to Bool { should: [Term * N] }
                let should: Vec<QueryExpression> = values
                    .iter()
                    .map(|v| QueryExpression::Term {
                        field: field.clone(),
                        value: v.clone(),
                    })
                    .collect();
                QueryExpression::Bool {
                    must: vec![],
                    should,
                    must_not: vec![],
                    filter: vec![],
                }
                .bind(searcher, score_mode)
            }

            // --- Full-text queries ---
            QueryExpression::Match {
                field,
                query,
                analyzer,
            } => crate::query::match_query::MatchQuery {
                field: field.clone(),
                query_text: query.clone(),
                analyzer: analyzer.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::MatchPhrase {
                field,
                query,
                analyzer,
            } => crate::query::phrase::MatchPhraseQuery {
                field: field.clone(),
                query_text: query.clone(),
                analyzer: analyzer.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::MatchBoolPrefix {
                field,
                query,
                analyzer,
            } => {
                // Rewrite: analyze text, all tokens -> term queries,
                // last -> prefix query, wrap in Bool/should.
                let registry = luci_analysis::AnalyzerRegistry::new();
                let analyzer_name = analyzer.as_deref().unwrap_or("standard");
                let analyzed = registry.get(analyzer_name).analyze(query);
                let tokens: Vec<String> = analyzed.into_iter().map(|t| t.text).collect();
                if tokens.is_empty() {
                    crate::query::convert::MatchNoneQuery.bind(searcher, score_mode)
                } else {
                    let mut should: Vec<QueryExpression> = Vec::new();
                    for (i, token) in tokens.iter().enumerate() {
                        if i == tokens.len() - 1 {
                            should.push(QueryExpression::Prefix {
                                field: field.clone(),
                                value: token.clone(),
                            });
                        } else {
                            should.push(QueryExpression::Term {
                                field: field.clone(),
                                value: token.clone(),
                            });
                        }
                    }
                    QueryExpression::Bool {
                        must: vec![],
                        should,
                        must_not: vec![],
                        filter: vec![],
                    }
                    .bind(searcher, score_mode)
                }
            }

            QueryExpression::MultiMatch {
                fields,
                query,
                analyzer,
            } => {
                // Rewrite to Bool { should: [Match per field] }
                let should: Vec<QueryExpression> = fields
                    .iter()
                    .map(|f| QueryExpression::Match {
                        field: f.clone(),
                        query: query.clone(),
                        analyzer: analyzer.clone(),
                    })
                    .collect();
                QueryExpression::Bool {
                    must: vec![],
                    should,
                    must_not: vec![],
                    filter: vec![],
                }
                .bind(searcher, score_mode)
            }

            // --- Compound queries (recursive) ---
            QueryExpression::Bool {
                must,
                should,
                must_not,
                filter,
            } => {
                // Construct BoolQuery with cloned sub-expressions as
                // Box<dyn Query>. BoolQuery::bind() will recursively call
                // QueryExpression::bind() on each child.
                crate::query::boolean::BoolQuery {
                    must: must
                        .iter()
                        .map(|q| -> Box<dyn super::Query> { Box::new(q.clone()) })
                        .collect(),
                    should: should
                        .iter()
                        .map(|q| -> Box<dyn super::Query> { Box::new(q.clone()) })
                        .collect(),
                    must_not: must_not
                        .iter()
                        .map(|q| -> Box<dyn super::Query> { Box::new(q.clone()) })
                        .collect(),
                    filter: filter
                        .iter()
                        .map(|q| -> Box<dyn super::Query> { Box::new(q.clone()) })
                        .collect(),
                }
                .bind(searcher, score_mode)
            }

            QueryExpression::DisMax {
                queries,
                tie_breaker,
            } => crate::query::dis_max::DisMaxQuery {
                queries: queries
                    .iter()
                    .map(|q| -> Box<dyn super::Query> { Box::new(q.clone()) })
                    .collect(),
                tie_breaker: *tie_breaker,
            }
            .bind(searcher, score_mode),

            QueryExpression::ConstantScore { query, boost } => {
                crate::query::constant_score::ConstantScoreQuery {
                    inner: Box::new(query.as_ref().clone()),
                    boost: *boost,
                }
                .bind(searcher, score_mode)
            }

            QueryExpression::Boost { query, boost } => crate::query::boost::BoostQuery {
                inner: Box::new(query.as_ref().clone()),
                boost: *boost,
            }
            .bind(searcher, score_mode),

            QueryExpression::Boosting {
                positive,
                negative,
                negative_boost,
            } => crate::query::boosting::BoostingQuery {
                positive: Box::new(positive.as_ref().clone()),
                negative: Box::new(negative.as_ref().clone()),
                negative_boost: *negative_boost,
            }
            .bind(searcher, score_mode),

            QueryExpression::ScriptScore {
                query,
                script,
                params,
            } => crate::query::script_score::ScriptScoreQuery {
                query: Box::new(query.as_ref().clone()),
                script: script.clone(),
                params: params.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::FunctionScore {
                query,
                functions,
                score_mode: fn_score_mode,
                boost_mode,
            } => crate::query::function_score::FunctionScoreQuery {
                query: Box::new(query.as_ref().clone()),
                functions: functions.clone(),
                score_mode: fn_score_mode.clone(),
                boost_mode: boost_mode.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::Nested {
                path,
                query,
                inner_hits,
            } => crate::query::nested::NestedQuery {
                path: path.clone(),
                inner: Box::new(query.as_ref().clone()),
                inner_hits: inner_hits.clone(),
            }
            .bind(searcher, score_mode),

            // --- Filter-context queries ---
            QueryExpression::Exists { field } => crate::query::exists::ExistsQuery {
                field: field.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::Prefix { field, value } => crate::query::prefix::PrefixQuery {
                field: field.clone(),
                value: value.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::Range {
                field,
                gte,
                gt,
                lte,
                lt,
            } => crate::query::range::RangeQuery {
                field: field.clone(),
                gte: *gte,
                gt: *gt,
                lte: *lte,
                lt: *lt,
            }
            .bind(searcher, score_mode),

            // --- Rewrite queries (scan term dict, then bind) ---
            QueryExpression::Fuzzy {
                field,
                value,
                fuzziness,
            } => crate::query::fuzzy::FuzzyQuery {
                field: field.clone(),
                value: value.clone(),
                fuzziness: *fuzziness,
            }
            .bind(searcher, score_mode),

            QueryExpression::Wildcard { field, value } => crate::query::wildcard::WildcardQuery {
                field: field.clone(),
                pattern: value.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::Regexp { field, value } => crate::query::regexp::RegexpQuery {
                field: field.clone(),
                pattern: value.clone(),
            }
            .bind(searcher, score_mode),

            // --- Geo queries ---
            QueryExpression::GeoDistance {
                field,
                lat,
                lon,
                distance,
            } => {
                let distance_km = crate::query::parser::parse_distance_km(distance);
                crate::spatial::query::GeoDistanceQuery {
                    field: field.clone(),
                    center: crate::spatial::geo::GeoPoint::new(*lat, *lon),
                    distance_km,
                }
                .bind(searcher, score_mode)
            }

            QueryExpression::GeoBoundingBox {
                field,
                top_left_lat,
                top_left_lon,
                bottom_right_lat,
                bottom_right_lon,
            } => crate::spatial::query::GeoBoundingBoxQuery {
                field: field.clone(),
                top_left: crate::spatial::geo::GeoPoint::new(*top_left_lat, *top_left_lon),
                bottom_right: crate::spatial::geo::GeoPoint::new(
                    *bottom_right_lat,
                    *bottom_right_lon,
                ),
            }
            .bind(searcher, score_mode),

            QueryExpression::GeoShape {
                field,
                shape,
                relation,
            } => {
                let query_geom = crate::spatial::shape::parse_geojson(&shape.json)
                    .unwrap_or(::geo::Geometry::Point(::geo::Point::new(0.0, 0.0)));
                let query_bbox = crate::spatial::shape::compute_bbox(&query_geom)
                    .unwrap_or((0.0, 0.0, 0.0, 0.0));
                crate::spatial::query::GeoShapeQuery {
                    field: field.clone(),
                    query_shape: query_geom,
                    query_bbox,
                    relation: relation.clone(),
                }
                .bind(searcher, score_mode)
            }

            // --- Span queries ---
            QueryExpression::SpanTerm { field, value } => crate::query::span::SpanTermQuery {
                field: field.clone(),
                value: value.clone(),
            }
            .bind(searcher, score_mode),

            QueryExpression::SpanNear {
                field,
                terms,
                slop,
                in_order,
            } => crate::query::span::SpanNearQuery {
                field: field.clone(),
                terms: terms.clone(),
                slop: *slop,
                in_order: *in_order,
            }
            .bind(searcher, score_mode),

            QueryExpression::SpanNot { include, exclude } => crate::query::span::SpanNotQuery {
                include: Box::new(include.as_ref().clone()),
                exclude: Box::new(exclude.as_ref().clone()),
            }
            .bind(searcher, score_mode),

            QueryExpression::SpanFirst { query, end } => crate::query::span::SpanFirstQuery {
                inner: Box::new(query.as_ref().clone()),
                end: *end,
            }
            .bind(searcher, score_mode),

            // --- Terminal queries ---
            QueryExpression::MatchAll => {
                crate::query::convert::MatchAllQuery.bind(searcher, score_mode)
            }

            QueryExpression::MatchNone => {
                crate::query::convert::MatchNoneQuery.bind(searcher, score_mode)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn term_query() {
        let q = QueryExpression::Term {
            field: "status".into(),
            value: "active".into(),
        };
        assert_eq!(
            q,
            QueryExpression::Term {
                field: "status".into(),
                value: "active".into()
            }
        );
    }

    #[test]
    fn bool_query_construction() {
        let q = QueryExpression::bool_query(
            vec![QueryExpression::Term {
                field: "f".into(),
                value: "v".into(),
            }],
            vec![],
            vec![],
            vec![],
        );
        if let QueryExpression::Bool { must, .. } = &q {
            assert_eq!(must.len(), 1);
        } else {
            panic!("expected Bool");
        }
    }

    #[test]
    fn nested_bool() {
        let inner =
            QueryExpression::bool_query(vec![QueryExpression::MatchAll], vec![], vec![], vec![]);
        let outer = QueryExpression::bool_query(vec![inner], vec![], vec![], vec![]);
        if let QueryExpression::Bool { must, .. } = &outer {
            assert!(matches!(&must[0], QueryExpression::Bool { .. }));
        }
    }

    #[test]
    fn constant_score_wraps() {
        let q = QueryExpression::ConstantScore {
            query: Box::new(QueryExpression::Term {
                field: "f".into(),
                value: "v".into(),
            }),
            boost: 1.5,
        };
        if let QueryExpression::ConstantScore { boost, .. } = q {
            assert_eq!(boost, 1.5);
        }
    }

    #[test]
    fn match_query() {
        let q = QueryExpression::Match {
            field: "body".into(),
            query: "search engine".into(),
            analyzer: None,
        };
        if let QueryExpression::Match { field, query, .. } = &q {
            assert_eq!(field, "body");
            assert_eq!(query, "search engine");
        }
    }

    #[test]
    fn debug_format() {
        let q = QueryExpression::MatchAll;
        let s = format!("{q:?}");
        assert!(s.contains("MatchAll"));
    }

    #[test]
    fn clone_works() {
        let q = QueryExpression::Term {
            field: "f".into(),
            value: "v".into(),
        };
        let q2 = q.clone();
        assert_eq!(q, q2);
    }

    #[test]
    fn terms_query() {
        let q = QueryExpression::Terms {
            field: "tags".into(),
            values: vec!["a".into(), "b".into(), "c".into()],
        };
        if let QueryExpression::Terms { values, .. } = &q {
            assert_eq!(values.len(), 3);
        }
    }
}
