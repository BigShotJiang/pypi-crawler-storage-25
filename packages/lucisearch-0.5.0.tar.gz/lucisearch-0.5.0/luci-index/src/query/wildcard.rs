//! Wildcard query: match terms using * (any chars) and ? (single char).
//!
//! Compiles the wildcard pattern into a regex, then uses the `regex`
//! crate's DFA for O(term_length) matching per term. No recursive
//! backtracking.
//!
//! See [[elasticsearch-parity]] and [[optimization-wildcard-fuzzy-queries]].

use luci_core::{Result, ScoreMode};
use regex::Regex;

use crate::query::boolean::BoolQuery;
use crate::query::term::TermQuery;
use crate::query::{BoundQuery, Query};
use crate::search::searcher::Searcher;

/// Wildcard query: * matches any sequence, ? matches single character.
pub struct WildcardQuery {
    pub field: String,
    pub pattern: String,
}

impl WildcardQuery {
    /// Check if a term matches the wildcard pattern (for tests).
    pub fn matches(pattern: &str, term: &str) -> bool {
        let regex_pattern = wildcard_to_regex(pattern);
        Regex::new(&regex_pattern)
            .map(|re| re.is_match(term))
            .unwrap_or(false)
    }

    /// Extract a prefix before the first wildcard character.
    fn prefix(pattern: &str) -> &str {
        match pattern.find(|c| c == '*' || c == '?') {
            Some(pos) => &pattern[..pos],
            None => pattern,
        }
    }
}

/// Convert a wildcard pattern to a regex pattern.
/// `*` → `.*`, `?` → `.`, other chars are escaped.
fn wildcard_to_regex(pattern: &str) -> String {
    let mut regex = String::with_capacity(pattern.len() * 2 + 2);
    regex.push('^');
    for ch in pattern.chars() {
        match ch {
            '*' => regex.push_str(".*"),
            '?' => regex.push('.'),
            '.' | '+' | '(' | ')' | '[' | ']' | '{' | '}' | '\\' | '^' | '$' | '|' => {
                regex.push('\\');
                regex.push(ch);
            }
            _ => regex.push(ch),
        }
    }
    regex.push('$');
    regex
}

impl Query for WildcardQuery {
    fn bind(&self, searcher: &Searcher, score_mode: ScoreMode) -> Result<Box<dyn BoundQuery>> {
        let prefix = Self::prefix(&self.pattern);

        // Compile the wildcard pattern into a regex DFA — O(pattern_length)
        let regex_pattern = wildcard_to_regex(&self.pattern);
        let re = Regex::new(&regex_pattern).map_err(|e| {
            luci_core::LuciError::InvalidQuery(format!("invalid wildcard pattern: {e}"))
        })?;

        let mut matching_terms: Vec<String> = Vec::new();

        for segment in searcher.segments() {
            let field_id = match segment
                .header()
                .fields
                .iter()
                .find(|f| f.field_name == self.field)
                .map(|f| f.field_id)
            {
                Some(id) => id,
                None => continue,
            };

            // Use prefix to narrow scan for trailing wildcards (tech*)
            for (term, _) in segment.terms_with_prefix(field_id, prefix) {
                if re.is_match(&term) && !matching_terms.contains(&term) {
                    matching_terms.push(term);
                }
            }
        }

        if matching_terms.is_empty() {
            return crate::query::convert::MatchNoneQuery.bind(searcher, score_mode);
        }

        let should: Vec<Box<dyn Query>> = matching_terms
            .into_iter()
            .map(|term| -> Box<dyn Query> {
                Box::new(TermQuery {
                    field: self.field.clone(),
                    value: term,
                })
            })
            .collect();

        BoolQuery {
            must: vec![],
            should,
            must_not: vec![],
            filter: vec![],
        }
        .bind(searcher, score_mode)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::segment::builder::SegmentBuilder;
    use crate::segment::reader::SegmentReader;
    use luci_analysis::Token;
    use luci_core::{FieldId, SegmentId};
    use luci_mapping::{FieldType, Mapping};

    #[test]
    fn wildcard_matching() {
        assert!(WildcardQuery::matches("tech*", "technology"));
        assert!(WildcardQuery::matches("tech*", "tech"));
        assert!(!WildcardQuery::matches("tech*", "tec"));
        assert!(WildcardQuery::matches("t?ch", "tech"));
        assert!(!WildcardQuery::matches("t?ch", "touch"));
        assert!(WildcardQuery::matches("*fox*", "quick fox jumps"));
        assert!(WildcardQuery::matches("*", "anything"));
        assert!(WildcardQuery::matches("?", "x"));
        assert!(!WildcardQuery::matches("?", ""));
        assert!(WildcardQuery::matches("a*b", "ab"));
        assert!(WildcardQuery::matches("a*b", "aXYZb"));
        assert!(!WildcardQuery::matches("a*b", "aXYZc"));
    }

    #[test]
    fn prefix_extraction() {
        assert_eq!(WildcardQuery::prefix("tech*"), "tech");
        assert_eq!(WildcardQuery::prefix("t?ch"), "t");
        assert_eq!(WildcardQuery::prefix("*fox"), "");
        assert_eq!(WildcardQuery::prefix("exact"), "exact");
    }

    fn make_tokens(terms: &[&str]) -> Vec<Token> {
        terms
            .iter()
            .enumerate()
            .map(|(i, t)| Token::new(*t, 0, t.len(), i as u32))
            .collect()
    }

    #[test]
    fn wildcard_query_star() {
        let schema = Mapping::builder().field("tag", FieldType::Keyword).build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);
        for tag in &["technology", "technical", "tennis", "science"] {
            builder.add_document(
                &[(FieldId::new(0), vec![Token::new(*tag, 0, tag.len(), 0)])],
                b"{}",
            );
        }
        let reader = SegmentReader::open(builder.build()).unwrap();
        let store = crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        );
        let searcher = Searcher::new(&store);

        let results = searcher.search_query(
            &WildcardQuery {
                field: "tag".into(),
                pattern: "tech*".into(),
            },
            10,
            0,
        );
        assert_eq!(results.total_hits.value, 2); // technology, technical
    }

    #[test]
    fn wildcard_query_question_mark() {
        let schema = Mapping::builder().field("tag", FieldType::Keyword).build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);
        for tag in &["cat", "cut", "cot", "cart"] {
            builder.add_document(
                &[(FieldId::new(0), vec![Token::new(*tag, 0, tag.len(), 0)])],
                b"{}",
            );
        }
        let reader = SegmentReader::open(builder.build()).unwrap();
        let store = crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        );
        let searcher = Searcher::new(&store);

        let results = searcher.search_query(
            &WildcardQuery {
                field: "tag".into(),
                pattern: "c?t".into(),
            },
            10,
            0,
        );
        assert_eq!(results.total_hits.value, 3); // cat, cut, cot (not cart — 4 chars)
    }

    #[test]
    fn wildcard_no_matches() {
        let schema = Mapping::builder().field("tag", FieldType::Keyword).build();
        let mut builder = SegmentBuilder::new(SegmentId::new(1), &schema);
        builder.add_document(
            &[(FieldId::new(0), vec![Token::new("hello", 0, 5, 0)])],
            b"{}",
        );
        let reader = SegmentReader::open(builder.build()).unwrap();
        let store = crate::search::segment_store::SegmentStore::new(
            vec![reader],
            luci_analysis::AnalyzerRegistry::new(),
            None,
        );
        let searcher = Searcher::new(&store);

        let results = searcher.search_query(
            &WildcardQuery {
                field: "tag".into(),
                pattern: "xyz*".into(),
            },
            10,
            0,
        );
        assert_eq!(results.total_hits.value, 0);
    }
}
