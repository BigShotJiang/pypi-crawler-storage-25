//! Document store: LZ4-compressed storage for original JSON source.
//!
//! See [[document-store]] and [[architecture-segment-layout]].

pub mod doc_store;
