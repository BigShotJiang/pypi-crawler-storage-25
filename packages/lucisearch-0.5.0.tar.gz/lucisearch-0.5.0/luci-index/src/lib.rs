// Obsidian [[wikilinks]] in doc comments are intentional — they link to
// design and reference docs in docs/. Rustdoc doesn't understand them.
#![allow(rustdoc::broken_intra_doc_links)]

//! `luci-index` — inverted index, document store, and search engine.
//!
//! This crate implements [[architecture-overview|milestone-1]]: indexing JSON documents, searching
//! with term queries, BM25 scoring, and segment merge. It builds on
//! `luci-core` (types/traits), `luci-schema` (field mappings),
//! `luci-analysis` (text analysis), and `luci-storage` (persistence).
//!
//! See [[architecture-overview]] and [[architecture-segment-layout]] for the design.

pub mod agg;
pub mod columnar;
pub mod inverted;
pub mod ip;
pub mod query;
pub mod search;
pub mod segment;
pub mod spatial;
pub mod store;
pub mod vector;

pub mod deletion;
pub mod index;
pub mod merge;
pub mod merge_policy;
pub mod reader;
pub mod writer;

/// Configure the global thread pool for parallel search.
///
/// Must be called before any search operation. Can only be called once
/// per process — subsequent calls return an error.
///
/// If not called, rayon defaults to the number of available CPUs
/// (or the `RAYON_NUM_THREADS` environment variable).
pub fn set_num_threads(num_threads: usize) -> luci_core::Result<()> {
    rayon::ThreadPoolBuilder::new()
        .num_threads(num_threads)
        .build_global()
        .map_err(|e| luci_core::LuciError::InvalidQuery(format!("failed to set thread pool: {e}")))
}
