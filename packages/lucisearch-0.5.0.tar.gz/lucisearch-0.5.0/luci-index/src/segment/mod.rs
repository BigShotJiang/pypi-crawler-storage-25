//! Segment format, builder, and reader.
//!
//! See [[architecture-segment-layout]] and [[architecture-indexing-pipeline]].

pub mod builder;
pub mod format;
pub mod reader;
