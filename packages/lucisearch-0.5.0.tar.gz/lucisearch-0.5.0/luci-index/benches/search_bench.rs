//! Pure Rust benchmarks for Luci search operations.
//!
//! Mirrors bench/bench.py's query set and corpus but measures the Rust API
//! directly — no Python SDK overhead. Each query is measured in two modes:
//!
//! - `search` — full materialization via `Index.search()` (source + fields)
//! - `search_lazy` — scoring only via `Index.search_lazy()` (no source/fields)
//!
//! Run: `cargo bench -p luci-index`
//!
//! See [[architecture-scoring-materialization-separation]] and
//! [[architecture-benchmark-methodology]].

use criterion::{Criterion, black_box, criterion_group, criterion_main};

use luci_index::index::Index;
use luci_mapping::{FieldType, Mapping};
use serde_json::json;

use std::path::PathBuf;

const DOC_COUNT: usize = 100_000;

// --- Corpus (matches bench/corpus.py exactly) ---

fn bench_dir() -> PathBuf {
    let dir = std::env::temp_dir().join("luci_criterion_bench");
    dir
}

fn bench_schema() -> Mapping {
    Mapping::builder()
        .field("title", FieldType::Text)
        .field("body", FieldType::Text)
        .field("tag", FieldType::Keyword)
        .field("category", FieldType::Keyword)
        .field("price", FieldType::Float)
        .field("location", FieldType::GeoPoint)
        .field("boundary", FieldType::GeoShape)
        .field("offers", FieldType::Nested)
        .field("offers.seller", FieldType::Keyword)
        .field("offers.price", FieldType::Keyword)
        .field("embedding", FieldType::DenseVector { dims: 32 })
        .build()
}

fn pseudo_random(seed: u64) -> f64 {
    let x = (seed
        .wrapping_mul(6364136223846793005)
        .wrapping_add(1442695040888963407)
        >> 33)
        & 0xFFFFFFFF;
    x as f64 / 0xFFFFFFFF_u64 as f64
}

fn make_vector(i: usize, dims: usize) -> Vec<f64> {
    let raw: Vec<f64> = (0..dims)
        .map(|d| pseudo_random((i * dims + d) as u64) * 2.0 - 1.0)
        .collect();
    let norm: f64 = raw.iter().map(|x| x * x).sum::<f64>().sqrt();
    if norm > 0.0 {
        raw.iter().map(|x| (x / norm * 1e6).round() / 1e6).collect()
    } else {
        raw
    }
}

static TOPICS: &[&str] = &[
    "technology",
    "science",
    "sports",
    "politics",
    "entertainment",
];
static SUBTOPICS: &[&str] = &[
    "artificial intelligence",
    "machine learning",
    "quantum computing",
    "climate change",
    "renewable energy",
    "space exploration",
    "football",
    "basketball",
    "tennis",
    "elections",
    "policy",
    "legislation",
    "movies",
    "music",
    "gaming",
];
static CITIES: &[(f64, f64)] = &[
    (40.7128, -74.0060),
    (51.5074, -0.1278),
    (48.8566, 2.3522),
    (35.6762, 139.6503),
    (-33.8688, 151.2093),
];
static SELLERS: &[&str] = &["alice", "bob", "charlie", "diana", "eve"];

fn generate_doc(i: usize) -> serde_json::Value {
    let topic = TOPICS[i % TOPICS.len()];
    let subtopic = SUBTOPICS[i % SUBTOPICS.len()];
    let cat = format!("cat_{}", i % 50);
    let (base_lat, base_lon) = CITIES[i % CITIES.len()];

    let lat_jitter = (pseudo_random(i as u64 * 2) - 0.5) * 0.5;
    let lon_jitter = (pseudo_random(i as u64 * 2 + 1) - 0.5) * 0.5;
    let lat = ((base_lat + lat_jitter) * 10000.0).round() / 10000.0;
    let lon = ((base_lon + lon_jitter) * 10000.0).round() / 10000.0;
    let r = 0.01 + pseudo_random(i as u64 * 3 + 99) * 0.09;

    let num_offers = (i % 3) + 1;
    let offers: Vec<serde_json::Value> = (0..num_offers)
        .map(|j| {
            json!({
                "seller": SELLERS[(i + j) % SELLERS.len()],
                "price": format!("{}", (i * 10 + j * 100) % 1000),
            })
        })
        .collect();

    json!({
        "title": format!("document {i} about {topic} topics"),
        "body": format!(
            "this is the body text for document {i} covering {topic} \
             related content and discussions about {subtopic} \
             in the field of {cat} research and development"
        ),
        "tag": topic,
        "category": cat,
        "price": ((i % 1000) as f64 + 0.99 * 100.0).round() / 100.0,
        "location": {"lat": lat, "lon": lon},
        "boundary": {
            "type": "Polygon",
            "coordinates": [[
                [(lon - r * 10000.0).round() / 10000.0, (lat - r * 10000.0).round() / 10000.0],
                [(lon + r * 10000.0).round() / 10000.0, (lat - r * 10000.0).round() / 10000.0],
                [(lon + r * 10000.0).round() / 10000.0, (lat + r * 10000.0).round() / 10000.0],
                [(lon - r * 10000.0).round() / 10000.0, (lat + r * 10000.0).round() / 10000.0],
                [(lon - r * 10000.0).round() / 10000.0, (lat - r * 10000.0).round() / 10000.0],
            ]],
        },
        "offers": offers,
        "embedding": make_vector(i, 32),
    })
}

/// Build the benchmark index. Reuses an existing index on disk if present.
fn build_bench_index() -> (PathBuf, Index) {
    let path = bench_dir();
    // Reuse if already built (same process or previous run)
    if path.exists() {
        if let Ok(index) = Index::open(&path) {
            return (path, index);
        }
        let _ = std::fs::remove_dir_all(&path);
    }
    let mut index = Index::create_with_mapping(&path, bench_schema()).unwrap();
    let docs: Vec<serde_json::Value> = (0..DOC_COUNT).map(generate_doc).collect();
    index.bulk(docs).unwrap();
    (path, index)
}

// --- Benchmark helpers ---

/// Benchmark a query via Index.search() (scoring only, no content materialization).
macro_rules! bench_query {
    ($group:expr, $index:expr, $name:expr, $query:expr) => {
        let query_json = $query;
        $group.bench_function($name, |b| {
            let expr =
                luci_index::search::expression::parse_search(query_json.clone(), 10).unwrap();
            b.iter(|| {
                let r = $index.search(black_box(&expr)).unwrap();
                black_box(r.total_hits().value);
            });
        });
    };
}

// --- Query groups ---

fn bench_keyword(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("keyword");
    bench_query!(
        g,
        &mut index,
        "term",
        json!({"term": {"tag": "technology"}})
    );
    bench_query!(
        g,
        &mut index,
        "terms",
        json!({"terms": {"tag": ["technology", "science"]}})
    );
    bench_query!(
        g,
        &mut index,
        "exists",
        json!({"exists": {"field": "price"}})
    );
    bench_query!(g, &mut index, "prefix", json!({"prefix": {"tag": "tech"}}));
    bench_query!(
        g,
        &mut index,
        "wildcard",
        json!({"wildcard": {"tag": "tech*"}})
    );
    bench_query!(
        g,
        &mut index,
        "regexp",
        json!({"regexp": {"tag": "sci.*ce"}})
    );
    bench_query!(
        g,
        &mut index,
        "fuzzy",
        json!({"fuzzy": {"tag": {"value": "technoogy", "fuzziness": 1}}})
    );
    g.finish();
}

fn bench_text(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("text");
    bench_query!(
        g,
        &mut index,
        "match_single",
        json!({"match": {"title": "technology"}})
    );
    bench_query!(
        g,
        &mut index,
        "match_multi",
        json!({"match": {"title": "document technology topics"}})
    );
    bench_query!(
        g,
        &mut index,
        "multi_match",
        json!({"multi_match": {"query": "document technology", "fields": ["title", "body"]}})
    );
    bench_query!(
        g,
        &mut index,
        "match_phrase",
        json!({"match_phrase": {"body": "related content"}})
    );
    bench_query!(g, &mut index, "match_all", json!({"match_all": {}}));
    g.finish();
}

fn bench_bool(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("bool");
    bench_query!(
        g,
        &mut index,
        "must+filter",
        json!({"bool": {"must": [{"match": {"title": "document"}}], "filter": [{"term": {"tag": "science"}}]}})
    );
    bench_query!(
        g,
        &mut index,
        "must_not",
        json!({"bool": {"must": [{"match": {"title": "document"}}], "must_not": [{"term": {"tag": "sports"}}]}})
    );
    bench_query!(
        g,
        &mut index,
        "should",
        json!({"bool": {"should": [{"term": {"tag": "technology"}}, {"term": {"tag": "science"}}]}})
    );
    g.finish();
}

fn bench_agg(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("agg");
    bench_query!(
        g,
        &mut index,
        "terms_agg",
        json!({"query": {"match_all": {}}, "aggs": {"by_tag": {"terms": {"field": "tag"}}}, "size": 0})
    );
    bench_query!(
        g,
        &mut index,
        "avg_agg",
        json!({"query": {"match_all": {}}, "aggs": {"avg_price": {"avg": {"field": "price"}}}, "size": 0})
    );
    bench_query!(
        g,
        &mut index,
        "query+agg",
        json!({"query": {"term": {"tag": "technology"}}, "aggs": {"avg_price": {"avg": {"field": "price"}}}, "size": 0})
    );
    g.finish();
}

fn bench_range(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("range");
    bench_query!(
        g,
        &mut index,
        "narrow",
        json!({"range": {"price": {"gte": 100, "lt": 110}}})
    );
    bench_query!(
        g,
        &mut index,
        "wide",
        json!({"range": {"price": {"gte": 0, "lte": 500}}})
    );
    bench_query!(
        g,
        &mut index,
        "bool_range+term",
        json!({"bool": {"must": [{"term": {"tag": "technology"}}], "filter": [{"range": {"price": {"gte": 50, "lt": 200}}}]}})
    );
    g.finish();
}

fn bench_sort(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("sort");
    bench_query!(
        g,
        &mut index,
        "numeric",
        json!({"query": {"match_all": {}}, "sort": ["price"], "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "keyword",
        json!({"query": {"match_all": {}}, "sort": [{"tag": "asc"}], "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "score",
        json!({"query": {"match": {"title": "document"}}, "sort": ["_score"], "size": 10})
    );
    g.finish();
}

fn bench_features(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("features");
    bench_query!(
        g,
        &mut index,
        "source_full",
        json!({"query": {"match": {"title": "document"}}, "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "source_disabled",
        json!({"query": {"match": {"title": "document"}}, "_source": false, "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "fields_only",
        json!({"query": {"match": {"title": "document"}}, "fields": ["tag", "price"], "_source": false, "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "collapse",
        json!({"query": {"match_all": {}}, "collapse": {"field": "tag"}, "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "explain",
        json!({"query": {"match": {"title": "document"}}, "explain": true, "size": 10})
    );
    g.finish();
}

fn bench_pagination(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("pagination");
    bench_query!(
        g,
        &mut index,
        "from_0",
        json!({"query": {"match": {"title": "document"}}, "from": 0, "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "from_100",
        json!({"query": {"match": {"title": "document"}}, "from": 100, "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "from_1000",
        json!({"query": {"match": {"title": "document"}}, "from": 1000, "size": 10})
    );
    g.finish();
}

fn bench_span(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("span");
    bench_query!(
        g,
        &mut index,
        "term",
        json!({"span_term": {"body": "content"}})
    );
    bench_query!(
        g,
        &mut index,
        "near",
        json!({"span_near": {"clauses": [{"span_term": {"body": "related"}}, {"span_term": {"body": "content"}}], "slop": 1, "in_order": true}})
    );
    g.finish();
}

fn bench_nested(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("nested");
    bench_query!(
        g,
        &mut index,
        "term",
        json!({"nested": {"path": "offers", "query": {"term": {"offers.seller": "alice"}}}})
    );
    bench_query!(
        g,
        &mut index,
        "bool",
        json!({"nested": {"path": "offers", "query": {"bool": {"must": [{"term": {"offers.seller": "alice"}}, {"term": {"offers.price": "100"}}]}}}})
    );
    g.finish();
}

fn bench_highlight(c: &mut Criterion) {
    let (_path, mut index) = build_bench_index();
    let mut g = c.benchmark_group("highlight");
    bench_query!(
        g,
        &mut index,
        "single",
        json!({"query": {"match": {"title": "document"}}, "highlight": {"fields": {"title": {}}}, "size": 10})
    );
    bench_query!(
        g,
        &mut index,
        "multi_field",
        json!({"query": {"match": {"body": "related content"}}, "highlight": {"fields": {"title": {}, "body": {}}}, "size": 10})
    );
    g.finish();
}

criterion_group!(
    benches,
    bench_keyword,
    bench_text,
    bench_bool,
    bench_agg,
    bench_range,
    bench_sort,
    bench_features,
    bench_pagination,
    bench_span,
    bench_nested,
    bench_highlight,
);
criterion_main!(benches);
