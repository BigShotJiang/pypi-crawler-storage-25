"""Type stubs for the native _luci extension module."""

from typing import Self

def set_num_threads(num_threads: int) -> None:
    """Configure parallel search threads.

    Must be called before any search. Once per process.
    """

class Index:
    @staticmethod
    def create(
        path: str,
        mapping: dict[str, object] | None = None,
        memory_budget: int | None = None,
        write_timeout: float | None = None,
    ) -> Index:
        """Create a new index.

        Args:
            path: File path for the index.
            mapping: Optional ES-compatible mapping dict.
            memory_budget: Memory budget in bytes before auto-flush.
            write_timeout: Cross-process write lock timeout in seconds.

        """
    @staticmethod
    def open(
        path: str,
        memory_budget: int | None = None,
        write_timeout: float | None = None,
    ) -> Index:
        """Open an existing index. Mappings are loaded from the index file."""
    def add(self, doc: dict[str, object], write_timeout: float | None = None) -> None:
        """Add a single document. Auto-commits. For multiple docs, use bulk()."""
    def bulk(
        self,
        docs: list[dict[str, object]],
        write_timeout: float | None = None,
    ) -> dict[str, object]:
        """Add multiple documents in one call. Returns ``{"took": ms, "count": n}``."""
    def force_merge(self, max_segments: int = 1) -> None:
        """Force-merge segments. Call after bulk indexing for query performance."""
    def search(self, query: dict[str, object], size: int = 10) -> SearchResults:
        """Search the index. Returns lazy SearchResults."""
    def get(self, id: str) -> dict[str, object] | None:
        """Get a document by its _id. Returns None if not found."""
    def delete(self, id: str) -> bool:
        """Delete a document by its _id. Returns True if found and deleted."""
    def update(self, id: str, doc: dict[str, object]) -> bool:
        """Update a document by its _id with a partial doc merge."""
    def delete_by_query(self, query: dict[str, object]) -> int:
        """Delete all documents matching a query. Returns count deleted."""
    def count(self, query: dict[str, object]) -> int:
        """Count documents matching a query."""
    def buffered_doc_count(self) -> int:
        """Return the number of buffered (uncommitted) documents."""
    def set_write_timeout(self, timeout_secs: float = 5.0) -> None:
        """Set the cross-process write lock timeout in seconds."""
    def transaction(self) -> Transaction:
        """Create a transaction for batched writes with explicit commit control."""

class Transaction:
    """Sync transaction context manager for batched writes."""

    def add(self, doc: dict[str, object]) -> None:
        """Add a document to the transaction buffer."""
    def __enter__(self) -> Self: ...
    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> bool: ...

class SearchResults:
    """Lazy search results. Access via dict-style keys."""

    def __getitem__(self, key: str) -> object: ...
    def __len__(self) -> int: ...
    def __iter__(self) -> object: ...

class SearchHit:
    """A single search hit with lazy content access."""

    def __getitem__(self, key: str) -> object: ...
