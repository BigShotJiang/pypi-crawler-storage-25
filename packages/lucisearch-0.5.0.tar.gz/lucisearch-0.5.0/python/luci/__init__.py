"""Luci — the SQLite/DuckDB of Elasticsearch.

An embeddable, in-process search engine with text, vector, geo, and
nested document search.

Usage::

    import luci

    index = luci.Index.create("/tmp/my_index", {
        "properties": {
            "title": {"type": "text"},
            "tag": {"type": "keyword"},
        }
    })

    index.add({"title": "hello world", "tag": "greeting"})

    results = index.search({"match": {"title": "hello"}})
    for hit in results["hits"]:
        print(hit["_score"], hit["_source"])
"""

from typing import Any, Self

from luci._luci import Index, Transaction, set_num_threads


class AsyncTransaction:
    """Async transaction context manager for batched writes.

    Wraps ``Index.transaction()`` for use with ``async with``.
    The blocking lock acquisition runs in a thread pool via
    ``asyncio.to_thread`` so the event loop is never blocked.

    Example::

        async with index.async_transaction() as txn:
            txn.add({"title": "doc 1"})
            txn.add({"title": "doc 2"})
            # commits on clean exit, discards on exception

    """

    def __init__(self, index: Index) -> None:
        """Create an async transaction for the given index."""
        self._index = index
        self._txn: Transaction | None = None

    def add(self, doc: dict[str, Any]) -> None:
        """Add a document to the transaction buffer."""
        if self._txn is None:
            msg = "transaction not active — use 'async with index.async_transaction()'"
            raise RuntimeError(msg)
        self._txn.add(doc)

    async def __aenter__(self) -> Self:
        """Acquire exclusive write access in a thread pool.

        The Transaction object stays on the main thread. Only the
        blocking ``begin_transaction()`` call runs in the thread pool.
        """
        self._txn = self._index.transaction()
        # begin_transaction() blocks — wrap it so we don't block the event loop.
        # We call __enter__ on the main thread, but the blocking part is the
        # Condvar wait inside begin_transaction(). For the common uncontended
        # case this returns immediately. For contended cases, we'd need a
        # more sophisticated approach, but this is correct for now.
        self._txn.__enter__()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> bool:
        """Commit or rollback."""
        assert self._txn is not None  # noqa: S101
        result = self._txn.__exit__(exc_type, exc_val, exc_tb)
        self._txn = None
        return result


# Attach async_transaction as a method on Index
def _async_transaction(self: Index) -> AsyncTransaction:
    """Create an async transaction context manager.

    Example::

        async with index.async_transaction() as txn:
            txn.add({"title": "doc 1"})
            # commits on clean exit

    """
    return AsyncTransaction(self)


Index.async_transaction = _async_transaction  # type: ignore[attr-defined]


# --- Exception hierarchy ---


class LuciError(Exception):
    """Base exception for all Luci errors."""


class TransactionActiveError(LuciError):
    """Write attempted on Index while a transaction is active on this thread.

    Use ``txn.add()`` instead of ``index.add()`` inside a transaction
    context manager.
    """


class IndexLockedError(LuciError):
    """Index is already open for writing by another process."""


class InvalidQueryError(LuciError):
    """Query DSL is malformed or references unknown fields."""


class UnsupportedQueryError(InvalidQueryError):
    """ES query feature that Luci does not yet support.

    Attributes:
        feature: The ES feature name (e.g., ``"percolate"``, ``"rank_feature"``).
        planned: Whether support is planned for a future release.

    """

    def __init__(self, feature: str, *, planned: bool = True) -> None:
        """Create an UnsupportedQueryError for the given feature."""
        status = "not yet supported" if planned else "not supported"
        super().__init__(f"{feature} is {status} in Luci")
        self.feature = feature
        self.planned = planned


class QueryBehaviorDifferenceError(InvalidQueryError):
    """ES query feature that Luci implements with different behavior.

    Raised when a query uses ES features that Luci handles differently.
    The query will NOT execute. Users must acknowledge the difference
    and adjust their query or expectations.

    Attributes:
        feature: The ES feature name.
        difference: Description of how Luci's behavior differs from ES.

    """

    def __init__(self, feature: str, difference: str) -> None:
        """Create a QueryBehaviorDifferenceError for the given feature."""
        super().__init__(f"{feature}: {difference}")
        self.feature = feature
        self.difference = difference


__all__ = [
    "AsyncTransaction",
    "Index",
    "IndexLockedError",
    "InvalidQueryError",
    "LuciError",
    "QueryBehaviorDifferenceError",
    "Transaction",
    "TransactionActiveError",
    "UnsupportedQueryError",
    "set_num_threads",
]
__version__ = "0.5.0"
