# Embedl Hub Python library

Optimize and deploy your model on any edge device with the Embedl Hub Python library:

- **Compile** your model for execution on CPU, GPU, NPU or other AI accelerators
  using ONNX Runtime, TensorRT, or TFLite backends.
- **Profile** your model's latency and memory usage on real edge devices in the cloud.
- **Invoke** your compiled model to run inference with real input data.

The library logs your metrics, parameters, and results on the
[Embedl Hub](https://hub.embedl.com) website, allowing you to inspect, compare,
and reproduce your results.

For comprehensive getting started guides and API reference, visit the
[Embedl Hub documentation](https://hub.embedl.com/docs).

[Create a free Embedl Hub account](https://hub.embedl.com/docs/setup)
to get started.

## Installation

Install `embedl-hub` with `pip`:

```shell
pip install embedl-hub
```

## Usage

The `embedl-hub` library can be used in two ways:

### CLI

The `embedl-hub` (or `ehub`) command provides an end-to-end workflow for
compiling, profiling, and invoking models from the terminal:

```
Usage: embedl-hub [OPTIONS] COMMAND [ARGS]...

 embedl-hub end-to-end Edge-AI workflow CLI

╭─ Options ────────────────────────────────────────────────────────────────╮
│ --version      -V               Print embedl-hub version and exit.       │
│ --verbose      -v      INTEGER  Increase verbosity (-v, -vv, -vvv).      │
│ --help                          Show this message and exit.              │
╰──────────────────────────────────────────────────────────────────────────╯
╭─ Commands ───────────────────────────────────────────────────────────────╮
│ auth           Store the API key for embedl-hub CLI.                     │
│ init           Configure persistent CLI context.                         │
│ show           Print the active project name and artifact directory.     │
│ compile        Compile a model for on-device deployment.                 │
│ profile        Profile a compiled model on a target device.              │
│ invoke         Run inference on a compiled model.                        │
│ log            Show past runs from the artifact directory.               │
│ list-devices   List available devices.                                   │
╰──────────────────────────────────────────────────────────────────────────╯
```

### Python API

For programmatic use, import from the `embedl_hub` package. The API provides
compiler, profiler, and invoker components for each supported backend
(ONNX Runtime, TensorRT, TFLite):

```python
from embedl_hub.compile import OnnxRuntimeCompiler
from embedl_hub.profile import OnnxRuntimeProfiler
from embedl_hub.invoke import OnnxRuntimeInvoker
```

See the [Embedl Hub documentation](https://hub.embedl.com/docs) for detailed
guides and examples.

## License

Copyright (C) 2025, 2026 Embedl AB

This software is subject to the [Embedl Hub Software License Agreement](https://hub.embedl.com/embedl-hub-sla.txt).

<!-- Copyright (C) 2025, 2026 Embedl AB -->
