# Copyright (C) 2026 Embedl AB

"""Fundamental type aliases shared across the Embedl Hub SDK.

:data:`LocalPath` and :data:`RemotePath` are lightweight type aliases
used in virtually every package — CLI, core, tracking, and tests.
Defining them here avoids circular imports that arise when lower-level
modules (e.g. ``core.component.output``) need to reference these types
but cannot safely import from ``core.device`` during initialisation.
"""

from __future__ import annotations

import pathlib
from typing import TypeAlias

LocalPath: TypeAlias = pathlib.Path
"""Alias for :class:`pathlib.Path` — a path on the local filesystem."""

RemotePath: TypeAlias = pathlib.PurePosixPath
"""Alias for :class:`pathlib.PurePosixPath` — a path on a remote device."""
