# Copyright (C) 2026 Embedl AB

"""TensorRT invoker component.

Supports model invocation via:
- **``trtexec``** devices: Remote invocation using ``trtexec``
  over SSH.
"""

from __future__ import annotations

import json
from collections.abc import Collection
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from embedl_hub._internal.core.compile.tensorrt import TensorRTCompiledModel
from embedl_hub._internal.core.component.abc import Component, NoProviderError
from embedl_hub._internal.core.component.output import ComponentOutput
from embedl_hub._internal.core.component.provider_type import ProviderType
from embedl_hub._internal.core.context import HubContext
from embedl_hub._internal.core.device.abc import CommandRunner
from embedl_hub._internal.core.device.commands import run_remote_command
from embedl_hub._internal.core.device.config.trtexec import TrtexecConfig
from embedl_hub._internal.core.invoke import InvokeError
from embedl_hub._internal.core.types import LocalPath, RemotePath
from embedl_hub._internal.tracking.rest_api import RunType
from embedl_hub._internal.tracking.run_log import LoggedArtifact


def _validate_invoke_args(trtexec_cli_args: Collection[str]) -> None:
    """Validate ``trtexec`` CLI arguments for internally reserved flags.

    :param trtexec_cli_args: CLI arguments to validate.
    :raises ValueError: If any reserved flag is present.
    """
    trtexec_options = [
        arg.split("=", maxsplit=1)[0] for arg in trtexec_cli_args
    ]
    issues: list[str] = []

    if "--loadEngine" in trtexec_options:
        issues.append(
            "--loadEngine: the engine path is set internally and should "
            "not be provided via trtexec_cli_args."
        )
    if "--loadInputs" in trtexec_options:
        issues.append(
            "--loadInputs: set internally from input_data and should "
            "not be provided via trtexec_cli_args."
        )
    if "--exportOutput" in trtexec_options:
        issues.append(
            "--exportOutput: set internally and should not be provided."
        )

    if issues:
        raise ValueError(
            "Invalid parameters in 'trtexec_cli_args':\n" + "\n".join(issues)
        )


def _save_input_to_local(
    input_data: dict[str, np.ndarray],
    local_dir: LocalPath,
) -> None:
    """Save input data as ``.raw`` files to *local_dir*.

    Each input tensor is written as a flat binary file using
    :meth:`numpy.ndarray.tofile`.

    :param input_data: Mapping of input names to NumPy arrays.
    :param local_dir: Local directory to write the raw files into.
    """
    for key, array in input_data.items():
        local_input = local_dir / f"{key}.raw"
        array.tofile(local_input)


def _upload_inputs_to_remote(
    runner: CommandRunner,
    input_data: dict[str, np.ndarray],
    local_dir: LocalPath,
    remote_dir: RemotePath,
) -> str:
    """Save input data locally, upload to the remote device, and return
    the ``--loadInputs`` argument string.

    :param runner: The device command runner.
    :param input_data: Mapping of input names to NumPy arrays.
    :param local_dir: Local directory for temporary raw files.
    :param remote_dir: Remote directory to upload raw files to.
    :return: A ``trtexec``-compatible ``--loadInputs`` argument value
        in the format ``name1:path1,name2:path2``.
    """
    _save_input_to_local(input_data, local_dir)
    remote_input_args: list[str] = []
    for key in input_data:
        local_input = local_dir / f"{key}.raw"
        remote_input = remote_dir / f"{key}.raw"
        runner.put(LocalPath(local_input), remote_input)
        remote_input_args.append(f"{key}:{remote_input}")
    return ",".join(remote_input_args)


def _load_output_json(output_path: Path) -> dict[str, np.ndarray]:
    """Parse the JSON output produced by ``trtexec --exportOutput``.

    The JSON file contains a list of objects, each with ``name``,
    ``dimensions`` (e.g. ``"1x3x224x224"``), and ``values`` (flat list
    of floats).

    :param output_path: Path to the JSON file.
    :return: Mapping of output names to NumPy arrays.
    """
    with open(output_path, encoding="utf-8") as f:
        output_json = json.load(f)

    output_data: dict[str, np.ndarray] = {}
    for item in output_json:
        shape = list(map(int, item["dimensions"].split("x")))
        array = np.array(item["values"], dtype=np.float32)
        output_data[item["name"]] = array.reshape(shape)
    return output_data


@dataclass(frozen=True)
class TensorRTInvocationResult(ComponentOutput):
    """Output from the TensorRTInvoker component.

    :param output: The output data from the model invocation, mapping
        output tensor names to NumPy arrays.
    :param output_file: The artifact containing the serialised output
        JSON file produced by ``trtexec --exportOutput``.
    """

    output: dict[str, np.ndarray]
    output_file: LoggedArtifact


class TensorRTInvoker(Component):
    """Component that runs inference on TensorRT engines using ``trtexec``.

    Runs ``trtexec`` on a remote device over SSH to execute inference on
    a compiled ``.trt`` / ``.engine`` / ``.plan`` engine and exports
    the output tensors.

    Device-specific parameters (``trtexec_path``, ``trtexec_cli_args``)
    are configured via :class:`~embedl_hub._internal.core.device.config.trtexec.TrtexecConfig`
    on the device.  Per-component overrides can be set via
    :attr:`~Device.provider_config_overrides`.
    """

    run_type = RunType.INFERENCE

    def __init__(
        self,
        *,
        name: str | None = None,
        device: str | None = None,
    ) -> None:
        """Create a new TensorRT invoker.

        Parameters passed here become the defaults for every call.
        They can be overridden per call by passing them to
        :meth:`run` directly.

        :param name: Display name for this component instance.
        :param device: Name of the target device.
        """
        super().__init__(
            name=name,
            device=device,
        )

    def run(
        self,
        ctx: HubContext,
        model: TensorRTCompiledModel,
        input_data: dict[str, np.ndarray],
        *,
        device: str | None = None,
    ) -> TensorRTInvocationResult:
        """Run inference on a compiled TensorRT engine via ``trtexec``.

        Keyword arguments override the defaults set in the constructor.
        If a keyword argument is not provided here, the value from the
        constructor is used.

        :param ctx: The execution context with device configuration.
        :param model: A :class:`TensorRTCompiledModel` whose ``path``
            artifact points to a compiled TensorRT engine.
        :param input_data: Dictionary mapping input tensor names to
            NumPy arrays.
        :return: A :class:`TensorRTInvocationResult` with the output
            artifact.
        """
        raise NoProviderError  # Replaced by the component system.


# --------------------------------------------------------------------- #
# trtexec provider
# --------------------------------------------------------------------- #


@TensorRTInvoker.provider(ProviderType.TRTEXEC)
def _invoke_tensorrt_cli(
    ctx: HubContext,
    model: TensorRTCompiledModel,
    input_data: dict[str, np.ndarray],
    *,
    device: str | None = None,
) -> TensorRTInvocationResult:
    """Run inference on a compiled TensorRT engine via ``trtexec``.

    All keyword arguments are pre-resolved by the component system.

    :param ctx: The execution context with device configuration.
    :param model: A :class:`TensorRTCompiledModel`.
    :param input_data: Mapping of input names to NumPy arrays.
    :param device: Name of the target device.
    :return: A :class:`TensorRTInvocationResult`.
    """
    # -- validate device ------------------------------------------------
    dev = ctx.devices[device]
    runner = dev.runner
    if runner is None:
        raise ValueError(
            "trtexec devices require a device with a command runner."
        )
    remote_artifact_dir = dev.artifact_dir
    if remote_artifact_dir is None:
        raise ValueError("No remote artifact directory available.")

    # -- resolve engine path (auto-transfer) ----------------------------
    remote_engine = model.path.to_remote(ctx, device_name=device).remote()

    # -- resolve provider config ----------------------------------------
    cfg = dev.get_provider_config(TrtexecConfig, TensorRTInvoker)
    if cfg is None:
        cfg = TrtexecConfig()
    trtexec_path = str(cfg.trtexec_path)
    effective_cli_args: list[str] = list(cfg.trtexec_cli_args)

    # Apply default invoke args if config has none
    if not effective_cli_args:
        effective_cli_args = [
            "--iterations=1",
            "--warmUp=0",
            "--duration=0",
            "--avgRuns=0",
        ]

    # -- validate engine suffix -----------------------------------------
    engine_suffix = Path(model.path.file_name).suffix
    if engine_suffix not in (".engine", ".plan", ".trt"):
        raise ValueError(
            "The provided model is not a TensorRT engine "
            f"(received '{engine_suffix}')."
        )

    # -- log input artifact ---------------------------------------------
    ctx.client.log_artifact(
        model.path,
        name="input",
        file_name=f"input_{model.path.file_name}",
        ctx=ctx,
    )

    # -- invoke --------------------------------------------------------
    output_data = _run_remote_invocation(
        ctx,
        runner=runner,
        remote_engine=remote_engine,
        input_data=input_data,
        remote_artifact_dir=remote_artifact_dir,
        trtexec_path=trtexec_path,
        trtexec_cli_args=effective_cli_args,
    )

    # -- save and log output artifact -----------------------------------
    output_json_path = ctx.artifact_dir / "output.json"
    _save_output_json(output_data, output_json_path)
    ctx.client.log_artifact(output_json_path, name="output_file")

    # Build the result: tracked fields come from the run log, the raw
    # output dict is passed explicitly.
    result = TensorRTInvocationResult.from_current_run(ctx, output=output_data)
    return result


# --------------------------------------------------------------------- #
# internal helpers
# --------------------------------------------------------------------- #


def _save_output_json(
    output_data: dict[str, np.ndarray],
    output_path: Path,
) -> None:
    """Save output data as a JSON file matching ``trtexec`` format.

    :param output_data: Mapping of output names to NumPy arrays.
    :param output_path: Path to write the JSON file to.
    """
    output_json = [
        {
            "name": name,
            "dimensions": "x".join(map(str, array.shape)),
            "values": array.flatten().tolist(),
        }
        for name, array in output_data.items()
    ]
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(output_json, f)


def _run_remote_invocation(
    ctx: HubContext,
    *,
    runner: CommandRunner,
    remote_engine: RemotePath,
    input_data: dict[str, np.ndarray],
    remote_artifact_dir: RemotePath,
    trtexec_path: str,
    trtexec_cli_args: list[str],
) -> dict[str, np.ndarray]:
    """Upload inputs, run ``trtexec`` inference, and download + parse
    the output.

    :param ctx: The execution context.
    :param runner: The device command runner.
    :param remote_engine: Remote path to the TensorRT engine on the device.
    :param input_data: Mapping of input names to NumPy arrays.
    :param remote_artifact_dir: Remote directory for artifacts.
    :param trtexec_path: Path to ``trtexec`` on the remote device.
    :param trtexec_cli_args: Extra CLI arguments for ``trtexec``.
    :return: Mapping of output names to NumPy arrays.
    :raises InvokeError: If the remote command fails.
    """
    # Upload input data and build the --loadInputs argument
    local_artifact_dir = ctx.artifact_dir
    load_inputs_arg = _upload_inputs_to_remote(
        runner, input_data, local_artifact_dir, remote_artifact_dir
    )

    # Save input data as JSON for artifact tracking
    input_json = [
        {
            "name": name,
            "dimensions": "x".join(map(str, array.shape)),
            "values": array.flatten().tolist(),
        }
        for name, array in input_data.items()
    ]
    input_json_path = local_artifact_dir / "input.json"
    with open(input_json_path, "w", encoding="utf-8") as f:
        json.dump(input_json, f)

    # Build the remote output path
    remote_output = remote_artifact_dir / "output.json"

    # Assemble the trtexec command
    run_args: list[str] = [
        trtexec_path,
        f"--loadEngine={remote_engine}",
        f"--loadInputs={load_inputs_arg}",
        f"--exportOutput={remote_output}",
        *trtexec_cli_args,
    ]

    # Validate arguments
    _validate_invoke_args(trtexec_cli_args)

    # Log parameters
    ctx.client.log_param("$runtime", "tensorrt")
    ctx.client.log_param("trtexec_path", trtexec_path)
    if trtexec_cli_args:
        ctx.client.log_param("trtexec_cli_args", " ".join(trtexec_cli_args))

    # Execute trtexec on the remote device
    result = run_remote_command(
        runner,
        run_args,
        local_artifact_dir,
        error_cls=InvokeError,
        error_message="TensorRT invocation failed on the remote device.",
    )

    # Download the output from the remote device
    local_output = local_artifact_dir / "output.json"
    runner.get(remote_output, local_output)

    # Parse and return the output data
    return _load_output_json(local_output)
