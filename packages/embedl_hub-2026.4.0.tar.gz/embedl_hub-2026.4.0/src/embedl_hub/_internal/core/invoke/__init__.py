# Copyright (C) 2026 Embedl AB

"""Invoke module for Embedl Hub."""


class InvokeError(RuntimeError):
    """Raised when an invocation job fails."""


__all__ = ["InvokeError"]
