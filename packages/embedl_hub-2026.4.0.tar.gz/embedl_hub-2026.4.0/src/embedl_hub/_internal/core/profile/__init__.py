# Copyright (C) 2026 Embedl AB

"""Profile module for Embedl Hub.

Public symbols are re-exported from :mod:`embedl_hub.core.profile`.
"""
