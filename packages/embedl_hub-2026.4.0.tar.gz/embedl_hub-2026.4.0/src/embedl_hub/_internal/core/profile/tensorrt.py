# Copyright (C) 2026 Embedl AB

"""TensorRT profiler component.

Supports profiling via:
- **``trtexec``** devices: Remote profiling using ``trtexec``
  over SSH.
"""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Collection
from dataclasses import dataclass
from pathlib import Path

from embedl_hub._internal.core.compile.tensorrt import TensorRTCompiledModel
from embedl_hub._internal.core.component.abc import Component, NoProviderError
from embedl_hub._internal.core.component.output import ComponentOutput
from embedl_hub._internal.core.component.provider_type import ProviderType
from embedl_hub._internal.core.context import HubContext
from embedl_hub._internal.core.device.abc import CommandRunner
from embedl_hub._internal.core.device.commands import run_remote_command
from embedl_hub._internal.core.device.config.trtexec import TrtexecConfig
from embedl_hub._internal.core.profile.logging import (
    log_execution_detail,
    log_model_summary,
)
from embedl_hub._internal.core.profile.parsers import (
    parse_trtexec_gpu_memory,
    parse_trtexec_profile,
)
from embedl_hub._internal.core.profile.result import (
    ProfileError,
    ProfilingMethod,
)
from embedl_hub._internal.core.types import RemotePath
from embedl_hub._internal.tracking.rest_api import RunType
from embedl_hub._internal.tracking.run_log import LoggedArtifact, LoggedMetric

logger = logging.getLogger(__name__)


#: Backward-compatible alias for the old ``TensorRTProfilingMethod``.
TensorRTProfilingMethod = ProfilingMethod


def _validate_profiling_args(trtexec_cli_args: Collection[str]) -> None:
    """Validate ``trtexec`` CLI arguments for internally reserved flags.

    :param trtexec_cli_args: CLI arguments to validate.
    :raises ValueError: If any reserved flag is present.
    """
    trtexec_options = [
        arg.split("=", maxsplit=1)[0] for arg in trtexec_cli_args
    ]
    issues: list[str] = []

    if "--loadEngine" in trtexec_options:
        issues.append(
            "--loadEngine: the engine path is set internally and should "
            "not be provided via trtexec_cli_args."
        )
    if "--exportProfile" in trtexec_options:
        issues.append(
            "--exportProfile: set internally based on the profiling method."
        )
    if "--exportTimes" in trtexec_options:
        issues.append(
            "--exportTimes: set internally based on the profiling method."
        )

    if issues:
        raise ValueError(
            "Invalid parameters in 'trtexec_cli_args':\n" + "\n".join(issues)
        )


def _parse_profiling_results(
    profile_json: list[dict],
    profiling_method: ProfilingMethod,
    profiling_execution_time: float,
) -> tuple[float, float]:
    """Parse profiling output and compute latency and FPS.

    :param profile_json: The parsed JSON output from ``trtexec``.
    :param profiling_method: The method used for profiling.
    :param profiling_execution_time: Wall-clock time in seconds (used
        only for :attr:`ProfilingMethod.PYTHON`).
    :return: A ``(latency_ms, fps)`` tuple.
    """
    if profiling_method == ProfilingMethod.PYTHON:
        num_executions = len(
            [item for item in profile_json if "latencyMs" in item]
        )
        average_ms = (profiling_execution_time / num_executions) * 1000
    elif profiling_method == ProfilingMethod.LAYERWISE:
        average_ms = sum(
            item["averageMs"] for item in profile_json if "averageMs" in item
        )
    else:
        times = [
            item["latencyMs"] for item in profile_json if "latencyMs" in item
        ]
        average_ms = sum(times) / len(times)

    fps = 1000.0 / average_ms
    return average_ms, fps


@dataclass(frozen=True)
class TensorRTProfilingResult(ComponentOutput):
    """Output from the TensorRTProfiler component.

    :param latency: The average inference latency in milliseconds.
    :param fps: The inferred frames per second.
    :param output_file: The artifact containing the per-layer profile JSON,
        if available.
    """

    latency: LoggedMetric
    fps: LoggedMetric
    output_file: LoggedArtifact | None


class TensorRTProfiler(Component):
    """Component that profiles TensorRT engines using ``trtexec``.

    Runs ``trtexec`` on a remote device over SSH to benchmark a compiled
    ``.trt`` / ``.engine`` / ``.plan`` engine and extracts latency and
    throughput metrics.

    Device-specific parameters (``trtexec_path``, ``trtexec_cli_args``)
    are configured via :class:`~embedl_hub._internal.core.device.config.trtexec.TrtexecConfig`
    on the device.  Per-component overrides can be set via
    :attr:`~Device.provider_config_overrides`.
    """

    run_type = RunType.PROFILE

    def __init__(
        self,
        *,
        name: str | None = None,
        device: str | None = None,
        profiling_method: ProfilingMethod = ProfilingMethod.LAYERWISE,
    ) -> None:
        """Create a new TensorRT profiler.

        Parameters passed here become the defaults for every call.
        They can be overridden per call by passing them to
        :meth:`run` directly.

        :param name: Display name for this component instance.
        :param device: Name of the target device.
        :param profiling_method: Method specifying how to measure
            execution time.  See :class:`ProfilingMethod`.
        """
        super().__init__(
            name=name,
            device=device,
            profiling_method=profiling_method,
        )

    def run(
        self,
        ctx: HubContext,
        model: TensorRTCompiledModel,
        *,
        device: str | None = None,
        profiling_method: ProfilingMethod = ProfilingMethod.LAYERWISE,
    ) -> TensorRTProfilingResult:
        """Profile a compiled TensorRT engine via ``trtexec``.

        Keyword arguments override the defaults set in the constructor.
        If a keyword argument is not provided here, the value from the
        constructor is used.

        :param ctx: The execution context with device configuration.
        :param model: A :class:`TensorRTCompiledModel` whose ``path``
            artifact points to a compiled TensorRT engine.
        :param device: Name of the target device.
        :param profiling_method: Method specifying how to measure
            execution time.  See :class:`ProfilingMethod`.
        :return: A :class:`TensorRTProfilingResult` with latency and
            FPS metrics.
        """
        raise NoProviderError  # Replaced by the component system.


# --------------------------------------------------------------------- #
# trtexec provider
# --------------------------------------------------------------------- #


@TensorRTProfiler.provider(ProviderType.TRTEXEC)
def _profile_tensorrt_cli(
    ctx: HubContext,
    model: TensorRTCompiledModel,
    *,
    device: str | None = None,
    profiling_method: ProfilingMethod = ProfilingMethod.LAYERWISE,
) -> TensorRTProfilingResult:
    """Profile a compiled TensorRT engine via ``trtexec``.

    All keyword arguments are pre-resolved by the component system.

    :param ctx: The execution context with device configuration.
    :param model: A :class:`TensorRTCompiledModel`.
    :param device: Name of the target device.
    :param profiling_method: Profiling method.
    :return: A :class:`TensorRTProfilingResult`.
    """
    # -- validate device ------------------------------------------------
    dev = ctx.devices[device]
    runner = dev.runner
    if runner is None:
        raise ValueError(
            "trtexec devices require a device with a command runner."
        )
    remote_artifact_dir = dev.artifact_dir
    if remote_artifact_dir is None:
        raise ValueError("No remote artifact directory available.")

    # -- resolve provider config ----------------------------------------
    cfg = dev.get_provider_config(TrtexecConfig, TensorRTProfiler)
    if cfg is None:
        cfg = TrtexecConfig()
    trtexec_path = str(cfg.trtexec_path)
    effective_cli_args: list[str] = list(cfg.trtexec_cli_args)

    # Apply default profiling args if config has none
    if not effective_cli_args:
        effective_cli_args = [
            "--useCudaGraph",
            "--useSpinWait",
            "--noDataTransfers",
        ]
        logger.info("Using default trtexec_cli_args: %s", effective_cli_args)

    # -- resolve engine path (auto-transfer) ----------------------------
    remote_engine = model.path.to_remote(ctx, device_name=device).remote()

    # -- validate engine suffix -----------------------------------------
    engine_suffix = Path(model.path.file_name).suffix
    if engine_suffix not in (".engine", ".plan", ".trt"):
        raise ValueError(
            "The provided model is not a TensorRT engine "
            f"(received '{engine_suffix}')."
        )

    # -- log input artifact ---------------------------------------------
    ctx.client.log_artifact(
        model.path,
        name="input",
        file_name=f"input_{model.path.file_name}",
        ctx=ctx,
    )

    # -- profile --------------------------------------------------------
    latency_ms, fps, profile_json, trtexec_stdout = _run_remote_profiling(
        ctx,
        runner=runner,
        remote_engine=remote_engine,
        remote_artifact_dir=remote_artifact_dir,
        trtexec_path=trtexec_path,
        trtexec_cli_args=effective_cli_args,
        profiling_method=profiling_method,
    )

    # -- log output metrics and artifacts --------------------------------
    ctx.client.log_metric("$latency", latency_ms)
    ctx.client.log_metric("fps", fps)

    # -- log model summary and per-layer execution detail ----------------
    if profiling_method == ProfilingMethod.LAYERWISE and profile_json:
        summary, execution_detail = parse_trtexec_profile(profile_json)
        gpu_mem = parse_trtexec_gpu_memory(trtexec_stdout)
        if gpu_mem is not None:
            summary["peak_memory_usage_mb"] = gpu_mem
        log_model_summary(ctx.client, summary)
        log_execution_detail(ctx.client, execution_detail)

    profile_path = ctx.artifact_dir / "profile.json"
    if profile_path.exists():
        ctx.client.log_artifact(profile_path, name="output_file")

    return TensorRTProfilingResult.from_current_run(ctx)


# --------------------------------------------------------------------- #
# internal helpers
# --------------------------------------------------------------------- #


def _run_remote_profiling(
    ctx: HubContext,
    *,
    runner: CommandRunner,
    remote_engine: RemotePath,
    remote_artifact_dir: RemotePath,
    trtexec_path: str,
    trtexec_cli_args: list[str],
    profiling_method: ProfilingMethod,
) -> tuple[float, float, list[dict], str]:
    """Run ``trtexec`` profiling on a remote device and parse results.

    :param ctx: The execution context.
    :param runner: The device command runner.
    :param remote_engine: Remote path to the TensorRT engine on the device.
    :param remote_artifact_dir: Remote directory for artifacts.
    :param trtexec_path: Path to ``trtexec`` on the remote device.
    :param trtexec_cli_args: Extra CLI arguments for ``trtexec``.
    :param profiling_method: The profiling method to use.
    :return: A ``(latency_ms, fps, profile_json, stdout)`` tuple.
    :raises ProfileError: If the remote command fails.
    """
    # Build the profiling output path
    remote_profile = remote_artifact_dir / "profile.json"

    # Assemble the trtexec command
    if profiling_method == ProfilingMethod.LAYERWISE:
        profile_args = [
            f"--exportProfile={remote_profile}",
            "--separateProfileRun",
        ]
    else:
        profile_args = [
            f"--exportTimes={remote_profile}",
        ]

    run_args: list[str] = [
        trtexec_path,
        f"--loadEngine={remote_engine}",
        *profile_args,
        *trtexec_cli_args,
    ]

    # Validate arguments
    _validate_profiling_args(trtexec_cli_args)

    # Log parameters
    ctx.client.log_param("$runtime", "tensorrt")
    ctx.client.log_param("trtexec_path", trtexec_path)
    ctx.client.log_param("profiling_method", profiling_method.value)
    if trtexec_cli_args:
        ctx.client.log_param("trtexec_cli_args", " ".join(trtexec_cli_args))

    # Execute trtexec on the remote device
    local_artifact_dir = ctx.artifact_dir

    profiling_start_time = time.time()
    result = run_remote_command(
        runner,
        run_args,
        local_artifact_dir,
        error_cls=ProfileError,
        error_message="TensorRT profiling failed on the remote device.",
    )
    profiling_execution_time = time.time() - profiling_start_time
    stdout = result.stdout or ""

    # Download the profile output
    local_profile = local_artifact_dir / "profile.json"
    runner.get(remote_profile, local_profile)

    # Parse the profiling results
    with open(local_profile, encoding="utf-8") as profile_file:
        profile_json: list[dict] = json.load(profile_file)

    latency_ms, fps = _parse_profiling_results(
        profile_json, profiling_method, profiling_execution_time
    )
    return latency_ms, fps, profile_json, stdout
