# Copyright (C) 2026 Embedl AB

"""Shared logging helpers for profiling results.

These functions log profile summary metrics and per-layer execution
detail to the tracking backend via a :class:`Client` instance
(the ``ctx.client`` pattern from the component system).
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from embedl_hub._internal.tracking.client import Client


def log_model_summary(client: Client, summary: dict) -> None:
    """Log model-summary metrics to the tracking backend.

    Logs:

    - ``$peak_memory_usage`` — peak inference memory in MB.
    - ``$num_layers_cpu``, ``$num_layers_gpu``, ``$num_layers_npu`` —
      layer counts per compute unit.
    - ``$num_layers`` — total number of layers.
    - ``$load_time`` — warm load time in milliseconds.

    All metrics are sent in a single batched API call.

    :param client: The tracking client (``ctx.client``).
    :param summary: A summary dict as returned by
        :func:`~embedl_hub._internal.core.profile.parsers.parse_qai_hub_profile`
        (or equivalent).
    """
    metrics: list[tuple[str, float, int | None]] = []

    peak_mem = summary.get("peak_memory_usage_mb")
    if peak_mem is not None:
        metrics.append(("$peak_memory_usage", peak_mem, None))

    for unit, count in summary.get("layers_by_unit", {}).items():
        metrics.append((f"$num_layers_{unit.lower()}", count, None))

    num_layers = summary.get("num_layers")
    if num_layers is not None:
        metrics.append(("$num_layers", num_layers, None))

    load_time = summary.get("load_time_ms")
    if load_time is not None:
        metrics.append(("$load_time", load_time, None))

    if metrics:
        client.log_batch(metrics=metrics)


def log_execution_detail(client: Client, execution_detail: list[dict]) -> None:
    """Log per-layer execution detail to the tracking backend.

    Logs:

    - ``$layer_name_<idx>`` — param with the layer name.
    - ``$layer_type_<idx>`` — param with the layer/op type.
    - ``$layer_compute_unit_<idx>`` — param with the compute unit.
    - ``$latency_per_layer`` — metric with ``step=idx`` (execution time µs).
    - ``$cycles_per_layer`` — metric with ``step=idx`` (execution cycles).

    All data is sent in a single batched API call for efficiency.

    :param client: The tracking client (``ctx.client``).
    :param execution_detail: A list of layer dicts, each containing
        ``name``, ``type``, ``compute_unit``, ``execution_time``,
        and ``execution_cycles``.
    """
    metrics: list[tuple[str, float, int | None]] = []
    params: list[tuple[str, str]] = []

    for idx, layer in enumerate(execution_detail):
        params.append((f"$layer_name_{idx}", layer["name"]))
        params.append((f"$layer_type_{idx}", layer["type"]))
        params.append((f"$layer_compute_unit_{idx}", layer["compute_unit"]))
        metrics.append(("$latency_per_layer", layer["execution_time"], idx))
        metrics.append(("$cycles_per_layer", layer["execution_cycles"], idx))

    if metrics or params:
        client.log_batch(metrics=metrics, params=params)
