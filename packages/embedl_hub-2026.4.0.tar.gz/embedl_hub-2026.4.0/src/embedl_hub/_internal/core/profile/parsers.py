# Copyright (C) 2026 Embedl AB

"""Profile output parsers for different runtimes.

Each parser takes a raw profile dict/list produced by a specific runtime
(QAI Hub, ONNX Runtime, TensorRT) and returns a ``(summary, execution_detail)``
tuple with a uniform schema.
"""

from __future__ import annotations

import re
from typing import Any

# ---------------------------------------------------------------------------
# Unit-conversion helpers
# ---------------------------------------------------------------------------


def _to_us_ms(val: object) -> float | None:
    """Convert microseconds to milliseconds, or ``None`` if unavailable.

    :param val: Value in microseconds, or ``None``.
    :return: Value in milliseconds, or ``None``.
    """
    return float(val) / 1000.0 if val is not None else None  # type: ignore[arg-type]


def _to_megabytes(val: object) -> float | None:
    """Convert bytes to megabytes, or ``None`` if unavailable.

    :param val: Value in bytes, or ``None``.
    :return: Value in megabytes, or ``None``.
    """
    return float(val) / (1024 * 1024) if val is not None else None  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# Layer helpers
# ---------------------------------------------------------------------------


def _count_layers_by_unit(execution_detail: list[dict]) -> dict[str, int]:
    """Count layers by compute unit (CPU, GPU, NPU) from execution detail.

    :param execution_detail: List of layer dicts, each with a
        ``"compute_unit"`` key.
    :return: A dict mapping ``"CPU"``, ``"GPU"``, and ``"NPU"``
        to the number of layers assigned to each.
    """
    counts: dict[str, int] = {"CPU": 0, "GPU": 0, "NPU": 0}
    for layer in execution_detail:
        unit = layer.get("compute_unit")
        if unit in counts:
            counts[unit] += 1
    return counts


def _make_layer_names_unique(execution_detail: list[dict]) -> None:
    """Modify `execution_detail` in-place so every layer has a unique name.

    When all names are already distinct and non-empty, they are kept
    as-is.  Otherwise, names are replaced with ``<type>_<index>``
    strings to guarantee uniqueness.
    """
    all_unique = True
    seen: set[str | None] = set()
    for layer in execution_detail:
        name = layer.get("name")
        if name in seen or name == "":
            all_unique = False
            break
        seen.add(name)

    if all_unique:
        return

    counts: dict[str, int] = {}
    for layer in execution_detail:
        layer_type = layer["type"]
        idx = counts.get(layer_type, 0)
        layer["name"] = f"{layer_type.lower()}_{idx}"
        counts[layer_type] = idx + 1


# ---------------------------------------------------------------------------
# QAI Hub profile parsing
# ---------------------------------------------------------------------------


def parse_qai_hub_profile(profile: dict[str, Any]) -> tuple[dict, list[dict]]:
    """Parse a QAI Hub profile dict into a summary dict and execution detail.

    The returned *summary* dict has keys:

    - ``mean_ms`` — average latency in milliseconds.
    - ``peak_memory_usage_mb`` — peak inference memory in megabytes.
    - ``layers_by_unit`` — ``{"CPU": N, "GPU": N, "NPU": N}``.
    - ``num_layers`` — total number of layers.
    - ``load_time_ms`` — warm load time in milliseconds (if available).

    The *execution_detail* list has one dict per layer, each with keys
    ``name``, ``type``, ``compute_unit``, ``execution_time`` (µs),
    ``execution_cycles``.

    :param profile: The raw dict returned by ``job.download_profile()``.
    :return: ``(summary_dict, execution_detail)`` tuple.
    """
    exec_summary = profile.get("execution_summary", {})
    execution_detail: list[dict] = profile.get("execution_detail", [])
    _make_layer_names_unique(execution_detail)
    layer_counts = _count_layers_by_unit(execution_detail)

    summary_dict: dict[str, Any] = {
        "mean_ms": _to_us_ms(exec_summary.get("estimated_inference_time")),
        "peak_memory_usage_mb": _to_megabytes(
            exec_summary.get("estimated_inference_peak_memory")
        ),
        "layers_by_unit": layer_counts,
        "num_layers": len(execution_detail),
        "load_time_ms": _to_us_ms(exec_summary.get("warm_load_time")),
    }
    return summary_dict, execution_detail


# ---------------------------------------------------------------------------
# ONNX Runtime (embedl-onnxruntime) profile parsing
# ---------------------------------------------------------------------------


#: Mapping from ONNX Runtime execution provider names to the canonical
#: compute-unit labels used by the logging helpers.
_ORT_PROVIDER_TO_UNIT: dict[str, str] = {
    "CPUExecutionProvider": "CPU",
    "CUDAExecutionProvider": "GPU",
    "TensorrtExecutionProvider": "GPU",
    "OpenVINOExecutionProvider": "CPU",
    "CoreMLExecutionProvider": "NPU",
    "QNNExecutionProvider": "NPU",
    "TIDLExecutionProvider": "NPU",
    "NnapiExecutionProvider": "NPU",
    "ArmNNExecutionProvider": "CPU",
}


def _map_ort_provider_to_unit(exec_provider: str | None) -> str:
    """Map an ONNX Runtime execution-provider name to a compute-unit label.

    Falls back to ``"CPU"`` for unknown or missing providers.

    :param exec_provider: The ORT provider name, e.g.
        ``"CPUExecutionProvider"``.
    :return: ``"CPU"``, ``"GPU"``, or ``"NPU"``.
    """
    if exec_provider is None:
        return "CPU"
    return _ORT_PROVIDER_TO_UNIT.get(exec_provider, "CPU")


def parse_ort_profile(profile: dict[str, Any]) -> tuple[dict, list[dict]]:
    """Parse an ``embedl-onnxruntime`` JSON profile into summary + detail.

    The JSON file written by ``embedl-onnxruntime measure-latency
    --output-json-file`` contains a :class:`ModelBenchmarkMetrics` dict
    with keys ``runs``, ``avg_ms``, and optionally ``layers`` mapping
    layer names to :class:`LayerBenchmarkMetrics`.

    The returned *summary* dict contains:

    - ``mean_ms`` — average latency in milliseconds.
    - ``layers_by_unit`` — ``{"CPU": N, "GPU": N, "NPU": N}``.
    - ``num_layers`` — total number of layers.

    The returned *execution_detail* list has one dict per layer
    (same schema as :func:`parse_qai_hub_profile` output), with
    ``execution_cycles`` always set to ``0`` (ONNX Runtime does not
    report cycle counts).

    :param profile: The parsed JSON dict from the profile file.
    :return: ``(summary_dict, execution_detail)`` tuple.
    """
    layers: dict[str, dict] = profile.get("layers", {})

    execution_detail: list[dict] = []
    for _layer_name, layer_data in layers.items():
        name = layer_data.get("name", _layer_name)
        op_name = layer_data.get("op_name", "Unknown")
        exec_provider = layer_data.get("exec_provider")
        compute_unit = _map_ort_provider_to_unit(exec_provider)
        avg_ms = layer_data.get("avg_ms", 0.0)

        execution_detail.append(
            {
                "name": name,
                "type": op_name,
                "compute_unit": compute_unit,
                "execution_time": avg_ms * 1000.0,  # ms → µs
                "execution_cycles": 0,
            }
        )

    _make_layer_names_unique(execution_detail)
    layer_counts = _count_layers_by_unit(execution_detail)

    summary_dict: dict[str, Any] = {
        "mean_ms": profile.get("avg_ms"),
        "layers_by_unit": layer_counts,
        "num_layers": len(execution_detail),
    }
    return summary_dict, execution_detail


# ---------------------------------------------------------------------------
# TensorRT (trtexec --exportProfile) profile parsing
# ---------------------------------------------------------------------------


def parse_trtexec_profile(profile_json: list[dict]) -> tuple[dict, list[dict]]:
    """Parse a ``trtexec --exportProfile`` JSON into summary + detail.

    The JSON is a list of dicts.  The first entry usually contains only
    ``{"count": N}`` (total number of iterations).  Subsequent entries
    represent individual TensorRT layers with keys ``name``,
    ``averageMs``, ``timeMs``, ``percentage``, etc.

    Because TensorRT fuses operators, the ``name`` is the fused kernel
    name rather than an individual ONNX op name.  No ``type`` or
    ``compute_unit`` information is available — all layers run on GPU.

    The returned *summary* dict contains:

    - ``mean_ms`` — total model latency (sum of layer averages).
    - ``layers_by_unit`` — ``{"CPU": 0, "GPU": N, "NPU": 0}``.
    - ``num_layers`` — total number of layers.

    The returned *execution_detail* list has one dict per layer with
    ``execution_cycles`` always ``0`` and ``compute_unit`` always
    ``"GPU"``.

    :param profile_json: The parsed JSON list from ``--exportProfile``.
    :return: ``(summary_dict, execution_detail)`` tuple.
    """
    execution_detail: list[dict] = []

    for item in profile_json:
        name = item.get("name")
        if name is None:
            continue  # skip the count-only entry
        avg_ms = item.get("averageMs", 0.0)
        execution_detail.append(
            {
                "name": name,
                "type": "FusedKernel",
                "compute_unit": "GPU",
                "execution_time": avg_ms * 1000.0,  # ms → µs
                "execution_cycles": 0,
            }
        )

    _make_layer_names_unique(execution_detail)
    layer_counts = _count_layers_by_unit(execution_detail)
    mean_ms = sum(
        item["averageMs"] for item in profile_json if "averageMs" in item
    )

    summary_dict: dict[str, Any] = {
        "mean_ms": mean_ms,
        "layers_by_unit": layer_counts,
        "num_layers": len(execution_detail),
    }
    return summary_dict, execution_detail


def parse_trtexec_gpu_memory(stdout: str) -> float | None:
    """Parse GPU memory usage from ``trtexec`` standard output.

    Looks for the last ``[MemUsageChange]`` line that reports the
    total GPU allocation (the ``now: CPU …, GPU … (MiB)`` part).

    :param stdout: The standard output from ``trtexec``.
    :return: Peak GPU memory in megabytes, or ``None`` if not found.
    """
    # Match lines like:
    #   [MemUsageChange] TensorRT-managed allocation in
    #   IExecutionContext creation: CPU +0, GPU +7, now: CPU 0, GPU 20 (MiB)
    pattern = r"\[MemUsageChange\].*now:\s*CPU\s+\d+,\s*GPU\s+(\d+)\s*\(MiB\)"
    matches = re.findall(pattern, stdout)
    if not matches:
        return None
    # Return the last (highest) reported GPU total
    return float(matches[-1])
