# Copyright (C) 2026 Embedl AB

"""Typed provider configuration for devices.

Each provider (e.g. ``trtexec``, ``embedl_onnxruntime``) defines a
frozen dataclass implementing :class:`ProviderConfig`.  These
configuration objects replace the untyped ``provider_metadata`` dict
on :class:`~embedl_hub._internal.core.device.abc.Device`.

Provider configs are structured in two tiers on each device:

* A **default** :attr:`~Device.provider_config` that applies to all
  component types.
* Optional **per-component overrides** in
  :attr:`~Device.provider_config_overrides`, keyed by the concrete
  :class:`~embedl_hub._internal.core.component.abc.Component` subclass.

Example::

    from embedl_hub._internal.core.device.config.trtexec import TrtexecConfig

    device = DeviceManager.get_tensorrt_device(
        ssh_config,
        config=TrtexecConfig(trtexec_cli_args=("--fp16",)),
        overrides={
            TensorRTCompiler: TrtexecConfig(
                trtexec_cli_args=("--fp16", "--int8"),
            ),
        },
    )
"""
