# Copyright (C) 2026 Embedl AB

"""Device specification types.

This module defines the data classes that describe device platforms and
execution environments.

:data:`LocalPath` and :data:`RemotePath` are re-exported here for
backward compatibility but are canonically defined in
:mod:`embedl_hub._internal.core.types`.
"""

from __future__ import annotations

from dataclasses import dataclass

from embedl_hub._internal.core.types import LocalPath, RemotePath


@dataclass
class DeviceSpec:
    """Specification for a target device.

    :param device_name: Optional name identifier for the device
        (e.g. ``'Samsung Galaxy S24'``).
    """

    device_name: str | None = None
