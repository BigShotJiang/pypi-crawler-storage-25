# Copyright (C) 2026 Embedl AB

"""Typed configuration for the ``trtexec`` provider."""

from __future__ import annotations

from dataclasses import dataclass, field

from embedl_hub._internal.core.device.config.abc import ProviderConfig
from embedl_hub._internal.core.types import RemotePath


@dataclass(frozen=True)
class TrtexecConfig(ProviderConfig):
    """Configuration for devices using the ``trtexec`` CLI.

    Instances are attached to a :class:`~embedl_hub._internal.core.device.abc.Device`
    via :attr:`~Device.provider_config` (default for all components) and
    optionally overridden per-component in
    :attr:`~Device.provider_config_overrides`.

    :param trtexec_path: Path to the ``trtexec`` executable on the remote
        system.  Defaults to ``"trtexec"`` (assumes it is on ``$PATH``).
    :param trtexec_cli_args: Additional device-specific CLI arguments
        forwarded verbatim to ``trtexec``.  These are **appended** to
        any component-level arguments.
    """

    trtexec_path: RemotePath = RemotePath("trtexec")
    trtexec_cli_args: tuple[str, ...] = field(default_factory=tuple)
