# Copyright (C) 2026 Embedl AB

"""Remote artifact directory management for devices.

This module provides the :class:`RemoteArtifactManager` which encapsulates
all logic for creating, tracking, downloading, and cleaning up remote
artifact directories on a device.
"""

from __future__ import annotations

import uuid
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from embedl_hub._internal.core.types import LocalPath, RemotePath

if TYPE_CHECKING:
    from embedl_hub._internal.core.device.abc import CommandRunner


@dataclass
class RemoteArtifactManager:
    """Manages remote artifact directories for a device.

    Handles creating, tracking, downloading, and cleaning up artifact
    directories on a remote device via a :class:`CommandRunner`.

    :param runner: The command runner used for remote operations.
    """

    runner: CommandRunner | None
    _base_dir: RemotePath | None = field(default=None, init=False, repr=False)
    _subdir_name: str | None = field(default=None, init=False, repr=False)
    _dir_created: bool = field(default=False, init=False, repr=False)
    _active: bool = field(default=False, init=False, repr=False)
    _owns_base_dir: bool = field(default=False, init=False, repr=False)
    _last_download_dir: LocalPath | None = field(
        default=None, init=False, repr=False
    )

    # -- base_dir property ---------------------------------------------------

    @property
    def base_dir(self) -> RemotePath | None:
        """Get the remote base directory for artifacts."""
        return self._base_dir

    @base_dir.setter
    def base_dir(self, value: RemotePath | None) -> None:
        """Set the remote base directory for artifacts.

        :raises RuntimeError: If called while the manager is active.
        """
        if self._active:
            raise RuntimeError(
                "Cannot set 'artifact_base_dir' while inside a device context."
            )
        self._base_dir = value

    # -- artifact_dir property -----------------------------------------------

    @property
    def artifact_dir(self) -> RemotePath | None:
        """Get the artifact directory for the current run.

        On first access the directory is lazily created on the remote
        device.  Returns ``None`` if there is no base directory, no
        subdirectory name, no runner, or the manager is not active.
        """
        if (
            self._base_dir is None
            or self._subdir_name is None
            or self.runner is None
            or not self._active
        ):
            return None

        artifact_dir = self._base_dir / self._subdir_name
        if not self._dir_created:
            self.runner.run(["mkdir", "-p", str(artifact_dir)], hide=True)
            self._dir_created = True
        return artifact_dir

    # -- subdir management ---------------------------------------------------

    def set_subdir_name(self, subdir_name: str) -> None:
        """Set the artifact subdirectory name for a component run.

        :param subdir_name: The subdirectory name to append to the base dir.
        """
        self._subdir_name = subdir_name
        self._dir_created = False

    def clear_subdir_name(self) -> None:
        """Clear the artifact subdirectory name.

        The remote directory is not deleted; it will be cleaned up when
        the base directory is removed on context exit.
        """
        self._subdir_name = None
        self._dir_created = False

    # -- download ------------------------------------------------------------

    def download_artifact_dir(self, destination: LocalPath) -> LocalPath:
        """Download the current remote artifact directory to a local path.

        :param destination: The local directory to download into.
        :return: The local path where the artifacts were downloaded.
        :raises RuntimeError: If the manager is not active.
        :raises RuntimeError: If there is no command runner.
        :raises RuntimeError: If there is no remote artifact directory.
        """
        if not self._active:
            raise RuntimeError(
                "Cannot download artifacts outside an active context."
            )
        if self.runner is None:
            raise RuntimeError(
                "Cannot download artifacts without a command runner."
            )
        artifact_dir = self.artifact_dir
        if artifact_dir is None:
            raise RuntimeError("No remote artifact directory to download.")

        from embedl_hub._internal.core.device.transfer import get_directory

        get_directory(self.runner, artifact_dir, destination)
        self._last_download_dir = destination
        return destination

    @property
    def last_download_dir(self) -> LocalPath | None:
        """Get the local path of the most recent artifact download."""
        return self._last_download_dir

    # -- context management --------------------------------------------------

    @contextmanager
    def activate(self) -> Generator[RemoteArtifactManager, None, None]:
        """Activate the artifact manager, optionally creating a temp base dir.

        If no :attr:`base_dir` has been set and a runner is available, a
        unique temporary directory is created on the remote device and
        automatically cleaned up on exit.

        :yields: This manager instance in an active state.
        """
        self._active = True

        if self._base_dir is None and self.runner is not None:
            unique_dir = f"/tmp/embedl-{uuid.uuid4().hex}/"
            self.runner.run(["mkdir", "-p", unique_dir], hide=True)
            self._base_dir = RemotePath(unique_dir)
            self._owns_base_dir = True

        try:
            yield self
        finally:
            if self._owns_base_dir and self._base_dir is not None:
                if self.runner is not None:
                    self.runner.run(
                        ["rm", "-rf", str(self._base_dir)], hide=True
                    )
                self._base_dir = None
                self._owns_base_dir = False

            self._active = False
