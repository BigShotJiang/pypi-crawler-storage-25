# Copyright (C) 2026 Embedl AB

"""File transfer and remote path utilities for devices.

This module provides helper functions for transferring directories between
local and remote devices, and for probing remote file-system paths.
"""

from __future__ import annotations

import tarfile
import tempfile
import uuid
from typing import TYPE_CHECKING

from embedl_hub._internal.core.types import LocalPath, RemotePath

if TYPE_CHECKING:
    from embedl_hub._internal.core.device.abc import CommandRunner


def get_directory(
    runner: CommandRunner,
    source: RemotePath,
    destination: LocalPath,
) -> None:
    """Download a remote directory to a local path using a command runner.

    Creates a tarball of the remote directory, transfers it in a single
    operation, and extracts it locally.  A temporary directory is used
    on the local side to stage the tarball.

    :param runner: The command runner to use for the transfer.
    :param source: The remote directory to download.
    :param destination: The local directory to download into.
    """
    destination.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="embedl-get-") as tmp:
        tmp_path = LocalPath(tmp)
        remote_tar = RemotePath(f"/tmp/embedl-xfer-{uuid.uuid4().hex}.tar.gz")
        local_tar = tmp_path / "archive.tar.gz"

        try:
            # Create tarball on the remote device
            runner.run(
                [
                    "tar",
                    "-czf",
                    str(remote_tar),
                    "-C",
                    str(source),
                    ".",
                ],
                hide=True,
            )

            # Transfer the single tarball
            runner.get(remote_tar, local_tar)
        finally:
            # Clean up the remote tarball
            runner.run(["rm", "-f", str(remote_tar)], hide=True)

        # Extract locally
        with tarfile.open(local_tar, "r:gz") as tar:
            tar.extractall(path=destination)  # noqa: S202


def put_directory(
    runner: CommandRunner,
    source: LocalPath,
    destination: RemotePath,
) -> None:
    """Upload a local directory to a remote path using a command runner.

    Creates a local tarball of the source directory, transfers it in a
    single operation, and extracts it on the remote device.  A temporary
    directory is used on the local side to stage the tarball.

    :param runner: The command runner to use for the transfer.
    :param source: The local directory to upload.
    :param destination: The remote directory to upload into.
    """
    runner.run(["mkdir", "-p", str(destination)], hide=True)

    with tempfile.TemporaryDirectory(prefix="embedl-put-") as tmp:
        tmp_path = LocalPath(tmp)
        local_tar = tmp_path / "archive.tar.gz"
        remote_tar = RemotePath(f"/tmp/embedl-xfer-{uuid.uuid4().hex}.tar.gz")

        # Create tarball locally
        with tarfile.open(local_tar, "w:gz") as tar:
            tar.add(str(source), arcname=".")

        try:
            # Transfer the single tarball
            runner.put(local_tar, remote_tar)

            # Extract on the remote device
            runner.run(
                [
                    "tar",
                    "-xzf",
                    str(remote_tar),
                    "-C",
                    str(destination),
                ],
                hide=True,
            )
        finally:
            # Clean up the remote tarball
            runner.run(["rm", "-f", str(remote_tar)], hide=True)


def is_remote_dir(runner: CommandRunner, path: RemotePath) -> bool:
    """Check if a remote path is a directory.

    :param runner: The command runner to use for the check.
    :param path: The remote path to check.
    :return: ``True`` if the path is a directory, ``False`` otherwise.
    """
    try:
        runner.run(["test", "-d", str(path)], hide=True)
    except Exception:
        return False
    return True


def is_remote_file(runner: CommandRunner, path: RemotePath) -> bool:
    """Check if a remote path is a regular file.

    :param runner: The command runner to use for the check.
    :param path: The remote path to check.
    :return: ``True`` if the path is a regular file, ``False`` otherwise.
    """
    try:
        runner.run(["test", "-f", str(path)], hide=True)
    except Exception:
        return False
    return True
