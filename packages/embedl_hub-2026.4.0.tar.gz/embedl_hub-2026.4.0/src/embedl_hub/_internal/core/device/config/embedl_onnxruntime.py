# Copyright (C) 2026 Embedl AB

"""Typed configuration for the ``embedl_onnxruntime`` provider."""

from __future__ import annotations

from dataclasses import dataclass, field

from embedl_hub._internal.core.device.config.abc import ProviderConfig
from embedl_hub._internal.core.types import RemotePath


@dataclass(frozen=True)
class EmbedlONNXRuntimeConfig(ProviderConfig):
    """Configuration for devices using the ``embedl-onnxruntime`` CLI.

    Instances are attached to a :class:`~embedl_hub._internal.core.device.abc.Device`
    via :attr:`~Device.provider_config` (default for all components) and
    optionally overridden per-component in
    :attr:`~Device.provider_config_overrides`.

    :param embedl_onnxruntime_path: Path to the ``embedl-onnxruntime``
        executable on the remote system.  Defaults to
        ``"embedl-onnxruntime"`` (assumes it is on ``$PATH``).
    :param cli_args: Additional device-specific CLI arguments forwarded
        verbatim to the ``embedl-onnxruntime`` tool.
    """

    embedl_onnxruntime_path: RemotePath = RemotePath("embedl-onnxruntime")
    cli_args: tuple[str, ...] = field(default_factory=tuple)
