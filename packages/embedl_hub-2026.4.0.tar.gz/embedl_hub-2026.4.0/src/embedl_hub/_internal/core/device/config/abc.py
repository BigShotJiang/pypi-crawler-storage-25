# Copyright (C) 2026 Embedl AB

"""Base protocol for provider configuration objects."""

from __future__ import annotations


class ProviderConfig:
    """Marker base class for typed provider configurations.

    Each provider defines a frozen dataclass that inherits from this
    class.  The :meth:`Device.get_provider_config` method uses
    :func:`isinstance` against a concrete subclass to narrow the type
    at runtime and satisfy static type-checkers.
    """

    __slots__ = ()
