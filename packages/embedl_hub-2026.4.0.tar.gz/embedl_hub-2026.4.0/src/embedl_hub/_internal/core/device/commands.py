# Copyright (C) 2026 Embedl AB

"""Shared helpers for running commands on remote devices."""

from __future__ import annotations

from collections.abc import Sequence
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from embedl_hub._internal.core.device.abc import (
        CommandResult,
        CommandRunner,
    )


def run_remote_command(
    runner: CommandRunner,
    run_args: Sequence[str],
    artifact_dir: Path,
    *,
    error_cls: type[Exception] = RuntimeError,
    error_message: str = "Remote command failed",
) -> CommandResult:
    """Run a command on a remote device, capturing stdout/stderr.

    On success, writes ``out.txt`` and ``err.txt`` into `artifact_dir`.
    On failure, writes whatever output is available and re-raises with
    a detailed error message.

    :param runner: The command runner to execute the command on.
    :param run_args: The command and arguments to execute.
    :param artifact_dir: Local directory to write ``out.txt`` / ``err.txt``.
    :param error_cls: Exception class to raise on failure.
    :param error_message: Human-readable prefix for the error message.
    :return: The :class:`~embedl_hub._internal.core.device.abc.CommandResult`
        from the successful execution.
    :raises error_cls: If the command fails.
    """
    out_file = artifact_dir / "out.txt"
    err_file = artifact_dir / "err.txt"

    try:
        result = runner.run(run_args)
    except Exception as error:
        stdout = getattr(error, "stdout", "") or ""
        stderr = getattr(error, "stderr", "") or ""
        if stdout:
            out_file.write_text(stdout)
        if stderr:
            err_file.write_text(stderr)
        detail = stderr.strip() or stdout.strip() or str(error)
        raise error_cls(f"{error_message}\n{detail}") from error

    stdout = getattr(result, "stdout", "") or ""
    stderr = getattr(result, "stderr", "") or ""
    out_file.write_text(stdout)
    err_file.write_text(stderr)
    return result
