# Copyright (C) 2025, 2026 Embedl AB

"""Module for ONNX related helper functions."""

from pathlib import Path

import onnx

from embedl_hub._internal.core.hub_logging import console


def load_onnx_model(model_path: Path) -> onnx.ModelProto:
    """Load an ONNX model from a file or directory.

    If a directory is provided, it expects exactly one ``.onnx`` file
    inside.

    :param model_path: Path to the ONNX model file or directory.
    :return: Loaded ONNX model.
    :raises ValueError: If `model_path` is invalid or does not contain
        a valid ``.onnx`` file.
    """

    if model_path.is_file():
        if model_path.suffix.lower() != ".onnx":
            raise ValueError(f"Expected a .onnx file, got: {model_path.name}")
        return onnx.load(model_path)
    if not model_path.is_dir():
        raise ValueError(
            f"Model path must be a file or directory: {model_path}"
        )
    onnx_files = sorted([p for p in model_path.glob("*.onnx") if p.is_file()])
    if not len(onnx_files) == 1:
        raise ValueError(
            f"Expected exactly one ONNX file in directory, found: {len(onnx_files)}"
        )
    return onnx.load(onnx_files[0])


def maybe_package_onnx_folder_to_file(
    model_path: Path, dest_folder: Path | str
) -> Path:
    """Repackage a directory ONNX model into a single ``.onnx`` file.

    If `model_path` is already a file, it is returned as-is.  If it is a
    directory, the model is loaded and saved as a single file inside
    `dest_folder`.

    :param model_path: Path to an ``.onnx`` file or a directory containing one.
    :param dest_folder: Directory for the repackaged file.
    :return: Path to the ``.onnx`` file (original or newly created).
    """
    if model_path.is_dir():
        console.log("Directory model detected. Looking for ONNX file...")
        # Repackage directory onnx model into a single .onnx file
        onnx_model = load_onnx_model(model_path)
        new_onnx_path = (
            Path(dest_folder) / model_path.with_suffix(".onnx").name
        )
        onnx.save(onnx_model, new_onnx_path)
        console.log("ONNX model found and validated.")
        return new_onnx_path
    return model_path
