# Copyright (C) 2025, 2026 Embedl AB

"""Utility functions for Qualcomm AI Hub integration."""

from __future__ import annotations

import shutil
import zipfile
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import TYPE_CHECKING

import onnx
import qai_hub as hub
import qai_hub.public_api_pb2 as hub_pb
import qai_hub.public_rest_api as hub_api
from qai_hub.client import Client, Model
from qai_hub.hub import _global_client

if TYPE_CHECKING:
    from embedl_hub._internal.core.context import HubContext
    from embedl_hub._internal.tracking.client import Client as TrackingClient

QAI_HUB_RUNTIME_NAMES = ["ONNX Runtime", "TensorFlow Lite", "QNN"]


def get_global_qai_hub_client() -> Client:
    """Get the global Qualcomm AI Hub API client."""
    return _global_client


def get_job_result(
    job_id: str, client_config: hub_api.ClientConfig
) -> hub_pb.JobResult:
    """Get the protobuf result of a Qualcomm AI Hub job.

    Used to retrieve information about a job that is otherwise not
    exposed by the ``qai_hub`` package's public API.

    :param job_id: The QAI Hub job ID.
    :param client_config: QAI Hub client configuration.
    :return: The job result protobuf message.
    """
    # pylint: disable-next=protected-access
    job_result: hub_pb.JobResult = hub.client._api_call(
        hub_api.get_job_results, client_config, job_id
    )
    return job_result


def parse_runtime_info(job_result: hub_pb.JobResult) -> str:
    """Extract the runtime name from a QAI Hub job result.

    :param job_result: The protobuf job result.
    :return: The recognized runtime name (e.g. ``"ONNX Runtime"``).
    :raises RuntimeError: If no recognized runtime is found.
    """

    runtime = None

    job_type = job_result.WhichOneof("result")

    job_runtime_names = []

    if job_type == "compile_job_result":
        job_runtime_names = [
            tool.name
            for tool in job_result.compile_job_result.compile_detail.tool_versions
        ]
    elif job_type == "profile_job_result":
        job_runtime_names = [
            runtime.name
            for runtime in job_result.profile_job_result.profile.runtime_config
        ]
    elif job_type == "inference_job_result":
        job_runtime_names = [
            runtime.name
            for runtime in job_result.inference_job_result.detail.runtime_config
        ]
    else:
        raise RuntimeError(f"Unrecognized job type: {job_type}.")

    for expected_runtime_name in QAI_HUB_RUNTIME_NAMES:
        if expected_runtime_name in job_runtime_names:
            runtime = expected_runtime_name
            break

    if runtime is None:
        raise RuntimeError(
            f"No recognized runtime in job result: {job_runtime_names}. "
            f"Expected one of: {QAI_HUB_RUNTIME_NAMES}."
        )

    return runtime


def create_device(device_name: str) -> hub.Device:
    """Create and validate a QAI Hub device by name.

    :param device_name: The device name (e.g. ``"Samsung Galaxy S24"``).
    :return: A :class:`qai_hub.Device` instance.
    :raises ValueError: If the device name is not recognized.
    """
    all_device_names = [d.name for d in hub.get_devices()]
    if device_name not in all_device_names:
        raise ValueError(
            f"Device name '{device_name}' not recognized. "
            "Use `embedl-hub list-devices` to see available devices."
        )
    return hub.Device(device_name)


def unzip_if_zipped(
    model_path: Path,
    tmp_folder: Path,
    *,
    target_extension: str = ".onnx",
) -> Path:
    """Unzip the model if it is a zip file and return the model file path.

    :param model_path: Path to the model file (or zip archive).
    :param tmp_folder: Temporary folder used for extraction.
    :param target_extension: The model file extension to look for inside
        the zip archive.  Defaults to ``'.onnx'``.
    :return: Path to the extracted (or original) model file.
    """
    if model_path.suffix == ".zip":
        with zipfile.ZipFile(model_path, "r") as zip_ref:
            extract_path = tmp_folder / model_path.stem
            zip_ref.extractall(extract_path)
            subfolders = [f for f in extract_path.iterdir() if f.is_dir()]
            if len(subfolders) != 1:
                raise RuntimeError(
                    f"Expected exactly one folder in the zip, found: {len(subfolders)}"
                )
            only_folder = subfolders[0]
            model_files = list(only_folder.rglob(f"*{target_extension}"))
            if len(model_files) != 1:
                raise RuntimeError(
                    f"Expected exactly one {target_extension} file, "
                    f"found: {len(model_files)}"
                )
            return model_files[0]
    return model_path


def save_qai_hub_model(
    model: Model,
    output_file: Path | str | None = None,
) -> Path:
    """Save a Qualcomm AI Hub model to a local file.

    If the model is a zip archive it will be extracted.  Small models
    are saved as a single ``.onnx`` file; large models are saved in a
    folder with an external data file.

    :param model: The QAI Hub model object to save.
    :param output_file: Destination path.  Defaults to
        ``<cwd>/<model.name>``.
    :return: Path to the saved model file (or folder).
    """

    if output_file is None:
        output_file = Path.cwd() / model.name
    else:
        output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with TemporaryDirectory() as tmpdir:
        tmp_file = Path(tmpdir) / "model"
        tmp_zip = model.download(str(tmp_file))
        model_file = unzip_if_zipped(Path(tmp_zip), Path(tmpdir))
        if model_file.suffix != ".onnx":
            shutil.copy2(model_file, output_file)
            return output_file
        onnx_model = onnx.load(model_file)
        try:
            onnx.save_model(onnx_model, output_file)
            return output_file
        except Exception:
            # Model too large to save as single file, save as folder
            output_folder = output_file.with_suffix("")
            output_folder.mkdir(parents=True, exist_ok=True)
            output_file = (output_folder / model.name).with_suffix(".onnx")
            data_file = output_file.with_suffix(".data")
            onnx.save_model(
                onnx_model,
                output_file,
                save_as_external_data=True,
                location=data_file.name,
            )
            return output_folder


def save_qai_hub_tflite_model(
    model: Model,
    output_file: Path | str | None = None,
) -> Path:
    """Save a Qualcomm AI Hub model as a TFLite file.

    Downloads the model from QAI Hub, extracts the ``.tflite`` file if
    the download is a zip archive, and copies it to *output_file*.

    :param model: The QAI Hub model to save.
    :param output_file: Destination path.  Defaults to
        ``<cwd>/<model.name>``.
    :return: Path to the saved ``.tflite`` file.
    """
    if output_file is None:
        output_file = Path.cwd() / model.name
    else:
        output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with TemporaryDirectory() as tmpdir:
        tmp_file = Path(tmpdir) / "model"
        tmp_zip = model.download(str(tmp_file))
        model_file = unzip_if_zipped(
            Path(tmp_zip), Path(tmpdir), target_extension=".tflite"
        )
        shutil.copy2(model_file, output_file)
    return output_file


# ---------------------------------------------------------------------------
# Shared QAI Hub provider helpers
# ---------------------------------------------------------------------------


def resolve_qai_hub_device(
    ctx: HubContext,
    device: str | None,
) -> tuple[hub.Device, str]:
    """Validate and resolve a QAI Hub device from the component context.

    Performs the standard validation sequence used by every QAI Hub
    provider function:

    1. Assert *device* is not ``None``.
    2. Look up the :class:`Device` in the context.
    3. Extract and validate the ``device_name`` from its spec.
    4. Create a ``qai_hub.Device`` and log the ``$device`` param.

    :param ctx: The execution context.
    :param device: The device key in ``ctx.devices``.
    :return: A ``(hub_device, device_name)`` pair.
    :raises ValueError: If `device` is ``None`` or the device spec has
        no ``device_name``.
    """
    assert device is not None
    dev = ctx.devices[device]
    device_name = dev.spec.device_name
    if device_name is None:
        raise ValueError("Device spec must have a device_name.")
    hub_device = create_device(device_name)
    ctx.client.log_param("$device", device_name)
    return hub_device, device_name


def log_runtime_info(
    client: TrackingClient,
    job_id: str,
    *,
    error_class: type[Exception] = RuntimeError,
) -> str:
    """Extract and log QAI Hub runtime info for a completed job.

    Fetches the job result from QAI Hub, extracts the runtime name,
    and logs it as the ``$runtime`` parameter.

    :param client: The tracking client (``ctx.client``).
    :param job_id: The QAI Hub job ID.
    :param error_class: Exception class to raise on failure
        (defaults to :class:`RuntimeError`).
    :return: The runtime name string (e.g. ``"ONNX Runtime"``).
    :raises error_class: If the runtime info cannot be extracted.
    """
    try:
        job_result = get_job_result(job_id, get_global_qai_hub_client().config)
        runtime = parse_runtime_info(job_result)
    except RuntimeError as exc:
        raise error_class(
            f"Failed to extract runtime info from QAI Hub job {job_id}."
        ) from exc
    client.log_param("$runtime", runtime)
    return runtime
