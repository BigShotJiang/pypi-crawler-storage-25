# Copyright (C) 2025, 2026 Embedl AB

"""Module for loading and generating calibration data."""

from pathlib import Path

import numpy as np
from ai_edge_litert.interpreter import Interpreter

from embedl_hub._internal.core.utils.onnx_utils import load_onnx_model


def generate_random_calibration_data(
    model_path: Path,
) -> dict[str, list[np.ndarray]]:
    """Generate a single random calibration sample from ONNX model inputs.

    Inspects the model's input tensor shapes and produces random float32
    arrays with matching dimensions.  Dynamic dimensions (``0`` or ``-1``)
    are replaced with ``1``.

    :param model_path: Path to the ONNX model file.
    :return: A dict mapping input names to single-element lists of
        :class:`numpy.ndarray`.
    """
    onnx_model = load_onnx_model(model_path)
    calibration_data: dict[str, list[np.ndarray]] = {}
    for model_input in onnx_model.graph.input:
        input_shape = [
            dim.dim_value if dim.dim_value > 0 else 1
            for dim in model_input.type.tensor_type.shape.dim
        ]
        calibration_data[model_input.name] = [
            np.random.rand(*input_shape).astype(np.float32)
        ]
    return calibration_data


def load_calibration_dataset(
    data_path: Path,
    input_names: list[str],
) -> dict[str, list[np.ndarray]]:
    """Load calibration data from a directory of ``.npy`` files.

    For single-input models, `data_path` should contain ``.npy`` files
    directly.  For multi-input models, `data_path` should contain one
    subdirectory per input (named after the input), each holding
    ``.npy`` files.

    :param data_path: Path to the calibration data directory.
    :param input_names: List of model input names to load data for.
    :return: A dict mapping input names to lists of
        :class:`numpy.ndarray`.
    :raises ValueError: If `data_path` is invalid.
    :raises FileNotFoundError: If expected ``.npy`` files or
        subdirectories are missing.
    """
    if not data_path or not data_path.is_dir():
        raise ValueError(f"Invalid data path: {data_path}")

    if len(input_names) == 1:
        # Single input model
        input_name = input_names[0]
        npy_files = sorted(data_path.glob("*.npy"))
        if not npy_files:
            raise FileNotFoundError(f"No .npy files found in {data_path}")
        return {input_name: [np.load(f) for f in npy_files]}

    # Multiple input model
    datasets = {}
    num_input_samples = set()
    for input_name in input_names:
        input_dir = data_path / input_name
        if not input_dir.is_dir():
            raise FileNotFoundError(
                f"Input directory not found for input '{input_name}': {input_dir}"
            )
        npy_files = sorted(input_dir.glob("*.npy"))
        if not npy_files:
            raise FileNotFoundError(f"No .npy files found in {input_dir}")
        datasets[input_name] = [np.load(f) for f in npy_files]
        num_input_samples.add(len(datasets[input_name]))

    if len(num_input_samples) != 1:
        raise ValueError("All inputs must have the same number of samples.")
    return datasets


def load_onnx_calibration_data(
    model_path: Path,
    data_path: Path,
) -> dict[str, list[np.ndarray]]:
    """Load calibration data for an ONNX model.

    Reads the model's input names and delegates to
    :func:`load_calibration_dataset`.

    :param model_path: Path to the ONNX model.
    :param data_path: Path to the calibration data directory.
    :return: A dict mapping input names to lists of
        :class:`numpy.ndarray`.
    """

    onnx_model = load_onnx_model(model_path=model_path)
    input_names = [i.name for i in onnx_model.graph.input]
    return load_calibration_dataset(
        data_path=data_path,
        input_names=input_names,
    )


def load_tflite_calibration_data(
    interpreter: Interpreter,
    data_path: Path,
) -> list[dict[str, np.ndarray]]:
    """Load calibration data for a TFLite model.

    Reads the model's input names from the interpreter's signature and
    delegates to :func:`load_calibration_dataset`.  The result is
    re-shaped into a per-sample list of dictionaries.

    :param interpreter: A TFLite interpreter for the model.
    :param data_path: Path to the calibration data directory.
    :return: A list of dicts, one per sample, mapping input names to
        :class:`numpy.ndarray`.
    """

    signatures: dict[str, dict[str, list[str]]] = (
        interpreter.get_signature_list()
    )
    signature_key = list(signatures.keys())[0]
    input_names = signatures[signature_key]['inputs']

    calibration_data = load_calibration_dataset(
        data_path=data_path,
        input_names=input_names,
    )
    return [
        {name: calibration_data[name][i] for name in input_names}
        for i in range(len(calibration_data[input_names[0]]))
    ]
