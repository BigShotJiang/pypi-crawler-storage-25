# Copyright (C) 2025, 2026 Embedl AB

"""Core module for Embedl Hub."""
