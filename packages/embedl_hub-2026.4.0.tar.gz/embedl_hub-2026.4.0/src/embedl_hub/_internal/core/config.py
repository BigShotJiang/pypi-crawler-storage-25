# Copyright (C) 2025, 2026 Embedl AB

"""Application configuration persistence.

Provides helpers for reading and writing the on-disk config and state
files used by both the CLI and the tracking client, as well as
resolving the artifact directory from the persisted config.
"""

from pathlib import Path

import platformdirs
import yaml

from embedl_hub._internal.core.hub_logging import console

APP_NAME = "embedl-hub"
CONFIG_FILE = platformdirs.user_config_path(APP_NAME) / "config.yaml"
STATE_FILE = platformdirs.user_data_path(APP_NAME) / "state.yaml"
DEFAULT_ARTIFACT_DIR = platformdirs.user_data_path(APP_NAME) / "artifacts"


def get_artifact_dir(config: dict[str, str]) -> Path:
    """Return the configured artifact directory, falling back to the default.

    :param config: The loaded CLI config dict.
    :return: Resolved artifact directory as an absolute path.
    """
    raw = config.get("artifact_dir", "")
    if raw:
        return Path(raw).expanduser().resolve()
    return DEFAULT_ARTIFACT_DIR


def get_project_dir(
    config: dict[str, str],
    project_name: str | None = None,
) -> Path:
    """Return the project-scoped artifact directory.

    Runs are stored under ``<artifact_dir>/<project_name>/``.

    :param config: The loaded CLI config dict.
    :param project_name: Override for the project name.  Falls back to
        the ``project_name`` key in *config*.
    :return: ``get_artifact_dir(config) / project_name``.
    """
    name = project_name or config.get("project_name", "")
    base = get_artifact_dir(config)
    if not name:
        return base
    return base / name


def _write_to_file(path: Path, content: dict[str, str]) -> None:
    """Write dict to YAML, creating parent directories if needed."""
    if not path.exists():
        console.print(f"File not found. Creating: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(yaml.safe_dump(content, sort_keys=False), encoding="utf-8")


def _read_from_file(path: Path) -> dict[str, str]:
    """Read dict from YAML, and return empty if file does not exist."""
    return (
        yaml.safe_load(path.read_text(encoding="utf-8"))
        if path.exists()
        else {}
    )


def write_ctx_config(config: dict[str, str]) -> None:
    """Persist the current ``ctx.config`` object to file."""
    _write_to_file(CONFIG_FILE, config)


def write_ctx_state(state: dict[str, str]) -> None:
    """Persist the current ``ctx.state`` object to file."""
    _write_to_file(STATE_FILE, state)


def load_ctx_config() -> dict[str, str]:
    """Read persisted ``ctx.config`` from file."""
    return _read_from_file(CONFIG_FILE)


def load_ctx_state() -> dict[str, str]:
    """Read persisted ``ctx.state`` from file."""
    return _read_from_file(STATE_FILE)
