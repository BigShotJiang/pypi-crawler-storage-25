# Copyright (C) 2026 Embedl AB

"""TensorRT compiler component.

Supports compilation via:
- **``trtexec``** devices: Remote compilation using ``trtexec``
  over SSH.
"""

from __future__ import annotations

import re
from collections.abc import Collection
from dataclasses import dataclass
from pathlib import Path

from packaging.version import Version

from embedl_hub._internal.core.compile.result import CompileError
from embedl_hub._internal.core.component.abc import Component, NoProviderError
from embedl_hub._internal.core.component.output import CompiledModel
from embedl_hub._internal.core.component.provider_type import ProviderType
from embedl_hub._internal.core.context import HubContext
from embedl_hub._internal.core.device.abc import CommandRunner
from embedl_hub._internal.core.device.commands import run_remote_command
from embedl_hub._internal.core.device.config.trtexec import TrtexecConfig
from embedl_hub._internal.core.types import LocalPath, RemotePath
from embedl_hub._internal.tracking.rest_api import RunType


def _validate_no_duplicate_flags(run_args: list[str]) -> None:
    """Validate that *run_args* does not contain duplicate CLI flags.

    :param run_args: The full argument list to check.
    :raises ValueError: If any ``--flag`` appears more than once.
    """
    options = [
        arg.split("=", maxsplit=1)[0]
        for arg in run_args
        if arg.startswith("--")
    ]
    seen: set[str] = set()
    duplicates: set[str] = set()
    for option in options:
        if option in seen:
            duplicates.add(option)
        else:
            seen.add(option)
    if duplicates:
        raise ValueError(
            "Found duplicate option(s): "
            f"{', '.join(sorted(duplicates))}. "
            "Each option should only be provided once."
        )


def _validate_trtexec_args(
    trtexec_cli_args: Collection[str],
) -> None:
    """Validate ``trtexec`` CLI arguments for internally reserved flags.

    :param trtexec_cli_args: CLI arguments to validate.
    :raises ValueError: If any reserved flag is present.
    """
    trtexec_options = [
        arg.split("=", maxsplit=1)[0] for arg in trtexec_cli_args
    ]
    issues: list[str] = []

    if "--onnx" in trtexec_options:
        issues.append(
            "--onnx: the model path is set internally and should not "
            "be provided via trtexec_cli_args."
        )
    if "--buildOnly" in trtexec_options:
        issues.append(
            "--buildOnly: set internally based on the TensorRT version."
        )
    if "--skipInference" in trtexec_options:
        issues.append(
            "--skipInference: set internally based on the TensorRT version."
        )
    if "--saveEngine" in trtexec_options:
        issues.append(
            "--saveEngine: set internally and should not be provided."
        )

    if issues:
        raise ValueError(
            "Invalid parameters in 'trtexec_cli_args':\n" + "\n".join(issues)
        )


def _detect_tensorrt_version(
    runner: CommandRunner,
    trtexec_path: str,
) -> str:
    """Detect the TensorRT version by running ``trtexec --help``.

    :param runner: The device command runner.
    :param trtexec_path: Path to the ``trtexec`` binary.
    :return: A dotted version string (e.g. ``"10.8.0"``).
    :raises RuntimeError: If the version cannot be determined.
    """
    result = runner.run([trtexec_path, "--help"], hide=True)
    version_pattern = r"(8|10)((?<=8)\d|(?<=10)\d\d)(\d\d)"
    versions = re.findall(rf"\[TensorRT v{version_pattern}\]", result.stdout)
    if len(versions) != 1:
        raise RuntimeError(
            "Could not determine TensorRT version by running "
            f"'{trtexec_path} --help'. Please specify 'tensorrt_version' "
            "explicitly."
        )
    return str(Version(".".join(versions[0])))


@dataclass(frozen=True)
class TensorRTCompiledModel(CompiledModel):
    """Output from the TensorRTCompiler component.

    :param graph_file: The artifact containing the engine graph JSON
        (from ``--exportLayerInfo``), if available.
    """


class TensorRTCompiler(Component):
    """Component that compiles ONNX models to TensorRT engines.

    Runs ``trtexec`` on a remote device over SSH to convert an ``.onnx``
    model into a ``.trt`` engine file.

    Provider-specific parameters (``trtexec_path``, ``trtexec_cli_args``)
    are configured via :class:`~embedl_hub._internal.core.device.config.trtexec.TrtexecConfig`
    on the device.  Per-component overrides can be set via
    :attr:`~Device.provider_config_overrides`.
    """

    run_type = RunType.COMPILE

    def __init__(
        self,
        *,
        name: str | None = None,
        device: str | None = None,
        tensorrt_version: str | None = None,
        calib_path: Path | None = None,
    ) -> None:
        """Create a new TensorRT compiler.

        Parameters passed here become the defaults for every
        :meth:`run` call.  They can be overridden per call by passing
        them to :meth:`run` directly.

        :param name: Display name for this compiler instance.  Defaults
            to the class name.
        :param device: Name of the target device.  When ``None``,
            auto-selects the first compatible device.
        :param tensorrt_version: The TensorRT version to target.  When
            ``None`` the compiler auto-detects the version by running
            ``trtexec --help`` on the remote device.
        :param calib_path: Optional *local* path to a TensorRT INT8
            calibration ``.cache`` file.  This file contains
            pre-computed per-tensor dynamic ranges (scale factors)
            needed by ``trtexec`` when ``--int8`` is enabled.
            It must be generated externally using the TensorRT
            Python API (e.g. ``trt.IInt8EntropyCalibrator2``) from
            your calibration dataset before calling the compiler.
        """
        super().__init__(
            name=name,
            device=device,
            tensorrt_version=tensorrt_version,
            calib_path=calib_path,
        )

    def run(
        self,
        ctx: HubContext,
        onnx_path: Path,
        *,
        device: str | None = None,
        tensorrt_version: str | None = None,
        calib_path: Path | None = None,
    ) -> TensorRTCompiledModel:
        """Compile an ONNX model to a TensorRT engine.

        Keyword arguments override the defaults set in the constructor.
        If a keyword argument is not provided here, the constructor
        default is used.

        :param ctx: The execution context with device configuration.
        :param onnx_path: Local path to the input ONNX model.
        :param device: Name of the target device (overrides the
            constructor default).
        :param tensorrt_version: The TensorRT version to target.  When
            ``None`` the compiler auto-detects the version by running
            ``trtexec --help`` on the remote device.
        :param calib_path: Optional *local* path to a TensorRT INT8
            calibration ``.cache`` file containing pre-computed
            per-tensor dynamic ranges.  The cache must be generated
            externally using the TensorRT Python API (e.g.
            ``trt.IInt8EntropyCalibrator2``) from your calibration
            dataset.
        :return: A :class:`TensorRTCompiledModel` with the compiled
            engine path.
        """
        raise NoProviderError  # Replaced by the component system.


# --------------------------------------------------------------------- #
# trtexec provider
# --------------------------------------------------------------------- #


@TensorRTCompiler.provider(ProviderType.TRTEXEC)
def _compile_tensorrt_cli(
    ctx: HubContext,
    onnx_path: Path,
    *,
    device: str | None = None,
    tensorrt_version: str | None = None,
    calib_path: Path | None = None,
) -> TensorRTCompiledModel:
    """Compile an ONNX model to a TensorRT engine via ``trtexec``.

    All keyword arguments are pre-resolved by the component system: call-time
    values override constructor defaults.

    :param ctx: The execution context with device configuration.
    :param onnx_path: Local path to the input ONNX model.
    :param tensorrt_version: Override the TensorRT version.
    :param calib_path: Override the calibration cache path.
    :return: A :class:`TensorRTCompiledModel` with the compiled engine.
    :raises CompileError: If compilation fails.
    :raises ValueError: If the device or runner is not configured.
    """
    # -- validate device ------------------------------------------------
    dev = ctx.devices[device]
    runner = dev.runner
    if runner is None:
        raise ValueError(
            "trtexec devices require a device with a command runner."
        )
    remote_artifact_dir = dev.artifact_dir
    if remote_artifact_dir is None:
        raise ValueError("No remote artifact directory available.")

    # -- resolve provider config ----------------------------------------
    cfg = dev.get_provider_config(TrtexecConfig, TensorRTCompiler)
    if cfg is None:
        cfg = TrtexecConfig()
    trtexec_path = str(cfg.trtexec_path)
    effective_cli_args: list[str] = list(cfg.trtexec_cli_args)

    # -- log input artifact ---------------------------------------------
    ctx.client.log_artifact(
        onnx_path, name="input", file_name=f"input_{onnx_path.name}"
    )

    # -- detect / resolve TensorRT version ------------------------------
    effective_version = tensorrt_version
    if effective_version is None:
        effective_version = _detect_tensorrt_version(runner, trtexec_path)

    # -- compile --------------------------------------------------------
    local_engine_path = _run_remote_compilation(
        ctx,
        runner=runner,
        onnx_path=onnx_path,
        remote_artifact_dir=remote_artifact_dir,
        trtexec_path=trtexec_path,
        trtexec_cli_args=effective_cli_args,
        tensorrt_version=effective_version,
        calib_path=calib_path,
    )

    # -- log output artifact --------------------------------------------
    ctx.client.log_artifact(local_engine_path, name="path")

    return TensorRTCompiledModel.from_current_run(ctx)


# --------------------------------------------------------------------- #
# internal helpers
# --------------------------------------------------------------------- #


def _run_remote_compilation(
    ctx: HubContext,
    *,
    runner: CommandRunner,
    onnx_path: Path,
    remote_artifact_dir: RemotePath,
    trtexec_path: str,
    trtexec_cli_args: list[str],
    tensorrt_version: str,
    calib_path: Path | None,
) -> Path:
    """Upload the model, run ``trtexec``, and download the engine.

    :param ctx: The execution context.
    :param runner: The device command runner.
    :param onnx_path: Local path to the input ONNX model.
    :param remote_artifact_dir: Remote directory for artifacts.
    :param trtexec_path: Path to ``trtexec`` on the remote device.
    :param trtexec_cli_args: Extra CLI arguments for ``trtexec``.
    :param tensorrt_version: The resolved TensorRT version string.
    :param calib_path: Optional local calibration cache file.
    :return: Local path to the downloaded ``.trt`` engine file.
    :raises CompileError: If the remote command fails.
    """
    # Upload the ONNX model
    remote_onnx = remote_artifact_dir / onnx_path.name
    runner.put(LocalPath(onnx_path), remote_onnx)

    # Ensure model path points to an .onnx file
    model_arg = remote_onnx
    if model_arg.suffix != ".onnx":
        model_arg = model_arg / "model.onnx"

    # Determine compile-only flag based on TensorRT version
    compile_only_flag = (
        "--buildOnly"
        if Version(tensorrt_version) < Version("8.6.0")
        else "--skipInference"
    )

    # Build the engine output path
    remote_engine = model_arg.with_suffix(".trt")

    # Assemble the full trtexec command
    run_args: list[str] = [
        trtexec_path,
        compile_only_flag,
        f"--onnx={model_arg}",
        f"--saveEngine={remote_engine}",
        "--exportLayerInfo=trt_engine_graph.json",
        "--profilingVerbosity=detailed",
    ]
    run_args.extend(trtexec_cli_args)

    # Upload calibration cache if provided
    if calib_path is not None:
        remote_calib = remote_artifact_dir / calib_path.name
        runner.put(LocalPath(calib_path), remote_calib)
        run_args.append(f"--calib={remote_calib}")

    # Validate arguments
    _validate_trtexec_args(trtexec_cli_args)
    _validate_no_duplicate_flags(run_args)

    # Log parameters
    ctx.client.log_param("$runtime", "tensorrt")
    ctx.client.log_param("trtexec_path", trtexec_path)
    ctx.client.log_param("tensorrt_version", tensorrt_version)
    if trtexec_cli_args:
        ctx.client.log_param("trtexec_cli_args", " ".join(trtexec_cli_args))
    if calib_path is not None:
        ctx.client.log_param("calib_path", str(calib_path))

    # Execute trtexec on the remote device
    local_artifact_dir = ctx.artifact_dir
    result = run_remote_command(
        runner,
        run_args,
        local_artifact_dir,
        error_cls=CompileError,
        error_message="TensorRT compilation failed on the remote device.",
    )

    # Download the compiled engine
    local_engine_path = local_artifact_dir / remote_engine.name
    runner.get(remote_engine, local_engine_path)

    # Download the graph file if it was produced
    remote_graph = remote_artifact_dir / "trt_engine_graph.json"
    local_graph = local_artifact_dir / "trt_engine_graph.json"
    try:
        runner.get(remote_graph, local_graph)
    except Exception:
        pass  # Graph export is optional; don't fail compilation

    return local_engine_path
