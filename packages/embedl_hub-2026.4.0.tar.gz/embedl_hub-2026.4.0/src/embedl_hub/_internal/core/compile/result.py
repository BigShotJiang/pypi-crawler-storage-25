# Copyright (C) 2025, 2026 Embedl AB

"""Result and error types for model compilation."""

from dataclasses import dataclass
from pathlib import Path


class CompileError(RuntimeError):
    """Raised when a compile job fails or times out."""


@dataclass
class CompileResult:
    """Result of a successful compile job."""

    model_path: Path  # local .tflite, .bin, or .onnx after compile
    job_id: str | None = None
    device: str | None = None
