# Copyright (C) 2025, 2026 Embedl AB

"""Convert ONNX models to TensorFlow/TFLite format."""

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

import numpy as np

# TODO: Remove this try-except when `onnx2tf` and/or `tf-keras` has updated
#       requirements to require a compatible TensorFlow version.
try:
    # pylint: disable-next=unused-import
    import tf_keras
except ImportError as e:
    raise ImportError(
        "tf-keras is required for ONNX to TFLite conversion. "
        "Please install it via 'pip install tf-keras --no-deps'."
    ) from e

import onnx2tf
import tensorflow as tf

from embedl_hub._internal.core.compile.result import CompileResult


@contextmanager
def _patch_test_image_download() -> Iterator[None]:
    """Replace ``onnx2tf``'s test-image download with local dummy data.

    ``onnx2tf`` 1.28.3 downloads a calibration ``.npy`` file from a
    GitHub release URL that no longer exists (returns 404).  The library
    does not check the HTTP status code, so it feeds the raw error page
    bytes into ``np.load``, which crashes.

    The downloaded data is only used for optional ONNX-vs-TF output
    validation (``check_onnx_tf_outputs_elementwise_close``, which
    defaults to ``False``), so replacing it with random dummy data of
    the expected shape (20, 128, 128, 3) float32 is safe.

    .. note::
        This is a workaround for the pinned ``onnx2tf==1.28.3``.
        Remove this when ``onnx2tf`` is upgraded to a version with
        working download URLs or that no longer requires this file.
    """

    def _dummy_test_image_data() -> np.ndarray:
        return np.random.default_rng(0).random(
            (20, 128, 128, 3), dtype=np.float32
        )

    with patch(
        "onnx2tf.onnx2tf.download_test_image_data",
        side_effect=_dummy_test_image_data,
    ):
        yield


def compile_onnx_to_tflite(
    onnx_model_path: Path,
    output_model_path: Path | None = None,
    fp16: bool = True,
) -> CompileResult:
    """Convert an ONNX model to TFLite format.

    Uses ``onnx2tf`` to convert the model to a TensorFlow SavedModel,
    then uses the TensorFlow Lite converter to produce the final
    ``.tflite`` file.

    :param onnx_model_path: Path to the input ONNX model file.
    :param output_model_path: Path to save the converted TFLite model.
        When ``None``, the output path is derived from `onnx_model_path`
        with a ``.tflite`` (or ``.fp16.tflite``) suffix.
    :param fp16: Whether to apply float16 quantization during
        conversion.  Defaults to ``True``.
    :return: A :class:`~embedl_hub._internal.core.compile.result.CompileResult`
        with the path to the converted model.
    """

    if output_model_path is None:
        new_suffix = ".fp16.tflite" if fp16 else ".tflite"
        output_model_path = onnx_model_path.with_suffix(new_suffix)
    with TemporaryDirectory() as tmpdir:
        # Onnx -> TF SavedModel
        # (Onnx2tf is not able to provide correct signatures during TFLite conversion)
        try:
            with _patch_test_image_download():
                onnx2tf.convert(
                    input_onnx_file_path=onnx_model_path,
                    output_folder_path=tmpdir,
                    output_signaturedefs=True,
                )
        except ValueError as e:
            if "axes don't match array" in str(e):
                raise RuntimeError(
                    "The ONNX model might be missing the 'kernel_shape' attribute in convolution layers. "
                    "This is a known issue when exporting with `dynamo=True` in PyTorch. "
                    "See https://github.com/pytorch/pytorch/issues/169824 for more details."
                ) from e
            raise e

        # TF SavedModel -> TFLite (With correct signatures)
        converter = tf.lite.TFLiteConverter.from_saved_model(str(tmpdir))
        if fp16:
            converter.optimizations = [tf.lite.Optimize.DEFAULT]
            converter.target_spec.supported_ops = [
                tf.lite.OpsSet.TFLITE_BUILTINS
            ]
            converter.target_spec.supported_types = [tf.float16]
        tflite_model = converter.convert()
        with open(output_model_path, "wb") as f:
            f.write(tflite_model)

    return CompileResult(model_path=output_model_path)
