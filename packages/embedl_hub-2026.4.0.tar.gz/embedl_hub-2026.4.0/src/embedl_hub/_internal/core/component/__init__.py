# Copyright (C) 2026 Embedl AB

"""Component module for Embedl Hub.

Public symbols are re-exported from :mod:`embedl_hub.core.component`.
"""
