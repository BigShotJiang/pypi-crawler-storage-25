# Copyright (C) 2026 Embedl AB

"""Provider type identifiers for component dispatch.

Each :class:`ProviderType` value corresponds to a backend that
can execute a component's workload.  Components register
implementation functions under one of these identifiers via the
:meth:`~Component.provider` decorator, and the correct
implementation is selected automatically based on the device's
``provider_type``.
"""

from __future__ import annotations

from enum import Enum


class ProviderType(str, Enum):
    """Well-known provider types.

    Inherits from ``str`` so that values compare naturally with plain
    strings and can be used as dictionary keys alongside raw strings.
    """

    def __str__(self) -> str:
        return self.value

    LOCAL = "local"
    """Local execution — no remote device required."""

    QAI_HUB = "qai_hub"
    """Qualcomm AI Hub cloud execution."""

    AWS = "aws"
    """Embedl device cloud (AWS Device Farm)."""

    EMBEDL_ONNXRUNTIME = "embedl_onnxruntime"
    """Remote execution via ``embedl-onnxruntime`` over SSH."""

    TRTEXEC = "trtexec"
    """Remote execution via ``trtexec`` over SSH."""
