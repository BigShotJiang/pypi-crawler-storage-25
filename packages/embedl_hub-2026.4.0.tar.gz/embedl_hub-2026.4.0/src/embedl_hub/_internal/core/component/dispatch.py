# Copyright (C) 2026 Embedl AB

"""Internal dispatch logic for component execution.

This module contains the dispatch function that routes
:meth:`~embedl_hub._internal.core.component.abc.Component.run` invocations to
the appropriate device-specific implementation, together with helpers
for artifact-directory management, input logging, and run-log
population.
"""

from __future__ import annotations

import functools
import inspect
import time
from collections.abc import Callable
from dataclasses import replace
from datetime import datetime
from typing import TYPE_CHECKING

from embedl_hub._internal.core.component.output import (
    CompiledModel,
    ComponentOutput,
)
from embedl_hub._internal.core.component.provider_type import ProviderType
from embedl_hub._internal.core.context import HubContext

if TYPE_CHECKING:
    from embedl_hub._internal.core.component.abc import Component
    from embedl_hub._internal.core.device.abc import Device
    from embedl_hub._internal.tracking.client import Client


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _log_inputs(
    ctx: HubContext,
    param_names: list[str],
    args: tuple[object, ...],
    kwargs: dict[str, object],
) -> None:
    r"""Re-log params, metrics, and artifacts from component inputs.

    For each positional or keyword argument that is a
    :class:`ComponentOutput` with a :attr:`~ComponentOutput.run_log`,
    all entries from that run log are re-logged with names prefixed by
    ``$input_<param_name>_``.

    Non-\ :class:`ComponentOutput` inputs are silently ignored.

    All entries are logged with ``save_to_run_log=False``.

    :param ctx: The execution context.
    :param param_names: Parameter names from the original method
        signature (excluding ``self`` and ``ctx``).
    :param args: Positional arguments passed to the component.
    :param kwargs: Keyword arguments passed to the component.
    """
    # Build a name -> value mapping from positional and keyword args
    named_args: dict[str, object] = {}
    for i, val in enumerate(args):
        if i < len(param_names):
            named_args[param_names[i]] = val
    named_args.update(kwargs)

    for param_name, value in named_args.items():
        if isinstance(value, ComponentOutput) and value.run_log is not None:
            prefix = f"input_{param_name}"
            value.run_log.log_all(ctx, prefix=f"{prefix}_")


def _find_parent_run_id(
    param_names: list[str],
    args: tuple[object, ...],
    kwargs: dict[str, object],
) -> str | None:
    """Find the parent run ID from the first :class:`ComponentOutput` input.

    Scans positional and keyword arguments for the first
    :class:`ComponentOutput` whose :attr:`~ComponentOutput.run_log`
    carries a ``run_id``.  That ID is returned so the current run can
    be linked as a child of the previous one.

    .. todo::

        Allow multiple previous inputs in the future.  Currently only
        the first :class:`ComponentOutput` input is considered for the
        parent run relationship.  A DAG-based lineage model would let
        every input contribute as a parent.

    :param param_names: Parameter names from the method signature.
    :param args: Positional arguments passed to the component.
    :param kwargs: Keyword arguments passed to the component.
    :return: The ``run_id`` of the first :class:`ComponentOutput` input,
        or ``None``.
    """
    all_values: list[object] = list(args) + list(kwargs.values())
    for value in all_values:
        if isinstance(value, ComponentOutput) and value.run_log is not None:
            return value.run_log.run_id
    return None


def _setup_artifact_dirs(ctx: HubContext, subdir_name: str) -> None:
    """Create local artifact directory and set device subdirectories.

    Creates ``<project_dir>/<subdir_name>/local/`` and sets it as
    the current artifact directory on the context.  Also notifies each
    device of the new `subdir_name`.

    :param ctx: The execution context.
    :param subdir_name: Name of the run subdirectory.
    """
    local_artifact_dir = ctx.project_dir / subdir_name / "local"
    local_artifact_dir.mkdir(parents=True, exist_ok=True)
    ctx._artifact_dir = local_artifact_dir

    for dev in ctx.devices.values():
        dev._set_artifact_subdir_name(subdir_name)


def _download_remote_artifacts(
    ctx: HubContext,
    subdir_name: str,
    client: Client | None = None,
) -> None:
    """Download remote device artifact directories if requested.

    When `client` is provided, a
    ``remote_<dev>_artifact_dir_download_time`` metric is logged for
    each device.

    :param ctx: The execution context.
    :param subdir_name: Name of the run subdirectory.
    :param client: Optional tracking client for logging download
        metrics.
    """
    if not ctx.download_artifacts:
        return
    run_dir = ctx.project_dir / subdir_name
    for dev_name, dev in ctx.devices.items():
        if dev.artifact_dir is None:
            continue
        download_dest = run_dir / f"remote_{dev_name}"
        t0 = time.monotonic()
        dev.download_artifact_dir(download_dest)
        if client is not None:
            dt = time.monotonic() - t0
            client.log_metric(
                f"remote_{dev_name}_artifact_dir_download_time", dt
            )


def _populate_run_log(ctx: HubContext) -> None:
    """Fill the current :class:`~embedl_hub._internal.tracking.run_log.RunLog` with
    artifact directory paths and device information.

    Also logs the local and remote artifact directory paths to the Hub
    as parameters (``artifact_dir`` and ``remote_<dev>_artifact_dir``).

    :param ctx: The execution context.
    """
    if ctx.client is None:
        return

    # Log artifact directory paths to the server
    ctx.client.log_param("artifact_dir", str(ctx.artifact_dir))
    for dev_name, dev in ctx.devices.items():
        if dev.is_active and dev.artifact_dir is not None:
            ctx.client.log_param(
                f"remote_{dev_name}_artifact_dir", str(dev.artifact_dir)
            )

    run_log = ctx.client.current_run_log
    if run_log is None:
        return
    run_log.artifact_dir = ctx.artifact_dir
    for dev_name, dev in ctx.devices.items():
        run_log.devices[dev_name] = dev.create_device_log(dev_name)


def _log_context_tags(ctx: HubContext) -> None:
    """Log any tags set on the context to the current run.

    :param ctx: The execution context.
    """
    if ctx.client is None:
        return
    for name, value in ctx.tags.items():
        ctx.client.log_tag(name, value)


def _cleanup_artifact_dirs(ctx: HubContext) -> None:
    """Clear device subdirectories and reset the context's artifact directory.

    :param ctx: The execution context.
    """
    for dev in ctx.devices.values():
        dev._clear_artifact_subdir_name()
    ctx._artifact_dir = None


def _save_run_yaml(
    ctx: HubContext,
    subdir_name: str,
    *,
    run_type: str | None = None,
    component_type: str | None = None,
    output_type: str | None = None,
    status: str | None = None,
    parent_run_id: str | None = None,
) -> None:
    """Persist a ``run.yaml`` metadata file for the current run.

    Only writes when an explicit `artifact_base_dir` was provided
    to the :class:`~embedl_hub._internal.core.context.HubContext`.  Temporary
    directories are skipped.

    :param ctx: The execution context.
    :param subdir_name: Name of the run subdirectory.
    :param run_type: Run type string (e.g. ``"COMPILE"``).
    :param component_type: Component class name.
    :param output_type: Output class name.
    :param status: Final run status (e.g. ``"FINISHED"``).
    :param parent_run_id: ID of the parent run, if any.
    """
    if ctx._provided_artifact_base_dir is None:
        return
    run_log = ctx.client.current_run_log if ctx.client is not None else None
    if run_log is None:
        return

    run_log.run_type = run_type
    run_log.component_type = component_type
    run_log.output_type = output_type
    run_log.status = status
    run_log.parent_run_id = parent_run_id
    run_log.tags = dict(ctx.tags)

    run_dir = ctx.project_dir / subdir_name
    run_log.save_yaml(run_dir)


def _update_downloaded_artifact_dirs(ctx: HubContext) -> None:
    """Update :class:`~embedl_hub._internal.tracking.run_log.DeviceLog` entries
    with the post-download local path.

    After :func:`_download_remote_artifacts` has run, each downloaded
    device will have its ``last_download_dir`` set.  This function
    replaces the corresponding :class:`~embedl_hub._internal.tracking.run_log.DeviceLog`
    entries in the current :class:`~embedl_hub._internal.tracking.run_log.RunLog`
    so that ``downloaded_artifact_dir`` reflects the *current* run's
    download.

    :param ctx: The execution context.
    """
    if ctx.client is None:
        return
    run_log = ctx.client.current_run_log
    if run_log is None:
        return
    for dev_name, dev in ctx.devices.items():
        if dev_name in run_log.devices and dev.last_download_dir is not None:
            old_log = run_log.devices[dev_name]
            run_log.devices[dev_name] = replace(
                old_log, downloaded_artifact_dir=dev.last_download_dir
            )


def validate_provider_signature(
    cls: type[Component],
    provider_type: str,
    fn: Callable,
) -> None:
    """Validate that an implementation function's signature matches ``run``.

    The function must accept ``(ctx, *positional_args, **kw_args)``
    where the positional and keyword-only parameter *names* match those
    of the component's ``run`` method (excluding ``self``).

    :param cls: The component class.
    :param provider_type: The device-type string (for error messages).
    :param fn: The implementation function.
    :raises TypeError: On signature mismatch.
    """
    fn_sig = inspect.signature(fn)
    fn_params = list(fn_sig.parameters.values())

    if not fn_params:
        raise TypeError(
            f"Provider '{fn.__name__}' for '{cls.__name__}' must accept "
            "at least 'ctx: HubContext' as first parameter."
        )

    # Extract positional and keyword-only param names from the function
    fn_positional: list[str] = []
    fn_keyword: list[str] = []
    for p in fn_params[1:]:  # Skip ctx
        if p.kind == inspect.Parameter.KEYWORD_ONLY:
            fn_keyword.append(p.name)
        elif p.kind in (
            inspect.Parameter.POSITIONAL_ONLY,
            inspect.Parameter.POSITIONAL_OR_KEYWORD,
        ):
            fn_positional.append(p.name)

    # 'name' is reserved for the component instance name and must not
    # appear on provider functions.
    if "name" in fn_keyword or "name" in fn_positional:
        raise TypeError(
            f"Provider '{fn.__name__}' ('{provider_type}') must not "
            f"declare a 'name' parameter.  'name' is reserved for "
            f"the component instance name."
        )

    expected_positional: list[str] = cls._positional_params
    expected_keyword: set[str] = set(cls._keyword_params.keys())

    if fn_positional != expected_positional:
        raise TypeError(
            f"Provider '{fn.__name__}' ('{provider_type}') positional "
            f"parameters {fn_positional} don't match "
            f"'{cls.__name__}.run' parameters {expected_positional}."
        )

    fn_keyword_set = set(fn_keyword)
    if fn_keyword_set != expected_keyword:
        missing = expected_keyword - fn_keyword_set
        extra = fn_keyword_set - expected_keyword
        parts: list[str] = []
        if missing:
            parts.append(f"missing: {sorted(missing)}")
        if extra:
            parts.append(f"extra: {sorted(extra)}")
        raise TypeError(
            f"Provider '{fn.__name__}' ('{provider_type}') keyword "
            f"parameters don't match '{cls.__name__}.run': "
            f"{', '.join(parts)}."
        )


def _resolve_devices(
    ctx: HubContext,
    resolved_kwargs: dict[str, object],
    class_name: str,
    available_providers: set[str],
) -> tuple[dict[str, Device], str]:
    """Select devices from the context and derive the device type.

    Supports two modes depending on which kwarg the component declared:

    * **``device``** (single) — resolves to one device.  When ``None``,
      the first compatible device in the context is selected.
    * **``devices``** (multi) — resolves to one or more devices.  When
      ``None``, *all* devices sharing the same type as the first
      compatible device are selected.

    In both modes the returned dict temporarily replaces
    ``ctx.devices`` during the component call.

    :param ctx: The execution context.
    :param resolved_kwargs: Resolved keyword arguments (must contain
        either ``"device"`` or ``"devices"``).
    :param class_name: Component class name (for error messages).
    :param available_providers: Device types registered on the
        component.
    :return: ``(selected_devices, device_type)`` — a dict of the
        matching :class:`~embedl_hub._internal.core.device.abc.Device` objects
        and the common device type string.
    :raises ValueError: If no compatible device can be found, a device
        name is not in the context, or the selected devices have mixed
        types.
    :raises TypeError: If ``devices`` is not a list/tuple, or ``device``
        is not a string.
    """
    # Determine the mode: single ("device") vs multi ("devices").
    is_single = "device" in resolved_kwargs

    if is_single:
        return _resolve_single_device(
            ctx, resolved_kwargs, class_name, available_providers
        )
    return _resolve_multi_devices(
        ctx, resolved_kwargs, class_name, available_providers
    )


def _resolve_single_device(
    ctx: HubContext,
    resolved_kwargs: dict[str, object],
    class_name: str,
    available_providers: set[str],
) -> tuple[dict[str, Device], str]:
    """Resolve a single ``device`` kwarg to a one-element device dict.

    :param ctx: The execution context.
    :param resolved_kwargs: Resolved keyword arguments.
    :param class_name: Component class name (for error messages).
    :param available_providers: Device types registered on the component.
    :return: ``(selected_devices, device_type)``.
    """
    device_name_raw = resolved_kwargs.get("device")

    if device_name_raw is None:
        # Prefer the LOCAL provider when no device is specified and
        # the context has no devices (or none match).
        if ProviderType.LOCAL in available_providers:
            return {}, ProviderType.LOCAL

        # Auto-select: first device whose provider_type has a provider.
        for dev_name, dev in ctx.devices.items():
            if dev.provider_type in available_providers:
                resolved_kwargs["device"] = dev_name
                device_name_raw = dev_name
                break
        else:
            return _raise_no_compatible_device(
                ctx, class_name, available_providers
            )

    if not isinstance(device_name_raw, str):
        raise TypeError(
            f"'{class_name}' expected 'device' to be a device name "
            f"string, got {type(device_name_raw).__name__}."
        )

    if device_name_raw not in ctx.devices:
        available = ", ".join(sorted(ctx.devices.keys())) or "(none)"
        raise ValueError(
            f"Device '{device_name_raw}' not found in HubContext. "
            f"Available devices: {available}."
        )

    dev = ctx.devices[device_name_raw]
    return {device_name_raw: dev}, dev.provider_type


def _resolve_multi_devices(
    ctx: HubContext,
    resolved_kwargs: dict[str, object],
    class_name: str,
    available_providers: set[str],
) -> tuple[dict[str, Device], str]:
    """Resolve a ``devices`` kwarg to a dict of one or more devices.

    :param ctx: The execution context.
    :param resolved_kwargs: Resolved keyword arguments.
    :param class_name: Component class name (for error messages).
    :param available_providers: Device types registered on the component.
    :return: ``(selected_devices, device_type)``.
    """
    device_names_raw = resolved_kwargs.get("devices")

    if device_names_raw is None:
        # Prefer the LOCAL provider when no devices are specified and
        # the context has no devices (or none match).
        if ProviderType.LOCAL in available_providers:
            return {}, ProviderType.LOCAL

        # Auto-select: all devices sharing the provider_type of the
        # first compatible device.
        first_provider: str | None = None
        for dev in ctx.devices.values():
            if dev.provider_type in available_providers:
                first_provider = dev.provider_type
                break
        if first_provider is None:
            return _raise_no_compatible_device(
                ctx, class_name, available_providers
            )
        auto_names = [
            n
            for n, d in ctx.devices.items()
            if d.provider_type == first_provider
        ]
        resolved_kwargs["devices"] = auto_names
        device_names_raw = auto_names

    if not isinstance(device_names_raw, (list, tuple)):
        raise TypeError(
            f"'{class_name}' expected 'devices' to be a list of "
            f"device names, got {type(device_names_raw).__name__}."
        )
    device_names: list[str] = list(device_names_raw)

    selected_devices: dict[str, Device] = {}
    for dname in device_names:
        if dname not in ctx.devices:
            available = ", ".join(sorted(ctx.devices.keys())) or "(none)"
            raise ValueError(
                f"Device '{dname}' not found in HubContext. "
                f"Available devices: {available}."
            )
        selected_devices[dname] = ctx.devices[dname]

    provider_types = {dev.provider_type for dev in selected_devices.values()}
    if len(provider_types) != 1:
        raise ValueError(
            f"All devices passed to '{class_name}' must have the "
            f"same provider_type, but got: "
            f"{sorted(str(p) for p in provider_types)}."
        )
    return selected_devices, provider_types.pop()


def _raise_no_compatible_device(
    ctx: HubContext,
    class_name: str,
    available_providers: set[str],
) -> tuple[dict[str, Device], str]:
    """Raise :class:`ValueError` when no device matches any registered type.

    Always raises; the return annotation exists only so callers can
    use ``return _raise_no_compatible_device(...)`` without type errors.

    :param ctx: The execution context.
    :param class_name: Component class name (for error messages).
    :param available_providers: Device types registered on the component.
    :raises ValueError: Always.
    """
    dev_types = sorted({str(d.provider_type) for d in ctx.devices.values()})
    raise ValueError(
        f"'{class_name}' has no provider for any device in "
        f"the context.  Device provider types: {dev_types}.  "
        f"Available providers: {sorted(available_providers)}."
    )


def _ensure_compiled_model_runs(
    ctx: HubContext,
    param_names: list[str],
    args: tuple[object, ...],
    kwargs: dict[str, object],
) -> tuple[tuple[object, ...], dict[str, object]]:
    """Create an import run for any :class:`CompiledModel` input that has
    no associated :class:`~embedl_hub._internal.tracking.run_log.RunLog`.

    When a :class:`CompiledModel` is passed as an argument but has no
    :attr:`~ComponentOutput.run_log` (i.e. it was constructed manually
    rather than produced by a compiler component), this function creates
    a short-lived ``IMPORT`` run named ``PreCompiledModel``, re-logs the
    model's contents, and replaces the argument with a new
    :class:`CompiledModel` that carries the resulting
    :class:`~embedl_hub._internal.tracking.run_log.RunLog`.

    This guarantees that every :class:`CompiledModel` reaching the
    component implementation has full lineage information.

    :param ctx: The execution context (must have an active client).
    :param param_names: Positional parameter names from the component
        signature.
    :param args: The positional arguments (may be replaced).
    :param kwargs: The keyword arguments (may be mutated in-place).
    :return: A ``(args, kwargs)`` tuple with any untracked
        :class:`CompiledModel` inputs replaced by tracked copies.
    """
    if ctx.client is None:
        return args, kwargs

    args_list = list(args)
    modified = False

    # Check positional args
    for i, val in enumerate(args_list):
        if isinstance(val, CompiledModel) and val.run_log is None:
            args_list[i] = _create_compile_run(ctx, val)
            modified = True

    # Check keyword args
    for key, val in kwargs.items():
        if isinstance(val, CompiledModel) and val.run_log is None:
            kwargs[key] = _create_compile_run(ctx, val)

    return (tuple(args_list) if modified else args, kwargs)


def _create_compile_run(
    ctx: HubContext,
    model: CompiledModel,
) -> CompiledModel:
    """Create a synthetic compile run for a manually constructed
    :class:`CompiledModel`.

    Opens a short-lived ``IMPORT`` run named ``PreCompiledModel``,
    logs the model's ``input`` and ``path`` artifacts, and returns
    a copy of `model` with a populated
    :attr:`~ComponentOutput.run_log`.

    :param ctx: The execution context with an active client.
    :param model: The :class:`CompiledModel` without a run log.
    :return: A replacement :class:`CompiledModel` with a run log.
    """
    from embedl_hub._internal.tracking.rest_api import RunType

    assert ctx.client is not None  # noqa: S101

    with ctx.client.start_run(
        type=RunType.COMPILE,
        name="PreCompiledModel",
    ):
        if model.input is not None:
            ctx.client.log_artifact(
                model.input,
                name="$input",
                ctx=ctx,
            )
        ctx.client.log_artifact(
            model.path,
            name="$path",
            ctx=ctx,
        )

        run_log = ctx.client.current_run_log
        return replace(model, run_log=run_log)


# ---------------------------------------------------------------------------
# Dispatcher factory
# ---------------------------------------------------------------------------


def create_dispatcher(
    class_name: str,
    original_method: Callable,
    positional_params: list[str],
    keyword_params: dict[str, object],
) -> Callable:
    """Create a dispatch wrapper that resolves defaults and routes to
    the registered device-specific implementation at runtime.

    :param class_name: Component class name (for error messages).
    :param original_method: The original ``run`` method.
    :param positional_params: Positional parameter names.
    :param keyword_params: Keyword parameter names and their defaults.
    :return: A wrapper function that replaces ``run``.
    """
    _param_names = list(positional_params)
    _kw_names = list(keyword_params.keys())

    @functools.wraps(original_method)
    def dispatch(
        self: Component, ctx: HubContext, *args: object, **kwargs: object
    ) -> ComponentOutput:
        if not ctx.is_active:
            raise RuntimeError(
                f"Cannot call '{class_name}' outside of an active "
                f"HubContext. Use 'with ctx:' to enter the context "
                f"first."
            )

        # Resolve keyword args: call-time value > constructor default
        resolved_kwargs: dict[str, object] = {}
        for kw_name in _kw_names:
            if kw_name in kwargs:
                resolved_kwargs[kw_name] = kwargs.pop(kw_name)
            else:
                resolved_kwargs[kw_name] = getattr(self, kw_name)

        if kwargs:
            unexpected = ", ".join(sorted(str(k) for k in kwargs))
            raise TypeError(
                f"'{class_name}' got unexpected keyword arguments: "
                f"{unexpected}"
            )

        # ---- resolve devices and determine provider_type ----------------
        selected_devices, provider_type = _resolve_devices(
            ctx, resolved_kwargs, class_name, set(self._providers)
        )

        if provider_type not in self._providers:
            available = ", ".join(sorted(self._providers.keys()))
            raise ValueError(
                f"'{class_name}' has no provider for '{provider_type!s}'. "
                f"Available providers: {available}."
            )

        provider_fn = self._providers[provider_type]

        # -- Temporary context mutation ------------------------------------
        # The dispatcher narrows three pieces of HubContext state for the
        # duration of the provider call and restores them in `finally`:
        #
        #   1. ctx.devices        — swapped to the selected subset so the
        #      provider only sees the device(s) it should operate on.
        #   2. ctx._artifact_dir  — pointed at a fresh per-run local
        #      directory by _setup_artifact_dirs().
        #   3. Device artifact subdirs — each device's remote artifact_dir
        #      is set to <base>/<subdir_name> via _setup_artifact_dirs().
        #
        # All three are reverted by the finally block (_cleanup_artifact_dirs
        # resets 2 & 3; the explicit reassignment restores 1).
        #
        # This is safe because dispatch is single-threaded.  If dispatch
        # ever becomes concurrent, these mutations must be replaced with a
        # scoped snapshot (e.g. passing selected_devices as an argument).
        # -----------------------------------------------------------------
        original_devices = ctx.devices
        ctx.devices = selected_devices

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        subdir_name = f"{class_name}_{timestamp}"
        _setup_artifact_dirs(ctx, subdir_name)

        try:
            if ctx.client is not None:
                args, resolved_kwargs = _ensure_compiled_model_runs(
                    ctx, _param_names, args, resolved_kwargs
                )
                parent_run_id = _find_parent_run_id(
                    _param_names, args, resolved_kwargs
                )
                with ctx.client.start_run(
                    type=self.run_type,
                    name=self.name,
                    parent_run_id=parent_run_id,
                ):
                    _populate_run_log(ctx)
                    _log_context_tags(ctx)
                    ctx.client.log_param(
                        "device_provider_type", str(provider_type)
                    )
                    # TODO: Fix automatic input logging once the
                    # server-side lineage model supports it.
                    # _log_inputs(ctx, _param_names, args, resolved_kwargs)

                    _run_type_str = (
                        self.run_type.value
                        if self.run_type is not None
                        else None
                    )
                    try:
                        result = provider_fn(ctx, *args, **resolved_kwargs)
                    except Exception:
                        _save_run_yaml(
                            ctx,
                            subdir_name,
                            run_type=_run_type_str,
                            component_type=class_name,
                            status="FAILED",
                            parent_run_id=parent_run_id,
                        )
                        raise

                    _download_remote_artifacts(ctx, subdir_name, ctx.client)
                    _update_downloaded_artifact_dirs(ctx)
                    _save_run_yaml(
                        ctx,
                        subdir_name,
                        run_type=_run_type_str,
                        component_type=class_name,
                        output_type=type(result).__name__,
                        status="FINISHED",
                        parent_run_id=parent_run_id,
                    )
                    return result
            else:
                result = provider_fn(ctx, *args, **resolved_kwargs)
                _download_remote_artifacts(ctx, subdir_name)
                return result
        finally:
            _cleanup_artifact_dirs(ctx)
            ctx.devices = original_devices

    return dispatch
