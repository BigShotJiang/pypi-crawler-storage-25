# Copyright (C) 2025, 2026 Embedl AB

"""Run log types and containers for tracking run history.

Provides the :class:`RunLog` container for storing parameters, metrics,
and artifacts recorded during a single run, as well as
:class:`LoggedParam`, :class:`LoggedMetric`, and :class:`LoggedArtifact`
data classes.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any, Self, cast

import yaml

from embedl_hub._internal.core.device.abc import CommandRunner, Device
from embedl_hub._internal.core.device.spec import DeviceSpec
from embedl_hub._internal.core.device.transfer import (
    get_directory,
    is_remote_dir,
    is_remote_file,
    put_directory,
)
from embedl_hub._internal.core.types import LocalPath, RemotePath

if TYPE_CHECKING:
    from embedl_hub._internal.core.context import HubContext


@dataclass(frozen=True)
class DeviceLog:
    """Snapshot of device information captured at the start of a run.

    Records the device name, hardware specification, and remote artifact
    directory so that artifacts can be transferred after the run completes.
    """

    name: str
    artifact_dir: RemotePath | None
    spec: DeviceSpec
    provider_type: str
    provider_metadata: dict[str, object]
    downloaded_artifact_dir: LocalPath | None = None


@dataclass(frozen=True)
class LoggedParam:
    """A parameter logged during a run."""

    name: str
    value: str
    logged_at: datetime


@dataclass(frozen=True)
class LoggedMetric:
    """A metric logged during a run."""

    name: str
    value: float
    step: int | None
    logged_at: datetime


@dataclass(frozen=True)
class LoggedArtifact:
    """An artifact logged during a run."""

    id: str
    file_name: str
    file_size: int
    logged_at: datetime
    file_path: LocalPath | RemotePath
    name: str | None = None
    device: DeviceLog | None = None
    artifact_dir: LocalPath | None = None

    @property
    def is_local(self) -> bool:
        return isinstance(self.file_path, LocalPath)

    @property
    def is_remote(self) -> bool:
        return not self.is_local

    def local(self) -> LocalPath:
        """Return the file path as a :class:`LocalPath`.

        :raises RuntimeError: If the artifact is not local.
        """
        if not self.is_local:
            raise RuntimeError(
                "Artifact is not local; call 'to_local()' first."
            )
        return cast(LocalPath, self.file_path)

    def remote(self) -> RemotePath:
        """Return the file path as a :class:`RemotePath`.

        :raises RuntimeError: If the artifact is not remote.
        """
        if not self.is_remote:
            raise RuntimeError(
                "Artifact is not remote; call 'to_remote()' first."
            )
        return cast(RemotePath, self.file_path)

    def to_local(
        self, ctx: HubContext, target_dir: LocalPath | None = None
    ) -> LoggedArtifact:
        """Get a local copy of this artifact, downloading if necessary.

        If the artifact is already local, the same instance is returned.
        Passing `target_dir` on an already-local artifact raises
        :class:`RuntimeError`.

        :param ctx: The execution context, used to access device
            information and the local artifact directory if `target_dir`
            is not provided.
        :param target_dir: Optional directory to download the artifact
            into.  When ``None``, the context's local artifact directory
            is used.
        :return: A :class:`LoggedArtifact` pointing at the local copy.
        :raises RuntimeError: If the artifact is already local and
            `target_dir` is provided, or if the artifact is remote but no
            device information is available, or if the download fails.
        """
        if self.is_local:
            if target_dir is not None:
                raise RuntimeError(
                    "Cannot specify 'target_dir' on an artifact that is "
                    "already local."
                )
            return self

        source = cast(RemotePath, self.file_path)

        _, runner = _resolve_device(ctx, self.device)
        device_name = self.device.name if self.device is not None else None
        target_dir = _resolve_local_target_dir(ctx, target_dir, device_name)
        destination = _compute_local_destination(
            source,
            target_dir,
            self.device,
        )
        _download(runner, source, destination, self.device)

        return replace(
            self,
            file_path=destination,
            device=None,
            artifact_dir=target_dir,
        )

    def to_remote(
        self,
        ctx: HubContext,
        device_name: str = "main",
        target_dir: RemotePath | None = None,
    ) -> LoggedArtifact:
        """Upload a local artifact to a remote device.

        If the artifact is already remote, the same instance is returned.
        Passing `target_dir` on an already-remote artifact raises
        :class:`RuntimeError`.

        :param ctx: The execution context, used to access device
            information and the remote artifact directory if `target_dir`
            is not provided.
        :param device_name: Name of the device to upload to
            (default ``"main"``).
        :param target_dir: Optional remote directory to upload the
            artifact into.  When ``None``, the device's artifact
            directory is used.
        :return: A :class:`LoggedArtifact` pointing at the remote copy.
        :raises RuntimeError: If the artifact is already remote and
            `target_dir` is provided, or if the required device or
            artifact directory is unavailable.
        """
        if self.is_remote:
            if target_dir is not None:
                raise RuntimeError(
                    "Cannot specify 'target_dir' on an artifact that is "
                    "already remote."
                )
            return self

        source = cast(LocalPath, self.file_path)
        device, runner = _resolve_device_by_name(ctx, device_name)
        target_dir = _resolve_remote_target_dir(
            device, device_name, target_dir
        )
        destination = _compute_remote_destination(
            source,
            target_dir,
            self.artifact_dir,
        )
        _upload(runner, source, destination)

        return replace(
            self,
            file_path=destination,
            device=device.create_device_log(device_name),
            artifact_dir=None,
        )


# -- LoggedArtifact helper functions ----------------------------------------


def _resolve_device(
    ctx: HubContext, device_log: DeviceLog | None
) -> tuple[Device, CommandRunner]:
    """Look up the live :class:`Device` from a :class:`DeviceLog`.

    :param ctx: The execution context.
    :param device_log: Device snapshot attached to the artifact.
    :return: A ``(device, runner)`` pair.
    :raises RuntimeError: If `device_log` is ``None``, the device is not
        found in the context, or the device has no command runner.
    """
    if device_log is None:
        raise RuntimeError(
            "Cannot fetch remote artifact without device information "
            "(device == None)."
        )

    device = ctx.devices.get(device_log.name)
    if device is None:
        raise RuntimeError(
            "Cannot fetch remote artifact: logged device "
            f"'{device_log.name}' not found in context."
        )
    if device.runner is None:
        raise RuntimeError(
            "Cannot fetch remote artifact: logged device "
            f"'{device_log.name}' has no command runner."
        )
    return device, device.runner


def _resolve_device_by_name(
    ctx: HubContext, device_name: str
) -> tuple[Device, CommandRunner]:
    """Look up a live :class:`Device` by name.

    :param ctx: The execution context.
    :param device_name: Name of the device to look up.
    :return: A ``(device, runner)`` pair.
    :raises RuntimeError: If the device is not found or has no runner.
    """
    device = ctx.devices.get(device_name)
    if device is None:
        raise RuntimeError(
            f"Cannot upload local artifact: device "
            f"'{device_name}' not found in context."
        )
    if device.runner is None:
        raise RuntimeError(
            f"Cannot upload local artifact: device "
            f"'{device_name}' has no command runner."
        )
    return device, device.runner


def _resolve_local_target_dir(
    ctx: HubContext,
    target_dir: LocalPath | None,
    device_name: str | None = None,
) -> LocalPath:
    """Determine the local directory to download a remote artifact into.

    When `target_dir` is ``None`` the context's artifact directory is used,
    with a ``.remote_<device_name>`` subdirectory appended (or ``.remote``
    when no `device_name` is given).

    :param ctx: The execution context.
    :param target_dir: Explicit download directory, or ``None`` to
        auto-derive one from the context.
    :param device_name: Optional device name used to build the
        subdirectory name.
    :raises RuntimeError: If no target directory can be determined or the
        context artifact directory does not exist.
    """
    if target_dir is not None:
        if not target_dir.exists():
            target_dir.mkdir(parents=True, exist_ok=True)
        return target_dir

    artifact_dir = ctx.artifact_dir
    if artifact_dir is None:
        raise RuntimeError(
            "Cannot fetch remote artifact: context has no active "
            "local artifact directory (ctx.artifact_dir == None)."
        )
    if not artifact_dir.exists():
        raise RuntimeError(
            "Cannot fetch remote artifact: local target directory "
            f"'{artifact_dir}' does not exist."
        )
    suffix = f".remote_{device_name}" if device_name else ".remote"
    target_dir = artifact_dir / suffix
    target_dir.mkdir(exist_ok=True)
    return target_dir


def _resolve_remote_target_dir(
    device: Device,
    device_name: str,
    target_dir: RemotePath | None,
) -> RemotePath:
    """Determine the remote directory to upload a local artifact into.

    When `target_dir` is ``None`` the device's artifact directory is used.

    :param device: The target device.
    :param device_name: Device name (for error messages).
    :param target_dir: Explicit upload directory, or ``None`` to use
        the device's artifact directory.
    :raises RuntimeError: If no target directory can be determined.
    """
    if target_dir is not None:
        return target_dir

    if device.artifact_dir is None:
        raise RuntimeError(
            f"Cannot upload local artifact: device '{device_name}' "
            "has no active artifact directory."
        )
    return device.artifact_dir


def _compute_local_destination(
    source: RemotePath,
    target_dir: LocalPath,
    device_log: DeviceLog | None,
) -> LocalPath:
    """Compute the local destination path preserving relative structure.

    :param source: Remote path of the artifact.
    :param target_dir: Local directory to place the artifact in.
    :param device_log: Optional device snapshot (used to derive the
        relative sub-path).
    :return: The resolved local destination path.
    """
    destination_name: str = str(
        source.relative_to(device_log.artifact_dir)
        if device_log is not None
        and device_log.artifact_dir is not None
        and source.is_relative_to(device_log.artifact_dir)
        else source.name
    )
    destination = target_dir / destination_name
    destination.parent.mkdir(parents=True, exist_ok=True)
    return destination


def _compute_remote_destination(
    source: LocalPath,
    target_dir: RemotePath,
    artifact_dir: LocalPath | None,
) -> RemotePath:
    """Compute the remote destination path preserving relative structure.

    :param source: Local path of the artifact.
    :param target_dir: Remote directory to place the artifact in.
    :param artifact_dir: Local artifact directory used to derive the
        relative sub-path.
    :return: The resolved remote destination path.
    """
    destination_name = (
        source.relative_to(artifact_dir)
        if artifact_dir is not None and source.is_relative_to(artifact_dir)
        else source.name
    )
    return RemotePath(target_dir) / destination_name


def _download(
    runner: CommandRunner,
    source: RemotePath,
    destination: LocalPath,
    device_log: DeviceLog | None,
) -> None:
    """Download a remote file or directory to a local path.

    :raises FileNotFoundError: If the remote path is neither a file nor
        a directory.
    """
    if is_remote_dir(runner, source):
        get_directory(runner, source, destination)
    elif is_remote_file(runner, source):
        runner.get(source, destination)
    else:
        device_name = device_log.name if device_log is not None else "unknown"
        raise FileNotFoundError(
            f"Cannot fetch remote artifact: logged remote file path "
            f"'{source}' is neither a file nor a directory on "
            f"device '{device_name}'."
        )


def _upload(
    runner: CommandRunner,
    source: LocalPath,
    destination: RemotePath,
) -> None:
    """Upload a local file or directory to a remote path.

    :raises FileNotFoundError: If the local path is neither a file nor
        a directory.
    """
    if source.is_dir():
        put_directory(runner, source, destination)
    elif source.is_file():
        runner.run(["mkdir", "-p", str(destination.parent)], hide=True)
        runner.put(source, destination)
    else:
        raise FileNotFoundError(
            f"Cannot upload local artifact: local file path "
            f"'{source}' is neither a file nor a directory."
        )


@dataclass
class RunLog:
    """Container for all data logged during a single run.

    Stores :class:`LoggedParam`, :class:`LoggedMetric`, and
    :class:`LoggedArtifact` entries recorded while the run is active,
    together with run metadata (ID, name, timestamps, status, etc.).

    Named entries are stored in dictionaries keyed by name; unnamed
    artifacts are kept in a separate list.
    """

    run_id: str
    run_name: str | None
    started_at: datetime
    ended_at: datetime | None = None
    artifact_dir: LocalPath | None = None
    devices: dict[str, DeviceLog] = field(default_factory=dict)

    # Optional run metadata — populated by the component system / client.
    run_type: str | None = None
    component_type: str | None = None
    output_type: str | None = None
    status: str | None = None
    parent_run_id: str | None = None
    project_id: str | None = None
    hub_url: str | None = None
    tags: dict[str, str] = field(default_factory=dict)

    _params: dict[str, LoggedParam] = field(default_factory=dict)
    _metrics: dict[str, LoggedMetric] = field(default_factory=dict)
    _named_artifacts: dict[str, LoggedArtifact] = field(default_factory=dict)
    _unnamed_artifacts: list[LoggedArtifact] = field(default_factory=list)

    def add_param(self, param: LoggedParam) -> None:
        """Add a parameter to the run log."""
        self._params[param.name] = param

    def add_metric(self, metric: LoggedMetric) -> None:
        """Add a metric to the run log."""
        self._metrics[metric.name] = metric

    def add_artifact(self, artifact: LoggedArtifact) -> None:
        """Add an artifact to the run log.

        Named artifacts are stored in a dict, unnamed artifacts in a list.
        """
        if artifact.name is not None:
            self._named_artifacts[artifact.name] = artifact
        else:
            self._unnamed_artifacts.append(artifact)

    @property
    def params(self) -> dict[str, LoggedParam]:
        """Get all logged parameters (read-only copy)."""
        return dict(self._params)

    @property
    def metrics(self) -> dict[str, LoggedMetric]:
        """Get all logged metrics (read-only copy)."""
        return dict(self._metrics)

    @property
    def named_artifacts(self) -> dict[str, LoggedArtifact]:
        """Get all named artifacts as a dict (read-only copy)."""
        return dict(self._named_artifacts)

    @property
    def unnamed_artifacts(self) -> Sequence[LoggedArtifact]:
        """Get all unnamed artifacts (read-only)."""
        return tuple(self._unnamed_artifacts)

    @property
    def artifacts(self) -> Sequence[LoggedArtifact]:
        """Get all logged artifacts (read-only)."""
        return tuple(
            list(self._named_artifacts.values()) + self._unnamed_artifacts
        )

    def log_all(
        self,
        ctx: HubContext,
        *,
        prefix: str = "",
        include_internal: bool = False,
    ) -> None:
        """Re-log all params, metrics, and named artifacts to the Hub.

        Each entry is logged with its original name prepended by `prefix`.
        The entries are sent to the Hub server but **not** saved to the
        client's current :class:`RunLog` (``save_to_run_log=False``).

        :param ctx: The execution context.
        :param prefix: A string prepended to each entry name.
        :param include_internal: Whether to include internal entries
            (names starting with ``$``).  Defaults to ``False``.
        :raises RuntimeError: If the run has named artifacts but no
            artifact directory.
        """
        for name, param in self._params.items():
            if not include_internal and name.startswith("$"):
                continue
            ctx.client.log_param(
                f"{prefix}{name}",
                param.value,
                save_to_run_log=False,
            )
        for name, metric in self._metrics.items():
            if not include_internal and name.startswith("$"):
                continue
            ctx.client.log_metric(
                f"{prefix}{name}",
                metric.value,
                metric.step,
                save_to_run_log=False,
            )
        for name, artifact in self._named_artifacts.items():
            if not include_internal and name.startswith("$"):
                continue
            ctx.client.log_artifact(
                artifact.to_local(ctx).local(),
                name=f"{prefix}{name}",
                file_name=f"{prefix}{artifact.file_name}",
                save_to_run_log=False,
            )

    # -- YAML serialization -------------------------------------------------

    _YAML_VERSION = 1

    def save_yaml(self, run_dir: LocalPath) -> LocalPath:
        """Write a ``run.yaml`` metadata file into `run_dir`.

        All paths inside the YAML are stored **relative** to `run_dir`
        so the directory is fully portable.

        :param run_dir: The run subdirectory (e.g.
            ``<artifact_base_dir>/TFLiteProfiler_20260323_141500/``).
        :return: The path to the written ``run.yaml`` file.
        """
        run_dir.mkdir(parents=True, exist_ok=True)

        def _rel(path: LocalPath | RemotePath | None) -> str | None:
            """Make *path* relative to *run_dir* when possible."""
            if path is None:
                return None
            try:
                return str(LocalPath(path).relative_to(run_dir))
            except (ValueError, TypeError):
                return str(path)

        def _iso(dt: datetime | None) -> str | None:
            return dt.isoformat() if dt is not None else None

        def _serialize_device(dev: DeviceLog) -> dict[str, Any]:
            return {
                "provider_type": str(dev.provider_type),
                "artifact_dir": str(dev.artifact_dir)
                if dev.artifact_dir
                else None,
                "downloaded_artifact_dir": _rel(dev.downloaded_artifact_dir),
                "device_name": dev.spec.device_name if dev.spec else None,
                "provider_metadata": dev.provider_metadata or None,
            }

        def _serialize_artifact(art: LoggedArtifact) -> dict[str, Any]:
            return {
                "id": art.id,
                "file_name": art.file_name,
                "file_size": art.file_size,
                "file_path": _rel(art.file_path),
                "logged_at": _iso(art.logged_at),
            }

        data: dict[str, Any] = {
            "version": self._YAML_VERSION,
            "run": {
                "id": self.run_id,
                "name": self.run_name,
                "type": self.run_type,
                "component_type": self.component_type,
                "output_type": self.output_type,
                "status": self.status,
                "started_at": _iso(self.started_at),
                "ended_at": _iso(self.ended_at),
                "parent_run_id": self.parent_run_id,
                "project_id": self.project_id,
                "hub_url": self.hub_url,
            },
            "artifact_dir": _rel(self.artifact_dir),
            "devices": {
                name: _serialize_device(dev)
                for name, dev in self.devices.items()
            }
            or None,
            "params": {
                name: {"value": str(p.value), "logged_at": _iso(p.logged_at)}
                for name, p in self._params.items()
            }
            or None,
            "metrics": {
                name: {
                    "value": float(m.value),
                    "step": m.step,
                    "logged_at": _iso(m.logged_at),
                }
                for name, m in self._metrics.items()
            }
            or None,
            "artifacts": {
                name: _serialize_artifact(a)
                for name, a in self._named_artifacts.items()
            }
            or None,
            "unnamed_artifacts": (
                [_serialize_artifact(a) for a in self._unnamed_artifacts]
                or None
            ),
            "tags": self.tags or None,
        }

        yaml_path = run_dir / "run.yaml"
        with open(yaml_path, "w", encoding="utf-8") as fh:
            yaml.dump(data, fh, default_flow_style=False, sort_keys=False)
        return yaml_path

    @classmethod
    def from_yaml(cls, yaml_path: LocalPath) -> Self:
        """Reconstruct a :class:`RunLog` from a ``run.yaml`` file.

        Relative paths stored in the YAML are resolved against the
        parent directory of `yaml_path`.

        :param yaml_path: Path to a ``run.yaml`` file.
        :return: A fully populated :class:`RunLog`.
        :raises FileNotFoundError: If `yaml_path` does not exist.
        :raises ValueError: If the YAML version is unsupported.
        """
        yaml_path = LocalPath(yaml_path)
        run_dir = yaml_path.parent

        with open(yaml_path, encoding="utf-8") as fh:
            data: dict[str, Any] = yaml.safe_load(fh)

        version = data.get("version", 0)
        if version != cls._YAML_VERSION:
            raise ValueError(
                f"Unsupported run.yaml version {version} "
                f"(expected {cls._YAML_VERSION})."
            )

        def _abs(rel: str | None) -> LocalPath | None:
            """Resolve a relative path against *run_dir*."""
            if rel is None:
                return None
            return run_dir / rel

        def _dt(iso: str | None) -> datetime | None:
            if iso is None:
                return None
            return datetime.fromisoformat(iso)

        run_data = data.get("run") or {}

        # -- devices ---------------------------------------------------------
        devices: dict[str, DeviceLog] = {}
        for dev_name, dev_data in (data.get("devices") or {}).items():
            # Support both the new flat "device_name" key and the legacy
            # nested spec.platform.device_name layout.
            raw_device_name = dev_data.get("device_name")
            if raw_device_name is None:
                spec_data = dev_data.get("spec") or {}
                plat_data = spec_data.get("platform") or {}
                raw_device_name = plat_data.get("device_name")

            from embedl_hub._internal.core.device.spec import DeviceSpec

            remote_art_dir_raw = dev_data.get("artifact_dir")
            devices[dev_name] = DeviceLog(
                name=dev_name,
                artifact_dir=(
                    RemotePath(remote_art_dir_raw)
                    if remote_art_dir_raw
                    else None
                ),
                spec=DeviceSpec(device_name=raw_device_name),
                provider_type=dev_data.get("provider_type", ""),
                provider_metadata=dev_data.get("provider_metadata") or {},
                downloaded_artifact_dir=_abs(
                    dev_data.get("downloaded_artifact_dir")
                ),
            )

        # -- params ----------------------------------------------------------
        params: dict[str, LoggedParam] = {}
        for pname, pdata in (data.get("params") or {}).items():
            params[pname] = LoggedParam(
                name=pname,
                value=pdata["value"],
                logged_at=_dt(pdata.get("logged_at")) or datetime.now(UTC),
            )

        # -- metrics ---------------------------------------------------------
        metrics: dict[str, LoggedMetric] = {}
        for mname, mdata in (data.get("metrics") or {}).items():
            metrics[mname] = LoggedMetric(
                name=mname,
                value=mdata["value"],
                step=mdata.get("step"),
                logged_at=_dt(mdata.get("logged_at")) or datetime.now(UTC),
            )

        # -- artifacts -------------------------------------------------------
        def _load_artifact(
            aname: str | None, adata: dict[str, Any]
        ) -> LoggedArtifact:
            raw_path = adata.get("file_path")
            file_path: LocalPath | RemotePath
            resolved = _abs(raw_path)
            file_path = resolved if resolved is not None else LocalPath()
            return LoggedArtifact(
                id=adata.get("id", ""),
                file_name=adata.get("file_name", ""),
                file_size=adata.get("file_size", 0),
                logged_at=(_dt(adata.get("logged_at")) or datetime.now(UTC)),
                file_path=file_path,
                name=aname,
            )

        named_artifacts: dict[str, LoggedArtifact] = {}
        for aname, adata in (data.get("artifacts") or {}).items():
            named_artifacts[aname] = _load_artifact(aname, adata)

        unnamed_artifacts: list[LoggedArtifact] = []
        for adata in data.get("unnamed_artifacts") or []:
            unnamed_artifacts.append(_load_artifact(None, adata))

        log = cls(
            run_id=run_data.get("id", ""),
            run_name=run_data.get("name"),
            started_at=_dt(run_data.get("started_at")) or datetime.now(UTC),
            ended_at=_dt(run_data.get("ended_at")),
            artifact_dir=_abs(data.get("artifact_dir")),
            devices=devices,
            run_type=run_data.get("type"),
            component_type=run_data.get("component_type"),
            output_type=run_data.get("output_type"),
            status=run_data.get("status"),
            parent_run_id=run_data.get("parent_run_id"),
            project_id=run_data.get("project_id"),
            hub_url=run_data.get("hub_url"),
            tags=data.get("tags") or {},
        )
        log._params = params
        log._metrics = metrics
        log._named_artifacts = named_artifacts
        log._unnamed_artifacts = unnamed_artifacts
        return log


class RunLogHistory:
    """Read-only container for completed :class:`RunLog` entries.

    Provides indexed and iterable access to the history of completed
    runs without allowing modification.
    """

    def __init__(self, logs: list[RunLog]) -> None:
        self._logs = logs

    def __len__(self) -> int:
        return len(self._logs)

    def __iter__(self):
        return iter(self._logs)

    def __getitem__(self, index: int) -> RunLog:
        return self._logs[index]

    @property
    def latest(self) -> RunLog | None:
        """Get the most recent :class:`RunLog`, or ``None`` if the history
        is empty.
        """
        if not self._logs:
            return None
        return self._logs[-1]

    def get_all(self) -> Sequence[RunLog]:
        """Get all :class:`RunLog` entries (read-only)."""
        return tuple(self._logs)
