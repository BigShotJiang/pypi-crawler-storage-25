# Copyright (C) 2025, 2026 Embedl AB

"""
embedl-hub compile — compile (and optionally quantize) models for
on-device deployment.

The CLI hierarchy is::

    compile <toolchain> <provider> [args …]

Toolchains
~~~~~~~~~~
* ``tflite``  — TFLite compilation via :class:`~embedl_hub._internal.core.compile.tflite.TFLiteCompiler`
* ``onnxruntime`` — ONNX Runtime compilation via :class:`~embedl_hub._internal.core.compile.onnxruntime.ONNXRuntimeCompiler`
* ``tensorrt`` — TensorRT compilation via :class:`~embedl_hub._internal.core.compile.tensorrt.TensorRTCompiler`

Backends vary per toolchain:

======================  ======  ==========  ==================  ======
Backend                tflite  onnxruntime embedl-onnxruntime  trtexec
======================  ======  ==========  ==================  ======
``local``                ✓
``qai-hub``              ✓       ✓
``embedl-onnxruntime``                       ✓
``trtexec``                                                      ✓
======================  ======  ==========  ==================  ======
"""

from pathlib import Path
from tempfile import TemporaryDirectory

import typer

from embedl_hub._internal.core.config import get_artifact_dir
from embedl_hub.cli.commands import (
    PROJECT_NAME_OPTION,
    RUN_NAME_OPTION,
    TAGS_OPTION,
)
from embedl_hub.cli.helper import (
    DEVICE_HELPER,
    EMBEDL_CLOUD_COMPILE_MODEL_HELPER,
    EMBEDL_ORT_CLI_ARGS_HELPER,
    EMBEDL_ORT_PATH_HELPER,
    QUALCOMM_COMPILE_MODEL_HELPER,
    SIZE_HELPER,
    SSH_HOST_HELPER,
    SSH_KEY_HELPER,
    SSH_PORT_HELPER,
    SSH_USER_HELPER,
    TRTEXEC_CLI_ARGS_HELPER,
    TRTEXEC_PATH_HELPER,
)

# All other embedl_hub imports should be done inside the function.
from embedl_hub.cli.run_metadata import (
    print_run_summary,
    save_cli_yaml_for_latest_run,
)

# ===================================================================== #
# Top-level group: compile
# ===================================================================== #

compile_cli = typer.Typer(
    name="compile",
    help="Compile a model for on-device deployment.",
    no_args_is_help=True,
)

# ===================================================================== #
# tflite toolchain
# ===================================================================== #

_compile_tflite_cli = typer.Typer(
    name="tflite",
    help="Compile using TFLite toolchain.",
    no_args_is_help=True,
)
compile_cli.add_typer(_compile_tflite_cli)


@_compile_tflite_cli.command("local", no_args_is_help=True)
def compile_tflite_local(
    ctx: typer.Context,
    model: Path = typer.Option(
        ...,
        "-m",
        "--model",
        help=EMBEDL_CLOUD_COMPILE_MODEL_HELPER,
        show_default=False,
    ),
    fp16: bool = typer.Option(
        False,
        "--fp16",
        help="Enable FP16 quantization for the TFLite model.",
        show_default=True,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Compile an ONNX model to TFLite locally via onnx2tf.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Compile model.onnx to TFLite format::

        $ embedl-hub compile tflite local -m model.onnx
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.tflite import TFLiteCompiler
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub.cli.context import (
        create_local_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import assert_api_config, parse_tags
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    if not model.exists():
        raise typer.BadParameter(f"Model path does not exist: {model}")

    tags_dict = parse_tags(tags)
    hub_ctx = create_local_context(
        project_name=resolved_project,
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )
    compiler = TFLiteCompiler(name=run_name)

    try:
        with hub_ctx:
            result = compiler.run(hub_ctx, model)
            compiled_path = result.path.to_local(hub_ctx).local()
        console.print(f"[green]✓ Compiled model to {compiled_path}[/]")
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


@_compile_tflite_cli.command("qai-hub", no_args_is_help=True)
def compile_tflite_qai_hub(
    ctx: typer.Context,
    model: Path = typer.Option(
        ...,
        "-m",
        "--model",
        help=QUALCOMM_COMPILE_MODEL_HELPER,
        show_default=False,
    ),
    device: str = typer.Option(
        ...,
        "-d",
        "--device",
        help=DEVICE_HELPER,
        show_default=False,
    ),
    size: str = typer.Option(
        ...,
        "--size",
        "-s",
        help=SIZE_HELPER,
        show_default=False,
    ),
    quantize_io: bool = typer.Option(
        False,
        "--quantize-io",
        help="Quantize input and output tensors.",
        show_default=True,
    ),
    data_path: Path | None = typer.Option(
        None,
        "--data",
        help="Path to calibration data directory for quantization.",
        show_default=False,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Compile a model to TFLite via Qualcomm AI Hub.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Compile model.onnx for Samsung Galaxy S24::

        $ embedl-hub compile tflite qai-hub -m model.onnx -s 1,3,224,224 -d "Samsung Galaxy S24"
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.result import CompileError
    from embedl_hub._internal.core.compile.tflite import TFLiteCompiler
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.utils.onnx_utils import (
        maybe_package_onnx_folder_to_file,
    )
    from embedl_hub.cli.context import (
        create_qai_hub_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        prepare_input_size,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    if not model.exists():
        raise typer.BadParameter(f"Model path does not exist: {model}")

    input_shape = prepare_input_size(size)
    tags_dict = parse_tags(tags)

    with TemporaryDirectory() as tmpdir:
        model_path = maybe_package_onnx_folder_to_file(model, tmpdir)
        hub_ctx = create_qai_hub_context(
            project_name=resolved_project,
            device_name=device,
            artifact_dir=artifact_base_dir,
            tags=tags_dict,
        )

        try:
            with hub_ctx:
                compiler = TFLiteCompiler(name=run_name)
                result = compiler.run(
                    hub_ctx,
                    model_path,
                    device="main",
                    input_shape=input_shape,
                    calibration_data=data_path,
                    quantize_io=quantize_io,
                )
                _ = result.path.to_local(hub_ctx).local()
            console.print(f"[green]✓ Compiled model for {device}[/]")
        except (CompileError, ValueError) as error:
            console.print(f"[red]✗ {error}[/]")
            raise typer.Exit(1)
        finally:
            save_cli_yaml_for_latest_run(project_dir)
            print_run_summary(project_dir)


# ===================================================================== #
# onnxruntime toolchain
# ===================================================================== #

_compile_onnxruntime_cli = typer.Typer(
    name="onnxruntime",
    help="Compile using ONNX Runtime toolchain.",
    no_args_is_help=True,
)
compile_cli.add_typer(_compile_onnxruntime_cli)


@_compile_onnxruntime_cli.command("qai-hub", no_args_is_help=True)
def compile_onnxruntime_qai_hub(
    ctx: typer.Context,
    model: Path = typer.Option(
        ...,
        "-m",
        "--model",
        help=QUALCOMM_COMPILE_MODEL_HELPER,
        show_default=False,
    ),
    device: str = typer.Option(
        ...,
        "-d",
        "--device",
        help=DEVICE_HELPER,
        show_default=False,
    ),
    size: str = typer.Option(
        ...,
        "--size",
        "-s",
        help=SIZE_HELPER,
        show_default=False,
    ),
    quantize_io: bool = typer.Option(
        False,
        "--quantize-io",
        help="Quantize input and output tensors.",
        show_default=True,
    ),
    data_path: Path | None = typer.Option(
        None,
        "--data",
        help="Path to calibration data directory for quantization.",
        show_default=False,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Compile a model to ONNX Runtime via Qualcomm AI Hub.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Compile model.onnx for Samsung Galaxy S24::

        $ embedl-hub compile onnxruntime qai-hub -m model.onnx -s 1,3,224,224 -d "Samsung Galaxy S24"
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.onnxruntime import (
        ONNXRuntimeCompiler,
    )
    from embedl_hub._internal.core.compile.result import CompileError
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.utils.onnx_utils import (
        maybe_package_onnx_folder_to_file,
    )
    from embedl_hub.cli.context import (
        create_qai_hub_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        prepare_input_size,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    if not model.exists():
        raise typer.BadParameter(f"Model path does not exist: {model}")

    input_shape = prepare_input_size(size)
    tags_dict = parse_tags(tags)

    with TemporaryDirectory() as tmpdir:
        model_path = maybe_package_onnx_folder_to_file(model, tmpdir)
        hub_ctx = create_qai_hub_context(
            project_name=resolved_project,
            device_name=device,
            artifact_dir=artifact_base_dir,
            tags=tags_dict,
        )

        try:
            with hub_ctx:
                compiler = ONNXRuntimeCompiler(name=run_name)
                result = compiler.run(
                    hub_ctx,
                    model_path,
                    device="main",
                    input_shape=input_shape,
                    calibration_data=data_path,
                    quantize_io=quantize_io,
                )
                _ = result.path.to_local(hub_ctx).local()
            console.print(f"[green]✓ Compiled model for {device}[/]")
        except (CompileError, ValueError) as error:
            console.print(f"[red]✗ {error}[/]")
            raise typer.Exit(1)
        finally:
            save_cli_yaml_for_latest_run(project_dir)
            print_run_summary(project_dir)


@_compile_onnxruntime_cli.command("embedl-onnxruntime", no_args_is_help=True)
def compile_onnxruntime_embedl_ort(
    ctx: typer.Context,
    model: Path = typer.Option(
        ...,
        "-m",
        "--model",
        help=EMBEDL_CLOUD_COMPILE_MODEL_HELPER,
        show_default=False,
    ),
    host: str = typer.Option(
        ...,
        "--host",
        help=SSH_HOST_HELPER,
        show_default=False,
    ),
    username: str = typer.Option(
        ...,
        "--user",
        help=SSH_USER_HELPER,
        show_default=False,
    ),
    port: int = typer.Option(22, "--port", help=SSH_PORT_HELPER),
    key_file: Path | None = typer.Option(
        None,
        "--key-file",
        help=SSH_KEY_HELPER,
        show_default=False,
    ),
    size: str | None = typer.Option(
        None,
        "--size",
        "-s",
        help=SIZE_HELPER,
        show_default=False,
    ),
    exec_path: str | None = typer.Option(
        None,
        "--exec-path",
        help=EMBEDL_ORT_PATH_HELPER,
        show_default=False,
    ),
    extra_args: list[str] | None = typer.Option(
        None,
        "--cli-args",
        help=EMBEDL_ORT_CLI_ARGS_HELPER,
        show_default=False,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Compile a model using embedl-onnxruntime over SSH.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Compile model.onnx on a remote device::

        $ embedl-hub compile onnxruntime embedl-onnxruntime -m model.onnx --host 192.168.1.10 --user pi
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.onnxruntime import (
        ONNXRuntimeCompiler,
    )
    from embedl_hub._internal.core.compile.result import CompileError
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub.cli.context import (
        create_embedl_onnxruntime_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        prepare_input_size,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    if not model.exists():
        raise typer.BadParameter(f"Model path does not exist: {model}")

    input_shape = prepare_input_size(size)
    tags_dict = parse_tags(tags)

    hub_ctx = create_embedl_onnxruntime_context(
        project_name=resolved_project,
        host=host,
        username=username,
        port=port,
        private_key_path=key_file,
        exec_path=exec_path,
        cli_args=tuple(extra_args) if extra_args else (),
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            compiler = ONNXRuntimeCompiler(name=run_name)
            kwargs: dict = {}
            if input_shape is not None:
                kwargs["input_shape"] = input_shape
            result = compiler.run(hub_ctx, model, device="main", **kwargs)
            compiled_path = result.path.to_local(hub_ctx).local()
        console.print(f"[green]✓ Compiled model to {compiled_path}[/]")
    except (CompileError, ValueError) as error:
        console.print(f"[red]✗ {error}[/]")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


# ===================================================================== #
# tensorrt toolchain
# ===================================================================== #

_compile_tensorrt_cli = typer.Typer(
    name="tensorrt",
    help="Compile using TensorRT toolchain.",
    no_args_is_help=True,
)
compile_cli.add_typer(_compile_tensorrt_cli)


@_compile_tensorrt_cli.command("trtexec", no_args_is_help=True)
def compile_tensorrt_trtexec(
    ctx: typer.Context,
    model: Path = typer.Option(
        ...,
        "-m",
        "--model",
        help=EMBEDL_CLOUD_COMPILE_MODEL_HELPER,
        show_default=False,
    ),
    host: str = typer.Option(
        ...,
        "--host",
        help=SSH_HOST_HELPER,
        show_default=False,
    ),
    username: str = typer.Option(
        ...,
        "--user",
        help=SSH_USER_HELPER,
        show_default=False,
    ),
    port: int = typer.Option(22, "--port", help=SSH_PORT_HELPER),
    key_file: Path | None = typer.Option(
        None,
        "--key-file",
        help=SSH_KEY_HELPER,
        show_default=False,
    ),
    size: str | None = typer.Option(
        None,
        "--size",
        "-s",
        help=SIZE_HELPER,
        show_default=False,
    ),
    exec_path: str | None = typer.Option(
        None,
        "--exec-path",
        help=TRTEXEC_PATH_HELPER,
        show_default=False,
    ),
    extra_args: list[str] | None = typer.Option(
        None,
        "--cli-args",
        help=TRTEXEC_CLI_ARGS_HELPER,
        show_default=False,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Compile a model to TensorRT engine via trtexec over SSH.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Compile model.onnx on a remote NVIDIA device::

        $ embedl-hub compile tensorrt trtexec -m model.onnx --host 192.168.1.10 --user nvidia
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.result import CompileError
    from embedl_hub._internal.core.compile.tensorrt import TensorRTCompiler
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub.cli.context import (
        create_trtexec_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        prepare_input_size,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    if not model.exists():
        raise typer.BadParameter(f"Model path does not exist: {model}")

    input_shape = prepare_input_size(size)
    tags_dict = parse_tags(tags)

    hub_ctx = create_trtexec_context(
        project_name=resolved_project,
        host=host,
        username=username,
        port=port,
        private_key_path=key_file,
        exec_path=exec_path,
        cli_args=tuple(extra_args) if extra_args else (),
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            compiler = TensorRTCompiler(name=run_name)
            kwargs: dict = {}
            if input_shape is not None:
                kwargs["input_shape"] = input_shape
            result = compiler.run(hub_ctx, model, device="main", **kwargs)
            compiled_path = result.path.to_local(hub_ctx).local()
        console.print(f"[green]✓ Compiled model to {compiled_path}[/]")
    except (CompileError, ValueError) as error:
        console.print(f"[red]✗ {error}[/]")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)
