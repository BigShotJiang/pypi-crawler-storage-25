# Copyright (C) 2025, 2026 Embedl AB

"""
Module defining common CLI command options for embedl-hub.
"""

import typer

PROJECT_NAME_OPTION = typer.Option(
    None,
    "--project-name",
    "-pn",
    help="Name of the project to use for the run. (Overrides context set with 'embedl-hub init')",
)

RUN_NAME_OPTION = typer.Option(
    None,
    "--run-name",
    "-rn",
    help="Optional name for the run. (If not set, a random name will be generated)",
)

TAGS_OPTION = typer.Option(
    None,
    "--tag",
    "-t",
    help="Tag to log for the run, in key=value format. Repeatable.",
    show_default=False,
)
