# Copyright (C) 2025, 2026 Embedl AB
"""Project context management for embedl-hub CLI.

Provides the ``init`` and ``show`` commands that configure and display
the persistent CLI context.  The context determines:

* Under which **project** all data, results, and metadata are stored
  on https://hub.embedl.com.
* Which **artifact directory** is used by every compile, profile,
  invoke, and log command.

Configuration is persisted in ``~/.config/embedl-hub/config.yaml``.
"""

from __future__ import annotations

from pathlib import Path

import typer
from rich.table import Table

init_cli = typer.Typer(help="Initialise / show project context")


@init_cli.command("init")
def init_command(
    ctx: typer.Context,
    project: str | None = typer.Option(
        None, "-p", "--project", help="Project name or id", show_default=False
    ),
    artifact_dir: str | None = typer.Option(
        None,
        "--artifact-dir",
        help="Directory for storing run artifacts. "
        "Persisted in config so all commands use the same location.",
        show_default=False,
    ),
):
    """Configure persistent CLI context.

    Stores values used by all other commands in a local config file
    (``~/.config/embedl-hub/config.yaml``).  The config file records:

    * The active **project** (created automatically when the name does
      not yet exist on the server).
    * The **artifact directory** where every compile, profile, and
      invoke run writes its outputs.

    Examples
    --------

    Create a new project with a random name::

        $ embedl-hub init

    Create or set a named project::

        $ embedl-hub init -p "My Flower Detector App"

    Set a custom artifact directory::

        $ embedl-hub init --artifact-dir ~/my-artifacts
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.config import (
        DEFAULT_ARTIFACT_DIR,
        get_artifact_dir,
        write_ctx_config,
        write_ctx_state,
    )
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.tracking.client import Client
    from embedl_hub._internal.tracking.utils import (
        timestamp_id,
        to_project_url,
    )
    from embedl_hub.cli.utils import assert_api_config
    # pylint: enable=import-outside-toplevel

    assert_api_config()

    current_project = ctx.obj["config"].get("project_name")
    # Decide which project to use
    project_to_use: str | None
    if project:
        console.print(f"Setting project to '{project}'")
        project_to_use = project
    elif not current_project:
        console.print("No active project, creating a new one")
        project_to_use = project
    else:
        console.print(f"Keeping current project '{current_project}'")
        project_to_use = current_project

    project_name = project_to_use or timestamp_id("project")
    result = Client().set_project(project_name)
    ctx.obj["state"]["project_id"] = result.id
    ctx.obj["config"]["project_name"] = result.name

    # -- artifact directory ------------------------------------------------
    if artifact_dir is not None:
        resolved = str(Path(artifact_dir).expanduser().resolve())
        ctx.obj["config"]["artifact_dir"] = resolved
    elif "artifact_dir" not in ctx.obj["config"]:
        ctx.obj["config"]["artifact_dir"] = str(DEFAULT_ARTIFACT_DIR)

    write_ctx_config(ctx.obj["config"])
    write_ctx_state(ctx.obj["state"])

    effective_dir = get_artifact_dir(ctx.obj["config"])
    console.print(f"[green]✓ Project:[/] {ctx.obj['config']['project_name']}")
    console.print(f"[green]✓ Artifacts:[/] {effective_dir}")
    console.print(
        f"See your results: {to_project_url(ctx.obj['state']['project_id'])}"
    )


@init_cli.command("show")
def show_command(
    ctx: typer.Context,
):
    """Print the active project name and artifact directory."""

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub.cli.context import require_initialized_ctx
    from embedl_hub.cli.utils import assert_api_config
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    table = Table(title="Configuration", show_lines=True, show_header=False)
    for k in ("project_name", "artifact_dir"):
        table.add_row(k, ctx.obj["config"].get(k, "—"))
    console.print(table)
