# Copyright (C) 2025, 2026 Embedl AB

"""CLI context helpers — build HubContext from CLI arguments."""

from __future__ import annotations

from pathlib import Path

import typer

from embedl_hub._internal.core.hub_logging import console


def require_initialized_ctx(config: dict[str, str]) -> None:
    """Throw error if ``project_name`` is not in config."""
    if not config.get("project_name"):
        console.print(
            "[red]Failed to find context: No project is initialized.[/]\n",
            "[red]Run 'embedl-hub init' to set up a project.[/]\n",
            "[red]Run 'embedl-hub auth' to set up an api key.[/]",
        )
        raise typer.Exit(1)


def create_qai_hub_context(
    project_name: str,
    device_name: str,
    *,
    artifact_dir: Path | None = None,
    tags: dict[str, str] | None = None,
):
    """Build a :class:`~embedl_hub._internal.core.context.HubContext` for a QAI Hub device.

    :param project_name: The project name from CLI config.
    :param device_name: QAI Hub device name (e.g. ``"Samsung Galaxy S24"``).
    :param artifact_dir: Optional local artifact directory.
    :param tags: Optional tags to set on the context.
    :return: A configured :class:`~embedl_hub._internal.core.context.HubContext` (not yet entered).
    """
    from embedl_hub._internal.core.context import HubContext
    from embedl_hub._internal.core.device.manager import DeviceManager

    device = DeviceManager.get_qai_hub_device(device_name)
    ctx = HubContext(
        project_name=project_name,
        artifact_base_dir=artifact_dir,
        devices=[device],
    )
    if tags:
        ctx.set_tags(**tags)
    return ctx


def create_aws_context(
    project_name: str,
    device_name: str,
    *,
    artifact_dir: Path | None = None,
    tags: dict[str, str] | None = None,
):
    """Build a :class:`~embedl_hub._internal.core.context.HubContext` for an Embedl device cloud (AWS) device.

    :param project_name: The project name from CLI config.
    :param device_name: Embedl device cloud device name.
    :param artifact_dir: Optional local artifact directory.
    :param tags: Optional tags to set on the context.
    :return: A configured :class:`~embedl_hub._internal.core.context.HubContext` (not yet entered).
    """
    from embedl_hub._internal.core.context import HubContext
    from embedl_hub._internal.core.device.manager import DeviceManager

    device = DeviceManager.get_aws_device(device_name)
    ctx = HubContext(
        project_name=project_name,
        artifact_base_dir=artifact_dir,
        devices=[device],
    )
    if tags:
        ctx.set_tags(**tags)
    return ctx


def create_local_context(
    project_name: str,
    *,
    artifact_dir: Path | None = None,
    tags: dict[str, str] | None = None,
):
    """Build a :class:`~embedl_hub._internal.core.context.HubContext` for local execution (no device).

    :param project_name: The project name from CLI config.
    :param artifact_dir: Optional local artifact directory.
    :param tags: Optional tags to set on the context.
    :return: A configured :class:`~embedl_hub._internal.core.context.HubContext` (not yet entered).
    """
    from embedl_hub._internal.core.context import HubContext

    ctx = HubContext(
        project_name=project_name,
        artifact_base_dir=artifact_dir,
        devices=[],
    )
    if tags:
        ctx.set_tags(**tags)
    return ctx


def create_trtexec_context(
    project_name: str,
    host: str,
    username: str,
    *,
    port: int = 22,
    private_key_path: Path | None = None,
    exec_path: str | None = None,
    cli_args: tuple[str, ...] = (),
    artifact_dir: Path | None = None,
    tags: dict[str, str] | None = None,
):
    """Build a :class:`~embedl_hub._internal.core.context.HubContext` for a remote TensorRT (``trtexec``) device.

    :param project_name: The project name from CLI config.
    :param host: SSH hostname or IP address.
    :param username: SSH username.
    :param port: SSH port (default 22).
    :param private_key_path: Optional path to SSH private key.
    :param exec_path: Path to the ``trtexec`` binary on the remote device.
    :param cli_args: Extra CLI flags forwarded verbatim to ``trtexec``.
    :param artifact_dir: Optional local artifact directory.
    :param tags: Optional tags to set on the context.
    :return: A configured :class:`~embedl_hub._internal.core.context.HubContext` (not yet entered).
    """
    from embedl_hub._internal.core.context import HubContext
    from embedl_hub._internal.core.device.config.trtexec import TrtexecConfig
    from embedl_hub._internal.core.device.manager import DeviceManager
    from embedl_hub._internal.core.device.ssh import SSHConfig

    ssh_config = SSHConfig(
        host=host,
        username=username,
        port=port,
        private_key_path=private_key_path,
    )
    cfg_kwargs: dict = {}
    if exec_path is not None:
        from embedl_hub._internal.core.types import RemotePath

        cfg_kwargs["trtexec_path"] = RemotePath(exec_path)
    if cli_args:
        cfg_kwargs["trtexec_cli_args"] = cli_args
    provider_config = TrtexecConfig(**cfg_kwargs)
    device = DeviceManager.get_tensorrt_device(
        ssh_config,
        provider_config=provider_config,
    )
    ctx = HubContext(
        project_name=project_name,
        artifact_base_dir=artifact_dir,
        devices=[device],
    )
    if tags:
        ctx.set_tags(**tags)
    return ctx


def create_embedl_onnxruntime_context(
    project_name: str,
    host: str,
    username: str,
    *,
    port: int = 22,
    private_key_path: Path | None = None,
    exec_path: str | None = None,
    cli_args: tuple[str, ...] = (),
    artifact_dir: Path | None = None,
    tags: dict[str, str] | None = None,
):
    """Build a :class:`~embedl_hub._internal.core.context.HubContext` for a remote ``embedl-onnxruntime`` device.

    :param project_name: The project name from CLI config.
    :param host: SSH hostname or IP address.
    :param username: SSH username.
    :param port: SSH port (default 22).
    :param private_key_path: Optional path to SSH private key.
    :param exec_path: Path to ``embedl-onnxruntime`` on the remote device.
    :param cli_args: Extra CLI flags forwarded verbatim to
        ``embedl-onnxruntime``.
    :param artifact_dir: Optional local artifact directory.
    :param tags: Optional tags to set on the context.
    :return: A configured :class:`~embedl_hub._internal.core.context.HubContext` (not yet entered).
    """
    from embedl_hub._internal.core.context import HubContext
    from embedl_hub._internal.core.device.config.embedl_onnxruntime import (
        EmbedlONNXRuntimeConfig,
    )
    from embedl_hub._internal.core.device.manager import DeviceManager
    from embedl_hub._internal.core.device.ssh import SSHConfig

    ssh_config = SSHConfig(
        host=host,
        username=username,
        port=port,
        private_key_path=private_key_path,
    )
    cfg_kwargs: dict = {}
    if exec_path is not None:
        from embedl_hub._internal.core.types import RemotePath

        cfg_kwargs["embedl_onnxruntime_path"] = RemotePath(exec_path)
    if cli_args:
        cfg_kwargs["cli_args"] = cli_args
    provider_config = EmbedlONNXRuntimeConfig(**cfg_kwargs)
    device = DeviceManager.get_embedl_onnxruntime_device(
        ssh_config,
        provider_config=provider_config,
    )
    ctx = HubContext(
        project_name=project_name,
        artifact_base_dir=artifact_dir,
        devices=[device],
    )
    if tags:
        ctx.set_tags(**tags)
    return ctx
