# Copyright (C) 2026 Embedl AB

"""CLI-level run metadata helpers.

This module provides utilities for persisting and presenting run
metadata at the CLI layer:

* **cli.yaml** — records ``sys.argv`` so ``embedl-hub log`` can
  display the exact command that produced a given run.
* **Run discovery** — :func:`find_run_dirs` scans the project
  directory for timestamped subdirectories containing ``run.yaml``.
* **Run summary panel** — :func:`print_run_summary` renders a
  Rich panel with the most recent run's key information (ID, name,
  status, provider, directory, hub link, and parent/input run).
  Used by compile, profile, and invoke commands at the end of every
  run.

The core package knows nothing about ``cli.yaml`` files — they are
owned entirely by the CLI.
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import yaml

from embedl_hub._internal.core.types import LocalPath


def _is_embedl_hub_command() -> bool:
    """Return ``True`` if the current process looks like an embedl-hub CLI invocation."""
    if not sys.argv:
        return False
    basename = sys.argv[0].rsplit("/", 1)[-1]
    return basename.startswith("embedl-hub") or basename.startswith(
        "embedl_hub"
    )


def save_cli_yaml(run_dir: LocalPath) -> LocalPath | None:
    """Write a ``cli.yaml`` file capturing the CLI invocation.

    The file records ``sys.argv`` so that ``embedl-hub log`` can
    display the exact command that produced a given run.

    The write is skipped when the file already exists (a fresh run
    directory never contains one) or when the current process is not
    an ``embedl-hub`` invocation (e.g. ``pytest``).

    :param run_dir: The run subdirectory.
    :return: Path to the written ``cli.yaml`` file, or ``None`` if
        the write was skipped.
    """
    yaml_path = run_dir / "cli.yaml"
    if yaml_path.exists():
        return None
    if not _is_embedl_hub_command():
        return None
    run_dir.mkdir(parents=True, exist_ok=True)
    data: dict[str, Any] = {
        "command": " ".join(sys.argv),
        "argv": list(sys.argv),
    }
    with open(yaml_path, "w", encoding="utf-8") as fh:
        yaml.dump(data, fh, default_flow_style=False, sort_keys=False)
    return yaml_path


def load_cli_yaml(run_dir: LocalPath) -> dict[str, Any] | None:
    """Load a ``cli.yaml`` file from a run directory.

    :param run_dir: The run subdirectory.
    :return: Parsed dict or ``None`` if the file does not exist.
    """
    yaml_path = run_dir / "cli.yaml"
    if not yaml_path.exists():
        return None
    with open(yaml_path, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


def find_run_dirs(project_dir: Path) -> list[LocalPath]:
    """Find all run subdirectories under `project_dir`.

    Returns directories that contain a ``run.yaml`` file, sorted
    most-recent first.  Directories are sorted by the embedded
    ``YYYYMMDD_HHMMSS`` timestamp suffix (extracted from the last
    two ``_``-separated segments), falling back to the full name
    for directories without that pattern.

    :param project_dir: The project-scoped artifact directory
        (``<artifact_base_dir>/<project_name>``).
    :return: Sorted list of run directories (newest first).
    """
    base = LocalPath(project_dir)
    if not base.is_dir():
        return []

    def _sort_key(d: LocalPath) -> str:
        """Extract ``YYYYMMDD_HHMMSS`` from e.g. ``TFLiteInvoker_20260323_141924``."""
        parts = d.name.rsplit("_", 2)
        if len(parts) >= 3:
            return f"{parts[-2]}_{parts[-1]}"
        return d.name

    dirs = [
        d for d in base.iterdir() if d.is_dir() and (d / "run.yaml").exists()
    ]
    dirs.sort(key=_sort_key, reverse=True)
    return dirs


def save_cli_yaml_for_latest_run(project_dir: Path) -> None:
    """Write ``cli.yaml`` into the most recent run directory.

    If `project_dir` has no run directories yet (or does not
    exist), the call is silently ignored.

    :param project_dir: The project-scoped artifact directory.
    """
    dirs = find_run_dirs(project_dir)
    if dirs:
        save_cli_yaml(dirs[0])


# -------------------------------------------------------------------
# Run summary panel
# -------------------------------------------------------------------


def print_run_summary(project_dir: Path) -> None:
    """Print a Rich panel summarising the most recent run.

    Reads ``run.yaml`` from the newest run directory under
    *project_dir* and renders a concise summary similar to
    ``embedl-hub log`` output (without the CLI command).

    Errors are silently swallowed so that this helper never masks
    a real exception in the calling command.

    :param project_dir: The project-scoped artifact directory.
    """
    try:
        _print_run_summary_impl(project_dir)
    except Exception:  # noqa: BLE001 – intentionally broad
        pass


def _format_timestamp(iso: str | None) -> str:
    """Format an ISO timestamp for display.

    :param iso: ISO-8601 timestamp string, or ``None``.
    :return: Human-readable date/time string, or ``""``.
    """
    if iso is None:
        return ""
    from datetime import datetime

    try:
        dt = datetime.fromisoformat(iso)
        return dt.strftime("%Y-%m-%d %H:%M:%S")
    except (ValueError, TypeError):
        return str(iso)


def _extract_provider_types(data: dict) -> set[str]:
    """Extract device provider types from run data.

    Checks the ``devices`` section first, then falls back to the
    ``device_provider_type`` parameter.

    :param data: The full parsed ``run.yaml`` dict.
    :return: Set of provider type strings (may be empty).
    """
    devices_data = data.get("devices") or {}
    provider_types: set[str] = {
        d.get("provider_type", "")
        for d in devices_data.values()
        if isinstance(d, dict) and d.get("provider_type")
    }
    if not provider_types:
        params = data.get("params") or {}
        raw = (params.get("device_provider_type") or {}).get("value", "")
        if "." in raw:
            raw = raw.rsplit(".", 1)[-1]
        raw = raw.strip().lower()
        if raw:
            provider_types = {raw}
    return provider_types


def _print_run_summary_impl(project_dir: Path) -> None:
    """Render the run summary panel (may raise on I/O errors).

    :param project_dir: The project-scoped artifact directory.
    """
    from rich.panel import Panel

    from embedl_hub._internal.core.hub_logging import console

    dirs = find_run_dirs(project_dir)
    if not dirs:
        return

    run_dir = dirs[0]
    yaml_path = run_dir / "run.yaml"
    if not yaml_path.exists():
        return

    with open(yaml_path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    if data is None:
        return

    run_data = data.get("run") or {}
    run_id = run_data.get("id", "")
    run_name = run_data.get("name")
    component_type = run_data.get("component_type")
    status = run_data.get("status")
    started_at = run_data.get("started_at")
    parent_run_id = run_data.get("parent_run_id")

    short = run_id[:8] if len(run_id) > 8 else run_id

    # -- Name / component fragment --
    name_frag = ""
    if run_name and run_name == component_type:
        name_frag = f"[cyan]{run_name}[/]"
    else:
        if run_name:
            name_frag = f"[bold]{run_name}[/]"
        if component_type:
            name_frag += f"  [dim]([/][cyan]{component_type}[/][dim])[/]"

    # -- Status --
    status_color = {
        "FINISHED": "green",
        "FAILED": "red",
        "KILLED": "red",
        "RUNNING": "blue",
    }.get(status or "", "dim")
    status_frag = f"[{status_color}]{status}[/]" if status else ""

    # -- Hub link --
    project_id = run_data.get("project_id")
    hub_url = run_data.get("hub_url")
    link = ""
    if project_id and hub_url and run_id:
        base = hub_url.rstrip("/")
        link = f"{base}/projects/{project_id}/runs/{run_id}"

    # -- Assemble lines --
    lines: list[str] = []

    line1 = f"[yellow]{short}[/]"
    if name_frag:
        line1 += f"  {name_frag}"
    lines.append(line1)

    line2_parts: list[str] = []
    time_frag = _format_timestamp(started_at)
    if time_frag:
        line2_parts.append(time_frag)
    if status_frag:
        line2_parts.append(status_frag)
    provider_types = _extract_provider_types(data)
    if provider_types:
        line2_parts.append(f"[magenta]{', '.join(sorted(provider_types))}[/]")
    if line2_parts:
        lines.append(f"  {' · '.join(line2_parts)}")

    if link:
        lines.append(f"  url: [dim link={link}]{link}[/]")

    if parent_run_id:
        short_parent = (
            parent_run_id[:8] if len(parent_run_id) > 8 else parent_run_id
        )
        lines.append(f"  input: [yellow]{short_parent}[/]")

    lines.append(f"  dir: [dim]{run_dir.resolve()}/[/]")

    # -- Panel border colour --
    border_style = "dim green"
    if status in ("FAILED", "KILLED"):
        border_style = "dim red"
    elif status == "RUNNING":
        border_style = "dim blue"

    console.print()
    console.print(
        Panel(
            "\n".join(lines),
            title="Run Summary",
            border_style=border_style,
            expand=False,
        )
    )
