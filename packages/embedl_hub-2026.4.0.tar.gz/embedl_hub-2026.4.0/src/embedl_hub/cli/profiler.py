# Copyright (C) 2025, 2026 Embedl AB

"""
embedl-hub profile — profile a compiled model on a target device.

The CLI hierarchy is::

    profile <toolchain> <provider> [args …]

Toolchains
~~~~~~~~~~
* ``tflite``      — Profile via :class:`~embedl_hub._internal.core.profile.tflite.TFLiteProfiler`
* ``onnxruntime`` — Profile via :class:`~embedl_hub._internal.core.profile.onnxruntime.ONNXRuntimeProfiler`
* ``tensorrt``    — Profile via :class:`~embedl_hub._internal.core.profile.tensorrt.TensorRTProfiler`

Backends vary per toolchain:

======================  ======  ==========  ==================  ======
Backend                tflite  onnxruntime embedl-onnxruntime  trtexec
======================  ======  ==========  ==================  ======
``qai-hub``              ✓       ✓
``aws``                  ✓
``embedl-onnxruntime``                       ✓
``trtexec``                                                      ✓
======================  ======  ==========  ==================  ======
"""

from pathlib import Path

import typer

from embedl_hub._internal.core.config import get_artifact_dir
from embedl_hub.cli.commands import (
    PROJECT_NAME_OPTION,
    RUN_NAME_OPTION,
    TAGS_OPTION,
)
from embedl_hub.cli.helper import (
    DEVICE_HELPER,
    EMBEDL_BENCHMARK_PARAM_HELPER,
    EMBEDL_ORT_CLI_ARGS_HELPER,
    EMBEDL_ORT_PATH_HELPER,
    SSH_HOST_HELPER,
    SSH_KEY_HELPER,
    SSH_PORT_HELPER,
    SSH_USER_HELPER,
    TRTEXEC_CLI_ARGS_HELPER,
    TRTEXEC_PATH_HELPER,
)
from embedl_hub.cli.resolve_run import FROM_RUN_HELP, resolve_model_input
from embedl_hub.cli.run_metadata import (
    print_run_summary,
    save_cli_yaml_for_latest_run,
)

# ===================================================================== #
# Top-level group: profiler
# ===================================================================== #

profiler_cli = typer.Typer(
    name="profile",
    help="Profile a compiled model on a target device.",
    no_args_is_help=True,
)

# ===================================================================== #
# tflite toolchain
# ===================================================================== #

_profiler_tflite_cli = typer.Typer(
    name="tflite",
    help="Profile using TFLite toolchain.",
    no_args_is_help=True,
)
profiler_cli.add_typer(_profiler_tflite_cli)


@_profiler_tflite_cli.command("qai-hub", no_args_is_help=True)
def profiler_tflite_qai_hub(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled .tflite model file.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    device: str = typer.Option(
        ..., "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Profile a TFLite model via Qualcomm AI Hub.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Profile a .tflite model on Samsung Galaxy S25::

        $ embedl-hub profile tflite qai-hub -m my_model.tflite -d "Samsung Galaxy S25"
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.tflite import TFLiteCompiledModel
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.profile.tflite import TFLiteProfiler
    from embedl_hub.cli.context import (
        create_qai_hub_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        print_profile_summary,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        TFLiteCompiledModel,
    )
    label = model.name if model else from_run
    console.log(f"Profiling {label} on {device} using Qualcomm AI Hub")

    tags_dict = parse_tags(tags)

    hub_ctx = create_qai_hub_context(
        project_name=resolved_project,
        device_name=device,
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            profiler = TFLiteProfiler(name=run_name)
            result = profiler.run(hub_ctx, compiled_model, device="main")
            summary = {}
            if result.latency is not None:
                summary["mean_ms"] = result.latency.value
            if result.fps is not None:
                summary["fps"] = result.fps.value
        print_profile_summary(summary)
        console.print(
            f"[green]✓ Saved profile artifacts to:[/] {project_dir.absolute()}"
        )
    except Exception as exc:
        console.print(f"[red]✗ profiling failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


@_profiler_tflite_cli.command("aws", no_args_is_help=True)
def profiler_tflite_aws(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled .tflite model file.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    device: str = typer.Option(
        ..., "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    benchmark_params: list[str] | None = typer.Option(
        None,
        "--param",
        "-p",
        help=EMBEDL_BENCHMARK_PARAM_HELPER,
        show_default=False,
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Profile a TFLite model on the Embedl device cloud (AWS).

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Profile a .tflite model on Samsung Galaxy S25::

        $ embedl-hub profile tflite aws -m my_model.tflite -d "Samsung Galaxy S25"

    Profile with custom TFLite benchmark parameters::

        $ embedl-hub profile tflite aws -m my_model.tflite -d "Samsung Galaxy S25" -p num_threads=2 -p warmup_runs=10
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.tflite import TFLiteCompiledModel
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.profile.tflite import TFLiteProfiler
    from embedl_hub._internal.tracking.device_cloud import (
        TFLiteBenchmarkParams,
    )
    from embedl_hub._internal.tracking.errors import JobQuotaExceededError
    from embedl_hub.cli.context import (
        create_aws_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        print_profile_summary,
    )
    # pylint: enable=import-outside-toplevel

    parsed_params: dict[str, str] = {}
    if benchmark_params:
        for param in benchmark_params:
            if "=" not in param:
                raise typer.BadParameter(
                    f"Invalid benchmark param format: '{param}'. Expected key=value."
                )
            key, value = param.split("=", 1)
            parsed_params[key] = value

    bp: TFLiteBenchmarkParams | None = None
    if parsed_params:
        try:
            bp = TFLiteBenchmarkParams(parsed_params)
        except ValueError as e:
            raise typer.BadParameter(str(e))

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        TFLiteCompiledModel,
    )
    label = model.name if model else from_run
    console.log(f"Profiling {label} on {device}")

    tags_dict = parse_tags(tags)

    hub_ctx = create_aws_context(
        project_name=resolved_project,
        device_name=device,
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    profiler = TFLiteProfiler(name=run_name)

    try:
        with hub_ctx:
            result = profiler.run(
                hub_ctx,
                compiled_model,
                device="main",
                benchmark_params=bp,
            )
            summary = {}
            if result.latency is not None:
                summary["mean_ms"] = result.latency.value
            if result.fps is not None:
                summary["fps"] = result.fps.value
        print_profile_summary(summary)
        console.print(
            f"[green]✓ Saved profile artifacts to:[/] {project_dir.absolute()}"
        )
    except JobQuotaExceededError as exc:
        console.print(f"[red]Job quota exceeded:[/] {exc}")
        raise typer.Exit(1)
    except Exception as exc:
        console.print(f"[red]✗ profiling failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


# ===================================================================== #
# onnxruntime toolchain
# ===================================================================== #

_profiler_onnxruntime_cli = typer.Typer(
    name="onnxruntime",
    help="Profile using ONNX Runtime toolchain.",
    no_args_is_help=True,
)
profiler_cli.add_typer(_profiler_onnxruntime_cli)


@_profiler_onnxruntime_cli.command("qai-hub", no_args_is_help=True)
def profiler_onnxruntime_qai_hub(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled ONNX model file or directory.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    device: str = typer.Option(
        ..., "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Profile an ONNX Runtime model via Qualcomm AI Hub.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Profile an .onnx model on Samsung Galaxy S25::

        $ embedl-hub profile onnxruntime qai-hub -m my_model.onnx -d "Samsung Galaxy S25"
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.onnxruntime import (
        ONNXRuntimeCompiledModel,
    )
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.profile.onnxruntime import (
        ONNXRuntimeProfiler,
    )
    from embedl_hub.cli.context import (
        create_qai_hub_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        print_profile_summary,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        ONNXRuntimeCompiledModel,
    )
    label = model.name if model else from_run
    console.log(f"Profiling {label} on {device} using Qualcomm AI Hub")

    tags_dict = parse_tags(tags)

    hub_ctx = create_qai_hub_context(
        project_name=resolved_project,
        device_name=device,
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            profiler = ONNXRuntimeProfiler(name=run_name)
            result = profiler.run(hub_ctx, compiled_model, device="main")
            summary = {}
            if result.latency is not None:
                summary["mean_ms"] = result.latency.value
            if result.fps is not None:
                summary["fps"] = result.fps.value
        print_profile_summary(summary)
        console.print(
            f"[green]✓ Saved profile artifacts to:[/] {project_dir.absolute()}"
        )
    except Exception as exc:
        console.print(f"[red]✗ profiling failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


@_profiler_onnxruntime_cli.command("embedl-onnxruntime", no_args_is_help=True)
def profiler_onnxruntime_embedl_ort(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled ONNX model file.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    host: str = typer.Option(
        ..., "--host", help=SSH_HOST_HELPER, show_default=False
    ),
    username: str = typer.Option(
        ..., "--user", help=SSH_USER_HELPER, show_default=False
    ),
    port: int = typer.Option(22, "--port", help=SSH_PORT_HELPER),
    key_file: Path | None = typer.Option(
        None, "--key-file", help=SSH_KEY_HELPER, show_default=False
    ),
    exec_path: str | None = typer.Option(
        None, "--exec-path", help=EMBEDL_ORT_PATH_HELPER, show_default=False
    ),
    extra_args: list[str] | None = typer.Option(
        None, "--cli-args", help=EMBEDL_ORT_CLI_ARGS_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Profile an ONNX Runtime model on a remote device via SSH.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Profile model on a remote device::

        $ embedl-hub profile onnxruntime embedl-onnxruntime -m my_model.onnx --host 192.168.1.10 --user pi
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.onnxruntime import (
        ONNXRuntimeCompiledModel,
    )
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.profile.onnxruntime import (
        ONNXRuntimeProfiler,
    )
    from embedl_hub.cli.context import (
        create_embedl_onnxruntime_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        print_profile_summary,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        ONNXRuntimeCompiledModel,
    )
    label = model.name if model else from_run
    console.log(f"Profiling {label} on {host}")

    tags_dict = parse_tags(tags)

    hub_ctx = create_embedl_onnxruntime_context(
        project_name=resolved_project,
        host=host,
        username=username,
        port=port,
        private_key_path=key_file,
        exec_path=exec_path,
        cli_args=tuple(extra_args) if extra_args else (),
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            profiler = ONNXRuntimeProfiler(name=run_name)
            result = profiler.run(hub_ctx, compiled_model, device="main")
            summary = {}
            if result.latency is not None:
                summary["mean_ms"] = result.latency.value
            if result.fps is not None:
                summary["fps"] = result.fps.value
        print_profile_summary(summary)
        console.print(
            f"[green]✓ Saved profile artifacts to:[/] {project_dir.absolute()}"
        )
    except Exception as exc:
        console.print(f"[red]✗ profiling failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


# ===================================================================== #
# tensorrt toolchain
# ===================================================================== #

_profiler_tensorrt_cli = typer.Typer(
    name="tensorrt",
    help="Profile using TensorRT toolchain.",
    no_args_is_help=True,
)
profiler_cli.add_typer(_profiler_tensorrt_cli)


@_profiler_tensorrt_cli.command("trtexec", no_args_is_help=True)
def profiler_tensorrt_trtexec(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled TensorRT engine file.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    host: str = typer.Option(
        ..., "--host", help=SSH_HOST_HELPER, show_default=False
    ),
    username: str = typer.Option(
        ..., "--user", help=SSH_USER_HELPER, show_default=False
    ),
    port: int = typer.Option(22, "--port", help=SSH_PORT_HELPER),
    key_file: Path | None = typer.Option(
        None, "--key-file", help=SSH_KEY_HELPER, show_default=False
    ),
    exec_path: str | None = typer.Option(
        None, "--exec-path", help=TRTEXEC_PATH_HELPER, show_default=False
    ),
    extra_args: list[str] | None = typer.Option(
        None, "--cli-args", help=TRTEXEC_CLI_ARGS_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Profile a TensorRT model on a remote NVIDIA device via SSH.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Profile a TensorRT engine on a remote NVIDIA device::

        $ embedl-hub profile tensorrt trtexec -m my_model.engine --host 192.168.1.10 --user nvidia
    """

    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.compile.tensorrt import (
        TensorRTCompiledModel,
    )
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.profile.tensorrt import TensorRTProfiler
    from embedl_hub.cli.context import (
        create_trtexec_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import (
        assert_api_config,
        parse_tags,
        print_profile_summary,
    )
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        TensorRTCompiledModel,
    )
    label = model.name if model else from_run
    console.log(f"Profiling {label} on {host}")

    tags_dict = parse_tags(tags)

    hub_ctx = create_trtexec_context(
        project_name=resolved_project,
        host=host,
        username=username,
        port=port,
        private_key_path=key_file,
        exec_path=exec_path,
        cli_args=tuple(extra_args) if extra_args else (),
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            profiler = TensorRTProfiler(name=run_name)
            result = profiler.run(hub_ctx, compiled_model, device="main")
            summary = {}
            if result.latency is not None:
                summary["mean_ms"] = result.latency.value
            if result.fps is not None:
                summary["fps"] = result.fps.value
        print_profile_summary(summary)
        console.print(
            f"[green]✓ Saved profile artifacts to:[/] {project_dir.absolute()}"
        )
    except Exception as exc:
        console.print(f"[red]✗ profiling failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)
