# Copyright (C) 2025, 2026 Embedl AB

"""Utility functions for the Embedl Hub CLI."""

from pathlib import Path
from typing import Any

import tabulate
import typer

from embedl_hub._internal.core.hub_logging import console
from embedl_hub._internal.core.utils.onnx_utils import (
    maybe_package_onnx_folder_to_file,
)
from embedl_hub._internal.tracking.client import Client


def remove_none_values(input_dict: dict[str, Any]) -> dict[str, Any]:
    """Remove keys with ``None`` values from a dictionary.

    :param input_dict: Dictionary to filter.
    :return: A new dictionary with all ``None``-valued entries removed.
    """
    return {key: val for key, val in input_dict.items() if val is not None}


def assert_api_config():
    """Assert that the API configuration can be accessed without error."""
    try:
        _ = Client().api_config
    except RuntimeError as e:
        console.print(f"[red]✗[/] API configuration error: {e}")
        raise typer.Exit(1)


def parse_tags(tag_values: list[str] | None) -> dict[str, str] | None:
    """Parse CLI tag values in ``key=value`` format.

    :param tag_values: Raw tag strings from the CLI, or ``None``.
    :return: Parsed tag dict, or ``None`` if `tag_values` is empty.
    :raises typer.BadParameter: If a tag is not in ``key=value`` format
        or has an empty key or value.
    """

    if not tag_values:
        return None

    tags: dict[str, str] = {}
    for raw in tag_values:
        if "=" not in raw:
            raise typer.BadParameter(
                f"Invalid tag '{raw}'. Expected format: key=value"
            )
        key, value = raw.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key or not value:
            raise typer.BadParameter(
                f"Invalid tag '{raw}'. Expected non-empty key and value"
            )
        tags[key] = value

    return tags


def prepare_input_size(size: str | None) -> tuple[int, ...] | None:
    """Parse a comma-separated size string into a tuple of integers.

    :param size: Dimension string (e.g. ``"1,3,224,224"``), or ``None``.
    :return: Parsed dimensions, or ``None`` if `size` is empty.
    :raises ValueError: If the string cannot be parsed as integers.
    """
    if not size:
        return None
    try:
        sizes = tuple(map(int, size.split(",")))
    except ValueError as error:
        raise ValueError(
            "Invalid size format. Use dim0, dim1,..., e.g. 1,3,224,224"
        ) from error
    console.print(f"[yellow]Using input size: {size}[/]")
    return sizes


def _make_layer_times_table(layer_times: list) -> str:
    """Create a pretty-printed table of layer execution times.

    :param layer_times: List of ``(time_ms, name, layer_type)`` tuples.
    :return: Formatted Markdown-style table string.
    """
    headers = ["Name", "Type", "Time (ms)"]
    rows = [
        [name, layer_type, f"{time:.2f}" if time is not None else "—"]
        for time, name, layer_type in layer_times
    ]
    title = f"Layer execution times (Top {len(layer_times)})"
    table = tabulate.tabulate(rows, headers=headers, tablefmt="github")
    return f"\n{title}\n{table}\n"


def print_profile_summary(summary: dict) -> None:
    """Print a profiling summary to the console.

    Displays mean latency, peak memory usage, layer counts by compute
    unit, and a per-layer timing table when available.

    :param summary: Summary dict as returned by the profiling parsers.
    """
    if summary.get("mean_ms") is not None:
        console.print(f"[green]✓ Mean latency:[/] {summary['mean_ms']:.2f} ms")
    if summary.get("peak_memory_usage_mb") is not None:
        console.print(
            f"[green]✓ Peak memory usage:[/] {summary['peak_memory_usage_mb']:.2f} MB"
        )
    if summary.get("layers_by_unit"):
        layers_by_unit = ", ".join(
            f"{k}={v}" for k, v in summary["layers_by_unit"].items()
        )
        console.print(f"[green]✓ Layers by compute unit:[/] {layers_by_unit}")
    if summary.get("layer_times"):
        table = _make_layer_times_table(summary["layer_times"])
        console.print(table)


def prepare_compile_kwargs(
    model: Path,
    device: str,
    runtime: str,
    size: str,
    tmpdir: Path | str,
    quantize_io: bool = False,
    output_file: Path | str | None = None,
) -> dict:
    """Build keyword arguments for the compile function.

    :param model: Path to the model file.
    :param device: Target device name.
    :param runtime: Target runtime identifier.
    :param size: Comma-separated input dimensions (e.g. ``"1,3,224,224"``).
    :param tmpdir: Temporary directory for intermediate files.
    :param quantize_io: Whether to quantize model I/O.
    :param output_file: Optional explicit output path; defaults to the
        model path with a runtime-based suffix.
    :return: Dict of keyword arguments suitable for the compile function.
    :raises ValueError: If `model` does not exist or `size` is empty.
    """

    if not model.exists():
        raise ValueError(f"Model not found: {model}")
    if not size:
        raise ValueError(
            "Please specify input size using --size, e.g. 1,3,224,224"
        )

    if not output_file:
        output_file = model.with_suffix(f".{runtime}").as_posix()
        console.print(
            f"[yellow]No output file specified, using {output_file}[/]"
        )
    input_size = prepare_input_size(size)
    model_path = maybe_package_onnx_folder_to_file(model, tmpdir)
    return {
        "model_path": model_path,
        "device": device,
        "runtime": runtime,
        "quantize_io": quantize_io,
        "output_file": output_file,
        "input_size": input_size,
    }


def fetch_quantization_recipes() -> list[str]:
    """Fetch available quantization recipes from ``ai_edge_quantizer``.

    :return: List of recipe names.
    """
    # pylint: disable=import-outside-toplevel
    from ai_edge_quantizer import recipe
    # pylint: enable=import-outside-toplevel

    return [
        attr
        for attr in dir(recipe)
        if not attr.startswith("_")
        and callable(getattr(recipe, attr))
        and attr != "AlgorithmName"
    ]
