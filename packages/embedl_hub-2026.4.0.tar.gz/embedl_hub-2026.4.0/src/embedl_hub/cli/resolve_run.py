# Copyright (C) 2026 Embedl AB

"""Resolve a past run from the artifact directory.

Used by ``--from-run`` in the profile and invoke CLI commands to
load a :class:`~embedl_hub._internal.core.component.output.ComponentOutput`
from a previous run, identified either by ``"latest"`` or by a
run-ID prefix.
"""

from __future__ import annotations

from pathlib import Path
from typing import TypeVar

import yaml

from embedl_hub._internal.core.component.output import ComponentOutput
from embedl_hub._internal.core.types import LocalPath
from embedl_hub.cli.run_metadata import find_run_dirs

T = TypeVar("T", bound=ComponentOutput)


# -- Option help text -------------------------------------------------------

FROM_RUN_HELP = (
    'Load a compiled model from a previous run.  Use "latest" to pick '
    "the most recent matching run, or provide a run-ID prefix."
)


class RunResolutionError(Exception):
    """Raised when a run cannot be resolved from the artifact directory."""


def _print_resolved_run(output: ComponentOutput) -> None:
    """Print the resolved run ID and name so the user knows what was picked."""
    from embedl_hub._internal.core.hub_logging import console

    run_log = output.run_log
    if run_log is None:
        return
    run_id = run_log.run_id or ""
    short = run_id[:8] if len(run_id) > 8 else run_id
    name = run_log.run_name or ""
    component = run_log.component_type or ""

    label = ""
    if name and name != component:
        label = f"  [bold]{name}[/]  [dim]([/][cyan]{component}[/][dim])[/]"
    elif name:
        label = f"  [cyan]{name}[/]"

    console.print(f"[dim]Using output from run[/] [yellow]{short}[/]{label}")


def resolve_model_input(
    model: Path | None,
    from_run: str | None,
    project_dir: Path,
    expected_output_type: type[T],
) -> T:
    """Validate ``-m`` / ``--from-run`` mutual exclusion and return a model.

    Exactly one of `model` and `from_run` must be provided.

    :param model: ``-m`` model path (may be ``None``).
    :param from_run: ``--from-run`` value (``"latest"`` or ID prefix, or ``None``).
    :param project_dir: Project-scoped artifact directory for run lookups.
    :param expected_output_type: The :class:`~embedl_hub._internal.core.component.output.ComponentOutput`
        subclass to reconstruct (e.g. ``TFLiteCompiledModel``).
    :return: An instance of `expected_output_type`.
    :raises typer.BadParameter: If neither or both options are supplied,
        or if the model path does not exist.
    :raises RunResolutionError: If the run cannot be resolved.
    """
    import typer

    if model is not None and from_run is not None:
        raise typer.BadParameter(
            "Provide either -m/--model or --from-run, not both."
        )
    if model is None and from_run is None:
        raise typer.BadParameter("Provide either -m/--model or --from-run.")

    if from_run is not None:
        result = resolve_run(from_run, project_dir, expected_output_type)
        _print_resolved_run(result)
        return result

    # -m path
    assert model is not None  # noqa: S101
    if not model.exists():
        raise typer.BadParameter(f"Model path does not exist: {model}")
    return expected_output_type.from_path(model)


def _read_run_data(run_dir: LocalPath) -> dict | None:
    """Read the ``run.yaml`` from `run_dir`, returning ``None`` on error.

    :param run_dir: Path to a run directory.
    :return: Parsed dict or ``None`` if the file is absent or invalid.
    """
    yaml_path = run_dir / "run.yaml"
    try:
        with open(yaml_path, encoding="utf-8") as fh:
            return yaml.safe_load(fh)
    except Exception:
        return None


def resolve_run(
    from_run: str,
    project_dir: Path,
    expected_output_type: type[T],
) -> T:
    """Resolve ``--from-run`` to a :class:`ComponentOutput` instance.

    :param from_run: Either ``"latest"`` or a run-ID prefix.
    :param project_dir: The project-scoped artifact directory.
    :param expected_output_type: The :class:`~embedl_hub._internal.core.component.output.ComponentOutput`
        subclass that the caller expects (e.g. ``TFLiteCompiledModel``).
    :return: An instance of `expected_output_type` reconstructed from
        the matching run's ``run.yaml``.
    :raises RunResolutionError: If no matching run is found, the
        ``output_type`` does not match, or the YAML cannot be parsed.
    """
    expected_name = expected_output_type.__name__

    if from_run.lower() == "latest":
        return _resolve_latest(project_dir, expected_output_type)
    return _resolve_by_id(from_run, project_dir, expected_output_type)


def _resolve_latest(
    project_dir: Path,
    expected_output_type: type[T],
) -> T:
    """Find the most recent run whose ``output_type`` matches.

    :param project_dir: The project-scoped artifact directory.
    :param expected_output_type: The expected
        :class:`~embedl_hub._internal.core.component.output.ComponentOutput` subclass.
    :return: An instance of `expected_output_type`.
    :raises RunResolutionError: If no matching run is found.
    """
    expected_name = expected_output_type.__name__
    run_dirs = find_run_dirs(project_dir)

    if not run_dirs:
        raise RunResolutionError(f"No runs found in {project_dir}.")

    for run_dir in run_dirs:
        data = _read_run_data(run_dir)
        if data is None:
            continue
        run_data = data.get("run") or {}
        output_type = run_data.get("output_type")
        if output_type == expected_name:
            return _load_output(run_dir, expected_output_type)

    raise RunResolutionError(
        f"No run with output_type '{expected_name}' found in {project_dir}."
    )


def _resolve_by_id(
    id_prefix: str,
    project_dir: Path,
    expected_output_type: type[T],
) -> T:
    """Find a run whose ID starts with `id_prefix` and validate its type.

    :param id_prefix: Run-ID prefix to search for.
    :param project_dir: The project-scoped artifact directory.
    :param expected_output_type: The expected
        :class:`~embedl_hub._internal.core.component.output.ComponentOutput` subclass.
    :return: An instance of `expected_output_type`.
    :raises RunResolutionError: If no matching run is found, the prefix
        is ambiguous, or the output type does not match.
    """
    expected_name = expected_output_type.__name__
    run_dirs = find_run_dirs(project_dir)

    if not run_dirs:
        raise RunResolutionError(f"No runs found in {project_dir}.")

    matches: list[tuple[LocalPath, dict]] = []
    for run_dir in run_dirs:
        data = _read_run_data(run_dir)
        if data is None:
            continue
        run_data = data.get("run") or {}
        run_id = run_data.get("id", "")
        if run_id.startswith(id_prefix):
            matches.append((run_dir, data))

    if not matches:
        raise RunResolutionError(
            f"No run with ID starting with '{id_prefix}' found in "
            f"{project_dir}."
        )

    if len(matches) > 1:
        ids = [m[1].get("run", {}).get("id", "?") for m in matches]
        raise RunResolutionError(
            f"Ambiguous run ID prefix '{id_prefix}' matches "
            f"{len(matches)} runs: {', '.join(ids[:5])}. "
            f"Provide a longer prefix."
        )

    run_dir, data = matches[0]
    run_data = data.get("run") or {}
    output_type = run_data.get("output_type")

    if output_type != expected_name:
        raise RunResolutionError(
            f"Run '{run_data.get('id', '?')}' has output_type "
            f"'{output_type}', but expected '{expected_name}'."
        )

    return _load_output(run_dir, expected_output_type)


def _load_output(
    run_dir: LocalPath,
    output_type: type[T],
) -> T:
    """Load a :class:`~embedl_hub._internal.core.component.output.ComponentOutput`
    from a run directory's ``run.yaml``.

    :param run_dir: Path to the run directory.
    :param output_type: The
        :class:`~embedl_hub._internal.core.component.output.ComponentOutput` subclass
        to reconstruct.
    :return: An instance of `output_type`.
    :raises RunResolutionError: If the YAML cannot be loaded.
    """
    yaml_path = run_dir / "run.yaml"
    try:
        return output_type.from_yaml(yaml_path)
    except Exception as exc:
        raise RunResolutionError(
            f"Failed to load {output_type.__name__} from {yaml_path}: {exc}"
        ) from exc
