# Copyright (C) 2025, 2026 Embedl AB
"""
embedl-hub list-devices - List all available target devices for the commands
`compile`, `profiler` and `invoke`.
"""

import typer

list_devices_cli = typer.Typer(
    name="list-devices",
    help="List available devices (default subcommand: 'embedl').",
    invoke_without_command=True,
)


@list_devices_cli.callback(invoke_without_command=True)
def list_devices_command(ctx: typer.Context):
    """
    List all available target devices.

    A device name is used as input to the `--device` option
    in the commands `compile`, `profiler` and `invoke`.

    Device lists are available from different providers:
    - `embedl`: Devices from Embedl Cloud (default).
    - `qai-hub`: Devices from Qualcomm AI Hub.
    """
    # pylint: disable=import-outside-toplevel
    from embedl_hub.cli.context import require_initialized_ctx
    from embedl_hub.cli.utils import assert_api_config
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    if ctx.invoked_subcommand is None:
        ctx.invoke(embedl_list_devices_command)


@list_devices_cli.command("embedl")
def embedl_list_devices_command():
    """
    List all available target devices from Embedl Cloud.
    """
    # pylint: disable=import-outside-toplevel
    from rich.table import Table

    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.tracking.client import Client
    # pylint: enable=import-outside-toplevel

    devices = Client().get_devices()
    table = Table(title="Embedl Hub devices")
    table.add_column("Name", style="cyan")
    table.add_column("Vendor")
    table.add_column("Platform")
    table.add_column("OS")
    table.add_column("Type")
    for device in devices:
        table.add_row(
            device.name, device.vendor, device.platform, device.os, device.type
        )
    console.print(table)


@list_devices_cli.command("qai-hub")
def qai_hub_list_devices_command():
    """
    List all available target devices from Qualcomm AI Hub.
    """
    # pylint: disable=import-outside-toplevel
    import qai_hub as hub
    from rich.table import Table

    from embedl_hub._internal.core.hub_logging import console
    # pylint: enable=import-outside-toplevel

    table = Table(title="Embedl Hub devices")
    table.add_column("Name", style="cyan")
    table.add_column("Cloud")
    table.add_column("OS")
    table.add_column("Chipset / Attrs", overflow="fold")
    devices = [
        (
            d.name,
            "qai-hub",
            d.os or "—",
            ", ".join(a for a in d.attributes if "chipset" in a) or "—",
        )
        for d in hub.get_devices()
    ]
    for row in devices:
        table.add_row(*row)
    console.print(table)
