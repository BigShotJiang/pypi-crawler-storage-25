# Copyright (C) 2026 Embedl AB

"""embedl-hub log — display past runs from the artifact directory.

Scans the artifact directory (configured via ``embedl-hub init``) for
timestamped run subdirectories, reads their ``run.yaml`` (and optional
``cli.yaml``) metadata, and prints a concise, git-log-style summary.
"""

import typer

from embedl_hub._internal.core.config import get_project_dir, load_ctx_config

log_cli = typer.Typer(
    name="log",
    help="Show past runs from the artifact directory.",
    invoke_without_command=True,
)


def _short_id(run_id: str, length: int = 8) -> str:
    """Return a shortened run ID, similar to a short git hash."""
    return run_id[:length] if len(run_id) > length else run_id


def _shorten_command(command: str) -> str:
    """Replace the full binary path with ``embedl-hub``.

    Turns e.g. ``/home/user/.venv/bin/embedl-hub compile …`` into
    ``embedl-hub compile …``.  If the command does not look like an
    embedl-hub invocation the string is returned unchanged.

    :param command: The raw command string from ``cli.yaml``.
    :return: Shortened command string.
    """
    parts = command.split(None, 1)
    if not parts:
        return command
    binary = parts[0]
    # Strip directory path — keep only the filename.
    basename = binary.rsplit("/", 1)[-1]
    if basename.startswith("embedl-hub") or basename.startswith("embedl_hub"):
        rest = parts[1] if len(parts) > 1 else ""
        return f"embedl-hub {rest}".rstrip()
    return command


@log_cli.callback(invoke_without_command=True)
def log_command(
    run_ids: list[str] | None = typer.Argument(
        None,
        help="Run ID(s) or prefixes to display. Bypasses status filters.",
    ),
    count: int = typer.Option(
        20,
        "-n",
        "--count",
        help="Maximum number of runs to display.",
    ),
    show_all: bool = typer.Option(
        False,
        "--all",
        "-a",
        help="Show all runs including failed ones.",
    ),
    failed: bool = typer.Option(
        False,
        "--failed",
        help="Show only failed runs.",
    ),
    oneline: bool = typer.Option(
        False,
        "--oneline",
        help="Compact one-line-per-run output.",
    ),
    full_command: bool = typer.Option(
        False,
        "--full-command",
        help="Show the full binary path in CLI commands.",
    ),
    project_name: str | None = typer.Option(
        None,
        "--project-name",
        "-pn",
        help="Project name to show logs for. Defaults to the configured project.",
    ),
) -> None:
    """Show past runs from the artifact directory.

    Reads from the artifact directory configured by
    ``embedl-hub init --artifact-dir``.

    By default, failed runs are hidden.  Use ``--all`` to include them
    or ``--failed`` to show only failed runs.

    You can also pass one or more run IDs (or prefixes) as positional
    arguments to display specific runs regardless of status.

    Examples
    --------

    Show the last 20 runs::

        $ embedl-hub log

    Include failed runs::

        $ embedl-hub log --all

    Show only failed runs::

        $ embedl-hub log --failed

    Show specific runs by ID prefix::

        $ embedl-hub log abc123 def456
    """

    # pylint: disable=import-outside-toplevel
    import yaml

    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub.cli.run_metadata import (
        _extract_provider_types,
        _format_timestamp,
        find_run_dirs,
        load_cli_yaml,
    )
    # pylint: enable=import-outside-toplevel

    config = load_ctx_config()
    resolved_project = project_name or config.get("project_name", "")
    artifact_base_dir = get_project_dir(config, project_name)

    run_dirs = find_run_dirs(artifact_base_dir)

    if not run_dirs:
        if resolved_project:
            console.print(f"[bold]Project:[/] [cyan]{resolved_project}[/]")
        console.print(
            f"[dim]No runs found in {artifact_base_dir.absolute()}[/]"
        )
        raise typer.Exit()

    # When explicit IDs are given, we resolve them up-front so we can
    # bypass status filters and report unmatched prefixes.
    explicit_ids: set[str] = set(run_ids) if run_ids else set()

    # -- Pre-scan to compute summary stats --------------------------------
    total_runs = len(run_dirs)
    pre_hidden_failed = 0
    pre_visible = 0
    if not explicit_ids:
        for run_dir in run_dirs:
            yaml_path = run_dir / "run.yaml"
            try:
                with open(yaml_path, encoding="utf-8") as fh:
                    data = yaml.safe_load(fh)
            except Exception:
                data = None
            if data is None:
                pre_visible += 1
                continue
            run_data = data.get("run") or {}
            status = run_data.get("status")
            is_failed = status in ("FAILED", "KILLED")
            if failed and not is_failed:
                continue
            if not show_all and not failed and is_failed:
                pre_hidden_failed += 1
                continue
            pre_visible += 1

    with console.pager(styles=True):
        # -- Print header --------------------------------------------------
        if resolved_project:
            console.print(f"[bold]Project:[/] [cyan]{resolved_project}[/]")

        if not explicit_ids and pre_hidden_failed > 0:
            noun = (
                "[red]failed[/] run"
                if pre_hidden_failed == 1
                else "[red]failed[/] runs"
            )
            console.print(
                f"[yellow]{pre_hidden_failed} {noun} hidden[/] "
                f"[dim](use [bold]--all[/bold] or [bold]--failed[/bold] "
                f"to show)[/]"
            )
        console.print()
        shown = 0
        hidden_failed = 0
        matched_ids: set[str] = set()
        for run_dir in run_dirs:
            if shown >= count and not explicit_ids:
                break

            yaml_path = run_dir / "run.yaml"
            try:
                with open(yaml_path, encoding="utf-8") as fh:
                    data = yaml.safe_load(fh)
            except Exception:
                data = None

            if data is None:
                if not explicit_ids:
                    console.print(
                        f"[yellow]![/] [dim]{run_dir.name}[/] "
                        f"[red](unreadable run.yaml)[/]"
                    )
                    console.print()
                    shown += 1
                continue

            run_data = data.get("run") or {}
            run_id = run_data.get("id", "")
            run_name = run_data.get("name")
            component_type = run_data.get("component_type")
            status = run_data.get("status")
            started_at = run_data.get("started_at")
            parent_run_id = run_data.get("parent_run_id")

            is_failed = status in ("FAILED", "KILLED")

            # Check if this run was explicitly requested by ID prefix
            explicitly_requested = False
            if explicit_ids:
                for prefix in explicit_ids:
                    if run_id.startswith(prefix):
                        explicitly_requested = True
                        matched_ids.add(prefix)
                        break
                if not explicitly_requested:
                    continue

            # Apply status filter (bypassed for explicitly requested runs)
            if not explicitly_requested:
                if failed and not is_failed:
                    continue
                if not show_all and not failed and is_failed:
                    hidden_failed += 1
                    continue

            if shown >= count and not explicitly_requested:
                break

            short = _short_id(run_id)

            # -- Build the name/component fragment (shared by both modes) --
            name_frag = ""
            if run_name and run_name == component_type:
                name_frag = f"[cyan]{run_name}[/]"
            else:
                if run_name:
                    name_frag = f"[bold]{run_name}[/]"
                if component_type:
                    name_frag += (
                        f"  [dim]([/][cyan]{component_type}[/][dim])[/]"
                    )

            # -- Build the status fragment --
            status_frag = ""
            if status:
                color = {
                    "FINISHED": "green",
                    "FAILED": "red",
                    "KILLED": "red",
                    "RUNNING": "blue",
                }.get(status, "dim")
                status_frag = f"[{color}]{status}[/]"

            # -- Build the hub link --
            project_id = run_data.get("project_id")
            hub_url = run_data.get("hub_url")
            link = ""
            if project_id and hub_url and run_id:
                base = hub_url.rstrip("/")
                link = f"{base}/projects/{project_id}/runs/{run_id}"

            if oneline:
                # Compact single-line output
                line_parts: list[str] = [f"[yellow]{short}[/]"]
                if name_frag:
                    line_parts.append(name_frag)
                if parent_run_id:
                    line_parts.append(
                        f"input:[yellow]{_short_id(parent_run_id)}[/]"
                    )
                if status_frag:
                    line_parts.append(status_frag)
                if link:
                    line_parts.append(f"[dim link={link}]{link}[/]")
                console.print(" · ".join(line_parts), soft_wrap=True)
            else:
                # Full multi-line output
                line1 = f"[yellow]{short}[/]"
                if name_frag:
                    line1 += f"  {name_frag}"
                console.print(line1)

                # Line 2:  DATE  STATUS  PROVIDER
                line2_parts: list[str] = []
                if started_at:
                    line2_parts.append(_format_timestamp(started_at))
                if status_frag:
                    line2_parts.append(status_frag)
                provider_types = _extract_provider_types(data)
                if provider_types:
                    line2_parts.append(
                        f"[magenta]{', '.join(sorted(provider_types))}[/]"
                    )
                if line2_parts:
                    console.print(f"  {' · '.join(line2_parts)}")

                if link:
                    console.print(
                        f"  url: [dim link={link}]{link}[/]",
                        soft_wrap=True,
                    )

                if parent_run_id:
                    console.print(
                        f"  input: [yellow]{_short_id(parent_run_id)}[/]"
                    )

                console.print(
                    f"  dir: [dim]{run_dir.resolve()}/[/]", soft_wrap=True
                )

                cli_data = load_cli_yaml(run_dir)
                if cli_data and cli_data.get("command"):
                    cmd = cli_data["command"]
                    if not full_command:
                        cmd = _shorten_command(cmd)
                    console.print(f"  [dim italic]$ {cmd}[/]")

                console.print()  # blank line between entries
            shown += 1

        # -- Footer --------------------------------------------------------
        if not explicit_ids:
            will_show = min(pre_visible, count)
            not_shown = pre_visible - will_show
            footer_parts: list[str] = [
                f"[dim]{will_show} of {pre_visible} runs[/]",
            ]
            if not_shown > 0:
                footer_parts.append(
                    f"[dim]{not_shown} more not shown "
                    f"(use -n {pre_visible} to show all)[/]"
                )
            console.print(" · ".join(footer_parts))

        # Report any unmatched ID prefixes
        unmatched = explicit_ids - matched_ids
        for prefix in sorted(unmatched):
            console.print(
                f"[yellow]⚠[/] No run found matching ID prefix "
                f"[yellow]{prefix}[/]"
            )
