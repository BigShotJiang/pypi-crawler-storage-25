# Copyright (C) 2026 Embedl AB

"""
embedl-hub invoke — run inference on a compiled model.

The CLI hierarchy is::

    invoke <toolchain> <provider> [args …]

Toolchains
~~~~~~~~~~
* ``tflite``      — Invoke via :class:`~embedl_hub._internal.core.invoke.tflite.TFLiteInvoker`
* ``onnxruntime`` — Invoke via :class:`~embedl_hub._internal.core.invoke.onnxruntime.ONNXRuntimeInvoker`
* ``tensorrt``    — Invoke via :class:`~embedl_hub._internal.core.invoke.tensorrt.TensorRTInvoker`

Backends vary per toolchain:

======================  ======  ==========  ==================  ======
Backend                tflite  onnxruntime embedl-onnxruntime  trtexec
======================  ======  ==========  ==================  ======
``qai-hub``              ✓       ✓
``embedl-onnxruntime``                       ✓
``trtexec``                                                      ✓
======================  ======  ==========  ==================  ======
"""

from pathlib import Path

import typer

from embedl_hub._internal.core.config import get_artifact_dir
from embedl_hub.cli.commands import (
    PROJECT_NAME_OPTION,
    RUN_NAME_OPTION,
    TAGS_OPTION,
)
from embedl_hub.cli.helper import (
    DEVICE_HELPER,
    EMBEDL_ORT_CLI_ARGS_HELPER,
    EMBEDL_ORT_PATH_HELPER,
    SSH_HOST_HELPER,
    SSH_KEY_HELPER,
    SSH_PORT_HELPER,
    SSH_USER_HELPER,
    TRTEXEC_CLI_ARGS_HELPER,
    TRTEXEC_PATH_HELPER,
)
from embedl_hub.cli.resolve_run import FROM_RUN_HELP, resolve_model_input
from embedl_hub.cli.run_metadata import (
    print_run_summary,
    save_cli_yaml_for_latest_run,
)

# ===================================================================== #
# Top-level group: invoke
# ===================================================================== #

invoke_cli = typer.Typer(
    name="invoke",
    help="Run inference on a compiled model.",
    no_args_is_help=True,
)


def _print_invoke_output(output: dict | None, output_path: Path) -> None:
    """Print inference output summary."""
    # pylint: disable=import-outside-toplevel
    from embedl_hub._internal.core.hub_logging import console
    # pylint: enable=import-outside-toplevel

    num_outputs = len(output) if output else 0
    console.print(
        f"[green]✓ Inference complete — {num_outputs} output tensor(s).[/]"
    )
    for name, arr in (output or {}).items():
        console.print(f"  {name}: shape={arr.shape}, dtype={arr.dtype}")

    console.print(f"[green]✓ Saved output to:[/] {output_path}")


# ===================================================================== #
# tflite toolchain
# ===================================================================== #

_invoke_tflite_cli = typer.Typer(
    name="tflite",
    help="Invoke using TFLite toolchain.",
    no_args_is_help=True,
)
invoke_cli.add_typer(_invoke_tflite_cli)


@_invoke_tflite_cli.command("qai-hub", no_args_is_help=True)
def invoke_tflite_qai_hub(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled .tflite model file.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    input_data: Path = typer.Option(
        ...,
        "-i",
        "--input",
        help="Path to input data (.npz file mapping input names to arrays).",
        show_default=False,
    ),
    device: str = typer.Option(
        ..., "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Run inference on a TFLite model via Qualcomm AI Hub.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Invoke a .tflite model on Samsung Galaxy S25::

        $ embedl-hub invoke tflite qai-hub -m my_model.tflite -i input.npz -d "Samsung Galaxy S25"
    """

    # pylint: disable=import-outside-toplevel
    import numpy as np

    from embedl_hub._internal.core.compile.tflite import TFLiteCompiledModel
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.invoke.tflite import TFLiteInvoker
    from embedl_hub.cli.context import (
        create_qai_hub_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import assert_api_config, parse_tags
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        TFLiteCompiledModel,
    )
    if not input_data.exists():
        raise typer.BadParameter(
            f"Input data path does not exist: {input_data}"
        )

    loaded = np.load(input_data)
    inputs: dict[str, np.ndarray] = dict(loaded)

    tags_dict = parse_tags(tags)

    hub_ctx = create_qai_hub_context(
        project_name=resolved_project,
        device_name=device,
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            invoker = TFLiteInvoker(name=run_name)
            result = invoker.run(
                hub_ctx, compiled_model, inputs, device="main"
            )
            output = result.output
            output_dir = result.artifact_dir or artifact_base_dir
            output_path = output_dir / "output.npz"
            output_dir.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(output_path, **output)
        _print_invoke_output(output, output_path)
    except Exception as exc:
        console.print(f"[red]✗ inference failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


# ===================================================================== #
# onnxruntime toolchain
# ===================================================================== #

_invoke_onnxruntime_cli = typer.Typer(
    name="onnxruntime",
    help="Invoke using ONNX Runtime toolchain.",
    no_args_is_help=True,
)
invoke_cli.add_typer(_invoke_onnxruntime_cli)


@_invoke_onnxruntime_cli.command("qai-hub", no_args_is_help=True)
def invoke_onnxruntime_qai_hub(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled ONNX model file or directory.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    input_data: Path = typer.Option(
        ...,
        "-i",
        "--input",
        help="Path to input data (.npz file mapping input names to arrays).",
        show_default=False,
    ),
    device: str = typer.Option(
        ..., "-d", "--device", help=DEVICE_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Run inference on an ONNX Runtime model via Qualcomm AI Hub.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Invoke an .onnx model on Samsung Galaxy S25::

        $ embedl-hub invoke onnxruntime qai-hub -m my_model.onnx -i input.npz -d "Samsung Galaxy S25"
    """

    # pylint: disable=import-outside-toplevel
    import numpy as np

    from embedl_hub._internal.core.compile.onnxruntime import (
        ONNXRuntimeCompiledModel,
    )
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.invoke.onnxruntime import ONNXRuntimeInvoker
    from embedl_hub.cli.context import (
        create_qai_hub_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import assert_api_config, parse_tags
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        ONNXRuntimeCompiledModel,
    )
    if not input_data.exists():
        raise typer.BadParameter(
            f"Input data path does not exist: {input_data}"
        )

    loaded = np.load(input_data)
    inputs: dict[str, np.ndarray] = dict(loaded)

    tags_dict = parse_tags(tags)

    hub_ctx = create_qai_hub_context(
        project_name=resolved_project,
        device_name=device,
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            invoker = ONNXRuntimeInvoker(name=run_name)
            result = invoker.run(
                hub_ctx, compiled_model, inputs, device="main"
            )
            output = result.output
            output_dir = result.artifact_dir or artifact_base_dir
            output_path = output_dir / "output.npz"
            output_dir.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(output_path, **output)
        _print_invoke_output(output, output_path)
    except Exception as exc:
        console.print(f"[red]✗ inference failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


@_invoke_onnxruntime_cli.command("embedl-onnxruntime", no_args_is_help=True)
def invoke_onnxruntime_embedl_ort(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled ONNX model file.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    input_data: Path = typer.Option(
        ...,
        "-i",
        "--input",
        help="Path to input data (.npz file mapping input names to arrays).",
        show_default=False,
    ),
    host: str = typer.Option(
        ..., "--host", help=SSH_HOST_HELPER, show_default=False
    ),
    username: str = typer.Option(
        ..., "--user", help=SSH_USER_HELPER, show_default=False
    ),
    port: int = typer.Option(22, "--port", help=SSH_PORT_HELPER),
    key_file: Path | None = typer.Option(
        None, "--key-file", help=SSH_KEY_HELPER, show_default=False
    ),
    exec_path: str | None = typer.Option(
        None, "--exec-path", help=EMBEDL_ORT_PATH_HELPER, show_default=False
    ),
    extra_args: list[str] | None = typer.Option(
        None, "--cli-args", help=EMBEDL_ORT_CLI_ARGS_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Run inference on an ONNX Runtime model on a remote device via SSH.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Invoke model on a remote device::

        $ embedl-hub invoke onnxruntime embedl-onnxruntime -m my_model.onnx -i input.npz --host 192.168.1.10 --user pi
    """

    # pylint: disable=import-outside-toplevel
    import numpy as np

    from embedl_hub._internal.core.compile.onnxruntime import (
        ONNXRuntimeCompiledModel,
    )
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.invoke.onnxruntime import ONNXRuntimeInvoker
    from embedl_hub.cli.context import (
        create_embedl_onnxruntime_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import assert_api_config, parse_tags
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        ONNXRuntimeCompiledModel,
    )
    if not input_data.exists():
        raise typer.BadParameter(
            f"Input data path does not exist: {input_data}"
        )

    loaded = np.load(input_data)
    inputs: dict[str, np.ndarray] = dict(loaded)

    tags_dict = parse_tags(tags)

    hub_ctx = create_embedl_onnxruntime_context(
        project_name=resolved_project,
        host=host,
        username=username,
        port=port,
        private_key_path=key_file,
        exec_path=exec_path,
        cli_args=tuple(extra_args) if extra_args else (),
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            invoker = ONNXRuntimeInvoker(name=run_name)
            result = invoker.run(
                hub_ctx, compiled_model, inputs, device="main"
            )
            output = result.output
            output_dir = result.artifact_dir or artifact_base_dir
            output_path = output_dir / "output.npz"
            output_dir.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(output_path, **output)
        _print_invoke_output(output, output_path)
    except Exception as exc:
        console.print(f"[red]✗ inference failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)


# ===================================================================== #
# tensorrt toolchain
# ===================================================================== #

_invoke_tensorrt_cli = typer.Typer(
    name="tensorrt",
    help="Invoke using TensorRT toolchain.",
    no_args_is_help=True,
)
invoke_cli.add_typer(_invoke_tensorrt_cli)


@_invoke_tensorrt_cli.command("trtexec", no_args_is_help=True)
def invoke_tensorrt_trtexec(
    ctx: typer.Context,
    model: Path | None = typer.Option(
        None,
        "-m",
        "--model",
        help="Path to a compiled TensorRT engine file.",
        show_default=False,
    ),
    from_run: str | None = typer.Option(
        None,
        "--from-run",
        help=FROM_RUN_HELP,
        show_default=False,
    ),
    input_data: Path = typer.Option(
        ...,
        "-i",
        "--input",
        help="Path to input data (.npz file mapping input names to arrays).",
        show_default=False,
    ),
    host: str = typer.Option(
        ..., "--host", help=SSH_HOST_HELPER, show_default=False
    ),
    username: str = typer.Option(
        ..., "--user", help=SSH_USER_HELPER, show_default=False
    ),
    port: int = typer.Option(22, "--port", help=SSH_PORT_HELPER),
    key_file: Path | None = typer.Option(
        None, "--key-file", help=SSH_KEY_HELPER, show_default=False
    ),
    exec_path: str | None = typer.Option(
        None, "--exec-path", help=TRTEXEC_PATH_HELPER, show_default=False
    ),
    extra_args: list[str] | None = typer.Option(
        None, "--cli-args", help=TRTEXEC_CLI_ARGS_HELPER, show_default=False
    ),
    project_name: str | None = PROJECT_NAME_OPTION,
    run_name: str | None = RUN_NAME_OPTION,
    tags: list[str] | None = TAGS_OPTION,
):
    """Run inference on a TensorRT model on a remote NVIDIA device via SSH.

    Artifacts are written to the directory configured by
    ``embedl-hub init --artifact-dir``.

    Examples
    --------

    Invoke a TensorRT engine on a remote NVIDIA device::

        $ embedl-hub invoke tensorrt trtexec -m my_model.engine -i input.npz --host 192.168.1.10 --user nvidia
    """

    # pylint: disable=import-outside-toplevel
    import numpy as np

    from embedl_hub._internal.core.compile.tensorrt import (
        TensorRTCompiledModel,
    )
    from embedl_hub._internal.core.hub_logging import console
    from embedl_hub._internal.core.invoke.tensorrt import TensorRTInvoker
    from embedl_hub.cli.context import (
        create_trtexec_context,
        require_initialized_ctx,
    )
    from embedl_hub.cli.utils import assert_api_config, parse_tags
    # pylint: enable=import-outside-toplevel

    assert_api_config()
    require_initialized_ctx(ctx.obj["config"])

    config = ctx.obj["config"]
    artifact_base_dir = get_artifact_dir(config)
    resolved_project = project_name or config["project_name"]
    project_dir = artifact_base_dir / resolved_project

    compiled_model = resolve_model_input(
        model,
        from_run,
        project_dir,
        TensorRTCompiledModel,
    )
    if not input_data.exists():
        raise typer.BadParameter(
            f"Input data path does not exist: {input_data}"
        )

    loaded = np.load(input_data)
    inputs: dict[str, np.ndarray] = dict(loaded)

    tags_dict = parse_tags(tags)

    hub_ctx = create_trtexec_context(
        project_name=resolved_project,
        host=host,
        username=username,
        port=port,
        private_key_path=key_file,
        exec_path=exec_path,
        cli_args=tuple(extra_args) if extra_args else (),
        artifact_dir=artifact_base_dir,
        tags=tags_dict,
    )

    try:
        with hub_ctx:
            invoker = TensorRTInvoker(name=run_name)
            result = invoker.run(
                hub_ctx, compiled_model, inputs, device="main"
            )
            output = result.output
            output_dir = result.artifact_dir or artifact_base_dir
            output_path = output_dir / "output.npz"
            output_dir.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(output_path, **output)
        _print_invoke_output(output, output_path)
    except Exception as exc:
        console.print(f"[red]✗ inference failed:[/] {exc}")
        raise typer.Exit(1)
    finally:
        save_cli_yaml_for_latest_run(project_dir)
        print_run_summary(project_dir)
