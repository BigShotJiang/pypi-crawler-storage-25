# Copyright (C) 2026 Embedl AB

"""Profiler components and result types.

Re-exports
----------
- :exc:`ProfileError` — Raised on profiling failure.
- :class:`ProfilingMethod` — Enum of profiling methods.
- :class:`ONNXRuntimeProfiler` — ONNX Runtime profiler component.
- :class:`ONNXRuntimeProfilingResult` — Output of ONNX Runtime profiling.
- :class:`TensorRTProfiler` — TensorRT profiler component.
- :class:`TensorRTProfilingResult` — Output of TensorRT profiling.
- :class:`TFLiteProfiler` — TFLite profiler component.
- :class:`TFLiteProfilingResult` — Output of TFLite profiling.
"""

from embedl_hub._internal.core.profile.onnxruntime import (
    ONNXRuntimeProfiler,
    ONNXRuntimeProfilingResult,
)
from embedl_hub._internal.core.profile.result import (
    ProfileError,
    ProfilingMethod,
)
from embedl_hub._internal.core.profile.tensorrt import (
    TensorRTProfiler,
    TensorRTProfilingResult,
)
from embedl_hub._internal.core.profile.tflite import (
    TFLiteProfiler,
    TFLiteProfilingResult,
)

__all__ = [
    "ONNXRuntimeProfiler",
    "ONNXRuntimeProfilingResult",
    "ProfileError",
    "ProfilingMethod",
    "TFLiteProfiler",
    "TFLiteProfilingResult",
    "TensorRTProfiler",
    "TensorRTProfilingResult",
]
