# Copyright (C) 2026 Embedl AB

"""Component base classes, outputs, and provider types.

Re-exports
----------
- :class:`Component` — Abstract base class for all components.
- :class:`CompiledModel` — Output type for compilation components.
- :class:`ComponentOutput` — Base output type for all components.
- :exc:`MissingOutputError` — Raised on missing output fields.
- :exc:`NoProviderError` — Raised when no provider is registered.
- :class:`ProviderType` — Enum of built-in provider identifiers.
- :class:`RunType` — Enum of run types for tracking.
"""

from embedl_hub._internal.core.component.abc import Component, NoProviderError
from embedl_hub._internal.core.component.output import (
    CompiledModel,
    ComponentOutput,
    MissingOutputError,
)
from embedl_hub._internal.core.component.provider_type import ProviderType
from embedl_hub._internal.tracking.rest_api import RunType

__all__ = [
    "CompiledModel",
    "Component",
    "ComponentOutput",
    "MissingOutputError",
    "NoProviderError",
    "ProviderType",
    "RunType",
]
