# Copyright (C) 2025, 2026 Embedl AB

"""Compiler components and result types.

Re-exports
----------
- :exc:`CompileError` — Raised on compilation failure.
- :class:`CompileResult` — Container for compilation results.
- :class:`ONNXRuntimeCompiler` — ONNX Runtime compiler component.
- :class:`ONNXRuntimeCompiledModel` — Output of ONNX Runtime compilation.
- :class:`TensorRTCompiler` — TensorRT compiler component.
- :class:`TensorRTCompiledModel` — Output of TensorRT compilation.
- :class:`TFLiteCompiler` — TFLite compiler component.
- :class:`TFLiteCompiledModel` — Output of TFLite compilation.
"""

from embedl_hub._internal.core.compile.onnxruntime import (
    ONNXRuntimeCompiledModel,
    ONNXRuntimeCompiler,
)
from embedl_hub._internal.core.compile.result import (
    CompileError,
    CompileResult,
)
from embedl_hub._internal.core.compile.tensorrt import (
    TensorRTCompiledModel,
    TensorRTCompiler,
)
from embedl_hub._internal.core.compile.tflite import (
    TFLiteCompiledModel,
    TFLiteCompiler,
)

__all__ = [
    "CompileError",
    "CompileResult",
    "ONNXRuntimeCompiledModel",
    "ONNXRuntimeCompiler",
    "TFLiteCompiledModel",
    "TFLiteCompiler",
    "TensorRTCompiledModel",
    "TensorRTCompiler",
]
