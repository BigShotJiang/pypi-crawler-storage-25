# Copyright (C) 2026 Embedl AB

"""Invocation components and result types.

Re-exports
----------
- :exc:`InvokeError` — Raised when an invocation job fails.
- :class:`ONNXRuntimeInvoker` — ONNX Runtime invoker component.
- :class:`ONNXRuntimeInvocationResult` — Output of ONNX Runtime invocation.
- :class:`TensorRTInvoker` — TensorRT invoker component.
- :class:`TensorRTInvocationResult` — Output of TensorRT invocation.
- :class:`TFLiteInvoker` — TFLite invoker component.
- :class:`TFLiteInvocationResult` — Output of TFLite invocation.
"""

from embedl_hub._internal.core.invoke import InvokeError
from embedl_hub._internal.core.invoke.onnxruntime import (
    ONNXRuntimeInvocationResult,
    ONNXRuntimeInvoker,
)
from embedl_hub._internal.core.invoke.tensorrt import (
    TensorRTInvocationResult,
    TensorRTInvoker,
)
from embedl_hub._internal.core.invoke.tflite import (
    TFLiteInvocationResult,
    TFLiteInvoker,
)

__all__ = [
    "InvokeError",
    "ONNXRuntimeInvocationResult",
    "ONNXRuntimeInvoker",
    "TFLiteInvocationResult",
    "TFLiteInvoker",
    "TensorRTInvocationResult",
    "TensorRTInvoker",
]
