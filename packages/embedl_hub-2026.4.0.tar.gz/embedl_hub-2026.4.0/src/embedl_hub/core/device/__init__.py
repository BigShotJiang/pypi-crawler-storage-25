# Copyright (C) 2026 Embedl AB

"""Device abstraction, management, and configuration.

Re-exports
----------
- :class:`CommandResult` — Protocol for command execution results.
- :class:`CommandRunner` — Protocol for running commands on a device.
- :class:`Device` — Concrete device representation.
- :class:`DeviceManager` — Factory for creating device instances.
- :class:`DeviceSpec` — Hardware specification for a device.
- :class:`SSHConfig` — SSH connection configuration.
- :class:`SSHCommandRunner` — SSH-based command runner.
- :exc:`SSHConnectionError` — Raised on SSH connection failure.
- :class:`ProviderConfig` — Base class for provider configurations.
- :class:`EmbedlONNXRuntimeConfig` — Config for the Embedl ONNX Runtime
  provider.
- :class:`TrtexecConfig` — Config for the TensorRT (trtexec) provider.
"""

from embedl_hub._internal.core.device.abc import (
    CommandResult,
    CommandRunner,
    Device,
)
from embedl_hub._internal.core.device.config.abc import ProviderConfig
from embedl_hub._internal.core.device.config.embedl_onnxruntime import (
    EmbedlONNXRuntimeConfig,
)
from embedl_hub._internal.core.device.config.trtexec import TrtexecConfig
from embedl_hub._internal.core.device.manager import DeviceManager
from embedl_hub._internal.core.device.spec import DeviceSpec
from embedl_hub._internal.core.device.ssh import (
    SSHCommandRunner,
    SSHConfig,
    SSHConnectionError,
)

__all__ = [
    "CommandResult",
    "CommandRunner",
    "Device",
    "DeviceManager",
    "DeviceSpec",
    "EmbedlONNXRuntimeConfig",
    "ProviderConfig",
    "SSHCommandRunner",
    "SSHConfig",
    "SSHConnectionError",
    "TrtexecConfig",
]
