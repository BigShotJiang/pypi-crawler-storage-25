# Copyright (C) 2025, 2026 Embedl AB

"""Public API for the Embedl Hub core package.

Subpackages
-----------
- :mod:`embedl_hub.core.compile` — Compiler components and results.
- :mod:`embedl_hub.core.component` — Component base classes and outputs.
- :mod:`embedl_hub.core.device` — Device abstraction and management.
- :mod:`embedl_hub.core.invoke` — Invocation components.
- :mod:`embedl_hub.core.profile` — Profiler components and results.

Top-level re-exports
--------------------
- :class:`HubContext` — Execution context for component runs.
- :data:`LocalPath`, :data:`RemotePath` — Path type aliases.
"""

from embedl_hub._internal.core.context import HubContext
from embedl_hub._internal.core.types import LocalPath, RemotePath

__all__ = [
    "HubContext",
    "LocalPath",
    "RemotePath",
]
