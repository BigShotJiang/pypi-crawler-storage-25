# Copyright (C) 2026 Embedl AB

import pytest

from embedl_hub._internal.tracking.errors import (
    InvalidRunLineageError,
    raise_if_run_error,
)
from embedl_hub._internal.tracking.rest_api import (
    ApiError,
    ApiErrorDetail,
    ErrorCode,
)


def test_raise_if_run_error_raises_invalid_run_lineage_error_from_code():
    with pytest.raises(
        InvalidRunLineageError, match="Compile runs cannot have a parent run"
    ):
        raise_if_run_error(
            ApiError(
                400,
                "Bad Request",
                errors=[
                    ApiErrorDetail(
                        code=ErrorCode.INVALID_RUN_LINEAGE.value,
                        detail="Compile runs cannot have a parent run",
                    )
                ],
            )
        )


def test_raise_if_run_error_raises_invalid_run_lineage_error_from_message():
    with pytest.raises(
        InvalidRunLineageError,
        match="Only compile runs can be selected as parent runs",
    ):
        raise_if_run_error(
            ApiError(
                400,
                "Bad Request",
                errors=[
                    ApiErrorDetail(
                        title="Only compile runs can be selected as parent runs",
                    )
                ],
            )
        )
