from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field, StrictFloat, StrictInt, StrictStr, StrictBool
from typing import Any, ClassVar, Dict, List, Optional, Union
from typing import Optional, Set, Any, Dict, List
from typing_extensions import Self

from dataforseo_client.models.llm_message_chain_item import LlmMessageChainItem



class AiOptimizationClaudeLlmResponsesLiveRequestInfo(BaseModel):
    """
    AiOptimizationClaudeLlmResponsesLiveRequestInfo
    """ # noqa: E501
    user_prompt: Optional[StrictStr] = Field(default=None, description=r"prompt for the AI modelrequired fieldthe question or task you want to send to the AI model;you can specify up to 500 characters in the user_prompt field")
    model_name: Optional[StrictStr] = Field(default=None, description=r"name of the AI modelrequired fieldmodel_nameconsists of the actual model name and version name;if the basic model name is specified, its latest version will be set by default;for example, if claude-opus-4-0 is specified, the claude-opus-4-20250514 will be set as model_name automatically;you can receive the list of available LLM models by making a separate request to the https://api.dataforseo.com/v3/ai_optimization/claude/llm_responses/models")
    max_output_tokens: Optional[StrictInt] = Field(default=None, description=r"maximum number of tokens in the AI responseoptional fieldminimum value: 1;maximum value: 4096;default value: 2048;Note: if web_search is set to true or the reasoning model is specified in the request, the output token count may exceed the specified max_output_tokens limitNote #2: if use_reasoning is set to true, the minimum value for max_output_tokens is 1025")
    temperature: Optional[StrictFloat] = Field(default=None, description=r"randomness of the AI responseoptional fieldhigher values make output more diverse; lower values make output more focused;minimum value: 0maximum value: 1default value: 0.7Note: temperature cannot be used together with top_p in the same request")
    top_p: Optional[StrictFloat] = Field(default=None, description=r"diversity of the AI responseoptional field controls diversity of the response by limiting token selection;minimum value: 0maximum value: 1 default value: nullNote: top_p cannot be used together with temperature in the same request")
    web_search: Optional[StrictBool] = Field(default=None, description=r"enable web search for current informationoptional fieldwhen enabled, the AI model can access and cite current web information;Note: refer to the Models endpoint for a list of models that support web_search; default value: false;The cost of the parameter can be calculated on the Pricing page")
    force_web_search: Optional[StrictBool] = Field(default=None, description=r"force AI agent to use web searchoptional fieldto enable this parameter, web_search must also be enabled;when enabled, the AI model is forced to access and cite current web information;default value: false;Note: even if the parameter is set to true, there is no guarantee web sources will be cited in the response")
    web_search_country_iso_code: Optional[StrictStr] = Field(default=None, description=r"ISO country code of the locationoptional fieldpossible values: 'AR','AT','AU','BE','BR','CA','CH','CL','CN','DE','DK','ES','FI','FR','GB','HK','ID','IN','IT','JP','KR','MX','MY','NL','NO','NZ','PH','PL','PT','RU','SA','SE','TR','TW','US','ZA'")
    web_search_city: Optional[StrictStr] = Field(default=None, description=r"city name of the locationoptional fieldNote: specify web_search_country_iso_code to use this parameter")
    system_message: Optional[StrictStr] = Field(default=None, description=r"instructions for the AI behaviouroptional fielddefines the AI's role, tone, or specific behavior;you can specify up to 500 characters in the system_message field")
    message_chain: Optional[List[Optional[LlmMessageChainItem]]] = Field(default=None, description=r"conversation history. optional field. array of message objects representing previous conversation turns;. each object must contain:. role string with either user or ai role;. message string with message content (max 500 characters);. you can specify maximum of 10 message objects in the array;. Note: for Perplexity models, messages must strictly alternate between user and AI roles (user → ai);. example:. 'message_chain': [{'role':'user','message':'Hello, what’s up?'},{'role':'ai','message':'Hello! I’m doing well, thank you. How can I assist you today?'}]")
    use_reasoning: Optional[StrictBool] = Field(default=None, description=r"enable reasoning for the AI modeloptional fieldwhen enabled, the model will perform reasoning before generating a responserefer to the Models endpoint for a list of models that support reasoningdefault value: falseNote: if set to true, the minimum value for max_output_tokens is 1025Note #2: if set to true, force_web_search must be set to falseNote #3: if set to true, the temperature and top_p cannot be used")
    tag: Optional[StrictStr] = Field(default=None, description=r"user-defined task identifieroptional fieldthe character limit is 255you can use this parameter to identify the task and match it with the resultyou will find the specified tag value in the data object of the response")
    __properties: ClassVar[List[str]] = [
        "user_prompt", 
        "model_name", 
        "max_output_tokens", 
        "temperature", 
        "top_p", 
        "web_search", 
        "force_web_search", 
        "web_search_country_iso_code", 
        "web_search_city", 
        "system_message", 
        "message_chain", 
        "use_reasoning", 
        "tag", 
        ]

    additional_properties: Dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )

    def to_str(self) -> str:
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        excluded_fields: Set[str] = set([
        ])

        _dict = {}

        _dict['user_prompt'] = self.user_prompt
        _dict['model_name'] = self.model_name
        _dict['max_output_tokens'] = self.max_output_tokens
        _dict['temperature'] = self.temperature
        _dict['top_p'] = self.top_p
        _dict['web_search'] = self.web_search
        _dict['force_web_search'] = self.force_web_search
        _dict['web_search_country_iso_code'] = self.web_search_country_iso_code
        _dict['web_search_city'] = self.web_search_city
        _dict['system_message'] = self.system_message
        message_chain_items = []
        if self.message_chain:
            for _item in self.message_chain:
                if _item:
                    message_chain_items.append(_item.to_dict())
            _dict['message_chain'] = message_chain_items
        _dict['use_reasoning'] = self.use_reasoning
        _dict['tag'] = self.tag
        return _dict


    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "user_prompt": obj.get("user_prompt"),
            "model_name": obj.get("model_name"),
            "max_output_tokens": obj.get("max_output_tokens"),
            "temperature": obj.get("temperature"),
            "top_p": obj.get("top_p"),
            "web_search": obj.get("web_search"),
            "force_web_search": obj.get("force_web_search"),
            "web_search_country_iso_code": obj.get("web_search_country_iso_code"),
            "web_search_city": obj.get("web_search_city"),
            "system_message": obj.get("system_message"),
            "message_chain": [LlmMessageChainItem.from_dict(_item) for _item in obj["message_chain"]] if obj.get("message_chain") is not None else None,
            "use_reasoning": obj.get("use_reasoning"),
            "tag": obj.get("tag"),
        })

        additional_properties = {k: v for k, v in obj.items() if k not in cls.__properties}
        _obj.additional_properties = additional_properties
        return _obj