# 🔐 QuickTOTP

> Simple, fast, and powerful TOTP generator for your terminal.

QuickTOTP is a lightweight CLI tool to generate Time-Based One-Time Passwords (TOTP) directly from your terminal — no mobile app required.

---

## ✨ Features

- 🔑 Generate TOTP codes instantly
- 📦 Store multiple accounts
- ⚡ Live auto-refresh mode
- 🖥 Simple CLI interface
- 💾 Local storage (no internet required)

---

## 📦 Installation

```bash
pip install quicktotp
```
🚀 Usage

➕ Add account
```bash
quicktotp add github JBSWY3DPEHPK3PXP
```
📋 List accounts
```bash
quicktotp list
```
🔢 Generate code
```bash
quicktotp code github
```
⚡ Live mode (auto refresh)
```bash
quicktotp live github
```
❌ Delete account
```bash
quicktotp delete github
```
📂 Storage

All secrets are stored locally in:

~/.quicktotp.json

⚠️ Security Notice

Secrets are stored in plain text.

For better security, encryption will be added in future versions.

🛠 Requirements
Python 3.7+
pyotp
📜 License

MIT License © 2026 Eden