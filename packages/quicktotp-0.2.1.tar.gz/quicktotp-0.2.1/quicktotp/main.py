import pyotp
import json
import os
import sys
import time
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.panel import Panel

console = Console()

DATA_FILE = os.path.join(os.path.expanduser("~"), ".quicktotp.json")


# =====================
# UTIL
# =====================
def load_data():
    if not os.path.exists(DATA_FILE):
        return {}
    with open(DATA_FILE, "r") as f:
        return json.load(f)


def save_data(data):
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=4)


# =====================
# COMMANDS
# =====================
def add_account(name, secret):
    data = load_data()
    data[name] = secret
    save_data(data)
    console.print(f"[green][+] Account '{name}' added successfully![/green]")


def list_accounts():
    data = load_data()
    
    if not data:
        console.print("[red]No accounts found.[/red]")
        return

    table = Table(title="📦 Saved Accounts")
    table.add_column("Name", style="cyan")

    for name in data:
        table.add_row(name)

    console.print(table)


def generate_code(name):
    data = load_data()
    
    if name not in data:
        console.print("[red]Account not found.[/red]")
        return
    
    secret = data[name]
    totp = pyotp.TOTP(secret)
    
    code = totp.now()
    remaining = 30 - int(time.time()) % 30

    console.print(Panel.fit(
        f"[bold green]{code}[/bold green]\n[cyan]Expires in: {remaining}s[/cyan]",
        title=f"🔐 {name}",
    ))


def delete_account(name):
    data = load_data()
    
    if name not in data:
        console.print("[red]Account not found.[/red]")
        return
    
    del data[name]
    save_data(data)
    console.print(f"[yellow][-] Account '{name}' deleted.[/yellow]")


def live_code(name):
    data = load_data()

    if name not in data:
        console.print("[red]Account not found.[/red]")
        return

    secret = data[name]
    totp = pyotp.TOTP(secret)

    def render():
        code = totp.now()
        remaining = 30 - int(time.time()) % 30

        return Panel.fit(
            f"[bold green]{code}[/bold green]\n\n"
            f"[cyan]Expires in: {remaining}s[/cyan]",
            title=f"⚡ LIVE: {name}",
            border_style="green"
        )

    try:
        with Live(render(), refresh_per_second=4) as live:
            while True:
                time.sleep(1)
                live.update(render())

    except KeyboardInterrupt:
        console.print("\n[yellow]Exited live mode.[/yellow]")


# =====================
# CLI HANDLER
# =====================
def main():
    print("DEBUG: CLI RUNNING") 
    if len(sys.argv) < 2:
        print("""
QuickTOTP CLI

Commands:
  add <name> <secret>     Add new account
  list                    Show all accounts
  code <name>             Generate TOTP code
  live <name>             Live auto-refresh mode
  delete <name>           Delete account
""")
        return

    command = sys.argv[1]

    if command == "add" and len(sys.argv) == 4:
        add_account(sys.argv[2], sys.argv[3])

    elif command == "list":
        list_accounts()

    elif command == "code" and len(sys.argv) == 3:
        generate_code(sys.argv[2])

    elif command == "live" and len(sys.argv) == 3:
        live_code(sys.argv[2])

    elif command == "delete" and len(sys.argv) == 3:
        delete_account(sys.argv[2])

    else:
        print("Invalid command.")


if __name__ == "__main__":
    main()