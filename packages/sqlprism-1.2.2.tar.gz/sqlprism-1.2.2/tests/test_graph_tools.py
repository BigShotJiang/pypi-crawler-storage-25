"""Tests for DuckPGQ graph tools (find_path, find_critical_models, etc.)."""

import pytest

from sqlprism.core.graph import GraphDB


def _build_chain_graph():
    """Create a linear chain: raw.orders -> staging.orders -> int_payments -> marts.revenue.
    Plus an isolated model: model_isolated (no edges).
    """
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    file_id = db.insert_file(repo_id, "pipeline.sql", "sql", "abc123")

    raw = db.insert_node(file_id, "table", "raw.orders", "sql")
    stg = db.insert_node(file_id, "table", "staging.orders", "sql")
    intp = db.insert_node(file_id, "table", "int_payments", "sql")
    mart = db.insert_node(file_id, "table", "marts.revenue", "sql")
    db.insert_node(file_id, "table", "model_isolated", "sql")

    db.insert_edge(raw, stg, "references")
    db.insert_edge(stg, intp, "references")
    db.insert_edge(intp, mart, "references")

    db.refresh_property_graph()
    return db


# ── find_path tests ──


def test_find_path_shortest():
    """Shortest path through full chain returns all intermediate nodes."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_path("raw.orders", "marts.revenue")
    assert result["path_found"] is True
    assert result["length"] == 3
    assert result["path"] == ["raw.orders", "staging.orders", "int_payments", "marts.revenue"]
    db.close()


def test_find_path_no_path():
    """No path between disconnected models."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_path("raw.orders", "model_isolated")
    assert result["path_found"] is False
    assert result["path"] == []
    assert result["length"] == 0
    db.close()


def test_find_path_direct():
    """Direct dependency returns 2-element path with length 1."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_path("raw.orders", "staging.orders")
    assert result["path_found"] is True
    assert result["length"] == 1
    assert result["path"] == ["raw.orders", "staging.orders"]
    db.close()


def test_find_path_no_pgq():
    """Returns error dict when DuckPGQ is not installed."""
    db = GraphDB()
    db._has_pgq = False
    result = db.query_find_path("a", "b")
    assert result.keys() == {"error"}
    assert "DuckPGQ" in result["error"]
    db.close()


def test_find_path_reverse_direction():
    """No path in reverse direction (edges are directed)."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_path("marts.revenue", "raw.orders")
    assert result["path_found"] is False
    db.close()


def test_find_path_nonexistent_node():
    """Nonexistent model returns path_found=False."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_path("does_not_exist", "raw.orders")
    assert result["path_found"] is False
    assert result["path"] == []
    db.close()


def test_find_path_max_hops_too_short():
    """max_hops shorter than actual path returns no path."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    # Chain is 3 hops, but max_hops=2
    result = db.query_find_path("raw.orders", "marts.revenue", max_hops=2)
    assert result["path_found"] is False
    db.close()


def test_find_path_self():
    """Self-path returns path_found=False (min 1 hop required)."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_path("raw.orders", "raw.orders")
    assert result["path_found"] is False
    db.close()


# ── find_critical_models tests ──


def test_find_critical_models_pagerank():
    """PageRank returns ranked models with expected fields and values."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_critical_models(top_n=5)
    assert "models" in result
    assert result["total_indexed_nodes"] == 5
    models = result["models"]
    assert len(models) == 5
    for m in models:
        assert "name" in m
        assert "kind" in m
        assert isinstance(m["importance"], float)
        assert isinstance(m["direct_dependents"], int)
    # Sorted by importance descending
    importances = [m["importance"] for m in models]
    assert importances == sorted(importances, reverse=True)
    # Verify concrete direct_dependents for known topology
    by_name = {m["name"]: m for m in models}
    # model_isolated has no dependents
    assert by_name["model_isolated"]["direct_dependents"] == 0
    # Chain: raw.orders -> staging.orders -> int_payments -> marts.revenue
    # direct_dependents = models whose edges point TO this node (source_id -> target_id)
    # raw.orders is root source — nothing points to it
    assert by_name["raw.orders"]["direct_dependents"] == 0
    # staging.orders is target of raw.orders
    assert by_name["staging.orders"]["direct_dependents"] == 1
    # int_payments is target of staging.orders
    assert by_name["int_payments"]["direct_dependents"] == 1
    # marts.revenue is target of int_payments
    assert by_name["marts.revenue"]["direct_dependents"] == 1
    db.close()


def test_find_critical_models_default_top_n():
    """Default top_n returns all models when fewer than 20 exist."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_critical_models()
    assert "models" in result
    assert len(result["models"]) == 5
    db.close()


def test_find_critical_models_top_n_truncation():
    """top_n=2 returns exactly 2 models."""
    db = _build_chain_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    result = db.query_find_critical_models(top_n=2)
    assert len(result["models"]) == 2
    db.close()


def test_find_critical_models_repo_filter():
    """Repo filter returns only models from the specified repo."""
    db = GraphDB()
    repo_a = db.upsert_repo("repo_a", "/tmp/repo_a", repo_type="sql")
    repo_b = db.upsert_repo("repo_b", "/tmp/repo_b", repo_type="sql")
    file_a = db.insert_file(repo_a, "a.sql", "sql", "aaa")
    file_b = db.insert_file(repo_b, "b.sql", "sql", "bbb")

    n_a1 = db.insert_node(file_a, "table", "model_a1", "sql")
    n_a2 = db.insert_node(file_a, "table", "model_a2", "sql")
    n_b1 = db.insert_node(file_b, "table", "model_b1", "sql")

    db.insert_edge(n_a1, n_a2, "references")
    db.insert_edge(n_b1, n_a2, "references")  # cross-repo edge

    db.refresh_property_graph()

    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")

    result = db.query_find_critical_models(repo="repo_a")
    names = {m["name"] for m in result["models"]}
    assert names == {"model_a1", "model_a2"}
    assert result["total_indexed_nodes"] == 2
    # model_a2 is referenced by both n_a1 and n_b1 (cross-repo)
    by_name = {m["name"]: m for m in result["models"]}
    assert by_name["model_a2"]["direct_dependents"] == 2
    assert by_name["model_a1"]["direct_dependents"] == 0
    db.close()


def test_find_critical_models_no_pgq():
    """Returns error dict when DuckPGQ is not installed."""
    db = GraphDB()
    db._has_pgq = False
    result = db.query_find_critical_models()
    assert result.keys() == {"error"}
    assert "DuckPGQ" in result["error"]
    db.close()


# ── detect_cycles tests ──


def test_detect_cycles_dag():
    """DAG with no cycles returns has_cycles=False."""
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    file_id = db.insert_file(repo_id, "dag.sql", "sql", "abc")

    a = db.insert_node(file_id, "table", "a", "sql")
    b = db.insert_node(file_id, "table", "b", "sql")
    c = db.insert_node(file_id, "table", "c", "sql")
    d = db.insert_node(file_id, "table", "d", "sql")

    db.insert_edge(a, b, "references")
    db.insert_edge(b, c, "references")
    db.insert_edge(c, d, "references")

    result = db.query_detect_cycles()
    assert result["has_cycles"] is False
    assert result["cycles"] == []
    assert result["total_nodes_in_scope"] == 4
    db.close()


def test_detect_cycles_simple():
    """Simple cycle a->b->c->a is detected."""
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    file_id = db.insert_file(repo_id, "cycle.sql", "sql", "abc")

    a = db.insert_node(file_id, "table", "a", "sql")
    b = db.insert_node(file_id, "table", "b", "sql")
    c = db.insert_node(file_id, "table", "c", "sql")

    db.insert_edge(a, b, "references")
    db.insert_edge(b, c, "references")
    db.insert_edge(c, a, "references")

    result = db.query_detect_cycles()
    assert result["has_cycles"] is True
    assert result["total_nodes_in_scope"] == 3
    assert len(result["cycles"]) == 1
    cycle = result["cycles"][0]
    assert cycle["length"] == 3
    assert len(cycle["path"]) == 4
    assert cycle["path"][0] == cycle["path"][-1]
    assert set(cycle["path"][:3]) == {"a", "b", "c"}
    db.close()


def test_detect_cycles_multiple():
    """Two independent cycles are both detected with correct content."""
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    file_id = db.insert_file(repo_id, "multi.sql", "sql", "abc")

    a = db.insert_node(file_id, "table", "a", "sql")
    b = db.insert_node(file_id, "table", "b", "sql")
    c = db.insert_node(file_id, "table", "c", "sql")
    d = db.insert_node(file_id, "table", "d", "sql")
    e = db.insert_node(file_id, "table", "e", "sql")

    # Cycle 1: a -> b -> a (length 2)
    db.insert_edge(a, b, "references")
    db.insert_edge(b, a, "references")

    # Cycle 2: c -> d -> e -> c (length 3)
    db.insert_edge(c, d, "references")
    db.insert_edge(d, e, "references")
    db.insert_edge(e, c, "references")

    result = db.query_detect_cycles()
    assert result["has_cycles"] is True
    assert len(result["cycles"]) == 2
    # Verify cycle lengths and node sets
    lengths = {cy["length"] for cy in result["cycles"]}
    assert lengths == {2, 3}
    node_sets = {frozenset(cy["path"][:-1]) for cy in result["cycles"]}
    assert node_sets == {frozenset({"a", "b"}), frozenset({"c", "d", "e"})}
    db.close()


def test_detect_cycles_repo_filter():
    """Repo filter isolates cycles to the specified repo."""
    db = GraphDB()
    repo_a = db.upsert_repo("repo_a", "/tmp/repo_a", repo_type="sql")
    repo_b = db.upsert_repo("repo_b", "/tmp/repo_b", repo_type="sql")
    file_a = db.insert_file(repo_a, "a.sql", "sql", "aaa")
    file_b = db.insert_file(repo_b, "b.sql", "sql", "bbb")

    # DAG in repo_a
    a1 = db.insert_node(file_a, "table", "a1", "sql")
    a2 = db.insert_node(file_a, "table", "a2", "sql")
    db.insert_edge(a1, a2, "references")

    # Cycle in repo_b
    b1 = db.insert_node(file_b, "table", "b1", "sql")
    b2 = db.insert_node(file_b, "table", "b2", "sql")
    db.insert_edge(b1, b2, "references")
    db.insert_edge(b2, b1, "references")

    result_a = db.query_detect_cycles(repo="repo_a")
    assert result_a["has_cycles"] is False
    assert result_a["total_nodes_in_scope"] == 2

    result_b = db.query_detect_cycles(repo="repo_b")
    assert result_b["has_cycles"] is True
    assert len(result_b["cycles"]) == 1
    assert set(result_b["cycles"][0]["path"][:-1]) == {"b1", "b2"}
    db.close()


def test_detect_cycles_cross_repo_no_leak():
    """Cross-repo edges don't produce false-positive cycles in filtered results."""
    db = GraphDB()
    repo_a = db.upsert_repo("repo_a", "/tmp/repo_a", repo_type="sql")
    repo_b = db.upsert_repo("repo_b", "/tmp/repo_b", repo_type="sql")
    file_a = db.insert_file(repo_a, "a.sql", "sql", "aaa")
    file_b = db.insert_file(repo_b, "b.sql", "sql", "bbb")

    # Cross-repo "cycle": a1 (repo_a) -> b1 (repo_b) -> a1 (repo_a)
    a1 = db.insert_node(file_a, "table", "a1", "sql")
    b1 = db.insert_node(file_b, "table", "b1", "sql")
    db.insert_edge(a1, b1, "references")
    db.insert_edge(b1, a1, "references")

    # Neither repo should see a cycle when filtered
    assert db.query_detect_cycles(repo="repo_a")["has_cycles"] is False
    assert db.query_detect_cycles(repo="repo_b")["has_cycles"] is False
    # But unfiltered should see it
    assert db.query_detect_cycles()["has_cycles"] is True
    db.close()


def test_detect_cycles_max_length_boundary():
    """Cycle longer than max_cycle_length is not detected."""
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    file_id = db.insert_file(repo_id, "long.sql", "sql", "abc")

    # Build a cycle of length 4: a -> b -> c -> d -> a
    nodes = []
    for name in ["a", "b", "c", "d"]:
        nodes.append(db.insert_node(file_id, "table", name, "sql"))
    for i in range(len(nodes)):
        db.insert_edge(nodes[i], nodes[(i + 1) % len(nodes)], "references")

    # max_cycle_length=3 should miss the length-4 cycle
    result_short = db.query_detect_cycles(max_cycle_length=3)
    assert result_short["has_cycles"] is False

    # max_cycle_length=4 should find it
    result_long = db.query_detect_cycles(max_cycle_length=4)
    assert result_long["has_cycles"] is True
    assert result_long["cycles"][0]["length"] == 4
    db.close()


def test_detect_cycles_no_pgq_not_required():
    """Cycle detection works without DuckPGQ (CTE-only approach)."""
    db = GraphDB()
    db._has_pgq = False
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    file_id = db.insert_file(repo_id, "cycle.sql", "sql", "abc")

    a = db.insert_node(file_id, "table", "a", "sql")
    b = db.insert_node(file_id, "table", "b", "sql")
    db.insert_edge(a, b, "references")
    db.insert_edge(b, a, "references")

    result = db.query_detect_cycles()
    assert result["has_cycles"] is True
    assert len(result["cycles"]) == 1
    db.close()


# ── find_subgraphs ──────────────────────────────────────────────────


def test_find_subgraphs_single():
    """Single connected component when all models are linked."""
    db = GraphDB()
    if not db.has_pgq:
        pytest.skip("DuckPGQ not installed")
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "chain.sql", "sql", "abc")

        a = db.insert_node(file_id, "table", "a", "sql")
        b = db.insert_node(file_id, "table", "b", "sql")
        c = db.insert_node(file_id, "table", "c", "sql")
        db.insert_edge(a, b, "references")
        db.insert_edge(b, c, "references")

        db._create_property_graph()
        result = db.query_find_subgraphs()

        assert result["total_components"] == 1
        assert result["total_nodes_in_scope"] == 3
        assert len(result["components"]) == 1
        assert result["components"][0]["size"] == 3
        assert set(result["components"][0]["models"]) == {"a", "b", "c"}
        assert result["largest_component"] == {"name": "a", "size": 3}
        assert result["orphaned_models"] == []
    finally:
        db.close()


def test_find_subgraphs_multiple():
    """Multiple disconnected components with an orphan are detected separately."""
    db = GraphDB()
    if not db.has_pgq:
        pytest.skip("DuckPGQ not installed")
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "multi.sql", "sql", "abc")

        # Component 1: a -> b -> c
        a = db.insert_node(file_id, "table", "a", "sql")
        b = db.insert_node(file_id, "table", "b", "sql")
        c = db.insert_node(file_id, "table", "c", "sql")
        db.insert_edge(a, b, "references")
        db.insert_edge(b, c, "references")

        # Component 2: x -> y
        x = db.insert_node(file_id, "table", "x", "sql")
        y = db.insert_node(file_id, "table", "y", "sql")
        db.insert_edge(x, y, "references")

        # Orphan
        db.insert_node(file_id, "table", "z_orphan", "sql")

        db._create_property_graph()
        result = db.query_find_subgraphs()

        assert result["total_components"] == 3
        assert result["total_nodes_in_scope"] == 6
        # Largest first
        assert result["components"][0]["size"] == 3
        assert result["components"][1]["size"] == 2
        assert result["components"][2]["size"] == 1
        assert set(result["components"][0]["models"]) == {"a", "b", "c"}
        assert set(result["components"][1]["models"]) == {"x", "y"}
        assert result["largest_component"] == {"name": "a", "size": 3}
        assert result["orphaned_models"] == ["z_orphan"]
    finally:
        db.close()


def test_find_subgraphs_orphans():
    """Isolated models (no edges) appear as size-1 components via CSR fallback."""
    db = GraphDB()
    if not db.has_pgq:
        pytest.skip("DuckPGQ not installed")
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "orphans.sql", "sql", "abc")

        db.insert_node(file_id, "table", "orphan_a", "sql")
        db.insert_node(file_id, "table", "orphan_b", "sql")
        db.insert_node(file_id, "table", "orphan_c", "sql")

        db._create_property_graph()
        result = db.query_find_subgraphs()

        assert result["total_components"] == 3
        assert result["total_nodes_in_scope"] == 3
        assert all(c["size"] == 1 for c in result["components"])
        assert sorted(result["orphaned_models"]) == ["orphan_a", "orphan_b", "orphan_c"]
        # largest_component is one of the orphans (all size 1)
        assert result["largest_component"]["size"] == 1
    finally:
        db.close()


def test_find_subgraphs_repo_filter():
    """Repo filter restricts analysis to models in that repo."""
    db = GraphDB()
    if not db.has_pgq:
        pytest.skip("DuckPGQ not installed")
    try:
        repo_a = db.upsert_repo("repo_a", "/tmp/repo_a", repo_type="sql")
        repo_b = db.upsert_repo("repo_b", "/tmp/repo_b", repo_type="sql")
        file_a = db.insert_file(repo_a, "a.sql", "sql", "abc")
        file_b = db.insert_file(repo_b, "b.sql", "sql", "def")

        # repo_a: m1 -> m2
        m1 = db.insert_node(file_a, "table", "m1", "sql")
        m2 = db.insert_node(file_a, "table", "m2", "sql")
        db.insert_edge(m1, m2, "references")

        # repo_b: n1 (isolated)
        db.insert_node(file_b, "table", "n1", "sql")

        db._create_property_graph()

        result_a = db.query_find_subgraphs(repo="repo_a")
        assert result_a["total_components"] == 1
        assert result_a["total_nodes_in_scope"] == 2
        assert set(result_a["components"][0]["models"]) == {"m1", "m2"}

        result_b = db.query_find_subgraphs(repo="repo_b")
        assert result_b["total_components"] == 1
        assert result_b["total_nodes_in_scope"] == 1
        assert result_b["orphaned_models"] == ["n1"]

        # Non-existent repo returns empty results
        result_none = db.query_find_subgraphs(repo="nonexistent")
        assert result_none["total_components"] == 0
        assert result_none["total_nodes_in_scope"] == 0
        assert result_none["largest_component"] is None
    finally:
        db.close()


def test_find_subgraphs_no_pgq():
    """Returns error dict only when DuckPGQ is not installed."""
    db = GraphDB()
    db._has_pgq = False
    try:
        result = db.query_find_subgraphs()
        assert result == {"error": "DuckPGQ not installed. Install with: INSTALL duckpgq FROM community"}
    finally:
        db.close()


def test_find_subgraphs_empty():
    """Empty graph (no nodes, no edges) returns zero components."""
    db = GraphDB()
    if not db.has_pgq:
        pytest.skip("DuckPGQ not installed")
    try:
        db.upsert_repo("test", "/tmp/test", repo_type="sql")
        db._create_property_graph()
        result = db.query_find_subgraphs()

        assert result["total_components"] == 0
        assert result["total_nodes_in_scope"] == 0
        assert result["components"] == []
        assert result["largest_component"] is None
        assert result["orphaned_models"] == []
    finally:
        db.close()


# ── find_bottlenecks ────────────────────────────────────────────────


def _build_star_graph(db, file_id, hub_name: str, spoke_count: int):
    """Create a star: hub_name <- spoke_1, spoke_2, ..., spoke_N.

    Each spoke depends on hub (edge: spoke -> hub), so hub has
    `spoke_count` downstream dependents.
    """
    hub = db.insert_node(file_id, "table", hub_name, "sql")
    for i in range(spoke_count):
        spoke = db.insert_node(file_id, "table", f"{hub_name}_dep_{i}", "sql")
        db.insert_edge(spoke, hub, "references")
    return hub


def test_find_bottlenecks_high_fanout():
    """Model with high downstream count is identified as bottleneck."""
    db = GraphDB()
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "star.sql", "sql", "abc")

        # Hub has 25 dependents and 1 upstream dependency
        hub = _build_star_graph(db, file_id, "staging_orders", 25)
        source = db.insert_node(file_id, "table", "raw_orders", "sql")
        db.insert_edge(hub, source, "references")

        if db.has_pgq:
            db._create_property_graph()
        result = db.query_find_bottlenecks(min_downstream=5)

        assert len(result["bottlenecks"]) == 1
        b = result["bottlenecks"][0]
        assert b["name"] == "staging_orders"
        assert b["downstream"] == 25
        assert b["upstream"] == 1
        assert b["risk"] == "high"
    finally:
        db.close()


def test_find_bottlenecks_min_filter():
    """min_downstream filters out models below the threshold."""
    db = GraphDB()
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "multi.sql", "sql", "abc")

        _build_star_graph(db, file_id, "hub_3", 3)
        _build_star_graph(db, file_id, "hub_10", 10)
        _build_star_graph(db, file_id, "hub_25", 25)
        _build_star_graph(db, file_id, "hub_50", 50)

        if db.has_pgq:
            db._create_property_graph()

        result = db.query_find_bottlenecks(min_downstream=20)
        names = {b["name"] for b in result["bottlenecks"]}
        assert names == {"hub_25", "hub_50"}

        result_all = db.query_find_bottlenecks(min_downstream=1)
        names_all = {b["name"] for b in result_all["bottlenecks"]}
        assert {"hub_3", "hub_10", "hub_25", "hub_50"} <= names_all
    finally:
        db.close()


def test_find_bottlenecks_clustering():
    """Clustering coefficient is included when DuckPGQ is available."""
    db = GraphDB()
    if not db.has_pgq:
        pytest.skip("DuckPGQ not installed")
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "cluster.sql", "sql", "abc")

        _build_star_graph(db, file_id, "hub", 6)
        db._create_property_graph()

        result = db.query_find_bottlenecks(min_downstream=5)
        assert result["has_clustering"] is True
        assert len(result["bottlenecks"]) >= 1
        b = result["bottlenecks"][0]
        assert b["name"] == "hub"
        assert isinstance(b["clustering"], (int, float))
    finally:
        db.close()


def test_find_bottlenecks_no_pgq_fallback():
    """Without DuckPGQ, has_clustering is False and clustering is None."""
    db = GraphDB()
    db._has_pgq = False
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "star.sql", "sql", "abc")

        _build_star_graph(db, file_id, "hub", 10)

        result = db.query_find_bottlenecks(min_downstream=5)
        assert result["has_clustering"] is False
        assert len(result["bottlenecks"]) == 1
        b = result["bottlenecks"][0]
        assert b["clustering"] is None
        assert b["downstream"] == 10
    finally:
        db.close()


def test_find_bottlenecks_ordering():
    """Results ordered by downstream desc; risk boundaries at 10 and 20."""
    db = GraphDB()
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "order.sql", "sql", "abc")

        _build_star_graph(db, file_id, "small", 5)          # low (<= 10)
        _build_star_graph(db, file_id, "at_ten", 10)        # low (boundary: exactly 10)
        _build_star_graph(db, file_id, "medium", 15)        # medium (> 10)
        _build_star_graph(db, file_id, "at_twenty_one", 21) # high (> 20)
        _build_star_graph(db, file_id, "large", 30)         # high

        if db.has_pgq:
            db._create_property_graph()

        result = db.query_find_bottlenecks(min_downstream=5)
        downstream_counts = [b["downstream"] for b in result["bottlenecks"]]
        assert downstream_counts == sorted(downstream_counts, reverse=True)

        by_name = {b["name"]: b for b in result["bottlenecks"]}
        assert by_name["large"]["risk"] == "high"
        assert by_name["at_twenty_one"]["risk"] == "high"
        assert by_name["medium"]["risk"] == "medium"
        assert by_name["at_ten"]["risk"] == "low"   # exactly 10 is NOT > 10
        assert by_name["small"]["risk"] == "low"
    finally:
        db.close()


def test_find_bottlenecks_repo_filter():
    """Repo filter restricts analysis to models in that repo."""
    db = GraphDB()
    try:
        repo_a = db.upsert_repo("repo_a", "/tmp/repo_a", repo_type="sql")
        repo_b = db.upsert_repo("repo_b", "/tmp/repo_b", repo_type="sql")
        file_a = db.insert_file(repo_a, "a.sql", "sql", "abc")
        file_b = db.insert_file(repo_b, "b.sql", "sql", "def")

        _build_star_graph(db, file_id=file_a, hub_name="hub_a", spoke_count=10)
        _build_star_graph(db, file_id=file_b, hub_name="hub_b", spoke_count=15)

        if db.has_pgq:
            db._create_property_graph()

        result_a = db.query_find_bottlenecks(min_downstream=5, repo="repo_a")
        names_a = {b["name"] for b in result_a["bottlenecks"]}
        assert names_a == {"hub_a"}

        result_b = db.query_find_bottlenecks(min_downstream=5, repo="repo_b")
        names_b = {b["name"] for b in result_b["bottlenecks"]}
        assert names_b == {"hub_b"}

        # Non-existent repo returns empty results
        result_none = db.query_find_bottlenecks(min_downstream=1, repo="nonexistent")
        assert result_none["bottlenecks"] == []
        assert result_none["total_analyzed"] == 0
    finally:
        db.close()


def test_find_bottlenecks_empty_graph():
    """Empty graph returns no bottlenecks."""
    db = GraphDB()
    try:
        db.upsert_repo("test", "/tmp/test", repo_type="sql")
        result = db.query_find_bottlenecks(min_downstream=1)
        assert result["bottlenecks"] == []
        assert result["total_analyzed"] == 0
    finally:
        db.close()


# ── #127: defines-edge filter regression ──


def _build_defines_self_collision_graph():
    """Mirror the #127 fixture: a file-stem `query` node with a `defines`
    edge to a same-named `table` node, plus a real `references` edge.

    orders (query)      -[defines]->    orders (table)
    orders (query)      -[references]-> stg_orders (table)
    downstream (query)  -[references]-> orders (table)
    """
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    orders_file = db.insert_file(repo_id, "orders.sql", "sql", "orders-abc")
    downstream_file = db.insert_file(repo_id, "downstream.sql", "sql", "downstream-abc")

    orders_query = db.insert_node(orders_file, "query", "orders", "sql")
    orders_table = db.insert_node(orders_file, "table", "orders", "sql")
    stg_orders = db.insert_node(orders_file, "table", "stg_orders", "sql")
    downstream_query = db.insert_node(downstream_file, "query", "downstream", "sql")

    db.insert_edge(orders_query, orders_table, "defines", "CREATE statement")
    db.insert_edge(orders_query, stg_orders, "references")
    db.insert_edge(downstream_query, orders_table, "references")

    if db.has_pgq:
        db.refresh_property_graph()
    return db


def test_find_path_excludes_self_via_defines_edge():
    """#127 BDD: find_path('orders', 'orders') does not return a length-1
    self-path via the `defines` edge between the file-stem query node and
    the table it declares.
    """
    db = _build_defines_self_collision_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    try:
        result = db.query_find_path("orders", "orders")
        assert result["path_found"] is False
        assert result["path"] == []
        assert result["length"] == 0
    finally:
        db.close()


def test_find_bottlenecks_ignores_defines_edge():
    """#127: `defines` edges must not contribute to downstream_count.

    Without the filter the `orders (table)` node would report downstream=2
    (real `downstream` consumer + the `orders (query)` defines edge); with
    the filter downstream=1 (only the real consumer). Also asserts the
    real consumer's own downstream/upstream still register, so a future
    over-eager filter that drops *all* edges would fail.
    """
    db = _build_defines_self_collision_graph()
    try:
        result = db.query_find_bottlenecks(min_downstream=1)
        by_name_kind = {(b["name"], b["kind"]): b for b in result["bottlenecks"]}
        orders_table = by_name_kind.get(("orders", "table"))
        assert orders_table is not None, "orders (table) should appear as a bottleneck"
        assert orders_table["downstream"] == 1, (
            f"defines edge leaked into downstream count: {orders_table}"
        )
        # `stg_orders` has one inbound real `references` edge from
        # orders(query) — its downstream must be 1. This is a stronger
        # check than `orders(table).downstream == 1`: it proves the filter
        # is narrow, not an over-eager drop of all edges touching the
        # file-stem query node.
        stg_orders = by_name_kind.get(("stg_orders", "table"))
        assert stg_orders is not None, "stg_orders (real consumer target) missing"
        assert stg_orders["downstream"] == 1, (
            f"real references edge dropped: {stg_orders}"
        )
    finally:
        db.close()


def test_find_bottlenecks_upstream_count_ignores_defines_edge():
    """#127: `defines` edges must not contribute to upstream count either.

    Covers the symmetric half of the fix — the `upstream_counts` CTE must
    apply the same filter as the fan-in join. A query node with N real
    outbound references plus one `defines` edge should report upstream=N.
    """
    db = GraphDB()
    try:
        repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
        file_id = db.insert_file(repo_id, "m.sql", "sql", "m-abc")
        consumer_file = db.insert_file(repo_id, "consumer.sql", "sql", "c-abc")

        m_query = db.insert_node(file_id, "query", "m", "sql")
        m_table = db.insert_node(file_id, "table", "m", "sql")
        src_a = db.insert_node(file_id, "table", "src_a", "sql")
        src_b = db.insert_node(file_id, "table", "src_b", "sql")
        consumer = db.insert_node(consumer_file, "query", "consumer", "sql")

        db.insert_edge(m_query, m_table, "defines")      # identity, not dataflow
        db.insert_edge(m_query, src_a, "references")     # real upstream #1
        db.insert_edge(m_query, src_b, "references")     # real upstream #2
        db.insert_edge(consumer, m_query, "references")  # gives m_query 1 inbound

        if db.has_pgq:
            db.refresh_property_graph()

        result = db.query_find_bottlenecks(min_downstream=1)
        by_name_kind = {(b["name"], b["kind"]): b for b in result["bottlenecks"]}
        m_query_stats = by_name_kind.get(("m", "query"))
        assert m_query_stats is not None, "m (query) should qualify"
        assert m_query_stats["upstream"] == 2, (
            f"defines edge leaked into upstream count: {m_query_stats}"
        )
    finally:
        db.close()


# ── #127: inserts_into self-loop filter regression ──


def _build_inserts_into_self_collision_graph():
    """Mirror the #127 inserts_into self-loop fixture.

    Emulates ``orders.sql`` with ``INSERT INTO orders SELECT * FROM raw_orders``
    — the SQL parser (sql.py:410) emits both ``inserts_into`` edges from the
    file-stem query. When the file stem collides with the INSERT target, the
    source/target share a name — the same self-loop shape as the ``defines``
    bug fixed for trace/references in PR #126.

      orders (query)      -[inserts_into]-> orders (table)       # self-loop
      orders (query)      -[inserts_into]-> raw_orders (table)   # cross-table
      downstream (query)  -[references]->   orders (table)
    """
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    orders_file = db.insert_file(repo_id, "orders.sql", "sql", "orders-abc")
    downstream_file = db.insert_file(repo_id, "downstream.sql", "sql", "downstream-abc")

    orders_query = db.insert_node(orders_file, "query", "orders", "sql")
    orders_table = db.insert_node(orders_file, "table", "orders", "sql")
    raw_orders = db.insert_node(orders_file, "table", "raw_orders", "sql")
    downstream_query = db.insert_node(downstream_file, "query", "downstream", "sql")

    db.insert_edge(orders_query, orders_table, "inserts_into")
    db.insert_edge(orders_query, raw_orders, "inserts_into")
    db.insert_edge(downstream_query, orders_table, "references")

    if db.has_pgq:
        db.refresh_property_graph()
    return db


def test_find_path_excludes_self_via_inserts_into_edge():
    """#127: find_path('orders', 'orders') does not return a length-1 self-path
    via an `inserts_into` edge between the file-stem query and same-named target.
    """
    db = _build_inserts_into_self_collision_graph()
    if not db.has_pgq:
        db.close()
        pytest.skip("DuckPGQ not installed")
    try:
        result = db.query_find_path("orders", "orders")
        assert result["path_found"] is False
        assert result["path"] == []
        assert result["length"] == 0
    finally:
        db.close()


def test_find_bottlenecks_ignores_inserts_into_self_loop():
    """#127: inserts_into self-loop must not contribute to downstream_count.

    Without the filter `orders (table)` reports downstream=2 (real `downstream`
    consumer + the `orders (query)` inserts_into self-loop). With the filter
    downstream=1 — the real consumer only.
    """
    db = _build_inserts_into_self_collision_graph()
    try:
        result = db.query_find_bottlenecks(min_downstream=1)
        by_name_kind = {(b["name"], b["kind"]): b for b in result["bottlenecks"]}
        orders_table = by_name_kind.get(("orders", "table"))
        assert orders_table is not None, "orders (table) should appear as a bottleneck"
        assert orders_table["downstream"] == 1, (
            f"inserts_into self-loop leaked into downstream count: {orders_table}"
        )
    finally:
        db.close()


def test_find_bottlenecks_upstream_count_ignores_inserts_into_self_loop():
    """Symmetric upstream-count regression: the file-stem query's own
    inserts_into edge to a same-named target must not inflate its upstream.
    The cross-table inserts_into edge (to raw_orders) still counts.
    """
    db = _build_inserts_into_self_collision_graph()
    try:
        # orders_query has two outbound inserts_into edges — one self-loop to
        # orders(table), one real to raw_orders(table). After filtering only
        # the real edge counts. orders_query has 0 inbound so min_downstream=1
        # would drop it; drop min_downstream to 0 to admit it into the result.
        result = db.query_find_bottlenecks(min_downstream=1)
        by_name_kind = {(b["name"], b["kind"]): b for b in result["bottlenecks"]}
        # Assert the self-loop did not inflate the declared table's upstream.
        # orders(table) has 0 outbound real edges — upstream should be 0.
        orders_table = by_name_kind.get(("orders", "table"))
        assert orders_table is not None
        assert orders_table["upstream"] == 0, (
            f"unexpected upstream for orders(table): {orders_table}"
        )
    finally:
        db.close()


def test_check_impact_ignores_inserts_into_self_loop():
    """#127: check_impact downstream discovery must exclude the file-stem query
    node that inserts into a same-named target, not just the one that defines it.
    """
    db = GraphDB()
    repo_id = db.upsert_repo("test", "/tmp/test", repo_type="sql")
    with db.write_transaction():
        file_id = db.insert_file(repo_id, "orders.sql", "sql", "abc")
        orders_table = db.insert_node(file_id, "table", "orders", "sql")
        orders_query = db.insert_node(file_id, "query", "orders", "sql")
        consumer_id = db.insert_node(file_id, "query", "marts.revenue", "sql")

        db.insert_edge(orders_query, orders_table, "inserts_into")   # self-loop
        db.insert_edge(consumer_id, orders_table, "references")      # real consumer
        db.insert_column_usage(consumer_id, "orders", "amount", "select", file_id)

    try:
        result = db.query_check_impact(
            "orders",
            [{"action": "add_column", "column": "new_field"}],
        )
        safe_models = {s["model"] for s in result["impacts"][0]["safe"]}
        # The file-stem query's inserts_into self-loop must not surface as a
        # downstream consumer — only the real references-based consumer does.
        assert "orders" not in safe_models, (
            f"inserts_into self-loop leaked into downstream consumers: {safe_models}"
        )
        assert "marts.revenue" in safe_models
    finally:
        db.close()
