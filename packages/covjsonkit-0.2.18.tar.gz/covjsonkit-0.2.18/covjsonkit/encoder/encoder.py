from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import timedelta
from typing import Any

import numpy as np
import orjson
import pandas as pd
from covjson_pydantic.coverage import CoverageCollection
from covjson_pydantic.domain import DomainType

from covjsonkit.param_db import get_param_ids, get_params, get_units


def timedelta_to_step_string(td: timedelta) -> str:
    """
    Convert a timedelta object to a step string in the format 'XhYm'.

    Args:
        td: timedelta object representing the step

    Returns:
        String in format 'Xh', 'Ym', or 'XhYm' depending on the timedelta value

    Examples:
        timedelta(hours=13) -> "13h"
        timedelta(hours=13, minutes=30) -> "13h30m"
        timedelta(minutes=30) -> "30m"
        timedelta(hours=0, minutes=0) -> "0h"
    """
    total_seconds = int(td.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60

    if hours > 0 and minutes > 0:
        return f"{hours}h{minutes}m"
    elif hours > 0:
        return f"{hours}h"
    elif minutes > 0:
        return f"{minutes}m"
    else:
        return "0h"


def parse_step_string(step_str: str) -> float:
    """
    Parse a step string in format 'XhYm' and return total hours as float.

    Args:
        step_str: Step string in format 'Xh', 'Ym', or 'XhYm'

    Returns:
        Total hours as a float value

    Examples:
        parse_step_string("13h") -> 13.0
        parse_step_string("13h30m") -> 13.5
        parse_step_string("30m") -> 0.5
        parse_step_string("0h") -> 0.0
    """
    if isinstance(step_str, (int, float)):
        return float(step_str)

    step_str = str(step_str)
    hours = 0.0
    minutes = 0.0

    # Parse hours
    if "h" in step_str:
        parts = step_str.split("h")
        hours = float(parts[0])
        step_str = parts[1] if len(parts) > 1 else ""

    # Parse minutes
    if "m" in step_str and step_str:
        minutes = float(step_str.replace("m", ""))

    return hours + (minutes / 60.0)


def sort_step_values(steps: list) -> list:
    """
    Sort a list of step values that might be in various formats.

    Args:
        steps: List of step values (strings like "13h30m", integers, or floats)

    Returns:
        Sorted list of step values in their original format

    Examples:
        sort_step_values(["13h30m", "12h", "14h"]) -> ["12h", "13h30m", "14h"]
    """
    # Create tuples of (original_value, numeric_value) for sorting
    step_tuples = [(step, parse_step_string(step)) for step in steps]
    # Sort by numeric value
    step_tuples.sort(key=lambda x: x[1])
    # Return original values in sorted order
    return [step[0] for step in step_tuples]


def normalize_step_value(step):
    """
    Normalize a step value from various formats, preserving integers when possible.

    Handles:
    - timedelta objects (datetime.timedelta) - converts to int if whole hours, else string "XhYm"
    - numpy.timedelta64 objects - converts to int if whole hours, else string "XhYm"
    - integers - returns as-is (legacy compatibility)
    - floats - converts to int if whole hours, else string "XhYm"
    - strings - returns as-is if already in correct format

    Args:
        step: Step value in various formats

    Returns:
        Integer for whole hour values, string in 'XhYm' format for sub-hourly values

    Examples:
        normalize_step_value(timedelta(hours=13, minutes=30)) -> "13h30m"
        normalize_step_value(timedelta(hours=13)) -> 13
        normalize_step_value(13) -> 13
        normalize_step_value(13.5) -> "13h30m"
        normalize_step_value("13h30m") -> "13h30m"
    """
    # If it's already a string, return as-is (assumes it's already in correct format)
    if isinstance(step, str):
        return step

    # If it's a timedelta or pd.Timedelta, check if it has sub-hourly components
    if isinstance(step, (timedelta, pd.Timedelta)):
        if isinstance(step, pd.Timedelta):
            td = step.to_pytimedelta()
        else:
            td = step

        total_seconds = int(td.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60

        # If there are minutes, return string format
        if minutes > 0:
            return timedelta_to_step_string(td)
        # Otherwise return integer hours
        return hours

    # If it's a numpy timedelta64, convert to Python timedelta first
    if isinstance(step, np.timedelta64):
        td = pd.Timedelta(step).to_pytimedelta()
        total_seconds = int(td.total_seconds())
        hours = total_seconds // 3600
        minutes = (total_seconds % 3600) // 60

        if minutes > 0:
            return timedelta_to_step_string(td)
        return hours

    # If it's an integer, return as-is (legacy compatibility)
    if isinstance(step, (int, np.integer)):
        return int(step)

    # If it's a float, check if it has fractional hours
    if isinstance(step, (float, np.floating)):
        hours = int(step)
        total_minutes = int(step * 60)
        minutes = total_minutes % 60

        if minutes > 0:
            if hours > 0:
                return f"{hours}h{minutes}m"
            else:
                return f"{minutes}m"
        return hours

    # Fallback: convert to string
    return str(step)


class Encoder(ABC):
    def __init__(self, type, domaintype):
        """
        Base class for encoding data into CovJSON format.

        The Encoder class provides functionality to initialize and manage the encoding
        process for various domain types, including point series, multi-point, vertical profiles,
        and trajectories. It handles parameters, referencing systems, and domain types, and
        supports conversion between parameter IDs and parameter names.

        Attributes:
            covjson (dict): The CovJSON representation being constructed.
            type (str): The type of data being encoded.
            referencing (list): A list of referencing systems used in the encoding.
            units (dict): Units associated with the parameters, retrieved from the database.
            params (dict): Parameters associated with the data type, retrieved from the database.
            param_ids (dict): Mapping of parameter names to their IDs.
            domaintype (str): The domain type of the data being encoded.
            pydantic_coverage (CoverageCollection): A Pydantic representation of the coverage collection.
            parameters (list): A list of parameters included in the encoding.

        Methods:
            add_parameter(param): Adds a parameter to the CovJSON representation.
            add_reference(reference): Adds a referencing system to the CovJSON representation.
            convert_param_id_to_param(paramid): Converts a parameter ID to its corresponding parameter name.
            convert_param_to_param_id(param): Converts a parameter name to its corresponding parameter ID.
            get_json(): Returns the CovJSON representation as a JSON string.
            walk_tree(tree, fields, coords, mars_metadata, range_dict): Processes a hierarchical tree structure
                to extract data and populate the CovJSON representation.
            walk_tree_step(tree, fields, coords, mars_metadata, range_dict): Processes a hierarchical tree structure
                with step-based data to extract and populate the CovJSON representation.

        Abstract Methods:
            add_coverage(mars_metadata, coords, values): Abstract method for adding coverage data.
            add_domain(coverage, domain): Abstract method for adding domain information.
            add_range(coverage, range): Abstract method for adding range information.
            add_mars_metadata(coverage, metadata): Abstract method for adding Mars metadata.
            from_xarray(dataset): Abstract method for encoding data from an xarray dataset.
            from_polytope(result): Abstract method for encoding data from a polytope result.
        """

        self.covjson = {}
        self.covjson["type"] = "CoverageCollection"

        self.type = type

        self.referencing = []

        self.units = get_units(self.type)
        self.params = get_params(self.type)
        self.param_ids = get_param_ids(self.type)

        domaintype = domaintype.lower()

        if domaintype == "pointseries":
            self.domaintype = DomainType.point_series
        elif domaintype == "multipoint":
            self.domaintype = DomainType.multi_point
        elif domaintype == "polygon":
            self.domaintype = DomainType.multi_point
        elif domaintype == "boundingbox":
            self.domaintype = DomainType.multi_point
        elif domaintype == "shapefile":
            self.domaintype = DomainType.multi_point
        elif domaintype == "frame":
            self.domaintype = DomainType.multi_point
        elif domaintype == "circle":
            self.domaintype = DomainType.multi_point
        elif domaintype == "verticalprofile":
            self.domaintype = DomainType.vertical_profile
        elif domaintype == "path":
            self.domaintype = "Trajectory"
        elif domaintype == "grid":
            self.domaintype = "Grid"
        elif domaintype == "position":
            self.domaintype = DomainType.point_series

        # Trajectory not yet implemented in covjson-pydantic
        if self.domaintype != "Trajectory" and self.domaintype != "Grid":
            self.pydantic_coverage = CoverageCollection(
                type="CoverageCollection", coverages=[], domainType=self.domaintype, parameters={}, referencing=[]
            )
        self.parameters = []

    def add_parameter(self, param):
        # param_dict = get_param_from_db(param)
        # unit = get_unit_from_db(param_dict["unit_id"])
        param_dict = self.params[str(param)]
        if isinstance(param_dict["unit_id"], str):
            unit = {"name": param_dict["unit_id"]}
        else:
            unit = self.units[str(param_dict["unit_id"])]
        parameter = {
            "type": "Parameter",
            "description": {"en": param_dict["description"]},
            "unit": {"symbol": unit["name"]},
            "observedProperty": {
                "id": param_dict["shortname"],
                "label": {"en": param_dict["name"]},
            },
        }
        # self.pydantic_coverage.parameters[param_dict["shortname"]] = Parameter.model_validate_json(
        #    json.dumps(parameter)
        # )
        if "parameters" not in self.covjson:
            self.covjson["parameters"] = {}
            self.covjson["parameters"][param_dict["shortname"]] = parameter
        else:
            self.covjson["parameters"][param_dict["shortname"]] = parameter
        self.parameters.append(param)

    def add_reference(self, reference):
        # self.pydantic_coverage.referencing.append(
        #    ReferenceSystemConnectionObject.model_validate_json(json.dumps(reference))
        # )
        # self.pydantic_coverage.referencing.append(reference)
        # for ref in reference["coordinates"]:
        #    if ref not in self.referencing:
        # self.referencing.append(ref)
        self.covjson["referencing"] = [reference]

    def convert_param_id_to_param(self, paramid):
        try:
            param = int(paramid)
        except BaseException:
            return paramid
        # param_dict = get_param_from_db(int(param))
        param_dict = self.params[str(param)]
        return param_dict["shortname"]

    def convert_param_to_param_id(self, param):
        if isinstance(param, int):
            return param
        # param_dict = get_param_from_db(param)
        param_id = self.param_ids[param]
        return param_id

    def get_json(self):
        # self.covjson = self.pydantic_coverage.model_dump_json(exclude_none=True, indent=4)
        return orjson.dumps(self.covjson)

    def walk_tree(
        self,
        tree,
        fields: dict[str, Any],
        coords: dict[str, dict[str, list]],
        mars_metadata: dict[str, Any],
        range_dict: dict[tuple, list],
        date_key: str = "date",
    ) -> None:
        """Walk the polytope result tree, extracting data into fields, coords, and range_dict.

        ``date_key`` controls which tree axis is treated as the time dimension
        (e.g. ``"date"`` for forecasts, ``"hdate"`` for hindcast/reforecast data).
        Any other axis with the default name falls through to ``mars_metadata``
        instead.  Regardless of ``date_key``, values are always stored under
        ``fields["dates"]``.
        """

        def create_composite_key(date, level, num, para, s):
            return (date, level, num, para, s)

        def handle_non_leaf_node(child):
            non_leaf_axes = ["latitude", "longitude", "param", date_key]
            if child.axis.name not in non_leaf_axes:
                val = child.values[0]
                if isinstance(val, np.datetime64):
                    val = str(val)
                elif isinstance(val, timedelta):
                    val = timedelta_to_step_string(val)
                elif child.axis.name == "step":
                    # Step is not a timedelta! Need to normalize it
                    val = normalize_step_value(val)
                mars_metadata[child.axis.name] = val

        def handle_specific_axes(child):
            if child.axis.name == "latitude":
                return child.values[0]
            if child.axis.name == "levelist":
                return child.values
            if child.axis.name == "param":
                return child.values
            if child.axis.name in [date_key, "time"]:
                dates = [f"{date}Z" for date in child.values]
                mars_metadata["Forecast date"] = str(child.values[0])
                for date in dates:
                    coords[date] = {}
                    coords[date]["composite"] = []
                    coords[date]["t"] = [date]
                return dates
            if child.axis.name == "number":
                return child.values
            if child.axis.name == "step":
                return child.values
            return None

        def calculate_index_bounds(level_len, num_len, para_len, step_len, l, i, j, k):  # noqa: E741
            start_index = int(l * level_len) + int(i * num_len) + int(j * para_len) + int(k * step_len)
            end_index = start_index + int(step_len)
            return start_index, end_index

        def append_composite_coords(dates, tree_values, lat, coords):
            # for date in dates:
            for value in tree_values:
                coords[dates]["composite"].append([lat, value])

        if len(tree.children) != 0:
            for child in tree.children:
                handle_non_leaf_node(child)
                result = handle_specific_axes(child)
                if result is not None:
                    if child.axis.name == "latitude":
                        fields["lat"] = result
                    elif child.axis.name == "levelist":
                        fields["levels"] = result
                        if "l" in fields:
                            fields["l"].extend(result)
                    elif child.axis.name == "param":
                        fields["param"] = result
                    elif child.axis.name in [date_key, "time"]:
                        fields["dates"].extend(result)
                    elif child.axis.name == "number":
                        fields["number"] = result
                    elif child.axis.name == "step":
                        fields["step"] = result
                        if "s" in fields:
                            fields["s"].extend(result)

                self.walk_tree(child, fields, coords, mars_metadata, range_dict, date_key=date_key)
        else:
            tree.values = [float(val) for val in tree.values]
            if all(val is None for val in tree.result):
                fields["dates"] = fields["dates"][:-1]
                for date in fields["dates"]:
                    for level in fields["levels"]:
                        for num in fields["number"]:
                            for para in fields["param"]:
                                for s in fields["step"]:
                                    key = create_composite_key(date, level, num, para, s)
                                    if key in range_dict:
                                        del range_dict[key]
            else:
                tree.result = [float(val) if val is not None else val for val in tree.result]
                level_len = len(tree.result) / len(fields["levels"])
                num_len = level_len / len(fields["number"])
                para_len = num_len / len(fields["param"])
                step_len = para_len / len(fields["step"])

                append_composite_coords(fields["dates"][-1], tree.values, fields["lat"], coords)

                for l, level in enumerate(fields["levels"]):  # noqa: E741
                    for i, num in enumerate(fields["number"]):
                        for j, para in enumerate(fields["param"]):
                            for k, s in enumerate(fields["step"]):
                                start_index, end_index = calculate_index_bounds(
                                    level_len, num_len, para_len, step_len, l, i, j, k
                                )
                                key = create_composite_key(fields["dates"][-1], level, num, para, s)
                                if key not in range_dict:
                                    range_dict[key] = []
                                range_dict[key].extend(tree.result[start_index:end_index])

    def walk_tree_step(self, tree, fields, coords, mars_metadata, range_dict):
        def create_composite_key_step(date, level, num, para):
            return (date, level, num, para)

        def handle_non_leaf_node_step(child):
            non_leaf_axes = ["latitude", "longitude", "param", "date", "time"]
            if child.axis.name not in non_leaf_axes:
                val = child.values[0]
                if isinstance(val, np.datetime64):
                    val = str(val)
                elif isinstance(val, timedelta):
                    val = timedelta_to_step_string(val)
                elif child.axis.name == "step":
                    # Step is not a timedelta! Need to normalize it
                    val = normalize_step_value(val)
                mars_metadata[child.axis.name] = val

        def handle_specific_axes_step(child):
            if child.axis.name == "latitude":
                return child.values[0]
            if child.axis.name == "levelist":
                return child.values
            if child.axis.name == "param":
                return child.values
            if child.axis.name in ["date"]:
                dates = [f"{date}Z" for date in child.values]
                # mars_metadata["Forecast date"] = str(child.values[0])
                # for date in dates:
                #    coords[date] = {}
                #    coords[date]["composite"] = []
                #    coords[date]["t"] = [date]
                return dates
            if child.axis.name == "number":
                return child.values
            if child.axis.name == "step":
                return child.values
            if child.axis.name == "time":
                for date in fields["dates"]:
                    coords[date] = {}
                    coords[date]["composite"] = []
                    coords[date]["t"] = []
                    for time in child.values:
                        datetime = pd.Timestamp(date) + time
                        coords[date]["t"].append(str(datetime).split("+")[0] + "Z")
                return child.values
            return None

        def calculate_index_bounds_step(level_len, num_len, para_len, step_len, l, i, j, k):  # noqa: E741
            start_index = int(l * level_len) + int(i * num_len) + int(j * para_len) + int(k * step_len)
            end_index = start_index + int(step_len)
            return start_index, end_index

        def append_composite_coords_step(dates, tree_values, lat, coords):
            # for date in dates:
            for value in tree_values:
                coords[dates]["composite"].append([lat, value])

        if len(tree.children) != 0:
            for child in tree.children:
                handle_non_leaf_node_step(child)
                result = handle_specific_axes_step(child)
                if result is not None:
                    if child.axis.name == "latitude":
                        fields["lat"] = result
                    elif child.axis.name == "levelist":
                        fields["levels"] = result
                        if "l" in fields:
                            fields["l"].extend(result)
                    elif child.axis.name == "param":
                        fields["param"] = result
                    elif child.axis.name in ["date"]:
                        fields["dates"].extend(result)
                    elif child.axis.name == "number":
                        fields["number"] = result
                    elif child.axis.name == "step":
                        fields["step"] = result
                        if "s" in fields:
                            fields["s"].extend(result)
                    elif child.axis.name == "time":
                        fields["times"].extend(result)

                self.walk_tree_step(child, fields, coords, mars_metadata, range_dict)
        else:
            tree.values = [float(val) for val in tree.values]
            if all(val is None for val in tree.result):
                fields["dates"] = fields["dates"][:-1]
                for date in fields["dates"]:
                    for level in fields["levels"]:
                        for num in fields["number"]:
                            for para in fields["param"]:
                                for s in fields["step"]:
                                    key = create_composite_key_step(date, level, num, para)
                                    if key in range_dict:
                                        del range_dict[key]
            else:
                tree.result = [float(val) if val is not None else val for val in tree.result]
                date_len = len(tree.result) / len(fields["dates"])
                level_len = date_len / len(fields["levels"])
                para_len = level_len / len(fields["param"])
                # time_len = para_len / len(fields["times"])
                # coords_len = len(tree.values)

                for date in fields["dates"]:
                    append_composite_coords_step(date, tree.values, fields["lat"], coords)
                """
                for ti, _ in enumerate(fields["times"]):
                    for d, date in enumerate(fields["dates"]):
                        for l, level in enumerate(fields["levels"]):  # noqa: E741
                            for i, num in enumerate(fields["number"]):
                                for j, para in enumerate(fields["param"]):
                                    # for k, t in enumerate(fields["times"]):
                                    # start_index, end_index = calculate_index_bounds_step(
                                    #    level_len, num_len, para_len, time_len, l, i, j, k
                                    # )
                                    key = create_composite_key_step(date, level, num, para)
                                    if key not in range_dict:
                                        range_dict[key] = []
                                    # range_dict[key].extend(tree.result[start_index:end_index])
                                    # print(d, date_len,j, para_len)
                                    # print(d*date_len+j*para_len)
                                    # print(int(d*date_len+j*para_len+len(fields["times"])))
                                    # print(tree.result[int(d*date_len+j*para_len+len)])
                                    #print(tree.result)
                                    range_dict[key].append(#tree.result
                                        tree.result[
                                            int(d * date_len + j * para_len + ti * time_len) : int(
                                                d * date_len + j * para_len + ti * time_len + len(tree.values)
                                            )
                                        ]
                                    )
                """
                for d, date in enumerate(fields["dates"]):
                    for l, level in enumerate(fields["levels"]):  # noqa: E741
                        for i, num in enumerate(fields["number"]):
                            for j, para in enumerate(fields["param"]):
                                # for k, t in enumerate(fields["times"]):
                                # start_index, end_index = calculate_index_bounds_step(
                                #    level_len, num_len, para_len, time_len, l, i, j, k
                                # )
                                key = create_composite_key_step(date, level, num, para)
                                if key not in range_dict:
                                    range_dict[key] = []
                                range_dict[key].append(  # tree.result
                                    tree.result[
                                        int(d * date_len + l * level_len + j * para_len) : int(
                                            d * date_len + l * level_len + j * para_len + len(fields["times"])
                                        )
                                    ]
                                )

    def walk_tree_month(self, tree, fields, coords, mars_metadata, range_dict):
        """Walk the result tree for monthly-mean streams (e.g. clmn).

        These streams use ``year`` and ``month`` axes instead of ``date``/``time``/``step``.
        Each unique (year, month) pair is represented as an ISO-8601 date string
        ``"YYYY-MM"`` that plays the same role as ``date`` does in the standard
        step-based tree walker.

        Because the tree ordering can place ``month`` before ``year`` (or vice
        versa), both axes are collected independently into ``fields["months"]``
        and ``fields["years"]``.  The combined "YYYY-MM" keys are only built
        once both are available — either when the second axis is encountered, or
        at the leaf node.
        """

        def _year_month_key(year, month):
            return f"{int(year):04d}-{int(month):02d}"

        def _ensure_date_keys():
            """Populate ``fields["dates"]`` and ``coords`` once both year and
            month values are known."""
            if not fields.get("years") or not fields.get("months"):
                return
            for year in fields["years"]:
                for month in fields["months"]:
                    key = _year_month_key(year, month)
                    if key not in fields["dates"]:
                        fields["dates"].append(key)
                    if key not in coords:
                        coords[key] = {"composite": [], "t": [key]}

        def handle_non_leaf_node_month(child):
            non_leaf_axes = ["latitude", "longitude", "param", "year", "month"]
            if child.axis.name not in non_leaf_axes:
                val = child.values[0]
                if isinstance(val, np.datetime64):
                    val = str(val)
                mars_metadata[child.axis.name] = val

        def handle_specific_axes_month(child):
            if child.axis.name == "latitude":
                return child.values[0]
            if child.axis.name == "levelist":
                return child.values
            if child.axis.name == "param":
                return child.values
            if child.axis.name == "year":
                return child.values
            if child.axis.name == "month":
                return child.values
            if child.axis.name == "number":
                return child.values
            return None

        def append_composite_coords_month(date_key, tree_values, lat):
            for value in tree_values:
                coords[date_key]["composite"].append([lat, value])

        if len(tree.children) != 0:
            for child in tree.children:
                handle_non_leaf_node_month(child)
                result = handle_specific_axes_month(child)
                if result is not None:
                    if child.axis.name == "latitude":
                        fields["lat"] = result
                    elif child.axis.name == "levelist":
                        fields["levels"] = result
                        if "l" in fields:
                            fields["l"].extend(result)
                    elif child.axis.name == "param":
                        fields["param"] = result
                    elif child.axis.name == "year":
                        fields["years"] = result
                        _ensure_date_keys()
                    elif child.axis.name == "month":
                        fields["months"] = result
                        _ensure_date_keys()
                    elif child.axis.name == "number":
                        fields["number"] = result

                self.walk_tree_month(child, fields, coords, mars_metadata, range_dict)
        else:
            # Leaf node — make sure date keys are built before processing.
            _ensure_date_keys()

            tree.values = [float(val) for val in tree.values]
            if all(val is None for val in tree.result):
                # Remove the last date entry that produced no data.
                if fields["dates"]:
                    last_date = fields["dates"][-1]
                    fields["dates"] = fields["dates"][:-1]
                    for level in fields["levels"]:
                        for num in fields["number"]:
                            for para in fields["param"]:
                                key = (last_date, level, num, para)
                                if key in range_dict:
                                    del range_dict[key]
            else:
                tree.result = [float(val) if val is not None else val for val in tree.result]

                n_dates = len(fields["dates"])
                n_levels = len(fields["levels"])
                n_params = len(fields["param"])

                date_len = len(tree.result) / n_dates if n_dates else len(tree.result)
                level_len = date_len / n_levels if n_levels else date_len
                para_len = level_len / n_params if n_params else level_len

                # Append this leaf's longitude values to composite coords for
                # every date key so spatial points are recorded.
                for date in fields["dates"]:
                    append_composite_coords_month(date, tree.values, fields["lat"])

                for d, date in enumerate(fields["dates"]):
                    for l, level in enumerate(fields["levels"]):  # noqa: E741
                        for i, num in enumerate(fields["number"]):
                            for j, para in enumerate(fields["param"]):
                                key = (date, level, num, para)
                                if key not in range_dict:
                                    range_dict[key] = []
                                start = int(d * date_len + l * level_len + j * para_len)
                                end = int(start + len(tree.values))
                                range_dict[key].append(tree.result[start:end])

    @abstractmethod
    def add_coverage(self, mars_metadata, coords, values):
        pass

    @abstractmethod
    def add_domain(self, coverage, domain):
        pass

    @abstractmethod
    def add_range(self, coverage, range):
        pass

    @abstractmethod
    def add_mars_metadata(self, coverage, metadata):
        pass

    @abstractmethod
    def from_xarray(self, dataset):
        pass

    @abstractmethod
    def from_polytope(self, result, date_key: str = "date") -> dict:
        pass

    def from_polytope_reforecast(self, result) -> dict:
        """Encode reforecast/reanalysis data that uses ``"hdate"`` as the time axis.

        Delegates to :meth:`from_polytope` with ``date_key="hdate"``.
        Each hdate produces a separate coverage; steps within a single
        hdate become that coverage's t-axis values.
        """
        return self.from_polytope(result, date_key="hdate")
