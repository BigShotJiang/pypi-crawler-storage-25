# 📦 Catbox

> Python file uploader powered by [catbox.moe](https://catbox.moe) — sync & async support.

---

## ⚙️ Install

Install the latest version from PyPI:

```bash
pip install catxbox
```

Install a specific version:

```bash
pip install catxbox==2.0.2
```

Install directly from GitHub (always up to date):

```bash
pip install git+https://github.com/Badmunda05/catbox
```

---

## 🚀 Quick Start

```python
from catbox import Catbox

cb = Catbox()
urls = await cb.upload_async("photo.jpg")
print(urls[0])  # https://files.catbox.moe/xxxxxx.jpg
```

---

## 📖 Usage

### 🔹 Class-based — Sync

```python
from catbox import Catbox

cb = Catbox()                        # anonymous
cb = Catbox(userhash="yourhash")     # with catbox.moe account

# Upload single file
urls = cb.upload("photo.jpg")
print(urls[0])  # https://files.catbox.moe/xxxxxx.jpg

# Upload multiple files
urls = cb.upload(["photo.jpg", "video.mp4"])

# Delete files (userhash required)
cb.delete(["abc123.jpg"])
```

### 🔹 Class-based — Async (Recommended for bots)

```python
from catbox import Catbox

cb = Catbox()

# Upload
urls = await cb.upload_async("photo.jpg")
print(urls[0])

# Upload multiple
urls = await cb.upload_async(["photo.jpg", "video.mp4"])

# Delete
await cb.delete_async(["abc123.jpg"])
```

### 🔹 Standalone Functions

```python
from catbox import upload_file_catbox, upload_file_catbox_async
from catbox import delete_file_catbox, delete_file_catbox_async

# Sync upload
urls = upload_file_catbox("photo.jpg")

# Async upload
urls = await upload_file_catbox_async("photo.jpg")

# Sync delete
delete_file_catbox(["abc123.jpg"], userhash="yourhash")

# Async delete
await delete_file_catbox_async(["abc123.jpg"], userhash="yourhash")
```

---

## 🤖 Telegram Bot Example (Pyrogram)

```python
from catbox import upload_file_catbox_async, CatboxException
import os

@app.on_message(filters.command(["upload", "tgm"]))
async def upload_handler(_, message):
    reply = message.reply_to_message
    if not reply or not reply.media:
        return await message.reply("❌ Reply to a media file.")

    m = await message.reply("⏳ Uploading...")
    path = await reply.download()

    try:
        urls = await upload_file_catbox_async(path)
        await m.edit(f"✅ **Done!**\n\n🔗 {urls[0]}")
    except CatboxException as e:
        await m.edit(f"❌ Upload failed: `{e}`")
    finally:
        if path and os.path.exists(path):
            os.remove(path)
```

---

## 📋 API Reference

### `Catbox(userhash="")`

| Method | Sync/Async | Description | Returns |
|--------|-----------|-------------|---------|
| `upload(f)` | Sync | Upload file(s) | `list[str]` |
| `upload_async(f)` | Async | Upload file(s) | `list[str]` |
| `delete(filenames)` | Sync | Delete file(s) | `str` |
| `delete_async(filenames)` | Async | Delete file(s) | `str` |

### Standalone Functions

| Function | Description |
|----------|-------------|
| `upload_file_catbox(f, userhash="")` | Sync upload |
| `upload_file_catbox_async(f, userhash="")` | Async upload |
| `delete_file_catbox(filenames, userhash)` | Sync delete |
| `delete_file_catbox_async(filenames, userhash)` | Async delete |

---

## ⚠️ Exception Handling

```python
from catbox import CatboxException

try:
    urls = await upload_file_catbox_async("photo.jpg")
except CatboxException as e:
    print(f"Upload failed: {e}")
```

---

## 📦 Requirements

- Python `3.7+`
- `requests` — for sync uploads
- `httpx` — for async uploads

---

## 🌐 Links

| | |
|--|--|
| 👤 **Made by** | [@BadMundaXD](https://t.me/BadMundaXD) |
| 💬 **Support** | [@PBXCHATS](https://t.me/PBXCHATS) |
| 🔔 **Updates** | [@PBX_UPDATE](https://t.me/PBX_UPDATE) |
| 🌍 **Service** | [catbox.moe](https://catbox.moe) |

---

<p align="center">Made with ❤️ by <a href="https://t.me/BadMundaXD">BadMundaXD</a></p>
