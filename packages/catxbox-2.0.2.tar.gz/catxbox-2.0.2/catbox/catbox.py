# -*- coding: utf-8 -*-
"""
Catbox.moe uploader — sync + async
Repo    : https://github.com/Badmunda05/catbox
Author  : Badmunda05 <munda.bad1322@gmail.com>
Service : https://catbox.moe
"""

import os
import requests
from .exceptions import CatboxException

API_URL = "https://catbox.moe/user/api.php"


# ─────────────────────────────────────────────
#  Catbox Class (sync + async methods)
# ─────────────────────────────────────────────

class Catbox:
    """Catbox.moe uploader class — sync & async.

    Example (sync):
        cb = Catbox(userhash="yourhash")  # or Catbox() for anonymous
        urls = cb.upload("photo.jpg")
        print(urls[0])  # https://files.catbox.moe/xxxxxx.jpg

    Example (async):
        cb = Catbox()
        urls = await cb.upload_async("photo.jpg")
    """

    def __init__(self, userhash: str = ""):
        self.userhash = userhash

    # ── SYNC ──────────────────────────────────

    def upload(self, f) -> list:
        """Upload file(s) to catbox.moe. Returns list of URLs."""
        return upload_file_catbox(f, userhash=self.userhash)

    def delete(self, filenames: list) -> str:
        """Delete file(s) from catbox.moe. Requires userhash."""
        return delete_file_catbox(filenames, userhash=self.userhash)

    # ── ASYNC ─────────────────────────────────

    async def upload_async(self, f) -> list:
        """Async upload file(s) to catbox.moe. Returns list of URLs."""
        return await upload_file_catbox_async(f, userhash=self.userhash)

    async def delete_async(self, filenames: list) -> str:
        """Async delete file(s) from catbox.moe. Requires userhash."""
        return await delete_file_catbox_async(filenames, userhash=self.userhash)

    def __repr__(self):
        return f"Catbox(userhash={'set' if self.userhash else 'anonymous'})"


# ─────────────────────────────────────────────
#  Standalone functions (sync)
# ─────────────────────────────────────────────

def upload_file_catbox(f, userhash: str = "") -> list:
    """Upload one or more files to catbox.moe (sync).

    Example:
        urls = upload_file_catbox("photo.jpg")
        print(urls[0])   # https://files.catbox.moe/xxxxxx.jpg
    """
    files_input = [f] if not isinstance(f, (list, tuple)) else list(f)
    urls = []
    for item in files_input:
        if isinstance(item, str):
            filename = os.path.basename(item)
            fobj = open(item, "rb")
            opened = True
        else:
            filename = getattr(item, "name", "upload")
            fobj = item
            opened = False
        try:
            resp = requests.post(
                API_URL,
                data={"reqtype": "fileupload", "userhash": userhash},
                files={"fileToUpload": (filename, fobj)},
                timeout=60,
            )
        finally:
            if opened:
                fobj.close()
        result = resp.text.strip()
        if not result.startswith("https://"):
            raise CatboxException("Upload failed (HTTP {}): {}".format(resp.status_code, result[:200]))
        urls.append(result)
    return urls


def delete_file_catbox(filenames: list, userhash: str) -> str:
    """Delete files from catbox.moe (sync). Requires userhash."""
    resp = requests.post(
        API_URL,
        data={"reqtype": "deletefiles", "userhash": userhash, "files": " ".join(filenames)},
        timeout=30,
    )
    result = resp.text.strip()
    if resp.status_code != 200:
        raise CatboxException("Delete failed (HTTP {}): {}".format(resp.status_code, result[:200]))
    return result


# ─────────────────────────────────────────────
#  Standalone functions (async)
# ─────────────────────────────────────────────

async def upload_file_catbox_async(f, userhash: str = "") -> list:
    """Async upload to catbox.moe. Returns list of direct URLs."""
    try:
        import httpx
    except ImportError:
        raise ImportError("httpx is required: pip install httpx")
    files_input = [f] if not isinstance(f, (list, tuple)) else list(f)
    urls = []
    async with httpx.AsyncClient(timeout=60) as client:
        for item in files_input:
            if isinstance(item, str):
                filename = os.path.basename(item)
                fobj = open(item, "rb")
                opened = True
            else:
                filename = getattr(item, "name", "upload")
                fobj = item
                opened = False
            try:
                resp = await client.post(
                    API_URL,
                    data={"reqtype": "fileupload", "userhash": userhash},
                    files={"fileToUpload": (filename, fobj)},
                )
            finally:
                if opened:
                    fobj.close()
            result = resp.text.strip()
            if not result.startswith("https://"):
                raise CatboxException("Upload failed (HTTP {}): {}".format(resp.status_code, result[:200]))
            urls.append(result)
    return urls


async def delete_file_catbox_async(filenames: list, userhash: str) -> str:
    """Async delete files from catbox.moe. Requires userhash."""
    try:
        import httpx
    except ImportError:
        raise ImportError("httpx is required: pip install httpx")
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            API_URL,
            data={"reqtype": "deletefiles", "userhash": userhash, "files": " ".join(filenames)},
        )
    result = resp.text.strip()
    if resp.status_code != 200:
        raise CatboxException("Delete failed (HTTP {}): {}".format(resp.status_code, result[:200]))
    return result
