# -*- coding: utf-8 -*-
# AUTO-GENERATED — do not edit manually
# Run generate_async_api.py to regenerate
"""
Catbox.moe uploader — ASYNC (auto-generated from catbox.py)
Repo    : https://github.com/Badmunda05/catbox
Author  : Badmunda05 <munda.bad1322@gmail.com>
"""

import os
import httpx
from .exceptions import CatboxException

async def upload_file_catbox_async(f, userhash: str = "") -> list:
    """Async upload to catbox.moe. Returns list of direct URLs.

    Example:
        from catbox.catbox_async import upload_file_catbox_async
        urls = await upload_file_catbox_async("photo.jpg")
        print(urls[0])
    """
    try:
        import httpx
    except ImportError:
        raise ImportError("httpx is required: pip install httpx")
    files_input = [f] if not isinstance(f, (list, tuple)) else list(f)
    urls = []
    async with httpx.AsyncClient(timeout=60) as client:
        for item in files_input:
            if isinstance(item, str):
                filename = os.path.basename(item)
                fobj = open(item, "rb")
                opened = True
            else:
                filename = getattr(item, "name", "upload")
                fobj = item
                opened = False
            try:
                resp = await client.post(
                    "https://catbox.moe/user/api.php",
                    data={"reqtype": "fileupload", "userhash": userhash},
                    files={"fileToUpload": (filename, fobj)},
                )
            finally:
                if opened:
                    fobj.close()
            result = resp.text.strip()
            if not result.startswith("https://"):
                raise CatboxException("Catbox upload failed (HTTP {}): {}".format(resp.status_code, result[:200]))
            urls.append(result)
    return urls

async def delete_file_catbox_async(filenames: list, userhash: str) -> str:
    """Async delete files from catbox.moe. Requires userhash."""
    try:
        import httpx
    except ImportError:
        raise ImportError("httpx is required: pip install httpx")
    async with httpx.AsyncClient(timeout=30) as client:
        resp = await client.post(
            "https://catbox.moe/user/api.php",
            data={"reqtype": "deletefiles", "userhash": userhash, "files": " ".join(filenames)},
        )
    result = resp.text.strip()
    if resp.status_code != 200:
        raise CatboxException("Delete failed (HTTP {}): {}".format(resp.status_code, result[:200]))
    return result
