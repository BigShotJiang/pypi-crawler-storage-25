# -*- coding: utf-8 -*-
"""
Catbox — File uploader powered by catbox.moe
Repo    : https://github.com/Badmunda05/catbox
Author  : Badmunda05 <munda.bad1322@gmail.com>
"""

__author__ = 'Badmunda05'
__email__  = 'munda.bad1322@gmail.com'
__version__ = "2.0.2"

from .catbox import (
    Catbox,
    upload_file_catbox,
    upload_file_catbox_async,
    delete_file_catbox,
    delete_file_catbox_async,
)
from .exceptions import CatboxException
