class CatboxException(Exception):
    pass

class RetryAfterError(CatboxException):
    def __init__(self, retry_after: int):
        self.retry_after = retry_after
        super().__init__(f'Flood control exceeded. Retry in {retry_after} seconds')
