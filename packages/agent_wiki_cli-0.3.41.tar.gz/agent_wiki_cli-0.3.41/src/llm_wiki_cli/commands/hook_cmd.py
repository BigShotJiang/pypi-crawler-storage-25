from __future__ import annotations

import os
import stat
import sys
from pathlib import Path

from ..config import CLI_AGENTS, DEFAULT_WIKI_DIR, IDE_AGENTS, get_agent_config_path, read_config, validate_path
from ..services.paths import shell_quote

# Agents that support headless CLI execution (can be used in post-commit hook)
_CLI_AGENTS = set(CLI_AGENTS)
# Agents that are IDE-only and cannot run headlessly
_UI_ONLY_AGENTS = IDE_AGENTS
HOOK_SIGNATURE = "LLM Wiki"


def _read_agent_config(wiki_dir: str) -> str | None:
    """Read the agent name persisted by `llm-wiki init`."""
    config_path = get_agent_config_path(wiki_dir)
    if config_path.exists():
        config = read_config(wiki_dir)
        return config.get("agent")
    return None


def _build_post_commit(agent: str, wiki_dir: str) -> str:
    quoted_agent = shell_quote(agent)
    quoted_wiki_dir = shell_quote(wiki_dir)
    return f"""#!/bin/sh

# LLM Wiki Auto-Sync Post-Commit Hook
# Triggers the wiki update in the background so it doesn't block the developer

# Skip if this commit was made by the pre-push auto-bump
if [ -n "$LLM_WIKI_AUTO_COMMIT" ]; then
    exit 0
fi

echo "Triggering LLM Wiki subagent sync in the background..."

# Configurable via environment variables (no need to re-install hook)
LLM_WIKI_TIMEOUT="${{LLM_WIKI_TIMEOUT:-300}}"
LLM_WIKI_MAX_DIFF="${{LLM_WIKI_MAX_DIFF:-1000}}"
LLM_WIKI_MAX_PROMPT_BYTES="${{LLM_WIKI_MAX_PROMPT_BYTES:-2000000}}"

# Find the virtual environment if it exists, or run globally
if [ -f ".venv/bin/llm-wiki" ]; then
    CLI=".venv/bin/llm-wiki"
else
    CLI="llm-wiki"
fi

nohup "$CLI" trigger-agent --agent {quoted_agent} --wiki-dir {quoted_wiki_dir} --timeout "$LLM_WIKI_TIMEOUT" --max-diff-lines "$LLM_WIKI_MAX_DIFF" --max-prompt-bytes "$LLM_WIKI_MAX_PROMPT_BYTES" > .git/llm-wiki-sync.log 2>&1 &
"""


def _build_ide_post_commit(wiki_dir: str) -> str:
    quoted_wiki_dir = shell_quote(wiki_dir)
    return f"""#!/bin/sh

# LLM Wiki -- IDE Agent Prompt Helper (Post-Commit Hook)
# Generates a ready-to-paste sync prompt for IDE agents (Copilot, Cursor, etc.)
# The agent cannot run headlessly, so this hook prepares the work for you.

# Skip if this commit was made by the pre-push auto-bump
if [ -n "$LLM_WIKI_AUTO_COMMIT" ]; then
    exit 0
fi

if [ -f ".venv/bin/llm-wiki" ]; then
    CLI=".venv/bin/llm-wiki"
else
    CLI="llm-wiki"
fi

"$CLI" generate-prompt --wiki-dir {quoted_wiki_dir} --output .git/llm-wiki-prompt.txt

echo ""
echo "+--------------------------------------------------------------+"
echo "|  LLM Wiki: paste the sync prompt into your IDE agent chat.  |"
echo "|  File: .git/llm-wiki-prompt.txt                             |"
echo "+--------------------------------------------------------------+"

# Auto-open in VS Code only when explicitly enabled
if [ "${{LLM_WIKI_OPEN_PROMPT:-0}}" = "1" ] && [ "$TERM_PROGRAM" = "vscode" ]; then
    code .git/llm-wiki-prompt.txt 2>/dev/null || true
fi
"""


def _build_validation_pre_commit(wiki_dir: str) -> str:
    quoted_wiki_dir = shell_quote(wiki_dir)
    return f"""#!/bin/sh

# LLM Wiki Strict Validation Pre-Commit Hook
# Opt-in guard for teams that want stale wiki coverage to block commits.

if [ -n "$LLM_WIKI_AUTO_COMMIT" ]; then
    exit 0
fi

if [ -f ".venv/bin/llm-wiki" ]; then
    CLI=".venv/bin/llm-wiki"
else
    CLI="llm-wiki"
fi

"$CLI" lint --strict --wiki-dir {quoted_wiki_dir} --src-dir .
"""




def _install_hook(hooks_dir: Path, name: str, content: str, *, force: bool = False) -> None:
    """Write a hook file and make it executable."""
    hook_path = hooks_dir / name
    if hook_path.exists():
        existing = hook_path.read_text(encoding="utf-8", errors="replace")
        if HOOK_SIGNATURE not in existing and not force:
            print(
                f"Error: {hook_path} already exists and does not look like an LLM Wiki hook.\n"
                "Use --force to replace it intentionally.",
                file=sys.stderr,
            )
            sys.exit(1)
    with open(hook_path, "w", encoding="utf-8") as f:
        f.write(content)
    st = os.stat(hook_path)
    os.chmod(hook_path, st.st_mode | stat.S_IEXEC)
    print(f"  Installed: {hook_path}")


def run(args):
    git_dir = Path(".git")
    if not git_dir.exists():
        print("Error: No .git directory found. Are you in the root of a git repository?")
        sys.exit(1)

    hooks_dir = git_dir / "hooks"
    hooks_dir.mkdir(exist_ok=True)

    wiki_dir = getattr(args, "wiki_dir", DEFAULT_WIKI_DIR)
    validate_path(wiki_dir, "--wiki-dir")

    # Resolve agent: CLI override > config file > fallback
    agent = getattr(args, "agent", None)
    if not agent:
        agent = _read_agent_config(wiki_dir)
        if not agent:
            print(
                f"Warning: No agent config found at .git/.llm-wiki-agent.\n"
                f"Run `llm-wiki init --agent <agent>` first, or pass --agent to this command.\n"
                f"Defaulting to 'claude'."
            )
            agent = "claude"

    # IDE-only agent: install the prompt-generation hook instead of the headless sync hook
    if agent in _UI_ONLY_AGENTS:
        _install_hook(
            hooks_dir, "post-commit", _build_ide_post_commit(wiki_dir),
            force=getattr(args, "force", False),
        )
        if getattr(args, "enable_validation", False):
            _install_hook(
                hooks_dir, "pre-commit", _build_validation_pre_commit(wiki_dir),
                force=getattr(args, "force", False),
            )
        print(f"  Agent: {agent} (IDE mode -- prompt-generation hook)")
        print(
            f"\nIDE sync hook installed. After each commit, a prompt file will be generated at\n"
            f"  .git/llm-wiki-prompt.txt\n"
            f"Paste its contents into your {agent} chat to sync the wiki.\n"
            f"You can also generate it manually at any time:\n"
            f"  llm-wiki generate-prompt"
        )
        print("\nHook installation complete.")
        return

    # CLI agent: install headless auto-sync hook with agent baked in
    _install_hook(
        hooks_dir, "post-commit", _build_post_commit(agent, wiki_dir),
        force=getattr(args, "force", False),
    )
    if getattr(args, "enable_validation", False):
        _install_hook(
            hooks_dir, "pre-commit", _build_validation_pre_commit(wiki_dir),
            force=getattr(args, "force", False),
        )
    print(f"  Agent: {agent}")

    print("\nHook installation complete.")
