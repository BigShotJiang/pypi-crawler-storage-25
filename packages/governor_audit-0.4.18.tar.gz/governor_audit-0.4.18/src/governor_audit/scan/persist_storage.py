"""Sync ``INFORMATION_SCHEMA.TABLE_STORAGE`` + ``SCHEMATA_OPTIONS``
into ``TableStorageMetric``.

Powers the ``storage_billing_optimization`` rule. Audit had no use for
storage data before — the rule was registered but always received an
empty ``_storage_metrics`` list, so it never produced findings.

Mirrors the contract of ``sync_table_columns``: non-fatal, returns 0 on
any BigQuery API error so the surrounding scan can continue. The two
underlying core helpers (``query_table_storage``, ``query_billing_models``)
are independent — if one fails we still process the other and fall back
to ``"LOGICAL"`` for any dataset whose billing model we couldn't read.
"""

from __future__ import annotations

import logging
from collections import Counter
from typing import TYPE_CHECKING

from governor_core.sync.models import TableStorageMetric

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

logger = logging.getLogger("governor_audit.scan.persist_storage")


def fetch_storage(
    *, project_id: str, region: str
) -> tuple[list[dict] | None, dict[str, str]]:
    """Network-only fetch of ``INFORMATION_SCHEMA.TABLE_STORAGE`` +
    ``SCHEMATA_OPTIONS``. Spec 147 Layer 1 split this out of
    ``sync_table_storage`` so the orchestrator can dispatch it in
    parallel with the JOBS_BY_PROJECT and COLUMNS fetches.

    Returns ``(rows, billing_models)``. ``rows`` is ``None`` if the
    TABLE_STORAGE query failed. ``billing_models`` is empty when
    SCHEMATA_OPTIONS failed (rule then defaults every dataset to
    LOGICAL — safe direction).
    """
    try:
        from governor_core.gcp.clients import query_table_storage

        rows: list[dict] | None = query_table_storage(
            project_id=project_id, region=region
        )
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "INFORMATION_SCHEMA.TABLE_STORAGE fetch skipped — "
            "project=%s region=%s error=%s",
            project_id,
            region,
            exc,
        )
        rows = None

    billing_models: dict[str, str] = {}
    try:
        from governor_core.gcp.clients import query_billing_models

        billing_models = query_billing_models(project_id=project_id, region=region)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "INFORMATION_SCHEMA.SCHEMATA_OPTIONS fetch skipped — "
            "project=%s region=%s error=%s — defaulting all datasets to LOGICAL",
            project_id,
            region,
            exc,
        )

    return rows, billing_models


def sync_table_storage(
    *,
    session: Session,
    config_id: str,
    sync_id: str,
    project_id: str,
    region: str,
    rows: list[dict] | None = None,
    billing_models: dict[str, str] | None = None,
) -> int:
    """Pull every ``INFORMATION_SCHEMA.TABLE_STORAGE`` row for
    ``project_id`` in ``region``, look up each dataset's billing model
    from ``SCHEMATA_OPTIONS``, and upsert into ``TableStorageMetric``
    scoped to ``config_id``.

    When ``rows`` and ``billing_models`` are provided (spec 147
    parallel-fetch path), the network calls are skipped and the
    supplied data is persisted directly. Pass ``rows=None`` to retain
    the original synchronous fetch + persist behaviour for direct
    callers / tests.

    Returns the number of metric rows persisted (new + refreshed).
    Any error is caught, logged, and zero is returned — storage data is
    opportunistic, not required, and the JOBS/COLUMNS pipeline must not
    be affected by a storage-side failure.
    """
    if rows is None and billing_models is None:
        rows, billing_models = fetch_storage(project_id=project_id, region=region)
    elif billing_models is None:
        billing_models = {}

    if rows is None:
        return 0

    if not rows:
        logger.info(
            "INFORMATION_SCHEMA.TABLE_STORAGE empty for project=%s region=%s",
            project_id,
            region,
        )
        return 0

    persisted = 0
    billing_distribution: Counter[str] = Counter()
    datasets_seen: set[str] = set()

    for row in rows:
        dataset_name = row["table_schema"]
        table_name = row["table_name"]
        billing_model = billing_models.get(dataset_name, "LOGICAL")
        billing_distribution[billing_model] += 1
        datasets_seen.add(dataset_name)

        existing = (
            session.query(TableStorageMetric)
            .filter(
                TableStorageMetric.config_id == config_id,
                TableStorageMetric.project_id == project_id,
                TableStorageMetric.dataset_name == dataset_name,
                TableStorageMetric.table_name == table_name,
            )
            .first()
        )
        values = {
            "sync_id": sync_id,
            "table_type": row["table_type"],
            "billing_model": billing_model,
            "total_rows": row.get("total_rows"),
            "total_partitions": row.get("total_partitions") or 0,
            "total_logical_bytes": row.get("total_logical_bytes") or 0,
            "active_logical_bytes": row.get("active_logical_bytes") or 0,
            "long_term_logical_bytes": row.get("long_term_logical_bytes") or 0,
            "total_physical_bytes": row.get("total_physical_bytes") or 0,
            "active_physical_bytes": row.get("active_physical_bytes") or 0,
            "long_term_physical_bytes": row.get("long_term_physical_bytes") or 0,
            "time_travel_physical_bytes": row.get("time_travel_physical_bytes") or 0,
            "fail_safe_physical_bytes": row.get("fail_safe_physical_bytes") or 0,
        }
        if existing is not None:
            for key, value in values.items():
                setattr(existing, key, value)
        else:
            session.add(
                TableStorageMetric(
                    config_id=config_id,
                    project_id=project_id,
                    dataset_name=dataset_name,
                    table_name=table_name,
                    **values,
                )
            )
        persisted += 1

    session.flush()
    logger.info(
        "storage sync: %d metric rows persisted across %d datasets "
        "(LOGICAL=%d, PHYSICAL=%d)",
        persisted,
        len(datasets_seen),
        billing_distribution.get("LOGICAL", 0),
        billing_distribution.get("PHYSICAL", 0),
    )
    return persisted


__all__ = ["fetch_storage", "sync_table_storage"]
