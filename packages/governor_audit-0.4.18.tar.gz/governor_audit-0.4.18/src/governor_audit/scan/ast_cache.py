"""Shared sqlglot AST cache for the detection phase.

Audit reuses every ``governor_core`` rule unmodified. Each rule
internally calls ``sqlglot.parse_one(query, dialect="bigquery")`` from
``detect()`` — at enterprise scale (50k jobs × ~8 sqlglot-using
rules) that's hundreds of thousands of parses for what's typically a
few thousand unique queries (recurring dbt models share bodies).

This module monkey-patches ``sqlglot.parse_one`` for the duration of
the detection rule loop with a wrapper that consults a process-local
``functools.lru_cache`` before delegating to the real parser. Cache
key is ``(query_text, dialect)``. On exit the original symbol is
restored, so the patch never escapes the detection phase.

Defensive deepcopy on hit so a rule that mutates its parsed tree
doesn't corrupt the cache for the next rule. Audit of the current
rules in ``governor_core`` (spec 147 task T010) found no mutation,
but the deepcopy is cheap insurance against a future rule.
"""

from __future__ import annotations

import contextlib
import copy
import functools
import logging
from typing import Any, Iterator

logger = logging.getLogger("governor_audit.scan.ast_cache")

# Capacity tuned for ~5k distinct queries per scan; tune via env-var
# in a follow-up if profiling shows ``currsize == maxsize`` regularly.
# Each entry holds a sqlglot Expression tree (typically a few KB), so
# 8k entries is well under 100 MB.
_DEFAULT_CACHE_SIZE = 8192


@contextlib.contextmanager
def patch_sqlglot_during_detection(
    *, cache_size: int = _DEFAULT_CACHE_SIZE
) -> Iterator[dict[str, int]]:
    """Patch ``sqlglot.parse_one`` with a cached wrapper, restore on exit.

    Yields a stats dict the caller can read after the ``with`` block.
    Stats come from ``cache_info()`` so the orchestrator can log the
    hit rate at INFO level (Story 2 acceptance signal).
    """
    import sqlglot

    original_parse_one = sqlglot.parse_one

    @functools.lru_cache(maxsize=cache_size)
    def _cached(query: str, dialect: str | None) -> Any:
        return original_parse_one(query, dialect=dialect)

    def cached_parse_one(
        query: str, *args: Any, dialect: str | None = None, **kwargs: Any
    ) -> Any:
        # Only cache the (query, dialect) call shape rules use today.
        # Any call with extra positional / keyword args bypasses the
        # cache and delegates straight to the original (defensive —
        # avoid serving wrong cache hits on calls we didn't anticipate).
        if args or kwargs:
            return original_parse_one(query, *args, dialect=dialect, **kwargs)
        cached_tree = _cached(query, dialect)
        # Defensive deepcopy so rules that mutate the AST don't corrupt
        # the cache for subsequent rules. No current rule mutates, but
        # the cost is negligible vs re-parsing.
        return copy.deepcopy(cached_tree)

    sqlglot.parse_one = cached_parse_one  # type: ignore[assignment]
    stats: dict[str, int] = {"hits": 0, "misses": 0, "currsize": 0}
    try:
        yield stats
    finally:
        info = _cached.cache_info()
        stats["hits"] = info.hits
        stats["misses"] = info.misses
        stats["currsize"] = info.currsize
        sqlglot.parse_one = original_parse_one
        total_calls = info.hits + info.misses
        hit_rate = (info.hits / total_calls * 100) if total_calls else 0.0
        logger.info(
            "AST cache: %d hits, %d misses, %d entries (hit rate %.1f%%)",
            info.hits,
            info.misses,
            info.currsize,
            hit_rate,
        )


__all__ = ["patch_sqlglot_during_detection"]
