"""Phase-by-phase wall-clock timing for the scan orchestrator.

Tiny zero-dependency context manager. Records ``perf_counter`` deltas
keyed by phase name and emits a single summary log line at the end of
``run_scan``. The line is INFO-level so it shows up in stdout / log
forwarders without enabling DEBUG, which is what spec 147 Story 3
asks for.

Format (single line):

    scan timing: jobs_fetch=45.2s columns_fetch=287.1s storage_fetch=12.4s persist=8.7s detection=312.5s opportunities_persist=18.2s total=684.1s

The timer is robust to exceptions inside a ``phase()`` block — the
partial duration is still recorded and the eventual ``emit_summary``
runs from a ``finally`` in the orchestrator.
"""

from __future__ import annotations

import contextlib
import logging
import time
from typing import Iterator

logger = logging.getLogger("governor_audit.scan.timing")


class PhaseTimer:
    """Accumulates wall-clock durations per named phase.

    Same-name phases sum (e.g. two ``persist`` blocks contribute to a
    single ``persist`` total) so the orchestrator can decompose any
    step further without changing the summary line shape.
    """

    def __init__(self) -> None:
        self.phases: dict[str, float] = {}
        self._started_at = time.perf_counter()

    @contextlib.contextmanager
    def phase(self, name: str) -> Iterator[None]:
        """Time a single phase. Records the duration even if the body raises."""
        t0 = time.perf_counter()
        try:
            yield
        finally:
            self.phases[name] = self.phases.get(name, 0.0) + (
                time.perf_counter() - t0
            )

    def elapsed_total(self) -> float:
        """Wall-clock time since the timer was constructed."""
        return time.perf_counter() - self._started_at

    def emit_summary(self) -> None:
        """Log a single INFO line with every recorded phase + total."""
        total = self.elapsed_total()
        if not self.phases:
            logger.info("scan timing: total=%.1fs", total)
            return
        parts = " ".join(f"{name}={dt:.1f}s" for name, dt in self.phases.items())
        logger.info("scan timing: %s total=%.1fs", parts, total)


__all__ = ["PhaseTimer"]
