"""Sync ``INFORMATION_SCHEMA.COLUMNS`` for the project into
``TableColumnMetadata``.

Powers the ``expand_select_star`` deterministic template (and the
existing ``make_column_lookup`` cluster_by/partition_by validators).
Audit had no use for column metadata before — every rule operated on
SQL alone — but the SELECT * → explicit-column-list rewrite needs to
know what columns each table actually has.

Failure here is non-fatal: if the BigQuery API call fails or the user's
service account lacks ``bigquery.tables.list`` permission, we log a
warning and proceed. The select_star template will simply return None
and the UI falls back to plain text guidance.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from governor_core.sync.models import TableColumnMetadata

if TYPE_CHECKING:
    from sqlalchemy.orm import Session

logger = logging.getLogger("governor_audit.scan.persist_columns")


def fetch_columns(*, project_id: str, region: str) -> list[dict] | None:
    """Network-only fetch of ``INFORMATION_SCHEMA.COLUMNS``. Spec 147
    Layer 1 split this out of ``sync_table_columns`` so the orchestrator
    can dispatch it in parallel with the JOBS_BY_PROJECT and
    TABLE_STORAGE fetches.

    Returns the row list on success, ``None`` on any failure (logged).
    The caller passes the returned list (or ``None``) into
    ``sync_table_columns(rows=...)`` for the persist phase.
    """
    try:
        from governor_core.gcp.clients import query_table_columns

        return query_table_columns(project_id=project_id, region=region)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "INFORMATION_SCHEMA.COLUMNS fetch skipped — "
            "project=%s region=%s error=%s",
            project_id,
            region,
            exc,
        )
        return None


def sync_table_columns(
    *,
    session: Session,
    config_id: str,
    sync_id: str,
    project_id: str,
    region: str,
    rows: list[dict] | None = None,
) -> int:
    """Pull every ``INFORMATION_SCHEMA.COLUMNS`` row for ``project_id``
    in ``region`` and upsert into ``TableColumnMetadata`` scoped to
    ``config_id``.

    When ``rows`` is provided (spec 147 parallel-fetch path), the
    network call is skipped and the supplied rows are persisted
    directly. Pass ``rows=None`` to retain the original synchronous
    fetch + persist behaviour for direct callers / tests.

    Returns the number of column rows persisted (new + refreshed).
    Any error is caught, logged, and zero is returned — column metadata
    is opportunistic, not required.
    """
    if rows is None:
        rows = fetch_columns(project_id=project_id, region=region)
        if rows is None:
            return 0

    if not rows:
        logger.info(
            "INFORMATION_SCHEMA.COLUMNS empty for project=%s region=%s",
            project_id,
            region,
        )
        return 0

    # Upsert by the existing unique constraint
    # (config_id, project_id, dataset_name, table_name, column_name).
    # SQLite doesn't have ON CONFLICT for the SQLAlchemy ORM here, so
    # we look up + update / insert per row. The dataset has hundreds to
    # low thousands of rows in typical projects — fine for one pass.
    persisted = 0
    for row in rows:
        dataset_name = row["dataset_name"]
        table_name = row["table_name"]
        column_name = row["column_name"]
        existing = (
            session.query(TableColumnMetadata)
            .filter(
                TableColumnMetadata.config_id == config_id,
                TableColumnMetadata.project_id == project_id,
                TableColumnMetadata.dataset_name == dataset_name,
                TableColumnMetadata.table_name == table_name,
                TableColumnMetadata.column_name == column_name,
            )
            .first()
        )
        if existing is not None:
            existing.data_type = row["data_type"]
            existing.ordinal_position = row["ordinal_position"]
            existing.sync_id = sync_id
        else:
            session.add(
                TableColumnMetadata(
                    config_id=config_id,
                    sync_id=sync_id,
                    project_id=project_id,
                    dataset_name=dataset_name,
                    table_name=table_name,
                    column_name=column_name,
                    data_type=row["data_type"],
                    ordinal_position=row["ordinal_position"],
                )
            )
        persisted += 1

    session.flush()
    logger.info(
        "INFORMATION_SCHEMA.COLUMNS synced: %d rows for project=%s region=%s",
        persisted,
        project_id,
        region,
    )
    return persisted


__all__ = ["fetch_columns", "sync_table_columns"]
