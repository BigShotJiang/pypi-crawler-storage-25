"""Architectural enforcement for dotscope."""
