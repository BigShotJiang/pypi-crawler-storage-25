"""ux module boundaries."""
