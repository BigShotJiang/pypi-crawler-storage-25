"""ALab local experiment workbench."""

__all__ = ["__version__"]

__version__ = "0.1.1"
