"""Tests for neuron reordering utilities."""

import torch
import torch.nn as nn
from ladam import compute_neuron_order, reorder_linear_layer


def test_compute_order_identity_small():
    """Small tensors (<=4 neurons) should return identity order."""
    x = torch.randn(100, 3)
    order = compute_neuron_order(x)
    assert order == [0, 1, 2]


def test_compute_order_valid_permutation():
    """Output should be a valid permutation of [0, n)."""
    x = torch.randn(200, 32)
    order = compute_neuron_order(x)
    assert sorted(order) == list(range(32))
    assert len(order) == 32


def test_compute_order_correlated_adjacent():
    """Highly correlated neurons should end up nearby in the order."""
    torch.manual_seed(42)
    n_neurons = 16
    n_samples = 500

    # Create activations where neurons 0,1,2 are highly correlated
    base = torch.randn(n_samples, 1)
    noise = torch.randn(n_samples, n_neurons) * 0.1
    activations = noise.clone()
    activations[:, 0] = base.squeeze() + noise[:, 0]
    activations[:, 1] = base.squeeze() + noise[:, 1]
    activations[:, 2] = base.squeeze() + noise[:, 2]

    order = compute_neuron_order(activations)

    # Find positions of neurons 0, 1, 2 in the order
    positions = [order.index(i) for i in range(3)]
    # They should be within 3 positions of each other
    spread = max(positions) - min(positions)
    assert spread <= 4, f"Correlated neurons too far apart: positions {positions}"


def test_reorder_preserves_function():
    """Reordering should not change the network's output."""
    torch.manual_seed(42)

    fc1 = nn.Linear(10, 32)
    fc2 = nn.Linear(32, 5)

    x = torch.randn(8, 10)

    # Compute output before reorder
    with torch.no_grad():
        h = torch.relu(fc1(x))
        out_before = fc2(h)

    # Apply random permutation
    order = list(range(32))
    import random
    random.seed(42)
    random.shuffle(order)

    reorder_linear_layer(fc1, fc2, order)

    # Compute output after reorder
    with torch.no_grad():
        h = torch.relu(fc1(x))
        out_after = fc2(h)

    assert torch.allclose(out_before, out_after, atol=1e-5), \
        f"Max diff: {(out_before - out_after).abs().max().item()}"


def test_reorder_changes_weights():
    """Reordering should actually permute the weight matrices."""
    fc1 = nn.Linear(8, 16)
    fc2 = nn.Linear(16, 4)

    w1_before = fc1.weight.data.clone()

    # Swap first two neurons
    order = list(range(16))
    order[0], order[1] = order[1], order[0]

    reorder_linear_layer(fc1, fc2, order)

    # First two rows should be swapped
    assert torch.allclose(fc1.weight.data[0], w1_before[1])
    assert torch.allclose(fc1.weight.data[1], w1_before[0])


def test_compute_order_type_validation():
    """Should raise TypeError for non-tensor input."""
    try:
        compute_neuron_order([[1, 2], [3, 4]])
        assert False, "Should have raised TypeError"
    except TypeError:
        pass


def test_reorder_type_validation():
    """Should raise TypeError for non-Linear layers."""
    try:
        reorder_linear_layer(nn.Conv2d(3, 16, 3), nn.Linear(16, 4), [0, 1])
        assert False, "Should have raised TypeError"
    except TypeError:
        pass
