"""Tests for WaveNorm, WaveNormDamped, and ChiNorm."""

import torch
from ladam import WaveNorm, WaveNormDamped, ChiNorm


# ---- WaveNorm ----

def test_wavenorm_2d_shape():
    """WaveNorm should preserve shape for 2D (MLP) inputs."""
    norm = WaveNorm(64)
    x = torch.randn(32, 64)
    out = norm(x)
    assert out.shape == (32, 64)


def test_wavenorm_4d_shape():
    """WaveNorm should preserve shape for 4D (CNN) inputs."""
    norm = WaveNorm(16)
    x = torch.randn(8, 16, 7, 7)
    out = norm(x)
    assert out.shape == (8, 16, 7, 7)


def test_wavenorm_gradient_flow():
    """Gradients should flow through WaveNorm."""
    norm = WaveNorm(32)
    x = torch.randn(16, 32, requires_grad=True)
    out = norm(x)
    loss = out.sum()
    loss.backward()
    assert x.grad is not None
    assert x.grad.shape == (16, 32)


def test_wavenorm_learnable_params():
    """WaveNorm should have learnable dt, c, chi, gamma, beta."""
    norm = WaveNorm(8)
    param_names = {n for n, _ in norm.named_parameters()}
    assert {'dt', 'c', 'chi', 'gamma', 'beta'} == param_names


def test_wavenorm_not_identity():
    """With n_steps > 0, output should differ from input."""
    norm = WaveNorm(16, n_steps=3)
    x = torch.randn(8, 16)
    out = norm(x)
    assert not torch.allclose(x, out, atol=1e-4)


# ---- WaveNormDamped ----

def test_wavenorm_damped_2d_shape():
    """WaveNormDamped should preserve shape for 2D inputs."""
    norm = WaveNormDamped(64)
    x = torch.randn(32, 64)
    out = norm(x)
    assert out.shape == (32, 64)


def test_wavenorm_damped_4d_shape():
    """WaveNormDamped should preserve shape for 4D inputs."""
    norm = WaveNormDamped(16)
    x = torch.randn(8, 16, 7, 7)
    out = norm(x)
    assert out.shape == (8, 16, 7, 7)


def test_wavenorm_damped_gradient_flow():
    """Gradients should flow through WaveNormDamped."""
    norm = WaveNormDamped(32)
    x = torch.randn(16, 32, requires_grad=True)
    out = norm(x)
    loss = out.sum()
    loss.backward()
    assert x.grad is not None


def test_wavenorm_damped_has_damping():
    """WaveNormDamped should have damping_raw parameter."""
    norm = WaveNormDamped(8)
    param_names = {n for n, _ in norm.named_parameters()}
    assert 'damping_raw' in param_names


def test_wavenorm_damped_damping_range():
    """Damping (after sigmoid) should be in [0, 1]."""
    norm = WaveNormDamped(16, init_damping=0.3)
    damping = torch.sigmoid(norm.damping_raw)
    assert (damping >= 0).all()
    assert (damping <= 1).all()
    # Check initial value is approximately 0.3
    assert abs(damping.mean().item() - 0.3) < 0.01


# ---- ChiNorm ----

def test_chinorm_2d_shape():
    """ChiNorm should preserve shape for 2D inputs."""
    norm = ChiNorm(64)
    x = torch.randn(32, 64)
    out = norm(x)
    assert out.shape == (32, 64)


def test_chinorm_4d_shape():
    """ChiNorm should preserve shape for 4D inputs."""
    norm = ChiNorm(16)
    x = torch.randn(8, 16, 7, 7)
    out = norm(x)
    assert out.shape == (8, 16, 7, 7)


def test_chinorm_gradient_flow():
    """Gradients should flow through ChiNorm."""
    norm = ChiNorm(32)
    x = torch.randn(16, 32, requires_grad=True)
    out = norm(x)
    loss = out.sum()
    loss.backward()
    assert x.grad is not None


def test_chinorm_running_energy_updates():
    """Running energy should update during training."""
    norm = ChiNorm(8)
    norm.train()

    x = torch.randn(16, 8) * 5.0  # High energy
    norm(x)

    assert norm.running_energy.sum().item() > 0
    assert norm.num_batches_tracked.item() == 1


def test_chinorm_eval_uses_running_stats():
    """In eval mode, ChiNorm should use running stats, not batch stats."""
    norm = ChiNorm(8)
    norm.train()

    # Train with high energy
    x_train = torch.randn(64, 8) * 10.0
    for _ in range(10):
        norm(x_train)

    running_before = norm.running_energy.clone()

    # Switch to eval — running stats should not change
    norm.eval()
    x_test = torch.randn(16, 8) * 0.1
    norm(x_test)

    assert torch.allclose(norm.running_energy, running_before)
