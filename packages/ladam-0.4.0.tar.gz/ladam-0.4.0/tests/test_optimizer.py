"""Tests for LAdam optimizer."""

import pytest
import torch
import torch.nn as nn
from ladam import LAdam, suggest_c2


class SimpleMLP(nn.Module):
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(20, 64)
        self.fc2 = nn.Linear(64, 64)
        self.fc3 = nn.Linear(64, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return self.fc3(x)


@pytest.fixture
def model():
    return SimpleMLP()


@pytest.fixture
def data():
    torch.manual_seed(42)
    X = torch.randn(100, 20)
    y = torch.randn(100, 1)
    return X, y


def test_basic_step(model, data):
    """LAdam can perform a basic optimization step."""
    X, y = data
    opt = LAdam(model.parameters(), lr=1e-3, c2=1e-4)
    loss_fn = nn.MSELoss()

    loss_before = loss_fn(model(X), y).item()
    for _ in range(10):
        opt.zero_grad()
        loss = loss_fn(model(X), y)
        loss.backward()
        opt.step()
    loss_after = loss_fn(model(X), y).item()

    assert loss_after < loss_before, "Loss should decrease after optimization"


def test_c2_zero_equals_adam(model, data):
    """With c2=0, LAdam should behave identically to Adam."""
    X, y = data
    loss_fn = nn.MSELoss()

    # LAdam with c2=0
    torch.manual_seed(0)
    m1 = SimpleMLP()
    opt1 = LAdam(m1.parameters(), lr=1e-3, c2=0.0)
    for _ in range(5):
        opt1.zero_grad()
        loss_fn(m1(X), y).backward()
        opt1.step()

    # Standard Adam
    torch.manual_seed(0)
    m2 = SimpleMLP()
    opt2 = torch.optim.Adam(m2.parameters(), lr=1e-3)
    for _ in range(5):
        opt2.zero_grad()
        loss_fn(m2(X), y).backward()
        opt2.step()

    for p1, p2 in zip(m1.parameters(), m2.parameters()):
        assert torch.allclose(p1, p2, atol=1e-6), \
            "c2=0 LAdam should match standard Adam"


def test_all_modes(model, data):
    """All three modes should run without error and reduce loss."""
    X, y = data
    loss_fn = nn.MSELoss()

    for mode in ['variance_lap', 'update_lap', 'weight_lap']:
        torch.manual_seed(42)
        m = SimpleMLP()
        opt = LAdam(m.parameters(), lr=1e-3, c2=1e-4, mode=mode)

        loss_before = loss_fn(m(X), y).item()
        for _ in range(20):
            opt.zero_grad()
            loss_fn(m(X), y).backward()
            opt.step()
        loss_after = loss_fn(m(X), y).item()

        assert loss_after < loss_before, f"Mode '{mode}' should reduce loss"


def test_invalid_params():
    """Invalid parameters should raise ValueError."""
    m = SimpleMLP()
    with pytest.raises(ValueError):
        LAdam(m.parameters(), lr=-1)
    with pytest.raises(ValueError):
        LAdam(m.parameters(), c2=-1)
    with pytest.raises(ValueError):
        LAdam(m.parameters(), mode='invalid')
    with pytest.raises(ValueError):
        LAdam(m.parameters(), betas=(1.5, 0.999))


def test_suggest_c2():
    """Architecture-specific c2 suggestions."""
    assert suggest_c2('pinn') == 1e-5
    assert suggest_c2('transformer') == 1e-4
    assert suggest_c2('cnn') == 0.0
    assert suggest_c2('auto') == 1e-4
    with pytest.raises(ValueError):
        suggest_c2('unknown_arch')


def test_param_groups(model, data):
    """Per-group c2 values should work."""
    X, y = data
    loss_fn = nn.MSELoss()

    opt = LAdam([
        {'params': model.fc1.parameters(), 'c2': 1e-4},
        {'params': model.fc2.parameters(), 'c2': 1e-5},
        {'params': model.fc3.parameters(), 'c2': 0.0},
    ], lr=1e-3)

    for _ in range(10):
        opt.zero_grad()
        loss_fn(model(X), y).backward()
        opt.step()


def test_gpu_if_available(data):
    """LAdam should work on GPU if available."""
    if not torch.cuda.is_available():
        pytest.skip("CUDA not available")

    X, y = data
    X, y = X.cuda(), y.cuda()
    m = SimpleMLP().cuda()
    opt = LAdam(m.parameters(), lr=1e-3, c2=1e-4)
    loss_fn = nn.MSELoss()

    for _ in range(5):
        opt.zero_grad()
        loss_fn(m(X), y).backward()
        opt.step()


def test_with_weight_decay(model, data):
    """Weight decay should work alongside Laplacian."""
    X, y = data
    opt = LAdam(model.parameters(), lr=1e-3, c2=1e-4, weight_decay=0.01)
    loss_fn = nn.MSELoss()

    for _ in range(10):
        opt.zero_grad()
        loss_fn(model(X), y).backward()
        opt.step()


def test_closure(model, data):
    """Closure-based step should work (for LBFGS-style usage)."""
    X, y = data
    opt = LAdam(model.parameters(), lr=1e-3, c2=1e-4)
    loss_fn = nn.MSELoss()

    def closure():
        opt.zero_grad()
        loss = loss_fn(model(X), y)
        loss.backward()
        return loss

    loss = opt.step(closure)
    assert loss is not None
