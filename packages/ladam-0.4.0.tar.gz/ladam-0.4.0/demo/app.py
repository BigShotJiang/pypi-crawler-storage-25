"""
LAdam Interactive Demo - Hugging Face Spaces
=============================================
Live comparison of LAdam vs Adam on toy training tasks.
Deploy to HF Spaces: https://huggingface.co/spaces/gpartin/ladam-demo
"""

import gradio as gr
import torch
import torch.nn as nn
import numpy as np
import time

# ---------------------------------------------------------------------------
# We vendor the optimizer inline so the Space works without installing ladam
# from PyPI (HF Spaces can be slow to install custom packages).
# For real usage: `pip install ladam` and `from ladam import LAdam`
# ---------------------------------------------------------------------------

import torch.nn.functional as F


class LAdam(torch.optim.Optimizer):
    """Minimal LAdam for the demo (production version: pip install ladam)."""

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, c2=1e-4):
        defaults = dict(lr=lr, betas=betas, eps=eps,
                        weight_decay=weight_decay, c2=c2)
        super().__init__(params, defaults)
        self._lap_kernels = {}

    def _get_kernel(self, shape, device):
        key = (shape, device)
        if key not in self._lap_kernels:
            k = torch.tensor([[0, 1, 0], [1, -4, 1], [0, 1, 0]],
                             dtype=torch.float32, device=device).reshape(1, 1, 3, 3)
            self._lap_kernels[key] = k
        return self._lap_kernels[key]

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()
        for group in self.param_groups:
            lr = group['lr']
            b1, b2 = group['betas']
            eps = group['eps']
            wd = group['weight_decay']
            c2 = group['c2']
            for p in group['params']:
                if p.grad is None:
                    continue
                g = p.grad
                if wd != 0:
                    g = g.add(p, alpha=wd)
                state = self.state[p]
                if len(state) == 0:
                    state['step'] = 0
                    state['m'] = torch.zeros_like(p)
                    state['v'] = torch.zeros_like(p)
                state['step'] += 1
                m, v = state['m'], state['v']
                m.mul_(b1).add_(g, alpha=1 - b1)
                v.mul_(b2).addcmul_(g, g, value=1 - b2)
                bc1 = 1 - b1 ** state['step']
                bc2 = 1 - b2 ** state['step']
                m_hat = m / bc1
                v_hat = v / bc2
                # Laplacian smoothing on v_hat
                if c2 > 0 and v_hat.dim() >= 2 and v_hat.shape[-1] >= 3 and v_hat.shape[-2] >= 3:
                    orig = v_hat.shape
                    v2d = v_hat.reshape(1, 1, orig[-2], orig[-1])
                    kernel = self._get_kernel(v2d.shape, v2d.device)
                    lap = F.conv2d(F.pad(v2d, (1, 1, 1, 1), mode='circular'), kernel)
                    v_hat = (v_hat + c2 * lap.reshape(orig)).clamp_(min=0)
                p.addcdiv_(m_hat, v_hat.sqrt().add_(eps), value=-lr)
        return loss


# ---------------------------------------------------------------------------
# Training tasks
# ---------------------------------------------------------------------------

def make_pinn_data(n=500, device='cpu'):
    """1D wave equation: u(x,t) = sin(pi*x)*cos(pi*t), domain [0,1]x[0,1]."""
    x = torch.rand(n, 1, device=device)
    t = torch.rand(n, 1, device=device)
    u_true = torch.sin(np.pi * x) * torch.cos(np.pi * t)
    return torch.cat([x, t], dim=1), u_true


def make_classification_data(n=2000, device='cpu'):
    """Spiral dataset (2 classes)."""
    theta = torch.linspace(0, 4 * np.pi, n // 2, device=device)
    r = torch.linspace(0.2, 1.0, n // 2, device=device)

    noise = torch.randn(n // 2, device=device) * 0.08
    x1 = torch.stack([r * torch.cos(theta) + noise,
                       r * torch.sin(theta) + noise], dim=1)
    noise = torch.randn(n // 2, device=device) * 0.08
    x2 = torch.stack([r * torch.cos(theta + np.pi) + noise,
                       r * torch.sin(theta + np.pi) + noise], dim=1)

    X = torch.cat([x1, x2], dim=0)
    y = torch.cat([torch.zeros(n // 2, device=device),
                    torch.ones(n // 2, device=device)]).long()

    # Shuffle
    perm = torch.randperm(n, device=device)
    return X[perm], y[perm]


def make_rosenbrock():
    """Rosenbrock function: f(x,y) = (1-x)^2 + 100*(y-x^2)^2."""
    x = torch.tensor([-1.5, -1.0], requires_grad=True)
    return x


class SmallMLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, hidden), nn.Tanh(),
            nn.Linear(hidden, out_dim),
        )

    def forward(self, x):
        return self.net(x)


# ---------------------------------------------------------------------------
# Core training functions
# ---------------------------------------------------------------------------

def train_pinn(lr, c2, steps, seed):
    """Train a PINN on 1D wave equation, return loss curves."""
    torch.manual_seed(seed)
    X, u_true = make_pinn_data(500)

    results = {}
    for name, opt_cls, opt_kw in [
        ("Adam", torch.optim.Adam, {}),
        ("LAdam", LAdam, {"c2": c2}),
    ]:
        torch.manual_seed(seed)
        model = SmallMLP(2, 128, 1)
        opt = opt_cls(model.parameters(), lr=lr, **opt_kw)
        losses = []
        for step in range(steps):
            pred = model(X)
            loss = F.mse_loss(pred, u_true)
            loss.backward()
            opt.step()
            opt.zero_grad()
            if step % max(1, steps // 200) == 0:
                losses.append(loss.item())
        results[name] = losses
    return results


def train_spiral(lr, c2, steps, seed):
    """Train on spiral classification, return loss + accuracy curves."""
    torch.manual_seed(seed)
    X, y = make_classification_data(2000)

    results = {}
    for name, opt_cls, opt_kw in [
        ("Adam", torch.optim.Adam, {}),
        ("LAdam", LAdam, {"c2": c2}),
    ]:
        torch.manual_seed(seed)
        model = SmallMLP(2, 64, 2)
        opt = opt_cls(model.parameters(), lr=lr, **opt_kw)
        losses, accs = [], []
        for step in range(steps):
            logits = model(X)
            loss = F.cross_entropy(logits, y)
            loss.backward()
            opt.step()
            opt.zero_grad()
            if step % max(1, steps // 200) == 0:
                losses.append(loss.item())
                acc = (logits.argmax(1) == y).float().mean().item() * 100
                accs.append(acc)
        results[name] = {"loss": losses, "acc": accs}
    return results


def train_rosenbrock(lr, c2, steps, seed):
    """Optimize Rosenbrock function, return trajectory + loss."""
    results = {}
    for name, opt_cls, opt_kw in [
        ("Adam", torch.optim.Adam, {}),
        ("LAdam", LAdam, {"c2": c2}),
    ]:
        torch.manual_seed(seed)
        x = torch.tensor([-1.5, -1.0], requires_grad=True)
        opt = opt_cls([x], lr=lr, **opt_kw)
        losses, traj = [], []
        for step in range(steps):
            f = (1 - x[0])**2 + 100 * (x[1] - x[0]**2)**2
            f.backward()
            opt.step()
            opt.zero_grad()
            if step % max(1, steps // 200) == 0:
                losses.append(f.item())
                traj.append(x.detach().clone().numpy().tolist())
        results[name] = {"loss": losses, "traj": traj}
    return results


# ---------------------------------------------------------------------------
# Gradio interface
# ---------------------------------------------------------------------------

def run_comparison(task, lr, c2, steps, seed):
    """Main entry point for the Gradio interface."""
    lr = float(lr)
    c2 = float(c2)
    steps = int(steps)
    seed = int(seed)

    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    if task == "PINN (Wave Equation)":
        results = train_pinn(lr, c2, steps, seed)
        fig, ax = plt.subplots(1, 1, figsize=(8, 5))
        for name, losses in results.items():
            xs = np.linspace(0, steps, len(losses))
            ax.semilogy(xs, losses, label=name, linewidth=2)
        ax.set_xlabel("Step")
        ax.set_ylabel("MSE Loss (log)")
        ax.set_title("PINN: Wave Equation u_tt = c^2 u_xx")
        ax.legend()
        ax.grid(True, alpha=0.3)

        adam_final = results["Adam"][-1]
        ladam_final = results["LAdam"][-1]
        delta = (ladam_final - adam_final) / adam_final * 100
        summary = (f"**Final MSE**: Adam = {adam_final:.6f}, "
                   f"LAdam = {ladam_final:.6f} "
                   f"(**{delta:+.1f}%**)")
        plt.tight_layout()
        return fig, summary

    elif task == "Spiral Classification":
        results = train_spiral(lr, c2, steps, seed)
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

        for name, data in results.items():
            xs = np.linspace(0, steps, len(data["loss"]))
            ax1.semilogy(xs, data["loss"], label=name, linewidth=2)
            ax2.plot(xs, data["acc"], label=name, linewidth=2)

        ax1.set_xlabel("Step"); ax1.set_ylabel("Loss (log)")
        ax1.set_title("Training Loss"); ax1.legend(); ax1.grid(True, alpha=0.3)
        ax2.set_xlabel("Step"); ax2.set_ylabel("Accuracy (%)")
        ax2.set_title("Training Accuracy"); ax2.legend(); ax2.grid(True, alpha=0.3)

        adam_acc = results["Adam"]["acc"][-1]
        ladam_acc = results["LAdam"]["acc"][-1]
        delta = ladam_acc - adam_acc
        summary = (f"**Final Accuracy**: Adam = {adam_acc:.1f}%, "
                   f"LAdam = {ladam_acc:.1f}% "
                   f"(**{delta:+.1f}pp**)")
        plt.tight_layout()
        return fig, summary

    elif task == "Rosenbrock Optimization":
        results = train_rosenbrock(lr, c2, steps, seed)
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

        for name, data in results.items():
            xs = np.linspace(0, steps, len(data["loss"]))
            ax1.semilogy(xs, data["loss"], label=name, linewidth=2)

        ax1.set_xlabel("Step"); ax1.set_ylabel("f(x,y) (log)")
        ax1.set_title("Rosenbrock Loss"); ax1.legend(); ax1.grid(True, alpha=0.3)

        # Contour plot
        xg = np.linspace(-2, 2, 100)
        yg = np.linspace(-2, 2, 100)
        Xg, Yg = np.meshgrid(xg, yg)
        Zg = (1 - Xg)**2 + 100 * (Yg - Xg**2)**2
        ax2.contour(Xg, Yg, np.log10(Zg + 1), levels=20, cmap='viridis', alpha=0.5)
        ax2.plot(1, 1, 'r*', markersize=15, label='Minimum')

        for name, data in results.items():
            traj = np.array(data["traj"])
            ax2.plot(traj[:, 0], traj[:, 1], '-o', markersize=1, linewidth=1.5, label=name)

        ax2.set_xlabel("x"); ax2.set_ylabel("y")
        ax2.set_title("Optimization Trajectory"); ax2.legend()
        ax2.set_xlim(-2, 2); ax2.set_ylim(-2, 2)

        adam_final = results["Adam"]["loss"][-1]
        ladam_final = results["LAdam"]["loss"][-1]
        summary = (f"**Final f(x,y)**: Adam = {adam_final:.6f}, "
                   f"LAdam = {ladam_final:.6f}")
        plt.tight_layout()
        return fig, summary


# Build the Gradio app
with gr.Blocks(
    title="LAdam Demo",
    theme=gr.themes.Soft(),
) as demo:
    gr.Markdown("""
    # LAdam: Laplacian Adam Optimizer

    **Live comparison of LAdam vs Adam** on toy training tasks.
    LAdam adds discrete Laplacian regularization to Adam's variance estimate,
    coupling neighboring weight learning rates.

    `pip install ladam` | [GitHub](https://github.com/gpartin/ladam) | [PyPI](https://pypi.org/project/ladam/)
    """)

    with gr.Row():
        with gr.Column(scale=1):
            task = gr.Dropdown(
                choices=["PINN (Wave Equation)", "Spiral Classification",
                         "Rosenbrock Optimization"],
                value="PINN (Wave Equation)",
                label="Task",
            )
            lr = gr.Number(value=1e-3, label="Learning Rate")
            c2 = gr.Number(value=1e-4, label="LAdam c2 (coupling strength)")
            steps = gr.Slider(100, 5000, value=2000, step=100, label="Training Steps")
            seed = gr.Number(value=42, label="Random Seed", precision=0)
            run_btn = gr.Button("Run Comparison", variant="primary")

        with gr.Column(scale=2):
            plot = gr.Plot(label="Training Curves")
            summary = gr.Markdown(label="Results")

    run_btn.click(
        fn=run_comparison,
        inputs=[task, lr, c2, steps, seed],
        outputs=[plot, summary],
    )

    gr.Markdown("""
    ---
    ### Tips
    - **PINN**: Try c2=1e-5 for best results (gentle coupling on physics-structured weights)
    - **Spiral**: Try c2=1e-4 (default) -- LAdam's Laplacian helps the hidden layers
    - **Rosenbrock**: 2D optimization -- demonstrates the Laplacian on tiny parameter tensors

    ### When to use LAdam
    LAdam excels on **PINNs**, **transformers**, and **MLPs with neuron reordering**.
    For LLMs, diffusion models, and RL, use standard Adam.

    *Built by [Greg Partin](https://github.com/gpartin) | MIT License*
    """)


if __name__ == "__main__":
    demo.launch()
