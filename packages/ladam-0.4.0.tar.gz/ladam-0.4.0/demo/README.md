---
title: LAdam Demo
emoji: "⚡"
colorFrom: blue
colorTo: purple
sdk: gradio
sdk_version: "5.0"
app_file: app.py
pinned: false
license: mit
---

# LAdam: Laplacian Adam Optimizer Demo

Live comparison of LAdam vs Adam on toy training tasks.

**LAdam** adds discrete Laplacian regularization to Adam's variance estimate (v_t),
coupling neighboring weight learning rates for spatially-smooth optimization.

- [PyPI](https://pypi.org/project/ladam/)
- [GitHub](https://github.com/gpartin/ladam)
- [Paper](https://github.com/gpartin/ladam#citation)
