"""
LAdam Normalization Layers — Physics-inspired alternatives to BatchNorm.

Three normalization approaches based on Lattice Field Medium wave dynamics:

- **WaveNorm**: Leapfrog wave evolution as normalization (GOV-01 dynamics)
- **WaveNormDamped**: WaveNorm with learnable per-feature damping
- **ChiNorm**: Adaptive gain from GOV-03 chi-energy coupling
"""

import math

import torch
import torch.nn as nn


class WaveNorm(nn.Module):
    """
    Wave-equation normalization via leapfrog evolution.

    Normalizes activations by evolving them through a few steps of the
    discrete wave equation: E'' = c^2 * laplacian(E) - chi^2 * E

    The wave dynamics naturally smooth and scale activations along the
    channel dimension, with learnable wave speed (c), mass (chi), and
    affine parameters (gamma, beta).

    Results:
        FashionMNIST CNN: +0.76% accuracy vs BatchNorm (91.94% vs 91.18%)
        SVHN CNN: +0.57% accuracy vs BatchNorm (92.20% vs 91.63%)
        CalHousing regression: -13.5% MSE vs BatchNorm (0.184 vs 0.213)

    Args:
        num_features (int): Number of features/channels.
        n_steps (int): Number of leapfrog evolution steps. Default: 3.
        dt (float): Initial time step. Default: 0.1 (learnable).
        c (float): Initial wave speed. Default: 1.0 (learnable).
        chi (float): Initial mass/frequency parameter. Default: 1.0
            (learnable, per-feature).

    Example::

        from ladam import WaveNorm

        # Replace nn.BatchNorm2d(64) with:
        norm = WaveNorm(64)

        # Works for both 2D (MLP: [B, C]) and 4D (CNN: [B, C, H, W])
        out = norm(x)
    """

    def __init__(self, num_features, n_steps=3, dt=0.1, c=1.0, chi=1.0):
        super().__init__()
        self.num_features = num_features
        self.n_steps = n_steps
        self.dt = nn.Parameter(torch.tensor(float(dt)))
        self.c = nn.Parameter(torch.tensor(float(c)))
        self.chi = nn.Parameter(torch.full((num_features,), float(chi)))
        self.gamma = nn.Parameter(torch.ones(num_features))
        self.beta = nn.Parameter(torch.zeros(num_features))

    def _laplacian_1d(self, x):
        """1D discrete Laplacian along the last dimension (circular padding)."""
        x_pad = torch.cat([x[..., -1:], x, x[..., :1]], dim=-1)
        return x_pad[..., 2:] - 2 * x_pad[..., 1:-1] + x_pad[..., :-2]

    def forward(self, x):
        orig_shape = x.shape

        # Reshape 4D (CNN) to 2D for uniform processing
        if x.dim() == 4:
            B, C, H, W = x.shape
            x_flat = x.permute(0, 2, 3, 1).reshape(-1, C)  # [B*H*W, C]
        elif x.dim() == 2:
            x_flat = x
        else:
            # Fallback: flatten all but last dim
            x_flat = x.reshape(-1, x.shape[-1])

        # Leapfrog wave evolution
        chi = self.chi.view(1, -1)
        e_prev = x_flat
        e_curr = x_flat

        for _ in range(self.n_steps):
            lap = self._laplacian_1d(e_curr)
            accel = self.dt ** 2 * (self.c ** 2 * lap - chi ** 2 * e_curr)
            e_next = 2 * e_curr - e_prev + accel
            e_prev = e_curr
            e_curr = e_next

        # Apply learnable affine transform
        gamma = self.gamma.view(1, -1)
        beta = self.beta.view(1, -1)
        out = gamma * e_curr + beta

        # Reshape back to original spatial layout
        if len(orig_shape) == 4:
            out = out.reshape(B, H, W, C).permute(0, 3, 1, 2)

        return out

    def extra_repr(self):
        return (f"num_features={self.num_features}, n_steps={self.n_steps}, "
                f"dt={self.dt.item():.3f}, c={self.c.item():.3f}")


class WaveNormDamped(nn.Module):
    """
    WaveNorm with learnable per-feature damping.

    Adds a friction term to the wave evolution that suppresses oscillation:
        E_next = 2*E - E_prev + dt^2*(c^2*lap - chi^2*E) - damping*velocity

    The damping coefficient is learnable per-feature via sigmoid, so the
    network can learn:
    - damping ~ 0: preserve momentum (good for regression)
    - damping ~ 1: suppress ringing (good for classification with bounded outputs)

    This fixes WaveNorm's oscillation problem on classification tasks while
    preserving its regression advantage.

    Results:
        CalHousing regression: -13.5% MSE vs BatchNorm (preserved from WaveNorm)
        WineQuality classification: -0.8% MSE vs BatchNorm (fixed oscillation)

    Args:
        num_features (int): Number of features/channels.
        n_steps (int): Number of leapfrog evolution steps. Default: 3.
        dt (float): Initial time step. Default: 0.1 (learnable).
        c (float): Initial wave speed. Default: 1.0 (learnable).
        chi (float): Initial mass/frequency parameter. Default: 1.0 (learnable).
        init_damping (float): Initial damping strength in [0, 1]. Default: 0.5.

    Example::

        from ladam import WaveNormDamped

        # Drop-in replacement for BatchNorm:
        norm = WaveNormDamped(128, init_damping=0.3)
        out = norm(x)
    """

    def __init__(self, num_features, n_steps=3, dt=0.1, c=1.0, chi=1.0,
                 init_damping=0.5):
        super().__init__()
        self.num_features = num_features
        self.n_steps = n_steps
        self.dt = nn.Parameter(torch.tensor(float(dt)))
        self.c = nn.Parameter(torch.tensor(float(c)))
        self.chi = nn.Parameter(torch.full((num_features,), float(chi)))

        # Damping: sigmoid(raw) maps to [0, 1]
        init_damping = max(min(init_damping, 0.999), 0.001)
        init_raw = math.log(init_damping / (1.0 - init_damping))
        self.damping_raw = nn.Parameter(
            torch.full((num_features,), init_raw)
        )

        self.gamma = nn.Parameter(torch.ones(num_features))
        self.beta = nn.Parameter(torch.zeros(num_features))

    def _laplacian_1d(self, x):
        """1D discrete Laplacian along the last dimension (circular padding)."""
        x_pad = torch.cat([x[..., -1:], x, x[..., :1]], dim=-1)
        return x_pad[..., 2:] - 2 * x_pad[..., 1:-1] + x_pad[..., :-2]

    def forward(self, x):
        orig_shape = x.shape

        if x.dim() == 4:
            B, C, H, W = x.shape
            x_flat = x.permute(0, 2, 3, 1).reshape(-1, C)
        elif x.dim() == 2:
            x_flat = x
        else:
            x_flat = x.reshape(-1, x.shape[-1])

        chi = self.chi.view(1, -1)
        damping = torch.sigmoid(self.damping_raw).view(1, -1)
        e_prev = x_flat
        e_curr = x_flat

        for _ in range(self.n_steps):
            lap = self._laplacian_1d(e_curr)
            velocity = e_curr - e_prev
            accel = self.dt ** 2 * (self.c ** 2 * lap - chi ** 2 * e_curr)
            e_next = 2 * e_curr - e_prev + accel - damping * velocity
            e_prev = e_curr
            e_curr = e_next

        gamma = self.gamma.view(1, -1)
        beta = self.beta.view(1, -1)
        out = gamma * e_curr + beta

        if len(orig_shape) == 4:
            out = out.reshape(B, H, W, C).permute(0, 3, 1, 2)

        return out

    def extra_repr(self):
        damping_val = torch.sigmoid(self.damping_raw).mean().item()
        return (f"num_features={self.num_features}, n_steps={self.n_steps}, "
                f"mean_damping={damping_val:.3f}")


class ChiNorm(nn.Module):
    """
    Chi-field adaptive normalization based on GOV-03.

    Implements: chi^2 = chi0^2 - g * <|x|^2>

    Unlike BatchNorm which forces zero-mean/unit-variance, ChiNorm creates
    adaptive gain that PRESERVES strong activations:
    - High energy (|x|^2 large) -> chi drops -> output amplified
    - Low energy (vacuum) -> chi ~ chi0 -> baseline normalization

    Args:
        num_features (int): Number of features/channels.
        chi0_init (float): Initial vacuum chi value. Default: 1.0.
        g_init (float): Initial coupling strength. Default: 0.1.
        tau (float): Running average momentum. Default: 0.1.
        eps (float): Numerical stability. Default: 1e-5.

    Example::

        from ladam import ChiNorm

        # Replace nn.BatchNorm2d(64) with:
        norm = ChiNorm(64)
        out = norm(x)  # Works for [B, C] and [B, C, H, W]
    """

    def __init__(self, num_features, chi0_init=1.0, g_init=0.1, tau=0.1,
                 eps=1e-5):
        super().__init__()
        self.num_features = num_features
        self.eps = eps
        self.tau = tau

        self.chi0 = nn.Parameter(torch.full((num_features,), float(chi0_init)))
        self.g = nn.Parameter(torch.full((num_features,), float(g_init)))
        self.gamma = nn.Parameter(torch.ones(num_features))
        self.beta = nn.Parameter(torch.zeros(num_features))

        self.register_buffer('running_energy', torch.zeros(num_features))
        self.register_buffer('num_batches_tracked',
                             torch.tensor(0, dtype=torch.long))

    def forward(self, x):
        # Compute energy density |x|^2 averaged over batch and spatial dims
        if x.dim() == 4:  # Conv: [B, C, H, W]
            energy = (x ** 2).mean(dim=(0, 2, 3))
        elif x.dim() == 2:  # Linear: [B, C]
            energy = (x ** 2).mean(dim=0)
        else:
            reduce_dims = tuple(range(x.dim() - 1))
            energy = (x ** 2).mean(dim=reduce_dims)

        # Update running energy (GOV-03 tau-averaging)
        if self.training:
            with torch.no_grad():
                self.num_batches_tracked += 1
                self.running_energy.mul_(1 - self.tau).add_(
                    energy, alpha=self.tau
                )
            current_energy = energy
        else:
            current_energy = self.running_energy

        # GOV-03: chi^2 = chi0^2 - g * <|x|^2>
        chi_squared = self.chi0 ** 2 - self.g * current_energy
        chi_squared = torch.clamp(chi_squared, min=self.eps)
        chi = torch.sqrt(chi_squared)

        # Reshape for broadcasting
        if x.dim() == 4:
            chi = chi.view(1, -1, 1, 1)
            gamma = self.gamma.view(1, -1, 1, 1)
            beta = self.beta.view(1, -1, 1, 1)
        else:
            chi = chi.view(1, -1)
            gamma = self.gamma.view(1, -1)
            beta = self.beta.view(1, -1)

        return gamma * (x / chi) + beta

    def extra_repr(self):
        return (f"num_features={self.num_features}, tau={self.tau}, "
                f"eps={self.eps}")
