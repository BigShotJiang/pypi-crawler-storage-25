"""
LAdam — Laplacian Adam Optimizer
================================

A drop-in Adam replacement that applies discrete Laplacian regularization
to the second moment estimate (v_t), producing spatially-smoothed adaptive
learning rates.

Key insight: adjacent weights in neural networks are often functionally
correlated, but Adam computes independent per-parameter learning rates.
LAdam restores spatial coherence by applying a Laplacian diffusion
operator to Adam's variance estimate, allowing neighboring weights to
share curvature information.

This is particularly effective for:
  - **PINNs** (physics-informed neural networks): -44.6% L2 error vs Adam
  - **Transformers**: +0.20% accuracy, p=0.0005 across 5 seeds
  - Any architecture with spatially-correlated weight structure

Usage:
    from ladam import LAdam

    optimizer = LAdam(model.parameters(), lr=1e-3, c2=1e-4)

    for batch in dataloader:
        loss = model(batch)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
"""

import torch
import torch.nn.functional as F
from torch.optim import Optimizer


class LAdam(Optimizer):
    """
    LAdam: Laplacian Adam — Adam with Laplacian-regularized variance estimates.

    Applies a discrete Laplacian to Adam's second-moment estimate v_t,
    coupling adjacent weight learning rates. This smooths the adaptive
    learning rate landscape, improving convergence for architectures with
    spatially-structured parameters.

    Modes:
        'variance_lap':  Laplacian on v_t (default, best overall)
        'update_lap':    Laplacian on the update direction
        'weight_lap':    Standard Adam step + weight-space diffusion

    Args:
        params: Model parameters or param groups.
        lr (float): Learning rate. Default: 1e-3.
        betas (Tuple[float, float]): EMA coefficients for (m_t, v_t).
            Default: (0.9, 0.999).
        eps (float): Numerical stability. Default: 1e-8.
        weight_decay (float): L2 weight decay. Default: 0.
        c2 (float): Laplacian coupling strength. Controls how much
            neighboring variance estimates influence each other.
            Recommended: 1e-5 for PINNs, 1e-4 for transformers.
            Default: 1e-4.
        mode (str): Which internal quantity to apply the Laplacian to.
            Default: 'variance_lap'.
        stencil (str): Laplacian stencil type for 2D parameters.
            '9point': Isotropic stencil [1,4,1;4,-20,4;1,4,1]/6 — 0.46%
                anisotropy. Default. Based on LFM lattice geometry
                (face weight 2/3, diagonal weight 1/6).
            '5point': Standard stencil [0,1,0;1,-4,1;0,1,0] — 12.3%
                anisotropy. Legacy option for reproducing prior results.
        min_spatial_size (int): Skip Laplacian for parameters with fewer
            elements than this threshold. Small params (biases, norms)
            lack meaningful spatial structure. Default: 16.
    """

    # Pre-built Laplacian kernels (cached on first use per device/stencil)
    _lap_kernels_2d = {}
    _lap_kernel_1d = None

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8,
                 weight_decay=0, c2=1e-4, mode='variance_lap',
                 stencil='9point', min_spatial_size=16):
        if lr < 0.0:
            raise ValueError(f"Invalid learning rate: {lr}")
        if eps < 0.0:
            raise ValueError(f"Invalid epsilon value: {eps}")
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 0: {betas[0]}")
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 1: {betas[1]}")
        if c2 < 0.0:
            raise ValueError(f"Invalid coupling strength: {c2}")
        if mode not in ('variance_lap', 'update_lap', 'weight_lap'):
            raise ValueError(f"Invalid mode: {mode}. Choose from: "
                             "'variance_lap', 'update_lap', 'weight_lap'")
        if stencil not in ('5point', '9point'):
            raise ValueError(f"Invalid stencil: {stencil}. Choose from: "
                             "'5point', '9point'")

        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay,
                        c2=c2, mode=mode, stencil=stencil,
                        min_spatial_size=min_spatial_size)
        super().__init__(params, defaults)

    @classmethod
    def _get_lap_kernel_2d(cls, device, dtype, stencil='9point'):
        """Lazily create and cache the 2D discrete Laplacian kernel.

        stencil='9point' (default): Isotropic [1,4,1;4,-20,4;1,4,1]/6
            Isotropic stencil — faces weighted 2/3, diagonals 1/6.
            Only 0.46% anisotropy vs 12.3% for 5-point.
        stencil='5point': Standard [0,1,0;1,-4,1;0,1,0].
            Standard cross-pattern stencil.
        """
        key = (stencil, device, dtype)
        if key not in cls._lap_kernels_2d:
            if stencil == '9point':
                # Isotropic 2D Laplacian: face weight 4/6, diagonal weight 1/6
                # Minimizes angular anisotropy (0.46% vs 12.3% for 5-point)
                k = torch.tensor([[1/6., 4/6., 1/6.],
                                  [4/6., -20/6., 4/6.],
                                  [1/6., 4/6., 1/6.]], device=device, dtype=dtype)
            else:  # 5point
                k = torch.tensor([[0., 1., 0.],
                                  [1., -4., 1.],
                                  [0., 1., 0.]], device=device, dtype=dtype)
            cls._lap_kernels_2d[key] = k.reshape(1, 1, 3, 3)
        return cls._lap_kernels_2d[key]

    @classmethod
    def _get_lap_kernel_1d(cls, device, dtype):
        """Lazily create and cache the 1D discrete Laplacian kernel."""
        if cls._lap_kernel_1d is None or cls._lap_kernel_1d.device != device:
            k = torch.tensor([1., -2., 1.], device=device, dtype=dtype)
            cls._lap_kernel_1d = k.reshape(1, 1, 3)
        return cls._lap_kernel_1d.to(dtype=dtype)

    @staticmethod
    def _laplacian(W, kernel_2d, kernel_1d):
        """
        Apply discrete Laplacian via fused conv2d — single GPU kernel launch.

        Uses circular padding to treat weight matrices as periodic fields.
        High-dimensional tensors are reshaped to 2D while preserving spatial
        structure.
        """
        if W.dim() == 1:
            n = W.numel()
            if n < 4:
                return torch.zeros_like(W)
            x = W.reshape(1, 1, n)
            x = F.pad(x, (1, 1), mode='circular')
            return F.conv1d(x, kernel_1d).reshape(W.shape)
        else:
            shape = W.shape
            W2 = W.reshape(shape[0], -1) if W.dim() > 2 else W
            h, w = W2.shape
            if h < 3 or w < 3:
                return torch.zeros_like(W)
            x = W2.reshape(1, 1, h, w)
            x = F.pad(x, (1, 1, 1, 1), mode='circular')
            result = F.conv2d(x, kernel_2d).reshape(W2.shape)
            if W.dim() > 2:
                result = result.reshape(shape)
            return result

    @torch.no_grad()
    def step(self, closure=None):
        """Performs a single optimization step.

        Args:
            closure (Callable, optional): A closure that reevaluates the model
                and returns the loss.
        """
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group['lr']
            beta1, beta2 = group['betas']
            eps = group['eps']
            c2 = group['c2']
            mode = group['mode']
            wd = group['weight_decay']
            min_sp = group['min_spatial_size']

            stencil = group['stencil']

            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad.data
                if wd != 0:
                    grad = grad.add(p.data, alpha=wd)

                state = self.state[p]

                # State initialization
                if len(state) == 0:
                    state['step'] = 0
                    state['m'] = torch.zeros_like(p.data)
                    state['v'] = torch.zeros_like(p.data)
                    state['use_lap'] = (c2 > 0 and p.data.numel() >= min_sp)

                state['step'] += 1
                m, v = state['m'], state['v']
                step = state['step']
                use_lap = state['use_lap']

                # Standard Adam momentum updates
                m.mul_(beta1).add_(grad, alpha=1 - beta1)
                v.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                # Bias correction
                m_hat = m / (1 - beta1 ** step)
                v_hat = v / (1 - beta2 ** step)

                if mode == 'variance_lap':
                    # Core innovation: couple neighboring variance estimates
                    if use_lap:
                        k2d = self._get_lap_kernel_2d(p.device, v_hat.dtype, stencil)
                        k1d = self._get_lap_kernel_1d(p.device, v_hat.dtype)
                        v_smooth = v_hat + c2 * self._laplacian(v_hat, k2d, k1d)
                        v_smooth = v_smooth.clamp(min=eps)
                    else:
                        v_smooth = v_hat
                    p.data.addcdiv_(m_hat, v_smooth.sqrt().add_(eps), value=-lr)

                elif mode == 'update_lap':
                    update = m_hat / (v_hat.sqrt() + eps)
                    if use_lap:
                        k2d = self._get_lap_kernel_2d(p.device, update.dtype, stencil)
                        k1d = self._get_lap_kernel_1d(p.device, update.dtype)
                        update = update + c2 * self._laplacian(update, k2d, k1d)
                    p.data.add_(update, alpha=-lr)

                elif mode == 'weight_lap':
                    p.data.addcdiv_(m_hat, v_hat.sqrt().add_(eps), value=-lr)
                    if use_lap:
                        k2d = self._get_lap_kernel_2d(p.device, p.data.dtype, stencil)
                        k1d = self._get_lap_kernel_1d(p.device, p.data.dtype)
                        p.data.add_(self._laplacian(p.data, k2d, k1d), alpha=c2)

        return loss


def suggest_c2(architecture: str = 'auto') -> float:
    """
    Suggest a c2 value based on architecture type.

    Based on systematic sweeps across 7 c2 values and 4 architecture types.

    Args:
        architecture: One of 'pinn', 'transformer', 'mlp', 'cnn', or 'auto'.
            'auto' returns a safe default.

    Returns:
        Recommended c2 value.
    """
    recommendations = {
        'pinn': 1e-5,         # -44.6% L2 error vs Adam
        'transformer': 1e-4,  # +0.20% acc, p=0.0005
        'mlp': 1e-5,          # Marginal improvement, safe value
        'cnn': 0.0,           # No benefit; skip Laplacian
        'auto': 1e-4,         # Safe general-purpose default
    }
    arch = architecture.lower()
    if arch not in recommendations:
        raise ValueError(f"Unknown architecture: {arch}. "
                         f"Choose from: {list(recommendations.keys())}")
    return recommendations[arch]


class LAdaGrad(Optimizer):
    """
    LAdaGrad: AdaGrad with Laplacian-regularized accumulator.

    Standard AdaGrad accumulates squared gradients independently per parameter.
    LAdaGrad applies discrete Laplacian diffusion to the accumulator, letting
    neighboring weights share curvature information.

    Args:
        params: Model parameters or param groups.
        lr (float): Learning rate. Default: 1e-2.
        lr_decay (float): Learning rate decay. Default: 0.
        eps (float): Numerical stability. Default: 1e-10.
        weight_decay (float): L2 weight decay. Default: 0.
        c2 (float): Laplacian coupling strength. Default: 1e-4.
        stencil (str): '9point' or '5point'. Default: '9point'.
        min_spatial_size (int): Skip Laplacian below this size. Default: 16.
    """

    def __init__(self, params, lr=1e-2, lr_decay=0, eps=1e-10,
                 weight_decay=0, c2=1e-4, stencil='9point',
                 min_spatial_size=16):
        if lr < 0.0:
            raise ValueError(f"Invalid learning rate: {lr}")
        if c2 < 0.0:
            raise ValueError(f"Invalid coupling strength: {c2}")
        defaults = dict(lr=lr, lr_decay=lr_decay, eps=eps,
                        weight_decay=weight_decay, c2=c2,
                        stencil=stencil, min_spatial_size=min_spatial_size)
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group['lr']
            lr_decay = group['lr_decay']
            eps = group['eps']
            c2 = group['c2']
            wd = group['weight_decay']
            min_sp = group['min_spatial_size']
            stencil = group['stencil']

            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad.data
                if wd != 0:
                    grad = grad.add(p.data, alpha=wd)

                state = self.state[p]
                if len(state) == 0:
                    state['step'] = 0
                    state['sum'] = torch.zeros_like(p.data)
                    state['use_lap'] = (c2 > 0 and p.data.numel() >= min_sp)

                state['step'] += 1
                state['sum'].addcmul_(grad, grad, value=1)

                clr = lr / (1 + (state['step'] - 1) * lr_decay)

                acc = state['sum']
                if state['use_lap']:
                    k2d = LAdam._get_lap_kernel_2d(p.device, acc.dtype, stencil)
                    k1d = LAdam._get_lap_kernel_1d(p.device, acc.dtype)
                    acc_smooth = acc + c2 * LAdam._laplacian(acc, k2d, k1d)
                    acc_smooth = acc_smooth.clamp(min=0)
                else:
                    acc_smooth = acc

                p.data.addcdiv_(grad, acc_smooth.sqrt().add_(eps), value=-clr)

        return loss


class LRMSProp(Optimizer):
    """
    LRMSProp: RMSProp with Laplacian-regularized running average.

    Standard RMSProp maintains a decaying average of squared gradients per
    parameter. LRMSProp applies discrete Laplacian diffusion to this average,
    coupling neighbors.

    Args:
        params: Model parameters or param groups.
        lr (float): Learning rate. Default: 1e-2.
        alpha (float): Smoothing constant (decay). Default: 0.99.
        eps (float): Numerical stability. Default: 1e-8.
        weight_decay (float): L2 weight decay. Default: 0.
        momentum (float): Momentum factor. Default: 0.
        c2 (float): Laplacian coupling strength. Default: 1e-4.
        stencil (str): '9point' or '5point'. Default: '9point'.
        min_spatial_size (int): Skip Laplacian below this size. Default: 16.
    """

    def __init__(self, params, lr=1e-2, alpha=0.99, eps=1e-8,
                 weight_decay=0, momentum=0, c2=1e-4, stencil='9point',
                 min_spatial_size=16):
        if lr < 0.0:
            raise ValueError(f"Invalid learning rate: {lr}")
        if alpha < 0.0 or alpha >= 1.0:
            raise ValueError(f"Invalid alpha: {alpha}")
        if c2 < 0.0:
            raise ValueError(f"Invalid coupling strength: {c2}")
        defaults = dict(lr=lr, alpha=alpha, eps=eps, weight_decay=weight_decay,
                        momentum=momentum, c2=c2, stencil=stencil,
                        min_spatial_size=min_spatial_size)
        super().__init__(params, defaults)

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group['lr']
            alpha = group['alpha']
            eps = group['eps']
            c2 = group['c2']
            wd = group['weight_decay']
            mom = group['momentum']
            min_sp = group['min_spatial_size']
            stencil = group['stencil']

            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad.data
                if wd != 0:
                    grad = grad.add(p.data, alpha=wd)

                state = self.state[p]
                if len(state) == 0:
                    state['step'] = 0
                    state['square_avg'] = torch.zeros_like(p.data)
                    if mom > 0:
                        state['momentum_buffer'] = torch.zeros_like(p.data)
                    state['use_lap'] = (c2 > 0 and p.data.numel() >= min_sp)

                state['step'] += 1
                sq_avg = state['square_avg']
                sq_avg.mul_(alpha).addcmul_(grad, grad, value=1 - alpha)

                if state['use_lap']:
                    k2d = LAdam._get_lap_kernel_2d(p.device, sq_avg.dtype, stencil)
                    k1d = LAdam._get_lap_kernel_1d(p.device, sq_avg.dtype)
                    avg_smooth = sq_avg + c2 * LAdam._laplacian(sq_avg, k2d, k1d)
                    avg_smooth = avg_smooth.clamp(min=0)
                else:
                    avg_smooth = sq_avg

                if mom > 0:
                    buf = state['momentum_buffer']
                    buf.mul_(mom).addcdiv_(grad, avg_smooth.sqrt().add_(eps))
                    p.data.add_(buf, alpha=-lr)
                else:
                    p.data.addcdiv_(grad, avg_smooth.sqrt().add_(eps), value=-lr)

        return loss
