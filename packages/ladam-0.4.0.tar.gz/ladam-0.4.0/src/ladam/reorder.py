"""
LAdam Neuron Reordering — Structure-aware neuron permutation for MLPs.

Key insight: MLP neurons are randomly ordered, but functionally correlated
neurons benefit from being adjacent (for Laplacian-based optimization).
This module computes optimal neuron orderings from activation correlations
and applies them to model weights.
"""

import torch
import torch.nn as nn


def compute_neuron_order(activations):
    """
    Compute optimal neuron ordering using activation correlation + greedy TSP.

    Neurons that fire similarly should be adjacent so LAdam's channel Laplacian
    can exploit the spatial structure.

    Args:
        activations (Tensor): Activation matrix of shape [batch, num_neurons].

    Returns:
        list[int]: Permutation indices that reorder neurons so correlated
            ones are adjacent.

    Example::

        from ladam import compute_neuron_order, reorder_linear_layer

        # Collect activations from a warmup phase
        activations = model.collect_hidden_activations(dataloader)

        # Compute optimal ordering
        order = compute_neuron_order(activations)

        # Apply to model weights
        reorder_linear_layer(model.fc1, model.fc2, order)
    """
    if not isinstance(activations, torch.Tensor):
        raise TypeError(f"Expected torch.Tensor, got {type(activations)}")
    if activations.dim() != 2:
        raise ValueError(f"Expected 2D tensor [batch, neurons], got {activations.dim()}D")

    n = activations.shape[1]
    if n <= 4:
        return list(range(n))

    # Compute correlation matrix on CPU (numpy is faster for this)
    act = activations.detach().float().cpu()
    stds = act.std(dim=0)
    stds = stds.clamp(min=1e-8)
    normed = (act - act.mean(dim=0)) / stds
    corr = (normed.t() @ normed) / act.shape[0]

    # Greedy nearest-neighbor TSP: place most-correlated neurons adjacent
    visited = [False] * n
    order = [0]
    visited[0] = True

    for _ in range(n - 1):
        current = order[-1]
        best_next = -1
        best_corr = -2.0
        for j in range(n):
            if not visited[j] and corr[current, j].item() > best_corr:
                best_corr = corr[current, j].item()
                best_next = j
        order.append(best_next)
        visited[best_next] = True

    return order


def reorder_linear_layer(layer, next_layer, order):
    """
    Reorder output neurons of a Linear layer and fix the next layer's inputs.

    Permutes the output dimension of ``layer`` and the input dimension of
    ``next_layer`` according to ``order``, keeping the network functionally
    identical but with neurons reordered for better spatial structure.

    Args:
        layer (nn.Linear): The layer whose output neurons to reorder.
        next_layer (nn.Linear): The following layer (input connections adjusted).
        order (list[int]): Permutation indices from :func:`compute_neuron_order`.

    Example::

        from ladam import reorder_linear_layer

        reorder_linear_layer(model.fc1, model.fc2, order)
        reorder_linear_layer(model.fc2, model.fc3, order2)
    """
    if not isinstance(layer, nn.Linear):
        raise TypeError(f"layer must be nn.Linear, got {type(layer)}")
    if not isinstance(next_layer, nn.Linear):
        raise TypeError(f"next_layer must be nn.Linear, got {type(next_layer)}")

    device = layer.weight.device
    order_t = torch.tensor(order, dtype=torch.long, device=device)

    with torch.no_grad():
        # Reorder outputs of current layer
        layer.weight.data = layer.weight.data[order_t]
        layer.bias.data = layer.bias.data[order_t]

        # Reorder corresponding inputs of next layer
        next_layer.weight.data = next_layer.weight.data[:, order_t]
