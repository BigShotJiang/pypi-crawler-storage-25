"""
LAdam — Laplacian Adam Optimizer + Physics-Inspired ML Toolkit
"""

__version__ = "0.4.0"

# Optimizers
from .optimizer import LAdam, LAdaGrad, LRMSProp, suggest_c2

# Scheduler
from .scheduler import ChiAnnealScheduler

# Normalization layers
from .normalization import WaveNorm, WaveNormDamped, ChiNorm

# Neuron reordering utilities
from .reorder import compute_neuron_order, reorder_linear_layer

# Auto-tuning
from .auto import auto_configure, analyze_model

# Backward compatibility alias
WaveAdam = LAdam

__all__ = [
    # Optimizers
    "LAdam", "LAdaGrad", "LRMSProp", "WaveAdam", "suggest_c2",
    # Scheduler
    "ChiAnnealScheduler",
    # Normalization
    "WaveNorm", "WaveNormDamped", "ChiNorm",
    # Utilities
    "compute_neuron_order", "reorder_linear_layer",
    # Auto-tuning
    "auto_configure", "analyze_model",
]
