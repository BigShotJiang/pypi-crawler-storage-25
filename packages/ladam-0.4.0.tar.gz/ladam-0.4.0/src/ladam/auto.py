"""
LAdam Auto-Tuning — Automatic optimizer configuration from model architecture.

Usage:
    from ladam.auto import auto_configure
    optimizer, scheduler = auto_configure(model, lr=1e-3, total_steps=10000)
"""

from __future__ import annotations

import math
from typing import Any

import torch
import torch.nn as nn

from .optimizer import LAdam
from .scheduler import ChiAnnealScheduler


# ---------------------------------------------------------------------------
# Layer classification
# ---------------------------------------------------------------------------

_ATTENTION_NAMES = frozenset({
    "self_attn", "multihead_attn", "attention", "attn",
    "q_proj", "k_proj", "v_proj", "out_proj",
    "query", "key", "value",
})

_NORM_TYPES = (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d,
               nn.LayerNorm, nn.GroupNorm, nn.InstanceNorm1d,
               nn.InstanceNorm2d, nn.InstanceNorm3d)


def _is_attention_param(name: str) -> bool:
    """Check if a parameter name suggests an attention layer."""
    parts = name.lower().split(".")
    return any(p in _ATTENTION_NAMES for p in parts)


def _classify_param(name: str, param: torch.Tensor, module_map: dict[str, nn.Module]) -> str:
    """Classify a parameter into one of: attention, conv, linear, norm, embedding, bias, other."""
    if param.ndim <= 1:
        return "bias"

    if _is_attention_param(name):
        return "attention"

    # Walk module map to find the owning module
    prefix = ".".join(name.split(".")[:-1])
    mod = module_map.get(prefix)

    if isinstance(mod, (nn.Conv1d, nn.Conv2d, nn.Conv3d)):
        return "conv"
    if isinstance(mod, _NORM_TYPES):
        return "norm"
    if isinstance(mod, nn.Embedding):
        return "embedding"
    if isinstance(mod, nn.Linear):
        return "linear"

    # Fallback: use shape heuristics
    if param.ndim >= 3:
        return "conv"
    if param.ndim == 2:
        return "linear"
    return "other"


# ---------------------------------------------------------------------------
# c2 recommendation per layer type (from 64-experiment benchmark)
# ---------------------------------------------------------------------------

_C2_MAP: dict[str, float] = {
    "linear":    1e-5,   # Validated: B10b +0.80% FashionMNIST
    "conv":      0.0,    # No measurable benefit in 64-exp suite
    "attention": 0.0,    # DANGEROUS: B21 GPT-2 1098 ppl catastrophe
    "norm":      0.0,    # Normalization params should not be coupled
    "embedding": 0.0,    # Discrete lookups, no spatial structure
    "bias":      0.0,    # 1D, too small for Laplacian
    "other":     0.0,    # Unknown — conservative default
}


# ---------------------------------------------------------------------------
# Architecture detection
# ---------------------------------------------------------------------------

def _detect_architecture(model: nn.Module) -> str:
    """Detect broad architecture family from model structure."""
    module_types = {type(m).__name__.lower() for m in model.modules()}
    param_names = {n for n, _ in model.named_parameters()}

    has_attention = any(_is_attention_param(n) for n in param_names) or \
                    any("attention" in t or "transformer" in t for t in module_types)
    has_conv = any(isinstance(m, (nn.Conv1d, nn.Conv2d, nn.Conv3d)) for m in model.modules())
    has_rnn = any(isinstance(m, (nn.RNN, nn.LSTM, nn.GRU)) for m in model.modules())

    if has_attention:
        return "transformer"
    if has_rnn:
        return "rnn"
    if has_conv:
        return "cnn"
    return "mlp"


# ---------------------------------------------------------------------------
# Model analysis report
# ---------------------------------------------------------------------------

def analyze_model(model: nn.Module) -> dict[str, Any]:
    """Analyze a model and return a structured report.

    Returns a dict with:
        architecture: str — detected architecture family
        total_params: int — total trainable parameters
        layer_counts: dict[str, int] — count of each layer type
        layer_params: dict[str, int] — parameter count per layer type
        recommendation: str — human-readable recommendation
        c2_map: dict[str, float] — recommended c2 per layer type
    """
    module_map = dict(model.named_modules())
    layer_counts: dict[str, int] = {}
    layer_params: dict[str, int] = {}

    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        cat = _classify_param(name, param, module_map)
        layer_counts[cat] = layer_counts.get(cat, 0) + 1
        layer_params[cat] = layer_params.get(cat, 0) + param.numel()

    arch = _detect_architecture(model)
    total = sum(layer_params.values())

    # Build recommendation string
    active_types = [k for k, v in _C2_MAP.items() if v > 0 and k in layer_counts]
    active_params = sum(layer_params.get(k, 0) for k in active_types)
    pct = (100.0 * active_params / total) if total > 0 else 0.0

    if not active_types:
        rec = (f"Architecture '{arch}' has no layer types where LAdam's Laplacian "
               f"provides measured benefit. Consider using standard Adam.")
    elif pct < 10:
        rec = (f"Only {pct:.1f}% of parameters ({active_params:,} / {total:,}) "
               f"benefit from Laplacian coupling. Mixed optimizer recommended.")
    else:
        rec = (f"{pct:.1f}% of parameters ({active_params:,} / {total:,}) are in "
               f"layer types where LAdam showed gains. Good candidate for LAdam.")

    return {
        "architecture": arch,
        "total_params": total,
        "layer_counts": dict(sorted(layer_counts.items())),
        "layer_params": dict(sorted(layer_params.items())),
        "recommendation": rec,
        "c2_map": {k: v for k, v in _C2_MAP.items() if k in layer_counts},
    }


# ---------------------------------------------------------------------------
# Auto-configure optimizer + scheduler
# ---------------------------------------------------------------------------

def auto_configure(
    model: nn.Module,
    lr: float = 1e-3,
    total_steps: int | None = None,
    total_epochs: int | None = None,
    steps_per_epoch: int | None = None,
    weight_decay: float = 0.0,
    use_scheduler: bool = True,
) -> tuple[LAdam, ChiAnnealScheduler | None]:
    """Automatically configure LAdam + ChiAnnealScheduler for a model.

    Analyzes the model architecture and creates parameter groups with
    per-layer-type c2 values based on the 64-experiment benchmark.

    Parameters
    ----------
    model : nn.Module
        The model to optimize.
    lr : float
        Base learning rate (default: 1e-3).
    total_steps : int, optional
        Total training steps. Required if use_scheduler=True and
        total_epochs is not provided.
    total_epochs : int, optional
        Total epochs (alternative to total_steps).
    steps_per_epoch : int, optional
        Steps per epoch (needed if total_epochs is given).
    weight_decay : float
        Weight decay (default: 0).
    use_scheduler : bool
        Whether to create a ChiAnnealScheduler (default: True).

    Returns
    -------
    (optimizer, scheduler) : tuple
        Configured LAdam optimizer and optional ChiAnnealScheduler.
        scheduler is None if use_scheduler=False.

    Example
    -------
    >>> from ladam.auto import auto_configure
    >>> model = torchvision.models.resnet18()
    >>> optimizer, scheduler = auto_configure(model, lr=1e-3, total_epochs=100, steps_per_epoch=391)
    >>> for batch in dataloader:
    ...     loss = train_step(model, batch)
    ...     loss.backward()
    ...     optimizer.step()
    ...     optimizer.zero_grad()
    ...     if scheduler: scheduler.step()
    """
    # Resolve total steps
    if total_steps is None:
        if total_epochs is not None and steps_per_epoch is not None:
            total_steps = total_epochs * steps_per_epoch
        elif use_scheduler:
            raise ValueError(
                "Either total_steps or (total_epochs + steps_per_epoch) "
                "required when use_scheduler=True"
            )

    module_map = dict(model.named_modules())

    # Group parameters by their recommended c2
    groups: dict[float, list[torch.nn.Parameter]] = {}
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        cat = _classify_param(name, param, module_map)
        c2 = _C2_MAP.get(cat, 0.0)
        groups.setdefault(c2, []).append(param)

    # Build optimizer param groups
    param_groups = []
    for c2_val, params in sorted(groups.items()):
        param_groups.append({
            "params": params,
            "c2": c2_val,
            "lr": lr,
            "weight_decay": weight_decay,
        })

    optimizer = LAdam(param_groups)

    # Build scheduler
    scheduler = None
    if use_scheduler and total_steps is not None:
        scheduler = ChiAnnealScheduler(
            optimizer,
            total_steps=total_steps,
        )

    return optimizer, scheduler
