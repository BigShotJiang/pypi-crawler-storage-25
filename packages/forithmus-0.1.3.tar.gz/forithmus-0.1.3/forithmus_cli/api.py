from __future__ import annotations
"""API client for the Forithmus Research Hub."""
import sys
from pathlib import Path

import httpx
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn

from forithmus_cli.auth import get_api_url, get_token

console = Console()


def _headers() -> dict:
    token = get_token()
    h = {"X-Requested-With": "XMLHttpRequest"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h


def api_get(path: str, params: dict | None = None):
    """GET request to the API. Returns parsed JSON or None."""
    url = get_api_url()
    try:
        res = httpx.get(f"{url}{path}", headers=_headers(), params=params, timeout=30)
        if res.status_code == 200:
            return res.json()
        if res.status_code == 401:
            console.print("[red]Session expired. Run: forithmus login[/red]")
            return None
        return None
    except httpx.RequestError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        return None


def api_post(path: str, data=None, files=None, timeout=30):
    """POST request to the API. Returns parsed JSON or None."""
    url = get_api_url()
    try:
        if files:
            res = httpx.post(f"{url}{path}", headers=_headers(), files=files, timeout=timeout)
        else:
            res = httpx.post(f"{url}{path}", headers=_headers(), json=data, timeout=timeout)
        if res.status_code < 400:
            return res.json()
        detail = "Unknown error"
        try:
            detail = res.json().get("detail", detail)
        except Exception:
            pass
        console.print(f"[red]Error ({res.status_code}): {detail}[/red]")
        return None
    except httpx.RequestError as e:
        console.print(f"[red]Connection error: {e}[/red]")
        return None


def upload_file(path: str, endpoint: str, field_name: str = "file",
                extra_fields: dict | None = None, desc: str = "Uploading") -> dict | None:
    """Upload a file with progress bar. Returns API response or None."""
    url = get_api_url()
    filepath = Path(path)
    if not filepath.exists():
        console.print(f"[red]File not found: {path}[/red]")
        return None

    file_size = filepath.stat().st_size
    size_mb = file_size / (1024 * 1024)

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task(f"{desc} ({size_mb:.0f} MB)", total=file_size)

        class _ProgressReader:
            """File-like wrapper that updates a progress bar as bytes are read.
            httpx.files=... needs an object with .read(size), not a generator."""
            def __init__(self, fp, progress, task):
                self.fp = fp
                self.progress = progress
                self.task = task

            def read(self, size=-1):
                chunk = self.fp.read(size) if size != -1 else self.fp.read()
                if chunk:
                    self.progress.update(self.task, advance=len(chunk))
                return chunk

        with open(filepath, "rb") as f:
            headers = _headers()
            fields = extra_fields or {}
            reader = _ProgressReader(f, progress, task)

            try:
                # Stream file in chunks to avoid loading entire file into memory
                # (Docker images can be multiple GB)
                files_dict = {field_name: (filepath.name, reader, "application/octet-stream")}
                data_dict = {k: str(v) for k, v in fields.items()} if fields else None

                with httpx.Client(timeout=httpx.Timeout(600.0, connect=30.0)) as client:
                    res = client.post(
                        f"{url}{endpoint}",
                        headers=headers,
                        files=files_dict,
                        data=data_dict,
                        timeout=httpx.Timeout(600.0, connect=30.0),
                    )

                if res.status_code < 400:
                    return res.json()

                detail = "Upload failed"
                try:
                    detail = res.json().get("detail", detail)
                except Exception:
                    pass
                console.print(f"[red]Error ({res.status_code}): {detail}[/red]")
                return None

            except httpx.RequestError as e:
                console.print(f"[red]Upload failed: {e}[/red]")
                return None


def upload_direct_to_gcs(
    path: str,
    data_type: str,
    slug: str,
    phase_id: str,
    desc: str = "Uploading",
) -> dict | None:
    """Upload a file directly to GCS using a POST Policy from the backend.
    Three steps:
      1. Request signed POST Policy from backend
      2. POST file directly to GCS (streams, no buffering)
      3. Notify backend that upload is complete

    This avoids buffering the file through the backend for large (multi-GB) uploads.
    Returns API response from /upload-complete or None on failure.
    """
    filepath = Path(path)
    if not filepath.exists():
        console.print(f"[red]File not found: {path}[/red]")
        return None

    file_size = filepath.stat().st_size
    size_mb = file_size / (1024 * 1024)
    size_gb = file_size / (1024 * 1024 * 1024)
    size_label = f"{size_gb:.1f} GB" if size_gb >= 1 else f"{size_mb:.0f} MB"

    # Step 1: request POST Policy from backend (include size so backend caps policy to declared size)
    policy = api_post(
        f"/challenges/{slug}/phases/{phase_id}/data/upload-url",
        data={"data_type": data_type, "filename": filepath.name, "size_bytes": file_size},
        timeout=30,
    )
    if not policy:
        return None

    upload_id = policy.get("upload_id")
    gcs_url = policy.get("url")
    fields = policy.get("fields", {})

    if not gcs_url or not upload_id:
        console.print("[red]Backend returned invalid upload session[/red]")
        return None

    # Step 2: POST file directly to GCS with progress bar
    console.print(f"[dim]Uploading to GCS ({size_label})...[/dim]")
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=console,
        ) as progress:
            task = progress.add_task(f"{desc} ({size_label})", total=file_size)

            class _ProgressReader:
                def __init__(self, fp, progress, task):
                    self.fp = fp
                    self.progress = progress
                    self.task = task

                def read(self, size=-1):
                    chunk = self.fp.read(size) if size != -1 else self.fp.read()
                    if chunk:
                        self.progress.update(self.task, advance=len(chunk))
                    return chunk

            with open(filepath, "rb") as f:
                reader = _ProgressReader(f, progress, task)
                # GCS POST Policy requires specific field order: policy fields first, file last
                files_dict = {
                    **{k: (None, v) for k, v in fields.items()},
                    "file": (filepath.name, reader, fields.get("content-type", "application/octet-stream")),
                }
                # 24h timeout — enough for 250GB+ on slow connections
                with httpx.Client(timeout=httpx.Timeout(86400.0, connect=30.0)) as client:
                    res = client.post(gcs_url, files=files_dict)

            if res.status_code >= 400:
                console.print(f"[red]GCS upload failed ({res.status_code}): {res.text[:200]}[/red]")
                # Try to abort the session so the key can be reused
                _abort_upload(slug, phase_id, upload_id)
                return None

    except KeyboardInterrupt:
        console.print("\n[yellow]Upload cancelled. Cleaning up...[/yellow]")
        _abort_upload(slug, phase_id, upload_id)
        raise
    except httpx.RequestError as e:
        console.print(f"[red]Upload failed: {e}[/red]")
        _abort_upload(slug, phase_id, upload_id)
        return None

    # Step 3: notify backend that upload is complete
    console.print("[dim]Verifying upload...[/dim]")
    complete = api_post(
        f"/challenges/{slug}/phases/{phase_id}/data/upload-complete",
        data={"upload_id": upload_id},
        timeout=60,
    )
    return complete


def _abort_upload(slug: str, phase_id: str, upload_id: str):
    """Best-effort abort of a direct upload: tells backend to delete the temp blob."""
    try:
        api_post(
            f"/challenges/{slug}/phases/{phase_id}/data/upload-abort",
            data={"upload_id": upload_id},
            timeout=10,
        )
    except Exception:
        pass


def poll_status(endpoint: str, key: str = "status", target: str = "ready",
                fail_values: set | None = None, interval: float = 3.0,
                timeout: float = 600.0, desc: str = "Processing") -> str | None:
    """Poll an endpoint until status reaches target or fails. Returns final status."""
    import time
    fail_values = fail_values or {"failed", "rejected"}
    url = get_api_url()
    start = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn(f"[progress.description]{desc}..."),
        TimeElapsedColumn(),
        console=console,
    ) as progress:
        task = progress.add_task(desc, total=None)
        while time.time() - start < timeout:
            try:
                res = httpx.get(f"{url}{endpoint}", headers=_headers(), timeout=10)
                if res.status_code == 200:
                    status = res.json().get(key, "")
                    if status == target:
                        return status
                    if status in fail_values:
                        return status
            except Exception:
                pass
            time.sleep(interval)

    console.print(f"[yellow]Timed out waiting for {target}[/yellow]")
    return None
