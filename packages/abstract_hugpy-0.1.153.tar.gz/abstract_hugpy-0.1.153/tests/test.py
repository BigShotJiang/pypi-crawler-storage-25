from imports import *
pdf_path = "/srv/media/thedailydialectics/pdfs/economics/Technical_Analysis/Technical_Analysis.pdf"
result = analyze_pdf(pdf_path)
input(result)
