"""Validate, format, and identify UK Companies House company numbers.

"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

__version__ = "1.0.0"
__all__ = [
    "CompanyNumberInfo",
    "validate",
    "parse",
    "format_number",
    "get_jurisdiction",
    "get_type",
    "get_prefix",
    "equals",
    "prefixes",
]

PREFIXES: dict[str, dict[str, str]] = {
    "": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "ltd",
        "type_name": "Private Limited Company",
    },
    "SC": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "ltd",
        "type_name": "Private Limited Company",
    },
    "NI": {
        "jurisdiction": "northern-ireland",
        "jurisdiction_name": "Northern Ireland",
        "type": "ltd",
        "type_name": "Private Limited Company",
    },
    "R": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "ltd",
        "type_name": "Old Public Company (pre-1981)",
    },
    "OC": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "llp",
        "type_name": "Limited Liability Partnership",
    },
    "SO": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "llp",
        "type_name": "Limited Liability Partnership",
    },
    "NC": {
        "jurisdiction": "northern-ireland",
        "jurisdiction_name": "Northern Ireland",
        "type": "llp",
        "type_name": "Limited Liability Partnership",
    },
    "FC": {
        "jurisdiction": "uk",
        "jurisdiction_name": "United Kingdom",
        "type": "overseas",
        "type_name": "Overseas Company",
    },
    "SF": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "overseas",
        "type_name": "Overseas Company (Scotland registered)",
    },
    "NF": {
        "jurisdiction": "northern-ireland",
        "jurisdiction_name": "Northern Ireland",
        "type": "overseas",
        "type_name": "Overseas Company (Northern Ireland registered)",
    },
    "GE": {
        "jurisdiction": "uk",
        "jurisdiction_name": "United Kingdom",
        "type": "eeig",
        "type_name": "European Economic Interest Grouping",
    },
    "LP": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "lp",
        "type_name": "Limited Partnership",
    },
    "SL": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "lp",
        "type_name": "Limited Partnership",
    },
    "NL": {
        "jurisdiction": "northern-ireland",
        "jurisdiction_name": "Northern Ireland",
        "type": "lp",
        "type_name": "Limited Partnership",
    },
    "IP": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "industrial-provident",
        "type_name": "Industrial & Provident Society",
    },
    "SP": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "industrial-provident",
        "type_name": "Industrial & Provident Society (Scotland)",
    },
    "NP": {
        "jurisdiction": "northern-ireland",
        "jurisdiction_name": "Northern Ireland",
        "type": "industrial-provident",
        "type_name": "Industrial & Provident Society (Northern Ireland)",
    },
    "RC": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "royal-charter",
        "type_name": "Royal Charter Company",
    },
    "SR": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "royal-charter",
        "type_name": "Royal Charter Company (Scotland)",
    },
    "NR": {
        "jurisdiction": "northern-ireland",
        "jurisdiction_name": "Northern Ireland",
        "type": "royal-charter",
        "type_name": "Royal Charter Company (Northern Ireland)",
    },
    "SE": {
        "jurisdiction": "uk",
        "jurisdiction_name": "United Kingdom",
        "type": "se",
        "type_name": "Societas Europaea",
    },
    "CE": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "community-interest",
        "type_name": "Community Interest Company",
    },
    "CS": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "community-interest",
        "type_name": "Community Interest Company (Scotland)",
    },
    "AC": {
        "jurisdiction": "england-wales",
        "jurisdiction_name": "England & Wales",
        "type": "assurance",
        "type_name": "Assurance Company",
    },
    "SA": {
        "jurisdiction": "scotland",
        "jurisdiction_name": "Scotland",
        "type": "assurance",
        "type_name": "Assurance Company (Scotland)",
    },
    "NA": {
        "jurisdiction": "northern-ireland",
        "jurisdiction_name": "Northern Ireland",
        "type": "assurance",
        "type_name": "Assurance Company (Northern Ireland)",
    },
    "OE": {
        "jurisdiction": "uk",
        "jurisdiction_name": "United Kingdom",
        "type": "overseas",
        "type_name": "Overseas Entity",
    },
}


@dataclass(frozen=True, slots=True)
class CompanyNumberInfo:
    number: str
    prefix: str
    numeric_part: str
    jurisdiction: str
    jurisdiction_name: str
    type: str
    type_name: str


def parse(number: str) -> Optional[CompanyNumberInfo]:
    """Parse a UK company number into structured information."""
    if not isinstance(number, str):
        return None
    cleaned = re.sub(r"[\s.\-]", "", number.strip()).upper()
    if not cleaned:
        return None

    # 2-letter prefix + 6 digits
    m = re.match(r"^([A-Z]{2})(\d{6})$", cleaned)
    if m:
        prefix, digits = m.group(1), m.group(2)
        info = PREFIXES.get(prefix)
        if info:
            return CompanyNumberInfo(
                number=prefix + digits, prefix=prefix, numeric_part=digits, **info
            )
        return None

    # 1-letter prefix + 7 digits (R prefix)
    m = re.match(r"^([A-Z])(\d{7})$", cleaned)
    if m:
        prefix, digits = m.group(1), m.group(2)
        info = PREFIXES.get(prefix)
        if info:
            return CompanyNumberInfo(
                number=prefix + digits, prefix=prefix, numeric_part=digits, **info
            )
        return None

    # Pure digits (England & Wales)
    m = re.match(r"^(\d+)$", cleaned)
    if m:
        digits = m.group(1)
        if len(digits) > 8:
            return None
        padded = digits.zfill(8)
        if padded == "00000000":
            return None
        return CompanyNumberInfo(
            number=padded, prefix="", numeric_part=padded, **PREFIXES[""]
        )

    return None


def validate(number: str) -> bool:
    """Check if a string is a valid UK company number format."""
    return parse(number) is not None


def format_number(number: str) -> Optional[str]:
    """Format a company number to its canonical form."""
    info = parse(number)
    return info.number if info else None


def get_jurisdiction(number: str) -> Optional[str]:
    """Get the jurisdiction for a company number."""
    info = parse(number)
    return info.jurisdiction if info else None


def get_type(number: str) -> Optional[str]:
    """Get the company type for a company number."""
    info = parse(number)
    return info.type if info else None


def get_prefix(number: str) -> Optional[str]:
    """Get the prefix from a company number."""
    info = parse(number)
    return info.prefix if info else None


def equals(a: str, b: str) -> bool:
    """Check if two company numbers refer to the same company."""
    fa = format_number(a)
    fb = format_number(b)
    if fa is None or fb is None:
        return False
    return fa == fb


def prefixes() -> list[dict[str, str]]:
    """Get all known prefixes and their descriptions."""
    result = []
    for prefix, info in sorted(PREFIXES.items()):
        if prefix == "":
            continue
        result.append({"prefix": prefix, **info})
    return result
