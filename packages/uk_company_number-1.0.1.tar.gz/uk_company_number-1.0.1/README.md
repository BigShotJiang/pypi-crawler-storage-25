# uk-company-number

**This package has been discontinued and is no longer maintained.**

Deprecated as of 2026-04-22. No further updates, bug fixes, or support will be provided.
