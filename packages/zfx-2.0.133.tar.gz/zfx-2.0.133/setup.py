from pathlib import Path
from textwrap import dedent

from setuptools import find_packages, setup


当前目录 = Path(__file__).resolve().parent
README路径 = 当前目录 / "README.md"

长描述 = README路径.read_text(encoding="utf-8") if README路径.exists() else dedent(
    """
    ZFX 是一个中文命名的 Python 多功能工具包，覆盖文本、时间、文件、目录、
    系统、进程、网络请求、网页提取、数据库、邮件与自动化等常见场景。
    """
).strip()


setup(
    name="zfx",
    version="2.0.133",
    packages=find_packages(),
    include_package_data=False,
    author="zengfengxiang",
    author_email="424491679@qq.com",
    description=(
        "ZFX 是一个中文命名的 Python 多功能工具包，覆盖文本、时间、文件、"
        "目录、系统、进程、网络请求、网页提取、数据库、邮件与自动化等常见场景。"
    ),
    long_description=长描述,
    long_description_content_type="text/markdown",
    url="",
    keywords=[
        "zfx",
        "python",
        "工具包",
        "中文函数",
        "文本处理",
        "文件处理",
        "系统工具",
        "自动化",
        "网络请求",
    ],
    install_requires=[
        "selenium",  # 用于支持库：谷歌填表
        "pyotp",  # 用于支持库：谷歌填表
        "pymysql",  # 用于支持库：mysqlx
        "pyinstaller",  # 用于支持库：文件（封装 EXE）
        "pyperclip",  # 用于支持库：系统（剪贴板）
        "requests",  # 用于支持库：http、网页协议、公共API、系统
        "psutil",  # 用于支持库：进程
        "beautifulsoup4",  # 用于支持库：html
    ],
)
