from __future__ import annotations
from typing import Any, Dict, Optional, Union
import requests


def GET(
    url: str,
    params: Optional[Dict[str, Any]] = None,
    headers: Optional[Dict[str, str]] = None,
    cookies: Optional[Dict[str, str]] = None,
    timeout: Union[int, float] = 10,
    allow_redirects: bool = True,
    verify: bool = True,
    proxies: Optional[Dict[str, str]] = None,
) -> Optional[requests.Response]:
    """
    发送 HTTP GET 请求并返回响应对象（requests.Response）。

    本函数面向“工具库”场景设计，强调稳定与可控：
        - 成功返回 requests.Response
        - 任意异常（网络错误/超时/参数错误等）返回 None
        - 函数内部不抛出异常

    Args:
        url (str): 目标 URL，例如 "https://example.com/api".
        params (Optional[Dict[str, Any]]): Query 参数字典，会自动拼接到 URL 上。
        headers (Optional[Dict[str, str]]): 请求头字典，例如 {"User-Agent": "..."}。
        cookies (Optional[Dict[str, str]]): Cookie 字典。
        timeout (Union[int, float]): 超时时间（秒），例如 10 或 3.5。
        allow_redirects (bool): 是否允许自动跟随重定向。
        verify (bool): 是否验证 HTTPS 证书。为 False 时可能降低安全性。
        proxies (Optional[Dict[str, str]]): 代理配置，例如：
            {"http": "http://127.0.0.1:7890", "https": "http://127.0.0.1:7890"}。

    Returns:
        Optional[requests.Response]:
            - 成功：返回 响应对象（requests.Response）
            - 失败：返回 None
    """
    if not isinstance(url, str) or not url.strip():
        return None

    try:
        响应 = requests.get(
            url=url,
            params=params,
            headers=headers,
            cookies=cookies,
            timeout=timeout,
            allow_redirects=allow_redirects,
            verify=verify,
            proxies=proxies,
        )
        return 响应
    except Exception:
        return None