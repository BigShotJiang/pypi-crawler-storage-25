from __future__ import annotations

from typing import Optional, Any


def 取状态码(响应对象: Any) -> Optional[int]:
    """
    从 HTTP 响应对象中安全获取状态码。

    常见状态码说明：
        - 200：请求成功，服务器正常返回了结果（最常见）
        - 201：资源创建成功（常见于 POST / PUT）
        - 204：请求成功，但无返回内容（无响应体）

        - 301：资源被永久重定向
        - 302：资源被临时重定向

        - 400：请求参数错误 / 格式不正确
        - 401：未授权（通常需要登录或鉴权）
        - 403：已授权，但没有访问权限
        - 404：请求的资源不存在（URL 错误或资源已删除）
        - 429：请求过于频繁，被限流

        - 500：服务器内部错误
        - 502：网关错误（上游服务异常）
        - 503：服务不可用（服务器维护或过载）

    设计约定：
        - 支持 requests.Response 等常见响应对象
        - 当响应对象为 None 或不具备状态码属性时，返回 None
        - 函数内部不抛出异常

    Args:
        响应对象 (Any): HTTP 请求返回的响应对象。

    Returns:
        Optional[int]:
            - 成功：返回 HTTP 状态码，例如 200、404
            - 失败：返回 None
    """
    try:
        状态码 = getattr(响应对象, "status_code", None)
        if isinstance(状态码, int):
            return 状态码
        return None
    except Exception:
        return None