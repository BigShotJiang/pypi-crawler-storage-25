from .DELETE import DELETE
from .GET import GET
from .GET_并发 import GET_并发
from .GET_直到成功 import GET_直到成功
from .POST import POST
from .POST_并发 import POST_并发
from .POST_直到成功 import POST_直到成功
from .取响应文本 import 取响应文本
from .取状态码 import 取状态码
from .图片下载 import 图片下载
from .生成随机UA import 生成随机UA

