from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Any, List, Optional, Sequence, Union


PathLike = Union[str, Path]


def 查询_保存表数据到文本(
    连接对象,
    表名: str,
    字段列表: Optional[Union[Sequence[str], PathLike]] = None,
    保存路径: Optional[PathLike] = None,
    *,
    编码: str = "utf-8",
) -> bool:
    """查询指定 MySQL 表的数据，并按 JSON Lines 格式保存到本地文本文件。

    功能说明:
        - 可指定字段列表，仅导出这些字段；
        - 不传字段列表时，默认导出整张表的所有字段；
        - 保存格式为 JSON Lines：一行一条记录，每行是一个 JSON 对象；
        - 字符串中的逗号、制表符、换行等会被 JSON 自动转义，避免分隔符混淆；
        - 查询失败、参数非法或写入失败时返回 False；
        - 不打印、不抛异常。

    Args:
        连接对象: 已建立的 MySQL 数据库连接对象。
        表名 (str): 要查询的表名（仅允许字母、数字、下划线）。
        字段列表 (Sequence[str] | str | Path | None):
            - 传入字段名序列时，仅导出这些字段，例如 ["slug", "os", "drm"]；
            - 传入 None 时，导出整张表；
            - 也支持省略字段列表，将本参数直接作为 保存路径 使用。
        保存路径 (str | Path | None): 文本文件保存路径。
        编码 (str): 写入文件使用的编码，默认 utf-8。

    Returns:
        bool:
            - True  : 查询并保存成功（即使结果为空，也会创建空文件）。
            - False : 参数非法、查询失败或写入失败。

    Examples:
        查询_保存表数据到文本(连接对象, "game", ["slug", "os", "drm"], r"C:\\数据.txt")
        查询_保存表数据到文本(连接对象, "game", r"C:\\数据.txt")
    """
    try:
        if not re.fullmatch(r"[A-Za-z0-9_]+", 表名):
            return False

        if 保存路径 is None:
            if isinstance(字段列表, (str, Path)):
                保存路径 = 字段列表
                字段列表 = None
            else:
                return False

        输出路径 = Path(保存路径)
        if not str(输出路径).strip():
            return False

        查询字段列表: Optional[List[str]] = None
        if 字段列表 is not None:
            if isinstance(字段列表, (str, Path)):
                return False

            查询字段列表 = list(字段列表)
            if not 查询字段列表:
                return False

            for 字段名 in 查询字段列表:
                if not isinstance(字段名, str) or not re.fullmatch(r"[A-Za-z0-9_]+", 字段名):
                    return False

        if 查询字段列表 is None:
            sql = f"SELECT * FROM `{表名}`"
        else:
            字段表达式 = ", ".join(f"`{字段名}`" for 字段名 in 查询字段列表)
            sql = f"SELECT {字段表达式} FROM `{表名}`"

        with 连接对象.cursor() as 游标:
            游标.execute(sql)
            行列表 = 游标.fetchall() or []
            字段名列表 = [列信息[0] for 列信息 in (游标.description or [])]

        输出路径.parent.mkdir(parents=True, exist_ok=True)
        with 输出路径.open("w", encoding=编码, newline="\n") as 文件:
            for 行 in 行列表:
                记录 = {
                    字段名: _转换为可JSON序列化(值)
                    for 字段名, 值 in zip(字段名列表, 行)
                }
                文件.write(json.dumps(记录, ensure_ascii=False, default=str))
                文件.write("\n")

        return True

    except Exception:
        return False


def _转换为可JSON序列化(值: Any) -> Any:
    """保留常见 JSON 原生类型，其他类型交给 json.dumps 的 default=str 处理。"""
    if 值 is None or isinstance(值, (str, int, float, bool, list, tuple, dict)):
        return 值
    return 值
