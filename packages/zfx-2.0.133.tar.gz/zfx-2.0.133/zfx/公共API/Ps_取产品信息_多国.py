from __future__ import annotations
import time
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
import base64
import json
import zlib

语言映射 = (
    "eJw1z0EOgjAQBdCrkK6dC7grUAoSCqFtIOxMxKgLYpCVxrubPw7Ll5+Z+fNRulfHRM0v0r06JEpH5kI6gimnz41STjMtaaaZrcxmLZgb8DJTbkDjJTUeLHjVdaWCV9lUVtkULGvwfaOyBisnaeWYAbxvVAXw1IGPM506sBnlUDOCzsqss6Df6ZmBa2wrBa4RBrkbBjD+Oy8UufO0/ztp9f0Bu45EVA=="
)

_PS_URL = "aHR0cHM6Ly93ZWIubnAucGxheXN0YXRpb24uY29tL2FwaS9ncmFwaHFsL3YxL29w"

def _取PS接口URL() -> str:
    try:
        return base64.b64decode(_PS_URL).decode("utf-8")
    except Exception:
        return ""

def 取语言映射() -> Dict[str, str]:
    try:
        二进制 = base64.b64decode(语言映射)
        原始数据 = zlib.decompress(二进制)
        data = json.loads(原始数据.decode("utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

_国家到语言映射: Dict[str, str] = 取语言映射()


def Ps_取产品信息_多国(
    产品ID: str,
    国家列表: List[str],
    最大重试次数: int = 3,
    超时时间: int = 10,
) -> Dict[str, Any]:
    """
    获取 Play Store 指定产品在多个国家/地区站点的页面数据。

    本函数用于根据用户给定的国家代码列表，访问对应地区的 Play Store
    产品页面（concept 页面），并返回每个国家成功获取到的原始响应内容（文本）。

    支持的国家/地区代码如下（仅支持下列代码）：
        ["AR", "AU", "BR", "CA", "CO", "DE", "ES", "FR", "GB", "HK", "IN","IT", "JP", "MX", "NG", "SG", "TR", "TW", "US", "ZA"]

    关键行为说明：
    - 单个国家请求失败时会进行重试，以提升成功率；重试次数由 最大重试次数 控制。
    - 仅返回请求成功（HTTP 200）的国家数据；不支持的国家代码或多次失败的国家会被忽略，
      不会出现在返回结果中。
    - 函数内部会捕获所有异常；若执行过程中出现任何异常，将直接返回空字典，
      以保证调用流程稳定。

    Args:
        产品ID: Play Store 产品 ID（concept ID），例如 "12345678"。
        国家列表: 国家/地区代码列表，例如 ["US", "TR", "JP"]。
        最大重试次数: 每个国家请求失败后的最大重试次数，默认 3。
        超时时间: 单次 HTTP 请求超时时间（秒），默认 10。

    Returns:
        以国家/地区代码为键、该国家请求成功的页面响应文本为值的字典。
        若发生异常或全部失败，则返回空字典。
    """
    try:
        def _请求单国家(国家代码: str) -> Optional[Dict[str, Any]]:
            try:
                override_locale = _国家到语言映射.get(国家代码)
                if not override_locale:
                    return None

                url = _取PS接口URL()
                if not url:
                    return None

                # ✅ 与网页抓包一致
                params = {
                    "operationName": "conceptRetrieveForCtasWithPrice",
                    "variables": f'{{"conceptId":"{产品ID}"}}',
                    "extensions": (
                        '{"persistedQuery":{"version":1,'
                        '"sha256Hash":"4ec6effdcdb6e041936c79acecd44aeea347ae3055d2b23ee2c794084b6e9c60"}}'
                    ),
                }

                headers = {
                    "Accept": "*/*",
                    "Referer": "https://store.playstation.com/",
                    "User-Agent": "Mozilla/5.0",
                    "Content-Type": "application/json",
                    "x-psn-store-locale-override": override_locale.lower(),
                    "Accept-Language": "en-US,en;q=0.9",
                }

                for _ in range(max(1, 最大重试次数)):
                    try:
                        r = requests.get(url, params=params, headers=headers, timeout=超时时间)
                        if r.status_code == 200:
                            data = r.json()
                            if isinstance(data, dict) and not data.get("errors"):
                                return data
                    except Exception:
                        pass
                    time.sleep(0.5)

                return None
            except Exception:
                return None

        if not 国家列表:
            return {}

        结果: Dict[str, Any] = {}
        max_workers = min(len(国家列表), 32)

        with ThreadPoolExecutor(max_workers=max_workers) as 执行器:
            任务映射 = {执行器.submit(_请求单国家, 国家): 国家 for 国家 in 国家列表}

            for 任务 in as_completed(任务映射):
                try:
                    国家 = 任务映射[任务]
                    数据 = 任务.result()
                    if 数据 is not None:
                        结果[国家] = 数据
                except Exception:
                    return {}

        return 结果
    except Exception:
        return {}