from typing import Any, Callable, Dict

def 筛选键值对(
    数据: Dict[str, Any],
    条件函数: Callable[[str, Any], bool]
) -> Dict[str, Any]:
    """按条件函数筛选字典中的键值对，并返回新字典。

    功能说明:
        - 这个函数用于按条件函数筛选字典中的键值对，并返回新字典。
        - 它把字典里的常见操作单独封装好了，调用时不用自己反复写判断逻辑。
        - 当输入不符合要求时，函数会返回空字典或约定结果，避免程序因为异常中断。

    Args:
        数据 (dict): 原始字典对象。
        条件函数 (Callable[[str, Any], bool]): 筛选判断函数。
        - 示例： lambda 键, 值: 键.startswith("user_")
        - 示例： lambda 键, 值: isinstance(值, int)

    Returns:
        dict[str, Any]:
        - 成功：返回筛选后的新字典；
        - 失败：返回空字典 {}。"""
    try:
        if not isinstance(数据, dict):
            return {}

        if not callable(条件函数):
            return {}

        return {
            str(键): 值
            for 键, 值 in 数据.items()
            if 条件函数(str(键), 值)
        }
    except Exception:
        return {}


if __name__ == "__main__":
    print("===== 示例1：基础用法 =====")
    数据 = {"名称": "zfx", "年龄": 18, "城市": "上海"}
    条件函数 = lambda 键, 值: 键.startswith("名")
    print("结果:", 筛选键值对(数据, 条件函数))
    print("数据:", 数据)

    print("\n===== 示例2：常见变体 =====")
    数据 = {"name": "zfx", "phone": None, "items": [1, 2]}
    条件函数 = lambda 键, 值: isinstance(值, int)
    print("结果:", 筛选键值对(数据, 条件函数))
    print("数据:", 数据)

    print("\n===== 示例3：边界情况 =====")
    数据 = {}
    条件函数 = lambda 键, 值: True
    print("结果:", 筛选键值对(数据, 条件函数))
    print("数据:", 数据)

    print("\n===== 示例4：异常情况 =====")
    数据 = []
    条件函数 = 123
    print("结果:", 筛选键值对(数据, 条件函数))
    print("数据:", 数据)

    print("\n===== 示例5：特殊值情况 =====")
    数据 = {"名称": "", "备注": None, "标签": []}
    条件函数 = lambda 键, 值: 值 not in (None, "")
    print("结果:", 筛选键值对(数据, 条件函数))
    print("数据:", 数据)

    print("\n===== 示例6：应用场景-整理业务字典 =====")
    数据 = {"订单号": "A001", "状态": "待发货", "数量": 3}
    条件函数 = lambda 键, 值: 键 in ("订单号", "状态")
    print("结果:", 筛选键值对(数据, 条件函数))
    print("数据:", 数据)
