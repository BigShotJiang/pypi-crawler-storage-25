from typing import Any, Dict

def 删除键(
    数据: Dict[str, Any],
    键: Any
) -> bool:
    """从字典中安全地删除指定键。

    功能说明:
        - 这个函数用于从字典中安全地删除指定键。
        - 它主要返回 True 或 False，适合直接写在 if 判断里控制后续流程。
        - 当输入不符合要求时，函数会直接返回 False，方便你快速判断这次操作有没有成功。

    Args:
        数据 (dict): 目标字典对象。
        键: 需要删除的键，内部将转换为字符串。

    Returns:
        bool:
        True  - 键存在且已成功删除；
        False - 键不存在、数据非法或发生异常。"""
    try:
        if not isinstance(数据, dict):
            return False

        键名 = str(键)

        if 键名 not in 数据:
            return False

        del 数据[键名]
        return True
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：基础用法 =====")
    数据 = {"名称": "zfx", "年龄": 18, "城市": "上海"}
    键 = "名称"
    print("结果:", 删除键(数据, 键))
    print("数据:", 数据)

    print("\n===== 示例2：常见变体 =====")
    数据 = {"name": "zfx", "phone": None, "items": [1, 2]}
    键 = "name"
    print("结果:", 删除键(数据, 键))
    print("数据:", 数据)

    print("\n===== 示例3：边界情况 =====")
    数据 = {}
    键 = "不存在"
    print("结果:", 删除键(数据, 键))
    print("数据:", 数据)

    print("\n===== 示例4：异常情况 =====")
    数据 = []
    键 = "名称"
    print("结果:", 删除键(数据, 键))
    print("数据:", 数据)

    print("\n===== 示例5：特殊值情况 =====")
    数据 = {"名称": "", "备注": None, "标签": []}
    键 = "备注"
    print("结果:", 删除键(数据, 键))
    print("数据:", 数据)

    print("\n===== 示例6：应用场景-整理业务字典 =====")
    数据 = {"订单号": "A001", "状态": "待发货", "数量": 3}
    键 = "状态"
    print("结果:", 删除键(数据, 键))
    print("数据:", 数据)
