from __future__ import annotations

from typing import Any, List, Sequence, Union


_路径类型 = Union[str, Sequence[Any]]


def 确保路径存在(
    数据: Any,
    键路径: _路径类型,
    分隔符: str = ".",
    键转字符串: bool = True,
) -> bool:
    """确保嵌套结构中的指定路径存在，不存在时自动补齐。

    功能说明:
        - 这个函数用于确保嵌套结构中的指定路径存在，不存在时自动补齐。
        - 当你准备往多层结构里写值时，可以先调用它把中间层结构补好，后面再写值就会省心很多。
        - 它适合处理接口组装、配置初始化、构造多层业务数据这类场景。

    Args:
        数据: 通常为 dict 或 list 的嵌套结构。
        键路径: 路径字符串或路径序列。
            - 字符串示例： "a.b.0.c"
            - 列表示例： ["a", "b", 0, "c"]
        分隔符: 字符串路径的分隔符，默认 "."。
        键转字符串: 当走 dict 路径时，是否将键统一转为 str。默认 True。

    Returns:
        路径已存在或补齐成功时返回 ``True``；失败时返回 ``False``。
    """
    try:
        if isinstance(键路径, str):
            if 键路径 == "":
                return False
            路径列表: List[Any] = 键路径.split(分隔符)
        elif isinstance(键路径, (list, tuple)):
            if len(键路径) == 0:
                return False
            路径列表 = list(键路径)
        else:
            return False

        if not isinstance(数据, (dict, list)):
            return False

        当前 = 数据

        for 索引位置, 段 in enumerate(路径列表):
            是否最后一段 = 索引位置 == len(路径列表) - 1
            下一段 = None if 是否最后一段 else 路径列表[索引位置 + 1]

            if isinstance(当前, dict):
                键名 = str(段) if 键转字符串 else 段

                if 键名 not in 当前:
                    if 是否最后一段:
                        当前[键名] = {}
                    else:
                        try:
                            需要列表 = not isinstance(下一段, bool) and (
                                isinstance(下一段, int) or str(下一段).isdigit()
                            )
                        except Exception:
                            需要列表 = False
                        当前[键名] = [] if 需要列表 else {}

                if not isinstance(当前[键名], (dict, list)):
                    return 是否最后一段

                当前 = 当前[键名]
                continue

            if isinstance(当前, list):
                try:
                    目标索引 = 段 if isinstance(段, int) else int(str(段))
                except Exception:
                    return False

                if 目标索引 < 0:
                    return False

                while len(当前) <= 目标索引:
                    当前.append(None)

                if 当前[目标索引] is None:
                    if 是否最后一段:
                        当前[目标索引] = {}
                    else:
                        try:
                            需要列表 = not isinstance(下一段, bool) and (
                                isinstance(下一段, int) or str(下一段).isdigit()
                            )
                        except Exception:
                            需要列表 = False
                        当前[目标索引] = [] if 需要列表 else {}

                if not isinstance(当前[目标索引], (dict, list)):
                    return 是否最后一段

                当前 = 当前[目标索引]
                continue

            return False

        return True
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：基础用法 =====")
    数据 = {}
    print("结果:", 确保路径存在(数据, "用户.信息.0.城市"))
    print("数据:", 数据)

    print("\n===== 示例2：使用列表路径 =====")
    数据 = {}
    print("结果:", 确保路径存在(数据, ["用户", "信息", 0, "城市"]))
    print("数据:", 数据)

    print("\n===== 示例3：边界情况-空路径 =====")
    数据 = {}
    print("结果:", 确保路径存在(数据, ""))
    print("数据:", 数据)

    print("\n===== 示例4：异常情况-数据不是字典或列表 =====")
    数据 = "不是字典"
    print("结果:", 确保路径存在(数据, "用户.信息.0.城市"))
    print("数据:", 数据)

    print("\n===== 示例5：特殊值情况-已有结构时直接通过 =====")
    数据 = {"用户": {"信息": [{"城市": "上海"}]}}
    print("结果:", 确保路径存在(数据, "用户.信息.0.城市"))
    print("数据:", 数据)

    print("\n===== 示例6：应用场景-初始化订单收货信息结构 =====")
    数据 = {}
    print("结果:", 确保路径存在(数据, "订单.收货信息.0.联系人"))
    print("数据:", 数据)
