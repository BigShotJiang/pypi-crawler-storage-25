from typing import Any, Dict

def 是否包含子集(
    主字典: Dict[str, Any],
    子集字典: Dict[str, Any]
) -> bool:
    """判断主字典是否包含子集字典中的全部键值对。

    功能说明:
        - 这个函数用于判断主字典是否包含子集字典中的全部键值对。
        - 它主要返回 True 或 False，适合直接写在 if 判断里控制后续流程。
        - 当输入不符合要求时，函数会直接返回 False，方便你快速判断这次操作有没有成功。

    Args:
        主字典 (dict): 用于包含判断的主字典。
        子集字典 (dict): 需要被验证是否包含的子集字典。

    Returns:
        bool:
        True  - 主字典包含子集字典；
        False - 不包含或参数非法。"""
    try:
        if not isinstance(主字典, dict):
            return False

        if not isinstance(子集字典, dict):
            return False

        主值映射 = {str(键): 值 for 键, 值 in 主字典.items()}

        for 键, 值 in 子集字典.items():
            键名 = str(键)
            if 键名 not in 主值映射:
                return False
            if 主值映射[键名] != 值:
                return False

        return True
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：基础用法 =====")
    主字典 = {"a": 1, "b": 2, "c": 3}
    子集字典 = {"b": 2, "c": 4, "d": 5}
    print("结果:", 是否包含子集(主字典, 子集字典))
    print("主字典:", 主字典)
    print("子集字典:", 子集字典)

    print("\n===== 示例2：常见变体 =====")
    主字典 = {"名称": "zfx", "城市": "上海"}
    子集字典 = {"城市": "上海", "名称": "zfx"}
    print("结果:", 是否包含子集(主字典, 子集字典))
    print("主字典:", 主字典)
    print("子集字典:", 子集字典)

    print("\n===== 示例3：边界情况 =====")
    主字典 = {}
    子集字典 = {}
    print("结果:", 是否包含子集(主字典, 子集字典))
    print("主字典:", 主字典)
    print("子集字典:", 子集字典)

    print("\n===== 示例4：异常情况 =====")
    主字典 = []
    子集字典 = []
    print("结果:", 是否包含子集(主字典, 子集字典))
    print("主字典:", 主字典)
    print("子集字典:", 子集字典)

    print("\n===== 示例5：特殊值情况 =====")
    主字典 = {"配置": {"端口": 3306}, "debug": False}
    子集字典 = {"配置": {"端口": 3306}, "debug": False}
    print("结果:", 是否包含子集(主字典, 子集字典))
    print("主字典:", 主字典)
    print("子集字典:", 子集字典)

    print("\n===== 示例6：应用场景-整理业务字典 =====")
    主字典 = {"订单号": "A001", "状态": "待支付", "金额": 99}
    子集字典 = {"状态": "待支付"}
    print("结果:", 是否包含子集(主字典, 子集字典))
    print("主字典:", 主字典)
    print("子集字典:", 子集字典)
