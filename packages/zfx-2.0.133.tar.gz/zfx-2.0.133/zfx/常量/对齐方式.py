左对齐 = "left"
居中对齐 = "center"
右对齐 = "right"

顶部对齐 = "top"
底部对齐 = "bottom"

左上 = "nw"
上中 = "n"
右上 = "ne"
左中 = "w"
正中 = "center"
右中 = "e"
左下 = "sw"
下中 = "s"
右下 = "se"

水平填充 = "x"
垂直填充 = "y"
双向填充 = "both"

左侧 = "left"
右侧 = "right"
顶部 = "top"
底部 = "bottom"

起始 = "start"
结束 = "end"

