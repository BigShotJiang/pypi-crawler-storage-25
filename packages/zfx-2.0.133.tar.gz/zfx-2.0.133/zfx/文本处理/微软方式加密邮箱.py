def 微软方式加密邮箱(email):
    """
    按常见脱敏方式隐藏邮箱用户名中间部分。

    功能说明:
        - 这个函数用于对邮箱地址做简单脱敏展示。
        - 会保留邮箱用户名开头部分和结尾部分，中间用 ** 替代。
        - 邮箱域名部分会保留不变。
        - 邮箱格式无效或发生异常时返回空字符串。

    Args:
        email (str): 要脱敏的邮箱地址。

    Returns:
        成功时返回脱敏后的邮箱地址；失败时返回空字符串 ""。
    """
    try:
        # 分割邮箱为本地部分和域名部分
        local, domain = email.split("@")

        # 加密本地部分
        if len(local) > 3:
            encrypted_local = local[:2] + "**" + local[-1]
        elif len(local) > 2:
            encrypted_local = local[:2] + "**"
        else:
            encrypted_local = local + "**"

        # 拼接加密后的邮箱
        return f"{encrypted_local}@{domain}"
    except Exception:
        # 返回空字符串表示加密失败
        return ""


if __name__ == "__main__":
    print("===== 示例1：普通邮箱脱敏 =====")
    print("结果:", 微软方式加密邮箱("username@example.com"))

    print("\n===== 示例2：用户名较短的邮箱 =====")
    print("结果:", 微软方式加密邮箱("abc@example.com"))

    print("\n===== 示例3：用户名很短的邮箱 =====")
    print("结果:", 微软方式加密邮箱("a@example.com"))

    print("\n===== 示例4：邮箱格式错误 =====")
    print("结果:", 微软方式加密邮箱("not-email"))

    print("\n===== 示例5：参数异常 =====")
    print("结果:", 微软方式加密邮箱(None))

    print("\n===== 示例6：应用场景-展示用户邮箱但隐藏隐私 =====")
    用户邮箱 = "customer2026@shop.com"
    print("展示邮箱:", 微软方式加密邮箱(用户邮箱))
