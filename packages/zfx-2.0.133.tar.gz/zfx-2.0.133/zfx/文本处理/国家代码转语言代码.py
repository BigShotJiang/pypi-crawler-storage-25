from __future__ import annotations
from typing import Optional

# ISO 3166-1 alpha-2 -> 常见默认 locale（BCP47：language-REGION）
# 统一返回小写：例如 "es-ar"
_国家到语言代码: dict[str, str] = {
    # A
    "AD": "ca-ad",
    "AE": "ar-ae",
    "AF": "fa-af",
    "AG": "en-ag",
    "AI": "en-ai",
    "AL": "sq-al",
    "AM": "hy-am",
    "AO": "pt-ao",
    "AQ": "en-aq",
    "AR": "es-ar",
    "AS": "en-as",
    "AT": "de-at",
    "AU": "en-au",
    "AW": "nl-aw",
    "AX": "sv-ax",
    "AZ": "az-az",

    # B
    "BA": "bs-ba",
    "BB": "en-bb",
    "BD": "bn-bd",
    "BE": "nl-be",   # 常见默认：荷兰语（也可能 fr-be）
    "BF": "fr-bf",
    "BG": "bg-bg",
    "BH": "ar-bh",
    "BI": "fr-bi",
    "BJ": "fr-bj",
    "BL": "fr-bl",
    "BM": "en-bm",
    "BN": "ms-bn",
    "BO": "es-bo",
    "BQ": "nl-bq",
    "BR": "pt-br",
    "BS": "en-bs",
    "BT": "dz-bt",
    "BV": "no-bv",
    "BW": "en-bw",
    "BY": "ru-by",   # 常见软件默认：俄语（也可能 be-by）
    "BZ": "en-bz",

    # C
    "CA": "en-ca",   # 常见默认：英语（也可能 fr-ca）
    "CC": "en-cc",
    "CD": "fr-cd",
    "CF": "fr-cf",
    "CG": "fr-cg",
    "CH": "de-ch",   # 常见默认：德语（也可能 fr-ch/it-ch）
    "CI": "fr-ci",
    "CK": "en-ck",
    "CL": "es-cl",
    "CM": "fr-cm",   # 常见默认：法语（也可能 en-cm）
    "CN": "zh-cn",
    "CO": "es-co",
    "CR": "es-cr",
    "CU": "es-cu",
    "CV": "pt-cv",
    "CW": "nl-cw",
    "CX": "en-cx",
    "CY": "el-cy",
    "CZ": "cs-cz",

    # D
    "DE": "de-de",
    "DJ": "fr-dj",
    "DK": "da-dk",
    "DM": "en-dm",
    "DO": "es-do",
    "DZ": "ar-dz",

    # E
    "EC": "es-ec",
    "EE": "et-ee",
    "EG": "ar-eg",
    "EH": "ar-eh",
    "ER": "ti-er",
    "ES": "es-es",
    "ET": "am-et",
    "FI": "fi-fi",
    "FJ": "en-fj",
    "FK": "en-fk",
    "FM": "en-fm",
    "FO": "fo-fo",
    "FR": "fr-fr",

    # G
    "GA": "fr-ga",
    "GB": "en-gb",
    "GD": "en-gd",
    "GE": "ka-ge",
    "GF": "fr-gf",
    "GG": "en-gg",
    "GH": "en-gh",
    "GI": "en-gi",
    "GL": "kl-gl",
    "GM": "en-gm",
    "GN": "fr-gn",
    "GP": "fr-gp",
    "GQ": "es-gq",
    "GR": "el-gr",
    "GS": "en-gs",
    "GT": "es-gt",
    "GU": "en-gu",
    "GW": "pt-gw",
    "GY": "en-gy",

    # H
    "HK": "zh-hk",
    "HM": "en-hm",
    "HN": "es-hn",
    "HR": "hr-hr",
    "HT": "ht-ht",
    "HU": "hu-hu",

    # I
    "ID": "id-id",
    "IE": "en-ie",
    "IL": "he-il",
    "IM": "en-im",
    "IN": "hi-in",   # 常见默认：印地语（也常见 en-in）
    "IO": "en-io",
    "IQ": "ar-iq",
    "IR": "fa-ir",
    "IS": "is-is",
    "IT": "it-it",

    # J
    "JE": "en-je",
    "JM": "en-jm",
    "JO": "ar-jo",
    "JP": "ja-jp",

    # K
    "KE": "sw-ke",
    "KG": "ky-kg",
    "KH": "km-kh",
    "KI": "en-ki",
    "KM": "fr-km",
    "KN": "en-kn",
    "KP": "ko-kp",
    "KR": "ko-kr",
    "KW": "ar-kw",
    "KY": "en-ky",
    "KZ": "kk-kz",

    # L
    "LA": "lo-la",
    "LB": "ar-lb",
    "LC": "en-lc",
    "LI": "de-li",
    "LK": "si-lk",
    "LR": "en-lr",
    "LS": "en-ls",
    "LT": "lt-lt",
    "LU": "fr-lu",
    "LV": "lv-lv",
    "LY": "ar-ly",

    # M
    "MA": "ar-ma",
    "MC": "fr-mc",
    "MD": "ro-md",
    "ME": "sr-me",
    "MF": "fr-mf",
    "MG": "fr-mg",
    "MH": "en-mh",
    "MK": "mk-mk",
    "ML": "fr-ml",
    "MM": "my-mm",
    "MN": "mn-mn",
    "MO": "zh-mo",
    "MP": "en-mp",
    "MQ": "fr-mq",
    "MR": "ar-mr",
    "MS": "en-ms",
    "MT": "mt-mt",
    "MU": "en-mu",
    "MV": "dv-mv",
    "MW": "en-mw",
    "MX": "es-mx",
    "MY": "ms-my",
    "MZ": "pt-mz",

    # N
    "NA": "en-na",
    "NC": "fr-nc",
    "NE": "fr-ne",
    "NF": "en-nf",
    "NG": "en-ng",
    "NI": "es-ni",
    "NL": "nl-nl",
    "NO": "nb-no",
    "NP": "ne-np",
    "NR": "en-nr",
    "NU": "en-nu",
    "NZ": "en-nz",

    # O
    "OM": "ar-om",

    # P
    "PA": "es-pa",
    "PE": "es-pe",
    "PF": "fr-pf",
    "PG": "en-pg",
    "PH": "en-ph",
    "PK": "ur-pk",
    "PL": "pl-pl",
    "PM": "fr-pm",
    "PN": "en-pn",
    "PR": "es-pr",
    "PS": "ar-ps",
    "PT": "pt-pt",
    "PW": "en-pw",
    "PY": "es-py",

    # Q
    "QA": "ar-qa",

    # R
    "RE": "fr-re",
    "RO": "ro-ro",
    "RS": "sr-rs",
    "RU": "ru-ru",
    "RW": "rw-rw",

    # S
    "SA": "ar-sa",
    "SB": "en-sb",
    "SC": "en-sc",
    "SD": "ar-sd",
    "SE": "sv-se",
    "SG": "en-sg",
    "SH": "en-sh",
    "SI": "sl-si",
    "SJ": "no-sj",
    "SK": "sk-sk",
    "SL": "en-sl",
    "SM": "it-sm",
    "SN": "fr-sn",
    "SO": "so-so",
    "SR": "nl-sr",
    "SS": "en-ss",
    "ST": "pt-st",
    "SV": "es-sv",
    "SX": "nl-sx",
    "SY": "ar-sy",
    "SZ": "en-sz",

    # T
    "TC": "en-tc",
    "TD": "fr-td",
    "TF": "fr-tf",
    "TG": "fr-tg",
    "TH": "th-th",
    "TJ": "tg-tj",
    "TK": "en-tk",
    "TL": "pt-tl",
    "TM": "tk-tm",
    "TN": "ar-tn",
    "TO": "en-to",
    "TR": "tr-tr",
    "TT": "en-tt",
    "TV": "en-tv",
    "TW": "zh-tw",
    "TZ": "sw-tz",

    # U
    "UA": "uk-ua",
    "UG": "en-ug",
    "UM": "en-um",
    "US": "en-us",
    "UY": "es-uy",
    "UZ": "uz-uz",

    # V
    "VA": "it-va",
    "VC": "en-vc",
    "VE": "es-ve",
    "VG": "en-vg",
    "VI": "en-vi",
    "VN": "vi-vn",
    "VU": "fr-vu",

    # W
    "WF": "fr-wf",
    "WS": "sm-ws",

    # Y
    "YE": "ar-ye",
    "YT": "fr-yt",

    # Z
    "ZA": "en-za",
    "ZM": "en-zm",
    "ZW": "en-zw",
}


def 国家代码转语言代码(国家代码: str) -> Optional[str]:
    """
    根据国家或地区代码查询常见默认语言代码。

    功能说明:
        - 这个函数用于把两位国家/地区代码转换成常见语言区域代码。
        - 输入会自动去掉前后空格，并转成大写后再查询。
        - 例如 US 返回 en-us，CN 返回 zh-cn，JP 返回 ja-jp。
        - 输入无效、未收录或发生异常时返回 None。

    Args:
        国家代码 (str): 两位国家/地区代码，例如 "US"、"CN"、"JP"。

    Returns:
        成功时返回语言区域代码；失败或未知时返回 None。

    Notes:
        - 返回值采用小写格式，例如 "en-us"；
        - 一个国家可能有多种官方语言，本函数返回常见默认值。
    """
    try:
        if not isinstance(国家代码, str):
            return None
        code = 国家代码.strip().upper()
        if len(code) != 2 or not code.isalpha():
            return None
        return _国家到语言代码.get(code)
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：查询美国语言代码 =====")
    print("结果:", 国家代码转语言代码("US"))

    print("\n===== 示例2：查询中国语言代码 =====")
    print("结果:", 国家代码转语言代码("CN"))

    print("\n===== 示例3：自动忽略大小写和空格 =====")
    print("结果:", 国家代码转语言代码(" jp "))

    print("\n===== 示例4：未知国家代码 =====")
    print("结果:", 国家代码转语言代码("XX"))

    print("\n===== 示例5：参数类型错误 =====")
    print("结果:", 国家代码转语言代码(None))

    print("\n===== 示例6：应用场景-批量查询站点默认语言 =====")
    国家列表 = ["US", "CN", "DE", "BR"]
    print("结果:", {国家: 国家代码转语言代码(国家) for 国家 in 国家列表})
