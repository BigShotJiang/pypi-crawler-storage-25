from __future__ import annotations
import random
from typing import Optional


def 取随机范围小数(
    起始数: float,
    结束数: float,
    小数位数: int = 2
) -> Optional[float]:
    """
    在指定数字范围内生成一个随机小数。

    功能说明:
        - 这个函数用于在两个数之间随机取一个小数。
        - 可以指定保留的小数位数。
        - 如果起始数大于结束数，函数会自动交换顺序后再生成。
        - 参数非法或发生异常时返回 None。

    Args:
        起始数 (float): 随机范围下限。
        结束数 (float): 随机范围上限。
        小数位数 (int): 保留的小数位数，默认 2。

    Returns:
        成功时返回随机小数；失败时返回 None。

    Notes:
        - 随机结果每次运行都可能不同；
        - 小数位数不能小于 0。
    """
    try:
        if not isinstance(小数位数, int) or 小数位数 < 0:
            return None

        if 起始数 > 结束数:
            起始数, 结束数 = 结束数, 起始数

        倍数 = 10 ** 小数位数
        最小整数 = int(round(起始数 * 倍数))
        最大整数 = int(round(结束数 * 倍数))

        随机整数 = random.randint(最小整数, 最大整数)
        return 随机整数 / 倍数

    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：生成1到10之间的两位小数 =====")
    print("结果:", 取随机范围小数(1.0, 10.0, 2))

    print("\n===== 示例2：生成一位小数 =====")
    print("结果:", 取随机范围小数(0.0, 1.0, 1))

    print("\n===== 示例3：起始数大于结束数会自动交换 =====")
    print("结果:", 取随机范围小数(10.0, 1.0, 2))

    print("\n===== 示例4：小数位数为0 =====")
    print("结果:", 取随机范围小数(1.0, 10.0, 0))

    print("\n===== 示例5：小数位数非法 =====")
    print("结果:", 取随机范围小数(1.0, 10.0, -1))

    print("\n===== 示例6：应用场景-随机生成折扣比例 =====")
    print("折扣:", 取随机范围小数(0.75, 0.95, 2))
