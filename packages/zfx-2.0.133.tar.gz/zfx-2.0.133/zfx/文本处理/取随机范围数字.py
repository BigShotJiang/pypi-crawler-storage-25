from __future__ import annotations
import random
from typing import Optional


def 取随机范围数字(起始数: int, 结束数: int) -> Optional[int]:
    """
    在指定整数范围内生成一个随机整数。

    功能说明:
        - 这个函数用于在两个整数之间随机取一个整数。
        - 起始数和结束数都会包含在可取范围内。
        - 如果起始数大于结束数，函数会自动交换顺序后再生成。
        - 参数非法或发生异常时返回 None。

    Args:
        起始数 (int): 随机范围下限。
        结束数 (int): 随机范围上限。

    Returns:
        成功时返回随机整数；失败时返回 None。

    Notes:
        - 随机结果每次运行都可能不同；
        - 范围是闭区间，也就是包含两边边界。
    """
    try:
        if not isinstance(起始数, int) or not isinstance(结束数, int):
            return None

        if 起始数 > 结束数:
            起始数, 结束数 = 结束数, 起始数

        return random.randint(起始数, 结束数)

    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：生成1到10之间的随机整数 =====")
    print("结果:", 取随机范围数字(1, 10))

    print("\n===== 示例2：起始数和结束数相同 =====")
    print("结果:", 取随机范围数字(5, 5))

    print("\n===== 示例3：起始数大于结束数会自动交换 =====")
    print("结果:", 取随机范围数字(10, 1))

    print("\n===== 示例4：包含负数范围 =====")
    print("结果:", 取随机范围数字(-5, 5))

    print("\n===== 示例5：参数类型错误 =====")
    print("结果:", 取随机范围数字("1", 10))

    print("\n===== 示例6：应用场景-随机选择等待秒数 =====")
    print("等待秒数:", 取随机范围数字(3, 8))
