def 货币代码转国家代码(货币代码: str) -> list[str]:
    """
    根据货币代码查询使用该货币的国家或地区代码列表。

    功能说明:
        - 这个函数用于把三位货币代码转换成国家/地区代码列表。
        - 输入会自动去掉前后空格，并转成大写后再查询。
        - 例如 USD 可能对应多个国家和地区，CNY 通常对应 CN。
        - 未匹配或发生异常时返回空列表 []。

    Args:
        货币代码 (str): 三位货币代码，例如 "USD"、"CNY"、"EUR"。

    Returns:
        成功时返回国家/地区代码列表；失败或未知时返回空列表 []。

    Notes:
        - 货币代码通常参考 ISO 4217；
        - 国家代码通常参考 ISO 3166-1 Alpha-2；
        - 一个货币代码可能对应多个国家或地区。
    """
    try:
        if not isinstance(货币代码, str) or len(货币代码.strip()) < 3:
            return []

        货币代码 =货币代码.strip().upper()

        # —— 数据源：国家 → 货币（与“国家代码转货币代码”一致）——
        国家到货币 = {
            "US": "USD", "CN": "CNY", "JP": "JPY", "KR": "KRW", "HK": "HKD", "TW": "TWD",
            "GB": "GBP", "EU": "EUR", "DE": "EUR", "FR": "EUR", "IT": "EUR", "ES": "EUR",
            "CA": "CAD", "AU": "AUD", "NZ": "NZD", "SG": "SGD", "IN": "INR", "BR": "BRL",
            "MX": "MXN", "AR": "ARS", "TR": "TRY", "ZA": "ZAR", "CH": "CHF", "SE": "SEK",
            "NO": "NOK", "DK": "DKK", "PL": "PLN", "CZ": "CZK", "HU": "HUF", "RO": "RON",
            "BG": "BGN", "RU": "RUB", "AE": "AED", "SA": "SAR", "QA": "QAR", "OM": "OMR",
            "KW": "KWD", "BH": "BHD", "EG": "EGP", "TH": "THB", "ID": "IDR", "MY": "MYR",
            "PH": "PHP", "VN": "VND", "BD": "BDT", "PK": "PKR", "NP": "NPR", "LK": "LKR",
            "BT": "BTN", "MM": "MMK", "KH": "KHR", "LA": "LAK", "IR": "IRR", "IQ": "IQD",
            "IL": "ILS", "JO": "JOD", "LB": "LBP", "SY": "SYP", "YE": "YER", "AF": "AFN",
            "AZ": "AZN", "AM": "AMD", "GE": "GEL", "KZ": "KZT", "KG": "KGS", "UZ": "UZS",
            "TJ": "TJS", "TM": "TMT", "MN": "MNT", "BN": "BND", "TL": "USD", "NG": "NGN",
            "GH": "GHS", "KE": "KES", "TZ": "TZS", "UG": "UGX", "ZM": "ZMW", "ZW": "ZWL",
            "DZ": "DZD", "MA": "MAD", "TN": "TND", "LY": "LYD", "MR": "MRU", "SN": "XOF",
            "ML": "XOF", "BF": "XOF", "NE": "XOF", "TG": "XOF", "BJ": "XOF", "CI": "XOF",
            "CM": "XAF", "TD": "XAF", "CF": "XAF", "GA": "XAF", "CG": "XAF", "GQ": "XAF",
            "AO": "AOA", "MZ": "MZN", "NA": "NAD", "BW": "BWP", "SZ": "SZL", "LS": "LSL",
            "MG": "MGA", "MU": "MUR", "KM": "KMF", "SC": "SCR", "CV": "CVE", "ST": "STN",
            "IS": "ISK", "FI": "EUR", "EE": "EUR", "LV": "EUR", "LT": "EUR", "SK": "EUR",
            "SI": "EUR", "HR": "EUR", "ME": "EUR", "RS": "RSD", "BA": "BAM", "AL": "ALL",
            "MK": "MKD", "XK": "EUR", "IE": "EUR", "NL": "EUR", "BE": "EUR", "LU": "EUR",
            "AT": "EUR", "PT": "EUR", "GR": "EUR", "CY": "EUR", "MT": "EUR", "LI": "CHF",
            "FO": "DKK", "CH": "CHF", "HK": "HKD", "MO": "MOP", "TH": "THB", "SG": "SGD",
            "PH": "PHP", "MY": "MYR", "ID": "IDR", "VN": "VND", "CN": "CNY", "JP": "JPY",
            "KR": "KRW", "TW": "TWD", "AU": "AUD", "NZ": "NZD", "FJ": "FJD", "PG": "PGK",
            "SB": "SBD", "VU": "VUV", "TO": "TOP", "WS": "WST", "TV": "AUD", "NR": "AUD",
            "KI": "AUD", "NC": "XPF", "PF": "XPF", "WF": "XPF", "GU": "USD", "MP": "USD",
            "AS": "USD", "IO": "USD", "NF": "AUD", "CX": "AUD", "CC": "AUD", "AQ": "未知",
            # —— 美洲与加勒比补充（在你上一版单函数中未显式列出的一些常见地区，可按需增减）——
            "PR": "USD", "VI": "USD", "VG": "USD", "KY": "KYD", "TT": "TTD", "BB": "BBD",
            "BS": "BSD", "BZ": "BZD", "GD": "XCD", "LC": "XCD", "DM": "XCD", "KN": "XCD",
            "AG": "XCD", "AI": "XCD", "CW": "ANG", "SX": "ANG", "AW": "AWG", "BQ": "USD",
            "JM": "JMD", "DO": "DOP", "HT": "HTG", "PA": "PAB", "CR": "CRC", "GT": "GTQ",
            "HN": "HNL", "NI": "NIO", "SV": "USD", "EC": "USD", "UY": "UYU", "PY": "PYG",
            "BO": "BOB", "PE": "PEN", "CL": "CLP", "CO": "COP", "VE": "VES", "AR": "ARS",
            "BR": "BRL", "GY": "GYD", "SR": "SRD", "FK": "FKP",
            # —— 北欧/极地/法属海外等 ——
            "GL": "DKK", "SJ": "NOK", "RE": "EUR", "YT": "EUR", "TF": "EUR", "GF": "EUR",
            "MQ": "EUR", "GP": "EUR",
        }

        # —— 单函数内构建“货币 → 国家列表”的倒排表，并做缓存（函数属性）——
        if not hasattr(货币代码转国家代码, "_缓存_货币到国家"):
            倒排 = {}
            for 国家, 币种 in 国家到货币.items():
                if 币种 == "未知":
                    continue
                倒排.setdefault(币种, []).append(国家)
            for 币种 in 倒排:
                倒排[币种].sort()
            货币代码转国家代码._缓存_货币到国家 = 倒排  # type: ignore[attr-defined]

        return 货币代码转国家代码._缓存_货币到国家.get(货币代码, [])  # type: ignore[attr-defined]

    except Exception as e:
        return []


if __name__ == "__main__":
    print("===== 示例1：查询 USD 对应国家地区 =====")
    print("结果:", 货币代码转国家代码("USD"))

    print("\n===== 示例2：查询 CNY 对应国家地区 =====")
    print("结果:", 货币代码转国家代码("CNY"))

    print("\n===== 示例3：自动忽略大小写和空格 =====")
    print("结果:", 货币代码转国家代码(" eur "))

    print("\n===== 示例4：未知货币代码 =====")
    print("结果:", 货币代码转国家代码("XXX"))

    print("\n===== 示例5：参数类型错误 =====")
    print("结果:", 货币代码转国家代码(None))

    print("\n===== 示例6：应用场景-判断某币种覆盖哪些市场 =====")
    币种 = "AUD"
    print(f"{币种} 覆盖地区:", 货币代码转国家代码(币种))
