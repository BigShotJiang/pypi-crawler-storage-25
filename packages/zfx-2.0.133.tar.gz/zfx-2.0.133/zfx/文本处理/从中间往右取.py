from typing import Optional


def 从中间往右取(
    字符串: str,
    开始位置: int,
    字符数量: int
) -> Optional[str]:
    """
    从文本的指定位置开始，向右取出指定数量的字符。

    功能说明:
        - 这个函数用于从一段文本中间某个位置开始，向右截取固定长度的内容。
        - 开始位置从 0 开始计数，例如第一个字符的位置是 0。
        - 如果截取范围超过文本结尾，会自动取到文本结尾为止。
        - 参数非法时返回 None，方便新手判断这次截取是否成功。

    Args:
        字符串 (str): 要处理的原始文本。
        开始位置 (int): 从哪里开始截取，从 0 开始计数。
        字符数量 (int): 要向右截取的字符数量。

    Returns:
        成功时返回截取后的字符串；参数非法时返回 None。

    Notes:
        - 不支持负数位置；
        - 开始位置等于文本长度时返回空字符串；
        - 字符数量为 0 时返回空字符串。
    """

    # 类型校验
    if not isinstance(字符串, str):
        return None
    if not isinstance(开始位置, int):
        return None
    if not isinstance(字符数量, int):
        return None

    # 数值校验
    if 开始位置 < 0 or 字符数量 < 0:
        return None
    if 开始位置 > len(字符串):
        return None

    return 字符串[开始位置:开始位置 + 字符数量]


if __name__ == "__main__":
    print("===== 示例1：从中间向右取3个字符 =====")
    print("结果:", 从中间往右取("abcdef", 2, 3))

    print("\n===== 示例2：从开头向右取字符 =====")
    print("结果:", 从中间往右取("abcdef", 0, 2))

    print("\n===== 示例3：截取范围超过文本结尾 =====")
    print("结果:", 从中间往右取("abcdef", 4, 10))

    print("\n===== 示例4：字符数量为0 =====")
    print("结果:", 从中间往右取("abcdef", 2, 0))

    print("\n===== 示例5：开始位置非法 =====")
    print("结果:", 从中间往右取("abcdef", -1, 2))

    print("\n===== 示例6：应用场景-从订单号中取日期部分 =====")
    订单号 = "DD202604220001"
    print("日期:", 从中间往右取(订单号, 2, 8))
