def 保留转义符(
    文本: str,
    *,
    使用_repr: bool = False
) -> str:
    """
    把文本中的换行、制表符等转义字符显示成可见形式。

    功能说明:
        - 这个函数用于把文本里的换行符、制表符等特殊字符显示成 \n、\t 这样的字面形式。
        - 默认使用 unicode_escape，返回不带外层引号的结果。
        - 使用_repr=True 时，返回 Python repr() 风格的字符串表示。
        - 转换失败时返回原始值的字符串形式。

    Args:
        文本 (str): 要处理的原始文本。
        使用_repr (bool): 是否使用 repr() 形式输出，默认 False。

    Returns:
        成功时返回转义符可见化后的文本；失败时返回原始值的字符串形式。

    Notes:
        - 默认结果适合展示或保存；
        - repr() 结果会带外层引号。
    """
    try:
        if 使用_repr:
            return repr(文本)
        return 文本.encode("unicode_escape").decode("utf-8")
    except Exception:
        return str(文本)


if __name__ == "__main__":
    print("===== 示例1：保留换行符 =====")
    print("结果:", 保留转义符("第一行\n第二行"))

    print("\n===== 示例2：保留制表符 =====")
    print("结果:", 保留转义符("A\tB"))

    print("\n===== 示例3：使用 repr 形式 =====")
    print("结果:", 保留转义符("A\nB", 使用_repr=True))

    print("\n===== 示例4：普通文本不受影响 =====")
    print("结果:", 保留转义符("ABC"))

    print("\n===== 示例5：参数异常时转字符串 =====")
    print("结果:", 保留转义符(123))

    print("\n===== 示例6：应用场景-把多行日志变成一行可见文本 =====")
    日志 = "启动\n运行\t完成"
    print("可见日志:", 保留转义符(日志))
