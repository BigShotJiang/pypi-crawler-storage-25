import random
import string


def 生成随机密码(长度, 模式):
    """
    按指定长度和模式生成随机密码。

    功能说明:
        - 这个函数用于生成随机密码字符串。
        - 模式决定密码中可以包含哪些字符类型。
        - 函数会尽量保证所选模式中的每类字符至少出现一次。
        - 模式无效、长度不足或发生异常时返回空字符串。

    Args:
        长度 (int): 要生成的密码长度。
        模式 (int): 密码模式，1=数字，2=数字+小写，3=数字+小写+大写，4=数字+小写+大写+符号，5=小写+大写，6=小写+大写+符号。

    Returns:
        成功时返回随机密码；失败时返回空字符串 ""。

    Notes:
        - 随机结果每次运行都可能不同；
        - 如果长度小于模式需要的最少字符数，可能返回比指定长度更长的结果。
    """
    try:
        # 根据模式选择字符集合
        可选字符 = ""
        密码字符 = []

        if 模式 == 1:
            可选字符 = string.digits  # 只包含数字
            密码字符 = [random.choice(可选字符)]  # 确保密码包含数字
        elif 模式 == 2:
            可选字符 = string.digits + string.ascii_lowercase  # 数字 + 小写字母
            密码字符 = [random.choice(string.digits), random.choice(string.ascii_lowercase)]  # 确保包含数字和小写字母
        elif 模式 == 3:
            可选字符 = string.digits + string.ascii_lowercase + string.ascii_uppercase  # 数字 + 小写字母 + 大写字母
            密码字符 = [random.choice(string.digits), random.choice(string.ascii_lowercase), random.choice(string.ascii_uppercase)]  # 确保包含数字、小写字母、大写字母
        elif 模式 == 4:
            可选字符 = string.digits + string.ascii_lowercase + string.ascii_uppercase + string.punctuation  # 数字 + 小写字母 + 大写字母 + 符号
            密码字符 = [random.choice(string.digits), random.choice(string.ascii_lowercase), random.choice(string.ascii_uppercase), random.choice(string.punctuation)]  # 确保包含所有类型的字符
        elif 模式 == 5:
            可选字符 = string.ascii_lowercase + string.ascii_uppercase  # 小写字母 + 大写字母
            密码字符 = [random.choice(string.ascii_lowercase), random.choice(string.ascii_uppercase)]  # 确保包含小写字母和大写字母
        elif 模式 == 6:
            可选字符 = string.ascii_lowercase + string.ascii_uppercase + string.punctuation  # 小写字母 + 大写字母 + 符号
            密码字符 = [random.choice(string.ascii_lowercase), random.choice(string.ascii_uppercase), random.choice(string.punctuation)]  # 确保包含小写字母、大写字母和符号
        else:
            return ""  # 如果模式无效，返回空字符串

        # 计算剩余字符数，并从可选字符中随机选择
        剩余字符数 = 长度 - len(密码字符)
        密码字符 += random.choices(可选字符, k=剩余字符数)

        # 打乱密码字符，确保随机性
        random.shuffle(密码字符)

        # 返回生成的密码
        return ''.join(密码字符)
    except Exception:
        return ""  # 如果发生异常，返回空字符串


if __name__ == "__main__":
    print("===== 示例1：生成纯数字密码 =====")
    print("结果:", 生成随机密码(6, 1))

    print("\n===== 示例2：生成数字加小写字母密码 =====")
    print("结果:", 生成随机密码(8, 2))

    print("\n===== 示例3：生成数字小写大写密码 =====")
    print("结果:", 生成随机密码(10, 3))

    print("\n===== 示例4：模式无效 =====")
    print("结果:", 生成随机密码(10, 99))

    print("\n===== 示例5：长度参数异常 =====")
    print("结果:", 生成随机密码("10", 1))

    print("\n===== 示例6：应用场景-生成包含符号的临时密码 =====")
    print("临时密码:", 生成随机密码(12, 4))
