import shutil
import os


def 复制(被复制文件名, 复制到文件名, 是否覆盖=False):
    """复制文件。

    Args:
        被复制文件名: 源文件路径。
        复制到文件名: 目标文件路径。
        是否覆盖: 目标已存在时是否覆盖，默认为 ``False``。

    Returns:
        复制成功时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not 是否覆盖 and os.path.exists(复制到文件名):
            return False

        shutil.copy2(被复制文件名, 复制到文件名)
        return True
    except Exception:
        return False
