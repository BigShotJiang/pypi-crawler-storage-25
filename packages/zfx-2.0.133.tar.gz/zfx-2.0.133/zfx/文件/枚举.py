import os


def 枚举(目录路径):
    """递归枚举目录中的所有文件。

    Args:
        目录路径: 要枚举的目录路径。

    Returns:
        成功时返回文件完整路径列表；失败时返回 ``False``。
    """
    文件列表 = []
    try:
        for 根目录, _, 文件名 in os.walk(目录路径):
            for 文件 in 文件名:
                文件完整路径 = os.path.join(根目录, 文件)
                文件列表.append(文件完整路径)
        return 文件列表
    except Exception:
        return False
