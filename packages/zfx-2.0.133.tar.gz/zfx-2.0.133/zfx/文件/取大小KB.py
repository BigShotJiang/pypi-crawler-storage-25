import os


def 取大小KB(文件完整路径):
    """返回文件大小，单位为 KB。

    Args:
        文件完整路径: 要获取大小的文件完整路径。

    Returns:
        文件大小的 KB 值；获取失败时返回 ``None``。
    """
    try:
        大小B = os.path.getsize(文件完整路径)
        return 大小B / 1024.0
    except Exception:
        return None
