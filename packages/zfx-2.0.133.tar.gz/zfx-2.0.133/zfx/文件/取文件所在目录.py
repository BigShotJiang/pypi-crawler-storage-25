import os


def 取文件所在目录(文件完整路径):
    """返回文件所在目录路径。

    Args:
        文件完整路径: 文件完整路径。

    Returns:
        成功时返回目录路径字符串；失败时返回 ``None``。
    """
    try:
        return os.path.dirname(os.path.abspath(文件完整路径))
    except Exception:
        return None
