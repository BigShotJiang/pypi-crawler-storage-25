import os


def 删除文件(文件完整路径):
    """删除指定文件。

    Args:
        文件完整路径: 要删除的文件完整路径。

    Returns:
        删除成功时返回 ``True``，否则返回 ``False``。
    """
    try:
        if os.path.exists(文件完整路径):
            os.remove(文件完整路径)
            return True
        return False
    except Exception:
        return False
