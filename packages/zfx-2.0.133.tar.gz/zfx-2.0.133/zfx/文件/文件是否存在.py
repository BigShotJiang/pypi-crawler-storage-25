import os


def 文件是否存在(文件完整路径):
    """判断路径是否存在。

    Args:
        文件完整路径: 要检查的路径。

    Returns:
        路径存在时返回 ``True``，否则返回 ``False``。
    """
    try:
        return os.path.exists(文件完整路径)
    except Exception:
        return False
