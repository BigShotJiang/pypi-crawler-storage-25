import subprocess
import os
import sys
import tempfile


def 封装Py代码成EXE_独立编译(脚本路径):
    """使用 PyInstaller 将 Python 脚本打包为单文件 EXE。

    Args:
        脚本路径: 要打包的 Python 脚本完整路径。
    """
    try:
        桌面路径 = os.path.join(os.path.expanduser("~"), "Desktop")

        pyinstaller_path = os.path.join(os.path.dirname(sys.executable), "Scripts", "pyinstaller.exe")

        if not os.path.isfile(pyinstaller_path):
            raise FileNotFoundError(f"无法找到 pyinstaller.exe，请确保已安装 PyInstaller。")

        with tempfile.TemporaryDirectory() as 临时目录:
            subprocess.run(
                [pyinstaller_path, "--onefile", "--distpath", 桌面路径, "--workpath", 临时目录, "--specpath", 临时目录, 脚本路径],
                check=True,
            )

        print(f"成功将 {脚本路径} 打包成 EXE 文件，并保存在桌面。")
    except subprocess.CalledProcessError as e:
        print(f"打包过程中出现错误: {e}")
    except FileNotFoundError as e:
        print(e)
