import os


def 取最后修改时间(文件完整路径):
    """返回文件最后修改时间戳。

    Args:
        文件完整路径: 文件完整路径。

    Returns:
        成功时返回 ``float`` 时间戳；失败时返回 ``None``。
    """
    try:
        return os.path.getmtime(文件完整路径)
    except Exception:
        return None
