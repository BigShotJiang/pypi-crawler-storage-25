import os


def 取后缀名(文件完整路径, 是否包含点号=True):
    """返回文件后缀名。

    Args:
        文件完整路径: 文件完整路径。
        是否包含点号: 返回结果是否保留 ``.``，默认为 ``True``。

    Returns:
        成功时返回后缀名字符串；失败时返回 ``None``。
    """
    try:
        后缀名 = os.path.splitext(文件完整路径)[1]
        if 是否包含点号:
            return 后缀名
        return 后缀名.lstrip(".")
    except Exception:
        return None
