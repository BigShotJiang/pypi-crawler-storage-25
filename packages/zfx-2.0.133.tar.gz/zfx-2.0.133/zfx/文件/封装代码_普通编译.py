import subprocess
import os
import sys
import tempfile


def 封装代码_普通编译(脚本路径, 隐藏导入模块=None):
    """使用 PyInstaller 打包为普通目录结构 EXE。

    Args:
        脚本路径: 要打包的 Python 脚本完整路径。
        隐藏导入模块: 需要补充声明的隐藏导入模块列表。
    """
    桌面路径 = os.path.join(os.path.expanduser("~"), "Desktop")
    pyinstaller_path = os.path.join(os.path.dirname(sys.executable), "Scripts", "pyinstaller.exe")

    if not os.path.isfile(pyinstaller_path):
        print(f"❌ 错误：未找到 pyinstaller.exe，请确认已正确安装。\n路径: {pyinstaller_path}")
        return

    if 隐藏导入模块 is not None:
        if isinstance(隐藏导入模块, str):
            print("❌ [类型错误] 隐藏导入模块不能是字符串，请使用 ['模块名'] 格式的列表")
            return
        if not isinstance(隐藏导入模块, (list, tuple)) or not all(isinstance(m, str) for m in 隐藏导入模块):
            print("❌ [类型错误] 隐藏导入模块参数必须是字符串列表，例如：['模块1', '模块2']")
            return

    try:
        with tempfile.TemporaryDirectory() as 临时目录:
            命令 = [
                pyinstaller_path,
                "--distpath", 桌面路径,
                "--workpath", 临时目录,
                "--specpath", 临时目录,
            ]

            if 隐藏导入模块:
                for 模块名 in 隐藏导入模块:
                    命令.append(f"--hidden-import={模块名}")

            命令.append(脚本路径)

            print(f"🚀 开始打包（标准结构）：{os.path.basename(脚本路径)}")
            subprocess.run(命令, check=True)
            print(f"✅ 打包成功：{os.path.basename(脚本路径)}（标准结构）已输出至桌面。")

    except subprocess.CalledProcessError as e:
        print(f"❌ 打包失败（PyInstaller 出错）\n错误信息：{e}")
    except Exception as e:
        print(f"❌ 发生未知错误：{e}")
