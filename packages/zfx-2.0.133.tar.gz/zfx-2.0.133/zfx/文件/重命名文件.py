import os


def 重命名文件(原文件路径, 新文件路径, 是否覆盖=False):
    """重命名文件。

    Args:
        原文件路径: 当前文件路径。
        新文件路径: 重命名后的文件路径。
        是否覆盖: 目标已存在时是否覆盖，默认为 ``False``。

    Returns:
        重命名成功时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not 是否覆盖 and os.path.exists(新文件路径):
            return False

        if 是否覆盖 and os.path.exists(新文件路径):
            os.remove(新文件路径)

        os.rename(原文件路径, 新文件路径)
        return True
    except Exception:
        return False
