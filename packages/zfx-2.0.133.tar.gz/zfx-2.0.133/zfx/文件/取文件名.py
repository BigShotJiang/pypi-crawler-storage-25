import os


def 取文件名(文件完整路径, 是否包含后缀=True):
    """返回路径中的文件名。

    Args:
        文件完整路径: 文件完整路径。
        是否包含后缀: 是否保留文件后缀，默认为 ``True``。

    Returns:
        成功时返回文件名字符串；失败时返回 ``None``。
    """
    try:
        文件名 = os.path.basename(文件完整路径)
        if 是否包含后缀:
            return 文件名
        return os.path.splitext(文件名)[0]
    except Exception:
        return None
