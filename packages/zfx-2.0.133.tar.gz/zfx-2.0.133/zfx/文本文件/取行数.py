﻿def 取行数(文件路径):
    """
    统计文本文件的总行数。

    功能说明:
        - 按 UTF-8 编码逐行读取文本文件；
        - 返回文件中的行数；
        - 读取失败或发生异常时返回 -1。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要统计行数的文本文件路径。

    Returns:
        int:
            - >= 0 : 文件总行数。
            - -1   : 读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 空文件返回 0。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行数 = sum(1 for _ in file)  # 通过逐行迭代计算行数
        return 行数
    except Exception:
        return -1


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：统计普通文件行数 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("A\nB\nC\n", encoding="utf-8")
        print("结果:", 取行数(str(文件)))

        print("\n===== 示例2：空文件行数 =====")
        文件.write_text("", encoding="utf-8")
        print("结果:", 取行数(str(文件)))

        print("\n===== 示例3：包含空行也会计入总行数 =====")
        文件.write_text("A\n\nB\n", encoding="utf-8")
        print("结果:", 取行数(str(文件)))

        print("\n===== 示例4：最后一行没有换行符 =====")
        文件.write_text("A\nB\nC", encoding="utf-8")
        print("结果:", 取行数(str(文件)))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取行数(str(不存在文件)))

        print("\n===== 示例6：应用场景-统计账号文件总行数 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A\n账号B\n账号C\n账号D\n", encoding="utf-8")
        print("账号总行数:", 取行数(str(文件)))
