from pathlib import Path


def 文本按行去重(文件路径: str) -> bool:
    """删除文本文件中的重复行，并保留每行第一次出现的位置。

    功能说明:
        - 这个函数用于按行去除文本文件里的重复内容。
        - 判断重复时，会把每行末尾的换行符去掉后再比较。
        - 重复行只保留第一次出现的那一行，后面再次出现的相同行会被删除。
        - 常用于账号、链接、关键词、任务列表等一行一条的数据去重。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要去重的文本文件路径。

    Returns:
        去重成功返回 ``True``；失败时返回 ``False``。
    """
    try:
        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            行列表 = 文件对象.readlines()

        已出现 = set()
        去重后行列表 = []
        for 行 in 行列表:
            行内容 = 行.rstrip("\n").rstrip("\r")
            if 行内容 not in 已出现:
                已出现.add(行内容)
                去重后行列表.append(行内容 + "\n")

        with open(文件路径, "w", encoding="utf-8") as 文件对象:
            文件对象.writelines(去重后行列表)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：普通按行去重 =====")
        文件 = Path(临时目录) / "链接.txt"
        文件.write_text("a\nb\na\nc\nb\n", encoding="utf-8")
        print("结果:", 文本按行去重(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：没有重复行 =====")
        文件 = Path(临时目录) / "无重复.txt"
        文件.write_text("a\nb\nc\n", encoding="utf-8")
        print("结果:", 文本按行去重(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：空文件 =====")
        文件 = Path(临时目录) / "空文件.txt"
        文件.write_text("", encoding="utf-8")
        print("结果:", 文本按行去重(str(文件)))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例4：空行也会参与去重 =====")
        文件 = Path(临时目录) / "空行.txt"
        文件.write_text("a\n\n\nb\n\n", encoding="utf-8")
        print("结果:", 文本按行去重(str(文件)))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 文本按行去重(str(文件)))

        print("\n===== 示例6：应用场景-采集链接结果去重 =====")
        文件 = Path(临时目录) / "采集链接.txt"
        文件.write_text("https://a.com\nhttps://b.com\nhttps://a.com\nhttps://c.com\n", encoding="utf-8")
        print("结果:", 文本按行去重(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))
