﻿def 取指定行内容(文件路径, 行号):
    """
    读取文本文件中指定行的内容。

    功能说明:
        - 读取 UTF-8 文本文件的全部行；
        - 按从 1 开始的行号取出目标行；
        - 返回内容时移除行尾换行符；
        - 行号无效或发生异常时返回 None。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        行号 (int): 要读取的行号，从 1 开始。

    Returns:
        str | None:
            - str  : 指定行内容，不包含行尾换行符。
            - None : 行号无效、读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行内容 = file.readlines()

        # 检查行号是否有效
        if 行号 < 1 or 行号 > len(行内容):
            return None

        # 返回指定行的内容，去除行尾的换行符
        return 行内容[行号 - 1].rstrip('\n')
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：读取指定行 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("第一行\n第二行\n第三行\n", encoding="utf-8")
        print("结果:", 取指定行内容(str(文件), 2))

        print("\n===== 示例2：读取第一行 =====")
        print("结果:", 取指定行内容(str(文件), 1))

        print("\n===== 示例3：读取最后一行 =====")
        print("结果:", 取指定行内容(str(文件), 3))

        print("\n===== 示例4：行号超出范围 =====")
        print("结果:", 取指定行内容(str(文件), 99))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取指定行内容(str(不存在文件), 1))

        print("\n===== 示例6：应用场景-读取任务队列中的第2个任务 =====")
        文件 = Path(临时目录) / "任务队列.txt"
        文件.write_text("登录账号\n采集数据\n保存结果\n", encoding="utf-8")
        print("当前任务:", 取指定行内容(str(文件), 2))
