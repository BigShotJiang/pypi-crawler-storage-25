from typing import Optional


def 取文件最后一行(文件路径: str) -> Optional[str]:
    """读取文本文件的最后一行内容。

    功能说明:
        - 这个函数用于取出文本文件中的最后一行。
        - 返回结果会去掉行尾换行符，方便直接继续处理。
        - 如果文件为空、读取失败或发生异常，会返回 ``None``。
        - 常用于查看最新日志、最新结果、最后一个任务或最后一条账号记录。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要读取的文本文件路径。

    Returns:
        成功时返回最后一行文本；失败或文件为空时返回 ``None``。
    """
    try:
        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            行列表 = 文件对象.readlines()

        if not 行列表:
            return None
        return 行列表[-1].rstrip("\n").rstrip("\r")
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：读取最后一行 =====")
        文件 = Path(临时目录) / "日志.txt"
        文件.write_text("第一行\n第二行\n第三行\n", encoding="utf-8")
        print("结果:", 取文件最后一行(str(文件)))

        print("\n===== 示例2：只有一行 =====")
        文件 = Path(临时目录) / "单行.txt"
        文件.write_text("唯一一行\n", encoding="utf-8")
        print("结果:", 取文件最后一行(str(文件)))

        print("\n===== 示例3：空文件 =====")
        文件 = Path(临时目录) / "空文件.txt"
        文件.write_text("", encoding="utf-8")
        print("结果:", 取文件最后一行(str(文件)))

        print("\n===== 示例4：最后一行没有换行符 =====")
        文件 = Path(临时目录) / "无结尾换行.txt"
        文件.write_text("第一行\n最后一行", encoding="utf-8")
        print("结果:", 取文件最后一行(str(文件)))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取文件最后一行(str(文件)))

        print("\n===== 示例6：应用场景-读取最新运行状态 =====")
        文件 = Path(临时目录) / "运行状态.log"
        文件.write_text("09:00 启动\n09:10 采集完成\n09:11 保存完成\n", encoding="utf-8")
        print("最新状态:", 取文件最后一行(str(文件)))
