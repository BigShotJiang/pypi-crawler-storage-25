﻿def 指定行插入内容(文件路径, 行号, 内容):
    """
    在文本文件的指定行前插入内容。

    功能说明:
        - 读取 UTF-8 文本文件的全部行；
        - 在指定行号前插入一行新内容；
        - 行号从 1 开始计数；
        - 插入后写回原文件；
        - 操作成功返回 True，失败返回 False。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要操作的文本文件路径。
        行号 (int): 插入位置的行号，从 1 开始。
        内容 (str): 要插入的文本内容，函数会自动补充行尾换行符。

    Returns:
        bool:
            - True  : 插入成功。
            - False : 插入失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取和写入；
        - 行号大于文件总行数时，会插入到文件末尾。
    """
    try:
        # 以读写模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r+', encoding='utf-8') as file:
            行列表 = file.readlines()

            # 插入内容到指定行，行号从 1 开始
            行列表.insert(行号 - 1, 内容 + '\n')

            # 重置文件指针到文件开头，并写回修改后的内容
            file.seek(0)
            file.writelines(行列表)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：在指定行前插入内容 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("第一行\n第三行\n", encoding="utf-8")
        print("结果:", 指定行插入内容(str(文件), 2, "第二行"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：插入到第一行前 =====")
        文件.write_text("B\nC\n", encoding="utf-8")
        print("结果:", 指定行插入内容(str(文件), 1, "A"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：行号超过总行数时插入末尾 =====")
        文件.write_text("A\nB\n", encoding="utf-8")
        print("结果:", 指定行插入内容(str(文件), 99, "C"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例4：插入空字符串 =====")
        文件.write_text("A\nB\n", encoding="utf-8")
        print("结果:", 指定行插入内容(str(文件), 2, ""))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 指定行插入内容(str(不存在文件), 1, "内容"))

        print("\n===== 示例6：应用场景-在任务队列顶部插入紧急任务 =====")
        文件 = Path(临时目录) / "任务队列.txt"
        文件.write_text("普通任务A\n普通任务B\n", encoding="utf-8")
        print("结果:", 指定行插入内容(str(文件), 1, "紧急任务"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))
