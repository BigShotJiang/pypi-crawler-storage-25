﻿def 取指定行内容_分割(文件路径, 行号, 分隔符):
    """
    读取指定行内容，并按分隔符切分为列表。

    功能说明:
        - 读取 UTF-8 文本文件的指定行；
        - 移除目标行行尾换行符；
        - 使用给定分隔符执行 split()；
        - 返回列表中的每一项都会执行 strip()；
        - 行号无效或发生异常时返回 None。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        行号 (int): 要读取的行号，从 1 开始。
        分隔符 (str): 用于切分行内容的分隔符。

    Returns:
        list[str] | None:
            - list[str] : 分割并清理后的内容列表。
            - None      : 行号无效、读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 分隔符不存在时，返回仅包含原行内容的列表。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行内容 = file.readlines()

        # 检查行号是否有效
        if 行号 < 1 or 行号 > len(行内容):
            return None

        # 获取指定行并去除行尾的换行符
        指定行内容 = 行内容[行号 - 1].rstrip('\n')

        # 根据分隔符分割行内容，并去除每个分割项的前后空格
        分割内容列表 = [item.strip() for item in 指定行内容.split(分隔符)]

        return 分割内容列表
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：按分隔符分割指定行 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("user1----pass1----token1\nuser2----pass2----token2\n", encoding="utf-8")
        print("结果:", 取指定行内容_分割(str(文件), 1, "----"))

        print("\n===== 示例2：分隔符不存在 =====")
        print("结果:", 取指定行内容_分割(str(文件), 1, "####"))

        print("\n===== 示例3：行号超出范围 =====")
        print("结果:", 取指定行内容_分割(str(文件), 99, "----"))

        print("\n===== 示例4：分割后会去掉两边空格 =====")
        文件.write_text(" A ---- B ---- C \n", encoding="utf-8")
        print("结果:", 取指定行内容_分割(str(文件), 1, "----"))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取指定行内容_分割(str(不存在文件), 1, "----"))

        print("\n===== 示例6：应用场景-拆分账号密码令牌 =====")
        文件 = Path(临时目录) / "账号资料.txt"
        文件.write_text("账号A----密码A----令牌A\n账号B----密码B----令牌B\n", encoding="utf-8")
        账号信息 = 取指定行内容_分割(str(文件), 2, "----")
        print("账号信息:", 账号信息)
