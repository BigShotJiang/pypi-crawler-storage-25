﻿from typing import List


def 取包含关键词的行(文件路径: str, 关键词: str) -> List[str]:
    """从文本文件中取出所有包含指定关键词的行。

    功能说明:
        - 这个函数用于筛选文本文件中包含某个关键词的行。
        - 文件会按行读取，只要某一行里包含关键词，就会把这一行加入结果列表。
        - 返回的行内容会去掉行尾的换行符，方便后续直接处理。
        - 常用于筛选日志、账号状态、链接列表、关键词结果等文本数据。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径: 要读取的文本文件路径。
        关键词: 要查找的关键词。

    Returns:
        成功时返回包含关键词的行列表；失败或没有匹配时返回空列表 ``[]``。
    """
    try:
        if not isinstance(关键词, str) or 关键词 == "":
            return []

        结果列表 = []
        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            for 行 in 文件对象:
                当前行 = 行.rstrip("\n").rstrip("\r")
                if 关键词 in 当前行:
                    结果列表.append(当前行)

        return 结果列表
    except Exception:
        return []


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：取出包含关键词的行 =====")
        文件 = Path(临时目录) / "状态.txt"
        文件.write_text("账号A----成功\n账号B----失败\n账号C----成功\n", encoding="utf-8")
        print("结果:", 取包含关键词的行(str(文件), "成功"))

        print("\n===== 示例2：没有匹配内容 =====")
        print("结果:", 取包含关键词的行(str(文件), "等待中"))

        print("\n===== 示例3：空关键词 =====")
        print("结果:", 取包含关键词的行(str(文件), ""))

        print("\n===== 示例4：读取不存在的文件 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取包含关键词的行(str(不存在文件), "成功"))

        print("\n===== 示例5：关键词出现在行中间 =====")
        文件 = Path(临时目录) / "链接.txt"
        文件.write_text("https://a.com?id=100\nhttps://b.com?id=200\n", encoding="utf-8")
        print("结果:", 取包含关键词的行(str(文件), "id=200"))

        print("\n===== 示例6：应用场景-从运行日志中取出失败记录 =====")
        文件 = Path(临时目录) / "运行日志.txt"
        文件.write_text("任务1 成功\n任务2 失败: 网络错误\n任务3 成功\n任务4 失败: 超时\n", encoding="utf-8")
        失败记录 = 取包含关键词的行(str(文件), "失败")
        print("失败数量:", len(失败记录))
        print("失败记录:", 失败记录)
