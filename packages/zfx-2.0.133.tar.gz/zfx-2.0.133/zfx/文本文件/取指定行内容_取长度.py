﻿def 取指定行内容_取长度(文件路径, 行号):
    """
    读取指定行内容，并返回该行文本长度。

    功能说明:
        - 读取 UTF-8 文本文件的指定行；
        - 移除目标行行尾换行符；
        - 返回处理后字符串的长度；
        - 行号无效或发生异常时返回 None。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        行号 (int): 要读取的行号，从 1 开始。

    Returns:
        int | None:
            - int  : 指定行内容的字符长度。
            - None : 行号无效、读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 长度不包含行尾换行符。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行内容 = file.readlines()

        # 检查行号是否有效
        if 行号 < 1 or 行号 > len(行内容):
            return None

        # 获取指定行并去除行尾的换行符
        指定行内容 = 行内容[行号 - 1].rstrip('\n')

        # 获取行内容的长度
        行内容长度 = len(指定行内容)

        return 行内容长度
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：取指定行长度 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("abc\nhello\n", encoding="utf-8")
        print("结果:", 取指定行内容_取长度(str(文件), 2))

        print("\n===== 示例2：空行长度为0 =====")
        文件.write_text("第一行\n\n第三行\n", encoding="utf-8")
        print("结果:", 取指定行内容_取长度(str(文件), 2))

        print("\n===== 示例3：中文字符长度 =====")
        文件.write_text("你好世界\n", encoding="utf-8")
        print("结果:", 取指定行内容_取长度(str(文件), 1))

        print("\n===== 示例4：行号超出范围 =====")
        print("结果:", 取指定行内容_取长度(str(文件), 9))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取指定行内容_取长度(str(不存在文件), 1))

        print("\n===== 示例6：应用场景-检查账号行长度是否过长 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A----密码A----令牌A\n", encoding="utf-8")
        长度 = 取指定行内容_取长度(str(文件), 1)
        print("账号行长度:", 长度)
