﻿def 删除空行(文件路径):
    """
    删除文本文件中的空行。

    功能说明:
        - 读取 UTF-8 文本文件的全部行；
        - 移除 strip() 后为空的行；
        - 将剩余内容写回原文件；
        - 操作成功返回 True，失败返回 False。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要处理的文本文件路径。

    Returns:
        bool:
            - True  : 删除空行成功。
            - False : 删除失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取和写入；
        - 空白字符组成的行也会被视为空行。
    """
    try:
        # 打开文件读取所有行
        with open(文件路径, 'r', encoding='utf-8') as file:
            lines = file.readlines()

        # 过滤掉空行
        non_empty_lines = [line for line in lines if line.strip()]

        # 将非空行写回文件
        with open(文件路径, 'w', encoding='utf-8') as file:
            file.writelines(non_empty_lines)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：删除普通空行 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("A\n\nB\n\nC\n", encoding="utf-8")
        print("结果:", 删除空行(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：删除只有空格的行 =====")
        文件.write_text("A\n   \nB\n\t\nC\n", encoding="utf-8")
        print("结果:", 删除空行(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：没有空行 =====")
        文件.write_text("A\nB\nC\n", encoding="utf-8")
        print("结果:", 删除空行(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例4：空文件 =====")
        文件.write_text("", encoding="utf-8")
        print("结果:", 删除空行(str(文件)))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 删除空行(str(不存在文件)))

        print("\n===== 示例6：应用场景-清理账号列表中的空白行 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A\n\n账号B\n   \n账号C\n", encoding="utf-8")
        print("结果:", 删除空行(str(文件)))
        print("清理后内容:", 文件.read_text(encoding="utf-8"))
