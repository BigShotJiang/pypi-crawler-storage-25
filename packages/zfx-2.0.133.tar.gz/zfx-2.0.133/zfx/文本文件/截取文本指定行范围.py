from typing import List


def 截取文本指定行范围(文件路径: str, 开始行号: int, 结束行号: int) -> List[str]:
    """截取文本文件中指定行号范围内的内容。

    功能说明:
        - 这个函数用于从文本文件里取出一段连续行。
        - 开始行号和结束行号都从 1 开始计数，并且包含开始行和结束行。
        - 返回结果会去掉每行末尾的换行符，方便直接继续处理。
        - 常用于预览大文件中的某一段、取出部分账号、检查指定范围日志。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要读取的文本文件路径。
        开始行号: 要截取的起始行号，从 1 开始。
        结束行号: 要截取的结束行号，从 1 开始。

    Returns:
        成功时返回指定范围的文本行列表；失败时返回空列表 ``[]``。
    """
    try:
        if not isinstance(开始行号, int) or not isinstance(结束行号, int):
            return []
        if 开始行号 < 1 or 结束行号 < 开始行号:
            return []

        结果列表 = []
        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            for 当前行号, 行 in enumerate(文件对象, start=1):
                if 当前行号 < 开始行号:
                    continue
                if 当前行号 > 结束行号:
                    break
                结果列表.append(行.rstrip("\n").rstrip("\r"))

        return 结果列表
    except Exception:
        return []


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：截取第2行到第4行 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("第1行\n第2行\n第3行\n第4行\n第5行\n", encoding="utf-8")
        print("结果:", 截取文本指定行范围(str(文件), 2, 4))

        print("\n===== 示例2：只截取一行 =====")
        print("结果:", 截取文本指定行范围(str(文件), 3, 3))

        print("\n===== 示例3：结束行号超过文件总行数 =====")
        print("结果:", 截取文本指定行范围(str(文件), 4, 10))

        print("\n===== 示例4：开始行号小于1 =====")
        print("结果:", 截取文本指定行范围(str(文件), 0, 3))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 截取文本指定行范围(str(文件), 1, 3))

        print("\n===== 示例6：应用场景-截取日志中间一段检查 =====")
        文件 = Path(临时目录) / "运行日志.txt"
        文件.write_text("启动\n登录\n采集\n保存\n结束\n", encoding="utf-8")
        print("中间步骤:", 截取文本指定行范围(str(文件), 2, 4))
