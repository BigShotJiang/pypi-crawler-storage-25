from typing import List


def 取不包含关键词的行(文件路径: str, 关键词: str) -> List[str]:
    """从文本文件中取出所有不包含指定关键词的行。

    功能说明:
        - 这个函数用于筛选文本文件中不包含某个关键词的行。
        - 文件会按行读取，只要某一行里不包含关键词，就会把这一行加入结果列表。
        - 返回的行内容会去掉行尾的换行符，方便后续直接处理。
        - 常用于筛选未完成任务、未标记账号、未包含某状态的记录等文本数据。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要读取的文本文件路径。
        关键词: 要排除的关键词。

    Returns:
        成功时返回不包含关键词的行列表；失败时返回空列表 ``[]``。
    """
    try:
        if not isinstance(关键词, str) or 关键词 == "":
            return []

        结果列表 = []
        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            for 行 in 文件对象:
                当前行 = 行.rstrip("\n").rstrip("\r")
                if 关键词 not in 当前行:
                    结果列表.append(当前行)

        return 结果列表
    except Exception:
        return []


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：取出不包含关键词的行 =====")
        文件 = Path(临时目录) / "状态.txt"
        文件.write_text("账号A----已完成\n账号B----待处理\n账号C----已完成\n", encoding="utf-8")
        print("结果:", 取不包含关键词的行(str(文件), "已完成"))

        print("\n===== 示例2：所有行都包含关键词 =====")
        文件.write_text("A----完成\nB----完成\n", encoding="utf-8")
        print("结果:", 取不包含关键词的行(str(文件), "完成"))

        print("\n===== 示例3：没有任何行包含关键词 =====")
        文件.write_text("A----待处理\nB----待处理\n", encoding="utf-8")
        print("结果:", 取不包含关键词的行(str(文件), "完成"))

        print("\n===== 示例4：空关键词 =====")
        print("结果:", 取不包含关键词的行(str(文件), ""))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取不包含关键词的行(str(文件), "完成"))

        print("\n===== 示例6：应用场景-筛选未失败的日志 =====")
        文件 = Path(临时目录) / "运行日志.txt"
        文件.write_text("任务1 成功\n任务2 失败\n任务3 成功\n任务4 跳过\n", encoding="utf-8")
        print("未失败记录:", 取不包含关键词的行(str(文件), "失败"))
