from typing import List


def 取文件前N行(文件路径: str, 行数: int) -> List[str]:
    """读取文本文件开头的 N 行内容。

    功能说明:
        - 这个函数用于从文本文件开头取出指定数量的行。
        - 返回结果会去掉每行末尾的换行符。
        - 如果行数大于文件总行数，会返回文件中已有的全部行。
        - 常用于预览大文件、读取前几个账号、读取前几个任务等场景。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要读取的文本文件路径。
        行数: 要读取的前 N 行数量，必须大于 0。

    Returns:
        成功时返回前 N 行文本列表；失败时返回空列表 ``[]``。
    """
    try:
        if not isinstance(行数, int) or 行数 <= 0:
            return []

        结果列表 = []
        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            for 行 in 文件对象:
                if len(结果列表) >= 行数:
                    break
                结果列表.append(行.rstrip("\n").rstrip("\r"))

        return 结果列表
    except Exception:
        return []


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：读取前2行 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("第1行\n第2行\n第3行\n", encoding="utf-8")
        print("结果:", 取文件前N行(str(文件), 2))

        print("\n===== 示例2：行数超过文件总行数 =====")
        print("结果:", 取文件前N行(str(文件), 10))

        print("\n===== 示例3：行数为0 =====")
        print("结果:", 取文件前N行(str(文件), 0))

        print("\n===== 示例4：空文件 =====")
        文件 = Path(临时目录) / "空文件.txt"
        文件.write_text("", encoding="utf-8")
        print("结果:", 取文件前N行(str(文件), 3))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取文件前N行(str(文件), 3))

        print("\n===== 示例6：应用场景-预览账号文件前5行 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号1\n账号2\n账号3\n账号4\n账号5\n账号6\n", encoding="utf-8")
        print("预览:", 取文件前N行(str(文件), 5))
