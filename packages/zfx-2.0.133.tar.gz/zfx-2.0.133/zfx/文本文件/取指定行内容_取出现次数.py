﻿def 取指定行内容_取出现次数(文件路径, 行号, 子字符串):
    """
    统计子字符串在指定行中出现的次数。

    功能说明:
        - 读取 UTF-8 文本文件的指定行；
        - 移除目标行行尾换行符；
        - 使用 str.count() 统计子字符串出现次数；
        - 行号无效或发生异常时返回 None。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        行号 (int): 要读取的行号，从 1 开始。
        子字符串 (str): 要统计出现次数的字符串。

    Returns:
        int | None:
            - int  : 子字符串在指定行中的出现次数，可能为 0。
            - None : 行号无效、读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 统计规则与 Python 的 str.count() 一致，不计算重叠匹配。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行内容 = file.readlines()

        # 检查行号是否有效
        if 行号 < 1 or 行号 > len(行内容):
            return None

        # 获取指定行并去除行尾的换行符
        指定行内容 = 行内容[行号 - 1].rstrip('\n')

        # 获取子字符串在指定行内容中出现的次数
        出现次数 = 指定行内容.count(子字符串)

        return 出现次数
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：统计指定行子字符串次数 =====")
        文件 = Path(临时目录) / "内容.txt"
        文件.write_text("成功 成功 失败\n第二行\n", encoding="utf-8")
        print("结果:", 取指定行内容_取出现次数(str(文件), 1, "成功"))

        print("\n===== 示例2：子字符串不存在 =====")
        print("结果:", 取指定行内容_取出现次数(str(文件), 1, "等待"))

        print("\n===== 示例3：统计第二行 =====")
        文件.write_text("第一行\nabc abc abc\n", encoding="utf-8")
        print("结果:", 取指定行内容_取出现次数(str(文件), 2, "abc"))

        print("\n===== 示例4：行号超出范围 =====")
        print("结果:", 取指定行内容_取出现次数(str(文件), 99, "abc"))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取指定行内容_取出现次数(str(不存在文件), 1, "abc"))

        print("\n===== 示例6：应用场景-统计某条日志中的错误次数 =====")
        文件 = Path(临时目录) / "日志.txt"
        文件.write_text("任务A 错误 错误 已停止\n任务B 正常\n", encoding="utf-8")
        print("错误次数:", 取指定行内容_取出现次数(str(文件), 1, "错误"))
