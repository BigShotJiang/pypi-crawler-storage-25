﻿def 删除包含关键词的行(文件路径: str, 关键词: str) -> bool:
    """删除文本文件中所有包含指定关键词的行。

    功能说明:
        - 这个函数用于从文本文件中删除包含某个关键词的整行内容。
        - 文件会按行读取，只要某一行里包含关键词，这一行就不会再写回文件。
        - 常用于清理失败记录、无效账号、重复标记、过期链接等文本数据。
        - 删除后会直接覆盖原文件内容，请确认关键词写对后再使用。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径: 要处理的文本文件路径。
        关键词: 要匹配并删除整行的关键词。

    Returns:
        删除处理成功返回 ``True``；失败时返回 ``False``。
    """
    try:
        if not isinstance(关键词, str) or 关键词 == "":
            return False

        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            行列表 = 文件对象.readlines()

        保留行列表 = [行 for 行 in 行列表 if 关键词 not in 行]

        with open(文件路径, "w", encoding="utf-8") as 文件对象:
            文件对象.writelines(保留行列表)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：删除包含关键词的行 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A----正常\n账号B----无效\n账号C----正常\n", encoding="utf-8")
        print("结果:", 删除包含关键词的行(str(文件), "无效"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：关键词不存在 =====")
        文件.write_text("账号A----正常\n账号C----正常\n", encoding="utf-8")
        print("结果:", 删除包含关键词的行(str(文件), "失败"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：空关键词 =====")
        print("结果:", 删除包含关键词的行(str(文件), ""))

        print("\n===== 示例4：读取不存在的文件 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 删除包含关键词的行(str(不存在文件), "无效"))

        print("\n===== 示例5：删除多行匹配内容 =====")
        文件 = Path(临时目录) / "日志.txt"
        文件.write_text("任务1 成功\n任务2 失败\n任务3 失败\n任务4 成功\n", encoding="utf-8")
        print("结果:", 删除包含关键词的行(str(文件), "失败"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例6：应用场景-清理已处理任务 =====")
        文件 = Path(临时目录) / "任务队列.txt"
        文件.write_text("任务A----已完成\n任务B----待处理\n任务C----已完成\n任务D----待处理\n", encoding="utf-8")
        print("结果:", 删除包含关键词的行(str(文件), "已完成"))
        剩余任务 = 文件.read_text(encoding="utf-8")
        print("剩余任务:\n" + 剩余任务)
