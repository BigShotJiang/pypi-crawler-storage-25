from pathlib import Path


def 清空文本文件(文件路径: str) -> bool:
    """清空文本文件中的全部内容。

    功能说明:
        - 这个函数用于保留文本文件本身，但删除文件中的全部内容。
        - 如果文件已经存在，会把文件内容清空为空字符串。
        - 如果文件不存在，会自动创建一个空文件。
        - 常用于重置日志文件、清空临时结果、重新开始写入任务数据。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要清空的文本文件路径。

    Returns:
        清空成功返回 ``True``；失败时返回 ``False``。
    """
    try:
        输出路径 = Path(文件路径)
        if not str(输出路径).strip():
            return False
        if 输出路径.parent != Path("."):
            输出路径.parent.mkdir(parents=True, exist_ok=True)

        with open(输出路径, "w", encoding="utf-8") as 文件对象:
            文件对象.write("")

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：清空已有文本文件 =====")
        文件 = Path(临时目录) / "结果.txt"
        文件.write_text("第一行\n第二行\n", encoding="utf-8")
        print("结果:", 清空文本文件(str(文件)))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例2：清空空文件 =====")
        文件 = Path(临时目录) / "空文件.txt"
        文件.write_text("", encoding="utf-8")
        print("结果:", 清空文本文件(str(文件)))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例3：文件不存在时自动创建 =====")
        文件 = Path(临时目录) / "新文件.txt"
        print("结果:", 清空文本文件(str(文件)))
        print("文件是否存在:", 文件.exists())

        print("\n===== 示例4：自动创建上级目录 =====")
        文件 = Path(临时目录) / "输出" / "日志.txt"
        print("结果:", 清空文本文件(str(文件)))
        print("文件是否存在:", 文件.exists())

        print("\n===== 示例5：空文件路径 =====")
        print("结果:", 清空文本文件(""))

        print("\n===== 示例6：应用场景-任务开始前重置运行日志 =====")
        文件 = Path(临时目录) / "运行日志.txt"
        文件.write_text("旧日志1\n旧日志2\n", encoding="utf-8")
        清空文本文件(str(文件))
        文件.write_text("新任务开始\n", encoding="utf-8")
        print("文件内容:", 文件.read_text(encoding="utf-8"))
