﻿def 取首行无标记文本S(文件路径, 标记列表):
    r"""
    取出第一行不包含任意标记的文本。

    功能说明:
        - 按 UTF-8 编码逐行读取文本文件；
        - 标记列表中的任意标记只要出现在行内，该行即视为已标记；
        - 返回第一行未包含任何标记的行号与内容；
        - 所有行都包含标记时返回 None；
        - 文件读取失败或发生异常时返回 False。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        标记列表 (list[str]): 用于判断一行是否已标记的字符串列表。

    Returns:
        tuple[int, str] | None | bool:
            - (行号, 行内容): 找到第一行未包含任何标记的文本，行号从 1 开始。
            - None          : 所有行都已包含标记。
            - False         : 文件读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 判断规则是“行内包含任意标记内容”；
        - 返回的行内容会移除行尾换行符。
    """
    try:
        with open(文件路径, 'r', encoding='utf-8') as 文件对象:
            for 索引, 行内容 in enumerate(文件对象, start=1):
                当前行 = 行内容.rstrip('\n').rstrip('\r')
                if not any(标记 in 当前行 for 标记 in 标记列表):
                    return 索引, 当前行
        return None
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：按多个标记取第一行未标记文本 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A----已完成\n账号B----跳过\n账号C\n", encoding="utf-8")
        print("结果:", 取首行无标记文本S(str(文件), ["已完成", "跳过"]))

        print("\n===== 示例2：第一行就未命中任何标记 =====")
        文件.write_text("账号A\n账号B----已完成\n", encoding="utf-8")
        print("结果:", 取首行无标记文本S(str(文件), ["已完成", "跳过"]))

        print("\n===== 示例3：所有行都包含标记 =====")
        文件.write_text("账号A----已完成\n账号B----跳过\n", encoding="utf-8")
        print("结果:", 取首行无标记文本S(str(文件), ["已完成", "跳过"]))

        print("\n===== 示例4：标记列表为空 =====")
        文件.write_text("账号A\n账号B\n", encoding="utf-8")
        print("结果:", 取首行无标记文本S(str(文件), []))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取首行无标记文本S(str(不存在文件), ["已完成"]))

        print("\n===== 示例6：应用场景-跳过完成和无效账号，取下一条可处理记录 =====")
        文件 = Path(临时目录) / "账号任务.txt"
        文件.write_text("账号A----已完成\n账号B----无效\n账号C----待处理\n", encoding="utf-8")
        print("下一条可处理记录:", 取首行无标记文本S(str(文件), ["已完成", "无效"]))
