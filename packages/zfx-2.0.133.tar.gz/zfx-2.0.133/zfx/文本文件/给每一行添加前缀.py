def 给每一行添加前缀(文件路径: str, 前缀: str) -> bool:
    """给文本文件中的每一行开头添加固定前缀。

    功能说明:
        - 这个函数用于给文本文件的每一行开头添加同一段内容。
        - 函数会保留原来的行顺序，并把处理后的结果写回原文件。
        - 空行也会添加前缀，如果不想处理空行，可以先使用删除空行类函数。
        - 常用于给关键词补完整链接前缀、给任务添加编号前缀、给记录添加统一标识。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要处理的文本文件路径。
        前缀: 要添加到每一行开头的固定内容。

    Returns:
        处理成功返回 ``True``；失败时返回 ``False``。
    """
    try:
        if not isinstance(前缀, str):
            return False

        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            行列表 = 文件对象.readlines()

        新行列表 = []
        for 行 in 行列表:
            行内容 = 行.rstrip("\n").rstrip("\r")
            新行列表.append(前缀 + 行内容 + "\n")

        with open(文件路径, "w", encoding="utf-8") as 文件对象:
            文件对象.writelines(新行列表)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：给每行添加普通前缀 =====")
        文件 = Path(临时目录) / "关键词.txt"
        文件.write_text("python\nmysql\nexcel\n", encoding="utf-8")
        print("结果:", 给每一行添加前缀(str(文件), "搜索:"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：添加空前缀 =====")
        文件.write_text("A\nB\n", encoding="utf-8")
        print("结果:", 给每一行添加前缀(str(文件), ""))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：空文件 =====")
        文件 = Path(临时目录) / "空文件.txt"
        文件.write_text("", encoding="utf-8")
        print("结果:", 给每一行添加前缀(str(文件), "前缀"))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例4：前缀不是字符串 =====")
        文件 = Path(临时目录) / "错误.txt"
        文件.write_text("A\nB\n", encoding="utf-8")
        print("结果:", 给每一行添加前缀(str(文件), 123))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 给每一行添加前缀(str(文件), "前缀"))

        print("\n===== 示例6：应用场景-给路径片段补完整网址前缀 =====")
        文件 = Path(临时目录) / "路径.txt"
        文件.write_text("/item/1001\n/item/1002\n/item/1003\n", encoding="utf-8")
        print("结果:", 给每一行添加前缀(str(文件), "https://example.com"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))
