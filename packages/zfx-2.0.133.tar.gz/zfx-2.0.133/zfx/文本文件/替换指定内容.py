﻿def 替换指定内容(文件路径, 旧内容, 新内容):
    """
    替换文本文件中的指定内容。

    功能说明:
        - 读取 UTF-8 文本文件的全部内容；
        - 使用 str.replace() 将 旧内容 替换为 新内容；
        - 替换后写回原文件；
        - 操作成功返回 True，失败返回 False。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要修改的文本文件路径。
        旧内容 (str): 要被替换的内容。
        新内容 (str): 替换后的新内容。

    Returns:
        bool:
            - True  : 替换并写入成功。
            - False : 替换失败、写入失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取和写入；
        - 替换规则与 Python 的 str.replace() 一致，会替换全部匹配内容。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as 文件:
            文本 = 文件.read()

        # 替换文本内容
        替换后文本 = 文本.replace(旧内容, 新内容)

        # 以写入模式保存修改后的文本内容
        with open(文件路径, 'w', encoding='utf-8') as 文件:
            文件.write(替换后文本)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：替换普通内容 =====")
        文件 = Path(临时目录) / "内容.txt"
        文件.write_text("你好，旧内容。\n", encoding="utf-8")
        print("结果:", 替换指定内容(str(文件), "旧内容", "新内容"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：替换多处内容 =====")
        文件.write_text("失败\n成功\n失败\n", encoding="utf-8")
        print("结果:", 替换指定内容(str(文件), "失败", "待重试"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：旧内容不存在 =====")
        print("结果:", 替换指定内容(str(文件), "不存在", "新内容"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例4：替换为空字符串 =====")
        文件.write_text("A-B-C\n", encoding="utf-8")
        print("结果:", 替换指定内容(str(文件), "-", ""))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 替换指定内容(str(不存在文件), "旧", "新"))

        print("\n===== 示例6：应用场景-把任务状态从待处理改为已完成 =====")
        文件 = Path(临时目录) / "任务.txt"
        文件.write_text("任务A----待处理\n任务B----待处理\n", encoding="utf-8")
        print("结果:", 替换指定内容(str(文件), "待处理", "已完成"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))
