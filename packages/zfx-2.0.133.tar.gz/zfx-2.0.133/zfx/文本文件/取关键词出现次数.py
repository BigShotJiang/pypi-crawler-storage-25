﻿def 取关键词出现次数(文件路径, 关键词):
    """
    统计关键词在文本文件中出现的次数。

    功能说明:
        - 按 UTF-8 编码逐行读取文本文件；
        - 使用 str.count() 统计关键词在每行中的出现次数；
        - 返回所有行的累计次数；
        - 读取失败或发生异常时返回 None。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        关键词 (str): 要统计出现次数的关键词。

    Returns:
        int | None:
            - int  : 关键词出现的总次数，可能为 0。
            - None : 读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 统计规则与 Python 的 str.count() 一致，不计算重叠匹配。
    """
    try:
        出现次数 = 0
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as 文件:
            for 行 in 文件:
                出现次数 += 行.count(关键词)
        return 出现次数
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：统计普通关键词次数 =====")
        文件 = Path(临时目录) / "内容.txt"
        文件.write_text("成功\n失败\n成功\n", encoding="utf-8")
        print("结果:", 取关键词出现次数(str(文件), "成功"))

        print("\n===== 示例2：同一行出现多次 =====")
        文件.write_text("成功 成功 成功\n失败\n", encoding="utf-8")
        print("结果:", 取关键词出现次数(str(文件), "成功"))

        print("\n===== 示例3：关键词不存在 =====")
        print("结果:", 取关键词出现次数(str(文件), "等待"))

        print("\n===== 示例4：空关键词 =====")
        print("结果:", 取关键词出现次数(str(文件), ""))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取关键词出现次数(str(不存在文件), "成功"))

        print("\n===== 示例6：应用场景-统计日志中失败出现次数 =====")
        文件 = Path(临时目录) / "运行日志.txt"
        文件.write_text("任务A 失败\n任务B 成功\n任务C 失败 失败原因: 超时\n", encoding="utf-8")
        print("失败出现次数:", 取关键词出现次数(str(文件), "失败"))
