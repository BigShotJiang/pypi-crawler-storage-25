﻿def 删除指定行(文件路径, 行号):
    """
    删除文本文件中的指定行。

    功能说明:
        - 读取 UTF-8 文本文件的全部行；
        - 删除指定行号对应的内容；
        - 行号从 1 开始计数；
        - 删除后写回原文件并截断多余内容；
        - 行号无效或发生异常时返回 False。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要操作的文本文件路径。
        行号 (int): 要删除的行号，从 1 开始。

    Returns:
        bool:
            - True  : 删除成功。
            - False : 删除失败、行号无效或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取和写入；
        - 本函数会直接修改原文件。
    """
    try:
        # 以读写模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r+', encoding='utf-8') as file:
            行列表 = file.readlines()

            # 检查行号是否在有效范围内
            if 0 < 行号 <= len(行列表):
                行列表.pop(行号 - 1)  # 删除指定行

                # 写回剩余内容
                file.seek(0)
                file.writelines(行列表)
                file.truncate()  # 截断文件以移除多余内容
                return True

            return False
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：删除中间一行 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("第一行\n第二行\n第三行\n", encoding="utf-8")
        print("结果:", 删除指定行(str(文件), 2))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：删除第一行 =====")
        文件.write_text("A\nB\nC\n", encoding="utf-8")
        print("结果:", 删除指定行(str(文件), 1))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：删除最后一行 =====")
        文件.write_text("A\nB\nC\n", encoding="utf-8")
        print("结果:", 删除指定行(str(文件), 3))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例4：行号超出范围 =====")
        print("结果:", 删除指定行(str(文件), 99))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 删除指定行(str(不存在文件), 1))

        print("\n===== 示例6：应用场景-删除已处理队列中的第一条任务 =====")
        文件 = Path(临时目录) / "任务队列.txt"
        文件.write_text("任务A\n任务B\n任务C\n", encoding="utf-8")
        print("结果:", 删除指定行(str(文件), 1))
        print("剩余任务:", 文件.read_text(encoding="utf-8"))
