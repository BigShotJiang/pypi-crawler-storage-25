﻿from pathlib import Path
from typing import Any, List


def 保存列表到文本(文件路径: str, 列表数据: List[Any]) -> bool:
    """将列表中的每个成员按一行一个保存到文本文件。

    功能说明:
        - 这个函数用于把列表数据保存成普通文本文件。
        - 列表中的每个成员都会转换成字符串，并单独写入一行。
        - 常用于保存账号列表、链接列表、关键词列表、任务列表等一行一条的数据。
        - 保存时会覆盖原文件内容；如果文件不存在，会自动创建文件。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径: 要保存到的文本文件路径。
        列表数据: 要保存的列表数据。

    Returns:
        保存成功返回 ``True``；失败时返回 ``False``。
    """
    try:
        if not isinstance(列表数据, list):
            return False

        输出路径 = Path(文件路径)
        if not str(输出路径).strip():
            return False

        if 输出路径.parent != Path("."):
            输出路径.parent.mkdir(parents=True, exist_ok=True)

        with open(输出路径, "w", encoding="utf-8") as 文件对象:
            for 成员 in 列表数据:
                文件对象.write(str(成员))
                文件对象.write("\n")

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：保存普通字符串列表 =====")
        文件 = str(Path(临时目录) / "账号.txt")
        数据 = ["user1", "user2", "user3"]
        print("结果:", 保存列表到文本(文件, 数据))
        print("文件内容:", Path(文件).read_text(encoding="utf-8"))

        print("\n===== 示例2：保存空列表 =====")
        文件 = str(Path(临时目录) / "空列表.txt")
        数据 = []
        print("结果:", 保存列表到文本(文件, 数据))
        print("文件内容:", repr(Path(文件).read_text(encoding="utf-8")))

        print("\n===== 示例3：保存数字列表 =====")
        文件 = str(Path(临时目录) / "数字.txt")
        数据 = [100, 200, 300]
        print("结果:", 保存列表到文本(文件, 数据))
        print("文件内容:", Path(文件).read_text(encoding="utf-8"))

        print("\n===== 示例4：保存包含复杂成员的列表 =====")
        文件 = str(Path(临时目录) / "复杂成员.txt")
        数据 = ["任务A", {"状态": "完成"}, ["标签1", "标签2"]]
        print("结果:", 保存列表到文本(文件, 数据))
        print("文件内容:", Path(文件).read_text(encoding="utf-8"))

        print("\n===== 示例5：传入的不是列表 =====")
        文件 = str(Path(临时目录) / "错误.txt")
        数据 = ("a", "b", "c")
        print("结果:", 保存列表到文本(文件, 数据))

        print("\n===== 示例6：应用场景-保存采集到的商品链接 =====")
        文件 = str(Path(临时目录) / "商品链接.txt")
        商品链接 = [
            "https://example.com/item/1001",
            "https://example.com/item/1002",
            "https://example.com/item/1003",
        ]
        print("结果:", 保存列表到文本(文件, 商品链接))
        print("文件内容:", Path(文件).read_text(encoding="utf-8"))
