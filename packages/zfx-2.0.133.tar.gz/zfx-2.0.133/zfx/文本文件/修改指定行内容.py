﻿def 修改指定行内容(文件路径, 行号, 新内容):
    """
    修改文本文件中指定行的内容。

    功能说明:
        - 读取 UTF-8 文本文件的全部行；
        - 使用 新内容 替换指定行；
        - 行号从 1 开始计数；
        - 修改成功后写回原文件；
        - 失败、文件不可读写或行号越界时返回 False。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要修改的文本文件路径。
        行号 (int): 要修改的行号，从 1 开始。
        新内容 (str): 用于替换该行的新内容，函数会自动补充行尾换行符。

    Returns:
        bool:
            - True  : 修改成功。
            - False : 修改失败、行号无效或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取和写入；
        - 本函数会覆盖原文件内容。
    """
    try:
        # 打开文件并读取所有行，假定文件为 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行列表 = file.readlines()

        # 检查行号是否在范围内
        if 行号 < 1 or 行号 > len(行列表):
            return False

        # 替换指定行的内容
        行列表[行号 - 1] = 新内容 + '\n'

        # 写回修改后的内容，保持 UTF-8 编码
        with open(文件路径, 'w', encoding='utf-8') as file:
            file.writelines(行列表)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：修改指定行内容 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("第一行\n第二行\n第三行\n", encoding="utf-8")
        print("结果:", 修改指定行内容(str(文件), 2, "新的第二行"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：修改第一行 =====")
        文件.write_text("A\nB\nC\n", encoding="utf-8")
        print("结果:", 修改指定行内容(str(文件), 1, "新的A"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：行号超出范围 =====")
        print("结果:", 修改指定行内容(str(文件), 10, "不存在的行"))

        print("\n===== 示例4：行号小于1 =====")
        print("结果:", 修改指定行内容(str(文件), 0, "错误行号"))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 修改指定行内容(str(不存在文件), 1, "内容"))

        print("\n===== 示例6：应用场景-把任务状态改成已完成 =====")
        文件 = Path(临时目录) / "任务.txt"
        文件.write_text("任务A----待处理\n任务B----待处理\n任务C----待处理\n", encoding="utf-8")
        print("结果:", 修改指定行内容(str(文件), 2, "任务B----已完成"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))
