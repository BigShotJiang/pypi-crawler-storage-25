﻿def 取指定行内容_取右边(文件路径, 行号, 分隔符):
    """
    读取指定行内容，并返回分隔符右侧的文本。

    功能说明:
        - 读取 UTF-8 文本文件的指定行；
        - 查找指定分隔符第一次出现的位置；
        - 返回分隔符右侧的全部内容；
        - 行号无效、分隔符不存在或发生异常时返回 None。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        行号 (int): 要读取的行号，从 1 开始。
        分隔符 (str): 用于定位右侧内容的分隔符。

    Returns:
        str | None:
            - str  : 分隔符右侧的内容。
            - None : 行号无效、未找到分隔符、读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 只使用分隔符第一次出现的位置。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行内容 = file.readlines()

        # 检查行号是否有效
        if 行号 < 1 or 行号 > len(行内容):
            return None

        # 获取指定行并去除行尾的换行符
        指定行内容 = 行内容[行号 - 1].rstrip('\n')

        # 查找分隔符位置并获取分隔符右边的内容
        分隔符位置 = 指定行内容.find(分隔符)
        if 分隔符位置 == -1:
            return None

        # 返回分隔符右边的内容
        右边内容 = 指定行内容[分隔符位置 + len(分隔符):]

        return 右边内容
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：取分隔符右边内容 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("name=张三\n", encoding="utf-8")
        print("结果:", 取指定行内容_取右边(str(文件), 1, "="))

        print("\n===== 示例2：分隔符不存在 =====")
        print("结果:", 取指定行内容_取右边(str(文件), 1, "----"))

        print("\n===== 示例3：分隔符在开头 =====")
        文件.write_text("=右边内容\n", encoding="utf-8")
        print("结果:", 取指定行内容_取右边(str(文件), 1, "="))

        print("\n===== 示例4：行号超出范围 =====")
        print("结果:", 取指定行内容_取右边(str(文件), 9, "="))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取指定行内容_取右边(str(不存在文件), 1, "="))

        print("\n===== 示例6：应用场景-取状态字段右侧内容 =====")
        文件 = Path(临时目录) / "任务.txt"
        文件.write_text("任务A----状态=已完成\n", encoding="utf-8")
        print("状态:", 取指定行内容_取右边(str(文件), 1, "状态="))
