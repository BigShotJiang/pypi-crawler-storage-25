﻿def 取首行无标记文本(文件路径: str, 标记内容: str):
    r"""
    取出第一行不包含指定标记的文本。

    功能说明:
        - 按 UTF-8 编码逐行读取文本文件；
        - 跳过所有包含 标记内容 的行；
        - 返回第一行未包含标记的行号与内容；
        - 所有行都包含标记时返回 None；
        - 文件读取失败或发生异常时返回 False。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        标记内容 (str): 用于判断一行是否已标记的字符串。

    Returns:
        tuple[int, str] | None | bool:
            - (行号, 行内容): 找到第一行未包含标记的文本，行号从 1 开始。
            - None          : 所有行都已包含标记。
            - False         : 文件读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 判断规则是“行内包含标记内容”；
        - 返回的行内容会移除行尾换行符。
    """
    try:
        with open(文件路径, 'r', encoding='utf-8') as 文件对象:
            for 索引, 行内容 in enumerate(文件对象, start=1):
                当前行 = 行内容.rstrip('\n').rstrip('\r')
                if 标记内容 not in 当前行:
                    return 索引, 当前行
        return None
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：取第一行未标记文本 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A----已完成\n账号B\n账号C\n", encoding="utf-8")
        print("结果:", 取首行无标记文本(str(文件), "已完成"))

        print("\n===== 示例2：第一行就未标记 =====")
        文件.write_text("账号A\n账号B----已完成\n", encoding="utf-8")
        print("结果:", 取首行无标记文本(str(文件), "已完成"))

        print("\n===== 示例3：所有行都已标记 =====")
        文件.write_text("账号A----已完成\n账号B----已完成\n", encoding="utf-8")
        print("结果:", 取首行无标记文本(str(文件), "已完成"))

        print("\n===== 示例4：空文件 =====")
        文件.write_text("", encoding="utf-8")
        print("结果:", 取首行无标记文本(str(文件), "已完成"))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取首行无标记文本(str(不存在文件), "已完成"))

        print("\n===== 示例6：应用场景-取下一条待处理账号 =====")
        文件 = Path(临时目录) / "任务账号.txt"
        文件.write_text("账号A----已完成\n账号B----待处理\n账号C\n", encoding="utf-8")
        结果 = 取首行无标记文本(str(文件), "已完成")
        print("下一条可处理记录:", 结果)
