def 替换包含关键词的整行(文件路径: str, 关键词: str, 新内容: str) -> bool:
    """把文本文件中所有包含指定关键词的整行替换成新内容。

    功能说明:
        - 这个函数用于按关键词定位文本行，并替换整行内容。
        - 只要某一行包含关键词，这一整行就会被替换为新内容。
        - 函数会保留其他不包含关键词的行，并把结果写回原文件。
        - 常用于把某个账号、链接、任务记录更新为新的状态行。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要处理的文本文件路径。
        关键词: 用于匹配整行的关键词。
        新内容: 替换后的整行内容，函数会自动补充换行符。

    Returns:
        替换并写入成功返回 ``True``；失败时返回 ``False``。
    """
    try:
        if not isinstance(关键词, str) or 关键词 == "":
            return False
        if not isinstance(新内容, str):
            return False

        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            行列表 = 文件对象.readlines()

        新行列表 = []
        for 行 in 行列表:
            if 关键词 in 行:
                新行列表.append(新内容 + "\n")
            else:
                新行列表.append(行)

        with open(文件路径, "w", encoding="utf-8") as 文件对象:
            文件对象.writelines(新行列表)

        return True
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：替换包含关键词的整行 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A----待处理\n账号B----待处理\n", encoding="utf-8")
        print("结果:", 替换包含关键词的整行(str(文件), "账号A", "账号A----已完成"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：关键词不存在 =====")
        print("结果:", 替换包含关键词的整行(str(文件), "账号X", "账号X----已完成"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：多行同时命中 =====")
        文件.write_text("任务A----失败\n任务B----成功\n任务C----失败\n", encoding="utf-8")
        print("结果:", 替换包含关键词的整行(str(文件), "失败", "失败任务----待重试"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例4：空关键词 =====")
        print("结果:", 替换包含关键词的整行(str(文件), "", "新内容"))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 替换包含关键词的整行(str(文件), "账号A", "账号A----已完成"))

        print("\n===== 示例6：应用场景-把指定链接记录标记为已采集 =====")
        文件 = Path(临时目录) / "链接状态.txt"
        文件.write_text("https://a.com----待采集\nhttps://b.com----待采集\n", encoding="utf-8")
        print("结果:", 替换包含关键词的整行(str(文件), "https://b.com", "https://b.com----已采集"))
        print("文件内容:", 文件.read_text(encoding="utf-8"))
