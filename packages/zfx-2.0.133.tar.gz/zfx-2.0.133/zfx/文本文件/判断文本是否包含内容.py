﻿def 判断文本是否包含内容(文件路径: str, 内容: str) -> bool:
    """判断文本文件中是否包含指定内容。

    功能说明:
        - 这个函数用于检查文本文件里有没有某段指定内容。
        - 只要文件任意位置包含传入的内容，就返回 True。
        - 如果文件不存在、读取失败、内容为空，都会返回 False。
        - 常用于处理前先判断某个账号、链接、关键词或状态是否已经写入文本。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径: 要检查的文本文件路径。
        内容: 要判断是否存在的内容。

    Returns:
        包含时返回 ``True``；不包含或失败时返回 ``False``。
    """
    try:
        if not isinstance(内容, str) or 内容 == "":
            return False

        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            return 内容 in 文件对象.read()
    except Exception:
        return False


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：文本中包含指定内容 =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("user1\nuser2\nuser3\n", encoding="utf-8")
        print("结果:", 判断文本是否包含内容(str(文件), "user2"))

        print("\n===== 示例2：文本中不包含指定内容 =====")
        print("结果:", 判断文本是否包含内容(str(文件), "user9"))

        print("\n===== 示例3：空内容 =====")
        print("结果:", 判断文本是否包含内容(str(文件), ""))

        print("\n===== 示例4：读取不存在的文件 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 判断文本是否包含内容(str(不存在文件), "user1"))

        print("\n===== 示例5：判断一段内容而不是单个词 =====")
        文件 = Path(临时目录) / "日志.txt"
        文件.write_text("任务1 成功\n任务2 失败: 网络错误\n", encoding="utf-8")
        print("结果:", 判断文本是否包含内容(str(文件), "失败: 网络错误"))

        print("\n===== 示例6：应用场景-写入前检查链接是否已存在 =====")
        文件 = Path(临时目录) / "已采集链接.txt"
        文件.write_text("https://example.com/a\nhttps://example.com/b\n", encoding="utf-8")
        新链接 = "https://example.com/b"
        if 判断文本是否包含内容(str(文件), 新链接):
            print("结果: 链接已存在，不重复写入")
        else:
            print("结果: 链接不存在，可以写入")
