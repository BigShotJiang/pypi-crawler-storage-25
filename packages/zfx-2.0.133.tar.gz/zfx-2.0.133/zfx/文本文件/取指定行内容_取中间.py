﻿def 取指定行内容_取中间(文件路径, 行号, 左字符串, 右字符串):
    """
    读取指定行内容，并取出左右边界之间的文本。

    功能说明:
        - 读取 UTF-8 文本文件的指定行；
        - 先查找 左字符串 的位置；
        - 再从左边界之后查找 右字符串 的位置；
        - 返回两个边界之间的内容；
        - 行号无效、边界不存在或发生异常时返回 None。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。
    Args:
        文件路径 (str): 要读取的文本文件路径。
        行号 (int): 要读取的行号，从 1 开始。
        左字符串 (str): 左侧边界字符串。
        右字符串 (str): 右侧边界字符串。

    Returns:
        str | None:
            - str  : 左右边界之间的内容。
            - None : 行号无效、未找到边界、读取失败或发生异常。

    Notes:
        - 文件按 UTF-8 编码读取；
        - 只匹配指定行中第一次符合条件的左右边界。
    """
    try:
        # 以读取模式打开文件，使用 UTF-8 编码
        with open(文件路径, 'r', encoding='utf-8') as file:
            行内容 = file.readlines()

        # 检查行号是否有效
        if 行号 < 1 or 行号 > len(行内容):
            return None

        # 获取指定行并去除行尾的换行符
        指定行内容 = 行内容[行号 - 1].rstrip('\n')

        # 查找左字符串的位置
        左字符串位置 = 指定行内容.find(左字符串)
        if 左字符串位置 == -1:
            return None

        # 查找右字符串的位置
        右字符串位置 = 指定行内容.find(右字符串, 左字符串位置 + len(左字符串))
        if 右字符串位置 == -1:
            return None

        # 获取左字符串和右字符串之间的内容
        中间内容 = 指定行内容[左字符串位置 + len(左字符串):右字符串位置]

        return 中间内容
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：取左右边界中间内容 =====")
        文件 = Path(临时目录) / "数据.txt"
        文件.write_text("标题：[重要内容] 结尾\n", encoding="utf-8")
        print("结果:", 取指定行内容_取中间(str(文件), 1, "[", "]"))

        print("\n===== 示例2：左边界不存在 =====")
        print("结果:", 取指定行内容_取中间(str(文件), 1, "{", "]"))

        print("\n===== 示例3：右边界不存在 =====")
        print("结果:", 取指定行内容_取中间(str(文件), 1, "[", "}"))

        print("\n===== 示例4：行号超出范围 =====")
        print("结果:", 取指定行内容_取中间(str(文件), 9, "[", "]"))

        print("\n===== 示例5：文件不存在 =====")
        不存在文件 = Path(临时目录) / "不存在.txt"
        print("结果:", 取指定行内容_取中间(str(不存在文件), 1, "[", "]"))

        print("\n===== 示例6：应用场景-从账号记录中取 token =====")
        文件 = Path(临时目录) / "账号.txt"
        文件.write_text("账号A----token=abc123----已完成\n", encoding="utf-8")
        print("token:", 取指定行内容_取中间(str(文件), 1, "token=", "----"))
