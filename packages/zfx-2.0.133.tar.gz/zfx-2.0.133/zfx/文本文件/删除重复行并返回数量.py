from typing import Optional


def 删除重复行并返回数量(文件路径: str) -> Optional[int]:
    """删除文本文件中的重复行，并返回删除掉的重复行数量。

    功能说明:
        - 这个函数用于按行删除文本文件里的重复内容。
        - 相同内容的行只保留第一次出现的位置，后面再次出现的重复行会被删除。
        - 函数会返回本次实际删除了多少行，方便确认清理效果。
        - 常用于清理重复账号、重复链接、重复关键词、重复任务记录等文本数据。

    适用文件:
        - 本函数按 UTF-8 普通文本方式读取或写入文件，不限制文件后缀。
        - 常见可处理后缀包括 .txt、.csv、.tsv、.log、.json、.jsonl、.md、.ini、.conf、.yaml、.xml，以及 .py、.js、.html、.css 等代码文本文件。
        - .docx、.xlsx、.pdf、图片、压缩包等非纯文本文件，不适合直接使用本函数处理。

    Args:
        文件路径: 要去重的文本文件路径。

    Returns:
        成功时返回删除掉的重复行数量；失败时返回 ``None``。
    """
    try:
        with open(文件路径, "r", encoding="utf-8") as 文件对象:
            行列表 = 文件对象.readlines()

        已出现 = set()
        去重后行列表 = []
        for 行 in 行列表:
            行内容 = 行.rstrip("\n").rstrip("\r")
            if 行内容 not in 已出现:
                已出现.add(行内容)
                去重后行列表.append(行)

        with open(文件路径, "w", encoding="utf-8") as 文件对象:
            文件对象.writelines(去重后行列表)

        return len(行列表) - len(去重后行列表)
    except Exception:
        return None


if __name__ == "__main__":
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as 临时目录:
        print("===== 示例1：删除普通重复行 =====")
        文件 = Path(临时目录) / "链接.txt"
        文件.write_text("a\nb\na\nc\nb\n", encoding="utf-8")
        print("删除数量:", 删除重复行并返回数量(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例2：没有重复行 =====")
        文件 = Path(临时目录) / "无重复.txt"
        文件.write_text("a\nb\nc\n", encoding="utf-8")
        print("删除数量:", 删除重复行并返回数量(str(文件)))
        print("文件内容:", 文件.read_text(encoding="utf-8"))

        print("\n===== 示例3：空文件 =====")
        文件 = Path(临时目录) / "空文件.txt"
        文件.write_text("", encoding="utf-8")
        print("删除数量:", 删除重复行并返回数量(str(文件)))

        print("\n===== 示例4：空行重复也会被删除 =====")
        文件 = Path(临时目录) / "空行.txt"
        文件.write_text("a\n\n\nb\n\n", encoding="utf-8")
        print("删除数量:", 删除重复行并返回数量(str(文件)))
        print("文件内容:", repr(文件.read_text(encoding="utf-8")))

        print("\n===== 示例5：文件不存在 =====")
        文件 = Path(临时目录) / "不存在.txt"
        print("删除数量:", 删除重复行并返回数量(str(文件)))

        print("\n===== 示例6：应用场景-清理重复采集结果并查看删除数量 =====")
        文件 = Path(临时目录) / "采集结果.txt"
        文件.write_text("商品A\n商品B\n商品A\n商品C\n商品B\n商品D\n", encoding="utf-8")
        删除数量 = 删除重复行并返回数量(str(文件))
        print("删除数量:", 删除数量)
        print("清理后内容:", 文件.read_text(encoding="utf-8"))
