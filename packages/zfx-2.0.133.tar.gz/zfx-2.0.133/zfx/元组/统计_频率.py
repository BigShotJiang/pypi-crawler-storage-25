﻿from typing import Any, Dict, Tuple


def 统计_频率(元组数据: Tuple[Any, ...]) -> Dict[Any, int]:
    """统计元组中各成员的出现频率。

    功能说明:
        - 这个函数用于统计元组中各成员的出现频率。
        - 常用于查看元组中各类成员的分布情况、频率情况或占比情况。
        - 返回结果通常是统计后的结构化数据，方便继续分析、展示或二次处理。

    Args:
        元组数据: 待统计的元组。

    Returns:
        统计成功时返回频率字典；失败时返回空字典 ``{}``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return {}

        结果: Dict[Any, int] = {}
        for 元素 in 元组数据:
            try:
                结果[元素] = 结果.get(元素, 0) + 1
            except Exception:
                pass
        return 结果
    except Exception:
        return {}


if __name__ == "__main__":
    print("===== 示例1：基础频率统计 =====")
    数据 = ("a", "b", "a", "c", "a")
    print("结果:", 统计_频率(数据))

    print("\n===== 示例2：不可哈希成员会被跳过 =====")
    数据 = ("a", [1], "a", {"x": 1})
    print("结果:", 统计_频率(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = ["a", "b", "a"]
    print("结果:", 统计_频率(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 统计_频率(数据))

    print("\n===== 示例5：布尔值与数字相等性 =====")
    数据 = (0, False, 1, True, 1)
    print("结果:", 统计_频率(数据))

    print("\n===== 示例6：应用场景-统计日志级别分布 =====")
    日志级别 = ("INFO", "ERROR", "INFO", "WARNING", "ERROR", "INFO")
    print("结果:", 统计_频率(日志级别))



