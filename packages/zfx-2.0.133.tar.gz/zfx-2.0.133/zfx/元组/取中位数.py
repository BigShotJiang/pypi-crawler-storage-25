﻿from numbers import Number
from typing import Any, Tuple


def 取中位数(元组数据: Tuple[Any, ...]):
    """返回元组的中位数。

    功能说明:
        - 这个函数用于返回元组的中位数。
        - 常用于从元组中读取某个成员、某一段数据，或者计算出一个统计结果。
        - 如果当前数据不适合处理，函数会返回约定好的结果，方便新手直接判断这次是否成功取到值。

    Args:
        元组数据: 仅包含数字成员的元组。

    Returns:
        成功时返回 ``(中位数, True)``；失败时返回 ``(None, False)``。
    """
    try:
        if not isinstance(元组数据, tuple) or not 元组数据:
            return None, False
        if not all(isinstance(元素, Number) for 元素 in 元组数据):
            return None, False

        排序后 = sorted(元组数据)
        长度 = len(排序后)
        中间索引 = 长度 // 2

        if 长度 % 2 == 1:
            return 排序后[中间索引], True
        return (排序后[中间索引 - 1] + 排序后[中间索引]) / 2, True
    except Exception:
        return None, False


if __name__ == "__main__":
    print("===== 示例1：奇数个数字 =====")
    数据 = (7, 1, 5)
    print("结果:", 取中位数(数据))

    print("\n===== 示例2：偶数个数字 =====")
    数据 = (10, 2, 8, 4)
    print("结果:", 取中位数(数据))

    print("\n===== 示例3：包含非数字 =====")
    数据 = (1, "2", 3)
    print("结果:", 取中位数(数据))

    print("\n===== 示例4：单个数字 =====")
    数据 = (100,)
    print("结果:", 取中位数(数据))

    print("\n===== 示例5：空元组 =====")
    数据 = ()
    print("结果:", 取中位数(数据))

    print("\n===== 示例6：应用场景-统计接口响应中位数 =====")
    响应耗时毫秒 = (120, 110, 118, 600, 117, 119, 121)
    print("结果:", 取中位数(响应耗时毫秒))



