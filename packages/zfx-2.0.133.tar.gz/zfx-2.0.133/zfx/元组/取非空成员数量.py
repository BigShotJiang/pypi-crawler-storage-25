﻿from typing import Any, Tuple


def _是否空值(值: Any) -> bool:
    if 值 is None:
        return True
    if isinstance(值, (str, bytes, tuple, list, dict, set)) and len(值) == 0:
        return True
    return False


def 取非空成员数量(元组数据: Tuple[Any, ...]):
    """返回元组中的非空成员数量。

    功能说明:
        - 这个函数用于返回元组中的非空成员数量。
        - 这个函数围绕元组数据做处理，重点是把常见操作封装成更容易直接调用的形式。
        - 使用时一般只需要关注传入什么数据、返回什么结果，不需要自己重复写底层处理逻辑。

    空值定义:
        ``None``、空字符串、空列表、空字典、空元组、空集合。

    Args:
        元组数据: 待统计的元组。

    Returns:
        成功时返回数量；失败时返回 ``None``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return None
        return sum(1 for 元素 in 元组数据 if not _是否空值(元素))
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：基础非空统计 =====")
    数据 = (1, None, "", "ok", [])
    print("结果:", 取非空成员数量(数据))

    print("\n===== 示例2：0 和 False 不算空值 =====")
    数据 = (0, False, None, "")
    print("结果:", 取非空成员数量(数据))

    print("\n===== 示例3：全部为空 =====")
    数据 = (None, "", (), [], {}, set())
    print("结果:", 取非空成员数量(数据))

    print("\n===== 示例4：空元组 =====")
    数据 = ()
    print("结果:", 取非空成员数量(数据))

    print("\n===== 示例5：数据不是元组 =====")
    数据 = [1, 2, 3]
    print("结果:", 取非空成员数量(数据))

    print("\n===== 示例6：应用场景-统计已填写字段数量 =====")
    表单数据 = ("张三", "13800000001", "", None, "北京")
    print("结果:", 取非空成员数量(表单数据))



