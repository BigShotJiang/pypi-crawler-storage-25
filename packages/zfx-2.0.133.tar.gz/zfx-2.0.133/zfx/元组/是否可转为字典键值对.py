﻿from typing import Any, Tuple


def 是否可转为字典键值对(元组数据: Tuple[Any, ...]) -> bool:
    """判断元组是否可安全转换为字典。

    功能说明:
        - 这个函数用于判断元组是否可安全转换为字典。
        - 常用于先判断元组数据是否满足某个条件，再决定后续要不要继续处理。
        - 返回结果一般是 ``True`` 或 ``False``，适合直接写在 ``if`` 判断里使用。

    Args:
        元组数据: 待验证的元组，要求其成员均为长度为 2 的元组。

    Returns:
        可转换时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return False
        for 项 in 元组数据:
            if not isinstance(项, tuple) or len(项) != 2:
                return False
        return True
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：合法键值对结构 =====")
    数据 = (("a", 1), ("b", 2))
    print("结果:", 是否可转为字典键值对(数据))

    print("\n===== 示例2：存在非法长度子项 =====")
    数据 = (("a", 1), ("b", 2, 3))
    print("结果:", 是否可转为字典键值对(数据))

    print("\n===== 示例3：数据不是元组 =====")
    数据 = [("a", 1), ("b", 2)]
    print("结果:", 是否可转为字典键值对(数据))

    print("\n===== 示例4：空元组也可转换 =====")
    数据 = ()
    print("结果:", 是否可转为字典键值对(数据))

    print("\n===== 示例5：内层不是元组 =====")
    数据 = (["a", 1], ("b", 2))
    print("结果:", 是否可转为字典键值对(数据))

    print("\n===== 示例6：应用场景-预检查配置项是否可直接转字典 =====")
    配置项 = (("host", "127.0.0.1"), ("port", 3306), ("debug", True))
    print("结果:", 是否可转为字典键值对(配置项))



