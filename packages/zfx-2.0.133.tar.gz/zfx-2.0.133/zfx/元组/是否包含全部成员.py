﻿from typing import Any, Iterable, Tuple


def 是否包含全部成员(元组数据: Tuple[Any, ...], 候选成员组: Iterable[Any]) -> bool:
    """判断元组是否包含候选成员中的全部成员。

    功能说明:
        - 这个函数用于判断元组是否包含候选成员中的全部成员。
        - 常用于先判断元组数据是否满足某个条件，再决定后续要不要继续处理。
        - 返回结果一般是 ``True`` 或 ``False``，适合直接写在 ``if`` 判断里使用。

    Args:
        元组数据: 待检查的元组。
        候选成员组: 候选成员序列。

    Returns:
        全部命中时返回 ``True``，否则返回 ``False``。
    """
    try:
        if not isinstance(元组数据, tuple):
            return False

        候选列表 = tuple(候选成员组)
        if not 候选列表:
            return False
        return all(成员 in 元组数据 for 成员 in 候选列表)
    except Exception:
        return False


if __name__ == "__main__":
    print("===== 示例1：全部命中 =====")
    数据 = ("a", "b", "c")
    print("结果:", 是否包含全部成员(数据, ("a", "c")))

    print("\n===== 示例2：部分命中 =====")
    数据 = (1, 2, 3)
    print("结果:", 是否包含全部成员(数据, (2, 9)))

    print("\n===== 示例3：候选成员为空 =====")
    数据 = ("a", "b")
    print("结果:", 是否包含全部成员(数据, ()))

    print("\n===== 示例4：候选成员有重复 =====")
    数据 = ("a", "b", "c")
    print("结果:", 是否包含全部成员(数据, ("a", "a", "b")))

    print("\n===== 示例5：复杂对象比较 =====")
    数据 = ([1], {"x": 1}, ("a",))
    print("结果:", 是否包含全部成员(数据, ([1], {"x": 1})))

    print("\n===== 示例6：应用场景-检查必备字段是否齐全 =====")
    返回字段 = ("id", "name", "email", "mobile", "status")
    必备字段 = ("id", "name", "status")
    print("结果:", 是否包含全部成员(返回字段, 必备字段))



