﻿from numbers import Number
from typing import Any, Tuple


def 取数字成员数量(元组数据: Tuple[Any, ...]):
    """返回元组中数字成员的数量。

    功能说明:
        - 这个函数用于返回元组中数字成员的数量。
        - 常用于从元组中读取某个成员、某一段数据，或者计算出一个统计结果。
        - 如果当前数据不适合处理，函数会返回约定好的结果，方便新手直接判断这次是否成功取到值。
"""
    try:
        if not isinstance(元组数据, tuple):
            return None
        return sum(1 for 元素 in 元组数据 if isinstance(元素, Number))
    except Exception:
        return None


if __name__ == "__main__":
    print("===== 示例1：基础数字统计 =====")
    数据 = (1, 2.5, "3", None)
    print("结果:", 取数字成员数量(数据))

    print("\n===== 示例2：布尔值也属于数字 =====")
    数据 = (True, False, 1, 2)
    print("结果:", 取数字成员数量(数据))

    print("\n===== 示例3：复数也属于数字 =====")
    数据 = (1 + 2j, 3, "x")
    print("结果:", 取数字成员数量(数据))

    print("\n===== 示例4：没有数字 =====")
    数据 = ("a", None, {})
    print("结果:", 取数字成员数量(数据))

    print("\n===== 示例5：空元组 =====")
    数据 = ()
    print("结果:", 取数字成员数量(数据))

    print("\n===== 示例6：应用场景-统计金额列中的数值个数 =====")
    金额列 = (1200.5, 980, "", None, 300)
    print("结果:", 取数字成员数量(金额列))



