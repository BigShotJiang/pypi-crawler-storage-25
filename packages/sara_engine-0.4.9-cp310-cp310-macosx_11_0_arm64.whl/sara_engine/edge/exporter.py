# ディレクトリパス: src/sara_engine/edge/exporter.py
# ファイルの日本語タイトル: エッジ用モデルエクスポーター
# ファイルの目的や内容: 学習済みのSARAモデルからシナプス重みだけを抽出し、エッジデバイスで読み込める軽量なフォーマットにシリアライズする。
import json
from typing import Any, Dict, Mapping, Optional


def _extract_weight(value: Any) -> float:
    if isinstance(value, tuple) and value:
        return float(value[0])
    if isinstance(value, list) and value:
        return float(value[0])
    return float(value)


def _normalize_readout_row(row: Mapping[Any, Any]) -> Dict[int, float]:
    normalized: Dict[int, float] = {}
    for post_id, raw_weight in row.items():
        normalized[int(post_id)] = _extract_weight(raw_weight)
    return normalized


def _quantize_row(row: Dict[int, float], quantization_bits: int) -> Dict[int, float]:
    if not row:
        return {}
    if quantization_bits < 2:
        return dict(row)

    levels = max(2, 2 ** int(quantization_bits))
    values = list(row.values())
    min_val = min(values)
    max_val = max(values)
    if max_val <= min_val:
        return dict(row)

    quantized: Dict[int, float] = {}
    scale = (levels - 1) / (max_val - min_val)
    for post_id, weight in row.items():
        q_value = int(round((weight - min_val) * scale))
        q_value = max(0, min(levels - 1, q_value))
        quantized[post_id] = min_val + (q_value / (levels - 1)) * (max_val - min_val)
    return quantized


def export_for_edge(
    model: Any,
    filepath: str,
    quantization_bits: Optional[int] = None,
) -> None:
    """
    Extracts essential inference parameters (e.g., readout synapses, context length)
    from a SpikingTransformerModel and saves it as a lightweight JSON for Sara-Edge.
    """
    # mypy対応: 辞書の型を明示
    edge_data: Dict[str, Any] = {
        "context_length": getattr(model, "context_length", 64),
        "embed_dim": getattr(model.config, "embed_dim", 64) if hasattr(model, "config") else 64,
        "total_readout_size": getattr(model, "total_readout_size", 8192 + 64),
        "readout_synapses": [],
        "edge_quantization": {
            "enabled": bool(quantization_bits is not None),
            "bits": int(quantization_bits or 0),
        },
    }
    
    # Convert readout_synapses to JSON-serializable rows of scalar weights.
    if hasattr(model, "readout_synapses"):
        for synapses in model.readout_synapses:
            if not isinstance(synapses, Mapping):
                edge_data["readout_synapses"].append({})
                continue
            normalized = _normalize_readout_row(synapses)
            if quantization_bits is not None:
                normalized = _quantize_row(normalized, quantization_bits)
            edge_data["readout_synapses"].append(normalized)
            
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(edge_data, f)
    
    print(f"Model successfully exported for Sara-Edge at: {filepath}")
