```sh
open-case -y 2025 1
```