import argparse
import os
import subprocess
import getpass
import string
import platform
from datetime import datetime

IS_WINDOWS = platform.system() == "Windows"
IS_MAC = platform.system() == "Darwin"

# ==============================
# Utility Functions
# ==============================


def format_thai_year(year: int) -> str:
    return str(year + 543)


def open_folder(path: str):
    print(f"Opening: {path}")
    try:
        if IS_WINDOWS:
            subprocess.run(["explorer", path])
        elif IS_MAC:
            subprocess.run(["open", path])
        else:
            subprocess.run(["xdg-open", path])
    except Exception as e:
        print(f"Error opening folder: {e}")


def ensure_and_open(path: str):
    if os.path.exists(path):
        open_folder(path)
        return True

    print(f"Folder not found: {path}")
    if input("Create it? (y/n): ").strip().lower() == "y":
        try:
            os.makedirs(path, exist_ok=True)
            open_folder(path)
            return True
        except Exception as e:
            print(f"Error creating folder: {e}")
    return False


def try_open_paths(paths: list[str]):
    existing = [p for p in paths if os.path.exists(p)]

    if len(existing) == 1:
        open_folder(existing[0])
        return

    if len(existing) > 1:
        print("Multiple folders found:")
        for i, p in enumerate(existing, 1):
            print(f"{i}. {p}")
        try:
            sel = int(input("Select: "))
            open_folder(existing[sel - 1])
            return
        except (ValueError, IndexError):
            print("Invalid selection.")
            return

    ensure_and_open(paths[0])

# ==============================
# Path Builders (OS-aware)
# ==============================


def build_onedrive_path(year: int, case: str, user: str, prefix: str):
    folder_name = f"{prefix}-{year}-{case}"
    if IS_WINDOWS:
        return rf"C:\Users\{user}\OneDrive\Documents\Forensic Reports\{year}\{folder_name}"
    elif IS_MAC:
        return f"/Users/{user}/Library/CloudStorage/OneDrive-Personal/Documents/Forensic Reports/{year}/{folder_name}"


def build_nas10_path(year: int, case: str, prefix: str):
    folder_name = f"{prefix}-{year}-{case}"
    if IS_WINDOWS:
        return rf"\\192.168.9.10\Case Archive\Case-Forensic\{year}\{folder_name}"
    elif IS_MAC:
        return f"/Volumes/Case Archive/Case-Forensic/{year}/{folder_name}"


def build_nas130_paths(year: int, case: str, prefix: str):
    thai_year = format_thai_year(year)
    folder_name = f"{prefix}-{year}-{case}"
    # รองรับ format แบบสั้น เช่น F001 หรือ C001 ด้วย
    short_folder = f"{prefix}{case}"

    if IS_WINDOWS:
        base = rf"\\192.168.9.130\dfu\System DFU Evidence\Case-{thai_year[2:]}"
    elif IS_MAC:
        base = f"/Volumes/dfu/System DFU Evidence/Case-{thai_year[2:]}"

    return [os.path.join(base, folder_name), os.path.join(base, short_folder)]

# ==============================
# External Drive Scanner
# ==============================


def get_external_roots():
    if IS_WINDOWS:
        roots = []
        for drive in string.ascii_uppercase:
            path = f"{drive}:\\"
            if os.path.exists(path) and drive.lower() != "c":
                roots.append(path)
        return roots
    elif IS_MAC:
        base = "/Volumes"
        if not os.path.exists(base):
            return []
        return [os.path.join(base, d) for d in os.listdir(base) if os.path.isdir(os.path.join(base, d))]
    return []


def find_case_in_drives(target_name: str):
    found = []
    roots = get_external_roots()
    print(f"Searching for '{target_name}' in external drives...")

    for root in roots:
        try:
            for current, dirs, _ in os.walk(root):
                if target_name in dirs:
                    found.append(os.path.join(current, target_name))
                    break  # หยุดหาใน root นี้ถ้าเจอแล้ว
        except PermissionError:
            continue
    return found

# ==============================
# Main
# ==============================


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("case", nargs="?", type=int, default=1)
    parser.add_argument("-y", "--year", type=int, default=datetime.now().year)
    parser.add_argument("-t", "--type", type=str,
                        default="F", help="Case type (F or C)")
    args = parser.parse_args()

    # จัดการ Case Type ให้เป็นตัวใหญ่
    case_type = args.type.upper()
    year = args.year
    case_no = str(args.case).zfill(3)
    user = getpass.getuser()

    # ชื่อโฟลเดอร์หลักที่ใช้ค้นหา
    target_folder_name = f"{case_type}-{year}-{case_no}"

    options = {
        "1": lambda: ensure_and_open(build_onedrive_path(year, case_no, user, case_type)),
        "2": lambda: ensure_and_open(build_nas10_path(year, case_no, case_type)),
        "3": lambda: try_open_paths(build_nas130_paths(year, case_no, case_type)),
        "4": lambda: try_open_paths(find_case_in_drives(target_folder_name)),
    }

    print(f"--- Case Mode: {case_type} | Target: {target_folder_name} ---")
    print("1. OneDrive")
    print("2. NAS 192.168.9.10")
    print("3. NAS 192.168.9.130")
    print("4. External Drive Scan")

    choice = input("Choose location: ").strip()
    action = options.get(choice)

    if action:
        action()
    else:
        print("Invalid choice.")


if __name__ == "__main__":
    main()
