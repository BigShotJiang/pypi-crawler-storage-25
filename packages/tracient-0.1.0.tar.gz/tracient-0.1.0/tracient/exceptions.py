class TracientError(Exception):
    """Base Tracient exception."""

class AuthenticationError(TracientError):
    """Invalid or missing API key."""

class APIError(TracientError):
    """Unexpected API response."""
    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code
