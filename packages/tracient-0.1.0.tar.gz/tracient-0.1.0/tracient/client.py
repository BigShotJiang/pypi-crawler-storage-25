"""
Tracient SDK Client
Wrap your AI calls to log compliance events automatically.
"""
import hashlib
import functools
import inspect
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional, TypeVar

import httpx

from .exceptions import AuthenticationError, APIError, TracientError

F = TypeVar("F", bound=Callable[..., Any])

DEFAULT_BASE_URL = "https://tracient-api.up.railway.app"


class TracientClient:
    """
    Tracient compliance client.

    Usage:
        import tracient
        client = tracient.Client(api_key="tk_live_...")

        # Option 1: manual logging
        client.log_decision(
            action="credit_assessment",
            context="credit_scoring",
            model="gpt-4o",
            input_data=applicant_dict,
            outcome="approved",
        )

        # Option 2: decorator (auto-logs the call)
        @client.monitor(context="credit_scoring", action="credit_assessment", model="gpt-4o")
        def assess_credit(applicant):
            return openai.chat.completions.create(...)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        environment: str = "production",
        timeout: float = 10.0,
        raise_on_error: bool = False,
    ):
        if not api_key or not api_key.startswith("tk_"):
            raise AuthenticationError("API key must start with 'tk_live_' or 'tk_test_'.")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.environment = environment
        self.raise_on_error = raise_on_error
        self._http = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            timeout=timeout,
        )

    # ── Core logging ──────────────────────────────────────────────────────────

    def log_decision(
        self,
        action: str,
        context: str = "general",
        model: Optional[str] = None,
        input_data: Optional[Dict[str, Any]] = None,
        input_summary: Optional[str] = None,
        output_summary: Optional[str] = None,
        outcome: Optional[str] = None,
        occurred_at: Optional[str] = None,
        client_event_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Log an AI decision event to Tracient.

        Returns a dict with event_id, risk_level, regulations_mapped, and flags.
        On network error, returns {"error": "..."} unless raise_on_error=True.
        """
        payload: Dict[str, Any] = {
            "action": action,
            "context": context,
            "environment": self.environment,
            "sdk_version": "0.1.0",
        }

        if model:
            payload["model"] = model
        if input_summary:
            payload["input_summary"] = input_summary
        if output_summary:
            payload["output_summary"] = output_summary
        if outcome:
            payload["outcome"] = outcome
        if occurred_at:
            payload["occurred_at"] = occurred_at
        if client_event_id:
            payload["client_event_id"] = client_event_id
        if metadata:
            payload["metadata"] = metadata

        # Hash input_data if provided (never send raw PII)
        if input_data:
            raw = str(sorted(str(input_data).encode())).encode()
            payload["input_data"] = {"__hash_only": hashlib.sha256(raw).hexdigest()}

        try:
            resp = self._http.post("/v1/events", json=payload)
            if resp.status_code == 401:
                raise AuthenticationError("Invalid API key.")
            if resp.status_code >= 400:
                if self.raise_on_error:
                    raise APIError(resp.text, resp.status_code)
                return {"error": resp.text, "status_code": resp.status_code}
            return resp.json()
        except (AuthenticationError, APIError):
            raise
        except Exception as e:
            if self.raise_on_error:
                raise TracientError(str(e)) from e
            return {"error": str(e)}

    # ── Decorator ─────────────────────────────────────────────────────────────

    def monitor(
        self,
        context: str = "general",
        action: Optional[str] = None,
        model: Optional[str] = None,
        extract_outcome: Optional[Callable[[Any], str]] = None,
    ):
        """
        Decorator that automatically logs a function call as an AI decision event.

        @client.monitor(context="credit_scoring", action="credit_assessment", model="gpt-4o")
        def assess_credit(applicant_data):
            return llm_call(applicant_data)
        """
        def decorator(func: F) -> F:
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                started_at = datetime.now(timezone.utc).isoformat()
                result = None
                outcome = None

                try:
                    result = func(*args, **kwargs)
                    if extract_outcome and result is not None:
                        try:
                            outcome = extract_outcome(result)
                        except Exception:
                            pass
                    return result
                finally:
                    # Always log, even if the function raised
                    fn_action = action or func.__name__
                    self.log_decision(
                        action=fn_action,
                        context=context,
                        model=model,
                        outcome=outcome,
                        occurred_at=started_at,
                        metadata={"function": func.__name__, "module": func.__module__},
                    )
            return wrapper  # type: ignore
        return decorator

    # ── Evidence packs ────────────────────────────────────────────────────────

    def generate_evidence_pack(
        self,
        output_path: Optional[str] = None,
        period_start: Optional[str] = None,
        period_end: Optional[str] = None,
        context_filter: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Generate a regulator-ready evidence pack.
        If output_path is provided, saves the HTML to that file.
        Returns pack metadata including pack_id and download_url.
        """
        payload: Dict[str, Any] = {}
        if period_start:
            payload["period_start"] = period_start
        if period_end:
            payload["period_end"] = period_end
        if context_filter:
            payload["context_filter"] = context_filter

        try:
            resp = self._http.post("/v1/evidence-packs", json=payload)
            if resp.status_code >= 400:
                if self.raise_on_error:
                    raise APIError(resp.text, resp.status_code)
                return {"error": resp.text}
            pack = resp.json()

            # Download HTML if output_path specified
            if output_path and pack.get("pack_id"):
                dl_resp = self._http.get(f"/v1/evidence-packs/{pack['pack_id']}/download")
                if dl_resp.status_code == 200:
                    with open(output_path, "w", encoding="utf-8") as f:
                        f.write(dl_resp.text)
                    pack["saved_to"] = output_path

            return pack
        except (AuthenticationError, APIError):
            raise
        except Exception as e:
            if self.raise_on_error:
                raise TracientError(str(e)) from e
            return {"error": str(e)}

    # ── Convenience ───────────────────────────────────────────────────────────

    def get_summary(self) -> Dict[str, Any]:
        """Get compliance summary for your organisation."""
        try:
            resp = self._http.get("/v1/summary")
            return resp.json()
        except Exception as e:
            return {"error": str(e)}

    def list_events(self, limit: int = 50, context: Optional[str] = None) -> Dict[str, Any]:
        """List recent AI decision events."""
        params: Dict[str, Any] = {"limit": limit}
        if context:
            params["context"] = context
        try:
            resp = self._http.get("/v1/events", params=params)
            return resp.json()
        except Exception as e:
            return {"error": str(e)}

    def ping(self) -> bool:
        """Check API connectivity. Returns True if reachable."""
        try:
            resp = self._http.get("/health")
            return resp.status_code == 200
        except Exception:
            return False

    def __repr__(self) -> str:
        prefix = self.api_key[:12] + "..." if len(self.api_key) > 12 else self.api_key
        return f"TracientClient(key={prefix}, env={self.environment})"
