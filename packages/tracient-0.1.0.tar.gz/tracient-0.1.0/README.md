# Tracient

**AI compliance layer for regulated fintechs — DORA, EU AI Act, NIS2.**

Tracient wraps your AI agent calls and automatically logs every decision with full regulatory mapping. When a regulator asks for an audit trail, you generate an evidence pack in seconds.

```python
pip install tracient
```

---

## Why Tracient

Under DORA and the EU AI Act, regulated fintechs must maintain forensic-grade logs of AI agent decisions, map them to specific regulation articles, and produce evidence packs on demand. Doing this manually is expensive and error-prone. Tracient does it automatically with two lines of code.

- **DORA Art.9, 12, 28** — ICT risk management, event logging, third-party register
- **EU AI Act Annex III §5(b), Art.9, 12, 13, 14** — High-risk AI obligations for credit scoring and mortgage assessment
- **NIS2** — Incident reporting and risk management requirements

---

## Quickstart

```python
from tracient import Client

client = Client(api_key="tk_live_...")

# Option 1 — decorator (wraps your function automatically)
@client.monitor(context="credit_scoring", action="assess_application", model="gpt-4o")
def assess_credit(application_data):
    # your AI call here
    return result

# Option 2 — manual log
client.log_decision(
    action="credit_assessment",
    context="credit_scoring",
    model="gpt-4o",
    input_summary="Applicant file — anonymised",
    output_summary="Score: 742, Band: B",
    outcome="approved",
)
```

Every logged event is automatically mapped to the relevant DORA and EU AI Act articles.

---

## Generate an evidence pack

```python
client.generate_evidence_pack(output_path="evidence_pack.html")
```

Downloads a regulator-ready HTML document with executive summary, risk breakdown, obligations table, and full event log.

---

## Contexts and risk mapping

| Context | Risk level | Regulations triggered |
|---|---|---|
| `credit_scoring` | HIGH | EU AI Act Annex III §5(b), DORA Art.9/12/28 |
| `mortgage_assessment` | HIGH | EU AI Act Annex III §5(b), DORA Art.9/12/28 |
| `fraud_detection` | MEDIUM | DORA Art.9/12, NIS2 Art.21 |
| `customer_service` | LOW | DORA Art.9, NIS2 |
| `investment_advice` | MEDIUM | DORA Art.9/12/28 |

---

## API key

Get your API key at [tracient.ai](https://tracient.ai).

---

## Requirements

- Python 3.9+
- `httpx >= 0.27.0`

---

## License

MIT
