from setuptools import setup, find_packages

setup(
    name="tracient",
    version="0.1.0",
    description="AI compliance layer for regulated fintechs — DORA, EU AI Act, NIS2",
    author="Oliver Symons",
    author_email="oliver@mail.tracient.ai",
    url="https://tracient.ai",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.27.0",
    ],
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Financial and Insurance Industry",
        "Topic :: Security",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    long_description=open("README.md").read() if __import__("os").path.exists("README.md") else "",
    long_description_content_type="text/markdown",
)
