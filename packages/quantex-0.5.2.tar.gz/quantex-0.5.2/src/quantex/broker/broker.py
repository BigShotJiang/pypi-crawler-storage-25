from typing import final
import numpy as np

from quantex.broker.types import Order, OrderSide, OrderStatus, OrderType, CommissionType
from ..datasource import DataSource


def same_sign(num1, num2):
    """
    Check if two numbers have the same sign (both positive or both negative).
    
    This utility function is used to determine if two numerical values
    are on the same side of zero, which is important for position
    management and averaging price calculations.
    
    Args:
        num1: First number to compare.
        num2: Second number to compare.
        
    Returns:
        bool: True if both numbers are positive or both are negative,
              False if they have opposite signs or either is zero.
              
    Example:
        >>> same_sign(5, 10)
        True
        >>> same_sign(-3, -7)
        True
        >>> same_sign(2, -5)
        False
        >>> same_sign(0, 5)
        False
    """
    if (num1 > 0 and num2 > 0):
        return True
    elif (num1 < 0 and num2 < 0):
        return True
    return False

class Broker:
    """
    Broker class for managing trading positions and order execution.
    
    This class simulates a brokerage environment, handling position management,
    order processing, commission calculations, and P&L tracking. It provides
    the core trading infrastructure for backtesting strategies.
    
    The broker manages:
    - Current position and average price
    - Cash/balance management (realized P&L + commissions)
    - Order execution (market and limit orders)
    - Commission calculations
    - Stop loss and take profit order management
    - P&L record tracking
    - Leverage for amplified position sizing
    - Margin tracking separate from equity
    
    Accounting Model:
    - balance: Realized account balance after P&L and commissions
    - used_margin = abs(position) * mark_price / leverage
    - unrealized_pnl = position * (mark_price - position_avg_price)
    - equity = balance + unrealized_pnl
    - free_cash = equity - used_margin
    
    Example:
        >>> source = CSVDataSource("data.csv")  
        >>> broker = Broker(source)  
        >>> broker.buy(quantity=0.1)  # Buy 10% of available cash  
        >>> broker.sell(quantity=0.5)  # Sell 50% of available position  
    """
    def __init__(self, source: DataSource):
        """
        Initialize the broker with a data source.
        
        Args:
            source (DataSource): The data source providing market data
                (OHLCV prices and timestamps) for the broker to operate on.
        """
        self.position: np.float64 = np.float64(0)
        self.position_avg_price: np.float64 = np.float64(0)
        self.cash: np.float64 = np.float64(10_000)
        self.commision: np.float64 = np.float64(0.002)
        self.commision_type: CommissionType = CommissionType.PERCENTAGE
        self.lot_size: int = 1
        self.margin_call: float = 0.5  # Margin call threshold (50% of used margin)
        self.leverage: float = 1.0  # Leverage multiplier (1.0 = no leverage)
        self.share_decimals = 1
        self.orders: list[Order] = []
        self.complete_orders = []
        self.active_order: Order | None = None
        self.pending_close_order: Order | None = None
        self.margin_call_triggered: bool = False
        self.margin_call_events: list[dict] = []
        self._i = 0
        self.source = source
        self.PnLRecord = np.full(len(self.source.data['Close']), self.cash, dtype=np.float64)
        self.cashRecord = []

    def _get_equity(self) -> np.float64:
        """
        Calculate current equity based on realized balance and unrealized P&L.
        
        Equity is always: balance + unrealized_pnl
        This is consistent regardless of leverage.
        
        Returns:
            np.float64: Current equity value.
        """
        unrealized_pnl = self._get_unrealized_pnl()
        return self.cash + unrealized_pnl
    
    def _get_unrealized_pnl(self) -> np.float64:
        """
        Calculate unrealized P&L based on current position and entry price.
        
        unrealized_pnl = position * (mark_price - position_avg_price)
        
        Returns:
            np.float64: Unrealized P&L, or 0 if position is zero.
        """
        if self.position == 0:
            return np.float64(0)
        mark_price = self.source.CClose
        return self.position * (mark_price - self.position_avg_price)
    
    def _get_used_margin(self) -> np.float64:
        """
        Calculate margin currently used by open positions.
        
        used_margin = abs(position) * mark_price / leverage
        
        Returns:
            np.float64: Margin used by current position.
        """
        if self.position == 0:
            return np.float64(0)
        mark_price = self.source.CClose
        return abs(self.position) * mark_price / self.leverage
    
    def _get_free_cash(self) -> np.float64:
        """
        Calculate free cash available for new positions.
        
        free_cash = equity - used_margin
        
        Returns:
            np.float64: Free cash available.
        """
        equity = self._get_equity()
        used_margin = self._get_used_margin()
        return equity - used_margin

    def _enqueue_order(self, order: Order) -> None:
        """
        Add an order while keeping the active-order queue compact.

        The broker logic only meaningfully supports a single active protective
        order for the current open position. Replacing stale active orders keeps
        per-bar iteration bounded and prevents pathological queue growth.
        """
        if order.reduce_only:
            if self.pending_close_order is not None:
                try:
                    self.orders.remove(self.pending_close_order)
                except ValueError:
                    pass
            self.pending_close_order = order
            self.orders.append(order)
            return

        if order.status == OrderStatus.PENDING and order.stop_loss is None and order.take_profit is None:
            self.orders.append(order)
            return

        if self.active_order is not None:
            try:
                self.orders.remove(self.active_order)
            except ValueError:
                pass
            self.active_order = None

        self.orders.append(order)

    @final
    def buy(self, quantity: float = 1, limit: np.float64 | None = None, amount: np.float64 | None = None, stop_loss: np.float64 | None = None, take_profit: np.float64 | None = None):
        """
        Place a buy order for a specified quantity.
        
        This method creates a buy order with optional limit price, stop loss,
        and take profit conditions. The quantity can be specified as a
        percentage of available cash or as an absolute amount.
        
        Args:
            quantity (float, optional): Quantity to buy as fraction of available
                cash (0 < quantity <= 1). Defaults to 1 (full cash amount).
                For example: 0.5 = buy with 50% of available cash.
            limit (np.float64 | None, optional): Limit price for the order.
                If None, creates a market order. Defaults to None.
            amount (np.float64 | None, optional): Absolute number of shares
                to buy. If provided, overrides quantity calculation.
                Defaults to None.
            stop_loss (np.float64 | None, optional): Stop loss price.
                If provided, creates a stop loss order that executes when
                price falls to this level. Defaults to None.
            take_profit (np.float64 | None, optional): Take profit price.
                If provided, creates a take profit order that executes when
                price rises to this level. Defaults to None.
                
        Raises:
            ValueError: If quantity is not in (0, 1] range.
            ValueError: If limit price is negative.
            ValueError: If amount is negative.
            ValueError: If attempting to buy more than available cash balance.
            
        Note:
            - If both quantity and amount are provided, amount takes precedence.
            - Orders are added to the broker's order queue and processed
              during the next iteration.
            - Market orders execute immediately at current open price.
            - Limit orders only execute when price reaches the specified level.
            - Leverage amplifies position size - with 2x leverage and quantity=1,
              you control 2x the shares while only using 1x cash as margin.
            - Opening positions deducts only commission from cash; equity remains
              continuous because unrealized P&L is properly tracked.
               
        Example:
            >>> broker = Broker(source)  
            >>> # Buy with 25% of available cash  
            >>> broker.buy(quantity=0.25)  
            >>> # Buy exactly 100 shares at limit price $50  
            >>> broker.buy(amount=100, limit=50.0)  
            >>> # Buy with stop loss and take profit  
            >>> broker.buy(quantity=0.1, stop_loss=45.0, take_profit=55.0)  
        """
        ## Default to full account buy
        if (quantity > 1 or quantity <= 0):
            raise ValueError("Quantity must be between 0 and 1")
        if (limit and limit < 0):
            raise ValueError("Cannot have a negative limit price")
        if (amount and amount < 0):
            raise ValueError("Cannot have a negative amount!")
        if (limit):
            type = OrderType.LIMIT
        else:
            type = OrderType.MARKET
        current_price = self.source.Close[-1]
        if (amount):
            # When using absolute amount, still apply leverage to the base calculation
            # but the user-provided amount is the final leveraged position size
            total_shares = amount
        else:
            # Calculate shares: base on cash * quantity, then apply leverage
            base_shares = round((self.cash * quantity) / current_price, self.share_decimals)
            # Apply leverage to increase position size
            total_shares = round(base_shares * self.leverage, self.share_decimals)
        order = Order(
            side=OrderSide.BUY, 
            quantity=total_shares, 
            type=type,
            price=limit,
            stop_loss=stop_loss,
            take_profit=take_profit,
            status=OrderStatus.PENDING,
            timestamp=self.source.Index[self._i]
            )
        ## Transmit the order
        self._enqueue_order(order)
            

    @final
    def sell(self, quantity: float = 1, limit = None, amount: np.float64 | None = None, stop_loss: np.float64 | None = None, take_profit: np.float64 | None = None):
        """
        Place a sell order for a specified quantity.
        
        This method creates a sell order with optional limit price, stop loss,
        and take profit conditions. The quantity can be specified as a
        percentage of available cash or as an absolute amount.
        
        Args:
            quantity (float, optional): Quantity to sell as fraction of available
                cash (0 < quantity <= 1). Defaults to 1 (full cash amount).
                For example: 0.5 = sell shares worth 50% of available cash.
            limit (optional): Limit price for the order (same as limit parameter
                in buy method). If None, creates a market order. Defaults to None.
            amount (np.float64 | None, optional): Absolute number of shares
                to sell. If provided, overrides quantity calculation.
                Defaults to None.
            stop_loss (np.float64 | None, optional): Stop loss price for
                the position. Defaults to None.
            take_profit (np.float64 | None, optional): Take profit price for
                the position. Defaults to None.
                
        Raises:
            ValueError: If quantity is not in (0, 1] range.
            ValueError: If limit price is negative.
            ValueError: If amount is negative.
            ValueError: If attempting to sell more shares than currently held.
            
        Note:
            - If both quantity and amount are provided, amount takes precedence.
            - Orders are added to the broker's order queue and processed
              during the next iteration.
            - Selling reduces the current position and increases cash balance.
            - Stop loss and take profit apply to remaining position after sale.
            - Realized P&L is credited to cash immediately on close.
            - Leverage amplifies short position size - with 2x leverage and quantity=1,
              you can short 2x the shares while only using 1x cash as margin.
               
        Example:
            >>> broker = Broker(source)  
            >>> broker.buy(quantity=1)  # First buy full position  
            >>> # Sell 50% of position  
            >>> broker.sell(quantity=0.5)  
            >>> # Sell exactly 100 shares at limit price $52  
            >>> broker.sell(amount=100, limit=52.0)  
        """
        ## Default to full account sell
        if (quantity > 1 or quantity <= 0):
            raise ValueError("Quantity must be between 0 and 1")
        if (limit and limit < 0):
            raise ValueError("Cannot have a negative limit price")
        if (amount and amount < 0):
            raise ValueError("Cannot have a negative amount!")
        if (limit):
            type = OrderType.LIMIT
        else:
            type = OrderType.MARKET
        current_price = self.source.Close[-1]
        if (amount):
            # When using absolute amount, still apply leverage to the base calculation
            # but the user-provided amount is the final leveraged position size
            total_shares = amount
        else:
            # Calculate shares: base on cash * quantity, then apply leverage
            base_shares = round((self.cash * quantity) / current_price, self.share_decimals)
            # Apply leverage to increase position size
            total_shares = round(base_shares * self.leverage, self.share_decimals)
        order = Order(
            side=OrderSide.SELL, 
            quantity=total_shares, 
            type=type,
            price=limit,
            stop_loss=stop_loss,
            take_profit=take_profit,
            status=OrderStatus.PENDING,
            timestamp=self.source.Index[self._i]
            )
        ## Transmit the order
        self._enqueue_order(order)
    
    @final
    def close(self):
        """
        Close all current positions with market orders.
        
        This method creates market orders to liquidate the entire current
        position, regardless of whether it's long or short. It's commonly
        used at the end of a backtest or when exiting all positions.
        
        The method creates:
        - A sell order if holding a long position (positive shares)
        - A buy order if holding a short position (negative shares)
        
        Note:
            - This method only creates orders; they are executed during
              the next iteration cycle.
            - No parameters are required as it closes the entire position.
            - Commission and slippage will apply to the closing trades.
            - Existing stop loss and take profit orders remain active
              unless explicitly cancelled.
              
        Example:
            >>> broker = Broker(source)  
            >>> broker.buy(quantity=1)  # Open long position  
            >>> # Later, close all positions  
            >>> broker.close()  
        """
        ## Close active and complete positions
        if (self.position > 0):
            order = Order(
                side=OrderSide.SELL, 
                quantity=self.position, 
                type=OrderType.MARKET,
                price=None,
                stop_loss=None,
                take_profit=None,
                status=OrderStatus.PENDING,
                timestamp=self.source.Index[self._i],
                reduce_only=True,
                )
            self._enqueue_order(order)
        elif (self.position < 0):
            order = Order(
                side=OrderSide.BUY, 
                quantity=-self.position, 
                type=OrderType.MARKET,
                price=None,
                stop_loss=None,
                take_profit=None,
                status=OrderStatus.PENDING,
                timestamp=self.source.Index[self._i],
                reduce_only=True,
                )
            self._enqueue_order(order)
    
    def is_long(self):
        """
        Check if currently holding a long position.
        
        Returns:
            bool: True if position is positive (long), False otherwise.
            
        Example:
            >>> broker.buy(quantity=0.5)  
            >>> broker.is_long()  
            True
        """
        return self.position > 0
    
    def is_short(self):
        """
        Check if currently holding a short position.
        
        Returns:
            bool: True if position is negative (short), False otherwise.
            
        Example:
            >>> broker.sell(quantity=0.5)  
            >>> broker.is_short()  
            True
        """
        return self.position < 0
    
    def is_closed(self):
        """
        Check if currently not holding any position.
        
        Returns:
            bool: True if position is zero (no open position), False otherwise.
            
        Example:
            >>> broker.close()  
            >>> broker.is_closed()  
            True
        """
        return self.position == 0

    def _debit(self, amount: np.float64): 
        """
        Deduct amount from cash balance (internal method).
        
        This is an internal method used to reduce the cash balance when
        paying commissions or fees. It does NOT deduct position notional
        value, as equity is tracked separately via unrealized P&L.
        
        Args:
            amount (np.float64): Amount to deduct from cash balance.
            
        Raises:
            ValueError: If attempting to deduct more than available equity
                (accounting for used margin).
        """
        available = self._get_free_cash()
        if (available - amount < 0):
            raise ValueError("Insufficient equity for this operation")
        self.cash -= amount

    def _credit(self, amount: np.float64): 
        """
        Add amount to cash balance (internal method).
        
        This is an internal method used to increase the cash balance when
        realizing P&L from closing positions or receiving funds.
        
        Args:
            amount (np.float64): Amount to add to cash balance.
        """
        self.cash += amount
    

    def _calc_commission(self, quantity: np.float64, price: np.float64):
        """
        Calculate commission for a trade (internal method).
        
        This method computes the commission based on the configured
        commission type and rate.
        
        Args:
            quantity (np.float64): Number of shares/contracts traded.
            price (np.float64): Execution price per share/contract.
            
        Returns:
            np.float64: Commission amount to be charged.
            
        Note:
            - This is an internal method used by _apply_commission.
            - Commission type can be PERCENTAGE (percentage of trade value)
              or CASH (fixed amount per lot).
        """
        if self.commision_type == CommissionType.CASH:
            debit = quantity * self.commision / self.lot_size
        else:
            debit = quantity * price * self.commision
        return debit

    def _apply_commission(self, quantity: np.float64, price: np.float64):
        """
        Apply commission to the trade (internal method).
        
        This method calculates and deducts commission from the cash balance.
        
        Args:
            quantity (np.float64): Number of shares/contracts traded.
            price (np.float64): Execution price per share/contract.
        """
        debit = self._calc_commission(quantity, price)
        self._debit(debit)

    def _execute_opening_order(self, side: OrderSide, quantity: np.float64, price: np.float64):
        """
        Execute an order that opens or increases a position.
        
        This handles the accounting for opening positions:
        - Updates position size and average price
        - Deducts only commission from balance (not notional exposure)
        - Equity remains continuous because unrealized P&L is properly tracked
        
        Args:
            side: BUY or SELL side
            quantity: Number of shares/contracts
            price: Execution price
        """
        old_pos = self.position
        if side == OrderSide.BUY:
            new_pos = old_pos + quantity
        else:
            new_pos = old_pos - quantity
        
        # Update average price using weighted average
        if old_pos == 0:
            # No existing position - new avg price is fill price
            self.position_avg_price = price
        elif same_sign(old_pos, new_pos):
            if abs(new_pos) > abs(old_pos):
                # Increasing exposure - update weighted average
                self.position_avg_price = (
                    old_pos * self.position_avg_price + quantity * price
                ) / new_pos
            # If reducing exposure, keep avg price unchanged
        else:
            # Crossing through zero - remainder becomes new position with fill price
            self.position_avg_price = price
        
        # Only deduct commission from balance (NOT margin/notional)
        # Equity remains continuous because unrealized P&L calculation
        # accounts for the new position at current market price
        self._apply_commission(quantity, price)
        
        self.position = new_pos
        
        # Reset avg price if position is closed
        if self.position == 0:
            self.position_avg_price = np.float64(0)

    def _execute_closing_order(self, side: OrderSide, quantity: np.float64, price: np.float64):
        """
        Execute an order that closes or reduces a position.
        
        This handles the accounting for closing positions:
        - Realizes P&L into balance
        - Updates position size
        - Keeps remaining avg price unchanged if partially reduced
        
        Args:
            side: BUY or SELL side
            quantity: Number of shares/contracts to close
            price: Execution price
        """
        old_pos = self.position
        if side == OrderSide.BUY:
            new_pos = old_pos + quantity  # Buying to close short
        else:
            new_pos = old_pos - quantity  # Selling to close long
        
        # Calculate realized P&L for the closed portion
        # P&L = closed_quantity * (exit_price - entry_price)
        # For long: exit_price - entry_price
        # For short: entry_price - exit_price (we bought at lower to cover, profit)
        closed_quantity = abs(old_pos - new_pos)
        if old_pos > 0:  # Closing long position
            realized_pnl = closed_quantity * (price - self.position_avg_price)
        elif old_pos < 0:  # Closing short position
            realized_pnl = closed_quantity * (self.position_avg_price - price)
        else:
            realized_pnl = np.float64(0)
        
        # Credit realized P&L and commission to balance
        self._credit(realized_pnl)
        self._apply_commission(quantity, price)
        
        self.position = new_pos
        
        # Reset avg price if position is fully closed
        if self.position == 0:
            self.position_avg_price = np.float64(0)
        # If partially closed but still same direction, keep avg price unchanged

    def _iterate(self, current_index: int):
        """
        Process orders and update broker state for current time step (internal method).
        
        This is the core method that handles order execution, position updates,
        P&L calculations, and margin call checks. It's called for each time step
        in the backtest loop.
        
        The method performs:
        1. Order processing and execution (market and limit orders)
        2. Position and average price updates
        3. Stop loss and take profit order management
        4. P&L and equity calculations
        5. Margin call checks and enforcement
        6. P&L record updates
        
        Args:
            current_index (int): Current time step index in the data source.
            
        Note:
            This is an internal method called automatically by the backtester
            and should not be called directly by strategy code.
        """
        self._i = current_index
        to_delete = []
        ## Do one loop to see if you can execute any orders
        for order in self.orders:
            if self.position == 0:
                self.cashRecord.append(self.cash)
            ## Check for new orders
            match order.status:
                case OrderStatus.PENDING:
                    if (order.type == OrderType.LIMIT):
                        if (order.side == OrderSide.BUY):
                            if (not order.price == None and self.source.COpen <= order.price):
                                ## We can buy it
                                self._execute_order(order.side, order.quantity, order.price)
                                if (order.stop_loss or order.take_profit):
                                    order.status = OrderStatus.ACTIVE ## Will need to be checked on for each update
                                    self.active_order = order
                                else:
                                    order.status = OrderStatus.COMPLETE ## We are done with it
                                    to_delete.append(order)
                        else:
                            if (not order.price == None and self.source.COpen >= order.price):
                                ## We can sell it
                                self._execute_order(order.side, order.quantity, order.price)
                                if (order.stop_loss or order.take_profit):
                                    order.status = OrderStatus.ACTIVE ## Will need to be checked on for each update
                                    self.active_order = order
                                else:
                                    order.status = OrderStatus.COMPLETE ## We are done with it
                                    to_delete.append(order)
                    else:
                        try:
                            price = self.source.COpen
                            self._execute_order(order.side, order.quantity, price)
                            if (order.stop_loss or order.take_profit):
                                order.status = OrderStatus.ACTIVE
                                self.active_order = order
                            else:
                                order.status = OrderStatus.COMPLETE
                                self.complete_orders.append(order)
                                to_delete.append(order)
                        except:
                            pass
                case OrderStatus.ACTIVE:
                    if (
                        order.side == OrderSide.BUY 
                        and (
                            (order.take_profit and self.source.COpen >= order.take_profit)
                            or (order.stop_loss and self.source.COpen <= order.stop_loss)
                            )):
                        close_order = Order(
                            side=OrderSide.SELL, 
                            quantity=order.quantity, 
                            type=OrderType.MARKET, 
                            price= None, 
                            stop_loss= None, 
                            take_profit= None, 
                            status=OrderStatus.PENDING,
                            timestamp=self.source.Index[self._i],
                            reduce_only=True,
                            )
                        self._enqueue_order(close_order)
                        order.status = OrderStatus.COMPLETE
                        if self.active_order is order:
                            self.active_order = None
                        self.complete_orders.append(order)
                        to_delete.append(order)
                    elif(order.side == OrderSide.SELL
                         and (
                             (order.take_profit and self.source.COpen <= order.take_profit) 
                             or (order.stop_loss and self.source.COpen >= order.stop_loss)
                             )):
                        close_order = Order(
                            side=OrderSide.BUY,
                            quantity=order.quantity,
                            type=OrderType.MARKET,
                            price=None,
                            stop_loss=None,
                            take_profit=None,
                            status=OrderStatus.PENDING,
                            timestamp=self.source.Index[self._i],
                            reduce_only=True,
                        )
                        self._enqueue_order(close_order)
                        order.status = OrderStatus.COMPLETE
                        if self.active_order is order:
                            self.active_order = None
                        self.complete_orders.append(order)
                        to_delete.append(order)
        for item in to_delete:
            self.orders.remove(item)
            if self.pending_close_order is item:
                self.pending_close_order = None
        
        # Calculate equity: balance + unrealized P&L
        # This is always correct regardless of leverage
        equity = self._get_equity()
        
        # Clamp equity to 0 minimum to prevent negative equity
        equity = max(np.float64(0), equity)
        self.PnLRecord[self._i] = equity
        
        # Check margin call using equity and used margin
        # Margin call triggers when equity falls below margin_call threshold of used margin
        used_margin = self._get_used_margin()
        margin_call_threshold = self.margin_call * used_margin
        
        # Only trigger margin call if there's an open position and equity is below threshold
        if used_margin > 0 and equity < margin_call_threshold:
            self.margin_call_triggered = True
            self.margin_call_events.append({
                "timestamp": self.source.Index[self._i],
                "equity": equity,
                "used_margin": used_margin,
                "margin_call_threshold": margin_call_threshold,
                "position": self.position,
            })
            self.close()  # Close all positions immediately, margin call

    def _execute_order(self, side: OrderSide, quantity: np.float64, price: np.float64):
        """
        Execute an order, routing to opening or closing logic.
        
        Args:
            side: BUY or SELL side
            quantity: Number of shares/contracts
            price: Execution price
        """
        # Determine if this is opening or closing based on position direction
        old_pos = self.position
        
        if old_pos == 0:
            # No position - any order opens a new position
            self._execute_opening_order(side, quantity, price)
        elif side == OrderSide.BUY:
            if old_pos > 0:
                # Currently long - buying adds to position
                self._execute_opening_order(side, quantity, price)
            else:
                # Currently short - buying closes/reduces position
                close_qty = min(quantity, abs(old_pos))
                if close_qty > 0:
                    self._execute_closing_order(side, close_qty, price)
                if quantity > close_qty:
                    # Remainder opens new long position
                    self._execute_opening_order(side, quantity - close_qty, price)
        else:  # side == OrderSide.SELL
            if old_pos < 0:
                # Currently short - selling adds to position
                self._execute_opening_order(side, quantity, price)
            else:
                # Currently long - selling closes/reduces position
                close_qty = min(quantity, abs(old_pos))
                if close_qty > 0:
                    self._execute_closing_order(side, close_qty, price)
                if quantity > close_qty:
                    # Remainder opens new short position
                    self._execute_opening_order(side, quantity - close_qty, price)
