"""
setup.py — Compile qtsq C code into a Python extension module.

After: pip install .
Anyone: import qtsq
"""

import os
import platform
from setuptools import setup, Extension

SRC_DIR = 'src'
INCLUDE_DIR = 'include'

# Collect C source files (skip .mm — replaced by stubs)
c_sources = [os.path.join(SRC_DIR, f)
             for f in sorted(os.listdir(SRC_DIR))
             if f.endswith('.c')]

# Add Python C extension wrapper + Metal stubs
c_sources.append('qtsq/_native.c')
c_sources.append('qtsq/_metal_stubs.c')

# Compiler flags
compile_args = ['-O2', '-std=c11',
                '-Wno-unused-parameter', '-Wno-sign-compare',
                '-Wno-missing-braces', '-Wno-unused-function',
                '-Wno-misleading-indentation']
link_args = []
libs = ['z']

if platform.system() == 'Darwin':
    link_args += ['-framework', 'Metal', '-framework', 'Foundation']
elif platform.system() == 'Linux':
    compile_args += ['-D_GNU_SOURCE']  # enables CLOCK_MONOTONIC, strnlen, etc.
    libs += ['m', 'pthread']

ext = Extension(
    'qtsq._native',
    sources=c_sources,
    include_dirs=[INCLUDE_DIR],
    libraries=libs,
    extra_compile_args=compile_args,
    extra_link_args=link_args,
)

# All metadata (name, version, deps, classifiers) lives in pyproject.toml.
# setup.py only defines the C extension which pyproject.toml can't do.
setup(ext_modules=[ext])
