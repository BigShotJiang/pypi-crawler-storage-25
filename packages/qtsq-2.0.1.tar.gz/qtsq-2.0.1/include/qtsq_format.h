/*
 * Quantum Tensor Sequence — File Format Structures & Constants
 * File Extension: .qtsq (Quantum Tensor Sequence)
 * 
 * Author: Haruhito
 * License: MIT
 */

#ifndef QTSQ_FORMAT_H
#define QTSQ_FORMAT_H

#include <stdint.h>
#include <stddef.h>
/* Magic bytes: "QTS\x01" */
#define QTSQ_MAGIC_0 'Q'
#define QTSQ_MAGIC_1 'T'
#define QTSQ_MAGIC_2 'S'
#define QTSQ_MAGIC_3 '\x01'
#define QTSQ_VERSION_1  1
#define QTSQ_VERSION_2  2
#define QTSQ_VERSION    2     /* current version */

/* gravitational wave diff (.qtsw): "QTW\x01" */
#define QTW_MAGIC_0 'Q'
#define QTW_MAGIC_1 'T'
#define QTW_MAGIC_2 'W'
#define QTW_MAGIC_3 '\x01'

/* Chandrasekhara limit*/
#define QTSQ_CHANDRASEKHAR_LIMIT 4096

/* Compression Strategy*/
typedef enum {
    QTSQ_STRATEGY_NONE        = 0x00,
    QTSQ_STRATEGY_PROCEDURAL  = 0x01,
    QTSQ_STRATEGY_FRACTAL     = 0x02,
    QTSQ_STRATEGY_FOURIER     = 0x03,
    QTSQ_STRATEGY_DELTA_SEED  = 0x04,
    QTSQ_STRATEGY_DICTIONARY  = 0x05,
    QTSQ_STRATEGY_TEMPORAL    = 0x06,
    QTSQ_STRATEGY_TRIANGLE    = 0x07,
    QTSQ_STRATEGY_PHOTON      = 0x08,  /* HQ Gabor atom audio (Photon Audio) */
    QTSQ_STRATEGY_SPLAT       = 0x09,  /* Pure 2D Gaussian Splat image (no triangles) */
    QTSQ_STRATEGY_TENSOR      = 0x0A,  /* Float delta-quantize-zlib for neural tensors */
    QTSQ_STRATEGY_LAYERED     = 0xFF,
} qtsq_strategy_t;

/* data type*/
typedef enum {
    QTSQ_TYPE_RAW          = 0x00,
    QTSQ_TYPE_IMAGE_GRAY   = 0x10,
    QTSQ_TYPE_IMAGE_RGB    = 0x11,
    QTSQ_TYPE_IMAGE_RGBA   = 0x12,
    QTSQ_TYPE_AUDIO_MONO   = 0x20,
    QTSQ_TYPE_AUDIO_STEREO = 0x21,
    QTSQ_TYPE_AUDIO_MULTI  = 0x22,
    QTSQ_TYPE_VIDEO_FRAMES = 0x30,
    QTSQ_TYPE_TEXT_ASCII   = 0x40,
    QTSQ_TYPE_TEXT_UTF8    = 0x41,
    QTSQ_TYPE_TABLE_INT    = 0x50,
    QTSQ_TYPE_TABLE_FLOAT  = 0x51,
    QTSQ_TYPE_JSON         = 0x52,
    QTSQ_TYPE_CSV          = 0x53,
    QTSQ_TYPE_SIGNAL_1D    = 0x60,
    QTSQ_TYPE_SIGNAL_2D    = 0x61,
    QTSQ_TYPE_TENSOR       = 0x70,  /* Neural tensor: weights, biases, embeddings */
    QTSQ_TYPE_CONTAINER    = 0xF0,
} qtsq_data_type_t;

/* Flags */
#define QTSQ_FLAG_LAZY_DECOMP   0x0001
#define QTSQ_FLAG_LOSSY         0x0002
#define QTSQ_FLAG_CHECKSUMMED   0x0004
#define QTSQ_FLAG_SEEKABLE      0x0008
#define QTSQ_FLAG_ENCRYPTED     0x0010
#define QTSQ_FLAG_MULTI_STREAM  0x0020
#define QTSQ_FLAG_AUTO_DETECTED 0x0040
#define QTSQ_FLAG_HAS_WORMHOLES 0x0080
#define QTSQ_FLAG_HAS_ECC       0x0100
#define QTSQ_FLAG_REDSHIFTABLE  0x0200
#define QTSQ_FLAG_HD            0x0400  /* High-quality triangle mesh (QTSQ HD) */
#define QTSQ_FLAG_3D            0x0800  /* 3D Depth encoded (Parallax/Volumetric) */
#define QTSQ_FLAG_UPSCALE       0x1000  /* Upscale mathematical enhancement for lossy frames */
#define QTSQ_FLAG_SPATIAL       0x2000  /* Spatial audio via atoms or object positioning */
#define QTSQ_FLAG_ZLIB          0x4000  /* Singularity payload is ZLib-compressed */
#define QTSQ_FLAG_SPLAT_ONLY    0x8000  /* Pure 2D Gaussian Splat image (no triangles) */

/* error codes */
#define QTSQ_OK                  0
#define QTSQ_ERR_NULL           -1
#define QTSQ_ERR_ALLOC          -2
#define QTSQ_ERR_IO             -3
#define QTSQ_ERR_FORMAT         -4
#define QTSQ_ERR_CHECKSUM       -5
#define QTSQ_ERR_STRATEGY       -6
#define QTSQ_ERR_TYPE           -7
#define QTSQ_ERR_ENCRYPTED      -8
#define QTSQ_ERR_DECRYPT        -9
#define QTSQ_ERR_WORMHOLE       -10
#define QTSQ_ERR_WORMHOLE_HASH  -11
#define QTSQ_ERR_CORRUPT        -12
#define QTSQ_ERR_RECOVERY_FAIL  -13
#define QTSQ_ERR_TOO_SMALL      -14

/* file header v2 — 96 bytes packed
 * v1 was 80 bytes with uint32_t sizes (4 GB limit)
 * v2 uses uint64_t sizes (18.4 EB limit) */
typedef struct {
    uint8_t      magic[4];
    uint8_t      version;
    uint8_t      strategy;
    uint16_t     flags;
    uint8_t      data_type;
    uint8_t      num_channels;
    uint16_t     sample_depth;
    uint32_t     reserved;
    uint64_t     original_size;
    uint64_t     timestamp;
    uint8_t      checksum[32];
    uint64_t     horizon_size;       /* v2: was uint32_t */
    uint64_t     accretion_size;     /* v2: was uint32_t */
    uint64_t     singularity_size;   /* v2: was uint32_t */
    uint64_t     radiation_size;     /* v2: was uint32_t */
} __attribute__((packed)) qtsq_header_t;

_Static_assert(sizeof(qtsq_header_t) == 96, "header must be 96 bytes");

/* v1 header for backward compatibility (reading old files) */
typedef struct {
    uint8_t      magic[4];
    uint8_t      version;
    uint8_t      strategy;
    uint16_t     flags;
    uint8_t      data_type;
    uint8_t      num_channels;
    uint16_t     sample_depth;
    uint32_t     reserved;
    uint64_t     original_size;
    uint64_t     timestamp;
    uint8_t      checksum[32];
    uint32_t     horizon_size;
    uint32_t     accretion_size;
    uint32_t     singularity_size;
    uint32_t     radiation_size;
} __attribute__((packed)) qtsq_header_v1_t;

_Static_assert(sizeof(qtsq_header_v1_t) == 80, "v1 header must be 80 bytes");

/* schema */
typedef struct {
    char         name[64];
    uint8_t      data_type;
    uint32_t     dimensions[8];
    uint8_t      num_dims;
    uint32_t     sample_rate;
    uint32_t     frame_rate;
    char         encoding[64];
} qtsq_schema_t;

/* transform */
typedef struct {
    uint8_t      type;
    uint32_t     param_size;
    void        *params;
} qtsq_transform_t;

/* Photon Audio Spatial Atom */
typedef struct {
    float freq_hz;
    float magnitude;
    float phase;
    float x;        /* Spatial X (pan): -1 (left) to 1 (right) */
    float y;        /* Spatial Y (height): -1 (low) to 1 (high) */
    float z;        /* Spatial Z (depth): 0 (far) to 1 (near) */
    float spread;   /* Spatial Spread (width): 0 (point) to 1 (diffuse) */
    uint32_t frame_index;
} photon_atom_t;

/* transform */
typedef struct {
    uint64_t     logical_offset;
    uint32_t     chunk_size;
    uint32_t     singularity_offset;
    uint8_t      priority;
} __attribute__((packed)) qtsq_index_t;

/* wormhole */
#define QTSQ_WORMHOLE_LOCAL      0x01
#define QTSQ_WORMHOLE_LAN        0x02
#define QTSQ_WORMHOLE_CLOUD      0x03
#define QTSQ_WORMHOLE_MARKER     0xEE

typedef struct {
    uint8_t      type;
    uint8_t      target_hash[32];
    char         target_path[256];
    uint32_t     target_offset;
    uint32_t     target_size;
} qtsq_wormhole_t;

/* censorship */
typedef struct {
    uint8_t       iv[16];
    uint8_t       salt[16];
    uint8_t       auth_tag[16];
    uint32_t      iterations;
} qtsq_censorship_t;

/* recovery */
typedef struct {
    uint32_t       num_chunks;
    uint32_t       *chunk_checksums;
    uint8_t        *reed_solomon_parity;
    uint32_t       parity_size;
} qtsq_recovery_t;

/* wave header (.qtsw) */
typedef struct {
    uint8_t        magic[4];
    uint8_t        source_hash[32];
    uint8_t        result_hash[32];
    uint64_t       timestamp;
    uint32_t       num_patches;
} __attribute__((packed)) qtsq_wave_header_t;

typedef struct {
    uint32_t       offset;
    uint32_t       old_size;
    uint32_t       new_size;
    uint8_t       *new_data;
} qtsq_patch_t;

/* main context */
typedef struct {
    qtsq_header_t       header;
    qtsq_schema_t       schema;
    qtsq_transform_t   *transforms;
    uint32_t           num_transforms;
    uint8_t           *singularity;
    uint64_t           singularity_size;
    qtsq_index_t       *radiation_index;
    uint32_t           num_radiation;
    qtsq_wormhole_t    *wormholes;
    uint32_t           num_wormholes;
    qtsq_censorship_t   censorship;
    int                is_encrypted;
    qtsq_recovery_t     recovery;
    int                has_recovery;
} qtsq_context_t;

/* ── Container (Multi-Stream) ── */
#define QTSQ_MAX_STREAMS 65536

/* v2 stream entry — no size limit per stream */
typedef struct {
    uint8_t   data_type;       /* QTSQ_TYPE_* for this stream */
    uint8_t   strategy;        /* QTSQ_STRATEGY_* used to compress */
    uint16_t  flags;           /* per-stream flags (ZLIB, LOSSY, etc.) */
    uint32_t  reserved;        /* alignment padding */
    uint64_t  data_offset;     /* offset from start of stream data block */
    uint64_t  data_size;       /* compressed size in bytes */
    uint64_t  original_size;   /* original uncompressed size */
} __attribute__((packed)) qtsq_stream_entry_t;

_Static_assert(sizeof(qtsq_stream_entry_t) == 32, "stream entry must be 32 bytes");

#endif