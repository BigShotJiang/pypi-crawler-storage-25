/*
 * Quantum Tensor Sequence — Universal Public API
 * File Extension: .qtsq (Quantum Tensor Sequence)
 * Author: Haruhito
 */

#ifndef QTSQ_H
#define QTSQ_H

#include "qtsq_format.h"
#include "qtsq_types.h"
#include "qtsq_turbo.h"
#include "qtsq_triangle_only.h"
#include "qtsq_ionic.h"

int  qtsq_init(qtsq_context_t *ctx);
void qtsq_free(qtsq_context_t *ctx);

int qtsq_compress(qtsq_context_t *ctx,
                 const uint8_t *data, size_t size,
                 qtsq_data_type_t type_hint);

int qtsq_compress_image(qtsq_context_t *ctx,
                       const uint8_t *pixels,
                       uint32_t width, uint32_t height,
                       uint8_t channels);

int qtsq_compress_gravitational(qtsq_context_t *ctx,
                                const uint8_t *pixels,
                                uint32_t width, uint32_t height,
                                uint8_t channels,
                                size_t source_size);

int qtsq_compress_gravitational_hd(qtsq_context_t *ctx,
                                    const uint8_t *pixels,
                                    uint32_t width, uint32_t height,
                                    uint8_t channels,
                                    size_t source_size);

/* Mathematical upscaler for lossy inputs (JPEG/WebP).
 * Uses dense triangle mesh + splats to reconstruct clean edges
 * from compression artifacts. Output is LARGER but HIGHER QUALITY. */
int qtsq_compress_gravitational_upscale(qtsq_context_t *ctx,
                                         const uint8_t *pixels,
                                         uint32_t width, uint32_t height,
                                         uint8_t channels,
                                         size_t source_size);

/* Lossless HD mode — maximum fidelity with 6M vertices.
 * Output caps: <5MB input → ≤10MB output, ≥5MB input → ≤30MB output. */
int qtsq_compress_gravitational_lossless(qtsq_context_t *ctx,
                                          const uint8_t *pixels,
                                          uint32_t width, uint32_t height,
                                          uint8_t channels,
                                          size_t source_size);

/* Pure 2D Gaussian Splat compression (no triangle mesh). */
int qtsq_compress_splat_compact(qtsq_context_t *ctx,
                                 const uint8_t *pixels,
                                 uint32_t width, uint32_t height,
                                 uint8_t channels, size_t source_size);
int qtsq_compress_splat_hd(qtsq_context_t *ctx,
                             const uint8_t *pixels,
                             uint32_t width, uint32_t height,
                             uint8_t channels, size_t source_size);
int qtsq_compress_splat_lossless(qtsq_context_t *ctx,
                                   const uint8_t *pixels,
                                   uint32_t width, uint32_t height,
                                   uint8_t channels, size_t source_size);
int qtsq_decompress_splat_only(qtsq_context_t *ctx,
                                 uint8_t **out_data, size_t *out_size);

int qtsq_decompress_gravitational(qtsq_context_t *ctx,
                                  uint8_t **out_data, size_t *out_size);

int qtsq_optimize_mesh(qtsq_context_t *ctx, const uint8_t *rgb_target, 
                       uint32_t width, uint32_t height);

/* ══════════════════════════════════════════════════════════════
 *  Gravitational AI Direct Render API 
 *  Bypasses redundant Delaunay triangulation during optimizations
 * ══════════════════════════════════════════════════════════════ */
typedef struct {
    float x, y;
    uint8_t r, g, b;
} tri_vertex_t;

typedef struct {
    uint32_t v0, v1, v2;
} tri_face_t;

int qtsq_render_mesh(const tri_vertex_t *verts, uint32_t nv,
                     const tri_face_t *faces, uint32_t nf,
                     uint32_t orig_w, uint32_t orig_h, uint8_t ch,
                     uint8_t *output);

/* AI Hooks for MeshNet V3 */
int qtsq_extract_vertices(const qtsq_context_t *ctx, float *flat_verts, uint32_t max_verts);
int qtsq_apply_vertices(qtsq_context_t *ctx, const float *new_verts, uint32_t num_verts);

/* Mesh Editor: Splat extract/apply — works with splat2d_t arrays directly */
int qtsq_extract_splats(const qtsq_context_t *ctx, void *out_splats, uint32_t max_splats,
                         uint32_t *out_width, uint32_t *out_height);
int qtsq_apply_splats(qtsq_context_t *ctx, const void *splats, uint32_t count,
                       uint32_t width, uint32_t height);

int qtsq_compress_gravitational_audio(qtsq_context_t *ctx,
                                       const int16_t *pcm,
                                       uint32_t total_samples,
                                       uint8_t channels,
                                       uint32_t sample_rate);

int qtsq_decompress_gravitational_audio(const qtsq_context_t *ctx,
                                          uint8_t **out_data, size_t *out_size);

int qtsq_compress_audio(qtsq_context_t *ctx,
                       const int16_t *samples,
                       size_t num_samples,
                       uint32_t sample_rate,
                       uint8_t channels);

/* Photon Audio — HQ Spatial Gabor atom codec */
int qtsq_compress_audio_hq(qtsq_context_t *ctx,
                            const float *samples,     /* 32-bit float */
                            size_t num_samples,
                            uint32_t sample_rate,
                            uint8_t channels);

int qtsq_decompress_audio_hq(const qtsq_context_t *ctx,
                              float **out_pcm,            /* outputs 32-bit float interleaved */
                              size_t *out_total_samples,
                              photon_atom_t **out_atoms,  /* outputs spatial atoms array */
                              size_t *out_atom_count);

/* Tensor precision levels */
typedef enum {
    QTSQ_TENSOR_F32    = 0,  /* 32-bit float (default, delta-quantized) */
    QTSQ_TENSOR_F16    = 1,  /* 16-bit IEEE 754 half-precision */
    QTSQ_TENSOR_F8     = 2,  /* 8-bit E4M3 (NVIDIA FP8) */
    QTSQ_TENSOR_F4     = 3,  /* 4-bit symmetric linear quantization */
    QTSQ_TENSOR_RAW    = 4,  /* 32-bit lossless (no delta encoding) */
} qtsq_tensor_precision_t;

/* Tensor compression — optimized for float32 arrays (AI weights, embeddings) */
int qtsq_compress_tensor(qtsq_context_t *ctx,
                          const float *data, size_t count,
                          const uint32_t *dimensions, uint8_t num_dims);

/* Quantized tensor — specify precision for model size reduction */
int qtsq_compress_tensor_quantized(qtsq_context_t *ctx,
                                    const float *data, size_t count,
                                    const uint32_t *dimensions, uint8_t num_dims,
                                    qtsq_tensor_precision_t precision);

int qtsq_decompress_tensor(const qtsq_context_t *ctx,
                            float **out_data, size_t *out_count);

/* High-level AI brain state API — packs everything into a container */
int qtsq_brain_save(const char *filename,
                     const float *weights, size_t weight_count,
                     const float *biases, size_t bias_count,
                     const float *memory_vectors, size_t num_memories,
                     size_t vector_dim,
                     const char *metadata_json);

int qtsq_brain_load(const char *filename,
                     float **out_weights, size_t *out_weight_count,
                     float **out_biases, size_t *out_bias_count,
                     float **out_memory_vectors, size_t *out_num_memories,
                     size_t *out_vector_dim,
                     char **out_metadata_json);

int qtsq_compress_text(qtsq_context_t *ctx,
                      const char *text, size_t length);

int qtsq_compress_csv(qtsq_context_t *ctx,
                     const char *csv_data, size_t length);

int qtsq_compress_json(qtsq_context_t *ctx,
                       const char *json, size_t length);

int qtsq_compress_signal(qtsq_context_t *ctx,
                        const double *signal, size_t num_samples);

typedef struct qtsq_video_encoder qtsq_video_encoder_t;

/* Initialize a video encoder session */
qtsq_video_encoder_t* qtsq_video_encoder_create(qtsq_context_t *ctx,
                                                uint32_t width, uint32_t height,
                                                uint8_t channels, uint32_t fps,
                                                int strategy_flags,
                                                size_t target_payload_per_frame);

/* Append a single uncompressed frame to the video sequence. */
int qtsq_video_encoder_add_frame(qtsq_video_encoder_t *enc, const uint8_t *pixels);

/* Finish encoding and flush all buffers to context. */
int qtsq_video_encoder_finish(qtsq_video_encoder_t *enc);

/* Get the underlying context */
qtsq_context_t* qtsq_video_encoder_get_context(qtsq_video_encoder_t *enc);

/* Cleanup encoder resources */
void qtsq_video_encoder_free(qtsq_video_encoder_t *enc);

typedef struct qtsq_video_decoder qtsq_video_decoder_t;

/* Open a video for decoding */
qtsq_video_decoder_t* qtsq_video_decoder_open(const qtsq_context_t *ctx);

/* Decode a specific frame. Returns malloc'd RGB buffer. */
int qtsq_video_decoder_get_frame(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t **out_pixels, uint32_t *width, uint32_t *height);

/* Get total number of frames */
uint32_t qtsq_video_decoder_get_frame_count(qtsq_video_decoder_t *dec);

/* Get the underlying context */
const qtsq_context_t* qtsq_video_decoder_get_context(qtsq_video_decoder_t *dec);

/* Cleanup decoder resources */
void qtsq_video_decoder_free(qtsq_video_decoder_t *dec);

int qtsq_compress_raw(qtsq_context_t *ctx,
                     const uint8_t *data, size_t size, uint64_t seed);

int qtsq_write(const qtsq_context_t *ctx, const char *filename);
int qtsq_read(qtsq_context_t *ctx, const char *filename);

int qtsq_decompress(qtsq_context_t *ctx,
                   uint8_t **out_data, size_t *out_size);

int qtsq_decompress_redshift(const qtsq_context_t *ctx,
                            double redshift,
                            uint8_t **out_data, size_t *out_size);

int qtsq_radiate(const qtsq_context_t *ctx,
                uint64_t offset, uint32_t size,
                uint8_t **out_data);
int qtsq_radiate_time(const qtsq_context_t *ctx,
                     double start_sec, double duration_sec,
                     int16_t **out_samples, size_t *out_count);
int qtsq_radiate_region(const qtsq_context_t *ctx,
                       uint32_t x, uint32_t y, uint32_t w, uint32_t h,
                       uint8_t **out_pixels);
int qtsq_radiate_frame(const qtsq_context_t *ctx,
                      uint32_t frame_index, uint8_t **out_pixels);

int qtsq_add_wormhole(qtsq_context_t *ctx,
                     const char *target_path,
                     uint32_t target_offset, uint32_t target_size);
int qtsq_resolve_wormholes(qtsq_context_t *ctx);

int qtsq_encrypt(qtsq_context_t *ctx, const char *password);
int qtsq_decrypt(qtsq_context_t *ctx, const char *password);
int qtsq_is_encrypted(const qtsq_context_t *ctx);

int qtsq_emit_wave(const qtsq_context_t *old_ctx,
                  const qtsq_context_t *new_ctx,
                  const char *wave_filename);
int qtsq_apply_wave(qtsq_context_t *ctx,
                   const char *wave_filename);

int qtsq_add_recovery(qtsq_context_t *ctx);
int qtsq_health_check(const qtsq_context_t *ctx);
int qtsq_recover(qtsq_context_t *ctx);

void            qtsq_print_info(const qtsq_context_t *ctx);
double          qtsq_compression_ratio(const qtsq_context_t *ctx);
const char*     qtsq_error_string(int error_code);

/* ══════ Utility ══════ */
void qtsq_sha256(const uint8_t *data, size_t size, uint8_t *hash);
double qtsq_entropy(const uint8_t *data, size_t size);
uint32_t qtsq_crc32(const uint8_t *data, size_t size);

/* ══════ Engine-specific decompression ══════ */
int qtsq_decompress_singularity(const qtsq_context_t *ctx,
                                uint8_t **out_data, size_t *out_size);
int qtsq_decompress_horizon(const qtsq_context_t *ctx,
                            uint8_t **out_data, size_t *out_size);
int qtsq_decompress_lensing(const qtsq_context_t *ctx,
                            uint8_t **out_data, size_t *out_size);
int qtsq_decompress_accretion(const qtsq_context_t *ctx,
                              uint8_t **out_data, size_t *out_size);

/* ══════ Container (Multi-Data) ══════ */
int qtsq_container_create(qtsq_context_t *ctx);
int qtsq_container_add_file(qtsq_context_t *ctx, const char *path,
                             const char *stream_name);
int qtsq_container_add_stream(qtsq_context_t *ctx,
                               const qtsq_context_t *sub_ctx,
                               const char *stream_name);
int qtsq_container_add_folder(qtsq_context_t *ctx, const char *folder_path);
int qtsq_container_pack(qtsq_context_t *ctx);
int qtsq_container_get_count(const qtsq_context_t *ctx, uint32_t *out_count);
int qtsq_container_get_stream(const qtsq_context_t *ctx, uint32_t index,
                               qtsq_context_t *out_ctx,
                               char *name_buf, size_t name_buf_size);

#endif /* QTSQ_H */
