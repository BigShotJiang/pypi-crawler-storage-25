/*
 * qtsq_triangle_only.h — Pure Triangle Mesh Compression (No Splats)
 *
 * Provides triangle-only compression at three quality levels.
 * Output is a pure Delaunay triangle mesh (TRM3 format) with NO
 * Gaussian splat overlay. Designed for DTCN neural network input.
 *
 * Author: Priyanshu Boruah / QTSQ Project
 */

#ifndef QTSQ_TRIANGLE_ONLY_H
#define QTSQ_TRIANGLE_ONLY_H

#include "qtsq_format.h"

/* ══════════════════════════════════════════════════════════════
 *  Pure Triangle-Only Compression API
 *
 *  All four modes produce TRM3 format (vertices only, no splats).
 *  The decoder performs Delaunay triangulation on the vertices and
 *  rasterizes the mesh with barycentric RGB interpolation.
 *
 *  Quality Levels:
 *    Compact  —  25K-400K vertices, 30-40% of original size
 *    HD       —  200K-3M vertices, 70-85% of original size
 *    Lossless —  500K-6M vertices, near-lossless quality
 *    Pixel    —  W×H vertices (1:1), pixel-perfect, for ML training
 * ══════════════════════════════════════════════════════════════ */

int qtsq_compress_triangle_compact(qtsq_context_t *ctx,
                                    const uint8_t *pixels,
                                    uint32_t width, uint32_t height,
                                    uint8_t channels, size_t source_size);

int qtsq_compress_triangle_hd(qtsq_context_t *ctx,
                                const uint8_t *pixels,
                                uint32_t width, uint32_t height,
                                uint8_t channels, size_t source_size);

int qtsq_compress_triangle_lossless(qtsq_context_t *ctx,
                                      const uint8_t *pixels,
                                      uint32_t width, uint32_t height,
                                      uint8_t channels, size_t source_size);

int qtsq_compress_triangle_pixel(qtsq_context_t *ctx,
                                   const uint8_t *pixels,
                                   uint32_t width, uint32_t height,
                                   uint8_t channels, size_t source_size);

/* Decompress: same as gravitational — Delaunay + barycentric rasterization.
 * Pixel mode uses direct vertex→pixel write (no interpolation).
 * Uses the existing qtsq_decompress_gravitational() since TRM3 format is shared. */

#endif /* QTSQ_TRIANGLE_ONLY_H */
