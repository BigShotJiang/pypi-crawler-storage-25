# QTSQ — Quantum Tensor Sequence

A high-performance binary format for images, text, audio, video, AI tensors, and complete neural brain states.

```
pip install qtsq
```

---

## Quick Start

```python
import qtsq
```

---

## Images

```python
# Compress an image → .qtsq
qtsq.compress("photo.png", "photo.qtsq")
qtsq.compress("photo.png", "photo.qtsq", mode="hd")         # high quality
qtsq.compress("photo.png", "photo.qtsq", mode="lossless")    # near-lossless

# Decompress → numpy array
img = qtsq.decompress("photo.qtsq")    # → numpy (H, W, 3) uint8

# View in window or save
qtsq.render("photo.qtsq")              # opens interactive viewer
qtsq.render("photo.qtsq", "out.png")   # saves to file
```

### Compression Modes

| Mode | Strategy | Best For |
|------|----------|----------|
| `"default"` | Triangle + Splat | General purpose |
| `"hd"` | Triangle + Splat (dense) | High quality output |
| `"lossless"` | Triangle + Splat | Near-lossless preservation |
| `"splat"` | Gaussian Splats only | Smooth images, gradients |
| `"splat_hd"` | HD Splats | High quality smooth regions |
| `"triangle"` | Mesh only | Sharp edges, diagrams |
| `"triangle_pixel"` | 1 vertex/pixel | ML training data |
| `"hd_ionic"` | HD + Ionic I/O | Maximum speed + quality |

---

## Text

```python
# Compress
qtsq.compress_text("Hello, world!", "hello.qtsq")

# Decompress
text = qtsq.decompress_text("hello.qtsq")
print(text)  # "Hello, world!"
```

---

## Tensors (AI Weights & Embeddings)

Store neural network weights with configurable precision. Smaller precision = smaller file, slightly less accuracy.

```python
import numpy as np
import qtsq

# Create some weights
weights = np.random.randn(10_000_000).astype(np.float32) * 0.1

# Save at different precisions
qtsq.compress_tensor(weights, "weights_f32.qtsq", precision="f32")   # lossless
qtsq.compress_tensor(weights, "weights_f16.qtsq", precision="f16")   # 2x smaller
qtsq.compress_tensor(weights, "weights_f8.qtsq",  precision="f8")    # 6x smaller
qtsq.compress_tensor(weights, "weights_f4.qtsq",  precision="f4")    # 7x smaller

# Load (always returns float32 regardless of storage precision)
loaded = qtsq.decompress_tensor("weights_f16.qtsq")
print(loaded.shape, loaded.dtype)  # (10000000,) float32
```

### Multi-dimensional tensors

```python
# Shape is preserved automatically
matrix = np.random.randn(768, 3072).astype(np.float32)
qtsq.compress_tensor(matrix, "layer.qtsq", precision="f16")

loaded = qtsq.decompress_tensor("layer.qtsq")
print(loaded.shape)  # (768, 3072)
```

### Precision Guide

| Precision | Bits | Compression | Max Error | Best For |
|-----------|------|-------------|-----------|----------|
| `"f32"` | 32 | ~1:1 | ~1e-8 | Training, gradients, critical weights |
| `"f16"` | 16 | ~2:1 | ~1e-4 | Inference, fine-tuning |
| `"f8"` | 8 | ~6:1 | ~1e-2 | Edge/mobile deployment |
| `"f4"` | 4 | ~7:1 | ~1e-2 | LLM inference (GGUF-compatible) |
| `"raw"` | 32 | ~1:1 | 0 | Bit-exact lossless |

### Precision Constants

```python
qtsq.TENSOR_F32   # "f32"
qtsq.TENSOR_F16   # "f16"
qtsq.TENSOR_F8    # "f8"
qtsq.TENSOR_F4    # "f4"
qtsq.TENSOR_RAW   # "raw"
```

---

## AI Brain State

Save and load a complete AI brain — weights, biases, memory vectors, and metadata — in a single `.qtsq` file.

```python
import qtsq
import json
import numpy as np

# ── Save ──
weights  = np.random.randn(1_000_000).astype(np.float32) * 0.1
biases   = np.random.randn(1000).astype(np.float32) * 0.01
memories = np.random.randn(100, 128).astype(np.float32)  # 100 memories, 128-dim each

metadata = json.dumps({
    "age": 5000,
    "stage": "child",
    "dopamine": 0.6,
    "cortisol": 0.2,
    "curiosity": 0.8,
    "confidence": 0.7,
})

qtsq.brain_save(
    "brain.qtsq",
    weights=weights,
    biases=biases,
    memories=memories.flatten(),
    vector_dim=128,
    metadata_json=metadata,
)

# ── Load ──
state = qtsq.brain_load("brain.qtsq")

print(state["weights"].shape)      # (1000000,)    — numpy float32
print(state["biases"].shape)       # (1000,)       — numpy float32
print(state["memories"].shape)     # (100, 128)    — numpy float32
print(state["num_memories"])       # 100
print(state["vector_dim"])         # 128

meta = json.loads(state["metadata"])
print(meta["stage"])               # "child"
print(meta["dopamine"])            # 0.6
```

### Brain State Structure

```
brain.qtsq
├── network_weights    → compressed float32 tensor
├── neuron_biases      → compressed float32 tensor
├── memory_vectors     → (num_memories × vector_dim) float32
└── metadata           → JSON string (personality, hormones, age, etc.)
```

---

## File Info

Inspect any `.qtsq` file without decompressing it:

```python
info = qtsq.info("photo.qtsq")
print(info)
# {
#   'strategy': 'tensor',
#   'data_type': 'tensor',
#   'width': 0,
#   'height': 0,
#   'channels': 0,
#   'original_size': 4000000,
#   'version': 1,
#   'encrypted': 0
# }
```

---

## Mesh Data (for DTCN)

Extract triangle mesh data for graph neural networks:

```python
data = qtsq.read("photo.qtsq")
print(data)
# QTSQData('photo.qtsq', 1920×1080, 45,231 vertices, 89,104 triangles)

data.vertices     # (N, 5) — x, y, R, G, B
data.positions    # (N, 2) — normalized positions
data.colors       # (N, 3) — RGB [0, 1]
data.triangles    # (M, 3) — triangle indices

# Convert to PyTorch Geometric graph
graph = data.to_graph(label=3)
```

---

## Install

### From PyPI

```bash
pip install qtsq
```

### From source

```bash
git clone https://github.com/haruhito/qtsq.git
cd qtsq
pip install .
```

### Requirements

- **Python** ≥ 3.8
- **C compiler** — Xcode (macOS) or gcc (Linux)
- **zlib** — usually pre-installed; on Linux: `apt install zlib1g-dev`
- **numpy**, **scipy** — installed automatically

### Optional dependencies

```bash
pip install qtsq[images]    # + Pillow (for qtsq.compress from image files)
pip install qtsq[ml]        # + PyTorch, PyG (for qtsq.read().to_graph())
```

---

## C API

The underlying C library can also be used directly:

```c
#include "qtsq.h"

// Tensor with f16 precision
float weights[1000000];
qtsq_context_t ctx;
qtsq_init(&ctx);
uint32_t dims[] = {1000000};
qtsq_compress_tensor_quantized(&ctx, weights, 1000000, dims, 1, QTSQ_TENSOR_F16);
qtsq_write(&ctx, "weights.qtsq");
qtsq_free(&ctx);

// Brain state
qtsq_brain_save("brain.qtsq", weights, 1000000, biases, 1000,
                memories, 100, 128, "{\"age\": 5000}");
```

Build the C library:

```bash
make lib    # → libqtsq.a
make cli    # → bin/qtsq (command-line tool)
```

---

## License

Proprietary — © haruhito
