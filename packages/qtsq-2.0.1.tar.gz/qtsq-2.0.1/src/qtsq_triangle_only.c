/*
 * qtsq_triangle_only.c — Pure Triangle Mesh Compression (No Splats)
 *
 * Forked from qtsq_gravitational.c with ALL splat logic removed.
 * Produces pure TRM3 vertex data → Delaunay triangulation at decode.
 *
 * Three quality tiers:
 *   Compact  — small output, 25K-400K vertices
 *   HD       — high quality, 200K-3M vertices, full budget to triangles
 *   Lossless — near-lossless, 500K-6M vertices
 *
 * Author: Priyanshu Boruah / QTSQ Project
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <zlib.h>
#include "qtsq_triangle_only.h"
#include "qtsq_parallel.h"
#include "qtsq.h"
#include <time.h>
#ifdef __APPLE__
#include "qtsq_metal.h"
#endif

#ifdef __ANDROID__
#include <android/log.h>
#define TONLY_LOG(...) __android_log_print(ANDROID_LOG_INFO, "QTSQ_TONLY", __VA_ARGS__)
#else
#define TONLY_LOG(...) fprintf(stderr, __VA_ARGS__)
#endif

static double tonly_time_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1000000.0;
}

/* ══════════════════════════════════════════════════════════════
 *  Sobel Edge Detection (Multi-Threaded)
 * ══════════════════════════════════════════════════════════════ */

typedef struct {
    const uint8_t *pixels;
    float *grad;
    uint32_t w, h;
    uint8_t ch;
    uint32_t start_row, end_row;
} tonly_grad_arg_t;

static void *tonly_gradient_strip(void *arg) {
    tonly_grad_arg_t *a = (tonly_grad_arg_t *)arg;
    const uint8_t *pixels = a->pixels;
    float *grad = a->grad;
    uint32_t w = a->w, h = a->h;
    uint8_t ch = a->ch;
    uint32_t y0 = a->start_row < 1 ? 1 : a->start_row;
    uint32_t y1 = a->end_row > h - 1 ? h - 1 : a->end_row;

    for (uint32_t y = y0; y < y1; y++) {
        for (uint32_t x = 1; x < w - 1; x++) {
            float gx = 0, gy = 0;
            for (uint8_t c = 0; c < ch; c++) {
                float dx = -(float)pixels[((y-1)*w + (x-1))*ch + c]
                           + (float)pixels[((y-1)*w + (x+1))*ch + c]
                           - 2.0f*(float)pixels[(y*w + (x-1))*ch + c]
                           + 2.0f*(float)pixels[(y*w + (x+1))*ch + c]
                           - (float)pixels[((y+1)*w + (x-1))*ch + c]
                           + (float)pixels[((y+1)*w + (x+1))*ch + c];
                float dy = -(float)pixels[((y-1)*w + (x-1))*ch + c]
                           - 2.0f*(float)pixels[((y-1)*w + x)*ch + c]
                           - (float)pixels[((y-1)*w + (x+1))*ch + c]
                           + (float)pixels[((y+1)*w + (x-1))*ch + c]
                           + 2.0f*(float)pixels[((y+1)*w + x)*ch + c]
                           + (float)pixels[((y+1)*w + (x+1))*ch + c];
                gx += dx * dx;
                gy += dy * dy;
            }
            grad[y * w + x] = sqrtf(gx + gy);
        }
    }
    return NULL;
}

static float *tonly_compute_gradient(const uint8_t *pixels, uint32_t w, uint32_t h, uint8_t ch) {
    float *grad = (float *)calloc((size_t)w * h, sizeof(float));
    if (!grad) return NULL;

#ifdef __APPLE__
    static qtsq_metal_ctx_t *metal = NULL;
    if (!metal) metal = qtsq_metal_init();
    if (metal) {
        if (qtsq_metal_sobel(metal, pixels, grad, w, h, ch) == 0)
            return grad;
    }
#endif

    int nc = qtsq_num_cores();
    if ((uint32_t)nc > h) nc = (int)h;

    tonly_grad_arg_t args[QTSQ_MAX_THREADS];
    for (int t = 0; t < nc; t++) {
        args[t].pixels = pixels;
        args[t].grad = grad;
        args[t].w = w; args[t].h = h; args[t].ch = ch;
        args[t].start_row = (uint32_t)((uint64_t)h * t / nc);
        args[t].end_row   = (uint32_t)((uint64_t)h * (t + 1) / nc);
    }
    qtsq_dispatch(tonly_gradient_strip, args, sizeof(tonly_grad_arg_t), nc);
    return grad;
}

/* ══════════════════════════════════════════════════════════════
 *  Vertex Placement — Full Image (No fg/bg Split)
 *
 *  Unlike the gravitational mode, we do NOT create a foreground/
 *  background map. ALL regions get vertices. 100% budget goes
 *  to the triangle mesh for maximum coverage.
 * ══════════════════════════════════════════════════════════════ */

static inline int tonly_add_vertex(const uint8_t *pixels, uint32_t w, uint8_t ch,
                                    tri_vertex_t *verts, uint8_t *used,
                                    uint32_t *nv, uint32_t max_verts,
                                    uint32_t x, uint32_t y) {
    if (*nv >= max_verts) return 0;
    if (used[y * w + x]) return 0;
    used[y * w + x] = 1;
    size_t idx = ((size_t)y * w + x) * ch;
    verts[*nv].x = (float)x;
    verts[*nv].y = (float)y;
    verts[*nv].r = pixels[idx];
    verts[*nv].g = (ch >= 2) ? pixels[idx + 1] : pixels[idx];
    verts[*nv].b = (ch >= 3) ? pixels[idx + 2] : pixels[idx];
    (*nv)++;
    return 1;
}

static uint32_t tonly_place_vertices(const uint8_t *pixels, const float *grad,
                                      uint32_t w, uint32_t h, uint8_t ch,
                                      tri_vertex_t *verts, uint32_t max_verts,
                                      uint8_t *used) {
    uint32_t nv = 0;
    size_t npx = (size_t)w * h;

    /* ────────────────────────────────────────────────────────
     *  Phase 1: Boundary anchors (essential for clean edges)
     *  Budget: ~5% — these prevent border artifacts
     * ──────────────────────────────────────────────────────── */
    uint32_t bnd_budget = (uint32_t)(max_verts * 0.05f);
    if (bnd_budget < 20) bnd_budget = 20;
    uint32_t bnd_count = 2 * (w + h);
    int bnd_step = (int)((float)bnd_count / (float)bnd_budget + 0.5f);
    if (bnd_step < 1) bnd_step = 1;

    /* Four edges */
    for (uint32_t x = 0; x < w && nv < max_verts; x += bnd_step)
        tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, x, 0);
    for (uint32_t x = 0; x < w && nv < max_verts; x += bnd_step)
        tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, x, h - 1);
    for (uint32_t y = 1; y < h - 1 && nv < max_verts; y += bnd_step)
        tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, 0, y);
    for (uint32_t y = 1; y < h - 1 && nv < max_verts; y += bnd_step)
        tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, w - 1, y);
    /* Corners guaranteed */
    tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, 0, 0);
    tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, w - 1, 0);
    tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, 0, h - 1);
    tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, w - 1, h - 1);

    uint32_t bnd_placed = nv;

    /* ────────────────────────────────────────────────────────
     *  Phase 2: Sparse safety grid (~5% budget)
     *  Prevents large uncovered holes in completely flat regions
     *  that have zero gradient (solid color walls, clear sky).
     *  Grid step is large — only catches areas the gradient pass
     *  would completely skip.
     * ──────────────────────────────────────────────────────── */
    uint32_t safety_budget = (uint32_t)(max_verts * 0.05f);
    double safety_step_f = sqrt((double)npx / (double)(safety_budget > 0 ? safety_budget : 1));
    int safety_step = (int)ceil(safety_step_f);
    if (safety_step < 2) safety_step = 2;

    uint32_t safety_placed = 0;
    for (uint32_t y = (uint32_t)(safety_step / 2); y < h && safety_placed < safety_budget; y += safety_step)
        for (uint32_t x = (uint32_t)(safety_step / 2); x < w && safety_placed < safety_budget; x += safety_step)
            if (tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, x, y))
                safety_placed++;

    /* ────────────────────────────────────────────────────────
     *  Phase 3: Gradient-Density Placement (~90% budget)
     *
     *  Vertex density is PROPORTIONAL to local gradient magnitude.
     *  Uses error-diffusion (Floyd-Steinberg style) across the
     *  gradient field so placement is spatially even, not biased
     *  toward the top-left.
     *
     *  Key improvements over old algorithm:
     *  - Base floor: every pixel gets min weight (grad + base),
     *    so flat regions still get sparse coverage
     *  - Multi-pass: if first pass doesn't fill budget, runs
     *    again with lower threshold
     *  - Non-linear gradient boost: grad^1.5 emphasizes strong
     *    edges more aggressively
     * ──────────────────────────────────────────────────────── */
    uint32_t density_budget = max_verts - nv;
    if (density_budget < 10) goto done;

    /* Build boosted gradient field: grad^1.5 + base_floor.
     * The exponent >1 concentrates vertices MORE on strong edges.
     * The base_floor ensures smooth regions still get minimal coverage. */
    float grad_max = 0.0f;
    for (size_t i = 0; i < npx; i++)
        if (grad[i] > grad_max) grad_max = grad[i];
    if (grad_max < 1.0f) grad_max = 1.0f;

    /* Base floor: 1% of max gradient — ensures even zero-gradient
     * regions contribute a tiny amount to vertex density. */
    float base_floor = grad_max * 0.01f;

    /* Compute boosted gradient sum for error-diffusion threshold */
    double sum_boosted = 0.0;
    for (uint32_t y = 1; y < h - 1; y++)
        for (uint32_t x = 1; x < w - 1; x++)
            if (!used[y * w + x]) {
                float g = grad[y * w + x] + base_floor;
                /* Non-linear boost: g^1.5 = g * sqrt(g) */
                sum_boosted += (double)(g * sqrtf(g));
            }

    double boosted_per_vert = sum_boosted / (double)(density_budget > 0 ? density_budget : 1);
    if (boosted_per_vert < 0.0001) boosted_per_vert = 1.0;

    /* Error-diffusion pass: accumulate boosted gradient,
     * emit vertex when accumulated error exceeds threshold.
     * Scan in serpentine (alternating L→R, R→L) to avoid
     * directional bias toward top-left. */
    double error_acc = 0.0;
    for (uint32_t y = 1; y < h - 1 && nv < max_verts; y++) {
        int rev = (y & 1);  /* Serpentine: even rows L→R, odd rows R→L */
        for (uint32_t xi = 0; xi < w - 2 && nv < max_verts; xi++) {
            uint32_t x = rev ? (w - 2 - xi) : (xi + 1);
            if (used[y * w + x]) continue;

            float g = grad[y * w + x] + base_floor;
            float boosted = g * sqrtf(g);
            error_acc += (double)boosted;

            if (error_acc >= boosted_per_vert) {
                tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, x, y);
                error_acc -= boosted_per_vert;
            }
        }
    }

    /* Phase 4: Fill any remaining budget with uniform backfill */
    if (nv < max_verts) {
        uint32_t remaining = max_verts - nv;
        if (remaining > 10) {
            double r_step_f = sqrt((double)npx / (double)remaining);
            int r_step = (int)ceil(r_step_f);
            if (r_step < 1) r_step = 1;
            for (uint32_t y = (uint32_t)(r_step / 2); y < h && nv < max_verts; y += r_step)
                for (uint32_t x = (uint32_t)(r_step / 2); x < w && nv < max_verts; x += r_step)
                    if (!used[y * w + x])
                        tonly_add_vertex(pixels, w, ch, verts, used, &nv, max_verts, x, y);
        }
    }

done:
    TONLY_LOG("[TONLY] Vertices placed: %u (boundary=%u safety=%u density=%u)\n",
             nv, bnd_placed, safety_placed, nv - bnd_placed - safety_placed);
    return nv;
}

/* ══════════════════════════════════════════════════════════════
 *  TRM3 Packing — Pack vertices into planar TRM3 format + zlib
 * ══════════════════════════════════════════════════════════════ */

static int tonly_compare_verts_yx(const void *a, const void *b) {
    const tri_vertex_t *va = (const tri_vertex_t *)a;
    const tri_vertex_t *vb = (const tri_vertex_t *)b;
    if (va->y < vb->y) return -1;
    if (va->y > vb->y) return 1;
    if (va->x < vb->x) return -1;
    if (va->x > vb->x) return 1;
    return 0;
}

static int tonly_pack_trm3(const tri_vertex_t *verts, uint32_t nv,
                            uint32_t width, uint32_t height, uint8_t channels,
                            uint8_t **out_data, size_t *out_size, int comp_level) {
    /* Sort copy by Y,X for better zlib delta compression */
    tri_vertex_t *sorted = (tri_vertex_t *)malloc(nv * sizeof(tri_vertex_t));
    if (!sorted) return -1;
    memcpy(sorted, verts, nv * sizeof(tri_vertex_t));
    qsort(sorted, nv, sizeof(tri_vertex_t), tonly_compare_verts_yx);

    size_t hsz = 4 + 4 + 4 + 1 + 4;  /* TRM3 header */
    size_t vd = (size_t)nv * 7;       /* 2+2+1+1+1 per vertex */
    size_t raw_sz = hsz + vd;

    uint8_t *raw = (uint8_t *)malloc(raw_sz);
    if (!raw) { free(sorted); return -1; }

    size_t p = 0;
    raw[p++] = 'T'; raw[p++] = 'R'; raw[p++] = 'M'; raw[p++] = '3';
    memcpy(raw + p, &width, 4);  p += 4;
    memcpy(raw + p, &height, 4); p += 4;
    raw[p++] = channels;
    memcpy(raw + p, &nv, 4);     p += 4;

    /* Planar layout: all X, all Y, all R, all G, all B */
    for (uint32_t i = 0; i < nv; i++) { uint16_t v = (uint16_t)(sorted[i].x + 0.5f); memcpy(raw + p, &v, 2); p += 2; }
    for (uint32_t i = 0; i < nv; i++) { uint16_t v = (uint16_t)(sorted[i].y + 0.5f); memcpy(raw + p, &v, 2); p += 2; }
    for (uint32_t i = 0; i < nv; i++) raw[p++] = sorted[i].r;
    for (uint32_t i = 0; i < nv; i++) raw[p++] = sorted[i].g;
    for (uint32_t i = 0; i < nv; i++) raw[p++] = sorted[i].b;
    free(sorted);

    /* Zlib compress */
    uLongf zb = compressBound((uLong)p);
    uint8_t *zd = (uint8_t *)malloc(zb);
    if (!zd) { free(raw); return -1; }
    uLongf zs = zb;
    if (compress2(zd, &zs, raw, (uLong)p, comp_level) != Z_OK) {
        free(raw); free(zd); return -1;
    }

    size_t final_sz = 4 + (size_t)zs;
    uint8_t *out = (uint8_t *)malloc(final_sz);
    if (!out) { free(raw); free(zd); return -1; }
    uint32_t uncomp = (uint32_t)p;
    memcpy(out, &uncomp, 4);
    memcpy(out + 4, zd, zs);
    free(raw); free(zd);

    *out_data = out;
    *out_size = final_sz;
    return 0;
}

/* ══════════════════════════════════════════════════════════════
 *  Shared helper: finalize context after compression
 * ══════════════════════════════════════════════════════════════ */

static void tonly_finalize_ctx(qtsq_context_t *ctx,
                                uint8_t *payload, size_t payload_size,
                                uint32_t nv, uint32_t width, uint32_t height,
                                uint8_t channels, const uint8_t *pixels,
                                uint32_t flags, const char *encoding) {
    size_t pixel_count = (size_t)width * height;

    if (ctx->singularity) free(ctx->singularity);
    ctx->singularity = payload;
    ctx->singularity_size = (uint32_t)payload_size;

    ctx->header.reserved = nv;
    ctx->header.strategy = QTSQ_STRATEGY_TRIANGLE;
    ctx->header.data_type = (channels == 1) ? QTSQ_TYPE_IMAGE_GRAY :
                            (channels == 4) ? QTSQ_TYPE_IMAGE_RGBA :
                            QTSQ_TYPE_IMAGE_RGB;
    ctx->header.original_size = pixel_count * channels;
    ctx->header.num_channels = channels;
    ctx->header.sample_depth = 8;
    ctx->header.singularity_size = ctx->singularity_size;
    ctx->header.flags |= QTSQ_FLAG_LOSSY | QTSQ_FLAG_CHECKSUMMED | flags;

    memset(&ctx->schema, 0, sizeof(qtsq_schema_t));
    strncpy(ctx->schema.name, "triangle_only", 63);
    ctx->schema.data_type = ctx->header.data_type;
    ctx->schema.dimensions[0] = width;
    ctx->schema.dimensions[1] = height;
    ctx->schema.dimensions[2] = channels;
    ctx->schema.num_dims = 3;
    strncpy(ctx->schema.encoding, encoding, 63);
    ctx->header.horizon_size = sizeof(qtsq_schema_t);

    qtsq_sha256(pixels, pixel_count * channels, ctx->header.checksum);
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_compress_triangle_compact
 *
 *  Pure triangle mesh, compact size.
 *  25K-400K vertices, 30-40% of original.
 *  No splats. 100% budget to triangle mesh.
 * ══════════════════════════════════════════════════════════════ */

int qtsq_compress_triangle_compact(qtsq_context_t *ctx,
                                    const uint8_t *pixels,
                                    uint32_t width, uint32_t height,
                                    uint8_t channels, size_t source_size) {
    if (!ctx || !pixels) return QTSQ_ERR_NULL;
    if (width < 8 || height < 8) return QTSQ_ERR_TOO_SMALL;
    if (channels < 1 || channels > 4) return QTSQ_ERR_FORMAT;

    double t_total = tonly_time_ms();
    size_t pixel_count = (size_t)width * height;
    size_t original_bytes = source_size > 0 ? source_size : (pixel_count * channels / 10);

    /* Budget: target 65% of original size */
    double target_ratio = (original_bytes <= 2 * 1024 * 1024) ? 0.65 : 0.75;
    double target_bytes = (double)original_bytes * target_ratio;

    /* 100% budget → vertices (no splat split!) */
    uint32_t max_verts = (uint32_t)(target_bytes / 3.6);
    if (max_verts < 25000)   max_verts = 25000;
    if (max_verts > 2000000) max_verts = 2000000;

    TONLY_LOG("[TONLY Compact] Input: %zu bytes, max_verts: %u\n", original_bytes, max_verts);

    /* Allocate */
    tri_vertex_t *verts = (tri_vertex_t *)malloc(max_verts * sizeof(tri_vertex_t));
    uint8_t *used = (uint8_t *)calloc(pixel_count, sizeof(uint8_t));
    if (!verts || !used) { free(verts); free(used); return QTSQ_ERR_ALLOC; }

    /* Gradient */
    float *grad = tonly_compute_gradient(pixels, width, height, channels);
    if (!grad) { free(verts); free(used); return QTSQ_ERR_ALLOC; }

    /* Place vertices — 100% to triangles */
    uint32_t nv = tonly_place_vertices(pixels, grad, width, height, channels,
                                        verts, max_verts, used);
    free(grad);
    free(used);

    /* Pack TRM3 + zlib level 9 (max compression for compact) */
    uint8_t *payload = NULL;
    size_t payload_size = 0;
    if (tonly_pack_trm3(verts, nv, width, height, channels,
                         &payload, &payload_size, 9) != 0) {
        free(verts);
        return QTSQ_ERR_ALLOC;
    }
    free(verts);

    tonly_finalize_ctx(ctx, payload, payload_size, nv,
                        width, height, channels, pixels,
                        0, "TRI_ONLY_COMPACT");

    TONLY_LOG("[TONLY Compact] %u verts → %zu bytes in %.1f ms\n",
             nv, payload_size, tonly_time_ms() - t_total);
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_compress_triangle_hd
 *
 *  Pure triangle mesh, high quality.
 *  200K-3M vertices, 70-85% of original.
 *  No splats. Full HD budget to triangle mesh.
 * ══════════════════════════════════════════════════════════════ */

int qtsq_compress_triangle_hd(qtsq_context_t *ctx,
                                const uint8_t *pixels,
                                uint32_t width, uint32_t height,
                                uint8_t channels, size_t source_size) {
    if (!ctx || !pixels) return QTSQ_ERR_NULL;
    if (width < 8 || height < 8) return QTSQ_ERR_TOO_SMALL;
    if (channels < 1 || channels > 4) return QTSQ_ERR_FORMAT;

    double t_total = tonly_time_ms();
    size_t pixel_count = (size_t)width * height;

    /* HD budget: 100% of raw budget goes to vertices (no 85/15 splat split!) */
    size_t target_payload;
    if (source_size > 0) {
        target_payload = (size_t)(source_size * 3.5);
        if (target_payload > pixel_count * channels * 2)
            target_payload = pixel_count * channels * 2;
    } else {
        target_payload = (size_t)(pixel_count * channels * 2.0);
    }

    size_t hdr_overhead = sizeof(qtsq_header_t) + sizeof(qtsq_schema_t);
    if (target_payload > hdr_overhead) target_payload -= hdr_overhead;

    /* ALL payload → vertices (gravitational mode only gives 85%) */
    uint32_t max_verts = (uint32_t)(target_payload / 2);
    if (max_verts < 200000)  max_verts = 200000;
    if (max_verts > 3000000) max_verts = 3000000;

    TONLY_LOG("[TONLY HD] Input: %zu bytes, budget: %zu, max_verts: %u\n",
             source_size, target_payload, max_verts);

    /* Allocate */
    tri_vertex_t *verts = (tri_vertex_t *)malloc(max_verts * sizeof(tri_vertex_t));
    uint8_t *used = (uint8_t *)calloc(pixel_count, sizeof(uint8_t));
    if (!verts || !used) { free(verts); free(used); return QTSQ_ERR_ALLOC; }

    /* Gradient */
    float *grad = tonly_compute_gradient(pixels, width, height, channels);
    if (!grad) { free(verts); free(used); return QTSQ_ERR_ALLOC; }

    /* Place vertices */
    uint32_t nv = tonly_place_vertices(pixels, grad, width, height, channels,
                                        verts, max_verts, used);
    free(grad);
    free(used);

    /* Pack TRM3 + zlib level 1 (fast, for HD) */
    uint8_t *payload = NULL;
    size_t payload_size = 0;
    if (tonly_pack_trm3(verts, nv, width, height, channels,
                         &payload, &payload_size, 1) != 0) {
        free(verts);
        return QTSQ_ERR_ALLOC;
    }
    free(verts);

    tonly_finalize_ctx(ctx, payload, payload_size, nv,
                        width, height, channels, pixels,
                        QTSQ_FLAG_HD, "TRI_ONLY_HD");

    TONLY_LOG("[TONLY HD] %u verts → %zu bytes in %.1f ms\n",
             nv, payload_size, tonly_time_ms() - t_total);
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_compress_triangle_lossless
 *
 *  Pure triangle mesh, near-lossless quality.
 *  500K-6M vertices, maximum fidelity.
 *  No splats. Every byte goes to vertex density.
 * ══════════════════════════════════════════════════════════════ */

int qtsq_compress_triangle_lossless(qtsq_context_t *ctx,
                                      const uint8_t *pixels,
                                      uint32_t width, uint32_t height,
                                      uint8_t channels, size_t source_size) {
    if (!ctx || !pixels) return QTSQ_ERR_NULL;
    if (width < 8 || height < 8) return QTSQ_ERR_TOO_SMALL;
    if (channels < 1 || channels > 4) return QTSQ_ERR_FORMAT;

    double t_total = tonly_time_ms();
    size_t pixel_count = (size_t)width * height;

    /* Lossless budget: maximum vertex density */
    size_t target_payload;
    if (source_size > 0) {
        target_payload = (size_t)(source_size * 5.0);
        if (target_payload > pixel_count * channels * 3)
            target_payload = pixel_count * channels * 3;
    } else {
        target_payload = (size_t)(pixel_count * channels * 3.0);
    }

    /* ALL payload → vertices */
    uint32_t max_verts = (uint32_t)(target_payload / 2);
    if (max_verts < 500000)  max_verts = 500000;
    if (max_verts > 6000000) max_verts = 6000000;

    /* Cap memory: 6M vertices × sizeof(tri_vertex_t) ≈ 120MB */
    size_t mem_needed = (size_t)max_verts * sizeof(tri_vertex_t) + pixel_count;
    if (mem_needed > 512 * 1024 * 1024) {
        max_verts = (uint32_t)((512 * 1024 * 1024 - pixel_count) / sizeof(tri_vertex_t));
    }

    TONLY_LOG("[TONLY Lossless] Input: %zu bytes, max_verts: %u\n",
             source_size, max_verts);

    /* Allocate */
    tri_vertex_t *verts = (tri_vertex_t *)malloc(max_verts * sizeof(tri_vertex_t));
    uint8_t *used = (uint8_t *)calloc(pixel_count, sizeof(uint8_t));
    if (!verts || !used) { free(verts); free(used); return QTSQ_ERR_ALLOC; }

    /* Gradient */
    float *grad = tonly_compute_gradient(pixels, width, height, channels);
    if (!grad) { free(verts); free(used); return QTSQ_ERR_ALLOC; }

    /* Place vertices */
    uint32_t nv = tonly_place_vertices(pixels, grad, width, height, channels,
                                        verts, max_verts, used);
    free(grad);
    free(used);

    /* Pack TRM3 + zlib level 6 (balanced speed/compression) */
    uint8_t *payload = NULL;
    size_t payload_size = 0;
    if (tonly_pack_trm3(verts, nv, width, height, channels,
                         &payload, &payload_size, 6) != 0) {
        free(verts);
        return QTSQ_ERR_ALLOC;
    }
    free(verts);

    tonly_finalize_ctx(ctx, payload, payload_size, nv,
                        width, height, channels, pixels,
                        QTSQ_FLAG_HD, "TRI_ONLY_LOSSLESS");

    TONLY_LOG("[TONLY Lossless] %u verts → %zu bytes in %.1f ms\n",
             nv, payload_size, tonly_time_ms() - t_total);
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_compress_triangle_pixel
 *
 *  Pixel-perfect triangle mesh: 1 vertex per pixel.
 *  Every pixel is stored as a vertex with its exact RGB color.
 *  No gradient-based sampling, no quality loss.
 *
 *  The decoder writes each vertex directly to its (x,y) position
 *  instead of doing barycentric interpolation — guaranteed bit-exact
 *  pixel reconstruction.
 *
 *  The Delaunay triangulation is still available at decode time for
 *  DTCN graph construction, but is NOT used for pixel rendering.
 *
 *  Size: typically 50-150 KB for 150×150 images (zlib'd TRM3).
 *  Designed for ML training datasets where quality > size.
 * ══════════════════════════════════════════════════════════════ */

int qtsq_compress_triangle_pixel(qtsq_context_t *ctx,
                                   const uint8_t *pixels,
                                   uint32_t width, uint32_t height,
                                   uint8_t channels, size_t source_size) {
    if (!ctx || !pixels) return QTSQ_ERR_NULL;
    if (width < 8 || height < 8) return QTSQ_ERR_TOO_SMALL;
    if (channels < 1 || channels > 4) return QTSQ_ERR_FORMAT;

    double t_total = tonly_time_ms();
    size_t pixel_count = (size_t)width * height;

    /* Every pixel = 1 vertex. No subsampling. */
    uint32_t nv = (uint32_t)pixel_count;

    TONLY_LOG("[TONLY Pixel] %ux%u (%u pixels) → %u vertices (1:1)\n",
             width, height, nv, nv);

    /* Allocate vertices — sequential pixel-to-vertex mapping */
    tri_vertex_t *verts = (tri_vertex_t *)malloc(nv * sizeof(tri_vertex_t));
    if (!verts) return QTSQ_ERR_ALLOC;

    /* Direct mapping: vertex[i] = pixel[i] with position (x, y) */
    for (uint32_t y = 0; y < height; y++) {
        for (uint32_t x = 0; x < width; x++) {
            uint32_t vi = y * width + x;
            size_t pi = (size_t)vi * channels;
            verts[vi].x = (float)x;
            verts[vi].y = (float)y;
            verts[vi].r = pixels[pi];
            verts[vi].g = (channels >= 2) ? pixels[pi + 1] : pixels[pi];
            verts[vi].b = (channels >= 3) ? pixels[pi + 2] : pixels[pi];
        }
    }

    /* Pack TRM3 + zlib level 6 (balanced speed/compression).
     * The planar layout (all X, all Y, all R, all G, all B) compresses
     * very well with zlib because adjacent pixels have similar values. */
    uint8_t *payload = NULL;
    size_t payload_size = 0;
    if (tonly_pack_trm3(verts, nv, width, height, channels,
                         &payload, &payload_size, 6) != 0) {
        free(verts);
        return QTSQ_ERR_ALLOC;
    }
    free(verts);

    tonly_finalize_ctx(ctx, payload, payload_size, nv,
                        width, height, channels, pixels,
                        QTSQ_FLAG_HD, "TRI_ONLY_PIXEL");

    TONLY_LOG("[TONLY Pixel] %u verts → %zu bytes in %.1f ms\n",
             nv, payload_size, tonly_time_ms() - t_total);
    return QTSQ_OK;
}
