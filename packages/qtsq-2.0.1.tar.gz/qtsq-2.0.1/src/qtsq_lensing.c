/*
 * Quantum Tensor Sequence — Singularity Audio Codec v5
 * Dictionary-Based Spectral Compression with Phase Preservation
 *
 * Architecture:
 *   1. STFT → magnitude + phase frames (using sqrt-Hann window)
 *   2. Build dictionary: greedy clustering via cosine similarity
 *      - Each unique spectral shape stored once
 *      - Per-band gains (8 bands) for adaptive matching
 *   3. Phase: store deviation from expected phase advance (8-bit)
 *   4. Timeline: [dictionary_index, band_gains[], phase_deviations[]] per frame
 *   5. Decode: lookup × band_gains → combine with stored phase → iSTFT
 *
 * v5 improvements over v4:
 *   - Phase preservation (no more metallic/robotic artifacts)
 *   - Per-band gains (8 bands) for better spectral matching
 *   - Log-scale magnitude quantization (perceptual)
 *   - Proper sqrt-Hann COLA overlap-add
 *   - Reduced dictionary quantization noise
 *
 * Author: Haruhito
 */
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <zlib.h>
#include "qtsq.h"

#define FFT_SIZE     2048
#define HOP_SIZE     1024      /* 50% overlap — good balance of quality vs size */
#define FREQ_BINS    (FFT_SIZE / 2 + 1)  /* 1025 */
#define PHASE_BINS   256       /* Only store phase for bins 0-255 (~5.5 kHz, perceptually critical) */
#define SIM_THRESH   0.92f    /* Slightly more permissive → fewer entries, bigger gains */
#define MAX_DICT     4096     /* More entries allowed for quality */
#define NUM_BANDS    8        /* Per-band gain resolution */
#define PHASE_BITS   4        /* 4-bit phase deviation → 2 values per byte */

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

/* Band boundaries (approximate critical bands simplified to 8) */
static const int BAND_EDGES[NUM_BANDS + 1] = {
    0, 16, 48, 128, 256, 384, 512, 768, FREQ_BINS
};

/* ═══════════════════════════════════════════
 *  FFT — Radix-2 Cooley-Tukey
 * ═══════════════════════════════════════════ */
static void fft(float *re, float *im, int N, int inverse) {
    int j = 0;
    for (int i = 0; i < N - 1; i++) {
        if (i < j) {
            float tr = re[i]; re[i] = re[j]; re[j] = tr;
            float ti = im[i]; im[i] = im[j]; im[j] = ti;
        }
        int m = N >> 1;
        while (m >= 1 && j >= m) { j -= m; m >>= 1; }
        j += m;
    }
    for (int step = 1; step < N; step <<= 1) {
        float angle = (inverse ? (float)M_PI : (float)-M_PI) / (float)step;
        float wr = cosf(angle), wi = sinf(angle);
        for (int group = 0; group < N; group += step << 1) {
            float cr = 1.0f, ci = 0.0f;
            for (int pair = 0; pair < step; pair++) {
                int a = group + pair, b = a + step;
                float tr = re[b] * cr - im[b] * ci;
                float ti = re[b] * ci + im[b] * cr;
                re[b] = re[a] - tr; im[b] = im[a] - ti;
                re[a] += tr; im[a] += ti;
                float nr = cr * wr - ci * wi;
                ci = cr * wi + ci * wr; cr = nr;
            }
        }
    }
    if (inverse) {
        float inv = 1.0f / (float)N;
        for (int i = 0; i < N; i++) { re[i] *= inv; im[i] *= inv; }
    }
}

/* ═══════════════════════════════════════════
 *  Window — sqrt-Hann for COLA compliance
 *  Analysis × Synthesis both use sqrt-Hann
 *  so (sqrt-Hann)² = Hann, which is COLA.
 * ═══════════════════════════════════════════ */
static float ana_win[FFT_SIZE];
static int win_ready = 0;
static void ensure_window(void) {
    if (win_ready) return;
    for (int i = 0; i < FFT_SIZE; i++) {
        float hann = 0.5f * (1.0f - cosf(2.0f * (float)M_PI * i / (float)(FFT_SIZE - 1)));
        ana_win[i] = sqrtf(hann + 1e-10f);  /* sqrt-Hann for analysis+synthesis */
    }
    win_ready = 1;
}

/* ═══════════════════════════════════════════
 *  STFT — Now stores both magnitude AND phase
 * ═══════════════════════════════════════════ */
static void stft_forward_full(const float *audio, uint32_t nsamp,
                               float *mag, float *phase, uint32_t *nf_out) {
    ensure_window();
    uint32_t nf = 0;
    for (uint32_t start = 0; start + FFT_SIZE <= nsamp; start += HOP_SIZE) {
        float re[FFT_SIZE], im[FFT_SIZE];
        for (int i = 0; i < FFT_SIZE; i++) {
            re[i] = audio[start + i] * ana_win[i];
            im[i] = 0.0f;
        }
        fft(re, im, FFT_SIZE, 0);
        for (int k = 0; k < FREQ_BINS; k++) {
            mag[nf * FREQ_BINS + k] = sqrtf(re[k] * re[k] + im[k] * im[k]);
            phase[nf * FREQ_BINS + k] = atan2f(im[k], re[k]);
        }
        nf++;
    }
    *nf_out = nf;
}

/* ═══════════════════════════════════════════
 *  iSTFT — Uses stored phase (no vocoder needed)
 * ═══════════════════════════════════════════ */
static void istft_from_phase(const float *mag, const float *phase,
                              uint32_t nf, float *audio, uint32_t nsamp) {
    ensure_window();
    float *wsum = (float *)calloc(nsamp, sizeof(float));
    memset(audio, 0, nsamp * sizeof(float));

    for (uint32_t f = 0; f < nf; f++) {
        float re[FFT_SIZE], im[FFT_SIZE];
        for (int k = 0; k < FREQ_BINS; k++) {
            float m = mag[f * FREQ_BINS + k];
            float p = phase[f * FREQ_BINS + k];
            re[k] = m * cosf(p);
            im[k] = m * sinf(p);
        }
        /* Mirror for real-valued iFFT */
        for (int k = FREQ_BINS; k < FFT_SIZE; k++) {
            re[k] =  re[FFT_SIZE - k];
            im[k] = -im[FFT_SIZE - k];
        }
        fft(re, im, FFT_SIZE, 1);

        uint32_t start = f * HOP_SIZE;
        for (int i = 0; i < FFT_SIZE && start + i < nsamp; i++) {
            audio[start + i] += re[i] * ana_win[i];  /* synthesis window */
            wsum[start + i]  += ana_win[i] * ana_win[i];
        }
    }
    /* Normalize by window sum (COLA) with safe floor */
    for (uint32_t i = 0; i < nsamp; i++) {
        if (wsum[i] > 0.01f) audio[i] /= wsum[i];
    }
    free(wsum);
}

/* ═══════════════════════════════════════════
 *  Phase Deviation Encoding
 *
 *  expected_phase[k] = prev_phase[k] + 2π × k × HOP / FFT
 *  deviation = actual_phase - expected_phase (wrapped to [-π, π])
 *  Quantize deviation to 8-bit: [0, 255] → [-π, π]
 * ═══════════════════════════════════════════ */
static float wrap_phase(float p) {
    while (p > (float)M_PI) p -= 2.0f * (float)M_PI;
    while (p < -(float)M_PI) p += 2.0f * (float)M_PI;
    return p;
}

static uint8_t encode_phase_dev(float dev) {
    /* dev ∈ [-π, π] → [0, 15] (4-bit) */
    float normalized = (dev + (float)M_PI) / (2.0f * (float)M_PI);
    if (normalized < 0) normalized = 0;
    if (normalized > 1) normalized = 1;
    return (uint8_t)(normalized * 15.0f + 0.5f);
}

static float decode_phase_dev(uint8_t v) {
    /* [0, 15] → [-π, π] */
    return ((float)(v & 0x0F) / 15.0f) * 2.0f * (float)M_PI - (float)M_PI;
}

/* ═══════════════════════════════════════════
 *  Dictionary Builder (unchanged conceptually)
 * ═══════════════════════════════════════════ */
static float vec_norm(const float *v, int n) {
    double sum = 0;
    for (int i = 0; i < n; i++) sum += (double)v[i] * v[i];
    return (float)sqrt(sum);
}

static float cosine_sim(const float *a, const float *b, int n) {
    double dot = 0, na = 0, nb = 0;
    for (int i = 0; i < n; i++) {
        dot += (double)a[i] * b[i];
        na  += (double)a[i] * a[i];
        nb  += (double)b[i] * b[i];
    }
    double denom = sqrt(na) * sqrt(nb);
    if (denom < 1e-12) return 0.0f;
    return (float)(dot / denom);
}

typedef struct {
    float *entries;     /* dict_size × FREQ_BINS */
    float *norms;       /* dict_size — precomputed L2 norms */
    int size;
    int capacity;
} dict_t;

static void dict_init(dict_t *d, int cap) {
    d->entries = (float *)malloc(cap * FREQ_BINS * sizeof(float));
    d->norms = (float *)malloc(cap * sizeof(float));
    d->size = 0;
    d->capacity = cap;
}

static int dict_add(dict_t *d, const float *frame) {
    if (d->size >= d->capacity) return d->size - 1;
    int idx = d->size;
    memcpy(d->entries + idx * FREQ_BINS, frame, FREQ_BINS * sizeof(float));
    d->norms[idx] = vec_norm(frame, FREQ_BINS);
    d->size++;
    return idx;
}

/* Per-band gains: compute gain for each of NUM_BANDS frequency bands */
static void compute_band_gains(const float *frame, const float *dict_entry,
                                float *band_gains) {
    for (int b = 0; b < NUM_BANDS; b++) {
        int lo = BAND_EDGES[b], hi = BAND_EDGES[b + 1];
        float frame_energy = 0, dict_energy = 0;
        for (int k = lo; k < hi; k++) {
            frame_energy += frame[k] * frame[k];
            dict_energy += dict_entry[k] * dict_entry[k];
        }
        frame_energy = sqrtf(frame_energy);
        dict_energy = sqrtf(dict_energy);
        band_gains[b] = (dict_energy > 1e-6f) ? (frame_energy / dict_energy) : 0.0f;
    }
}

static int dict_find_best(const dict_t *d, const float *frame, float *band_gains) {
    float frame_norm = vec_norm(frame, FREQ_BINS);
    if (frame_norm < 1e-6f) {
        for (int b = 0; b < NUM_BANDS; b++) band_gains[b] = 0.0f;
        return 0;
    }

    int best_idx = -1;
    float best_sim = -1.0f;

    for (int i = 0; i < d->size; i++) {
        float sim = cosine_sim(frame, d->entries + i * FREQ_BINS, FREQ_BINS);
        if (sim > best_sim) {
            best_sim = sim;
            best_idx = i;
        }
    }

    if (best_sim >= SIM_THRESH && best_idx >= 0) {
        compute_band_gains(frame, d->entries + best_idx * FREQ_BINS, band_gains);
        return best_idx;
    }

    /* No match: add new entry */
    for (int b = 0; b < NUM_BANDS; b++) band_gains[b] = 1.0f;
    return dict_add((dict_t *)d, frame);
}

static void dict_free(dict_t *d) {
    free(d->entries); free(d->norms);
    d->entries = NULL; d->norms = NULL;
    d->size = 0;
}

/* ═══════════════════════════════════════════
 *  Quantization helpers — Log-scale for magnitudes
 * ═══════════════════════════════════════════ */
/* Log-scale: better for perceptual audio (more bits for quiet parts) */
static uint16_t mag_to_u16_log(float v, float mx) {
    if (mx < 1e-10f || v <= 0) return 0;
    /* log(1 + v/mx * 1023) / log(1024) → [0, 1] → × 65535 */
    float ratio = v / mx;
    if (ratio > 1.0f) ratio = 1.0f;
    float logval = log2f(1.0f + ratio * 1023.0f) / 10.0f;  /* log2(1024) = 10 */
    return (uint16_t)(logval * 65535.0f);
}

static float u16_to_mag_log(uint16_t v, float mx) {
    float logval = (float)v / 65535.0f;
    float ratio = (powf(2.0f, logval * 10.0f) - 1.0f) / 1023.0f;
    return ratio * mx;
}

/* Log-scale gain encoding: 16-bit */
static uint16_t encode_gain(float g) {
    if (g <= 0) return 0;
    float lg = log2f(g + 1e-6f) + 10.0f;
    if (lg < 0) lg = 0;
    if (lg > 17.0f) lg = 17.0f;
    return (uint16_t)(lg / 17.0f * 65535.0f);
}

static float decode_gain(uint16_t v) {
    float lg = ((float)v / 65535.0f) * 17.0f;
    return powf(2.0f, lg - 10.0f);
}

/* ═══════════════════════════════════════════
 *  ENCODER v5
 * ═══════════════════════════════════════════ */
int qtsq_compress_audio(qtsq_context_t *ctx, const int16_t *samples,
                        size_t num_samples, uint32_t sample_rate,
                        uint8_t channels) {
    if (!ctx || !samples) return QTSQ_ERR_NULL;
    if (num_samples == 0) return QTSQ_ERR_TOO_SMALL;
    if (channels == 0) channels = 1;
    if (channels > 2) channels = 2;
    uint32_t spc = (uint32_t)(num_samples / channels);

    /* Mid/Side split */
    float *mid  = (float *)malloc(spc * sizeof(float));
    float *side = (float *)malloc(spc * sizeof(float));
    if (!mid || !side) { free(mid); free(side); return QTSQ_ERR_ALLOC; }

    if (channels >= 2) {
        for (uint32_t i = 0; i < spc; i++) {
            float L = (float)samples[i * 2], R = (float)samples[i * 2 + 1];
            mid[i]  = (L + R) * 0.5f;
            side[i] = (L - R) * 0.5f;
        }
    } else {
        for (uint32_t i = 0; i < spc; i++) mid[i] = (float)samples[i];
        memset(side, 0, spc * sizeof(float));
    }

    /* STFT → magnitude + phase frames */
    uint32_t max_fr = (spc / HOP_SIZE) + 2;
    float *mid_mag   = (float *)calloc(max_fr * FREQ_BINS, sizeof(float));
    float *mid_phase  = (float *)calloc(max_fr * FREQ_BINS, sizeof(float));
    float *side_mag  = (float *)calloc(max_fr * FREQ_BINS, sizeof(float));
    float *side_phase = (float *)calloc(max_fr * FREQ_BINS, sizeof(float));
    if (!mid_mag || !mid_phase || !side_mag || !side_phase) {
        free(mid); free(side);
        free(mid_mag); free(mid_phase); free(side_mag); free(side_phase);
        return QTSQ_ERR_ALLOC;
    }

    uint32_t nf, snf;
    stft_forward_full(mid, spc, mid_mag, mid_phase, &nf);
    stft_forward_full(side, spc, side_mag, side_phase, &snf);
    free(mid); free(side);

    /* ─── Compute phase deviations (only for low-freq bins 0..PHASE_BINS-1) ─── */
    float *phase_inc = (float *)malloc(PHASE_BINS * sizeof(float));
    for (int k = 0; k < PHASE_BINS; k++)
        phase_inc[k] = 2.0f * (float)M_PI * (float)k * (float)HOP_SIZE / (float)FFT_SIZE;

    /* Pack 2 × 4-bit values per byte → PHASE_BINS/2 bytes per frame */
    uint32_t phase_bytes_per_frame = (PHASE_BINS + 1) / 2;
    uint8_t *mid_phase_packed  = (uint8_t *)calloc(nf * phase_bytes_per_frame, 1);
    uint8_t *side_phase_packed = (uint8_t *)calloc(nf * phase_bytes_per_frame, 1);
    float *prev_mid_phase  = (float *)calloc(PHASE_BINS, sizeof(float));
    float *prev_side_phase = (float *)calloc(PHASE_BINS, sizeof(float));

    for (uint32_t f = 0; f < nf; f++) {
        for (int k = 0; k < PHASE_BINS; k++) {
            float expected_mid  = prev_mid_phase[k] + phase_inc[k];
            float dev_mid = wrap_phase(mid_phase[f * FREQ_BINS + k] - expected_mid);
            uint8_t qm = encode_phase_dev(dev_mid);
            prev_mid_phase[k] = mid_phase[f * FREQ_BINS + k];

            float expected_side = prev_side_phase[k] + phase_inc[k];
            float dev_side = wrap_phase(side_phase[f * FREQ_BINS + k] - expected_side);
            uint8_t qs = encode_phase_dev(dev_side);
            prev_side_phase[k] = side_phase[f * FREQ_BINS + k];

            /* Pack 2 nibbles into 1 byte */
            uint32_t byte_idx = f * phase_bytes_per_frame + (k / 2);
            if (k % 2 == 0) {
                mid_phase_packed[byte_idx]  = (qm << 4);
                side_phase_packed[byte_idx] = (qs << 4);
            } else {
                mid_phase_packed[byte_idx]  |= (qm & 0x0F);
                side_phase_packed[byte_idx] |= (qs & 0x0F);
            }
        }
    }
    free(phase_inc); free(prev_mid_phase); free(prev_side_phase);
    free(mid_phase); free(side_phase);

    /* ─── Build dictionaries with per-band gains ─── */
    dict_t mid_dict, side_dict;
    dict_init(&mid_dict, MAX_DICT);
    dict_init(&side_dict, MAX_DICT);

    uint16_t *mid_indices  = (uint16_t *)malloc(nf * sizeof(uint16_t));
    uint16_t *mid_bgains   = (uint16_t *)malloc(nf * NUM_BANDS * sizeof(uint16_t));
    uint16_t *side_indices = (uint16_t *)malloc(nf * sizeof(uint16_t));
    uint16_t *side_bgains  = (uint16_t *)malloc(nf * NUM_BANDS * sizeof(uint16_t));

    dict_add(&mid_dict, mid_mag);  /* seed */
    dict_add(&side_dict, side_mag);

    for (uint32_t f = 0; f < nf; f++) {
        float mg[NUM_BANDS], sg[NUM_BANDS];
        int mi = dict_find_best(&mid_dict, mid_mag + f * FREQ_BINS, mg);
        int si = dict_find_best(&side_dict, side_mag + f * FREQ_BINS, sg);
        mid_indices[f]  = (uint16_t)mi;
        side_indices[f] = (uint16_t)si;
        for (int b = 0; b < NUM_BANDS; b++) {
            mid_bgains[f * NUM_BANDS + b]  = encode_gain(mg[b]);
            side_bgains[f * NUM_BANDS + b] = encode_gain(sg[b]);
        }
    }
    free(mid_mag); free(side_mag);

    /* ─── Pack v5 format ─── */
    /* Find max values for log quantization */
    float mid_dict_max = 0, side_dict_max = 0;
    for (int i = 0; i < mid_dict.size * FREQ_BINS; i++)
        if (mid_dict.entries[i] > mid_dict_max) mid_dict_max = mid_dict.entries[i];
    for (int i = 0; i < side_dict.size * FREQ_BINS; i++)
        if (side_dict.entries[i] > side_dict_max) side_dict_max = side_dict.entries[i];

    /* v5 header: magic(4) + spc(4) + sr(4) + nf(4) + md_sz(2) + sd_sz(2)
     *          + ch(1) + num_bands(1) + md_max(4) + sd_max(4) = 30 bytes */
    size_t phase_total = nf * phase_bytes_per_frame;  /* per channel */
    size_t packed_sz = 30 +
                       mid_dict.size * FREQ_BINS * 2 +    /* mid dict (16-bit log) */
                       side_dict.size * FREQ_BINS * 2 +   /* side dict (16-bit log) */
                       nf * 2 +                            /* mid indices */
                       nf * NUM_BANDS * 2 +                /* mid band gains */
                       nf * 2 +                            /* side indices */
                       nf * NUM_BANDS * 2 +                /* side band gains */
                       phase_total +                        /* mid phase (4-bit packed) */
                       phase_total;                         /* side phase (4-bit packed) */

    uint8_t *packed = (uint8_t *)malloc(packed_sz);
    if (!packed) {
        dict_free(&mid_dict); dict_free(&side_dict);
        free(mid_indices); free(mid_bgains); free(side_indices); free(side_bgains);
        free(mid_phase_packed); free(side_phase_packed);
        return QTSQ_ERR_ALLOC;
    }

    size_t p = 0;
    /* v5 magic to distinguish from v4 */
    packed[p++] = 'S'; packed[p++] = 'D'; packed[p++] = 'v'; packed[p++] = '5';
    memcpy(packed + p, &spc, 4); p += 4;
    memcpy(packed + p, &sample_rate, 4); p += 4;
    memcpy(packed + p, &nf, 4); p += 4;
    uint16_t md_sz = (uint16_t)mid_dict.size, sd_sz = (uint16_t)side_dict.size;
    memcpy(packed + p, &md_sz, 2); p += 2;
    memcpy(packed + p, &sd_sz, 2); p += 2;
    packed[p++] = channels;
    packed[p++] = (uint8_t)NUM_BANDS;
    memcpy(packed + p, &mid_dict_max, 4); p += 4;
    memcpy(packed + p, &side_dict_max, 4); p += 4;

    /* Mid dictionary: 16-bit log-quantized */
    for (int i = 0; i < mid_dict.size * FREQ_BINS; i++) {
        uint16_t v = mag_to_u16_log(mid_dict.entries[i], mid_dict_max);
        packed[p++] = v >> 8; packed[p++] = v & 0xFF;
    }
    /* Side dictionary */
    for (int i = 0; i < side_dict.size * FREQ_BINS; i++) {
        uint16_t v = mag_to_u16_log(side_dict.entries[i], side_dict_max);
        packed[p++] = v >> 8; packed[p++] = v & 0xFF;
    }

    /* Mid timeline: indices + per-band gains */
    for (uint32_t f = 0; f < nf; f++) {
        packed[p++] = mid_indices[f] >> 8; packed[p++] = mid_indices[f] & 0xFF;
    }
    for (uint32_t f = 0; f < nf; f++) {
        for (int b = 0; b < NUM_BANDS; b++) {
            uint16_t g = mid_bgains[f * NUM_BANDS + b];
            packed[p++] = g >> 8; packed[p++] = g & 0xFF;
        }
    }
    /* Side timeline */
    for (uint32_t f = 0; f < nf; f++) {
        packed[p++] = side_indices[f] >> 8; packed[p++] = side_indices[f] & 0xFF;
    }
    for (uint32_t f = 0; f < nf; f++) {
        for (int b = 0; b < NUM_BANDS; b++) {
            uint16_t g = side_bgains[f * NUM_BANDS + b];
            packed[p++] = g >> 8; packed[p++] = g & 0xFF;
        }
    }

    /* Phase deviations (4-bit packed, PHASE_BINS bins only) */
    memcpy(packed + p, mid_phase_packed, phase_total); p += phase_total;
    memcpy(packed + p, side_phase_packed, phase_total); p += phase_total;

    dict_free(&mid_dict); dict_free(&side_dict);
    free(mid_indices); free(mid_bgains); free(side_indices); free(side_bgains);
    free(mid_phase_packed); free(side_phase_packed);

    /* zlib compress */
    uLongf zb = compressBound((uLong)p);
    uint8_t *zd = (uint8_t *)malloc(zb);
    if (!zd) { free(packed); return QTSQ_ERR_ALLOC; }
    uLongf zs = zb;
    if (compress2(zd, &zs, packed, (uLong)p, 9) != Z_OK) {
        free(packed); free(zd); return QTSQ_ERR_ALLOC;
    }
    free(packed);

    size_t total = 4 + (size_t)zs;
    uint8_t *out = (uint8_t *)malloc(total);
    if (!out) { free(zd); return QTSQ_ERR_ALLOC; }
    uint32_t ps32 = (uint32_t)p;
    memcpy(out, &ps32, 4);
    memcpy(out + 4, zd, zs);
    free(zd);

    if (ctx->singularity) free(ctx->singularity);
    ctx->singularity = out;
    ctx->singularity_size = total;
    ctx->header.strategy = QTSQ_STRATEGY_FOURIER;
    ctx->header.data_type = (channels >= 2) ? QTSQ_TYPE_AUDIO_STEREO : QTSQ_TYPE_AUDIO_MONO;
    ctx->header.original_size = num_samples * sizeof(int16_t);
    ctx->header.num_channels = channels;
    ctx->header.sample_depth = 16;
    ctx->header.singularity_size = ctx->singularity_size;
    ctx->header.flags |= QTSQ_FLAG_LOSSY | QTSQ_FLAG_CHECKSUMMED;
    memset(&ctx->schema, 0, sizeof(qtsq_schema_t));
    strncpy(ctx->schema.name, "audio_dictionary", 63);
    ctx->schema.data_type = ctx->header.data_type;
    ctx->schema.dimensions[0] = spc;
    ctx->schema.num_dims = 1;
    ctx->schema.sample_rate = sample_rate;
    strncpy(ctx->schema.encoding, "SPEC_DICTIONARY", 63);
    ctx->header.horizon_size = sizeof(qtsq_schema_t);
    qtsq_sha256((const uint8_t *)samples, num_samples * sizeof(int16_t), ctx->header.checksum);
    return QTSQ_OK;
}

int qtsq_compress_signal(qtsq_context_t *ctx, const double *sig, size_t n) {
    if (!ctx || !sig) return QTSQ_ERR_NULL;
    if (n == 0) return QTSQ_ERR_TOO_SMALL;
    int16_t *s = (int16_t *)malloc(n * sizeof(int16_t));
    if (!s) return QTSQ_ERR_ALLOC;
    double mx = 0;
    for (size_t i = 0; i < n; i++) { double a = fabs(sig[i]); if (a > mx) mx = a; }
    if (mx == 0) mx = 1;
    for (size_t i = 0; i < n; i++) s[i] = (int16_t)(sig[i] / mx * 32767.0);
    int r = qtsq_compress_audio(ctx, s, n, 1, 1);
    free(s);
    if (r == QTSQ_OK) ctx->header.data_type = QTSQ_TYPE_SIGNAL_1D;
    return r;
}

/* ═══════════════════════════════════════════
 *  DECODER v5 — Dictionary + Phase Reconstruction
 * ═══════════════════════════════════════════ */
int qtsq_decompress_lensing(const qtsq_context_t *ctx,
                            uint8_t **out_data, size_t *out_size) {
    if (!ctx || !out_data || !out_size) return QTSQ_ERR_NULL;
    if (!ctx->singularity || ctx->singularity_size < 8) return QTSQ_ERR_FORMAT;

    const uint8_t *buf = ctx->singularity;
    uint32_t packed_sz;
    memcpy(&packed_sz, buf, 4);

    uint8_t *packed = (uint8_t *)malloc(packed_sz);
    if (!packed) return QTSQ_ERR_ALLOC;
    uLongf dl = (uLongf)packed_sz;
    if (uncompress(packed, &dl, buf + 4, (uLong)(ctx->singularity_size - 4)) != Z_OK) {
        free(packed); return QTSQ_ERR_FORMAT;
    }

    size_t p = 0;

    /* Check for v5 magic */
    int is_v5 = (packed[0] == 'S' && packed[1] == 'D' &&
                 packed[2] == 'v' && packed[3] == '5');

    uint32_t spc, sr, nf;
    uint16_t md_sz, sd_sz;
    uint8_t ch;
    uint8_t num_bands = 1;  /* v4 default: 1 global gain */
    float mid_dict_max, side_dict_max;

    if (is_v5) {
        p = 4; /* skip magic */
        memcpy(&spc, packed + p, 4); p += 4;
        memcpy(&sr, packed + p, 4); p += 4;
        memcpy(&nf, packed + p, 4); p += 4;
        memcpy(&md_sz, packed + p, 2); p += 2;
        memcpy(&sd_sz, packed + p, 2); p += 2;
        ch = packed[p++]; if (ch < 1) ch = 1; if (ch > 2) ch = 2;
        num_bands = packed[p++]; if (num_bands < 1) num_bands = 1; if (num_bands > 16) num_bands = 16;
        memcpy(&mid_dict_max, packed + p, 4); p += 4;
        memcpy(&side_dict_max, packed + p, 4); p += 4;
    } else {
        /* v4 backward compat */
        memcpy(&spc, packed + p, 4); p += 4;
        memcpy(&sr, packed + p, 4); p += 4;
        memcpy(&nf, packed + p, 4); p += 4;
        memcpy(&md_sz, packed + p, 2); p += 2;
        memcpy(&sd_sz, packed + p, 2); p += 2;
        ch = packed[p++]; if (ch < 1) ch = 1; if (ch > 2) ch = 2;
        memcpy(&mid_dict_max, packed + p, 4); p += 4;
        memcpy(&side_dict_max, packed + p, 4); p += 4;
    }

    int fb = FREQ_BINS;

    /* Read dictionaries */
    float *mid_dict = (float *)malloc(md_sz * fb * sizeof(float));
    float *side_dict = (float *)malloc(sd_sz * fb * sizeof(float));
    if (!mid_dict || !side_dict) {
        free(packed); free(mid_dict); free(side_dict);
        return QTSQ_ERR_ALLOC;
    }

    for (int i = 0; i < md_sz * fb; i++) {
        uint16_t v = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
        mid_dict[i] = is_v5 ? u16_to_mag_log(v, mid_dict_max)
                            : ((float)v / 65535.0f) * mid_dict_max; /* v4 linear */
    }
    for (int i = 0; i < sd_sz * fb; i++) {
        uint16_t v = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
        side_dict[i] = is_v5 ? u16_to_mag_log(v, side_dict_max)
                             : ((float)v / 65535.0f) * side_dict_max;
    }

    /* Read timelines */
    uint16_t *m_idx = (uint16_t *)malloc(nf * sizeof(uint16_t));
    uint16_t *s_idx = (uint16_t *)malloc(nf * sizeof(uint16_t));
    uint16_t *m_bgains = (uint16_t *)calloc(nf * num_bands, sizeof(uint16_t));
    uint16_t *s_bgains = (uint16_t *)calloc(nf * num_bands, sizeof(uint16_t));

    for (uint32_t f = 0; f < nf; f++) {
        m_idx[f] = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
    }
    if (is_v5) {
        /* v5: per-band gains */
        for (uint32_t f = 0; f < nf; f++) {
            for (int b = 0; b < num_bands; b++) {
                m_bgains[f * num_bands + b] = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
            }
        }
    } else {
        /* v4: single gain per frame */
        for (uint32_t f = 0; f < nf; f++) {
            uint16_t g = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
            for (int b = 0; b < num_bands; b++) m_bgains[f * num_bands + b] = g;
        }
    }

    for (uint32_t f = 0; f < nf; f++) {
        s_idx[f] = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
    }
    if (is_v5) {
        for (uint32_t f = 0; f < nf; f++) {
            for (int b = 0; b < num_bands; b++) {
                s_bgains[f * num_bands + b] = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
            }
        }
    } else {
        for (uint32_t f = 0; f < nf; f++) {
            uint16_t g = ((uint16_t)packed[p] << 8) | packed[p + 1]; p += 2;
            for (int b = 0; b < num_bands; b++) s_bgains[f * num_bands + b] = g;
        }
    }

    /* Phase deviations (v5 only — 4-bit packed, PHASE_BINS bins) */
    uint32_t phase_bytes_per_frame_dec = (PHASE_BINS + 1) / 2;
    uint32_t phase_total_dec = nf * phase_bytes_per_frame_dec;
    uint8_t *mid_phase_packed = NULL, *side_phase_packed = NULL;
    if (is_v5) {
        mid_phase_packed = (uint8_t *)malloc(phase_total_dec);
        side_phase_packed = (uint8_t *)malloc(phase_total_dec);
        memcpy(mid_phase_packed, packed + p, phase_total_dec); p += phase_total_dec;
        memcpy(side_phase_packed, packed + p, phase_total_dec); p += phase_total_dec;
    }
    free(packed);

    /* Resolve band edges for this num_bands */
    int band_edges_dec[17]; /* max 16 bands + 1 edge */
    if (num_bands == NUM_BANDS) {
        for (int i = 0; i <= NUM_BANDS; i++) band_edges_dec[i] = BAND_EDGES[i];
    } else {
        /* Uniform split fallback */
        for (int i = 0; i <= num_bands; i++)
            band_edges_dec[i] = (int)((float)i / num_bands * fb);
    }

    /* Reconstruct magnitude spectrograms with per-band gains */
    float *mid_mag  = (float *)calloc(nf * fb, sizeof(float));
    float *side_mag = (float *)calloc(nf * fb, sizeof(float));
    if (!mid_mag || !side_mag) {
        free(mid_dict); free(side_dict);
        free(m_idx); free(s_idx); free(m_bgains); free(s_bgains);
        free(mid_phase_packed); free(side_phase_packed);
        free(mid_mag); free(side_mag);
        return QTSQ_ERR_ALLOC;
    }

    for (uint32_t f = 0; f < nf; f++) {
        int mi = m_idx[f];
        if (mi < md_sz) {
            for (int b = 0; b < num_bands; b++) {
                float mg = decode_gain(m_bgains[f * num_bands + b]);
                int lo = band_edges_dec[b], hi = band_edges_dec[b + 1];
                for (int k = lo; k < hi && k < fb; k++)
                    mid_mag[f * fb + k] = mid_dict[mi * fb + k] * mg;
            }
        }

        int si = s_idx[f];
        if (si < sd_sz) {
            for (int b = 0; b < num_bands; b++) {
                float sg = decode_gain(s_bgains[f * num_bands + b]);
                int lo = band_edges_dec[b], hi = band_edges_dec[b + 1];
                for (int k = lo; k < hi && k < fb; k++)
                    side_mag[f * fb + k] = side_dict[si * fb + k] * sg;
            }
        }
    }
    free(mid_dict); free(side_dict);
    free(m_idx); free(s_idx); free(m_bgains); free(s_bgains);

    /* Reconstruct phase */
    float *mid_phase_out  = (float *)calloc(nf * fb, sizeof(float));
    float *side_phase_out = (float *)calloc(nf * fb, sizeof(float));

    if (is_v5 && mid_phase_packed && side_phase_packed) {
        /* v5: reconstruct low-freq phase from stored deviations,
         * synthesize high-freq phase via standard advance */
        float *phase_inc = (float *)malloc(fb * sizeof(float));
        for (int k = 0; k < fb; k++)
            phase_inc[k] = 2.0f * (float)M_PI * (float)k * (float)HOP_SIZE / (float)FFT_SIZE;

        float *prev_mid  = (float *)calloc(fb, sizeof(float));
        float *prev_side = (float *)calloc(fb, sizeof(float));

        for (uint32_t f = 0; f < nf; f++) {
            /* Low-frequency bins: use stored phase deviations */
            for (int k = 0; k < PHASE_BINS && k < fb; k++) {
                uint32_t byte_idx = f * phase_bytes_per_frame_dec + (k / 2);
                uint8_t nibble_m, nibble_s;
                if (k % 2 == 0) {
                    nibble_m = (mid_phase_packed[byte_idx] >> 4) & 0x0F;
                    nibble_s = (side_phase_packed[byte_idx] >> 4) & 0x0F;
                } else {
                    nibble_m = mid_phase_packed[byte_idx] & 0x0F;
                    nibble_s = side_phase_packed[byte_idx] & 0x0F;
                }

                float expected_mid = prev_mid[k] + phase_inc[k];
                float dev_mid = decode_phase_dev(nibble_m);
                mid_phase_out[f * fb + k] = expected_mid + dev_mid;
                prev_mid[k] = mid_phase_out[f * fb + k];

                float expected_side = prev_side[k] + phase_inc[k];
                float dev_side = decode_phase_dev(nibble_s);
                side_phase_out[f * fb + k] = expected_side + dev_side;
                prev_side[k] = side_phase_out[f * fb + k];
            }
            /* High-frequency bins: standard phase advance (vocoder) */
            for (int k = PHASE_BINS; k < fb; k++) {
                mid_phase_out[f * fb + k] = prev_mid[k] + phase_inc[k];
                prev_mid[k] = mid_phase_out[f * fb + k];
                side_phase_out[f * fb + k] = prev_side[k] + phase_inc[k];
                prev_side[k] = side_phase_out[f * fb + k];
            }
        }
        free(phase_inc); free(prev_mid); free(prev_side);
    } else {
        /* v4 fallback: phase vocoder (synthesized phase) */
        float *phase_inc = (float *)malloc(fb * sizeof(float));
        for (int k = 0; k < fb; k++)
            phase_inc[k] = 2.0f * (float)M_PI * (float)k * (float)HOP_SIZE / (float)FFT_SIZE;

        float *cur_phase = (float *)calloc(fb, sizeof(float));
        for (uint32_t f = 0; f < nf; f++) {
            for (int k = 0; k < fb; k++) {
                mid_phase_out[f * fb + k] = cur_phase[k];
                side_phase_out[f * fb + k] = cur_phase[k];
                cur_phase[k] += phase_inc[k];
            }
        }
        free(phase_inc); free(cur_phase);
    }
    free(mid_phase_packed); free(side_phase_packed);

    /* iSTFT synthesis using stored/reconstructed phase */
    float *mid_audio  = (float *)calloc(spc, sizeof(float));
    float *side_audio = (float *)calloc(spc, sizeof(float));
    if (!mid_audio || !side_audio) {
        free(mid_mag); free(side_mag);
        free(mid_phase_out); free(side_phase_out);
        free(mid_audio); free(side_audio);
        return QTSQ_ERR_ALLOC;
    }

    istft_from_phase(mid_mag, mid_phase_out, nf, mid_audio, spc);
    istft_from_phase(side_mag, side_phase_out, nf, side_audio, spc);
    free(mid_mag); free(side_mag);
    free(mid_phase_out); free(side_phase_out);

    /* Build stereo WAV */
    uint16_t out_ch = (ch >= 2) ? 2 : 1;
    uint32_t pcm_bytes = spc * out_ch * 2;
    uint32_t wav_size = 44 + pcm_bytes;
    uint8_t *wav = (uint8_t *)malloc(wav_size);
    if (!wav) { free(mid_audio); free(side_audio); return QTSQ_ERR_ALLOC; }

    uint32_t fsz = wav_size - 8, brate = sr * out_ch * 2, fc = 16;
    uint16_t af = 1, ba = out_ch * 2, bits = 16;
    memcpy(wav, "RIFF", 4);       memcpy(wav + 4, &fsz, 4);
    memcpy(wav + 8, "WAVE", 4);   memcpy(wav + 12, "fmt ", 4);
    memcpy(wav + 16, &fc, 4);     memcpy(wav + 20, &af, 2);
    memcpy(wav + 22, &out_ch, 2); memcpy(wav + 24, &sr, 4);
    memcpy(wav + 28, &brate, 4);  memcpy(wav + 32, &ba, 2);
    memcpy(wav + 34, &bits, 2);   memcpy(wav + 36, "data", 4);
    memcpy(wav + 40, &pcm_bytes, 4);

    int16_t *pcm = (int16_t *)(wav + 44);
    for (uint32_t i = 0; i < spc; i++) {
        float m = mid_audio[i], s = side_audio[i];
        float L = m + s, R = m - s;
        if (L > 32767) L = 32767; if (L < -32768) L = -32768;
        if (R > 32767) R = 32767; if (R < -32768) R = -32768;
        if (out_ch == 2) {
            pcm[i * 2] = (int16_t)L; pcm[i * 2 + 1] = (int16_t)R;
        } else pcm[i] = (int16_t)m;
    }
    free(mid_audio); free(side_audio);

    *out_data = wav;
    *out_size = wav_size;
    return QTSQ_OK;
}
