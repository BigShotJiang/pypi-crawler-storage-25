#include "qtsq.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <zlib.h>

#include "qtsq_splat2d.h"
#ifdef __APPLE__
#include "qtsq_metal.h"
#endif

struct qtsq_video_decoder {
    const qtsq_context_t *ctx;
    uint32_t width;
    uint32_t height;
    uint8_t channels;
    
    uint32_t frame_count;
    uint32_t *frame_offsets;
    uint32_t *frame_sizes;
    uint8_t  *frame_types;
    
    const uint8_t *bitstream;
    size_t bitstream_size;
    
    /* Ring buffer (capacity 3) for output frames */
    uint8_t *ring_buffers[3];
    uint32_t ring_head;
    size_t   ring_buffer_size;
    
    /* Reference frame: last decoded I-frame for P-frame reconstruction */
    uint8_t *ref_frame;
    int has_ref_frame;
    uint32_t last_iframe_index; /* track which I-frame is loaded */
    
    /* Reference splat buffer: cached I-frame splat data for P-frame delta application */
    uint8_t *ref_splat_raw;       /* working copy: modified by P-frame deltas for rendering */
    uint8_t *ref_splat_original;  /* pristine I-frame copy: never modified after caching */
    uint32_t ref_splat_count;
    
    /* Scene segment cache: avoid decompressing same segment on every frame */
    uint32_t  cached_seg_offset;   /* bitstream offset of cached segment (UINT32_MAX = none) */
    uint8_t  *cached_seg_body;     /* decompressed body data */
    size_t    cached_seg_body_size;
    uint32_t  cached_seg_num_splats;
    uint32_t  cached_seg_num_static;
    uint32_t  cached_seg_num_dynamic;
    uint16_t  cached_seg_frames;
    uint8_t   cached_seg_num_kf;
    uint8_t   cached_seg_kf_interval;
    uint32_t  cached_seg_start;    /* first frame index of this segment */
    
    /* ── Persistent Video Render Cache ──
     * Pre-allocated once, reused for all frames in the segment.
     * Eliminates per-frame calloc/free and Metal buffer allocation. */
    splat2d_t *render_splats;         /* persistent splat array (positions set once, only colors updated) */
    uint32_t   render_splat_capacity; /* allocated capacity */
    uint8_t   *render_output;         /* persistent output pixel buffer */
    size_t     render_output_size;
    int        render_positions_set;  /* 1 if positions are already filled from cached segment */
    
    /* ── Hybrid Triangle+Splat Render Cache ── */
    tri_vertex_t *hybrid_verts;       /* persistent vertex array */
    uint32_t      hybrid_vert_count;
    tri_face_t   *hybrid_faces;       /* persistent face array */
    uint32_t      hybrid_face_count;
    splat2d_t    *hybrid_splats;      /* persistent splat array for hybrid */
    uint32_t      hybrid_splat_count;
    
    /* Cached HSCN segment data (parsed pointers into cached_seg_body) */
    uint32_t  cached_hybrid_num_verts;
    uint32_t  cached_hybrid_num_faces;
    uint32_t  cached_hybrid_num_splats;
    uint32_t  cached_hybrid_num_static_verts;
    uint32_t  cached_hybrid_num_static_splats;
    int       hybrid_geometry_set;    /* 1 if faces are loaded from segment */
};

/* ── RLE decoder for P-frame delta ──
 * Format matches the encoder:
 * [0xFF][high][low] = skip N unchanged pixels (all channels = 128)
 * [0xFE][ch0][ch1][ch2] = one changed pixel with biased delta values
 */
static int rle_decode_delta(const uint8_t *rle, size_t rle_size, uint8_t *delta, size_t delta_cap, uint8_t ch) {
    size_t ri = 0;
    size_t di = 0;
    
    while (ri < rle_size && di < delta_cap) {
        uint8_t marker = rle[ri++];
        
        if (marker == 0xFF) {
            /* Unchanged run */
            if (ri + 2 > rle_size) return -1;
            uint16_t run = ((uint16_t)rle[ri] << 8) | rle[ri + 1];
            ri += 2;
            
            for (uint16_t p = 0; p < run && di + ch <= delta_cap; p++) {
                for (uint8_t c = 0; c < ch; c++) {
                    delta[di++] = 128; /* no change */
                }
            }
        } else if (marker == 0xFE) {
            /* Raw changed pixel */
            if (ri + ch > rle_size || di + ch > delta_cap) return -1;
            for (uint8_t c = 0; c < ch; c++) {
                delta[di++] = rle[ri++];
            }
        } else {
            /* Legacy: raw byte (shouldn't happen with new encoder, but handle gracefully) */
            if (di < delta_cap) {
                delta[di++] = marker;
            }
        }
    }
    return 0;
}

/* Apply a bias-encoded delta to a reference frame:
 * output[i] = ref[i] + (delta[i] - 128) 
 */
static void apply_delta(const uint8_t *ref, const uint8_t *delta, uint8_t *output, size_t size) {
    for (size_t i = 0; i < size; i++) {
        int val = (int)ref[i] + ((int)delta[i] - 128);
        output[i] = (uint8_t)(val < 0 ? 0 : (val > 255 ? 255 : val));
    }
}

qtsq_video_decoder_t* qtsq_video_decoder_open(const qtsq_context_t *ctx) {
    if (!ctx) { fprintf(stderr, "[QTSQ Decoder] ctx is NULL\n"); return NULL; }
    if (!ctx->singularity) { fprintf(stderr, "[QTSQ Decoder] singularity is NULL\n"); return NULL; }
    if (ctx->singularity_size < 8) { fprintf(stderr, "[QTSQ Decoder] singularity_size too small: %zu\n", ctx->singularity_size); return NULL; }
    if (ctx->header.data_type != QTSQ_TYPE_VIDEO_FRAMES) {
        fprintf(stderr, "[QTSQ Decoder] data_type mismatch: %d (expected %d)\n", ctx->header.data_type, QTSQ_TYPE_VIDEO_FRAMES);
        return NULL;
    }

    const uint8_t *p = ctx->singularity;
    if (p[0] != 'I' || p[1] != 'D' || p[2] != 'X' || p[3] != '1') {
        fprintf(stderr, "[QTSQ Decoder] Error: Missing IDX1 chunk. Got: %c%c%c%c\n", p[0], p[1], p[2], p[3]);
        return NULL;
    }
    fprintf(stderr, "[QTSQ Decoder] Opening: %u×%u, singularity=%zu bytes\n",
            ctx->schema.dimensions[0], ctx->schema.dimensions[1], ctx->singularity_size);

    qtsq_video_decoder_t *dec = (qtsq_video_decoder_t *)calloc(1, sizeof(qtsq_video_decoder_t));
    if (!dec) return NULL;

    dec->ctx = ctx;
    dec->width = ctx->schema.dimensions[0];
    dec->height = ctx->schema.dimensions[1];
    dec->channels = ctx->schema.dimensions[2];

    p += 4;
    memcpy(&dec->frame_count, p, 4); p += 4;

    if (dec->frame_count > 0) {
        dec->frame_offsets = (uint32_t *)malloc(dec->frame_count * sizeof(uint32_t));
        dec->frame_sizes = (uint32_t *)malloc(dec->frame_count * sizeof(uint32_t));
        dec->frame_types = (uint8_t *)malloc(dec->frame_count * sizeof(uint8_t));

        if (!dec->frame_offsets || !dec->frame_sizes || !dec->frame_types) {
            qtsq_video_decoder_free(dec);
            return NULL;
        }

        memcpy(dec->frame_offsets, p, dec->frame_count * 4); p += dec->frame_count * 4;
        memcpy(dec->frame_sizes, p, dec->frame_count * 4); p += dec->frame_count * 4;
        memcpy(dec->frame_types, p, dec->frame_count); p += dec->frame_count;
    }

    dec->bitstream = p;
    dec->bitstream_size = ctx->singularity_size - (p - ctx->singularity);
    
    /* Initialize ring buffers lazily */
    dec->ring_head = 0;
    dec->ring_buffer_size = 0;
    
    /* Allocate reference frame buffer */
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    dec->ref_frame = (uint8_t *)calloc(1, frame_bytes);
    dec->has_ref_frame = 0;
    dec->last_iframe_index = UINT32_MAX;
    
    /* Initialize scene segment cache as empty */
    dec->cached_seg_offset = UINT32_MAX;
    dec->cached_seg_body = NULL;

    return dec;
}

/* Simple 2x bilinear upscale for 'D' (downscaled) I-frames */
static uint8_t* upscale_2x(const uint8_t *src, uint32_t sw, uint32_t sh, uint32_t dw, uint32_t dh, uint8_t ch) {
    uint8_t *dst = (uint8_t *)malloc((size_t)dw * dh * ch);
    if (!dst) return NULL;
    
    for (uint32_t y = 0; y < dh; y++) {
        for (uint32_t x = 0; x < dw; x++) {
            /* Map destination pixel to source coordinates */
            float sx = (float)x * sw / dw;
            float sy = (float)y * sh / dh;
            uint32_t sx0 = (uint32_t)sx, sy0 = (uint32_t)sy;
            uint32_t sx1 = sx0 + 1 < sw ? sx0 + 1 : sx0;
            uint32_t sy1 = sy0 + 1 < sh ? sy0 + 1 : sy0;
            float fx = sx - sx0, fy = sy - sy0;
            
            for (uint8_t c = 0; c < ch; c++) {
                float v00 = src[(sy0 * sw + sx0) * ch + c];
                float v10 = src[(sy0 * sw + sx1) * ch + c];
                float v01 = src[(sy1 * sw + sx0) * ch + c];
                float v11 = src[(sy1 * sw + sx1) * ch + c];
                float val = v00 * (1-fx)*(1-fy) + v10 * fx*(1-fy) + v01 * (1-fx)*fy + v11 * fx*fy;
                dst[(y * dw + x) * ch + c] = (uint8_t)(val + 0.5f);
            }
        }
    }
    return dst;
}

/* Decode a keyframe.
 * 'S' = Splat keyframe (pure Gaussian Splats, Phase 10)
 * 'G' = GPU gravitational (vertices + triangles + splats, legacy)
 * 'K' = zlib raw pixels
 * 'I'/'D' = legacy gravitational
 */
static int decode_iframe(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t *output) {
    uint32_t offset = dec->frame_offsets[frame_index];
    uint32_t size = dec->frame_sizes[frame_index];
    uint8_t type = dec->frame_types[frame_index];
    
    if (offset + size > dec->bitstream_size || size < 4) return QTSQ_ERR_CORRUPT;
    
    const uint8_t *data = dec->bitstream + offset;
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    if (type == 'S') {
        /* Pure Splat keyframe (Phase 10):
         * [2B: w] [2B: h] [4B: num_splats] [4B: splat_zlen]
         * [zlib: 9-byte-per-splat data] */
        if (size < 12) return QTSQ_ERR_CORRUPT;
        
        uint16_t fw, fh;
        uint32_t num_splats, splat_zlen;
        memcpy(&fw, data, 2);
        memcpy(&fh, data + 2, 2);
        memcpy(&num_splats, data + 4, 4);
        memcpy(&splat_zlen, data + 8, 4);
        
        if (num_splats == 0) {
            memset(output, 0, frame_bytes);
            return QTSQ_OK;
        }
        
        /* Decompress splat data (9 bytes per splat) */
        size_t raw_size = (size_t)num_splats * 9;
        uint8_t *raw = (uint8_t *)malloc(raw_size);
        if (!raw) return QTSQ_ERR_ALLOC;
        
        uLongf rlen = (uLongf)raw_size;
        if (uncompress(raw, &rlen, data + 12, splat_zlen) != Z_OK) {
            free(raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        /* Cache reference splat data for P-frame delta decoding */
        if (dec->ref_splat_raw) free(dec->ref_splat_raw);
        if (dec->ref_splat_original) free(dec->ref_splat_original);
        dec->ref_splat_raw = (uint8_t *)malloc(raw_size);
        dec->ref_splat_original = (uint8_t *)malloc(raw_size);
        if (dec->ref_splat_raw && dec->ref_splat_original) {
            memcpy(dec->ref_splat_raw, raw, raw_size);
            memcpy(dec->ref_splat_original, raw, raw_size);
            dec->ref_splat_count = num_splats;
        } else {
            dec->ref_splat_count = 0;
        }
        
        /* Convert to splat2d_t for GPU rendering */
        memset(output, 0, frame_bytes);
        
        splat2d_t *splats = (splat2d_t *)calloc(num_splats, sizeof(splat2d_t));
        if (!splats) { free(raw); return QTSQ_ERR_ALLOC; }
        
        for (uint32_t i = 0; i < num_splats; i++) {
            uint8_t *sp = raw + i * 9;
            uint16_t sx, sy;
            memcpy(&sx, sp, 2);
            memcpy(&sy, sp + 2, 2);
            splats[i].x = (float)sx;
            splats[i].y = (float)sy;
            splats[i].z = 0;
            splats[i].r = sp[4];
            splats[i].g = sp[5];
            splats[i].b = sp[6];
            splats[i].sx = sp[7]; /* radius */
            splats[i].sy = sp[7]; /* radius (circular) */
            splats[i].alpha = sp[8];
            splats[i].theta = 0;
        }
        free(raw);
        
        /* CPU splat rasterizer — O(splats × radius²), fast painter's algorithm.
         * DO NOT use GPU render_splats here — it's O(pixels × splats) = 100B ops at 1080p. */
        for (uint32_t i = 0; i < num_splats; i++) {
            int cx = (int)splats[i].x, cy = (int)splats[i].y;
            int r = (int)splats[i].sx;
            if (r < 1) r = 1;
            uint8_t sr = splats[i].r, sg = splats[i].g, sb = splats[i].b;
            float r2f = (float)(r * r);
            
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    float d2 = (float)(dx * dx + dy * dy);
                    if (d2 > r2f) continue;
                    int px = cx + dx, py = cy + dy;
                    if (px < 0 || px >= (int)dec->width || py < 0 || py >= (int)dec->height) continue;
                    
                    /* Gaussian-like blend: full color at center, fade at edges */
                    float w = 1.0f - (d2 / (r2f * 1.2f));
                    if (w < 0.0f) w = 0.0f;
                    
                    size_t pidx = ((size_t)py * dec->width + px) * dec->channels;
                    uint8_t er = output[pidx], eg = output[pidx + 1], eb = output[pidx + 2];
                    output[pidx]     = (uint8_t)(sr * w + er * (1.0f - w));
                    output[pidx + 1] = (uint8_t)(sg * w + eg * (1.0f - w));
                    output[pidx + 2] = (uint8_t)(sb * w + eb * (1.0f - w));
                    if (dec->channels == 4) output[pidx + 3] = 255;
                }
            }
        }
        
        free(splats);
        return QTSQ_OK;
    }
    
    if (type == 'G') {
        /* GPU gravitational keyframe:
         * [2B: w] [2B: h] [4B: num_verts] [4B: num_tris] [4B: num_splats]
         * [4B: vert_zlen] [4B: tri_zlen] [4B: splat_zlen]
         * [zlib: vert_data] [zlib: tri_data] [zlib: splat_data] */
        if (size < 28) return QTSQ_ERR_CORRUPT;
        
        uint16_t fw, fh;
        uint32_t num_verts, num_tris, num_splats;
        uint32_t vert_zlen, tri_zlen, splat_zlen;
        
        memcpy(&fw, data, 2);
        memcpy(&fh, data + 2, 2);
        memcpy(&num_verts, data + 4, 4);
        memcpy(&num_tris, data + 8, 4);
        memcpy(&num_splats, data + 12, 4);
        memcpy(&vert_zlen, data + 16, 4);
        memcpy(&tri_zlen, data + 20, 4);
        memcpy(&splat_zlen, data + 24, 4);
        
        const uint8_t *vert_z = data + 28;
        const uint8_t *tri_z = vert_z + vert_zlen;
        const uint8_t *splat_z = tri_z + tri_zlen;
        
        /* Decompress vertex data: positions(float2×N) + colors(uchar3×N) */
        size_t vert_raw_size = num_verts * 2 * sizeof(float) + num_verts * 3;
        uint8_t *vert_raw = (uint8_t *)malloc(vert_raw_size);
        if (!vert_raw) return QTSQ_ERR_ALLOC;
        
        uLongf vlen = (uLongf)vert_raw_size;
        if (uncompress(vert_raw, &vlen, vert_z, vert_zlen) != Z_OK) {
            free(vert_raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        float *vert_pos = (float *)vert_raw;
        uint8_t *vert_colors = vert_raw + num_verts * 2 * sizeof(float);
        
        /* Decompress triangle indices */
        size_t tri_raw_size = num_tris * 3 * sizeof(uint32_t);
        uint32_t *tris = (uint32_t *)malloc(tri_raw_size);
        if (!tris) { free(vert_raw); return QTSQ_ERR_ALLOC; }
        
        uLongf tlen = (uLongf)tri_raw_size;
        if (uncompress((uint8_t*)tris, &tlen, tri_z, tri_zlen) != Z_OK) {
            free(tris); free(vert_raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        /* Decompress splat data if present */
        uint8_t *splat_raw = NULL;
        if (num_splats > 0 && splat_zlen > 0) {
            size_t splat_raw_size = num_splats * 12;
            splat_raw = (uint8_t *)malloc(splat_raw_size);
            if (splat_raw) {
                uLongf slen = (uLongf)splat_raw_size;
                if (uncompress(splat_raw, &slen, splat_z, splat_zlen) != Z_OK) {
                    free(splat_raw);
                    splat_raw = NULL;
                    num_splats = 0;
                }
            }
        }
        
        /* Render: Build TriVertex array and rasterize using GPU */
        memset(output, 0, frame_bytes); /* Clear output */
        
        /* Build TriVertex array from positions + colors */
        /* TriVertex: float x, float y, uchar r, g, b = 13 bytes but struct-aligned */
        /* Use the existing Metal rasterization kernel via CPU struct packing */
        tri_vertex_t *vertices = (tri_vertex_t *)malloc(num_verts * sizeof(tri_vertex_t));
        tri_face_t *faces = (tri_face_t *)malloc(num_tris * sizeof(tri_face_t));
        
        if (vertices && faces) {
            for (uint32_t i = 0; i < num_verts; i++) {
                vertices[i].x = vert_pos[i * 2];
                vertices[i].y = vert_pos[i * 2 + 1];
                vertices[i].r = vert_colors[i * 3];
                vertices[i].g = vert_colors[i * 3 + 1];
                vertices[i].b = vert_colors[i * 3 + 2];
            }
            
            /* Triangle indices use pixel-linearized IDs; remap to vertex indices */
            /* The encoder stores va = seed_y * width + seed_x as the index.
             * We need to find which vertex index corresponds to each pixel ID. */
            /* Build a lookup from pixel position to vertex index */
            for (uint32_t i = 0; i < num_tris; i++) {
                /* For now, these are pixel-linearized — find matching vertex by position */
                faces[i].v0 = tris[i * 3];
                faces[i].v1 = tris[i * 3 + 1];
                faces[i].v2 = tris[i * 3 + 2];
            }
            
            uint8_t *blur_map = (uint8_t *)calloc(dec->width * dec->height, 1);
            
#ifdef __APPLE__
            qtsq_metal_ctx_t *metal = qtsq_metal_global();
            if (metal) {
                qtsq_metal_rasterize(metal, vertices, num_verts, faces, num_tris,
                                      dec->width, dec->height, dec->channels, output, blur_map, NULL);
                
                /* Render splats in smooth regions */
                if (splat_raw && num_splats > 0) {
                    /* Convert splat_raw to splat2d_t array for rendering */
                    splat2d_t *splats = (splat2d_t *)calloc(num_splats, sizeof(splat2d_t));
                    if (splats) {
                        for (uint32_t i = 0; i < num_splats; i++) {
                            uint8_t *sp = splat_raw + i * 12;
                            float sx, sy;
                            memcpy(&sx, sp, 4);
                            memcpy(&sy, sp + 4, 4);
                            splats[i].x = sx;
                            splats[i].y = sy;
                            splats[i].z = 0;
                            splats[i].r = sp[8];
                            splats[i].g = sp[9];
                            splats[i].b = sp[10];
                            /* SplatOutput layout: [float2 pos(8B)][r(1B)][g(1B)][b(1B)][radius(1B)] = 12 bytes */
                            splats[i].sx = sp[11]; /* radius as sx */
                            splats[i].sy = sp[11]; /* radius as sy */
                            splats[i].alpha = 200; /* Fixed alpha for smooth regions */
                            splats[i].theta = 0;
                        }
                        qtsq_metal_render_splats(metal, splats, num_splats,
                                                  dec->width, dec->height, dec->channels,
                                                  output, NULL);
                        free(splats);
                    }
                }
            }
#endif
            if (blur_map) free(blur_map);
        }
        
        if (vertices) free(vertices);
        if (faces) free(faces);
        if (splat_raw) free(splat_raw);
        free(tris);
        free(vert_raw);
        
        return QTSQ_OK;
    }
    
    /* Read resolution header (common to K/I/D types) */
    uint16_t comp_w, comp_h;
    memcpy(&comp_w, data, 2);
    memcpy(&comp_h, data + 2, 2);
    
    uint8_t *decoded = NULL;
    size_t decoded_size = 0;
    
    if (type == 'K') {
        /* Fast zlib keyframe: [2B: w] [2B: h] [4B: raw_size] [zlib_data] */
        if (size < 8) return QTSQ_ERR_CORRUPT;
        uint32_t raw_size;
        memcpy(&raw_size, data + 4, 4);
        
        decoded = (uint8_t *)malloc(raw_size);
        if (!decoded) return QTSQ_ERR_ALLOC;
        
        uLongf dest_len = raw_size;
        int zret = uncompress(decoded, &dest_len, data + 8, size - 8);
        if (zret != Z_OK) {
            free(decoded);
            return QTSQ_ERR_CORRUPT;
        }
        decoded_size = dest_len;
    } else {
        /* Legacy gravitational: [2B: w] [2B: h] [gravitational_data] */
        qtsq_context_t temp_ctx;
        qtsq_init(&temp_ctx);
        temp_ctx.header = dec->ctx->header;
        temp_ctx.schema = dec->ctx->schema;
        temp_ctx.schema.dimensions[0] = comp_w;
        temp_ctx.schema.dimensions[1] = comp_h;
        
        size_t payload_size = size - 4;
        temp_ctx.singularity_size = payload_size;
        temp_ctx.singularity = (uint8_t *)malloc(payload_size);
        if (!temp_ctx.singularity) return QTSQ_ERR_ALLOC;
        memcpy(temp_ctx.singularity, data + 4, payload_size);
        
        int ret = qtsq_decompress_gravitational(&temp_ctx, &decoded, &decoded_size);
        free(temp_ctx.singularity);
        temp_ctx.singularity = NULL;
        qtsq_free(&temp_ctx);
        if (ret != QTSQ_OK) {
            if (decoded) free(decoded);
            return ret;
        }
    }
    
    /* If compressed at a smaller resolution, upscale to full output size */
    if (comp_w != dec->width || comp_h != dec->height) {
        uint8_t *upscaled = upscale_2x(decoded, comp_w, comp_h, dec->width, dec->height, dec->channels);
        free(decoded);
        if (!upscaled) return QTSQ_ERR_ALLOC;
        memcpy(output, upscaled, frame_bytes);
        free(upscaled);
    } else {
        size_t copy_size = decoded_size < frame_bytes ? decoded_size : frame_bytes;
        memcpy(output, decoded, copy_size);
        free(decoded);
    }
    
    return QTSQ_OK;
}

/* Decode a B-frame: 8×8 Block-Level Pixel Delta
 * Format: [2B: w][2B: h][4B: num_changed_blocks][4B: zlen]
 *         [zlib: for each block: [2B: bx][2B: by][192B: 8×8×3 RGB]]
 * Copy reference frame, then patch in changed blocks. */
#define DECODE_BLOCK_SIZE 8

static int decode_bframe(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t *output) {
    uint32_t offset = dec->frame_offsets[frame_index];
    uint32_t size = dec->frame_sizes[frame_index];
    
    if (offset + size > dec->bitstream_size) return QTSQ_ERR_CORRUPT;
    if (!dec->has_ref_frame || !dec->ref_frame) return QTSQ_ERR_CORRUPT;
    
    const uint8_t *data = dec->bitstream + offset;
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    /* Parse header: [2B: w][2B: h][4B: num_changed][4B: zlen] */
    if (size < 12) return QTSQ_ERR_CORRUPT;
    uint32_t num_changed, zlen;
    memcpy(&num_changed, data + 4, 4);
    memcpy(&zlen, data + 8, 4);
    
    /* Start from reference frame */
    memcpy(output, dec->ref_frame, frame_bytes);
    
    /* Apply changed blocks */
    if (num_changed > 0 && zlen > 0) {
        size_t per_block = 4 + DECODE_BLOCK_SIZE * DECODE_BLOCK_SIZE * 3;
        size_t raw_size = (size_t)num_changed * per_block;
        uint8_t *raw = (uint8_t *)malloc(raw_size);
        if (!raw) return QTSQ_ERR_ALLOC;
        
        uLongf rlen = (uLongf)raw_size;
        if (uncompress(raw, &rlen, data + 12, zlen) != Z_OK) {
            free(raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        /* Patch each changed block into the output */
        uint32_t w = dec->width, h = dec->height;
        uint8_t ch = dec->channels;
        
        for (uint32_t i = 0; i < num_changed; i++) {
            uint8_t *blk = raw + i * per_block;
            uint16_t bx, by;
            memcpy(&bx, blk, 2);
            memcpy(&by, blk + 2, 2);
            uint8_t *pixels = blk + 4;
            
            uint32_t px0 = (uint32_t)bx * DECODE_BLOCK_SIZE;
            uint32_t py0 = (uint32_t)by * DECODE_BLOCK_SIZE;
            
            for (uint32_t dy = 0; dy < DECODE_BLOCK_SIZE; dy++) {
                for (uint32_t dx = 0; dx < DECODE_BLOCK_SIZE; dx++) {
                    uint32_t px = px0 + dx, py = py0 + dy;
                    if (px >= w || py >= h) continue;
                    size_t pidx = ((size_t)py * w + px) * ch;
                    size_t sidx = (dy * DECODE_BLOCK_SIZE + dx) * 3;
                    output[pidx]     = pixels[sidx];
                    output[pidx + 1] = pixels[sidx + 1];
                    output[pidx + 2] = pixels[sidx + 2];
                    if (ch == 4) output[pidx + 3] = 255;
                }
            }
        }
        free(raw);
    }
    
    return QTSQ_OK;
}

/* Legacy P-frame decoder (for old 'P' type splat delta frames) */
static int decode_pframe(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t *output) {
    uint32_t offset = dec->frame_offsets[frame_index];
    uint32_t size = dec->frame_sizes[frame_index];
    
    if (offset + size > dec->bitstream_size) return QTSQ_ERR_CORRUPT;
    if (!dec->ref_splat_raw || dec->ref_splat_count == 0) {
        /* No splat data — try using ref_frame as pixel fallback */
        if (dec->has_ref_frame && dec->ref_frame) {
            size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
            memcpy(output, dec->ref_frame, frame_bytes);
            return QTSQ_OK;
        }
        return QTSQ_ERR_CORRUPT;
    }
    
    const uint8_t *data = dec->bitstream + offset;
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    if (size < 12) return QTSQ_ERR_CORRUPT;
    uint32_t num_changed, zlen;
    memcpy(&num_changed, data + 4, 4);
    memcpy(&zlen, data + 8, 4);
    
    if (dec->ref_splat_original) {
        size_t splat_data_size = (size_t)dec->ref_splat_count * 9;
        memcpy(dec->ref_splat_raw, dec->ref_splat_original, splat_data_size);
    }
    
    if (num_changed > 0 && zlen > 0) {
        size_t raw_size = (size_t)num_changed * 7;
        uint8_t *raw = (uint8_t *)malloc(raw_size);
        if (!raw) return QTSQ_ERR_ALLOC;
        
        uLongf rlen = (uLongf)raw_size;
        if (uncompress(raw, &rlen, data + 12, zlen) != Z_OK) {
            free(raw);
            return QTSQ_ERR_CORRUPT;
        }
        
        for (uint32_t i = 0; i < num_changed; i++) {
            uint32_t splat_idx;
            memcpy(&splat_idx, raw + i * 7, 4);
            if (splat_idx >= dec->ref_splat_count) continue;
            
            uint8_t *sp = dec->ref_splat_raw + splat_idx * 9;
            int new_r = (int)sp[4] + ((int)raw[i * 7 + 4] - 128);
            int new_g = (int)sp[5] + ((int)raw[i * 7 + 5] - 128);
            int new_b = (int)sp[6] + ((int)raw[i * 7 + 6] - 128);
            sp[4] = (uint8_t)(new_r < 0 ? 0 : (new_r > 255 ? 255 : new_r));
            sp[5] = (uint8_t)(new_g < 0 ? 0 : (new_g > 255 ? 255 : new_g));
            sp[6] = (uint8_t)(new_b < 0 ? 0 : (new_b > 255 ? 255 : new_b));
        }
        free(raw);
    }
    
    /* Re-render splats (legacy path) */
    memset(output, 0, frame_bytes);
    for (uint32_t i = 0; i < dec->ref_splat_count; i++) {
        uint8_t *sp = dec->ref_splat_raw + i * 9;
        uint16_t sx, sy;
        memcpy(&sx, sp, 2);
        memcpy(&sy, sp + 2, 2);
        int cx = (int)sx, cy = (int)sy;
        int r = (int)sp[7];
        if (r < 1) r = 1;
        uint8_t sr = sp[4], sg = sp[5], sb = sp[6];
        float r2f = (float)(r * r);
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                float d2 = (float)(dx * dx + dy * dy);
                if (d2 > r2f) continue;
                int px = cx + dx, py = cy + dy;
                if (px < 0 || px >= (int)dec->width || py < 0 || py >= (int)dec->height) continue;
                float w = 1.0f - (d2 / (r2f * 1.2f));
                if (w < 0.0f) w = 0.0f;
                size_t pidx = ((size_t)py * dec->width + px) * dec->channels;
                uint8_t er = output[pidx], eg = output[pidx + 1], eb = output[pidx + 2];
                output[pidx]     = (uint8_t)(sr * w + er * (1.0f - w));
                output[pidx + 1] = (uint8_t)(sg * w + eg * (1.0f - w));
                output[pidx + 2] = (uint8_t)(sb * w + eb * (1.0f - w));
                if (dec->channels == 4) output[pidx + 3] = 255;
            }
        }
    }
    return QTSQ_OK;
}

/* ═══════════════════════════════════════════════════════════
 * Decode a 'V' (Scene) frame.
 * All frames in a segment share the same blob. The decoder computes
 * which frame within the segment this is, interpolates dynamic splat
 * colors at time t, then renders all splats to the pixel buffer.
 *
 * Format:
 *   [4B: 'SCEN'][2B: w][2B: h][4B: N splats][4B: N static][4B: N dynamic]
 *   [2B: seg_frames][1B: num_kf][1B: kf_interval][4B: zlib_len]
 *   [zlib: positions(5B×N) + static_colors(3B×S) + dynamic_kf_colors(3B×K×D)]
 * ═══════════════════════════════════════════════════════════ */
static int decode_scene_frame(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t *output) {
    uint32_t offset = dec->frame_offsets[frame_index];
    uint32_t size = dec->frame_sizes[frame_index];
    
    if (offset + size > dec->bitstream_size || size < 28) return QTSQ_ERR_CORRUPT;
    
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    /* ── Check if this segment is already cached ── */
    if (dec->cached_seg_offset != offset) {
        /* Need to decompress this new segment */
        const uint8_t *data = dec->bitstream + offset;
        
        if (data[0] != 'S' || data[1] != 'C' || data[2] != 'E' || data[3] != 'N') {
            return QTSQ_ERR_CORRUPT;
        }
        
        memcpy(&dec->cached_seg_num_splats, data + 8, 4);
        memcpy(&dec->cached_seg_num_static, data + 12, 4);
        memcpy(&dec->cached_seg_num_dynamic, data + 16, 4);
        memcpy(&dec->cached_seg_frames, data + 20, 2);
        dec->cached_seg_num_kf = data[22];
        dec->cached_seg_kf_interval = data[23];
        
        if (dec->cached_seg_num_splats == 0 || dec->cached_seg_frames == 0) return QTSQ_ERR_CORRUPT;
        if (dec->cached_seg_num_static + dec->cached_seg_num_dynamic != dec->cached_seg_num_splats) return QTSQ_ERR_CORRUPT;
        
        uint32_t zlen;
        memcpy(&zlen, data + 24, 4);
        
        size_t pos_size = (size_t)dec->cached_seg_num_splats * 5;
        size_t static_size = (size_t)dec->cached_seg_num_static * 3;
        size_t dynamic_size = (size_t)dec->cached_seg_num_dynamic * dec->cached_seg_num_kf * 3;
        size_t body_size = pos_size + static_size + dynamic_size;
        
        /* Free old cache */
        if (dec->cached_seg_body) { free(dec->cached_seg_body); dec->cached_seg_body = NULL; }
        
        dec->cached_seg_body = (uint8_t *)malloc(body_size);
        if (!dec->cached_seg_body) return QTSQ_ERR_ALLOC;
        
        uLongf body_len = (uLongf)body_size;
        if (uncompress(dec->cached_seg_body, &body_len, data + 28, zlen) != Z_OK) {
            free(dec->cached_seg_body);
            dec->cached_seg_body = NULL;
            return QTSQ_ERR_CORRUPT;
        }
        dec->cached_seg_body_size = body_size;
        dec->cached_seg_offset = offset;
        dec->render_positions_set = 0;  /* force position reload for new segment */
        
        /* Find segment start frame */
        uint32_t seg_start = frame_index;
        while (seg_start > 0 && dec->frame_types[seg_start - 1] == 'V' &&
               dec->frame_offsets[seg_start - 1] == offset) {
            seg_start--;
        }
        dec->cached_seg_start = seg_start;
    }
    
    /* ── Use cached segment data ── */
    uint32_t num_splats = dec->cached_seg_num_splats;
    uint32_t num_static = dec->cached_seg_num_static;
    uint32_t num_dynamic = dec->cached_seg_num_dynamic;
    uint8_t num_kf = dec->cached_seg_num_kf;
    uint8_t kf_interval = dec->cached_seg_kf_interval;
    
    uint32_t frame_in_seg = frame_index - dec->cached_seg_start;
    if (frame_in_seg >= dec->cached_seg_frames) frame_in_seg = dec->cached_seg_frames - 1;
    
    float t = (float)frame_in_seg;
    
    size_t pos_size = (size_t)num_splats * 5;
    size_t static_size = (size_t)num_static * 3;
    const uint8_t *positions = dec->cached_seg_body;
    const uint8_t *static_colors = dec->cached_seg_body + pos_size;
    const uint8_t *dynamic_kf = dec->cached_seg_body + pos_size + static_size;
    
    /* ── Persistent splat array: allocate once, reuse across frames ── */
    if (!dec->render_splats || dec->render_splat_capacity < num_splats) {
        free(dec->render_splats);
        dec->render_splats = (splat2d_t *)calloc(num_splats, sizeof(splat2d_t));
        if (!dec->render_splats) return QTSQ_ERR_ALLOC;
        dec->render_splat_capacity = num_splats;
        dec->render_positions_set = 0;
    }
    
    splat2d_t *splats = dec->render_splats;
    
    /* Set positions ONCE per segment (they never change between frames) */
    if (!dec->render_positions_set) {
        for (uint32_t i = 0; i < num_splats; i++) {
            const uint8_t *pos = positions + i * 5;
            uint16_t sx, sy;
            memcpy(&sx, pos, 2);
            memcpy(&sy, pos + 2, 2);
            uint8_t sr = pos[4];
            
            splats[i].x = sx;
            splats[i].y = sy;
            splats[i].sx = sr;
            splats[i].sy = sr;
            splats[i].alpha = 255;
            splats[i].theta = 0;
            splats[i].z = 0;
        }
        dec->render_positions_set = 1;
        fprintf(stderr, "[QTSQ Video] Positions loaded for %u splats (persistent)\n", num_splats);
    }
    
    /* Update ONLY colors per frame (the cheap part: ~2ms for 50K splats) */
    for (uint32_t i = 0; i < num_splats; i++) {
        if (i < num_static) {
            const uint8_t *c = static_colors + i * 3;
            splats[i].r = c[0];
            splats[i].g = c[1];
            splats[i].b = c[2];
        } else {
            uint32_t dyn_idx = i - num_static;
            const uint8_t *kf_colors = dynamic_kf + (size_t)dyn_idx * num_kf * 3;
            
            float kf_pos = t / (float)kf_interval;
            int kf_lo = (int)kf_pos;
            int kf_hi = kf_lo + 1;
            float frac = kf_pos - (float)kf_lo;
            
            if (kf_lo < 0) kf_lo = 0;
            if (kf_lo >= (int)num_kf) kf_lo = (int)num_kf - 1;
            if (kf_hi >= (int)num_kf) kf_hi = (int)num_kf - 1;
            
            const uint8_t *c0 = kf_colors + kf_lo * 3;
            const uint8_t *c1 = kf_colors + kf_hi * 3;
            
            splats[i].r = (uint8_t)(c0[0] * (1.0f - frac) + c1[0] * frac + 0.5f);
            splats[i].g = (uint8_t)(c0[1] * (1.0f - frac) + c1[1] * frac + 0.5f);
            splats[i].b = (uint8_t)(c0[2] * (1.0f - frac) + c1[2] * frac + 0.5f);
        }
    }
    
    /* Render splats to output pixel buffer */
    memset(output, 0, frame_bytes);
    
#ifdef __APPLE__
    qtsq_metal_ctx_t *metal = qtsq_metal_global();
    if (metal) {
        qtsq_metal_render_splats_fast(metal, splats, num_splats,
                                       dec->width, dec->height, dec->channels,
                                       output);
    } else
#endif
    {
        splat2d_render(splats, num_splats, output, dec->width, dec->height, NULL);
    }
    
    /* DO NOT free splats — they're persistent in dec->render_splats */
    return QTSQ_OK;
}

/* ═══════════════════════════════════════════════════════════
 * Decode a 'H' (Hybrid Scene) frame.
 * All frames in a segment share the same mesh + splat geometry.
 * Per-frame: interpolate vertex/splat colors, then GPU render.
 *
 * HSCN Format (40-byte header):
 *   [4B: 'HSCN'][2B: w][2B: h]
 *   [4B: num_verts][4B: num_faces][4B: num_splats]
 *   [4B: num_static_verts][4B: num_static_splats]
 *   [2B: seg_frames][1B: num_kf][1B: kf_interval][4B: reserved]
 *   [4B: zlib_len]
 *   [zlib body...]
 * ═══════════════════════════════════════════════════════════ */
static int decode_hybrid_frame(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t *output) {
    uint32_t offset = dec->frame_offsets[frame_index];
    uint32_t size = dec->frame_sizes[frame_index];
    
    if (offset + size > dec->bitstream_size || size < 44) return QTSQ_ERR_CORRUPT;
    
    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    /* ── Check if this segment is already cached ── */
    if (dec->cached_seg_offset != offset) {
        const uint8_t *data = dec->bitstream + offset;
        
        if (data[0] != 'H' || data[1] != 'S' || data[2] != 'C' || data[3] != 'N') {
            return QTSQ_ERR_CORRUPT;
        }
        
        uint32_t num_verts, num_faces, num_splats, num_static_verts, num_static_splats;
        memcpy(&num_verts, data + 8, 4);
        memcpy(&num_faces, data + 12, 4);
        memcpy(&num_splats, data + 16, 4);
        memcpy(&num_static_verts, data + 20, 4);
        memcpy(&num_static_splats, data + 24, 4);
        memcpy(&dec->cached_seg_frames, data + 28, 2);
        dec->cached_seg_num_kf = data[30];
        dec->cached_seg_kf_interval = data[31];
        
        if (num_verts == 0 || num_faces == 0 || dec->cached_seg_frames == 0) return QTSQ_ERR_CORRUPT;
        
        uint32_t zlen;
        memcpy(&zlen, data + 40, 4);
        
        /* Calculate expected body size */
        uint32_t num_dynamic_verts = num_verts - num_static_verts;
        uint32_t num_dynamic_splats = num_splats - num_static_splats;
        size_t vert_pos_size = (size_t)num_verts * 4;
        size_t face_idx_size = (size_t)num_faces * 6;
        size_t splat_pos_size = (size_t)num_splats * 5;
        size_t static_vert_color_size = (size_t)num_static_verts * 3;
        size_t static_splat_color_size = (size_t)num_static_splats * 3;
        size_t dynamic_vert_color_size = (size_t)num_dynamic_verts * dec->cached_seg_num_kf * 3;
        size_t dynamic_splat_color_size = (size_t)num_dynamic_splats * dec->cached_seg_num_kf * 3;
        size_t body_size = vert_pos_size + face_idx_size + splat_pos_size
                         + static_vert_color_size + static_splat_color_size
                         + dynamic_vert_color_size + dynamic_splat_color_size;
        
        /* Decompress body */
        if (dec->cached_seg_body) { free(dec->cached_seg_body); dec->cached_seg_body = NULL; }
        dec->cached_seg_body = (uint8_t *)malloc(body_size);
        if (!dec->cached_seg_body) return QTSQ_ERR_ALLOC;
        
        uLongf body_len = (uLongf)body_size;
        if (uncompress(dec->cached_seg_body, &body_len, data + 44, zlen) != Z_OK) {
            free(dec->cached_seg_body);
            dec->cached_seg_body = NULL;
            return QTSQ_ERR_CORRUPT;
        }
        dec->cached_seg_body_size = body_size;
        dec->cached_seg_offset = offset;
        dec->hybrid_geometry_set = 0;  /* force geometry reload */
        
        /* Store parsed counts */
        dec->cached_hybrid_num_verts = num_verts;
        dec->cached_hybrid_num_faces = num_faces;
        dec->cached_hybrid_num_splats = num_splats;
        dec->cached_hybrid_num_static_verts = num_static_verts;
        dec->cached_hybrid_num_static_splats = num_static_splats;
        
        /* Find segment start frame */
        uint32_t seg_start = frame_index;
        while (seg_start > 0 && dec->frame_types[seg_start - 1] == 'H' &&
               dec->frame_offsets[seg_start - 1] == offset) {
            seg_start--;
        }
        dec->cached_seg_start = seg_start;
        
        fprintf(stderr, "[QTSQ Hybrid] Cached segment: %u verts, %u faces, %u splats, %u frames\n",
                num_verts, num_faces, num_splats, dec->cached_seg_frames);
    }
    
    /* ── Parse body pointers ── */
    uint32_t num_verts = dec->cached_hybrid_num_verts;
    uint32_t num_faces = dec->cached_hybrid_num_faces;
    uint32_t num_splats = dec->cached_hybrid_num_splats;
    uint32_t num_static_verts = dec->cached_hybrid_num_static_verts;
    uint32_t num_static_splats = dec->cached_hybrid_num_static_splats;
    uint32_t num_dynamic_verts = num_verts - num_static_verts;
    uint32_t num_dynamic_splats = num_splats - num_static_splats;
    uint8_t num_kf = dec->cached_seg_num_kf;
    uint8_t kf_interval = dec->cached_seg_kf_interval;
    
    const uint8_t *body = dec->cached_seg_body;
    const uint8_t *vert_positions = body;
    const uint8_t *face_indices = vert_positions + (size_t)num_verts * 4;
    const uint8_t *splat_positions = face_indices + (size_t)num_faces * 6;
    const uint8_t *static_vert_colors = splat_positions + (size_t)num_splats * 5;
    const uint8_t *static_splat_colors = static_vert_colors + (size_t)num_static_verts * 3;
    const uint8_t *dynamic_vert_kf = static_splat_colors + (size_t)num_static_splats * 3;
    const uint8_t *dynamic_splat_kf = dynamic_vert_kf + (size_t)num_dynamic_verts * num_kf * 3;
    
    /* ── Allocate/resize persistent geometry buffers ── */
    if (dec->hybrid_vert_count < num_verts) {
        if (dec->hybrid_verts) free(dec->hybrid_verts);
        dec->hybrid_verts = (tri_vertex_t *)malloc(num_verts * sizeof(tri_vertex_t));
        dec->hybrid_vert_count = num_verts;
    }
    if (dec->hybrid_face_count < num_faces) {
        if (dec->hybrid_faces) free(dec->hybrid_faces);
        dec->hybrid_faces = (tri_face_t *)malloc(num_faces * sizeof(tri_face_t));
        dec->hybrid_face_count = num_faces;
    }
    if (num_splats > 0 && dec->hybrid_splat_count < num_splats) {
        if (dec->hybrid_splats) free(dec->hybrid_splats);
        dec->hybrid_splats = (splat2d_t *)calloc(num_splats, sizeof(splat2d_t));
        dec->hybrid_splat_count = num_splats;
    }
    
    /* ── Load geometry ONCE per segment ── */
    if (!dec->hybrid_geometry_set) {
        /* Parse vertex positions */
        for (uint32_t i = 0; i < num_verts; i++) {
            uint16_t vx, vy;
            memcpy(&vx, vert_positions + i * 4, 2);
            memcpy(&vy, vert_positions + i * 4 + 2, 2);
            dec->hybrid_verts[i].x = (float)vx;
            dec->hybrid_verts[i].y = (float)vy;
        }
        
        /* Parse face indices */
        for (uint32_t i = 0; i < num_faces; i++) {
            uint16_t v0, v1, v2;
            memcpy(&v0, face_indices + i * 6, 2);
            memcpy(&v1, face_indices + i * 6 + 2, 2);
            memcpy(&v2, face_indices + i * 6 + 4, 2);
            dec->hybrid_faces[i].v0 = v0;
            dec->hybrid_faces[i].v1 = v1;
            dec->hybrid_faces[i].v2 = v2;
        }
        
        /* Parse splat positions */
        for (uint32_t i = 0; i < num_splats; i++) {
            const uint8_t *sp = splat_positions + i * 5;
            uint16_t sx, sy;
            memcpy(&sx, sp, 2);
            memcpy(&sy, sp + 2, 2);
            dec->hybrid_splats[i].x = sx;
            dec->hybrid_splats[i].y = sy;
            dec->hybrid_splats[i].sx = sp[4];
            dec->hybrid_splats[i].sy = sp[4];
            dec->hybrid_splats[i].alpha = 255;
            dec->hybrid_splats[i].theta = 0;
            dec->hybrid_splats[i].z = 0;
        }
        
        dec->hybrid_geometry_set = 1;
        fprintf(stderr, "[QTSQ Hybrid] Geometry loaded: %u verts, %u faces, %u splats\n",
                num_verts, num_faces, num_splats);
    }
    
    /* ── Per-frame: interpolate vertex colors ── */
    uint32_t t = frame_index - dec->cached_seg_start;
    
    for (uint32_t i = 0; i < num_verts; i++) {
        if (i < num_static_verts) {
            const uint8_t *c = static_vert_colors + i * 3;
            dec->hybrid_verts[i].r = c[0];
            dec->hybrid_verts[i].g = c[1];
            dec->hybrid_verts[i].b = c[2];
        } else {
            uint32_t dyn_idx = i - num_static_verts;
            const uint8_t *kf_colors = dynamic_vert_kf + (size_t)dyn_idx * num_kf * 3;
            
            float kf_pos = (float)t / (float)kf_interval;
            int kf_lo = (int)kf_pos;
            int kf_hi = kf_lo + 1;
            float frac = kf_pos - (float)kf_lo;
            
            if (kf_lo < 0) kf_lo = 0;
            if (kf_lo >= (int)num_kf) kf_lo = (int)num_kf - 1;
            if (kf_hi >= (int)num_kf) kf_hi = (int)num_kf - 1;
            
            const uint8_t *c0 = kf_colors + kf_lo * 3;
            const uint8_t *c1 = kf_colors + kf_hi * 3;
            
            dec->hybrid_verts[i].r = (uint8_t)(c0[0] * (1.0f - frac) + c1[0] * frac + 0.5f);
            dec->hybrid_verts[i].g = (uint8_t)(c0[1] * (1.0f - frac) + c1[1] * frac + 0.5f);
            dec->hybrid_verts[i].b = (uint8_t)(c0[2] * (1.0f - frac) + c1[2] * frac + 0.5f);
        }
    }
    
    /* ── Per-frame: interpolate splat colors ── */
    for (uint32_t i = 0; i < num_splats; i++) {
        if (i < num_static_splats) {
            const uint8_t *c = static_splat_colors + i * 3;
            dec->hybrid_splats[i].r = c[0];
            dec->hybrid_splats[i].g = c[1];
            dec->hybrid_splats[i].b = c[2];
        } else {
            uint32_t dyn_idx = i - num_static_splats;
            const uint8_t *kf_colors = dynamic_splat_kf + (size_t)dyn_idx * num_kf * 3;
            
            float kf_pos = (float)t / (float)kf_interval;
            int kf_lo = (int)kf_pos;
            int kf_hi = kf_lo + 1;
            float frac = kf_pos - (float)kf_lo;
            
            if (kf_lo < 0) kf_lo = 0;
            if (kf_lo >= (int)num_kf) kf_lo = (int)num_kf - 1;
            if (kf_hi >= (int)num_kf) kf_hi = (int)num_kf - 1;
            
            const uint8_t *c0 = kf_colors + kf_lo * 3;
            const uint8_t *c1 = kf_colors + kf_hi * 3;
            
            dec->hybrid_splats[i].r = (uint8_t)(c0[0] * (1.0f - frac) + c1[0] * frac + 0.5f);
            dec->hybrid_splats[i].g = (uint8_t)(c0[1] * (1.0f - frac) + c1[1] * frac + 0.5f);
            dec->hybrid_splats[i].b = (uint8_t)(c0[2] * (1.0f - frac) + c1[2] * frac + 0.5f);
        }
    }
    
    /* ── GPU Hybrid Render: 3-pass (triangles + splats + composite) ── */
    memset(output, 0, frame_bytes);
    
#ifdef __APPLE__
    qtsq_metal_ctx_t *metal = qtsq_metal_global();
    if (metal) {
        qtsq_metal_render_hybrid(metal,
                                  dec->hybrid_verts, num_verts,
                                  dec->hybrid_faces, num_faces,
                                  dec->hybrid_splats, num_splats,
                                  dec->width, dec->height, dec->channels,
                                  output);
    } else
#endif
    {
        /* CPU fallback: splat-only render (triangles need GPU) */
        if (num_splats > 0) {
            splat2d_render(dec->hybrid_splats, num_splats, output,
                           dec->width, dec->height, NULL);
        }
    }
    
    return QTSQ_OK;
}

int qtsq_video_decoder_get_frame(qtsq_video_decoder_t *dec, uint32_t frame_index, uint8_t **out_pixels, uint32_t *width, uint32_t *height) {
    if (!dec || !out_pixels) return QTSQ_ERR_NULL;
    if (frame_index >= dec->frame_count) return QTSQ_ERR_IO;

    size_t frame_bytes = (size_t)dec->width * dec->height * dec->channels;
    
    /* Lazy-init ring buffers */
    if (dec->ring_buffer_size == 0) {
        dec->ring_buffer_size = frame_bytes;
        for (int i = 0; i < 3; i++) {
            dec->ring_buffers[i] = (uint8_t *)malloc(dec->ring_buffer_size);
        }
    }
    
    uint8_t *local_buffer = dec->ring_buffers[dec->ring_head];
    dec->ring_head = (dec->ring_head + 1) % 3;
    *out_pixels = local_buffer;

    uint8_t type = dec->frame_types[frame_index];
    int ret = QTSQ_OK;
    
    /* 'I'/'D'/'K'/'G' = keyframe types */
    if (type == 'I' || type == 'D' || type == 'K' || type == 'G' || type == 'S') {
        /* I-frame: decode and update reference */
        ret = decode_iframe(dec, frame_index, local_buffer);
        if (ret == QTSQ_OK) {
            /* Update reference frame */
            memcpy(dec->ref_frame, local_buffer, frame_bytes);
            dec->has_ref_frame = 1;
            dec->last_iframe_index = frame_index;
        }
    } else if (type == 'B') {
        /* Block-delta frame — fast path: copy ref + patch blocks */
        if (!dec->has_ref_frame) {
            /* Seek back to nearest keyframe */
            uint32_t search = frame_index;
            while (search > 0 && dec->frame_types[search] != 'I' && dec->frame_types[search] != 'S' && dec->frame_types[search] != 'D' && dec->frame_types[search] != 'K' && dec->frame_types[search] != 'G') {
                search--;
            }
            ret = decode_iframe(dec, search, dec->ref_frame);
            if (ret != QTSQ_OK) return ret;
            dec->has_ref_frame = 1;
            dec->last_iframe_index = search;
        }
        
        ret = decode_bframe(dec, frame_index, local_buffer);
        if (ret == QTSQ_OK) {
            /* Do NOT update ref_frame — B-frames always delta against the I-frame */
        }
    } else if (type == 'P') {
        /* Legacy splat P-frame */
        if (!dec->has_ref_frame) {
            uint32_t search = frame_index;
            while (search > 0 && dec->frame_types[search] != 'I' && dec->frame_types[search] != 'S' && dec->frame_types[search] != 'D' && dec->frame_types[search] != 'K' && dec->frame_types[search] != 'G') {
                search--;
            }
            ret = decode_iframe(dec, search, dec->ref_frame);
            if (ret != QTSQ_OK) return ret;
            dec->has_ref_frame = 1;
            dec->last_iframe_index = search;
        }
        
        ret = decode_pframe(dec, frame_index, local_buffer);
        if (ret == QTSQ_OK) {
            memcpy(dec->ref_frame, local_buffer, frame_bytes);
        }
    } else if (type == 'V') {
        /* Scene-level splat segment: instant random access */
        ret = decode_scene_frame(dec, frame_index, local_buffer);
    } else if (type == 'H') {
        /* Hybrid triangle+splat segment: instant random access */
        ret = decode_hybrid_frame(dec, frame_index, local_buffer);
    } else {
        ret = QTSQ_ERR_STRATEGY; /* Unknown frame type */
    }

    if (ret == QTSQ_OK) {
        if (width) *width = dec->width;
        if (height) *height = dec->height;
    }

    return ret;
}

uint32_t qtsq_video_decoder_get_frame_count(qtsq_video_decoder_t *dec) {
    if (!dec) return 0;
    return dec->frame_count;
}

const qtsq_context_t* qtsq_video_decoder_get_context(qtsq_video_decoder_t *dec) {
    if (!dec) return NULL;
    return dec->ctx;
}

void qtsq_video_decoder_free(qtsq_video_decoder_t *dec) {
    if (!dec) return;
    if (dec->frame_offsets) free(dec->frame_offsets);
    if (dec->frame_sizes) free(dec->frame_sizes);
    if (dec->frame_types) free(dec->frame_types);
    if (dec->ref_frame) free(dec->ref_frame);
    if (dec->ref_splat_raw) free(dec->ref_splat_raw);
    if (dec->ref_splat_original) free(dec->ref_splat_original);
    if (dec->cached_seg_body) free(dec->cached_seg_body);
    if (dec->render_splats) free(dec->render_splats);
    if (dec->render_output) free(dec->render_output);
    if (dec->hybrid_verts) free(dec->hybrid_verts);
    if (dec->hybrid_faces) free(dec->hybrid_faces);
    if (dec->hybrid_splats) free(dec->hybrid_splats);
    for (int i = 0; i < 3; i++) {
        if (dec->ring_buffers[i]) free(dec->ring_buffers[i]);
    }
    free(dec);
}
