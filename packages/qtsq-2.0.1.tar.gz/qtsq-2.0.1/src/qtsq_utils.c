/*
 * Quantum Tensor Sequence — Utilities
 * SHA-256 (NIST FIPS 180-4), CRC-32 (IEEE 802.3), entropy.
 * Author: Haruhito
 */

#include "qtsq.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* SHA-256 */
static const uint32_t sha256_k[64] = {
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5,
    0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
    0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc,
    0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7,
    0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
    0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3,
    0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5,
    0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
    0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
};

#define ROTR(x, n)  (((x) >> (n)) | ((x) << (32 - (n))))
#define CH(x, y, z)  (((x) & (y)) ^ (~(x) & (z)))
#define MAJ(x, y, z) (((x) & (y)) ^ ((x) & (z)) ^ ((y) & (z)))
#define EP0(x)  (ROTR(x, 2)  ^ ROTR(x, 13) ^ ROTR(x, 22))
#define EP1(x)  (ROTR(x, 6)  ^ ROTR(x, 11) ^ ROTR(x, 25))
#define SIG0(x) (ROTR(x, 7)  ^ ROTR(x, 18) ^ ((x) >> 3))
#define SIG1(x) (ROTR(x, 17) ^ ROTR(x, 19) ^ ((x) >> 10))

void qtsq_sha256(const uint8_t *data, size_t len, uint8_t out[32]) {
    uint32_t h0 = 0x6a09e667, h1 = 0xbb67ae85;
    uint32_t h2 = 0x3c6ef372, h3 = 0xa54ff53a;
    uint32_t h4 = 0x510e527f, h5 = 0x9b05688c;
    uint32_t h6 = 0x1f83d9ab, h7 = 0x5be0cd19;

    size_t new_len = len + 1;
    while (new_len % 64 != 56) new_len++;
    new_len += 8;

    uint8_t *msg = (uint8_t *)calloc(new_len, 1);
    if (!msg) return;
    memcpy(msg, data, len);
    msg[len] = 0x80;

    uint64_t bits_len = (uint64_t)len * 8;
    for (int i = 0; i < 8; i++)
        msg[new_len - 1 - i] = (uint8_t)(bits_len >> (i * 8));

    for (size_t offset = 0; offset < new_len; offset += 64) {
        uint32_t w[64];
        for (int i = 0; i < 16; i++) {
            w[i] = ((uint32_t)msg[offset + i*4] << 24) |
                    ((uint32_t)msg[offset + i*4+1] << 16) |
                    ((uint32_t)msg[offset + i*4+2] << 8) |
                    ((uint32_t)msg[offset + i*4+3]);
        }
        for (int i = 16; i < 64; i++)
            w[i] = SIG1(w[i-2]) + w[i-7] + SIG0(w[i-15]) + w[i-16];

        uint32_t a = h0, b = h1, c = h2, d = h3;
        uint32_t e = h4, f = h5, g = h6, h = h7;

        for (int i = 0; i < 64; i++) {
            uint32_t t1 = h + EP1(e) + CH(e,f,g) + sha256_k[i] + w[i];
            uint32_t t2 = EP0(a) + MAJ(a,b,c);
            h = g; g = f; f = e; e = d + t1;
            d = c; c = b; b = a; a = t1 + t2;
        }

        h0 += a; h1 += b; h2 += c; h3 += d;
        h4 += e; h5 += f; h6 += g; h7 += h;
    }

    free(msg);

    uint32_t hash[8] = {h0, h1, h2, h3, h4, h5, h6, h7};
    for (int i = 0; i < 8; i++) {
        out[i*4]   = (hash[i] >> 24) & 0xFF;
        out[i*4+1] = (hash[i] >> 16) & 0xFF;
        out[i*4+2] = (hash[i] >> 8) & 0xFF;
        out[i*4+3] = hash[i] & 0xFF;
    }
}

/* CRC-32 */
static uint32_t crc32_table[256];
static int crc32_initialized = 0;

static void crc32_init_table(void) {
    for (uint32_t i = 0; i < 256; i++) {
        uint32_t c = i;
        for (int j = 0; j < 8; j++) {
            if (c & 1) c = 0xEDB88320 ^ (c >> 1);
            else c >>= 1;
        }
        crc32_table[i] = c;
    }
    crc32_initialized = 1;
}

uint32_t qtsq_crc32(const uint8_t *data, size_t len) {
    if (!crc32_initialized) crc32_init_table();
    uint32_t crc = 0xFFFFFFFF;
    for (size_t i = 0; i < len; i++)
        crc = crc32_table[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
    return crc ^ 0xFFFFFFFF;
}

/* Entropy */
double qtsq_entropy(const uint8_t *data, size_t len) {
    if (len == 0) return 0.0;
    uint64_t freq[256] = {0};
    for (size_t i = 0; i < len; i++) freq[data[i]]++;

    double entropy = 0.0;
    for (int i = 0; i < 256; i++) {
        if (freq[i] == 0) continue;
        double p = (double)freq[i] / (double)len;
        entropy -= p * log2(p);
    }
    return entropy;
}

/* Lifecycle */
int qtsq_init(qtsq_context_t *ctx) {
    if (!ctx) return QTSQ_ERR_NULL;
    memset(ctx, 0, sizeof(qtsq_context_t));

    ctx->header.magic[0] = QTSQ_MAGIC_0;
    ctx->header.magic[1] = QTSQ_MAGIC_1;
    ctx->header.magic[2] = QTSQ_MAGIC_2;
    ctx->header.magic[3] = QTSQ_MAGIC_3;
    ctx->header.version  = QTSQ_VERSION;

    return QTSQ_OK;
}

void qtsq_free(qtsq_context_t *ctx) {
    if (!ctx) return;
    if (ctx->transforms) {
        for (uint32_t i = 0; i < ctx->num_transforms; i++)
            free(ctx->transforms[i].params);
        free(ctx->transforms);
    }
    free(ctx->singularity);
    free(ctx->radiation_index);
    free(ctx->wormholes);
    free(ctx->recovery.chunk_checksums);
    free(ctx->recovery.reed_solomon_parity);
    memset(ctx, 0, sizeof(qtsq_context_t));
}

/* Error Strings */
const char* qtsq_error_string(int code) {
    switch (code) {
        case QTSQ_OK:              return "OK";
        case QTSQ_ERR_NULL:        return "Null pointer";
        case QTSQ_ERR_ALLOC:       return "Memory allocation failed";
        case QTSQ_ERR_IO:          return "File I/O error";
        case QTSQ_ERR_FORMAT:      return "Invalid .qtsq format";
        case QTSQ_ERR_CHECKSUM:    return "Checksum mismatch";
        case QTSQ_ERR_STRATEGY:    return "Unknown strategy";
        case QTSQ_ERR_TYPE:        return "Unknown data type";
        case QTSQ_ERR_ENCRYPTED:   return "Data encrypted, key required";
        case QTSQ_ERR_DECRYPT:     return "Decryption failed";
        case QTSQ_ERR_WORMHOLE:    return "Wormhole target not found";
        case QTSQ_ERR_WORMHOLE_HASH: return "Wormhole hash mismatch";
        case QTSQ_ERR_CORRUPT:     return "Data corruption detected";
        case QTSQ_ERR_RECOVERY_FAIL: return "Recovery failed";
        case QTSQ_ERR_TOO_SMALL:   return "Below Chandrasekhar limit";
        default:                  return "Unknown error";
    }
}

/* Inspection */
double qtsq_compression_ratio(const qtsq_context_t *ctx) {
    if (!ctx || ctx->header.singularity_size == 0) return 0.0;
    return (double)ctx->header.original_size / (double)ctx->header.singularity_size;
}

void qtsq_print_info(const qtsq_context_t *ctx) {
    if (!ctx) return;
    printf("=== Quantum Tensor Sequence (.qtsq) ===\n");
    printf("  Version:     %u\n", ctx->header.version);
    printf("  Data Type:   %s (0x%02X)\n",
           qtsq_type_name(ctx->header.data_type), ctx->header.data_type);
    printf("  Strategy:    %s (0x%02X)\n",
           qtsq_strategy_name(ctx->header.strategy), ctx->header.strategy);
    printf("  Channels:    %u\n", ctx->header.num_channels);
    printf("  Bit Depth:   %u\n", ctx->header.sample_depth);
    printf("  Original:    %llu bytes\n",
           (unsigned long long)ctx->header.original_size);
    printf("  Singularity: %llu bytes\n", (unsigned long long)ctx->header.singularity_size);
    printf("  Ratio:       %.1f:1\n", qtsq_compression_ratio(ctx));
    printf("  Flags:       0x%04X", ctx->header.flags);
    if (ctx->header.flags & QTSQ_FLAG_ENCRYPTED)     printf(" [ENCRYPTED]");
    if (ctx->header.flags & QTSQ_FLAG_HAS_WORMHOLES) printf(" [WORMHOLES]");
    if (ctx->header.flags & QTSQ_FLAG_HAS_ECC)       printf(" [ECC]");
    if (ctx->header.flags & QTSQ_FLAG_LOSSY)          printf(" [LOSSY]");
    if (ctx->header.flags & QTSQ_FLAG_REDSHIFTABLE)   printf(" [REDSHIFT]");
    printf("\n");
    printf("  Wormholes:   %u\n", ctx->num_wormholes);
    printf("==============================\n");
}
