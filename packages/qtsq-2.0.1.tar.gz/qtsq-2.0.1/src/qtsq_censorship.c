/*
 * Quantum Tensor Sequence — Cosmic Censorship Engine (Encryption)
 * Feature: Password-based encryption using custom AES-256 + GCM-like auth
 * Key derivation: PBKDF2-like iterative hashing
 * Author: Haruhito
 *
 * NOTE: This is a lightweight, self-contained implementation.
 * For production, link against OpenSSL/libsodium for validated AES-256-GCM.
 */

#include <string.h>
#include <stdlib.h>
#include "qtsq.h"

/* ══════════════════════════════════════════════════════════════
 *  Minimal AES-256 implementation (FIPS-197 compatible)
 *  Self-contained, no external dependencies.
 * ══════════════════════════════════════════════════════════════ */

/* AES S-Box */
static const uint8_t SBOX[256] = {
    0x63,0x7c,0x77,0x7b,0xf2,0x6b,0x6f,0xc5,0x30,0x01,0x67,0x2b,0xfe,0xd7,0xab,0x76,
    0xca,0x82,0xc9,0x7d,0xfa,0x59,0x47,0xf0,0xad,0xd4,0xa2,0xaf,0x9c,0xa4,0x72,0xc0,
    0xb7,0xfd,0x93,0x26,0x36,0x3f,0xf7,0xcc,0x34,0xa5,0xe5,0xf1,0x71,0xd8,0x31,0x15,
    0x04,0xc7,0x23,0xc3,0x18,0x96,0x05,0x9a,0x07,0x12,0x80,0xe2,0xeb,0x27,0xb2,0x75,
    0x09,0x83,0x2c,0x1a,0x1b,0x6e,0x5a,0xa0,0x52,0x3b,0xd6,0xb3,0x29,0xe3,0x2f,0x84,
    0x53,0xd1,0x00,0xed,0x20,0xfc,0xb1,0x5b,0x6a,0xcb,0xbe,0x39,0x4a,0x4c,0x58,0xcf,
    0xd0,0xef,0xaa,0xfb,0x43,0x4d,0x33,0x85,0x45,0xf9,0x02,0x7f,0x50,0x3c,0x9f,0xa8,
    0x51,0xa3,0x40,0x8f,0x92,0x9d,0x38,0xf5,0xbc,0xb6,0xda,0x21,0x10,0xff,0xf3,0xd2,
    0xcd,0x0c,0x13,0xec,0x5f,0x97,0x44,0x17,0xc4,0xa7,0x7e,0x3d,0x64,0x5d,0x19,0x73,
    0x60,0x81,0x4f,0xdc,0x22,0x2a,0x90,0x88,0x46,0xee,0xb8,0x14,0xde,0x5e,0x0b,0xdb,
    0xe0,0x32,0x3a,0x0a,0x49,0x06,0x24,0x5c,0xc2,0xd3,0xac,0x62,0x91,0x95,0xe4,0x79,
    0xe7,0xc8,0x37,0x6d,0x8d,0xd5,0x4e,0xa9,0x6c,0x56,0xf4,0xea,0x65,0x7a,0xae,0x08,
    0xba,0x78,0x25,0x2e,0x1c,0xa6,0xb4,0xc6,0xe8,0xdd,0x74,0x1f,0x4b,0xbd,0x8b,0x8a,
    0x70,0x3e,0xb5,0x66,0x48,0x03,0xf6,0x0e,0x61,0x35,0x57,0xb9,0x86,0xc1,0x1d,0x9e,
    0xe1,0xf8,0x98,0x11,0x69,0xd9,0x8e,0x94,0x9b,0x1e,0x87,0xe9,0xce,0x55,0x28,0xdf,
    0x8c,0xa1,0x89,0x0d,0xbf,0xe6,0x42,0x68,0x41,0x99,0x2d,0x0f,0xb0,0x54,0xbb,0x16,
};

/* AES Inverse S-Box */
static const uint8_t INV_SBOX[256] = {
    0x52,0x09,0x6a,0xd5,0x30,0x36,0xa5,0x38,0xbf,0x40,0xa3,0x9e,0x81,0xf3,0xd7,0xfb,
    0x7c,0xe3,0x39,0x82,0x9b,0x2f,0xff,0x87,0x34,0x8e,0x43,0x44,0xc4,0xde,0xe9,0xcb,
    0x54,0x7b,0x94,0x32,0xa6,0xc2,0x23,0x3d,0xee,0x4c,0x95,0x0b,0x42,0xfa,0xc3,0x4e,
    0x08,0x2e,0xa1,0x66,0x28,0xd9,0x24,0xb2,0x76,0x5b,0xa2,0x49,0x6d,0x8b,0xd1,0x25,
    0x72,0xf8,0xf6,0x64,0x86,0x68,0x98,0x16,0xd4,0xa4,0x5c,0xcc,0x5d,0x65,0xb6,0x92,
    0x6c,0x70,0x48,0x50,0xfd,0xed,0xb9,0xda,0x5e,0x15,0x46,0x57,0xa7,0x8d,0x9d,0x84,
    0x90,0xd8,0xab,0x00,0x8c,0xbc,0xd3,0x0a,0xf7,0xe4,0x58,0x05,0xb8,0xb3,0x45,0x06,
    0xd0,0x2c,0x1e,0x8f,0xca,0x3f,0x0f,0x02,0xc1,0xaf,0xbd,0x03,0x01,0x13,0x8a,0x6b,
    0x3a,0x91,0x11,0x41,0x4f,0x67,0xdc,0xea,0x97,0xf2,0xcf,0xce,0xf0,0xb4,0xe6,0x73,
    0x96,0xac,0x74,0x22,0xe7,0xad,0x35,0x85,0xe2,0xf9,0x37,0xe8,0x1c,0x75,0xdf,0x6e,
    0x47,0xf1,0x1a,0x71,0x1d,0x29,0xc5,0x89,0x6f,0xb7,0x62,0x0e,0xaa,0x18,0xbe,0x1b,
    0xfc,0x56,0x3e,0x4b,0xc6,0xd2,0x79,0x20,0x9a,0xdb,0xc0,0xfe,0x78,0xcd,0x5a,0xf4,
    0x1f,0xdd,0xa8,0x33,0x88,0x07,0xc7,0x31,0xb1,0x12,0x10,0x59,0x27,0x80,0xec,0x5f,
    0x60,0x51,0x7f,0xa9,0x19,0xb5,0x4a,0x0d,0x2d,0xe5,0x7a,0x9f,0x93,0xc9,0x9c,0xef,
    0xa0,0xe0,0x3b,0x4d,0xae,0x2a,0xf5,0xb0,0xc8,0xeb,0xbb,0x3c,0x83,0x53,0x99,0x61,
    0x17,0x2b,0x04,0x7e,0xba,0x77,0xd6,0x26,0xe1,0x69,0x14,0x63,0x55,0x21,0x0c,0x7d,
};

static const uint8_t RCON[10] = {
    0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x1b,0x36
};

/* GF(2^8) multiplication */
static uint8_t gmul(uint8_t a, uint8_t b) {
    uint8_t p = 0;
    for (int i = 0; i < 8; i++) {
        if (b & 1) p ^= a;
        uint8_t hi = a & 0x80;
        a <<= 1;
        if (hi) a ^= 0x1b;
        b >>= 1;
    }
    return p;
}

/* Key expansion for AES-256 (32-byte key → 240-byte expanded key) */
static void aes256_expand_key(const uint8_t key[32], uint8_t expanded[240]) {
    memcpy(expanded, key, 32);

    uint8_t temp[4];
    int bytes_generated = 32;
    int rcon_idx = 0;

    while (bytes_generated < 240) {
        memcpy(temp, expanded + bytes_generated - 4, 4);

        if (bytes_generated % 32 == 0) {
            /* RotWord */
            uint8_t t = temp[0];
            temp[0] = SBOX[temp[1]];
            temp[1] = SBOX[temp[2]];
            temp[2] = SBOX[temp[3]];
            temp[3] = SBOX[t];
            temp[0] ^= RCON[rcon_idx++];
        } else if (bytes_generated % 32 == 16) {
            for (int i = 0; i < 4; i++)
                temp[i] = SBOX[temp[i]];
        }

        for (int i = 0; i < 4; i++) {
            expanded[bytes_generated] = expanded[bytes_generated - 32] ^ temp[i];
            bytes_generated++;
        }
    }
}

/* AES-256 encrypt single 16-byte block */
static void aes256_encrypt_block(const uint8_t in[16], uint8_t out[16],
                                  const uint8_t expanded_key[240]) {
    uint8_t state[16];
    memcpy(state, in, 16);

    /* AddRoundKey (round 0) */
    for (int i = 0; i < 16; i++) state[i] ^= expanded_key[i];

    for (int round = 1; round <= 14; round++) {
        /* SubBytes */
        for (int i = 0; i < 16; i++) state[i] = SBOX[state[i]];

        /* ShiftRows */
        uint8_t tmp;
        tmp = state[1]; state[1] = state[5]; state[5] = state[9]; state[9] = state[13]; state[13] = tmp;
        tmp = state[2]; state[2] = state[10]; state[10] = tmp;
        tmp = state[6]; state[6] = state[14]; state[14] = tmp;
        tmp = state[15]; state[15] = state[11]; state[11] = state[7]; state[7] = state[3]; state[3] = tmp;

        /* MixColumns (skip on last round) */
        if (round < 14) {
            for (int c = 0; c < 4; c++) {
                int i = c * 4;
                uint8_t a0 = state[i], a1 = state[i+1], a2 = state[i+2], a3 = state[i+3];
                state[i]   = gmul(a0,2) ^ gmul(a1,3) ^ a2 ^ a3;
                state[i+1] = a0 ^ gmul(a1,2) ^ gmul(a2,3) ^ a3;
                state[i+2] = a0 ^ a1 ^ gmul(a2,2) ^ gmul(a3,3);
                state[i+3] = gmul(a0,3) ^ a1 ^ a2 ^ gmul(a3,2);
            }
        }

        /* AddRoundKey */
        for (int i = 0; i < 16; i++)
            state[i] ^= expanded_key[round * 16 + i];
    }

    memcpy(out, state, 16);
}

/* AES-256 decrypt single 16-byte block */
static void __attribute__((unused)) aes256_decrypt_block(const uint8_t in[16], uint8_t out[16],
                                  const uint8_t expanded_key[240]) {
    uint8_t state[16];
    memcpy(state, in, 16);

    /* AddRoundKey (round 14) */
    for (int i = 0; i < 16; i++) state[i] ^= expanded_key[14 * 16 + i];

    for (int round = 13; round >= 0; round--) {
        /* InvShiftRows */
        uint8_t tmp;
        tmp = state[13]; state[13] = state[9]; state[9] = state[5]; state[5] = state[1]; state[1] = tmp;
        tmp = state[10]; state[10] = state[2]; state[2] = tmp;
        tmp = state[14]; state[14] = state[6]; state[6] = tmp;
        tmp = state[3]; state[3] = state[7]; state[7] = state[11]; state[11] = state[15]; state[15] = tmp;

        /* InvSubBytes */
        for (int i = 0; i < 16; i++) state[i] = INV_SBOX[state[i]];

        /* AddRoundKey */
        for (int i = 0; i < 16; i++)
            state[i] ^= expanded_key[round * 16 + i];

        /* InvMixColumns (skip on round 0) */
        if (round > 0) {
            for (int c = 0; c < 4; c++) {
                int i = c * 4;
                uint8_t a0 = state[i], a1 = state[i+1], a2 = state[i+2], a3 = state[i+3];
                state[i]   = gmul(a0,14) ^ gmul(a1,11) ^ gmul(a2,13) ^ gmul(a3,9);
                state[i+1] = gmul(a0,9) ^ gmul(a1,14) ^ gmul(a2,11) ^ gmul(a3,13);
                state[i+2] = gmul(a0,13) ^ gmul(a1,9) ^ gmul(a2,14) ^ gmul(a3,11);
                state[i+3] = gmul(a0,11) ^ gmul(a1,13) ^ gmul(a2,9) ^ gmul(a3,14);
            }
        }
    }

    memcpy(out, state, 16);
}

/* ── CTR mode (Counter) for streaming encryption ── */

static void aes256_ctr(const uint8_t *in, uint8_t *out, size_t size,
                        const uint8_t key[32], const uint8_t iv[16]) {
    uint8_t expanded[240];
    aes256_expand_key(key, expanded);

    uint8_t counter[16];
    memcpy(counter, iv, 16);

    uint8_t keystream[16];
    size_t pos = 0;

    while (pos < size) {
        aes256_encrypt_block(counter, keystream, expanded);

        size_t block_len = size - pos;
        if (block_len > 16) block_len = 16;

        for (size_t i = 0; i < block_len; i++) {
            out[pos + i] = in[pos + i] ^ keystream[i];
        }
        pos += block_len;

        /* Increment counter (big-endian) */
        for (int i = 15; i >= 0; i--) {
            counter[i]++;
            if (counter[i] != 0) break;
        }
    }

    /* Wipe sensitive data */
    memset(expanded, 0, sizeof(expanded));
    memset(keystream, 0, sizeof(keystream));
}

/* ── PBKDF2-like key derivation (SHA-256 based) ── */

static void derive_key(const char *password, const uint8_t salt[16],
                        uint32_t iterations, uint8_t key[32]) {
    /* Simple iterative hash: key = SHA256(SHA256(...SHA256(password + salt))) */
    uint8_t buf[256];
    size_t pw_len = strlen(password);
    size_t buf_len = pw_len + 16;
    if (buf_len > sizeof(buf)) buf_len = sizeof(buf);

    memcpy(buf, password, pw_len);
    memcpy(buf + pw_len, salt, 16);

    qtsq_sha256(buf, buf_len, key);

    for (uint32_t i = 1; i < iterations; i++) {
        /* Hash the previous output concatenated with salt */
        memcpy(buf, key, 32);
        memcpy(buf + 32, salt, 16);
        qtsq_sha256(buf, 48, key);
    }

    memset(buf, 0, sizeof(buf));
}

/* ── Simple PRNG for IV/salt generation ── */

static void generate_random_bytes(uint8_t *out, size_t len) {
    /* Use a combination of address entropy + counter */
    /* In production, use /dev/urandom or a CSPRNG */
    static uint64_t counter = 0;
    uint64_t seed = (uint64_t)(uintptr_t)out ^ counter++;
    uint8_t hash[32];

    for (size_t i = 0; i < len; i += 32) {
        seed += 0x9E3779B97F4A7C15ULL;
        uint8_t seed_buf[8];
        memcpy(seed_buf, &seed, 8);
        qtsq_sha256(seed_buf, 8, hash);
        size_t to_copy = len - i;
        if (to_copy > 32) to_copy = 32;
        memcpy(out + i, hash, to_copy);
    }
}

/* ── Compute authentication tag ── */

static void compute_auth_tag(const uint8_t *ciphertext, size_t size,
                              const uint8_t key[32], uint8_t tag[16]) {
    /* HMAC-like: tag = SHA256(key || ciphertext)[0:16] */
    size_t buf_size = 32 + size;
    uint8_t *buf = (uint8_t *)malloc(buf_size);
    if (!buf) {
        memset(tag, 0, 16);
        return;
    }

    memcpy(buf, key, 32);
    memcpy(buf + 32, ciphertext, size);

    uint8_t hash[32];
    qtsq_sha256(buf, buf_size, hash);
    memcpy(tag, hash, 16);

    memset(buf, 0, buf_size);
    free(buf);
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_encrypt
 * ══════════════════════════════════════════════════════════════ */

int qtsq_encrypt(qtsq_context_t *ctx, const char *password) {
    if (!ctx || !password) return QTSQ_ERR_NULL;
    if (!ctx->singularity || ctx->singularity_size == 0) return QTSQ_ERR_FORMAT;
    if (ctx->is_encrypted) return QTSQ_OK; /* already encrypted */

    /* Generate random IV and salt */
    generate_random_bytes(ctx->censorship.iv, 16);
    generate_random_bytes(ctx->censorship.salt, 16);
    ctx->censorship.iterations = 100000;

    /* Derive AES-256 key from password */
    uint8_t key[32];
    derive_key(password, ctx->censorship.salt,
               ctx->censorship.iterations, key);

    /* Encrypt singularity data in-place using CTR mode */
    uint8_t *ciphertext = (uint8_t *)malloc(ctx->singularity_size);
    if (!ciphertext) { memset(key, 0, 32); return QTSQ_ERR_ALLOC; }

    aes256_ctr(ctx->singularity, ciphertext, ctx->singularity_size,
               key, ctx->censorship.iv);

    /* Compute authentication tag */
    compute_auth_tag(ciphertext, ctx->singularity_size, key,
                     ctx->censorship.auth_tag);

    /* Replace singularity with ciphertext */
    memcpy(ctx->singularity, ciphertext, ctx->singularity_size);
    free(ciphertext);

    /* Mark as encrypted */
    ctx->is_encrypted = 1;
    ctx->header.flags |= QTSQ_FLAG_ENCRYPTED;

    /* Wipe key */
    memset(key, 0, 32);

    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_decrypt
 * ══════════════════════════════════════════════════════════════ */

int qtsq_decrypt(qtsq_context_t *ctx, const char *password) {
    if (!ctx || !password) return QTSQ_ERR_NULL;
    if (!ctx->is_encrypted) return QTSQ_OK; /* not encrypted */
    if (!ctx->singularity || ctx->singularity_size == 0) return QTSQ_ERR_FORMAT;

    /* Derive key from password */
    uint8_t key[32];
    derive_key(password, ctx->censorship.salt,
               ctx->censorship.iterations, key);

    /* Verify authentication tag before decrypting */
    uint8_t computed_tag[16];
    compute_auth_tag(ctx->singularity, ctx->singularity_size,
                     key, computed_tag);

    if (memcmp(computed_tag, ctx->censorship.auth_tag, 16) != 0) {
        memset(key, 0, 32);
        return QTSQ_ERR_DECRYPT; /* wrong password or tampered data */
    }

    /* Decrypt in-place using CTR mode (CTR is symmetric) */
    uint8_t *plaintext = (uint8_t *)malloc(ctx->singularity_size);
    if (!plaintext) { memset(key, 0, 32); return QTSQ_ERR_ALLOC; }

    aes256_ctr(ctx->singularity, plaintext, ctx->singularity_size,
               key, ctx->censorship.iv);

    memcpy(ctx->singularity, plaintext, ctx->singularity_size);
    free(plaintext);

    /* Mark as decrypted */
    ctx->is_encrypted = 0;
    ctx->header.flags &= ~QTSQ_FLAG_ENCRYPTED;

    memset(key, 0, 32);
    return QTSQ_OK;
}

/* ══════════════════════════════════════════════════════════════
 *  PUBLIC API: qtsq_is_encrypted
 * ══════════════════════════════════════════════════════════════ */

int qtsq_is_encrypted(const qtsq_context_t *ctx) {
    if (!ctx) return 0;
    return ctx->is_encrypted;
}
