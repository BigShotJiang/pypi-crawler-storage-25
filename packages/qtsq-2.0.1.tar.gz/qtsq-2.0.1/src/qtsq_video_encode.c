#include "qtsq.h"
#include "qtsq_splat2d.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "qtsq_parallel.h"
#include <zlib.h>

#ifdef __APPLE__
#include "qtsq_metal.h"
#endif

#define QTSQ_VIDEO_BATCH_MAX 32

/* ── Scene Splat Video Configuration ── */
#define SCENE_SPLAT_MAX         600000  /* Max splats per segment */
#define COLOR_KF_INTERVAL       10      /* Color keyframe every N frames */
#define STATIC_VARIANCE_THRESHOLD 20    /* Max per-channel variance to classify as static */
#define SCENE_CUT_THRESHOLD     0.60f   /* Frame-diff ratio that triggers a new segment */

typedef struct {
    qtsq_video_encoder_t *enc;
    uint8_t *raw_pixels;
    int frame_index;
    int ret_code;
    uint8_t *compressed_data;
    size_t compressed_size;
    uint8_t frame_type;
    uint8_t *delta_buffer;
    float change_ratio;
} batch_job_t;

struct qtsq_video_encoder {
    qtsq_context_t *ctx;
    uint32_t width;
    uint32_t height;
    uint8_t channels;
    uint32_t fps;
    int strategy_flags;
    size_t target_payload_per_frame;

    uint32_t frame_count;     /* Total frames encoded so far */

    uint8_t *bitstream;
    size_t bitstream_size;
    size_t bitstream_capacity;

    uint32_t *frame_offsets;
    uint32_t *frame_sizes;
    uint8_t  *frame_types;
    size_t index_capacity;

    /* ── Scene-level splat buffering ── */
    uint8_t **frame_buffer;       /* Array of pointers to buffered frame pixels */
    uint32_t frame_buffer_count;  /* Frames currently buffered */
    uint32_t segment_size;        /* Max frames per segment (fps × 2) */

    /* Legacy batch processing (kept for fallback K-frame) */
    batch_job_t batch[QTSQ_VIDEO_BATCH_MAX];
    int batch_count;
    int batch_capacity;

    /* Reference frame for scene-cut detection */
    uint8_t *ref_frame;
    int has_ref_frame;

    /* Legacy splat refs (kept for compatibility) */
    uint8_t *ref_splat_input;
    uint8_t *ref_splat_colors;
    uint32_t ref_splat_count;
};


static int append_to_bitstream(qtsq_video_encoder_t *enc, const uint8_t *data, size_t size) {
    if (enc->bitstream_size + size > enc->bitstream_capacity) {
        size_t new_cap = enc->bitstream_capacity * 2;
        if (new_cap < enc->bitstream_size + size + 1024 * 1024) {
            new_cap = enc->bitstream_size + size + 1024 * 1024;
        }
        uint8_t *new_buf = (uint8_t *)realloc(enc->bitstream, new_cap);
        if (!new_buf) return QTSQ_ERR_ALLOC;
        enc->bitstream = new_buf;
        enc->bitstream_capacity = new_cap;
    }
    memcpy(enc->bitstream + enc->bitstream_size, data, size);
    enc->bitstream_size += size;
    return QTSQ_OK;
}

static int append_to_index(qtsq_video_encoder_t *enc, uint32_t offset, uint32_t size, uint8_t type) {
    if (enc->frame_count >= enc->index_capacity) {
        size_t new_cap = enc->index_capacity == 0 ? 600 : enc->index_capacity * 2;
        uint32_t *new_offsets = (uint32_t *)realloc(enc->frame_offsets, new_cap * sizeof(uint32_t));
        uint32_t *new_sizes = (uint32_t *)realloc(enc->frame_sizes, new_cap * sizeof(uint32_t));
        uint8_t *new_types = (uint8_t *)realloc(enc->frame_types, new_cap * sizeof(uint8_t));
        if (!new_offsets || !new_sizes || !new_types) return QTSQ_ERR_ALLOC;

        enc->frame_offsets = new_offsets;
        enc->frame_sizes = new_sizes;
        enc->frame_types = new_types;
        enc->index_capacity = new_cap;
    }
    enc->frame_offsets[enc->frame_count] = offset;
    enc->frame_sizes[enc->frame_count] = size;
    enc->frame_types[enc->frame_count] = type;
    enc->frame_count++;
    return QTSQ_OK;
}

qtsq_video_encoder_t* qtsq_video_encoder_create(qtsq_context_t *ctx,
                                                uint32_t width, uint32_t height,
                                                uint8_t channels, uint32_t fps,
                                                int strategy_flags,
                                                size_t target_payload_per_frame) {
    if (!ctx) return NULL;
    qtsq_video_encoder_t *enc = (qtsq_video_encoder_t *)calloc(1, sizeof(qtsq_video_encoder_t));
    if (!enc) return NULL;

    enc->ctx = ctx;
    enc->width = width;
    enc->height = height;
    enc->channels = channels;
    enc->fps = fps > 0 ? fps : 24;
    enc->strategy_flags = strategy_flags;
    enc->target_payload_per_frame = target_payload_per_frame;

    /* Batch frames into 2-second segments to avoid excessive RAM usage.
     * The decoder decompresses once per segment, interpolating colors per frame. */
    enc->segment_size = enc->fps * 2;
    if (enc->segment_size < 12) enc->segment_size = 12;

    /* Allocate frame buffer (pointer array — pixels allocated per frame in add_frame) */
    enc->frame_buffer = (uint8_t **)calloc(enc->segment_size, sizeof(uint8_t *));
    enc->frame_buffer_count = 0;

    enc->batch_capacity = qtsq_num_cores();
    if (enc->batch_capacity > QTSQ_VIDEO_BATCH_MAX) enc->batch_capacity = QTSQ_VIDEO_BATCH_MAX;
    if (enc->batch_capacity < 1) enc->batch_capacity = 1;
    enc->batch_count = 0;

    /* Initialize bitstream with 1MB minimum */
    enc->bitstream_capacity = 1024 * 1024;
    enc->bitstream = (uint8_t *)malloc(enc->bitstream_capacity);
    enc->bitstream_size = 0;

    /* Reference frame for scene-cut detection */
    size_t frame_bytes = (size_t)width * height * channels;
    enc->ref_frame = (uint8_t *)calloc(1, frame_bytes);
    enc->has_ref_frame = 0;

    /* Prep context */
    ctx->header.data_type = QTSQ_TYPE_VIDEO_FRAMES;
    ctx->header.strategy = QTSQ_STRATEGY_TEMPORAL;
    ctx->header.flags = strategy_flags;

    strcpy(ctx->schema.name, "QTSQ_VIDEO_STREAM");
    ctx->schema.data_type = QTSQ_TYPE_VIDEO_FRAMES;
    ctx->schema.dimensions[0] = width;
    ctx->schema.dimensions[1] = height;
    ctx->schema.dimensions[2] = channels;
    ctx->schema.num_dims = 3;
    ctx->schema.frame_rate = enc->fps;

    return enc;
}

static int cmp_splat_y(const void *a, const void *b) {
    const splat2d_t *sa = (const splat2d_t *)a;
    const splat2d_t *sb = (const splat2d_t *)b;
    if (sa->y < sb->y) return -1;
    if (sa->y > sb->y) return 1;
    if (sa->x < sb->x) return -1;
    if (sa->x > sb->x) return 1;
    return 0;
}

/* ═══════════════════════════════════════════════════════════
 *  ADAPTIVE QUAD-TREE SPLAT GENERATOR
 * ═══════════════════════════════════════════════════════════ */
static int quadtree_splats(const uint8_t *img, int w, int h, int ch, 
                           int bx, int by, int bw, int bh, 
                           splat2d_t *out, uint32_t *count, uint32_t max_count) {
    if (*count >= max_count) return 0;
    if (bx >= w || by >= h) return 0;
    
    int actual_w = (bx + bw > w) ? w - bx : bw;
    int actual_h = (by + bh > h) ? h - by : bh;
    
    uint8_t min_r = 255, max_r = 0, min_g = 255, max_g = 0, min_b = 255, max_b = 0;
    uint32_t sum_r = 0, sum_g = 0, sum_b = 0;
    
    for (int y = by; y < by + actual_h; y++) {
        for (int x = bx; x < bx + actual_w; x++) {
            size_t idx = ((size_t)y * w + x) * ch;
            uint8_t r = img[idx];
            uint8_t g = (ch>1) ? img[idx+1] : r;
            uint8_t b = (ch>2) ? img[idx+2] : r;
            if (r < min_r) min_r = r; if (r > max_r) max_r = r;
            if (g < min_g) min_g = g; if (g > max_g) max_g = g;
            if (b < min_b) min_b = b; if (b > max_b) max_b = b;
            sum_r += r; sum_g += g; sum_b += b;
        }
    }
    
    int range = (max_r - min_r) + (max_g - min_g) + (max_b - min_b);
    int pixels = actual_w * actual_h;
    if (pixels == 0) return 0;
    
    /* Place splat if variance is extremely low OR block reached physical pixel limit (2x2) */
    if (range < 15 || bw <= 2 || actual_w <= 2 || actual_h <= 2) {
        uint32_t idx = (*count)++;
        out[idx].x = (uint16_t)(bx + actual_w / 2);
        out[idx].y = (uint16_t)(by + actual_h / 2);
        
        float radius = (float)(bw > bh ? bw : bh) / 2.0f;
        out[idx].sx = (uint8_t)(radius * 1.8f); /* 80% overlap for extremely dense blending */
        if (out[idx].sx < 2) out[idx].sx = 2;
        out[idx].sy = out[idx].sx;
        
        out[idx].theta = 0;
        out[idx].alpha = 255;
        out[idx].z = 0;
        return 1;
    }
    
    /* Subdivide into 4 quadrants */
    int half_w = bw / 2, half_h = bh / 2;
    quadtree_splats(img, w, h, ch, bx, by, half_w, half_h, out, count, max_count);
    quadtree_splats(img, w, h, ch, bx + half_w, by, half_w, half_h, out, count, max_count);
    quadtree_splats(img, w, h, ch, bx, by + half_h, half_w, half_h, out, count, max_count);
    quadtree_splats(img, w, h, ch, bx + half_w, by + half_h, half_w, half_h, out, count, max_count);
    
    return 1;
}

/* ═══════════════════════════════════════════════════════════
 *  SCENE-LEVEL GAUSSIAN SPLAT SEGMENT ENCODER
 *
 *  This is the core of QTSQ video — it encodes a 2-second segment
 *  as a persistent 2D splat scene with temporal color evolution.
 *
 *  SEGMENT FORMAT ('V' type):
 *    Header:
 *      [4B: 'SCEN']
 *      [2B: width] [2B: height]
 *      [4B: num_total_splats]
 *      [4B: num_static]
 *      [4B: num_dynamic]
 *      [4B: segment_frame_count]
 *      [1B: num_color_keyframes]
 *      [1B: color_kf_interval]
 *      = 24 bytes header
 *    Body (zlib compressed):
 *      [5B × num_total: positions — x(2) y(2) radius(1)]
 *      [3B × num_static: static colors — r g b]
 *      [3B × num_kf × num_dynamic: dynamic keyframe colors]
 * ═══════════════════════════════════════════════════════════ */

/* Forward declarations for functions from qtsq_gravitational.c */
extern uint32_t delaunay_triangulate(tri_vertex_t *verts, uint32_t nv,
                                      tri_face_t *faces, uint32_t max_faces,
                                      uint32_t img_w, uint32_t img_h);

/* ═══════════════════════════════════════════════════════════
 *  HYBRID TRIANGLE + SPLAT SEGMENT ENCODER
 *
 *  Encodes a segment as:
 *   - ~80% triangles (sharp edges, detail) — hardware-accelerated decode
 *   - ~20% splats (smooth gradients) — Gaussian blending decode
 *
 *  Focus: MAXIMUM QUALITY. No compression aggressiveness.
 *
 *  SEGMENT FORMAT ('H' type — Hybrid Scene):
 *    Header (40 bytes):
 *      [4B: 'HSCN']
 *      [2B: width] [2B: height]
 *      [4B: num_vertices]
 *      [4B: num_faces]
 *      [4B: num_splats]
 *      [4B: num_static_verts]
 *      [4B: num_static_splats]
 *      [2B: segment_frame_count]
 *      [1B: num_color_keyframes]
 *      [1B: color_kf_interval]
 *      [4B: reserved]
 *    Body (zlib compressed):
 *      [vertex positions: 4B × num_verts (u16 x, u16 y)]
 *      [face indices: 6B × num_faces (u16 v0, v1, v2)]
 *      [splat positions: 5B × num_splats (u16 x, u16 y, u8 radius)]
 *      [static vertex colors: 3B × num_static_verts]
 *      [static splat colors: 3B × num_static_splats]
 *      [dynamic vertex kf colors: 3B × num_kf × num_dynamic_verts]
 *      [dynamic splat kf colors: 3B × num_kf × num_dynamic_splats]
 * ═══════════════════════════════════════════════════════════ */
static int flush_segment(qtsq_video_encoder_t *enc) {
    if (enc->frame_buffer_count == 0) return QTSQ_OK;

    uint32_t w = enc->width, h = enc->height;
    uint8_t ch = enc->channels;
    size_t frame_bytes = (size_t)w * h * ch;
    uint32_t seg_frames = enc->frame_buffer_count;
    uint8_t *first_frame = enc->frame_buffer[0];

    fprintf(stderr, "[QTSQ Hybrid] Encoding segment: %u frames, %ux%u\n", seg_frames, w, h);

    /* ═══ PHASE 1: Compute Gradient (Sobel) ═══ */
    size_t pixel_count = (size_t)w * h;
    float *grad = (float *)calloc(pixel_count, sizeof(float));
    if (!grad) goto fail;

#ifdef __APPLE__
    {
        qtsq_metal_ctx_t *metal = qtsq_metal_global();
        if (metal) {
            qtsq_metal_sobel(metal, first_frame, grad, w, h, ch);
        }
    }
#endif
    /* CPU fallback: simple magnitude computation */
    if (grad[w + 1] == 0.0f && grad[w * 2 + 2] == 0.0f) {
        /* GPU didn't fill it, do CPU Sobel */
        for (uint32_t y = 1; y < h - 1; y++) {
            for (uint32_t x = 1; x < w - 1; x++) {
                float gx = 0, gy = 0;
                for (uint8_t c = 0; c < ch; c++) {
                    float dx = -(float)first_frame[((y-1)*w + (x-1))*ch + c]
                               + (float)first_frame[((y-1)*w + (x+1))*ch + c]
                               - 2.0f*(float)first_frame[(y*w + (x-1))*ch + c]
                               + 2.0f*(float)first_frame[(y*w + (x+1))*ch + c]
                               - (float)first_frame[((y+1)*w + (x-1))*ch + c]
                               + (float)first_frame[((y+1)*w + (x+1))*ch + c];
                    float dy = -(float)first_frame[((y-1)*w + (x-1))*ch + c]
                               - 2.0f*(float)first_frame[((y-1)*w + x)*ch + c]
                               - (float)first_frame[((y-1)*w + (x+1))*ch + c]
                               + (float)first_frame[((y+1)*w + (x-1))*ch + c]
                               + 2.0f*(float)first_frame[((y+1)*w + x)*ch + c]
                               + (float)first_frame[((y+1)*w + (x+1))*ch + c];
                    gx += dx * dx;
                    gy += dy * dy;
                }
                grad[y * w + x] = sqrtf(gx + gy);
            }
        }
    }

    fprintf(stderr, "[QTSQ Hybrid] Phase 1: Gradient computed\n");

    /* ═══ PHASE 2: Vertex Placement ═══
     * For maximum quality: high density — up to 500K vertices for 1080p */
    uint32_t max_verts = (uint32_t)(pixel_count / 4);  /* ~1 vertex per 4 pixels */
    if (max_verts > 500000) max_verts = 500000;
    if (max_verts < 50000) max_verts = 50000;

    tri_vertex_t *verts = (tri_vertex_t *)malloc((max_verts + 3) * sizeof(tri_vertex_t)); /* +3 for super-triangle */
    uint8_t *used = (uint8_t *)calloc(pixel_count, sizeof(uint8_t));
    if (!verts || !used) { free(verts); free(used); free(grad); goto fail; }

    /* Place vertices using gradient-weighted density */
    uint32_t nv = 0;

    /* 40% uniform grid for baseline coverage */
    uint32_t grid_budget = (uint32_t)(max_verts * 0.40f);
    int grid_step = (int)ceil(sqrt((double)pixel_count / (double)(grid_budget > 0 ? grid_budget : 1)));
    if (grid_step < 1) grid_step = 1;

    for (uint32_t y = 0; y < h && nv < grid_budget; y += grid_step) {
        for (uint32_t x = 0; x < w && nv < grid_budget; x += grid_step) {
            if (used[y * w + x]) continue;
            used[y * w + x] = 1;
            size_t idx = ((size_t)y * w + x) * ch;
            verts[nv].x = (float)x;
            verts[nv].y = (float)y;
            verts[nv].r = first_frame[idx];
            verts[nv].g = (ch >= 2) ? first_frame[idx + 1] : first_frame[idx];
            verts[nv].b = (ch >= 3) ? first_frame[idx + 2] : first_frame[idx];
            nv++;
        }
    }

    /* Boundary vertices */
    int bnd_step = grid_step;
    for (uint32_t y = 0; y < h && nv < max_verts; y += bnd_step) {
        if (!used[y * w + 0]) {
            used[y * w + 0] = 1;
            size_t idx = ((size_t)y * w) * ch;
            verts[nv].x = 0; verts[nv].y = (float)y;
            verts[nv].r = first_frame[idx];
            verts[nv].g = (ch >= 2) ? first_frame[idx+1] : first_frame[idx];
            verts[nv].b = (ch >= 3) ? first_frame[idx+2] : first_frame[idx];
            nv++;
        }
        if (nv < max_verts && !used[y * w + (w-1)]) {
            used[y * w + (w-1)] = 1;
            size_t idx = ((size_t)y * w + (w-1)) * ch;
            verts[nv].x = (float)(w-1); verts[nv].y = (float)y;
            verts[nv].r = first_frame[idx];
            verts[nv].g = (ch >= 2) ? first_frame[idx+1] : first_frame[idx];
            verts[nv].b = (ch >= 3) ? first_frame[idx+2] : first_frame[idx];
            nv++;
        }
    }
    for (uint32_t x = 0; x < w && nv < max_verts; x += bnd_step) {
        if (!used[x]) {
            used[x] = 1;
            size_t idx = (size_t)x * ch;
            verts[nv].x = (float)x; verts[nv].y = 0;
            verts[nv].r = first_frame[idx];
            verts[nv].g = (ch >= 2) ? first_frame[idx+1] : first_frame[idx];
            verts[nv].b = (ch >= 3) ? first_frame[idx+2] : first_frame[idx];
            nv++;
        }
        if (nv < max_verts && !used[(h-1) * w + x]) {
            used[(h-1) * w + x] = 1;
            size_t idx = ((size_t)(h-1) * w + x) * ch;
            verts[nv].x = (float)x; verts[nv].y = (float)(h-1);
            verts[nv].r = first_frame[idx];
            verts[nv].g = (ch >= 2) ? first_frame[idx+1] : first_frame[idx];
            verts[nv].b = (ch >= 3) ? first_frame[idx+2] : first_frame[idx];
            nv++;
        }
    }

    /* 60% edge-biased placement via error diffusion */
    {
        double sum_grad = 0.0;
        for (uint32_t y = 2; y < h - 2; y++) {
            for (uint32_t x = 2; x < w - 2; x++) {
                if (!used[y * w + x]) sum_grad += (double)grad[y * w + x];
            }
        }
        uint32_t edge_budget = max_verts - nv;
        double grad_per_vert = sum_grad / (double)(edge_budget > 0 ? edge_budget : 1);
        if (grad_per_vert < 0.0001) grad_per_vert = 1.0;

        double error_acc = 0.0;
        for (uint32_t y = 2; y < h - 2 && nv < max_verts; y++) {
            for (uint32_t x = 2; x < w - 2 && nv < max_verts; x++) {
                if (used[y * w + x]) continue;
                error_acc += (double)grad[y * w + x];
                if (error_acc >= grad_per_vert) {
                    used[y * w + x] = 1;
                    size_t idx = ((size_t)y * w + x) * ch;
                    verts[nv].x = (float)x;
                    verts[nv].y = (float)y;
                    verts[nv].r = first_frame[idx];
                    verts[nv].g = (ch >= 2) ? first_frame[idx+1] : first_frame[idx];
                    verts[nv].b = (ch >= 3) ? first_frame[idx+2] : first_frame[idx];
                    nv++;
                    error_acc -= grad_per_vert;
                }
            }
        }
    }

    free(used);
    fprintf(stderr, "[QTSQ Hybrid] Phase 2: %u vertices placed\n", nv);

    /* ═══ PHASE 3: Delaunay Triangulation ═══ */
    uint32_t max_faces = nv * 3;
    tri_face_t *faces = (tri_face_t *)malloc(max_faces * sizeof(tri_face_t));
    if (!faces) { free(verts); free(grad); goto fail; }

    uint32_t nf = delaunay_triangulate(verts, nv, faces, max_faces, w, h);
    fprintf(stderr, "[QTSQ Hybrid] Phase 3: %u faces triangulated\n", nf);

    /* ═══ PHASE 4: Splat Fitting (smooth regions only) ═══
     * Use adaptive quadtree but only in low-gradient regions */
    uint32_t max_splats = 50000;
    splat2d_t *splats = (splat2d_t *)calloc(max_splats, sizeof(splat2d_t));
    uint32_t num_splats = 0;
    if (!splats) { free(faces); free(verts); free(grad); goto fail; }

    /* Only place splats in blocks where gradient is below median */
    float *sorted_grad = (float *)malloc(pixel_count * sizeof(float));
    if (sorted_grad) {
        memcpy(sorted_grad, grad, pixel_count * sizeof(float));
        /* Find approximate median using sampling */
        float grad_threshold = 0;
        {
            double total = 0;
            uint32_t samples = 0;
            for (uint32_t i = 0; i < pixel_count; i += 64) {
                total += grad[i];
                samples++;
            }
            grad_threshold = (float)(total / (double)(samples > 0 ? samples : 1)) * 0.5f;
        }
        free(sorted_grad);

        /* Quadtree splats only in smooth areas */
        for (uint32_t y = 0; y < h; y += 32) {
            for (uint32_t x = 0; x < w; x += 32) {
                /* Check if this block is smooth (below gradient threshold) */
                float block_grad = 0;
                int count = 0;
                uint32_t by = y, bx = x;
                uint32_t bh2 = (by + 32 < h) ? 32 : h - by;
                uint32_t bw2 = (bx + 32 < w) ? 32 : w - bx;
                for (uint32_t py = by; py < by + bh2; py += 4) {
                    for (uint32_t px = bx; px < bx + bw2; px += 4) {
                        block_grad += grad[py * w + px];
                        count++;
                    }
                }
                if (count > 0 && (block_grad / count) < grad_threshold) {
                    quadtree_splats(first_frame, w, h, ch, x, y, 32, 32,
                                    splats, &num_splats, max_splats);
                }
            }
        }
    }
    free(grad);

    /* Sort splats by Y for consistent rendering */
    if (num_splats > 0) {
        qsort(splats, num_splats, sizeof(splat2d_t), cmp_splat_y);
    }

    fprintf(stderr, "[QTSQ Hybrid] Phase 4: %u splats in smooth regions\n", num_splats);

    /* ═══ PHASE 5: Per-Frame Color Sampling + Classification ═══
     * Sample vertex colors and splat colors from every frame.
     * Classify as static (constant across frames) or dynamic. */

    /* Vertex colors: [seg_frames × nv × 3] */
    uint8_t *vert_colors = (uint8_t *)calloc((size_t)seg_frames * nv * 3, 1);
    if (!vert_colors) { free(splats); free(faces); free(verts); goto fail; }

    for (uint32_t f = 0; f < seg_frames; f++) {
        uint8_t *frame = enc->frame_buffer[f];
        uint8_t *vc = vert_colors + (size_t)f * nv * 3;
        for (uint32_t v = 0; v < nv; v++) {
            uint32_t vx = (uint32_t)(verts[v].x + 0.5f);
            uint32_t vy = (uint32_t)(verts[v].y + 0.5f);
            if (vx >= w) vx = w - 1;
            if (vy >= h) vy = h - 1;
            size_t pidx = ((size_t)vy * w + vx) * ch;
            vc[v * 3]     = frame[pidx];
            vc[v * 3 + 1] = (ch >= 2) ? frame[pidx + 1] : frame[pidx];
            vc[v * 3 + 2] = (ch >= 3) ? frame[pidx + 2] : frame[pidx];
        }
    }

    /* Splat colors: [seg_frames × num_splats × 3] */
    uint8_t *splat_colors = NULL;
    if (num_splats > 0) {
        splat_colors = (uint8_t *)calloc((size_t)seg_frames * num_splats * 3, 1);
        if (!splat_colors) { free(vert_colors); free(splats); free(faces); free(verts); goto fail; }

        /* Pack splat positions for GPU color sampler */
        uint8_t *splat_packed = (uint8_t *)malloc((size_t)num_splats * 5);
        if (splat_packed) {
            for (uint32_t i = 0; i < num_splats; i++) {
                uint16_t sx = splats[i].x, sy = splats[i].y;
                uint8_t sr = splats[i].sx > 0 ? splats[i].sx : 2;
                memcpy(splat_packed + i * 5, &sx, 2);
                memcpy(splat_packed + i * 5 + 2, &sy, 2);
                splat_packed[i * 5 + 4] = sr;
            }

            for (uint32_t f = 0; f < seg_frames; f++) {
                uint8_t *sc = splat_colors + (size_t)f * num_splats * 3;
#ifdef __APPLE__
                qtsq_metal_ctx_t *metal = qtsq_metal_global();
                if (metal) {
                    qtsq_metal_splat_color_sample(metal, splat_packed, num_splats,
                                                   enc->frame_buffer[f], sc, w, h, ch);
                } else
#endif
                {
                    for (uint32_t s = 0; s < num_splats; s++) {
                        uint16_t sx, sy;
                        memcpy(&sx, splat_packed + s * 5, 2);
                        memcpy(&sy, splat_packed + s * 5 + 2, 2);
                        if (sx < w && sy < h) {
                            size_t pidx = ((size_t)sy * w + sx) * ch;
                            sc[s * 3]     = enc->frame_buffer[f][pidx];
                            sc[s * 3 + 1] = enc->frame_buffer[f][pidx + 1];
                            sc[s * 3 + 2] = enc->frame_buffer[f][pidx + 2];
                        }
                    }
                }
            }
            free(splat_packed);
        }
    }

    fprintf(stderr, "[QTSQ Hybrid] Phase 5: Colors sampled from %u frames\n", seg_frames);

    /* ── Classify vertices: static vs dynamic ── */
    uint8_t *vert_is_dynamic = (uint8_t *)calloc(nv, 1);
    uint32_t num_static_verts = 0, num_dynamic_verts = 0;
    if (!vert_is_dynamic) { free(splat_colors); free(vert_colors); free(splats); free(faces); free(verts); goto fail; }

    for (uint32_t v = 0; v < nv; v++) {
        uint8_t min_r = 255, min_g = 255, min_b = 255;
        uint8_t max_r = 0, max_g = 0, max_b = 0;
        for (uint32_t f = 0; f < seg_frames; f++) {
            uint8_t *c = vert_colors + (size_t)f * nv * 3 + v * 3;
            if (c[0] < min_r) min_r = c[0]; if (c[0] > max_r) max_r = c[0];
            if (c[1] < min_g) min_g = c[1]; if (c[1] > max_g) max_g = c[1];
            if (c[2] < min_b) min_b = c[2]; if (c[2] > max_b) max_b = c[2];
        }
        int range = (int)(max_r - min_r) + (int)(max_g - min_g) + (int)(max_b - min_b);
        if (range > STATIC_VARIANCE_THRESHOLD * 3) {
            vert_is_dynamic[v] = 1;
            num_dynamic_verts++;
        } else {
            num_static_verts++;
        }
    }

    /* ── Classify splats: static vs dynamic ── */
    uint8_t *splat_is_dynamic = NULL;
    uint32_t num_static_splats = 0, num_dynamic_splats = 0;
    if (num_splats > 0) {
        splat_is_dynamic = (uint8_t *)calloc(num_splats, 1);
        if (!splat_is_dynamic) { free(vert_is_dynamic); free(splat_colors); free(vert_colors); free(splats); free(faces); free(verts); goto fail; }

        for (uint32_t s = 0; s < num_splats; s++) {
            uint8_t min_r = 255, min_g = 255, min_b = 255;
            uint8_t max_r = 0, max_g = 0, max_b = 0;
            for (uint32_t f = 0; f < seg_frames; f++) {
                uint8_t *c = splat_colors + (size_t)f * num_splats * 3 + s * 3;
                if (c[0] < min_r) min_r = c[0]; if (c[0] > max_r) max_r = c[0];
                if (c[1] < min_g) min_g = c[1]; if (c[1] > max_g) max_g = c[1];
                if (c[2] < min_b) min_b = c[2]; if (c[2] > max_b) max_b = c[2];
            }
            int range = (int)(max_r - min_r) + (int)(max_g - min_g) + (int)(max_b - min_b);
            if (range > STATIC_VARIANCE_THRESHOLD * 3) {
                splat_is_dynamic[s] = 1;
                num_dynamic_splats++;
            } else {
                num_static_splats++;
            }
        }
    }

    fprintf(stderr, "[QTSQ Hybrid] Vertices: %u static, %u dynamic | Splats: %u static, %u dynamic\n",
            num_static_verts, num_dynamic_verts, num_static_splats, num_dynamic_splats);

    /* ═══ PHASE 6: Pack HSCN Format + Compress ═══ */
    uint8_t num_kf = (uint8_t)((seg_frames + COLOR_KF_INTERVAL - 1) / COLOR_KF_INTERVAL) + 1;
    if (num_kf < 2) num_kf = 2;
    uint8_t kf_interval = COLOR_KF_INTERVAL;

    /* Calculate body size */
    size_t vert_pos_size = (size_t)nv * 4;                          /* u16 x, u16 y per vertex */
    size_t face_idx_size = (size_t)nf * 6;                          /* u16 v0, v1, v2 per face */
    size_t splat_pos_size = (size_t)num_splats * 5;                 /* u16 x, u16 y, u8 radius */
    size_t static_vert_color_size = (size_t)num_static_verts * 3;
    size_t static_splat_color_size = (size_t)num_static_splats * 3;
    size_t dynamic_vert_color_size = (size_t)num_dynamic_verts * num_kf * 3;
    size_t dynamic_splat_color_size = (size_t)num_dynamic_splats * num_kf * 3;
    size_t body_size = vert_pos_size + face_idx_size + splat_pos_size
                     + static_vert_color_size + static_splat_color_size
                     + dynamic_vert_color_size + dynamic_splat_color_size;

    uint8_t *body = (uint8_t *)malloc(body_size);
    if (!body) { free(splat_is_dynamic); free(vert_is_dynamic); free(splat_colors); free(vert_colors); free(splats); free(faces); free(verts); goto fail; }

    uint8_t *bp = body;

    /* Build reorder maps: static first, then dynamic */
    uint32_t *vert_order = (uint32_t *)malloc(nv * sizeof(uint32_t));
    if (!vert_order) { free(body); free(splat_is_dynamic); free(vert_is_dynamic); free(splat_colors); free(vert_colors); free(splats); free(faces); free(verts); goto fail; }
    {
        uint32_t si = 0, di = num_static_verts;
        for (uint32_t v = 0; v < nv; v++) {
            if (!vert_is_dynamic[v]) vert_order[si++] = v;
            else vert_order[di++] = v;
        }
    }

    /* Build reverse map for face index remapping */
    uint32_t *vert_remap = (uint32_t *)malloc(nv * sizeof(uint32_t));
    if (!vert_remap) { free(vert_order); free(body); free(splat_is_dynamic); free(vert_is_dynamic); free(splat_colors); free(vert_colors); free(splats); free(faces); free(verts); goto fail; }
    for (uint32_t i = 0; i < nv; i++) {
        vert_remap[vert_order[i]] = i;
    }

    /* Write vertex positions in reordered form */
    for (uint32_t i = 0; i < nv; i++) {
        uint32_t orig = vert_order[i];
        uint16_t vx = (uint16_t)(verts[orig].x + 0.5f);
        uint16_t vy = (uint16_t)(verts[orig].y + 0.5f);
        memcpy(bp, &vx, 2); bp += 2;
        memcpy(bp, &vy, 2); bp += 2;
    }

    /* Write face indices (remapped) */
    for (uint32_t f = 0; f < nf; f++) {
        uint16_t v0 = (uint16_t)vert_remap[faces[f].v0];
        uint16_t v1 = (uint16_t)vert_remap[faces[f].v1];
        uint16_t v2 = (uint16_t)vert_remap[faces[f].v2];
        memcpy(bp, &v0, 2); bp += 2;
        memcpy(bp, &v1, 2); bp += 2;
        memcpy(bp, &v2, 2); bp += 2;
    }
    free(vert_remap);

    /* Write splat positions */
    uint32_t *splat_order = NULL;
    if (num_splats > 0) {
        splat_order = (uint32_t *)malloc(num_splats * sizeof(uint32_t));
        if (splat_order) {
            uint32_t si = 0, di = num_static_splats;
            for (uint32_t s = 0; s < num_splats; s++) {
                if (!splat_is_dynamic[s]) splat_order[si++] = s;
                else splat_order[di++] = s;
            }
        }
        for (uint32_t i = 0; i < num_splats; i++) {
            uint32_t orig = splat_order ? splat_order[i] : i;
            uint16_t sx = splats[orig].x, sy = splats[orig].y;
            uint8_t sr = splats[orig].sx > 0 ? splats[orig].sx : 2;
            memcpy(bp, &sx, 2); bp += 2;
            memcpy(bp, &sy, 2); bp += 2;
            *bp++ = sr;
        }
    }

    /* Write static vertex colors (average across frames) */
    for (uint32_t i = 0; i < num_static_verts; i++) {
        uint32_t orig = vert_order[i];
        uint32_t sum_r = 0, sum_g = 0, sum_b = 0;
        for (uint32_t f = 0; f < seg_frames; f++) {
            uint8_t *c = vert_colors + (size_t)f * nv * 3 + orig * 3;
            sum_r += c[0]; sum_g += c[1]; sum_b += c[2];
        }
        *bp++ = (uint8_t)(sum_r / seg_frames);
        *bp++ = (uint8_t)(sum_g / seg_frames);
        *bp++ = (uint8_t)(sum_b / seg_frames);
    }

    /* Write static splat colors */
    if (num_splats > 0 && splat_colors) {
        for (uint32_t i = 0; i < num_static_splats; i++) {
            uint32_t orig = splat_order ? splat_order[i] : i;
            uint32_t sum_r = 0, sum_g = 0, sum_b = 0;
            for (uint32_t f = 0; f < seg_frames; f++) {
                uint8_t *c = splat_colors + (size_t)f * num_splats * 3 + orig * 3;
                sum_r += c[0]; sum_g += c[1]; sum_b += c[2];
            }
            *bp++ = (uint8_t)(sum_r / seg_frames);
            *bp++ = (uint8_t)(sum_g / seg_frames);
            *bp++ = (uint8_t)(sum_b / seg_frames);
        }
    }

    /* Write dynamic vertex keyframe colors */
    for (uint32_t i = 0; i < num_dynamic_verts; i++) {
        uint32_t orig = vert_order[num_static_verts + i];
        for (uint8_t k = 0; k < num_kf; k++) {
            uint32_t kf_frame = (uint32_t)k * kf_interval;
            if (kf_frame >= seg_frames) kf_frame = seg_frames - 1;
            uint8_t *c = vert_colors + (size_t)kf_frame * nv * 3 + orig * 3;
            *bp++ = c[0]; *bp++ = c[1]; *bp++ = c[2];
        }
    }

    /* Write dynamic splat keyframe colors */
    if (num_splats > 0 && splat_colors) {
        for (uint32_t i = 0; i < num_dynamic_splats; i++) {
            uint32_t orig = splat_order ? splat_order[num_static_splats + i] : (num_static_splats + i);
            for (uint8_t k = 0; k < num_kf; k++) {
                uint32_t kf_frame = (uint32_t)k * kf_interval;
                if (kf_frame >= seg_frames) kf_frame = seg_frames - 1;
                uint8_t *c = splat_colors + (size_t)kf_frame * num_splats * 3 + orig * 3;
                *bp++ = c[0]; *bp++ = c[1]; *bp++ = c[2];
            }
        }
    }

    /* Cleanup intermediate buffers */
    free(vert_order);
    free(splat_order);
    free(vert_is_dynamic);
    free(splat_is_dynamic);
    free(vert_colors);
    free(splat_colors);
    free(splats);
    free(faces);
    free(verts);

    /* ═══ HEADER ═══ (40 bytes) */
    uint8_t header[40];
    memset(header, 0, 40);
    header[0] = 'H'; header[1] = 'S'; header[2] = 'C'; header[3] = 'N';
    uint16_t w16 = (uint16_t)w, h16 = (uint16_t)h;
    memcpy(header + 4, &w16, 2);
    memcpy(header + 6, &h16, 2);
    memcpy(header + 8, &nv, 4);
    memcpy(header + 12, &nf, 4);
    memcpy(header + 16, &num_splats, 4);
    memcpy(header + 20, &num_static_verts, 4);
    memcpy(header + 24, &num_static_splats, 4);
    uint16_t seg16 = (uint16_t)seg_frames;
    memcpy(header + 28, &seg16, 2);
    header[30] = num_kf;
    header[31] = kf_interval;
    /* header[32-39] = reserved (already zeroed) */

    /* Compress body with zlib (level 1 for speed, quality > size) */
    uLongf zbuf_len = compressBound((uLong)body_size);
    uint8_t *zbuf = (uint8_t *)malloc(zbuf_len);
    if (!zbuf) { free(body); goto fail; }

    int zret = compress2(zbuf, &zbuf_len, body, (uLong)body_size, Z_BEST_SPEED);
    free(body);
    if (zret != Z_OK) { free(zbuf); goto fail; }

    /* Assemble: header(40) + zbuf_len(4) + zbuf */
    uint32_t zlen32 = (uint32_t)zbuf_len;
    size_t total_size = 40 + 4 + zbuf_len;
    uint8_t *segment_data = (uint8_t *)malloc(total_size);
    if (!segment_data) { free(zbuf); goto fail; }

    memcpy(segment_data, header, 40);
    memcpy(segment_data + 40, &zlen32, 4);
    memcpy(segment_data + 44, zbuf, zbuf_len);
    free(zbuf);

    fprintf(stderr, "[QTSQ Hybrid] Segment: %u verts, %u faces, %u splats → %zu bytes compressed\n",
            nv, nf, num_splats, total_size);

    /* ═══ Append to bitstream ═══ */
    uint32_t offset = (uint32_t)enc->bitstream_size;
    uint32_t size = (uint32_t)total_size;

    if (append_to_bitstream(enc, segment_data, total_size) != QTSQ_OK) {
        free(segment_data);
        goto fail;
    }
    free(segment_data);

    /* All frames in this segment point to the same blob */
    for (uint32_t f = 0; f < seg_frames; f++) {
        append_to_index(enc, offset, size, 'H');  /* 'H' = Hybrid */
    }

    /* Free buffered frames */
    for (uint32_t f = 0; f < seg_frames; f++) {
        free(enc->frame_buffer[f]);
        enc->frame_buffer[f] = NULL;
    }
    enc->frame_buffer_count = 0;

    return QTSQ_OK;

fail:
    /* Free buffered frames on error */
    for (uint32_t f = 0; f < enc->frame_buffer_count; f++) {
        if (enc->frame_buffer[f]) {
            free(enc->frame_buffer[f]);
            enc->frame_buffer[f] = NULL;
        }
    }
    enc->frame_buffer_count = 0;
    return QTSQ_ERR_IO;
}



int qtsq_video_encoder_add_frame(qtsq_video_encoder_t *enc, const uint8_t *pixels) {
    if (!enc || !pixels) return QTSQ_ERR_NULL;

    size_t frame_bytes = (size_t)enc->width * enc->height * enc->channels;

    /* Scene-cut detection: if this frame differs drastically from the last buffered
     * frame, flush the current segment and start fresh. */
    if (enc->frame_buffer_count > 0 && enc->has_ref_frame) {
        /* Quick CPU-based scene-cut check: compare against ref_frame */
        uint32_t changed = 0;
        uint32_t total = enc->width * enc->height;
        /* Sample every 64th pixel for speed */
        for (uint32_t i = 0; i < total; i += 64) {
            size_t idx = (size_t)i * enc->channels;
            int dr = abs((int)pixels[idx] - (int)enc->ref_frame[idx]);
            int dg = abs((int)pixels[idx + 1] - (int)enc->ref_frame[idx + 1]);
            int db = abs((int)pixels[idx + 2] - (int)enc->ref_frame[idx + 2]);
            if (dr + dg + db > 80) changed++;
        }
        float ratio = (float)changed / (float)(total / 64);
        if (ratio > SCENE_CUT_THRESHOLD) {
            fprintf(stderr, "[QTSQ Scene] Scene cut detected (ratio=%.2f), flushing segment\n", ratio);
            int ret = flush_segment(enc);
            if (ret != QTSQ_OK) return ret;
        }
    }

    /* Buffer this frame */
    uint8_t *copy = (uint8_t *)malloc(frame_bytes);
    if (!copy) return QTSQ_ERR_ALLOC;
    memcpy(copy, pixels, frame_bytes);

    /* Grow the pointer array if needed */
    if (enc->frame_buffer_count >= enc->segment_size) {
        uint32_t new_size = enc->segment_size * 2;
        uint8_t **new_buf = (uint8_t **)realloc(enc->frame_buffer, new_size * sizeof(uint8_t *));
        if (!new_buf) { free(copy); return QTSQ_ERR_ALLOC; }
        memset(new_buf + enc->segment_size, 0, (new_size - enc->segment_size) * sizeof(uint8_t *));
        enc->frame_buffer = new_buf;
        enc->segment_size = new_size;
    }

    enc->frame_buffer[enc->frame_buffer_count] = copy;
    enc->frame_buffer_count++;

    /* Update ref_frame for scene-cut detection */
    memcpy(enc->ref_frame, pixels, frame_bytes);
    enc->has_ref_frame = 1;

    /* Flush if segment is full */
    if (enc->frame_buffer_count >= enc->segment_size) {
        return flush_segment(enc);
    }

    return QTSQ_OK;
}

int qtsq_video_encoder_finish(qtsq_video_encoder_t *enc) {
    if (!enc) return QTSQ_ERR_NULL;

    /* Flush any remaining buffered frames */
    if (enc->frame_buffer_count > 0) {
        flush_segment(enc);
    }

    /* Build the final payload in the context */
    /* Structure: [Frame Index] [Bitstream] */
    size_t index_size = 4 + 4 + (enc->frame_count * 4) + (enc->frame_count * 4) + enc->frame_count;
    size_t total_payload = index_size + enc->bitstream_size;

    enc->ctx->singularity = (uint8_t *)malloc(total_payload);
    if (!enc->ctx->singularity) return QTSQ_ERR_ALLOC;
    enc->ctx->singularity_size = total_payload;

    uint8_t *p = enc->ctx->singularity;
    p[0] = 'I'; p[1] = 'D'; p[2] = 'X'; p[3] = '1'; p += 4;
    memcpy(p, &enc->frame_count, 4); p += 4;

    if (enc->frame_count > 0) {
        memcpy(p, enc->frame_offsets, enc->frame_count * 4); p += enc->frame_count * 4;
        memcpy(p, enc->frame_sizes, enc->frame_count * 4); p += enc->frame_count * 4;
        memcpy(p, enc->frame_types, enc->frame_count); p += enc->frame_count;
    }

    /* Copy bitstream */
    if (enc->bitstream_size > 0 && enc->bitstream != NULL) {
        memcpy(p, enc->bitstream, enc->bitstream_size);
    }

    /* Update header sizes — critical for qtsq_write/qtsq_read round-trip */
    enc->ctx->header.original_size = (uint64_t)enc->width * enc->height * enc->channels * enc->frame_count;
    enc->ctx->header.singularity_size = total_payload;
    enc->ctx->header.horizon_size = sizeof(qtsq_schema_t);

    fprintf(stderr, "[QTSQ Video] Encoded %u frames as scene-level splats (%zu bytes compressed, singularity=%zu bytes)\n",
            enc->frame_count, enc->bitstream_size, total_payload);

    return QTSQ_OK;
}

qtsq_context_t* qtsq_video_encoder_get_context(qtsq_video_encoder_t *enc) {
    if (!enc) return NULL;
    return enc->ctx;
}

void qtsq_video_encoder_free(qtsq_video_encoder_t *enc) {
    if (!enc) return;
    if (enc->bitstream) free(enc->bitstream);
    if (enc->frame_offsets) free(enc->frame_offsets);
    if (enc->frame_sizes) free(enc->frame_sizes);
    if (enc->frame_types) free(enc->frame_types);
    if (enc->ref_frame) free(enc->ref_frame);
    if (enc->ref_splat_input) free(enc->ref_splat_input);
    if (enc->ref_splat_colors) free(enc->ref_splat_colors);

    /* Free any leftover buffered frames */
    if (enc->frame_buffer) {
        for (uint32_t i = 0; i < enc->segment_size; i++) {
            if (enc->frame_buffer[i]) free(enc->frame_buffer[i]);
        }
        free(enc->frame_buffer);
    }

    for (int i = 0; i < enc->batch_count; i++) {
        if (enc->batch[i].raw_pixels) free(enc->batch[i].raw_pixels);
        if (enc->batch[i].compressed_data) free(enc->batch[i].compressed_data);
        if (enc->batch[i].delta_buffer) free(enc->batch[i].delta_buffer);
    }
    free(enc);
}
