/*
 * Quantum Tensor Sequence — Photon Audio HQ Decoder (v4)
 * Hybrid Lossless PCM + Per-Atom Spatial Metadata
 *
 * Architecture:
 *   1. Lossless Layer: zlib -> 2nd-order delta int32 -> float32 -> L/R stereo decode
 *   2. Spatial Layer: extract spatial atom metadata for renderer
 *
 * Author: Haruhito
 */
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <zlib.h>
#include "qtsq.h"

/* ═══════════ 2nd-Order Delta Decoding ═══════════ */
static void delta_decode_int32_to_float32(const int32_t *input, float *output, uint32_t count) {
    if (count == 0) return;
    
    const float inv_scale = 1.0f / 8388607.0f;
    
    int32_t dec0 = input[0];
    output[0] = (float)dec0 * inv_scale;
    if (count == 1) return;
    
    int32_t dec1 = dec0 + input[1];
    output[1] = (float)dec1 * inv_scale;
    
    int32_t p0 = dec0;
    int32_t p1 = dec1;
    
    for (uint32_t i = 2; i < count; i++) {
        int32_t predicted = 2 * p1 - p0;
        int32_t val = predicted + input[i];
        output[i] = (float)val * inv_scale;
        p0 = p1;
        p1 = val;
    }
}

/* ═══════════ DECODER ═══════════ */
int qtsq_decompress_audio_hq(const qtsq_context_t *ctx,
                              float **out_pcm, size_t *out_total_samples,
                              photon_atom_t **out_atoms, size_t *out_atom_count)
{
    FILE *f = fopen("/tmp/qtsq_debug.log", "a");
    if(f) { fprintf(f, "--- qtsq_decompress_audio_hq START ---\n"); fclose(f); }

    if (!ctx || !out_pcm || !out_total_samples) {
        if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "Failed Null Pointers\n"); fclose(f); }
        return QTSQ_ERR_NULL;
    }
    *out_pcm = NULL;
    *out_total_samples = 0;
    if (out_atoms) *out_atoms = NULL;
    if (out_atom_count) *out_atom_count = 0;
    
    if (!ctx->singularity || ctx->singularity_size < 8) {
        if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "Failed Singularity Size: %llu\n", ctx->singularity_size); fclose(f); }
        return QTSQ_ERR_FORMAT;
    }
    
    /* Decompress outer zlib payload */
    uint32_t raw_size;
    memcpy(&raw_size, ctx->singularity, 4);
    
    uint8_t *raw = (uint8_t *)malloc(raw_size);
    if (!raw) {
        if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "Failed malloc raw_size: %u\n", raw_size); fclose(f); }
        return QTSQ_ERR_ALLOC;
    }
    uLongf dl = (uLongf)raw_size;
    
    int zerr = uncompress(raw, &dl, ctx->singularity + 4,
                   (uLong)(ctx->singularity_size - 4));
    if (zerr != Z_OK) {
        if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "uncompress failed: %d, required dl: %lu, available: %llu\n", zerr, dl, ctx->singularity_size - 4); fclose(f); }
        free(raw);
        return QTSQ_ERR_FORMAT;
    }
    
    /* Parse header — PH04 format */
    if (dl < 28) { 
        if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "Format error: dl < 28 (dl = %lu)\n", dl); fclose(f); }
        free(raw); return QTSQ_ERR_FORMAT; 
    }
    if (raw[0] != 'P' || raw[1] != 'H' || raw[2] != '0' || raw[3] != '4') {
        if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "Format error: magic mismatch %c%c%c%c\n", raw[0], raw[1], raw[2], raw[3]); fclose(f); }
        free(raw); return QTSQ_ERR_FORMAT;
    }
    
    size_t p = 4;
    uint32_t spc, sample_rate, pcm_bytes_per_ch, total_atoms, atom_size;
    uint8_t channels, bit_depth, flags;
    
    memcpy(&spc, raw + p, 4); p += 4;
    memcpy(&sample_rate, raw + p, 4); p += 4;
    channels = raw[p++];
    bit_depth = raw[p++]; (void)bit_depth;
    flags = raw[p++];
    p++; /* reserved */
    
    memcpy(&pcm_bytes_per_ch, raw + p, 4); p += 4;
    memcpy(&total_atoms, raw + p, 4); p += 4;
    memcpy(&atom_size, raw + p, 4); p += 4;
    
    /* Calculate remaining sizes */
    size_t required_pcm_bytes = (size_t)channels * pcm_bytes_per_ch;
    size_t required_atom_bytes = (size_t)total_atoms * atom_size;
    if (p + required_pcm_bytes + required_atom_bytes > dl) {
        if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "Format error: requires %zu, but dl is %lu\n", (p + required_pcm_bytes + required_atom_bytes), dl); fclose(f); }
        free(raw);
        return QTSQ_ERR_FORMAT;
    }
    
    /* Read and Delta Decode PCM Layers */
    float **decoded_ch = (float **)malloc(channels * sizeof(float *));
    if (!decoded_ch) { free(raw); return QTSQ_ERR_ALLOC; }
    
    for (int c = 0; c < channels; c++) {
        decoded_ch[c] = (float *)malloc(spc * sizeof(float));
        if (!decoded_ch[c]) {
            for (int i=0; i<c; i++) free(decoded_ch[i]);
            free(decoded_ch); free(raw);
            return QTSQ_ERR_ALLOC;
        }
        
        int32_t *delta_data = (int32_t *)(raw + p);
        p += pcm_bytes_per_ch;
        
        delta_decode_int32_to_float32(delta_data, decoded_ch[c], spc);
    }
    
    /* Mid/Side -> Left/Right reconstruction */
    float *pcm = (float *)malloc((size_t)channels * spc * sizeof(float));
    if (!pcm) {
        for (int c=0; c<channels; c++) free(decoded_ch[c]);
        free(decoded_ch); free(raw);
        return QTSQ_ERR_ALLOC;
    }
    
    for (int pair = 0; pair < channels / 2; pair++) {
        int L_ch = pair * 2;
        int R_ch = pair * 2 + 1;
        for (uint32_t i = 0; i < spc; i++) {
            float Mid = decoded_ch[L_ch][i];
            float Side = decoded_ch[R_ch][i];
            
            float L = Mid + Side;
            float R = Mid - Side;
            
            /* hard clip float to valid audio ranges just in case */
            if (L > 1.0f) L = 1.0f; else if (L < -1.0f) L = -1.0f;
            if (R > 1.0f) R = 1.0f; else if (R < -1.0f) R = -1.0f;
            
            pcm[i * channels + L_ch] = L;
            pcm[i * channels + R_ch] = R;
        }
    }
    /* Mono odd channel fallback */
    if (channels % 2 == 1) {
        int c = channels - 1;
        for (uint32_t i = 0; i < spc; i++) {
            float val = decoded_ch[c][i];
            if (val > 1.0f) val = 1.0f; else if (val < -1.0f) val = -1.0f;
            pcm[i * channels + c] = val;
        }
    }
    
    for (int c = 0; c < channels; c++) free(decoded_ch[c]);
    free(decoded_ch);
    
    /* Read Atoms (if requested) */
    if (out_atoms && out_atom_count && total_atoms > 0 && (flags & 1)) {
        photon_atom_t *atoms = (photon_atom_t *)malloc(total_atoms * sizeof(photon_atom_t));
        if (atoms) {
            /* If sizes match, direct copy, else field-by-field safety */
            if (atom_size == sizeof(photon_atom_t)) {
                memcpy(atoms, raw + p, total_atoms * sizeof(photon_atom_t));
            } else {
                /* fallback parsing for future compat */
                for (uint32_t i = 0; i < total_atoms; i++) {
                    memcpy(&atoms[i], raw + p + i * atom_size, 
                           atom_size < sizeof(photon_atom_t) ? atom_size : sizeof(photon_atom_t));
                }
            }
            *out_atoms = atoms;
            *out_atom_count = total_atoms;
        }
    }
    
    free(raw);
    *out_pcm = pcm;
    *out_total_samples = (size_t)channels * spc;
    if(f=fopen("/tmp/qtsq_debug.log", "a")) { fprintf(f, "SUCCESS Decode PCM out.\n"); fclose(f); }
    return QTSQ_OK;
}
