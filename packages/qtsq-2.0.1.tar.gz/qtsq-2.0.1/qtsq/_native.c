/*
 * qtsq Python C Extension — Full SDK
 *
 * Functions:
 *   qtsq._native.read_vertices(path)              → vertex data
 *   qtsq._native.compress_image(pixels, w, h, ch, path, mode)  → compress
 *   qtsq._native.decompress_image(path)            → pixel data
 *   qtsq._native.compress_text(text, path)          → compress text
 *   qtsq._native.decompress_raw(path)               → raw bytes
 *   qtsq._native.file_info(path)                    → metadata dict
 *   qtsq._native.compress_tensor(data, dims, path, precision)  → tensor
 *   qtsq._native.decompress_tensor(path)            → float array
 *   qtsq._native.brain_save(path, weights, biases, memories, vector_dim, meta)
 *   qtsq._native.brain_load(path)                   → dict of arrays
 *
 * Author: haruhito
 */

#define PY_SSIZE_T_CLEAN
#include <Python.h>
#include "qtsq.h"
#include <string.h>
#include <zlib.h>

#define MAX_VERTICES 100000

/* ── Helper: get TRM3 dimensions ── */
static int get_dimensions(const qtsq_context_t *ctx, uint32_t *w, uint32_t *h) {
    if (!ctx || !ctx->singularity || ctx->singularity_size < 8) return -1;
    uint32_t uncomp_sz;
    memcpy(&uncomp_sz, ctx->singularity, 4);
    uint8_t *packed = (uint8_t *)malloc(uncomp_sz);
    if (!packed) return -1;
    uLongf dl = (uLongf)uncomp_sz;
    if (uncompress(packed, &dl, ctx->singularity + 4,
                   (uLong)(ctx->singularity_size - 4)) != Z_OK) {
        free(packed);
        return -1;
    }
    if (packed[0]!='T' || packed[1]!='R' || packed[2]!='M' || packed[3]!='3') {
        free(packed);
        return -1;
    }
    memcpy(w, packed + 4, 4);
    memcpy(h, packed + 8, 4);
    free(packed);
    return 0;
}

/* ══════════════════════════════════════════════════════
 *  1. read_vertices(path, max_vertices=100000)
 * ══════════════════════════════════════════════════════ */
static PyObject* py_read_vertices(PyObject *self, PyObject *args, PyObject *kwargs) {
    const char *path;
    int max_verts = MAX_VERTICES;
    static char *kwlist[] = {"path", "max_vertices", NULL};
    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "s|i", kwlist, &path, &max_verts))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    uint32_t width = 0, height = 0;
    get_dimensions(&ctx, &width, &height);

    float *verts = (float *)malloc((size_t)max_verts * 5 * sizeof(float));
    if (!verts) { qtsq_free(&ctx); return PyErr_NoMemory(); }

    int nv = qtsq_extract_vertices(&ctx, verts, (uint32_t)max_verts);
    qtsq_free(&ctx);

    if (nv <= 0) {
        free(verts);
        PyErr_Format(PyExc_RuntimeError, "No vertices in: %s", path);
        return NULL;
    }

    if (width == 0 || height == 0) {
        for (int i = 0; i < nv; i++) {
            if ((uint32_t)verts[i*5+0]+1 > width)  width = (uint32_t)verts[i*5+0]+1;
            if ((uint32_t)verts[i*5+1]+1 > height) height = (uint32_t)verts[i*5+1]+1;
        }
    }

    PyObject *vert_list = PyList_New(nv);
    for (int i = 0; i < nv; i++) {
        PyList_SET_ITEM(vert_list, i, Py_BuildValue("(fffff)",
            verts[i*5+0], verts[i*5+1], verts[i*5+2], verts[i*5+3], verts[i*5+4]));
    }
    free(verts);

    return Py_BuildValue("{s:O,s:I,s:I,s:i}",
        "vertices", vert_list, "width", width, "height", height, "num_vertices", nv);
}

/* ══════════════════════════════════════════════════════
 *  2. compress_image(pixels_bytes, w, h, ch, path, mode)
 * ══════════════════════════════════════════════════════ */
static PyObject* py_compress_image(PyObject *self, PyObject *args) {
    const char *pixels;
    Py_ssize_t pixels_len;
    unsigned int w, h;
    unsigned char ch;
    const char *out_path;
    const char *mode;

    if (!PyArg_ParseTuple(args, "y#IIbss",
                          &pixels, &pixels_len, &w, &h, &ch, &out_path, &mode))
        return NULL;

    if ((Py_ssize_t)(w * h * ch) != pixels_len) {
        PyErr_Format(PyExc_ValueError,
            "Pixel buffer size mismatch: expected %u, got %zd", w*h*ch, pixels_len);
        return NULL;
    }

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }

    int rc;
    size_t src_size = (size_t)pixels_len;

    /* ── Gravitational (triangle + splat) ── */
    if (strcmp(mode, "hd") == 0) {
        rc = qtsq_compress_gravitational_hd(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "lossless") == 0) {
        rc = qtsq_compress_gravitational_lossless(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "upscale") == 0) {
        rc = qtsq_compress_gravitational_upscale(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }
    /* ── Splat-only ── */
    else if (strcmp(mode, "splat") == 0) {
        rc = qtsq_compress_splat_compact(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "splat_hd") == 0) {
        rc = qtsq_compress_splat_hd(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "splat_lossless") == 0) {
        rc = qtsq_compress_splat_lossless(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }
    /* ── Triangle-only ── */
    else if (strcmp(mode, "triangle") == 0) {
        rc = qtsq_compress_triangle_compact(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "triangle_hd") == 0) {
        rc = qtsq_compress_triangle_hd(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "triangle_lossless") == 0) {
        rc = qtsq_compress_triangle_lossless(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    } else if (strcmp(mode, "triangle_pixel") == 0) {
        rc = qtsq_compress_triangle_pixel(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }
    /* ── Ionic Data Tunnel (ICE-inspired) ── */
    else if (strcmp(mode, "hd_ionic") == 0) {
        rc = qtsq_ionic_compress_hd(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }
    /* ── Default: gravitational (triangle + splat) ── */
    else {
        rc = qtsq_compress_gravitational(&ctx,
            (const uint8_t *)pixels, w, h, ch, src_size);
    }

    if (rc != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_RuntimeError, "Compress failed (mode=%s, err=%d)", mode, rc);
        return NULL;
    }

    rc = qtsq_write(&ctx, out_path);
    qtsq_free(&ctx);

    if (rc != 0) {
        PyErr_Format(PyExc_RuntimeError, "Write failed: %s (err=%d)", out_path, rc);
        return NULL;
    }

    Py_RETURN_NONE;
}

/* ══════════════════════════════════════════════════════
 *  3. decompress_image(path) → {pixels, width, height, channels}
 * ══════════════════════════════════════════════════════ */
static PyObject* py_decompress_image(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    /* Get dimensions */
    uint32_t width = 0, height = 0;
    get_dimensions(&ctx, &width, &height);

    /* Decompress based on strategy */
    uint8_t *out_data = NULL;
    size_t out_size = 0;
    int rc;

    uint8_t strategy = ctx.header.strategy;
    if (strategy == QTSQ_STRATEGY_SPLAT) {
        rc = qtsq_decompress_splat_only(&ctx, &out_data, &out_size);
    } else if (strategy == QTSQ_STRATEGY_TRIANGLE ||
               strategy == QTSQ_STRATEGY_LAYERED) {
        rc = qtsq_decompress_gravitational(&ctx, &out_data, &out_size);
    } else {
        rc = qtsq_decompress(&ctx, &out_data, &out_size);
    }

    if (rc != 0 || !out_data || out_size == 0) {
        qtsq_free(&ctx);
        if (out_data) free(out_data);
        PyErr_Format(PyExc_RuntimeError, "Decompress failed: %s (err=%d)", path, rc);
        return NULL;
    }

    /* Figure out channels */
    uint8_t ch = ctx.header.num_channels;
    if (ch == 0) ch = 3;

    /* If dimensions unknown, try to figure them out */
    if (width == 0 || height == 0) {
        /* Fallback: get from schema */
        width = ctx.schema.dimensions[0];
        height = ctx.schema.dimensions[1];
    }

    /* Return as bytes + metadata */
    PyObject *result = Py_BuildValue("{s:y#,s:I,s:I,s:B}",
        "pixels", out_data, (Py_ssize_t)out_size,
        "width", width,
        "height", height,
        "channels", ch);

    free(out_data);
    qtsq_free(&ctx);
    return result;
}

/* ══════════════════════════════════════════════════════
 *  4. compress_text(text, path)
 * ══════════════════════════════════════════════════════ */
static PyObject* py_compress_text(PyObject *self, PyObject *args) {
    const char *text;
    Py_ssize_t text_len;
    const char *out_path;

    if (!PyArg_ParseTuple(args, "s#s", &text, &text_len, &out_path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }

    int rc = qtsq_compress_text(&ctx, text, (size_t)text_len);
    if (rc != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_RuntimeError, "Text compress failed (err=%d)", rc);
        return NULL;
    }

    rc = qtsq_write(&ctx, out_path);
    qtsq_free(&ctx);

    if (rc != 0) {
        PyErr_Format(PyExc_RuntimeError, "Write failed: %s (err=%d)", out_path, rc);
        return NULL;
    }

    Py_RETURN_NONE;
}

/* ══════════════════════════════════════════════════════
 *  5. decompress_raw(path) → bytes
 * ══════════════════════════════════════════════════════ */
static PyObject* py_decompress_raw(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    uint8_t *out_data = NULL;
    size_t out_size = 0;
    int rc = qtsq_decompress(&ctx, &out_data, &out_size);
    qtsq_free(&ctx);

    if (rc != 0 || !out_data) {
        if (out_data) free(out_data);
        PyErr_Format(PyExc_RuntimeError, "Decompress failed: %s", path);
        return NULL;
    }

    PyObject *result = PyBytes_FromStringAndSize((const char *)out_data, (Py_ssize_t)out_size);
    free(out_data);
    return result;
}

/* ══════════════════════════════════════════════════════
 *  6. file_info(path) → dict with metadata
 * ══════════════════════════════════════════════════════ */
static PyObject* py_file_info(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    qtsq_context_t ctx;
    if (qtsq_init(&ctx) != 0) {
        PyErr_SetString(PyExc_RuntimeError, "qtsq_init failed");
        return NULL;
    }
    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    uint32_t width = 0, height = 0;
    get_dimensions(&ctx, &width, &height);

    /* Strategy name */
    const char *strategy_name = "unknown";
    switch (ctx.header.strategy) {
        case QTSQ_STRATEGY_TRIANGLE: strategy_name = "triangle"; break;
        case QTSQ_STRATEGY_SPLAT:    strategy_name = "splat"; break;
        case QTSQ_STRATEGY_LAYERED:  strategy_name = "layered"; break;
        case QTSQ_STRATEGY_PROCEDURAL: strategy_name = "procedural"; break;
        case QTSQ_STRATEGY_FRACTAL:  strategy_name = "fractal"; break;
        case QTSQ_STRATEGY_FOURIER:  strategy_name = "fourier"; break;
        case QTSQ_STRATEGY_DICTIONARY: strategy_name = "dictionary"; break;
        case QTSQ_STRATEGY_PHOTON:   strategy_name = "photon"; break;
        case QTSQ_STRATEGY_TENSOR:   strategy_name = "tensor"; break;
        case QTSQ_STRATEGY_NONE:     strategy_name = "none"; break;
        default: break;
    }

    /* Data type name */
    const char *type_name = "unknown";
    switch (ctx.header.data_type) {
        case QTSQ_TYPE_IMAGE_RGB:    type_name = "image_rgb"; break;
        case QTSQ_TYPE_IMAGE_RGBA:   type_name = "image_rgba"; break;
        case QTSQ_TYPE_IMAGE_GRAY:   type_name = "image_gray"; break;
        case QTSQ_TYPE_TEXT_ASCII:   type_name = "text_ascii"; break;
        case QTSQ_TYPE_TEXT_UTF8:    type_name = "text_utf8"; break;
        case QTSQ_TYPE_AUDIO_MONO:   type_name = "audio_mono"; break;
        case QTSQ_TYPE_AUDIO_STEREO: type_name = "audio_stereo"; break;
        case QTSQ_TYPE_VIDEO_FRAMES: type_name = "video"; break;
        case QTSQ_TYPE_RAW:          type_name = "raw"; break;
        case QTSQ_TYPE_JSON:         type_name = "json"; break;
        case QTSQ_TYPE_CSV:          type_name = "csv"; break;
        case QTSQ_TYPE_TENSOR:       type_name = "tensor"; break;
        case QTSQ_TYPE_CONTAINER:    type_name = "container"; break;
        default: break;
    }

    PyObject *result = Py_BuildValue(
        "{s:s, s:s, s:I, s:I, s:B, s:K, s:I, s:i}",
        "strategy", strategy_name,
        "data_type", type_name,
        "width", width,
        "height", height,
        "channels", ctx.header.num_channels,
        "original_size", (unsigned long long)ctx.header.original_size,
        "version", (unsigned int)ctx.header.version,
        "encrypted", ctx.is_encrypted
    );

    qtsq_free(&ctx);
    return result;
}

/* ══════════════════════════════════════════════════════
 *  7. compress_tensor(data, dims, path, precision='f32')
 * ══════════════════════════════════════════════════════ */
static PyObject* py_compress_tensor(PyObject *self, PyObject *args, PyObject *kwargs) {
    PyObject *data_obj;
    PyObject *dims_obj;
    const char *out_path;
    const char *precision_str = "f32";
    static char *kwlist[] = {"data", "dims", "path", "precision", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "OOs|s", kwlist,
                                      &data_obj, &dims_obj, &out_path, &precision_str))
        return NULL;

    /* Parse precision string → enum */
    qtsq_tensor_precision_t prec = QTSQ_TENSOR_F32;
    if (strcmp(precision_str, "f16") == 0) prec = QTSQ_TENSOR_F16;
    else if (strcmp(precision_str, "f8") == 0) prec = QTSQ_TENSOR_F8;
    else if (strcmp(precision_str, "f4") == 0) prec = QTSQ_TENSOR_F4;
    else if (strcmp(precision_str, "raw") == 0) prec = QTSQ_TENSOR_RAW;
    else if (strcmp(precision_str, "f32") != 0) {
        PyErr_Format(PyExc_ValueError,
            "Unknown precision '%s'. Use: 'f32', 'f16', 'f8', 'f4', 'raw'", precision_str);
        return NULL;
    }

    /* Parse data → float array */
    PyObject *data_list = PySequence_Fast(data_obj, "data must be a sequence");
    if (!data_list) return NULL;

    Py_ssize_t count = PySequence_Fast_GET_SIZE(data_list);
    if (count <= 0) {
        Py_DECREF(data_list);
        PyErr_SetString(PyExc_ValueError, "data must not be empty");
        return NULL;
    }

    float *data = (float *)malloc((size_t)count * sizeof(float));
    if (!data) { Py_DECREF(data_list); return PyErr_NoMemory(); }

    for (Py_ssize_t i = 0; i < count; i++) {
        data[i] = (float)PyFloat_AsDouble(PySequence_Fast_GET_ITEM(data_list, i));
    }
    Py_DECREF(data_list);

    if (PyErr_Occurred()) { free(data); return NULL; }

    /* Parse dims → uint32_t array */
    PyObject *dims_seq = PySequence_Fast(dims_obj, "dims must be a sequence");
    if (!dims_seq) { free(data); return NULL; }

    Py_ssize_t ndims = PySequence_Fast_GET_SIZE(dims_seq);
    if (ndims > 8) ndims = 8;
    uint32_t dims[8] = {0};
    for (Py_ssize_t i = 0; i < ndims; i++) {
        dims[i] = (uint32_t)PyLong_AsUnsignedLong(PySequence_Fast_GET_ITEM(dims_seq, i));
    }
    Py_DECREF(dims_seq);

    /* Compress */
    qtsq_context_t ctx;
    qtsq_init(&ctx);

    int rc = qtsq_compress_tensor_quantized(&ctx, data, (size_t)count,
                                             dims, (uint8_t)ndims, prec);
    free(data);

    if (rc != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_RuntimeError, "Tensor compress failed (prec=%s, err=%d)",
                     precision_str, rc);
        return NULL;
    }

    rc = qtsq_write(&ctx, out_path);
    qtsq_free(&ctx);

    if (rc != 0) {
        PyErr_Format(PyExc_RuntimeError, "Write failed: %s (err=%d)", out_path, rc);
        return NULL;
    }

    return Py_BuildValue("{s:n,s:s,s:K}",
        "count", count,
        "precision", precision_str,
        "compressed_size", (unsigned long long)ctx.singularity_size);
}

/* ══════════════════════════════════════════════════════
 *  8. decompress_tensor(path) → {data, count, dims}
 * ══════════════════════════════════════════════════════ */
static PyObject* py_decompress_tensor(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    qtsq_context_t ctx;
    qtsq_init(&ctx);

    if (qtsq_read(&ctx, path) != 0) {
        qtsq_free(&ctx);
        PyErr_Format(PyExc_FileNotFoundError, "Failed to read: %s", path);
        return NULL;
    }

    float *out = NULL;
    size_t count = 0;
    int rc = qtsq_decompress_tensor(&ctx, &out, &count);

    if (rc != 0 || !out) {
        if (out) free(out);
        qtsq_free(&ctx);
        PyErr_Format(PyExc_RuntimeError, "Tensor decompress failed: %s (err=%d)", path, rc);
        return NULL;
    }

    /* Build data list */
    PyObject *data_list = PyList_New((Py_ssize_t)count);
    for (size_t i = 0; i < count; i++) {
        PyList_SET_ITEM(data_list, (Py_ssize_t)i, PyFloat_FromDouble((double)out[i]));
    }

    /* Build dims tuple */
    uint8_t ndims = ctx.schema.num_dims;
    PyObject *dims_tuple = PyTuple_New(ndims);
    for (int i = 0; i < ndims; i++) {
        PyTuple_SET_ITEM(dims_tuple, i, PyLong_FromUnsignedLong(ctx.schema.dimensions[i]));
    }

    free(out);

    PyObject *result = Py_BuildValue("{s:O,s:n,s:O,s:s}",
        "data", data_list,
        "count", (Py_ssize_t)count,
        "dims", dims_tuple,
        "encoding", ctx.schema.encoding);

    Py_DECREF(data_list);
    Py_DECREF(dims_tuple);
    qtsq_free(&ctx);
    return result;
}

/* ══════════════════════════════════════════════════════
 *  9. brain_save(path, weights, biases, memories, vector_dim, metadata_json)
 * ══════════════════════════════════════════════════════ */
static PyObject* py_brain_save(PyObject *self, PyObject *args, PyObject *kwargs) {
    const char *path;
    PyObject *weights_obj, *biases_obj, *memories_obj;
    unsigned int vector_dim = 0;
    const char *metadata_json = NULL;
    static char *kwlist[] = {"path", "weights", "biases", "memories",
                              "vector_dim", "metadata_json", NULL};

    if (!PyArg_ParseTupleAndKeywords(args, kwargs, "sOOO|Is", kwlist,
                                      &path, &weights_obj, &biases_obj,
                                      &memories_obj, &vector_dim, &metadata_json))
        return NULL;

    /* Helper: convert Python list → float array */
    #define PY_TO_FLOAT_ARRAY(obj, arr, cnt) do { \
        PyObject *seq = PySequence_Fast(obj, #obj " must be a sequence"); \
        if (!seq) return NULL; \
        cnt = (size_t)PySequence_Fast_GET_SIZE(seq); \
        arr = (float *)malloc(cnt * sizeof(float)); \
        if (!arr) { Py_DECREF(seq); return PyErr_NoMemory(); } \
        for (size_t _i = 0; _i < cnt; _i++) \
            arr[_i] = (float)PyFloat_AsDouble(PySequence_Fast_GET_ITEM(seq, (Py_ssize_t)_i)); \
        Py_DECREF(seq); \
        if (PyErr_Occurred()) { free(arr); return NULL; } \
    } while(0)

    float *weights = NULL, *biases = NULL, *memories = NULL;
    size_t wc = 0, bc = 0, mc = 0;

    PY_TO_FLOAT_ARRAY(weights_obj, weights, wc);
    PY_TO_FLOAT_ARRAY(biases_obj, biases, bc);
    PY_TO_FLOAT_ARRAY(memories_obj, memories, mc);

    #undef PY_TO_FLOAT_ARRAY

    /* Compute num_memories */
    size_t num_memories = (vector_dim > 0) ? mc / vector_dim : 0;

    int rc = qtsq_brain_save(path, weights, wc, biases, bc,
                              memories, num_memories, (size_t)vector_dim,
                              metadata_json);

    free(weights); free(biases); free(memories);

    if (rc != 0) {
        PyErr_Format(PyExc_RuntimeError, "Brain save failed (err=%d)", rc);
        return NULL;
    }

    Py_RETURN_NONE;
}

/* ══════════════════════════════════════════════════════
 *  10. brain_load(path) → dict
 * ══════════════════════════════════════════════════════ */
static PyObject* py_brain_load(PyObject *self, PyObject *args) {
    const char *path;
    if (!PyArg_ParseTuple(args, "s", &path))
        return NULL;

    float *weights = NULL, *biases = NULL, *memories = NULL;
    size_t wc = 0, bc = 0, mc = 0, vd = 0;
    char *metadata = NULL;

    int rc = qtsq_brain_load(path, &weights, &wc, &biases, &bc,
                              &memories, &mc, &vd, &metadata);
    if (rc != 0) {
        PyErr_Format(PyExc_RuntimeError, "Brain load failed: %s (err=%d)", path, rc);
        return NULL;
    }

    /* Build Python lists */
    PyObject *w_list = PyList_New((Py_ssize_t)wc);
    for (size_t i = 0; i < wc; i++)
        PyList_SET_ITEM(w_list, (Py_ssize_t)i, PyFloat_FromDouble((double)weights[i]));

    PyObject *b_list = PyList_New((Py_ssize_t)bc);
    for (size_t i = 0; i < bc; i++)
        PyList_SET_ITEM(b_list, (Py_ssize_t)i, PyFloat_FromDouble((double)biases[i]));

    size_t mem_total = mc * vd;
    PyObject *m_list = PyList_New((Py_ssize_t)mem_total);
    for (size_t i = 0; i < mem_total; i++)
        PyList_SET_ITEM(m_list, (Py_ssize_t)i, PyFloat_FromDouble((double)memories[i]));

    PyObject *result = Py_BuildValue("{s:O,s:n,s:O,s:n,s:O,s:n,s:n,s:s}",
        "weights", w_list, "weight_count", (Py_ssize_t)wc,
        "biases", b_list, "bias_count", (Py_ssize_t)bc,
        "memories", m_list, "num_memories", (Py_ssize_t)mc,
        "vector_dim", (Py_ssize_t)vd,
        "metadata", metadata ? metadata : "{}");

    Py_DECREF(w_list);
    Py_DECREF(b_list);
    Py_DECREF(m_list);
    free(weights); free(biases); free(memories); free(metadata);
    return result;
}

/* ── Module definition ── */

static PyMethodDef qtsq_methods[] = {
    {"read_vertices", (PyCFunction)py_read_vertices, METH_VARARGS|METH_KEYWORDS,
     "Read vertices from a .qtsq file."},
    {"compress_image", py_compress_image, METH_VARARGS,
     "Compress pixel data to .qtsq file.\n"
     "Args: pixels_bytes, width, height, channels, output_path, mode"},
    {"decompress_image", py_decompress_image, METH_VARARGS,
     "Decompress a .qtsq image file to pixel data.\n"
     "Returns dict: {pixels, width, height, channels}"},
    {"compress_text", py_compress_text, METH_VARARGS,
     "Compress text string to .qtsq file.\n"
     "Args: text, output_path"},
    {"decompress_raw", py_decompress_raw, METH_VARARGS,
     "Decompress a .qtsq file to raw bytes."},
    {"file_info", py_file_info, METH_VARARGS,
     "Get metadata from a .qtsq file without decompressing."},
    {"compress_tensor", (PyCFunction)py_compress_tensor, METH_VARARGS|METH_KEYWORDS,
     "Compress a float32 array to .qtsq tensor format.\n"
     "Args: data (list/bytes), count, dims (tuple), output_path, precision='f32'"},
    {"decompress_tensor", py_decompress_tensor, METH_VARARGS,
     "Decompress a .qtsq tensor file to float32 list.\n"
     "Returns dict: {data, count, dims}"},
    {"brain_save", (PyCFunction)py_brain_save, METH_VARARGS|METH_KEYWORDS,
     "Save AI brain state to .qtsq container.\n"
     "Args: path, weights, biases, memories, vector_dim, metadata_json"},
    {"brain_load", py_brain_load, METH_VARARGS,
     "Load AI brain state from .qtsq container.\n"
     "Returns dict: {weights, biases, memories, num_memories, vector_dim, metadata}"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef qtsq_module = {
    PyModuleDef_HEAD_INIT,
    "qtsq._native",
    "C extension for .qtsq file operations",
    -1,
    qtsq_methods
};

PyMODINIT_FUNC PyInit__native(void) {
    return PyModule_Create(&qtsq_module);
}
