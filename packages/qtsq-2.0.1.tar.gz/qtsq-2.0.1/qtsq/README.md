# qtsq — Python Module

Read `.qtsq` (Quantum Tensor Sequence) files in Python.

## Install

```bash
# Build the shared library first
make dylib

# Install the Python module
pip install .
```

## Usage

```python
import qtsq

data = qtsq.read("image.qtsq")

# Access data
data.vertices       # (N, 5) — x, y, R, G, B
data.positions      # (N, 2) — x, y coordinates
data.colors         # (N, 3) — RGB normalized [0,1]
data.triangles      # (M, 3) — Delaunay triangle indices
data.width          # image width
data.height         # image height

# Convert to PyTorch Geometric graph (for DTCN)
graph = data.to_graph(label=3)
```

## Requirements

- `libqtsq.dylib` — build with `make dylib`
- `numpy`, `scipy` — installed automatically
- `torch`, `torch-geometric` — optional, needed for `.to_graph()`
