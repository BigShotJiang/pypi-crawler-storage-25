"""Agent Finder registry adapters."""
