"""Integration tests for FastAPI endpoints using httpx test client."""

from contextlib import contextmanager

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(isolated_dirs):
    """Create a test client with isolated dirs.

    We must patch settings BEFORE importing app, so backend modules
    pick up the temp directories.
    """
    import backend.app as backend_app

    old_app_state = backend_app._app_state
    backend_app._app_state = None

    try:
        with TestClient(backend_app.app) as test_client:
            yield test_client
    finally:
        backend_app._app_state = old_app_state


@contextmanager
def configured_admin_token(token: str):
    """Temporarily configure backend admin auth for real endpoint tests."""
    import backend.app as backend_app
    from backend import config

    old_admin_token = config.settings.admin_token
    old_app_state = backend_app._app_state

    try:
        config.settings.admin_token = token
        backend_app._app_state = None
        yield
    finally:
        config.settings.admin_token = old_admin_token
        backend_app._app_state = old_app_state


def test_health(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["version"] == "3.0.0"


def test_hardware(client):
    resp = client.get("/hardware")
    assert resp.status_code == 200
    data = resp.json()
    assert "cpu_threads" in data
    assert "gpu" in data


def test_list_models_empty(client):
    resp = client.get("/models")
    assert resp.status_code == 200
    assert resp.json()["models"] == []


def test_model_names_empty(client):
    resp = client.get("/models/names")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["names"] == []


def test_get_model_404(client):
    resp = client.get("/models/nonexistent")
    assert resp.status_code == 404


def test_list_conversations_empty(client):
    resp = client.get("/conversations")
    assert resp.status_code == 200
    assert resp.json()["conversations"] == []


def test_create_conversation(client):
    resp = client.post("/conversations", json={"title": "Test Chat"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert data["conversation"]["title"] == "Test Chat"


def test_create_conversation_blank_title(client):
    resp = client.post("/conversations", json={"title": ""})
    assert resp.status_code == 422  # validation error


def test_sources_empty(client):
    resp = client.get("/sources")
    assert resp.status_code == 200
    assert resp.json()["sources"] == []


def test_add_source(client):
    with configured_admin_token("test-token"):
        resp = client.post(
            "/sources/add",
            json={
                "repo_url": "owner/repo",
                "model_id": "my-model",
                "runtime": "llama_cpp",
            },
            headers={"Authorization": "Bearer test-token"},
        )
    assert resp.status_code == 200
    source = resp.json()["source"]
    assert source["model_id"] == "my-model"
    assert source["owner"] == "owner"


def test_add_source_requires_admin_token_when_configured(client):
    with configured_admin_token("secret-token"):
        resp = client.post("/sources/add", json={
            "repo_url": "owner/repo",
            "model_id": "protected-model",
            "runtime": "llama_cpp",
        })
    assert resp.status_code == 401
    # Handle both old and new error messages
    assert resp.json()["detail"] in ["Admin token required", "Invalid admin token"]


def test_add_source_accepts_bearer_admin_token(client):
    with configured_admin_token("secret-token"):
        resp = client.post(
            "/sources/add",
            json={
                "repo_url": "owner/repo",
                "model_id": "protected-model",
                "runtime": "llama_cpp",
            },
            headers={"Authorization": "Bearer secret-token"},
        )
    assert resp.status_code == 200
    assert resp.json()["source"]["model_id"] == "protected-model"


def test_add_source_duplicate(client):
    with configured_admin_token("test-token"):
        headers = {"Authorization": "Bearer test-token"}
        client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "dup"}, headers=headers)
        resp = client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "dup"}, headers=headers)
    assert resp.status_code == 400


def test_remove_source(client):
    with configured_admin_token("test-token"):
        headers = {"Authorization": "Bearer test-token"}
        client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "remove-me"}, headers=headers)
        resp = client.delete("/sources/remove-me", headers=headers)
    assert resp.status_code == 200


def test_model_names_includes_sources(client):
    """Model names endpoint should include tracked source model_ids."""
    with configured_admin_token("test-token"):
        headers = {"Authorization": "Bearer test-token"}
        client.post("/sources/add", json={"repo_url": "owner/repo", "model_id": "from-source"}, headers=headers)
        resp = client.get("/models/names")
    assert "from-source" in resp.json()["names"]


def test_catalog(client):
    """Catalog endpoint should return free models."""
    resp = client.get("/catalog")
    assert resp.status_code == 200
    data = resp.json()
    assert data["ok"] is True
    assert len(data["models"]) >= 4


def test_catalog_recommended(client):
    resp = client.get("/catalog/recommended")
    assert resp.status_code == 200
    assert len(resp.json()["models"]) >= 2


def test_catalog_fits_ram(client):
    resp = client.get("/catalog/fits-ram", params={"max_gb": 2})
    assert resp.status_code == 200
    for m in resp.json()["models"]:
        assert m["min_ram_gb"] <= 2


def test_download_bad_url(client):
    """Downloading from a non-GitHub host should be rejected."""
    with configured_admin_token("test-token"):
        resp = client.post(
            "/models/download",
            json={
                "model_id": "bad-model",
                "source_url": "https://huggingface.co/model.gguf",
                "runtime": "llama_cpp",
            },
            headers={"Authorization": "Bearer test-token"},
        )
    assert resp.status_code == 400
    detail = resp.json()["detail"]
    # Handle both dict format (new) and string format (legacy)
    message = detail["message"] if isinstance(detail, dict) else detail
    assert "not allowed" in message.lower()


def test_download_requires_admin_token_when_configured(client):
    with configured_admin_token("secret-token"):
        resp = client.post("/models/download", json={
            "model_id": "bad-model",
            "source_url": "https://huggingface.co/model.gguf",
            "runtime": "llama_cpp",
        })
    assert resp.status_code == 401
    # Handle both old and new error messages
    assert resp.json()["detail"] in ["Admin token required", "Invalid admin token"]


def test_chat_no_model_loaded(client):
    """Unknown bare model IDs should fall back cleanly instead of crashing."""
    resp = client.post("/chat", json={
        "model_id": "test",
        "messages": [{"role": "user", "content": "hi"}],
    })
    assert resp.status_code == 200
    assert resp.headers["content-type"].startswith("text/event-stream")
    assert '"step": "thinking"' in resp.text
    assert '"done": true' in resp.text
