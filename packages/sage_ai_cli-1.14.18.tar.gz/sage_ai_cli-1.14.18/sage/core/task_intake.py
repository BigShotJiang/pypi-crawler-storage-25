"""Structured task intake for SAGE execution-loop normalization.

Converts raw user prompts into a stable execution spec that downstream
planning, TDD, validation, and reporting code can reuse.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from enum import Enum, auto
from pathlib import Path


class TaskKind(Enum):
    """High-level signals extracted from user input."""

    NO_PROMPT = auto()
    VAGUE_PROMPT = auto()
    DETAILED_PROMPT = auto()
    REPO_LEVEL_TASK = auto()
    FILE_LEVEL_TASK = auto()
    BUG_REPORT = auto()
    STACK_TRACE = auto()
    FEATURE_REQUEST = auto()
    REFACTOR_REQUEST = auto()
    TEST_FAILURE = auto()


class ExecutionMode(Enum):
    """Recommended execution mode for the request."""

    READ_ONLY_ANALYSIS = auto()
    IMPLEMENT_WITH_TDD = auto()
    ANALYZE_THEN_IMPLEMENT = auto()


_PATH_RE = re.compile(
    r"\b(?:[\w.-]+/)*[\w.-]+\.(?:py|js|ts|tsx|jsx|go|rs|java|json|ya?ml|toml|md|sh|css|html)\b"
)


@dataclass
class TaskIntake:
    """Normalized execution spec derived from raw user input."""

    original_prompt: str
    normalized_prompt: str
    kinds: list[TaskKind] = field(default_factory=list)
    goal: str = ""
    scope: str = ""
    constraints: list[str] = field(default_factory=list)
    assumptions: list[str] = field(default_factory=list)
    risks: list[str] = field(default_factory=list)
    success_criteria: list[str] = field(default_factory=list)
    referenced_files: list[str] = field(default_factory=list)
    execution_mode: ExecutionMode = ExecutionMode.IMPLEMENT_WITH_TDD
    no_prompt: bool = False

    def to_markdown(self) -> str:
        """Render the intake as a compact execution brief for the model."""
        lines = [
            "## Task Intake",
            f"**Goal:** {self.goal}",
            f"**Scope:** {self.scope}",
            "**Constraints:**",
            *[f"- {item}" for item in self.constraints],
            "**Assumptions:**",
            *[f"- {item}" for item in self.assumptions],
            "**Risks:**",
            *[f"- {item}" for item in self.risks],
            "**Success criteria:**",
            *[f"- {item}" for item in self.success_criteria],
        ]
        if self.referenced_files:
            lines.append("**Referenced files:**")
            lines.extend(f"- {path}" for path in self.referenced_files)
        return "\n".join(lines)


def _extract_referenced_files(prompt: str) -> list[str]:
    """Extract likely repo-relative file references from the prompt."""
    found: list[str] = []
    seen: set[str] = set()

    for match in _PATH_RE.findall(prompt):
        normalized = match.strip().lstrip("./")
        if normalized not in seen:
            seen.add(normalized)
            found.append(normalized)

    for special_name in ("Dockerfile", "Makefile", "README.md", "pyproject.toml"):
        if re.search(rf"\b{re.escape(special_name)}\b", prompt) and special_name not in seen:
            seen.add(special_name)
            found.append(special_name)

    return found


def _append_kind(kinds: list[TaskKind], kind: TaskKind) -> None:
    """Append a kind once while preserving discovery order."""
    if kind not in kinds:
        kinds.append(kind)


def _is_probably_readonly(prompt: str) -> bool:
    """Detect read-only analysis/review requests."""
    lower = prompt.lower()
    if not lower.strip():
        return False
    if re.search(r"\b(fix|implement|write|add|create|update|change|refactor|patch)\b", lower):
        return False
    return bool(
        re.search(
            r"\b(analyze|review|audit|assess|summarize|explain|what needs|what's wrong|identify)\b",
            lower,
        )
    )


def analyze_task_intake(prompt: str) -> TaskIntake:
    """Normalize a raw prompt into an execution-ready intake spec."""
    normalized = prompt.strip()
    lower = normalized.lower()
    kinds: list[TaskKind] = []
    referenced_files = _extract_referenced_files(normalized)
    no_prompt = not normalized

    if no_prompt:
        _append_kind(kinds, TaskKind.NO_PROMPT)
        _append_kind(kinds, TaskKind.REPO_LEVEL_TASK)
    else:
        if referenced_files:
            _append_kind(kinds, TaskKind.FILE_LEVEL_TASK)
        else:
            _append_kind(kinds, TaskKind.REPO_LEVEL_TASK)

        if len(normalized.split()) <= 5 or re.search(
            r"\b(fix this|look at this|check this|improve this|help)\b", lower
        ):
            _append_kind(kinds, TaskKind.VAGUE_PROMPT)
        else:
            _append_kind(kinds, TaskKind.DETAILED_PROMPT)

        if re.search(r"\b(traceback|stack trace|assertionerror|exception|^e\s{2,})\b", lower, re.MULTILINE):
            _append_kind(kinds, TaskKind.STACK_TRACE)

        if re.search(
            r"\b(pytest|test failure|failing test|assertionerror|assert |test_[\w]+|failed\b)\b",
            lower,
        ):
            _append_kind(kinds, TaskKind.TEST_FAILURE)

        if re.search(r"\b(bug|broken|regression|failing|failure|error)\b", lower):
            _append_kind(kinds, TaskKind.BUG_REPORT)

        if re.search(r"\b(refactor|restructure|cleanup|simplify)\b", lower):
            _append_kind(kinds, TaskKind.REFACTOR_REQUEST)

        if re.search(r"\b(feature|support|implement|build|create|add)\b", lower):
            _append_kind(kinds, TaskKind.FEATURE_REQUEST)

    if no_prompt:
        execution_mode = ExecutionMode.ANALYZE_THEN_IMPLEMENT
    elif _is_probably_readonly(normalized):
        execution_mode = ExecutionMode.READ_ONLY_ANALYSIS
    else:
        execution_mode = ExecutionMode.IMPLEMENT_WITH_TDD

    if no_prompt:
        goal = (
            "Analyze the repository, identify the project type and validation workflow, "
            "surface the highest-value issues, and recommend the next safe implementation step."
        )
        scope = "Repository-wide"
    elif TaskKind.STACK_TRACE in kinds or TaskKind.TEST_FAILURE in kinds:
        goal = "Diagnose the failing error path, find the root cause, and land the smallest verified fix."
        scope = (
            f"Focus on: {', '.join(referenced_files)}"
            if referenced_files
            else "Focus on the failing runtime and test path."
        )
    elif TaskKind.REFACTOR_REQUEST in kinds:
        goal = "Refactor the targeted code path while preserving intended behavior and existing contracts."
        scope = (
            f"Focus on: {', '.join(referenced_files)}"
            if referenced_files
            else "Refactor the explicitly requested subsystem."
        )
    elif TaskKind.FEATURE_REQUEST in kinds:
        goal = "Implement the requested functionality in the existing codebase using the established project patterns."
        scope = (
            f"Focus on: {', '.join(referenced_files)}"
            if referenced_files
            else "Repository-wide, constrained to the requested feature surface."
        )
    elif TaskKind.BUG_REPORT in kinds:
        goal = "Fix the reported defect and protect the behavior with regression coverage."
        scope = (
            f"Focus on: {', '.join(referenced_files)}"
            if referenced_files
            else "Repository-wide around the reported defect."
        )
    else:
        goal = "Understand the request, inspect the relevant code paths, and execute the safest next step."
        scope = (
            f"Focus on: {', '.join(referenced_files)}"
            if referenced_files
            else "Repository-wide"
        )

    constraints = [
        "Read existing files before making claims or edits.",
        "Write changes to the real repository paths on disk, not drafts or placeholders.",
        "Avoid destructive commands unless the task explicitly requires them.",
    ]
    if execution_mode != ExecutionMode.READ_ONLY_ANALYSIS:
        constraints.extend(
            [
                "Use TDD for code-writing work: tests first, implementation second, validation last.",
                "Run relevant tests or validation commands against the on-disk workspace.",
            ]
        )
    if no_prompt:
        constraints.append("Start with safe repo diagnostics before proposing or attempting implementation.")

    assumptions = [
        "The current working directory is the intended project root.",
        "Existing tests, configs, and code patterns are the source of truth.",
    ]
    if TaskKind.VAGUE_PROMPT in kinds or no_prompt:
        assumptions.append("If the request is underspecified, begin with analysis and narrow the first change by evidence.")

    risks = [
        "Hidden cross-file dependencies may make the smallest fix broader than expected.",
    ]
    if TaskKind.REFACTOR_REQUEST in kinds:
        risks.append("Behavior regressions are possible if the refactor changes runtime contracts.")
    if TaskKind.STACK_TRACE in kinds or TaskKind.TEST_FAILURE in kinds:
        risks.append("It is easy to treat the symptom instead of the underlying root cause.")
    if no_prompt:
        risks.append("Without explicit user steering, the first chosen task may not match the highest business priority.")

    if execution_mode == ExecutionMode.READ_ONLY_ANALYSIS:
        success_criteria = [
            "The repository or requested scope is understood from real files and project metadata.",
            "Findings are prioritized and grounded in concrete codebase evidence.",
            "The response explains the next recommended action without making silent code changes.",
        ]
    else:
        success_criteria = [
            "Relevant tests are added or updated to capture the intended behavior.",
            "Implementation changes are written to the real repository files on disk.",
            "Relevant validation passes against the updated on-disk workspace.",
            "The final report explains what changed, why it changed, and any remaining risks.",
        ]
        if no_prompt:
            success_criteria.insert(
                0,
                "Repository type, test/build commands, and the highest-value next task are identified before implementation begins.",
            )

    return TaskIntake(
        original_prompt=prompt,
        normalized_prompt=normalized,
        kinds=kinds,
        goal=goal,
        scope=scope,
        constraints=constraints,
        assumptions=assumptions,
        risks=risks,
        success_criteria=success_criteria,
        referenced_files=referenced_files,
        execution_mode=execution_mode,
        no_prompt=no_prompt,
    )


def build_no_prompt_default_prompt(project_root: Path | None = None) -> str:
    """Build the default mission prompt for no-prompt SAGE execution."""
    intake = analyze_task_intake("")
    root_note = (
        f"Current project root: {project_root}\n\n"
        if project_root is not None
        else ""
    )
    return (
        "No explicit task was provided.\n\n"
        f"{root_note}"
        f"{intake.to_markdown()}\n\n"
        "Default no-prompt workflow:\n"
        "1. Analyze the repository structure and identify the project type.\n"
        "2. Inspect tests, build scripts, configs, and CI entrypoints.\n"
        "3. Run only safe diagnostics first.\n"
        "4. Detect the most important current problems.\n"
        "5. Propose the best next implementation step, and only begin implementation if the evidence is strong.\n"
    )
