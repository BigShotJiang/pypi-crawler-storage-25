"""Tests for structured task intake and no-prompt defaults."""

from sage.core.task_intake import (
    ExecutionMode,
    TaskKind,
    analyze_task_intake,
    build_no_prompt_default_prompt,
)
from sage.main import _enhance_task_prompt


def test_no_prompt_intake_defaults_to_repo_analysis_then_implementation():
    intake = analyze_task_intake("")

    assert intake.no_prompt is True
    assert TaskKind.NO_PROMPT in intake.kinds
    assert TaskKind.REPO_LEVEL_TASK in intake.kinds
    assert intake.execution_mode == ExecutionMode.ANALYZE_THEN_IMPLEMENT
    assert "analyze" in intake.goal.lower()
    assert intake.scope == "Repository-wide"
    assert any("tests" in item.lower() for item in intake.success_criteria)


def test_file_level_bug_report_extracts_paths_and_tdd_mode():
    intake = analyze_task_intake(
        "Fix the failing auth regression in backend/app.py and backend/tests/test_auth.py"
    )

    assert TaskKind.FILE_LEVEL_TASK in intake.kinds
    assert TaskKind.BUG_REPORT in intake.kinds
    assert TaskKind.TEST_FAILURE in intake.kinds
    assert intake.execution_mode == ExecutionMode.IMPLEMENT_WITH_TDD
    assert "backend/app.py" in intake.referenced_files
    assert "backend/tests/test_auth.py" in intake.referenced_files
    assert any("test" in item.lower() for item in intake.success_criteria)


def test_stack_trace_intake_detects_runtime_failure():
    intake = analyze_task_intake(
        'Traceback (most recent call last):\n'
        '  File "backend/app.py", line 12, in <module>\n'
        "AssertionError: expected 200 == 500"
    )

    assert TaskKind.STACK_TRACE in intake.kinds
    assert TaskKind.TEST_FAILURE in intake.kinds
    assert "root cause" in intake.goal.lower()


def test_refactor_request_marks_behavior_risk():
    intake = analyze_task_intake(
        "Refactor sage/main.py to simplify task routing without changing behavior"
    )

    assert TaskKind.FILE_LEVEL_TASK in intake.kinds
    assert TaskKind.REFACTOR_REQUEST in intake.kinds
    assert any(
        "behavior" in risk.lower() or "regression" in risk.lower()
        for risk in intake.risks
    )


def test_intake_markdown_contains_required_sections():
    intake = analyze_task_intake("Implement a feature in sage/main.py")
    markdown = intake.to_markdown()

    for section in (
        "Goal",
        "Scope",
        "Constraints",
        "Assumptions",
        "Risks",
        "Success criteria",
    ):
        assert f"**{section}:**" in markdown


def test_no_prompt_default_prompt_contains_safe_repo_mission():
    prompt = build_no_prompt_default_prompt()

    assert "No explicit task was provided" in prompt
    assert "analyze the repository" in prompt.lower()
    assert "safe diagnostics" in prompt.lower()


def test_enhance_task_prompt_appends_structured_task_intake():
    result = _enhance_task_prompt("fix auth bug in backend/app.py")

    assert "## Task Intake" in result
    assert "**Goal:**" in result
    assert "**Success criteria:**" in result
