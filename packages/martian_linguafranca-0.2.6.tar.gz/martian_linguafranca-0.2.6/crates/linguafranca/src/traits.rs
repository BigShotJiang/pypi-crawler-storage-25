use crate::config::ConversionConfig;
use crate::error::{ConversionError, ConversionResult};

pub trait IntoOpenResponses {
    type Target;
    fn into_open_responses(
        self,
        config: Option<ConversionConfig>,
    ) -> Result<ConversionResult<Self::Target>, ConversionError>;
}

pub trait FromOpenResponses: Sized {
    type Source;
    fn from_open_responses(
        source: Self::Source,
        config: Option<ConversionConfig>,
    ) -> Result<ConversionResult<Self>, ConversionError>;
}
