use super::accum::AnthropicMessageAccum;
use crate::anthropic::convert::ctx::ConversionCtx;
use crate::anthropic::convert::helpers::*;
use crate::anthropic::request::AnthropicRequest;
use crate::anthropic::types::*;
use crate::config::ConversionConfig;
use crate::convert::mapping::LossyTryFromWithCtx;
use crate::error::{ConversionError, ConversionResult};
use crate::open_responses::request::{OpenResponsesInput, OpenResponsesRequest};
use crate::open_responses::types::*;
use crate::traits::FromOpenResponses;

impl FromOpenResponses for AnthropicRequest {
    type Source = OpenResponsesRequest;

    fn from_open_responses(
        source: OpenResponsesRequest,
        config: Option<ConversionConfig>,
    ) -> Result<ConversionResult<Self>, ConversionError> {
        let strip = config.as_ref().is_some_and(|c| c.strip_encrypted_reasoning);
        let mut ctx = if strip {
            ConversionCtx::with_config(crate::anthropic::convert::config::AnthropicConvertConfig {
                strip_encrypted_reasoning: true,
                ..Default::default()
            })
        } else {
            ConversionCtx::new()
        };
        let had_instructions = source.instructions.is_some();
        let (messages, system_from_input) =
            convert_open_responses_input_to_anthropic_messages(source.input, &mut ctx);

        let system = system_from_input;
        let tools = source.tools.map(|tools| {
            tools
                .into_iter()
                .filter_map(|t| convert_open_responses_tool_to_anthropic_messages(t, &mut ctx))
                .collect()
        });
        let mut tool_choice = source
            .tool_choice
            .and_then(|tc| convert_open_responses_tool_choice_to_anthropic_messages(tc, &mut ctx));
        let max_tokens = source
            .max_output_tokens
            .unwrap_or(ctx.config.default_max_tokens);
        let thinking = source.reasoning.and_then(|r| {
            convert_open_responses_reasoning_to_anthropic_messages_thinking(r, max_tokens, &mut ctx)
        });
        normalize_thinking_tool_choice_compatibility(thinking.as_ref(), &mut tool_choice, &mut ctx);

        // Anthropic requires max_tokens > thinking.budget_tokens. If a
        // degenerate max_output_tokens (e.g. 0 or 1) was provided, bump
        // max_tokens so the request is valid.
        let max_tokens = match &thinking {
            Some(AnthropicThinkingConfig::Enabled { budget_tokens, .. })
                if *budget_tokens >= max_tokens =>
            {
                let fixed = budget_tokens + 1;
                ctx.warn(
                    "max_tokens",
                    format!(
                        "max_tokens ({max_tokens}) must exceed thinking.budget_tokens ({budget_tokens}); bumped to {fixed}"
                    ),
                );
                fixed
            }
            _ => max_tokens,
        };

        let mut result = ConversionResult::with_warnings(
            AnthropicRequest {
                model: source.model,
                max_tokens,
                messages,
                system,
                temperature: source.temperature,
                top_p: source.top_p,
                top_k: None,
                stop_sequences: None,
                stream: source.stream,
                metadata: None,
                tools,
                tool_choice,
                thinking,
                service_tier: source.service_tier.and_then(|tier| {
                    AnthropicServiceTier::lossy_try_from(tier, &mut ctx, "service_tier")
                }),
                cache_control: Some(convert_open_responses_prompt_cache_retention_to_anthropic(
                    source.prompt_cache_retention.as_deref(),
                )),
                container: None,
                inference_geo: None,
                output_config: convert_open_responses_text_to_anthropic_output_config(
                    source.text.as_ref(),
                    &mut ctx,
                ),
            },
            ctx.into_warnings(),
        );

        result.warn_unsupported(
            "Anthropic",
            &[
                ("presence_penalty", source.presence_penalty.is_some()),
                ("frequency_penalty", source.frequency_penalty.is_some()),
                ("truncation", source.truncation.is_some()),
                ("store", source.store.is_some()),
                ("background", source.background.is_some()),
                (
                    "previous_response_id",
                    source.previous_response_id.is_some(),
                ),
                ("parallel_tool_calls", source.parallel_tool_calls.is_some()),
                ("top_logprobs", source.top_logprobs.is_some()),
            ],
        );
        if had_instructions {
            result.warn("instructions", "not supported in Anthropic, dropped");
        }

        Ok(result)
    }
}

fn is_instruction_message(item: &InputItem) -> bool {
    matches!(
        item,
        InputItem::Message {
            role: MessageRole::System | MessageRole::Developer,
            ..
        }
    )
}

fn normalize_thinking_tool_choice_compatibility(
    thinking: Option<&AnthropicThinkingConfig>,
    tool_choice: &mut Option<AnthropicToolChoice>,
    ctx: &mut ConversionCtx,
) {
    let has_extended_thinking = matches!(
        thinking,
        Some(AnthropicThinkingConfig::Enabled { .. } | AnthropicThinkingConfig::Adaptive { .. })
    );
    if !has_extended_thinking {
        return;
    }

    let replacement = match tool_choice.as_ref() {
        Some(AnthropicToolChoice::Any {
            disable_parallel_tool_use,
        }) => Some(AnthropicToolChoice::Auto {
            disable_parallel_tool_use: *disable_parallel_tool_use,
        }),
        Some(AnthropicToolChoice::Tool {
            disable_parallel_tool_use,
            ..
        }) => Some(AnthropicToolChoice::Auto {
            disable_parallel_tool_use: *disable_parallel_tool_use,
        }),
        _ => None,
    };

    if let Some(replacement) = replacement {
        ctx.warn(
            "tool_choice",
            "Anthropic extended thinking is not compatible with tool_choice any/tool; mapped to auto",
        );
        *tool_choice = Some(replacement);
    }
}

fn convert_open_responses_input_to_anthropic_messages(
    input: OpenResponsesInput,
    ctx: &mut ConversionCtx,
) -> (Vec<AnthropicMessage>, Option<AnthropicSystem>) {
    match input {
        OpenResponsesInput::Text(t) => (
            vec![AnthropicMessage {
                role: AnthropicRole::User,
                content: AnthropicMessageContent::Text(t),
            }],
            None,
        ),
        OpenResponsesInput::Items(items) => {
            let mut accum = AnthropicMessageAccum::new();
            let mut system_blocks: Vec<AnthropicSystemBlock> = Vec::new();
            let mut in_conversation_phase = false;

            for (i, item) in items.into_iter().enumerate() {
                ctx.push(format!("input[{i}]"));

                let is_instruction = is_instruction_message(&item);
                let interleaved_instruction = is_instruction && in_conversation_phase;
                if !is_instruction {
                    in_conversation_phase = true;
                }

                match item {
                    InputItem::Message {
                        role: MessageRole::System | MessageRole::Developer,
                        content,
                        ..
                    } => {
                        let appended = append_open_responses_content_to_anthropic_system_blocks(
                            &mut system_blocks,
                            content,
                            ctx,
                        );
                        if appended && interleaved_instruction {
                            ctx.warn(
                                "role",
                                "instruction message was hoisted to Anthropic system; original position not preserved",
                            );
                        }
                    }
                    InputItem::Message { role, content, .. } => {
                        convert_open_responses_message_to_anthropic_messages(
                            &mut accum, role, content, ctx,
                        );
                    }
                    InputItem::FunctionCall {
                        call_id,
                        name,
                        arguments,
                        ..
                    } => {
                        convert_open_responses_function_call_to_anthropic_messages(
                            &mut accum, call_id, name, arguments, ctx,
                        );
                    }
                    InputItem::FunctionCallOutput {
                        call_id, output, ..
                    } => {
                        convert_open_responses_function_call_output_to_anthropic_messages(
                            &mut accum, call_id, output, ctx,
                        );
                    }
                    InputItem::Reasoning {
                        summary,
                        encrypted_content,
                        ..
                    } => {
                        if !ctx.config.strip_encrypted_reasoning {
                            convert_open_responses_reasoning_to_anthropic_messages_block(
                                &mut accum,
                                summary,
                                encrypted_content,
                                ctx,
                            );
                        }
                    }
                    InputItem::CustomToolCall { .. } => {
                        ctx.warn(
                            "custom_tool_call",
                            "custom tool calls are not supported in Anthropic, dropped",
                        );
                    }
                    InputItem::CustomToolCallOutput { .. } => {
                        ctx.warn(
                            "custom_tool_call_output",
                            "custom tool call outputs are not supported in Anthropic, dropped",
                        );
                    }
                    InputItem::WebSearchCall { .. } => {
                        ctx.warn(
                            "web_search_call",
                            "web_search_call cannot be converted to Anthropic (missing encrypted_content), dropped",
                        );
                    }
                    InputItem::ToolSearchCall { id, arguments, .. } => {
                        let block_id = id.unwrap_or_else(|| format!("ts_{i}"));
                        accum.push_blocks(
                            AnthropicRole::Assistant,
                            vec![AnthropicInputContentBlock::ServerToolUse {
                                id: block_id,
                                name: ctx.config.tool_search_name.to_string(),
                                input: arguments,
                                cache_control: None,
                            }],
                        );
                    }
                    InputItem::ToolSearchOutput {
                        call_id,
                        tools,
                        execution,
                        ..
                    } => {
                        let tool_use_id = call_id.unwrap_or_else(|| format!("ts_{i}"));
                        if execution == Some(ToolSearchExecution::Client) {
                            // Client-side: emit tool_result with tool_reference blocks
                            let blocks: Vec<AnthropicToolResultBlock> = tools
                                .into_iter()
                                .filter_map(|t| match t {
                                    Tool::Function { name, .. } => {
                                        Some(AnthropicToolResultBlock::ToolReference {
                                            tool_name: name,
                                        })
                                    }
                                    other => {
                                        ctx.warn(
                                            "tool_search_output",
                                            format!("only function tools can be referenced, dropped {:?}", std::mem::discriminant(&other)),
                                        );
                                        None
                                    }
                                })
                                .collect();
                            accum.push_blocks(
                                AnthropicRole::User,
                                vec![AnthropicInputContentBlock::ToolResult {
                                    tool_use_id,
                                    content: Some(AnthropicToolResultContent::Blocks(blocks)),
                                    is_error: None,
                                    cache_control: None,
                                }],
                            );
                        } else {
                            // Server-side: emit tool_search_tool_result
                            let tool_references = tools
                                .into_iter()
                                .filter_map(|t| match t {
                                    Tool::Function { name, .. } => {
                                        Some(AnthropicToolReference::new(name))
                                    }
                                    other => {
                                        ctx.warn(
                                            "tool_search_output",
                                            format!("only function tools can be referenced, dropped {:?}", std::mem::discriminant(&other)),
                                        );
                                        None
                                    }
                                })
                                .collect();
                            accum.push_blocks(
                                AnthropicRole::User,
                                vec![AnthropicInputContentBlock::ToolSearchToolResult {
                                    tool_use_id,
                                    content: AnthropicToolSearchToolResultContent::SearchResult {
                                        tool_references,
                                    },
                                    cache_control: None,
                                }],
                            );
                        }
                    }
                    InputItem::ItemReference { .. } => {
                        ctx.warn("item_reference", "not supported in Anthropic, dropped");
                    }
                }
                ctx.pop();
            }

            let system = match system_blocks.len() {
                0 => None,
                1 => Some(AnthropicSystem::Text(system_blocks.pop().unwrap().text)),
                _ => Some(AnthropicSystem::Blocks(system_blocks)),
            };
            (accum.into_messages(), system)
        }
    }
}

fn convert_open_responses_message_to_anthropic_messages(
    accum: &mut AnthropicMessageAccum,
    role: MessageRole,
    content: InputContent,
    ctx: &mut ConversionCtx,
) {
    let am_role = match role {
        MessageRole::User => AnthropicRole::User,
        MessageRole::Assistant => AnthropicRole::Assistant,
        MessageRole::System | MessageRole::Developer => {
            ctx.warn(
                "role",
                "instruction message was not hoisted before message conversion; coerced to user",
            );
            AnthropicRole::User
        }
    };

    match content {
        InputContent::Text(t) => accum.push_text(am_role, t),
        InputContent::Parts(parts) => {
            let blocks = parts
                .into_iter()
                .enumerate()
                .filter_map(|(j, part)| {
                    ctx.push(format!("content[{j}]"));
                    let result = convert_open_responses_part_to_anthropic_messages(part, ctx);
                    ctx.pop();
                    result
                })
                .collect();
            accum.push_blocks(am_role, blocks);
        }
    }
}

fn convert_open_responses_function_call_to_anthropic_messages(
    accum: &mut AnthropicMessageAccum,
    call_id: String,
    name: String,
    arguments: String,
    ctx: &mut ConversionCtx,
) {
    let input = serde_json::from_str(&arguments).unwrap_or_else(|_| {
        ctx.warn(
            "function_call.arguments",
            "malformed JSON arguments, replaced with empty object",
        );
        serde_json::Value::Object(Default::default())
    });
    let block = AnthropicInputContentBlock::ToolUse {
        id: call_id,
        name,
        input,
        cache_control: None,
    };
    accum.push_blocks(AnthropicRole::Assistant, vec![block]);
}

fn convert_open_responses_function_call_output_to_anthropic_messages(
    accum: &mut AnthropicMessageAccum,
    call_id: String,
    output: FunctionCallOutputValue,
    ctx: &mut ConversionCtx,
) {
    let content = match output {
        FunctionCallOutputValue::Text(t) => Some(AnthropicToolResultContent::Text(t)),
        FunctionCallOutputValue::Parts(parts) => {
            let blocks: Vec<AnthropicToolResultBlock> = parts
                .into_iter()
                .enumerate()
                .filter_map(|(j, p)| {
                    ctx.push(format!("output[{j}]"));
                    let result = match p {
                        InputContentPart::Text { text }
                        | InputContentPart::OutputText { text, .. } => {
                            Some(AnthropicToolResultBlock::Text { text })
                        }
                        InputContentPart::Image { image_url, .. } => {
                            let url = image_url?;
                            let (source, warn) = url_to_image_source(url);
                            if let Some(msg) = warn {
                                ctx.warn("image", msg);
                            }
                            Some(AnthropicToolResultBlock::Image { source })
                        }
                        InputContentPart::File {
                            filename,
                            file_data,
                            file_url,
                        } => {
                            let source = open_responses_file_to_document_source(
                                file_url,
                                file_data,
                                filename.as_deref(),
                            )?;
                            Some(AnthropicToolResultBlock::Document {
                                source,
                                citations: None,
                                context: None,
                                title: filename,
                            })
                        }
                    };
                    ctx.pop();
                    result
                })
                .collect();
            if blocks.is_empty() {
                None
            } else {
                Some(AnthropicToolResultContent::Blocks(blocks))
            }
        }
    };
    let block = AnthropicInputContentBlock::ToolResult {
        tool_use_id: call_id,
        content,
        is_error: None,
        cache_control: None,
    };
    accum.push_blocks(AnthropicRole::User, vec![block]);
}

/// Non-empty summary → Thinking (signature restored from encrypted_content).
/// Empty summary + encrypted_content → RedactedThinking.
fn convert_open_responses_reasoning_to_anthropic_messages_block(
    accum: &mut AnthropicMessageAccum,
    summary: Vec<SummaryContent>,
    encrypted_content: Option<String>,
    ctx: &mut ConversionCtx,
) {
    let block = if !summary.is_empty() {
        let text = summary
            .into_iter()
            .map(|s| s.text)
            .collect::<Vec<_>>()
            .join("\n");
        AnthropicInputContentBlock::Thinking {
            thinking: text,
            signature: encrypted_content.unwrap_or_default(),
        }
    } else if let Some(data) = encrypted_content {
        AnthropicInputContentBlock::RedactedThinking { data }
    } else {
        ctx.warn("reasoning", "empty reasoning item, skipped");
        return;
    };
    accum.push_blocks(AnthropicRole::Assistant, vec![block]);
}

fn append_open_responses_content_to_anthropic_system_blocks(
    system_blocks: &mut Vec<AnthropicSystemBlock>,
    content: InputContent,
    ctx: &mut ConversionCtx,
) -> bool {
    let before_len = system_blocks.len();

    match content {
        InputContent::Text(text) => {
            system_blocks.push(AnthropicSystemBlock {
                kind: "text".into(),
                text,
                cache_control: None,
            });
        }
        InputContent::Parts(parts) => {
            for (j, part) in parts.into_iter().enumerate() {
                ctx.push(format!("content[{j}]"));
                match part {
                    InputContentPart::Text { text } | InputContentPart::OutputText { text, .. } => {
                        system_blocks.push(AnthropicSystemBlock {
                            kind: "text".into(),
                            text,
                            cache_control: None,
                        });
                    }
                    InputContentPart::Image { .. } => {
                        ctx.warn(
                            "image",
                            "images are not representable in Anthropic system and were dropped",
                        );
                    }
                    InputContentPart::File { .. } => {
                        ctx.warn(
                            "file",
                            "files are not representable in Anthropic system and were dropped",
                        );
                    }
                }
                ctx.pop();
            }
        }
    }

    let appended = system_blocks.len() != before_len;
    if !appended {
        ctx.warn(
            "content",
            "instruction message had no representable Anthropic system text and was dropped",
        );
    }
    appended
}

fn convert_open_responses_part_to_anthropic_messages(
    part: InputContentPart,
    ctx: &mut ConversionCtx,
) -> Option<AnthropicInputContentBlock> {
    match part {
        InputContentPart::Text { text } | InputContentPart::OutputText { text, .. } => {
            Some(AnthropicInputContentBlock::Text {
                text,
                cache_control: None,
                citations: None,
            })
        }
        InputContentPart::Image { image_url, .. } => {
            let url = image_url?;
            let (source, warn) = url_to_image_source(url);
            if let Some(msg) = warn {
                ctx.warn("image", msg);
            }
            Some(AnthropicInputContentBlock::Image {
                source,
                cache_control: None,
            })
        }
        InputContentPart::File {
            filename,
            file_data,
            file_url,
        } => {
            let source =
                open_responses_file_to_document_source(file_url, file_data, filename.as_deref())?;
            Some(AnthropicInputContentBlock::Document {
                source,
                cache_control: None,
                citations: None,
                context: None,
                title: filename,
            })
        }
    }
}

fn convert_open_responses_tool_to_anthropic_messages(
    tool: Tool,
    ctx: &mut ConversionCtx,
) -> Option<AnthropicToolUnion> {
    match tool {
        Tool::Function {
            name,
            description,
            parameters,
            strict,
            defer_loading,
        } => Some(AnthropicToolUnion::Known(AnthropicTool {
            name,
            description,
            input_schema: parameters.unwrap_or(serde_json::json!({"type": "object"})),
            cache_control: None,
            strict,
            kind: None,
            defer_loading,
        })),
        Tool::WebSearch {
            search_context_size,
            user_location,
            filters,
        } => {
            if search_context_size.is_some() {
                ctx.warn("search_context_size", "not supported in Anthropic, dropped");
            }
            let mut obj = serde_json::json!({
                "type": ctx.config.web_search_type,
                "name": ctx.config.web_search_name
            });
            if let Some(loc) = user_location {
                obj["user_location"] = serde_json::json!({
                    "type": loc.kind,
                    "city": loc.city,
                    "country": loc.country,
                    "region": loc.region,
                    "timezone": loc.timezone,
                });
            }
            if let Some(f) = filters
                && !f.allowed_domains.is_empty()
            {
                obj["allowed_domains"] = serde_json::json!(f.allowed_domains);
            }
            Some(AnthropicToolUnion::Other(obj))
        }
        Tool::Custom { .. } => {
            ctx.warn(
                "custom_tool",
                "custom tools are not supported in Anthropic, dropped",
            );
            None
        }
        Tool::ToolSearch { execution, .. } => {
            if execution == Some(ToolSearchExecution::Client) {
                // Client-side tool search uses a regular function tool on
                // the Anthropic side — no dedicated tool definition needed.
                None
            } else {
                // OR Tool::ToolSearch doesn't distinguish bm25/regex, so we
                // use the configured default. The variant is not preserved.
                Some(AnthropicToolUnion::Other(serde_json::json!({
                    "type": ctx.config.tool_search_type,
                    "name": ctx.config.tool_search_name
                })))
            }
        }
    }
}

fn convert_open_responses_tool_choice_to_anthropic_messages(
    tc: ToolChoice,
    ctx: &mut ConversionCtx,
) -> Option<AnthropicToolChoice> {
    match tc {
        ToolChoice::Mode(ToolChoiceMode::Auto) => Some(AnthropicToolChoice::Auto {
            disable_parallel_tool_use: None,
        }),
        ToolChoice::Mode(ToolChoiceMode::Required) => Some(AnthropicToolChoice::Any {
            disable_parallel_tool_use: None,
        }),
        ToolChoice::Mode(ToolChoiceMode::None) => Some(AnthropicToolChoice::None),
        ToolChoice::Specific(SpecificToolChoice::Function { name }) => match name {
            Some(name) => Some(AnthropicToolChoice::Tool {
                name,
                disable_parallel_tool_use: None,
            }),
            None => {
                ctx.warn(
                    "tool_choice",
                    "specific function tool choice is missing name; tool_choice dropped",
                );
                None
            }
        },
        ToolChoice::Specific(SpecificToolChoice::Custom { name }) => {
            Some(AnthropicToolChoice::Tool {
                name,
                disable_parallel_tool_use: None,
            })
        }
        ToolChoice::AllowedTools(_) => {
            ctx.warn(
                "tool_choice.allowed_tools",
                "not representable in Anthropic, dropped",
            );
            None
        }
    }
}

fn convert_open_responses_text_to_anthropic_output_config(
    text: Option<&TextConfig>,
    ctx: &mut ConversionCtx,
) -> Option<AnthropicOutputConfig> {
    let text = text?;

    if text.verbosity.is_some() {
        ctx.warn("text.verbosity", "not supported in Anthropic, dropped");
    }

    let format = match &text.format {
        Some(TextFormat::JsonSchema {
            schema,
            name,
            description,
            strict,
        }) => {
            if !name.is_empty() {
                ctx.warn("text.format.name", "not supported in Anthropic, dropped");
            }
            if description.is_some() {
                ctx.warn(
                    "text.format.description",
                    "not supported in Anthropic, dropped",
                );
            }
            if strict.is_some() {
                ctx.warn("text.format.strict", "not supported in Anthropic, dropped");
            }
            match schema {
                Some(s) => Some(AnthropicOutputFormat::JsonSchema { schema: s.clone() }),
                None => {
                    ctx.warn(
                        "text.format.schema",
                        "schema is missing, dropped json_schema format",
                    );
                    None
                }
            }
        }
        Some(TextFormat::Text) => None,
        Some(TextFormat::JsonObject) => {
            ctx.warn(
                "text.format",
                "json_object format not supported in Anthropic, dropped",
            );
            None
        }
        None => None,
    };

    format.as_ref()?;

    Some(AnthropicOutputConfig {
        effort: None,
        format,
    })
}

fn convert_open_responses_reasoning_to_anthropic_messages_thinking(
    reasoning: ReasoningConfig,
    max_tokens: u64,
    ctx: &mut ConversionCtx,
) -> Option<AnthropicThinkingConfig> {
    let ReasoningConfig { effort, summary } = reasoning;

    match (effort, summary) {
        (Some(ReasoningEffort::None), Some(_)) => {
            ctx.warn(
                "reasoning.summary",
                "reasoning.summary is not representable when reasoning.effort is none; dropped",
            );
            Some(AnthropicThinkingConfig::Disabled)
        }
        (Some(ReasoningEffort::None), None) => Some(AnthropicThinkingConfig::Disabled),
        (Some(effort), summary) => {
            let display = match summary {
                None => Some(AnthropicThinkingDisplay::Omitted),
                Some(ReasoningSummary::Auto) => None,
                Some(ReasoningSummary::Concise) => Some(AnthropicThinkingDisplay::Summarized),
                Some(ReasoningSummary::Detailed) => {
                    ctx.warn(
                        "reasoning.summary",
                        "Anthropic only supports summarized/omitted thinking display; mapped to summarized",
                    );
                    Some(AnthropicThinkingDisplay::Summarized)
                }
            };
            let budget_tokens = ctx.config.effort_to_budget(&effort, max_tokens)
                .unwrap_or_else(|_| {
                    ctx.warn(
                        "max_tokens",
                        format!(
                            "max_tokens ({max_tokens}) is too small for reasoning budget; defaulting budget to 1"
                        ),
                    );
                    1
                });
            Some(AnthropicThinkingConfig::Enabled {
                budget_tokens,
                display,
            })
        }
        (None, Some(summary)) => {
            let display = match summary {
                ReasoningSummary::Auto => None,
                ReasoningSummary::Concise => Some(AnthropicThinkingDisplay::Summarized),
                ReasoningSummary::Detailed => {
                    ctx.warn(
                        "reasoning.summary",
                        "Anthropic only supports summarized/omitted thinking display; mapped to summarized",
                    );
                    Some(AnthropicThinkingDisplay::Summarized)
                }
            };
            Some(AnthropicThinkingConfig::Adaptive { display })
        }
        (None, None) => None,
    }
}

/// Open Responses caches prompts by default; Anthropic requires explicit opt-in.
/// We always return a `CacheControl` with `type: "ephemeral"` and derive the
/// TTL from the Open Responses `prompt_cache_retention` value:
///
/// - `None` or `"in-memory"` → AM `ttl: None` (AM defaults to 5 min)
/// - `"24h"` → AM `ttl: Some("1h")` (AM's max extended tier)
fn convert_open_responses_prompt_cache_retention_to_anthropic(
    retention: Option<&str>,
) -> CacheControl {
    let ttl = match retention {
        Some("24h") => Some("1h".to_string()),
        _ => None, // None | "in-memory" → AM default (5m)
    };
    CacheControl {
        kind: "ephemeral".to_string(),
        ttl,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::traits::FromOpenResponses;

    #[test]
    fn reasoning_summary_is_dropped_when_effort_is_none() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: Some(ReasoningEffort::None),
                summary: Some(ReasoningSummary::Concise),
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(thinking, Some(AnthropicThinkingConfig::Disabled));
        let warnings = ctx.into_warnings();
        assert_eq!(warnings.len(), 1);
        assert_eq!(warnings[0].field, "reasoning.summary");
        assert_eq!(
            warnings[0].message,
            "reasoning.summary is not representable when reasoning.effort is none; dropped"
        );
    }

    #[test]
    fn reasoning_summary_auto_maps_to_no_display_with_effort() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: Some(ReasoningEffort::Low),
                summary: Some(ReasoningSummary::Auto),
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(
            thinking,
            Some(AnthropicThinkingConfig::Enabled {
                budget_tokens: 3276,
                display: None,
            })
        );
        assert!(ctx.into_warnings().is_empty());
    }

    #[test]
    fn reasoning_summary_concise_maps_to_summarized() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: Some(ReasoningEffort::Low),
                summary: Some(ReasoningSummary::Concise),
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(
            thinking,
            Some(AnthropicThinkingConfig::Enabled {
                budget_tokens: 3276,
                display: Some(AnthropicThinkingDisplay::Summarized),
            })
        );
        assert!(ctx.into_warnings().is_empty());
    }

    #[test]
    fn reasoning_summary_detailed_maps_to_summarized_with_warning() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: Some(ReasoningEffort::Low),
                summary: Some(ReasoningSummary::Detailed),
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(
            thinking,
            Some(AnthropicThinkingConfig::Enabled {
                budget_tokens: 3276,
                display: Some(AnthropicThinkingDisplay::Summarized),
            })
        );
        let warnings = ctx.into_warnings();
        assert_eq!(warnings.len(), 1);
        assert_eq!(warnings[0].field, "reasoning.summary");
    }

    #[test]
    fn reasoning_no_summary_maps_to_omitted() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: Some(ReasoningEffort::Low),
                summary: None,
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(
            thinking,
            Some(AnthropicThinkingConfig::Enabled {
                budget_tokens: 3276,
                display: Some(AnthropicThinkingDisplay::Omitted),
            })
        );
        assert!(ctx.into_warnings().is_empty());
    }

    #[test]
    fn reasoning_summary_auto_maps_to_adaptive_no_display() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: None,
                summary: Some(ReasoningSummary::Auto),
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(
            thinking,
            Some(AnthropicThinkingConfig::Adaptive { display: None })
        );
        assert!(ctx.into_warnings().is_empty());
    }

    #[test]
    fn reasoning_summary_concise_maps_to_adaptive_summarized() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: None,
                summary: Some(ReasoningSummary::Concise),
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(
            thinking,
            Some(AnthropicThinkingConfig::Adaptive {
                display: Some(AnthropicThinkingDisplay::Summarized),
            })
        );
        assert!(ctx.into_warnings().is_empty());
    }

    #[test]
    fn reasoning_summary_detailed_maps_to_adaptive_summarized_with_warning() {
        let mut ctx = ConversionCtx::new();
        let thinking = convert_open_responses_reasoning_to_anthropic_messages_thinking(
            ReasoningConfig {
                effort: None,
                summary: Some(ReasoningSummary::Detailed),
            },
            32_768,
            &mut ctx,
        );

        assert_eq!(
            thinking,
            Some(AnthropicThinkingConfig::Adaptive {
                display: Some(AnthropicThinkingDisplay::Summarized),
            })
        );
        let warnings = ctx.into_warnings();
        assert_eq!(warnings.len(), 1);
        assert_eq!(warnings[0].field, "reasoning.summary");
    }

    #[test]
    fn required_tool_choice_with_extended_thinking_maps_to_auto_with_warning() {
        let result = AnthropicRequest::from_open_responses(
            OpenResponsesRequest {
                model: "gpt-5".to_string(),
                input: OpenResponsesInput::Text("hi".to_string()),
                tool_choice: Some(ToolChoice::Mode(ToolChoiceMode::Required)),
                reasoning: Some(ReasoningConfig {
                    effort: Some(ReasoningEffort::Low),
                    summary: None,
                }),
                ..Default::default()
            },
            None,
        )
        .unwrap();

        assert_eq!(
            result.value.tool_choice,
            Some(AnthropicToolChoice::Auto {
                disable_parallel_tool_use: None,
            })
        );
        assert!(result.warnings.iter().any(|warning| {
            warning.field == "tool_choice"
                && warning.message
                    == "Anthropic extended thinking is not compatible with tool_choice any/tool; mapped to auto"
        }));
    }

    #[test]
    fn specific_tool_choice_with_adaptive_thinking_maps_to_auto_with_warning() {
        let result = AnthropicRequest::from_open_responses(
            OpenResponsesRequest {
                model: "gpt-5".to_string(),
                input: OpenResponsesInput::Text("hi".to_string()),
                tool_choice: Some(ToolChoice::Specific(SpecificToolChoice::Custom {
                    name: "lookup".to_string(),
                })),
                reasoning: Some(ReasoningConfig {
                    effort: None,
                    summary: Some(ReasoningSummary::Concise),
                }),
                ..Default::default()
            },
            None,
        )
        .unwrap();

        assert_eq!(
            result.value.tool_choice,
            Some(AnthropicToolChoice::Auto {
                disable_parallel_tool_use: None,
            })
        );
        assert!(result.warnings.iter().any(|warning| {
            warning.field == "tool_choice"
                && warning.message
                    == "Anthropic extended thinking is not compatible with tool_choice any/tool; mapped to auto"
        }));
    }

    #[test]
    fn prompt_cache_retention_none_maps_to_ephemeral_no_ttl() {
        let cc = convert_open_responses_prompt_cache_retention_to_anthropic(None);
        assert_eq!(cc.kind, "ephemeral");
        assert_eq!(cc.ttl, None);
    }

    #[test]
    fn prompt_cache_retention_in_memory_maps_to_ephemeral_no_ttl() {
        let cc = convert_open_responses_prompt_cache_retention_to_anthropic(Some("in-memory"));
        assert_eq!(cc.kind, "ephemeral");
        assert_eq!(cc.ttl, None);
    }

    #[test]
    fn prompt_cache_retention_24h_maps_to_ephemeral_1h_ttl() {
        let cc = convert_open_responses_prompt_cache_retention_to_anthropic(Some("24h"));
        assert_eq!(cc.kind, "ephemeral");
        assert_eq!(cc.ttl, Some("1h".to_string()));
    }

    #[test]
    fn or_to_am_always_injects_cache_control() {
        let result = AnthropicRequest::from_open_responses(
            OpenResponsesRequest {
                model: "test".to_string(),
                input: OpenResponsesInput::Text("hi".to_string()),
                ..Default::default()
            },
            None,
        )
        .unwrap();

        assert_eq!(
            result.value.cache_control,
            Some(CacheControl {
                kind: "ephemeral".to_string(),
                ttl: None,
            })
        );
    }

    #[test]
    fn or_to_am_24h_retention_maps_to_1h_ttl() {
        let result = AnthropicRequest::from_open_responses(
            OpenResponsesRequest {
                model: "test".to_string(),
                input: OpenResponsesInput::Text("hi".to_string()),
                prompt_cache_retention: Some("24h".to_string()),
                ..Default::default()
            },
            None,
        )
        .unwrap();

        assert_eq!(
            result.value.cache_control,
            Some(CacheControl {
                kind: "ephemeral".to_string(),
                ttl: Some("1h".to_string()),
            })
        );
    }
}
