use crate::anthropic::convert::config::AnthropicConvertConfig;
use crate::anthropic::types::{AnthropicKnownServiceTier, AnthropicServiceTier};
use crate::convert::ctx::ConversionCtx;
use crate::convert::mapping::LossyTryFromWithCtx;
use crate::open_responses::types::ServiceTier;

impl From<AnthropicKnownServiceTier> for ServiceTier {
    fn from(value: AnthropicKnownServiceTier) -> Self {
        match value {
            AnthropicKnownServiceTier::Auto => ServiceTier::Auto,
            AnthropicKnownServiceTier::Standard => ServiceTier::Default,
            AnthropicKnownServiceTier::Priority => ServiceTier::Priority,
        }
    }
}

impl LossyTryFromWithCtx<AnthropicServiceTier, AnthropicConvertConfig> for ServiceTier {
    fn lossy_try_from(
        value: AnthropicServiceTier,
        ctx: &mut ConversionCtx<AnthropicConvertConfig>,
        field: &str,
    ) -> Option<Self> {
        match value {
            AnthropicServiceTier::Known(known) => Some(known.into()),
            AnthropicServiceTier::Other(value) => match value.as_str() {
                // Backward compatibility for older fixtures/inputs.
                "default" => Some(ServiceTier::Default),
                "flex" => Some(ServiceTier::Flex),
                other => {
                    ctx.warn(
                        field,
                        format!("unknown Anthropic service_tier '{other}', dropped"),
                    );
                    None
                }
            },
        }
    }
}

impl LossyTryFromWithCtx<ServiceTier, AnthropicConvertConfig> for AnthropicServiceTier {
    fn lossy_try_from(
        value: ServiceTier,
        ctx: &mut ConversionCtx<AnthropicConvertConfig>,
        field: &str,
    ) -> Option<Self> {
        Some(match value {
            ServiceTier::Auto => AnthropicServiceTier::Known(AnthropicKnownServiceTier::Auto),
            ServiceTier::Default => {
                AnthropicServiceTier::Known(AnthropicKnownServiceTier::Standard)
            }
            ServiceTier::Priority => {
                AnthropicServiceTier::Known(AnthropicKnownServiceTier::Priority)
            }
            ServiceTier::Flex => {
                ctx.warn(
                    field,
                    "service_tier=flex is not available in Anthropic and was mapped to standard",
                );
                AnthropicServiceTier::Known(AnthropicKnownServiceTier::Standard)
            }
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::anthropic::convert::ctx::ConversionCtx as AnthropicConversionCtx;

    #[test]
    fn known_service_tier_maps_to_open_responses() {
        let mut ctx = AnthropicConversionCtx::new();
        let tier = ServiceTier::lossy_try_from(
            AnthropicServiceTier::Known(AnthropicKnownServiceTier::Standard),
            &mut ctx,
            "service_tier",
        );
        assert_eq!(tier, Some(ServiceTier::Default));
        assert!(ctx.into_warnings().is_empty());
    }

    #[test]
    fn legacy_default_string_maps_to_default_without_warning() {
        let mut ctx = AnthropicConversionCtx::new();
        let tier = ServiceTier::lossy_try_from(
            AnthropicServiceTier::Other("default".into()),
            &mut ctx,
            "service_tier",
        );
        assert_eq!(tier, Some(ServiceTier::Default));
        assert!(ctx.into_warnings().is_empty());
    }

    #[test]
    fn unknown_anthropic_service_tier_warns_and_drops() {
        let mut ctx = AnthropicConversionCtx::new();
        let tier = ServiceTier::lossy_try_from(
            AnthropicServiceTier::Other("burst".into()),
            &mut ctx,
            "service_tier",
        );
        assert_eq!(tier, None);
        let warnings = ctx.into_warnings();
        assert_eq!(warnings.len(), 1);
        assert_eq!(warnings[0].field, "service_tier");
    }

    #[test]
    fn flex_maps_to_standard_with_warning() {
        let mut ctx = AnthropicConversionCtx::new();
        let tier =
            AnthropicServiceTier::lossy_try_from(ServiceTier::Flex, &mut ctx, "service_tier");
        assert_eq!(
            tier,
            Some(AnthropicServiceTier::Known(
                AnthropicKnownServiceTier::Standard
            ))
        );
        let warnings = ctx.into_warnings();
        assert_eq!(warnings.len(), 1);
        assert_eq!(warnings[0].field, "service_tier");
    }
}
