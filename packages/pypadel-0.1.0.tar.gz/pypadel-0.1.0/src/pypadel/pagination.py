"""Pagination helpers exposed by the SDK."""

from __future__ import annotations

from collections.abc import Callable, Iterator
from dataclasses import dataclass, field
from typing import Generic, TypeVar

T = TypeVar("T")
FetchPage = Callable[[int], "Page[T]"]


@dataclass
class Page(Generic[T]):
    """A typed page of API results."""

    items: list[T]
    current_page: int
    total_pages: int | None
    has_next_page: bool
    _fetch_page: FetchPage[T] | None = field(default=None, repr=False, compare=False)

    def __iter__(self) -> Iterator[T]:
        return iter(self.items)

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int) -> T:
        return self.items[index]

    def __bool__(self) -> bool:
        return len(self.items) > 0

    def __contains__(self, item: object) -> bool:
        return item in self.items

    def next_page(self) -> Page[T] | None:
        """Fetch the next page if one is available."""

        if not self.has_next_page or self._fetch_page is None:
            return None
        return self._fetch_page(self.current_page + 1)

    def iter_all(self) -> Iterator[T]:
        """Yield items from this page and all subsequent pages lazily."""

        page: Page[T] | None = self
        while page is not None:
            yield from page.items
            page = page.next_page()
