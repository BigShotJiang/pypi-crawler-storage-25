"""Shared service behavior."""

from __future__ import annotations

from datetime import date
from typing import TYPE_CHECKING

from ..exceptions import ApiResponseError, NotFoundError
from ..models.matches import MatchCard
from ..models.players import PlayerDetail, PlayerSummary
from ..models.tournaments import Tournament
from ..transport import ApiEnvelope

if TYPE_CHECKING:
    from ..client import PremierPadelClient


PlayerArg = PlayerSummary | PlayerDetail | int | str
TournamentArg = Tournament | int | str
MatchArg = MatchCard | int | str


class BaseService:
    """Base class for all resource services."""

    def __init__(self, client: PremierPadelClient) -> None:
        self._client = client

    def _lang(self, lang: str | None) -> str:
        return lang or self._client._config.lang

    def _unwrap(self, envelope: ApiEnvelope, *, not_found: bool = False) -> object:
        if envelope.status == 1:
            return envelope.data
        message = envelope.message or "Premier Padel API request failed."
        if not_found or "Invalid parameter value" in message:
            raise NotFoundError(message, status=envelope.status, payload=envelope.raw)
        raise ApiResponseError(message, status=envelope.status, payload=envelope.raw)

    def _resolve_player_id(
        self,
        player: PlayerArg,
        *,
        lang: str | None = None,
    ) -> int:
        if isinstance(player, PlayerSummary):
            self._client._remember_player(player)
            return player.id
        if isinstance(player, PlayerDetail):
            self._client._remember_player(player)
            return player.id
        if isinstance(player, int):
            return player
        if player.isdigit():
            return int(player)
        cached = self._client._players_by_slug.get(player)
        if cached is not None:
            return cached.id
        detail = self._client.players.get(player, lang=lang)
        return detail.id

    def _resolve_player_slug(
        self,
        player: PlayerArg,
        *,
        lang: str | None = None,
    ) -> str:
        if isinstance(player, (PlayerSummary, PlayerDetail)):
            self._client._remember_player(player)
            return player.slug
        if isinstance(player, int) or (isinstance(player, str) and player.isdigit()):
            player_id = int(player) if isinstance(player, str) else player
            cached = self._client._players_by_id.get(player_id)
            if cached is not None:
                return cached.slug
            raise NotFoundError(
                f"Cannot resolve player id {player_id} to a slug. "
                f"Fetch the player via slug or listing first."
            )
        return player

    def _resolve_match_id(self, match: MatchArg) -> int:
        if isinstance(match, MatchCard):
            return match.id
        if isinstance(match, int):
            return match
        if match.isdigit():
            return int(match)
        raise NotFoundError(f"Expected a numeric match identifier, got {match!r}.")

    def _resolve_tournament_slug(
        self,
        tournament: TournamentArg,
        *,
        lang: str | None = None,
    ) -> str:
        if isinstance(tournament, Tournament):
            self._client._remember_tournament(tournament)
            return tournament.slug
        if isinstance(tournament, int):
            resolved = self._client._lookup_tournament_by_id(tournament, lang=lang)
            return resolved.slug
        if tournament.isdigit():
            resolved = self._client._lookup_tournament_by_id(int(tournament), lang=lang)
            return resolved.slug
        cached = self._client._tournaments_by_slug.get(tournament)
        if cached is not None:
            return cached.slug
        return tournament

    def _resolve_tournament_id(
        self,
        tournament: TournamentArg,
        *,
        lang: str | None = None,
    ) -> int:
        if isinstance(tournament, Tournament):
            self._client._remember_tournament(tournament)
            return tournament.id
        if isinstance(tournament, int):
            return tournament
        if tournament.isdigit():
            return int(tournament)
        cached = self._client._tournaments_by_slug.get(tournament)
        if cached is not None:
            return cached.id
        resolved = self._client._lookup_tournament_by_slug(tournament, lang=lang)
        return resolved.id

    @staticmethod
    def _coerce_date(value: date | str) -> date:
        if isinstance(value, date):
            return value
        return date.fromisoformat(value)
