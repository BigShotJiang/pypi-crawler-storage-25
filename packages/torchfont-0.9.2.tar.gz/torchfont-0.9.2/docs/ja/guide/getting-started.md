# クイックスタート

<!-- markdownlint-disable MD013 -->

このページでは、TorchFont を導入して最初の Dataset と DataLoader を動かすまでを扱います。

## 前提

- Python 3.10 以上
- PyTorch 2.3 以上

## 1. インストール

::: code-group

```bash [uv (推奨)]
uv add torchfont
```

```bash [pip]
pip install torchfont
```

:::

## 2. ローカルフォントを読む

`GlyphDataset` はローカルディレクトリ配下のフォント（`.ttf` / `.otf` /
`.ttc` / `.otc`）を走査して Dataset を作ります。

```python
from torchfont.datasets import GlyphDataset

# root は存在するディレクトリを指定してください
# 例: root="~/fonts"（このリポジトリを clone 済みなら "tests/fonts" も可）
dataset = GlyphDataset(
    root="~/fonts",
    patterns=("*.ttf",),
    codepoints=range(0x20, 0x7F),
)

print(f"samples={len(dataset)}")
print(f"styles={len(dataset.style_classes)}")
print(f"contents={len(dataset.content_classes)}")

sample = dataset[0]
print(sample.types.shape)   # (seq_len,)
print(sample.coords.shape)  # (seq_len, 6)
```

::: warning
`GlyphDataset` は `root` を絶対パス化してから読み込みます。存在しないパスを渡すと初期化時に例外になります。
:::

## 3. DataLoader に渡す

グリフは可変長なので、batch ごとに outline tensor を padding する小さな
`collate_fn` を定義します。

```python
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader

from torchfont.datasets import GlyphDataset, GlyphSample


def transform(sample: GlyphSample):
    return sample.types, sample.coords


def collate_fn(batch):
    types = pad_sequence([types for types, _ in batch], batch_first=True)
    coords = pad_sequence([coords for _, coords in batch], batch_first=True)
    return types, coords


dataset = GlyphDataset(
    root="~/fonts",
    patterns=("*.ttf",),
    codepoints=range(0x20, 0x7F),
    transform=transform,
)
loader = DataLoader(dataset, batch_size=32, shuffle=True, collate_fn=collate_fn)

types_t, coords_t = next(iter(loader))
print(types_t.shape)   # (32, L)
print(coords_t.shape)  # (32, L, 6)
```

## 4. ローカル checkout を大きなコーパスに向ける

リポジトリの同期は TorchFont の外側で行い、その checkout を
`GlyphDataset` に渡します。

```bash
git clone --depth 1 https://github.com/google/fonts data/google/fonts
```

```python
from torchfont.datasets import GlyphDataset

dataset = GlyphDataset(
    root="data/google/fonts",
    patterns=(
        "apache/*/*.ttf",
        "ofl/*/*.ttf",
        "ufl/*/*.ttf",
        "!ofl/adobeblank/AdobeBlank-Regular.ttf",
    ),
)

print(len(dataset), len(dataset.style_classes), len(dataset.content_classes))
```

TorchFont は checkout 済みディレクトリを通常のローカルフォルダとして扱います。
Git などで更新したあとは、ネイティブな indexing state がディスク内容と
ずれないように Dataset インスタンスを作り直してください。Dataset の利用中
にファイルが変わった場合の結果は未定義で、不正な sample や runtime error
につながることがあります。

## よくある最初の改善

- 2 次セグメントを 3 次へ統一する: `quad_to_cubic(types, coords)`
- シーケンス長の制限や整形は dataset transform やモデル固有 utility で行う
- 学習対象を絞る: `codepoints=` や `patterns=`

## 次に読むページ

- [グリフデータ形式](/ja/guide/glyph-data-format)
- [DataLoader との統合](/ja/guide/dataloader)
- [Git checkout 済みリポジトリを使う](/ja/guide/git-repos)
- [Google Fonts](/ja/guide/google-fonts)
