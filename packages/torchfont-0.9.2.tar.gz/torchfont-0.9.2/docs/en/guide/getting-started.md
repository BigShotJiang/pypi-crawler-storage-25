# Quickstart

This page gets you from installation to a working dataset and DataLoader setup.

## Requirements

- Python 3.10+
- PyTorch 2.3+

## 1. Install

::: code-group

```bash [uv (Recommended)]
uv add torchfont
```

```bash [pip]
pip install torchfont
```

:::

## 2. Load local fonts

`GlyphDataset` scans local directories for `.ttf`, `.otf`, `.ttc`, and `.otc`
files.

```python
from torchfont.datasets import GlyphDataset

# root must point to an existing directory
# e.g. root="~/fonts" (or "tests/fonts" if you cloned this repository)
dataset = GlyphDataset(
    root="~/fonts",
    patterns=("*.ttf",),
    codepoints=range(0x20, 0x7F),
)

print(f"samples={len(dataset)}")
print(f"styles={len(dataset.style_classes)}")
print(f"contents={len(dataset.content_classes)}")

sample = dataset[0]
print(sample.types.shape)   # (seq_len,)
print(sample.coords.shape)  # (seq_len, 6)
```

::: warning
`GlyphDataset` resolves `root` to an absolute path during initialization. If the
path does not exist, initialization fails.
:::

## 3. Plug into DataLoader

Glyph sequences are variable-length, so define a small `collate_fn` that pads
the outline tensors for each batch.

```python
from torch.nn.utils.rnn import pad_sequence
from torch.utils.data import DataLoader

from torchfont.datasets import GlyphDataset, GlyphSample


def transform(sample: GlyphSample):
    return sample.types, sample.coords


def collate_fn(batch):
    types = pad_sequence([types for types, _ in batch], batch_first=True)
    coords = pad_sequence([coords for _, coords in batch], batch_first=True)
    return types, coords


dataset = GlyphDataset(
    root="~/fonts",
    patterns=("*.ttf",),
    codepoints=range(0x20, 0x7F),
    transform=transform,
)
loader = DataLoader(dataset, batch_size=32, shuffle=True, collate_fn=collate_fn)

types_t, coords_t = next(iter(loader))
print(types_t.shape)   # (32, L)
print(coords_t.shape)  # (32, L, 6)
```

## 4. Scale up with a local checkout

Sync the repository outside TorchFont, then point `GlyphDataset` at the
checked-out directory.

```bash
git clone --depth 1 https://github.com/google/fonts data/google/fonts
```

```python
from torchfont.datasets import GlyphDataset

dataset = GlyphDataset(
    root="data/google/fonts",
    patterns=(
        "apache/*/*.ttf",
        "ofl/*/*.ttf",
        "ufl/*/*.ttf",
        "!ofl/adobeblank/AdobeBlank-Regular.ttf",
    ),
)

print(len(dataset), len(dataset.style_classes), len(dataset.content_classes))
```

TorchFont treats any checkout as a normal local directory. Use Git or another
sync tool to refresh the checkout, then recreate the dataset instance so the
native indexing state stays in sync with the files. If files change while a
dataset instance is still in use, results are undefined and may include
incorrect samples or runtime errors.

## Common Next Tweaks

- Convert quadratic segments to cubic: `quad_to_cubic(types, coords)`
- Shape or limit tensors in your dataset or model-specific utility code
- Narrow the dataset scope: `codepoints=` and `patterns=`

## Read Next

- [Glyph Data Format](/en/guide/glyph-data-format)
- [DataLoader Integration](/en/guide/dataloader)
- [Git Repository Checkouts](/en/guide/git-repos)
- [Google Fonts](/en/guide/google-fonts)
