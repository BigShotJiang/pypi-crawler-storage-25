"""Filesystem-based tenka repository implementation."""

from pathlib import Path

from daimyo.config import settings
from daimyo.domain import Tenka, TenkaFulfillment
from daimyo.infrastructure.filesystem.tenka_parser import parse_tenka, parse_tenka_fulfillment
from daimyo.infrastructure.filesystem.yaml_parser import parse_yaml_file, validate_scope_name
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)


class FilesystemTenkaRepository:
    """Repository for loading tenka data from the filesystem.

    Tenka files are optional and stored alongside other scope files:
    - ``tenka.yml``: user stories and acceptance criteria
    - ``tenka.fulfillment.yml``: validation results (local-only, never inherited)
    """

    def __init__(self, rules_path: str | None = None):
        """Initialize the repository.

        :param rules_path: Path to the rules directory (defaults to config setting)
        :type rules_path: str | None
        """
        self.rules_path = Path(rules_path or settings.RULES_PATH)
        logger.info(f"Initialized FilesystemTenkaRepository with path: {self.rules_path}")

    def get_tenka(self, scope_name: str) -> Tenka | None:
        """Load tenka for a scope from the filesystem.

        :param scope_name: Scope name (directory name)
        :type scope_name: str
        :returns: Tenka instance if tenka.yml exists, None otherwise
        :rtype: Tenka | None
        :raises InvalidScopeError: If tenka data is malformed
        :raises YAMLParseError: If YAML parsing fails
        """
        validate_scope_name(scope_name)
        tenka_file = self.rules_path / scope_name / "tenka.yml"

        if not tenka_file.exists():
            logger.debug(f"No tenka.yml found for scope '{scope_name}'")
            return None

        logger.debug(f"Loading tenka for scope '{scope_name}' from {tenka_file}")
        data = parse_yaml_file(tenka_file)
        tenka = parse_tenka(data)
        logger.info(
            f"Loaded tenka for scope '{scope_name}': {len(tenka.stories)} user stories"
        )
        return tenka

    def get_tenka_fulfillment(self, scope_name: str) -> TenkaFulfillment | None:
        """Load validation fulfillment data for a scope.

        :param scope_name: Scope name (directory name)
        :type scope_name: str
        :returns: TenkaFulfillment if tenka.fulfillment.yml exists, None otherwise
        :rtype: TenkaFulfillment | None
        :raises InvalidScopeError: If fulfillment data is malformed
        :raises YAMLParseError: If YAML parsing fails
        """
        validate_scope_name(scope_name)
        fulfillment_file = self.rules_path / scope_name / "tenka.fulfillment.yml"

        if not fulfillment_file.exists():
            logger.debug(f"No tenka.fulfillment.yml found for scope '{scope_name}'")
            return None

        logger.debug(
            f"Loading tenka fulfillment for scope '{scope_name}' from {fulfillment_file}"
        )
        data = parse_yaml_file(fulfillment_file)
        fulfillment = parse_tenka_fulfillment(data)
        logger.info(
            f"Loaded tenka fulfillment for scope '{scope_name}': "
            f"{len(fulfillment.fulfillments)} AC entries"
        )
        return fulfillment


__all__ = ["FilesystemTenkaRepository"]
