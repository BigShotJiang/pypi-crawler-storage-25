"""YAML parsing utilities for tenka.yml and tenka.fulfillment.yml."""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

from daimyo.domain import (
    ACFulfillment,
    AcceptanceCriterion,
    AutoValidation,
    InvalidScopeError,
    ManualValidation,
    Tenka,
    TenkaFulfillment,
    UserStory,
)

_US_ID_PATTERN = re.compile(r"^US\d+$")
_AC_ID_PATTERN = re.compile(r"^AC\d+\.\d+$")


def parse_tenka(data: dict[str, Any]) -> Tenka:
    """Parse the contents of a tenka.yml file into a Tenka instance.

    Expected top-level key: ``tenka``.

    :param data: Parsed YAML dictionary
    :type data: dict[str, Any]
    :returns: Tenka with all user stories and acceptance criteria
    :rtype: Tenka
    :raises InvalidScopeError: If the structure is malformed
    """
    tenka = Tenka()

    raw = data.get("tenka")
    if raw is None:
        return tenka

    if not isinstance(raw, dict):
        raise InvalidScopeError("'tenka' must be a mapping of user story ids to story data")

    for us_id, us_data in raw.items():
        us_id = str(us_id)
        if not _US_ID_PATTERN.match(us_id):
            raise InvalidScopeError(
                f"User story id '{us_id}' must match format US<number> (e.g. US1, US123)"
            )
        if not isinstance(us_data, dict):
            raise InvalidScopeError(f"User story '{us_id}' must be a mapping")

        who = us_data.get("who")
        what = us_data.get("what")
        why = us_data.get("why")

        if not isinstance(who, str) or not who.strip():
            raise InvalidScopeError(f"User story '{us_id}': 'who' must be a non-empty string")
        if not isinstance(what, str) or not what.strip():
            raise InvalidScopeError(f"User story '{us_id}': 'what' must be a non-empty string")
        if not isinstance(why, str) or not why.strip():
            raise InvalidScopeError(f"User story '{us_id}': 'why' must be a non-empty string")

        active = us_data.get("active", True)
        if not isinstance(active, bool):
            raise InvalidScopeError(f"User story '{us_id}': 'active' must be a boolean")

        story = UserStory(id=us_id, who=who, what=what, why=why, active=active)

        raw_acs = us_data.get("acs")
        if raw_acs is not None:
            if not isinstance(raw_acs, dict):
                raise InvalidScopeError(f"User story '{us_id}': 'acs' must be a mapping")
            for ac_id, ac_data in raw_acs.items():
                ac_id = str(ac_id)
                story.acs[ac_id] = _parse_ac(us_id, ac_id, ac_data)

        tenka.stories[us_id] = story

    return tenka


def _parse_ac(us_id: str, ac_id: str, ac_data: Any) -> AcceptanceCriterion:
    """Parse a single acceptance criterion entry.

    :param us_id: Parent user story id (for error messages)
    :type us_id: str
    :param ac_id: Acceptance criterion id
    :type ac_id: str
    :param ac_data: Raw mapping from YAML
    :type ac_data: Any
    :returns: AcceptanceCriterion instance
    :rtype: AcceptanceCriterion
    :raises InvalidScopeError: If the structure is malformed
    """
    if not _AC_ID_PATTERN.match(ac_id):
        raise InvalidScopeError(
            f"Acceptance criterion id '{ac_id}' must match format AC<number>.<number> (e.g. AC1.1, AC123.5)"
        )
    ctx = f"AC '{ac_id}' of user story '{us_id}'"

    if not isinstance(ac_data, dict):
        raise InvalidScopeError(f"{ctx}: must be a mapping")

    then = ac_data.get("then")
    if not isinstance(then, str) or not then.strip():
        raise InvalidScopeError(f"{ctx}: 'then' must be a non-empty string")

    given = ac_data.get("given")
    if given is not None and not isinstance(given, str):
        raise InvalidScopeError(f"{ctx}: 'given' must be a string or null")

    when_clause = ac_data.get("when")
    if when_clause is not None and not isinstance(when_clause, str):
        raise InvalidScopeError(f"{ctx}: 'when' must be a string or null")

    active = ac_data.get("active", True)
    if not isinstance(active, bool):
        raise InvalidScopeError(f"{ctx}: 'active' must be a boolean")

    return AcceptanceCriterion(
        id=ac_id,
        then=then,
        given=given if given else None,
        when_clause=when_clause if when_clause else None,
        active=active,
    )


def parse_tenka_fulfillment(data: dict[str, Any]) -> TenkaFulfillment:
    """Parse the contents of a tenka.fulfillment.yml file.

    Expected top-level key: ``tenka_fulfillment``.

    :param data: Parsed YAML dictionary
    :type data: dict[str, Any]
    :returns: TenkaFulfillment with all validation entries
    :rtype: TenkaFulfillment
    :raises InvalidScopeError: If the structure is malformed
    """
    fulfillment = TenkaFulfillment()

    raw = data.get("tenka_fulfillment")
    if raw is None:
        return fulfillment

    if not isinstance(raw, dict):
        raise InvalidScopeError(
            "'tenka_fulfillment' must be a mapping of AC reference ids to validation lists"
        )

    for ac_ref, entries in raw.items():
        ac_ref = str(ac_ref)
        if not _AC_ID_PATTERN.match(ac_ref):
            raise InvalidScopeError(
                f"Fulfillment AC reference '{ac_ref}' must match format AC<number>.<number> (e.g. AC1.1, AC123.5)"
            )
        if not isinstance(entries, list):
            raise InvalidScopeError(f"Fulfillment for '{ac_ref}' must be a list")

        ac_fulfillment = ACFulfillment(ac_ref=ac_ref)
        for idx, entry in enumerate(entries):
            ac_fulfillment.validations.append(_parse_validation_entry(ac_ref, idx, entry))

        fulfillment.fulfillments[ac_ref] = ac_fulfillment

    return fulfillment


def _parse_validation_entry(
    ac_ref: str, idx: int, entry: Any
) -> AutoValidation | ManualValidation:
    """Parse a single validation entry.

    :param ac_ref: AC reference id (for error messages)
    :type ac_ref: str
    :param idx: Entry index (for error messages)
    :type idx: int
    :param entry: Raw mapping from YAML
    :type entry: Any
    :returns: AutoValidation or ManualValidation instance
    :rtype: AutoValidation | ManualValidation
    :raises InvalidScopeError: If the structure is malformed
    """
    ctx = f"Fulfillment entry [{idx}] for '{ac_ref}'"

    if not isinstance(entry, dict):
        raise InvalidScopeError(f"{ctx}: must be a mapping")

    entry_type = entry.get("type")
    if entry_type not in ("auto", "manual"):
        raise InvalidScopeError(
            f"{ctx}: 'type' must be 'auto' or 'manual', got {entry_type!r}"
        )

    passed = entry.get("passed", False)
    if not isinstance(passed, bool):
        raise InvalidScopeError(f"{ctx}: 'passed' must be a boolean")

    timestamp_raw = entry.get("timestamp")
    if timestamp_raw is None:
        raise InvalidScopeError(f"{ctx}: 'timestamp' is required")
    timestamp = _parse_timestamp(ctx, timestamp_raw)

    if entry_type == "auto":
        source = entry.get("source")
        name = entry.get("name")
        if not isinstance(source, str) or not source.strip():
            raise InvalidScopeError(f"{ctx}: 'source' must be a non-empty string for auto entries")
        if not isinstance(name, str) or not name.strip():
            raise InvalidScopeError(f"{ctx}: 'name' must be a non-empty string for auto entries")
        message = entry.get("message")
        if message is not None and not isinstance(message, str):
            raise InvalidScopeError(f"{ctx}: 'message' must be a string or null")
        return AutoValidation(
            source=source,
            name=name,
            passed=passed,
            timestamp=timestamp,
            message=message if message else None,
        )

    verdict = entry.get("verdict")
    if not isinstance(verdict, str) or not verdict.strip():
        raise InvalidScopeError(
            f"{ctx}: 'verdict' must be a non-empty string for manual entries"
        )
    return ManualValidation(verdict=verdict, passed=passed, timestamp=timestamp)


def _parse_timestamp(ctx: str, raw: Any) -> datetime:
    """Parse an ISO 8601 timestamp string.

    :param ctx: Context description for error messages
    :type ctx: str
    :param raw: Raw timestamp value from YAML
    :type raw: Any
    :returns: Parsed datetime (timezone-aware if tz info present)
    :rtype: datetime
    :raises InvalidScopeError: If the timestamp cannot be parsed
    """
    if isinstance(raw, datetime):
        return raw if raw.tzinfo is not None else raw.replace(tzinfo=timezone.utc)
    if not isinstance(raw, str):
        raise InvalidScopeError(f"{ctx}: 'timestamp' must be a string or datetime")
    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        return dt
    except ValueError as exc:
        raise InvalidScopeError(f"{ctx}: invalid 'timestamp' format: {exc}") from exc


__all__ = ["parse_tenka", "parse_tenka_fulfillment"]
