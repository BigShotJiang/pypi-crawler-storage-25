"""Filtering service for tenka user stories and acceptance criteria."""

from __future__ import annotations

from enum import Enum

from daimyo.domain import (
    ACFulfillment,
    AcceptanceCriterion,
    Tenka,
    TenkaFulfillment,
    UserStory,
)
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)

VALID_STATUS_VALUES: frozenset[str] = frozenset({"all", "validated", "not_validated"})
VALID_AUTOMATION_VALUES: frozenset[str] = frozenset({"all", "automated", "has_manual"})


class StatusFilter(Enum):
    """Filter by validation status."""

    ALL = "all"
    VALIDATED = "validated"
    NOT_VALIDATED = "not_validated"


class AutomationFilter(Enum):
    """Filter by automation coverage."""

    ALL = "all"
    AUTOMATED = "automated"
    HAS_MANUAL = "has_manual"


class TenkaFilteringService:
    """Service for filtering tenka user stories and acceptance criteria.

    All filtering methods respect the following defaults:
    - Inactive USs/ACs are hidden by default (``include_inactive=False``)
    - Validation status is not filtered by default (``StatusFilter.ALL``)
    """

    def filter_user_stories(
        self,
        tenka: Tenka,
        fulfillment: TenkaFulfillment | None,
        include_inactive: bool = False,
        status_filter: StatusFilter = StatusFilter.ALL,
    ) -> list[UserStory]:
        """Return a filtered list of user stories.

        A US is "fully validated" iff all its active ACs are validated.

        :param tenka: Source tenka
        :type tenka: Tenka
        :param fulfillment: Optional validation data
        :type fulfillment: TenkaFulfillment | None
        :param include_inactive: When False, deactivated USs are excluded
        :type include_inactive: bool
        :param status_filter: Filter by validation status
        :type status_filter: StatusFilter
        :returns: Filtered list of user stories (in insertion order)
        :rtype: list[UserStory]
        """
        result = []
        for story in tenka.stories.values():
            if not include_inactive and not story.active:
                continue
            if status_filter != StatusFilter.ALL:
                validated = self._is_story_validated(story, fulfillment)
                if status_filter == StatusFilter.VALIDATED and not validated:
                    continue
                if status_filter == StatusFilter.NOT_VALIDATED and validated:
                    continue
            result.append(story)
        logger.debug(f"Filtered user stories: {len(result)} of {len(tenka.stories)} returned")
        return result

    def filter_acceptance_criteria(
        self,
        tenka: Tenka,
        fulfillment: TenkaFulfillment | None,
        story_ids: list[str] | None = None,
        include_inactive: bool = False,
        status_filter: StatusFilter = StatusFilter.ALL,
    ) -> list[AcceptanceCriterion]:
        """Return a flat, filtered list of acceptance criteria.

        :param tenka: Source tenka
        :type tenka: Tenka
        :param fulfillment: Optional validation data
        :type fulfillment: TenkaFulfillment | None
        :param story_ids: When provided, only ACs from these USs are returned
        :type story_ids: list[str] | None
        :param include_inactive: When False, deactivated ACs (and ACs of inactive USs) are excluded
        :type include_inactive: bool
        :param status_filter: Filter by validation status
        :type status_filter: StatusFilter
        :returns: Flat list of matching acceptance criteria
        :rtype: list[AcceptanceCriterion]
        """
        result = []
        for us_id, story in tenka.stories.items():
            if story_ids is not None and us_id not in story_ids:
                continue
            if not include_inactive and not story.active:
                continue
            for ac in story.acs.values():
                if not include_inactive and not ac.active:
                    continue
                if status_filter != StatusFilter.ALL:
                    ac_fulfillment = fulfillment.get_for_ac(ac.id) if fulfillment else None
                    validated = ac_fulfillment is not None and ac_fulfillment.is_validated
                    if status_filter == StatusFilter.VALIDATED and not validated:
                        continue
                    if status_filter == StatusFilter.NOT_VALIDATED and validated:
                        continue
                result.append(ac)
        logger.debug(f"Filtered acceptance criteria: {len(result)} returned")
        return result

    def filter_validation_status(
        self,
        tenka: Tenka,
        fulfillment: TenkaFulfillment | None,
        ac_refs: list[str] | None = None,
        passing_filter: StatusFilter = StatusFilter.ALL,
        automation_filter: AutomationFilter = AutomationFilter.ALL,
    ) -> list[tuple[str, ACFulfillment | None]]:
        """Return filtered validation status entries for acceptance criteria.

        Only active ACs from active USs are included. Returns a list of
        (ac_ref, fulfillment_or_None) pairs ordered by US/AC insertion order.

        :param tenka: Source tenka (used to enumerate ACs in canonical order)
        :type tenka: Tenka
        :param fulfillment: Optional validation data
        :type fulfillment: TenkaFulfillment | None
        :param ac_refs: When provided, only these ACs are returned
        :type ac_refs: list[str] | None
        :param passing_filter: Filter by whether the AC is validated
        :type passing_filter: StatusFilter
        :param automation_filter: Filter by automation coverage of validation entries
        :type automation_filter: AutomationFilter
        :returns: List of (ac_ref, ACFulfillment | None) tuples
        :rtype: list[tuple[str, ACFulfillment | None]]
        """
        result: list[tuple[str, ACFulfillment | None]] = []
        for story in tenka.stories.values():
            if not story.active:
                continue
            for ac in story.acs.values():
                if not ac.active:
                    continue
                if ac_refs is not None and ac.id not in ac_refs:
                    continue

                ac_fulfillment = fulfillment.get_for_ac(ac.id) if fulfillment else None

                if passing_filter != StatusFilter.ALL:
                    validated = ac_fulfillment is not None and ac_fulfillment.is_validated
                    if passing_filter == StatusFilter.VALIDATED and not validated:
                        continue
                    if passing_filter == StatusFilter.NOT_VALIDATED and validated:
                        continue

                if automation_filter != AutomationFilter.ALL:
                    if ac_fulfillment is None or not ac_fulfillment.validations:
                        continue
                    if automation_filter == AutomationFilter.AUTOMATED and ac_fulfillment.has_manual:
                        continue
                    if automation_filter == AutomationFilter.HAS_MANUAL and not ac_fulfillment.has_manual:
                        continue

                result.append((ac.id, ac_fulfillment))

        logger.debug(f"Filtered validation status: {len(result)} entries returned")
        return result

    @staticmethod
    def _is_story_validated(
        story: UserStory, fulfillment: TenkaFulfillment | None
    ) -> bool:
        """Return True iff all active ACs of the story are validated.

        A story with no active ACs is considered NOT validated.

        :param story: The user story to check
        :type story: UserStory
        :param fulfillment: Optional validation data
        :type fulfillment: TenkaFulfillment | None
        :rtype: bool
        """
        active_acs = [ac for ac in story.acs.values() if ac.active]
        if not active_acs:
            return False
        if fulfillment is None:
            return False
        return all(
            (f := fulfillment.get_for_ac(ac.id)) is not None and f.is_validated
            for ac in active_acs
        )


__all__ = [
    "AutomationFilter",
    "StatusFilter",
    "TenkaFilteringService",
    "VALID_AUTOMATION_VALUES",
    "VALID_STATUS_VALUES",
]
