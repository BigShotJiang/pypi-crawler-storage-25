"""Markdown formatters for tenka user stories, acceptance criteria, and validation status."""

from __future__ import annotations

from daimyo.domain import (
    ACFulfillment,
    AcceptanceCriterion,
    AutoValidation,
    ManualValidation,
    UserStory,
)
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)


class TenkaUSMarkdownFormatter:
    """Format user stories as a markdown list.

    Output uses configurable prologue/epilogue from dynaconf settings.
    """

    def __init__(self) -> None:
        """Initialize formatter, loading settings lazily."""
        from daimyo.config import settings

        self.settings = settings

    def format(self, scope_name: str, stories: list[UserStory]) -> str:
        """Format a list of user stories as markdown.

        :param scope_name: The scope name (used for fully-qualified ids)
        :type scope_name: str
        :param stories: User stories to format
        :type stories: list[UserStory]
        :returns: Markdown-formatted string
        :rtype: str
        """
        lines = []

        prologue = self.settings.get("TENKA_US_LISTING_MARKDOWN_PROLOGUE", "").strip()
        if prologue:
            lines.append(prologue)
            lines.append("")

        lines.append(f"# User Stories for {scope_name}\n")

        if not stories:
            lines.append("No user stories found.")
        else:
            for story in stories:
                fq_id = f"{scope_name}:{story.id}"
                lines.append(f'- "{fq_id}": "{story.as_text()}"')

        epilogue = self.settings.get("TENKA_US_LISTING_MARKDOWN_EPILOGUE", "").strip()
        if epilogue:
            lines.append("")
            lines.append(epilogue)

        return "\n".join(lines)


class TenkaACMarkdownFormatter:
    """Format acceptance criteria as a flat markdown list.

    Output uses configurable prologue/epilogue from dynaconf settings.
    """

    def __init__(self) -> None:
        """Initialize formatter, loading settings lazily."""
        from daimyo.config import settings

        self.settings = settings

    def format(self, scope_name: str, acs: list[AcceptanceCriterion]) -> str:
        """Format a flat list of acceptance criteria as markdown.

        :param scope_name: The scope name (used for fully-qualified ids)
        :type scope_name: str
        :param acs: Acceptance criteria to format
        :type acs: list[AcceptanceCriterion]
        :returns: Markdown-formatted string
        :rtype: str
        """
        lines = []

        prologue = self.settings.get("TENKA_AC_LISTING_MARKDOWN_PROLOGUE", "").strip()
        if prologue:
            lines.append(prologue)
            lines.append("")

        lines.append(f"# Acceptance Criteria for {scope_name}\n")

        if not acs:
            lines.append("No acceptance criteria found.")
        else:
            for ac in acs:
                fq_id = f"{scope_name}:{ac.id}"
                lines.append(f'- "{fq_id}": {ac.as_text()}')

        epilogue = self.settings.get("TENKA_AC_LISTING_MARKDOWN_EPILOGUE", "").strip()
        if epilogue:
            lines.append("")
            lines.append(epilogue)

        return "\n".join(lines)


class TenkaValidationMarkdownFormatter:
    """Format validation status as a markdown list.

    Output uses configurable prologue/epilogue from dynaconf settings.
    """

    def __init__(self) -> None:
        """Initialize formatter, loading settings lazily."""
        from daimyo.config import settings

        self.settings = settings

    def format(
        self,
        scope_name: str,
        validation_results: list[tuple[str, ACFulfillment | None]],
    ) -> str:
        """Format validation status entries as markdown.

        :param scope_name: The scope name (used for fully-qualified ids)
        :type scope_name: str
        :param validation_results: List of (ac_ref, fulfillment_or_None) pairs
        :type validation_results: list[tuple[str, ACFulfillment | None]]
        :returns: Markdown-formatted string
        :rtype: str
        """
        lines = []

        prologue = self.settings.get("TENKA_VALIDATION_MARKDOWN_PROLOGUE", "").strip()
        if prologue:
            lines.append(prologue)
            lines.append("")

        lines.append(f"# Validation Status for {scope_name}\n")

        if not validation_results:
            lines.append("No acceptance criteria found.")
        else:
            for ac_ref, ac_fulfillment in validation_results:
                fq_id = f"{scope_name}:{ac_ref}"
                if ac_fulfillment is not None and ac_fulfillment.is_validated:
                    lines.append(f'- "{fq_id}": VALIDATED')
                else:
                    lines.append(f'- "{fq_id}": NOT VALIDATED')
                    if ac_fulfillment and ac_fulfillment.failed_validations:
                        lines.append("  - Failed tests:")
                        for v in ac_fulfillment.failed_validations:
                            lines.append(f"    - {_format_validation_entry(v)}")

        epilogue = self.settings.get("TENKA_VALIDATION_MARKDOWN_EPILOGUE", "").strip()
        if epilogue:
            lines.append("")
            lines.append(epilogue)

        return "\n".join(lines)


def _format_validation_entry(v: AutoValidation | ManualValidation) -> str:
    """Format a single failed validation entry as a markdown list item fragment.

    :param v: Validation entry
    :type v: AutoValidation | ManualValidation
    :returns: Formatted string (without leading "- ")
    :rtype: str
    """
    if isinstance(v, AutoValidation):
        ref = f"`{v.source}:{v.name}`"
        if v.message:
            return f"(auto) {ref}: {v.message}"
        return f"(auto) {ref}"
    verdict = v.verdict
    return f"(manual): {verdict}"


__all__ = [
    "TenkaUSMarkdownFormatter",
    "TenkaACMarkdownFormatter",
    "TenkaValidationMarkdownFormatter",
]
