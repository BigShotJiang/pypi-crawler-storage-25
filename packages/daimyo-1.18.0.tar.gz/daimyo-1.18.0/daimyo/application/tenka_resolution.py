"""Tenka resolution service — walks the scope parent chain and merges tenka."""

from __future__ import annotations

from daimyo.application.tenka_service import TenkaMergingService
from daimyo.config import settings
from daimyo.domain import (
    CircularDependencyError,
    InheritanceDepthExceededError,
    ScopeNotFoundError,
    ScopeRepository,
    Tenka,
    TenkaFulfillment,
    TenkaRepository,
)
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)


class TenkaResolutionService:
    """Service for resolving tenka with full scope inheritance.

    Mirrors the parent-chain traversal logic of ScopeResolutionService but is
    restricted to local scopes (tenka is not federated over remote servers).

    Resolution algorithm:
    1. Load the scope's parent chain from the ScopeRepository (metadata only)
    2. Recursively resolve tenka from ancestor to descendant
    3. Merge using TenkaMergingService (selective AC override)
    4. Load fulfillment ONLY for the directly requested scope (not inherited)
    """

    def __init__(
        self,
        scope_repository: ScopeRepository,
        tenka_repository: TenkaRepository,
        max_depth: int | None = None,
    ):
        """Initialize the service.

        :param scope_repository: Repository used to read scope metadata (parent chain)
        :type scope_repository: ScopeRepository
        :param tenka_repository: Repository used to read tenka.yml files
        :type tenka_repository: TenkaRepository
        :param max_depth: Maximum inheritance depth (defaults to config setting)
        :type max_depth: int | None
        """
        self.scope_repository = scope_repository
        self.tenka_repository = tenka_repository
        self.max_depth = max_depth if max_depth is not None else settings.MAX_INHERITANCE_DEPTH
        self._merging_service = TenkaMergingService()

    def resolve_tenka(
        self, scope_name: str
    ) -> tuple[Tenka, TenkaFulfillment | None]:
        """Resolve the merged tenka and local fulfillment for a scope.

        :param scope_name: Scope to resolve
        :type scope_name: str
        :returns: Tuple of (merged Tenka, fulfillment or None)
        :rtype: tuple[Tenka, TenkaFulfillment | None]
        :raises ScopeNotFoundError: If the scope does not exist
        :raises CircularDependencyError: If circular parent reference detected
        :raises InheritanceDepthExceededError: If max inheritance depth exceeded
        """
        logger.info(f"Resolving tenka for scope: {scope_name}")
        if self.scope_repository.get_scope(scope_name) is None:
            raise ScopeNotFoundError(scope_name)
        visited: set[str] = set()
        tenka = self._resolve_recursive(scope_name, visited, depth=0)
        fulfillment = self.tenka_repository.get_tenka_fulfillment(scope_name)
        return tenka, fulfillment

    def _resolve_recursive(
        self, scope_name: str, visited: set[str], depth: int
    ) -> Tenka:
        """Recursively resolve and merge tenka from the inheritance chain.

        :param scope_name: Scope to resolve
        :type scope_name: str
        :param visited: Set of already-visited scope names (cycle detection)
        :type visited: set[str]
        :param depth: Current recursion depth
        :type depth: int
        :returns: Merged Tenka for this scope and all its ancestors
        :rtype: Tenka
        """
        if depth > self.max_depth:
            raise InheritanceDepthExceededError(
                f"Maximum inheritance depth ({self.max_depth}) exceeded at scope '{scope_name}'"
            )

        if scope_name in visited:
            raise CircularDependencyError(
                f"Circular parent dependency detected for scope '{scope_name}'"
            )

        visited = visited | {scope_name}

        scope = self.scope_repository.get_scope(scope_name)
        if scope is None:
            logger.warning(
                f"Scope '{scope_name}' not found while resolving tenka inheritance; "
                "treating as empty tenka"
            )
            return Tenka()

        local_tenka = self.tenka_repository.get_tenka(scope_name) or Tenka()

        parent_list = scope.metadata.get_parent_list()
        if not parent_list:
            return local_tenka

        merged_parent = self._merge_parents(parent_list, visited, depth)
        return self._merging_service.merge(merged_parent, local_tenka)

    def _merge_parents(
        self, parent_list: list[str], visited: set[str], depth: int
    ) -> Tenka:
        """Resolve and merge multiple parent scopes left-to-right.

        :param parent_list: Ordered list of parent scope names
        :type parent_list: list[str]
        :param visited: Already-visited scope names
        :type visited: set[str]
        :param depth: Current recursion depth
        :type depth: int
        :returns: Merged parent Tenka
        :rtype: Tenka
        """
        result = Tenka()
        for parent_name in parent_list:
            parent_tenka = self._resolve_recursive(parent_name, visited, depth + 1)
            result = self._merging_service.merge(result, parent_tenka)
        return result


__all__ = ["TenkaResolutionService"]
