"""Tenka merging service for combining user stories across scope inheritance."""

from __future__ import annotations

from daimyo.domain import AcceptanceCriterion, Tenka, UserStory
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)


class TenkaMergingService:
    """Service for merging Tenka instances according to selective AC override semantics.

    Merge rules:
    - USs only in parent: inherited verbatim
    - USs only in child: added as-is
    - USs in both: child fields (who/what/why/active) replace parent;
      ACs are merged selectively — child ACs override parent ACs by the same id,
      parent ACs not redefined in the child are retained
    """

    def merge(self, parent: Tenka, child: Tenka) -> Tenka:
        """Merge parent and child Tenka instances.

        :param parent: Ancestor scope's tenka
        :type parent: Tenka
        :param child: Descendant scope's tenka
        :type child: Tenka
        :returns: Merged Tenka
        :rtype: Tenka
        """
        result = Tenka()

        for us_id, story in parent.stories.items():
            result.stories[us_id] = self._copy_story(story)

        for us_id, child_story in child.stories.items():
            if us_id in result.stories:
                result.stories[us_id] = self._merge_story(result.stories[us_id], child_story)
                logger.debug(f"Merged user story '{us_id}' from parent and child")
            else:
                result.stories[us_id] = self._copy_story(child_story)
                logger.debug(f"Added new user story '{us_id}' from child")

        logger.debug(f"Merged tenka: {len(result.stories)} user stories total")
        return result

    @staticmethod
    def _copy_story(story: UserStory) -> UserStory:
        """Create a shallow copy of a user story (ACs are immutable frozen dataclasses).

        :param story: Source story
        :type story: UserStory
        :returns: Copied UserStory
        :rtype: UserStory
        """
        return UserStory(
            id=story.id,
            who=story.who,
            what=story.what,
            why=story.why,
            active=story.active,
            acs=dict(story.acs),
        )

    @staticmethod
    def _merge_story(parent_story: UserStory, child_story: UserStory) -> UserStory:
        """Merge a parent story with a child override using selective AC override.

        :param parent_story: Story from the parent scope
        :type parent_story: UserStory
        :param child_story: Story from the child scope
        :type child_story: UserStory
        :returns: Merged UserStory
        :rtype: UserStory
        """
        merged_acs: dict[str, AcceptanceCriterion] = dict(parent_story.acs)
        for ac_id, child_ac in child_story.acs.items():
            merged_acs[ac_id] = child_ac
            if ac_id in parent_story.acs:
                logger.debug(f"  Overrode AC '{ac_id}' from parent with child definition")
            else:
                logger.debug(f"  Added new AC '{ac_id}' from child")

        return UserStory(
            id=child_story.id,
            who=child_story.who,
            what=child_story.what,
            why=child_story.why,
            active=child_story.active,
            acs=merged_acs,
        )


__all__ = ["TenkaMergingService"]
