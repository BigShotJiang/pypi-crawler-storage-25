"""Domain models for Daimyo rules server."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

_TEMPLATE_TEXT_TRUNCATION_LENGTH = 400


class RuleType(Enum):
    """Type of rule - mandatory or suggested."""

    COMMANDMENT = "commandment"
    SUGGESTION = "suggestion"


@dataclass(frozen=True)
class Rule:
    """Individual rule statement.

    :param text: The rule text
    :type text: str
    :param rule_type: Whether this is a commandment (MUST) or suggestion (SHOULD)
    :type rule_type: RuleType
    """

    text: str
    rule_type: RuleType

    def __str__(self) -> str:
        """Format rule with MUST/SHOULD prefix.

        :returns: Formatted rule string with prefix
        :rtype: str
        """
        prefix = "MUST" if self.rule_type == RuleType.COMMANDMENT else "SHOULD"
        return f"{prefix}: {self.text}"


@dataclass(frozen=True)
class TemplateFailure:
    """Information about a template rendering failure.

    :param element_type: Type of element that failed
    :type element_type: str
    :param element_identifier: Human-readable identifier
    :type element_identifier: str
    :param template_text: Original template text (truncated)
    :type template_text: str
    :param error_message: Error message from template engine
    :type error_message: str
    :param variable_name: Undefined variable name if applicable
    :type variable_name: str | None
    """

    element_type: str
    element_identifier: str
    template_text: str
    error_message: str
    variable_name: str | None = None


@dataclass(frozen=True)
class CategoryKey:
    """Represents a category path like 'python.web.testing'.

    Categories form a universal namespace shared across all scopes. Multiple scopes
    can contain rules for the same category, and these rules are merged during
    scope resolution. Categories are hierarchical and used for filtering rules.

    Immutable to allow use as dictionary keys.

    :param parts: Tuple of category path parts
    :type parts: tuple[str, ...]
    """

    parts: tuple[str, ...]

    @classmethod
    def from_string(cls, category: str) -> CategoryKey:
        """Create CategoryKey from dot-separated string.

        :param category: Category path like "python.web.testing"
        :type category: str
        :returns: CategoryKey instance
        :rtype: CategoryKey
        """
        cleaned = category.lstrip("+")
        return cls(parts=tuple(cleaned.split(".")))

    def __str__(self) -> str:
        """Convert back to dot-separated string.

        :returns: Dot-separated category string
        :rtype: str
        """
        return ".".join(self.parts)

    def matches_prefix(self, prefix: CategoryKey) -> bool:
        """Check if this category starts with the given prefix.

        :param prefix: The prefix to check
        :type prefix: CategoryKey
        :returns: True if this category starts with the prefix
        :rtype: bool
        """
        if len(prefix.parts) > len(self.parts):
            return False
        return self.parts[: len(prefix.parts)] == prefix.parts

    def depth(self) -> int:
        """Return the depth of this category.

        :returns: Number of parts in the category path
        :rtype: int
        """
        return len(self.parts)


@dataclass
class Category:
    """A category of rules with applicability description and ruleset.

    :param key: The category key (e.g., python.web.testing)
    :type key: CategoryKey
    :param when: Description of when these rules apply
    :type when: str | None
    :param rules: List of rules for this category
    :type rules: List[Rule]
    :param tags: List of tags for this category
    :type tags: List[str]
    :param append_to_parent: Whether to append to parent category (for suggestions)
    :type append_to_parent: bool
    """

    key: CategoryKey
    when: str | None = None
    rules: list[Rule] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    append_to_parent: bool = False

    def add_rule(self, rule: Rule) -> None:
        """Add a rule to this category.

        :param rule: Rule to add
        :type rule: Rule
        :rtype: None
        """
        self.rules.append(rule)

    def copy(self) -> Category:
        """Create a deep copy of this category.

        :returns: Copied category with new list instance
        :rtype: Category
        """
        return Category(
            key=self.key,
            when=self.when,
            rules=self.rules.copy(),
            tags=self.tags.copy(),
            append_to_parent=self.append_to_parent,
        )


@dataclass
class RuleSet:
    """Collection of rules organized by category.

    Used to represent either commandments or suggestions for a scope.

    :param categories: Dictionary mapping category keys to categories
    :type categories: Dict[CategoryKey, Category]
    """

    categories: dict[CategoryKey, Category] = field(default_factory=dict)

    def add_category(self, category: Category) -> None:
        """Add or update a category.

        :param category: Category to add
        :type category: Category
        :rtype: None
        """
        self.categories[category.key] = category

    def get_category(self, key: CategoryKey) -> Category | None:
        """Get a category by key.

        :param key: Category key to retrieve
        :type key: CategoryKey
        :returns: Category if found, None otherwise
        :rtype: Category | None
        """
        return self.categories.get(key)

    def get_matching_categories(self, prefix: str | None = None) -> list[Category]:
        """Get all categories matching the prefix.

        :param prefix: Optional prefix to filter by (e.g., "python.web").
                       If None, returns all categories
        :type prefix: Optional[str]
        :returns: List of matching categories
        :rtype: List[Category]
        """
        if prefix is None:
            return list(self.categories.values())

        prefix_key = CategoryKey.from_string(prefix)
        return [
            cat
            for cat in self.categories.values()
            if cat.key.matches_prefix(prefix_key) or cat.key == prefix_key
        ]

    def copy(self) -> RuleSet:
        """Create a deep copy of this ruleset.

        :returns: Copied ruleset with new category instances
        :rtype: RuleSet
        """
        new_ruleset = RuleSet()
        for cat in self.categories.values():
            new_ruleset.add_category(cat.copy())
        return new_ruleset


@dataclass
class ScopeMetadata:
    """Metadata for a scope.

    :param name: Scope name (e.g., "team-backend", "project-xyz")
    :type name: str
    :param description: Human-readable description
    :type description: str
    :param parent: Optional parent scope for inheritance (deprecated, use parents)
    :type parent: Optional[str]
    :param parents: Optional list of parent scopes for multiple inheritance
    :type parents: Optional[list[str]]
    :param tags: Optional tags for categorization
    :type tags: Dict[str, str]
    """

    name: str
    description: str
    parent: str | None = None
    parents: list[str] | None = None
    tags: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        from daimyo.domain.exceptions import InvalidScopeError

        if self.parent is not None and self.parents is not None:
            raise InvalidScopeError(
                "Cannot specify both 'parent' and 'parents'. "
                "Use 'parents' for single or multiple parents."
            )

    def get_parent_list(self) -> list[str]:
        if self.parents is not None:
            return self.parents if self.parents else []
        if self.parent is not None:
            return [self.parent]
        return []


@dataclass(frozen=True)
class Kata:
    """Individual kata procedure.

    :param name: The name of the kata
    :type name: str
    :param procedure: The procedure text (Jinja2 template)
    :type procedure: str
    """

    name: str
    procedure: str


@dataclass
class KataCategory:
    """A category of katas.

    :param key: The category key
    :type key: CategoryKey
    :param when: Description of when these katas apply
    :type when: str | None
    :param katas: Dictionary of katas by name
    :type katas: dict[str, Kata]
    """

    key: CategoryKey
    when: str | None = None
    katas: dict[str, Kata] = field(default_factory=dict)

    def add_kata(self, kata: Kata) -> None:
        """Add a kata to this category.

        :param kata: Kata to add
        :type kata: Kata
        """
        self.katas[kata.name] = kata

    def copy(self) -> KataCategory:
        """Create a deep copy of this category.

        :returns: Copied category
        :rtype: KataCategory
        """
        return KataCategory(
            key=self.key,
            when=self.when,
            katas=self.katas.copy(),
        )


@dataclass
class KataSet:
    """Collection of katas organized by category.

    :param categories: Dictionary mapping category keys to kata categories
    :type categories: dict[CategoryKey, KataCategory]
    """

    categories: dict[CategoryKey, KataCategory] = field(default_factory=dict)

    def add_category(self, category: KataCategory) -> None:
        """Add or update a category.

        :param category: Category to add
        :type category: KataCategory
        """
        self.categories[category.key] = category

    def get_category(self, key: CategoryKey) -> KataCategory | None:
        """Get a category by key.

        :param key: Category key to retrieve
        :type key: CategoryKey
        :returns: KataCategory if found, None otherwise
        :rtype: KataCategory | None
        """
        return self.categories.get(key)

    def copy(self) -> KataSet:
        """Create a deep copy of this kataset.

        :returns: Copied kataset
        :rtype: KataSet
        """
        new_kataset = KataSet()
        for cat in self.categories.values():
            new_kataset.add_category(cat.copy())
        return new_kataset


@dataclass
class Scope:
    """A scope with metadata, rules, and katas.

    Scopes represent organizational contexts (company, team, project).
    Each scope has commandments (mandatory rules) and suggestions (recommended rules).

    :param metadata: Scope metadata
    :type metadata: ScopeMetadata
    :param commandments: Mandatory rules organized by category
    :type commandments: RuleSet
    :param suggestions: Recommended rules organized by category
    :type suggestions: RuleSet
    :param katas: Katas organized by category
    :type katas: KataSet
    :param source: Source identifier (e.g., "local" or remote URL)
    :type source: str
    """

    metadata: ScopeMetadata
    commandments: RuleSet = field(default_factory=RuleSet)
    suggestions: RuleSet = field(default_factory=RuleSet)
    katas: KataSet = field(default_factory=KataSet)
    source: str = "local"

    def get_all_category_keys(self) -> set[CategoryKey]:
        """Get all unique category keys from commandments, suggestions, and katas.

        :returns: Set of all category keys
        :rtype: set[CategoryKey]
        """
        return (
            set(self.commandments.categories.keys())
            | set(self.suggestions.categories.keys())
            | set(self.katas.categories.keys())
        )


@dataclass
class MergedScope:
    """A scope after merging with parent and remote shards.

    This represents the final, resolved scope after applying inheritance
    and merging rules from multiple sources.

    :param metadata: Scope metadata (from child scope)
    :type metadata: ScopeMetadata
    :param commandments: Merged commandments
    :type commandments: RuleSet
    :param suggestions: Merged suggestions
    :type suggestions: RuleSet
    :param katas: Merged katas
    :type katas: KataSet
    :param sources: List of sources that contributed to this merged scope
    :type sources: List[str]
    :param template_failures: List of template rendering failures
    :type template_failures: List[TemplateFailure]
    """

    metadata: ScopeMetadata
    commandments: RuleSet
    suggestions: RuleSet
    katas: KataSet = field(default_factory=KataSet)
    sources: list[str] = field(default_factory=list)
    template_failures: list[TemplateFailure] = field(default_factory=list)

    def add_template_failure(
        self,
        element_type: str,
        element_identifier: str,
        template_text: str,
        error: Exception,
        variable_name: str | None = None,
    ) -> None:
        """Record a template rendering failure.

        :param element_type: Type of element that failed
        :type element_type: str
        :param element_identifier: Human-readable identifier
        :type element_identifier: str
        :param template_text: Original template text
        :type template_text: str
        :param error: The exception that was raised
        :type error: Exception
        :param variable_name: Undefined variable name if applicable
        :type variable_name: str | None
        :rtype: None
        """
        failure = TemplateFailure(
            element_type=element_type,
            element_identifier=element_identifier,
            template_text=template_text[:_TEMPLATE_TEXT_TRUNCATION_LENGTH],
            error_message=str(error),
            variable_name=variable_name,
        )
        self.template_failures.append(failure)

    @classmethod
    def from_scope(cls, scope: Scope) -> MergedScope:
        """Create a MergedScope from a single Scope.

        :param scope: The source scope
        :type scope: Scope
        :returns: MergedScope with the scope's data
        :rtype: MergedScope
        """
        return cls(
            metadata=scope.metadata,
            commandments=scope.commandments.copy(),
            suggestions=scope.suggestions.copy(),
            katas=scope.katas.copy(),
            sources=[scope.source],
        )

    def copy(self) -> MergedScope:
        """Create a deep copy of this merged scope.

        :returns: Copied merged scope with new ruleset instances
        :rtype: MergedScope
        """
        return MergedScope(
            metadata=self.metadata,
            commandments=self.commandments.copy(),
            suggestions=self.suggestions.copy(),
            katas=self.katas.copy(),
            sources=self.sources.copy(),
            template_failures=self.template_failures.copy(),
        )


@dataclass(frozen=True)
class AcceptanceCriterion:
    """An acceptance criterion for a user story.

    :param id: Reference identifier (e.g., "AC123.1")
    :type id: str
    :param then: The expected outcome (required)
    :type then: str
    :param given: Optional precondition
    :type given: str | None
    :param when_clause: Optional action/event that triggers the outcome
    :type when_clause: str | None
    :param active: Whether this AC is active (default True)
    :type active: bool
    """

    id: str
    then: str
    given: str | None = None
    when_clause: str | None = None
    active: bool = True

    def as_text(self) -> str:
        """Format the acceptance criterion as a readable sentence.

        :returns: Formatted Given/When/Then sentence
        :rtype: str
        """
        parts = []
        if self.given:
            parts.append(f"Given {self.given}")
        if self.when_clause:
            parts.append(f"when {self.when_clause}")
        parts.append(f"then {self.then}")
        return ", ".join(parts) + "."


@dataclass
class UserStory:
    """A user story with acceptance criteria.

    :param id: Story identifier (e.g., "US123")
    :type id: str
    :param who: The role or persona
    :type who: str
    :param what: The desired capability
    :type what: str
    :param why: The reason or value
    :type why: str
    :param active: Whether this story is active (default True)
    :type active: bool
    :param acs: Acceptance criteria keyed by AC id
    :type acs: dict[str, AcceptanceCriterion]
    """

    id: str
    who: str
    what: str
    why: str
    active: bool = True
    acs: dict[str, AcceptanceCriterion] = field(default_factory=dict)

    def as_text(self) -> str:
        """Format the story as a readable sentence.

        :returns: "As a(n) <who>, I want <what>, so that <why>"
        :rtype: str
        """
        return f"As a(n) {self.who}, I want {self.what}, so that {self.why}"


@dataclass
class Tenka:
    """Collection of user stories for a scope (the scope's vision).

    :param stories: User stories keyed by story id
    :type stories: dict[str, UserStory]
    """

    stories: dict[str, UserStory] = field(default_factory=dict)


class ValidationType(Enum):
    """Type of validation — automated test or manual verification."""

    AUTO = "auto"
    MANUAL = "manual"


@dataclass(frozen=True)
class AutoValidation:
    """An automated validation entry (e.g., a test case result).

    :param source: Test file path
    :type source: str
    :param name: Test function name
    :type name: str
    :param passed: Whether the validation passed
    :type passed: bool
    :param timestamp: When the validation was recorded
    :type timestamp: datetime
    :param message: Optional failure explanation
    :type message: str | None
    """

    source: str
    name: str
    passed: bool
    timestamp: datetime
    message: str | None = None


@dataclass(frozen=True)
class ManualValidation:
    """A manual validation entry (e.g., a human review result).

    :param verdict: Human-readable description of what was verified
    :type verdict: str
    :param passed: Whether the validation passed
    :type passed: bool
    :param timestamp: When the validation was recorded
    :type timestamp: datetime
    """

    verdict: str
    passed: bool
    timestamp: datetime


@dataclass
class ACFulfillment:
    """Validation data for a single acceptance criterion.

    :param ac_ref: Reference id of the AC (e.g., "AC123.1")
    :type ac_ref: str
    :param validations: List of validation entries
    :type validations: list[AutoValidation | ManualValidation]
    """

    ac_ref: str
    validations: list[AutoValidation | ManualValidation] = field(default_factory=list)

    @property
    def is_validated(self) -> bool:
        """Return True iff all entries exist and every one has passed=True.

        :rtype: bool
        """
        return bool(self.validations) and all(v.passed for v in self.validations)

    @property
    def failed_validations(self) -> list[AutoValidation | ManualValidation]:
        """Return all entries where passed is False.

        :rtype: list[AutoValidation | ManualValidation]
        """
        return [v for v in self.validations if not v.passed]

    @property
    def has_auto(self) -> bool:
        """Return True if at least one entry is an AutoValidation.

        :rtype: bool
        """
        return any(isinstance(v, AutoValidation) for v in self.validations)

    @property
    def has_manual(self) -> bool:
        """Return True if at least one entry is a ManualValidation.

        :rtype: bool
        """
        return any(isinstance(v, ManualValidation) for v in self.validations)


@dataclass
class TenkaFulfillment:
    """Validation data for all acceptance criteria in a scope.

    Local-only: never inherited across scope boundaries.

    :param fulfillments: ACFulfillment entries keyed by AC reference id
    :type fulfillments: dict[str, ACFulfillment]
    """

    fulfillments: dict[str, ACFulfillment] = field(default_factory=dict)

    def get_for_ac(self, ac_ref: str) -> ACFulfillment | None:
        """Get fulfillment data for a specific AC.

        :param ac_ref: The AC reference id
        :type ac_ref: str
        :returns: ACFulfillment if found, None otherwise
        :rtype: ACFulfillment | None
        """
        return self.fulfillments.get(ac_ref)


__all__ = [
    "Rule",
    "RuleType",
    "TemplateFailure",
    "Category",
    "CategoryKey",
    "RuleSet",
    "Kata",
    "KataCategory",
    "KataSet",
    "Scope",
    "ScopeMetadata",
    "MergedScope",
    "AcceptanceCriterion",
    "UserStory",
    "Tenka",
    "ValidationType",
    "AutoValidation",
    "ManualValidation",
    "ACFulfillment",
    "TenkaFulfillment",
]
