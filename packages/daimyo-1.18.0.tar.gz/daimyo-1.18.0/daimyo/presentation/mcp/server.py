"""FastMCP server for Daimyo rules."""

import json

from fastmcp import FastMCP

from daimyo.application.error_handling import ErrorMapper
from daimyo.application.formatters import (
    IndexMarkdownFormatter,
    KataIndexMarkdownFormatter,
    KataListMarkdownFormatter,
    KataMarkdownFormatter,
    MarkdownFormatter,
    TenkaACMarkdownFormatter,
    TenkaUSMarkdownFormatter,
    TenkaValidationMarkdownFormatter,
)
from daimyo.application.tenka_filtering import (
    AutomationFilter,
    StatusFilter,
    VALID_AUTOMATION_VALUES,
    VALID_STATUS_VALUES,
)
from daimyo.application.validation import (
    ValidationError,
    sanitize_for_logging,
    validate_categories,
    validate_scope_name,
)
from daimyo.config.settings import settings
from daimyo.domain import CategoryKey
from daimyo.infrastructure.di import get_container
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)

_container = get_container()
_scope_service = _container.scope_service()
_filter_service = _container.category_filter_service()
_scope_repository = _container.scope_repository()
_template_renderer = _container.template_renderer()
_feedback_service = _container.feedback_service()
_tenka_resolution_service = _container.tenka_resolution_service()
_tenka_filter_service = _container.tenka_filter_service()

mcp = FastMCP("Daimyo Rules Server")


@mcp.tool()
def get_rules(scope_name: str | None = None, categories: str | None = None) -> str:
    """Get rules for a scope in markdown format.

    The rules of a given category include also the rules of all its subcategories.\f

    :param scope_name: Name of the scope to retrieve (e.g., 'python-general', 'team-backend').
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :param categories: Optional comma-separated category filters (e.g., 'python.web,python.testing')
    :type categories: str | None
    :returns: Markdown-formatted rules with hierarchy, MUST/SHOULD markers, and descriptions
    :rtype: str

    Examples::

        get_rules("python-general")
        get_rules("team-backend", "python.web")
        get_rules()  # Uses default scope if configured
    """
    try:
        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
            validate_categories(categories)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_rules: scope={sanitize_for_logging(scope_name)}, "
            f"categories={sanitize_for_logging(categories, max_length=500, is_comma_list=True)}, "
            f"used_default={used_default}"
        )

        merged_scope = _scope_service.resolve_scope(scope_name)
        merged_scope = _filter_service.filter_from_string(merged_scope, categories)

        formatter = MarkdownFormatter(template_renderer=_template_renderer)
        result = formatter.format(merged_scope)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(f"Successfully retrieved rules for scope '{sanitize_for_logging(scope_name)}'")
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


@mcp.tool()
def get_category_index(scope_name: str | None = None) -> str:
    """Get a hierarchical index of all available categories in a scope.

    Returns a list of all categories with their descriptions to help determine
    which categories are relevant before requesting specific rules.\f

    :param scope_name: Name of the scope to retrieve categories from.
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :returns: Markdown-formatted hierarchical list of categories with descriptions
    :rtype: str

    Examples::

        get_category_index("python-general")
        get_category_index("team-backend")
        get_category_index()  # Uses default scope if configured
    """
    try:
        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_category_index: scope={sanitize_for_logging(scope_name)}, "
            f"used_default={used_default}"
        )

        merged_scope = _scope_service.resolve_scope(scope_name)

        formatter = IndexMarkdownFormatter(template_renderer=_template_renderer)
        result = formatter.format(merged_scope)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(
            f"Successfully retrieved category index for scope '{sanitize_for_logging(scope_name)}'"
        )
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


@mcp.tool()
def get_kata_category_index(scope_name: str | None = None) -> str:
    """Get a hierarchical index of all categories that contain katas in a scope.

    Returns a list of all categories containing katas with their descriptions.\f

    :param scope_name: Name of the scope to retrieve categories from.
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :returns: Markdown-formatted hierarchical list of kata categories
    :rtype: str

    Examples::

        get_kata_category_index("python-general")
        get_kata_category_index()  # Uses default scope if configured
    """
    try:
        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_kata_category_index: scope={sanitize_for_logging(scope_name)}, "
            f"used_default={used_default}"
        )

        merged_scope = _scope_service.resolve_scope(scope_name)

        formatter = KataIndexMarkdownFormatter(template_renderer=_template_renderer)
        result = formatter.format(merged_scope)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(
            "Successfully retrieved kata category index"
            f" for scope '{sanitize_for_logging(scope_name)}'"
        )
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


@mcp.tool()
def get_katas(scope_name: str | None = None, categories: str | None = None) -> str:
    """Get available katas for a scope, optionally filtered by categories.

    Returns a list of kata names organized by category.\f

    :param scope_name: Name of the scope to retrieve (e.g., 'python-general').
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :param categories: Optional comma-separated category filters (e.g., 'python.web')
    :type categories: str | None
    :returns: Markdown-formatted list of available katas
    :rtype: str

    Examples::

        get_katas("python-general", "python.web")
        get_katas()  # Uses default scope if configured
    """
    try:
        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
            validate_categories(categories)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_katas: scope={sanitize_for_logging(scope_name)}, "
            f"categories={sanitize_for_logging(categories, max_length=500, is_comma_list=True)}, "
            f"used_default={used_default}"
        )

        merged_scope = _scope_service.resolve_scope(scope_name)
        merged_scope = _filter_service.filter_from_string(merged_scope, categories)

        formatter = KataListMarkdownFormatter(template_renderer=_template_renderer)
        result = formatter.format(merged_scope)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(f"Successfully retrieved katas for scope '{sanitize_for_logging(scope_name)}'")
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


@mcp.tool()
def get_kata(
    kata_name: str,
    scope_name: str | None = None,
    category: str | None = None,
) -> str:
    """Get a specific kata procedure.

    Returns the rendered procedure for the requested kata.\f

    :param kata_name: The name of the kata to retrieve.
    :type kata_name: str
    :param scope_name: Name of the scope to retrieve (e.g., 'python-general').
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :param category: Category key to disambiguate when the same kata name exists in multiple
                     categories (e.g., 'python.testing'). When omitted, the first matching kata
                     is returned.
    :type category: str | None
    :returns: Markdown-formatted kata procedure
    :rtype: str

    Examples::

        get_kata("TDD-cycle", "python-general")
        get_kata("TDD-cycle", "python-general", "python.testing")
        get_kata("open-acquire-implement-validate-finish")
    """
    try:
        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_kata: kata={sanitize_for_logging(kata_name)}, "
            f"scope={sanitize_for_logging(scope_name)}, "
            f"category={sanitize_for_logging(category) if category else None}, "
            f"used_default={used_default}"
        )

        merged_scope = _scope_service.resolve_scope(scope_name)

        kata = None
        if category is not None:
            category_key = CategoryKey.from_string(category)
            if category_key not in merged_scope.katas.categories:
                return f"Error: Category '{category}' not found in scope '{scope_name}'."
            kata = merged_scope.katas.categories[category_key].katas.get(kata_name)
            if not kata:
                return (
                    f"Error: Kata '{kata_name}' not found in category '{category}' "
                    f"in scope '{scope_name}'."
                )
        else:
            for cat in merged_scope.katas.categories.values():
                if kata_name in cat.katas:
                    kata = cat.katas[kata_name]
                    break
            if not kata:
                return f"Error: Kata '{kata_name}' not found in scope '{scope_name}'."

        formatter = KataMarkdownFormatter(template_renderer=_template_renderer)
        result = formatter.format_kata(merged_scope, kata)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(
            f"Successfully retrieved kata '{sanitize_for_logging(kata_name)}' "
            f"for scope '{sanitize_for_logging(scope_name)}'"
        )
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


@mcp.prompt()
def apply_scope_rules(scope_name: str | None = None, categories: str | None = None) -> str:
    """Prompt template to apply scope rules to an agent.\f

    :param scope_name: Name of the scope to apply.
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :param categories: Optional comma-separated category filters
    :type categories: str | None
    :returns: Formatted prompt with rules for the agent to follow
    :rtype: str
    """
    try:
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )

        try:
            validate_scope_name(scope_name)
            validate_categories(categories)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP apply_scope_rules: scope={sanitize_for_logging(scope_name)}, "
            f"categories={sanitize_for_logging(categories, max_length=500, is_comma_list=True)}"
        )
        rules = get_rules(scope_name, categories)

        prompt = f"""You are an AI agent that must follow these rules from the '{scope_name}' scope.

{rules}

Instructions:
1. **MUST rules (Commandments)**: These are mandatory and cannot be violated
2. **SHOULD rules (Suggestions)**: These are strong recommendations you should
   follow unless you have a good reason not to

Apply these rules to all your actions, recommendations, and code generation.
When rules conflict, commandments take precedence over suggestions.
"""
        return prompt

    except Exception as e:
        error_msg = f"Error generating prompt: {str(e)}"
        logger.exception(error_msg)
        return error_msg


@mcp.tool()
def get_user_stories(
    scope_name: str | None = None,
    status: str | None = None,
    include_inactive: bool = False,
) -> str:
    """Get user stories for a scope.

    Returns a markdown list of user stories with their fully-qualified ids.
    Each story is formatted as: As a(n) <who>, I want <what>, so that <why>.\f

    :param scope_name: Name of the scope to retrieve.
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :param status: Filter by validation status: ``validated``, ``not_validated``, or ``all``
                   (default ``all``). A story is "validated" when all its active ACs are validated.
    :type status: str | None
    :param include_inactive: When True, deactivated user stories are included (default False)
    :type include_inactive: bool
    :returns: Markdown-formatted list of user stories
    :rtype: str

    Examples::

        get_user_stories("kencho")
        get_user_stories("kencho", status="not_validated")
        get_user_stories()  # Uses default scope if configured
    """
    try:
        resolved_status = status or "all"
        if resolved_status not in VALID_STATUS_VALUES:
            return f"Error: Invalid status '{resolved_status}'. Must be one of: {', '.join(sorted(VALID_STATUS_VALUES))}"

        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_user_stories: scope={sanitize_for_logging(scope_name)}, "
            f"status={resolved_status}, include_inactive={include_inactive}, "
            f"used_default={used_default}"
        )

        tenka, fulfillment = _tenka_resolution_service.resolve_tenka(scope_name)
        status_filter = StatusFilter(resolved_status)
        stories = _tenka_filter_service.filter_user_stories(
            tenka, fulfillment, include_inactive=include_inactive, status_filter=status_filter
        )

        formatter = TenkaUSMarkdownFormatter()
        result = formatter.format(scope_name, stories)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(
            f"Successfully retrieved user stories for scope '{sanitize_for_logging(scope_name)}'"
        )
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


@mcp.tool()
def get_acceptance_criteria(
    scope_name: str | None = None,
    stories: str | None = None,
    status: str | None = None,
    include_inactive: bool = False,
) -> str:
    """Get acceptance criteria for a scope.

    Returns a flat markdown list of acceptance criteria with their fully-qualified ids.
    Each criterion is formatted as: Given <given>, when <when>, then <then>.\f

    :param scope_name: Name of the scope to retrieve.
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :param stories: Optional comma-separated list of user story ids to filter by
                    (e.g., ``US123,US456``). When omitted, all stories are included.
    :type stories: str | None
    :param status: Filter by validation status: ``validated``, ``not_validated``, or ``all``
                   (default ``all``).
    :type status: str | None
    :param include_inactive: When True, deactivated ACs and USs are included (default False)
    :type include_inactive: bool
    :returns: Markdown-formatted list of acceptance criteria
    :rtype: str

    Examples::

        get_acceptance_criteria("kencho")
        get_acceptance_criteria("kencho", stories="US123,US456")
        get_acceptance_criteria("kencho", status="not_validated")
    """
    try:
        resolved_status = status or "all"
        if resolved_status not in VALID_STATUS_VALUES:
            return f"Error: Invalid status '{resolved_status}'. Must be one of: {', '.join(sorted(VALID_STATUS_VALUES))}"

        story_ids: list[str] | None = None
        if stories:
            story_ids = [s.strip() for s in stories.split(",") if s.strip()]

        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_acceptance_criteria: scope={sanitize_for_logging(scope_name)}, "
            f"stories={sanitize_for_logging(stories, is_comma_list=True)}, "
            f"status={resolved_status}, include_inactive={include_inactive}, "
            f"used_default={used_default}"
        )

        tenka, fulfillment = _tenka_resolution_service.resolve_tenka(scope_name)
        status_filter = StatusFilter(resolved_status)
        acs = _tenka_filter_service.filter_acceptance_criteria(
            tenka,
            fulfillment,
            story_ids=story_ids,
            include_inactive=include_inactive,
            status_filter=status_filter,
        )

        formatter = TenkaACMarkdownFormatter()
        result = formatter.format(scope_name, acs)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(
            f"Successfully retrieved ACs for scope '{sanitize_for_logging(scope_name)}'"
        )
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


@mcp.tool()
def get_validation_status(
    scope_name: str | None = None,
    acs: str | None = None,
    passing: str | None = None,
    automation: str | None = None,
) -> str:
    """Get validation status for acceptance criteria in a scope.

    Returns a markdown list showing which ACs are VALIDATED or NOT VALIDATED,
    including details of failed tests when validation data exists.\f

    :param scope_name: Name of the scope to retrieve.
                       If not provided and a DEFAULT_SCOPE is configured, uses the default scope.
    :type scope_name: str | None
    :param acs: Optional comma-separated list of AC reference ids to filter by
                (e.g., ``AC123.1,AC123.2``). When omitted, all active ACs are included.
    :type acs: str | None
    :param passing: Filter by passing status: ``validated``, ``not_validated``, or ``all``
                    (default ``all``).
    :type passing: str | None
    :param automation: Filter by automation coverage: ``automated`` (all entries are auto),
                       ``has_manual`` (at least one manual entry), or ``all`` (default ``all``).
    :type automation: str | None
    :returns: Markdown-formatted validation status report
    :rtype: str

    Examples::

        get_validation_status("kencho")
        get_validation_status("kencho", acs="AC123.1,AC123.2")
        get_validation_status("kencho", passing="not_validated")
        get_validation_status("kencho", automation="has_manual")
    """
    try:
        resolved_passing = passing or "all"
        if resolved_passing not in VALID_STATUS_VALUES:
            return f"Error: Invalid passing filter '{resolved_passing}'. Must be one of: {', '.join(sorted(VALID_STATUS_VALUES))}"

        resolved_automation = automation or "all"
        if resolved_automation not in VALID_AUTOMATION_VALUES:
            return f"Error: Invalid automation filter '{resolved_automation}'. Must be one of: {', '.join(sorted(VALID_AUTOMATION_VALUES))}"

        ac_refs: list[str] | None = None
        if acs:
            ac_refs = [a.strip() for a in acs.split(",") if a.strip()]

        used_default = False
        if scope_name is None:
            scope_name = settings.DEFAULT_SCOPE
            if not scope_name:
                return (
                    "Error: No scope name provided and no default scope configured. "
                    "Please provide a scope_name parameter or configure DEFAULT_SCOPE."
                )
            used_default = True

        try:
            validate_scope_name(scope_name)
        except ValidationError as e:
            return f"Error: {e}"

        logger.info(
            f"MCP get_validation_status: scope={sanitize_for_logging(scope_name)}, "
            f"acs={sanitize_for_logging(acs, is_comma_list=True)}, "
            f"passing={resolved_passing}, automation={resolved_automation}, "
            f"used_default={used_default}"
        )

        tenka, fulfillment = _tenka_resolution_service.resolve_tenka(scope_name)
        passing_filter = StatusFilter(resolved_passing)
        automation_filter = AutomationFilter(resolved_automation)
        results = _tenka_filter_service.filter_validation_status(
            tenka,
            fulfillment,
            ac_refs=ac_refs,
            passing_filter=passing_filter,
            automation_filter=automation_filter,
        )

        formatter = TenkaValidationMarkdownFormatter()
        result = formatter.format(scope_name, results)

        if used_default:
            result = f"> **Note:** Using default scope: `{scope_name}`\n\n{result}"

        logger.info(
            f"Successfully retrieved validation status for scope '{sanitize_for_logging(scope_name)}'"
        )
        return result

    except Exception as e:
        return ErrorMapper.map_to_error_string(e, context=scope_name if scope_name else "default")


_VALID_FEEDBACK_TYPES = {"contradictory_rules", "missed_categories"}


@mcp.tool()
def submit_feedback(
    type: str,
    task: str,
    rules_json: str | None = None,
    categories: str | None = None,
    reason: str | None = None,
) -> str:
    """Submit feedback about daimyo rules.

    Two feedback types are supported:

    **contradictory_rules** — two or more rules that conflict with each other.
    Requires ``rules_json``: a JSON array where each element is
    ``{"category": "<category-key>", "rule": "<rule-text>"}``.
    Example: ``'[{"category": "python.testing", "rule": "Use pytest"}]'``

    **missed_categories** — categories that were not initially fetched but should have been.
    Requires ``categories`` (comma-separated category names) and ``reason``.\f

    :param type: Feedback type — ``contradictory_rules`` or ``missed_categories``.
    :type type: str
    :param task: Description of the work being done when the issue was found.
    :type task: str
    :param rules_json: JSON array of ``{category, rule}`` objects (contradictory_rules only).
    :type rules_json: str | None
    :param categories: Comma-separated missed category names (missed_categories only).
    :type categories: str | None
    :param reason: Why the categories were not initially fetched (missed_categories only).
    :type reason: str | None
    :returns: Success message or error description.
    :rtype: str
    """
    try:
        if type not in _VALID_FEEDBACK_TYPES:
            return (
                f"Error: Unknown feedback type '{type}'. "
                f"Valid types: {', '.join(sorted(_VALID_FEEDBACK_TYPES))}"
            )

        if not task or not task.strip():
            return "Error: 'task' must not be empty."

        if type == "contradictory_rules":
            if not rules_json:
                return "Error: 'rules_json' is required for contradictory_rules feedback."
            try:
                rules = json.loads(rules_json)
            except json.JSONDecodeError as exc:
                return f"Error: 'rules_json' is not valid JSON: {exc}"
            if not isinstance(rules, list) or len(rules) == 0:
                return "Error: 'rules_json' must be a non-empty JSON array."
            payload: dict = {"task": task, "rules": rules}

        else:
            if not categories or not categories.strip():
                return "Error: 'categories' is required for missed_categories feedback."
            if not reason or not reason.strip():
                return "Error: 'reason' is required for missed_categories feedback."
            category_list = [c.strip() for c in categories.split(",") if c.strip()]
            if not category_list:
                return "Error: 'categories' must contain at least one category name."
            payload = {"task": task, "categories": category_list, "reason": reason}

        logger.info(f"MCP submit_feedback: type={sanitize_for_logging(type)}")
        _feedback_service.submit(type, payload)
        return "Feedback submitted successfully."

    except Exception as exc:
        return ErrorMapper.map_to_error_string(exc, context="submit_feedback")


__all__ = ["mcp"]
