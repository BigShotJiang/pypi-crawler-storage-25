"""Tenka API endpoints — user stories, acceptance criteria, and validation status."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Response

from daimyo.application.error_handling import ErrorMapper
from daimyo.application.formatters import (
    TenkaACMarkdownFormatter,
    TenkaUSMarkdownFormatter,
    TenkaValidationMarkdownFormatter,
)
from daimyo.application.tenka_filtering import (
    AutomationFilter,
    StatusFilter,
    TenkaFilteringService,
    VALID_AUTOMATION_VALUES,
    VALID_STATUS_VALUES,
)
from daimyo.application.tenka_resolution import TenkaResolutionService
from daimyo.application.validation import (
    ValidationError,
    sanitize_for_logging,
    validate_scope_name,
)
from daimyo.presentation.rest.dependencies import (
    get_tenka_filter_service,
    get_tenka_resolution_service,
)
from daimyo.presentation.rest.models import ErrorResponse
from daimyo.infrastructure.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/api/v1/scopes", tags=["tenka"])


@router.get(
    "/{name}/tenka/stories",
    response_model=None,
    responses={
        200: {
            "description": "Successful response",
            "content": {
                "text/markdown": {
                    "example": (
                        '- "kencho:US123": "As a(n) Administrator, I want a user management '
                        'facility, so that I can manage the users and their permissions"'
                    )
                },
            },
        },
        400: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
    summary="List user stories for a scope",
    description=(
        "Returns user stories for a scope in Markdown format. "
        "Inactive stories are hidden by default."
    ),
)
async def list_user_stories(
    name: str,
    tenka_service: Annotated[TenkaResolutionService, Depends(get_tenka_resolution_service)],
    filter_service: Annotated[TenkaFilteringService, Depends(get_tenka_filter_service)],
    status: Annotated[
        str | None,
        Query(description="Filter by validation status: validated, not_validated, or all"),
    ] = None,
    include_inactive: Annotated[
        bool,
        Query(description="Include deactivated user stories (default: false)"),
    ] = False,
) -> Response:
    """List user stories for a scope.

    :param name: Scope name
    :type name: str
    :param tenka_service: Tenka resolution service
    :type tenka_service: TenkaResolutionService
    :param filter_service: Tenka filter service
    :type filter_service: TenkaFilteringService
    :param status: Filter by validation status
    :type status: str | None
    :param include_inactive: Include deactivated user stories
    :type include_inactive: bool
    :returns: Markdown-formatted user story list
    :rtype: Response
    """
    try:
        validate_scope_name(name)
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

    resolved_status = status or "all"
    if resolved_status not in VALID_STATUS_VALUES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status '{resolved_status}'. Must be one of: {', '.join(sorted(VALID_STATUS_VALUES))}",
        )

    try:
        logger.info(
            f"GET /api/v1/scopes/{sanitize_for_logging(name)}/tenka/stories"
            f"?status={resolved_status}&include_inactive={include_inactive}"
        )
        tenka, fulfillment = tenka_service.resolve_tenka(name)
        status_filter = StatusFilter(resolved_status)
        stories = filter_service.filter_user_stories(
            tenka, fulfillment, include_inactive=include_inactive, status_filter=status_filter
        )
        formatter = TenkaUSMarkdownFormatter()
        content = formatter.format(name, stories)
        return Response(content=content, media_type="text/markdown")
    except Exception as e:
        raise ErrorMapper.map_to_http_exception(e, context=name)


@router.get(
    "/{name}/tenka/acs",
    response_model=None,
    responses={
        200: {
            "description": "Successful response",
            "content": {
                "text/markdown": {
                    "example": (
                        '- "kencho:AC123.1": Given a new username, '
                        "when inserting the user, then the user is added to the database."
                    )
                },
            },
        },
        400: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
    summary="List acceptance criteria for a scope",
    description=(
        "Returns acceptance criteria for a scope in Markdown format. "
        "Inactive ACs and ACs from inactive stories are hidden by default."
    ),
)
async def list_acceptance_criteria(
    name: str,
    tenka_service: Annotated[TenkaResolutionService, Depends(get_tenka_resolution_service)],
    filter_service: Annotated[TenkaFilteringService, Depends(get_tenka_filter_service)],
    stories: Annotated[
        str | None,
        Query(description="Comma-separated user story ids to filter by (e.g., US123,US456)"),
    ] = None,
    status: Annotated[
        str | None,
        Query(description="Filter by validation status: validated, not_validated, or all"),
    ] = None,
    include_inactive: Annotated[
        bool,
        Query(description="Include deactivated ACs and stories (default: false)"),
    ] = False,
) -> Response:
    """List acceptance criteria for a scope.

    :param name: Scope name
    :type name: str
    :param tenka_service: Tenka resolution service
    :type tenka_service: TenkaResolutionService
    :param filter_service: Tenka filter service
    :type filter_service: TenkaFilteringService
    :param stories: Comma-separated story ids to filter by
    :type stories: str | None
    :param status: Filter by validation status
    :type status: str | None
    :param include_inactive: Include deactivated ACs
    :type include_inactive: bool
    :returns: Markdown-formatted acceptance criteria list
    :rtype: Response
    """
    try:
        validate_scope_name(name)
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

    resolved_status = status or "all"
    if resolved_status not in VALID_STATUS_VALUES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid status '{resolved_status}'. Must be one of: {', '.join(sorted(VALID_STATUS_VALUES))}",
        )

    story_ids: list[str] | None = None
    if stories:
        story_ids = [s.strip() for s in stories.split(",") if s.strip()]

    try:
        logger.info(
            f"GET /api/v1/scopes/{sanitize_for_logging(name)}/tenka/acs"
            f"?stories={sanitize_for_logging(stories, is_comma_list=True)}"
            f"&status={resolved_status}&include_inactive={include_inactive}"
        )
        tenka, fulfillment = tenka_service.resolve_tenka(name)
        status_filter = StatusFilter(resolved_status)
        acs = filter_service.filter_acceptance_criteria(
            tenka,
            fulfillment,
            story_ids=story_ids,
            include_inactive=include_inactive,
            status_filter=status_filter,
        )
        formatter = TenkaACMarkdownFormatter()
        content = formatter.format(name, acs)
        return Response(content=content, media_type="text/markdown")
    except Exception as e:
        raise ErrorMapper.map_to_http_exception(e, context=name)


@router.get(
    "/{name}/tenka/validation",
    response_model=None,
    responses={
        200: {
            "description": "Successful response",
            "content": {
                "text/markdown": {
                    "example": (
                        '- "kencho:AC123.1": VALIDATED\n'
                        '- "kencho:AC123.2": NOT VALIDATED\n'
                        "  - Failed tests:\n"
                        "    - (auto) `tests/test_x.py:test_case`: Assertion failed"
                    )
                },
            },
        },
        400: {"model": ErrorResponse},
        404: {"model": ErrorResponse},
        500: {"model": ErrorResponse},
    },
    summary="Get validation status for acceptance criteria",
    description=(
        "Returns the validation status of acceptance criteria for a scope. "
        "Only active ACs from active user stories are included."
    ),
)
async def get_validation_status(
    name: str,
    tenka_service: Annotated[TenkaResolutionService, Depends(get_tenka_resolution_service)],
    filter_service: Annotated[TenkaFilteringService, Depends(get_tenka_filter_service)],
    acs: Annotated[
        str | None,
        Query(description="Comma-separated AC reference ids to filter by (e.g., AC123.1,AC123.2)"),
    ] = None,
    passing: Annotated[
        str | None,
        Query(description="Filter by passing status: validated, not_validated, or all"),
    ] = None,
    automation: Annotated[
        str | None,
        Query(description="Filter by automation coverage: automated, has_manual, or all"),
    ] = None,
) -> Response:
    """Get validation status for acceptance criteria in a scope.

    :param name: Scope name
    :type name: str
    :param tenka_service: Tenka resolution service
    :type tenka_service: TenkaResolutionService
    :param filter_service: Tenka filter service
    :type filter_service: TenkaFilteringService
    :param acs: Comma-separated AC reference ids to filter by
    :type acs: str | None
    :param passing: Filter by passing status
    :type passing: str | None
    :param automation: Filter by automation coverage
    :type automation: str | None
    :returns: Markdown-formatted validation status report
    :rtype: Response
    """
    try:
        validate_scope_name(name)
    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))

    resolved_passing = passing or "all"
    if resolved_passing not in VALID_STATUS_VALUES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid passing filter '{resolved_passing}'. Must be one of: {', '.join(sorted(VALID_STATUS_VALUES))}",
        )

    resolved_automation = automation or "all"
    if resolved_automation not in VALID_AUTOMATION_VALUES:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid automation filter '{resolved_automation}'. Must be one of: {', '.join(sorted(VALID_AUTOMATION_VALUES))}",
        )

    ac_refs: list[str] | None = None
    if acs:
        ac_refs = [a.strip() for a in acs.split(",") if a.strip()]

    try:
        logger.info(
            f"GET /api/v1/scopes/{sanitize_for_logging(name)}/tenka/validation"
            f"?acs={sanitize_for_logging(acs, is_comma_list=True)}"
            f"&passing={resolved_passing}&automation={resolved_automation}"
        )
        tenka, fulfillment = tenka_service.resolve_tenka(name)
        passing_filter = StatusFilter(resolved_passing)
        automation_filter = AutomationFilter(resolved_automation)
        results = filter_service.filter_validation_status(
            tenka,
            fulfillment,
            ac_refs=ac_refs,
            passing_filter=passing_filter,
            automation_filter=automation_filter,
        )
        formatter = TenkaValidationMarkdownFormatter()
        content = formatter.format(name, results)
        return Response(content=content, media_type="text/markdown")
    except Exception as e:
        raise ErrorMapper.map_to_http_exception(e, context=name)


__all__ = ["router"]
