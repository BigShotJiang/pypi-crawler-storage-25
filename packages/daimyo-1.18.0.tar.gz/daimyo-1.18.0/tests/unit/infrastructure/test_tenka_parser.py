"""Unit tests for tenka YAML parser."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from daimyo.domain import (
    AutoValidation,
    InvalidScopeError,
    ManualValidation,
)
from daimyo.infrastructure.filesystem.tenka_parser import parse_tenka, parse_tenka_fulfillment


class TestParseTenka:
    def test_empty_key(self):
        tenka = parse_tenka({})
        assert tenka.stories == {}

    def test_null_tenka_key(self):
        tenka = parse_tenka({"tenka": None})
        assert tenka.stories == {}

    def test_minimal_story(self):
        data = {
            "tenka": {
                "US1": {
                    "who": "Admin",
                    "what": "manage users",
                    "why": "I can control access",
                }
            }
        }
        tenka = parse_tenka(data)
        assert "US1" in tenka.stories
        story = tenka.stories["US1"]
        assert story.id == "US1"
        assert story.who == "Admin"
        assert story.what == "manage users"
        assert story.why == "I can control access"
        assert story.active is True
        assert story.acs == {}

    def test_story_with_inactive(self):
        data = {
            "tenka": {
                "US1": {
                    "who": "Admin",
                    "what": "manage",
                    "why": "control",
                    "active": False,
                }
            }
        }
        tenka = parse_tenka(data)
        assert tenka.stories["US1"].active is False

    def test_story_with_full_ac(self):
        data = {
            "tenka": {
                "US1": {
                    "who": "Admin",
                    "what": "manage",
                    "why": "control",
                    "acs": {
                        "AC1.1": {
                            "given": "a valid payload",
                            "when": "submitting the form",
                            "then": "the user is saved",
                        }
                    },
                }
            }
        }
        tenka = parse_tenka(data)
        ac = tenka.stories["US1"].acs["AC1.1"]
        assert ac.id == "AC1.1"
        assert ac.given == "a valid payload"
        assert ac.when_clause == "submitting the form"
        assert ac.then == "the user is saved"
        assert ac.active is True

    def test_ac_minimal_then_only(self):
        data = {
            "tenka": {
                "US1": {
                    "who": "A",
                    "what": "B",
                    "why": "C",
                    "acs": {"AC1.1": {"then": "done"}},
                }
            }
        }
        ac = parse_tenka(data).stories["US1"].acs["AC1.1"]
        assert ac.given is None
        assert ac.when_clause is None

    def test_ac_inactive(self):
        data = {
            "tenka": {
                "US1": {
                    "who": "A",
                    "what": "B",
                    "why": "C",
                    "acs": {"AC1.1": {"then": "done", "active": False}},
                }
            }
        }
        ac = parse_tenka(data).stories["US1"].acs["AC1.1"]
        assert ac.active is False

    def test_empty_given_becomes_none(self):
        data = {
            "tenka": {
                "US1": {
                    "who": "A",
                    "what": "B",
                    "why": "C",
                    "acs": {"AC1.1": {"then": "done", "given": ""}},
                }
            }
        }
        ac = parse_tenka(data).stories["US1"].acs["AC1.1"]
        assert ac.given is None

    def test_invalid_tenka_not_dict(self):
        with pytest.raises(InvalidScopeError):
            parse_tenka({"tenka": "bad"})

    def test_invalid_story_not_dict(self):
        with pytest.raises(InvalidScopeError):
            parse_tenka({"tenka": {"US1": "bad"}})

    def test_missing_who(self):
        with pytest.raises(InvalidScopeError):
            parse_tenka({"tenka": {"US1": {"what": "x", "why": "y"}}})

    def test_missing_then(self):
        with pytest.raises(InvalidScopeError):
            parse_tenka(
                {
                    "tenka": {
                        "US1": {
                            "who": "A",
                            "what": "B",
                            "why": "C",
                            "acs": {"AC1.1": {"given": "x"}},
                        }
                    }
                }
            )

    def test_invalid_active_type(self):
        with pytest.raises(InvalidScopeError):
            parse_tenka({"tenka": {"US1": {"who": "A", "what": "B", "why": "C", "active": "yes"}}})

    def test_invalid_us_id_format(self):
        with pytest.raises(InvalidScopeError, match="US<number>"):
            parse_tenka({"tenka": {"BadId": {"who": "A", "what": "B", "why": "C"}}})

    def test_invalid_us_id_no_number(self):
        with pytest.raises(InvalidScopeError, match="US<number>"):
            parse_tenka({"tenka": {"US": {"who": "A", "what": "B", "why": "C"}}})

    def test_invalid_ac_id_format(self):
        with pytest.raises(InvalidScopeError, match="AC<number>"):
            parse_tenka({
                "tenka": {
                    "US1": {
                        "who": "A", "what": "B", "why": "C",
                        "acs": {"BadAC": {"then": "done"}},
                    }
                }
            })


class TestParseTenkaFulfillment:
    def test_empty(self):
        tf = parse_tenka_fulfillment({})
        assert tf.fulfillments == {}

    def test_null_key(self):
        tf = parse_tenka_fulfillment({"tenka_fulfillment": None})
        assert tf.fulfillments == {}

    def test_auto_entry_passed(self):
        data = {
            "tenka_fulfillment": {
                "AC1.1": [
                    {
                        "type": "auto",
                        "source": "tests/test_x.py",
                        "name": "test_thing",
                        "passed": True,
                        "timestamp": "2026-05-14T20:47:00Z",
                    }
                ]
            }
        }
        tf = parse_tenka_fulfillment(data)
        ac_f = tf.fulfillments["AC1.1"]
        assert len(ac_f.validations) == 1
        v = ac_f.validations[0]
        assert isinstance(v, AutoValidation)
        assert v.source == "tests/test_x.py"
        assert v.name == "test_thing"
        assert v.passed is True
        assert v.message is None

    def test_auto_entry_with_message(self):
        data = {
            "tenka_fulfillment": {
                "AC1.1": [
                    {
                        "type": "auto",
                        "source": "t.py",
                        "name": "test_x",
                        "passed": False,
                        "timestamp": "2026-01-01T00:00:00+00:00",
                        "message": "Assertion failed",
                    }
                ]
            }
        }
        tf = parse_tenka_fulfillment(data)
        v = tf.fulfillments["AC1.1"].validations[0]
        assert isinstance(v, AutoValidation)
        assert v.passed is False
        assert v.message == "Assertion failed"

    def test_manual_entry(self):
        data = {
            "tenka_fulfillment": {
                "AC1.1": [
                    {
                        "type": "manual",
                        "verdict": "Looks good",
                        "passed": True,
                        "timestamp": "2026-05-14T12:00:00Z",
                    }
                ]
            }
        }
        tf = parse_tenka_fulfillment(data)
        v = tf.fulfillments["AC1.1"].validations[0]
        assert isinstance(v, ManualValidation)
        assert v.verdict == "Looks good"
        assert v.passed is True

    def test_passed_defaults_false(self):
        data = {
            "tenka_fulfillment": {
                "AC1.1": [
                    {
                        "type": "auto",
                        "source": "t.py",
                        "name": "test_x",
                        "timestamp": "2026-01-01T00:00:00Z",
                    }
                ]
            }
        }
        tf = parse_tenka_fulfillment(data)
        assert tf.fulfillments["AC1.1"].validations[0].passed is False

    def test_multiple_entries(self):
        data = {
            "tenka_fulfillment": {
                "AC1.1": [
                    {
                        "type": "auto",
                        "source": "t.py",
                        "name": "test_a",
                        "passed": True,
                        "timestamp": "2026-01-01T00:00:00Z",
                    },
                    {
                        "type": "manual",
                        "verdict": "ok",
                        "passed": True,
                        "timestamp": "2026-01-01T00:00:00Z",
                    },
                ]
            }
        }
        tf = parse_tenka_fulfillment(data)
        assert len(tf.fulfillments["AC1.1"].validations) == 2

    def test_invalid_type(self):
        data = {
            "tenka_fulfillment": {
                "AC1.1": [
                    {"type": "unknown", "timestamp": "2026-01-01T00:00:00Z"}
                ]
            }
        }
        with pytest.raises(InvalidScopeError):
            parse_tenka_fulfillment(data)

    def test_missing_timestamp(self):
        data = {
            "tenka_fulfillment": {
                "AC1.1": [{"type": "auto", "source": "t.py", "name": "x", "passed": True}]
            }
        }
        with pytest.raises(InvalidScopeError):
            parse_tenka_fulfillment(data)

    def test_not_a_list(self):
        data = {"tenka_fulfillment": {"AC1.1": "bad"}}
        with pytest.raises(InvalidScopeError):
            parse_tenka_fulfillment(data)

    def test_not_a_dict(self):
        data = {"tenka_fulfillment": "bad"}
        with pytest.raises(InvalidScopeError):
            parse_tenka_fulfillment(data)

    def test_datetime_object_timestamp(self):
        ts = datetime(2026, 5, 14, 20, 47, 0)
        data = {
            "tenka_fulfillment": {
                "AC1.1": [
                    {"type": "auto", "source": "t.py", "name": "x", "passed": True, "timestamp": ts}
                ]
            }
        }
        tf = parse_tenka_fulfillment(data)
        v = tf.fulfillments["AC1.1"].validations[0]
        assert v.timestamp.tzinfo == timezone.utc

    def test_invalid_ac_ref_format(self):
        data = {"tenka_fulfillment": {"BadRef": []}}
        with pytest.raises(InvalidScopeError, match="AC<number>"):
            parse_tenka_fulfillment(data)
