"""Unit tests for tenka domain models."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from daimyo.domain import (
    ACFulfillment,
    AcceptanceCriterion,
    AutoValidation,
    ManualValidation,
    Tenka,
    TenkaFulfillment,
    UserStory,
)


_TS = datetime(2026, 1, 1, tzinfo=timezone.utc)


class TestAcceptanceCriterion:
    def test_creation_minimal(self):
        ac = AcceptanceCriterion(id="AC1.1", then="the user is saved")
        assert ac.id == "AC1.1"
        assert ac.then == "the user is saved"
        assert ac.given is None
        assert ac.when_clause is None
        assert ac.active is True

    def test_creation_full(self):
        ac = AcceptanceCriterion(
            id="AC1.2",
            then="the user is saved",
            given="a valid payload",
            when_clause="submitting the form",
            active=False,
        )
        assert ac.given == "a valid payload"
        assert ac.when_clause == "submitting the form"
        assert ac.active is False

    def test_as_text_then_only(self):
        ac = AcceptanceCriterion(id="AC1.1", then="the user is saved")
        assert ac.as_text() == "then the user is saved."

    def test_as_text_given_when_then(self):
        ac = AcceptanceCriterion(
            id="AC1.1",
            then="the user is saved",
            given="a valid payload",
            when_clause="submitting the form",
        )
        assert ac.as_text() == "Given a valid payload, when submitting the form, then the user is saved."

    def test_as_text_given_then(self):
        ac = AcceptanceCriterion(id="AC1.1", then="the user is saved", given="a valid payload")
        assert ac.as_text() == "Given a valid payload, then the user is saved."

    def test_as_text_when_then(self):
        ac = AcceptanceCriterion(
            id="AC1.1", then="the user is saved", when_clause="submitting the form"
        )
        assert ac.as_text() == "when submitting the form, then the user is saved."

    def test_immutability(self):
        ac = AcceptanceCriterion(id="AC1.1", then="saved")
        with pytest.raises(Exception):
            ac.id = "AC1.2"  # type: ignore[misc]


class TestUserStory:
    def test_creation(self):
        story = UserStory(id="US1", who="Admin", what="manage users", why="I can control access")
        assert story.id == "US1"
        assert story.who == "Admin"
        assert story.what == "manage users"
        assert story.why == "I can control access"
        assert story.active is True
        assert story.acs == {}

    def test_creation_inactive(self):
        story = UserStory(id="US1", who="Admin", what="manage users", why="x", active=False)
        assert story.active is False

    def test_as_text(self):
        story = UserStory(id="US1", who="Admin", what="manage users", why="I can control access")
        assert story.as_text() == "As a(n) Admin, I want manage users, so that I can control access"

    def test_acs_mutable(self):
        story = UserStory(id="US1", who="A", what="B", why="C")
        ac = AcceptanceCriterion(id="AC1.1", then="done")
        story.acs["AC1.1"] = ac
        assert "AC1.1" in story.acs


class TestTenka:
    def test_empty(self):
        tenka = Tenka()
        assert tenka.stories == {}

    def test_with_stories(self):
        tenka = Tenka()
        tenka.stories["US1"] = UserStory(id="US1", who="A", what="B", why="C")
        assert len(tenka.stories) == 1


class TestACFulfillment:
    def test_empty_not_validated(self):
        f = ACFulfillment(ac_ref="AC1.1")
        assert not f.is_validated
        assert f.failed_validations == []
        assert not f.has_auto
        assert not f.has_manual

    def test_all_passed_validated(self):
        f = ACFulfillment(
            ac_ref="AC1.1",
            validations=[
                AutoValidation(source="t.py", name="test_x", passed=True, timestamp=_TS),
                ManualValidation(verdict="ok", passed=True, timestamp=_TS),
            ],
        )
        assert f.is_validated
        assert f.failed_validations == []
        assert f.has_auto
        assert f.has_manual

    def test_one_failed_not_validated(self):
        auto_fail = AutoValidation(source="t.py", name="test_x", passed=False, timestamp=_TS)
        f = ACFulfillment(
            ac_ref="AC1.1",
            validations=[
                auto_fail,
                ManualValidation(verdict="ok", passed=True, timestamp=_TS),
            ],
        )
        assert not f.is_validated
        assert f.failed_validations == [auto_fail]

    def test_auto_only(self):
        f = ACFulfillment(
            ac_ref="AC1.1",
            validations=[AutoValidation(source="t.py", name="test_x", passed=True, timestamp=_TS)],
        )
        assert f.has_auto
        assert not f.has_manual

    def test_manual_only(self):
        f = ACFulfillment(
            ac_ref="AC1.1",
            validations=[ManualValidation(verdict="ok", passed=True, timestamp=_TS)],
        )
        assert not f.has_auto
        assert f.has_manual


class TestTenkaFulfillment:
    def test_get_for_ac_present(self):
        ac_f = ACFulfillment(ac_ref="AC1.1")
        tf = TenkaFulfillment(fulfillments={"AC1.1": ac_f})
        assert tf.get_for_ac("AC1.1") is ac_f

    def test_get_for_ac_absent(self):
        tf = TenkaFulfillment()
        assert tf.get_for_ac("AC1.1") is None

    def test_empty(self):
        tf = TenkaFulfillment()
        assert tf.fulfillments == {}
