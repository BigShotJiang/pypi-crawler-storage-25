"""Unit tests for TenkaFilteringService."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from daimyo.application.tenka_filtering import AutomationFilter, StatusFilter, TenkaFilteringService
from daimyo.domain import (
    ACFulfillment,
    AcceptanceCriterion,
    AutoValidation,
    ManualValidation,
    Tenka,
    TenkaFulfillment,
    UserStory,
)


_TS = datetime(2026, 1, 1, tzinfo=timezone.utc)


def _ac(ac_id: str, active: bool = True) -> AcceptanceCriterion:
    return AcceptanceCriterion(id=ac_id, then="done", active=active)


def _story(us_id: str, active: bool = True, acs: list[AcceptanceCriterion] | None = None) -> UserStory:
    story = UserStory(id=us_id, who="A", what="B", why="C", active=active)
    for ac in (acs or []):
        story.acs[ac.id] = ac
    return story


def _auto_pass() -> AutoValidation:
    return AutoValidation(source="t.py", name="test_x", passed=True, timestamp=_TS)


def _auto_fail() -> AutoValidation:
    return AutoValidation(source="t.py", name="test_x", passed=False, timestamp=_TS)


def _manual_pass() -> ManualValidation:
    return ManualValidation(verdict="ok", passed=True, timestamp=_TS)



def _fulfillment(validations_by_ac: dict) -> TenkaFulfillment:
    tf = TenkaFulfillment()
    for ac_ref, validations in validations_by_ac.items():
        tf.fulfillments[ac_ref] = ACFulfillment(ac_ref=ac_ref, validations=validations)
    return tf


@pytest.fixture
def service() -> TenkaFilteringService:
    return TenkaFilteringService()


class TestFilterUserStories:
    def test_empty_tenka(self, service):
        assert service.filter_user_stories(Tenka(), None) == []

    def test_active_stories_returned(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1")
        result = service.filter_user_stories(tenka, None)
        assert len(result) == 1

    def test_inactive_excluded_by_default(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", active=False)
        result = service.filter_user_stories(tenka, None)
        assert result == []

    def test_include_inactive(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", active=False)
        result = service.filter_user_stories(tenka, None, include_inactive=True)
        assert len(result) == 1

    def test_status_validated_no_fulfillment(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        result = service.filter_user_stories(tenka, None, status_filter=StatusFilter.VALIDATED)
        assert result == []

    def test_status_not_validated_no_fulfillment(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        result = service.filter_user_stories(tenka, None, status_filter=StatusFilter.NOT_VALIDATED)
        assert len(result) == 1

    def test_status_validated_all_acs_passed(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        fulfillment = _fulfillment({"AC1.1": [_auto_pass()]})
        result = service.filter_user_stories(tenka, fulfillment, status_filter=StatusFilter.VALIDATED)
        assert len(result) == 1

    def test_status_validated_one_ac_failed(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        fulfillment = _fulfillment({"AC1.1": [_auto_pass()], "AC1.2": [_auto_fail()]})
        result = service.filter_user_stories(tenka, fulfillment, status_filter=StatusFilter.VALIDATED)
        assert result == []

    def test_story_with_no_active_acs_not_validated(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1", active=False)])
        fulfillment = _fulfillment({})
        result = service.filter_user_stories(tenka, fulfillment, status_filter=StatusFilter.VALIDATED)
        assert result == []


class TestFilterAcceptanceCriteria:
    def test_empty_tenka(self, service):
        assert service.filter_acceptance_criteria(Tenka(), None) == []

    def test_active_acs_returned(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        result = service.filter_acceptance_criteria(tenka, None)
        assert len(result) == 2

    def test_inactive_ac_excluded(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2", active=False)])
        result = service.filter_acceptance_criteria(tenka, None)
        assert len(result) == 1
        assert result[0].id == "AC1.1"

    def test_inactive_story_excluded(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", active=False, acs=[_ac("AC1.1")])
        result = service.filter_acceptance_criteria(tenka, None)
        assert result == []

    def test_include_inactive(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", active=False, acs=[_ac("AC1.1")])
        result = service.filter_acceptance_criteria(tenka, None, include_inactive=True)
        assert len(result) == 1

    def test_story_ids_filter(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        tenka.stories["US2"] = _story("US2", acs=[_ac("AC2.1")])
        result = service.filter_acceptance_criteria(tenka, None, story_ids=["US1"])
        assert len(result) == 1
        assert result[0].id == "AC1.1"

    def test_status_validated(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        fulfillment = _fulfillment({"AC1.1": [_auto_pass()]})
        result = service.filter_acceptance_criteria(
            tenka, fulfillment, status_filter=StatusFilter.VALIDATED
        )
        assert len(result) == 1
        assert result[0].id == "AC1.1"

    def test_status_not_validated(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        fulfillment = _fulfillment({"AC1.1": [_auto_pass()]})
        result = service.filter_acceptance_criteria(
            tenka, fulfillment, status_filter=StatusFilter.NOT_VALIDATED
        )
        assert len(result) == 1
        assert result[0].id == "AC1.2"


class TestFilterValidationStatus:
    def test_empty_tenka(self, service):
        assert service.filter_validation_status(Tenka(), None) == []

    def test_active_acs_included(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        result = service.filter_validation_status(tenka, None)
        assert len(result) == 1
        assert result[0][0] == "AC1.1"
        assert result[0][1] is None

    def test_inactive_acs_excluded(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1", active=False)])
        assert service.filter_validation_status(tenka, None) == []

    def test_inactive_stories_excluded(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", active=False, acs=[_ac("AC1.1")])
        assert service.filter_validation_status(tenka, None) == []

    def test_ac_refs_filter(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        result = service.filter_validation_status(tenka, None, ac_refs=["AC1.1"])
        assert len(result) == 1
        assert result[0][0] == "AC1.1"

    def test_passing_filter_validated(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        fulfillment = _fulfillment({"AC1.1": [_auto_pass()]})
        result = service.filter_validation_status(
            tenka, fulfillment, passing_filter=StatusFilter.VALIDATED
        )
        assert len(result) == 1
        assert result[0][0] == "AC1.1"

    def test_passing_filter_not_validated(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        fulfillment = _fulfillment({"AC1.1": [_auto_pass()]})
        result = service.filter_validation_status(
            tenka, fulfillment, passing_filter=StatusFilter.NOT_VALIDATED
        )
        assert len(result) == 1
        assert result[0][0] == "AC1.2"

    def test_automation_filter_automated(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        fulfillment = _fulfillment({
            "AC1.1": [_auto_pass()],                    # auto only
            "AC1.2": [_auto_pass(), _manual_pass()],    # mixed
        })
        result = service.filter_validation_status(
            tenka, fulfillment, automation_filter=AutomationFilter.AUTOMATED
        )
        assert len(result) == 1
        assert result[0][0] == "AC1.1"

    def test_automation_filter_has_manual(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1"), _ac("AC1.2")])
        fulfillment = _fulfillment({
            "AC1.1": [_auto_pass()],
            "AC1.2": [_manual_pass()],
        })
        result = service.filter_validation_status(
            tenka, fulfillment, automation_filter=AutomationFilter.HAS_MANUAL
        )
        assert len(result) == 1
        assert result[0][0] == "AC1.2"

    def test_automation_filter_excludes_no_fulfillment(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        result = service.filter_validation_status(
            tenka, None, automation_filter=AutomationFilter.AUTOMATED
        )
        assert result == []

    def test_automation_filter_excludes_empty_validations(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        fulfillment = _fulfillment({"AC1.1": []})
        result = service.filter_validation_status(
            tenka, fulfillment, automation_filter=AutomationFilter.HAS_MANUAL
        )
        assert result == []

    def test_fulfillment_attached_to_result(self, service):
        tenka = Tenka()
        tenka.stories["US1"] = _story("US1", acs=[_ac("AC1.1")])
        fulfillment = _fulfillment({"AC1.1": [_auto_pass()]})
        result = service.filter_validation_status(tenka, fulfillment)
        assert result[0][1] is not None
        assert result[0][1].ac_ref == "AC1.1"
