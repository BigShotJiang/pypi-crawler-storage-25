"""Unit tests for TenkaMergingService (selective AC override merge)."""

from __future__ import annotations

import pytest

from daimyo.application.tenka_service import TenkaMergingService
from daimyo.domain import AcceptanceCriterion, Tenka, UserStory


def _ac(ac_id: str, then: str = "done", active: bool = True) -> AcceptanceCriterion:
    return AcceptanceCriterion(id=ac_id, then=then, active=active)


def _story(
    us_id: str,
    who: str = "Admin",
    what: str = "do something",
    why: str = "it works",
    active: bool = True,
    acs: dict[str, AcceptanceCriterion] | None = None,
) -> UserStory:
    story = UserStory(id=us_id, who=who, what=what, why=why, active=active)
    if acs:
        story.acs.update(acs)
    return story


@pytest.fixture
def service() -> TenkaMergingService:
    return TenkaMergingService()


class TestMergeEmpty:
    def test_both_empty(self, service):
        result = service.merge(Tenka(), Tenka())
        assert result.stories == {}

    def test_parent_empty_child_has_story(self, service):
        child = Tenka()
        child.stories["US1"] = _story("US1")
        result = service.merge(Tenka(), child)
        assert "US1" in result.stories

    def test_child_empty_parent_has_story(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1")
        result = service.merge(parent, Tenka())
        assert "US1" in result.stories


class TestMergeStoryInheritance:
    def test_parent_only_story_inherited_verbatim(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1", who="ParentRole")
        result = service.merge(parent, Tenka())
        assert result.stories["US1"].who == "ParentRole"

    def test_child_only_story_added(self, service):
        child = Tenka()
        child.stories["US2"] = _story("US2", who="ChildRole")
        result = service.merge(Tenka(), child)
        assert result.stories["US2"].who == "ChildRole"

    def test_child_overrides_parent_fields(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1", who="ParentRole", what="old what", why="old why")
        child = Tenka()
        child.stories["US1"] = _story("US1", who="ChildRole", what="new what", why="new why")
        result = service.merge(parent, child)
        s = result.stories["US1"]
        assert s.who == "ChildRole"
        assert s.what == "new what"
        assert s.why == "new why"

    def test_child_overrides_active_flag(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1", active=True)
        child = Tenka()
        child.stories["US1"] = _story("US1", active=False)
        result = service.merge(parent, child)
        assert result.stories["US1"].active is False

    def test_multiple_parents_and_child(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1")
        parent.stories["US2"] = _story("US2")
        child = Tenka()
        child.stories["US3"] = _story("US3")
        result = service.merge(parent, child)
        assert "US1" in result.stories
        assert "US2" in result.stories
        assert "US3" in result.stories


class TestMergeACOverride:
    def test_parent_acs_inherited_when_child_has_none(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1", acs={"AC1.1": _ac("AC1.1", then="parent then")})
        child = Tenka()
        child.stories["US1"] = _story("US1")
        result = service.merge(parent, child)
        assert "AC1.1" in result.stories["US1"].acs
        assert result.stories["US1"].acs["AC1.1"].then == "parent then"

    def test_child_ac_overrides_parent_ac_by_id(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1", acs={"AC1.1": _ac("AC1.1", then="parent then")})
        child = Tenka()
        child.stories["US1"] = _story("US1", acs={"AC1.1": _ac("AC1.1", then="child then")})
        result = service.merge(parent, child)
        assert result.stories["US1"].acs["AC1.1"].then == "child then"

    def test_child_adds_new_ac_retaining_parent_acs(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1", acs={"AC1.1": _ac("AC1.1", then="from parent")})
        child = Tenka()
        child.stories["US1"] = _story("US1", acs={"AC1.2": _ac("AC1.2", then="from child")})
        result = service.merge(parent, child)
        acs = result.stories["US1"].acs
        assert "AC1.1" in acs
        assert acs["AC1.1"].then == "from parent"
        assert "AC1.2" in acs
        assert acs["AC1.2"].then == "from child"

    def test_child_partial_ac_override(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story(
            "US1",
            acs={
                "AC1.1": _ac("AC1.1", then="p1"),
                "AC1.2": _ac("AC1.2", then="p2"),
                "AC1.3": _ac("AC1.3", then="p3"),
            },
        )
        child = Tenka()
        child.stories["US1"] = _story("US1", acs={"AC1.2": _ac("AC1.2", then="c2")})
        result = service.merge(parent, child)
        acs = result.stories["US1"].acs
        assert acs["AC1.1"].then == "p1"
        assert acs["AC1.2"].then == "c2"
        assert acs["AC1.3"].then == "p3"

    def test_does_not_mutate_parent(self, service):
        parent = Tenka()
        parent.stories["US1"] = _story("US1", acs={"AC1.1": _ac("AC1.1", then="original")})
        child = Tenka()
        child.stories["US1"] = _story("US1", acs={"AC1.1": _ac("AC1.1", then="override")})
        service.merge(parent, child)
        assert parent.stories["US1"].acs["AC1.1"].then == "original"
