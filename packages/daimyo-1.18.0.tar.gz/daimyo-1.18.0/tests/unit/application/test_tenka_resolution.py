"""Unit tests for TenkaResolutionService."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from daimyo.application.tenka_resolution import TenkaResolutionService
from daimyo.domain import (
    CircularDependencyError,
    InheritanceDepthExceededError,
    Scope,
    ScopeMetadata,
    ScopeNotFoundError,
    Tenka,
    TenkaFulfillment,
    UserStory,
)


def _scope(name: str, parent: str | None = None, parents: list[str] | None = None) -> Scope:
    return Scope(metadata=ScopeMetadata(name=name, description="", parent=parent, parents=parents))


def _tenka_with_story(us_id: str) -> Tenka:
    t = Tenka()
    t.stories[us_id] = UserStory(id=us_id, who="A", what="B", why="C")
    return t


@pytest.fixture
def scope_repo():
    return MagicMock()


@pytest.fixture
def tenka_repo():
    return MagicMock()


@pytest.fixture
def service(scope_repo, tenka_repo) -> TenkaResolutionService:
    return TenkaResolutionService(scope_repo, tenka_repo, max_depth=5)


class TestResolveNoInheritance:
    def test_scope_not_found_raises(self, service, scope_repo):
        scope_repo.get_scope.return_value = None
        with pytest.raises(ScopeNotFoundError):
            service.resolve_tenka("missing")

    def test_no_parent_returns_local_tenka(self, service, scope_repo, tenka_repo):
        scope_repo.get_scope.return_value = _scope("leaf")
        tenka_repo.get_tenka.return_value = _tenka_with_story("US1")
        tenka_repo.get_tenka_fulfillment.return_value = None
        tenka, fulfillment = service.resolve_tenka("leaf")
        assert "US1" in tenka.stories
        assert fulfillment is None

    def test_no_tenka_file_returns_empty(self, service, scope_repo, tenka_repo):
        scope_repo.get_scope.return_value = _scope("leaf")
        tenka_repo.get_tenka.return_value = None
        tenka_repo.get_tenka_fulfillment.return_value = None
        tenka, _ = service.resolve_tenka("leaf")
        assert tenka.stories == {}

    def test_fulfillment_loaded_for_requested_scope(self, service, scope_repo, tenka_repo):
        scope_repo.get_scope.return_value = _scope("leaf")
        tenka_repo.get_tenka.return_value = None
        fulfillment = TenkaFulfillment()
        tenka_repo.get_tenka_fulfillment.return_value = fulfillment
        _, result = service.resolve_tenka("leaf")
        assert result is fulfillment
        tenka_repo.get_tenka_fulfillment.assert_called_once_with("leaf")


class TestResolveWithInheritance:
    def test_single_parent_merged(self, service, scope_repo, tenka_repo):
        parent_tenka = _tenka_with_story("US-parent")
        child_tenka = _tenka_with_story("US-child")

        def get_scope(name):
            if name == "child":
                return _scope("child", parent="parent")
            if name == "parent":
                return _scope("parent")
            return None

        def get_tenka(name):
            if name == "child":
                return child_tenka
            if name == "parent":
                return parent_tenka
            return None

        scope_repo.get_scope.side_effect = get_scope
        tenka_repo.get_tenka.side_effect = get_tenka
        tenka_repo.get_tenka_fulfillment.return_value = None

        tenka, _ = service.resolve_tenka("child")
        assert "US-parent" in tenka.stories
        assert "US-child" in tenka.stories

    def test_missing_parent_scope_treated_as_empty(self, service, scope_repo, tenka_repo):
        def get_scope(name):
            if name == "child":
                return _scope("child", parent="ghost-parent")
            return None

        scope_repo.get_scope.side_effect = get_scope
        tenka_repo.get_tenka.return_value = _tenka_with_story("US-child")
        tenka_repo.get_tenka_fulfillment.return_value = None

        tenka, _ = service.resolve_tenka("child")
        assert "US-child" in tenka.stories

    def test_fulfillment_not_loaded_for_parent(self, service, scope_repo, tenka_repo):
        def get_scope(name):
            if name == "child":
                return _scope("child", parent="parent")
            return _scope(name)

        scope_repo.get_scope.side_effect = get_scope
        tenka_repo.get_tenka.return_value = None
        tenka_repo.get_tenka_fulfillment.return_value = None

        service.resolve_tenka("child")
        tenka_repo.get_tenka_fulfillment.assert_called_once_with("child")

    def test_multiple_parents_merged_left_to_right(self, service, scope_repo, tenka_repo):
        p1_tenka = _tenka_with_story("US-p1")
        p2_tenka = _tenka_with_story("US-p2")

        def get_scope(name):
            if name == "child":
                return _scope("child", parents=["p1", "p2"])
            return _scope(name)

        def get_tenka(name):
            if name == "p1":
                return p1_tenka
            if name == "p2":
                return p2_tenka
            return None

        scope_repo.get_scope.side_effect = get_scope
        tenka_repo.get_tenka.side_effect = get_tenka
        tenka_repo.get_tenka_fulfillment.return_value = None

        tenka, _ = service.resolve_tenka("child")
        assert "US-p1" in tenka.stories
        assert "US-p2" in tenka.stories


class TestResolutionErrors:
    def test_circular_dependency_detected(self, service, scope_repo, tenka_repo):
        def get_scope(name):
            if name == "a":
                return _scope("a", parent="b")
            if name == "b":
                return _scope("b", parent="a")
            return None

        scope_repo.get_scope.side_effect = get_scope
        tenka_repo.get_tenka.return_value = None
        tenka_repo.get_tenka_fulfillment.return_value = None

        with pytest.raises(CircularDependencyError):
            service.resolve_tenka("a")

    def test_max_depth_exceeded(self, tenka_repo):
        scope_repo = MagicMock()
        svc = TenkaResolutionService(scope_repo, tenka_repo, max_depth=2)

        def get_scope(name):
            depth = int(name.split("_")[1])
            next_name = f"scope_{depth + 1}"
            return _scope(name, parent=next_name)

        scope_repo.get_scope.side_effect = get_scope
        tenka_repo.get_tenka.return_value = None
        tenka_repo.get_tenka_fulfillment.return_value = None

        with pytest.raises(InheritanceDepthExceededError):
            svc.resolve_tenka("scope_0")
