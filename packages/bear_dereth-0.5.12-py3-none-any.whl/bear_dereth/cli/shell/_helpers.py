from __future__ import annotations

import subprocess
from subprocess import CompletedProcess
from typing import TYPE_CHECKING

from funcy_bear.constants import ExitCode

if TYPE_CHECKING:
    from collections.abc import Sequence

    from _typeshed import StrOrBytesPath

    _CMD = StrOrBytesPath | Sequence[StrOrBytesPath]

SENTINEL_VALUE = -999


class FancyCompletedProcess(CompletedProcess[str]):
    def __init__(
        self,
        args: _CMD,
        returncode: int,
        stdout: str | None = None,
        stderr: str | None = None,
    ) -> None:
        """Initialize with custom attributes for better readability"""
        super().__init__(args=args, returncode=returncode, stdout=stdout, stderr=stderr)

    def __repr__(self) -> str:
        """Custom representation for better readability"""
        args: list[str] = [
            f"args={self.args!r}",
            f"returncode={self.returncode!r}",
            f"exit_message={self.exit_message!r}",
            f"stdout={self.stdout!r}" if self.stdout is not None else "",
            f"stderr={self.stderr!r}" if self.stderr is not None else "",
        ]
        return f"{type(self).__name__}({', '.join(filter(None, args))})"

    @property
    def exit_message(self) -> str:
        """Get a human-readable message for the exit code"""
        return ExitCode(self.returncode).text

    def __bool__(self) -> bool:
        """Helps us to know if this a sentinel value or an actual result"""
        return self.returncode != SENTINEL_VALUE


NOT_SET: FancyCompletedProcess = FancyCompletedProcess(args=[], returncode=SENTINEL_VALUE, stdout=None, stderr=None)

PIPE = -1
STDOUT = -2
DEVNULL = -3


def subprocess_run(
    *popenargs,
    input: str | bytes | None = None,  # noqa: A002
    capture_output: bool = False,
    timeout: float | None = None,
    check: bool = False,
    **kwargs,
) -> FancyCompletedProcess:
    if input is not None:
        if kwargs.get("stdin") is not None:
            raise ValueError("stdin and input arguments may not both be used.")
        kwargs["stdin"] = PIPE

    if capture_output:
        if kwargs.get("stdout") is not None or kwargs.get("stderr") is not None:
            raise ValueError("stdout and stderr arguments may not be used with capture_output.")
        kwargs["stdout"] = PIPE
        kwargs["stderr"] = PIPE

    with subprocess.Popen(*popenargs, **kwargs) as process:  # noqa: S603
        try:
            stdout, stderr = process.communicate(input, timeout=timeout)  # ty:ignore[invalid-argument-type]
        except subprocess.TimeoutExpired:
            process.kill()
            process.wait()
            raise
        except:  # Including KeyboardInterrupt, communicate handled that.
            process.kill()
            # We don't call process.wait() as .__exit__ does that for us.
            raise
        retcode: int = process.returncode
        if check and retcode:
            raise subprocess.CalledProcessError(retcode, process.args, output=stdout, stderr=stderr)
    return FancyCompletedProcess(process.args, retcode, stdout, stderr)
