from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager, contextmanager
from pathlib import Path
import shlex
from typing import TYPE_CHECKING, Self, override

from bear_dereth.cli.shells import DEFAULT_SHELL

from ._helpers import NOT_SET, FancyCompletedProcess, subprocess_run

if TYPE_CHECKING:
    from asyncio.subprocess import Process
    from collections.abc import AsyncGenerator, Callable, Generator


class SimpleShellSession:
    """Simple shell session for running commands"""

    def __init__(
        self,
        env: dict[str, str] | None = None,
        cwd: Path | str | None = None,
        shell: str = DEFAULT_SHELL,
        use_shell: bool = True,
    ) -> None:
        self.shell: str = shell
        self.cwd: Path = Path.cwd() if cwd is None else Path(cwd)
        self.env: dict[str, str] = env or {}
        self.use_shell: bool = use_shell
        self.result: FancyCompletedProcess[str] = NOT_SET

    def run(self, command: str, **kwargs) -> FancyCompletedProcess[str]:
        """Run a command and return the result"""
        self.result = subprocess_run(
            command if self.use_shell else shlex.split(command),
            cwd=self.cwd,
            env=self.env or None,
            shell=self.use_shell,
            capture_output=True,
            text=True,
            check=False,
            **kwargs,
        )
        return self.result

    @property
    def success(self) -> bool:
        """Return whether the last command succeeded"""
        return self.result.returncode == 0

    @property
    def returncode(self) -> int:
        """Return the return code of the last command"""
        return self.result.returncode

    @property
    def stdout(self) -> str:
        """Return the standard output of the last command"""
        return self.result.stdout.strip() if self.result.stdout else ""

    @property
    def stderr(self) -> str:
        """Return the standard error of the last command"""
        return self.result.stderr.strip() if self.result.stderr else ""

    @property
    def pretty_result(self) -> str:
        """Return a formatted string of the command result"""
        return (
            f"Command: {self.result.args}\n"
            f"Return Code: {self.result.returncode}\n"
            f"Standard Output: {self.stdout}\n"
            f"Standard Error: {self.stderr}\n"
        )

    def exit(self) -> None:
        """Exit the shell session, clearing state"""
        self.result = NOT_SET

    def __bool__(self) -> bool:
        """Return True if a command was successfully executed, False if not executed or failed"""
        return self.result == 0

    def __enter__(self) -> Self:
        """Enter the context manager"""
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        """Exit the context manager"""
        self.exit()


class AsyncShellSession(SimpleShellSession):
    """Async shell session with streaming support"""

    def __init__(
        self,
        env: dict[str, str] | None = None,
        cwd: str | None = None,
        shell: str = DEFAULT_SHELL,
        use_shell: bool = True,
    ) -> None:
        super().__init__(env=env, cwd=cwd, shell=shell, use_shell=use_shell)
        self.process: Process | None = None
        self._callbacks: list[Callable[[FancyCompletedProcess[str]], None]] = []

    @override
    async def run(self, command: str, **kwargs) -> Process:
        """Run a command asynchronously and return the process for streaming"""
        if self.use_shell:
            self.process = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.cwd,
                env=self.env or None,
                **kwargs,
            )
        else:
            args = shlex.split(command)
            self.process = await asyncio.create_subprocess_exec(
                *args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.cwd,
                env=self.env or None,
                **kwargs,
            )
        return self.process

    async def wait(self, stdin: str = "") -> FancyCompletedProcess[str]:
        """Wait for process to complete and return result"""
        if self.process is None:
            raise ValueError("No process has been started yet")

        input_bytes: bytes | None = stdin.encode("utf-8") if stdin else None
        stdout, stderr = await self.process.communicate(input=input_bytes)

        self.result = FancyCompletedProcess(
            args=str(self.process.pid),
            returncode=self.process.returncode or 0,
            stdout=stdout.decode() if stdout else "",
            stderr=stderr.decode() if stderr else "",
        )

        for callback in self._callbacks:
            callback(self.result)

        self.process = None
        self._callbacks.clear()

        return self.result

    async def stream_stdout(self) -> AsyncGenerator[str]:
        """Stream stdout line by line as it comes"""
        if self.process is None or self.process.stdout is None:
            raise ValueError("No process or stdout available")

        while True:
            line = await self.process.stdout.readline()
            if not line:
                break
            yield line.decode("utf-8").rstrip("\n")

    async def stream_stderr(self) -> AsyncGenerator[str]:
        """Stream stderr line by line as it comes"""
        if self.process is None or self.process.stderr is None:
            raise ValueError("No process or stderr available")

        while True:
            line = await self.process.stderr.readline()
            if not line:
                break
            yield line.decode("utf-8").rstrip("\n")

    def on_completion(self, callback: Callable[[FancyCompletedProcess[str]], None]) -> None:
        """Add callback for when process completes"""
        self._callbacks.append(callback)

    @property
    def is_running(self) -> bool:
        """Check if process is still running"""
        return self.process is not None and self.process.returncode is None


@contextmanager
def shell_session(shell: str = DEFAULT_SHELL, **kwargs) -> Generator[SimpleShellSession]:
    """Context manager for simple shell sessions"""
    session = SimpleShellSession(shell=shell, **kwargs)
    try:
        yield session
    finally:
        session.exit()


@asynccontextmanager
async def async_shell_session(shell: str = DEFAULT_SHELL, **kwargs) -> AsyncGenerator[AsyncShellSession]:
    """Asynchronous context manager for shell sessions"""
    session = AsyncShellSession(shell=shell, **kwargs)
    try:
        yield session
    finally:
        session.exit()
