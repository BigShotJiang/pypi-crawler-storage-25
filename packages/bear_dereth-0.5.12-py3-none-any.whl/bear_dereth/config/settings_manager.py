"""Settings Manager using BearBase backend."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime
from functools import partial
import sys
from typing import TYPE_CHECKING, Any, Literal, Self, cast

from bear_epoch_time import EpochTimestamp
from pydantic import BaseModel
from sqlalchemy.orm import Mapped, mapped_column

from bear_shelf.database.base_manager import BearShelfDB
from bear_shelf.database.schemas import DatabaseConfig
from bear_shelf.datastore.storage._common import StorageChoices  # noqa: TC001
from funcy_bear.typing_stuffs import parse_bool, str_to_type

from .settings_path import derive_settings_path

if TYPE_CHECKING:
    from collections.abc import Generator, Iterator
    from pathlib import Path

    from bear_shelf.datastore.database import BearBase
    from bear_shelf.dialect import BearShelfDialect

Base = BearShelfDB.get_base()


class Settings(Base):
    """SQLAlchemy model for settings storage."""

    __tablename__ = "settings"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True, default=0)
    key: Mapped[str] = mapped_column(nullable=False)
    value: Mapped[str] = mapped_column(nullable=False, default="")
    type: Mapped[str] = mapped_column(nullable=False, default="str")


class SettingsDB:
    """Database manager for settings storage."""

    def __init__(self, config: DatabaseConfig, **kwargs) -> None:
        """Initialize the SettingsDB with default parameters."""
        self._internal: BearShelfDB[Settings] = BearShelfDB(
            database_config=config,
            engine_create=True,
            **kwargs,
        )

    def create_tables(self) -> None:
        """Create the settings table."""
        self._internal.create_tables()

    @property
    def dialect(self) -> BearShelfDialect:
        """Get the database dialect."""
        return cast("BearShelfDialect", self._internal.engine.dialect)

    @property
    def dialect_base(self) -> BearBase:
        """Get the BearBase associated with the dialect."""
        return self.dialect.base


class DefaultSettings(BaseModel):
    """Default settings schema."""

    default_name: str = "settings"
    default_table: type[Settings] = Settings
    storage_type: StorageChoices = "toml"


SERIALIZED_MAP: dict[str, type] = {"epochtimestamp": int, "datetime": str}
DESERIALIZED_MAP: dict[str, type] = {"EpochTimestamp": EpochTimestamp, "datetime": datetime}
DEFAULT_EXEMPT: frozenset[str] = frozenset({"memory", "default"})
type Operation = Literal["serialize", "deserialize"]


class BearSettings:
    """Settings manager backed by BearBase instead of temp storage."""

    __slots__: tuple = (
        "_config",
        "_db",
        "_db_factory",
        "_default_table",
        "_settings",
        "_storage_type",
        "file_path",
        "name",
    )
    _default_settings: type[DefaultSettings] = DefaultSettings

    def __init__(
        self,
        name: str,
        file_name: str | None = None,
        path: Path | str | None = None,
        storage: StorageChoices = "toml",
        enable_wal: bool = False,
        config: DatabaseConfig | None = None,
        **kwargs,
    ) -> None:
        """Initialize BearBase-backed settings manager.

        Args:
            name: Name of the settings
            file_name: Optional specific file name
            path: Optional path to settings file
            storage (StorageChoices): Storage backend type
            enable_wal: Enable Write-Ahead Logging (default: False)
        """
        self.name: str = name
        self._settings = self._default_settings()
        self._storage_type = storage or self._settings.storage_type
        self.file_path: Path = derive_settings_path(name, file_name, path).full_path
        self._config: DatabaseConfig = config or DatabaseConfig(name=str(self.file_path), scheme="bearshelf")
        self._db_factory: partial[SettingsDB] = partial(
            SettingsDB,
            config=self._config,
            enable_wal=enable_wal,
            **kwargs,
        )
        self._db: SettingsDB | None = None

    @property
    def db(self) -> SettingsDB:
        """Get or create the database instance."""
        if self._db is None:
            self._db = self._db_factory()
            self._db.create_tables()
        return self._db

    @property
    def closed(self) -> bool:
        """Check if database is closed."""
        return self._db is None

    def type_parsing(self, value: Any, value_type: str, op: Operation = "deserialize") -> Any:
        """Parse value to the specified type."""
        if value_type == "NoneType":
            return None
        if value_type == "bool":
            return parse_bool(value)
        typing: Any = str_to_type(value_type, custom_map=SERIALIZED_MAP if op == "serialize" else DESERIALIZED_MAP)
        if typing is Any:
            typing = str
        try:
            return typing(value)
        except Exception:
            return value

    def get[T](self, key: str, default: Any = None, t_as: type[T] | None = None) -> T:
        """Get a setting value."""
        db: BearShelfDB[Settings] = self.db._internal
        with db.open_session(remove=True) as session:
            record: Settings | None = session.query(Settings).filter(Settings.key == key).first()
            if record:
                value: str = record.value
                value_type: str = record.type
                result = self.type_parsing(value, value_type, op="deserialize")
                if t_as is not None:
                    result = t_as(result)  # pyright: ignore[reportCallIssue]
                return result
        return default

    def set(self, key: str, value: Any, t: str | None = None) -> None:
        """Set a setting value."""
        self.upsert(key, value, t=t)

    def upsert(self, key: str, value: Any, t: str | None = None) -> None:
        """Insert or update a setting value."""
        db: BearShelfDB[Settings] = self.db._internal
        with db.open_session() as session:
            record: Settings | None = session.query(Settings).filter_by(key=key).first()
            if record is not None:
                record.value = value
            else:
                value_type: str = t or type(value).__name__
                value = self.type_parsing(value, value_type, op="serialize")
                session.add(Settings(key=key, value=value, type=value_type))

    def has(self, key: str) -> bool:
        """Check if setting exists."""
        return self.get(key) is not None

    def keys(self) -> list[str]:
        """Get all setting keys."""
        db: BearShelfDB[Settings] = self.db._internal
        with db.open_session(remove=True) as session:
            records: list[Settings] = session.query(Settings).all()
            return [record.key for record in records]

    def values(self) -> list[Any]:
        """Get all setting values."""
        db: BearShelfDB[Settings] = self.db._internal
        with db.open_session(remove=True) as session:
            records: list[Settings] = session.query(Settings).all()
            return [self.type_parsing(record.value, record.type, op="deserialize") for record in records]

    def items(self) -> list[tuple[str, Any]]:
        """Get all key-value pairs."""
        db: BearShelfDB[Settings] = self.db._internal
        with db.open_session(remove=True) as session:
            records: list[Settings] = session.query(Settings).all()
            return [(record.key, self.type_parsing(record.value, record.type, op="deserialize")) for record in records]

    def close(self) -> None:
        """Close the database."""
        if self._db is not None and not sys.is_finalizing():
            db: BearShelfDB[Settings] = self._db._internal
            db.close()
            self._db = None

    def __del__(self) -> None:
        if sys.meta_path is not None:
            self.close()

    @property
    def _class_name(self) -> str:
        return self.__class__.__name__

    def __getattr__(self, key: str) -> Any:
        """Handle dot notation access for settings."""
        if key in self.__slots__:
            raise AttributeError(f"'{key}' not initialized")
        if key.startswith("_"):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{key}'")
        return self.get(key)

    def __setattr__(self, key: str, value: Any) -> None:
        """Handle dot notation assignment for settings."""
        if key in self.__slots__:
            object.__setattr__(self, key, value)
            return
        self.set(key=key, value=value)

    def __getitem__(self, key: str) -> Any:
        return self.get(key)

    def __setitem__(self, key: str, value: Any) -> None:
        self.set(key, value)

    def __iter__(self) -> Iterator[str]:
        return iter(self.keys())

    def __contains__(self, key: str) -> bool:
        return self.has(key)

    def __len__(self) -> int:
        return len(self.keys())

    def __bool__(self) -> bool:
        return not self.closed and len(self) > 0

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"<{self._class_name} name='{self.name}'>"

    def __str__(self) -> str:
        return f"{self._class_name} for '{self.name}' with {len(self)} settings."


@contextmanager
def settings(
    name: str,
    file_name: str | None = None,
    path: str | Path | None = None,
    **kwargs,
) -> Generator[BearSettings]:
    """Context manager for SettingsManager.

    Args:
        name: Name of the settings
        file_name: Optional specific file name
        path: Optional path to settings file
        **kwargs: Additional arguments for BearSettings
    """
    sm: BearSettings = BearSettings(name, file_name=file_name, path=path, **kwargs)
    try:
        yield sm
    finally:
        sm.close()


class SettingsManager(BearSettings):
    """Alias for BearSettings."""


__all__ = ["BearSettings", "SettingsManager", "settings"]
