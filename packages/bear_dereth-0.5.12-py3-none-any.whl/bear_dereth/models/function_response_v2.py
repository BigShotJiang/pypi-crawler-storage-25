"""Simplified Function Response Class for handling function call results."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from subprocess import CompletedProcess
from typing import Any, Self

_EMPTY: tuple = (None, [], {}, "")


@dataclass(slots=True)
class FunctionResponse:
    """Represents the result of a function call: success, content, errors, sub-tasks."""

    name: str | None = None
    returncode: int = 0
    content: list[str] = field(default_factory=list)
    error: list[str] = field(default_factory=list)
    extra: dict[str, Any] = field(default_factory=dict)
    sub_tasks: dict[str, dict[str, Any]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.name is not None:
            self.name = str(self.name).lower().replace(" ", "_")

    @property
    def success(self) -> bool:
        """True when returncode is 0 and there are no errors."""
        return self.returncode == 0 and not self.error

    @classmethod
    def from_process(cls, process: CompletedProcess[str], **kwargs) -> Self:
        """Build a FunctionResponse from a subprocess CompletedProcess."""
        rc: int = process.returncode or 0
        out: str = (process.stdout or "").strip()
        err: str = (process.stderr or "").strip()
        # Some processes write success output to stderr — flip on rc=0 + empty stdout
        if rc == 0 and not out and err:
            out, err = err, ""
        content: list[str] = [out] if out else []
        error: list[str] = [err] if err else []
        return cls(returncode=rc, content=content, error=error, **kwargs)

    def _append(self, target: list[str], items: str | list[str], prefix: str | None = None) -> None:
        """Append non-empty strings to target, optionally prefixed with 'prefix: '."""
        seq: list[str] = [items] if isinstance(items, str) else items
        for item in seq:
            if not item:
                continue
            target.append(f"{prefix}: {item}" if prefix else item)

    def _absorb(self, other: FunctionResponse) -> None:
        """Merge another FunctionResponse's content/error/extra into this one."""
        self._append(self.content, other.content, prefix=other.name)
        self._append(self.error, other.error, prefix=other.name)
        self.extra.update(other.extra)

    def _ingest_content(self, content: str | list[str] | CompletedProcess[str] | FunctionResponse) -> None:
        """Dispatch content to the right handler based on its type.

        Behavior expected:
          - FunctionResponse  -> self._absorb(content)
          - CompletedProcess  -> append stdout to self.content, stderr to self.error,
                                 and set self.returncode = content.returncode
          - str | list[str]   -> self._append(self.content, content)
          - anything else     -> ignore (return None)
        """
        if isinstance(content, FunctionResponse):
            self._absorb(content)
        elif isinstance(content, CompletedProcess):
            self._absorb(self.from_process(content))
            self.returncode = content.returncode or 0
        elif isinstance(content, (str, list)):
            self._append(self.content, content)

    def add(
        self,
        content: str | list[str] | CompletedProcess[str] | FunctionResponse | None = None,
        error: str | list[str] | None = None,
        returncode: int = 0,
        extra: dict[str, Any] | None = None,
    ) -> Self:
        """Append content/error/extra to this response. Returns self for chaining."""
        if returncode != 0:
            self.returncode = returncode
        if content is not None:
            self._ingest_content(content)
        if error is not None:
            self._append(self.error, error)
        if extra:
            self.extra.update(extra)
        return self

    def successful(
        self,
        content: str | list[str] | CompletedProcess[str] | FunctionResponse,
        error: str | list[str] | None = None,
        returncode: int = 0,
        **kwargs,
    ) -> Self:
        """Mark response as successful with optional content/error."""
        return self.add(content=content, error=error, returncode=returncode, **kwargs)

    def fail(
        self,
        content: str | list[str] | CompletedProcess[str] | None = None,
        error: str | list[str] | None = None,
        **kwargs,
    ) -> Self:
        """Mark response as failed (returncode=1) with optional content/error."""
        return self.add(content=content, error=error, returncode=1, **kwargs)

    def sub_task(
        self,
        name: str | None = None,
        content: str | list[str] | None = None,
        error: str | list[str] | None = None,
        extra: dict[str, Any] | None = None,
        returncode: int = 0,
    ) -> Self:
        """Create a sub-task FunctionResponse, register it, and absorb its output."""
        sub_name: str = name or f"sub_task_{len(self.sub_tasks) + 1}"
        sub: FunctionResponse = FunctionResponse(name=sub_name)
        sub.add(content=content, error=error, returncode=returncode, extra=extra)
        self.sub_tasks[sub_name] = sub.to_dict()
        return self.add(content=sub)

    def done(self) -> Self:
        """No-op terminator for chained calls. Returns self."""
        return self

    def to_dict(self, exclude: set[str] | None = None) -> dict[str, Any]:
        """Dump to a dict, flatten `extra` into top-level keys, drop empty values."""
        excl: set[str] = exclude or set()
        dumped: dict[str, Any] = {k: v for k, v in asdict(self).items() if k not in excl}
        dumped["success"] = self.success
        extra: dict[str, Any] = dumped.pop("extra", {}) or {}
        for k, v in extra.items():
            if k not in excl and v not in _EMPTY:
                dumped[k] = v
        return {k: v for k, v in dumped.items() if v not in _EMPTY}

    def __repr__(self) -> str:
        parts: dict[str, Any] = {
            "name": self.name,
            "content": ", ".join(self.content) if self.content else None,
            "error": ", ".join(self.error) if self.error else None,
            "success": self.success,
            "returncode": self.returncode if self.returncode != 0 else None,
            "extra": self.extra or None,
            "sub_tasks": self.sub_tasks or None,
        }
        return f"FunctionResponse({', '.join(f'{k}={v!r}' for k, v in parts.items() if v is not None)})"

    __str__ = __repr__
