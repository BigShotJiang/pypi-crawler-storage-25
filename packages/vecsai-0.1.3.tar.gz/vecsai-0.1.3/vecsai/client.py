import requests
import json
import os
from typing import Optional, List, Dict, Any, Union


class VecsaiError(Exception):
    """Vecsai API hatası."""

    def __init__(self, status_code: int, message: str, response: Optional[requests.Response] = None):
        self.status_code = status_code
        self.message = message
        self.response = response
        super().__init__(f"[{status_code}] {message}")


class Collection:
    """
    Bir koleksiyona bağlı işlemleri kolayca yapmak için yardımcı sınıf.

    Kullanım:
        client = VecsaiClient()
        col = client.collection("movies")
        col.add({"title": "Inception", "rating": 8.8})
        results = col.search(q="inception", query_by="title")
    """

    def __init__(self, client: "VecsaiClient", name: str):
        self._client = client
        self.name = name

    def get(self) -> dict:
        """Koleksiyon detayını döner."""
        return self._client.get_collection(self.name)

    def delete(self) -> dict:
        """Koleksiyonu siler."""
        return self._client.delete_collection(self.name)

    # ── Document CRUD ──────────────────────────────────────────

    def add(self, document: dict) -> dict:
        """Tekil doküman ekler."""
        return self._client.create_document(self.name, document)

    def get_document(self, doc_id: str) -> dict:
        """ID ile doküman getirir."""
        return self._client.get_document(self.name, doc_id)

    def update_document(self, doc_id: str, updates: dict) -> dict:
        """Dokümanı kısmi günceller."""
        return self._client.update_document(self.name, doc_id, updates)

    def delete_document(self, doc_id: str) -> dict:
        """Tekil dokümanı siler."""
        return self._client.delete_document(self.name, doc_id)

    def delete_documents(self, filter_by: str) -> dict:
        """Filtreye uyan dokümanları topluca siler."""
        return self._client.delete_documents_by_filter(self.name, filter_by)

    # ── Bulk ───────────────────────────────────────────────────

    def import_documents(self, documents: List[dict], action: str = "create") -> list:
        """JSONL formatında toplu import."""
        return self._client.import_documents(self.name, documents, action=action)

    def import_jsonl(self, jsonl_str: str, action: str = "create") -> list:
        """Ham JSONL string ile toplu import."""
        return self._client.import_jsonl(self.name, jsonl_str, action=action)

    def upload(
        self,
        file_path: str,
        action: str = "create",
        format: str = "auto",
        sheet: Optional[str] = None,
        show_progress: Optional[bool] = None,
    ) -> dict:
        """CSV/JSON/JSONL/Excel dosyası yükler (arka plan işlemi)."""
        return self._client.upload_documents(
            self.name,
            file_path,
            action=action,
            format=format,
            sheet=sheet,
            show_progress=show_progress,
        )

    def export(self) -> str:
        """Tüm dokümanları JSONL formatında döner."""
        return self._client.export_documents(self.name)

    # ── Search ─────────────────────────────────────────────────

    def search(self, **kwargs) -> dict:
        """Arama yapar. Parametreler için VecsaiClient.search'e bakınız."""
        return self._client.search(self.name, **kwargs)

    def vector_search(self, **kwargs) -> dict:
        """Vektör araması yapar. Parametreler için VecsaiClient.vector_search'e bakınız."""
        return self._client.vector_search(self.name, **kwargs)

    def __repr__(self) -> str:
        return f"Collection('{self.name}')"


class SchemaBuilder:
    """
    Koleksiyon şeması oluşturmak için yardımcı builder.

    Kullanım:
        schema = (
            SchemaBuilder("movies")
            .field("title", "string", locale="tr")
            .field("rating", "float", sort=True)
            .field("genres", "string", facet=True)
            .vector_field("embedding", dim=768, model="nomic-embed-text-v2-moe",
                          source_fields=["title", "overview"])
            .sorting_field("rating")
            .vector_index("hnsw")
            .build()
        )
    """

    def __init__(self, name: str):
        self._schema: Dict[str, Any] = {"name": name, "fields": []}

    def field(
        self,
        name: str,
        type: str,
        facet: bool = False,
        sort: bool = False,
        index: bool = False,
        locale: Optional[str] = None,
    ) -> "SchemaBuilder":
        """Şemaya alan ekler."""
        f: Dict[str, Any] = {"name": name, "type": type}
        if facet:
            f["facet"] = True
        if sort:
            f["sort"] = True
        if index:
            f["index"] = True
        if locale:
            f["locale"] = locale
        self._schema["fields"].append(f)
        return self

    def vector_field(
        self,
        name: str,
        dim: int,
        model: Optional[str] = None,
        source_fields: Optional[List[str]] = None,
        index: bool = True,
    ) -> "SchemaBuilder":
        """Şemaya vektör alanı ekler."""
        f: Dict[str, Any] = {
            "name": name,
            "type": "vector",
            "vector_dim": dim,
            "index": index,
        }
        if model:
            f["vector_model"] = model
        if source_fields:
            f["vector_source_fields"] = source_fields
        self._schema["fields"].append(f)
        return self

    def sorting_field(self, field_name: str) -> "SchemaBuilder":
        """Varsayılan sıralama alanını belirler."""
        self._schema["default_sorting_field"] = field_name
        return self

    def vector_index(self, impl: str) -> "SchemaBuilder":
        """Vektör index implementasyonunu belirler (ör: 'hnsw', 'brute')."""
        self._schema["vector_index_impl"] = impl
        return self

    def build(self) -> dict:
        """Şemayı dict olarak döner."""
        return dict(self._schema)


class VecsaiClient:
    """
    vecsai-db sunucusuna bağlanan Python istemcisi.

    Tüm API endpoint'lerini destekler:
    health, metrics, koleksiyon CRUD, doküman CRUD,
    toplu import/export, upload, arama (text + vektör), job takibi.
    """

    def __init__(
        self,
        host: str = "localhost",
        port: int = 8137,
        timeout: int = 30,
        raise_on_error: bool = True,
    ):
        self.base_url = f"http://{host}:{port}"
        self.timeout = timeout
        self.raise_on_error = raise_on_error
        self._session = requests.Session()
        self._session.headers.update({"Content-Type": "application/json"})

    # ── Yardımcılar ────────────────────────────────────────────

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _handle(self, resp: requests.Response) -> Any:
        """Yanıtı işler; hata durumunda VecsaiError fırlatır."""
        if self.raise_on_error and resp.status_code >= 400:
            try:
                body = resp.json()
                msg = body.get("message") or body.get("error") or str(body)
            except Exception:
                msg = resp.text
            raise VecsaiError(resp.status_code, msg, response=resp)
        try:
            return resp.json()
        except Exception:
            return resp.text

    def _get(self, path: str, params: Optional[dict] = None, **kwargs) -> Any:
        resp = self._session.get(self._url(path), params=params, timeout=self.timeout, **kwargs)
        return self._handle(resp)

    def _post(self, path: str, json: Optional[Any] = None, **kwargs) -> Any:
        resp = self._session.post(self._url(path), json=json, timeout=self.timeout, **kwargs)
        return self._handle(resp)

    def _patch(self, path: str, json: Optional[Any] = None, **kwargs) -> Any:
        resp = self._session.patch(self._url(path), json=json, timeout=self.timeout, **kwargs)
        return self._handle(resp)

    def _delete(self, path: str, params: Optional[dict] = None, **kwargs) -> Any:
        resp = self._session.delete(self._url(path), params=params, timeout=self.timeout, **kwargs)
        return self._handle(resp)

    def _raw_post(self, path: str, **kwargs) -> Any:
        """Content-Type header'ı olmadan POST (multipart / raw body)."""
        headers = {k: v for k, v in self._session.headers.items() if k.lower() != "content-type"}
        resp = requests.post(self._url(path), headers=headers, timeout=self.timeout, **kwargs)
        return self._handle(resp)

    # ── Health & Metrics ───────────────────────────────────────

    def health(self) -> dict:
        """
        Sunucunun çalışır durumda olup olmadığını kontrol eder.

        Returns:
            {"ok": True, "status": "healthy"}
        """
        return self._get("/health")

    def metrics(self) -> dict:
        """
        Motor metriklerini döner (koleksiyon sayıları vb.).

        Returns:
            dict — engine.Metrics çıktısı
        """
        return self._get("/metrics")

    # ── Collections ────────────────────────────────────────────

    def create_collection(self, schema: Union[dict, "SchemaBuilder"]) -> dict:
        """
        Yeni koleksiyon oluşturur.

        Args:
            schema: Koleksiyon şeması (dict veya SchemaBuilder).

        Returns:
            Oluşturulan koleksiyonun şeması.

        Raises:
            VecsaiError: 400 (geçersiz şema) veya 409 (zaten mevcut).
        """
        if isinstance(schema, SchemaBuilder):
            schema = schema.build()
        return self._post("/collections", json=schema)

    def list_collections(self) -> list:
        """
        Mevcut koleksiyonların listesini döner.

        Returns:
            Koleksiyon şemalarının listesi.
        """
        return self._get("/collections")

    def get_collection(self, name: str) -> dict:
        """
        Koleksiyon detayını döner.

        Args:
            name: Koleksiyon adı.

        Returns:
            {"name", "fields", "default_sorting_field", "num_documents"}

        Raises:
            VecsaiError: 404 koleksiyon bulunamadıysa.
        """
        return self._get(f"/collections/{name}")

    def delete_collection(self, name: str) -> dict:
        """
        Koleksiyonu siler.

        Args:
            name: Koleksiyon adı.

        Returns:
            {"name": "..."}

        Raises:
            VecsaiError: 404 koleksiyon bulunamadıysa.
        """
        return self._delete(f"/collections/{name}")

    def collection(self, name: str) -> Collection:
        """
        Koleksiyona bağlı işlemler için Collection nesnesi döner.

        Args:
            name: Koleksiyon adı.

        Returns:
            Collection nesnesi.
        """
        return Collection(self, name)

    # ── Document CRUD ──────────────────────────────────────────

    def create_document(self, collection_name: str, document: dict) -> dict:
        """
        Tekil doküman oluşturur.

        Args:
            collection_name: Koleksiyon adı.
            document: Doküman verisi. 'id' verilmezse sunucu üretir.

        Returns:
            Oluşturulan doküman.

        Raises:
            VecsaiError: 400/404/409
        """
        return self._post(f"/collections/{collection_name}/documents", json=document)

    def get_document(self, collection_name: str, doc_id: str) -> dict:
        """
        ID ile doküman getirir.

        Args:
            collection_name: Koleksiyon adı.
            doc_id: Doküman ID.

        Returns:
            Doküman verisi.

        Raises:
            VecsaiError: 404 doküman bulunamadıysa.
        """
        return self._get(f"/collections/{collection_name}/documents/{doc_id}")

    def update_document(self, collection_name: str, doc_id: str, updates: dict) -> dict:
        """
        Dokümanı kısmi günceller (PATCH).

        Args:
            collection_name: Koleksiyon adı.
            doc_id: Doküman ID.
            updates: Güncellenecek alanlar.

        Returns:
            Güncellenmiş doküman.
        """
        return self._patch(f"/collections/{collection_name}/documents/{doc_id}", json=updates)

    def delete_document(self, collection_name: str, doc_id: str) -> dict:
        """
        Tekil dokümanı siler.

        Args:
            collection_name: Koleksiyon adı.
            doc_id: Doküman ID.

        Returns:
            {"id": "..."}
        """
        return self._delete(f"/collections/{collection_name}/documents/{doc_id}")

    def delete_documents_by_filter(self, collection_name: str, filter_by: str) -> dict:
        """
        Filtreye uyan dokümanları topluca siler.

        Args:
            collection_name: Koleksiyon adı.
            filter_by: Filtre ifadesi.

        Returns:
            {"num_deleted": N}

        Raises:
            VecsaiError: 400/404
        """
        return self._delete(
            f"/collections/{collection_name}/documents",
            params={"filter_by": filter_by},
        )

    # ── Import / Export ────────────────────────────────────────

    def import_documents(
        self,
        collection_name: str,
        documents: List[dict],
        action: str = "create",
    ) -> list:
        """
        Dokümanları JSONL formatında toplu import eder.

        Args:
            collection_name: Koleksiyon adı.
            documents: Doküman listesi.
            action: 'create' | 'upsert' | 'update' (varsayılan: 'create').

        Returns:
            Satır bazlı sonuç listesi (success/error).
        """
        jsonl = "\n".join(json.dumps(doc, ensure_ascii=False) for doc in documents)
        return self.import_jsonl(collection_name, jsonl, action=action)

    def import_jsonl(
        self,
        collection_name: str,
        jsonl_str: str,
        action: str = "create",
    ) -> list:
        """
        Ham JSONL string ile toplu import.

        Args:
            collection_name: Koleksiyon adı.
            jsonl_str: Newline-delimited JSON string.
            action: 'create' | 'upsert' | 'update'.

        Returns:
            Satır bazlı sonuç listesi.
        """
        path = f"/collections/{collection_name}/documents/import"
        resp = requests.post(
            self._url(path),
            params={"action": action},
            data=jsonl_str.encode("utf-8"),
            headers={"Content-Type": "text/plain"},
            timeout=self.timeout,
        )
        return self._handle(resp)

    def upload_documents(
        self,
        collection_name: str,
        file_path: str,
        action: str = "create",
        format: str = "auto",
        sheet: Optional[str] = None,
        show_progress: Optional[bool] = None,
    ) -> dict:
        """
        CSV/JSON/JSONL/Excel dosyasını multipart olarak yükler.
        Sunucu arka planda import başlatır.

        Args:
            collection_name: Koleksiyon adı.
            file_path: Yüklenecek dosya yolu.
            action: 'create' | 'upsert' (varsayılan: 'create').
            format: 'auto' | 'csv' | 'json' | 'jsonl' | 'excel' (varsayılan: 'auto').
            sheet: Excel için sayfa adı/numarası (opsiyonel).
            show_progress: Loglarda ilerleme gösterimi (opsiyonel).

        Returns:
            {"message": "...", "job_id": "..."}
        """
        url = self._url(f"/collections/{collection_name}/documents/upload")
        params: Dict[str, Any] = {"action": action, "format": format}
        if sheet is not None:
            params["sheet"] = sheet
        if show_progress is not None:
            params["show_progress"] = str(show_progress).lower()

        with open(file_path, "rb") as f:
            files = {"file": (os.path.basename(file_path), f)}
            resp = requests.post(url, params=params, files=files, timeout=self.timeout)

        return self._handle(resp)

    def export_documents(self, collection_name: str) -> str:
        """
        Koleksiyondaki tüm dokümanları JSONL formatında döner.

        Args:
            collection_name: Koleksiyon adı.

        Returns:
            JSONL string.
        """
        resp = self._session.get(
            self._url(f"/collections/{collection_name}/documents/export"),
            timeout=self.timeout,
            stream=True,
        )
        if self.raise_on_error and resp.status_code >= 400:
            return self._handle(resp)
        return resp.text

    # ── Search ─────────────────────────────────────────────────

    def search(
        self,
        collection_name: str,
        q: str = "*",
        query_by: Optional[str] = None,
        query_by_weights: Optional[str] = None,
        filter_by: Optional[str] = None,
        sort_by: Optional[str] = None,
        facet_by: Optional[str] = None,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
        highlight_fields: Optional[str] = None,
        highlight_start_tag: Optional[str] = None,
        highlight_end_tag: Optional[str] = None,
    ) -> dict:
        """
        Full-text arama yapar.

        Args:
            collection_name: Koleksiyon adı.
            q: Sorgu metni (varsayılan: '*' tümü).
            query_by: Aranacak alanlar, virgülle ayrılmış (ör: 'title,overview').
            query_by_weights: Alan ağırlıkları, virgülle ayrılmış.
            filter_by: Filtre ifadesi.
            sort_by: Sıralama ifadesi.
            facet_by: Facet alanları.
            page: Sayfa numarası (varsayılan: 1).
            per_page: Sayfa başına sonuç (varsayılan: 10).
            highlight_fields: Highlight yapılacak alanlar.
            highlight_start_tag: Highlight başlangıç etiketi.
            highlight_end_tag: Highlight bitiş etiketi.

        Returns:
            SearchResponse: {Found, Page, Hits, ...}
        """
        params: Dict[str, Any] = {"q": q}
        if query_by is not None:
            params["query_by"] = query_by
        if query_by_weights is not None:
            params["query_by_weights"] = query_by_weights
        if filter_by is not None:
            params["filter_by"] = filter_by
        if sort_by is not None:
            params["sort_by"] = sort_by
        if facet_by is not None:
            params["facet_by"] = facet_by
        if page is not None:
            params["page"] = page
        if per_page is not None:
            params["per_page"] = per_page
        if highlight_fields is not None:
            params["highlight_fields"] = highlight_fields
        if highlight_start_tag is not None:
            params["highlight_start_tag"] = highlight_start_tag
        if highlight_end_tag is not None:
            params["highlight_end_tag"] = highlight_end_tag

        return self._get(f"/collections/{collection_name}/documents/search", params=params)

    def vector_search(
        self,
        collection_name: str,
        q: Optional[str] = None,
        vector: Optional[List[float]] = None,
        vector_field: Optional[str] = None,
        model: Optional[str] = None,
        k: Optional[int] = None,
        filter_by: Optional[str] = None,
        page: Optional[int] = None,
        per_page: Optional[int] = None,
    ) -> dict:
        """
        Vektör araması yapar. İki yol desteklenir:

        1) embed=true — sunucu 'q' parametresini embedding'e çevirir.
        2) vector — doğrudan vektör değerleri gönderilir.

        Args:
            collection_name: Koleksiyon adı.
            q: Sorgu metni (embed=true modunda kullanılır).
            vector: Vektör değerleri listesi (doğrudan vektör araması).
            vector_field: Hangi vector alanında arama yapılacağı.
            model: Embedding modeli (opsiyonel).
            k: Kaç sonuç döneceği (varsayılan: 10).
            filter_by: Filtre ifadesi.
            page: Sayfa numarası.
            per_page: Sayfa başına sonuç.

        Returns:
            SearchResponse: {Found, Page, Hits, ...}
        """
        params: Dict[str, Any] = {}

        if vector is not None:
            # Doğrudan vektör araması
            params["vector"] = ",".join(str(v) for v in vector)
        elif q is not None:
            # Embedding üzerinden arama
            params["q"] = q
            params["embed"] = "true"
        else:
            raise ValueError("vector_search için 'q' veya 'vector' parametrelerinden biri gereklidir.")

        if vector_field is not None:
            params["vector_field"] = vector_field
        if model is not None:
            params["model"] = model
        if k is not None:
            params["k"] = k
        if filter_by is not None:
            params["filter_by"] = filter_by
        if page is not None:
            params["page"] = page
        if per_page is not None:
            params["per_page"] = per_page

        return self._get(f"/collections/{collection_name}/documents/search", params=params)

    # ── Jobs ───────────────────────────────────────────────────

    def get_job(self, job_id: str) -> dict:
        """
        Asenkron import/upload işleminin durumunu sorgular.

        Args:
            job_id: İş ID'si (upload_documents'tan dönen).

        Returns:
            {"status", "total", "processed", "imported", "failed", "errors"}
        """
        return self._get(f"/jobs/{job_id}")

    # ── Kısa yollar (geriye uyumluluk) ─────────────────────────

    def add_document(self, collection_name: str, document: dict) -> dict:
        """create_document için alias (geriye uyumluluk)."""
        return self.create_document(collection_name, document)

    def upload_csv(self, collection_name: str, file_path: str, action: str = "create") -> dict:
        """upload_documents için alias (geriye uyumluluk, sadece CSV)."""
        return self.upload_documents(collection_name, file_path, action=action, format="csv")

    def __repr__(self) -> str:
        return f"VecsaiClient('{self.base_url}')"