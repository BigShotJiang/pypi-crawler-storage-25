from .client import VecsaiClient, Collection, SchemaBuilder, VecsaiError


def client(host="localhost", port=8137, **kwargs):
	"""Kısa yol: VecsaiClient nesnesi oluşturur."""
	return VecsaiClient(host=host, port=port, **kwargs)


__all__ = [
	"VecsaiClient",
	"Collection",
	"SchemaBuilder",
	"VecsaiError",
	"client",
]
