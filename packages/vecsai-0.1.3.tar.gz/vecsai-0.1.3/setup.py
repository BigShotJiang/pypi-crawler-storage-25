from setuptools import setup, find_packages

setup(
    name="vecsai",
    version="0.1.3",
    author="Vecsai Team",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1",
    ],
    description="Vecsai: vector db for everyone",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    python_requires='>=3.7',
)