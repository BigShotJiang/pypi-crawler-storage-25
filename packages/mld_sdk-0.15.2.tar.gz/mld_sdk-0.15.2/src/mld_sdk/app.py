"""
Standalone app factory and FastAPI helpers for MLD plugins.

Provides ``create_standalone_app`` to replace the 50+ lines of boilerplate
that every plugin copies for CORS, lifespan, router mounting, and frontend
serving.  Also provides reusable building blocks (``SPAStaticFiles``,
``PluginDependency``, ``require_context``) for plugins that need more control.
"""

from __future__ import annotations

from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, Any, Generic, Optional, TypeVar, overload

if TYPE_CHECKING:
    from mld_sdk.context import PlatformContext
    from mld_sdk.plugin import AnalysisPlugin

T = TypeVar("T")


# ---------------------------------------------------------------------------
# SPAStaticFiles
# ---------------------------------------------------------------------------


class SPAStaticFiles:
    """StaticFiles subclass with SPA fallback to ``index.html``.

    When a request doesn't match a real file (e.g. ``/settings``), the SPA
    router needs ``index.html`` to be served so client-side routing can take
    over.  This class wraps ``starlette.staticfiles.StaticFiles`` and catches
    lookup failures, falling back to the root ``index.html``.

    Usage::

        from mld_sdk.app import SPAStaticFiles

        app.mount("/", SPAStaticFiles(directory="frontend/dist", html=True))
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> Any:
        from starlette.staticfiles import StaticFiles

        class _SPAStaticFiles(StaticFiles):
            async def get_response(self, path: str, scope: Any) -> Any:
                try:
                    return await super().get_response(path, scope)
                except Exception:
                    return await super().get_response("index.html", scope)

        return _SPAStaticFiles(*args, **kwargs)


# ---------------------------------------------------------------------------
# PluginDependency
# ---------------------------------------------------------------------------


class PluginDependency(Generic[T]):
    """Typed dependency container for injecting services into FastAPI routes.

    Replaces the per-router ``_service``/``set_service``/``get_service``
    boilerplate pattern used across all MLD plugins.

    Usage::

        from mld_sdk.app import PluginDependency

        # Declare at module level in your router file:
        session_dep = PluginDependency[SessionService]("SessionService")

        # In plugin initialize(), wire the service:
        session_dep.set(my_session_service)

        # In routes, use as a FastAPI dependency:
        @router.post("/upload")
        async def upload(svc: SessionService = Depends(session_dep)):
            ...

        # Or call directly:
        svc = session_dep()
    """

    def __init__(self, name: str = "service") -> None:
        self._name = name
        self._instance: T | None = None

    def set(self, instance: T) -> None:
        """Set the service instance."""
        self._instance = instance

    def reset(self) -> None:
        """Clear the service instance (useful in tests)."""
        self._instance = None

    def __call__(self) -> T:
        """Get the service instance, raising 503 if not set."""
        if self._instance is None:
            from fastapi import HTTPException, status

            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail=f"{self._name} not initialized",
            )
        return self._instance

    def __repr__(self) -> str:
        state = "set" if self._instance is not None else "empty"
        return f"PluginDependency({self._name!r}, {state})"


# ---------------------------------------------------------------------------
# require_context
# ---------------------------------------------------------------------------


def require_context(context: Optional["PlatformContext"]) -> "PlatformContext":
    """Return *context* if set, otherwise raise HTTP 503.

    Utility for routes that only work in integrated (non-standalone) mode.

    Usage::

        from mld_sdk.app import require_context

        @router.get("/experiments")
        async def list_experiments():
            ctx = require_context(plugin.context)
            repo = ctx.get_experiment_repository()
            ...
    """
    if context is None:
        from fastapi import HTTPException, status

        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Not available in standalone mode",
        )
    return context


# ---------------------------------------------------------------------------
# create_standalone_app
# ---------------------------------------------------------------------------


@overload
def create_standalone_app(
    plugin_or_cls: type["AnalysisPlugin"],
    *,
    cors: bool = ...,
    cors_origins: list[str] | None = ...,
    title: str | None = ...,
) -> Any: ...


@overload
def create_standalone_app(
    plugin_or_cls: "AnalysisPlugin",
    *,
    cors: bool = ...,
    cors_origins: list[str] | None = ...,
    title: str | None = ...,
) -> Any: ...


def create_standalone_app(
    plugin_or_cls: "type[AnalysisPlugin] | AnalysisPlugin",
    *,
    cors: bool = True,
    cors_origins: list[str] | None = None,
    title: str | None = None,
) -> Any:
    """Create a fully configured FastAPI app for running a plugin standalone.

    Handles everything plugins previously did manually:

    - Lifespan management (initialize + shutdown)
    - Subprocess isolation detection (``create_context_for_environment``)
    - CORS middleware
    - Router mounting at ``/api{routes_prefix}{sub_prefix}``
    - Frontend static file serving with SPA fallback

    Usage::

        # In your plugin module:
        from mld_sdk.app import create_standalone_app
        from my_plugin.plugin import MyPlugin

        app = create_standalone_app(MyPlugin)

        # Run with: uvicorn my_plugin.plugin:app --reload

    Or as a factory function for uvicorn::

        def create_app():
            return create_standalone_app(MyPlugin)

        # uvicorn my_plugin.plugin:create_app --factory --reload

    Args:
        plugin_or_cls: A plugin class (will be instantiated) or an instance.
        cors: Whether to add CORS middleware (default True).
        cors_origins: Allowed origins for CORS (default ``["*"]``).
        title: Override the app title (default: ``"{plugin.name} (Standalone)"``).

    Returns:
        A configured FastAPI application.
    """
    from fastapi import FastAPI

    # Accept both a class and an instance
    if isinstance(plugin_or_cls, type):
        plugin = plugin_or_cls()
    else:
        plugin = plugin_or_cls

    meta = plugin.metadata

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        from mld_sdk.remote_context import create_context_for_environment

        context = create_context_for_environment()
        await plugin.initialize(context=context)
        yield
        await plugin.shutdown()

    app = FastAPI(
        title=title or f"{meta.name} (Standalone)",
        version=meta.version,
        description=meta.description,
        lifespan=lifespan,
    )

    # CORS
    if cors:
        from fastapi.middleware.cors import CORSMiddleware

        app.add_middleware(
            CORSMiddleware,
            allow_origins=cors_origins or ["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    # Mount API routers
    prefix = meta.routes_prefix
    for router, sub_prefix in plugin.get_routers():
        app.include_router(router, prefix=f"/api{prefix}{sub_prefix}")

    # Mount frontend with SPA fallback
    frontend_dir = plugin.get_frontend_dir()
    if frontend_dir:
        app.mount(
            prefix,
            SPAStaticFiles(directory=frontend_dir, html=True),
            name="frontend",
        )

    return app
