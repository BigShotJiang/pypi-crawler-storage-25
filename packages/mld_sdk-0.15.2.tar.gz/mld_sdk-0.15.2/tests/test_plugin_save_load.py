"""Tests for AnalysisPlugin save/load convenience methods."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Optional
from unittest.mock import AsyncMock

import pytest
from mld_sdk.models import PluginMetadata
from mld_sdk.plugin import AnalysisPlugin
from mld_sdk.repositories import DesignData, PluginAnalysisResult, PluginDataRepository


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_design_data(
    experiment_id: int = 1,
    plugin_id: str = "test-plugin",
    data: dict[str, Any] | None = None,
    schema_version: str = "1.0",
) -> DesignData:
    now = datetime.now(UTC)
    return DesignData(
        id=1,
        experiment_id=experiment_id,
        plugin_id=plugin_id,
        data=data or {"key": "value"},
        schema_version=schema_version,
        created_at=now,
        updated_at=now,
    )


def _make_analysis_result(
    experiment_id: int = 1,
    plugin_id: str = "test-plugin",
    result: dict[str, Any] | None = None,
) -> PluginAnalysisResult:
    now = datetime.now(UTC)
    return PluginAnalysisResult(
        id=1,
        experiment_id=experiment_id,
        plugin_id=plugin_id,
        result=result or {"score": 0.95},
        created_at=now,
        updated_at=now,
    )


class MockPluginDataRepo:
    """Mock implementing PluginDataRepository protocol."""

    def __init__(self) -> None:
        self.save_experiment_data = AsyncMock(
            return_value=_make_design_data()
        )
        self.get_experiment_data = AsyncMock(
            return_value=_make_design_data()
        )
        self.delete_experiment_data = AsyncMock(return_value=True)
        self.save_analysis_result = AsyncMock(
            return_value=_make_analysis_result()
        )
        self.get_analysis_result = AsyncMock(
            return_value=_make_analysis_result()
        )
        self.get_analysis_results = AsyncMock(return_value=[])
        self.delete_analysis_result = AsyncMock(return_value=True)


class MockContext:
    """Minimal mock PlatformContext."""

    def __init__(self, repo: MockPluginDataRepo) -> None:
        self._repo = repo

    def get_plugin_data_repository(self) -> MockPluginDataRepo:
        return self._repo


class ConcretePlugin(AnalysisPlugin):
    """Minimal concrete plugin for testing."""

    def __init__(self, name: str = "test-plugin", schema_version: str = "1.0") -> None:
        super().__init__()
        self._name = name
        self._schema_version = schema_version

    @property
    def metadata(self) -> PluginMetadata:
        return PluginMetadata(
            name=self._name,
            version="1.0.0",
            description="Test plugin",
            analysis_type="test",
            routes_prefix="/test",
            schema_version=self._schema_version,
        )

    def get_routers(self):
        return []

    async def initialize(self, context=None):
        self._context = context

    async def shutdown(self):
        pass


class OverriddenPluginIdPlugin(ConcretePlugin):
    """Plugin that overrides plugin_id (like DRP does)."""

    @property
    def plugin_id(self) -> str:
        return "custom-plugin-id"


@pytest.fixture
def repo() -> MockPluginDataRepo:
    return MockPluginDataRepo()


@pytest.fixture
def ctx(repo: MockPluginDataRepo) -> MockContext:
    return MockContext(repo)


@pytest.fixture
async def plugin(ctx: MockContext) -> ConcretePlugin:
    p = ConcretePlugin()
    await p.initialize(ctx)
    return p


@pytest.fixture
async def standalone_plugin() -> ConcretePlugin:
    p = ConcretePlugin()
    await p.initialize(None)
    return p


# ---------------------------------------------------------------------------
# plugin_id property
# ---------------------------------------------------------------------------


class TestPluginId:
    def test_defaults_to_metadata_name(self):
        plugin = ConcretePlugin(name="my-analysis")
        assert plugin.plugin_id == "my-analysis"

    def test_overridable(self):
        plugin = OverriddenPluginIdPlugin(name="original-name")
        assert plugin.plugin_id == "custom-plugin-id"


# ---------------------------------------------------------------------------
# save_design
# ---------------------------------------------------------------------------


class TestSaveDesign:
    @pytest.mark.asyncio
    async def test_calls_repo_with_correct_args(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        data = {"layout": "grid"}
        await plugin.save_design(1, data)

        repo.save_experiment_data.assert_awaited_once_with(
            experiment_id=1,
            plugin_id="test-plugin",
            data=data,
            schema_version="1.0",
        )

    @pytest.mark.asyncio
    async def test_uses_metadata_schema_version(self, ctx: MockContext, repo: MockPluginDataRepo):
        p = ConcretePlugin(schema_version="2.0")
        await p.initialize(ctx)
        await p.save_design(1, {"x": 1})

        repo.save_experiment_data.assert_awaited_once()
        call_kwargs = repo.save_experiment_data.call_args.kwargs
        assert call_kwargs["schema_version"] == "2.0"

    @pytest.mark.asyncio
    async def test_override_schema_version(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        await plugin.save_design(1, {"x": 1}, schema_version="3.0")

        call_kwargs = repo.save_experiment_data.call_args.kwargs
        assert call_kwargs["schema_version"] == "3.0"

    @pytest.mark.asyncio
    async def test_returns_design_data(self, plugin: ConcretePlugin):
        result = await plugin.save_design(1, {"x": 1})
        assert isinstance(result, DesignData)

    @pytest.mark.asyncio
    async def test_standalone_returns_none(self, standalone_plugin: ConcretePlugin):
        result = await standalone_plugin.save_design(1, {"x": 1})
        assert result is None


# ---------------------------------------------------------------------------
# load_design
# ---------------------------------------------------------------------------


class TestLoadDesign:
    @pytest.mark.asyncio
    async def test_calls_repo(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        await plugin.load_design(1)
        repo.get_experiment_data.assert_awaited_once_with(1)

    @pytest.mark.asyncio
    async def test_returns_design_data(self, plugin: ConcretePlugin):
        result = await plugin.load_design(1)
        assert isinstance(result, DesignData)

    @pytest.mark.asyncio
    async def test_returns_none_when_not_found(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        repo.get_experiment_data.return_value = None
        result = await plugin.load_design(1)
        assert result is None

    @pytest.mark.asyncio
    async def test_standalone_returns_none(self, standalone_plugin: ConcretePlugin):
        result = await standalone_plugin.load_design(1)
        assert result is None


# ---------------------------------------------------------------------------
# save_analysis
# ---------------------------------------------------------------------------


class TestSaveAnalysis:
    @pytest.mark.asyncio
    async def test_calls_repo_with_correct_args(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        result_data = {"score": 0.95}
        await plugin.save_analysis(1, result_data)

        repo.save_analysis_result.assert_awaited_once_with(
            experiment_id=1,
            plugin_id="test-plugin",
            result=result_data,
        )

    @pytest.mark.asyncio
    async def test_uses_plugin_id(self, repo: MockPluginDataRepo, ctx: MockContext):
        p = OverriddenPluginIdPlugin()
        await p.initialize(ctx)
        await p.save_analysis(1, {"score": 1.0})

        call_kwargs = repo.save_analysis_result.call_args.kwargs
        assert call_kwargs["plugin_id"] == "custom-plugin-id"

    @pytest.mark.asyncio
    async def test_returns_analysis_result(self, plugin: ConcretePlugin):
        result = await plugin.save_analysis(1, {"score": 0.5})
        assert isinstance(result, PluginAnalysisResult)

    @pytest.mark.asyncio
    async def test_standalone_returns_none(self, standalone_plugin: ConcretePlugin):
        result = await standalone_plugin.save_analysis(1, {"score": 0.5})
        assert result is None


# ---------------------------------------------------------------------------
# load_analysis
# ---------------------------------------------------------------------------


class TestLoadAnalysis:
    @pytest.mark.asyncio
    async def test_calls_repo_with_plugin_id(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        await plugin.load_analysis(1)
        repo.get_analysis_result.assert_awaited_once_with(1, "test-plugin")

    @pytest.mark.asyncio
    async def test_uses_overridden_plugin_id(self, repo: MockPluginDataRepo, ctx: MockContext):
        p = OverriddenPluginIdPlugin()
        await p.initialize(ctx)
        await p.load_analysis(1)

        repo.get_analysis_result.assert_awaited_once_with(1, "custom-plugin-id")

    @pytest.mark.asyncio
    async def test_returns_none_when_not_found(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        repo.get_analysis_result.return_value = None
        result = await plugin.load_analysis(1)
        assert result is None

    @pytest.mark.asyncio
    async def test_standalone_returns_none(self, standalone_plugin: ConcretePlugin):
        result = await standalone_plugin.load_analysis(1)
        assert result is None


# ---------------------------------------------------------------------------
# save (combined)
# ---------------------------------------------------------------------------


class TestSaveCombined:
    @pytest.mark.asyncio
    async def test_saves_both_when_both_provided(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        design, analysis = await plugin.save(
            1, design={"layout": "grid"}, analysis={"score": 0.9}
        )
        repo.save_experiment_data.assert_awaited_once()
        repo.save_analysis_result.assert_awaited_once()
        assert isinstance(design, DesignData)
        assert isinstance(analysis, PluginAnalysisResult)

    @pytest.mark.asyncio
    async def test_saves_only_design_when_analysis_is_none(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        design, analysis = await plugin.save(1, design={"layout": "grid"})
        repo.save_experiment_data.assert_awaited_once()
        repo.save_analysis_result.assert_not_awaited()
        assert isinstance(design, DesignData)
        assert analysis is None

    @pytest.mark.asyncio
    async def test_saves_only_analysis_when_design_is_none(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        design, analysis = await plugin.save(1, analysis={"score": 0.9})
        repo.save_experiment_data.assert_not_awaited()
        repo.save_analysis_result.assert_awaited_once()
        assert design is None
        assert isinstance(analysis, PluginAnalysisResult)

    @pytest.mark.asyncio
    async def test_noop_when_neither_provided(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        design, analysis = await plugin.save(1)
        repo.save_experiment_data.assert_not_awaited()
        repo.save_analysis_result.assert_not_awaited()
        assert design is None
        assert analysis is None

    @pytest.mark.asyncio
    async def test_passes_schema_version_to_design(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        await plugin.save(1, design={"x": 1}, schema_version="5.0")
        call_kwargs = repo.save_experiment_data.call_args.kwargs
        assert call_kwargs["schema_version"] == "5.0"

    @pytest.mark.asyncio
    async def test_standalone_returns_none_tuple(self, standalone_plugin: ConcretePlugin):
        design, analysis = await standalone_plugin.save(
            1, design={"x": 1}, analysis={"y": 2}
        )
        assert design is None
        assert analysis is None


# ---------------------------------------------------------------------------
# load (combined)
# ---------------------------------------------------------------------------


class TestLoadCombined:
    @pytest.mark.asyncio
    async def test_loads_both(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        design, analysis = await plugin.load(1)
        repo.get_experiment_data.assert_awaited_once_with(1)
        repo.get_analysis_result.assert_awaited_once_with(1, "test-plugin")
        assert isinstance(design, DesignData)
        assert isinstance(analysis, PluginAnalysisResult)

    @pytest.mark.asyncio
    async def test_standalone_returns_none_tuple(self, standalone_plugin: ConcretePlugin):
        design, analysis = await standalone_plugin.load(1)
        assert design is None
        assert analysis is None


# ---------------------------------------------------------------------------
# delete_design
# ---------------------------------------------------------------------------


class TestDeleteDesign:
    @pytest.mark.asyncio
    async def test_calls_repo(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        result = await plugin.delete_design(1)
        repo.delete_experiment_data.assert_awaited_once_with(1)
        assert result is True

    @pytest.mark.asyncio
    async def test_standalone_returns_false(self, standalone_plugin: ConcretePlugin):
        result = await standalone_plugin.delete_design(1)
        assert result is False


# ---------------------------------------------------------------------------
# delete_analysis
# ---------------------------------------------------------------------------


class TestDeleteAnalysis:
    @pytest.mark.asyncio
    async def test_calls_repo_with_plugin_id(self, plugin: ConcretePlugin, repo: MockPluginDataRepo):
        result = await plugin.delete_analysis(1)
        repo.delete_analysis_result.assert_awaited_once_with(1, "test-plugin")
        assert result is True

    @pytest.mark.asyncio
    async def test_standalone_returns_false(self, standalone_plugin: ConcretePlugin):
        result = await standalone_plugin.delete_analysis(1)
        assert result is False
