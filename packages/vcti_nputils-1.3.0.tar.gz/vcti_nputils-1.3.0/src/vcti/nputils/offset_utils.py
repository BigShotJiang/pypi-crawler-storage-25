# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Offset and position utilities for counts-based data layouts.

Currently exposes :func:`position_array` for converting a 1-D count
array to a cumulative offset array (CSR-style). Other offset-related
helpers (inverse offsets-to-counts, segment-boundary masks, etc.) can
live here as they're added.
"""

import numpy as np


def position_array(counts: np.ndarray, dtype: np.dtype | None = None) -> np.ndarray:
    """Convert count array to cumulative position (offset) array.

    The result has length len(counts) + 1, starting with 0.

    Args:
        counts: Array of non-negative counts for each element.
        dtype: Data type for the output array (default: same as counts).

    Returns:
        Position array with cumulative offsets.

    Raises:
        ValueError: If any count is negative.

    Example:
        >>> counts = np.array([3, 2, 4, 1])
        >>> position_array(counts)
        array([0, 3, 5, 9, 10])
    """
    if len(counts) > 0 and np.any(counts < 0):
        raise ValueError("counts must be non-negative")
    if dtype is None:
        dtype = counts.dtype
    pos_array = np.empty(len(counts) + 1, dtype=dtype)
    pos_array[0] = 0
    np.cumsum(counts, out=pos_array[1:])
    return pos_array
