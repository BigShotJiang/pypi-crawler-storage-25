# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Dtype construction and transformation utilities.

Operations that create or transform ``np.dtype`` objects without
touching array data. All functions are pure — they take dtypes in and
return dtypes out. The returned dtypes are typically combined with
``ndarray.view()`` to reinterpret existing memory.
"""

from typing import Any

import numpy as np


def structured_dtype(dtype: Any, names: list[str]) -> np.dtype:
    """Build a structured dtype with named fields sharing a common base dtype.

    Accepts either a scalar dtype (all fields take that dtype) or an
    array subdtype such as ``np.dtype((np.float64, 3))`` (in which case
    the subdtype's shape must match ``len(names)`` and each field gets
    the base dtype).

    Args:
        dtype: A scalar dtype, an array subdtype, or anything numpy
            accepts as a dtype spec (string, type, etc.).
        names: Field names, one per output field.

    Returns:
        A structured dtype with one field per name, each field sharing
        the same base dtype.

    Raises:
        ValueError: If *names* is empty, if the supplied subdtype's
            total element count does not match ``len(names)``, or if
            *names* contains duplicates.

    Example:
        >>> structured_dtype('f8', ['x', 'y', 'z'])
        dtype([('x', '<f8'), ('y', '<f8'), ('z', '<f8')])

        >>> structured_dtype(np.dtype((np.float64, 3)), ['x', 'y', 'z'])
        dtype([('x', '<f8'), ('y', '<f8'), ('z', '<f8')])
    """
    if not names:
        raise ValueError("names must be a non-empty list")
    if len(set(names)) != len(names):
        raise ValueError(f"names contains duplicates: {names}")

    dt = np.dtype(dtype)
    if dt.subdtype is not None:
        base, shape = dt.subdtype
        total = 1
        for dim in shape:
            total *= dim
        if total != len(names):
            raise ValueError(
                f"subdtype shape {shape} has {total} components but {len(names)} names were given"
            )
        return np.dtype([(name, base) for name in names])

    return np.dtype([(name, dt) for name in names])


def flatten_dtype(
    dt: np.dtype,
    *,
    field_names: dict[str, list[str]] | None = None,
    fmt: str = "{name}_{dim}",
    strip_plural: bool = True,
) -> tuple[np.dtype, list[str]]:
    """Flatten a structured dtype by expanding array fields into scalar fields.

    Array fields (fields with shape) are expanded into one scalar field
    per component. Scalar fields pass through unchanged.

    Naming is controlled by three parameters, in order of priority:

    1. ``field_names[field]`` — if provided for a given source field,
       those names are used verbatim.
    2. ``fmt`` — a format string with ``{name}`` and ``{dim}`` tokens.
       ``{name}`` is the source field name after optional plural
       stripping; ``{dim}`` is the 0-based component index.
    3. Defaults (``fmt="{name}_{dim}"``, ``strip_plural=True``) produce
       the classic ``values (3,)`` → ``value_0, value_1, value_2``.

    Args:
        dt: NumPy structured dtype to flatten.
        field_names: Optional ``{source_field: [names...]}`` mapping.
            For any field listed here, ``fmt`` is ignored and the
            explicit names are used. The list length must equal the
            field's total element count (product of its shape).
        fmt: Format string applied to fields not in *field_names*.
            Must contain ``{dim}`` (otherwise all expansions of a
            field would collide on a single name).
        strip_plural: When True (default), strip a trailing ``'s'``
            from the source field name before substituting ``{name}``.

    Returns:
        ``(flattened_dtype, column_list)``.

    Raises:
        ValueError: If *field_names* references a field not in *dt*,
            if a names list has the wrong length, if *fmt* lacks
            ``{dim}`` but is needed to expand an array field, or if
            the generated column names have duplicates.
        RuntimeError: If the flattened dtype's itemsize differs from
            the original (should not happen under normal use).

    Example:
        >>> dt = np.dtype([('id', 'i4'), ('coords', 'f8', (3,))])
        >>> _, cols = flatten_dtype(dt)
        >>> cols
        ['id', 'coord_0', 'coord_1', 'coord_2']

        >>> _, cols = flatten_dtype(
        ...     dt, field_names={'coords': ['x', 'y', 'z']},
        ... )
        >>> cols
        ['id', 'x', 'y', 'z']

        >>> _, cols = flatten_dtype(dt, fmt="{name}[{dim}]")
        >>> cols
        ['id', 'coord[0]', 'coord[1]', 'coord[2]']
    """
    field_names = field_names or {}
    if dt.names is not None:
        unknown = [k for k in field_names if k not in dt.names]
        if unknown:
            raise ValueError(f"field_names references unknown fields: {unknown}")

    columns: list[str] = []
    flattened_descr: list[tuple[Any, ...]] = []
    for item in dt.descr:
        if len(item) > 2:
            name = item[0]
            field_format = item[1]
            field_shape = item[2]
            total = 1
            for dim in field_shape:
                total *= dim

            if name in field_names:
                expanded = field_names[name]
                if len(expanded) != total:
                    raise ValueError(
                        f"field_names[{name!r}] has {len(expanded)} names "
                        f"but field shape {field_shape} has {total} components"
                    )
            else:
                if "{dim}" not in fmt:
                    raise ValueError("fmt must contain '{dim}' to expand array fields")
                stem = name[:-1] if strip_plural and name.endswith("s") else name
                expanded = [fmt.format(name=stem, dim=i) for i in range(total)]

            for col_name in expanded:
                columns.append(col_name)
                flattened_descr.append((col_name, field_format))
        else:
            name = item[0]
            if name:
                columns.append(name)
            flattened_descr.append(item)

    if len(set(columns)) != len(columns):
        raise ValueError(f"Flattened dtype has duplicate column names: {columns}")

    flattened_dt = np.dtype(flattened_descr)
    if dt.itemsize != flattened_dt.itemsize:
        raise RuntimeError(
            f"Unable to flatten the dtype: original itemsize {dt.itemsize} != "
            f"flattened itemsize {flattened_dt.itemsize}"
        )
    return (flattened_dt, columns)


# Legacy alias — kept for continuity; prefer flatten_dtype.
flatten_record_dtype = flatten_dtype


def rename_fields(dt: np.dtype, mapping: dict[str, str]) -> np.dtype:
    """Return a new dtype with fields renamed according to *mapping*.

    Fields not present in *mapping* keep their original names.

    Args:
        dt: Structured NumPy dtype.
        mapping: Dictionary mapping old field names to new field names.

    Returns:
        A new dtype with renamed fields.

    Raises:
        ValueError: If the dtype is not structured.
        KeyError: If any key in *mapping* does not exist in *dt*.

    Example:
        >>> dt = np.dtype([('x', 'f8'), ('y', 'f8')])
        >>> rename_fields(dt, {'x': 'longitude', 'y': 'latitude'})
        dtype([('longitude', '<f8'), ('latitude', '<f8')])
    """
    if dt.names is None:
        raise ValueError("dtype must be a structured dtype with fields")

    missing = [k for k in mapping if k not in dt.names]
    if missing:
        raise KeyError(f"Fields not found in dtype: {missing}")

    new_descr = []
    for item in dt.descr:
        name = item[0]
        new_name = mapping.get(name, name)
        new_descr.append((new_name, *item[1:]))
    return np.dtype(new_descr)


def merge_adjacent_fields(
    dt: np.dtype,
    fields: list[str],
    new_name: str,
) -> np.dtype:
    """Merge adjacent 'S' fields into a single 'S' field.

    The listed fields must all be byte-string dtype (``kind='S'``) and
    occupy adjacent (contiguous) offsets in *dt*. They are replaced in
    place by a single field named *new_name* with dtype
    ``S{combined_itemsize}``. Field order around the merge point is
    preserved.

    This is a pure dtype transformation: the returned dtype has the
    same total itemsize as *dt* and can be used with ``ndarray.view()``
    to reinterpret an existing array without copying.

    Only 'S' fields are supported. Merging different kinds (e.g. two
    ``i4`` into one ``i8``) is ambiguous (endianness, sign extension)
    and is not handled here.

    Args:
        dt: Structured NumPy dtype.
        fields: Two or more field names to merge, in any order. All
            listed fields must be adjacent in *dt*.
        new_name: Name for the resulting merged field.

    Returns:
        A new structured dtype with the listed fields replaced by a
        single ``S{N}`` field named *new_name*.

    Raises:
        ValueError: If *dt* is not structured, if fewer than two
            fields are given, if any listed field is missing from
            *dt*, if any listed field is not 'S' kind, if the listed
            fields are not adjacent in memory, or if *new_name*
            collides with a surviving field name.

    Example:
        >>> dt = np.dtype([('first', 'S4'), ('last', 'S6'), ('age', 'i4')])
        >>> merge_adjacent_fields(dt, ['first', 'last'], 'name')
        dtype([('name', 'S10'), ('age', '<i4')])
    """
    if dt.names is None:
        raise ValueError("dtype must be a structured dtype with fields")
    if len(fields) < 2:
        raise ValueError("merge_adjacent_fields requires at least two fields")

    missing = [f for f in fields if f not in dt.names]
    if missing:
        raise ValueError(f"Fields not found in dtype: {missing}")

    non_s = [f for f in fields if dt.fields[f][0].kind != "S"]  # type: ignore[index]
    if non_s:
        raise ValueError(
            f"Only 'S' (byte string) fields can be merged; got non-'S' fields: {non_s}"
        )

    # Sort listed fields by their offset in dt
    by_offset = sorted(
        fields,
        key=lambda f: dt.fields[f][1],  # type: ignore[index]
    )

    # Verify adjacency: each field's end offset must equal the next field's start
    for i in range(len(by_offset) - 1):
        cur = by_offset[i]
        nxt = by_offset[i + 1]
        cur_offset = dt.fields[cur][1]  # type: ignore[index]
        cur_size = dt.fields[cur][0].itemsize  # type: ignore[index]
        nxt_offset = dt.fields[nxt][1]  # type: ignore[index]
        if cur_offset + cur_size != nxt_offset:
            raise ValueError(
                f"Fields {cur!r} and {nxt!r} are not adjacent "
                f"(offsets {cur_offset}+{cur_size} vs {nxt_offset})"
            )

    total_size = 0
    for f in fields:
        total_size += dt.fields[f][0].itemsize  # type: ignore[index]
    merged_descr = (new_name, f"S{total_size}")

    # Check new_name does not collide with a surviving field
    surviving = [f for f in dt.names if f not in set(fields)]
    if new_name in surviving:
        raise ValueError(f"new_name {new_name!r} collides with an existing field not being merged")

    # Rebuild the descr, inserting the merged field in the position of by_offset[0]
    first_field = by_offset[0]
    skip = set(fields)
    new_descr: list[tuple[Any, ...]] = []
    inserted = False
    for item in dt.descr:
        name = item[0]
        if name == first_field:
            new_descr.append(merged_descr)
            inserted = True
        elif name in skip:
            # Later field being merged — swallow
            continue
        else:
            new_descr.append(item)
    if not inserted:
        # Defensive: should always insert because first_field is in skip
        raise RuntimeError("internal error: merged field not inserted")

    return np.dtype(new_descr)
