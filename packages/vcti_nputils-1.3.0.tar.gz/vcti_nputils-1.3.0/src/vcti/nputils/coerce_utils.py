# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Safe coercion of Python values into NumPy arrays.

Currently exposes :func:`as_ndarray` for the common ``None / list /
ndarray`` trio. Other coercion helpers (scalar broadcasting,
dtype-inference-with-fallback, etc.) can live here as they're added.
"""

from typing import Any

import numpy as np


def as_ndarray(
    value: np.ndarray | list[Any] | None,
    dtype: np.dtype | None = None,
) -> np.ndarray:
    """Coerce a value to a NumPy ndarray.

    Handles the three common input forms seen across the vcti codebase:
    ``None`` becomes an empty array, lists are converted, and existing
    arrays are passed through (or cast if *dtype* differs).

    Args:
        value: Input value — an ndarray, a Python list, or None.
        dtype: Desired dtype for the output array. When *value* is
            already an ndarray with a matching dtype it is returned
            as-is (no copy).

    Returns:
        A NumPy ndarray.

    Example:
        >>> as_ndarray([1, 2, 3], dtype=np.float64)
        array([1., 2., 3.])
        >>> as_ndarray(None).shape
        (0,)
    """
    if value is None:
        return np.empty(0, dtype=dtype)
    if isinstance(value, np.ndarray):
        if dtype is not None and value.dtype != dtype:
            return value.astype(dtype)
        return value
    return np.asarray(value, dtype=dtype)
