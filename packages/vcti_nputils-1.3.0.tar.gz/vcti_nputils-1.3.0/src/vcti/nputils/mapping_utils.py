# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Value-to-name mapping utilities for NumPy arrays.

Currently exposes :func:`name_array` for enum-style mapping of integer
arrays to string arrays via a dictionary lookup. Other mapping
operations (reverse lookup, multi-key mapping, etc.) can live here.
"""

import warnings
from typing import cast

import numpy as np

_SPARSE_LOOKUP_THRESHOLD = 10_000


def name_array(
    nparray: np.ndarray,
    enum_dict: dict[int, str],
    default: str = "",
) -> np.ndarray:
    """Convert numeric array values to names using a dictionary.

    Maps each numeric value to its corresponding name. Values not found
    in the dictionary are replaced with *default*.

    Uses array indexing for O(n) performance when enum values are
    reasonably dense. Space complexity is O(max_key - min_key). A warning
    is emitted when the lookup array exceeds 10 000 elements.

    Args:
        nparray: NumPy array containing integer values.
        enum_dict: Dictionary mapping integer values to name strings.
        default: String used for values not present in *enum_dict*.

    Returns:
        NumPy array of strings with the corresponding names. Values
        outside the dictionary key range are mapped to *default*.

    Example:
        >>> enum_dict = {1: 'ACTIVE', 2: 'INACTIVE', 3: 'PENDING'}
        >>> values = np.array([1, 2, 1, 3])
        >>> name_array(values, enum_dict)
        array(['ACTIVE', 'INACTIVE', 'ACTIVE', 'PENDING'], dtype='<U...')
    """
    if len(enum_dict) == 0:
        default_len = max(len(default), 1)
        return np.full(len(nparray), default, dtype=f"U{default_len}")

    keys = list(enum_dict.keys())
    min_val = min(keys)
    max_val = max(keys)
    span = max_val - min_val + 1

    if span > _SPARSE_LOOKUP_THRESHOLD:
        warnings.warn(
            f"name_array: enum key range spans {span} entries "
            f"({min_val}..{max_val}) — consider using a denser mapping",
            stacklevel=2,
        )

    max_len = max(len(default), max(len(str(v)) for v in enum_dict.values()))

    lookup = np.full(span, default, dtype=f"U{max_len}")
    for key, value in enum_dict.items():
        lookup[key - min_val] = value

    # Clamp out-of-range values so they map to *default*
    shifted = nparray - min_val
    out_of_range = (shifted < 0) | (shifted >= span)
    if out_of_range.any():
        shifted = shifted.copy()
        shifted[out_of_range] = 0  # index 0 is safe; will be overwritten below
    result = lookup[shifted]
    if out_of_range.any():
        result[out_of_range] = default
    return cast(np.ndarray, result)
