# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""vcti.nputils — NumPy structured array utilities."""

from importlib.metadata import version

from .byte_utils import (
    ZERO_CHAR,
    bytes_from_string,
    check_overflow,
    decode_column,
    decode_field,
    encode_column,
    encode_field,
    get_encoding,
    string_from_bytes,
    with_encoding,
)
from .coerce_utils import as_ndarray
from .dtype_utils import (
    flatten_dtype,
    flatten_record_dtype,
    merge_adjacent_fields,
    rename_fields,
    structured_dtype,
)
from .join_utils import join_struct_arrays
from .mapping_utils import name_array
from .offset_utils import position_array
from .view_utils import drop_fields, fields_view

__version__ = version("vcti-nputils")

__all__ = [
    "ZERO_CHAR",
    "__version__",
    "as_ndarray",
    "bytes_from_string",
    "check_overflow",
    "decode_column",
    "decode_field",
    "drop_fields",
    "encode_column",
    "encode_field",
    "fields_view",
    "flatten_dtype",
    "flatten_record_dtype",
    "get_encoding",
    "join_struct_arrays",
    "merge_adjacent_fields",
    "name_array",
    "position_array",
    "rename_fields",
    "string_from_bytes",
    "structured_dtype",
    "with_encoding",
]
