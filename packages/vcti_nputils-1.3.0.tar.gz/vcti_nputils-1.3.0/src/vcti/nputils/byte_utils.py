# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Byte and string conversion utilities for structured NumPy arrays.

Provides utilities for converting between Python strings and fixed-length
byte fields (dtype 'S'), supporting the pybind11/C++ interop pattern where
C-style byte strings are passed to Python as numpy 'S' fields.

Two field layouts are supported:
- Single field: only the byte column (``name: S32``).
- Paired field: byte column plus a length column (``name: S32``,
  ``name_length: i4``) — the length captures the *original* encoded byte
  length so overflow/truncation can be detected later.

Encoding can be passed explicitly to each function or attached to a dtype
via :func:`with_encoding` and read by :func:`get_encoding`. When encoding
is omitted on ``decode_field``/``encode_field``, the dtype metadata is
consulted first and falls back to utf-8.

Gotchas
-------
- Field lengths and truncation are measured in *bytes*, not characters.
  With utf-8 a single character can occupy up to 4 bytes.
- Only *trailing* null bytes are stripped on decode. Null bytes in the
  middle of a value are preserved.
- Encoding metadata lives on an individual (scalar) dtype, not on the
  enclosing structured dtype. Annotate each field dtype with
  :func:`with_encoding` before composing the structured dtype.
"""

import numpy as np

ZERO_CHAR = "\x00"
_ZERO_BYTES = b"\x00"
_ENCODING_KEY = "encoding"
_DEFAULT_ENCODING = "utf-8"


def string_from_bytes(value: bytes, encoding: str = _DEFAULT_ENCODING) -> str:
    """Decode bytes to string, stripping trailing null bytes.

    Only *trailing* nulls are stripped. Null bytes embedded in the middle
    of the value are preserved in the output.

    Args:
        value: Bytes to decode (may include trailing null padding).
        encoding: Character encoding (default: utf-8).

    Returns:
        Decoded string with trailing null bytes stripped.

    Example:
        >>> string_from_bytes(b'hello\\x00\\x00\\x00')
        'hello'
    """
    return value.rstrip(_ZERO_BYTES).decode(encoding)


def bytes_from_string(
    value: str,
    length: int,
    encoding: str = _DEFAULT_ENCODING,
) -> bytes:
    """Encode a string to fixed-length bytes, padding or truncating as needed.

    The returned bytes are exactly *length* bytes long. Strings that encode
    to more than *length* bytes are truncated; shorter strings are padded
    with null bytes.

    Args:
        value: String to encode.
        length: Target byte length.
        encoding: Character encoding (default: utf-8).

    Returns:
        Bytes of exactly *length* bytes.

    Raises:
        ValueError: If *length* is negative.

    Example:
        >>> bytes_from_string("hello", 10)
        b'hello\\x00\\x00\\x00\\x00\\x00'
    """
    if length < 0:
        raise ValueError(f"length must be non-negative, got {length}")
    encoded = value.encode(encoding)
    if len(encoded) >= length:
        return encoded[:length]
    return encoded + _ZERO_BYTES * (length - len(encoded))


def decode_column(
    byte_array: np.ndarray,
    encoding: str = _DEFAULT_ENCODING,
) -> np.ndarray:
    """Decode a byte-string column to a string column.

    Each element is decoded and *trailing* null bytes (padding) are
    stripped. Null bytes embedded in the middle of a value are preserved.

    Args:
        byte_array: NumPy array with a byte-string dtype (``kind='S'``).
        encoding: Character encoding (default: utf-8).

    Returns:
        Unicode string array (``kind='U'``) of the same length.

    Raises:
        ValueError: If *byte_array* does not have a byte-string dtype.

    Example:
        >>> col = np.array([b'Alice', b'Bob'], dtype='S10')
        >>> decode_column(col).tolist()
        ['Alice', 'Bob']
    """
    if byte_array.dtype.kind != "S":
        raise ValueError(
            f"Expected byte-string dtype (kind='S'), got kind={byte_array.dtype.kind!r}"
        )
    decoded = np.char.decode(byte_array, encoding)
    return np.char.rstrip(decoded, ZERO_CHAR)


def encode_column(
    strings: list[str] | np.ndarray,
    length: int,
    encoding: str = _DEFAULT_ENCODING,
) -> tuple[np.ndarray, np.ndarray]:
    """Encode a string column to a ``(bytes_array, lengths_array)`` pair.

    Each string is encoded and padded or truncated to exactly *length*
    bytes. The returned length array contains the *original* encoded byte
    length for each string (before truncation), which can be used later
    with :func:`check_overflow` to detect truncation.

    Args:
        strings: Iterable of strings (list or 1-D ndarray).
        length: Target byte length for each row.
        encoding: Character encoding (default: utf-8).

    Returns:
        Tuple of ``(bytes_array, lengths_array)``:

        - ``bytes_array``: dtype ``S<length>`` with padded/truncated bytes.
        - ``lengths_array``: dtype ``int64`` holding original encoded byte length.

    Example:
        >>> b, lens = encode_column(["hi", "hello world"], length=5)
        >>> b.tolist()
        [b'hi', b'hello']
        >>> lens.tolist()
        [2, 11]
    """
    if isinstance(strings, np.ndarray) and strings.ndim != 1:
        raise ValueError(f"strings must be 1-dimensional, got {strings.ndim}-D array")
    n = len(strings)
    encoded_list = [s.encode(encoding) for s in strings]
    lengths = np.array([len(e) for e in encoded_list], dtype=np.int64)
    bytes_out = np.empty(n, dtype=f"S{length}")
    for i, e in enumerate(encoded_list):
        bytes_out[i] = e[:length]  # 'S' dtype auto-pads shorter values with nulls
    return bytes_out, lengths


def decode_field(
    sa: np.ndarray,
    field_name: str,
    *,
    encoding: str | None = None,
) -> np.ndarray:
    """Decode a byte field in a structured array to a string column.

    If *encoding* is None, it is resolved from the field's dtype metadata
    via :func:`get_encoding` (utf-8 fallback).

    Args:
        sa: Structured NumPy array.
        field_name: Name of the byte field to decode.
        encoding: Character encoding; if None, read from dtype metadata.

    Returns:
        Unicode string array of the same length as *sa*.

    Raises:
        ValueError: If *sa* is not structured or the field is not 'S' dtype.
        KeyError: If *field_name* is not in the array.

    Example:
        >>> dt = np.dtype([('name', 'S10'), ('value', 'f8')])
        >>> sa = np.array([(b'Alice', 1.5), (b'Bob', 2.5)], dtype=dt)
        >>> decode_field(sa, 'name').tolist()
        ['Alice', 'Bob']
    """
    if sa.dtype.fields is None:
        raise ValueError("Array must have a structured dtype with fields")
    if field_name not in sa.dtype.fields:
        raise KeyError(f"Field '{field_name}' not found in array")
    field_dtype = sa.dtype.fields[field_name][0]
    if field_dtype.kind != "S":
        raise ValueError(
            f"Field '{field_name}' is not a byte-string dtype (kind={field_dtype.kind!r})"
        )
    if encoding is None:
        encoding = get_encoding(field_dtype)
    return decode_column(sa[field_name], encoding=encoding)


def encode_field(
    sa: np.ndarray,
    field_name: str,
    strings: list[str] | np.ndarray,
    *,
    length_field: str | None = None,
    encoding: str | None = None,
) -> None:
    """Encode strings and assign them to a byte field of a structured array.

    Pads or truncates each string to match the field's byte length. If
    *length_field* is given, it must be a sibling integer field on *sa*
    and will be populated with the *original* encoded byte length for each
    row — used later by :func:`check_overflow` to detect truncation.

    If *encoding* is None, it is resolved from the field's dtype metadata
    via :func:`get_encoding` (utf-8 fallback).

    Args:
        sa: Structured NumPy array (modified in place).
        field_name: Name of the target byte field.
        strings: Iterable of strings, one per row.
        length_field: Optional name of a sibling integer field to populate
            with original encoded byte lengths.
        encoding: Character encoding; if None, read from dtype metadata.

    Raises:
        ValueError: If *sa* is not structured, the field is not 'S' dtype,
            or ``len(strings) != len(sa)``.
        KeyError: If *field_name* or *length_field* is not present.

    Example:
        >>> dt = np.dtype([('name', 'S10'), ('name_length', 'i4')])
        >>> sa = np.zeros(2, dtype=dt)
        >>> encode_field(sa, 'name', ['Alice', 'Bob'], length_field='name_length')
        >>> sa['name'].tolist()
        [b'Alice', b'Bob']
        >>> sa['name_length'].tolist()
        [5, 3]
    """
    if sa.dtype.fields is None:
        raise ValueError("Array must have a structured dtype with fields")
    if field_name not in sa.dtype.fields:
        raise KeyError(f"Field '{field_name}' not found in array")
    field_dtype = sa.dtype.fields[field_name][0]
    if field_dtype.kind != "S":
        raise ValueError(
            f"Field '{field_name}' is not a byte-string dtype (kind={field_dtype.kind!r})"
        )
    if length_field is not None and length_field not in sa.dtype.fields:
        raise KeyError(f"Length field '{length_field}' not found in array")
    if isinstance(strings, np.ndarray) and strings.ndim != 1:
        raise ValueError(f"strings must be 1-dimensional, got {strings.ndim}-D array")
    if len(strings) != len(sa):
        raise ValueError(
            f"Length of strings ({len(strings)}) does not match array length ({len(sa)})"
        )

    if encoding is None:
        encoding = get_encoding(field_dtype)
    bytes_col, lens_col = encode_column(strings, field_dtype.itemsize, encoding=encoding)
    sa[field_name] = bytes_col
    if length_field is not None:
        sa[length_field] = lens_col


def check_overflow(
    sa: np.ndarray,
    field_name: str,
    length_field: str,
) -> np.ndarray:
    """Detect rows where the original encoded byte length exceeded the field.

    Given paired ``(bytes, length)`` columns, returns a boolean mask that
    is True for rows where the original encoded byte length exceeds the
    byte field's itemsize — i.e., rows that were truncated. The comparison
    is strictly against *byte* length in the encoding originally used;
    character count is irrelevant for multi-byte encodings.

    Args:
        sa: Structured NumPy array.
        field_name: Name of the byte field.
        length_field: Name of the integer field holding original byte lengths.

    Returns:
        Boolean array of shape ``(len(sa),)`` where True indicates overflow.

    Raises:
        ValueError: If *sa* is not structured or the byte field is not 'S' dtype.
        KeyError: If either field is not present in *sa*.

    Example:
        >>> dt = np.dtype([('name', 'S5'), ('name_length', 'i4')])
        >>> sa = np.array([(b'hi', 2), (b'hello', 11)], dtype=dt)
        >>> check_overflow(sa, 'name', 'name_length').tolist()
        [False, True]
    """
    if sa.dtype.fields is None:
        raise ValueError("Array must have a structured dtype with fields")
    if field_name not in sa.dtype.fields:
        raise KeyError(f"Field '{field_name}' not found in array")
    if length_field not in sa.dtype.fields:
        raise KeyError(f"Length field '{length_field}' not found in array")
    field_dtype = sa.dtype.fields[field_name][0]
    if field_dtype.kind != "S":
        raise ValueError(
            f"Field '{field_name}' is not a byte-string dtype (kind={field_dtype.kind!r})"
        )
    return sa[length_field] > field_dtype.itemsize


def get_encoding(
    dtype: np.dtype,
    default: str = _DEFAULT_ENCODING,
) -> str:
    """Read the encoding stored in a dtype's metadata.

    Args:
        dtype: NumPy dtype.
        default: Encoding to return if no metadata is set (default: utf-8).

    Returns:
        The encoding name from ``dtype.metadata['encoding']`` if present,
        otherwise *default*.

    Example:
        >>> dt = with_encoding(np.dtype('S10'), 'latin-1')
        >>> get_encoding(dt)
        'latin-1'
        >>> get_encoding(np.dtype('S10'))
        'utf-8'
    """
    metadata = dtype.metadata
    if metadata and _ENCODING_KEY in metadata:
        return str(metadata[_ENCODING_KEY])
    return default


def with_encoding(dtype: np.dtype, encoding: str) -> np.dtype:
    """Return a copy of the dtype with *encoding* stored in its metadata.

    Preserves any other metadata already attached to the dtype. This is
    intended for scalar (non-structured) dtypes — typically an 'S' field
    dtype before composing it into a structured dtype. Passing a structured
    dtype raises ``ValueError``; annotate the field dtypes individually
    instead.

    Args:
        dtype: Scalar NumPy dtype to annotate.
        encoding: Encoding name to store under the 'encoding' key.

    Returns:
        A new dtype with updated metadata.

    Raises:
        ValueError: If *dtype* is a structured (multi-field) dtype.

    Example:
        >>> dt = with_encoding(np.dtype('S10'), 'latin-1')
        >>> dt.metadata['encoding']
        'latin-1'
    """
    if dtype.names is not None:
        raise ValueError(
            "with_encoding is for scalar dtypes; annotate individual field "
            "dtypes before composing them into a structured dtype"
        )
    existing = dict(dtype.metadata) if dtype.metadata else {}
    existing[_ENCODING_KEY] = encoding
    # Construct from str to force a fresh dtype — numpy's dtype(obj, metadata=...)
    # merges metadata but preserves existing keys, which would prevent overwriting.
    return np.dtype(dtype.str, metadata=existing)
