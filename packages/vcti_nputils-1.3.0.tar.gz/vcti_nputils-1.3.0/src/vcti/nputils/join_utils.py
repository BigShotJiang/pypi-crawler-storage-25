# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Functions for combining multiple arrays into one.

Currently exposes :func:`join_struct_arrays` for horizontal (field-wise)
joins of structured arrays with matching row counts. Other combination
operations (row-wise concatenation, zipping, masking-based merges) can
live here as they're added.
"""

import numpy as np


def join_struct_arrays(arrays: list[np.ndarray]) -> np.ndarray:
    """Join multiple structured arrays horizontally by combining their fields.

    All input arrays must have the same number of rows.

    Args:
        arrays: List of structured NumPy arrays to join.

    Returns:
        A new structured array containing all fields from the input arrays.

    Raises:
        ValueError: If arrays list is empty, any array is not structured,
            arrays have mismatched row counts, or field names are duplicated
            across arrays.

    Example:
        >>> dt1 = np.dtype([('id', 'i4'), ('value', 'f8')])
        >>> dt2 = np.dtype([('name', 'U10')])
        >>> arr1 = np.array([(1, 1.5), (2, 2.5)], dtype=dt1)
        >>> arr2 = np.array([('Alice',), ('Bob',)], dtype=dt2)
        >>> result = join_struct_arrays([arr1, arr2])
        >>> result.dtype.names
        ('id', 'value', 'name')
    """
    if not arrays:
        raise ValueError("arrays list cannot be empty")

    n = len(arrays[0])
    seen: set[str] = set()
    duplicates: list[str] = []
    for i, a in enumerate(arrays):
        if a.dtype.names is None:
            raise ValueError(f"Array at index {i} does not have a structured dtype")
        if i > 0 and len(a) != n:
            raise ValueError(f"Array at index {i} has {len(a)} rows, expected {n}")
        for name in a.dtype.names:
            if name in seen:
                duplicates.append(name)
            seen.add(name)
    if duplicates:
        raise ValueError(f"Duplicate field names across arrays: {duplicates}")

    sizes = np.array([a.itemsize for a in arrays])
    offsets = np.r_[0, sizes.cumsum()]
    # Build a uint8 matrix with one column-block per input array, then
    # reinterpret the flattened bytes with the merged dtype.
    joint = np.empty((n, offsets[-1]), dtype=np.uint8)
    for a, size, offset in zip(arrays, sizes, offsets):
        joint[:, offset : offset + size] = a.view(np.uint8).reshape(n, size)
    dtype = sum((a.dtype.descr for a in arrays), [])
    return joint.ravel().view(dtype)
