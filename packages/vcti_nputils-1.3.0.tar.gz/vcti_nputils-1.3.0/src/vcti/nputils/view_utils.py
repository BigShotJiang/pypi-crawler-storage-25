# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Zero-copy field-selection views over structured arrays.

Functions that return a view sharing memory with the source array,
exposing a subset of its fields. Use these when you want to pass a
narrower structured array downstream without allocating a copy.
"""

import numpy as np


def fields_view(sa: np.ndarray, fields: list[str]) -> np.ndarray:
    """Create a view of a structured array with only selected fields.

    Returns a view (not a copy) sharing memory with the original array.
    Modifications to the view will be reflected in the original.

    Args:
        sa: Structured NumPy array.
        fields: List of field names to include.

    Returns:
        A view containing only the selected fields. The view shares
        memory with *sa*; writes to either are visible in both.

    Raises:
        ValueError: If the array does not have a structured dtype.
        KeyError: If any field name does not exist in the array.

    Example:
        >>> dt = np.dtype([('id', 'i4'), ('name', 'U10'), ('value', 'f8')])
        >>> arr = np.array([(1, 'Alice', 1.5), (2, 'Bob', 2.5)], dtype=dt)
        >>> view = fields_view(arr, ['id', 'value'])
        >>> view.dtype.names
        ('id', 'value')
    """
    if sa.dtype.fields is None:
        raise ValueError("Array must have a structured dtype with fields")

    missing_fields = [f for f in fields if f not in sa.dtype.fields]
    if missing_fields:
        raise KeyError(f"Fields not found in array: {missing_fields}")

    dtype_fields = np.dtype({name: sa.dtype.fields[name] for name in fields})  # type: ignore[call-overload]
    return np.ndarray(sa.shape, dtype_fields, sa, 0, sa.strides)


def drop_fields(sa: np.ndarray, exclude: list[str]) -> np.ndarray:
    """Create a view of a structured array with specified fields excluded.

    The complement of :func:`fields_view` — keeps all fields *except*
    those listed in *exclude*. Returns a zero-copy view sharing memory
    with the original array.

    Args:
        sa: Structured NumPy array.
        exclude: Field names to exclude from the view.

    Returns:
        A view containing all fields not in *exclude*. The view shares
        memory with *sa*; writes to either are visible in both.

    Raises:
        ValueError: If the array does not have a structured dtype, or
            if excluding all fields would leave an empty dtype.
        KeyError: If any name in *exclude* does not exist in the array.

    Example:
        >>> dt = np.dtype([('id', 'i4'), ('filler', 'u1'), ('value', 'f8')])
        >>> arr = np.array([(1, 0, 1.5), (2, 0, 2.5)], dtype=dt)
        >>> drop_fields(arr, ['filler']).dtype.names
        ('id', 'value')
    """
    if sa.dtype.fields is None:
        raise ValueError("Array must have a structured dtype with fields")

    missing = [f for f in exclude if f not in sa.dtype.fields]
    if missing:
        raise KeyError(f"Fields not found in array: {missing}")

    exclude_set = set(exclude)
    keep = [name for name in sa.dtype.names if name not in exclude_set]  # type: ignore[union-attr]
    if not keep:
        raise ValueError("Cannot exclude all fields — result would be empty")

    return fields_view(sa, keep)
