# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for coerce_utils module."""

import numpy as np

from vcti.nputils.coerce_utils import as_ndarray


class TestAsNdarray:
    def test_from_list(self):
        result = as_ndarray([1, 2, 3])
        assert isinstance(result, np.ndarray)
        assert np.array_equal(result, np.array([1, 2, 3]))

    def test_from_list_with_dtype(self):
        result = as_ndarray([1, 2, 3], dtype=np.float64)
        assert result.dtype == np.float64
        assert np.array_equal(result, np.array([1.0, 2.0, 3.0]))

    def test_from_none(self):
        result = as_ndarray(None)
        assert isinstance(result, np.ndarray)
        assert result.shape == (0,)

    def test_from_none_with_dtype(self):
        result = as_ndarray(None, dtype=np.int32)
        assert result.dtype == np.int32
        assert result.shape == (0,)

    def test_passthrough_ndarray(self):
        arr = np.array([1, 2, 3])
        result = as_ndarray(arr)
        assert result is arr

    def test_ndarray_same_dtype_no_copy(self):
        arr = np.array([1.0, 2.0], dtype=np.float64)
        result = as_ndarray(arr, dtype=np.float64)
        assert result is arr

    def test_ndarray_different_dtype_casts(self):
        arr = np.array([1, 2, 3], dtype=np.int32)
        result = as_ndarray(arr, dtype=np.float64)
        assert result.dtype == np.float64
        assert result is not arr
        assert np.array_equal(result, np.array([1.0, 2.0, 3.0]))

    def test_empty_list(self):
        result = as_ndarray([])
        assert isinstance(result, np.ndarray)
        assert len(result) == 0
