# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for byte_utils module."""

import numpy as np
import pytest

from vcti.nputils.byte_utils import (
    bytes_from_string,
    check_overflow,
    decode_column,
    decode_field,
    encode_column,
    encode_field,
    get_encoding,
    string_from_bytes,
    with_encoding,
)


class TestStringFromBytes:
    def test_basic(self):
        assert string_from_bytes(b"hello") == "hello"

    def test_trailing_nulls_stripped(self):
        assert string_from_bytes(b"hello\x00\x00\x00") == "hello"

    def test_empty(self):
        assert string_from_bytes(b"") == ""

    def test_all_nulls(self):
        assert string_from_bytes(b"\x00\x00\x00") == ""

    def test_utf8_multibyte(self):
        assert string_from_bytes("café".encode()) == "café"

    def test_latin1(self):
        assert string_from_bytes(b"caf\xe9", encoding="latin-1") == "café"


class TestBytesFromString:
    def test_basic_padding(self):
        result = bytes_from_string("hello", 10)
        assert result == b"hello\x00\x00\x00\x00\x00"
        assert len(result) == 10

    def test_exact_fit(self):
        result = bytes_from_string("hello", 5)
        assert result == b"hello"

    def test_truncation(self):
        result = bytes_from_string("hello world", 5)
        assert result == b"hello"
        assert len(result) == 5

    def test_empty_string(self):
        result = bytes_from_string("", 4)
        assert result == b"\x00\x00\x00\x00"

    def test_negative_length_raises(self):
        with pytest.raises(ValueError, match="non-negative"):
            bytes_from_string("hello", -1)

    def test_zero_length(self):
        assert bytes_from_string("hello", 0) == b""

    def test_utf8_multibyte(self):
        # 'é' encodes to 2 bytes in utf-8
        result = bytes_from_string("café", 10)
        assert result == "café".encode() + b"\x00" * 5


class TestDecodeColumn:
    def test_basic(self):
        col = np.array([b"Alice", b"Bob"], dtype="S10")
        result = decode_column(col)
        assert result.tolist() == ["Alice", "Bob"]

    def test_strips_trailing_nulls(self):
        col = np.array([b"a\x00\x00\x00", b"bb\x00\x00"], dtype="S4")
        result = decode_column(col)
        assert result.tolist() == ["a", "bb"]

    def test_empty_array(self):
        col = np.array([], dtype="S10")
        result = decode_column(col)
        assert len(result) == 0

    def test_latin1_encoding(self):
        col = np.array([b"caf\xe9"], dtype="S10")
        result = decode_column(col, encoding="latin-1")
        assert result[0] == "café"

    def test_non_byte_dtype_raises(self):
        col = np.array([1, 2, 3])
        with pytest.raises(ValueError, match="byte-string dtype"):
            decode_column(col)


class TestEncodeColumn:
    def test_basic(self):
        bytes_col, lens = encode_column(["Alice", "Bob"], length=10)
        assert bytes_col.dtype == np.dtype("S10")
        assert bytes_col[0] == b"Alice"
        assert bytes_col[1] == b"Bob"
        assert lens.tolist() == [5, 3]

    def test_truncation_tracked(self):
        bytes_col, lens = encode_column(["hi", "hello world"], length=5)
        assert bytes_col[0] == b"hi"
        assert bytes_col[1] == b"hello"
        assert lens.tolist() == [2, 11]

    def test_empty_list(self):
        bytes_col, lens = encode_column([], length=5)
        assert len(bytes_col) == 0
        assert len(lens) == 0

    def test_utf8_length_tracks_bytes_not_chars(self):
        # 'é' is 2 bytes in utf-8, so 'café' is 5 bytes
        _, lens = encode_column(["café"], length=10)
        assert lens.tolist() == [5]

    def test_from_ndarray(self):
        bytes_col, lens = encode_column(np.array(["x", "yz"]), length=4)
        assert bytes_col[0] == b"x"
        assert bytes_col[1] == b"yz"
        assert lens.tolist() == [1, 2]

    def test_exact_length_fit(self):
        bytes_col, lens = encode_column(["hello"], length=5)
        assert bytes_col[0] == b"hello"
        assert lens.tolist() == [5]

    def test_2d_array_raises(self):
        arr2d = np.array([["a", "b"], ["c", "d"]])
        with pytest.raises(ValueError, match="1-dimensional"):
            encode_column(arr2d, length=5)

    def test_non_string_raises(self):
        # Passing non-str elements should fail cleanly on .encode()
        with pytest.raises(AttributeError):
            encode_column([1, 2, 3], length=5)


class TestDecodeField:
    def test_basic(self):
        dt = np.dtype([("name", "S10"), ("value", "f8")])
        sa = np.array([(b"Alice", 1.5), (b"Bob", 2.5)], dtype=dt)
        result = decode_field(sa, "name")
        assert result.tolist() == ["Alice", "Bob"]

    def test_reads_encoding_from_metadata(self):
        name_dt = with_encoding(np.dtype("S10"), "latin-1")
        dt = np.dtype([("name", name_dt)])
        sa = np.zeros(1, dtype=dt)
        sa["name"][0] = b"caf\xe9"
        result = decode_field(sa, "name")
        assert result[0] == "café"

    def test_explicit_encoding_overrides_metadata(self):
        name_dt = with_encoding(np.dtype("S10"), "latin-1")
        dt = np.dtype([("name", name_dt)])
        sa = np.zeros(1, dtype=dt)
        sa["name"][0] = "é".encode()
        result = decode_field(sa, "name", encoding="utf-8")
        assert result[0] == "é"

    def test_missing_field_raises(self):
        dt = np.dtype([("name", "S10")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(KeyError, match="Field 'missing' not found"):
            decode_field(sa, "missing")

    def test_non_structured_raises(self):
        arr = np.array([b"hi"], dtype="S5")
        with pytest.raises(ValueError, match="structured dtype"):
            decode_field(arr, "any")

    def test_non_byte_field_raises(self):
        dt = np.dtype([("value", "i4")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(ValueError, match="not a byte-string dtype"):
            decode_field(sa, "value")


class TestEncodeField:
    def test_basic(self):
        dt = np.dtype([("name", "S10"), ("value", "f8")])
        sa = np.zeros(2, dtype=dt)
        encode_field(sa, "name", ["Alice", "Bob"])
        assert sa["name"].tolist() == [b"Alice", b"Bob"]

    def test_with_length_field(self):
        dt = np.dtype([("name", "S10"), ("name_length", "i4")])
        sa = np.zeros(2, dtype=dt)
        encode_field(sa, "name", ["Alice", "Bob"], length_field="name_length")
        assert sa["name"].tolist() == [b"Alice", b"Bob"]
        assert sa["name_length"].tolist() == [5, 3]

    def test_length_field_captures_original_length(self):
        # byte field is S5 but input is 11 chars — length field should record 11
        dt = np.dtype([("name", "S5"), ("name_length", "i4")])
        sa = np.zeros(1, dtype=dt)
        encode_field(sa, "name", ["hello world"], length_field="name_length")
        assert sa["name"][0] == b"hello"
        assert sa["name_length"][0] == 11

    def test_reads_encoding_from_metadata(self):
        name_dt = with_encoding(np.dtype("S10"), "latin-1")
        dt = np.dtype([("name", name_dt)])
        sa = np.zeros(1, dtype=dt)
        encode_field(sa, "name", ["café"])
        assert sa["name"][0] == b"caf\xe9"

    def test_explicit_encoding_overrides_metadata(self):
        name_dt = with_encoding(np.dtype("S10"), "latin-1")
        dt = np.dtype([("name", name_dt)])
        sa = np.zeros(1, dtype=dt)
        encode_field(sa, "name", ["é"], encoding="utf-8")
        assert sa["name"][0] == "é".encode()

    def test_missing_field_raises(self):
        dt = np.dtype([("value", "f8")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(KeyError, match="Field 'name' not found"):
            encode_field(sa, "name", ["x"])

    def test_missing_length_field_raises(self):
        dt = np.dtype([("name", "S10")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(KeyError, match="Length field 'missing' not found"):
            encode_field(sa, "name", ["x"], length_field="missing")

    def test_non_byte_field_raises(self):
        dt = np.dtype([("name", "U10")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(ValueError, match="not a byte-string dtype"):
            encode_field(sa, "name", ["x"])

    def test_length_mismatch_raises(self):
        dt = np.dtype([("name", "S10")])
        sa = np.zeros(2, dtype=dt)
        with pytest.raises(ValueError, match="does not match array length"):
            encode_field(sa, "name", ["a", "b", "c"])

    def test_2d_strings_raises(self):
        dt = np.dtype([("name", "S10")])
        sa = np.zeros(2, dtype=dt)
        arr2d = np.array([["a", "b"], ["c", "d"]])
        with pytest.raises(ValueError, match="1-dimensional"):
            encode_field(sa, "name", arr2d)

    def test_non_structured_raises(self):
        arr = np.zeros(1, dtype="S5")
        with pytest.raises(ValueError, match="structured dtype"):
            encode_field(arr, "any", ["x"])


class TestCheckOverflow:
    def test_no_overflow(self):
        dt = np.dtype([("name", "S10"), ("name_length", "i4")])
        sa = np.zeros(2, dtype=dt)
        encode_field(sa, "name", ["Alice", "Bob"], length_field="name_length")
        result = check_overflow(sa, "name", "name_length")
        assert result.tolist() == [False, False]

    def test_detects_truncation(self):
        dt = np.dtype([("name", "S5"), ("name_length", "i4")])
        sa = np.zeros(2, dtype=dt)
        encode_field(sa, "name", ["hi", "hello world"], length_field="name_length")
        result = check_overflow(sa, "name", "name_length")
        assert result.tolist() == [False, True]

    def test_exact_fit_not_overflow(self):
        dt = np.dtype([("name", "S5"), ("name_length", "i4")])
        sa = np.zeros(1, dtype=dt)
        encode_field(sa, "name", ["hello"], length_field="name_length")
        result = check_overflow(sa, "name", "name_length")
        assert result.tolist() == [False]

    def test_empty_string_no_overflow(self):
        dt = np.dtype([("name", "S5"), ("name_length", "i4")])
        sa = np.zeros(1, dtype=dt)
        encode_field(sa, "name", [""], length_field="name_length")
        result = check_overflow(sa, "name", "name_length")
        assert result.tolist() == [False]
        assert sa["name_length"][0] == 0

    def test_missing_field_raises(self):
        dt = np.dtype([("name_length", "i4")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(KeyError, match="Field 'name' not found"):
            check_overflow(sa, "name", "name_length")

    def test_missing_length_field_raises(self):
        dt = np.dtype([("name", "S5")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(KeyError, match="Length field"):
            check_overflow(sa, "name", "name_length")

    def test_non_byte_field_raises(self):
        dt = np.dtype([("name", "U5"), ("name_length", "i4")])
        sa = np.zeros(1, dtype=dt)
        with pytest.raises(ValueError, match="not a byte-string dtype"):
            check_overflow(sa, "name", "name_length")


class TestEncodingMetadata:
    def test_get_encoding_default(self):
        assert get_encoding(np.dtype("S10")) == "utf-8"

    def test_get_encoding_custom_default(self):
        assert get_encoding(np.dtype("S10"), default="ascii") == "ascii"

    def test_get_encoding_from_metadata(self):
        dt = with_encoding(np.dtype("S10"), "latin-1")
        assert get_encoding(dt) == "latin-1"

    def test_with_encoding_basic(self):
        dt = with_encoding(np.dtype("S10"), "latin-1")
        assert dt.metadata["encoding"] == "latin-1"
        assert dt.itemsize == 10
        assert dt.kind == "S"

    def test_with_encoding_preserves_other_metadata(self):
        dt = np.dtype("S10", metadata={"source": "pybind11"})
        annotated = with_encoding(dt, "latin-1")
        assert annotated.metadata["encoding"] == "latin-1"
        assert annotated.metadata["source"] == "pybind11"

    def test_with_encoding_overwrites_existing(self):
        dt = with_encoding(np.dtype("S10"), "ascii")
        dt2 = with_encoding(dt, "latin-1")
        assert dt2.metadata["encoding"] == "latin-1"

    def test_with_encoding_rejects_structured_dtype(self):
        dt = np.dtype([("name", "S10"), ("value", "f8")])
        with pytest.raises(ValueError, match="scalar dtypes"):
            with_encoding(dt, "utf-8")


class TestRoundtrip:
    def test_encode_then_decode_utf8(self):
        dt = np.dtype([("name", "S20")])
        sa = np.zeros(3, dtype=dt)
        originals = ["Alice", "Bob Smith", "Carol"]
        encode_field(sa, "name", originals)
        decoded = decode_field(sa, "name")
        assert decoded.tolist() == originals

    def test_encode_then_decode_latin1_via_metadata(self):
        name_dt = with_encoding(np.dtype("S20"), "latin-1")
        dt = np.dtype([("city", name_dt)])
        sa = np.zeros(2, dtype=dt)
        originals = ["München", "Zürich"]
        encode_field(sa, "city", originals)
        decoded = decode_field(sa, "city")
        assert decoded.tolist() == originals

    def test_roundtrip_preserves_truncated_prefix(self):
        # When the string overflows, the roundtrip returns the truncated prefix
        dt = np.dtype([("name", "S5")])
        sa = np.zeros(1, dtype=dt)
        encode_field(sa, "name", ["hello world"])
        decoded = decode_field(sa, "name")
        assert decoded[0] == "hello"

    def test_roundtrip_with_paired_length_field(self):
        dt = np.dtype([("name", "S5"), ("name_length", "i4")])
        sa = np.zeros(3, dtype=dt)
        encode_field(sa, "name", ["hi", "hello", "overflowing"], length_field="name_length")
        decoded = decode_field(sa, "name")
        overflow = check_overflow(sa, "name", "name_length")
        assert decoded.tolist() == ["hi", "hello", "overf"]
        assert overflow.tolist() == [False, False, True]
