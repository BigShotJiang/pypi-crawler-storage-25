# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for offset_utils module."""

import numpy as np
import pytest

from vcti.nputils.offset_utils import position_array


class TestPositionArray:
    def test_basic(self):
        counts = np.array([3, 2, 4, 1])
        result = position_array(counts)
        expected = np.array([0, 3, 5, 9, 10])
        assert np.array_equal(result, expected)

    def test_empty_counts(self):
        result = position_array(np.array([], dtype=np.int32))
        assert np.array_equal(result, np.array([0], dtype=np.int32))

    def test_custom_dtype(self):
        counts = np.array([1, 2, 3], dtype=np.int32)
        result = position_array(counts, dtype=np.int64)
        assert result.dtype == np.int64

    def test_single_count(self):
        result = position_array(np.array([5]))
        assert np.array_equal(result, np.array([0, 5]))

    def test_zeros(self):
        result = position_array(np.array([0, 0, 0]))
        assert np.array_equal(result, np.array([0, 0, 0, 0]))

    def test_negative_counts_raises(self):
        with pytest.raises(ValueError, match="non-negative"):
            position_array(np.array([3, -1, 2]))
