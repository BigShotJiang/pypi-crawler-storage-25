# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Version tests for vcti-nputils."""

import re

import vcti.nputils


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.nputils, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.nputils.__version__)
