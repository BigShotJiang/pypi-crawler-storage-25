# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for mapping_utils module."""

import warnings

import numpy as np

from vcti.nputils.mapping_utils import _SPARSE_LOOKUP_THRESHOLD, name_array


class TestNameArray:
    def test_basic_enum_mapping(self):
        enum_dict = {1: "ACTIVE", 2: "INACTIVE", 3: "PENDING"}
        values = np.array([1, 2, 1, 3])
        result = name_array(values, enum_dict)
        expected = np.array(["ACTIVE", "INACTIVE", "ACTIVE", "PENDING"])
        assert np.array_equal(result, expected)

    def test_sequential_from_zero(self):
        enum_dict = {0: "ZERO", 1: "ONE", 2: "TWO", 3: "THREE"}
        values = np.array([0, 3, 1, 2])
        result = name_array(values, enum_dict)
        expected = np.array(["ZERO", "THREE", "ONE", "TWO"])
        assert np.array_equal(result, expected)

    def test_non_sequential_values(self):
        enum_dict = {10: "TEN", 11: "ELEVEN", 12: "TWELVE"}
        values = np.array([10, 12, 11, 10])
        result = name_array(values, enum_dict)
        expected = np.array(["TEN", "TWELVE", "ELEVEN", "TEN"])
        assert np.array_equal(result, expected)

    def test_sparse_values(self):
        enum_dict = {1: "ONE", 5: "FIVE", 9: "NINE"}
        values = np.array([1, 9, 5])
        result = name_array(values, enum_dict)
        expected = np.array(["ONE", "NINE", "FIVE"])
        assert np.array_equal(result, expected)

    def test_missing_values_return_empty(self):
        enum_dict = {1: "ONE", 3: "THREE"}
        values = np.array([1, 2, 3])
        result = name_array(values, enum_dict)
        expected = np.array(["ONE", "", "THREE"])
        assert np.array_equal(result, expected)

    def test_empty_dict(self):
        result = name_array(np.array([1, 2, 3]), {})
        expected = np.full(3, "", dtype="U1")
        assert np.array_equal(result, expected)

    def test_empty_array(self):
        result = name_array(np.array([], dtype=int), {1: "ONE"})
        assert len(result) == 0

    def test_single_element(self):
        result = name_array(np.array([42]), {42: "ANSWER"})
        assert np.array_equal(result, np.array(["ANSWER"]))

    def test_varying_string_lengths(self):
        enum_dict = {1: "A", 2: "MEDIUM", 3: "VERY_LONG_NAME"}
        result = name_array(np.array([1, 2, 3]), enum_dict)
        expected = np.array(["A", "MEDIUM", "VERY_LONG_NAME"])
        assert np.array_equal(result, expected)
        assert result.dtype.itemsize >= len("VERY_LONG_NAME")

    def test_duplicate_values(self):
        enum_dict = {1: "ONE", 2: "TWO"}
        result = name_array(np.array([1, 1, 2, 2, 1]), enum_dict)
        expected = np.array(["ONE", "ONE", "TWO", "TWO", "ONE"])
        assert np.array_equal(result, expected)

    def test_negative_values(self):
        enum_dict = {-2: "NEG_TWO", -1: "NEG_ONE", 0: "ZERO", 1: "ONE"}
        result = name_array(np.array([-2, 0, 1, -1]), enum_dict)
        expected = np.array(["NEG_TWO", "ZERO", "ONE", "NEG_ONE"])
        assert np.array_equal(result, expected)

    def test_out_of_range_values_return_empty(self):
        enum_dict = {1: "ONE", 2: "TWO", 3: "THREE"}
        result = name_array(np.array([0, 1, 5, 3, -1]), enum_dict)
        expected = np.array(["", "ONE", "", "THREE", ""])
        assert np.array_equal(result, expected)

    def test_all_out_of_range(self):
        enum_dict = {10: "TEN", 11: "ELEVEN"}
        result = name_array(np.array([0, 1, 100]), enum_dict)
        expected = np.array(["", "", ""])
        assert np.array_equal(result, expected)

    def test_sparse_enum_warns(self):
        sparse_dict = {0: "ZERO", _SPARSE_LOOKUP_THRESHOLD + 1: "BIG"}
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            name_array(np.array([0]), sparse_dict)
            assert len(w) == 1
            assert "enum key range" in str(w[0].message)

    def test_dense_enum_no_warning(self):
        dense_dict = {i: str(i) for i in range(10)}
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            name_array(np.array([0, 5, 9]), dense_dict)
            assert len(w) == 0

    def test_custom_default(self):
        enum_dict = {1: "ONE", 2: "TWO"}
        result = name_array(np.array([1, 5, 2]), enum_dict, default="UNKNOWN")
        expected = np.array(["ONE", "UNKNOWN", "TWO"])
        assert np.array_equal(result, expected)

    def test_custom_default_for_gaps(self):
        enum_dict = {1: "ONE", 3: "THREE"}
        result = name_array(np.array([1, 2, 3]), enum_dict, default="N/A")
        expected = np.array(["ONE", "N/A", "THREE"])
        assert np.array_equal(result, expected)

    def test_custom_default_empty_dict(self):
        result = name_array(np.array([1, 2]), {}, default="MISSING")
        expected = np.array(["MISSING", "MISSING"])
        assert np.array_equal(result, expected)

    def test_default_dtype_accommodates_long_default(self):
        result = name_array(np.array([1, 99]), {1: "A"}, default="VERY_LONG_DEFAULT")
        assert result[1] == "VERY_LONG_DEFAULT"
