# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for dtype_utils module."""

import numpy as np
import pytest

from vcti.nputils.dtype_utils import (
    flatten_dtype,
    flatten_record_dtype,
    merge_adjacent_fields,
    rename_fields,
    structured_dtype,
)


class TestFlattenDtype:
    def test_basic_flattening(self):
        dt = np.dtype([("id", "i4"), ("values", "f8", (3,))])
        _, cols = flatten_dtype(dt)
        assert cols == ["id", "value_0", "value_1", "value_2"]

    def test_plural_name_stripping(self):
        dt = np.dtype([("values", "f8", (2,))])
        _, cols = flatten_dtype(dt)
        assert cols == ["value_0", "value_1"]

    def test_non_plural_name_preserved(self):
        dt = np.dtype([("data", "f8", (2,))])
        _, cols = flatten_dtype(dt)
        assert cols == ["data_0", "data_1"]

    def test_scalar_fields_unchanged(self):
        dt = np.dtype([("id", "i4"), ("name", "U10")])
        _, cols = flatten_dtype(dt)
        assert cols == ["id", "name"]

    def test_itemsize_preserved(self):
        dt = np.dtype([("id", "i4"), ("values", "f8", (3,))])
        flat_dt, _ = flatten_dtype(dt)
        assert dt.itemsize == flat_dt.itemsize

    def test_all_scalar_fields(self):
        dt = np.dtype([("a", "i4"), ("b", "f8"), ("c", "U5")])
        flat_dt, cols = flatten_dtype(dt)
        assert cols == ["a", "b", "c"]
        assert dt.itemsize == flat_dt.itemsize

    def test_multiple_array_fields(self):
        dt = np.dtype([("coords", "f8", (3,)), ("colors", "u1", (4,))])
        _, cols = flatten_dtype(dt)
        assert cols == [
            "coord_0",
            "coord_1",
            "coord_2",
            "color_0",
            "color_1",
            "color_2",
            "color_3",
        ]

    def test_strip_plural_false(self):
        dt = np.dtype([("values", "f8", (2,))])
        _, cols = flatten_dtype(dt, strip_plural=False)
        assert cols == ["values_0", "values_1"]

    def test_multidimensional_shape(self):
        dt = np.dtype([("matrix", "f8", (2, 3))])
        flat_dt, cols = flatten_dtype(dt)
        assert cols == [
            "matrix_0",
            "matrix_1",
            "matrix_2",
            "matrix_3",
            "matrix_4",
            "matrix_5",
        ]
        assert dt.itemsize == flat_dt.itemsize

    def test_flat_dtype_is_idempotent(self):
        dt = np.dtype([("a", "i4"), ("b", "f8")])
        flat_dt, cols = flatten_dtype(dt)
        assert flat_dt == dt
        assert cols == ["a", "b"]

    # -- Custom naming ---------------------------------------------------------

    def test_field_names_override(self):
        dt = np.dtype([("id", "i4"), ("coords", "f8", (3,))])
        _, cols = flatten_dtype(dt, field_names={"coords": ["x", "y", "z"]})
        assert cols == ["id", "x", "y", "z"]

    def test_field_names_partial(self):
        dt = np.dtype([("coords", "f8", (3,)), ("colors", "u1", (2,))])
        _, cols = flatten_dtype(dt, field_names={"coords": ["x", "y", "z"]})
        # coords uses explicit names; colors falls through to default fmt
        assert cols == ["x", "y", "z", "color_0", "color_1"]

    def test_field_names_wrong_length_raises(self):
        dt = np.dtype([("coords", "f8", (3,))])
        with pytest.raises(ValueError, match="has 2 names but"):
            flatten_dtype(dt, field_names={"coords": ["x", "y"]})

    def test_field_names_unknown_field_raises(self):
        dt = np.dtype([("coords", "f8", (3,))])
        with pytest.raises(ValueError, match="unknown fields"):
            flatten_dtype(dt, field_names={"bogus": ["a"]})

    def test_custom_fmt_bracket(self):
        dt = np.dtype([("coords", "f8", (3,))])
        _, cols = flatten_dtype(dt, fmt="{name}[{dim}]")
        assert cols == ["coord[0]", "coord[1]", "coord[2]"]

    def test_custom_fmt_with_strip_plural_false(self):
        dt = np.dtype([("coords", "f8", (3,))])
        _, cols = flatten_dtype(dt, fmt="{name}[{dim}]", strip_plural=False)
        assert cols == ["coords[0]", "coords[1]", "coords[2]"]

    def test_fmt_without_dim_raises(self):
        dt = np.dtype([("coords", "f8", (3,))])
        with pytest.raises(ValueError, match=r"fmt must contain '\{dim\}'"):
            flatten_dtype(dt, fmt="{name}")

    def test_duplicate_names_raises(self):
        dt = np.dtype([("a", "i4"), ("coords", "f8", (2,))])
        with pytest.raises(ValueError, match="duplicate"):
            flatten_dtype(dt, field_names={"coords": ["a", "b"]})

    def test_record_alias_works(self):
        # Legacy name must still work as an alias.
        dt = np.dtype([("values", "f8", (2,))])
        _, cols = flatten_record_dtype(dt)
        assert cols == ["value_0", "value_1"]


class TestStructuredDtype:
    def test_scalar_dtype(self):
        dt = structured_dtype("f8", ["x", "y", "z"])
        assert dt.names == ("x", "y", "z")
        assert dt["x"] == np.dtype("f8")
        assert dt["y"] == np.dtype("f8")
        assert dt["z"] == np.dtype("f8")

    def test_subdtype_matching_length(self):
        dt = structured_dtype(np.dtype((np.float64, 3)), ["x", "y", "z"])
        assert dt.names == ("x", "y", "z")
        assert dt.itemsize == 3 * 8

    def test_subdtype_mismatched_length_raises(self):
        with pytest.raises(ValueError, match="shape"):
            structured_dtype(np.dtype((np.float64, 3)), ["x", "y"])

    def test_multidim_subdtype(self):
        dt = structured_dtype(
            np.dtype((np.int32, (2, 2))),
            ["a", "b", "c", "d"],
        )
        assert dt.names == ("a", "b", "c", "d")
        assert dt["a"] == np.dtype("i4")

    def test_single_name(self):
        dt = structured_dtype("i8", ["value"])
        assert dt.names == ("value",)

    def test_empty_names_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            structured_dtype("f8", [])

    def test_duplicate_names_raises(self):
        with pytest.raises(ValueError, match="duplicates"):
            structured_dtype("f8", ["x", "x", "y"])

    def test_integer_dtype(self):
        dt = structured_dtype("i4", ["a", "b"])
        assert dt["a"] == np.dtype("i4")
        assert dt["b"] == np.dtype("i4")


class TestRenameFields:
    def test_basic_rename(self):
        dt = np.dtype([("x", "f8"), ("y", "f8")])
        result = rename_fields(dt, {"x": "longitude", "y": "latitude"})
        assert result.names == ("longitude", "latitude")

    def test_partial_rename(self):
        dt = np.dtype([("id", "i4"), ("name", "U10"), ("value", "f8")])
        result = rename_fields(dt, {"name": "label"})
        assert result.names == ("id", "label", "value")

    def test_empty_mapping(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        result = rename_fields(dt, {})
        assert result.names == ("id", "value")

    def test_preserves_dtype_format(self):
        dt = np.dtype([("x", "f8"), ("y", "i4")])
        result = rename_fields(dt, {"x": "a", "y": "b"})
        assert result["a"] == np.dtype("f8")
        assert result["b"] == np.dtype("i4")

    def test_preserves_array_field_shape(self):
        dt = np.dtype([("values", "f8", (3,))])
        result = rename_fields(dt, {"values": "coords"})
        assert result.names == ("coords",)
        assert dt.itemsize == result.itemsize

    def test_missing_field_raises(self):
        dt = np.dtype([("id", "i4")])
        with pytest.raises(KeyError, match="Fields not found"):
            rename_fields(dt, {"missing": "new"})

    def test_non_structured_raises(self):
        dt = np.dtype("f8")
        with pytest.raises(ValueError, match="structured dtype"):
            rename_fields(dt, {"x": "y"})


class TestMergeAdjacentFields:
    def test_merge_two_s4(self):
        dt = np.dtype([("first", "S4"), ("last", "S6"), ("age", "i4")])
        merged = merge_adjacent_fields(dt, ["first", "last"], "name")
        assert merged.names == ("name", "age")
        assert merged["name"] == np.dtype("S10")
        assert merged.itemsize == dt.itemsize

    def test_merge_preserves_position(self):
        dt = np.dtype([("id", "i4"), ("pre", "S2"), ("post", "S3"), ("value", "f8")])
        merged = merge_adjacent_fields(dt, ["pre", "post"], "tag")
        assert merged.names == ("id", "tag", "value")
        assert merged["tag"] == np.dtype("S5")

    def test_merge_is_view_compatible(self):
        # Verify the merged dtype can be used with .view() on an actual array.
        dt = np.dtype([("a", "S3"), ("b", "S2")])
        arr = np.array([(b"Ali", b"ce"), (b"Bob", b"by")], dtype=dt)
        merged = merge_adjacent_fields(dt, ["a", "b"], "name")
        viewed = arr.view(merged)
        assert viewed["name"].tolist() == [b"Alice", b"Bobby"]

    def test_merge_three_fields(self):
        dt = np.dtype([("a", "S1"), ("b", "S2"), ("c", "S3"), ("x", "i4")])
        merged = merge_adjacent_fields(dt, ["a", "b", "c"], "combo")
        assert merged.names == ("combo", "x")
        assert merged["combo"] == np.dtype("S6")

    def test_merge_not_adjacent_raises(self):
        dt = np.dtype([("a", "S4"), ("mid", "i4"), ("b", "S4")])
        with pytest.raises(ValueError, match="not adjacent"):
            merge_adjacent_fields(dt, ["a", "b"], "name")

    def test_merge_non_s_field_raises(self):
        dt = np.dtype([("a", "S4"), ("b", "i4")])
        with pytest.raises(ValueError, match="Only 'S'"):
            merge_adjacent_fields(dt, ["a", "b"], "combo")

    def test_merge_missing_field_raises(self):
        dt = np.dtype([("a", "S4"), ("b", "S4")])
        with pytest.raises(ValueError, match="Fields not found"):
            merge_adjacent_fields(dt, ["a", "missing"], "combo")

    def test_merge_single_field_raises(self):
        dt = np.dtype([("a", "S4"), ("b", "S4")])
        with pytest.raises(ValueError, match="at least two"):
            merge_adjacent_fields(dt, ["a"], "only")

    def test_merge_non_structured_raises(self):
        with pytest.raises(ValueError, match="structured dtype"):
            merge_adjacent_fields(np.dtype("S4"), ["a", "b"], "x")

    def test_new_name_collision_raises(self):
        dt = np.dtype([("a", "S4"), ("b", "S4"), ("existing", "i4")])
        with pytest.raises(ValueError, match="collides"):
            merge_adjacent_fields(dt, ["a", "b"], "existing")
