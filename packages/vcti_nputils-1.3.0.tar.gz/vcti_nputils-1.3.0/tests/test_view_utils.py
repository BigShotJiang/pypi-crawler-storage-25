# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for view_utils module."""

import numpy as np
import pytest

from vcti.nputils.view_utils import drop_fields, fields_view


class TestFieldsView:
    def test_basic_view(self):
        dt = np.dtype([("id", "i4"), ("name", "U10"), ("value", "f8")])
        arr = np.array([(1, "Alice", 1.5), (2, "Bob", 2.5)], dtype=dt)
        view = fields_view(arr, ["id", "value"])
        assert view.dtype.names == ("id", "value")
        assert view[0]["id"] == 1
        assert view[0]["value"] == 1.5

    def test_missing_field_raises(self):
        dt = np.dtype([("id", "i4"), ("name", "U10")])
        arr = np.array([(1, "Alice")], dtype=dt)
        with pytest.raises(KeyError, match="Fields not found"):
            fields_view(arr, ["id", "missing"])

    def test_non_structured_raises(self):
        arr = np.array([1, 2, 3])
        with pytest.raises(ValueError, match="structured dtype"):
            fields_view(arr, ["id"])

    def test_single_field(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5), (2, 2.5)], dtype=dt)
        view = fields_view(arr, ["value"])
        assert view.dtype.names == ("value",)
        assert len(view) == 2

    def test_view_shares_memory(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5), (2, 2.5)], dtype=dt)
        view = fields_view(arr, ["id", "value"])
        view[0]["id"] = 99
        assert arr[0]["id"] == 99

    def test_all_fields(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5), (2, 2.5)], dtype=dt)
        view = fields_view(arr, ["id", "value"])
        assert view.dtype.names == ("id", "value")
        assert np.array_equal(view["id"], arr["id"])
        assert np.array_equal(view["value"], arr["value"])

    def test_subset_fields_preserves_data(self):
        dt = np.dtype([("id", "i4"), ("name", "U10"), ("value", "f8")])
        arr = np.array([(1, "Alice", 1.5), (2, "Bob", 2.5)], dtype=dt)
        view = fields_view(arr, ["value", "id"])
        assert "id" in view.dtype.names
        assert "value" in view.dtype.names
        assert "name" not in view.dtype.names
        assert view[0]["value"] == 1.5
        assert view[0]["id"] == 1


class TestDropFields:
    def test_basic_drop(self):
        dt = np.dtype([("id", "i4"), ("filler", "u1"), ("value", "f8")])
        arr = np.array([(1, 0, 1.5), (2, 0, 2.5)], dtype=dt)
        result = drop_fields(arr, ["filler"])
        assert "id" in result.dtype.names
        assert "value" in result.dtype.names
        assert "filler" not in result.dtype.names

    def test_drop_multiple(self):
        dt = np.dtype([("a", "i4"), ("b", "f8"), ("c", "U5"), ("d", "i4")])
        arr = np.array([(1, 1.5, "x", 10)], dtype=dt)
        result = drop_fields(arr, ["b", "d"])
        assert result.dtype.names == ("a", "c")

    def test_shares_memory(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5), (2, 2.5)], dtype=dt)
        result = drop_fields(arr, ["value"])
        result[0]["id"] = 99
        assert arr[0]["id"] == 99

    def test_missing_field_raises(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5)], dtype=dt)
        with pytest.raises(KeyError, match="Fields not found"):
            drop_fields(arr, ["missing"])

    def test_non_structured_raises(self):
        arr = np.array([1, 2, 3])
        with pytest.raises(ValueError, match="structured dtype"):
            drop_fields(arr, ["id"])

    def test_drop_all_raises(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5)], dtype=dt)
        with pytest.raises(ValueError, match="Cannot exclude all fields"):
            drop_fields(arr, ["id", "value"])

    def test_drop_empty_list(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5), (2, 2.5)], dtype=dt)
        result = drop_fields(arr, [])
        assert result.dtype.names == ("id", "value")

    def test_equivalent_to_fields_view_complement(self):
        dt = np.dtype([("a", "i4"), ("b", "f8"), ("c", "U5")])
        arr = np.array([(1, 1.5, "x"), (2, 2.5, "y")], dtype=dt)
        dropped = drop_fields(arr, ["b"])
        viewed = fields_view(arr, ["a", "c"])
        assert dropped.dtype.names == viewed.dtype.names
        assert np.array_equal(dropped["a"], viewed["a"])
        assert np.array_equal(dropped["c"], viewed["c"])
