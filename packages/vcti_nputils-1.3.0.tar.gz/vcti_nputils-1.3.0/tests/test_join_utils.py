# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for join_utils module."""

import numpy as np
import pytest

from vcti.nputils.join_utils import join_struct_arrays


class TestJoinStructArrays:
    def test_basic_join(self):
        dt1 = np.dtype([("id", "i4"), ("value", "f8")])
        dt2 = np.dtype([("name", "U10")])
        arr1 = np.array([(1, 1.5), (2, 2.5)], dtype=dt1)
        arr2 = np.array([("Alice",), ("Bob",)], dtype=dt2)
        result = join_struct_arrays([arr1, arr2])
        assert result.dtype.names == ("id", "value", "name")
        assert result[0]["id"] == 1
        assert result[0]["name"] == "Alice"

    def test_empty_list_raises(self):
        with pytest.raises(ValueError, match="cannot be empty"):
            join_struct_arrays([])

    def test_three_arrays(self):
        dt1 = np.dtype([("id", "i4")])
        dt2 = np.dtype([("name", "U10")])
        dt3 = np.dtype([("score", "f8")])
        arr1 = np.array([(1,), (2,)], dtype=dt1)
        arr2 = np.array([("Alice",), ("Bob",)], dtype=dt2)
        arr3 = np.array([(95.5,), (87.3,)], dtype=dt3)
        result = join_struct_arrays([arr1, arr2, arr3])
        assert result.dtype.names == ("id", "name", "score")
        assert len(result) == 2

    def test_mismatched_row_count_raises(self):
        dt1 = np.dtype([("id", "i4")])
        dt2 = np.dtype([("name", "U10")])
        arr1 = np.array([(1,), (2,)], dtype=dt1)
        arr2 = np.array([("Alice",), ("Bob",), ("Carol",)], dtype=dt2)
        with pytest.raises(ValueError, match="index 1 has 3 rows, expected 2"):
            join_struct_arrays([arr1, arr2])

    def test_single_array(self):
        dt = np.dtype([("id", "i4"), ("value", "f8")])
        arr = np.array([(1, 1.5), (2, 2.5)], dtype=dt)
        result = join_struct_arrays([arr])
        assert result.dtype.names == ("id", "value")
        assert np.array_equal(result["id"], arr["id"])

    def test_empty_rows(self):
        dt1 = np.dtype([("id", "i4")])
        dt2 = np.dtype([("name", "U10")])
        arr1 = np.array([], dtype=dt1)
        arr2 = np.array([], dtype=dt2)
        result = join_struct_arrays([arr1, arr2])
        assert result.dtype.names == ("id", "name")
        assert len(result) == 0

    def test_duplicate_field_names_raises(self):
        dt1 = np.dtype([("id", "i4"), ("value", "f8")])
        dt2 = np.dtype([("value", "f8"), ("name", "U10")])
        arr1 = np.array([(1, 1.5)], dtype=dt1)
        arr2 = np.array([(2.5, "Alice")], dtype=dt2)
        with pytest.raises(ValueError, match="Duplicate field names"):
            join_struct_arrays([arr1, arr2])

    def test_non_structured_array_raises(self):
        dt = np.dtype([("id", "i4")])
        arr_struct = np.array([(1,), (2,)], dtype=dt)
        arr_plain = np.array([1.5, 2.5])
        with pytest.raises(ValueError, match="does not have a structured dtype"):
            join_struct_arrays([arr_struct, arr_plain])
