# remotedev-agent

Agent daemon for [Remote AI Maestro](https://remote-ai-maestro.thesavvydeveloper.com) -- connects your machine to the platform so you can remotely control AI coding agents (Claude Code, Codex, Aider, Copilot, Cursor) via a browser-based terminal.

## What it does

- Opens tmux-backed PTY sessions that survive disconnects and daemon restarts
- Discovers AI agents available on your machine's PATH
- Streams terminal I/O to the Remote AI Maestro relay over WebSocket
- Manages sandbox directories (create, clone repos, delete)
- Installs as a background service (launchd on macOS, systemd on Linux)

## Requirements

- Python 3.10+
- tmux installed and on PATH
- macOS or Linux

## Installation

```bash
pip install remotedev-agent
```

## Quick start

1. Register a machine on the [Remote AI Maestro dashboard](https://remote-ai-maestro.thesavvydeveloper.com) to get your machine ID and token.

2. Configure the agent:

```bash
remotedev-agent configure \
  --relay-url wss://relay.thesavvydeveloper.com \
  --machine-id YOUR_MACHINE_ID \
  --token YOUR_MACHINE_TOKEN
```

3. Start the agent:

```bash
remotedev-agent start
```

The agent connects to the relay and begins accepting terminal sessions from the web dashboard.

## Interactive setup

If you prefer prompts instead of flags:

```bash
remotedev-agent setup
```

## Install as a background service

```bash
remotedev-agent install-service
```

This creates a launchd plist (macOS) or systemd unit (Linux) so the agent starts automatically on boot.

To remove the service:

```bash
remotedev-agent uninstall-service
```

## Configuration

Config is stored at `~/.remotedev-agent/config.json` with three fields:

| Field | Description |
|-------|-------------|
| `relay_url` | WebSocket URL of the relay server |
| `machine_id` | UUID assigned when you register the machine |
| `token` | Machine authentication token |

## How it works

The agent daemon maintains a persistent WebSocket connection to the Remote AI Maestro relay server. When a user opens a sandbox terminal in their browser, the relay forwards the request to the agent, which creates a tmux-backed PTY session on your machine. All terminal input/output is streamed in real time through the relay.

AI agents (Claude Code, Codex, etc.) are discovered by probing your PATH at startup. Users can invoke any discovered agent from the browser terminal.

## Development

```bash
# Install in editable mode with test dependencies
pip install -e ".[test]"

# Run tests
pytest
```

## License

MIT
