import subprocess
from pathlib import Path


class SandboxManager:
    def __init__(self, sandboxes_root: str):
        self.sandboxes_root = Path(sandboxes_root)

    async def create(self, sandbox_id: str, folder_path: str, github_repo: str | None, branch: str | None):
        path = Path(folder_path).resolve()
        sandboxes_root = self.sandboxes_root.resolve()
        if not str(path).startswith(str(sandboxes_root) + "/") and path != sandboxes_root:
            return {"success": False, "error": f"Path '{folder_path}' is outside sandboxes root"}

        if github_repo:
            # If the folder already exists and has a .git dir, just pull
            if (path / ".git").is_dir():
                result = subprocess.run(
                    ["git", "pull"], cwd=str(path),
                    capture_output=True, text=True, check=False,
                )
                return {"success": True, "path": str(path), "action": "pulled"}

            # If folder exists but isn't a git repo, clone into it
            # git clone won't work into a non-empty dir, so only clone if empty or missing
            if path.exists() and any(path.iterdir()):
                return {"success": True, "path": str(path), "action": "exists"}

            # Clone the repo
            path.parent.mkdir(parents=True, exist_ok=True)
            cmd = ["git", "clone", f"https://github.com/{github_repo}.git", str(path)]
            if branch:
                cmd.extend(["--branch", branch])
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
            if result.returncode != 0:
                return {"success": False, "error": result.stderr}
            return {"success": True, "path": str(path), "action": "cloned"}
        else:
            # No git repo — just ensure the directory exists
            path.mkdir(parents=True, exist_ok=True)
            return {"success": True, "path": str(path), "action": "created"}

    def get_path(self, sandbox_id: str, folder_path: str | None = None) -> str:
        if folder_path:
            return folder_path
        return str(self.sandboxes_root / sandbox_id)
