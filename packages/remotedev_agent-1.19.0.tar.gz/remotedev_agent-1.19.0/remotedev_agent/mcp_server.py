"""``maestro-mcp`` — Model Context Protocol stdio server.

Exposes Maestro features to Claude Code (or any MCP-aware client) as
callable tools. Phase 1 ships a single tool: ``browser_open``. Phase 2
will add navigate / click / type / screenshot.

The server is a thin wrapper over the same Unix-socket protocol the
``maestro`` CLI uses — single source of truth, so a fix to one path
fixes both.

Install: this module imports the official ``mcp`` Python SDK lazily. It
is declared as an optional dependency in pyproject.toml. Install with::

    pip install 'remotedev-agent[mcp]'

If ``mcp`` is not installed, ``main()`` prints a clear error rather than
crashing with an unhelpful ImportError.
"""

from __future__ import annotations

import json
import socket
import sys
from pathlib import Path

from remotedev_agent.ipc_server import SOCKET_PATH
from remotedev_agent.maestro_cli import _current_sandbox_id


def _send_to_daemon(payload: dict) -> dict:
    """Mirror of ``maestro_cli._send_to_daemon`` but raising plain exceptions.

    Click's ``ClickException`` is only safe inside the Click runtime; the
    MCP runtime wants regular exceptions, so we duplicate the small bit
    of I/O glue here.
    """
    if not Path(SOCKET_PATH).exists():
        raise RuntimeError(
            f"Agent IPC socket not found at {SOCKET_PATH}. Is remotedev-agent running?"
        )
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(5.0)
            s.connect(str(SOCKET_PATH))
            s.sendall((json.dumps(payload) + "\n").encode("utf-8"))
            buf = b""
            while b"\n" not in buf:
                chunk = s.recv(4096)
                if not chunk:
                    break
                buf += chunk
            line = buf.split(b"\n", 1)[0]
    except (ConnectionRefusedError, FileNotFoundError) as e:
        raise RuntimeError(f"Could not connect to agent: {e}")
    except socket.timeout:
        raise RuntimeError("Timed out waiting for the agent to reply.")
    reply = json.loads(line.decode("utf-8"))
    if not isinstance(reply, dict):
        raise RuntimeError(f"Agent returned unexpected reply: {reply!r}")
    return reply


def _do_browser_open(url: str, sandbox_id: str | None) -> str:
    """Send a browser_open command and return the user-facing result string."""
    if not (url.startswith("http://") or url.startswith("https://")):
        raise ValueError("URL must start with http:// or https://")
    resolved = sandbox_id or _current_sandbox_id()
    if not resolved:
        raise RuntimeError(
            "No sandbox_id provided and the MCP server is not running inside a "
            "Maestro tmux session. Pass sandbox_id explicitly."
        )
    reply = _send_to_daemon({
        "action": "browser_open",
        "url": url,
        "sandbox_id": resolved,
    })
    if not reply.get("ok"):
        raise RuntimeError(reply.get("error") or "Unknown error")
    return f"Opening {url} in the user's browser."


def _resolve_sandbox_id(sandbox_id: str | None) -> str:
    resolved = sandbox_id or _current_sandbox_id()
    if not resolved:
        raise RuntimeError(
            "No sandbox_id provided and the MCP server is not running inside a "
            "Maestro tmux session. Pass sandbox_id explicitly."
        )
    return resolved


def _do_browser_command(sandbox_id: str | None, payload: dict) -> dict:
    """Send a BROWSER_COMMAND through the Unix socket and return the result dict.

    Raises on failure with the bridge's verbatim error message so the
    MCP client (Claude) sees something actionable in tool-error output.
    """
    resolved = _resolve_sandbox_id(sandbox_id)
    reply = _send_to_daemon({
        "action": "browser_command",
        "sandbox_id": resolved,
        "payload": payload,
    })
    if not reply.get("ok"):
        raise RuntimeError(reply.get("error") or "Browser command failed")
    return reply.get("result") or {}


def main() -> None:
    """Entry point declared in pyproject.toml as ``maestro-mcp``."""
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError:
        print(
            "maestro-mcp requires the 'mcp' Python package.\n"
            "Install with:  pip install 'remotedev-agent[mcp]'",
            file=sys.stderr,
        )
        sys.exit(1)

    mcp = FastMCP("maestro")

    @mcp.tool()
    def browser_open(url: str, sandbox_id: str | None = None) -> str:
        """Open a URL in the user's local browser.

        Sends a BROWSER_OPEN command through the Remote AI Maestro relay
        to the user's workspace UI, which calls window.open(url) on
        receipt. Works regardless of whether the sandbox runs locally or
        on EC2 — the URL always opens in the user's actual browser
        (where they have the workspace open).

        Args:
            url: HTTP or HTTPS URL to open.
            sandbox_id: Optional. Defaults to the current tmux session's
                sandbox_id if the MCP server is running inside a Maestro
                tmux session.

        Returns:
            Confirmation string.
        """
        return _do_browser_open(url, sandbox_id)

    # --- Bridge-driven tools (require maestro-browser-bridge running) ---

    @mcp.tool()
    def browser_navigate(
        url: str,
        new_tab: bool = False,
        tab_id: str | None = None,
        sandbox_id: str | None = None,
    ) -> dict:
        """Navigate the bridge tab to URL and return {tab_id, url, title}.

        Requires the maestro-browser-bridge daemon to be running on the
        user's laptop. Use ``new_tab=True`` to spawn an additional tab
        instead of replacing the per-sandbox default tab.
        """
        if not (url.startswith("http://") or url.startswith("https://")):
            raise ValueError("URL must start with http:// or https://")
        payload: dict = {"action": "navigate", "url": url, "new_tab": new_tab}
        if tab_id:
            payload["tab_id"] = tab_id
        result = _do_browser_command(sandbox_id, payload)
        return {
            "tab_id": tab_id or _resolve_sandbox_id(sandbox_id),
            "url": result.get("current_url"),
            "title": result.get("title"),
        }

    @mcp.tool()
    def browser_click(
        selector: str,
        tab_id: str | None = None,
        sandbox_id: str | None = None,
    ) -> dict:
        """Click the element matching ``selector`` (CSS) on the bridge tab."""
        payload: dict = {"action": "click", "selector": selector}
        if tab_id:
            payload["tab_id"] = tab_id
        result = _do_browser_command(sandbox_id, payload)
        return {"ok": True, "url": result.get("current_url"), "title": result.get("title")}

    @mcp.tool()
    def browser_type(
        selector: str,
        text: str,
        tab_id: str | None = None,
        sandbox_id: str | None = None,
    ) -> dict:
        """Focus ``selector`` and type ``text`` character-by-character."""
        payload: dict = {"action": "type", "selector": selector, "text": text}
        if tab_id:
            payload["tab_id"] = tab_id
        _do_browser_command(sandbox_id, payload)
        return {"ok": True}

    @mcp.tool()
    def browser_screenshot(
        full_page: bool = False,
        tab_id: str | None = None,
        sandbox_id: str | None = None,
    ) -> dict:
        """Capture a PNG screenshot of the bridge tab.

        Returns ``{base64_png: <str>}``. Use ``full_page=True`` to
        capture the entire scrollable height (slower, much larger).
        """
        payload: dict = {"action": "screenshot", "full_page": full_page}
        if tab_id:
            payload["tab_id"] = tab_id
        result = _do_browser_command(sandbox_id, payload)
        b64 = result.get("screenshot_b64")
        if not isinstance(b64, str) or not b64:
            raise RuntimeError("Bridge returned no screenshot_b64")
        return {"base64_png": b64}

    @mcp.tool()
    def browser_read_dom(
        selector: str | None = None,
        tab_id: str | None = None,
        sandbox_id: str | None = None,
    ) -> dict:
        """Return outerHTML for ``selector`` (or whole page when omitted).

        Capped at 1MB on the bridge side — large pages are truncated
        rather than fragmented.
        """
        payload: dict = {"action": "read_dom"}
        if selector:
            payload["selector"] = selector
        if tab_id:
            payload["tab_id"] = tab_id
        result = _do_browser_command(sandbox_id, payload)
        return {"html": result.get("dom_snippet") or ""}

    @mcp.tool()
    def browser_console_logs(
        since_ts: float | None = None,
        tab_id: str | None = None,
        sandbox_id: str | None = None,
    ) -> dict:
        """Drain buffered console messages newer than ``since_ts``.

        Returns ``{logs: [{ts, level, text, url?}, ...]}``.
        """
        payload: dict = {"action": "console_logs"}
        if tab_id:
            payload["tab_id"] = tab_id
        if since_ts is not None:
            payload["since_ts"] = since_ts
        result = _do_browser_command(sandbox_id, payload)
        return {"logs": result.get("console_logs") or []}

    @mcp.tool()
    def browser_list_tabs(sandbox_id: str | None = None) -> dict:
        """List every tab the bridge currently has open."""
        result = _do_browser_command(sandbox_id, {"action": "list_tabs"})
        # BC.1.2 carries the tab list through the console_logs slot.
        return {"tabs": result.get("console_logs") or []}

    mcp.run()


if __name__ == "__main__":
    main()
