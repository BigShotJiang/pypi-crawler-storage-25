import getpass
import platform
import subprocess

KNOWN_AGENTS = {
    "claude": ["claude", "--version"],
    "codex": ["codex", "--version"],
    "aider": ["aider", "--version"],
    "copilot": ["copilot", "--version"],
    "cursor": ["cursor", "--version"],
}


def discover_agents() -> list[str]:
    available = []
    for name, check_cmd in KNOWN_AGENTS.items():
        try:
            result = subprocess.run(check_cmd, capture_output=True, timeout=3, check=False)
            if result.returncode == 0:
                available.append(name)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    return available


def get_os_info() -> dict:
    return {
        "os": platform.system(),
        "arch": platform.machine(),
        "hostname": platform.node(),
        "user": getpass.getuser(),
        "python": platform.python_version(),
    }
