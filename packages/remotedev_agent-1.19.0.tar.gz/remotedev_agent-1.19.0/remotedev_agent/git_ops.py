import subprocess


def get_status(folder_path: str) -> dict:
    try:
        branch = subprocess.run(
            ["git", "branch", "--show-current"],
            cwd=folder_path, capture_output=True, text=True, check=True,
        ).stdout.strip()

        # NOTE: do NOT .strip() the whole output — porcelain rows use
        # column-based status flags where the leading char of " M file"
        # (modified-but-not-staged) is a single space. Stripping the whole
        # blob removes that space from the first row and the parser
        # misclassifies it as staged.
        status_output = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=folder_path, capture_output=True, text=True, check=True,
        ).stdout

        modified = []
        untracked = []
        staged = []
        for line in status_output.splitlines():
            if len(line) < 3:
                continue
            if line.startswith("??"):
                untracked.append(line[3:])
            elif line[0] != " ":
                staged.append(line[3:])
            elif line[1] != " ":
                modified.append(line[3:])

        return {
            "branch": branch,
            "modified": modified,
            "untracked": untracked,
            "staged": staged,
        }
    except subprocess.CalledProcessError:
        return {"error": "Not a git repository"}
