"""Remote AI Maestro agent daemon."""

__version__ = "1.0.0"
