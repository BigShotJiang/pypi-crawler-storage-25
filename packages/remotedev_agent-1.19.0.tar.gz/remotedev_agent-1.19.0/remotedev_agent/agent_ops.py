"""Non-interactive AI-agent helpers for the W8 AGENT_ASK flow.

The terminal-routed ``AGENT_PROMPT`` path streams keystrokes into a PTY
running an interactive agent. ``AGENT_ASK`` is different — it spawns a
*one-shot* invocation of the underlying CLI, captures stdout, and hands
the response back as a single message. This is the surface a future
"Ask Claude" chat panel will hang off.

Each supported CLI has a tiny config block describing which arguments
flip it into non-interactive mode. We intentionally pin the list to
``claude`` for now: ``codex``'s non-interactive interface has shifted
across releases and ``aider``'s ``--message`` mode also opens an editor
unless several other flags are set. Treating those as "not yet
supported" is safer than guessing — the browser will display a clean
error and the user can fall back to the terminal.
"""
from __future__ import annotations

import shutil
import subprocess

# Hard cap on response bytes — matches the file-read cap so the
# WebSocket payload stays bounded regardless of which agent answers.
MAX_RESPONSE_BYTES = 100_000
ASK_TIMEOUT_SECONDS = 120

# Each entry: command name -> (argv builder, requires-PATH). The argv
# builder takes the prompt string and returns the argv to subprocess.run.
# Keeping this as a dict makes it trivial to drop in additional agents
# (codex, aider) once their non-interactive contracts are stable.
_NON_INTERACTIVE_AGENTS = {
    # `claude -p <prompt>` prints the answer to stdout and exits 0.
    # Confirmed by the W8 plan note and the existing terminal usage.
    "claude": lambda prompt: ["claude", "-p", prompt],
}


def supported_agents() -> list[str]:
    """Return the agents we know how to run non-interactively.

    Exposed so callers (and tests) can ask "is `claude` supported?"
    without poking the private dict.
    """
    return list(_NON_INTERACTIVE_AGENTS.keys())


def run_agent_ask(prompt: str, agent: str, *, cwd: str | None = None) -> dict:
    """Run a one-shot prompt against ``agent`` and return its stdout.

    Returns ``{content: str, error?: str, truncated?: bool}``.
    Errors are never raised across the WebSocket boundary — they come
    back in the ``error`` field so the frontend can render them inline.
    """
    if not isinstance(prompt, str) or not prompt.strip():
        return {"content": "", "error": "Missing prompt"}

    if agent not in _NON_INTERACTIVE_AGENTS:
        # Be specific: list what we do support so the UI can hint at
        # falling back to AGENT_PROMPT (PTY) for the unsupported agent.
        return {"content": "", "error": f"Agent '{agent}' does not support one-shot mode (supported: {', '.join(supported_agents())})"}

    cmd_builder = _NON_INTERACTIVE_AGENTS[agent]
    argv = cmd_builder(prompt)

    # Confirm the binary is actually on PATH before subprocess.run so the
    # error message is "not installed" rather than the generic FileNotFoundError.
    if shutil.which(argv[0]) is None:
        return {"content": "", "error": f"Agent '{agent}' not installed on this machine"}

    try:
        result = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=ASK_TIMEOUT_SECONDS,
            cwd=cwd,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {"content": "", "error": f"Agent '{agent}' timed out after {ASK_TIMEOUT_SECONDS}s"}
    except OSError as e:
        return {"content": "", "error": f"Failed to invoke '{agent}': {e}"}

    stdout = result.stdout or ""
    truncated = False
    encoded = stdout.encode("utf-8", errors="replace")
    if len(encoded) > MAX_RESPONSE_BYTES:
        # Truncate on a byte boundary, then decode with replacement so we
        # never split a multi-byte codepoint mid-sequence.
        encoded = encoded[:MAX_RESPONSE_BYTES]
        stdout = encoded.decode("utf-8", errors="replace")
        truncated = True

    response: dict = {"content": stdout}
    if truncated:
        response["truncated"] = True
    if result.returncode != 0:
        # Surface stderr (first line, trimmed) so the user knows why it failed.
        err = (result.stderr or "").strip().splitlines()
        response["error"] = err[0][:500] if err else f"Agent exited with code {result.returncode}"
    return response
