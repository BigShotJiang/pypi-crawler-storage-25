import json
import os
from dataclasses import dataclass
from pathlib import Path

CONFIG_DIR = Path.home() / ".remotedev"
CONFIG_FILE = CONFIG_DIR / "config.json"


@dataclass
class AgentConfig:
    relay_url: str
    machine_id: str
    token: str
    sandboxes_root: str = ""

    def __post_init__(self):
        if not self.sandboxes_root:
            self.sandboxes_root = str(Path.home() / "Documents")

    def save(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        os.chmod(CONFIG_DIR, 0o700)
        CONFIG_FILE.write_text(json.dumps({
            "relay_url": self.relay_url,
            "machine_id": self.machine_id,
            "token": self.token,
            "sandboxes_root": self.sandboxes_root,
        }, indent=2))
        os.chmod(CONFIG_FILE, 0o600)

    @classmethod
    def load(cls) -> "AgentConfig":
        if not CONFIG_FILE.exists():
            raise FileNotFoundError(f"Config not found at {CONFIG_FILE}. Run 'remotedev-agent setup' first.")
        data = json.loads(CONFIG_FILE.read_text())
        return cls(**data)
