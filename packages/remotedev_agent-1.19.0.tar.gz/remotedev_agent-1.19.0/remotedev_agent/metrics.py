"""Machine utilization metrics emitted on each PONG.

Each field is independently resilient — if `psutil` blows up resolving one
component (e.g. a disk path that doesn't exist) we return ``None`` for that
field rather than dropping the whole payload. This keeps the read endpoint
useful on partially-unhealthy machines.

`psutil.cpu_percent(interval=None)` returns the CPU usage between the last
call and now. The very first call always returns 0.0, so we prime it at
import time — subsequent calls (every ~30s on PONG) yield real values.
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path
from typing import Any

try:
    import psutil  # type: ignore
except ImportError:  # pragma: no cover — psutil is a hard dep
    psutil = None  # type: ignore

logger = logging.getLogger("remotedev_agent.metrics")

# Prime the non-blocking CPU sampler so the first real call (in metrics())
# returns a usage delta instead of 0.0. Safe to call at import time even
# when psutil isn't installed — guarded above.
if psutil is not None:
    try:
        psutil.cpu_percent(interval=None)
    except Exception:  # pragma: no cover
        pass


def _safe(fn) -> Any:
    """Run ``fn`` and return None on any exception.

    A failing field shouldn't blank the whole metrics payload — e.g. a
    container without /proc/loadavg or a sandboxes_root that no longer
    exists shouldn't suppress CPU/RAM readings.
    """
    try:
        return fn()
    except Exception as e:
        logger.debug("metrics_field_failed", extra={"error": str(e)})
        return None


def _resolve_disk_root(sandboxes_root: str | None) -> str:
    """Best-effort disk path: configured sandboxes_root, else ~/Documents."""
    candidate = sandboxes_root or str(Path.home() / "Documents")
    p = Path(candidate)
    if not p.exists():
        # Fall back to home dir which always exists on a healthy box.
        return str(Path.home())
    return str(p)


def metrics(sandboxes_root: str | None = None, session_count: int = 0) -> dict:
    """Return a snapshot of machine utilization.

    Args:
        sandboxes_root: Path to measure disk usage against. Falls back to
            ``~/Documents`` (same default as ``AgentConfig.sandboxes_root``).
        session_count: Number of live tmux/PTY sessions tracked by the
            agent. Caller supplies this — metrics module doesn't peek at
            the daemon's state directly.
    """
    if psutil is None:
        return {
            "cpu_pct": None,
            "ram_pct": None,
            "disk_pct": None,
            "load_1m": None,
            "uptime_s": None,
            "sessions": session_count,
        }

    disk_path = _resolve_disk_root(sandboxes_root)

    return {
        "cpu_pct": _safe(lambda: psutil.cpu_percent(interval=None)),
        "ram_pct": _safe(lambda: psutil.virtual_memory().percent),
        "disk_pct": _safe(lambda: psutil.disk_usage(disk_path).percent),
        "load_1m": _safe(lambda: os.getloadavg()[0]) if hasattr(os, "getloadavg") else None,
        "uptime_s": _safe(lambda: int(time.time() - psutil.boot_time())),
        "sessions": session_count,
    }
