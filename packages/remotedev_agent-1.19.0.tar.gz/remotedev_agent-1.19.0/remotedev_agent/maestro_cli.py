"""``maestro`` CLI — sandbox-side entry point for talking to the agent.

Phase 1 ships a single subcommand: ``maestro browser open <url>`` which
sends a ``BROWSER_OPEN`` to the user's connected browser via the agent's
WebSocket → relay → frontend path. The frontend handler calls
``window.open(url, '_blank')`` on receipt.

The CLI is intentionally small. It:
  1. Resolves the current sandbox_id by reading ``tmux display-message``.
  2. Opens a Unix socket to the agent daemon (``~/.remotedev/agent.sock``).
  3. Writes a JSON command, reads the JSON reply.

Failure modes are surfaced as actionable messages — not stack traces —
because most users hit this from an interactive shell.
"""

import json
import os
import socket
import subprocess
import sys
from pathlib import Path

import click

from remotedev_agent.ipc_server import SOCKET_PATH

# Same prefix the agent uses for tmux session naming (pty_manager.TMUX_PREFIX).
# Duplicated here as a literal to keep the CLI dependency-light — importing
# pty_manager pulls in ptyprocess which is heavy for a one-shot CLI.
_TMUX_SESSION_PREFIX = "remotedev-"


def _package_version() -> str:
    try:
        from importlib.metadata import version as _v
        return _v("remotedev-agent")
    except Exception:
        return "unknown"


def _current_sandbox_id() -> str | None:
    """Return the sandbox_id of the tmux session this process is inside.

    Returns ``None`` if the CLI is not running inside a Maestro-managed
    tmux session (e.g. user is in a plain shell). The agent's tmux
    sessions are always named ``remotedev-<sandbox_id>`` — we ask tmux
    for the current session name and strip the prefix.
    """
    if not os.environ.get("TMUX"):
        return None
    try:
        result = subprocess.run(
            ["tmux", "display-message", "-p", "#S"],
            capture_output=True, text=True, timeout=2,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    if result.returncode != 0:
        return None
    name = result.stdout.strip()
    if not name.startswith(_TMUX_SESSION_PREFIX):
        return None
    return name[len(_TMUX_SESSION_PREFIX):]


def _send_to_daemon(payload: dict) -> dict:
    """Connect to the agent IPC socket, send one command, return the reply.

    Raises ``ClickException`` with a user-readable message on any I/O
    failure — the calling command shouldn't have to think about errno.
    """
    if not Path(SOCKET_PATH).exists():
        raise click.ClickException(
            f"Agent IPC socket not found at {SOCKET_PATH}.\n"
            "Is the remotedev-agent daemon running on this machine?\n"
            "Check with:  remotedev-agent status"
        )

    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as s:
            s.settimeout(5.0)
            s.connect(str(SOCKET_PATH))
            s.sendall((json.dumps(payload) + "\n").encode("utf-8"))
            # Read until newline — replies are always a single JSON line.
            buf = b""
            while b"\n" not in buf:
                chunk = s.recv(4096)
                if not chunk:
                    break
                buf += chunk
            line = buf.split(b"\n", 1)[0]
    except (ConnectionRefusedError, FileNotFoundError) as e:
        raise click.ClickException(
            f"Could not connect to agent IPC socket: {e}.\n"
            "The agent daemon may be stopped — try 'remotedev-agent status'."
        )
    except socket.timeout:
        raise click.ClickException("Timed out waiting for the agent to reply.")
    except OSError as e:
        raise click.ClickException(f"Agent IPC error: {e}")

    try:
        reply = json.loads(line.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise click.ClickException(f"Agent returned malformed reply: {e}")
    if not isinstance(reply, dict):
        raise click.ClickException(f"Agent returned unexpected reply: {reply!r}")
    return reply


@click.group()
@click.version_option(version=_package_version(), prog_name="maestro")
def cli():
    """Maestro — sandbox-side CLI for Remote AI Maestro features."""


@cli.group()
def browser():
    """Browser control commands."""


def _resolve_sandbox_id(override: str | None) -> str:
    """Resolve sandbox_id: explicit override > tmux session > raise."""
    resolved = override or _current_sandbox_id()
    if not resolved:
        raise click.ClickException(
            "Could not detect sandbox_id from tmux.\n"
            "Run this from inside a Maestro sandbox terminal, or pass\n"
            "  --sandbox-id <uuid>  explicitly."
        )
    return resolved


def _send_browser_command(sandbox_id: str, payload: dict) -> dict:
    """Send a BROWSER_COMMAND through the IPC socket and return the result dict.

    Centralized here so every subcommand has identical error-handling.
    The IPC server's ``browser_command`` action returns a dict with:
      ``{ok, command_id, result: <bridge payload>, error}``.
    On ``ok=False`` we raise ``ClickException`` with the bridge's message
    so the user sees actionable text.
    """
    reply = _send_to_daemon({
        "action": "browser_command",
        "sandbox_id": sandbox_id,
        "payload": payload,
    })
    if not reply.get("ok"):
        # ``error`` may come from the IPC layer, the relay, or the bridge.
        # All three are surfaced verbatim — they're all human-readable.
        raise click.ClickException(reply.get("error") or "Browser command failed")
    return reply.get("result") or {}


@browser.command("open")
@click.argument("url")
@click.option(
    "--sandbox-id", default=None,
    help="Override the sandbox_id (defaults to current tmux session).",
)
def browser_open(url: str, sandbox_id: str | None):
    """Open URL in the user's local browser.

    Routes the request through the agent → relay → user's workspace UI,
    which calls window.open(url) on receipt. The URL opens in whichever
    browser the user has the workspace open in.
    """
    if not (url.startswith("http://") or url.startswith("https://")):
        raise click.ClickException("URL must start with http:// or https://")

    resolved_sandbox = _resolve_sandbox_id(sandbox_id)

    reply = _send_to_daemon({
        "action": "browser_open",
        "url": url,
        "sandbox_id": resolved_sandbox,
    })
    if not reply.get("ok"):
        raise click.ClickException(reply.get("error") or "Unknown error")
    click.echo(f"Opening {url} in your browser…")


# --- Bridge-driven subcommands (require maestro-browser-bridge running) ---


@browser.command("navigate")
@click.argument("url")
@click.option("--tab-id", default=None, help="Override the per-sandbox default tab.")
@click.option("--new-tab/--same-tab", default=False, help="Mint a fresh tab.")
@click.option("--sandbox-id", default=None, help="Override sandbox_id.")
def browser_navigate(url: str, tab_id: str | None, new_tab: bool, sandbox_id: str | None):
    """Navigate the bridge tab to URL."""
    if not (url.startswith("http://") or url.startswith("https://")):
        raise click.ClickException("URL must start with http:// or https://")
    resolved = _resolve_sandbox_id(sandbox_id)
    payload = {"action": "navigate", "url": url, "new_tab": new_tab}
    if tab_id:
        payload["tab_id"] = tab_id
    result = _send_browser_command(resolved, payload)
    click.echo(f"{result.get('current_url', url)}  —  {result.get('title') or ''}".rstrip(" —"))


@browser.command("click")
@click.argument("selector")
@click.option("--tab-id", default=None)
@click.option("--sandbox-id", default=None)
def browser_click(selector: str, tab_id: str | None, sandbox_id: str | None):
    """Click the element matching SELECTOR (CSS) on the bridge tab."""
    resolved = _resolve_sandbox_id(sandbox_id)
    payload = {"action": "click", "selector": selector}
    if tab_id:
        payload["tab_id"] = tab_id
    result = _send_browser_command(resolved, payload)
    click.echo(f"clicked — {result.get('current_url') or ''}")


@browser.command("type")
@click.argument("selector")
@click.argument("text")
@click.option("--tab-id", default=None)
@click.option("--sandbox-id", default=None)
def browser_type(selector: str, text: str, tab_id: str | None, sandbox_id: str | None):
    """Focus SELECTOR and type TEXT character-by-character."""
    resolved = _resolve_sandbox_id(sandbox_id)
    payload = {"action": "type", "selector": selector, "text": text}
    if tab_id:
        payload["tab_id"] = tab_id
    _send_browser_command(resolved, payload)
    click.echo("typed")


@browser.command("screenshot")
@click.option("--tab-id", default=None)
@click.option("--full-page", is_flag=True, help="Capture the full scrollable page.")
@click.option(
    "--output", "-o", type=click.Path(dir_okay=False, writable=True),
    default=None, help="Write PNG to FILE instead of base64 to stdout.",
)
@click.option("--sandbox-id", default=None)
def browser_screenshot(
    tab_id: str | None,
    full_page: bool,
    output: str | None,
    sandbox_id: str | None,
):
    """Capture a screenshot of the bridge tab.

    Without ``--output`` the base64 PNG goes to stdout — pipe to
    ``base64 -d > shot.png`` to save.
    """
    resolved = _resolve_sandbox_id(sandbox_id)
    payload = {"action": "screenshot", "full_page": full_page}
    if tab_id:
        payload["tab_id"] = tab_id
    result = _send_browser_command(resolved, payload)
    b64 = result.get("screenshot_b64")
    if not isinstance(b64, str) or not b64:
        raise click.ClickException("Bridge returned no screenshot_b64")
    if output:
        import base64 as _b64
        Path(output).write_bytes(_b64.b64decode(b64))
        click.echo(f"wrote {output}")
    else:
        click.echo(b64)


@browser.command("read-dom")
@click.option("--selector", default=None, help="Selector to read (omit for whole page).")
@click.option("--tab-id", default=None)
@click.option("--sandbox-id", default=None)
def browser_read_dom(selector: str | None, tab_id: str | None, sandbox_id: str | None):
    """Return outerHTML for SELECTOR (or whole page if omitted)."""
    resolved = _resolve_sandbox_id(sandbox_id)
    payload: dict = {"action": "read_dom"}
    if selector:
        payload["selector"] = selector
    if tab_id:
        payload["tab_id"] = tab_id
    result = _send_browser_command(resolved, payload)
    click.echo(result.get("dom_snippet") or "")


@browser.command("console-logs")
@click.option("--tab-id", default=None)
@click.option("--since-ts", type=float, default=None, help="Only return logs newer than ts.")
@click.option("--sandbox-id", default=None)
def browser_console_logs(
    tab_id: str | None, since_ts: float | None, sandbox_id: str | None
):
    """Drain buffered console messages from the bridge tab."""
    resolved = _resolve_sandbox_id(sandbox_id)
    payload: dict = {"action": "console_logs"}
    if tab_id:
        payload["tab_id"] = tab_id
    if since_ts is not None:
        payload["since_ts"] = since_ts
    result = _send_browser_command(resolved, payload)
    logs = result.get("console_logs") or []
    if not logs:
        click.echo("(no console logs)")
        return
    for entry in logs:
        ts = entry.get("ts", "?")
        level = entry.get("level", "log")
        text = entry.get("text", "")
        click.echo(f"[{ts}] {level}: {text}")


@browser.command("list-tabs")
@click.option("--sandbox-id", default=None)
def browser_list_tabs(sandbox_id: str | None):
    """Print all tabs the bridge knows about."""
    resolved = _resolve_sandbox_id(sandbox_id)
    result = _send_browser_command(resolved, {"action": "list_tabs"})
    # BC.1.2 smuggles the tab list through the console_logs slot.
    tabs = result.get("console_logs") or []
    if not tabs:
        click.echo("(no tabs open)")
        return
    for t in tabs:
        click.echo(f"{t.get('tab_id'):<32}  {t.get('url'):<60}  {t.get('title') or ''}")


if __name__ == "__main__":
    cli()
