import asyncio
import hashlib
import hmac
import json
import random
import re
import signal
import socket
import subprocess
import time
from pathlib import Path
from urllib.parse import urlparse

import websockets

from remotedev_agent.config import AgentConfig
from remotedev_agent.discovery import discover_agents, get_os_info
from remotedev_agent.agent_ops import run_agent_ask
from remotedev_agent.file_ops import (
    list_directory as files_list_directory,
    read_file as files_read_file,
    search_files as files_search_files,
    write_file as files_write_file,
)
from remotedev_agent.git_ops import get_status as git_get_status
from remotedev_agent.ipc_server import IPCServer
from remotedev_agent.metrics import metrics as collect_metrics
from remotedev_agent.pty_manager import PTYManager, PTYSession, _tmux_session_exists, _capture_tmux_scrollback, TMUX_PREFIX, check_tmux
from remotedev_agent.sandbox_manager import SandboxManager

# 1.1: Whitelist of allowed agent commands
ALLOWED_AGENT_COMMANDS = {"claude", "codex", "aider", "copilot", "cursor"}
MAX_AGENT_CMD_ARGS = 5


class AgentDaemon:
    def __init__(self, config: AgentConfig):
        self.config = config
        self.ws = None
        self.reconnect_delay = 1
        # Tracks consecutive failures whose root cause is a stalled handshake
        # (TCP/TLS connect or HTTP Upgrade). After enough of these we assume
        # DNS or routing state is stale and force a fresh resolution.
        self._consecutive_handshake_failures = 0
        check_tmux()
        self.pty_manager = PTYManager()
        self.sandbox_manager = SandboxManager(config.sandboxes_root)
        # Local IPC server for the `maestro` CLI / `maestro-mcp` server.
        # Started once in ``run()`` and survives WS reconnects so a sandbox
        # CLI can produce a useful error ("machine offline") instead of
        # hanging or failing silently when the relay is unreachable.
        self.ipc_server = IPCServer(self)
        # Pending BROWSER_COMMAND futures, keyed by command_id. The IPC
        # server registers a future when it sends a BROWSER_COMMAND and
        # the daemon's BROWSER_RESULT handler completes it. The future
        # carries the parsed result-payload dict.
        self.pending_browser_commands: dict[str, asyncio.Future] = {}

    def _validate_path(self, folder_path: str) -> Path:
        """1.2: Validate that folder_path is under sandboxes_root. Prevents path traversal."""
        resolved = Path(folder_path).resolve()
        sandboxes_root = Path(self.sandbox_manager.sandboxes_root).resolve()
        if not str(resolved).startswith(str(sandboxes_root) + "/") and resolved != sandboxes_root:
            raise ValueError(f"Path '{folder_path}' is outside sandboxes root '{sandboxes_root}'")
        return resolved

    async def run(self):
        # Install graceful-shutdown handlers so launchd/systemd SIGTERM and
        # detach-mode SIGTERM both unwind asyncio cleanly instead of os._exit.
        loop = asyncio.get_running_loop()
        self._stop_event = asyncio.Event()
        self._main_task = asyncio.current_task()

        def _signal_shutdown():
            self._stop_event.set()
            # Cancel the in-flight await so a long sleep / blocked socket read
            # doesn't keep us alive past launchd's grace period.
            if self._main_task is not None:
                self._main_task.cancel()

        for sig in (signal.SIGTERM, signal.SIGINT):
            try:
                loop.add_signal_handler(sig, _signal_shutdown)
            except (NotImplementedError, RuntimeError):
                pass

        async def _interruptible_sleep(seconds: float) -> None:
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=seconds)
            except asyncio.TimeoutError:
                pass

        # IPC server runs across the entire daemon lifetime — not per-WS —
        # so the CLI can respond cleanly even when the agent is between
        # reconnects ("machine offline" instead of "connection refused").
        try:
            await self.ipc_server.start()
        except Exception as e:
            # Don't crash the daemon if the IPC server can't bind — the WS
            # path still works without it. Surface the error so users can
            # debug; the CLI will fail with "connection refused" later.
            print(f"[IPC] Failed to start IPC server: {e}")

        consecutive_failures = 0
        circuit_open_until = 0
        while not self._stop_event.is_set():
            try:
                # Circuit breaker: skip reconnect attempts during cooldown
                now = time.time()
                if now < circuit_open_until:
                    await _interruptible_sleep(1)
                    continue
                # Reload config from disk before every connect attempt so the
                # agent picks up a token rotation (or relay URL change) without
                # requiring a process restart. If the config is missing or
                # malformed we keep the in-memory copy and continue.
                try:
                    self.config = AgentConfig.load()
                except FileNotFoundError:
                    pass
                except Exception as e:
                    print(f"[CONFIG] Could not reload config (using cached): {e}")
                await self.connect()
                consecutive_failures = 0  # Reset on successful connection
                self._consecutive_handshake_failures = 0
            except asyncio.CancelledError:
                # Triggered by the signal handler — fall out of the loop.
                if self._stop_event.is_set():
                    break
                raise
            except (asyncio.TimeoutError, websockets.exceptions.InvalidHandshake, websockets.exceptions.InvalidStatusCode, OSError) as e:
                # Looks like a transport-level failure — likely TCP connect,
                # TLS, or HTTP Upgrade stuck. After a few of these in a row,
                # force a fresh DNS lookup so a stale Cloudflare edge IP
                # cached during a VPN session isn't reused indefinitely.
                self._consecutive_handshake_failures += 1
                consecutive_failures += 1
                if self._consecutive_handshake_failures >= 3:
                    self._refresh_dns_cache()
                    self._consecutive_handshake_failures = 0
                if consecutive_failures >= 20:
                    print(f"Circuit breaker open: {consecutive_failures} consecutive failures. Cooling down 5m...")
                    circuit_open_until = time.time() + 300
                    consecutive_failures = 0
                jitter = random.uniform(0, self.reconnect_delay * 0.5)
                delay = self.reconnect_delay + jitter
                print(f"[CONNECT] Handshake/transport error ({type(e).__name__}): {e}. Reconnecting in {delay:.1f}s...")
                await _interruptible_sleep(delay)
                self.reconnect_delay = min(self.reconnect_delay * 2, 30)
            except Exception as e:
                consecutive_failures += 1
                if consecutive_failures >= 20:
                    print(f"Circuit breaker open: {consecutive_failures} consecutive failures. Cooling down 5m...")
                    circuit_open_until = time.time() + 300
                    consecutive_failures = 0
                # Add jitter to prevent thundering herd
                jitter = random.uniform(0, self.reconnect_delay * 0.5)
                delay = self.reconnect_delay + jitter
                print(f"Connection lost: {e}. Reconnecting in {delay:.1f}s...")
                await _interruptible_sleep(delay)
                # Cap at 30s (was 60s). Combined with TCP keepalive and the
                # tighter 15s/10s ping settings, worst-case recovery from a
                # network hiccup is ~30s rather than 60–90s.
                self.reconnect_delay = min(self.reconnect_delay * 2, 30)

        # Stop event reached — tear down the IPC server cleanly so the
        # socket file is removed (next daemon start sees a clean slate).
        try:
            await self.ipc_server.stop()
        except Exception as e:
            print(f"[IPC] Stop failed (ignoring): {e}")

    def _refresh_dns_cache(self):
        """Force the OS to re-resolve the relay hostname.

        The Python websockets library uses asyncio.get_event_loop().getaddrinfo
        under the hood, which honours the OS resolver cache. After a VPN
        topology change the OS may keep returning a now-unroutable IP for the
        relay until that cache expires. Calling getaddrinfo here primes a
        fresh lookup so the next connect uses an authoritative answer.
        """
        try:
            host = urlparse(self.config.relay_url).hostname
            if not host:
                return
            infos = socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)
            ips = sorted({info[4][0] for info in infos})
            print(f"[CONNECT] Refreshed DNS for {host}: {ips}")
        except Exception as e:
            print(f"[CONNECT] DNS refresh failed: {e}")

    def _enable_tcp_keepalive(self, ws):
        """Turn on aggressive TCP keepalive on the underlying socket.

        Without this, a half-open socket left over from a VPN drop can
        survive in the kernel's ESTABLISHED state for ~2 hours (default
        TCP_KEEPIDLE on macOS/Linux). With KEEPIDLE=30s, KEEPINTVL=10s,
        KEEPCNT=3 the kernel will signal a dead connection within ~60s,
        well before users notice.
        """
        try:
            sock = ws.transport.get_extra_info("socket")
            if sock is None:
                return
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
            # These constants are platform-specific; not all platforms expose
            # all three. Apply best-effort.
            for opt_name, value in (
                ("TCP_KEEPIDLE", 30),     # Linux
                ("TCP_KEEPALIVE", 30),    # macOS
                ("TCP_KEEPINTVL", 10),
                ("TCP_KEEPCNT", 3),
            ):
                opt = getattr(socket, opt_name, None)
                if opt is not None:
                    try:
                        sock.setsockopt(socket.IPPROTO_TCP, opt, value)
                    except OSError:
                        pass
        except Exception as e:
            # Log and continue; missing keepalive is a degradation, not an error.
            print(f"[CONNECT] Failed to enable TCP keepalive: {e}")

    async def _tcp_connect_v4_first(self) -> socket.socket | None:
        """Pre-resolve and TCP-connect via IPv4, returning the open socket.

        Background: when DNS returns both A and AAAA records (Cloudflare does
        for `relay.thesavvydeveloper.com`), Python's `websockets` library
        relies on `asyncio.getaddrinfo` and connects to the first address
        returned — typically IPv6 due to the OS resolver's RFC 6724 default.
        On networks where outbound IPv6 is blackholed (carrier NAT, partial
        v6 deployments, restrictive home routers) every connect attempt
        hangs the entire `open_timeout`. macOS's Happy Eyeballs only kicks
        in when the kernel resolves; it doesn't help once Python has fixed
        an address. Returning a pre-connected v4 socket here lets us hand
        the websocket library a working transport. Returns None if no v4
        record exists or v4 connect fails — caller falls back to default
        resolution which preserves v6-only environments.
        """
        parsed = urlparse(self.config.relay_url)
        host = parsed.hostname
        if host is None:
            return None
        port = parsed.port or (443 if parsed.scheme.lower() in ("wss", "https") else 80)
        loop = asyncio.get_event_loop()
        try:
            infos = await loop.getaddrinfo(
                host, port, family=socket.AF_INET, type=socket.SOCK_STREAM
            )
        except OSError:
            return None
        for family, type_, proto, _, sockaddr in infos:
            sock = socket.socket(family, type_, proto)
            sock.setblocking(False)
            try:
                await asyncio.wait_for(loop.sock_connect(sock, sockaddr), timeout=5.0)
                return sock
            except Exception:
                try:
                    sock.close()
                except Exception:
                    pass
        return None

    async def connect(self):
        url = f"{self.config.relay_url}/ws/agent/{self.config.machine_id}"
        headers = {"X-Machine-Token": self.config.token}
        parsed = urlparse(self.config.relay_url)

        connect_kwargs = dict(
            additional_headers=headers,
            ping_interval=15,    # was 20s — tighter cadence catches half-open sockets sooner
            ping_timeout=10,     # was 20s
            close_timeout=10,
            open_timeout=15,     # bound the handshake so a stalled CONNECT fails fast
        )

        # Prefer IPv4 to sidestep blackholed-v6 networks. If the v4 connect
        # works we hand websockets a ready socket; if it fails (no A record,
        # v4-blocked network, etc.) we fall back to default resolution which
        # still allows v6.
        v4_sock = await self._tcp_connect_v4_first()
        if v4_sock is not None:
            connect_kwargs["sock"] = v4_sock
            connect_kwargs["server_hostname"] = parsed.hostname

        async with websockets.connect(url, **connect_kwargs) as ws:
            self.ws = ws
            self.reconnect_delay = 1
            self._enable_tcp_keepalive(ws)
            print(f"Connected to relay at {self.config.relay_url}")

            await self.send({
                "type": "AGENT_DISCOVERY",
                "payload": {
                    "available_agents": discover_agents(),
                    "os_info": get_os_info(),
                },
                "ts": time.time(),
            })

            await asyncio.gather(
                self.heartbeat_loop(),
                self.message_loop(),
            )

    async def message_loop(self):
        async for raw in self.ws:
            msg = json.loads(raw)
            # 4.1: Verify HMAC signature on incoming messages
            if not self._verify_hmac(msg):
                print(f"Warning: HMAC verification failed for message type={msg.get('type')}")
                continue
            await self.handle(msg)

    async def heartbeat_loop(self):
        while True:
            await asyncio.sleep(30)
            await self.send({"type": "HEARTBEAT", "payload": {}, "ts": time.time()})

    async def handle(self, msg: dict):
        msg_type = msg.get("type")
        sandbox_id = msg.get("sandbox_id")
        payload = msg.get("payload", {})
        user_id = msg.get("user_id")

        # PING from server-side keepalive. Reply with PONG so the relay can
        # treat the response as a heartbeat (handles cases where the agent's
        # own heartbeat loop is starved or stuck). Piggyback machine
        # utilization metrics so the relay can expose them via
        # /machine-metrics without adding a separate protocol message.
        if msg_type == "PING":
            try:
                m = collect_metrics(
                    sandboxes_root=self.config.sandboxes_root,
                    session_count=len(self.pty_manager.sessions),
                )
            except Exception as e:
                # Metrics must never break the heartbeat.
                print(f"[METRICS] Failed to collect: {e}")
                m = None
            pong: dict = {"type": "PONG", "ts": time.time()}
            if m is not None:
                pong["metrics"] = m
            await self.send(pong)
            return

        print(f"Received: {msg_type} sandbox={sandbox_id}")

        if msg_type == "CREATE_SANDBOX":
            await self.handle_create_sandbox(sandbox_id, payload)
        elif msg_type == "DELETE_SANDBOX":
            await self.handle_delete_sandbox(sandbox_id, payload)
        elif msg_type == "OPEN_TERMINAL":
            await self.handle_open_terminal(sandbox_id, payload)
        elif msg_type == "TERMINAL_INPUT":
            self.handle_terminal_input(sandbox_id, payload, user_id)
        elif msg_type == "TERMINAL_RESIZE":
            self.handle_terminal_resize(sandbox_id, payload)
        elif msg_type == "START_AGENT":
            await self.handle_start_agent(sandbox_id, payload)
        elif msg_type == "AGENT_PROMPT":
            await self.handle_agent_prompt(sandbox_id, payload)
        elif msg_type == "GIT_STATUS_REQUEST":
            await self.handle_git_status_request(sandbox_id, payload)
        elif msg_type == "FILE_LIST_REQUEST":
            await self.handle_file_list_request(sandbox_id, payload)
        elif msg_type == "FILE_READ_REQUEST":
            await self.handle_file_read_request(sandbox_id, payload)
        elif msg_type == "FILE_WRITE_REQUEST":
            await self.handle_file_write_request(sandbox_id, payload)
        elif msg_type == "FILE_SEARCH_REQUEST":
            await self.handle_file_search_request(sandbox_id, payload)
        elif msg_type == "AGENT_ASK":
            await self.handle_agent_ask(sandbox_id, payload)
        elif msg_type == "BROWSER_RESULT":
            # Bridge → relay → agent reply. Wake the future the IPC
            # server is awaiting so the originating CLI/MCP call returns.
            command_id = msg.get("command_id")
            if isinstance(command_id, str):
                future = self.pending_browser_commands.pop(command_id, None)
                if future is not None and not future.done():
                    future.set_result(msg)
                else:
                    # No waiter — could be a late reply after timeout, or
                    # a result for a command we didn't issue. Both are
                    # fine to ignore at this layer.
                    print(f"[BROWSER] No waiter for command_id={command_id}")

    async def handle_git_status_request(self, sandbox_id: str, payload: dict):
        """Reply with a GIT_STATUS_RESPONSE for the live shell cwd.

        Uses ``_resolve_sandbox_root`` so the Git panel follows the user
        as they ``cd`` between projects — same resolver the Files panel
        uses. When the root can't be determined we reply with the
        not-a-repo shape (branch=null) rather than failing loudly, so the
        frontend keeps rendering its idle state.
        """
        root = self._resolve_sandbox_root(sandbox_id, payload)
        if root is None:
            await self.send({
                "type": "GIT_STATUS_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {"branch": None, "staged": [], "modified": [], "untracked": []},
                "ts": time.time(),
            })
            return

        # git_ops.get_status runs the actual subprocesses; offload so we
        # don't block the WS read loop on a slow filesystem.
        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, git_get_status, str(root))

        if "error" in result:
            # Not a git repository (or git failed). The frontend treats
            # branch=null as "not a git repo" so this is the right shape.
            await self.send({
                "type": "GIT_STATUS_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {"branch": None, "staged": [], "modified": [], "untracked": []},
                "ts": time.time(),
            })
            return

        await self.send({
            "type": "GIT_STATUS_RESPONSE",
            "sandbox_id": sandbox_id,
            "payload": {
                "branch": result.get("branch") or None,
                "staged": result.get("staged", []),
                "modified": result.get("modified", []),
                "untracked": result.get("untracked", []),
            },
            "ts": time.time(),
        })

    def _resolve_sandbox_root(self, sandbox_id: str, payload: dict) -> Path | None:
        """Locate the active root for a read-only file/git request.

        Source-of-truth order, most-current first:
          1. payload["root_override"] — WP-3: browser pins the panel to a
             specific project root (e.g. ``project.folder_path``). Goes
             through the same traversal-rejection check as everything
             else: ``..`` segments are refused so a malicious browser
             can't ask the agent to traverse out of where it intended.
          2. payload["folder_path"] — legacy browser override (kept for
             back-compat with pre-WP-3 frontends).
          3. The PTY session's *live* cwd, queried from tmux at request
             time. Follows the user wherever they ``cd`` inside the
             terminal, so the Files/Git panels match what the shell sees.
          4. The session's initial cwd (set at creation) as a fallback for
             pre-tmux setups or just-started sessions.
          5. ``None`` — caller returns an "unavailable" response.

        Note on the security model: this resolver intentionally does NOT
        apply ``_validate_path`` (which enforces "must live under
        sandboxes_root"). Read-only file ops follow the shell, and the
        agent already has the user's filesystem permissions via that
        shell — the terminal can ``cat`` whatever the user can read. The
        in-root traversal check inside ``file_ops`` still prevents the
        browser from escaping whatever root we pick here.

        Write-side ops (CREATE_SANDBOX / DELETE_SANDBOX) keep their own
        strict ``_validate_path`` call — those mutate filesystem state
        and must stay confined to sandboxes_root.
        """
        # WP-3: root_override takes precedence. Treat any path containing
        # a `..` segment as a traversal attempt and refuse — the browser
        # has no legitimate reason to ask for one. Note that an absolute
        # path *without* `..` is fine; the security boundary here is the
        # agent's filesystem permissions, not sandboxes_root (read-only ops
        # have already opted out of that constraint per the docstring).
        root_override = payload.get("root_override")
        if isinstance(root_override, str) and root_override.strip():
            if self._has_traversal_segment(root_override):
                return None
            folder_path: str | None = root_override
        else:
            folder_path = payload.get("folder_path")
            if not folder_path:
                session = self.pty_manager.get_session(sandbox_id)
                if session is not None:
                    # Prefer the live cwd (follows `cd`). Fall back to the
                    # session's recorded initial folder if tmux is unreachable
                    # or hasn't reported yet.
                    folder_path = session.live_cwd() or session.cwd
        if not folder_path:
            return None
        try:
            resolved = Path(folder_path).resolve()
        except OSError:
            return None
        if not resolved.exists() or not resolved.is_dir():
            return None
        return resolved

    @staticmethod
    def _has_traversal_segment(path: str) -> bool:
        """Return True if any path segment is exactly ``..``.

        We block the literal ``..`` segment rather than substring-matching
        because legitimate filenames can contain ``..`` (e.g. ``foo..bar``)
        and rejecting them outright would be over-aggressive.
        """
        parts = Path(path).parts
        return any(p == ".." for p in parts)

    async def handle_file_list_request(self, sandbox_id: str, payload: dict):
        """W3: list the immediate children of a directory under the sandbox.

        Browser sends ``{"relative_path": "src/components"}`` (empty string
        for root). We resolve, validate-inside-root, list, sort, cap. Errors
        surface as a normal response with ``error`` set so the UI can render
        them inline — no exceptions cross the WebSocket boundary.
        """
        relative_path = payload.get("relative_path", "")
        if not isinstance(relative_path, str):
            relative_path = ""

        root = self._resolve_sandbox_root(sandbox_id, payload)
        if root is None:
            await self.send({
                "type": "FILE_LIST_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {
                    "relative_path": relative_path,
                    "entries": [],
                    "error": "Sandbox folder unavailable",
                },
                "ts": time.time(),
            })
            return

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, files_list_directory, root, relative_path)
        # Surface the resolved absolute path so the frontend Explorer can
        # show the user which directory the tree is rooted at — important
        # when v1.6.0+'s live-cwd tracking has moved the root away from
        # the sandbox's original folder_path.
        result["root_path"] = str(root)
        await self.send({
            "type": "FILE_LIST_RESPONSE",
            "sandbox_id": sandbox_id,
            "payload": result,
            "ts": time.time(),
        })

    async def handle_file_read_request(self, sandbox_id: str, payload: dict):
        """W3: read a file's contents for the viewer tab.

        Requires ``relative_path`` — refuse otherwise (the browser never has
        a reason to read "the sandbox" itself). Caps + binary detection live
        in ``file_ops.read_file`` so this method stays a thin wrapper.
        """
        relative_path = payload.get("relative_path")
        if not isinstance(relative_path, str) or not relative_path:
            await self.send({
                "type": "FILE_READ_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {
                    "relative_path": relative_path if isinstance(relative_path, str) else "",
                    "size": 0,
                    "error": "Missing relative_path",
                },
                "ts": time.time(),
            })
            return

        root = self._resolve_sandbox_root(sandbox_id, payload)
        if root is None:
            await self.send({
                "type": "FILE_READ_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {
                    "relative_path": relative_path,
                    "size": 0,
                    "error": "Sandbox folder unavailable",
                },
                "ts": time.time(),
            })
            return

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, files_read_file, root, relative_path)
        await self.send({
            "type": "FILE_READ_RESPONSE",
            "sandbox_id": sandbox_id,
            "payload": result,
            "ts": time.time(),
        })

    async def handle_file_write_request(self, sandbox_id: str, payload: dict):
        """WP-5: write a file from the editor.

        Mirrors ``handle_file_read_request`` for resolution + error shape.
        The actual cap/binary/UTF-8 checks live in ``file_ops.write_file``
        so this method stays a thin async wrapper. Errors come back in
        the ``error`` field; ``ok=False`` is always paired with an error.
        """
        relative_path = payload.get("relative_path")
        content = payload.get("content")
        if not isinstance(relative_path, str) or not relative_path:
            await self.send({
                "type": "FILE_WRITE_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {
                    "relative_path": relative_path if isinstance(relative_path, str) else "",
                    "ok": False,
                    "error": "Missing relative_path",
                },
                "ts": time.time(),
            })
            return

        root = self._resolve_sandbox_root(sandbox_id, payload)
        if root is None:
            await self.send({
                "type": "FILE_WRITE_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {
                    "relative_path": relative_path,
                    "ok": False,
                    "error": "Sandbox folder unavailable",
                },
                "ts": time.time(),
            })
            return

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(None, files_write_file, root, relative_path, content)
        await self.send({
            "type": "FILE_WRITE_RESPONSE",
            "sandbox_id": sandbox_id,
            "payload": result,
            "ts": time.time(),
        })

    async def handle_file_search_request(self, sandbox_id: str, payload: dict):
        """WP-5c: full-text search across the sandbox folder.

        Uses ripgrep if available, falls back to grep. Cap at 500 matches.
        Search ranges are subject to the same root resolution as FILE_LIST/
        FILE_READ, so ``root_override`` from WP-3 pins search to the same
        directory the Files panel is showing.
        """
        query = payload.get("query", "")
        max_results = payload.get("max_results")
        case_sensitive = bool(payload.get("case_sensitive", False))

        root = self._resolve_sandbox_root(sandbox_id, payload)
        if root is None:
            await self.send({
                "type": "FILE_SEARCH_RESPONSE",
                "sandbox_id": sandbox_id,
                "payload": {
                    "query": query if isinstance(query, str) else "",
                    "matches": [],
                    "error": "Sandbox folder unavailable",
                },
                "ts": time.time(),
            })
            return

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            lambda: files_search_files(
                root, query, max_results=max_results, case_sensitive=case_sensitive
            ),
        )
        await self.send({
            "type": "FILE_SEARCH_RESPONSE",
            "sandbox_id": sandbox_id,
            "payload": result,
            "ts": time.time(),
        })

    async def handle_agent_ask(self, sandbox_id: str, payload: dict):
        """W8: run a one-shot prompt against the AI agent's non-interactive CLI.

        Distinct from ``AGENT_PROMPT`` which writes to a long-running PTY.
        This handler captures stdout from a single ``claude -p ...`` (or
        equivalent) invocation and returns it as a single message.

        ``conversation_id`` is opaque to the agent — the relay/frontend
        use it to thread responses; we just echo it back so the browser
        can correlate the reply.
        """
        prompt = payload.get("prompt", "")
        conversation_id = payload.get("conversation_id", "")
        agent = payload.get("agent", "claude")

        # cwd: prefer the resolved sandbox root so the agent runs in the
        # right project. Fall back to None (subprocess uses the daemon's
        # cwd) which is harmless for stateless prompts.
        root = self._resolve_sandbox_root(sandbox_id, payload)
        cwd = str(root) if root is not None else None

        loop = asyncio.get_running_loop()
        result = await loop.run_in_executor(
            None,
            lambda: run_agent_ask(prompt, agent, cwd=cwd),
        )
        # Always echo conversation_id back so the frontend can route the
        # response to the right transcript without correlating on prompt
        # text.
        result["conversation_id"] = conversation_id
        await self.send({
            "type": "AGENT_RESPONSE",
            "sandbox_id": sandbox_id,
            "payload": result,
            "ts": time.time(),
        })

    async def handle_create_sandbox(self, sandbox_id: str, payload: dict):
        folder_path = payload.get("folder_path", "")
        try:
            self._validate_path(folder_path)
        except ValueError as e:
            await self.send({
                "type": "SANDBOX_STATUS",
                "sandbox_id": sandbox_id,
                "payload": {"success": False, "error": str(e)},
                "ts": time.time(),
            })
            return

        result = await self.sandbox_manager.create(
            sandbox_id,
            folder_path,
            payload.get("github_repo"),
            payload.get("github_branch"),
        )
        await self.send({
            "type": "SANDBOX_STATUS",
            "sandbox_id": sandbox_id,
            "payload": result,
            "ts": time.time(),
        })

    async def handle_delete_sandbox(self, sandbox_id: str, payload: dict):
        """Delete sandbox folder from disk and terminate any running sessions."""
        import shutil

        # Kill PTY sessions for this sandbox
        self.pty_manager.remove_session(sandbox_id)
        self.pty_manager.remove_session(f"{sandbox_id}_agent")

        folder_path = payload.get("folder_path", "")
        if folder_path:
            try:
                self._validate_path(folder_path)
            except ValueError as e:
                print(f"Rejected delete for invalid path: {e}")
                return
            path = Path(folder_path)
            if path.exists():
                shutil.rmtree(path, ignore_errors=True)
                print(f"Deleted sandbox folder: {folder_path}")

    async def handle_open_terminal(self, sandbox_id: str, payload: dict):
        folder_path = payload.get("folder_path", self.sandbox_manager.get_path(sandbox_id))
        rows = payload.get("rows", 24)
        cols = payload.get("cols", 80)

        try:
            self._validate_path(folder_path)
        except ValueError as e:
            print(f"Rejected open_terminal for invalid path: {e}")
            return

        # Ensure directory exists before opening shell
        Path(folder_path).mkdir(parents=True, exist_ok=True)

        async def on_output(sid: str, data: str):
            await self.send({
                "type": "TERMINAL_OUTPUT",
                "sandbox_id": sid,
                "payload": {"data": data},
                "ts": time.time(),
            })

        # Reuse existing session if the tmux session is still alive
        existing = self.pty_manager.get_session(sandbox_id)
        if existing and existing.is_alive:
            # Session object exists in memory AND tmux session alive
            # Detach old ptyprocess attachment if any, then reattach.
            # Also reattach if the read loop has died (e.g. from a previous
            # transient WebSocket failure that broke on_output) — otherwise
            # the PTY would accept input but no output would ever flow back.
            read_task_dead = existing._read_task is None or existing._read_task.done()
            if (existing.process and not existing.process.isalive()) or read_task_dead:
                if existing.process and existing.process.isalive():
                    # Process is alive but read loop died — terminate the stale
                    # ptyprocess client so reattach can spawn a fresh one.
                    try:
                        existing.process.terminate(force=True)
                    except Exception as e:
                        print(f"[PTY] terminate before reattach failed: {e}")
                existing.reattach(on_output, rows, cols)
            else:
                existing.update_output_callback(on_output)
                existing.resize(rows, cols)
            # Resize tmux to browser dimensions before capturing scrollback
            subprocess.run(
                ["tmux", "resize-window", "-t", existing.tmux_session_name,
                 "-x", str(cols), "-y", str(rows)],
                capture_output=True,
            )
            # Replay scrollback from tmux capture-pane (clean, no raw PTY artifacts)
            scrollback = existing.get_tmux_scrollback()
            if scrollback:
                _h = hashlib.sha256(scrollback.encode("utf-8", "replace")).hexdigest()[:8]
                _lines = scrollback.count("\n")
                print(f"[REPLAY-DBG] sandbox={sandbox_id[:8]} bytes={len(scrollback)} lines={_lines} sha8={_h} (existing)", flush=True)
                await self.send({
                    "type": "TERMINAL_OUTPUT",
                    "sandbox_id": sandbox_id,
                    "payload": {"data": scrollback},
                    "ts": time.time(),
                })
            return

        # Check if tmux session exists but we lost our in-memory reference (daemon restarted)
        tmux_name = f"{TMUX_PREFIX}{sandbox_id}"
        if _tmux_session_exists(tmux_name):
            session = PTYSession(sandbox_id, folder_path, on_output)
            session.reattach(on_output, rows, cols)
            self.pty_manager.sessions[sandbox_id] = session
            # Resize tmux to browser dimensions before capturing scrollback
            subprocess.run(
                ["tmux", "resize-window", "-t", tmux_name,
                 "-x", str(cols), "-y", str(rows)],
                capture_output=True,
            )
            # Replay scrollback from tmux capture-pane
            scrollback = _capture_tmux_scrollback(tmux_name)
            if scrollback:
                _h = hashlib.sha256(scrollback.encode("utf-8", "replace")).hexdigest()[:8]
                _lines = scrollback.count("\n")
                print(f"[REPLAY-DBG] sandbox={sandbox_id[:8]} bytes={len(scrollback)} lines={_lines} sha8={_h} (reattach)", flush=True)
                await self.send({
                    "type": "TERMINAL_OUTPUT",
                    "sandbox_id": sandbox_id,
                    "payload": {"data": scrollback},
                    "ts": time.time(),
                })
            return

        # No existing session — create fresh
        session = self.pty_manager.create_session(sandbox_id, folder_path, on_output)
        session.start_shell(rows=rows, cols=cols)

    def handle_terminal_input(self, sandbox_id: str, payload: dict, user_id: str | None):
        session = self.pty_manager.get_session(sandbox_id)
        if session:
            session.write(payload.get("data", ""), user_id)

    def handle_terminal_resize(self, sandbox_id: str, payload: dict):
        session = self.pty_manager.get_session(sandbox_id)
        if session:
            session.resize(payload.get("rows", 24), payload.get("cols", 80))

    async def handle_start_agent(self, sandbox_id: str, payload: dict):
        folder_path = payload.get("folder_path", self.sandbox_manager.get_path(sandbox_id))
        agent_cmd = payload.get("agent_cmd", ["claude"])

        # 1.1: Validate agent command
        if not isinstance(agent_cmd, list) or len(agent_cmd) == 0 or len(agent_cmd) > MAX_AGENT_CMD_ARGS:
            await self.send({
                "type": "AGENT_OUTPUT",
                "sandbox_id": sandbox_id,
                "payload": {"content": f"Error: Invalid agent command format", "done": True},
                "ts": time.time(),
            })
            return

        if agent_cmd[0] not in ALLOWED_AGENT_COMMANDS:
            await self.send({
                "type": "AGENT_OUTPUT",
                "sandbox_id": sandbox_id,
                "payload": {"content": f"Error: Agent '{agent_cmd[0]}' is not allowed. Allowed: {', '.join(sorted(ALLOWED_AGENT_COMMANDS))}", "done": True},
                "ts": time.time(),
            })
            return

        # 1.2: Validate path
        try:
            self._validate_path(folder_path)
        except ValueError as e:
            await self.send({
                "type": "AGENT_OUTPUT",
                "sandbox_id": sandbox_id,
                "payload": {"content": f"Error: {e}", "done": True},
                "ts": time.time(),
            })
            return

        # Ensure directory exists
        Path(folder_path).mkdir(parents=True, exist_ok=True)

        async def on_output(sid: str, data: str):
            await self.send({
                "type": "AGENT_OUTPUT",
                "sandbox_id": sid,
                "payload": {"content": data, "done": False},
                "ts": time.time(),
            })

        session = self.pty_manager.create_session(f"{sandbox_id}_agent", folder_path, on_output)
        session.start_agent(agent_cmd)

    async def handle_agent_prompt(self, sandbox_id: str, payload: dict):
        # Try agent session first, then fall back to terminal session
        session = self.pty_manager.get_session(f"{sandbox_id}_agent")
        if not session:
            session = self.pty_manager.get_session(sandbox_id)
        if session and session.process and session.process.isalive():
            content = payload.get("content", "")
            session.process.write((content + "\n").encode())

    def _compute_hmac(self, payload: str) -> str:
        """4.1: Compute HMAC-SHA256 signature using machine token as key."""
        return hmac.new(
            self.config.token.encode(),
            payload.encode(),
            hashlib.sha256,
        ).hexdigest()

    def _verify_hmac(self, msg: dict) -> bool:
        """4.1: Verify HMAC signature on incoming message."""
        sig = msg.pop("hmac_sig", None)
        if sig is None:
            return False  # Reject unsigned messages
        payload = json.dumps(msg, sort_keys=True)
        expected = self._compute_hmac(payload)
        return hmac.compare_digest(sig, expected)

    async def send(self, msg: dict):
        if self.ws:
            payload = json.dumps(msg, sort_keys=True)
            msg["hmac_sig"] = self._compute_hmac(payload)
            await self.ws.send(json.dumps(msg))
