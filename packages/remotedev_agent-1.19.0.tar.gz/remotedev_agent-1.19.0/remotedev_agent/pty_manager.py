import asyncio
import codecs
import os
import re
import subprocess
from collections import deque
from collections.abc import Callable, Coroutine
from typing import Any

import ptyprocess

# Max scrollback buffer size in bytes (~100KB)
MAX_SCROLLBACK = 100_000

# Prefix for tmux session names to avoid collision with user sessions
TMUX_PREFIX = "remotedev-"

# Terminal-reply CSI sequences that the *terminal emulator* sends back to the host
# in response to host queries — we must strip them from any data we forward INTO
# the PTY (otherwise xterm.js's auto-replies leak into the shell as input, where
# they are interpreted as commands, e.g. `zsh: command not found: 50`) and from
# scrollback we replay back to the browser (where they appear as raw glyphs).
#   - DA1/DA2/DA3 replies:          \x1b[?...c   \x1b[>...c   \x1b[=...c   \x1b[c
#   - Cursor position report (CPR): \x1b[<row>;<col>R
#   - Window-manipulation reports:  \x1b[8;<h>;<w>t   \x1b[4;<px_h>;<px_w>t  ...
_TERMINAL_REPLY_RE = re.compile(
    r"\x1b\[(?:[\?>=]?[\d;]*c|\d+(?:;\d+)+[tR])"
)


def _strip_terminal_replies(data: str) -> str:
    """Remove terminal→host reply sequences from a chunk of text."""
    return _TERMINAL_REPLY_RE.sub("", data)


def _clean_env() -> dict[str, str]:
    """Return a clean environment for spawned PTY processes.

    Removes variables that would prevent launching nested AI agents
    (e.g. CLAUDECODE blocks launching claude inside another session).
    """
    env = os.environ.copy()
    for key in ("CLAUDECODE", "CLAUDE_CODE"):
        env.pop(key, None)
    # Ensure TERM is set — tmux requires it
    if "TERM" not in env:
        env["TERM"] = "xterm-256color"
    return env


def _tmux_session_exists(session_name: str) -> bool:
    """Check if a tmux session with the given name exists."""
    result = subprocess.run(
        ["tmux", "has-session", "-t", session_name],
        capture_output=True,
    )
    return result.returncode == 0


def _capture_tmux_scrollback(session_name: str, lines: int = 10000) -> str:
    """Capture scrollback from a tmux session via capture-pane.

    Uses -e to preserve ANSI color sequences for colored replay.
    Strips trailing blank lines (tmux filler artifacts from size mismatches)
    and DA (Device Attributes) response sequences that appear as raw text.
    """
    result = subprocess.run(
        ["tmux", "capture-pane", "-t", session_name, "-p", "-e", "-S", f"-{lines}"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        return ""
    output = result.stdout
    # Strip trailing blank/whitespace-only lines (tmux filler dots)
    lines_list = output.split("\n")
    while lines_list and lines_list[-1].strip() == "":
        lines_list.pop()
    output = "\n".join(lines_list)
    if output:
        output += "\n"
    # Strip terminal-reply sequences (DA1/DA2/DA3, CPR, window-manipulation reports)
    # that the terminal emulator emitted in response to host queries — they are
    # captured by tmux as plain text and look like garbage when replayed.
    output = _strip_terminal_replies(output)
    return output


def check_tmux() -> None:
    """Verify tmux is installed. Exit with helpful message if not."""
    result = subprocess.run(["tmux", "-V"], capture_output=True, text=True)
    if result.returncode != 0:
        import sys
        print("ERROR: tmux is required for session persistence.")
        print("Install with: brew install tmux (macOS) or apt install tmux (Linux)")
        sys.exit(1)
    else:
        print(f"[PTY] tmux found: {result.stdout.strip()}")


class PTYSession:
    def __init__(self, sandbox_id: str, cwd: str, on_output: Callable[[str, str], Coroutine[Any, Any, None]]):
        self.sandbox_id = sandbox_id
        self.cwd = cwd
        self.on_output = on_output
        self.process: ptyprocess.PtyProcess | None = None
        self._read_task: asyncio.Task | None = None
        # Scrollback buffer for session replay (deque for O(1) popleft)
        self._scrollback: deque[str] = deque()
        self._scrollback_size: int = 0
        self._utf8_decoder = codecs.getincrementaldecoder('utf-8')('replace')
        self.tmux_session_name = f"{TMUX_PREFIX}{sandbox_id}"

    @property
    def is_alive(self) -> bool:
        """Check if the tmux session exists (survives daemon restart)."""
        return _tmux_session_exists(self.tmux_session_name)

    def live_cwd(self) -> str | None:
        """Live cwd of the shell inside this tmux session.

        Returns whatever directory the user has most recently ``cd``'d into,
        not the folder we created the session in. tmux's ``pane_current_path``
        is computed from the foreground process group's cwd via OS APIs
        (``proc_pidinfo`` on macOS, ``/proc/<pid>/cwd`` on Linux) — it doesn't
        depend on OSC 7 or any shell-side configuration, so this works even
        in a vanilla zsh/bash setup.

        Returns ``None`` if the tmux session is dead or tmux can't report the
        path — callers should fall back to ``self.cwd`` (the original folder).
        """
        try:
            result = subprocess.run(
                ["tmux", "display-message", "-p", "-t", self.tmux_session_name,
                 "#{pane_current_path}"],
                capture_output=True, text=True, timeout=2,
            )
        except (subprocess.SubprocessError, FileNotFoundError, OSError):
            return None
        if result.returncode != 0:
            return None
        path = result.stdout.strip()
        return path or None

    def start_shell(self, shell: str | None = None, rows: int = 24, cols: int = 80):
        """Create a tmux session (if needed) and attach via ptyprocess."""
        if not _tmux_session_exists(self.tmux_session_name):
            if shell is None:
                shell = os.environ.get("SHELL", "/bin/zsh")
            print(f"[PTY] Creating tmux session: {self.tmux_session_name} in {self.cwd}")
            result = subprocess.run(
                ["tmux", "new-session", "-d", "-s", self.tmux_session_name,
                 "-x", str(cols), "-y", str(rows), "-c", self.cwd, shell],
                capture_output=True, text=True,
                env=_clean_env(),
            )
            if result.returncode != 0:
                print(f"[PTY] tmux new-session failed (rc={result.returncode}): {result.stderr.strip()}")
                return
            subprocess.run(
                ["tmux", "set-option", "-t", self.tmux_session_name, "history-limit", "10000"],
                capture_output=True,
            )
            print(f"[PTY] tmux session created: {self.tmux_session_name}")
        else:
            print(f"[PTY] tmux session already exists: {self.tmux_session_name}")
        self._attach(rows, cols)

    def start_agent(self, agent_cmd: list[str]):
        """Create a tmux session for an agent command and attach."""
        if not _tmux_session_exists(self.tmux_session_name):
            print(f"[PTY] Creating tmux agent session: {self.tmux_session_name} cmd={agent_cmd}")
            result = subprocess.run(
                ["tmux", "new-session", "-d", "-s", self.tmux_session_name,
                 "-x", "200", "-y", "24", "-c", self.cwd] + agent_cmd,
                capture_output=True, text=True,
                env=_clean_env(),
            )
            if result.returncode != 0:
                print(f"[PTY] tmux new-session (agent) failed (rc={result.returncode}): {result.stderr.strip()}")
                return
            subprocess.run(
                ["tmux", "set-option", "-t", self.tmux_session_name, "history-limit", "10000"],
                capture_output=True,
            )
            print(f"[PTY] tmux agent session created: {self.tmux_session_name}")
        self._attach()

    def _attach(self, rows: int = 24, cols: int = 80):
        """Attach to existing tmux session via ptyprocess for I/O streaming."""
        if not _tmux_session_exists(self.tmux_session_name):
            print(f"[PTY] Cannot attach: tmux session {self.tmux_session_name} does not exist")
            return
        try:
            print(f"[PTY] Attaching to tmux session: {self.tmux_session_name}")
            self.process = ptyprocess.PtyProcess.spawn(
                ["tmux", "attach-session", "-t", self.tmux_session_name],
                dimensions=(rows, cols),
                env=_clean_env(),
            )
            self._read_task = asyncio.create_task(self._read_loop())
            # Resize tmux pane to match browser dimensions
            subprocess.run(
                ["tmux", "resize-window", "-t", self.tmux_session_name, "-x", str(cols), "-y", str(rows)],
                capture_output=True,
            )
            # Ensure history-limit is up to date on existing sessions (not just new ones)
            subprocess.run(
                ["tmux", "set-option", "-t", self.tmux_session_name, "history-limit", "10000"],
                capture_output=True,
            )
            print(f"[PTY] Successfully attached to: {self.tmux_session_name}")
        except Exception as e:
            print(f"[PTY] Failed to attach to tmux session {self.tmux_session_name}: {e}")

    def reattach(self, on_output: Callable[[str, str], Coroutine[Any, Any, None]], rows: int = 24, cols: int = 80):
        """Reattach to a surviving tmux session after daemon restart."""
        self.on_output = on_output
        self._attach(rows, cols)

    async def _read_loop(self):
        loop = asyncio.get_event_loop()
        while self.process and self.process.isalive():
            try:
                data = await loop.run_in_executor(None, self.process.read, 4096)
            except EOFError:
                # Flush any remaining bytes in the decoder
                remaining = self._utf8_decoder.decode(b'', final=True)
                if remaining:
                    self._append_scrollback(remaining)
                    try:
                        await self.on_output(self.sandbox_id, remaining)
                    except Exception as e:
                        print(f"[PTY] on_output failed during EOF flush: {e}")
                print(f"[PTY] Read loop EOF: {self.tmux_session_name}")
                break
            except Exception as e:
                # PTY read failed — terminal genuinely broken, exit the loop
                print(f"[PTY] Read loop PTY read error for {self.tmux_session_name}: {e}")
                break

            # Decode and forward — catch on_output errors WITHOUT exiting the loop.
            # The read loop must survive transient WebSocket failures, otherwise
            # subsequent keystrokes echo into a void until the next reattach.
            try:
                text = self._utf8_decoder.decode(data, final=False)
            except Exception as e:
                print(f"[PTY] Decoder error for {self.tmux_session_name}: {e}")
                continue
            if text:
                self._append_scrollback(text)
                try:
                    await self.on_output(self.sandbox_id, text)
                except Exception as e:
                    # Don't break the loop. Output is in the scrollback buffer
                    # and a future reattach/capture-pane will replay it.
                    print(f"[PTY] on_output failed (continuing read loop) for {self.tmux_session_name}: {e}")

    def _append_scrollback(self, text: str):
        self._scrollback.append(text)
        self._scrollback_size += len(text)
        # Trim from the front if over limit
        while self._scrollback_size > MAX_SCROLLBACK and len(self._scrollback) > 1:
            removed = self._scrollback.popleft()
            self._scrollback_size -= len(removed)

    def get_scrollback(self) -> str:
        return "".join(self._scrollback)

    def get_tmux_scrollback(self) -> str:
        """Get scrollback from tmux capture-pane (works after daemon restart)."""
        return _capture_tmux_scrollback(self.tmux_session_name)

    def update_output_callback(self, on_output: Callable[[str, str], Coroutine[Any, Any, None]]):
        """Update the output callback (e.g. when relay reconnects)."""
        self.on_output = on_output

    def write(self, data: str, user_id: str | None = None):
        if self.process and self.process.isalive():
            # Drop xterm.js terminal-reply sequences (DA, CPR, window reports)
            # before they hit the shell as stdin — see _TERMINAL_REPLY_RE notes.
            data = _strip_terminal_replies(data)
            if not data:
                return
            try:
                self.process.write(data.encode())
            except (OSError, EOFError) as e:
                print(f"[PTY] Write failed for {self.tmux_session_name}: {e}")

    def resize(self, rows: int, cols: int):
        if self.process and self.process.isalive():
            self.process.setwinsize(rows, cols)
        # Keep tmux pane in sync so content renders at correct dimensions
        if _tmux_session_exists(self.tmux_session_name):
            subprocess.run(
                ["tmux", "resize-window", "-t", self.tmux_session_name,
                 "-x", str(cols), "-y", str(rows)],
                capture_output=True,
            )

    def terminate(self):
        """Detach from the tmux session (session persists for local access)."""
        if self.process and self.process.isalive():
            self.process.terminate(force=True)
        if self._read_task:
            self._read_task.cancel()

    def destroy(self):
        """Kill the tmux session entirely (used on sandbox delete)."""
        self.terminate()
        if _tmux_session_exists(self.tmux_session_name):
            print(f"[PTY] Destroying tmux session: {self.tmux_session_name}")
            subprocess.run(
                ["tmux", "kill-session", "-t", self.tmux_session_name],
                capture_output=True,
            )


class PTYManager:
    def __init__(self):
        self.sessions: dict[str, PTYSession] = {}

    def create_session(self, sandbox_id: str, cwd: str, on_output) -> PTYSession:
        if sandbox_id in self.sessions:
            self.sessions[sandbox_id].terminate()
        session = PTYSession(sandbox_id, cwd, on_output)
        self.sessions[sandbox_id] = session
        return session

    def get_session(self, sandbox_id: str) -> PTYSession | None:
        return self.sessions.get(sandbox_id)

    def remove_session(self, sandbox_id: str):
        """Remove and destroy session (kills tmux session)."""
        session = self.sessions.pop(sandbox_id, None)
        if session:
            session.destroy()
