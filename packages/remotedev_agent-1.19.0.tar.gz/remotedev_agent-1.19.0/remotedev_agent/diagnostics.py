"""Self-diagnostic helpers used by the `diagnose` CLI command and the
post-`configure` smoke check.

The goal: turn invisible failures (silent v6 blackhole, wrong token, agent
not running) into a single one-shot report a user can paste back when
asking for help. Each probe returns a `Probe` dataclass with status, brief,
and optional detail so callers can render a consistent table.
"""
from __future__ import annotations

import asyncio
import socket
import time
from dataclasses import dataclass, field
from typing import Optional
from urllib.parse import urlparse


@dataclass
class Probe:
    name: str
    ok: bool
    brief: str
    detail: Optional[str] = None
    duration_s: Optional[float] = None
    extras: dict = field(default_factory=dict)


def _hostport(relay_url: str) -> tuple[str, int]:
    p = urlparse(relay_url)
    if not p.hostname:
        raise ValueError(f"relay_url has no hostname: {relay_url!r}")
    port = p.port or (443 if p.scheme.lower() in ("wss", "https") else 80)
    return p.hostname, port


async def probe_dns(relay_url: str) -> Probe:
    host, _ = _hostport(relay_url)
    t0 = time.monotonic()
    try:
        infos = await asyncio.get_event_loop().getaddrinfo(
            host, None, type=socket.SOCK_STREAM
        )
    except Exception as e:
        return Probe("dns", False, f"resolution failed: {e}", duration_s=time.monotonic() - t0)
    v4 = sorted({i[4][0] for i in infos if i[0] == socket.AF_INET})
    v6 = sorted({i[4][0] for i in infos if i[0] == socket.AF_INET6})
    detail = f"v4={v4 or '(none)'} v6={v6 or '(none)'}"
    return Probe(
        "dns", True, f"{len(v4)} A record(s), {len(v6)} AAAA record(s)",
        detail=detail, duration_s=time.monotonic() - t0,
        extras={"v4": v4, "v6": v6},
    )


async def _tcp_probe(relay_url: str, family: int, label: str, timeout: float = 5.0) -> Probe:
    """Open a raw TCP connection (no TLS, no WebSocket) so we isolate
    transport reachability from token / TLS / WS protocol issues."""
    host, port = _hostport(relay_url)
    t0 = time.monotonic()
    loop = asyncio.get_event_loop()
    try:
        infos = await loop.getaddrinfo(host, port, family=family, type=socket.SOCK_STREAM)
    except Exception as e:
        return Probe(label, False, f"getaddrinfo failed: {e}", duration_s=time.monotonic() - t0)
    if not infos:
        return Probe(label, False, "no addresses for this family", duration_s=time.monotonic() - t0)
    last_err = None
    for fam, type_, proto, _, sockaddr in infos:
        sock = socket.socket(fam, type_, proto)
        sock.setblocking(False)
        try:
            await asyncio.wait_for(loop.sock_connect(sock, sockaddr), timeout=timeout)
            sock.close()
            return Probe(
                label, True, f"connected to {sockaddr[0]}:{port}",
                duration_s=time.monotonic() - t0,
            )
        except asyncio.TimeoutError:
            last_err = f"timeout to {sockaddr[0]}:{port} (>{timeout}s)"
        except Exception as e:
            last_err = f"{sockaddr[0]}:{port} → {type(e).__name__}: {e}"
        finally:
            try:
                sock.close()
            except Exception:
                pass
    return Probe(label, False, last_err or "all addresses failed", duration_s=time.monotonic() - t0)


async def probe_tcp_v4(relay_url: str, timeout: float = 5.0) -> Probe:
    return await _tcp_probe(relay_url, socket.AF_INET, "tcp_v4", timeout=timeout)


async def probe_tcp_v6(relay_url: str, timeout: float = 5.0) -> Probe:
    return await _tcp_probe(relay_url, socket.AF_INET6, "tcp_v6", timeout=timeout)


async def probe_ws_connect(
    relay_url: str, machine_id: str, token: str, timeout: float = 10.0
) -> Probe:
    """Full WebSocket open against /ws/agent/{machine_id} with the configured
    token. Distinguishes token-mismatch (HTTP 403) from network problems.

    Reuses the daemon's IPv4-first connect so this probe reflects what the
    real daemon does at runtime — broken-v6 networks pass here the same way
    they pass in production.
    """
    import websockets

    from remotedev_agent.daemon import AgentDaemon
    from remotedev_agent.config import AgentConfig

    cfg = AgentConfig(
        relay_url=relay_url, machine_id=machine_id, token=token,
        sandboxes_root="/tmp/remotedev-diag",
    )
    # We only need the v4-first helper; bypass the tmux check to avoid
    # spurious failures on machines without tmux installed yet.
    daemon = AgentDaemon.__new__(AgentDaemon)
    daemon.config = cfg

    url = f"{relay_url}/ws/agent/{machine_id}"
    headers = {"X-Machine-Token": token}
    parsed = urlparse(relay_url)
    t0 = time.monotonic()
    try:
        v4_sock = await daemon._tcp_connect_v4_first()
        kwargs = {"additional_headers": headers, "open_timeout": timeout, "close_timeout": 2}
        if v4_sock is not None:
            kwargs["sock"] = v4_sock
            kwargs["server_hostname"] = parsed.hostname
        async with websockets.connect(url, **kwargs) as ws:
            elapsed = time.monotonic() - t0
            await ws.close()
            return Probe(
                "ws_connect", True, "handshake completed",
                duration_s=elapsed,
                detail=f"used {'v4' if v4_sock is not None else 'default resolution'}",
            )
    except websockets.exceptions.InvalidStatus as e:  # type: ignore[attr-defined]
        elapsed = time.monotonic() - t0
        # 403 → token mismatch; 401 → no header; others → unexpected
        code = getattr(e.response, "status_code", None)
        if code == 403:
            brief = "rejected (HTTP 403) — token does not match the DB. Regenerate via the dashboard."
        elif code == 401:
            brief = "rejected (HTTP 401) — missing/invalid X-Machine-Token header (agent bug?)"
        else:
            brief = f"rejected (HTTP {code}) — {e}"
        return Probe("ws_connect", False, brief, duration_s=elapsed)
    except (asyncio.TimeoutError, TimeoutError):
        elapsed = time.monotonic() - t0
        return Probe(
            "ws_connect", False,
            f"handshake timed out after {elapsed:.1f}s — relay unreachable or blocked.",
            duration_s=elapsed,
        )
    except Exception as e:
        elapsed = time.monotonic() - t0
        return Probe(
            "ws_connect", False, f"{type(e).__name__}: {e}", duration_s=elapsed,
        )


async def run_full_diagnose(config: "AgentConfig") -> list[Probe]:  # type: ignore[name-defined]
    """Run every probe and return them in display order."""
    return [
        await probe_dns(config.relay_url),
        await probe_tcp_v4(config.relay_url),
        await probe_tcp_v6(config.relay_url),
        await probe_ws_connect(config.relay_url, config.machine_id, config.token),
    ]


def format_report(probes: list[Probe]) -> str:
    lines = []
    for p in probes:
        marker = "✓" if p.ok else "✗"
        dur = f" ({p.duration_s:.2f}s)" if p.duration_s is not None else ""
        lines.append(f"  {marker} {p.name:<12} {p.brief}{dur}")
        if p.detail:
            lines.append(f"      {p.detail}")
    return "\n".join(lines)


def summarize(probes: list[Probe]) -> str:
    """One-line interpretation suitable for the smoke-check at end of `configure`."""
    by_name = {p.name: p for p in probes}
    ws = by_name.get("ws_connect")
    if ws is None:
        return "diagnose did not run"
    if ws.ok:
        return "✓ Agent can reach the relay and the token is valid."
    v4 = by_name.get("tcp_v4")
    v6 = by_name.get("tcp_v6")
    if v6 is not None and v4 is not None and v4.ok and not v6.ok:
        return (
            "⚠ IPv6 to the relay is blackholed on this network "
            "(v4 works, v6 does not). The agent's v4-first connect should still "
            "succeed — re-run `remotedev-agent diagnose` after starting the agent."
        )
    if v4 is not None and not v4.ok:
        return f"✗ Cannot reach the relay over IPv4: {v4.brief}"
    return f"✗ {ws.brief}"
