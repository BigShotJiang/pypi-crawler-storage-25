import os
import subprocess
import sys
from pathlib import Path

LAUNCHD_LABEL = "io.remotedev.agent"

PLIST_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>io.remotedev.agent</string>
    <key>ProgramArguments</key>
    <array>
        <string>{python_path}</string>
        <string>-m</string>
        <string>remotedev_agent.cli</string>
        <string>start</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <dict>
        <key>SuccessfulExit</key>
        <false/>
        <key>Crashed</key>
        <true/>
    </dict>
    <key>ThrottleInterval</key>
    <integer>10</integer>
    <key>StandardOutPath</key>
    <string>{log_path}</string>
    <key>StandardErrorPath</key>
    <string>{log_path}</string>
    <key>WorkingDirectory</key>
    <string>{home}</string>
    <key>EnvironmentVariables</key>
    <dict>
        <key>PATH</key>
        <string>{path_value}</string>
        <key>HOME</key>
        <string>{home}</string>
    </dict>
</dict>
</plist>"""


def _user_path() -> str:
    """Capture the invoking user's PATH so launchd-managed agents discover the
    same set of AI tools (claude, codex, etc.) as foreground/detached mode.
    Falls back to a sensible default if PATH isn't set.
    """
    extras = ["/opt/homebrew/bin", "/usr/local/bin", "/usr/bin", "/bin", "/usr/sbin", "/sbin"]
    user_path = os.environ.get("PATH", "")
    parts = [p for p in user_path.split(":") if p]
    seen = set()
    merged = []
    for p in parts + extras:
        if p and p not in seen:
            merged.append(p)
            seen.add(p)
    return ":".join(merged)


def _gui_domain() -> str | None:
    """Per-user launchd domain for modern launchctl (`bootstrap`/`bootout`).

    Returns None on platforms without `os.getuid` (Windows) so the caller can
    fall back to the legacy `load`/`unload` path.
    """
    if not hasattr(os, "getuid"):
        return None
    return f"gui/{os.getuid()}"


def _bootout(plist_path: Path, label: str) -> None:
    """Best-effort tear-down of any prior load of this label.

    Tries modern `bootout` first, then legacy `unload`. Both are no-ops if
    the service isn't loaded, so failures are ignored.
    """
    domain = _gui_domain()
    if domain is not None:
        subprocess.run(
            ["launchctl", "bootout", f"{domain}/{label}"],
            check=False, capture_output=True,
        )
    subprocess.run(
        ["launchctl", "unload", str(plist_path)],
        check=False, capture_output=True,
    )


def _bootstrap(plist_path: Path) -> tuple[bool, str]:
    """Load the plist into the user's launchd domain.

    Tries `bootstrap` first (returns non-zero on failure — unlike `load`,
    which returns 0 even when it prints "Input/output error" to stderr) and
    falls back to legacy `load` if `bootstrap` isn't available on this
    macOS version. Returns (success, error_message).
    """
    domain = _gui_domain()
    if domain is not None:
        res = subprocess.run(
            ["launchctl", "bootstrap", domain, str(plist_path)],
            capture_output=True, text=True,
        )
        if res.returncode == 0:
            return True, ""
        # If the subcommand simply isn't supported (very old macOS), fall
        # through to legacy `load`. Otherwise surface the real error.
        stderr = (res.stderr or "").strip()
        if "Unrecognized subcommand" not in stderr and "unknown subcommand" not in stderr.lower():
            return False, stderr or f"launchctl bootstrap exited {res.returncode}"

    res = subprocess.run(
        ["launchctl", "load", str(plist_path)],
        capture_output=True, text=True,
    )
    # Legacy `load` infamously returns 0 even on "Input/output error". Treat
    # any stderr output as a failure so the user isn't told the service is
    # installed when it actually isn't.
    stderr = (res.stderr or "").strip()
    if res.returncode != 0 or stderr:
        return False, stderr or f"launchctl load exited {res.returncode}"
    return True, ""


def install():
    home = Path.home()
    # Match the path used by `remotedev-agent logs` so a single command
    # works for both detached and service modes.
    log_path = home / ".remotedev" / "agent.log"
    plist_path = home / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"

    plist_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)

    # Detached mode and service mode would race for the same log/PID file.
    # Stop any detached instance and surface the result so the user knows
    # what happened.
    try:
        from remotedev_agent import process_manager
        if process_manager.is_running():
            ok, message = process_manager.stop()
            print(message)
    except Exception as e:
        print(f"Warning: failed to stop detached agent before install: {e}")

    plist_content = PLIST_TEMPLATE.format(
        python_path=sys.executable,
        log_path=str(log_path),
        home=str(home),
        path_value=_user_path(),
    )
    plist_path.write_text(plist_content)

    _bootout(plist_path, LAUNCHD_LABEL)
    ok, err = _bootstrap(plist_path)
    if not ok:
        print(f"Failed to load service: {err}", file=sys.stderr)
        print(f"Plist written to {plist_path} but not loaded.", file=sys.stderr)
        print("Tip: `remotedev-agent start --detach` works around launchd.", file=sys.stderr)
        raise SystemExit(1)
    print(f"Service installed at {plist_path}")
    print(f"Logs: {log_path}")
    print("View logs:  remotedev-agent logs -f")
    print("Status:     remotedev-agent status")
    print("Restart:    remotedev-agent restart")


def uninstall():
    plist_path = Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
    if plist_path.exists():
        _bootout(plist_path, LAUNCHD_LABEL)
        plist_path.unlink()
        print("Service uninstalled")
    else:
        print("Service not installed")
