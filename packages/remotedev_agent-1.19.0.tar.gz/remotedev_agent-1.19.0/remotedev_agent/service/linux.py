import os
import subprocess
import sys
from pathlib import Path

UNIT_TEMPLATE = """[Unit]
Description=Remote AI Maestro Agent
After=network.target
StartLimitIntervalSec=60
StartLimitBurst=5

[Service]
Type=simple
ExecStart={python_path} -m remotedev_agent.cli start
Restart=on-failure
RestartSec=10
WorkingDirectory={home}
Environment="PATH={path_value}"
Environment="HOME={home}"
StandardOutput=append:{log_path}
StandardError=append:{log_path}

[Install]
WantedBy=default.target
"""


def _user_path() -> str:
    extras = ["/usr/local/bin", "/usr/bin", "/bin", "/usr/sbin", "/sbin"]
    user_path = os.environ.get("PATH", "")
    parts = [p for p in user_path.split(":") if p]
    seen = set()
    merged = []
    for p in parts + extras:
        if p and p not in seen:
            merged.append(p)
            seen.add(p)
    return ":".join(merged)


def install():
    home = Path.home()
    log_path = home / ".remotedev" / "agent.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        from remotedev_agent import process_manager
        if process_manager.is_running():
            ok, message = process_manager.stop()
            print(message)
    except Exception as e:
        print(f"Warning: failed to stop detached agent before install: {e}")

    unit_dir = home / ".config" / "systemd" / "user"
    unit_dir.mkdir(parents=True, exist_ok=True)
    unit_path = unit_dir / "remotedev-agent.service"

    unit_content = UNIT_TEMPLATE.format(
        python_path=sys.executable,
        home=str(home),
        path_value=_user_path(),
        log_path=str(log_path),
    )
    unit_path.write_text(unit_content)

    subprocess.run(["systemctl", "--user", "daemon-reload"], check=True)
    subprocess.run(["systemctl", "--user", "enable", "remotedev-agent"], check=True)
    subprocess.run(["systemctl", "--user", "restart", "remotedev-agent"], check=True)

    print(f"Service installed at {unit_path}")
    print(f"Logs:       {log_path}")
    print("View logs:  remotedev-agent logs -f  (or: journalctl --user -u remotedev-agent -f)")
    print("Status:     remotedev-agent status")
    print("Restart:    remotedev-agent restart")
    # On headless servers, services die on logout unless lingering is enabled.
    if not _has_linger():
        print("\nNote: enable boot-persistence with: sudo loginctl enable-linger $USER")


def _has_linger() -> bool:
    try:
        user = os.environ.get("USER") or ""
        if not user:
            import getpass
            user = getpass.getuser()
        res = subprocess.run(
            ["loginctl", "show-user", user, "-p", "Linger"],
            capture_output=True, text=True, timeout=2,
        )
        return "Linger=yes" in res.stdout
    except (OSError, subprocess.SubprocessError):
        return True  # assume OK; we don't want to nag falsely


def uninstall():
    subprocess.run(["systemctl", "--user", "stop", "remotedev-agent"], check=False)
    subprocess.run(["systemctl", "--user", "disable", "remotedev-agent"], check=False)
    unit_path = Path.home() / ".config" / "systemd" / "user" / "remotedev-agent.service"
    if unit_path.exists():
        unit_path.unlink()
    subprocess.run(["systemctl", "--user", "daemon-reload"], check=False)
    print("Service uninstalled")
