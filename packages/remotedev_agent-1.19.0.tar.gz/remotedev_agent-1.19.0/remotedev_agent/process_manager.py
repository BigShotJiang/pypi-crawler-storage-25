"""Detach the agent from the controlling terminal and manage its lifecycle.

The detach path is the lightweight alternative to `install-service`. It double-forks,
writes a PID file, and redirects stdio to a log file so the process survives
terminal close. On macOS/Linux, `install-service` is still the recommended path
for boot persistence and OS-managed restart.
"""

from __future__ import annotations

import errno
import hashlib
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path

CONFIG_DIR = Path.home() / ".remotedev"
PID_FILE = CONFIG_DIR / "agent.pid"
LOG_FILE = CONFIG_DIR / "agent.log"
LOG_MAX_BYTES = 10 * 1024 * 1024
LAUNCHD_LABEL = "io.remotedev.agent"
SYSTEMD_UNIT = "remotedev-agent"
PID_FILE_MARKER = "remotedev-agent"


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(CONFIG_DIR, 0o700)
    except OSError:
        pass


def _proc_starttime(pid: int) -> str | None:
    """Best-effort process-start identity so we can detect PID reuse.

    Returns a stable string identity (not a parsed timestamp). On Linux this
    is the kernel's clock-tick starttime from /proc/<pid>/stat; on macOS it's
    the lstart string from `ps`. On other platforms or failure, returns None
    and stop()/status() fall back to "is alive" semantics.

    NB: must NOT use Python's `hash()` — that is salted with PYTHONHASHSEED
    and produces different results in different processes, defeating the
    cross-process identity check.
    """
    try:
        if sys.platform.startswith("linux"):
            with open(f"/proc/{pid}/stat", "rb") as fh:
                fields = fh.read().split()
            return fields[21].decode("ascii", "replace")
        if sys.platform == "darwin":
            res = subprocess.run(
                ["ps", "-o", "lstart=", "-p", str(pid)],
                capture_output=True, text=True, timeout=2,
            )
            if res.returncode != 0:
                return None
            line = res.stdout.strip()
            return line or None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None
    return None


def _write_pid_record(pid: int) -> None:
    record = {
        "pid": pid,
        "starttime": _proc_starttime(pid),
        "marker": PID_FILE_MARKER,
        "exe": os.path.basename(sys.executable or ""),
    }
    tmp = PID_FILE.with_suffix(".pid.tmp")
    tmp.write_text(json.dumps(record))
    try:
        os.chmod(tmp, 0o600)
    except OSError:
        pass
    os.replace(tmp, PID_FILE)


def _read_pid_record() -> dict | None:
    if not PID_FILE.exists():
        return None
    try:
        raw = PID_FILE.read_text().strip()
        if not raw:
            return None
        if raw.startswith("{"):
            data = json.loads(raw)
            if isinstance(data, dict) and isinstance(data.get("pid"), int):
                return data
            return None
        # Backward-compat: bare integer (pre-1.1.0).
        return {"pid": int(raw), "starttime": None, "marker": None}
    except (ValueError, OSError, json.JSONDecodeError):
        return None


def read_pid() -> int | None:
    rec = _read_pid_record()
    if rec is None:
        return None
    pid = rec.get("pid")
    return pid if isinstance(pid, int) and pid > 0 else None


def is_running(pid: int | None = None) -> bool:
    pid = pid if pid is not None else read_pid()
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except OSError as e:
        return e.errno == errno.EPERM


def _is_our_process(rec: dict) -> bool:
    """Confirm the PID still points to *our* daemon (not a recycled PID)."""
    pid = rec.get("pid")
    if not isinstance(pid, int) or not is_running(pid):
        return False
    expected = rec.get("starttime")
    if expected is None:
        # No start-time captured (older pid file format or platform without
        # cheap support) — fall back to liveness only.
        return True
    actual = _proc_starttime(pid)
    if actual is None:
        return True
    return actual == expected


def _rotate_log() -> None:
    try:
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > LOG_MAX_BYTES:
            backup = LOG_FILE.with_suffix(".log.1")
            if backup.exists():
                backup.unlink()
            LOG_FILE.rename(backup)
    except OSError:
        pass


def service_status() -> dict:
    """Detect whether the agent is running via launchd (macOS) or systemd (Linux).

    Returns a dict with keys: kind ("launchd"|"systemd"|None), running (bool),
    detail (str). Cheap shell-out — runs in well under a second.
    """
    if sys.platform == "darwin":
        try:
            res = subprocess.run(
                ["launchctl", "list", LAUNCHD_LABEL],
                capture_output=True, text=True, timeout=3,
            )
            if res.returncode == 0:
                # Output contains "PID" = <int> if running; "PID" = - if loaded but stopped.
                running = '"PID" = ' in res.stdout and '"PID" = -' not in res.stdout
                return {"kind": "launchd", "running": running, "detail": res.stdout.strip()}
        except (OSError, subprocess.SubprocessError):
            pass
    elif sys.platform.startswith("linux"):
        # Only claim "systemd" if the unit file actually exists; otherwise
        # `systemctl is-active` will say "inactive" for a nonexistent unit
        # and we'd false-positive into the systemd branch of restart/stop.
        unit_path = Path.home() / ".config" / "systemd" / "user" / f"{SYSTEMD_UNIT}.service"
        if not unit_path.exists():
            return {"kind": None, "running": False, "detail": ""}
        try:
            res = subprocess.run(
                ["systemctl", "--user", "is-active", SYSTEMD_UNIT],
                capture_output=True, text=True, timeout=3,
            )
            state = res.stdout.strip()
            running = state == "active"
            return {"kind": "systemd", "running": running, "detail": state}
        except (OSError, subprocess.SubprocessError):
            pass
    return {"kind": None, "running": False, "detail": ""}


def detach_and_run(run_callable) -> int:
    """Daemonize via double-fork; in the grandchild, invoke run_callable().

    Returns the daemon PID in the original (parent) process. In the daemon,
    this function never returns — it runs run_callable() and exits.

    Raises RuntimeError if a detached agent is already running, the OS
    refuses fork(), or the grandchild fails to come up.
    """
    if sys.platform == "win32":
        raise RuntimeError("Detached mode is not supported on Windows. Use install-service or run in foreground.")

    _ensure_dir()

    rec = _read_pid_record()
    if rec and _is_our_process(rec):
        raise RuntimeError(f"Agent already running (PID {rec['pid']}). Stop it first with 'remotedev-agent stop'.")

    svc = service_status()
    if svc["running"]:
        raise RuntimeError(
            f"Agent is already running as a {svc['kind']} service. "
            f"Use 'remotedev-agent uninstall-service' before starting in detached mode."
        )

    if PID_FILE.exists():
        try:
            PID_FILE.unlink()
        except OSError:
            pass

    _rotate_log()

    try:
        first_child = os.fork()
    except OSError as e:
        raise RuntimeError(f"fork() failed: {e}") from e

    if first_child > 0:
        # Reap the first child so it doesn't linger as a zombie. The first
        # child exits immediately after the second fork.
        try:
            os.waitpid(first_child, 0)
        except OSError:
            pass
        # Wait for the grandchild to write its PID record.
        deadline = time.time() + 5
        recorded_pid: int | None = None
        while time.time() < deadline:
            rec2 = _read_pid_record()
            if rec2 and _is_our_process(rec2):
                recorded_pid = rec2["pid"]
                break
            time.sleep(0.05)
        if recorded_pid is None:
            raise RuntimeError(
                "Daemon did not start within 5s. Check ~/.remotedev/agent.log for the failure reason."
            )
        return recorded_pid

    # First child: become session leader, then fork again so we cannot
    # reacquire a controlling terminal.
    try:
        os.setsid()
    except OSError:
        pass

    try:
        second_child = os.fork()
    except OSError:
        os._exit(1)

    if second_child > 0:
        os._exit(0)

    # Grandchild — the actual daemon.
    # chdir("/") so a removable/network home doesn't pin its mount point.
    try:
        os.chdir("/")
    except OSError:
        pass
    os.umask(0o077)

    try:
        log_fh = open(LOG_FILE, "ab", buffering=0)
        try:
            os.chmod(LOG_FILE, 0o600)
        except OSError:
            pass
        devnull = open(os.devnull, "rb")
        os.dup2(devnull.fileno(), 0)
        os.dup2(log_fh.fileno(), 1)
        os.dup2(log_fh.fileno(), 2)
        # Close the originals — fds 1/2 are now valid via dup2.
        log_fh.close()
        devnull.close()
        # Close any other fds we inherited from the launcher (terminal, etc.).
        try:
            soft_limit = os.sysconf("SC_OPEN_MAX")
        except (AttributeError, ValueError, OSError):
            soft_limit = 1024
        os.closerange(3, max(int(soft_limit), 1024))
    except OSError:
        os._exit(1)

    try:
        sys.stdout = os.fdopen(1, "w", buffering=1)
        sys.stderr = os.fdopen(2, "w", buffering=1)
    except OSError:
        pass

    try:
        _write_pid_record(os.getpid())
    except OSError:
        # No PID file = no way to stop us. Better to die than to run as a
        # forever-orphan the user can't find.
        os._exit(1)

    def _cleanup_pid(*_args):
        try:
            if read_pid() == os.getpid():
                PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        os._exit(0)

    signal.signal(signal.SIGTERM, _cleanup_pid)
    signal.signal(signal.SIGINT, _cleanup_pid)
    # Ignore SIGHUP so a parent shell terminating doesn't take us down before
    # the user has a chance to run `remotedev-agent stop` cleanly. setsid()
    # already protects us from controlling-terminal SIGHUP, but be explicit.
    try:
        signal.signal(signal.SIGHUP, signal.SIG_IGN)
    except (AttributeError, ValueError):
        pass

    try:
        run_callable()
    finally:
        try:
            if read_pid() == os.getpid():
                PID_FILE.unlink(missing_ok=True)
        except Exception:
            pass
        os._exit(0)


def stop(timeout: float = 10.0) -> tuple[bool, str]:
    rec = _read_pid_record()
    if rec is None:
        return False, "No PID file found. Agent is not running in detached mode."
    pid = rec.get("pid")
    if not _is_our_process(rec):
        try:
            PID_FILE.unlink(missing_ok=True)
        except OSError:
            pass
        return False, f"Stale PID file removed (PID {pid} not running or recycled)."
    try:
        os.kill(pid, signal.SIGTERM)
    except OSError as e:
        return False, f"Failed to signal PID {pid}: {e}"

    deadline = time.time() + timeout
    while time.time() < deadline:
        if not is_running(pid):
            try:
                PID_FILE.unlink(missing_ok=True)
            except OSError:
                pass
            return True, f"Stopped agent (PID {pid})."
        time.sleep(0.1)

    try:
        os.kill(pid, signal.SIGKILL)
    except OSError:
        pass
    try:
        PID_FILE.unlink(missing_ok=True)
    except OSError:
        pass
    return True, f"Force-killed agent (PID {pid}) after {timeout:.0f}s."


def tail_log(lines: int = 200, follow: bool = False) -> None:
    if lines <= 0:
        lines = 1
    if not LOG_FILE.exists():
        print(f"No log file at {LOG_FILE}.")
        svc = service_status()
        if svc["kind"] == "systemd":
            print("Agent is managed by systemd; view logs with: journalctl --user -u remotedev-agent -f")
        else:
            print("Has the agent been started in detached mode or as a service?")
        return

    def _print_last_n(fh, n: int) -> None:
        try:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            if size == 0:
                return
            block = 65536
            data = b""
            while size > 0 and data.count(b"\n") <= n:
                step = min(block, size)
                size -= step
                fh.seek(size)
                data = fh.read(step) + data
            tail = b"\n".join(data.splitlines()[-n:])
            sys.stdout.buffer.write(tail)
            if tail and not tail.endswith(b"\n"):
                sys.stdout.buffer.write(b"\n")
            sys.stdout.flush()
        except OSError as e:
            print(f"Failed to read log: {e}")

    fh = open(LOG_FILE, "rb")
    try:
        _print_last_n(fh, lines)
        if not follow:
            return
        try:
            current_inode = os.fstat(fh.fileno()).st_ino
        except OSError:
            current_inode = None
        fh.seek(0, os.SEEK_END)
        try:
            while True:
                chunk = fh.read(4096)
                if chunk:
                    sys.stdout.buffer.write(chunk)
                    sys.stdout.flush()
                else:
                    time.sleep(0.5)
                    # Detect log rotation: if the file at LOG_FILE has been
                    # replaced (different inode) or truncated, reopen.
                    try:
                        if LOG_FILE.exists():
                            disk_inode = os.stat(LOG_FILE).st_ino
                            if current_inode is not None and disk_inode != current_inode:
                                fh.close()
                                fh = open(LOG_FILE, "rb")
                                current_inode = disk_inode
                                continue
                            disk_size = os.fstat(fh.fileno()).st_size
                            if fh.tell() > disk_size:
                                # Truncated — rewind.
                                fh.seek(0)
                    except OSError:
                        pass
        except KeyboardInterrupt:
            return
    finally:
        try:
            fh.close()
        except Exception:
            pass


def status() -> dict:
    rec = _read_pid_record()
    pid = rec.get("pid") if rec else None
    detached_running = bool(rec and _is_our_process(rec))
    svc = service_status()
    return {
        "pid": pid,
        "detached_running": detached_running,
        "service_kind": svc["kind"],
        "service_running": svc["running"],
        "service_detail": svc["detail"],
        "pid_file": str(PID_FILE),
        "log_file": str(LOG_FILE),
    }
