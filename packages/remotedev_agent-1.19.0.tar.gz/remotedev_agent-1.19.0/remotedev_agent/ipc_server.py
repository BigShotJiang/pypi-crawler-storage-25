"""Local-IPC server for the agent daemon.

A Unix domain socket at ``~/.remotedev/agent.sock`` (mode 0600) listens for
JSON commands from tools running in the user's tmux sandboxes — chiefly the
``maestro`` CLI and the ``maestro-mcp`` server. The socket is the bridge
from sandbox-side processes (which have no WebSocket of their own) to the
agent's existing WS connection to the relay.

Phase-1 protocol: newline-delimited JSON. Each line is one command and gets
exactly one reply. We deliberately do not pin a long-lived RPC framework —
this is a sub-100-line interface and pulling in grpc/jsonrpc would dwarf
the surface area.

Request shape::

    {"action": "browser_open", "url": "https://...", "sandbox_id": "..."}

Reply shape::

    {"ok": true}                                   # success
    {"ok": false, "error": "<human-readable>"}    # failure

The server runs as a long-lived asyncio task on the daemon's event loop,
started once in ``AgentDaemon.run()`` and torn down on SIGTERM. It survives
WS reconnects — when ``self.ws`` is None we surface a clear error to the
client rather than dropping the request, so the CLI can warn the user that
their machine is offline.
"""

import asyncio
import json
import os
import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from remotedev_agent.daemon import AgentDaemon


SOCKET_DIR = Path.home() / ".remotedev"
SOCKET_PATH = SOCKET_DIR / "agent.sock"

# Allowed actions a BROWSER_COMMAND can carry. Mirrors
# ``bridge/maestro_browser_bridge/protocol.py``'s ``BrowserAction`` —
# changes there require a matching update here.
_BROWSER_ACTIONS = frozenset({
    "navigate",
    "click",
    "type",
    "screenshot",
    "read_dom",
    "console_logs",
    "list_tabs",
})

# How long the IPC server waits for a BROWSER_RESULT before failing the
# CLI call. Generous — page loads + screenshots can take a few seconds —
# but bounded so a stuck bridge doesn't hang the caller forever.
_BROWSER_COMMAND_TIMEOUT_S = 30.0


class IPCServer:
    """Unix-socket server that accepts CLI / MCP commands.

    Lifetime is bound to the daemon. The single instance is owned by the
    ``AgentDaemon``, started once, and exposes ``start()`` / ``stop()``
    so the daemon can manage it alongside the WS connection loop.
    """

    def __init__(self, daemon: "AgentDaemon") -> None:
        self._daemon = daemon
        self._server: asyncio.AbstractServer | None = None

    async def start(self) -> None:
        # Best-effort: an old socket file from a crashed daemon prevents
        # bind. Remove it before opening.
        SOCKET_DIR.mkdir(parents=True, exist_ok=True)
        try:
            os.chmod(SOCKET_DIR, 0o700)
        except OSError:
            pass
        if SOCKET_PATH.exists():
            try:
                SOCKET_PATH.unlink()
            except OSError as e:
                print(f"[IPC] Could not remove stale socket {SOCKET_PATH}: {e}")

        self._server = await asyncio.start_unix_server(
            self._handle_client, path=str(SOCKET_PATH),
        )
        # Mode 0600 — only the daemon user can connect. The kernel honours
        # filesystem perms on Unix sockets on Linux/macOS, which is the only
        # authorization barrier we have (no token; the FS *is* the token).
        try:
            os.chmod(SOCKET_PATH, 0o600)
        except OSError as e:
            print(f"[IPC] Could not chmod socket: {e}")
        print(f"[IPC] Listening on {SOCKET_PATH}")

    async def stop(self) -> None:
        if self._server is None:
            return
        self._server.close()
        try:
            await self._server.wait_closed()
        except Exception:
            pass
        self._server = None
        try:
            if SOCKET_PATH.exists():
                SOCKET_PATH.unlink()
        except OSError:
            pass

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            # Cap the request size — a misbehaving client should never DOS
            # the daemon. 16KB is generous for a JSON command line.
            line = await asyncio.wait_for(reader.readline(), timeout=5.0)
            if not line:
                return
            if len(line) > 16 * 1024:
                await self._reply(writer, {"ok": False, "error": "Request too large"})
                return
            try:
                msg = json.loads(line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as e:
                await self._reply(writer, {"ok": False, "error": f"Invalid JSON: {e}"})
                return
            if not isinstance(msg, dict):
                await self._reply(writer, {"ok": False, "error": "Expected JSON object"})
                return

            reply = await self._dispatch(msg)
            await self._reply(writer, reply)
        except asyncio.TimeoutError:
            await self._reply(writer, {"ok": False, "error": "Read timeout"})
        except Exception as e:
            print(f"[IPC] Handler error: {e}")
            try:
                await self._reply(writer, {"ok": False, "error": str(e)})
            except Exception:
                pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass

    async def _reply(self, writer: asyncio.StreamWriter, payload: dict[str, Any]) -> None:
        data = (json.dumps(payload) + "\n").encode("utf-8")
        writer.write(data)
        await writer.drain()

    async def _dispatch(self, msg: dict[str, Any]) -> dict[str, Any]:
        action = msg.get("action")
        if action == "browser_open":
            return await self._handle_browser_open(msg)
        if action == "browser_command":
            return await self._handle_browser_command(msg)
        if action == "ping":
            return {"ok": True}
        return {"ok": False, "error": f"Unknown action: {action!r}"}

    async def _handle_browser_open(self, msg: dict[str, Any]) -> dict[str, Any]:
        url = msg.get("url")
        sandbox_id = msg.get("sandbox_id")
        if not isinstance(url, str) or not url:
            return {"ok": False, "error": "Missing 'url'"}
        if not isinstance(sandbox_id, str) or not sandbox_id:
            return {"ok": False, "error": "Missing 'sandbox_id'"}
        # Minimal URL hygiene — we don't want a CLI typo turning into an
        # arbitrary string the frontend tries to navigate to. Browsers
        # already reject odd schemes; this is just a friendlier early error.
        if not (url.startswith("http://") or url.startswith("https://")):
            return {"ok": False, "error": "URL must start with http:// or https://"}

        if self._daemon.ws is None:
            return {
                "ok": False,
                "error": "Agent is not connected to the relay (machine offline).",
            }

        try:
            await self._daemon.send({
                "type": "BROWSER_OPEN",
                "sandbox_id": sandbox_id,
                "payload": {"url": url},
                "ts": time.time(),
            })
        except Exception as e:
            return {"ok": False, "error": f"Send failed: {e}"}
        return {"ok": True}

    async def _handle_browser_command(self, msg: dict[str, Any]) -> dict[str, Any]:
        """Drive a full BROWSER_COMMAND through the agent → relay → bridge path.

        Builds the wire envelope, registers a Future keyed by command_id,
        sends the message, and awaits the matching BROWSER_RESULT (which
        the daemon's BROWSER_RESULT handler routes back to us).

        Args expected on ``msg``:
          - ``sandbox_id`` (str, required)
          - ``payload`` (dict, required) with an ``action`` of one of
            ``_BROWSER_ACTIONS``. Per-action required fields (url for
            navigate etc.) are validated by the bridge handler; this
            layer only checks the action whitelist + sandbox_id so
            obvious typos fail fast at the CLI rather than 30s later
            on timeout.
        """
        sandbox_id = msg.get("sandbox_id")
        payload = msg.get("payload")
        if not isinstance(sandbox_id, str) or not sandbox_id:
            return {"ok": False, "error": "Missing 'sandbox_id'"}
        if not isinstance(payload, dict):
            return {"ok": False, "error": "Missing 'payload' object"}
        action = payload.get("action")
        if not isinstance(action, str) or action not in _BROWSER_ACTIONS:
            return {
                "ok": False,
                "error": f"Action must be one of {sorted(_BROWSER_ACTIONS)} (got {action!r})",
            }

        if self._daemon.ws is None:
            return {
                "ok": False,
                "error": "Agent is not connected to the relay (machine offline).",
            }

        command_id = str(uuid.uuid4())
        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        self._daemon.pending_browser_commands[command_id] = future

        envelope = {
            "type": "BROWSER_COMMAND",
            "sandbox_id": sandbox_id,
            "command_id": command_id,
            "payload": payload,
            "ts": time.time(),
        }
        try:
            await self._daemon.send(envelope)
        except Exception as e:
            self._daemon.pending_browser_commands.pop(command_id, None)
            return {"ok": False, "error": f"Send failed: {e}"}

        try:
            result_msg = await asyncio.wait_for(
                future, timeout=_BROWSER_COMMAND_TIMEOUT_S
            )
        except asyncio.TimeoutError:
            self._daemon.pending_browser_commands.pop(command_id, None)
            return {
                "ok": False,
                "error": (
                    f"Bridge did not reply within {int(_BROWSER_COMMAND_TIMEOUT_S)}s — "
                    "is the maestro-browser-bridge daemon running on your laptop?"
                ),
            }

        # Forward the bridge's payload + error verbatim. The result_msg
        # envelope already has the shape:
        #   {type, command_id, sandbox_id, payload: {ok, current_url, ...}, error, ts}
        result_payload = result_msg.get("payload") or {}
        envelope_error = result_msg.get("error")
        return {
            "ok": bool(result_payload.get("ok")),
            "command_id": command_id,
            "result": result_payload,
            "error": envelope_error,
        }
