"""File operations backing the W3/WP-5/WP-5c Files + Editor + Search panels.

Pure helpers used by ``AgentDaemon`` handlers. Each takes a sandbox-folder
root and a *relative* path / query from the browser, validates that any
resolved path stays inside the root, then returns a dict that maps 1:1 to
the WS response shape consumed by the frontend.

Caps live here so they're cheap to evolve without touching daemon.py:
- ``MAX_LIST_ENTRIES``: protects against pathological directories like
  ``node_modules`` with tens of thousands of immediate children.
- ``MAX_READ_BYTES``: bounds the response size for the read-only viewer.
  When a file exceeds this we truncate and flag, rather than refusing,
  so the user can still skim large logs.
- ``MAX_WRITE_BYTES``: matches the read cap so the editor round-trip is
  symmetric. Larger payloads are rejected (frontend should split or warn).
- ``BINARY_PROBE_BYTES``: a null byte in the first chunk reliably flags
  non-text files (matches git's own heuristic). Cheap and well-tested.
- ``MAX_SEARCH_MATCHES``: capped at 500 — beyond this the user should
  refine the query rather than scroll through thousands of hits.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

MAX_LIST_ENTRIES = 500
MAX_READ_BYTES = 1_000_000
MAX_WRITE_BYTES = 1_000_000
BINARY_PROBE_BYTES = 8_192
MAX_SEARCH_MATCHES = 500
SEARCH_TIMEOUT_SECONDS = 15
# Folders we always skip during full-text search. ripgrep's defaults
# overlap with this list but we pass them through explicitly so the
# grep fallback honours the same boundary.
SEARCH_EXCLUDE_DIRS = (".git", "node_modules", "dist", "build", ".next", ".venv", "__pycache__")


def _resolve_inside(root: Path, relative_path: str) -> Path | None:
    """Return ``root / relative_path`` resolved, only if it stays under root.

    Treats an empty ``relative_path`` as the root itself (the browser sends
    "" to request the root listing). Returns ``None`` for anything that
    resolves outside the root — including absolute paths like
    ``/etc/passwd`` and traversal strings like ``../../foo``.
    """
    # Normalise: an empty string means "list the root".
    rel = relative_path.strip()
    candidate = root if rel == "" else (root / rel)
    try:
        resolved = candidate.resolve()
        root_resolved = root.resolve()
    except OSError:
        return None
    # Must be the root, or sit under it.
    if resolved == root_resolved:
        return resolved
    try:
        resolved.relative_to(root_resolved)
    except ValueError:
        return None
    return resolved


def list_directory(root: Path, relative_path: str) -> dict:
    """List the immediate children of ``root/relative_path``.

    Returns a dict with the response shape (``relative_path``, ``entries``,
    optional ``truncated``, optional ``error``). Sorted with directories
    before files, alphabetically within each group — matches the convention
    most file trees use and keeps the UI scannable.
    """
    target = _resolve_inside(root, relative_path)
    if target is None:
        return {"relative_path": relative_path, "entries": [], "error": "Path is outside sandbox"}
    if not target.exists():
        return {"relative_path": relative_path, "entries": [], "error": "Path does not exist"}
    if not target.is_dir():
        return {"relative_path": relative_path, "entries": [], "error": "Path is not a directory"}

    try:
        raw = list(target.iterdir())
    except PermissionError:
        return {"relative_path": relative_path, "entries": [], "error": "Permission denied"}
    except OSError as e:
        return {"relative_path": relative_path, "entries": [], "error": f"Cannot read directory: {e}"}

    # Sort: dirs first (alphabetical), then files (alphabetical). Case-insensitive
    # so "README" ends up near "readme.md" instead of arbitrarily ahead/behind.
    def sort_key(p: Path) -> tuple:
        is_file = not p.is_dir()
        return (is_file, p.name.lower())

    raw.sort(key=sort_key)

    truncated = len(raw) > MAX_LIST_ENTRIES
    if truncated:
        raw = raw[:MAX_LIST_ENTRIES]

    entries = []
    for p in raw:
        try:
            is_dir = p.is_dir()
        except OSError:
            # Broken symlink or permission glitch — skip rather than abort.
            continue
        entry: dict = {"name": p.name, "kind": "dir" if is_dir else "file"}
        if not is_dir:
            try:
                entry["size"] = p.stat().st_size
            except OSError:
                # File deleted mid-listing or permission issue — leave size off.
                pass
        entries.append(entry)

    response: dict = {"relative_path": relative_path, "entries": entries}
    if truncated:
        response["truncated"] = True
    return response


def read_file(root: Path, relative_path: str) -> dict:
    """Read a file's contents (or report why we can't).

    Returns a dict with ``relative_path`` + ``size`` (always), plus one of:
    - ``content`` (text payload, possibly truncated)
    - ``binary: True`` (no content — frontend renders "binary file")
    - ``error`` (path validation failure, not-a-file, etc.)
    - ``truncated: True`` when content is the first MAX_READ_BYTES of a
      larger file.
    """
    target = _resolve_inside(root, relative_path)
    if target is None:
        return {"relative_path": relative_path, "size": 0, "error": "Path is outside sandbox"}
    if not target.exists():
        return {"relative_path": relative_path, "size": 0, "error": "File does not exist"}
    if target.is_dir():
        return {"relative_path": relative_path, "size": 0, "error": "Path is a directory"}
    if not target.is_file():
        return {"relative_path": relative_path, "size": 0, "error": "Not a regular file"}

    try:
        size = target.stat().st_size
    except OSError as e:
        return {"relative_path": relative_path, "size": 0, "error": f"Cannot stat file: {e}"}

    try:
        with target.open("rb") as fh:
            probe = fh.read(BINARY_PROBE_BYTES)
            # Git's own heuristic: a null byte in the first ~8KB means binary.
            if b"\x00" in probe:
                return {"relative_path": relative_path, "size": size, "binary": True}
            # Read the rest up to MAX_READ_BYTES. We already consumed probe, so
            # read enough more to fill the cap (or until EOF).
            remaining = max(0, MAX_READ_BYTES - len(probe))
            rest = fh.read(remaining) if remaining else b""
            raw = probe + rest
            truncated = size > MAX_READ_BYTES
    except PermissionError:
        return {"relative_path": relative_path, "size": size, "error": "Permission denied"}
    except OSError as e:
        return {"relative_path": relative_path, "size": size, "error": f"Cannot read file: {e}"}

    # UTF-8 with replacement for the edge case of mixed-encoding files —
    # treats them as text rather than misclassifying as binary.
    try:
        content = raw.decode("utf-8")
    except UnicodeDecodeError:
        content = raw.decode("utf-8", errors="replace")

    response: dict = {"relative_path": relative_path, "size": size, "content": content}
    if truncated:
        response["truncated"] = True
    return response


def write_file(root: Path, relative_path: str, content: str) -> dict:
    """Write ``content`` to ``root/relative_path`` atomically.

    Strategy: write to a sibling tempfile and ``os.replace`` onto the
    target. This makes the swap atomic on POSIX so a partially-written
    file is never visible to readers (the editor on Save, or a watch).

    Validation order matches read_file so the error shape is predictable:
    1. Path must resolve inside the root (no traversal).
    2. relative_path must be non-empty (don't let "save" target a directory).
    3. content must be a str and UTF-8 encodable (reject binary corruption).
    4. encoded content must fit MAX_WRITE_BYTES.
    5. Parent directory must already exist — we don't `mkdir -p` because
       the editor never creates folders implicitly.
    6. If the target exists, it must be a regular file (no clobbering dirs).
    """
    if not isinstance(relative_path, str) or not relative_path.strip():
        return {"relative_path": relative_path if isinstance(relative_path, str) else "", "ok": False, "error": "Missing relative_path"}

    target = _resolve_inside(root, relative_path)
    if target is None:
        return {"relative_path": relative_path, "ok": False, "error": "Path is outside sandbox"}
    # Refuse to treat the root itself as a file target.
    try:
        if target.resolve() == root.resolve():
            return {"relative_path": relative_path, "ok": False, "error": "Cannot write to sandbox root"}
    except OSError:
        return {"relative_path": relative_path, "ok": False, "error": "Cannot resolve path"}

    if not isinstance(content, str):
        return {"relative_path": relative_path, "ok": False, "error": "Content must be a string"}

    # UTF-8 encode strict. If the browser sent us bytes that don't survive
    # round-tripping (e.g. lone surrogates), refuse instead of silently
    # mangling on disk.
    try:
        encoded = content.encode("utf-8")
    except UnicodeEncodeError as e:
        return {"relative_path": relative_path, "ok": False, "error": f"Content is not valid UTF-8: {e}"}

    if len(encoded) > MAX_WRITE_BYTES:
        return {"relative_path": relative_path, "ok": False, "error": f"Content exceeds {MAX_WRITE_BYTES} byte cap"}

    # Null bytes in the payload would survive a UTF-8 round trip but are
    # almost certainly a binary leak from the editor. Reject explicitly so
    # the response error message is actionable.
    if "\x00" in content:
        return {"relative_path": relative_path, "ok": False, "error": "Binary content not allowed"}

    parent = target.parent
    if not parent.exists():
        return {"relative_path": relative_path, "ok": False, "error": "Parent directory does not exist"}
    if not parent.is_dir():
        return {"relative_path": relative_path, "ok": False, "error": "Parent is not a directory"}

    if target.exists() and not target.is_file():
        return {"relative_path": relative_path, "ok": False, "error": "Target exists and is not a regular file"}

    # Atomic rename via a temp file in the same directory. Keeping the
    # tempfile next to the target ensures os.replace is a rename, not a
    # cross-device copy.
    tmp = parent / f".{target.name}.tmp.{os.getpid()}"
    try:
        with tmp.open("wb") as fh:
            fh.write(encoded)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except OSError:
                # fsync isn't available on every filesystem (e.g. some
                # network mounts). The atomic-rename guarantee is what
                # matters; durability through power loss is best-effort.
                pass
        os.replace(tmp, target)
    except PermissionError:
        _safe_unlink(tmp)
        return {"relative_path": relative_path, "ok": False, "error": "Permission denied"}
    except OSError as e:
        _safe_unlink(tmp)
        return {"relative_path": relative_path, "ok": False, "error": f"Cannot write file: {e}"}

    return {"relative_path": relative_path, "ok": True, "size": len(encoded)}


def _safe_unlink(p: Path) -> None:
    try:
        p.unlink()
    except OSError:
        pass


def search_files(
    root: Path,
    query: str,
    *,
    max_results: int | None = None,
    case_sensitive: bool = False,
) -> dict:
    """Full-text search for ``query`` under ``root``.

    Prefers ripgrep (``rg``) if installed — it's an order of magnitude
    faster and honours ``.gitignore`` by default. Falls back to
    ``grep -rIn`` (the ``-I`` skips binary files, ``-n`` adds line numbers)
    if rg isn't on PATH. The fallback misses some heuristics rg has
    (e.g. autodetected ignore files) but covers the common case.

    Returns ``{"query", "matches": [...], "truncated"?, "error"?}``. Each
    match is ``{path: <relative-to-root>, line: <1-based>, snippet: <str>}``.
    """
    if not isinstance(query, str) or not query:
        return {"query": query if isinstance(query, str) else "", "matches": [], "error": "Missing query"}

    cap = MAX_SEARCH_MATCHES if max_results is None else max(1, min(int(max_results), MAX_SEARCH_MATCHES))

    rg_path = shutil.which("rg")
    if rg_path is not None:
        cmd = [rg_path, "--no-heading", "--line-number", "--with-filename", "--color=never"]
        for d in SEARCH_EXCLUDE_DIRS:
            cmd.extend(["--glob", f"!{d}"])
        if not case_sensitive:
            cmd.append("-i")
        # Treat query as a literal string by default — the browser passes
        # what the user typed. Regex support can be wired in later via an
        # explicit flag without breaking callers.
        cmd.extend(["--fixed-strings", "--", query, str(root)])
    else:
        # grep fallback. -r (recursive), -I (skip binaries), -n (line nums),
        # --include excludes done via --exclude-dir. -F (fixed strings).
        cmd = ["grep", "-rInF"]
        if not case_sensitive:
            cmd.append("-i")
        for d in SEARCH_EXCLUDE_DIRS:
            cmd.append(f"--exclude-dir={d}")
        cmd.extend(["-e", query, str(root)])

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=SEARCH_TIMEOUT_SECONDS,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return {"query": query, "matches": [], "error": f"Search timed out after {SEARCH_TIMEOUT_SECONDS}s", "truncated": True}
    except FileNotFoundError as e:
        # Shouldn't happen — we checked which() — but cover the race.
        return {"query": query, "matches": [], "error": f"Search tool unavailable: {e}"}

    stdout = result.stdout or ""
    root_resolved = str(root.resolve())
    matches: list[dict] = []
    truncated = False
    for line in stdout.splitlines():
        if len(matches) >= cap:
            truncated = True
            break
        # Both rg and grep emit ``<absolute-path>:<lineno>:<snippet>``.
        # Split on the first two colons; the snippet may contain colons
        # of its own and must not be over-split.
        parts = line.split(":", 2)
        if len(parts) < 3:
            continue
        path_str, lineno_str, snippet = parts
        try:
            lineno = int(lineno_str)
        except ValueError:
            continue
        try:
            rel = str(Path(path_str).resolve().relative_to(root_resolved))
        except (ValueError, OSError):
            # Match outside root (shouldn't happen with our cmd but be
            # defensive) — surface the absolute path so debugging is easier.
            rel = path_str
        # Cap snippet length so a single 100KB minified line doesn't blow
        # the response size. 500 chars is well past the editor's typical
        # display width.
        if len(snippet) > 500:
            snippet = snippet[:500] + "…"
        matches.append({"path": rel, "line": lineno, "snippet": snippet})

    response: dict = {"query": query, "matches": matches}
    if truncated:
        response["truncated"] = True
    # grep / rg exit code 1 means "no matches" — both expected. Anything
    # else with non-empty stderr is worth surfacing.
    if result.returncode not in (0, 1) and result.stderr:
        response["error"] = result.stderr.strip().splitlines()[0][:200]
    return response
