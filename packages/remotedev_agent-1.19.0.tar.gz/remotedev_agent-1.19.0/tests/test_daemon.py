"""Tests for AgentDaemon dispatch, HMAC signing/verification, and path validation."""
from __future__ import annotations

import hashlib
import hmac
import json
from unittest.mock import AsyncMock, MagicMock

import pytest


# ---------------------------------------------------------------------------
# dispatch (handle) routing
# ---------------------------------------------------------------------------

async def test_handle_routes_open_terminal(daemon):
    daemon.handle_open_terminal = AsyncMock()
    await daemon.handle({
        "type": "OPEN_TERMINAL",
        "sandbox_id": "sbx-1",
        "payload": {"rows": 24, "cols": 80},
    })
    daemon.handle_open_terminal.assert_awaited_once_with("sbx-1", {"rows": 24, "cols": 80})


async def test_handle_routes_terminal_input(daemon):
    daemon.handle_terminal_input = MagicMock()
    await daemon.handle({
        "type": "TERMINAL_INPUT",
        "sandbox_id": "sbx-1",
        "payload": {"data": "ls\n"},
        "user_id": "u-1",
    })
    daemon.handle_terminal_input.assert_called_once_with("sbx-1", {"data": "ls\n"}, "u-1")


# ---------------------------------------------------------------------------
# HMAC
# ---------------------------------------------------------------------------

def test_verify_hmac_rejects_unsigned(daemon):
    """Regression for 7fe7440: _verify_hmac must return False (not True) on missing sig."""
    assert daemon._verify_hmac({"type": "PING", "payload": {}}) is False


def test_verify_hmac_accepts_properly_signed(daemon):
    msg = {"type": "PING", "payload": {"a": 1}, "ts": 123.0}
    payload_str = json.dumps(msg, sort_keys=True)
    sig = hmac.new(
        daemon.config.token.encode(),
        payload_str.encode(),
        hashlib.sha256,
    ).hexdigest()
    signed = dict(msg)
    signed["hmac_sig"] = sig
    assert daemon._verify_hmac(signed) is True


def test_verify_hmac_rejects_tampered(daemon):
    msg = {"type": "PING", "payload": {"a": 1}}
    payload_str = json.dumps(msg, sort_keys=True)
    sig = hmac.new(daemon.config.token.encode(), payload_str.encode(), hashlib.sha256).hexdigest()
    tampered = dict(msg)
    tampered["payload"] = {"a": 2}  # change after signing
    tampered["hmac_sig"] = sig
    assert daemon._verify_hmac(tampered) is False


def test_compute_hmac_is_stable_and_sort_key_based(daemon):
    msg = {"type": "X", "b": 2, "a": 1}
    expected = hmac.new(
        daemon.config.token.encode(),
        json.dumps(msg, sort_keys=True).encode(),
        hashlib.sha256,
    ).hexdigest()
    assert daemon._compute_hmac(json.dumps(msg, sort_keys=True)) == expected
    # Stable across calls
    assert daemon._compute_hmac(json.dumps(msg, sort_keys=True)) == expected


async def test_send_adds_hmac_sig(daemon):
    sent = {}

    class FakeWS:
        async def send(self, raw):
            sent["raw"] = raw

    daemon.ws = FakeWS()
    await daemon.send({"type": "HEARTBEAT", "payload": {}, "ts": 1.0})
    decoded = json.loads(sent["raw"])
    assert "hmac_sig" in decoded
    # Verify roundtrip: the signature validates
    assert daemon._verify_hmac(decoded) is True


# ---------------------------------------------------------------------------
# Path validation
# ---------------------------------------------------------------------------

def test_validate_path_rejects_traversal(daemon, tmp_path):
    bad = str(tmp_path / ".." / "etc")
    with pytest.raises(ValueError):
        daemon._validate_path(bad)


def test_validate_path_rejects_outside_root(daemon):
    with pytest.raises(ValueError):
        daemon._validate_path("/etc/passwd")


def test_validate_path_accepts_valid(daemon, tmp_path):
    good = tmp_path / "my-sbx"
    resolved = daemon._validate_path(str(good))
    assert str(resolved).startswith(str(tmp_path))


def test_validate_path_accepts_root_itself(daemon, tmp_path):
    # The root itself is allowed per the code's `resolved != sandboxes_root` check
    resolved = daemon._validate_path(str(tmp_path))
    assert resolved == tmp_path.resolve()


# ---------------------------------------------------------------------------
# IPv4-first connect (regression for blackholed-v6 networks)
# ---------------------------------------------------------------------------

async def test_tcp_connect_v4_first_returns_socket_when_v4_available(daemon, monkeypatch):
    """When DNS returns A records and the v4 connect succeeds, return a
    pre-connected socket so websockets does the WS upgrade on it instead of
    hitting v6 first.
    """
    import socket as socket_mod
    from unittest.mock import AsyncMock, MagicMock, patch

    daemon.config.relay_url = "wss://relay.example.com"

    fake_sock = MagicMock()
    fake_sock.setblocking = MagicMock()
    fake_sock.close = MagicMock()

    async def fake_getaddrinfo(host, port, *, family, type):
        # Caller asks specifically for AF_INET — assert that and return a v4 record.
        assert family == socket_mod.AF_INET
        return [(socket_mod.AF_INET, socket_mod.SOCK_STREAM, 0, "", ("104.21.9.148", 443))]

    loop = MagicMock()
    loop.getaddrinfo = fake_getaddrinfo
    loop.sock_connect = AsyncMock(return_value=None)
    with patch("remotedev_agent.daemon.asyncio.get_event_loop", return_value=loop), \
         patch("remotedev_agent.daemon.socket.socket", return_value=fake_sock):
        result = await daemon._tcp_connect_v4_first()
    assert result is fake_sock
    fake_sock.close.assert_not_called()


async def test_tcp_connect_v4_first_returns_none_when_no_v4(daemon, monkeypatch):
    """When the network has no v4 path (rare but possible — pure-v6 deployment),
    return None so the caller falls back to default resolution.
    """
    import socket as socket_mod
    from unittest.mock import MagicMock, patch

    daemon.config.relay_url = "wss://relay.example.com"

    async def fake_getaddrinfo(host, port, *, family, type):
        return []  # No v4 records

    loop = MagicMock()
    loop.getaddrinfo = fake_getaddrinfo
    with patch("remotedev_agent.daemon.asyncio.get_event_loop", return_value=loop):
        result = await daemon._tcp_connect_v4_first()
    assert result is None


async def test_tcp_connect_v4_first_returns_none_when_v4_connect_fails(daemon, monkeypatch):
    """If the v4 SYN itself times out (e.g. some weird firewall), return None
    so the caller can fall back to letting websockets try v6 — better some
    chance than no chance.
    """
    import asyncio as _asyncio
    import socket as socket_mod
    from unittest.mock import AsyncMock, MagicMock, patch

    daemon.config.relay_url = "wss://relay.example.com"

    fake_sock = MagicMock()

    async def fake_getaddrinfo(host, port, *, family, type):
        return [(socket_mod.AF_INET, socket_mod.SOCK_STREAM, 0, "", ("1.2.3.4", 443))]

    async def hanging_sock_connect(s, addr):
        await _asyncio.sleep(10)  # pretend it hangs

    loop = MagicMock()
    loop.getaddrinfo = fake_getaddrinfo
    loop.sock_connect = hanging_sock_connect
    with patch("remotedev_agent.daemon.asyncio.get_event_loop", return_value=loop), \
         patch("remotedev_agent.daemon.socket.socket", return_value=fake_sock):
        # The function uses asyncio.wait_for(..., timeout=5.0) internally; we
        # don't want to actually wait 5s in the test, so monkey-patch wait_for
        # to immediately raise TimeoutError.
        async def quick_timeout(coro, *, timeout):
            coro.close()
            raise _asyncio.TimeoutError()
        with patch("remotedev_agent.daemon.asyncio.wait_for", side_effect=quick_timeout):
            result = await daemon._tcp_connect_v4_first()
    assert result is None
    fake_sock.close.assert_called()
