"""Unit tests for the self-diagnostic probes and the user-facing report.

We mock out network calls so these tests work on any machine, including CI
runners with no outbound v6.
"""
from __future__ import annotations

import socket
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from remotedev_agent import diagnostics


@pytest.fixture
def relay_url() -> str:
    return "wss://relay.example.com"


# ---------------------------------------------------------------------------
# DNS probe
# ---------------------------------------------------------------------------

async def test_probe_dns_reports_v4_and_v6_counts(relay_url):
    addrinfo = [
        (socket.AF_INET, socket.SOCK_STREAM, 0, "", ("104.21.9.148", 0)),
        (socket.AF_INET, socket.SOCK_STREAM, 0, "", ("172.67.160.48", 0)),
        (socket.AF_INET6, socket.SOCK_STREAM, 0, "", ("2606:4700:3030::1", 0, 0, 0)),
    ]
    loop = MagicMock()

    async def fake_getaddrinfo(host, port, *, type):
        return addrinfo

    loop.getaddrinfo = fake_getaddrinfo
    with patch("remotedev_agent.diagnostics.asyncio.get_event_loop", return_value=loop):
        p = await diagnostics.probe_dns(relay_url)
    assert p.ok
    assert "2 A record" in p.brief
    assert "1 AAAA record" in p.brief
    assert p.extras["v4"] == ["104.21.9.148", "172.67.160.48"]
    assert p.extras["v6"] == ["2606:4700:3030::1"]


async def test_probe_dns_reports_failure(relay_url):
    loop = MagicMock()

    async def fake_getaddrinfo(host, port, *, type):
        raise socket.gaierror("Name or service not known")

    loop.getaddrinfo = fake_getaddrinfo
    with patch("remotedev_agent.diagnostics.asyncio.get_event_loop", return_value=loop):
        p = await diagnostics.probe_dns(relay_url)
    assert not p.ok
    assert "resolution failed" in p.brief


# ---------------------------------------------------------------------------
# TCP probes (the actual user-facing v6-blackhole detector)
# ---------------------------------------------------------------------------

async def test_probe_tcp_v4_succeeds_when_connect_succeeds(relay_url):
    loop = MagicMock()

    async def fake_getaddrinfo(host, port, *, family, type):
        assert family == socket.AF_INET
        return [(socket.AF_INET, socket.SOCK_STREAM, 0, "", ("1.2.3.4", 443))]

    loop.getaddrinfo = fake_getaddrinfo
    loop.sock_connect = AsyncMock(return_value=None)
    fake_sock = MagicMock()
    with patch("remotedev_agent.diagnostics.asyncio.get_event_loop", return_value=loop), \
         patch("remotedev_agent.diagnostics.socket.socket", return_value=fake_sock):
        p = await diagnostics.probe_tcp_v4(relay_url, timeout=1.0)
    assert p.ok
    assert "1.2.3.4:443" in p.brief


async def test_probe_tcp_v6_reports_blackholed_network(relay_url):
    """The exact failure mode users hit on broken-v6 networks: AAAA exists,
    SYN goes out, no SYN+ACK comes back. The probe must exit on its own
    timeout (not the test runner's) and surface a clear v6-failure message.
    """
    loop = MagicMock()

    async def fake_getaddrinfo(host, port, *, family, type):
        assert family == socket.AF_INET6
        return [(socket.AF_INET6, socket.SOCK_STREAM, 0, "", ("2606::1", 443, 0, 0))]

    async def hanging_connect(s, addr):
        await asyncio.sleep(10)

    loop.getaddrinfo = fake_getaddrinfo
    loop.sock_connect = hanging_connect
    fake_sock = MagicMock()
    with patch("remotedev_agent.diagnostics.asyncio.get_event_loop", return_value=loop), \
         patch("remotedev_agent.diagnostics.socket.socket", return_value=fake_sock):
        p = await diagnostics.probe_tcp_v6(relay_url, timeout=0.2)
    assert not p.ok
    assert "timeout" in p.brief.lower()


# ---------------------------------------------------------------------------
# Summary string — drives the post-configure smoke output
# ---------------------------------------------------------------------------

def test_summarize_flags_blackholed_v6():
    probes = [
        diagnostics.Probe("dns", True, "ok"),
        diagnostics.Probe("tcp_v4", True, "ok"),
        diagnostics.Probe("tcp_v6", False, "timeout"),
        diagnostics.Probe("ws_connect", False, "handshake timed out"),
    ]
    s = diagnostics.summarize(probes)
    assert "IPv6" in s and "blackholed" in s


def test_summarize_celebrates_success():
    probes = [
        diagnostics.Probe("dns", True, "ok"),
        diagnostics.Probe("tcp_v4", True, "ok"),
        diagnostics.Probe("tcp_v6", False, "timeout"),
        diagnostics.Probe("ws_connect", True, "handshake completed"),
    ]
    s = diagnostics.summarize(probes)
    assert s.startswith("✓")
    assert "valid" in s


def test_summarize_distinguishes_auth_from_network():
    """Token-mismatch produces a 403 brief from the WS probe; summary should
    pass that through verbatim so the user knows it's an auth issue, not
    a connectivity issue."""
    probes = [
        diagnostics.Probe("dns", True, "ok"),
        diagnostics.Probe("tcp_v4", True, "ok"),
        diagnostics.Probe("tcp_v6", True, "ok"),
        diagnostics.Probe("ws_connect", False,
                          "rejected (HTTP 403) — token does not match the DB."),
    ]
    s = diagnostics.summarize(probes)
    assert "403" in s
    assert "token" in s.lower()


# ---------------------------------------------------------------------------
# Format
# ---------------------------------------------------------------------------

def test_format_report_includes_marker_and_duration():
    probes = [
        diagnostics.Probe("dns", True, "1 record", duration_s=0.05),
        diagnostics.Probe("tcp_v6", False, "timeout (>5s)", duration_s=5.01),
    ]
    out = diagnostics.format_report(probes)
    assert "✓ dns" in out
    assert "✗ tcp_v6" in out
    assert "0.05s" in out
    assert "5.01s" in out


# ---------------------------------------------------------------------------
# CLI integration — `--version` and `diagnose` exist & wire correctly
# ---------------------------------------------------------------------------

def test_cli_has_version_flag():
    from click.testing import CliRunner
    from remotedev_agent.cli import cli
    runner = CliRunner()
    result = runner.invoke(cli, ["--version"])
    assert result.exit_code == 0
    assert "remotedev-agent" in result.output
    # Should contain a version string of some kind (digit dot digit).
    import re
    assert re.search(r"\d+\.\d+\.\d+", result.output) or "unknown" in result.output


def test_cli_diagnose_command_registered():
    from click.testing import CliRunner
    from remotedev_agent.cli import cli
    runner = CliRunner()
    result = runner.invoke(cli, ["diagnose", "--help"])
    assert result.exit_code == 0
    assert "self-diagnostic" in result.output.lower()


def test_cli_configure_has_no_verify_flag():
    from click.testing import CliRunner
    from remotedev_agent.cli import cli
    runner = CliRunner()
    result = runner.invoke(cli, ["configure", "--help"])
    assert result.exit_code == 0
    assert "--no-verify" in result.output
