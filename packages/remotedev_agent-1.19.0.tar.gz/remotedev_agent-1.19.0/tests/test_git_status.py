"""Tests for handle_git_status_request — the W2b agent feature.

Frontend asks for git status via GIT_STATUS_REQUEST; agent replies with
GIT_STATUS_RESPONSE shaped like {branch, staged, modified, untracked}.
The handler has three folder-path source paths (payload > PTY session >
none) and degrades to a not-a-repo response rather than erroring out, so
the workspace Git panel stays usable even on edge cases.
"""
from __future__ import annotations

import json
import subprocess
from unittest.mock import AsyncMock, MagicMock

import pytest


async def test_dispatch_routes_git_status_request(daemon):
    daemon.handle_git_status_request = AsyncMock()
    await daemon.handle({
        "type": "GIT_STATUS_REQUEST",
        "sandbox_id": "sbx-1",
        "payload": {"folder_path": "/tmp/x"},
    })
    daemon.handle_git_status_request.assert_awaited_once_with(
        "sbx-1", {"folder_path": "/tmp/x"}
    )


def _git(*args, cwd):
    subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True)


def _init_repo(path):
    _git("init", "-q", "-b", "main", cwd=str(path))
    _git("config", "user.email", "test@example.com", cwd=str(path))
    _git("config", "user.name", "Test", cwd=str(path))


async def test_clean_repo_returns_branch_and_empty_lists(daemon, tmp_path):
    repo = tmp_path / "sandbox"
    repo.mkdir()
    _init_repo(repo)
    (repo / "README.md").write_text("hi\n")
    _git("add", "README.md", cwd=str(repo))
    _git("commit", "-qm", "init", cwd=str(repo))

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda msg: sent.append(msg))

    await daemon.handle_git_status_request("sbx-1", {"folder_path": str(repo)})

    assert len(sent) == 1
    payload = sent[0]["payload"]
    assert sent[0]["type"] == "GIT_STATUS_RESPONSE"
    assert sent[0]["sandbox_id"] == "sbx-1"
    assert payload["branch"] == "main"
    assert payload["staged"] == []
    assert payload["modified"] == []
    assert payload["untracked"] == []


async def test_mixed_changes_classified_correctly(daemon, tmp_path):
    repo = tmp_path / "sandbox"
    repo.mkdir()
    _init_repo(repo)
    (repo / "a.txt").write_text("a\n")
    _git("add", "a.txt", cwd=str(repo))
    _git("commit", "-qm", "init", cwd=str(repo))

    # Modify the tracked file (working tree mod, not staged)
    (repo / "a.txt").write_text("modified\n")
    # New file staged
    (repo / "b.txt").write_text("b\n")
    _git("add", "b.txt", cwd=str(repo))
    # Untracked file
    (repo / "c.txt").write_text("c\n")

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda msg: sent.append(msg))

    await daemon.handle_git_status_request("sbx-1", {"folder_path": str(repo)})

    payload = sent[0]["payload"]
    assert payload["branch"] == "main"
    assert "b.txt" in payload["staged"]
    assert "a.txt" in payload["modified"]
    assert "c.txt" in payload["untracked"]


async def test_not_a_repo_returns_branch_null(daemon, tmp_path):
    folder = tmp_path / "sandbox"
    folder.mkdir()
    (folder / "x.txt").write_text("x\n")  # not a git repo

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda msg: sent.append(msg))

    await daemon.handle_git_status_request("sbx-1", {"folder_path": str(folder)})

    assert sent[0]["payload"] == {
        "branch": None,
        "staged": [],
        "modified": [],
        "untracked": [],
    }


async def test_derives_folder_path_from_pty_session(daemon, tmp_path):
    """When payload omits folder_path, the agent falls back to the PTY
    session's cwd. Matches handle_open_terminal's source-of-truth order."""
    repo = tmp_path / "sandbox"
    repo.mkdir()
    _init_repo(repo)

    fake_session = MagicMock()
    fake_session.cwd = str(repo)
    # live_cwd() is the v1.6.0 source-of-truth — model it returning None so
    # the resolver falls back to the recorded cwd (also covers the
    # tmux-unreachable case in production).
    fake_session.live_cwd = MagicMock(return_value=None)
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda msg: sent.append(msg))

    await daemon.handle_git_status_request("sbx-1", {})  # no folder_path

    assert sent[0]["payload"]["branch"] == "main"


async def test_no_folder_path_no_session_returns_null_branch(daemon):
    """No payload folder_path and no PTY session — degrade gracefully so
    the workspace Git panel renders 'not a git repo' instead of timing out."""
    daemon.pty_manager.get_session = MagicMock(return_value=None)

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda msg: sent.append(msg))

    await daemon.handle_git_status_request("sbx-1", {})

    assert sent[0]["payload"] == {
        "branch": None,
        "staged": [],
        "modified": [],
        "untracked": [],
    }


async def test_path_traversal_rejected_silently(daemon):
    """A path outside sandboxes_root must not leak the failure reason —
    just respond with the not-a-repo shape. Regression: don't echo the
    rejected path back to the browser."""
    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda msg: sent.append(msg))

    # ../etc passes Path.resolve() to somewhere outside sandboxes_root
    await daemon.handle_git_status_request(
        "sbx-1", {"folder_path": "/etc/passwd"}
    )

    assert sent[0]["payload"] == {
        "branch": None,
        "staged": [],
        "modified": [],
        "untracked": [],
    }
    # Make sure the bad path didn't leak into the response.
    serialized = json.dumps(sent[0])
    assert "/etc/passwd" not in serialized
