"""Unit tests for the macOS launchd installer.

Covers the modern-vs-legacy launchctl path the installer takes. These tests
mock subprocess so they run on any platform — they are not Darwin-gated.
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from remotedev_agent.service import macos


def _completed(returncode: int = 0, stdout: str = "", stderr: str = "") -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess(args=[], returncode=returncode, stdout=stdout, stderr=stderr)


def test_bootstrap_uses_modern_command_when_available():
    plist = Path("/tmp/io.remotedev.agent.plist")
    with patch("remotedev_agent.service.macos.subprocess.run") as run, \
         patch("remotedev_agent.service.macos.os.getuid", return_value=501, create=True):
        run.return_value = _completed(returncode=0)
        ok, err = macos._bootstrap(plist)
    assert ok is True
    assert err == ""
    args, _ = run.call_args
    assert args[0][:2] == ["launchctl", "bootstrap"]
    assert args[0][2] == "gui/501"


def test_bootstrap_falls_back_to_legacy_load_on_unrecognized_subcommand():
    plist = Path("/tmp/io.remotedev.agent.plist")
    calls = []

    def fake_run(cmd, **kwargs):
        calls.append(cmd)
        if cmd[1] == "bootstrap":
            return _completed(returncode=64, stderr="Unrecognized subcommand")
        return _completed(returncode=0)

    with patch("remotedev_agent.service.macos.subprocess.run", side_effect=fake_run), \
         patch("remotedev_agent.service.macos.os.getuid", return_value=501, create=True):
        ok, err = macos._bootstrap(plist)
    assert ok is True
    assert err == ""
    assert [c[1] for c in calls] == ["bootstrap", "load"]


def test_bootstrap_surfaces_real_failure_instead_of_falling_back():
    plist = Path("/tmp/io.remotedev.agent.plist")
    with patch("remotedev_agent.service.macos.subprocess.run") as run, \
         patch("remotedev_agent.service.macos.os.getuid", return_value=501, create=True):
        run.return_value = _completed(returncode=5, stderr="Input/output error")
        ok, err = macos._bootstrap(plist)
    assert ok is False
    assert "Input/output error" in err
    # Crucially: did NOT silently fall through to legacy `load`, which would
    # have hidden the failure (load returns 0 even when it logs I/O errors).
    assert run.call_count == 1


def test_bootstrap_legacy_load_treats_stderr_as_failure():
    """Legacy `launchctl load` returns 0 even on errors. We treat any stderr
    output as failure so users aren't told the service installed when it didn't.
    """
    plist = Path("/tmp/io.remotedev.agent.plist")

    def fake_run(cmd, **kwargs):
        if cmd[1] == "bootstrap":
            return _completed(returncode=64, stderr="Unrecognized subcommand")
        # Legacy load: rc=0 but "Input/output error" on stderr — the exact
        # bug we're guarding against.
        return _completed(returncode=0, stderr="Load failed: 5: Input/output error")

    with patch("remotedev_agent.service.macos.subprocess.run", side_effect=fake_run), \
         patch("remotedev_agent.service.macos.os.getuid", return_value=501, create=True):
        ok, err = macos._bootstrap(plist)
    assert ok is False
    assert "Input/output error" in err


def test_install_raises_systemexit_on_load_failure(tmp_path, monkeypatch):
    """install() must NOT print 'Service installed' when the load fails."""
    from remotedev_agent import process_manager

    home = tmp_path
    monkeypatch.setattr(macos.Path, "home", classmethod(lambda cls: home))
    monkeypatch.setattr(process_manager, "is_running", lambda: False)
    with patch("remotedev_agent.service.macos.subprocess.run") as run, \
         patch("remotedev_agent.service.macos.os.getuid", return_value=501, create=True):
        run.return_value = _completed(returncode=5, stderr="Input/output error")
        with pytest.raises(SystemExit) as exc:
            macos.install()
    assert exc.value.code == 1
    plist = home / "Library" / "LaunchAgents" / "io.remotedev.agent.plist"
    # Plist still gets written (so the user can debug it), but service isn't loaded.
    assert plist.exists()
