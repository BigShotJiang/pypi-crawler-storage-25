"""Tests for the maestro CLI.

The CLI is a thin Click wrapper around the IPC socket. We use Click's
CliRunner to invoke commands and assert on the IPC payload and exit
codes — the actual socket I/O is mocked.
"""
from __future__ import annotations

from unittest.mock import patch

import pytest
from click.testing import CliRunner

from remotedev_agent import maestro_cli


def test_browser_open_requires_http_scheme():
    """Bad scheme fails before any socket I/O — no daemon required."""
    runner = CliRunner()
    result = runner.invoke(maestro_cli.cli, ["browser", "open", "javascript:alert(1)"])
    assert result.exit_code != 0
    assert "http://" in result.output or "https://" in result.output


def test_browser_open_with_explicit_sandbox_id():
    """--sandbox-id override skips tmux detection."""
    runner = CliRunner()
    with patch.object(maestro_cli, "_send_to_daemon", return_value={"ok": True}) as send:
        result = runner.invoke(
            maestro_cli.cli,
            ["browser", "open", "https://example.com", "--sandbox-id", "manual-1"],
        )
    assert result.exit_code == 0, result.output
    send.assert_called_once_with({
        "action": "browser_open",
        "url": "https://example.com",
        "sandbox_id": "manual-1",
    })


def test_browser_open_falls_back_to_tmux_detection():
    """No --sandbox-id → CLI calls _current_sandbox_id()."""
    runner = CliRunner()
    with patch.object(maestro_cli, "_current_sandbox_id", return_value="auto-1") as detect, \
         patch.object(maestro_cli, "_send_to_daemon", return_value={"ok": True}) as send:
        result = runner.invoke(maestro_cli.cli, ["browser", "open", "https://example.com"])
    assert result.exit_code == 0, result.output
    detect.assert_called_once()
    assert send.call_args.args[0]["sandbox_id"] == "auto-1"


def test_browser_open_errors_when_no_sandbox_detected():
    """No tmux and no --sandbox-id → clear error, no socket call."""
    runner = CliRunner()
    with patch.object(maestro_cli, "_current_sandbox_id", return_value=None), \
         patch.object(maestro_cli, "_send_to_daemon") as send:
        result = runner.invoke(maestro_cli.cli, ["browser", "open", "https://example.com"])
    assert result.exit_code != 0
    assert "sandbox" in result.output.lower()
    send.assert_not_called()


def test_browser_open_surfaces_daemon_error():
    """If the daemon replies {ok: false, error: ...}, exit code is non-zero."""
    runner = CliRunner()
    with patch.object(maestro_cli, "_current_sandbox_id", return_value="auto-1"), \
         patch.object(maestro_cli, "_send_to_daemon", return_value={"ok": False, "error": "Agent is not connected"}):
        result = runner.invoke(maestro_cli.cli, ["browser", "open", "https://example.com"])
    assert result.exit_code != 0
    assert "not connected" in result.output.lower()


def test_current_sandbox_id_returns_none_outside_tmux(monkeypatch):
    """No TMUX env var → return None without spawning tmux."""
    monkeypatch.delenv("TMUX", raising=False)
    assert maestro_cli._current_sandbox_id() is None


def test_current_sandbox_id_strips_remotedev_prefix(monkeypatch):
    """A 'remotedev-<id>' session resolves to the sandbox UUID."""
    monkeypatch.setenv("TMUX", "/tmp/fake-tmux")

    class _FakeResult:
        returncode = 0
        stdout = "remotedev-abc123\n"

    with patch("remotedev_agent.maestro_cli.subprocess.run", return_value=_FakeResult()):
        assert maestro_cli._current_sandbox_id() == "abc123"


def test_current_sandbox_id_returns_none_for_unmanaged_tmux(monkeypatch):
    """A user's own tmux session (no 'remotedev-' prefix) is ignored."""
    monkeypatch.setenv("TMUX", "/tmp/fake-tmux")

    class _FakeResult:
        returncode = 0
        stdout = "my-personal-session\n"

    with patch("remotedev_agent.maestro_cli.subprocess.run", return_value=_FakeResult()):
        assert maestro_cli._current_sandbox_id() is None


# ── Bridge-driven subcommands ──────────────────────────────────────────


def _fake_reply(payload: dict) -> dict:
    """Build the standard IPC reply for a successful browser_command."""
    return {"ok": True, "command_id": "c-1", "result": payload, "error": None}


def test_browser_navigate_sends_navigate_payload():
    runner = CliRunner()
    with patch.object(
        maestro_cli, "_send_to_daemon",
        return_value=_fake_reply({"current_url": "https://x.test", "title": "X"}),
    ) as send:
        result = runner.invoke(
            maestro_cli.cli,
            ["browser", "navigate", "https://x.test", "--sandbox-id", "s-1"],
        )
    assert result.exit_code == 0, result.output
    send.assert_called_once()
    args = send.call_args.args[0]
    assert args["action"] == "browser_command"
    assert args["sandbox_id"] == "s-1"
    assert args["payload"] == {
        "action": "navigate",
        "url": "https://x.test",
        "new_tab": False,
    }
    assert "https://x.test" in result.output


def test_browser_navigate_rejects_bad_scheme():
    runner = CliRunner()
    with patch.object(maestro_cli, "_send_to_daemon") as send:
        result = runner.invoke(
            maestro_cli.cli,
            ["browser", "navigate", "ftp://x.test", "--sandbox-id", "s-1"],
        )
    assert result.exit_code != 0
    send.assert_not_called()


def test_browser_click_includes_tab_id_when_provided():
    runner = CliRunner()
    with patch.object(
        maestro_cli, "_send_to_daemon",
        return_value=_fake_reply({"current_url": "https://x.test"}),
    ) as send:
        result = runner.invoke(
            maestro_cli.cli,
            ["browser", "click", "button#go", "--sandbox-id", "s-1", "--tab-id", "tab-2"],
        )
    assert result.exit_code == 0, result.output
    args = send.call_args.args[0]
    assert args["payload"] == {
        "action": "click",
        "selector": "button#go",
        "tab_id": "tab-2",
    }


def test_browser_type_passes_text_through():
    runner = CliRunner()
    with patch.object(
        maestro_cli, "_send_to_daemon", return_value=_fake_reply({}),
    ) as send:
        result = runner.invoke(
            maestro_cli.cli,
            ["browser", "type", "input[name=q]", "hello world", "--sandbox-id", "s-1"],
        )
    assert result.exit_code == 0, result.output
    args = send.call_args.args[0]
    assert args["payload"] == {
        "action": "type",
        "selector": "input[name=q]",
        "text": "hello world",
    }


def test_browser_screenshot_writes_file(tmp_path):
    import base64

    png_bytes = b"\x89PNG\r\n\x1a\n-fake"
    b64 = base64.b64encode(png_bytes).decode("ascii")
    out_path = tmp_path / "shot.png"
    runner = CliRunner()
    with patch.object(
        maestro_cli, "_send_to_daemon",
        return_value=_fake_reply({"screenshot_b64": b64}),
    ):
        result = runner.invoke(
            maestro_cli.cli,
            [
                "browser", "screenshot",
                "--full-page",
                "--output", str(out_path),
                "--sandbox-id", "s-1",
            ],
        )
    assert result.exit_code == 0, result.output
    assert out_path.read_bytes() == png_bytes


def test_browser_console_logs_renders_entries():
    runner = CliRunner()
    logs = [
        {"ts": 1.0, "level": "log", "text": "hello"},
        {"ts": 2.0, "level": "error", "text": "boom"},
    ]
    with patch.object(
        maestro_cli, "_send_to_daemon",
        return_value=_fake_reply({"console_logs": logs}),
    ):
        result = runner.invoke(
            maestro_cli.cli,
            ["browser", "console-logs", "--sandbox-id", "s-1"],
        )
    assert result.exit_code == 0, result.output
    assert "hello" in result.output
    assert "boom" in result.output
    assert "error" in result.output


def test_browser_list_tabs_renders_entries():
    runner = CliRunner()
    tabs = [
        {"tab_id": "t-1", "url": "https://a.test", "title": "A"},
        {"tab_id": "t-2", "url": "https://b.test", "title": "B"},
    ]
    with patch.object(
        maestro_cli, "_send_to_daemon",
        return_value=_fake_reply({"console_logs": tabs}),
    ):
        result = runner.invoke(
            maestro_cli.cli, ["browser", "list-tabs", "--sandbox-id", "s-1"],
        )
    assert result.exit_code == 0, result.output
    assert "t-1" in result.output and "t-2" in result.output
    assert "a.test" in result.output and "b.test" in result.output


def test_browser_command_surfaces_bridge_error():
    """Bridge returned ok=false → non-zero exit + verbatim error."""
    runner = CliRunner()
    with patch.object(
        maestro_cli, "_send_to_daemon",
        return_value={
            "ok": False,
            "error": "Bridge did not reply within 30s",
            "command_id": "c-1",
        },
    ):
        result = runner.invoke(
            maestro_cli.cli,
            ["browser", "navigate", "https://x.test", "--sandbox-id", "s-1"],
        )
    assert result.exit_code != 0
    assert "did not reply" in result.output.lower()
