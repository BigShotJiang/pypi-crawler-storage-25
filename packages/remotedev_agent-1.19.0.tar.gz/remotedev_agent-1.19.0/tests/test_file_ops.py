"""Tests for the W3 file panel handlers and the file_ops module.

Two surfaces matter:
1. The pure file_ops helpers (sort order, caps, binary detection, traversal)
2. The daemon dispatch + response shape (what the browser actually sees)
"""
from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from remotedev_agent.file_ops import (
    BINARY_PROBE_BYTES,
    MAX_LIST_ENTRIES,
    MAX_READ_BYTES,
    list_directory,
    read_file,
)


# ----- file_ops pure helpers -----

def test_list_directory_sorts_dirs_first(tmp_path):
    (tmp_path / "z_file.txt").write_text("x")
    (tmp_path / "a_file.txt").write_text("x")
    (tmp_path / "m_dir").mkdir()
    (tmp_path / "B_dir").mkdir()

    out = list_directory(tmp_path, "")
    assert [e["name"] for e in out["entries"]] == ["B_dir", "m_dir", "a_file.txt", "z_file.txt"]
    # Dirs have no size; files do.
    kinds = {e["name"]: e["kind"] for e in out["entries"]}
    assert kinds["B_dir"] == "dir" and "size" not in next(e for e in out["entries"] if e["name"] == "B_dir")
    assert kinds["a_file.txt"] == "file" and "size" in next(e for e in out["entries"] if e["name"] == "a_file.txt")


def test_list_directory_traversal_rejected(tmp_path):
    # Even though /etc/passwd exists on disk, list_directory called with
    # tmp_path as root must refuse the traversal.
    out = list_directory(tmp_path, "../../../etc")
    assert out["entries"] == []
    assert "outside" in out["error"].lower()


def test_list_directory_absolute_path_rejected(tmp_path):
    out = list_directory(tmp_path, "/etc")
    assert out["entries"] == []
    assert "error" in out


def test_list_directory_truncated_when_over_cap(tmp_path):
    # Create MAX_LIST_ENTRIES+5 files. The response must cap at the limit
    # and flag truncation so the UI can warn the user.
    for i in range(MAX_LIST_ENTRIES + 5):
        (tmp_path / f"f{i:04d}.txt").write_text("x")
    out = list_directory(tmp_path, "")
    assert len(out["entries"]) == MAX_LIST_ENTRIES
    assert out["truncated"] is True


def test_list_directory_handles_subfolder(tmp_path):
    sub = tmp_path / "src" / "components"
    sub.mkdir(parents=True)
    (sub / "Button.tsx").write_text("x")
    out = list_directory(tmp_path, "src/components")
    assert [e["name"] for e in out["entries"]] == ["Button.tsx"]
    assert out["relative_path"] == "src/components"


def test_list_directory_missing_path(tmp_path):
    out = list_directory(tmp_path, "nope/nada")
    assert out["entries"] == []
    assert "exist" in out["error"].lower()


def test_list_directory_file_instead_of_dir(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("x")
    out = list_directory(tmp_path, "a.txt")
    assert "directory" in out["error"].lower()


def test_read_file_text(tmp_path):
    f = tmp_path / "hello.txt"
    f.write_text("hello world\n")
    out = read_file(tmp_path, "hello.txt")
    assert out["content"] == "hello world\n"
    assert out["size"] == len("hello world\n")
    assert "binary" not in out
    assert "truncated" not in out


def test_read_file_binary_detection(tmp_path):
    # Null byte in the first probe → binary. No content returned.
    f = tmp_path / "bin.dat"
    f.write_bytes(b"abc\x00def" + b"x" * 100)
    out = read_file(tmp_path, "bin.dat")
    assert out["binary"] is True
    assert "content" not in out


def test_read_file_truncation_for_large_files(tmp_path):
    # File larger than MAX_READ_BYTES should be truncated to the cap and
    # flagged. Use byte-pattern that never contains a null so it stays text.
    f = tmp_path / "big.txt"
    f.write_bytes(b"a" * (MAX_READ_BYTES + 1000))
    out = read_file(tmp_path, "big.txt")
    assert out["truncated"] is True
    assert len(out["content"]) == MAX_READ_BYTES
    assert out["size"] == MAX_READ_BYTES + 1000


def test_read_file_traversal_rejected_with_no_leak(tmp_path):
    out = read_file(tmp_path, "../../etc/passwd")
    assert "outside" in out["error"].lower()
    # Don't render content, size, or any other leakable field. The browser-
    # provided relative_path is echoed back (it's how the frontend correlates
    # the response to the request) — that's safe because the browser typed it.
    assert "content" not in out
    assert out["size"] == 0
    assert "binary" not in out


def test_read_file_directory_returns_error(tmp_path):
    (tmp_path / "sub").mkdir()
    out = read_file(tmp_path, "sub")
    assert "directory" in out["error"].lower()


def test_read_file_invalid_utf8_decodes_with_replacement(tmp_path):
    # No null bytes in the first probe → treated as text. Invalid UTF-8
    # sequences should decode with the replacement character so the viewer
    # still renders something useful.
    f = tmp_path / "mixed.txt"
    f.write_bytes(b"valid\nthen \xff\xfe invalid")
    out = read_file(tmp_path, "mixed.txt")
    assert "content" in out
    assert "valid" in out["content"]


def test_binary_probe_uses_first_chunk(tmp_path):
    # A null byte AFTER the probe window should NOT trip binary detection
    # (matches git's heuristic). Document the boundary explicitly.
    f = tmp_path / "late_null.txt"
    f.write_bytes(b"a" * BINARY_PROBE_BYTES + b"\x00more")
    out = read_file(tmp_path, "late_null.txt")
    # Treated as text — content contains the late null character.
    assert "content" in out
    assert "binary" not in out


# ----- daemon dispatch + response shape -----

async def test_dispatch_routes_file_list_request(daemon):
    daemon.handle_file_list_request = AsyncMock()
    await daemon.handle({
        "type": "FILE_LIST_REQUEST",
        "sandbox_id": "sbx-1",
        "payload": {"relative_path": ""},
    })
    daemon.handle_file_list_request.assert_awaited_once_with(
        "sbx-1", {"relative_path": ""}
    )


async def test_dispatch_routes_file_read_request(daemon):
    daemon.handle_file_read_request = AsyncMock()
    await daemon.handle({
        "type": "FILE_READ_REQUEST",
        "sandbox_id": "sbx-1",
        "payload": {"relative_path": "a.txt"},
    })
    daemon.handle_file_read_request.assert_awaited_once_with(
        "sbx-1", {"relative_path": "a.txt"}
    )


async def test_file_list_request_responds_with_entries(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "README.md").write_text("hi")
    (sandbox / "src").mkdir()

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_list_request(
        "sbx-1", {"folder_path": str(sandbox), "relative_path": ""}
    )

    assert len(sent) == 1
    assert sent[0]["type"] == "FILE_LIST_RESPONSE"
    assert sent[0]["sandbox_id"] == "sbx-1"
    payload = sent[0]["payload"]
    assert payload["relative_path"] == ""
    names = [e["name"] for e in payload["entries"]]
    assert "src" in names and "README.md" in names
    # v1.7.0: the resolved absolute root is surfaced so the frontend can
    # show it in the Explorer header. Should match the resolved sandbox path.
    assert payload["root_path"] == str(sandbox.resolve())


async def test_file_list_request_no_folder_path_falls_back_to_pty_session(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "a.txt").write_text("x")

    fake_session = MagicMock()
    fake_session.cwd = str(sandbox)
    # v1.6.0: model live_cwd() returning None so the resolver falls back to
    # session.cwd (the tmux-unreachable case in production).
    fake_session.live_cwd = MagicMock(return_value=None)
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_list_request("sbx-1", {"relative_path": ""})

    payload = sent[0]["payload"]
    assert [e["name"] for e in payload["entries"]] == ["a.txt"]


async def test_file_list_request_no_folder_no_session_returns_unavailable(daemon):
    daemon.pty_manager.get_session = MagicMock(return_value=None)
    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_list_request("sbx-1", {"relative_path": ""})

    payload = sent[0]["payload"]
    assert payload["entries"] == []
    assert "unavailable" in payload["error"].lower()


async def test_file_read_request_responds_with_content(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    (sandbox / "hello.txt").write_text("hello\n")

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_read_request(
        "sbx-1", {"folder_path": str(sandbox), "relative_path": "hello.txt"}
    )

    assert len(sent) == 1
    payload = sent[0]["payload"]
    assert payload["relative_path"] == "hello.txt"
    assert payload["content"] == "hello\n"


async def test_file_read_request_missing_relative_path_returns_error(daemon, tmp_path):
    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_read_request("sbx-1", {"folder_path": str(tmp_path)})

    payload = sent[0]["payload"]
    assert "error" in payload
    assert "relative_path" in payload["error"].lower()


async def test_file_read_request_traversal_rejected(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    # Put a sibling file we should NOT be able to read via ../
    outside = tmp_path / "secret.txt"
    outside.write_text("nope")

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_read_request(
        "sbx-1",
        {"folder_path": str(sandbox), "relative_path": "../secret.txt"},
    )

    payload = sent[0]["payload"]
    assert "error" in payload
    assert "outside" in payload["error"].lower()
    # And the secret content didn't leak.
    assert "nope" not in json.dumps(sent[0])
