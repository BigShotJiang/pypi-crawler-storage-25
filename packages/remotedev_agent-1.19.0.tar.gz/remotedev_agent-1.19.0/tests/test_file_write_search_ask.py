"""Tests for the v1.19.0 agent protocol additions.

Covers:
- WP-3: ``FILE_LIST_REQUEST { root_override }`` honours the override and
  rejects path-traversal segments.
- WP-5: ``FILE_WRITE_REQUEST`` / ``FILE_WRITE_RESPONSE`` round-trip,
  binary/UTF-8 corruption rejection, 1MB cap, atomic semantics.
- WP-5c: ``FILE_SEARCH_REQUEST`` / ``FILE_SEARCH_RESPONSE`` parses
  ripgrep / grep stdout, caps at 500, surfaces "tool unavailable".
- W8: ``AGENT_ASK`` / ``AGENT_RESPONSE`` runs ``claude -p`` style
  invocations, caps at 100KB, returns clean errors for unsupported
  agents and missing binaries.

The handlers themselves are thin async wrappers — most of the heavy
lifting (validation, caps, decoding) lives in the pure helpers so the
tests stay fast and free of WebSocket plumbing.
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from remotedev_agent.agent_ops import (
    ASK_TIMEOUT_SECONDS,
    MAX_RESPONSE_BYTES,
    run_agent_ask,
    supported_agents,
)
from remotedev_agent.file_ops import (
    MAX_SEARCH_MATCHES,
    MAX_WRITE_BYTES,
    search_files,
    write_file,
)


# =====================================================================
# WP-3: root_override + traversal rejection
# =====================================================================


def test_resolve_sandbox_root_honours_root_override(daemon, tmp_path):
    """When the browser passes ``root_override``, it wins over folder_path
    and the PTY session's cwd. This is the WP-3 contract that pins the
    Files panel to the project root even if the shell ``cd``'d elsewhere.
    """
    override = tmp_path / "project-root"
    override.mkdir()
    other = tmp_path / "elsewhere"
    other.mkdir()

    fake_session = MagicMock()
    fake_session.cwd = str(other)
    fake_session.live_cwd = MagicMock(return_value=str(other))
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    resolved = daemon._resolve_sandbox_root("sbx-1", {"root_override": str(override)})
    assert resolved == override.resolve()


def test_resolve_sandbox_root_rejects_traversal_in_override(daemon, tmp_path):
    """``..`` in root_override is refused — browser has no legit reason
    for it. Resolver returns None and the handler renders an "unavailable"
    error instead of stepping outside.
    """
    resolved = daemon._resolve_sandbox_root(
        "sbx-1", {"root_override": str(tmp_path / ".." / "outside")}
    )
    assert resolved is None


def test_resolve_sandbox_root_blank_override_falls_through(daemon, tmp_path):
    """An empty / whitespace root_override is ignored so old browsers
    that send the field with no value still get the legacy resolution.
    """
    fake_session = MagicMock()
    fake_session.cwd = str(tmp_path)
    fake_session.live_cwd = MagicMock(return_value=None)
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    resolved = daemon._resolve_sandbox_root("sbx-1", {"root_override": "   "})
    assert resolved == tmp_path.resolve()


async def test_file_list_request_uses_root_override(daemon, tmp_path):
    pinned = tmp_path / "pinned"
    pinned.mkdir()
    (pinned / "main.py").write_text("x")

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))
    daemon.pty_manager.get_session = MagicMock(return_value=None)

    await daemon.handle_file_list_request(
        "sbx-1", {"root_override": str(pinned), "relative_path": ""}
    )
    payload = sent[0]["payload"]
    assert [e["name"] for e in payload["entries"]] == ["main.py"]
    assert payload["root_path"] == str(pinned.resolve())


# =====================================================================
# WP-5: write_file pure helper
# =====================================================================


def test_write_file_round_trip(tmp_path):
    out = write_file(tmp_path, "hello.txt", "hello world\n")
    assert out["ok"] is True
    assert out["size"] == len("hello world\n".encode())
    assert (tmp_path / "hello.txt").read_text() == "hello world\n"


def test_write_file_overwrites_existing(tmp_path):
    (tmp_path / "f.txt").write_text("old")
    out = write_file(tmp_path, "f.txt", "new")
    assert out["ok"] is True
    assert (tmp_path / "f.txt").read_text() == "new"


def test_write_file_rejects_traversal(tmp_path):
    out = write_file(tmp_path, "../escape.txt", "x")
    assert out["ok"] is False
    assert "outside" in out["error"].lower()
    assert not (tmp_path.parent / "escape.txt").exists()


def test_write_file_rejects_binary_content(tmp_path):
    # Null byte in content should never reach disk.
    out = write_file(tmp_path, "bin.txt", "before\x00after")
    assert out["ok"] is False
    assert "binary" in out["error"].lower()
    assert not (tmp_path / "bin.txt").exists()


def test_write_file_rejects_over_cap(tmp_path):
    huge = "a" * (MAX_WRITE_BYTES + 1)
    out = write_file(tmp_path, "huge.txt", huge)
    assert out["ok"] is False
    assert "cap" in out["error"].lower() or "exceed" in out["error"].lower()


def test_write_file_accepts_at_cap(tmp_path):
    payload = "a" * MAX_WRITE_BYTES
    out = write_file(tmp_path, "ok.txt", payload)
    assert out["ok"] is True
    assert out["size"] == MAX_WRITE_BYTES


def test_write_file_requires_relative_path(tmp_path):
    out = write_file(tmp_path, "", "x")
    assert out["ok"] is False
    assert "missing" in out["error"].lower()


def test_write_file_refuses_to_overwrite_directory(tmp_path):
    (tmp_path / "adir").mkdir()
    out = write_file(tmp_path, "adir", "x")
    assert out["ok"] is False
    # Either "regular file" or similar — just must refuse.
    assert "regular" in out["error"].lower() or "directory" in out["error"].lower()


def test_write_file_missing_parent_fails_cleanly(tmp_path):
    out = write_file(tmp_path, "noexist/a.txt", "x")
    assert out["ok"] is False
    assert "parent" in out["error"].lower()


def test_write_file_invalid_utf8_via_surrogate(tmp_path):
    # A lone surrogate can't be UTF-8 encoded — reject rather than mangle.
    out = write_file(tmp_path, "bad.txt", "\ud800")
    assert out["ok"] is False
    assert "utf-8" in out["error"].lower()


# =====================================================================
# WP-5: dispatch + response shape for FILE_WRITE_REQUEST
# =====================================================================


async def test_dispatch_routes_file_write_request(daemon):
    daemon.handle_file_write_request = AsyncMock()
    await daemon.handle({
        "type": "FILE_WRITE_REQUEST",
        "sandbox_id": "sbx-1",
        "payload": {"relative_path": "a.txt", "content": "hi"},
    })
    daemon.handle_file_write_request.assert_awaited_once()


async def test_file_write_request_writes_and_replies_ok(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_write_request(
        "sbx-1",
        {"folder_path": str(sandbox), "relative_path": "a.txt", "content": "hello"},
    )
    assert sent[0]["type"] == "FILE_WRITE_RESPONSE"
    payload = sent[0]["payload"]
    assert payload["ok"] is True
    assert (sandbox / "a.txt").read_text() == "hello"


async def test_file_write_request_missing_relative_path(daemon, tmp_path):
    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_write_request(
        "sbx-1", {"folder_path": str(tmp_path), "content": "x"}
    )
    payload = sent[0]["payload"]
    assert payload["ok"] is False
    assert "relative_path" in payload["error"].lower()


async def test_file_write_request_root_unavailable(daemon):
    daemon.pty_manager.get_session = MagicMock(return_value=None)
    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_write_request(
        "sbx-1", {"relative_path": "a.txt", "content": "x"}
    )
    payload = sent[0]["payload"]
    assert payload["ok"] is False
    assert "unavailable" in payload["error"].lower()


# =====================================================================
# WP-5c: search_files pure helper
# =====================================================================


def _fake_completed(stdout: str = "", stderr: str = "", returncode: int = 0):
    """Build a CompletedProcess-shaped object for subprocess.run patches."""
    cp = MagicMock()
    cp.stdout = stdout
    cp.stderr = stderr
    cp.returncode = returncode
    return cp


def test_search_files_parses_ripgrep_output(tmp_path):
    """rg-style ``path:lineno:snippet`` lines parse into the expected
    match dicts and paths are made relative to the root.
    """
    (tmp_path / "a.py").write_text("x")
    fake_stdout = f"{tmp_path}/a.py:42:  useEffect(() => {{}}, [])\n"

    with patch("remotedev_agent.file_ops.shutil.which", return_value="/usr/bin/rg"), \
         patch("remotedev_agent.file_ops.subprocess.run", return_value=_fake_completed(stdout=fake_stdout)):
        out = search_files(tmp_path, "useEffect")

    assert out["query"] == "useEffect"
    assert len(out["matches"]) == 1
    assert out["matches"][0]["path"] == "a.py"
    assert out["matches"][0]["line"] == 42
    assert "useEffect" in out["matches"][0]["snippet"]


def test_search_files_falls_back_to_grep(tmp_path):
    """When ripgrep isn't on PATH, the helper builds a ``grep -rIn`` cmd
    and parses the same ``path:lineno:snippet`` shape.
    """
    (tmp_path / "b.py").write_text("x")
    fake_stdout = f"{tmp_path}/b.py:7:  foo bar\n"

    captured: dict = {}

    def fake_run(cmd, *_, **__):
        captured["cmd"] = cmd
        return _fake_completed(stdout=fake_stdout)

    with patch("remotedev_agent.file_ops.shutil.which", return_value=None), \
         patch("remotedev_agent.file_ops.subprocess.run", side_effect=fake_run):
        out = search_files(tmp_path, "foo")

    assert captured["cmd"][0] == "grep"
    assert "-rInF" in captured["cmd"]
    assert len(out["matches"]) == 1
    assert out["matches"][0]["path"] == "b.py"


def test_search_files_caps_at_max(tmp_path):
    """More results than the cap → truncated=True and matches list is
    exactly MAX_SEARCH_MATCHES long.
    """
    # Build stdout with 2x the cap so we have room to truncate.
    over = MAX_SEARCH_MATCHES + 50
    rows = "\n".join(f"{tmp_path}/f{i:04d}.py:{i}:hit" for i in range(over))

    with patch("remotedev_agent.file_ops.shutil.which", return_value="/usr/bin/rg"), \
         patch("remotedev_agent.file_ops.subprocess.run", return_value=_fake_completed(stdout=rows)):
        out = search_files(tmp_path, "hit")

    assert len(out["matches"]) == MAX_SEARCH_MATCHES
    assert out["truncated"] is True


def test_search_files_missing_query(tmp_path):
    out = search_files(tmp_path, "")
    assert out["matches"] == []
    assert "missing" in out["error"].lower()


def test_search_files_handles_timeout(tmp_path):
    with patch("remotedev_agent.file_ops.shutil.which", return_value="/usr/bin/rg"), \
         patch("remotedev_agent.file_ops.subprocess.run", side_effect=subprocess.TimeoutExpired(cmd="rg", timeout=15)):
        out = search_files(tmp_path, "anything")
    assert out["matches"] == []
    assert "timed out" in out["error"].lower()


# =====================================================================
# WP-5c: dispatch + response shape for FILE_SEARCH_REQUEST
# =====================================================================


async def test_dispatch_routes_file_search_request(daemon):
    daemon.handle_file_search_request = AsyncMock()
    await daemon.handle({
        "type": "FILE_SEARCH_REQUEST",
        "sandbox_id": "sbx-1",
        "payload": {"query": "useEffect"},
    })
    daemon.handle_file_search_request.assert_awaited_once()


async def test_file_search_request_responds_with_matches(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    fake_stdout = f"{sandbox}/a.py:1:hit\n"
    with patch("remotedev_agent.file_ops.shutil.which", return_value="/usr/bin/rg"), \
         patch("remotedev_agent.file_ops.subprocess.run", return_value=_fake_completed(stdout=fake_stdout)):
        await daemon.handle_file_search_request(
            "sbx-1", {"folder_path": str(sandbox), "query": "hit"}
        )

    assert sent[0]["type"] == "FILE_SEARCH_RESPONSE"
    payload = sent[0]["payload"]
    assert payload["query"] == "hit"
    assert len(payload["matches"]) == 1


async def test_file_search_request_root_unavailable(daemon):
    daemon.pty_manager.get_session = MagicMock(return_value=None)
    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_file_search_request("sbx-1", {"query": "x"})
    payload = sent[0]["payload"]
    assert "unavailable" in payload["error"].lower()


# =====================================================================
# W8: run_agent_ask helper
# =====================================================================


def test_supported_agents_includes_claude():
    """``claude -p`` is the agent W8 confirms supports one-shot mode."""
    assert "claude" in supported_agents()


def test_run_agent_ask_returns_stdout():
    with patch("remotedev_agent.agent_ops.shutil.which", return_value="/usr/bin/claude"), \
         patch("remotedev_agent.agent_ops.subprocess.run", return_value=_fake_completed(stdout="answer\n")):
        out = run_agent_ask("hi", "claude")
    assert out["content"] == "answer\n"
    assert "error" not in out


def test_run_agent_ask_truncates_oversize_response():
    huge = "a" * (MAX_RESPONSE_BYTES + 500)
    with patch("remotedev_agent.agent_ops.shutil.which", return_value="/usr/bin/claude"), \
         patch("remotedev_agent.agent_ops.subprocess.run", return_value=_fake_completed(stdout=huge)):
        out = run_agent_ask("hi", "claude")
    assert out["truncated"] is True
    assert len(out["content"].encode("utf-8")) <= MAX_RESPONSE_BYTES


def test_run_agent_ask_unsupported_agent_returns_clean_error():
    """``codex`` and ``aider`` aren't currently wired for one-shot mode —
    return a clear error rather than guessing at their argv.
    """
    out = run_agent_ask("hi", "codex")
    assert out["content"] == ""
    assert "one-shot" in out["error"].lower() or "support" in out["error"].lower()


def test_run_agent_ask_missing_binary():
    with patch("remotedev_agent.agent_ops.shutil.which", return_value=None):
        out = run_agent_ask("hi", "claude")
    assert "not installed" in out["error"].lower()


def test_run_agent_ask_missing_prompt():
    out = run_agent_ask("", "claude")
    assert out["content"] == ""
    assert "missing" in out["error"].lower()


def test_run_agent_ask_timeout():
    with patch("remotedev_agent.agent_ops.shutil.which", return_value="/usr/bin/claude"), \
         patch(
             "remotedev_agent.agent_ops.subprocess.run",
             side_effect=subprocess.TimeoutExpired(cmd="claude", timeout=ASK_TIMEOUT_SECONDS),
         ):
        out = run_agent_ask("hi", "claude")
    assert "timed out" in out["error"].lower()


def test_run_agent_ask_nonzero_exit_surfaces_stderr():
    with patch("remotedev_agent.agent_ops.shutil.which", return_value="/usr/bin/claude"), \
         patch(
             "remotedev_agent.agent_ops.subprocess.run",
             return_value=_fake_completed(stdout="", stderr="boom\nmore", returncode=2),
         ):
        out = run_agent_ask("hi", "claude")
    assert "boom" in out["error"]


# =====================================================================
# W8: dispatch + response shape for AGENT_ASK
# =====================================================================


async def test_dispatch_routes_agent_ask(daemon):
    daemon.handle_agent_ask = AsyncMock()
    await daemon.handle({
        "type": "AGENT_ASK",
        "sandbox_id": "sbx-1",
        "payload": {"prompt": "hello", "conversation_id": "c1", "agent": "claude"},
    })
    daemon.handle_agent_ask.assert_awaited_once()


async def test_agent_ask_round_trips_conversation_id(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    with patch("remotedev_agent.agent_ops.shutil.which", return_value="/usr/bin/claude"), \
         patch("remotedev_agent.agent_ops.subprocess.run", return_value=_fake_completed(stdout="ok")):
        await daemon.handle_agent_ask(
            "sbx-1",
            {
                "folder_path": str(sandbox),
                "prompt": "hi",
                "conversation_id": "conv-42",
                "agent": "claude",
            },
        )

    assert sent[0]["type"] == "AGENT_RESPONSE"
    payload = sent[0]["payload"]
    assert payload["conversation_id"] == "conv-42"
    assert payload["content"] == "ok"


async def test_agent_ask_unsupported_agent_returns_error_response(daemon, tmp_path):
    sandbox = tmp_path / "sandbox"
    sandbox.mkdir()
    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))

    await daemon.handle_agent_ask(
        "sbx-1",
        {"folder_path": str(sandbox), "prompt": "hi", "conversation_id": "c", "agent": "aider"},
    )
    payload = sent[0]["payload"]
    assert payload["conversation_id"] == "c"
    assert "error" in payload


# =====================================================================
# Unknown message types still no-op (back-compat for old browsers)
# =====================================================================


async def test_unknown_message_type_silently_ignored(daemon):
    """Per the protocol contract, the agent must silently ignore message
    types it doesn't understand — this keeps newer frontends safe to
    deploy against older agents (and vice versa for new agent message
    types received by the existing dispatch).
    """
    daemon.send = AsyncMock()
    # Must not raise and must not send anything back.
    await daemon.handle({"type": "TOTALLY_NEW_FUTURE_TYPE", "sandbox_id": "sbx-1", "payload": {}})
    daemon.send.assert_not_called()
