"""Reviewer-flagged BLOCKER: scrollback persistence across browser refresh.

When a browser refreshes, it sends a fresh OPEN_TERMINAL. The agent must
respond by capturing the existing tmux pane scrollback (via capture-pane)
and forwarding the full content as TERMINAL_OUTPUT so the user does not
lose history. These tests pin that contract.

This is not just an academic concern: today's PTY-read-loop bug (52049d4)
manifested as "type something, refresh, see the typed text appear" — the
exact path being tested here is what made the bug appear refreshable.
"""
from __future__ import annotations

import time
from unittest.mock import AsyncMock, MagicMock, patch

import pytest


@pytest.fixture
def mock_subprocess_capture():
    """Mock subprocess.run so capture-pane returns a controllable scrollback."""
    captured = {"output": "line1\nline2\nline3\nline4\nline5\n"}

    def fake_run(cmd, *args, **kwargs):
        result = MagicMock()
        result.returncode = 0
        if "capture-pane" in cmd:
            result.stdout = captured["output"]
        elif "has-session" in cmd:
            result.returncode = 0  # session exists
        else:
            result.stdout = ""
        return result

    with patch("remotedev_agent.pty_manager.subprocess.run", side_effect=fake_run), \
         patch("remotedev_agent.daemon.subprocess.run", side_effect=fake_run):
        yield captured


@pytest.mark.asyncio
async def test_handle_open_terminal_replays_tmux_scrollback_for_existing_session(
    daemon, mock_subprocess_capture, tmp_path
):
    """When the tmux session already exists, OPEN_TERMINAL must replay the
    full capture-pane scrollback as TERMINAL_OUTPUT — that's what makes
    'type → refresh → see history' work for the user."""
    sent_messages = []

    async def fake_send(msg):
        sent_messages.append(msg)

    daemon.send = fake_send

    # Pre-create the session in pty_manager so the existing-session branch
    # is taken. Use a path INSIDE sandboxes_root so _validate_path passes.
    from remotedev_agent.pty_manager import PTYSession

    sandbox_id = "sbx-existing"
    sandbox_path = tmp_path / "sbx-existing"
    sandbox_path.mkdir()
    session = PTYSession(sandbox_id, str(sandbox_path), AsyncMock())
    proc = MagicMock()
    proc.isalive.return_value = True
    session.process = proc

    # Make the read task look healthy so we hit the "just update callback" path
    fake_task = MagicMock()
    fake_task.done.return_value = False
    session._read_task = fake_task

    daemon.pty_manager.sessions[sandbox_id] = session

    await daemon.handle_open_terminal(
        sandbox_id,
        {"folder_path": str(sandbox_path), "rows": 24, "cols": 80},
    )

    # The captured scrollback must be forwarded as TERMINAL_OUTPUT
    terminal_outputs = [m for m in sent_messages if m.get("type") == "TERMINAL_OUTPUT"]
    assert len(terminal_outputs) >= 1, f"expected TERMINAL_OUTPUT, got {sent_messages}"

    full_output = "".join(m["payload"]["data"] for m in terminal_outputs)
    for expected_line in ("line1", "line2", "line3", "line4", "line5"):
        assert expected_line in full_output, f"missing {expected_line} in scrollback replay"


@pytest.mark.asyncio
async def test_handle_open_terminal_skips_replay_when_session_was_dead_and_recreated(
    daemon, mock_subprocess_capture, tmp_path
):
    """If we have an in-memory session BUT both process and read_task died,
    the recovery path (reattach) should still send the scrollback so the
    user doesn't lose history.

    This guards the today-fixed bug variant: dead process + dead task +
    existing tmux session → reattach AND replay."""
    sent_messages = []

    async def fake_send(msg):
        sent_messages.append(msg)

    daemon.send = fake_send

    from remotedev_agent.pty_manager import PTYSession

    sandbox_id = "sbx-dead"
    sandbox_path = tmp_path / "sbx-dead"
    sandbox_path.mkdir()
    session = PTYSession(sandbox_id, str(sandbox_path), AsyncMock())
    # Process is dead
    proc = MagicMock()
    proc.isalive.return_value = False
    session.process = proc
    # Read task is also dead
    fake_task = MagicMock()
    fake_task.done.return_value = True
    session._read_task = fake_task

    daemon.pty_manager.sessions[sandbox_id] = session

    # Stub reattach so we don't actually spawn ptyprocess
    session.reattach = MagicMock()

    await daemon.handle_open_terminal(
        sandbox_id,
        {"folder_path": str(sandbox_path), "rows": 24, "cols": 80},
    )

    # reattach was called (recovery)
    assert session.reattach.called, "reattach should have been called for dead session"
    # AND the scrollback was still replayed
    terminal_outputs = [m for m in sent_messages if m.get("type") == "TERMINAL_OUTPUT"]
    assert len(terminal_outputs) >= 1
    full_output = "".join(m["payload"]["data"] for m in terminal_outputs)
    assert "line5" in full_output, "scrollback must be replayed even after recovery reattach"


@pytest.mark.asyncio
async def test_capture_tmux_scrollback_strips_da_response_sequences(mock_subprocess_capture):
    """capture-pane sometimes leaks Device Attribute response sequences as
    raw text (e.g. \\x1b[?1;2c). The helper should strip them so they
    don't render as garbage in the browser terminal.
    """
    from remotedev_agent.pty_manager import _capture_tmux_scrollback

    mock_subprocess_capture["output"] = "hello\x1b[?1;2cworld\n"
    out = _capture_tmux_scrollback("test-session")
    assert "hello" in out
    assert "world" in out
    assert "\x1b[?1;2c" not in out, "DA response sequence should have been stripped"


@pytest.mark.asyncio
async def test_capture_tmux_scrollback_strips_trailing_blank_filler_lines(mock_subprocess_capture):
    """tmux capture-pane sometimes returns trailing blank filler lines from
    a size mismatch between the captured pane and the resized window. Those
    blank lines push the prompt off-screen on the user's side."""
    from remotedev_agent.pty_manager import _capture_tmux_scrollback

    mock_subprocess_capture["output"] = "real content line 1\nreal content line 2\n\n\n   \n\n"
    out = _capture_tmux_scrollback("test-session")
    # Should preserve the real content but trim trailing blanks
    assert out.startswith("real content line 1")
    assert "real content line 2" in out
    # No more than one trailing newline expected
    assert not out.endswith("\n\n\n")
