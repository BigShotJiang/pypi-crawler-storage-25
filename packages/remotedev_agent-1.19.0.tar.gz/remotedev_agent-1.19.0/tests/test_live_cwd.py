"""Tests for the W3-D live-cwd-tracking feature.

Two surfaces matter:
1. ``PTYSession.live_cwd()`` — does it call tmux correctly and degrade
   gracefully when tmux is unavailable / silent / errors?
2. ``AgentDaemon._resolve_sandbox_root`` — does it prefer the live cwd
   over the session's recorded initial folder, and fall back when tmux
   says nothing? And does it relax the sandboxes_root constraint so
   read-only file/git ops can follow the user wherever they ``cd``?
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from remotedev_agent.pty_manager import PTYSession


# ----- PTYSession.live_cwd -----

def _make_session(sandbox_id: str = "sbx-1", cwd: str = "/tmp") -> PTYSession:
    async def _noop_on_output(_sid: str, _data: str) -> None: ...
    return PTYSession(sandbox_id, cwd, _noop_on_output)


def test_live_cwd_returns_tmux_pane_path():
    """Happy path: tmux replies with a path, we return it stripped."""
    session = _make_session()
    fake_result = subprocess.CompletedProcess(
        args=[], returncode=0, stdout="/Users/shaun/code/some-project\n", stderr=""
    )
    with patch("remotedev_agent.pty_manager.subprocess.run", return_value=fake_result) as mock_run:
        assert session.live_cwd() == "/Users/shaun/code/some-project"
        # Confirm we query the right tmux variable on the right session.
        args = mock_run.call_args.args[0]
        assert "display-message" in args
        assert "#{pane_current_path}" in args
        assert session.tmux_session_name in args


def test_live_cwd_returns_none_on_tmux_failure():
    """tmux exits non-zero (session missing, etc.) — we return None."""
    session = _make_session()
    fake_result = subprocess.CompletedProcess(args=[], returncode=1, stdout="", stderr="no such session")
    with patch("remotedev_agent.pty_manager.subprocess.run", return_value=fake_result):
        assert session.live_cwd() is None


def test_live_cwd_returns_none_on_empty_stdout():
    """tmux replies cleanly but with no path — don't return an empty string."""
    session = _make_session()
    fake_result = subprocess.CompletedProcess(args=[], returncode=0, stdout="\n", stderr="")
    with patch("remotedev_agent.pty_manager.subprocess.run", return_value=fake_result):
        assert session.live_cwd() is None


def test_live_cwd_returns_none_on_subprocess_error():
    """tmux binary missing / OS error — never raise, just return None."""
    session = _make_session()
    with patch(
        "remotedev_agent.pty_manager.subprocess.run",
        side_effect=FileNotFoundError("tmux"),
    ):
        assert session.live_cwd() is None


def test_live_cwd_returns_none_on_timeout():
    """tmux is stuck — never block the WS loop forever."""
    session = _make_session()
    with patch(
        "remotedev_agent.pty_manager.subprocess.run",
        side_effect=subprocess.TimeoutExpired(cmd=["tmux"], timeout=2),
    ):
        assert session.live_cwd() is None


# ----- daemon._resolve_sandbox_root -----

def test_resolver_prefers_live_cwd_over_session_cwd(daemon, tmp_path):
    """The headline behaviour: if the user ``cd``s into a different
    directory, the resolver uses that directory — not the original folder
    we created the session with."""
    initial = tmp_path / "initial"
    initial.mkdir()
    current = tmp_path / "different-project"
    current.mkdir()

    fake_session = MagicMock()
    fake_session.cwd = str(initial)
    fake_session.live_cwd = MagicMock(return_value=str(current))
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    resolved = daemon._resolve_sandbox_root("sbx-1", {})
    assert resolved == current.resolve()


def test_resolver_falls_back_to_session_cwd_when_live_cwd_unavailable(daemon, tmp_path):
    """tmux unreachable / just-started session — degrade to the recorded
    folder rather than refusing the request."""
    folder = tmp_path / "sandbox"
    folder.mkdir()
    fake_session = MagicMock()
    fake_session.cwd = str(folder)
    fake_session.live_cwd = MagicMock(return_value=None)
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    resolved = daemon._resolve_sandbox_root("sbx-1", {})
    assert resolved == folder.resolve()


def test_resolver_allows_paths_outside_sandboxes_root(daemon, tmp_path):
    """Read-only file ops follow the shell. The user can ``cd`` anywhere
    their terminal can reach — the sandboxes_root constraint that applies
    to CREATE_SANDBOX does NOT apply here. This is the security-model
    relaxation that makes the Files panel actually useful in practice."""
    # Build a directory clearly OUTSIDE the configured sandboxes_root
    # (which conftest sets to tmp_path itself). Use a sibling of tmp_path
    # so `relative_to` against sandboxes_root would fail.
    outside = tmp_path.parent / f"outside-{tmp_path.name}"
    outside.mkdir(exist_ok=True)
    try:
        fake_session = MagicMock()
        fake_session.cwd = str(tmp_path)
        fake_session.live_cwd = MagicMock(return_value=str(outside))
        daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

        resolved = daemon._resolve_sandbox_root("sbx-1", {})
        assert resolved == outside.resolve()
    finally:
        outside.rmdir()


def test_resolver_explicit_folder_path_still_wins(daemon, tmp_path):
    """The browser override remains the highest-priority source."""
    a = tmp_path / "a"; a.mkdir()
    b = tmp_path / "b"; b.mkdir()
    fake_session = MagicMock()
    fake_session.cwd = str(a)
    fake_session.live_cwd = MagicMock(return_value=str(a))
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    resolved = daemon._resolve_sandbox_root("sbx-1", {"folder_path": str(b)})
    assert resolved == b.resolve()


def test_resolver_returns_none_for_nonexistent_path(daemon, tmp_path):
    """Even if a session reports a path, the resolver must verify it
    still exists — otherwise file_ops would error opaquely later."""
    fake_session = MagicMock()
    fake_session.cwd = str(tmp_path / "gone")  # never created
    fake_session.live_cwd = MagicMock(return_value=None)
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    assert daemon._resolve_sandbox_root("sbx-1", {}) is None


def test_resolver_returns_none_when_no_session(daemon):
    """No PTY session means we can't know where the user is — refuse
    rather than guessing the sandbox_manager default."""
    daemon.pty_manager.get_session = MagicMock(return_value=None)
    assert daemon._resolve_sandbox_root("sbx-1", {}) is None


# ----- end-to-end: panels follow live cwd -----

async def test_file_list_follows_live_cwd(daemon, tmp_path):
    """When tmux reports a different folder, file listings come from THAT
    folder — proves the integration through handle_file_list_request."""
    initial = tmp_path / "initial"
    initial.mkdir()
    (initial / "old.txt").write_text("old")

    current = tmp_path / "current"
    current.mkdir()
    (current / "new.txt").write_text("new")
    (current / "another.py").write_text("# code")

    fake_session = MagicMock()
    fake_session.cwd = str(initial)
    fake_session.live_cwd = MagicMock(return_value=str(current))
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))
    await daemon.handle_file_list_request("sbx-1", {"relative_path": ""})

    names = {e["name"] for e in sent[0]["payload"]["entries"]}
    assert names == {"new.txt", "another.py"}
    assert "old.txt" not in names


async def test_git_status_follows_live_cwd(daemon, tmp_path):
    """Same proof for the Git panel — the agent picks up the live cwd
    before invoking git_ops."""
    current = tmp_path / "project"
    current.mkdir()
    subprocess.run(["git", "init", "-q", "-b", "main"], cwd=str(current), check=True)
    subprocess.run(["git", "config", "user.email", "t@t"], cwd=str(current), check=True)
    subprocess.run(["git", "config", "user.name", "T"], cwd=str(current), check=True)
    (current / "f.txt").write_text("x")
    subprocess.run(["git", "add", "f.txt"], cwd=str(current), check=True)
    subprocess.run(["git", "commit", "-qm", "init"], cwd=str(current), check=True)

    fake_session = MagicMock()
    fake_session.cwd = str(tmp_path)  # NOT a git repo
    fake_session.live_cwd = MagicMock(return_value=str(current))
    daemon.pty_manager.get_session = MagicMock(return_value=fake_session)

    sent: list[dict] = []
    daemon.send = AsyncMock(side_effect=lambda m: sent.append(m))
    await daemon.handle_git_status_request("sbx-1", {})

    assert sent[0]["payload"]["branch"] == "main"
