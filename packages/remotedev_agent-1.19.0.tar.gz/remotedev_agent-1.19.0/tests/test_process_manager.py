"""Tests for the detached-mode process manager.

The actual fork is exercised end-to-end via a sleep-based stub child
process; assertions cover the non-fork code paths and the public API
contract used by cli.py.
"""

from __future__ import annotations

import os
import signal
import time
from pathlib import Path

import pytest


@pytest.fixture
def temp_state(tmp_path, monkeypatch):
    from remotedev_agent import process_manager as pm
    monkeypatch.setattr(pm, "CONFIG_DIR", tmp_path)
    monkeypatch.setattr(pm, "PID_FILE", tmp_path / "agent.pid")
    monkeypatch.setattr(pm, "LOG_FILE", tmp_path / "agent.log")
    return pm


def test_status_when_not_running(temp_state):
    info = temp_state.status()
    assert info["detached_running"] is False
    assert info["pid"] is None


def _dead_pid() -> int:
    """A PID that has definitely already exited (so os.kill(pid, 0) fails)."""
    pid = os.fork()
    if pid == 0:
        os._exit(0)
    # Reap so the kernel can release the PID; the slot may still be ours
    # for a while though.
    os.waitpid(pid, 0)
    return pid


def test_is_running_with_stale_pid(temp_state):
    pid = _dead_pid()
    temp_state.PID_FILE.write_text(str(pid))
    # Either the kernel has already released our slot (False) or the slot is
    # still recorded but not alive (False). Both acceptable.
    assert temp_state.is_running() is False


def test_stop_when_not_running(temp_state):
    ok, message = temp_state.stop()
    assert ok is False
    assert "not running" in message.lower()


def test_stop_clears_stale_pid_file(temp_state):
    temp_state.PID_FILE.write_text("999999")
    ok, message = temp_state.stop()
    assert ok is False
    assert "stale" in message.lower()
    assert not temp_state.PID_FILE.exists()


def test_tail_log_no_file(temp_state, capsys):
    temp_state.tail_log(lines=10, follow=False)
    captured = capsys.readouterr()
    assert "No log file" in captured.out


def test_tail_log_returns_last_n_lines(temp_state, capsys):
    temp_state.LOG_FILE.write_bytes(b"\n".join(f"line {i}".encode() for i in range(50)) + b"\n")
    temp_state.tail_log(lines=5, follow=False)
    out = capsys.readouterr().out
    # Last 5 lines should be 45..49.
    assert "line 49" in out
    assert "line 45" in out
    assert "line 44" not in out


def test_log_rotation_at_threshold(temp_state, monkeypatch):
    monkeypatch.setattr(temp_state, "LOG_MAX_BYTES", 100)
    temp_state.LOG_FILE.write_bytes(b"x" * 200)
    temp_state._rotate_log()
    assert not temp_state.LOG_FILE.exists()
    assert temp_state.LOG_FILE.with_suffix(".log.1").exists()


def test_detach_refuses_when_already_running(temp_state):
    temp_state.PID_FILE.write_text(str(os.getpid()))
    with pytest.raises(RuntimeError, match="already running"):
        temp_state.detach_and_run(lambda: None)


def test_detach_refuses_on_windows(monkeypatch, temp_state):
    monkeypatch.setattr("sys.platform", "win32")
    with pytest.raises(RuntimeError, match="not supported on Windows"):
        temp_state.detach_and_run(lambda: None)


def test_is_our_process_rejects_recycled_pid(temp_state):
    """Same PID, different starttime → not our daemon (PID was recycled)."""
    rec = {"pid": os.getpid(), "starttime": "definitely-not-the-real-starttime"}
    assert temp_state._is_our_process(rec) is False


def test_is_our_process_accepts_when_starttime_matches(temp_state):
    """If starttime matches the live PID, it's our daemon."""
    real_starttime = temp_state._proc_starttime(os.getpid())
    rec = {"pid": os.getpid(), "starttime": real_starttime}
    # _proc_starttime may return None on unsupported platforms; in that case the
    # function falls back to liveness-only and still returns True.
    assert temp_state._is_our_process(rec) is True


def test_service_status_returns_none_when_no_unit(temp_state, monkeypatch, tmp_path):
    """On Linux, kind=None when ~/.config/systemd/user/remotedev-agent.service is absent."""
    monkeypatch.setattr("sys.platform", "linux")
    monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
    info = temp_state.service_status()
    assert info["kind"] is None
    assert info["running"] is False
