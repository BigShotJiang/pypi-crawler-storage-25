"""Tests for PTYSession and PTYManager.

The star of this file is `test_read_loop_survives_on_output_exception`
which would have caught today's 52049d4 bug: a transient on_output failure
killed the read loop, leaving the PTY accepting input with no output path.
"""
from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from remotedev_agent.pty_manager import (
    MAX_SCROLLBACK,
    PTYManager,
    PTYSession,
    _capture_tmux_scrollback,
    _strip_terminal_replies,
)


def _make_session(on_output=None) -> PTYSession:
    if on_output is None:
        on_output = AsyncMock()
    return PTYSession("sbx-1", "/tmp/sbx", on_output)


# ---------------------------------------------------------------------------
# P0: _read_loop — today's bug
# ---------------------------------------------------------------------------

async def test_read_loop_survives_on_output_exception():
    """Regression for 52049d4.

    The read loop must NOT exit when on_output raises — otherwise a transient
    WebSocket failure silently breaks the PTY forever until reattach.
    """
    session = _make_session()

    # Mock process: two reads yield b"hi", then EOFError to stop the loop.
    process = MagicMock()
    process.isalive.return_value = True
    reads = [b"hi", b"hi", EOFError()]

    def fake_read(_size):
        nxt = reads.pop(0)
        if isinstance(nxt, Exception):
            raise nxt
        return nxt

    process.read.side_effect = fake_read
    session.process = process

    call_count = 0

    async def on_output(sid: str, data: str):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise RuntimeError("ws closed")
        # second call succeeds

    session.on_output = on_output

    await session._read_loop()

    assert call_count == 2, "Second on_output call must have happened — loop did not exit early"


async def test_read_loop_exits_cleanly_on_eof():
    session = _make_session()
    process = MagicMock()
    process.isalive.return_value = True
    process.read.side_effect = EOFError()
    session.process = process

    await session._read_loop()  # should return, not raise


async def test_read_loop_exits_on_non_eof_read_error():
    session = _make_session()
    process = MagicMock()
    process.isalive.return_value = True
    process.read.side_effect = OSError("pty gone")
    session.process = process

    # Should break out cleanly, not propagate
    await session._read_loop()
    # Only one read attempt because the loop breaks
    assert process.read.call_count == 1


async def test_read_loop_survives_decoder_errors():
    """Decoder exceptions should `continue`, not `break`."""
    session = _make_session()
    process = MagicMock()
    process.isalive.return_value = True
    reads = [b"first", b"second", EOFError()]

    def fake_read(_size):
        nxt = reads.pop(0)
        if isinstance(nxt, Exception):
            raise nxt
        return nxt

    process.read.side_effect = fake_read
    session.process = process

    # Force the decoder to raise once, then behave normally
    original_decode = session._utf8_decoder.decode
    call = {"n": 0}

    def flaky_decode(data, final=False):
        call["n"] += 1
        if call["n"] == 1:
            raise ValueError("boom")
        return original_decode(data, final=final)

    session._utf8_decoder.decode = flaky_decode  # type: ignore[method-assign]

    await session._read_loop()
    # Both reads consumed -> loop didn't break on decoder error
    assert len(reads) == 0
    # on_output called once (first read skipped due to decoder error)
    assert session.on_output.await_count == 1  # type: ignore[attr-defined]


# ---------------------------------------------------------------------------
# P0: handle_open_terminal read-task reattach logic
# ---------------------------------------------------------------------------

async def test_handle_open_terminal_restarts_dead_read_task(daemon, tmp_path):
    """The fix half of 52049d4: if the read task is done, reattach."""
    sandbox_id = "sbx-dead-task"
    folder = tmp_path / "sbx-dead-task"
    folder.mkdir()

    session = PTYSession(sandbox_id, str(folder), AsyncMock())
    session.process = MagicMock()
    session.process.isalive.return_value = True

    # Completed task → done() == True
    done_task: asyncio.Task = asyncio.create_task(asyncio.sleep(0))
    await done_task
    session._read_task = done_task

    session.reattach = MagicMock()
    session.update_output_callback = MagicMock()
    session.resize = MagicMock()
    session.get_tmux_scrollback = MagicMock(return_value="")

    daemon.pty_manager.sessions[sandbox_id] = session

    with patch("remotedev_agent.daemon._tmux_session_exists", return_value=True), \
         patch.object(type(session), "is_alive", new=True), \
         patch("remotedev_agent.daemon.subprocess.run"):
        daemon.send = AsyncMock()
        await daemon.handle_open_terminal(sandbox_id, {
            "folder_path": str(folder),
            "rows": 24,
            "cols": 80,
        })

    session.reattach.assert_called_once()
    # Stale ptyprocess should have been force-terminated before reattach
    session.process.terminate.assert_called_once_with(force=True)


async def test_handle_open_terminal_does_not_restart_healthy_read_task(daemon, tmp_path):
    sandbox_id = "sbx-healthy"
    folder = tmp_path / sandbox_id
    folder.mkdir()

    # Pending task — never completed
    async def forever():
        await asyncio.sleep(3600)

    loop = asyncio.get_event_loop()
    pending_task = loop.create_task(forever())

    try:
        session = PTYSession(sandbox_id, str(folder), AsyncMock())
        session.process = MagicMock()
        session.process.isalive.return_value = True
        session._read_task = pending_task

        session.reattach = MagicMock()
        session.update_output_callback = MagicMock()
        session.resize = MagicMock()
        session.get_tmux_scrollback = MagicMock(return_value="")

        daemon.pty_manager.sessions[sandbox_id] = session

        with patch("remotedev_agent.daemon._tmux_session_exists", return_value=True), \
             patch.object(type(session), "is_alive", new=True), \
             patch("remotedev_agent.daemon.subprocess.run"):
            daemon.send = AsyncMock()
            await daemon.handle_open_terminal(sandbox_id, {
                "folder_path": str(folder),
                "rows": 40,
                "cols": 120,
            })

        session.reattach.assert_not_called()
        session.update_output_callback.assert_called_once()
        session.resize.assert_called_once_with(40, 120)
    finally:
        pending_task.cancel()
        try:
            await pending_task
        except (asyncio.CancelledError, BaseException):
            pass


async def test_handle_open_terminal_reattaches_when_process_is_dead(daemon, tmp_path):
    sandbox_id = "sbx-dead-proc"
    folder = tmp_path / sandbox_id
    folder.mkdir()

    session = PTYSession(sandbox_id, str(folder), AsyncMock())
    dead_proc = MagicMock()
    dead_proc.isalive.return_value = False
    session.process = dead_proc

    # Pending task (so only the process-dead branch matters)
    async def forever():
        await asyncio.sleep(3600)

    pending = asyncio.get_event_loop().create_task(forever())
    try:
        session._read_task = pending

        session.reattach = MagicMock()
        session.update_output_callback = MagicMock()
        session.get_tmux_scrollback = MagicMock(return_value="")

        daemon.pty_manager.sessions[sandbox_id] = session

        with patch("remotedev_agent.daemon._tmux_session_exists", return_value=True), \
             patch.object(type(session), "is_alive", new=True), \
             patch("remotedev_agent.daemon.subprocess.run"):
            daemon.send = AsyncMock()
            await daemon.handle_open_terminal(sandbox_id, {
                "folder_path": str(folder),
                "rows": 24,
                "cols": 80,
            })

        session.reattach.assert_called_once()
        session.update_output_callback.assert_not_called()
    finally:
        pending.cancel()
        try:
            await pending
        except BaseException:
            pass


# ---------------------------------------------------------------------------
# P1: PTYSession internals
# ---------------------------------------------------------------------------

def test_write_catches_oserror(mock_pty_process):
    mock_pty_process.write.side_effect = OSError("broken pipe")
    session = _make_session()
    session.process = mock_pty_process
    # Should not raise
    session.write("hello")


def test_write_noop_when_process_none():
    session = _make_session()
    session.process = None
    session.write("anything")  # no exception = pass


def test_write_noop_when_process_not_alive(mock_pty_process):
    mock_pty_process.isalive.return_value = False
    session = _make_session()
    session.process = mock_pty_process
    session.write("hi")
    mock_pty_process.write.assert_not_called()


async def test_terminate_cancels_read_task_and_kills_process(mock_pty_process):
    session = _make_session()
    session.process = mock_pty_process

    async def forever():
        await asyncio.sleep(3600)

    task = asyncio.get_event_loop().create_task(forever())
    session._read_task = task

    session.terminate()
    mock_pty_process.terminate.assert_called_once_with(force=True)

    # Let the cancellation propagate
    try:
        await task
    except BaseException:
        pass

    assert task.cancelled() or task.done()


def test_append_scrollback_enforces_max_bytes():
    session = _make_session()
    chunk = "x" * 10_000
    # 15 chunks = 150_000 bytes > MAX_SCROLLBACK (100_000)
    for _ in range(15):
        session._append_scrollback(chunk)
    assert session._scrollback_size <= MAX_SCROLLBACK
    assert len(session._scrollback) >= 1


def test_is_alive_checks_tmux_session_existence():
    session = _make_session()
    with patch("remotedev_agent.pty_manager._tmux_session_exists", return_value=True) as m:
        assert session.is_alive is True
        m.assert_called_once_with(session.tmux_session_name)
    with patch("remotedev_agent.pty_manager._tmux_session_exists", return_value=False):
        assert session.is_alive is False


# ---------------------------------------------------------------------------
# P1: PTYManager
# ---------------------------------------------------------------------------

def test_create_session_terminates_existing():
    mgr = PTYManager()
    first = mgr.create_session("sbx-1", "/tmp", AsyncMock())
    first.terminate = MagicMock()
    second = mgr.create_session("sbx-1", "/tmp", AsyncMock())
    first.terminate.assert_called_once()
    assert mgr.sessions["sbx-1"] is second
    assert second is not first


def test_remove_session_destroys_and_removes():
    mgr = PTYManager()
    sess = mgr.create_session("sbx-2", "/tmp", AsyncMock())
    sess.destroy = MagicMock()
    mgr.remove_session("sbx-2")
    sess.destroy.assert_called_once()
    assert "sbx-2" not in mgr.sessions


def test_get_session_returns_none_for_unknown():
    mgr = PTYManager()
    assert mgr.get_session("nope") is None


# ---------------------------------------------------------------------------
# P0: terminal-reply CSI sanitiser
# ---------------------------------------------------------------------------
# Regression: xterm.js auto-replies to host queries (DA / cursor-position /
# window-manipulation). Those replies travel back as TERMINAL_INPUT and used
# to reach the shell, e.g. surfacing as `zsh: command not found: 50` and
# garbage glyphs in scrollback. They must be stripped on both the input path
# (PTYSession.write) and the scrollback-replay path (_capture_tmux_scrollback).


@pytest.mark.parametrize(
    "raw",
    [
        # DA1 (Primary Device Attributes)
        "\x1b[?64;1;2;6;9;15;18;21;22c",
        # DA2 (Secondary)
        "\x1b[>41;320;0c",
        # DA3 (Tertiary)
        "\x1b[=0c",
        # Bare DA query (matches existing behaviour, also stripped)
        "\x1b[c",
        # Cursor position report
        "\x1b[24;80R",
        # Window-manipulation reports (text-area + pixel-area)
        "\x1b[8;50;142t",
        "\x1b[4;600;1704t",
    ],
)
def test_strip_terminal_replies_removes_known_reply_sequences(raw):
    assert _strip_terminal_replies(raw) == ""
    assert _strip_terminal_replies(f"before{raw}after") == "beforeafter"


def test_strip_terminal_replies_handles_concatenated_burst():
    # Exact burst from the v1.5 audit ticket
    burst = (
        "\x1b[?64;1;2;6;9;15;18;21;22c"
        "\x1b[>41;320;0c"
        "\x1b[8;50;142t"
        "\x1b[4;600;1704t"
    )
    assert _strip_terminal_replies(burst) == ""


@pytest.mark.parametrize(
    "raw",
    [
        # Real keyboard input — must not be touched
        "ls -la\n",
        "echo hello\r",
        # Arrow / function keys
        "\x1b[A",
        "\x1b[1;5C",
        # Plain text containing characters that appear in reply sequences
        "use port 50;142 for the server",
        # ESC alone
        "\x1b",
    ],
)
def test_strip_terminal_replies_preserves_legitimate_input(raw):
    assert _strip_terminal_replies(raw) == raw


def test_write_strips_terminal_reply_before_pty(mock_pty_process):
    """Live-input path: xterm.js DA reply must never reach the shell."""
    session = _make_session()
    session.process = mock_pty_process

    session.write("ls\x1b[?64;1;2c\n")
    mock_pty_process.write.assert_called_once_with(b"ls\n")


def test_write_noop_when_input_is_only_reply_sequences(mock_pty_process):
    """If the entire chunk is replies, do not call into the PTY at all."""
    session = _make_session()
    session.process = mock_pty_process

    session.write("\x1b[?64;1;2;6;9;15;18;21;22c\x1b[>41;320;0c\x1b[8;50;142t")
    mock_pty_process.write.assert_not_called()


def test_capture_tmux_scrollback_strips_window_manipulation_reports():
    """Scrollback-replay path: tmux capture-pane includes the leaked replies."""
    fake_capture = (
        "$ ls\n"
        "file.txt\n"
        "\x1b[?64;1;2c\x1b[>41;320;0c\x1b[8;50;142t\x1b[4;600;1704t"
    )
    completed = MagicMock()
    completed.returncode = 0
    completed.stdout = fake_capture

    with patch("remotedev_agent.pty_manager.subprocess.run", return_value=completed):
        out = _capture_tmux_scrollback("remotedev-sbx-1")

    assert "\x1b[" not in out
    assert "$ ls" in out
    assert "file.txt" in out
