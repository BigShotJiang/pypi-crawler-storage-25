"""Unit tests for the machine-utilization metrics helper.

Covers:
  * happy-path shape
  * single failing field does not blank the rest
  * disk path fallback when sandboxes_root is missing
  * session_count is forwarded
  * load_1m is None when os.getloadavg isn't available
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from remotedev_agent import metrics as metrics_mod


EXPECTED_KEYS = {"cpu_pct", "ram_pct", "disk_pct", "load_1m", "uptime_s", "sessions"}


def _fake_psutil(*, vm_pct=42.0, du_pct=12.5, cpu_pct=7.0, boot=1_000_000.0):
    """Build a MagicMock that mimics the psutil surface we touch."""
    fake = MagicMock()
    fake.cpu_percent.return_value = cpu_pct
    vm = MagicMock()
    vm.percent = vm_pct
    fake.virtual_memory.return_value = vm
    du = MagicMock()
    du.percent = du_pct
    fake.disk_usage.return_value = du
    fake.boot_time.return_value = boot
    return fake


def test_metrics_returns_expected_shape(tmp_path):
    fake = _fake_psutil()
    with patch.object(metrics_mod, "psutil", fake):
        result = metrics_mod.metrics(sandboxes_root=str(tmp_path), session_count=3)

    assert set(result.keys()) == EXPECTED_KEYS
    assert result["cpu_pct"] == 7.0
    assert result["ram_pct"] == 42.0
    assert result["disk_pct"] == 12.5
    assert result["sessions"] == 3
    # uptime is an int derived from time.time() - boot_time(); just assert type
    assert isinstance(result["uptime_s"], int)


def test_metrics_single_failing_field_doesnt_blank_others(tmp_path):
    """If psutil.disk_usage raises, cpu/ram should still come through."""
    fake = _fake_psutil()
    fake.disk_usage.side_effect = OSError("disk gone")

    with patch.object(metrics_mod, "psutil", fake):
        result = metrics_mod.metrics(sandboxes_root=str(tmp_path), session_count=0)

    assert result["disk_pct"] is None
    # Other fields must still be populated
    assert result["cpu_pct"] == 7.0
    assert result["ram_pct"] == 42.0
    assert isinstance(result["uptime_s"], int)
    assert result["sessions"] == 0


def test_metrics_falls_back_to_home_when_sandboxes_root_missing(tmp_path):
    """A non-existent sandboxes_root shouldn't blow up — fall back to ~."""
    fake = _fake_psutil()
    missing = tmp_path / "does-not-exist"

    with patch.object(metrics_mod, "psutil", fake):
        result = metrics_mod.metrics(sandboxes_root=str(missing), session_count=1)

    # disk_usage should still have been called (on home dir), not on the missing path
    args, _ = fake.disk_usage.call_args
    assert args[0] != str(missing)
    assert result["disk_pct"] == 12.5


def test_metrics_sessions_forwarded():
    fake = _fake_psutil()
    with patch.object(metrics_mod, "psutil", fake):
        result = metrics_mod.metrics(sandboxes_root=None, session_count=7)
    assert result["sessions"] == 7


def test_metrics_load_1m_none_when_getloadavg_absent(tmp_path):
    """On platforms without os.getloadavg (Windows), load_1m must be None."""
    fake = _fake_psutil()
    with patch.object(metrics_mod, "psutil", fake), \
         patch("remotedev_agent.metrics.hasattr", lambda obj, name: False if name == "getloadavg" else hasattr(obj, name)):
        result = metrics_mod.metrics(sandboxes_root=str(tmp_path), session_count=0)
    assert result["load_1m"] is None


def test_metrics_when_psutil_missing_returns_none_fields():
    """If psutil isn't importable, return the schema with None values."""
    with patch.object(metrics_mod, "psutil", None):
        result = metrics_mod.metrics(sandboxes_root=None, session_count=2)
    assert set(result.keys()) == EXPECTED_KEYS
    assert result["sessions"] == 2
    for k in ("cpu_pct", "ram_pct", "disk_pct", "load_1m", "uptime_s"):
        assert result[k] is None, f"{k} should be None when psutil missing"
