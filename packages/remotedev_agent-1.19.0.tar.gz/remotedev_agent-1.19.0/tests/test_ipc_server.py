"""Tests for the agent IPC server + maestro CLI plumbing.

Covers the Phase-1 BROWSER_OPEN path end-to-end at the Python level:
  - IPC server binds, sets 0600 perms, removes stale socket file
  - browser_open with valid args dispatches a BROWSER_OPEN WS message
  - validation errors surface as ``{ok: false, error: ...}`` replies
  - offline daemon (no ws) returns a clear error instead of hanging

Tests use a real Unix socket under tmp_path so we exercise the actual
asyncio.start_unix_server code path — mocking the socket would defeat
the purpose.
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import socket
import tempfile
import uuid
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from remotedev_agent import ipc_server as ipc_mod


@pytest.fixture
def tmp_socket(monkeypatch):
    """Redirect the IPC socket path to a short tmpdir for the test.

    macOS / Linux cap AF_UNIX paths at ~104/108 bytes. pytest's default
    ``tmp_path`` (under /private/var/folders/...) is too deep. We mint
    a short path under ``/tmp`` for each test and clean up afterwards.
    """
    sock_dir = Path(tempfile.gettempdir()) / f"rd-ipc-{uuid.uuid4().hex[:8]}"
    sock_path = sock_dir / "agent.sock"
    monkeypatch.setattr(ipc_mod, "SOCKET_DIR", sock_dir)
    monkeypatch.setattr(ipc_mod, "SOCKET_PATH", sock_path)
    try:
        yield sock_path
    finally:
        shutil.rmtree(sock_dir, ignore_errors=True)


@pytest.fixture
def fake_daemon():
    """A daemon stand-in with a stub send() the IPC server can call."""
    daemon = MagicMock()
    daemon.ws = MagicMock()  # Not None — looks "connected"
    daemon.send = AsyncMock()
    return daemon


async def _send_command(sock_path: Path, payload: dict) -> dict:
    """Open a Unix socket, send one JSON line, return the parsed reply."""
    reader, writer = await asyncio.open_unix_connection(str(sock_path))
    try:
        writer.write((json.dumps(payload) + "\n").encode("utf-8"))
        await writer.drain()
        line = await reader.readline()
    finally:
        writer.close()
        try:
            await writer.wait_closed()
        except Exception:
            pass
    assert line, "server closed without replying"
    return json.loads(line.decode("utf-8"))


async def test_browser_open_dispatches_ws_message(tmp_socket, fake_daemon):
    """Happy path: valid command → daemon.send called with BROWSER_OPEN."""
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {
            "action": "browser_open",
            "url": "https://example.com",
            "sandbox_id": "sbox-1",
        })
        assert reply == {"ok": True}
        fake_daemon.send.assert_awaited_once()
        sent = fake_daemon.send.call_args.args[0]
        assert sent["type"] == "BROWSER_OPEN"
        assert sent["sandbox_id"] == "sbox-1"
        assert sent["payload"] == {"url": "https://example.com"}
        assert isinstance(sent["ts"], float)
    finally:
        await server.stop()


async def test_browser_open_rejects_missing_url(tmp_socket, fake_daemon):
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {
            "action": "browser_open",
            "sandbox_id": "sbox-1",
        })
        assert reply["ok"] is False
        assert "url" in reply["error"].lower()
        fake_daemon.send.assert_not_awaited()
    finally:
        await server.stop()


async def test_browser_open_rejects_bad_scheme(tmp_socket, fake_daemon):
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {
            "action": "browser_open",
            "url": "javascript:alert(1)",
            "sandbox_id": "sbox-1",
        })
        assert reply["ok"] is False
        # We don't validate against XSS here — that's the browser's job —
        # but we want a clear "scheme not supported" message for typos.
        assert "http" in reply["error"].lower()
        fake_daemon.send.assert_not_awaited()
    finally:
        await server.stop()


async def test_browser_open_rejects_when_offline(tmp_socket, fake_daemon):
    """If ``daemon.ws is None`` the daemon is between reconnects → fail fast."""
    fake_daemon.ws = None
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {
            "action": "browser_open",
            "url": "https://example.com",
            "sandbox_id": "sbox-1",
        })
        assert reply["ok"] is False
        assert "offline" in reply["error"].lower() or "not connected" in reply["error"].lower()
        fake_daemon.send.assert_not_awaited()
    finally:
        await server.stop()


async def test_unknown_action_rejected(tmp_socket, fake_daemon):
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {"action": "wat"})
        assert reply["ok"] is False
        assert "unknown action" in reply["error"].lower()
    finally:
        await server.stop()


async def test_malformed_json_rejected(tmp_socket, fake_daemon):
    """A garbage payload shouldn't crash the server."""
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        reader, writer = await asyncio.open_unix_connection(str(tmp_socket))
        try:
            writer.write(b"not json at all\n")
            await writer.drain()
            line = await reader.readline()
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:
                pass
        reply = json.loads(line.decode("utf-8"))
        assert reply["ok"] is False
        assert "invalid json" in reply["error"].lower()
    finally:
        await server.stop()


async def test_socket_has_0600_perms(tmp_socket, fake_daemon):
    """The socket must not be world- or group-readable."""
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        mode = os.stat(tmp_socket).st_mode & 0o777
        assert mode == 0o600, f"expected 0600, got {oct(mode)}"
    finally:
        await server.stop()


async def test_stale_socket_removed_on_start(tmp_socket, fake_daemon):
    """A leftover socket file from a crashed daemon should not block startup."""
    tmp_socket.parent.mkdir(parents=True, exist_ok=True)
    # Create a regular file at the socket path — simulates leftover state.
    tmp_socket.write_text("stale")
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    try:
        # Should now be a socket, not a regular file.
        import stat
        assert stat.S_ISSOCK(os.stat(tmp_socket).st_mode)
    finally:
        await server.stop()


async def test_server_stop_removes_socket(tmp_socket, fake_daemon):
    server = ipc_mod.IPCServer(fake_daemon)
    await server.start()
    assert tmp_socket.exists()
    await server.stop()
    assert not tmp_socket.exists()


# ── browser_command ──────────────────────────────────────────────────


@pytest.fixture
def fake_daemon_with_pending(fake_daemon):
    """Daemon stub with the pending_browser_commands dict + ws hook."""
    fake_daemon.pending_browser_commands = {}
    return fake_daemon


async def test_browser_command_dispatches_envelope(tmp_socket, fake_daemon_with_pending):
    """Happy path: BROWSER_COMMAND sent, BROWSER_RESULT awaited, returned."""
    server = ipc_mod.IPCServer(fake_daemon_with_pending)
    await server.start()
    try:
        # Schedule a fake BROWSER_RESULT to complete the future shortly
        # after the command is sent.
        async def _drive_response():
            await asyncio.sleep(0.05)
            # The IPC server stored a future under the generated command_id.
            assert len(fake_daemon_with_pending.pending_browser_commands) == 1
            command_id, future = next(iter(
                fake_daemon_with_pending.pending_browser_commands.items()
            ))
            future.set_result({
                "type": "BROWSER_RESULT",
                "command_id": command_id,
                "sandbox_id": "sbox-1",
                "payload": {"ok": True, "current_url": "https://x.test"},
                "error": None,
                "ts": 0,
            })
            # The handler pops on success, but it's fine if the test
            # itself didn't pop — the daemon's BROWSER_RESULT case would.

        asyncio.create_task(_drive_response())

        reply = await _send_command(tmp_socket, {
            "action": "browser_command",
            "sandbox_id": "sbox-1",
            "payload": {"action": "navigate", "url": "https://x.test"},
        })
        assert reply["ok"] is True
        assert reply["result"]["current_url"] == "https://x.test"
        # And the envelope was actually sent.
        fake_daemon_with_pending.send.assert_awaited_once()
        sent = fake_daemon_with_pending.send.call_args.args[0]
        assert sent["type"] == "BROWSER_COMMAND"
        assert sent["sandbox_id"] == "sbox-1"
        assert sent["payload"]["action"] == "navigate"
        assert "command_id" in sent
    finally:
        await server.stop()


async def test_browser_command_rejects_unknown_action(tmp_socket, fake_daemon_with_pending):
    server = ipc_mod.IPCServer(fake_daemon_with_pending)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {
            "action": "browser_command",
            "sandbox_id": "sbox-1",
            "payload": {"action": "format_disk"},
        })
        assert reply["ok"] is False
        assert "action must be" in reply["error"].lower()
        fake_daemon_with_pending.send.assert_not_awaited()
    finally:
        await server.stop()


async def test_browser_command_rejects_when_offline(tmp_socket, fake_daemon_with_pending):
    fake_daemon_with_pending.ws = None
    server = ipc_mod.IPCServer(fake_daemon_with_pending)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {
            "action": "browser_command",
            "sandbox_id": "sbox-1",
            "payload": {"action": "navigate", "url": "https://x.test"},
        })
        assert reply["ok"] is False
        assert "offline" in reply["error"].lower()
    finally:
        await server.stop()


async def test_browser_command_times_out_when_no_response(
    tmp_socket, fake_daemon_with_pending, monkeypatch
):
    """If no BROWSER_RESULT arrives within the timeout, return a clean error."""
    # Shrink the timeout from 30s → 0.2s so the test runs fast.
    monkeypatch.setattr(ipc_mod, "_BROWSER_COMMAND_TIMEOUT_S", 0.2)
    server = ipc_mod.IPCServer(fake_daemon_with_pending)
    await server.start()
    try:
        reply = await _send_command(tmp_socket, {
            "action": "browser_command",
            "sandbox_id": "sbox-1",
            "payload": {"action": "navigate", "url": "https://x.test"},
        })
        assert reply["ok"] is False
        assert "did not reply" in reply["error"].lower()
        # And the pending entry got cleaned up.
        assert fake_daemon_with_pending.pending_browser_commands == {}
    finally:
        await server.stop()
