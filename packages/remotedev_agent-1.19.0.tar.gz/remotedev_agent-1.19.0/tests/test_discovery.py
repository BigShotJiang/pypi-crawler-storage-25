"""Tests for agent discovery."""
from __future__ import annotations

from unittest.mock import MagicMock, patch

from remotedev_agent.discovery import discover_agents, get_os_info


def test_discover_agents_returns_subset_from_subprocess():
    def fake_run(cmd, **kwargs):
        result = MagicMock()
        # claude and aider are "installed" (rc=0), others raise FileNotFoundError
        if cmd[0] in ("claude", "aider"):
            result.returncode = 0
            return result
        raise FileNotFoundError(cmd[0])

    with patch("remotedev_agent.discovery.subprocess.run", side_effect=fake_run):
        agents = discover_agents()

    assert set(agents) == {"claude", "aider"}
    # Only from the known whitelist
    assert all(a in {"claude", "codex", "aider", "copilot", "cursor"} for a in agents)


def test_get_os_info_has_expected_keys():
    info = get_os_info()
    for key in ("os", "arch", "hostname", "user", "python"):
        assert key in info
