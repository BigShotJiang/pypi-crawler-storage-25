import asyncio
import os
import subprocess
import tempfile


class PlaybackError(Exception):
    pass


class StreamingPlayer:
    """Plays MP3 chunks using afplay with an async queue.

    feed() enqueues chunks without blocking, so the WebSocket stream
    keeps receiving while earlier chunks play. A background task
    consumes the queue and plays chunks sequentially via afplay,
    which respects macOS system audio routing (AirPlay, etc.).
    """

    def __init__(self) -> None:
        self._temp_dir = tempfile.mkdtemp(prefix="elvenreader_")
        self._chunk_index = 0
        self._queue: asyncio.Queue[str | None] = asyncio.Queue()
        self._player_task = asyncio.ensure_future(self._player_loop())

    async def feed(self, chunk: bytes) -> None:
        """Write chunk to temp file and enqueue for playback."""
        path = os.path.join(self._temp_dir, f"chunk_{self._chunk_index}.mp3")
        self._chunk_index += 1
        with open(path, "wb") as f:
            f.write(chunk)
        await self._queue.put(path)

    async def _player_loop(self) -> None:
        """Background task: play queued chunks sequentially."""
        loop = asyncio.get_running_loop()
        while True:
            path = await self._queue.get()
            if path is None:
                break
            await loop.run_in_executor(None, self._play_and_cleanup, path)

    def _play_and_cleanup(self, path: str) -> None:
        subprocess.run(["afplay", path], check=False)
        os.unlink(path)

    async def close(self) -> None:
        """Signal end of stream and wait for all chunks to finish playing."""
        await self._queue.put(None)
        await self._player_task
        try:
            os.rmdir(self._temp_dir)
        except OSError:
            pass
