import time

from elvenreader.http import client

from elvenreader.config import FIREBASE_SIGN_IN_URL, FIREBASE_REFRESH_URL
from elvenreader.types import AuthState, TokenPair


class AuthError(Exception):
    pass


async def sign_in(email: str, password: str) -> AuthState:
    """Firebase email/password authentication."""
    async with client() as http:
        resp = await http.post(
            FIREBASE_SIGN_IN_URL,
            json={"email": email, "password": password, "returnSecureToken": True},
        )
    if resp.status_code != 200:
        raise AuthError(f"Sign-in failed ({resp.status_code}): {resp.text}")
    data = resp.json()
    return AuthState(
        id_token=data["idToken"],
        refresh_token=data["refreshToken"],
        expires_at=time.time() + int(data["expiresIn"]),
    )


async def refresh_id_token(refresh_token: str) -> AuthState:
    """Exchange a refresh token for a new ID token."""
    async with client() as http:
        resp = await http.post(
            FIREBASE_REFRESH_URL,
            data={"grant_type": "refresh_token", "refresh_token": refresh_token},
        )
    if resp.status_code != 200:
        raise AuthError(f"Token refresh failed ({resp.status_code}): {resp.text}")
    data = resp.json()
    return AuthState(
        id_token=data["id_token"],
        refresh_token=data["refresh_token"],
        expires_at=time.time() + int(data["expires_in"]),
    )


# [LAW:dataflow-not-control-flow] Token validity is determined by comparing
# timestamps. get_valid_id_token always returns a valid token — refresh is
# a computation on the expiration data, not a conditional branch.
async def get_valid_id_token(auth_state: AuthState) -> AuthState:
    """Return an AuthState with a valid (non-expired) ID token."""
    now = time.time()
    remaining = auth_state.expires_at - now
    # Refresh when less than 5 minutes remain
    needs_refresh = remaining < 300
    return (
        await refresh_id_token(auth_state.refresh_token)
        if needs_refresh
        else auth_state
    )


def make_token_pair(auth_state: AuthState, app_check_token: str) -> TokenPair:
    return TokenPair(id_token=auth_state.id_token, app_check_token=app_check_token)
