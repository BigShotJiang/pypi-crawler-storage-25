"""Shared HTTP client that uses the macOS system trust store."""

import ssl

import httpx
import truststore


def make_ssl_context() -> ssl.SSLContext:
    return truststore.SSLContext(ssl.PROTOCOL_TLS_CLIENT)


def client(**kwargs) -> httpx.AsyncClient:
    """Create an AsyncClient that trusts system CA certificates (including AirPlay/proxy CAs)."""
    return httpx.AsyncClient(verify=make_ssl_context(), **kwargs)
