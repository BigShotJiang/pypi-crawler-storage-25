"""ElvenReader API client — library and CLI for ElvenReader TTS.

High-level usage:

    from elvenreader import ElvenReader

    reader = ElvenReader(email="...", password="...")
    mp3_bytes = await reader.read("Hello world", voice="brian")

    # Or with stored credentials (from `elvenreader login`):
    reader = ElvenReader.from_keychain()
    await reader.read_to_file("Hello world", "output.mp3", voice="george")
"""

from elvenreader.auth import sign_in, refresh_id_token, make_token_pair
from elvenreader.audio import concatenate_chunks
from elvenreader.config import DEFAULT_VOICE_ID
from elvenreader.reads import upload_text
from elvenreader.stream import stream_audio
from elvenreader.types import AuthState, TokenPair, AudioChunk, ReadMetadata
from elvenreader.voices import list_voices, resolve_voice, create_previews, save_voice_from_preview

__all__ = [
    "ElvenReader",
    # Types
    "AuthState",
    "TokenPair",
    "AudioChunk",
    "ReadMetadata",
    # Low-level API
    "sign_in",
    "refresh_id_token",
    "make_token_pair",
    "upload_text",
    "stream_audio",
    "list_voices",
    "resolve_voice",
    "create_previews",
    "save_voice_from_preview",
    "concatenate_chunks",
]


class ElvenReader:
    """High-level async client for the ElvenReader TTS API.

    Handles auth refresh, voice resolution, text upload, and audio streaming.
    """

    def __init__(
        self,
        *,
        email: str | None = None,
        password: str | None = None,
        refresh_token: str | None = None,
        app_check_token: str = "",
        device_id: str = "",
    ) -> None:
        import uuid

        self._email = email
        self._password = password
        self._refresh_token = refresh_token
        self._app_check_token = app_check_token
        self._device_id = device_id or str(uuid.uuid4())
        self._auth_state: AuthState | None = None

    @classmethod
    def from_keychain(cls) -> "ElvenReader":
        """Create a client using credentials stored by `elvenreader login`."""
        from elvenreader.credentials import load_credentials

        creds = load_credentials()
        return cls(
            refresh_token=creds.refresh_token,
            app_check_token=creds.app_check_token,
            device_id=creds.device_id,
        )

    async def _ensure_auth(self) -> AuthState:
        """Return a valid AuthState, refreshing or signing in as needed."""
        from elvenreader.auth import get_valid_id_token

        if self._auth_state is not None:
            self._auth_state = await get_valid_id_token(self._auth_state)
            return self._auth_state

        if self._refresh_token:
            self._auth_state = await refresh_id_token(self._refresh_token)
            return self._auth_state

        if self._email and self._password:
            self._auth_state = await sign_in(self._email, self._password)
            self._refresh_token = self._auth_state.refresh_token
            return self._auth_state

        raise RuntimeError(
            "No credentials available. Provide email+password, a refresh_token, "
            "or use ElvenReader.from_keychain()."
        )

    async def read(
        self,
        text: str,
        voice: str = DEFAULT_VOICE_ID,
    ) -> bytes:
        """Read text and return MP3 bytes."""
        auth = await self._ensure_auth()
        voice_id = await resolve_voice(voice, auth)
        read_meta = await upload_text(text, auth)
        token_pair = make_token_pair(auth, self._app_check_token)

        chunks: list[bytes] = []
        async for chunk in stream_audio(
            read_id=read_meta.read_id,
            voice_id=voice_id,
            token_pair=token_pair,
            device_id=self._device_id,
        ):
            if chunk.is_final:
                break
            chunks.append(chunk.audio)

        return concatenate_chunks(chunks)

    async def read_to_file(
        self,
        text: str,
        output_path: str,
        voice: str = DEFAULT_VOICE_ID,
    ) -> ReadMetadata:
        """Read text and save as MP3 file. Returns read metadata."""
        auth = await self._ensure_auth()
        voice_id = await resolve_voice(voice, auth)
        read_meta = await upload_text(text, auth)
        token_pair = make_token_pair(auth, self._app_check_token)

        chunks: list[bytes] = []
        async for chunk in stream_audio(
            read_id=read_meta.read_id,
            voice_id=voice_id,
            token_pair=token_pair,
            device_id=self._device_id,
        ):
            if chunk.is_final:
                break
            chunks.append(chunk.audio)

        mp3_data = concatenate_chunks(chunks)
        with open(output_path, "wb") as f:
            f.write(mp3_data)
        return read_meta
