def strip_id3v2(data: bytes) -> bytes:
    """Strip the ID3v2 header from MP3 data, returning raw MPEG frames.

    ID3v2 header structure:
    - Bytes 0-2: "ID3"
    - Byte 3: major version
    - Byte 4: revision
    - Byte 5: flags (bit 4 = footer present)
    - Bytes 6-9: size (synchsafe integer, 4x7 bits)
    """
    if len(data) < 10 or data[:3] != b"ID3":
        return data
    has_footer = (data[5] & 0x10) != 0
    size = (
        (data[6] << 21)
        | (data[7] << 14)
        | (data[8] << 7)
        | data[9]
    )
    total = 10 + size + (10 if has_footer else 0)
    return data[total:]


def concatenate_chunks(chunks: list[bytes]) -> bytes:
    """Concatenate MP3 chunks, keeping the first ID3v2 header and stripping the rest.

    MP3 is a streaming format — raw MPEG frames concatenate without re-encoding.
    """
    parts: list[bytes] = []
    for i, chunk in enumerate(chunks):
        # Keep the ID3 header from the first chunk only
        parts.append(chunk if i == 0 else strip_id3v2(chunk))
    return b"".join(parts)
