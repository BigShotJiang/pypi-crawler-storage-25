import base64
import json
import uuid
from collections.abc import AsyncIterator

import websockets

from elvenreader.config import WS_BASE
from elvenreader.types import Alignment, AudioChunk, TokenPair


class StreamError(Exception):
    pass


async def stream_audio(
    read_id: str,
    voice_id: str,
    token_pair: TokenPair,
    device_id: str,
    position: int = 0,
) -> AsyncIterator[AudioChunk]:
    """Connect to ElevenReader WebSocket and yield audio chunks as they arrive."""
    url = f"{WS_BASE}/reads/stream/v2/{read_id}?voice_id={voice_id}&device_id={device_id}"
    stream_id = str(uuid.uuid4())

    # [LAW:single-enforcer] Auth is encoded once here in the subprotocol list.
    subprotocols = [
        "reader",
        f"bearer.{token_pair.id_token}",
        f"app_check.{token_pair.app_check_token}",
    ]
    extra_headers = {
        "Origin": "https://elevenreader.io",
    }

    async with websockets.connect(
        url,
        subprotocols=subprotocols,
        additional_headers=extra_headers,
    ) as ws:
        init_msg = json.dumps({"position": position, "stream_id": stream_id})
        await ws.send(init_msg)

        async for raw_msg in ws:
            data = json.loads(raw_msg)

            audio_b64 = data.get("audio")
            audio_bytes = base64.b64decode(audio_b64) if audio_b64 else b""

            alignment_data = data.get("alignment")
            alignment = (
                Alignment(
                    chars=alignment_data["chars"],
                    char_start_times_ms=alignment_data["charStartTimesMs"],
                    char_durations_ms=alignment_data["charDurationsMs"],
                )
                if alignment_data
                else None
            )

            yield AudioChunk(
                stream_id=data.get("streamId", stream_id),
                audio=audio_bytes,
                alignment=alignment,
                is_final=data.get("isFinal", False),
            )
