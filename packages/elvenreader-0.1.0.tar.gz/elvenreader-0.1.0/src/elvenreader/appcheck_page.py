"""Obtain an App Check token via Tampermonkey script + local receiver server.

Flow:
1. User installs a Tampermonkey script (one-time) that runs on elevenreader.io
2. CLI starts a local HTTP server on a fixed port
3. User opens elevenreader.io and plays any read (triggering a WebSocket)
4. The script intercepts the App Check token from the WebSocket subprotocol
5. Script POSTs the token to our local server via GM_xmlhttpRequest
6. Server stores the token in Keychain and shuts down
"""

import http.server
import json
import threading

RECEIVER_PORT = 18329

_TOKEN_RESULT: str | None = None

TAMPERMONKEY_SCRIPT = """\
// ==UserScript==
// @name         elvenreader App Check Token Extractor
// @namespace    elvenreader
// @version      1.0
// @description  Extracts Firebase App Check token for elvenreader CLI
// @match        https://elevenreader.io/*
// @grant        GM_xmlhttpRequest
// @connect      127.0.0.1
// @run-at       document-start
// ==/UserScript==

(function() {
    'use strict';

    // Use unsafeWindow to patch the *page's* WebSocket, not the
    // Tampermonkey sandbox's copy. Without this, the page never sees our patch.
    const pageWindow = (typeof unsafeWindow !== 'undefined') ? unsafeWindow : window;

    console.log('[elvenreader] Patching WebSocket on page window...');

    const OrigWebSocket = pageWindow.WebSocket;
    const patched = function WebSocket(url, protocols) {
        console.log('[elvenreader] WebSocket created:', url);
        console.log('[elvenreader] protocols:', JSON.stringify(protocols));
        if (protocols && Array.isArray(protocols)) {
            for (let i = 0; i < protocols.length; i++) {
                if (protocols[i].startsWith('app_check.')) {
                    console.log('[elvenreader] Found app_check token, sending...');
                    sendToken(protocols[i].slice(10));
                    break;
                }
            }
        }
        if (protocols !== undefined) {
            return new OrigWebSocket(url, protocols);
        }
        return new OrigWebSocket(url);
    };
    patched.prototype = OrigWebSocket.prototype;
    patched.CONNECTING = 0;
    patched.OPEN = 1;
    patched.CLOSING = 2;
    patched.CLOSED = 3;
    pageWindow.WebSocket = patched;

    function sendToken(token) {
        console.log('[elvenreader] Sending token to CLI (' + token.length + ' chars)...');
        GM_xmlhttpRequest({
            method: 'POST',
            url: 'http://127.0.0.1:""" + str(RECEIVER_PORT) + """/token',
            headers: { 'Content-Type': 'application/json' },
            data: JSON.stringify({ token: token }),
            onload: function(resp) {
                console.log('[elvenreader] Token sent successfully, status:', resp.status);
            },
            onerror: function(err) {
                console.log('[elvenreader] Failed to send token:', JSON.stringify(err));
            }
        });
    }
})();
"""


class _Handler(http.server.BaseHTTPRequestHandler):
    def do_POST(self) -> None:
        global _TOKEN_RESULT
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length))
        _TOKEN_RESULT = body["token"]
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(b'{"ok":true}')
        threading.Thread(target=self.server.shutdown, daemon=True).start()

    def do_OPTIONS(self) -> None:
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def log_message(self, format: str, *args: object) -> None:
        pass


def wait_for_app_check_token() -> str:
    """Start the local receiver server and block until the token arrives."""
    global _TOKEN_RESULT
    _TOKEN_RESULT = None

    server = http.server.HTTPServer(("127.0.0.1", RECEIVER_PORT), _Handler)
    server.serve_forever()
    server.server_close()

    if _TOKEN_RESULT is None:
        raise RuntimeError("Failed to obtain App Check token")
    return _TOKEN_RESULT
