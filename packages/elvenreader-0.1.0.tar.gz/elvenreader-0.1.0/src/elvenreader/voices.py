import base64

from elvenreader.http import client

from elvenreader.config import API_BASE
from elvenreader.types import AuthState


class VoiceError(Exception):
    pass


async def list_voices(auth_state: AuthState) -> list[dict]:
    """Fetch available reader voices."""
    headers = {
        "Authorization": f"Bearer {auth_state.id_token}",
        "Origin": "https://elevenreader.io",
        "Referer": "https://elevenreader.io/",
    }
    async with client() as http:
        resp = await http.get(
            f"{API_BASE}/voices", headers=headers, timeout=10.0,
        )
    if resp.status_code != 200:
        raise VoiceError(f"Failed to list voices ({resp.status_code}): {resp.text}")
    return resp.json()["voices"]


async def resolve_voice(voice_input: str, auth_state: AuthState) -> str:
    """Resolve a voice name or ID to a voice ID.

    Accepts:
    - A voice ID (returned as-is if it looks like one)
    - A voice name like "Brian" or "george" (case-insensitive prefix match)
    """
    # If it looks like a voice ID (mix of upper/lower/digits, 20+ chars), use directly
    if len(voice_input) >= 20 and voice_input.isalnum():
        return voice_input

    voices = await list_voices(auth_state)
    query = voice_input.lower()

    # Exact match on first name (the part before " - ")
    for v in voices:
        first_name = v["name"].split(" - ")[0].strip().lower()
        if first_name == query:
            return v["voice_id"]

    # Prefix match
    matches = []
    for v in voices:
        if v["name"].lower().startswith(query):
            matches.append(v)

    if len(matches) == 1:
        return matches[0]["voice_id"]
    if len(matches) > 1:
        names = ", ".join(m["name"].split(" - ")[0] for m in matches)
        raise VoiceError(f"Ambiguous voice '{voice_input}', matches: {names}")

    # Substring match as last resort
    for v in voices:
        if query in v["name"].lower():
            return v["voice_id"]

    available = "\n".join(f"  {v['name'].split(' - ')[0]:20s} {v['voice_id']}" for v in voices)
    raise VoiceError(f"Voice '{voice_input}' not found. Available:\n{available}")


async def create_previews(
    description: str, auth_state: AuthState, app_check_token: str,
) -> list[dict]:
    """Generate voice previews from a text description.

    Returns a list of previews, each with 'generated_voice_id' and 'audio' (raw MP3 bytes).
    """
    headers = {
        "Authorization": f"Bearer {auth_state.id_token}",
        "Origin": "https://elevenreader.io",
        "Referer": "https://elevenreader.io/",
        "xi-app-check-token": app_check_token,
    }
    async with client() as http:
        resp = await http.post(
            f"{API_BASE}/voices/voice-design/create-previews",
            headers=headers,
            json={"voice_description": description},
            timeout=30.0,
        )
    if resp.status_code != 200:
        raise VoiceError(f"Preview generation failed ({resp.status_code}): {resp.text}")
    data = resp.json()
    previews = []
    for p in data["previews"]:
        previews.append({
            "generated_voice_id": p["generated_voice_id"],
            "audio": base64.b64decode(p["audio_base_64"]),
        })
    return previews


async def save_voice_from_preview(
    generated_voice_id: str,
    voice_name: str,
    description: str,
    auth_state: AuthState,
    app_check_token: str,
) -> dict:
    """Save a generated preview as a permanent voice.

    Returns {'voice_id': ..., 'name': ...}.
    """
    headers = {
        "Authorization": f"Bearer {auth_state.id_token}",
        "Origin": "https://elevenreader.io",
        "Referer": "https://elevenreader.io/",
        "xi-app-check-token": app_check_token,
    }
    async with client() as http:
        resp = await http.post(
            f"{API_BASE}/voices/voice-design/create-voice-from-preview",
            headers=headers,
            json={
                "generated_voice_id": generated_voice_id,
                "voice_name": voice_name,
                "voice_description": description,
            },
            timeout=15.0,
        )
    if resp.status_code != 200:
        raise VoiceError(f"Voice save failed ({resp.status_code}): {resp.text}")
    return resp.json()
