from elvenreader.http import client

from elvenreader.config import API_BASE
from elvenreader.types import AuthState, Chapter, ReadMetadata


class ReadsError(Exception):
    pass


async def upload_text(text: str, auth_state: AuthState) -> ReadMetadata:
    """Upload text content to ElevenReader and get a read_id back."""
    headers = {
        "Authorization": f"Bearer {auth_state.id_token}",
        "Origin": "https://elevenreader.io",
        "Referer": "https://elevenreader.io/",
    }
    files = {
        "from_document": ("document.txt", text.encode("utf-8"), "text/plain"),
    }
    async with client() as http:
        resp = await http.post(
            f"{API_BASE}/reads/add/v2",
            headers=headers,
            files=files,
            timeout=30.0,
        )
    if resp.status_code != 200:
        raise ReadsError(f"Upload failed ({resp.status_code}): {resp.text}")
    data = resp.json()
    chapters = [
        Chapter(
            chapter_name=ch["chapter_name"],
            word_count=ch["word_count"],
            char_count=ch["char_count"],
            starting_char_offset=ch["starting_char_offset"],
        )
        for ch in data.get("chapters", [])
    ]
    return ReadMetadata(
        read_id=data["read_id"],
        word_count=data["word_count"],
        char_count=data["char_count"],
        title=data.get("title", ""),
        chapters=chapters,
    )


async def update_position(
    read_id: str, char_offset: int, auth_state: AuthState
) -> None:
    """Update the last-listened position for a read."""
    headers = {
        "Authorization": f"Bearer {auth_state.id_token}",
        "Content-Type": "application/json",
        "Origin": "https://elevenreader.io",
        "Referer": "https://elevenreader.io/",
    }
    # read_id contains "u:" which needs to stay as-is — httpx handles URL encoding
    async with client() as http:
        resp = await http.patch(
            f"{API_BASE}/reads/{read_id}",
            headers=headers,
            json={"last_listened_char_offset": char_offset},
            timeout=10.0,
        )
    if resp.status_code != 200:
        raise ReadsError(f"Position update failed ({resp.status_code}): {resp.text}")
