import json
import uuid

import keyring

from elvenreader.config import KEYCHAIN_SERVICE
from elvenreader.types import StoredCredentials


def save_credentials(
    email: str,
    refresh_token: str,
    device_id: str = "",
    app_check_token: str = "",
) -> StoredCredentials:
    device_id = device_id or str(uuid.uuid4())
    creds = StoredCredentials(
        email=email,
        refresh_token=refresh_token,
        device_id=device_id,
        app_check_token=app_check_token,
    )
    keyring.set_password(KEYCHAIN_SERVICE, "credentials", json.dumps({
        "email": creds.email,
        "refresh_token": creds.refresh_token,
        "device_id": creds.device_id,
        "app_check_token": creds.app_check_token,
    }))
    return creds


def load_credentials() -> StoredCredentials:
    raw = keyring.get_password(KEYCHAIN_SERVICE, "credentials")
    if raw is None:
        raise CredentialsNotFound("No credentials found. Run 'elvenreader login' first.")
    data = json.loads(raw)
    return StoredCredentials(
        email=data["email"],
        refresh_token=data["refresh_token"],
        device_id=data["device_id"],
        app_check_token=data.get("app_check_token", ""),
    )


def save_app_check_token(token: str) -> None:
    creds = load_credentials()
    save_credentials(
        email=creds.email,
        refresh_token=creds.refresh_token,
        device_id=creds.device_id,
        app_check_token=token,
    )


class CredentialsNotFound(Exception):
    pass
