from dataclasses import dataclass, field


@dataclass(frozen=True)
class AuthState:
    id_token: str
    refresh_token: str
    expires_at: float  # time.time() epoch


@dataclass(frozen=True)
class AppCheckState:
    token: str
    expires_at: float  # time.time() epoch


@dataclass(frozen=True)
class TokenPair:
    id_token: str
    app_check_token: str


@dataclass(frozen=True)
class StoredCredentials:
    email: str
    refresh_token: str
    device_id: str
    app_check_token: str = ""


@dataclass(frozen=True)
class Chapter:
    chapter_name: str
    word_count: int
    char_count: int
    starting_char_offset: int


@dataclass(frozen=True)
class ReadMetadata:
    read_id: str
    word_count: int
    char_count: int
    title: str
    chapters: list[Chapter] = field(default_factory=list)


@dataclass(frozen=True)
class Alignment:
    chars: list[str]
    char_start_times_ms: list[int]
    char_durations_ms: list[int]


@dataclass(frozen=True)
class AudioChunk:
    stream_id: str
    audio: bytes  # raw MP3 bytes (already base64-decoded)
    alignment: Alignment | None
    is_final: bool
