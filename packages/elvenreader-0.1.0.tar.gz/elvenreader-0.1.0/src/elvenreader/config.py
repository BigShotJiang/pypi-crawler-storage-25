# [LAW:one-source-of-truth] All Firebase/API constants live here and nowhere else.

FIREBASE_API_KEY = "AIzaSyDSJy4Xs8dz8NNlAImw1CKWbWl23JTf-F0"
FIREBASE_APP_ID = "1:265222077342:web:e4f2a367417210e770348f"
FIREBASE_AUTH_DOMAIN = "elevenlabs.io"
FIREBASE_PROJECT_ID = "xi-labs"
FIREBASE_PROJECT_NUMBER = "265222077342"

RECAPTCHA_SITE_KEY = "6LdMZxErAAAAAGr4EuzdVw5SKpptLALUk1MIHKJU"

API_BASE = "https://api.elevenlabs.io/v1/reader"
WS_BASE = "wss://api.elevenlabs.io/v1/reader"

FIREBASE_SIGN_IN_URL = (
    f"https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword"
    f"?key={FIREBASE_API_KEY}"
)
FIREBASE_REFRESH_URL = (
    f"https://securetoken.googleapis.com/v1/token"
    f"?key={FIREBASE_API_KEY}"
)

DEFAULT_VOICE_ID = "nPczCjzI2devNBz1zQrb"

KEYCHAIN_SERVICE = "elvenreader"
