import asyncio
import sys

import click

pass  # imports are deferred to commands


@click.group()
def main() -> None:
    """CLI for the ElevenReader TTS API (elvenreader)."""


@main.command()
def login() -> None:
    """Authenticate with ElevenReader (Firebase email/password)."""
    from elvenreader.auth import sign_in
    from elvenreader.credentials import save_credentials

    email = click.prompt("Email")
    password = click.prompt("Password", hide_input=True)

    click.echo("Signing in...")
    auth_state = asyncio.run(sign_in(email, password))
    save_credentials(
        email=email,
        refresh_token=auth_state.refresh_token,
    )
    click.echo(f"Logged in as {email}. Credentials stored in Keychain.")


@main.command("app-check")
@click.option("--show-script", is_flag=True, help="Print the Tampermonkey script and exit")
def app_check(show_script: bool) -> None:
    """Obtain an App Check token via Tampermonkey userscript.

    First run: use --show-script to get the Tampermonkey script to install.
    Then: run this command, open elevenreader.io, and play any read.
    The token is captured automatically from the WebSocket connection.
    """
    from elvenreader.appcheck_page import TAMPERMONKEY_SCRIPT, wait_for_app_check_token, RECEIVER_PORT
    from elvenreader.credentials import save_app_check_token

    if show_script:
        click.echo(TAMPERMONKEY_SCRIPT)
        return

    click.echo(f"Listening on 127.0.0.1:{RECEIVER_PORT} for App Check token...")
    click.echo("Open elevenreader.io and play any read. The Tampermonkey script")
    click.echo("will send the token automatically.")
    click.echo("(Install the script first with: elvenreader app-check --show-script)")
    click.echo()
    click.echo("Waiting...")
    token = wait_for_app_check_token()
    save_app_check_token(token)
    click.echo(f"App Check token stored ({len(token)} chars, ~7 day lifetime).")


@main.command()
def voices() -> None:
    """List available voices."""
    asyncio.run(_list_voices())


async def _list_voices() -> None:
    from elvenreader.auth import refresh_id_token
    from elvenreader.credentials import load_credentials
    from elvenreader.voices import list_voices

    creds = load_credentials()
    auth_state = await refresh_id_token(creds.refresh_token)
    voice_list = await list_voices(auth_state)
    for v in voice_list:
        name = v["name"].split(" - ")[0]
        desc = v["name"].split(" - ")[1] if " - " in v["name"] else ""
        gender = v.get("gender", "")
        click.echo(f"  {name:20s} {gender:8s} {desc}")


@main.command("create-voice")
@click.argument("description")
@click.option("--name", "-n", required=True, help="Name for the new voice")
def create_voice(description: str, name: str) -> None:
    """Design a new voice from a text description.

    Generates preview voices, lets you listen to each, then saves your pick.

    DESCRIPTION is a text prompt describing the voice characteristics, e.g.
    "warm British male, slightly raspy, authoritative storyteller"
    """
    asyncio.run(_create_voice_pipeline(description, name))


async def _create_voice_pipeline(description: str, voice_name: str) -> None:
    from elvenreader.auth import refresh_id_token
    from elvenreader.credentials import load_credentials
    from elvenreader.playback import StreamingPlayer
    from elvenreader.voices import create_previews, save_voice_from_preview

    creds = load_credentials()
    auth_state = await refresh_id_token(creds.refresh_token)

    click.echo(f"Generating voice previews...")
    previews = await create_previews(description, auth_state, creds.app_check_token)
    click.echo(f"Got {len(previews)} previews.\n")

    for i, preview in enumerate(previews):
        click.echo(f"Playing preview {i + 1}/{len(previews)} ({len(preview['audio']):,} bytes)...")
        player = StreamingPlayer()
        await player.feed(preview["audio"])
        await player.close()
        click.echo()

    choice = click.prompt(
        f"Which preview to save as '{voice_name}'? (1-{len(previews)}, or 0 to cancel)",
        type=int,
    )
    if choice == 0:
        click.echo("Cancelled.")
        return
    if choice < 1 or choice > len(previews):
        click.echo("Invalid choice.", err=True)
        return

    selected = previews[choice - 1]
    click.echo(f"Saving preview {choice} as '{voice_name}'...")
    result = await save_voice_from_preview(
        generated_voice_id=selected["generated_voice_id"],
        voice_name=voice_name,
        description=description,
        auth_state=auth_state,
        app_check_token=creds.app_check_token,
    )
    click.echo(f"Voice created: {result['name']} (ID: {result['voice_id']})")


@main.command()
@click.argument("text", required=False)
@click.option("--file", "-f", "file_path", type=click.Path(exists=True), help="Read text from file")
@click.option("--voice", "-v", default="brian", help="Voice name or ID (e.g. 'brian', 'george')")
@click.option("--output", "-o", type=click.Path(), help="Save MP3 to file")
@click.option("--play", "-p", is_flag=True, help="Stream audio playback via afplay")
def read(
    text: str | None,
    file_path: str | None,
    voice: str,
    output: str | None,
    play: bool,
) -> None:
    """Read text aloud using ElevenReader TTS.

    Provide TEXT as an argument or use --file to read from a file.
    Use --play for streaming playback, --output to save MP3, or both.
    """
    if text is None and file_path is None:
        click.echo("Error: provide TEXT argument or --file", err=True)
        sys.exit(1)
    if not play and output is None:
        click.echo("Error: specify --play and/or --output", err=True)
        sys.exit(1)

    content = text if text is not None else open(file_path).read()  # type: ignore[arg-type]
    asyncio.run(_read_pipeline(content, voice, output, play))


async def _read_pipeline(
    text: str,
    voice_id: str,
    output_path: str | None,
    play: bool,
) -> None:
    from elvenreader.audio import strip_id3v2
    from elvenreader.auth import get_valid_id_token, make_token_pair
    from elvenreader.credentials import load_credentials
    from elvenreader.auth import refresh_id_token
    from elvenreader.playback import StreamingPlayer
    from elvenreader.reads import upload_text
    from elvenreader.stream import stream_audio
    from elvenreader.voices import resolve_voice

    creds = load_credentials()
    click.echo("Refreshing auth token...")
    auth_state = await refresh_id_token(creds.refresh_token)
    auth_state = await get_valid_id_token(auth_state)
    token_pair = make_token_pair(auth_state, creds.app_check_token)

    voice_id = await resolve_voice(voice_id, auth_state)
    click.echo(f"Voice: {voice_id}")

    click.echo(f"Uploading text ({len(text)} chars)...")
    read_meta = await upload_text(text, auth_state)
    click.echo(f"Created read: {read_meta.read_id} ({read_meta.word_count} words)")

    player = StreamingPlayer() if play else None
    chunks: list[bytes] = []
    chunk_count = 0
    total_bytes = 0

    click.echo("Streaming audio...")
    async for audio_chunk in stream_audio(
        read_id=read_meta.read_id,
        voice_id=voice_id,
        token_pair=token_pair,
        device_id=creds.device_id,
    ):
        if audio_chunk.is_final:
            break

        chunk_count += 1
        total_bytes += len(audio_chunk.audio)
        click.echo(f"  chunk {chunk_count}: {len(audio_chunk.audio):,} bytes", nl=False)
        click.echo(f"  (total: {total_bytes:,})", nl=True)

        if player:
            await player.feed(audio_chunk.audio)

        if output_path is not None:
            # Strip ID3 from chunks after the first for clean concatenation
            raw = audio_chunk.audio if chunk_count == 1 else strip_id3v2(audio_chunk.audio)
            chunks.append(raw)

    if player:
        await player.close()
        click.echo("Playback finished.")

    if output_path is not None and chunks:
        mp3_data = b"".join(chunks)
        with open(output_path, "wb") as f:
            f.write(mp3_data)
        click.echo(f"Saved {len(mp3_data):,} bytes to {output_path}")
