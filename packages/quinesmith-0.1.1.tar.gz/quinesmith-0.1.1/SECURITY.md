# Security Policy

`quinesmith` is digital fire. It assists AI agents in editing source code that
generates source code. The blast radius of a compromised quine generator is the
blast radius of every emission downstream of it. The security posture must
match.

## Threat model

`quinesmith` is designed against three classes of adversary.

### 1. APT-class supply chain attacks

The package distribution itself is the attack surface. An attacker who can
publish a malicious version *as `quinesmith`* can compromise every downstream
quine system that depends on it.

**Mitigations:**

- **PyPI Trusted Publishing via GitHub OIDC.** No long-lived API tokens. A
  compromise of the maintainer's password does not yield publish capability.
- **Sigstore keyless signing.** Every release is signed against a verifiable
  X.509 certificate via Fulcio and logged in Rekor.
- **SLSA Level 3 build provenance.** Generated automatically by the trusted
  publishing flow. Consumers can verify the wheel was built from the claimed
  source commit.
- **PEP 740 attestations.** Published with every release.
- **CycloneDX SBOM.** Published with every release.
- **GitHub artifact attestations (in-toto).** Secondary provenance store.
- **Pinned GitHub Actions SHAs.** (codex hardening: replace `@tag` with
  `@sha` across every workflow.) Tag-mutation supply-chain attacks cannot
  drift through pinned SHAs.
- **Required signed commits, branch protection, code review** on the
  publishing branch.

### 2. AI-supply-chain attacks

This package is *for AI* to use during quine editing. AI agents themselves
are an attack vector class: a compromised, misaligned, or jailbroken agent
that can edit template code can corrupt the generator and propagate the
corruption through every emission.

**Mitigations:**

- **Boundary at the API.** `verify.prepare_commands(...)` returns a
  *string* the human operator runs. It does not execute. The protocol's
  safety boundary (§7.7, §8) is enforced at the Python API: agents prepare;
  humans run. Functions that would cross the boundary (e.g.,
  `verify.run_full_check`) intentionally do not exist. They are not
  omissions — they are refusals.
- **Pre-edit checklist as observable acknowledgement.** The
  `audit.pre_edit_checklist()` function returns *items* the agent must
  acknowledge having performed. Skipped acknowledgement is visible in the
  agent's transcript to the operator.
- **No side-effects at import.** Importing `quinesmith` does not run code,
  modify files, or open network connections. All primitives are
  deterministic and side-effect-free at module level.
- **Stop-and-audit predicate.** `should_stop(history)` (codex: implement)
  codifies the §11 stop conditions so an agent that crosses level
  boundaries it didn't recognize halts on its own behavior.

### 3. Operator error / accidental misuse

Quine systems have non-local failure modes: a brace miscount in a Level 1
template can produce a host-syntax-correct file that emits broken Level 0
code. The downstream failure surfaces far from the cause.

**Mitigations:**

- **Failure-mode taxonomy.** `quinesmith.failure_modes.FailureMode` names
  every known class so operators can diagnose precisely.
- **Pre-edit checklist** enforces context-window reading before edits.
- **Stop-and-audit conditions** (§11) are codified as a callable predicate.

## Reporting a vulnerability

Report security issues to the maintainer via GitHub Security Advisories:

> https://github.com/Yufok1/Quine-Forge/security/advisories/new

Please **do not** open public issues for vulnerabilities. Coordinated
disclosure window: 90 days from acknowledgement, unless mutually extended.

## Boundary statement

Per the Quine Template Edit Protocol §7.7 and §8:

> The agent must not run compilation, regeneration, or quine verification
> on its own initiative. The verification commands are for the human
> operator. The agent may prepare, explain, or restate them.

`quinesmith` enforces this boundary at the API level. Do not propose
patches that add `subprocess.run`, `os.system`, or equivalent execution
surfaces to the verification primitives. Such patches will be rejected as
boundary violations regardless of their utility argument.

## Provenance verification

Every release ships with multiple provenance surfaces:

- **PyPI / Sigstore attestation** (PEP 740)
- **GitHub artifact attestation** (in-toto)
- **SLSA Level 3 provenance** (automatic via trusted publishing)
- **CycloneDX SBOM**
- **`cascade-lattice` receipt** to the public provenance ledger

To verify a release:

```bash
# Sigstore / PyPI attestation, for releases published through the trusted
# GitHub workflow:
pip download --no-deps --no-binary :all: quinesmith==X.Y.Z
python -m sigstore verify identity \
    --bundle quinesmith-X.Y.Z.tar.gz.sigstore.json \
    --cert-identity 'https://github.com/Yufok1/Quine-Forge/.github/workflows/publish.yml@refs/tags/vX.Y.Z' \
    --cert-oidc-issuer https://token.actions.githubusercontent.com \
    quinesmith-X.Y.Z.tar.gz

# GitHub artifact attestation:
gh attestation verify quinesmith-X.Y.Z-py3-none-any.whl --owner Yufok1

# Cascade-lattice receipt:
# (codex: wire the cascade-lattice verification CLI here)
```

A release that fails any verification surface is not authoritative,
regardless of which surface fails. Treat as a supply-chain incident and
report via the security advisory channel above.

## Lineage

`quinesmith` is part of the Ouroboros ecosystem. Companion components:

- [`cascade-lattice`](https://pypi.org/project/cascade-lattice/) —
  composable provenance / audit primitives. Used here for the secondary
  provenance ledger.
- [`brotology-field-guide`](https://pypi.org/project/brotology-field-guide/) —
  operator contract for AI collaboration on living systems.
- [`Brotology-field-guide` (repo)](https://github.com/Yufok1/Brotology-field-guide) —
  doctrinal reference / source of truth.
