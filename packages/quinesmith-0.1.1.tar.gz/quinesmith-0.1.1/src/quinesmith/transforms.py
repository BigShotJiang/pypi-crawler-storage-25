"""Canonical template transformations from the Quine Template Edit Protocol."""

from __future__ import annotations

from enum import Enum


class Transform(str, Enum):
    """The nine Level-1 reference transformations from the protocol."""

    OPEN_BRACE = "open_brace"
    CLOSE_BRACE = "close_brace"
    VARIABLE_REFERENCE = "variable_reference"
    DICT_LITERAL = "dict_literal"
    TRIPLE_QUOTE = "triple_quote"
    NEWLINE_ESCAPE = "newline_escape"
    BACKSLASH = "backslash"
    FSTRING_LEVEL_1 = "fstring_level_1"
    FSTRING_LEVEL_2 = "fstring_level_2"


_LEVEL_1_WRITES: dict[Transform, str] = {
    Transform.OPEN_BRACE: "{{",
    Transform.CLOSE_BRACE: "}}",
    Transform.VARIABLE_REFERENCE: "{{variable}}",
    Transform.DICT_LITERAL: '{{"key": "val"}}',
    Transform.TRIPLE_QUOTE: '\\"\\"\\"',
    Transform.NEWLINE_ESCAPE: "\\\\n",
    Transform.BACKSLASH: "\\\\",
    Transform.FSTRING_LEVEL_1: 'f"{{x}}"',
    Transform.FSTRING_LEVEL_2: 'f"{{{{x}}}}"',
}


def template_write_for(transform: Transform | str) -> str:
    """Return what to write inside a Level-1 template for a known transform."""

    return _LEVEL_1_WRITES[Transform(transform)]
