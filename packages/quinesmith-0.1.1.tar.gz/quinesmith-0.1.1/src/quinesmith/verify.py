"""Verification command preparers.

CRITICAL BOUNDARY (Quine Template Edit Protocol §7.7, §8):

    The agent must not run compilation, regeneration, or quine verification
    on its own initiative. The verification commands are for the human
    operator. The agent may prepare, explain, or restate them.

This module enforces that boundary at the API. Functions return strings for
human invocation. There is no ``run()`` function. There will not be one.
Adding subprocess execution to this module is a boundary violation regardless
of utility argument and will be rejected at code review.
"""

from __future__ import annotations

from pathlib import Path


def prepare_commands(quine_file: str | Path) -> str:
    """Prepare the five verification commands as a copy-pasteable shell block.

    The OPERATOR runs these. The agent must not.

    The five commands are (in order):

    1. ``py_compile`` the quine source — host syntax still compiles.
    2. ``--verify-quine`` — self-hash still matches.
    3. ``--emit > regen.py`` — emission still produces valid output.
    4. ``py_compile regen.py`` — emitted file also compiles.
    5. ``diff source regen`` — emission is byte-identical (fixed-point property).

    A quine that no longer emits a byte-identical copy of itself has lost the
    fixed-point property and is no longer a quine.

    Args:
        quine_file: Path to the quine source file under verification.

    Returns:
        A shell block (newline-separated) the operator can paste into their
        terminal. One command per line.

    Examples:
        >>> print(prepare_commands("my_quine.py"))
        python -m py_compile my_quine.py
        python my_quine.py --verify-quine
        python my_quine.py --emit > regen.py
        python -m py_compile regen.py
        diff my_quine.py regen.py
    """
    p = str(quine_file)
    return "\n".join((
        f"python -m py_compile {p}",
        f"python {p} --verify-quine",
        f"python {p} --emit > regen.py",
        "python -m py_compile regen.py",
        f"diff {p} regen.py",
    ))


def explain_commands() -> str:
    """Return a human-readable explanation of what each verification command checks.

    For agent restating to operator, or for documentation surfaces. Carries
    no executable content.

    Returns:
        Multi-line string with one line per command, plus a closing note on
        the fixed-point property.
    """
    return "\n".join((
        "1. py_compile <quine>: host Python syntax still compiles",
        "2. <quine> --verify-quine: self-hash still matches (merkle / provenance check)",
        "3. <quine> --emit > regen: emission still produces valid output",
        "4. py_compile regen.py: emitted file also compiles",
        "5. diff <quine> regen: emission is byte-identical (fixed-point property)",
        "",
        "A quine that no longer emits a byte-identical copy of itself has lost",
        "the fixed-point property and is no longer a quine.",
    ))
