"""Level and brace-count primitives.

Per Quine Template Edit Protocol §2 and §3.

Levels:

- Level 0 — host Python (compiler source); ``{x}`` injects from host scope.
- Level 1 — template body inside ``f'''...'''``; ``{{x}}`` is a literal ``{x}``
  in the generated file.
- Level 2 — template inside a template; ``{{{{x}}}}`` is a literal ``{x}``
  in the output of the output.
- Level n — recursive nesting; the doubling rule applies.

The doubling rule:

    braces_required(level) == 2 ** level
"""

from __future__ import annotations

from enum import IntEnum


class Level(IntEnum):
    """Template nesting level.

    The doubling rule applies: ``braces_required = 2 ** level``.
    """

    HOST = 0
    """Host Python — the compiler source."""

    TEMPLATE = 1
    """Template body inside ``f'''...'''`` — code that will exist after generation."""

    NESTED = 2
    """Template inside a template — code that writes code."""


def braces_required(level: Level | int) -> int:
    """Return the brace count needed to represent a literal ``{x}`` at the given level.

    Args:
        level: Template nesting level (0 = host, 1 = template, 2 = nested, ...).

    Returns:
        Number of braces required on each side of the identifier.

    Raises:
        ValueError: If ``level`` is negative.

    Examples:
        >>> braces_required(Level.HOST)
        1
        >>> braces_required(Level.TEMPLATE)
        2
        >>> braces_required(Level.NESTED)
        4
        >>> braces_required(3)
        8
    """
    n = int(level)
    if n < 0:
        raise ValueError(f"level must be non-negative, got {n}")
    return 2 ** n
