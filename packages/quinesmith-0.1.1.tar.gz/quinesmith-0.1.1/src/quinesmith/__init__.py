"""quinesmith — Safe primitives for AI-assisted editing of quine/capsule templates.

This package provides the operational primitives that codify the
Quine Template Edit Protocol. It enforces the protocol's safety boundary
at the API level: agents prepare; operators run. Functions that would cross
the boundary (e.g., subprocess execution of verification commands)
intentionally do not exist.

See SECURITY.md for the threat model and boundary statement.
"""

from __future__ import annotations

__version__ = "0.1.1"

from quinesmith.failure_modes import FailureMode
from quinesmith.levels import Level, braces_required
from quinesmith.transforms import Transform, template_write_for

__all__ = (
    "FailureMode",
    "Level",
    "Transform",
    "__version__",
    "braces_required",
    "template_write_for",
)
