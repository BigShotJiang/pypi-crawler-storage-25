"""Quine template failure mode taxonomy.

Per Quine Template Edit Protocol §6 (Common Failures) and §10 (Failure Mode
Summary). Every known failure class is named here so operators can classify
and diagnose precisely.

Never compress failure classes. Compressing truth / contract / transport /
rendering / gating / stale-runtime-state into a single "broken" category is
the most common drift in quine debugging, and it always produces wrong
patches.
"""

from __future__ import annotations

from enum import Enum


class FailureMode(str, Enum):
    """Canonical failure classes for quine template edits.

    Each value names a distinct failure mode with a distinct fix. Do not
    treat these as interchangeable severity levels — they map to different
    seams in the producer / contract / transport / renderer chain.
    """

    HOST_SYNTAX_ERROR = "host_syntax_error"
    """Host Python won't compile — usually unescaped brace or quote at Level 1."""

    EMISSION_KEYERROR = "emission_keyerror"
    """Compiles, but emission crashes with KeyError because a literal ``{x}``
    reached the output where ``x`` was meant to interpolate."""

    OVER_DOUBLED_BRACES = "over_doubled_braces"
    """Compiles and emits, but the generated file contains a literal ``{x}``
    where a value was wanted."""

    LEVEL_2_ESCAPING_LOST = "level_2_escaping_lost"
    """Compiles and emits, but the regenerated file does not compile because
    a quadruple-brace was reduced to double during edit."""

    FIXED_POINT_BROKEN = "fixed_point_broken"
    """Compiles, emits, regen compiles, but ``diff(source, regen)`` is non-empty.
    Quine no longer self-identical."""

    HASH_VERIFY_FAILURE = "hash_verify_failure"
    """Compiles, emits, regen identical, but merkle/provenance hash mismatch.
    Provenance hook out of date."""

    COLLAPSED_BRACE = "collapsed_brace"
    """Braces eaten by the Level 1 compiler; should have been doubled.
    Symptom of `data = {"key": "value"}` written without doubling."""

    UNESCAPED_TRIPLE_QUOTE = "unescaped_triple_quote"
    """Triple-quote inside template body closes the f-string prematurely."""

    LEVEL_CONFUSION = "level_confusion"
    """f-string inside f-string with wrong escaping; host evaluates a name
    that was meant to remain in the generated file."""

    INJECTION_MISTAKE = "injection_mistake"
    """Doubled braces produced a literal where host-side interpolation was intended."""

    @classmethod
    def from_symptom(cls, symptom: str) -> FailureMode | None:
        """Classify a free-text symptom against the canonical taxonomy.

        This is intentionally narrow: it matches against canonical phrasing
        from the protocol's §10 table. For ambiguous symptoms it returns
        ``None`` so the operator classifies manually rather than the
        function over-confidently misclassifying.

        Args:
            symptom: Free-text description of observed behavior.

        Returns:
            Matched ``FailureMode``, or ``None`` if the symptom does not
            unambiguously match a known class.

        Examples:
            >>> FailureMode.from_symptom("SyntaxError on host compile")
            <FailureMode.HOST_SYNTAX_ERROR: 'host_syntax_error'>
            >>> FailureMode.from_symptom("compiles, emits, regen identical, hash verify fails")
            <FailureMode.HASH_VERIFY_FAILURE: 'hash_verify_failure'>
            >>> FailureMode.from_symptom("everything is broken")  # ambiguous
            >>> # returns None
        """
        s = symptom.lower()

        if "syntaxerror" in s and ("host" in s or "compile" in s):
            return cls.HOST_SYNTAX_ERROR
        if "keyerror" in s and ("emission" in s or "emits" in s):
            return cls.EMISSION_KEYERROR
        if "hash" in s and "verify" in s and ("fail" in s or "mismatch" in s):
            return cls.HASH_VERIFY_FAILURE
        if "regen does not compile" in s or ("regen" in s and "not compile" in s):
            return cls.LEVEL_2_ESCAPING_LOST
        if "diff non-empty" in s or "fixed-point" in s or "fixed point" in s:
            return cls.FIXED_POINT_BROKEN
        if ("literal" in s and "{x}" in s) or "where a value was wanted" in s:
            return cls.OVER_DOUBLED_BRACES
        return None
