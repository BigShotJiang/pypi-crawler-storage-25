"""Audit checklist primitives for quine-template edits."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class ChecklistItem:
    """An observable audit item an agent can acknowledge in its transcript."""

    key: str
    text: str


def pre_edit_checklist() -> tuple[ChecklistItem, ...]:
    """Return the protocol's required pre-edit checklist."""

    return (
        ChecklistItem("read_context", "Read the 50 lines above and below the edit site."),
        ChecklistItem("identify_level", "Identify the template level of the edit site."),
        ChecklistItem("classify_braces", "Classify every brace in the edit window."),
        ChecklistItem("preserve_unknown", "Do not modify any brace pattern you do not understand."),
        ChecklistItem("minimal_change", "Confirm the edit is the minimum change that achieves intent."),
        ChecklistItem("prepare_verification", "Prepare verification commands for the human operator."),
        ChecklistItem("respect_boundary", "Do not run compilation, regeneration, or quine verification."),
    )


def should_stop(events: Iterable[str]) -> bool:
    """Return True when the protocol says to stop and audit.

    The predicate is intentionally conservative and text-based so it can be
    used with transcripts, tool logs, or hand-authored event notes.
    """

    joined = "\n".join(str(event).lower() for event in events)
    if "three consecutive failed compile" in joined:
        return True
    if "unknown brace pattern" in joined or "does not match any of the nine" in joined:
        return True
    if "differs from the source by more than the edited region" in joined:
        return True
    return "--verify-quine" in joined and ("fails" in joined or "failed" in joined)
