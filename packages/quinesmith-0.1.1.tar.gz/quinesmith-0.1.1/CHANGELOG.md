# Changelog

## 0.1.1 - 2026-04-29

- Fixed PyPI README links so security and protocol surfaces resolve to GitHub.
- Added a Protocol project URL in package metadata.
- Clarified that `docs/protocol.md` is bundled in the source distribution,
  while PyPI project pages link to the GitHub-rendered document.

## 0.1.0 - 2026-04-29

- Initial PyPI release of `quinesmith`.
- Added level and brace-count primitives.
- Added quine-template failure taxonomy.
- Added Level-1 transformation registry.
- Added audit checklist and stop-and-audit predicate.
- Added verification command preparers that preserve the operator-run boundary.
