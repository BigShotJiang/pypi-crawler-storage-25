# Changelog

All notable changes to the `superpenguin` Python SDK are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and the project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.2] — 2026-04-20

### Changed

- **Pricing data is now loaded from the unified `pricing/models.json`** source of truth at the cost-management monorepo root, replacing the hand-maintained `_MODEL_PRICING` dict that lived in `_pricing.py`. The dashboard server (`src/lib/pricing.ts`) loads the same file, so the SDK and dashboard can no longer drift on model rates.
  - Wheels and sdists ship a bundled copy at `superpenguin/data/models.json` (built by a custom hatch hook). Editable installs (`pip install -e .`) skip the staging step and the runtime loader walks up to find the live monorepo copy, so local edits to `pricing/models.json` are picked up immediately without a reinstall.
  - The schema is **versioned by effective date**: every model has a `rate_cards` array with `effective_from` (and optional `effective_until`) timestamps. Future provider price changes append a new card instead of mutating the old one, so historical `provider_usage_records` rows can re-cost themselves against the rate that was actually in effect when the request happened. See `pricing/README.md` for the runbooks.
- **Cache-rate convention: NO heuristic fallback.** When a model entry omits `cache_read` (or any other rate leg), the calculator now resolves it to **0** rather than using the previous `input_rate × 0.5` heuristic. The heuristic was wrong for several OpenAI models — e.g. `gpt-4.1`'s actual cached_input is $0.50/1M but the heuristic produced $1.00/1M, silently inflating cost reports for cache-heavy workloads. Every model that supports caching now records an explicit `cache_read`; models that do not (the OpenAI Pro family) record `null`.

### Added

- **`as_of: datetime | None`** keyword-only parameter on `calculate_cost_micros` to select the rate card in effect at a given timestamp. Omit (default) to use the current (latest) card. Naive datetimes are treated as UTC.
- **`gemini-2.5-flash` updated to Google's stable unified rate.** Google retired the preview-period thinking-disabled vs thinking-enabled rate split in June 2025 and unified at $0.30 input / $2.50 output / $0.03 cache_read per 1M regardless of reasoning mode. The previous SDK encoded the (now-defunct) thinking-disabled preview rates as the default, undercharging input by 2x and output by ~4x for every gemini-2.5-flash row issued after June 2025. The `rate_variants.thinking` field has been removed since the distinction no longer exists. Verified against `https://ai.google.dev/gemini-api/docs/pricing` on 2026-04-20.
- **OpenAI GPT-5 family completed.** Five models that were missing from the previous table are now included, all verified against `https://platform.openai.com/docs/pricing` on 2026-04-20:
  - `gpt-5.4-pro` — input $30 / output $180 per 1M (≤272K), $60 / $270 (>272K). No prompt caching offered.
  - `gpt-5.2` — input $1.75 / cached $0.175 / output $14 per 1M.
  - `gpt-5.2-pro` — input $21 / output $168 per 1M. No prompt caching offered.
  - `gpt-5.1` — input $1.25 / cached $0.125 / output $10 per 1M (same published rates as `gpt-5`, distinct API id).
  - `gpt-5-pro` — input $15 / output $120 per 1M. No prompt caching offered.
- **`gpt-5.4` long-context tiering.** Added `tier_threshold: { field: "input_tokens", value: 272000 }` with `[low, high]` rate arrays so the calculator picks the correct rate when a single request exceeds 272K input tokens. Low tier matches the previous flat values ($2.50 / $0.25 / $15 per 1M); high tier is $5.00 / $0.50 / $22.50 per 1M.

### Fixed

- **`_normalize_model` no longer over-strips `text-embedding-ada-002`.** The version-pin regex (`-\d{3}$`, intended for Vertex AI suffixes like `gemini-2.0-flash-001`) was greedily turning `text-embedding-ada-002` into `text-embedding-ada` and dropping the cost calculation to $0. The normalizer now tries progressively-aggressive suffix strips and returns the first candidate that resolves to a known model. Behavior for previously-handled models (e.g. `gemini-2.0-flash-001 → gemini-2.0-flash`) is unchanged.
- **`gemini-2.5-flash` rate (re)corrected to Google's stable unified rate.** An interim version of the unified pricing migration encoded the preview-period thinking-disabled rates as the default ($0.15 input / $0.60 output). Both the preview thinking-disabled AND preview thinking-enabled tiers were retired by Google in June 2025 in favor of a single unified $0.30 / $2.50 / $0.03 per 1M rate that applies regardless of reasoning mode. The 0.2.2 release ships with the unified rate.
- **Cached-input rates corrected for several OpenAI models** that previously fell through to the (wrong) `input_rate × 0.5` heuristic. Any caller passing `cached_tokens > 0` for these models was being over-charged on the cached portion. Net direction: cache-heavy workloads on these models will now report **lower** cost going forward.
  - `gpt-4.1`: heuristic $1.00 → actual **$0.50** per 1M
  - `gpt-4.1-mini`: heuristic $0.20 → actual **$0.10** per 1M
  - `gpt-4.1-nano`: heuristic $0.05 → actual **$0.025** per 1M
  - `o3`: heuristic $1.00 → actual **$0.50** per 1M
  - `o4-mini`: heuristic $0.55 → actual **$0.275** per 1M
  - (`gpt-4o` and `gpt-4o-mini` heuristic happened to coincide with OpenAI's published rate, so values are unchanged but `cache_read` is now explicit.)

### Notes

- The SDK's public API is unchanged; only the internal pricing-data loading mechanism moved. `_MODEL_PRICING`, `_MODEL_ALIASES`, `_warned_unknown_models`, `_normalize_model`, and `calculate_cost_micros` remain importable with their existing shapes (the legacy `_MODEL_PRICING` dict is now built at import time from `pricing/models.json`).
- `gemini-2.0-pro` was removed from the table — it was never published by Google (Gemini 2.0 launched as Flash-only) and the previous server-only entry was almost certainly erroneous. If real usage rows reference it, the existing unknown-model Slack alert will fire.

## [0.2.1] — 2026-04-20

### Added

- **Pricing entries for OpenAI embedding models** (input-only, no completion tokens, no caching). Source: https://platform.openai.com/docs/pricing#embeddings (verified 2026-04-20):
  - `text-embedding-3-small` — $0.02 / 1M tokens
  - `text-embedding-3-large` — $0.13 / 1M tokens
  - `text-embedding-ada-002` — $0.10 / 1M tokens
- **Pricing entries for OpenAI transcription models** — pre-positioned for symmetry with the dashboard's pricing table and to prevent future silent regressions when transcribe wrapping is added. Source: https://platform.openai.com/docs/pricing#transcription (verified 2026-04-20):
  - `gpt-4o-transcribe` — input $2.50 / output $10.00 per 1M tokens
  - `gpt-4o-mini-transcribe` — input $1.25 / output $5.00 per 1M tokens

### Notes

- `sp.wrap()` already patches the OpenAI `embeddings` resource (since 0.1.0). Before this release, embedding calls flowed through to the dashboard with `cost_usd_micros = 0`, which silently zeroed embedding spend on per-customer / per-feature breakdowns and triggered an "unknown model pricing" Slack alert via the dashboard's ingest route. After upgrading, embedding calls report cost correctly inline.
- Audio transcription is NOT yet wrapped by `sp.wrap()` — `_OPENAI_RESOURCES` does not include `audio.transcriptions`, so a transcribe call passes straight through and never reaches the SDK pipeline. Transcribe spend continues to flow exclusively via the OpenAI billing-API sync. The transcribe rates are added now so that whenever transcribe wrapping ships, the cost calculation is already correct on day one.
- Note that transcribe rates are very different from the chat-completion `gpt-4o` / `gpt-4o-mini` SKUs ($2.50/$10.00 vs $2.50/$10.00 for the full size — same coincidentally — but $1.25/$5.00 vs $0.15/$0.60 for mini, an ~8× difference). Don't collapse `-transcribe` via model normalization or aliasing.

## [0.2.0] — 2026-04-18

### Added

- **Google Gemini support** via the unified [`google-genai`](https://github.com/googleapis/python-genai) client (works against both AI Studio and Vertex AI).
  - `sp.wrap(genai.Client(...))` patches `client.models.generate_content`, `generate_content_stream`, and their async equivalents under `client.aio.models.*`.
  - Token counts, cached tokens, latency, tool-call detection, and `model_version` are extracted from both single-shot and streaming responses.
  - New `[google]` install extra: `pip install "superpenguin[google]"`.
- **Pricing table for Gemini text models** (Standard tier, verified against `https://ai.google.dev/gemini-api/docs/pricing` on 2026-04-16):
  - `gemini-3.1-pro-preview` (tiered at 200k input tokens)
  - `gemini-3.1-flash-lite-preview`
  - `gemini-3-flash-preview`
  - `gemini-2.5-pro` (tiered at 200k input tokens), `gemini-2.5-flash`, `gemini-2.5-flash-lite`
  - `gemini-2.0-flash`, `gemini-2.0-flash-lite`
- **Tiered pricing engine**: per-rate `[low, high]` lists paired with `tier_threshold` (in input tokens) so Gemini Pro SKUs bill the right rate above/below the long-context threshold.
- **Model alias map** (`_MODEL_ALIASES`) so stable names like `gemini-3.1-pro` resolve to the canonical `-preview` SKU.
- **Smarter model normalization**: in addition to ISO date suffixes (`-2025-09-15`, `-20250915`), the SDK now strips Google month-year suffixes (`-09-2025`) and Vertex version pins (`-001`, `-002`) before pricing lookup.
- `gemini` and `google` added to the package keyword list.

### Notes

- Audio and image input modalities for Gemini are billed separately by Google. The SDK currently tracks the text rate only — audio-heavy workloads will be under-counted by the SDK estimator (provider-side billing is unaffected).
- Batch / Flex / Priority Gemini tiers are not yet modeled; pricing assumes the paid Standard tier.

## [0.1.0] — 2026-04-11

Initial public release.

### Added

- `sp.init()`, `sp.wrap()`, `sp.flush()`, and the `@sp.trace` decorator.
- OpenAI client support (`chat.completions`, `completions`, `embeddings`, `responses`), including streaming.
- Anthropic client support (`messages`), including streaming.
- LiteLLM patching via `sp.patch_litellm()`.
- Background batched HTTP submission to `https://api.carrotlabs.ai/api/sdk/ingest` with `atexit` flush.
- Per-call attribution metadata (`customer_id`, `feature`, `team`, `environment`, `prompt_key`, `prompt_version`, plus arbitrary string custom tags).
