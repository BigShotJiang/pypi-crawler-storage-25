"""Unit tests for the pricing table, model normalization, and cost math."""

from __future__ import annotations

from datetime import datetime, timezone

import pytest

from superpenguin._pricing import (
    _MODEL_ALIASES,
    _MODEL_PRICING,
    _PRICING_DATA,
    _normalize_model,
    calculate_cost_micros,
)


# ---------------------------------------------------------------------------
# _normalize_model
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    "raw, expected",
    [
        ("gpt-4o", "gpt-4o"),
        ("openai/gpt-4o", "gpt-4o"),
        ("openai/gpt-5-mini-2025-09-15", "gpt-5-mini"),
        ("models/gemini-2.5-pro", "gemini-2.5-pro"),
        ("gemini-2.5-flash-lite-preview-09-2025", "gemini-2.5-flash-lite-preview"),
        ("gemini-2.0-flash-001", "gemini-2.0-flash"),
        ("gemini-3.1-pro", "gemini-3.1-pro-preview"),
        ("gemini-3.1-pro-preview", "gemini-3.1-pro-preview"),
        ("gemini-3-flash", "gemini-3-flash-preview"),
        ("gemini-3.1-flash-lite", "gemini-3.1-flash-lite-preview"),
        ("claude-sonnet-4-5-20250915", "claude-sonnet-4-5"),
    ],
)
def test_normalize_model(raw: str, expected: str) -> None:
    assert _normalize_model(raw) == expected


# ---------------------------------------------------------------------------
# Tiered pricing — Gemini 2.5 Pro and 3.1 Pro
# ---------------------------------------------------------------------------


def test_gemini_2_5_pro_low_tier() -> None:
    # 100K input (≤200K), 1K output:
    #   input  100_000 * 1.25 / 1M = 0.125
    #   output   1_000 * 10.0 / 1M = 0.01
    #   total = 0.135 USD = 135_000 micros
    assert calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000) == 135_000


def test_gemini_2_5_pro_high_tier() -> None:
    # 300K input (>200K), 1K output:
    #   input  300_000 * 2.50 / 1M = 0.75
    #   output   1_000 * 15.0 / 1M = 0.015
    #   total = 0.765 USD
    assert calculate_cost_micros("gemini-2.5-pro", 300_000, 1_000) == 765_000


def test_gemini_3_1_pro_low_tier() -> None:
    # 100K input ≤200K: input 0.20 + output 0.012 = 0.212 USD
    assert calculate_cost_micros("gemini-3.1-pro", 100_000, 1_000) == 212_000


def test_gemini_3_1_pro_high_tier() -> None:
    # 300K input >200K: input 1.20 + output 0.018 = 1.218 USD
    assert calculate_cost_micros("gemini-3.1-pro", 300_000, 1_000) == 1_218_000


def test_gemini_3_1_pro_tier_threshold_boundary() -> None:
    # Exactly at threshold (200_000) should still use the LOW tier.
    # 200_000 * 2.0 / 1M = 0.40, output 0.012 = 0.412 USD
    assert calculate_cost_micros("gemini-3.1-pro", 200_000, 1_000) == 412_000
    # One token over → high tier.
    # 200_001 * 4.0 / 1M = 0.800004, output 0.018 = 0.818004 USD → 818_004 micros
    assert calculate_cost_micros("gemini-3.1-pro", 200_001, 1_000) == 818_004


# ---------------------------------------------------------------------------
# Cache pricing for Gemini
# ---------------------------------------------------------------------------


def test_gemini_2_5_pro_cache_uses_official_rate() -> None:
    # 100K input total, 50K of which are cached, 1K output (low tier):
    #   uncached input 50_000 * 1.25 / 1M = 0.0625
    #   cache read     50_000 * 0.125 / 1M = 0.00625
    #   output          1_000 * 10.0  / 1M = 0.01
    #   total = 0.07875 USD = 78_750 micros
    assert calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000, 50_000) == 78_750


def test_gemini_3_1_pro_cache_high_tier() -> None:
    # 300K input total, 100K cached, 1K output (high tier):
    #   uncached input 200_000 * 4.0 / 1M = 0.80
    #   cache read     100_000 * 0.40 / 1M = 0.04
    #   output           1_000 * 18.0 / 1M = 0.018
    #   total = 0.858 USD
    assert calculate_cost_micros("gemini-3.1-pro", 300_000, 1_000, 100_000) == 858_000


def test_gemini_2_5_flash_unified_stable_rate() -> None:
    # Google unified gemini-2.5-flash pricing in the June 2025 stable release:
    # the previous preview-period split between thinking-disabled ($0.15 input /
    # $0.60 output / $0.0375 cache) and thinking-enabled ($0.30 / $2.50 / $0.03)
    # rates was retired. As of 2026-04-20 the published rate is unified at
    #   input $0.30, output $2.50, cache_read $0.03 per 1M
    # regardless of whether reasoning is enabled. Verified against
    # ai.google.dev/gemini-api/docs/pricing on 2026-04-20.
    #
    # 1M input + 1K output:
    #   input  1_000_000 * 0.30 / 1M = 0.300000
    #   output     1_000 * 2.50 / 1M = 0.002500
    #   total = 0.302500 USD = 302_500 micros
    assert calculate_cost_micros("gemini-2.5-flash", 1_000_000, 1_000) == 302_500


# ---------------------------------------------------------------------------
# Regression — non-Gemini models still work
# ---------------------------------------------------------------------------


def test_gpt_4o_regression() -> None:
    # 1M input + 1K output: 2.50 + 0.01 = 2.51 USD
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000) == 2_510_000


def test_claude_sonnet_4_with_cache() -> None:
    # 100K input total, 50K cached, 1K output:
    #   uncached input 50_000 * 3.0 / 1M = 0.15
    #   cache read     50_000 * 0.3 / 1M = 0.015
    #   output          1_000 * 15.0 / 1M = 0.015
    #   total = 0.18 USD
    assert calculate_cost_micros("claude-sonnet-4", 100_000, 1_000, 50_000) == 180_000


def test_text_embedding_3_small_input_only() -> None:
    # Embeddings bill on input only ($0.02/MTok). Output rate is 0 so any
    # output_tokens passed in must NOT contribute to the cost.
    #   1M input * $0.02 / 1M = $0.02 = 20_000 micros
    #   any output value is multiplied by 0 → 0
    assert calculate_cost_micros("text-embedding-3-small", 1_000_000, 0) == 20_000
    assert calculate_cost_micros("text-embedding-3-small", 1_000_000, 999) == 20_000


def test_text_embedding_3_large_input_only() -> None:
    # 500K input * $0.13 / 1M = $0.065 = 65_000 micros
    assert calculate_cost_micros("text-embedding-3-large", 500_000, 0) == 65_000


def test_unknown_model_returns_zero() -> None:
    assert calculate_cost_micros("not-a-real-model-xyz", 1_000, 1_000) == 0


def test_provider_prefix_is_stripped() -> None:
    # litellm-style prefixes should resolve to the underlying model
    assert (
        calculate_cost_micros("openai/gpt-4o", 1_000_000, 1_000)
        == calculate_cost_micros("gpt-4o", 1_000_000, 1_000)
    )
    assert (
        calculate_cost_micros("gemini/gemini-2.5-pro", 100_000, 1_000)
        == calculate_cost_micros("gemini-2.5-pro", 100_000, 1_000)
    )


# ---------------------------------------------------------------------------
# Loader / data-source contract
# ---------------------------------------------------------------------------


def test_pricing_data_loads_with_expected_top_level_keys() -> None:
    """The runtime loader must surface the canonical structure intact.

    If this fails, either pricing/models.json was edited without bumping
    $schema_version (and the loader's version guard tripped), or the file
    isn't being found by either resolution path (bundled or repo-root walk-up).
    """
    assert _PRICING_DATA["$schema_version"] == 1
    for key in ("models", "aliases", "flat_pricing"):
        assert key in _PRICING_DATA, f"missing top-level key {key!r}"
    assert len(_PRICING_DATA["models"]) >= 30, "expected at least 30 models in seed"


def test_legacy_model_pricing_is_bare_keyed() -> None:
    """The _MODEL_PRICING legacy export must be keyed by BARE model id (no
    provider prefix) so back-compat consumers like internal-notify.ts on the
    server side and any external code that imported _MODEL_PRICING continue
    to work after the canonical-source refactor.
    """
    assert "gpt-4o" in _MODEL_PRICING, "bare key 'gpt-4o' should be present"
    assert "openai/gpt-4o" not in _MODEL_PRICING, "should NOT include provider prefix"
    assert "gemini-2.5-pro" in _MODEL_PRICING


def test_legacy_aliases_are_bare_to_bare() -> None:
    """_MODEL_ALIASES values used to be bare model ids (pre-refactor). The new
    canonical pricing/models.json stores them as canonical (provider/model)
    targets — the loader must strip the prefix to preserve the bare→bare
    contract for back-compat."""
    assert _MODEL_ALIASES.get("gemini-3.1-pro") == "gemini-3.1-pro-preview"
    assert "/" not in _MODEL_ALIASES.get("gemini-3.1-pro", "")


# ---------------------------------------------------------------------------
# as_of (rate-card resolution by timestamp)
# ---------------------------------------------------------------------------


def test_as_of_none_uses_latest_card() -> None:
    """Default behavior (as_of=None) must use the latest open-ended card."""
    a = calculate_cost_micros("gpt-4o", 1_000_000, 1_000)
    b = calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=None)
    assert a == b == 2_510_000


def test_as_of_after_seed_date_uses_seed_card() -> None:
    """All seed cards have effective_from=2026-04-20. Any timestamp at or
    after that date should resolve to the seed card."""
    after = datetime(2026, 12, 31, tzinfo=timezone.utc)
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=after) == 2_510_000


def test_as_of_before_earliest_card_extrapolates_backward() -> None:
    """For timestamps before the earliest card's effective_from, the loader
    extrapolates backward (with a debug log). This is necessary so historical
    rows from before the seed date still get a cost computed.
    """
    pre_seed = datetime(2025, 1, 1, tzinfo=timezone.utc)
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=pre_seed) == 2_510_000


def test_as_of_with_naive_datetime_assumes_utc() -> None:
    """as_of with no tzinfo should be treated as UTC (no AttributeError)."""
    naive = datetime(2026, 12, 31)
    assert calculate_cost_micros("gpt-4o", 1_000_000, 1_000, as_of=naive) == 2_510_000


# ---------------------------------------------------------------------------
# Comprehensive regression fixture
#
# This locks down EXACT cost math for every model in the canonical pricing
# table. If you change a rate in pricing/models.json (legitimately, by
# appending a new effective-dated card), the affected expected values here
# need to be updated too, and the dev-log entry should explain why.
#
# Inputs are chosen to be small but exercise input + output + (where
# applicable) cache_read so the assertion catches drift in any rate leg.
# ---------------------------------------------------------------------------


# (model_bare_key, input_tokens, output_tokens, cached_tokens, expected_micros)
REGRESSION_FIXTURE: list[tuple[str, int, int, int, int]] = [
    # --- OpenAI GPT-5 family (verified against OpenAI pricing page 2026-04-20) ---
    # gpt-5.4 has tiered pricing at 272K input tokens (long-context).
    # Low tier: input 2.5, output 15.0, cache_read 0.25 (per 1M)
    # High tier: input 5.0, output 22.5, cache_read 0.5
    ("gpt-5.4",                     100_000, 1_000,      0,    265_000),  # low tier: 100K*2.5 + 1K*15
    ("gpt-5.4",                   1_000_000, 1_000,      0,  5_022_500),  # high tier: 1M*5.0 + 1K*22.5
    ("gpt-5.4",                     100_000, 1_000, 50_000,    152_500),  # low tier w/ cache: 50K*2.5+50K*0.25+1K*15
    ("gpt-5.4",                     300_000, 1_000,100_000,  1_072_500),  # high tier w/ cache: 200K*5+100K*0.5+1K*22.5
    ("gpt-5.4-mini",              1_000_000, 1_000,      0,    754_500),  # flat: 1M*0.75 + 1K*4.5
    ("gpt-5.4-nano",              1_000_000, 1_000,      0,    201_250),  # flat: 1M*0.2 + 1K*1.25
    ("gpt-5.4-pro",                 100_000, 1_000,      0,  3_180_000),  # low tier: 100K*30 + 1K*180
    ("gpt-5.4-pro",               1_000_000, 1_000,      0, 60_270_000),  # high tier: 1M*60 + 1K*270
    ("gpt-5.2",                   1_000_000, 1_000,      0,  1_764_000),  # 1M*1.75 + 1K*14
    ("gpt-5.2-pro",               1_000_000, 1_000,      0, 21_168_000),  # 1M*21 + 1K*168 (no caching offered)
    ("gpt-5.2-pro",                 100_000, 1_000, 50_000,  1_218_000),  # cached_tokens passed → uncached 50K*21+output 1K*168, cache_read=$0/1M
    ("gpt-5.1",                   1_000_000, 1_000,      0,  1_260_000),  # 1M*1.25 + 1K*10 (same as gpt-5)
    ("gpt-5",                     1_000_000, 1_000,      0,  1_260_000),
    ("gpt-5-mini",                1_000_000, 1_000,      0,    252_000),  # 1M*0.25 + 1K*2.0
    ("gpt-5-nano",                1_000_000, 1_000,      0,     50_400),  # 1M*0.05 + 1K*0.4
    ("gpt-5-pro",                 1_000_000, 1_000,      0, 15_120_000),  # 1M*15 + 1K*120 (no caching offered)
    # --- OpenAI GPT-4 family ---
    ("gpt-4o",                    1_000_000, 1_000,      0,  2_510_000),
    ("gpt-4o",                      100_000, 1_000, 50_000,    197_500),  # 50K*2.5 + 50K*1.25 + 1K*10 = 0.125+0.0625+0.01
    ("gpt-4o-mini",               1_000_000, 1_000,      0,    150_600),
    ("gpt-4.1",                   1_000_000, 1_000,      0,  2_008_000),
    ("gpt-4.1",                     100_000, 1_000, 50_000,    133_000),  # cache fix: 50K*2 + 50K*0.5 + 1K*8 = 0.10+0.025+0.008
    ("gpt-4.1-mini",              1_000_000, 1_000,      0,    401_600),
    ("gpt-4.1-nano",              1_000_000, 1_000,      0,    100_400),
    ("o3",                        1_000_000, 1_000,      0,  2_008_000),
    ("o4-mini",                   1_000_000, 1_000,      0,  1_104_400),
    # --- OpenAI embeddings + transcription ---
    ("text-embedding-3-small",    1_000_000,     0,      0,     20_000),  # input only
    ("text-embedding-3-large",    1_000_000,     0,      0,    130_000),
    ("text-embedding-ada-002",    1_000_000,     0,      0,    100_000),
    ("gpt-4o-transcribe",         1_000_000, 1_000,      0,  2_510_000),
    ("gpt-4o-mini-transcribe",    1_000_000, 1_000,      0,  1_255_000),
    # --- Anthropic ---
    ("claude-opus-4",             1_000_000, 1_000, 0, 15_075_000),    # 1M*15 + 1K*75
    ("claude-opus-4-5",           1_000_000, 1_000, 0,  5_025_000),    # 1M*5 + 1K*25
    ("claude-opus-4-6",           1_000_000, 1_000, 0,  5_025_000),
    ("claude-opus-4-7",           1_000_000, 1_000, 0,  5_025_000),
    ("claude-sonnet-4",           1_000_000, 1_000, 0,  3_015_000),    # 1M*3 + 1K*15
    ("claude-sonnet-4-5",         1_000_000, 1_000, 0,  3_015_000),
    ("claude-sonnet-4-6",         1_000_000, 1_000, 0,  3_015_000),
    ("claude-haiku-4-5",          1_000_000, 1_000, 0,  1_005_000),    # 1M*1 + 1K*5
    # --- Google Gemini ---
    ("gemini-3.1-pro-preview",      100_000, 1_000, 0,    212_000),   # low tier: 100K*2.0 + 1K*12
    ("gemini-3.1-pro-preview",      300_000, 1_000, 0,  1_218_000),   # high tier: 300K*4.0 + 1K*18
    ("gemini-3.1-flash-lite-preview", 1_000_000, 1_000, 0, 251_500),  # 1M*0.25 + 1K*1.5
    ("gemini-3-flash-preview",      1_000_000, 1_000, 0,    503_000), # 1M*0.5 + 1K*3
    ("gemini-2.5-pro",              100_000, 1_000, 0,    135_000),   # low tier: 100K*1.25 + 1K*10
    ("gemini-2.5-pro",              300_000, 1_000, 0,    765_000),   # high tier: 300K*2.5 + 1K*15
    ("gemini-2.5-flash",          1_000_000, 1_000, 0,    302_500),   # unified stable: 1M*0.30 + 1K*2.50
    ("gemini-2.5-flash-lite",     1_000_000, 1_000, 0,    100_400),   # 1M*0.10 + 1K*0.4
    ("gemini-2.0-flash",          1_000_000, 1_000, 0,    100_400),
    ("gemini-2.0-flash-lite",     1_000_000, 1_000, 0,     75_300),   # 1M*0.075 + 1K*0.3
    # --- xAI ---
    ("grok-3",                    1_000_000, 1_000, 0,  3_015_000),
    ("grok-3-mini",               1_000_000, 1_000, 0,    300_500),   # 1M*0.3 + 1K*0.5
    ("grok-3-fast",               1_000_000, 1_000, 0,  5_025_000),   # 1M*5 + 1K*25
    # --- Cache pricing sanity ---
    ("claude-opus-4",             100_000, 1_000, 50_000, 900_000),
    # uncached 50K*$15 + cache_read 50K*$1.5 + output 1K*$75 / 1M
    # = 0.750 + 0.075 + 0.075 = 0.900 USD = 900_000 micros
    ("gpt-4o-audio",              1_000_000, 1_000, 0, 2_510_000),
    # default rates only (input_audio / output_audio default to 0 when no audio
    # token columns supplied to calculate_cost_micros — the SDK API doesn't
    # expose them, so the audio-rate paths are server-only today)
]


@pytest.mark.parametrize(
    "model,input_tokens,output_tokens,cached_tokens,expected_micros",
    REGRESSION_FIXTURE,
)
def test_regression_fixture(
    model: str,
    input_tokens: int,
    output_tokens: int,
    cached_tokens: int,
    expected_micros: int,
) -> None:
    """If this fails, you changed a rate in pricing/models.json (intentionally
    or not). Update the expected_micros in REGRESSION_FIXTURE if the change
    was intentional and explain it in docs/dev-log.md.
    """
    actual = calculate_cost_micros(model, input_tokens, output_tokens, cached_tokens)
    assert actual == expected_micros, (
        f"{model} ({input_tokens=}, {output_tokens=}, {cached_tokens=}): "
        f"expected {expected_micros:,} micros but got {actual:,} micros — "
        f"a rate in pricing/models.json changed"
    )


def test_pro_models_with_cached_tokens_charge_no_cache_surcharge() -> None:
    """Pro models (gpt-5-pro, gpt-5.2-pro, gpt-5.4-pro) do NOT offer prompt
    caching — `cache_read` is explicitly `null` in pricing/models.json. If a
    caller passes `cached_tokens > 0` for one of these models, the calculator
    must:
      (a) deduct the cached portion from the input charge (since those tokens
          aren't counted as fresh input)
      (b) add ZERO cache_read cost (no caching offered → no rate to apply).

    A previous iteration of the calculator used a `input_rate * 0.5` heuristic
    when cache_read was missing/null, which would have over-charged pro-model
    callers by ~50% of the input rate × cached_tokens. This test guards
    against the heuristic being re-introduced.
    """
    # gpt-5-pro: input $15 / 1M, output $120 / 1M, no cached
    # 100K input total, 50K cached, 1K output:
    #   uncached: 50K * $15 / 1M = $0.75
    #   cache_read: 50K * $0   / 1M = $0.00
    #   output: 1K * $120 / 1M = $0.12
    #   total = $0.87 = 870_000 micros
    assert calculate_cost_micros("gpt-5-pro", 100_000, 1_000, 50_000) == 870_000

    # If the heuristic (input_rate * 0.5) were still active:
    #   cache_read = 50K * $7.5 / 1M = $0.375 → total $1.245 = 1_245_000 micros
    # We assert the result is decisively NOT that.
    assert calculate_cost_micros("gpt-5-pro", 100_000, 1_000, 50_000) != 1_245_000


def test_regression_fixture_covers_every_seeded_model() -> None:
    """Guard against a model being added to pricing/models.json without a
    corresponding regression-fixture entry. Every model in _MODEL_PRICING
    must have at least one row in REGRESSION_FIXTURE."""
    fixture_models = {row[0] for row in REGRESSION_FIXTURE}
    pricing_models = set(_MODEL_PRICING.keys())
    missing = pricing_models - fixture_models
    assert not missing, (
        f"{len(missing)} model(s) in pricing/models.json have no regression-"
        f"fixture entry: {sorted(missing)}. Add them to REGRESSION_FIXTURE in "
        "tests/test_pricing.py with hand-calculated expected micros."
    )
