# py-llm-audit

Internal Python package for unified LLM audit logging.

Exports:

- `configure_audit_logger(...)`
- `use_structlog_context(...)`
- `set_audit_context(...)`
- `aset_audit_context(...)`
- `get_audit_context()`
- `clear_audit_context()`
- `bind_tool_name(...)`
- `register_user_resolver(...)`
- `clear_user_resolver()`
- `resolve_audit_user_id(...)`
- `audit_context_from_headers(...)`
- `merge_audit_headers(...)`
- `build_llm_audit_doc(...)`
- `log_llm_audit(...)`
- `alog_llm_audit(...)`
- `MongoAuditWriter`
- `AsyncMongoAuditWriter`

Notes:

- Supports native `contextvars`
- Can reuse existing `structlog.contextvars`
- Supports async `user_id` resolution for cases such as `gpt_id -> user_id`
- `log_llm_audit(...)` is for sync writers
- `alog_llm_audit(...)` is for async writers such as Motor-backed Mongo
- Default behavior is non-blocking: audit context resolution, doc building, and write failures do not interrupt the original business flow unless strict mode is explicitly enabled with `fail_silently=False`
