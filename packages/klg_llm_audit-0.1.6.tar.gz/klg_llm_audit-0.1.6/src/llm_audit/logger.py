from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any
from uuid import uuid4

from .context import get_audit_context
from .schema import LlmAuditLog
from .writer import MongoAuditWriter


@dataclass
class AuditLoggerConfig:
    writer: Any | None = None
    default_context: dict[str, Any] = field(default_factory=dict)
    fail_silently: bool = True


_CONFIG = AuditLoggerConfig()


def configure_audit_logger(
    *,
    mongo_uri: str | None = None,
    database: str | None = None,
    collection: str = "llm_audit_logs",
    mongo_client: Any | None = None,
    writer: Any | None = None,
    default_context: dict[str, Any] | None = None,
    fail_silently: bool = True,
) -> None:
    resolved_writer = writer
    if resolved_writer is None:
        resolved_writer = MongoAuditWriter(
            mongo_uri=mongo_uri,
            database=database,
            collection=collection,
            mongo_client=mongo_client,
        )

    _CONFIG.writer = resolved_writer
    _CONFIG.default_context = dict(default_context or {})
    _CONFIG.fail_silently = fail_silently


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def _validate_required_fields(doc: dict[str, Any]) -> None:
    return None


def _build_fallback_doc(kwargs: dict[str, Any]) -> dict[str, Any]:
    try:
        context = {**_CONFIG.default_context, **get_audit_context()}
    except Exception:
        context = dict(_CONFIG.default_context)

    return LlmAuditLog(
        event_time=_now_iso(),
        log_id=str(uuid4()),
        request_id=context.get("request_id"),
        task_id=context.get("task_id"),
        user_id=context.get("user_id"),
        org_id=context.get("org_id"),
        app=context.get("app"),
        project=context.get("project"),
        source_project=context.get("source_project"),
        server_id=context.get("server_id"),
        workflow_id=context.get("workflow_id"),
        tool_id=context.get("tool_id"),
        llm_provider=kwargs.get("llm_provider"),
        llm_model=kwargs.get("llm_model"),
        status=kwargs.get("status"),
        latency_ms=kwargs.get("latency_ms"),
        prompt_tokens=kwargs.get("prompt_tokens"),
        completion_tokens=kwargs.get("completion_tokens"),
        cached_tokens=kwargs.get("cached_tokens"),
        total_tokens=kwargs.get("total_tokens"),
        input_preview=kwargs.get("input_preview"),
        output_preview=kwargs.get("output_preview"),
        module=kwargs.get("module")
        if kwargs.get("module") is not None
        else context.get("module"),
        entry_point=kwargs.get("entry_point")
        if kwargs.get("entry_point") is not None
        else context.get("entry_point"),
        source_location=kwargs.get("source_location"),
        error_code=kwargs.get("error_code"),
        error_message=kwargs.get("error_message"),
    ).to_dict()


def build_llm_audit_doc(
    *,
    llm_provider: str,
    llm_model: str,
    status: str,
    latency_ms: int,
    prompt_tokens: int | None = None,
    completion_tokens: int | None = None,
    cached_tokens: int | None = None,
    total_tokens: int | None = None,
    input_preview: str | None = None,
    output_preview: str | None = None,
    source_location: str | None = None,
    error_code: str | None = None,
    error_message: str | None = None,
    module: str | None = None,
    entry_point: str | None = None,
) -> dict[str, Any]:
    context = {**_CONFIG.default_context, **get_audit_context()}

    resolved_total_tokens = total_tokens
    if (
        resolved_total_tokens is None
        and prompt_tokens is not None
        and completion_tokens is not None
    ):
        resolved_total_tokens = prompt_tokens + completion_tokens

    log = LlmAuditLog(
        event_time=_now_iso(),
        log_id=str(uuid4()),
        request_id=context.get("request_id"),
        task_id=context.get("task_id"),
        user_id=context.get("user_id"),
        org_id=context.get("org_id"),
        app=context.get("app"),
        project=context.get("project"),
        source_project=context.get("source_project"),
        server_id=context.get("server_id"),
        workflow_id=context.get("workflow_id"),
        tool_id=context.get("tool_id"),
        llm_provider=llm_provider,
        llm_model=llm_model,
        status=status,
        latency_ms=latency_ms,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        cached_tokens=cached_tokens,
        total_tokens=resolved_total_tokens,
        input_preview=input_preview,
        output_preview=output_preview,
        module=module if module is not None else context.get("module"),
        entry_point=entry_point if entry_point is not None else context.get("entry_point"),
        source_location=source_location,
        error_code=error_code,
        error_message=error_message,
    )
    doc = log.to_dict()
    _validate_required_fields(doc)
    return doc


def log_llm_audit(**kwargs: Any) -> dict[str, Any]:
    doc: dict[str, Any] | None = None
    try:
        doc = build_llm_audit_doc(**kwargs)

        if _CONFIG.writer is None:
            raise RuntimeError(
                "Audit logger is not configured. Call configure_audit_logger(...) first."
            )

        result = _CONFIG.writer.write(doc)
        if inspect.isawaitable(result):
            raise RuntimeError("Configured audit writer is async. Use alog_llm_audit(...) instead.")
        return result
    except Exception:
        if _CONFIG.fail_silently:
            return doc or _build_fallback_doc(kwargs)
        raise


async def alog_llm_audit(**kwargs: Any) -> dict[str, Any]:
    doc: dict[str, Any] | None = None
    try:
        doc = build_llm_audit_doc(**kwargs)

        if _CONFIG.writer is None:
            raise RuntimeError(
                "Audit logger is not configured. Call configure_audit_logger(...) first."
            )

        result = _CONFIG.writer.write(doc)
        if inspect.isawaitable(result):
            return await result
        return result
    except Exception:
        if _CONFIG.fail_silently:
            return doc or _build_fallback_doc(kwargs)
        raise
