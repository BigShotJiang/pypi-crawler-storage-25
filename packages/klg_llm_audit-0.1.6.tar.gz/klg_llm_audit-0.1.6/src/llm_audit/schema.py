from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass
class AuditContext:
    request_id: str | None = None
    task_id: str | None = None
    user_id: str | None = None
    org_id: str | None = None
    app: str | None = None
    project: str | None = None
    source_project: str | None = None
    server_id: str | None = None
    workflow_id: str | None = None
    tool_id: str | None = None
    module: str | None = None
    entry_point: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class LlmAuditLog:
    event_time: str
    log_id: str
    request_id: str | None = None
    task_id: str | None = None
    user_id: str | None = None
    org_id: str | None = None
    app: str | None = None
    project: str | None = None
    source_project: str | None = None
    server_id: str | None = None
    workflow_id: str | None = None
    tool_id: str | None = None
    llm_provider: str | None = None
    llm_model: str | None = None
    status: str | None = None
    latency_ms: int | None = None
    prompt_tokens: int | None = None
    completion_tokens: int | None = None
    cached_tokens: int | None = None
    total_tokens: int | None = None
    input_preview: str | None = None
    output_preview: str | None = None
    module: str | None = None
    entry_point: str | None = None
    source_location: str | None = None
    error_code: str | None = None
    error_message: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)
