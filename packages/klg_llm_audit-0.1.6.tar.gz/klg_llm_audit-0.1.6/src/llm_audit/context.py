from __future__ import annotations

import inspect
from contextvars import ContextVar
from typing import Any, Awaitable, Callable

from .schema import AuditContext

_AUDIT_CONTEXT: ContextVar[dict[str, Any]] = ContextVar("llm_audit_context", default={})
_USE_STRUCTLOG_CONTEXT = False
_USER_RESOLVER: Callable[[dict[str, Any]], str | None | Awaitable[str | None]] | None = None
_AUDIT_KEYS = (
    "request_id",
    "task_id",
    "user_id",
    "org_id",
    "app",
    "project",
    "source_project",
    "server_id",
    "workflow_id",
    "tool_id",
    "module",
    "entry_point",
)


def register_user_resolver(
    resolver: Callable[[dict[str, Any]], str | None | Awaitable[str | None]] | None,
) -> None:
    global _USER_RESOLVER
    _USER_RESOLVER = resolver


def clear_user_resolver() -> None:
    global _USER_RESOLVER
    _USER_RESOLVER = None


def use_structlog_context(enabled: bool = True) -> None:
    global _USE_STRUCTLOG_CONTEXT

    if enabled:
        try:
            import structlog.contextvars  # noqa: F401
        except ImportError as exc:  # pragma: no cover - depends on optional dependency
            raise RuntimeError(
                "structlog is not installed. Install `llm-audit[structlog]` or disable structlog mode."
            ) from exc

    _USE_STRUCTLOG_CONTEXT = enabled


def _bind_context(values: dict[str, Any]) -> None:
    clean_values = {key: value for key, value in values.items() if value is not None}

    if _USE_STRUCTLOG_CONTEXT:
        import structlog.contextvars

        structlog.contextvars.bind_contextvars(**clean_values)
        return

    current = dict(_AUDIT_CONTEXT.get())
    current.update(clean_values)
    _AUDIT_CONTEXT.set(current)


def _read_context() -> dict[str, Any]:
    if _USE_STRUCTLOG_CONTEXT:
        import structlog.contextvars

        return dict(structlog.contextvars.get_contextvars())
    return dict(_AUDIT_CONTEXT.get())


def set_audit_context(
    *,
    user_id: str | None = None,
    app: str,
    project: str,
    request_id: str | None = None,
    task_id: str | None = None,
    org_id: str | None = None,
    server_id: str | None = None,
    workflow_id: str | None = None,
    source_project: str | None = None,
    module: str | None = None,
    entry_point: str | None = None,
) -> dict[str, Any]:
    values = AuditContext(
        request_id=request_id,
        task_id=task_id,
        user_id=user_id,
        org_id=org_id,
        app=app,
        project=project,
        source_project=source_project,
        server_id=server_id,
        workflow_id=workflow_id,
        module=module,
        entry_point=entry_point,
    ).to_dict()
    try:
        _bind_context(values)
    except Exception:
        return get_audit_context()
    return get_audit_context()


async def resolve_audit_user_id(
    *,
    user_id: str | None = None,
    resolver_context: dict[str, Any] | None = None,
    default_user_id: str | None = None,
) -> str | None:
    if user_id:
        return str(user_id)

    if _USER_RESOLVER is None:
        return default_user_id

    try:
        resolved = _USER_RESOLVER(dict(resolver_context or {}))
        if inspect.isawaitable(resolved):
            resolved = await resolved
    except Exception:
        return default_user_id

    if resolved is None:
        return default_user_id

    text = str(resolved).strip()
    return text or default_user_id


async def aset_audit_context(
    *,
    user_id: str | None = None,
    app: str,
    project: str,
    request_id: str | None = None,
    task_id: str | None = None,
    org_id: str | None = None,
    server_id: str | None = None,
    workflow_id: str | None = None,
    source_project: str | None = None,
    module: str | None = None,
    entry_point: str | None = None,
    resolver_context: dict[str, Any] | None = None,
    default_user_id: str | None = None,
) -> dict[str, Any]:
    resolved_user_id = await resolve_audit_user_id(
        user_id=user_id,
        resolver_context=resolver_context,
        default_user_id=default_user_id,
    )
    values = AuditContext(
        request_id=request_id,
        task_id=task_id,
        user_id=resolved_user_id,
        org_id=org_id,
        app=app,
        project=project,
        source_project=source_project,
        server_id=server_id,
        workflow_id=workflow_id,
        module=module,
        entry_point=entry_point,
    ).to_dict()
    try:
        _bind_context(values)
    except Exception:
        return get_audit_context()
    return get_audit_context()


def bind_tool_name(tool_id: str) -> dict[str, Any]:
    try:
        _bind_context({"tool_id": tool_id})
    except Exception:
        return get_audit_context()
    return get_audit_context()


def get_audit_context() -> dict[str, Any]:
    try:
        return _read_context()
    except Exception:
        return {}


def clear_audit_context() -> None:
    try:
        if _USE_STRUCTLOG_CONTEXT:
            import structlog.contextvars

            structlog.contextvars.unbind_contextvars(*_AUDIT_KEYS)
            return
        _AUDIT_CONTEXT.set({})
    except Exception:
        return
