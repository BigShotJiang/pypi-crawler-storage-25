from __future__ import annotations

from collections.abc import Mapping
from typing import Any

LOG_CONTEXT_HEADER_MAP: dict[str, str] = {
    "x-logs-request-id": "request_id",
    "x-logs-task-id": "task_id",
    "x-logs-user-id": "user_id",
    "x-logs-org-id": "org_id",
    "x-logs-app": "app",
    "x-logs-workflow-id": "workflow_id",
    "x-logs-server-id": "server_id",
    "x-logs-source-project": "source_project",
}


def _normalize_headers(headers: Mapping[str, Any] | None) -> dict[str, Any]:
    if not headers:
        return {}
    return {str(key).lower(): value for key, value in headers.items()}


def audit_context_from_headers(headers: Mapping[str, Any] | None) -> dict[str, str]:
    normalized_headers = _normalize_headers(headers)
    context: dict[str, str] = {}

    for header_name, context_key in LOG_CONTEXT_HEADER_MAP.items():
        value = normalized_headers.get(header_name)
        if value is None:
            continue

        text = str(value).strip()
        if not text:
            continue
        context[context_key] = text

    return context


def merge_audit_headers(
    headers: Mapping[str, Any] | None,
    context: Mapping[str, Any] | None,
) -> dict[str, Any]:
    merged_headers = dict(headers or {})
    normalized_headers = _normalize_headers(merged_headers)
    context = dict(context or {})

    for header_name, context_key in LOG_CONTEXT_HEADER_MAP.items():
        if header_name in normalized_headers:
            continue

        value = context.get(context_key)
        if value is None:
            continue

        text = str(value).strip()
        if not text:
            continue

        merged_headers[header_name] = text
        normalized_headers[header_name] = text

    return merged_headers
