from __future__ import annotations

import inspect
from typing import Any, Protocol


class AuditWriter(Protocol):
    def write(self, doc: dict[str, Any]) -> dict[str, Any]:
        ...


class AsyncAuditWriter(Protocol):
    async def write(self, doc: dict[str, Any]) -> dict[str, Any]:
        ...


class MongoAuditWriter:
    def __init__(
        self,
        *,
        mongo_uri: str | None = None,
        database: str | None = None,
        collection: str = "llm_audit_logs",
        mongo_client: Any | None = None,
    ) -> None:
        if mongo_client is None and (not mongo_uri or not database):
            raise ValueError("Either mongo_client or both mongo_uri/database must be provided.")

        if mongo_client is None:
            from pymongo import MongoClient

            mongo_client = MongoClient(mongo_uri)

        if not database:
            raise ValueError("database is required.")

        self._collection = mongo_client[database][collection]

    def write(self, doc: dict[str, Any]) -> dict[str, Any]:
        self._collection.insert_one(doc)
        return doc


class AsyncMongoAuditWriter:
    def __init__(self, *, collection: Any) -> None:
        if collection is None:
            raise ValueError("collection is required.")
        self._collection = collection

    async def write(self, doc: dict[str, Any]) -> dict[str, Any]:
        result = self._collection.insert_one(doc)
        if inspect.isawaitable(result):
            await result
        return doc
