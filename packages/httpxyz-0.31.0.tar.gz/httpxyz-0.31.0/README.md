<p align="center">
  <a href="https://httpxyz.org/"><img width="877" height="208" src="https://httpxyz.org/img/httpxyz.png" alt='HTTPXYZ'></a>
</p>


<p align="center"><strong>HTTPXYZ</strong> <em>- A friendly fork of the next-generation HTTP client for Python.</em></p>

HTTPXYZ (pronounced "HTTP-ex-why-zee") is a fully featured HTTP client library for Python 3. It includes **an integrated command line client**, has support for both **HTTP/1.1 and HTTP/2**, and provides both **sync and async APIs**.

## About this fork

HTTPXYZ is a fork of [HTTPX](https://github.com/encode/httpx). HTTPX had no
release after November 2024 while bugs affecting real-world usage went
unresolved. Our goal is stability: bug fixes only, no breaking API changes.

We mean no harm to the original author or contributors — HTTPX is excellent
work. For the full story, see [Why we forked HTTPX](https://httpxyz.org/why-fork/).

### Migrating from HTTPX

For most users, migration is a one-line change:

```python
import httpxyz as httpx
```

That's it, HTTPXYZ is a drop-in replacement, all APIs, exceptions, and behaviour are identical.

If you want to use HTTPXYZ natively:

```python
import httpxyz
r = httpxyz.get("https://www.example.org/")
```

### Transparent httpx aliasing

Importing `httpxyz` automatically registers itself as `sys.modules["httpx"]`. This means that any third-party library which does `import httpx` internally will receive `httpxyz` instead, as long as `httpxyz` was imported first:

```python
import httpxyz          # registers httpxyz as sys.modules["httpx"]
import some_library     # internally does `import httpx` — gets httpxyz
```

`isinstance` checks against `httpx` classes will therefore pass for `httpxyz` objects, even in code you don't control. See [HTTPX Compatibility](https://httpxyz.org/httpx-compatibility/) for full details, including how to set this up correctly when using [respx](https://github.com/lundberg/respx) in pytest.

---

## Using HTTPXYZ

Install HTTPXYZ using pip:

```shell
$ pip install httpxyz
```

Now, let's get started:

```pycon
>>> import httpxyz
>>> r = httpxyz.get('https://www.example.org/')
>>> r
<Response [200 OK]>
>>> r.status_code
200
>>> r.headers['content-type']
'text/html; charset=UTF-8'
>>> r.text
'<!doctype html>\n<html>\n<head>\n<title>Example Domain</title>...'
```

Or, using the command-line client.

```shell
$ pip install 'httpxyz[cli]'  # The command line client is an optional dependency.
```

Which now allows us to use HTTPXYZ directly from the command-line...

<p align="center">
  <img width="700" src="docs/img/httpxyz-help.png" alt='httpxyz --help'>
</p>

Sending a request...

<p align="center">
  <img width="700" src="docs/img/httpxyz-request.png" alt='httpxyz http://httpbin.org/json'>
</p>

## Features

HTTPXYZ builds on the well-established usability of `requests`, and gives you:

* A broadly [requests-compatible API](https://httpxyz.org/compatibility/).
* An integrated command-line client.
* HTTP/1.1 [and HTTP/2 support](https://httpxyz.org/http2/).
* Standard synchronous interface, but with [async support if you need it](https://httpxyz.org/async/).
* Ability to make requests directly to [WSGI applications](https://httpxyz.org/advanced/transports/#wsgi-transport) or [ASGI applications](https://httpxyz.org/advanced/transports/#asgi-transport).
* Strict timeouts everywhere.
* Fully type annotated.
* 100% test coverage.

Plus all the standard features of `requests`...

* International Domains and URLs
* Keep-Alive & Connection Pooling
* Sessions with Cookie Persistence
* Browser-style SSL Verification
* Basic/Digest Authentication
* Elegant Key/Value Cookies
* Automatic Decompression
* Automatic Content Decoding
* Unicode Response Bodies
* Multipart File Uploads
* HTTP(S) Proxy Support
* Connection Timeouts
* Streaming Downloads
* .netrc Support
* Chunked Requests

## Installation

Install with pip:

```shell
$ pip install httpxyz
```

Or, to include the optional HTTP/2 support, use:

```shell
$ pip install httpxyz[http2]
```

HTTPXYZ requires Python 3.9+.

## Documentation

Project documentation is available at [https://httpxyz.org/](https://httpxyz.org/).

For a run-through of all the basics, head over to the [QuickStart](https://httpxyz.org/quickstart/).

For more advanced topics, see the [Advanced Usage](https://httpxyz.org/advanced/) section, the [async support](https://httpxyz.org/async/) section, or the [HTTP/2](https://httpxyz.org/http2/) section.

The [Developer Interface](https://httpxyz.org/api/) provides a comprehensive API reference.

To find out about tools that integrate with HTTPXYZ, see [Third Party Packages](https://httpxyz.org/third_party_packages/).

## Contribute

If you want to contribute with HTTPXYZ check out the [Contributing Guide](https://httpxyz.org/contributing/) to learn how to start.

## Dependencies

The HTTPXYZ project relies on these excellent libraries:

* `httpcore` - The underlying transport implementation for `httpxyz`.
  * `h11` - HTTP/1.1 support.
* `certifi` - SSL certificates.
* `idna` - Internationalized domain name support.
* `sniffio` - Async library autodetection.

As well as these optional installs:

* `h2` - HTTP/2 support. *(Optional, with `httpxyz[http2]`)*
* `socksio` - SOCKS proxy support. *(Optional, with `httpxyz[socks]`)*
* `rich` - Rich terminal support. *(Optional, with `httpxyz[cli]`)*
* `click` - Command line client support. *(Optional, with `httpxyz[cli]`)*
* `brotli` or `brotlicffi` - Decoding for "brotli" compressed responses. *(Optional, with `httpxyz[brotli]`)*
* `zstandard` - Decoding for "zstd" compressed responses. *(Optional, with `httpxyz[zstd]`)*

A huge amount of credit is due to `requests` for the API layout that
much of this work follows, as well as to `urllib3` for plenty of design
inspiration around the lower-level networking details.

---

<p align="center"><i>HTTPXYZ is <a href="https://codeberg.org/httpxyz/httpxyz/src/branch/main/LICENSE.md">BSD licensed</a> code.<br/>Designed & crafted with care.</i><br/>&mdash; 🦋 &mdash;</p>
