import pytest

import httpxyz


@pytest.mark.anyio
async def test_read_timeout(server):
    timeout = httpxyz.Timeout(None, read=1e-6)

    async with httpxyz.AsyncClient(timeout=timeout) as client:
        with pytest.raises(httpxyz.ReadTimeout):
            await client.get(server.url.copy_with(path="/slow_response"))


# TODO: Fix ResourceWarning in this test for Python>=3.14
@pytest.mark.filterwarnings("ignore::ResourceWarning")
@pytest.mark.anyio
async def test_write_timeout(server):
    timeout = httpxyz.Timeout(None, write=1e-6)

    async with httpxyz.AsyncClient(timeout=timeout) as client:
        with pytest.raises(httpxyz.WriteTimeout):
            data = b"*" * 1024 * 1024 * 100
            await client.put(server.url.copy_with(path="/slow_response"), content=data)


@pytest.mark.anyio
@pytest.mark.network
async def test_connect_timeout(server):
    timeout = httpxyz.Timeout(None, connect=1e-6)

    async with httpxyz.AsyncClient(timeout=timeout) as client:
        with pytest.raises(httpxyz.ConnectTimeout):
            # See https://stackoverflow.com/questions/100841/
            await client.get("http://10.255.255.1/")


@pytest.mark.anyio
async def test_pool_timeout(server):
    limits = httpxyz.Limits(max_connections=1)
    timeout = httpxyz.Timeout(None, pool=1e-4)

    async with httpxyz.AsyncClient(limits=limits, timeout=timeout) as client:
        with pytest.raises(httpxyz.PoolTimeout):
            async with client.stream("GET", server.url):
                await client.get(server.url)


@pytest.mark.anyio
async def test_async_client_new_request_send_timeout(server):
    timeout = httpxyz.Timeout(1e-6)

    async with httpxyz.AsyncClient(timeout=timeout) as client:
        with pytest.raises(httpxyz.TimeoutException):
            await client.send(
                httpxyz.Request("GET", server.url.copy_with(path="/slow_response"))
            )
