import ssl
import typing
from pathlib import Path

import certifi
import pytest

import httpxyz


def test_load_ssl_config():
    context = httpxyz.create_ssl_context()
    assert context.verify_mode == ssl.VerifyMode.CERT_REQUIRED
    assert context.check_hostname is True


def test_load_ssl_config_verify_non_existing_file():
    with pytest.raises(IOError):
        context = httpxyz.create_ssl_context()
        context.load_verify_locations(cafile="/path/to/nowhere")


def test_load_ssl_with_keylog(monkeypatch: typing.Any) -> None:
    monkeypatch.setenv("SSLKEYLOGFILE", "test")
    context = httpxyz.create_ssl_context()
    assert context.keylog_filename == "test"


def test_load_ssl_config_verify_existing_file():
    context = httpxyz.create_ssl_context()
    context.load_verify_locations(capath=certifi.where())
    assert context.verify_mode == ssl.VerifyMode.CERT_REQUIRED
    assert context.check_hostname is True


def test_load_ssl_config_verify_directory():
    context = httpxyz.create_ssl_context()
    context.load_verify_locations(capath=Path(certifi.where()).parent)
    assert context.verify_mode == ssl.VerifyMode.CERT_REQUIRED
    assert context.check_hostname is True


def test_load_ssl_config_cert_and_key(cert_pem_file, cert_private_key_file):
    context = httpxyz.create_ssl_context()
    context.load_cert_chain(cert_pem_file, cert_private_key_file)
    assert context.verify_mode == ssl.VerifyMode.CERT_REQUIRED
    assert context.check_hostname is True


@pytest.mark.parametrize("password", [b"password", "password"])
def test_load_ssl_config_cert_and_encrypted_key(
    cert_pem_file, cert_encrypted_private_key_file, password
):
    context = httpxyz.create_ssl_context()
    context.load_cert_chain(cert_pem_file, cert_encrypted_private_key_file, password)
    assert context.verify_mode == ssl.VerifyMode.CERT_REQUIRED
    assert context.check_hostname is True


def test_load_ssl_config_cert_and_key_invalid_password(
    cert_pem_file, cert_encrypted_private_key_file
):
    with pytest.raises(ssl.SSLError):
        context = httpxyz.create_ssl_context()
        context.load_cert_chain(
            cert_pem_file, cert_encrypted_private_key_file, "password1"
        )


def test_load_ssl_config_cert_without_key_raises(cert_pem_file):
    with pytest.raises(ssl.SSLError):
        context = httpxyz.create_ssl_context()
        context.load_cert_chain(cert_pem_file)


def test_load_ssl_config_no_verify():
    context = httpxyz.create_ssl_context(verify=False)
    assert context.verify_mode == ssl.VerifyMode.CERT_NONE
    assert context.check_hostname is False


@pytest.mark.filterwarnings("ignore:.*deprecated.*")
def test_load_ssl_config_cert_and_verify(cert_pem_file):
    # this test is testing deprecated code paths
    # https://github.com/encode/httpx/pull/3718

    # we can only pass in a location of a certificate through create_ssl_context, and
    # the cert_pem_file fixture needs a key file, so it won't load. Instead,
    # we verify the code is trying to load a certificate by expecting a SSL error.
    with pytest.raises(ssl.SSLError):
        httpxyz.create_ssl_context(verify=certifi.where(), cert=cert_pem_file)


def test_SSLContext_with_get_request(server, cert_pem_file):
    context = httpxyz.create_ssl_context()
    context.load_verify_locations(cert_pem_file)
    response = httpxyz.get(server.url, verify=context)
    assert response.status_code == 200


def test_limits_repr():
    limits = httpxyz.Limits(max_connections=100)
    expected = (
        "Limits(max_connections=100, max_keepalive_connections=None,"
        " keepalive_expiry=5.0)"
    )
    assert repr(limits) == expected


def test_limits_eq():
    limits = httpxyz.Limits(max_connections=100)
    assert limits == httpxyz.Limits(max_connections=100)


def test_timeout_eq():
    timeout = httpxyz.Timeout(timeout=5.0)
    assert timeout == httpxyz.Timeout(timeout=5.0)


def test_timeout_all_parameters_set():
    timeout = httpxyz.Timeout(connect=5.0, read=5.0, write=5.0, pool=5.0)
    assert timeout == httpxyz.Timeout(timeout=5.0)


def test_timeout_from_nothing():
    timeout = httpxyz.Timeout(None)
    assert timeout.connect is None
    assert timeout.read is None
    assert timeout.write is None
    assert timeout.pool is None


def test_timeout_from_none():
    timeout = httpxyz.Timeout(timeout=None)
    assert timeout == httpxyz.Timeout(None)


def test_timeout_from_one_none_value():
    timeout = httpxyz.Timeout(None, read=None)
    assert timeout == httpxyz.Timeout(None)


def test_timeout_from_one_value():
    timeout = httpxyz.Timeout(None, read=5.0)
    assert timeout == httpxyz.Timeout(timeout=(None, 5.0, None, None))


def test_timeout_from_one_value_and_default():
    timeout = httpxyz.Timeout(5.0, pool=60.0)
    assert timeout == httpxyz.Timeout(timeout=(5.0, 5.0, 5.0, 60.0))


def test_timeout_missing_default():
    with pytest.raises(ValueError):
        httpxyz.Timeout(pool=60.0)


def test_timeout_from_tuple():
    timeout = httpxyz.Timeout(timeout=(5.0, 5.0, 5.0, 5.0))
    assert timeout == httpxyz.Timeout(timeout=5.0)


def test_timeout_from_config_instance():
    timeout = httpxyz.Timeout(timeout=5.0)
    assert httpxyz.Timeout(timeout) == httpxyz.Timeout(timeout=5.0)


def test_timeout_repr():
    timeout = httpxyz.Timeout(timeout=5.0)
    assert repr(timeout) == "Timeout(timeout=5.0)"

    timeout = httpxyz.Timeout(None, read=5.0)
    assert repr(timeout) == "Timeout(connect=None, read=5.0, write=None, pool=None)"


def test_proxy_from_url():
    proxy = httpxyz.Proxy("https://example.com")

    assert str(proxy.url) == "https://example.com"
    assert proxy.auth is None
    assert proxy.headers == {}
    assert repr(proxy) == "Proxy('https://example.com')"


def test_proxy_with_auth_from_url():
    proxy = httpxyz.Proxy("https://username:password@example.com")

    assert str(proxy.url) == "https://example.com"
    assert proxy.auth == ("username", "password")
    assert proxy.headers == {}
    assert repr(proxy) == "Proxy('https://example.com', auth=('username', '********'))"


def test_invalid_proxy_scheme():
    with pytest.raises(ValueError):
        httpxyz.Proxy("invalid://example.com")
