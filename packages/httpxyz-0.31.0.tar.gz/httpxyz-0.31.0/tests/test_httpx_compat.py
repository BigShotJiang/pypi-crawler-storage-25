"""
Tests for the httpx compatibility alias.

When httpxyz is imported it registers itself under the ``httpx`` name in
``sys.modules``, so that third-party libraries which do ``import httpx`` or
check ``isinstance(obj, httpx.Response)`` continue to work transparently.
"""

import sys

import httpxyz


def test_httpx_alias_registered_in_sys_modules() -> None:
    assert "httpx" in sys.modules


def test_import_httpx_returns_httpxyz() -> None:
    import httpx

    assert httpx.Response is httpxyz.Response


def test_httpx_response_isinstance() -> None:
    import httpx

    response = httpxyz.Response(200)
    assert isinstance(response, httpx.Response)


def test_httpx_request_isinstance() -> None:
    import httpx

    request = httpxyz.Request("GET", "https://example.com")
    assert isinstance(request, httpx.Request)


def test_httpx_client_isinstance() -> None:
    import httpx

    with httpxyz.Client() as client:
        assert isinstance(client, httpx.Client)
