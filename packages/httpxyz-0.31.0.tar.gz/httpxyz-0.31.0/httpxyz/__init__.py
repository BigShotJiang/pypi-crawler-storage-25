from .__version__ import __description__, __title__, __version__
from ._api import *
from ._auth import *
from ._client import *
from ._config import *
from ._content import *
from ._exceptions import *
from ._models import *
from ._status_codes import *
from ._transports import *
from ._types import *
from ._urls import *


# import the _main module lazily so that we only incur the extra import time
# for the CLI dependencies (click, rich, etc.) when intending to run the CLI
# and not on every import of httpxyz
def __getattr__(name: str):  # type: ignore[no-untyped-def]
    if name == "main":
        try:
            from ._main import main
        except ImportError:  # pragma: no cover

            def main() -> None:  # type: ignore
                import sys

                print(
                    "The httpxyz command line client could not run because the "
                    "required dependencies were not installed.\nMake sure you've "
                    "installed everything with: pip install 'httpxyz[cli]'"
                )
                sys.exit(1)

        return main

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "__description__",
    "__title__",
    "__version__",
    "ASGITransport",
    "AsyncBaseTransport",
    "AsyncByteStream",
    "AsyncClient",
    "AsyncHTTPTransport",
    "Auth",
    "BaseTransport",
    "BasicAuth",
    "ByteStream",
    "Client",
    "CloseError",
    "codes",
    "ConnectError",
    "ConnectTimeout",
    "CookieConflict",
    "Cookies",
    "create_ssl_context",
    "DecodingError",
    "delete",
    "DigestAuth",
    "FunctionAuth",
    "get",
    "head",
    "Headers",
    "HTTPError",
    "HTTPStatusError",
    "HTTPTransport",
    "InvalidURL",
    "Limits",
    "LocalProtocolError",
    "MockTransport",
    "NetRCAuth",
    "NetworkError",
    "options",
    "patch",
    "PoolTimeout",
    "post",
    "ProtocolError",
    "Proxy",
    "ProxyError",
    "put",
    "QueryParams",
    "ReadError",
    "ReadTimeout",
    "RemoteProtocolError",
    "request",
    "Request",
    "RequestError",
    "RequestNotRead",
    "Response",
    "ResponseNotRead",
    "stream",
    "StreamClosed",
    "StreamConsumed",
    "StreamError",
    "SyncByteStream",
    "Timeout",
    "TimeoutException",
    "TooManyRedirects",
    "TransportError",
    "UnsupportedProtocol",
    "URL",
    "USE_CLIENT_DEFAULT",
    "WriteError",
    "WriteTimeout",
    "WSGITransport",
]


__locals = locals()
for __name in __all__:
    if not __name.startswith("__"):
        setattr(__locals[__name], "__module__", "httpxyz")  # noqa

import logging as _logging
import sys as _sys

if "httpx" not in _sys.modules:
    _sys.modules["httpx"] = _sys.modules[__name__]
    _logging.getLogger("httpxyz").debug(
        "httpx not found in sys.modules — aliased to httpxyz"
    )
else:
    _logging.getLogger("httpxyz").debug(
        "httpx already present in sys.modules — httpxyz alias not applied"
    )

del _logging, _sys
