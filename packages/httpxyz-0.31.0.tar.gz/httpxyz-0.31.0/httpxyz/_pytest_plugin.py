# Importing this module imports the httpxyz package, which registers
# httpxyz as sys.modules["httpx"] via setdefault.  This must happen
# before respx (or any other library) imports the real httpx.
# See: https://docs.pytest.org/en/stable/reference/plugin_list.html
