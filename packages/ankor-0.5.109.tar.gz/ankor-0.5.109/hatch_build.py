import subprocess
from pathlib import Path

from hatchling.builders.hooks.plugin.interface import BuildHookInterface


class CustomBuildHook(BuildHookInterface):
    def initialize(self, version: str, build_data: dict) -> None:
        # Editable installs are only used during development (uv sync in example/).
        # The frontend is served by Vite in dev mode — never build it here.
        if version == "editable":
            return

        static_dir = Path(__file__).parent / "src" / "ankor" / "static"

        # When building the wheel FROM a pre-built sdist, static files are already
        # present and the frontend/ tree is not available — skip the Vite build.
        if static_dir.exists() and any(static_dir.iterdir()):
            print(
                f"ℹ️  Static files already present in {static_dir}, skipping Vite build."
            )
            return

        root = Path(__file__).parent.parent  # ankor/
        frontend_dir = root / "frontend"

        print(f"🔨 Building Vite frontend → {static_dir}")

        subprocess.run(
            ["pnpm", "run", "build"],
            cwd=frontend_dir,
            check=True,
        )

        if not static_dir.exists() or not any(static_dir.iterdir()):
            raise RuntimeError(
                f"Vite build completed but static dir is empty: {static_dir}"
            )

        print("✅ Frontend build complete")
