from __future__ import annotations

from typing import Awaitable, Callable

# The callable shape for a node or workflow wrapper produced by @gtm.node / @gtm.workflow.
# Both accept a dict of inputs plus an optional keyword-only `slug`.
NodeFn = Callable[..., Awaitable[dict | None]]
WorkflowFn = Callable[..., Awaitable[dict | None]]
