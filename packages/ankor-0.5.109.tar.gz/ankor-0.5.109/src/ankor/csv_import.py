import csv
import io
import json
from typing import Any

# Maps column type → callable(raw_string) → Python value
_COERCE_FN: dict[str, Any] = {
    "text":    str,
    "string":  str,
    "select":  str,
    "integer": lambda v: int(v) if v.strip().lstrip("-").isdigit() else round(float(v)),
    "float":   float,
    "boolean": lambda v: v.strip().lower() in ("1", "true", "yes"),
    "date":    str,  # stored as ISO string
    "json":    json.loads,
}


def _coerce(value: str, col_type: str) -> Any:
    """Coerce *value* to the Python type implied by *col_type*.

    Returns ``None`` for empty strings and the raw string on parse failure
    (best-effort — callers see errors via the ``errors`` list from
    :func:`parse_csv`, not exceptions).
    """
    if value == "":
        return None
    fn = _COERCE_FN.get(col_type)
    if fn is None:
        return value
    try:
        return fn(value)
    except (ValueError, TypeError, json.JSONDecodeError):
        return value


def parse_csv(
    content: str,
    columns: list[dict],
) -> tuple[list[dict], list[str]]:
    """Parse CSV *content* into a list of typed row dicts.

    Handles RFC 4180 quoting (embedded commas, newlines, ``""`` escapes) as
    well as the triple-quote JSON pattern emitted by some CRM exporters.

    Parameters
    ----------
    content:
        Raw CSV text.  Pass ``content.lstrip("\\ufeff")`` before calling if
        the source may be UTF-8-BOM (Excel).
    columns:
        List of ``{"id": ..., "name": ..., "type": ...}`` dicts matching the
        ``DbTable.columns`` schema.  ``name`` is optional; when present it is
        used as a fallback header-to-column mapping.

    Returns
    -------
    rows:
        ``[{col_id: coerced_value, ...}, ...]`` — one dict per data row.
    errors:
        Human-readable strings for rows/cells that could not be coerced.
        Import continues; callers decide whether to abort or skip.
    """
    col_type_by_id: dict[str, str] = {c["id"]: c.get("type", "text") for c in columns}
    # Also allow matching by display name (e.g. "Deal ID" → "deal_id")
    id_by_name: dict[str, str] = {
        c["name"]: c["id"] for c in columns if "name" in c
    }

    reader = csv.DictReader(io.StringIO(content))
    rows: list[dict] = []
    errors: list[str] = []

    for line_no, raw_row in enumerate(reader, start=2):
        row: dict[str, Any] = {}
        for header, raw_value in (raw_row or {}).items():
            if raw_value is None:
                raw_value = ""

            # Resolve header → column id
            col_id = header if header in col_type_by_id else id_by_name.get(header)
            if col_id is None:
                row[header] = raw_value  # unknown column: keep as-is
                continue

            col_type = col_type_by_id[col_id]
            try:
                row[col_id] = _coerce(raw_value, col_type)
            except Exception as exc:  # noqa: BLE001
                errors.append(f"Row {line_no}, column '{header}': {exc}")
                row[col_id] = raw_value
        rows.append(row)

    return rows, errors
