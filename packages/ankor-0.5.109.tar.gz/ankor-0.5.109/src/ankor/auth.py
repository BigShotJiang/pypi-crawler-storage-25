import hmac
import secrets
import string
from datetime import datetime, timedelta, timezone

import bcrypt
from jose import jwt

_WEBHOOK_TOKEN_ALPHABET = string.ascii_letters + string.digits


def generate_webhook_token() -> str:
    return "".join(secrets.choice(_WEBHOOK_TOKEN_ALPHABET) for _ in range(24))


def verify_webhook_token(provided: str, stored: str) -> bool:
    return hmac.compare_digest(provided, stored)

_secret: str = ""


def configure(secret: str) -> None:
    global _secret
    _secret = secret


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode(), hashed.encode())


def create_access_token(subject: str, expire_minutes: int = 60 * 24) -> str:
    expire = datetime.now(timezone.utc) + timedelta(minutes=expire_minutes)
    return jwt.encode({"sub": subject, "exp": expire}, _secret, algorithm="HS256")


def create_api_token(subject: str, token_id: str, expire_days: int | None = None) -> str:
    payload: dict = {"sub": subject, "jti": token_id, "type": "api"}
    if expire_days is not None:
        payload["exp"] = datetime.now(timezone.utc) + timedelta(days=expire_days)
    return jwt.encode(payload, _secret, algorithm="HS256")


def decode_token(token: str) -> str | None:
    try:
        payload = jwt.decode(token, _secret, algorithms=["HS256"])
        return payload.get("sub")
    except Exception:
        return None
