"""Programmatic read/write access to the Config store.

Exposed as ``gtm.config`` on a ``ankor`` instance so that workflow and
node functions can read configuration values without going through the HTTP
API.

Example::

    @gtm.workflow
    async def my_workflow(inputs: dict):
        retries = await gtm.config.get_typed("max.retries")   # → 3  (int)
        name    = await gtm.config.get("app.name")            # → "ANKOR"
        ...
"""

from __future__ import annotations

import json
from datetime import date, datetime, time
from typing import Any


def _coerce(value: str, type_: str) -> Any:
    """Cast the stored string *value* to the declared Python type."""
    if type_ == "number":
        try:
            return int(value)
        except ValueError:
            return float(value)
    if type_ == "date":
        return date.fromisoformat(value)
    if type_ == "datetime":
        return datetime.fromisoformat(value)
    if type_ == "time":
        return time.fromisoformat(value)
    if type_ == "json":
        return json.loads(value)
    return value  # string, select


def _to_dict(record: Any) -> dict:
    return {
        "id": str(record.id),
        "key": record.key,
        "value": record.value,
        "type": record.type,
        "select_options": record.select_options,
        "description": record.description,
        "folder": record.folder,
        "created_at": record.created_at,
        "updated_at": record.updated_at,
    }


class ConfigStore:
    """Thin async wrapper around :class:`~ankor.models.ConfigRecord`.

    Attached to ``ankor`` as ``gtm.config``.
    """

    # ── Read ─────────────────────────────────────────────────────────────────

    async def get(self, key: str) -> str | None:
        """Return the raw stored string for *key*, or ``None`` if not found."""
        from sqlmodel import select

        from .database import _SessionLocal
        from .models import ConfigRecord

        if _SessionLocal is None:
            return None
        async with _SessionLocal() as session:
            result = await session.exec(
                select(ConfigRecord).where(ConfigRecord.key == key)
            )
            record = result.first()
        return record.value if record else None

    async def get_typed(self, key: str) -> Any:
        """Return the value coerced to its declared Python type.

        Type mapping:

        * ``string`` / ``select`` → ``str``
        * ``number``              → ``int`` (falls back to ``float``)
        * ``date``                → :class:`datetime.date`
        * ``datetime``            → :class:`datetime.datetime`
        * ``time``                → :class:`datetime.time`
        * ``json``                → parsed object (``dict`` / ``list`` / …)

        Returns ``None`` if *key* does not exist.
        """
        from sqlmodel import select

        from .database import _SessionLocal
        from .models import ConfigRecord

        if _SessionLocal is None:
            return None
        async with _SessionLocal() as session:
            result = await session.exec(
                select(ConfigRecord).where(ConfigRecord.key == key)
            )
            record = result.first()
        if record is None:
            return None
        return _coerce(record.value, record.type)

    async def all(self) -> list[dict]:
        """Return every config record as a plain ``dict``.

        Keys: ``id``, ``key``, ``value``, ``type``, ``select_options``,
        ``description``, ``folder``, ``created_at``, ``updated_at``.
        """
        from sqlmodel import select

        from .database import _SessionLocal
        from .models import ConfigRecord

        if _SessionLocal is None:
            return []
        async with _SessionLocal() as session:
            records = (await session.exec(select(ConfigRecord))).all()
        return [_to_dict(r) for r in records]

    # ── Write ────────────────────────────────────────────────────────────────

    async def set(self, key: str, value: str) -> None:
        """Update the stored string value for an existing config record.

        Only the ``value`` field is changed; ``type`` and all metadata are
        preserved.  Raises :class:`KeyError` if *key* does not exist.
        """
        from datetime import timezone

        from sqlmodel import select

        from .database import _SessionLocal
        from .models import ConfigRecord

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        async with _SessionLocal() as session:
            result = await session.exec(
                select(ConfigRecord).where(ConfigRecord.key == key)
            )
            record = result.first()
            if record is None:
                raise KeyError(f"Config key {key!r} not found.")
            record.value = str(value)
            record.updated_at = datetime.now(timezone.utc)
            session.add(record)
            await session.commit()
