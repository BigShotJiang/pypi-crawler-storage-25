from __future__ import annotations

import asyncio
from datetime import datetime

from sqlalchemy import delete as sa_delete
from sqlmodel import select

from ..database import _SessionLocal
from ..models import RunNode, WorkflowRun, WorkflowStatus
from ._context import _pending_db_saves
from ._serialization import _json_safe

_SNAPSHOT_DELAY = 0.5


def _node_kwargs(action: dict) -> dict:
    """Extract promoted column values from an action dict."""
    raw_started = action.get("started_at")
    started_at: datetime | None = None
    if isinstance(raw_started, str) and raw_started:
        try:
            from datetime import timezone as _tz

            dt = datetime.fromisoformat(raw_started)
            started_at = dt if dt.tzinfo is not None else dt.replace(tzinfo=_tz.utc)
        except ValueError:
            started_at = None
    elif isinstance(raw_started, datetime):
        started_at = raw_started

    status_raw = action.get("status")
    try:
        status = WorkflowStatus(status_raw) if status_raw else WorkflowStatus.pending
    except ValueError:
        status = WorkflowStatus.pending

    return dict(
        name=action.get("name") or "",
        slug=action.get("slug"),
        status=status,
        duration_ms=action.get("duration_ms") or 0,
        started_at=started_at,
        child_run_id=action.get("child_run_id"),
    )


async def _insert_nodes_recursive(
    session,
    run_id: int,
    actions: list,
    parent_node_id: int | None = None,
    depth: int = 0,
) -> None:
    """Recursively insert RunNode rows, flushing to get IDs before inserting children."""
    if depth >= 5:
        return
    for action in actions:
        node = RunNode(
            run_id=run_id,
            parent_node_id=parent_node_id,
            data={
                "inputs": _json_safe(action.get("inputs") or {}),
                "outputs": _json_safe(action.get("outputs") or {}),
                "logs": _json_safe(action.get("logs")),
            },
            **_node_kwargs(action),
        )
        session.add(node)
        await session.flush()  # populates node.id before children reference it
        children = action.get("children") or []
        if children:
            await _insert_nodes_recursive(session, run_id, children, node.id, depth + 1)


async def _persist_run_snapshot(run_id: int, ctx: dict) -> None:
    if _SessionLocal is None:
        return
    async with _SessionLocal() as session:
        run = await session.get(WorkflowRun, run_id)
        if run is not None and run.status == WorkflowStatus.running:
            run.data = {
                **(run.data or {}),
                "logs": _json_safe(ctx["logs"]),
            }
            session.add(run)
            await session.execute(sa_delete(RunNode).where(RunNode.run_id == run_id))
            await _insert_nodes_recursive(session, run_id, ctx["actions"])
            await session.commit()


def _schedule_snapshot(run_id: int, ctx: dict, delay: float = _SNAPSHOT_DELAY) -> None:
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        return
    existing = _pending_db_saves.get(run_id)
    if existing and not existing.done():
        existing.cancel()

    async def _save():
        await asyncio.sleep(delay)
        await _persist_run_snapshot(run_id, ctx)

    _pending_db_saves[run_id] = loop.create_task(_save())
