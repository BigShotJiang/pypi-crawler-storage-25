"""Add 'actions' column to data_tables for storing associated workflow slugs.

Revision ID: 0025
Revises: 0024
Create Date: 2026-04-19
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0025"
down_revision: Union[str, None] = "0024"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_tables",
        sa.Column("actions", sa.JSON(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("data_tables", "actions")
