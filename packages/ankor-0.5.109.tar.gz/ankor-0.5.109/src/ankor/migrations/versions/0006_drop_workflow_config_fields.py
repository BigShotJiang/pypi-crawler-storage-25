"""Drop description and tags columns from workflow_configs.

Revision ID: 0006
Revises: 0005
Create Date: 2026-04-07
"""
from typing import Sequence, Union

import sqlalchemy as sa
import sqlmodel
from alembic import op

revision: str = "0006"
down_revision: Union[str, None] = "0005"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.drop_column("workflow_configs", "description")
    op.drop_column("workflow_configs", "tags")


def downgrade() -> None:
    op.add_column("workflow_configs", sa.Column("tags", sa.JSON(), nullable=True))
    op.add_column("workflow_configs", sa.Column("description", sqlmodel.AutoString(), nullable=True))
