"""Add 'views' column to data_tables for storing saved filter views.

Revision ID: 0027
Revises: 0026
Create Date: 2026-04-21
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0027"
down_revision: Union[str, None] = "0026"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "data_tables",
        sa.Column("views", sa.JSON(), nullable=True),
    )


def downgrade() -> None:
    op.drop_column("data_tables", "views")
