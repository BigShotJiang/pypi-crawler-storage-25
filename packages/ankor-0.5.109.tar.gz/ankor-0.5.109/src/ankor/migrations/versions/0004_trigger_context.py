"""Add trigger_context column to workflow_runs.

Revision ID: 0004
Revises: 0003
Create Date: 2026-04-06
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0004"
down_revision: Union[str, None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "workflow_runs",
        sa.Column("trigger_context", sa.JSON(), nullable=True),
    )
    op.execute("UPDATE workflow_runs SET trigger_context = '{}'::jsonb WHERE trigger_context IS NULL")
    op.alter_column("workflow_runs", "trigger_context", nullable=False)


def downgrade() -> None:
    op.drop_column("workflow_runs", "trigger_context")
