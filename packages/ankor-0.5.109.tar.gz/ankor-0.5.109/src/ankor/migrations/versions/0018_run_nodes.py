"""Extract workflow run node execution data into a dedicated run_nodes table.

Each top-level entry from workflow_runs.data['actions'] (or 'nodes') becomes
a separate row in run_nodes, keyed by run_id.  The workflow_runs.data column
no longer stores actions/nodes, keeping it small and query-friendly.

Revision ID: 0018
Revises: 0017
Create Date: 2026-04-16
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0018"
down_revision: Union[str, None] = "0017"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "run_nodes",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("run_id", sa.Integer(), nullable=False),
        sa.Column("data", sa.JSON(), nullable=False, server_default="{}"),
        sa.ForeignKeyConstraint(["run_id"], ["workflow_runs.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_run_nodes_run_id", "run_nodes", ["run_id"])

    conn = op.get_bind()

    # Migrate existing top-level action entries into run_nodes rows.
    conn.execute(
        sa.text(
            """
        INSERT INTO run_nodes (run_id, data)
        SELECT
            wr.id,
            action_elem
        FROM workflow_runs wr,
             json_array_elements(
                 COALESCE(
                     wr.data->'actions',
                     wr.data->'nodes',
                     '[]'::json
                 )
             ) AS action_elem
        WHERE wr.data IS NOT NULL
    """
        )
    )

    # Strip actions/nodes keys from workflow_runs.data to keep it compact.
    conn.execute(
        sa.text(
            """
        UPDATE workflow_runs
        SET data = ((data::jsonb - 'actions') - 'nodes')::json
        WHERE data IS NOT NULL
    """
        )
    )


def downgrade() -> None:
    conn = op.get_bind()

    # Re-embed nodes back into workflow_runs.data as the 'actions' key.
    conn.execute(
        sa.text(
            """
        UPDATE workflow_runs wr
        SET data = (data::jsonb || jsonb_build_object(
            'actions',
            COALESCE(
                (
                    SELECT jsonb_agg(rn.data::jsonb ORDER BY rn.id)
                    FROM run_nodes rn
                    WHERE rn.run_id = wr.id
                ),
                '[]'::jsonb
            )
        ))::json
        WHERE data IS NOT NULL
    """
        )
    )

    op.drop_index("ix_run_nodes_run_id", table_name="run_nodes")
    op.drop_table("run_nodes")
