"""Remove columns JSON blob from data_tables; add data_table_column_meta for
select option metadata. Column definitions are now stored exclusively in the
PostgreSQL catalog (information_schema.columns).

Existing tables have their col-N identifiers renamed to the human-readable
names stored in the old columns JSON.

Revision ID: 0014
Revises: 0013
Create Date: 2026-04-08
"""
from __future__ import annotations

import json
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0014"
down_revision: Union[str, None] = "0013"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "data_table_column_meta",
        sa.Column("table_id", sa.Integer(), nullable=False),
        sa.Column("column_name", sa.Text(), nullable=False),
        sa.Column("select_options", sa.JSON(), nullable=True),
        sa.ForeignKeyConstraint(["table_id"], ["data_tables.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("table_id", "column_name"),
    )

    conn = op.get_bind()

    rows = conn.execute(sa.text("SELECT id, columns FROM data_tables")).fetchall()

    for row in rows:
        table_id = row[0]
        columns = row[1] or []
        tbl = f"data_table_{table_id}"

        tbl_exists = conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.tables "
                "WHERE table_name = :tbl AND table_schema = 'public'"
            ),
            {"tbl": tbl},
        ).fetchone()
        if not tbl_exists:
            continue

        for col in columns:
            old_name = col.get("id", "")
            new_name = col.get("name", old_name)
            if old_name and old_name != new_name:
                col_exists = conn.execute(
                    sa.text(
                        "SELECT 1 FROM information_schema.columns "
                        "WHERE table_name = :tbl AND column_name = :cn AND table_schema = 'public'"
                    ),
                    {"tbl": tbl, "cn": old_name},
                ).fetchone()
                if col_exists:
                    conn.execute(
                        sa.text(f'ALTER TABLE "{tbl}" RENAME COLUMN "{old_name}" TO "{new_name}"')
                    )

        for col in columns:
            col_name = col.get("name", col.get("id", ""))
            if col.get("type") == "select" and col.get("selectOptions") and col_name:
                conn.execute(
                    sa.text(
                        "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                        "VALUES (:tid, :cn, CAST(:opts AS json))"
                    ),
                    {"tid": table_id, "cn": col_name, "opts": json.dumps(col["selectOptions"])},
                )

    op.drop_column("data_tables", "columns")


def downgrade() -> None:
    op.add_column("data_tables", sa.Column("columns", sa.JSON(), nullable=True))
    op.drop_table("data_table_column_meta")
