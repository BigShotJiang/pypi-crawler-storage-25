"""Consolidate workflow_runs.nodes + trigger_context into a single data JSON column.

The new `data` column stores everything related to a run's execution:
  {
    "trigger_context": {...},
    "nodes": [...],
    "inputs": {...},   # workflow-level inputs
    "outputs": {...},  # workflow-level outputs
  }

Revision ID: 0011
Revises: 0010
Create Date: 2026-04-07
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0011"
down_revision: Union[str, None] = "0010"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    op.add_column("workflow_runs", sa.Column("data", sa.JSON(), nullable=True))

    conn.execute(sa.text("""
        UPDATE workflow_runs
        SET data = jsonb_build_object(
            'trigger_context', COALESCE(trigger_context, '{}'),
            'nodes',           COALESCE(nodes, '[]'),
            'inputs',          '{}',
            'outputs',         '{}'
        )
    """))

    op.alter_column("workflow_runs", "data", nullable=False)
    op.drop_column("workflow_runs", "nodes")
    op.drop_column("workflow_runs", "trigger_context")


def downgrade() -> None:
    conn = op.get_bind()

    op.add_column("workflow_runs", sa.Column("nodes", sa.JSON(), nullable=True))
    op.add_column("workflow_runs", sa.Column("trigger_context", sa.JSON(), nullable=True))

    conn.execute(sa.text("""
        UPDATE workflow_runs
        SET nodes           = COALESCE(data->'nodes', '[]'),
            trigger_context = COALESCE(data->'trigger_context', '{}')
    """))

    op.drop_column("workflow_runs", "data")
