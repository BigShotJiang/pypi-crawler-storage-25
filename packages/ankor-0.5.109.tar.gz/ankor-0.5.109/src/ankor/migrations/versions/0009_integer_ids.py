"""Replace UUID primary keys with auto-increment integers.

Affects: workflow_runs, config_records, db_tables, api_tokens.

NOTE: This migration drops and recreates these four tables.  Any existing
data in them will be lost.  Re-seed after upgrading (make seed).

Revision ID: 0009
Revises: 0008
Create Date: 2026-04-07
"""
from typing import Sequence, Union

import sqlalchemy as sa
import sqlmodel
from alembic import op

revision: str = "0009"
down_revision: Union[str, None] = "0008"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # api_tokens references workflow_runs indirectly via users; drop it first.
    op.drop_table("api_tokens")

    # workflow_runs has a self-referential FK (parent_id → id).
    op.drop_index("ix_workflow_runs_parent_id", table_name="workflow_runs")
    op.drop_table("workflow_runs")

    op.drop_table("config_records")
    op.drop_table("db_tables")

    # The workflowstatus enum type outlives the table in PostgreSQL — drop it
    # explicitly so the CREATE TABLE below can recreate it cleanly.
    op.execute("DROP TYPE IF EXISTS workflowstatus")

    # Recreate with SERIAL (auto-increment integer) primary keys.
    op.create_table(
        "workflow_runs",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column(
            "status",
            sa.Enum("pending", "running", "success", "failed", name="workflowstatus"),
            nullable=False,
            server_default="pending",
        ),
        sa.Column("triggered_by", sqlmodel.AutoString(), nullable=False, server_default="manual"),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("parent_id", sa.Integer(), nullable=True),
        sa.Column("nodes", sa.JSON(), nullable=True),
        sa.Column("trigger_context", sa.JSON(), nullable=True),
        sa.ForeignKeyConstraint(["parent_id"], ["workflow_runs.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_workflow_runs_parent_id", "workflow_runs", ["parent_id"])

    op.create_table(
        "config_records",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("key", sqlmodel.AutoString(), nullable=False),
        sa.Column("value", sqlmodel.AutoString(), nullable=False),
        sa.Column("type", sqlmodel.AutoString(), nullable=False),
        sa.Column("select_options", sa.JSON(), nullable=True),
        sa.Column("description", sqlmodel.AutoString(), nullable=True),
        sa.Column("folder", sqlmodel.AutoString(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("key"),
    )
    op.create_index("ix_config_records_key", "config_records", ["key"])

    op.create_table(
        "db_tables",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column("description", sqlmodel.AutoString(), nullable=True),
        sa.Column("columns", sa.JSON(), nullable=True),
        sa.Column("rows", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "api_tokens",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column("username", sqlmodel.AutoString(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["username"], ["users.username"]),
        sa.PrimaryKeyConstraint("id"),
    )


def downgrade() -> None:
    op.drop_table("api_tokens")
    op.drop_index("ix_workflow_runs_parent_id", table_name="workflow_runs")
    op.drop_table("workflow_runs")
    op.drop_table("config_records")
    op.drop_table("db_tables")

    op.execute("DROP TYPE IF EXISTS workflowstatus")

    # Restore UUID-based tables (data will still be lost).
    op.create_table(
        "workflow_runs",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column(
            "status",
            sa.Enum("pending", "running", "success", "failed", name="workflowstatus"),
            nullable=False,
            server_default="pending",
        ),
        sa.Column("triggered_by", sqlmodel.AutoString(), nullable=False, server_default="manual"),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("finished_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("parent_id", sa.Uuid(), nullable=True),
        sa.Column("nodes", sa.JSON(), nullable=True),
        sa.Column("trigger_context", sa.JSON(), nullable=True),
        sa.ForeignKeyConstraint(["parent_id"], ["workflow_runs.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("ix_workflow_runs_parent_id", "workflow_runs", ["parent_id"])

    op.create_table(
        "config_records",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("key", sqlmodel.AutoString(), nullable=False),
        sa.Column("value", sqlmodel.AutoString(), nullable=False),
        sa.Column("type", sqlmodel.AutoString(), nullable=False),
        sa.Column("select_options", sa.JSON(), nullable=True),
        sa.Column("description", sqlmodel.AutoString(), nullable=True),
        sa.Column("folder", sqlmodel.AutoString(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("key"),
    )
    op.create_index("ix_config_records_key", "config_records", ["key"])

    op.create_table(
        "db_tables",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column("description", sqlmodel.AutoString(), nullable=True),
        sa.Column("columns", sa.JSON(), nullable=True),
        sa.Column("rows", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "api_tokens",
        sa.Column("id", sa.Uuid(), nullable=False),
        sa.Column("name", sqlmodel.AutoString(), nullable=False),
        sa.Column("username", sqlmodel.AutoString(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(["username"], ["users.username"]),
        sa.PrimaryKeyConstraint("id"),
    )
