"""Add folder column to workflows table.

Revision ID: 0021
Revises: 0020
Create Date: 2026-04-18
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0021"
down_revision: Union[str, None] = "0020"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("workflows", sa.Column("folder", sa.String(), nullable=True))


def downgrade() -> None:
    op.drop_column("workflows", "folder")
