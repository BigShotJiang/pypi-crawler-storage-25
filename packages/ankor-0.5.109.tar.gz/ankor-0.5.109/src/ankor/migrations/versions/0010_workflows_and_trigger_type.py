"""Rename workflow_configs → workflows (integer PK); add workflow_id FK to
workflow_runs replacing the name column; convert triggered_by to a PostgreSQL
enum type (triggertype).

Any existing data is migrated in-place.  workflow_runs rows whose name has no
corresponding workflows row get a new one inserted automatically.

NOTE: downgrade re-creates the old schema but data is lost.

Revision ID: 0010
Revises: 0009
Create Date: 2026-04-07
"""
from typing import Sequence, Union

import sqlalchemy as sa
import sqlmodel
from alembic import op

revision: str = "0010"
down_revision: Union[str, None] = "0009"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    # ── 1. Rename workflow_configs → workflows ─────────────────────────────
    op.rename_table("workflow_configs", "workflows")

    # ── 2. Drop the old string primary key; add integer surrogate PK ───────
    # PostgreSQL keeps the old PK constraint under the original table name.
    conn.execute(sa.text("ALTER TABLE workflows DROP CONSTRAINT IF EXISTS workflow_configs_pkey"))
    conn.execute(sa.text("ALTER TABLE workflows ADD COLUMN id SERIAL NOT NULL"))
    conn.execute(sa.text("ALTER TABLE workflows ADD PRIMARY KEY (id)"))
    op.create_unique_constraint("uq_workflows_name", "workflows", ["name"])

    # ── 3. Ensure a workflows row exists for every name in workflow_runs ────
    conn.execute(sa.text("""
        INSERT INTO workflows (name, enabled, created_at, updated_at)
        SELECT DISTINCT wr.name, TRUE, now(), now()
        FROM workflow_runs wr
        WHERE NOT EXISTS (
            SELECT 1 FROM workflows w WHERE w.name = wr.name
        )
    """))

    # ── 4. Add workflow_id FK column (nullable first for data migration) ────
    op.add_column("workflow_runs", sa.Column("workflow_id", sa.Integer(), nullable=True))
    conn.execute(sa.text("""
        UPDATE workflow_runs wr
        SET workflow_id = w.id
        FROM workflows w
        WHERE w.name = wr.name
    """))
    op.alter_column("workflow_runs", "workflow_id", nullable=False)
    op.create_foreign_key(
        "fk_workflow_runs_workflow_id", "workflow_runs",
        "workflows", ["workflow_id"], ["id"],
    )

    # ── 5. Drop the old name column from workflow_runs ─────────────────────
    op.drop_column("workflow_runs", "name")

    # ── 6. Convert triggered_by TEXT → triggertype enum ───────────────────
    # Normalise any non-standard historical values before casting.
    conn.execute(sa.text("""
        UPDATE workflow_runs
        SET triggered_by = 'manual'
        WHERE triggered_by NOT IN ('manual', 'cron', 'webhook', 'rerun')
    """))
    conn.execute(sa.text("CREATE TYPE triggertype AS ENUM ('manual', 'cron', 'webhook', 'rerun')"))
    # Drop the string default before changing the column type; PostgreSQL cannot
    # cast the stored default 'manual' (text) automatically to the new enum type.
    conn.execute(sa.text("ALTER TABLE workflow_runs ALTER COLUMN triggered_by DROP DEFAULT"))
    conn.execute(sa.text("""
        ALTER TABLE workflow_runs
        ALTER COLUMN triggered_by TYPE triggertype
        USING triggered_by::triggertype
    """))
    conn.execute(sa.text("ALTER TABLE workflow_runs ALTER COLUMN triggered_by SET DEFAULT 'manual'::triggertype"))


def downgrade() -> None:
    conn = op.get_bind()

    # ── Restore triggered_by as plain TEXT ────────────────────────────────
    conn.execute(sa.text("""
        ALTER TABLE workflow_runs
        ALTER COLUMN triggered_by TYPE VARCHAR
        USING triggered_by::VARCHAR
    """))
    conn.execute(sa.text("ALTER TABLE workflow_runs ALTER COLUMN triggered_by SET DEFAULT 'manual'"))
    conn.execute(sa.text("DROP TYPE IF EXISTS triggertype"))

    # ── Restore name column in workflow_runs ──────────────────────────────
    op.add_column("workflow_runs", sa.Column("name", sqlmodel.AutoString(), nullable=True))
    conn.execute(sa.text("""
        UPDATE workflow_runs wr
        SET name = w.name
        FROM workflows w
        WHERE w.id = wr.workflow_id
    """))
    op.alter_column("workflow_runs", "name", nullable=False)
    op.drop_constraint("fk_workflow_runs_workflow_id", "workflow_runs", type_="foreignkey")
    op.drop_column("workflow_runs", "workflow_id")

    # ── Restore workflow_configs table with name as PK ────────────────────
    op.drop_constraint("uq_workflows_name", "workflows", type_="unique")
    conn.execute(sa.text("ALTER TABLE workflows DROP COLUMN id"))
    conn.execute(sa.text("ALTER TABLE workflows ADD PRIMARY KEY (name)"))
    op.rename_table("workflows", "workflow_configs")
