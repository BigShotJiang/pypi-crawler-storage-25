"""Add email and role columns to users table; create userrole enum type.

Revision ID: 0015
Revises: 0014
Create Date: 2026-04-14
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0015"
down_revision: Union[str, None] = "0014"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # Create the userrole enum type first
    op.execute("CREATE TYPE userrole AS ENUM ('admin')")

    op.add_column("users", sa.Column("email", sa.String(), nullable=True))
    op.add_column(
        "users",
        sa.Column(
            "role",
            sa.Enum("admin", name="userrole", create_type=False),
            nullable=False,
            server_default="admin",
        ),
    )


def downgrade() -> None:
    op.drop_column("users", "role")
    op.drop_column("users", "email")
    op.execute("DROP TYPE IF EXISTS userrole")
