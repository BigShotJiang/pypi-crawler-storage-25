"""Add created_at and updated_at system columns to all existing data_table_* tables.
New tables are created with these columns by default from this point on.

Revision ID: 0016
Revises: 0015
Create Date: 2026-04-09
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0016"
down_revision: Union[str, None] = "0015"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    table_ids = [
        row[0]
        for row in conn.execute(sa.text("SELECT id FROM data_tables ORDER BY id")).fetchall()
    ]

    for table_id in table_ids:
        tbl = f"data_table_{table_id}"
        tbl_exists = conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.tables "
                "WHERE table_name = :tbl AND table_schema = 'public'"
            ),
            {"tbl": tbl},
        ).fetchone()
        if not tbl_exists:
            continue

        for col in ("created_at", "updated_at"):
            col_exists = conn.execute(
                sa.text(
                    "SELECT 1 FROM information_schema.columns "
                    "WHERE table_name = :tbl AND column_name = :col AND table_schema = 'public'"
                ),
                {"tbl": tbl, "col": col},
            ).fetchone()
            if not col_exists:
                conn.execute(
                    sa.text(
                        f'ALTER TABLE "{tbl}" ADD COLUMN "{col}" TIMESTAMPTZ NOT NULL DEFAULT NOW()'
                    )
                )


def downgrade() -> None:
    conn = op.get_bind()
    table_ids = [
        row[0]
        for row in conn.execute(sa.text("SELECT id FROM data_tables ORDER BY id")).fetchall()
    ]
    for table_id in table_ids:
        tbl = f"data_table_{table_id}"
        for col in ("created_at", "updated_at"):
            conn.execute(sa.text(f'ALTER TABLE "{tbl}" DROP COLUMN IF EXISTS "{col}"'))
