"""Replace JSON-blob db_tables with a real-table registry (data_tables) and
per-table PostgreSQL relations (data_table_{id}).

Each user-defined table is stored in its own PostgreSQL table named
``data_table_{id}``.  The ``data_tables`` registry holds metadata
(name, description, column schema JSON).

Revision ID: 0013
Revises: 5aba83f071b2
Create Date: 2026-04-08
"""
from __future__ import annotations

import json
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0013"
down_revision: Union[str, None] = "5aba83f071b2"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_PG_TYPE_MAP = {
    "text": "TEXT",
    "number": "NUMERIC",
    "boolean": "BOOLEAN",
    "date": "DATE",
    "select": "TEXT",
    "json": "JSONB",
}


def upgrade() -> None:
    op.create_table(
        "data_tables",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("columns", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )

    conn = op.get_bind()

    old_rows = conn.execute(
        sa.text("SELECT id, name, description, columns, rows, created_at, updated_at FROM db_tables")
    ).fetchall()

    for old in old_rows:
        columns = old.columns if old.columns is not None else []
        rows = old.rows if old.rows is not None else []

        new_id = conn.execute(
            sa.text(
                "INSERT INTO data_tables (name, description, columns, created_at, updated_at) "
                "VALUES (:name, :desc, CAST(:cols AS json), :ca, :ua) RETURNING id"
            ),
            {
                "name": old.name,
                "desc": old.description,
                "cols": json.dumps(columns),
                "ca": old.created_at,
                "ua": old.updated_at,
            },
        ).scalar()

        tbl = f"data_table_{new_id}"
        col_defs = ["id INTEGER NOT NULL"] + [
            f'"{c["id"]}" {_PG_TYPE_MAP.get(c.get("type", "text"), "TEXT")}'
            for c in columns
        ]
        conn.execute(sa.text(f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))"))

        col_ids = {c["id"] for c in columns}
        for data_row in rows:
            if not data_row:
                continue
            row_id = data_row.get("id")
            if row_id is None:
                continue
            data = {k: v for k, v in data_row.items() if k != "id" and k in col_ids}
            if data:
                col_clause = ", ".join(f'"{k}"' for k in data)
                val_clause = ", ".join(f":v{i}" for i in range(len(data)))
                params = {"row_id": int(row_id), **{f"v{i}": v for i, v in enumerate(data.values())}}
                conn.execute(
                    sa.text(f"INSERT INTO {tbl} (id, {col_clause}) VALUES (:row_id, {val_clause})"),
                    params,
                )
            else:
                conn.execute(sa.text(f"INSERT INTO {tbl} (id) VALUES (:row_id)"), {"row_id": int(row_id)})

    op.drop_table("db_tables")


def downgrade() -> None:
    conn = op.get_bind()
    tbl_ids = [r[0] for r in conn.execute(sa.text("SELECT id FROM data_tables")).fetchall()]
    for tbl_id in tbl_ids:
        conn.execute(sa.text(f"DROP TABLE IF EXISTS data_table_{tbl_id}"))

    op.drop_table("data_tables")

    op.create_table(
        "db_tables",
        sa.Column("id", sa.Integer(), autoincrement=True, nullable=False),
        sa.Column("name", sa.Text(), nullable=False),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("columns", sa.JSON(), nullable=True),
        sa.Column("rows", sa.JSON(), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )
