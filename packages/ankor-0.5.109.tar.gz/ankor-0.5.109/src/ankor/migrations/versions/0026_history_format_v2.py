"""Convert row history to new actions-based format (v2).

Old format (one entry per db.update_row call):
    {"wf_id": …, "wf_name": …, "node_id": …, "date": …, "state": {…}, "note": "…"}

New format (one entry per workflow run, actions list inside):
    {"wf_id": …, "wf_name": …, "date": …,
     "actions": [
         {"type": "row_update", "state": {…}, "date": "…"},
         {"type": "note",       "data":  "…",  "date": "…"},   # optional
     ]}

Consecutive old entries that share the same non-null wf_id are merged into a
single new entry so the history remains "one item per workflow run".

Revision ID: 0026
Revises: 0025
Create Date: 2026-04-19
"""

from __future__ import annotations

import json
from typing import Any, Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0026"
down_revision: Union[str, None] = "0025"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _is_new_format(entry: dict) -> bool:
    """Return True if the entry is already in the new actions-based format."""
    return "actions" in entry


def _convert_single(entry: dict) -> dict:
    """Convert one old-format entry to new format."""
    date = entry.get("date") or ""
    state = entry.get("state") or {}
    note = entry.get("note")
    actions: list[dict[str, Any]] = [
        {"type": "row_update", "state": state, "date": date}
    ]
    if note:
        actions.append({"type": "note", "data": note, "date": date})
    return {
        "wf_id": entry.get("wf_id"),
        "wf_name": entry.get("wf_name"),
        "date": date,
        "actions": actions,
    }


def _convert_history(raw_history: list[dict]) -> list[dict]:
    """Convert a full history array, merging consecutive same-wf_id old entries."""
    if not raw_history:
        return raw_history

    result: list[dict] = []
    i = 0
    while i < len(raw_history):
        entry = raw_history[i]

        # Already in new format — keep as-is.
        if _is_new_format(entry):
            result.append(entry)
            i += 1
            continue

        wf_id = entry.get("wf_id")

        if wf_id is None:
            # No run id — convert individually.
            result.append(_convert_single(entry))
            i += 1
            continue

        # Collect all *consecutive* old-format entries that share this wf_id.
        grouped = [entry]
        j = i + 1
        while j < len(raw_history):
            nxt = raw_history[j]
            if not _is_new_format(nxt) and nxt.get("wf_id") == wf_id:
                grouped.append(nxt)
                j += 1
            else:
                break

        # Build merged new-format entry.
        earliest_date = min((g.get("date") or "") for g in grouped)
        actions: list[dict[str, Any]] = []
        for g in grouped:
            g_date = g.get("date") or ""
            actions.append(
                {"type": "row_update", "state": g.get("state") or {}, "date": g_date}
            )
            if g.get("note"):
                actions.append({"type": "note", "data": g["note"], "date": g_date})

        result.append(
            {
                "wf_id": wf_id,
                "wf_name": entry.get("wf_name"),
                "date": earliest_date,
                "actions": actions,
            }
        )
        i = j

    return result


# ---------------------------------------------------------------------------
# Alembic upgrade / downgrade
# ---------------------------------------------------------------------------


def upgrade() -> None:
    conn = op.get_bind()

    # Find all dynamic data tables that have a history column.
    table_rows = conn.execute(
        sa.text(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema = 'public' "
            "  AND table_name ~ '^data_table_[0-9]+$' "
            "ORDER BY table_name"
        )
    ).fetchall()

    for (tbl,) in table_rows:
        has_history = conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.columns "
                "WHERE table_schema = 'public' AND table_name = :tbl AND column_name = 'history'"
            ),
            {"tbl": tbl},
        ).fetchone()
        if not has_history:
            continue

        rows = conn.execute(
            sa.text(f"SELECT id, history FROM \"{tbl}\" WHERE history != '[]'::jsonb")
        ).fetchall()

        for row_id, history_raw in rows:
            if history_raw is None:
                continue
            # history_raw may be a string or already a Python list depending on the driver.
            if isinstance(history_raw, str):
                try:
                    history = json.loads(history_raw)
                except (json.JSONDecodeError, ValueError):
                    continue
            else:
                history = history_raw  # already parsed by asyncpg / psycopg2

            if not isinstance(history, list) or not history:
                continue

            # Skip if already fully converted.
            if all(_is_new_format(e) for e in history):
                continue

            new_history = _convert_history(history)
            conn.execute(
                sa.text(
                    f'UPDATE "{tbl}" SET history = CAST(:h AS jsonb) WHERE id = :rid'
                ),
                {"h": json.dumps(new_history), "rid": row_id},
            )


def downgrade() -> None:
    """Downgrade is intentionally a no-op.

    Converting back to the old flat format would lose the merge semantics and
    is not needed for routine rollbacks.  The new format is backward-compatible
    enough to be read by the previous restore endpoint without data loss.
    """
    pass
