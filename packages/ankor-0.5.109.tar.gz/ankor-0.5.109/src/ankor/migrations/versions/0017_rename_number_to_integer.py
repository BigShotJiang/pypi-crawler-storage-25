"""Rename the 'number' (NUMERIC) column type to 'integer' (INTEGER) in all data_table_* tables.

Existing NUMERIC columns are converted to INTEGER; fractional values are rounded to
the nearest whole number.  The downgrade path casts back to NUMERIC to preserve
numeric storage (data is not lost).

Revision ID: 0017
Revises: 0016
Create Date: 2026-04-09
"""
from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0017"
down_revision: Union[str, None] = "0016"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _data_table_ids(conn: sa.engine.Connection) -> list[int]:
    return [
        row[0]
        for row in conn.execute(sa.text("SELECT id FROM data_tables ORDER BY id")).fetchall()
    ]


def _numeric_columns(conn: sa.engine.Connection, tbl: str) -> list[str]:
    """Return column names whose PostgreSQL type is NUMERIC in *tbl*."""
    rows = conn.execute(
        sa.text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_schema = 'public' AND table_name = :tbl "
            "AND udt_name = 'numeric' "
            "AND column_name NOT IN ('id', 'created_at', 'updated_at') "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    ).fetchall()
    return [r[0] for r in rows]


def upgrade() -> None:
    conn = op.get_bind()

    for table_id in _data_table_ids(conn):
        tbl = f"data_table_{table_id}"

        tbl_exists = conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.tables "
                "WHERE table_schema = 'public' AND table_name = :tbl"
            ),
            {"tbl": tbl},
        ).fetchone()
        if not tbl_exists:
            continue

        for col in _numeric_columns(conn, tbl):
            conn.execute(
                sa.text(
                    f'ALTER TABLE "{tbl}" '
                    f'ALTER COLUMN "{col}" TYPE BIGINT '
                    f'USING ROUND("{col}"::numeric)::bigint'
                )
            )


def downgrade() -> None:
    conn = op.get_bind()

    for table_id in _data_table_ids(conn):
        tbl = f"data_table_{table_id}"

        tbl_exists = conn.execute(
            sa.text(
                "SELECT 1 FROM information_schema.tables "
                "WHERE table_schema = 'public' AND table_name = :tbl"
            ),
            {"tbl": tbl},
        ).fetchone()
        if not tbl_exists:
            continue

        # Find BIGINT columns (int8) that were previously NUMERIC
        int_cols = conn.execute(
            sa.text(
                "SELECT column_name FROM information_schema.columns "
                "WHERE table_schema = 'public' AND table_name = :tbl "
                "AND udt_name = 'int8' "
                "AND column_name NOT IN ('id', 'created_at', 'updated_at') "
                "ORDER BY ordinal_position"
            ),

            {"tbl": tbl},
        ).fetchall()

        for (col,) in int_cols:
            conn.execute(
                sa.text(
                    f'ALTER TABLE "{tbl}" '
                    f'ALTER COLUMN "{col}" TYPE NUMERIC '
                    f'USING "{col}"::numeric'
                )
            )
