"""Refactor run_nodes: flatten child nodes into rows, add parent_node_id / slug /
child_run_id columns, convert status to workflowstatus enum, and slim data to
{inputs, outputs, logs} only.

Removes:
  action_id   — was the in-run counter id; DB primary key is now canonical
  children    — embedded JSON subtrees; each child becomes its own row

Adds:
  parent_node_id  — self-referential FK for tree structure
  slug            — promoted from data['slug']
  child_run_id    — promoted from data['child_run_id']

Alters:
  status  — VARCHAR → workflowstatus enum (reuses existing PG type)
  data    — trimmed to {inputs, outputs, logs}

Revision ID: 0020
Revises: 0019
Create Date: 2026-04-16
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0020"
down_revision: Union[str, None] = "0019"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

_VALID_STATUSES = {"pending", "running", "success", "failed", "cancelled"}


def _insert_children(
    conn,
    run_id: int,
    parent_node_id: int,
    children: list,
    depth: int,
) -> None:
    """Recursively insert child nodes as their own rows (max 5 levels)."""
    if depth >= 5 or not children:
        return
    for child in children:
        status = (child.get("status") or "pending").strip().lower()
        if status not in _VALID_STATUSES:
            status = "pending"
        duration_ms = child.get("duration_ms") or 0
        if isinstance(duration_ms, float):
            duration_ms = int(duration_ms)
        child_run_id = child.get("child_run_id")
        if child_run_id is not None:
            try:
                child_run_id = int(child_run_id)
            except (TypeError, ValueError):
                child_run_id = None
        # Parse started_at: asyncpg needs a datetime object, not a string.
        started_at_raw = child.get("started_at")
        started_at: datetime | None = None
        if started_at_raw:
            if isinstance(started_at_raw, datetime):
                started_at = started_at_raw
            else:
                try:
                    started_at = datetime.fromisoformat(str(started_at_raw))
                except (ValueError, TypeError):
                    pass
        child_data = json.dumps(
            {
                "inputs": child.get("inputs") or {},
                "outputs": child.get("outputs") or {},
                "logs": child.get("logs"),
            }
        )
        # Use (:param)::type syntax instead of CAST(:param AS type) — the CAST()
        # function form confuses the SQLAlchemy asyncpg dialect's named→positional
        # parameter rewriter, leaving the colon-prefixed names in the final SQL.
        result = conn.execute(
            sa.text(
                """
                INSERT INTO run_nodes
                    (run_id, parent_node_id, name, slug, status, duration_ms,
                     started_at, child_run_id, data)
                VALUES
                    (:run_id, :parent_id, :name, :slug,
                     (:status)::text::workflowstatus, :duration_ms, :started_at,
                     :child_run_id, (:data)::json)
                RETURNING id
            """
            ),
            {
                "run_id": run_id,
                "parent_id": parent_node_id,
                "name": child.get("name") or "",
                "slug": child.get("slug"),
                "status": status,
                "duration_ms": duration_ms,
                "started_at": started_at,
                "child_run_id": child_run_id,
                "data": child_data,
            },
        )
        new_id = result.fetchone()[0]
        grandchildren = child.get("children") or []
        if grandchildren:
            _insert_children(conn, run_id, new_id, grandchildren, depth + 1)


def upgrade() -> None:
    conn = op.get_bind()

    # ── 1. Add new columns ──────────────────────────────────────────────────
    op.add_column("run_nodes", sa.Column("parent_node_id", sa.Integer(), nullable=True))
    op.add_column("run_nodes", sa.Column("slug", sa.String(), nullable=True))
    op.add_column("run_nodes", sa.Column("child_run_id", sa.Integer(), nullable=True))

    # ── 2. Create FK + index for parent_node_id ─────────────────────────────
    op.create_foreign_key(
        "fk_run_nodes_parent_node_id",
        "run_nodes",
        "run_nodes",
        ["parent_node_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_index("ix_run_nodes_parent_node_id", "run_nodes", ["parent_node_id"])

    # ── 3. Backfill slug and child_run_id from data ──────────────────────────
    conn.execute(
        sa.text(
            """
        UPDATE run_nodes
        SET
            slug         = data->>'slug',
            child_run_id = CAST(NULLIF(data->>'child_run_id', '') AS int)
        WHERE data IS NOT NULL
    """
        )
    )

    # ── 4. Convert status VARCHAR → workflowstatus enum ─────────────────────
    # Normalise any stray values before casting.
    conn.execute(
        sa.text(
            """
        UPDATE run_nodes
        SET status = 'pending'
        WHERE status IS NULL
           OR status NOT IN ('pending', 'running', 'success', 'failed', 'cancelled')
    """
        )
    )
    conn.execute(
        sa.text(
            """
        ALTER TABLE run_nodes
        ALTER COLUMN status TYPE workflowstatus USING CAST(status AS workflowstatus)
    """
        )
    )

    # ── 5. Flatten embedded children into their own rows ────────────────────
    rows = conn.execute(
        sa.text(
            """
            SELECT id, run_id, data
            FROM   run_nodes
            WHERE  data IS NOT NULL
              AND  (CAST(data AS jsonb) -> 'children') IS NOT NULL
              AND  jsonb_array_length(CAST(data AS jsonb) -> 'children') > 0
        """
        )
    ).fetchall()

    for row in rows:
        node_id, run_id, data_raw = row
        data = json.loads(data_raw) if isinstance(data_raw, str) else data_raw
        children = data.get("children") or []
        if children:
            _insert_children(conn, run_id, node_id, children, depth=0)

    # ── 6. Slim data down to {inputs, outputs, logs} only ───────────────────
    conn.execute(
        sa.text(
            """
        UPDATE run_nodes
        SET data = CAST(jsonb_build_object(
                'inputs',  COALESCE(CAST(data AS jsonb) -> 'inputs',  '{}'),
                'outputs', COALESCE(CAST(data AS jsonb) -> 'outputs', '{}'),
                'logs',    CAST(data AS jsonb) -> 'logs'
            ) AS json)
        WHERE data IS NOT NULL
    """
        )
    )

    # ── 7. Drop action_id column ─────────────────────────────────────────────
    op.drop_column("run_nodes", "action_id")


def downgrade() -> None:
    conn = op.get_bind()

    # Re-add action_id
    op.add_column("run_nodes", sa.Column("action_id", sa.Integer(), nullable=True))

    # Delete all child rows (parent_node_id IS NOT NULL) — lossy but necessary
    conn.execute(sa.text("DELETE FROM run_nodes WHERE parent_node_id IS NOT NULL"))

    # Revert status enum → VARCHAR
    conn.execute(
        sa.text(
            """
        ALTER TABLE run_nodes
        ALTER COLUMN status TYPE VARCHAR USING CAST(status AS text)
    """
        )
    )

    # Drop new columns
    op.drop_index("ix_run_nodes_parent_node_id", table_name="run_nodes")
    op.drop_constraint("fk_run_nodes_parent_node_id", "run_nodes", type_="foreignkey")
    op.drop_column("run_nodes", "child_run_id")
    op.drop_column("run_nodes", "slug")
    op.drop_column("run_nodes", "parent_node_id")
