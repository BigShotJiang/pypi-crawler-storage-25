"""Add promoted metadata columns to run_nodes and backfill from JSON data.

These columns allow the /nodes list endpoint to filter and sort without
loading the heavy data JSONB field on every row.

Columns added:
  action_id   — in-run action counter id (data['id'])
  name        — node function name (data['name'])
  status      — execution status (data['status'])
  duration_ms — wall-clock duration in milliseconds (data['duration_ms'])
  started_at  — UTC timestamp when the node started (data['started_at'])

Revision ID: 0019
Revises: 0018
Create Date: 2026-04-16
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0019"
down_revision: Union[str, None] = "0018"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("run_nodes", sa.Column("action_id", sa.Integer(), nullable=True))
    op.add_column("run_nodes", sa.Column("name", sa.String(), nullable=True))
    op.add_column("run_nodes", sa.Column("status", sa.String(), nullable=True))
    op.add_column("run_nodes", sa.Column("duration_ms", sa.Integer(), nullable=True))
    op.add_column(
        "run_nodes",
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
    )

    # Backfill promoted columns from the existing data JSON.
    op.get_bind().execute(
        sa.text(
            """
        UPDATE run_nodes
        SET
            action_id  = (data->>'id')::int,
            name       = data->>'name',
            status     = data->>'status',
            duration_ms = (data->>'duration_ms')::int,
            started_at = (data->>'started_at')::timestamptz
        WHERE data IS NOT NULL
    """
        )
    )


def downgrade() -> None:
    op.drop_column("run_nodes", "started_at")
    op.drop_column("run_nodes", "duration_ms")
    op.drop_column("run_nodes", "status")
    op.drop_column("run_nodes", "name")
    op.drop_column("run_nodes", "action_id")
