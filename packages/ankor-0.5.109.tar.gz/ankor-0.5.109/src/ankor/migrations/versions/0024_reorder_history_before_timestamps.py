"""Reorder 'history' column to appear before 'created_at' and 'updated_at'
in all existing data_table_* tables by recreating them with the correct column order.

Revision ID: 0024
Revises: 0023
Create Date: 2026-04-19
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0024"
down_revision: Union[str, None] = "0023"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def _pg_type_from_info(udt_name: str, char_max_length: int | None) -> str:
    mapping = {
        "int4": "INTEGER",
        "int8": "BIGINT",
        "text": "TEXT",
        "bool": "BOOLEAN",
        "float8": "DOUBLE PRECISION",
        "float4": "REAL",
        "jsonb": "JSONB",
        "timestamptz": "TIMESTAMPTZ",
        "date": "DATE",
        "numeric": "NUMERIC",
    }
    if udt_name in mapping:
        return mapping[udt_name]
    if udt_name.startswith("varchar"):
        return f"VARCHAR({char_max_length})" if char_max_length else "VARCHAR"
    return udt_name.upper()


def upgrade() -> None:
    conn = op.get_bind()

    # Find all dynamic data tables.
    table_rows = conn.execute(
        sa.text(
            "SELECT table_name FROM information_schema.tables "
            "WHERE table_schema = 'public' "
            "  AND table_name ~ '^data_table_[0-9]+$' "
            "ORDER BY table_name"
        )
    ).fetchall()

    for (tbl,) in table_rows:
        col_rows = conn.execute(
            sa.text(
                """
                SELECT column_name, ordinal_position, column_default,
                       is_nullable, udt_name, character_maximum_length
                FROM information_schema.columns
                WHERE table_schema = 'public' AND table_name = :tbl
                ORDER BY ordinal_position
                """
            ),
            {"tbl": tbl},
        ).fetchall()

        col_names = [r[0] for r in col_rows]

        if "history" not in col_names:
            continue

        history_idx = col_names.index("history")
        ts_indices = [
            col_names.index(c) for c in ("created_at", "updated_at") if c in col_names
        ]

        if not ts_indices:
            continue

        # Skip if history already appears before all timestamp columns.
        if history_idx < min(ts_indices):
            continue

        # Build new column order: id, history, created_at, updated_at, [user cols]
        SYSTEM = {"id", "history", "created_at", "updated_at"}
        user_cols = [c for c in col_names if c not in SYSTEM]
        new_order = (
            ["id"]
            + (["history"] if "history" in col_names else [])
            + (["created_at"] if "created_at" in col_names else [])
            + (["updated_at"] if "updated_at" in col_names else [])
            + user_cols
        )

        col_info = {r[0]: r for r in col_rows}

        col_defs = []
        for cname in new_order:
            r = col_info[cname]
            typ = _pg_type_from_info(r[4], r[5])
            nullable = r[3] == "YES"
            default = r[2]

            defn = f'"{cname}" {typ}'
            if not nullable:
                defn += " NOT NULL"
            if default is not None:
                defn += f" DEFAULT {default}"
            col_defs.append(defn)

        col_defs_str = ", ".join(col_defs) + ", PRIMARY KEY (id)"
        tmp = f"{tbl}_tmp_reorder"

        conn.execute(sa.text(f'CREATE TABLE "{tmp}" ({col_defs_str})'))

        cols_quoted = ", ".join(f'"{c}"' for c in new_order)
        conn.execute(
            sa.text(
                f'INSERT INTO "{tmp}" ({cols_quoted}) SELECT {cols_quoted} FROM "{tbl}"'
            )
        )

        conn.execute(sa.text(f'DROP TABLE "{tbl}"'))
        conn.execute(sa.text(f'ALTER TABLE "{tmp}" RENAME TO "{tbl}"'))


def downgrade() -> None:
    # Reversing a column reorder is not worth the risk; this is a no-op.
    pass
