"""Add 'cancelled' value to the workflowstatus PostgreSQL enum.

Revision ID: 0012
Revises: 0011
Create Date: 2026-04-07
"""
from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0012"
down_revision: Union[str, None] = "0011"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()
    conn.execute(sa.text("ALTER TYPE workflowstatus ADD VALUE IF NOT EXISTS 'cancelled'"))


def downgrade() -> None:
    # PostgreSQL does not support removing enum values — this is a no-op.
    pass
