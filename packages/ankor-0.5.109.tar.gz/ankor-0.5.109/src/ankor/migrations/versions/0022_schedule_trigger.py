"""Merge cron + interval into a single 'schedule' trigger type.

- Adds 'schedule' value to the triggertype enum
- Migrates existing 'cron' triggered_by values → 'schedule'
- Removes 'cron' value from the triggertype enum
- Adds schedule_override column to workflows
- Drops cron_override and interval_override columns from workflows

Revision ID: 0022
Revises: 0021
Create Date: 2026-04-18
"""

from __future__ import annotations

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op

revision: str = "0022"
down_revision: Union[str, None] = "0021"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    conn = op.get_bind()

    # ── 1. Add 'schedule' to the triggertype enum ─────────────────────────
    conn.execute(sa.text("ALTER TYPE triggertype ADD VALUE IF NOT EXISTS 'schedule'"))

    # Commit so the new enum value is visible before we use it in UPDATE.
    conn.execute(sa.text("COMMIT"))

    # ── 2. Migrate existing 'cron' values to 'schedule' ───────────────────
    conn.execute(
        sa.text(
            """
        UPDATE workflow_runs
        SET triggered_by = 'schedule'::triggertype
        WHERE triggered_by = 'cron'::triggertype
    """
        )
    )

    # ── 3. schedule_override on workflows ─────────────────────────────────
    # Populate schedule_override from cron_override before dropping it.
    op.add_column(
        "workflows", sa.Column("schedule_override", sa.String(), nullable=True)
    )
    conn.execute(
        sa.text(
            """
        UPDATE workflows
        SET schedule_override = cron_override
        WHERE cron_override IS NOT NULL
    """
        )
    )

    # ── 4. Drop old columns ───────────────────────────────────────────────
    op.drop_column("workflows", "cron_override")
    op.drop_column("workflows", "interval_override")


def downgrade() -> None:
    conn = op.get_bind()

    # Restore cron_override / interval_override
    op.add_column("workflows", sa.Column("cron_override", sa.String(), nullable=True))
    op.add_column(
        "workflows", sa.Column("interval_override", sa.Integer(), nullable=True)
    )
    conn.execute(
        sa.text(
            """
        UPDATE workflows
        SET cron_override = schedule_override
        WHERE schedule_override IS NOT NULL
    """
        )
    )
    op.drop_column("workflows", "schedule_override")

    # Migrate 'schedule' back to 'cron' (best-effort; 'schedule' value stays in enum)
    conn.execute(
        sa.text(
            """
        UPDATE workflow_runs
        SET triggered_by = 'cron'::triggertype
        WHERE triggered_by = 'schedule'::triggertype
    """
        )
    )
