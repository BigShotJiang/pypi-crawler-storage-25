"""Programmatic read/write access to the DB tables.

Exposed as ``gtm.db`` on a ``ankor`` instance so that workflow and node
functions can query and mutate table rows without going through the HTTP API.

Each table is identified by its **name** (the ``name`` column of the
``data_tables`` registry). Rows are plain ``dict`` objects that always
contain an ``"id"`` key (integer) alongside any column values.

Example::

    @gtm.workflow
    async def sync_customers(inputs: dict):
        rows = await gtm.db.rows("Customers")
        for row in rows:
            if not row.get("col-6"):   # active == False
                await gtm.db.update_row("Customers", row["id"], {"col-6": True})
        new = await gtm.db.add_row("Customers", {"col-2": "Dana Lee", "col-6": True})
        return {"processed": len(rows), "new_id": new["id"]}
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from decimal import Decimal
from datetime import date, datetime, timezone
from typing import Any

from sqlalchemy import text


def _normalize_select_opts(opts: list | None) -> list[dict]:
    """Normalize select options to ``[{id, label, color?}]`` format.

    Accepts legacy plain-string lists ``["a", "b"]`` or partially-formed
    objects ``[{"label": "a"}]`` and always returns fully-formed objects.
    ``None`` or empty input returns ``[]``.
    """
    if not opts:
        return []
    result: list[dict] = []
    for i, opt in enumerate(opts):
        if isinstance(opt, str):
            result.append({"id": i + 1, "label": opt})
        elif isinstance(opt, dict):
            if "id" not in opt:
                result.append({**opt, "id": i + 1})
            else:
                result.append(opt)
    return result


@dataclass
class RowFilter:
    """A single filter clause for :meth:`DbStore.rows`.

    Supported operators:

    - ``eq`` / ``neq`` — equality / inequality (all types)
    - ``gt`` / ``gte`` / ``lt`` / ``lte`` — comparison (number, float, date)
    - ``contains`` / ``starts_with`` / ``ends_with`` — case-insensitive substring matching (text, select)
    """

    column: str
    op: str
    value: Any


@dataclass
class OrderBy:
    """Sort clause for :meth:`DbStore.rows`.

    ``direction`` must be ``"asc"`` or ``"desc"`` (case-insensitive).
    Defaults to ascending order.

    Example::

        from ankor import OrderBy

        rows = await gtm.db.rows("Deals", order_by=OrderBy("amount", "desc"))
    """

    column: str
    direction: str = "asc"


_FILTER_OPS: dict[str, str] = {
    "eq": "=",
    "neq": "!=",
    "gt": ">",
    "gte": ">=",
    "lt": "<",
    "lte": "<=",
}
_LIKE_OPS: frozenset[str] = frozenset({"contains", "starts_with", "ends_with"})
_ALL_FILTER_OPS: frozenset[str] = frozenset(_FILTER_OPS) | _LIKE_OPS
_ORDER_DIRECTIONS: frozenset[str] = frozenset({"asc", "desc"})


def _build_where(filters: list[RowFilter]) -> tuple[str, dict]:
    if not filters:
        return "", {}
    parts: list[str] = []
    params: dict[str, Any] = {}
    for i, f in enumerate(filters):
        if f.op not in _ALL_FILTER_OPS:
            raise ValueError(
                f"Unknown filter op {f.op!r}. Valid ops: {sorted(_ALL_FILTER_OPS)}"
            )
        col_q = _qi(f.column)
        p = f"fp{i}"
        if f.op in _FILTER_OPS:
            parts.append(f"{col_q} {_FILTER_OPS[f.op]} :{p}")
            params[p] = f.value
        elif f.op == "contains":
            parts.append(f"{col_q} ILIKE :{p}")
            params[p] = f"%{f.value}%"
        elif f.op == "starts_with":
            parts.append(f"{col_q} ILIKE :{p}")
            params[p] = f"{f.value}%"
        else:
            parts.append(f"{col_q} ILIKE :{p}")
            params[p] = f"%{f.value}"
    return " WHERE " + " AND ".join(parts), params


def _build_order_by(order_by: "OrderBy | None") -> str:
    """Return the ORDER BY expression (without the ORDER BY keyword)."""
    if order_by is None:
        return _qi("id")
    direction = order_by.direction.lower()
    if direction not in _ORDER_DIRECTIONS:
        raise ValueError(
            f"Invalid order direction {order_by.direction!r}. Use 'asc' or 'desc'."
        )
    return f"{_qi(order_by.column)} {direction.upper()}"


def _build_select_cols(columns: list[str] | None) -> str:
    """Return the SELECT column list. id is always included when columns are specified."""
    if not columns:
        return "*"
    # Preserve caller order; deduplicate id if explicitly passed
    seen: set[str] = {"id"}
    parts = [_qi("id")]
    for col in columns:
        if col not in seen:
            parts.append(_qi(col))
            seen.add(col)
    return ", ".join(parts)


def _qi(s: str) -> str:
    """Double-quote a PostgreSQL identifier to handle hyphens and special chars."""
    return '"' + s.replace('"', '""') + '"'


def _pg_table(table_id: int) -> str:
    return f"data_table_{table_id}"


_PG_TYPE_MAP: dict[str, str] = {
    "text": "TEXT",
    "integer": "BIGINT",
    "float": "DOUBLE PRECISION",
    "boolean": "BOOLEAN",
    "date": "DATE",
    "select": "BIGINT",
    "json": "JSONB",
}

_UDT_TO_FRONTEND_TYPE: dict[str, str] = {
    "text": "text",
    "varchar": "text",
    "bpchar": "text",
    "numeric": "integer",
    "int2": "integer",
    "int4": "integer",
    "int8": "integer",
    "float4": "float",
    "float8": "float",
    "bool": "boolean",
    "date": "date",
    "jsonb": "json",
    "json": "json",
}


def _normalize_row(mapping: Any, col_types: dict[str, str] | None = None) -> dict:
    result: dict[str, Any] = {}
    for k, v in mapping.items():
        if isinstance(v, Decimal):
            result[k] = float(v)
        elif isinstance(v, datetime):
            result[k] = v.isoformat()
        elif isinstance(v, date):
            result[k] = v.isoformat()
        elif isinstance(v, str) and (
            k == "history" or (col_types and col_types.get(k) == "json")
        ):
            try:
                result[k] = json.loads(v)
            except (json.JSONDecodeError, ValueError):
                result[k] = v
        else:
            result[k] = v
    return result


_SYSTEM_COLS = frozenset({"id", "created_at", "updated_at", "history"})

_BOOL_TRUE = frozenset({"true", "1", "yes", "on"})
_BOOL_FALSE = frozenset({"false", "0", "no", "off"})


def coerce_csv_value(raw: str, col_type: str) -> Any:
    """Coerce a raw CSV string to the appropriate Python type for a given column type."""
    if raw == "":
        return None
    if col_type == "integer":
        try:
            return int(raw) if "." not in raw else round(float(raw))
        except ValueError:
            return None
    if col_type == "float":
        try:
            return float(raw)
        except ValueError:
            return None
    if col_type == "boolean":
        lower = raw.strip().lower()
        if lower in _BOOL_TRUE:
            return True
        if lower in _BOOL_FALSE:
            return False
        return None
    if col_type == "date":
        s = raw.strip()
        try:
            # Accept full ISO datetime strings (e.g. "2024-01-15T09:00:00.000Z") or plain dates
            return (
                datetime.fromisoformat(s.rstrip("Z")).date()
                if "T" in s
                else date.fromisoformat(s)
            )
        except ValueError:
            return None
    if col_type == "json":
        try:
            json.loads(raw)
            return raw.strip()
        except json.JSONDecodeError:
            return raw.strip()
    return raw


async def _get_column_names(session: Any, tbl: str) -> list[str]:
    result = await session.execute(
        text(
            "SELECT column_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' "
            "AND column_name NOT IN ('id', 'created_at', 'updated_at', 'history') "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    return [row[0] for row in result]


async def _read_col_types(session: Any, tbl: str) -> dict[str, str]:
    """Return ``{column_name: frontend_type}`` for all non-system columns."""
    result = await session.execute(
        text(
            "SELECT column_name, udt_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' "
            "AND column_name NOT IN ('id', 'created_at', 'updated_at', 'history') "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    return {row[0]: _UDT_TO_FRONTEND_TYPE.get(row[1], "text") for row in result}


def _coerce_for_write(value: Any, col_type: str) -> Any:
    """Coerce a Python value to the appropriate type for a PostgreSQL write."""
    if value is None:
        return None
    if col_type == "date":
        if isinstance(value, datetime):
            return value.date()
        if isinstance(value, str):
            s = value.strip()
            try:
                return (
                    datetime.fromisoformat(s.rstrip("Z")).date()
                    if "T" in s
                    else date.fromisoformat(s)
                )
            except ValueError:
                return None
    if col_type == "json" and isinstance(value, (dict, list)):
        return json.dumps(value)
    return value


async def _read_columns(session: Any, table_id: int) -> list[dict[str, Any]]:
    tbl = _pg_table(table_id)
    col_result = await session.execute(
        text(
            "SELECT column_name, udt_name FROM information_schema.columns "
            "WHERE table_name = :tbl AND table_schema = 'public' "
            "AND column_name NOT IN ('id', 'created_at', 'updated_at', 'history') "
            "ORDER BY ordinal_position"
        ),
        {"tbl": tbl},
    )
    pg_cols = col_result.fetchall()
    meta_result = await session.execute(
        text(
            "SELECT column_name, select_options FROM data_table_column_meta WHERE table_id = :tid"
        ),
        {"tid": table_id},
    )
    select_opts_map: dict[str, list[dict[str, str]]] = {
        row[0]: row[1] for row in meta_result if row[1] is not None
    }
    cols: list[dict[str, Any]] = []
    for col in pg_cols:
        col_name, udt = col[0], col[1]
        opts = select_opts_map.get(col_name)
        col_type = (
            "select" if opts is not None else _UDT_TO_FRONTEND_TYPE.get(udt, "text")
        )
        entry: dict[str, Any] = {"id": col_name, "name": col_name, "type": col_type}
        if opts is not None:
            entry["selectOptions"] = _normalize_select_opts(opts)
        cols.append(entry)
    return cols


async def _upsert_row(
    session: Any, tbl_name: str, row: dict, col_ids: list[str]
) -> None:
    """INSERT ... ON CONFLICT (id) DO UPDATE for a single row.

    System columns created_at and updated_at are managed automatically:
    created_at is set on first insert only; updated_at is always refreshed.
    """
    known = set(col_ids)
    data = {k: v for k, v in row.items() if k != "id" and k in known}
    params: dict[str, Any] = {"row_id": int(row["id"])}
    col_q, val_ph, update_parts = [], [], []
    for i, (k, v) in enumerate(data.items()):
        qk = _qi(k)
        col_q.append(qk)
        val_ph.append(f":v{i}")
        update_parts.append(f"{qk} = EXCLUDED.{qk}")
        params[f"v{i}"] = v
    sys_update = "updated_at = NOW()"
    if col_q:
        sql = (
            f"INSERT INTO {tbl_name} (id, created_at, updated_at, {', '.join(col_q)}) "
            f"VALUES (:row_id, NOW(), NOW(), {', '.join(val_ph)}) "
            f"ON CONFLICT (id) DO UPDATE SET {sys_update}, {', '.join(update_parts)}"
        )
    else:
        sql = (
            f"INSERT INTO {tbl_name} (id, created_at, updated_at) VALUES (:row_id, NOW(), NOW()) "
            f"ON CONFLICT (id) DO UPDATE SET {sys_update}"
        )
    await session.execute(text(sql), params)


async def _ensure_tables(schema: list[dict]) -> None:
    """Idempotently create or migrate tables declared in the ankor `tables=` config.

    Each entry in *schema* is a dict with keys:
        name        str                     required
        description str | None              optional
        columns     list[dict]              required — each has {id, name, type, selectOptions?}

    For each declared table:
    - If the table does not exist in the registry, it is created (physical table + metadata row).
    - If the table already exists, any declared columns that are missing are added (ALTER TABLE ADD COLUMN).
    - Existing columns are never dropped or modified (safe forward-only migration).
    """
    from .database import _SessionLocal

    if _SessionLocal is None:
        return

    from sqlmodel import select
    from .models import DataTable

    async with _SessionLocal() as session:
        for entry in schema:
            name: str = entry["name"]
            description: str | None = entry.get("description")
            actions: list[str] | None = entry.get("actions")
            declared_cols: list[dict] = entry.get("columns") or []

            existing = (
                await session.exec(select(DataTable).where(DataTable.name == name))
            ).first()

            if existing is None:
                t = DataTable(name=name, description=description, actions=actions)
                session.add(t)
                await session.flush()
                tbl = _pg_table(t.id)
                col_defs = [
                    "id INTEGER NOT NULL",
                    "history JSONB NOT NULL DEFAULT '[]'",
                    "created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                    "updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()",
                ] + [
                    f"{_qi(col['id'])} {_PG_TYPE_MAP.get(col.get('type', 'text'), 'TEXT')}"
                    for col in declared_cols
                ]
                await session.execute(
                    text(
                        f"CREATE TABLE {tbl} ({', '.join(col_defs)}, PRIMARY KEY (id))"
                    )
                )
                for col in declared_cols:
                    if col.get("type") == "select":
                        await session.execute(
                            text(
                                "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                                "VALUES (:tid, :cn, CAST(:opts AS json))"
                            ),
                            {
                                "tid": t.id,
                                "cn": col["id"],
                                "opts": json.dumps(
                                    _normalize_select_opts(col.get("selectOptions"))
                                ),
                            },
                        )
            else:
                tbl = _pg_table(existing.id)
                if actions is not None:
                    existing.actions = actions
                    session.add(existing)
                result = await session.execute(
                    text(
                        "SELECT column_name FROM information_schema.columns "
                        "WHERE table_name = :tbl AND table_schema = 'public'"
                    ),
                    {"tbl": tbl},
                )
                existing_cols = {row[0] for row in result}
                if "history" not in existing_cols:
                    await session.execute(
                        text(
                            f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS "
                            f"history JSONB NOT NULL DEFAULT '[]'"
                        )
                    )
                for col in declared_cols:
                    col_id = col["id"]
                    if col_id in existing_cols:
                        continue
                    pg_type = _PG_TYPE_MAP.get(col.get("type", "text"), "TEXT")
                    await session.execute(
                        text(
                            f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS {_qi(col_id)} {pg_type}"
                        )
                    )
                    if col.get("type") == "select":
                        await session.execute(
                            text(
                                "INSERT INTO data_table_column_meta (table_id, column_name, select_options) "
                                "VALUES (:tid, :cn, CAST(:opts AS json)) "
                                "ON CONFLICT (table_id, column_name) DO NOTHING"
                            ),
                            {
                                "tid": existing.id,
                                "cn": col_id,
                                "opts": json.dumps(
                                    _normalize_select_opts(col.get("selectOptions"))
                                ),
                            },
                        )

        await session.commit()


def _record_db_action(
    op: str, table: str, inputs: dict, outputs: dict, duration_ms: int
) -> None:
    from .decorator import DbActionRecord, record_db_action

    record_db_action(op, table, DbActionRecord(inputs, outputs, duration_ms))


class DbStore:
    """Thin async wrapper around real PostgreSQL data tables.

    Attached to ``ankor`` as ``gtm.db``.
    """

    @staticmethod
    async def _fetch_registry(session: Any, table_name: str) -> Any:
        from sqlmodel import select

        from .models import DataTable

        result = await session.exec(
            select(DataTable).where(DataTable.name == table_name)
        )
        table = result.first()
        if table is None:
            raise KeyError(f"Table {table_name!r} not found.")
        return table

    async def rows(
        self,
        table_name: str,
        filters: list[RowFilter] | None = None,
        columns: list[str] | None = None,
        order_by: "OrderBy | None" = None,
    ) -> list[dict]:
        """Return rows from the named table as a list of plain ``dict``\\s.

        Pass *filters* to restrict which rows are returned::

            from ankor import RowFilter

            rows = await gtm.db.rows("Deals", filters=[
                RowFilter("amount", "gt", 1000),
                RowFilter("status", "eq", "active"),
            ])

        Pass *columns* to return only specific fields (``id`` is always included)::

            rows = await gtm.db.rows("Deals", columns=["amount", "status"])

        Pass *order_by* to control sort order::

            from ankor import OrderBy

            rows = await gtm.db.rows("Deals", order_by=OrderBy("amount", "desc"))
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            return []
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            tbl = _pg_table(t.id)
            col_types = await _read_col_types(session, tbl)
            if columns:
                valid_cols = set(col_types) | _SYSTEM_COLS
                invalid = [c for c in columns if c not in valid_cols]
                if invalid:
                    raise ValueError(
                        f"Unknown columns: {invalid!r}. "
                        f"Valid columns: {sorted(valid_cols)}"
                    )
            where_sql, params = _build_where(filters or [])
            select_sql = _build_select_cols(columns)
            order_sql = _build_order_by(order_by)
            sql = f"SELECT {select_sql} FROM {tbl}{where_sql} ORDER BY {order_sql}"
            result = await session.execute(text(sql), params)
            rows = [_normalize_row(r._mapping, col_types) for r in result]
        _record_db_action(
            "rows",
            table_name,
            {
                "filters": len(filters or []),
                "columns": columns,
                "order_by": order_by.column if order_by else None,
            },
            {"rows": rows, "count": len(rows)},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        return rows

    async def get_row(self, table_name: str, row_id: int) -> dict | None:
        """Return a single row by its ``id``, or ``None`` if not found."""
        from .database import _SessionLocal

        if _SessionLocal is None:
            return None
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            tbl = _pg_table(t.id)
            col_types = await _read_col_types(session, tbl)
            result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :row_id"),
                {"row_id": row_id},
            )
            row = result.first()
            found = _normalize_row(row._mapping, col_types) if row else None
        _record_db_action(
            "get_row",
            table_name,
            {"id": row_id},
            {"row": found},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        return found

    async def add_row(self, table_name: str, data: dict[str, Any]) -> dict:
        """Append a new row to the named table.

        A unique integer ``id`` is assigned automatically. Returns the stored row dict.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            col_types = await _read_col_types(session, tbl)
            max_id: int = (
                await session.scalar(text(f"SELECT COALESCE(MAX(id), 0) FROM {tbl}"))
            ) or 0
            new_id = max_id + 1
            row = {
                "id": new_id,
                **{
                    k: _coerce_for_write(v, col_types.get(k, "text"))
                    for k, v in data.items()
                    if k != "id"
                },
            }
            await _upsert_row(session, tbl, row, list(col_types.keys()))
            result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :row_id"), {"row_id": new_id}
            )
            stored = result.first()
            await session.commit()
            stored_row = _normalize_row(stored._mapping, col_types) if stored else row
        _record_db_action(
            "add_row",
            table_name,
            {k: v for k, v in data.items() if k != "id"},
            stored_row,
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        await manager.broadcast(f"table:{table_id}", {"type": "rows_changed"})
        return stored_row

    async def update_row(
        self,
        table_name: str,
        row_id: int,
        data: dict[str, Any],
    ) -> dict:
        """Merge *data* into an existing row and return ``{"old": ..., "new": ..., "_meta": ...}``.

        Raises :class:`KeyError` if *row_id* is not found.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        from .decorator._context import _active_run_ctx

        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            # Lazy-add history column for tables created before this feature.
            await session.execute(
                text(
                    f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS "
                    f"history JSONB NOT NULL DEFAULT '[]'"
                )
            )
            col_types = await _read_col_types(session, tbl)
            old_result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :row_id"), {"row_id": row_id}
            )
            old_row_raw = old_result.first()
            if old_row_raw is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            old_row = _normalize_row(old_row_raw._mapping, col_types)
            update_data = {
                k: _coerce_for_write(v, col_types.get(k, "text"))
                for k, v in data.items()
                if k in col_types
            }
            if not update_data:
                return {
                    "old": old_row,
                    "new": old_row,
                    "_meta": {
                        "views": [
                            {"key": "old", "type": "json"},
                            {"key": "new", "type": "json"},
                        ]
                    },
                }

            run_ctx = _active_run_ctx.get()

            params: dict[str, Any] = {"row_id": row_id}
            set_clauses = ["updated_at = NOW()"]
            for i, (k, v) in enumerate(update_data.items()):
                set_clauses.append(f"{_qi(k)} = :v{i}")
                params[f"v{i}"] = v

            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            if run_ctx is not None:
                # Inside a workflow run — accumulate history in memory only;
                # flush_row_history writes a single combined entry at the end.
                row_history: dict = run_ctx.setdefault("_row_history", {})
                key = (table_id, row_id)
                new_actions = (
                    [
                        {
                            "type": "row_update",
                            "state": {
                                k: v for k, v in old_row.items() if k != "history"
                            },
                            "date": now_ms,
                        }
                    ]
                    if update_data
                    else []
                )
                if key not in row_history:
                    row_history[key] = {
                        "wr_id": run_ctx.get("run_id"),
                        "wf_name": (run_ctx.get("_run_meta") or {}).get("name"),
                        "date": now_ms,
                        "actions": new_actions,
                    }
                else:
                    row_history[key]["actions"].extend(new_actions)
                result = await session.execute(
                    text(
                        f"UPDATE {tbl} SET {', '.join(set_clauses)} WHERE id = :row_id RETURNING *"
                    ),
                    params,
                )
            else:
                # Called outside a workflow — write history immediately.
                history_entry = {
                    "wr_id": None,
                    "wf_name": None,
                    "date": now_ms,
                    "actions": [
                        *(
                            [
                                {
                                    "type": "row_update",
                                    "state": {
                                        k: v
                                        for k, v in old_row.items()
                                        if k != "history"
                                    },
                                    "date": now_ms,
                                }
                            ]
                            if update_data
                            else []
                        ),
                    ],
                }
                set_clauses.append(
                    "history = COALESCE(history, '[]'::jsonb) || CAST(:history_entry AS jsonb)"
                )
                params["history_entry"] = json.dumps([history_entry])
                result = await session.execute(
                    text(
                        f"UPDATE {tbl} SET {', '.join(set_clauses)} WHERE id = :row_id RETURNING *"
                    ),
                    params,
                )

            updated = result.first()
            if updated is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            await session.commit()
            updated_row = _normalize_row(updated._mapping, col_types)
        output = {
            "old": old_row,
            "new": updated_row,
            "_meta": {
                "views": [
                    {"key": "diff", "type": "diff", "from": "old", "to": "new"},
                    {"key": "old", "type": "json"},
                    {"key": "new", "type": "json"},
                ]
            },
        }
        _record_db_action(
            "update_row",
            table_name,
            {"id": row_id, "data": data},
            output,
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        json_col_ids = {k for k, v in col_types.items() if v == "json"}
        broadcast_row = {k: v for k, v in updated_row.items() if k not in json_col_ids}
        await manager.broadcast(
            f"table:{table_id}", {"type": "row_updated", "row": broadcast_row}
        )
        return output

    async def note(self, table_name: str, row_id: int, text_: str) -> None:
        """Append a note to a row's history without modifying any column values.

        Raises :class:`KeyError` if *row_id* is not found.
        """
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        from .decorator._context import _active_run_ctx

        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            await session.execute(
                text(
                    f"ALTER TABLE {tbl} ADD COLUMN IF NOT EXISTS "
                    f"history JSONB NOT NULL DEFAULT '[]'"
                )
            )
            col_types = await _read_col_types(session, tbl)
            result = await session.execute(
                text(f"SELECT id FROM {tbl} WHERE id = :row_id"), {"row_id": row_id}
            )
            if result.first() is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")

            run_ctx = _active_run_ctx.get()
            now_ms = int(datetime.now(timezone.utc).timestamp() * 1000)
            note_action = {"type": "note", "data": text_, "date": now_ms}

            if run_ctx is not None:
                # Inside a workflow run — accumulate in memory only; flush at end.
                row_history: dict = run_ctx.setdefault("_row_history", {})
                key = (table_id, row_id)
                if key in row_history:
                    row_history[key]["actions"].append(note_action)
                else:
                    row_history[key] = {
                        "wr_id": run_ctx.get("run_id"),
                        "wf_name": (run_ctx.get("_run_meta") or {}).get("name"),
                        "date": now_ms,
                        "actions": [note_action],
                    }
                await session.close()
            else:
                # Outside a workflow — write to DB immediately.
                history_entry = {
                    "wr_id": None,
                    "wf_name": None,
                    "date": now_ms,
                    "actions": [note_action],
                }
                await session.execute(
                    text(
                        f"UPDATE {tbl} SET "
                        "history = COALESCE(history, '[]'::jsonb) || CAST(:entry AS jsonb), "
                        "updated_at = NOW() "
                        "WHERE id = :row_id"
                    ),
                    {"entry": json.dumps([history_entry]), "row_id": row_id},
                )
                await session.commit()
                # Fetch updated row for broadcast
                updated_result = await session.execute(
                    text(f"SELECT * FROM {tbl} WHERE id = :rid"), {"rid": row_id}
                )
                updated_raw = updated_result.first()
                if updated_raw is not None:
                    from .broadcast import manager

                    json_col_ids = {k for k, v in col_types.items() if v == "json"}
                    normalized = _normalize_row(updated_raw._mapping, col_types)
                    broadcast_row = {
                        k: v for k, v in normalized.items() if k not in json_col_ids
                    }
                    await manager.broadcast(
                        f"table:{table_id}",
                        {"type": "row_updated", "row": broadcast_row},
                    )
        _record_db_action(
            "note",
            table_name,
            {"id": row_id, "note": text_},
            {},
            int((datetime.now() - t0).total_seconds() * 1000),
        )

    async def delete_row(self, table_name: str, row_id: int) -> None:
        """Remove a row by its ``id``.  Raises :class:`KeyError` if not found."""
        from .database import _SessionLocal

        if _SessionLocal is None:
            raise RuntimeError(
                "Database not initialised. ankor must be instantiated first."
            )
        t0 = datetime.now()
        async with _SessionLocal() as session:
            t = await self._fetch_registry(session, table_name)
            table_id = t.id
            tbl = _pg_table(t.id)
            result = await session.execute(
                text(f"DELETE FROM {tbl} WHERE id = :row_id RETURNING id"),
                {"row_id": row_id},
            )
            deleted = result.first()
            if deleted is None:
                raise KeyError(f"Row {row_id!r} not found in table {table_name!r}.")
            await session.commit()
        _record_db_action(
            "delete_row",
            table_name,
            {"id": row_id},
            {},
            int((datetime.now() - t0).total_seconds() * 1000),
        )
        from .broadcast import manager

        await manager.broadcast(f"table:{table_id}", {"type": "rows_changed"})


async def flush_row_history(ctx: dict, *, failed_exc: Exception | None = None) -> None:
    """Broadcast a final ``row_updated`` for every row touched during a workflow run.

    For successful runs, history entries are written inline by ``update_row``.
    For failed runs (``failed_exc`` provided), a failed history entry is written
    to the DB for each pre-registered row that was never reached by ``update_row``
    (i.e. its ``actions`` list is still empty), so the frontend can show it as failed.
    """
    from .database import _SessionLocal
    from .broadcast import manager

    if _SessionLocal is None:
        return
    row_history: dict = ctx.get("_row_history", {})
    if not row_history:
        return

    run_id: int | None = ctx.get("run_id")
    error_str = f"{type(failed_exc).__name__}: {failed_exc}" if failed_exc else None

    async with _SessionLocal() as session:
        for (table_id, row_id), entry in row_history.items():
            tbl = _pg_table(table_id)

            if failed_exc is not None and not entry.get("actions"):
                # Failed run, row never reached update_row — write a failed marker.
                db_entry = {
                    "wr_id": entry.get("wr_id"),
                    "wf_name": entry.get("wf_name"),
                    "date": entry.get("date"),
                    "actions": [],
                    "status": "failed",
                    "error": error_str,
                }
            else:
                # Successful run (or failed run with partial actions) — write the
                # single accumulated entry with all actions collected during the run.
                db_entry = dict(entry)
                if failed_exc is not None:
                    db_entry["status"] = "failed"
                    db_entry["error"] = error_str

            await session.execute(
                text(
                    f"UPDATE {tbl} SET "
                    "history = COALESCE(history, '[]'::jsonb) || CAST(:entry AS jsonb), "
                    "updated_at = NOW() "
                    "WHERE id = :row_id"
                ),
                {"entry": json.dumps([db_entry]), "row_id": row_id},
            )
            await session.commit()

            col_types = await _read_col_types(session, tbl)
            result = await session.execute(
                text(f"SELECT * FROM {tbl} WHERE id = :rid"),
                {"rid": row_id},
            )
            row = result.first()
            if row is None:
                continue
            normalized = _normalize_row(row._mapping, col_types)
            json_col_ids = {k for k, v in col_types.items() if v == "json"}
            broadcast_row = {
                k: v for k, v in normalized.items() if k not in json_col_ids
            }
            msg: dict = {"type": "row_updated", "row": broadcast_row}
            if run_id is not None:
                msg["run_id"] = run_id
            await manager.broadcast(f"table:{table_id}", msg)
