from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy import func
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..auth import create_access_token, hash_password, verify_password
from ..database import get_session
from ..deps import get_current_user
from ..models import User, UserRole
from .schemas import SetupRequest


def create_auth_router() -> APIRouter:
    router = APIRouter()

    @router.post("/auth/token", tags=["auth"])
    async def login(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
    ):
        user = await session.get(User, form.username)
        if not user or not verify_password(form.password, user.hashed_password):
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
        return {"access_token": create_access_token(user.username), "token_type": "bearer"}

    @router.post("/auth/register", status_code=status.HTTP_201_CREATED, tags=["auth"])
    async def register(
        form: OAuth2PasswordRequestForm = Depends(),
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        if await session.get(User, form.username):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")
        session.add(User(username=form.username, hashed_password=hash_password(form.password)))
        await session.commit()
        return {"username": form.username}

    @router.get("/auth/setup-status", tags=["auth"])
    async def setup_status(session: AsyncSession = Depends(get_session)):
        count = (await session.execute(select(func.count(User.username)))).scalar_one()
        return {"setupRequired": count == 0}

    @router.post("/auth/setup", status_code=status.HTTP_201_CREATED, tags=["auth"])
    async def setup(
        body: SetupRequest,
        session: AsyncSession = Depends(get_session),
    ):
        count = (await session.execute(select(func.count(User.username)))).scalar_one()
        if count > 0:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Setup already completed")
        session.add(User(
            username=body.username,
            email=body.email,
            hashed_password=hash_password(body.password),
            role=UserRole.admin,
        ))
        await session.commit()
        return {"username": body.username}

    @router.get("/health", tags=["system"])
    async def health():
        return {"status": "ok"}

    return router
