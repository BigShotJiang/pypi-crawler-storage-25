from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..auth import create_api_token, generate_webhook_token, hash_password
from ..database import get_session
from ..deps import get_current_user
from ..models import ApiToken, User, WebhookToken
from .schemas import (
    ApiTokenCreate,
    ApiTokenCreated,
    ApiTokenRead,
    UserCreate,
    UserPasswordUpdate,
    UserRead,
    WebhookTokenRead,
)


def create_users_router() -> APIRouter:
    router = APIRouter()

    @router.get("/users", response_model=list[UserRead], response_model_by_alias=True, tags=["users"])
    async def list_users(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        users = (await session.exec(select(User))).all()
        return [UserRead(username=u.username, created_at=u.created_at) for u in users]

    @router.post("/users", response_model=UserRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["users"])
    async def create_user(
        body: UserCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        if await session.get(User, body.username):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists")
        user = User(username=body.username, hashed_password=hash_password(body.password))
        session.add(user)
        await session.commit()
        await session.refresh(user)
        return UserRead(username=user.username, created_at=user.created_at)

    @router.delete("/users/{username}", status_code=status.HTTP_204_NO_CONTENT, tags=["users"])
    async def delete_user(
        username: str,
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        if username == current_user.username:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot delete your own account")
        user = await session.get(User, username)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        tokens = (await session.exec(select(ApiToken).where(ApiToken.username == username))).all()
        for t in tokens:
            await session.delete(t)
        await session.delete(user)
        await session.commit()

    @router.patch("/users/{username}/password", status_code=status.HTTP_204_NO_CONTENT, tags=["users"])
    async def update_user_password(
        username: str,
        body: UserPasswordUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        user = await session.get(User, username)
        if not user:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        user.hashed_password = hash_password(body.password)
        session.add(user)
        await session.commit()

    @router.get("/tokens", response_model=list[ApiTokenRead], response_model_by_alias=True, tags=["tokens"])
    async def list_tokens(
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        tokens = (await session.exec(select(ApiToken).where(ApiToken.username == current_user.username))).all()
        return [
            ApiTokenRead(id=t.id, name=t.name, username=t.username, created_at=t.created_at, expires_at=t.expires_at)
            for t in tokens
        ]

    @router.post("/tokens", response_model=ApiTokenCreated, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["tokens"])
    async def create_token(
        body: ApiTokenCreate,
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        expires_at = datetime.now(timezone.utc) + timedelta(days=body.expires_days) if body.expires_days else None
        record = ApiToken(name=body.name, username=current_user.username, expires_at=expires_at)
        session.add(record)
        await session.commit()
        await session.refresh(record)
        token_str = create_api_token(current_user.username, str(record.id), body.expires_days)
        return ApiTokenCreated(
            id=record.id, name=record.name, username=record.username,
            created_at=record.created_at, expires_at=record.expires_at, token=token_str,
        )

    @router.delete("/tokens/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["tokens"])
    async def revoke_token(
        id: int,
        session: AsyncSession = Depends(get_session),
        current_user: User = Depends(get_current_user),
    ):
        token = await session.get(ApiToken, id)
        if not token or token.username != current_user.username:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Token not found")
        await session.delete(token)
        await session.commit()

    @router.get("/webhook-token", response_model=WebhookTokenRead, response_model_by_alias=True, tags=["webhook-token"])
    async def get_webhook_token(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        wt = await session.get(WebhookToken, "default")
        if not wt:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Webhook token not initialized")
        return WebhookTokenRead(token=wt.token, created_at=wt.created_at)

    @router.post("/webhook-token/rotate", response_model=WebhookTokenRead, response_model_by_alias=True, tags=["webhook-token"])
    async def rotate_webhook_token(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        wt = await session.get(WebhookToken, "default")
        if wt is None:
            wt = WebhookToken(token=generate_webhook_token())
            session.add(wt)
        else:
            wt.token = generate_webhook_token()
            wt.created_at = datetime.now(timezone.utc)
            session.add(wt)
        await session.commit()
        await session.refresh(wt)
        return WebhookTokenRead(token=wt.token, created_at=wt.created_at)

    return router
