from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from typing import Any, Callable, Coroutine

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from sqlalchemy import BigInteger, Text, and_, cast, func, literal_column, or_
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..broadcast import manager
from ..database import get_session
from ..decorator import _run_detail, _run_summary, _running_tasks
from ..deps import get_current_user
from ..models import RunNode, User, Workflow, WorkflowRun, WorkflowStatus
from ..trigger_context import TriggerContext
from .schemas import (
    WorkflowNodeRead,
    WorkflowNodeSummary,
    WorkflowRunRead,
    WorkflowRunSummary,
    WorkflowStats,
)


def _node_row_to_slim(
    node: RunNode, all_nodes: list[RunNode], depth: int = 0
) -> WorkflowNodeSummary:
    """Build a slim WorkflowNodeSummary from a RunNode row, recursing into children."""
    children: list[WorkflowNodeSummary] = []
    if depth < 5:
        children = [
            _node_row_to_slim(c, all_nodes, depth + 1)
            for c in all_nodes
            if c.parent_node_id == node.id
        ]
    st = node.status
    return WorkflowNodeSummary(
        id=node.id,
        name=node.name or "",
        slug=node.slug,
        status=(st.value if hasattr(st, "value") else st) or "pending",
        duration_ms=node.duration_ms or 0,
        started_at=node.started_at,
        child_run_id=node.child_run_id,
        children=children,
    )


def _node_row_to_full(
    node: RunNode, all_nodes: list[RunNode], depth: int = 0
) -> WorkflowNodeRead:
    """Build a full WorkflowNodeRead from a RunNode row, recursing into children."""
    d = node.data or {}
    children: list[WorkflowNodeRead] = []
    if depth < 5:
        children = [
            _node_row_to_full(c, all_nodes, depth + 1)
            for c in all_nodes
            if c.parent_node_id == node.id
        ]
    st = node.status
    return WorkflowNodeRead(
        id=node.id,
        name=node.name or "",
        slug=node.slug,
        status=(st.value if hasattr(st, "value") else st) or "pending",
        inputs=d.get("inputs") or {},
        outputs=d.get("outputs") or {},
        duration_ms=node.duration_ms or 0,
        started_at=node.started_at,
        logs=d.get("logs"),
        child_run_id=node.child_run_id,
        children=children,
    )


def _to_summary(
    run: WorkflowRun, cm: dict[int, list[WorkflowRun]], wf_names: dict[int, str]
) -> WorkflowRunSummary:
    d = run.data or {}
    return WorkflowRunSummary(
        id=run.id,
        name=wf_names.get(run.workflow_id, ""),
        status=run.status.value,
        triggered_by=(
            run.triggered_by.value
            if hasattr(run.triggered_by, "value")
            else run.triggered_by
        ),
        trigger_context=d.get("trigger_context", {}),
        inputs=d.get("inputs", {}),
        outputs=d.get("outputs", {}),
        logs=d.get("logs", []),
        started_at=run.started_at,
        finished_at=run.finished_at,
        created_at=run.created_at,
        parent_id=run.parent_id,
        children=[_to_summary(c, cm, wf_names) for c in cm.get(run.id, [])],
    )


# Columns that are sufficient for list/stats views — excludes the heavy `data` JSONB column.
_SLIM_COLS = (
    WorkflowRun.id,
    WorkflowRun.workflow_id,
    WorkflowRun.status,
    WorkflowRun.triggered_by,
    WorkflowRun.started_at,
    WorkflowRun.finished_at,
    WorkflowRun.created_at,
    WorkflowRun.parent_id,
)


def _row_to_summary(
    row: Any, cm: dict[int, list[Any]], wf_names: dict[int, str]
) -> WorkflowRunSummary:
    st, tb = row.status, row.triggered_by
    return WorkflowRunSummary(
        id=row.id,
        name=wf_names.get(row.workflow_id, ""),
        status=st.value if hasattr(st, "value") else st,
        triggered_by=tb.value if hasattr(tb, "value") else tb,
        trigger_context={},
        inputs={},
        outputs={},
        logs=[],
        started_at=row.started_at,
        finished_at=row.finished_at,
        created_at=row.created_at,
        parent_id=row.parent_id,
        children=[_row_to_summary(c, cm, wf_names) for c in cm.get(row.id, [])],
    )


def _build_summary_tree(
    rows: list[Any], wf_names: dict[int, str]
) -> list[WorkflowRunSummary]:
    cm: dict[int, list[Any]] = defaultdict(list)
    roots: list[Any] = []
    for r in rows:
        if r.parent_id:
            cm[r.parent_id].append(r)
        else:
            roots.append(r)
    return [_row_to_summary(r, cm, wf_names) for r in roots]


def _run_to_read(
    run: WorkflowRun, cm: dict[int, list[WorkflowRun]], wf_names: dict[int, str]
) -> WorkflowRunRead:
    d = run.data or {}
    return WorkflowRunRead(
        id=run.id,
        name=wf_names.get(run.workflow_id, ""),
        status=run.status.value,
        triggered_by=(
            run.triggered_by.value
            if hasattr(run.triggered_by, "value")
            else run.triggered_by
        ),
        trigger_context=d.get("trigger_context", {}),
        inputs=d.get("inputs", {}),
        outputs=d.get("outputs", {}),
        logs=d.get("logs", []),
        started_at=run.started_at,
        finished_at=run.finished_at,
        created_at=run.created_at,
        parent_id=run.parent_id,
        actions=[],
        children=[_run_to_read(c, cm, wf_names) for c in cm.get(run.id, [])],
    )


def _build_tree(
    runs: list[WorkflowRun], wf_names: dict[int, str]
) -> list[WorkflowRunRead]:
    cm: dict[int, list[WorkflowRun]] = defaultdict(list)
    roots: list[WorkflowRun] = []
    for r in runs:
        if r.parent_id:
            cm[r.parent_id].append(r)
        else:
            roots.append(r)
    return [_run_to_read(r, cm, wf_names) for r in roots]


def create_runs_router(invoke: Callable[..., Coroutine[Any, Any, Any]]) -> APIRouter:
    router = APIRouter()

    @router.get(
        "/workflow-runs/stats",
        response_model=WorkflowStats,
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_workflow_stats(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        raw = await session.execute(
            select(WorkflowRun.status, func.count(WorkflowRun.id)).group_by(
                WorkflowRun.status
            )
        )
        counts: dict[str, int] = {
            (s.value if hasattr(s, "value") else str(s)): c for s, c in raw.all()
        }
        for s in WorkflowStatus:
            counts.setdefault(s.value, 0)

        active_rows = (
            await session.execute(
                select(*_SLIM_COLS).where(WorkflowRun.status == WorkflowStatus.running)
            )
        ).all()

        recent_rows = (
            await session.execute(
                select(*_SLIM_COLS)
                .where(WorkflowRun.status != WorkflowStatus.running)
                .order_by(WorkflowRun.created_at.desc())
                .limit(5)
            )
        ).all()

        wf_ids = {r.workflow_id for r in list(active_rows) + list(recent_rows)}
        wf_entries = (
            (await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))).all()
            if wf_ids
            else []
        )
        wf_names = {w.id: w.name for w in wf_entries}

        return WorkflowStats(
            counts=counts,
            active=[_row_to_summary(r, {}, wf_names) for r in active_rows],
            recent=[_row_to_summary(r, {}, wf_names) for r in recent_rows],
        )

    @router.get(
        "/workflow-runs",
        response_model=list[WorkflowRunSummary],
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def list_workflow_runs(
        fastapi_response: Response,
        offset: int = 0,
        limit: int = 50,
        search: str = "",
        status: list[str] = Query(default=[]),
        workflow_name: list[str] = Query(default=[]),
        date_from: datetime | None = None,
        date_to: datetime | None = None,
        triggered_by: list[str] = Query(default=[]),
        original_run_id: str | None = None,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        conds = [WorkflowRun.parent_id == None]  # noqa: E711
        if search:
            conds.append(
                or_(
                    WorkflowRun.workflow_id.in_(
                        select(Workflow.id).where(Workflow.name.ilike(f"%{search}%"))
                    ),
                    cast(WorkflowRun.id, Text).ilike(f"%{search}%"),
                    literal_column("workflow_runs.data::text").ilike(f"%{search}%"),
                    WorkflowRun.id.in_(
                        select(RunNode.run_id).where(
                            literal_column("run_nodes.data::text").ilike(f"%{search}%")
                        )
                    ),
                )
            )
        if status:
            conds.append(WorkflowRun.status.in_(status))  # type: ignore[arg-type]
        if workflow_name:
            conds.append(
                WorkflowRun.workflow_id.in_(
                    select(Workflow.id).where(Workflow.name.in_(workflow_name))
                )
            )
        if date_from:
            conds.append(WorkflowRun.created_at >= date_from)
        if date_to:
            conds.append(WorkflowRun.created_at <= date_to)
        if triggered_by:
            conds.append(WorkflowRun.triggered_by.in_(triggered_by))
        if original_run_id:
            # Handle both camelCase (current) and snake_case (legacy) key names
            conds.append(
                or_(
                    func.json_extract_path_text(
                        WorkflowRun.data, "trigger_context", "originalRunId"
                    )
                    == original_run_id,
                    func.json_extract_path_text(
                        WorkflowRun.data, "trigger_context", "original_run_id"
                    )
                    == original_run_id,
                )
            )
        where = and_(*conds)

        total = (
            await session.execute(select(func.count(WorkflowRun.id)).where(where))
        ).scalar_one()
        fastapi_response.headers["X-Total-Count"] = str(total)

        roots = (
            await session.execute(
                select(*_SLIM_COLS)
                .where(where)
                .order_by(WorkflowRun.created_at.desc(), WorkflowRun.id.desc())
                .offset(offset)
                .limit(limit)
            )
        ).all()

        if not roots:
            return []

        root_ids = [r.id for r in roots]
        children = (
            await session.execute(
                select(*_SLIM_COLS).where(WorkflowRun.parent_id.in_(root_ids))
            )
        ).all()

        grandchildren: list[Any] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = (
                await session.execute(
                    select(*_SLIM_COLS).where(WorkflowRun.parent_id.in_(child_ids))
                )
            ).all()

        all_rows = list(roots) + list(children) + list(grandchildren)
        wf_ids = {r.workflow_id for r in all_rows}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        return _build_summary_tree(all_rows, wf_names)

    @router.get(
        "/workflow-runs/{id}",
        response_model=WorkflowRunRead,
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )

        children = list(
            (
                await session.exec(
                    select(WorkflowRun).where(WorkflowRun.parent_id == id)
                )
            ).all()
        )
        grandchildren: list[WorkflowRun] = []
        if children:
            child_ids = [c.id for c in children]
            grandchildren = list(
                (
                    await session.exec(
                        select(WorkflowRun).where(WorkflowRun.parent_id.in_(child_ids))
                    )
                ).all()
            )

        cm: dict[int, list[WorkflowRun]] = defaultdict(list)
        for r in children + grandchildren:
            cm[r.parent_id].append(r)

        wf_ids = {run.workflow_id} | {r.workflow_id for r in children + grandchildren}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        return _run_to_read(run, cm, wf_names)

    @router.get(
        "/workflow-runs/{id}/nodes",
        response_model=list[WorkflowNodeSummary],
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_workflow_run_nodes(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )
        all_nodes = list(
            (
                await session.exec(
                    select(RunNode).where(RunNode.run_id == id).order_by(RunNode.id)
                )
            ).all()
        )
        roots = [n for n in all_nodes if n.parent_node_id is None]
        return [_node_row_to_slim(n, all_nodes) for n in roots]

    @router.get(
        "/nodes/{id}",
        response_model=WorkflowNodeRead,
        response_model_by_alias=True,
        tags=["workflow-runs"],
    )
    async def get_node(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        node = await session.get(RunNode, id)
        if not node:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Node not found"
            )
        # Fetch all nodes for the same run to build the children subtree.
        all_nodes = list(
            (
                await session.exec(
                    select(RunNode)
                    .where(RunNode.run_id == node.run_id)
                    .order_by(RunNode.id)
                )
            ).all()
        )
        return _node_row_to_full(node, all_nodes)

    @router.post("/workflow-runs/{id}/rerun", status_code=202, tags=["workflow-runs"])
    async def rerun_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )

        stored = (run.data or {}).get("trigger_context") or {}
        if not stored:
            stored = {
                "type": (
                    run.triggered_by.value
                    if hasattr(run.triggered_by, "value")
                    else run.triggered_by
                ),
                "inputs": {},
            }
        original_ctx = TriggerContext.from_db(stored)
        rerun_ctx = TriggerContext(
            type="rerun",
            inputs=original_ctx.inputs,
            metadata={
                **original_ctx.metadata,
                "originalType": original_ctx.type,
                "originalRunId": str(id),
            },
        )

        wf = await session.get(Workflow, run.workflow_id)
        workflow_name = wf.name if wf else ""
        try:
            await invoke(workflow_name, rerun_ctx)
        except KeyError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Workflow '{workflow_name}' is not registered in this process",
            )

        return {"status": "accepted"}

    @router.post("/workflow-runs/{id}/cancel", status_code=200, tags=["workflow-runs"])
    async def cancel_workflow_run(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        run = await session.get(WorkflowRun, id)
        if not run:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found"
            )
        if run.status not in (WorkflowStatus.pending, WorkflowStatus.running):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Run is already in a terminal state",
            )

        wf = await session.get(Workflow, run.workflow_id)
        workflow_name = wf.name if wf else ""

        run.status = WorkflowStatus.cancelled
        run.finished_at = datetime.now(timezone.utc)
        session.add(run)
        await session.commit()

        await manager.broadcast(
            "workflow_list",
            {"type": "run_updated", "data": _run_summary(run, workflow_name)},
        )
        await manager.broadcast(
            f"workflow_detail:{run.id}",
            {"type": "run_updated", "data": _run_detail(run, workflow_name)},
        )

        live_task = _running_tasks.get(id)
        if live_task is not None and not live_task.done():
            live_task.cancel()

        return {"status": "cancelled"}

    @router.post(
        "/workflow-runs/cancel-pending", status_code=200, tags=["workflow-runs"]
    )
    async def cancel_pending_runs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        pending = list(
            (
                await session.exec(
                    select(WorkflowRun).where(
                        WorkflowRun.status == WorkflowStatus.pending
                    )
                )
            ).all()
        )

        if not pending:
            return {"cancelled": 0}

        wf_ids = {r.workflow_id for r in pending}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        now = datetime.now(timezone.utc)
        for run in pending:
            run.status = WorkflowStatus.cancelled
            run.finished_at = now
            session.add(run)

        await session.commit()

        for run in pending:
            name = wf_names.get(run.workflow_id, "")
            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _run_summary(run, name)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {"type": "run_updated", "data": _run_detail(run, name)},
            )

        return {"cancelled": len(pending)}

    @router.post("/workflow-runs/cancel-all", status_code=200, tags=["workflow-runs"])
    async def cancel_all_runs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        """Cancel all pending and running (root-level) workflow runs."""
        runs = list(
            (
                await session.exec(
                    select(WorkflowRun).where(
                        WorkflowRun.status.in_(
                            [WorkflowStatus.pending, WorkflowStatus.running]
                        ),
                        WorkflowRun.parent_id == None,  # noqa: E711
                    )
                )
            ).all()
        )

        if not runs:
            return {"cancelled": 0}

        wf_ids = {r.workflow_id for r in runs}
        wf_entries = (
            await session.exec(select(Workflow).where(Workflow.id.in_(wf_ids)))
        ).all()
        wf_names = {w.id: w.name for w in wf_entries}

        now = datetime.now(timezone.utc)
        for run in runs:
            run.status = WorkflowStatus.cancelled
            run.finished_at = now
            session.add(run)

        await session.commit()

        for run in runs:
            name = wf_names.get(run.workflow_id, "")
            await manager.broadcast(
                "workflow_list",
                {"type": "run_updated", "data": _run_summary(run, name)},
            )
            await manager.broadcast(
                f"workflow_detail:{run.id}",
                {"type": "run_updated", "data": _run_detail(run, name)},
            )

        return {"cancelled": len(runs)}

    @router.get(
        "/execution-buckets", response_model=list[dict], tags=["execution-buckets"]
    )
    async def get_execution_buckets(
        from_ms: int = Query(..., alias="from"),
        to_ms: int = Query(..., alias="to"),
        step_ms: int = Query(..., alias="step"),
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        dt_from = datetime.fromtimestamp(from_ms / 1000, tz=timezone.utc)
        dt_to = datetime.fromtimestamp(to_ms / 1000, tz=timezone.utc)
        step_secs = step_ms / 1000

        # Push bucketing into the DB — avoids loading any row data into Python.
        slot_expr = (
            func.floor(func.extract("epoch", WorkflowRun.started_at) / step_secs)
            * step_secs
            * 1000
        ).cast(BigInteger)

        rows = (
            await session.execute(
                select(
                    slot_expr.label("slot"),
                    func.count().label("y"),
                    func.bool_or(WorkflowRun.status == WorkflowStatus.failed).label(
                        "has_failed"
                    ),
                )
                .where(
                    WorkflowRun.started_at.is_not(None),
                    WorkflowRun.started_at >= dt_from,
                    WorkflowRun.started_at <= dt_to,
                )
                .group_by(slot_expr)
                .order_by(slot_expr)
            )
        ).all()

        # Index non-empty buckets then fill the full range (so the chart has a
        # continuous series with zero-count buckets).
        filled: dict[int, dict] = {
            int(r.slot): {"x": int(r.slot), "y": r.y, "hasFailed": r.has_failed}
            for r in rows
        }
        output = []
        slot = (from_ms // step_ms) * step_ms
        last = (to_ms // step_ms) * step_ms
        while slot <= last:
            output.append(filled.get(slot, {"x": slot, "y": 0, "hasFailed": False}))
            slot += step_ms
        return output

    return router
