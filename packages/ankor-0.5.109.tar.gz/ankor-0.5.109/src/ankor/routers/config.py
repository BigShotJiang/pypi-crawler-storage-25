from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, status
from sqlmodel import select
from sqlmodel.ext.asyncio.session import AsyncSession

from ..database import get_session
from ..deps import get_current_user
from ..models import ConfigRecord, User
from .schemas import ConfigCreate, ConfigRead, ConfigUpdate


def _cfg_read(r: ConfigRecord) -> ConfigRead:
    return ConfigRead(
        id=r.id, key=r.key, value=r.value, type=r.type,
        select_options=r.select_options, description=r.description,
        folder=r.folder, created_at=r.created_at, updated_at=r.updated_at,
    )


def create_config_router() -> APIRouter:
    router = APIRouter()

    @router.get("/configs", response_model=list[ConfigRead], response_model_by_alias=True, tags=["configs"])
    async def list_configs(
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        return [_cfg_read(r) for r in (await session.exec(select(ConfigRecord))).all()]

    @router.post("/configs", response_model=ConfigRead, response_model_by_alias=True, status_code=status.HTTP_201_CREATED, tags=["configs"])
    async def create_config(
        body: ConfigCreate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = ConfigRecord(**body.model_dump(by_alias=False))
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return _cfg_read(record)

    @router.patch("/configs/{id}", response_model=ConfigRead, response_model_by_alias=True, tags=["configs"])
    async def update_config(
        id: int,
        body: ConfigUpdate,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = await session.get(ConfigRecord, id)
        if not record:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
        for field, value in body.model_dump(exclude_unset=True, by_alias=False).items():
            setattr(record, field, value)
        record.updated_at = datetime.now(timezone.utc)
        session.add(record)
        await session.commit()
        await session.refresh(record)
        return _cfg_read(record)

    @router.delete("/configs/{id}", status_code=status.HTTP_204_NO_CONTENT, tags=["configs"])
    async def delete_config(
        id: int,
        session: AsyncSession = Depends(get_session),
        _: User = Depends(get_current_user),
    ):
        record = await session.get(ConfigRecord, id)
        if not record:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Config not found")
        await session.delete(record)
        await session.commit()

    return router
