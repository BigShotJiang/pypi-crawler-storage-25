from __future__ import annotations

from typing import Any, Callable, Coroutine

from fastapi import APIRouter

from .auth import create_auth_router
from .config import create_config_router
from .db_tables import create_db_tables_router
from .runs import create_runs_router
from .users import create_users_router
from .websocket import create_websocket_router
from .workflows import create_workflows_router


def create_router(
    workflow_meta: dict,
    invoke: Callable[..., Coroutine[Any, Any, Any]],
    wrappers: dict | None = None,
) -> APIRouter:
    router = APIRouter()
    router.include_router(create_auth_router())
    router.include_router(create_runs_router(invoke))
    router.include_router(create_workflows_router(workflow_meta, invoke, wrappers))
    router.include_router(create_config_router())
    router.include_router(create_db_tables_router())
    router.include_router(create_users_router())
    router.include_router(create_websocket_router())
    return router
