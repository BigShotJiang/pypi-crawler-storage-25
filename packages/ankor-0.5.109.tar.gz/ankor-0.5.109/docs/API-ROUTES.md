# API Routes

All routes are mounted under `/api` on your FastAPI app. Routes marked **✓** require a JWT Bearer token (session token from `/auth/token` or a long-lived API token from `/tokens`).

---

## Auth

- **`POST /api/auth/token`** — Log in with username + password (OAuth2 password flow). Returns `{"access_token": "<jwt>", "token_type": "bearer"}`. Token is valid for 24 hours.
- **`POST /api/auth/register`** ✓ — Create a new user account. Requires an existing authenticated session (admin must add users). Body: `{username, email?, password}`.
- **`GET /api/auth/setup-status`** — Returns `{"setup_required": true|false}`. When `true`, no users exist yet and setup is allowed without auth. Used by the dashboard on first load to redirect to the setup page.
- **`POST /api/auth/setup`** — Creates the first admin account. Only works when no users exist. Body: `{username, email?, password}`.

---

## Health

- **`GET /api/health`** — Simple liveness check. Returns `{"status": "ok"}`. No auth required. Used by container orchestrators and uptime monitors.

---

## Webhooks

- **`POST /api/webhooks/{name}`** — Invoke a `webhook=True` workflow. Requires `Authorization: Bearer <webhook-token>` (the shared webhook signing token, not a user JWT). Body is parsed as JSON and passed to the workflow as `inputs["body"]`; request headers (minus sensitive ones) are passed as `inputs["headers"]`.
  - **Sync mode** (default): holds the connection open until the workflow finishes. Returns the workflow's return value as JSON, or `{"status": "success"}` if it returns `None`.
  - **Background mode** (`background=True` on the decorator): responds immediately with `202 {"status": "accepted"}` and runs the workflow as a background task.

---

## Workflow Runs

- **`GET /api/workflow-runs`** ✓ — Paginated list of runs. Query params: `page`, `page_size` (max 100), `status` (filter by `pending|running|success|failed|cancelled`), `workflow_name`, `from_date`, `to_date`, `search` (free-text match against trigger context JSON). Returns `{items: WorkflowRunSummary[], total, page, page_size}`. Only root runs are returned at the top level (sub-runs appear as `children`).
- **`GET /api/workflow-runs/stats`** ✓ — Dashboard stats. Returns `{counts: {pending, running, success, failed, cancelled}, active: WorkflowRunSummary[], recent: WorkflowRunSummary[]}`. `active` is up to 5 currently running runs; `recent` is the 10 most recently finished. Uses slim DB projections (no JSONB read) for speed.
- **`GET /api/workflow-runs/{id}`** ✓ — Full run detail. Returns `WorkflowRunRead` including the full node tree under `actions`. If the run is still in-memory (running), the live in-memory actions are served; otherwise the persisted `RunNode` rows are loaded from the DB.
- **`GET /api/workflow-runs/{id}/nodes`** ✓ — Slim node list for a run. Returns `WorkflowNodeSummary[]` — id, name, slug, status, durationMs, startedAt, childRunId, and recursive children. No inputs, outputs, or logs. Designed for the run timeline panel to render quickly without fetching heavy payloads.
- **`GET /api/nodes/{id}`** ✓ — Full detail for a single node. Returns `WorkflowNodeRead` — all fields including `inputs`, `outputs`, `logs[]`, and recursive `children`. Used when the user clicks a node in the timeline to inspect its data.
- **`POST /api/workflow-runs/{id}/rerun`** ✓ — Re-execute a workflow using the original inputs from the specified run. Creates a new run with `triggered_by=rerun`. The original run is left unchanged.
- **`POST /api/workflow-runs/{id}/cancel`** ✓ — Cancel a specific run. If the run is currently executing, cancels the underlying `asyncio.Task` (triggers `CancelledError`). Sets `status=cancelled` and `finished_at` on the DB row.
- **`POST /api/workflow-runs/cancel-pending`** ✓ — Bulk-cancel all `pending` (queued) runs. Does not affect currently running runs. Useful for clearing a backed-up queue.
- **`POST /api/workflow-runs/cancel-all`** ✓ — Cancel all `pending` and `running` runs. Cancels in-flight tasks and marks all as `cancelled`.

---

## Execution Buckets

- **`GET /api/execution-buckets`** ✓ — Returns run counts grouped into time buckets for dashboard charting. Query params: `from_date`, `to_date`, `workflow_name`. Used to render the run-frequency bar chart.

---

## Workflows

- **`GET /api/workflows`** ✓ — List all registered workflow definitions. Returns `WorkflowDefinitionRead[]`, each including: trigger type (`manual|schedule|webhook`), schedule expression, enabled state, `folder` (optional path string for grouping in the dashboard tree), `input_schema` (the array of field definitions used to render the trigger form), `description` (freetext hint shown in the UI), `last_run_at`, `last_run_status`, `total_runs`, `failure_rate`, and `recent_nodes` (node names from the last run).
- **`GET /api/workflows/{name}`** ✓ — Single workflow definition with the same fields as the list, plus the current DB-persisted config overrides.
- **`PATCH /api/workflows/{name}`** ✓ — Override per-workflow runtime config without redeploying. Persists a `Workflow` row. Fields: `enabled` (pause/unpause), `cron_override` (different schedule than the decorated default), `interval_override`, `timeout_seconds` (adds an `asyncio.wait_for` wrapper), `max_concurrent_runs` (0 = disabled, N = queue pending runs when N slots are full).
- **`POST /api/workflows/{name}/trigger`** ✓ — Manually trigger a workflow. Body: `{inputs: dict}` (validated against the workflow's `input_schema`). Fires the workflow as a background asyncio task and returns immediately with `{"run_id": <id>}`.

---

## Config Store

- **`GET /api/configs`** ✓ — List all config records. Returns `ConfigRead[]` with id, key, value (always a string), type, select_options, description, folder, and timestamps.
- **`POST /api/configs`** ✓ — Create a new config record. Body: `{key, value, type, select_options?, description?, folder?}`. Types: `string`, `number`, `boolean`, `date`, `datetime`, `time`, `json`, `select`.
- **`PATCH /api/configs/{id}`** ✓ — Partial update of any config field. Commonly used to change `value` from the dashboard form.
- **`DELETE /api/configs/{id}`** ✓ — Delete a config record.

---

## Data Tables

- **`GET /api/db-tables`** ✓ — List all data tables with their columns and all rows. Each table is a real Postgres table (`data_table_<id>`). Response: `DbTableRead[]` — id, name, description, columns schema, and rows.
- **`POST /api/db-tables`** ✓ — Create a new table. Body: `{name, description?, columns: [{id, name, type}]}`. Creates the Postgres table immediately.
- **`PATCH /api/db-tables/{id}`** ✓ — Multi-purpose update endpoint. The `op` field in the body selects the operation:
  - `add_column` — adds a new column to the Postgres table.
  - `rename_column` — renames a column (both the Postgres column and the metadata).
  - `delete_column` — drops a column.
  - `retype_column` — changes a column's type declaration (metadata only; no data migration).
  - `add_row` / `update_row` / `delete_row` — row-level CRUD.
  - `import_csv` — accepts a multipart file upload, parses the CSV via `csv_import.parse_csv`, and bulk-inserts rows. Returns `{imported, errors[]}`.
  - `export_csv` — returns a CSV file download of all rows.
  - `update_rows` — bulk upsert (used by the dashboard spreadsheet editor).
  - `get_rows` — server-side paginated/filtered row fetch with optional MUI DataGrid filter model support.
- **`DELETE /api/db-tables/{id}`** ✓ — Drop the Postgres table and delete the `DataTable` metadata row.

---

## Users

- **`GET /api/users`** ✓ — List all users. Returns `UserRead[]` — username, email, role, created_at. Passwords are never returned.
- **`POST /api/users`** ✓ — Create a user. Body: `{username, email?, password}`. Password is bcrypt-hashed before storage.
- **`DELETE /api/users/{username}`** ✓ — Delete a user. Cannot delete the currently authenticated user.
- **`PATCH /api/users/{username}/password`** ✓ — Change a user's password. Body: `{password}`. Rehashes with bcrypt.

---

## API Tokens

Long-lived tokens for programmatic / CI use, scoped to the creating user.

- **`GET /api/tokens`** ✓ — List the current user's API tokens. Returns `ApiTokenRead[]` — id, name, created_at, expires_at. The raw token string is **not** returned after creation.
- **`POST /api/tokens`** ✓ — Create an API token. Body: `{name, expires_days?}`. Returns `ApiTokenCreated` which includes the raw token — store it securely, it is shown only once.
- **`DELETE /api/tokens/{id}`** ✓ — Revoke a token.

---

## Webhook Token

A single shared secret used to authenticate incoming webhooks.

- **`GET /api/webhook-token`** ✓ — Return the current webhook signing token.
- **`POST /api/webhook-token/rotate`** ✓ — Generate and store a new random token. Existing integrations sending the old token will immediately start receiving 401 responses.

---

## WebSocket

- **`WS /api/ws?token=<jwt>`** ✓ — Real-time event stream. After connecting, send `{"type": "subscribe", "channel": "<name>"}` to subscribe to a channel. You can resubscribe at any time to switch channels without reconnecting.
  - Channel `workflow_list` — receives `run_created` and `run_updated` events for all runs (used by the dashboard list and stats).
  - Channel `workflow_detail:<id>` — receives `run_updated` events for a specific run as each node starts, updates, and finishes (used by the run detail panel for live updates).
  - Event payload shape: `{"type": "run_created"|"run_updated", "data": WorkflowRunSummary|WorkflowRunRead}`.

---

## Dashboard

- **`GET /admin/`** — Serves the React SPA. No auth at the network level (the SPA handles its own login flow). In production, served from the bundled `static/` directory. In dev (`GTM_DEV=true`), requests are proxied to Vite on `:5173`.
