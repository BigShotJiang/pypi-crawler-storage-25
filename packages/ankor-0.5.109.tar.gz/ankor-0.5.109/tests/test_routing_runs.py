"""Tests for workflow-runs read endpoints (stats, list, detail).

Cancel and rerun are covered in test_cancel.py and test_rerun.py.
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

from fastapi import FastAPI
from fastapi.testclient import TestClient

from ankor.database import get_session
from ankor.deps import get_current_user
from ankor.models import RunNode, TriggerType, Workflow, WorkflowRun, WorkflowStatus
from ankor.router import create_router


def _build_run(
    run_id: int = 1,
    workflow_id: int = 1,
    status: WorkflowStatus = WorkflowStatus.success,
) -> WorkflowRun:
    return WorkflowRun(
        id=run_id,
        workflow_id=workflow_id,
        status=status,
        triggered_by=TriggerType.manual,
        data={"trigger_context": {}, "inputs": {}, "outputs": {}},
    )


def _make_client(
    run: WorkflowRun | None = None,
    runs: list[WorkflowRun] | None = None,
    workflows: list[Workflow] | None = None,
    status_counts: list[tuple] | None = None,
    nodes: list[RunNode] | None = None,
):
    """Build a TestClient with a flexible mock session."""
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    _runs = runs or ([] if run is None else [run])
    _workflows = workflows or [Workflow(id=1, name="wf_one")]
    _status_counts = status_counts or []
    _nodes = nodes or []

    async def _override_session():
        session = AsyncMock()

        async def _mock_get(model_cls, pk):
            if model_cls is WorkflowRun:
                return run
            if model_cls is Workflow:
                return next((w for w in _workflows if w.id == pk), None)
            return None

        session.get = _mock_get

        exec_calls: list = []

        async def _mock_execute(stmt):
            result = MagicMock()
            idx = len(exec_calls)
            exec_calls.append(stmt)
            if idx == 0:
                # stats query: group-by status counts
                result.all.return_value = _status_counts
                result.scalar_one.return_value = len(_runs)
            else:
                result.scalar_one.return_value = len(_runs)
            return result

        # Each exec() call in an endpoint returns something different:
        # list_runs:   [0]=roots, [1]=children, [2]=workflows
        # detail run:  [0]=children, [1]=workflows  (grandchildren skipped if no children)
        # stats:       [0]=active runs, [1]=recent runs, [2]=workflows
        exec_seq = [_runs, [], _workflows, _workflows]
        exec_idx_box = [0]

        async def _mock_exec(stmt):
            r = MagicMock()
            idx = exec_idx_box[0]
            exec_idx_box[0] += 1
            # Return data based on which model is being queried
            descs = getattr(stmt, "column_descriptions", [])
            entity = descs[0].get("entity") if descs else None
            if entity is Workflow:
                data = _workflows
            elif entity is RunNode:
                data = _nodes
            else:
                data = exec_seq[idx] if idx < len(exec_seq) else []
            r.all.return_value = data
            r.first.return_value = data[0] if data else None
            return r

        session.execute = _mock_execute
        session.exec = _mock_exec

        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")

    return TestClient(app)


# ---------------------------------------------------------------------------
# GET /workflow-runs/stats
# ---------------------------------------------------------------------------


def test_get_stats_returns_200():
    client = _make_client()
    resp = client.get("/api/workflow-runs/stats")
    assert resp.status_code == 200
    body = resp.json()
    # All WorkflowStatus variants must be present in counts
    assert "pending" in body["counts"]
    assert "running" in body["counts"]
    assert "success" in body["counts"]
    assert "failed" in body["counts"]
    assert "cancelled" in body["counts"]
    assert "active" in body
    assert "recent" in body


def _unauthenticated_client() -> TestClient:
    """Client with a mocked session but no auth override — expects 401 responses."""
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    async def _null_session():
        yield AsyncMock()

    app.dependency_overrides[get_session] = _null_session
    return TestClient(app)


def test_get_stats_requires_auth():
    resp = _unauthenticated_client().get("/api/workflow-runs/stats")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /workflow-runs
# ---------------------------------------------------------------------------


def test_list_runs_returns_200_and_total_count_header():
    run = _build_run()
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs")
    assert resp.status_code == 200
    assert "X-Total-Count" in resp.headers


def test_list_runs_empty():
    client = _make_client(runs=[])
    resp = client.get("/api/workflow-runs")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_runs_pagination_params_accepted():
    run = _build_run()
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs?offset=0&limit=10")
    assert resp.status_code == 200


def test_list_runs_status_filter_accepted():
    run = _build_run(status=WorkflowStatus.success)
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs?status=success")
    assert resp.status_code == 200


def test_list_runs_workflow_name_filter_accepted():
    run = _build_run()
    client = _make_client(run=run, runs=[run])
    resp = client.get("/api/workflow-runs?workflow_name=wf_one")
    assert resp.status_code == 200


def test_list_runs_requires_auth():
    resp = _unauthenticated_client().get("/api/workflow-runs")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /workflow-runs/{id}
# ---------------------------------------------------------------------------


def test_get_run_by_id_found():
    run = _build_run()
    client = _make_client(run=run)
    resp = client.get(f"/api/workflow-runs/{run.id}")
    assert resp.status_code == 200
    body = resp.json()
    assert body["id"] == run.id
    assert body["status"] == run.status.value


def test_get_run_by_id_not_found():
    client = _make_client(run=None)
    resp = client.get("/api/workflow-runs/9999")
    assert resp.status_code == 404


def test_get_run_by_id_requires_auth():
    resp = _unauthenticated_client().get("/api/workflow-runs/1")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /execution-buckets
# ---------------------------------------------------------------------------


def test_execution_buckets_returns_200():
    client = _make_client(runs=[])
    resp = client.get("/api/execution-buckets?from=0&to=60000&step=10000")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)


def test_execution_buckets_requires_auth():
    resp = _unauthenticated_client().get(
        "/api/execution-buckets?from=0&to=60000&step=10000"
    )
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /workflow-runs/{id}/nodes
# ---------------------------------------------------------------------------


def test_get_run_nodes_empty():
    run = _build_run()
    client = _make_client(run=run)
    resp = client.get(f"/api/workflow-runs/{run.id}/nodes")
    assert resp.status_code == 200
    assert resp.json() == []


def test_get_run_nodes_returns_slim_data():
    """List endpoint returns slim summary — no inputs/outputs/logs."""
    run = _build_run()
    node = RunNode(
        id=1,
        run_id=run.id,
        parent_node_id=None,
        name="fetch_data",
        slug=None,
        status=WorkflowStatus.success,
        duration_ms=100,
        child_run_id=None,
        data={"inputs": {"query": "SELECT 1"}, "outputs": {"result": 42}, "logs": None},
    )
    client = _make_client(run=run, nodes=[node])
    resp = client.get(f"/api/workflow-runs/{run.id}/nodes")
    assert resp.status_code == 200
    body = resp.json()
    assert len(body) == 1
    n = body[0]
    assert n["id"] == 1
    assert n["name"] == "fetch_data"
    assert n["status"] == "success"
    assert n["durationMs"] == 100
    # Heavy fields must NOT be present in the slim list.
    assert "inputs" not in n
    assert "outputs" not in n
    assert "logs" not in n


def test_get_run_nodes_not_found():
    client = _make_client(run=None)
    resp = client.get("/api/workflow-runs/9999/nodes")
    assert resp.status_code == 404


def test_get_run_nodes_requires_auth():
    resp = _unauthenticated_client().get("/api/workflow-runs/1/nodes")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /nodes/{id}
# ---------------------------------------------------------------------------


def _make_node_client(node: RunNode | None, all_run_nodes: list[RunNode] | None = None):
    """Build a TestClient for the /nodes/{id} endpoint."""
    app = FastAPI()
    from ankor.router import create_router
    from unittest.mock import AsyncMock, MagicMock

    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    _nodes = all_run_nodes or ([] if node is None else [node])

    async def _override_session():
        session = AsyncMock()

        async def _mock_get(model_cls, pk):
            if model_cls is RunNode:
                return node
            return None

        session.get = _mock_get

        async def _mock_exec(stmt):
            r = MagicMock()
            r.all.return_value = _nodes
            r.first.return_value = _nodes[0] if _nodes else None
            return r

        session.exec = _mock_exec
        session.execute = AsyncMock(
            return_value=MagicMock(all=lambda: [], scalar_one=lambda: 0)
        )
        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")
    return TestClient(app)


def test_get_node_detail_returns_full_data():
    """GET /nodes/{id} returns the full node payload including inputs/outputs/logs."""
    node = RunNode(
        id=1,
        run_id=1,
        parent_node_id=None,
        name="fetch_data",
        slug=None,
        status=WorkflowStatus.success,
        duration_ms=100,
        child_run_id=None,
        data={
            "inputs": {"query": "SELECT 1"},
            "outputs": {"result": 42},
            "logs": [
                {
                    "timestamp": "2026-04-16T10:00:00+00:00",
                    "body": "ok",
                    "type": "info",
                    "json": False,
                }
            ],
        },
    )
    client = _make_node_client(node)
    resp = client.get("/api/nodes/1")
    assert resp.status_code == 200
    body = resp.json()
    assert body["id"] == 1
    assert body["name"] == "fetch_data"
    assert body["status"] == "success"
    assert body["inputs"] == {"query": "SELECT 1"}
    assert body["outputs"] == {"result": 42}
    assert len(body["logs"]) == 1


def test_get_node_detail_not_found():
    client = _make_node_client(None)
    resp = client.get("/api/nodes/9999")
    assert resp.status_code == 404


def test_get_node_detail_requires_auth():
    resp = _unauthenticated_client().get("/api/nodes/1")
    assert resp.status_code == 401
