"""Tests for input_schema and description fields on GET /workflows."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from ankor.database import get_session
from ankor.deps import get_current_user
from ankor.router import create_router
from ankor.trigger_context import TriggerContext

_SCHEMA_META = {
    "my_workflow": {
        "trigger_type": "manual",
        "schedule": None,
        "is_webhook": False,
        "webhook_path": None,
        "input_schema": [
            {"key": "limit", "type": "number", "label": "Limit", "default": 10},
            {"key": "dry_run", "type": "boolean", "label": "Dry run", "default": False},
            {
                "key": "mode",
                "type": "select",
                "label": "Mode",
                "options": ["fast", "slow"],
                "required": True,
            },
        ],
        "description": "Run this to enrich contacts.",
    },
    "bare_workflow": {
        "trigger_type": "manual",
        "schedule": None,
        "is_webhook": False,
        "webhook_path": None,
        "input_schema": [],
        "description": None,
    },
}


def _make_client():
    async def _invoke(name: str, ctx: TriggerContext) -> None:
        pass

    app = FastAPI()
    router = create_router(_SCHEMA_META, invoke=_invoke)
    app.include_router(router, prefix="/api")

    async def _override_session():
        # All Workflow DB lookups return None (no DB row — defaults to enabled)
        exec_result = MagicMock()
        exec_result.first = MagicMock(return_value=None)
        exec_result.all = MagicMock(return_value=[])
        session = AsyncMock()
        session.exec = AsyncMock(return_value=exec_result)
        execute_result = MagicMock()
        execute_result.scalar_one = MagicMock(return_value=0)
        session.execute = AsyncMock(return_value=execute_result)
        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")

    return TestClient(app)


def test_list_workflows_includes_input_schema():
    client = _make_client()
    resp = client.get("/api/workflows")
    assert resp.status_code == 200
    data = {w["name"]: w for w in resp.json()}

    wf = data["my_workflow"]
    assert len(wf["inputSchema"]) == 3

    limit_field = next(f for f in wf["inputSchema"] if f["key"] == "limit")
    assert limit_field["type"] == "number"
    assert limit_field["label"] == "Limit"
    assert limit_field["default"] == 10

    dry_run_field = next(f for f in wf["inputSchema"] if f["key"] == "dry_run")
    assert dry_run_field["type"] == "boolean"
    assert dry_run_field["default"] is False

    mode_field = next(f for f in wf["inputSchema"] if f["key"] == "mode")
    assert mode_field["type"] == "select"
    assert mode_field["options"] == ["fast", "slow"]
    assert mode_field["required"] is True


def test_list_workflows_includes_description():
    client = _make_client()
    resp = client.get("/api/workflows")
    assert resp.status_code == 200
    data = {w["name"]: w for w in resp.json()}
    assert data["my_workflow"]["description"] == "Run this to enrich contacts."


def test_bare_workflow_has_empty_schema_and_no_description():
    client = _make_client()
    resp = client.get("/api/workflows")
    assert resp.status_code == 200
    data = {w["name"]: w for w in resp.json()}
    assert data["bare_workflow"]["inputSchema"] == []
    assert data["bare_workflow"]["description"] is None
