"""Tests for workflow definition endpoints (list, get, patch, trigger)."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from ankor.database import get_session
from ankor.deps import get_current_user
from ankor.models import TriggerType, Workflow, WorkflowRun, WorkflowStatus
from ankor.router import create_router
from ankor.trigger_context import TriggerContext


_WORKFLOW_META = {
    "my_wf": {
        "trigger_type": "manual",
        "schedule": None,
        "is_webhook": False,
        "webhook_path": None,
        "input_schema": [],
        "description": None,
    }
}


def _make_client(
    workflow_cfg: Workflow | None = None,
    workflow_meta: dict | None = None,
    invoke=None,
):
    async def default_invoke(name: str, ctx: TriggerContext) -> None:
        pass

    app = FastAPI()
    router = create_router(
        workflow_meta if workflow_meta is not None else _WORKFLOW_META,
        invoke=invoke or default_invoke,
    )
    app.include_router(router, prefix="/api")

    async def _override_session():
        session = AsyncMock()

        async def _mock_get(model_cls, pk):
            if model_cls is Workflow:
                return workflow_cfg
            return None

        session.get = _mock_get

        count_result = MagicMock()
        count_result.scalar_one.return_value = 0
        session.execute = AsyncMock(return_value=count_result)

        # Exec call sequence inside workflow endpoints:
        # PATCH: [0] cfg lookup, [1] wf lookup (in _build_wf_def), [2] last_run lookup
        # GET:   [0] wf lookup,  [1] last_run lookup
        # exec(Workflow) → workflow_cfg; exec(WorkflowRun) → None
        exec_seq = [workflow_cfg, workflow_cfg, None, None]
        exec_idx_box = [0]

        async def _mock_exec(stmt):
            r = MagicMock()
            idx = exec_idx_box[0]
            exec_idx_box[0] += 1
            val = exec_seq[idx] if idx < len(exec_seq) else None
            r.all.return_value = [val] if val is not None else []
            r.first.return_value = val
            return r

        session.exec = _mock_exec
        session.add = MagicMock()
        yield session

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")
    return TestClient(app)


# ---------------------------------------------------------------------------
# GET /workflows
# ---------------------------------------------------------------------------


def test_list_workflows_returns_registered_entries():
    client = _make_client()
    resp = client.get("/api/workflows")
    assert resp.status_code == 200
    body = resp.json()
    assert isinstance(body, list)
    assert len(body) == 1
    assert body[0]["name"] == "my_wf"


def test_list_workflows_empty_when_no_meta():
    client = _make_client(workflow_meta={})
    resp = client.get("/api/workflows")
    assert resp.status_code == 200
    assert resp.json() == []


def _unauthenticated_client() -> TestClient:
    app = FastAPI()
    router = create_router(_WORKFLOW_META, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    async def _null_session():
        yield AsyncMock()

    app.dependency_overrides[get_session] = _null_session
    return TestClient(app)


def test_list_workflows_requires_auth():
    resp = _unauthenticated_client().get("/api/workflows")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# GET /workflows/{name}
# ---------------------------------------------------------------------------


def test_get_workflow_found():
    client = _make_client()
    resp = client.get("/api/workflows/my_wf")
    assert resp.status_code == 200
    assert resp.json()["name"] == "my_wf"


def test_get_workflow_not_found():
    client = _make_client()
    resp = client.get("/api/workflows/unknown_wf")
    assert resp.status_code == 404


def test_get_workflow_requires_auth():
    resp = _unauthenticated_client().get("/api/workflows/my_wf")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# PATCH /workflows/{name}
# ---------------------------------------------------------------------------


def test_patch_workflow_not_found():
    client = _make_client()
    resp = client.patch("/api/workflows/unknown_wf", json={"enabled": False})
    assert resp.status_code == 404


def test_patch_workflow_creates_config_when_absent():
    """PATCH on a registered workflow with no existing DB config creates one."""
    client = _make_client(workflow_cfg=None)
    resp = client.patch("/api/workflows/my_wf", json={"enabled": False})
    assert resp.status_code == 200
    assert resp.json()["name"] == "my_wf"


def test_patch_workflow_updates_existing_config():
    cfg = Workflow(id=1, name="my_wf", enabled=True)
    client = _make_client(workflow_cfg=cfg)
    resp = client.patch("/api/workflows/my_wf", json={"enabled": False})
    assert resp.status_code == 200


# ---------------------------------------------------------------------------
# POST /workflows/{name}/trigger
# ---------------------------------------------------------------------------


def test_trigger_workflow_not_found():
    client = _make_client()
    resp = client.post("/api/workflows/unknown_wf/trigger", json={"inputs": {}})
    assert resp.status_code == 404


def test_trigger_workflow_disabled():
    cfg = Workflow(id=1, name="my_wf", enabled=False)
    client = _make_client(workflow_cfg=cfg)
    resp = client.post("/api/workflows/my_wf/trigger", json={"inputs": {}})
    assert resp.status_code == 409


def test_trigger_workflow_success():
    captured: dict = {}

    async def capturing_invoke(name: str, ctx: TriggerContext) -> None:
        captured["name"] = name
        captured["ctx"] = ctx

    client = _make_client(invoke=capturing_invoke)
    resp = client.post("/api/workflows/my_wf/trigger", json={"inputs": {"key": "val"}})
    assert resp.status_code == 202
    assert resp.json() == {"status": "accepted"}
    assert captured["name"] == "my_wf"
    assert captured["ctx"].inputs == {"key": "val"}
    assert captured["ctx"].type == "manual"


def test_trigger_workflow_requires_auth():
    resp = _unauthenticated_client().post(
        "/api/workflows/my_wf/trigger", json={"inputs": {}}
    )
    assert resp.status_code == 401
