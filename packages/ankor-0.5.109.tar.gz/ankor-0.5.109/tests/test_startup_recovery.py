"""Tests for _recover_from_restart — startup recovery of interrupted workflow runs.

Simulates server stoppage by pre-populating a mock session with runs in various
states, then calling _recover_from_restart directly.  No live server needed.
"""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ankor.core import _recover_from_restart
from ankor.models import TriggerType, WorkflowRun, WorkflowStatus

# _ensure_drain_task and _notify_drain are imported lazily inside
# _recover_from_restart via `from .decorator import ...`.  The lazy import
# resolves names from the ankor.decorator namespace, so we patch there.
_DRAIN_ENSURE = "ankor.decorator._ensure_drain_task"
_DRAIN_NOTIFY = "ankor.decorator._notify_drain"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_run(run_id: int, status: WorkflowStatus, workflow_id: int = 1) -> WorkflowRun:
    return WorkflowRun(
        id=run_id,
        workflow_id=workflow_id,
        status=status,
        triggered_by=TriggerType.manual,
        data={"inputs": {}, "outputs": {}, "actions": []},
    )


def _mock_session(
    orphaned_runs: list[WorkflowRun], pending_wf_names: list[str]
) -> AsyncMock:
    """Build a mock async session that returns the two exec() result sequences."""
    session = AsyncMock()
    session.add = MagicMock()

    exec_calls: list = []

    async def _mock_exec(stmt):
        result = MagicMock()
        idx = len(exec_calls)
        exec_calls.append(stmt)
        if idx == 0:
            result.all.return_value = orphaned_runs
        else:
            result.all.return_value = pending_wf_names
        return result

    session.exec = _mock_exec
    return session


# ---------------------------------------------------------------------------
# Tests: orphaned running runs are cancelled
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_running_runs_are_cancelled():
    runs = [_make_run(1, WorkflowStatus.running), _make_run(2, WorkflowStatus.running)]
    session = _mock_session(orphaned_runs=runs, pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={})

    for run in runs:
        assert run.status == WorkflowStatus.cancelled
        assert run.finished_at is not None


@pytest.mark.asyncio
async def test_cancelled_runs_have_finished_at_set():
    run = _make_run(1, WorkflowStatus.running)
    before = datetime.now(timezone.utc)
    session = _mock_session(orphaned_runs=[run], pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={})

    assert run.finished_at >= before


@pytest.mark.asyncio
async def test_orphaned_runs_are_added_to_session():
    runs = [_make_run(1, WorkflowStatus.running), _make_run(2, WorkflowStatus.running)]
    session = _mock_session(orphaned_runs=runs, pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={})

    assert session.add.call_count == 2
    added_runs = [c.args[0] for c in session.add.call_args_list]
    assert set(r.id for r in added_runs) == {1, 2}


@pytest.mark.asyncio
async def test_commit_called_when_orphaned_runs_exist():
    run = _make_run(1, WorkflowStatus.running)
    session = _mock_session(orphaned_runs=[run], pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={})

    session.commit.assert_called_once()


@pytest.mark.asyncio
async def test_commit_not_called_when_no_orphaned_runs():
    session = _mock_session(orphaned_runs=[], pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={})

    session.commit.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: pending runs resume drain
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_pending_runs_start_drain_task():
    async def my_workflow(inputs: dict):
        return {}

    session = _mock_session(orphaned_runs=[], pending_wf_names=["my_workflow"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify:
        await _recover_from_restart(session, wrappers={"my_workflow": my_workflow})

    mock_ensure.assert_called_once_with("my_workflow", my_workflow)
    mock_notify.assert_called_once_with("my_workflow")


@pytest.mark.asyncio
async def test_pending_runs_for_multiple_workflows():
    async def wf_one(inputs: dict):
        return {}

    async def wf_two(inputs: dict):
        return {}

    session = _mock_session(orphaned_runs=[], pending_wf_names=["wf_one", "wf_two"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify:
        await _recover_from_restart(
            session, wrappers={"wf_one": wf_one, "wf_two": wf_two}
        )

    assert mock_ensure.call_count == 2
    assert mock_notify.call_count == 2


@pytest.mark.asyncio
async def test_pending_runs_for_unregistered_workflow_are_skipped():
    """Pending runs for a workflow that no longer exists in wrappers must not start a drain."""
    session = _mock_session(orphaned_runs=[], pending_wf_names=["removed_workflow"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify:
        await _recover_from_restart(session, wrappers={})

    mock_ensure.assert_not_called()
    mock_notify.assert_not_called()


# ---------------------------------------------------------------------------
# Tests: mixed and edge cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_clean_state_is_a_noop():
    """No running or pending runs — nothing should be written or started."""
    session = _mock_session(orphaned_runs=[], pending_wf_names=[])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify:
        await _recover_from_restart(session, wrappers={})

    session.add.assert_not_called()
    session.commit.assert_not_called()
    mock_ensure.assert_not_called()
    mock_notify.assert_not_called()


@pytest.mark.asyncio
async def test_mixed_running_and_pending_both_handled():
    """Running runs are cancelled AND pending runs get drained in the same call."""

    async def my_workflow(inputs: dict):
        return {}

    orphaned = [_make_run(10, WorkflowStatus.running)]
    session = _mock_session(orphaned_runs=orphaned, pending_wf_names=["my_workflow"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY) as mock_notify:
        await _recover_from_restart(session, wrappers={"my_workflow": my_workflow})

    assert orphaned[0].status == WorkflowStatus.cancelled
    assert orphaned[0].finished_at is not None
    session.commit.assert_called_once()
    mock_ensure.assert_called_once_with("my_workflow", my_workflow)
    mock_notify.assert_called_once_with("my_workflow")


@pytest.mark.asyncio
async def test_wrapper_with_gtm_fn_attribute_uses_raw_fn():
    """When wrapper has _gtm_fn attribute, the raw underlying fn is passed to drain."""

    async def raw_fn(inputs: dict):
        return {}

    wrapper = MagicMock()
    wrapper._gtm_fn = raw_fn

    session = _mock_session(orphaned_runs=[], pending_wf_names=["my_workflow"])

    with patch(_DRAIN_ENSURE) as mock_ensure, patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={"my_workflow": wrapper})

    mock_ensure.assert_called_once_with("my_workflow", raw_fn)


@pytest.mark.asyncio
async def test_multiple_orphaned_runs_single_commit():
    """All orphaned runs are batched and committed in one go."""
    runs = [_make_run(i, WorkflowStatus.running) for i in range(1, 6)]
    session = _mock_session(orphaned_runs=runs, pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={})

    assert session.add.call_count == 5
    session.commit.assert_called_once()
    assert all(r.status == WorkflowStatus.cancelled for r in runs)


@pytest.mark.asyncio
async def test_child_runs_also_cancelled():
    """Sub-workflow runs (parent_id set) are orphaned too and must be cancelled."""
    parent_run = _make_run(1, WorkflowStatus.running)
    child_run = WorkflowRun(
        id=2,
        workflow_id=1,
        parent_id=1,
        status=WorkflowStatus.running,
        triggered_by=TriggerType.manual,
        data={},
    )
    session = _mock_session(orphaned_runs=[parent_run, child_run], pending_wf_names=[])

    with patch(_DRAIN_ENSURE), patch(_DRAIN_NOTIFY):
        await _recover_from_restart(session, wrappers={})

    assert parent_run.status == WorkflowStatus.cancelled
    assert child_run.status == WorkflowStatus.cancelled
