"""Tests for user, API-token, and webhook-token endpoints."""

from __future__ import annotations

from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

import ankor.auth as auth_module
from ankor.database import get_session
from ankor.deps import get_current_user
from ankor.models import ApiToken, User, UserRole, WebhookToken
from ankor.router import create_router


# Stable secret needed so create_api_token / decode_token work.
auth_module.configure("test-secret")


def _make_user(username: str = "admin") -> User:
    return User(
        username=username,
        hashed_password=auth_module.hash_password("pw"),
        role=UserRole.admin,
        created_at=datetime.now(timezone.utc),
    )


def _make_token(token_id: int = 1, username: str = "admin") -> ApiToken:
    return ApiToken(
        id=token_id,
        name="my-token",
        username=username,
        created_at=datetime.now(timezone.utc),
    )


def _make_client(
    target_user: User | None = None,
    api_token: ApiToken | None = None,
    users: list[User] | None = None,
    tokens: list[ApiToken] | None = None,
    webhook_token: WebhookToken | None = None,
    current_username: str = "admin",
):
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    _users = users or []
    _tokens = tokens or []

    async def _override_session():
        session = AsyncMock()

        async def _mock_get(model_cls, pk):
            if model_cls is User:
                return target_user
            if model_cls is ApiToken:
                return api_token
            if model_cls is WebhookToken:
                return webhook_token
            return None

        session.get = _mock_get

        async def _mock_exec(stmt):
            r = MagicMock()
            r.all.return_value = _users or _tokens
            r.first.return_value = (
                (_users or _tokens)[0] if (_users or _tokens) else None
            )
            return r

        session.exec = _mock_exec
        session.add = MagicMock()
        session.delete = AsyncMock()

        async def _mock_refresh(obj):
            if isinstance(obj, ApiToken) and obj.id is None:
                obj.id = 1

        session.refresh = _mock_refresh
        yield session

    def _get_user():
        return MagicMock(username=current_username)

    app.dependency_overrides[get_session] = _override_session
    app.dependency_overrides[get_current_user] = _get_user
    return TestClient(app)


# ---------------------------------------------------------------------------
# GET /users
# ---------------------------------------------------------------------------


def test_list_users_returns_200():
    users = [_make_user("alice"), _make_user("bob")]
    client = _make_client(users=users)
    resp = client.get("/api/users")
    assert resp.status_code == 200
    assert len(resp.json()) == 2


def _unauthenticated_client() -> TestClient:
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")

    async def _null_session():
        yield AsyncMock()

    app.dependency_overrides[get_session] = _null_session
    return TestClient(app)


def test_list_users_requires_auth():
    resp = _unauthenticated_client().get("/api/users")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# POST /users
# ---------------------------------------------------------------------------


def test_create_user_success():
    client = _make_client(target_user=None)
    resp = client.post("/api/users", json={"username": "newuser", "password": "pw"})
    assert resp.status_code == 201
    assert resp.json()["username"] == "newuser"


def test_create_user_duplicate():
    existing = _make_user("bob")
    client = _make_client(target_user=existing)
    resp = client.post("/api/users", json={"username": "bob", "password": "pw"})
    assert resp.status_code == 409


# ---------------------------------------------------------------------------
# DELETE /users/{username}
# ---------------------------------------------------------------------------


def test_delete_own_user_is_forbidden():
    user = _make_user("admin")
    client = _make_client(target_user=user, current_username="admin", tokens=[])
    resp = client.delete("/api/users/admin")
    assert resp.status_code == 400


def test_delete_user_not_found():
    client = _make_client(target_user=None)
    resp = client.delete("/api/users/ghost")
    assert resp.status_code == 404


def test_delete_user_success():
    user = _make_user("alice")
    client = _make_client(target_user=user, current_username="admin", tokens=[])
    resp = client.delete("/api/users/alice")
    assert resp.status_code == 204


# ---------------------------------------------------------------------------
# PATCH /users/{username}/password
# ---------------------------------------------------------------------------


def test_update_password_not_found():
    client = _make_client(target_user=None)
    resp = client.patch("/api/users/ghost/password", json={"password": "new-pw"})
    assert resp.status_code == 404


def test_update_password_success():
    user = _make_user("alice")
    client = _make_client(target_user=user)
    resp = client.patch("/api/users/alice/password", json={"password": "new-pw"})
    assert resp.status_code == 204


# ---------------------------------------------------------------------------
# GET /tokens
# ---------------------------------------------------------------------------


def test_list_tokens_returns_own_tokens():
    token = _make_token(username="admin")
    client = _make_client(tokens=[token], current_username="admin")
    resp = client.get("/api/tokens")
    assert resp.status_code == 200
    assert len(resp.json()) == 1


def test_list_tokens_requires_auth():
    resp = _unauthenticated_client().get("/api/tokens")
    assert resp.status_code == 401


# ---------------------------------------------------------------------------
# POST /tokens
# ---------------------------------------------------------------------------


def test_create_token_returns_token_string():
    client = _make_client(current_username="admin")
    resp = client.post("/api/tokens", json={"name": "ci-token"})
    assert resp.status_code == 201
    body = resp.json()
    assert "token" in body
    assert body["name"] == "ci-token"


def test_create_token_with_expiry():
    client = _make_client(current_username="admin")
    resp = client.post("/api/tokens", json={"name": "short-lived", "expiresDays": 30})
    assert resp.status_code == 201


# ---------------------------------------------------------------------------
# DELETE /tokens/{id}
# ---------------------------------------------------------------------------


def test_revoke_token_not_found():
    client = _make_client(api_token=None, current_username="admin")
    resp = client.delete("/api/tokens/999")
    assert resp.status_code == 404


def test_revoke_token_belonging_to_other_user():
    """A token owned by someone else should appear as not-found (security)."""
    token = _make_token(token_id=5, username="other-user")
    client = _make_client(api_token=token, current_username="admin")
    resp = client.delete("/api/tokens/5")
    assert resp.status_code == 404


def test_revoke_token_success():
    token = _make_token(token_id=5, username="admin")
    client = _make_client(api_token=token, current_username="admin")
    resp = client.delete("/api/tokens/5")
    assert resp.status_code == 204


# ---------------------------------------------------------------------------
# GET /webhook-token
# ---------------------------------------------------------------------------


def test_get_webhook_token_not_found():
    client = _make_client(webhook_token=None)
    resp = client.get("/api/webhook-token")
    assert resp.status_code == 404


def test_get_webhook_token_found():
    wt = WebhookToken(token="abc123", created_at=datetime.now(timezone.utc))
    client = _make_client(webhook_token=wt)
    resp = client.get("/api/webhook-token")
    assert resp.status_code == 200
    assert resp.json()["token"] == "abc123"


# ---------------------------------------------------------------------------
# POST /webhook-token/rotate
# ---------------------------------------------------------------------------


def test_rotate_webhook_token_creates_new_when_absent():
    client = _make_client(webhook_token=None)
    resp = client.post("/api/webhook-token/rotate")
    assert resp.status_code == 200
    body = resp.json()
    assert "token" in body
    assert len(body["token"]) > 0


def test_rotate_webhook_token_updates_existing():
    wt = WebhookToken(token="old-token", created_at=datetime.now(timezone.utc))
    client = _make_client(webhook_token=wt)
    resp = client.post("/api/webhook-token/rotate")
    assert resp.status_code == 200
    # Token must have changed
    assert resp.json()["token"] != "old-token"
