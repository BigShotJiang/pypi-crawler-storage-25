"""Tests for data table CSV import/export endpoints and value coercion."""

from __future__ import annotations

import csv
import io
import json
from datetime import date, datetime, timezone
from unittest.mock import AsyncMock, MagicMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from ankor.database import get_session
from ankor.deps import get_current_user
from ankor.db_store import _coerce_for_write, _normalize_row, coerce_csv_value
from ankor.models import DataTable
from ankor.router import create_router


# ---------------------------------------------------------------------------
# coerce_csv_value — pure function tests (no DB needed)
# ---------------------------------------------------------------------------


class TestCoerceCsvValue:
    def test_empty_string_returns_none(self):
        for col_type in ("text", "integer", "boolean", "date", "select", "json"):
            assert coerce_csv_value("", col_type) is None

    def test_text_passthrough(self):
        assert coerce_csv_value("hello world", "text") == "hello world"
        assert coerce_csv_value("42", "text") == "42"

    def test_select_passthrough(self):
        assert coerce_csv_value("draft", "select") == "draft"

    def test_number_integer(self):
        assert coerce_csv_value("42", "integer") == 42
        assert isinstance(coerce_csv_value("42", "integer"), int)

    def test_number_float(self):
        result = coerce_csv_value("3.14", "integer")
        assert result == 3
        assert isinstance(result, int)

    def test_number_zero(self):
        assert coerce_csv_value("0", "integer") == 0

    def test_number_negative(self):
        assert coerce_csv_value("-7", "integer") == -7

    def test_number_invalid_returns_none(self):
        assert coerce_csv_value("abc", "integer") is None

    def test_float_simple(self):
        result = coerce_csv_value("123.45", "float")
        assert abs(result - 123.45) < 1e-9
        assert isinstance(result, float)

    def test_float_integer_string(self):
        result = coerce_csv_value("42", "float")
        assert abs(result - 42.0) < 1e-9

    def test_float_negative(self):
        result = coerce_csv_value("-9.99", "float")
        assert abs(result - (-9.99)) < 1e-9

    def test_float_scientific(self):
        result = coerce_csv_value("1.5e3", "float")
        assert abs(result - 1500.0) < 1e-9

    def test_float_empty_returns_none(self):
        assert coerce_csv_value("", "float") is None

    def test_float_invalid_returns_none(self):
        assert coerce_csv_value("not_a_float", "float") is None

    def test_boolean_true_variants(self):
        for val in ("true", "True", "TRUE", "1", "yes", "Yes", "on", "ON"):
            assert (
                coerce_csv_value(val, "boolean") is True
            ), f"Expected True for {val!r}"

    def test_boolean_false_variants(self):
        for val in ("false", "False", "FALSE", "0", "no", "No", "off", "OFF"):
            assert (
                coerce_csv_value(val, "boolean") is False
            ), f"Expected False for {val!r}"

    def test_boolean_unknown_returns_none(self):
        assert coerce_csv_value("maybe", "boolean") is None

    def test_date_plain(self):
        from datetime import date

        assert coerce_csv_value("2026-04-09", "date") == date(2026, 4, 9)
        assert coerce_csv_value("  2026-01-01  ", "date") == date(2026, 1, 1)

    def test_date_iso_datetime_string(self):
        from datetime import date

        # Full ISO datetime (e.g. from CRM exports) is truncated to date
        assert coerce_csv_value("2023-12-06T09:33:40.609Z", "date") == date(2023, 12, 6)
        assert coerce_csv_value("2024-01-01T00:00:00.000Z", "date") == date(2024, 1, 1)

    def test_date_invalid_returns_none(self):
        assert coerce_csv_value("not-a-date", "date") is None

    def test_date_empty_returns_none(self):
        assert coerce_csv_value("", "date") is None

    def test_json_valid(self):
        assert coerce_csv_value('{"key": 1}', "json") == '{"key": 1}'
        assert coerce_csv_value("[1, 2, 3]", "json") == "[1, 2, 3]"

    def test_json_invalid_returns_raw(self):
        assert coerce_csv_value("not json", "json") == "not json"


# ---------------------------------------------------------------------------
# _coerce_for_write — pure function tests (no DB needed)
# ---------------------------------------------------------------------------


class TestCoerceForWrite:
    def test_none_passthrough(self):
        assert _coerce_for_write(None, "text") is None
        assert _coerce_for_write(None, "date") is None
        assert _coerce_for_write(None, "json") is None

    def test_date_plain_string(self):
        assert _coerce_for_write("2026-04-09", "date") == date(2026, 4, 9)

    def test_date_iso_datetime_string(self):
        assert _coerce_for_write("2025-09-04T11:40:06.492Z", "date") == date(2025, 9, 4)

    def test_date_already_date_object(self):
        d = date(2026, 1, 1)
        assert _coerce_for_write(d, "date") == d

    def test_date_datetime_object_truncated(self):
        dt = datetime(2026, 1, 1, 12, 0, 0)
        assert _coerce_for_write(dt, "date") == date(2026, 1, 1)

    def test_date_invalid_string_returns_none(self):
        assert _coerce_for_write("not-a-date", "date") is None

    def test_json_dict_serialized_to_string(self):
        result = _coerce_for_write({"key": 1}, "json")
        assert isinstance(result, str)
        assert json.loads(result) == {"key": 1}

    def test_json_list_serialized_to_string(self):
        result = _coerce_for_write([1, 2, 3], "json")
        assert isinstance(result, str)
        assert json.loads(result) == [1, 2, 3]

    def test_json_string_passthrough(self):
        assert _coerce_for_write('{"key": 1}', "json") == '{"key": 1}'

    def test_text_passthrough(self):
        assert _coerce_for_write("hello", "text") == "hello"

    def test_number_passthrough(self):
        assert _coerce_for_write(42, "integer") == 42


# ---------------------------------------------------------------------------
# _normalize_row — pure function tests (no DB needed)
# ---------------------------------------------------------------------------


class TestNormalizeRow:
    def test_json_string_parsed_with_col_types(self):
        col_types = {"data": "json"}
        result = _normalize_row({"id": 1, "data": '{"key": "value"}'}, col_types)
        assert result["data"] == {"key": "value"}

    def test_json_invalid_string_kept_as_string(self):
        col_types = {"data": "json"}
        result = _normalize_row({"id": 1, "data": "not json"}, col_types)
        assert result["data"] == "not json"

    def test_json_string_not_parsed_without_col_types(self):
        result = _normalize_row({"id": 1, "data": '{"key": "value"}'})
        assert result["data"] == '{"key": "value"}'

    def test_json_dict_passthrough_with_col_types(self):
        col_types = {"data": "json"}
        result = _normalize_row({"id": 1, "data": {"key": "value"}}, col_types)
        assert result["data"] == {"key": "value"}

    def test_date_serialized_to_isoformat(self):
        result = _normalize_row({"id": 1, "birthday": date(2026, 4, 9)})
        assert result["birthday"] == "2026-04-09"

    def test_decimal_to_float(self):
        from decimal import Decimal

        result = _normalize_row({"id": 1, "score": Decimal("3.14")})
        assert abs(result["score"] - 3.14) < 1e-9
        assert isinstance(result["score"], float)


# ---------------------------------------------------------------------------
# HTTP endpoint helpers
# ---------------------------------------------------------------------------

_NOW = datetime(2026, 4, 9, 12, 0, 0, tzinfo=timezone.utc)


def _make_table(table_id: int = 1, name: str = "TestTable") -> DataTable:
    t = DataTable(name=name, description=None)
    t.id = table_id
    t.created_at = _NOW
    t.updated_at = _NOW
    return t


_ALL_TYPE_COLUMNS = [
    {"id": "name", "name": "name", "type": "text"},
    {"id": "score", "name": "score", "type": "integer"},
    {"id": "rating", "name": "rating", "type": "float"},
    {"id": "active", "name": "active", "type": "boolean"},
    {"id": "birthday", "name": "birthday", "type": "date"},
    {
        "id": "status",
        "name": "status",
        "type": "select",
        "selectOptions": ["draft", "published"],
    },
    {"id": "meta", "name": "meta", "type": "json"},
]


def _make_client():
    app = FastAPI()
    router = create_router({}, invoke=AsyncMock())
    app.include_router(router, prefix="/api")
    app.dependency_overrides[get_current_user] = lambda: MagicMock(username="admin")
    return app


def _build_mock_session(
    table: DataTable, columns: list[dict], rows: list[dict], max_id: int = 0
):
    session = AsyncMock()
    session.get = AsyncMock(return_value=table)
    session.scalar = AsyncMock(return_value=max_id)
    session.commit = AsyncMock()

    info_schema_rows_user_cols = MagicMock()
    info_schema_rows_user_cols.__iter__ = MagicMock(
        return_value=iter([(c["id"], "text") for c in columns])
    )

    meta_rows = MagicMock()
    meta_rows.fetchall = MagicMock(
        return_value=[
            (c["id"], c["selectOptions"]) for c in columns if c.get("type") == "select"
        ]
    )

    def _execute_side_effect(stmt, params=None):
        sql = str(stmt)
        result = MagicMock()
        if "information_schema.columns" in sql:
            result.__iter__ = MagicMock(
                return_value=iter([(c["id"], "text") for c in columns])
            )
            result.fetchall = MagicMock(
                return_value=[(c["id"], "text") for c in columns]
            )
        elif "data_table_column_meta" in sql:
            result.fetchall = MagicMock(
                return_value=[
                    (c["id"], c["selectOptions"])
                    for c in columns
                    if c.get("type") == "select"
                ]
            )
        elif sql.strip().startswith("SELECT *"):
            result.__iter__ = MagicMock(
                return_value=iter(
                    [
                        MagicMock(
                            _mapping={
                                **r,
                                "created_at": _NOW.isoformat(),
                                "updated_at": _NOW.isoformat(),
                            }
                        )
                        for r in rows
                    ]
                )
            )
        else:
            result.fetchall = MagicMock(return_value=[])
        return result

    session.execute = AsyncMock(side_effect=_execute_side_effect)
    return session


# ---------------------------------------------------------------------------
# Export CSV tests
# ---------------------------------------------------------------------------


class TestExportCsv:
    def test_export_returns_csv_content_type(self):
        app = _make_client()
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        rows = [{"id": 1, "name": "Alice"}]

        async def _session():
            yield _build_mock_session(table, columns, rows)

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        resp = client.get("/api/db-tables/1/export")
        assert resp.status_code == 200
        assert "text/csv" in resp.headers["content-type"]

    def test_export_csv_headers(self):
        app = _make_client()
        table = _make_table()
        columns = [
            {"id": "name", "name": "name", "type": "text"},
            {"id": "score", "name": "score", "type": "integer"},
        ]
        rows = []

        async def _session():
            yield _build_mock_session(table, columns, rows)

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        resp = client.get("/api/db-tables/1/export")
        reader = csv.DictReader(io.StringIO(resp.text))
        assert set(reader.fieldnames or []) == {
            "id",
            "name",
            "score",
            "created_at",
            "updated_at",
        }

    def test_export_csv_row_values(self):
        app = _make_client()
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        rows = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]

        async def _session():
            yield _build_mock_session(table, columns, rows)

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        resp = client.get("/api/db-tables/1/export")
        reader = list(csv.DictReader(io.StringIO(resp.text)))
        assert len(reader) == 2
        assert reader[0]["name"] == "Alice"
        assert reader[1]["name"] == "Bob"

    def test_export_404_for_unknown_table(self):
        app = _make_client()

        async def _session():
            session = AsyncMock()
            session.get = AsyncMock(return_value=None)
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        resp = client.get("/api/db-tables/999/export")
        assert resp.status_code == 404

    def test_export_filename_from_table_name(self):
        app = _make_client()
        table = _make_table(name="My Customers!")
        columns = [{"id": "name", "name": "name", "type": "text"}]

        async def _session():
            yield _build_mock_session(table, columns, [])

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        resp = client.get("/api/db-tables/1/export")
        assert "My_Customers_" in resp.headers["content-disposition"]


# ---------------------------------------------------------------------------
# Import CSV tests
# ---------------------------------------------------------------------------


def _csv_file(content: str, filename: str = "import.csv") -> tuple[str, tuple]:
    return ("file", (filename, content.encode(), "text/csv"))


class TestImportCsv:
    def _make_import_session(self, table, columns, existing_max_id=0):
        executed_sqls: list[str] = []
        upserted_rows: list[dict] = []

        session = AsyncMock()
        session.get = AsyncMock(return_value=table)
        session.scalar = AsyncMock(return_value=existing_max_id)
        session.commit = AsyncMock()

        def _execute_side_effect(stmt, params=None):
            sql = str(stmt)
            executed_sqls.append(sql)
            result = MagicMock()
            if "information_schema.columns" in sql:
                result.__iter__ = MagicMock(
                    return_value=iter([(c["id"], "text") for c in columns])
                )
                result.fetchall = MagicMock(
                    return_value=[(c["id"], "text") for c in columns]
                )
            elif "data_table_column_meta" in sql:
                result.fetchall = MagicMock(
                    return_value=[
                        (c["id"], c["selectOptions"])
                        for c in columns
                        if c.get("type") == "select"
                    ]
                )
            elif "INSERT" in sql or "ON CONFLICT" in sql:
                if params:
                    upserted_rows.append(dict(params))
            else:
                result.fetchall = MagicMock(return_value=[])
            return result

        session.execute = AsyncMock(side_effect=_execute_side_effect)
        return session, upserted_rows

    def test_import_returns_count(self):
        app = _make_client()
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        session, _ = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = "id,name\n1,Alice\n2,Bob\n"
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 2

    def test_import_all_data_types_coercion(self):
        """CSV import correctly coerces text, number, boolean, date, select, json."""
        app = _make_client()
        table = _make_table()
        columns = _ALL_TYPE_COLUMNS
        session, upserted = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = (
            "id,name,score,active,birthday,status,meta\n"
            '1,Alice,42,true,2000-01-15,draft,"{""key"": 1}"\n'
        )
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 1

    def test_import_boolean_false(self):
        app = _make_client()
        table = _make_table()
        columns = [{"id": "active", "name": "active", "type": "boolean"}]
        session, _ = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        for false_val in ("false", "0", "no", "off"):
            assert coerce_csv_value(false_val, "boolean") is False

    def test_import_number_float(self):
        assert coerce_csv_value("3.14", "integer") == 3
        assert coerce_csv_value("-100", "integer") == -100

    def test_import_empty_csv_returns_zero(self):
        app = _make_client()
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        session, _ = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = "id,name\n"
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 0

    def test_import_no_id_auto_assigns(self):
        """Rows without an id get auto-incremented ids."""
        app = _make_client()
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        session, upserted = self._make_import_session(table, columns, existing_max_id=5)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = "name\nAlice\nBob\n"
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 2

    def test_import_uses_column_name_as_header(self):
        """CSV headers can be column display names, not just IDs."""
        app = _make_client()
        table = _make_table()
        columns = [{"id": "first_name", "name": "First Name", "type": "text"}]
        session, _ = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = "id,First Name\n1,Alice\n"
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 1

    def test_import_404_for_unknown_table(self):
        app = _make_client()

        async def _session():
            session = AsyncMock()
            session.get = AsyncMock(return_value=None)
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = "id,name\n1,Alice\n"
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 404

    def test_import_system_columns_ignored(self):
        """Don't error or write to created_at/updated_at even if CSV contains them."""
        app = _make_client()
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        session, _ = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = "id,name,created_at,updated_at\n1,Alice,2026-01-01,2026-01-02\n"
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 1

    def test_import_utf8_bom(self):
        """CSV files with UTF-8 BOM (common from Excel) are handled correctly."""
        app = _make_client()
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        session, _ = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        bom_content = "\ufeffid,name\n1,Alice\n"
        resp = client.post(
            "/api/db-tables/1/import",
            files=[
                ("file", ("import.csv", bom_content.encode("utf-8-sig"), "text/csv"))
            ],
        )
        assert resp.status_code == 200
        assert resp.json()["imported"] == 1

    def test_import_float_column(self):
        """Float columns are coerced to Python float during CSV import."""
        app = _make_client()
        table = _make_table()
        columns = [
            {"id": "name", "name": "name", "type": "text"},
            {"id": "rating", "name": "rating", "type": "float"},
        ]
        session, upserted = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        csv_content = "id,name,rating\n1,Demo Item,4.75\n2,Another Item,0.5\n"
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 2

    def test_import_float_column_with_json_blob(self):
        """CSV with float column and RFC-4180 escaped JSON blob imports correctly."""
        app = _make_client()
        table = _make_table()
        columns = [
            {"id": "ref_id", "name": "ref_id", "type": "integer"},
            {"id": "amount", "name": "amount", "type": "float"},
            {"id": "label", "name": "label", "type": "text"},
            {"id": "payload", "name": "payload", "type": "json"},
        ]
        session, _ = self._make_import_session(table, columns)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        # JSON blob uses RFC 4180 double-quote escaping: inner " → ""
        csv_content = (
            "id,ref_id,amount,label,payload\n"
            '1,100001,123.45,Demo Entry,"{""key"":""value"",""n"":1}"\n'
        )
        resp = client.post("/api/db-tables/1/import", files=[_csv_file(csv_content)])
        assert resp.status_code == 200
        assert resp.json()["imported"] == 1


# ---------------------------------------------------------------------------
# RowFilter / _build_where tests
# ---------------------------------------------------------------------------

from datetime import date as _date  # noqa: E402
from ankor.db_store import RowFilter, _build_where  # noqa: E402


class TestBuildWhere:
    def test_empty_filters_returns_empty(self):
        sql, params = _build_where([])
        assert sql == ""
        assert params == {}

    def test_invalid_op_raises(self):
        with pytest.raises(ValueError, match="Unknown filter op"):
            _build_where([RowFilter("col", "like", "x")])

    # --- number ---

    def test_number_eq(self):
        sql, params = _build_where([RowFilter("score", "eq", 42)])
        assert '"score" = :fp0' in sql
        assert params == {"fp0": 42}

    def test_number_neq(self):
        sql, params = _build_where([RowFilter("score", "neq", 0)])
        assert '"score" != :fp0' in sql
        assert params == {"fp0": 0}

    def test_number_gt(self):
        sql, params = _build_where([RowFilter("score", "gt", 100)])
        assert '"score" > :fp0' in sql
        assert params == {"fp0": 100}

    def test_number_gte(self):
        sql, params = _build_where([RowFilter("score", "gte", 50)])
        assert '"score" >= :fp0' in sql
        assert params == {"fp0": 50}

    def test_number_lt(self):
        sql, params = _build_where([RowFilter("score", "lt", 200)])
        assert '"score" < :fp0' in sql
        assert params == {"fp0": 200}

    def test_number_lte(self):
        sql, params = _build_where([RowFilter("score", "lte", 99)])
        assert '"score" <= :fp0' in sql
        assert params == {"fp0": 99}

    # --- float ---

    def test_float_gt(self):
        sql, params = _build_where([RowFilter("rating", "gt", 3.5)])
        assert '"rating" > :fp0' in sql
        assert params == {"fp0": 3.5}

    def test_float_lte(self):
        sql, params = _build_where([RowFilter("rating", "lte", 10.0)])
        assert '"rating" <= :fp0' in sql
        assert params == {"fp0": 10.0}

    def test_float_eq(self):
        sql, params = _build_where([RowFilter("rating", "eq", 4.75)])
        assert '"rating" = :fp0' in sql
        assert params == {"fp0": 4.75}

    # --- boolean ---

    def test_boolean_eq_true(self):
        sql, params = _build_where([RowFilter("active", "eq", True)])
        assert '"active" = :fp0' in sql
        assert params == {"fp0": True}

    def test_boolean_eq_false(self):
        sql, params = _build_where([RowFilter("active", "eq", False)])
        assert '"active" = :fp0' in sql
        assert params == {"fp0": False}

    def test_boolean_neq(self):
        sql, params = _build_where([RowFilter("active", "neq", True)])
        assert '"active" != :fp0' in sql
        assert params == {"fp0": True}

    # --- text / select ---

    def test_text_eq(self):
        sql, params = _build_where([RowFilter("name", "eq", "Alice")])
        assert '"name" = :fp0' in sql
        assert params == {"fp0": "Alice"}

    def test_text_neq(self):
        sql, params = _build_where([RowFilter("status", "neq", "archived")])
        assert '"status" != :fp0' in sql
        assert params == {"fp0": "archived"}

    def test_text_contains(self):
        sql, params = _build_where([RowFilter("name", "contains", "müller")])
        assert '"name" ILIKE :fp0' in sql
        assert params == {"fp0": "%müller%"}

    def test_text_starts_with(self):
        sql, params = _build_where([RowFilter("name", "starts_with", "Max")])
        assert '"name" ILIKE :fp0' in sql
        assert params == {"fp0": "Max%"}

    def test_text_ends_with(self):
        sql, params = _build_where([RowFilter("email", "ends_with", "@example.com")])
        assert '"email" ILIKE :fp0' in sql
        assert params == {"fp0": "%@example.com"}

    # --- date ---

    def test_date_eq(self):
        sql, params = _build_where([RowFilter("birthday", "eq", _date(2000, 1, 15))])
        assert '"birthday" = :fp0' in sql
        assert params == {"fp0": _date(2000, 1, 15)}

    def test_date_neq(self):
        sql, params = _build_where([RowFilter("birthday", "neq", _date(2020, 6, 1))])
        assert '"birthday" != :fp0' in sql

    def test_date_gt(self):
        sql, params = _build_where([RowFilter("birthday", "gt", _date(2000, 1, 1))])
        assert '"birthday" > :fp0' in sql
        assert params == {"fp0": _date(2000, 1, 1)}

    def test_date_gte(self):
        sql, params = _build_where([RowFilter("created_at", "gte", _date(2024, 1, 1))])
        assert '"created_at" >= :fp0' in sql

    def test_date_lt(self):
        sql, params = _build_where([RowFilter("birthday", "lt", _date(2026, 4, 9))])
        assert '"birthday" < :fp0' in sql

    def test_date_lte(self):
        sql, params = _build_where([RowFilter("birthday", "lte", _date(2025, 12, 31))])
        assert '"birthday" <= :fp0' in sql
        assert params == {"fp0": _date(2025, 12, 31)}

    # --- multiple filters combined ---

    def test_multiple_filters_joined_with_and(self):
        sql, params = _build_where(
            [
                RowFilter("score", "gt", 50),
                RowFilter("active", "eq", True),
            ]
        )
        assert " AND " in sql
        assert '"score" > :fp0' in sql
        assert '"active" = :fp1' in sql
        assert params == {"fp0": 50, "fp1": True}

    def test_three_filters(self):
        sql, params = _build_where(
            [
                RowFilter("score", "gte", 10),
                RowFilter("score", "lte", 100),
                RowFilter("name", "contains", "test"),
            ]
        )
        assert sql.count(" AND ") == 2
        assert len(params) == 3

    # --- hyphenated column ids ---

    def test_hyphenated_column_id_quoted(self):
        sql, params = _build_where([RowFilter("col-2", "eq", "active")])
        assert '"col-2" = :fp0' in sql
        assert params == {"fp0": "active"}

    # --- WHERE prefix ---

    def test_where_clause_prefix(self):
        sql, _ = _build_where([RowFilter("x", "eq", 1)])
        assert sql.startswith(" WHERE ")


# ---------------------------------------------------------------------------
# GET /db-tables/{id}/rows — server-side pagination endpoint
# ---------------------------------------------------------------------------

import json as _json  # noqa: E402


def _build_rows_mock_session(
    table: DataTable | None, columns: list[dict], rows: list[dict], total: int
):
    """Build a mock session for the GET /db-tables/{id}/rows endpoint."""
    session = AsyncMock()
    session.get = AsyncMock(return_value=table)
    session.scalar = AsyncMock(return_value=total)

    def _execute_side_effect(stmt, params=None):
        sql = str(stmt)
        result = MagicMock()
        if "information_schema.columns" in sql:
            result.__iter__ = MagicMock(
                return_value=iter([(c["id"], "text") for c in columns])
            )
            result.fetchall = MagicMock(
                return_value=[(c["id"], "text") for c in columns]
            )
        elif "data_table_column_meta" in sql:
            result.fetchall = MagicMock(
                return_value=[
                    (c["id"], c["selectOptions"])
                    for c in columns
                    if c.get("type") == "select"
                ]
            )
        elif "ORDER BY id" in sql:
            result.__iter__ = MagicMock(
                return_value=iter(
                    [
                        MagicMock(
                            _mapping={
                                **r,
                                "created_at": _NOW.isoformat(),
                                "updated_at": _NOW.isoformat(),
                            }
                        )
                        for r in rows
                    ]
                )
            )
        else:
            result.fetchall = MagicMock(return_value=[])
        return result

    session.execute = AsyncMock(side_effect=_execute_side_effect)
    return session


class TestGetTableRows:
    def _make_app(self, table, columns, rows, total=None):
        if total is None:
            total = len(rows)
        app = _make_client()
        session = _build_rows_mock_session(table, columns, rows, total)

        async def _session():
            yield session

        app.dependency_overrides[get_session] = _session
        return TestClient(app)

    def test_returns_rows_and_total(self):
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        rows = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
        client = self._make_app(table, columns, rows, total=2)

        resp = client.get("/api/db-tables/1/rows")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 2
        assert len(data["rows"]) == 2

    def test_returns_404_for_unknown_table(self):
        app = _make_client()

        async def _session():
            session = AsyncMock()
            session.get = AsyncMock(return_value=None)
            yield session

        app.dependency_overrides[get_session] = _session
        client = TestClient(app)
        resp = client.get("/api/db-tables/999/rows")

        assert resp.status_code == 404

    def test_invalid_filter_json_returns_422(self):
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        client = self._make_app(table, columns, [], total=0)

        resp = client.get("/api/db-tables/1/rows?filter=not_valid_json")

        assert resp.status_code == 422

    def test_page_size_clamped_to_1000(self):
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        client = self._make_app(table, columns, [], total=0)

        resp = client.get("/api/db-tables/1/rows?page_size=99999")

        assert resp.status_code == 200

    def test_negative_page_clamped_to_zero(self):
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        client = self._make_app(table, columns, [], total=0)

        resp = client.get("/api/db-tables/1/rows?page=-5")

        assert resp.status_code == 200

    def test_empty_table_returns_zero_total_and_empty_rows(self):
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        client = self._make_app(table, columns, [], total=0)

        resp = client.get("/api/db-tables/1/rows")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 0
        assert data["rows"] == []

    def test_page_and_page_size_params_accepted(self):
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        rows = [{"id": 51, "name": "Charlie"}]
        client = self._make_app(table, columns, rows, total=100)

        resp = client.get("/api/db-tables/1/rows?page=1&page_size=50")

        assert resp.status_code == 200
        data = resp.json()
        assert data["total"] == 100

    def test_total_independent_of_page_rows(self):
        """total reflects the full result set size, not just the current page."""
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        page_rows = [{"id": 1, "name": "Alice"}]
        client = self._make_app(table, columns, page_rows, total=500)

        resp = client.get("/api/db-tables/1/rows?page=0&page_size=1")

        assert resp.status_code == 200
        assert resp.json()["total"] == 500

    def test_valid_filter_json_accepted(self):
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        client = self._make_app(table, columns, [], total=0)
        filter_val = _json.dumps(
            [{"field": "name", "operator": "contains", "value": "Alice"}]
        )

        resp = client.get(f"/api/db-tables/1/rows?filter={filter_val}")

        assert resp.status_code == 200

    def test_filter_logic_or_param_accepted(self):
        table = _make_table()
        columns = [
            {"id": "name", "name": "name", "type": "text"},
            {"id": "status", "name": "status", "type": "text"},
        ]
        client = self._make_app(table, columns, [], total=0)
        filter_val = _json.dumps(
            [
                {"field": "name", "operator": "contains", "value": "Alice"},
                {"field": "status", "operator": "equals", "value": "draft"},
            ]
        )

        resp = client.get(f"/api/db-tables/1/rows?filter={filter_val}&filter_logic=or")

        assert resp.status_code == 200

    def test_unknown_filter_field_is_skipped_not_errored(self):
        """Filter items referencing unknown columns are silently skipped (SQL injection safeguard)."""
        table = _make_table()
        columns = [{"id": "name", "name": "name", "type": "text"}]
        client = self._make_app(table, columns, [], total=0)
        filter_val = _json.dumps(
            [{"field": "nonexistent_col", "operator": "contains", "value": "x"}]
        )

        resp = client.get(f"/api/db-tables/1/rows?filter={filter_val}")

        assert resp.status_code == 200
