"""Unit tests for DbStore.rows() columns and order_by features.

Covers:
- _build_order_by   — pure function, no DB required
- _build_select_cols — pure function, no DB required
- DbStore.rows()    — mock-based tests verifying SQL construction and column validation
"""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from ankor import OrderBy
from ankor.db_store import (
    DbStore,
    OrderBy,
    _build_order_by,
    _build_select_cols,
)


# ---------------------------------------------------------------------------
# _build_order_by — pure function tests
# ---------------------------------------------------------------------------


class TestBuildOrderBy:
    def test_none_defaults_to_id(self):
        assert _build_order_by(None) == '"id"'

    def test_asc_direction(self):
        result = _build_order_by(OrderBy("amount", "asc"))
        assert result == '"amount" ASC'

    def test_desc_direction(self):
        result = _build_order_by(OrderBy("amount", "desc"))
        assert result == '"amount" DESC'

    def test_direction_case_insensitive_asc(self):
        result = _build_order_by(OrderBy("name", "ASC"))
        assert result == '"name" ASC'

    def test_direction_case_insensitive_desc(self):
        result = _build_order_by(OrderBy("name", "DESC"))
        assert result == '"name" DESC'

    def test_direction_mixed_case(self):
        result = _build_order_by(OrderBy("name", "Desc"))
        assert result == '"name" DESC'

    def test_default_direction_is_asc(self):
        result = _build_order_by(OrderBy("name"))
        assert result == '"name" ASC'

    def test_invalid_direction_raises(self):
        with pytest.raises(ValueError, match="Invalid order direction"):
            _build_order_by(OrderBy("name", "random"))

    def test_invalid_direction_empty_raises(self):
        with pytest.raises(ValueError, match="Invalid order direction"):
            _build_order_by(OrderBy("name", ""))

    def test_hyphenated_column_quoted(self):
        result = _build_order_by(OrderBy("col-2", "asc"))
        assert result == '"col-2" ASC'

    def test_hyphenated_column_desc(self):
        result = _build_order_by(OrderBy("col-name", "desc"))
        assert result == '"col-name" DESC'

    # --- one test per column type to confirm all work ---

    def test_text_column(self):
        result = _build_order_by(OrderBy("name", "asc"))
        assert result == '"name" ASC'

    def test_integer_column(self):
        result = _build_order_by(OrderBy("score", "desc"))
        assert result == '"score" DESC'

    def test_float_column(self):
        result = _build_order_by(OrderBy("rating", "asc"))
        assert result == '"rating" ASC'

    def test_boolean_column(self):
        result = _build_order_by(OrderBy("active", "desc"))
        assert result == '"active" DESC'

    def test_date_column(self):
        result = _build_order_by(OrderBy("created_on", "asc"))
        assert result == '"created_on" ASC'

    def test_json_column_asc(self):
        result = _build_order_by(OrderBy("metadata", "asc"))
        assert result == '"metadata" ASC'

    def test_select_column(self):
        result = _build_order_by(OrderBy("status", "desc"))
        assert result == '"status" DESC'

    def test_column_with_spaces_quoted(self):
        result = _build_order_by(OrderBy("first name", "asc"))
        assert result == '"first name" ASC'

    def test_column_with_double_quotes_escaped(self):
        result = _build_order_by(OrderBy('col"weird', "asc"))
        assert result == '"col""weird" ASC'

    def test_output_contains_no_order_by_keyword(self):
        # The function returns only the expression, not the full clause
        result = _build_order_by(OrderBy("amount", "desc"))
        assert not result.startswith("ORDER BY")

    def test_system_column_updated_at(self):
        result = _build_order_by(OrderBy("updated_at", "desc"))
        assert result == '"updated_at" DESC'

    def test_system_column_created_at(self):
        result = _build_order_by(OrderBy("created_at", "asc"))
        assert result == '"created_at" ASC'


# ---------------------------------------------------------------------------
# _build_select_cols — pure function tests
# ---------------------------------------------------------------------------


class TestBuildSelectCols:
    def test_none_returns_star(self):
        assert _build_select_cols(None) == "*"

    def test_empty_list_returns_star(self):
        assert _build_select_cols([]) == "*"

    def test_single_column_includes_id(self):
        result = _build_select_cols(["name"])
        assert result == '"id", "name"'

    def test_multiple_columns_includes_id(self):
        result = _build_select_cols(["name", "score"])
        assert result == '"id", "name", "score"'

    def test_id_in_columns_not_duplicated(self):
        result = _build_select_cols(["id", "name"])
        assert result == '"id", "name"'
        assert result.count('"id"') == 1

    def test_id_only_not_duplicated(self):
        result = _build_select_cols(["id"])
        assert result == '"id"'

    def test_hyphenated_columns_quoted(self):
        result = _build_select_cols(["col-2", "col-3"])
        assert result == '"id", "col-2", "col-3"'

    def test_single_hyphenated_column(self):
        result = _build_select_cols(["col-1"])
        assert result == '"id", "col-1"'

    def test_order_preserved(self):
        result = _build_select_cols(["zzz", "aaa"])
        assert result == '"id", "zzz", "aaa"'

    def test_three_columns(self):
        result = _build_select_cols(["amount", "status", "created_on"])
        assert result == '"id", "amount", "status", "created_on"'

    def test_column_with_spaces_quoted(self):
        result = _build_select_cols(["first name"])
        assert result == '"id", "first name"'

    def test_column_with_double_quotes_escaped(self):
        result = _build_select_cols(['col"x'])
        assert result == '"id", "col""x"'

    def test_system_column_created_at(self):
        result = _build_select_cols(["created_at"])
        assert result == '"id", "created_at"'

    def test_system_column_updated_at(self):
        result = _build_select_cols(["updated_at"])
        assert result == '"id", "updated_at"'

    def test_duplicate_non_id_column_deduplicated(self):
        result = _build_select_cols(["amount", "amount"])
        assert result == '"id", "amount"'

    def test_all_system_cols(self):
        result = _build_select_cols(["id", "created_at", "updated_at"])
        assert '"id"' in result
        assert '"created_at"' in result
        assert '"updated_at"' in result
        assert result.count('"id"') == 1


# ---------------------------------------------------------------------------
# DbStore.rows() — mock-based integration tests
# ---------------------------------------------------------------------------


def _make_sl(col_type_rows: list[tuple], data_rows: list[dict]) -> tuple:
    """Build a ``_SessionLocal`` mock for ``DbStore.rows()``.

    Returns ``(sl_mock, session_mock)`` so callers can inspect call args.

    - ``session.exec()`` returns a mock DataTable with ``id=1``
    - ``session.execute()`` is called twice:
        * first call → ``col_type_rows`` (for ``_read_col_types``)
        * second call → data row mocks (for the main SELECT)
    """
    mock_table = MagicMock()
    mock_table.id = 1

    exec_result = MagicMock()
    exec_result.first = MagicMock(return_value=mock_table)

    col_result = list(col_type_rows)

    data_result = [MagicMock(_mapping=row) for row in data_rows]

    mock_session = AsyncMock()
    mock_session.exec = AsyncMock(return_value=exec_result)
    mock_session.execute = AsyncMock(side_effect=[col_result, data_result])

    mock_cm = AsyncMock()
    mock_cm.__aenter__ = AsyncMock(return_value=mock_session)
    mock_cm.__aexit__ = AsyncMock(return_value=None)

    sl = MagicMock(return_value=mock_cm)
    return sl, mock_session


def _sql_from_session(mock_session: MagicMock) -> str:
    """Return the SQL string passed on the second execute() call (the main SELECT)."""
    call = mock_session.execute.call_args_list[1]
    return str(call.args[0])


COL_TYPES = [
    ("name", "text"),
    ("score", "int8"),
    ("active", "bool"),
    ("birthday", "date"),
]
ROW_DATA = [{"id": 1, "name": "Alice", "score": 10, "active": True, "birthday": None}]


class TestDbStoreRowsColumns:
    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_no_columns_selects_star(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable")
        sql = _sql_from_session(session)
        assert sql.startswith("SELECT *")

    async def test_columns_selects_specific_fields(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["name", "score"])
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert '"score"' in sql
        assert sql.startswith("SELECT")
        assert "* " not in sql

    async def test_columns_id_always_included(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["name"])
        sql = _sql_from_session(session)
        assert '"id"' in sql

    async def test_columns_id_not_duplicated(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["id", "name"])
        sql = _sql_from_session(session)
        select_clause = sql.split("FROM")[0]
        assert select_clause.count('"id"') == 1

    async def test_columns_unknown_raises_value_error(self):
        sl, _ = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            with pytest.raises(ValueError, match="Unknown columns"):
                await self.store.rows("MyTable", columns=["nonexistent"])

    async def test_columns_multiple_unknown_all_reported(self):
        sl, _ = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            with pytest.raises(ValueError, match="Unknown columns"):
                await self.store.rows("MyTable", columns=["ghost", "phantom"])

    async def test_columns_system_created_at_allowed(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["created_at"])
        sql = _sql_from_session(session)
        assert '"created_at"' in sql

    async def test_columns_system_updated_at_allowed(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["updated_at"])
        sql = _sql_from_session(session)
        assert '"updated_at"' in sql

    async def test_columns_hyphenated(self):
        col_types = [("col-2", "text"), ("col-3", "int8")]
        sl, session = _make_sl(col_types, [{"id": 1, "col-2": "x"}])
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["col-2"])
        sql = _sql_from_session(session)
        assert '"col-2"' in sql

    async def test_columns_order_preserved_in_sql(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", columns=["score", "name"])
        sql = _sql_from_session(session)
        score_pos = sql.index('"score"')
        name_pos = sql.index('"name"')
        assert score_pos < name_pos


class TestDbStoreRowsOrderBy:
    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_no_order_by_defaults_to_id(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable")
        sql = _sql_from_session(session)
        assert 'ORDER BY "id"' in sql

    async def test_order_by_asc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("score", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "score" ASC' in sql

    async def test_order_by_desc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("score", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "score" DESC' in sql

    async def test_order_by_text_column_asc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("name", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "name" ASC' in sql

    async def test_order_by_text_column_desc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("name", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "name" DESC' in sql

    async def test_order_by_boolean_column(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("active", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "active" ASC' in sql

    async def test_order_by_date_column(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("birthday", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "birthday" DESC' in sql

    async def test_order_by_system_column(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("created_at", "desc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "created_at" DESC' in sql

    async def test_order_by_hyphenated_column(self):
        col_types = [("col-2", "text")]
        sl, session = _make_sl(col_types, [{"id": 1, "col-2": "x"}])
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("col-2", "asc"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "col-2" ASC' in sql

    async def test_order_by_invalid_direction_raises(self):
        sl, _ = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            with pytest.raises(ValueError, match="Invalid order direction"):
                await self.store.rows("MyTable", order_by=OrderBy("score", "sideways"))

    async def test_order_by_default_direction_is_asc(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows("MyTable", order_by=OrderBy("score"))
        sql = _sql_from_session(session)
        assert 'ORDER BY "score" ASC' in sql


class TestDbStoreRowsCombined:
    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_columns_and_order_by_together(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows(
                "MyTable",
                columns=["name", "score"],
                order_by=OrderBy("score", "desc"),
            )
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert '"score"' in sql
        assert 'ORDER BY "score" DESC' in sql

    async def test_columns_and_filters_together(self):
        from ankor import RowFilter

        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows(
                "MyTable",
                filters=[RowFilter("score", "gt", 5)],
                columns=["name"],
            )
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert "WHERE" in sql
        assert '"score"' in sql

    async def test_all_three_options_together(self):
        from ankor import RowFilter

        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            await self.store.rows(
                "MyTable",
                filters=[RowFilter("active", "eq", True)],
                columns=["name", "score"],
                order_by=OrderBy("name", "asc"),
            )
        sql = _sql_from_session(session)
        assert '"id"' in sql
        assert '"name"' in sql
        assert '"score"' in sql
        assert "WHERE" in sql
        assert 'ORDER BY "name" ASC' in sql

    async def test_no_options_returns_all_rows(self):
        sl, session = _make_sl(COL_TYPES, ROW_DATA)
        with patch("ankor.database._SessionLocal", sl):
            rows = await self.store.rows("MyTable")
        assert isinstance(rows, list)
        assert len(rows) == 1

    async def test_no_session_returns_empty_list(self):
        with patch("ankor.database._SessionLocal", None):
            rows = await self.store.rows("MyTable")
        assert rows == []


# ---------------------------------------------------------------------------
# DbStore.update_row() — mock-based tests
# ---------------------------------------------------------------------------

_UPDATE_COL_TYPES = [("name", "text"), ("score", "float8")]

_OLD_ROW_MAPPING = {
    "id": 1,
    "name": "Alice",
    "score": 0.5,
    "created_at": "2026-01-01T00:00:00+00:00",
    "updated_at": "2026-01-01T00:00:00+00:00",
    "history": [],
}

_NEW_ROW_MAPPING = {
    **_OLD_ROW_MAPPING,
    "score": 0.9,
    "updated_at": "2026-04-19T00:00:00+00:00",
}


def _make_update_session(
    old_mapping: dict = _OLD_ROW_MAPPING,
    new_mapping: dict = _NEW_ROW_MAPPING,
    col_types: list[tuple] = _UPDATE_COL_TYPES,
) -> tuple:
    """Build a _SessionLocal mock suitable for update_row().

    execute() is called in order:
      0 – ALTER TABLE (returns None / ignored)
      1 – _read_col_types SELECT → col type rows
      2 – SELECT old row → old_row_raw
      3 – UPDATE … RETURNING * → updated row
    """
    mock_table = MagicMock()
    mock_table.id = 1

    exec_result = MagicMock()
    exec_result.first = MagicMock(return_value=mock_table)

    old_mock = MagicMock()
    old_mock.first = MagicMock(return_value=MagicMock(_mapping=old_mapping))

    updated_mock = MagicMock()
    updated_mock.first = MagicMock(return_value=MagicMock(_mapping=new_mapping))

    mock_session = AsyncMock()
    mock_session.exec = AsyncMock(return_value=exec_result)
    mock_session.execute = AsyncMock(
        side_effect=[
            None,  # ALTER TABLE — return value ignored
            col_types,  # _read_col_types
            old_mock,  # SELECT old row
            updated_mock,  # UPDATE RETURNING
        ]
    )
    mock_session.commit = AsyncMock()

    mock_cm = AsyncMock()
    mock_cm.__aenter__ = AsyncMock(return_value=mock_session)
    mock_cm.__aexit__ = AsyncMock(return_value=None)

    sl = MagicMock(return_value=mock_cm)
    return sl, mock_session


def _update_sql(mock_session: MagicMock) -> str:
    """Return the SQL string from the UPDATE call (4th execute call, index 3)."""
    return str(mock_session.execute.call_args_list[3].args[0])


@pytest.fixture()
def mock_broadcast(monkeypatch):
    """Patch broadcast manager so no real WebSocket is needed."""
    mock_mgr = MagicMock()
    mock_mgr.broadcast = AsyncMock()
    monkeypatch.setattr("ankor.broadcast.manager", mock_mgr)
    return mock_mgr


class TestUpdateRowWithData:
    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_returns_old_and_new(self, mock_broadcast):
        sl, _ = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            result = await self.store.update_row("MyTable", 1, {"score": 0.9})
        assert "old" in result
        assert "new" in result

    async def test_meta_contains_diff_view(self, mock_broadcast):
        sl, _ = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            result = await self.store.update_row("MyTable", 1, {"score": 0.9})
        view_keys = [v["key"] for v in result["_meta"]["views"]]
        assert "diff" in view_keys
        assert "old" in view_keys
        assert "new" in view_keys

    async def test_sql_contains_set_column(self, mock_broadcast):
        sl, session = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {"score": 0.9})
        sql = _update_sql(session)
        assert '"score"' in sql

    async def test_sql_contains_updated_at(self, mock_broadcast):
        sl, session = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {"score": 0.9})
        sql = _update_sql(session)
        assert "updated_at" in sql

    async def test_sql_contains_history_append(self, mock_broadcast):
        sl, session = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {"score": 0.9})
        sql = _update_sql(session)
        assert "history" in sql

    async def test_history_entry_has_row_update_action(self, mock_broadcast):
        sl, session = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {"score": 0.9})
        params = mock_session_update_params(session)
        import json as _json

        entry = _json.loads(params["history_entry"])[0]
        action_types = [a["type"] for a in entry["actions"]]
        assert "row_update" in action_types

    async def test_history_row_update_state_matches_old_row(self, mock_broadcast):
        sl, session = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {"score": 0.9})
        import json as _json

        params = mock_session_update_params(session)
        entry = _json.loads(params["history_entry"])[0]
        row_update = next(a for a in entry["actions"] if a["type"] == "row_update")
        assert row_update["state"]["score"] == _OLD_ROW_MAPPING["score"]

    async def test_broadcasts_row_updated(self, mock_broadcast):
        sl, _ = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {"score": 0.9})
        mock_broadcast.broadcast.assert_awaited_once()
        call_args = mock_broadcast.broadcast.call_args
        assert call_args.args[1]["type"] == "row_updated"

    async def test_unknown_column_silently_ignored(self, mock_broadcast):
        """Keys not present in col_types are silently dropped."""
        sl, session = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {"nonexistent": "x"})
        # With no valid update data and no note → early return (no UPDATE call)
        assert session.execute.call_count < 4


class TestUpdateRowNoteOnly:
    """DbStore.note() — appends a note action to a row's history."""

    store = DbStore()
    pytestmark = pytest.mark.asyncio


def _make_note_session(
    mapping: dict = _OLD_ROW_MAPPING,
    col_types: list[tuple] = _UPDATE_COL_TYPES,
) -> tuple:
    """Build a _SessionLocal mock for note() called outside a workflow run.

    execute() side-effects in order:
      0 – ALTER TABLE (ignored)
      1 – _read_col_types SELECT → col type rows
      2 – SELECT id (existence check) → row mock
      3 – UPDATE history (ignored)
      4 – SELECT * for broadcast → updated row
    """
    mock_table = MagicMock()
    mock_table.id = 1

    exec_result = MagicMock()
    exec_result.first = MagicMock(return_value=mock_table)

    id_mock = MagicMock()
    id_mock.first = MagicMock(return_value=MagicMock(id=1))  # non-None → row exists

    updated_mock = MagicMock()
    updated_mock.first = MagicMock(return_value=MagicMock(_mapping=mapping))

    mock_session = AsyncMock()
    mock_session.exec = AsyncMock(return_value=exec_result)
    mock_session.execute = AsyncMock(
        side_effect=[
            None,  # ALTER TABLE
            col_types,  # _read_col_types
            id_mock,  # SELECT id
            None,  # UPDATE (no RETURNING)
            updated_mock,  # SELECT * for broadcast
        ]
    )
    mock_session.commit = AsyncMock()
    mock_session.close = AsyncMock()

    mock_cm = AsyncMock()
    mock_cm.__aenter__ = AsyncMock(return_value=mock_session)
    mock_cm.__aexit__ = AsyncMock(return_value=None)

    sl = MagicMock(return_value=mock_cm)
    return sl, mock_session


def _note_sql(mock_session: MagicMock) -> str:
    """Return the SQL string from the UPDATE call in note() (4th execute, index 3)."""
    return str(mock_session.execute.call_args_list[3].args[0])


def _note_params(mock_session: MagicMock) -> dict:
    """Return the params dict from the UPDATE call in note() (4th execute, index 3)."""
    call = mock_session.execute.call_args_list[3]
    return call.args[1] if len(call.args) > 1 else call.kwargs.get("params", {})


@pytest.mark.asyncio
class TestNote:
    """DbStore.note() — appends a note action to a row's history."""

    store = DbStore()

    async def test_note_executes_five_times(self, mock_broadcast):
        sl, session = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "hello")
        assert session.execute.call_count == 5

    async def test_note_history_entry_has_note_action(self, mock_broadcast):
        sl, session = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "hello")
        import json as _json

        entry = _json.loads(_note_params(session)["entry"])[0]
        action_types = [a["type"] for a in entry["actions"]]
        assert "note" in action_types

    async def test_note_history_entry_has_no_row_update_action(self, mock_broadcast):
        sl, session = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "hello")
        import json as _json

        entry = _json.loads(_note_params(session)["entry"])[0]
        action_types = [a["type"] for a in entry["actions"]]
        assert "row_update" not in action_types

    async def test_note_text_preserved(self, mock_broadcast):
        sl, session = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "my note")
        import json as _json

        entry = _json.loads(_note_params(session)["entry"])[0]
        note_action = next(a for a in entry["actions"] if a["type"] == "note")
        assert note_action["data"] == "my note"

    async def test_note_sql_contains_history(self, mock_broadcast):
        sl, session = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "hello")
        assert "history" in _note_sql(session)

    async def test_note_sql_contains_updated_at(self, mock_broadcast):
        sl, session = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "hello")
        assert "updated_at" in _note_sql(session)

    async def test_note_sql_does_not_set_data_columns(self, mock_broadcast):
        sl, session = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "hello")
        assert ":v0" not in _note_sql(session)

    async def test_note_returns_none(self, mock_broadcast):
        sl, _ = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            result = await self.store.note("MyTable", 1, "hello")
        assert result is None

    async def test_note_broadcasts(self, mock_broadcast):
        sl, _ = _make_note_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.note("MyTable", 1, "hello")
        mock_broadcast.broadcast.assert_awaited_once()


class TestUpdateRowNoOp:
    """update_row with neither data nor note — early return, no DB writes."""

    store = DbStore()
    pytestmark = pytest.mark.asyncio

    async def test_no_data_no_note_returns_old_equals_new(self, mock_broadcast):
        sl, _ = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            result = await self.store.update_row("MyTable", 1, {})
        assert result["old"] == result["new"]

    async def test_no_data_no_note_no_update_executed(self, mock_broadcast):
        sl, session = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {})
        # Should stop after: ALTER TABLE + _read_col_types + SELECT old = 3 calls
        assert session.execute.call_count == 3

    async def test_no_data_no_note_does_not_broadcast(self, mock_broadcast):
        sl, _ = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            await self.store.update_row("MyTable", 1, {})
        mock_broadcast.broadcast.assert_not_awaited()

    async def test_no_data_no_note_meta_has_no_diff_view(self, mock_broadcast):
        sl, _ = _make_update_session()
        with patch("ankor.database._SessionLocal", sl):
            result = await self.store.update_row("MyTable", 1, {})
        view_keys = [v["key"] for v in result["_meta"]["views"]]
        assert "diff" not in view_keys


# Helper used by several tests above — extract UPDATE params from the session mock.
def mock_session_update_params(mock_session: MagicMock) -> dict:
    call = mock_session.execute.call_args_list[3]
    return call.args[1] if len(call.args) > 1 else call.kwargs.get("params", {})
