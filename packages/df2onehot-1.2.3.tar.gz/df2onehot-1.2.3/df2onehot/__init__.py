import logging

from df2onehot.df2onehot import (
    df2onehot,
    import_example,
    )

from df2onehot.utils import (
 	set_dtypes,
 	is_DataFrame,
    set_y,
)

__author__ = 'Erdogan Tasksen'
__email__ = 'erdogant@gmail.com'
__version__ = '1.2.3'

# Setup root logger
_logger = logging.getLogger('df2onehot')
_log_handler = logging.StreamHandler()
_fmt = '[{asctime}] [{name}] [{levelname}] {message}'
_formatter = logging.Formatter(fmt=_fmt, style='{', datefmt='%d-%m-%Y %H:%M:%S')
_log_handler.setFormatter(_formatter)
_log_handler.setLevel(logging.DEBUG)
_logger.addHandler(_log_handler)
_logger.propagate = False

# module level doc-string
__doc__ = """
df2onehot is an Python package to convert a pandas dataframe into a stuctured dataframe.
=============================================================================================

Example
-------
>>> import df2onehot
>>> df = df2onehot.import_example()
>>> out = df2onehot.df2onehot(df)

"""
