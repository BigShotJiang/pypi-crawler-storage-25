from __future__ import annotations

import json
import os
import time
from pathlib import Path
from typing import Iterator

from podflare.client import Client
from podflare.regions import resolve_region
from podflare.types import Event, ExecResult, Language  # noqa: F401 — Event re-exported via replay


# Module-level default clients, keyed by host URL (None = env-default).
# Back-to-back Sandbox() calls that target the same region reuse the same
# httpx.Client — TLS handshake + connection pool amortized across calls.
_default_clients: dict[str | None, Client] = {}

# Once we resolve a default-host Sandbox() through the edge (api.podflare.ai)
# and the server tells us which region it landed in, we remember the direct
# region URL here. Future Sandbox() calls with no explicit host jump straight
# to the region — skipping the Cloudflare Worker hop (~200 ms saved per
# create). Pinning is per-process, per-default-host; explicit host / region
# arguments are never overridden.
_auto_resolved_host: str | None = None

# Persistent region cache — survives across processes. Written after a
# successful edge → region resolve; read at Client init. Trims ~1500 ms off
# cold start on the second and subsequent process runs from the same
# machine (which is most of dev-iteration and re-invoked CI patterns).
# Lives in XDG_CACHE_HOME (Linux) or ~/.podflare/cache on macOS/Windows.
_REGION_CACHE_TTL_SECONDS = 7 * 24 * 3600  # 7 days


def _cache_file() -> Path:
    """~/.podflare/region-cache.json by default; overridable via XDG_CACHE_HOME."""
    xdg = os.environ.get("XDG_CACHE_HOME")
    base = Path(xdg) if xdg else Path.home() / ".podflare"
    return base / "region-cache.json"


def _load_cached_region() -> str | None:
    """Read the on-disk pin. Returns None if missing, unreadable, or older
    than the TTL. Failures are silent — a bad cache just means first-run
    speed, not an error."""
    try:
        raw = _cache_file().read_text()
        data = json.loads(raw)
        url = data.get("url")
        ts = float(data.get("ts", 0))
        if not url or (time.time() - ts) > _REGION_CACHE_TTL_SECONDS:
            return None
        return url
    except (OSError, ValueError):
        return None


def _save_cached_region(url: str) -> None:
    """Write the resolved region URL for the next process to pick up.
    Best-effort — if we can't write (read-only FS, HOME unset, etc.),
    the runtime pin still works within this process."""
    try:
        f = _cache_file()
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps({"url": url, "ts": time.time()}))
    except OSError:
        pass


# Load the on-disk pin at module import. If present + fresh, it's the
# default host for any Sandbox() with no explicit region/host.
_auto_resolved_host = _load_cached_region()


def _get_default_client(host: str | None = None) -> Client:
    # Resolution order when host is not explicit:
    #   1. Disk-pinned region from previous run (fastest — proven good).
    #   2. Local-detected region (timezone → haversine; pure local, no
    #      HTTP). Saves the Worker hop on cold-cold first call.
    #   3. PODFLARE_API_URL / api.podflare.ai edge — Worker decides.
    if host is None:
        if _auto_resolved_host is not None:
            host = _auto_resolved_host
        else:
            # Lazy import to avoid circular reference if regions touches
            # sandbox in the future.
            from podflare.regions import default_api_base
            host = default_api_base()
    if host not in _default_clients:
        _default_clients[host] = Client(host=host)
    return _default_clients[host]


def _record_resolved_host(resolved: str, original: str | None) -> None:
    """Cache the direct region URL the server handed back. Next call to
    ``_get_default_client(None)`` (i.e. a fresh ``Sandbox()`` with no explicit
    host) uses the region URL directly. Also persists to disk so the NEXT
    Python process starts with the pin already set — this is the cut that
    makes dev-iteration cold-start fast (runs #2+ of the same script)."""
    global _auto_resolved_host
    if original is None or original == DEFAULT_EDGE_HOST:
        # Only pin when the caller was using the edge. If they pinned a
        # region explicitly, don't second-guess them.
        clean = resolved.rstrip("/")
        _auto_resolved_host = clean
        _save_cached_region(clean)


# The public edge. Any Sandbox() with no host argument starts here; after
# first successful create, `_auto_resolved_host` takes over.
DEFAULT_EDGE_HOST = "https://api.podflare.ai"


def close_default_client(*, clear_disk_cache: bool = False) -> None:
    """Close all shared default clients. Idempotent. Safe to call at shutdown
    if you want to free open connections deterministically. Clears the
    in-memory pin so the next Sandbox() re-resolves; disk cache is
    preserved unless ``clear_disk_cache=True`` (e.g. you want to force
    re-resolution after moving machines / changing default region)."""
    global _default_clients, _auto_resolved_host
    for c in _default_clients.values():
        c.close()
    _default_clients = {}
    _auto_resolved_host = _load_cached_region() if not clear_disk_cache else None
    if clear_disk_cache:
        try:
            _cache_file().unlink(missing_ok=True)
        except OSError:
            pass


class Sandbox:
    """A Podflare sandbox."""

    def __init__(
        self,
        *,
        template: str | None = None,
        region: str | None = None,
        host: str | None = None,
        client: Client | None = None,
        traceparent: str | None = None,
        api_key: str | None = None,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        ram_mib: int | None = None,
        rootfs_gb: int | None = None,
        persistent: bool | None = None,
        egress: bool | None = None,
    ):
        """Create a new sandbox.

        Args:
            region: "us" | "eu" — pick the hostd region closest to your
                users. Overrides `host` if both are passed.
            host: Explicit hostd URL. Overrides env + default if set.
            template: Template name (e.g. "python-datasci").
            client: Pre-built Client to reuse across sandboxes. If passed,
                region/host/traceparent/api_key are ignored.
            traceparent: W3C Trace Context string to propagate.
            api_key: Explicit bearer token (otherwise PODFLARE_API_KEY).
            timeout_seconds: Total wall-clock lifetime (seconds) before the
                sandbox is auto-destroyed. Server silently caps against your
                billing tier — free: 30 min max, pro: 8 h, scale: 24 h.
                Omit for the tier default.
            idle_timeout_seconds: Seconds of no-exec before auto-destroy.
                Tier caps apply — free: 5 min, pro: 30 min, scale: 2 h.
            ram_mib: Sandbox RAM in MiB. Tier-capped — free: 1024,
                pro: 4096, scale: 16384. Non-default values trigger a
                cold boot (~1.5 s) because the warm pool is pre-booted
                at 1024 MiB and Firecracker can't resume a snapshot
                into a larger VM.
            rootfs_gb: Sandbox rootfs size in GiB. Tier-capped —
                free: 4, pro: 16, scale: 64. Values above 4 trigger
                a cold boot while we grow the per-VM reflink of
                base.ext4.
            persistent: When True, the sandbox is frozen into a
                persistent Space when its idle timeout fires (instead
                of being destroyed). Retrieve the space id from the
                ``sandbox.frozen`` webhook + resume later with
                ``Sandbox.resume(space_id)``. Paid tiers only —
                silently ignored on the free tier.
            egress: Outbound network policy. Default ``None`` (treated
                as True by the server) — sandboxes can reach the
                internet, so ``pip install``, external API calls, and
                ``git clone`` all work. Set to ``False`` to harden the
                sandbox: the tap device stays unattached from the
                egress bridge, and every outbound packet is dropped at
                the host. Use when running LLM-authored code you don't
                want reaching external services. Fork children inherit
                this flag automatically.
        """
        # Region wins over host.
        resolved_host = resolve_region(region) or host

        if client is not None:
            # Caller brought their own client — trust it.
            self._client = client
            self._owns_client = False
        elif traceparent is None and api_key is None:
            # No client-level options beyond region/host → share a default
            # client keyed on the host URL. Keeps TLS + connection pools
            # warm across repeated Sandbox(region="us") calls.
            self._client = _get_default_client(resolved_host)
            self._owns_client = False
        else:
            self._client = Client(
                host=resolved_host, traceparent=traceparent, api_key=api_key
            )
            self._owns_client = True

        info = self._client.create_sandbox_info(
            template=template,
            timeout_seconds=timeout_seconds,
            idle_timeout_seconds=idle_timeout_seconds,
            ram_mib=ram_mib,
            rootfs_gb=rootfs_gb,
            persistent=persistent,
            egress=egress,
        )
        self.id = info["id"]

        # If the hostd that served this create returned an explicit public
        # endpoint (multi-region deployment), pin all subsequent ops on
        # this sandbox to that URL — regardless of what DNS does next.
        # We also record the resolved host at module level so future
        # Sandbox() calls with no host argument skip the Cloudflare edge
        # and go straight to the direct region URL.
        endpoint = info.get("endpoint")
        if endpoint and endpoint.rstrip("/") != self._client.host.rstrip("/"):
            # Module-level pin is always safe: it only kicks in for future
            # Sandbox() calls that use the default host (no explicit host).
            # Callers with explicit api_key/traceparent still build their
            # own Client and aren't affected.
            _record_resolved_host(endpoint, resolved_host)
            # Swap THIS sandbox's client only when we were using the
            # default shared client — custom-cred clients are caller-owned
            # and we shouldn't reparent them mid-flight.
            if traceparent is None and api_key is None and client is None:
                self._client = _get_default_client(endpoint)
                self._owns_client = False

    @classmethod
    def _from_id(cls, sandbox_id: str, client: Client) -> "Sandbox":
        """Wrap an existing sandbox id (e.g., a fork child) without creating."""
        instance = cls.__new__(cls)
        instance.id = sandbox_id
        instance._client = client
        instance._owns_client = False
        return instance

    @classmethod
    def resume(
        cls,
        space_id: str,
        *,
        region: str | None = None,
        host: str | None = None,
        client: Client | None = None,
        traceparent: str | None = None,
        api_key: str | None = None,
        timeout_seconds: int | None = None,
        idle_timeout_seconds: int | None = None,
        persistent: bool | None = None,
        egress: bool | None = None,
    ) -> "Sandbox":
        """Resume a previously-frozen Space into a live Sandbox.

        A space is single-shot: resuming it consumes it server-side. To
        keep the resumed sandbox itself persistent (so it refreezes on
        idle), pass ``persistent=True`` — that creates a fresh space
        with a new id on the next idle cycle.

        IMPORTANT: the region/host you resume on must match the region
        where the space was originally frozen. Spaces are region-local
        (the snapshot files live on that hostd's disk) — resuming on a
        different region returns 404.
        """
        resolved_host = resolve_region(region) or host
        if client is not None:
            sdk_client = client
            owns = False
        elif traceparent is None and api_key is None:
            sdk_client = _get_default_client(resolved_host)
            owns = False
        else:
            sdk_client = Client(
                host=resolved_host, traceparent=traceparent, api_key=api_key
            )
            owns = True

        info = sdk_client.resume_space(
            space_id,
            timeout_seconds=timeout_seconds,
            idle_timeout_seconds=idle_timeout_seconds,
            persistent=persistent,
            egress=egress,
        )

        # Pin to the returned endpoint exactly like __init__ does, so a
        # geo-routed resume doesn't drift to a different region mid-session.
        endpoint = info.get("endpoint")
        if (
            endpoint
            and endpoint.rstrip("/") != sdk_client.host.rstrip("/")
            and traceparent is None
            and api_key is None
        ):
            sdk_client = _get_default_client(endpoint)
            owns = False

        instance = cls.__new__(cls)
        instance.id = info["id"]
        instance._client = sdk_client
        instance._owns_client = owns
        return instance

    def __enter__(self) -> "Sandbox":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def replay(self) -> list[Event]:
        """Return the recent event history for this sandbox (up to 1000
        events). Useful for audit, debugging, and nesting under OTel traces
        after the fact."""
        return self._client.replay(self.id)

    def fork(self, n: int = 1) -> list["Sandbox"]:
        """Snapshot this sandbox mid-flight and spawn N CoW children.

        Each child starts from this sandbox's current state; subsequent
        execution is isolated (copy-on-write memory + reflinked rootfs).
        Destroying a child does not affect this sandbox.
        """
        if n < 1:
            raise ValueError("fork n must be >= 1")
        child_ids = self._client.fork_sandbox(self.id, n)
        return [Sandbox._from_id(cid, client=self._client) for cid in child_ids]

    def merge_into(self, winner: "Sandbox") -> None:
        """Replace this sandbox's state with `winner`'s.

        `winner` should be a fork child of this sandbox. After merge, this
        sandbox's id continues to work and now reflects winner's VM state.
        `winner`'s original id becomes defunct — do not call any methods on
        `winner` after merge; it is silently marked closed.
        """
        if winner.id == self.id:
            raise ValueError("cannot merge a sandbox into itself")
        self._client.merge_into(self.id, winner.id)
        winner._merged_into_parent = True  # type: ignore[attr-defined]

    def upload(self, local_path: str | bytes, remote_path: str) -> None:
        """Copy a local file (or raw bytes) to `remote_path` inside the sandbox.

        Implementation: embeds the base64-encoded data in a Python snippet
        executed via run_code. Suitable for files up to a few MB; larger
        transfers should wait on a dedicated streaming endpoint.
        """
        import base64

        if isinstance(local_path, bytes):
            data = local_path
        else:
            with open(local_path, "rb") as f:
                data = f.read()
        b64 = base64.b64encode(data).decode()
        code = (
            "import base64, os\n"
            f"os.makedirs(os.path.dirname({remote_path!r}) or '.', exist_ok=True)\n"
            f"with open({remote_path!r}, 'wb') as _f:\n"
            f"    _f.write(base64.b64decode({b64!r}))\n"
        )
        r = self.run_code(code, language="python")
        if r.exit_code != 0:
            raise IOError(f"upload failed: {r.stderr}")

    def download(self, remote_path: str) -> bytes:
        """Read `remote_path` inside the sandbox and return its bytes."""
        import base64

        code = (
            "import base64, sys\n"
            f"with open({remote_path!r}, 'rb') as _f:\n"
            "    sys.stdout.write(base64.b64encode(_f.read()).decode())\n"
        )
        r = self.run_code(code, language="python")
        if r.exit_code != 0:
            raise IOError(f"download failed: {r.stderr}")
        return base64.b64decode(r.stdout.strip())

    def diff(
        self,
        other: "Sandbox",
        paths: list[str] | None = None,
    ) -> dict[str, list[str]]:
        """Compare filesystem state with another sandbox.

        Runs sha256sum of every file under `paths` (default: /root /tmp) in
        both sandboxes and returns {"added": [...], "removed": [...],
        "modified": [...]}, where "added" means files present in `other` but
        not `self`, etc. Fast: two parallel bash runs, one diff in Python.
        """
        paths = paths or ["/root", "/tmp"]
        cmd = (
            "find "
            + " ".join(paths)
            + " -type f -exec sha256sum {} + 2>/dev/null | sort"
        )
        a = self.run_code(cmd, language="bash").stdout
        b = other.run_code(cmd, language="bash").stdout

        def parse(s: str) -> dict[str, str]:
            out: dict[str, str] = {}
            for line in s.splitlines():
                line = line.strip()
                if not line:
                    continue
                # "<sha>  <path>"
                parts = line.split(maxsplit=1)
                if len(parts) == 2:
                    out[parts[1]] = parts[0]
            return out

        a_map = parse(a)
        b_map = parse(b)
        a_keys = set(a_map)
        b_keys = set(b_map)
        return {
            "added": sorted(b_keys - a_keys),
            "removed": sorted(a_keys - b_keys),
            "modified": sorted(
                p for p in a_keys & b_keys if a_map[p] != b_map[p]
            ),
        }

    def close(self) -> None:
        # Don't destroy if we were merged into a parent.
        if getattr(self, "_merged_into_parent", False):
            return
        try:
            self._client.destroy_sandbox(self.id)
        finally:
            if self._owns_client:
                self._client.close()

    def run_code_stream(self, code: str, language: Language = "python") -> Iterator[Event]:
        """Stream raw events as they arrive from the executor."""
        return self._client.exec_stream(self.id, code, language)

    def run_code(self, code: str, language: Language = "python") -> ExecResult:
        """Run code and return the accumulated result. Blocks until exit."""
        stdout_parts: list[str] = []
        stderr_parts: list[str] = []
        exit_code = -1
        for ev in self.run_code_stream(code, language):
            if ev.type == "stdout":
                stdout_parts.append(str(ev.data))
            elif ev.type == "stderr":
                stderr_parts.append(str(ev.data))
            elif ev.type == "exit":
                exit_code = int(ev.data)
        return ExecResult(
            stdout="\n".join(stdout_parts),
            stderr="\n".join(stderr_parts),
            exit_code=exit_code,
        )
