import os
import subprocess
import sys
from pathlib import Path

from rich import print

from anime_sama_api.cli.config import config
from anime_sama_api.episode import Episode
from anime_sama_api.langs import Lang


def open_silent_process(command: list[str]) -> subprocess.Popen[bytes]:
    try:
        if os.name in ("nt", "dos"):
            return subprocess.Popen(command)
        else:
            return subprocess.Popen(
                command, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL
            )

    except FileNotFoundError as e:
        print(f"[red]Error: {e}")
        sys.exit(404)


def play_episode(
    episode: Episode,
    prefer_languages: list[Lang],
    args: list[str] | None = None,
) -> subprocess.Popen[bytes] | None:
    best = episode.best(prefer_languages)
    if best is None:
        print("[red]No player available")
        return None

    player_command = list(config.internal_player_command) + [best]
    # VLC : une instance par épisode ; fermeture de la fenêtre = VLC quitte complètement (pas de tray).
    if player_command and "vlc" in player_command[0].lower():
        for opt in ("--no-one-instance", "--no-qt-system-tray"):
            if opt not in player_command:
                player_command.insert(1, opt)
    if args is not None:
        player_command += args

    # Check by the caller
    # if isinstance(self._sub_proc, sp.Popen):
    #     self.kill_player()

    return open_silent_process(player_command)

    # self._write_hist(entry)
    # self._start_dc_presence(entry)


def play_file(path: Path, args: list[str] | None = None) -> subprocess.Popen[bytes]:
    player_command = config.internal_player_command + [str(path)]
    if args is not None:
        player_command += args

    return open_silent_process(player_command)
