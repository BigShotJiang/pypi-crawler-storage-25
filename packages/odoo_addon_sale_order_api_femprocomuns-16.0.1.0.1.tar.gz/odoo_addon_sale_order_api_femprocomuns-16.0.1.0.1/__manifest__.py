# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).
{
    "name": "Expose Sale Order API of Femprocomuns",
    "version": "16.0.1.0.1",
    "depends": ["api_common_base", "product_contract_related_products", "queue_job"],
    "author": "Coopdevs Treball SCCL",
    "category": "",
    "website": "https://git.coopdevs.org/coopdevs/odoo/odoo-addons/odoo-femprocomuns",
    "license": "AGPL-3",
    "summary": """
        Expose Sale Order API of Femprocomuns
    """,
    "data": [
        "views/sale_order.xml",
        "views/res_company.xml",
    ],
    "installable": True,
}
