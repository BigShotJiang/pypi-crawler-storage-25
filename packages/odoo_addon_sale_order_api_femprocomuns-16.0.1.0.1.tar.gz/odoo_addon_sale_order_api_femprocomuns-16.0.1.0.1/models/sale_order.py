# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).
from odoo import _, fields, models
from odoo.exceptions import MissingError


class SaleOrder(models.Model):
    _inherit = "sale.order"

    collective_id = fields.Char(string="Collective ID", required=True)
    requesting_keycloak_partner_id = fields.Char(string="Requesting Keycloak User ID")

    def create_so_from_api(self, params):
        try:
            order_params = self._prepare_create(params)
            order = self.env["sale.order"].sudo().create(order_params)
            order_params = self._prepare_create_order_lines(order, params)
        except Exception as e:
            raise SaleOrderCreateException(params) from e

    def _prepare_create(self, params):
        return {
            "partner_id": params["partner_id"],
            "collective_id": params["collective_id"],
            "requesting_keycloak_partner_id": params["user_id"],
            "team_id": self.env.company.sale_order_team_id.id,
            "operating_unit_id": self.env.company.sale_order_team_id.operating_unit_id.id,
            "payment_mode_id": self.env.company.sale_order_payment_mode_id.id,
        }

    def _prepare_create_order_lines(self, order, params):
        order_lines = []
        for order_line in params["lines"]:
            product = self._search_product(order_line["product_code"])
            main_order_line = self._create_order_line(order.id, product.id)
            order_lines.append(main_order_line)
            if "related_products" in order_line:
                for related_product in order_line["related_products"]:
                    related_product = self._search_product(
                        related_product["product_code"]
                    )
                    related_line = self._create_order_line(order.id, related_product.id)
                    related_line.related_line_id = main_order_line
                    order_lines.append(main_order_line.related_line_id)

        return {"partner_id": params["partner_id"], "order_line": order_lines}

    def _search_product(self, product_code):
        product = self.env["product.product"].search(
            [("default_code", "=", product_code)]
        )
        if not product:
            raise MissingError(_("Product with code %s not found") % product_code)
        return product

    def _create_order_line(self, order_id, product_id):
        return (
            self.env["sale.order.line"]
            .sudo()
            .create(
                {
                    "order_id": order_id,
                    "product_id": product_id,
                    "is_contract": True,
                }
            )
        )


class SaleOrderCreateException(Exception):
    def __init__(self, params):
        self.message = (
            f"Partner ID: {params['partner_id']}"
            f"Collective ID {params['collective_id']}"
            f"User ID {params['user_id']}"
            f"Lines: {params['lines']}"
        )
