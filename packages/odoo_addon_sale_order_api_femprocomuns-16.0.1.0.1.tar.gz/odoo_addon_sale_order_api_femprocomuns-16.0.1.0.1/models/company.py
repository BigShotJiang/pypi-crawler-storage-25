from odoo import fields, models


class ResCompany(models.Model):
    _inherit = "res.company"

    sale_order_team_id = fields.Many2one(
        comodel_name="crm.team",
        string="Team for Sale Orders",
    )
    sale_order_payment_mode_id = fields.Many2one(
        comodel_name="account.payment.mode",
        string="Payment Mode for Sale Orders",
    )
