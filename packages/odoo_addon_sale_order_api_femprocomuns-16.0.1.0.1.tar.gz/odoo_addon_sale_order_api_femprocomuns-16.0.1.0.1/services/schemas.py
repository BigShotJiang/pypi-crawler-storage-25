S_ORDER_CREATE = {
    "partner_id": {
        "type": "integer",
        "required": True,
    },
    "collective_id": {
        "type": "string",
        "required": True,
    },
    "user_id": {
        "type": "string",
        "required": True,
    },
    "lines": {
        "type": "list",
        "required": True,
        "schema": {
            "type": "dict",
            "schema": {
                "product_code": {"type": "string", "required": True},
                "related_products": {
                    "type": "list",
                    "schema": {
                        "type": "dict",
                        "schema": {
                            "product_code": {"type": "string", "required": True},
                        },
                    },
                },
            },
        },
    },
}

S_ORDER_RETURN_CREATE = {
    "id": {
        "type": "integer",
        "required": True,
    },
    "partner_id": {
        "type": "integer",
        "required": True,
    },
}
