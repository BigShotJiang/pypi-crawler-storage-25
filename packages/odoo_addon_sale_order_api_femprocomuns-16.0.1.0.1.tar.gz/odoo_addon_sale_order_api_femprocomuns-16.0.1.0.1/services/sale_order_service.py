from odoo.addons.base_rest import restapi
from odoo.addons.component.core import Component

from . import schemas

PRODUCT_CATEGORY = "CommondsCloud"
IGNORE_CATEGORIES = ["Extras"]


class SaleOrderService(Component):
    _name = "sale.order.rest.service"
    _inherit = "base.rest.service"
    _usage = "order"
    _collection = "api_common_base.services"
    _description = """ Sale Order API for FemProcomuns """

    # pylint: disable=W8106
    @restapi.method(
        [(["/"], "POST")],
        input_param=restapi.CerberusValidator("_validator_create"),
        auth="api_key",
    )
    def create(self, **params):
        self.env["sale.order"].sudo().with_delay().create_so_from_api(params)
        return {"status": "OK"}

    def _validator_create(self):
        return schemas.S_ORDER_CREATE
