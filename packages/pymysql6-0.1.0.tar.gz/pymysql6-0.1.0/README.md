# pymysql6

Bundles a small PyQt6 application template and dumps it into the current
directory on demand.

## Install

```bash
pip install pymysql6
```

## Usage

Dump the bundled template into the current directory:

```bash
pymysql6-dump
```

Or into a specific folder, overwriting existing files:

```bash
pymysql6-dump ./my-project -f
```

Equivalent invocations:

```bash
python -m pymysql6
python -c "import pymysql6; pymysql6.dump('.')"
```

After dumping you'll get a ready-to-run layout:

```
auth/        database/    dialogs/     ui/      users/
main.py      resources/images/   (place your own .jpg files here)
```

Run with:

```bash
pip install PyQt6
python main.py
```

## Build & publish

```bash
pip install build twine
python -m build
twine upload dist/*
```
