"""Dump the bundled exam template into a target directory."""
from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

PAYLOAD_DIR = Path(__file__).resolve().parent / "_payload"


def dump(target: str | Path = ".", *, overwrite: bool = False) -> Path:
    """Copy bundled template files into ``target``.

    Returns the resolved target path.
    """
    target_path = Path(target).resolve()
    target_path.mkdir(parents=True, exist_ok=True)

    if not PAYLOAD_DIR.is_dir():
        raise RuntimeError(f"payload not found at {PAYLOAD_DIR}")

    copied = 0
    for src in PAYLOAD_DIR.rglob("*"):
        rel = src.relative_to(PAYLOAD_DIR)
        # Files in the payload are stored as `<name>.py.tpl` so that pip does
        # not try to byte-compile them on install. Restore the original `.py`
        # name when dumping.
        if rel.suffix == ".tpl" and rel.suffixes[-2:] == [".py", ".tpl"]:
            rel = rel.with_suffix("")
        dst = target_path / rel
        if src.is_dir():
            dst.mkdir(parents=True, exist_ok=True)
            continue
        if dst.exists() and not overwrite:
            print(f"skip (exists): {rel}", file=sys.stderr)
            continue
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        copied += 1

    print(f"dumped {copied} file(s) to {target_path}")
    return target_path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="pymysql6-dump",
        description="Dump the bundled pm02 exam template into a directory.",
    )
    parser.add_argument(
        "target",
        nargs="?",
        default=".",
        help="target directory (default: current directory)",
    )
    parser.add_argument(
        "-f",
        "--force",
        action="store_true",
        help="overwrite existing files",
    )
    args = parser.parse_args(argv)
    try:
        dump(args.target, overwrite=args.force)
    except Exception as exc:  # pragma: no cover
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
