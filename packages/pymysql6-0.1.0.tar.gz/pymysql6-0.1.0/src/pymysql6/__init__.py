"""pymysql6 — exam template payload."""
from .cli import dump

__all__ = ["dump"]
__version__ = "0.1.0"
