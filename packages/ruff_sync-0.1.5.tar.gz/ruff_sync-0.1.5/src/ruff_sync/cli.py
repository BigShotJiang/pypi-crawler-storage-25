"""Synchronize Ruff linter configuration across Python projects.

This module provides a CLI tool and library for downloading, parsing, and merging
Ruff configuration from upstream sources (like GitHub/GitLab) into local projects.
"""

from __future__ import annotations

import asyncio
import logging
import os
import pathlib
import sys
from argparse import ArgumentParser, BooleanOptionalAction, RawDescriptionHelpFormatter
from functools import lru_cache
from importlib import metadata
from typing import (
    TYPE_CHECKING,
    ClassVar,
    Final,
    Literal,
    NamedTuple,
    Protocol,
)

import tomlkit
from httpx import URL
from typing_extensions import deprecated, override

from ruff_sync.constants import (
    DEFAULT_BRANCH,
    DEFAULT_EXCLUDE,
    DEFAULT_PATH,
    ConfKey,
    OutputFormat,
)
from ruff_sync.core import (
    Config,
    RuffConfigFileName,
    UpstreamError,
    check,
    pull,
    resolve_raw_url,
)
from ruff_sync.dependencies import DependencyError

if TYPE_CHECKING:
    from collections.abc import Iterable, Mapping

__all__: Final[list[str]] = [
    "Arguments",
    "ColoredFormatter",
    "OutputFormat",
    "get_config",
    "main",
]

try:
    __version__ = metadata.version("ruff-sync")
except metadata.PackageNotFoundError:
    __version__ = "0.0.0-dev"


CIProvider = Literal[OutputFormat.GITHUB, OutputFormat.GITLAB]


LOGGER = logging.getLogger(__name__)


class ColoredFormatter(logging.Formatter):
    """Logging Formatter to add colors."""

    RESET: ClassVar[str] = "\x1b[0m"
    COLORS: ClassVar[Mapping[int, str]] = {
        logging.DEBUG: "\x1b[36m",  # Cyan
        logging.INFO: "\x1b[32m",  # Green
        logging.WARNING: "\x1b[33m",  # Yellow
        logging.ERROR: "\x1b[31m",  # Red
        logging.CRITICAL: "\x1b[1;31m",  # Bold Red
    }

    def __init__(self, fmt: str = "%(message)s") -> None:
        """Initialize the formatter with a format string."""
        super().__init__(fmt)

    @override
    def format(self, record: logging.LogRecord) -> str:
        """Format the log record with colors if the output is a TTY."""
        if sys.stderr.isatty():
            color = self.COLORS.get(record.levelno, self.RESET)
            return f"{color}{super().format(record)}{self.RESET}"
        return super().format(record)


class Arguments(NamedTuple):
    """CLI arguments for the ruff-sync tool."""

    command: str
    upstream: tuple[URL, ...]
    to: pathlib.Path
    exclude: Iterable[str]
    verbose: int
    branch: str = DEFAULT_BRANCH
    path: str | None = None
    semantic: bool = False
    diff: bool = True
    init: bool = False
    pre_commit: bool = False
    save: bool | None = None
    output_format: OutputFormat = OutputFormat.TEXT

    @property
    @deprecated("Use 'to' instead")
    def source(self) -> pathlib.Path:
        """Deprecated: use 'to' instead."""
        return self.to

    @classmethod
    @lru_cache(maxsize=1)
    def fields(cls) -> set[str]:
        """Return the set of all field names, including deprecated ones."""
        return set(cls._fields) | {"source"}


class ResolvedArgs(NamedTuple):
    """Internal container for resolved arguments."""

    upstream: tuple[URL, ...]
    to: pathlib.Path
    exclude: Iterable[str]
    branch: str
    path: str | None
    output_format: OutputFormat


class CLIArguments(Protocol):
    """Protocol for parsed CLI arguments from ArgumentParser."""

    command: str | None
    upstream: list[URL]
    to: str | None
    source: str | None
    exclude: list[str] | None
    verbose: int
    branch: str | None
    path: str | None
    pre_commit: bool | None
    output_format: OutputFormat | None
    # Subcommand specific
    init: bool
    save: bool | None
    semantic: bool
    diff: bool


@lru_cache(maxsize=1)
def get_config(
    source: pathlib.Path,
) -> Config:
    """Read [tool.ruff-sync] configuration from pyproject.toml.

    Examples:
        >>> import pathlib
        >>> config = get_config(pathlib.Path("."))
        >>> if "upstream" in config:
        ...     print(f"Syncing from {config['upstream']}")
    """
    local_toml = source / RuffConfigFileName.PYPROJECT_TOML
    # TODO: use pydantic to validate the toml file
    cfg_result: Config = {}
    if local_toml.exists():
        toml = tomlkit.parse(local_toml.read_text())
        config = toml.get("tool", {}).get("ruff-sync")
        if config:
            allowed_keys = set(Config.__annotations__.keys())
            for raw_key, value in config.items():
                # Check for legacy 'source' key to emit deprecation warning
                if raw_key.replace("-", "_") == ConfKey.to_attr(ConfKey.SOURCE):
                    LOGGER.warning(
                        f"DeprecationWarning: [tool.ruff-sync] '{raw_key}' "
                        f"is deprecated. Use '{ConfKey.TO}' instead."
                    )

                # Map legacy names (source, pre_commit_sync) to canonical
                # (to, pre-commit-version-sync)
                canonical_key = ConfKey.get_canonical(raw_key)

                # Normalize TOML key (dashes) to internal Python attribute name (underscores)
                # e.g. "pre-commit-version-sync" -> "pre_commit_version_sync"
                arg_attr = ConfKey.to_attr(canonical_key)

                if arg_attr in allowed_keys:
                    cfg_result[arg_attr] = value  # type: ignore[literal-required]
                else:
                    LOGGER.warning(f"Unknown ruff-sync configuration: {raw_key}")

            # Ensure 'to' is populated if 'source' was used
            to_attr = ConfKey.to_attr(ConfKey.TO)
            source_attr = ConfKey.to_attr(ConfKey.SOURCE)
            if source_attr in cfg_result and to_attr not in cfg_result:
                cfg_result[to_attr] = cfg_result[source_attr]  # type: ignore[literal-required]
    return cfg_result


def _get_cli_parser() -> ArgumentParser:
    parser = ArgumentParser(
        prog="ruff-sync",
        description=(
            "Synchronize Ruff linter configuration across Python projects.\n\n"
            f"Downloads a {RuffConfigFileName.PYPROJECT_TOML} from an upstream URL, "
            "extracts the\n"
            "[tool.ruff] section, and merges it into the local "
            f"{RuffConfigFileName.PYPROJECT_TOML}\n"
            "while preserving formatting, comments, and whitespace.\n\n"
            "Defaults to the 'pull' subcommand when none is specified."
        ),
        epilog=(
            "Examples:\n"
            f"  ruff-sync pull https://github.com/org/repo/blob/main/"
            f"{RuffConfigFileName.PYPROJECT_TOML}\n"
            f"  ruff-sync check https://github.com/org/repo/blob/main/"
            f"{RuffConfigFileName.PYPROJECT_TOML}\n"
            "  ruff-sync pull git@github.com:org/repo.git\n"
            "  ruff-sync pull ssh://git@gitlab.com/org/repo.git\n"
            "  ruff-sync check --semantic  # ignore formatting-only differences\n\n"
            f"The upstream URL can also be set in [tool.ruff-sync] in "
            f"{RuffConfigFileName.PYPROJECT_TOML}\n"
            "so you can simply run: ruff-sync pull"
        ),
        formatter_class=RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    subparsers = parser.add_subparsers(dest="command", help="Subcommand to run (default: pull)")

    # Common arguments
    common_parser = ArgumentParser(add_help=False)
    common_parser.add_argument(
        "upstream",
        type=URL,
        nargs="*",
        help=f"One or more URLs to download the {RuffConfigFileName.PYPROJECT_TOML} file from."
        " Optional if defined in [tool.ruff-sync]. Upstreams are merged sequentially.",
    )
    common_parser.add_argument(
        "--to",
        help="The directory or file to sync ruff configuration to. Default: .",
        required=False,
    )
    # Add --source as a deprecated alias
    common_parser.add_argument(
        "--source",
        help="Deprecated alias for --to.",
        required=False,
        metavar="PATH",
    )
    common_parser.add_argument(
        "--exclude",
        nargs="+",
        help=f"Exclude certain ruff configs. Default: {' '.join(DEFAULT_EXCLUDE)}",
        default=None,
    )
    common_parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase verbosity. -v for INFO, -vv for DEBUG.",
    )
    common_parser.add_argument(
        "--branch",
        help=f"The default branch to use when resolving repo URLs. Default: {DEFAULT_BRANCH}",
        default=None,
    )
    common_parser.add_argument(
        "--path",
        help=f"The parent path where {RuffConfigFileName.PYPROJECT_TOML} is located."
        f" Default: {DEFAULT_PATH or 'root'}",
        default=None,
    )
    common_parser.add_argument(
        "--pre-commit",
        action=BooleanOptionalAction,
        default=None,
        help="Sync the pre-commit Ruff hook version with the project's Ruff version.",
    )
    common_parser.add_argument(
        "--output-format",
        type=OutputFormat,
        choices=list(OutputFormat),
        default=None,
        help="Format for output. Default: text (auto-detected in CI).",
    )

    # Pull subcommand (the default action)
    pull_parser = subparsers.add_parser(
        "pull",
        parents=[common_parser],
        help="Pull and apply upstream ruff configuration",
    )
    pull_parser.add_argument(
        "--init",
        action="store_true",
        help="Create a new configuration file if it does not exist in the target directory.",
    )
    pull_parser.add_argument(
        "--save",
        action=BooleanOptionalAction,
        default=None,
        help="Save CLI arguments to [tool.ruff-sync] in pyproject.toml.",
    )

    # Check subcommand
    check_parser = subparsers.add_parser(
        "check", parents=[common_parser], help="Check if ruff configuration is in sync"
    )
    check_parser.add_argument(
        "--semantic",
        action="store_true",
        help="Ignore non-functional differences like whitespace and comments.",
    )
    check_parser.add_argument(
        "--diff",
        action="store_true",
        default=True,
        help="Show a diff of what would change. Default: True.",
    )
    check_parser.add_argument(
        "--no-diff",
        action="store_false",
        dest="diff",
        help="Do not show a diff.",
    )

    # Inspect subcommand
    subparsers.add_parser(
        "inspect",
        parents=[common_parser],
        help="Open a Terminal UI to explore and interrogate your local ruff configuration.",
    )

    return parser


PARSER: Final[ArgumentParser] = _get_cli_parser()


def _resolve_upstream(args: CLIArguments, config: Config) -> tuple[URL, ...]:
    """Resolve upstream URL(s) from CLI or config."""
    if args.upstream:
        upstreams = tuple(args.upstream)
        # Log CLI upstreams for consistency with config sourcing
        summary = (
            f"{upstreams[0]}... ({len(upstreams)} total)"
            if len(upstreams) > 1
            else str(upstreams[0])
        )
        LOGGER.info(f"📂 Using upstream(s) from CLI: {summary}")
        return upstreams
    if "upstream" in config:
        config_upstream = config["upstream"]
        if isinstance(config_upstream, str):
            upstream = (URL(config_upstream),)
            LOGGER.info(f"📂 Using upstream from [tool.ruff-sync]: {upstream[0]}")
            return upstream
        if isinstance(config_upstream, list):
            if not config_upstream:
                PARSER.error("❌ [tool.ruff-sync].upstream list cannot be empty.")
            if not all(isinstance(u, str) for u in config_upstream):
                PARSER.error(
                    "❌ all items in [tool.ruff-sync].upstream must be strings, "
                    f"got {[type(u).__name__ for u in config_upstream]}"
                )
            upstreams = tuple(URL(u) for u in config_upstream)
            LOGGER.info(f"📂 Using {len(upstreams)} upstreams from [tool.ruff-sync]")
            return upstreams

        PARSER.error(
            "❌ upstream in [tool.ruff-sync] must be a string or a list of strings, "
            f"got {type(config_upstream).__name__}"
        )

    if args.command == "inspect":
        return ()

    PARSER.error(
        "❌ the following arguments are required: upstream "
        f"(or define it in [tool.ruff-sync] in {RuffConfigFileName.PYPROJECT_TOML}) 💥"
    )


def _resolve_exclude(args: CLIArguments, config: Config) -> Iterable[str]:
    """Resolve exclude patterns from CLI or config.

    Returns the CLI value if provided, otherwise the value from
    ``[tool.ruff-sync].exclude`` in the config.  If neither is set,
    returns ``DEFAULT_EXCLUDE``.
    """
    if args.exclude is not None:
        return args.exclude
    if "exclude" in config:
        exclude: Iterable[str] = config["exclude"]
        LOGGER.info(f"🚫 Using exclude from [tool.ruff-sync]: {list(exclude)}")
        return exclude
    return DEFAULT_EXCLUDE


def _resolve_branch(args: CLIArguments, config: Config) -> str:
    """Resolve branch name from CLI, config, or MISSING.

    An empty string (``--branch ""``) is treated as falsy and falls back to
    the config or default, preserving the original behaviour.
    """
    if args.branch:
        return args.branch
    if "branch" in config:
        branch: str = config["branch"]
        LOGGER.info(f"🌿 Using branch from [tool.ruff-sync]: {branch}")
        return branch
    return DEFAULT_BRANCH


def _resolve_path(args: CLIArguments, config: Config) -> str:
    """Resolve path prefix from CLI, config, or MISSING.

    An empty string (``--path ""``) is treated as falsy and falls back to
    the config or default, preserving the original behaviour.
    """
    if args.path:
        return args.path
    if "path" in config:
        path: str = config["path"]
        LOGGER.info(f"📄 Using path from [tool.ruff-sync]: {path}")
        return path
    return DEFAULT_PATH


def _resolve_output_format(args: CLIArguments, config: Config) -> OutputFormat:
    """Resolve output format from CLI, config, or environment auto-detection."""
    if args.output_format:
        return args.output_format

    if "output_format" in config:
        fmt_str = config["output_format"]
        try:
            fmt = OutputFormat(fmt_str)
        except ValueError:
            valid_formats = ", ".join(f.value for f in OutputFormat)
            LOGGER.warning(
                f"Unknown output format in config: {fmt_str}. Valid values: {valid_formats}"
            )
        else:
            LOGGER.info(f"📊 Using output format from [tool.ruff-sync]: {fmt}")
            return fmt

    # Auto-detection
    provider = _detect_ci_provider()
    if provider:
        LOGGER.info(f"🤖 Auto-detected CI environment: {provider}")
        return provider

    return OutputFormat.TEXT


def _resolve_to(args: CLIArguments, config: Config, initial_to: pathlib.Path) -> pathlib.Path:
    """Resolve target path from CLI, config, or default."""
    if args.source:
        LOGGER.warning("DeprecationWarning: --source is deprecated. Use --to instead.")
        return pathlib.Path(args.source)
    if args.to:
        return pathlib.Path(args.to)
    if "to" in config:
        target = pathlib.Path(config["to"])
        # Resolve relative to the directory where we found the config file
        base_dir = initial_to.parent if initial_to.is_file() else initial_to
        resolved = base_dir / target
        LOGGER.info(f"🎯 Using target path from [tool.ruff-sync]: {resolved}")
        return resolved
    return initial_to


def _resolve_args(args: CLIArguments, config: Config, initial_to: pathlib.Path) -> ResolvedArgs:
    """Resolve upstream, to, exclude, branch, and path from CLI and config."""
    upstream = _resolve_upstream(args, config)
    to = _resolve_to(args, config, initial_to)
    exclude = _resolve_exclude(args, config)
    branch = _resolve_branch(args, config)
    path = _resolve_path(args, config)
    output_format = _resolve_output_format(args, config)

    # Normalize path "" -> None to match core expectation
    final_path: str | None = path or None

    return ResolvedArgs(
        upstream,
        to,
        exclude,
        branch,
        final_path,
        output_format,
    )


def _resolve_pre_commit(args: CLIArguments, config: Config) -> bool:
    """Resolve pre-commit sync setting from CLI or config."""
    if args.pre_commit is not None:
        return args.pre_commit

    pre_commit_attr = ConfKey.to_attr(ConfKey.PRE_COMMIT_VERSION_SYNC)
    if pre_commit_attr in config:
        val = config.get(pre_commit_attr)
        return bool(val)
    return False


def _detect_ci_provider() -> CIProvider | None:
    """Return the current CI provider, or None if not in a CI environment."""
    if os.environ.get("GITHUB_ACTIONS") == "true":
        return OutputFormat.GITHUB
    if os.environ.get("GITLAB_CI") == "true":
        return OutputFormat.GITLAB
    return None


def _validate_ci_output_format(args: Arguments) -> None:
    """Log a warning if the specified output format does not match the CI environment."""
    provider = _detect_ci_provider()
    if provider is OutputFormat.GITHUB and args.output_format == OutputFormat.GITLAB:
        LOGGER.warning(
            "⚠️ GitLab output format detected in GitHub Actions environment. "
            "Did you mean '--output-format github'?"
        )
    elif provider is OutputFormat.GITLAB and args.output_format == OutputFormat.GITHUB:
        LOGGER.warning(
            "⚠️ GitHub output format detected in GitLab CI environment. "
            "Did you mean '--output-format gitlab'?"
        )


def main() -> int:
    """Run the ruff-sync CLI."""
    # Handle backward compatibility: default to 'pull' if no command provided
    if len(sys.argv) > 1 and sys.argv[1] not in (
        "pull",
        "check",
        "inspect",
        "-h",
        "--help",
        "--version",
    ):
        sys.argv.insert(1, "pull")
    elif len(sys.argv) == 1:
        sys.argv.append("pull")

    args = PARSER.parse_args()

    # Configure logging
    log_level = {
        0: logging.WARNING,
        1: logging.INFO,
    }.get(args.verbose, logging.DEBUG)

    # Configure logging for the entire ruff_sync package
    root_logger = logging.getLogger("ruff_sync")
    root_logger.setLevel(log_level)

    # Avoid adding multiple handlers if main() is called multiple times (e.g. in tests)
    if not root_logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(ColoredFormatter())
        root_logger.addHandler(handler)

    root_logger.propagate = "PYTEST_CURRENT_TEST" in os.environ

    # Determine target 'to' from CLI or use default '.'
    # Defer Path conversion to avoid pyfakefs issues with captured Path class
    arg_to = args.to or args.source
    initial_to = pathlib.Path(arg_to) if arg_to else pathlib.Path()
    config: Config = get_config(initial_to)

    upstream, to_val, exclude, branch, path, output_format = _resolve_args(args, config, initial_to)
    pre_commit_val = _resolve_pre_commit(args, config)

    resolved_upstream = tuple(resolve_raw_url(u, branch=branch, path=path) for u in upstream)

    exec_args = Arguments(
        command=args.command,
        upstream=resolved_upstream,
        to=to_val,
        exclude=exclude,
        verbose=args.verbose,
        branch=branch,
        path=path,
        semantic=getattr(args, "semantic", False),
        diff=getattr(args, "diff", True),
        init=getattr(args, "init", False),
        pre_commit=pre_commit_val,
        save=getattr(args, "save", None),
        output_format=output_format,
    )

    # Warn if the specified output format doesn't match the current CI environment
    _validate_ci_output_format(exec_args)

    try:
        if exec_args.command == "inspect":
            from ruff_sync.tui import get_tui_app  # noqa: PLC0415

            app_class = get_tui_app()
            return app_class(exec_args).run() or 0

        if exec_args.command == "check":
            return asyncio.run(check(exec_args))
        return asyncio.run(pull(exec_args))
    except DependencyError as e:
        LOGGER.error(f"❌ {e}")  # noqa: TRY400
        return 1
    except UpstreamError as e:
        for url, err in e.errors:
            LOGGER.error(f"❌ Failed to fetch {url}: {err}")  # noqa: TRY400
        return 4


def inspect() -> int:
    """Entry point for the ruff-inspect console script."""
    # Handle optional subcommands/args if user passed any to ruff-inspect
    # but primarily ensure "inspect" is the command.
    if len(sys.argv) > 1 and sys.argv[1] not in ("-h", "--help", "--version"):
        # If they passed args but no command, insert 'inspect'
        if sys.argv[1] not in ("pull", "check", "inspect"):
            sys.argv.insert(1, "inspect")
    else:
        # Default to 'inspect' if no args or just flags
        sys.argv.insert(1, "inspect")

    return main()


if __name__ == "__main__":
    sys.exit(main())
