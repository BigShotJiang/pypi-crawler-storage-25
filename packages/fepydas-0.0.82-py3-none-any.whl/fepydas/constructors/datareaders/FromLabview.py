import numpy
import os
from io import StringIO
from fepydas.datatypes.Dataset import Spectrum, PLE, SpectrumSeries, SparseSpectrumMap, Map
from fepydas.constructors.datareaders.Generic import ASCII
from fepydas.datatypes.Data import Data1D, Data2D, Data3D, DataType
import fepydas.datatypes as datatypes
import sympy.physics.units as u

def Automatic(filename):
    """
    Automatically reads data from a specified file and processes the headers.

    Args:
        filename (str): The path to the file to be read.

    Returns:
        None
    """
    file = open(filename, encoding="Latin-1")
    done = False
    headers = {}
    while not done:
        line = file.readline().strip().split(" = ")
        # print(line)
        if line[0] == "HEADER":
            done = True
        else:
            headers[line[0]] = line[1:]
    # Header Done
    if "Header Version" in headers.keys() and int(headers["Header Version"][0]) == 2:
        # New Header
        # These use the old header currently
        is_ple_response = False
        is_histogram = False
        is_reference = False
        is_map = False
        is_ple = False
        if "Series Mode" in headers.keys():
            is_spectrum = True
            is_map = (headers["Series Mode"][0] == "Mapscan Cube" or headers["Series Mode"][0] == "Mapscan XY")
            is_ple = headers["Series Mode"][0] == "PLE"
            is_series = True
            series_mode = headers["Series Mode"][0]
        else:
            if "Reference Mode" in headers.keys():
                reference_mode = headers["Reference Mode"][0]
                if reference_mode == "None":
                    is_reference = False
                else:
                    is_reference = True
            elif "Measurement Mode" in headers.keys():
                print("Measurement Mode: "+headers["Measurement Mode"][0])
                if headers["Measurement Mode"][0]=="TRPL":
                    is_histogram = True
                    is_spectrum = True
                if headers["Measurement Mode"][0]=="EdgeCounting Map":
                    is_map = True
                    is_spectrum = False
            else:
                #I think if we are here the header is broken (program crashed before saving for example) and in this case we should default to series?
                is_series = True
                is_spectrum = True
                series_mode = "Header incomplete"

        def read_units(file):
            """
            Reads unit information from a file.

            Args:
                file: The file object to read from.

            Returns:
                tuple: A tuple containing the names, units, and information dictionary, along with the length of the read data.
            """
            length = 0
            done = False
            infos = {}
            while not done:
                line = file.readline().strip()
                length += 1
                if line == "---":
                    done = True
                else:
                    line = line.split("\t")
                    infos[line[0]] = Data1D(
                        numpy.array(line[2:], dtype=numpy.float64),
                        datatypes.generateDataType(line[0], line[1]),
                    )
            names = file.readline().strip().split("\t")
            units = file.readline().strip().split("\t")
            length += 2
            return names, units, infos, length

    else:
        # Old Header
        is_map = headers["Measurement Type"][0] == "Mapscan Cube"
        is_series = headers["Measurement Type"][0] == "Series"
        if is_series:
          series_mode = headers["Measurement Type"][1]
        is_ple = is_series and headers["Measurement Type"][1] == "PLE Xe Arc Lamp"
        is_ple_response = headers["Measurement Type"][0] == "PLE Response"
        is_histogram = headers["Measurement Type"][0] == "Histogram"
        is_reference = False
        is_spectrum = True

        def read_units(file):
            names = file.readline().strip().split("\t")
            units = file.readline().strip().split("\t")
            infos = {}
            if is_series and len(units) > 2:
                # In the legacy file, the powers are appended after the units in the units row, unless it is a Time Series (no param), where they start in column 3..
                if headers["Measurement Type"][1] == "Time Series":
                    fields = units[3:]
                elif headers["Measurement Type"][1] == "Power":
                    fields = names[3:]                 
                else:                 
                    fields = units[1 + int(len(units) / 2) :]  
                try:
                    values = numpy.array(fields, dtype=numpy.float64)        
                    infos["Power Track"] = Data1D(values, datatypes.P_mW)
                except ValueError as e:
                    print("Invalid Power in tracked power:", e)
            return names, units, infos, 2  # in the old format, these are always 2 lines

    if is_map:
        print("Mapscan detected")
        # For Mapscans, the Header is followed by a section showing the mapping using X and O.
        map_x = int(headers["Map Dimension X"][0])
        map_y = int(headers["Map Dimension Y"][0])
        if "Map Pitch (µm)" in headers.keys():
            map_pitch = float(headers["Map Pitch (µm)"][0])
            map_x0 = float(headers["Map Edge Position X (µm)"][0])
            map_y0 = float(headers["Map Edge Position Y (µm)"][0])
            datatype_pos = datatypes.POS_um
        else:
            map_pitch = float(headers["Map Pitch (mm)"][0])
            map_x0 = float(headers["Map Edge Position X (mm)"][0])
            map_y0 = float(headers["Map Edge Position Y (mm)"][0])
            datatype_pos = datatypes.POS_mm
        file.readline()  # ---
        mapping = numpy.ndarray(shape=(map_x, map_y, 2), dtype=numpy.float64)
        bool_mask = numpy.ndarray(shape=(map_x, map_y), dtype=bool)
        num = 0
        for i in range(map_y):
            line = file.readline()
            for j in range(map_x):
                mapping[j, map_y - 1 - i] = [
                    map_x0 + j * map_pitch,
                    map_y0 + (map_y - 1 - i) * map_pitch,
                ]
                if line[j] == "X":
                    bool_mask[j, map_y - 1 - i] = True
                    num += 1
                else:
                    bool_mask[j, map_y - 1 - i] = False
        file.readline()  # ---

        def build_mask(actual_num):
            mask = numpy.ndarray(shape=(map_x, map_y), dtype=numpy.float64)
            #build mask
            n = 0
            for i in range(map_x):
                for j in range(map_y):
                    if bool_mask[i, j]:
                        if n < actual_num:  # Ignore missing pixels
                            mask[i, j] = n
                        else:
                            mask[i, j] = numpy.nan
                        n += 1
                    else:
                        mask[i, j] = numpy.nan
            return Data2D(mask, datatypes.NUMBER)

        mapping = Data3D(mapping, datatype_pos)

        if is_spectrum:
            names, units, infos, length = read_units(file)
            endOfAxis = False
            axisData = []
            while not endOfAxis:
                value = file.readline().strip()
                if value == "---":
                    break
                axisData.append(float(value.split("\t")[0]))
            axis = Data1D(numpy.array(axisData), datatypes.generateDataType(names[0], units[0]))
            raw = numpy.fromfile(file, dtype=numpy.dtype(">u8"))[
                1:
            ]  # 64bit uint big-endian
            actual_num = int(numpy.floor(len(raw) / len(axis.values)))
            data = numpy.ndarray(shape=(actual_num, len(axis.values)))
            # It seems that this array is transposed?
            data = raw.reshape((len(axis.values), actual_num)).T

            #Special case for DARK map
            if (
                "Dark Frames" in headers.keys()
                and int(headers["Dark Frames"][0]) > 0
                and data.shape[0] == int(headers["Dark Frames"][0])+1 
            ):
                # This is a Time Series of Dark Spectra, the last Dark Spectrum is the AVG used for correct
                keyvals = numpy.arange(1, int(headers["Dark Frames"][0]) + 2)
                keys = Data1D(keyvals.astype(str), datatypes.NUMBER)
                keys.values[-1] = "Average"
                return SpectrumSeries(axis, keys, Data1D(data, datatypes.COUNTS), headers, infos)

            sparsemap = SparseSpectrumMap(
                axis,
                Data2D(data.astype(numpy.float64), datatypes.COUNTS),
                mapping,
                build_mask(actual_num),
                None,
                headers,
                infos,
            )
            if "Dark Frames" in headers.keys() and int(headers["Dark Frames"][0]) > 0:
                # Has been corrected and is offset by 1000
                if "Dark Offset" in headers.keys():
                    sparsemap.data.values -= int(headers["Dark Offset"][0])
                else:
                    sparsemap.data.values -= 1000
            return sparsemap
        else:
            #This is a 2D Map (e.g. EdgeCountingMap)
            data = numpy.genfromtxt(file)
            return Map(mapping, Data1D(data, datatypes.COUNTS), build_mask(len(data)))
    else: #!is_map
        names, units, infos, hlength = read_units(file)
        length = hlength + len(headers) + 1
        if is_reference:
            #2 Tables
            lines = []
            while True:
                line=file.readline()
                if line.strip()=="---":
                    break
                lines.append(line)
            data = numpy.genfromtxt(StringIO('\n'.join(lines))).T
            is_series=False
            file.close()

        else:
            #1 Table
            file.close()
            data = ASCII(filename, skip_header=length).T
        if data[0, 0] == numpy.inf or data[0, 0] == -numpy.inf:
            axis = Data1D(data[1, :], datatypes.generateDataType(names[1], units[1]))
        else:
            axis = Data1D(data[0, :], datatypes.generateDataType(names[0], units[0]))
        if is_series:
            # 2D
            values = Data2D(data[2:, :], datatypes.COUNTS)
            if "Dark Spectrum" in headers.keys()  or ("Dark Frames" in headers.keys() and int(headers["Dark Frames"][0]) > 0):
                # Has been corrected and is offset by 1000
                if "Dark Offset" in headers.keys():
                    values.values -= int(headers["Dark Offset"][0])
                else:
                    values.values -= 1000
            if is_ple:
                dtype = datatypes.generateDataType("Excitation Wavelength", "nm")
            else:
                if len(units) > 2:
                    dtype = datatypes.generateDataType(series_mode, units[2])  # TODO
                else:
                    dtype = datatypes.generateDataType(series_mode, "a.u.")  # TODO
            keys = Data1D(
                numpy.array(names[2 : 2 + values.values.shape[0]]).astype(
                    numpy.float64
                ),
                dtype,
            )
            if (
                "Dark Frames" in headers.keys()
                and int(headers["Dark Frames"][0]) > 0
                and values.values.shape[0] == int(headers["Dark Frames"][0])+1 
                and len(keys.values) == 0
            ):
                # This is a Time Series of Dark Spectra, the last Dark Spectrum is the AVG used for correct
                keyvals = numpy.arange(1, int(headers["Dark Frames"][0]) + 2)
                keys.values = keyvals.astype(str)
                keys.values[-1] = "Average"
            if is_ple:
                return PLE(axis, keys, values, None, None, headers)
            else:
                return SpectrumSeries(axis, keys, values, headers, infos)
        elif is_ple_response:
            spectra= []
            for i in range(1,4):
                spectra.append(Spectrum(axis, Data1D(data[i, :], datatypes.generateDataType(names[i], units[i])), headers))
            return spectra
        elif is_histogram:
            values = Data1D(data[1, :], datatypes.COUNTS)
            return Spectrum(axis, values, headers)
        else:
            # 1D
            values = Data1D(data[2, :], datatypes.COUNTS)
            return Spectrum(axis, values, headers)
