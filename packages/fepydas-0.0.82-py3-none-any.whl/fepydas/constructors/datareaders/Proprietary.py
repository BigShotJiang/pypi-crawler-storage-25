#!/usr/bin/python3
import numpy
from fepydas.libs.sdtfile import SdtFile

try:
    import ptufile
except ImportError:
    ptufile = None


def PicoHarpHistogramIntegrationTime(filename):
    """
    Reads the integration time from a PicoHarp histogram file.

    Args:
        filename (str): The path to the PicoHarp histogram file.

    Returns:
        float: The integration time extracted from the file.
    """
    file = open(filename, "br")
    bytes = file.read(1000000000)
    from struct import unpack, calcsize

    skip = 0
    fmt_txtHdr = "8s8s"
    size_txtHdr = calcsize(fmt_txtHdr)
    data_txtHdr = unpack(fmt_txtHdr, bytes[skip : skip + size_txtHdr])
    skip += size_txtHdr
    fmt_Hdr = "32s3i1I"
    size_Hdr = calcsize(fmt_Hdr)
    NumberOfCurves = 0
    HistResDscr = {}
    while True:
        data_Hdr = unpack(fmt_Hdr, bytes[skip : skip + size_Hdr])
        skip += size_Hdr
        if data_Hdr[2] & 65535 == 65535:
            skip += data_Hdr[3]
        if data_Hdr[0] == b"HistResDscr_MDescStopAfter\x00\x00\x00\x00\x00\x00":
            # if data_Hdr[0] == b'MeasDesc_AcquisitionTime\x00\x00\x00\x00\x00\x00\x00\x00':
            time = data_Hdr[3]
            break
        if (
            data_Hdr[0]
            == b"Header_End\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        ):
            break
    file.close()
    return time


def PicoHarpHistogram(filename):
    """
    Reads histogram data from a PicoHarp histogram file.

    Args:
        filename (str): The path to the PicoHarp histogram file.

    Returns:
        tuple: A tuple containing the time axis and histogram data as numpy arrays.
    """
    file = open(filename, "br")
    bytes = file.read(1000000000)
    from struct import unpack, calcsize

    skip = 0
    fmt_txtHdr = "8s8s"
    size_txtHdr = calcsize(fmt_txtHdr)
    data_txtHdr = unpack(fmt_txtHdr, bytes[skip : skip + size_txtHdr])
    skip += size_txtHdr
    fmt_Hdr = "32s3i1I"
    size_Hdr = calcsize(fmt_Hdr)
    NumberOfCurves = 0
    HistResDscr = {}
    while True:
        data_Hdr = unpack(fmt_Hdr, bytes[skip : skip + size_Hdr])
        skip += size_Hdr
        if data_Hdr[2] & 65535 == 65535:
            skip += data_Hdr[3]
        if (
            data_Hdr[0]
            == b"Header_End\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        ):
            break
        if data_Hdr[0] == b"HistoResult_NumberOfCurves\x00\x00\x00\x00\x00\x00":
            NumberOfCurves = data_Hdr[3]
        if (
            data_Hdr[0]
            == b"HistResDscr_DataOffset\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
        ):
            curveId = data_Hdr[1]
            value = data_Hdr[3]
            if not curveId in HistResDscr.keys():
                HistResDscr[curveId] = {}
            HistResDscr[curveId]["DataOffset"] = value
        if data_Hdr[0] == b"HistResDscr_HistogramBins\x00\x00\x00\x00\x00\x00\x00":
            curveId = data_Hdr[1]
            value = data_Hdr[3]
            if not curveId in HistResDscr.keys():
                HistResDscr[curveId] = {}
            HistResDscr[curveId]["HistogramBins"] = value
        if data_Hdr[0] == b"HistResDscr_MDescResolution\x00\x00\x00\x00\x00":
            curveId = data_Hdr[1]
            fmt_Float = "1d"
            size_Float = calcsize(fmt_Float)
            data_Float = data_Hdr = unpack(fmt_Float, bytes[skip - size_Float : skip])
            value = data_Float[0]
            if not curveId in HistResDscr.keys():
                HistResDscr[curveId] = {}
            HistResDscr[curveId]["MDescResolution"] = value
    data = numpy.zeros(shape=(HistResDscr[0]["HistogramBins"]), dtype=numpy.int64)
    print("Number of Curves: {0}".format(NumberOfCurves))
    for i in range(NumberOfCurves):
        offset = HistResDscr[i]["DataOffset"]
        fmt_Histogram = "{0}I".format(HistResDscr[i]["HistogramBins"])
        size_Histogram = calcsize(fmt_Histogram)
        Histogram = unpack(fmt_Histogram, bytes[offset : offset + size_Histogram])
        data += Histogram
    print(
        "Bins: {0} Resolution: {1}".format(
            HistResDscr[0]["HistogramBins"], HistResDscr[0]["MDescResolution"]
        )
    )
    time = numpy.arange(
        0,
        (HistResDscr[0]["HistogramBins"]) * HistResDscr[0]["MDescResolution"] / 1e-9,
        HistResDscr[0]["MDescResolution"] / 1e-9,
    )
    file.close()
    return time, data


def TimeHarpHistogram(filename):
    """
    Reads histogram data from a TimeHarp histogram file.

    Args:
        filename (str): The path to the TimeHarp histogram file.

    Returns:
        tuple: A tuple containing the time axis and histogram data as numpy arrays.
    """
    file = open(filename, "br")
    bytes = file.read(100000000)
    from struct import unpack, calcsize

    skip = 0
    fmt_txtHdr = "16s6s18s12s18s2s256s"
    size_txtHdr = calcsize(fmt_txtHdr)
    skip += size_txtHdr

    fmt_binHdr = "6id2iI3i4I16i9f4i20s"
    size_binHdr = calcsize(fmt_binHdr)
    skip += size_binHdr

    fmt_mainHardwareHdr = "16s8s16s2id12i"
    size_mainHardwareHdr = calcsize(fmt_mainHardwareHdr)
    data_mainHardwareHdr = unpack(
        fmt_mainHardwareHdr, bytes[skip : skip + size_mainHardwareHdr]
    )
    inpChansPresent = data_mainHardwareHdr[7]
    skip += size_mainHardwareHdr

    fmt_inputChannelSettings = "4i"
    size_inputChannelsettings = inpChansPresent * calcsize(fmt_inputChannelSettings)
    skip += size_inputChannelsettings

    fmt_curveHdr = "iI16s8s16s2id20id4i3f3iQ2i"
    size_curveHdr = calcsize(fmt_curveHdr)
    data_curveHdr = unpack(fmt_curveHdr, bytes[skip : skip + size_curveHdr])
    bins = data_curveHdr[40]
    offset = data_curveHdr[41]
    resolution = data_curveHdr[28]
    print("Acquisition Time: {0}s".format(data_curveHdr[31] / 1000))
    print("Resolution: {0}ns".format(resolution / 1000))

    fmt_counts = "{0}I".format(bins)
    size_counts = calcsize(fmt_counts)
    data_counts = unpack(fmt_counts, bytes[offset : offset + size_counts])
    data = numpy.array(data_counts)
    time = numpy.arange(0, (bins) * resolution / 1000, resolution / 1000)

    return time, data


def BeckerHicklHistogram(filename):
    """
    Reads histogram data from a Becker & Hickl SDT file.

    Args:
        filename (str): The path to the Becker & Hickl SDT file.

    Returns:
        tuple: A tuple containing the time axis and histogram data as numpy arrays.
    """
    sdt = SdtFile(filename)
    x = numpy.ndarray(shape=(len(sdt.times[0][:])))
    y = numpy.ndarray(shape=(len(sdt.times[0][:])))
    print(len(sdt.times[0]))
    for i in range(len(sdt.times[0][:])):
        x[i] = numpy.abs(sdt.times[0][i] * 1000000000)
        y[i] = sdt.data[0][0][i]
    return x, y


def PTUHistogram(
    filename,
    channel=0,
    bin_width_s=0.001,
    use_memmap=True,
    all_channels=True,
    bin_width_steps=None,
    number_of_bins=None,
    max_bins=1000000,
):
    """
    Liesst eine Zeitspur (Histogramm) aus einer PicoQuant PTU-Datei durch Binning
    der Photonenevents über die globale Messzeit.

    Args:
        filename (str): Pfad zur PTU-Datei.
        channel (int | None, optional): Gewählter Detektorkanal. Ignoriert wenn all_channels=True.
            Defaults zu 0.
        bin_width_s (float, optional): Zeit-Breite der Bins in Sekunden. Muss ein ganzzahliges
            Vielfaches der Globalauflösung sein. Defaults zu 0.001 s.
        use_memmap (bool, optional): Wenn True, Records via Memory-Mapping einlesen, bevor
            dekodiert wird.
        all_channels (bool, optional): Wenn True, alle vorhandenen Kanäle gleichzeitig laden und
            als 2D-Array zurückgeben (shape: n_channels × n_bins).
        bin_width_steps (int | None, optional): Anzahl der Globalauflösungen pro Bin (k).
            Wenn gesetzt, überschreibt dies bin_width_s.
        number_of_bins (int | None, optional): Explizite Zielanzahl an Bins (überschreibt bin_width_*).
        max_bins (int, optional): Sicherheitslimit gegen zu große Arrays.

    Returns:
        tuple:
            time_ns (numpy.ndarray): Bin-Zeitmittelpunkte in ns (1D).
            data (numpy.ndarray): Zählraten.
                * all_channels=False: 1D-Array (n_bins,) für den gewählten Kanal
                * all_channels=True: 2D-Array (n_channels, n_bins)
            metadata (dict)
    """
    if ptufile is None:
        raise ImportError(
            "PTU support requires 'ptufile'. Install it with: pip install ptufile"
        )

    if number_of_bins is None and bin_width_s is None and bin_width_steps is None:
        raise ValueError(
            "Provide one of: number_of_bins, bin_width_steps or bin_width_s"
        )

    if bin_width_s is not None and bin_width_s <= 0:
        raise ValueError("bin_width_s must be > 0")

    if bin_width_steps is not None and int(bin_width_steps) < 1:
        raise ValueError("bin_width_steps must be an integer >= 1")

    if number_of_bins is not None and int(number_of_bins) < 1:
        raise ValueError("number_of_bins must be an integer >= 1")

    with ptufile.PtuFile(filename) as ptu:
        records = ptu.decode_records(
            ptu.read_records(memmap=True) if use_memmap else None
        )

        channels_arr = records["channel"]
        times_ticks = records["time"]

        valid = channels_arr >= 0
        channels_arr = channels_arr[valid]
        times_ticks = times_ticks[valid]

        if times_ticks.size == 0:
            raise ValueError("PTU file contains no photon events")

        active_channels = tuple(int(c) for c in numpy.unique(channels_arr))

        # Globalauflösung
        global_resolution_s = float(ptu.global_resolution)
        if not numpy.isfinite(global_resolution_s) or global_resolution_s <= 0:
            raise ValueError("Invalid PTU global_resolution")

        # Zeiten in Sekunden
        times_s = times_ticks.astype(numpy.float64) * global_resolution_s
        t_min = 0.0
        t_max = float(times_s.max())
        duration_s = t_max - t_min

        # Bins bestimmen: Priorität number_of_bins > bin_width_steps > bin_width_s
        used_number_of_bins = None
        used_k = None
        if number_of_bins is not None:
            used_number_of_bins = int(number_of_bins)
            if used_number_of_bins > max_bins:
                raise MemoryError(
                    "Requested number_of_bins = {0} exceeds safety limit max_bins = {1}".format(
                        used_number_of_bins, max_bins
                    )
                )
            # Gleichmäßig über [t_min, t_max]; wenn keine Events exakt an der Oberkante,
            # ist das äquivalent zu arange mit passender bin_width
            edges = numpy.linspace(
                t_min, t_max, used_number_of_bins + 1, dtype=numpy.float64
            )
            bin_width_s = (
                duration_s / used_number_of_bins
                if used_number_of_bins > 0
                else duration_s
            )
        else:
            # Binbreite über k oder s
            if bin_width_steps is not None:
                used_k = int(bin_width_steps)
                bin_width_s = used_k * global_resolution_s
            else:
                k = bin_width_s / global_resolution_s
                k_round = int(round(k))
                if k != k_round:
                    suggested = k_round * global_resolution_s
                    raise ValueError(
                        "bin_width_s must be an integer multiple of the PTU global resolution "
                        "(global_resolution_s = {0:.12g} s). Requested: {1:.12g} s, "
                        "nearest valid: {2:.12g} s (k = {3})".format(
                            global_resolution_s, bin_width_s, suggested, k_round
                        )
                    )
                used_k = k_round
                bin_width_s = used_k * global_resolution_s

            # Anzahl Bins vorab prüfen
            approx_bins = (
                int(numpy.ceil(duration_s / bin_width_s)) if bin_width_s > 0 else 1
            )
            if approx_bins > max_bins:
                raise MemoryError(
                    "The chosen bin width results in ~{0} bins, exceeding max_bins = {1}. "
                    "Increase bin_width_steps (gröbere Bins) oder setze number_of_bins.".format(
                        approx_bins, max_bins
                    )
                )

            edges = numpy.arange(
                t_min, t_max + bin_width_s, bin_width_s, dtype=numpy.float64
            )
            if edges.size < 2:
                edges = numpy.array([t_min, t_min + bin_width_s], dtype=numpy.float64)
            # Korrigiere number_of_bins aus edges
            used_number_of_bins = int(edges.size - 1)

        # Zeitachsenmittelpunkte in ns
        time_ns = 0.5 * (edges[:-1] + edges[1:]) * 1e9

        if all_channels:
            data_2d = numpy.zeros(
                (len(active_channels), len(time_ns)), dtype=numpy.int64
            )
            events_per_channel = {}
            for idx, ch in enumerate(active_channels):
                ch_mask = channels_arr == ch
                ch_times_s = times_s[ch_mask]
                events_per_channel[int(ch)] = int(ch_mask.sum())
                if ch_times_s.size > 0:
                    hist, _ = numpy.histogram(ch_times_s, bins=edges)
                    data_2d[idx, :] = hist

            metadata = ptu.attrs.copy()
            metadata.pop("tags", None)
            metadata["filename"] = filename
            metadata["format"] = "ptu"
            metadata["available_channels"] = active_channels
            metadata["bin_width_s"] = float(bin_width_s)
            metadata["bin_width_ns"] = float(bin_width_s * 1e9)
            metadata["bin_width_steps"] = int(round(bin_width_s / global_resolution_s))
            metadata["number_of_bins"] = int(used_number_of_bins)
            metadata["x_axis"] = "global_time"
            metadata["duration_s"] = float(t_max)
            metadata["time_start_s"] = float(t_min)
            metadata["time_stop_s"] = float(edges[-1])
            metadata["events_per_channel"] = events_per_channel

            print(
                "PTU time trace: {0}, channels: {1}, bins: {2}, bin width: {3} s, duration: {4} s".format(
                    filename, active_channels, data_2d.shape[1], bin_width_s, t_max
                )
            )
            return time_ns, data_2d, metadata

        # Single-Channel
        if channel not in active_channels:
            raise ValueError(
                "Channel {0} not found in PTU file. Available channels: {1}".format(
                    channel, active_channels
                )
            )
        ch_times_s = times_s[channels_arr == channel]
        if ch_times_s.size == 0:
            raise ValueError("Channel {0} contains no photon events".format(channel))

        data, _ = numpy.histogram(ch_times_s, bins=edges)

        metadata = ptu.attrs.copy()
        metadata.pop("tags", None)
        metadata["filename"] = filename
        metadata["format"] = "ptu"
        metadata["channel"] = int(channel)
        metadata["available_channels"] = active_channels
        metadata["bin_width_s"] = float(bin_width_s)
        metadata["bin_width_ns"] = float(bin_width_s * 1e9)
        metadata["bin_width_steps"] = int(round(bin_width_s / global_resolution_s))
        metadata["x_axis"] = "global_time"
        metadata["events_in_channel"] = int(ch_times_s.size)
        metadata["duration_s"] = float(t_max)
        metadata["time_start_s"] = float(t_min)
        metadata["time_stop_s"] = float(edges[-1])
        metadata["number_of_bins"] = int(len(data))

        print(
            "PTU time trace: {0}, channel: {1}, bins: {2}, bin width: {3} s, duration: {4} s".format(
                filename, channel, len(data), bin_width_s, t_max
            )
        )

    return time_ns, data, metadata
