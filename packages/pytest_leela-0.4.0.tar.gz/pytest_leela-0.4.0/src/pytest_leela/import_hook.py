"""Import hook for in-memory AST mutation — zero file I/O."""

from __future__ import annotations

import ast
import importlib
import importlib.abc
import importlib.machinery
import sys
import types
from typing import Any, Callable

from pytest_leela.models import Mutant

# Pre-cache bytecode functions at import time.  Doing the import inside
# exec_module() is fragile: during self-mutation the import machinery
# would load a MUTATED version of bytecode.py, causing all mutations
# to silently fail (0% kill rate).  Capturing references at module load
# avoids the problem entirely — same pattern as _django_clear_url_caches
# in runner.py.
try:
    from pytest_leela.bytecode import (
        is_bytecode_eligible as _bc_is_eligible,
        is_supported as _bc_is_supported,
        mutate_code as _bc_mutate_code,
    )
except ImportError:
    _bc_is_eligible = None
    _bc_is_supported = None
    _bc_mutate_code = None

# AST operator classes by name
_OP_CLASSES: dict[str, type] = {
    "Add": ast.Add,
    "Sub": ast.Sub,
    "Mult": ast.Mult,
    "Div": ast.Div,
    "FloorDiv": ast.FloorDiv,
    "Mod": ast.Mod,
    "Pow": ast.Pow,
    "Eq": ast.Eq,
    "NotEq": ast.NotEq,
    "Lt": ast.Lt,
    "LtE": ast.LtE,
    "Gt": ast.Gt,
    "GtE": ast.GtE,
    "Is": ast.Is,
    "IsNot": ast.IsNot,
    "In": ast.In,
    "NotIn": ast.NotIn,
    "And": ast.And,
    "Or": ast.Or,
    "UAdd": ast.UAdd,
    "USub": ast.USub,
    "Not": ast.Not,
    "BitAnd": ast.BitAnd,
    "BitOr": ast.BitOr,
    "BitXor": ast.BitXor,
    "LShift": ast.LShift,
    "RShift": ast.RShift,
}


class MutantApplier(ast.NodeTransformer):
    """Apply a single mutation to an AST."""

    def __init__(self, mutant: Mutant) -> None:
        self.mutant = mutant
        self.applied = False

    def _matches(self, node: ast.AST) -> bool:
        return (
            hasattr(node, "lineno")
            and node.lineno == self.mutant.point.lineno
            and hasattr(node, "col_offset")
            and node.col_offset == self.mutant.point.col_offset
        )

    def visit_BinOp(self, node: ast.BinOp) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "BinOp":
            op_class = _OP_CLASSES.get(self.mutant.replacement_op)
            if op_class is not None:
                node.op = op_class()
                self.applied = True
        return self.generic_visit(node)

    def visit_Compare(self, node: ast.Compare) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "Compare":
            op_class = _OP_CLASSES.get(self.mutant.replacement_op)
            if op_class is not None:
                # Replace all comparison ops (single comparison case)
                node.ops = [op_class() for _ in node.ops]
                self.applied = True
        return self.generic_visit(node)

    def visit_BoolOp(self, node: ast.BoolOp) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "BoolOp":
            op_class = _OP_CLASSES.get(self.mutant.replacement_op)
            if op_class is not None:
                node.op = op_class()
                self.applied = True
        return self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "AugAssign":
            op_class = _OP_CLASSES.get(self.mutant.replacement_op)
            if op_class is not None:
                node.op = op_class()
                self.applied = True
        return self.generic_visit(node)

    def visit_IfExp(self, node: ast.IfExp) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "IfExp":
            replacement = self.mutant.replacement_op
            if replacement == "swap_branches":
                node.body, node.orelse = node.orelse, node.body
                self.applied = True
            elif replacement == "always_true":
                self.applied = True
                return ast.copy_location(node.body, node)
            elif replacement == "always_false":
                self.applied = True
                return ast.copy_location(node.orelse, node)
        return self.generic_visit(node)

    def visit_Break(self, node: ast.Break) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "Break":
            if self.mutant.replacement_op == "continue":
                self.applied = True
                return ast.copy_location(ast.Continue(), node)
        return self.generic_visit(node)

    def visit_Continue(self, node: ast.Continue) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "Continue":
            if self.mutant.replacement_op == "break":
                self.applied = True
                return ast.copy_location(ast.Break(), node)
        return self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "ExceptHandler":
            replacement = self.mutant.replacement_op
            if replacement == "broaden" and node.type is not None:
                original_type = node.type
                node.type = ast.Name(id="Exception", ctx=ast.Load())
                ast.copy_location(node.type, original_type)
                self.applied = True
            elif replacement == "body_to_raise":
                raise_stmt = ast.Raise()
                ast.copy_location(raise_stmt, node)
                node.body = [raise_stmt]
                self.applied = True
        return self.generic_visit(node)

    def visit_UnaryOp(self, node: ast.UnaryOp) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "UnaryOp":
            if self.mutant.replacement_op == "_remove":
                self.applied = True
                return node.operand
            op_class = _OP_CLASSES.get(self.mutant.replacement_op)
            if op_class is not None:
                node.op = op_class()
                self.applied = True
        return self.generic_visit(node)

    def visit_Return(self, node: ast.Return) -> ast.AST:
        if self._matches(node) and self.mutant.point.node_type == "Return":
            node = self._mutate_return(node)
        return self.generic_visit(node)

    def _mutate_return(self, node: ast.Return) -> ast.Return:
        replacement = self.mutant.replacement_op

        if replacement == "False":
            node.value = ast.Constant(value=False)
            self.applied = True
        elif replacement == "True":
            node.value = ast.Constant(value=True)
            self.applied = True
        elif replacement == "None":
            node.value = ast.Constant(value=None)
            self.applied = True
        elif replacement == "negate" and node.value is not None:
            node.value = ast.UnaryOp(op=ast.USub(), operand=node.value)
            self.applied = True
        elif replacement == "negate_expr" and node.value is not None:
            node.value = ast.UnaryOp(op=ast.Not(), operand=node.value)
            self.applied = True
        elif replacement == "remove_negation" and isinstance(node.value, ast.UnaryOp):
            node.value = node.value.operand
            self.applied = True
        elif replacement == "empty_str":
            node.value = ast.Constant(value="")
            self.applied = True
        elif (
            replacement == "expr"
            and node.value is not None
            and isinstance(node.value, ast.Constant)
            and node.value.value is None
        ):
            node.value = ast.Constant(value=True)
            self.applied = True

        return node


def apply_mutation(source: str, mutant: Mutant) -> tuple[str, bool]:
    """Apply a mutation to source code, return (mutated_source_compiled, was_applied)."""
    tree = ast.parse(source)
    applier = MutantApplier(mutant)
    tree = applier.visit(tree)
    ast.fix_missing_locations(tree)
    return tree, applier.applied


class MutatingLoader(importlib.abc.Loader):
    """Loader that applies a mutation to source before executing."""

    def __init__(
        self,
        source: str,
        mutant: Mutant,
        filename: str,
        cached_code: types.CodeType | None = None,
    ) -> None:
        self.source = source
        self.mutant = mutant
        self.filename = filename
        self.cached_code = cached_code

    def create_module(self, spec: importlib.machinery.ModuleSpec) -> None:
        return None

    def exec_module(self, module: types.ModuleType) -> None:
        # Try bytecode path first when a cached code object is available.
        # Uses pre-cached references to avoid loading a mutated bytecode.py
        # during self-mutation.
        if (
            self.cached_code is not None
            and _bc_is_supported is not None
            and _bc_is_supported()
            and _bc_is_eligible(self.mutant)
        ):
            mutated = _bc_mutate_code(self.cached_code, self.mutant)
            if mutated is not None:
                exec(mutated, module.__dict__)
                return

        # Fall back to AST pipeline
        tree = ast.parse(self.source, filename=self.filename)
        applier = MutantApplier(self.mutant)
        tree = applier.visit(tree)
        ast.fix_missing_locations(tree)
        code = compile(tree, self.filename, "exec")
        exec(code, module.__dict__)


class MutatingFinder(importlib.abc.MetaPathFinder):
    """Meta path finder that intercepts imports of target modules."""

    def __init__(
        self,
        target_modules: dict[str, str],
        mutant: Mutant,
        target_codes: dict[str, types.CodeType] | None = None,
    ) -> None:
        # target_modules: {module_name: source_code}
        self.target_modules = target_modules
        self.mutant = mutant
        self.target_codes = target_codes or {}
        self._module_to_file: dict[str, str] = {}
        for mod_name in target_modules:
            self._module_to_file[mod_name] = f"<mutated:{mod_name}>"

    def set_file_paths(self, module_to_file: dict[str, str]) -> None:
        self._module_to_file.update(module_to_file)

    def find_spec(
        self,
        fullname: str,
        path: Any = None,
        target: Any = None,
    ) -> importlib.machinery.ModuleSpec | None:
        if fullname in self.target_modules:
            filename = self._module_to_file.get(fullname, f"<mutated:{fullname}>")
            loader = MutatingLoader(
                self.target_modules[fullname],
                self.mutant,
                filename,
                cached_code=self.target_codes.get(fullname),
            )
            return importlib.machinery.ModuleSpec(fullname, loader, origin=filename)
        return None


def install_hook(
    target_modules: dict[str, str],
    mutant: Mutant,
    module_to_file: dict[str, str] | None = None,
    target_codes: dict[str, types.CodeType] | None = None,
) -> MutatingFinder:
    """Install a mutating import hook. Returns the finder for later removal."""
    finder = MutatingFinder(target_modules, mutant, target_codes=target_codes)
    if module_to_file:
        finder.set_file_paths(module_to_file)
    sys.meta_path.insert(0, finder)
    return finder


def remove_hook(finder: MutatingFinder) -> None:
    """Remove a previously installed import hook."""
    try:
        sys.meta_path.remove(finder)
    except ValueError:
        pass


def clear_target_modules(module_names: list[str]) -> None:
    """Remove target modules from sys.modules to force re-import."""
    for name in module_names:
        sys.modules.pop(name, None)
        # Also clear submodules
        to_remove = [k for k in sys.modules if k.startswith(name + ".")]
        for k in to_remove:
            del sys.modules[k]
