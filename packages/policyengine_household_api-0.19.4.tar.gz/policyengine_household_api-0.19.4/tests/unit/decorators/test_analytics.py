"""
Unit tests for analytics decorator.
Tests conditional analytics logging based on opt-in/opt-out configuration.
"""

import pytest


class TestAnalyticsDecorator:
    """Test the log_analytics_if_enabled decorator."""

    def test__given_analytics_disabled__decorator_skips_analytics_logging(
        self, sample_function, mock_analytics_disabled
    ):
        """Decorator should skip analytics when disabled."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        decorated = log_analytics_if_enabled(sample_function)
        result = decorated("arg1", "arg2", kwarg1="test")
        assert result == "Result: arg1, arg2, test"

    def test__given_analytics_enabled_and_valid_auth__decorator_logs_visit(
        self, sample_function, setup_analytics_decorator_test
    ):
        """Decorator should log analytics when enabled with valid auth."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        decorated = log_analytics_if_enabled(sample_function)
        result = decorated("arg1", "arg2", kwarg1="test")

        assert result == "Result: arg1, arg2, test"

        # Verify properties were set on Visit instance
        visit = setup_analytics_decorator_test["visit"]
        assert visit.client_id == "test-client"
        assert visit.endpoint == "calculate"
        assert visit.method == "POST"
        assert visit.content_length_bytes == 1024
        assert visit.datetime == setup_analytics_decorator_test["fixed_time"]
        assert visit.api_version == "1.0.0"

        # Verify database operations
        session = setup_analytics_decorator_test["session"]
        session.add.assert_called_once_with(visit)
        session.commit.assert_called_once()

    def test__given_no_authorization__decorator_logs_with_null_client(
        self,
        sample_function,
        mock_analytics_enabled,
        mock_visit_class,
        mock_request_without_auth,
        mock_datetime_fixed,
        mock_version,
        mock_db_session,
    ):
        """Missing Authorization header must store NULL client_id.

        Aligns with the verified-fail path: any identity we can't prove
        is stored as None, never as an attacker-writable sentinel.
        """
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        _, visit_instance = mock_visit_class

        decorated = log_analytics_if_enabled(sample_function)
        result = decorated("arg1", "arg2", kwarg1="test")

        assert result == "Result: arg1, arg2, test"
        assert visit_instance.client_id is None
        mock_db_session.add.assert_called_once_with(visit_instance)

    def test__given_jwt_decode_error__decorator_logs_with_null_client(
        self,
        sample_function,
        mock_analytics_enabled,
        mock_visit_class,
        mock_request_with_auth,
        mock_jwt_invalid,
        mock_datetime_fixed,
        mock_version,
        mock_db_session,
    ):
        """JWT decode errors must also produce a NULL client_id."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        _, visit_instance = mock_visit_class

        decorated = log_analytics_if_enabled(sample_function)
        result = decorated("arg1", "arg2", kwarg1="test")

        assert result == "Result: arg1, arg2, test"
        assert visit_instance.client_id is None

    def test__given_client_id_with_suffix__decorator_strips_suffix(
        self,
        sample_function,
        mock_analytics_enabled,
        mock_visit_class,
        mock_request_with_auth,
        mock_jwt_valid_with_suffix,
        mock_datetime_fixed,
        mock_version,
        mock_db_session,
    ):
        """Decorator should strip @clients suffix from client ID."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        _, visit_instance = mock_visit_class

        decorated = log_analytics_if_enabled(sample_function)
        decorated("arg1", "arg2")

        # Verify client_id had @clients suffix stripped
        assert visit_instance.client_id == "test-client"

    def test__given_client_id_without_suffix__decorator_preserves_id(
        self,
        sample_function,
        mock_analytics_enabled,
        mock_visit_class,
        mock_request_with_auth,
        mock_jwt_valid_without_suffix,
        mock_datetime_fixed,
        mock_version,
        mock_db_session,
    ):
        """Decorator should preserve client ID without @clients suffix."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        _, visit_instance = mock_visit_class

        decorated = log_analytics_if_enabled(sample_function)
        decorated("arg1", "arg2")

        # Verify client_id preserved as-is
        assert visit_instance.client_id == "test-client"

    def test__given_database_error__decorator_raises(
        self,
        sample_function,
        mock_analytics_enabled,
        mock_visit_class,
        mock_request_with_auth,
        mock_jwt_valid_with_suffix,
        mock_datetime_fixed,
        mock_version,
        mock_db_session_with_error,
    ):
        """Enabled analytics should fail the request on database errors."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        decorated = log_analytics_if_enabled(sample_function)

        with pytest.raises(Exception, match="Database error"):
            decorated("arg1", "arg2", kwarg1="test")

        mock_db_session_with_error.rollback.assert_called_once()

    def test__given_analytics_check_raises_error__decorator_raises(
        self, sample_function, mock_analytics_error
    ):
        """Enabled analytics checks are required and should not fail open."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        decorated = log_analytics_if_enabled(sample_function)

        with pytest.raises(Exception, match="Error"):
            decorated("arg1", "arg2", kwarg1="test")

    def test__given_schema_not_ready__decorator_raises(
        self,
        sample_function,
        mock_analytics_enabled,
        mock_analytics_schema_not_ready,
        mock_db_session,
    ):
        """Enabled analytics requires a ready schema."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        decorated = log_analytics_if_enabled(sample_function)
        with pytest.raises(RuntimeError, match="Analytics is enabled"):
            decorated("arg1", "arg2", kwarg1="test")

        mock_db_session.add.assert_not_called()

    def test__given_unverified_jwt__decorator_logs_with_null_client_id(
        self,
        sample_function,
        mock_analytics_enabled,
        mock_visit_class,
        mock_request_with_auth,
        mock_jwt_unverified,
        mock_datetime_fixed,
        mock_version,
        mock_db_session,
    ):
        """Decorator should store null client_id when signature can't be verified."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        _, visit_instance = mock_visit_class

        decorated = log_analytics_if_enabled(sample_function)
        decorated("arg1", "arg2")

        # Unverified JWT means we MUST NOT trust the sub claim.
        assert visit_instance.client_id is None

    def test__given_function_decorated__metadata_is_preserved(
        self, sample_function
    ):
        """Decorator should preserve the original function's metadata."""
        from policyengine_household_api.decorators.analytics import (
            log_analytics_if_enabled,
        )

        decorated = log_analytics_if_enabled(sample_function)

        assert decorated.__name__ == sample_function.__name__
        assert decorated.__doc__ == sample_function.__doc__
