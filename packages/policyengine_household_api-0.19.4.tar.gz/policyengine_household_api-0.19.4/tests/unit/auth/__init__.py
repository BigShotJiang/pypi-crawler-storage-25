"""
Auth unit tests module.
"""
