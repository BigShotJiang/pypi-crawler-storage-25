"""
Auth fixture module.
"""
