## [0.19.4] - 2026-05-14

### Fixed

- Fix Modal staging integration tests to resolve the deployed gateway URL inside each matrix job instead of relying on a cross-job URL output.


## [0.19.3] - 2026-05-14

### Fixed

- Fix Modal gateway URL lookup to use Modal's deployed web URL instead of reconstructing overlong hostnames.


## [0.19.2] - 2026-05-14

### Fixed

- Fix the Modal gateway web endpoint label so release smoke checks use a stable URL, and scope PR workflow concurrency per pull request so stale runs do not block newer commits.


## [0.19.1] - 2026-05-14

### Fixed

- Fix Modal release app naming and manifest metadata so only US and UK package versions are release-significant, and invoke the Modal CLI through the project environment in deployment helpers.


## [0.19.0] - 2026-05-14

### Added

- Added Modal current/frontier release configuration, gateway routing, and
  manifest management for versioned household API deployments.


## [0.18.0] - 2026-05-13

### Added

- Added an authenticated, scoped calculate analytics endpoint for value-free
  request and unique variable-key queries.


## [0.17.0] - 2026-05-12

### Added

- Added privacy-safe calculate variable usage analytics and Alembic-managed analytics database migrations.


## [0.16.2] - 2026-05-12

### Changed

- Update PolicyEngine US to 1.691.1.


## [0.16.1] - 2026-05-07

### Fixed

- Validate household calculate payload variables before simulation, returning
  HTTP 400 with structured `errors` for variables not available in the API's
  PolicyEngine model version while preserving allowlisted deprecated-variable
  warnings. Also expose the OpenAPI specification and document calculate request
  and response schemas.


## [0.16.0] - 2026-05-06

### Added

- Added a deprecation registry and warn-and-drop layer for inbound /calculate payloads. Removed model variables (e.g. `medical_out_of_pocket_expenses`, deleted in policyengine-us 1.673.0) are now stripped before the engine runs, and the response includes a structured warning telling partners which variable was ignored and how to migrate. Previously these requests returned HTTP 500 with `VariableNotFoundError`.


## [0.15.2] - 2026-05-05

### Changed

- Update PolicyEngine US to 1.687.0.


## [0.15.1] - 2026-05-05

### Changed

- Migrated the `my_friend_ben` customer-household fixture off the removed `medical_out_of_pocket_expenses` input to `other_medical_expenses`, the load-bearing replacement for non-premium medical spending in policyengine-us 1.673.0+.


## [0.15.0] - 2026-04-30

### Added

- Add a `warnings` field to `/calculate` responses when the request mixes single-month input on a MONTH-defined variable with an annual output request. The other 11 months default to 0 in the engine, silently inflating annual sums; the warning explains the issue and points partners to a fix (send a yearly key, or set all 12 monthly keys).
- Reject `/calculate` requests with malformed period keys (e.g. `"not-a-period"`, `"2026/13"`) with a 400 ("Invalid period key") that names the offending key, variable, and entity. Previously these were passed through to the engine and silently ignored, leaving partners with a confusing zero result. Pydantic doesn't validate period-key strings, so this is the first checkpoint that catches them.

### Fixed

- Match the hosted v1 API when partners send a YEAR-period key on a MONTH-defined variable. Numeric values are treated as annual totals: any explicit monthly inputs are subtracted, and the remainder splits evenly across the unset months as a raw float (matching policyengine-core's `set_input_divide_by_period`, which has had this behavior since 2015). Boolean / string / enum values broadcast unchanged across the unset months while explicit monthly values override. The API rejects with a 400 ("Inconsistent input") only when every month of the year is explicit AND those monthlies don't sum to the annual total — partial monthly overrides are silently accepted with the remainder distributed across the unset months, matching v1's exact rule. Negative annual values are accepted (some MONTH-defined numeric variables can legitimately be negative). Output requests echo the partner's original keys. Adds a `warnings` array to the response when partial monthly input is paired with an annual output for the same year and there is no year-key fallback for that variable, so partners see a heads-up that the unset months will read the engine's default (purely additive — v1 has no such warning, the numeric output is unchanged).


## [0.14.4] - 2026-04-28

### Fixed

- Reapply selected audit security and correctness fixes that were rolled back in the 0.13.13 restoration.
- Migrate Auth0 JWKS validation to joserfc keys so Authlib 1.7.0 works without the temporary version cap.


## [0.14.3] - 2026-04-28

### Changed

- Update PolicyEngine US to 1.663.0.


## [0.14.2] - 2026-04-27

### Fixed

- Check out repository files before staged release promotion and cleanup jobs run local scripts.


## [0.14.1] - 2026-04-27

### Fixed

- Restore Docker's GitHub Actions image publishing path for staged releases so GHCR image names are normalized before push.


## [0.14.0] - 2026-04-27

### Changed

- Adopt Towncrier changelog fragments and automate version bumps from fragment types.

### Removed

- Remove PR-time App Engine deployment validation; pull requests now run local lint and test checks only.


# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), 
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.13.15] - 2026-04-23 18:04:20

### Changed

- Pin Authlib below 1.7.0 because the current auth module reproduces ValueError "Invalid key" on 1.7.0 but not on 1.6.11

## [0.13.14] - 2026-04-23 17:00:25

### Changed

- Restore the household API codebase to the 0.13.13 baseline
- Pin policyengine_core to <=3.23.6 and urllib3 to <=1.26.20

## [0.13.13] - 2026-04-12 01:07:14

### Added

- Return PolicyEngine bundle metadata from household calculate responses.

## [0.13.12] - 2026-04-01 21:30:32

### Changed

- Update PolicyEngine US to 1.626.1

## [0.13.11] - 2026-03-29 16:25:42

### Changed

- Return JSON service metadata from the home endpoint and improve self-hosted Docker guidance, including a container healthcheck and non-root runtime user.

## [0.13.10] - 2026-03-26 23:01:49

### Changed

- Fixed Amplifi and My Friend Ben test households with correct fixture data

## [0.13.9] - 2026-03-25 22:10:16

### Changed

- Renamed benefits_navigator test household to amplifi with updated household data

## [0.13.8] - 2026-03-19 23:02:45

### Changed

- Remove unused gcp/bump_country_package.py script.

## [0.13.7] - 2026-03-19 14:24:26

### Changed

- Update PolicyEngine US to 1.600.0

## [0.13.6] - 2026-03-19 14:08:06

### Fixed

- Pass GitHub App token to EndBug/add-and-commit to allow pushing to protected main branch

## [0.13.5] - 2026-02-26 01:08:40

### Changed

- Update PolicyEngine US to 1.587.1

## [0.13.4] - 2026-02-26 01:01:47

### Fixed

- Fix weekly update PR missing changelog details by parsing CHANGELOG.md instead of non-existent changelog.yaml from policyengine-us

## [0.13.3] - 2026-01-29 03:36:34

### Changed

- Update PolicyEngine US to 1.532.0

## [0.13.2] - 2026-01-29 03:19:47

### Fixed

- Fix PR edit permission error in weekly update workflow by using REST API instead of GraphQL.

## [0.13.1] - 2026-01-21 22:21:35

### Changed

- Update PolicyEngine US to 1.511.1

## [0.13.0] - 2026-01-19 14:04:10

### Added

- Docker Compose support for local development with Redis
- Makefile targets for building and running Docker containers
- Support for external Docker networks when running alongside other PolicyEngine services

## [0.12.0] - 2026-01-16 18:07:34

### Added

- Add GitHub Actions workflow for weekly policyengine-us updates with changelog summary generation.

## [0.11.9] - 2026-01-15 23:07:16

### Changed

- Update PolicyEngine US to 1.502.3

## [0.11.8] - 2025-12-30 00:06:02

### Changed

- Update PolicyEngine US to 1.485.0

## [0.11.7] - 2025-12-12 23:50:15

### Changed

- Update PolicyEngine US to 1.460.0

## [0.11.6] - 2025-12-09 00:51:17

### Changed

- Update PolicyEngine US to 1.452.0

## [0.11.5] - 2025-10-20 13:58:09

### Changed

- Update PolicyEngine US to 1.423.0

## [0.11.4] - 2025-10-10 21:03:26

### Changed

- Update PolicyEngine US to 1.413.0

## [0.11.3] - 2025-10-10 19:56:19

### Changed

- Migrated from pkg_resources to importlib for package management utilities.

## [0.11.2] - 2025-09-22 21:57:28

### Changed

- Update PolicyEngine US to 1.402.1

## [0.11.1] - 2025-09-16 16:31:57

### Changed

- Update PolicyEngine US to 1.398.1

## [0.11.0] - 2025-09-03 00:22:35

### Changed

- Fixed code that makes environment variables optional for auth0 configuration
- Fixed code that makes environment variables optional for analytics tracking configuration
- Made environment variables configurable for AI-powered endpoints

## [0.10.5] - 2025-09-02 23:43:07

### Changed

- Update PolicyEngine US to 1.389.0

## [0.10.4] - 2025-09-02 15:25:12

### Changed

- Update PolicyEngine US to 1.387.0

## [0.10.3] - 2025-09-01 13:53:12

### Changed

- Update PolicyEngine US to 1.386.0

## [0.10.2] - 2025-08-29 21:13:07

### Changed

- Update PolicyEngine US to 1.384.0

## [0.10.1] - 2025-08-29 01:24:00

### Changed

- Update PolicyEngine US to 1.380.0

## [0.10.0] - 2025-08-27 23:15:50

### Changed

- Decoupled auth0 setup logic from main app logic.
- Updated configuration structure to support new decoupled auth0 setup.

## [0.9.0] - 2025-08-27 02:21:05

### Added

- Capability to optionally opt into user analytics structure
- Reverse-compatible structure to allow us to deploy with user analytics enabled

## [0.8.0] - 2025-08-26 23:33:33

### Added

- Created config loader to load custom configuration files; this remains unused

## [0.7.22] - 2025-08-26 16:41:06

### Added

- First, unimplemented version of deploy config files

## [0.7.21] - 2025-08-22 18:04:20

### Added

- Production Docker image now deploys to both GitHub Container Registry and Google Artifact Registry

## [0.7.20] - 2025-08-21 14:43:24

### Changed

- Update PolicyEngine US to 1.375.0

## [0.7.19] - 2025-08-13 23:55:10

### Changed

- Update PolicyEngine US to 1.370.1

## [0.7.18] - 2025-08-13 00:59:30

## [0.7.17] - 2025-08-13 00:37:02

### Changed

- Replaced custom GCP deploy script with official Google action.
- Re-enabled itemized deductions to prevent UK service outage.

## [0.7.16] - 2025-08-12 20:20:34

### Changed

- Made various fixes to Dockerfile and GCP deployment scripts.

## [0.7.15] - 2025-08-12 15:44:48

### Changed

- Correct env var setup in deploy-production.yml

## [0.7.14] - 2025-08-12 15:26:20

### Changed

- Fixed launch tag syntax

## [0.7.13] - 2025-08-12 15:10:39

### Changed

- Fixed GCP deploy tag on Artifact Registry image

## [0.7.12] - 2025-08-12 14:54:59

### Changed

- Modified tag to launch from

## [0.7.11] - 2025-08-12 14:20:01

### Changed

- Change the default image tag to `latest` in the production deployment workflow.

## [0.7.10] - 2025-08-12 06:38:03

### Changed

- Various fixes to the deployment workflow.

## [0.7.9] - 2025-08-12 02:59:07

### Changed

- Added missing credentials to push workflow.

## [0.7.8] - 2025-08-12 02:51:19

### Changed

- Modified Docker deployment workflow to use pre-built image via multi-stage build.

## [0.7.7] - 2025-08-10 13:01:44

### Changed

- Switched to use of in-memory storage for rate limiting instead of Redis.

## [0.7.6] - 2025-08-07 17:25:33

### Changed

- Update PolicyEngine US to 1.330.0

## [0.7.5] - 2025-08-07 16:24:30

### Fixed

- No branching for itemization.
- Lower memory back to pre-change 8GB.

## [0.7.4] - 2025-08-07 00:13:08

### Changed

- Decreased memory from 16GB to 12GB.

## [0.7.3] - 2025-08-06 23:44:51

### Changed

- Allowed use of Python 3.12.
- Increased memory from 8GB to 16GB.

## [0.7.2] - 2025-08-06 19:58:12

### Changed

- Increased readiness check timeout to 600 seconds.

## [0.7.1] - 2025-08-02 18:39:28

### Changed

- Update Docker build address to use GitHub Container Registry

## [0.7.0] - 2025-07-30 22:49:16

### Changed

- Upgrade Python version requirement from 3.10 to 3.13

## [0.6.33] - 2025-06-30 19:41:23

### Changed

- Update PolicyEngine US to 1.328.0

## [0.6.32] - 2025-06-16 15:22:02

### Changed

- Update PolicyEngine US to 1.313.0

## [0.6.31] - 2025-06-09 22:07:29

### Changed

- Update PolicyEngine UK to 2.31.0

## [0.6.30] - 2025-06-05 21:25:41

### Changed

- Update PolicyEngine US to 1.305.0

## [0.6.29] - 2025-06-03 16:21:27

### Changed

- Update PolicyEngine US to 1.302.0

## [0.6.28] - 2025-06-02 15:57:45

### Changed

- Update PolicyEngine US to 1.300.0

## [0.6.27] - 2025-05-28 15:30:56

### Changed

- Update PolicyEngine US to 1.297.2

## [0.6.26] - 2025-05-27 15:28:37

### Changed

- Update PolicyEngine US to 1.295.0

## [0.6.25] - 2025-05-22 21:44:12

### Changed

- Update PolicyEngine US to 1.289.1

## [0.6.24] - 2025-05-20 19:51:14

### Changed

- Update PolicyEngine US to 1.287.0

## [0.6.23] - 2025-05-13 16:41:01

### Changed

- Update PolicyEngine US to 1.279.0

## [0.6.22] - 2025-05-12 15:28:58

### Changed

- Update PolicyEngine US to 1.270.2

## [0.6.21] - 2025-05-10 00:39:54

### Changed

- Update PolicyEngine US to 1.269.2

## [0.6.20] - 2025-05-05 20:48:14

### Changed

- Update PolicyEngine US to 1.265.0

## [0.6.19] - 2025-05-01 15:54:07

### Changed

- Update PolicyEngine US to 1.264.0

## [0.6.18] - 2025-04-21 21:05:19

### Changed

- Update PolicyEngine US to 1.254.0

## [0.6.17] - 2025-04-16 19:06:48

### Changed

- Update PolicyEngine UK to 2.24.0

## [0.6.16] - 2025-04-04 22:55:24

### Changed

- Update PolicyEngine US to 1.244.0

## [0.6.15] - 2025-04-01 22:48:01

### Changed

- Update PolicyEngine US to 1.240.1

## [0.6.14] - 2025-04-01 18:21:27

### Changed

- Update PolicyEngine US to 1.239.0

## [0.6.13] - 2025-03-27 01:53:25

### Changed

- Update PolicyEngine UK to 2.22.6

## [0.6.12] - 2025-03-26 01:10:31

### Changed

- Update PolicyEngine UK to 2.22.4

## [0.6.11] - 2025-03-26 01:09:47

### Added

- Re-enabled automated analytics logging of calculate endpoint

## [0.6.10] - 2025-03-20 18:10:01

### Changed

- Update PolicyEngine US to 1.221.0

## [0.6.9] - 2025-03-19 22:48:41

### Changed

- Update PolicyEngine US to 1.220.0

## [0.6.8] - 2025-03-12 23:12:22

### Changed

- Update PolicyEngine US to 1.212.0

## [0.6.7] - 2025-03-10 18:20:25

### Changed

- Update PolicyEngine US to 1.209.0

## [0.6.6] - 2025-03-07 19:22:43

### Added

- Impactica customer integration test

## [0.6.5] - 2025-03-07 12:05:04

### Changed

- Update PolicyEngine US to 1.207.3

## [0.6.4] - 2025-03-05 14:47:06

### Changed

- Update PolicyEngine US to 1.207.0

## [0.6.3] - 2025-03-04 20:47:56

### Changed

- Update PolicyEngine US to 1.205.0

## [0.6.2] - 2025-03-03 20:50:08

### Changed

- Update PolicyEngine UK to 2.22.0

## [0.6.1] - 2025-03-01 15:33:35

### Added

- Customer test for Benefits Navigator

### Changed

- Loosened schema requirements for US- and UK-specific entities
- Changed "year" to string-based "period" for filtering variables from household

## [0.6.0] - 2025-02-28 22:24:43

### Added

- AI explainer feature; users can now take a computation tree and generate a human-readable explanation of the computation of a particular variable
- Tools to flatten a nested household structure into an array of dictionaries mapping to each variable for a given year

### Changed

- Household computation now returns an (optional) computation tree alongside outputs

## [0.5.155] - 2025-02-28 20:50:46

### Added

- Tests for sample household objects from clients

## [0.5.154] - 2025-02-28 17:18:25

### Changed

- Update PolicyEngine UK to 2.21.0

## [0.5.153] - 2025-02-28 00:51:18

### Changed

- Update PolicyEngine US to 1.203.0

## [0.5.152] - 2025-02-26 13:49:03

### Changed

- Update PolicyEngine UK to 2.19.3

## [0.5.151] - 2025-02-24 23:55:42

### Changed

- Update PolicyEngine US to 1.202.2

## [0.5.150] - 2025-02-24 16:09:54

### Changed

- Update PolicyEngine US to 1.202.1

## [0.5.149] - 2025-02-21 17:42:43

### Changed

- Update PolicyEngine UK to 2.19.1

## [0.5.148] - 2025-02-20 22:38:46

### Changed

- Update PolicyEngine US to 1.202.0

## [0.5.147] - 2025-02-19 23:16:25

### Changed

- Update PolicyEngine US to 1.199.0

## [0.5.146] - 2025-02-19 00:09:59

### Changed

- Update PolicyEngine US to 1.198.0

## [0.5.145] - 2025-02-14 19:56:39

### Changed

- Update PolicyEngine US to 1.196.0

## [0.5.144] - 2025-02-13 22:02:29

### Changed

- Update PolicyEngine US to 1.195.1

## [0.5.143] - 2025-02-11 23:33:18

### Changed

- Update PolicyEngine UK to 2.18.0

## [0.5.142] - 2025-02-11 00:46:34

### Changed

- Update PolicyEngine US to 1.191.0

## [0.5.141] - 2025-02-07 14:03:04

### Changed

- Update PolicyEngine US to 1.189.0

## [0.5.140] - 2025-02-04 16:45:47

### Changed

- Update PolicyEngine US to 1.187.1

## [0.5.139] - 2025-02-04 14:56:46

### Changed

- Update PolicyEngine UK to 2.18.0

## [0.5.138] - 2025-01-31 17:02:58

### Changed

- Update PolicyEngine US to 1.186.0

## [0.5.137] - 2025-01-31 15:01:53

### Changed

- Update PolicyEngine US to 1.185.0

## [0.5.136] - 2025-01-30 15:18:32

### Changed

- Update PolicyEngine US to 1.184.0

## [0.5.135] - 2025-01-29 18:10:38

### Changed

- Update PolicyEngine US to 1.183.1

## [0.5.134] - 2025-01-28 16:26:26

### Changed

- Update PolicyEngine US to 1.182.2

## [0.5.133] - 2025-01-22 15:50:25

### Changed

- Update PolicyEngine US to 1.180.1

## [0.5.132] - 2025-01-21 11:01:14

### Changed

- Update PolicyEngine US to 1.179.0

## [0.5.131] - 2025-01-20 12:58:50

### Changed

- Update PolicyEngine US to 1.176.3

## [0.5.130] - 2025-01-17 14:55:32

### Changed

- Update PolicyEngine US to 1.176.0

## [0.5.129] - 2024-12-23 15:12:03

### Changed

- Update PolicyEngine US to 1.162.1

## [0.5.128] - 2024-12-16 19:11:28

### Changed

- Update PolicyEngine US to 1.161.2

## [0.5.127] - 2024-12-12 14:42:36

### Changed

- Update PolicyEngine US to 1.161.0

## [0.5.126] - 2024-12-05 19:13:55

### Changed

- Update PolicyEngine US to 1.160.0

## [0.5.125] - 2024-12-05 16:44:13

### Changed

- Update PolicyEngine UK to 2.18.0

## [0.5.124] - 2024-12-04 20:01:36

### Changed

- Updated version of policyengine-canada to 0.96.2

## [0.5.123] - 2024-11-28 17:22:06

### Changed

- Update PolicyEngine UK to 2.16.0

## [0.5.122] - 2024-11-25 23:51:56

### Changed

- Update PolicyEngine US to 1.153.0

## [0.5.121] - 2024-11-25 22:16:36

### Changed

- Update PolicyEngine US to 1.151.0

## [0.5.120] - 2024-11-21 12:58:13

### Changed

- Update PolicyEngine US to 1.150.0

## [0.5.119] - 2024-11-20 15:49:49

### Changed

- Update PolicyEngine US to 1.147.0

## [0.5.118] - 2024-11-19 22:15:41

### Changed

- Update PolicyEngine US to 1.146.2

## [0.5.117] - 2024-11-19 16:58:33

### Changed

- Update PolicyEngine US to 1.146.1

## [0.5.116] - 2024-11-19 14:18:00

### Changed

- Update PolicyEngine UK to 2.15.1

## [0.5.115] - 2024-11-18 19:48:17

### Changed

- Update PolicyEngine US to 1.145.0

## [0.5.114] - 2024-11-18 01:32:59

### Changed

- Update PolicyEngine US to 1.142.5

## [0.5.113] - 2024-11-11 14:53:56

### Changed

- Update PolicyEngine US to 1.140.1

## [0.5.112] - 2024-11-10 18:36:37

### Changed

- Update PolicyEngine US to 1.139.2

## [0.5.111] - 2024-11-07 17:24:35

### Changed

- Update PolicyEngine US to 1.139.0

## [0.5.110] - 2024-11-06 00:31:23

### Changed

- Update PolicyEngine US to 1.138.0

## [0.5.109] - 2024-11-05 21:29:18

### Changed

- Update PolicyEngine UK to 2.15.1

## [0.5.108] - 2024-11-04 13:45:16

### Changed

- Update PolicyEngine US to 1.137.4

## [0.5.107] - 2024-11-01 22:38:33

### Changed

- Update PolicyEngine US to 1.137.3

## [0.5.106] - 2024-10-30 23:44:11

### Changed

- Update PolicyEngine US to 1.137.0

## [0.5.105] - 2024-10-30 15:34:19

### Changed

- Update PolicyEngine UK to 2.14.1

## [0.5.104] - 2024-10-30 14:41:04

### Changed

- Update PolicyEngine UK to 2.14.1

## [0.5.103] - 2024-10-29 20:19:07

### Changed

- Update PolicyEngine US to 1.136.1

## [0.5.102] - 2024-10-29 15:55:28

### Changed

- Update PolicyEngine US to 1.136.0

## [0.5.101] - 2024-10-29 01:04:58

### Changed

- Update PolicyEngine US to 1.135.0

## [0.5.100] - 2024-10-28 14:48:23

### Changed

- Update PolicyEngine UK to 2.14.0

## [0.5.99] - 2024-10-27 22:48:57

### Changed

- Update PolicyEngine US to 1.133.0

## [0.5.98] - 2024-10-24 22:21:56

### Changed

- Update PolicyEngine UK to 2.13.1

## [0.5.97] - 2024-10-23 23:44:25

### Changed

- Update PolicyEngine US to 1.131.0

## [0.5.96] - 2024-10-23 15:23:02

### Changed

- Update PolicyEngine UK to 2.12.0

## [0.5.95] - 2024-10-22 16:18:38

### Changed

- Update PolicyEngine UK to 2.10.0

## [0.5.94] - 2024-10-21 22:33:58

### Changed

- Update PolicyEngine US to 1.129.3

## [0.5.93] - 2024-10-21 20:11:16

### Changed

- Update PolicyEngine US to 1.129.1

## [0.5.92] - 2024-10-21 15:41:08

### Changed

- Update PolicyEngine UK to 2.8.0

## [0.5.91] - 2024-10-18 13:59:16

### Changed

- Update PolicyEngine UK to 2.4.0

## [0.5.90] - 2024-10-17 20:27:39

### Changed

- Update PolicyEngine US to 1.129.0

## [0.5.89] - 2024-10-17 13:32:40

### Changed

- Update PolicyEngine UK to 2.3.0

## [0.5.88] - 2024-10-16 17:27:16

### Changed

- Update PolicyEngine UK to 2.2.0

## [0.5.87] - 2024-10-15 21:23:28

### Changed

- Update PolicyEngine US to 1.127.0

## [0.5.86] - 2024-10-15 18:43:48

### Changed

- Update PolicyEngine US to 1.124.0

## [0.5.85] - 2024-10-10 18:24:09

### Changed

- Update PolicyEngine US to 1.115.0

## [0.5.84] - 2024-10-08 17:20:37

### Changed

- Update PolicyEngine US to 1.112.0

## [0.5.83] - 2024-10-07 20:54:54

### Changed

- Update PolicyEngine US to 1.110.0

## [0.5.82] - 2024-10-07 12:52:28

### Changed

- Update PolicyEngine US to 1.109.0

## [0.5.81] - 2024-10-04 17:12:45

### Changed

- Update PolicyEngine US to 1.106.0

## [0.5.80] - 2024-10-01 12:58:28

### Changed

- Update PolicyEngine US to 1.105.1

## [0.5.79] - 2024-09-30 17:20:50

### Changed

- Update PolicyEngine US to 1.105.0

## [0.5.78] - 2024-09-20 16:40:33

### Changed

- Update PolicyEngine US to 1.85.4

## [0.5.77] - 2024-09-19 18:20:57

### Changed

- Update PolicyEngine US to 1.85.3

## [0.5.76] - 2024-09-19 16:02:51

### Changed

- Update PolicyEngine US to 1.85.0

## [0.5.75] - 2024-09-18 19:05:47

### Changed

- Update PolicyEngine US to 1.81.0

## [0.5.74] - 2024-09-18 13:34:34

### Changed

- Update PolicyEngine US to 1.80.1

## [0.5.73] - 2024-09-16 15:46:25

### Changed

- Update PolicyEngine UK to 1.8.0

## [0.5.72] - 2024-09-16 15:38:53

### Changed

- Update PolicyEngine US to 1.79.2

## [0.5.71] - 2024-09-06 21:52:40

### Changed

- Update PolicyEngine US to 1.75.1

## [0.5.70] - 2024-09-06 13:41:32

### Changed

- Update PolicyEngine US to 1.74.0

## [0.5.69] - 2024-09-05 12:59:00

### Changed

- Update PolicyEngine US to 1.72.1

## [0.5.68] - 2024-09-04 15:10:35

### Changed

- Update PolicyEngine US to 1.71.1.
- Update PolicyEngine Canada to 0.96.1.
- Update PolicyEngine UK to 1.7.3.

## [0.5.67] - 2024-09-02 12:50:41

### Changed

- Update PolicyEngine US to 1.69.0

## [0.5.66] - 2024-08-31 20:49:49

### Changed

- Update PolicyEngine US to 1.67.0

## [0.5.65] - 2024-08-31 17:16:16

### Changed

- Update PolicyEngine US to 1.66.0

## [0.5.64] - 2024-08-30 12:59:42

### Changed

- Update PolicyEngine US to 1.65.1

## [0.5.63] - 2024-08-29 16:40:55

### Changed

- Update PolicyEngine US to 1.64.0

## [0.5.62] - 2024-08-28 23:39:44

### Changed

- Update PolicyEngine US to 1.63.0

## [0.5.61] - 2024-08-26 12:02:00

### Changed

- Update PolicyEngine US to 1.61.1

## [0.5.60] - 2024-08-23 18:50:39

### Changed

- Update PolicyEngine US to 1.61.0

## [0.5.59] - 2024-08-23 01:51:37

### Changed

- Update PolicyEngine UK to 1.7.1

## [0.5.58] - 2024-08-23 01:25:42

### Changed

- Update PolicyEngine US to 1.60.0

## [0.5.57] - 2024-08-23 00:08:38

### Changed

- Removed empty ENV call in Dockerfile

## [0.5.56] - 2024-08-22 20:15:08

### Changed

- Updated GCP Dockerfile to properly support launching off of start.sh

## [0.5.55] - 2024-08-22 04:20:11

### Fixed

- Updated Docker image path

## [0.5.54] - 2024-08-22 04:10:32

### Changed

- Update to Python 3.10
- Updated policyengine-us version
- Updated policyengine-uk version

## [0.5.53] - 2024-08-12 22:51:20

### Changed

- Update PolicyEngine UK to 1.5.1

## [0.5.52] - 2024-08-08 18:45:10

### Changed

- Update PolicyEngine US to 1.44.0

## [0.5.51] - 2024-08-06 23:55:38

### Changed

- Update PolicyEngine US to 1.43.1

## [0.5.50] - 2024-08-02 19:27:31

### Changed

- Update PolicyEngine US to 1.40.0

## [0.5.49] - 2024-08-01 20:12:26

### Changed

- Update PolicyEngine US to 1.38.0

## [0.5.48] - 2024-07-31 18:59:37

### Changed

- Update PolicyEngine US to 1.35.0

## [0.5.47] - 2024-07-30 23:51:58

### Changed

- Update PolicyEngine US to 1.34.7

## [0.5.46] - 2024-07-30 19:33:38

### Changed

- Update PolicyEngine UK to 1.4.0

## [0.5.45] - 2024-07-30 19:20:05

### Changed

- Update PolicyEngine US to 1.34.5

## [0.5.44] - 2024-07-29 22:10:58

### Changed

- Update PolicyEngine UK to 1.2.0

## [0.5.43] - 2024-07-26 21:02:47

### Changed

- Update PolicyEngine US to 1.34.1

## [0.5.42] - 2024-07-26 20:49:29

### Changed

- Update PolicyEngine UK to 1.1.0

## [0.5.41] - 2024-07-26 02:55:35

### Changed

- Update PolicyEngine US to 1.34.0

## [0.5.40] - 2024-07-22 21:54:20

### Changed

- Update PolicyEngine US to 1.26.2

## [0.5.39] - 2024-07-22 19:26:11

### Changed

- Update PolicyEngine US to 1.26.1

## [0.5.38] - 2024-07-18 20:22:20

### Changed

- Update PolicyEngine US to 1.22.1

## [0.5.37] - 2024-07-17 19:04:36

### Changed

- Update PolicyEngine UK to 0.86.6

## [0.5.36] - 2024-07-14 23:04:25

### Fixed

- Updated policyengine-uk to 0.86.3

## [0.5.35] - 2024-07-14 22:53:56

### Changed

- Update PolicyEngine US to 1.21.0

## [0.5.34] - 2024-07-14 22:46:55

### Fixed

- Allow GitHub Actions to use earlier version of glibc

## [0.5.33] - 2024-07-04 22:43:09

### Changed

- Update PolicyEngine US to 1.13.0

## [0.5.32] - 2024-07-02 18:00:23

### Changed

- Update PolicyEngine US to 1.10.0

## [0.5.31] - 2024-07-02 16:57:32

### Changed

- Update PolicyEngine US to 1.8.0

## [0.5.30] - 2024-07-01 21:37:02

### Changed

- Update PolicyEngine US to 1.5.1

## [0.5.29] - 2024-07-01 20:19:02

### Changed

- Update PolicyEngine US to 1.5.0

## [0.5.28] - 2024-06-28 17:40:12

### Changed

- Update PolicyEngine US to 1.4.0

## [0.5.27] - 2024-06-28 00:54:27

### Changed

- Update PolicyEngine US to 1.3.0

## [0.5.26] - 2024-06-26 18:30:23

### Changed

- Update PolicyEngine US to 1.1.0

## [0.5.25] - 2024-06-25 15:21:55

### Changed

- Update PolicyEngine US to 0.796.0

## [0.5.24] - 2024-06-21 19:36:42

### Changed

- Update PolicyEngine US to 0.794.2

## [0.5.23] - 2024-06-20 14:49:25

### Changed

- Update PolicyEngine US to 0.792.0

## [0.5.22] - 2024-06-19 14:16:30

### Changed

- Update PolicyEngine US to 0.790.0

## [0.5.21] - 2024-06-14 20:37:53

### Changed

- Update PolicyEngine US to 0.789.0

## [0.5.20] - 2024-06-13 17:21:10

### Changed

- Updated authlib version

## [0.5.19] - 2024-06-13 16:57:12

### Changed

- Update PolicyEngine US to 0.788.0

## [0.5.18] - 2024-06-11 15:45:30

### Changed

- Update PolicyEngine US to 0.786.0

## [0.5.17] - 2024-06-11 14:56:37

### Changed

- Update PolicyEngine US to 0.785.2

## [0.5.16] - 2024-06-10 19:50:12

### Changed

- Update PolicyEngine US to 0.785.0

## [0.5.15] - 2024-06-10 13:32:46

### Changed

- Update PolicyEngine US to 0.783.0

## [0.5.14] - 2024-06-07 21:15:22

### Changed

- Update PolicyEngine US to 0.782.0

## [0.5.13] - 2024-06-07 16:42:50

### Changed

- Update PolicyEngine US to 0.781.0

## [0.5.12] - 2024-06-07 13:31:33

### Changed

- Update PolicyEngine US to 0.780.1

## [0.5.11] - 2024-06-06 18:08:41

### Changed

- Update PolicyEngine US to 0.780.0

## [0.5.10] - 2024-06-04 21:27:23

### Changed

- Update PolicyEngine US to 0.779.2

## [0.5.9] - 2024-05-30 14:12:58

### Changed

- Update PolicyEngine US to 0.777.7

## [0.5.8] - 2024-05-29 14:03:00

### Changed

- Update PolicyEngine US to 0.777.6

## [0.5.7] - 2024-05-24 15:12:36

### Changed

- Update PolicyEngine US to 0.777.4

## [0.5.6] - 2024-05-24 14:37:24

### Changed

- Update PolicyEngine US to 0.777.3

## [0.5.5] - 2024-05-22 20:32:02

### Changed

- Fixed main branch reference in bump_country_package

## [0.5.4] - 2024-05-13 16:23:57

### Changed

- Upgraded black to v. 24.3.0
- Upgraded policyengine-canada to v. 0.95.0
- Upgraded policyengine-uk to v. 0.74.1
- Upgraded policyengine-us to v. 0.754.0

## [0.5.3] - 2024-02-02 21:49:10

### Changed

- Prevented strange version increase for policyengine-ng

## [0.5.2] - 2024-02-02 20:47:10

### Changed

- Added calculate_demo endpoint for use on API documentation page

## [0.5.1] - 2024-02-02 16:57:55

### Changed

- Removed the '@clients' parameter from the client_id portion of the JWT

## [0.5.0] - 2024-01-25 23:27:28

### Added

- Fix environment variables

## [0.4.0] - 2024-01-25 23:10:35

### Added

- User analytics tracking

## [0.3.10] - 2024-01-25 22:35:48

### Changed

- Fix Black version

## [0.3.9] - 2024-01-22 20:36:31

### Changed

- Update README and home page to reflect proper name

## [0.3.8] - 2024-01-22 19:16:47

### Changed

- Properly updated GCP service account address

## [0.3.7] - 2024-01-22 18:46:37

### Changed

- Updated GCP service account name

## [0.3.6] - 2024-01-15 21:51:07

### Changed

- Fixed GCP app folder name

## [0.3.5] - 2024-01-15 21:47:09

### Changed

- Correct repo name and updated references (except GCP)

## [0.3.4] - 2024-01-06 23:24:52

### Changed

- Corrected environment variables to correspond with different auth0 tenant

## [0.3.3] - 2024-01-03 18:54:18

### Added

- Added tests for malformed and missing auth tokens

## [0.3.2] - 2024-01-03 17:52:46

## [0.3.1] - 2024-01-03 03:14:38

### Changed

- Moved auth protection to main API file

## [0.3.0] - 2024-01-03 02:30:44

### Added

- Added authentication via auth0

## [0.2.8] - 2023-12-21 21:38:11

## [0.2.7] - 2023-12-21 20:51:01

### Changed

- Changed urllib3 specification to accord with policyengine-core

## [0.2.6] - 2023-12-21 20:41:57

### Changed

- Corrected import for urllib3

## [0.2.5] - 2023-12-21 20:34:42

## [0.2.4] - 2023-12-21 20:17:34

### Changed

- Updated Dockerfile address

## [0.2.3] - 2023-12-21 19:37:10

### Changed

- Repo address now lowercase

## [0.2.2] - 2023-12-21 19:33:02

### Changed

- Changing text to redeploy

## [0.2.1] - 2023-12-21 19:29:40

### Changed

- Pointed Dockerfile toward correct target

## [0.2.0] - 2023-12-21 17:17:09

### Added

- First version deployment ready.

## [0.1.9] - 2023-12-21 04:50:12

### Changed

- Added tests to ensure API-light in sync with API

## [0.1.8] - 2023-12-21 02:25:10

### Changed

- Re-enabled local testing in GitHub Actions

## [0.1.7] - 2023-12-21 02:18:35

### Changed

- Removed deprecated tests

## [0.1.6] - 2023-12-21 02:02:43

### Changed

- Removed deprecated economy, metadata, and policy folders

## [0.1.5] - 2023-12-20 23:33:36

### Changed

- Removed unused code portions

## [0.1.4] - 2023-12-19 21:26:41

### Changed

- Temporarily disabled GCP deployment

## [0.1.3] - 2023-12-19 16:47:18

### Added

- Changelog update.

## [0.1.2] - 2023-12-18 18:22:16

### Changed

- Manually added last changelog entries

## [0.1.1] - 2023-12-18 18:04:42

### Changed

- Change links to re-enable changelog building

## [0.1.0] - 2023-12-14 00:00:00

### Added

- Initial API.



[0.13.15]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.14...0.13.15
[0.13.14]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.13...0.13.14
[0.13.13]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.12...0.13.13
[0.13.12]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.11...0.13.12
[0.13.11]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.10...0.13.11
[0.13.10]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.9...0.13.10
[0.13.9]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.8...0.13.9
[0.13.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.7...0.13.8
[0.13.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.6...0.13.7
[0.13.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.5...0.13.6
[0.13.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.4...0.13.5
[0.13.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.3...0.13.4
[0.13.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.2...0.13.3
[0.13.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.1...0.13.2
[0.13.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.13.0...0.13.1
[0.13.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.12.0...0.13.0
[0.12.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.9...0.12.0
[0.11.9]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.8...0.11.9
[0.11.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.7...0.11.8
[0.11.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.6...0.11.7
[0.11.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.5...0.11.6
[0.11.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.4...0.11.5
[0.11.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.3...0.11.4
[0.11.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.2...0.11.3
[0.11.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.1...0.11.2
[0.11.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.11.0...0.11.1
[0.11.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.10.5...0.11.0
[0.10.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.10.4...0.10.5
[0.10.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.10.3...0.10.4
[0.10.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.10.2...0.10.3
[0.10.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.10.1...0.10.2
[0.10.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.10.0...0.10.1
[0.10.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.9.0...0.10.0
[0.9.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.8.0...0.9.0
[0.8.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.22...0.8.0
[0.7.22]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.21...0.7.22
[0.7.21]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.20...0.7.21
[0.7.20]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.19...0.7.20
[0.7.19]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.18...0.7.19
[0.7.18]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.17...0.7.18
[0.7.17]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.16...0.7.17
[0.7.16]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.15...0.7.16
[0.7.15]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.14...0.7.15
[0.7.14]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.13...0.7.14
[0.7.13]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.12...0.7.13
[0.7.12]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.11...0.7.12
[0.7.11]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.10...0.7.11
[0.7.10]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.9...0.7.10
[0.7.9]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.8...0.7.9
[0.7.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.7...0.7.8
[0.7.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.6...0.7.7
[0.7.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.5...0.7.6
[0.7.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.4...0.7.5
[0.7.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.3...0.7.4
[0.7.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.2...0.7.3
[0.7.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.1...0.7.2
[0.7.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.7.0...0.7.1
[0.7.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.33...0.7.0
[0.6.33]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.32...0.6.33
[0.6.32]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.31...0.6.32
[0.6.31]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.30...0.6.31
[0.6.30]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.29...0.6.30
[0.6.29]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.28...0.6.29
[0.6.28]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.27...0.6.28
[0.6.27]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.26...0.6.27
[0.6.26]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.25...0.6.26
[0.6.25]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.24...0.6.25
[0.6.24]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.23...0.6.24
[0.6.23]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.22...0.6.23
[0.6.22]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.21...0.6.22
[0.6.21]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.20...0.6.21
[0.6.20]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.19...0.6.20
[0.6.19]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.18...0.6.19
[0.6.18]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.17...0.6.18
[0.6.17]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.16...0.6.17
[0.6.16]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.15...0.6.16
[0.6.15]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.14...0.6.15
[0.6.14]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.13...0.6.14
[0.6.13]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.12...0.6.13
[0.6.12]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.11...0.6.12
[0.6.11]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.10...0.6.11
[0.6.10]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.9...0.6.10
[0.6.9]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.8...0.6.9
[0.6.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.7...0.6.8
[0.6.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.6...0.6.7
[0.6.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.5...0.6.6
[0.6.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.4...0.6.5
[0.6.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.3...0.6.4
[0.6.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.2...0.6.3
[0.6.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.1...0.6.2
[0.6.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.6.0...0.6.1
[0.6.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.155...0.6.0
[0.5.155]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.154...0.5.155
[0.5.154]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.153...0.5.154
[0.5.153]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.152...0.5.153
[0.5.152]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.151...0.5.152
[0.5.151]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.150...0.5.151
[0.5.150]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.149...0.5.150
[0.5.149]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.148...0.5.149
[0.5.148]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.147...0.5.148
[0.5.147]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.146...0.5.147
[0.5.146]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.145...0.5.146
[0.5.145]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.144...0.5.145
[0.5.144]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.143...0.5.144
[0.5.143]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.142...0.5.143
[0.5.142]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.141...0.5.142
[0.5.141]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.140...0.5.141
[0.5.140]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.139...0.5.140
[0.5.139]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.138...0.5.139
[0.5.138]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.137...0.5.138
[0.5.137]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.136...0.5.137
[0.5.136]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.135...0.5.136
[0.5.135]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.134...0.5.135
[0.5.134]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.133...0.5.134
[0.5.133]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.132...0.5.133
[0.5.132]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.131...0.5.132
[0.5.131]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.130...0.5.131
[0.5.130]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.129...0.5.130
[0.5.129]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.128...0.5.129
[0.5.128]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.127...0.5.128
[0.5.127]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.126...0.5.127
[0.5.126]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.125...0.5.126
[0.5.125]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.124...0.5.125
[0.5.124]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.123...0.5.124
[0.5.123]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.122...0.5.123
[0.5.122]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.121...0.5.122
[0.5.121]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.120...0.5.121
[0.5.120]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.119...0.5.120
[0.5.119]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.118...0.5.119
[0.5.118]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.117...0.5.118
[0.5.117]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.116...0.5.117
[0.5.116]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.115...0.5.116
[0.5.115]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.114...0.5.115
[0.5.114]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.113...0.5.114
[0.5.113]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.112...0.5.113
[0.5.112]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.111...0.5.112
[0.5.111]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.110...0.5.111
[0.5.110]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.109...0.5.110
[0.5.109]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.108...0.5.109
[0.5.108]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.107...0.5.108
[0.5.107]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.106...0.5.107
[0.5.106]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.105...0.5.106
[0.5.105]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.104...0.5.105
[0.5.104]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.103...0.5.104
[0.5.103]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.102...0.5.103
[0.5.102]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.101...0.5.102
[0.5.101]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.100...0.5.101
[0.5.100]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.99...0.5.100
[0.5.99]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.98...0.5.99
[0.5.98]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.97...0.5.98
[0.5.97]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.96...0.5.97
[0.5.96]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.95...0.5.96
[0.5.95]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.94...0.5.95
[0.5.94]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.93...0.5.94
[0.5.93]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.92...0.5.93
[0.5.92]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.91...0.5.92
[0.5.91]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.90...0.5.91
[0.5.90]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.89...0.5.90
[0.5.89]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.88...0.5.89
[0.5.88]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.87...0.5.88
[0.5.87]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.86...0.5.87
[0.5.86]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.85...0.5.86
[0.5.85]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.84...0.5.85
[0.5.84]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.83...0.5.84
[0.5.83]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.82...0.5.83
[0.5.82]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.81...0.5.82
[0.5.81]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.80...0.5.81
[0.5.80]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.79...0.5.80
[0.5.79]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.78...0.5.79
[0.5.78]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.77...0.5.78
[0.5.77]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.76...0.5.77
[0.5.76]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.75...0.5.76
[0.5.75]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.74...0.5.75
[0.5.74]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.73...0.5.74
[0.5.73]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.72...0.5.73
[0.5.72]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.71...0.5.72
[0.5.71]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.70...0.5.71
[0.5.70]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.69...0.5.70
[0.5.69]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.68...0.5.69
[0.5.68]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.67...0.5.68
[0.5.67]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.66...0.5.67
[0.5.66]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.65...0.5.66
[0.5.65]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.64...0.5.65
[0.5.64]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.63...0.5.64
[0.5.63]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.62...0.5.63
[0.5.62]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.61...0.5.62
[0.5.61]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.60...0.5.61
[0.5.60]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.59...0.5.60
[0.5.59]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.58...0.5.59
[0.5.58]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.57...0.5.58
[0.5.57]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.56...0.5.57
[0.5.56]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.55...0.5.56
[0.5.55]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.54...0.5.55
[0.5.54]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.53...0.5.54
[0.5.53]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.52...0.5.53
[0.5.52]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.51...0.5.52
[0.5.51]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.50...0.5.51
[0.5.50]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.49...0.5.50
[0.5.49]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.48...0.5.49
[0.5.48]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.47...0.5.48
[0.5.47]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.46...0.5.47
[0.5.46]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.45...0.5.46
[0.5.45]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.44...0.5.45
[0.5.44]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.43...0.5.44
[0.5.43]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.42...0.5.43
[0.5.42]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.41...0.5.42
[0.5.41]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.40...0.5.41
[0.5.40]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.39...0.5.40
[0.5.39]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.38...0.5.39
[0.5.38]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.37...0.5.38
[0.5.37]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.36...0.5.37
[0.5.36]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.35...0.5.36
[0.5.35]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.34...0.5.35
[0.5.34]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.33...0.5.34
[0.5.33]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.32...0.5.33
[0.5.32]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.31...0.5.32
[0.5.31]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.30...0.5.31
[0.5.30]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.29...0.5.30
[0.5.29]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.28...0.5.29
[0.5.28]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.27...0.5.28
[0.5.27]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.26...0.5.27
[0.5.26]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.25...0.5.26
[0.5.25]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.24...0.5.25
[0.5.24]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.23...0.5.24
[0.5.23]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.22...0.5.23
[0.5.22]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.21...0.5.22
[0.5.21]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.20...0.5.21
[0.5.20]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.19...0.5.20
[0.5.19]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.18...0.5.19
[0.5.18]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.17...0.5.18
[0.5.17]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.16...0.5.17
[0.5.16]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.15...0.5.16
[0.5.15]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.14...0.5.15
[0.5.14]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.13...0.5.14
[0.5.13]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.12...0.5.13
[0.5.12]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.11...0.5.12
[0.5.11]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.10...0.5.11
[0.5.10]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.9...0.5.10
[0.5.9]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.8...0.5.9
[0.5.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.7...0.5.8
[0.5.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.6...0.5.7
[0.5.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.5...0.5.6
[0.5.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.4...0.5.5
[0.5.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.3...0.5.4
[0.5.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.2...0.5.3
[0.5.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.1...0.5.2
[0.5.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.5.0...0.5.1
[0.5.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.4.0...0.5.0
[0.4.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.10...0.4.0
[0.3.10]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.9...0.3.10
[0.3.9]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.8...0.3.9
[0.3.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.7...0.3.8
[0.3.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.6...0.3.7
[0.3.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.5...0.3.6
[0.3.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.4...0.3.5
[0.3.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.3...0.3.4
[0.3.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.2...0.3.3
[0.3.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.1...0.3.2
[0.3.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.3.0...0.3.1
[0.3.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.8...0.3.0
[0.2.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.7...0.2.8
[0.2.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.6...0.2.7
[0.2.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.5...0.2.6
[0.2.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.4...0.2.5
[0.2.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.3...0.2.4
[0.2.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.2...0.2.3
[0.2.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.1...0.2.2
[0.2.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.2.0...0.2.1
[0.2.0]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.9...0.2.0
[0.1.9]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.8...0.1.9
[0.1.8]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.7...0.1.8
[0.1.7]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.6...0.1.7
[0.1.6]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.5...0.1.6
[0.1.5]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.4...0.1.5
[0.1.4]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.3...0.1.4
[0.1.3]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.2...0.1.3
[0.1.2]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.1...0.1.2
[0.1.1]: https://github.com/PolicyEngine/policyengine-household-api/compare/0.1.0...0.1.1
