# Lutflow MCP Server

**The first AI FinOps tool with native MCP support.**

Works inside Cursor, Claude Code, VS Code, and any MCP-compatible client.

## Installation

```bash
pip install lutflow-mcp
```

Or install from source:

```bash
cd mcp-server
pip install -e .
```

## Configuration

### For Cursor

Add to your `~/.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "lutflow": {
      "command": "lutflow-mcp",
      "env": {
        "LUTFLOW_API_KEY": "lut_xxx",
        "LUTFLOW_TENANT_ID": "your-tenant"
      }
    }
  }
}
```

### For Claude Desktop

Add to your Claude Desktop config:

```json
{
  "mcpServers": {
    "lutflow": {
      "command": "lutflow-mcp",
      "env": {
        "LUTFLOW_API_KEY": "lut_xxx"
      }
    }
  }
}
```

## Available Tools

### 1. `check_budget`

Check current budget status for a tenant.

```
check_budget(tenant_id="acme")
```

Returns: budget limit, spent amount, remaining budget, utilization percentage.

### 2. `list_deployments`

List all active AI model deployments.

```
list_deployments(tenant_id="acme")
```

Returns: deployment IDs, models, costs, status, kill path state.

### 3. `get_costs`

Get detailed cost breakdown by model and deployment.

```
get_costs(period="today")
get_costs(deployment_id="abc-123", period="week")
```

Returns: total spend, per-model costs, billing event count.

### 4. `kill_deployment`

Manually terminate an AI model deployment.

```
kill_deployment(deployment_id="abc-123", reason="overspend")
```

Triggers the Lutflow kill path (eBPF → Tetragon → kubectl fallback).

### 5. `recommend_model`

Get AI model recommendation for a task within budget.

```
recommend_model(task="text-classification", budget_usd_per_hour=0.50)
recommend_model(task="code-generation", gpu_type="nvidia-a100-80gb")
```

Uses live HuggingFace benchmark data and real-time GPU pricing.

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `LUTFLOW_API_KEY` | API key for Lutflow Cloud | None (offline mode) |
| `LUTFLOW_ENDPOINT` | API endpoint | `https://api.lutflow.dev` |
| `LUTFLOW_TENANT_ID` | Default tenant ID | `default` |

## Offline Mode

When the Lutflow API is unreachable, the MCP server operates in offline mode:

- `check_budget` returns default/cached values
- `list_deployments` returns empty list
- `get_costs` returns zero costs
- `kill_deployment` cannot confirm termination
- `recommend_model` uses cached recommendations

All responses in offline mode are clearly labeled `[OFFLINE MODE]`.

## Example Usage in Cursor

Once configured, you can ask Claude:

> "Check my AI budget status"

> "List all my active deployments"

> "How much did I spend on GPT-4 today?"

> "Kill deployment abc-123 — it's overspending"

> "Recommend a model for text classification under $0.50/hr"

## Links

- **Website**: [lutflow.dev](https://lutflow.dev)
- **SDK**: [pypi.org/project/lutflow](https://pypi.org/project/lutflow/)
- **GitHub**: [github.com/Lutflow/lutflow](https://github.com/Lutflow/lutflow)

## License

Business Source License 1.1 (BSL 1.1)
