"""
Lutflow MCP Server — AI FinOps tools for IDEs.

The first AI FinOps tool with native MCP support.
Works inside Cursor, Claude Code, VS Code, and any MCP-compatible client.
"""

__version__ = "0.1.0"
