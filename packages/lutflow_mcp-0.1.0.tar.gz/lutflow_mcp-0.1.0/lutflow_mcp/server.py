"""
Lutflow MCP Server — AI FinOps tools for IDEs.

Exposes 5 tools:
1. check_budget - Check current budget status for a tenant
2. list_deployments - List active deployments with costs
3. get_costs - Get cost breakdown by model/deployment
4. kill_deployment - Terminate a deployment (manual kill path)
5. recommend_model - Get model recommendation for task/budget

Usage:
    # Run as stdio server (for MCP clients)
    lutflow-mcp

    # Or with Python
    python -m lutflow_mcp.server

Environment variables:
    LUTFLOW_API_KEY - API key for Lutflow Cloud (optional for local mode)
    LUTFLOW_ENDPOINT - API endpoint (default: https://api.lutflow.dev)
    LUTFLOW_TENANT_ID - Default tenant ID
"""

import asyncio
import os
import sys
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
)
from pydantic import BaseModel

DEFAULT_ENDPOINT = "https://api.lutflow.dev"


class LutflowClient:
    """HTTP client for Lutflow API."""

    def __init__(
        self,
        api_key: str | None = None,
        endpoint: str | None = None,
        tenant_id: str | None = None,
    ):
        self.api_key = api_key or os.getenv("LUTFLOW_API_KEY")
        self.endpoint = endpoint or os.getenv("LUTFLOW_ENDPOINT", DEFAULT_ENDPOINT)
        self.tenant_id = tenant_id or os.getenv("LUTFLOW_TENANT_ID", "default")
        self._client = httpx.AsyncClient(
            base_url=self.endpoint,
            timeout=30.0,
            headers=self._build_headers(),
        )

    def _build_headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    async def check_budget(self, tenant_id: str | None = None) -> dict[str, Any]:
        """Get budget status for a tenant."""
        tid = tenant_id or self.tenant_id
        try:
            r = await self._client.get(f"/api/v1/budget/status?tenant_id={tid}")
            if r.status_code == 200:
                return r.json()
            return {
                "error": f"API returned {r.status_code}",
                "offline_mode": True,
                "tenant_id": tid,
                "budget_usd": 0,
                "spent_usd": 0,
                "remaining_usd": 0,
                "utilization_percent": 0,
            }
        except httpx.RequestError:
            return {
                "offline_mode": True,
                "tenant_id": tid,
                "budget_usd": 0,
                "spent_usd": 0,
                "remaining_usd": 0,
                "utilization_percent": 0,
                "message": "API unreachable — running in offline mode",
            }

    async def list_deployments(self, tenant_id: str | None = None) -> dict[str, Any]:
        """List active deployments for a tenant."""
        tid = tenant_id or self.tenant_id
        try:
            r = await self._client.get(f"/api/v1/deployments?tenant_id={tid}")
            if r.status_code == 200:
                return r.json()
            return {"deployments": [], "offline_mode": True}
        except httpx.RequestError:
            return {
                "deployments": [],
                "offline_mode": True,
                "message": "API unreachable — running in offline mode",
            }

    async def get_costs(
        self,
        tenant_id: str | None = None,
        deployment_id: str | None = None,
        period: str = "today",
    ) -> dict[str, Any]:
        """Get cost breakdown."""
        tid = tenant_id or self.tenant_id
        params = {"tenant_id": tid, "period": period}
        if deployment_id:
            params["deployment_id"] = deployment_id
        try:
            r = await self._client.get("/api/v1/billing/events", params=params)
            if r.status_code == 200:
                data = r.json()
                events = data.get("events", [])
                total = sum(e.get("cost_usd", 0) for e in events)
                by_model: dict[str, float] = {}
                for e in events:
                    model = e.get("model_id", "unknown")
                    by_model[model] = by_model.get(model, 0) + e.get("cost_usd", 0)
                return {
                    "total_cost_usd": total,
                    "by_model": by_model,
                    "event_count": len(events),
                    "period": period,
                }
            return {"total_cost_usd": 0, "by_model": {}, "offline_mode": True}
        except httpx.RequestError:
            return {
                "total_cost_usd": 0,
                "by_model": {},
                "offline_mode": True,
                "message": "API unreachable — running in offline mode",
            }

    async def kill_deployment(
        self, deployment_id: str, reason: str = "manual"
    ) -> dict[str, Any]:
        """Terminate a deployment."""
        try:
            r = await self._client.delete(
                f"/api/v1/deployments/{deployment_id}",
                json={"reason": reason},
            )
            if r.status_code in (200, 204):
                return {
                    "success": True,
                    "deployment_id": deployment_id,
                    "reason": reason,
                    "message": f"Deployment {deployment_id} terminated",
                }
            return {
                "success": False,
                "deployment_id": deployment_id,
                "error": f"API returned {r.status_code}",
            }
        except httpx.RequestError:
            return {
                "success": False,
                "deployment_id": deployment_id,
                "offline_mode": True,
                "message": "API unreachable — cannot confirm kill",
            }

    async def recommend_model(
        self,
        task: str,
        budget_usd_per_hour: float = 1.0,
        gpu_type: str = "nvidia-l4",
    ) -> dict[str, Any]:
        """Get model recommendation for a task and budget."""
        try:
            r = await self._client.post(
                "/api/v1/agent/recommend",
                json={
                    "task": task,
                    "budget_usd_per_hour": budget_usd_per_hour,
                    "gpu_type": gpu_type,
                },
            )
            if r.status_code == 200:
                return r.json()
            return self._fallback_recommendation(task, budget_usd_per_hour, gpu_type)
        except httpx.RequestError:
            return self._fallback_recommendation(task, budget_usd_per_hour, gpu_type)

    def _fallback_recommendation(
        self, task: str, budget: float, gpu: str
    ) -> dict[str, Any]:
        """Provide cached recommendations when API is unavailable."""
        recommendations = {
            "text-classification": {
                "model": "microsoft/deberta-v3-base",
                "score": 0.91,
                "vram_gb": 1.2,
                "cost_per_hour": 0.35,
            },
            "tabular-classification": {
                "model": "autogluon/tabpfn-v2",
                "score": 0.89,
                "vram_gb": 2.0,
                "cost_per_hour": 0.35,
            },
            "code-generation": {
                "model": "Qwen/Qwen2.5-Coder-7B-Instruct",
                "score": 0.85,
                "vram_gb": 14.0,
                "cost_per_hour": 0.80,
            },
            "chat": {
                "model": "meta-llama/Llama-3.1-8B-Instruct",
                "score": 0.82,
                "vram_gb": 16.0,
                "cost_per_hour": 0.80,
            },
        }
        task_key = task.lower().replace(" ", "-")
        rec = recommendations.get(task_key, recommendations["chat"])
        return {
            "recommendation": rec["model"],
            "score": rec["score"],
            "vram_gb": rec["vram_gb"],
            "cost_per_hour": rec["cost_per_hour"],
            "provider": "vastai",
            "gpu_type": gpu,
            "budget_remaining": budget - rec["cost_per_hour"],
            "source": "cached",
            "offline_mode": True,
            "message": "Using cached recommendations — connect to Lutflow Cloud for live data",
        }

    async def close(self):
        await self._client.aclose()


# MCP Server instance
server = Server("lutflow-mcp")
client: LutflowClient | None = None


def get_client() -> LutflowClient:
    global client
    if client is None:
        client = LutflowClient()
    return client


@server.list_tools()
async def list_tools() -> list[Tool]:
    """Return the list of available tools."""
    return [
        Tool(
            name="check_budget",
            description="Check current budget status for a tenant. Returns budget limit, spent amount, remaining budget, and utilization percentage.",
            inputSchema={
                "type": "object",
                "properties": {
                    "tenant_id": {
                        "type": "string",
                        "description": "Tenant ID to check (optional, uses default if not provided)",
                    },
                },
            },
        ),
        Tool(
            name="list_deployments",
            description="List all active AI model deployments with their current costs and status. Shows model ID, budget, current spend, and kill path status.",
            inputSchema={
                "type": "object",
                "properties": {
                    "tenant_id": {
                        "type": "string",
                        "description": "Tenant ID to list deployments for (optional)",
                    },
                },
            },
        ),
        Tool(
            name="get_costs",
            description="Get detailed cost breakdown by model and deployment. Shows total spend, per-model costs, and billing event count.",
            inputSchema={
                "type": "object",
                "properties": {
                    "tenant_id": {
                        "type": "string",
                        "description": "Tenant ID (optional)",
                    },
                    "deployment_id": {
                        "type": "string",
                        "description": "Filter by specific deployment ID (optional)",
                    },
                    "period": {
                        "type": "string",
                        "description": "Time period: 'today', 'week', 'month' (default: today)",
                        "enum": ["today", "week", "month"],
                    },
                },
            },
        ),
        Tool(
            name="kill_deployment",
            description="Manually terminate an AI model deployment. Use when a deployment is overspending or needs to be stopped immediately. Triggers the Lutflow kill path (eBPF/Tetragon/kubectl).",
            inputSchema={
                "type": "object",
                "properties": {
                    "deployment_id": {
                        "type": "string",
                        "description": "ID of the deployment to terminate",
                    },
                    "reason": {
                        "type": "string",
                        "description": "Reason for termination (e.g., 'overspend', 'manual', 'budget_exceeded')",
                    },
                },
                "required": ["deployment_id"],
            },
        ),
        Tool(
            name="recommend_model",
            description="Get AI model recommendation for a specific task within a budget. Uses live HuggingFace benchmark data and real-time GPU pricing to find the best model for your use case.",
            inputSchema={
                "type": "object",
                "properties": {
                    "task": {
                        "type": "string",
                        "description": "ML task description (e.g., 'text-classification', 'code-generation', 'chat', 'tabular-classification')",
                    },
                    "budget_usd_per_hour": {
                        "type": "number",
                        "description": "Maximum hourly budget in USD (default: 1.0)",
                    },
                    "gpu_type": {
                        "type": "string",
                        "description": "GPU type (e.g., 'nvidia-l4', 'nvidia-a100-80gb'). Default: nvidia-l4",
                    },
                },
                "required": ["task"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle tool calls."""
    c = get_client()

    if name == "check_budget":
        result = await c.check_budget(arguments.get("tenant_id"))
        return [TextContent(type="text", text=_format_budget(result))]

    elif name == "list_deployments":
        result = await c.list_deployments(arguments.get("tenant_id"))
        return [TextContent(type="text", text=_format_deployments(result))]

    elif name == "get_costs":
        result = await c.get_costs(
            arguments.get("tenant_id"),
            arguments.get("deployment_id"),
            arguments.get("period", "today"),
        )
        return [TextContent(type="text", text=_format_costs(result))]

    elif name == "kill_deployment":
        deployment_id = arguments.get("deployment_id")
        if not deployment_id:
            return [TextContent(type="text", text="Error: deployment_id is required")]
        result = await c.kill_deployment(
            deployment_id, arguments.get("reason", "manual")
        )
        return [TextContent(type="text", text=_format_kill(result))]

    elif name == "recommend_model":
        task = arguments.get("task")
        if not task:
            return [TextContent(type="text", text="Error: task is required")]
        result = await c.recommend_model(
            task,
            arguments.get("budget_usd_per_hour", 1.0),
            arguments.get("gpu_type", "nvidia-l4"),
        )
        return [TextContent(type="text", text=_format_recommendation(result))]

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


def _format_budget(data: dict[str, Any]) -> str:
    """Format budget status for display."""
    if data.get("offline_mode"):
        return f"""## Budget Status [OFFLINE MODE]

API unreachable — showing cached/default values.

- **Tenant:** {data.get('tenant_id', 'unknown')}
- **Budget:** ${data.get('budget_usd', 0):.2f}
- **Spent:** ${data.get('spent_usd', 0):.2f}
- **Remaining:** ${data.get('remaining_usd', 0):.2f}
- **Utilization:** {data.get('utilization_percent', 0):.1f}%

Connect to Lutflow Cloud for real-time data."""

    return f"""## Budget Status

- **Tenant:** {data.get('tenant_id', 'unknown')}
- **Budget:** ${data.get('budget_usd', 0):.2f}
- **Spent:** ${data.get('spent_usd', 0):.4f}
- **Remaining:** ${data.get('remaining_usd', 0):.4f}
- **Utilization:** {data.get('utilization_percent', 0):.1f}%
- **Kill Path:** {data.get('kill_path_status', 'ACTIVE')}"""


def _format_deployments(data: dict[str, Any]) -> str:
    """Format deployments list for display."""
    deployments = data.get("deployments", [])
    if not deployments:
        if data.get("offline_mode"):
            return "## Deployments [OFFLINE MODE]\n\nNo deployments found. API unreachable."
        return "## Deployments\n\nNo active deployments."

    lines = ["## Active Deployments\n"]
    for d in deployments:
        status = d.get("status", "unknown")
        emoji = "🟢" if status == "running" else "🔴" if status == "killed" else "🟡"
        lines.append(f"""### {emoji} {d.get('deployment_id', 'unknown')}
- **Model:** {d.get('model_id', 'unknown')}
- **Cost:** ${d.get('current_cost', 0):.4f} / ${d.get('budget_usd', 0):.2f}
- **Status:** {status}
""")
    return "\n".join(lines)


def _format_costs(data: dict[str, Any]) -> str:
    """Format cost breakdown for display."""
    if data.get("offline_mode"):
        return "## Cost Breakdown [OFFLINE MODE]\n\nAPI unreachable — no cost data available."

    lines = [f"## Cost Breakdown ({data.get('period', 'today')})\n"]
    lines.append(f"**Total:** ${data.get('total_cost_usd', 0):.4f}")
    lines.append(f"**Events:** {data.get('event_count', 0)}\n")

    by_model = data.get("by_model", {})
    if by_model:
        lines.append("### By Model")
        for model, cost in sorted(by_model.items(), key=lambda x: -x[1]):
            lines.append(f"- **{model}:** ${cost:.4f}")

    return "\n".join(lines)


def _format_kill(data: dict[str, Any]) -> str:
    """Format kill result for display."""
    if data.get("success"):
        return f"""## ⚡ Kill Executed

- **Deployment:** {data.get('deployment_id')}
- **Reason:** {data.get('reason', 'manual')}
- **Status:** Terminated

The deployment has been stopped. No further costs will be incurred."""

    if data.get("offline_mode"):
        return f"""## Kill Request [OFFLINE MODE]

- **Deployment:** {data.get('deployment_id')}
- **Status:** Cannot confirm

API unreachable — the deployment may still be running.
Check your cluster directly or retry when connected."""

    return f"""## Kill Failed

- **Deployment:** {data.get('deployment_id')}
- **Error:** {data.get('error', 'Unknown error')}

The kill request could not be completed."""


def _format_recommendation(data: dict[str, Any]) -> str:
    """Format model recommendation for display."""
    source = data.get("source", "unknown")
    source_badge = "[CACHED]" if source == "cached" else "[LIVE]"

    return f"""## Model Recommendation {source_badge}

**Task:** {data.get('task', 'unknown')}

### Recommended: {data.get('recommendation', 'unknown')}

- **Score:** {data.get('score', 0):.3f}
- **VRAM:** {data.get('vram_gb', 0):.1f} GB
- **Cost:** ${data.get('cost_per_hour', 0):.2f}/hr on {data.get('provider', 'unknown')}
- **GPU:** {data.get('gpu_type', 'nvidia-l4')}
- **Budget Remaining:** ${data.get('budget_remaining', 0):.2f}/hr

{data.get('message', '')}"""


async def run_server():
    """Run the MCP server."""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main():
    """Entry point for the MCP server."""
    asyncio.run(run_server())


if __name__ == "__main__":
    main()
