"""Tharun++ CLI Module"""

from .main import app

__all__ = ['app']
