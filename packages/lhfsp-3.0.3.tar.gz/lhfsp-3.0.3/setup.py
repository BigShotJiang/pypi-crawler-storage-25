from setuptools import setup, find_packages

setup(
    name='lhfsp',
    version='3.0.3',
    packages=find_packages(),
    install_requires=['pyperclip'],
)