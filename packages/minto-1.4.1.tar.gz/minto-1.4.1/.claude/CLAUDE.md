
# Developing Environment

Pythonの環境には`uv`を使っています。
ライブラリの管理、インストール、削除などは全て`uv`を使って行なってください。


# Pythonコーディング規約

## Pythonのtyping

typingは

```
import typing as typ

typ.Any
```
のように`typ`というエイリアスで使ってください。こうすることでimportが長くなりすぎるのを防ぎます。
またlistなどはListを使わずに、`list[float]`のように組み込み型を使ってください。

## docstringの書き方

docstringはGoogleスタイルで書いてください。


# 開発の流れ


## Testing

実装を変更したら、必ず`uv run pytest`でテストを実行し、全てのテストが通ることを確認してください。

新しい機能を開発することになる場合は、できればTDDで進めてください。
つまり、最初に失敗するテストを書き、その後に実装を書いてテストを通す、という流れです。


## ruff formating

コードのフォーマットには`ruff`を使っています。
コードを書き終えたら、`uv run ruff check .`でフォーマットをチェックし、問題があれば`uv run ruff format .`で自動修正してください。
