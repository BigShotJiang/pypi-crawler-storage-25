"""Soliplex configuration package"""
