# socket_vault 
Set up a temporary socket server to stored passwords.

