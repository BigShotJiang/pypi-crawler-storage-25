
import importlib.metadata
import logging
socket_vault_logger = logging.getLogger(__name__)

__version__ =  importlib.metadata.version('socket_vault')

from socket_vault.main import query_vault, set_vault, vault_password
