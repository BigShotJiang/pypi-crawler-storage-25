import logging

from socket_vault import set_vault, query_vault, socket_vault_logger, vault_password
from socket_vault.main import SocketVault

logging.basicConfig()
socket_vault_logger.setLevel(logging.DEBUG)
_S = '/tmp/mysock'

with  SocketVault(_S):
    pw = vault_password(_S,"query","test")
    pw2 = vault_password(_S,"query","test")
    assert (pw == pw2)


