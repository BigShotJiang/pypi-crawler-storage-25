import logging

from socket_vault import set_vault, query_vault, socket_vault_logger
from socket_vault.main import SocketVault

logging.basicConfig()
socket_vault_logger.setLevel(logging.DEBUG)
_S = '/tmp/mysock'

pw = 'mo'
with SocketVault(_S):
    set_vault(_S,'eenie','meanie',pw)
    r = query_vault(_S,'eenie','meanie')
    assert(pw == r)
    r = query_vault(_S,'junk','bond')
    assert (r is None)
    try:
        r = query_vault('/tmp/fiction','a','b')
        assert (False)
    except FileNotFoundError:
        pass


