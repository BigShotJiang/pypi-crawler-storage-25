#!/usr/bin/env python3
import argparse
import json
import logging
import os
import socket
import struct
import threading
import time
from pathlib import Path

from memory_vault import memory_vault_logger


class MemoryVault:

    def __init__(self, spath: str) -> None:
        """Set up socket server on spath"""
        self._spath = spath
        self._store: dict[tuple[str, str], str | None] = {}
        self._lock = threading.Lock()
        self._server_uid = os.getuid()

        if os.path.exists(spath):
            os.unlink(spath)

    def __enter__(self):
        spath = self._spath
        self._sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self._sock.bind(spath)
        os.chmod(spath, 0o600)
        self._sock.listen(5)
        self._thread = threading.Thread(target=self._serve, daemon=True)

        self._thread.start()
        memory_vault_logger.info("MemoryVault server started on %s", spath)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.stop()
        except Exception:
            pass

    def _serve(self) -> None:
        while True:
            try:
                conn, _ = self._sock.accept()
            except OSError:
                break
            threading.Thread(target=self._handle, args=(conn,), daemon=True).start()

    def _peer_uid(self, conn: socket.socket) -> int:
        # SO_PEERCRED returns ucred: { pid_t pid, uid_t uid, gid_t gid }
        raw = conn.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, struct.calcsize("iII"))
        _, uid, _ = struct.unpack("iII", raw)
        return uid

    def _handle(self, conn: socket.socket) -> None:
        with conn:
            try:
                if self._peer_uid(conn) != self._server_uid:
                    memory_vault_logger.warning("Rejected connection from foreign UID")
                    return
                data = b""
                while b"\n" not in data:
                    chunk = conn.recv(4096)
                    if not chunk:
                        return
                    data += chunk
                request = json.loads(data.strip())
                response = self._dispatch(request)
                conn.sendall(json.dumps(response).encode() + b"\n")
            except Exception as exc:
                memory_vault_logger.exception("Error handling request: %s", exc)

    def _dispatch(self, request: dict) -> dict:
        op = request.get("op")
        key = (request.get("context", ""), request.get("account", ""))
        if op == "set":
            with self._lock:
                self._store[key] = request.get("password")
            memory_vault_logger.debug(f"stored {key}")
            return {"status": "ok"}
        if op == "query":
            with self._lock:
                password = self._store.get(key)
            if memory_vault_logger.isEnabledFor(logging.DEBUG):
                stat = 'retrieved' if password is not None else 'not found'
                memory_vault_logger.debug(f"{key} {stat}")
            return {"status": "ok", "password": password}
        return {"status": "error", "message": f"unknown op: {op}"}

    def stop(self) -> None:
        self._sock.close()
        if os.path.exists(self._spath):
            os.unlink(self._spath)


def _send_recv(spath: Path, request: dict) -> dict:
    if not spath.is_socket():
        raise FileNotFoundError(f"socket {spath.as_posix()} not found")
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as sock:
        sock.connect(spath.as_posix())
        sock.sendall(json.dumps(request).encode() + b"\n")
        data = b""
        while b"\n" not in data:
            chunk = sock.recv(4096)
            if not chunk:
                break
            data += chunk
    return json.loads(data.strip())


def set_vault(spath: str, context: str, account: str, password: str | None) -> None:
    """set password in server for context and account"""
    response = _send_recv(Path(spath), {"op": "set", "context": context, "account": account, "password": password})
    if response.get("status") != "ok":
        raise RuntimeError(f"set_vault failed: {response}")


def query_vault(spath: str, context: str, account: str) -> str | None:
    """query for server for existing password for context and account"""
    response = _send_recv(Path(spath), {"op": "query", "context": context, "account": account})
    if response.get("status") != "ok":
        raise RuntimeError(f"query_vault failed: {response}")
    return response.get("password")

def vault_password(spath: str, context: str, account: str) -> str | None:
    """Call query vault to get password. If None, prompt user for password. Store user entered password for future use"""
    password = query_vault(spath, context, account)
    if password is None:
        import getpass
        password = getpass.getpass(f"Password for {context}/{account}: ")
        set_vault(spath, context, account, password)
    return password


def main():
    logging.basicConfig()
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("-l", "--loglevel", default="WARN", help="Python logging level")
    parser.add_argument("--hours", type=int, default=2, help="Number of hours server will run before exiting")
    parser.add_argument("socket", help="Location for unix socket")

    args = parser.parse_args()
    memory_vault_logger.setLevel(getattr(logging, args.loglevel))

    with MemoryVault(args.socket):
        try:
            time.sleep(args.hours * 3600)
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    main()
