
import importlib.metadata
import logging
memory_vault_logger = logging.getLogger(__name__)

__version__ =  importlib.metadata.version('memory_vault')

from memory_vault.main import query_vault, set_vault, vault_password
