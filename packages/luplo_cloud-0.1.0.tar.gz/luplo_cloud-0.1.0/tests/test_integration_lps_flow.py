"""End-to-end integration test for the ``lps`` CLI against a real
FastAPI backend running in a subprocess.

This test lives here for archival reference only: it depends on a
companion API package and a local postgres instance that are not part
of this repository. It is unconditionally skipped in the public
``luplo-cloud`` repo and is exercised in the upstream development
environment instead.

Journey covered (when enabled upstream):

    0. boot: uvicorn subprocess + /health probe
    1. POST /auth/signup (seed the keyring with a CLI token pair
       straight from the API)
    2. keyring_store.save(...) — what lps login would have done
    3. `lps whoami --server URL` → prints email
    4. `lps mcp-config --server URL` → JSON with matching access token
    5. real /mcp initialize + tools/list using the token from (4)
    6. `lps logout --server URL` → keyring cleared, /auth/refresh then 401
"""
from __future__ import annotations

import json
import os
import shutil
import signal
import socket
import subprocess
import time
from pathlib import Path

import httpx
import pytest
from typer.testing import CliRunner

from luplo_cloud import keyring_store
from luplo_cloud.main import app as lps_app

pytestmark = pytest.mark.skip(
    reason="requires a companion SaaS API + DB not present in this repo"
)

_API_DIR = Path(__file__).resolve().parents[2] / "api"
_TEST_DB = os.environ.get(
    "LUPLO_SAAS_TEST_DB_URL",
    "postgresql+asyncpg://postgres:localdb@localhost:5433/luplo_cloud_test",
)
_LUPLO_TEST_DB = os.environ.get(
    "LUPLO_SAAS_LUPLO_TEST_DB_URL",
    "postgresql://postgres:localdb@localhost:5433/luplo_test",
)


def _pg_reachable() -> bool:
    # Strip asyncpg driver prefix for a raw socket probe
    import re

    m = re.search(r"@([^:/]+):(\d+)", _TEST_DB)
    if not m:
        return False
    host, port = m.group(1), int(m.group(2))
    try:
        with socket.create_connection((host, port), timeout=1.0):
            return True
    except OSError:
        return False


# NOTE: top-of-file `pytestmark` already unconditionally skips this module
# in the public luplo-cloud repo (no live SaaS API/DB available). The
# original conditional skip below is preserved as a comment for the
# monorepo equivalent test, which is where this journey is actually
# exercised:
#
# pytestmark = pytest.mark.skipif(
#     not _pg_reachable(),
#     reason=f"test postgres not reachable at {_TEST_DB!r}; integration skipped",
# )


def _pick_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="module")
def api_server():
    """Spawn uvicorn against the api/ package on a random port.

    We don't re-run alembic on every test — the existing luplo_cloud_test
    already has public schema from the api test suite. If that ever
    drifts, `cd api && uv run alembic upgrade head` fixes it.
    """
    if not shutil.which("uv"):
        pytest.skip("`uv` CLI not available on PATH")

    port = _pick_port()
    env = {
        **os.environ,
        "LUPLO_SAAS_ENV": "test",
        "LUPLO_SAAS_DB_URL": _TEST_DB,
        "LUPLO_SAAS_LUPLO_DB_URL": _LUPLO_TEST_DB,
        "LUPLO_SAAS_SESSION_SECRET": "integration-session-secret-32chars-pad",
        "LUPLO_SAAS_JWT_SECRET": "integration-jwt-secret-32chars-pad-----",
        "LUPLO_SAAS_APP_ORIGIN": f"http://127.0.0.1:{port}",
        "LUPLO_SAAS_COOKIE_DOMAIN": "",
        "LUPLO_SAAS_LOG_LEVEL": "WARNING",
    }
    proc = subprocess.Popen(
        [
            "uv", "run", "alembic", "upgrade", "head",
        ],
        cwd=str(_API_DIR),
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    proc.wait(timeout=60)

    proc = subprocess.Popen(
        [
            "uv", "run", "uvicorn",
            "luplo_saas.main:app",
            "--host", "127.0.0.1",
            "--port", str(port),
            "--log-level", "warning",
        ],
        cwd=str(_API_DIR),
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    base = f"http://127.0.0.1:{port}"
    deadline = time.monotonic() + 45
    while time.monotonic() < deadline:
        try:
            r = httpx.get(f"{base}/health", timeout=1.0)
            if r.status_code == 200:
                break
        except httpx.HTTPError:
            pass
        time.sleep(0.3)
    else:
        proc.terminate()
        proc.wait(timeout=5)
        pytest.fail("api did not become healthy within 45s")

    yield base

    proc.send_signal(signal.SIGTERM)
    try:
        proc.wait(timeout=10)
    except subprocess.TimeoutExpired:
        proc.kill()


def _signup(base: str, email: str, password: str) -> dict:
    r = httpx.post(
        f"{base}/auth/signup",
        json={"email": email, "password": password},
        timeout=10.0,
    )
    r.raise_for_status()
    return r.json()


def _saas_dsn() -> str:
    """Convert the SaaS test DB URL into a libpq-form DSN usable by psycopg."""
    from urllib.parse import urlparse

    u = urlparse(_TEST_DB)
    user_pass = f"{u.username}:{u.password}" if u.password else (u.username or "")
    path = u.path or ""
    return f"postgresql://{user_pass}@{u.hostname}:{u.port}{path}"


def _purge_user(base: str, email: str) -> None:
    """Best-effort cleanup between runs — signup refuses duplicate
    emails, so we pre-drop by email."""
    import psycopg

    with psycopg.connect(_saas_dsn(), autocommit=True) as conn, conn.cursor() as cur:
        cur.execute("DELETE FROM public.users WHERE email = %s", (email,))


def test_full_lps_journey(api_server: str) -> None:
    runner = CliRunner()
    email = "integration-lps@example.com"

    _purge_user(api_server, email)
    keyring_store.clear()

    # 1. signup (stands in for the browser login flow — the CLI's
    # LoginBridge has its own unit tests)
    body = _signup(api_server, email, "integration-lps-secret")
    tokens = body["tokens"]
    keyring_store.save(tokens["access_token"], tokens["refresh_token"])

    # 2. lps whoami
    r = runner.invoke(lps_app, ["whoami", "--server", api_server])
    assert r.exit_code == 0, r.stdout + r.stderr
    assert email in r.stdout
    assert body["user"]["id"] in r.stdout
    assert body["user"]["actor_id"] in r.stdout

    # 3. lps mcp-config — must emit a valid Claude Desktop JSON that
    # points at the running api and carries the access token from
    # keyring
    r = runner.invoke(lps_app, ["mcp-config", "--server", api_server])
    assert r.exit_code == 0, r.stdout
    entry = json.loads(r.stdout)
    luplo = entry["mcpServers"]["luplo"]
    assert luplo["url"] == f"{api_server}/mcp"
    assert luplo["authentication"]["bearer_token"] == tokens["access_token"]

    # 4. The bearer in mcp-config really opens an MCP session and lets
    # tools/list succeed — end-to-end proof that what lps hands Claude
    # is live-wired
    bearer = luplo["authentication"]["bearer_token"]
    common_headers = {
        "Authorization": f"Bearer {bearer}",
        "Accept": "application/json, text/event-stream",
        "Content-Type": "application/json",
    }
    init = httpx.post(
        f"{api_server}/mcp",
        headers=common_headers,
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "initialize",
            "params": {
                "protocolVersion": "2025-06-18",
                "capabilities": {},
                "clientInfo": {"name": "lps-integration", "version": "1"},
            },
        },
        timeout=10.0,
    )
    assert init.status_code == 200, init.text
    sid = init.headers["mcp-session-id"]
    httpx.post(
        f"{api_server}/mcp",
        headers={**common_headers, "mcp-session-id": sid},
        json={"jsonrpc": "2.0", "method": "notifications/initialized"},
        timeout=10.0,
    )
    tools = httpx.post(
        f"{api_server}/mcp",
        headers={**common_headers, "mcp-session-id": sid},
        json={"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        timeout=10.0,
    )
    # parse SSE or JSON
    ct = tools.headers.get("content-type", "")
    if ct.startswith("application/json"):
        payload = tools.json()
    else:
        payload = next(
            json.loads(line[6:])
            for line in tools.text.splitlines()
            if line.startswith("data: ")
        )
    names = {t["name"] for t in payload["result"]["tools"]}
    assert "luplo_item_search" in names

    # 5. lps logout — keyring clean + refresh rejected afterwards
    r = runner.invoke(lps_app, ["logout", "--server", api_server])
    assert r.exit_code == 0
    assert keyring_store.load() is None
    retry_refresh = httpx.post(
        f"{api_server}/auth/refresh",
        json={"refresh_token": tokens["refresh_token"]},
        timeout=10.0,
    )
    assert retry_refresh.status_code == 401


def test_whoami_without_login_reports_and_exits_nonzero(api_server: str) -> None:
    keyring_store.clear()
    runner = CliRunner()
    r = runner.invoke(lps_app, ["whoami", "--server", api_server])
    assert r.exit_code == 1
    combined = r.stdout + r.stderr
    assert "not logged in" in combined.lower()
