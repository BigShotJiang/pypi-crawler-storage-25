# Response Status Guide

Every `AdapterResponse` carries a `status` field — one of `SUCCESS`, `FAILED`, or `REVIEW_REQUIRED`. The status determines what Core does next, what the user sees, and whether the document re-enters the queue.

This guide describes when to return each status, how the platform UI reacts, and the override mechanism that lets users push past adapter-side flags.

## TL;DR — Decision Tree

```
Did the adapter complete the integration successfully?
├─ Yes  → SUCCESS                                          (#success)
└─ No
   ├─ Did the adapter fail with no realistic recovery path
   │  for the user to act on?                              → FAILED  (#failed)
   │  Examples: target system unreachable, missing required
   │  field that can't be filled in by review, exception in
   │  the integration step.
   │
   └─ Could the user resolve this by reviewing the data
      or affirming a flagged value?                        → REVIEW_REQUIRED  (#review_required)
      Examples: ambiguous customer match, fuzzy product
      lookup, suspicious value (holiday delivery date,
      out-of-stock SKU, price below floor).
```

When in doubt: prefer `REVIEW_REQUIRED` over `FAILED`. Review is recoverable; failures need an engineer.

## SUCCESS

The integration completed end-to-end. The document has been written to the target system (ERP, CRM, etc.) and no human follow-up is needed.

```python
return AdapterResponse(
    document_id=payload.document_id,
    status=StatusEnum.SUCCESS,
    details={"erp_order_number": "VIS-12345"},
    notifications=["Order created in Vision as VIS-12345"],  # optional
)
```

**UI effect:** File moves to `PROCESSED`. The user sees a success badge. `notifications` (optional) renders as an info banner on the file's split view.

**Use `details` for** machine-friendly outcome data (target system IDs, line counts). It's stored and can be queried later by support tooling.

**Use `notifications` for** short user-facing messages worth surfacing in the UI ("Created order #X", "Note: shipped via standard freight"). Each entry renders as a bullet.

## FAILED

A hard failure that the user can't fix by editing the data. Either the integration step blew up, or required information is missing in a way that review wouldn't help.

```python
return AdapterResponse(
    document_id=payload.document_id,
    status=StatusEnum.FAILED,
    failure_type="erp_unreachable",
    failure_reason="Vision PostgreSQL connection timed out after 30s",
    details={"step": "create_order", "host": "vision-prod.local"},
)
```

**UI effect:** File moves to `ADAPTER_FAILED`. A red error banner shows `failure_reason`. The user sees a "Retry" affordance and a "Mark Manually Resolved" escape hatch.

**`failure_type`** is a short machine identifier (e.g. `erp_unreachable`, `validation_error`, `duplicate_invoice`, `permission_denied`). Stable strings let support tooling and dashboards aggregate by failure mode. Pick one per failure path and reuse it.

**`failure_reason`** is a one-sentence human explanation. Keep it specific enough to be actionable for whoever is on call.

**Don't use `FAILED` for:**

- Ambiguous matches the user could resolve by picking a value → use `REVIEW_REQUIRED`
- Suspicious-but-valid values the user might want to affirm (holiday delivery, price floor, low stock) → use `REVIEW_REQUIRED` with `proposed_values=[]`
- A document that doesn't apply to your handler — Core's `adapter_identifier` routing already handles that

If your handler raises an unhandled exception, the framework catches it and returns `FAILED` automatically with `failure_type="adapter_error"`. You don't need a top-level try/except just for this — wrap only when you want a more specific `failure_type`.

## REVIEW_REQUIRED

The integration didn't complete because the document needs human review. The user opens it in SplitView, resolves the flagged fields, and re-sends. The same handler runs again with the user's edits applied.

```python
return AdapterResponse(
    document_id=payload.document_id,
    status=StatusEnum.REVIEW_REQUIRED,
    review_reason=["Customer match ambiguous", "Delivery date on a Dutch holiday"],
    review_suggestions=[
        ReviewSuggestion(
            field_path="document.customer_number",
            original_value="ACME-DE",
            proposed_values=[
                ProposedValue(value="ACME-DE-001", description="Acme Deutschland Hamburg"),
                ProposedValue(value="ACME-DE-002", description="Acme Deutschland Berlin"),
            ],
        ),
        ReviewSuggestion(
            field_path="document.delivery_date",
            original_value="27-04-2026",
            proposed_values=[],
            reason="Delivery date falls on King's Day — public holiday in NL",
        ),
    ],
)
```

**UI effect:** File moves to `ADAPTER_REVIEW_REQUIRED`. SplitView opens with the document; the per-field flags render inline (yellow border on the cell), and `review_reason` shows as a bullet list at the top of the page.

### Two flavors of `ReviewSuggestion`

The shape of `proposed_values` decides the UI:

**With proposed values (`proposed_values: [...]`)** — *advisory.* Renders an inline Combobox on the field. The user picks a proposed value, types a custom one, or leaves the extracted value alone. Send is **not** gated; the user can review and send the file with one click. On resend, the adapter validates whatever value the user committed.

Use this when there's a sensible alternative the adapter could suggest:

- Fuzzy product match → propose the top candidates
- Ambiguous customer ID → propose all matches
- Date format normalization → propose the canonical form
- Holiday delivery date → propose the previous business day

**Without proposed values (`proposed_values: []`)** — *requires explicit affirmation.* Renders as a yellow-bordered cell with an inline Accept button (or, when multiple are present, surfaces in a confirmation dialog when the user clicks Send). The user must explicitly accept the flagged value or edit it to something different.

Use this when the adapter can flag the value as suspicious but has no good alternative to propose:

- Out-of-stock SKU but the customer placed a backorder
- Price below the agreed floor
- Credit limit exceeded for the customer
- Holiday delivery date the user might genuinely want

### `review_reason` vs `ReviewSuggestion.reason`

**`AdapterResponse.review_reason: list[str]`** — document-level bullet summary at the top of SplitView. Keep it short (1–3 entries). It's the reviewer's triage signal: *why does this file need attention?*

**`ReviewSuggestion.reason: str | None`** — per-field tooltip, only shown on the inline Accept pill (empty-proposals branch). Single-field context that the user sees while deciding whether to accept that specific value.

Heavy use cases ship 3+ suggestions per line item across many lines; rendering each `ReviewSuggestion.reason` at the document level would overwhelm the user. Don't aggregate per-field reasons into `review_reason` — keep them separate.

For Combobox suggestions (with proposed values), the per-`ProposedValue.description` is what the user reads. `ReviewSuggestion.reason` is **not** rendered there; setting it is harmless but won't be visible.

### The override mechanism

When a user accepts a flagged value (clicks the Accept pill or confirms the dialog on Send), Core forwards that affirmation to the adapter on the next send via `payload.accepted_overrides: dict[str, str]`. The handler consults this with the helper:

```python
if not payload.is_override_accepted("document.delivery_date"):
    # Run the holiday/weekend check as normal
    review_suggestion = self._build_delivery_date_review(delivery_date)
    if review_suggestion is not None:
        review_suggestions.append(review_suggestion)
# else: user has affirmed this value on this resend — skip the check
```

**Without this wrap, the loop is infinite:** the adapter flags → user accepts → resend → adapter flags the same value again. The `is_override_accepted` check breaks the loop on the resend.

**Don't wrap hard data errors with override checks.** A malformed date string should still surface as `failure_reason` even when an override is accepted on that path — overrides are an escape hatch for *valid-but-suspicious* values, not for parsing failures.

```python
# Correct: review check is overridable, parse error is not
review, parse_error = self._build_delivery_date_review(delivery_date)
if parse_error:
    errors.append(parse_error)              # always surfaces
if review is not None and not payload.is_override_accepted("document.delivery_date"):
    review_suggestions.append(review)       # suppressed when accepted
```

### What the user sees when they click Send

If the file has any unresolved no-proposal flag (i.e. a `proposed_values=[]` suggestion the user hasn't accepted via the inline pill), clicking Send opens a confirmation dialog listing each flagged field with its `reason` and current value. Confirming records overrides for any unchanged values and proceeds with the send. Cancel closes the dialog.

This means the user *will* see your `reason` text in two places: once as a tooltip on the inline pill, and once as a line in the confirmation dialog. Write it as a short, neutral statement of the rule that triggered (e.g. `"Delivery date falls on a Dutch holiday"`, `"Stock is below requested quantity"`), not as an imperative or a question.

Flags **with** proposed values do not appear in the confirmation dialog and never gate Send.

## Common Pitfalls

**Returning `FAILED` for ambiguous matches.** A customer code that matches three records is not a failure — it's a review case. Return `REVIEW_REQUIRED` with the candidates as `proposed_values` so the user picks one.

**Returning `SUCCESS` when only part of the document was integrated.** Either the whole document made it (SUCCESS), it failed (FAILED), or it needs review (REVIEW_REQUIRED). Don't mix outcomes — split the document upstream if necessary.

**Aggregating per-field reasons into `review_reason`.** The two fields exist precisely so they don't overlap. `review_reason` = short doc-level summary. `ReviewSuggestion.reason` = per-field context. Mixing them produces a wall of text at the top of SplitView.

**Forgetting `is_override_accepted` on a check that emits review suggestions.** Without it, the user is trapped in an accept-resend-reflag loop. Wrap any check that calls `review_suggestions.append(...)` with the helper.

**Wrapping hard errors with `is_override_accepted`.** Overrides are user-affirmed *valid* values. Bad data (parse errors, schema violations, missing required fields) must not be silenced by an override. Keep the error branch outside the override gate.

**Rendering `ReviewSuggestion.reason` on a Combobox suggestion (with proposed values).** It won't show — `ProposedValue.description` is what the user reads on those. Either move the explanation into the per-value description, or accept that `reason` is silently unused there.

## Reference

- `entr_adapter_core.schemas.StatusEnum` — the three statuses
- `entr_adapter_core.schemas.AdapterResponse` — full response shape
- `entr_adapter_core.schemas.ReviewSuggestion` — per-field flag
- `entr_adapter_core.schemas.ProposedValue` — Combobox option
- `DocumentPayload.accepted_overrides` — user-affirmed values, populated by Core
- `DocumentPayload.is_override_accepted(field_path)` — handler-side check helper
