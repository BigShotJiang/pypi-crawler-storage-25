# Gmail Connector — User Guide

This guide covers the manual steps required to set up Gmail retrieval for a new tenant. These are **internal actions** performed by ENTR staff — the client does not need to do anything.

All steps use the shared `entr-processor@entr.solutions` Google Workspace account.

---

## Prerequisites

- Access to [Google Admin Console](https://admin.google.com) for `entr.solutions`
- Access to the `entr-processor@entr.solutions` Gmail account
- The tenant's `TENANT_NAME` value (from `.env` or `config.py`)

---

## Step 1: Add an email alias in Google Admin Console

1. Log in to [Google Admin Console](https://admin.google.com)
2. Navigate to **Directory > Users**
3. Find and select the **entr-processor@entr.solutions** user
4. Click **User information > Alternative email addresses (email alias)**
5. Add the alias email address for this tenant (e.g. `tenant-orders@entr.solutions`)
6. Click **Save**

> The alias takes a few minutes to propagate. You can verify by sending a test email to the alias.

---

## Step 2: Create the tenant label in Gmail

1. Log in to [Gmail](https://mail.google.com) as `entr-processor@entr.solutions`
2. In the left sidebar, scroll down and click **+ Create new label**
3. Enter the label name: `TENANT/{TENANT_NAME}`
   - Example: for `TENANT_NAME=Zuidberg`, create label `TENANT/Zuidberg`
   - **Case matters** — `TENANT/Zuidberg` is not the same as `TENANT/zuidberg`
   - The label name must match `TENANT_NAME` in the adapter's `.env` exactly, unless `label_override` is configured in the adapter settings

> If using `label_override`: the label name must match the override value instead of `TENANT/{TENANT_NAME}`.

---

## Step 3: Create a Gmail filter

1. In Gmail, click the **search options icon** (down arrow in the search bar)
2. In the **To** field, enter the alias email created in Step 1
3. Click **Create filter**
4. Check **Apply the label** and select the label created in Step 2
5. Check **Never send it to Spam** — without this, forwarded emails can be filtered into Spam and never reach the adapter
6. Optionally check **Also apply filter to matching conversations** to label existing emails
7. Click **Create filter**

---

## Step 4: (Optional) Configure sender whitelist

When you need `list_documents` to return **only** messages from specific senders (for
example, restricting a tenant to its own corporate domains), configure the
optional `sender_whitelist` field on `GmailConnectorConfig`.

### Accepted patterns

| Pattern | Meaning |
| ------- | ------- |
| `"@domain.tld"` | Any sender on that domain |
| `"user@domain.tld"` | Exact address |

Each entry must:

- Be a plain ASCII string (IDN / non-ASCII domains must be pre-encoded as
  Punycode — e.g. `"@xn--mller-kva.de"`, not `"@müller.de"`).
- Contain exactly one `@`.
- Have a non-empty domain after the `@`, and that domain must contain a `.`
  (so `"@localhost"` and `"@"` are rejected).
- Contain no internal whitespace. Put each pattern in its own list item —
  do NOT try to embed `OR` inside a single entry.

Invalid entries raise a `ValidationError` (config path) or `ValueError`
(handler constructor path) with the offending entry quoted in the message.

### Behavior

- **Unset or empty** (`None` or `[]`) — no filter applied, all labeled mail is
  returned. This is the default and is fully backward-compatible.
- **Multiple patterns** — Gmail's server-side `q=` query is extended with a
  `(from:<p1> OR from:<p2> …)` clause, combined with any date filter already in
  place. No extra round-trips, no client-side filtering.
- **Single pattern** — emits a bare `from:<pattern>` clause (no parens, no
  `OR`), combined with any date filter in the same `q=` string.
- **Case insensitive** — entries are lowercased on storage; Gmail's `from:`
  operator is also case-insensitive.
- **Precedence** — if both are set, `GmailConnectorConfig.sender_whitelist` wins
  over the handler's `sender_whitelist=` constructor argument (mirrors the
  existing `label_override` precedence).

### Example

```python
config = GmailConnectorConfig(
    tenant_name="Acme",
    gmail_client_id="...",
    gmail_client_secret="...",
    gmail_refresh_token="...",
    sender_whitelist=["@acme.com", "vendor@partner.com"],
)
```

Or, when the whitelist belongs to the tenant's main adapter code rather than
the shared config (e.g. Smurfit passes the same list across all divisions):

```python
handler = EntrMailboxRetrievalHandler(
    settings,
    label_override="TENANT/Acme",
    sender_whitelist=["@acme.com", "vendor@partner.com"],
)
```

`sender_whitelist` is **keyword-only** on the handler constructor — this
prevents silent `label_override` ↔ `sender_whitelist` swaps in positional
call sites.

### Query-length caveat

A whitelist of up to ~100 entries is safe. Gmail's search query has a rough
upper bound around 1500 characters; longer lists may be silently truncated.
Use domain-level patterns (`@domain.tld`) rather than enumerating every
individual address.

### Typo warning

A single typo silently drops all mail — Gmail simply returns zero matches
for a filter that matches nothing. After configuring, verify via a
round-trip test (send a real email, then call `/list_documents`) **before
going live**. The handler logs a pattern count at INFO on startup and the
composed `q=` string on each list call, so CloudWatch / stdout both show the
active filter.

---

## Verification

After completing all steps, send a test email to the alias address. It should:

1. Arrive in the `entr-processor@entr.solutions` inbox
2. Automatically receive the `TENANT/{TENANT_NAME}` label

You can then verify the adapter can see it:

```bash
curl -X POST http://localhost:8096/list_documents \
  -H "Content-Type: application/json" \
  -d '{"adapter_identifier": "<handler_id>", "source_identifier": "gmail"}'
```

The test email should appear in the response.

---

## Troubleshooting

| Problem | Cause | Fix |
|---------|-------|-----|
| Emails arrive but have no label | Filter not matching | Check the **To** field in the filter matches the alias exactly |
| Forwarded emails missing from inbox | Gmail flagged them as spam | Edit the filter and enable **Never send it to Spam** |
| Alias email bounces | Alias not yet propagated | Wait 5-10 minutes after adding in Admin Console |
| Adapter returns 0 documents | Label name mismatch | Compare the label in Gmail with `TENANT_NAME` in `.env` — must be exact match (case-sensitive) |
| `Gmail label 'TENANT/X' not found` error | Label doesn't exist or name differs | Open Gmail, verify the label exists under the exact name `TENANT/{TENANT_NAME}` |
