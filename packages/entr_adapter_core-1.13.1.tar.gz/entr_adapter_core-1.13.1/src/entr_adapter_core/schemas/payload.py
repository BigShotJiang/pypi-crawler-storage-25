"""Payload schemas for the Core-to-Adapter contract.

These models define the structure of data that ENTR Core sends to tenant
adapters via the /process endpoint.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class AppliedMapping(BaseModel):
    """Informational record of a mapping that Core applied to the document data.

    Core applies mappings internally before sending the payload. This record
    tells the adapter what was changed, but the adapter does not need to
    re-apply anything.

    Field names mirror Core's ``AppliedMapping`` in
    ``backend/src/files/schemas.py`` — Core is the single source of truth.
    """

    field_path: str = Field(
        ..., description="JSON path where the mapping was applied (e.g., 'line_items.0.product_id')"
    )
    mapping_field: str = Field(
        ..., description="The field name that was mapped (e.g., 'product_id')"
    )
    original_value: str = Field(
        ..., description="The original value before mapping was applied"
    )
    mapped_value: str = Field(
        ..., description="The value after mapping was applied"
    )
    context: Optional[Dict[str, Any]] = Field(
        None, description="Context fields used for strict matching (e.g., {'article_number': 'ABC123'})"
    )


class DocumentPayload(BaseModel):
    """Payload that ENTR Core sends to an adapter's /process endpoint.

    Contains the extracted document data (with mappings already applied by Core),
    along with optional original data and file content for adapter-side processing.
    """

    adapter_identifier: str = Field(
        ..., description="Identifier for the specific adapter process/logic to invoke"
    )
    document_id: int = Field(
        ..., description="ID of the document in the ENTR-CORE platform"
    )
    data: Dict[str, Any] = Field(
        ..., description="Structured fields extracted from the document, with mappings already applied by Core"
    )
    original_data: Optional[Dict[str, Any]] = Field(
        None, description="Original document data before mapping application"
    )
    applied_mappings: Optional[List[AppliedMapping]] = Field(
        None, description="Informational list of mappings that Core applied to the data"
    )
    original_file_content_b64: Optional[str] = Field(
        None, description="Base64-encoded content of the original file"
    )
    original_file_name: Optional[str] = Field(
        None, description="Original filename with extension (e.g., 'invoice.pdf')"
    )
    accepted_overrides: Dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Map of JSON field paths to user-affirmed values. "
            "Populated by Core when the user has explicitly accepted a "
            "value for a flagged field (via the Combobox commit on a "
            "field with proposals, or the Accept pill on a field with "
            "no proposals). Handlers consult this via "
            "is_override_accepted() to suppress re-flagging on resend."
        ),
    )

    def is_override_accepted(self, field_path: str) -> bool:
        """Return True if the user has explicitly affirmed a value for
        the given field path on this send. Handlers should wrap any
        suggestion-emitting check with `if not
        payload.is_override_accepted(path): ...` to support overrides.
        """
        return field_path in self.accepted_overrides
