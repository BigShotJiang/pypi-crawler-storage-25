"""FastAPI router with bundled adapter endpoints.

Provides ``create_adapter_router()`` which returns an ``APIRouter`` with
all standard ENTR adapter endpoints: /process, /list_documents,
/download_document, and /health. When ``source_root`` is supplied,
also registers the production /debug/tree and /debug/file endpoints
that ENTR Core's support AI agent uses to inspect adapter source code.
"""

from __future__ import annotations

import logging
import os
import tomllib
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from entr_adapter_core.app.dispatcher import Dispatcher
from entr_adapter_core.handlers import BaseHandler
from entr_adapter_core.schemas import (
    AdapterResponse,
    DocumentDownloadPayload,
    DocumentDownloadResponse,
    DocumentPayload,
    RetrievalPayload,
    RetrievalResponse,
    StatusEnum,
)
from entr_adapter_core.utils.sandbox import SandboxError, SourceSandbox

logger = logging.getLogger(__name__)


class HealthResponse(BaseModel):
    """Response from the /health endpoint."""

    status: str = Field(default="ok")
    handlers: list[str] = Field(
        default_factory=list,
        description="Alphabetically sorted list of registered handler identifiers",
    )


class VersionInfo(BaseModel):
    """Response from the /version endpoint."""

    core_version: str = Field(..., description="The version of the ENTR-Core platform")
    adapter_version: str = Field(..., description="The version of the adapter")
    package_version: str = Field(..., description="The version of the entr-adapter-core package")
    tenant_name: str = Field(..., description="The name of the tenant")


def create_adapter_router(
    handlers: Dict[str, BaseHandler],
    *,
    settings: Any = None,
    source_root: Optional[Path] = None,
) -> APIRouter:
    """Create a FastAPI router with all standard adapter endpoints.

    This is the composable building block for adapters. Use it directly
    when you need custom middleware, additional routes, or custom startup
    logic on your own FastAPI app. For the simpler case, use
    ``create_adapter_app()`` which wraps this router.

    Args:
        handlers: Mapping of adapter identifiers to handler instances.
        settings: Optional settings object. If it has an ``ENV`` attribute,
            ``ENV == "local"``-gated debug endpoints (e.g. /debug/handlers)
            are registered.
        source_root: Optional path to the adapter's ``src/`` tree. When
            provided, /debug/tree and /debug/file are registered so Core's
            support AI agent can inspect the adapter's source code. Access
            is sandboxed (see :class:`SourceSandbox`) so traversal outside
            the root is rejected.

    Returns:
        A configured ``APIRouter`` with /process, /list_documents,
        /download_document, and /health endpoints (plus the debug
        endpoints described above when applicable).
    """
    dispatcher = Dispatcher(handlers=handlers)
    router = APIRouter()
    # Capture CWD at router creation time so /version resolves correctly
    # even if CWD changes later (e.g., in tests or background tasks)
    _project_root = Path.cwd()

    # -- Standard endpoints --

    @router.post("/process", response_model=AdapterResponse)
    async def process_document(payload: DocumentPayload) -> AdapterResponse:
        """Process a document payload by dispatching to the matching handler.

        The dispatcher looks up the handler by adapter_identifier, wraps the
        call with FlightRecorder for log capture, and returns the response
        with execution_logs attached.
        """
        return await dispatcher.dispatch_process(payload)

    @router.post("/list_documents", response_model=RetrievalResponse)
    async def list_documents(payload: RetrievalPayload) -> RetrievalResponse:
        """List available documents from an external source.

        Routes to the handler's retrieval_handler based on source_identifier.
        Returns an error response if no retrieval handler is configured.
        """
        return await dispatcher.dispatch_list_documents(
            payload.source_identifier, payload
        )

    @router.post("/download_document", response_model=DocumentDownloadResponse)
    async def download_document(request: DocumentDownloadPayload) -> DocumentDownloadResponse:
        """Download a specific document by identifier.

        Routes to the handler's retrieval_handler based on source_identifier.
        Returns an error response if no retrieval handler is configured.
        """
        try:
            return await dispatcher.dispatch_download_document(
                request.source_identifier, request.document_identifier
            )
        except ValueError as exc:
            # Dispatcher raises ValueError for missing handlers/retrieval.
            # DocumentDownloadResponse has no status field, so we use HTTP error
            # to clearly communicate the failure to Core.
            logger.warning("download_document failed: %s", exc)
            raise HTTPException(status_code=404, detail=str(exc))

    @router.get("/adapters")
    async def list_adapters() -> list[str]:
        """Return a list of all registered adapter identifiers.

        Used by Core to populate adapter selection dropdowns.
        """
        return sorted(dispatcher.get_handler_identifiers())

    @router.get("/version", response_model=VersionInfo)
    async def get_version() -> VersionInfo:
        """Return version information about the adapter and Core platform.

        Reads the adapter version from pyproject.toml and the Core platform
        version from core-version.txt (both in the adapter project root,
        captured as `_project_root` at router creation time). Backed by
        :mod:`entr_adapter_core.app.versions` so the heartbeat task and
        this endpoint stay in lockstep.
        """
        from entr_adapter_core.app.versions import collect_versions
        versions = collect_versions(_project_root)
        tenant_name = getattr(settings, "TENANT_NAME", "unknown") if settings else "unknown"
        return VersionInfo(
            core_version=versions["core_version"],
            adapter_version=versions["adapter_version"],
            package_version=versions["package_version"],
            tenant_name=tenant_name,
        )

    @router.get("/health", response_model=HealthResponse)
    async def health() -> HealthResponse:
        """Shallow liveness check returning registered handler identifiers.

        No database or external service calls — just confirms the app is
        running and lists which handlers are registered.
        """
        return HealthResponse(
            status="ok",
            handlers=sorted(dispatcher.get_handler_identifiers()),
        )

    # -- Source-code inspection endpoints (used by Core's support AI agent) --
    # Available in all environments — sandboxed via SourceSandbox. Skipped
    # when no source_root is supplied or when the path doesn't exist.

    if source_root is not None and Path(source_root).exists():
        sandbox = SourceSandbox(Path(source_root))
        logger.info("Source-inspection endpoints enabled (root=%s)", sandbox.root)

        @router.get("/debug/tree")
        async def debug_tree(
            path: str = Query(default=".", description="Subdirectory to list"),
        ) -> dict:
            """List files in the adapter's source tree (sandboxed)."""
            try:
                entries = sandbox.list_tree(path)
                return {"entries": entries, "base": f"{sandbox.root.name}/"}
            except SandboxError as exc:
                raise HTTPException(status_code=403, detail=str(exc))
            except FileNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except Exception:
                logger.exception("debug_tree failed")
                raise HTTPException(status_code=500, detail="Internal error listing files")

        @router.get("/debug/file")
        async def debug_file(
            path: str = Query(..., description="File path relative to source root"),
        ) -> dict:
            """Return the contents of a file in the adapter's source tree (sandboxed)."""
            try:
                content = sandbox.get_content(path)
                return {"path": path, "content": content}
            except FileNotFoundError as exc:
                raise HTTPException(status_code=404, detail=str(exc))
            except SandboxError as exc:
                raise HTTPException(status_code=403, detail=str(exc))
            except Exception:
                logger.exception("debug_file failed")
                raise HTTPException(status_code=500, detail="Internal error reading file")
    elif source_root is not None:
        logger.warning(
            "source_root=%s does not exist; /debug/tree and /debug/file not registered",
            source_root,
        )

    # -- Debug endpoints (conditional on ENV) --

    env = getattr(settings, "ENV", None) or os.environ.get("ENV", "production")

    if env == "local":
        logger.info("Debug endpoints enabled (ENV=local)")

        @router.get("/debug/handlers")
        async def debug_handlers() -> dict:
            """Return detailed handler information (debug only)."""
            info = {}
            for key, handler in handlers.items():
                info[key] = {
                    "handler_class": type(handler).__name__,
                    "has_retrieval_handler": handler.retrieval_handler is not None,
                    "retrieval_class": (
                        type(handler.retrieval_handler).__name__
                        if handler.retrieval_handler
                        else None
                    ),
                    "settings_type": (
                        type(handler.settings).__name__
                        if handler.settings
                        else None
                    ),
                }
            return {"handlers": info, "env": env}
    else:
        logger.info("Debug endpoints disabled (ENV=%s)", env)

    return router
