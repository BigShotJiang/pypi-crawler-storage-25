"""App factory for creating fully configured ENTR adapter applications.

Provides ``create_adapter_app()`` — the primary entry point for most adapters.
For adapters needing custom middleware or additional routes, use
``create_adapter_router()`` from ``router.py`` instead.
"""

from __future__ import annotations

import asyncio
import inspect
import logging
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional

from fastapi import FastAPI

from entr_adapter_core.app.file_context import install_file_context
from entr_adapter_core.app.heartbeat import (
    heartbeat_config,
    heartbeat_enabled,
    heartbeat_loop,
)
from entr_adapter_core.app.router import create_adapter_router
from entr_adapter_core.app.versions import collect_versions
from entr_adapter_core.handlers import BaseHandler

logger = logging.getLogger(__name__)


def _detect_source_root() -> Optional[Path]:
    """Return the directory containing the file that called ``create_adapter_app``.

    Walks back through the call stack, skipping any frames inside the
    ``entr_adapter_core`` package, and returns the parent directory of
    the first non-package frame whose own directory is a Python package
    (i.e. has an ``__init__.py``). For the canonical adapter layout
    (``src/main.py`` calling ``create_adapter_app``), this resolves to
    the adapter's ``src/`` directory.

    Returns ``None`` if no suitable frame is found, in which case the
    sandboxed source-inspection endpoints are simply not registered.
    """
    package_marker = "entr_adapter_core"
    for frame_info in inspect.stack()[1:]:
        try:
            filename = Path(frame_info.filename).resolve()
        except OSError:
            continue
        if package_marker in filename.parts:
            continue
        candidate = filename.parent
        if (candidate / "__init__.py").exists():
            return candidate
        return None
    return None


def create_adapter_app(
    handlers: Dict[str, BaseHandler],
    *,
    on_startup: Optional[List[Callable]] = None,
    on_shutdown: Optional[List[Callable]] = None,
    title: str = "ENTR Adapter",
    settings: Any = None,
    source_root: Optional[Path] = None,
    install_file_log_context: bool = True,
    **kwargs,
) -> FastAPI:
    """Create a fully configured FastAPI application for an ENTR adapter.

    This is the primary entry point for most adapters. It creates a FastAPI
    app with all standard endpoints (/process, /list_documents,
    /download_document, /health) and optional lifecycle callbacks.

    For adapters needing custom middleware, additional routes, or custom
    startup logic, use ``create_adapter_router()`` instead and include
    it in your own FastAPI app.

    Args:
        handlers: Mapping of adapter identifiers to handler instances.
            Each handler must be an instance of ``BaseHandler``.
        on_startup: Optional list of callbacks to execute on app startup.
            Executed in order after handler registration. Both sync and
            async callbacks are supported. A failing callback prevents
            the app from starting (fatal).
        on_shutdown: Optional list of callbacks to execute on app shutdown.
            Executed in order. Both sync and async callbacks are supported.
            Exceptions are logged but do not prevent other callbacks
            from running.
        title: FastAPI app title (default: "ENTR Adapter").
        settings: Optional settings object passed to the router for
            ENV-based debug endpoint gating.
        source_root: Path to the adapter's source tree exposed via the
            sandboxed /debug/tree and /debug/file endpoints (used by
            Core's support AI agent). When omitted (default), the
            package walks the call stack and uses the directory of the
            file that called ``create_adapter_app`` — for the canonical
            ``src/main.py`` layout this is just ``src/``, so adapters
            never need to set it explicitly. Pass ``Path("")`` to
            disable the endpoints.
        install_file_log_context: When ``True`` (default), middleware and
            a logging filter are installed so every adapter log line
            emitted while serving ``POST /process`` is prefixed with
            ``[File: {document_id}]``. Required for ``entr-cli logs
            lookup <file_id>`` to find lines in CloudWatch.
        **kwargs: Additional keyword arguments passed to ``FastAPI()``.

    Returns:
        A configured ``FastAPI`` application ready to serve.

    Examples:
        Basic usage::

            app = create_adapter_app(
                handlers={"invoice": InvoiceHandler(settings=my_settings)}
            )

        With lifecycle callbacks::

            async def connect_db():
                await db.connect()

            async def close_db():
                await db.disconnect()

            app = create_adapter_app(
                handlers={"invoice": InvoiceHandler()},
                on_startup=[connect_db],
                on_shutdown=[close_db],
            )

        For custom middleware, use ``create_adapter_router()`` instead::

            from entr_adapter_core.app import create_adapter_router

            app = FastAPI()
            app.add_middleware(CORSMiddleware, ...)
            router = create_adapter_router(handlers={...})
            app.include_router(router)
    """

    # Ensure a StreamHandler exists on the root logger so handler logs reach
    # stdout/stderr (and therefore Docker logs / CloudWatch). basicConfig is a
    # no-op if the root logger already has handlers, so adapters that configure
    # their own logging are unaffected.
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Startup: run callbacks in order, let exceptions propagate (fatal)
        for callback in on_startup or []:
            logger.info("Running startup callback: %s", callback.__name__)
            if asyncio.iscoroutinefunction(callback):
                await callback()
            else:
                callback()

        # Built-in Control Center heartbeat — silence-detection telemetry.
        # Opt out via CONTROL_CENTER_HEARTBEAT_ENABLED=false (e.g. local dev).
        # Failures inside the loop never raise — the receiver's silence sweeper
        # is the failure signal, so a network blip is fine to ignore.
        heartbeat_task: asyncio.Task | None = None
        if heartbeat_enabled():
            # Silence httpx's per-request INFO log — every 30s heartbeat would
            # otherwise log a line. Failures are still surfaced by our own
            # warning-level logs in heartbeat.py::post_heartbeat. Adapter
            # authors can re-enable with
            #   logging.getLogger("httpx").setLevel(logging.INFO).
            logging.getLogger("httpx").setLevel(logging.WARNING)

            tenant, url, interval = heartbeat_config()
            # Versions are static for the lifetime of the process — read once
            # and cache. The same cwd-based resolution as the /version
            # endpoint, so the heartbeat and that endpoint can never disagree.
            versions = collect_versions()
            heartbeat_task = asyncio.create_task(
                heartbeat_loop(
                    tenant=tenant,
                    control_center_url=url,
                    interval_seconds=interval,
                    get_handlers=lambda: sorted(handlers.keys()),
                    versions=versions,
                ),
                name="control-center-heartbeat",
            )
            app.state.heartbeat_task = heartbeat_task
        else:
            logger.info("Adapter heartbeat disabled via CONTROL_CENTER_HEARTBEAT_ENABLED=false")

        yield

        # Shutdown: run user callbacks first so they have time to drain DB
        # connections, in-flight requests, etc. The heartbeat keeps firing
        # until cancellation below — important so the Control Center doesn't
        # mistake a slow graceful shutdown for a `gone_silent` event.
        for callback in on_shutdown or []:
            try:
                logger.info("Running shutdown callback: %s", callback.__name__)
                if asyncio.iscoroutinefunction(callback):
                    await callback()
                else:
                    callback()
            except Exception as exc:
                logger.error(
                    "Shutdown callback %s failed: %s",
                    callback.__name__,
                    exc,
                )

        # Now cancel the heartbeat. The loop's CancelledError handler sends one
        # final heartbeat with `shutting_down: True` so the receiver can suppress
        # a spurious silent-alert during a rolling deploy.
        if heartbeat_task is not None:
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except asyncio.CancelledError:
                # Expected — cancel was self-issued.
                pass
            except Exception:
                # Any other shutdown-time exception is logged but swallowed so
                # one bad heartbeat tick can't block the lifespan from exiting.
                logger.exception("Heartbeat task raised on shutdown")

    app = FastAPI(title=title, lifespan=lifespan, **kwargs)

    # Auto-detect the adapter's source root from the caller's frame so
    # adapters don't have to remember to set it. An explicit Path("")
    # opts out (the router only registers the endpoints when the path
    # exists).
    if source_root is None:
        source_root = _detect_source_root()

    router = create_adapter_router(
        handlers=handlers,
        settings=settings,
        source_root=source_root,
    )
    app.include_router(router)

    if install_file_log_context:
        install_file_context(app)

    logger.info(
        "ENTR Adapter app created with %d handler(s): %s",
        len(handlers),
        list(handlers.keys()),
    )

    return app
