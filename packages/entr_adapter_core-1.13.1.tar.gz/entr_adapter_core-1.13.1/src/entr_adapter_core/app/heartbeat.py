"""Built-in adapter heartbeat task.

Adapters created via :func:`entr_adapter_core.app.create_adapter_app`
automatically POST `{tenant, service: "adapter", status, details: {handlers}}`
to ENTR's Control Center every 30s. The receiver alerts Slack on silence
or status-change transitions. See `Entr-Adapter-Core/CHANGELOG.md` and
the corresponding Control Center repo.

The task is intentionally fail-soft — if the Control Center is unreachable
the loop logs a warning and waits for the next interval. Silence is the
alert signal, so a transient network blip doesn't need to escalate.

Single POST attempt per tick (no in-tick retry loop). The 30s interval is
itself the retry — escalating retries would only extend the silence window
during a Control Center brownout, fighting the silence-is-signal model.

Opt-out for local dev: ``CONTROL_CENTER_HEARTBEAT_ENABLED=false``.
"""

from __future__ import annotations

import asyncio
import logging
import os
from datetime import datetime, timezone
from typing import Any, Callable

import httpx

from entr_adapter_core.app.versions import Versions

logger = logging.getLogger(__name__)


HEARTBEAT_TIMEOUT_SECONDS = 5.0
DEFAULT_INTERVAL_SECONDS = 30
DEFAULT_CONTROL_CENTER_URL = "https://entr-control-center.mijngarst.nl"


class HeartbeatConfigError(RuntimeError):
    """Raised when heartbeat is enabled but configuration is incomplete."""


def _truthy(value: str | None, *, default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in ("1", "true", "yes", "on")


def heartbeat_enabled() -> bool:
    if not _truthy(os.environ.get("CONTROL_CENTER_HEARTBEAT_ENABLED"), default=True):
        return False
    # Dev environments must not pollute the Control Center dashboard with
    # heartbeats from local laptops — those would compete with the real
    # tenant rows and trigger spurious silence alerts when a developer
    # closes their machine. Tenant compose files set `ENV=development` (or
    # `ENV=local` for the local-dev override service) for the dev profile,
    # and `ENV=production` for prod; some Core-style deployments use
    # `ENVIRONMENT` instead, so check both.
    env = (os.environ.get("ENV") or os.environ.get("ENVIRONMENT") or "").strip().lower()
    if env in ("development", "local"):
        return False
    return True


def heartbeat_config() -> tuple[str, str, int]:
    """Resolve (tenant, url, interval_seconds) from env vars.

    `TENANT_NAME` is the canonical tenant identifier in adapter containers
    (mapped from `TENANT_SLUG` on the host — see the prod compose).

    Raises :class:`HeartbeatConfigError` if neither `TENANT_NAME` nor
    `TENANT_SLUG` is set. Falling back to a placeholder like "unknown" would
    silently merge multiple misconfigured adapters into one row, masking the
    bug — failing fast is loud enough to fix.
    """
    tenant = os.environ.get("TENANT_NAME") or os.environ.get("TENANT_SLUG")
    if not tenant:
        raise HeartbeatConfigError(
            "Adapter heartbeat is enabled but neither TENANT_NAME nor "
            "TENANT_SLUG is set in the environment. Set one of them, or "
            "disable the heartbeat with CONTROL_CENTER_HEARTBEAT_ENABLED=false."
        )
    url = os.environ.get("CONTROL_CENTER_URL", DEFAULT_CONTROL_CENTER_URL)
    interval_str = os.environ.get("CONTROL_CENTER_HEARTBEAT_INTERVAL_SECONDS")
    try:
        interval = int(interval_str) if interval_str else DEFAULT_INTERVAL_SECONDS
    except ValueError:
        interval = DEFAULT_INTERVAL_SECONDS
    return tenant, url, interval


async def post_heartbeat(
    *,
    client: httpx.AsyncClient,
    tenant: str,
    control_center_url: str,
    status: str,
    details: dict[str, Any],
) -> None:
    """Send one heartbeat. Never raises — failures are logged and swallowed.

    Reuses the supplied AsyncClient so successive heartbeats reuse the same
    keep-alive connection / TLS session instead of paying the handshake cost
    every 30s.
    """
    # Path prefix `/api/cc/` matches the nginx + Next.js routing on the
    # office-server LiveCounterENTR repo: nginx forwards /api/cc/* to the
    # FastAPI backend with the prefix stripped, so this URL lands at
    # `POST /heartbeat/{tenant}/adapter` on the backend.
    url = f"{control_center_url.rstrip('/')}/api/cc/heartbeat/{tenant}/adapter"
    body = {
        "status": status,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "details": details,
    }
    try:
        resp = await client.post(url, json=body)
        if resp.status_code >= 400:
            logger.warning(
                "Heartbeat POST returned %s (tenant=%s) — silence-detector will catch it on the next interval",
                resp.status_code, tenant,
            )
    except httpx.HTTPError as exc:
        logger.warning(
            "Heartbeat POST failed (tenant=%s): %s — silence-detector will catch it on the next interval",
            tenant, exc,
        )


async def heartbeat_loop(
    *,
    tenant: str,
    control_center_url: str,
    interval_seconds: int,
    get_handlers: Callable[[], list[str]],
    versions: Versions | None = None,
) -> None:
    """Long-running asyncio task: send a heartbeat every `interval_seconds`.

    `versions` is captured once at startup (it doesn't change at runtime)
    and embedded in every heartbeat's `details` payload, so the Control
    Center dashboard doubles as a live "what's deployed where" inventory.
    """
    logger.info(
        "Adapter heartbeat starting — tenant=%s, target=%s, interval=%ds",
        tenant, control_center_url, interval_seconds,
    )
    static_details: dict[str, Any] = dict(versions or {})
    async with httpx.AsyncClient(timeout=HEARTBEAT_TIMEOUT_SECONDS) as client:
        try:
            while True:
                try:
                    details = {**static_details, "handlers": list(get_handlers())}
                    await post_heartbeat(
                        client=client,
                        tenant=tenant,
                        control_center_url=control_center_url,
                        status="ok",
                        details=details,
                    )
                except Exception:  # noqa: BLE001
                    # Loop must never die on a single failure.
                    logger.exception("Heartbeat iteration failed; continuing")
                await asyncio.sleep(interval_seconds)
        except asyncio.CancelledError:
            logger.info("Adapter heartbeat cancelled — shutting down cleanly")
            # Send one last "shutting down" heartbeat so the Control Center
            # can suppress a false `gone_silent` alert during a slow graceful
            # shutdown. Best-effort — if it fails, we just exit anyway.
            try:
                await post_heartbeat(
                    client=client,
                    tenant=tenant,
                    control_center_url=control_center_url,
                    status="ok",
                    details={**static_details, "handlers": list(get_handlers()), "shutting_down": True},
                )
            except Exception:  # noqa: BLE001
                pass
            raise
