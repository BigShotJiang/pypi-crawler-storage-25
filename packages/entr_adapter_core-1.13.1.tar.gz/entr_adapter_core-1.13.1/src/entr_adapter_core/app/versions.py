"""Helpers for collecting version info about the running adapter.

Three values:

- ``core_version``     — the ENTR-Core platform release the adapter was built
                          against. Read from ``core-version.txt`` at the
                          adapter project root, written there at build time
                          by the tenant's CI.
- ``adapter_version``  — the per-tenant adapter's own release. Read from
                          its ``pyproject.toml``.
- ``package_version``  — the version of this ``entr_adapter_core`` package
                          (i.e. ``entr_adapter_core.__version__``).

Used by both the existing ``/version`` endpoint and the heartbeat task —
the latter ships the versions as part of every heartbeat's ``details``
payload so the Control Center dashboard doubles as a live "what is
deployed where" inventory.
"""

from __future__ import annotations

import logging
import tomllib
from pathlib import Path
from typing import TypedDict

logger = logging.getLogger(__name__)


class Versions(TypedDict):
    core_version: str
    adapter_version: str
    package_version: str


def _read_pyproject_version(project_root: Path) -> str:
    pyproject_path = project_root / "pyproject.toml"
    if not pyproject_path.exists():
        return "unknown"
    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
        return data.get("project", {}).get("version", "unknown") or "unknown"
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not read adapter version from pyproject.toml: %s", exc)
        return "unknown"


def _read_core_version(project_root: Path) -> str:
    path = project_root / "core-version.txt"
    if not path.exists():
        return "unknown"
    try:
        return path.read_text().strip() or "unknown"
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not read core-version.txt: %s", exc)
        return "unknown"


def _package_version() -> str:
    try:
        from entr_adapter_core import __version__ as pkg_version
        return pkg_version or "unknown"
    except Exception:  # noqa: BLE001
        return "unknown"


def collect_versions(project_root: Path | None = None) -> Versions:
    """Return all three version strings for the running adapter.

    ``project_root`` defaults to ``Path.cwd()`` to match the existing
    ``/version`` endpoint's behavior — for the canonical ``uvicorn`` /
    Docker setup the cwd IS the adapter project root.
    """
    root = project_root or Path.cwd()
    return {
        "core_version": _read_core_version(root),
        "adapter_version": _read_pyproject_version(root),
        "package_version": _package_version(),
    }
