from pydantic import Field

from .types.meta import Entity


class BaseError(Exception):
    """Base exception for all ms api errors."""


class Error(Entity):
    error: str | None = Field(..., alias="error")
    parameter: str | None = Field(None, alias="parameter")
    code: int | None = Field(None, alias="code")
    error_message: str | None = Field(None, alias="error_message")
    more_info: str | None = Field(None, alias="moreInfo")
    line: int | None = Field(None, alias="line")
    column: int | None = Field(None, alias="column")
    dependencies: str | None = Field(None, alias="dependencies")


class MoyskladAPIError(BaseError):
    def __init__(self, errors: list[Error], http_status: int | None = None) -> None:
        self.errors = errors
        self.http_status = http_status

    def __str__(self) -> str:
        parts = []
        for e in self.errors:
            msg = e.error_message or e.error
            if e.more_info:
                msg += f" ({e.more_info})"
            parts.append(msg)
        return "; ".join(parts)

    def __repr__(self) -> str:
        return f"{type(self).__name__}('{self}', http_status={self.http_status})"
