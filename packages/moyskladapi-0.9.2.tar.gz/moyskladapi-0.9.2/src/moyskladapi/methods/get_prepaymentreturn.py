from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.prepaymentreturn import Prepaymentreturn
from .base import MSMethod


class GetPrepaymentreturn(MSMethod):
    """
    Средствами JSON API можно запрашивать списки Возвратов предоплат и сведения по отдельным
    Возвратам предоплат. Кодом сущности для Возврата предоплаты в составе JSON API является
    ключевое слово prepaymentreturn.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return
    """

    __return__ = Prepaymentreturn
    __api_method__ = "entity/prepaymentreturn"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return"

    id: str = Field(..., alias="prepaymentreturn_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
