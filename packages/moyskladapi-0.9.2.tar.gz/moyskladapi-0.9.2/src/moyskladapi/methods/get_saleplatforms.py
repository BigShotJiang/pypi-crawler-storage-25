from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.saleplatform import Saleplatform
from .base import MSMethod


class GetSaleplatforms(MSMethod):
    """
    Средствами JSON API можно просматривать сведения о Площадках для продаж, запрашивать списки
    Площадок для продаж и сведения по отдельным Площадкам для продаж. Кодом сущности для Площадки
    для продаж в составе JSON API является ключевое слово saleplatform.

    :param name: Наименование Площадки для продаж
    :param sale_platform_group: Группа площадок для продаж

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleplatform
    """

    __return__ = MetaArray[Saleplatform]
    __api_method__ = "entity/saleplatform"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleplatform"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
