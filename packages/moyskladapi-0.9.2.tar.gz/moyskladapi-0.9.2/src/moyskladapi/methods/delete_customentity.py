from pydantic import Field

from ..types.customentity import Customentity
from .base import MSMethod


class DeleteCustomentity(MSMethod[Customentity]):
    """
    Кодом сущности для Пользовательских справочников в составе JSON API является ключевое слово
    customentity.

    :param name: Наименование Пользовательского справочника

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
    """

    __return__ = Customentity
    __api_method__ = "entity/customentity"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity"

    id: str = Field(..., alias="customentity_id")
