from collections.abc import Sequence

from ..client.filters import Condition
from ..types.bonusprogram import Bonusprogram
from ..types.meta import MetaArray
from .base import MSMethod


class GetBonusprograms(MSMethod):
    """
    Кодом сущности для Бонусных программ в составе JSON API является ключевое слово bonusprogram.
    Перед работой со скидками настоятельно рекомендуем вам прочитать вот эту статью на портале
    поддержки МоегоСклада.

    :param active: Индикатор, является ли бонусная программа активной на данный момент
    :param agent_tags: Тэги контрагентов, к которым применяется бонусная программа. В случае
        пустого значения контрагентов в результате выводится пустой массив.
    :param all_agents: Индикатор, действует ли скидка на всех контрагентов (см. )
    :param all_products: Индикатор, действует ли бонусная программа на все товары (всегда `true`,
        см. )
    :param earn_rate_roubles_to_point: Курс начисления
    :param earn_while_redeeming: Разрешить одновременное начисление и списание бонусов. Если `true`
        - бонусы будут начислены на денежную часть покупки, даже при частичной оплате покупки
        баллами.
    :param max_paid_rate_percents: Максимальный процент оплаты баллами
    :param name: Наименование Бонусной программы
    :param postponed_bonuses_delay_days: Баллы начисляются через [N] дней
    :param spend_rate_points_to_rouble: Курс списания
    :param welcome_bonuses_enabled: Возможность начисления приветственных баллов
    :param welcome_bonuses_mode: Условие начисления приветственных баллов. Не может быть пустым,
        если `welcomeBonusesEnabled` = true.
    :param welcome_bonuses_value: Количество приветственных баллов, начисляемых участникам бонусной
        программы. Не может быть отрицательным. Не может быть пустым, если `welcomeBonusesEnabled`
        = true

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-program
    """

    __return__ = MetaArray[Bonusprogram]
    __api_method__ = "entity/bonusprogram"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-program"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
