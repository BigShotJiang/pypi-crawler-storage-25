from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.discount import Discount
from .base import MSMethod


class GetDiscount(MSMethod):
    """
    Кодом сущности для Скидок в составе JSON API является ключевое слово discount. Операции
    создания, изменения и удаления не поддерживаются. Перед работой со скидками настоятельно
    рекомендуем вам прочитать вот эту статью на портале поддержки МоегоСклада.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/discount
    """

    __return__ = Discount
    __api_method__ = "entity/discount"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/discount"

    id: str = Field(..., alias="discount_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
