from collections.abc import Sequence

from ..client.filters import Condition
from ..types.customentity import Customentity
from ..types.meta import MetaArray
from .base import MSMethod


class GetCustomentities(MSMethod):
    """
    Кодом сущности для Пользовательских справочников в составе JSON API является ключевое слово
    customentity.

    :param name: Наименование Пользовательского справочника

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
    """

    __return__ = MetaArray[Customentity]
    __api_method__ = "entity/customentity"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
