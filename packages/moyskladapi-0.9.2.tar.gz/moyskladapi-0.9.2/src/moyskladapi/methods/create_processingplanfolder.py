from ..types.processingplanfolder import Processingplanfolder
from .base import MSMethod


class CreateProcessingplanfolder(MSMethod[Processingplanfolder]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Группах техкарт, запрашивать списки
    Групп техкарт и сведения по отдельным Группам техкарт. Кодом сущности для Группы техкарт в
    составе JSON API является ключевое слово processingplanfolder.

    :param archived: Добавлена ли Группа техкарт в архив
    :param external_code: Внешний код Группы техкарт
    :param code: Код Группы техкарт
    :param description: Описание Группы техкарт
    :param group: Метаданные отдела сотрудника
    :param name: Наименование Группы техкарт
    :param owner: Метаданные владельца (Сотрудника)
    :param path_name: Наименование Группы техкарт, в которую входит данная Группа техкарт
    :param shared: Общий доступ
    :param updated: Момент последнего обновления сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder
    """

    __return__ = Processingplanfolder
    __api_method__ = "entity/processingplanfolder"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplanfolder"

    data: Processingplanfolder
