from ..types.state import State
from .base import MSMethod


class UpdateStates(MSMethod[State]):
    """
    Кодом сущности для Статусов документов в составе JSON API является ключевое слово state.

    :param color: Цвет Статуса
    :param entity_type: Тип сущности, к которой относится Статус (ключевое слово в рамках JSON API)
    :param name: Наименование Статуса
    :param state_type: Тип Статуса

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/states
    """

    __return__ = list[State]
    __api_method__ = "entity/state"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/states"

    data: list[State]
