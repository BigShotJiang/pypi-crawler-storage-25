from ..types.paymentin import Paymentin
from .base import MSMethod


class CreatePaymentin(MSMethod[Paymentin]):
    """
    Средствами JSON API можно создавать и обновлять сведения о платеже , запрашивать списки
    Входящих платежей и сведения по отдельным Входящим платежам. Кодом сущности для Входящего
    платежа в составе JSON API является ключевое слово paymentin. Больше о платежах  и работе с
    ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Входящего платежа
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Входящего платежаа
    :param description: Комментарий Входящего платежа
    :param external_code: Внешний код Входящего платежа
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param incoming_date: Входящая дата
    :param incoming_number: Входящий номер
    :param moment: Дата документа
    :param name: Наименование Входящего платежа
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payment_purpose: Назначение платежа
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param sales_channel: Метаданные канала продаж
    :param state: Метаданные статуса Входящего платежа
    :param sum: Сумма Входящего платежа в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Входящего платежа
    :param vat_sum: Сумма НДС
    :param facture_out: Ссылка на Счет-фактуру выданный, с которым связан этот платеж в формате
    :param operations: Массив ссылок на связанные операции в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in
    """

    __return__ = Paymentin
    __api_method__ = "entity/paymentin"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-in"

    data: Paymentin
