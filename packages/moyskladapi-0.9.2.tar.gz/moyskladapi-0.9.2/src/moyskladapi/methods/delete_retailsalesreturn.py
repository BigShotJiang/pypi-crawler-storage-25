from pydantic import Field

from ..types.retailsalesreturn import Retailsalesreturn
from .base import MSMethod


class DeleteRetailsalesreturn(MSMethod[Retailsalesreturn]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Розничных возвратах, запрашивать
    списки Розничных возвратов и сведения по отдельным Розничным возвратам. Позициями Розничных
    возвратов  можно управлять как в составе отдельного Возврата, так и отдельно - с помощью
    специальных ресурсов для управления позициями Розничного возврата. Кодом сущности для
    Розничного возврата в составе JSON API является ключевое слово retailsalesreturn.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param cash_sum: Оплачено наличными
    :param code: Код Розничного возврата
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Розничного возврата
    :param demand: Метаданные связанной Розничной продажи
    :param description: Комментарий Розничного возврата
    :param external_code: Внешний код Розничного возврата
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Розничного возврата
    :param no_cash_sum: Оплачено картой
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Розничного возврата
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param qr_sum: Оплачено по QR-коду
    :param rate: Валюта.
    :param retail_shift: Метаданные Розничной смены
    :param retail_store: Метаданные Точки продаж
    :param shared: Общий доступ
    :param state: Метаданные статуса Розничного возврата
    :param store: Метаданные склада
    :param sum: Сумма Розничного возврата в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param tax_system: Код системы налогообложения.
    :param updated: Момент последнего обновления Розничного возврата
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return
    """

    __return__ = Retailsalesreturn
    __api_method__ = "entity/retailsalesreturn"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retail-sales-return"

    id: str = Field(..., alias="retailsalesreturn_id")
