from ..types.file import File
from .base import MSMethod


class DeleteFile(MSMethod):
    """
    Удалить Файл у Операции, Номенклатуры, Задачи или Контрагента.

    Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files
    """

    __return__ = File
    __http_method__ = "DELETE"
    __api_method__ = "entity/{type}/{id}/files/{file_id}"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files"

    type: str
    id: str
    file_id: str
