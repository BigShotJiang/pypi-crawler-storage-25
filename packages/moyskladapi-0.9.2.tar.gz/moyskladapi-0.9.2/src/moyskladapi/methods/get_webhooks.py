from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.webhook import Webhook
from .base import MSMethod


class GetWebhooks(MSMethod):
    """
    Пример того, в каком виде будут передаваться данные:

    :param events: Данные о событии, вызвавшем срабатывание вебхука
    :param audit_context: Контекст аудита, соответствующий событию вебхука
    :param action: Действие, которое вызвало срабатывание вебхука. Возможные значения: `[CREATE,
        UPDATE, DELETE, PROCESSED]`
    :param updated_fields: Поля сущности, измененные пользователем
    :param uid: Логин Сотрудника
    :param moment: Дата изменения
    :param author_application: Метаданные Решения, создавшего вебхук
    :param diff_type: Режим отображения изменения сущности. Указывается только для действия
        `UPDATE`. Возможные значения: `[NONE, FIELDS]` (по умолчанию `NONE`)
    :param enabled: Флажок состояние вебхука (включен / отключен)
    :param entity_type: Тип сущности, к которой привязан вебхук
    :param method: HTTP метод, с которым будет происходить запрос. Возможные значения: `POST`
    :param url: URL, по которому будет происходить запрос. Допустимая длина до 255 символов

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook
    """

    __return__ = MetaArray[Webhook]
    __api_method__ = "entity/webhook"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhook"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
