from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.namedfilter import Namedfilter
from .base import MSMethod


class GetNamedfilter(MSMethod):
    """
    Кодом сущности для Сохраненных фильтров в составе JSON API является ключевое слово namedfilter.

    :param name: Название фильтра
    :param owner: Владелец (Сотрудник)

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/named-filter
    """

    __return__ = Namedfilter
    __api_method__ = "entity/namedfilter"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/named-filter"

    id: str = Field(..., alias="namedfilter_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
