from pydantic import Field

from ..types.bonustransaction import Bonustransaction
from .base import MSMethod


class DeleteBonustransaction(MSMethod[Bonustransaction]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Бонусных операциях, запрашивать
    списки Бонусных операций и сведения по отдельным Бонусым операциям. Кодом сущности для Бонусной
    операции в составе JSON API является ключевое слово bonustransaction.

    :param agent: Метаданные Контрагента, связанного с бонусной операцией
    :param applicable: Отметка о проведении
    :param bonus_program: Метаданные бонусной программы
    :param bonus_value: Количество бонусных баллов
    :param category_type: Категория бонусной операции. Возможные значения: `REGULAR`, `WELCOME`
    :param code: Код Бонусной операции
    :param created: Момент создания Бонусной операции
    :param description: Комментарий к Бонусной операции
    :param execution_date: Дата начисления бонусной операции
    :param external_code: Внешний код Бонусной операции
    :param group: Отдел сотрудника
    :param moment: Время проведения бонусной операции
    :param name: Наименование Бонусной операции
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param parent_document: Метаданные связанного документа бонусной операции
    :param shared: Общий доступ
    :param transaction_status: Статус бонусной операции. Возможные значения: `WAIT_PROCESSING`,
        `COMPLETED`, `CANCELED`
    :param transaction_type: Тип бонусной операции. Возможные значения: `EARNING`, `SPENDING`
    :param updated: Момент последнего обновления Бонусной операции
    :param updated_by: Автор последнего обновления бонусной операции в формате `uid`
        (`admin@admin`) (Атрибут используется только для фильтрации)

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation
    """

    __return__ = Bonustransaction
    __api_method__ = "entity/bonustransaction"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bonus-operation"

    id: str = Field(..., alias="bonustransaction_id")
