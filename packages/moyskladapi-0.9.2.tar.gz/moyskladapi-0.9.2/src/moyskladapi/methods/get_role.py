from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.role import Role
from .base import MSMethod


class GetRole(MSMethod):
    """
    Кодом сущности для Пользовательской роли в составе JSON API является ключевое слово role.

    :param name: Наименование пользовательской роли

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/custom-role
    """

    __return__ = Role
    __api_method__ = "entity/role"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/custom-role"

    id: str = Field(..., alias="role_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
