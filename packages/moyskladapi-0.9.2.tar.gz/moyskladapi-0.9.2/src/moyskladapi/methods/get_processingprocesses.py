from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.processingprocess import Processingprocess
from .base import MSMethod


class GetProcessingprocesses(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Техпроцессах, запрашивать списки
    Техпроцессов и сведения по отдельным Техпроцессам. Позициями Техпроцессов можно управлять как в
    составе отдельного Техпроцесса, так и отдельно - с помощью специальных ресурсов для управления
    позициями Техпроцессов. Кодом сущности для Техпроцессов в составе JSON API является ключевое
    слово processingprocess. Больше о Техпроцессах и работе с ними в основном интерфейсе вы можете
    прочитать в нашей службе поддержки по этой ссылке.

    :param archived: Добавлен ли Техпроцесс в архив
    :param description: Комментарий Техпроцесса
    :param external_code: Внешний код Техпроцесса
    :param group: Отдел сотрудника
    :param name: Наименование Техпроцесса
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Техпроцесса
    :param shared: Общий доступ
    :param updated: Момент последнего обновления сущности
    :param processingstage: Метаданные этапа, который представляет собой позиция
    :param next_positions: Метаданные следующих позиций позиции Техпроцесса

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess
    """

    __return__ = MetaArray[Processingprocess]
    __api_method__ = "entity/processingprocess"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingprocess"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
