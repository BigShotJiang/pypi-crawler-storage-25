from pydantic import Field

from ..types.loss import Loss
from .base import MSMethod


class DeleteLoss(MSMethod[Loss]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Списаниях, запрашивать списки
    Списаний и сведения по отдельным Списаниям. Позициями Списаний можно управлять как в составе
    отдельного Списания, так и отдельно - с помощью специальных ресурсов для управления позициями
    Списания. Кодом сущности для Списания в составе JSON API является ключевое слово loss. Больше о
    Списаниях можно прочитать этой ссылке.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Списания
    :param created: Дата создания
    :param deleted: Момент последнего удаления Списания
    :param description: Комментарий Списания
    :param expense_item: Метаданные Статьи расходов
    :param external_code: Внешний код Списания
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Списания
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Списания
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Списания
    :param store: Метаданные склада
    :param sum: Сумма Списания в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Списания
    :param sales_return: Ссылка на связанный со списанием возврат покупателя в формате
    :param inventory: Ссылка на связанную со списанием инвентаризацию в формате
    :param gtd: Регистрационный номер партии товара
    :param rnpt: Грузовая таможенная декларация
    :param country: Страна происхождения товара
    :param quantity: Количество товара с указанными ГТД или РНПТ в позиции документа

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss
    """

    __return__ = Loss
    __api_method__ = "entity/loss"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/loss"

    id: str = Field(..., alias="loss_id")
