from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.stock import Stock
from .base import MSMethod


class GetStock(MSMethod):
    """
    Расширенный отчёт об остатках.

    Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-stock
    """

    __return__ = MetaArray[Stock]
    __api_method__ = "report/stock/all"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-stock"

    limit: int | None = None
    offset: int | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
    group_by: str | None = None
    include_related: bool | None = None
