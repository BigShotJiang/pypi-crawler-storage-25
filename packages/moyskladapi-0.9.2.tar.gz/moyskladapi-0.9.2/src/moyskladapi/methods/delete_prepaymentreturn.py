from pydantic import Field

from ..types.prepaymentreturn import Prepaymentreturn
from .base import MSMethod


class DeletePrepaymentreturn(MSMethod[Prepaymentreturn]):
    """
    Средствами JSON API можно запрашивать списки Возвратов предоплат и сведения по отдельным
    Возвратам предоплат. Кодом сущности для Возврата предоплаты в составе JSON API является
    ключевое слово prepaymentreturn.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return
    """

    __return__ = Prepaymentreturn
    __api_method__ = "entity/prepaymentreturn"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return"

    id: str = Field(..., alias="prepaymentreturn_id")
