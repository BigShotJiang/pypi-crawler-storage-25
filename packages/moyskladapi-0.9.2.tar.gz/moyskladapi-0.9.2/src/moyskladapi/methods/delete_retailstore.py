from pydantic import Field

from ..types.retailstore import Retailstore
from .base import MSMethod


class DeleteRetailstore(MSMethod[Retailstore]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Точках продаж, запрашивать списки
    Точек продаж и сведения по отдельным Точкам продаж. Также можно получить доступ к специальному
    ресурсу для управления кассирами точки продаж. Кодом сущности для точки продаж в составе JSON
    API является ключевое слово retailstore. Больше о точках продаж и работе с ними в основном
    интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке в разделе "Создание
    точки продаж в основном интерфейсе". По данной сущности можно осуществлять контекстный поиск с
    помощью специального параметра search. Подробнее можно узнать

    :param acquire: Метаданные Банка-эквайера по операциям по карте
    :param active: Состояние точки продаж (Включена/Отключена)
    :param address: Адрес Точки продаж
    :param address_full: Адрес с детализацией по отдельным полям.
    :param allow_create_products: Контроль остатков. Не может быть `true`, если
        `controlShippingStock` имеет значение `true`
    :param allow_custom_price: Разрешить продажу по свободной цене
    :param allow_delete_receipt_positions: Разрешить удалять позиции в чеке по умолчанию
    :param allow_sell_tobacco_without_mrc: Разрешить продавать табачную продукцию не по МРЦ
    :param archived: Добавлена ли Точка продаж в архив
    :param auth_token_attached: Создан ли токен для точки продаж
    :param bank_percent: Комиссия банка-эквайера по операциям по карте (в процентах)
    :param cashiers: Метаданные Кассиров
    :param control_cashier_choice: Выбор продавца
    :param control_shipping_stock: Контроль остатков. Не может быть `true`, если
        `AllowCreateProducts` имеет значение `true`
    :param create_agents_tags: Коллекция групп покупателей, представленных в формате строк.
        Определяет группы, в которые добавляются новые покупатели. Значения `null` игнорируются
    :param create_cash_in_on_retail_shift_closing: Создавать ПКО при закрытии смены
    :param create_order_with_state: Метаданные статуса, который будет указан при создании заказа
    :param create_payment_in_on_retail_shift_closing: Создавать входящий платеж при закрытии смены
    :param customer_order_states: Метаданные статусов, в которых выгружаются заказы в точку продаж
        (если указано)
    :param default_tax_system: Код системы налогообложения по умолчанию.
    :param demand_prefix: Префикс номера продаж
    :param description: Комментарий к Точке продаж
    :param discount_enable: Разрешить скидки
    :param discount_max_percent: Максимальная скидка (в процентах)
    :param enable_returns_with_no_reason: Разрешить возвраты без основания
    :param environment: Информация об окружении.
    :param external_code: Внешний код Точки продаж
    :param filter_agents_tags: Коллекция групп покупателей, представленных в формате строк.
        Определяет группы, из которых выгружаются покупатели. Значения `null` игнорируются
    :param fiscal_type: Тип формирования чеков.
    :param group: Отдел сотрудника
    :param id_qr: Идентификатор устройства QR (IdQR) для решения оплаты по QR
    :param issue_orders: Выдача заказов
    :param last_operation_names: Последние операции.
    :param marking_selling_mode: Режим продажи маркированной продукции, если используется формат
        фискальных документов версии 1.2.
    :param marks_check_mode: Настройка проверки КМ перед продажей в ГИС МТ (по умолчанию
        CORRECT_MARKS_ONLY)
    :param master_retail_stores: Ссылка на точки продаж, которые могут фискализировать операции с
        текущей точки продаж, если `minionToMaster` = `CHOSEN`
    :param minion_to_master_type: Стратегия выбора кассы для фискализации облачных чеков.
    :param name: Наименование Точки продаж
    :param ofd_enabled: Отправлять электронный чек через ОФД
    :param only_in_stock: Выгружать только товары в наличии. Доступно только при активном контроле
        остатков. Влияет только на выгрузку остатков в POS API
    :param order_tax_system: Код системы налогообложения для заказов.
    :param order_to_state: Метаданные статуса, который проставится заказу после проведения продажи
        на его основании (если указано)
    :param organization: Метаданные Юрлица
    :param owner: Владелец (Сотрудник)
    :param price_type: Тип цен, с которыми будут продаваться товары в рознице
    :param print_always: Всегда печатать кассовые чеки
    :param priority_ofd_send: Приоритет отправки электронного чека. Активен только, когда отправка
        электронных чеков через ОФД включена.
    :param product_folders: Коллекция Метаданных групп товаров, из которых можно выгружать товары
    :param qr_acquire: Метаданные Банка-эквайера по операциям по QR-коду
    :param qr_bank_percent: Комиссия банка-эквайера по операция по QR-коду (в процентах)
    :param qr_pay_enabled: Возможность оплаты по QR-коду на точке продаж
    :param qr_terminal_id: Идентификатор терминала (TerminalID) для решения оплаты по QR
    :param receipt_template: Метаданные шаблона печати кассовых чеков
    :param required_fio: Обязательность поля ФИО при создании контрагента по умолчанию
    :param required_phone: Обязательность поля телефон при создании контрагента по умолчанию
    :param required_email: Обязательность поля эл. почта при создании контрагента по умолчанию
    :param required_birthdate: Обязательность поля дата рождения при создании контрагента по
        умолчанию
    :param required_sex: Обязательность поля пол при создании контрагента по умолчанию
    :param required_discount_card_number: Обязательность поля номер бонусной карты при создании
        контрагента по умолчанию
    :param reserve_prepaid_goods: Резервировать товары, за которые внесена предоплата
    :param return_from_closed_shift_enabled: Разрешить возвраты в закрытых сменах
    :param sell_reserves: Учет резервов
    :param send_marks_for_check: Для облачных точек — до продажи отправлять коды маркировки на
        проверку на точку с ККТ
    :param send_marks_to_chestny_znak_on_cloud: Для облачных точек — отправлять коды маркировки на
        проверку в Честный Знак по умолчанию
    :param sync_agents: Выгружать покупателей для работы оффлайн по умолчанию
    :param shared: Общий доступ
    :param show_beer_on_tap: Отображать или нет вскрытые кеги на кассе по умолчанию
    :param state: Информация статусе точки продаж.
    :param store: Метаданные Склада
    :param tobacco_mrc_control_type: Контроль МРЦ для табачной продукции.
    :param updated: Момент последнего обновления Точки продаж
    :param phone: Приоритет отправки на телефон
    :param email: Приоритет отправки на e-mail
    :param none: Отсутствие отправки чека
    :param device: Информация об устройстве
    :param os: Информация об операционной системе
    :param software: Информация о ПО.
    :param cheque_printer: Данные о ККТ.
    :param payment_terminal: Информация о платежном терминале
    :param vendor: Производитель
    :param version: Версия ПО
    :param driver: Информация об используемом драйвере.
    :param firmware_version: Версия прошивки ККТ
    :param fiscal_data_version: Формат фискальных данных
    :param fiscal_memory: Информация о фискальном накопителе.
    :param serial: Серийный номер
    :param fiscal_validity_date: Версия фискальной памяти
    :param sync: Состояние синхронизации.
    :param last_check_moment: Дата и время последней синхронизации
    :param message: Состояние синхронизации
    :param last_attemp_moment: Дата последней сихронизации (не обязательно успешной)
    :param error: Информация об ошибке ФН.
    :param not_send_doc_count: Количество неотправленных документов в ОФД
    :param not_send_first_doc_moment: Время начала не отправки документов
    :param сode: Код ошибки ФН
    :param acquiring_type: Информация о типе эквайера (например: inpas/payme)
    :param add_info: Другое
    :param apartment: Квартира
    :param city: Город
    :param comment: Комментарий
    :param country: Метаданные страны
    :param house: Дом
    :param postal_code: Почтовый индекс
    :param region: Метаданные региона
    :param street: Улица
    :param entity: Ключевое слово, обозначающее тип последней операции
    :param employee: Метаданные сотрудника, которого представляет собой кассир
    :param retail_store: Метаданные точки продаж, к которой прикреплен кассир

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore
    """

    __return__ = Retailstore
    __api_method__ = "entity/retailstore"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/retailstore"

    id: str = Field(..., alias="retailstore_id")
