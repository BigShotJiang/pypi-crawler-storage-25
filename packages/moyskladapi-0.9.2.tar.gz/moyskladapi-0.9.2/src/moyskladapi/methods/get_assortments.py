from collections.abc import Sequence

from ..client.filters import Condition
from ..types.assortment import Assortment
from ..types.meta import MetaArray
from .base import MSMethod


class GetAssortments(MSMethod):
    """
    Результаты запроса можно отфильтровать, используя параметр filter.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/assortment
    """

    __return__ = MetaArray[Assortment]
    __api_method__ = "entity/assortment"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/assortment"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
