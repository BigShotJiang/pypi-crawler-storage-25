from ..types.contract import Contract
from .base import MSMethod


class UpdateContracts(MSMethod[Contract]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Договорах, запрашивать списки
    Договоров и сведения по отдельным Договорам. Кодом сущности для Договора в составе JSON API
    является ключевое слово contract. Больше о Договорах и работе с ними в основном интерфейсе вы
    можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
    контекстный поиск с помощью специального параметра search. Подробнее можно узнать по ссылке.
    Поиск с параметром search отличается от других тем, что поиск не префиксный, без токенизации и
    идет только по одному полю одновременно. Ищет такие строки, в которые входит значение строки
    поиска.

    :param agent: Метаданные Контрагента
    :param agent_account: Метаданные счета контрагента
    :param archived: Добавлен ли Договор в архив
    :param attributes: Коллекция доп. полей
    :param code: Код Договора
    :param contract_type: Тип Договора. Возможные значения: `Договор комиссии`, `Договор купли-
        продажи`
    :param description: Описание Договора
    :param external_code: Внешний код Договора
    :param group: Метаданные отдела сотрудника
    :param moment: Дата Договора
    :param name: Номер договора
    :param organization_account: Метаданные счета вашего юрлица
    :param own_agent: Метаданные вашего юрлица
    :param owner: Метаданные владельца (Сотрудника)
    :param rate: Метаданные валюты
    :param reward_percent: Вознаграждение в процентах (от 0 до 100)
    :param reward_type: Тип Вознаграждения. Возможные значения: `Процент от суммы продажи`, `Не
        рассчитывать`
    :param shared: Общий доступ
    :param state: Метаданные статуса договора
    :param sum: Сумма Договора
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param updated: Момент последнего обновления сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract
    """

    __return__ = list[Contract]
    __api_method__ = "entity/contract"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contract"

    data: list[Contract]
