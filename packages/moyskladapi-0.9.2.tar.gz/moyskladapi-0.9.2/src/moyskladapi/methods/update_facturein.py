from pydantic import Field

from ..types.facturein import Facturein
from .base import MSMethod


class UpdateFacturein(MSMethod[Facturein]):
    """
    Средствами JSON API можно создавать и изменять Счета-фактуры полученные, запрашивать списки
    Счетов-фактур полученных, сведения по отдельным Счетам-фактурам и удалять Счета-фактуры. Счет-
    фактура может быть создана только на основании приемки или исходящего платежа, без документа-
    основания счет-фактуру создать нельзя.  Кодом сущности для Счета-фактуры полученного в составе
    JSON API является ключевое слово facturein.

    :param agent: Метаданные контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Счета-фактуры полученного
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Счета-фактуры полученного
    :param description: Комментарий Счета-фактуры полученного
    :param external_code: Внешний код Счета-фактуры полученного
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Счета-фактуры полученного
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Счета-фактуры полученного
    :param sum: Сумма Счета-фактуры полученного в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Счета-фактуры полученного
    :param supplies: Массив ссылок на связанные приемки в формате
    :param payments: Массив ссылок на связанные исходящие платежи в формате
    :param incoming_number: Входящий номер
    :param incoming_date: Входящая дата

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein
    """

    __return__ = Facturein
    __api_method__ = "entity/facturein"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/facturein"

    id: str = Field(..., alias="facturein_id")
    data: Facturein
