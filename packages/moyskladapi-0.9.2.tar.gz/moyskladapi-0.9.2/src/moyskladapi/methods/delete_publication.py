from pydantic import Field

from ..types.publication import Publication
from .base import MSMethod


class DeletePublication(MSMethod[Publication]):
    """
    JSON API позволяет опубликовать для общего пользования печатную форму документа, созданную на
    основе шаблона печатной формы. Кодом сущности для публикации в составе JSON API является
    ключевое слово publication.

    :param template: Метаданные Шаблона печати
    :param href: Ссылка на страницу Публикации

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/publication
    """

    __return__ = Publication
    __api_method__ = "entity/publication"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/publication"

    id: str = Field(..., alias="publication_id")
