from pydantic import Field

from ..types.counterparty import Counterparty
from .base import MSMethod


class UpdateCounterparty(MSMethod[Counterparty]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Контрагентах, запрашивать списки
    Контрагентов и сведения по отдельным Контрагентам. Счетами Контрагента и его контактными лицами
    можно управлять как в составе отдельного Контрагента, так и отдельно - с помощью специальных
    ресурсов для управления счетами и контактными лицами Контрагента. Кодом сущности для
    Контрагента в составе JSON API является ключевое слово counterparty. Больше о Контрагентах и
    работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
    ссылке. По данной сущности можно осуществлять контекстный поиск с помощью специального
    параметра search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается от
    других тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые входит
    значение строки поиска.

    :param accounts: Массив счетов Контрагентов.
    :param actual_address: Фактический адрес Контрагента
    :param actual_address_full: Фактический адрес Контрагента с детализацией по отдельным полям.
    :param archived: Добавлен ли Контрагент в архив
    :param attributes: Массив метаданных доп. полей
    :param bonus_points: Бонусные баллы по активной бонусной программе
    :param bonus_program: Метаданные активной Бонусной программы
    :param code: Код Контрагента
    :param company_type: Тип Контрагента. В зависимости от значения данного поля набор выводимых
        реквизитов контрагента может меняться.
    :param contactpersons: Массив контактных лиц фирмы Контрагента.
    :param created: Момент создания
    :param description: Комментарий к Контрагенту
    :param discount_card_number: Номер дисконтной карты Контрагента
    :param discounts: Массив скидок Контрагента. Массив может содержать персональные и
        накопительные скидки. Персональная скидка выводится, если хотя бы раз изменялся **процент
        скидки** для контрагента, значение будет указано в поле **personalDiscount**
    :param email: Адрес электронной почты
    :param external_code: Внешний код Контрагента
    :param fax: Номер факса
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param name: Наименование Контрагента
    :param notes: Массив событий Контрагента.
    :param owner: Владелец (Сотрудник)
    :param phone: Номер городского телефона
    :param price_type: Тип цены Контрагента.
    :param sales_amount: Сумма продаж
    :param shared: Общий доступ
    :param state: Метаданные Статуса Контрагента
    :param sync_id: ID синхронизации
    :param tags: Группы контрагента
    :param updated: Момент последнего обновления Контрагента
    :param birth_date: Дата рождения Контрагента типа `[Физическое лицо]`. Игнорируется для
        Контрагентов типов `[Индивидуальный предприниматель, Юридическое лицо]`
    :param certificate_date: Дата свидетельства
    :param certificate_number: Номер свидетельства
    :param inn: ИНН
    :param kpp: КПП
    :param legal_address: Юридический адрес Контрагента
    :param legal_address_full: Юридический адрес Контрагента с детализацией по отдельным полям
    :param legal_first_name: Имя для Контрагента типа `[Индивидуальный предприниматель, Физическое
        лицо]`. Игнорируется для Контрагентов типа `[Юридическое лицо]`
    :param legal_last_name: Фамилия для Контрагента типа `[Индивидуальный предприниматель,
        Физическое лицо]`. Игнорируется для Контрагентов типа `[Юридическое лицо]`
    :param legal_middle_name: Отчество для Контрагента типа `[Индивидуальный предприниматель,
        Физическое лицо]`. Игнорируется для Контрагентов типа `[Юридическое лицо]`
    :param legal_title: Полное наименование для Контрагента типа `[Юридическое лицо]`. Игнорируется
        для Контрагентов типа `[Индивидуальный предприниматель, Физическое лицо]`, если передано
        одно из значений для ФИО и формируется автоматически на основе получаемых ФИО Контрагента
    :param ogrn: ОГРН
    :param ogrnip: ОГРНИП
    :param okpo: ОКПО
    :param sex: Пол Контрагента.
    :param add_info: Другое
    :param apartment: Квартира
    :param city: Город
    :param comment: Комментарий
    :param country: Метаданные страны
    :param house: Дом
    :param postal_code: Почтовый индекс
    :param region: Метаданные региона
    :param street: Улица
    :param account_number: Номер счета
    :param bank_location: Адрес банка
    :param bank_name: Наименование банка
    :param bic: БИК
    :param correspondent_account: Корр счет
    :param is_default: Является ли счет основным счетом Контрагента
    :param agent: Метаданные контрагента
    :param position: Должность контактного лица
    :param author: Метаданные Сотрудника - создателя события (администратор аккаунта, если автор -
        решение)
    :param author_application: Метаданные Решения - создателя события
    :param oked: ОКЕД
    :param pinfl: ПИНФЛ
    :param vat_payer_reg_code: Регистрационный код плательщика НДС
    :param vat_certificate_date: Дата выдачи свидетельства плательщика НДС
    :param vat_certificate_number: Номер свидетельства плательщика НДС
    :param bin: БИН
    :param iin: ИИН
    :param kbe: КБе
    :param legal: Юридическое лицо
    :param entrepreneur: Индивидуальный предприниматель
    :param individual: Физическое лицо
    :param legal_uz: Юридическое лицо, Узбекистан
    :param entrepreneur_uz: Индивидуальный предприниматель, Узбекистан
    :param individual_uz: Физическое лицо, Узбекистан
    :param legal_kz: Юридическое лицо, Казахстан
    :param entrepreneur_kz: Индивидуальный предприниматель, Казахстан
    :param individual_kz: Физическое лицо, Казахстан

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty
    """

    __return__ = Counterparty
    __api_method__ = "entity/counterparty"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/counterparty"

    id: str = Field(..., alias="counterparty_id")
    data: Counterparty
