from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.region import Region
from .base import MSMethod


class GetRegion(MSMethod):
    """
    Средствами JSON API можно запрашивать список регионов России и сведения по отдельным регионам.
    Кодом сущности для Регионов в составе JSON API является ключевое слово region.

    :param code: Код Региона
    :param external_code: Внешний код Региона
    :param name: Наименование Региона
    :param updated: Момент последнего обновления сущности
    :param version: Версия сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/region
    """

    __return__ = Region
    __api_method__ = "entity/region"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/region"

    id: str = Field(..., alias="region_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
