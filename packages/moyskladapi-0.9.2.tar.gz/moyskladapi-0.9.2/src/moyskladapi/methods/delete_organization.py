from pydantic import Field

from ..types.organization import Organization
from .base import MSMethod


class DeleteOrganization(MSMethod[Organization]):
    """
    Средствами JSON API можно создавать и обновлять сведения о юрлицах, запрашивать списки юрлиц и
    сведения по отдельным юрлицам. С помощью специального ресурса можно управлять счетами
    отдельного юрлица. Кодом сущности для юрлица в составе JSON API является ключевое слово
    organization. По данной сущности можно осуществлять контекстный поиск с помощью специального
    параметра search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается от
    других тем, что поиск не префиксный и без токенизации. Ищет такие строки, в которые входит
    значение строки поиска

    :param actual_address: Фактический адрес Юрлица
    :param actual_address_full: Фактический адрес Юрлица с детализацией по отдельным полям.
    :param archived: Добавлено ли Юрлицо в архив
    :param bonus_points: Бонусные баллы по активной бонусной программе
    :param bonus_program: Метаданные активной бонусной программы
    :param code: Код Юрлица
    :param company_type: Тип Юрлица . В зависимости от значения данного поля набор выводимых
        реквизитов контрагента может меняться.
    :param created: Дата создания
    :param description: Комментарий к Юрлицу
    :param external_code: Внешний код Юрлица
    :param group: Отдел сотрудника
    :param name: Наименование Юрлица
    :param owner: Владелец (Сотрудник)
    :param shared: Общий доступ
    :param sync_id: ID синхронизации
    :param tracking_contract_date: Дата договора с ЦРПТ
    :param tracking_contract_number: Номер договора с ЦРПТ
    :param updated: Момент последнего обновления Юрлица
    :param accounts: Метаданные счетов юрлица
    :param advance_payment_vat: Налоговая ставка для авансов для плательщиков НДС. Можно
        использовать значение только из существующих
    :param attributes: Массив метаданных дополнительных полей юрлица
    :param certificate_date: Дата свидетельства
    :param certificate_number: Номер свидетельства
    :param chief_account_sign: Подпись главного бухгалтера.
    :param chief_accountant: Главный бухгалтер
    :param company_vat__ru: Настройки НДС
    :param director: Руководитель
    :param director_position: Должность руководителя
    :param director_sign: Подпись руководителя.
    :param email: Адрес электронной почты
    :param fax: Номер факса
    :param fsrar_id: Идентификатор в ФСРАР
    :param inn: ИНН
    :param is_egais_enable: Включен ли ЕГАИС для данного юрлица
    :param kpp: КПП
    :param legal_address: Юридический адреса Юрлица
    :param legal_address_full: Юридический адрес Юрлица с детализацией по отдельным полям
    :param legal_first_name: Имя для Юрлица типа `[Индивидуальный предприниматель, Физическое
        лицо]`. Игнорируется для Юрлиц типа `[Юридическое лицо]`
    :param legal_last_name: Фамилия для Юрлица типа `[Индивидуальный предприниматель, Физическое
        лицо]`. Игнорируется для Юрлиц типа `[Юридическое лицо]`
    :param legal_middle_name: Отчество для Юрлица типа `[Индивидуальный предприниматель, Физическое
        лицо]`. Игнорируется для Юрлиц типа `[Юридическое лицо]`
    :param legal_title: Полное наименование. Игнорируется, если передано одно из значений для ФИО.
        Формируется автоматически на основе получаемых ФИО Юрлица
    :param ogrn: ОГРН
    :param ogrnip: ОГРНИП
    :param okpo: ОКПО
    :param payer_vat: Является ли данное юрлицо плательщиком НДС
    :param phone: Номер городского телефона
    :param stamp: Печать.
    :param utm_url: IP-адрес УТМ
    :param add_info: Другое
    :param apartment: Квартира
    :param city: Город
    :param comment: Комментарий
    :param country: Метаданные страны
    :param house: Дом
    :param postal_code: Почтовый индекс
    :param region: Метаданные региона
    :param street: Улица
    :param use_company_vat: Признак использования НДС из карточки юрлица. Если `false` – все
        остальные поля объекта игнорируются
    :param default_company_vat: НДС‑ставка по умолчанию для юрлица. Передаётся в ответе только если
        `useCompanyVat == true`
    :param default_company_vat_enabled: Флаг, определяющий, следует ли выставлять «без НДС».
        Передаётся в ответе только если `useCompanyVat == true`
    :param title: Название Изображения
    :param filename: Имя файла
    :param miniature: Метаданные миниатюры изображения
    :param account_number: Номер счета
    :param agent: Метаданные юрлица
    :param bank_location: Адрес банка
    :param bank_name: Наименование банка
    :param bic: БИК
    :param correspondent_account: Корр счет
    :param is_default: Является ли счет основным счетом юрлица
    :param oked: ОКЕД
    :param pinfl: ПИНФЛ
    :param vat_payer_reg_code: Регистрационный код плательщика НДС
    :param vat_certificate_date: Дата выдачи свидетельства плательщика НДС
    :param vat_certificate_number: Номер свидетельства плательщика НДС
    :param bin: БИН
    :param iin: ИИН
    :param kbe: КБе
    :param legal: Юридическое лицо
    :param entrepreneur: Индивидуальный предприниматель
    :param individual: Физическое лицо
    :param legal_uz: Юридическое лицо, Узбекистан
    :param entrepreneur_uz: Индивидуальный предприниматель, Узбекистан
    :param individual_uz: Физическое лицо, Узбекистан
    :param legal_kz: Юридическое лицо, Казахстан
    :param entrepreneur_kz: Индивидуальный предприниматель, Казахстан
    :param individual_kz: Физическое лицо, Казахстан

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization
    """

    __return__ = Organization
    __api_method__ = "entity/organization"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/organization"

    id: str = Field(..., alias="organization_id")
