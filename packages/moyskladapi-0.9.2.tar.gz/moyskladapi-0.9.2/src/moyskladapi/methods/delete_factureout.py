from pydantic import Field

from ..types.factureout import Factureout
from .base import MSMethod


class DeleteFactureout(MSMethod[Factureout]):
    """
    Средствами JSON API можно создавать и изменять Счета-фактуры выданные, запрашивать списки
    Счетов-фактур выданных, сведения по отдельным Счетам-фактурам и удалять Счета-фактуры. Счет-
    фактура может быть создана только на основании отгрузки, возврата поставщику или входящего
    платежа, без документа-основания счет-фактуру создать нельзя. Кодом сущности для Счета-фактуры
    выданного в составе JSON API является ключевое слово factureout.

    :param agent: Метаданные контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Счета-фактуры выданного
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Счета-фактуры выданного
    :param description: Комментарий Счета-фактуры выданного
    :param external_code: Внешний код Счета-фактуры выданного
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Счета-фактуры выданного
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Счета-фактуры выданного
    :param state_contract_id: Идентификатор государственного контракта, договора (соглашения)
    :param sum: Сумма Счета-фактуры выданного в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Счета-фактуры выданного
    :param advance_payment_vat: Ставка НДС для авансового платежа (в процентах) Доступно только для
        счетов-фактур с основаниями-платежами
    :param payment_purpose: Назначение платежа Доступно только для счетов-фактур с основаниями-
        платежами
    :param vat_sum: Сумма включая НДС Доступно только для счетов-фактур с основаниями-платежами
    :param demands: Массив ссылок на связанные отгрузки в формате
    :param payments: Массив ссылок на связанные входящие платежи в формате
    :param returns: Массив ссылок на связанные возвраты поставщикам в формате
    :param consignee: Метаданные грузополучателя (контрагент или юрлицо)
    :param payment_number: Название платежного документа
    :param payment_date: Дата платежного документа

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout
    """

    __return__ = Factureout
    __api_method__ = "entity/factureout"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/factureout"

    id: str = Field(..., alias="factureout_id")
