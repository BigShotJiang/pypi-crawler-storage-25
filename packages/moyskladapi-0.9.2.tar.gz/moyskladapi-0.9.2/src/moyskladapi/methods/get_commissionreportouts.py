from collections.abc import Sequence

from ..client.filters import Condition
from ..types.commissionreportout import Commissionreportout
from ..types.meta import MetaArray
from .base import MSMethod


class GetCommissionreportouts(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Выданных отчетах комиссионера,
    запрашивать списки Выданных отчетов комиссионера и сведения по отдельным Выданным отчетам
    комиссионера. Позициями отчетов комиссионера можно управлять как в составе отдельного отчета,
    так и с помощью специальных ресурсов для управления позициями. Кодом сущности для Выданного
    отчета комиссионера в составе JSON API является ключевое слово commissionreportout. Больше об
    отчетах комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей службе
    поддержки по  этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Выданного отчета комиссионера
    :param commission_period_end: Конец периода
    :param commission_period_start: Начало периода
    :param commitent_sum: Сумма коммитента в установленной валюте
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Выданного отчета комиссионера
    :param description: Комментарий Выданного отчета комиссионера
    :param external_code: Внешний код Выданного отчета комиссионера
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Выданного отчета комиссионера
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Оплаченная сумма
    :param positions: Метаданные позиций Выданного отчета
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param reward_percent: Процент вознаграждения (всегда 0 если вознаграждение не рассчитывается)
    :param reward_type: Тип вознаграждения
    :param shared: Общий доступ
    :param sales_channel: Метаданные канала продаж
    :param state: Метаданные статуса Выданного отчета комиссионера
    :param sum: Сумма Выданного отчета комиссионера в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Выданного отчета комиссионера
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param payments: Массив ссылок на связанные платежи в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportout
    """

    __return__ = MetaArray[Commissionreportout]
    __api_method__ = "entity/commissionreportout"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportout"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
