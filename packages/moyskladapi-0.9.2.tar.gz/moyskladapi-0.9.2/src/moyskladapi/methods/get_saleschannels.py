from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.saleschannel import Saleschannel
from .base import MSMethod


class GetSaleschannels(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Каналах продаж, запрашивать списки
    Каналов продаж и сведения по отдельным Каналам продаж. Кодом сущности для Канала продаж в
    составе JSON API является ключевое слово saleschannel. Больше о Каналах продаж и работе с ними
    в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. По данной
    сущности можно осуществлять контекстный поиск с помощью специального параметра search.
    Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
    не префиксный, без токенизации и идет только по одному полю одновременно. Ищет такие строки, в
    которые входит значение строки поиска.

    :param archived: Добавлен ли Канал продаж в архив
    :param code: Код Канала продаж
    :param description: Описание Канала продаж
    :param external_code: Внешний код Канала продаж
    :param group: Метаданные отдела сотрудника
    :param name: Наименование Канала продаж
    :param owner: Метаданные владельца (Сотрудника)
    :param shared: Общий доступ
    :param type: Тип Канала продаж
    :param updated: Момент последнего обновления сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel
    """

    __return__ = MetaArray[Saleschannel]
    __api_method__ = "entity/saleschannel"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/saleschannel"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
