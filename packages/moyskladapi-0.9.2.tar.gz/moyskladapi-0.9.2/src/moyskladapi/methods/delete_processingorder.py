from pydantic import Field

from ..types.processingorder import Processingorder
from .base import MSMethod


class DeleteProcessingorder(MSMethod[Processingorder]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Заказах на производство, запрашивать
    списки Заказов и сведения по отдельным Заказам на производство. Позициями Заказов можно
    управлять как в составе отдельного Заказа на производство, так и отдельно - с помощью
    специальных ресурсов для управления позициями Заказа. Кодом сущности для Заказа на производство
    в составе JSON API является ключевое слово processingorder. Больше о Заказах на производство и
    работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
    ссылке.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Заказа на производство
    :param created: Дата создания
    :param deleted: Момент последнего удаления Заказа на производство
    :param delivery_planned_moment: Планируемая дата производства
    :param description: Комментарий Заказа на производство
    :param external_code: Внешний код Заказа на производство
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Заказа на производство
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Заказа на производство
    :param printed: Напечатан ли документ
    :param processing_plan: Метаданные Техкарты
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param quantity: Объем производства
    :param shared: Общий доступ
    :param state: Метаданные статуса Заказа на производство
    :param store: Метаданные склада
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновленияЗаказа на производство
    :param processings: Массив ссылок на связанные техоперации в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder
    """

    __return__ = Processingorder
    __api_method__ = "entity/processingorder"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processingorder"

    id: str = Field(..., alias="processingorder_id")
