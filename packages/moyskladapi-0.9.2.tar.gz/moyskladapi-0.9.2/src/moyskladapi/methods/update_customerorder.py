from pydantic import Field

from ..types.customerorder import Customerorder
from .base import MSMethod


class UpdateCustomerorder(MSMethod[Customerorder]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Заказах покупателя, запрашивать
    списки Заказов и сведения по отдельным Заказам покупателей. Позициями Заказов можно управлять
    как в составе отдельного Заказа покупателя, так и отдельно - с помощью специальных ресурсов для
    управления позициями Заказа. Кодом сущности для Заказа покупателя в составе JSON API является
    ключевое слово customerorder. Больше о Заказах покупателей и работе с ними в основном
    интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. Также в Заказе
    покупателя поддерживается протокол оповещения об изменениях виджетов вендоров - change-handler.
    Подробнее см. в документации для вендоров о виджетах.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Заказа покупателя
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Заказа покупателя
    :param delivery_planned_moment: Планируемая дата приёмки
    :param description: Комментарий Заказа покупателя
    :param external_code: Внешний код Заказа покупателя
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param invoiced_sum: Сумма счетов покупателю
    :param moment: Дата документа
    :param name: Наименование Заказа покупателя
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Сумма входящих платежей по Заказу
    :param positions: Метаданные позиций Заказа покупателя
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param reserved_sum: Сумма товаров в резерве
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param shipment_address: Адрес доставки Заказа покупателя
    :param shipment_address_full: Адрес доставки Заказа покупателя с детализацией по отдельным
        полям.
    :param shipped_sum: Сумма отгруженного
    :param state: Метаданные статуса заказа
    :param store: Метаданные склада
    :param sum: Сумма Заказа в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param tax_system: Код системы налогообложения.
    :param updated: Момент последнего обновления Заказа покупателя
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param purchase_orders: Массив ссылок на связанные заказы поставщикам в формате
    :param demands: Массив ссылок на связанные отгрузки в формате
    :param payments: Массив ссылок на связанные платежи в формате
    :param production_tasks: Массив ссылок на связанные производственные задания в формате
    :param invoices_out: Массив ссылок на связанные счета покупателям в формате
    :param moves: Массив ссылок на связанные перемещения в формате
    :param prepayments: Массив ссылок на связанные предоплаты в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder
    """

    __return__ = Customerorder
    __api_method__ = "entity/customerorder"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/customerOrder"

    id: str = Field(..., alias="customerorder_id")
    data: Customerorder
