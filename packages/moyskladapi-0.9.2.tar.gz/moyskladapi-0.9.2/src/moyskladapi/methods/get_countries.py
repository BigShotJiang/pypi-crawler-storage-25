from collections.abc import Sequence

from ..client.filters import Condition
from ..types.country import Country
from ..types.meta import MetaArray
from .base import MSMethod


class GetCountries(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Странах, запрашивать списки Стран и
    сведения по отдельным Странам. Кодом сущности для Страны в составе JSON API является ключевое
    слово country. По данной сущности можно осуществлять контекстный поиск с помощью специального
    параметра search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается от
    других тем, что поиск не префиксный, без токенизации и идет только по одному полю одновременно.
    Ищет такие строки, в которые входит значение строки поиска.

    :param code: Код Страны
    :param description: Описание Страны
    :param external_code: Внешний код Страны
    :param group: Отдел-владелец
    :param name: Наименование Страны
    :param owner: Сотрудник-владелец
    :param shared: Флаг Общий доступ
    :param updated: Момент последнего обновления сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country
    """

    __return__ = MetaArray[Country]
    __api_method__ = "entity/country"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/country"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
