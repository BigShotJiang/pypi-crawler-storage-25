from pydantic import Field

from ..types.uom import Uom
from .base import MSMethod


class DeleteUom(MSMethod[Uom]):
    """
    Кодом сущности для Единиц измерения в составе JSON API является ключевое слово uom. По данной
    сущности можно осуществлять контекстный поиск с помощью специального параметра search.
    Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
    не префиксный, без токенизации и идет только по одному полю одновременно. Ищет такие строки, в
    которые входит значение строки поиска.

    :param code: Код Единицы измерения
    :param description: Описание Единциы измерения
    :param external_code: Внешний код Единицы измерения
    :param group: Отдел сотрудника
    :param name: Наименование Единицы измерения
    :param owner: Владелец (Сотрудник)
    :param shared: Общий доступ
    :param updated: Момент последнего обновления Единицы измерения

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom
    """

    __return__ = Uom
    __api_method__ = "entity/uom"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/uom"

    id: str = Field(..., alias="uom_id")
