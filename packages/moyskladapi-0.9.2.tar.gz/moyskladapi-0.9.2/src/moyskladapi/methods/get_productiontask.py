from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.productiontask import Productiontask
from .base import MSMethod


class GetProductiontask(MSMethod):
    """
    Средствами JSON API можно обновлять сведения о Производственных заданиях, запрашивать списки
    Производственных заданий и сведения по отдельным Производственным заданиям. Позициями
    Производственных заданий можно управлять как в составе отдельного Производственного задания,
    так и отдельно - с помощью специальных ресурсов для управления позициями Производственных
    заданий. Кодом сущности для Производственных заданий в составе JSON API является ключевое слово
    productiontask. Больше о Производстве и Производственном задании и работе с ними в основном
    интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей
    :param awaiting: Флаг ожидания продукта Производственного задания
    :param code: Код Производственного задания
    :param created: Дата создания
    :param deleted: Момент последнего удаления Производственного задания
    :param delivery_planned_moment: Планируемая дата выполнения
    :param description: Комментарий Производственного задания
    :param external_code: Внешний код Производственного задания
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param materials_store: Метаданные склада материалов
    :param moment: Дата документа
    :param name: Наименование Производственного задания
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param production_rows: Метаданные Позиций производственного задания.
    :param production_end: Дата окончания производства
    :param production_start: Дата начала производства
    :param products: Метаданные производимой продукции.
    :param products_store: Метаданные склада продукции
    :param published: Опубликован ли документ
    :param reserve: Флаг резервирования материала Производственного задания
    :param shared: Общий доступ
    :param state: Метаданные статуса Производственного задания
    :param updated: Момент последнего обновления Производственного задания
    :param customer_orders: Массив ссылок на связанные заказы покупателей в формате
    :param emission_orders: Массив ссылок на связанные заказы кодов маркировки
    :param internal_orders: Массив ссылок на связанные внутренние заказы в формате
    :param moves: Массив ссылок на связанные перемещения в формате
    :param production_tasks: Массив ссылок на связанные производственные задания в качестве
        документов-оснований в формате
    :param production_task_supplies: Массив ссылок на связанные производственные задания в формате
    :param purchase_orders: Массив ссылок на связанные заказы поставщикам в формате
    :param supplies: Массив ссылок на связанные приемки в формате
    :param assortment: Ссылка на товар/партию/модификацию, которую представляет собой позиция.
    :param plan_quantity: Запланированное для производства количество продукта
    :param production_row: Метаданные

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask
    """

    __return__ = Productiontask
    __api_method__ = "entity/productiontask"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionTask"

    id: str = Field(..., alias="productiontask_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
