from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.contentcard import Contentcard
from .base import MSMethod


class GetContentcard(MSMethod):
    """
    Средствами JSON API можно просматривать сведения о Карточках контента, запрашивать списки
    Карточек контента и сведения по отдельным Карточкам контента. Кодом сущности для Карточки
    контента в составе JSON API является ключевое слово contentcard.

    :param assortment: Метаданные Ассортимента
    :param card_content_name: Как карточка контента отображается в списке на UI
    :param description: Описание товара или услуги
    :param group: Метаданные отдела сотрудника
    :param name: Название товара или услуги
    :param owner: Метаданные владельца (Сотрудника)
    :param shared: Общий доступ
    :param sale_platform: Метаданные Площадки для продаж. .
    :param sales_channels: Массив ссылок на связанные каналы продаж в формате . . Максимальное
        число - 1000. Для фильтрации по полю необходимо указывать его в единственном числе
        **salesChannel**.
    :param sales_channel: Канал продаж

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contentcard
    """

    __return__ = Contentcard
    __api_method__ = "entity/contentcard"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/contentcard"

    id: str = Field(..., alias="contentcard_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
