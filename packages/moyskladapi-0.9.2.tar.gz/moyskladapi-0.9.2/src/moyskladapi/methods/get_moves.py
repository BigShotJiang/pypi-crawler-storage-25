from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.move import Move
from .base import MSMethod


class GetMoves(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Перемещениях, запрашивать списки
    Перемещений и сведения по отдельным Перемещениям. Позициями Перемещений можно управлять как в
    составе отдельного Перемещения, так и отдельно - с помощью специальных ресурсов для управления
    позициями Перемещения. Кодом сущности для Перемещения в составе JSON API является ключевое
    слово move.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Перемещения
    :param created: Дата создания
    :param deleted: Момент последнего удаления Перемещения
    :param demand: Метаданные Отгрузки, связанной с Перемещением
    :param description: Комментарий Перемещения
    :param external_code: Внешний код Перемещения
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param internal_order: Метаданные Внутреннего заказа, связанного с Перемещением
    :param customer_order: Метаданные Заказа покупателя, связанного с Перемещением
    :param moment: Дата документа
    :param name: Наименование Перемещения
    :param organization: Метаданные юрлица
    :param overhead: Накладные расходы. . Если Позиции Перемещения не заданы, то накладные расходы
        нельзя задать
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Перемещения
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param source_store: Метаданные склада, с которого совершается перемещение
    :param state: Метаданные статуса Перемещения
    :param sum: Сумма Перемещения в копейках
    :param supply: Метаданные Приемки, связанной с Перемещением
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param target_store: Метаданные склада, на который совершается перемещение
    :param updated: Момент последнего обновления Перемещения
    :param distribution: Распределение накладных расходов `[weight, volume, price]` -> `[по весу,
        по объему, по цене]`
    :param production_tasks: Массив ссылок на связанные производственные задания в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move
    """

    __return__ = MetaArray[Move]
    __api_method__ = "entity/move"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/move"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
