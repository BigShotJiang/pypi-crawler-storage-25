from pydantic import Field

from ..types.consignment import Consignment
from .base import MSMethod


class UpdateConsignment(MSMethod[Consignment]):
    """
    Кодом сущности для Партии в составе JSON API является ключевое слово consignment. По данной
    сущности можно осуществлять контекстный поиск с помощью специального параметра search.
    Подробнее можно узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск
    не префиксный, без токенизации и идет только по одному полю одновременно. Ищет такие строки, в
    которые входит значение строки поиска.

    :param archived: Добавлена ли партия в архив
    :param attributes: Коллекция доп. полей Партии
    :param assortment: Метаданные товара/услуги/комплекта, которую представляет собой компонент
    :param barcodes: Штрихкоды партии . Для фильтрации по полю необходимо указывать его в
        единственном числе **barcode**.
    :param code: Код Партии
    :param description: Описание Партии
    :param expiry_date: Срок годности Партии
    :param external_code: Внешний код Партии
    :param images: Массив метаданных товара, к которому относится данная партия (Максимальное
        количество изображений - 10)
    :param label: Метка Партии
    :param name: Наименование Партии. "Собирается" и отображается как "Наименование товара / Метка
        Партии"
    :param updated: Момент последнего обновления сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment
    """

    __return__ = Consignment
    __api_method__ = "entity/consignment"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/consignment"

    id: str = Field(..., alias="consignment_id")
    data: Consignment
