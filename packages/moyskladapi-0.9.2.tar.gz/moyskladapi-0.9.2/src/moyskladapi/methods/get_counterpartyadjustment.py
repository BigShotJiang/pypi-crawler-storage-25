from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.counterpartyadjustment import Counterpartyadjustment
from .base import MSMethod


class GetCounterpartyadjustment(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Корректировках взаиморасчетов,
    запрашивать списки Корректировок взаиморасчетов и сведения по отдельным Корректировкам
    взаиморасчетов. Кодом сущности для Корректировки взаиморасчетов в составе JSON API является
    ключевое слово counterpartyadjustment. Больше о Корректировках взаиморасчетов и работе с ними в
    основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке.

    :param agent: Метаданные контрагента или сотрудника
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param created: Дата создания
    :param deleted: Момент последнего удаления Корректировки взаиморасчетов
    :param description: Комментарий Корректировки взаиморасчетов
    :param external_code: Внешний код Корректировки взаиморасчетов
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Корректировки взаиморасчетов
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param shared: Общий доступ
    :param sum: Сумма Корректировки взаиморасчетов в копейках
    :param updated: Момент последнего обновления Корректировки взаиморасчетов

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment
    """

    __return__ = Counterpartyadjustment
    __api_method__ = "entity/counterpartyadjustment"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/counterpartyadjustment"

    id: str = Field(..., alias="counterpartyadjustment_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
