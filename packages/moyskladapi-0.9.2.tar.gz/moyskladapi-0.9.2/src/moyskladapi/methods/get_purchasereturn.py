from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.purchasereturn import Purchasereturn
from .base import MSMethod


class GetPurchasereturn(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Возвратах поставщикам, запрашивать
    списки Возвратов поставщикам и сведения по отдельным Возвратам поставщикам. Позициями Возвратов
    поставщикам можно управлять как в составе отдельного Возврата, так и отдельно - с помощью
    специальных ресурсов для управления позициями Возврата поставщику. Кодом сущности для Возврата
    поставщику в составе JSON API является ключевое слово purchasereturn.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Возврата поставщику
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Возврата поставщику
    :param description: Комментарий Возврата поставщику
    :param external_code: Внешний код Возврата поставщику
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Возврата поставщику
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Возврата поставщику
    :param store: Метаданные склада
    :param sum: Сумма Возврата поставщику в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Возврата поставщику
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param positions: Ссылка на позиции Возврата поставщику в формате
    :param supply: Ссылка на приемку, по которой произошел возврат в формате Поле является
        необходимым для возврата с основанием.
    :param facture_out: Ссылка на Счет-фактуру выданный в формате
    :param facture_in: Ссылка на Счет-фактуру полученный в формате
    :param payed_sum: Сумма входящих платежей по возврату поставщику
    :param payments: Массив ссылок на связанные платежи в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return
    """

    __return__ = Purchasereturn
    __api_method__ = "entity/purchasereturn"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchase-return"

    id: str = Field(..., alias="purchasereturn_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
