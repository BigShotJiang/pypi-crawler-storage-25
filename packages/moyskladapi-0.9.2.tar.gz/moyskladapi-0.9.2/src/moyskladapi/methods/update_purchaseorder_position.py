from pydantic import Field

from ..types.purchaseorder import PurchaseorderPosition
from .base import MSMethod


class UpdatePurchaseorderPosition(MSMethod[PurchaseorderPosition]):
    """
    Запрос на обновление отдельной позиции Заказа поставщику.
    Все поля в теле запроса необязательны — указывайте только то, что хотите обновить.

    :param purchaseorder_id: id Заказа поставщику
    :param position_id: id позиции
    :param data: Поля позиции для обновления

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseorder
    """

    __return__ = PurchaseorderPosition
    __api_method__ = "entity/purchaseorder/{purchaseorder_id}/positions"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseorder"

    purchaseorder_id: str
    id: str = Field(..., alias="position_id")
    data: PurchaseorderPosition

    def _prepare_request_data(self, data: dict) -> dict:
        return data.get("data", {})
