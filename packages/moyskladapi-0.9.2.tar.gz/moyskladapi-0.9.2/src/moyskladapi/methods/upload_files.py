from ..types.file import File, FileInput
from .base import MSMethod


class UploadFiles(MSMethod):
    """
    Добавить новые Файлы к Операции, Номенклатуре или Контрагенту.
    Максимум 10 файлов за один запрос.

    Каждый элемент data: список объектов FileInput с полями 'filename' и 'content' (Base64).

    Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files
    """

    __return__ = list[File]
    __http_method__ = "POST"
    __api_method__ = "entity/{type}/{id}/files"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files"

    type: str
    id: str
    data: list[FileInput]
