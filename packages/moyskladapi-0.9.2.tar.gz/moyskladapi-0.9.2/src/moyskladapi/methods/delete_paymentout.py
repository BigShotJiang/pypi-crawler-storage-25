from pydantic import Field

from ..types.paymentout import Paymentout
from .base import MSMethod


class DeletePaymentout(MSMethod[Paymentout]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Исходящем платеже, запрашивать
    списки Исходящих платежей  и сведения по отдельным Исходящим платежам. Кодом сущности для
    Исходящего платежа  в составе JSON API является ключевое слово paymentout. Больше о платежа х и
    работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой
    ссылке.

    :param agent: Метаданные контрагента, сотрудника или юр.лица
    :param agent_account: Метаданные счета контрагента или юр.лица
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Исходящего платежа
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Исходящего платежа
    :param description: Комментарий Исходящего платежа
    :param expense_item: Метаданные Статьи расходов
    :param external_code: Внешний код Исходящего платежа
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param no_closing_docs: Признак "Без закрывающих документов". Нельзя одновременно передать
        **noClosingDocs = true** и непустой **operations**
    :param moment: Дата документа
    :param name: Наименование Исходящего платежа
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payment_purpose: Назначение платежа
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param state: Метаданные статуса Исходящего платежа
    :param sum: Сумма Исходящего платежа в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Исходящего платежа
    :param vat_sum: Сумма НДС
    :param facture_in: Ссылка на Счет-фактуру полученный, с которым связан этот платеж в формате
    :param operations: Массив ссылок на связанные операции в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out
    """

    __return__ = Paymentout
    __api_method__ = "entity/paymentout"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/payment-out"

    id: str = Field(..., alias="paymentout_id")
