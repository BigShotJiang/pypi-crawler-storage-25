from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.variant import Variant
from .base import MSMethod


class GetVariants(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Модификациях товаров, запрашивать
    списки Модификаций товаров и сведения по отдельным Модификациям. Кодом сущности для Модификации
    в составе JSON API является ключевое слово variant. Больше о Модификациях товаров и работе с
    ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке, а также
    больше о работе с товарами здесь. По данной сущности можно осуществлять контекстный поиск с
    помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с параметром
    search отличается от других тем, что поиск не префиксный, без токенизации и идет только по
    одному полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

    :param archived: Добавлен ли товар в архив
    :param barcodes: Массив штрихкодов модификации. . Для фильтрации по полю необходимо указывать
        его в единственном числе **barcode**.
    :param buy_price: Закупочная цена
    :param characteristics: Характеристики Модификации.
    :param code: Код Модификации
    :param description: Описание Модификации
    :param discount_prohibited: Признак запрета скидок
    :param external_code: Внешний код Модификации
    :param images: Массив метаданных (Максимальное количество изображений - 10)
    :param min_price: Минимальная цена.
    :param minimum_stock: Неснижаемый остаток.
    :param name: Наименование товара с Модификацией
    :param packs: Упаковки модификации
    :param product: Метаданные , к которому привязана Модификация
    :param sale_prices: Цены продажи.
    :param things: Серийные номера
    :param updated: Момент последнего обновления сущности
    :param ean13: штрихкод в формате EAN13, если требуется создать штрихкод в формате EAN13
    :param ean8: штрихкод в формате EAN8, если требуется создать штрихкод в формате EAN8
    :param code128: штрихкод в формате Code128, если требуется создать штрихкод в формате Code128
    :param gtin: штрихкод в формате GTIN, если требуется создать штрихкод в формате GTIN.
        Валидируется на соответствие формату GS1
    :param upc: штрихкод в формате UPC, если требуется создать штрихкод в формате UPC
    :param value: Значение характеристики
    :param required: Флаг о том, является ли характеристика обязательной
    :param type: Тип значения характеристики
    :param filename: Имя файла
    :param miniature: Метаданные миниатюры изображения
    :param tiny: Метаданные уменьшенного изображения
    :param title: Название Изображения
    :param content: Изображение, закодированное в формате Base64.
    :param currency: Ссылка на валюту в формате
    :param price_type: Тип цены
    :param inherited: Признак, наследуется ли Неснижаемый остаток от родительского товара
    :param quantity: Количество Неснижаемого остатка в сумме на всех складах
    :param storebalances: Количество Неснижаемого остатка заданное для каждого склада
    :param store: Метаданные склада для которого задан Неснижаемый остаток
    :param parentpack: Метаданные родительской упаковки (упаковки товара), для которой
        переопределяется штрихкод

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant
    """

    __return__ = MetaArray[Variant]
    __api_method__ = "entity/variant"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/variant"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
