from pydantic import Field

from ..types.supply import Supply
from .base import MSMethod


class DeleteSupply(MSMethod[Supply]):
    """
    Средствами JSON API можно создавать и обновлять сведения об Приемках, запрашивать списки
    Приемок и сведения по отдельным Приемкам. Позициями Приемок можно управлять как в составе
    отдельной Приемки, так и отдельно - с помощью специальных ресурсов для управления позициями
    Приемки. Кодом сущности для Приемки в составе JSON API является ключевое слово supply. Больше
    об Приемках и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
    по  этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Приемки
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Приемки
    :param description: Комментарий Приемки
    :param external_code: Внешний код Приемки
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param incoming_date: Входящая дата
    :param incoming_number: Входящий номер
    :param moment: Дата документа
    :param name: Наименование Приемки
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param overhead: Накладные расходы. . Если Позиции Приемки не заданы, то накладные расходы
        нельзя задать
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Сумма входящих платежей по Приемке
    :param positions: Метаданные позиций Приемки
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Приемки
    :param store: Метаданные склада
    :param sum: Сумма Приемки в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Приемки
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param distribution: Распределение накладных расходов `[weight, volume, price]` -> `[по весу,
        по объему, по цене]`
    :param purchase_order: Ссылка на связанный заказ поставщику в формате
    :param facture_in: Ссылка на Счет-фактуру полученный, с которым связана эта Приемка в формате
    :param invoices_in: Массив ссылок на связанные счета поставщиков в формате
    :param payments: Массив ссылок на связанные платежи в формате
    :param production_task: Ссылка на связанное производственное задание в формате
    :param returns: Массив ссылок на связанные возвраты в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
    """

    __return__ = Supply
    __api_method__ = "entity/supply"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply"

    id: str = Field(..., alias="supply_id")
