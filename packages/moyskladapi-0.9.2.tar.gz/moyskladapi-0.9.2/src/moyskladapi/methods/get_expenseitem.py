from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.expenseitem import Expenseitem
from .base import MSMethod


class GetExpenseitem(MSMethod):
    """
    Средствами JSON API можно запрашивать списки Статей расходов и сведения по отдельным Статьям
    расходов. Кодом сущности для Статей расходов в составе JSON API является ключевое слово
    expenseitem. Больше о Статьях расходов и работе с ними в основном интерфейсе вы можете
    прочитать в нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
    контекстный поиск с помощью специального параметра search. Подробнее можно узнать по ссылке.
    Поиск с параметром search отличается от других тем, что поиск не префиксный, без токенизации и
    идет только по одному полю одновременно. Ищет такие строки, в которые входит значение строки
    поиска.

    :param code: Код Статьи расходов
    :param description: Описание Статьи расходов
    :param external_code: Внешний код Статьи расходов
    :param name: Наименование Статьи расходов
    :param updated: Момент последнего обновления сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem
    """

    __return__ = Expenseitem
    __api_method__ = "entity/expenseitem"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/expenseitem"

    id: str = Field(..., alias="expenseitem_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
