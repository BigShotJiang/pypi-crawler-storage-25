from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.project import Project
from .base import MSMethod


class GetProjects(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Проектах, запрашивать списки
    Проектов и сведения по отдельным Проектам. Кодом сущности для Проекта в составе JSON API
    является ключевое слово project. Больше о Проектах и работе с ними в основном интерфейсе вы
    можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять
    контекстный поиск с помощью специального параметра search. Подробнее можно узнать по ссылке.
    Поиск с параметром search отличается от других тем, что поиск не префиксный, без токенизации и
    идет только по одному полю одновременно. Ищет такие строки, в которые входит значение строки
    поиска.

    :param archived: Добавлен ли Проект в архив
    :param attributes: Коллекция доп. полей
    :param code: Код Проекта
    :param description: Описание Проекта
    :param external_code: Внешний код Проекта
    :param group: Метаданные отдела сотрудника
    :param name: Наименование Проекта
    :param owner: Метаданные владельца (Сотрудника)
    :param shared: Общий доступ
    :param updated: Момент последнего обновления сущности

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project
    """

    __return__ = MetaArray[Project]
    __api_method__ = "entity/project"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/project"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
