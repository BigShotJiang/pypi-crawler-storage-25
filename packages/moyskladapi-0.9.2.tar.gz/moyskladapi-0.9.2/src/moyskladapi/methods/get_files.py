from ..types.file import File
from ..types.meta import MetaArray
from .base import MSMethod


class GetFiles(MSMethod):
    """
    Получить список Файлов Операции, Номенклатуры, Задачи или Контрагента.

    Источник: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files
    """

    __return__ = MetaArray[File]
    __api_method__ = "entity/{type}/{id}/files"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/files"

    type: str
    id: str
    limit: int | None = None
    offset: int | None = None
    order: str | None = None
