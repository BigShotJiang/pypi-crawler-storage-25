from ..types.emissionorder import Emissionorder
from .base import MSMethod


class CreateEmissionorder(MSMethod[Emissionorder]):
    """
    Для создания/изменения Заказов кодов маркировки необходима тарифная опция Маркировка для
    аккаунтов из RU региона и расширение Честный знак для остальных регионов.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
    """

    __return__ = Emissionorder
    __api_method__ = "entity/emissionorder"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder"

    data: Emissionorder
