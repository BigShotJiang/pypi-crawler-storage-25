from ..types.retireorder import Retireorder
from .base import MSMethod


class CreateRetireorder(MSMethod[Retireorder]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Выводе кодов маркировки из оборота,
    а также запрашивать списки документов и информацию о конкретных Выводах. Позициями можно
    управлять как в составе документа Вывода, так и отдельно - с помощью специальных ресурсов для
    управления позициями. Кодом сущности для Вывода из оборота в составе JSON API является ключевое
    слово retireorder. Больше о Выводах кодов из оборота можно прочитать здесь.

    :param agent: Метаданные контрагента
    :param created: Дата создания
    :param deleted: Момент последнего удаления Вывода из оборота
    :param description: Комментарий Вывода из оборота
    :param destination_country: Страна назначения
    :param document_state: Статус процесса вывода кодов маркировки из оборота.
    :param external_code: Внешний код Вывода из оборота
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Вывода из оборота
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Вывода из оборота
    :param primary_document_name: Наименование первичного документа
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param reason_description: Описание причины
    :param retire_order_type: Способ вывода из оборота.
    :param shared: Общий доступ
    :param state: Метаданные статуса Вывода из оборота
    :param state_contract_id: Идентификатор государственного контракта, договора (соглашения)
    :param supporting_transaction: Тип документа-основания.
    :param supporting_transaction_date: Дата документа-основания
    :param supporting_transaction_number: Номер документа-основания
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param tracking_type: Тип маркируемой продукции.
    :param updated: Момент последнего обновления Вывода из оборота.
    :param sum: Сумма вывода из оборота в установленной валюте
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder
    """

    __return__ = Retireorder
    __api_method__ = "entity/retireorder"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retireorder"

    data: Retireorder
