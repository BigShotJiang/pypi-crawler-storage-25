from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.emissionorder import Emissionorder
from .base import MSMethod


class GetEmissionorder(MSMethod):
    """
    Для создания/изменения Заказов кодов маркировки необходима тарифная опция Маркировка для
    аккаунтов из RU региона и расширение Честный знак для остальных регионов.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
    """

    __return__ = Emissionorder
    __api_method__ = "entity/emissionorder"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder"

    id: str = Field(..., alias="emissionorder_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
