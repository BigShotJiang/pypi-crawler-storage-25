from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.thing import Thing
from .base import MSMethod


class GetThings(MSMethod):
    """
    Средствами JSON API можно запрашивать списки Серийных номеров и сведения по отдельным Серийным
    номерам. Кодом сущности для Серийного номера в составе JSON API является ключевое слово thing.

    :param description: Описание Серийного номера
    :param name: Наименование Серийного номера

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/thing
    """

    __return__ = MetaArray[Thing]
    __api_method__ = "entity/thing"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/thing"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
