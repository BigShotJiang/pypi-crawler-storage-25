from pydantic import Field

from ..types.retailshift import Retailshift
from .base import MSMethod


class UpdateRetailshift(MSMethod[Retailshift]):
    """
    Средствами JSON API можно запрашивать списки Розничных смен и сведения по отдельным Розничным
    сменам. Кодом сущности для Розничной смены в составе JSON API является ключевое слово
    retailshift.

    :param acquire: Метаданные Банка-эквайера по операциям по карте
    :param agent_account: Метаданные счета контрагента
    :param attributes: Коллекция метаданных доп. полей.
    :param bank_comission: Сумма комиссии эквайера за проведение безналичных платежей по банковской
        карте. Не может превышать общую сумму безналичных платежей по карте. Если не указано,
        заполняется 0 автоматически.
    :param bank_percent: Комиссия банка-эквайера по операциям по карте (в процентах)
    :param cheque: Информация о смене ККТ.
    :param close_date: Дата закрытия смены
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Розничной смены
    :param description: Комментарий Розничной смены
    :param external_code: Внешний код Розничной смены
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата смены
    :param name: Наименование Розничной смены
    :param operations: Коллекция метаданных связанных операций
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payment_operations: Коллекция метаданных платежных операций
    :param printed: Напечатан ли документ
    :param proceeds_cash: Выручка наличными
    :param proceeds_no_cash: Выручка безнал
    :param published: Опубликован ли документ
    :param qr_acquire: Метаданные Банка-эквайера по операциям по QR-коду
    :param qr_bank_comission: Сумма комиссии эквайера за проведение безналичных платежей по QR-
        коду. Не может превышать общую сумму безналичных платежей по QR-коду. Если не указано,
        заполняется 0 автоматически.
    :param qr_bank_percent: Комиссия банка-эквайера по операция по QR-коду (в процентах)
    :param received_cash: Получено наличными
    :param received_no_cash: Получено безнал
    :param retail_store: Метаданные точки продаж
    :param shared: Общий доступ
    :param store: Метаданные склада. Если не указано, заполняется с точки продаж автоматически
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Розничной смены
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param start: Информация об открытии смены.
    :param end: Информация о закрытии смены
    :param fn_number: Номер фискального накопителя
    :param kkt_reg_number: Регистрационный номер ККТ
    :param fiscal_doc_sign: Фискальный признак документа
    :param shift_number: Номер смены ККТ
    :param fiscal_doc_number: Номер фискального документа
    :param time: Дата и время открытия смены.
    :param cheques_total: Количество чеков за смену
    :param fiscal_docs_total: Количество фискальных документов за смену

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retailshift
    """

    __return__ = Retailshift
    __api_method__ = "entity/retailshift"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retailshift"

    id: str = Field(..., alias="retailshift_id")
    data: Retailshift
