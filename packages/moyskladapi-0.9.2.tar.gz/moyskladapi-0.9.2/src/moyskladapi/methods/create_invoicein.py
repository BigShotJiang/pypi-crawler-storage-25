from ..types.invoicein import Invoicein
from .base import MSMethod


class CreateInvoicein(MSMethod[Invoicein]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Счете поставщика, запрашивать списки
    Счетов и сведения по отдельным Счетам Поставщиков. Позициями Счетов можно управлять как в
    составе отдельного Счета, так и отдельно - с помощью специальных ресурсов для управления
    позициями Счета. Кодом сущности для Счета поставщика в составе JSON API является ключевое слово
    invoicein. Больше о Счетах Поставщиков и работе с ними в основном интерфейсе вы можете
    прочитать в нашей службе поддержки по этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Счета поставщика
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Счета поставщика
    :param description: Комментарий Счета поставщика
    :param external_code: Внешний код Счета поставщика
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param incoming_date: Входящая дата
    :param incoming_number: Входящий номер
    :param moment: Дата документа
    :param name: Наименование Счета поставщика
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Сумма входящих платежей по Счету поставщика
    :param payment_planned_moment: Планируемая дата оплаты
    :param positions: Метаданные позиций Счета поставщика
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param shipped_sum: Сумма отгруженного
    :param state: Метаданные статуса счета
    :param store: Метаданные склада
    :param sum: Сумма Счета в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Счета поставщика
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param payments: Массив ссылок на связанные операции в формате `Только для чтения`
    :param purchase_order: Ссылка на связанный заказ поставщику в формате
    :param supplies: Ссылки на связанные приемки в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in
    """

    __return__ = Invoicein
    __api_method__ = "entity/invoicein"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-in"

    data: Invoicein
