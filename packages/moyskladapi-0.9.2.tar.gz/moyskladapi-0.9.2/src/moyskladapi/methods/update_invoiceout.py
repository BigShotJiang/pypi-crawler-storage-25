from pydantic import Field

from ..types.invoiceout import Invoiceout
from .base import MSMethod


class UpdateInvoiceout(MSMethod[Invoiceout]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Счете покупателю, запрашивать списки
    Счетов и сведения по отдельным Счетам Покупателям. Позициями Счетов можно управлять как в
    составе отдельного Счета, так и отдельно - с помощью специальных ресурсов для управления
    позициями Счета. Кодом сущности для Счета покупателю в составе JSON API является ключевое слово
    invoiceout. Больше о Счетах Покупателям и работе с ними в основном интерфейсе вы можете
    прочитать в нашей службе поддержки по этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Счета покупателю
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Счета покупателю
    :param description: Комментарий Счета покупателю
    :param external_code: Внешний код Счета покупателю
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Счета покупателю
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Сумма входящих платежей по Счету покупателю
    :param payment_planned_moment: Планируемая дата оплаты
    :param positions: Метаданные позиций Счета покупателю
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param shipped_sum: Сумма отгруженного
    :param state: Метаданные статуса счета
    :param store: Метаданные склада
    :param sum: Сумма Счета в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Счета покупателю
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param customer_order: Ссылка на Заказ Покупателя, с которым связан этот Счет покупателю в
        формате
    :param payments: Массив ссылок на связанные операции в формате `Только для чтения`
    :param demands: Массив ссылок на связанные отгрузки в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out
    """

    __return__ = Invoiceout
    __api_method__ = "entity/invoiceout"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/invoice-out"

    id: str = Field(..., alias="invoiceout_id")
    data: Invoiceout
