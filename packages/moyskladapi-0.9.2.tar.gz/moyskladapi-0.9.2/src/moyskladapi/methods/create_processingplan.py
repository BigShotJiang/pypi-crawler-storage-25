from ..types.processingplan import Processingplan
from .base import MSMethod


class CreateProcessingplan(MSMethod[Processingplan]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Техкартах, запрашивать списки
    Техкарт и сведения по отдельным Техкартам. Позициями Техкарт можно управлять как в составе
    отдельной Техкарты, так и отдельно - с помощью специальных ресурсов для управления материалами
    и продуктами Техкарты. Кодом сущности для Техкарты в составе JSON API является ключевое слово
    processingplan. Больше о Техкартах и работе с ними в основном интерфейсе вы можете прочитать в
    нашей службе поддержки по этой ссылке. По данной сущности можно осуществлять контекстный поиск
    с помощью специального параметра search. Подробнее можно узнать по ссылке.

    :param archived: Добавлена ли Техкарта в архив
    :param code: Код Техкарты
    :param cost: Стоимость производства
    :param cost_distribution_type: Тип распределения себестоимости. Возможные значения: `BY_PRICE`,
        `BY_PRODUCTION`
    :param external_code: Внешний код Техкарты
    :param group: Отдел сотрудника
    :param stages: Коллекция метаданных этапов Техкарты
    :param materials: Коллекция метаданных материалов Техкарты
    :param name: Наименование Техкарты
    :param owner: Владелец (Сотрудник)
    :param parent: Метаданные группы Техкарты
    :param path_name: Наименование группы, в которую входит Техкарта
    :param processing_process: Метаданные Техпроцесса
    :param products: Коллекция метаданных готовых продуктов Техкарты
    :param shared: Общий доступ
    :param updated: Момент последнего обновления Техкарты
    :param enable_hour_accounting: Признак активности учета по нормо-часам
    :param labour_cost: Оплата труда, на определенном этапе
    :param standard_hour: Нормо-часы, на определенном этапе
    :param processing_process_position: Метаданные позиции техпроцесса
    :param standard_hour_cost: Стоимость нормо-часа
    :param assortment: Метаданные товара или модификации позиции
    :param product: Метаданные товара позиции. В случае, если в поле **assortment** указана
        модификация, то это поле содержит товар, к которому относится эта модификация
    :param quantity: Количество товаров данного вида в позиции
    :param material_processing_plan: Метаданные техкарты материала

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan
    """

    __return__ = Processingplan
    __api_method__ = "entity/processingplan"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingplan"

    data: Processingplan
