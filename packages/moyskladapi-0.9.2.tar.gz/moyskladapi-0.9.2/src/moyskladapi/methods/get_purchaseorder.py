from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.purchaseorder import Purchaseorder
from .base import MSMethod


class GetPurchaseorder(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Заказах поставщику, запрашивать
    списки Заказов и сведения по отдельным Заказам Поставщикам. Позициями Заказов можно управлять
    как в составе отдельного Заказа поставщику, так и отдельно - с помощью специальных ресурсов для
    управления позициями Заказа. Кодом сущности для Заказа поставщику в составе JSON API является
    ключевое слово purchaseorder. Больше о Заказах Поставщикам и работе с ними в основном
    интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Заказа поставщику
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Заказа поставщику
    :param delivery_planned_moment: Планируемая дата отгрузки
    :param description: Комментарий Заказа поставщику
    :param external_code: Внешний код Заказа поставщику
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param invoiced_sum: Сумма счетов поставщику
    :param moment: Дата документа
    :param name: Наименование Заказа поставщику
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Сумма входящих платежей по Заказу
    :param positions: Метаданные позиций Заказа поставщику
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param shipped_sum: Сумма принятого
    :param state: Метаданные статуса заказа
    :param store: Метаданные склада
    :param sum: Сумма Заказа поставщику в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Заказа поставщику
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param wait_sum: Сумма товаров в пути
    :param customer_orders: Массив ссылок на связанные заказы покупателей в формате
    :param invoices_in: Массив ссылок на связанные счета поставщиков в формате
    :param production_tasks: Массив ссылок на связанные производственные задания в формате
    :param payments: Массив ссылок на связанные платежи в формате
    :param supplies: Массив ссылок на связанные приемки в формате
    :param internal_order: Внутренний заказ, связанный с заказом поставщику, в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder
    """

    __return__ = Purchaseorder
    __api_method__ = "entity/purchaseorder"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/purchaseOrder"

    id: str = Field(..., alias="purchaseorder_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
