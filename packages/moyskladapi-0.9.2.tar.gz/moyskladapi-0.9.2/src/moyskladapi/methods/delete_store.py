from pydantic import Field

from ..types.store import Store
from .base import MSMethod


class DeleteStore(MSMethod[Store]):
    """
    Кодом сущности для Складов в составе JSON API является ключевое слово store.

    :param address: Адрес склада
    :param address_full: Адрес с детализацией по отдельным полям.
    :param archived: Добавлен ли Склад в архив
    :param attributes: Массив метаданных дополнительных полей склада
    :param code: Код Склада
    :param description: Комментарий к Складу
    :param external_code: Внешний код Склада
    :param group: Отдел сотрудника
    :param name: Наименование Склада
    :param owner: Владелец (Сотрудник)
    :param parent: Метаданные родительского склада (Группы)
    :param path_name: Группа Склада
    :param shared: Общий доступ
    :param updated: Момент последнего обновления Склада
    :param zones: Зоны склада.
    :param slots: Ячейки склада.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
    """

    __return__ = Store
    __api_method__ = "entity/store"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store"

    id: str = Field(..., alias="store_id")
