from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.thing import Thing
from .base import MSMethod


class GetThing(MSMethod):
    """
    Средствами JSON API можно запрашивать списки Серийных номеров и сведения по отдельным Серийным
    номерам. Кодом сущности для Серийного номера в составе JSON API является ключевое слово thing.

    :param description: Описание Серийного номера
    :param name: Наименование Серийного номера

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/thing
    """

    __return__ = Thing
    __api_method__ = "entity/thing"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/thing"

    id: str = Field(..., alias="thing_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
