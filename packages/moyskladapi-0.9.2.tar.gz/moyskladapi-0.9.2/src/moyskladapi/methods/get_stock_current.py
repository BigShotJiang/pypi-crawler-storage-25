from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.stock_current import StockCurrent
from .base import MSMethod


class GetStockCurrent(MSMethod):
    """Краткий отчет об остатках (текущие остатки без разбиения по складам)."""

    __return__ = list[StockCurrent]
    __api_method__ = "report/stock/all/current"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-stock"

    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
    include: str | None = None
    changed_since: str | None = Field(None, alias="changedSince")
    stock_type: str | None = Field(None, alias="stockType")
