from pydantic import Field

from ..types.service import Service
from .base import MSMethod


class DeleteService(MSMethod[Service]):
    """
    Средствами JSON API можно создавать и обновлять сведения об Услугах, запрашивать списки Услуг и
    сведения по отдельным Услугам. Кодом сущности для Услуги в составе JSON API является ключевое
    слово service. Услуга - специальная разновидность товара, без закупочной цены и упаковок.
    Больше о Товарах и работе с ними в основном интерфейсе вы можете прочитать в нашей службе
    поддержки в разделе Товары и склад.

    :param archived: Добавлена ли Услуга в архив
    :param attributes: Коллекция доп. полей
    :param barcodes: Штрихкоды Услуги. . Для фильтрации по полю необходимо указывать его в
        единственном числе **barcode**.
    :param buy_price: Закупочная цена.
    :param code: Код Услуги
    :param description: Описание Услуги
    :param discount_prohibited: Признак запрета скидок
    :param effective_vat: Реальный НДС %
    :param effective_vat_enabled: Дополнительный признак для определения разграничения реального
        НДС = 0 или "без НДС". (effectiveVat = 0, effectiveVatEnabled = false) -> "без НДС",
        (effectiveVat = 0, effectiveVatEnabled = true) -> 0%.
    :param external_code: Внешний код Услуги
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Метаданные отдела сотрудника
    :param min_price: Минимальная цена.
    :param name: Наименование Услуги
    :param owner: Метаданные владельца (Сотрудника)
    :param path_name: Наименование группы, в которую входит Услуга
    :param payment_item_type: Признак предмета расчета.
    :param product_folder: Метаданные группы Услуги
    :param sale_prices: Цены продажи.
    :param shared: Общий доступ
    :param sync_id: ID синхронизации
    :param tax_system: Код системы налогообложения.
    :param uom: Единицы измерения
    :param updated: Момент последнего обновления сущности
    :param use_parent_vat: Используется ли ставка НДС родительской группы. Если true для единицы
        ассортимента будет применена ставка, установленная для родительской группы.
    :param vat: НДС %
    :param vat_enabled: Включен ли НДС для услуги. С помощью этого флага для услуги можно
        выставлять НДС = 0 или НДС = "без НДС". (vat = 0, vatEnabled = false) -> vat = "без НДС",
        (vat = 0, vatEnabled = true) -> vat = 0%.
    :param ean13: штрихкод в формате EAN13, если требуется создать штрихкод в формате EAN13
    :param ean8: штрихкод в формате EAN8, если требуется создать штрихкод в формате EAN8
    :param code128: штрихкод в формате Code128, если требуется создать штрихкод в формате Code128
    :param gtin: штрихкод в формате GTIN, если требуется создать штрихкод в формате GTIN.
        Валидируется на соответствие формату GS1
    :param upc: штрихкод в формате UPC, если требуется создать штрихкод в формате UPC
    :param value: Значение цены
    :param currency: Ссылка на валюту в формате
    :param price_type: Тип цены
    :param ikpu: Код из справочника ТАСНИФ
    :param pack_code: Код упаковки из справочника ТАСНИФ
    :param barcode_tasnif: Штрихкод из справочника ТАСНИФ

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service
    """

    __return__ = Service
    __api_method__ = "entity/service"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/service"

    id: str = Field(..., alias="service_id")
