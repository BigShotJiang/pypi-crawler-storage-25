from pydantic import Field

from ..types.retaildemand import Retaildemand
from .base import MSMethod


class UpdateRetaildemand(MSMethod[Retaildemand]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Розничных продажах, запрашивать
    списки Розничных продаж и сведения по отдельным Розничным продажам. Позициями Розничных продаж
    можно управлять как в составе отдельной Розничной продажи, так и отдельно - с помощью
    специальных ресурсов для управления позициями Розничными продажами. Кодом сущности для
    Розничной продажи в составе JSON API является ключевое слово retaildemand. Больше о Розничных
    продажах и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по
    этой ссылке в разделе Оформление продажи.

    :param advance_payment_sum: Оплачено из аванса
    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param cash_sum: Оплачено наличными
    :param check_number: Номер чека
    :param check_sum: Сумма Чека
    :param cheque: Фискальные данные продажи.
    :param code: Код Розничной продажи
    :param created: Дата создания
    :param customer_order: Метаданные Заказа Покупателя
    :param deleted: Момент последнего удаления Розничной продажи
    :param description: Комментарий Розничной продажи
    :param document_number: Номер документа
    :param external_code: Внешний код Розничной продажи
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param gift_cards: Коллекция подарочных сертификатов, используемых при оплате продажи.
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Розничной продажи
    :param no_cash_sum: Оплачено картой
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Сумма входящих платежей по Отгрузке
    :param positions: Метаданные позиций Розничной продажи
    :param prepayment_cash_sum: Предоплата наличными
    :param prepayment_no_cash_sum: Предоплата картой
    :param prepayment_qr_sum: Предоплата по QR-коду
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param qr_sum: Оплачено по QR-коду
    :param rate: Валюта.
    :param retail_shift: Метаданные Розничной смены
    :param retail_store: Метаданные Точки продаж
    :param session_number: Номер сессии
    :param shared: Общий доступ
    :param state: Метаданные статуса Розничной продажи
    :param store: Метаданные склада
    :param sum: Сумма Розничной продажи в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param tax_system: Код системы налогообложения.
    :param updated: Момент последнего обновления Розничной продажи
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param payment_sum: Сумма сертификата
    :param fn_number: Номер фискального накопителя
    :param fiscal_doc_sign: Фискальный признак документа
    :param fiscal_doc_number: Номер фискального документа
    :param kkt_reg_number: Регистрационный номер
    :param time: Время фискализации
    :param gtd: Регистрационный номер партии товара
    :param rnpt: Грузовая таможенная декларация
    :param country: Страна происхождения товара
    :param quantity: Количество товара с указанными ГТД или РНПТ в позиции документа

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand
    """

    __return__ = Retaildemand
    __api_method__ = "entity/retaildemand"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildemand"

    id: str = Field(..., alias="retaildemand_id")
    data: Retaildemand
