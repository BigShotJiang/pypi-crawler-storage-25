from ..types.task import Task
from .base import MSMethod


class UpdateTasks(MSMethod[Task]):
    """
    Средствами JSON API можно создавать и обновлять сведения о задачах, запрашивать списки задач и
    сведения по отдельным задачам. Кодом сущности для задачи в составе JSON API является ключевое
    слово task. Больше о задачах и работе с ними в основном интерфейсе вы можете прочитать в нашей
    службе поддержки по  этой ссылке.

    :param agent: Метаданные Контрагента или юрлица, связанного с задачей. Задача может быть
        привязана либо к конрагенту, либо к юрлицу, либо к документу
    :param assignee: Метаданные ответственного за выполнение задачи
    :param author: Метаданные Сотрудника, создавшего задачу (администратор аккаунта, если автор -
        Решение)
    :param author_application: Метаданные Решения, создавшего задачу
    :param completed: Время выполнения задачи
    :param created: Момент создания
    :param description: Текст задачи
    :param done: Отметка о выполнении задачи
    :param due_to_date: Срок задачи
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param implementer: Метаданные Сотрудника, выполнившего задачу
    :param state: Метаданные Типа задачи
    :param notes: Метаданные комментария к задаче
    :param operation: Метаданные Документа, связанного с задачей. Задача может быть привязана либо
        к конрагенту, либо к юрлицу, либо к документу
    :param updated: Момент последнего обновления Задачи
    :param moment: Момент создания комментария
    :param color: Цвет Типа задачи
    :param entity_type: Тип сущности - всегда является task
    :param name: Наименование Типа задачи
    :param state_type: Тип Статуса

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task
    """

    __return__ = list[Task]
    __api_method__ = "entity/task"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/task"

    data: list[Task]
