from pydantic import Field

from ..types.group import Group
from .base import MSMethod


class UpdateGroup(MSMethod[Group]):
    """
    Средствами JSON API можно запрашивать и изменять списки Отделов и сведения по отдельным
    Отделам. Кодом сущности для Отдела в составе JSON API является ключевое слово group. Больше об
    Отделах и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по
    этой ссылке. По данной сущности можно осуществлять контекстный поиск с помощью специального
    параметра search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается от
    других тем, что поиск не префиксный, без токенизации и идет только по одному полю одновременно.
    Ищет такие строки, в которые входит значение строки поиска.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group
    """

    __return__ = Group
    __api_method__ = "entity/group"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group"

    id: str = Field(..., alias="group_id")
    data: Group
