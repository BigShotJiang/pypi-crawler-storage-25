from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.cashier import Cashier
from .base import MSMethod


class GetCashier(MSMethod):
    """
    Средствами JSON API можно запрашивать списки Кассиров и сведения по отдельным кассирам. Кодом
    сущности для кассира в составе JSON API является ключевое слово cashier.

    :param employee: Метаданные сотрудника, которого представляет собой кассир
    :param retail_store: Метаданные точки продаж, к которой прикреплен кассир

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/cashier
    """

    __return__ = Cashier
    __api_method__ = "entity/cashier"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/cashier"

    id: str = Field(..., alias="cashier_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
