from pydantic import Field

from ..types.bundle import Bundle
from .base import MSMethod


class UpdateBundle(MSMethod[Bundle]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Комплектах, запрашивать списки
    Комплектов и сведения по отдельным Комплектам. Кодом сущности для Комплекта в составе JSON API
    является ключевое слово bundle.

    :param archived: Добавлен ли Комплект в архив
    :param article: Артикул
    :param attributes: Коллекция доп. полей
    :param barcodes: Штрихкоды Комплекта. . Для фильтрации по полю необходимо указывать его в
        единственном числе **barcode**.
    :param code: Код Комплекта
    :param components: Массив компонентов Комплекта
    :param country: Метаданные Страны
    :param description: Описание Комплекта
    :param discount_prohibited: Признак запрета скидок
    :param effective_vat: Реальный НДС %
    :param effective_vat_enabled: Дополнительный признак для определения разграничения реального
        НДС = 0 или "без НДС". (effectiveVat = 0, effectiveVatEnabled = false) -> "без НДС",
        (effectiveVat = 0, effectiveVatEnabled = true) -> 0%.
    :param external_code: Внешний код Комплекта
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Метаданные отдела сотрудника
    :param images: Массив метаданных (Максимальное количество изображений - 10)
    :param min_price: Минимальная цена.
    :param name: Наименование Комплекта
    :param overhead: Дополнительные расходы.
    :param owner: Метаданные владельца (Сотрудника)
    :param partial_disposal: Управление состоянием частичного выбытия маркированного товара. «true»
        - возможность включена.
    :param path_name: Наименование группы, в которую входит Комплект
    :param payment_item_type: Признак предмета расчета.
    :param product_folder: Метаданные группы Комплекта
    :param sale_prices: Цены продажи
    :param shared: Общий доступ
    :param sync_id: ID синхронизации
    :param tax_system: Код системы налогообложения.
    :param tnved: Код ТН ВЭД
    :param tracking_type: Тип маркируемой продукции.
    :param uom: Единицы измерения
    :param updated: Момент последнего обновления сущности
    :param use_parent_vat: Используется ли ставка НДС родительской группы. Если true для единицы
        ассортимента будет применена ставка, установленная для родительской группы.
    :param vat: НДС %
    :param vat_enabled: Включен ли НДС для товара. С помощью этого флага для товара можно
        выставлять НДС = 0 или НДС = "без НДС". (vat = 0, vatEnabled = false) -> vat = "без НДС",
        (vat = 0, vatEnabled = true) -> vat = 0%.
    :param volume: Объем
    :param weight: Вес
    :param ikpu: Код из справочника ТАСНИФ
    :param pack_code: Код упаковки из справочника ТАСНИФ
    :param barcode_tasnif: Штрихкод из справочника ТАСНИФ
    :param value: Значение цены
    :param currency: Ссылка на валюту в формате
    :param assortment: Метаданные товара/услуги/партии, которую представляет собой компонент
    :param quantity: Количество товаров/услуг данного вида в компоненте
    :param ean13: штрихкод в формате EAN13, если требуется создать штрихкод в формате EAN13
    :param ean8: штрихкод в формате EAN8, если требуется создать штрихкод в формате EAN8
    :param code128: штрихкод в формате Code128, если требуется создать штрихкод в формате Code128
    :param gtin: штрихкод в формате GTIN, если требуется создать штрихкод в формате GTIN.
        Валидируется на соответствие формату GS1
    :param upc: штрихкод в формате UPC, если требуется создать штрихкод в формате UPC
    :param filename: Имя файла
    :param miniature: Метаданные миниатюры изображения
    :param tiny: Метаданные уменьшенного изображения
    :param title: Название Изображения
    :param content: Изображение, закодированное в формате Base64.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle
    """

    __return__ = Bundle
    __api_method__ = "entity/bundle"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/bundle"

    id: str = Field(..., alias="bundle_id")
    data: Bundle
