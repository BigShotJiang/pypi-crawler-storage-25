from ..types.customentity import Customentity
from .base import MSMethod


class CreateCustomentity(MSMethod[Customentity]):
    """
    Кодом сущности для Пользовательских справочников в составе JSON API является ключевое слово
    customentity.

    :param name: Наименование Пользовательского справочника

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity
    """

    __return__ = Customentity
    __api_method__ = "entity/customentity"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/customentity"

    data: Customentity
