from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.productfolder import Productfolder
from .base import MSMethod


class GetProductfolder(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Группах товаров, запрашивать списки
    Групп товаров и сведения по отдельным Группам товаров. Кодом сущности для Группы товаров в
    составе JSON API является ключевое слово productfolder. По данной сущности можно осуществлять
    контекстный поиск с помощью специального параметра search. Подробнее можно узнать по ссылке.

    :param archived: Добавлена ли Группа товаров в архив
    :param code: Код Группы товаров
    :param description: Описание Группы товаров
    :param effective_vat: Реальный НДС %
    :param effective_vat_enabled: Дополнительный признак для определения разграничения реального
        НДС = 0 или "без НДС". (effectiveVat = 0, effectiveVatEnabled = false) -> "без НДС",
        (effectiveVat = 0, effectiveVatEnabled = true) -> 0%.
    :param external_code: Внешний код Группы товаров
    :param group: Метаданные отдела сотрудника
    :param name: Наименование Группы товаров
    :param owner: Метаданные владельца (Сотрудника)
    :param path_name: Наименование Группы товаров, в которую входит данная Группа товаров
    :param product_folder: Ссылка на Группу товаров, в которую входит данная Группа товаров, в
        формате Метаданных
    :param shared: Общий доступ
    :param tax_system: Код системы налогообложения.
    :param updated: Момент последнего обновления сущности
    :param use_parent_vat: Используется ли ставка НДС родительской группы. Если true для единицы
        ассортимента будет применена ставка, установленная для родительской группы.
    :param vat: НДС %
    :param vat_enabled: Включен ли НДС для группы. С помощью этого флага для группы можно
        выставлять НДС = 0 или НДС = "без НДС". (vat = 0, vatEnabled = false) -> vat = "без НДС",
        (vat = 0, vatEnabled = true) -> vat = 0%.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder
    """

    __return__ = Productfolder
    __api_method__ = "entity/productfolder"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/productFolder"

    id: str = Field(..., alias="productfolder_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
