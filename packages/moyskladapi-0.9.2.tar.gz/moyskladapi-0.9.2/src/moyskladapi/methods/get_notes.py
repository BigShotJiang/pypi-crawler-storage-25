from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.notes import Notes
from .base import MSMethod


class GetNotes(MSMethod):
    """
    Кодом сущности для Ленты событий в составе JSON API является ключевое слово notes.

    :param created: Момент создания События
    :param description: Текст События
    :param author: Метаданные Сотрудника - создателя События (администратор аккаунта, если автор -
        решение)
    :param author_application: Метаданные Решения - создателя события

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/eventfeed
    """

    __return__ = Notes
    __api_method__ = "entity/notes"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/eventfeed"

    id: str = Field(..., alias="notes_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
