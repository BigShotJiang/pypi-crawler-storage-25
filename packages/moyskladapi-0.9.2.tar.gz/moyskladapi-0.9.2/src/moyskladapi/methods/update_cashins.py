from ..types.cashin import Cashin
from .base import MSMethod


class UpdateCashins(MSMethod[Cashin]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Приходном ордере, запрашивать списки
    Приходных ордеров и сведения по отдельным Приходным ордерам.Кодом сущности для Приходного
    ордера в составе JSON API является ключевое слово cashin.

    :param agent: Метаданные контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Приходного ордера
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Приходного ордера
    :param description: Комментарий Приходного ордера
    :param external_code: Внешний код Приходного ордера
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Приходного ордера
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param payment_purpose: Основание
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param state: Метаданные статуса Приходного ордера
    :param sum: Сумма Приходного ордера в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Приходного ордера
    :param vat_sum: Сумма НДС
    :param facture_in: Ссылка на Счет-фактуру полученный, с которым связан этот платеж в формате
    :param operations: Массив ссылок на связанные операции в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin
    """

    __return__ = list[Cashin]
    __api_method__ = "entity/cashin"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashin"

    data: list[Cashin]
