from pydantic import Field

from ..types.supply import SupplyPosition
from .base import MSMethod


class UpdateSupplyPosition(MSMethod[SupplyPosition]):
    """
    Запрос на обновление отдельной позиции Приёмки.
    Все поля в теле запроса необязательны — указывайте только то, что хотите обновить.

    :param supply_id: id Приёмки
    :param position_id: id позиции
    :param data: Поля позиции для обновления

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply
    """

    __return__ = SupplyPosition
    __api_method__ = "entity/supply/{supply_id}/positions"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/supply"

    supply_id: str
    id: str = Field(..., alias="position_id")
    data: SupplyPosition

    def _prepare_request_data(self, data: dict) -> dict:
        return data.get("data", {})
