from pydantic import Field

from ..types.enter import Enter
from .base import MSMethod


class DeleteEnter(MSMethod[Enter]):
    """
    Средствами JSON API можно создавать и обновлять сведения об Оприходованиях, запрашивать списки
    Оприходований и сведения по отдельным Оприходованиям. Позициями Оприходований можно управлять
    как в составе отдельного Оприходования, так и отдельно - с помощью специальных ресурсов для
    управления позициями Оприходования. Кодом сущности для Оприходования в составе JSON API
    является ключевое слово enter. Больше об Оприходованиях можно прочитать этой ссылке.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Оприходования
    :param created: Дата создания
    :param deleted: Момент последнего удаления Оприходования
    :param description: Комментарий Оприходования
    :param external_code: Внешний код Оприходования
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Номер Оприходования
    :param organization: Метаданные юрлица
    :param overhead: Накладные расходы. . Если Позиции Оприходования не заданы, то накладные
        расходы нельзя задать
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Оприходования
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса оприходования
    :param store: Метаданные склада
    :param sum: Сумма Оприходования в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Оприходования
    :param distribution: Распределение накладных расходов `[weight, volume, price]` -> `[по весу,
        по объему, по цене]`
    :param inventory: Ссылка на связанную с оприходованием инвентаризацию в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter
    """

    __return__ = Enter
    __api_method__ = "entity/enter"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/enter"

    id: str = Field(..., alias="enter_id")
