from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.prepaymentreturn import Prepaymentreturn
from .base import MSMethod


class GetPrepaymentreturns(MSMethod):
    """
    Средствами JSON API можно запрашивать списки Возвратов предоплат и сведения по отдельным
    Возвратам предоплат. Кодом сущности для Возврата предоплаты в составе JSON API является
    ключевое слово prepaymentreturn.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return
    """

    __return__ = MetaArray[Prepaymentreturn]
    __api_method__ = "entity/prepaymentreturn"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment-return"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
