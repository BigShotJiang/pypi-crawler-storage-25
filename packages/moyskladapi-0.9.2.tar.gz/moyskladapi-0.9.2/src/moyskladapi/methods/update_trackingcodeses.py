from ..types.trackingcodes import Trackingcodes
from .base import MSMethod


class UpdateTrackingcodeses(MSMethod[Trackingcodes]):
    """
    Средствами JSON API можно получать, создавать, редактировать и удалять Коды маркировки. Кодом
    сущности для Кодов маркировки в составе JSON API является ключевое слово trackingCodes.
    Сущность представлена в виде идентификатора, текстового кода, типа кода и массива вложенных
    Кодов маркировки. Коды маркировки относятся к отдельной позиции конкретного документа. Порядок
    вывода КМ первого уровня фиксирован - вложенные КМ могут выводиться в случайном порядке.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/tracking-code
    """

    __return__ = list[Trackingcodes]
    __api_method__ = "entity/trackingcodes"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/tracking-code"

    data: list[Trackingcodes]
