from ..types.pricelist import Pricelist
from .base import MSMethod


class CreatePricelist(MSMethod[Pricelist]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Прайс-листах, запрашивать списки
    Прайс-листов и сведения по отдельным Прайс-листам. Позициями Прайс-листов можно управлять как в
    составе отдельного Прайс-листа, так и отдельно - с помощью специальных ресурсов для управления
    позициями Прайс-листа. Кодом сущности для Прайс-листа в составе JSON API является ключевое
    слово pricelist. Больше о Прайс-листах и работе с ними в основном интерфейсе вы можете
    прочитать в нашей службе поддержки по  этой ссылке.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Прайс-листа
    :param columns: Массив столбцов описания таблицы
    :param created: Дата создания
    :param deleted: Момент последнего удаления Прайс-листа
    :param description: Комментарий Прайс-листа
    :param external_code: Внешний код Прайс-листа
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Прайс-листа
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Прайс-листа
    :param price_type: Объект типа цены
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param shared: Общий доступ
    :param state: Метаданные статуса Прайс-листа
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Прайс-листа
    :param percentage_discount: Процентная наценка или скидка по умолчанию для столбца
    :param column: Название столбца, к которому относится данная ячейка
    :param sum: Числовое значение ячейки

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist
    """

    __return__ = Pricelist
    __api_method__ = "entity/pricelist"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/pricelist"

    data: Pricelist
