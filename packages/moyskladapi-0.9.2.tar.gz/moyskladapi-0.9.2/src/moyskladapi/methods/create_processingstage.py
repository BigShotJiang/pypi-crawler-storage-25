from ..types.processingstage import Processingstage
from .base import MSMethod


class CreateProcessingstage(MSMethod[Processingstage]):
    """
    Средствами JSON API можно запрашивать и обновлять списки Этапов и сведения по отдельным Этапам.
    Кодом сущности для Этапов в составе JSON API является ключевое слово processingstage. Больше об
    Этапах и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по
    этой ссылке.

    :param all_performers: Признак доступности назначения на этап любого сотрудника
    :param archived: Добавлен ли Этап в архив
    :param description: Комментарий Этапа
    :param distribution_required: Признак видимости заданий для исполнителей в веб-приложении
        МойСклад Производство. true - показывать исполнителю только назначенные на него задания;
        false - показывать исполнителю все доступные задания
    :param external_code: Внешний код Этапа
    :param group: Отдел сотрудника
    :param material_store: Метаданные склада материалов
    :param name: Наименование Этапа
    :param owner: Владелец (Сотрудник)
    :param performers: Метаданные возможных исполнителей
    :param shared: Общий доступ
    :param standard_hour_cost: Стоимость нормо-часа
    :param updated: Момент последнего обновления Этапа

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage
    """

    __return__ = Processingstage
    __api_method__ = "entity/processingstage"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/processingstage"

    data: Processingstage
