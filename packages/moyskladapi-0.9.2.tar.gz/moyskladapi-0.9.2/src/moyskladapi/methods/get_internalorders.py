from collections.abc import Sequence

from ..client.filters import Condition
from ..types.internalorder import Internalorder
from ..types.meta import MetaArray
from .base import MSMethod


class GetInternalorders(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Внутренних заказах, запрашивать
    списки Внутренних заказов и сведения по отдельным Внутренним заказам. Позициями Внутренних
    заказов можно управлять как в составе отдельного заказа, так и с помощью специальных ресурсов
    для управления позициями. Кодом сущности для Внутреннего заказа в составе JSON API является
    ключевое слово internalorder.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Внутреннего заказа
    :param created: Дата создания
    :param deleted: Момент последнего удаления Внутреннего заказа
    :param delivery_planned_moment: Планируемая дата приемки
    :param description: Комментарий Внутреннего заказа
    :param external_code: Внешний код Внутреннего заказа
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param moves: Коллекция метаданных на связанные заказы перемещения
    :param name: Наименование Внутреннего заказа
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Внутреннего заказа
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param purchase_orders: Коллекция метаданных на связанные заказы поставщику
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Внутреннего заказа
    :param store: Метаданные склада
    :param sum: Сумма Внутреннего заказа в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Внутреннего заказа
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param purchase_order: Ссылка на Заказ Поставщика, с которым связан этот Внутренний заказ в
        формате
    :param move: Ссылка на Перемещение, с которой связан этот Внутренний заказ в формате
    :param processing_order: Ссылка на Заказ на производство, с которым связан этот Внутренний
        заказ в формате
    :param production_tasks: Массив ссылок на связанные производственные задания в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder
    """

    __return__ = MetaArray[Internalorder]
    __api_method__ = "entity/internalorder"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/internalOrder"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
