from pydantic import Field

from ..types.role import Role
from .base import MSMethod


class DeleteRole(MSMethod[Role]):
    """
    Кодом сущности для Пользовательской роли в составе JSON API является ключевое слово role.

    :param name: Наименование пользовательской роли

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/custom-role
    """

    __return__ = Role
    __api_method__ = "entity/role"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/custom-role"

    id: str = Field(..., alias="role_id")
