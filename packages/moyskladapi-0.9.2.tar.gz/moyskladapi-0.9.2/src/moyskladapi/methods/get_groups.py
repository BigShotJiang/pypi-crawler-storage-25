from collections.abc import Sequence

from ..client.filters import Condition
from ..types.group import Group
from ..types.meta import MetaArray
from .base import MSMethod


class GetGroups(MSMethod):
    """
    Средствами JSON API можно запрашивать и изменять списки Отделов и сведения по отдельным
    Отделам. Кодом сущности для Отдела в составе JSON API является ключевое слово group. Больше об
    Отделах и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по
    этой ссылке. По данной сущности можно осуществлять контекстный поиск с помощью специального
    параметра search. Подробнее можно узнать по ссылке. Поиск с параметром search отличается от
    других тем, что поиск не префиксный, без токенизации и идет только по одному полю одновременно.
    Ищет такие строки, в которые входит значение строки поиска.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group
    """

    __return__ = MetaArray[Group]
    __api_method__ = "entity/group"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/group"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
