from collections.abc import Sequence

from ..client.filters import Condition
from ..types.audit import Audit
from ..types.meta import MetaArray
from .base import MSMethod


class GetAudits(MSMethod):
    """
    В аудите под контекстом подразумевается одно или несколько связанных событий, например,
    массовое обновление товаров. События отражают конкретные произошедшие изменения, например,
    изменение значения поля. Контекст же содержит только общую информацию событий, относящихся к
    нему.

    :param entity_type: Название сущности (поле присутствует, только если оно одинаково
        у всех Событий в рамках данного Контекста)
    :param event_type: Действие Событий (поле присутствует, только если оно одинаково
        у всех Событий в рамках данного Контекста)
    :param events: Список методанных Событий аудита
    :param info: Краткое описание
    :param moment: Дата изменения
    :param object_count: количество измененных объектов
    :param object_type: Тип сущностей, с которыми связанно данное изменение. Поле
        присутствует только для `entityType` = `entitysettings` или `statesettings`
        или `templatesettings`
    :param source: Тип изменения
    :param support_access: Был ли доступ произведен поддержкой от имени пользователя.
        Флаг отсутствует, если значение false
    :param uid: Логин Сотрудника
    :param registration: Регистрация аккаунта
    :param clearrecyclebin: Автоматическая очистка корзины
    :param combine: Объединение
    :param bulkcreate: Массовое создание
    :param connectors: Синхронизация с ИМ
    :param copy: Копирование
    :param emailsend: Отправка сообщения
    :param evotor: Синхронизация с Эвотор
    :param export: Экспорт
    :param exportediclient1c: Экспорт в 1С Клиент ЭДО
    :param import: Импорт
    :param import1c: Импорт из 1С
    :param import_alfabank: Импорт из Альфа-Банка
    :param import_modulebank: Импорт из Модульбанка
    :param import_tinkoffbank: Импорт из Тинькофф Банка
    :param import_tochkabank: Импорт из Точка Банка
    :param importediclient1c: Импорт в 1С Клиент ЭДО
    :param loginlogout: Вход или выход из МоегоСклада
    :param posapi: POS API
    :param restapi: REST API
    :param retail: Точка продаж
    :param app: Все действия

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/audit/audit
    """

    __return__ = MetaArray[Audit]
    __api_method__ = "audit"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/audit/audit"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
