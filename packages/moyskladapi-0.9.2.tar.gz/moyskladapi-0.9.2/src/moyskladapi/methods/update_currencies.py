from ..types.currency import Currency
from .base import MSMethod


class UpdateCurrencies(MSMethod[Currency]):
    """
    Средствами JSON API можно запрашивать списки валют и сведения по отдельным валютам, а также
    создавать новые и обновлять сведения по уже существующим валютам. Кодом сущности для валют в
    составе JSON API является ключевое слово currency. Больше о валютах и работе с ними в основном
    интерфейсе вы можете прочитать в нашей службе поддержки по этой ссылке. По данной сущности
    можно осуществлять контекстный поиск с помощью специального параметра search. Подробнее можно
    узнать по ссылке. Поиск с параметром search отличается от других тем, что поиск не префиксный,
    без токенизации и идет только по одному полю одновременно. Ищет такие строки, в которые входит
    значение строки поиска.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/currency
    """

    __return__ = list[Currency]
    __api_method__ = "entity/currency"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/currency"

    data: list[Currency]
