from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.commissionreportin import Commissionreportin
from .base import MSMethod


class GetCommissionreportin(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Полученных отчетах комиссионера,
    запрашивать списки Полученных отчетов комиссионера и сведения по отдельным Полученным отчетам
    комиссионера. Позициями отчетов комиссионера можно управлять как в составе отдельного отчета,
    так и с помощью специальных ресурсов для управления позициями. Кодом сущности для Полученного
    отчета комиссионера в составе JSON API является ключевое слово commissionreportin. Больше об
    отчетах комиссионера и работе с ними в основном интерфейсе вы можете прочитать в нашей службе
    поддержки по  этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Полученного отчета комиссионера
    :param commission_overhead: Прочие расходы. . Если Позиции Отчета комиссионера не заданы, то
        расходы нельзя задать
    :param commission_period_end: Конец периода
    :param commission_period_start: Начало периода
    :param commitent_sum: Сумма коммитента в установленной валюте
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Полученного отчета комиссионера
    :param description: Комментарий Полученного отчета комиссионера
    :param external_code: Внешний код Полученного отчета комиссионера
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Полученного отчета комиссионера
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Оплаченная сумма
    :param positions: Метаданные позиций реализовано комиссионером Полученного отчета комиссионера
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param return_to_commissioner_positions: Метаданные позиций возврата на склад комиссионера
        Полученного отчета комиссионера
    :param reward_percent: Процент вознаграждения (всегда 0 если вознаграждение не рассчитывается)
    :param reward_type: Тип вознаграждения
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param state: Метаданные статуса Полученного отчета комиссионера
    :param sum: Сумма Полученного отчета комиссионера в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Полученного отчета комиссионера
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param payments: Массив ссылок на связанные платежи в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin
    """

    __return__ = Commissionreportin
    __api_method__ = "entity/commissionreportin"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/commissionreportin"

    id: str = Field(..., alias="commissionreportin_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
