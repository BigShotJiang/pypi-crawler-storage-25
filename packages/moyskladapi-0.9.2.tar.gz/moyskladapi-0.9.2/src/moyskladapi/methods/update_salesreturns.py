from ..types.salesreturn import Salesreturn
from .base import MSMethod


class UpdateSalesreturns(MSMethod[Salesreturn]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Возвратах покупателей, запрашивать
    списки Возвратов покупателей и сведения по отдельным Возвратам покупателей. Позициями Возвратов
    покупателей можно управлять как в составе отдельного Возврата, так и отдельно - с помощью
    специальных ресурсов для управления позициями Возврата покупателя. Кодом сущности для Возврата
    покупателя в составе JSON API является ключевое слово salesreturn.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Возврата Покупателя
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Возврата Покупателя
    :param description: Комментарий Возврата Покупателя
    :param external_code: Внешний код Возврата Покупателя
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Возврата Покупателя
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Возврата Покупателя
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param state: Метаданные статуса Возврата Покупателя
    :param store: Метаданные склада
    :param sum: Сумма Возврата Покупателя в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Возврата Покупателя
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param demand: Ссылка на отгрузку, по которой произошел возврат в формате Поле является
        необходимым для возврата с основанием.
    :param losses: Массив ссылок на связанные списания в формате
    :param payments: Массив ссылок на связанные платежи в формате
    :param payed_sum: Сумма исходящих платежей по возврату покупателя
    :param facture_out: Ссылка на Счет-фактуру выданный, с которым связан этот возврат, в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return
    """

    __return__ = list[Salesreturn]
    __api_method__ = "entity/salesreturn"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/sales-return"

    data: list[Salesreturn]
