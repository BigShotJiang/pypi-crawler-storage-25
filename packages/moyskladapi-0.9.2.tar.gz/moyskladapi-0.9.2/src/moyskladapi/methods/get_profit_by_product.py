from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.profit import Profit
from .base import MSMethod


class GetProfitByProduct(MSMethod):
    """Прибыльность по товарам."""

    __return__ = MetaArray[Profit]
    __api_method__ = "report/profit/byproduct"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/reports/report-pnl"

    limit: int | None = None
    offset: int | None = None
    moment_from: str | None = Field(None, alias="momentFrom")
    moment_to: str | None = Field(None, alias="momentTo")
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
