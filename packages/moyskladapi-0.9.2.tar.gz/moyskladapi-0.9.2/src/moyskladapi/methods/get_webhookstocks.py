from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.webhookstock import Webhookstock
from .base import MSMethod


class GetWebhookstocks(MSMethod):
    """
    > Пример того, в каком виде будут передаваться данные: POST
    https://example.com/webhook_path?requestId=640569eb-522d-427a-b07e-fa757c5d4217

    :param stock_type: Тип остатков, изменение которых вызывает вебхук на изменение остатков.
        Возможные значения: `[stock]`
    :param report_type: Тип отчета остатков, к которым привязан вебхук на изменение остатков.
        Возможные значения: `[all, bystore]`
    :param report_url: URL на получения данных по
    :param author_application: Метаданные Решения, создавшего вебхук на изменение остатков
    :param enabled: Флажок состояния вебхука на изменение остатков (включен / отключен)
    :param url: URL, по которому будет происходить обработка вебхука. Допустимая длина до 255
        символов

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock
    """

    __return__ = MetaArray[Webhookstock]
    __api_method__ = "entity/webhookstock"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/webhookstock"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
