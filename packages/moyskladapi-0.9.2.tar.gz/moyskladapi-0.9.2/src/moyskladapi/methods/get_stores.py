from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.store import Store
from .base import MSMethod


class GetStores(MSMethod):
    """
    Кодом сущности для Складов в составе JSON API является ключевое слово store.

    :param address: Адрес склада
    :param address_full: Адрес с детализацией по отдельным полям.
    :param archived: Добавлен ли Склад в архив
    :param attributes: Массив метаданных дополнительных полей склада
    :param code: Код Склада
    :param description: Комментарий к Складу
    :param external_code: Внешний код Склада
    :param group: Отдел сотрудника
    :param name: Наименование Склада
    :param owner: Владелец (Сотрудник)
    :param parent: Метаданные родительского склада (Группы)
    :param path_name: Группа Склада
    :param shared: Общий доступ
    :param updated: Момент последнего обновления Склада
    :param zones: Зоны склада.
    :param slots: Ячейки склада.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store
    """

    __return__ = MetaArray[Store]
    __api_method__ = "entity/store"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/store"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
