from pydantic import Field

from ..types.demand import DemandPosition
from .base import MSMethod


class UpdateDemandPosition(MSMethod[DemandPosition]):
    """
    Запрос на обновление отдельной позиции Отгрузки.
    Все поля в теле запроса необязательны — указывайте только то, что хотите обновить.

    :param demand_id: id Отгрузки
    :param position_id: id позиции
    :param data: Поля позиции для обновления

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
    """

    __return__ = DemandPosition
    __api_method__ = "entity/demand/{demand_id}/positions"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand"

    demand_id: str
    id: str = Field(..., alias="position_id")
    data: DemandPosition

    def _prepare_request_data(self, data: dict) -> dict:
        return data.get("data", {})
