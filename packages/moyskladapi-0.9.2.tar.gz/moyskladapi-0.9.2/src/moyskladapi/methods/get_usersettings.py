from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.usersettings import Usersettings
from .base import MSMethod


class GetUsersettings(MSMethod):
    """
    Кодом сущности для Настройки пользователя в составе JSON API является ключевое слово
    usersettings.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/usersettings
    """

    __return__ = Usersettings
    __api_method__ = "entity/usersettings"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/usersettings"

    id: str = Field(..., alias="usersettings_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
