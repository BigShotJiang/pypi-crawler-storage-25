from pydantic import Field

from ..types.demand import Demand
from .base import MSMethod


class UpdateDemand(MSMethod[Demand]):
    """
    Средствами JSON API можно создавать и обновлять сведения об Отгрузках, запрашивать списки
    Отгрузок и сведения по отдельным Отгрузкам. Позициями Отгрузок можно управлять как в составе
    отдельной Отгрузки, так и отдельно - с помощью специальных ресурсов для управления позициями
    Отгрузки. Кодом сущности для Отгрузки в составе JSON API является ключевое слово demand. Больше
    об Отгрузках и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
    по  этой ссылке.

    :param agent: Метаданные контрагента
    :param agent_account: Метаданные счета контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Отгрузки
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Отгрузки
    :param description: Комментарий Отгрузки
    :param external_code: Внешний код Отгрузки
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Отгрузки
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param overhead: Накладные расходы. . Если Позиции Отгрузки не заданы, то накладные расходы
        нельзя задать
    :param owner: Владелец (Сотрудник)
    :param payed_sum: Сумма входящих платежей по Отгрузке
    :param positions: Метаданные позиций Отгрузки
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param shipment_address: Адрес доставки Отгрузки
    :param shipment_address_full: Адрес доставки Отгрузки с детализацией по отдельным полям.
    :param state: Метаданные статуса Отгрузки
    :param store: Метаданные склада
    :param sum: Сумма Отгрузки в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Отгрузки
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС
    :param distribution: Распределение накладных расходов `[weight, volume, price]` -> `[по весу,
        по объему, по цене]`
    :param customer_order: Ссылка на Заказ Покупателя, с которым связана эта Отгрузка в формате
    :param facture_out: Ссылка на Счет-фактуру выданный, с которым связана эта Отгрузка в формате
    :param returns: Массив ссылок на связанные возвраты в формате
    :param payments: Массив ссылок на связанные платежи в формате
    :param invoices_out: Массив ссылок на связанные счета покупателям в формате
    :param cargo_name: Наименование груза
    :param carrier: Метаданные перевозчика (контрагент или юрлицо)
    :param consignee: Метаданные грузополучателя (контрагент или юрлицо)
    :param good_pack_quantity: Всего мест
    :param shipping_instructions: Указания грузоотправителя
    :param state_contract_id: Идентификатор государственного контракта, договора (соглашения)
    :param transport_facility: Транспортное средство
    :param transport_facility_number: Номер автомобиля

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand
    """

    __return__ = Demand
    __api_method__ = "entity/demand"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/demand"

    id: str = Field(..., alias="demand_id")
    data: Demand
