from pydantic import Field

from ..types.image import Image
from .base import MSMethod


class DeleteImage(MSMethod[Image]):
    """
    Средствами JSON API можно создавать и обновлять сведения по Изображениям для Товаров,
    Комплектов и Модификаций, запрашивать списки Изображений, а также сведения по отдельным
    Изображениям. Кодом сущности для Изображения в составе JSON API является ключевое слово image.

    :param filename: Имя файла
    :param miniature: Метаданные миниатюры изображения
    :param tiny: Метаданные уменьшенного изображения
    :param title: Название Изображения
    :param updated: Время загрузки файла на сервер

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/images
    """

    __return__ = Image
    __api_method__ = "entity/image"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/images"

    id: str = Field(..., alias="image_id")
