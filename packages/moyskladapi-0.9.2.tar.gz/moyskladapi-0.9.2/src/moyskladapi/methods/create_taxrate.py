from ..types.taxrate import Taxrate
from .base import MSMethod


class CreateTaxrate(MSMethod[Taxrate]):
    """
    Средствами JSON API можно создавать и обновлять сведения о налоговых ставках, запрашивать
    списки ставок и сведения по отдельным ставкам. Кодом сущности для налоговой ставки в составе
    JSON API является ключевое слово taxrate. По данной сущности можно осуществлять контекстный
    поиск с помощью специального параметра search. Подробнее можно узнать по ссылке. Поиск с
    параметром search отличается от других тем, что поиск не префиксный, без токенизации и идет
    только по одному полю одновременно. Ищет такие строки, в которые входит значение строки поиска.

    :param comment: Комментарий к налоговой ставке
    :param group: Отдел-владелец
    :param rate: Значение налоговой ставки
    :param owner: Сотрудник-владелец
    :param shared: Флаг общего доступа
    :param updated: Момент последнего обновления сущности
    :param archived: Флаг принадлежности ставки к архивным ставкам

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate
    """

    __return__ = Taxrate
    __api_method__ = "entity/taxrate"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/taxrate"

    data: Taxrate
