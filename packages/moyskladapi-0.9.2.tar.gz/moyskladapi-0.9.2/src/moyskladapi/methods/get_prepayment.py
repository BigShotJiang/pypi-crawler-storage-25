from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.prepayment import Prepayment
from .base import MSMethod


class GetPrepayment(MSMethod):
    """
    Средствами JSON API можно запрашивать списки Предоплат и сведения по отдельным Предоплатам.
    Кодом сущности для Предоплаты в составе JSON API является ключевое слово prepayment. Больше о
    Предоплатах и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
    по этой ссылке.

    :param agent: Метаданные контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param cash_sum: Оплачено наличными
    :param code: Код Предоплаты
    :param created: Дата создания
    :param customer_order: Метаданные Заказа Покупателя
    :param deleted: Момент последнего удаления Предоплаты
    :param description: Комментарий Предоплаты
    :param external_code: Внешний код Предоплаты
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Предоплаты
    :param no_cash_sum: Оплачено картой
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param positions: Метаданные позиций Предоплаты
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param qr_sum: Оплачено по QR-коду
    :param rate: Валюта.
    :param retail_shift: Метаданные Розничной смены
    :param retail_store: Метаданные Точки продаж
    :param returns: Коллекция метаданных на связанные возвраты
    :param shared: Общий доступ
    :param state: Метаданные статуса Предоплаты
    :param sum: Сумма Предоплаты в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param tax_system: Код системы налогообложения.
    :param updated: Момент последнего обновления Предоплаты
    :param vat_enabled: Учитывается ли НДС
    :param vat_included: Включен ли НДС в цену
    :param vat_sum: Сумма НДС

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment
    """

    __return__ = Prepayment
    __api_method__ = "entity/prepayment"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/prepayment"

    id: str = Field(..., alias="prepayment_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
