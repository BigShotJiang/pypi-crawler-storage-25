from ..types.product import Product
from .base import MSMethod


class CreateProduct(MSMethod[Product]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Товарах, запрашивать списки Товаров
    и сведения по отдельным Товарам. Кодом сущности для Товара в составе JSON API является ключевое
    слово product. Больше о Товарах и работе с ними в основном интерфейсе вы можете прочитать в
    нашей службе поддержки в разделе Товары и склад. По данной сущности можно осуществлять
    контекстный поиск с помощью специального параметра search. Подробнее можно узнать по ссылке.

    :param alcoholic: Объект, содержащий поля алкогольной продукции.
    :param archived: Добавлен ли Товар в архив
    :param article: Артикул
    :param attributes: Коллекция доп. полей
    :param barcodes: Штрихкоды Товаров. . Для фильтрации по полю необходимо указывать его в
        единственном числе **barcode**.
    :param buy_price: Закупочная цена.
    :param code: Код Товара
    :param country: Метаданные Страны
    :param description: Описание Товара
    :param discount_prohibited: Признак запрета скидок
    :param effective_vat: Реальный НДС %
    :param effective_vat_enabled: Дополнительный признак для определения разграничения реального
        НДС = 0 или "без НДС". (effectiveVat = 0, effectiveVatEnabled = false) -> "без НДС",
        (effectiveVat = 0, effectiveVatEnabled = true) -> 0%.
    :param external_code: Внешний код Товара
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Метаданные отдела сотрудника
    :param images: Массив метаданных (Максимальное количество изображений - 10)
    :param is_serial_trackable: Учет по серийным номерам. Данная отметка не сочетается с признаками
        **weighed**, **alcoholic**, **ppeType**, **trackingType**, **onTap**.
    :param min_price: Минимальная цена.
    :param minimum_balance: Неснижаемый остаток
    :param minimum_stock: Неснижаемый остаток.
    :param name: Наименование Товара
    :param owner: Метаданные владельца (Сотрудника)
    :param packs: Упаковки Товара.
    :param partial_disposal: Управление состоянием частичного выбытия маркированного товара. «true»
        - возможность включена.
    :param path_name: Наименование группы, в которую входит Товар
    :param payment_item_type: Признак предмета расчета.
    :param ppe_type: Код вида номенклатурной классификации медицинских средств индивидуальной
        защиты (EAN-13).
    :param product_folder: Метаданные группы Товара
    :param sale_prices: Цены продажи.
    :param shared: Общий доступ
    :param supplier: Метаданные контрагента-поставщика
    :param sync_id: ID синхронизации
    :param tax_system: Код системы налогообложения.
    :param things: Серийные номера
    :param tnved: Код ТН ВЭД
    :param tracking_type: Тип маркируемой продукции.
    :param uom: Единицы измерения
    :param updated: Момент последнего обновления сущности
    :param use_parent_vat: Используется ли ставка НДС родительской группы. Если true для единицы
        ассортимента будет применена ставка, установленная для родительской группы.
    :param variants_count: Количество модификаций у данного товара
    :param vat: НДС %
    :param vat_enabled: Включен ли НДС для товара. С помощью этого флага для товара можно
        выставлять НДС = 0 или НДС = "без НДС". (vat = 0, vatEnabled = false) -> vat = "без НДС",
        (vat = 0, vatEnabled = true) -> vat = 0%.
    :param volume: Объем
    :param weight: Вес
    :param quantity: Количество Товаров в упаковке данного вида
    :param create_shared: Создавать новые Товары с меткой "Общий"
    :param ean13: штрихкод в формате EAN13, если требуется создать штрихкод в формате EAN13
    :param ean8: штрихкод в формате EAN8, если требуется создать штрихкод в формате EAN8
    :param code128: штрихкод в формате Code128, если требуется создать штрихкод в формате Code128
    :param gtin: штрихкод в формате GTIN, если требуется создать штрихкод в формате GTIN.
        Валидируется на соответствие формату GS1
    :param upc: штрихкод в формате UPC, если требуется создать штрихкод в формате UPC
    :param excise: Содержит акцизную марку
    :param type: Код вида продукции
    :param strength: Крепость
    :param value: Значение цены в копейках
    :param currency: Ссылка на валюту в формате
    :param price_type: Тип цены
    :param storebalances: Количество Неснижаемого остатка заданное для каждого склада
    :param store: Метаданные склада, для которого задан Неснижаемый остаток
    :param filename: Имя файла
    :param miniature: Метаданные миниатюры изображения
    :param tiny: Метаданные уменьшенного изображения
    :param title: Название Изображения
    :param content: Изображение, закодированное в формате Base64.
    :param weighed: Поле, показывающее является ли товар весовым. Если его значение false - поле не
        отображается.
    :param on_tap: Поле, показывающее является ли товар разливным. Если его значение false - поле
        не отображается.
    :param ikpu: Код из справочника ТАСНИФ
    :param pack_code: Код упаковки из справочника ТАСНИФ
    :param barcode_tasnif: Штрихкод из справочника ТАСНИФ
    :param ntin: Идентификационный код товара

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product
    """

    __return__ = Product
    __api_method__ = "entity/product"
    __http_method__ = "POST"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/product"

    data: Product
