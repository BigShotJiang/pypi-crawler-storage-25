from collections.abc import Sequence

from ..client.filters import Condition
from ..types.inventory import Inventory
from ..types.meta import MetaArray
from .base import MSMethod


class GetInventories(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Инвентаризации, запрашивать списки
    Инвентаризаций и сведения по отдельным Инвентаризациям. Позициями Инвентаризации можно
    управлять как в составе отдельной Инвентаризации, так и отдельно - с помощью специальных
    ресурсов для управления позициями Инвентаризации. Кодом сущности для Инвентаризации в составе
    JSON API является ключевое слово inventory. Больше о Инвентаризациях можно прочитать этой
    ссылке.

    :param search: `string` (optional) *Example: 0001* Фильтр документов по указанной поисковой
        строке.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory
    """

    __return__ = MetaArray[Inventory]
    __api_method__ = "entity/inventory"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/inventory"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
