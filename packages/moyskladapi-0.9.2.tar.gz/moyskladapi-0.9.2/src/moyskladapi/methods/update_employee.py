from pydantic import Field

from ..types.employee import Employee
from .base import MSMethod


class UpdateEmployee(MSMethod[Employee]):
    """
    Средствами JSON API можно запрашивать списки Сотрудников и сведения по отдельным Сотрудникам.
    Кодом сущности для Сотрудника в составе JSON API является ключевое слово employee. Больше о
    Сотрудниках и работе с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки
    по этой ссылке. По данной сущности можно осуществлять контекстный поиск с помощью специального
    параметра search. Подробнее можно узнать по ссылке.

    :param archived: Добавлен ли Сотрудник в архив
    :param attributes: Дополнительные поля Сотрудника
    :param cashiers: Массив кассиров.
    :param created: Момент создания Сотрудника
    :param description: Комментарий к Сотруднику
    :param email: Электронная почта сотрудника
    :param external_code: Внешний код Сотрудника
    :param first_name: Имя
    :param full_name: Имя Отчество Фамилия
    :param group: Отдел сотрудника
    :param image: Фотография сотрудника.
    :param inn: ИНН сотрудника (в формате ИНН физического лица)
    :param last_name: Фамилия
    :param middle_name: Отчество
    :param name: Наименование Сотрудника
    :param owner: Владелец (Сотрудник)
    :param phone: Телефон сотрудника
    :param position: Должность сотрудника
    :param salary: Оклад сотрудника
    :param shared: Общий доступ
    :param short_fio: Краткое ФИО
    :param uid: Логин Сотрудника
    :param updated: Момент последнего обновления Сотрудника
    :param value: Сумма оклада
    :param employee: Метаданные сотрудника, которого представляет собой кассир
    :param retail_store: Метаданные точки продаж, к которой прикреплен кассир
    :param filename: Имя файла
    :param miniature: Метаданные миниатюры изображения
    :param tiny: Метаданные уменьшенного изображения
    :param title: Название Изображения
    :param content: Изображение, закодированное в формате Base64

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/employee
    """

    __return__ = Employee
    __api_method__ = "entity/employee"
    __http_method__ = "PUT"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/employee"

    id: str = Field(..., alias="employee_id")
    data: Employee
