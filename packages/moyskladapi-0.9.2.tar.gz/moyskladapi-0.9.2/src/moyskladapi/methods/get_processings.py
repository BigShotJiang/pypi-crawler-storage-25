from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.processing import Processing
from .base import MSMethod


class GetProcessings(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Техоперациях, запрашивать списки
    Техопераций и сведения по отдельным Техоперациям. Позициями Техопераций можно управлять как в
    составе отдельной Техоперации, так и отдельно - с помощью специальных ресурсов для управления
    материалами и продуктами Техоперации. Кодом сущности для Техоперации в составе JSON API
    является ключевое слово processing. Больше о Техоперациях и работе с ними в основном интерфейсе
    вы можете прочитать в нашей службе поддержки по этой ссылке.

    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Техоперации
    :param created: Дата создания
    :param deleted: Момент последнего удаления Техоперации
    :param description: Комментарий Техоперации
    :param external_code: Внешний код Техоперации
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param materials: Список Метаданных материалов Техоперации
    :param materials_store: Метаданные склада для материалов
    :param moment: Дата документа
    :param name: Наименование Техоперации
    :param organization: Метаданные юрлица
    :param organization_account: Метаданные счета юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param processing_plan: Метаданные Техкарты
    :param processing_sum: Затраты на производство за единицу объема производства
    :param products: Список Метаданных готовых продуктов Техоперации
    :param products_store: Метаданные склада для продукции
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param quantity: Объем производства
    :param shared: Общий доступ
    :param state: Метаданные статуса Техоперации
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Техоперации
    :param processing_order: Ссылка на заказ на производство в формате
    :param assortment: Метаданные товара/партии/модификации, которую представляет собой позиция

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing
    """

    __return__ = MetaArray[Processing]
    __api_method__ = "entity/processing"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/processing"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
