from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.retaildrawercashin import Retaildrawercashin
from .base import MSMethod


class GetRetaildrawercashin(MSMethod):
    """
    Средствами JSON API можно создавать и обновлять сведения о Внесениях денег, запрашивать списки
    Внесений денег и сведения по отдельным Внесениям денег. Кодом сущности для Внесения денег в
    составе JSON API является ключевое слово retaildrawercashin. Больше о Внесениях денег и работе
    с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке.

    :param agent: Метаданные контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param created: Дата создания
    :param deleted: Момент последнего удаления Внесения денег
    :param description: Комментарий Внесения денег
    :param external_code: Внешний код Внесения денег
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Внесения денег
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Внесения денег
    :param sum: Сумма Внесения денег в копейках
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Внесения денег
    :param retail_shift: Ссылка на розничную смену, в рамках которой было выполнено Внесение денег
        в формате . По данному полю можно фильтровать используя операторы = и !=. `Необходимое`

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashin
    """

    __return__ = Retaildrawercashin
    __api_method__ = "entity/retaildrawercashin"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashin"

    id: str = Field(..., alias="retaildrawercashin_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
