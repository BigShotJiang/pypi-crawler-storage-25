from collections.abc import Sequence

from ..client.filters import Condition
from ..types.meta import MetaArray
from ..types.productionstagecompletion import Productionstagecompletion
from .base import MSMethod


class GetProductionstagecompletions(MSMethod):
    """
    Кодом сущности для Выполнения этапа производства в составе JSON API является ключевое слово
    productionstagecompletion.

    :param applicable: Отметка о проведении
    :param created: Дата создания
    :param defect: Признак брака
    :param description: Комментарий Выполнения этапа
    :param enable_hour_accounting: Признак активности учета по нормо-часам
    :param external_code: Внешний код Выполнения этапа производства
    :param group: Отдел сотрудника
    :param labour_unit_cost: Оплата труда за единицу объема производства
    :param standard_hour_unit: Нормо-часы единицы объема производства
    :param materials: Метаданные Материалов выполнения этапа производства.
    :param moment: Дата документа
    :param name: Наименование Выполнения этапа производства
    :param owner: Владелец (Сотрудник)
    :param performer: Исполнитель (Сотрудник)
    :param processing_unit_cost: Затраты на единицу объема производства
    :param production_stage:
    :param production_volume: Объем производства
    :param products: Метаданные Продуктов выполнения этапа производства. Есть только у последнего
        этапа.
    :param service: Услуга, выполняемая контрагентом
    :param shared: Общий доступ
    :param standard_hour_cost: Стоимость нормо-часа
    :param updated: Момент последнего обновления Выполнения этапа производства

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion
    """

    __return__ = MetaArray[Productionstagecompletion]
    __api_method__ = "entity/productionstagecompletion"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/productionStageCompletion"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
