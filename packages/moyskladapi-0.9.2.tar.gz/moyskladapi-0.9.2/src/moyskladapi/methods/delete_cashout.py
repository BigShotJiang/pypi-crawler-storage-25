from pydantic import Field

from ..types.cashout import Cashout
from .base import MSMethod


class DeleteCashout(MSMethod[Cashout]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Расходном ордере, запрашивать списки
    Расходных ордеров  и сведения по отдельным Расходных ордеров. Кодом сущности для Расходного
    ордера  в составе JSON API является ключевое слово cashout.

    :param agent: Метаданные контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Расходного ордера
    :param contract: Метаданные договора
    :param created: Дата создания
    :param deleted: Момент последнего удаления Расходного ордера
    :param description: Комментарий Расходного ордера
    :param expense_item: Метаданные Статьи расходов
    :param external_code: Внешний код Расходного ордера
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param no_closing_docs: Признак "Без закрывающих документов". Нельзя одновременно передать
        **noClosingDocs = true** и непустой **operations**
    :param moment: Дата документа
    :param name: Наименование Расходного ордера
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param payment_purpose: Основание
    :param printed: Напечатан ли документ
    :param project: Метаданные проекта
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param sales_channel: Метаданные канала продаж
    :param shared: Общий доступ
    :param state: Метаданные статуса Расходного ордера
    :param sum: Сумма расходного ордера в установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Расходного ордера
    :param vat_sum: Сумма НДС
    :param facture_in: Ссылка на Счет-фактуру полученный, с которым связан этот платеж в формате
    :param operations: Массив ссылок на связанные операции в формате

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout
    """

    __return__ = Cashout
    __api_method__ = "entity/cashout"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/cashout"

    id: str = Field(..., alias="cashout_id")
