from pydantic import Field

from ..types.retaildrawercashout import Retaildrawercashout
from .base import MSMethod


class DeleteRetaildrawercashout(MSMethod[Retaildrawercashout]):
    """
    Средствами JSON API можно создавать и обновлять сведения о Выплатах денег, запрашивать списки
    Выплат денег и сведения по отдельным Выплатам денег. Кодом сущности для внесения денег в
    составе JSON API является ключевое слово retaildrawercashout. Больше о Выплатах денег и работе
    с ними в основном интерфейсе вы можете прочитать в нашей службе поддержки по  этой ссылке

    :param agent: Метаданные контрагента
    :param applicable: Отметка о проведении
    :param attributes: Коллекция метаданных доп. полей.
    :param code: Код Выплаты денег
    :param created: Дата создания
    :param deleted: Момент последнего удаления Выплаты денег
    :param description: Комментарий Выплаты денег
    :param external_code: Внешний код Выплаты денег
    :param files: Метаданные массива (Максимальное количество файлов - 100)
    :param group: Отдел сотрудника
    :param moment: Дата документа
    :param name: Наименование Выплаты денег
    :param organization: Метаданные юрлица
    :param owner: Владелец (Сотрудник)
    :param printed: Напечатан ли документ
    :param published: Опубликован ли документ
    :param rate: Валюта.
    :param shared: Общий доступ
    :param state: Метаданные статуса Выплаты денег
    :param sum: Сумма Выплаты денег установленной валюте
    :param sync_id: ID синхронизации. После заполнения недоступен для изменения
    :param updated: Момент последнего обновления Выплаты денег
    :param retail_shift: Ссылка на розничную смену, в рамках которой было выполнено Внесение денег
        в формате . По данному полю можно фильтровать используя операторы = и !=. `Необходимое`

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashout
    """

    __return__ = Retaildrawercashout
    __api_method__ = "entity/retaildrawercashout"
    __http_method__ = "DELETE"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/retaildrawercashout"

    id: str = Field(..., alias="retaildrawercashout_id")
