from collections.abc import Sequence

from ..client.filters import Condition
from ..types.emissionorder import Emissionorder
from ..types.meta import MetaArray
from .base import MSMethod


class GetEmissionorders(MSMethod):
    """
    Для создания/изменения Заказов кодов маркировки необходима тарифная опция Маркировка для
    аккаунтов из RU региона и расширение Честный знак для остальных регионов.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder
    """

    __return__ = MetaArray[Emissionorder]
    __api_method__ = "entity/emissionorder"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/documents/emissionorder"

    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
