from collections.abc import Sequence

from pydantic import Field

from ..client.filters import Condition
from ..types.companysettings import Companysettings
from .base import MSMethod


class GetCompanysettings(MSMethod):
    """
    Кодом сущности для Настройки компании в составе JSON API является ключевое слово
    companysettings. На данный момент можно получить информацию о текущих настройках компании и
    типах цен товаров.

    Source: https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/companysettings
    """

    __return__ = Companysettings
    __api_method__ = "entity/companysettings"
    __doc_url__ = "https://dev.moysklad.ru/doc/api/remap/1.2/#/dictionaries/companysettings"

    id: str = Field(..., alias="companysettings_id")
    limit: int | None = None
    offset: int | None = None
    expand: Sequence[str] | str | None = None
    filters: Condition | Sequence[Condition] | None = None
    order: str | None = None
