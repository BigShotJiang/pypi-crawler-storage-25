from enum import StrEnum


class TransactionStatus(StrEnum):
    WAIT_PROCESSING = "WAIT_PROCESSING"
    COMPLETED = "COMPLETED"
    CANCELED = "CANCELED"
