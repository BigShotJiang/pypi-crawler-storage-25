from enum import StrEnum


class DiffType(StrEnum):
    NONE = "NONE"
