from enum import StrEnum


class Method(StrEnum):
    POST = "POST"
