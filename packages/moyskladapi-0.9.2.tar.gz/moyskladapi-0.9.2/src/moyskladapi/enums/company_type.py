from enum import StrEnum


class CompanyType(StrEnum):
    LEGAL = "legal"
    ENTREPRENEUR = "entrepreneur"
    INDIVIDUAL = "individual"
    LEGALUZ = "legalUZ"
    ENTREPRENEURUZ = "entrepreneurUZ"
    INDIVIDUALUZ = "individualUZ"
    LEGALKZ = "legalKZ"
    ENTREPRENEURKZ = "entrepreneurKZ"
    INDIVIDUALKZ = "individualKZ"
