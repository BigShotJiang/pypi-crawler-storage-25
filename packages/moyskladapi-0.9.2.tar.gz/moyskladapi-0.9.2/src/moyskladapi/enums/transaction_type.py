from enum import StrEnum


class TransactionType(StrEnum):
    EARNING = "EARNING"
    SPENDING = "SPENDING"
