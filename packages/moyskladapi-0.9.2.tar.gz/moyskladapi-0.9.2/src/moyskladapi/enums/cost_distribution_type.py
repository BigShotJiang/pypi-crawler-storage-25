from enum import StrEnum


class CostDistributionType(StrEnum):
    BY_PRICE = "BY_PRICE"
    BY_PRODUCTION = "BY_PRODUCTION"
