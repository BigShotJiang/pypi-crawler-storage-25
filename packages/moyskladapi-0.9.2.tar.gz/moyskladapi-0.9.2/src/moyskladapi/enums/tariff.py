from enum import StrEnum


class Tariff(StrEnum):
    BASIC = "BASIC"
    CORPORATE = "CORPORATE"
    FREE = "FREE"
    MINIMAL = "MINIMAL"
    PROFESSIONAL = "PROFESSIONAL"
    RETAIL = "RETAIL"
    START = "START"
    TRIAL = "TRIAL"
