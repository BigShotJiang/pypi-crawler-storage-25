from enum import StrEnum


class EmissionType(StrEnum):
    LOCAL = "LOCAL"
    FOREIGN = "FOREIGN"
    REMAINS = "REMAINS"
    CROSSBORDER = "CROSSBORDER"
    COMMISSION = "COMMISSION"
