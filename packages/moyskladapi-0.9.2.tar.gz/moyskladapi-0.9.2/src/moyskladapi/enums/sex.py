from enum import StrEnum


class Sex(StrEnum):
    MALE = "MALE"
    FEMALE = "FEMALE"
