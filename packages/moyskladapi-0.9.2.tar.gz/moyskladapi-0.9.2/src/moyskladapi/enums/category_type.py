from enum import StrEnum


class CategoryType(StrEnum):
    REGULAR = "REGULAR"
    WELCOME = "WELCOME"
