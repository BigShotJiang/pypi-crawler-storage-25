from enum import StrEnum


class Update(StrEnum):
    NO = "NO"
    AUTHOR_OR_ASSIGNEE = "AUTHOR_OR_ASSIGNEE"
    ASSIGNEE = "ASSIGNEE"
    AUTHOR = "AUTHOR"
    ALL = "ALL"
