from enum import StrEnum


class WelcomeBonusesMode(StrEnum):
    REGISTRATION = "REGISTRATION"
    FIRST_PURCHASE = "FIRST_PURCHASE"
