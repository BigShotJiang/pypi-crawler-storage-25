from .client.api import MoyskladAPI
from .client.filters import Filter


F = Filter()


__all__ = (
    "MoyskladAPI",
    "F",
)
