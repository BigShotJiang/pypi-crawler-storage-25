from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .group import Group
from .image import Image
from .meta import Entity


class Employee(Entity):
    archived: bool | None = Field(None, alias="archived")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    cashiers: dict | list | None = Field(None, alias="cashiers")
    created: datetime | None = Field(None, alias="created")
    description: str | None = Field(None, alias="description")
    email: str | None = Field(None, alias="email")
    external_code: str | None = Field(None, alias="externalCode")
    first_name: str | None = Field(None, alias="firstName")
    full_name: str | None = Field(None, alias="fullName")
    group: Group | None = Field(None, alias="group")
    image: Image | None = Field(None, alias="image")
    inn: str | None = Field(None, alias="inn")
    last_name: str | None = Field(None, alias="lastName")
    middle_name: str | None = Field(None, alias="middleName")
    name: str | None = Field(None, alias="name")
    owner: dict | None = Field(None, alias="owner")
    phone: str | None = Field(None, alias="phone")
    position: str | None = Field(None, alias="position")
    salary: dict | None = Field(None, alias="salary")
    shared: bool | None = Field(None, alias="shared")
    short_fio: str | None = Field(None, alias="shortFio")
    uid: str | None = Field(None, alias="uid")
    updated: datetime | None = Field(None, alias="updated")
    value: float | None = Field(None, alias="value")
    employee: dict | None = Field(None, alias="employee")
    retail_store: dict | None = Field(None, alias="retailStore")
    filename: str | None = Field(None, alias="filename")
    miniature: dict | None = Field(None, alias="miniature")
    tiny: dict | None = Field(None, alias="tiny")
    title: str | None = Field(None, alias="title")
    content: dict | None = Field(None, alias="content")
