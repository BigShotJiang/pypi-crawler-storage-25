from pydantic import Field

from .employee import Employee
from .meta import Entity


class Cashier(Entity):
    employee: Employee | None = Field(None, alias="employee")
    retail_store: dict | None = Field(None, alias="retailStore")
