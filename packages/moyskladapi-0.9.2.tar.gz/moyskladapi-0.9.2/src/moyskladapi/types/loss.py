from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .country import Country
from .group import Group
from .inventory import Inventory
from .meta import Entity
from .organization import Organization
from .project import Project
from .state import State
from .store import Store


class Loss(Entity):
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    expense_item: dict | None = Field(None, alias="expenseItem")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    positions: dict | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    store: Store | None = Field(None, alias="store")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    sales_return: dict | None = Field(None, alias="salesReturn")
    inventory: Inventory | None = Field(None, alias="inventory")
    gtd: str | None = Field(None, alias="gtd")
    rnpt: str | None = Field(None, alias="rnpt")
    country: Country | None = Field(None, alias="country")
    quantity: float | None = Field(None, alias="quantity")
