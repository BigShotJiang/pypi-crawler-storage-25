from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .contract import Contract
from .counterparty import Counterparty
from .group import Group
from .meta import Entity
from .organization import Organization
from .project import Project
from .state import State


class Commissionreportin(Entity):
    id: str | None = Field(None, alias="id")
    agent: Counterparty | None = Field(None, alias="agent")
    agent_account: dict | None = Field(None, alias="agentAccount")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    commission_overhead: dict | None = Field(None, alias="commissionOverhead")
    commission_period_end: datetime | None = Field(None, alias="commissionPeriodEnd")
    commission_period_start: datetime | None = Field(None, alias="commissionPeriodStart")
    commitent_sum: float | None = Field(None, alias="commitentSum")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    organization_account: dict | None = Field(None, alias="organizationAccount")
    owner: dict | None = Field(None, alias="owner")
    payed_sum: float | None = Field(None, alias="payedSum")
    positions: dict | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    return_to_commissioner_positions: dict | list | None = Field(
        None, alias="returnToCommissionerPositions"
    )
    reward_percent: int | None = Field(None, alias="rewardPercent")
    reward_type: str | None = Field(None, alias="rewardType")
    sales_channel: dict | None = Field(None, alias="salesChannel")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
    payments: list | None = Field(None, alias="payments")
