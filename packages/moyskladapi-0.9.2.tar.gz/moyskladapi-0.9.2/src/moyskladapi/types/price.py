from pydantic import Field

from .currency import Currency
from .meta import Entity
from .pricetype import Pricetype


class Price(Entity):
    value: float | None = Field(None, alias="value")
    currency: Currency | None = Field(None, alias="currency")
    price_type: Pricetype | None = Field(None, alias="priceType")
