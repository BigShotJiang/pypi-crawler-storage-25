from datetime import datetime

from pydantic import Field

from ..enums.category_type import CategoryType
from ..enums.transaction_status import TransactionStatus
from ..enums.transaction_type import TransactionType
from .group import Group
from .meta import Entity
from .organization import Organization


class Bonustransaction(Entity):
    agent: dict | None = Field(None, alias="agent")
    applicable: bool | None = Field(None, alias="applicable")
    bonus_program: dict | None = Field(None, alias="bonusProgram")
    bonus_value: int | None = Field(None, alias="bonusValue")
    category_type: CategoryType | None = Field(None, alias="categoryType")
    code: str | None = Field(None, alias="code")
    created: datetime | None = Field(None, alias="created")
    description: str | None = Field(None, alias="description")
    execution_date: datetime | None = Field(None, alias="executionDate")
    external_code: str | None = Field(None, alias="externalCode")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    parent_document: dict | None = Field(None, alias="parentDocument")
    shared: bool | None = Field(None, alias="shared")
    transaction_status: TransactionStatus | None = Field(None, alias="transactionStatus")
    transaction_type: TransactionType | None = Field(None, alias="transactionType")
    updated: datetime | None = Field(None, alias="updated")
    updated_by: str | None = Field(None, alias="updatedBy")
