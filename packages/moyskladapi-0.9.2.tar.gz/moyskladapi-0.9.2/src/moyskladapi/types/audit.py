from datetime import datetime

from pydantic import Field

from .meta import Entity


class Audit(Entity):
    entity_type: str | None = Field(None, alias="entityType")
    event_type: str | None = Field(None, alias="eventType")
    events: list | None = Field(None, alias="events")
    info: dict | None = Field(None, alias="info")
    moment: datetime | None = Field(None, alias="moment")
    object_count: int | None = Field(None, alias="objectCount")
    object_type: str | None = Field(None, alias="objectType")
    source: str | None = Field(None, alias="source")
    support_access: bool | None = Field(None, alias="supportAccess")
    uid: str | None = Field(None, alias="uid")
    registration: dict | None = Field(None, alias="registration")
    clearrecyclebin: dict | None = Field(None, alias="clearrecyclebin")
    combine: dict | None = Field(None, alias="combine")
    bulkcreate: dict | None = Field(None, alias="bulkcreate")
    connectors: dict | None = Field(None, alias="connectors")
    copy_: dict | None = Field(None, alias="copy")
    emailsend: dict | None = Field(None, alias="emailsend")
    evotor: dict | None = Field(None, alias="evotor")
    export: dict | None = Field(None, alias="export")
    exportediclient1c: dict | None = Field(None, alias="exportediclient1c")
    import_: dict | None = Field(None, alias="import")
    import1c: dict | None = Field(None, alias="import1c")
    import_alfabank: dict | None = Field(None, alias="importAlfabank")
    import_modulebank: dict | None = Field(None, alias="importModulebank")
    import_tinkoffbank: dict | None = Field(None, alias="importTinkoffbank")
    import_tochkabank: dict | None = Field(None, alias="importTochkabank")
    importediclient1c: dict | None = Field(None, alias="importediclient1c")
    loginlogout: dict | None = Field(None, alias="loginlogout")
    posapi: dict | None = Field(None, alias="posapi")
    restapi: dict | None = Field(None, alias="restapi")
    retail: dict | None = Field(None, alias="retail")
    app: dict | None = Field(None, alias="app")
