from pydantic import Field

from .meta import Entity


class Namedfilter(Entity):
    name: str | None = Field(None, alias="name")
    owner: dict | None = Field(None, alias="owner")
