from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .contract import Contract
from .group import Group
from .meta import Entity
from .organization import Organization
from .state import State


class Facturein(Entity):
    agent: dict | None = Field(None, alias="agent")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    supplies: list | None = Field(None, alias="supplies")
    payments: list | None = Field(None, alias="payments")
    incoming_number: str | None = Field(None, alias="incomingNumber")
    incoming_date: datetime | None = Field(None, alias="incomingDate")
