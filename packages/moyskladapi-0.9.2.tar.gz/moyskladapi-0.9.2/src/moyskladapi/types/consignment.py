from datetime import datetime

from pydantic import Field

from .assortment import Assortment
from .attribute import Attribute
from .barcode import Barcode
from .image import Image
from .meta import Entity, MetaArray


class Consignment(Entity):
    archived: bool | None = Field(None, alias="archived")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    assortment: Assortment | None = Field(None, alias="assortment")
    barcodes: list[Barcode] | None = Field(None, alias="barcodes")
    code: str | None = Field(None, alias="code")
    description: str | None = Field(None, alias="description")
    expiry_date: datetime | None = Field(None, alias="expiryDate")
    external_code: str | None = Field(None, alias="externalCode")
    images: MetaArray[Image] | list[Image] | None = Field(None, alias="images")
    label: str | None = Field(None, alias="label")
    name: str | None = Field(None, alias="name")
    updated: datetime | None = Field(None, alias="updated")
