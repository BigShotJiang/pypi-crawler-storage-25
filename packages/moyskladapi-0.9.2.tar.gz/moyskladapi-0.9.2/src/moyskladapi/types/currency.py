from pydantic import Field

from .meta import Entity


class Currency(Entity):
    archived: bool | None = Field(None, alias="archived")
    code: str | None = Field(None, alias="code")
    default: bool | None = Field(None, alias="default")
    full_name: str | None = Field(None, alias="fullName")
    indirect: bool | None = Field(None, alias="indirect")
    iso_code: str | None = Field(None, alias="isoCode")
    major_unit: dict | None = Field(None, alias="majorUnit")
    margin: float | None = Field(None, alias="margin")
    minor_unit: dict | None = Field(None, alias="minorUnit")
    multiplicity: int | None = Field(None, alias="multiplicity")
    name: str | None = Field(None, alias="name")
    rate: float | None = Field(None, alias="rate")
    rate_update_type: str | None = Field(None, alias="rateUpdateType")
    system: bool | None = Field(None, alias="system")
