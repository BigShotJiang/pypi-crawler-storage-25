from datetime import datetime

from pydantic import Field

from ..enums.payment_item_type import PaymentItemType
from ..enums.tax_system import TaxSystem
from ..enums.tracking_type import TrackingType
from ..enums.type import Type
from .attribute import Attribute
from .barcode import Barcode
from .counterparty import Counterparty
from .country import Country
from .currency import Currency
from .group import Group
from .image import Image
from .meta import Entity, MetaArray
from .price import Price
from .product import Product
from .productfolder import Productfolder
from .uom import Uom


class Assortment(Entity):
    id: str | None = Field(None, alias="id")
    archived: bool | None = Field(None, alias="archived")
    article: str | None = Field(None, alias="article")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    barcodes: list[Barcode] | None = Field(None, alias="barcodes")
    buy_price: dict | None = Field(None, alias="buyPrice")
    characteristics: list | None = Field(None, alias="characteristics")
    code: str | None = Field(None, alias="code")
    country: Country | None = Field(None, alias="country")
    description: str | None = Field(None, alias="description")
    discount_prohibited: bool | None = Field(None, alias="discountProhibited")
    effective_vat: int | None = Field(None, alias="effectiveVat")
    effective_vat_enabled: bool | None = Field(None, alias="effectiveVatEnabled")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    images: MetaArray[Image] | list[Image] | None = Field(None, alias="images")
    is_serial_trackable: bool | None = Field(None, alias="isSerialTrackable")
    min_price: dict | None = Field(None, alias="minPrice")
    minimum_balance: float | None = Field(None, alias="minimumBalance")
    minimum_stock: dict | None = Field(None, alias="minimumStock")
    name: str | None = Field(None, alias="name")
    owner: dict | None = Field(None, alias="owner")
    packs: list | None = Field(None, alias="packs")
    partial_disposal: bool | None = Field(None, alias="partialDisposal")
    path_name: str | None = Field(None, alias="pathName")
    payment_item_type: PaymentItemType | None = Field(None, alias="paymentItemType")
    product: Product | None = Field(None, alias="product")
    product_folder: Productfolder | None = Field(None, alias="productFolder")
    quantity: float | None = Field(None, alias="quantity")
    sale_prices: list[Price] | None = Field(None, alias="salePrices")
    shared: bool | None = Field(None, alias="shared")
    supplier: Counterparty | None = Field(None, alias="supplier")
    sync_id: str | None = Field(None, alias="syncId")
    tax_system: TaxSystem | None = Field(None, alias="taxSystem")
    things: list[str] | None = Field(None, alias="things")
    tnved: str | None = Field(None, alias="tnved")
    tracking_type: TrackingType | None = Field(None, alias="trackingType")
    type: Type | None = Field(None, alias="type")
    uom: Uom | None = Field(None, alias="uom")
    updated: datetime | None = Field(None, alias="updated")
    use_parent_vat: bool | None = Field(None, alias="useParentVat")
    variants_count: int | None = Field(None, alias="variantsCount")
    vat: int | None = Field(None, alias="vat")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    volume: float | None = Field(None, alias="volume")
    weight: float | None = Field(None, alias="weight")
    currency: Currency | None = Field(None, alias="currency")
    price_type: dict | None = Field(None, alias="priceType")
    value: float | None = Field(None, alias="value")
    ikpu: str | None = Field(None, alias="ikpu")
    pack_code: str | None = Field(None, alias="packCode")
    barcode_tasnif: str | None = Field(None, alias="barcodeTasnif")
    ntin: str | None = Field(None, alias="ntin")
