from pydantic import Field

from .meta import Entity


class Group(Entity):
    index: int | None = Field(None, alias="index")
    name: str | None = Field(None, alias="name")
