from pydantic import Field

from .currency import Currency
from .meta import Entity


class Companysettings(Entity):
    account_country: str | None = Field(None, alias="accountCountry")
    check_min_price: bool | None = Field(None, alias="checkMinPrice")
    check_shipping_stock: bool | None = Field(None, alias="checkShippingStock")
    company_address: str | None = Field(None, alias="companyAddress")
    currency: Currency | None = Field(None, alias="currency")
    discount_strategy: str | None = Field(None, alias="discountStrategy")
    global_operation_numbering: bool | None = Field(None, alias="globalOperationNumbering")
    price_types: list | None = Field(None, alias="priceTypes")
    use_company_address: bool | None = Field(None, alias="useCompanyAddress")
    use_recycle_bin: bool | None = Field(None, alias="useRecycleBin")
