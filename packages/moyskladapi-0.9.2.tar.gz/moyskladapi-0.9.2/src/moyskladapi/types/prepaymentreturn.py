from datetime import datetime

from pydantic import Field

from ..enums.tax_system import TaxSystem
from .attribute import Attribute
from .group import Group
from .meta import Entity
from .organization import Organization
from .state import State


class Prepaymentreturn(Entity):
    agent: dict | None = Field(None, alias="agent")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    cash_sum: float | None = Field(None, alias="cashSum")
    code: str | None = Field(None, alias="code")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    no_cash_sum: float | None = Field(None, alias="noCashSum")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    positions: dict | None = Field(None, alias="positions")
    prepayment: dict | None = Field(None, alias="prepayment")
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    qr_sum: float | None = Field(None, alias="qrSum")
    rate: dict | None = Field(None, alias="rate")
    retail_shift: dict | None = Field(None, alias="retailShift")
    retail_store: dict | None = Field(None, alias="retailStore")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    tax_system: TaxSystem | None = Field(None, alias="taxSystem")
    updated: datetime | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
