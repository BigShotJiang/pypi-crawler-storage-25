from pydantic import Field

from .meta import Entity


class Inventory(Entity):
    search: dict | None = Field(None, alias="search")
