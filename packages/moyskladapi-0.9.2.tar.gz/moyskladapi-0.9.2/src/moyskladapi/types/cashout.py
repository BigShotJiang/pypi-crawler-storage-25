from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .contract import Contract
from .group import Group
from .meta import Entity
from .organization import Organization
from .project import Project
from .state import State


class Cashout(Entity):
    agent: dict | None = Field(None, alias="agent")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    expense_item: dict | None = Field(None, alias="expenseItem")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    no_closing_docs: bool | None = Field(None, alias="noClosingDocs")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    payment_purpose: str | None = Field(None, alias="paymentPurpose")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    sales_channel: dict | None = Field(None, alias="salesChannel")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    vat_sum: float | None = Field(None, alias="vatSum")
    facture_in: dict | None = Field(None, alias="factureIn")
    operations: list | None = Field(None, alias="operations")
