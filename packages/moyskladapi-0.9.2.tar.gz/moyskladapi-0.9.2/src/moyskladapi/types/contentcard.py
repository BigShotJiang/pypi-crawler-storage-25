from pydantic import Field

from .assortment import Assortment
from .group import Group
from .meta import Entity


class Contentcard(Entity):
    assortment: Assortment | None = Field(None, alias="assortment")
    card_content_name: str | None = Field(None, alias="cardContentName")
    description: str | None = Field(None, alias="description")
    group: Group | None = Field(None, alias="group")
    name: str | None = Field(None, alias="name")
    owner: dict | None = Field(None, alias="owner")
    shared: bool | None = Field(None, alias="shared")
    sale_platform: dict | None = Field(None, alias="salePlatform")
    sales_channels: dict | list | None = Field(None, alias="salesChannels")
    sales_channel: dict | None = Field(None, alias="salesChannel")
