from pydantic import Field

from .meta import Entity, Meta


class Attribute(Entity):
    id: str | None
    name: str | None = Field(None, alias="name")
    type: str | None = Field(None, alias="type")
    value: str | float | bool | dict | None = Field(None, alias="value")
    required: bool | None = Field(None, alias="required")
    customentity_meta: Meta | None = Field(None, alias="customEntityMeta")
    description: str | None = Field(None, alias="description")
