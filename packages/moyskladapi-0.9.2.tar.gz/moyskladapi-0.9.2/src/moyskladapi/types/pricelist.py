from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .group import Group
from .meta import Entity
from .organization import Organization
from .state import State


class Pricelist(Entity):
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    columns: list | None = Field(None, alias="columns")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    positions: dict | None = Field(None, alias="positions")
    price_type: dict | None = Field(None, alias="priceType")
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    percentage_discount: int | None = Field(None, alias="percentageDiscount")
    column: str | None = Field(None, alias="column")
    sum: int | None = Field(None, alias="sum")
