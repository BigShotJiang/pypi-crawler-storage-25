from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .group import Group
from .meta import Entity
from .organization import Organization


class Counterpartyadjustment(Entity):
    agent: dict | None = Field(None, alias="agent")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    shared: bool | None = Field(None, alias="shared")
    sum: float | None = Field(None, alias="sum")
    updated: datetime | None = Field(None, alias="updated")
