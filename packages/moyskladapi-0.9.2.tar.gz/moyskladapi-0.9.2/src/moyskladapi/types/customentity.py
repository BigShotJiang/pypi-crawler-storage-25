from pydantic import Field

from .meta import Entity


class Customentity(Entity):
    name: str | None = Field(None, alias="name")
