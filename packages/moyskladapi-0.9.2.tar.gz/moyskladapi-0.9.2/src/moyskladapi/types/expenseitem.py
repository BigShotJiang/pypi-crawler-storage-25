from datetime import datetime

from pydantic import Field

from .meta import Entity


class Expenseitem(Entity):
    code: str | None = Field(None, alias="code")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    name: str | None = Field(None, alias="name")
    updated: datetime | None = Field(None, alias="updated")
