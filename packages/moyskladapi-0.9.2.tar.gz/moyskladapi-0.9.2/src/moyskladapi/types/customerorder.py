from datetime import datetime

from pydantic import Field

from ..enums.tax_system import TaxSystem
from .attribute import Attribute
from .contract import Contract
from .demand import Demand
from .group import Group
from .meta import Entity
from .move import Move
from .organization import Organization
from .prepayment import Prepayment
from .project import Project
from .state import State
from .store import Store


class Customerorder(Entity):
    agent: dict | None = Field(None, alias="agent")
    agent_account: dict | None = Field(None, alias="agentAccount")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    delivery_planned_moment: datetime | None = Field(None, alias="deliveryPlannedMoment")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    invoiced_sum: float | None = Field(None, alias="invoicedSum")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    organization_account: dict | None = Field(None, alias="organizationAccount")
    owner: dict | None = Field(None, alias="owner")
    payed_sum: float | None = Field(None, alias="payedSum")
    positions: dict | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    reserved_sum: float | None = Field(None, alias="reservedSum")
    sales_channel: dict | None = Field(None, alias="salesChannel")
    shared: bool | None = Field(None, alias="shared")
    shipment_address: str | None = Field(None, alias="shipmentAddress")
    shipment_address_full: dict | None = Field(None, alias="shipmentAddressFull")
    shipped_sum: float | None = Field(None, alias="shippedSum")
    state: State | None = Field(None, alias="state")
    store: Store | None = Field(None, alias="store")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    tax_system: TaxSystem | None = Field(None, alias="taxSystem")
    updated: datetime | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
    purchase_orders: list | None = Field(None, alias="purchaseOrders")
    demands: list[Demand] | None = Field(None, alias="demands")
    payments: list | None = Field(None, alias="payments")
    production_tasks: list | None = Field(None, alias="productionTasks")
    invoices_out: list | None = Field(None, alias="invoicesOut")
    moves: list[Move] | None = Field(None, alias="moves")
    prepayments: list[Prepayment] | None = Field(None, alias="prepayments")
