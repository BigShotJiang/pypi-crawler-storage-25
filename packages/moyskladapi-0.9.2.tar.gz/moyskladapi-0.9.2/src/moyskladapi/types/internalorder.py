from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .group import Group
from .meta import Entity
from .move import Move
from .organization import Organization
from .project import Project
from .state import State
from .store import Store


class Internalorder(Entity):
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    delivery_planned_moment: datetime | None = Field(None, alias="deliveryPlannedMoment")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    moves: list[Move] | None = Field(None, alias="moves")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    positions: dict | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    purchase_orders: list | None = Field(None, alias="purchaseOrders")
    rate: dict | None = Field(None, alias="rate")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    store: Store | None = Field(None, alias="store")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
    purchase_order: dict | None = Field(None, alias="purchaseOrder")
    move: Move | None = Field(None, alias="move")
    processing_order: dict | None = Field(None, alias="processingOrder")
    production_tasks: list | None = Field(None, alias="productionTasks")
