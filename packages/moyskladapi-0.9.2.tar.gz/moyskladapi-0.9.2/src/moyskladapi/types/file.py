from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from .meta import Entity, Meta


class FileInput(BaseModel):
    """Входные данные для загрузки файла: имя и содержимое в Base64."""

    filename: str
    content: str


class File(Entity):
    """Файл, прикреплённый к Операции, Номенклатуре, Задаче или Контрагенту."""

    created: datetime | None = Field(None, alias="created")
    created_by: Entity | None = Field(None, alias="createdBy")
    filename: str | None = Field(None, alias="filename")
    miniature: Meta | None = Field(None, alias="miniature")
    size: int | None = Field(None, alias="size")
    tiny: Meta | None = Field(None, alias="tiny")
    title: str | None = Field(None, alias="title")
