from datetime import datetime

from pydantic import Field

from .assortment import Assortment
from .attribute import Attribute
from .contract import Contract
from .group import Group
from .meta import Entity, Meta, MetaArray
from .organization import Organization
from .project import Project
from .state import State
from .store import Store


class DemandPosition(Entity):
    account_id: str | None = Field(None, alias="accountId")
    assortment: Assortment | None = Field(None, alias="assortment")
    cost: int | None = Field(None, alias="cost")
    declaration: list | None = Field(None, alias="declaration")
    discount: float | None = Field(None, alias="discount")
    id: str | None = Field(None, alias="id")
    pack: dict | None = Field(None, alias="pack")
    price: float | None = Field(None, alias="price")
    quantity: float | None = Field(None, alias="quantity")
    slot: Meta | None = Field(None, alias="slot")
    things: list[str] | None = Field(None, alias="things")
    tracking_codes: list | None = Field(None, alias="trackingCodes")
    tracking_codes_1162: list | None = Field(None, alias="trackingCodes_1162")
    overhead: int | None = Field(None, alias="overhead")
    vat: int | None = Field(None, alias="vat")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")


class Demand(Entity):
    agent: dict | None = Field(None, alias="agent")
    agent_account: dict | None = Field(None, alias="agentAccount")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    organization_account: dict | None = Field(None, alias="organizationAccount")
    overhead: dict | None = Field(None, alias="overhead")
    owner: dict | None = Field(None, alias="owner")
    payed_sum: float | None = Field(None, alias="payedSum")
    positions: MetaArray[DemandPosition] | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    sales_channel: dict | None = Field(None, alias="salesChannel")
    shared: bool | None = Field(None, alias="shared")
    shipment_address: str | None = Field(None, alias="shipmentAddress")
    shipment_address_full: dict | None = Field(None, alias="shipmentAddressFull")
    state: State | None = Field(None, alias="state")
    store: Store | None = Field(None, alias="store")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    vat_enabled: bool | None = Field(None, alias="vatEnabled")
    vat_included: bool | None = Field(None, alias="vatIncluded")
    vat_sum: float | None = Field(None, alias="vatSum")
    distribution: str | None = Field(None, alias="distribution")
    customer_order: dict | None = Field(None, alias="customerOrder")
    facture_out: dict | None = Field(None, alias="factureOut")
    returns: list | None = Field(None, alias="returns")
    payments: list | None = Field(None, alias="payments")
    invoices_out: list | None = Field(None, alias="invoicesOut")
    cargo_name: str | None = Field(None, alias="cargoName")
    carrier: dict | None = Field(None, alias="carrier")
    consignee: dict | None = Field(None, alias="consignee")
    good_pack_quantity: int | None = Field(None, alias="goodPackQuantity")
    shipping_instructions: str | None = Field(None, alias="shippingInstructions")
    state_contract_id: str | None = Field(None, alias="stateContractId")
    transport_facility: str | None = Field(None, alias="transportFacility")
    transport_facility_number: str | None = Field(None, alias="transportFacilityNumber")
