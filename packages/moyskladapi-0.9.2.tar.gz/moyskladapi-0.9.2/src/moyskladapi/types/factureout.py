from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .contract import Contract
from .demand import Demand
from .group import Group
from .meta import Entity
from .organization import Organization
from .state import State


class Factureout(Entity):
    agent: dict | None = Field(None, alias="agent")
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract: Contract | None = Field(None, alias="contract")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    state_contract_id: str | None = Field(None, alias="stateContractId")
    sum: float | None = Field(None, alias="sum")
    sync_id: str | None = Field(None, alias="syncId")
    updated: datetime | None = Field(None, alias="updated")
    advance_payment_vat: int | None = Field(None, alias="advancePaymentVat")
    payment_purpose: str | None = Field(None, alias="paymentPurpose")
    vat_sum: float | None = Field(None, alias="vatSum")
    demands: list[Demand] | None = Field(None, alias="demands")
    payments: list | None = Field(None, alias="payments")
    returns: list | None = Field(None, alias="returns")
    consignee: dict | None = Field(None, alias="consignee")
    payment_number: str | None = Field(None, alias="paymentNumber")
    payment_date: datetime | None = Field(None, alias="paymentDate")
