from datetime import datetime

from pydantic import Field

from .group import Group
from .meta import Entity


class Country(Entity):
    code: str | None = Field(None, alias="code")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    group: Group | None = Field(None, alias="group")
    name: str | None = Field(None, alias="name")
    owner: dict | None = Field(None, alias="owner")
    shared: bool | None = Field(None, alias="shared")
    updated: datetime | None = Field(None, alias="updated")
