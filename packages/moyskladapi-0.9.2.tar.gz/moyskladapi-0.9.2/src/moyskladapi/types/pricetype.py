from pydantic import Field

from .meta import Entity


class Pricetype(Entity):
    id: str | None = Field(None, alias="id")
    external_code: str | None = Field(None, alias="externalCode")
    name: str | None = Field(None, alias="name")
