from pydantic import Field

from ..enums.welcome_bonuses_mode import WelcomeBonusesMode
from .meta import Entity


class Bonusprogram(Entity):
    active: bool | None = Field(None, alias="active")
    agent_tags: list[str] | None = Field(None, alias="agentTags")
    all_agents: bool | None = Field(None, alias="allAgents")
    all_products: bool | None = Field(None, alias="allProducts")
    earn_rate_roubles_to_point: int | None = Field(None, alias="earnRateRoublesToPoint")
    earn_while_redeeming: bool | None = Field(None, alias="earnWhileRedeeming")
    max_paid_rate_percents: int | None = Field(None, alias="maxPaidRatePercents")
    name: str | None = Field(None, alias="name")
    postponed_bonuses_delay_days: int | None = Field(None, alias="postponedBonusesDelayDays")
    spend_rate_points_to_rouble: int | None = Field(None, alias="spendRatePointsToRouble")
    welcome_bonuses_enabled: bool | None = Field(None, alias="welcomeBonusesEnabled")
    welcome_bonuses_mode: WelcomeBonusesMode | None = Field(None, alias="welcomeBonusesMode")
    welcome_bonuses_value: int | None = Field(None, alias="welcomeBonusesValue")
