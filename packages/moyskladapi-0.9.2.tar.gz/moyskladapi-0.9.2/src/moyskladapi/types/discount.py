from pydantic import Field

from .meta import Entity


class Discount(Entity):
    active: bool | None = Field(None, alias="active")
    agent_tags: list[str] | None = Field(None, alias="agentTags")
    all_products: bool | None = Field(None, alias="allProducts")
    assortment: list | None = Field(None, alias="assortment")
    name: str | None = Field(None, alias="name")
    product_folders: list | None = Field(None, alias="productfolders")
    discount: float | None = Field(None, alias="discount")
    special_price: dict | None = Field(None, alias="specialPrice")
    levels: list | None = Field(None, alias="levels")
