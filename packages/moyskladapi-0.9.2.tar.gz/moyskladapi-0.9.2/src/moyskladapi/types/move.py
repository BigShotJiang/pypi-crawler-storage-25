from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .demand import Demand
from .group import Group
from .meta import Entity
from .organization import Organization
from .project import Project
from .state import State
from .supply import Supply


class Move(Entity):
    applicable: bool | None = Field(None, alias="applicable")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    created: datetime | None = Field(None, alias="created")
    deleted: datetime | None = Field(None, alias="deleted")
    demand: Demand | None = Field(None, alias="demand")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    files: dict | list | None = Field(None, alias="files")
    group: Group | None = Field(None, alias="group")
    internal_order: dict | None = Field(None, alias="internalOrder")
    customer_order: dict | None = Field(None, alias="customerOrder")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    overhead: dict | None = Field(None, alias="overhead")
    owner: dict | None = Field(None, alias="owner")
    positions: dict | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    project: Project | None = Field(None, alias="project")
    published: bool | None = Field(None, alias="published")
    rate: dict | None = Field(None, alias="rate")
    shared: bool | None = Field(None, alias="shared")
    source_store: dict | None = Field(None, alias="sourceStore")
    state: State | None = Field(None, alias="state")
    sum: float | None = Field(None, alias="sum")
    supply: Supply | None = Field(None, alias="supply")
    sync_id: str | None = Field(None, alias="syncId")
    target_store: dict | None = Field(None, alias="targetStore")
    updated: datetime | None = Field(None, alias="updated")
    distribution: str | None = Field(None, alias="distribution")
    production_tasks: list | None = Field(None, alias="productionTasks")
