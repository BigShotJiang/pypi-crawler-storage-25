from pydantic import Field

from .meta import Entity


class Barcode(Entity):
    ean8: str | None = Field(None, alias="ean8")
    ean13: str | None = Field(None, alias="ean13")
    code128: str | None = Field(None, alias="code128")
    gtin: str | None = Field(None, alias="gtin")
    upc: str | None = Field(None, alias="upc")
