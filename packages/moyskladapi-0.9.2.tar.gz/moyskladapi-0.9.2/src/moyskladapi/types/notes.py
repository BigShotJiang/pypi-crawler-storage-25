from datetime import datetime

from pydantic import Field

from .meta import Entity


class Notes(Entity):
    created: datetime | None = Field(None, alias="created")
    description: str | None = Field(None, alias="description")
    author: dict | None = Field(None, alias="author")
    author_application: dict | None = Field(None, alias="authorApplication")
