from datetime import datetime

from pydantic import Field

from .attribute import Attribute
from .group import Group
from .meta import Entity
from .state import State


class Contract(Entity):
    agent: dict | None = Field(None, alias="agent")
    agent_account: dict | None = Field(None, alias="agentAccount")
    archived: bool | None = Field(None, alias="archived")
    attributes: list[Attribute] | None = Field(None, alias="attributes")
    code: str | None = Field(None, alias="code")
    contract_type: str | None = Field(None, alias="contractType")
    description: str | None = Field(None, alias="description")
    external_code: str | None = Field(None, alias="externalCode")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization_account: dict | None = Field(None, alias="organizationAccount")
    own_agent: dict | None = Field(None, alias="ownAgent")
    owner: dict | None = Field(None, alias="owner")
    rate: dict | None = Field(None, alias="rate")
    reward_percent: int | None = Field(None, alias="rewardPercent")
    reward_type: str | None = Field(None, alias="rewardType")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    sum: int | None = Field(None, alias="sum")
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    updated: datetime | None = Field(None, alias="updated")
