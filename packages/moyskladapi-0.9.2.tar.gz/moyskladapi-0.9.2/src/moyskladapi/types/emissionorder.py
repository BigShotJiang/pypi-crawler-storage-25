from datetime import datetime

from pydantic import Field

from ..enums.document_state import DocumentState
from ..enums.emission_type import EmissionType
from ..enums.tracking_type import TrackingType
from .group import Group
from .meta import Entity
from .organization import Organization
from .state import State


class Emissionorder(Entity):
    created: datetime | None = Field(None, alias="created")
    description: str | None = Field(None, alias="description")
    document_state: DocumentState | None = Field(None, alias="documentState")
    emission_type: EmissionType | None = Field(None, alias="emissionType")
    external_code: str | None = Field(None, alias="externalCode")
    group: Group | None = Field(None, alias="group")
    moment: datetime | None = Field(None, alias="moment")
    name: str | None = Field(None, alias="name")
    organization: Organization | None = Field(None, alias="organization")
    owner: dict | None = Field(None, alias="owner")
    positions: dict | None = Field(None, alias="positions")
    printed: bool | None = Field(None, alias="printed")
    published: bool | None = Field(None, alias="published")
    shared: bool | None = Field(None, alias="shared")
    state: State | None = Field(None, alias="state")
    tracking_type: TrackingType | None = Field(None, alias="trackingType")
    updated: datetime | None = Field(None, alias="updated")
