from pydantic import Field

from ..enums.type import Type
from .meta import Entity


class Embeddedtemplate(Entity):
    type: Type | None = Field(None, alias="type")
