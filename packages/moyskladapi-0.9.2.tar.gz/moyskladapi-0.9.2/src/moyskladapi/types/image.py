from datetime import datetime

from pydantic import Field

from .meta import Entity


class Image(Entity):
    filename: str | None = Field(None, alias="filename")
    miniature: dict | None = Field(None, alias="miniature")
    tiny: dict | None = Field(None, alias="tiny")
    title: str | None = Field(None, alias="title")
    updated: datetime | None = Field(None, alias="updated")
