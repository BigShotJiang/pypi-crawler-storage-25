import asyncio
import logging
from typing import Any

from aiolimiter import AsyncLimiter
import httpx
from httpx import RequestError

from ...exceptions import Error, MoyskladAPIError
from .headers import Headers


logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)


class BaseSession:
    base_url: str
    timeout: int
    headers: Headers

    def __init__(
        self,
        base: str = "https://api.moysklad.ru/api/remap/1.2",
        timeout: int = 30,
        rate_limit: int = 45,
        rate_period: float = 3.0,
    ) -> None:
        self.base_url = base.rstrip("/")
        self.timeout = timeout
        self.headers = Headers()
        self._client = httpx.AsyncClient(timeout=self.timeout)
        self._limiter = AsyncLimiter(max_rate=rate_limit, time_period=rate_period)

    async def close(self) -> None:
        await self._client.aclose()

    async def _request(
        self,
        method: str,
        url: str,
        *,
        params: dict[str, Any] | None = None,
        json: Any | None = None,
        data: str | bytes | None = None,
    ) -> Any:
        async with self._limiter:
            try:
                response = await self._client.request(
                    method=method,
                    url=url,
                    params=params,
                    json=json,
                    content=data,
                    headers=self.headers.model_dump(),
                )
            except RequestError as e:
                raise MoyskladAPIError([Error(error=str(e))]) from e

        if response.status_code == 429:
            retry_ms = int(response.headers.get("X-Lognex-Retry-TimeInterval", 3000))
            await asyncio.sleep(retry_ms / 1000)
            return await self._request(method, url, params=params, json=json, data=data)

        if response.status_code >= 400:
            errors = []
            try:
                body = response.json()
                if isinstance(body, dict) and isinstance(body.get("errors"), list):
                    for raw in body["errors"]:
                        try:
                            errors.append(Error.model_validate(raw))
                        except Exception:
                            pass
            except Exception:
                pass
            if not errors:
                errors.append(Error(error=response.text or str(response.status_code)))
            raise MoyskladAPIError(errors, http_status=response.status_code)

        if not response.content:
            return None
        try:
            return response.json()
        except Exception:
            return None

    async def get(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        return await self._request("GET", url, params=params)

    async def post(
        self,
        url: str,
        *,
        json: Any | None = None,
        data: str | bytes | None = None,
    ) -> Any:
        return await self._request("POST", url, json=json, data=data)

    async def put(
        self,
        url: str,
        *,
        json: Any | None = None,
        data: str | bytes | None = None,
    ) -> Any:
        return await self._request("PUT", url, json=json, data=data)

    async def delete(self, url: str, *, params: dict[str, Any] | None = None) -> Any:
        return await self._request("DELETE", url, params=params)

    async def download(self, url: str) -> bytes:
        async with self._limiter:
            try:
                response = await self._client.get(
                    url,
                    headers=self.headers.model_dump(),
                    follow_redirects=True,
                )
            except RequestError as e:
                raise MoyskladAPIError([Error(error=str(e))]) from e

        if response.status_code >= 400:
            raise MoyskladAPIError(
                [Error(error=f"Download failed with status {response.status_code}")],
                http_status=response.status_code,
            )

        return response.content
