from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeVar

if TYPE_CHECKING:
    from state_machine.core import StateMachine


@dataclass(frozen=True)
class HookContext:
    """
    Argument passed to every hook handler. Generic base shared by all consumers.

    Each consumer (palletizer, sanding, etc.) extends this with a domain-specific
    subclass that adds its own integration root (services, config, model accessors,
    runtime helpers). The state machine library exposes only the generic base; the
    extended type is supplied by the consumer via `load_hooks(..., context_factory=...)`.
    """

    state_machine: StateMachine


HookContextT = TypeVar("HookContextT", bound=HookContext)


def build_context(machine: "StateMachine") -> HookContext:
    base = HookContext(state_machine=machine)
    factory = machine._context_factory
    return factory(base) if factory is not None else base
