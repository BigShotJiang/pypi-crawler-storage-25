"""Boot-time cross-checks between registered hooks and the target state machine.

Decorators capture registrations at import time without inspecting the target
machine. This module reads the populated registry and rejects hooks whose
target/signature/async-shape would otherwise break at first transition (or, for
async guards, silently corrupt every transition). Errors aggregate so consumers
see every offending handler in a single failure rather than one fix per reboot.
"""

from __future__ import annotations

import inspect
from typing import TYPE_CHECKING, List, Set

from state_machine.hooks.registry import HookRegistration, HookRegistry

if TYPE_CHECKING:
    from state_machine.core import StateMachine

_STATE_DECORATORS = frozenset(
    {
        "add_on_enter_state",
        "replace_on_enter_state",
        "add_on_exit_state",
        "replace_on_exit_state",
    }
)
_GUARD_DECORATORS = frozenset({"add_guard", "replace_guard"})
_BACKGROUND_TASK_DECORATOR = "register_background_task"

_SIGNATURE_PROBE = object()


class HookValidationError(RuntimeError):
    """Raised by `load_hooks()` when one or more registered handlers are invalid."""

    def __init__(self, errors: List[str]) -> None:
        self.errors = list(errors)
        joined = "\n  - ".join(self.errors)
        super().__init__(f"Hook validation failed:\n  - {joined}")


def validate_registry(machine: "StateMachine", registry: HookRegistry) -> None:
    """Run every boot-time check and raise `HookValidationError` listing all failures."""
    known_triggers: Set[str] = set(machine.events)
    errors: List[str] = []

    for registration in registry.all_registrations():
        _check_target_exists(registration, machine, known_triggers, errors)
        _check_async_shape(registration, errors)
        _check_signature_accepts_context(registration, errors)

    if errors:
        raise HookValidationError(errors)


def _check_target_exists(
    registration: HookRegistration,
    machine: "StateMachine",
    known_triggers: Set[str],
    errors: List[str],
) -> None:
    if registration.target is None:
        return
    if registration.decorator in _STATE_DECORATORS:
        # `machine.states` only contains top-level names; nested leaves like
        # 'parent_child' resolve via `get_state` (which the loader also uses)
        # but are absent from the dict. Defer to `get_state` so flat and
        # hierarchical machines validate identically.
        try:
            machine.get_state(registration.target)
        except (ValueError, KeyError, AttributeError):
            errors.append(
                f"{_identify(registration)}: unknown state {registration.target!r}; "
                f"known states: {sorted(_collect_state_names(machine))}"
            )
    elif registration.decorator in _GUARD_DECORATORS and registration.target not in known_triggers:
        errors.append(f"{_identify(registration)}: unknown trigger {registration.target!r}; " f"known triggers: {sorted(known_triggers)}")


def _collect_state_names(machine: "StateMachine") -> Set[str]:
    """Walk the state hierarchy and yield every reachable name, including nested
    leaves spelled with the machine's separator (e.g. 'parent_child').

    pytransitions' `NestedState` exposes children via `.states` (OrderedDict),
    not `.children` — the latter exists on different state subclasses in older
    transitions versions, so we probe both.
    """
    separator = getattr(machine, "separator", "_")
    names: Set[str] = set()

    def walk(state: object, prefix: str) -> None:
        name = getattr(state, "name", None)
        if name is None:
            return
        full_name = f"{prefix}{name}"
        names.add(full_name)
        nested_states = getattr(state, "states", None)
        if nested_states:
            for child in nested_states.values():
                walk(child, f"{full_name}{separator}")
            return
        for child in getattr(state, "children", []) or []:
            walk(child, f"{full_name}{separator}")

    for top_level in machine.states.values():
        walk(top_level, "")
    return names


def _check_async_shape(registration: HookRegistration, errors: List[str]) -> None:
    if registration.decorator in _GUARD_DECORATORS and registration.is_async:
        # pytransitions' Condition.check never awaits — an async guard returns a
        # coroutine object (truthy), comparison to target=True yields False, so
        # the transition is silently blocked and Python warns about the leaked
        # coroutine. Surface this at boot rather than as a quiet runtime failure.
        errors.append(f"{_identify(registration)}: handler must be sync; " f"@{registration.decorator} does not support async.")
    if registration.decorator == _BACKGROUND_TASK_DECORATOR and not registration.is_async:
        errors.append(
            f"{_identify(registration)}: handler must be a coroutine function; " f"@{_BACKGROUND_TASK_DECORATOR} requires `async def`."
        )


def _check_signature_accepts_context(registration: HookRegistration, errors: List[str]) -> None:
    try:
        signature = inspect.signature(registration.handler)
    except (TypeError, ValueError) as exc:
        errors.append(f"{_identify(registration)}: handler has no introspectable signature ({exc}).")
        return
    try:
        signature.bind(_SIGNATURE_PROBE)
    except TypeError as exc:
        errors.append(f"{_identify(registration)}: handler signature does not accept the hook context argument ({exc}).")


def _identify(registration: HookRegistration) -> str:
    target_segment = f" {registration.target!r}" if registration.target is not None else ""
    return f"{registration.module}.{registration.qualname} (@{registration.decorator}{target_segment})"
