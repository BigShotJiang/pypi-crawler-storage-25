from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

HookHandler = Callable[..., object]


class DuplicateHookError(Exception):
    """Raised when two handlers register for the same `HookTargetKey`."""


@dataclass(frozen=True)
class HookTargetKey:
    """
    Compound key identifying a unique `(decorator, target)` slot in the registry.

    Frozen so it can be used as a dict key. Spelled out as a dataclass instead of
    a bare `tuple[str, str]` so the contract is obvious at every type signature
    and call site — no need to remember "is the first string the decorator or
    the target?".
    """

    decorator: str
    target: str


@dataclass(frozen=True)
class HookRegistration:
    """One handler registration captured by a decorator at import time.

    `module` / `qualname` are captured from `fn.__module__` / `fn.__qualname__`
    so log lines and duplicate-error messages don't have to re-introspect the
    handler.
    """

    decorator: str
    target: Optional[str]
    handler: HookHandler
    is_async: bool
    module: str
    qualname: str


@dataclass
class HookRegistry:
    """
    In-memory registry of hook handlers populated by decorators at import time.

    Storage splits in two:

    - Target-keyed decorators (`replace_guard`, `add_guard`, `replace_on_enter_state`,
      `add_on_enter_state`, `replace_on_exit_state`, `add_on_exit_state`) accept at most
      one handler per `HookTargetKey(decorator, target)`. A second registration raises
      `DuplicateHookError`. `replace_X` and `add_X` for the same target coexist because
      the decorator name is part of the key.
    - Lifecycle decorators (`on_runtime_start`, `register_background_task`) allow
      multiple registrations, recorded in registration order.

    The registry only records. Validation (target existence, signature shape, async-guard
    rejection) lives in the boot-time loader.
    """

    _target_registrations: Dict[HookTargetKey, HookRegistration] = field(default_factory=dict)
    _runtime_start: List[HookRegistration] = field(default_factory=list)
    _background_tasks: List[HookRegistration] = field(default_factory=list)

    def add_target_hook(self, registration: HookRegistration) -> None:
        if registration.target is None:
            raise ValueError(f"Target hook '{registration.decorator}' requires a non-None target")
        key = HookTargetKey(decorator=registration.decorator, target=registration.target)
        existing = self._target_registrations.get(key)
        if existing is not None:
            raise DuplicateHookError(
                f"Duplicate hook registration: @{registration.decorator}({registration.target!r}) "
                f"already registered by {existing.module}.{existing.qualname}; "
                f"second registration came from {registration.module}.{registration.qualname}"
            )
        self._target_registrations[key] = registration

    def add_runtime_start(self, registration: HookRegistration) -> None:
        self._runtime_start.append(registration)

    def add_background_task(self, registration: HookRegistration) -> None:
        self._background_tasks.append(registration)

    def get_target_hook(self, decorator: str, target: str) -> Optional[HookRegistration]:
        return self._target_registrations.get(HookTargetKey(decorator=decorator, target=target))

    @property
    def target_hooks(self) -> Dict[HookTargetKey, HookRegistration]:
        return dict(self._target_registrations)

    @property
    def runtime_start_handlers(self) -> Tuple[HookRegistration, ...]:
        return tuple(self._runtime_start)

    @property
    def background_tasks(self) -> Tuple[HookRegistration, ...]:
        return tuple(self._background_tasks)

    def all_registrations(self) -> Tuple[HookRegistration, ...]:
        return (
            *self._target_registrations.values(),
            *self._runtime_start,
            *self._background_tasks,
        )

    def clear(self) -> None:
        self._target_registrations.clear()
        self._runtime_start.clear()
        self._background_tasks.clear()


_REGISTRY = HookRegistry()


def get_registry() -> HookRegistry:
    """Module-level singleton accessed by decorators and the boot-time loader."""
    return _REGISTRY
