"""
Hook loader: import the consumer's `handlers/` package so decorators
self-register into `HookRegistry`, then wire the registrations into
pytransitions' guard and state-callback machinery.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
import sys
from collections.abc import Coroutine, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Dict, List, Optional, cast

from transitions.core import Condition, EventData

from state_machine.hooks.context import HookContext, HookContextT, build_context
from state_machine.hooks.registry import HookRegistration, HookTargetKey, get_registry
from state_machine.hooks.validation import validate_registry

if TYPE_CHECKING:
    from state_machine.core import StateMachine

logger = logging.getLogger(__name__)

HANDLERS_PACKAGE_NAME = "handlers"

STATE_ENTER_ADD = "add_on_enter_state"
STATE_ENTER_REPLACE = "replace_on_enter_state"
STATE_EXIT_ADD = "add_on_exit_state"
STATE_EXIT_REPLACE = "replace_on_exit_state"
GUARD_ADD = "add_guard"
GUARD_REPLACE = "replace_guard"

# pytransitions invokes state callbacks with an `EventData` (or `None`, from
# the internal `_run_enter_callbacks` helper) and ignores the return value.
# Conditions get the same input but must return `bool`.
StateCallback = Callable[[Optional[EventData]], object]
GuardCondition = Callable[[Optional[EventData]], bool]


def load_hooks_into(
    machine: "StateMachine",
    hooks_directory: Path,
    *,
    context_factory: Optional[Callable[[HookContext], HookContextT]] = None,
) -> None:
    """See `StateMachine.load_hooks`."""
    if machine._hooks_loaded:
        # One-shot per machine; a second call would double every wired callback.
        raise RuntimeError(
            "load_hooks() has already been called on this state machine. "
            "It is one-shot per machine; create a fresh instance to load a different hooks directory."
        )
    machine._hooks_loaded = True

    if not hooks_directory.is_dir():
        logger.info("Hooks directory %s does not exist; no hooks loaded.", hooks_directory)
        return

    machine._context_factory = context_factory

    _import_handler_modules(hooks_directory)

    registry = get_registry()
    if not registry.all_registrations():
        logger.info(
            "No hooks registered after importing handlers/ from %s; the package may be empty or its modules use no hook decorators.",
            hooks_directory,
        )
        return

    validate_registry(machine, registry)

    target_hooks = registry.target_hooks
    _wire_state_callbacks(machine, target_hooks, hook_type="enter")
    _wire_state_callbacks(machine, target_hooks, hook_type="exit")
    _wire_guards(machine, target_hooks)

    machine._runtime_start_handlers = list(registry.runtime_start_handlers)
    machine._background_task_handlers = list(registry.background_tasks)
    for registration in machine._runtime_start_handlers:
        _log_registration(registration)
    for registration in machine._background_task_handlers:
        _log_registration(registration)


@contextmanager
def _on_sys_path(directory: str) -> Iterator[None]:
    """Insert `directory` at the front of `sys.path` for the duration of the
    block. Removes it on exit only if we added it, so we don't trample a
    caller who already had it on the path."""
    already_present = directory in sys.path
    if not already_present:
        sys.path.insert(0, directory)
    try:
        yield
    finally:
        if not already_present and directory in sys.path:
            sys.path.remove(directory)


def _import_handler_modules(hooks_directory: Path) -> None:
    """Import every submodule of the `handlers` package so decorators
    self-register. `sys.path` is only mutated for the duration of the
    import burst, not permanently."""
    with _on_sys_path(str(hooks_directory)):
        handlers_pkg = importlib.import_module(HANDLERS_PACKAGE_NAME)
        for module_info in pkgutil.iter_modules(handlers_pkg.__path__, prefix=f"{HANDLERS_PACKAGE_NAME}."):
            importlib.import_module(module_info.name)


def _wire_state_callbacks(
    machine: "StateMachine",
    target_hooks: Dict[HookTargetKey, HookRegistration],
    *,
    hook_type: str,
) -> None:
    """Wire add_/replace_on_<hook_type>_state hooks into each affected state's callback list."""
    add_decorator = STATE_ENTER_ADD if hook_type == "enter" else STATE_EXIT_ADD
    replace_decorator = STATE_ENTER_REPLACE if hook_type == "enter" else STATE_EXIT_REPLACE

    by_state: Dict[str, Dict[str, HookRegistration]] = {}
    for key, registration in target_hooks.items():
        if key.decorator not in (add_decorator, replace_decorator):
            continue
        by_state.setdefault(key.target, {})[key.decorator] = registration

    for state_name, hooks_for_state in by_state.items():
        state_obj = machine.get_state(state_name)
        # `state.on_enter` / `state.on_exit` are the lists; `state.enter` /
        # `state.exit` are the bound methods that invoke them.
        callback_list: List[StateCallback] = getattr(state_obj, f"on_{hook_type}")

        # Replace removes only callbacks installed by @on_enter_state /
        # @on_exit_state decorators. Auto-discovered `on_enter_<state>` methods
        # and externally added callbacks stay — replace composes with the
        # decorator surface, not with arbitrary pytransitions internals.
        if replace_decorator in hooks_for_state:
            for installed_state, installed_type, installed_callable in machine._decorator_manager.installed_state_callbacks:
                if installed_state == state_name and installed_type == hook_type and installed_callable in callback_list:
                    callback_list.remove(installed_callable)

        prepend: List[StateCallback] = []
        if add_decorator in hooks_for_state:
            registration = hooks_for_state[add_decorator]
            prepend.append(_build_state_callback(machine, registration))
            _log_registration(registration)
        if replace_decorator in hooks_for_state:
            registration = hooks_for_state[replace_decorator]
            prepend.append(_build_state_callback(machine, registration))
            _log_registration(registration)

        for insertion_index, callback in enumerate(prepend):
            callback_list.insert(insertion_index, callback)


def _wire_guards(
    machine: "StateMachine",
    target_hooks: Dict[HookTargetKey, HookRegistration],
) -> None:
    by_trigger: Dict[str, Dict[str, HookRegistration]] = {}
    for key, registration in target_hooks.items():
        if key.decorator not in (GUARD_ADD, GUARD_REPLACE):
            continue
        by_trigger.setdefault(key.target, {})[key.decorator] = registration

    for trigger_name, hooks_for_trigger in by_trigger.items():
        event = machine.events[trigger_name]

        # Replace removes the class-level composite condition so the hook is
        # the only pre-transition gate; class-level @guards are skipped.
        if GUARD_REPLACE in hooks_for_trigger:
            existing = machine._installed_guard_conditions.pop(trigger_name, None)
            if existing is not None:
                for transitions_for_source in event.transitions.values():
                    for transition in transitions_for_source:
                        if existing in transition.conditions:
                            transition.conditions.remove(existing)

        new_conditions: List[Condition] = []
        if GUARD_ADD in hooks_for_trigger:
            registration = hooks_for_trigger[GUARD_ADD]
            new_conditions.append(Condition(_build_guard_condition(machine, registration)))
            _log_registration(registration)
        if GUARD_REPLACE in hooks_for_trigger:
            registration = hooks_for_trigger[GUARD_REPLACE]
            new_conditions.append(Condition(_build_guard_condition(machine, registration)))
            _log_registration(registration)

        for transitions_for_source in event.transitions.values():
            for transition in transitions_for_source:
                transition.conditions.extend(new_conditions)


def _build_state_callback(
    machine: "StateMachine",
    registration: HookRegistration,
) -> StateCallback:
    """Async hooks are scheduled via `machine.spawn(...)` rather than awaited;
    the transition does not block on completion."""
    handler = registration.handler
    is_async = registration.is_async

    def callback(_event: Optional[EventData]) -> None:
        context = build_context(machine)
        result = handler(context)
        if is_async:
            coro = cast(Coroutine[Any, Any, Any], result)
            try:
                machine.spawn(coro)
            except RuntimeError:
                # No running event loop. Close the coroutine to suppress the
                # "coroutine was never awaited" RuntimeWarning, then warn.
                coro.close()
                logger.warning(
                    "Async state hook %s.%s could not be scheduled: no running event loop.",
                    registration.module,
                    registration.qualname,
                )

    return callback


def _build_guard_condition(
    machine: "StateMachine",
    registration: HookRegistration,
) -> GuardCondition:
    handler = registration.handler

    def condition(_event: Optional[EventData]) -> bool:
        context = build_context(machine)
        return bool(handler(context))

    return condition


def _log_registration(registration: HookRegistration) -> None:
    replace_flag = "[REPLACE] " if registration.decorator.startswith("replace_") else ""
    target = registration.target if registration.target is not None else "<lifecycle>"
    logger.info(
        "%sRegistered hook @%s on %s from %s.%s",
        replace_flag,
        registration.decorator,
        target,
        registration.module,
        registration.qualname,
    )
