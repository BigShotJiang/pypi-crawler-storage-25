"""Runtime dispatch for `@on_runtime_start` and `@register_background_task`.

Background tasks are tracked in `machine._lifecycle_background_tasks`, not
`machine._tasks`. `to_fault` cancels only `_tasks`, so bg tasks survive faults
— matches the palletizer convention (MQTT, telemetry, tower-light must keep
running so the fault state itself can be observed and reported). Only `stop()`
cancels them. Exceptions inside bg tasks are logged, never propagated.
"""

from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Awaitable, List, cast

from state_machine.hooks.context import build_context
from state_machine.hooks.registry import HookRegistration

if TYPE_CHECKING:
    from state_machine.core import StateMachine

logger = logging.getLogger(__name__)


async def run_runtime_start_handlers(machine: "StateMachine") -> None:
    for registration in machine._runtime_start_handlers:
        result = registration.handler(build_context(machine))
        if registration.is_async:
            await cast(Awaitable[object], result)


def schedule_background_tasks(machine: "StateMachine") -> List[asyncio.Task[None]]:
    scheduled: List[asyncio.Task[None]] = []
    for registration in machine._background_task_handlers:
        task = asyncio.create_task(_wrap_background_task(registration, machine))
        machine._lifecycle_background_tasks.add(task)
        task.add_done_callback(machine._lifecycle_background_tasks.discard)
        scheduled.append(task)
    return scheduled


async def _wrap_background_task(registration: HookRegistration, machine: "StateMachine") -> None:
    try:
        await cast(Awaitable[object], registration.handler(build_context(machine)))
    except asyncio.CancelledError:
        raise  # let stop()'s await observe the cancel
    except Exception:
        logger.exception(
            "Background task %s.%s raised; the state machine continues.",
            registration.module,
            registration.qualname,
        )
