"""
Hook-authoring decorators.

The eight decorators exposed here record into the module-level `HookRegistry`
at import time and do not validate the handler's shape, async-ness, or target
existence. All loud failures (async guards, sync background tasks, unknown
states/triggers, duplicate handler module imports across hook directories) are
surfaced once, by the boot-time loader, so consumers read every error from one
place. See `state_machine.hooks.registry.HookRegistry`.
"""

from __future__ import annotations

import inspect
from typing import Callable, TypeVar, Union

from state_machine.hooks.registry import HookRegistration, get_registry
from state_machine.utils import resolve_state_name, resolve_trigger_name

HookFunction = TypeVar("HookFunction", bound=Callable[..., object])
TargetNode = TypeVar("TargetNode")


def _build_registration(
    decorator_name: str,
    target: Union[str, None],
    hook_function: Callable[..., object],
) -> HookRegistration:
    return HookRegistration(
        decorator=decorator_name,
        target=target,
        handler=hook_function,
        is_async=inspect.iscoroutinefunction(hook_function),
        module=getattr(hook_function, "__module__", "<unknown>"),
        qualname=getattr(hook_function, "__qualname__", getattr(hook_function, "__name__", "<unknown>")),
    )


def _make_target_decorator(
    decorator_name: str,
    resolve_target: Callable[[TargetNode], str],
) -> Callable[[TargetNode], Callable[[HookFunction], HookFunction]]:
    def factory(target_node: TargetNode) -> Callable[[HookFunction], HookFunction]:
        target_name = resolve_target(target_node)

        def decorator(hook_function: HookFunction) -> HookFunction:
            registration = _build_registration(decorator_name, target_name, hook_function)
            get_registry().add_target_hook(registration)
            return hook_function

        return decorator

    return factory


replace_guard = _make_target_decorator("replace_guard", resolve_trigger_name)
add_guard = _make_target_decorator("add_guard", resolve_trigger_name)
replace_on_enter_state = _make_target_decorator("replace_on_enter_state", resolve_state_name)
add_on_enter_state = _make_target_decorator("add_on_enter_state", resolve_state_name)
replace_on_exit_state = _make_target_decorator("replace_on_exit_state", resolve_state_name)
add_on_exit_state = _make_target_decorator("add_on_exit_state", resolve_state_name)


def on_runtime_start(hook_function: HookFunction) -> HookFunction:
    """
    Mark `hook_function` to run once when `state_machine.start()` is called, in registration order.
    Sync or async. Multiple handlers may register; each runs in turn and failures abort startup.
    """
    registration = _build_registration("on_runtime_start", None, hook_function)
    get_registry().add_runtime_start(registration)
    return hook_function


def register_background_task(hook_function: HookFunction) -> HookFunction:
    """
    Mark `hook_function` for scheduling on the runtime loop as a background task
    after `@on_runtime_start` handlers complete. Cancelled on stop. Multiple
    handlers may register.

    Must be a coroutine function at runtime — the registration surface accepts
    any callable and records `is_async` accordingly; the boot-time loader
    rejects sync handlers registered through this decorator.
    """
    registration = _build_registration("register_background_task", None, hook_function)
    get_registry().add_background_task(registration)
    return hook_function
