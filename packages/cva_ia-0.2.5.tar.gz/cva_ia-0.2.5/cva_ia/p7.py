import textwrap
def display_code():
    code = """
import pandas as pd
from sklearn.preprocessing import MinMaxScaler 
from sklearn.model_selection import train_test_split 
from tensorflow import keras
from tensorflow.keras.layers import SimpleRNN, Dense

url = "https://raw.githubusercontent.com/selva86/datasets/master/BostonHousing.csv"
data = pd.read_csv(url)

X = data.drop('medv', axis=1) 
y = data['medv']

scaler = MinMaxScaler() 
X = scaler.fit_transform(X)

X = X.reshape(X.shape[0], 1, X.shape[1])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = keras.Sequential()
model.add(SimpleRNN(128, activation='relu', input_shape=(X_train.shape[1], X_train.shape[2])))
model.add(Dense(1))

model.compile(optimizer='adam', loss='mse', metrics=['mae']) 

model.fit(X_train, y_train, epochs=50, batch_size=32)

loss, mae = model.evaluate(X_test, y_test)
print(f"Mean Absolute Error: {mae}")
    """

    return code