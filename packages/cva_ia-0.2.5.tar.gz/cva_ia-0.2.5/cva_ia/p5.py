import textwrap
def display_code():
    code = """
import numpy as np
from tensorflow import keras
from tensorflow.keras import layers
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.datasets import imdb
from tensorflow.keras.models import Sequential
from tensorflow.keras.optimizers import Adam

max_words = 10000 

(x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=max_words)

max_len = 500 
x_train = pad_sequences(x_train, maxlen=max_len)
x_test = pad_sequences(x_test, maxlen=max_len)

model = Sequential()
model.add(layers.Embedding(input_dim=max_words, output_dim=128, input_length=max_len))
model.add(layers.LSTM(128))
model.add(layers.Dense(1, activation='sigmoid'))

model.compile(loss='binary_crossentropy', optimizer=Adam(), metrics=['accuracy'])

model.fit(x_train, y_train, epochs=5, batch_size=64, validation_data=(x_test, y_test))

test_loss, test_acc = model.evaluate(x_test, y_test)
print(f"Test Accuracy: {test_acc:.4f}")

predictions = model.predict(x_test[:5])
print("Predictions:", predictions)

print("\nEnter a review using word indices separated by space")
user_input = input("Enter review: ")

user_review = [int(i) for i in user_input.split()]
user_review = pad_sequences([user_review], maxlen=max_len)

prediction = model.predict(user_review)[0][0]

if prediction >= 0.5:
    print("\nPredicted Sentiment: POSITIVE ")
else:
    print("\nPredicted Sentiment: NEGATIVE ")
    """

    return code