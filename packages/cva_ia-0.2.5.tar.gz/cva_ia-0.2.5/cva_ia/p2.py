def display_code():
    code = """
import numpy as np 

def sigmoid(x):
    return 1 / (1 + np.exp(-x)) 

def sigmoid_derivative(x):
    return x * (1 - x) 


class NeuralNetwork:
    def __init__(self, input_size, hidden_size, output_size, learning_rate=0.5): 
        self.input_size = input_size
        self.hidden_size = hidden_size 
        self.output_size = output_size 
        self.learning_rate = learning_rate

        self.weights_input_hidden = np.random.uniform(-1, 1, (self.input_size, self.hidden_size)) 
        self.weights_hidden_output = np.random.uniform(-1, 1, (self.hidden_size, self.output_size)) 
        self.bias_hidden = np.random.uniform(-1, 1, (1, self.hidden_size))
        self.bias_output = np.random.uniform(-1, 1, (1, self.output_size)) 

    def forward(self, inputs):
        self.hidden_input = np.dot(inputs, self.weights_input_hidden) + self.bias_hidden
        self.hidden_output = sigmoid(self.hidden_input)
        self.final_input = np.dot(self.hidden_output, self.weights_hidden_output) + self.bias_output
        self.final_output = sigmoid(self.final_input)
        return self.final_output

    def backward(self, inputs, expected_output, actual_output): 
        output_error = expected_output - actual_output
        d_output = output_error * sigmoid_derivative(actual_output) 
        hidden_error = d_output.dot(self.weights_hidden_output.T)

        d_hidden = hidden_error * sigmoid_derivative(self.hidden_output) 

        self.weights_hidden_output += self.hidden_output.T.dot(d_output) * self.learning_rate
        self.bias_output += np.sum(d_output, axis=0, keepdims=True) * self.learning_rate 
        self.weights_input_hidden += inputs.T.dot(d_hidden) * self.learning_rate 
        self.bias_hidden += np.sum(d_hidden, axis=0, keepdims=True) * self.learning_rate

    def train(self, inputs, outputs, epochs=10000): 
        for epoch in range(epochs):
            output = self.forward(inputs) 
            self.backward(inputs, outputs, output) 

            if epoch % 1000 == 0:
                loss = np.mean((outputs - output) ** 2) 
                print(f"Epoch {epoch} Loss: {loss:.4f}")

    def predict(self, inputs):
        return np.round(self.forward(inputs)) 


X = np.array([[0, 0],
              [0, 1],
              [1, 0],
              [1, 1]])

y = np.array([[0],
              [1],
              [1],
              [0]])

nn = NeuralNetwork(input_size=2, hidden_size=2, output_size=1) 
nn.train(X, y)

print("\nXOR Predictions:") 
for x in X:
    output = nn.predict(np.array([x]))
    print(f"Input: {x} → Predicted: {int(output[0][0])}")
    """

    return code