def display_code():
    code = """import tensorflow as tf 
from tensorflow.keras.datasets import cifar10 
from tensorflow.keras.preprocessing.image import ImageDataGenerator 
from tensorflow.keras.models import Sequential 
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout 
from tensorflow.keras.utils import to_categorical 

(x_train, y_train), (x_test, y_test) = cifar10.load_data() 

x_train, x_test = x_train / 255.0, x_test / 255.0 

y_train = to_categorical(y_train, num_classes=10) 
y_test = to_categorical(y_test, num_classes=10) 

datagen = ImageDataGenerator(
    horizontal_flip=True,
) 

datagen.fit(x_train) 

model = Sequential([
    Conv2D(32, (3, 3), activation='relu', padding='same', input_shape=x_train.shape[1:]), 
    MaxPooling2D((2, 2)), 
    Dropout(0.25), 

    Conv2D(64, (3, 3), activation='relu', padding='same'), 
    MaxPooling2D((2, 2)), 
    Dropout(0.25), 

    Flatten(), 
    Dense(512, activation='relu'), 
    Dropout(0.5), 
    Dense(10, activation='softmax') 
]) 

model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy']) 

model.fit(datagen.flow(x_train, y_train, batch_size=64),
          epochs=5,
          validation_data=(x_test, y_test)) 

_, accuracy = model.evaluate(x_test, y_test, verbose=0) 
print(f"Test Accuracy: {accuracy * 100:.2f}%")
    """
    return code