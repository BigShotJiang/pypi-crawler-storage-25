import textwrap
def display_code():
    code = """
import tensorflow
from tensorflow import keras
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense
from tensorflow.keras.models import Sequential
from tensorflow.keras.datasets import mnist 

(x_train, y_train), (x_test, y_test) = mnist.load_data() 

x_train = x_train.reshape(-1, 28, 28, 1) / 255.0 
x_test = x_test.reshape(-1, 28, 28, 1) / 255.0 

y_train_eo = (y_train % 2).astype("int32") 
y_test_eo = (y_test % 2).astype("int32")

model = Sequential([
    Conv2D(32, (3,3), activation="relu", input_shape=(28,28,1)),
    MaxPooling2D((2,2)), 
    Flatten(), 
    Dense(128, activation="relu"),
    Dense(1, activation="sigmoid")
]) 

model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

model.fit(x_train, y_train_eo, epochs=5, validation_data=(x_test, y_test_eo)) 

loss, accuracy = model.evaluate(x_test, y_test_eo, verbose=0)

print(f"Test loss:{loss:.4f}") 
print(f"accuracy:{accuracy:.4f}")
    """

    return code