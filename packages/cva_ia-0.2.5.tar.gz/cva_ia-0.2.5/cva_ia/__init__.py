# def display_code(choice):
#     try:
#         module = __import__(f"cva_ia.p{choice}", fromlist=["display_code"])
#         return module.display_code()   # ✅ RETURN
#     except Exception:
#         return "Invalid choice. Use 1 to 10."

import pyperclip

def display_code(choice):
    try:
        module = __import__(f"cva_ia.p{choice}", fromlist=["display_code"])

        code = module.display_code()

        pyperclip.copy(code)   # copy output to clipboard

    except Exception:
        print("Invalid choice. Use 1 to 10.")