
def display_code():
    code = """
import tensorflow as tf
from tensorflow.keras.models import Sequential 
from tensorflow.keras.layers import Dense, Flatten 
from tensorflow.keras.datasets import mnist 

(x_train, y_train), (x_test, y_test) = mnist.load_data() 

x_train, x_test = x_train / 255.0, x_test / 255.0 

y_train = (y_train % 2).astype("int32") 
y_test = (y_test % 2).astype("int32") 

model = Sequential([
    Flatten(input_shape=(28, 28)),
    Dense(64, activation="relu"), 
    Dense(32, activation="relu"), 
    Dense(1, activation="sigmoid")
])

model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

model.fit(x_train, y_train, epochs=10, validation_data=(x_test, y_test)) 

loss, accuracy = model.evaluate(x_test, y_test)

print(f"loss:{loss:.4f}") 
print(f"accuracy:{accuracy:.4f}")
    """

    return code