from setuptools import setup, find_packages

setup(
    name="cva-ia",
    version="0.2.5",
    packages=find_packages(),
)