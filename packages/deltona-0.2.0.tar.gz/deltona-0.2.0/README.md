# deltona

<!-- WISWA-GENERATED-README:START -->

[![Python versions](https://img.shields.io/pypi/pyversions/deltona.svg?color=blue&logo=python&logoColor=white)](https://www.python.org/)
[![PyPI - Version](https://img.shields.io/pypi/v/deltona)](https://pypi.org/project/deltona/)
[![GitHub tag (with filter)](https://img.shields.io/github/v/tag/Tatsh/deltona)](https://github.com/Tatsh/deltona/tags)
[![License](https://img.shields.io/github/license/Tatsh/deltona)](https://github.com/Tatsh/deltona/blob/master/LICENSE.txt)
[![GitHub commits since latest release (by SemVer including pre-releases)](https://img.shields.io/github/commits-since/Tatsh/deltona/v0.2.0/master)](https://github.com/Tatsh/deltona/compare/v0.2.0...master)
[![CodeQL](https://github.com/Tatsh/deltona/actions/workflows/codeql.yml/badge.svg)](https://github.com/Tatsh/deltona/actions/workflows/codeql.yml)
[![QA](https://github.com/Tatsh/deltona/actions/workflows/qa.yml/badge.svg)](https://github.com/Tatsh/deltona/actions/workflows/qa.yml)
[![Tests](https://github.com/Tatsh/deltona/actions/workflows/tests.yml/badge.svg)](https://github.com/Tatsh/deltona/actions/workflows/tests.yml)
[![Coverage Status](https://coveralls.io/repos/github/Tatsh/deltona/badge.svg?branch=master)](https://coveralls.io/github/Tatsh/deltona?branch=master)
[![Dependabot](https://img.shields.io/badge/Dependabot-enabled-blue?logo=dependabot)](https://github.com/dependabot)
[![Documentation Status](https://readthedocs.org/projects/deltona/badge/?version=latest)](https://deltona.readthedocs.org/?badge=latest)
[![mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)
[![uv](https://img.shields.io/badge/uv-261230?logo=astral)](https://docs.astral.sh/uv/)
[![pytest](https://img.shields.io/badge/pytest-zz?logo=Pytest&labelColor=black&color=black)](https://docs.pytest.org/en/stable/)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![Downloads](https://static.pepy.tech/badge/deltona/month)](https://pepy.tech/project/deltona)
[![Stargazers](https://img.shields.io/github/stars/Tatsh/deltona?logo=github&style=flat)](https://github.com/Tatsh/deltona/stargazers)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit)](https://github.com/pre-commit/pre-commit)
[![Prettier](https://img.shields.io/badge/Prettier-black?logo=prettier)](https://prettier.io/)

[![@Tatsh](https://img.shields.io/badge/dynamic/json?url=https%3A%2F%2Fpublic.api.bsky.app%2Fxrpc%2Fapp.bsky.actor.getProfile%2F%3Factor=did%3Aplc%3Auq42idtvuccnmtl57nsucz72&query=%24.followersCount&label=Follow+%40Tatsh&logo=bluesky&style=social)](https://bsky.app/profile/Tatsh.bsky.social)
[![Buy Me A Coffee](https://img.shields.io/badge/Buy%20Me%20a%20Coffee-Tatsh-black?logo=buymeacoffee)](https://buymeacoffee.com/Tatsh)
[![Libera.Chat](https://img.shields.io/badge/Libera.Chat-Tatsh-black?logo=liberadotchat)](irc://irc.libera.chat/Tatsh)
[![Mastodon Follow](https://img.shields.io/mastodon/follow/109370961877277568?domain=hostux.social&style=social)](https://hostux.social/@Tatsh)
[![Patreon](https://img.shields.io/badge/Patreon-Tatsh2-F96854?logo=patreon)](https://www.patreon.com/Tatsh2)

<!-- WISWA-GENERATED-README:STOP -->

A lot of uncategorised utilities.

This project will eventually be split into different projects by category.

## Installation

```shell
pip install deltona
```

## Usage

See [the documentation](https://deltona.readthedocs.org/?badge=latest) for commands and the library.
