"""
Core modules for SentinelCI
"""
