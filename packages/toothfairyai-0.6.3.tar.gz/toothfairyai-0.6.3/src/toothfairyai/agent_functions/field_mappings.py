"""Field mappings for AgentFunction type.

Maps SDK snake_case → GraphQL/API camelCase with exceptions.
Only exception cases are listed here - standard conversions use to_camel_case().

Derived from: /app/app/amplify/backend/api/toothfairyai/schema.graphql
"""

AGENT_FUNCTION_FIELD_MAPPINGS = {
    "workspace_id": "workspaceid",
    
    "authorisation_id": "authorisationID",
    "code_execution_environment_id": "codeExecutionEnvironmentID",
    "db_connection_id": "dbConnectionID",
    "pre_execution_fn_id": "preExecutionFnID",
    
    "oauth_connection_id": "OAuthConnectionID",
    
    "is_mcp_server": "isMCPServer",
}

AGENT_FUNCTION_EXPLICIT_PARAMS = set()