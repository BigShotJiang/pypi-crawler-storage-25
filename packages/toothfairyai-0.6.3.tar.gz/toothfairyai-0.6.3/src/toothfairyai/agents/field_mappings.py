"""Field mappings for Agent type.

Maps SDK snake_case → GraphQL/API camelCase with exceptions.
Only exception cases are listed here - standard conversions use to_camel_case().

Derived from: /app/app/amplify/backend/api/toothfairyai/schema.graphql
"""

AGENT_FIELD_MAPPINGS = {
    "workspace_id": "workspaceid",
    
    "parent_agent_id": "parentAgentID",
    "parent_chat_id": "parentChatID",
    "cloned_agent_id": "clonedAgentID",
    
    "sip_dispatch_rule_id": "sipDispatchRuleId",
    
    "has_ner": "hasNER",
    "agentic_rag": "agenticRAG",
    "allow_external_api": "allowExternalAPI",
    "is_mfa_enabled": "isMFAEnabled",
}

AGENT_EXPLICIT_PARAMS = {
    "label",
    "description",
    "temperature",
    "max_tokens",
    "max_history",
    "top_k",
    "doc_top_k",
    "charting",
}