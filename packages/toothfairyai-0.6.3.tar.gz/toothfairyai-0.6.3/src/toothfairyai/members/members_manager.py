"""Member manager for handling members operations."""

from typing import TYPE_CHECKING, Any, Dict, List, Optional

from ..types import ListResponse, Member

if TYPE_CHECKING:
    from ..client import ToothFairyClient


class MemberManager:
    """Manager for members operations.

    This manager provides methods to create, update, and manage workspace members.
    Note: Members map to UserWorkspaceType in GraphQL.

    Example:
        >>> client = ToothFairyClient(api_key="...", workspace_id="...")
        >>> member = client.members.create(user_id="user-123", user_type="human")
    """

    def __init__(self, client: "ToothFairyClient"):
        """Initialize the MemberManager.

        Args:
            client: The ToothFairyClient instance.
        """
        self._client = client

    def create(
        self,
        user_id: str,
        user_type: Optional[str] = None,
        policy_id: Optional[str] = None,
        favorite_agents: Optional[List[str]] = None,
        recent_local_folders: Optional[List[str]] = None,
        recent_files: Optional[List[str]] = None,
    ) -> Member:
        """Create a new member.

        Args:
            user_id: ID of the user to add as a member (required, maps to userID).
            user_type: Type of user (e.g., 'human', 'bot', maps to userType).
            policy_id: ID of the policy to assign (maps to policyID).
            favorite_agents: List of favorite agent IDs (maps to favoriteAgents).
            recent_local_folders: List of recent local folder IDs.
            recent_files: List of recent file IDs.

        Returns:
            The created Member object.
        """
        data: Dict[str, Any] = {
            "userID": user_id,
        }

        if user_type is not None:
            data["userType"] = user_type
        if policy_id is not None:
            data["policyID"] = policy_id
        if favorite_agents is not None:
            data["favoriteAgents"] = favorite_agents
        if recent_local_folders is not None:
            data["recentLocalFolders"] = recent_local_folders
        if recent_files is not None:
            data["recentFiles"] = recent_files

        response = self._client.request("POST", "/member/create", data=data)
        return Member.from_dict(response)

    def update(
        self,
        member_id: str,
        user_type: Optional[str] = None,
        policy_id: Optional[str] = None,
        favorite_agents: Optional[List[str]] = None,
        recent_local_folders: Optional[List[str]] = None,
        recent_files: Optional[List[str]] = None,
    ) -> Member:
        """Update a member.

        Args:
            member_id: ID of the member to update.
            user_type: Type of user (maps to userType).
            policy_id: ID of the policy (maps to policyID).
            favorite_agents: List of favorite agent IDs (maps to favoriteAgents).
            recent_local_folders: List of recent local folder IDs.
            recent_files: List of recent file IDs.

        Returns:
            The updated Member object.
        """
        data: Dict[str, Any] = {"id": member_id}

        if user_type is not None:
            data["userType"] = user_type
        if policy_id is not None:
            data["policyID"] = policy_id
        if favorite_agents is not None:
            data["favoriteAgents"] = favorite_agents
        if recent_local_folders is not None:
            data["recentLocalFolders"] = recent_local_folders
        if recent_files is not None:
            data["recentFiles"] = recent_files

        response = self._client.request("POST", "/member/update", data=data)
        return Member.from_dict(response)

    def delete(self, member_id: str) -> Dict[str, bool]:
        """Delete a member.

        Args:
            member_id: ID of the member to delete.

        Returns:
            A dictionary with success status.
        """
        self._client.request("DELETE", f"/member/delete/{member_id}")
        return {"success": True}

    def get(self, member_id: str) -> Member:
        """Get a member by ID.

        Args:
            member_id: ID of the member to retrieve.

        Returns:
            The Member object.
        """
        response = self._client.request("GET", f"/member/get/{member_id}")
        return Member.from_dict(response)

    def list(
        self,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> ListResponse:
        """List all members.

        Args:
            limit: Maximum number of members to return.
            offset: Number of members to skip.

        Returns:
            A ListResponse containing the members.
        """
        params: Dict[str, Any] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        response = self._client.request("GET", "/member/list", params=params)

        items = []
        if isinstance(response, list):
            items = [Member.from_dict(item) for item in response]
        elif isinstance(response, dict):
            items = [Member.from_dict(item) for item in response.get("items", [])]

        return ListResponse(items=items)

    def get_by_user_type(self, user_type: str) -> List[Member]:
        """Get members by user type.

        Args:
            user_type: User type to filter by (e.g., 'human', 'bot').

        Returns:
            A list of Member objects with the specified user type.
        """
        result = self.list()
        return [member for member in result.items if member.user_type == user_type]

    def search(self, search_term: str) -> List[Member]:
        """Search members by user ID.

        Args:
            search_term: Term to search for in user IDs.

        Returns:
            A list of matching Member objects.
        """
        all_members = self.list()
        search_lower = search_term.lower()
        return [member for member in all_members.items if search_lower in member.user_id.lower()]
