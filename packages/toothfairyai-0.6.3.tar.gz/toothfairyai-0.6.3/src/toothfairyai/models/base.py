"""Base Pydantic model with common configuration."""

from typing import Any, Dict, Optional
from pydantic import BaseModel, ConfigDict, field_validator


class ToothFairyModel(BaseModel):
    """Base model for all ToothFairy validation models.
    
    Provides:
    - Extra field validation (warn on unknown fields)
    - None exclusion for clean payloads
    - snake_case field names with camelCase serialization
    """
    
    model_config = ConfigDict(
        extra="forbid",
        validate_assignment=True,
        populate_by_name=True,
        str_strip_whitespace=True,
    )
    
    def to_api_payload(self, exclude_none: bool = True) -> Dict[str, Any]:
        """Convert to API-ready payload.
        
        Args:
            exclude_none: If True, exclude None values from output
            
        Returns:
            Dictionary suitable for API calls
        """
        return self.model_dump(
            exclude_none=exclude_none,
            exclude_unset=True,
            by_alias=True,
        )
    
    def to_sdk_kwargs(self) -> Dict[str, Any]:
        """Convert to SDK kwargs (snake_case keys).
        
        Returns:
            Dictionary with snake_case keys for passing to manager methods
        """
        return self.model_dump(exclude_none=True, exclude_unset=True)