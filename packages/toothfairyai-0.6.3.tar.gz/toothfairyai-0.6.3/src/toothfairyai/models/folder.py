"""Pydantic models for Folder validation."""

from typing import Optional
from pydantic import Field

from .base import ToothFairyModel


class FolderCreateModel(ToothFairyModel):
    """Validation model for creating a folder."""

    name: str = Field(..., min_length=1, max_length=255, description="Folder name")
    description: Optional[str] = Field(default=None, description="Folder description")
    emoji: Optional[str] = Field(default=None, max_length=10, description="Folder emoji")
    status: str = Field(default="active", description="Folder status")
    parent: Optional[str] = Field(default=None, description="Parent folder ID for subfolders")

    def to_api_payload(self) -> dict:
        payload = {
            "name": self.name,
            "status": self.status,
        }
        if self.description is not None:
            payload["description"] = self.description
        if self.emoji is not None:
            payload["emoji"] = self.emoji
        if self.parent is not None:
            payload["parent"] = self.parent
        return payload


class FolderUpdateModel(ToothFairyModel):
    """Validation model for updating a folder."""

    folder_id: str = Field(..., min_length=1, description="Folder ID to update")
    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    description: Optional[str] = Field(default=None)
    emoji: Optional[str] = Field(default=None, max_length=10)
    status: Optional[str] = Field(default=None)
    parent: Optional[str] = Field(default=None)

    def to_api_payload(self) -> dict:
        payload = {"id": self.folder_id}
        if self.name is not None:
            payload["name"] = self.name
        if self.description is not None:
            payload["description"] = self.description
        if self.emoji is not None:
            payload["emoji"] = self.emoji
        if self.status is not None:
            payload["status"] = self.status
        if self.parent is not None:
            payload["parent"] = self.parent
        return payload