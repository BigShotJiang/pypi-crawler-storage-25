"""Pydantic models for Member validation."""

from typing import List, Optional
from pydantic import Field

from .base import ToothFairyModel


class MemberCreateModel(ToothFairyModel):
    """Validation model for creating a member."""

    user_id: str = Field(..., min_length=1, description="User ID to add as member")
    user_type: Optional[str] = Field(default=None, description="User type (e.g., 'human', 'bot')")
    policy_id: Optional[str] = Field(default=None, description="Policy ID to assign")
    favorite_agents: Optional[List[str]] = Field(default=None, description="List of favorite agent IDs")
    recent_local_folders: Optional[List[str]] = Field(default=None, description="List of recent local folder IDs")
    recent_files: Optional[List[str]] = Field(default=None, description="List of recent file IDs")

    def to_api_payload(self) -> dict:
        payload = {"userID": self.user_id}
        if self.user_type is not None:
            payload["userType"] = self.user_type
        if self.policy_id is not None:
            payload["policyID"] = self.policy_id
        if self.favorite_agents is not None:
            payload["favoriteAgents"] = self.favorite_agents
        if self.recent_local_folders is not None:
            payload["recentLocalFolders"] = self.recent_local_folders
        if self.recent_files is not None:
            payload["recentFiles"] = self.recent_files
        return payload


class MemberUpdateModel(ToothFairyModel):
    """Validation model for updating a member."""

    member_id: str = Field(..., min_length=1, description="Member ID to update")
    user_type: Optional[str] = Field(default=None, description="User type")
    policy_id: Optional[str] = Field(default=None, description="Policy ID")
    favorite_agents: Optional[List[str]] = Field(default=None, description="List of favorite agent IDs")
    recent_local_folders: Optional[List[str]] = Field(default=None, description="List of recent local folder IDs")
    recent_files: Optional[List[str]] = Field(default=None, description="List of recent file IDs")

    def to_api_payload(self) -> dict:
        payload = {"id": self.member_id}
        if self.user_type is not None:
            payload["userType"] = self.user_type
        if self.policy_id is not None:
            payload["policyID"] = self.policy_id
        if self.favorite_agents is not None:
            payload["favoriteAgents"] = self.favorite_agents
        if self.recent_local_folders is not None:
            payload["recentLocalFolders"] = self.recent_local_folders
        if self.recent_files is not None:
            payload["recentFiles"] = self.recent_files
        return payload