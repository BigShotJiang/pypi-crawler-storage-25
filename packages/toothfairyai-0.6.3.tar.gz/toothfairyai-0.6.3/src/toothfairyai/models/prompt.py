"""Pydantic models for Prompt validation."""

from typing import List, Optional
from pydantic import Field, field_validator

from .base import ToothFairyModel
from .validators import validate_interpolation_string


class PromptCreateModel(ToothFairyModel):
    """Validation model for creating a prompt."""

    label: str = Field(..., min_length=1, max_length=255, description="Prompt label")
    interpolation_string: str = Field(..., min_length=128, description="Prompt template string (minimum 128 characters)")
    prompt_type: str = Field(default="custom", description="Prompt type")
    scope: Optional[str] = Field(default=None, description="Prompt scope")
    style: Optional[str] = Field(default=None, description="Prompt style")
    domain: Optional[str] = Field(default=None, description="Prompt domain")
    prompt_placeholder: Optional[str] = Field(default=None, description="Placeholder text")
    available_to_agents: Optional[List[str]] = Field(default=None, description="List of agent IDs that can use this prompt")

    @field_validator("interpolation_string")
    @classmethod
    def validate_interpolation(cls, v: str) -> str:
        return validate_interpolation_string(v)

    def to_api_payload(self) -> dict:
        payload = {
            "label": self.label,
            "type": self.prompt_type,
            "interpolationString": self.interpolation_string,
            "promptLength": max(len(self.interpolation_string), 128),
        }
        if self.scope is not None:
            payload["scope"] = self.scope
        if self.style is not None:
            payload["style"] = self.style
        if self.domain is not None:
            payload["domain"] = self.domain
        if self.prompt_placeholder is not None:
            payload["promptPlaceholder"] = self.prompt_placeholder
        if self.available_to_agents is not None:
            payload["availableToAgents"] = self.available_to_agents
        return payload


class PromptUpdateModel(ToothFairyModel):
    """Validation model for updating a prompt."""

    prompt_id: str = Field(..., min_length=1, description="Prompt ID to update")
    label: Optional[str] = Field(default=None, min_length=1, max_length=255)
    interpolation_string: Optional[str] = Field(default=None, min_length=128)
    prompt_type: Optional[str] = Field(default=None)
    scope: Optional[str] = Field(default=None)
    style: Optional[str] = Field(default=None)
    domain: Optional[str] = Field(default=None)
    prompt_placeholder: Optional[str] = Field(default=None)
    available_to_agents: Optional[List[str]] = Field(default=None)

    @field_validator("interpolation_string")
    @classmethod
    def validate_interpolation(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            return validate_interpolation_string(v)
        return v

    def to_api_payload(self) -> dict:
        payload = {"id": self.prompt_id}
        if self.label is not None:
            payload["label"] = self.label
        if self.interpolation_string is not None:
            payload["interpolationString"] = self.interpolation_string
            payload["promptLength"] = max(len(self.interpolation_string), 128)
        if self.prompt_type is not None:
            payload["type"] = self.prompt_type
        if self.scope is not None:
            payload["scope"] = self.scope
        if self.style is not None:
            payload["style"] = self.style
        if self.domain is not None:
            payload["domain"] = self.domain
        if self.prompt_placeholder is not None:
            payload["promptPlaceholder"] = self.prompt_placeholder
        if self.available_to_agents is not None:
            payload["availableToAgents"] = self.available_to_agents
        return payload