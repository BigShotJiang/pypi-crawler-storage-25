"""Pydantic models for Channel validation."""

from typing import Optional
from pydantic import Field

from .base import ToothFairyModel
from .enums import ChannelType, ChannelProvider


class ChannelCreateModel(ToothFairyModel):
    """Validation model for creating a channel."""

    name: str = Field(..., min_length=1, max_length=255, description="Channel name")
    channel: ChannelType = Field(..., description="Communication channel type")
    provider: ChannelProvider = Field(..., description="Service provider")
    description: Optional[str] = Field(default=None, description="Channel description")
    senderid: Optional[str] = Field(default=None, description="Sender ID for SMS/WhatsApp")
    is_active: bool = Field(default=True, description="Whether the channel is active")

    def to_api_payload(self) -> dict:
        payload = {
            "name": self.name,
            "channel": self.channel.value,
            "provider": self.provider.value,
            "isActive": self.is_active,
        }
        if self.description is not None:
            payload["description"] = self.description
        if self.senderid is not None:
            payload["senderid"] = self.senderid
        return payload


class ChannelUpdateModel(ToothFairyModel):
    """Validation model for updating a channel."""

    channel_id: str = Field(..., min_length=1, description="Channel ID to update")
    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    channel: Optional[ChannelType] = Field(default=None)
    provider: Optional[ChannelProvider] = Field(default=None)
    description: Optional[str] = Field(default=None)
    senderid: Optional[str] = Field(default=None)
    is_active: Optional[bool] = Field(default=None)

    def to_api_payload(self) -> dict:
        payload = {"id": self.channel_id}
        if self.name is not None:
            payload["name"] = self.name
        if self.channel is not None:
            payload["channel"] = self.channel.value
        if self.provider is not None:
            payload["provider"] = self.provider.value
        if self.description is not None:
            payload["description"] = self.description
        if self.senderid is not None:
            payload["senderid"] = self.senderid
        if self.is_active is not None:
            payload["isActive"] = self.is_active
        return payload