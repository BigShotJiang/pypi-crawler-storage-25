"""Pydantic models for Chat and Message validation."""

from typing import Any, Dict, List, Optional
from pydantic import Field

from .base import ToothFairyModel
from .enums import MessageRole


class ChatCreateModel(ToothFairyModel):
    """Validation model for creating a chat."""

    name: str = Field(default="", max_length=255, description="Chat name")
    customer_id: str = Field(default="", description="Customer identifier")
    customer_info: Optional[Dict[str, Any]] = Field(default=None, description="Additional customer information")
    primary_role: str = Field(default="user", description="Primary role for the chat")
    external_participant_id: str = Field(default="", description="External participant identifier")
    channel_settings: Optional[Dict[str, str]] = Field(default=None, description="Channel configuration")

    def to_api_payload(self) -> dict:
        payload = {
            "name": self.name,
            "customerId": self.customer_id,
            "customerInfo": self.customer_info or {},
            "primaryRole": self.primary_role,
            "externalParticipantId": self.external_participant_id,
        }
        if self.channel_settings is not None:
            payload["channelSettings"] = self.channel_settings
        return payload


class ChatUpdateModel(ToothFairyModel):
    """Validation model for updating a chat."""

    chat_id: str = Field(..., min_length=1, description="Chat ID to update")
    name: Optional[str] = Field(default=None, max_length=255)
    customer_id: Optional[str] = Field(default=None)
    customer_info: Optional[Dict[str, Any]] = Field(default=None)
    primary_role: Optional[str] = Field(default=None)
    external_participant_id: Optional[str] = Field(default=None)
    channel_settings: Optional[Dict[str, str]] = Field(default=None)

    def to_api_payload(self) -> dict:
        payload = {"id": self.chat_id}
        if self.name is not None:
            payload["name"] = self.name
        if self.customer_id is not None:
            payload["customerId"] = self.customer_id
        if self.customer_info is not None:
            payload["customerInfo"] = self.customer_info
        if self.primary_role is not None:
            payload["primaryRole"] = self.primary_role
        if self.external_participant_id is not None:
            payload["externalParticipantId"] = self.external_participant_id
        if self.channel_settings is not None:
            payload["channelSettings"] = self.channel_settings
        return payload


class MessageCreateModel(ToothFairyModel):
    """Validation model for creating a message."""

    chat_id: str = Field(..., min_length=1, description="Chat ID")
    text: str = Field(..., min_length=1, description="Message text content")
    role: MessageRole = Field(default=MessageRole.USER, description="Message role")
    user_id: str = Field(default="", description="User identifier")
    images: Optional[List[str]] = Field(default=None, description="List of image URLs")
    audios: Optional[List[str]] = Field(default=None, description="List of audio URLs")
    videos: Optional[List[str]] = Field(default=None, description="List of video URLs")
    files: Optional[List[str]] = Field(default=None, description="List of file URLs")

    def to_api_payload(self) -> dict:
        payload = {
            "chatID": self.chat_id,
            "text": self.text,
            "role": self.role.value,
            "userID": self.user_id,
            "images": self.images or [],
            "audios": self.audios or [],
            "videos": self.videos or [],
            "files": self.files or [],
        }
        return payload


class MessageUpdateModel(ToothFairyModel):
    """Validation model for updating a message."""

    message_id: str = Field(..., min_length=1, description="Message ID to update")
    text: Optional[str] = Field(default=None, min_length=1)
    role: Optional[MessageRole] = Field(default=None)
    user_id: Optional[str] = Field(default=None)
    images: Optional[List[str]] = Field(default=None)
    audios: Optional[List[str]] = Field(default=None)
    videos: Optional[List[str]] = Field(default=None)
    files: Optional[List[str]] = Field(default=None)

    def to_api_payload(self) -> dict:
        payload = {"id": self.message_id}
        if self.text is not None:
            payload["text"] = self.text
        if self.role is not None:
            payload["role"] = self.role.value
        if self.user_id is not None:
            payload["userID"] = self.user_id
        if self.images is not None:
            payload["images"] = self.images
        if self.audios is not None:
            payload["audios"] = self.audios
        if self.videos is not None:
            payload["videos"] = self.videos
        if self.files is not None:
            payload["files"] = self.files
        return payload