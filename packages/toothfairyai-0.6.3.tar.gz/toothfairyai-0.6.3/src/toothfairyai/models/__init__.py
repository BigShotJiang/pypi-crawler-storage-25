"""Pydantic validation models for ToothFairyAI SDK.

These models provide pre-API-call validation with clear error messages,
reducing cryptic API errors and catching issues early.
"""

from .base import ToothFairyModel
from .validators import (
    validate_temperature,
    validate_max_tokens,
    validate_top_k,
    validate_json_schema,
    validate_cron_expression,
    validate_interpolation_string,
    validate_url,
    validate_hex_color,
)
from .enums import (
    AgentMode,
    AgentType,
    EntityType,
    AuthType,
    RequestType,
    ReasoningMode,
    ReasoningEffort,
    Department,
    PlanType,
    ChatMode,
    Visibility,
    CronJobFrequency,
    CronJobStatus,
    CommunicationChannel,
    CommunicationProvider,
    HostingType,
    OutputType,
    SearchStrategy,
    InternetSearchMode,
    MemberRole,
    ChannelType,
    ChannelProvider,
    DocType,
    PromptType,
)

from .agent import AgentCreateModel, AgentUpdateModel
from .agent_function import AgentFunctionCreateModel, AgentFunctionUpdateModel
from .scheduled_job import (
    ScheduledJobCreateModel,
    CronScheduleModel,
    ExecutionConfigModel,
    NotificationConfigModel,
    RetryConfigModel,
)
from .document import (
    DocumentCreateModel,
    DocumentUpdateModel,
    DocumentSearchModel,
    FileUploadModel,
    Base64UploadModel,
)
from .prompt import PromptCreateModel, PromptUpdateModel
from .authorisation import AuthorisationCreateModel, AuthorisationUpdateModel
from .hook import HookCreateModel, HookUpdateModel
from .benchmark import BenchmarkCreateModel, BenchmarkUpdateModel
from .connection import ConnectionCreateModel, ConnectionUpdateModel
from .chat import ChatCreateModel, ChatUpdateModel, MessageCreateModel, MessageUpdateModel
from .channel import ChannelCreateModel, ChannelUpdateModel
from .folder import FolderCreateModel, FolderUpdateModel
from .entity import EntityCreateModel, EntityUpdateModel
from .member import MemberCreateModel, MemberUpdateModel
from .secret import SecretCreateModel

__all__ = [
    "ToothFairyModel",
    "validate_temperature",
    "validate_max_tokens",
    "validate_top_k",
    "validate_json_schema",
    "validate_cron_expression",
    "validate_interpolation_string",
    "validate_url",
    "validate_hex_color",
    "AgentMode",
    "AgentType",
    "EntityType",
    "AuthType",
    "RequestType",
    "ReasoningMode",
    "ReasoningEffort",
    "Department",
    "PlanType",
    "ChatMode",
    "Visibility",
    "CronJobFrequency",
    "CronJobStatus",
    "CommunicationChannel",
    "CommunicationProvider",
    "HostingType",
    "OutputType",
    "SearchStrategy",
    "InternetSearchMode",
    "MemberRole",
    "ChannelType",
    "ChannelProvider",
    "DocType",
    "PromptType",
    "AgentCreateModel",
    "AgentUpdateModel",
    "AgentFunctionCreateModel",
    "AgentFunctionUpdateModel",
    "ScheduledJobCreateModel",
    "CronScheduleModel",
    "ExecutionConfigModel",
    "NotificationConfigModel",
    "RetryConfigModel",
    "DocumentCreateModel",
    "DocumentUpdateModel",
    "DocumentSearchModel",
    "FileUploadModel",
    "Base64UploadModel",
    "PromptCreateModel",
    "PromptUpdateModel",
    "AuthorisationCreateModel",
    "AuthorisationUpdateModel",
    "HookCreateModel",
    "HookUpdateModel",
    "BenchmarkCreateModel",
    "BenchmarkUpdateModel",
    "ConnectionCreateModel",
    "ConnectionUpdateModel",
    "ChatCreateModel",
    "ChatUpdateModel",
    "MessageCreateModel",
    "MessageUpdateModel",
    "ChannelCreateModel",
    "ChannelUpdateModel",
    "FolderCreateModel",
    "FolderUpdateModel",
    "EntityCreateModel",
    "EntityUpdateModel",
    "MemberCreateModel",
    "MemberUpdateModel",
    "SecretCreateModel",
]