"""Enum types extracted from types.py for Pydantic models.

These enums match the Literal types defined in types.py and are used
for Pydantic model validation.
"""

from enum import Enum
from typing import Literal


class AgentMode(str, Enum):
    """Agent operation mode."""
    RETRIEVER = "retriever"
    CODER = "coder"
    CHATTER = "chatter"
    PLANNER = "planner"
    COMPUTER = "computer"
    VOICE = "voice"
    ACCURACY = "accuracy"


class AgentType(str, Enum):
    """Agent type classification."""
    CHATBOT = "Chatbot"
    BUSINESS_ANALYST = "BusinessAnalyst"
    CONTENT_CREATOR = "ContentCreator"
    DEFAULT = "Default"


class EntityType(str, Enum):
    """Entity type for topics, intents, NER."""
    INTENT = "intent"
    NER = "ner"
    TOPIC = "topic"


class AuthType(str, Enum):
    """Authorisation type for functions."""
    BEARER = "bearer"
    APIKEY = "apikey"
    OAUTH = "oauth"
    PASSWORD = "password"
    ENV = "env"
    GENERIC = "generic"
    NONE = "none"
    USERNAME_AND_PASSWORD = "username_and_password"
    BASIC = "basic"


class RequestType(str, Enum):
    """HTTP request type for functions."""
    GET = "get"
    POST = "post"
    PUT = "put"
    DELETE = "delete"
    PATCH = "patch"
    CUSTOM = "custom"
    GRAPHQL_QUERY = "graphql_query"
    GRAPHQL_MUTATION = "graphql_mutation"


class ReasoningMode(str, Enum):
    """Reasoning mode for agents."""
    AUTO = "auto"
    DYNAMIC = "dynamic"
    ALWAYS = "always"
    NEVER = "never"


class ReasoningEffort(str, Enum):
    """Reasoning effort level."""
    NONE = "none"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class Department(str, Enum):
    """Department classification for agents."""
    HUMAN_RESOURCES = "HUMAN_RESOURCES"
    FINANCE_AND_ACCOUNTING = "FINANCE_AND_ACCOUNTING"
    SALES = "SALES"
    MARKETING = "MARKETING"
    OPERATIONS = "OPERATIONS"
    INFORMATION_TECHNOLOGY = "INFORMATION_TECHNOLOGY"
    CUSTOMER_SERVICE = "CUSTOMER_SERVICE"
    RESEARCH_AND_DEVELOPMENT = "RESEARCH_AND_DEVELOPMENT"
    LEGAL_AND_COMPLIANCE = "LEGAL_AND_COMPLIANCE"
    SUPPLY_CHAIN_MANAGEMENT = "SUPPLY_CHAIN_MANAGEMENT"
    PROJECT_MANAGEMENT = "PROJECT_MANAGEMENT"
    GENERAL_PURPOSE = "GENERAL_PURPOSE"


class PlanType(str, Enum):
    """Subscription plan type."""
    BASE = "base"
    PRO = "pro"
    BUSINESS = "business"
    ENTERPRISE = "enterprise"


class ChatMode(str, Enum):
    """Chat mode for agents."""
    SPEED = "speed"
    ACCURACY = "accuracy"
    CUSTOM = "custom"
    RETRIEVER = "retriever"
    CODER = "coder"
    MATHEMATICIAN = "mathematician"
    CHATTER = "chatter"
    PLANNER = "planner"
    COMPUTER = "computer"
    VOICE = "voice"


class Visibility(str, Enum):
    """Visibility setting."""
    PRIVATE = "private"
    PUBLIC = "public"
    SHARED = "shared"


class CronJobFrequency(str, Enum):
    """Scheduled job frequency."""
    MINUTES = "MINUTES"
    HOURLY = "HOURLY"
    DAILY = "DAILY"
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    YEARLY = "YEARLY"
    CUSTOM = "CUSTOM"


class CronJobStatus(str, Enum):
    """Scheduled job status."""
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    DISABLED = "DISABLED"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    PENDING = "PENDING"


class CommunicationChannel(str, Enum):
    """Communication channel type."""
    EMAIL = "email"
    SMS = "sms"
    WHATSAPP = "whatsapp"
    LINKEDIN = "linkedin"
    SIP = "sip"


class CommunicationProvider(str, Enum):
    """Communication provider."""
    SENDGRID = "sendgrid"
    SES = "ses"
    MAILGUN = "mailgun"
    POSTMARK = "postmark"
    MAILJET = "mailjet"
    TWILIO = "twilio"
    WHATSAPP = "whatsapp"
    SMS_MAGIC = "sms_magic"
    SMS_MAGIC_SF = "sms_magic_sf"
    LINKEDIN = "linkedin"


class HostingType(str, Enum):
    """LLM hosting type."""
    AZURE_OPENAI = "azure_openai"
    AWS = "aws"
    LOCAL = "local"
    GOOGLE = "google"
    ANTHROPIC = "anthropic"
    TOGETHER = "together"
    TF = "tf"
    REPLICATE = "replicate"
    AZURE = "azure"
    OPENAI = "openai"
    GROQ = "groq"
    OLLAMA = "ollama"


class OutputType(str, Enum):
    """Agent output type."""
    IMAGES = "images"
    VIDEOS = "videos"
    MODELLING = "modelling"
    TEXT = "text"
    CODE_INTERPRETER = "code_interpreter"
    CANVAS = "canvas"
    INTERNET_SEARCH = "internet_search"
    DEEP_THINKING = "deep_thinking"
    BROWSER = "browser"
    AUDIO = "audio"
    VOICE = "voice"
    RAG = "rag"


class SearchStrategy(str, Enum):
    """RAG search strategy."""
    PARALLEL = "parallel"
    TARGETED_FIRST = "targeted_first"
    VECTOR_FIRST = "vector_first"


class InternetSearchMode(str, Enum):
    """Internet search mode."""
    SEARCH = "search"
    NEWS = "news"
    IMAGES = "images"
    VIDEOS = "videos"
    MAPS = "maps"
    PLACES = "places"
    SHOPPING = "shopping"


class MemberRole(str, Enum):
    """Workspace member role."""
    ADMIN = "admin"
    MEMBER = "member"
    VIEWER = "viewer"


class ChannelType(str, Enum):
    """Communication channel type (for channels manager)."""
    SMS = "sms"
    WHATSAPP = "whatsapp"
    EMAIL = "email"
    LINKEDIN = "linkedin"
    SIP = "sip"


class ChannelProvider(str, Enum):
    """Channel provider (for channels manager)."""
    TWILIO = "twilio"
    SENDGRID = "sendgrid"
    SES = "ses"
    MAILGUN = "mailgun"
    POSTMARK = "postmark"
    MAILJET = "mailjet"
    WHATSAPP = "whatsapp"
    SMS_MAGIC = "sms_magic"
    SMS_MAGIC_SF = "sms_magic_sf"
    LINKEDIN = "linkedin"


class DocType(str, Enum):
    """Document type for file uploads."""
    PDF = "pdf"
    DOCX = "docx"
    TXT = "txt"
    MD = "md"
    HTML = "html"
    CSV = "csv"
    JSON = "json"
    XLSX = "xlsx"
    PPTX = "pptx"


class PromptType(str, Enum):
    """Prompt template type."""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    CHAT = "chat"


class Priority(str, Enum):
    """Priority level for scheduled jobs."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class DocumentType(str, Enum):
    """Document type for uploads."""
    PDF = "pdf"
    DOCX = "docx"
    TXT = "txt"
    MD = "md"
    HTML = "html"
    CSV = "csv"
    JSON = "json"
    XLSX = "xlsx"
    PPTX = "pptx"


class MessageRole(str, Enum):
    """Chat message role."""
    USER = "user"
    ASSISTANT = "assistant"
    SYSTEM = "system"


AgentModeLiteral = Literal["retriever", "coder", "chatter", "planner", "computer", "voice", "accuracy"]
EntityTypeLiteral = Literal["intent", "ner", "topic"]
AuthTypeLiteral = Literal["bearer", "apikey", "oauth", "password", "env", "generic", "none", "username_and_password", "basic"]
RequestTypeLiteral = Literal["get", "post", "put", "delete", "patch", "custom", "graphql_query", "graphql_mutation"]