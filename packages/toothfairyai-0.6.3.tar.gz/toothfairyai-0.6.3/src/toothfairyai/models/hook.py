"""Pydantic models for Hook (CustomCodeExecutionEnvironment) validation."""

from typing import Any, Dict, Optional
from pydantic import Field

from .base import ToothFairyModel


class HookCreateModel(ToothFairyModel):
    """Validation model for creating a hook (custom code execution environment)."""

    name: str = Field(..., min_length=1, max_length=255, description="Hook name")
    description: Optional[str] = Field(default=None, description="Hook description")
    function_name: Optional[str] = Field(default=None, description="Name of the function to execute")
    custom_execution_code: Optional[str] = Field(default=None, description="Custom Python code to execute")
    custom_execution_instructions: Optional[str] = Field(default=None, description="Instructions for code execution")
    custom_execution_secrets: Optional[Dict[str, Any]] = Field(default=None, description="Secrets for code execution")
    static_docs: Optional[Dict[str, Any]] = Field(default=None, description="Static documents for code execution")
    available_libraries: Optional[str] = Field(default=None, description="Available Python libraries")
    allow_external_api: bool = Field(default=False, description="Whether to allow external API calls")
    hardcoded_script: bool = Field(default=False, description="Whether this is a hardcoded script")
    is_template: bool = Field(default=False, description="Whether this is a template hook")

    def to_api_payload(self) -> dict:
        payload = {
            "name": self.name,
            "allowExternalAPI": self.allow_external_api,
            "hardcodedScript": self.hardcoded_script,
            "isTemplate": self.is_template,
        }
        if self.description is not None:
            payload["description"] = self.description
        if self.function_name is not None:
            payload["functionName"] = self.function_name
        if self.custom_execution_code is not None:
            payload["customExecutionCode"] = self.custom_execution_code
        if self.custom_execution_instructions is not None:
            payload["customExecutionInstructions"] = self.custom_execution_instructions
        if self.custom_execution_secrets is not None:
            payload["customExecutionSecrets"] = self.custom_execution_secrets
        if self.static_docs is not None:
            payload["staticDocs"] = self.static_docs
        if self.available_libraries is not None:
            payload["availableLibraries"] = self.available_libraries
        return payload


class HookUpdateModel(ToothFairyModel):
    """Validation model for updating a hook."""

    hook_id: str = Field(..., min_length=1, description="Hook ID to update")
    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    description: Optional[str] = Field(default=None)
    function_name: Optional[str] = Field(default=None)
    custom_execution_code: Optional[str] = Field(default=None)
    custom_execution_instructions: Optional[str] = Field(default=None)
    custom_execution_secrets: Optional[Dict[str, Any]] = Field(default=None)
    static_docs: Optional[Dict[str, Any]] = Field(default=None)
    available_libraries: Optional[str] = Field(default=None)
    allow_external_api: Optional[bool] = Field(default=None)
    hardcoded_script: Optional[bool] = Field(default=None)
    is_template: Optional[bool] = Field(default=None)

    def to_api_payload(self) -> dict:
        payload = {"id": self.hook_id}
        if self.name is not None:
            payload["name"] = self.name
        if self.description is not None:
            payload["description"] = self.description
        if self.function_name is not None:
            payload["functionName"] = self.function_name
        if self.custom_execution_code is not None:
            payload["customExecutionCode"] = self.custom_execution_code
        if self.custom_execution_instructions is not None:
            payload["customExecutionInstructions"] = self.custom_execution_instructions
        if self.custom_execution_secrets is not None:
            payload["customExecutionSecrets"] = self.custom_execution_secrets
        if self.static_docs is not None:
            payload["staticDocs"] = self.static_docs
        if self.available_libraries is not None:
            payload["availableLibraries"] = self.available_libraries
        if self.allow_external_api is not None:
            payload["allowExternalAPI"] = self.allow_external_api
        if self.hardcoded_script is not None:
            payload["hardcodedScript"] = self.hardcoded_script
        if self.is_template is not None:
            payload["isTemplate"] = self.is_template
        return payload