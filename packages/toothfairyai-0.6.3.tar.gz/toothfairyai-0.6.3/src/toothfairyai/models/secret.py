"""Pydantic models for Secret validation."""

from pydantic import Field

from .base import ToothFairyModel


class SecretCreateModel(ToothFairyModel):
    """Validation model for creating a secret."""

    authorisation_id: str = Field(..., min_length=1, description="Authorisation ID to link secret to")
    password_secret_value: str = Field(..., min_length=1, description="The secret value to store")

    def to_api_payload(self) -> dict:
        return {
            "id": self.authorisation_id,
            "passwordSecretValue": self.password_secret_value,
        }