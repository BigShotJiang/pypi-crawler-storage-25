"""Pydantic models for Connection (Hosting) validation."""

from typing import Optional
from pydantic import Field, field_validator

from .base import ToothFairyModel
from .enums import HostingType
from .validators import validate_url


class ConnectionCreateModel(ToothFairyModel):
    """Validation model for creating a connection (Hosting)."""

    name: str = Field(..., min_length=1, max_length=255, description="Connection name")
    type: HostingType = Field(..., description="Hosting type")
    endpoint: Optional[str] = Field(default=None, description="API endpoint URL")
    model_name: Optional[str] = Field(default=None, description="Model name to use")
    base_model: Optional[str] = Field(default=None, description="Base model identifier")
    custom_model: bool = Field(default=False, description="Whether this is a custom model")
    api_version: Optional[str] = Field(default=None, description="API version (for Azure OpenAI)")
    token_secret: Optional[str] = Field(default=None, description="Secret name for API token")
    description: Optional[str] = Field(default=None, description="Connection description")

    @field_validator("endpoint")
    @classmethod
    def validate_endpoint(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            return validate_url(v)
        return v

    def to_api_payload(self) -> dict:
        payload = {
            "name": self.name,
            "type": self.type.value,
            "customModel": self.custom_model,
        }
        if self.endpoint is not None:
            payload["endpoint"] = self.endpoint
        if self.model_name is not None:
            payload["modelName"] = self.model_name
        if self.base_model is not None:
            payload["baseModel"] = self.base_model
        if self.api_version is not None:
            payload["apiVersion"] = self.api_version
        if self.token_secret is not None:
            payload["tokenSecret"] = self.token_secret
        if self.description is not None:
            payload["description"] = self.description
        return payload


class ConnectionUpdateModel(ToothFairyModel):
    """Validation model for updating a connection."""

    connection_id: str = Field(..., min_length=1, description="Connection ID to update")
    name: Optional[str] = Field(default=None, min_length=1, max_length=255)
    type: Optional[HostingType] = Field(default=None)
    endpoint: Optional[str] = Field(default=None)
    model_name: Optional[str] = Field(default=None)
    base_model: Optional[str] = Field(default=None)
    custom_model: Optional[bool] = Field(default=None)
    api_version: Optional[str] = Field(default=None)
    token_secret: Optional[str] = Field(default=None)
    description: Optional[str] = Field(default=None)

    @field_validator("endpoint")
    @classmethod
    def validate_endpoint(cls, v: Optional[str]) -> Optional[str]:
        if v is not None:
            return validate_url(v)
        return v

    def to_api_payload(self) -> dict:
        payload = {"id": self.connection_id}
        if self.name is not None:
            payload["name"] = self.name
        if self.type is not None:
            payload["type"] = self.type.value
        if self.endpoint is not None:
            payload["endpoint"] = self.endpoint
        if self.model_name is not None:
            payload["modelName"] = self.model_name
        if self.base_model is not None:
            payload["baseModel"] = self.base_model
        if self.custom_model is not None:
            payload["customModel"] = self.custom_model
        if self.api_version is not None:
            payload["apiVersion"] = self.api_version
        if self.token_secret is not None:
            payload["tokenSecret"] = self.token_secret
        if self.description is not None:
            payload["description"] = self.description
        return payload