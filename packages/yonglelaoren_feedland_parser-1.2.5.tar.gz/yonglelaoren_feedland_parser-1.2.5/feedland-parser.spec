# -*- mode: python ; coding: utf-8 -*-

block_cipher = None

a = Analysis(
    ['src/feedland_parser/cli.py'],
    pathex=[],
    binaries=[],
    datas=[
        ('src/feedland_parser', 'feedland_parser'),
    ],
    hiddenimports=[
        'feedparser',
        'newspaper',
        'bs4',
        'requests',
        'lxml',
        'dateutil',
        'dateutil.parser',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'matplotlib',
        'numpy',
        'pandas',
        'scipy',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='yonglelaoren-feedland-parser',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

# 如果需要创建目录版本（包含所有依赖）
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='yonglelaoren-feedland-parser',
)