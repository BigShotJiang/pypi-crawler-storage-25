"""H.264 → aiortc VideoStreamTrack adapter.

Reads H.264 NAL units produced by ScrcpyAdapter and feeds them as
av.VideoFrame objects to an aiortc VideoStreamTrack for WebRTC streaming.
"""

from __future__ import annotations

import asyncio
import fractions
import logging
import time
from typing import Any, Callable

import av
from aiortc import MediaStreamTrack
from aiortc.mediastreams import MediaStreamError

logger = logging.getLogger(__name__)

CLOCK_RATE = 90_000
TIME_BASE = fractions.Fraction(1, CLOCK_RATE)


class ScrcpyVideoTrack(MediaStreamTrack):
    """aiortc video track fed by H.264 NAL units from scrcpy."""

    kind = "video"

    def __init__(
        self,
        target_fps: int = 30,
        on_bulk_discard: Callable[[], None] | None = None,
    ) -> None:
        super().__init__()
        self._queue: asyncio.Queue[bytes] = asyncio.Queue(maxsize=120)
        self._codec: av.CodecContext | None = None
        self._target_fps = target_fps
        self._frame_interval = 1.0 / target_fps
        self._start_time: float | None = None
        self._frame_count = 0
        self._on_bulk_discard = on_bulk_discard
        self._last_width = 0
        self._last_height = 0

    def push_nal(self, data: bytes, *, is_config: bool = False) -> None:
        """Push raw H.264 NAL unit data (called by ScrcpyAdapter reader).

        ``is_config`` marks SPS/PPS parameter sets which should never be
        dropped.
        """
        try:
            self._queue.put_nowait(data)
        except asyncio.QueueFull:
            if is_config:
                try:
                    self._queue.get_nowait()
                except asyncio.QueueEmpty:
                    pass
                try:
                    self._queue.put_nowait(data)
                except asyncio.QueueFull:
                    pass
            else:
                to_discard = max(1, (self._queue.qsize() * 3) // 4)
                discarded = 0
                for _ in range(to_discard):
                    try:
                        self._queue.get_nowait()
                        discarded += 1
                    except asyncio.QueueEmpty:
                        break
                if discarded:
                    logger.debug("Bulk-discarded %d/%d stale frames (kept recent quarter)",
                                 discarded, discarded + self._queue.qsize())
                    if self._on_bulk_discard:
                        self._on_bulk_discard()
                try:
                    self._queue.put_nowait(data)
                except asyncio.QueueFull:
                    pass

    def flush(self) -> None:
        """Drain the queue and reset H.264 decoder for stream restart."""
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
        if self._codec is not None:
            self._codec = None
            logger.info("H.264 codec context reset (stream restart)")

    async def recv(self) -> av.VideoFrame:
        """Called by aiortc to get the next video frame."""
        if self.readyState != "live":
            raise MediaStreamError

        if self._start_time is None:
            self._start_time = time.monotonic()

        while True:
            try:
                data = await asyncio.wait_for(self._queue.get(), timeout=5.0)
            except asyncio.TimeoutError:
                if self.readyState != "live":
                    raise MediaStreamError
                logger.warning("No video frames for 5s, still waiting…")
                continue
            frames = self._decode_h264(data)
            if frames:
                frame = frames[-1]
                self._last_width = frame.width
                self._last_height = frame.height
                frame.pts = self._frame_count
                frame.time_base = TIME_BASE
                self._frame_count += 1
                return frame

    def _decode_h264(self, data: bytes) -> list[av.VideoFrame]:
        if self._codec is None:
            self._codec = av.CodecContext.create("h264", "r")
        try:
            packet = av.Packet(data)
            return self._codec.decode(packet)
        except av.error.InvalidDataError:
            logger.debug("Invalid H.264 data, skipping packet")
            return []

    def stop(self) -> None:
        super().stop()
        if self._codec:
            self._codec = None
