"""ACP JSON-RPC 2.0 method router.

Dispatches incoming JSON-RPC requests/notifications to the appropriate handler.
Protocol is aligned with beeos-claw's ACP implementation.
"""

from __future__ import annotations

import json
import logging
from typing import Any, Callable, Awaitable

from .device_handler import DeviceHandler
from .session_handler import SessionHandler

logger = logging.getLogger(__name__)

JsonRpcHandler = Callable[[dict[str, Any]], Awaitable[dict[str, Any]]]


class ACPRouter:
    """Routes ACP JSON-RPC 2.0 messages to device and session handlers."""

    def __init__(
        self,
        device_handler: DeviceHandler,
        session_handler: SessionHandler,
    ) -> None:
        self._device = device_handler
        self._session = session_handler
        self._handlers: dict[str, JsonRpcHandler] = {}
        self._notification_handlers: dict[str, JsonRpcHandler] = {}
        self._register_handlers()

    def _register_handlers(self) -> None:
        # Protocol handshake
        self._handlers["initialize"] = self._handle_initialize

        # device/*
        self._handlers["device/info"] = self._device.handle_info
        self._handlers["device/screenshot"] = self._device.handle_screenshot
        self._handlers["device/ui-tree"] = self._device.handle_ui_tree
        self._handlers["device/action"] = self._device.handle_action
        self._handlers["device/install"] = self._device.handle_install
        self._handlers["device/shell"] = self._device.handle_shell

        # session/*
        self._handlers["session/new"] = self._session.handle_new
        self._handlers["session/load"] = self._session.handle_load
        self._handlers["session/list"] = self._session.handle_list
        self._handlers["session/prompt"] = self._session.handle_prompt
        self._handlers["session/rename"] = self._session.handle_rename
        self._handlers["session/delete"] = self._session.handle_delete
        self._handlers["session/clear"] = self._session.handle_clear
        self._handlers["session/cancel"] = self._session.handle_cancel
        self._handlers["session/set_mode"] = self._session.handle_set_mode
        self._handlers["session/set_model"] = self._session.handle_set_model

        # skills/*
        self._handlers["skills/list"] = self._handle_skills_list

        # Notifications (no id, no response)
        self._notification_handlers["session/cancel"] = self._session.handle_cancel

    @staticmethod
    async def _handle_initialize(_msg: dict[str, Any]) -> dict[str, Any]:
        return {
            "protocolVersion": 1,
            "agentCapabilities": {
                "loadSession": True,
                "terminal": False,
                "skills": False,
                "promptCapabilities": {
                    "image": False,
                    "audio": False,
                    "embeddedContext": False,
                },
                "sessionCapabilities": {
                    "list": {},
                },
            },
            "agentInfo": {
                "name": "device-agent",
                "title": "BeeOS Device Agent",
                "version": "0.1.0",
            },
            "_meta": {},
            "authMethods": [],
        }

    @staticmethod
    async def _handle_skills_list(_msg: dict[str, Any]) -> dict[str, Any]:
        return {"skills": []}

    async def handle_message(self, raw: str) -> str | None:
        """Parse and dispatch a JSON-RPC 2.0 message, returning the response JSON.

        Returns ``None`` for notifications (no ``id`` field).
        """
        try:
            msg = json.loads(raw)
        except json.JSONDecodeError:
            return self._error_response(None, -32700, "Parse error")

        method = msg.get("method", "")
        msg_id = msg.get("id")

        if msg_id is None:
            handler = self._notification_handlers.get(method)
            if handler:
                try:
                    await handler(msg)
                except Exception:
                    logger.exception("Notification handler error for %s", method)
            return None

        handler = self._handlers.get(method)
        if handler is None:
            return self._error_response(msg_id, -32601, f"Method not found: {method}")

        try:
            result = await handler(msg)
            return json.dumps({
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": result,
            })
        except Exception as exc:
            logger.exception("Handler error for %s", method)
            return self._error_response(msg_id, -32000, str(exc))

    @staticmethod
    def _error_response(msg_id: Any, code: int, message: str) -> str:
        return json.dumps({
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {"code": code, "message": message},
        })
