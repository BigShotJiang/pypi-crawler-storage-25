"""ADB Proxy Server for cloud mode.

Listens on a configurable port (default 5556) and transparently forwards
ADB connections to the local ReDroid ADB server (localhost:5555).

Security model:
  - Maintains a set of authorized ADB public keys (added via add_authorized_key).
  - When one or more keys are registered, only connections that present a
    recognized RSA public key during the ADB AUTH handshake are forwarded.
  - When no keys are registered, all connections are rejected (closed mode)
    unless explicitly set to open mode via allow_unauthenticated().
  - Keys can be added/removed at runtime (thread-safe via asyncio).

ADB protocol notes:
  The proxy intercepts the initial ADB handshake to enforce authentication.
  ADB messages are 24 bytes: command(4) + arg0(4) + arg1(4) + length(4) +
  crc(4) + magic(4), followed by `length` bytes of payload.
  AUTH flow: daemon CNXN → client CNXN → daemon AUTH TOKEN → client AUTH
  SIGNATURE → (optionally) client AUTH RSAPUBLICKEY → daemon CNXN (success).
  We intercept AUTH RSAPUBLICKEY from client to extract and verify the key.
"""

from __future__ import annotations

import asyncio
import logging
import os
import struct

logger = logging.getLogger(__name__)

_DEFAULT_ADB_TARGET = "127.0.0.1"
_DEFAULT_ADB_TARGET_PORT = 5555
_DEFAULT_PROXY_PORT = 5556

_ADB_HEADER_SIZE = 24
_ADB_CMD_CNXN = 0x4E584E43  # 'CNXN'
_ADB_CMD_AUTH = 0x48545541  # 'AUTH'
_ADB_AUTH_TOKEN = 1
_ADB_AUTH_SIGNATURE = 2
_ADB_AUTH_RSAPUBLICKEY = 3


def _parse_adb_message(data: bytes) -> tuple[int, int, int, int] | None:
    """Parse an ADB message header. Returns (command, arg0, arg1, data_length) or None."""
    if len(data) < _ADB_HEADER_SIZE:
        return None
    cmd, arg0, arg1, data_len, _, _ = struct.unpack("<6I", data[:_ADB_HEADER_SIZE])
    return cmd, arg0, arg1, data_len


class ADBProxyServer:
    """TCP proxy that forwards ADB connections to a local ADB server with optional key auth."""

    def __init__(
        self,
        listen_host: str = "0.0.0.0",
        listen_port: int = _DEFAULT_PROXY_PORT,
        target_host: str = _DEFAULT_ADB_TARGET,
        target_port: int = _DEFAULT_ADB_TARGET_PORT,
    ) -> None:
        self._listen_host = listen_host
        self._listen_port = int(os.environ.get("ADB_PROXY_PORT", listen_port))
        self._target_host = target_host
        self._target_port = target_port
        self._authorized_keys: set[str] = set()
        self._open_mode = False
        self._server: asyncio.Server | None = None
        self._active_connections = 0

    def add_authorized_key(self, pubkey: str) -> None:
        """Register an ADB public key. Connections presenting this key will be allowed."""
        normalized = pubkey.strip()
        if not normalized:
            return
        self._authorized_keys.add(normalized)
        logger.info("adb-proxy: authorized key added (total: %d)", len(self._authorized_keys))

    def remove_authorized_key(self, pubkey: str) -> None:
        """Remove a previously authorized key."""
        self._authorized_keys.discard(pubkey.strip())
        logger.info("adb-proxy: key removed (total: %d)", len(self._authorized_keys))

    def allow_unauthenticated(self, allow: bool = True) -> None:
        """When True, connections are forwarded even with no authorized keys."""
        self._open_mode = allow

    @property
    def key_count(self) -> int:
        return len(self._authorized_keys)

    async def start(self) -> None:
        self._server = await asyncio.start_server(
            self._handle_client,
            self._listen_host,
            self._listen_port,
        )
        addrs = [s.getsockname() for s in self._server.sockets]
        logger.info("adb-proxy: listening on %s (forwarding to %s:%d)",
                     addrs, self._target_host, self._target_port)

    async def stop(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            logger.info("adb-proxy: stopped")

    def _is_key_authorized(self, key_data: bytes) -> bool:
        """Check if a public key (from AUTH RSAPUBLICKEY payload) is in the allowlist."""
        try:
            key_str = key_data.rstrip(b"\x00").decode("utf-8", errors="replace").strip()
        except Exception:
            return False
        for authorized in self._authorized_keys:
            if key_str == authorized or key_str.startswith(authorized.split()[0] if " " in authorized else authorized):
                return True
        return False

    async def _read_adb_message(self, reader: asyncio.StreamReader) -> tuple[bytes, int, int, int, int] | None:
        """Read one complete ADB message (header + payload). Returns (full_bytes, cmd, arg0, arg1, data_len)."""
        try:
            header = await asyncio.wait_for(reader.readexactly(_ADB_HEADER_SIZE), timeout=30.0)
        except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError):
            return None
        parsed = _parse_adb_message(header)
        if parsed is None:
            return None
        cmd, arg0, arg1, data_len = parsed
        payload = b""
        if data_len > 0:
            try:
                payload = await asyncio.wait_for(reader.readexactly(data_len), timeout=30.0)
            except (asyncio.IncompleteReadError, asyncio.TimeoutError, ConnectionError):
                return None
        return header + payload, cmd, arg0, arg1, data_len

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        peer = writer.get_extra_info("peername")
        self._active_connections += 1
        logger.info("adb-proxy: connection from %s (active: %d)", peer, self._active_connections)

        if not self._open_mode and not self._authorized_keys:
            logger.warning("adb-proxy: rejecting %s — no authorized keys and not in open mode", peer)
            writer.close()
            self._active_connections -= 1
            return

        try:
            upstream_reader, upstream_writer = await asyncio.open_connection(
                self._target_host, self._target_port
            )
        except (ConnectionRefusedError, OSError) as e:
            logger.error("adb-proxy: cannot connect to ADB at %s:%d: %s",
                         self._target_host, self._target_port, e)
            writer.close()
            self._active_connections -= 1
            return

        if self._authorized_keys:
            authorized = await self._authenticate_connection(
                reader, writer, upstream_reader, upstream_writer, peer
            )
            if not authorized:
                for w in (writer, upstream_writer):
                    try:
                        w.close()
                    except Exception:
                        pass
                self._active_connections -= 1
                return

        try:
            await asyncio.gather(
                self._pipe(reader, upstream_writer, f"client→adb ({peer})"),
                self._pipe(upstream_reader, writer, f"adb→client ({peer})"),
            )
        except Exception:
            pass
        finally:
            for w in (writer, upstream_writer):
                try:
                    w.close()
                except Exception:
                    pass
            self._active_connections -= 1
            logger.info("adb-proxy: disconnected %s (active: %d)", peer, self._active_connections)

    async def _authenticate_connection(
        self,
        client_reader: asyncio.StreamReader,
        client_writer: asyncio.StreamWriter,
        upstream_reader: asyncio.StreamReader,
        upstream_writer: asyncio.StreamWriter,
        peer: object,
    ) -> bool:
        """Intercept ADB AUTH handshake to verify client's public key.

        ADB handshake order:
          1. daemon → CNXN (banner)
          2. client → CNXN
          3. daemon → AUTH TOKEN (challenge)
          4. client → AUTH SIGNATURE / AUTH RSAPUBLICKEY  (we check key here)
          5. daemon → CNXN (success) or loop to 3

        We must read from upstream first because the daemon initiates with CNXN.
        """
        # Step 1: read daemon's initial CNXN and forward to client
        daemon_hello = await self._read_adb_message(upstream_reader)
        if daemon_hello is None:
            logger.warning("adb-proxy: upstream closed before sending CNXN for %s", peer)
            return False
        raw, cmd, _, _, _ = daemon_hello
        client_writer.write(raw)
        await client_writer.drain()
        if cmd != _ADB_CMD_CNXN:
            logger.warning("adb-proxy: expected CNXN from daemon, got 0x%08X for %s", cmd, peer)
            return False

        # Step 2..N: relay client ↔ daemon, inspecting AUTH RSAPUBLICKEY from client
        max_rounds = 20
        for _ in range(max_rounds):
            # Read from client
            msg = await self._read_adb_message(client_reader)
            if msg is None:
                logger.warning("adb-proxy: client %s disconnected during auth", peer)
                return False
            raw, cmd, arg0, _, data_len = msg

            if cmd == _ADB_CMD_AUTH and arg0 == _ADB_AUTH_RSAPUBLICKEY:
                key_payload = raw[_ADB_HEADER_SIZE:_ADB_HEADER_SIZE + data_len]
                if not self._is_key_authorized(key_payload):
                    logger.warning("adb-proxy: rejecting %s — unauthorized ADB public key", peer)
                    return False
                logger.info("adb-proxy: authorized key from %s", peer)

            # Forward to daemon
            upstream_writer.write(raw)
            await upstream_writer.drain()

            # Read daemon response
            resp = await self._read_adb_message(upstream_reader)
            if resp is None:
                return False
            resp_raw, resp_cmd, _, _, _ = resp

            # Forward to client
            client_writer.write(resp_raw)
            await client_writer.drain()

            if resp_cmd == _ADB_CMD_CNXN:
                return True

        logger.warning("adb-proxy: auth handshake exceeded max rounds for %s", peer)
        return False

    @staticmethod
    async def _pipe(
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        label: str,
    ) -> None:
        try:
            while True:
                data = await reader.read(65536)
                if not data:
                    break
                writer.write(data)
                await writer.drain()
        except (ConnectionResetError, BrokenPipeError, asyncio.CancelledError):
            pass
        except Exception as e:
            logger.debug("adb-proxy pipe %s error: %s", label, e)
        finally:
            try:
                if writer.can_write_eof():
                    writer.write_eof()
            except Exception:
                pass
