"""Multi-model mobile agent for BeeOS DeviceAgent.

Supports UI-TARS (ByteDance), MobileAgent (X-PLUG), and generic VLMs.
Provides an async agent loop that uses a VLM to perceive and act on mobile devices.
"""

from .agent import StepResult, run_mobile_agent
from .vlm import detect_model_profile

__all__ = ["run_mobile_agent", "StepResult", "detect_model_profile"]
