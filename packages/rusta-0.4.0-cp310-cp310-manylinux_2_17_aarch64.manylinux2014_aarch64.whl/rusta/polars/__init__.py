"""Polars-native interface for Rusta indicators.

Accepts polars.Series, returns polars.Series.
Internally converts to NumPy arrays for Rust computation.
"""

import numpy as np
import polars as pl

from ..rusta import (
    sma as _sma,
    ema as _ema,
    wma as _wma,
    hma as _hma,
    alma as _alma,
    kama as _kama,
    macd as _macd,
    rsi as _rsi,
)


def _to_numpy(s: pl.Series) -> np.ndarray:
    return s.to_numpy().astype(np.float64, copy=False)


def _to_series(name: str, arr: np.ndarray) -> pl.Series:
    return pl.Series(name, arr, nan_to_null=False)


def sma(series: pl.Series, period: int) -> pl.Series:
    return _to_series(series.name, _sma(_to_numpy(series), period))


def ema(series: pl.Series, period: int) -> pl.Series:
    return _to_series(series.name, _ema(_to_numpy(series), period))


def wma(series: pl.Series, period: int) -> pl.Series:
    return _to_series(series.name, _wma(_to_numpy(series), period))


def hma(series: pl.Series, period: int) -> pl.Series:
    return _to_series(series.name, _hma(_to_numpy(series), period))


def alma(series: pl.Series, period: int, offset: float = 0.85, sigma: float = 6.0) -> pl.Series:
    return _to_series(series.name, _alma(_to_numpy(series), period, offset, sigma))


def kama(series: pl.Series, period: int, fast_period: int = 2, slow_period: int = 30) -> pl.Series:
    return _to_series(series.name, _kama(_to_numpy(series), period, fast_period, slow_period))


def macd(
    series: pl.Series,
    fast_period: int = 12,
    slow_period: int = 26,
    signal_period: int = 9,
) -> tuple[pl.Series, pl.Series, pl.Series]:
    m, s, h = _macd(_to_numpy(series), fast_period, slow_period, signal_period)
    name = series.name
    return (_to_series(f"MACD_{name}", m), _to_series(f"MACDs_{name}", s), _to_series(f"MACDh_{name}", h))


def rsi(series: pl.Series, period: int = 14) -> pl.Series:
    return _to_series(series.name, _rsi(_to_numpy(series), period))
