import numpy as np

from .rusta import (
    sma as _sma,
    ema as _ema,
    wma as _wma,
    hma as _hma,
    alma as _alma,
    kama as _kama,
    macd as _macd,
    rsi as _rsi,
)

__all__ = ["sma", "ema", "wma", "hma", "alma", "kama", "macd", "rsi"]


def _ensure_array(data):
    if isinstance(data, np.ndarray):
        return np.asarray(data, dtype=np.float64)
    return np.asarray(data, dtype=np.float64)


def sma(data, period):
    return _sma(_ensure_array(data), period)


def ema(data, period):
    return _ema(_ensure_array(data), period)


def wma(data, period):
    return _wma(_ensure_array(data), period)


def hma(data, period):
    return _hma(_ensure_array(data), period)


def alma(data, period, offset=0.85, sigma=6.0):
    return _alma(_ensure_array(data), period, offset, sigma)


def kama(data, period, fast_period=2, slow_period=30):
    return _kama(_ensure_array(data), period, fast_period, slow_period)


def macd(data, fast_period=12, slow_period=26, signal_period=9):
    return _macd(_ensure_array(data), fast_period, slow_period, signal_period)


def rsi(data, period=14):
    return _rsi(_ensure_array(data), period)
