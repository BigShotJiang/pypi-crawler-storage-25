// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! [`HandoverAttestation`] — type alias for [`Attestation<HandoverRecord>`].

use super::{super::attestation_framework::Attestation, record::HandoverRecord};

/// A validator's attestation to a specific epoch transition.
///
/// Created by signing a [`HandoverRecord`]'s `record_digest()` with the
/// validator's protocol key via [`Attestation::sign`].
pub type HandoverAttestation = Attestation<HandoverRecord>;
