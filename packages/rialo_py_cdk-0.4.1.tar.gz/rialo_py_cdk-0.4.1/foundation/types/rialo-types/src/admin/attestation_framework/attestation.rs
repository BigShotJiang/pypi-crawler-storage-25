// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Generic `Attestation<R>` type: sign, verify, and display.

use serde::{Deserialize, Serialize};

use super::{
    super::ED25519_SIGNATURE_SIZE,
    errors::AttestationError,
    record::{AttestableRecord, ATTESTATION_SIGNING_SIZE, INTENT_PREFIX_LENGTH},
    RecordDigest,
};
use crate::consensus_crypto::{AuthorityPublicKey, ProtocolPublicKey};

// ---------------------------------------------------------------------------
// Generic attestation type
// ---------------------------------------------------------------------------

/// A validator's signed attestation over a record digest.
///
/// Generic over `R: AttestableRecord`, which determines the intent prefix
/// used for domain-separated signing. Concrete attestation types are created
/// by defining a record type that implements `AttestableRecord` (via the
/// `impl_attestable_record!` macro) and using `Attestation<MyRecord>`.
///
/// # Wire compatibility
///
/// The `PhantomData<R>` field is `#[serde(skip)]` — it occupies zero bytes
/// on the wire. BCS/JSON encoding contains only the four real fields.
/// `R` is still required to implement [`Serialize`] and [`DeserializeOwned`](serde::de::DeserializeOwned) via
/// [`AttestableRecord`] so derived serde impls on `Attestation<R>` carry correct bounds.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Attestation<R: AttestableRecord> {
    /// Blake3 digest of the record being attested.
    record_digest: RecordDigest,

    /// The validator's authority public key identifying the sender.
    authority_key: AuthorityPublicKey,

    /// The validator's protocol public key used to verify the signature.
    protocol_key: ProtocolPublicKey,

    /// Ed25519 signature over the intent-prefixed record_digest bytes.
    #[serde(with = "serde_big_array::BigArray")]
    signature: [u8; ED25519_SIGNATURE_SIZE],

    /// Type marker for the record type. Zero-size, not serialized.
    #[serde(skip)]
    _marker: std::marker::PhantomData<R>,
}

impl<R: AttestableRecord> PartialEq for Attestation<R> {
    fn eq(&self, other: &Self) -> bool {
        self.authority_key == other.authority_key
            && self.record_digest == other.record_digest
            && self.protocol_key == other.protocol_key
            && self.signature == other.signature
    }
}

impl<R: AttestableRecord> Eq for Attestation<R> {}

impl<R: AttestableRecord> PartialOrd for Attestation<R> {
    fn partial_cmp(&self, other: &Self) -> Option<std::cmp::Ordering> {
        Some(self.cmp(other))
    }
}

/// Ordered by `authority_key` first, then remaining fields for total-order consistency
/// with `PartialEq`. This ordering is what allows [`BTreeSet`](std::collections::BTreeSet)
/// storage in [`Certificate`](super::certificate::Certificate).
impl<R: AttestableRecord> Ord for Attestation<R> {
    fn cmp(&self, other: &Self) -> std::cmp::Ordering {
        self.authority_key
            .cmp(&other.authority_key)
            .then_with(|| self.record_digest.cmp(&other.record_digest))
            .then_with(|| self.protocol_key.cmp(&other.protocol_key))
            .then_with(|| self.signature.cmp(&other.signature))
    }
}

impl<R: AttestableRecord> Attestation<R> {
    /// Returns the message bytes that should be signed for this attestation type.
    ///
    /// The message is `intent_prefix || record_digest` (35 bytes), where
    /// `intent_prefix` is determined by [`R::INTENT_PREFIX`](AttestableRecord::INTENT_PREFIX).
    pub fn signing_message(record_digest: &RecordDigest) -> [u8; ATTESTATION_SIGNING_SIZE] {
        let mut msg = [0u8; ATTESTATION_SIGNING_SIZE];
        msg[..INTENT_PREFIX_LENGTH].copy_from_slice(&R::INTENT_PREFIX);
        msg[INTENT_PREFIX_LENGTH..].copy_from_slice(record_digest);
        msg
    }

    /// Returns the message bytes for this attestation instance.
    pub fn message_bytes(&self) -> [u8; ATTESTATION_SIGNING_SIZE] {
        Self::signing_message(&self.record_digest)
    }

    /// Builds and signs an attestation.
    ///
    /// Computes the record digest via [`AttestableRecord::record_digest()`],
    /// signs it with the protocol keypair, self-verifies unconditionally, and
    /// returns the attestation on success.
    ///
    /// # Errors
    /// Returns [`AttestationError::SelfVerificationFailed`] if self-verification fails
    /// (corrupted keypair or signing bug).
    pub fn sign(
        record: &R,
        protocol_keypair: &crate::ProtocolKeyPair,
        authority_key: &AuthorityPublicKey,
    ) -> Result<Self, AttestationError> {
        let record_digest = record.record_digest();
        let protocol_public_key = protocol_keypair.public();
        let msg_bytes = Self::signing_message(&record_digest);
        let signature = protocol_keypair.sign(&msg_bytes);

        // Self-verify unconditionally to catch corrupted keypairs or signing bugs.
        if let Err(e) = protocol_public_key.verify(&msg_bytes, &signature) {
            tracing::error!(
                attestation_type = R::TYPE_NAME,
                record_digest = hex::encode(&record_digest[..8]),
                error = %e,
                "Attestation self-verification FAILED — signing may be corrupted",
            );
            return Err(AttestationError::SelfVerificationFailed {
                attest_type: R::TYPE_NAME,
            });
        }

        let mut signature_bytes = [0u8; ED25519_SIGNATURE_SIZE];
        signature_bytes.copy_from_slice(&signature.to_bytes());

        Ok(Self {
            record_digest,
            authority_key: authority_key.clone(),
            protocol_key: protocol_public_key,
            signature: signature_bytes,
            _marker: std::marker::PhantomData,
        })
    }

    /// Verifies the Ed25519 signature against the **embedded** `protocol_key`.
    ///
    /// # NOT a trust-boundary check
    /// This method only proves internal consistency: the signature was produced
    /// by whoever controls the private key matching `self.protocol_key`. It does
    /// **NOT** authenticate the signer — an adversary can embed their own keypair,
    /// sign any digest, and this method will return `Ok(())`.
    ///
    /// **At actual trust boundaries** (P2P ingress, tracker insertion), callers
    /// MUST first verify that `self.protocol_key` belongs to a committee-registered
    /// validator for the claimed epoch, then call this method.
    ///
    /// # Errors
    ///
    /// Returns [`AttestationError::MalformedSignature`] or
    /// [`AttestationError::SignatureVerificationFailed`] on failure.
    pub fn verify_internal_consistency(&self) -> Result<(), AttestationError> {
        let msg = self.message_bytes();
        let sig = crate::ProtocolKeySignature::from_bytes(&self.signature).map_err(|_| {
            AttestationError::MalformedSignature {
                attest_type: R::TYPE_NAME,
            }
        })?;
        self.protocol_key.verify(&msg, &sig).map_err(|_| {
            AttestationError::SignatureVerificationFailed {
                attest_type: R::TYPE_NAME,
            }
        })
    }

    /// Returns the Blake3 digest of the attested record.
    pub fn record_digest(&self) -> &RecordDigest {
        &self.record_digest
    }

    /// Returns the validator's authority public key.
    pub fn authority_key(&self) -> &AuthorityPublicKey {
        &self.authority_key
    }

    /// Returns the validator's protocol public key used to verify the signature.
    pub fn protocol_key(&self) -> &ProtocolPublicKey {
        &self.protocol_key
    }

    /// Returns the Ed25519 signature bytes.
    pub fn signature_bytes(&self) -> &[u8; ED25519_SIGNATURE_SIZE] {
        &self.signature
    }
}

impl<R: AttestableRecord> std::fmt::Display for Attestation<R> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "{}Attestation(digest={}…, authority={}…)",
            R::TYPE_NAME,
            hex::encode(&self.record_digest[..4]),
            hex::encode(&self.authority_key.to_bytes()[..4]),
        )
    }
}

/// Test-only constructors for [`Attestation<R>`].
///
/// Available when compiling tests within this crate (`#[cfg(test)]`) or when
/// downstream crates enable the `test-utils` Cargo feature.
#[cfg(any(test, feature = "test-utils"))]
impl<R: AttestableRecord> Attestation<R> {
    /// Construct an attestation from raw parts.
    ///
    /// **For tests only.** Bypasses `sign()` and self-verification.
    pub fn from_parts_for_test(
        record_digest: RecordDigest,
        authority_key: AuthorityPublicKey,
        protocol_key: ProtocolPublicKey,
        signature: [u8; ED25519_SIGNATURE_SIZE],
    ) -> Self {
        Self {
            record_digest,
            authority_key,
            protocol_key,
            signature,
            _marker: std::marker::PhantomData,
        }
    }
}

#[cfg(test)]
impl<R: AttestableRecord> Attestation<R> {
    /// Test helper: XOR a byte in the signature to simulate corruption.
    pub(crate) fn tamper_signature(&mut self, idx: usize, xor_val: u8) {
        self.signature[idx] ^= xor_val;
    }

    /// Test helper: replace the protocol key to simulate a wrong-signer scenario.
    pub(crate) fn set_protocol_key(&mut self, key: ProtocolPublicKey) {
        self.protocol_key = key;
    }

    /// Test helper: XOR a byte in the record digest to simulate a tampered digest.
    pub(crate) fn tamper_record_digest(&mut self, idx: usize, xor_val: u8) {
        self.record_digest[idx] ^= xor_val;
    }
}
