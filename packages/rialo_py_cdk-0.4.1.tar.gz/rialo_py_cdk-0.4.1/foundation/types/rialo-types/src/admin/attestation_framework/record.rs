// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Sealed record trait and macro for attestable record types.

use serde::{de::DeserializeOwned, Serialize};

use super::super::{epoch::EpochIdentifier, Blake3Hash, BLAKE3_HASH_SIZE};

/// The output of [`AttestableRecord::record_digest()`] — a domain-separated Blake3 hash.
pub type RecordDigest = Blake3Hash;

/// Prevents downstream crates from implementing [`AttestableRecord`].
///
/// Only protocol-defined record types may be used as type parameters for
/// [`Attestation<R>`](super::Attestation). The macro `impl_attestable_record!` adds the
/// `Sealed` impl alongside the trait impl.
pub(crate) mod private {
    pub trait Sealed {}
}

/// A record type that can be attested by validators.
///
/// This trait is **sealed** — it cannot be implemented outside this module.
/// Implementations must also be [`Serialize`] and [`DeserializeOwned`](serde::de::DeserializeOwned) so
/// [`Attestation<R>`](super::Attestation) (and future composite types) have well-defined serde bounds
/// even though `R` itself is not serialized inside a bare attestation
/// (`PhantomData<R>` is `#[serde(skip)]` on the wire).
///
/// Each record type provides a unique [`INTENT_PREFIX`](AttestableRecord::INTENT_PREFIX)
/// for domain-separated signing and a [`TYPE_NAME`](AttestableRecord::TYPE_NAME) for
/// log messages and `Display` implementations.
///
/// Signing and internal verification failures are reported as [`AttestationError`](super::AttestationError),
/// which carries [`AttestableRecord::TYPE_NAME`] as [`AttestationError::attest_type`](super::AttestationError::attest_type)
/// for structured handling and display.
pub trait AttestableRecord: private::Sealed + Serialize + DeserializeOwned {
    /// The 3-byte intent prefix for domain-separated signing.
    ///
    /// Format: `[IntentScope, IntentVersion::V0, AppId::Consensus]`.
    /// Each attestation type uses a distinct scope byte to prevent
    /// cross-protocol signature confusion.
    const INTENT_PREFIX: [u8; INTENT_PREFIX_LENGTH];

    /// Human-readable name for this record type (e.g., `"Snapshot"`, `"Handover"`).
    ///
    /// Used in structured log fields (`attestation_type`) and the
    /// [`Display`](std::fmt::Display) implementation of [`Attestation<R>`](super::Attestation).
    const TYPE_NAME: &'static str;

    /// The domain-separated digest that validators sign.
    fn record_digest(&self) -> RecordDigest;
}

/// Implements [`private::Sealed`] + [`AttestableRecord`] for a record type.
///
/// # Requirements
///
/// The record type **must** implement [`Serialize`] and [`DeserializeOwned`](serde::de::DeserializeOwned) (e.g. via
/// `#[derive(Serialize, Deserialize)]`).
///
/// The record type **must** define an inherent `fn compute_record_digest(&self) -> RecordDigest`
/// (any visibility) holding the real digest logic. The macro implements
/// [`AttestableRecord::record_digest`] as a call to that method, so it cannot accidentally
/// recurse into the trait method. Types may still expose `pub fn record_digest` as a thin
/// forwarder to `compute_record_digest` for a conventional public API.
///
/// # Usage
/// ```ignore
/// impl SnapshotRecord {
///     fn compute_record_digest(&self) -> RecordDigest { /* hash fields */ }
/// }
/// impl_attestable_record!(SnapshotRecord, SNAPSHOT_ATTESTATION_INTENT_PREFIX, "Snapshot");
/// ```
macro_rules! impl_attestable_record {
    ($record:ty, $prefix:expr, $type_name:literal) => {
        impl private::Sealed for $record {}

        impl AttestableRecord for $record {
            const INTENT_PREFIX: [u8; INTENT_PREFIX_LENGTH] = $prefix;
            const TYPE_NAME: &'static str = $type_name;

            fn record_digest(&self) -> RecordDigest {
                self.compute_record_digest()
            }
        }
    };
}

// ---------------------------------------------------------------------------
// Committee-attested records
// ---------------------------------------------------------------------------

/// Sealed marker for [`CommitteeAttestedRecord`].
pub(crate) mod committee_record {
    /// Crate-private seal: only `rialo-types` committee-attested record types implement this.
    pub trait Sealed {}
}

/// Record types that may appear in [`Certificate`](super::certificate::Certificate): they name an
/// **attesting epoch** and a **block height** so a
/// [`HandoverChain`](super::super::handover::HandoverChain) can supply the right committee and
/// window checks for [`Certificate::add_attestation`](super::certificate::Certificate::add_attestation).
///
/// For operational records (snapshots, ordered blocks, write-sets) the attesting epoch is the
/// single epoch the record belongs to. For **handover records** it is the **source epoch** — the
/// committee of the epoch being *left* attests the transition.
pub trait CommitteeAttestedRecord: AttestableRecord + committee_record::Sealed {
    /// Human-readable certificate family label, used in
    /// [`CertificateAttestationConsistencyError`](super::errors::CertificateAttestationConsistencyError).
    const CERTIFICATE_TYPE_NAME: &'static str;

    /// Epoch whose opening handover supplies the attestation committee.
    ///
    /// For operational records this is the record's single epoch. For handover records this is
    /// [`HandoverRecord::source_epoch`](super::super::handover::HandoverRecord::source_epoch) —
    /// the committee of the epoch being left.
    fn attesting_epoch(&self) -> EpochIdentifier;

    /// Block height used for epoch window checks against the handover chain.
    fn attested_block_height(&self) -> u64;
}

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

/// Intent prefix length (scope + version + app_id).
///
/// Mirrors `shared_crypto::intent::INTENT_PREFIX_LENGTH` but is inlined here
/// because `rialo-types` cannot depend on `shared-crypto` at compile time.
/// A `#[cfg(test)]` guard verifies these stay in sync.
pub(crate) const INTENT_PREFIX_LENGTH: usize = 3;

/// Size of the signing message for single-digest attestations:
/// 3-byte intent prefix + 32-byte record_digest = 35 bytes.
pub(crate) const ATTESTATION_SIGNING_SIZE: usize = INTENT_PREFIX_LENGTH + BLAKE3_HASH_SIZE;
