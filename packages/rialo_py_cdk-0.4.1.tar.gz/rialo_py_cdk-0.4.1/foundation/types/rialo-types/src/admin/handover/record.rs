// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! [`HandoverRecord`]: unsigned epoch-transition record and trait implementations.

use serde::{Deserialize, Serialize};

use super::super::{
    attestation_framework::{
        committee_record, private, AttestableRecord, CommitteeAttestedRecord, INTENT_PREFIX_LENGTH,
    },
    epoch::{EpochChangeConfig, EpochIdentifier},
    Blake3Hash, RecordDigest, BLAKE3_HASH_SIZE,
};

/// An epoch-transition record that validators attest to.
///
/// This is the unsigned record describing an epoch transition. It becomes
/// the subject of [`HandoverAttestation`](super::HandoverAttestation)s, which are aggregated into a
/// [`HandoverCertificate`](crate::HandoverCertificate) once f+1 stake-weighted validators attest.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct HandoverRecord {
    block_index: u64,
    source_epoch: EpochIdentifier,
    dest_epoch: EpochIdentifier,
    epoch_config: EpochChangeConfig,
    previous_handover_hash: Blake3Hash,
}

/// Domain prefix for `HandoverRecord::record_digest()`.
const RIALO_HANDOVER_RECORD_V1: &[u8] = b"RIALO_HANDOVER_RECORD_V1";

/// Intent prefix for `HandoverAttestation` signing messages.
///
/// Wire format: `[IntentScope::HandoverAttestation, IntentVersion::V0, AppId::Consensus]`
///
/// Guard tests:
/// - `test_handover_attestation_intent_prefix_matches_shared_crypto` (enum value sync)
/// - `test_handover_attestation_signing_message_wire_compatible_with_bcs` (full BCS wire compat)
pub(crate) const HANDOVER_ATTESTATION_INTENT_PREFIX: [u8; INTENT_PREFIX_LENGTH] = [11, 0, 2];

impl HandoverRecord {
    /// Constructs a new `HandoverRecord`.
    pub fn new(
        block_index: u64,
        source_epoch: EpochIdentifier,
        dest_epoch: EpochIdentifier,
        epoch_config: EpochChangeConfig,
        previous_handover_hash: Blake3Hash,
    ) -> Self {
        Self {
            block_index,
            source_epoch,
            dest_epoch,
            epoch_config,
            previous_handover_hash,
        }
    }

    /// Block index of this handover in the main chain.
    pub fn block_index(&self) -> u64 {
        self.block_index
    }

    /// The epoch being transitioned from.
    pub fn source_epoch(&self) -> EpochIdentifier {
        self.source_epoch
    }

    /// The epoch being transitioned to.
    pub fn dest_epoch(&self) -> EpochIdentifier {
        self.dest_epoch
    }

    /// Full configuration for the new epoch.
    pub fn epoch_config(&self) -> &EpochChangeConfig {
        &self.epoch_config
    }

    /// Blake3 hash of the previous `HandoverRecord` (forms skiplist chain).
    pub fn previous_handover_hash(&self) -> &Blake3Hash {
        &self.previous_handover_hash
    }

    /// Domain-separated Blake3 hash of this record.
    ///
    /// This single digest serves two roles:
    /// 1. **Chain linking** — stored as `previous_handover_hash` in the next record.
    /// 2. **Attestation signing** — the `record_digest` validators attest to.
    ///
    /// The hash is prefixed with `RIALO_HANDOVER_RECORD_V1` for domain separation.
    ///
    /// **Breaking change from legacy `HandoverCertificate::deterministic_hash()`:**
    /// This version prepends the domain prefix, which the original did not.
    /// Existing `previous_handover_hash` chains are incompatible.
    pub fn record_digest(&self) -> RecordDigest {
        self.compute_record_digest()
    }

    fn compute_record_digest(&self) -> RecordDigest {
        let mut hasher = blake3::Hasher::new();
        hasher.update(RIALO_HANDOVER_RECORD_V1);
        hasher.update(&self.block_index.to_le_bytes());
        hasher.update(&self.source_epoch.to_le_bytes());
        hasher.update(&self.dest_epoch.to_le_bytes());
        hasher.update(&self.epoch_config.deterministic_hash());
        hasher.update(&self.previous_handover_hash);
        *hasher.finalize().as_bytes()
    }

    /// Creates a genesis handover record.
    ///
    /// Genesis is a degenerate record where `source_epoch == dest_epoch == 0`,
    /// `epoch_config.current_epoch == epoch_config.new_epoch == 0`,
    /// and `previous_handover_hash` is zero.
    ///
    /// # Panics
    ///
    /// Panics if `epoch` is not 0, or if `epoch_config.current_epoch` or
    /// `epoch_config.new_epoch` differs from `epoch`.
    pub fn genesis(epoch: EpochIdentifier, epoch_config: EpochChangeConfig) -> Self {
        assert_eq!(epoch, EpochIdentifier::from(0), "genesis epoch must be 0");
        assert_eq!(
            epoch_config.current_epoch, epoch,
            "genesis epoch_config.current_epoch must match epoch"
        );
        assert_eq!(
            epoch_config.new_epoch, epoch,
            "genesis epoch_config.new_epoch must match epoch"
        );
        Self {
            block_index: 0,
            source_epoch: epoch,
            dest_epoch: epoch,
            epoch_config,
            previous_handover_hash: [0u8; BLAKE3_HASH_SIZE],
        }
    }

    /// Returns true if this is a genesis record.
    ///
    /// Matches the canonical shape produced by [`Self::genesis`] with epoch 0 and a
    /// degenerate epoch-change config: `block_index == 0`, `source_epoch == dest_epoch == 0`,
    /// `epoch_config.current_epoch == epoch_config.new_epoch == 0`, and
    /// `previous_handover_hash` is all zeros.
    pub fn is_genesis(&self) -> bool {
        self.block_index == 0
            && self.source_epoch == EpochIdentifier::from(0)
            && self.dest_epoch == EpochIdentifier::from(0)
            && self.epoch_config.current_epoch == EpochIdentifier::from(0)
            && self.epoch_config.new_epoch == EpochIdentifier::from(0)
            && self.previous_handover_hash == [0u8; BLAKE3_HASH_SIZE]
    }
}

impl_attestable_record!(
    HandoverRecord,
    HANDOVER_ATTESTATION_INTENT_PREFIX,
    "Handover"
);

impl committee_record::Sealed for HandoverRecord {}

impl CommitteeAttestedRecord for HandoverRecord {
    const CERTIFICATE_TYPE_NAME: &'static str = "HandoverCertificate";

    fn attesting_epoch(&self) -> EpochIdentifier {
        self.source_epoch
    }

    fn attested_block_height(&self) -> u64 {
        self.block_index
    }
}
