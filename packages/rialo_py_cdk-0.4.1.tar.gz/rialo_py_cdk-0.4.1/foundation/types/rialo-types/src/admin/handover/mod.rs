// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Handover record, attestation, and certificate types for epoch transitions.

mod attestation;
mod certificate;
mod chain;
pub(crate) mod errors;
mod record;

pub use attestation::HandoverAttestation;
pub use certificate::{HandoverCertificate, HandoverCertificateAddAttestationError};
pub use chain::HandoverChain;
pub use errors::HandoverChainError;
pub use record::HandoverRecord;

#[cfg(test)]
mod tests;
