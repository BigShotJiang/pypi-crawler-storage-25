// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Snapshot record, attestation, submission, and certificate types.

mod certificate;
mod record;
mod submission;

pub use certificate::{SnapshotCertificate, SnapshotCertificateAddAttestationError};
pub use record::{SnapshotAttestation, SnapshotRecord};
pub use submission::{SnapshotAttestationSubmission, SnapshotAttestationSubmissionError};

#[cfg(test)]
mod tests;
