// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! [`HandoverCertificate`] — type alias for [`Certificate<HandoverRecord>`] with
//! convenience accessors.

use super::{
    super::attestation_framework::{Certificate, CertificateAddAttestationError},
    record::HandoverRecord,
};

/// Quorum-certified epoch transition — alias to the generic certificate framework.
pub type HandoverCertificate = Certificate<HandoverRecord>;

/// Error type alias kept for backward-compatible ergonomics in the `handover` module.
pub type HandoverCertificateAddAttestationError = CertificateAddAttestationError;

impl Certificate<HandoverRecord> {
    /// The attested handover record (convenience wrapper around [`Certificate::record`]).
    #[inline]
    pub fn handover_record(&self) -> &HandoverRecord {
        self.record()
    }

    /// `true` iff this certificate's [`HandoverRecord`] is the canonical genesis shape (see
    /// [`HandoverRecord::is_genesis`]).
    ///
    /// This does **not** check attestations; use [`Certificate::is_complete`] for quorum.
    pub fn is_genesis(&self) -> bool {
        self.record().is_genesis()
    }
}
