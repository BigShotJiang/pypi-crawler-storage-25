// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Error types for the attestation framework.

use thiserror::Error;

// ---------------------------------------------------------------------------
// Attestation errors
// ---------------------------------------------------------------------------

/// Errors from [`Attestation::sign`](super::Attestation::sign) and
/// [`Attestation::verify_internal_consistency`](super::Attestation::verify_internal_consistency).
#[derive(Debug, Copy, Clone, PartialEq, Eq, Error)]
pub enum AttestationError {
    /// Post-sign self-verification failed (corrupted keypair or signing bug).
    #[error("{attest_type}Attestation self-verification failed")]
    SelfVerificationFailed {
        /// Same as [`AttestableRecord::TYPE_NAME`](super::AttestableRecord::TYPE_NAME) for the record type (e.g. `"Snapshot"`).
        attest_type: &'static str,
    },
    /// Ed25519 verify failed for the embedded `protocol_key` and signature.
    #[error("{attest_type}Attestation signature verification failed")]
    SignatureVerificationFailed { attest_type: &'static str },
    /// `signature` bytes are not a valid Ed25519 encoding.
    #[error("{attest_type}Attestation invalid signature bytes")]
    MalformedSignature { attest_type: &'static str },
}

impl AttestationError {
    /// [`AttestableRecord::TYPE_NAME`](super::AttestableRecord::TYPE_NAME) for the attestation's record type.
    pub fn attest_type(&self) -> &'static str {
        match self {
            AttestationError::SelfVerificationFailed { attest_type }
            | AttestationError::SignatureVerificationFailed { attest_type }
            | AttestationError::MalformedSignature { attest_type } => attest_type,
        }
    }
}

// ---------------------------------------------------------------------------
// Certificate–attestation consistency errors
// ---------------------------------------------------------------------------

/// Error when an attestation's embedded digest does not match the certificate record digest.
///
/// Returned by [`validate_attestation_consistency`](super::validate_attestation_consistency).
/// Certificate types that aggregate [`Attestation`](super::Attestation) values should expose a
/// `validate_attestation_consistency` method that delegates to that helper and propagates this
/// error.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum CertificateAttestationConsistencyError {
    /// At least one attestation carries a different `record_digest` than the certificate's record.
    #[error("{cert_type} contains attestation with mismatched record_digest")]
    MismatchedRecordDigest { cert_type: &'static str },
}
