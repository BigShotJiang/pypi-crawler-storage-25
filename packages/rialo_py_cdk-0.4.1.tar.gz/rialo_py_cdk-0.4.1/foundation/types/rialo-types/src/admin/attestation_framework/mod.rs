// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Generic attestation framework: sealed traits, macro, [`Attestation<R>`], [`Certificate<R>`] for
//! committee-attested records, and helpers.

pub(crate) mod errors;

#[macro_use]
pub(crate) mod record;
mod attestation;
mod certificate;

pub use attestation::*;
pub use certificate::*;
pub use errors::*;
pub use record::*;

#[cfg(test)]
mod tests;

#[cfg(test)]
mod certificate_tests;

/// Validates that every attestation in `attestations` binds to `expected_digest`.
///
/// This is the shared implementation backing each certificate type's
/// `validate_attestation_consistency()` method. `cert_type_name` identifies the certificate in
/// `CertificateAttestationConsistencyError`.
///
/// # Tests
///
/// Covered directly by `validate_attestation_consistency_*` unit tests in this module
/// (empty slice, single attestation, mismatched digest, mixed digests, multiple matching).
pub fn validate_attestation_consistency<R: AttestableRecord>(
    expected_digest: &RecordDigest,
    attestations: &[Attestation<R>],
    cert_type_name: &'static str,
) -> Result<(), CertificateAttestationConsistencyError> {
    if attestations
        .iter()
        .all(|a| a.record_digest() == expected_digest)
    {
        Ok(())
    } else {
        Err(
            CertificateAttestationConsistencyError::MismatchedRecordDigest {
                cert_type: cert_type_name,
            },
        )
    }
}

// ---------------------------------------------------------------------------
// Attestation threshold
// ---------------------------------------------------------------------------

/// Numerator of the attestation stake floor; pair with [`ATTESTATION_THRESHOLD_DENOMINATOR`].
///
/// # Why f+1-style overlap, not 2f+1 consensus quorum?
///
/// Attestations confirm **deterministic execution** of **already committed** consensus
/// input. Every correct node runs the same committed work and, because execution is
/// deterministic, produces identical results. A **f+1**-style overlap—strictly **more
/// than one third** of stake—is enough that at least one honest validator is represented,
/// which suffices to vouch for the unique correct output. Two conflicting values cannot
/// both exceed that threshold among honest nodes.
///
/// **2f+1** (two-thirds **plus one**) is the usual **Byzantine agreement** / commit quorum:
/// validators must agree *before* execution commits. Attestations are not on that path;
/// they only ratify a deterministic consequence, so the weaker floor below is deliberate
/// and **not** interchangeable with consensus arithmetic such as `2 * total / 3 + 1` on
/// stake.
///
/// # How that policy is encoded
///
/// "Strictly more than **f** of **n**" in an n = 3f+1-style story is expressed as a
/// **1/3** floor on total stake via this numerator and [`ATTESTATION_THRESHOLD_DENOMINATOR`]:
/// [`attestation_threshold`] computes `⌊total × numerator ÷ denominator⌋`, and callers
/// require **strictly greater** support (e.g. `count > attestation_threshold(total)`).
/// A **2f+1**-style line would be **2/3** (numerator 2, denominator 3); this module
/// intentionally does **not** use that for attestations.
pub const ATTESTATION_THRESHOLD_NUMERATOR: u64 = 1;

/// Denominator of the attestation stake floor; see [`ATTESTATION_THRESHOLD_NUMERATOR`].
pub const ATTESTATION_THRESHOLD_DENOMINATOR: u64 = 3;

/// Largest stake count that is still **below** the attestation policy threshold.
///
/// Computes  
/// `⌊total ÷ [`ATTESTATION_THRESHOLD_DENOMINATOR`] × [`ATTESTATION_THRESHOLD_NUMERATOR`]⌋`  
/// using integer division (divide first, then multiply) to avoid overflow when `total` is
/// close to `u64::MAX`.
///
/// Validators (or stake-weighted support) must **exceed** this value—e.g.
/// `support > attestation_threshold(total)`—to meet the policy described on
/// [`ATTESTATION_THRESHOLD_NUMERATOR`].
///
/// # Panics
///
/// Panics if `total == 0`.
pub const fn attestation_threshold(total: u64) -> u64 {
    assert!(total > 0, "committee cannot be empty");
    total / ATTESTATION_THRESHOLD_DENOMINATOR * ATTESTATION_THRESHOLD_NUMERATOR
}
