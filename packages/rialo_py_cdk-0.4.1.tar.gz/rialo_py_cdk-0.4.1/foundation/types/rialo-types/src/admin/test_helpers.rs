// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use crate::consensus_crypto::{AuthorityPublicKey, NetworkPublicKey, ProtocolPublicKey};

pub(crate) mod test_keys {
    use fastcrypto::{ed25519, traits::KeyPair};
    use rand::SeedableRng;

    use super::*;

    /// Helper to create test keys with a given seed for deterministic tests.
    pub(crate) fn create_test_keys(
        seed: u64,
    ) -> (AuthorityPublicKey, ProtocolPublicKey, NetworkPublicKey) {
        let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
        let authority_key = AuthorityPublicKey::new(
            fastcrypto::bls12381::min_sig::BLS12381KeyPair::generate(&mut rng)
                .public()
                .clone(),
        );
        let protocol_key =
            ProtocolPublicKey::new(ed25519::Ed25519KeyPair::generate(&mut rng).public().clone());
        let network_key =
            NetworkPublicKey::new(ed25519::Ed25519KeyPair::generate(&mut rng).public().clone());
        (authority_key, protocol_key, network_key)
    }

    pub(crate) fn create_test_keys_with_keypair(
        seed: u64,
    ) -> (AuthorityPublicKey, crate::ProtocolKeyPair, NetworkPublicKey) {
        let mut rng = rand::rngs::StdRng::seed_from_u64(seed);
        let authority_key = AuthorityPublicKey::new(
            fastcrypto::bls12381::min_sig::BLS12381KeyPair::generate(&mut rng)
                .public()
                .clone(),
        );
        let protocol_keypair =
            crate::ProtocolKeyPair::new(ed25519::Ed25519KeyPair::generate(&mut rng));
        let network_key =
            NetworkPublicKey::new(ed25519::Ed25519KeyPair::generate(&mut rng).public().clone());
        (authority_key, protocol_keypair, network_key)
    }
}

pub(crate) mod test_records {
    use crate::admin::{
        epoch::{EpochChangeConfig, EpochIdentifier},
        handover::HandoverRecord,
        snapshot::SnapshotRecord,
    };

    pub(crate) fn create_test_handover_record(
        block_index: u64,
        source: u64,
        dest: u64,
        previous_hash: crate::admin::Blake3Hash,
    ) -> HandoverRecord {
        HandoverRecord::new(
            block_index,
            EpochIdentifier::new(source),
            EpochIdentifier::new(dest),
            EpochChangeConfig {
                current_epoch: EpochIdentifier::new(source),
                new_epoch: EpochIdentifier::new(dest),
                validators: vec![],
                consensus_config: None,
            },
            previous_hash,
        )
    }

    pub(crate) fn create_test_snapshot_record(block_height: u64, epoch: u64) -> SnapshotRecord {
        SnapshotRecord::new(block_height, EpochIdentifier::new(epoch), [0xABu8; 32])
    }
}
