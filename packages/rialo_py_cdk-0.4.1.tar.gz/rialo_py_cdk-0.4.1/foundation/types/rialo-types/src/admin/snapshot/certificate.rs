// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! [`SnapshotCertificate`] — type alias for [`Certificate<SnapshotRecord>`] with
//! convenience accessors.

use super::{
    super::attestation_framework::{Certificate, CertificateAddAttestationError},
    record::SnapshotRecord,
};

/// Quorum-certified snapshot — alias to the generic certificate framework.
pub type SnapshotCertificate = Certificate<SnapshotRecord>;

/// Error type alias kept for backward-compatible ergonomics in the `snapshot` module.
pub type SnapshotCertificateAddAttestationError = CertificateAddAttestationError;

impl Certificate<SnapshotRecord> {
    /// The attested snapshot record (convenience wrapper around [`Certificate::record`]).
    #[inline]
    pub fn snapshot_record(&self) -> &SnapshotRecord {
        self.record()
    }
}
