// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! [`Certificate<R>`]: quorum-certified wrapper, attestation consistency, and threshold.

// `BTreeSet<Attestation<R>>` triggers this because `AuthorityPublicKey` (BLS12-381) contains
// an `OnceCell` cache. Our `Ord` impl compares the stable serialized bytes, so the interior
// mutability does not affect key ordering.
#![allow(clippy::mutable_key_type)]

use std::collections::BTreeSet;

use serde::{de::DeserializeOwned, Deserialize, Serialize};
use thiserror::Error;
use tracing::warn;

use super::{
    super::{
        epoch::EpochIdentifier,
        handover::{HandoverCertificate, HandoverChain, HandoverChainError, HandoverRecord},
        RecordDigest,
    },
    attestation_threshold,
    errors::{AttestationError, CertificateAttestationConsistencyError},
    record::{AttestableRecord, CommitteeAttestedRecord},
    Attestation,
};

/// Validates that every attestation in `attestations` binds to `expected_digest`.
fn validate_attestation_consistency<'a, R: AttestableRecord + 'a>(
    expected_digest: &RecordDigest,
    mut attestations: impl Iterator<Item = &'a Attestation<R>>,
    cert_type_name: &'static str,
) -> Result<(), CertificateAttestationConsistencyError> {
    if attestations.all(|a| a.record_digest() == expected_digest) {
        Ok(())
    } else {
        Err(
            CertificateAttestationConsistencyError::MismatchedRecordDigest {
                cert_type: cert_type_name,
            },
        )
    }
}

// ---------------------------------------------------------------------------
// Certificate errors
// ---------------------------------------------------------------------------

/// Errors when appending an attestation to [`Certificate`] (`add_attestation`).
///
/// Committee context comes from [`HandoverChain`] (via [`HandoverChain::certificate_for_epoch`]),
/// not from a caller-supplied [`HandoverRecord`].
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum CertificateAddAttestationError {
    /// Ed25519 / embedded-key consistency check failed (see [`Attestation::verify_internal_consistency`]).
    #[error("attestation is not internally consistent: {0}")]
    InvalidAttestation(#[from] AttestationError),
    /// Attestation's signed digest does not match this certificate's record.
    #[error("attestation record_digest does not match certificate record")]
    WrongDigest,
    /// No certificate in `chain` whose [`HandoverRecord::dest_epoch`] equals the record's epoch.
    #[error("no handover certificate in chain for epoch {0}")]
    MissingEpochInChain(EpochIdentifier),
    /// Record `block_height` is before the handover that opens this epoch.
    #[error("record block_height is before the handover that opens this epoch")]
    BlockBeforeEpochStart,
    /// Record `block_height` exceeds the next epoch's handover `block_index`.
    ///
    /// The handover block itself is the last block under the previous epoch's purview,
    /// so `block_height` must be `<= next_epoch_start_block`.
    #[error("record block_height {block_height} must be <= next epoch handover block_index {next_epoch_start_block}")]
    BlockAfterNextEpochHandover {
        block_height: u64,
        next_epoch_start_block: u64,
    },
    /// Signer's authority key is not in the committee from the opening handover.
    #[error("signer authority_key is not in epoch committee")]
    InvalidAttestor,
    /// Attestation's protocol key does not match the committee-registered key for that authority.
    #[error("attestation protocol_key does not match committee-registered protocol key")]
    ProtocolKeyMismatch,
    /// Same validator authority key already present in this certificate.
    #[error("duplicate attestation for this authority_key")]
    DuplicateAttestation,
    /// The [`HandoverChain`] failed validation.
    #[error("handover chain validation failed: {0}")]
    InvalidChain(#[from] HandoverChainError),
}

// ---------------------------------------------------------------------------
// Certificate<R>
// ---------------------------------------------------------------------------

/// Quorum-certified wrapper around a [`CommitteeAttestedRecord`].
///
/// Produced when stake above [`attestation_threshold`] attests to the same `record` (matching
/// `record_digest`). The verifier looks up the committee for the certificate's epoch via the
/// handover chain — the certificate does not embed the committee.
///
/// # Genesis quorum policy
///
/// At **block height 0** (the genesis bootstrap), [`is_complete`](Self::is_complete) requires
/// **unanimous attestation** from every committee member, not just the f+1 stake threshold.
/// This ensures the network cannot start with a partially-attested genesis state. Once the
/// chain advances past block 0, the standard [`attestation_threshold`]-based quorum applies.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
#[serde(bound(serialize = "R: Serialize", deserialize = "R: DeserializeOwned"))]
pub struct Certificate<R: CommitteeAttestedRecord> {
    /// The attested record (contains the epoch for committee lookup).
    ///
    /// Deserialization accepts legacy field names for backward compatibility.
    #[serde(
        alias = "snapshot_record",
        alias = "write_set_record",
        alias = "ordered_block_record",
        alias = "handover_record"
    )]
    record: R,

    /// Stake-weighted attestations over [`Self::record`], ordered by authority key
    /// (see [`Attestation`]'s [`Ord`] impl).
    attestations: BTreeSet<Attestation<R>>,
}

impl<R: CommitteeAttestedRecord> Certificate<R> {
    /// Creates a new certificate with no attestations. Use [`Self::add_attestation`] when a
    /// [`HandoverChain`] is available.
    pub fn new(record: R) -> Self {
        Self {
            record,
            attestations: BTreeSet::new(),
        }
    }

    /// Builds a certificate with attestations the caller has already validated (e.g. aggregated by
    /// a tracker that enforced quorum outside [`HandoverChain`] checks). Prefer [`Self::new`] plus
    /// [`Self::add_attestation`] when chain validation applies.
    #[cfg(test)]
    pub(crate) fn from_record_and_attestations(
        record: R,
        attestations: impl IntoIterator<Item = Attestation<R>>,
    ) -> Self {
        Self {
            record,
            attestations: attestations.into_iter().collect(),
        }
    }

    /// The attested record.
    #[inline]
    pub fn record(&self) -> &R {
        &self.record
    }

    /// Attestations over [`Self::record`], ordered by authority key.
    #[inline]
    pub fn attestations(&self) -> &BTreeSet<Attestation<R>> {
        &self.attestations
    }

    /// Block height from the attested record (delegates to [`CommitteeAttestedRecord::attested_block_height`]).
    #[inline]
    pub fn block_index(&self) -> u64 {
        self.record.attested_block_height()
    }

    /// Validates that every attestation binds to this certificate's record.
    pub fn validate_attestation_consistency(
        &self,
    ) -> Result<(), CertificateAttestationConsistencyError> {
        validate_attestation_consistency(
            &self.record.record_digest(),
            self.attestations.iter(),
            R::CERTIFICATE_TYPE_NAME,
        )
    }

    fn opening_certificate<'a>(
        &self,
        chain: &'a HandoverChain,
    ) -> Result<Option<&'a HandoverCertificate>, HandoverChainError> {
        chain.certificate_for_epoch(self.record.attesting_epoch())
    }

    fn ensure_epoch_scope(
        &self,
        chain: &HandoverChain,
        opening: &HandoverCertificate,
    ) -> Result<(), CertificateAddAttestationError> {
        let hr = opening.handover_record();
        let bh = self.record.attested_block_height();
        if bh < hr.block_index() {
            return Err(CertificateAddAttestationError::BlockBeforeEpochStart);
        }

        let epoch = self.record.attesting_epoch();
        if let Some(next_n) = epoch.as_u64().checked_add(1) {
            let next_epoch = EpochIdentifier::new(next_n);
            if let Some(next_cert) = chain.certificate_for_epoch(next_epoch)? {
                let next_start = next_cert.handover_record().block_index();
                if bh > next_start {
                    return Err(
                        CertificateAddAttestationError::BlockAfterNextEpochHandover {
                            block_height: bh,
                            next_epoch_start_block: next_start,
                        },
                    );
                }
            }
        }
        Ok(())
    }

    pub(crate) fn add_attestation_for_committee_record(
        &mut self,
        attestation: Attestation<R>,
        committee_source: &HandoverRecord,
    ) -> Result<(), CertificateAddAttestationError> {
        attestation.verify_internal_consistency()?;
        if *attestation.record_digest() != self.record.record_digest() {
            return Err(CertificateAddAttestationError::WrongDigest);
        }
        let Some(signer) = committee_source
            .epoch_config()
            .validators
            .iter()
            .find(|v| v.authority_key == *attestation.authority_key())
        else {
            return Err(CertificateAddAttestationError::InvalidAttestor);
        };
        if signer.protocol_key != *attestation.protocol_key() {
            return Err(CertificateAddAttestationError::ProtocolKeyMismatch);
        }
        if self
            .attestations
            .iter()
            .any(|a| *a.authority_key() == *attestation.authority_key())
        {
            return Err(CertificateAddAttestationError::DuplicateAttestation);
        }
        self.attestations.insert(attestation);
        Ok(())
    }

    /// Inserts an attestation after validating against `chain` (opening epoch + block window) and
    /// committee membership from [`HandoverChain::certificate_for_epoch`] on the record's epoch.
    ///
    /// Rejects duplicate authority keys. The [`BTreeSet`] maintains sorted order automatically.
    pub fn add_attestation(
        &mut self,
        attestation: Attestation<R>,
        chain: &HandoverChain,
    ) -> Result<(), CertificateAddAttestationError> {
        let opening = self.opening_certificate(chain)?.ok_or(
            CertificateAddAttestationError::MissingEpochInChain(self.record.attesting_epoch()),
        )?;
        self.ensure_epoch_scope(chain, opening)?;
        self.add_attestation_for_committee_record(attestation, opening.handover_record())
    }

    /// Stake-weighted quorum: true iff attested stake from the opening handover's committee is
    /// **strictly greater** than [`attestation_threshold`] on total stake, and the record's block
    /// height is in the epoch window (see [`Self::add_attestation`]).
    ///
    /// **Genesis exception (block height 0):** returns `true` only when *every* validator in
    /// the committee has attested, regardless of individual stake. This unanimous requirement
    /// prevents the network from bootstrapping on a partially-confirmed genesis state.
    pub fn is_complete(&self, chain: &HandoverChain) -> bool {
        let opening = match self.opening_certificate(chain) {
            Ok(Some(o)) => o,
            Ok(None) => return false,
            Err(e) => {
                warn!(
                    error = %e,
                    cert_type = R::CERTIFICATE_TYPE_NAME,
                    "Certificate::is_complete: chain validation failed",
                );
                return false;
            }
        };
        if let Err(e) = self.ensure_epoch_scope(chain, opening) {
            warn!(
                error = %e,
                cert_type = R::CERTIFICATE_TYPE_NAME,
                epoch = self.record().attesting_epoch().as_u64(),
                block_height = self.record().attested_block_height(),
                "Certificate::is_complete: epoch scope validation failed",
            );
            return false;
        }
        self.is_complete_against_committee_record(opening.handover_record())
    }

    /// Inner completeness check against a specific committee record.
    ///
    /// **Genesis (block height 0):** requires every validator to have attested (unanimous).
    /// **Post-genesis:** requires attested stake > [`attestation_threshold`](total_stake).
    pub(crate) fn is_complete_against_committee_record(&self, committee: &HandoverRecord) -> bool {
        let validators = &committee.epoch_config().validators;
        let Some(total_stake) = validators
            .iter()
            .try_fold(0u64, |acc, v| acc.checked_add(v.stake))
        else {
            warn!(
                validator_count = validators.len(),
                cert_type = R::CERTIFICATE_TYPE_NAME,
                "Certificate::is_complete: committee total stake overflowed u64",
            );
            return false;
        };
        if total_stake == 0 {
            return false;
        }
        let attesting_keys: BTreeSet<_> = self
            .attestations
            .iter()
            .map(|a| a.authority_key())
            .collect();
        if self.record.attested_block_height() == 0 {
            return validators
                .iter()
                .all(|v| attesting_keys.contains(&v.authority_key));
        }
        let threshold = attestation_threshold(total_stake);
        let attested: u64 = validators
            .iter()
            .filter(|v| attesting_keys.contains(&v.authority_key))
            .fold(0u64, |acc, v| acc.saturating_add(v.stake));
        attested > threshold
    }
}
