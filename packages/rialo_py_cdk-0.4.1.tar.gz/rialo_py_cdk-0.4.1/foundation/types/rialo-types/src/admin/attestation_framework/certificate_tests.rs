// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use rialo_s_pubkey::Pubkey;

use super::{
    super::{
        epoch::{EpochChangeConfig, EpochIdentifier, ValidatorInfo},
        handover::{HandoverChain, HandoverRecord},
        test_helpers::test_keys::*,
        BLAKE3_HASH_SIZE,
    },
    tests::TestRecord,
    *,
};

type TestCert = Certificate<TestRecord>;

fn test_validator(seed: u64, stake: u64) -> (ValidatorInfo, crate::ProtocolKeyPair) {
    let (authority_key, protocol_keypair, network_key) = create_test_keys_with_keypair(seed);
    let protocol_key = protocol_keypair.public();
    (
        ValidatorInfo {
            stake,
            consensus_address: "/ip4/127.0.0.1/udp/10100".parse().unwrap(),
            state_sync_address: "/ip4/127.0.0.1/udp/20100".parse().unwrap(),
            hostname: format!("v-{seed}"),
            authority_key,
            protocol_key,
            network_key,
            signing_key: Pubkey::new_unique(),
        },
        protocol_keypair,
    )
}

fn test_genesis() -> HandoverRecord {
    HandoverRecord::genesis(
        EpochIdentifier::new(0),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(0),
            validators: vec![],
            consensus_config: None,
        },
    )
}

fn handover_opening_epoch_1_at(
    block_index: u64,
    previous_hash: super::super::Blake3Hash,
) -> HandoverRecord {
    let (v0, _kp0) = test_validator(3100, 10);
    let (v1, _kp1) = test_validator(3101, 10);
    let (v2, _kp2) = test_validator(3102, 10);
    HandoverRecord::new(
        block_index,
        EpochIdentifier::new(0),
        EpochIdentifier::new(1),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(1),
            validators: vec![v0, v1, v2],
            consensus_config: None,
        },
        previous_hash,
    )
}

fn chain_genesis_and_epoch1_opening_at(opening_block: u64) -> HandoverChain {
    let genesis = test_genesis();
    let genesis_hash = genesis.record_digest();
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis).unwrap();
    chain
        .insert_next_handover(handover_opening_epoch_1_at(opening_block, genesis_hash))
        .unwrap();
    chain
}

fn chain_with_epoch2_after_epoch1(
    e1_opening_block: u64,
    epoch2_opening_block: u64,
) -> HandoverChain {
    let mut chain = chain_genesis_and_epoch1_opening_at(e1_opening_block);
    let prev_hash = chain.last().unwrap().handover_record().record_digest();
    let (v0, _kp0) = test_validator(4000, 10);
    let epoch2 = HandoverRecord::new(
        epoch2_opening_block,
        EpochIdentifier::new(1),
        EpochIdentifier::new(2),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(1),
            new_epoch: EpochIdentifier::new(2),
            validators: vec![v0],
            consensus_config: None,
        },
        prev_hash,
    );
    chain.insert_next_handover(epoch2).unwrap();
    chain
}

fn record_at(epoch: u64, block_height: u64) -> TestRecord {
    TestRecord::new(7, 42, epoch, block_height)
}

#[test]
fn certificate_new_and_accessors() {
    let r = record_at(1, 150);
    let c = TestCert::new(r.clone());
    assert_eq!(*c.record(), r);
    assert!(c.attestations().is_empty());
    assert_eq!(c.block_index(), 150);
}

#[test]
fn certificate_from_record_and_attestations_sorts_by_authority_key() {
    let r = record_at(1, 150);
    let (a1, k1, _) = create_test_keys_with_keypair(9001);
    let (a2, k2, _) = create_test_keys_with_keypair(9002);
    // Intentionally sign in reverse lexicographic order of authority keys
    let att2 = Attestation::<TestRecord>::sign(&r, &k2, &a2).unwrap();
    let att1 = Attestation::<TestRecord>::sign(&r, &k1, &a1).unwrap();
    let c = TestCert::from_record_and_attestations(r, vec![att2, att1]);
    let keys: Vec<_> = c
        .attestations()
        .iter()
        .map(|a| a.authority_key().to_bytes())
        .collect();
    let mut sorted = keys.clone();
    sorted.sort();
    assert_eq!(keys, sorted);
}

#[test]
fn certificate_validate_attestation_consistency_ok_and_mismatch() {
    let r = record_at(1, 150);
    let (a1, k1, _) = create_test_keys_with_keypair(9010);
    let (a2, k2, _) = create_test_keys_with_keypair(9011);
    let att1 = Attestation::<TestRecord>::sign(&r, &k1, &a1).unwrap();
    let att2 = Attestation::<TestRecord>::sign(&r, &k2, &a2).unwrap();
    let c = TestCert::from_record_and_attestations(r.clone(), vec![att1, att2]);
    assert!(c.validate_attestation_consistency().is_ok());

    let other = record_at(1, 999);
    let bad = Attestation::<TestRecord>::sign(&other, &k2, &a2).unwrap();
    let c_bad = TestCert::from_record_and_attestations(r, vec![bad]);
    assert_eq!(
        c_bad.validate_attestation_consistency().unwrap_err(),
        CertificateAttestationConsistencyError::MismatchedRecordDigest {
            cert_type: "TestCertificate",
        }
    );
}

#[test]
fn certificate_serde_json_roundtrip() {
    let r = record_at(1, 150);
    let (a1, k1, _) = create_test_keys_with_keypair(9020);
    let att = Attestation::<TestRecord>::sign(&r, &k1, &a1).unwrap();
    let c = TestCert::from_record_and_attestations(r.clone(), vec![att]);
    let s = serde_json::to_string(&c).unwrap();
    let d: TestCert = serde_json::from_str(&s).unwrap();
    assert_eq!(*d.record(), *c.record());
    assert_eq!(d.attestations().len(), 1);
    assert!(d.validate_attestation_consistency().is_ok());
}

#[test]
fn certificate_add_attestation_success() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 2, 1, 150);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert!(c.add_attestation(att, &chain).is_ok());
    assert_eq!(c.attestations().len(), 1);
}

#[test]
fn certificate_add_attestation_missing_epoch_in_chain() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 2, 2, 150);
    let (a, k, _) = create_test_keys_with_keypair(9030);
    let att = Attestation::<TestRecord>::sign(&r, &k, &a).unwrap();
    let mut c = TestCert::new(r);
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::MissingEpochInChain(EpochIdentifier::new(2)),
    );
}

#[test]
fn certificate_add_attestation_block_before_epoch_start() {
    let chain = chain_genesis_and_epoch1_opening_at(200);
    let r = TestRecord::new(3, 4, 1, 199);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::BlockBeforeEpochStart,
    );
}

#[test]
fn certificate_add_attestation_block_after_next_epoch() {
    let chain = chain_with_epoch2_after_epoch1(100, 500);
    // Block at the handover boundary (500) is still within epoch 1's scope.
    let r_at_boundary = TestRecord::new(5, 6, 1, 500);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r_at_boundary, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r_at_boundary);
    assert!(
        c.add_attestation(att, &chain).is_ok(),
        "the handover block is the last responsibility of the old epoch"
    );

    // Block strictly past the handover is rejected.
    let r_past = TestRecord::new(5, 6, 1, 501);
    let att_past = Attestation::<TestRecord>::sign(&r_past, &kp0, &v0.authority_key).unwrap();
    let mut c_past = TestCert::new(r_past);
    assert_eq!(
        c_past.add_attestation(att_past, &chain).unwrap_err(),
        CertificateAddAttestationError::BlockAfterNextEpochHandover {
            block_height: 501,
            next_epoch_start_block: 500,
        },
    );
}

#[test]
fn certificate_add_attestation_wrong_digest() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r_cert = TestRecord::new(1, 1, 1, 150);
    let r_signed = TestRecord::new(2, 2, 1, 150);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r_signed, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r_cert);
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::WrongDigest,
    );
}

#[test]
fn certificate_add_attestation_invalid_attestation_bad_signature() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 150);
    let (v0, kp0) = test_validator(3100, 10);
    let mut att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    att.tamper_signature(0, 0xFF);
    let mut c = TestCert::new(r);
    assert!(matches!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::InvalidAttestation(_),
    ));
}

#[test]
fn certificate_add_attestation_invalid_attestor() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 150);
    let (outsider_kp, outsider_auth) = {
        let (a, k, _) = create_test_keys_with_keypair(9040);
        (k, a)
    };
    let att = Attestation::<TestRecord>::sign(&r, &outsider_kp, &outsider_auth).unwrap();
    let mut c = TestCert::new(r);
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::InvalidAttestor,
    );
}

#[test]
fn certificate_add_attestation_protocol_key_mismatch() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 150);
    let (v0, _kp0) = test_validator(3100, 10);
    let (_, wrong_signing_kp, _) = create_test_keys_with_keypair(9041);
    let att = Attestation::<TestRecord>::sign(&r, &wrong_signing_kp, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::ProtocolKeyMismatch,
    );
}

#[test]
fn certificate_add_attestation_duplicate_authority() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 150);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    c.add_attestation(att.clone(), &chain).unwrap();
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::DuplicateAttestation,
    );
}

#[test]
fn certificate_is_complete_stake_threshold() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 150);
    let (v0, kp0) = test_validator(3100, 10);
    let (v1, kp1) = test_validator(3101, 10);
    let (v2, kp2) = test_validator(3102, 10);
    let a0 = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let a1 = Attestation::<TestRecord>::sign(&r, &kp1, &v1.authority_key).unwrap();
    let mut c_two = TestCert::new(r.clone());
    c_two.add_attestation(a0, &chain).unwrap();
    c_two.add_attestation(a1, &chain).unwrap();
    assert!(c_two.is_complete(&chain));

    let a2 = Attestation::<TestRecord>::sign(&r, &kp2, &v2.authority_key).unwrap();
    let mut c_one = TestCert::new(r);
    c_one.add_attestation(a2, &chain).unwrap();
    assert!(!c_one.is_complete(&chain));
}

#[test]
fn certificate_is_complete_false_when_scope_invalid() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 50);
    let (v0, kp0) = test_validator(3100, 10);
    let (v1, kp1) = test_validator(3101, 10);
    let (v2, kp2) = test_validator(3102, 10);
    let a0 = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let a1 = Attestation::<TestRecord>::sign(&r, &kp1, &v1.authority_key).unwrap();
    let a2 = Attestation::<TestRecord>::sign(&r, &kp2, &v2.authority_key).unwrap();
    let c = TestCert::from_record_and_attestations(r, vec![a0, a1, a2]);
    assert!(
        !c.is_complete(&chain),
        "height before epoch-1 opening must not complete",
    );
}

#[test]
fn certificate_is_complete_false_when_committee_stake_overflows_u64() {
    let (v0, kp0) = test_validator(3200, u64::MAX);
    let (v1, kp1) = test_validator(3201, 1u64);
    let r = TestRecord::new(1, 1, 1, 150);
    let a0 = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let a1 = Attestation::<TestRecord>::sign(&r, &kp1, &v1.authority_key).unwrap();
    let genesis = test_genesis();
    let genesis_hash = genesis.record_digest();
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis).unwrap();
    chain
        .insert_next_handover(HandoverRecord::new(
            100,
            EpochIdentifier::new(0),
            EpochIdentifier::new(1),
            EpochChangeConfig {
                current_epoch: EpochIdentifier::new(0),
                new_epoch: EpochIdentifier::new(1),
                validators: vec![v0, v1],
                consensus_config: None,
            },
            genesis_hash,
        ))
        .unwrap();

    let mut c = TestCert::new(r);
    c.add_attestation(a0, &chain).unwrap();
    c.add_attestation(a1, &chain).unwrap();
    assert!(!c.is_complete(&chain));
}

#[test]
fn certificate_is_complete_false_when_opening_epoch_missing() {
    let chain = HandoverChain::new();
    let r = TestRecord::new(1, 1, 1, 150);
    let (a, k, _) = create_test_keys_with_keypair(9050);
    let att = Attestation::<TestRecord>::sign(&r, &k, &a).unwrap();
    let c = TestCert::from_record_and_attestations(r, vec![att]);
    assert!(!c.is_complete(&chain));
}

#[test]
fn test_record_digest_changes_with_epoch_and_block_height() {
    let a = TestRecord::new(1, 2, 0, 0);
    let b = TestRecord::new(1, 2, 1, 0);
    let c = TestRecord::new(1, 2, 0, 99);
    assert_ne!(a.record_digest(), b.record_digest());
    assert_ne!(a.record_digest(), c.record_digest());
}

// -----------------------------------------------------------------------
// Epoch boundary: handover block belongs to the old epoch
// -----------------------------------------------------------------------

#[test]
fn certificate_at_handover_block_is_in_old_epoch_scope() {
    let chain = chain_with_epoch2_after_epoch1(100, 500);
    let r = TestRecord::new(1, 1, 1, 500);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert!(c.add_attestation(att, &chain).is_ok());
}

// -----------------------------------------------------------------------
// Certificate<HandoverRecord>: handover through the generic framework
// -----------------------------------------------------------------------

type HandoverCert = Certificate<HandoverRecord>;

#[test]
fn handover_certificate_add_attestation_through_generic_path() {
    let (v0, kp0) = test_validator(5000, 50);
    let (v1, _kp1) = test_validator(5001, 50);
    let genesis_config = EpochChangeConfig {
        current_epoch: EpochIdentifier::new(0),
        new_epoch: EpochIdentifier::new(0),
        validators: vec![v0.clone(), v1],
        consensus_config: None,
    };
    let genesis = HandoverRecord::genesis(EpochIdentifier::new(0), genesis_config);
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis.clone()).unwrap();

    let handover = HandoverRecord::new(
        100,
        EpochIdentifier::new(0),
        EpochIdentifier::new(1),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(1),
            validators: vec![],
            consensus_config: None,
        },
        genesis.record_digest(),
    );
    chain.insert_next_handover(handover.clone()).unwrap();

    let att = Attestation::<HandoverRecord>::sign(&handover, &kp0, &v0.authority_key).unwrap();
    let mut cert = HandoverCert::new(handover);
    assert!(
        cert.add_attestation(att, &chain).is_ok(),
        "handover record at its own block_index must pass generic epoch scope"
    );
    assert_eq!(cert.attestations().len(), 1);
}

#[test]
fn handover_certificate_is_complete_stake_threshold_via_generic() {
    let (v0, kp0) = test_validator(5100, 10);
    let (v1, kp1) = test_validator(5101, 10);
    let (v2, _kp2) = test_validator(5102, 10);
    let genesis_config = EpochChangeConfig {
        current_epoch: EpochIdentifier::new(0),
        new_epoch: EpochIdentifier::new(0),
        validators: vec![v0.clone(), v1.clone(), v2],
        consensus_config: None,
    };
    let genesis = HandoverRecord::genesis(EpochIdentifier::new(0), genesis_config);
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis.clone()).unwrap();

    let handover = HandoverRecord::new(
        200,
        EpochIdentifier::new(0),
        EpochIdentifier::new(1),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(1),
            validators: vec![],
            consensus_config: None,
        },
        genesis.record_digest(),
    );
    chain.insert_next_handover(handover.clone()).unwrap();

    let a0 = Attestation::<HandoverRecord>::sign(&handover, &kp0, &v0.authority_key).unwrap();
    let a1 = Attestation::<HandoverRecord>::sign(&handover, &kp1, &v1.authority_key).unwrap();

    let mut cert = HandoverCert::new(handover);
    cert.add_attestation(a0, &chain).unwrap();
    cert.add_attestation(a1, &chain).unwrap();
    assert!(
        cert.is_complete(&chain),
        "20 stake > attestation_threshold(30) = 10"
    );
}

// -----------------------------------------------------------------------
// Genesis quorum at block 0: all committee members required
// -----------------------------------------------------------------------

#[test]
fn genesis_quorum_requires_all_members_via_block_height_zero() {
    let (v0, kp0) = test_validator(5200, 10);
    let (v1, kp1) = test_validator(5201, 10);
    let (v2, kp2) = test_validator(5202, 10);
    let genesis_config = EpochChangeConfig {
        current_epoch: EpochIdentifier::new(0),
        new_epoch: EpochIdentifier::new(0),
        validators: vec![v0.clone(), v1.clone(), v2.clone()],
        consensus_config: None,
    };
    let genesis = HandoverRecord::genesis(EpochIdentifier::new(0), genesis_config);
    let chain = {
        let mut c = HandoverChain::new();
        c.insert_next_handover(genesis.clone()).unwrap();
        c
    };

    // Two of three: exceeds stake threshold but should NOT be complete at block 0.
    let a0 = Attestation::<HandoverRecord>::sign(&genesis, &kp0, &v0.authority_key).unwrap();
    let a1 = Attestation::<HandoverRecord>::sign(&genesis, &kp1, &v1.authority_key).unwrap();
    let partial = HandoverCert::from_record_and_attestations(genesis.clone(), vec![a0, a1]);
    assert!(
        !partial.is_complete(&chain),
        "block 0 requires all committee members, not just stake threshold"
    );

    // All three: complete.
    let a0 = Attestation::<HandoverRecord>::sign(&genesis, &kp0, &v0.authority_key).unwrap();
    let a1 = Attestation::<HandoverRecord>::sign(&genesis, &kp1, &v1.authority_key).unwrap();
    let a2 = Attestation::<HandoverRecord>::sign(&genesis, &kp2, &v2.authority_key).unwrap();
    let full = HandoverCert::from_record_and_attestations(genesis.clone(), vec![a0, a1, a2]);
    assert!(full.is_complete(&chain));
}

// -----------------------------------------------------------------------
// Block height boundary: exactly at epoch opening
// -----------------------------------------------------------------------

#[test]
fn certificate_add_attestation_at_exactly_epoch_opening_block() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 100);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert!(
        c.add_attestation(att, &chain).is_ok(),
        "block_height exactly at epoch opening block_index must be accepted"
    );
}

#[test]
fn certificate_add_attestation_one_before_epoch_opening_is_rejected() {
    let chain = chain_genesis_and_epoch1_opening_at(100);
    let r = TestRecord::new(1, 1, 1, 99);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::BlockBeforeEpochStart,
    );
}

#[test]
fn certificate_add_attestation_one_past_next_epoch_handover_is_rejected() {
    let chain = chain_with_epoch2_after_epoch1(100, 500);
    let r = TestRecord::new(1, 1, 1, 501);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert_eq!(
        c.add_attestation(att, &chain).unwrap_err(),
        CertificateAddAttestationError::BlockAfterNextEpochHandover {
            block_height: 501,
            next_epoch_start_block: 500,
        },
    );
}

#[test]
fn certificate_add_attestation_at_next_epoch_handover_block_is_accepted() {
    let chain = chain_with_epoch2_after_epoch1(100, 500);
    let r = TestRecord::new(1, 1, 1, 500);
    let (v0, kp0) = test_validator(3100, 10);
    let att = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    assert!(
        c.add_attestation(att, &chain).is_ok(),
        "handover block is the last block under the previous epoch's purview"
    );
}

// -----------------------------------------------------------------------
// Stake threshold boundary: exactly threshold vs threshold + 1
// -----------------------------------------------------------------------

#[test]
fn certificate_is_complete_exactly_at_threshold_is_not_complete() {
    // 3 validators: stake 3, 3, 3. Total=9, threshold=floor(9/3)=3.
    // Attested stake must be strictly > 3. A single validator with stake 3 should NOT complete.
    let (v0, kp0) = test_validator(6000, 3);
    let (v1, _kp1) = test_validator(6001, 3);
    let (v2, _kp2) = test_validator(6002, 3);
    let genesis = test_genesis();
    let genesis_hash = genesis.record_digest();
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis).unwrap();
    chain
        .insert_next_handover(HandoverRecord::new(
            100,
            EpochIdentifier::new(0),
            EpochIdentifier::new(1),
            EpochChangeConfig {
                current_epoch: EpochIdentifier::new(0),
                new_epoch: EpochIdentifier::new(1),
                validators: vec![v0.clone(), v1, v2],
                consensus_config: None,
            },
            genesis_hash,
        ))
        .unwrap();

    let r = TestRecord::new(1, 1, 1, 150);
    let a0 = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let mut c = TestCert::new(r);
    c.add_attestation(a0, &chain).unwrap();
    assert!(
        !c.is_complete(&chain),
        "attested stake 3 == threshold 3: not strictly greater, should not complete"
    );
}

#[test]
fn certificate_is_complete_at_threshold_plus_one() {
    // 3 validators: stake 2, 2, 2. Total=6, threshold=floor(6/3)=2.
    // Two validators: attested stake=4 > threshold=2.
    let (v0, kp0) = test_validator(6100, 2);
    let (v1, kp1) = test_validator(6101, 2);
    let (v2, _kp2) = test_validator(6102, 2);
    let genesis = test_genesis();
    let genesis_hash = genesis.record_digest();
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis).unwrap();
    chain
        .insert_next_handover(HandoverRecord::new(
            100,
            EpochIdentifier::new(0),
            EpochIdentifier::new(1),
            EpochChangeConfig {
                current_epoch: EpochIdentifier::new(0),
                new_epoch: EpochIdentifier::new(1),
                validators: vec![v0.clone(), v1.clone(), v2],
                consensus_config: None,
            },
            genesis_hash,
        ))
        .unwrap();

    let r = TestRecord::new(1, 1, 1, 150);
    let a0 = Attestation::<TestRecord>::sign(&r, &kp0, &v0.authority_key).unwrap();
    let a1 = Attestation::<TestRecord>::sign(&r, &kp1, &v1.authority_key).unwrap();
    let mut c = TestCert::new(r);
    c.add_attestation(a0, &chain).unwrap();
    c.add_attestation(a1, &chain).unwrap();
    assert!(
        c.is_complete(&chain),
        "attested stake 4 > threshold 2: should complete"
    );
}

// -----------------------------------------------------------------------
// previous_handover_hash chain integrity
// -----------------------------------------------------------------------

#[test]
fn previous_handover_hash_forms_linked_chain() {
    let genesis = HandoverRecord::genesis(
        EpochIdentifier::new(0),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(0),
            validators: vec![],
            consensus_config: None,
        },
    );
    let genesis_hash = genesis.record_digest();
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis).unwrap();

    let h1 = HandoverRecord::new(
        100,
        EpochIdentifier::new(0),
        EpochIdentifier::new(1),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(1),
            validators: vec![],
            consensus_config: None,
        },
        genesis_hash,
    );
    let h1_hash = h1.record_digest();
    chain.insert_next_handover(h1).unwrap();

    assert_eq!(
        *chain[1].handover_record().previous_handover_hash(),
        genesis_hash,
        "first transition must back-link to genesis hash"
    );

    let h2 = HandoverRecord::new(
        200,
        EpochIdentifier::new(1),
        EpochIdentifier::new(2),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(1),
            new_epoch: EpochIdentifier::new(2),
            validators: vec![],
            consensus_config: None,
        },
        h1_hash,
    );
    chain.insert_next_handover(h2).unwrap();

    assert_eq!(
        *chain[2].handover_record().previous_handover_hash(),
        h1_hash,
        "second transition must back-link to first transition hash"
    );

    // Verify genesis has zero previous hash
    assert_eq!(
        *chain[0].handover_record().previous_handover_hash(),
        [0u8; BLAKE3_HASH_SIZE],
        "genesis previous_handover_hash must be all zeros"
    );
}

#[test]
fn insert_next_handover_rejects_wrong_previous_hash() {
    use super::super::handover::HandoverChainError;

    let genesis = test_genesis();
    let mut chain = HandoverChain::new();
    chain.insert_next_handover(genesis).unwrap();

    let bad_record = HandoverRecord::new(
        100,
        EpochIdentifier::new(0),
        EpochIdentifier::new(1),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(1),
            validators: vec![],
            consensus_config: None,
        },
        [0xFFu8; BLAKE3_HASH_SIZE],
    );
    assert!(matches!(
        chain.insert_next_handover(bad_record).unwrap_err(),
        HandoverChainError::PreviousHashMismatch { .. }
    ));
}

// -----------------------------------------------------------------------
// Intent prefix sync with shared-crypto
// -----------------------------------------------------------------------

#[test]
fn handover_intent_prefix_matches_shared_crypto_enum_values() {
    use shared_crypto::intent::{AppId, IntentScope, IntentVersion};

    assert_eq!(
        HandoverRecord::INTENT_PREFIX,
        [
            IntentScope::HandoverAttestation as u8,
            IntentVersion::V0 as u8,
            AppId::Consensus as u8,
        ],
        "HandoverRecord intent prefix must stay in sync with shared-crypto enums"
    );
}

#[test]
fn handover_signing_message_bcs_wire_compatible() {
    use shared_crypto::intent::{Intent, IntentMessage, IntentScope};

    let record = HandoverRecord::new(
        42,
        EpochIdentifier::new(0),
        EpochIdentifier::new(1),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(1),
            validators: vec![],
            consensus_config: None,
        },
        [0u8; BLAKE3_HASH_SIZE],
    );
    let digest = record.record_digest();
    let generic_msg = Attestation::<HandoverRecord>::signing_message(&digest);

    let intent_msg = IntentMessage::new(
        Intent::consensus_app(IntentScope::HandoverAttestation),
        digest,
    );
    let bcs_bytes = bcs::to_bytes(&intent_msg).expect("BCS serialization");

    assert_eq!(
        generic_msg.as_slice(),
        bcs_bytes.as_slice(),
        "signing_message() must be byte-identical to BCS(IntentMessage(HandoverAttestation, digest))"
    );
}

// -----------------------------------------------------------------------
// BCS roundtrip serialization
// -----------------------------------------------------------------------

#[test]
fn attestation_bcs_roundtrip() {
    let r = record_at(1, 150);
    let (a1, k1, _) = create_test_keys_with_keypair(7000);
    let att = Attestation::<TestRecord>::sign(&r, &k1, &a1).unwrap();

    let bytes = bcs::to_bytes(&att).expect("BCS serialize");
    let restored: Attestation<TestRecord> = bcs::from_bytes(&bytes).expect("BCS deserialize");
    assert_eq!(att, restored);
    restored
        .verify_internal_consistency()
        .expect("restored attestation must verify");
}

#[test]
fn certificate_bcs_roundtrip() {
    let r = record_at(1, 150);
    let (a1, k1, _) = create_test_keys_with_keypair(7010);
    let (a2, k2, _) = create_test_keys_with_keypair(7011);
    let att1 = Attestation::<TestRecord>::sign(&r, &k1, &a1).unwrap();
    let att2 = Attestation::<TestRecord>::sign(&r, &k2, &a2).unwrap();
    let c = TestCert::from_record_and_attestations(r, vec![att1, att2]);

    let bytes = bcs::to_bytes(&c).expect("BCS serialize");
    let restored: TestCert = bcs::from_bytes(&bytes).expect("BCS deserialize");
    assert_eq!(*restored.record(), *c.record());
    assert_eq!(restored.attestations().len(), 2);
    assert!(restored.validate_attestation_consistency().is_ok());
}

#[test]
fn handover_record_bcs_roundtrip() {
    let record = HandoverRecord::new(
        42,
        EpochIdentifier::new(0),
        EpochIdentifier::new(1),
        EpochChangeConfig {
            current_epoch: EpochIdentifier::new(0),
            new_epoch: EpochIdentifier::new(1),
            validators: vec![],
            consensus_config: None,
        },
        [0xABu8; BLAKE3_HASH_SIZE],
    );
    let bytes = bcs::to_bytes(&record).expect("BCS serialize");
    let restored: HandoverRecord = bcs::from_bytes(&bytes).expect("BCS deserialize");
    assert_eq!(restored, record);
    assert_eq!(restored.record_digest(), record.record_digest());
}

#[test]
fn handover_certificate_bcs_roundtrip() {
    let (v0, kp0) = test_validator(7100, 50);
    let genesis_config = EpochChangeConfig {
        current_epoch: EpochIdentifier::new(0),
        new_epoch: EpochIdentifier::new(0),
        validators: vec![v0.clone()],
        consensus_config: None,
    };
    let genesis = HandoverRecord::genesis(EpochIdentifier::new(0), genesis_config);
    let att = Attestation::<HandoverRecord>::sign(&genesis, &kp0, &v0.authority_key).unwrap();
    let cert = HandoverCert::from_record_and_attestations(genesis, vec![att]);

    let bytes = bcs::to_bytes(&cert).expect("BCS serialize");
    let restored: HandoverCert = bcs::from_bytes(&bytes).expect("BCS deserialize");
    assert_eq!(*restored.record(), *cert.record());
    assert_eq!(restored.attestations().len(), 1);
    assert!(restored.validate_attestation_consistency().is_ok());
}
