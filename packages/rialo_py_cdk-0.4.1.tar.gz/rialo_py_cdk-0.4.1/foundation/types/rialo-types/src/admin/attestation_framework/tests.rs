// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use super::{
    super::{
        epoch::EpochIdentifier, test_helpers::test_keys::*, BLAKE3_HASH_SIZE,
        ED25519_SIGNATURE_SIZE,
    },
    *,
};

pub(super) const TEST_RECORD_INTENT_PREFIX: [u8; INTENT_PREFIX_LENGTH] = [255, 0, 2];

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
pub(super) struct TestRecord {
    value_a: u32,
    value_b: u32,
    epoch: EpochIdentifier,
    block_height: u64,
}

impl TestRecord {
    pub(super) fn new(value_a: u32, value_b: u32, epoch: u64, block_height: u64) -> Self {
        Self {
            value_a,
            value_b,
            epoch: EpochIdentifier::new(epoch),
            block_height,
        }
    }

    fn compute_record_digest(&self) -> super::RecordDigest {
        let mut hasher = blake3::Hasher::new();
        hasher.update(&self.value_a.to_le_bytes());
        hasher.update(&self.value_b.to_le_bytes());
        hasher.update(&self.epoch.as_u64().to_le_bytes());
        hasher.update(&self.block_height.to_le_bytes());
        *hasher.finalize().as_bytes()
    }

    pub(super) fn record_digest(&self) -> super::RecordDigest {
        self.compute_record_digest()
    }
}

impl_attestable_record!(TestRecord, TEST_RECORD_INTENT_PREFIX, "Test");

impl committee_record::Sealed for TestRecord {}

impl CommitteeAttestedRecord for TestRecord {
    const CERTIFICATE_TYPE_NAME: &'static str = "TestCertificate";

    fn attesting_epoch(&self) -> EpochIdentifier {
        self.epoch
    }

    fn attested_block_height(&self) -> u64 {
        self.block_height
    }
}

/// Deterministic seeds for `create_test_keys*` (`StdRng::seed_from_u64`); each test uses a
/// distinct offset so key material never collides.
const KEYGEN_SEED_BASE: u64 = 500;

#[test]
fn test_attestation_sign_verify_roundtrip() {
    let record = TestRecord::new(42, 99, 0, 0);
    let (authority_key, protocol_keypair, _) = create_test_keys_with_keypair(KEYGEN_SEED_BASE);

    let attestation = Attestation::<TestRecord>::sign(&record, &protocol_keypair, &authority_key)
        .expect("sign() should succeed with a valid keypair");

    attestation
        .verify_internal_consistency()
        .expect("freshly signed attestation should verify");

    assert_eq!(*attestation.record_digest(), record.record_digest());
    assert_eq!(*attestation.authority_key(), authority_key);
    assert_eq!(*attestation.protocol_key(), protocol_keypair.public());
}

#[test]
fn test_attestation_verify_rejects_tampered_signature() {
    let record = TestRecord::new(1, 2, 0, 0);
    let (authority_key, protocol_keypair, _) = create_test_keys_with_keypair(KEYGEN_SEED_BASE + 1);

    let mut attestation =
        Attestation::<TestRecord>::sign(&record, &protocol_keypair, &authority_key)
            .expect("sign() should succeed");

    attestation.tamper_signature(0, 0xFF);

    assert!(
        attestation.verify_internal_consistency().is_err(),
        "should reject a tampered signature"
    );
}

#[test]
fn test_attestation_verify_rejects_wrong_key() {
    let record = TestRecord::new(10, 20, 0, 0);
    let (authority_key, protocol_keypair, _) = create_test_keys_with_keypair(KEYGEN_SEED_BASE + 2);
    let (_, other_keypair, _) = create_test_keys_with_keypair(KEYGEN_SEED_BASE + 3);

    let mut attestation =
        Attestation::<TestRecord>::sign(&record, &protocol_keypair, &authority_key)
            .expect("sign() should succeed");

    attestation.set_protocol_key(other_keypair.public());

    assert!(
        attestation.verify_internal_consistency().is_err(),
        "should reject when protocol_key doesn't match the signer"
    );
}

#[test]
fn test_attestation_verify_rejects_tampered_record_digest() {
    let record = TestRecord::new(7, 8, 0, 0);
    let (authority_key, protocol_keypair, _) = create_test_keys_with_keypair(KEYGEN_SEED_BASE + 4);

    let mut attestation =
        Attestation::<TestRecord>::sign(&record, &protocol_keypair, &authority_key)
            .expect("sign() should succeed");

    attestation.tamper_record_digest(0, 0xFF);

    assert!(
        attestation.verify_internal_consistency().is_err(),
        "should reject a tampered record_digest"
    );
}

#[test]
fn test_attestation_signing_message_format() {
    let record = TestRecord::new(100, 200, 0, 0);
    let digest = record.record_digest();
    let msg = Attestation::<TestRecord>::signing_message(&digest);

    assert_eq!(msg.len(), ATTESTATION_SIGNING_SIZE);

    assert_eq!(msg[..INTENT_PREFIX_LENGTH], TEST_RECORD_INTENT_PREFIX);
    assert_eq!(msg[INTENT_PREFIX_LENGTH..], digest);
}

#[test]
fn test_test_record_digest_determinism() {
    let record_a = TestRecord::new(42, 99, 0, 0);
    let record_b = TestRecord::new(42, 99, 0, 0);
    assert_eq!(
        record_a.record_digest(),
        record_b.record_digest(),
        "identical records must produce identical digests"
    );
}

#[test]
fn test_test_record_digest_field_sensitivity() {
    let base = TestRecord::new(1, 2, 0, 0);
    let different_a = TestRecord::new(999, 2, 0, 0);
    let different_b = TestRecord::new(1, 999, 0, 0);

    assert_ne!(
        base.record_digest(),
        different_a.record_digest(),
        "different value_a must produce different digests"
    );
    assert_ne!(
        base.record_digest(),
        different_b.record_digest(),
        "different value_b must produce different digests"
    );
    assert_ne!(
        different_a.record_digest(),
        different_b.record_digest(),
        "records differing in different fields must produce different digests"
    );
}

#[test]
fn test_attestation_error_messages_contain_type_name() {
    let (authority_key, protocol_key, _) = create_test_keys(KEYGEN_SEED_BASE + 11);
    let digest = [0xAAu8; BLAKE3_HASH_SIZE];

    let attestation = Attestation::<TestRecord>::from_parts_for_test(
        digest,
        authority_key,
        protocol_key,
        [0u8; ED25519_SIGNATURE_SIZE],
    );

    let err = attestation.verify_internal_consistency().unwrap_err();
    assert_eq!(err.attest_type(), "Test");
    assert!(
        matches!(
            err,
            AttestationError::MalformedSignature { .. }
                | AttestationError::SignatureVerificationFailed { .. }
        ),
        "expected malformed signature or verify failure, got {err:?}"
    );
    let msg = err.to_string();
    assert!(
        msg.starts_with("Test"),
        "Display should start with TYPE_NAME, got: {msg}"
    );
    assert!(
        msg.contains("Attestation"),
        "Display should mention 'Attestation', got: {msg}"
    );
}

#[test]
fn test_attestation_display() {
    let digest = [0xABu8; BLAKE3_HASH_SIZE];
    let (authority_key, protocol_key, _) = create_test_keys(KEYGEN_SEED_BASE + 12);
    let attestation = Attestation::<TestRecord>::from_parts_for_test(
        digest,
        authority_key,
        protocol_key,
        [0u8; ED25519_SIGNATURE_SIZE],
    );

    let display = format!("{attestation}");
    assert!(
        display.starts_with("TestAttestation(digest="),
        "Display should start with 'TestAttestation(digest=', got: {display}"
    );
    assert!(
        display.contains("authority="),
        "Display should contain 'authority=', got: {display}"
    );
    assert!(
        display.ends_with("…)"),
        "Display should end with '…)', got: {display}"
    );
}

#[test]
fn test_attestation_intent_prefix_length_matches_shared_crypto() {
    use shared_crypto::intent::INTENT_PREFIX_LENGTH as SHARED_CRYPTO_PREFIX_LENGTH;

    assert_eq!(
        INTENT_PREFIX_LENGTH, SHARED_CRYPTO_PREFIX_LENGTH,
        "INTENT_PREFIX_LENGTH must match shared_crypto::intent::INTENT_PREFIX_LENGTH"
    );
}

#[test]
fn test_attestation_threshold_matches_numerator_denominator_floor() {
    use super::{
        attestation_threshold, ATTESTATION_THRESHOLD_DENOMINATOR, ATTESTATION_THRESHOLD_NUMERATOR,
    };
    for total in 1u64..=512 {
        let expected = total / ATTESTATION_THRESHOLD_DENOMINATOR * ATTESTATION_THRESHOLD_NUMERATOR;
        assert_eq!(attestation_threshold(total), expected, "total={total}");
    }
}

/// Corner cases tied to [`ATTESTATION_THRESHOLD_NUMERATOR`] and
/// [`ATTESTATION_THRESHOLD_DENOMINATOR`]: totals where `total * N < D` still floor to zero,
/// then totals on and just below multiples of `D`.
#[test]
fn test_attestation_threshold_corner_cases_near_denominator() {
    use super::{
        attestation_threshold, ATTESTATION_THRESHOLD_DENOMINATOR, ATTESTATION_THRESHOLD_NUMERATOR,
    };
    let n = ATTESTATION_THRESHOLD_NUMERATOR;
    let d = ATTESTATION_THRESHOLD_DENOMINATOR;

    let mut total = 1u64;
    while total.saturating_mul(n) < d {
        assert_eq!(
            attestation_threshold(total),
            0,
            "total * NUMERATOR < DENOMINATOR ⇒ floor 0, total={total}"
        );
        total += 1;
    }

    for k in 1u64..=24 {
        let at = k.saturating_mul(d);
        assert_eq!(
            attestation_threshold(at),
            at.saturating_mul(n) / d,
            "at total = k * DENOMINATOR (k={k})"
        );
        if k >= 2 {
            let below = k.saturating_mul(d).saturating_sub(1);
            assert_eq!(
                attestation_threshold(below),
                below.saturating_mul(n) / d,
                "just below k * DENOMINATOR (k={k})"
            );
        }
    }
}

#[test]
#[should_panic(expected = "committee cannot be empty")]
fn test_attestation_threshold_panics_on_zero() {
    use super::attestation_threshold;
    attestation_threshold(0);
}

/// Verifies that `attestation_threshold` does not overflow for stake totals larger than
/// `u64::MAX / 2`. The divide-first order of operations (`total / DENOM * NUMER`) avoids
/// the intermediate overflow that `total * NUMER / DENOM` would hit if `NUMER` were >= 2.
#[test]
fn test_attestation_threshold_no_overflow_large_stake() {
    use super::{
        attestation_threshold, ATTESTATION_THRESHOLD_DENOMINATOR, ATTESTATION_THRESHOLD_NUMERATOR,
    };

    let large = u64::MAX / 2 + 1;
    let expected = large / ATTESTATION_THRESHOLD_DENOMINATOR * ATTESTATION_THRESHOLD_NUMERATOR;
    assert_eq!(
        attestation_threshold(large),
        expected,
        "should not overflow for total > u64::MAX / 2"
    );

    let max = u64::MAX;
    let expected_max = max / ATTESTATION_THRESHOLD_DENOMINATOR * ATTESTATION_THRESHOLD_NUMERATOR;
    assert_eq!(
        attestation_threshold(max),
        expected_max,
        "should not overflow for u64::MAX"
    );
}
