// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! [`SnapshotRecord`] and [`SnapshotAttestation`].

use serde::{Deserialize, Serialize};

use super::super::{
    attestation_framework::{
        private,
        record::{committee_record, CommitteeAttestedRecord},
        AttestableRecord, Attestation, INTENT_PREFIX_LENGTH,
    },
    epoch::EpochIdentifier,
    Blake3Hash, RecordDigest,
};

/// Canonical description of a snapshot that validators attest to.
///
/// A validator creates a `SnapshotRecord` after taking a snapshot, then signs
/// `record_digest()` to produce a `SnapshotAttestation`. The record + attestation
/// are bundled into a [`SnapshotAttestationSubmission`](super::SnapshotAttestationSubmission) and submitted through
/// consensus as `AdminTransaction::SnapshotAttestationSubmission`.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct SnapshotRecord {
    /// The block height at which the snapshot was taken.
    block_height: u64,

    /// The epoch in which the snapshot was created.
    epoch: EpochIdentifier,

    /// The Blake3 hash of the snapshot's key-value state.
    keysvals_hash: Blake3Hash,
}

/// Domain prefix for `SnapshotRecord::record_digest()`.
///
/// Changing this prefix is **hash-breaking** and requires a stop-the-world deployment.
const RIALO_SNAPSHOT_RECORD_V1: &[u8] = b"RIALO_SNAPSHOT_RECORD_V1";

/// Intent prefix for snapshot attestation signatures.
/// `[scope=SnapshotAttestation=10, version=V0=0, app_id=Consensus=2]`
///
/// Mirrors `shared_crypto::intent::IntentScope::SnapshotAttestation` but is
/// inlined to avoid pulling `shared-crypto` into RISC-V / PDK builds.
/// A `#[cfg(test)]` assertion verifies these stay in sync.
pub(crate) const SNAPSHOT_ATTESTATION_INTENT_PREFIX: [u8; INTENT_PREFIX_LENGTH] = [10, 0, 2];

impl SnapshotRecord {
    pub fn new(block_height: u64, epoch: EpochIdentifier, keysvals_hash: Blake3Hash) -> Self {
        Self {
            block_height,
            epoch,
            keysvals_hash,
        }
    }

    pub fn block_height(&self) -> u64 {
        self.block_height
    }

    pub fn epoch(&self) -> EpochIdentifier {
        self.epoch
    }

    pub fn keysvals_hash(&self) -> Blake3Hash {
        self.keysvals_hash
    }

    /// Computes the domain-separated Blake3 digest of this record.
    ///
    /// The digest covers `block_height`, `epoch`, and `keysvals_hash` in that order after the
    /// `RIALO_SNAPSHOT_RECORD_V1` domain prefix. Changing the field set or encoding is **hash-breaking**.
    ///
    /// Named `compute_record_digest` so the [`impl_attestable_record!`] macro can delegate to it
    /// without recursing into the trait method.
    fn compute_record_digest(&self) -> RecordDigest {
        let mut hasher = blake3::Hasher::new();
        hasher.update(RIALO_SNAPSHOT_RECORD_V1);
        hasher.update(&self.block_height.to_le_bytes());
        hasher.update(&self.epoch.to_le_bytes());
        hasher.update(&self.keysvals_hash);
        *hasher.finalize().as_bytes()
    }

    /// Public convenience forwarder for `compute_record_digest`.
    pub fn record_digest(&self) -> RecordDigest {
        self.compute_record_digest()
    }
}

impl std::fmt::Display for SnapshotRecord {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "SnapshotRecord(height={}, epoch={}, keysvals={}…)",
            self.block_height(),
            self.epoch(),
            hex::encode(&self.keysvals_hash()[..4]),
        )
    }
}

impl_attestable_record!(
    SnapshotRecord,
    SNAPSHOT_ATTESTATION_INTENT_PREFIX,
    "Snapshot"
);

impl committee_record::Sealed for SnapshotRecord {}

impl CommitteeAttestedRecord for SnapshotRecord {
    const CERTIFICATE_TYPE_NAME: &'static str = "SnapshotCertificate";

    fn attesting_epoch(&self) -> EpochIdentifier {
        self.epoch
    }

    fn attested_block_height(&self) -> u64 {
        self.block_height
    }
}

/// A validator's signed attestation that a snapshot is valid.
pub type SnapshotAttestation = Attestation<SnapshotRecord>;
