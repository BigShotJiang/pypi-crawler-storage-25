// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Error types for the handover module.

use thiserror::Error;

use super::super::{
    attestation_framework::CertificateAttestationConsistencyError, epoch::EpochIdentifier,
    Blake3Hash,
};

#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum HandoverChainError {
    #[error("block_index {new} must be > last entry block_index {last}")]
    NonAscendingBlockIndex { new: u64, last: u64 },
    /// New record must continue from the previous certificate's `HandoverRecord::dest_epoch`.
    #[error(
        "next handover source_epoch must equal last dest_epoch {last_dest}: got source_epoch {got}"
    )]
    SourceEpochMismatch {
        last_dest: EpochIdentifier,
        got: EpochIdentifier,
    },
    /// `dest_epoch` went backwards relative to the previous certificate's `dest_epoch`.
    #[error(
        "next handover dest_epoch regressed (expected exactly last_dest+1={expected}): last_dest={last_dest} got={got}"
    )]
    DestEpochRegression {
        last_dest: EpochIdentifier,
        expected: EpochIdentifier,
        got: EpochIdentifier,
    },
    /// `dest_epoch` skipped over the next epoch (`last_dest + 2` or higher).
    #[error(
        "next handover dest_epoch skipped an epoch (expected exactly last_dest+1={expected}): last_dest={last_dest} got={got}"
    )]
    DestEpochSkipped {
        last_dest: EpochIdentifier,
        expected: EpochIdentifier,
        got: EpochIdentifier,
    },
    /// `last_dest_epoch` is `u64::MAX`; no further epoch transition is representable.
    #[error("cannot append handover: last dest_epoch is the maximum epoch value")]
    DestEpochOverflow,
    /// The first certificate must be canonical genesis `0→0` (see `HandoverRecord::is_genesis`).
    #[error(
        "first handover record must be canonical genesis (epoch 0→0); see HandoverRecord::is_genesis"
    )]
    InvalidGenesisFirstRecord,
    #[error("genesis certificate attestation consistency: {0}")]
    GenesisAttestationConsistency(#[from] CertificateAttestationConsistencyError),
    /// Genesis certificate must satisfy `HandoverCertificate::is_complete` on a singleton chain
    /// (fully attested per genesis rules).
    #[error("genesis certificate must be complete (see HandoverCertificate::is_complete)")]
    IncompleteGenesisCertificate,
    /// Record's `HandoverRecord::previous_handover_hash` does not match the
    /// `HandoverRecord::record_digest` of the preceding certificate.
    #[error("previous_handover_hash mismatch: expected {expected:02x?}, got {got:02x?}")]
    PreviousHashMismatch {
        expected: Blake3Hash,
        got: Blake3Hash,
    },
    /// Two certificates both claim the transition into the same `HandoverRecord::dest_epoch`.
    #[error("duplicate handover certificate for dest_epoch {epoch}")]
    DuplicateDestEpoch { epoch: EpochIdentifier },
}
