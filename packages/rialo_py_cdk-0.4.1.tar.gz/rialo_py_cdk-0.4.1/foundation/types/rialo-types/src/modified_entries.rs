// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use rialo_s_pubkey::Pubkey;

use crate::{
    rex_info::{RexEntry, RexId},
    websocket::WebSocketConnection,
    RexDutiesMapKey, RexDutiesMapValue,
};

/// Represents a collection of modified REX-related entries.
///
/// This struct contains all the changes that occurred during REX processing,
/// including registries updates and duty modifications. It serves as a consolidated
/// view of all REX state changes that need to be persisted or propagated.
#[derive(Debug, Clone, Default)]
pub struct ModifiedEntries {
    pub modified_duties_registry_entries: Vec<(Pubkey, RexEntry)>,
    pub added_rex_duties: Vec<(RexDutiesMapKey, RexDutiesMapValue)>,
    pub removed_rex_duties: Vec<RexDutiesMapKey>,
    pub modified_websocket_connections: Vec<(RexId, WebSocketConnection)>,
}
