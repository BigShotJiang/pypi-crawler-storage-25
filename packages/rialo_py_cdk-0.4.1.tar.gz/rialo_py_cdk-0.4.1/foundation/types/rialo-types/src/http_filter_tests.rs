// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use std::str::FromStr;

use super::*;

#[test]
fn test_http_get_filter_from_str() {
    // Test valid regex filter
    let filter = HttpFilter::from_str("regex:value:\\s*\"([^\"]*)\"");
    assert!(filter.is_ok());
    assert_eq!(
        filter.unwrap(),
        HttpFilter::Regex("value:\\s*\"([^\"]*)\"".to_string())
    );

    // Test valid jsonpath filter
    let filter = HttpFilter::from_str("jsonpath:$.data.value");
    assert!(filter.is_ok());
    assert_eq!(
        filter.unwrap(),
        HttpFilter::JsonPath("$.data.value".to_string())
    );

    // Test invalid filter format
    let filter = HttpFilter::from_str("invalid_format");
    assert!(filter.is_err());
}

#[test]
fn test_http_get_filter_display() {
    let regex_filter = HttpFilter::Regex("test.*pattern".to_string());
    assert_eq!(regex_filter.to_string(), "regex:test.*pattern");

    let jsonpath_filter = HttpFilter::JsonPath("$.data.value".to_string());
    assert_eq!(jsonpath_filter.to_string(), "jsonpath:$.data.value");
}
