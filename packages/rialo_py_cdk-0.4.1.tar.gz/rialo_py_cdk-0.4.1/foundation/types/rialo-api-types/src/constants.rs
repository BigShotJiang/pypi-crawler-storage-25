// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Constants used throughout the API validation

/// Minimum transaction size in bytes
pub const MIN_TRANSACTION_SIZE: usize = 10;

/// Maximum transaction size in bytes
pub const MAX_TRANSACTION_SIZE: usize = 4096;

/// Maximum possible kelvins (500 million RLO * 1e9 kelvins/RLO)
pub const MAX_KELVINS: u64 = 500_000_000_000_000_000;

/// Maximum airdrop amount in kelvins (1000 RLO)
pub const MAX_AIRDROP_AMOUNT: u64 = 1_000_000_000_000;

/// Maximum limit for paginated requests
pub const MAX_PAGINATION_LIMIT: u64 = 1000;

/// Maximum nonce length in characters
pub const MAX_NONCE_LENGTH: usize = 64;

/// Maximum signature length in base58 characters (for a 64-byte signature)
/// Note: Minimum can be as low as 64 chars if signature has many leading zeros
pub const MAX_SIGNATURE_LENGTH: usize = 88;

/// Minimum blockhash length in base58 characters
pub const MIN_BLOCKHASH_LENGTH: usize = 43;

/// Maximum blockhash length in base58 characters
pub const MAX_BLOCKHASH_LENGTH: usize = 44;
