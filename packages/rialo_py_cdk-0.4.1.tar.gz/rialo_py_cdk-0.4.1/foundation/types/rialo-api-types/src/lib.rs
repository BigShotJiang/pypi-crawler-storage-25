// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! # Rialo API Types
//!
//! This crate provides strongly-typed, validated data structures for all Rialo RPC endpoints.
//! It implements the JSON-RPC 2.0 specification with full Solana compatibility.
//!
//! ## Features
//!
//! - **Type Safety**: Strongly typed request and response structures for all RPC endpoints
//! - **Input Validation**: Built-in validation using the `validator` crate with custom rules  
//! - **JSON-RPC 2.0**: Full compliance with JSON-RPC 2.0 specification
//! - **Solana Compatibility**: Compatible with Solana RPC client libraries and tools
//! - **Comprehensive Documentation**: Each endpoint includes examples and usage patterns
//!
//! ## Quick Start
//!
//! ```rust
//! use rialo_api_types::{
//!     messages::get_account_info::{GetAccountInfoRequest, GetAccountInfoConfig},
//!     validation::validate_request
//! };
//!
//! // Create a request
//! let request = GetAccountInfoRequest {
//!     version: 0,
//!     address: "7xB9i2AcjLNJ6M8iZ3LZJvLm7xpSmH7T5uZzR3DeVXWi".to_string(),
//!     config: Some(GetAccountInfoConfig {
//!         data_slice: None,
//!         min_context_slot: None,
//!     })
//! };
//!
//! // Serialize to JSON
//! let json = serde_json::to_string(&request).unwrap();
//! ```
//!
//! ## Validation
//!
//! All request types support comprehensive input validation:
//!
//! ```rust
//! use rialo_api_types::{
//!     messages::request_airdrop::RequestAirdropRequest,
//!     validation::validate_request
//! };
//!
//! let request = RequestAirdropRequest::new(
//!     "7xB9i2AcjLNJ6M8iZ3LZJvLm7xpSmH7T5uZzR3DeVXWi".to_string(),
//!     1_000_000_000 // 1 RLO in kelvins
//! );
//!
//! // This validates the pubkey format and amount constraints
//! let validated = validate_request(request).unwrap();
//! ```
//!
//! ## Supported RPC Methods
//!
//! ### Account Operations
//! - `getAccountInfo` - Get account information and data
//! - `getBalance` - Get account balance in kelvins
//! - `getMultipleAccounts` - Get information for multiple accounts
//!
//! ### Transaction Operations  
//! - `sendTransaction` - Submit a signed transaction to the network
//! - `getTransaction` - Get transaction details and metadata
//! - `getSignatureStatuses` - Get confirmation status of transactions
//! - `getSignaturesForAddress` - Get transaction signatures for an address
//!
//! ### Block Operations
//! - `getBlock` - Get confirmed block information
//!
//! ### Health & Status
//! - `getHealth` - Node health check endpoint
//! - `getValidatorHealth` - Validator-specific health check
//! - `getConnectedFullNodes` - Get full nodes connected to validator
//! - `getEpochInfo` - Get current epoch information
//!
//! ### Utility Operations
//! - `requestAirdrop` - Request test tokens (devnet/testnet only)
//! - `getMinimumBalanceForRentExemption` - Get minimum balance for rent exemption
//! - `getFeeForMessage` - Calculate transaction fees
//! - `isBlockhashValid` - Check if a blockhash is still valid
//!
//! ### Rialo-Specific Operations
//! - `getWorkflowLineage` - Get workflow transaction lineage and relationships
//! - `getTriggeredTransactions` - Get transactions triggered by events
//! - `getSubscription` - Get subscription by subscriber and nonce
//! - `getTransactionCount` - Get total transaction count
//!
//! ## Error Handling
//!
//! ```rust
//! use rialo_api_types::validation::{ValidationError, ValidationResult};
//! use rialo_api_types::messages::request_airdrop::RequestAirdropRequest;
//!
//! fn handle_validation_error(result: ValidationResult<RequestAirdropRequest>) {
//!     match result {
//!         Ok(data) => { /* Use validated data */ }
//!         Err(ValidationError::InvalidPublicKey(msg)) => {
//!             println!("Invalid public key: {}", msg);
//!         }
//!         Err(ValidationError::Multiple(msg)) => {
//!             println!("Multiple validation errors: {}", msg);
//!         }
//!         Err(err) => {
//!             println!("Validation failed: {}", err);
//!         }
//!     }
//! }
//! ```
//!
//! ## JSON-RPC 2.0 Format
//!
//! All requests follow the JSON-RPC 2.0 specification:
//!
//! ```json
//! {
//!   "jsonrpc": "2.0",
//!   "id": 1,
//!   "method": "getAccountInfo",
//!   "params": [
//!     "7xB9i2AcjLNJ6M8iZ3LZJvLm7xpSmH7T5uZzR3DeVXWi"
//!   ]
//! }
//! ```
//!
//! Responses include context information and follow the same format:
//!
//! ```json
//! {
//!   "jsonrpc": "2.0",
//!   "id": 1,
//!   "result": {
//!     "context": {
//!       "slot": 1234567
//!     },
//!     "value": {
//!       "kelvins": 1000000000,
//!       "data": ["SGVsbG8gV29ybGQ=", "base64"],
//!       "owner": "11111111111111111111111111111111",
//!       "executable": false,
//!       "rentEpoch": 200
//!     }
//!   }
//! }
//! ```

pub mod constants;
pub mod messages;
pub mod parameters;
pub mod requests;
pub mod validation;

#[cfg(test)]
mod validation_test;

#[cfg(test)]
mod integration_test;

// Re-export commonly used types for convenience
pub use messages::{
    get_block::{GetBlockRequest, GetBlockResponse},
    get_connected_full_nodes::GetConnectedFullNodesResponse,
    get_health::GetHealthResponse,
    get_signature_statuses::GetSignatureStatusesRequest,
    get_transaction_count::GetTransactionCountResponse,
    get_validator_health::{GetValidatorHealthResponse, ValidatorHealthStatus},
    get_workflow_lineage::{GetWorkflowLineageRequest, GetWorkflowLineageResponse},
    request_airdrop::{RequestAirdropRequest, RequestAirdropResponse},
    rpc_response_context::RpcResponseContext,
};
