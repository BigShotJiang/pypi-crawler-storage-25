// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// Response structure for the `getTriggeredTransactions` RPC method.
///
/// Contains a list of transactions that were triggered by subscription matches
/// or other automated mechanisms within the blockchain.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GetTriggeredTransactionsResponse {
    #[serde(default)]
    pub version: u16,
    /// A vector of triggered transactions
    pub transactions: Vec<TriggeredTransaction>,
}

/// Represents a single triggered transaction with its metadata.
///
/// Triggered transactions are automatically generated transactions that are
/// executed in response to subscription matches or other programmatic conditions.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TriggeredTransaction {
    /// The unique signature (hash) of the triggered transaction
    pub signature: String,
    /// The block number where this triggered transaction was included
    #[serde(rename = "blockNumber")]
    pub block_number: u64,
}
impl TriggeredTransaction {
    pub fn new(signature: String, block_number: u64) -> Self {
        Self {
            signature,
            block_number,
        }
    }
}

/// Request for getTriggeredTransactions RPC call
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GetTriggeredTransactionsRequest {
    #[serde(default)]
    pub version: u16,
    pub subscription_pubkey: Option<String>,
    pub limit: Option<u32>,
}

impl GetTriggeredTransactionsRequest {
    pub fn new(subscription_pubkey: Option<String>, limit: Option<u32>) -> Self {
        Self {
            version: 0,
            subscription_pubkey,
            limit,
        }
    }
}

impl Default for GetTriggeredTransactionsRequest {
    fn default() -> Self {
        Self::new(None, None)
    }
}
