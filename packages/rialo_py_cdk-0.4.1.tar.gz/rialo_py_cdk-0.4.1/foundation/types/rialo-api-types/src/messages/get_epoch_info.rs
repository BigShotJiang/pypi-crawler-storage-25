// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// Request parameters for the `getEpochInfo` RPC method
/// Solana specification: <https://solana.com/docs/rpc/http/getepochinfo>
#[derive(Debug, Serialize, Deserialize)]
pub struct GetEpochInfoRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    pub version: u16,
    /// The configuration for the request, if any.
    pub config: Option<GetEpochInfoConfig>,
}

/// Config parameters for the getEpochInfo request.
#[derive(Serialize, Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct GetEpochInfoConfig {
    /// The minimum context slot for the request.
    pub min_context_slot: Option<u64>,
}

/// The response message for a getEpochInfo request.
/// Solana specification: <https://solana.com/docs/rpc/http/getepochinfo>
#[derive(Serialize, Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct EpochInfoResponse {
    /// The absolute slot number.
    pub absolute_slot: u64,
    /// The block height.
    pub block_height: u64,
    /// The current epoch.
    pub epoch: u64,
    /// The slot index within the current epoch.
    pub slot_index: u64,
    /// The total number of slots in the current epoch.
    pub slots_in_epoch: u64,
    /// The total transaction count, or null if unavailable.
    pub transaction_count: Option<u64>,
}
