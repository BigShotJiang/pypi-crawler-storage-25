// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// Request parameters for the `getRexRequests` RPC method
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct GetRexRequestsRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    pub version: u16,
    /// REX request creator pubkey, that is pubkey of the account that created the rex request.
    pub creator: String,

    /// Hex representation of the nonce associated with a specific rex.
    /// If empty, it will retrieve the most recently created REX requsts of the given creator.
    /// The result is truncated to an amount of rex that `RexRegistry` holds in memory.
    pub nonce: Option<String>,
}

/// The response message for a getRexRequests request.
#[derive(Serialize, Deserialize, Debug)]
pub struct GetRexRequestsResponse {
    pub rex_requests: Vec<RexInfoAndDuties>,
}

/// REX information combined with its associated duties
#[derive(Serialize, Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct RexInfoAndDuties {
    /// Pubkey of an account that created the rex.
    pub creator: String,
    /// Hex representation of the rex's nonce.
    pub nonce: String,

    /// See RexInfo for documentation.
    pub is_active: bool,
    pub description: String,
    pub update_frequency: String,
    pub starting_timestamp: String,
    pub created_at: String,
    pub validators_per_duty: u32,
    pub rex_request_delay_ms: u64,

    /// A list of all matching rex duties that currently expect rex updates or got their rex updates and expect commitment.
    /// Usually this happens some time before the duty gets committed, which includes `rex_request_delay_ms`.
    pub duties: Vec<RexDuty>,
}

/// Represents a single rex duty assignment for a specific target timestamp
#[derive(Serialize, Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct RexDuty {
    /// Target timestamp of this rex duty.
    pub target_timestamp: String,

    /// Hex representation of validators' ProtocolPublicKeys.
    pub assigned_validators: Vec<String>,
}
