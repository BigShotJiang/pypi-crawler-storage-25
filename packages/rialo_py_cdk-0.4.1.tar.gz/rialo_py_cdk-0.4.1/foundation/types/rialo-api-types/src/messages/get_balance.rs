// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};
use validator::Validate;

use super::rpc_response_context::RpcResponseContext;

/// Request parameters for the `getBalance` RPC method
#[derive(Debug, Serialize, Deserialize, PartialEq, Validate)]
pub struct GetBalanceRequest {
    #[serde(default)]
    #[validate(custom(function = crate::validation::validate_protocol_version))]
    pub version: u16,
    /// The account address to query balance (base58-encoded)
    #[validate(length(min = 1, message = "Address cannot be empty"))]
    #[validate(custom(function = crate::validation::validate_pubkey))]
    pub address: String,
}

impl GetBalanceRequest {
    pub fn new(address: String) -> Self {
        Self {
            version: 0,
            address,
        }
    }
}

/// The 'inner' response message for a GetBalance request.
#[derive(Serialize, Deserialize, Debug)]
pub struct GetBalanceResponse {
    #[serde(default)]
    pub version: u16,
    pub context: RpcResponseContext,
    pub value: u64,
}

impl GetBalanceResponse {
    pub fn new(slot: u64, value: u64) -> Self {
        Self {
            version: 0,
            context: RpcResponseContext::new(slot),
            value,
        }
    }
}
