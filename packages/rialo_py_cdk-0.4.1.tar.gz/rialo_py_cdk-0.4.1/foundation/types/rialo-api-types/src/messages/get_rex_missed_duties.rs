// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// Request parameters for the `getRexMissedDuties` RPC method
#[derive(Serialize, Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct GetRexMissedDutiesRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    pub version: u16,
    /// REX creator pubkey, that is pubkey of the account that created the rex request.
    pub creator: String,

    /// Hex representation of the nonce associated with a specific rex.
    pub nonce: String,
}

/// Response for the `getRexMissedDuties` RPC method containing proposal rounds where duties were missed.
/// The method returns data based on the `read_missed_rex_duties` function, which may not include all missed duties
/// due to store constraints or future changes. The duties are represented as corresponding target proposal rounds.
#[derive(Serialize, Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct GetRexMissedDutiesResponse {
    /// Returns most recent duties that received no updates.
    /// The duties are represented as corresponding proposal rounds.
    pub missed_duties_at_proposal_rounds: Vec<u64>,
}
