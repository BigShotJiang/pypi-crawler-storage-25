// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// Maximum number of blocks that can be returned in a single request.
pub const MAX_GET_BLOCKS_RANGE: u64 = 500_000;

/// Request parameters for the `getBlocks` RPC method.
///
/// Returns a list of confirmed blocks between two slots (inclusive).
#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetBlocksRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    pub version: u16,
    /// Start slot (inclusive).
    pub start_slot: u64,
    /// End slot (inclusive). If not provided, the endpoint will return
    /// a maximum of 500,000 blocks starting from `start_slot`.
    pub end_slot: Option<u64>,
}

/// Response for the `getBlocks` RPC method.
///
/// Contains an array of slot numbers that have confirmed blocks.
pub type GetBlocksResponse = Vec<u64>;

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::*;

    #[test]
    fn test_get_blocks_request_minimal() {
        let request: GetBlocksRequest = serde_json::from_value(json!({
            "version": 0,
            "startSlot": 100
        }))
        .unwrap();
        assert_eq!(request.start_slot, 100);
        assert!(request.end_slot.is_none());
    }

    #[test]
    fn test_get_blocks_request_with_end_slot() {
        let request: GetBlocksRequest = serde_json::from_value(json!({
            "version": 0,
            "startSlot": 100,
            "endSlot": 200
        }))
        .unwrap();
        assert_eq!(request.start_slot, 100);
        assert_eq!(request.end_slot, Some(200));
    }

    #[test]
    fn test_max_blocks_range_constant() {
        assert_eq!(MAX_GET_BLOCKS_RANGE, 500_000);
    }
}
