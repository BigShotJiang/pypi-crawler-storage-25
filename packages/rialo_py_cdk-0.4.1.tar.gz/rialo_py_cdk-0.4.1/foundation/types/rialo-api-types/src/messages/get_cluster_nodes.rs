// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// Information about a cluster node (authority)
#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct ClusterNodeInfo {
    /// Voting power of the authority in the committee.
    pub stake: u64,
    /// Network address for communicating with the authority.
    pub address: String,
    /// The authority's hostname.
    pub hostname: String,
    /// The authority's public key (base64 encoded BLS12381) as Rialo identity.
    pub authority_pubkey: String,
    /// The authority's public key (base64 encoded Ed25519) for verifying blocks.
    pub protocol_pubkey: String,
    /// The authority's public key (base64 encoded Ed25519) for TLS and as network identity.
    pub network_pubkey: String,
    /// Last committed round for this authority (from the full node's perspective).
    /// This indicates how far along this validator is in consensus.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub last_committed_round: Option<u32>,
}

/// Response structure for getClusterNodes RPC method
#[derive(Serialize, Deserialize, Clone, Debug)]
pub struct GetClusterNodesResponse {
    #[serde(default)]
    pub version: u16,
    /// List of cluster nodes (authorities)
    pub nodes: Vec<ClusterNodeInfo>,
}
