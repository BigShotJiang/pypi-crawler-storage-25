// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};
use validator::Validate;

/// Request parameters for the `getMinimumBalanceForRentExemption` RPC method
/// Solana specification: <https://solana.com/docs/rpc/http/getminimumbalanceforrentexemption>
#[derive(Debug, Serialize, Deserialize, Validate)]
pub struct GetMinimumBalanceForRentExemptionRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    #[validate(custom(function = crate::validation::validate_protocol_version))]
    pub version: u16,
    /// The length of the data to check for rent exemption
    #[validate(range(
        min = 0,
        max = 10485760,
        message = "Data length must be between 0 and 10MB"
    ))]
    pub data_length: u64,
}

/// Response for the `getMinimumBalanceForRentExemption` RPC method
/// Solana specification: <https://solana.com/docs/rpc/http/getminimumbalanceforrentexemption>
#[derive(Debug, Serialize, Deserialize)]
pub struct GetMinimumBalanceForRentExemptionResponse {
    /// The minimum balance in kelvins required for rent exemption
    pub value: u64,
}

impl GetMinimumBalanceForRentExemptionResponse {
    /// Create a new response with the given minimum balance
    pub fn new(value: u64) -> Self {
        Self { value }
    }
}
