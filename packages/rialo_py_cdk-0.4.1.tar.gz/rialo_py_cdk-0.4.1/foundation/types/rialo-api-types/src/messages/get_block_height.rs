// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// Request for getBlockHeight RPC method.
#[derive(Serialize, Deserialize, Debug, Default)]
pub struct GetBlockHeightRequest {
    /// Optional configuration.
    #[serde(skip_serializing_if = "Option::is_none")]
    pub config: Option<RequestBlockHeightConfig>,
}

/// Config parameters for the getBlockHeight request.
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct RequestBlockHeightConfig {
    #[serde(default)]
    pub version: u16,
    /// The minimum context slot for the request.
    #[serde(rename = "minContextSlot")]
    pub min_context_slot: Option<u64>,
}

#[cfg(test)]
mod tests {
    use serde_json::{from_str, to_string};

    use super::*;

    #[test]
    fn test_request_block_height_config_serialization() {
        let config = RequestBlockHeightConfig {
            version: 0,
            min_context_slot: Some(100),
        };
        let json = to_string(&config).unwrap();
        let expected = r#"{"version":0,"minContextSlot":100}"#;
        assert_eq!(json, expected);

        let deserialized: RequestBlockHeightConfig = from_str(&json).unwrap();
        assert_eq!(deserialized.min_context_slot, Some(100));
    }

    #[test]
    fn test_request_block_height_config_minimal_serialization() {
        let config = RequestBlockHeightConfig {
            version: 0,
            min_context_slot: None,
        };
        let json = to_string(&config).unwrap();
        let expected = r#"{"version":0,"minContextSlot":null}"#;
        assert_eq!(json, expected);

        let deserialized: RequestBlockHeightConfig = from_str(&json).unwrap();
        assert_eq!(deserialized.min_context_slot, None);
    }
}
