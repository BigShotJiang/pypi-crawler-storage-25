// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

use super::rpc_response_context::RpcResponseContext;

/// The response message for a getTransactionCount request.
/// Returns the total number of transactions processed by the ledger.
#[derive(Debug, Serialize, Deserialize)]
pub struct GetTransactionCountResponse {
    #[serde(default)]
    pub version: u16,
    pub context: RpcResponseContext,
    pub value: u64,
}

impl GetTransactionCountResponse {
    pub fn new(slot: u64, count: u64) -> Self {
        Self {
            version: 0,
            context: RpcResponseContext::new(slot),
            value: count,
        }
    }
}

/// Request for getTransactionCount RPC call
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct GetTransactionCountRequest {
    #[serde(default)]
    pub version: u16,
}

impl GetTransactionCountRequest {
    pub fn new() -> Self {
        Self { version: 0 }
    }
}
