// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use rialo_shared_types::Subscription;
use serde::{Deserialize, Serialize};

use super::rpc_response_context::RpcResponseContext;

/// The response message for a getSubscription request.
#[derive(Serialize, Deserialize, Debug)]
pub struct GetSubscriptionResponse {
    #[serde(default)]
    pub version: u16,
    pub context: RpcResponseContext,

    /// The subscription that is requested.
    pub subscription: Subscription,
}

/// Request for getSubscription RPC call
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GetSubscriptionRequest {
    #[serde(default)]
    pub version: u16,
    pub subscriber: Option<String>,
    pub nonce: Option<String>,
}

impl GetSubscriptionRequest {
    pub fn new(subscriber: Option<String>, nonce: Option<String>) -> Self {
        Self {
            version: 0,
            subscriber,
            nonce,
        }
    }
}

impl Default for GetSubscriptionRequest {
    fn default() -> Self {
        Self::new(None, None)
    }
}
