// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use rialo_shared_types::AccountInfoResponseValue;
use serde::{Deserialize, Serialize};
use validator::Validate;

use super::rpc_response_context::RpcResponseContext;

/// Request parameters for the `getMultipleAccounts` RPC method
#[derive(Debug, Serialize, Deserialize, Validate)]
pub struct GetMultipleAccountsRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    #[validate(custom(function = crate::validation::validate_protocol_version))]
    pub version: u16,
    /// List of base58-encoded account addresses to query
    #[validate(length(min = 1, max = 100, message = "Must provide 1-100 addresses"))]
    #[validate(custom(function = crate::validation::validate_addresses))]
    pub addresses: Vec<String>,
}

/// The response message for a getMultipleAccounts request.
///
/// Solana specification: <https://solana.com/docs/rpc/http/getmultipleaccounts>
#[derive(Serialize, Deserialize, Debug)]
pub struct MultipleAccountsResponse {
    pub context: RpcResponseContext,
    pub value: Vec<Option<AccountInfoResponseValue>>,
}
