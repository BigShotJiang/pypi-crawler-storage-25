// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};
use validator::Validate;

use super::rpc_response_context::RpcResponseContext;

#[derive(Serialize, Deserialize)]
pub struct IsBlockhashValidResponse {
    pub context: RpcResponseContext,
    pub value: bool,
}

impl IsBlockhashValidResponse {
    pub fn new(slot: u64, value: bool) -> Self {
        Self {
            context: RpcResponseContext::new(slot),
            value,
        }
    }
}

/// Request for isBlockhashValid RPC call
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Validate)]
pub struct IsBlockhashValidRequest {
    #[serde(default)]
    #[validate(custom(function = crate::validation::validate_protocol_version))]
    pub version: u16,

    #[validate(length(min = 1, message = "Blockhash cannot be empty"))]
    #[validate(custom(function = crate::validation::validate_blockhash))]
    pub blockhash: String,
}

impl IsBlockhashValidRequest {
    pub fn new(blockhash: String) -> Self {
        Self {
            version: 0,
            blockhash,
        }
    }
}
