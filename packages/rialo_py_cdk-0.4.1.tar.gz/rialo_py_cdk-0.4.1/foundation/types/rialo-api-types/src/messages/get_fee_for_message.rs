// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};
use validator::Validate;

use super::rpc_response_context::RpcResponseContext;

/// Request parameters for the `getFeeForMessage` RPC method
#[derive(Debug, Serialize, Deserialize, Validate)]
pub struct GetFeeForMessageRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    #[validate(custom(function = crate::validation::validate_protocol_version))]
    pub version: u16,
    /// bincode-serialized versioned message in base64 format
    #[validate(length(min = 1, message = "Message cannot be empty"))]
    #[validate(custom(function = crate::validation::validate_base64))]
    pub message: String,
}

/// The 'inner' response message for a GetFeeForMessage request.
#[derive(Serialize, Deserialize, Debug)]
pub struct GetFeeForMessageResponse {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    pub version: u16,
    pub context: RpcResponseContext,
    pub value: Option<u64>,
}

impl GetFeeForMessageResponse {
    pub fn new(version: u16, slot: u64, value: Option<u64>) -> Self {
        Self {
            version,
            context: RpcResponseContext::new(slot),
            value,
        }
    }
}
