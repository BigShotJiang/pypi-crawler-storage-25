// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use rialo_s_sdk::signature::Signature;
use serde::{Deserialize, Serialize};

use super::{
    get_transaction::{Transaction, TransactionStatusMetadata},
    rpc_response_context::RpcResponseContext,
};

/// Request parameters for the `getBlock` RPC method
#[derive(Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetBlockRequest {
    /// Protocol version for forward compatibility.
    #[serde(default)]
    pub version: u16,
    /// The block height to retrieve
    pub block_height: u64,
    /// Configuration options for the request
    #[serde(default)]
    pub config: Option<GetBlockConfig>,
}

/// Configuration options for getBlock requests
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub struct GetBlockConfig {
    /// Level of transaction detail to return
    #[serde(default)]
    pub transaction_details: TransactionDetails,
}

/// Transaction detail levels
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize, Default)]
#[serde(rename_all = "camelCase")]
pub enum TransactionDetails {
    /// Return full transaction details
    #[default]
    Full,
    /// Return only transaction signatures
    Signatures,
    /// Return no transaction details
    None,
}

/// Block information response
#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct BlockInfo {
    /// Block height
    pub block_height: u64,
    /// Block timestamp in unix format (seconds since epoch)
    pub block_time: i64,
    /// Transactions in the block
    pub transactions: Option<Vec<TransactionWithMeta>>,
    /// Transaction signatures (when transaction_details is Signatures)
    pub signatures: Option<Vec<Signature>>,
}

/// Transaction information in a block using existing types
#[derive(Debug, Serialize)]
pub struct TransactionWithMeta {
    /// The transaction data (reusing from get_transaction.rs)
    pub transaction: Transaction,
    /// Transaction metadata (reusing from get_transaction.rs)
    pub meta: Option<TransactionStatusMetadata>,
}

/// The response message for a GetBlock request
#[derive(Serialize, Debug)]
pub struct GetBlockResponse {
    pub context: RpcResponseContext,
    pub value: BlockInfo,
}
