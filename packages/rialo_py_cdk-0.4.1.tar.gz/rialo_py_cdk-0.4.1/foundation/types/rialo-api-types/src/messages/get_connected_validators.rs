// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use serde::{Deserialize, Serialize};

/// The response message for a getConnectedValidators request.
/// Returns the indices (in committee order) of validators this node
/// has active outbound connections to.
#[derive(Debug, Serialize, Deserialize)]
#[serde(transparent)]
pub struct GetConnectedValidatorsResponse {
    /// The validator indices with active connections
    pub validator_indices: Vec<u32>,
}

impl GetConnectedValidatorsResponse {
    pub fn new(validator_indices: Vec<u32>) -> Self {
        Self { validator_indices }
    }
}

/// Request for getConnectedValidators RPC call
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GetConnectedValidatorsRequest {
    #[serde(default)]
    pub version: u16,
}

impl GetConnectedValidatorsRequest {
    pub fn new() -> Self {
        Self { version: 0 }
    }
}

impl Default for GetConnectedValidatorsRequest {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use serde_json::{from_str, to_string};

    use super::*;

    #[test]
    fn test_get_connected_validators_response_empty_serialization() {
        let indices = vec![];
        let response = GetConnectedValidatorsResponse::new(indices.clone());
        let json = to_string(&response).unwrap();
        assert_eq!(json, "[]");

        let deserialized: GetConnectedValidatorsResponse = from_str(&json).unwrap();
        assert_eq!(deserialized.validator_indices, indices);
    }

    #[test]
    fn test_get_connected_validators_response_non_empty_serialization() {
        let indices = vec![0, 1, 3, 5];
        let response = GetConnectedValidatorsResponse::new(indices.clone());
        let json = to_string(&response).unwrap();
        assert_eq!(json, "[0,1,3,5]");

        let deserialized: GetConnectedValidatorsResponse = from_str(&json).unwrap();
        assert_eq!(deserialized.validator_indices, indices);
    }
}
