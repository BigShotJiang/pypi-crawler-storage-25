// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Rialo CLI Representation Traits
//!
//! This crate defines lightweight traits used by the CLI and proc-macro to enable
//! human-readable and serializable representations for types printed in the CLI.
//! It is intentionally a small, non-proc-macro crate so it can be depended on by
//! both the main `rialo` crate and the `rialo-cli-representable` proc-macro crate.

/// Trait for types that can format themselves for human-readable output
pub trait HumanReadable {
    /// Return a human-readable string representation
    fn human_readable(&self) -> String;
}

/// Trait for types that can be represented in both human-readable and serialized formats
pub trait Representable: HumanReadable + serde::Serialize {}
