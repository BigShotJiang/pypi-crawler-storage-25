// SPDX-License-Identifier: Apache-2.0
// Copyright (c) Subzero Labs, Inc.

use rialo_s_pubkey::Pubkey;

mod compute_budget;
pub mod rex;

pub use compute_budget::*;
// Re-export rex module contents for easier access.
pub use rex::update_size::*;

/// The number of bytes in a kilobyte.
const KIB: u64 = 1024;

/// The number of bytes in a megabyte.
const MIB: u64 = 1024 * KIB;

/// The maximum size of a program instruction payload in bytes.
pub const MAX_INSTRUCTION_DATA_SIZE: u64 = 65 * KIB;

/// The maximum size of a consensus block in bytes.
pub const MAX_CONSENSUS_BLOCK_SIZE: u64 = 512 * KIB;

/// The maximum size of a single transaction in bytes.
pub const MAX_TRANSACTION_SIZE: u64 = 128 * KIB;

/// The maximum size for a payload received from a remote backend in bytes.
pub const MAX_RESPONSE_SIZE: usize = (10 * MIB) as usize;

/// The size of the data portion of a network packet in bytes.
/// Note: Maximum over-the-wire size of a Transaction
///   1280 is IPv6 minimum MTU
///   40 bytes is the size of the IPv6 header
///   8 bytes is the size of the fragment header
pub const PACKET_DATA_SIZE: usize = 4096 - 40 - 8;

#[cfg(test)]
static_assertions::const_assert_eq!(PACKET_DATA_SIZE, 4048);

// The packet has a maximum length of 1232 bytes.
// This means the maximum number of 32 byte keys is 38.
// 38 as an min-sized encoded u16 is 1 byte.
// We can simply read this byte, if it's >38 we can return None.
pub const MAX_STATIC_ACCOUNTS_PER_PACKET: u8 =
    (PACKET_DATA_SIZE / core::mem::size_of::<Pubkey>()) as u8;
