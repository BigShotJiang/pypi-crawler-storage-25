// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use crate::{rex::update_size::REX_OUTPUT_RAW_BASE_OVERHEAD, REX_MAX_OUTPUT_SIZE};

/// Maximum number of messages that can be sent at once over a WebSocket connection.
pub const WEBSOCKET_MAX_BATCH_MESSAGES: usize = 100;

/// Maximum size of WebSocket data buffer.
///
/// This is set to `REX_MAX_OUTPUT_SIZE - REX_OUTPUT_RAW_BASE_OVERHEAD` to account for
/// the additional bytes added when the WebSocketReadResponse is wrapped in RexResponse
/// and RexOutput::Success before being serialized by the REX handler.
///
/// Without this reduction, a WebSocketReadResponse at exactly REX_MAX_OUTPUT_SIZE would
/// become REX_MAX_OUTPUT_SIZE + 37 bytes after wrapping, exceeding the limit and causing
/// the handler's size check to panic (see rex-common/src/router/handler.rs).
pub const WEBSOCKET_MAX_BUFFER_SIZE: usize = REX_MAX_OUTPUT_SIZE - REX_OUTPUT_RAW_BASE_OVERHEAD;

/// Maximum reconnection backoff in seconds for WebSocket connections in the TEE
/// (used for exponential backoff when retrying failed connections).
pub const WEBSOCKET_MAX_RECONNECT_BACKOFF_SECS: u64 = 5;
