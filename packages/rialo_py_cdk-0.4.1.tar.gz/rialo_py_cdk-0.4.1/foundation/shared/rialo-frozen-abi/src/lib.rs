// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

#![allow(incomplete_features)]
#![cfg_attr(feature = "frozen-abi", feature(specialization))]

// Allows macro expansion of `use ::rialo_frozen_abi::*` to work within this crate
#[cfg(feature = "frozen-abi")]
extern crate self as rialo_frozen_abi;

#[cfg(feature = "frozen-abi")]
pub mod abi_digester;
#[cfg(feature = "frozen-abi")]
pub mod abi_example;
#[cfg(feature = "frozen-abi")]
mod hash;

#[cfg(feature = "frozen-abi")]
#[macro_use]
extern crate rialo_frozen_abi_macro;

// Not public API. Referenced by macro-generated code.
#[doc(hidden)]
pub mod __private {
    #[doc(hidden)]
    pub use log;
}
