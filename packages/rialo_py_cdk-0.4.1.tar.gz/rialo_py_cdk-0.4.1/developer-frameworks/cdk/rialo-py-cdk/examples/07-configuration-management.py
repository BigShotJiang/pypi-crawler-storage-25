#!/usr/bin/env python3
# Copyright (c) Subzero Labs, Inc.
# SPDX-License-Identifier: Apache-2.0

"""
Configuration Management Example

This example demonstrates basic configuration capabilities:
- Network switching and RPC URL management
- Basic configuration object usage
- Integration with wallet and RPC operations

Note: Advanced configuration providers (InMemoryConfigProvider, FileConfigProvider)
are planned for future releases.
"""

from rialo_py_cdk import (
    Config,
    generate_keypair,
    Wallet,
    HttpRpcClient,
    get_rpc_url_for_network,
    list_available_networks,
    get_localnet_url,
    RialoException,
    FILE_STORAGE_AVAILABLE
)


def main():
    """Demonstrate configuration management capabilities."""
    print('⚙️ Configuration Management Example')
    print('=' * 50)

    try:
        # 1. Basic configuration usage
        print('\n1. Creating basic configuration...')
        config = Config()

        print(f'   Default RPC URL: {config.rpc_url}')
        print(f'   Default network: {config.network}')

        # 2. Show available networks
        print('\n2. Available networks:')
        networks = list_available_networks()
        for network in networks:
            rpc_url = get_rpc_url_for_network(network)
            print(f'   {network}: {rpc_url}')

        # 3. Network configuration
        print('\n3. Network configuration examples...')

        network_urls = {
            'localnet': get_localnet_url(),
        }

        for network_name, url in network_urls.items():
            print(f'   {network_name}: {url}')

        # 4. Basic config object operations
        print('\n4. Basic configuration operations...')

        try:
            # Try to set network (may not be implemented yet)
            config.set_network('devnet')
            print(f'   ✅ Set network to devnet: {config.rpc_url}')
        except (AttributeError, Exception) as e:
            print(f'   ℹ️  Network setting not available: {type(e).__name__}')
            print('   (This is expected in current version)')

        # 5. Demonstrate RPC client with different networks
        print('\n5. Testing RPC clients with different networks...')

        for network_name, url in [('localnet', get_localnet_url())]:
            print(f'\n   Testing {network_name} ({url})...')

            try:
                client = HttpRpcClient(url)

                # Try a simple RPC call
                print(f'   ✅ RPC client created for {network_name}')
                print(f'   ℹ️  Note: Actual RPC calls require a running node')

            except Exception as e:
                print(f'   ⚠️  Error creating RPC client: {e}')

        # 6. Wallet integration with configuration
        print('\n6. Wallet integration with configuration...')

        keypair = generate_keypair()
        wallet = Wallet('config-demo-wallet', keypair)

        print(f'   ✅ Created wallet: {wallet.get_public_key_string()[:16]}...')
        print(f'   ℹ️  This wallet can be used with any configured network')

        # 7. File storage availability
        print('\n7. Storage capabilities:')
        print(f'   File storage available: {FILE_STORAGE_AVAILABLE}')

        if FILE_STORAGE_AVAILABLE:
            print('   ✅ File-based storage is available')
            print('   📝 Advanced configuration providers coming in future versions')
        else:
            print('   ℹ️  File-based storage not available in this build')

        # 8. Future configuration features preview
        print('\n8. 🔮 Future Configuration Features:')
        print('   The following features are planned for future releases:')
        print('   • InMemoryConfigProvider - Store configs in memory')
        print('   • FileConfigProvider - Persist configs to disk')
        print('   • Configuration templates and profiles')
        print('   • Environment-based configuration loading')
        print('   • Configuration validation and schemas')
        print('   • Network-specific wallet defaults')
        print('   • Automatic configuration migration')

        print('\n✅ Configuration management example completed!')
        print('\n📝 Summary:')
        print('   • Basic Config object works')
        print('   • Network URL management is functional')
        print('   • RPC client integration works')
        print('   • Wallet integration is ready')
        print('   • Advanced features coming soon')

    except Exception as e:
        print(f'\n❌ Error in configuration example: {e}')
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()