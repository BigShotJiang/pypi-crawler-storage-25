#!/usr/bin/env python3
# Copyright (c) Subzero Labs, Inc.
# SPDX-License-Identifier: Apache-2.0

"""
Basic operations example demonstrating core functionality
"""

from rialo_py_cdk import (
    generate_keypair,
    public_key_from_keypair,
    sign,
    verify,
    get_localnet_url,
    Hash,
    PublicKey,
    Signature,
    Wallet,
    HttpRpcClient,
)


def basic_operations_example():
    """Run basic operations example demonstrating core functionality."""
    print('🚀 Starting Rialo CDK Basic Operations Example\n')

    try:
        # 1. Generate a keypair
        print('1. Generating keypair...')
        keypair = generate_keypair()
        print(f'   Generated keypair: {len(keypair)} bytes')

        # 2. Extract public key
        print('2. Extracting public key...')
        public_key = public_key_from_keypair(keypair)
        print(f'   Public key: {public_key}')

        # 3. Create a wallet
        print('3. Creating wallet...')
        wallet = Wallet(
            'example-wallet',
            keypair,
            None,  # no mnemonic for this example
            None   # no derivation path
        )
        print(f'   Wallet name: {wallet.name}')
        print(f'   Wallet public key: {wallet.get_public_key_string()}')

        # 4. Sign a message
        print('4. Signing a message...')
        message = b'Hello, Rialo blockchain!'
        signature = sign(keypair, message)
        print(f'   Signature: {signature}')

        # 5. Verify the signature
        print('5. Verifying signature...')
        is_valid = verify(public_key, message, signature)
        print(f'   Signature valid: {is_valid}')

        # 6. Create RPC client
        print('6. Creating RPC client...')
        client = HttpRpcClient(get_localnet_url())
        print(f'   RPC client created for local network: {get_localnet_url()}')

        # 7. Test hash operations
        print('7. Testing hash operations...')
        hash_bytes = bytes([42] * 32)  # Fill with test data
        hash_obj = Hash(hash_bytes)
        print(f'   Hash string: {hash_obj}')
        print(f'   Hash bytes length: {len(hash_obj.to_bytes())}')

        # 8. Test PublicKey operations
        print('8. Testing PublicKey operations...')
        pubkey_bytes = bytes([i % 256 for i in range(32)])
        pubkey_obj = PublicKey(pubkey_bytes)
        print(f'   PublicKey string: {pubkey_obj}')
        print(f'   PublicKey bytes length: {len(pubkey_obj.to_bytes())}')

        # 9. Test Signature operations
        print('9. Testing Signature operations...')
        sig_bytes = bytes([i % 256 for i in range(64)])
        sig_obj = Signature(sig_bytes)
        print(f'   Signature string: {sig_obj}')
        print(f'   Signature bytes length: {len(sig_obj.to_bytes())}')

        # 10. Sign a message with wallet
        print('10. Signing message with wallet...')
        wallet_signature = wallet.sign(message)
        print(f'    Wallet signature: {wallet_signature}')
        print(f'    Wallet signature length: {len(wallet_signature)}')

        print('\n✅ Basic operations completed successfully!')

    except Exception as error:
        print(f'❌ Error during basic operations: {error}')
        raise error


def main():
    """Run the basic operations example."""
    try:
        basic_operations_example()
        print('🎉 Example finished!')
    except Exception as error:
        print(f'💥 Example failed: {error}')
        import traceback
        traceback.print_exc()
        exit(1)


if __name__ == "__main__":
    main()