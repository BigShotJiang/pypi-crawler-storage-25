# Copyright (c) Subzero Labs, Inc.
# SPDX-License-Identifier: Apache-2.0

"""
Integration tests for the Rialo Python CDK with real blockchain interactions.

These tests require a running Rialo network, e.g. localhost
"""

import pytest
import time
from unittest.mock import patch, MagicMock
from rialo_py_cdk import (
    RialoRPCClient,
    create_wallet_with_mnemonic,
    TransactionBuilder,
    PublicKey,
    Hash,
    get_localnet_url,
    KELVIN_PER_RLO,
    rlo_to_kelvin,
    transfer_instruction,
    RialoException,
)






@pytest.fixture
def test_wallet():
    """Create a test wallet with mnemonic."""
    return create_wallet_with_mnemonic("integration_test_wallet")
















class TestBasicIntegration:
    """Basic integration tests that don't require async."""
    
    def test_wallet_and_rpc_client_creation(self):
        """Test that we can create wallets and RPC clients."""
        # Create wallet
        wallet, mnemonic = create_wallet_with_mnemonic("test_wallet")
        assert wallet.name == "test_wallet"
        assert len(mnemonic.split()) == 12
        
        # Create RPC client
        client = RialoRPCClient(get_localnet_url())
        assert client is not None
        
    def test_transaction_building(self):
        """Test transaction building without network interaction."""
        wallet, _ = create_wallet_with_mnemonic("tx_test_wallet")
        recipient_wallet, _ = create_wallet_with_mnemonic("recipient_wallet")
        
        # Build transaction
        # Args: payer, valid_from, config_hash_prefix
        builder = TransactionBuilder(wallet.get_public_key(), 0, 1)
        transfer_amount = int(rlo_to_kelvin(0.001))  # Convert to integer
        
        builder.add_transfer_instruction(
            wallet.get_public_key(),
            recipient_wallet.get_public_key(), 
            transfer_amount
        )
        
        # Build (but don't sign/send)
        tx_bytes = builder.build()
        assert tx_bytes is not None
        assert len(tx_bytes) > 0
    
    def test_transfer_instruction_creation(self):
        """Test transfer instruction creation."""
        from_wallet, _ = create_wallet_with_mnemonic("from_wallet")
        to_wallet, _ = create_wallet_with_mnemonic("to_wallet")
        
        # Create transfer instruction
        instruction = transfer_instruction(
            from_wallet.get_public_key(),
            to_wallet.get_public_key(),
            int(rlo_to_kelvin(1.0))  # Convert to integer
        )
        
        assert instruction is not None
        assert len(instruction.accounts) >= 2  # Should have from and to accounts
        assert len(instruction.data) > 0  # Should have instruction data


if __name__ == "__main__":
    pytest.main([__file__, "-v"])