// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

#[cfg(test)]
mod tests {
    use rialo_cdk::config::{ConfigManager, ConfigUtils, RialoCdkConfigurationSchemaCdkNetwork};
    use tempfile::TempDir;

    #[test]
    fn test_default_config() {
        let temp_dir = TempDir::new().unwrap();
        let config_path = temp_dir.path().join("test_default.toml");

        let manager = ConfigManager::new(&config_path).unwrap();
        let config = manager.load().unwrap();

        // Check default values
        assert_eq!(
            config.cdk.as_ref().unwrap().network,
            RialoCdkConfigurationSchemaCdkNetwork::Localnet
        );
        assert_eq!(config.cdk.as_ref().unwrap().default_wallet, None);
        assert!(!config.cdk.as_ref().unwrap().verbose_mode);

        // Check that we can get RPC URL
        let rpc_url = ConfigUtils::get_rpc_url(&config, None).unwrap();
        assert_eq!(rpc_url, "http://127.0.0.1:4104");
    }
}
