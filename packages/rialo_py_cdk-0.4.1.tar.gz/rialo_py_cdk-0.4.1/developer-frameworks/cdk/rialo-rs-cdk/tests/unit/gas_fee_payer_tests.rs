// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

#[cfg(test)]
mod tests {
    use std::collections::HashSet;

    use rialo_s_message::{ConfigHashPrefix, Message, SanitizedMessage};
    use rialo_s_pubkey::Pubkey;
    use rialo_s_sdk::instruction::CompiledInstruction;
    use rialo_sanitize::Sanitize;

    #[test]
    fn test_message_with_custom_fee_payer() {
        // Create a message where account at index 1 pays fees
        // Account layout:
        // 0: Fee payer (writable, signer)
        // 1: Transaction signer (writable)
        // 2: Program ID (readonly)
        let account0 = Pubkey::new_unique();
        let fee_payer = Pubkey::new_unique();
        let program_id = Pubkey::new_unique();

        let message = Message::new_with_compiled_instructions(
            2, // num_required_signatures (both account0 and fee_payer must sign)
            0, // num_readonly_signed_accounts
            1, // num_readonly_unsigned_accounts (program_id)
            vec![fee_payer, account0, program_id],
            0,
            ConfigHashPrefix::new(1),
            false,
            vec![CompiledInstruction::new(2, &(), vec![0])],
        );

        let message_with_custom_payer = message.clone();
        assert!(message_with_custom_payer.sanitize().is_ok());

        // Create sanitized message to test fee_payer() method
        let sanitized =
            SanitizedMessage::try_from_legacy_message(message_with_custom_payer, &HashSet::new())
                .unwrap();
        assert_eq!(sanitized.fee_payer(), &fee_payer);
    }

    #[test]
    fn test_backward_compatibility_default_payer() {
        let payer = Pubkey::new_unique();
        let program_id = Pubkey::new_unique();

        let message = Message::new_with_compiled_instructions(
            1,
            0,
            1,
            vec![payer, program_id],
            0,
            ConfigHashPrefix::new(1),
            false,
            vec![CompiledInstruction::new(1, &(), vec![0])],
        );

        // Sanitize should pass
        assert!(message.sanitize().is_ok());

        // Fee payer should be index 0
        let sanitized =
            SanitizedMessage::try_from_legacy_message(message, &HashSet::new()).unwrap();
        assert_eq!(sanitized.fee_payer(), &payer);
    }
}
