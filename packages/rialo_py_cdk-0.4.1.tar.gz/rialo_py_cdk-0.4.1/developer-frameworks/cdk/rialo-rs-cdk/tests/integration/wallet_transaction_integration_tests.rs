// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

#[cfg(test)]
mod tests {
    use std::str::FromStr;

    use rialo_cdk::{
        constants::ConfigHashPrefix,
        keyring::{InMemoryKeyringProvider, KeyringProvider},
        rpc::types::Pubkey,
        transaction::TransactionBuilder,
    };

    #[tokio::test]
    async fn test_keyring_signing_transaction() {
        // Create keyring
        let provider = InMemoryKeyringProvider::new();
        let keyring = provider
            .create("test_keyring", "password123")
            .await
            .unwrap();

        // Get current time in milliseconds for valid_from
        let valid_from = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("Time went backwards")
            .as_millis() as i64;

        // Build transaction
        let pubkey = Pubkey::from_str(&keyring.pubkey_string()).unwrap();
        let config_hash_prefix = ConfigHashPrefix::new(1);
        let builder = TransactionBuilder::new(pubkey, valid_from, config_hash_prefix);

        // Sign transaction
        let _transaction = builder.build().unwrap();
        let _signed = builder.sign(&keyring).unwrap();

        // Verify signature
        // This will depend on the exact transaction format
    }
}
