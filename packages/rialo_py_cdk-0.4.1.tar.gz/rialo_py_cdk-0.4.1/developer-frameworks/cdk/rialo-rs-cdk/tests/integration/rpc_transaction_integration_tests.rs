// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

#[cfg(test)]
mod tests {
    use std::{str::FromStr, sync::Arc};

    use rialo_cdk::{
        constants::ConfigHashPrefix,
        keyring::{InMemoryKeyringProvider, KeyringProvider},
        rpc::{
            types::{Pubkey, Signature},
            RpcClient,
        },
        transaction::TransactionBuilder,
    };

    use crate::mocks::MockRpcClient;

    const TEST_BASE58_STRING: &str =
        "5VERv8NMvzbJMEkV8xnrLkEaWRtSz9CosKDYjCJjBRnbJLgp8uirBgmQpjKhoR4tjF3ZpRzrFmBV6UjKdiSZkQUW";

    #[tokio::test]
    async fn test_send_transaction() {
        // Setup mock RPC client
        let valid_from = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("Time went backwards")
            .as_millis() as i64;
        let rpc_client = Arc::new(MockRpcClient::new_with_responses(vec![(
            "sendTransaction",
            serde_json::json!(TEST_BASE58_STRING),
        )]));

        // Create keyring
        let keyring_provider = Arc::new(InMemoryKeyringProvider::new());
        let keyring = keyring_provider
            .create("test_keyring", "password123")
            .await
            .unwrap();

        let pubkey = Pubkey::from_str(&keyring.pubkey_string()).unwrap();
        let config_hash_prefix = ConfigHashPrefix::new(1);
        let builder = TransactionBuilder::new(pubkey, valid_from, config_hash_prefix);
        let signed_tx = builder.sign(&keyring).unwrap();

        // Send transaction
        let signature = rpc_client.send_transaction(&signed_tx, None).await.unwrap();

        assert_eq!(signature, Signature::from_str(TEST_BASE58_STRING).unwrap());
    }
}
