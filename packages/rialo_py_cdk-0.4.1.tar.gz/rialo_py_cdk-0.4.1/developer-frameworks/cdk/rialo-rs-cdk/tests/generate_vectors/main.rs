// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Unified cross-platform test vector generator.
//!
//! This generates test vectors for crypto, bincode, and encryption operations
//! to verify cross-platform compatibility between Rust and TypeScript SDKs.

mod bincode_vectors;
mod crypto_vectors;
mod encryption_vectors;

fn main() {
    crypto_vectors::generate();
    bincode_vectors::generate();
    encryption_vectors::generate();
}
