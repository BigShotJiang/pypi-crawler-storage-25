// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Deprecated wallet module - use [`crate::keyring`] instead.
//!
//! This module re-exports types from the [`crate::keyring`] module for backward
//! compatibility. All types are deprecated and will be removed in a future version.
//!
//! # Migration Guide
//!
//! | Old Type | New Type |
//! |----------|----------|
//! | `Wallet` | [`Keyring`](crate::keyring::Keyring) |
//! | `Account` | [`DerivedKeypair`](crate::keyring::DerivedKeypair) |
//! | `WalletProvider` | [`KeyringProvider`](crate::keyring::KeyringProvider) |
//! | `InMemoryWalletProvider` | [`InMemoryKeyringProvider`](crate::keyring::InMemoryKeyringProvider) |
//! | `FileWalletProvider` | [`FileKeyringProvider`](crate::keyring::FileKeyringProvider) |
//!
//! # Example Migration
//!
//! Before:
//! ```rust,ignore
//! use rialo_cdk::wallet::{Wallet, WalletProvider, InMemoryWalletProvider};
//! ```
//!
//! After:
//! ```rust,ignore
//! use rialo_cdk::keyring::{Keyring, KeyringProvider, InMemoryKeyringProvider};
//! ```

// Note: This module is deprecated - marked at `pub mod wallet` in lib.rs

// Re-export submodules from keyring for backward compatibility
#[cfg(feature = "encryption")]
pub use crate::keyring::encryption;
#[cfg(feature = "file-storage")]
pub use crate::keyring::file;
#[cfg(feature = "mnemonic")]
pub use crate::keyring::mnemonic;
pub use crate::keyring::{memory, provider_base};

// Provide a traits module that re-exports from keyring::traits
pub mod traits {
    //! Re-exports from [`crate::keyring::traits`] for backward compatibility.
    #[allow(deprecated)]
    pub use crate::keyring::traits::{Account, Wallet, WalletProvider};
    pub use crate::keyring::traits::{DerivedKeypair, Keyring, KeyringProvider};
}

// Re-export types
#[cfg(feature = "file-storage")]
#[allow(deprecated)]
pub use crate::keyring::file::FileWalletProvider;
#[allow(deprecated)]
pub use crate::keyring::memory::InMemoryWalletProvider;
#[cfg(feature = "mnemonic")]
pub use crate::keyring::mnemonic::{generate_mnemonic, keypair_from_mnemonic};
#[allow(deprecated)]
pub use crate::keyring::traits::{Wallet, WalletProvider};
