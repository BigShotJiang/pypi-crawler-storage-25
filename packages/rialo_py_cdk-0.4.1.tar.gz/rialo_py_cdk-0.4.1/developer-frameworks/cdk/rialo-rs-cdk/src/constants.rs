// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! # Constants
//!
//! This module defines constants used throughout the Rialo SDK.
//!
//! It includes constants for wallet management, network configuration,
//! encryption parameters, RPC interactions, transaction processing,
//! and currency unit conversion.

/// Default number of accounts to generate when creating a new wallet.
pub const DEFAULT_NUM_ACCOUNTS: u32 = 3;

/// Length of the salt used in password-based encryption (in bytes).
pub const SALT_LEN: usize = 16;

/// Length of the nonce used in AES-GCM encryption (in bytes).
pub const NONCE_LEN: usize = 12;

/// Length of the authentication tag used in AES-GCM encryption (in bytes).
pub const TAG_LEN: usize = 16;

/// JSON-RPC protocol version used for node communication.
pub const RPC_VERSION: &str = "2.0";

/// Identifier for the main production network.
pub const NETWORK_MAINNET: &str = "mainnet";

/// Identifier for the test network used for testing before mainnet deployment.
pub const NETWORK_TESTNET: &str = "testnet";

/// Identifier for the development network used during application development.
pub const NETWORK_DEVNET: &str = "devnet";

/// Identifier for a locally running network, typically used for development.
pub const NETWORK_LOCALNET: &str = "localnet";

/// Account address of the system program, which handles fundamental operations.
/// The system program is responsible for creating accounts and transferring tokens.
pub const SYSTEM_PROGRAM_ID: &str = "11111111111111111111111111111111";

/// Instruction index for transfer operations within the system program.
pub const TRANSFER_INSTRUCTION_INDEX: u8 = 2;

/// String identifier for the smallest unit of currency (kelvin).
pub const UNIT_KELVIN: &str = "kelvin";

/// String identifier for the standard unit of currency (RLO).
pub const UNIT_RLO: &str = "RLO";

/// Number of kelvin that make up one RLO (1 billion).
/// Similar to how 1 SOL = 1,000,000,000 lamports in Solana.
pub const KELVIN_PER_RLO: u64 = 1_000_000_000;

/// Size of Ed25519 public key in bytes.
pub const PUBKEY_BYTES: usize = 32;

/// Size of Ed25519 signature in bytes.
pub const SIGNATURE_BYTES: usize = 64;

/// Size of SHA-256 hash in bytes.
pub const HASH_BYTES: usize = 32;

/// Size of Ed25519 private key in bytes.
pub const PRIVATE_KEY_BYTES: usize = 32;

/// Size of Ed25519 keypair in bytes (private key + public key).
pub const KEYPAIR_BYTES: usize = 64;
/// Derivation path coin type for Ed25519. (756 == RLO)
pub const DERIVATION_PATH_COIN_TYPE: u32 = 756;

/// Derivation path purpose for Ed25519. (BIP44)
pub const DERIVATION_PATH_PURPOSE_ED25519: u32 = 44;

/// Default derivation path for hierarchical deterministic wallets.
/// Follows BIP44 standard with Rialo's coin type (756).
/// Coin type 756 follows the telephone keypad convention: R=7, L=5, O=6
pub const BASE_DERIVATION_PATH: &str = "m/44'/756'/";

// Re-export ConfigHashPrefix from the SDK for convenience
pub use rialo_s_message::ConfigHashPrefix;

/// Example config hash prefix value for use in documentation and examples.
///
/// **Important:** This is a placeholder value for documentation purposes only.
/// In production code, you must fetch the actual config hash prefix from the
/// network using the `getRecentValidatorConfigHash` RPC method.
///
/// The value `0xDEAD_BEEF_CAFE_BABE` is deliberately chosen to be obviously
/// fake and easily recognizable in logs/debugging if accidentally used.
///
/// # Example
///
/// ```ignore
/// // In real code, fetch from network:
/// let config_hash_prefix = client.get_config_hash_prefix().await?;
///
/// // For documentation/examples only:
/// use rialo_cdk::constants::EXAMPLE_CONFIG_HASH;
/// let builder = TransactionBuilder::new(payer, valid_from, EXAMPLE_CONFIG_HASH);
/// ```
pub const EXAMPLE_CONFIG_HASH: ConfigHashPrefix = ConfigHashPrefix::new(0xDEAD_BEEF_CAFE_BABE);

// Auto-generated URL constants from JSON schema
include!(concat!(env!("OUT_DIR"), "/url_constants.rs"));
