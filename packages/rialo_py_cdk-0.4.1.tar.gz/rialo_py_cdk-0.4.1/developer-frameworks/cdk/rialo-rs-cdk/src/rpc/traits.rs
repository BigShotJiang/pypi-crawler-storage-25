// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use async_trait::async_trait;
use serde::de::DeserializeOwned;

use crate::error::Result;
// Re-export the generated RpcClient trait so `use rialo_cdk::rpc::traits::RpcClient` works
pub use crate::generated::rpc_client::RpcClient;
pub use crate::rpc::no_wasm::*;

/// A generic trait for making RPC calls with type safety.
///
/// This trait provides a foundation for implementing various RPC clients
/// with the ability to serialize request parameters and deserialize responses.
///
/// # Type Parameters
///
/// * `T` - The type of parameters to send in the RPC request.
/// * `R` - The expected return type from the RPC call.
#[cfg_attr(not(target_arch = "wasm32"), async_trait)]
#[cfg_attr(target_arch = "wasm32", async_trait(?Send))]
pub trait GenericRpcCaller: NoWasmSend + NoWasmSync {
    /// Makes a generic RPC call with the specified method and parameters.
    ///
    /// # Parameters
    ///
    /// * `method` - The RPC method name to call.
    /// * `params` - The parameters to pass to the RPC method.
    ///
    /// # Returns
    ///
    /// The deserialized response from the RPC call.
    ///
    /// # Errors
    ///
    /// Returns an error if the RPC call fails, or if there are serialization/deserialization issues.
    async fn call<T, R>(&self, method: &str, params: T) -> Result<R>
    where
        T: serde::Serialize + NoWasmSend,
        R: DeserializeOwned + NoWasmSend;
}
