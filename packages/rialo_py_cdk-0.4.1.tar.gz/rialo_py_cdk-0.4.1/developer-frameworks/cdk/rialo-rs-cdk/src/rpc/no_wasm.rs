// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

/// Conditional compilation module for WASM vs non-WASM targets.
///
/// This module provides traits that can be used to conditionally require `Send` and `Sync`
/// traits based on the target architecture. This avoids spreading conditional compilation
/// throughout the codebase and reduces duplication of otherwise very similar implementations.
///
/// # Purpose
///
/// In WASM targets (`target_arch = "wasm32"`), the `Send` and `Sync` traits are not
/// available or meaningful since WASM is single-threaded. However, in native targets,
/// these traits are often required for async operations and thread safety.
///
/// By using `NoWasmSend` and `NoWasmSync` instead of `Send` and `Sync` directly,
/// we can write code that works on both WASM and native targets without duplicating
/// implementations or spreading `#[cfg]` attributes throughout the codebase.
///
/// # Usage
///
/// Instead of:
/// ```text
/// async fn my_function<T: Send + Sync>(param: T) { ... }
/// ```
///
/// Use:
/// ```text
/// use crate::rpc::no_wasm::{NoWasmSend, NoWasmSync};
/// async fn my_function<T: NoWasmSend + NoWasmSync>(param: T) { ... }
/// ```
///
/// # Implementation Details
///
/// - On non-WASM targets: `NoWasmSend` requires `Send`, `NoWasmSync` requires `Sync`
/// - On WASM targets: Both traits have no requirements and are implemented for all types
#[cfg(not(target_arch = "wasm32"))]
pub(crate) mod internal {
    /// A trait that conditionally requires `Send` on non-WASM targets.
    ///
    /// On native targets, this trait requires the type to implement `Send`.
    /// On WASM targets, this trait has no requirements.
    pub trait NoWasmSend: Send {}

    /// A trait that conditionally requires `Sync` on non-WASM targets.
    ///
    /// On native targets, this trait requires the type to implement `Sync`.
    /// On WASM targets, this trait has no requirements.
    pub trait NoWasmSync: Sync {}

    // Implement for all types that meet the requirements
    impl<T> NoWasmSend for T where T: Send {}
    impl<T> NoWasmSync for T where T: Sync {}
}

/// Conditional compilation module for WASM targets.
///
/// On WASM targets, `Send` and `Sync` traits are not available or meaningful
/// since WASM is single-threaded. These traits provide a unified interface
/// that works across all targets.
#[cfg(target_arch = "wasm32")]
pub(crate) mod internal {
    /// A trait that conditionally requires `Send` on non-WASM targets.
    ///
    /// On native targets, this trait requires the type to implement `Send`.
    /// On WASM targets, this trait has no requirements.
    pub trait NoWasmSend {}

    /// A trait that conditionally requires `Sync` on non-WASM targets.
    ///
    /// On native targets, this trait requires the type to implement `Sync`.
    /// On WASM targets, this trait has no requirements.
    pub trait NoWasmSync {}

    // Implement for all types since WASM is single-threaded
    impl<T> NoWasmSend for T {}
    impl<T> NoWasmSync for T {}
}

pub use internal::*;
