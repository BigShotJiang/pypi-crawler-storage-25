// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! RPC client and utilities for communicating with the Rialo blockchain.
//!
//! This module provides functionality for making JSON-RPC calls to Rialo nodes,
//! including transaction submission, account queries, and blockchain state retrieval.
//!
//! # Submodules
//!
//! - [`client`]: HTTP-based RPC client implementation (requires `rpc-client` feature)
//! - [`mock_client`]: Mock RPC client for testing (requires `bincode` feature)
//! - [`traits`]: Core `RpcClient` trait defining the RPC interface
//! - [`types`]: Type definitions for RPC requests and responses
//! - [`airdrop`]: Airdrop utilities for development environments (non-WASM only)
//! - [`transaction_utils`]: Transaction confirmation helpers (non-WASM only)
//!
//! # Example
//!
//! ```rust,no_run
//! use rialo_cdk::rpc::{HttpRpcClient, RpcClient};
//!
//! #[tokio::main]
//! async fn main() -> rialo_cdk::Result<()> {
//!     let client = HttpRpcClient::new("http://127.0.0.1:4104".to_string());
//!     
//!     let block_height = client.get_block_height().await?;
//!     println!("Current block height: {}", block_height);
//!     
//!     Ok(())
//! }
//! ```

#[cfg(feature = "rpc-client")]
pub mod client;
#[cfg(feature = "rpc-client")]
mod conversions;
#[cfg(feature = "bincode")]
pub mod mock_client;
pub mod no_wasm;
pub mod traits;
#[cfg(feature = "bincode")]
pub mod transaction;
pub mod types;

// Transaction and airdrop utilities (non-WASM only)
#[cfg(not(target_arch = "wasm32"))]
pub mod airdrop;
#[cfg(not(target_arch = "wasm32"))]
pub mod transaction_utils;

// Re-export utility functions
#[cfg(not(target_arch = "wasm32"))]
pub use airdrop::*;
#[cfg(feature = "rpc-client")]
pub use client::HttpRpcClient;
#[cfg(feature = "bincode")]
pub use transaction::*;
#[cfg(not(target_arch = "wasm32"))]
pub use transaction_utils::*;

pub use crate::generated::rpc_client::RpcClient;
