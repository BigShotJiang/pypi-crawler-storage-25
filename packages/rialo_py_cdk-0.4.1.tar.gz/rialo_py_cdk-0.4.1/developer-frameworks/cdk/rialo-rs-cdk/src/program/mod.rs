// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Program deployment and invocation utilities for the Rialo blockchain.
//!
//! This module provides functionality to deploy and invoke programs on the Rialo blockchain,
//! following the patterns established in the core `crates/rialo` SDK and Solana's program
//! execution model.

pub mod constants;
pub mod deployment;
pub mod invocation;
pub mod source;

#[cfg(test)]
mod simple_test;

#[cfg(feature = "bincode")]
pub use deployment::{
    DeploymentConfig, LoaderType, ProgramDeployment, ProgramDeploymentBuilder, ProgramFormat,
};
pub use invocation::{ProgramInvocation, ProgramInvocationBuilder};
pub use source::{FileProgramDataSource, MemoryProgramDataSource, ProgramDataSource};
