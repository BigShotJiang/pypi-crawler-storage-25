// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Constants used in program operations.

/// The LoaderV4 program ID used to identify programs deployed with LoaderV4.
pub const LOADER_V4_PROGRAM_ID: &str = "LoaderV411111111111111111111111111111111111";

/// Account specification flags used in CLI commands.
pub mod account_flags {
    /// Indicates an account is a signer.
    pub const SIGNER: char = 's';

    /// Indicates an account is writable.
    pub const WRITABLE: char = 'w';

    /// Indicates an account is readonly.
    pub const READONLY: char = 'r';
}

/// Default values for program operations.
pub mod defaults {
    /// Default wallet name when none is specified.
    pub const WALLET_NAME: &str = "default";

    /// Default account index when none is specified.
    pub const ACCOUNT_INDEX: u32 = 0;

    /// Prefix for hex-encoded data strings.
    pub const HEX_PREFIX: &str = "0x";
}

/// Limits and constraints for program operations.
pub mod limits {
    /// Maximum length for Solana instruction data in bytes.
    /// This is based on Solana's transaction size limits.
    pub const MAX_INSTRUCTION_DATA_LEN: usize = 1232;
}

/// Constants for program deployment operations.
pub mod deployment {
    /// Default chunk size for writing program data in bytes.
    /// Must fit within PACKET_DATA_SIZE (4025 bytes) with room for transaction overhead
    /// (~250-300 bytes for signatures, headers, account keys, instruction metadata).
    pub const DEFAULT_CHUNK_SIZE: usize = 3700;

    /// Default maximum number of retries when waiting for buffer account to be ready.
    /// With exponential backoff (1.15x) from 50ms to 1000ms, 350 retries provides
    /// approximately 5+ minutes of total wait time for chunk propagation.
    pub const DEFAULT_MAX_RETRIES: u32 = 350;

    /// Default base delay between retries when waiting for buffer account (in milliseconds).
    pub const DEFAULT_RETRY_BASE_DELAY_MS: u64 = 50;

    /// Default max delay between retries when waiting for buffer account (in milliseconds).
    pub const DEFAULT_RETRY_MAX_DELAY_MS: u64 = 1000;

    /// Buffer balance safety factor to avoid running into shortage of funds errors.
    /// This follows the pattern from crates/rialo which uses a 1.2x buffer factor.
    pub const BUFFER_BALANCE_FACTOR: f64 = 1.2;

    /// Default batch size for chunk confirmations (number of chunks per batch).
    /// Chunks are confirmed in batches during deployment for faster large program deployments.
    /// A batch size of 25 balances between responsiveness (smaller batches) and efficiency
    /// (fewer confirmation rounds for large programs).
    pub const DEFAULT_CONFIRMATION_BATCH_SIZE: usize = 25;
}
