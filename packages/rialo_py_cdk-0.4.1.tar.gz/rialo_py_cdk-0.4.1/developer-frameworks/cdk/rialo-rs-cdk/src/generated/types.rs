// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0
// AUTO-GENERATED FROM spec.wit — DO NOT EDIT

/// A 32-byte hash, base58-encoded on the wire.
pub use rialo_s_sdk::hash::Hash;
// Core crypto primitives — re-exported from the SDK for type safety.
// The WIT spec defines these as `record { bytes: list<u8> }` but in Rust
// we use the real SDK types which have validation, Display, base58 serde, etc.
/// A 32-byte public key, base58-encoded on the wire.
pub use rialo_s_sdk::pubkey::Pubkey as PublicKey;
/// A 64-byte Ed25519 signature, base58-encoded on the wire.
pub use rialo_s_sdk::signature::Signature;
use serde::{Deserialize, Serialize};

/// Smallest unit of the native token.
pub type Kelvin = u64;

/// First 64 bits of the config hash, used for replay protection.
/// Re-exported from the SDK for compatibility with v0_message_utils and other SDK consumers.
pub use rialo_s_message::ConfigHashPrefix;

/// Information about an on-chain account.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountInfo {
    /// Account balance in kelvins.
    pub kelvin: Kelvin,
    /// Owner program public key.
    pub owner: PublicKey,
    /// Account data as encoded strings (typically [encoded_data, encoding_format]).
    pub data: Vec<String>,
    /// Whether the account contains executable code.
    pub executable: bool,
    /// Rent epoch.
    pub rent_epoch: u64,
    /// Account data size in bytes.
    pub space: u64,
}

/// A compiled instruction within a transaction message.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CompiledInstruction {
    /// Index into the account keys array identifying the program.
    pub program_id_index: u8,
    /// Indices into the account keys array for this instruction.
    pub accounts: Vec<u8>,
    /// Instruction data (base58-encoded on the wire).
    pub data: String,
}

/// Header of a transaction message.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MessageHeader {
    /// Number of signatures required.
    pub num_required_signatures: u8,
    /// Number of read-only signed accounts.
    pub num_readonly_signed_accounts: u8,
    /// Number of read-only unsigned accounts.
    pub num_readonly_unsigned_accounts: u8,
}

/// The message portion of a transaction.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TransactionMessage {
    pub header: MessageHeader,
    pub account_keys: Vec<PublicKey>,
    pub instructions: Vec<CompiledInstruction>,
}

/// A full transaction (signatures + message).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TransactionData {
    pub signatures: Vec<Signature>,
    pub message: TransactionMessage,
    /// Timestamp from which the transaction is valid.
    pub valid_from: i64,
}

/// Metadata about transaction execution.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TransactionStatusMetadata {
    /// Fee paid for the transaction in kelvins.
    pub fee: u64,
    /// Error message if the transaction failed, absent if successful.
    pub err: Option<String>,
    /// Log messages emitted during execution (if available).
    pub log_messages: Option<Vec<String>>,
}

/// Full response for a transaction query.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TransactionResponse {
    /// Block height where this transaction was processed.
    pub block_height: u64,
    /// Unix timestamp of the block (if available).
    pub block_time: Option<i64>,
    /// Execution metadata (fee, error).
    pub meta: TransactionStatusMetadata,
    /// The full transaction content.
    pub transaction: TransactionData,
}

/// A transaction paired with its metadata (used in block responses).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TransactionWithMeta {
    /// The full transaction content.
    pub transaction: TransactionData,
    /// Execution metadata (fee, error), absent if not available.
    pub meta: Option<TransactionStatusMetadata>,
}

/// Status of a transaction signature.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SignatureStatus {
    /// Slot in which the transaction was processed.
    pub slot: u64,
    /// Whether the transaction has been executed.
    pub executed: bool,
    /// Error message if the transaction failed.
    pub err: Option<String>,
}

/// Information about the current epoch.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EpochInfo {
    /// Current epoch number.
    pub epoch: u64,
    /// Current slot within the epoch.
    pub slot_index: u64,
    /// Total slots in the epoch.
    pub slots_in_epoch: u64,
    /// Absolute slot number.
    pub absolute_slot: u64,
    /// Current block height.
    pub block_height: u64,
    /// Total transaction count (if available).
    pub transaction_count: Option<u64>,
}

/// Options for submitting a transaction.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SendTransactionOptions {
    /// Skip preflight simulation.
    pub skip_preflight: bool,
    /// Maximum retries by the RPC node.
    pub max_retries: u32,
    /// Wait until the transaction has been executed before returning.
    pub wait_for_execution: bool,
}

/// Options for confirming a transaction.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ConfirmTransactionOptions {
    /// Maximum polling attempts (default: 30).
    pub max_retries: u32,
    /// Delay between polls in milliseconds (default: 1000).
    pub retry_delay_ms: u32,
}

/// Combined options for send-and-confirm.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SendAndConfirmOptions {
    /// Send options.
    pub skip_preflight: bool,
    pub max_retries: u32,
    /// Confirm options.
    pub confirm_max_retries: u32,
    pub confirm_retry_delay_ms: u32,
}

/// Result of a confirmed transaction.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ConfirmedTransaction {
    /// Transaction signature (base58).
    pub signature: String,
    /// Whether the transaction was executed.
    pub executed: bool,
    /// Error message if failed.
    pub err: Option<String>,
}

/// Fee calculation response.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FeeResponse {
    /// The fee in kelvins, absent if message is invalid.
    pub value: Option<u64>,
}

/// Response from blockhash validation.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct IsBlockhashValidResponse {
    /// Slot from the response context.
    pub slot: u64,
    /// Whether the blockhash is still valid.
    pub is_valid: bool,
}

/// Configuration for getSignaturesForAddress.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetSignaturesForAddressConfig {
    /// Maximum number of signatures to return.
    pub limit: Option<u32>,
    /// Search backwards from this signature (base58).
    pub before: Option<String>,
    /// Search forwards from this signature (base58).
    pub until: Option<String>,
}

/// Information about a single signature.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SignatureInfo {
    /// Transaction signature (base58).
    pub signature: String,
    /// Block height where the transaction was processed.
    pub block_height: u64,
    /// Unix timestamp of the block.
    pub block_time: i64,
    /// Error message if the transaction failed.
    pub err: Option<String>,
}

/// Kind of subscription.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum SubscriptionKind {
    Persistent,
    OneShot,
}

/// Metadata about an account used in a subscription instruction.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SubscriptionAccountMeta {
    /// The account's public key (base58).
    pub pubkey: String,
    /// Whether the account must sign the transaction.
    pub is_signer: bool,
    /// Whether the account can be written to during execution.
    pub is_writable: bool,
}

/// A single instruction within a subscription.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SubscriptionInstruction {
    /// The program ID invoked (base58).
    pub program_id: String,
    /// Metadata for the accounts involved in the instruction.
    pub accounts: Vec<SubscriptionAccountMeta>,
    /// Opaque binary data passed to the program.
    pub data: Vec<u8>,
}

/// A subscription record.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Subscription {
    pub kind: SubscriptionKind,
    pub topic: String,
    /// Instructions to be executed when triggered.
    pub instructions: Vec<SubscriptionInstruction>,
    pub subscriber: String,
    /// The account pubkey (base58) that stores the event data.
    pub event_account: Option<String>,
    /// Timestamp range for triggering (start inclusive, end exclusive).
    pub timestamp_range: Option<(u64, u64)>,
}

/// A transaction triggered by a subscription.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TriggeredTransaction {
    /// Transaction signature (base58).
    pub signature: String,
    /// Block number where executed.
    pub block_number: u64,
}

/// Event data from a workflow trigger.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EventData {
    pub topic: String,
}

/// Timestamp range.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TimestampRange {
    pub start: i64,
    pub end: i64,
}

/// Information about what triggered a workflow transaction.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TriggerInfo {
    pub event: EventData,
    pub subscription_pubkey: String,
    pub timestamp_range: Option<TimestampRange>,
    pub event_account: Option<String>,
}

/// Transaction data within a workflow node.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TransactionNodeData {
    pub block_height: u64,
    pub timestamp: i64,
    pub success: bool,
    pub instruction_count: u32,
    pub instruction_program_ids: Vec<String>,
}

/// A node in the workflow lineage tree.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkflowNode {
    /// Transaction signature (base58).
    pub id: String,
    /// Distance from the root transaction.
    pub depth: u32,
    /// Transaction data.
    pub data: TransactionNodeData,
    /// Subscriptions associated with this transaction.
    pub subscriptions: Vec<Subscription>,
    /// Trigger information if this node was triggered by a subscription event.
    pub triggered_by: Option<TriggerInfo>,
    /// Child transaction signatures.
    pub workflow_children: Vec<String>,
    /// Whether more children exist beyond what is shown.
    pub has_more_children: bool,
}

/// Reason for truncating workflow traversal.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum TruncationReason {
    MaxDepth,
    MaxNodes,
    None,
}

/// Workflow lineage request parameters.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetWorkflowLineageRequest {
    /// Root transaction signature (base58).
    pub signature: String,
    /// Maximum traversal depth (1-100, default 3).
    pub max_depth: Option<u32>,
    /// Whether to include event details.
    pub include_events: Option<bool>,
}

/// Workflow lineage response.
/// The lineage tree structure.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct WorkflowLineage {
    /// All nodes (transactions) in the lineage tree.
    pub workflow_nodes: Vec<WorkflowNode>,
}

/// Workflow lineage response.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetWorkflowLineageResponse {
    /// The lineage graph data.
    pub lineage: WorkflowLineage,
    /// Leaf transaction signatures (base58-encoded).
    pub leaves: Vec<String>,
    /// Whether the traversal was truncated due to max-depth.
    pub truncated: bool,
    /// The reason for truncation.
    pub truncation_reason: TruncationReason,
    /// Hints for continuation (base58-encoded).
    pub continuation_hints: Vec<String>,
}

/// Configuration for paginated transaction queries.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetTransactionsConfig {
    /// Maximum number of transactions to return.
    pub limit: Option<u32>,
    /// Cursor for pagination.
    pub before: Option<String>,
}

/// Brief info about a transaction in a paginated list.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TransactionInfo {
    /// Transaction signature (base58).
    pub signature: String,
    /// Slot where the transaction was processed.
    pub slot: u64,
    /// Block time (unix timestamp).
    pub block_time: Option<i64>,
    /// Error message if failed.
    pub err: Option<String>,
    /// Transaction version.
    pub version: Option<String>,
}

/// Filter for what kind of accounts to return.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub enum AccountFilter {
    ProgramAccounts,
    TokenAccounts(Option<String>),
}

/// Configuration for getAccountsByOwner pagination.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetAccountsByOwnerConfig {
    /// Maximum number of accounts to return.
    pub limit: Option<u32>,
    /// Cursor for pagination: accounts after this pubkey (base58).
    pub after: Option<String>,
}

/// An account returned by getAccountsByOwner.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OwnerAccount {
    /// Account public key.
    pub pubkey: PublicKey,
    /// Account information.
    pub account: AccountInfo,
}

/// Pagination metadata.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PaginationInfo {
    pub has_more: bool,
    pub next_cursor: Option<String>,
}

/// A single entry in a getMultipleAccounts response.
/// Absent if the account does not exist.
pub type OptionalAccountInfo = Option<AccountInfo>;

/// Validator health status.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ValidatorHealth {
    pub status: String,
}

/// Connected full node info.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ConnectedNode {
    /// Network public key (hex or base58).
    pub public_key: String,
    /// Connection duration in milliseconds.
    pub connected_ms: u64,
}

/// The TEE's X25519 public key for HPKE encryption.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SecretSharingPubkey {
    /// Hex-encoded public key.
    pub public_key: String,
}

/// Request to submit an epoch change (admin-only).
/// Validator information for epoch change requests.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ValidatorInfoRequest {
    /// Validator stake amount.
    pub stake: u64,
    /// Consensus network address (Multiaddr string).
    pub consensus_address: String,
    /// State sync network address (Multiaddr string).
    pub state_sync_address: String,
    /// Validator hostname.
    pub hostname: String,
    /// Identity public key.
    pub authority_key: String,
    /// Protocol public key.
    pub protocol_key: String,
    /// Network public key.
    pub network_key: String,
    /// Signing public key.
    pub signing_key: String,
}

/// Consensus configuration parameters for an epoch change.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct EpochConsensusConfigRequest {
    /// Number of leaders per round.
    pub num_leaders_per_round: Option<u32>,
    /// Maximum transaction bytes per block.
    pub max_transactions_in_block_bytes: Option<u64>,
    /// Maximum number of transactions per block.
    pub max_num_transactions_in_block: Option<u64>,
    /// Maximum size of a single transaction in bytes.
    pub max_transaction_size_bytes: Option<u64>,
    /// Garbage collection depth.
    pub gc_depth: Option<u32>,
    /// Whether to enable zstd compression.
    pub zstd_compression: Option<bool>,
}

/// Request to submit an epoch change (admin-only).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SubmitEpochChangeRequest {
    /// The new epoch number.
    pub new_epoch: u64,
    /// List of validators for the new epoch.
    pub validators: Vec<ValidatorInfoRequest>,
    /// Optional consensus configuration overrides.
    pub consensus_config: Option<EpochConsensusConfigRequest>,
}

/// Response from submitting an epoch change.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SubmitEpochChangeResponse {
    /// Whether the submission was accepted.
    pub success: bool,
}

/// Configuration for block queries.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetBlockConfig {
    /// Transaction detail level: "full", "signatures", or "none".
    /// Default: "full".
    pub transaction_details: Option<String>,
}

/// Information about a block.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct BlockInfo {
    /// The blockhash (base58).
    pub blockhash: String,
    /// Block height.
    pub block_height: u64,
    /// Unix timestamp of the block.
    pub block_time: i64,
    /// Full transactions with metadata (present when transaction-details = "full").
    pub transactions: Option<Vec<TransactionWithMeta>>,
    /// Transaction signatures only (present when transaction-details = "signatures").
    pub signatures: Option<Vec<String>>,
}

/// Configuration for getAllAccounts.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetAllAccountsConfig {
    /// Encoding for account data (e.g. "base64").
    pub encoding: Option<String>,
    /// Whether to include account data in the response.
    pub include_data: Option<bool>,
}

/// An entry in the getAllAccounts response.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AllAccountsEntry {
    /// Account public key (base58).
    pub pubkey: String,
    /// Account information.
    pub account: AccountInfo,
}

/// State of a stake account.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum StakeState {
    Inactive,
    Activating,
    Active,
    Deactivating,
    Unbonding,
}

/// Information about a stake account.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct StakeAccountInfo {
    /// Current state of the stake account.
    pub state: StakeState,
    /// Total kelvins in the account.
    pub kelvins: u64,
    /// Amount delegated to validator (0 when inactive).
    pub delegated_balance: u64,
    /// Undelegated amount.
    pub undelegated_balance: u64,
    /// Unix timestamp (ms) when ActivateStake was called.
    pub activation_requested: Option<u64>,
    /// Unix timestamp (ms) when DeactivateStake was called.
    pub deactivation_requested: Option<u64>,
    /// Validator info account (base58), absent if not delegated.
    pub validator: Option<String>,
    /// Admin authority (hot wallet, base58).
    pub admin_authority: String,
    /// Withdraw authority (cold wallet, base58).
    pub withdraw_authority: String,
    /// Optional account that receives rewards instead of compounding (base58).
    pub reward_receiver: Option<String>,
}

/// Request parameters for getValidatorAccounts.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GetValidatorAccountsRequest {
    /// If true, return from last frozen epoch; if false, return from pending.
    pub use_frozen: bool,
}

/// Information about a validator account.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ValidatorAccountInfo {
    /// Accumulated commission (kelvins) in the validator account.
    pub commission: u64,
    /// Public key of the validator info account (base58).
    pub pubkey: String,
    /// Signing key / initial withdrawal key (base58).
    pub signing_key: String,
    /// Commission withdrawal key (base58).
    pub withdrawal_key: String,
    /// Aggregate delegated stake for this validator.
    pub stake: u64,
    /// Network address for consensus communication.
    pub address: String,
    /// Network address for state synchronization.
    pub state_sync_address: String,
}

/// SPL Token account balance information.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TokenBalance {
    /// Raw token amount as string.
    pub amount: String,
    /// Number of decimals for the token.
    pub decimals: u8,
    /// Human-readable amount string.
    pub ui_amount_string: String,
}

/// Information about a node in the cluster.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ClusterNodeInfo {
    /// Stake amount in kelvins.
    pub stake: u64,
    /// Network address.
    pub address: String,
    /// Hostname of the node.
    pub hostname: String,
    /// Authority public key (base58).
    pub authority_pubkey: String,
    /// Protocol public key (base58).
    pub protocol_pubkey: String,
    /// Network public key (base58).
    pub network_pubkey: String,
    /// Last committed consensus round (if available).
    pub last_committed_round: Option<u32>,
}

/// A single REX duty assignment.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RexDuty {
    /// Target timestamp for the duty.
    pub target_timestamp: String,
    /// Validators assigned to this duty (base58 pubkeys).
    pub assigned_validators: Vec<String>,
}

/// Information about a REX request and its duties.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RexInfoAndDuties {
    /// Pubkey of account that created the REX (base58).
    pub creator: String,
    /// Hex representation of the REX's nonce.
    pub nonce: String,
    /// Whether the REX is currently active.
    pub is_active: bool,
    /// Description of the REX request.
    pub description: String,
    /// Update frequency.
    pub update_frequency: String,
    /// Starting timestamp.
    pub starting_timestamp: String,
    /// Creation timestamp.
    pub created_at: String,
    /// Number of validators per duty.
    pub validators_per_duty: u32,
    /// Delay in milliseconds for REX request processing.
    pub rex_request_delay_ms: u64,
    /// List of duties expecting updates or commitment.
    pub duties: Vec<RexDuty>,
}
