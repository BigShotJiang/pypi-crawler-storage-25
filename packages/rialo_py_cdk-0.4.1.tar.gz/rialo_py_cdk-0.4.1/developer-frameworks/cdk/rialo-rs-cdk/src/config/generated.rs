// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Generated configuration types from JSON schemas

use typify::import_types;

import_types!(
    schema = "schemas/cdk-config.json",
    struct_builder = true,
    derives = [schemars::JsonSchema]
);
