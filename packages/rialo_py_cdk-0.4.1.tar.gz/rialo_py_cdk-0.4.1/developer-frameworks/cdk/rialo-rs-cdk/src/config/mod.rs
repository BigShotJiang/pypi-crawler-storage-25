// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Configuration management for Rialo CDK applications.
//!
//! This module provides utilities for managing application configuration,
//! including RPC endpoints, wallet paths, and other settings.
//!
//! # Submodules
//!
//! - [`generated`]: Auto-generated configuration types
//! - [`manager`]: Configuration manager with file persistence
//! - [`simple`]: Simple in-memory configuration provider
//!
//! # Example
//!
//! ```rust
//! use rialo_cdk::config::{Config, InMemoryConfigProvider};
//!
//! // Create a config with default settings
//! let config = Config::default();
//!
//! // Or create a custom config
//! let custom_config = Config {
//!     rpc_url: "http://127.0.0.1:4104".to_string(),
//!     network: "localnet".to_string(),
//!     ..Default::default()
//! };
//!
//! // Create an in-memory config provider
//! let provider = InMemoryConfigProvider::new(custom_config);
//! ```

pub mod generated;
pub mod manager;
pub mod simple;

pub use generated::*;
pub use manager::{ConfigManager, ConfigUtils};
pub use simple::{Config, ConfigProvider, InMemoryConfigProvider};
