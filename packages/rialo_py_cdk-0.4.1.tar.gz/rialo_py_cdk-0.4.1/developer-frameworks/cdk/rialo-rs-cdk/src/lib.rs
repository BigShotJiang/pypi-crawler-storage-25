// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! # Rialo Client Development Kit (CDK)
//!
//! The `rialo-cdk` is a comprehensive library that provides all the core functionality
//! needed to interact with the Rialo blockchain. This includes wallet management,
//! transaction building and signing, RPC communication, and configuration management.
//!
//! ## Modules
//!
//! * [`config`] - Configuration management for networks, user preferences, and storage backends
//! * [`constants`] - Blockchain and protocol constants used throughout the CDK
//! * [`error`] - Error types and result handling for the CDK
//! * [`program`] - Program deployment and invocation utilities
//! * [`rpc`] - Client implementation for communicating with Rialo blockchain nodes
//! * [`transaction`] - Transaction building, signing, and serialization
//! * [`utils`] - Utility functions for cryptography, encoding, and other common operations
//! * [`keyring`] - Keyring management including creation, loading, and HD key derivation
//! * [`wallet`] - (Deprecated) Alias for [`keyring`] module for backward compatibility
//!
//! ## Key Components
//!
//! The CDK is designed around a trait-based architecture that allows for flexible
//! implementations while maintaining a consistent interface. Key components include:
//!
//! * Keyring management with BIP39 mnemonic support
//! * Transaction building and signing
//! * RPC client for blockchain communication
//! * Program deployment and invocation
//! * Configuration management with multiple storage backends
//!
//! ## Getting Started
//!
//! ```rust,no_run
//! use rialo_cdk::{Wallet, RpcClient, TransactionBuilder};
//! use rialo_cdk::rpc::HttpRpcClient;
//! use rialo_cdk::wallet::traits::WalletProvider;
//! use rialo_cdk::rpc::types::{Pubkey, Hash};
//! use ed25519_dalek::SigningKey as Keypair;
//! use std::str::FromStr;
//!
//! async fn example() -> rialo_cdk::Result<()> {
//!     // Create a wallet with a generated keypair
//!     let keypair = Keypair::generate(&mut rand::thread_rng());
//!     let wallet = Wallet::new(
//!         "my_wallet".to_string(),
//!         keypair,
//!         Some("your mnemonic phrase".to_string()),
//!         Some("m/44'/501'/0'/0'".to_string()),
//!     );
//!
//!     // Connect to a Rialo node
//!     let client = HttpRpcClient::new("https://api.devnet.rialo.xyz".to_string());
//!
//!     // Check account balance - using appropriate method from WalletProvider trait
//!     let wallet_pubkey = Pubkey::from_str(&wallet.pubkey_string()).unwrap();
//!     let balance = client.get_balance(&wallet_pubkey).await?;
//!
//!     // Build and send a transaction
//!     // Get current time in milliseconds for valid_from
//!     let valid_from = std::time::SystemTime::now()
//!        .duration_since(std::time::UNIX_EPOCH)
//!        .expect("Time went backwards")
//!        .as_millis() as i64;
//!
//!     let recipient_pubkey = Pubkey::from_str("11111111111111111111111111111112").unwrap();
//!     // In production, fetch from network: client.get_recent_validator_config_hash()
//!     // Using EXAMPLE_CONFIG_HASH for documentation purposes only
//!     let config_hash_prefix = rialo_cdk::EXAMPLE_CONFIG_HASH;
//!     let signed_tx = TransactionBuilder::new(wallet_pubkey, valid_from, config_hash_prefix)
//!         .add_transfer_instruction(&wallet_pubkey, &recipient_pubkey, 100)
//!         .sign_with_account(&wallet, 0)?;
//!
//!     let signature = client.send_transaction(&signed_tx, None).await?;
//!
//!     Ok(())
//! }
//! ```

/// Generated types and traits from spec.wit (RPC module only).
pub mod generated;

#[cfg(feature = "rpc-client")]
pub mod client_context;
pub mod config;
pub mod constants;
pub mod error;
pub mod error_codes;
pub mod program;
pub mod rpc;
#[cfg(feature = "rpc-client")]
pub mod sdk;
pub mod secret_encryption;
pub mod transaction;
pub mod utils;

// New keyring module (replaces wallet)
pub mod keyring;

// Deprecated wallet module - re-exports keyring for backward compatibility
#[deprecated(since = "0.2.0", note = "Use keyring module instead")]
pub mod wallet;

// Re-export commonly used types
#[cfg(feature = "rpc-client")]
pub use client_context::ClientContext;
pub use config::{Config, ConfigManager, ConfigProvider, InMemoryConfigProvider};
pub use constants::{
    ConfigHashPrefix, DEFAULT_NUM_ACCOUNTS, EXAMPLE_CONFIG_HASH, URL_DEVNET, URL_LOCALNET,
    URL_MAINNET, URL_TESTNET,
};
pub use error::{Result, RialoError};
// Deprecated wallet types for backward compatibility
#[allow(deprecated)]
pub use keyring::{Account, Wallet, WalletProvider};
// New keyring types (recommended)
pub use keyring::{DerivedKeypair, Keyring, KeyringProvider};
// Re-export utility functions (non-WASM only)
#[cfg(feature = "bincode")]
pub use program::{ProgramDeployment, ProgramInvocation};
#[cfg(not(target_arch = "wasm32"))]
pub use rpc::{request_airdrop_with_confirmation, wait_for_confirmation};
pub use rpc::{types::AccountInfo, RpcClient};
#[cfg(feature = "rpc-client")]
pub use sdk::{create_client_config, Rialo, RialoConfig};
pub use secret_encryption::{encrypt_secret, MAX_SECRET_LENGTH};
pub use transaction::{Instruction, TransactionBuilder};
