// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Keyring management module for the Rialo blockchain.
//!
//! This module provides functionality for managing cryptographic signing keys,
//! including key derivation, storage, and transaction signing. It replaces the
//! previous `wallet` module with more accurate terminology.
//!
//! # Terminology
//!
//! - **Keyring**: A collection of derived keypairs, optionally backed by a mnemonic
//! - **DerivedKeypair**: A single Ed25519 keypair with its derivation metadata
//! - **KeyringProvider**: A trait for keyring storage and lifecycle management
//!
//! # Submodules
//!
//! - [`traits`]: Core keyring and keypair traits (`Keyring`, `DerivedKeypair`, `KeyringProvider`)
//! - [`memory`]: In-memory keyring provider for testing
//! - [`mod@file`]: File-based keyring provider for persistent storage
//! - [`provider_base`]: Base trait with utility methods for providers
//! - [`encryption`]: Encryption utilities for secure key storage
//! - [`mnemonic`]: BIP39 mnemonic and HD key derivation
//!
//! # Example
//!
//! ```rust,no_run
//! use rialo_cdk::keyring::{Keyring, InMemoryKeyringProvider, KeyringProvider};
//! use ed25519_dalek::SigningKey as Keypair;
//!
//! #[tokio::main]
//! async fn main() -> rialo_cdk::Result<()> {
//!     // Create an in-memory keyring provider
//!     let provider = InMemoryKeyringProvider::new();
//!     
//!     // Create a new keyring
//!     let keyring = provider.create("my_keys", "password").await?;
//!     
//!     // Sign a message
//!     let message = b"Hello, Rialo!";
//!     let signature = keyring.sign(message);
//!     
//!     // Get the public key for on-chain operations
//!     let pubkey = keyring.pubkey();
//!     println!("Public key: {}", pubkey);
//!     
//!     Ok(())
//! }
//! ```
//!
//! # Note
//!
//! Keyrings manage cryptographic keys, NOT assets. On-chain accounts hold tokens;
//! keyrings hold the keys needed to sign transactions that interact with those accounts.

#[cfg(feature = "encryption")]
pub mod encryption;
#[cfg(feature = "file-storage")]
pub mod file;
pub mod memory;
#[cfg(feature = "mnemonic")]
pub mod mnemonic;
pub mod provider_base;
pub mod traits;

// Re-export main types
#[cfg(feature = "file-storage")]
pub use file::FileKeyringProvider;
#[cfg(feature = "file-storage")]
#[allow(deprecated)]
pub use file::FileWalletProvider;
pub use memory::InMemoryKeyringProvider;
#[allow(deprecated)]
pub use memory::InMemoryWalletProvider;
pub use provider_base::BaseKeyringProvider;
#[allow(deprecated)]
pub use provider_base::BaseWalletProvider;
// === Backward compatibility re-exports ===
#[allow(deprecated)]
pub use traits::{Account, Wallet, WalletProvider};
pub use traits::{DerivedKeypair, Keyring, KeyringProvider};
