// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Transaction building and signing utilities for the Rialo blockchain.
//!
//! This module provides a fluent API for constructing, signing, and serializing
//! transactions according to the Rialo wire format.
//!
//! # Submodules
//!
//! - [`builder`]: Transaction builder with fluent API for constructing transactions
//! - [`instruction`]: Instruction types and helpers for common operations
//!
//! # Example
//!
//! ```rust,no_run
//! use rialo_cdk::transaction::TransactionBuilder;
//! use rialo_cdk::wallet::Wallet;
//! use rialo_cdk::rpc::types::Pubkey;
//! use rialo_cdk::EXAMPLE_CONFIG_HASH;
//! use std::str::FromStr;
//!
//! fn create_transfer(wallet: &Wallet) -> rialo_cdk::Result<Vec<u8>> {
//!     let fee_payer = wallet.pubkey();
//!     let recipient = Pubkey::from_str("AQTdzvx3HCf1TMwU9CZfSKyj2jJkdmNQWM9tFMrUhmiv")?;
//!
//!     let valid_from = std::time::SystemTime::now()
//!         .duration_since(std::time::UNIX_EPOCH)
//!         .expect("Time went backwards")
//!         .as_millis() as i64;
//!
//!     // In production, fetch from network: client.get_recent_validator_config_hash()
//!     // Using EXAMPLE_CONFIG_HASH for documentation purposes only
//!     let config_hash_prefix = EXAMPLE_CONFIG_HASH;
//!
//!     // Build and sign a transfer transaction
//!     TransactionBuilder::new(fee_payer, valid_from, config_hash_prefix)
//!         .add_transfer_instruction(&fee_payer, &recipient, 1_000_000_000) // 1 RLO
//!         .sign(wallet)
//! }
//! ```

pub mod builder;
pub mod instruction;

pub use builder::TransactionBuilder;
pub use instruction::{AccountMeta, Instruction};
