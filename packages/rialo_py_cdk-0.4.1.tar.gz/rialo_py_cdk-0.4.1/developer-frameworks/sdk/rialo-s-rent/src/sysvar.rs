pub use rialo_s_sdk_ids::sysvar::rent::{check_id, id, ID};
use rialo_s_sysvar_id::impl_sysvar_id;

use crate::Rent;

impl_sysvar_id!(Rent);
