<p align="center">
  <a href="https://solana.com">
    <img alt="Solana" src="https://i.imgur.com/IKyzQ6T.png" width="250" />
  </a>
</p>

# Solana SDK

Use the Solana SDK Crate to write client side applications in Rust.  If writing on-chain programs, use the [Solana Program Crate](https://crates.io/crates/rialo-s-program) instead.

More information about Solana is available in the [Solana documentation](https://solana.com/docs).

The [Solana Program Library](https://github.com/solana-labs/solana-program-library) provides examples of how to use this crate.
