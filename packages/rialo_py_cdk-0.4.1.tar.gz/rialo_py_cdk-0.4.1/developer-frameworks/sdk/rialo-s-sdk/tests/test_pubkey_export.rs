// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

// Simple test to make sure we haven't broken the re-export of the pubkey macro in rialo_s_sdk
#[test]
fn test_sdk_pubkey_export() {
    assert_eq!(
        rialo_s_sdk::pubkey!("ZkTokenProof1111111111111111111111111111111"),
        rialo_s_pubkey::pubkey!("ZkTokenProof1111111111111111111111111111111")
    );
}
