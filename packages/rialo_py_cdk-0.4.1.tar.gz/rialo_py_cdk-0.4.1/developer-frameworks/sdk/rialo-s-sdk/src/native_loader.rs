//! The native loader native program.

use rialo_s_account::{ExecutableAccount, InheritableAccountFields, StoredAccount};
pub use rialo_s_sdk_ids::native_loader::{check_id, id, ID};

/// Create an executable account as a `StoredAccount::Executable` with the given shared object name.
/// This preserves the executable status when stored.
pub fn create_loadable_stored_account_with_fields(
    name: &str,
    (kelvins, rent_epoch): InheritableAccountFields,
) -> StoredAccount {
    let executable_account =
        ExecutableAccount::new(kelvins, name.as_bytes().to_vec(), &id(), rent_epoch);
    StoredAccount::Executable(executable_account)
}
