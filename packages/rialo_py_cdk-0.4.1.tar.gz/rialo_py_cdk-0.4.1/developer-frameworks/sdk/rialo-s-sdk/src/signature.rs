//! Functionality for public and private keys.
#![cfg(feature = "full")]

// legacy module paths
#[deprecated(
    since = "2.2.0",
    note = "Use rialo_s_keypair::signable::Signable instead."
)]
pub use rialo_s_keypair::signable::Signable;
pub use rialo_s_signature::{ParseSignatureError, Signature, SIGNATURE_BYTES};

pub use crate::signer::{keypair::*, null_signer::*, presigner::*, *};
