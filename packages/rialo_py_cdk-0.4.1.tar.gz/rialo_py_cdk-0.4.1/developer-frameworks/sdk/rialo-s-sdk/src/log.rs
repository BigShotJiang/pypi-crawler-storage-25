#![cfg(feature = "program")]

pub use rialo_s_program::log::*;
