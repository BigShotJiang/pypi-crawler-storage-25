pub use rialo_s_sdk_ids::sysvar::epoch_schedule::{check_id, id, ID};
use rialo_s_sysvar_id::impl_sysvar_id;

use crate::EpochSchedule;

impl_sysvar_id!(EpochSchedule);
