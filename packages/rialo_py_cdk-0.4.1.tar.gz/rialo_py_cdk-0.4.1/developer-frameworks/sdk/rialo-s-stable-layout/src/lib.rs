//! Types with stable memory layouts
//!
//! Internal use only; here be dragons!

#![allow(unsafe_code)]

pub mod stable_instruction;
pub mod stable_rc;
pub mod stable_ref_cell;
pub mod stable_slice;
pub mod stable_vec;
