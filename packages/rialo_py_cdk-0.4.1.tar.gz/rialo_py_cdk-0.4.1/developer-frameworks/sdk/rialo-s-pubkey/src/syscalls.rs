/// Syscall definitions used by `rialo_s_pubkey`.
pub use rialo_s_define_syscall::definitions::{
    rlo_create_program_address, rlo_log_pubkey, rlo_try_find_program_address,
};
