#[cfg(not(target_arch = "riscv64"))]
use rialo_s_define_syscall::define_syscall;
#[cfg(target_arch = "riscv64")]
use rialo_s_define_syscall::define_syscall_riscv;
pub use rialo_s_define_syscall::definitions::rlo_get_stack_height;
use rialo_s_pubkey::Pubkey;

use crate::{AccountMeta, ProcessedSiblingInstruction};

#[cfg(not(target_arch = "riscv64"))]
define_syscall!(fn rlo_get_processed_sibling_instruction(index: u64, meta: *mut ProcessedSiblingInstruction, program_id: *mut Pubkey, data: *mut u8, accounts: *mut AccountMeta) -> u64);

#[cfg(target_arch = "riscv64")]
define_syscall_riscv!(fn rlo_get_processed_sibling_instruction(index: u64, meta: *mut ProcessedSiblingInstruction, program_id: *mut Pubkey, data: *mut u8, accounts: *mut AccountMeta) -> u64);
