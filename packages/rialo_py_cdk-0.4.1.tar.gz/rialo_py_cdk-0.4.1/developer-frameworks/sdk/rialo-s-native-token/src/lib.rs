//! Definitions for the native RLO token and its fractional kelvins.

#![allow(clippy::arithmetic_side_effects)]

/// There are 10^9 kelvins in one RLO
pub const KELVINS_PER_RLO: u64 = 1_000_000_000;

/// Approximately convert fractional native tokens (kelvins) into native tokens (RLO)
pub fn kelvins_to_rlo(kelvins: u64) -> f64 {
    kelvins as f64 / KELVINS_PER_RLO as f64
}

/// Approximately convert native tokens (RLO) into fractional native tokens (kelvins)
pub fn rlo_to_kelvins(rlo: f64) -> u64 {
    (rlo * KELVINS_PER_RLO as f64) as u64
}

use std::fmt::{Debug, Display, Formatter, Result};
pub struct Rlo(pub u64);

impl Rlo {
    fn write_in_rlo(&self, f: &mut Formatter<'_>) -> Result {
        write!(
            f,
            "◎{}.{:09}",
            self.0 / KELVINS_PER_RLO,
            self.0 % KELVINS_PER_RLO
        )
    }
}

impl Display for Rlo {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        self.write_in_rlo(f)
    }
}

impl Debug for Rlo {
    fn fmt(&self, f: &mut Formatter<'_>) -> Result {
        self.write_in_rlo(f)
    }
}
