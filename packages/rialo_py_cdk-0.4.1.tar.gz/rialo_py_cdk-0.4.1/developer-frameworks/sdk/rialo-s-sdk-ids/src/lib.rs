#![no_std]

pub mod bpf_loader {
    rialo_s_pubkey::declare_id!("BPFLoader2111111111111111111111111111111111");
}

pub mod bpf_loader_deprecated {
    rialo_s_pubkey::declare_id!("BPFLoader1111111111111111111111111111111111");
}

pub mod bpf_loader_upgradeable {
    rialo_s_pubkey::declare_id!("BPFLoaderUpgradeab1e11111111111111111111111");
}

pub mod compute_budget {
    rialo_s_pubkey::declare_id!("ComputeBudget111111111111111111111111111111");
}

pub mod config {
    rialo_s_pubkey::declare_id!("Config1111111111111111111111111111111111111");
}

pub mod ed25519_program {
    rialo_s_pubkey::declare_id!("Ed25519SigVerify111111111111111111111111111");
}

pub mod feature {
    rialo_s_pubkey::declare_id!("Feature111111111111111111111111111111111111");
}

/// A designated address for burning kelvins.
///
/// Kelvins credited to this address will be removed from the total supply
/// (burned) at the end of the current block.
pub mod incinerator {
    rialo_s_pubkey::declare_id!("1nc1nerator11111111111111111111111111111111");
}

pub mod loader_v4 {
    rialo_s_pubkey::declare_id!("LoaderV411111111111111111111111111111111111");
}

pub mod native_loader {
    rialo_s_pubkey::declare_id!("NativeLoader1111111111111111111111111111111");
}

pub mod risc_v_loader {
    rialo_s_pubkey::declare_id!("RiscVLoader11111111111111111111111111111111");
}

pub mod rex_wasm_v1_loader {
    rialo_s_pubkey::declare_id!("RexWasmV1Loader1111111111111111111111111111");
}

pub mod secp256k1_program {
    rialo_s_pubkey::declare_id!("KeccakSecp256k11111111111111111111111111111");
}

pub mod secp256r1_program {
    rialo_s_pubkey::declare_id!("Secp256r1SigVerify1111111111111111111111111");
}

pub mod system_program {
    rialo_s_pubkey::declare_id!("11111111111111111111111111111111");
}

pub mod sysvar {
    // Owner pubkey for sysvar accounts
    rialo_s_pubkey::declare_id!("Sysvar1111111111111111111111111111111111111");
    pub mod clock {
        rialo_s_pubkey::declare_id!("SysvarC1ock11111111111111111111111111111111");
    }
    pub mod epoch_schedule {
        rialo_s_pubkey::declare_id!("SysvarEpochSchedu1e111111111111111111111111");
    }
    pub mod fees {
        rialo_s_pubkey::declare_id!("SysvarFees111111111111111111111111111111111");
    }
    pub mod instructions {
        rialo_s_pubkey::declare_id!("Sysvar1nstructions1111111111111111111111111");
    }
    pub mod recent_blockhashes {
        rialo_s_pubkey::declare_id!("SysvarRecentB1ockHashes11111111111111111111");
    }
    pub mod rent {
        rialo_s_pubkey::declare_id!("SysvarRent111111111111111111111111111111111");
    }
    pub mod rewards {
        rialo_s_pubkey::declare_id!("SysvarRewards111111111111111111111111111111");
    }
    pub mod stake_history {
        rialo_s_pubkey::declare_id!("SysvarStakeHistory1111111111111111111111111");
    }
}

pub mod zk_token_proof_program {
    rialo_s_pubkey::declare_id!("ZkTokenProof1111111111111111111111111111111");
}

pub mod zk_elgamal_proof_program {
    rialo_s_pubkey::declare_id!("ZkE1Gama1Proof11111111111111111111111111111");
}
