#[cfg(not(target_arch = "riscv64"))]
use rialo_s_define_syscall::define_syscall;
#[cfg(target_arch = "riscv64")]
use rialo_s_define_syscall::define_syscall_riscv;
/// Syscall definitions used by `rialo_s_cpi`.
pub use rialo_s_define_syscall::definitions::{
    rlo_invoke_signed_c, rlo_invoke_signed_rust, rlo_set_return_data,
};
use rialo_s_pubkey::Pubkey;

#[cfg(not(target_arch = "riscv64"))]
define_syscall!(fn rlo_get_return_data(data: *mut u8, length: u64, program_id: *mut Pubkey) -> u64);

#[cfg(target_arch = "riscv64")]
define_syscall_riscv!(fn rlo_get_return_data(data: *mut u8, length: u64, program_id: *mut Pubkey) -> u64);
