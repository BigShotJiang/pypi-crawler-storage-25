<p align="center">
  <a href="https://solana.com">
    <img alt="Solana" src="https://i.imgur.com/IKyzQ6T.png" width="250" />
  </a>
</p>

# Solana Program

Use the Solana Program Crate to write on-chain programs in Rust.  If writing client-side applications, use the [Solana SDK Crate](https://crates.io/crates/rialo-s-sdk) instead.

More information about Solana is available in the [Solana documentation](https://solana.com/docs).

[Solana Program Library](https://github.com/solana-labs/solana-program-library) provides examples of how to use this crate.
