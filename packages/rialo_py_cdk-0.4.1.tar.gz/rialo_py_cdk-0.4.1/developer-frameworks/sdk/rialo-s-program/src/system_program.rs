//! The [system native program][np].
//!
//! [np]: https://docs.solanalabs.com/runtime/programs#system-program
pub use rialo_s_sdk_ids::system_program::{check_id, id, ID};
