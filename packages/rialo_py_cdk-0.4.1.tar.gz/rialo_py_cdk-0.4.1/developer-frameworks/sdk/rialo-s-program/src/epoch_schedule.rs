#[deprecated(
    since = "2.1.0",
    note = "Use solana-clock and solana-epoch-schedule crates instead."
)]
pub use {
    rialo_s_clock::{Epoch, Slot, DEFAULT_SLOTS_PER_EPOCH},
    rialo_s_epoch_schedule::*,
};
