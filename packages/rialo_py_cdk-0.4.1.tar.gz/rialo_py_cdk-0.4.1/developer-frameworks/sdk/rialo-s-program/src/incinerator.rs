#[deprecated(since = "2.2.0", note = "Use `rialo_s_sdk_ids::incinerator` instead")]
pub use rialo_s_sdk_ids::incinerator::{check_id, id, ID};
