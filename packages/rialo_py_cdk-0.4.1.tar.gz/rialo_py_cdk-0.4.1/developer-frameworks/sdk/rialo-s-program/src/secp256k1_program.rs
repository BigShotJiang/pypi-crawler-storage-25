//! The [secp256k1 native program][np].
//!
//! [np]: https://docs.solanalabs.com/runtime/programs#secp256k1-program
//!
//! Constructors for secp256k1 program instructions, and documentation on the
//! program's usage can be found in [`rialo_s_sdk::secp256k1_instruction`].
//!
//! [`rialo_s_sdk::secp256k1_instruction`]: https://docs.rs/solana-sdk/latest/rialo_s_sdk/secp256k1_instruction/index.html
pub use rialo_s_sdk_ids::secp256k1_program::{check_id, id, ID};
