#[deprecated(since = "2.2.0", note = "Use solana-stake-interface instead")]
pub use rialo_s_stake_interface::{
    config, stake_flags, state, tools, MINIMUM_DELINQUENT_EPOCHS_FOR_DEACTIVATION,
};

pub mod instruction {
    #[deprecated(since = "2.2.0", note = "Use solana-stake-interface instead")]
    pub use rialo_s_stake_interface::{error::StakeError, instruction::*};
}
