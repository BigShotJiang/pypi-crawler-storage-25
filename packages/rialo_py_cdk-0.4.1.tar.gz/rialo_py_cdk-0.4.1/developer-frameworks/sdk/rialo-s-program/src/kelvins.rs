//! Re-exports the [`KelvinsError`] type for backwards compatibility.
#[deprecated(
    since = "2.1.0",
    note = "Use rialo_s_instruction::error::KelvinsError instead"
)]
pub use rialo_s_instruction::error::KelvinsError;
