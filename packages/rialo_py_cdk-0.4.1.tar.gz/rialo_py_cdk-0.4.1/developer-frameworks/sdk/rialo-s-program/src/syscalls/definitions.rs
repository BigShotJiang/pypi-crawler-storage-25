#[deprecated(since = "2.1.0", note = "Use `rialo_s_cpi::syscalls` instead")]
pub use rialo_s_cpi::syscalls::{
    rlo_get_return_data, rlo_invoke_signed_c, rlo_invoke_signed_rust, rlo_set_return_data,
};
#[deprecated(
    since = "2.2.0",
    note = "Use `rialo_s_define_syscall::definitions` instead"
)]
pub use rialo_s_define_syscall::definitions::{
    rlo_alt_bn128_compression, rlo_alt_bn128_group_op, rlo_big_mod_exp, rlo_blake3,
    rlo_curve_group_op, rlo_curve_multiscalar_mul, rlo_curve_pairing_map, rlo_curve_validate_point,
    rlo_get_clock_sysvar, rlo_get_epoch_schedule_sysvar, rlo_get_fees_sysvar, rlo_get_random_seed,
    rlo_get_rent_sysvar, rlo_get_sysvar, rlo_keccak256, rlo_poseidon, rlo_remaining_compute_units,
};
#[cfg(target_feature = "static-syscalls")]
pub use rialo_s_define_syscall::sys_hash;
#[deprecated(since = "2.1.0", note = "Use `rialo_s_instruction::syscalls` instead")]
pub use rialo_s_instruction::syscalls::{
    rlo_get_processed_sibling_instruction, rlo_get_stack_height,
};
#[deprecated(since = "2.1.0", note = "Use `rialo_s_msg::syscalls` instead.")]
pub use rialo_s_msg::syscalls::{rlo_log_, rlo_log_64_, rlo_log_compute_units_, rlo_log_data};
#[deprecated(
    since = "2.1.0",
    note = "Use `rialo_s_program_memory::syscalls` instead"
)]
pub use rialo_s_program_memory::syscalls::{rlo_memcmp_, rlo_memcpy_, rlo_memmove_, rlo_memset_};
#[deprecated(since = "2.1.0", note = "Use `rialo_s_pubkey::syscalls` instead")]
pub use rialo_s_pubkey::syscalls::{
    rlo_create_program_address, rlo_log_pubkey, rlo_try_find_program_address,
};
#[deprecated(
    since = "2.1.0",
    note = "Use `rialo_s_secp256k1_recover::rlo_secp256k1_recover` instead"
)]
pub use rialo_s_secp256k1_recover::rlo_secp256k1_recover;
#[deprecated(
    since = "2.1.0",
    note = "Use rialo_s_sha256_hasher::rlo_sha256 instead"
)]
pub use rialo_s_sha256_hasher::rlo_sha256;
