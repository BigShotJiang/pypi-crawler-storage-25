/// Return the remaining compute units the program may consume
#[inline]
pub fn rlo_remaining_compute_units() -> u64 {
    #[cfg(target_os = "solana")]
    unsafe {
        crate::syscalls::rlo_remaining_compute_units()
    }

    #[cfg(not(target_os = "solana"))]
    {
        crate::program_stubs::rlo_remaining_compute_units()
    }
}
