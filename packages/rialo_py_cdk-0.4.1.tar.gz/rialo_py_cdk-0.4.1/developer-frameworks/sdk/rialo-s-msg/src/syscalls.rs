/// Syscall definitions used by `rialo_s_msg`.
pub use rialo_s_define_syscall::definitions::{
    rlo_log_, rlo_log_64_, rlo_log_compute_units_, rlo_log_data,
};
