//! Implementations of syscalls used when `solana-program` is built for non-SBF targets.

#![cfg(not(target_os = "solana"))]

use std::sync::{Arc, LazyLock, RwLock};

use base64::{prelude::BASE64_STANDARD, Engine};
use rialo_s_account_info::AccountInfo;
use rialo_s_instruction::{error::UNSUPPORTED_SYSVAR, Instruction};
use rialo_s_program_error::ProgramResult;
use rialo_s_program_memory::stubs;
use rialo_s_pubkey::Pubkey;

static SYSCALL_STUBS: LazyLock<Arc<RwLock<Box<dyn SyscallStubs>>>> =
    LazyLock::new(|| Arc::new(RwLock::new(Box::new(DefaultSyscallStubs {}))));

// The default syscall stubs may not do much, but `set_syscalls()` can be used
// to swap in alternatives
pub fn set_syscall_stubs(syscall_stubs: Box<dyn SyscallStubs>) -> Box<dyn SyscallStubs> {
    std::mem::replace(&mut SYSCALL_STUBS.write().unwrap(), syscall_stubs)
}

pub trait SyscallStubs: Sync + Send {
    fn rlo_log(&self, message: &str) {
        println!("{message}");
    }
    fn rlo_log_compute_units(&self) {
        rlo_log("SyscallStubs: rlo_log_compute_units() not available");
    }
    fn rlo_remaining_compute_units(&self) -> u64 {
        rlo_log("SyscallStubs: rlo_remaining_compute_units() defaulting to 0");
        0
    }
    fn rlo_invoke_signed(
        &self,
        _instruction: &Instruction,
        _account_infos: &[AccountInfo<'_>],
        _signers_seeds: &[&[&[u8]]],
    ) -> ProgramResult {
        rlo_log("SyscallStubs: rlo_invoke_signed() not available");
        Ok(())
    }
    fn rlo_get_sysvar(
        &self,
        _sysvar_id_addr: *const u8,
        _var_addr: *mut u8,
        _offset: u64,
        _length: u64,
    ) -> u64 {
        UNSUPPORTED_SYSVAR
    }
    fn rlo_get_clock_sysvar(&self, _var_addr: *mut u8) -> u64 {
        UNSUPPORTED_SYSVAR
    }
    fn rlo_get_epoch_schedule_sysvar(&self, _var_addr: *mut u8) -> u64 {
        UNSUPPORTED_SYSVAR
    }
    fn rlo_get_fees_sysvar(&self, _var_addr: *mut u8) -> u64 {
        UNSUPPORTED_SYSVAR
    }
    fn rlo_get_rent_sysvar(&self, _var_addr: *mut u8) -> u64 {
        UNSUPPORTED_SYSVAR
    }

    /// # Safety
    unsafe fn rlo_memcpy(&self, dst: *mut u8, src: *const u8, n: usize) {
        stubs::rlo_memcpy(dst, src, n)
    }
    /// # Safety
    unsafe fn rlo_memmove(&self, dst: *mut u8, src: *const u8, n: usize) {
        stubs::rlo_memmove(dst, src, n)
    }
    /// # Safety
    unsafe fn rlo_memcmp(&self, s1: *const u8, s2: *const u8, n: usize, result: *mut i32) {
        stubs::rlo_memcmp(s1, s2, n, result)
    }
    /// # Safety
    unsafe fn rlo_memset(&self, s: *mut u8, c: u8, n: usize) {
        stubs::rlo_memset(s, c, n)
    }
    fn rlo_get_return_data(&self) -> Option<(Pubkey, Vec<u8>)> {
        None
    }
    fn rlo_set_return_data(&self, _data: &[u8]) {}
    fn rlo_log_data(&self, fields: &[&[u8]]) {
        println!(
            "data: {}",
            fields
                .iter()
                .map(|v| BASE64_STANDARD.encode(v))
                .collect::<Vec<_>>()
                .join(" ")
        );
    }
    fn rlo_get_processed_sibling_instruction(&self, _index: usize) -> Option<Instruction> {
        None
    }
    fn rlo_get_stack_height(&self) -> u64 {
        0
    }
}

struct DefaultSyscallStubs {}
impl SyscallStubs for DefaultSyscallStubs {}

pub fn rlo_log(message: &str) {
    SYSCALL_STUBS.read().unwrap().rlo_log(message);
}

pub fn rlo_log_64(arg1: u64, arg2: u64, arg3: u64, arg4: u64, arg5: u64) {
    rlo_log(&format!(
        "{arg1:#x}, {arg2:#x}, {arg3:#x}, {arg4:#x}, {arg5:#x}"
    ));
}

pub fn rlo_log_compute_units() {
    SYSCALL_STUBS.read().unwrap().rlo_log_compute_units();
}

pub fn rlo_remaining_compute_units() -> u64 {
    SYSCALL_STUBS.read().unwrap().rlo_remaining_compute_units()
}

pub fn rlo_invoke_signed(
    instruction: &Instruction,
    account_infos: &[AccountInfo<'_>],
    signers_seeds: &[&[&[u8]]],
) -> ProgramResult {
    SYSCALL_STUBS
        .read()
        .unwrap()
        .rlo_invoke_signed(instruction, account_infos, signers_seeds)
}

#[allow(dead_code)]
pub(crate) fn rlo_get_sysvar(
    sysvar_id_addr: *const u8,
    var_addr: *mut u8,
    offset: u64,
    length: u64,
) -> u64 {
    SYSCALL_STUBS
        .read()
        .unwrap()
        .rlo_get_sysvar(sysvar_id_addr, var_addr, offset, length)
}

#[cfg(feature = "bincode")]
pub(crate) fn rlo_get_clock_sysvar(var_addr: *mut u8) -> u64 {
    SYSCALL_STUBS.read().unwrap().rlo_get_clock_sysvar(var_addr)
}

#[cfg(feature = "bincode")]
pub(crate) fn rlo_get_epoch_schedule_sysvar(var_addr: *mut u8) -> u64 {
    SYSCALL_STUBS
        .read()
        .unwrap()
        .rlo_get_epoch_schedule_sysvar(var_addr)
}

#[cfg(feature = "bincode")]
pub(crate) fn rlo_get_fees_sysvar(var_addr: *mut u8) -> u64 {
    SYSCALL_STUBS.read().unwrap().rlo_get_fees_sysvar(var_addr)
}

#[cfg(feature = "bincode")]
pub(crate) fn rlo_get_rent_sysvar(var_addr: *mut u8) -> u64 {
    SYSCALL_STUBS.read().unwrap().rlo_get_rent_sysvar(var_addr)
}

pub fn rlo_get_return_data() -> Option<(Pubkey, Vec<u8>)> {
    SYSCALL_STUBS.read().unwrap().rlo_get_return_data()
}

pub fn rlo_set_return_data(data: &[u8]) {
    SYSCALL_STUBS.read().unwrap().rlo_set_return_data(data)
}

pub fn rlo_log_data(data: &[&[u8]]) {
    SYSCALL_STUBS.read().unwrap().rlo_log_data(data)
}

pub fn rlo_get_processed_sibling_instruction(index: usize) -> Option<Instruction> {
    SYSCALL_STUBS
        .read()
        .unwrap()
        .rlo_get_processed_sibling_instruction(index)
}

pub fn rlo_get_stack_height() -> u64 {
    SYSCALL_STUBS.read().unwrap().rlo_get_stack_height()
}
