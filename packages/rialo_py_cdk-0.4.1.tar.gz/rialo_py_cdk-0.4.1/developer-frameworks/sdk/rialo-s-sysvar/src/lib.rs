#![cfg_attr(docsrs, feature(doc_auto_cfg))]
#![cfg_attr(feature = "frozen-abi", feature(min_specialization))]
#![allow(unsafe_code)]
#![allow(clippy::ptr_as_ptr)]
#![allow(clippy::disallowed_methods)]
//! Access to special accounts with dynamically-updated data.
//!
//! Sysvars are special accounts that contain dynamically-updated data about the
//! network cluster, the blockchain history, and the executing transaction. Each
//! sysvar is defined in its own submodule within this module. The [`clock`],
//! [`epoch_schedule`], and [`rent`] sysvars are most useful to on-chain programs.
//!
//! Simple sysvars implement the [`Sysvar::get`] method, which loads a sysvar
//! directly from the runtime, as in this example that logs the `clock` sysvar:
//!
//! ```
//! use rialo_s_account_info::AccountInfo;
//! use rialo_s_msg::msg;
//! use rialo_s_sysvar::Sysvar;
//! use rialo_s_program_error::ProgramResult;
//! use rialo_s_pubkey::Pubkey;
//!
//! fn process_instruction(
//!     program_id: &Pubkey,
//!     accounts: &[AccountInfo],
//!     instruction_data: &[u8],
//! ) -> ProgramResult {
//!     let clock = rialo_s_clock::Clock::get()?;
//!     msg!("clock: {:#?}", clock);
//!     Ok(())
//! }
//! ```
//!
//! Since Solana sysvars are accounts, if the `AccountInfo` is provided to the
//! program, then the program can deserialize the sysvar with
//! [`Sysvar::from_account_info`] to access its data, as in this example that
//! again logs the [`clock`] sysvar.
//!
//! ```
//! use rialo_s_account_info::{AccountInfo, next_account_info};
//! use rialo_s_msg::msg;
//! use rialo_s_sysvar::Sysvar;
//! use rialo_s_program_error::ProgramResult;
//! use rialo_s_pubkey::Pubkey;
//!
//! fn process_instruction(
//!     program_id: &Pubkey,
//!     accounts: &[AccountInfo],
//!     instruction_data: &[u8],
//! ) -> ProgramResult {
//!     let account_info_iter = &mut accounts.iter();
//!     let clock_account = next_account_info(account_info_iter)?;
//!     let clock = rialo_s_clock::Clock::from_account_info(&clock_account)?;
//!     msg!("clock: {:#?}", clock);
//!     Ok(())
//! }
//! ```
//!
//! When possible, programs should prefer to call `Sysvar::get` instead of
//! deserializing with `Sysvar::from_account_info`, as the latter imposes extra
//! overhead of deserialization while also requiring the sysvar account address
//! be passed to the program, wasting the limited space available to
//! transactions. Deserializing sysvars that can instead be retrieved with
//! `Sysvar::get` should be only be considered for compatibility with older
//! programs that pass around sysvar accounts.
//!
//! Some sysvars are too large to deserialize within a program, and
//! `Sysvar::from_account_info` returns an error, or the serialization attempt
//! will exhaust the program's compute budget. Some sysvars do not implement
//! `Sysvar::get` and return an error. Some sysvars have custom deserializers
//! that do not implement the `Sysvar` trait. These cases are documented in the
//! modules for individual sysvars.
//!
//! All sysvar accounts are owned by the account identified by [`sysvar::ID`].
//!
//! [`sysvar::ID`]: https://docs.rs/solana-sdk-ids/latest/rialo_s_sdk_ids/sysvar/constant.ID.html
//!
//! For more details see the Solana [documentation on sysvars][sysvardoc].
//!
//! [sysvardoc]: https://docs.solanalabs.com/runtime/sysvars

// hidden re-exports to make macros work
pub mod __private {
    #[cfg(target_os = "solana")]
    pub use rialo_s_define_syscall::definitions;
    pub use rialo_s_program_entrypoint::SUCCESS;
    pub use rialo_s_program_error::ProgramError;
}
use rialo_s_pubkey::Pubkey;
#[allow(deprecated)]
#[doc(inline)]
#[deprecated(
    since = "2.0.0",
    note = "please use `rialo_s_sdk::reserved_account_keys::ReservedAccountKeys` instead"
)]
pub use sysvar_ids::ALL_IDS;
#[cfg(feature = "bincode")]
use {
    rialo_s_account_info::AccountInfo, rialo_s_program_error::ProgramError,
    rialo_s_sysvar_id::SysvarId,
};

pub mod clock;
pub mod epoch_schedule;
pub mod fees;
pub mod program_stubs;
pub mod recent_blockhashes;
pub mod rent;
pub mod rewards;

#[deprecated(
    since = "2.0.0",
    note = "please use `rialo_s_sdk::reserved_account_keys::ReservedAccountKeys` instead"
)]
mod sysvar_ids {
    use std::sync::LazyLock;

    use super::*;
    // This will be deprecated and so this list shouldn't be modified
    pub static ALL_IDS: LazyLock<Vec<Pubkey>> = LazyLock::new(|| {
        vec![
            clock::id(),
            epoch_schedule::id(),
            #[allow(deprecated)]
            fees::id(),
            #[allow(deprecated)]
            recent_blockhashes::id(),
            rent::id(),
            rewards::id(),
            rialo_s_sdk_ids::sysvar::instructions::id(),
        ]
    });
}

/// Returns `true` of the given `Pubkey` is a sysvar account.
#[deprecated(
    since = "2.0.0",
    note = "please check the account's owner or use rialo_s_sdk::reserved_account_keys::ReservedAccountKeys instead"
)]
#[allow(deprecated)]
pub fn is_sysvar_id(id: &Pubkey) -> bool {
    ALL_IDS.iter().any(|key| key == id)
}

#[cfg(feature = "bincode")]
/// A type that holds sysvar data.
pub trait Sysvar:
    SysvarId + Default + Sized + serde::Serialize + serde::de::DeserializeOwned
{
    /// The size in bytes of the sysvar as serialized account data.
    fn size_of() -> usize {
        bincode::serialized_size(&Self::default()).unwrap() as usize
    }

    /// Deserializes the sysvar from its `AccountInfo`.
    ///
    /// # Errors
    ///
    /// If `account_info` does not have the same ID as the sysvar this function
    /// returns [`ProgramError::InvalidArgument`].
    fn from_account_info(account_info: &AccountInfo<'_>) -> Result<Self, ProgramError> {
        if !Self::check_id(account_info.unsigned_key()) {
            return Err(ProgramError::InvalidArgument);
        }
        bincode::deserialize(&account_info.data.borrow()).map_err(|_| ProgramError::InvalidArgument)
    }

    /// Serializes the sysvar to `AccountInfo`.
    ///
    /// # Errors
    ///
    /// Returns `None` if serialization failed.
    fn to_account_info(&self, account_info: &mut AccountInfo<'_>) -> Option<()> {
        bincode::serialize_into(&mut account_info.data.borrow_mut()[..], self).ok()
    }

    /// Load the sysvar directly from the runtime.
    ///
    /// This is the preferred way to load a sysvar. Calling this method does not
    /// incur any deserialization overhead, and does not require the sysvar
    /// account to be passed to the program.
    ///
    /// Not all sysvars support this method. If not, it returns
    /// [`ProgramError::UnsupportedSysvar`].
    fn get() -> Result<Self, ProgramError> {
        Err(ProgramError::UnsupportedSysvar)
    }
}

/// Implements the [`Sysvar::get`] method for both SBF and host targets.
#[macro_export]
macro_rules! impl_sysvar_get {
    ($syscall_name:ident) => {
        fn get() -> Result<Self, $crate::__private::ProgramError> {
            let mut var = Self::default();
            let var_addr = &mut var as *mut _ as *mut u8;

            #[cfg(target_os = "solana")]
            let result = unsafe { $crate::__private::definitions::$syscall_name(var_addr) };

            #[cfg(not(target_os = "solana"))]
            let result = $crate::program_stubs::$syscall_name(var_addr);

            match result {
                $crate::__private::SUCCESS => Ok(var),
                e => Err(e.into()),
            }
        }
    };
}

/// Handler for retrieving a slice of sysvar data from the `rlo_get_sysvar`
/// syscall.
#[allow(dead_code)]
#[cfg(feature = "bytemuck")]
fn get_sysvar(
    dst: &mut [u8],
    sysvar_id: &Pubkey,
    offset: u64,
    length: u64,
) -> Result<(), rialo_s_program_error::ProgramError> {
    // Check that the provided destination buffer is large enough to hold the
    // requested data.
    if dst.len() < length as usize {
        return Err(rialo_s_program_error::ProgramError::InvalidArgument);
    }

    let sysvar_id = sysvar_id as *const _ as *const u8;
    let var_addr = dst as *mut _ as *mut u8;

    #[cfg(target_os = "solana")]
    let result = unsafe {
        rialo_s_define_syscall::definitions::rlo_get_sysvar(sysvar_id, var_addr, offset, length)
    };

    #[cfg(not(target_os = "solana"))]
    let result = crate::program_stubs::rlo_get_sysvar(sysvar_id, var_addr, offset, length);

    match result {
        rialo_s_program_entrypoint::SUCCESS => Ok(()),
        e => Err(e.into()),
    }
}

#[cfg(test)]
mod tests {
    use std::{cell::RefCell, rc::Rc};

    use rialo_s_clock::Epoch;
    use rialo_s_program_error::ProgramError;
    use rialo_s_pubkey::Pubkey;
    use serde_derive::{Deserialize, Serialize};

    use super::*;

    #[repr(C)]
    #[derive(Serialize, Deserialize, Debug, Default, PartialEq, Eq)]
    struct TestSysvar {
        something: Pubkey,
    }
    rialo_s_pubkey::declare_id!("TestSysvar111111111111111111111111111111111");
    impl rialo_s_sysvar_id::SysvarId for TestSysvar {
        fn id() -> rialo_s_pubkey::Pubkey {
            id()
        }

        fn check_id(pubkey: &rialo_s_pubkey::Pubkey) -> bool {
            check_id(pubkey)
        }
    }
    impl Sysvar for TestSysvar {}

    #[test]
    fn test_sysvar_account_info_to_from() {
        let test_sysvar = TestSysvar::default();
        let key = id();
        let wrong_key = Pubkey::new_unique();
        let owner = Pubkey::new_unique();
        let mut kelvins = 42;
        let mut data = vec![0_u8; TestSysvar::size_of()];
        let mut account_info = AccountInfo::new(
            &key,
            false,
            true,
            &mut kelvins,
            &mut data,
            &owner,
            false,
            Epoch::default(),
        );

        test_sysvar.to_account_info(&mut account_info).unwrap();
        let new_test_sysvar = TestSysvar::from_account_info(&account_info).unwrap();
        assert_eq!(test_sysvar, new_test_sysvar);

        account_info.key = &wrong_key;
        assert_eq!(
            TestSysvar::from_account_info(&account_info),
            Err(ProgramError::InvalidArgument)
        );

        let mut small_data = vec![];
        account_info.data = Rc::new(RefCell::new(&mut small_data));
        assert_eq!(test_sysvar.to_account_info(&mut account_info), None);
    }
}
