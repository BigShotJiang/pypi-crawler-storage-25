//! RISC-V syscall definitions using PolkaVM imports.
#![allow(unsafe_code)]

use crate::define_syscall_riscv;

#[unsafe(no_mangle)]
pub extern "C" fn rlo_log__(message: *const u8, len: u64) {
    unsafe { rlo_log_(message, len) }
}

#[unsafe(no_mangle)]
pub extern "C" fn abort() -> ! {
    unsafe {
        rlo_abort();
        unreachable!()
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn memcpy(dst: *mut u8, src: *const u8, n: usize) -> *mut u8 {
    rlo_memcpy_(dst, src, n as u64);
    dst
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn memset(s: *mut u8, c: i32, n: usize) -> *mut u8 {
    rlo_memset_(s, c as u32, n as u64);
    s
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn memcmp(s1: *const u8, s2: *const u8, n: usize) -> i32 {
    let mut result = 0i32;

    rlo_memcmp_(s1, s2, n as u64, &mut result as *mut _ as *mut i32);
    result
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn memmove(dst: *mut u8, src: *const u8, n: usize) -> *mut u8 {
    rlo_memmove_(dst, src, n as u64);
    dst
}

// =============================================================================
// Syscall definitions (mirrors ebpf.rs)
// =============================================================================

define_syscall_riscv!(fn rlo_secp256k1_recover(hash: *const u8, recovery_id: u64, signature: *const u8, result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_poseidon(parameters: u64, endianness: u64, vals: *const u8, val_len: u64, hash_result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_invoke_signed_c(instruction_addr: *const u8, account_infos_addr: *const u8, account_infos_len: u64, signers_seeds_addr: *const u8, signers_seeds_len: u64) -> u64);
define_syscall_riscv!(fn rlo_invoke_signed_rust(instruction_addr: *const u8, account_infos_addr: *const u8, account_infos_len: u64, signers_seeds_addr: *const u8, signers_seeds_len: u64) -> u64);
define_syscall_riscv!(fn rlo_set_return_data(data: *const u8, length: u64));
define_syscall_riscv!(fn rlo_get_stack_height() -> u64);
define_syscall_riscv!(fn rlo_log_(message: *const u8, len: u64));
define_syscall_riscv!(fn rlo_log_64_(arg1: u64, arg2: u64, arg3: u64, arg4: u64, arg5: u64));
define_syscall_riscv!(fn rlo_log_compute_units_());
define_syscall_riscv!(fn rlo_log_data(data: *const u8, data_len: u64));
define_syscall_riscv!(fn rlo_memcpy_(dst: *mut u8, src: *const u8, n: u64));
define_syscall_riscv!(fn rlo_memmove_(dst: *mut u8, src: *const u8, n: u64));
define_syscall_riscv!(fn rlo_memcmp_(s1: *const u8, s2: *const u8, n: u64, result: *mut i32));
// NOTE: rlo_memset_ uses u32 for `c` due to PolkaVM ABI limitation (no u8 support).
define_syscall_riscv!(fn rlo_memset_(s: *mut u8, c: u32, n: u64));
define_syscall_riscv!(fn rlo_log_pubkey(pubkey_addr: *const u8));
define_syscall_riscv!(fn rlo_create_program_address(seeds_addr: *const u8, seeds_len: u64, program_id_addr: *const u8, address_bytes_addr: *const u8) -> u64);
define_syscall_riscv!(fn rlo_try_find_program_address(seeds_addr: *const u8, seeds_len: u64, program_id_addr: *const u8, address_bytes_addr: *const u8, bump_seed_addr: *const u8) -> u64);
define_syscall_riscv!(fn rlo_sha256(vals: *const u8, val_len: u64, hash_result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_keccak256(vals: *const u8, val_len: u64, hash_result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_blake3(vals: *const u8, val_len: u64, hash_result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_curve_validate_point(curve_id: u64, point_addr: *const u8, result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_curve_group_op(curve_id: u64, group_op: u64, left_input_addr: *const u8, right_input_addr: *const u8, result_point_addr: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_curve_multiscalar_mul(curve_id: u64, scalars_addr: *const u8, points_addr: *const u8, points_len: u64, result_point_addr: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_curve_pairing_map(curve_id: u64, point: *const u8, result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_alt_bn128_group_op(group_op: u64, input: *const u8, input_size: u64, result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_big_mod_exp(params: *const u8, result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_remaining_compute_units() -> u64);
define_syscall_riscv!(fn rlo_alt_bn128_compression(op: u64, input: *const u8, input_size: u64, result: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_get_sysvar(sysvar_id_addr: *const u8, result: *mut u8, offset: u64, length: u64) -> u64);
define_syscall_riscv!(fn rlo_get_clock_sysvar(addr: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_get_epoch_schedule_sysvar(addr: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_get_rent_sysvar(addr: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_get_fees_sysvar(addr: *mut u8) -> u64);

// get random seed from the bank
define_syscall_riscv!(fn rlo_get_random_seed(addr: *mut u8) -> u64);

// RISC-V only syscalls (not registered in BPF loader)
define_syscall_riscv!(fn rlo_get_last_restart_slot(addr: *mut u8) -> u64);
define_syscall_riscv!(fn rlo_get_epoch_rewards_sysvar(addr: *mut u8) -> u64);

// Host function for aborts (called by libstd/libcore)
define_syscall_riscv!(fn rlo_abort());

// Host function for dynamic account loading
define_syscall_riscv!(fn rlo_load_account(pubkey: *const u8, addr: *mut u8) -> u64);
