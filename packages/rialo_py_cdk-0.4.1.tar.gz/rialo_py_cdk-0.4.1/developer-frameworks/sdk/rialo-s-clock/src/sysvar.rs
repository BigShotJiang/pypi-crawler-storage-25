pub use rialo_s_sdk_ids::sysvar::clock::{check_id, id, ID};
use rialo_s_sysvar_id::impl_sysvar_id;

use crate::Clock;

impl_sysvar_id!(Clock);
