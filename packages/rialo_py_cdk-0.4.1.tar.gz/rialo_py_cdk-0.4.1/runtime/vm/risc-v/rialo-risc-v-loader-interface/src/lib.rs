// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

use rialo_s_pubkey::Pubkey;

pub mod instruction;

rialo_s_pubkey::declare_id!("RiscVLoader11111111111111111111111111111111");

#[repr(u64)]
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub enum RiscVLoaderStatus {
    /// Program is in maintenance
    Retracted,
    /// Program is ready to be executed
    Deployed,
    /// Same as `Deployed`, but can not be retracted anymore
    Finalized,
}

/// RiscVLoader account states
#[repr(C)]
#[derive(Debug, PartialEq, Eq, Clone, Copy)]
pub struct RiscVLoaderState {
    /// Slot in which the program was last deployed, retracted or initialized.
    pub slot: u64,
    /// Address of signer which can send program management instructions when the status is not finalized.
    /// Otherwise a forwarding to the next version of the finalized program.
    pub authority_address_or_next_version: Pubkey,
    /// Deployment status.
    pub status: RiscVLoaderStatus,
    // The raw program data follows this serialized structure in the
    // account's data.
}

impl RiscVLoaderState {
    /// Size of a serialized program account.
    pub const fn program_data_offset() -> usize {
        std::mem::size_of::<Self>()
    }
}
