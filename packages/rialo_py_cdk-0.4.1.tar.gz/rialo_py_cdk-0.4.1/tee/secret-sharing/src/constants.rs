// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

/// Size of ChaCha20-Poly1305 AEAD tag in bytes.
pub const CHACHA20_POLY1305_TAG_SIZE: usize = 16;

/// Size of HPKE ciphertext for secret sharing (32-byte key + 16-byte tag).
pub const HPKE_CIPHERTEXT_SIZE: usize = rialo_types::X25519_KEY_SIZE + CHACHA20_POLY1305_TAG_SIZE;

/// HPKE info string for secret sharing operations.
///
/// This value is used as the info parameter in HPKE setup operations for key derivation context.
/// Both key wrapping operations and user secret sharing operations use the same info string
/// to ensure consistent cryptographic domain separation.
///
/// Version: v1 indicates the protocol version for secret sharing operations.
pub const SECRET_SHARING_HPKE_INFO: &[u8] = b"rialo/tee/secret-sharing-hpke/v1";

/// Associated Authenticated Data (AAD) for user secret encryption/decryption.
///
/// This value is used as AAD in HPKE operations for user-submitted secret payloads.
/// Both the client-side encryption and TEE-side decryption must use the same value
/// to ensure successful authentication and decryption.
///
/// Version: v1 indicates the format/protocol version for user secret handling.
pub const USER_SECRET_AAD: &[u8] = b"rex-secret-v1";
