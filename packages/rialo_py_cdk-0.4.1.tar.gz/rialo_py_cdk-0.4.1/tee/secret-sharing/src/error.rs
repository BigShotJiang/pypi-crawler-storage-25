// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

/// Errors surfaced by the secret-sharing engine and helpers.
#[derive(Debug, thiserror::Error)]
pub enum SecretSharingError {
    /// HPKE sealing failed (e.g., random generation, context/seal error).
    #[error("Wrap failed: {0}")]
    WrapFailed(String),

    /// HPKE opening failed (e.g., decapsulation, AEAD tag failure, AAD mismatch).
    #[error("Unwrap failed: {0}")]
    UnwrapFailed(String),

    /// Envelope is structurally invalid (wrong lengths, etc.).
    #[error("Envelope invalid: {0}")]
    EnvelopeInvalid(String),

    /// Received an envelope addressed to a different receiver.
    #[error("Recipient mismatch")]
    RecipientMismatch,

    /// OS RNG or entropy source failure.
    #[error("RNG failure: {0}")]
    RngFailed(&'static str),

    /// Invalid KeyId value provided.
    #[error("Invalid KeyId: {reason}")]
    InvalidKeyId { reason: String },

    /// Attempted to generate a key for an epoch that already has a key.
    #[error("Duplicate KeyId for epoch {epoch}: key already exists")]
    DuplicateKeyId { epoch: u64 },
}
