// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Minimal TEE type definitions shared across crates.
//!
//! This crate exists to break dependency cycles: both `rialo-types` (which
//! re-exports [`TeeType`]) and lightweight SDK crates can depend on it without
//! pulling in heavy transitive dependencies.

#![cfg_attr(feature = "frozen-abi", feature(min_specialization))]

use borsh::{BorshDeserialize, BorshSerialize};
use serde::{Deserialize, Serialize};

// TODO: Decouple Cloud provider and TEE types
// <https://linear.app/subzero-labs/issue/SUB-931/decouple-cloud-provider-from-tee-type-in-core-types>
#[cfg_attr(
    feature = "frozen-abi",
    derive(
        rialo_frozen_abi_macro::AbiExample,
        rialo_frozen_abi_macro::AbiEnumVisitor
    )
)]
#[derive(
    Clone,
    Copy,
    Debug,
    Default,
    Eq,
    Hash,
    PartialEq,
    Serialize,
    Deserialize,
    BorshSerialize,
    BorshDeserialize,
)]
#[borsh(use_discriminant = true)]
#[non_exhaustive]
pub enum TeeType {
    SevSnp = 1,
    #[default]
    AwsSevSnp = 2,
    AzureSevSnp = 3,
    IntelTdx = 4,
    #[cfg(feature = "testing")]
    Mock = 254,
}

impl std::fmt::Display for TeeType {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TeeType::AzureSevSnp => write!(f, "Azure SEV-SNP"),
            TeeType::AwsSevSnp => write!(f, "AWS SEV-SNP EC2 with NitroTPM"),
            TeeType::SevSnp => write!(f, "Generic SEV-SNP"),
            TeeType::IntelTdx => write!(f, "Intel TDX"),
            // This is a special TEE type used for testing purposes only.
            // It should never be included in production.
            #[cfg(feature = "testing")]
            TeeType::Mock => write!(f, "Mock TEE"),
        }
    }
}

/// The input data needed to create a new image measurement.
///
/// Used both during genesis initialization and by the `AddMeasurement` instruction.
#[cfg_attr(feature = "frozen-abi", derive(rialo_frozen_abi_macro::AbiExample))]
#[derive(Clone, Debug, Eq, PartialEq, BorshSerialize, BorshDeserialize, Serialize, Deserialize)]
pub struct ImageMeasurementInput {
    pub label: String,
    pub tee_type: TeeType,
    pub measurement_data: Vec<u8>,
    pub metadata_uri: String,
}
