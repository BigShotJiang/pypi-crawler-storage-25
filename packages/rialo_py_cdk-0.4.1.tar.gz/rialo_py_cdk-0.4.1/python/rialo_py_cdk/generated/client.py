# Copyright (c) Subzero Labs, Inc.
# SPDX-License-Identifier: Apache-2.0
# AUTO-GENERATED FROM spec.wit — DO NOT EDIT

from typing import Any, Optional
from .._rialo_py_cdk import PyHttpRpcClient as _PyHttpRpcClient
from .rpc_client import RpcClient
from .types import *  # noqa: F401,F403


class RialoRPCClient(RpcClient):
    """Spec-driven typed RPC client. Delegates to the PyO3 Rust backend."""

    def __init__(self, url: str):
        self._inner = _PyHttpRpcClient(url)

    def __getattr__(self, name: str) -> Any:
        """Fall through to the underlying PyO3 client for non-spec methods."""
        return getattr(self._inner, name)

    # ── Generated methods ──

    def get_balance(self, pubkey: Any) -> int:
        return self._inner.get_balance(pubkey)

    def get_account_info(self, pubkey: Any) -> AccountInfo:
        return AccountInfo.from_dict(self._inner.get_account_info(pubkey))

    def get_block_height(self) -> int:
        return self._inner.get_block_height()

    def get_block_height_with_config(self, min_context_slot: Optional[int]) -> int:
        return self._inner.get_block_height_with_config(min_context_slot)

    def get_transaction(self, sig: Any) -> TransactionResponse:
        return TransactionResponse.from_dict(self._inner.get_transaction(sig))

    def get_transaction_count(self) -> int:
        return self._inner.get_transaction_count()

    def get_minimum_balance_for_rent_exemption(self, data_size: int) -> int:
        return self._inner.get_minimum_balance_for_rent_exemption(data_size)

    def get_signature_statuses(self, signatures: list[Any]) -> list[Optional[SignatureStatus]]:
        return [SignatureStatus.from_dict(x) if x is not None else None for x in self._inner.get_signature_statuses(signatures)]

    def get_signatures_for_address(self, address: Any, config: Optional[GetSignaturesForAddressConfig]) -> list[SignatureInfo]:
        return [SignatureInfo.from_dict(x) for x in self._inner.get_signatures_for_address(address, config)]

    def get_epoch_info(self) -> EpochInfo:
        return EpochInfo.from_dict(self._inner.get_epoch_info())

    def get_fee_for_message(self, message: str) -> FeeResponse:
        return FeeResponse.from_dict(self._inner.get_fee_for_message(message))

    def get_multiple_accounts(self, pubkeys: list[Any]) -> list[OptionalAccountInfo]:
        return [OptionalAccountInfo.from_dict(x) for x in self._inner.get_multiple_accounts(pubkeys)]

    def get_accounts_by_owner(self, owner: Any, filter: Optional[AccountFilter], config: Optional[GetAccountsByOwnerConfig]) -> tuple[list[OwnerAccount], Optional[PaginationInfo]]:
        return self._inner.get_accounts_by_owner(owner, filter, config)

    def get_subscription(self, subscriber: Any, nonce: str) -> Subscription:
        return Subscription.from_dict(self._inner.get_subscription(subscriber, nonce))

    def get_triggered_transactions(self, subscription_account: Any, limit: Optional[int]) -> list[TriggeredTransaction]:
        return [TriggeredTransaction.from_dict(x) for x in self._inner.get_triggered_transactions(subscription_account, limit)]

    def get_workflow_lineage(self, request: GetWorkflowLineageRequest) -> GetWorkflowLineageResponse:
        return GetWorkflowLineageResponse.from_dict(self._inner.get_workflow_lineage(request))

    def get_transactions(self, config: Optional[GetTransactionsConfig]) -> list[TransactionInfo]:
        return [TransactionInfo.from_dict(x) for x in self._inner.get_transactions(config)]

    def is_blockhash_valid(self, blockhash: Any) -> IsBlockhashValidResponse:
        return IsBlockhashValidResponse.from_dict(self._inner.is_blockhash_valid(blockhash))

    def get_health(self) -> str:
        return self._inner.get_health()

    def get_validator_health(self) -> ValidatorHealth:
        return ValidatorHealth.from_dict(self._inner.get_validator_health())

    def get_connected_full_nodes(self) -> list[ConnectedNode]:
        return [ConnectedNode.from_dict(x) for x in self._inner.get_connected_full_nodes()]

    def get_secret_sharing_pubkey(self) -> SecretSharingPubkey:
        return SecretSharingPubkey.from_dict(self._inner.get_secret_sharing_pubkey())

    def get_config_hash_prefix(self) -> int:
        return self._inner.get_config_hash_prefix()

    def get_all_accounts(self, config: Optional[GetAllAccountsConfig]) -> list[AllAccountsEntry]:
        return [AllAccountsEntry.from_dict(x) for x in self._inner.get_all_accounts(config)]

    def get_block(self, block_height: int, config: Optional[GetBlockConfig]) -> BlockInfo:
        return BlockInfo.from_dict(self._inner.get_block(block_height, config))

    def get_blocks(self, start_height: int, end_height: Optional[int]) -> list[int]:
        return self._inner.get_blocks(start_height, end_height)

    def get_stake_account(self, pubkey: Any) -> Optional[StakeAccountInfo]:
        _raw = self._inner.get_stake_account(pubkey)
        return StakeAccountInfo.from_dict(_raw) if _raw is not None else None

    def get_validator_accounts(self, request: GetValidatorAccountsRequest) -> list[ValidatorAccountInfo]:
        return [ValidatorAccountInfo.from_dict(x) for x in self._inner.get_validator_accounts(request)]

    def get_token_account_balance(self, pubkey: Any) -> TokenBalance:
        return TokenBalance.from_dict(self._inner.get_token_account_balance(pubkey))

    def get_rex_requests(self, creator: Any, nonce: Optional[str]) -> list[RexInfoAndDuties]:
        return [RexInfoAndDuties.from_dict(x) for x in self._inner.get_rex_requests(creator, nonce)]

    def get_rex_missed_duties(self, creator: Any, nonce: str) -> list[int]:
        return self._inner.get_rex_missed_duties(creator, nonce)

    def get_cluster_nodes(self) -> list[ClusterNodeInfo]:
        return [ClusterNodeInfo.from_dict(x) for x in self._inner.get_cluster_nodes()]

    def get_connected_validators(self) -> list[int]:
        return self._inner.get_connected_validators()

    def send_transaction(self, transaction: bytes, options: Optional[SendTransactionOptions]) -> Any:
        return self._inner.send_transaction(transaction, options)

    def request_airdrop(self, pubkey: Any, amount: int) -> Any:
        return self._inner.request_airdrop(pubkey, amount)

    def confirm_transaction(self, sig: str, options: Optional[ConfirmTransactionOptions]) -> ConfirmedTransaction:
        return ConfirmedTransaction.from_dict(self._inner.confirm_transaction(sig, options))

    def send_and_confirm_transaction(self, transaction: bytes, options: Optional[SendAndConfirmOptions]) -> ConfirmedTransaction:
        return ConfirmedTransaction.from_dict(self._inner.send_and_confirm_transaction(transaction, options))

    def request_airdrop_and_confirm(self, pubkey: Any, amount: int) -> ConfirmedTransaction:
        return ConfirmedTransaction.from_dict(self._inner.request_airdrop_and_confirm(pubkey, amount))

    def send_admin_transaction(self, request: SubmitEpochChangeRequest) -> SubmitEpochChangeResponse:
        return SubmitEpochChangeResponse.from_dict(self._inner.send_admin_transaction(request))

