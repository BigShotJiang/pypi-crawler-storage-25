// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Instruction types for the Feature Management Program

extern crate alloc;
use alloc::{string::String, vec::Vec};

use borsh::{BorshDeserialize, BorshSerialize};
use rialo_s_pubkey::Pubkey;

/// Instructions supported by the Feature Management Program
#[derive(Clone, Debug, PartialEq, Eq, BorshSerialize, BorshDeserialize)]
pub enum FeatureManagementInstruction {
    /// Upsert features (add or modify)
    ///
    /// This instruction requires a valid signature from the authority.
    ///
    /// Accounts expected:
    /// 0. `[writable]` Storage account (PDA)
    /// 1. `[signer]` The authority account
    Upsert {
        /// Name of the feature
        name: String,
        /// Start time (Unix timestamp in seconds)
        start_time: u64,
        /// End time (Unix timestamp in seconds)
        end_time: u64,
    },

    /// Update the authority
    ///
    /// This instruction requires a valid signature from the current authority.
    ///
    /// Accounts expected:
    /// 0. `[writable]` Storage account (PDA)
    /// 1. `[signer]` The current authority account
    UpdateAuthority {
        /// The new authority that will control the feature management system
        new_authority: Pubkey,
    },
}

#[cfg(not(target_os = "solana"))]
impl FeatureManagementInstruction {
    /// Serialize instruction data
    pub fn serialize(&self) -> Result<Vec<u8>, borsh::io::Error> {
        borsh::to_vec(self)
    }

    /// Deserialize instruction data
    pub fn deserialize(data: &[u8]) -> Result<Self, borsh::io::Error> {
        borsh::from_slice(data)
    }
}
