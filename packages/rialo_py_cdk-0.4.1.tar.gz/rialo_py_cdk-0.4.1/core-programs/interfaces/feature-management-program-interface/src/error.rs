// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! Error types for the Feature Management Program

use rialo_s_instruction::error::InstructionError;
use rialo_s_program_error::{PrintProgramError, ProgramError};

/// Errors that can be returned by the Feature Management Program
///
/// Error codes are explicitly assigned to ensure stability across versions.
/// Do not reorder variants or change their discriminant values.
#[derive(Debug, Clone, PartialEq, Eq)]
#[repr(u32)]
pub enum FeatureManagementError {
    /// Unauthorized access - signature verification failed
    Unauthorized = 0,

    /// Invalid feature name (empty or too long)
    InvalidFeatureName = 1,

    /// Feature not found
    FeatureNotFound = 2,

    /// Invalid time range (start time >= end time)
    InvalidTimeRange = 3,

    /// Serialization error
    SerializationError = 4,

    /// Deserialization error
    DeserializationError = 5,

    /// Invalid instruction data
    InvalidInstructionData = 6,

    /// Internal error (e.g., mutex lock failure)
    InternalError = 7,

    /// Duplicate feature in modification list
    DuplicateFeature = 8,

    /// Invalid storage account (not the expected PDA)
    InvalidStorageAccount = 9,

    /// Storage account already initialized
    AlreadyInitialized = 10,

    /// Storage account not initialized
    NotInitialized = 11,
}

impl From<FeatureManagementError> for ProgramError {
    fn from(e: FeatureManagementError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

impl From<FeatureManagementError> for InstructionError {
    fn from(e: FeatureManagementError) -> Self {
        InstructionError::Custom(e as u32)
    }
}

impl PrintProgramError for FeatureManagementError {
    fn print<E>(&self) {}
}
