// Copyright (c) Subzero Labs, Inc.
// SPDX-License-Identifier: Apache-2.0

//! The REX WASM V1 loader program interface.
//!
//! This loader manages WASM component bytecode that executes in the REX (off-chain TEE) environment.

#![cfg_attr(feature = "frozen-abi", feature(min_specialization))]
#![cfg_attr(docsrs, feature(doc_auto_cfg))]

pub mod instruction;
pub mod state;

rialo_s_pubkey::declare_id!("RexWasmV1Loader1111111111111111111111111111");

/// Cooldown before a program can be un-/redeployed again
pub const DEPLOYMENT_COOLDOWN_IN_SLOTS: u64 = 1;

/// Bytecode format - what VM interprets this code
#[repr(u8)]
#[cfg_attr(feature = "frozen-abi", derive(rialo_frozen_abi_macro::AbiExample))]
#[cfg_attr(
    feature = "serde",
    derive(serde_derive::Serialize, serde_derive::Deserialize)
)]
#[derive(Debug, PartialEq, Eq, Clone, Copy, Default)]
pub enum BytecodeFormat {
    /// PolkaVM/RISC-V bytecode (magic: b"PVM\0")
    #[default]
    PolkaVm = 0,
    /// WASM component model bytecode (magic: b"\0asm")
    Wasm = 1,
}

/// Execution context - where this code runs
#[repr(u8)]
#[cfg_attr(feature = "frozen-abi", derive(rialo_frozen_abi_macro::AbiExample))]
#[cfg_attr(
    feature = "serde",
    derive(serde_derive::Serialize, serde_derive::Deserialize)
)]
#[derive(Debug, PartialEq, Eq, Clone, Copy, Default)]
pub enum ExecutionContext {
    /// Execute on-chain in the SVM (Solana Virtual Machine)
    #[default]
    Chain = 0,
    /// Execute off-chain in TEE (REX programs)
    Rex = 1,
}

/// The bytecode format for this loader (WASM component model)
pub const BYTECODE_FORMAT: BytecodeFormat = BytecodeFormat::Wasm;

/// The execution context for this loader (REX/TEE off-chain)
pub const EXECUTION_CONTEXT: ExecutionContext = ExecutionContext::Rex;
