"""athena-python-docx — drop-in replacement for python-docx.

Calls translate into Superdoc SDK operations against a Keryx Y.Doc.
See CLAUDE.md for the API parity contract.
"""

from __future__ import annotations

__version__ = "0.5.3"

from docx.api import Document
from docx._buffer import flush_all
# Re-exports python-docx ships at docx top-level for convenience.
from docx.shared import Emu, Inches, Pt, Cm, Mm, Twips, Length, RGBColor

__all__ = [
    "Document",
    "Emu",
    "Inches",
    "Pt",
    "Cm",
    "Mm",
    "Twips",
    "Length",
    "RGBColor",
    "flush_all",
    "__version__",
]
