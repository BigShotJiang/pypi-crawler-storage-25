"""Hyperlink — python-docx docx.text.hyperlink.Hyperlink parity.

Exposed via `Paragraph.hyperlinks`. Wraps a run that carries a hyperlink
mark or an `href` attribute.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from docx.text.paragraph import Paragraph


class Hyperlink:
    def __init__(
        self,
        *,
        paragraph: "Paragraph",
        target: str,
        run: dict | None = None,
        range_: tuple[int, int] | None = None,
    ) -> None:
        self._paragraph: "Paragraph" = paragraph
        self._target: str = target
        self._run: dict | None = run
        self._range: tuple[int, int] | None = range_

    @property
    def address(self) -> str:
        """The hyperlink address — the URL portion **without** the
        fragment (the part after ``#``).

        Mirrors python-docx 1.x: for ``"https://x.com/path#section1"``
        the address is ``"https://x.com/path"``. Internal "jump"
        hyperlinks (e.g. from a TOC pointing at an in-document
        bookmark) carry an empty address; the bookmark name lives in
        :attr:`fragment` instead.
        """
        from urllib.parse import urlparse, urlunparse

        try:
            parsed = urlparse(self._target)
        except (ValueError, TypeError):
            return self._target
        if not parsed.fragment:
            return self._target
        # Strip fragment, rebuild.
        return urlunparse(parsed._replace(fragment=""))

    @property
    def url(self) -> str:
        """The full hyperlink URL — ``address`` joined with ``fragment``
        via ``#`` when both are present.

        Mirrors python-docx 1.x. Empty string when there is no
        address portion (so its boolean value distinguishes external
        URLs from internal jumps).
        """
        address = self.address
        fragment = self.fragment
        if not address:
            return f"#{fragment}" if fragment else ""
        return f"{address}#{fragment}" if fragment else address

    @property
    def fragment(self) -> str:
        """Reference like `#glossary` at end of URL. Does NOT include
        the fragment-separator character ('#').

        Mirrors python-docx 1.x. For SuperDoc-stored URLs the fragment
        lives in the URL string itself rather than a separate XML
        attribute; we parse it out via urllib.parse.
        """
        from urllib.parse import urlparse
        try:
            return urlparse(self._target).fragment or ""
        except (ValueError, TypeError):
            return ""

    @property
    def text(self) -> str:
        if isinstance(self._run, dict):
            t = self._run.get("text")
            if isinstance(t, str):
                return t
        return ""

    @property
    def runs(self) -> list:
        """List of Run instances in this hyperlink. SuperDoc models the
        hyperlink as a mark on the run, so a single-run hyperlink
        materializes as a one-element list. Multi-run hyperlinks (where
        e.g. part of the link is bold) require SuperDoc to group
        consecutive same-target runs — tracked in
        ``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 9.
        """
        from docx.text.run import Run

        if self._range is None or not isinstance(self._run, dict):
            return []
        return [
            Run(
                session=self._paragraph._session,
                block_id=self._paragraph._node_id,
                range_=self._range,
                inline=self._run,
            ),
        ]

    @property
    def contains_page_break(self) -> bool:
        """True when the text of this hyperlink contains a hard page break.

        Mirrors python-docx 1.x. Detection uses SuperDoc's ``\\f`` form-
        feed sentinel inside the run text (matching
        ``Run.contains_page_break`` / ``Paragraph.contains_page_break``).
        """
        if isinstance(self._run, dict):
            text = self._run.get("text", "")
            if isinstance(text, str):
                return "\f" in text
        return False
