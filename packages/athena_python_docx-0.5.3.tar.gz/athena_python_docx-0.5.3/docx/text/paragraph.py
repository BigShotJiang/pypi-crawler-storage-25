"""Paragraph — mirrors python-docx's Paragraph class."""

from __future__ import annotations

from typing import TYPE_CHECKING

from docx._batching import run_sync

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.styles.style import CharacterStyle, ParagraphStyle
    from docx.text.parfmt import ParagraphFormat
    from docx.text.run import Run


def _node_text(session: "Session", node_id: str) -> str:
    """Fetch a block's full text via doc.get_node_by_id.

    The response shape nests inlines under a node-type key — ``paragraph``
    for paragraphs, ``heading`` for headings:
        {"node": {"paragraph": {"inlines": [{"run": {"text": "..."}}, ...]}}}
    """
    info: object = run_sync(
        session.doc.get_node_by_id({"id": node_id}),
    )
    return _extract_text(info)


def _extract_text(info: object) -> str:
    """Concatenate the text content of a paragraph, mirroring
    python-docx ``Paragraph.text`` semantics:

    - Runs contribute their ``text``
    - ``<w:tab/>`` (SuperDoc inline ``{type: "tab"}``) becomes ``\\t``
    - ``<w:br/>`` line breaks (SuperDoc inline ``{type: "lineBreak"}``)
      become ``\\n``
    - Page-break inlines and other non-text inlines are skipped, same
      as python-docx's behavior

    The earlier impl silently dropped tabs and line breaks, so any
    paragraph with mixed content returned a string that didn't match
    what python-docx returns for the same source — broken parity.
    """
    if not isinstance(info, dict):
        return ""
    node: object = info.get("node")
    if not isinstance(node, dict):
        return ""
    block: object = node.get("paragraph") or node.get("heading")
    if not isinstance(block, dict):
        return ""
    inlines: object = block.get("inlines")
    if not isinstance(inlines, list):
        return ""
    parts: list[str] = []
    for inline in inlines:
        if not isinstance(inline, dict):
            continue
        run: object = inline.get("run")
        if isinstance(run, dict):
            text: object = run.get("text")
            if isinstance(text, str):
                parts.append(text)
            continue
        # ProseMirror-style inlines come through as flat ``{type:
        # "text"|"tab"|"lineBreak", …}`` shapes.
        t: object = inline.get("type")
        if t == "text":
            text2: object = inline.get("text")
            if isinstance(text2, str):
                parts.append(text2)
        elif t == "tab":
            parts.append("\t")
        elif t == "lineBreak":
            parts.append("\n")
    return "".join(parts)


def _walk_inlines(info: object) -> list[dict]:
    """Return the inlines array (runs) from a getNodeById paragraph response."""
    if not isinstance(info, dict):
        return []
    node: object = info.get("node")
    if not isinstance(node, dict):
        return []
    block: object = node.get("paragraph") or node.get("heading")
    if not isinstance(block, dict):
        return []
    inlines: object = block.get("inlines")
    if isinstance(inlines, list):
        return [i for i in inlines if isinstance(i, dict)]
    return []


class Paragraph:
    """A paragraph block in a Word document."""

    def __init__(
        self,
        *,
        session: "Session",
        node_id: str,
        node_type: str = "paragraph",
    ) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id
        # Track node_type at creation so paragraph-level ops can skip a
        # getNodeById round-trip (which raced against Superdoc mutation
        # commits and raised "Block X was not found" for freshly-created
        # blocks). "paragraph" | "heading" | "listItem".
        self._node_type: str = node_type

    @property
    def text(self) -> str:
        """Return the plain-text content of this paragraph."""
        return _node_text(self._session, self._node_id)

    @text.setter
    def text(self, value: str) -> None:
        """Replace the paragraph's text. Preserves the paragraph itself."""
        current: str = _node_text(self._session, self._node_id)
        run_sync(
            self._session.doc.replace(
                {
                    "target": {
                        "kind": "selection",
                        "start": {
                            "kind": "text",
                            "blockId": self._node_id,
                            "offset": 0,
                        },
                        "end": {
                            "kind": "text",
                            "blockId": self._node_id,
                            "offset": len(current),
                        },
                    },
                    "text": value,
                },
            ),
        )

    @property
    def runs(self) -> list["Run"]:
        """Return the runs in this paragraph (in document order).

        Run offsets are computed against SuperDoc's text-address space,
        which counts tab and lineBreak inlines as 1 character each
        (so ``insert_tab({offset})`` and the run-range arithmetic stay
        consistent). The visible text of those inlines (``\\t`` and
        ``\\n``) is what :func:`_extract_text` emits, so ``Run.text``
        slicing of ``paragraph.text`` still aligns.
        """
        from docx.text.run import Run

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        inlines: list[dict] = _walk_inlines(info)
        runs: list["Run"] = []
        offset: int = 0
        for inline in inlines:
            run_data: object = inline.get("run")
            if isinstance(run_data, dict):
                text: object = run_data.get("text")
                if not isinstance(text, str):
                    continue
                start: int = offset
                end: int = offset + len(text)
                offset = end
                runs.append(
                    Run(
                        session=self._session,
                        block_id=self._node_id,
                        range_=(start, end),
                        inline=run_data,
                    ),
                )
                continue
            t: object = inline.get("type")
            if t == "text":
                text2: object = inline.get("text")
                if isinstance(text2, str):
                    start = offset
                    end = offset + len(text2)
                    offset = end
                    runs.append(
                        Run(
                            session=self._session,
                            block_id=self._node_id,
                            range_=(start, end),
                            inline=inline,
                        ),
                    )
            elif t in ("tab", "lineBreak"):
                # Tab/lineBreak occupy one position in SuperDoc's address
                # space. Don't yield as a Run (matches python-docx —
                # tabs/breaks are part of a Run's text, not separate
                # Run objects), but DO advance the offset so subsequent
                # runs land on the right index.
                offset += 1
        return runs

    @property
    def style(self):
        """Return a ParagraphStyle-like object whose .name == styleId.

        For python-docx parity, comparing the returned object to a string
        works via `.name` (not == string), matching stock behavior.
        """
        from docx.styles.style import ParagraphStyle
        from docx.enum.style import WD_STYLE_TYPE

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        if not isinstance(info, dict):
            return None
        node: object = info.get("node")
        if not isinstance(node, dict):
            return None
        style_id: object = node.get("styleId") or node.get("style")
        if not style_id:
            return None
        return ParagraphStyle(
            name=str(style_id),
            style_type=WD_STYLE_TYPE.PARAGRAPH,
            session=self._session,
        )

    @style.setter
    def style(self, value) -> None:
        """Set paragraph style. Accepts a style name, a style object, or ``None``.

        Mirrors python-docx 1.x:
        - ``None`` → restore the default ("Normal").
        - ``str`` → used verbatim as the style id.
        - ``ParagraphStyle`` / other ``BaseStyle`` subclass → use its
          ``style_id`` (NOT its display name). For built-in styles
          ``style_id`` and ``name`` diverge (``"Heading 1"`` vs
          ``"Heading1"``); the wire format wants the id.
        """
        style_id: str
        if value is None:
            style_id = "Normal"
        elif isinstance(value, str):
            style_id = value
        elif hasattr(value, "style_id"):
            style_id = str(value.style_id)
        elif hasattr(value, "name"):
            style_id = str(value.name)
        else:
            style_id = str(value)
        run_sync(
            self._session.doc.styles.paragraph.set_style(
                {
                    "target": self._block_target(),
                    "styleId": style_id,
                },
            ),
        )

    @property
    def alignment(self) -> "WD_ALIGN_PARAGRAPH | None":
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        if not isinstance(info, dict):
            return None
        node: object = info.get("node")
        if not isinstance(node, dict):
            return None
        block: object = node.get("paragraph") or node.get("heading")
        if isinstance(block, dict):
            raw: object = (
                block.get("alignment")
                or (block.get("attrs", {}) or {}).get("textAlign")
            )
            if isinstance(raw, str) and raw:
                return WD_ALIGN_PARAGRAPH.from_superdoc(raw)
        return None

    @alignment.setter
    def alignment(self, value: "WD_ALIGN_PARAGRAPH | str | None") -> None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        if value is None:
            run_sync(
                self._session.doc.format.paragraph.clear_alignment(
                    {"target": self._block_target()},
                ),
            )
            return
        if isinstance(value, WD_ALIGN_PARAGRAPH):
            alignment_str: str = value.to_superdoc()
        else:
            alignment_str = str(value).lower()
        run_sync(
            self._session.doc.format.paragraph.set_alignment(
                {
                    "target": self._block_target(),
                    "alignment": alignment_str,
                },
            ),
        )

    @property
    def paragraph_format(self) -> "ParagraphFormat":
        from docx.text.parfmt import ParagraphFormat

        return ParagraphFormat(self)

    @staticmethod
    def _extract_hyperlink_target(run_data: dict) -> str | None:
        """Extract the URL/anchor target from a SuperDoc run dict.

        Accepts both legacy (``href`` string) and current
        (``hyperlink`` object with ``url``/``target``) shapes. Returns
        the resolved target string or ``None`` if the run has no link.
        """
        hl = run_data.get("hyperlink") or run_data.get("href")
        if isinstance(hl, str) and hl:
            return hl
        if isinstance(hl, dict):
            maybe = hl.get("url") or hl.get("target")
            if isinstance(maybe, str) and maybe:
                return maybe
        return None

    @property
    def hyperlinks(self) -> list:
        """Return the hyperlinks in this paragraph.

        python-docx 1.x exposes Hyperlink objects; we walk inlines for runs
        with a hyperlink mark and return a list of Hyperlink proxies.
        Offsets are computed against SuperDoc's text-address space (same
        rules as :attr:`Paragraph.runs`) so the resulting Hyperlink
        objects can materialize their wrapped Run via the recorded
        ``range_``.
        """
        from docx.text.hyperlink import Hyperlink

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        out: list[Hyperlink] = []
        offset: int = 0
        for inline in _walk_inlines(info):
            run_data: dict | None = None
            text: str = ""
            maybe_run = inline.get("run")
            if isinstance(maybe_run, dict):
                maybe_text = maybe_run.get("text")
                if isinstance(maybe_text, str):
                    run_data = maybe_run
                    text = maybe_text
            elif inline.get("type") == "text":
                maybe_text = inline.get("text")
                if isinstance(maybe_text, str):
                    run_data = inline
                    text = maybe_text
            elif inline.get("type") in ("tab", "lineBreak"):
                offset += 1
                continue

            if run_data is None:
                continue

            target = self._extract_hyperlink_target(run_data)
            start = offset
            offset += len(text)
            if target:
                out.append(
                    Hyperlink(
                        paragraph=self,
                        target=target,
                        run=run_data,
                        range_=(start, start + len(text)),
                    )
                )
        return out

    @property
    def contains_page_break(self) -> bool:
        """python-docx 1.x: True if the paragraph contains a hard page break."""
        return "\f" in self.text

    @property
    def rendered_page_breaks(self) -> "list[RenderedPageBreak]":
        """Return a list of :class:`RenderedPageBreak` proxies for each
        hard page break in this paragraph.

        python-docx 1.x exposes this for inspecting Word's rendered
        page-break positions inside a paragraph. We surface a minimal
        proxy with a ``preceding_paragraph_text`` property so the
        common ``len(p.rendered_page_breaks)`` pattern works. The
        underlying break is detected via the ``\\f`` sentinel in the
        paragraph text.
        """
        text = self.text
        if "\f" not in text:
            return []
        out: list[RenderedPageBreak] = []
        offset = 0
        for segment in text.split("\f")[:-1]:
            offset += len(segment)
            out.append(RenderedPageBreak(
                paragraph=self,
                offset=offset,
                preceding_text=segment,
            ))
            offset += 1  # account for the \f itself
        return out

    def iter_inner_content(self):
        """Yield each inline child of the paragraph in document order.

        python-docx 1.x signature:
        ``Iterator[Run | Hyperlink | RenderedPageBreak]``.

        Order matches SuperDoc's inline list. Hyperlinks group their
        underlying runs, so a hyperlinked span yields a single
        :class:`Hyperlink` rather than the wrapped runs. Plain text
        runs yield :class:`Run` instances; runs whose text contains
        the form-feed (``\\f``) page-break sentinel split into their
        text-before-break and text-after-break halves, with a
        :class:`RenderedPageBreak` yielded between them. Items with
        no text content are skipped, matching python-docx behaviour.
        """
        from docx.text.hyperlink import Hyperlink
        from docx.text.pagebreak import RenderedPageBreak
        from docx.text.run import Run

        info: object = run_sync(
            self._session.doc.get_node_by_id({"id": self._node_id}),
        )
        inlines = _walk_inlines(info)
        offset: int = 0
        for inline in inlines:
            if not isinstance(inline, dict):
                continue
            # Two SuperDoc inline shapes are accepted by the rest of the
            # paragraph code (``_extract_text``, ``runs``):
            #   1. typed-wrapper:    {"run": {"text": "...", ...}}
            #   2. ProseMirror flat: {"type": "text", "text": "...", ...}
            # Both must yield runs from iter_inner_content. The flat
            # shape was dropped in an earlier rewrite — restore it.
            run_data: dict | None = None
            text: object = None
            maybe_run = inline.get("run")
            if isinstance(maybe_run, dict):
                maybe_text = maybe_run.get("text")
                if isinstance(maybe_text, str):
                    run_data = maybe_run
                    text = maybe_text
            elif inline.get("type") == "text":
                maybe_text = inline.get("text")
                if isinstance(maybe_text, str):
                    run_data = inline
                    text = maybe_text
            if run_data is None or not isinstance(text, str):
                continue
            target = self._extract_hyperlink_target(run_data)
            if target:
                start = offset
                offset += len(text)
                yield Hyperlink(
                    paragraph=self,
                    target=target,
                    run=run_data,
                    range_=(start, start + len(text)),
                )
                continue
            # Split the run on `\f` page-break sentinels and yield a
            # RenderedPageBreak for each. Multiple breaks in the same
            # run produce multiple proxies.
            if "\f" not in text:
                start = offset
                offset += len(text)
                yield Run(
                    session=self._session,
                    block_id=self._node_id,
                    range_=(start, offset),
                    inline=run_data,
                )
                continue
            parts = text.split("\f")
            for i, part in enumerate(parts):
                if part:
                    start = offset
                    offset += len(part)
                    yield Run(
                        session=self._session,
                        block_id=self._node_id,
                        range_=(start, offset),
                        inline=run_data,
                    )
                if i < len(parts) - 1:
                    preceding = "".join(parts[: i + 1])
                    yield RenderedPageBreak(
                        paragraph=self,
                        offset=offset,
                        preceding_text=preceding,
                    )
                    offset += 1  # the \f itself

    def _block_target(self) -> dict:
        """Build a {kind, nodeType, nodeId} target for paragraph-level ops.

        Uses the node_type cached at construction. This avoids an extra
        getNodeById round-trip that previously raced with Superdoc's
        mutation-commit pipeline and raised "Block X was not found" for
        blocks that had just been created by the same session.
        """
        return {
            "kind": "block",
            "nodeType": self._node_type,
            "nodeId": self._node_id,
        }

    def add_run(
        self,
        text: "str | None" = None,
        style: "str | CharacterStyle | None" = None,
    ) -> "Run":
        """Append a run to this paragraph.

        Mirrors python-docx: ``text`` defaults to ``None`` (treated as
        empty), ``style`` accepts either a style id string or a
        :class:`CharacterStyle` instance. Per python-docx 1.2.0
        contract, ``text`` may include tab (``\\t``), newline
        (``\\n``), and carriage-return (``\\r``) characters; each
        becomes a real Word tab / line-break element rather than a
        literal character. The earlier impl sent the raw string to
        SuperDoc's text-insert which stored ``\\t`` and ``\\n`` as
        literal characters — broken parity.
        """
        from docx.styles.style import CharacterStyle
        from docx.text.run import Run

        current: str = _node_text(self._session, self._node_id)
        start: int = len(current)
        text_str: str = text or ""

        if text_str:
            self._insert_run_text_segments(text_str, start)

        run_obj: "Run" = Run(
            session=self._session,
            block_id=self._node_id,
            range_=(start, start + len(text_str)),
        )
        if style is not None:
            style_id: str = (
                style.style_id if isinstance(style, CharacterStyle) else str(style)
            )
            run_obj.style = style_id
        return run_obj

    def _insert_run_text_segments(self, text: str, start_offset: int) -> None:
        """Insert ``text`` at ``start_offset``, splitting tab and
        newline characters into separate inline ops so they round-trip
        as Word ``<w:tab/>`` / ``<w:br/>`` elements rather than
        literal characters.

        Each ``\\t`` advances the offset by one and emits an
        ``insert_tab``; each ``\\n`` or ``\\r`` advances by one and
        emits an ``insert_line_break``. Between control characters
        the literal text segments go through ``doc.insert`` with the
        text type.
        """
        offset = start_offset
        i = 0
        n = len(text)
        while i < n:
            j = i
            while j < n and text[j] not in ("\t", "\n", "\r"):
                j += 1
            segment = text[i:j]
            if segment:
                cursor: dict = {
                    "kind": "text",
                    "blockId": self._node_id,
                    "offset": offset,
                }
                run_sync(
                    self._session.doc.insert(
                        {
                            "target": {
                                "kind": "selection",
                                "start": cursor,
                                "end": cursor,
                            },
                            "value": segment,
                            "type": "text",
                        },
                    ),
                )
                offset += len(segment)
            if j >= n:
                break
            ch = text[j]
            if ch == "\t":
                run_sync(
                    self._session.doc.insert_tab(
                        {"blockId": self._node_id, "offset": offset},
                    ),
                )
            else:
                run_sync(
                    self._session.doc.insert_line_break(
                        {"blockId": self._node_id, "offset": offset},
                    ),
                )
            offset += 1
            i = j + 1

    def clear(self) -> "Paragraph":
        """Clear the paragraph's text content."""
        self.text = ""
        return self

    def insert_paragraph_before(
        self,
        text: str | None = None,
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Insert a new paragraph directly before this one."""
        result: object = run_sync(
            self._session.doc.create.paragraph(
                {
                    "text": text or "",
                    "at": {"kind": "before", "target": self._block_target()},
                },
            ),
        )
        from docx.document import _extract_inserted_node_id

        if isinstance(result, dict):
            node_id: str = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
        else:
            node_id = ""
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return nodeId for insert_paragraph_before: {result!r}",
            )
        new_para = Paragraph(
            session=self._session, node_id=node_id, node_type="paragraph",
        )
        if style:
            new_para.style = style
        return new_para


from docx.text.pagebreak import RenderedPageBreak as RenderedPageBreak  # noqa: E402,F401

