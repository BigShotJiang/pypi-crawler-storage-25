"""Table, _Row, _Column, _Cell — python-docx parity."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.errors import ValidationError
from docx.shared import Length, Pt

if TYPE_CHECKING:
    from docx.client import Session
    from docx.enum.table import (
        WD_ALIGN_VERTICAL,
        WD_ROW_HEIGHT_RULE,
        WD_TABLE_ALIGNMENT,
        WD_TABLE_DIRECTION,
    )
    from docx.styles.style import ParagraphStyle
    from docx.text.paragraph import Paragraph


def _log_warn(msg: str) -> None:
    print(f"[docx-sdk] WARN: {msg}", file=sys.stderr)


def _find_first_paragraph_id(obj: object) -> str:
    """Walk a getNodeById result to find the first paragraph nodeId."""
    if isinstance(obj, dict):
        t: object = obj.get("type")
        if isinstance(t, str) and t in ("paragraph", "heading"):
            attrs: object = obj.get("attrs")
            if isinstance(attrs, dict):
                nid: object = attrs.get("nodeId") or attrs.get("id")
                if isinstance(nid, str) and nid:
                    return nid
            top_nid: object = obj.get("nodeId")
            if isinstance(top_nid, str) and top_nid:
                return top_nid
        for key in ("paragraph", "heading"):
            if key in obj and isinstance(obj[key], dict):
                nid_o: object = obj.get("nodeId")
                if isinstance(nid_o, str) and nid_o:
                    return nid_o
                inner = _find_first_paragraph_id(obj[key])
                if inner:
                    return inner
        for v in obj.values():
            found: str = _find_first_paragraph_id(v)
            if found:
                return found
    elif isinstance(obj, list):
        for item in obj:
            found = _find_first_paragraph_id(item)
            if found:
                return found
    return ""


def _collect_paragraph_ids(obj: object, out: list[str]) -> None:
    """Walk a node tree and collect all paragraph/heading nodeIds in order.

    Tolerates multiple shapes Superdoc emits:
      - cell getNodeById:  {"node": {"kind": "paragraph", "id": "UUID",
                                      "paragraph": {"inlines": [...]}}}
        (the cell's inner paragraph — server reports `id` as a bare UUID
         that the addressing layer expects as `paragraph:UUID`)
      - prosemirror-style: {"type": "paragraph", "attrs": {"nodeId": ...}}
      - typed-wrapper:     {"paragraph": {...}, "nodeId": "..."}
      - flat-address:      {"kind": "block", "nodeType": "paragraph", "nodeId": ...}
      - block-list shape:  {"nodeType": "paragraph", "nodeId": ...}
    """
    seen: set[str] = set(out)

    def _add(nid: object) -> None:
        if not isinstance(nid, str) or not nid:
            return
        # Superdoc uses bare UUIDs (or short hashes) — no `paragraph:`
        # prefix. Pass the value through verbatim.
        if nid in seen:
            return
        seen.add(nid)
        out.append(nid)

    if isinstance(obj, dict):
        # Cell getNodeById shape: {kind: "paragraph", id: "<UUID>", paragraph: {...}}
        kind: object = obj.get("kind")
        if kind == "paragraph" and isinstance(obj.get("id"), str):
            _add(obj.get("id"))
            # Some responses also put the wrapper's id at nodeId.
            _add(obj.get("nodeId"))
        # Prosemirror-style
        t: object = obj.get("type")
        if isinstance(t, str) and t in ("paragraph", "heading"):
            attrs: object = obj.get("attrs")
            if isinstance(attrs, dict):
                _add(attrs.get("nodeId") or attrs.get("id"))
            _add(obj.get("nodeId"))
            _add(obj.get("id"))
        # Flat-address / block-list
        node_type: object = obj.get("nodeType")
        if isinstance(node_type, str) and node_type in ("paragraph", "heading"):
            _add(obj.get("nodeId"))
        # Typed-wrapper
        for key in ("paragraph", "heading"):
            if key in obj and isinstance(obj[key], dict):
                _add(obj.get("nodeId"))
                inner = obj[key]
                if isinstance(inner, dict):
                    _add(inner.get("nodeId"))
        # Recurse
        for v in obj.values():
            _collect_paragraph_ids(v, out)
    elif isinstance(obj, list):
        for item in obj:
            _collect_paragraph_ids(item, out)


def _collect_block_ids(
    obj: object, out: list[tuple[str, str]], seen: set[str]
) -> None:
    """Walk an arbitrary getNodeById/getNode payload and collect every
    block child as ``(nodeId, nodeType)`` in document order.

    Type-aware variant of :func:`_collect_paragraph_ids` — recognizes
    paragraphs, headings, AND tables. Used by
    :meth:`_Cell.iter_inner_content` to yield ``Paragraph | Table`` in
    upstream order.

    Tolerates the same shapes ``_collect_paragraph_ids`` does:

    * flat-address: ``{nodeType, nodeId}``
    * typed-wrapper: ``{paragraph: {…}, nodeId}`` or
      ``{heading: {…}, nodeId}`` or ``{table: {…}, nodeId}``
    * prosemirror-style: ``{type: …, attrs: {nodeId}}``
    """
    BLOCK_TYPES: dict[str, str] = {
        "paragraph": "paragraph",
        "heading": "heading",
        "listItem": "paragraph",
        "table": "table",
    }

    def _add(nid: object, kind: str) -> None:
        if isinstance(nid, str) and nid and nid not in seen:
            seen.add(nid)
            out.append((nid, kind))

    if isinstance(obj, dict):
        # 1. Flat-address: {nodeType: "...", nodeId: "..."}
        nt = obj.get("nodeType")
        if isinstance(nt, str) and nt in BLOCK_TYPES:
            _add(obj.get("nodeId"), BLOCK_TYPES[nt])
        # 2. ProseMirror-style {type: "...", attrs: {nodeId}}
        pmt = obj.get("type")
        if isinstance(pmt, str) and pmt in BLOCK_TYPES:
            attrs = obj.get("attrs")
            if isinstance(attrs, dict):
                _add(attrs.get("nodeId"), BLOCK_TYPES[pmt])
        # 3. Typed-wrapper {paragraph: {...}, nodeId} (and table/heading variants)
        for key, kind in BLOCK_TYPES.items():
            wrapped = obj.get(key)
            if isinstance(wrapped, dict):
                _add(obj.get("nodeId"), kind)
                _add(wrapped.get("nodeId"), kind)
        # Recurse — but for table-wrappers, do NOT walk their inner
        # rows/cells because that would surface deeply-nested
        # paragraphs that are inside the nested table, not at the
        # parent cell's level.
        for key, value in obj.items():
            if key == "table" and isinstance(value, dict):
                continue
            _collect_block_ids(value, out, seen)
    elif isinstance(obj, list):
        for item in obj:
            _collect_block_ids(item, out, seen)


class Table:
    def __init__(self, *, session: "Session", node_id: str) -> None:
        self._session: "Session" = session
        self._node_id: str = node_id

    def _fresh_node_info(self) -> tuple[str, dict]:
        """Resolve the live nodeId and return ``(node_id, info_dict)``.

        ``info_dict`` is the ``tables.get`` payload that the fast path
        already fetched, so callers that need row/col counts can reuse
        it instead of issuing a second identical RPC. The fallback path
        (find + rotate) re-fetches the info for the rotated id.
        """
        # Fast-path: ask for this table directly. If the server finds it,
        # we're done — no rotation needed.
        try:
            info: object = run_sync(
                self._session.doc.tables.get({"nodeId": self._node_id}),
            )
            if isinstance(info, dict) and (
                info.get("nodeId") == self._node_id or info
            ):
                return self._node_id, info
        except Exception:
            pass
        # Fallback: scan top-level tables via doc.find.
        find_result: object = run_sync(
            self._session.doc.find({"type": "table"}),
        )
        items_obj: object = (
            find_result.get("items", []) if isinstance(find_result, dict) else []
        )
        items: list = items_obj if isinstance(items_obj, list) else []
        for item in items:
            if not isinstance(item, dict):
                continue
            addr = item.get("address", {})
            if isinstance(addr, dict) and addr.get("nodeId") == self._node_id:
                info_obj = run_sync(
                    self._session.doc.tables.get({"nodeId": self._node_id}),
                )
                return self._node_id, info_obj if isinstance(info_obj, dict) else {}
        if items:
            last = items[-1] if isinstance(items[-1], dict) else {}
            last_addr = last.get("address", {}) if isinstance(last, dict) else {}
            new_id: str = str(last_addr.get("nodeId", ""))
            if new_id and new_id != self._node_id:
                _log_warn(
                    f"table nodeId rotated: {self._node_id} -> {new_id}",
                )
                self._node_id = new_id
        info_obj = run_sync(
            self._session.doc.tables.get({"nodeId": self._node_id}),
        )
        return self._node_id, info_obj if isinstance(info_obj, dict) else {}

    def _fresh_node_id(self) -> str:
        """Return the live nodeId — thin wrapper over :meth:`_fresh_node_info`."""
        return self._fresh_node_info()[0]

    def _address(self) -> dict:
        return {"kind": "block", "nodeType": "table", "nodeId": self._fresh_node_id()}

    @property
    def rows(self) -> "_Rows":
        _, info_dict = self._fresh_node_info()
        row_count: int = int(
            info_dict.get("rows")
            or info_dict.get("rowCount")
            or (info_dict.get("table", {}) or {}).get("rows")
            or 0,
        )
        return _Rows([_Row(table=self, index=i) for i in range(row_count)], table=self)

    @property
    def columns(self) -> "_Columns":
        _, info_dict = self._fresh_node_info()
        col_count: int = int(
            info_dict.get("columns")
            or info_dict.get("cols")
            or info_dict.get("columnCount")
            or (info_dict.get("table", {}) or {}).get("columns")
            or 0,
        )
        return _Columns(
            [_Column(table=self, index=j) for j in range(col_count)],
            table=self,
        )

    def cell(self, row_idx: int, col_idx: int) -> "_Cell":
        """Return the :class:`_Cell` at ``(row_idx, col_idx)``.

        Mirrors python-docx: ``(0, 0)`` is the top-left cell. Bounds
        are validated eagerly — out-of-range indices raise
        :class:`IndexError` immediately rather than producing a proxy
        that fails later when its address is resolved.

        Negative indices are accepted Python-style (``-1`` is the last
        row/column).
        """
        _, info_dict = self._fresh_node_info()
        row_count: int = int(
            info_dict.get("rows")
            or info_dict.get("rowCount")
            or (info_dict.get("table", {}) or {}).get("rows")
            or 0,
        )
        col_count: int = int(
            info_dict.get("columns")
            or info_dict.get("cols")
            or info_dict.get("columnCount")
            or (info_dict.get("table", {}) or {}).get("columns")
            or 0,
        )
        # Normalize negative indices the same way list[] does.
        if row_idx < 0:
            row_idx += row_count
        if col_idx < 0:
            col_idx += col_count
        if not (0 <= row_idx < row_count):
            raise IndexError(
                f"row_idx {row_idx!r} out of range for table with "
                f"{row_count} rows",
            )
        if not (0 <= col_idx < col_count):
            raise IndexError(
                f"col_idx {col_idx!r} out of range for table with "
                f"{col_count} columns",
            )
        return _Cell(table=self, row=row_idx, col=col_idx)

    def row_cells(self, row_idx: int) -> list["_Cell"]:
        """Return a list of cells in the row at *row_idx*.

        Mirrors python-docx 1.x. Behaviour for merged cells follows
        python-docx: the same _Cell may appear at multiple positions in
        the returned list when a horizontal merge spans them.
        """
        return self.rows[row_idx].cells

    def column_cells(self, column_idx: int) -> list["_Cell"]:
        """Return a list of cells in the column at *column_idx*."""
        return self.columns[column_idx].cells

    @property
    def table(self) -> "Table":
        """Return ``self`` — mirrors python-docx where ``Table.table`` is
        defined for symmetry with ``_Cell.table`` so block iteration code
        can look up the enclosing table without checking type."""
        return self

    def add_row(self) -> "_Row":
        nid: str = self._fresh_node_id()
        row_count: int = len(self.rows)
        if row_count < 1:
            raise ValidationError(f"Cannot add row to empty table {nid}")
        run_sync(
            self._session.doc.tables.insert_row(
                {
                    "nodeId": nid,
                    "rowIndex": row_count - 1,
                    "position": "below",
                    "count": 1,
                },
            ),
        )
        return _Row(table=self, index=row_count)

    def add_column(self, width: "Length") -> "_Column":
        """Add a new column to the table at the rightmost position.

        ``width`` is required to match python-docx; columns without a
        width produce malformed Word output and are rejected upstream.
        """
        # Validate width eagerly. Upstream's ``Emu(-100)`` raises
        # ``ValueError`` so the column is never created. Previously this
        # method silently inserted the column first and only failed
        # later (or not at all, on a permissive backend), leaving a
        # phantom column in the table.
        if width is not None:
            raw_emu = int(width)
            if raw_emu < 0:
                raise ValueError(
                    f"value must be >= 0, got {raw_emu}",
                )
        nid: str = self._fresh_node_id()
        col_count: int = len(self.columns)
        if col_count < 1:
            raise ValidationError(f"Cannot add column to empty table {nid}")
        run_sync(
            self._session.doc.tables.insert_column(
                {
                    "nodeId": nid,
                    "columnIndex": col_count - 1,
                    "position": "right",
                    "count": 1,
                },
            ),
        )
        new_col = _Column(table=self, index=col_count)
        new_col.width = width
        return new_col

    @property
    def style(self) -> str | None:
        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            sid: object = info.get("styleId")
            if isinstance(sid, str) and sid:
                return sid
        return None

    @style.setter
    def style(self, value: str | None) -> None:
        nid: str = self._fresh_node_id()
        run_sync(
            self._session.doc.tables.set_style(
                {"nodeId": nid, "styleId": value or "TableGrid"},
            ),
        )

    @property
    def alignment(self) -> "WD_TABLE_ALIGNMENT | None":
        from docx.enum.table import WD_TABLE_ALIGNMENT

        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            a: object = info.get("alignment")
            if isinstance(a, str):
                for member in WD_TABLE_ALIGNMENT:
                    if member.value == a:
                        return member
        return None

    @alignment.setter
    def alignment(self, value: "WD_TABLE_ALIGNMENT | str | None") -> None:
        from docx.enum.table import WD_TABLE_ALIGNMENT

        if value is None:
            return
        v: str = (
            value.to_superdoc()
            if isinstance(value, WD_TABLE_ALIGNMENT)
            else str(value).lower()
        )
        # SuperDoc 1.8.1: alignment is a setLayout field, not a
        # setTableOptions field. The earlier setTableOptions call
        # silently dropped the value (Zod validated, AnyDoc punt let
        # the wire pass, SuperDoc's permissive parser ignored unknowns).
        run_sync(
            self._session.doc.tables.set_layout(
                {"nodeId": self._fresh_node_id(), "alignment": v},
            ),
        )

    @property
    def direction(self) -> "WD_TABLE_DIRECTION | None":
        from docx.enum.table import WD_TABLE_DIRECTION

        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            d: object = info.get("direction")
            if isinstance(d, str):
                for member in WD_TABLE_DIRECTION:
                    if member.value == d:
                        return member
        return None

    @direction.setter
    def direction(self, value: "WD_TABLE_DIRECTION | str | None") -> None:
        from docx.enum.table import WD_TABLE_DIRECTION

        if value is None:
            return
        v: str = (
            value.to_superdoc()
            if isinstance(value, WD_TABLE_DIRECTION)
            else str(value).lower()
        )
        # SuperDoc's setLayout takes ``tableDirection`` (not
        # ``direction``). Same diagnostic as alignment above —
        # setTableOptions silently swallowed the field.
        run_sync(
            self._session.doc.tables.set_layout(
                {"nodeId": self._fresh_node_id(), "tableDirection": v},
            ),
        )

    # python-docx aliases
    table_direction = direction

    @property
    def autofit(self) -> bool | None:
        info: object = run_sync(
            self._session.doc.tables.get_properties({"nodeId": self._fresh_node_id()}),
        )
        if isinstance(info, dict):
            mode: object = info.get("autoFitMode")
            if isinstance(mode, str):
                return mode != "fixedWidth"
        return None

    @autofit.setter
    def autofit(self, value: bool | None) -> None:
        if value is None:
            return
        run_sync(
            self._session.doc.tables.set_layout(
                {
                    "nodeId": self._fresh_node_id(),
                    # Wire field is ``autoFitMode``, not ``autoFit``.
                    # The earlier ``autoFit`` payload was rejected
                    # silently, so ``Table.autofit = …`` was a no-op.
                    "autoFitMode": "fitContents" if value else "fixedWidth",
                },
            ),
        )

    allow_autofit = autofit

    @property
    def _cells(self) -> list["_Cell"]:
        """Flat list of cells in row-major order."""
        out: list[_Cell] = []
        for r in self.rows:
            out.extend(r.cells)
        return out


class _Row:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index
        # Cache for the rowInfo dict — populated lazily on first access
        # and reused across grid_cols_before / grid_cols_after / height
        # / height_rule. Cleared by callers that mutate the row.
        self._row_info_cache: dict | None = None
        self._row_info_loaded: bool = False

    @property
    def cells(self) -> list["_Cell"]:
        col_count: int = len(self._table.columns)
        return [
            _Cell(table=self._table, row=self._index, col=j)
            for j in range(col_count)
        ]

    @property
    def table(self) -> Table:
        return self._table

    def _row_info(self) -> dict | None:
        """Pull the row entry from ``tables.get`` for the parent table.

        Cached per-instance — adjacent reads (``grid_cols_before`` +
        ``grid_cols_after`` + ``height`` etc.) all share the same
        ``tables.get`` round-trip rather than re-fetching N times.
        """
        if self._row_info_loaded:
            return self._row_info_cache
        self._row_info_loaded = True
        _, info = self._table._fresh_node_info()
        if isinstance(info, dict):
            rows = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    self._row_info_cache = entry
                    return entry
        return None

    @property
    def grid_cols_before(self) -> int:
        """Count of unpopulated grid-columns before the first cell.

        Mirrors python-docx ``_Row.grid_cols_before``. Word allows a
        row to "start late" — grid columns 0..N-1 are unpopulated and
        the first real cell sits at column N. Defaults to 0; SuperDoc
        may report under several keys depending on payload version.
        """
        entry = self._row_info()
        if isinstance(entry, dict):
            v = (
                entry.get("gridBefore")
                or entry.get("gridColsBefore")
                or entry.get("grid_cols_before")
                or 0
            )
            try:
                return max(0, int(v))
            except (TypeError, ValueError):
                return 0
        return 0

    @property
    def grid_cols_after(self) -> int:
        """Count of unpopulated grid-columns after the last cell.

        Mirrors python-docx ``_Row.grid_cols_after`` — the dual of
        :attr:`grid_cols_before`.
        """
        entry = self._row_info()
        if isinstance(entry, dict):
            v = (
                entry.get("gridAfter")
                or entry.get("gridColsAfter")
                or entry.get("grid_cols_after")
                or 0
            )
            try:
                return max(0, int(v))
            except (TypeError, ValueError):
                return 0
        return 0

    @property
    def height(self) -> "Length | None":
        _, info = self._table._fresh_node_info()
        if isinstance(info, dict):
            rows: object = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    h: object = entry.get("heightPt")
                    if isinstance(h, (int, float)):
                        return Pt(float(h))
        return None

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        if value is None:
            return
        # Mirror python-docx: row height is stored as unsigned twips
        # (``ST_TwipsMeasure``), so negative inputs raise ``ValueError``
        # at the type-coercion layer. Previously this setter would ship a
        # negative ``heightPt`` to the wire silently, and SuperDoc would
        # either reject it or round-trip a degenerate row height.
        raw_emu = int(value)
        if raw_emu < 0:
            raise ValueError(
                f"_Row.height must be non-negative; got EMU={raw_emu}. "
                f"Pass Length(0) (or None) to clear instead of a negative."
            )
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_row_height(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "rowIndex": self._index,
                    "heightPt": pt,
                    "rule": "atLeast",
                },
            ),
        )

    @property
    def height_rule(self) -> "WD_ROW_HEIGHT_RULE | None":
        from docx.enum.table import WD_ROW_HEIGHT_RULE

        nid = self._table._fresh_node_id()
        info: object = run_sync(
            self._table._session.doc.tables.get({"nodeId": nid}),
        )
        if isinstance(info, dict):
            rows: object = info.get("rowInfo") or info.get("rowsInfo")
            if isinstance(rows, list) and 0 <= self._index < len(rows):
                entry = rows[self._index]
                if isinstance(entry, dict):
                    r: object = entry.get("rule")
                    if isinstance(r, str):
                        for member in WD_ROW_HEIGHT_RULE:
                            if member.value == r:
                                return member
        return None

    @height_rule.setter
    def height_rule(self, value: "WD_ROW_HEIGHT_RULE | str | None") -> None:
        from docx.enum.table import WD_ROW_HEIGHT_RULE

        if value is None:
            return
        rule: str = (
            value.to_superdoc()
            if isinstance(value, WD_ROW_HEIGHT_RULE)
            else str(value)
        )
        h = self.height
        h_pt: float = float(h.pt) if isinstance(h, Length) else 12.0
        run_sync(
            self._table._session.doc.tables.set_row_height(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "rowIndex": self._index,
                    "heightPt": h_pt,
                    "rule": rule,
                },
            ),
        )


class _Column:
    def __init__(self, *, table: Table, index: int) -> None:
        self._table: Table = table
        self._index: int = index

    @property
    def cells(self) -> list["_Cell"]:
        row_count: int = len(self._table.rows)
        return [
            _Cell(table=self._table, row=i, col=self._index)
            for i in range(row_count)
        ]

    @property
    def table(self) -> Table:
        return self._table

    @property
    def width(self) -> "Length | None":
        nid = self._table._fresh_node_id()
        info: object = run_sync(
            self._table._session.doc.tables.get({"nodeId": nid}),
        )
        if isinstance(info, dict):
            cols: object = info.get("columnInfo") or info.get("columnsInfo")
            if isinstance(cols, list) and 0 <= self._index < len(cols):
                entry = cols[self._index]
                if isinstance(entry, dict):
                    w: object = entry.get("widthPt")
                    if isinstance(w, (int, float)):
                        return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            return
        # Mirror python-docx: width must be non-negative. Upstream
        # uses Emu which raises ``ValueError`` for negatives. Previously
        # this setter shipped negative widths to the wire silently, where
        # SuperDoc would either reject them or round-trip a garbage
        # column width.
        if isinstance(value, Length):
            raw_emu = int(value)
        else:
            raw_emu = int(value)
        if raw_emu < 0:
            raise ValueError(
                f"value must be >= 0, got {raw_emu}",
            )
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_column_width(
                {
                    "nodeId": self._table._fresh_node_id(),
                    "columnIndex": self._index,
                    "widthPt": pt,
                },
            ),
        )


class _Rows(list):
    """Sequence of :class:`_Row` instances. Subclasses ``list`` so all
    standard list operations work, plus exposes ``.table`` for parity
    with python-docx's :class:`docx.table._Rows`.
    """

    def __init__(self, items: list, *, table: Table) -> None:
        super().__init__(items)
        self._table: Table = table

    @property
    def table(self) -> Table:
        return self._table


class _Columns(list):
    """Sequence of :class:`_Column` instances; the column dual of
    :class:`_Rows`. Subclasses ``list``."""

    def __init__(self, items: list, *, table: Table) -> None:
        super().__init__(items)
        self._table: Table = table

    @property
    def table(self) -> Table:
        return self._table


class _Cell:
    def __init__(self, *, table: Table, row: int, col: int) -> None:
        self._table: Table = table
        self._row: int = row
        self._col: int = col

    def _cell_info(self) -> dict | None:
        nid: str = self._table._fresh_node_id()
        result: object = run_sync(
            self._table._session.doc.tables.get_cells(
                {
                    "nodeId": nid,
                    "rowIndex": self._row,
                    "columnIndex": self._col,
                },
            ),
        )
        if not isinstance(result, dict):
            return None
        cells_obj: object = result.get("cells", result.get("items", []))
        cells: list = cells_obj if isinstance(cells_obj, list) else []
        if not cells or not isinstance(cells[0], dict):
            return None
        return cells[0]

    def _cell_id(self) -> str:
        info = self._cell_info()
        if info is None:
            raise ValidationError(
                f"Cell ({self._row}, {self._col}) not found in "
                f"table {self._table._fresh_node_id()}",
            )
        nid: object = info.get("nodeId")
        if not isinstance(nid, str) or not nid:
            raise ValidationError(
                f"Cell ({self._row}, {self._col}) has no nodeId",
            )
        return nid

    def _cell_address(self) -> dict:
        return {"kind": "block", "nodeType": "tableCell", "nodeId": self._cell_id()}

    def _inner_paragraph_ids(self) -> list[str]:
        """Locate the paragraph nodeIds inside this cell, trying multiple
        Superdoc response shapes.

        Strategies (in order):
          1. doc.getNodeById with explicit nodeType=tableCell
          2. doc.getNodeById with just {id: ...}
          3. doc.getNode with target=tableCell address
          4. doc.blocks.list filtered to paragraph/heading + location match
        """
        cell_id = self._cell_id()
        session = self._table._session
        ids: list[str] = []

        # Strategy 1: with explicit nodeType
        try:
            info = run_sync(
                session.doc.get_node_by_id(
                    {"id": cell_id, "nodeType": "tableCell"},
                ),
            )
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        # Strategy 2: without nodeType (some sdk versions expect only id)
        try:
            info = run_sync(session.doc.get_node_by_id({"id": cell_id}))
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        # Strategy 3: doc.getNode with target address
        try:
            info = run_sync(
                session.doc.get_node(
                    {
                        "target": {
                            "kind": "block",
                            "nodeType": "tableCell",
                            "nodeId": cell_id,
                        },
                    },
                ),
            )
            _collect_paragraph_ids(info, ids)
            if ids:
                return ids
        except Exception:
            pass

        return ids

    @property
    def text(self) -> str:
        """Return the combined text of direct-child paragraphs in the cell.

        Mirrors python-docx's `_Cell.text`, which is:
            "\\n".join(p.text for p in self.paragraphs)

        Note: this is NOT recursive — nested-table content is not included
        (stock python-docx's _Cell.text has that same shallow semantic).
        """
        from docx.text.paragraph import _node_text

        ids = self._inner_paragraph_ids()
        if ids:
            return "\n".join(_node_text(self._table._session, pid) for pid in ids)
        info = self._cell_info()
        if info is not None:
            t: object = info.get("text")
            if isinstance(t, str):
                return t
        return ""

    @text.setter
    def text(self, value: str) -> None:
        """Set the cell's text content.

        The cell's single inner paragraph is addressed indirectly — Superdoc
        doesn't expose a paragraph ref that's usable as a `blockId` for text
        selections. Instead we use `doc.insert` with a structural paragraph
        fragment at `placement=insideEnd`, which APPENDS inline runs to the
        cell's existing paragraph. For a freshly-created (empty) cell this
        produces `cell.text == value` on read-back.

        For cells that already contain text, callers who truly want "replace"
        semantics should first resolve the cell's paragraph via `doc.find`
        and delete it — see _Cell.clear() (Phase 3).
        """
        # Mirror python-docx: passing a non-string raises ``TypeError``
        # there (the upstream implementation does ``"".join(value)`` and
        # ints/None aren't iterable). Previously this setter accepted
        # any type and ``or ""`` masked ``None``, while ``int`` values
        # were passed through to ``markdown_to_fragment`` where they
        # round-tripped as ``str(value)`` — a silent type coercion.
        if not isinstance(value, str):
            raise TypeError(
                f"_Cell.text must be a str; got {type(value).__name__}",
            )
        cell_id = self._cell_id()
        session = self._table._session
        cell_target: dict = {
            "kind": "block",
            "nodeType": "tableCell",
            "nodeId": cell_id,
        }
        # Superdoc only accepts block-typed fragments at the top level
        # (paragraph/heading/table/image/list/sectionBreak/sdt/tableOfContents).
        # We convert the plain-text value through `doc.markdownToFragment`
        # to get a guaranteed-valid `{kind:"paragraph", paragraph:{inlines:[...]}}`
        # shape, then doc.insert appends its inline runs into the cell's
        # existing paragraph (rather than adding a sibling paragraph).
        #
        # Confirmed against real staging Superdoc. This is the ONLY shape
        # that actually lands text inside a tableCell:
        #   - text mode + placement  → rejected ("placement only valid
        #     with structural content")
        #   - doc.replace + tableCell target → replaces the cell itself,
        #     destroying the table structure
        try:
            frag_result: object = run_sync(
                session.doc.markdown_to_fragment({"markdown": value or ""}),
            )
            fragment: object = (
                frag_result.get("fragment")
                if isinstance(frag_result, dict)
                else None
            )
            # Fall back to a hand-built fragment with Superdoc's native
            # shape if markdownToFragment is unavailable.
            if not isinstance(fragment, dict):
                fragment = {
                    "kind": "paragraph",
                    "paragraph": {
                        "inlines": (
                            [{"kind": "run", "run": {"text": value}}]
                            if value
                            else []
                        ),
                    },
                }
            run_sync(
                session.doc.insert(
                    {
                        "target": cell_target,
                        "placement": "insideEnd",
                        "content": fragment,
                    },
                ),
            )
            return
        except Exception as e:
            raise RuntimeError(
                f"Failed to set _Cell.text on cell ({self._row}, {self._col}) "
                f"of table {self._table._fresh_node_id()}: {e!r}",
            ) from e

    @property
    def paragraphs(self) -> list["Paragraph"]:
        from docx.text.paragraph import Paragraph

        return [
            Paragraph(
                session=self._table._session,
                node_id=pid,
                node_type="paragraph",
            )
            for pid in self._inner_paragraph_ids()
        ]

    @property
    def tables(self) -> list[Table]:
        cell_id = self._cell_id()
        info: object = run_sync(
            self._table._session.doc.get_node_by_id(
                {"id": cell_id, "nodeType": "tableCell"},
            ),
        )
        nested: list[Table] = []

        def walk(obj: object) -> None:
            if isinstance(obj, dict):
                t = obj.get("type") or obj.get("nodeType")
                if t == "table":
                    nid = obj.get("nodeId") or (
                        obj.get("attrs", {}).get("nodeId")
                        if isinstance(obj.get("attrs"), dict)
                        else None
                    )
                    if isinstance(nid, str) and nid:
                        nested.append(Table(session=self._table._session, node_id=nid))
                for v in obj.values():
                    walk(v)
            elif isinstance(obj, list):
                for item in obj:
                    walk(item)

        walk(info)
        return nested

    def add_paragraph(
        self,
        text: str = "",
        style: "str | ParagraphStyle | None" = None,
    ) -> "Paragraph":
        """Append a paragraph to the cell.

        Mirrors python-docx ``_Cell.add_paragraph(text, style)``. The
        ``style`` argument accepts either a style id string or a
        :class:`docx.styles.style.ParagraphStyle` instance; previously
        only ``str`` was honored and passing a ``ParagraphStyle`` got
        ``repr()``'d into the style id slot, silently producing a
        paragraph with a garbage style reference.
        """
        from docx.document import _extract_inserted_node_id
        from docx.styles.style import ParagraphStyle
        from docx.text.paragraph import Paragraph

        # Normalize style — ParagraphStyle → style_id, str → str, None → None.
        # Any other type lands as ``str(style)`` which Word will then
        # treat as an unknown style id (Word falls back to Normal).
        style_id: str | None
        if style is None:
            style_id = None
        elif isinstance(style, ParagraphStyle):
            style_id = style.style_id
        else:
            style_id = str(style)

        ids = self._inner_paragraph_ids()
        if ids:
            anchor = {
                "kind": "after",
                "target": {
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": ids[-1],
                },
            }
        else:
            # No paragraphs yet — create one inside the cell (sibling of cell
            # is invalid; fall back to documentEnd and accept degraded placement).
            anchor = {"kind": "documentEnd"}

        result: object = run_sync(
            self._table._session.doc.create.paragraph(
                {"text": text, "at": anchor},
            ),
        )
        if isinstance(result, dict):
            node_id: str = _extract_inserted_node_id(
                result, expected_type="paragraph",
            )
        else:
            node_id = ""
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return nodeId for _Cell.add_paragraph: {result!r}",
            )
        para = Paragraph(
            session=self._table._session,
            node_id=node_id,
            node_type="paragraph",
        )
        if style_id:
            para.style = style_id
        return para

    def add_table(self, rows: int, cols: int) -> Table:
        """Append a nested table inside the cell.

        Mirrors python-docx ``_Cell.add_table(rows, cols) -> Table``.
        Note that upstream's ``_Cell.add_table`` does not take a
        ``width`` parameter — Word inherits cell-table widths from
        layout. ``Document.add_table`` and ``Section.header.add_table``
        DO take ``width`` because they're block-level.
        """
        from docx.document import _extract_inserted_node_id

        if rows < 1 or cols < 1:
            raise ValidationError(f"rows/cols must be >=1; got {rows}/{cols}")
        # We can target the cell's last paragraph as an anchor.
        ids = self._inner_paragraph_ids()
        if ids:
            anchor = {
                "kind": "after",
                "target": {
                    "kind": "block",
                    "nodeType": "paragraph",
                    "nodeId": ids[-1],
                },
            }
        else:
            anchor = {"kind": "documentEnd"}
        result: object = run_sync(
            self._table._session.doc.create.table(
                {"rows": rows, "columns": cols, "at": anchor},
            ),
        )
        node_id: str = _extract_inserted_node_id(result, expected_type="table") if isinstance(result, dict) else ""
        if not node_id:
            raise RuntimeError(
                f"Superdoc did not return nodeId for nested table: {result!r}",
            )
        return Table(session=self._table._session, node_id=node_id)

    def merge(self, other_cell: "_Cell") -> "_Cell":
        """Return a merged cell created by spanning the rectangular
        region having this cell and ``other_cell`` as diagonal corners.

        Mirrors python-docx ``_Cell.merge(other_cell)``. Returns the
        **top-left** cell of the merged region so the result is
        addressable consistently regardless of which corner the caller
        started from. The earlier impl always returned ``self``, which
        was wrong when ``self`` was the bottom-right corner.
        """
        if other_cell._table is not self._table:
            raise ValidationError(
                "Cannot merge cells from different tables.",
            )
        # Normalize to top-left / bottom-right so the merge_cells op
        # always receives a well-formed rectangle (start ≤ end). Some
        # SuperDoc validators reject inverted ranges.
        top_row = min(self._row, other_cell._row)
        bot_row = max(self._row, other_cell._row)
        left_col = min(self._col, other_cell._col)
        right_col = max(self._col, other_cell._col)
        nid: str = self._table._fresh_node_id()
        run_sync(
            self._table._session.doc.tables.merge_cells(
                {
                    "nodeId": nid,
                    "start": {"rowIndex": top_row, "columnIndex": left_col},
                    "end": {
                        "rowIndex": bot_row,
                        "columnIndex": right_col,
                    },
                },
            ),
        )
        # Return the top-left cell. If self is already the top-left,
        # return self so we keep cached state; otherwise build a fresh
        # _Cell at the top-left address.
        if self._row == top_row and self._col == left_col:
            return self
        return type(self)(table=self._table, row=top_row, col=left_col)

    @property
    def grid_span(self) -> int:
        """Number of layout-grid columns this cell spans horizontally.

        Mirrors python-docx ``_Cell.grid_span``. A "normal" cell has
        ``grid_span == 1``; a horizontally-merged cell that covers
        three logical columns has ``grid_span == 3``. Vertical merges
        do NOT affect ``grid_span``.
        """
        info = self._cell_info()
        if isinstance(info, dict):
            span = info.get("gridSpan") or info.get("grid_span") or 1
            try:
                return max(1, int(span))
            except (TypeError, ValueError):
                return 1
        return 1

    def _inner_block_ids(self) -> list[tuple[str, str]]:
        """Walk the cell's ``getNodeById`` payload and collect every
        block child as ``(nodeId, nodeType)`` in document order.

        Mirrors :func:`_collect_paragraph_ids` but is type-aware —
        paragraph/heading/table blocks all show up. Used by
        :meth:`iter_inner_content`.
        """
        cell_id = self._cell_id()
        session = self._table._session
        # Try the same strategy ladder as _inner_paragraph_ids; whichever
        # response returns blocks wins.
        info: object = None
        for params in (
            {"id": cell_id, "nodeType": "tableCell"},
            {"id": cell_id},
        ):
            try:
                info = run_sync(session.doc.get_node_by_id(params))
                break
            except Exception:
                info = None
        if info is None:
            try:
                info = run_sync(
                    session.doc.get_node(
                        {
                            "target": {
                                "kind": "block",
                                "nodeType": "tableCell",
                                "nodeId": cell_id,
                            },
                        },
                    ),
                )
            except Exception:
                info = None
        out: list[tuple[str, str]] = []
        seen: set[str] = set()
        _collect_block_ids(info, out, seen)
        return out

    def iter_inner_content(self):
        """Yield each paragraph or table inside this cell in order.

        Mirrors python-docx ``_Cell.iter_inner_content() ->
        Iterator[Paragraph | Table]``. Tables nested inside the cell
        appear interleaved with paragraphs at their actual position.
        """
        from docx.text.paragraph import Paragraph

        for nid, ntype in self._inner_block_ids():
            if ntype == "table":
                yield Table(session=self._table._session, node_id=nid)
            else:
                # paragraph / heading / listItem all flow through Paragraph
                # — python-docx exposes them all as Paragraph instances.
                yield Paragraph(
                    session=self._table._session,
                    node_id=nid,
                    node_type=ntype if ntype else "paragraph",
                )

    @property
    def vertical_alignment(self) -> "WD_ALIGN_VERTICAL | None":
        from docx.enum.table import WD_ALIGN_VERTICAL

        info = self._cell_info()
        if info and isinstance(info, dict):
            va = info.get("verticalAlign")
            if isinstance(va, str):
                for m in WD_ALIGN_VERTICAL:
                    if m.value == va:
                        return m
        return None

    @vertical_alignment.setter
    def vertical_alignment(self, value: "WD_ALIGN_VERTICAL | str | None") -> None:
        from docx.enum.table import WD_ALIGN_VERTICAL

        if value is None:
            return
        if isinstance(value, WD_ALIGN_VERTICAL):
            v: str = value.to_superdoc()
        else:
            # Mirror python-docx: assigning an unknown vertical-align
            # value raises ``ValueError`` upstream. Previously this
            # setter silently lower-cased any string and shipped it to
            # the wire, where SuperDoc's permissive parser would either
            # drop it or round-trip a garbage value.
            candidate = str(value).lower()
            if not any(m.value == candidate for m in WD_ALIGN_VERTICAL):
                valid = sorted(m.value for m in WD_ALIGN_VERTICAL)
                raise ValueError(
                    f"{value!r} is not a valid WD_ALIGN_VERTICAL; "
                    f"expected one of {valid}",
                )
            v = candidate
        run_sync(
            self._table._session.doc.tables.set_cell_properties(
                {"target": self._cell_address(), "verticalAlign": v},
            ),
        )

    @property
    def width(self) -> "Length | None":
        info = self._cell_info()
        if info and isinstance(info, dict):
            w = info.get("preferredWidthPt") or info.get("widthPt")
            if isinstance(w, (int, float)):
                return Pt(float(w))
        return None

    @width.setter
    def width(self, value: "Length | int | None") -> None:
        if value is None:
            return
        # Mirror python-docx + ``_Column.width``: cell width is unsigned
        # twips; negative widths previously round-tripped to the wire
        # silently. Reject at the call site so callers learn at the
        # mutation, not on render.
        raw_emu = int(value)
        if raw_emu < 0:
            raise ValueError(
                f"_Cell.width must be non-negative; got EMU={raw_emu}. "
                f"Pass Length(0) (or None) to clear instead of a negative."
            )
        pt: float = value.pt if isinstance(value, Length) else float(value) / 12700.0
        run_sync(
            self._table._session.doc.tables.set_cell_properties(
                {"target": self._cell_address(), "preferredWidthPt": pt},
            ),
        )

    @property
    def height(self) -> "Length | None":
        # python-docx: Cell has no 'height' directly; row does. Return the row's height.
        row = _Row(table=self._table, index=self._row)
        return row.height

    @height.setter
    def height(self, value: "Length | int | None") -> None:
        row = _Row(table=self._table, index=self._row)
        row.height = value
