"""Exception types for athena-python-docx."""

from __future__ import annotations


class DocxError(Exception):
    """Base class for all athena-python-docx errors."""


class SessionError(DocxError):
    """Raised when the Superdoc SDK session cannot be established or used."""


class AuthenticationError(SessionError):
    """Raised when Keryx rejects the collab token."""


class UnsupportedProviderError(SessionError):
    """Raised when the asset is on ysweet instead of yhub.

    Phase 1 only supports yhub; ysweet-routed assets must be migrated first.
    """


class DocumentClosedError(DocxError):
    """Raised when operating on a closed Document."""


class ValidationError(DocxError):
    """Raised when SDK-level validation fails (bad args, out-of-range indices)."""


class NotFoundError(DocxError):
    """Raised when a server-side lookup determines that the addressed
    entity does not exist (comment id, node id, …).

    Distinct from :class:`DocxError` so callers can speculatively read
    (``Comments.get``, future ``find_by_id`` patterns) and coerce a
    typed miss to ``None`` without swallowing real transport/auth
    failures.
    """

    def __init__(self, message: str, payload: dict | None = None) -> None:
        super().__init__(message)
        self.payload: dict = payload or {}
