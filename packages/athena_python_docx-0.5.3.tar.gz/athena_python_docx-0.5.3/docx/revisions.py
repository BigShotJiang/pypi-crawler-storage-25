"""``docx.revisions`` — tracked-changes surface (Athena extension).

python-docx upstream has **no** track-changes API. The closest you get
is hand-edited XML on ``Document.settings.element`` to toggle the
``<w:trackChanges/>`` flag. Everything else (listing changes, accepting
or rejecting them, attribution) is left to Word.

athena-python-docx exposes a richer surface because the SuperDoc
backend models tracked changes as first-class entities:

  * :class:`Revision` — a single tracked insert/delete/format change
    with id, type, author, email, timestamp, and excerpt.
  * :class:`Revisions` — collection. ``doc.revisions`` yields one;
    iterable; supports ``get(id)``, ``accept_all()``, ``reject_all()``,
    ``accept(id)``, ``reject(id)``.
  * :class:`Revision.accept` / :class:`Revision.reject` — convenience
    methods on the proxy that route through ``Revisions.{accept,
    reject}``.

The companion surface lives on :class:`docx.document.Document`:

  * ``Document.track_revisions`` — bool property. When ``True``,
    subsequent mutations are recorded as tracked revisions instead of
    direct edits.
  * ``Document.tracked_revisions()`` — context manager that scopes the
    track-revisions flag to a ``with`` block.
  * ``Document.user_name`` / ``Document.user_email`` — author identity
    for tracked changes (threaded through to SuperDoc on session-open).

These are documented as Athena deviations in
``python-sdk/CLAUDE.md`` § *Intentional deviations*.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import TYPE_CHECKING

from docx._batching import run_sync
from docx.commands import TrackChangesDecide, TrackChangesGet, TrackChangesList
from docx.errors import DocxError, ValidationError

if TYPE_CHECKING:
    from collections.abc import Iterator

    from docx.client import Session


# Valid SuperDoc revision types. SuperDoc uses these strings on the wire;
# we expose them as a literal alias rather than an Enum so users can
# write ``rev.type == "insert"`` without importing anything else.
_VALID_TYPES = ("insert", "delete", "format")


def _coerce_iso_date(raw: object) -> "datetime | None":
    """SuperDoc returns ``date`` as an ISO-8601 string; coerce to a
    timezone-aware :class:`datetime`. Returns ``None`` for malformed or
    missing values rather than raising — callers can still read the raw
    string via :attr:`Revision.raw`.
    """
    if not isinstance(raw, str) or not raw:
        return None
    try:
        # python 3.11+: fromisoformat handles trailing 'Z' as UTC. We
        # support 3.10 by manually stripping the Z first.
        s = raw.rstrip("Z")
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=timezone.utc)
        return dt
    except ValueError:
        return None


class Revision:
    """A single tracked change in the document.

    Attributes are read-only — SuperDoc treats the change author/date
    as immutable metadata baked at the time the revision was created.
    To resolve a revision, call :meth:`accept` or :meth:`reject`.
    """

    __slots__ = ("_session", "_info")

    def __init__(self, *, session: "Session", info: dict) -> None:
        self._session: "Session" = session
        self._info: dict = dict(info or {})

    # ---- Identity ----
    @property
    def id(self) -> str:
        """The SuperDoc entity id for this change.

        Stable across batches but specific to a single document
        revision history — passing it to a different document is an
        error.
        """
        # SuperDoc uses ``id`` on list/get; the address sub-object also
        # carries ``entityId``. Prefer the top-level field, fall back.
        v = self._info.get("id")
        if not isinstance(v, str) or not v:
            addr = self._info.get("address")
            if isinstance(addr, dict):
                v = addr.get("entityId", "")
        return str(v or "")

    @property
    def type(self) -> str:
        """``"insert"``, ``"delete"``, or ``"format"``."""
        v = self._info.get("type", "")
        return str(v) if isinstance(v, str) else ""

    @property
    def author(self) -> str:
        v = self._info.get("author", "")
        return str(v) if isinstance(v, str) else ""

    @property
    def author_email(self) -> str:
        v = self._info.get("authorEmail", "")
        return str(v) if isinstance(v, str) else ""

    @property
    def date(self) -> "datetime | None":
        """Timezone-aware :class:`datetime` of the change.

        ``None`` if SuperDoc didn't return a parseable timestamp; in
        that case :attr:`raw_date` carries the original string.
        """
        return _coerce_iso_date(self._info.get("date"))

    @property
    def raw_date(self) -> str:
        """The unparsed ISO-8601 string from SuperDoc, or ``""``.

        Useful when SuperDoc returns a non-standard format that
        :func:`datetime.fromisoformat` can't parse; the string is
        always preserved verbatim.
        """
        v = self._info.get("date", "")
        return str(v) if isinstance(v, str) else ""

    @property
    def excerpt(self) -> str:
        """A short text excerpt from the changed range, if SuperDoc
        provided one. May be empty for format-only changes."""
        v = self._info.get("excerpt", "")
        return str(v) if isinstance(v, str) else ""

    @property
    def story(self) -> "dict | None":
        """The story locator (body / header / footnote) the change
        lives in, or ``None`` for the default body story."""
        addr = self._info.get("address")
        if isinstance(addr, dict):
            story = addr.get("story")
            if isinstance(story, dict):
                return dict(story)
        s = self._info.get("story")
        return dict(s) if isinstance(s, dict) else None

    # ---- Decisions ----

    def accept(self) -> None:
        """Accept this tracked change.

        For inserts this finalizes the new content; for deletes it
        removes the marked text; for format changes it commits the
        formatting. After ``accept()`` the revision id is no longer
        valid — querying it raises a :class:`DocxError`.
        """
        _decide_one(self._session, self.id, "accept", story=self.story)

    def reject(self) -> None:
        """Reject this tracked change.

        For inserts this removes the inserted text; for deletes it
        restores the marked text; for format changes it reverts the
        formatting. After ``reject()`` the revision id is no longer
        valid.
        """
        _decide_one(self._session, self.id, "reject", story=self.story)

    def __repr__(self) -> str:
        return (
            f"<Revision id={self.id!r} type={self.type!r} "
            f"author={self.author!r}>"
        )


def _decide_one(
    session: "Session",
    change_id: str,
    decision: str,
    *,
    story: "dict | None",
) -> None:
    if not change_id:
        raise ValidationError("Cannot accept/reject a revision without an id.")
    if decision not in ("accept", "reject"):
        raise ValidationError(
            f"decision must be 'accept' or 'reject'; got {decision!r}"
        )
    target: dict = {"id": change_id}
    if story is not None:
        target["story"] = story
    run_sync(
        session.doc.track_changes.decide(
            {"decision": decision, "target": target}
        )
    )


def _decide_all(session: "Session", decision: str) -> None:
    if decision not in ("accept", "reject"):
        raise ValidationError(
            f"decision must be 'accept' or 'reject'; got {decision!r}"
        )
    run_sync(
        session.doc.track_changes.decide(
            {"decision": decision, "target": {"scope": "all"}}
        )
    )


class Revisions:
    """Collection of all tracked changes in the document.

    Iterable / sized. Reading is a snapshot — the list reflects the
    state at the time of the call, not a live view.

    Examples
    --------

    Walk and accept everything by a specific author::

        for rev in doc.revisions:
            if rev.author == "Athena Agent":
                rev.accept()

    Bulk-accept all changes::

        doc.revisions.accept_all()

    Look up a single change by id::

        rev = doc.revisions.get("tc-7")
        if rev is not None:
            print(rev.type, rev.excerpt)
    """

    def __init__(self, *, session: "Session") -> None:
        self._session: "Session" = session

    def _items(
        self,
        *,
        change_type: "str | None" = None,
        limit: "int | None" = None,
        offset: "int | None" = None,
    ) -> list[dict]:
        params: dict = {}
        if change_type is not None:
            if change_type not in _VALID_TYPES:
                raise ValidationError(
                    "change_type must be one of "
                    f"{_VALID_TYPES}; got {change_type!r}"
                )
            params["type"] = change_type
        if limit is not None:
            params["limit"] = int(limit)
        if offset is not None:
            params["offset"] = int(offset)
        result: object = run_sync(self._session.doc.track_changes.list(params))
        if isinstance(result, dict):
            items = result.get("items")
            if isinstance(items, list):
                return [i for i in items if isinstance(i, dict)]
        return []

    def __iter__(self) -> "Iterator[Revision]":
        for item in self._items():
            yield Revision(session=self._session, info=item)

    def __len__(self) -> int:
        # Prefer SuperDoc's authoritative ``total`` over walking
        # ``items`` so a paged read returns the true population size.
        result: object = run_sync(self._session.doc.track_changes.list({}))
        if isinstance(result, dict):
            total = result.get("total")
            if isinstance(total, int):
                return total
            items = result.get("items")
            if isinstance(items, list):
                return len(items)
        return 0

    def list(
        self,
        *,
        change_type: "str | None" = None,
        limit: "int | None" = None,
        offset: "int | None" = None,
    ) -> "list[Revision]":
        """Return a filtered list of revisions.

        Filter ``change_type`` to ``"insert"`` / ``"delete"`` /
        ``"format"`` to narrow the result; ``limit`` / ``offset``
        paginate (SuperDoc applies its own ceiling).
        """
        items = self._items(
            change_type=change_type, limit=limit, offset=offset
        )
        return [Revision(session=self._session, info=i) for i in items]

    def get(self, change_id: "str | int") -> "Revision | None":
        """Look up a single revision by its SuperDoc entity id.

        Returns ``None`` if no revision with that id exists. Other
        backend errors (auth, transport) propagate as
        :class:`DocxError`.
        """
        try:
            result: object = run_sync(
                self._session.doc.track_changes.get({"id": str(change_id)})
            )
        except DocxError:
            return None
        if isinstance(result, dict) and result.get("id"):
            return Revision(session=self._session, info=result)
        return None

    def accept(self, change_id_or_revision: "str | int | Revision") -> None:
        """Accept a single tracked change by id or :class:`Revision`."""
        if isinstance(change_id_or_revision, Revision):
            change_id_or_revision.accept()
            return
        _decide_one(
            self._session, str(change_id_or_revision), "accept", story=None
        )

    def reject(self, change_id_or_revision: "str | int | Revision") -> None:
        """Reject a single tracked change by id or :class:`Revision`."""
        if isinstance(change_id_or_revision, Revision):
            change_id_or_revision.reject()
            return
        _decide_one(
            self._session, str(change_id_or_revision), "reject", story=None
        )

    def accept_all(self) -> None:
        """Accept every pending tracked change in the document.

        Convenience wrapper for ``decide(target={scope: "all"},
        decision: "accept")``. After this, the document's revisions
        list is empty.
        """
        _decide_all(self._session, "accept")

    def reject_all(self) -> None:
        """Reject every pending tracked change in the document.

        After this, the document's revisions list is empty and the
        document content reverts to the pre-tracking state.
        """
        _decide_all(self._session, "reject")


# Re-export the wire dataclasses so advanced callers can construct
# commands directly without reaching into ``docx.commands``.
__all__ = [
    "Revision",
    "Revisions",
    "TrackChangesDecide",
    "TrackChangesGet",
    "TrackChangesList",
]
