"""Tests pinning Settings silent-stub behavior.

These verify that ``Settings.odd_and_even_pages_header_footer`` warns
when set (because there is no SuperDoc ``doc.settings.set`` op to
persist the value) and that ``Settings.element`` raises
``AttributeError`` instead of silently returning ``None`` — callers
should fail loudly rather than crash on ``NoneType.append`` further
downstream.

See ``python-sdk/CLAUDE.md`` § 'Intentionally omitted' and
``docx-studio/SUPERDOC_UPSTREAM_REQUESTS.md`` § 8.
"""

from __future__ import annotations

import warnings
from typing import Any

import pytest

from docx.settings import PendingSettingsMutationWarning, Settings


def test_odd_and_even_pages_header_footer_setter_warns_once(
    mock_session: Any,
) -> None:
    """Setting ``odd_and_even_pages_header_footer`` emits
    :class:`PendingSettingsMutationWarning` exactly once — the value
    is stashed in-process but not persisted to the document.
    """
    s = Settings(session=mock_session)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter("always")
        s.odd_and_even_pages_header_footer = True
    pending = [
        w for w in captured
        if issubclass(w.category, PendingSettingsMutationWarning)
    ]
    assert len(pending) == 1, (
        f"expected exactly one PendingSettingsMutationWarning, got "
        f"{[str(w.message) for w in pending]}"
    )
    assert "odd_and_even_pages_header_footer" in str(pending[0].message)


def test_odd_and_even_pages_header_footer_reads_back_stashed_value(
    mock_session: Any,
) -> None:
    """After writing, reads return the stashed value (best-effort,
    in-process only — a fresh Document will not see it)."""
    s = Settings(session=mock_session)
    assert s.odd_and_even_pages_header_footer is False
    with pytest.warns(PendingSettingsMutationWarning):
        s.odd_and_even_pages_header_footer = True
    assert s.odd_and_even_pages_header_footer is True
    with pytest.warns(PendingSettingsMutationWarning):
        s.odd_and_even_pages_header_footer = False
    assert s.odd_and_even_pages_header_footer is False


def test_settings_element_raises_attribute_error(mock_session: Any) -> None:
    """``Settings.element`` raises ``AttributeError`` rather than
    silently returning ``None``. python-docx upstream returns the
    underlying lxml element; we don't expose lxml so callers must fail
    loudly."""
    s = Settings(session=mock_session)
    with pytest.raises(AttributeError, match="Settings.element"):
        _ = s.element
