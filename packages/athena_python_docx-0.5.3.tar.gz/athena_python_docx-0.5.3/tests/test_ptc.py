"""Tests for the Programmatic Tool Calling (PTC) trace client.

The trace client (``docx._ptc``) is intentionally side-effect-only:
- No ATHENA_PTC_URL set ⇒ ``emit_begin``/``emit_end`` are no-ops.
- URL set ⇒ background thread POSTs to the URL verbatim. The URL
  itself carries the auth (HMAC-signed token in ``?t=``).
"""

from __future__ import annotations

import importlib
import json
import os
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any


# ---------------------------------------------------------------------------
# Tiny capture server
# ---------------------------------------------------------------------------


class _CaptureServer:
    def __init__(self) -> None:
        self.requests: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        outer = self

        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *_args: Any, **_kwargs: Any) -> None:
                pass

            def do_POST(self) -> None:
                length = int(self.headers.get("Content-Length", "0"))
                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw.decode("utf-8"))
                except Exception:  # noqa: BLE001
                    body = None
                with outer._lock:
                    outer.requests.append(
                        {
                            "path": self.path,
                            "headers": dict(self.headers),
                            "body": body,
                        }
                    )
                self.send_response(204)
                self.end_headers()

        self._server = HTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            daemon=True,
        )
        self._thread.start()

    def url(self, *, query: str = "t=fake-token") -> str:
        host, port = self._server.server_address[:2]
        host_str = host if isinstance(host, str) else host.decode()
        return f"http://{host_str}:{port}/api/runtime/ptc-events?{query}"

    def stop(self) -> None:
        self._server.shutdown()
        self._server.server_close()
        self._thread.join(timeout=1.0)

    def wait_for_requests(self, n: int, timeout: float = 2.0) -> None:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            with self._lock:
                if len(self.requests) >= n:
                    return
            time.sleep(0.01)
        raise AssertionError(
            f"timed out waiting for {n} request(s); got {len(self.requests)}",
        )


# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------


_PTC_URL_KEY = "ATHENA_PTC_URL"


def _clear_ptc_env() -> str | None:
    saved = os.environ.get(_PTC_URL_KEY)
    os.environ.pop(_PTC_URL_KEY, None)
    return saved


def _restore_ptc_env(saved: str | None) -> None:
    if saved is None:
        os.environ.pop(_PTC_URL_KEY, None)
    else:
        os.environ[_PTC_URL_KEY] = saved


def _fresh_ptc_module():
    """Reload docx._ptc so the module-level _CLIENT picks up changes."""
    import docx._ptc as ptc_mod

    return importlib.reload(ptc_mod)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_no_env_is_noop() -> None:
    saved = _clear_ptc_env()
    try:
        ptc = _fresh_ptc_module()
        call_id = ptc.emit_begin("CreateParagraph", {"text": "x"})
        assert isinstance(call_id, str) and len(call_id) > 0
        ptc.emit_end(
            call_id=call_id,
            tool_name="CreateParagraph",
            result={"ok": True},
            is_error=False,
        )
        thread_names = {t.name for t in threading.enumerate()}
        assert "athena-docx-ptc" not in thread_names
    finally:
        _restore_ptc_env(saved)


def test_env_enabled_emits_begin_and_end() -> None:
    saved = _clear_ptc_env()
    server = _CaptureServer()
    try:
        url = server.url(query="t=presigned-token-A")
        os.environ[_PTC_URL_KEY] = url

        ptc = _fresh_ptc_module()
        call_id = ptc.emit_begin("CreateParagraph", {"text": "hi"})
        ptc.emit_end(
            call_id=call_id,
            tool_name="CreateParagraph",
            result={"ok": True},
            is_error=False,
        )

        server.wait_for_requests(2)
        begin_req, end_req = server.requests[0], server.requests[1]

        # Both events hit the exact presigned URL (path + query intact).
        assert begin_req["path"] == "/api/runtime/ptc-events?t=presigned-token-A"
        assert end_req["path"] == "/api/runtime/ptc-events?t=presigned-token-A"

        # Body only carries per-call info — no triple, no auth.
        for body in (begin_req["body"], end_req["body"]):
            assert body["callId"] == call_id
            assert body["toolName"] == "docx.CreateParagraph"
            # The (thread, parent, run) triple lives in the URL token,
            # NOT in the body. Keep this assertion strict so regressions
            # that add it back to the body get caught.
            for forbidden in ("threadId", "parentToolCallId", "runId"):
                assert forbidden not in body

        assert begin_req["body"]["phase"] == "begin"
        assert begin_req["body"]["args"] == {"text": "hi"}

        assert end_req["body"]["phase"] == "end"
        assert end_req["body"]["result"] == {"ok": True}
        assert end_req["body"]["isError"] is False

        # No Authorization header — auth is the URL.
        assert "Authorization" not in begin_req["headers"]
        assert "Authorization" not in end_req["headers"]
    finally:
        server.stop()
        _restore_ptc_env(saved)


def test_emit_end_uses_url_snapshot_from_begin() -> None:
    """If ATHENA_PTC_URL changes between begin and end (a new sandbox
    run swapping in a different presigned URL), the end event still
    posts to the begin-time URL. Prevents cross-run attribution bugs."""
    saved = _clear_ptc_env()
    server_a = _CaptureServer()
    server_b = _CaptureServer()
    try:
        os.environ[_PTC_URL_KEY] = server_a.url(query="t=token-A")

        ptc = _fresh_ptc_module()
        call_id = ptc.emit_begin("SetParagraphAlignment", {"alignment": "center"})

        # Simulate a new sandbox execution starting between begin & end.
        os.environ[_PTC_URL_KEY] = server_b.url(query="t=token-B")

        ptc.emit_end(
            call_id=call_id,
            tool_name="SetParagraphAlignment",
            result={"ok": True},
            is_error=False,
        )

        server_a.wait_for_requests(2)
        assert len(server_b.requests) == 0
        for req in (server_a.requests[0], server_a.requests[1]):
            assert req["path"].endswith("?t=token-A")
    finally:
        server_a.stop()
        server_b.stop()
        _restore_ptc_env(saved)


def test_unreachable_endpoint_does_not_raise() -> None:
    saved = _clear_ptc_env()
    try:
        # 127.0.0.1:1 is a well-known closed port.
        os.environ[_PTC_URL_KEY] = "http://127.0.0.1:1/api/runtime/ptc-events?t=x"

        ptc = _fresh_ptc_module()
        call_id = ptc.emit_begin("CreateParagraph", {"text": "x"})
        ptc.emit_end(
            call_id=call_id,
            tool_name="CreateParagraph",
            result={"ok": False},
            is_error=True,
        )
        time.sleep(0.1)
    finally:
        _restore_ptc_env(saved)


def test_emit_end_without_begin_is_silent_noop() -> None:
    saved = _clear_ptc_env()
    server = _CaptureServer()
    try:
        os.environ[_PTC_URL_KEY] = server.url()

        ptc = _fresh_ptc_module()
        ptc.emit_end(
            call_id="never-begun",
            tool_name="CreateParagraph",
            result={"ok": True},
            is_error=False,
        )
        time.sleep(0.1)
        assert server.requests == []
    finally:
        server.stop()
        _restore_ptc_env(saved)


class _FakeHttpClient:
    """Mirror of the existing test_buffer FakeClient — records batches."""

    def __init__(self, raise_on_call: bool = False) -> None:
        self.batches: list[list[Any]] = []
        self._raise = raise_on_call

    def execute_batch(
        self,
        _asset_id: str,
        commands: list[Any],
        *,
        change_mode: Any = None,
        user: Any = None,
    ) -> list[dict[str, Any]]:
        self.batches.append(list(commands))
        if self._raise:
            raise RuntimeError("simulated transport failure")
        return [{} for _ in commands]


def _stub_ptc(monkeypatch: Any) -> dict[str, list[Any]]:
    """Replace _ptc.emit_begin / emit_end with recorders."""
    import docx._buffer as buffer_mod

    calls: dict[str, list[Any]] = {"begin": [], "end": []}
    counter = {"n": 0}

    def fake_begin(tool_name: str, args: dict[str, Any]) -> str:
        counter["n"] += 1
        call_id = f"fake-call-{counter['n']}"
        calls["begin"].append((tool_name, args, call_id))
        return call_id

    def fake_end(
        *,
        call_id: str,
        tool_name: str,
        result: dict[str, Any] | None,
        is_error: bool,
    ) -> None:
        calls["end"].append(
            {
                "call_id": call_id,
                "tool_name": tool_name,
                "result": result,
                "is_error": is_error,
            }
        )

    monkeypatch.setattr(buffer_mod._ptc, "emit_begin", fake_begin)
    monkeypatch.setattr(buffer_mod._ptc, "emit_end", fake_end)
    return calls


def test_buffer_emits_begin_on_call_and_end_on_flush(monkeypatch: Any) -> None:
    from docx._buffer import CommandBuffer
    from docx.commands import SetParagraphAlignment

    calls = _stub_ptc(monkeypatch)
    client = _FakeHttpClient()
    buf = CommandBuffer(client, asset_id="asset-1", auto_flush_seconds=0)

    buf.call(SetParagraphAlignment(target={}, alignment="center"))
    buf.call(SetParagraphAlignment(target={}, alignment="left"))

    assert len(calls["begin"]) == 2
    assert calls["begin"][0][0] == "SetParagraphAlignment"
    assert len(calls["end"]) == 0

    buf.flush()
    assert len(calls["end"]) == 2
    assert all(c["is_error"] is False for c in calls["end"])
    assert all(c["result"] == {"ok": True} for c in calls["end"])


def test_buffer_emits_end_with_error_on_flush_failure(monkeypatch: Any) -> None:
    from docx._buffer import CommandBuffer
    from docx.commands import SetParagraphAlignment

    calls = _stub_ptc(monkeypatch)
    client = _FakeHttpClient(raise_on_call=True)
    buf = CommandBuffer(client, asset_id="asset-1", auto_flush_seconds=0)

    buf.call(SetParagraphAlignment(target={}, alignment="center"))
    assert len(calls["begin"]) == 1

    import pytest as _pytest

    with _pytest.raises(RuntimeError):
        buf.flush()

    assert len(calls["end"]) == 1
    assert calls["end"][0]["is_error"] is True
