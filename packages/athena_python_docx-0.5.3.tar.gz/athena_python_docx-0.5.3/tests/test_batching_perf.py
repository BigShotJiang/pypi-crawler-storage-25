"""Tests for the ``Document.batch()`` / ``CommandBuffer.batch()`` true-batching path.

Verifies the perf-critical contract documented in
``docx-studio/PERFORMANCE_BATCHING_ANALYSIS.md``: when a caller wraps
their edits in ``with doc.batch():``, Create*-shape commands buffer
alongside subsequent mutations and the entire sequence ships in **one**
HTTP request instead of one-per-Create.

The batching mechanism has three layers, each pinned by tests below:

1. **Python SDK** generates a client-side UUID (``client_node_id``)
   for each Create*, sets it on the command dataclass, and stamps the
   returned proxy with the same id. The buffer defers the Create when
   ``is_batching`` is True instead of eager-flushing it.
2. **Wire format** carries ``clientNodeId`` (camelCase per
   ``_snake_to_camel``) into the Zod-validated command.
3. **Server applier** translates client UUIDs → real SuperDoc ids in a
   per-batch ``clientIdMap`` and echoes both ``client_node_id`` and
   ``real_node_id`` in the per-cmd response. The SDK's flush rewrites
   each registered proxy's ``_node_id`` so subsequent batches use the
   real id transparently.

These tests cover layer 1 + 2 (and the SDK's response handling for
layer 3) via the fake HTTP client. The applier-side rewriter is covered
separately by the server-side test suite (TypeScript).
"""

from __future__ import annotations

import threading
from typing import Any

from docx._buffer import CommandBuffer
from docx.commands import Command, CreateParagraph, FormatApply


class _RecordingClient:
    """Fake HTTP client that records every batch and echoes
    ``real_node_id`` for each Create* that carries a ``client_node_id``.
    Mirrors the applier's ``clientIdMap`` echo behavior so we can
    exercise the Python-side proxy-rewrite path end-to-end without a
    real server.
    """

    def __init__(self) -> None:
        self.batches: list[list[Command]] = []
        self.envelopes: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._real_id_seq = 0

    def execute_batch(
        self,
        asset_id: str,  # noqa: ARG002
        commands: list[Command],
        *,
        change_mode: str | None = None,
        user: dict[str, str] | None = None,
    ) -> list[Any]:
        with self._lock:
            self.batches.append(list(commands))
            self.envelopes.append({"changeMode": change_mode, "user": user})
            results: list[Any] = []
            for cmd in commands:
                cli = getattr(cmd, "client_node_id", None)
                if cli is not None:
                    self._real_id_seq += 1
                    real = f"srv_{self._real_id_seq:04d}"
                    results.append(
                        {
                            "ok": True,
                            "client_node_id": cli,
                            "real_node_id": real,
                        },
                    )
                else:
                    results.append({"ok": True})
            return results


def test_create_paragraph_outside_batch_is_eager() -> None:
    """Outside ``with doc.batch():``, a CreateParagraph (which is
    response-bearing) eager-flushes immediately. This preserves the
    pre-batching default behavior so non-batched callers don't change."""
    fake = _RecordingClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)
    assert buf.is_batching is False

    buf.call(CreateParagraph(text="hello", at={"kind": "documentEnd"}))

    # One HTTP batch fired immediately because Create* is response-bearing.
    assert len(fake.batches) == 1
    assert [c.type for c in fake.batches[0]] == ["CreateParagraph"]
    buf.close()


def test_create_paragraph_in_batch_with_client_id_defers() -> None:
    """Inside batch mode, a CreateParagraph carrying a
    ``client_node_id`` does NOT flush — it queues alongside subsequent
    mutations."""
    fake = _RecordingClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)

    with buf.batch():
        assert buf.is_batching is True
        buf.call(
            CreateParagraph(
                text="hello",
                at={"kind": "documentEnd"},
                client_node_id="cli_abc12345",
            ),
        )
        # Still no HTTP request — Create is buffered now.
        assert fake.batches == []
        # A mutation that targets the as-yet-unresolved client id.
        buf.call(
            FormatApply(
                target={"kind": "block", "nodeId": "cli_abc12345"},
                inline={"bold": True},
            ),
        )
        assert fake.batches == []

    # Block exit triggers one flush — one HTTP request total.
    assert len(fake.batches) == 1
    types = [c.type for c in fake.batches[0]]
    assert types == ["CreateParagraph", "FormatApply"]


def test_proxy_id_ref_gets_rewritten_after_flush() -> None:
    """When a Create with a client_node_id flushes, the buffer rewrites
    the registered proxy's ``_node_id`` to the real server id."""

    class _FakeProxy:
        def __init__(self, node_id: str) -> None:
            self._node_id = node_id

    fake = _RecordingClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)
    proxy = _FakeProxy(node_id="cli_xyz98765")

    with buf.batch():
        buf.call(
            CreateParagraph(
                text="hi",
                at={"kind": "documentEnd"},
                client_node_id="cli_xyz98765",
            ),
        )
        buf.register_proxy_id_ref("cli_xyz98765", proxy, "_node_id")

    # After flush, the proxy's id was rewritten from client to server.
    assert proxy._node_id.startswith("srv_")
    assert proxy._node_id != "cli_xyz98765"


def test_30_paragraphs_in_batch_is_one_http_request() -> None:
    """The headline perf test: 30 ``CreateParagraph`` calls inside
    ``with buffer.batch():`` produce exactly ONE HTTP batch. Without
    batching this would be 30 separate round-trips (the prior
    behavior). See ``PERFORMANCE_BATCHING_ANALYSIS.md``."""
    fake = _RecordingClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)

    with buf.batch():
        for i in range(30):
            buf.call(
                CreateParagraph(
                    text=f"para {i}",
                    at={"kind": "documentEnd"},
                    client_node_id=f"cli_p{i:04d}",
                ),
            )

    assert len(fake.batches) == 1, (
        f"expected exactly 1 HTTP batch, got {len(fake.batches)}"
    )
    assert len(fake.batches[0]) == 30


def test_create_without_client_id_in_batch_still_eager_flushes() -> None:
    """Defensive: a Create without a client_node_id (legacy callers /
    direct ``buffer.call``) still eager-flushes inside a batch — the
    deferral is keyed on the presence of the client id, not the batch
    flag alone. This preserves the historical contract for callers
    that haven't been updated to pre-assign UUIDs."""
    fake = _RecordingClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)

    with buf.batch():
        # No client_node_id → eager.
        buf.call(CreateParagraph(text="x", at={"kind": "documentEnd"}))
        # Should have flushed immediately.
        assert len(fake.batches) == 1
        # A mutation queued after eager flush stays buffered.
        buf.call(
            FormatApply(target={"kind": "block"}, inline={"bold": True}),
        )
        assert len(fake.batches) == 1

    # Block exit flushes the pending mutation.
    assert len(fake.batches) == 2


def test_nested_batch_only_outermost_flushes() -> None:
    """``buffer.batch()`` is reentrant — nested blocks share the same
    queue and only the outer block triggers the actual flush."""
    fake = _RecordingClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)

    with buf.batch():
        buf.call(
            CreateParagraph(
                text="outer",
                at={"kind": "documentEnd"},
                client_node_id="cli_outer",
            ),
        )
        with buf.batch():
            buf.call(
                CreateParagraph(
                    text="inner",
                    at={"kind": "documentEnd"},
                    client_node_id="cli_inner",
                ),
            )
            # Still buffering — inner block exit must NOT flush.
            assert fake.batches == []
        # Outer block still open — inner exit didn't flush.
        assert fake.batches == []

    # Outer block exited — single flush.
    assert len(fake.batches) == 1
    assert len(fake.batches[0]) == 2


def test_client_node_id_on_wire_camelcases_to_clientNodeId() -> None:
    """Wire-format contract: Python's snake_case ``client_node_id``
    serialises to camelCase ``clientNodeId`` on the wire (matches the
    Zod schema field). Pin so a future ``to_dict`` refactor can't
    silently break the wire contract."""
    cmd = CreateParagraph(
        text="hi",
        at={"kind": "documentEnd"},
        client_node_id="cli_test",
    )
    wire = cmd.to_dict()
    assert "clientNodeId" in wire
    assert wire["clientNodeId"] == "cli_test"
    # And the snake-case Python field name does NOT appear on the wire.
    assert "client_node_id" not in wire


def test_create_paragraph_without_client_id_omits_wire_field() -> None:
    """Backwards-compat: a CreateParagraph with no client_node_id (the
    legacy path / non-batch eager flush) MUST NOT emit a
    ``clientNodeId`` field on the wire — the server's Zod schema marks
    it optional but we still want zero-overhead for the default case
    so the wire stays identical to the pre-batching format."""
    cmd = CreateParagraph(text="hi", at={"kind": "documentEnd"})
    wire = cmd.to_dict()
    assert "clientNodeId" not in wire
