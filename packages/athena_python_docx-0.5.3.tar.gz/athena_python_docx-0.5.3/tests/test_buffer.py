"""Tests for the :class:`CommandBuffer` — the HTTP-level batcher that sits
between SDK call sites and :class:`HttpClient`.

Verifies that:
- queries / response-bearing creates flush eagerly,
- pending pure mutations get drained in the same batch as an eager call,
- ``flush()`` drains explicitly,
- ``batch()`` context disables idle timer + flushes on exit,
- the process-wide ``flush_all`` walks every live buffer.
"""

from __future__ import annotations

import threading
import time
from typing import Any

from docx._buffer import CommandBuffer, flush_all
from docx.commands import (
    BlocksList,
    Command,
    CreateParagraph,
    FormatApply,
    Replace,
    SetParagraphAlignment,
)


class _FakeClient:
    """Records every batch handed to ``execute_batch`` and returns one
    empty result per command."""

    def __init__(self) -> None:
        self.batches: list[list[Command]] = []
        # Envelope-level fields recorded per batch — used by
        # track-changes tests to verify changeMode / user propagation.
        self.envelopes: list[dict[str, Any]] = []
        self._lock = threading.Lock()

    def execute_batch(
        self,
        asset_id: str,  # noqa: ARG002
        commands: list[Command],
        *,
        change_mode: str | None = None,
        user: dict[str, str] | None = None,
    ) -> list[Any]:
        with self._lock:
            self.batches.append(list(commands))
            self.envelopes.append(
                {"changeMode": change_mode, "user": user},
            )
        # Mimic per-command result envelope.
        return [{"index": i, "ok": True} for i, _ in enumerate(commands)]


def _types(batch: list[Command]) -> list[str]:
    return [c.type for c in batch]


def test_pure_mutation_buffers_no_immediate_post() -> None:
    """A FormatApply call alone should not POST anything until flush."""
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)
    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    assert fake.batches == []  # buffered only
    assert buf.pending_count == 1
    buf.close()


def test_query_flushes_and_drains_pending() -> None:
    """An eager call (BlocksList) flushes the queue too — order preserved."""
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)

    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf.call(Replace(target={"kind": "selection"}, text="x"))
    result = buf.call(BlocksList())

    # One batch went out, with both buffered mutations + the query at the end.
    assert len(fake.batches) == 1
    assert _types(fake.batches[0]) == [
        "FormatApply",
        "Replace",
        "BlocksList",
    ]
    # Query result is the last applied entry.
    assert result == {"index": 2, "ok": True}
    buf.close()


def test_response_bearing_creates_flush_eagerly() -> None:
    """Creates that return ids must flush — the caller is about to read."""
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)

    buf.call(FormatApply(target={"kind": "block"}, inline={"italic": True}))
    buf.call(CreateParagraph(text="hi", at={"kind": "documentEnd"}))

    assert len(fake.batches) == 1
    assert _types(fake.batches[0]) == ["FormatApply", "CreateParagraph"]
    buf.close()


def test_explicit_flush_drains_pending() -> None:
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)

    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf.call(SetParagraphAlignment(target={"kind": "block"}, alignment="center"))
    assert fake.batches == []
    buf.flush()
    assert len(fake.batches) == 1
    assert _types(fake.batches[0]) == ["FormatApply", "SetParagraphAlignment"]
    buf.close()


def test_flush_with_empty_queue_is_noop() -> None:
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)
    assert buf.flush() == []
    assert fake.batches == []
    buf.close()


def test_idle_timer_auto_flushes() -> None:
    """A non-zero idle window should flush after inactivity.

    Uses a generous margin to avoid CI flakiness on loaded runners —
    100ms idle window with a 500ms wait is 5× scheduling slack and
    has been stable across the local + CI envs we care about.
    """
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.1)
    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    assert fake.batches == []
    time.sleep(0.5)
    assert len(fake.batches) == 1
    assert _types(fake.batches[0]) == ["FormatApply"]
    buf.close()


def test_batch_context_disables_idle_flush_and_drains_on_exit() -> None:
    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.1)
    with buf.batch():
        buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
        # Even past the idle window we shouldn't have flushed.
        time.sleep(0.3)
        buf.call(Replace(target={"kind": "selection"}, text="y"))
        assert fake.batches == []
    # On exit, one batch with both ops in order.
    assert len(fake.batches) == 1
    assert _types(fake.batches[0]) == ["FormatApply", "Replace"]
    buf.close()


def test_close_flushes_and_disables_further_calls() -> None:
    import pytest

    fake = _FakeClient()
    buf = CommandBuffer(fake, "asset_1", auto_flush_seconds=0.0)
    buf.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf.close()
    assert len(fake.batches) == 1
    with pytest.raises(RuntimeError, match="closed"):
        buf.call(FormatApply(target={"kind": "block"}, inline={"italic": True}))


def test_flush_all_walks_every_live_buffer() -> None:
    fake_a = _FakeClient()
    fake_b = _FakeClient()
    buf_a = CommandBuffer(fake_a, "asset_a", auto_flush_seconds=0.0)
    buf_b = CommandBuffer(fake_b, "asset_b", auto_flush_seconds=0.0)
    buf_a.call(FormatApply(target={"kind": "block"}, inline={"bold": True}))
    buf_b.call(Replace(target={"kind": "selection"}, text="z"))

    assert fake_a.batches == [] and fake_b.batches == []
    flush_all()
    assert len(fake_a.batches) == 1
    assert len(fake_b.batches) == 1
    buf_a.close()
    buf_b.close()
