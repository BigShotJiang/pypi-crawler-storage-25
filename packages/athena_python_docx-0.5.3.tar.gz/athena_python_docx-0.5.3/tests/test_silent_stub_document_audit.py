"""Lock-in tests for silent-stub fixes on the Document class.

These tests pin behavior that was previously *silently partial* —
where the SDK accepted bogus input or ignored a user-supplied value
without surfacing the gap. Each test corresponds to a distinct fix
in ``docx/document.py``.

Background: ``athena-python-docx`` must be a 100% behavioral match
for python-docx 1.2.0 (see ``python-sdk/CLAUDE.md``). Where the
asset-backed SDK can't honor an upstream contract, the deviation
must be loud (warning or exception), not silent.

Audited gaps:

1. ``Document.add_section(start_type="bogus")`` previously passed the
   raw string through to SuperDoc, which accepted any string and
   produced a section break with an unknown ``breakType``. Upstream
   python-docx raises ``ValueError`` via enum coercion. Now mirrored.

2. ``Document.add_section(start_type=42)`` (non-str, non-enum) was
   silently swallowed via the ``elif`` fall-through and the default
   ``"nextPage"`` was used. Now raises ``ValueError``.

3. ``Document.save("/tmp/out.docx")`` previously succeeded silently
   without writing a file. The SDK is asset-backed, so file-export
   isn't possible — but a caller passing a path almost certainly
   expects one. We can't raise (intentional deviation pins no-arg +
   arg-form), so we emit ``IgnoredSaveTargetWarning`` to make the
   silent gap visible.
"""

from __future__ import annotations

import io
import warnings
from typing import Any

import pytest


def _make_doc(mock_session: Any):
    """Construct a Document bound to the fake session without opening
    a real Keryx connection. Mirrors the helper in
    ``test_silent_stub_add_picture.py`` (kept local rather than
    cross-imported so this file is self-contained).
    """
    from docx.document import Document as DocClass

    d = DocClass.__new__(DocClass)
    d._session = mock_session
    d._saved = False
    d._closed = False
    d._pending_user_name = None
    d._pending_user_email = None
    d._pending_track_revisions = False
    return d


# ---- add_section: invalid start_type strings ----

def test_add_section_invalid_string_raises_value_error(
    mock_session: Any,
) -> None:
    """Passing a string that isn't a valid ``WD_SECTION_START`` value
    must raise ``ValueError`` to match python-docx's upstream enum
    coercion. Previously this silently routed any string to SuperDoc."""
    doc = _make_doc(mock_session)
    with pytest.raises(ValueError, match="not a valid WD_SECTION_START"):
        doc.add_section("bogus_break_type")


def test_add_section_empty_string_raises_value_error(
    mock_session: Any,
) -> None:
    """The empty string isn't a member value either. Upstream rejects
    it; we must too."""
    doc = _make_doc(mock_session)
    with pytest.raises(ValueError, match="not a valid WD_SECTION_START"):
        doc.add_section("")


def test_add_section_non_string_non_enum_raises_value_error(
    mock_session: Any,
) -> None:
    """Non-string, non-enum values previously fell through to the
    default ``"nextPage"`` silently. Now they raise ``ValueError``
    so callers learn at the call site instead of getting an
    unexpected section break type."""
    doc = _make_doc(mock_session)
    with pytest.raises(ValueError, match="not a valid WD_SECTION_START"):
        doc.add_section(42)  # type: ignore[arg-type]


def test_add_section_accepts_valid_enum_string(
    mock_session: Any,
) -> None:
    """Valid member-value strings remain accepted (parity with
    upstream's ``WD_SECTION_START("continuous")`` coercion)."""
    doc = _make_doc(mock_session)
    # No raise. Scripted return on `sections.list` would normally be
    # an empty dict; we override so the post-create lookup succeeds.
    mock_session.doc.scripted_returns["sections.list"] = {
        "items": [{"address": {"sectionIndex": 0}}],
    }
    doc.add_section("continuous")
    # Verify the break type was translated to SuperDoc's expected wire
    # value (``"continuous"`` for CONTINUOUS).
    section_break_calls = [
        (op, params)
        for op, params in mock_session.doc.calls
        if op == "create.section_break"
    ]
    assert len(section_break_calls) == 1
    _, params = section_break_calls[0]
    assert params is not None
    assert params.get("breakType") == "continuous"


def test_add_section_accepts_enum_member(
    mock_session: Any,
) -> None:
    """Passing a ``WD_SECTION_START`` member directly continues to
    work (the original positive-path contract)."""
    from docx.enum.section import WD_SECTION_START

    doc = _make_doc(mock_session)
    mock_session.doc.scripted_returns["sections.list"] = {
        "items": [{"address": {"sectionIndex": 0}}],
    }
    doc.add_section(WD_SECTION_START.EVEN_PAGE)
    section_break_calls = [
        (op, params)
        for op, params in mock_session.doc.calls
        if op == "create.section_break"
    ]
    assert len(section_break_calls) == 1
    _, params = section_break_calls[0]
    assert params is not None
    assert params.get("breakType") == "evenPage"


# ---- save(path_or_stream): silent ignore → loud warning ----

def test_save_with_path_emits_ignored_save_target_warning(
    mock_session: Any,
) -> None:
    """Passing a string path to ``save()`` must emit
    ``IgnoredSaveTargetWarning`` so callers can see that the SDK
    didn't actually write a file. Previously a caller passing
    ``"/tmp/out.docx"`` got fully silent success and no file on disk.
    The warning is necessary-but-non-fatal: the existing
    ``test_document_save_accepts_no_arg`` test pins that the call
    itself does not raise, and that contract is preserved."""
    from docx.document import IgnoredSaveTargetWarning

    doc = _make_doc(mock_session)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        doc.save("/tmp/should-be-ignored.docx")

    matching = [w for w in caught if issubclass(w.category, IgnoredSaveTargetWarning)]
    assert len(matching) == 1, (
        f"Expected exactly one IgnoredSaveTargetWarning; got {len(matching)}: "
        f"{[str(w.message) for w in caught]}"
    )
    msg = str(matching[0].message)
    assert "/tmp/should-be-ignored.docx" in msg
    assert "Export DOCX" in msg or "asset-backed" in msg.lower()


def test_save_with_stream_emits_ignored_save_target_warning(
    mock_session: Any,
) -> None:
    """A binary stream argument is the other documented call shape
    (``str | BinaryIO``); it should warn for the same reason."""
    from docx.document import IgnoredSaveTargetWarning

    doc = _make_doc(mock_session)
    stream = io.BytesIO()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        doc.save(stream)

    matching = [w for w in caught if issubclass(w.category, IgnoredSaveTargetWarning)]
    assert len(matching) == 1


def test_save_no_arg_does_not_warn(mock_session: Any) -> None:
    """The intentional-deviation no-arg form (``doc.save()``) must
    remain warning-free — the warning is specifically for cases where
    the caller passes a non-None target, which is the silent-stub
    footgun. Locks in that the warning is scoped to the foot-gun
    case only."""
    from docx.document import IgnoredSaveTargetWarning

    doc = _make_doc(mock_session)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        doc.save()

    matching = [w for w in caught if issubclass(w.category, IgnoredSaveTargetWarning)]
    assert matching == [], (
        f"doc.save() (no arg) must not warn — that's the documented "
        f"deviation. Got: {[str(w.message) for w in matching]}"
    )


def test_save_with_path_still_flushes(mock_session: Any) -> None:
    """Verify the warning is additive — the in-place flush still
    happens. Previously the silent gap was that the call appeared to
    succeed; we keep the success behavior so existing call sites
    don't regress, only add the warning."""
    doc = _make_doc(mock_session)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        doc.save("/tmp/anything.docx")
    # session.save() must have been invoked exactly once (via _flush).
    assert mock_session.save.await_count == 1
    assert doc._saved is True
