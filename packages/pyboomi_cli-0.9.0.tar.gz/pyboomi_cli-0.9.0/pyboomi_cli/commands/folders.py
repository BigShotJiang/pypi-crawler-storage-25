# PyBoomi CLI - Folder Command
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-12-12

"""Folder management commands for PyBoomi CLI."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import sys

import click
from pyboomi_platform.utils import build_query_filter

from pyboomi_cli.utils import format_output, get_client

try:
    from pyboomi_platform.exceptions import BoomiAPIError
except (ImportError, AttributeError):
    try:
        from pyboomi_platform import BoomiAPIError  # type: ignore[attr-defined]
    except (ImportError, AttributeError):

        class BoomiAPIError(Exception):  # type: ignore[no-redef]
            """Fallback exception for Boomi API errors."""

            pass


@click.group("folder")
@click.pass_context
@click.option("--account-id", help="Boomi account ID (or use BOOMI_ACCT)")
@click.option("--username", help="Boomi user email (or use BOOMI_USER)")
@click.option("--api-token", help="Boomi Platform API token (or use BOOMI_TOKEN)")
def command(ctx, account_id, username, api_token):
    """
    Manage Boomi folders.

    Priority for credentials:
    - BOOMI_AUTH (base64 encoded Basic Auth string)
    - --username / --api-token CLI args
    - BOOMI_USER / BOOMI_TOKEN env vars

    Account ID can come from --account-id or BOOMI_ACCT env var.

    Note: Options like --account-id must be specified BEFORE the subcommand.
    Example: pyboomi folder --account-id ACCT123 get <folder-id>
    """
    ctx.ensure_object(dict)
    ctx.obj["account_id"] = account_id
    ctx.obj["username"] = username
    ctx.obj["api_token"] = api_token


@command.command("get")
@click.pass_context
@click.argument("id")
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Print full request and response details",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: folder_get_<id>.txt).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def get(ctx, id, verbose, save, save_filename, quiet):
    """Get a folder by ID or name."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        if verbose:
            click.echo(f"Request to: Folder/{id}")

        folder = client.get_folder(id)

        if verbose:
            click.echo("Response:\n")
            click.echo(format_output(folder))

        output_line = f"{folder['id']}: {folder['name']}: {folder.get('fullPath', '')}"
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else f"folder_get_{id}.txt"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(output_line + "\n")
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(output_line)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("query")
@click.pass_context
@click.option("--name", help="Filter folders by name")
@click.option("--parent-id", help="Filter by parent folder ID (uses parentId query filter)")
@click.option("--parent-name", help="Filter by parent folder name (uses parentName query filter)")
@click.option(
    "--parent-path",
    help="Filter results whose fullPath contains this partial parent path",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Print full request and response details",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: folder_query.txt).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def query(ctx, name, parent_id, parent_name, parent_path, verbose, save, save_filename, quiet):
    """Query and list Boomi folders."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        raw_filters = {}
        if name:
            raw_filters["name"] = name
        if parent_id:
            raw_filters["parentId"] = parent_id
        if parent_name:
            raw_filters["parentName"] = parent_name

        filters = build_query_filter(raw_filters) if raw_filters else {}

        if verbose:
            click.echo("Request to: Folder/query")
            click.echo(f"Payload:\n{filters}")

        result = client.query_folders(filters)

        if verbose:
            click.echo(f"Response:\n{result}")

        folders = result.get("result", [])

        if parent_path:
            # Post-filter on fullPath containing the partial parent path
            filtered = []
            for folder in folders:
                full_path = folder.get("fullPath", "")
                if parent_path in full_path:
                    filtered.append(folder)
            if verbose:
                click.echo(f"Filtered {len(folders)} -> {len(filtered)} by parent-path match '{parent_path}'")
            folders = filtered

        lines = [f"{folder['id']}: {folder['name']}: {folder.get('fullPath', '')}" for folder in folders]
        output_text = "\n".join(lines)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "folder_query.txt"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(output_text + ("\n" if output_text else ""))
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            for line in lines:
                click.echo(line)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Alias for lazy developers
command.add_command(query, name="q")


@command.command("create")
@click.pass_context
@click.option("--name", required=True, help="Name of the folder to create")
@click.option("--parent-id", help="Parent folder ID")
@click.option("--parent-name", help="Parent folder name (will be looked up)")
@click.option(
    "--parent-path",
    help="Partial parent path to disambiguate when looking up parent by name",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Print full request and response details",
)
@click.option("--output-format", default="json", type=click.Choice(["json", "yaml", "text"]))
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: folder_create.json).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def create(ctx, name, parent_id, parent_name, parent_path, verbose, output_format, save, save_filename, quiet):
    """Create a folder. Requires a name and a parent (by ID or by name lookup)."""
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        def lookup_parent_by_name():
            """Look up parent folder by name and optional path."""
            # Build query filters for the parent lookup
            raw_filters = {"name": parent_name}
            filters = build_query_filter(raw_filters)
            result = client.query_folders(filters)
            folders = result.get("result", [])

            if parent_path:
                folders = [f for f in folders if parent_path in f.get("fullPath", "")]

            if len(folders) == 0:
                raise click.UsageError(f"No parent folder found for name '{parent_name}'")
            if len(folders) > 1:
                details = "\n".join([f"{f['id']}: {f['fullPath']}" for f in folders])
                raise click.UsageError(
                    f"Multiple parent folders found for name '{parent_name}'. "
                    f"Use --parent-path to disambiguate or provide --parent-id.\n{details}"
                )
            return folders[0]["id"]

        if not parent_id:
            if not parent_name:
                raise click.UsageError("You must provide either --parent-id or --parent-name.")
            parent_id = lookup_parent_by_name()

        if verbose:
            click.echo(f"Creating folder '{name}' under parent '{parent_id}'")

        # Use keyword arguments (consistent with create_branch and create_packaged_component)
        created = client.create_folder(name=name, parent_id=parent_id)
        formatted = format_output(created, output_format)
        should_save = save or (save_filename is not None)
        if should_save:
            filename = save_filename.strip() if save_filename and save_filename.strip() else "folder_create.json"
            with open(filename, "w", encoding="utf-8") as f:
                f.write(formatted)
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(formatted)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@command.command("delete")
@click.pass_context
@click.option("--id", "folder_id", help="Folder ID to delete")
@click.option("--name", help="Folder name to delete (will be looked up)")
@click.option("--parent-name", help="Parent folder name (to narrow name lookup)")
@click.option("--parent-path", help="Partial parent path (to narrow name lookup)")
@click.option(
    "--auto-approve",
    is_flag=True,
    default=False,
    help="Skip confirmation prompt (only works if single folder matches)",
)
@click.option(
    "--verbose",
    is_flag=True,
    default=False,
    help="Print full request and response details",
)
@click.option("--save", is_flag=True, default=False, help="Save output to file (default: folder_delete_<id>.txt).")
@click.option(
    "--save-file",
    "save_filename",
    default=None,
    type=click.STRING,
    help="Save output to the specified path. Implies --save if set.",
)
@click.option("--quiet", is_flag=True, help="Suppress output to stdout.")
def delete(ctx, folder_id, name, parent_name, parent_path, auto_approve, verbose, save, save_filename, quiet):
    """
    Delete a folder by ID or name.

    Requires confirmation unless --auto-approve is used with a single match.
    """
    try:
        client = get_client(
            account_id=ctx.obj.get("account_id"),
            username=ctx.obj.get("username"),
            api_token=ctx.obj.get("api_token"),
        )

        # If folder_id is not provided, look it up by name
        if not folder_id:
            if not name:
                raise click.UsageError("You must provide either --id or --name to delete a folder.")

            # Build query filters for the folder lookup
            raw_filters = {"name": name}
            if parent_name:
                raw_filters["parentName"] = parent_name

            filters = build_query_filter(raw_filters) if raw_filters else {}

            if verbose:
                click.echo(f"Looking up folder by name '{name}'")
                if parent_name:
                    click.echo(f"Filtering by parent name: '{parent_name}'")
                if parent_path:
                    click.echo(f"Filtering by parent path: '{parent_path}'")
                click.echo(f"Query filters: {filters}")

            result = client.query_folders(filters)
            folders = result.get("result", [])

            # Apply parent-path filter if provided
            if parent_path:
                folders = [f for f in folders if parent_path in f.get("fullPath", "")]
                if verbose:
                    click.echo(f"Filtered to {len(folders)} folder(s) matching parent path '{parent_path}'")

            if len(folders) == 0:
                raise click.UsageError(
                    f"No folder found matching name '{name}'"
                    + (f" with parent name '{parent_name}'" if parent_name else "")
                    + (f" and parent path '{parent_path}'" if parent_path else "")
                )

            if len(folders) > 1:
                details = "\n".join([f"  {f['id']}: {f.get('fullPath', f['name'])}" for f in folders])
                raise click.UsageError(
                    f"Multiple folders found matching name '{name}'. "
                    f"Cannot determine which folder to delete.\n"
                    f"Matching folders:\n{details}\n"
                    f"Use --id to specify the exact folder, or use --parent-name/--parent-path to narrow the search."
                )

            folder_id = folders[0]["id"]
            folder_info = folders[0]
        else:
            # If folder_id is provided, fetch folder details for confirmation
            if verbose:
                click.echo(f"Fetching folder details for ID: {folder_id}")

            # Query for the folder by ID to get full details
            folder_info = None
            try:
                # Check if client has a get_folder method (most efficient)
                if hasattr(client, "get_folder"):
                    if verbose:
                        click.echo("Using get_folder method to fetch folder details")
                    folder_info = client.get_folder(folder_id)
                else:
                    # Fall back to querying - query all folders and filter by ID
                    # Note: This is less efficient but works if API doesn't support direct ID queries
                    if verbose:
                        click.echo("Querying folders to find matching ID...")
                    result = client.query_folders({})
                    all_folders = result.get("result", [])
                    matching_folders = [f for f in all_folders if f.get("id") == folder_id]

                    if matching_folders:
                        folder_info = matching_folders[0]
                        if verbose:
                            click.echo(f"Found folder: {folder_info.get('name', 'Unknown')}")
                    else:
                        if verbose:
                            click.echo(f"Warning: Folder with ID {folder_id} not found in query results")
            except Exception as e:
                # If query fails, we'll use minimal info below
                if verbose:
                    click.echo(f"Warning: Could not query folder details: {e}")

            # If we couldn't get folder info, use minimal info
            if not folder_info:
                if verbose:
                    click.echo("Using minimal folder info (ID only)")
                folder_info = {
                    "id": folder_id,
                    "name": name or "Unknown",
                    "fullPath": "",
                }

        # Display what will be deleted
        folder_name = folder_info.get("name", "Unknown")
        folder_path = folder_info.get("fullPath", folder_info.get("id", "Unknown"))
        click.echo("Folder to be deleted:")
        click.echo(f"  ID: {folder_id}")
        click.echo(f"  Name: {folder_name}")
        click.echo(f"  Path: {folder_path}")

        # Require confirmation unless auto-approve is used
        if not auto_approve:
            if not click.confirm("Are you sure you want to delete this folder?"):
                click.echo("Deletion cancelled.")
                return
        else:
            # Auto-approve only works if we have a single folder match
            # (This is already guaranteed if we got here, but we check for safety)
            if not folder_id:
                raise click.UsageError("--auto-approve can only be used when a single folder is identified.")

        # Perform the deletion
        if verbose:
            click.echo(f"Deleting folder '{folder_id}'...")

        client.delete_folder(folder_id)
        success_msg = f"Folder '{folder_name}' (ID: {folder_id}) deleted successfully."
        should_save = save or (save_filename is not None)
        if should_save:
            filename = (
                save_filename.strip() if save_filename and save_filename.strip() else f"folder_delete_{folder_id}.txt"
            )
            with open(filename, "w", encoding="utf-8") as f:
                f.write(success_msg + "\n")
            click.echo(f"Saved to {filename}", err=True)
        if not quiet:
            click.echo(success_msg)
    except BoomiAPIError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


# Alias for lazy developers
command.add_command(delete, name="rm")
