# PyBoomi CLI - CLI Main
#
# Copyright 2025 Robert Little
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
# Development Notes:
#     Contents of this file were produced with the help of code generation tools
#     and subsequently reviewed and edited by the author. While some code was
#     created with AI assistance, manual adjustments have been made to ensure
#     correctness, readability, functionality, and compliance with coding
#     standards. Any future modifications should preserve these manual changes.
#
# Author: Robert Little
# Created: 2025-12-12

"""CLI main module for PyBoomi CLI tool."""

__author__ = "Robert Little"
__copyright__ = "Copyright 2025, Robert Little"
__license__ = "Apache 2.0"
__version__ = "0.1.0"

import click

try:
    from importlib.metadata import version as _pkg_version
    __version__ = _pkg_version("pyboomi-cli")
except Exception:
    __version__ = "0.0.0.dev0"

from pyboomi_cli.commands.branch import command as branch_command
from pyboomi_cli.commands.component import command as component_command
from pyboomi_cli.commands.deployed import command as deployed_command
from pyboomi_cli.commands.environment import command as environment_command
from pyboomi_cli.commands.folders import command as folders_command
from pyboomi_cli.commands.merge import command as merge_command
from pyboomi_cli.commands.package import command as package_command
from pyboomi_cli.commands.processes import command as processes_command


@click.group()
@click.version_option(__version__, "--version", "-V", message="%(prog)s, version %(version)s")
def main():
    """PyBoomi CLI — manage Boomi Platform API from the terminal."""
    pass


main.add_command(folders_command)
# Plural alias for backward compatibility
main.add_command(folders_command, name="folders")
main.add_command(processes_command, name="processes")
main.add_command(processes_command, name="process")
main.add_command(component_command)
main.add_command(package_command)
main.add_command(branch_command)
main.add_command(merge_command)
main.add_command(environment_command)
main.add_command(environment_command, name="environments")
main.add_command(deployed_command)
main.add_command(deployed_command, name="deployment")


if __name__ == "__main__":
    main()
