"""Installed command helpers."""
