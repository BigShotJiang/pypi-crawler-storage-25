# MemoryOS Python SDK

Persistent memory for AI agents. Store, search, and retrieve memories with semantic understanding.

## Installation

```bash
pip install memoryos
```

## Quick Start

```python
from memoryos import MemoryOS

# Initialize client
client = MemoryOS(api_key="your-api-key")

# Store a memory
memory_id = client.store(
    "User prefers concise responses",
    metadata={"user_id": "123"}
)

# Search memories (semantic search)
results = client.search("user preferences", limit=5)
for memory in results:
    print(f"Similarity: {memory.similarity}")
    print(f"Content: {memory.content}")

# List all memories
all_memories = client.list(limit=20)

# Get a specific memory
memory = client.get(memory_id)

# Delete a memory
client.delete(memory_id)

# Get statistics
stats = client.stats()
print(f"Total memories: {stats.total_memories}")
```

## Integration with LangChain

```python
from langchain.memory import ConversationBufferMemory
from memoryos import MemoryOS

client = MemoryOS(api_key="your-api-key")

# Store conversation context
def remember_conversation(user_input, response):
    client.store(
        f"User: {user_input}\nAssistant: {response}",
        metadata={"type": "conversation"}
    )

# Retrieve relevant context
def get_context(query):
    results = client.search(query, limit=5)
    return [m.content for m in results]
```

## Integration with AutoGPT

```python
from memoryos import MemoryOS

class MemoryManager:
    def __init__(self, api_key):
        self.client = MemoryOS(api_key=api_key)
    
    def remember(self, fact, category):
        """Store a fact with category"""
        self.client.store(fact, metadata={"category": category})
    
    def recall(self, query, limit=5):
        """Retrieve relevant memories"""
        return self.client.search(query, limit=limit)
    
    def forget(self, memory_id):
        """Delete a memory"""
        self.client.delete(memory_id)

# Usage
manager = MemoryManager(api_key="your-api-key")
manager.remember("User is in New York", category="location")
memories = manager.recall("where is the user")
```

## API Reference

### MemoryOS(api_key, base_url)

Initialize the MemoryOS client.

**Parameters:**
- `api_key` (str): Your MemoryOS API key
- `base_url` (str, optional): Base URL of the MemoryOS API

### store(content, metadata=None)

Store a new memory.

**Parameters:**
- `content` (str): Memory content (max 10,000 characters)
- `metadata` (dict, optional): Custom metadata

**Returns:** Memory ID (int)

### search(query, limit=10)

Search memories using semantic search.

**Parameters:**
- `query` (str): Search query
- `limit` (int, optional): Max results (default: 10, max: 100)

**Returns:** List of Memory objects

### list(limit=20, offset=0)

List all memories with pagination.

**Parameters:**
- `limit` (int, optional): Results per page (default: 20, max: 100)
- `offset` (int, optional): Number to skip (default: 0)

**Returns:** List of Memory objects

### get(memory_id)

Get a specific memory by ID.

**Parameters:**
- `memory_id` (int): Memory ID

**Returns:** Memory object

### delete(memory_id)

Delete a memory.

**Parameters:**
- `memory_id` (int): Memory ID

**Returns:** True if successful

### stats()

Get memory statistics.

**Returns:** MemoryStats object with total_memories, oldest_memory, newest_memory

## Error Handling

```python
from memoryos import MemoryOSError

try:
    client.store("Some memory")
except MemoryOSError as e:
    print(f"Error: {e.message}")
    print(f"Status code: {e.status_code}")
```

## Getting Your API Key

1. Sign up at https://billiondna-vaiyukai.manus.space
2. Go to your dashboard
3. Create a new API key in the "API Keys" section
4. Use it in your code

## Support

For issues and questions, visit https://billiondna-vaiyukai.manus.space/docs

## License

MIT
