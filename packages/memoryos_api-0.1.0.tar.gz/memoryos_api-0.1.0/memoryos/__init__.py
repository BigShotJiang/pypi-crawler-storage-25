"""MemoryOS Python SDK - Persistent memory for AI agents"""

__version__ = "0.1.0"

from .client import MemoryOS

__all__ = ["MemoryOS"]
