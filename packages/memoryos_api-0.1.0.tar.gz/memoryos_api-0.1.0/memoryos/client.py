"""MemoryOS API Client for Python"""

import requests
import json
from typing import Optional, Dict, Any, List
from dataclasses import dataclass
from datetime import datetime


@dataclass
class Memory:
    """Represents a stored memory"""
    id: int
    content: str
    metadata: Optional[Dict[str, Any]] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


@dataclass
class MemoryStats:
    """Memory statistics for a user"""
    total_memories: int
    oldest_memory: Optional[str] = None
    newest_memory: Optional[str] = None


class MemoryOS:
    """
    MemoryOS Python SDK
    
    Simple client for storing and retrieving memories for AI agents.
    
    Example:
        >>> client = MemoryOS(api_key="your-api-key", base_url="https://api.memoryos.com")
        >>> memory_id = client.store("User prefers concise responses", {"user_id": "123"})
        >>> results = client.search("user preferences")
        >>> client.delete(memory_id)
    """
    
    def __init__(self, api_key: str, base_url: str = "https://billiondna-vaiyukai.manus.space"):
        """
        Initialize MemoryOS client
        
        Args:
            api_key: Your MemoryOS API key
            base_url: Base URL of the MemoryOS API (default: production)
        """
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }
    
    def store(
        self,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
        timeout: int = 30
    ) -> int:
        """
        Store a new memory
        
        Args:
            content: The memory content (up to 10,000 characters)
            metadata: Optional metadata dictionary
            timeout: Request timeout in seconds
            
        Returns:
            Memory ID of the stored memory
            
        Raises:
            MemoryOSError: If the request fails
        """
        payload = {
            "content": content,
            "metadata": metadata,
        }
        
        response = requests.post(
            f"{self.base_url}/api/memories/store",
            json=payload,
            headers=self.headers,
            timeout=timeout,
        )
        
        self._check_response(response)
        data = response.json()
        return data.get("id")
    
    def search(
        self,
        query: str,
        limit: int = 10,
        timeout: int = 30
    ) -> List[Memory]:
        """
        Search for memories
        
        Args:
            query: Search query (semantic search)
            limit: Maximum number of results (default: 10, max: 100)
            timeout: Request timeout in seconds
            
        Returns:
            List of matching memories
            
        Raises:
            MemoryOSError: If the request fails
        """
        params = {
            "query": query,
            "limit": min(limit, 100),
        }
        
        response = requests.get(
            f"{self.base_url}/api/memories/search",
            params=params,
            headers=self.headers,
            timeout=timeout,
        )
        
        self._check_response(response)
        data = response.json()
        
        return [
            Memory(
                id=m.get("id"),
                content=m.get("content"),
                metadata=m.get("metadata"),
                created_at=m.get("createdAt"),
                updated_at=m.get("updatedAt"),
            )
            for m in data
        ]
    
    def list(
        self,
        limit: int = 20,
        offset: int = 0,
        timeout: int = 30
    ) -> List[Memory]:
        """
        List all memories with pagination
        
        Args:
            limit: Number of memories to return (default: 20, max: 100)
            offset: Number of memories to skip (default: 0)
            timeout: Request timeout in seconds
            
        Returns:
            List of memories
            
        Raises:
            MemoryOSError: If the request fails
        """
        params = {
            "limit": min(limit, 100),
            "offset": offset,
        }
        
        response = requests.get(
            f"{self.base_url}/api/memories/list",
            params=params,
            headers=self.headers,
            timeout=timeout,
        )
        
        self._check_response(response)
        data = response.json()
        
        return [
            Memory(
                id=m.get("id"),
                content=m.get("content"),
                metadata=m.get("metadata"),
                created_at=m.get("createdAt"),
                updated_at=m.get("updatedAt"),
            )
            for m in data
        ]
    
    def get(self, memory_id: int, timeout: int = 30) -> Memory:
        """
        Get a specific memory by ID
        
        Args:
            memory_id: ID of the memory to retrieve
            timeout: Request timeout in seconds
            
        Returns:
            The memory object
            
        Raises:
            MemoryOSError: If the request fails or memory not found
        """
        response = requests.get(
            f"{self.base_url}/api/memories/{memory_id}",
            headers=self.headers,
            timeout=timeout,
        )
        
        self._check_response(response)
        data = response.json()
        
        return Memory(
            id=data.get("id"),
            content=data.get("content"),
            metadata=data.get("metadata"),
            created_at=data.get("createdAt"),
            updated_at=data.get("updatedAt"),
        )
    
    def delete(self, memory_id: int, timeout: int = 30) -> bool:
        """
        Delete a memory
        
        Args:
            memory_id: ID of the memory to delete
            timeout: Request timeout in seconds
            
        Returns:
            True if deletion was successful
            
        Raises:
            MemoryOSError: If the request fails
        """
        response = requests.delete(
            f"{self.base_url}/api/memories/{memory_id}",
            headers=self.headers,
            timeout=timeout,
        )
        
        self._check_response(response)
        return True
    
    def stats(self, timeout: int = 30) -> MemoryStats:
        """
        Get memory statistics
        
        Args:
            timeout: Request timeout in seconds
            
        Returns:
            Memory statistics
            
        Raises:
            MemoryOSError: If the request fails
        """
        response = requests.get(
            f"{self.base_url}/api/memories/stats",
            headers=self.headers,
            timeout=timeout,
        )
        
        self._check_response(response)
        data = response.json()
        
        return MemoryStats(
            total_memories=data.get("totalMemories", 0),
            oldest_memory=data.get("oldestMemory"),
            newest_memory=data.get("newestMemory"),
        )
    
    def _check_response(self, response: requests.Response) -> None:
        """Check response status and raise error if needed"""
        if response.status_code >= 400:
            try:
                error_data = response.json()
                message = error_data.get("message", response.text)
            except:
                message = response.text
            
            raise MemoryOSError(
                f"API Error ({response.status_code}): {message}",
                status_code=response.status_code,
            )


class MemoryOSError(Exception):
    """MemoryOS API error"""
    
    def __init__(self, message: str, status_code: int = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)
