from importlib.metadata import PackageNotFoundError as _PackageNotFoundError
from importlib.metadata import version as _meta_version

from . import (
    lattice,  # noqa: F401 — V2-6: expose alkahest.lattice submodule
    modular,  # noqa: F401 — V2-1: expose alkahest.modular submodule
    number_theory,  # noqa: F401 — V3-1: integer number theory
)
from ._context import (  # noqa: F401
    active_domain,
    active_pool,
    context,
    get_context_value,
    simplify_enabled,
    symbol,
)
from ._dlpack import _to_numpy  # noqa: F401
from ._parse import parse  # noqa: F401
from ._pretty import latex, unicode_str  # noqa: F401
from ._product import Product  # noqa: F401 — V2-22
from ._pytree import (  # noqa: F401
    TreeDef,
    flatten_exprs,
    map_exprs,
    unflatten_exprs,
)
from ._transform import (  # noqa: F401
    CompiledTracedFn,
    GradTracedFn,
    TracedFn,
    grad,
    jit,
    trace,
    trace_fn,
)
from .alkahest import (  # noqa: F401
    # Phase 17: DAE
    DAE,
    HAS_EGRAPH,
    # Phase 16: ODE
    ODE,
    # Phase 18: Acausal modelling
    AcausalSystem,
    # V3-3: First-order logic + V2-9 CAD/QE
    And,
    # Phase 22: Ball arithmetic
    ArbBall,
    # Phase 21: JIT compiled evaluation
    CompiledFn,
    # Core expression types
    DerivedResult,
    # V1-15: EgraphConfig and simplify_egraph_with
    EgraphConfig,
    # Phase 20: Hybrid systems
    Event,
    Exists,
    Expr,
    ExprPool,
    Forall,
    HybridODE,
    # Phase 15: Symbolic matrices
    Matrix,
    # Polynomial types
    MultiPoly,
    MultiPolyFactorization,
    # V2-1: Modular / CRT framework
    MultiPolyFp,
    Not,
    Or,
    Port,
    # PA-5: Primitive registry
    PrimitiveRegistry,
    RationalFunction,
    # Rewrite rules
    RewriteRule,
    # V2-4: Real root isolation (VAS)
    RootInterval,
    # Phase 19: Sensitivity analysis
    SensitivitySystem,
    Series,
    UniPoly,
    UniPolyFactorization,
    # V2-7: Polynomial factorization
    UniPolyFactorModP,
    abs,  # symbolic abs — use alkahest.abs(expr); shadows Python builtin within this module
    acos,
    adjoint_system,
    asin,
    atan,
    atan2,
    cad_lift,
    cad_project,
    ceil,
    # Phase 26: collect_like_terms
    collect_like_terms,
    compile_expr,
    # Math functions
    cos,
    cosh,
    decide,
    # Core operations
    diff,
    diff_forward,
    emit_c,
    erf,
    erfc,
    eval_expr,
    exp,
    factor_univariate_mod_p,
    floor,
    gamma,
    # V2-6: Approximate integer relations (LLL-backed heuristic — not Ferguson–Bailey PSLQ)
    guess_relation,
    # Phase 24: Horner-form code emission
    horner,
    integrate,
    interval_eval,
    jacobian,
    jit_is_available,
    limit,
    log,
    lower_to_first_order,
    make_rule,
    match_pattern,
    max,  # symbolic max(a, b) — shadows Python builtin within this module
    min,  # symbolic min(a, b) — shadows Python builtin within this module
    pantelides,
    # PA-9: Piecewise
    piecewise,
    # Phase 27: poly_normal
    poly_normal,
    product_definite,
    product_indefinite,
    real_roots,
    refine_root,
    resistor,
    # V2-2: Resultants and subresultant PRS
    resultant,
    round,  # symbolic round — use alkahest.round(expr)
    rsolve,
    satisfiable,
    sensitivity_system,
    series,
    sign,
    simplify,
    simplify_clifford_orthogonal,
    simplify_egraph,
    simplify_egraph_with,
    simplify_expanded,
    simplify_log_exp,
    simplify_par,
    simplify_pauli,
    simplify_trig,
    simplify_with,
    sin,
    sinh,
    solve_linear_recurrence_homogeneous,
    # V2-3: Sparse interpolation
    sparse_interp,
    sparse_interp_univariate,
    sqrt,
    subresultant_prs,
    subs,
    sum_definite,
    sum_indefinite,
    # V1-12: expanded primitive registry
    tan,
    tanh,
    # V5-1: Lean 4 certificate exporter
    to_lean,
    # V5-2: StableHLO/XLA bridge
    to_stablehlo,
    verify_wz_pair,
    version,
)
from .alkahest import (  # noqa: F401
    # Phase 14: Reverse-mode AD (symbolic gradient; for traced-fn gradient use alkahest.grad)
    grad as symbolic_grad,
)

# V5-7: JAX primitive integration (optional — requires JAX)
try:
    from ._jax import to_jax  # noqa: F401
except ImportError:
    pass

# V1-4 / V1-16: Polynomial system solver + Gröbner basis (optional — requires groebner feature)
try:
    from .alkahest import (
        CertifiedSolution,
        DaeIndexReduction,
        DiophantineSolution,
        GbPoly,
        GroebnerBasis,
        RegularChain,
        RosenfeldGroebnerResult,
        dae_index_reduce,
        diophantine,
        rosenfeld_groebner,
        solve,
        solve_numerical,
        triangularize,
    )  # noqa: F401
except ImportError:
    pass

# V1-3 — Structured exception hierarchy: bind pure-Python stubs first, then replace
# each name with the compiled class when ``alkahest.alkahest`` exports it.  A bulk
# ``from .alkahest import (..., DiophantineError, ...)`` fails entirely when optional
# features omit a symbol (``DiophantineError`` is registered only with the groebner
# feature); that used to downgrade *every* error class to stubs and drop names that
# have no stub (CadError, …).
from .exceptions import (  # noqa: F401, I001
    AlkahestError,
    CadError,
    ConversionError,
    DaeError,
    DiffError,
    DiophantineError,
    DomainError,
    EigenError,
    FactorError,
    IntegrationError,
    IoError,
    JitError,
    LatticeError,
    LimitError,
    LinearRecurrenceError,
    MatrixError,
    NumberTheoryError,
    OdeError,
    ParseError,
    PoolError,
    ProductError,
    PslqError,
    RealRootError,
    ResultantError,
    RsolveError,
    SeriesError,
    SolverError,
    SparseInterpError,
    SumError,
)

_NATIVE_EXCEPTION_OVERLAY: tuple[str, ...] = (
    "AlkahestError",
    "CadError",
    "ConversionError",
    "DaeError",
    "DiffError",
    "DiophantineError",
    "DomainError",
    "EigenError",
    "FactorError",
    "IntegrationError",
    "IoError",
    "JitError",
    "LatticeError",
    "LimitError",
    "LinearRecurrenceError",
    "MatrixError",
    "NumberTheoryError",
    "OdeError",
    "PoolError",
    "ProductError",
    "PslqError",
    "RealRootError",
    "ResultantError",
    "RsolveError",
    "SeriesError",
    "SolverError",
    "SparseInterpError",
)

try:
    from . import alkahest as _alkahest_native
except ImportError:
    pass
else:
    _globals = globals()
    for _overlay_name in _NATIVE_EXCEPTION_OVERLAY:
        _native_cls = getattr(_alkahest_native, _overlay_name, None)
        if _native_cls is not None:
            _globals[_overlay_name] = _native_cls

try:
    __version__ = _meta_version("alkahest")
except _PackageNotFoundError:
    __version__ = "unknown"


def numpy_eval(compiled_fn, *arrays):
    """Vectorised evaluation of a :class:`CompiledFn` over arrays.

    Phase 25 / PA-8 — NumPy / JAX / PyTorch / DLPack array evaluation.

    Parameters
    ----------
    compiled_fn : CompiledFn
        A compiled function returned by :func:`compile_expr`.
    *arrays : array-like
        One array per input variable.  All arrays must have the same number
        of elements.  Accepts NumPy arrays, PyTorch CPU tensors, JAX arrays,
        CuPy arrays (host copy made), or anything with ``__dlpack__`` or
        ``__array__``.

    Returns
    -------
    numpy.ndarray
        Output values with the same shape as the first input array.

    Example
    -------
    >>> import numpy as np
    >>> import alkahest
    >>> p = alkahest.ExprPool()
    >>> x = p.symbol("x")
    >>> f = alkahest.compile_expr(x ** 2, [x])
    >>> xs = np.linspace(0, 1, 1_000_000)
    >>> ys = alkahest.numpy_eval(f, xs)   # vectorised; ≥100× faster than a loop
    """
    try:
        import numpy as np
    except ImportError as exc:
        raise ImportError("numpy_eval requires NumPy.  Install it with: pip install numpy") from exc

    n_vars = compiled_fn.n_inputs
    if len(arrays) != n_vars:
        raise ValueError(f"expected {n_vars} input array(s), got {len(arrays)}")

    # Use DLPack-aware conversion for each input.
    first_raw = np.asarray(arrays[0])
    out_shape = first_raw.shape if first_raw.ndim > 0 else ()

    flat_arrays = [_to_numpy(a).ravel() for a in arrays]
    n_points = flat_arrays[0].size
    if any(a.size != n_points for a in flat_arrays):
        raise ValueError("all input arrays must have the same number of elements")

    inputs_flat = [v for arr in flat_arrays for v in arr.tolist()]
    result_flat = compiled_fn.call_batch_raw(inputs_flat, n_vars, n_points)
    result = np.array(result_flat, dtype=np.float64)
    if out_shape:
        result = result.reshape(out_shape)
    return result


__all__ = [
    "__version__",
    # Exceptions (V1-3 — stable diagnostic codes)
    "AlkahestError",
    "AlkahestError",
    "ConversionError",
    "FactorError",
    "DomainError",
    "DiffError",
    "PoolError",
    "IntegrationError",
    "LimitError",
    "SeriesError",
    "LinearRecurrenceError",
    "RsolveError",
    "DiophantineError",
    "MatrixError",
    "NumberTheoryError",
    "EigenError",
    "OdeError",
    "DaeError",
    "JitError",
    "SolverError",
    "version",
    # Core
    "ExprPool",
    "Expr",
    "DerivedResult",
    # Polynomials
    "UniPoly",
    "MultiPoly",
    "UniPolyFactorization",
    "UniPolyFactorModP",
    "MultiPolyFactorization",
    "factor_univariate_mod_p",
    "RationalFunction",
    # Rules
    "RewriteRule",
    # Simplification
    "simplify",
    "simplify_egraph",
    "simplify_egraph_with",
    "EgraphConfig",
    "HAS_EGRAPH",
    "simplify_expanded",
    "simplify_trig",
    "simplify_log_exp",
    "simplify_pauli",
    "simplify_clifford_orthogonal",
    "simplify_with",
    # Calculus
    "diff",
    "diff_forward",
    "integrate",
    "limit",
    "series",
    "Series",
    "solve_linear_recurrence_homogeneous",
    "rsolve",
    "sum_definite",
    "sum_indefinite",
    "product_definite",
    "product_indefinite",
    "Product",
    "verify_wz_pair",
    "symbolic_grad",
    # Pattern matching & substitution
    "match_pattern",
    "make_rule",
    "subs",
    # Math functions (core 5)
    "sin",
    "cos",
    "exp",
    "log",
    "sqrt",
    # V1-12: expanded primitives
    "tan",
    "sinh",
    "cosh",
    "tanh",
    "asin",
    "acos",
    "atan",
    "erf",
    "erfc",
    "abs",
    "sign",
    "floor",
    "ceil",
    "round",
    # Phase 15
    "Matrix",
    "jacobian",
    # Phase 16
    "ODE",
    "lower_to_first_order",
    # Phase 17
    "DAE",
    "pantelides",
    # Phase 18
    "AcausalSystem",
    "Port",
    "resistor",
    # Phase 19
    "SensitivitySystem",
    "sensitivity_system",
    "adjoint_system",
    # Phase 20
    "Event",
    "HybridODE",
    # Phase 21
    "CompiledFn",
    "compile_expr",
    "eval_expr",
    "jit_is_available",
    # Phase 22
    "ArbBall",
    "interval_eval",
    # Phase 23
    "simplify_par",
    # Phase 24
    "horner",
    "emit_c",
    # Phase 25
    "numpy_eval",
    # Phase 26
    "collect_like_terms",
    # Phase 27
    "poly_normal",
    # V2-2
    "resultant",
    "subresultant_prs",
    "ResultantError",
    # V2-3
    "sparse_interp",
    "sparse_interp_univariate",
    "SparseInterpError",
    "SumError",
    "ProductError",
    "CadError",
    # V2-6
    "guess_relation",
    "lattice",
    "number_theory",
    "LatticeError",
    "PslqError",
    # V2-4
    "real_roots",
    "refine_root",
    "RootInterval",
    "RealRootError",
    # PA-5
    "PrimitiveRegistry",
    # PA-7
    "TracedFn",
    "CompiledTracedFn",
    "GradTracedFn",
    "trace",
    "grad",
    "jit",
    "trace_fn",
    # PA-10
    "TreeDef",
    "flatten_exprs",
    "unflatten_exprs",
    "map_exprs",
    # PA-9
    "piecewise",
    # V3-3 — FOFormula / V2-9 CAD
    "decide",
    "cad_project",
    "cad_lift",
    "satisfiable",
    "And",
    "Or",
    "Not",
    "Forall",
    "Exists",
    # V5-1
    "to_lean",
    # V5-2
    "to_stablehlo",
    # V1-4 / V1-16: Polynomial system solver + Gröbner basis (requires groebner feature)
    "solve",
    "solve_numerical",
    "diophantine",
    "DiophantineSolution",
    "CertifiedSolution",
    "GroebnerBasis",
    "GbPoly",
    # V2-11 — Regular chains / triangular decomposition
    "triangularize",
    "RegularChain",
    # V2-13 — Differential algebra / Rosenfeld–Gröbner (requires groebner)
    "rosenfeld_groebner",
    "dae_index_reduce",
    "RosenfeldGroebnerResult",
    "DaeIndexReduction",
    # V1-16: IoError
    "IoError",
    # RW-7
    "context",
    "symbol",
    "active_pool",
    "active_domain",
    "simplify_enabled",
    "get_context_value",
    # V2-20
    "latex",
    "unicode_str",
    # V2-21
    "parse",
    "ParseError",
]
