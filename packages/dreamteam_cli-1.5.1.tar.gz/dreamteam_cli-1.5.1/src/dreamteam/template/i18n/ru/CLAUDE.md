{%- set pm_run = {'uv': 'uv run ', 'poetry': 'poetry run ', 'pdm': 'pdm run ', 'hatch': 'hatch run ', 'pip': '.venv/bin/'}[package_manager] -%}
{%- set pm_install = {'uv': 'uv sync', 'poetry': 'poetry install', 'pdm': 'pdm install', 'hatch': 'hatch env create', 'pip': 'python -m venv .venv && .venv/bin/pip install -e .[dev]'}[package_manager] -%}
{%- set pm_name = package_manager -%}
# Project rules for Claude

Этот файл — проектные правила для Claude (Claude Code). Глобальные
правила (`~/.claude/CLAUDE.md`) применяются всегда; здесь — только то,
что специфично для конкретного проекта.

## Что прочитать в начале сессии

1. `CONCEPT.md` (если есть) — изначальное видение проекта,
   immutable документ. Полезен как точка опоры через месяцы.
2. `README.md` — текущее описание / quick start / status проекта.
3. `DECISIONS.md` — архитектурные решения, которые уже приняты.
4. `BACKLOG.md` — что лежит в очереди.
5. При работе над крупной фичей — соответствующий `specs/T<NNN>-*/spec.md`.

## Ритуал составления `CONCEPT.md` (для нового проекта)

В начале нового проекта Claude помогает Разработчику составить
`CONCEPT.md` — immutable документ начального видения. Это ритуал
встречных вопросов, аналогичный `clarify` для спеки:

1. Разработчик пишет первый набросок (или формулирует идею).
2. Claude задаёт встречные вопросы по слепым зонам:
   - **Цель:** какую боль / задачу проект решает?
   - **Пользователь:** кто, в каком контексте?
   - **Ключевая функциональность:** MVP-минимум vs nice-to-have?
   - **Out of scope:** что СОЗНАТЕЛЬНО не делаем? (главный раздел
     для защиты от scope creep).
   - **Ограничения и догадки:** платформа, стек, нагрузка,
     ассумпции.
3. Ответы вшиваются в `CONCEPT.md`, проставляется дата создания.
4. **После фиксации `CONCEPT.md` не редактируется.** Текущее
   состояние ведётся в `README.md`. Если концепция кардинально
   меняется (rare, pivot) — добавляется `concepts/v2-...md`,
   `v3-...md` (ADR-pattern, но для концепций).

Заполнение `CONCEPT.md` — на этапе создания проекта через
`dreamteam init` (Claude задаёт встречные вопросы) или позже,
вручную.

## Описание проекта

{{ project_description }}

## Стек

<!-- Языки, фреймворки, ключевые библиотеки, целевая платформа. -->

**Базовый стек шаблона (для Python-проектов):**
- Python 3.14+ (`requires-python` в `pyproject.toml`).
- Менеджер зависимостей и окружений: **`{{ pm_name }}`** (выбран
  при `dreamteam init` через prompt `package_manager`; альтернативы:
  `uv` / `poetry` / `pdm` / `hatch` / `pip`).
- Линтер: `ruff` (правило `select = ["ALL"]` с фиксированным `ignore`).
- Тип-чекер: `mypy` с `mypy_path = "src"`.
- Тестовый стек: `pytest` + `pytest-cov` + `pytest-asyncio`. Coverage
  threshold ≥ 80% line coverage на `src/` (`--cov-fail-under=80`
  в `[tool.pytest.ini_options]`).
- **Корень исходников — `src/`** (всегда, во всех проектах).
- Тесты — в `tests/` в корне (в ruff `exclude`, но pytest их
  находит через `testpaths = ["tests"]`).

**Типичные команды (для выбранного `{{ pm_name }}`):**
{%- if package_manager == 'uv' %}
- `uv sync` — поставить зависимости (создаст `.venv` при первом запуске).
- `uv add <pkg>` / `uv add --dev <pkg>` — добавить runtime / dev зависимость.
- `uv run python ...` — запустить под `.venv` без активации.
- `uvx <tool>` — запустить CLI-инструмент без локальной установки.
{%- elif package_manager == 'poetry' %}
- `poetry install` — поставить зависимости (создаст venv при первом запуске).
- `poetry add <pkg>` / `poetry add --group dev <pkg>` — добавить runtime / dev зависимость.
- `poetry run python ...` — запустить под poetry venv без активации.
- `poetry env activate` — открыть подоболочку с активным venv.
{%- elif package_manager == 'pdm' %}
- `pdm install` — поставить зависимости (создаст `.venv` при первом запуске).
- `pdm add <pkg>` / `pdm add -dG dev <pkg>` — добавить runtime / dev зависимость.
- `pdm run python ...` — запустить под `.venv` без активации.
{%- elif package_manager == 'hatch' %}
- `hatch env create` — создать `default` environment с dev-deps.
- Зависимости редактируются в `[tool.hatch.envs.default.dependencies]` в `pyproject.toml`.
- `hatch run <cmd>` — запустить команду внутри `default` env без активации.
- Скрипты определяются в `[tool.hatch.envs.default.scripts]`, вызываются как `hatch run <script>`.
{%- else %}
- `python -m venv .venv && .venv/bin/pip install -e .[dev]` — создать venv и поставить dev-зависимости.
- `.venv/bin/pip install <pkg>` — добавить пакет (запиши его в `pyproject.toml` сам; pip не умеет автоматически).
- `.venv/bin/python ...` или активируй venv (`source .venv/bin/activate`) и запускай `python ...`.
{%- endif %}

Перед каждым `git push` обязательно **четыре** проверки с 0 ошибок:
1. `{{ pm_run }}ruff check .`
2. `{{ pm_run }}ruff format --check .`
3. `{{ pm_run }}mypy <код>`
4. `{{ pm_run }}pytest` (включает coverage threshold ≥ 80%).

**Запускать одной цепочкой**, чтобы fail на любом шаге прерывал
commit:

```bash
{{ pm_run }}ruff check . && \
{{ pm_run }}ruff format --check . && \
{{ pm_run }}mypy <код> && \
{{ pm_run }}pytest && \
git add -A && git commit -m "..." && git push
```

**Catch-it-at-the-output:** если в выводе предыдущей команды
видишь `FAILED`, `Error`, `1 failed` или подобные маркеры —
**не двигайся дальше**, проверь причину. И не глуши exit-code:
`pytest | tail -5` возвращает exit-код `tail`, не `pytest` —
fail незаметно проскочит в `git commit`.

Никаких `# noqa` / `# type: ignore` / расширений `ignore`-секций
без явного обсуждения с Разработчиком. Подробно — в глобальном
`~/.claude/CLAUDE.md`, разделы «Линтеры» и «Тестирование».

## Git workflow

Базовые правила процесса (применяются в этом проекте всегда):

- **Задачи нумеруются.** Каждая запись в `BOARD.md` / `BACKLOG.md`
  имеет ID `T<NNN>`; ветка — `T<NNN>-<slug>`; PR — `T<NNN>: <title>`.
  Исключение — методические PR, меняющие сами правила (без `T`-ID).
- **Прямой push в `main` / `master` запрещён.** Любое изменение — через
  feature-ветку и PR/MR.
- **Один PR — один коммит.** На feature-ветке можно коммитить как
  удобно для работы, перед merge — squash.
- **Каждый PR проходит code review** перед merge. По умолчанию —
  Claude (self-review с чеклистом: scope / архитектура / код /
  линтеры / документация / соглашения / безопасность). Иногда —
  Разработчик.
- **Сторонние ревью не игнорировать.** Боты типа qodo-code-review —
  читать, анализировать, обсуждать с Разработчиком; фиксировать
  решение (учесть / отбросить / отложить).

## Дисциплина планирования

Без Scrum-церемоний (sprints, story points, velocity, burndown).
Поддерживаем только полезные элементы:

- **Milestone-based versioning.** `[Unreleased]` в `CHANGELOG.md`
  накапливает изменения. Переход к новой версии `[N.M.0]` —
  когда **осмысленно завершено** (soft criterion): введены значимые
  изменения, ИЛИ завершён логически связанный цикл задач, ИЛИ
  накопилось «достаточно» для отдельной точки сохранения.
  Окончательно решает Разработчик; формальной метрики нет — она
  противоречит самому принципу «без Scrum-карго». Формат версий —
  Keep a Changelog (`## [N.M.0]`, без `v`-префикса).
- **Retrospective как ритуал** после закрытия milestone. Короткий
  разбор в формате трёх пунктов:
  - что зашло (work-as-expected, или приятный сюрприз),
  - что не зашло (boundle, slip-ы, лишний overhead),
  - правки методики (что менять в `~/.claude/CLAUDE.md` /
    проектном `CLAUDE.md` / шаблоне).
  Размещение: **секция `### Retrospective`** внутри записи
  соответствующей версии в `CHANGELOG.md`. Не отдельный файл —
  ретро тесно связан с milestone, удобно читать рядом.
- **Acceptance criteria** обязательны для задач крупнее однострочной
  правки — записываются прямо в `BOARD.md` / `BACKLOG.md` коротким
  блоком (`Acceptance: <что должно быть достигнуто, чтобы задача
  считалась закрытой>`) или в `specs/T<NNN>-*/spec.md` для крупных
  фич. Без явных acceptance criteria задача не считается зрелой
  для перехода `BACKLOG → BOARD → Doing`.
- **WIP-limit** в `BOARD.md → Doing`: максимум 1-2 задачи. Больше —
  теряется фокус (классическое kanban-правило).

Если у Разработчика настроен глобальный `~/.claude/CLAUDE.md` —
там лежит расширенная версия этих правил (разделы «Никогда не пушить
напрямую в main», «Один PR — один коммит», «Code review каждого PR»).
Краткой версии выше достаточно как самодостаточного источника.

## Проект-специфичные правила

<!-- Например:
- Все скрипты должны работать на Raspberry Pi Zero W (ARMv6).
- Никаких внешних зависимостей кроме stdlib.
- БД — SQLite, единый файл, без миграций.
- Стиль коммитов: Conventional Commits.
-->

## Что в этом проекте обычно идёт в BACKLOG.md, а не в текущую правку

<!-- Опционально: примеры типичных побочных находок для этого проекта,
     которые ты заметишь и захочешь починить «заодно», но не надо. -->

