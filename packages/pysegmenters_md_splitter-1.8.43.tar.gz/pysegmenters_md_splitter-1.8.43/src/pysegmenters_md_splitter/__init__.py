"""Markdown splitter"""

__version__ = "1.8.43"
