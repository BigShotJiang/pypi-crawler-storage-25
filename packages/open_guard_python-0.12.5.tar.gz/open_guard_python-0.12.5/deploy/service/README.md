# open-guard service mode — reference container

This directory contains a **reference** Dockerfile and entrypoint. It
demonstrates one viable wire-up; production deployments should
customize for their platform (secret manager integration, key
rotation, additional auth backends, observability stack).

No image is published. Build locally, copy to your registry, run.

## Build

```bash
docker build -f deploy/service/Dockerfile -t open-guard:dev .
```

## Environment

| Variable | Required | Description |
|----------|----------|-------------|
| `OPEN_GUARD_DSN` | recommended | Async SQL DSN (`sqlite+aiosqlite://`, `postgresql+asyncpg://`). Omit for in-memory. |
| `OPEN_GUARD_BOOTSTRAP_KEY_HASH` | yes | SHA-256 hex digest of the bootstrap API key. |
| `OPEN_GUARD_BOOTSTRAP_TENANT` | yes | Tenant id the bootstrap key belongs to. |
| `OPEN_GUARD_PREFIX` | no | Mount prefix (default `/v1`). |

## Generate a bootstrap key

```python
from open_guard.service.auth import ApiKeyAuth
cleartext, digest = ApiKeyAuth.generate()
print("API key:", cleartext)   # show once, hand to operator
print("Hash:", digest)         # set as OPEN_GUARD_BOOTSTRAP_KEY_HASH
```

## Run

```bash
docker run --rm -p 8000:8000 \
  -e OPEN_GUARD_DSN="postgresql+asyncpg://user:pass@db/openguard" \
  -e OPEN_GUARD_BOOTSTRAP_KEY_HASH="$HASH" \
  -e OPEN_GUARD_BOOTSTRAP_TENANT="t1" \
  open-guard:dev
```

## docker-compose example

```yaml
services:
  openguard:
    build:
      context: ../..
      dockerfile: deploy/service/Dockerfile
    ports:
      - "8000:8000"
    environment:
      OPEN_GUARD_DSN: postgresql+asyncpg://og:og@db:5432/openguard
      OPEN_GUARD_BOOTSTRAP_KEY_HASH: ${OG_HASH}
      OPEN_GUARD_BOOTSTRAP_TENANT: t1
    depends_on: [db]
  db:
    image: postgres:16
    environment:
      POSTGRES_USER: og
      POSTGRES_PASSWORD: og
      POSTGRES_DB: openguard
```

## Customizing

- Replace `InMemoryApiKeyStore` with a SQL-backed store before
  multi-replica deployment.
- Swap `ApiKeyAuth` for `ShieldAuth` (open-shield JWT) or
  `CallableAuth` (mTLS / proxy headers / custom).
- Mount the OpenAPI spec at a non-default path via `ServiceConfig`.
- Add request id / tracing middleware in your customized entrypoint.
