"""Reference entrypoint for the open-guard service container.

Wire-up:
- Read DSN, API key, and prefix from env vars.
- Build an AsyncGuard from the DSN.
- Configure ApiKeyAuth with a single bootstrap key.
- Hand both to ``create_app``.

Customize this file for your platform — secret manager integration,
multi-key bootstrapping, ShieldAuth wiring, alternative auth backends.
"""

from __future__ import annotations

import asyncio
import os

from open_guard import build_async_guard
from open_guard.service.app import ServiceConfig, create_app
from open_guard.service.auth import (
    ApiKeyAuth,
    ApiKeyRecord,
    InMemoryApiKeyStore,
)


def _build_app():
    dsn = os.environ.get("OPEN_GUARD_DSN")  # e.g. postgresql+asyncpg://...
    bootstrap_key_hash = os.environ["OPEN_GUARD_BOOTSTRAP_KEY_HASH"]
    bootstrap_tenant = os.environ["OPEN_GUARD_BOOTSTRAP_TENANT"]
    prefix = os.environ.get("OPEN_GUARD_PREFIX", "/v1")

    guard = asyncio.run(build_async_guard(dsn=dsn))
    store = InMemoryApiKeyStore()
    asyncio.run(
        store.add(
            ApiKeyRecord(
                key_hash=bootstrap_key_hash,
                tenant_id=bootstrap_tenant,
                service_identity="bootstrap",
                scopes=["cross_tenant_admin"],
            )
        )
    )
    return create_app(
        guard=guard,
        auth=ApiKeyAuth(store),
        config=ServiceConfig(prefix=prefix),
    )


app = _build_app()
