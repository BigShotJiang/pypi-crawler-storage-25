---
id: FEAT-001
title: Delegation chains — push/pull permission handoff
type: feature
priority: P1
status: open
created: 2026-04-17
target-phase: 3 (candidate)
related:
  - FEAT-002 (usage-counted permissions — often co-delegated)
  - FEAT-003 (leases — delegation can expire)
  - FEAT-005 (OBO identity chains — identity flow, distinct from permission flow)
  - FEAT-007 (pending approval — "pull" delegation often requires approval)
---

# FEAT-001: Delegation chains — push/pull permission handoff

## Problem

A parent task or actor (a human user, or a parent agent) frequently needs to hand a **subset** of its permissions to a child (subagent, downstream task, delegate service). Today open-guard has no first-class primitive for this. Consumers must either:

- Grant the child the full permission set (violates least-privilege), or
- Manually construct a new policy per delegation (stateful, hard to revoke, no chain semantics).

With AI agents invoking subagents and tool calls, this happens constantly — every subagent call is a delegation.

## Motivation

- Thomas & Sandhu 1997 TBAC paper defines **push** and **pull** delegation as foundational — not optional extensions.
- In 2026, every agentic framework has some delegation mechanism (Auth0 Token Vault, OAuth token exchange, Anthropic subagent dispatch). None are standardized at the authz-library level.
- TBAC without delegation is a single-level window; with delegation it becomes a tree — matching how real agent execution graphs work.

## Proposed Solution (sketch, not final)

Two complementary operations on the `Task` entity (or a new `Delegation` entity):

### Push delegation

Parent explicitly grants a permission subset to a child task.

```python
# Illustrative
guard.delegate_push(
    from_task_id="parent-task-123",
    to_task_id="child-task-456",
    permissions=["read:document:invoice-*"],   # subset of parent's perms
    max_uses=5,                                  # optional, ties to FEAT-002
    expires_at=datetime(...)                     # optional, ties to FEAT-003
)
```

### Pull delegation

Child requests a permission; parent (human, agent, or policy) approves.

```python
# Illustrative
request_id = guard.delegate_pull_request(
    task_id="child-task-456",
    permission="write:document:invoice-789",
    requested_by="agent-subprocessor-v1",
    reason="User asked to update this invoice"
)
# → approval flow — ties to FEAT-007 pending_approval
guard.delegate_pull_approve(request_id, approver="user-42")
```

### Core invariants

- **Narrowing only**: child can never hold a permission the parent didn't have. Enforced at delegation time AND re-checked at `authorize()` (parent revocation cascades).
- **Chain depth limit**: configurable max depth (default 10) to prevent runaway subagent trees.
- **Cascading revocation**: revoking a parent task invalidates all descendants' delegated permissions.

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Parent-child Task relations only (what Phase 1 has) | Already built; simple hierarchy | No push/pull semantics; no approval flow; no fine-grained scope narrowing |
| Model every delegation as a new policy | Uses existing machinery | Explodes policy store; no chain semantics; hard to cascade-revoke |
| Use ReBAC tuples (`delegated_to` relation) | Queryable via ReBAC | Conflates identity with permission; doesn't handle scope narrowing natively |
| **Proposed: first-class `Delegation` entity + push/pull ops** | Clear semantics; maps to Thomas-Sandhu; composable with FEAT-002/003/007 | New entity + port; more surface area |

## Open Questions

1. **Entity vs. field**: is delegation a new `Delegation` entity, or a field on `Task`? Delegations between agents that aren't tasks (pure actor-to-actor) suggests a new entity.
2. **Authorization of delegation itself**: who can call `delegate_push`? A meta-policy? Hardcoded "only the holder of the permission"?
3. **Partial revocation**: if parent's permission scope shrinks (not full revoke), do we cascade the shrink or only full revocation?
4. **Pull approval channel**: how does approval reach the human/agent — in-band via FEAT-007, or via ENH-009 obligations?
5. **Interaction with FEAT-005 OBO chain**: is delegation a permission-flow concept and OBO an identity-flow concept, or should they unify?

## Scope Boundaries

- **In scope**: push/pull ops, scope narrowing enforcement, cascade revocation, chain depth limit.
- **Out of scope (this item)**: async approval mechanics (FEAT-007), usage counts (FEAT-002), time-based expiry (FEAT-003) — composed, not owned.
- **Related / adjacent**: FEAT-005 (identity chains) is structurally parallel — same chain shape, different payload.

## References

- Thomas & Sandhu 1997 — *Task-based Authorization Controls (TBAC)* — foundational push/pull model
- RFC 8693 — OAuth 2.0 Token Exchange — industry pattern for scope-narrowing delegation
- IETF draft-ietf-oauth-identity-chaining — cross-domain delegation chains
- Auth0 for AI Agents — Token Vault async authorization
- `specs/architecture/auth-model.md` — TBAC section (current parent-child task model)

## Graduation Criteria

- [ ] Open questions 1, 2, 5 resolved (entity shape, authorization, relationship to FEAT-005)
- [ ] ADR: "Delegation as entity vs. Task field"
- [ ] ADR: "Push vs. pull approval flow semantics"
- [ ] `auth-model.md` delegation section drafted
