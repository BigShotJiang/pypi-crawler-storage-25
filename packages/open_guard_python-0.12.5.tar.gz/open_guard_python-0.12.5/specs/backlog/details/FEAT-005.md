---
id: FEAT-005
title: On-behalf-of identity chains
type: feature
priority: P1
status: open
created: 2026-04-17
target-phase: 3 (candidate)
related:
  - FEAT-001 (delegation chains — permission flow, distinct from identity flow)
  - FEAT-008 (DecisionTrace — chain must appear in traces)
  - FEAT-009 (MCP adapter — chain flows through tool calls)
---

# FEAT-005: On-behalf-of identity chains

## Problem

When an AI agent acts on behalf of a user, and that agent spawns a subagent, and the subagent invokes a tool — there are **three distinct identities** in play, each with different trust levels and audit requirements. Today the `Actor` entity models a single identity. A decision like "did this user approve this action?" cannot be answered because the chain is lost by the time `authorize()` runs.

Without identity chains:

- Audit trails lose provenance (who really initiated this?)
- Policies cannot reason over the chain (e.g., "deny if any untrusted agent is in the chain")
- Revoking the root user cannot cascade to all agent actions downstream
- Compliance claims ("a human approved this data export") cannot be verified

## Motivation

- **IETF draft-ietf-oauth-identity-chaining** codifies cross-domain chaining as the standard pattern.
- **RFC 8693 OAuth Token Exchange** uses `actor_token` alongside `subject_token` precisely for this — the `act` claim in JWTs represents the chain.
- Every major agentic-auth vendor (Auth0, Okta, Cerbos, Strata) ships identity-chain primitives in 2026.
- Without this, open-guard's "flexible actor model" is aesthetic — agents are just a different string label, not a first-class actor with a traceable origin.

## Proposed Solution (sketch, not final)

Extend `Actor` to carry a chain of delegators:

```python
# Illustrative
@dataclass(frozen=True)
class Actor:
    id: str
    type: ActorType  # user | agent | service | device | conversation
    attributes: dict
    acting_on_behalf_of: Optional["Actor"] = None   # recursive
    chain_depth: int = 0                             # derived; enforced
```

### Chain operations

```python
# Agent acting on behalf of user
user = Actor(id="alice", type="user")
agent = Actor(id="researcher-v2", type="agent", acting_on_behalf_of=user)

# Subagent spawned by agent
subagent = Actor(id="web-fetcher", type="agent", acting_on_behalf_of=agent)

# authorize() sees the full chain
guard.authorize(actor=subagent, action="read", resource="doc:42")
```

### Policies can reason over chains

- **Root actor**: the top of the chain (usually the human user)
- **Immediate actor**: who is calling right now
- **Chain predicates**: `any_ancestor_is(trust_level="untrusted")`, `chain_length <= 3`, `root_actor.type == "user"`
- **Scope intersection**: effective permissions = intersection of every level's permissions

### Enforcement rules

- **Max chain depth** (configurable, default 5) — prevents runaway agent trees
- **Monotonic narrowing**: each hop in the chain can only reduce, never expand, permissions
- **Chain integrity**: delegation must be authenticated (consumer's concern — open-guard trusts the chain as constructed, but provides hooks to verify)

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Store chain in ABAC attributes (`actor.delegated_by`) | Uses existing machinery | Stringly-typed; no depth enforcement; policies can't traverse natively |
| Model chain as ReBAC relations (`acts_on_behalf_of` tuple) | Queryable, composable | Requires a ReBAC lookup on every authorize(); conflates identity with relationship |
| **Proposed: recursive `Actor.acting_on_behalf_of` field** | Explicit, typed, enforces depth; composes with all four evaluators | Changes `Actor` shape — mitigation: default `None` keeps current callers working |
| Unify with FEAT-001 delegation | Single mental model | Conflates identity flow (who is acting) with permission flow (what they can do) — distinct concerns |

## Open Questions

1. **Chain vs. delegation relationship**: is FEAT-005 the *identity* layer and FEAT-001 the *permission* layer? Or are they unified? Current lean: keep separate.
2. **Chain verification**: does open-guard verify the chain (e.g., via signed tokens), or trust the consumer? Likely trust — verification is an adjacent concern (open-shield-python).
3. **Policy DSL access**: how do policies express chain predicates? New ABAC operators (`any_ancestor`, `root_is`) or a new chain-specific condition type?
4. **DecisionTrace integration**: should traces show the full chain resolution? (FEAT-008 dependency.)
5. **Backward compatibility**: existing `Actor(...)` constructions have no chain — does this stay `None` forever (opt-in), or do we migrate?

## Scope Boundaries

- **In scope**: `Actor.acting_on_behalf_of` field, chain depth enforcement, chain-aware policy predicates, chain propagation through `authorize()`.
- **Out of scope (this item)**: permission narrowing across the chain (FEAT-001 territory), token-level identity chain parsing (belongs in open-shield-python), async approval when chain requires it (FEAT-007).
- **Related / adjacent**: FEAT-001 (permission flow), FEAT-008 (trace must render the chain), FEAT-009 (MCP tool calls carry the chain).

## References

- IETF draft-ietf-oauth-identity-chaining — the standard being written right now
- RFC 8693 — OAuth 2.0 Token Exchange (`act` claim, actor chains)
- Strata — *A New Identity Playbook for AI Agents in 2026*
- Auth0 for AI Agents — On-Behalf-Of flows
- `specs/architecture/auth-model.md` — Actor model section (to be extended)

## Graduation Criteria

- [ ] Open questions 1, 3, 5 resolved
- [ ] ADR: "Identity chain as recursive Actor vs. separate Chain entity"
- [ ] ADR: "Chain-aware policy predicates — where they live (ABAC ops vs. new type)"
- [ ] `auth-model.md` Actor section rewritten with chain semantics
