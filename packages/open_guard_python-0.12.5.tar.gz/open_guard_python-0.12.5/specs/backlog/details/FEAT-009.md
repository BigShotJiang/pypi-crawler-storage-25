---
id: FEAT-009
title: MCP tool-call authorization adapter
type: feature
priority: P1
status: open
created: 2026-04-17
target-phase: 3 (candidate)
related:
  - FEAT-005 (chain flows through MCP calls)
  - FEAT-007 (tool calls frequently require approval)
  - FEAT-008 (trace must cover tool call decisions)
  - FEAT-002 (usage counts — "agent may call tool N times")
---

# FEAT-009: MCP tool-call authorization adapter

## Problem

Model Context Protocol (MCP) is the emerging standard (Anthropic-led, broadly adopted in 2026) for exposing tools and data sources to LLMs. An MCP server exposes a set of **tools**, each with:

- A name (e.g., `send_email`, `delete_file`, `query_database`)
- A parameter schema
- A return type

An MCP client (the LLM agent) calls these tools at runtime. Without authorization, any agent with the MCP connection can invoke any tool with any parameters — which is exactly the thing every serious agent deployment needs to prevent.

Cerbos, Kong, LiteLLM, AWS Bedrock AgentCore, and Gravitee have all shipped MCP authorization products in 2025-2026. Open-guard needs a first-class MCP adapter, or it cedes the most important agentic-authz surface.

## Motivation

- **Protocol significance**: MCP is on track to be the standard way agents talk to tools.
- **Exact fit**: open-guard's existing `authorize(actor, action, resource)` maps cleanly to `authorize(agent, tool_name, params)`.
- **Parameter-level ACLs**: the industry has converged on per-parameter restrictions (e.g., "agent may call `query_database` but only on tables matching pattern X"). ABAC conditions are the natural expression.
- **Competitive gap**: Cerbos and Kong have proprietary/hosted offerings; open-guard could be the open-source primitive.

## Proposed Solution (sketch, not final)

### Adapter layer

A new package-level module `open_guard.adapters.mcp` providing:

```python
# Illustrative
from open_guard.adapters.mcp import MCPGuard

mcp_guard = MCPGuard(guard=guard)

# In MCP server handler
@mcp_server.middleware
async def authorize_tool_call(request: MCPToolRequest) -> MCPToolRequest:
    decision = mcp_guard.check_tool_call(
        actor=request.actor,                 # built from MCP session context
        tool_name=request.tool_name,
        params=request.params,
        mcp_session_id=request.session_id,
    )
    if decision.type == DecisionType.DENY:
        raise MCPAuthorizationError(decision.final_reason)
    if decision.type == DecisionType.PENDING_APPROVAL:
        # FEAT-007 integration — return pending response
        return mcp_pending_response(decision)
    return request  # allow
```

### Policy shape

Tool calls are modeled as resources of type `tool`:

```python
Policy(
    effect="allow",
    subjects=["agent:research-*"],
    actions=["invoke"],
    resources=["tool:query_database", "tool:read_file"],
    conditions={
        # Per-parameter ABAC restrictions
        "params.query": {"not_regex": r"DROP|DELETE|TRUNCATE"},
        "params.table": {"in": ["public.users", "public.docs"]},
    }
)
```

### Parameter-schema enforcement

Beyond policy matching, the adapter validates:

- Param names in the call match the tool's declared schema (structural)
- Required params present
- Types match declared types

This is **pre-authorization hygiene** — rejects malformed calls before policy evaluation.

### Session context

An MCP session carries actor identity. The adapter extracts it (via a consumer-provided resolver) and constructs the `Actor` (including FEAT-005 chain if the agent was delegated to).

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Document "use `authorize()` directly" — no adapter | Zero library surface | Every consumer rebuilds MCP context extraction, param flattening, response shaping |
| Full MCP server shipped by open-guard | Turnkey | Scope explosion; ties us to MCP evolution; most users want to integrate, not replace |
| **Proposed: thin adapter layer** | Small surface; reusable; stays close to `Guard` | Still requires consumers to wire it into their MCP server |
| Use `open_guard.fastapi` as template and mirror its pattern | Consistent with existing adapter style | MCP middleware model differs from HTTP — can't be mechanical |

## Open Questions

1. **MCP SDK dependency**: do we depend on an MCP SDK (python-mcp-sdk), or stay SDK-agnostic by taking dicts/protocols? (Lean: SDK-agnostic; provide a thin binding to the official SDK as `[mcp]` extra.)
2. **Resource naming convention**: `tool:<name>` scheme fixed, or configurable? (Lean: fixed default, overridable.)
3. **Parameter serialization for conditions**: ABAC conditions need to introspect params — flat dot-paths (`params.query`) or JSONPath? (Lean: dot-paths, keep it simple.)
4. **Budget / usage counting**: FEAT-002 composition — is `max_calls_per_session` a policy field or a runtime construct? (Lean: policy field consumed by adapter.)
5. **Multi-server**: one MCP client may talk to many MCP servers. Does the adapter need to disambiguate the resource namespace? (Yes — qualify resources with server identity.)
6. **Streaming tools**: some MCP tools stream results. Authorize the call or each chunk? (Lean: call only; streaming chunk authz is out of scope.)
7. **Tool discovery vs. invocation**: should `list_tools` be filtered by what the agent may invoke (FEAT-006 territory)?

## Scope Boundaries

- **In scope**: MCP tool-call authorization middleware, parameter-level ABAC conditions, policy shape for `tool:*` resources, session-to-Actor resolution interface, integration with FEAT-007 pending decisions.
- **Out of scope (this item)**: MCP server/client implementation, MCP transport security, MCP capability negotiation, MCP streaming chunk-level authz, filtered tool discovery (FEAT-006 territory).
- **Related / adjacent**: FEAT-002 usage counts per tool, FEAT-005 chain propagation, FEAT-007 approval flow for dangerous tools, FEAT-008 traces for each tool call.

## References

- Anthropic MCP specification — https://modelcontextprotocol.io/
- Cerbos — *Dynamic Authorization for AI Agents: Fine-Grained Permissions in MCP Servers*
- Kong — *MCP Tool ACLs* (AI Gateway 3.13)
- LiteLLM — *MCP Permission Management*
- AWS Bedrock AgentCore Gateway interceptors
- AgentBound (arXiv 2510.21236) — academic framing of MCP access control
- `specs/architecture/integration-guide.md` — pattern to mirror

## Graduation Criteria

- [ ] Open questions 1, 3, 4, 5 resolved
- [ ] ADR: "MCP SDK dependency strategy"
- [ ] ADR: "Resource naming for tools (namespacing across servers)"
- [ ] `integration-guide.md` gains an MCP section
- [ ] Example repo or cookbook entry showing a working MCP server with open-guard middleware
