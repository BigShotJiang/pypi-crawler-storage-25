---
id: FEAT-008
title: DecisionTrace — explainability output
type: feature
priority: P1
status: open
created: 2026-04-17
target-phase: 3 (candidate)
related:
  - FEAT-005 (chain must appear in traces)
  - FEAT-006 (list_authorized per-result traces — scale problem)
  - FEAT-007 (pending approval reasons in trace)
  - ENH-009 (obligations often consume traces)
---

# FEAT-008: `DecisionTrace` — explainability output

## Problem

`Guard.authorize()` returns `allow`/`deny` with a short string reason. This is insufficient when:

- An auditor asks *"prove that this agent action was authorized by a valid policy that cited a valid human approval at timestamp T"* — the string reason can't demonstrate a chain of reasoning.
- An operator is debugging a policy misfire — they need to see *which* policy fired, *which* conditions matched, *which* relations were traversed, and *why* competing policies lost.
- The LLM itself (or a reviewing agent) wants to reason over the decision — it needs structured input, not prose.
- Compliance frameworks (SOC2, HIPAA, GDPR) require provable access records — a boolean + string is not a record.

## Motivation

- In traditional authz, the request happens → the decision is made → the human who initiated it sees the outcome (allowed or blocked) and moves on. If they want to know *why*, they ask.
- In agentic authz, the agent **is** the reasoner. It makes sequential decisions. The trace is the agent's (and the auditor's) only window into why each decision happened.
- Cerbos explicitly markets "every action authorized, bounded, revocable" — traces are what makes "provably authorized" real.
- The industry is moving toward treating authz decisions as **evidence**, not just gates.

## Proposed Solution (sketch, not final)

### Trace structure

```python
# Illustrative
@dataclass(frozen=True)
class DecisionTrace:
    decision: DecisionType                    # allow | deny | pending_approval
    final_reason: str                          # human-readable summary
    evaluator_results: list[EvaluatorTrace]    # one per evaluator that ran
    composition: str                           # "union" | "intersection" etc.
    actor_chain: list[ActorSnapshot]           # FEAT-005 chain as it was resolved
    duration_ms: float
    timestamp: datetime

@dataclass(frozen=True)
class EvaluatorTrace:
    evaluator: str                             # "rbac" | "abac" | "tbac" | "rebac"
    decision: DecisionType
    matched_policies: list[PolicyMatch]        # with reason per policy
    rejected_policies: list[PolicyMatch]       # and why each failed
    attributes_read: list[str]                 # which attrs were touched (audit)
    duration_ms: float

@dataclass(frozen=True)
class PolicyMatch:
    policy_id: str
    effect: str                                # "allow" | "deny"
    matched_conditions: list[ConditionResult]
    matched_relations: list[RelationMatch]     # for ReBAC
    task_scope_ok: Optional[bool]              # for TBAC
```

### API

Two modes to control overhead:

```python
# Lightweight default — same as today, plus a short reason
decision: Decision = guard.authorize(actor, action, resource)

# Full trace — opt-in because it is more expensive
decision, trace = guard.authorize_traced(actor, action, resource)
```

Or a single API with a flag — decide during design.

### Serialization

Must be JSON-serializable — for audit log sinks, SIEM integration, and LLM consumption.

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Always return the trace | Simpler API | Overhead on hot path; huge result objects for trivial decisions |
| **Proposed: opt-in `authorize_traced()`** | Pay only when needed | Two APIs to maintain |
| Log-only trace (structured log, not return value) | Zero caller impact | Callers (like agents!) can't consume the trace in-process |
| Reuse OpenTelemetry spans | Standard tooling | Spans are flat; decisions have nested structure; loses type safety |

## Open Questions

1. **Single vs. dual API**: `authorize_traced()` vs. a flag on `authorize()`? (Dual is cleaner; flag is simpler.)
2. **Privacy of traces**: traces can leak policy structure to attackers. Should traces be returned only internally, or available to end-users/agents? (Lean: configurable — default off for production responses, on for audit sinks.)
3. **Trace storage**: does open-guard store traces, or is that the consumer's job? (Lean: consumer. We return the object.)
4. **Perf budget**: what's acceptable overhead when traced? Target: < 20% over untraced baseline.
5. **FEAT-006 interaction**: per-result traces for `list_authorized()` would explode output. Summary trace per call + optional per-result? (Lean: summary only by default.)
6. **Schema stability**: this is a public-facing data contract — once shipped, hard to change. What's the versioning story?

## Scope Boundaries

- **In scope**: `DecisionTrace` type, per-evaluator sub-traces, policy-match records, JSON serialization, opt-in API.
- **Out of scope (this item)**: trace storage backends, log sink integrations, SIEM forwarders, trace query language, trace retention policy.
- **Related / adjacent**: FEAT-005 chain rendering in traces, FEAT-007 approval reason in traces, ENH-009 obligations triggered by traces.

## References

- Cerbos `Plan Resources` API — ships decision explanations
- OpenFGA `Expand` API — decision reasoning output
- NIST SP 800-162 (ABAC) — authoritative audit-trail requirements
- XACML 3.0 — `AdviceExpressions` and `ObligationExpressions` (conceptual parents)
- OpenTelemetry semantic conventions (authz span attributes — emerging)

## Graduation Criteria

- [ ] Open questions 1, 2, 6 resolved
- [ ] ADR: "DecisionTrace API shape (single vs. dual)"
- [ ] ADR: "Trace schema versioning strategy"
- [ ] ADR: "Trace privacy defaults (what's returned to whom)"
- [ ] `auth-model.md` and `integration-guide.md` sections drafted
