---
id: FEAT-018
title: AsyncGuard.list_authorized — async-native reverse-lookup parity
type: feature
priority: P1
status: open
created: 2026-05-18
target-phase: 11
related:
  - FEAT-006
  - FEAT-014
  - FEAT-015
  - ADR-0001
  - ADR-0011 (to be authored in Phase 11 — concurrency)
  - ADR-0012 (to be authored in Phase 11 — async-parity composition)
---

# FEAT-018: `AsyncGuard.list_authorized` — async-native reverse-lookup parity

> **Purpose of this doc**: Frame the problem and direction so a future phase brainstorm can pull this in with written material instead of recalled memory. This is NOT an ADR; it does not lock decisions.

## Problem

`Guard.list_authorized(subject, action, resource_type)` has shipped since Phase 4 (FEAT-006, v0.5.0) as the reverse-lookup primitive: "given an actor and an action, which resources are allowed?" It composes RBAC, ABAC, TBAC, and ReBAC; supports cursor pagination, deny precedence, chain enforcement, and pending-approval exclusion; and is the foundation any consumer needs for filter-down UIs, RAG candidate selection, and admin "what can X do?" views.

`AsyncGuard` — the async counterpart introduced in Phase 7 (v0.8.0) and used by every async store path — does **not** implement `list_authorized`. The gap surfaces concretely:

- `src/open_guard/service/decision_router.py:136` registers `POST /list_authorized` only when `is_async=False`. Async deployments are silently missing the endpoint.
- The HTTP service today threadpool-wraps the sync path (`asyncio.to_thread(sync_guard.list_authorized, ...)`) for any consumer that wires a sync `Guard` behind an async ASGI app — but that escape hatch is unavailable to consumers that adopted `AsyncGuard` end-to-end (the supported path for native async stores wired in FEAT-016, Phase 9).
- `MCPGuard.list_authorized_tools()` (`adapters/mcp/guard.py:141`) only exists because `Guard.list_authorized` exists. There is no async MCP equivalent for the same reason.

Result: any consumer running on async SQL stores cannot enumerate authorized resources via the library's own API. They either fall back to N+1 `authorize()` calls or duplicate the iterate-per-candidate logic outside the library.

## Motivation

Why now:

1. **Async is the production path.** Phase 9 (FEAT-016) wired async SQL stores into `build_async_guard()`. The library now actively recommends `AsyncGuard` for any deployment using `postgresql+asyncpg://` or `sqlite+aiosqlite://`. Missing `list_authorized` on that path is a feature gap, not a stylistic choice.
2. **Wire contract completeness.** Phase 10 (v0.11.0) shipped `POST /list_authorized` as part of the documented service mode contract, but the endpoint silently disappears when the embedded guard is async. The wire contract should not bifurcate on the engine choice.
3. **Async-parity backlog cluster.** FEAT-014 (`AsyncDelegationEvaluator`) and FEAT-015 (Async `ApprovalManager`) are already on the backlog as P2 async-parity gaps discovered during Phase 7. FEAT-018 is the third item in the same cluster and the most user-visible — it's the only one that changes what consumers can *call*, not just what works underneath an existing call. A minor phase grouping the three would close the async-parity story in one release.

This is a library primitive, not a service-specific feature. Every consumer of `AsyncGuard` will hit this within a phase of building any admin or filter-down surface.

## Proposed Solution (sketch, not final)

Mirror the sync API on `AsyncGuard`. Same signature, same semantics, same return shape — only the I/O changes from blocking to awaitable.

### Example shape

```python
# Illustrative — subject to change during brainstorm

class AsyncGuard:
    async def list_authorized(
        self,
        subject: Subject,
        action: Action | str,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None = None,
        limit: int = 100,
        cursor: ListCursor | None = None,
        candidate_source: AsyncCandidateResourcePort | None = None,
        session_id: str | None = None,
    ) -> ListAuthorizedResult:
        ...
```

Implementation direction (to be locked in the phase brainstorm, not here):

- **ReBAC fast path**: reuse the existing `AsyncRelationshipStorePort.find_object_ids_for_subject` method (already shipped in Phase 7 — `src/open_guard/domain/ports/async_relationship_store.py:94`). No new port method needed.
- **ABAC / RBAC / TBAC path**: reuse the existing `AsyncCandidateResourcePort` (already shipped in Phase 7 — `src/open_guard/domain/ports/async_candidate_resource.py`). No new port introduced. Same iterate-per-candidate composition documented in ADR-0001.
- **Decision pipeline reuse**: route each candidate through `AsyncGuard.authorize()` so deny precedence, chain enforcement, pending-approval status, session activation, and trust-gate evaluation all behave identically to the sync path. No parallel evaluator logic.
- **Cursor / pagination**: reuse the existing `ListCursor` and `ListAuthorizedResult` entities unchanged. Pagination semantics are a property of the data model, not the I/O model.
- **Service mode**: drop the `if not is_async` guard in `decision_router.py`. `POST /list_authorized` becomes available on every service deployment.
- **MCP adapter**: a future companion item can add `AsyncMCPGuard.list_authorized_tools()` once `AsyncGuard.list_authorized` exists; out of scope for this item.

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Implement `AsyncGuard.list_authorized` natively (this item) | Real async I/O across stores; consistent wire contract; matches the recommended async deployment path. | Requires new `AsyncCandidateResourcePort` and an async method on `AsyncRelationshipStorePort`. |
| Threadpool-wrap sync `Guard.list_authorized` from `AsyncGuard` | Smallest code change; reuses the existing implementation. | Blocks an executor thread per call; defeats async stores; doesn't work when the underlying stores are async-only. Rejected for the same reason `AsyncGuard` itself was introduced (Phase 7 decision: "to_thread() wrapper rejected — thread pool saturation at scale"). |
| Add the method to `AsyncGuard` but skip the ReBAC fast path | Lighter scope. | Inconsistent with sync semantics; ReBAC enumeration falls back to O(N) iteration; consumers see a performance cliff when switching engines. |
| Defer until a consumer asks | Zero work now. | The wire contract is already split between sync and async deployments today (v0.11.0); each new consumer adopting `AsyncGuard` re-discovers the gap. |

## Open Questions

1. **Async candidate port shape** — Mirror `CandidateResourcePort` exactly (`async def next_batch(...)` returning `(ids, next_cursor)`), or use an `AsyncIterator`/`AsyncGenerator`-based protocol? The first is a closer parity and easier to reason about; the second is more idiomatic for streaming sources. Decide during brainstorm.
2. **Concurrency for the iterate-per-candidate path** — Should the async implementation `gather` `authorize()` calls in bounded batches, or stay sequential like the sync version? Bounded concurrency is a real win for I/O-bound async stores; concurrency control needs to interact safely with cursor pagination and per-decision side effects (e.g. approval state).
3. **Pending-approval interaction** — Sync `list_authorized` excludes pending-approval results from the returned list (ADR-0001). Confirm the same rule, and confirm `AsyncGuard` still has the necessary approval gate by the time this lands — FEAT-015 (Async `ApprovalManager`) is currently open. Either FEAT-015 lands first, or FEAT-018 documents the gap explicitly.
4. **Delegation contribution** — Sync `list_authorized` accepts contributions from `DelegationEvaluator` (Phase 5). FEAT-014 (`AsyncDelegationEvaluator`) is open; the same ordering question applies — does FEAT-018 ship without delegation contribution and document the gap, or does it wait for FEAT-014?
5. **MCP async companion** — `AsyncMCPGuard.list_authorized_tools()` is a natural follow-on but is a separate item; should it be filed now or after FEAT-018 lands?

## Scope Boundaries

- **In scope**:
  - `AsyncGuard.list_authorized(...)` with full feature parity to sync (cursor pagination, deny precedence, chain enforcement, pending-approval exclusion, session activation, trust-gate composition).
  - `candidate_source: AsyncCandidateResourcePort | None` kwarg on `AsyncGuard.__init__` + factory wiring (sync `Guard` already accepts this).
  - Drop the `if not is_async` guard in `service/decision_router.py` so `POST /list_authorized` works for both sync and async service deployments.
  - No new ports — `AsyncCandidateResourcePort` and `AsyncRelationshipStorePort.find_object_ids_for_subject` were already shipped in Phase 7.
  - No Python SDK signature change — the wire endpoint is unchanged.
- **Out of scope (for this item)**:
  - REST endpoint additions beyond unbundling the existing one — this is the library primitive plus the existing wire contract.
  - Reverse-subject lookup (`list_subjects_authorized_for(action, resource)`) — a different shape; file separately if a real need surfaces.
  - Result caching / memoization (`list_authorized(..., cache=True)`) — implementation detail to add later only if profiling demands it.
  - Reverse-ABAC query compilation — already deferred (ENH-014); orthogonal to async parity.
  - Async MCP `list_authorized_tools` — follow-on item, file separately.
  - Per-result explainability (`trace_ids=`) for async — already deferred (ENH-016); orthogonal.
- **Related / adjacent**:
  - **FEAT-006** — sync `Guard.list_authorized` (the parity baseline). ADR-0001 documents the composition strategy.
  - **FEAT-014** — `AsyncDelegationEvaluator`. Same async-parity cluster. Decide ordering during brainstorm.
  - **FEAT-015** — Async `ApprovalManager`. Same async-parity cluster. Decide ordering during brainstorm.
  - **ENH-014** — reverse-ABAC query compilation (deferred). Could later optimize both sync and async list paths together.
  - **ENH-016** — per-result explainability for `list_authorized` (deferred). Applies to whichever paths exist.

## References

### Industry-standard reverse-lookup APIs (vendor-neutral)

This primitive is the same shape exposed by every modern policy engine. open-guard follows the same standard, not any single vendor.

- **OpenFGA — `ListObjects`** (CNCF, Apache-2.0): "given a user, a relation, and an object type, return all objects of that type the user has the relation to." [openfga.dev/api/service#/Relationship%20Queries/ListObjects](https://openfga.dev/api/service)
- **Auth0 FGA — `listObjects`**: same shape as OpenFGA (Auth0 FGA is built on OpenFGA).
- **Google Zanzibar — `Expand` / reverse-lookup**: original academic source for relation-tuple-based reverse lookup. ([Pang et al., USENIX ATC '19](https://research.google/pubs/pub48190/))
- **SpiceDB — `LookupResources`** (Apache-2.0): direct Zanzibar implementation; same semantics. [authzed.com/docs/spicedb/concepts/api-types#lookupresources](https://authzed.com/docs)
- **AWS Verified Permissions — `BatchIsAuthorized` / `IsAuthorizedWithToken`**: reverse-lookup over Cedar policies. [docs.aws.amazon.com/verifiedpermissions](https://docs.aws.amazon.com/verifiedpermissions/)
- **Cerbos — `PlanResources`**: server-side query plan generation for filter-down. [cerbos.dev/docs/latest/api/](https://cerbos.dev/docs)
- **Casbin — `getImplicitResourcesForUser`**: reverse permission enumeration. [casbin.org/docs/rbac-api](https://casbin.org/docs/rbac-api)

### Internal references

- **ADR-0001** — `list_authorized` composition strategy (iterate-per-candidate + native ReBAC enumeration). Locked the sync design; this item inherits the same model.
- **specs/architecture/integration-guide.md** — Phase 4 section covers consumer usage of `list_authorized`; will need an async mirror.
- **specs/phases/phase-4-agent-integration/** — phase materials for the sync version.

## Graduation Criteria

What must be true to pull this into a phase?

- [x] Open question 1 (port shape) — resolved: `AsyncCandidateResourcePort` already exists from Phase 7, no design needed.
- [ ] Open question 2 (concurrency model) — to be locked in ADR-0011 during Phase 11 (sequential per-candidate evaluation is the default).
- [x] Ordering vs FEAT-014 / FEAT-015 decided — bundled into Phase 11 "Async Parity" (v0.12.0); see `specs/phases/phase-11-async-parity/`.
- [ ] ADR-0011 (concurrency) + ADR-0012 (async-parity composition) authored during Phase 11.
- [ ] Integration-guide Phase 11 section drafted with executable mirrors.
- [x] Wire contract version `SERVICE_API_VERSION = "v1"` confirmed stable — this is an additive change to the existing endpoint's availability, not a new endpoint or a signature change.
