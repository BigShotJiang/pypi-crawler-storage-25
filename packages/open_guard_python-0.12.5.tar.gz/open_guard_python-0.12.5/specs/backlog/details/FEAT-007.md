---
id: FEAT-007
title: Tri-state Decision with pending_approval
type: feature
priority: P1
status: open
created: 2026-04-17
target-phase: 3 (candidate)
related:
  - FEAT-001 (pull delegation — approval is its natural signal)
  - ENH-009 (obligations — approval may trigger post-decision hooks)
---

# FEAT-007: Tri-state `Decision` with `pending_approval`

## Problem

`Guard.authorize()` returns a binary decision: `allow` or `deny`. For agentic systems, a critical third state is missing: **"not yet — a human must approve first."**

Examples where binary is wrong:

- Agent wants to send an email on user's behalf → should require explicit user confirmation
- Agent wants to spend > $X → budget policy requires human sign-off
- Agent wants to take a destructive action (delete file, close ticket) → human-in-the-loop required
- Delegation pull request (FEAT-001) — inherent approval flow

Today consumers fake it: either `deny` and hope the caller retries with a different context, or `allow` and pray. Neither is correct.

## Motivation

- **Auth0 Async Authorization** ships this as a first-class product feature.
- Anthropic's own agent patterns (tool approval in Claude Code) demonstrate this exact UX is mandatory for trusted agent deployments.
- Without it, any "dangerous action" policy has to be externalized — defeating the point of a unified authz library.

## Proposed Solution (sketch, not final)

### Decision enum extension

```python
# Illustrative
class DecisionType(Enum):
    ALLOW = "allow"
    DENY = "deny"
    PENDING_APPROVAL = "pending_approval"

@dataclass(frozen=True)
class Decision:
    type: DecisionType
    reason: str
    # New fields for pending_approval:
    approval_request_id: Optional[str] = None
    approval_channel: Optional[str] = None       # "slack", "email", "webhook", ...
    approval_ttl: Optional[timedelta] = None
    required_approvers: list[str] = field(default_factory=list)
```

### Resume semantics

```python
# Illustrative
decision = guard.authorize(actor, "send_email", resource)
if decision.type == DecisionType.PENDING_APPROVAL:
    # Consumer sends approval request via their own channel
    # User approves → calls back:
    guard.approve(decision.approval_request_id, approver="alice")

    # Re-run the same authorization — now returns ALLOW
    decision = guard.authorize(actor, "send_email", resource)
```

### Policy shape

A new policy field indicates approval is required:

```python
Policy(
    effect="allow",
    subjects=[...],
    actions=["send_email"],
    resources=["*"],
    requires_approval=ApprovalRequirement(
        approvers=["role:manager"],      # who can approve
        ttl=timedelta(hours=4),
        channel="slack"                   # hint for consumer dispatch
    )
)
```

### Storage

New `ApprovalStorePort` for pending requests. In-memory + SQLAlchemy impls.

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Consumer implements approval outside open-guard | Zero library change | Every consumer rebuilds the same pattern; policies can't express it |
| Use obligations (ENH-009) to trigger approval | Reuses obligation machinery | Obligations are post-decision — approval is a blocking pre-condition, not a post-action |
| Return `deny` with a "retry after approval" reason code | Minimal API change | Callers can't distinguish "never" from "not yet"; no resume semantics |
| **Proposed: explicit `PENDING_APPROVAL` state + approve/resume API** | Clear model; composable with FEAT-001; matches industry | New surface area; new store |

## Open Questions

1. **Approval channel dispatch**: does open-guard send the approval request, or just return enough info for the consumer to dispatch? (Lean: consumer dispatches — open-guard stays transport-neutral.)
2. **Multi-approver semantics**: quorum, any-one, all? (Lean: support all three, default any-one.)
3. **Cache of decision**: if same `authorize()` is called twice before approval, do we deduplicate to one pending request? (Lean: yes, idempotent by `(actor, action, resource)` hash.)
4. **Expiry handling**: what happens when TTL elapses — auto-deny on next check? Explicit cleanup job?
5. **Pending during agent chain**: if FEAT-005 chain includes agents, who is the approver — the immediate actor or the root user? (Lean: policy decides; default root user.)
6. **Interaction with FEAT-008 traces**: the trace should show "pending because policy P required approval from X."

## Scope Boundaries

- **In scope**: `PENDING_APPROVAL` decision, approval policy field, `approve()` / `reject()` API, `ApprovalStorePort`, TTL enforcement.
- **Out of scope (this item)**: actual dispatch transport (Slack/email integrations), UI for approvers, multi-approver workflow orchestration beyond quorum/any/all, webhook signing.
- **Related / adjacent**: FEAT-001 pull delegation uses this as its natural return state; ENH-009 obligations may fire on approval/rejection.

## References

- Auth0 for AI Agents — *Async Authorization* feature
- Anthropic Claude Code — tool approval UX (prior art for "ask before doing")
- NIST 800-207 Zero Trust — "never trust, always verify" extended to agentic actions
- OAuth 2.0 device flow / CIBA (Client-Initiated Backchannel Authentication) — approval-out-of-band pattern

## Graduation Criteria

- [ ] Open questions 1, 2, 5 resolved
- [ ] ADR: "Tri-state vs. binary Decision (commits to a breaking return-type change)"
- [ ] ADR: "Approval dispatch — library responsibility vs. consumer responsibility"
- [ ] `auth-model.md` Decision section extended
- [ ] Migration note for consumers on existing binary-decision code
