---
id: FEAT-NNN
title: Short title
type: feature | bug | tech-debt | enhancement
priority: P0 | P1 | P2 | P3
status: open | in-progress | resolved | deferred | deprecated
created: YYYY-MM-DD
target-phase: N | unassigned
related:
  - FEAT-X
  - ENH-Y
  - ADR-NNNN (if any locked decisions exist yet)
---

# FEAT-NNN: Title

> **Purpose of this doc**: Capture the thinking behind a complex backlog item so that — when a phase brainstorm pulls it in — there is written material to start from instead of recalled memory. This is NOT an ADR; it does not lock decisions. It frames the problem, sketches a direction, and lists what still needs answering.

## Problem

What doesn't work today? Who feels the pain, and when?

## Motivation

Why now? What triggered this — a research finding, an incident, an industry shift, a user request?

## Proposed Solution (sketch, not final)

High-level direction. Key primitives, entities, or APIs likely involved. Avoid locking decisions — that's the phase brainstorm's job.

### Example shape

```python
# Illustrative API sketch — subject to change during brainstorm
```

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| A | | |
| B | | |

## Open Questions

Numbered list of things that must be answered before a phase can plan this.

1. ...
2. ...

## Scope Boundaries

- **In scope**: what this item covers
- **Out of scope (for this item)**: what explicitly belongs to another item
- **Related / adjacent**: FEAT-X, ENH-Y — how this connects to them

## References

- Industry sources, prior art
- Academic papers
- Related ADRs in `specs/decisions/`
- Architecture docs this relates to

## Graduation Criteria

What must be true to pull this into a phase? Which decisions here would become ADRs once locked?

- [ ] Open questions above are answered
- [ ] An ADR exists for: [list the key decisions]
- [ ] Architecture doc section drafted if needed
