---
id: FEAT-006
title: list_authorized() — RAG filter-query API
type: feature
priority: P1
status: open
created: 2026-04-17
target-phase: 3 (candidate)
related:
  - FEAT-008 (DecisionTrace — per-result reasoning)
  - ENH-008 (PIP — may be needed for attribute enrichment during bulk eval)
---

# FEAT-006: `list_authorized()` — RAG filter-query API

## Problem

RAG (retrieval-augmented generation) pipelines need to answer the **inverse** of `authorize()`:

- `authorize()`: "Can actor A perform action X on resource R?"  → boolean
- `list_authorized()`: "**Which** resources of type T can actor A perform action X on?" → list of resource IDs

Without this, a RAG pipeline has two bad options:

1. Retrieve all documents, then filter via N round-trip `authorize()` calls (O(N) decisions per query — crushes latency)
2. Skip filtering, return everything, and let the LLM "decide" (catastrophic data leak risk)

## Motivation

- **OpenFGA ships `ListObjects`** — this is the canonical FGA-for-RAG primitive.
- **Auth0 FGA sells "FGA for RAG"** as a top-tier feature. Cerbos, SpiceDB, AuthZed all have equivalents.
- Every real-world agentic app that uses tenant-scoped or user-scoped document search needs this.
- Without it, open-guard is unusable for RAG — a major agentic-era use case.

## Proposed Solution (sketch, not final)

```python
# Illustrative
doc_ids: list[str] = guard.list_authorized(
    actor=user,
    action="read",
    resource_type="document",
    resource_filter={"tenant_id": "acme"},   # optional prefilter
    limit=100,
    cursor=None
)
```

### Behaviour across the four models

- **RBAC**: roles → permissions → resource patterns. Return all resources matching patterns the actor's roles grant.
- **ABAC**: conditions depend on resource attributes — requires either iterating candidate resources and evaluating, or reversing conditions into a query (reverse-ABAC, hard). Pragmatic: iterate with early termination.
- **TBAC**: filter by task-scoped resources valid right now.
- **ReBAC**: native strength — Zanzibar `ListObjects` algorithm. The primary source of truth for this operation.

### Composition

Result is the **union** (for "allow-any") or **intersection** (for "must-satisfy-all") across the four models, matching the existing `Guard` evaluator composition.

### Pagination

Cursor-based, because result sets can be arbitrarily large.

### Consistency

Point-in-time snapshot. No cross-call consistency guarantees (revisit when/if we add zookies — currently out of scope per Phase 2 decisions).

## Alternatives Considered

| Option | Pros | Cons |
|--------|------|------|
| Client iterates + calls `authorize()` per resource | No new API surface | O(N) decisions; catastrophic latency for large corpora |
| Dedicated ReBAC-only `list_objects()` | Maps directly to Zanzibar | Doesn't work for RBAC/ABAC-only deployments; forces users to pick a model |
| **Proposed: unified `list_authorized()` across all four models** | Matches `authorize()` composition; one API for all consumers | Reverse-ABAC is hard; implementation complexity |
| Expose a SQL query builder consumers run themselves | Maximum flexibility | Leaks policy internals; kills portability; ties consumers to store shape |

## Open Questions

1. **Reverse-ABAC**: is iteration-with-early-termination acceptable for P1, with true reverse-query reserved for later? (Lean: yes.)
2. **Cursor stability**: what happens if policies change mid-pagination? Document as undefined behavior, or snapshot at first call?
3. **Result shape**: list of IDs only, or IDs + the matching resource attributes? (Lean: IDs only — caller does enrichment.)
4. **Default limit**: reasonable default to prevent accidentally listing millions? (Propose: 100, no upper bound enforced.)
5. **Interaction with PIP (ENH-008)**: bulk eval may need bulk attribute fetch to avoid per-resource round trips.

## Scope Boundaries

- **In scope**: single actor + single action + single resource type + optional prefilter → list of IDs with cursor pagination, unified across RBAC/ABAC/TBAC/ReBAC.
- **Out of scope (this item)**: multi-action or multi-actor bulk eval, zookie-style consistency tokens, reverse-ABAC query compilation, result enrichment with resource attributes.
- **Related / adjacent**: FEAT-008 DecisionTrace is awkward at scale — per-result traces would explode output; need a separate shape.

## References

- Google Zanzibar paper — `Expand` and `Check` operations; `ListObjects` is implementation-defined but canonical
- OpenFGA `ListObjects` API documentation
- Auth0 FGA — "FGA for RAG" product positioning
- SpiceDB `LookupResources` API
- `specs/architecture/auth-model.md` — four-model composition

## Graduation Criteria

- [ ] Open questions 1, 3, 4 resolved
- [ ] ADR: "List API composition semantics across four models (union vs. intersection)"
- [ ] ADR: "Reverse-ABAC strategy (iteration vs. query compilation)"
- [ ] API stubbed in `auth-model.md` and `integration-guide.md`
