# Roadmap

> **Start Date**: 2026-04-16
> **Last Updated**: 2026-05-04 (Phase 10 complete — v0.11.0 released)

## Timeline

| Phase | Name | Status | Start | End | Effort |
|-------|------|--------|-------|-----|--------|
| 0 | RBAC + ABAC Core | **Complete** | 2026-04-16 | 2026-04-16 | 1 day |
| 1 | TBAC (Time + Task) | **Complete** | 2026-04-16 | 2026-04-16 | 1 day |
| 2 | ReBAC + SQLAlchemy + ABAC Enhancements | **Complete** | 2026-04-16 | 2026-04-17 | 1 day |
| 3 | Agentic Core Contract (OBO chains + async approval + traces) | **Complete** | 2026-04-17 | 2026-04-18 | ~1 session |
| 4 | Agent Integration Surface (list_authorized + MCP adapter + integration guide) | **Complete** | 2026-04-18 | 2026-04-18 | ~1 session |
| 5 | Delegation & Bounds (push/pull delegation + usage caps + leases) | **Complete** | 2026-04-19 | 2026-04-19 | ~1 session |
| 6 | Production Hardening — Sessions, Policy Isolation & Push Revocation | **Complete** | 2026-04-19 | 2026-04-19 | ~1 session |
| 7 | Consumer Integration (Factory, Admin SDK, REST API, Async, CLI) | **Complete** | 2026-04-19 | 2026-04-19 | ~1 session |
| 8 | AI-Era Primitives (TrustGate + OperationChain + ActorType) | **Complete** | 2026-04-20 | 2026-04-20 | ~1 session |
| 9 | Production Integration (Cerebrio P0 Blockers) | **Complete** | 2026-04-20 | 2026-04-28 | ~1 session |
| 10 | Service Mode + Python SDK (HTTP wrapper + sync/async Python clients) | **Complete** | 2026-05-04 | 2026-05-04 | ~1 session |
| 11 | Async Parity (AsyncGuard.list_authorized + AsyncDelegationEvaluator + AsyncApprovalManager) | **Complete** | 2026-05-18 | 2026-05-18 | ~1 session |
| 12 | gRPC + non-Python SDKs (gRPC service + TS/Go SDKs + MCP /tools/check endpoint) | Not Scheduled | — | — | — |

## Phase Dependencies

```
Phase 0 (RBAC + ABAC Core)
  └── Phase 1 (TBAC — Time + Task)
       └── Phase 2 (ReBAC + SQLAlchemy stores + ABAC enhancements)
            └── Phase 3 (Agentic Core Contract)
                 └── Phase 4 (Agent Integration Surface)
                      └── Phase 5 (Delegation & Bounds)
                           └── Phase 6 (Production Hardening — Sessions, Isolation, Push Revocation)
                                └── Phase 7 (Consumer Integration)
                                     └── Phase 8 (AI-Era Primitives)
                                          └── Phase 9 (Production Integration — Cerebrio P0)
                                               └── Phase 10 (Service Mode + Python SDK)
                                                    └── Phase 11 (Async Parity)
                                                         └── Phase 12 (gRPC + TS/Go SDKs)
```

## Milestones

| Milestone | Phase | Target Date |
|-----------|-------|-------------|
| Core auth engine + FastAPI integration | 0 | 2026-04-21 ✅ |
| Time + task access control | 1 | 2026-04-28 ✅ |
| Relationship access control + SQL store | 2 | 2026-05-05 ✅ |
| Agentic core (chains, approvals, traces) — v0.4.0 | 3 | 2026-05-12 ✅ (delivered 2026-04-18) |
| Agent integration (RAG filter, MCP) — v0.5.0 | 4 | 2026-05-19 ✅ (delivered 2026-04-18) |
| Delegation & bounds — v0.6.0 | 5 | 2026-05-26 ✅ (delivered 2026-04-19) |
| Production hardening (sessions, isolation, revocation) — v0.7.0 | 6 | — ✅ (delivered 2026-04-19) |
| Consumer integration (factory, admin SDK, async, CLI) — v0.8.0 | 7 | — ✅ (delivered 2026-04-19) |
| AI-Era Primitives (TrustGate + OperationChain) — v0.9.0 | 8 | — ✅ (delivered 2026-04-20) |
| Production Integration (Cerebrio P0) — v0.10.0 | 9 | — ✅ (delivered 2026-04-28) |
| Service Mode + Python SDK — v0.11.0 | 10 | — ✅ (delivered 2026-05-04) |
| Async Parity — v0.12.0 | 11 | — ✅ (delivered 2026-05-18) |

## Phase Summaries

### Phase 0 — RBAC + ABAC Core
Clean/hexagonal architecture, domain entities, RBAC evaluator with hierarchy, ABAC evaluator with condition operators, InMemoryPolicyStore, Guard unified API, FastAPI integration, open-shield-python bridge.

### Phase 1 — TBAC (Time + Task)
Time-based access control (absolute windows, recurring schedules with IANA timezone, TTL/ISO 8601 durations). Task-based access control (task entity with lifecycle state machine, permission scoping, parent-child hierarchy with narrowing, auto-revocation). TBACEvaluator, TaskStorePort, InMemoryTaskStore, TaskManager.

### Phase 2 — ReBAC + SQLAlchemy + ABAC Enhancements
Relationship-based access control (Zanzibar-style relation tuples, graph traversal with union/intersection/exclusion/arrow computed permissions, wildcards, subject sets, memoization, max-depth). SQLAlchemy-based stores for policies, tasks, and relationship tuples (SQLite/PostgreSQL/MySQL via JSON columns, consumer-owned engine, `[sql]` optional extra). ABAC enhancements — OR logic via `condition_groups`, negated operators (`not_contains`, `not_regex`), set operators (`contains_any`, `contains_all`, `is_subset`). Resolved ENH-004 and ENH-007.

### Phase 3 — Agentic Core Contract
Evolve core contracts for agentic systems — all additive, no breaking changes. `Subject` becomes a recursive chain via `on_behalf_of` with enforced depth limits and chain-aware ABAC predicates. `Decision` gains a `status` enum (ALLOWED/DENIED/PENDING_APPROVAL) with backward-compatible `allowed` property; policies can require human approval; resume via `guard.approve()` / `guard.reject()`. New `ApprovalStorePort` + `ApprovalManager` with idempotency, quorum, TTL. Opt-in `authorize_traced()` returns structured `DecisionTrace` (per-evaluator PolicyMatch with conditions/relations, actor chain, timing). Delivers FEAT-005 + FEAT-007 + FEAT-008 as v0.4.0.

### Phase 4 — Agent Integration Surface
Outward-facing integration layer for agentic systems. `list_authorized(actor, action, resource_type)` — the RAG filter-query API matching OpenFGA `ListObjects` / Auth0 FGA semantics; composes across RBAC/ABAC/TBAC/ReBAC with cursor pagination. MCP tool-call authorization adapter — maps Model Context Protocol tool invocations to `Guard.authorize()` with per-parameter ABAC conditions, resource-type namespacing (`tool:<name>`), session-to-Subject resolution, and integration with Phase 3 pending_approval flow for dangerous tools. Delivers FEAT-006 + FEAT-009 as v0.5.0.

### Phase 5 — Delegation & Bounds
First-class delegation primitives for agent-to-subagent handoffs. Push/pull delegation (Thomas & Sandhu 1997) with scope narrowing and cascade revocation. Usage-counted / budget-capped permissions ("agent may call tool N times / spend up to $X"). Heartbeat/lease renewal for long-running agents (Vault/etcd-style). Prompt-injection-resistant policy isolation documentation + test suite. Delivers FEAT-001 + FEAT-002 + FEAT-003 + FEAT-010 as v0.6.0.

### Phase 6 — Production Hardening (Sessions, Policy Isolation & Push Revocation)
NIST-compliant RBAC sessions (Session entity, SessionStorePort, SessionManager, session-aware RBACEvaluator, Guard.authorize(session_id=...), session.* ABAC namespace, multiple concurrent sessions). Prompt-injection-resistant policy isolation (ReadOnlyPolicyView, taint marking, trusted_only condition modifier, adversarial test suite). CAEP-style push revocation (RevocationEvent, RevocationStreamPort, InMemoryRevocationStream, integration with DelegationManager + SessionManager). Resolves ENH-001, FEAT-010, ENH-010 as v0.7.0.

### Phase 7 — Consumer Integration (v0.8.0)
Makes open-guard consumable by any Python app with minimal wiring. `Guard.from_config()` / `AsyncGuard.from_config()` one-liner factory. `PolicyAdmin` in-process SDK for tenant-scoped CRUD (policies, roles, relationships, delegations, sessions). `AdminRouter` mountable FastAPI router for REST management. `create_all_tables()` + CLI (`open-guard db init/schema`) + DDL export. Full async architecture: 8 async port ABCs, async memory + SQLAlchemy stores, `AsyncReBACEvaluator`, `AsyncPolicyRouter`, `AsyncGuard`. `[sql-async]` optional extra. 959 tests, 94% coverage. Resolves FEAT-011.

### Phase 8 — AI-Era Primitives (v0.9.0)
Evolve open-guard from a traditional 4-model authorization library to the enforcement engine for AI-era systems. `TrustGateEvaluator` — 5th evaluator gating on `trust_score` thresholds with chain-aware scopes (immediate/all/root). `OperationChainConfig` — action-pattern-based evaluator selection via fnmatch glob routing (first-match-wins). `ActorType` extended with `ROBOT` and `EDGE_DEVICE`. `EvaluatorPort.evaluator_type` abstract property on all evaluators. All wired through Guard/AsyncGuard factory. 1037 tests, 94% coverage. Zero breaking changes for consumers (operation_chain defaults to None).

### Phase 9 — Production Integration (Cerebrio P0 Blockers)
Close all P0 gaps blocking cerebrio-sapience production integration. Wire async SQL stores into `build_async_guard()` factory (FEAT-016) — accepts `sqlite+aiosqlite://` and `postgresql+asyncpg://` DSNs. Expose typed public `sync_store` property on all 6 async in-memory stores (ENH-020). Add resource-scoped RBAC role assignment via `resource_match` dict on `assign_role`/`revoke_role` (FEAT-017) — domain-neutral, no evaluator changes. Add `PolicyAdmin.check_relationship()` + `POST /relationships/check` AdminRouter endpoint (ENH-021) — Zanzibar `Check` parity. Delivered as v0.10.0 with zero breaking changes; 1069 tests, 94% coverage.

### Phase 10 — Service Mode + Python SDK (complete, v0.11.0 released 2026-05-04)
HTTP service mode + first-class Python SDK. New `open_guard.service` module with `create_app(...)` factory exposing a DecisionRouter (`/v1/authorize`, `/list_authorized`, `/authorize_and_consume`, `/authorize/traced`) and the existing AdminRouter under a configurable `/v1` prefix. Pluggable authentication: built-in `ApiKeyAuth`, optional `ShieldAuth` (open-shield JWT via `[shield]` extra), and a `CallableAuth` BYO escape hatch. Tenancy enforced from the auth claim — `X-Tenant-ID` override only honored with `cross_tenant_admin` scope. New `open_guard.client` module: sync `OpenGuardClient` + async `AsyncOpenGuardClient`, namespaced API (`client.decisions.*`, `client.admin.*`), shared `_BaseClient`, idempotent-only retries, typed exception hierarchy. Three new optional extras: `[service]`, `[shield]`, `[client]`. Reference Dockerfile under `deploy/service/`. Slim scope: gRPC and TS/Go SDKs and the MCP `/tools/check` endpoint deferred to a later phase. Targets v0.11.0. ADR-0009 (wire contract) + ADR-0010 (SDK shape).

### Phase 11 — Async Parity (complete, v0.12.0 delivered 2026-05-18)
Closed the remaining async-parity gaps so `AsyncGuard` has the same surface as sync `Guard`. Bundled three sibling primitives — all async siblings of existing sync code, no new public abstractions: **FEAT-018** `AsyncGuard.list_authorized` (async-native reverse-lookup; aligned with OpenFGA `ListObjects` / Zanzibar / SpiceDB `LookupResources` / AWS Verified Permissions `BatchIsAuthorized` / Auth0 FGA / Cerbos `PlanResources` / Casbin), **FEAT-014** `AsyncDelegationEvaluator` + delegation fallback on `AsyncGuard.authorize` + `AsyncGuard.authorize_and_consume` (CAS-safe on async SQL stores), and **FEAT-015** `AsyncApprovalManager` + approval gating + `AsyncGuard.approve` / `reject` (SHA-256 idempotency reused from sync). Side-effect: `service/decision_router.py` drops the `if not is_async` guard so `POST /list_authorized` is engine-agnostic. 1235 tests (+49), 93% coverage, zero breaking changes, zero new optional extras, `SERVICE_API_VERSION` stays `"v1"`. ADR-0011 (sequential per-candidate evaluation) + ADR-0012 (mirror-not-redesign composition).

### Phase 12 — gRPC + non-Python SDKs (not scheduled, renumbered from prior Phase 11)
gRPC service (proto schema, codegen, streaming considerations) + TypeScript and Go SDKs once the Python wire contract has been validated by a real consumer. Adds the MCP `/tools/check` endpoint behind the `[mcp]` extra. May also pick up SQL-backed `ApiKeyStore` if real deployments demand it.

## Open Questions

### [DEFERRED] Should open-shield be absorbed into open-guard?

> **Raised**: 2026-04-21 | **Status**: Under discussion — no decision made

**The question**: Merge open-shield-python into open-guard as an optional `authentication/` module, making open-guard the single library for the full auth pipeline (token validation → identity → authorization decision).

**Arguments for merging:**
- JWT validation is a utility (~500 lines wrapping pyjwt + httpx), not a domain worth a separate project
- open-shield's authorization helpers (`require_scope`, `require_role`) are redundant — open-guard handles this 100x better with real policies
- Nobody uses open-shield without open-guard in a real production system
- The `_subject_from_user_context()` bridge would not exist if they were one library
- One dependency, one config surface, clearer mental model: "open-guard handles auth"

**Arguments for keeping separate:**
- Different dependency trees — merging forces all consumers to pull in OIDC/JWT libs even if they don't need authentication (e.g. service-to-service with API keys)
- Can be used independently in simple apps that only need "is this user logged in?"
- Different spec change cadences: OIDC spec vs. policy model

**Proposed structure if merged:**
```
open-guard/
├── authentication/    # What was open-shield (optional install extra)
│   ├── jwt/
│   ├── oidc/
│   └── providers/
├── authorization/     # What open-guard already is
│   ├── rbac/ abac/ tbac/ rebac/ trust/
└── guard.py           # Unified entry point
```

**Impact if merged:**
- open-shield-python repo would be archived/deprecated
- open-guard gains `[auth]` optional extra with JWT/OIDC deps
- cerebrio-sapience depends on one library for the full auth stack

**Decision needed before**: Phase 10 (Service Mode + SDKs) — that phase shapes the public API surface.

---

## Change Log

- **2026-05-18**: Phase 11 repurposed from "gRPC + non-Python SDKs" to "Async Parity" (v0.12.0). Bundles FEAT-018 (AsyncGuard.list_authorized — new), FEAT-014 (AsyncDelegationEvaluator — promoted P2→P1 for the bundle), FEAT-015 (AsyncApprovalManager — promoted P2→P1 for the bundle). All three are async siblings of existing sync primitives; zero new public abstractions, zero wire-contract changes, SERVICE_API_VERSION unchanged. Triggered by realising the service mode `POST /list_authorized` endpoint silently bifurcates on engine choice (`service/decision_router.py:136`). Industry alignment: OpenFGA `ListObjects`, Zanzibar / SpiceDB `LookupResources`, AWS Verified Permissions `BatchIsAuthorized`, Auth0 FGA `listObjects`, Cerbos `PlanResources`, Casbin `getImplicitResourcesForUser` (list_authorized); NIST RBAC delegation + Vault/etcd leases (delegation); XACML obligations / NIST SP 800-162 (approval). gRPC + TS/Go SDKs + MCP `/tools/check` endpoint moved to Phase 12. Phase files at `specs/phases/phase-11-async-parity/`. ADR-0011 (concurrency) + ADR-0012 (async-parity composition) to be authored during implementation.
- **2026-05-04**: Phase 10 brainstormed and scope narrowed. Original "Service Mode + SDKs" (HTTP+gRPC + Py/TS/Go) split into Phase 10 (HTTP service + Python SDK) and Phase 11 (gRPC service + TS/Go SDKs + MCP `/tools/check`). Slim scope chosen to validate the wire contract with one SDK before duplicating across languages, and to keep gRPC's proto/codegen complexity in its own phase. Phase files written under `specs/phases/phase-10-service-mode-sdk/`. ADR-0009 + ADR-0010 to be authored during implementation.
- **2026-04-28**: Phase 9 complete — v0.10.0, 1069 tests, 94% coverage, zero breaking changes. Production Integration: async SQL factory wiring (FEAT-016), public `sync_store` accessor (ENH-020), resource-scoped RBAC via `resource_match` (FEAT-017), `check_relationship()` query API + AdminRouter endpoint (ENH-021). All 4 cerebrio-sapience P0 blockers cleared.
- **2026-04-20**: Phase 8 complete — v0.9.0, 1037 tests, 94% coverage, zero breaking changes. AI-Era Primitives: TrustGateEvaluator (5th evaluator, chain-aware trust scopes), OperationChainConfig (action-pattern evaluator routing), ActorType extension (ROBOT, EDGE_DEVICE), EvaluatorPort.evaluator_type abstract property.
- **2026-04-19**: Phase 7 complete — v0.8.0, 959 tests, 94% coverage, zero breaking changes. Consumer Integration: Guard.from_config() factory, PolicyAdmin SDK, AdminRouter REST API, DB tooling + CLI, full async architecture (AsyncGuard + async stores + AsyncReBACEvaluator). Resolves FEAT-011.
- **2026-04-19**: Phase 6 complete — v0.7.0, 806 tests, 97% coverage, zero breaking changes. RBAC sessions (ENH-001), prompt-injection policy isolation (FEAT-010), CAEP-style push revocation (ENH-010). ADR-0006, ADR-0007, ADR-0008.
- **2026-04-19**: Phase 6 scoped — Production Hardening (ENH-001 RBAC sessions, FEAT-010 policy isolation, ENH-010 push revocation). Original Phase 6 (External Adapters & DSL) replaced entirely — external adapters dropped (build our own), DSL dropped (tenants use console UI). Management APIs → Phase 7, Service Mode + SDKs → Phase 8.
- **2026-04-19**: Phase 5 complete — v0.6.0, 718 tests, 97% coverage, zero breaking changes.
- **2026-04-17**: Roadmap rewritten. Original Phase 3 (Policy Engine + External Adapters) split: agentic reframe produced three focused phases (3 Core Contract, 4 Integration Surface, 5 Delegation & Bounds). Original DSL/adapters deferred to unscheduled Phase 6.
