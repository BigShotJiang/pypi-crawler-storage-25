# Phase 5 — Delegation & Bounds: Retrospective

> **Completed**: 2026-04-19
> **Version**: v0.6.0
> **Tests**: 718 (+213 from Phase 4 baseline of 505)
> **Coverage**: 97%
> **Breaking changes**: None

---

## What Was Delivered

- **Delegation entities**: `Delegation`, `DelegationScope`, `DelegationStatus` with SHA-256 idempotency hash and CAS-safe counter validation
- **Phase 5 exceptions**: `DelegateNotPermittedError`, `UsageExhaustedError`, `LeaseExpiredError`, `DelegationRevokedError`, `DelegationNotFoundError`, `DelegationChainDepthExceededError`
- **Storage layer**: `DelegationStorePort` ABC, `InMemoryDelegationStore` (RLock CAS), `SQLAlchemyDelegationStore` (UPDATE WHERE CAS)
- **Service layer**: `DelegationManager` (delegate/revoke/renew/consume/expire_stale) + `DelegationEvaluator` (scope match + dynamic re-check + memoization)
- **Guard integration**: `Guard.delegate`, `revoke_delegation`, `renew_delegation`, `consume_delegation`, `authorize_and_consume`; delegation path parallel to policy path; `_skip_delegation` recursion guard
- **SelfDelegateOnly meta-authz**: `default_delegate_policy="self_only"` built-in (callers can only delegate their own permissions); overridable with explicit policy
- **`Policy.non_delegable` flag**: prevents downstream re-delegation of sensitive permissions
- **`list_authorized` contribution**: concrete ID scopes surface additional resources without consuming any usage
- **MCP budget helper**: `MCPAuthorizationResult.attributed_delegation_ids` + `MCPGuard.consume_tool_call_budget`
- **ADRs**: ADR-0003 (entity + API shape), ADR-0004 (evaluator + meta-authz), ADR-0005 (bounds: usage + budget + lease)
- **Integration guide**: full Phase 5 section with executable mirrors in `test_integration_guide_examples.py`

---

## What Went Well

### Design clarity before implementation
The brainstorm session that produced `overview.md` and `plan.md` eliminated all major design questions upfront. By the time T1 started, entity shapes, CAS semantics, `_skip_delegation` recursion guard, SelfDelegateOnly policy, and narrowing check were all decided. Zero scope creep during implementation.

### CAS counter approach
Using `RLock` in memory and `UPDATE ... WHERE uses_remaining >= :amount` in SQL was the right call. Both stores share an identical failure contract (`UsageExhaustedError` on race loss), making the upper services unaware of which backend is in use. The concurrent race tests (10 threads → 3 succeed) passed first try.

### Circular import avoidance via duck typing
Using `Any` for the `guard` parameter in `DelegationManager` and `DelegationEvaluator` completely avoided circular-import complexity while keeping the design correct. The `_skip_delegation` flag prevents recursion without requiring type-level coupling.

### Test structure
Separating unit tests (T1-T12) from integration tests (T13-T15) and guide mirrors (T17) made each layer independently verifiable. The cascade revocation tests and non-delegable semantics tests caught two subtle bugs in the interaction between `re_check_on_use` and `non_delegable_policy`.

### Zero breaking changes
All 505 Phase 4 tests passed unchanged. The delegation path is strictly additive — it only activates when `delegation_store` is wired into `Guard`. Consumers without delegation see identical behavior.

---

## What Didn't Go Well

### Ruff/mypy cleanup at the end
33 ruff violations and 6 mypy errors were discovered in a batch at the lint step, rather than incrementally. E501 line-length violations were the most numerous (multi-line expressions in SQL raw text, Field descriptions). SIM102/103/114 were stylistic but required careful manual rewrites to avoid logic changes. Running `ruff check --fix` earlier per-file would have caught these sooner.

### `non_delegable_policy` propagation path
The path from `Policy.non_delegable` → `Decision.non_delegable_policy` → `DelegationEvaluator._grantor_still_permitted` required reading three files to understand. It works correctly, but the attribute is set via `getattr` with a default (duck-typed from guard internals) rather than a typed field on `Decision`. This is a known limitation documented in ADR-0004.

### SQL WAL / concurrent test reliability
The SQLite concurrent `decrement_uses` test (10 threads, max_uses=3 → exactly 3 succeed) had a minor reliability risk because SQLite in WAL mode can return SQLITE_BUSY under high contention. The test passes reliably with `check_same_thread=False` + serialized writes through SQLAlchemy's connection pool, but would benefit from a PostgreSQL-based CI integration test for production validation.

---

## Lessons Learned

1. **Decide recursion guards before writing any re-check logic.** The `_skip_delegation` flag needed to be designed before T7 (DelegationEvaluator) was written — retrofitting it after would have required touching more files.

2. **Write lint/type checks incrementally, not at phase end.** With 20 tasks and ~2000 lines of new code, a single batch lint pass at the end is error-prone and slow.

3. **`list_authorized` consuming nothing is a correctness invariant, not just a nicety.** The test `uses_remaining still 5 after 1000 candidates` is the most important behavioral guarantee of the whole system — a RAG filter query must never mutate authorization state.

4. **The `attributed_delegation_ids` design (T12) was cleaner than alternatives.** Carrying delegation IDs in the result object rather than having `consume_tool_call_budget` re-query the store avoided an extra store round-trip and kept the MCP layer stateless.

5. **Phase 5 was the most complex phase by surface area but not by architectural novelty.** Phases 3-4 established the patterns (duck-typed guard, `_skip_` flags, port/adapter hexagonal pattern); Phase 5 composed them at scale. The complexity came from correctness under concurrency, not from new architectural ideas.
