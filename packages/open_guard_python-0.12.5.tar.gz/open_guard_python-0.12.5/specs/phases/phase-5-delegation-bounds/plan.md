# Phase 5 — Delegation & Bounds: Implementation Plan

> **Status**: In Progress
> **Version Target**: v0.6.0
> **TDD discipline**: Every task writes failing tests first, then implementation, then commit. Full suite green + lint + mypy clean on each commit.

## Workflow

1. Create `phase-5-delegation-bounds` branch from `main` at phase start.
2. For each task: red (failing tests), green (implementation), refactor, full suite + lint + mypy, commit with conventional message.
3. ADRs (T18) and integration guide (T17) follow implementation so prior-art citation reflects the shipped design.
4. Final task (T20) bumps version + public API + release notes and opens the release PR.

## Task List

### T1 — Entities: `Delegation`, `DelegationScope`, `DelegationStatus`

Add frozen Pydantic entities to `src/open_guard/domain/entities.py`.

**Failing tests first** (`tests/unit/domain/test_delegation_entities.py`):
- `DelegationScope` roundtrip with `action_match` (str and list), `resource_type`, `resource_match`, `conditions`.
- `Delegation` construction with all optional fields None — valid.
- `Delegation` with `max_uses=5` requires `uses_remaining=5` on create (manager sets it; entity validator enforces `uses_remaining <= max_uses` when both set).
- `Delegation` with `budget=Decimal("10.00")` requires `budget_remaining=Decimal("10.00")`.
- `Delegation` frozen — mutation raises.
- `DelegationStatus` enum values: `PENDING_APPROVAL`, `ACTIVE`, `REVOKED`, `EXPIRED`, `EXHAUSTED`.
- `Delegation.make_hash(...)` deterministic across instances with same canonical args; differs when any component differs.

**Implementation sketch:**

```python
# src/open_guard/domain/entities.py (additions)

class DelegationStatus(StrEnum):
    PENDING_APPROVAL = "pending_approval"
    ACTIVE = "active"
    REVOKED = "revoked"
    EXPIRED = "expired"
    EXHAUSTED = "exhausted"


class DelegationScope(Entity):
    """A single (action, resource_type, match) tuple within a delegation.

    OR across scopes on a Delegation; AND within resource_match/conditions.
    """
    model_config = ConfigDict(frozen=True)
    action_match: str | list[str] = Field(..., description="Action name(s), supports glob")
    resource_type: str = Field(..., description="Resource type this scope targets")
    resource_match: dict[str, Any] = Field(
        default_factory=dict,
        description="ABAC-style match conditions on the resource",
    )
    conditions: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional ABAC conditions (chain.*, params.*, etc.)",
    )

    @classmethod
    def from_policy(cls, policy: Policy) -> DelegationScope:
        """Extract a scope from an existing policy for convenience."""
        action_match = policy.action_match
        resource_type = policy.resource_match.get("type") or policy.resource_match.get("resource_type")
        if not isinstance(resource_type, str):
            raise ValueError(
                "Policy must have resource_match.type (or .resource_type) set to derive a DelegationScope"
            )
        return cls(
            action_match=action_match,
            resource_type=resource_type,
            resource_match={k: v for k, v in policy.resource_match.items() if k not in {"type", "resource_type"}},
            conditions=dict(policy.conditions),
        )


class Delegation(Entity):
    """A bounded permission grant from one subject to another.

    Phase 5 (FEAT-001 + FEAT-002 + FEAT-003).
    Operational state, separate from Policy rules.
    """
    model_config = ConfigDict(frozen=True)

    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str = Field(..., description="Tenant scope")
    from_subject_id: str = Field(..., description="Grantor subject id")
    from_subject_type: ActorType = Field(..., description="Grantor actor type")
    to_subject_id: str = Field(..., description="Grantee subject id")
    to_subject_type: ActorType = Field(..., description="Grantee actor type")
    scopes: list[DelegationScope] = Field(..., min_length=1, description="OR across scopes")
    parent_delegation_id: str | None = Field(default=None, description="For chains")

    # FEAT-002 — usage / budget
    max_uses: int | None = Field(default=None, ge=1)
    uses_remaining: int | None = Field(default=None, ge=0)
    budget: Decimal | None = Field(default=None)
    budget_remaining: Decimal | None = Field(default=None)

    # FEAT-003 — lease
    lease_ttl: timedelta | None = Field(default=None)
    last_heartbeat_at: datetime | None = Field(default=None)
    renewable_by: list[str] | None = Field(default=None)

    # Absolute expiry (immutable post-creation)
    expires_at: datetime | None = Field(default=None)

    # Opt-out for dynamic re-check at authorize time
    re_check_on_use: bool = Field(default=True)

    status: DelegationStatus = Field(default=DelegationStatus.ACTIVE)
    approval_request_id: str | None = Field(default=None)
    request_hash: str = Field(..., description="SHA-256 of canonical args — idempotency key")

    created_at: datetime = Field(...)
    created_by: str = Field(..., description="Subject id who called guard.delegate()")
    reason: str | None = Field(default=None)

    @model_validator(mode="after")
    def _check_counter_initial_state(self) -> Delegation:
        if self.max_uses is not None and self.uses_remaining is None:
            raise ValueError("uses_remaining required when max_uses is set")
        if self.max_uses is not None and self.uses_remaining is not None:
            if self.uses_remaining > self.max_uses:
                raise ValueError("uses_remaining cannot exceed max_uses")
        if self.budget is not None and self.budget_remaining is None:
            raise ValueError("budget_remaining required when budget is set")
        if self.budget is not None and self.budget_remaining is not None:
            if self.budget_remaining > self.budget:
                raise ValueError("budget_remaining cannot exceed budget")
        return self

    @staticmethod
    def make_hash(
        tenant_id: str,
        from_subject_id: str,
        to_subject_id: str,
        scopes: list[DelegationScope],
        parent_delegation_id: str | None,
        max_uses: int | None,
        budget: Decimal | None,
        lease_ttl: timedelta | None,
        expires_at: datetime | None,
    ) -> str:
        """Deterministic SHA-256 over canonical args. Mirrors ApprovalRequest.make_hash."""
        canonical_scopes = json.dumps(
            [s.model_dump(mode="json") for s in scopes],
            sort_keys=True,
            separators=(",", ":"),
        )
        parts = [
            tenant_id,
            from_subject_id,
            to_subject_id,
            canonical_scopes,
            parent_delegation_id or "",
            str(max_uses or ""),
            str(budget) if budget is not None else "",
            str(lease_ttl.total_seconds()) if lease_ttl else "",
            expires_at.isoformat() if expires_at else "",
        ]
        return hashlib.sha256("|".join(parts).encode("utf-8")).hexdigest()
```

**Commit**: `feat(domain): add Delegation, DelegationScope, DelegationStatus entities (Phase 5 T1)`

---

### T2 — Phase 5 exceptions

Add to `src/open_guard/domain/exceptions.py`:

```python
class DelegateNotPermittedError(Exception):
    """Raised when caller cannot create/revoke/renew a delegation."""

class UsageExhaustedError(Exception):
    """Raised when consume_delegation would take counter below zero."""

class LeaseExpiredError(Exception):
    """Raised when renewing an already-expired delegation."""

class DelegationRevokedError(Exception):
    """Raised when operating on a revoked delegation."""

class DelegationNotFoundError(Exception):
    """Raised when a delegation id does not exist."""

class DelegationChainDepthExceededError(Exception):
    """Raised when parent_delegation_id chain exceeds max_delegation_depth."""
```

**Failing tests**: construction, str repr, inheritance from Exception.

**Commit**: `feat(domain): add Phase 5 delegation exceptions (T2)`

---

### T3 — `DelegationStorePort` abstract interface

`src/open_guard/domain/ports/delegation_store.py`:

```python
class DelegationStorePort(ABC):
    """Operational store for Delegation entities. Not a policy store."""

    @abstractmethod
    def create(self, delegation: Delegation) -> Delegation: ...

    @abstractmethod
    def get(self, delegation_id: str, tenant_id: str) -> Delegation | None: ...

    @abstractmethod
    def find_by_hash(self, request_hash: str, tenant_id: str) -> Delegation | None: ...

    @abstractmethod
    def list_active_for_grantee(
        self,
        to_subject_id: str,
        tenant_id: str,
        resource_type: str | None = None,
    ) -> list[Delegation]: ...

    @abstractmethod
    def list_descendants(
        self, parent_delegation_id: str, tenant_id: str
    ) -> list[Delegation]:
        """All delegations with parent_delegation_id directly or transitively."""

    @abstractmethod
    def update_status(
        self, delegation_id: str, tenant_id: str, status: DelegationStatus
    ) -> Delegation: ...

    @abstractmethod
    def decrement_uses(
        self, delegation_id: str, tenant_id: str, amount: int
    ) -> Delegation:
        """CAS: atomic decrement; raise UsageExhaustedError if remaining < amount."""

    @abstractmethod
    def decrement_budget(
        self, delegation_id: str, tenant_id: str, cost: Decimal
    ) -> Delegation:
        """CAS: atomic decrement; raise UsageExhaustedError if remaining < cost."""

    @abstractmethod
    def touch_heartbeat(
        self, delegation_id: str, tenant_id: str, now: datetime
    ) -> Delegation: ...

    @abstractmethod
    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Transition statuses past effective_expiry to EXPIRED. Returns count."""
```

**Failing tests**: import-only contract test — `DelegationStorePort` is ABC, concrete methods raise TypeError on instantiation.

**Commit**: `feat(domain): add DelegationStorePort abstract interface (T3)`

---

### T4 — `InMemoryDelegationStore` with CAS-safe decrement

`src/open_guard/adapters/stores/memory_delegation.py`:

```python
class InMemoryDelegationStore(DelegationStorePort):
    def __init__(self) -> None:
        self._by_id: dict[tuple[str, str], Delegation] = {}  # (tenant, id) -> Delegation
        self._by_hash: dict[tuple[str, str], str] = {}       # (tenant, hash) -> id
        self._lock = threading.RLock()

    def decrement_uses(self, delegation_id, tenant_id, amount):
        with self._lock:
            d = self._by_id.get((tenant_id, delegation_id))
            if d is None:
                raise DelegationNotFoundError(...)
            if d.uses_remaining is None:
                return d  # no counter — idempotent no-op
            if d.uses_remaining < amount:
                raise UsageExhaustedError(...)
            new_remaining = d.uses_remaining - amount
            new_status = DelegationStatus.EXHAUSTED if new_remaining == 0 and (d.budget_remaining is None or d.budget_remaining == 0) else d.status
            updated = d.model_copy(update={"uses_remaining": new_remaining, "status": new_status})
            self._by_id[(tenant_id, delegation_id)] = updated
            return updated

    # ... other methods follow same lock-protected pattern
```

**Failing tests** (`tests/unit/adapters/stores/test_memory_delegation.py`):
- Create + get roundtrip; find_by_hash idempotency.
- `list_active_for_grantee` filters by subject + optional resource_type.
- `list_descendants` walks tree transitively.
- `decrement_uses`: 10 concurrent threads on `max_uses=3` → exactly 3 succeed, 7 raise `UsageExhaustedError`; final `uses_remaining == 0`; status transitioned to EXHAUSTED.
- `decrement_budget`: same story with Decimal cost.
- `touch_heartbeat` updates `last_heartbeat_at`.
- `expire_stale` transitions lease-expired delegations to EXPIRED.

**Commit**: `feat(stores): add InMemoryDelegationStore with CAS-safe counters (T4)`

---

### T5 — `SQLAlchemyDelegationStore` with CAS-safe decrement

Add `open_guard_delegations` + `open_guard_delegation_scopes` tables to `src/open_guard/adapters/stores/sql_models.py`. Build `SQLAlchemyDelegationStore` in `src/open_guard/adapters/stores/sql_delegation.py` (under `[sql]` extra).

**Key detail — CAS via `UPDATE ... WHERE`:**

```python
def decrement_uses(self, delegation_id, tenant_id, amount):
    with self._engine.begin() as conn:
        result = conn.execute(
            sa.text("""
                UPDATE open_guard_delegations
                SET uses_remaining = uses_remaining - :amount,
                    status = CASE
                        WHEN uses_remaining - :amount = 0 AND (budget_remaining IS NULL OR budget_remaining = 0)
                        THEN 'exhausted' ELSE status
                    END
                WHERE id = :id AND tenant_id = :tenant AND uses_remaining >= :amount
                RETURNING *
            """),
            {"id": delegation_id, "tenant": tenant_id, "amount": amount},
        )
        row = result.fetchone()
        if row is None:
            # Either not found or would go below zero — distinguish
            existing = self.get(delegation_id, tenant_id)
            if existing is None:
                raise DelegationNotFoundError(...)
            raise UsageExhaustedError(...)
        return self._row_to_delegation(row)
```

**Failing tests** (`tests/unit/adapters/stores/test_sql_delegation.py`):
- SQLite roundtrip, create_tables + from_url pattern.
- CAS behavior under concurrent session decrement (use `concurrent.futures.ThreadPoolExecutor` with SQLite WAL mode or PostgreSQL test container — follow Phase 2 pattern).
- FK cascade: delegation row delete also drops `open_guard_delegation_scopes` rows.
- Row round-trip: `JSON` columns for `resource_match` / `conditions` / `scopes`.
- Migration exportability: `create_tables()` + `metadata` usable by consumer-managed Alembic.

**Commit**: `feat(stores): add SQLAlchemyDelegationStore with CAS-safe counters (T5)`

---

### T6 — `DelegationManager` service (delegate / revoke / renew / consume)

`src/open_guard/domain/services/delegation_manager.py`:

```python
class DelegationManager:
    """Create, revoke, renew, consume delegations. Mirrors ApprovalManager shape."""

    def __init__(
        self,
        delegation_store: DelegationStorePort,
        guard: Guard,  # for static narrowing check
        approval_store: ApprovalStorePort | None = None,
        clock: Callable[[], datetime] | None = None,
        max_delegation_depth: int = 10,
    ): ...

    def delegate(
        self,
        *,
        caller: Subject,
        from_subject: Subject,
        to_subject: Subject,
        scopes: list[DelegationScope],
        tenant_id: str,
        parent_delegation_id: str | None = None,
        max_uses: int | None = None,
        budget: Decimal | None = None,
        lease_ttl: timedelta | None = None,
        expires_at: datetime | None = None,
        renewable_by: list[str] | None = None,
        re_check_on_use: bool = True,
        requires_approval: ApprovalRequirement | None = None,
        reason: str | None = None,
    ) -> Delegation:
        # 1. Meta-authz: guard.authorize(caller, "delegate", Resource(type="permission", ...))
        # 2. Chain depth check (walk parent_delegation_id)
        # 3. Hash + find_by_hash (idempotency)
        # 4. Static narrowing: for each scope, run guard.authorize(from_subject, scope.action, synthetic_resource) with _skip_delegation=True — at least one scope must be grantable
        # 5. If requires_approval: create PENDING_APPROVAL Delegation + ApprovalRequest via ApprovalManager; return PENDING_APPROVAL delegation
        # 6. Else: create ACTIVE Delegation with uses_remaining=max_uses, budget_remaining=budget, last_heartbeat_at=now (if lease_ttl set)
        # 7. Return Delegation
        ...

    def revoke(self, delegation_id: str, caller: Subject, tenant_id: str) -> Delegation:
        # 1. Meta-authz: guard.authorize(caller, "revoke_delegation", Resource(type="delegation", ...))
        # 2. Update self + all descendants to REVOKED (synchronous cascade)
        ...

    def renew(self, delegation_id: str, caller: Subject, tenant_id: str) -> Delegation:
        # 1. Load delegation; if EXPIRED already → raise LeaseExpiredError
        # 2. Check caller.id in renewable_by (default [to_subject_id])
        # 3. touch_heartbeat(now)
        ...

    def consume(
        self, delegation_id: str, tenant_id: str, amount: int = 1, cost: Decimal | None = None
    ) -> Delegation:
        # 1. If max_uses set: decrement_uses(amount)
        # 2. If budget set: decrement_budget(cost)
        # 3. Return updated Delegation
        ...

    def on_approval_resolved(self, approval_request_id: str, tenant_id: str) -> Delegation | None:
        """Hook to transition PENDING_APPROVAL → ACTIVE when ApprovalManager resolves.
        Starts lease countdown (sets last_heartbeat_at) at this moment."""
        ...

    def expire_stale(self, tenant_id: str) -> int:
        """Eager sweep for operators. Otherwise lazy expiry at read."""
        return self._store.expire_stale(tenant_id, self._clock())
```

**Failing tests** (`tests/unit/domain/services/test_delegation_manager.py`):
- Basic delegate + idempotent create (same hash returns same Delegation).
- Meta-authz refusal → `DelegateNotPermittedError` (mock guard.authorize to return DENIED).
- Chain depth: delegate with 10-deep parent chain → success; 11-deep → `DelegationChainDepthExceededError`.
- Static narrowing: from_subject lacks permission → `DelegateNotPermittedError`.
- Pending approval: `requires_approval` creates PENDING_APPROVAL + ApprovalRequest; `on_approval_resolved` transitions to ACTIVE with heartbeat set.
- Revoke cascade: 3-level chain, revoke root, all three marked REVOKED.
- Renew: caller in `renewable_by` succeeds; caller not in list raises.
- Renew of EXPIRED → `LeaseExpiredError`.
- Consume: usage decrement + budget decrement; UsageExhaustedError propagates.

**Commit**: `feat(services): add DelegationManager (delegate/revoke/renew/consume) (T6)`

---

### T7 — `DelegationEvaluator` service (match + dynamic re-check + memoization)

`src/open_guard/domain/services/delegation_evaluator.py`:

```python
class DelegationEvaluator:
    """Evaluate delegations against an AuthorizationRequest.

    Not an EvaluatorPort impl — delegations are operational state, not Policy rules.
    Produces Evaluation entities so it composes into Decision.evaluations identically.
    """

    def __init__(
        self,
        delegation_store: DelegationStorePort,
        guard: Guard,  # for dynamic re-check
        clock: Callable[[], datetime] | None = None,
        policy_store: PolicyStorePort | None = None,
    ): ...

    def evaluate(
        self,
        request: AuthorizationRequest,
        *,
        recheck_cache: dict[tuple[str, str, str, str], bool] | None = None,
    ) -> Evaluation:
        """Return ALLOWED iff an active, non-expired, non-exhausted delegation covers
        (action, resource) AND (when re_check_on_use) from_subject currently has the
        permission via non-delegation evaluators.
        """
        # 1. Load active delegations for subject + resource_type
        # 2. For each delegation:
        #    a. Check status == ACTIVE, not expired (effective_expiry)
        #    b. For each scope: action_match + resource_match + conditions → match?
        #    c. If re_check_on_use: call guard.authorize(from_subject, action, resource, _skip_delegation=True)
        #       Memoize by (tenant, from_subject_id, action.name, resource.id).
        #       Also check non_delegable: scan matched policies for non_delegable=True → fail re-check.
        #    d. First passing delegation → ALLOWED Evaluation with matched_policies_detail
        # 3. If no delegation passes → NOT_APPLICABLE (allowed=False, matched_policies=[])

    def list_contribution(
        self,
        request: ListRequest,
        *,
        limit: int,
    ) -> list[str]:
        """Emit concrete IDs from scopes with id: {op: eq/in}. Pattern scopes yield none."""
        ...
```

**Non-delegable check within dynamic re-check:**
The inner `guard.authorize(..., _skip_delegation=True)` returns a `Decision`. For non-delegable to work, the evaluator inspects matched ALLOW policies — if any carry `non_delegable=True`, the re-check fails (that policy cannot satisfy delegation transfer).

```python
def _passes_recheck(self, from_subject, action, resource, tenant_id, ctx) -> bool:
    decision = self._guard.authorize(
        from_subject, action, resource, tenant_id, ctx, _skip_delegation=True
    )
    if decision.status != DecisionStatus.ALLOWED:
        return False
    # All ALLOW policies must be delegable
    matched_ids = {p for ev in decision.evaluations if ev.allowed for p in ev.matched_policies}
    policies = self._policy_store.get_by_tenant(tenant_id)
    for p in policies:
        if p.id in matched_ids and p.effect == PolicyEffect.ALLOW and p.non_delegable:
            return False
    return True
```

**Failing tests** (`tests/unit/domain/services/test_delegation_evaluator.py`):
- No active delegations → Evaluation(allowed=False).
- Active delegation matching action + resource → Evaluation(allowed=True, matched_policies=[delegation.id]).
- Scope with `resource_match={"id": {"op": "eq", "value": "doc-1"}}` matches resource.id="doc-1"; not "doc-2".
- Expired delegation (lease_expired or expires_at past) → Evaluation(allowed=False).
- Revoked delegation → Evaluation(allowed=False).
- Exhausted delegation (uses_remaining=0) → Evaluation(allowed=False).
- `re_check_on_use=True` + parent lost permission → Evaluation(allowed=False).
- `re_check_on_use=False` + parent lost permission → Evaluation(allowed=True) (opt-out).
- Non-delegable policy → re-check fails even if from_subject has the permission directly.
- Memoization: 10 authorize calls for same (subject, action, resource) → guard.authorize (inner) called once.
- Chain `A -> B -> C`: C's request re-checks B's permission (immediate parent), which recursively re-checks A.

**Commit**: `feat(services): add DelegationEvaluator (match + dynamic re-check + memo) (T7)`

---

### T8 — Wire `DelegationEvaluator` into `Guard`

Modify `src/open_guard/domain/services/guard.py`:

```python
class Guard:
    def __init__(
        self,
        ...,
        delegation_store: DelegationStorePort | None = None,
        delegation_evaluator: DelegationEvaluator | None = None,
        max_delegation_depth: int = 10,
        default_delegate_policy: Policy | Literal["self_only"] | None = "self_only",
    ) -> None:
        ...
        self._delegation_store = delegation_store
        self._delegation_eval = delegation_evaluator
        self._max_delegation_depth = max_delegation_depth
        self._default_delegate_policy = self._resolve_default_delegate_policy(default_delegate_policy)

    def authorize(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
        *,
        _skip_delegation: bool = False,   # internal flag — breaks delegation recursion
        _recheck_cache: dict | None = None,
    ) -> Decision:
        ...
        policy_decision = self._evaluate_with_approval(request)
        if _skip_delegation or self._delegation_eval is None:
            return policy_decision
        if policy_decision.status == DecisionStatus.ALLOWED:
            return policy_decision  # short-circuit — already allowed via policy
        delegation_eval = self._delegation_eval.evaluate(
            request, recheck_cache=_recheck_cache or {}
        )
        if delegation_eval.allowed:
            merged_evals = [*policy_decision.evaluations, delegation_eval]
            return Decision(
                status=DecisionStatus.ALLOWED,
                reason="Allowed by delegation",
                evaluations=merged_evals,
            )
        return policy_decision  # unchanged
```

**Evaluation order rationale**: policy path first so zero-delegation deployments pay nothing. Only when policy path fails do we check delegations. If policy ALLOWED, we skip delegation (no ambiguity about how we were allowed — an `EvaluatorTrace` still records both paths via `authorize_traced`).

**Deny precedence**: a DENY from policy path still wins because we short-circuit on policy DENY (existing `_apply_approval_gate` semantics). Delegations can only rescue from "no matching allow"; they cannot override an explicit DENY. This is the correct Q8 semantics for `non_delegable` at the policy layer.

**New `Guard` methods:**
- `delegate(...)` → `self._delegation_mgr.delegate(...)`
- `revoke_delegation(...)` → `self._delegation_mgr.revoke(...)`
- `renew_delegation(...)` → `self._delegation_mgr.renew(...)`
- `consume_delegation(delegation_id, amount=1, cost=None)` → `self._delegation_mgr.consume(...)`
- `authorize_and_consume(subject, action, resource, tenant_id, ...)` → call `authorize()`, if ALLOWED via delegation, call `consume()` atomically, return `(Decision, list[ConsumedDelegation])`.

**Failing tests** (`tests/unit/domain/services/test_guard_delegate.py`):
- Guard without delegation wiring → all authorize behavior unchanged (regression).
- Guard with delegation wiring, policy-allowed → policy path wins (delegation evaluator not consulted).
- Guard with delegation wiring, policy-denied but delegation-allowed → Decision.status=ALLOWED, last Evaluation is the delegation.
- Guard with policy-denied and delegation-denied → Decision.status=DENIED.
- `_skip_delegation=True` → delegation never consulted (used by manager for static narrowing).
- `authorize_and_consume` consumes exactly one use when allowed via delegation.
- `authorize_and_consume` consumes nothing on DENY.
- `authorize_and_consume` consumes nothing when allowed via policy (no delegation attributed).
- `Guard.delegate`, `revoke_delegation`, `renew_delegation` proxy to manager correctly.

**Commit**: `feat(services): wire DelegationEvaluator into Guard + Guard.delegate/revoke/renew/consume (T8)`

---

### T9 — `non_delegable` flag on `Policy`

Modify `src/open_guard/domain/entities.py` `Policy`:

```python
class Policy(Entity):
    ...
    non_delegable: bool = Field(
        default=False,
        description=(
            "Phase 5 (FEAT-001): when True, this policy's ALLOW still applies "
            "to the direct subject but cannot satisfy the dynamic delegation "
            "re-check — i.e., the subject cannot delegate this permission."
        ),
    )
```

**Failing tests**: round-trip Pydantic dump/load; default False; `DelegationEvaluator` honors it (covered in T7 test suite — here just the entity + default).

**Commit**: `feat(domain): Policy.non_delegable flag for non-delegable permissions (T9)`

---

### T10 — Meta-authz default: `SelfDelegateOnly` built-in policy

Helper on `Guard` that synthesizes a built-in ABAC policy:

```python
def _resolve_default_delegate_policy(self, spec):
    if spec is None:
        return None
    if spec == "self_only":
        return Policy(
            tenant_id="*",  # applied across tenants internally
            evaluator_type="abac",
            action_match=["delegate", "revoke_delegation", "renew_delegation"],
            resource_match={"type": "permission"},
            conditions={
                "resource.attributes.from": {"op": "eq", "value": "${subject.id}"},
                # templated — expanded by a tiny resolver at check time
            },
            effect=PolicyEffect.ALLOW,
            priority=0,
        )
    return spec  # custom Policy passed in
```

In practice, the implementation is simpler: `DelegationManager` calls `guard.authorize(caller, "delegate", resource)`; if it returns DENIED AND the default policy spec is `"self_only"` AND `caller.id == from_subject.id`, override to ALLOWED. This avoids templating into the ABAC engine.

**Failing tests** (`tests/unit/domain/services/test_guard_delegate.py` additions):
- Default `self_only`: Alice delegates Alice's perms → allowed.
- Default `self_only`: Alice delegates Bob's perms (caller=Alice, from=Bob) → DelegateNotPermittedError.
- `default_delegate_policy=None`: no explicit delegate policy → DelegateNotPermittedError even for self-delegate.
- Custom `default_delegate_policy=Policy(...)` → evaluator uses the custom policy.

**Commit**: `feat(services): SelfDelegateOnly built-in default delegate policy (T10)`

---

### T11 — `list_authorized` delegation contribution

Modify `Guard.list_authorized` to include delegation-contributed IDs:

```python
def list_authorized(self, ...) -> ListResult:
    ...
    # Existing: candidate source first, ReBAC second
    # NEW (3rd source): delegation-contributed IDs
    if self._delegation_eval is not None and len(allow_ids) < limit:
        # Direct-ID scopes: emit without iteration
        delegation_ids = self._delegation_eval.list_contribution(
            request=ListRequest(...),
            limit=limit - len(allow_ids),
        )
        for obj_id in delegation_ids:
            if obj_id in seen:
                continue
            seen.add(obj_id)
            resource = Resource(id=obj_id, resource_type=resource_type, tenant_id=tenant_id, attributes={"type": resource_type})
            decision = self.authorize(subject, action_obj, resource, tenant_id, ctx)
            if decision.status == DecisionStatus.ALLOWED:
                allow_ids.append(obj_id)
                if len(allow_ids) >= limit:
                    break
    # Pattern-based scopes rely on candidate source + per-candidate authorize — already handled above
```

**Failing tests** (`tests/integration/test_delegation_list_authorized.py`):
- Delegation with concrete ID scope → ID appears in list_authorized output without candidate source.
- Delegation with pattern scope + candidate source → IDs emerge via iterate-per-candidate.
- Exhausted / revoked / expired delegations contribute nothing.
- Cursor stability: second call continues from cursor; no duplicates.
- List never consumes usage — delegation with `max_uses=5` + `list_authorized(limit=1000)` → `uses_remaining` unchanged after call.

**Commit**: `feat(services): Guard.list_authorized includes delegation contributions (T11)`

---

### T12 — MCP `consume_tool_call_budget` helper

Modify `src/open_guard/adapters/mcp/guard.py`:

```python
class MCPGuard:
    ...
    def consume_tool_call_budget(
        self,
        result: MCPAuthorizationResult,
        *,
        cost: Decimal | None = None,
        amount: int = 1,
    ) -> list[ConsumedDelegation]:
        """After a successful tool call, consume any delegation-attributed budget.

        Call this after the consumer has executed the tool successfully.
        Passing the MCPAuthorizationResult lets the helper know which delegation
        (if any) the authorization was attributed to.
        """
        if result.status != "allow":
            return []
        if not result.attributed_delegation_ids:
            return []
        consumed = []
        for did in result.attributed_delegation_ids:
            consumed.append(
                self._guard.consume_delegation(did, amount=amount, cost=cost)
            )
        return consumed
```

Requires `MCPAuthorizationResult.attributed_delegation_ids: list[str]` — populated from `Decision.evaluations` (the delegation evaluator writes its delegation id into `matched_policies`).

**Failing tests** (`tests/unit/adapters/mcp/test_consume_budget.py`):
- Tool call allowed via delegation → `consume_tool_call_budget` decrements budget.
- Tool call allowed via direct policy → helper is a no-op.
- Tool call denied → helper is a no-op.

**Commit**: `feat(mcp): MCPGuard.consume_tool_call_budget helper (T12)`

---

### T13 — Integration test: end-to-end delegation lifecycle

`tests/integration/test_delegation_e2e.py`:
- Alice has `read:document:*` policy → delegates `read:document:invoice-*` with `max_uses=3, lease_ttl=30s` to Bob.
- Bob `authorize("read", "invoice-123")` → ALLOWED; `consume_delegation(...)` → `uses_remaining=2`.
- Clock advances 31s; Bob `authorize(...)` → DENIED (lease expired).
- Bob `renew_delegation(...)`; `authorize(...)` → ALLOWED again; consume → `uses_remaining=1`.
- Consume once more → `uses_remaining=0`, status EXHAUSTED; next authorize → DENIED.
- Alice calls `revoke_delegation(delegation.id)` → status REVOKED (already exhausted → no-op semantically; test the call is accepted).

**Commit**: `test(integration): end-to-end delegation lifecycle (T13)`

---

### T14 — Integration test: cascade revocation + non-delegable

`tests/integration/test_delegation_cascade.py`:
- 3-level chain: root-policy grants Alice `delete:*`; Alice delegates to Bob; Bob delegates to Carol.
- Revoke root delegation → Bob and Carol's delegations both REVOKED; `authorize(Carol, delete, ...)` → DENIED.
- Reset. Alice has `Policy(effect=ALLOW, action_match="delete:*", non_delegable=True)`.
- `Alice.delegate(to=Bob, action="delete:*")` → succeeds (static narrowing: Alice can delete).
- `authorize(Bob, delete, ...)` with re_check → DENIED (non-delegable).
- Same test with `re_check_on_use=False` → ALLOWED (opt-out bypasses non-delegable).

**Commit**: `test(integration): cascade revocation + non-delegable semantics (T14)`

---

### T15 — Integration test: MCP tool-call with delegation + budget

`tests/integration/test_delegation_mcp.py`:
- Agent has no direct policy for `invoke:tool:query_db`.
- User delegates `invoke:tool:query_db` with `budget=Decimal("10.00")` to agent session.
- `mcp_guard.check_tool_call(session, "query_db", {"sql": "SELECT 1"}, server_id="prod")` → ALLOW.
- `mcp_guard.consume_tool_call_budget(result, cost=Decimal("2.50"))` → `budget_remaining=7.50`.
- Repeat until `budget_remaining=0` → next `check_tool_call` → DENY (EXHAUSTED).

**Commit**: `test(integration): MCP tool-call with delegation budget (T15)`

---

### T16 — Public API exports + version bump

Modify `src/open_guard/__init__.py` to export: `Delegation`, `DelegationScope`, `DelegationStatus`, `DelegationStorePort`, `InMemoryDelegationStore`, `DelegationManager`, `DelegationEvaluator`, `DelegateNotPermittedError`, `UsageExhaustedError`, `LeaseExpiredError`, `DelegationRevokedError`, `DelegationNotFoundError`, `DelegationChainDepthExceededError`.

SQL store re-exported from `open_guard.adapters.stores` under `[sql]` extra path.

Bump `pyproject.toml` version to `0.6.0`; `open_guard.__version__ = "0.6.0"`.

**Failing tests**: import regression tests verify every listed symbol is importable.

**Commit**: `chore: v0.6.0 — Phase 5 public API exports`

---

### T17 — Integration guide Phase 5 section + executable mirrors

Append to `specs/architecture/integration-guide.md` a Phase 5 section covering:
1. Delegation basics — push, pull-with-approval, scope narrowing.
2. Cascade revocation semantics.
3. Usage-counted and budget-capped delegations.
4. Heartbeat / lease renewal for long-running agents.
5. `authorize_and_consume` ergonomic helper.
6. MCP tool-call budgets end-to-end.
7. Non-delegable policies — how to lock down sensitive permissions.
8. Composition with Phase 3 OBO chain (orthogonal, opt-in ABAC coupling).

Add matching entries to `tests/integration/test_integration_guide_examples.py` — every snippet is an executable test. Fail if drift.

**Failing tests**: each Phase 5 snippet is a `test_phase5_*` test that exactly mirrors the guide code block.

**Commit**: `docs(integration-guide): Phase 5 section + executable mirrors (T17)`

---

### T18 — ADR-0003, ADR-0004, ADR-0005

Three ADRs. Each follows `specs/decisions/0000-template.md`. Each cites prior art explicitly (mirroring Phase 4's ADR discipline).

- **ADR-0003 — Delegation as first-class entity + unified push/pull API + hash idempotency**. Cites Thomas & Sandhu 1997, RFC 8693, Auth0 Token Vault, Google Zanzibar subject-sets. Documents rejected alternatives (field on Task, policy-subset, scope strings).
- **ADR-0004 — Delegation as parallel evaluator + non-delegable flag + meta-authz via authorize()**. Cites AWS STS AssumeRole (re-check per call), Cerbos bounded sessions. Documents why not EvaluatorPort-impl, why substitution (OAuth impersonation) is unsafe.
- **ADR-0005 — Consumer-driven consumption + lease semantics + CAS safety**. Cites Vault lease semantics, etcd lease decrement, AWS Token Service refresh. Documents why not auto-consume on authorize, why lease ≠ expires_at.

**Commit**: `docs(adr): ADR-0003 + ADR-0004 + ADR-0005 (Phase 5) (T18)`

---

### T19 — Sync docs

Run `/sync-docs` to propagate history-logged changes into `auth-model.md` (Delegation section), `policy-engine.md` (non_delegable flag mention), `backlog.md` (resolve FEAT-001/002/003).

**Commit**: `docs: sync Phase 5 changes to reference specs (T19)`

---

### T20 — Release prep

- Finalize release notes as `CHANGELOG` or release-notes entry for v0.6.0.
- Verify `pytest -v`, `mypy --strict`, `ruff check` all clean.
- Verify coverage ≥ 95% (target 98%).
- Update `specs/status.md` — mark Phase 5 complete.
- Update `specs/planning/roadmap.md` — mark Phase 5 delivered.
- Open release PR.

**Commit**: `release: v0.6.0 — Phase 5 Delegation & Bounds (T20)`

---

## Commit-message template

Follow Conventional Commits:
- `feat(domain|services|stores|mcp): <summary> (T<n>)`
- `test(integration): <summary> (T<n>)`
- `docs(adr|integration-guide): <summary> (T<n>)`
- `chore: <summary>`
- `release: v0.6.0 — Phase 5 <...>`

## Verification before release

Every acceptance criterion (1-32) in `overview.md` has a dedicated test or combination. Before `/complete-phase`:
- Full suite green: `pytest -v` (all ~640 tests, counting new + existing).
- `mypy --strict src/` clean.
- `ruff check src/ tests/` clean.
- Coverage ≥ 95%: `pytest --cov=open_guard --cov-report=term-missing`.
- `pip install -e '.[sql]'` + SQL store tests pass (Python 3.11+).
- `pip install -e '.[mcp]'` + MCP consume-budget tests pass.
- All three ADRs written + `auth-model.md` + integration guide updated.
- Version in `pyproject.toml` and `open_guard.__version__` = `0.6.0`.
