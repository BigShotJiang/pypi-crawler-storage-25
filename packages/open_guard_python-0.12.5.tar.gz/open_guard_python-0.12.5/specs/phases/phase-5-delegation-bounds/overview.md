# Phase 5 — Delegation & Bounds

> **Status**: In Progress
> **Estimated Effort**: 5-6 days (roadmap); likely ~1-2 sessions at Phase 3/4 velocity
> **Depends On**: Phase 4 (Agent Integration Surface) — v0.5.0
> **Version Target**: v0.6.0
> **Breaking Changes**: None (fully additive)

## Goal

Deliver first-class delegation primitives for agent-to-subagent permission handoffs, with **bounded consumption** (usage counts, monetary/token budgets) and **bounded liveness** (heartbeat-based leases for long-running agents). Three tightly-coupled features, one release:

1. **FEAT-001 — Push/pull delegation** (permission handoff with scope narrowing + cascade revocation). A `Delegation` first-class entity. `guard.delegate(from, to, permissions, ...)` is the unified push/pull API — immediate by default, PENDING_APPROVAL when `requires_approval` is set. Static narrowing check at creation; dynamic re-check at each authorize (memoized per request). Cascade revoke walks `parent_delegation_id`.
2. **FEAT-002 — Usage-counted / budget-capped permissions**. Optional `max_uses` and `budget` (Decimal) on `Delegation`. Consumer-driven consumption via `guard.consume_delegation(delegation_id, amount=1, cost=None)`. Ergonomic `guard.authorize_and_consume(...)` helper for the common case. CAS-based concurrency on counter decrement.
3. **FEAT-003 — Heartbeat / lease renewal**. Optional `lease_ttl` + `last_heartbeat_at` on `Delegation`. Rolling TTL renewal bounded by immutable `expires_at` ceiling. Lazy expiry at read (same pattern as `ApprovalRequest.expires_at`). Vault/etcd lease semantics.

Every change is **additive**. All Phase 0-4 tests pass unchanged. `guard.authorize()` stays source-compatible; delegations layer on as a new evaluator type.

FEAT-010 (prompt-injection-resistant policy isolation) is deferred — P2, docs-heavy, least coupled of the four originally-planned items. See roadmap for target phase.

## Theme: Why these three together

- **FEAT-001 without FEAT-002/003** ships delegation with no way to bound it — agents can chain grants that never expire or exhaust. Security gap.
- **FEAT-002 without FEAT-001** has no natural carrier — usage counts on a `Policy` misuse the rule/state split Phase 3 established (`ApprovalStorePort` ≠ `PolicyStorePort`).
- **FEAT-003 without FEAT-001** same — leases on what? A fresh orthogonal "lease" concept would duplicate cascade-revoke and auth-bound surface.
- Together they form one coherent primitive: *"A grants B a bounded permission."* Shipping as one release avoids opening the `Delegation` shape three times.

## Key Decisions

All locked during the 2026-04-19 brainstorm. Three ADRs to be written in-phase.

| Decision | Choice | Rationale | ADR |
|----------|--------|-----------|-----|
| Delegation representation | First-class `Delegation` entity + dedicated `DelegationStorePort` | Delegations are operational state, not policy rules — Phase 3 `ApprovalStorePort` pattern; mirrors OAuth Token Exchange / Zanzibar / Auth0 Token Vault | ADR-0003 |
| Delegation ↔ OBO chain relationship | Orthogonal — identity chain (Phase 3) and delegation graph (Phase 5) are independent. Coupling available as opt-in ABAC predicate | Tool-call subagents often have no chain wired; conflation would break deployments. Two distinct concerns (provenance vs. permission flow) | ADR-0003 |
| Push vs. pull API shape | Unified `guard.delegate(from, to, permissions, requires_approval=None, ...)` — push when no approval, PENDING_APPROVAL via `ApprovalStorePort` when set | Phase 3 approval machinery already solves idempotency + quorum + TTL; one API, one mental model | ADR-0003 |
| Scope narrowing enforcement | Both: static check at `delegate()` (fail-fast) + dynamic re-check at authorize time (memoized per request) | Static alone leaks permission after parent deprovisioning; dynamic alone has surprise failures at runtime. Both compose safely | ADR-0004 |
| Re-check opt-out | Per-delegation `re_check_on_use: bool = True` flag | High-throughput agent loops may accept static-narrowing tradeoff; default is safe, opt-out is explicit | ADR-0004 |
| Cascade revocation | Synchronous on explicit `guard.revoke_delegation()` — recursive UPDATE via `parent_delegation_id`. Implicit revocation (parent permission loss) discovered at next authorize via dynamic re-check, no background sweeper | Consistent with Phase 3 lazy-expiry pattern; avoids scheduler dependency | ADR-0004 |
| Delegation as evaluator | Parallel `DelegationEvaluator` that produces `Evaluation` entities (composes identically into `Decision.evaluations`). Invoked by `Guard` alongside `PolicyRouter`; **not** an `EvaluatorPort` impl (port contract is policy-based, delegations are operational state) | Preserves "fifth peer" compose semantics (Q8) while respecting the port's policy-list contract | ADR-0004 |
| Non-delegable policies | `Policy.non_delegable: bool = False` flag — policy's ALLOW still applies to direct subject but cannot satisfy dynamic re-check for a delegation | Operators need *"admins may do X, but admins may not delegate X to anyone"* semantics | ADR-0004 |
| Meta-authz (who can delegate) | `guard.authorize(caller, action="delegate", resource=Resource(type="permission", attributes={from, to, scopes}))` — meta-authz via existing authz pipeline | Composes with RBAC/ABAC; admins and self-delegation express via normal policies | ADR-0004 |
| Default delegate policy | Ship a `SelfDelegateOnly` built-in default — permits `action="delegate"` when `resource.attributes.from == subject.id`. Opt-out via `Guard(default_delegate_policy=None)` | 80% case (agents self-delegating to subagents) works without setup; strict operators disable explicitly | ADR-0004 |
| Usage consumption model | Consumer-driven — `guard.consume_delegation(delegation_id, amount, cost)` after successful action. `authorize_and_consume(...)` ergonomic shortcut. `list_authorized` never consumes | Decision ≠ action; Phase 4 RAG-filter enumeration would burn budget otherwise; matches how MCP tool-calls have a natural commit boundary | ADR-0005 |
| Budget type | `budget: Decimal \| None` (currency-unit-agnostic — consumer labels via `metadata`) | Token-cost or $ spend both fit; Decimal avoids float drift | ADR-0005 |
| Consumption race safety | CAS on counter decrement: SQL `UPDATE ... WHERE uses_remaining > 0 RETURNING ...`; in-memory lock. Losing race raises `UsageExhaustedError` | Vault / etcd lease-decrement pattern; deterministic, no silent overage | ADR-0005 |
| Lease representation | Fields on `Delegation` (`lease_ttl`, `last_heartbeat_at`, `renewable_by`), **not** separate `Lease` entity | Leases + absolute deadlines coexist and compose; separate entity would duplicate cascade paths | ADR-0005 |
| Lease expiry mechanism | Lazy at read — `effective_expiry = min(expires_at, last_heartbeat_at + lease_ttl)` checked in `DelegationEvaluator`. Optional `DelegationManager.expire_stale(tenant_id)` sweeper for operators who want eager cleanup | Mirrors `ApprovalManager.expire_stale` pattern; no scheduler dep | ADR-0005 |
| Renewal semantics | `guard.renew_delegation(delegation_id)` sets `last_heartbeat_at = now()`. Rolling TTL, not absolute deadline reset. **Does not extend `expires_at`** (hard ceiling immutable post-creation) | Matches Vault lease renewal; prevents grantor-intent drift | ADR-0005 |
| Renewer authorization | `Delegation.renewable_by: list[str] \| None` — defaults to `[to_subject_id]` when None. Renewal fails closed if caller not in list | Default: delegatee self-heartbeats; configurable for watchdog-pattern renewals | ADR-0005 |
| Lease countdown start | For `requires_approval=...` delegations, lease TTL countdown starts on **approval**, not creation | Otherwise the lease can expire while awaiting approval | ADR-0005 |
| Expiry precedence over usage | A lease-expired or time-expired delegation dies with any remaining uses intact (no "grace-period consumption") | Simpler reasoning; grantor-intent honored | ADR-0005 |
| Delegation's `list_authorized` contribution | For scopes with concrete IDs in `resource_match` (`id: {op: eq}` / `{op: in}`), emit directly. For pattern scopes, fall through to `CandidateResourcePort` + per-candidate `authorize()` (reuses Phase 4 machinery). Memoized with dynamic re-check cache | Zero new port; reuses Phase 4 iterate-per-candidate pattern; composes by construction | ADR-0003 |
| MCP adapter integration | No new `MCPGuard` surface — delegations flow through the existing `Guard.authorize` call. Add one helper: `MCPGuard.consume_tool_call_budget(result, cost)` wrapping `guard.consume_delegation` | Phase 4 seam already routes through `Guard.authorize`; minimal new surface | — |
| Idempotency | SHA-256 of `(tenant_id, from_subject_id, to_subject_id, scopes_canonical, parent_delegation_id, max_uses, budget, lease_ttl, expires_at)` — duplicate `delegate()` returns existing | Mirrors `ApprovalRequest.make_hash` pattern; deterministic retries | ADR-0003 |
| Test / coverage target | ~130-150 new tests; maintain 98% coverage (floor 95%); zero breaking changes; 505 Phase 4 tests pass unchanged | Phase 4 finished at 505/97%; Phase 5 easier surface (no SDK duck-typing) | — |

## Source Structure

```
src/open_guard/
  domain/
    entities.py                       # MODIFY — add Delegation, DelegationScope, DelegationStatus
    exceptions.py                     # MODIFY — add DelegateNotPermittedError, UsageExhaustedError, LeaseExpiredError, DelegationRevokedError, DelegationNotFoundError
    ports/
      delegation_store.py             # NEW — DelegationStorePort abstract interface
    services/
      delegation_manager.py           # NEW — DelegationManager service
      delegation_evaluator.py         # NEW — DelegationEvaluator (parallel evaluator)
      guard.py                        # MODIFY — add delegate(), revoke_delegation(), renew_delegation(), consume_delegation(), authorize_and_consume() methods; wire DelegationEvaluator into evaluate flow; add _skip_delegation internal flag
  adapters/
    stores/
      memory_delegation.py            # NEW — InMemoryDelegationStore with CAS-safe decrement
      sql_delegation.py               # NEW — SQLAlchemyDelegationStore (under [sql] extra)
      sql_models.py                   # MODIFY — add open_guard_delegations, open_guard_delegation_scopes tables
    mcp/
      guard.py                        # MODIFY — add consume_tool_call_budget helper
  __init__.py                         # MODIFY — export Phase 5 public API

specs/
  architecture/
    auth-model.md                     # MODIFY — add Delegation section (synced at phase close)
    integration-guide.md              # MODIFY — add Phase 5 section + executable mirror tests
  decisions/
    0003-delegation-entity-and-api-shape.md   # NEW — entity vs. field, unified API, hash idempotency
    0004-delegation-evaluator-and-meta-authz.md  # NEW — parallel evaluator, non-delegable flag, meta-authz
    0005-delegation-bounds-usage-budget-lease.md # NEW — consumption model, lease semantics, CAS safety

tests/
  unit/
    domain/
      test_delegation_entities.py     # NEW — Delegation, DelegationScope, DelegationStatus
      services/
        test_delegation_manager.py    # NEW — delegate, revoke, renew, consume, expire_stale
        test_delegation_evaluator.py  # NEW — match, dynamic re-check, memoization, non-delegable
        test_guard_delegate.py        # NEW — Guard methods: delegate, revoke, renew, consume, authorize_and_consume
    adapters/
      stores/
        test_memory_delegation.py     # NEW — in-memory store CAS behavior
        test_sql_delegation.py        # NEW — SQL store CAS, FK cascade, migration
      mcp/
        test_consume_budget.py        # NEW — MCPGuard.consume_tool_call_budget helper
  integration/
    test_delegation_e2e.py            # NEW — full flow: delegate -> authorize -> consume -> renew -> expire
    test_delegation_list_authorized.py  # NEW — list_authorized with delegation-only scopes
    test_delegation_cascade.py        # NEW — parent revoke, permission loss cascade, non-delegable
    test_delegation_mcp.py            # NEW — MCP tool-call with budget
    test_integration_guide_examples.py  # MODIFY — add Phase 5 executable mirrors
```

## Scope

### In Scope

**FEAT-001 — Push/pull delegation:**
- `Delegation`, `DelegationScope`, `DelegationStatus` entities (Pydantic, frozen)
- `DelegationStorePort` abstract interface + `InMemoryDelegationStore` + `SQLAlchemyDelegationStore` (under `[sql]` extra)
- `DelegationManager` service — `delegate()`, `revoke()`, `renew()`, `consume()`, `get()`, `list_active()`, `expire_stale()`, idempotent creation via SHA-256 hash
- `DelegationEvaluator` — reads `DelegationStorePort`, produces `Evaluation` entity, composes into `Decision.evaluations`
- `Guard.delegate()`, `Guard.revoke_delegation()`, `Guard.renew_delegation()`, `Guard.consume_delegation()`, `Guard.authorize_and_consume()` methods
- Meta-authz via `authorize("delegate", resource=Resource(type="permission", ...))` with `SelfDelegateOnly` built-in default
- `Policy.non_delegable: bool = False` flag; `DelegationEvaluator` respects it during dynamic re-check
- Static narrowing check at `delegate()` (fail-fast); dynamic re-check at `authorize()` time (memoized per-request via `_skip_delegation` internal flag)
- Cascade revoke on explicit `revoke_delegation()` — recursive `parent_delegation_id` walk, synchronous
- Chain depth cap `max_delegation_depth: int = 10` on `Guard` (matches FEAT-001 spec)
- Delegation's `list_authorized` contribution — direct ID emission for concrete-ID scopes; pattern scopes fall through to `CandidateResourcePort` iteration

**FEAT-002 — Usage & budget:**
- `Delegation.max_uses: int | None`, `Delegation.uses_remaining: int | None`
- `Delegation.budget: Decimal | None`, `Delegation.budget_remaining: Decimal | None`
- `Guard.consume_delegation(delegation_id, amount=1, cost=None)` — CAS-safe decrement
- `Guard.authorize_and_consume(subject, action, resource, ...)` — authorize, then if ALLOWED via a delegation, consume atomically
- `UsageExhaustedError` raised on consume-beyond-zero race
- `list_authorized` never consumes (enumeration ≠ action)
- `InMemoryDelegationStore` uses lock for atomic decrement; `SQLAlchemyDelegationStore` uses `UPDATE ... WHERE ... RETURNING` for CAS semantics

**FEAT-003 — Lease / heartbeat:**
- `Delegation.lease_ttl: timedelta | None`, `Delegation.last_heartbeat_at: datetime | None`
- `Delegation.renewable_by: list[str] | None` — defaults to `[to_subject_id]`
- `Delegation.expires_at: datetime | None` — immutable post-creation, hard ceiling
- `Guard.renew_delegation(delegation_id, caller)` — sets `last_heartbeat_at = now()`; fails closed if caller not in `renewable_by`; does not extend `expires_at`
- `DelegationManager.expire_stale(tenant_id)` — optional eager sweeper; lazy expiry at read is default
- Lease TTL countdown starts on delegation ACTIVE (after approval for `requires_approval=...` delegations)
- `DelegationEvaluator` computes `effective_expiry = min(expires_at, last_heartbeat_at + lease_ttl if both set)`; fail-closed past that
- `LeaseExpiredError` raised on renewal of already-expired delegation

**Integration:**
- MCP adapter — new `MCPGuard.consume_tool_call_budget(result, cost)` helper; documentation pattern for "grant agent $5 across session"
- Integration guide — new Phase 5 section with executable mirrors in `test_integration_guide_examples.py`
- `auth-model.md` updated at phase close via `/sync-docs`

**Documentation:**
- ADR-0003 (entity + API shape + idempotency)
- ADR-0004 (evaluator wiring + non-delegable + meta-authz)
- ADR-0005 (bounds: usage + budget + lease)
- Each ADR cites prior art (Thomas & Sandhu 1997, RFC 8693 OAuth Token Exchange, Vault/etcd lease semantics, Google Zanzibar subject-sets, AWS STS AssumeRole, Cerbos bounded sessions, Auth0 Token Vault)

### Out of Scope (Backlogged)

- **FEAT-010** prompt-injection-resistant policy isolation → deferred to a later phase (P2, docs-heavy, least coupled)
- **ENH-010** CAEP-style revocation push port → revocation stays pull-based (dynamic re-check) in Phase 5
- **ENH-011** subscription API for decision changes → polling only
- **ENH-013** reference `ApprovalDispatcher` impls (Slack / webhook) → remains backlog; Phase 5 doesn't add transport coupling
- Multi-hop delegation performance optimization (batch re-check) → default memoization only; optimization if profiling demands
- Automatic delegation expiry notifications / webhooks → consumer's concern
- Delegation templates or policy-based auto-delegation → explicit `delegate()` calls only
- Cross-tenant delegation → disallowed by construction (both `from` and `to` in same tenant)
- Changing the delegation graph from a tree to a DAG (multiple parents per delegation) → single-parent chain only, matches FEAT-001 spec

## Deliverables

| Deliverable | Verification |
|-------------|-------------|
| `Delegation`, `DelegationScope`, `DelegationStatus` entities | `pytest tests/unit/domain/test_delegation_entities.py -v` |
| Phase 5 exceptions (`UsageExhaustedError`, `LeaseExpiredError`, `DelegationRevokedError`, `DelegateNotPermittedError`, `DelegationNotFoundError`) | `pytest tests/unit -v -k delegation_exceptions` |
| `DelegationStorePort` abstract interface | — (type-check only) |
| `InMemoryDelegationStore` with CAS-safe decrement | `pytest tests/unit/adapters/stores/test_memory_delegation.py -v` |
| `SQLAlchemyDelegationStore` with CAS-safe decrement | `pytest tests/unit/adapters/stores/test_sql_delegation.py -v` |
| `DelegationManager` — delegate/revoke/renew/consume/expire | `pytest tests/unit/domain/services/test_delegation_manager.py -v` |
| `DelegationEvaluator` — match, dynamic re-check, memoization | `pytest tests/unit/domain/services/test_delegation_evaluator.py -v` |
| `Guard.delegate` / `revoke_delegation` / `renew_delegation` / `consume_delegation` / `authorize_and_consume` | `pytest tests/unit/domain/services/test_guard_delegate.py -v` |
| Meta-authz via `authorize("delegate", ...)` + `SelfDelegateOnly` default | `pytest tests/integration/test_delegation_e2e.py -v -k meta_authz` |
| Non-delegable flag honored | `pytest tests/integration/test_delegation_cascade.py -v -k non_delegable` |
| Cascade revocation | `pytest tests/integration/test_delegation_cascade.py -v -k cascade` |
| Lease expiry (lazy, at read) | `pytest tests/integration/test_delegation_e2e.py -v -k lease_expires` |
| Usage/budget exhaustion | `pytest tests/integration/test_delegation_e2e.py -v -k exhausted` |
| Delegation in `list_authorized` | `pytest tests/integration/test_delegation_list_authorized.py -v` |
| MCP tool-call with budget | `pytest tests/integration/test_delegation_mcp.py -v` |
| Integration guide Phase 5 examples executable | `pytest tests/integration/test_integration_guide_examples.py -v -k phase5` |
| ADR-0003 + ADR-0004 + ADR-0005 written | `ls specs/decisions/0003-*.md specs/decisions/0004-*.md specs/decisions/0005-*.md` |
| All 505 Phase 4 tests still pass unchanged | `pytest -v` (all green) |
| Type safety | `mypy --strict src/` (clean) |
| Code quality | `ruff check src/ tests/` (clean) |
| Coverage threshold | `pytest --cov=open_guard --cov-report=term-missing` ≥ 95% (target: maintain 98%) |

## Acceptance Criteria

### FEAT-001 — Delegation

1. `guard.delegate(caller=alice, to=bob_subject, scopes=[DelegationScope(action_match="read", resource_type="document", resource_match={"id": {"op": "eq", "value": "doc-1"}})], tenant_id="t1")` returns an ACTIVE `Delegation` when Alice has the corresponding permission.
2. Static narrowing: `delegate()` raises `DelegateNotPermittedError` when the grantor (`from_subject`) cannot perform the action on any resource matching the scope.
3. Meta-authz: `delegate()` raises `DelegateNotPermittedError` when the caller is not permitted to delegate (`authorize("delegate", ...)` fails).
4. `SelfDelegateOnly` default: Alice can delegate Alice's permissions without any explicit delegate policy.
5. Dynamic re-check: after `delegate(A -> B, read:doc:1)`, revoking A's role makes subsequent `authorize(B, read, doc:1)` return DENIED (when `re_check_on_use=True`, the default).
6. `re_check_on_use=False` skips dynamic re-check — B's delegation survives A's permission loss.
7. Cascade revoke: `revoke_delegation(parent_id)` marks all descendant delegations REVOKED synchronously; subsequent authorize calls return DENIED.
8. Non-delegable: a `Policy(non_delegable=True, effect=ALLOW, action="delete")` lets the direct subject delete but cannot satisfy the dynamic re-check for a delegation claiming `delete`.
9. Pending approval: `delegate(..., requires_approval=ApprovalRequirement(...))` creates a PENDING_APPROVAL delegation; `guard.approve(approval_request_id, ...)` transitions it to ACTIVE; `authorize()` starts succeeding.
10. Idempotency: two `delegate()` calls with the same canonical args (same hash) return the same `Delegation` object.
11. Chain depth: creating a delegation whose `parent_delegation_id` chain exceeds `max_delegation_depth` raises `DelegationChainDepthExceededError`.
12. Orthogonal to OBO chain: a request with `Subject.on_behalf_of=A` where B has a delegation from A authorizes correctly; a request with no chain and B has the delegation also authorizes correctly.

### FEAT-002 — Usage & budget

13. `guard.consume_delegation(delegation_id, amount=1)` decrements `uses_remaining`. When `uses_remaining` reaches 0, status becomes `EXHAUSTED` and subsequent authorize returns DENIED.
14. `guard.consume_delegation(delegation_id, cost=Decimal("0.50"))` decrements `budget_remaining`. When `budget_remaining <= 0`, status becomes `EXHAUSTED`.
15. Race safety: 10 concurrent `consume_delegation` calls on a delegation with `max_uses=3` result in exactly 3 successful consumes and 7 `UsageExhaustedError` raises — no overage.
16. `list_authorized` never consumes — 1000 candidate resources with a `max_uses=5` delegation still returns up to `limit` IDs without exhausting.
17. `guard.authorize_and_consume(subject, action, resource, ...)` returns `(Decision, list[ConsumedDelegation])`. On ALLOWED-via-delegation, the delegation is consumed atomically. On DENIED or ALLOWED-via-non-delegation, nothing is consumed.

### FEAT-003 — Lease / heartbeat

18. `guard.delegate(..., lease_ttl=timedelta(seconds=30))` creates a delegation that fails closed in `authorize()` after `last_heartbeat_at + 30s` has passed.
19. `guard.renew_delegation(delegation_id, caller=bob)` sets `last_heartbeat_at = now()`; the next `authorize()` succeeds.
20. Renewal by non-`renewable_by` caller raises `DelegateNotPermittedError`.
21. `expires_at` is immutable — `renew_delegation()` does not change `expires_at` even if `last_heartbeat_at + lease_ttl > expires_at`. Past `expires_at`, the delegation is dead regardless of heartbeats.
22. Lease countdown for `requires_approval=...` delegations starts at approval time (not creation time).
23. Expiry precedence: a delegation with `uses_remaining=5` that lease-expires is DENIED; the 5 uses are gone.
24. Lazy expiry: an already-expired delegation returns DENIED from `authorize()` without any background job. `DelegationManager.expire_stale(tenant_id)` optionally transitions statuses eagerly.

### Integration

25. MCP: `mcp_guard.check_tool_call(session_id, "expensive_tool", {}, server_id="prod")` against a session where the agent has a delegation with `max_uses=5, budget=Decimal("5.00")` returns ALLOW; `mcp_guard.consume_tool_call_budget(result, cost=Decimal("0.75"))` decrements budget.
26. `list_authorized` composes with delegation — IDs emitted include those covered by active delegations; expired/revoked/exhausted delegations contribute no IDs.
27. Integration guide Phase 5 section is copy-paste runnable; every snippet is an executable test in `test_integration_guide_examples.py`.

### Phase invariants

28. All 505 Phase 4 tests pass unchanged.
29. Coverage ≥ 95% (target 98%), `mypy --strict` clean, `ruff` clean.
30. Version bumped to `0.6.0` in `pyproject.toml` and `open_guard.__version__`.
31. Public API exports (`open_guard/__init__.py`) include: `Delegation`, `DelegationScope`, `DelegationStatus`, `DelegationStorePort`, `InMemoryDelegationStore`, `SQLAlchemyDelegationStore` (under `[sql]`), `DelegationManager`, `DelegationEvaluator`, `DelegateNotPermittedError`, `UsageExhaustedError`, `LeaseExpiredError`, `DelegationRevokedError`, `DelegationNotFoundError`, `DelegationChainDepthExceededError`.
32. ADR-0003, ADR-0004, ADR-0005 follow the `0000-template.md` structure.

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/architecture/auth-model.md` | Phase 0-4 core model — Phase 5 extends with delegation surface |
| `specs/backlog/details/FEAT-001.md` | Delegation detail doc — all five open questions resolved during this brainstorm |
| `specs/phases/phase-3-agentic-core/overview.md` | `ApprovalStorePort` / `ApprovalManager` patterns Phase 5 mirrors |
| `specs/phases/phase-4-agent-integration/overview.md` | `list_authorized` machinery Phase 5 composes with |
| `specs/phases/phase-4-agent-integration/retrospective.md` | Pre-plan codebase-inspection discipline, cite-prior-art ADR pattern, executable doc mirrors |
| Thomas & Sandhu 1997 — *Task-based Authorization Controls (TBAC)* | Foundational push/pull delegation model |
| RFC 8693 — *OAuth 2.0 Token Exchange* | Industry standard for scope-narrowing delegation |
| Google Zanzibar paper — *subject-set indirection* | Prior art on userset-based delegation |
| Vault / etcd lease documentation | Lease semantics + rolling TTL renewal |
| AWS STS AssumeRole | Scope-narrowing at creation + re-check per call pattern |
| Cerbos — *bounded sessions* | Prior art on time-bounded principal capabilities |
| Auth0 Token Vault | 2026-era industry pattern for agent delegation |
