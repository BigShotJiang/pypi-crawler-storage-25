# Phase 5 — Delegation & Bounds: Task Checklist

> Mirrors `plan.md` exactly. Mark tasks `[/]` when in-progress and `[x]` when complete.
> Commit hashes added next to completed tasks as they land.

## Overall

- [x] Phase 5 branch created (`phase-5-delegation-bounds`)
- [x] All tests green (`pytest -v`)
- [x] `mypy --strict` clean
- [x] `ruff check` clean
- [x] Coverage ≥ 95% (target 98%)
- [x] All 505 Phase 4 tests unchanged (regression check)
- [x] Version bumped to v0.6.0 in `pyproject.toml` + `__version__`
- [x] Public API exports updated in `open_guard/__init__.py`
- [x] ADR-0003 + ADR-0004 + ADR-0005 written
- [x] Integration guide Phase 5 section + executable mirrors
- [x] `specs/status.md` updated to mark Phase 5 complete
- [x] `specs/planning/roadmap.md` updated

## T1 — Entities: `Delegation`, `DelegationScope`, `DelegationStatus`

- [x] Failing tests (`tests/unit/domain/test_delegation_entities.py`): scope roundtrip, delegation construction with all optional fields None, uses_remaining/budget_remaining validators, frozen mutation raises, status enum values, `Delegation.make_hash` deterministic
- [x] Implementation: `DelegationStatus` enum, `DelegationScope` entity + `from_policy` classmethod, `Delegation` entity with `make_hash` staticmethod and `_check_counter_initial_state` validator
- [x] Imports in `domain/__init__.py` / surfaced as needed
- [x] Commit: `feat(domain): add Delegation, DelegationScope, DelegationStatus entities (Phase 5 T1)`

## T2 — Phase 5 exceptions

- [x] Failing tests: construction + inheritance check for each exception
- [x] Implementation: `DelegateNotPermittedError`, `UsageExhaustedError`, `LeaseExpiredError`, `DelegationRevokedError`, `DelegationNotFoundError`, `DelegationChainDepthExceededError`
- [x] Commit: `feat(domain): add Phase 5 delegation exceptions (T2)`

## T3 — `DelegationStorePort` abstract interface

- [x] `src/open_guard/domain/ports/delegation_store.py` with ABC methods: `create`, `get`, `find_by_hash`, `list_active_for_grantee`, `list_descendants`, `update_status`, `decrement_uses`, `decrement_budget`, `touch_heartbeat`, `expire_stale`
- [x] Failing tests: ABC contract + abstract method enforcement
- [x] Commit: `feat(domain): add DelegationStorePort abstract interface (T3)`

## T4 — `InMemoryDelegationStore`

- [x] Failing tests (`tests/unit/adapters/stores/test_memory_delegation.py`):
  - [x] create + get roundtrip
  - [x] find_by_hash idempotency
  - [x] list_active_for_grantee filters by subject + resource_type
  - [x] list_descendants walks tree transitively
  - [x] `decrement_uses` concurrent race: 10 threads on max_uses=3 → 3 succeed, 7 raise
  - [x] status auto-transitions to EXHAUSTED on last decrement
  - [x] `decrement_budget` with Decimal under concurrency
  - [x] `touch_heartbeat` updates `last_heartbeat_at`
  - [x] `expire_stale` returns count + transitions
- [x] Implementation: RLock-protected dict store; all mutations go through lock
- [x] Commit: `feat(stores): add InMemoryDelegationStore with CAS-safe counters (T4)`

## T5 — `SQLAlchemyDelegationStore`

- [x] Modify `sql_models.py`: add `open_guard_delegations` + `open_guard_delegation_scopes` tables (FK cascade on delete, JSON columns for match dicts + scopes array)
- [x] Failing tests (`tests/unit/adapters/stores/test_sql_delegation.py`):
  - [x] SQLite roundtrip via `from_url` + `create_tables`
  - [x] Concurrent `decrement_uses` on SQLite (WAL or retry semantics) with exact-3-succeed contract
  - [x] FK cascade on delegation delete
  - [x] `expire_stale` SQL path works
  - [x] `metadata` exportable for consumer Alembic
- [x] Implementation: `UPDATE ... WHERE uses_remaining >= :amount RETURNING *` for CAS decrement; same for budget with Decimal-as-NUMERIC
- [x] Commit: `feat(stores): add SQLAlchemyDelegationStore with CAS-safe counters (T5)`

## T6 — `DelegationManager` service

- [x] Failing tests (`tests/unit/domain/services/test_delegation_manager.py`):
  - [x] Basic `delegate` with minimal args
  - [x] Idempotent create via hash
  - [x] Meta-authz refusal raises `DelegateNotPermittedError`
  - [x] Chain depth limit
  - [x] Static narrowing: from_subject lacks perm → raises
  - [x] `requires_approval=...` → PENDING_APPROVAL delegation + `ApprovalRequest` created
  - [x] `on_approval_resolved` transitions to ACTIVE + sets `last_heartbeat_at` when lease is set
  - [x] `revoke` cascades to descendants synchronously
  - [x] `renew`: caller in `renewable_by` succeeds; otherwise raises
  - [x] `renew` of EXPIRED raises `LeaseExpiredError`
  - [x] `consume`: decrement uses and/or budget; UsageExhaustedError propagates
- [x] Implementation: `DelegationManager` with all methods from plan
- [x] Commit: `feat(services): add DelegationManager (delegate/revoke/renew/consume) (T6)`

## T7 — `DelegationEvaluator` service

- [x] Failing tests (`tests/unit/domain/services/test_delegation_evaluator.py`):
  - [x] No active delegations → allowed=False
  - [x] Active delegation matching → allowed=True, matched_policies=[delegation.id]
  - [x] Scope match with `id: {op: eq}` / `{op: in}` pattern
  - [x] Expired/revoked/exhausted → allowed=False
  - [x] `re_check_on_use=True` + parent permission lost → allowed=False
  - [x] `re_check_on_use=False` + parent permission lost → allowed=True
  - [x] Non-delegable policy fails re-check
  - [x] Memoization: 10 calls → inner guard.authorize called once per unique key
  - [x] Chain depth re-check recurses up parent_delegation_id
  - [x] `list_contribution` emits concrete IDs only for `id: eq/in` scopes
- [x] Implementation: `DelegationEvaluator` with `evaluate` + `list_contribution`
- [x] Commit: `feat(services): add DelegationEvaluator (match + dynamic re-check + memo) (T7)`

## T8 — Wire `DelegationEvaluator` into `Guard`

- [x] Modify `Guard.__init__` to accept `delegation_store`, `delegation_evaluator`, `max_delegation_depth`, `default_delegate_policy`
- [x] Modify `Guard.authorize` to accept internal `_skip_delegation` + `_recheck_cache` flags; consult delegation evaluator when policy path is not ALLOWED
- [x] Add `Guard.delegate`, `Guard.revoke_delegation`, `Guard.renew_delegation`, `Guard.consume_delegation`, `Guard.authorize_and_consume`
- [x] Failing tests (`tests/unit/domain/services/test_guard_delegate.py`):
  - [x] Guard without delegation wiring → behavior unchanged (regression)
  - [x] policy-allowed → policy path wins, delegation evaluator not consulted
  - [x] policy-denied + delegation-allowed → ALLOWED with delegation in evaluations
  - [x] policy-denied + delegation-denied → DENIED
  - [x] `_skip_delegation=True` → delegation skipped
  - [x] `authorize_and_consume` consumes on delegation ALLOW only
  - [x] `Guard.delegate` / `revoke_delegation` / `renew_delegation` proxy to manager
- [x] Commit: `feat(services): wire DelegationEvaluator into Guard + Guard.delegate/revoke/renew/consume (T8)`

## T9 — `non_delegable` flag on `Policy`

- [x] Modify `Policy` entity: add `non_delegable: bool = False`
- [x] Failing tests: roundtrip, default, entity does not affect existing policy evaluation unless delegation re-check inspects it (covered in T7)
- [x] Commit: `feat(domain): Policy.non_delegable flag for non-delegable permissions (T9)`

## T10 — Meta-authz: `SelfDelegateOnly` built-in default

- [x] Implementation: `Guard._resolve_default_delegate_policy` + override logic in `DelegationManager.delegate` meta-authz check
- [x] Failing tests:
  - [x] Alice delegates Alice's perms → allowed under default
  - [x] Alice delegates Bob's perms → raises under default
  - [x] `default_delegate_policy=None` → even self-delegate raises
  - [x] Custom `default_delegate_policy=Policy(...)` → custom policy used
- [x] Commit: `feat(services): SelfDelegateOnly built-in default delegate policy (T10)`

## T11 — `list_authorized` delegation contribution

- [x] Modify `Guard.list_authorized` to include delegation-contributed IDs after candidate source + ReBAC
- [x] Failing tests (`tests/integration/test_delegation_list_authorized.py`):
  - [x] Concrete-ID scope → ID appears without candidate source
  - [x] Pattern scope + candidate source → IDs emerge via iterate-per-candidate
  - [x] Exhausted/revoked/expired delegations contribute nothing
  - [x] Cursor stability across paginated calls
  - [x] `list_authorized` never consumes usage (1000 candidates + max_uses=5 → uses_remaining still 5)
- [x] Commit: `feat(services): Guard.list_authorized includes delegation contributions (T11)`

## T12 — MCP `consume_tool_call_budget` helper

- [x] Modify `MCPAuthorizationResult` to include `attributed_delegation_ids: list[str]`
- [x] Add `MCPGuard.consume_tool_call_budget`
- [x] Failing tests (`tests/unit/adapters/mcp/test_consume_budget.py`):
  - [x] Tool call allowed via delegation → budget decrements
  - [x] Tool call allowed via direct policy → no-op
  - [x] Tool call denied → no-op
- [x] Commit: `feat(mcp): MCPGuard.consume_tool_call_budget helper (T12)`

## T13 — Integration: end-to-end lifecycle

- [x] `tests/integration/test_delegation_e2e.py` covers: delegate → authorize → consume → renew → re-authorize after lease expiry → revoke
- [x] Commit: `test(integration): end-to-end delegation lifecycle (T13)`

## T14 — Integration: cascade revoke + non-delegable

- [x] `tests/integration/test_delegation_cascade.py`: 3-level chain revoke; non-delegable fails re-check; non-delegable + opt-out bypass
- [x] Commit: `test(integration): cascade revocation + non-delegable semantics (T14)`

## T15 — Integration: MCP + delegation budget

- [x] `tests/integration/test_delegation_mcp.py`: agent without direct policy + delegation with budget → tool call flow
- [x] Commit: `test(integration): MCP tool-call with delegation budget (T15)`

## T16 — Public API exports + version bump

- [x] Export Phase 5 symbols from `open_guard/__init__.py`
- [x] Bump `pyproject.toml` version to 0.6.0
- [x] Bump `open_guard.__version__`
- [x] Failing tests: import regression for every exported symbol
- [x] Commit: `chore: v0.6.0 — Phase 5 public API exports`

## T17 — Integration guide Phase 5 section + executable mirrors

- [x] Append Phase 5 section to `specs/architecture/integration-guide.md`
- [x] Add `test_phase5_*` mirrors in `tests/integration/test_integration_guide_examples.py`
- [x] Commit: `docs(integration-guide): Phase 5 section + executable mirrors (T17)`

## T18 — ADRs

- [x] `specs/decisions/0003-delegation-entity-and-api-shape.md`
- [x] `specs/decisions/0004-delegation-evaluator-and-meta-authz.md`
- [x] `specs/decisions/0005-delegation-bounds-usage-budget-lease.md`
- [x] Each cites prior art (Thomas & Sandhu, RFC 8693, Vault, etcd, AWS STS, Cerbos, Zanzibar, Auth0 Token Vault)
- [x] Commit: `docs(adr): ADR-0003 + ADR-0004 + ADR-0005 (Phase 5) (T18)`

## T19 — Sync docs

- [x] Run `/sync-docs` to update `auth-model.md` (Delegation section) + resolve FEAT-001/002/003 in backlog
- [x] Commit: `docs: sync Phase 5 changes to reference specs (T19)`

## T20 — Release prep

- [x] Verify full suite + lint + mypy + coverage
- [x] Verify `[sql]` extra tests pass
- [x] Verify `[mcp]` extra tests pass
- [x] Update `specs/status.md` + `specs/planning/roadmap.md`
- [x] Final release notes / CHANGELOG entry
- [x] Commit: `release: v0.6.0 — Phase 5 Delegation & Bounds (T20)`
- [x] Open release PR
