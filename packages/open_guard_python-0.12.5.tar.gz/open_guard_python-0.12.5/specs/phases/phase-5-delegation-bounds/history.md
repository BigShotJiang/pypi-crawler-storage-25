# Phase 5 — Delegation & Bounds: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [DECISION] 2026-04-19 — Phase 5 scope: FEAT-001 + FEAT-002 + FEAT-003 (FEAT-010 deferred)
Topics: scope, phase-theme, delegation, usage, lease, prompt-injection
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/planning/roadmap.md
Detail: Phase 5 bundles the three runtime primitives — push/pull delegation (FEAT-001), usage-counted / budget-capped permissions (FEAT-002), and heartbeat/lease renewal (FEAT-003) — as v0.6.0. FEAT-010 (prompt-injection-resistant policy isolation) deferred: P2 priority, docs-heavy, least coupled of the four originally planned items; deserves its own focused pass rather than riding shotgun. The three runtime features genuinely compose (a delegation can have usage caps and/or a lease), so shipping them together avoids re-opening the `Delegation` shape for follow-ons.

---

### [DECISION] 2026-04-19 — Delegation as first-class entity + dedicated `DelegationStorePort`
Topics: entity-shape, delegation-store, architecture, rule-vs-state
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0003-delegation-entity-and-api-shape.md (to be written T18), specs/architecture/auth-model.md
Detail: Chose a new `Delegation` entity + `DelegationStorePort` over three alternatives (fields on `Task`, policy-subset references in `PolicyStorePort`, or modeling delegations as `Policy` rows with parent links). Rationale: delegation is **operational state** (created/consumed/revoked live, counters decay), not a **rule** (durable policy). Phase 3 already taught us to split these (`ApprovalStorePort` ≠ `PolicyStorePort`). Industry prior art — OAuth 2.0 Token Exchange (RFC 8693), Google Zanzibar's `userset` indirection, Auth0 Token Vault — all treat delegation as its own concept. FEAT-002 (usage) and FEAT-003 (lease) become fields on this entity because their state decays over time and does not belong on a stable `Policy` or on a `Task` (work lifecycle is a different axis).

---

### [DECISION] 2026-04-19 — Delegation and OBO chain are orthogonal (not coupled)
Topics: obo-chain, identity, permission-flow, orthogonality
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0003-delegation-entity-and-api-shape.md, specs/architecture/auth-model.md
Detail: Phase 3's `Subject.on_behalf_of` identity chain and Phase 5's delegation graph are independent. Delegation authorize semantics: *"does an active, non-exhausted, non-revoked delegation from some subject to this subject cover this (action, resource)?"* — regardless of whether `on_behalf_of` is set. Coupling (require chain to match delegation graph) is available as an opt-in ABAC predicate but not required. Rationale: (1) tool-call subagents often have no chain wired (Phase 4's `MCPSessionResolver` leaves chain plumbing to consumers); (2) identity chain and permission flow are separate concerns — conflating them prevents using one without the other; (3) OAuth Token Exchange similarly decouples the `act` claim from the exchange path.

---

### [DECISION] 2026-04-19 — Unified `guard.delegate()` API with optional `requires_approval`
Topics: api-shape, push-pull, approval, pull-delegation
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0003-delegation-entity-and-api-shape.md
Detail: Push (sync grant) and pull (request + approve) collapse into one `guard.delegate(from, to, permissions, requires_approval=None, ...)` call. Without `requires_approval`, delegation is ACTIVE immediately (push). With `requires_approval=ApprovalRequirement(...)`, delegation is PENDING_APPROVAL, creates an `ApprovalRequest` via the existing `ApprovalStorePort`, and transitions to ACTIVE on `guard.approve(request_id, ...)`. Reuses Phase 3 idempotency + quorum + TTL machinery with zero new surface. Rejected: separate `delegate_push`/`delegate_pull_request`/`delegate_pull_approve` APIs (Thomas & Sandhu style) — introduces a parallel approval axis already solved by Phase 3.

---

### [DECISION] 2026-04-19 — Scope narrowing: both static (at delegate) and dynamic (at authorize), memoized, opt-out per delegation
Topics: narrowing, cascade, re-check, memoization, security
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0004-delegation-evaluator-and-meta-authz.md
Detail: (1) **Static narrowing at `delegate()`**: run `guard.authorize(from_subject, action, synthetic_resource)` per scope with `_skip_delegation=True`; reject if grantor cannot perform. Fail-fast on "you can't grant what you don't have right now." (2) **Dynamic re-check at `authorize()`**: the `DelegationEvaluator` calls `guard.authorize(from_subject_id, action, resource, _skip_delegation=True)` internally when re_check_on_use is set; cache by `(tenant, from_subject_id, action.name, resource.id)` to keep `list_authorized` over N candidates bounded to ≤N parent-authz calls (not N×chain_depth). (3) **Opt-out**: per-delegation `re_check_on_use: bool = True` (default safe); `False` for high-throughput loops that accept the static-narrowing tradeoff. (4) **Cascade revoke**: synchronous on explicit `guard.revoke_delegation()` via recursive `parent_delegation_id` walk. Implicit revocation (parent lost permission) is discovered lazily at next authorize via the dynamic re-check; no background sweeper.

---

### [DECISION] 2026-04-19 — DelegationEvaluator is a parallel evaluator, NOT an EvaluatorPort impl
Topics: evaluator-wiring, evaluator-port, compose, plumbing-refinement
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0004-delegation-evaluator-and-meta-authz.md
Detail: Brainstorm Q8 locked "delegation is a fifth peer evaluator." Codebase-inspection gate surfaced that the existing `EvaluatorPort.evaluate(request, policies: list[Policy])` is policy-based; delegations live in `DelegationStorePort` (operational state, not policies). Resolution: `DelegationEvaluator` is a **parallel evaluator type** that produces the same `Evaluation` entity (so it composes into `Decision.evaluations` unchanged), but `Guard` invokes it separately alongside the `PolicyRouter` and merges results. The "fifth peer" compose semantics from Q8 are preserved; only the plumbing differs — the port contract stays pure. Order: policy path runs first (short-circuit on ALLOW or DENY); delegation evaluator runs only when policy path yields no matching allow. Deny from policy path beats delegation (`non_delegable` flag further protects against upstream delegation transfer).

---

### [DECISION] 2026-04-19 — `Policy.non_delegable: bool` flag for non-delegable permissions
Topics: non-delegable, policy-flag, security
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0004-delegation-evaluator-and-meta-authz.md, specs/architecture/auth-model.md
Detail: Without a marker, any ALLOW policy's grant can be transferred via delegation + dynamic re-check. Operators need *"admins may do X, but admins may not delegate X to anyone"* semantics (think "read production secrets"). Adding `non_delegable: bool = False` to `Policy` means: the policy still ALLOWS the direct subject; during delegation re-check, if a matched ALLOW policy has `non_delegable=True`, the re-check fails — the delegation cannot borrow this permission. Default False preserves existing behavior; operators opt in per policy.

---

### [DECISION] 2026-04-19 — Meta-authz via `authorize("delegate", ...)` + `SelfDelegateOnly` built-in default
Topics: meta-authz, who-can-delegate, default-policy, security
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0004-delegation-evaluator-and-meta-authz.md
Detail: "Who can call `guard.delegate()`?" — FEAT-001 OQ #2. Chose: `guard.authorize(caller, action="delegate", resource=Resource(type="permission", attributes={"from": from_id, "to": to_id, "scopes": [...]}))` as meta-authz. Composes with existing RBAC/ABAC so operators control this via normal policies. Rejected: (a) trust-the-caller — spoofable; (b) caller-must-equal-from — blocks admin-delegates-for-user. Ship a built-in `default_delegate_policy="self_only"` (enabled by default) that permits self-delegation without explicit policy — the 80% case works out of the box. Operators who want strict fail-closed set `default_delegate_policy=None`. Custom `Policy` object also accepted for custom meta-authz rules. `revoke_delegation` / `renew_delegation` use the same authorize hook (default: caller == from_subject OR created_by OR admin).

---

### [DECISION] 2026-04-19 — Consumer-driven consumption + `authorize_and_consume` ergonomic shortcut
Topics: consumption, usage-count, budget, api-shape, rag-filter
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0005-delegation-bounds-usage-budget-lease.md
Detail: Chose consumer-driven consumption: `guard.consume_delegation(delegation_id, amount=1, cost=None)` called by the consumer after successful action. `guard.authorize_and_consume(subject, action, resource, ...)` is the ergonomic shortcut: calls `authorize`, and if ALLOWED via a delegation, atomically consumes. Returns `(Decision, list[ConsumedDelegation])`. Rejected: (a) auto-consume on every ALLOWED decision — breaks `list_authorized` (1000-candidate RAG filter would burn budget in one query) and mis-accounts retries; (b) two-phase reserve/commit tokens — adds a stateful token the consumer tracks across async boundaries, duplicates approval_request_id surface. `list_authorized` never consumes; enumeration ≠ action.

---

### [DECISION] 2026-04-19 — `budget: Decimal | None` — currency-unit-agnostic
Topics: budget, decimal, type-safety
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0005-delegation-bounds-usage-budget-lease.md
Detail: Budget is `Decimal` not `float` — avoids float drift over many decrements. Consumers label the unit via `Delegation.metadata` or convention (tokens, USD, etc.). `max_uses` and `budget` are independent — a delegation can have either, both, or neither. Authorization denies when **any** active limit is exhausted. Race-safety via CAS: SQL `UPDATE ... WHERE uses_remaining >= :amount RETURNING *`; in-memory lock on the store. Losing race raises `UsageExhaustedError` (caller handles); matches Vault / etcd lease-decrement deterministic semantics.

---

### [DECISION] 2026-04-19 — Lease as fields on `Delegation` (not separate entity); lazy expiry; rolling TTL bounded by immutable `expires_at`
Topics: lease, heartbeat, expiry, vault, etcd
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0005-delegation-bounds-usage-budget-lease.md
Detail: Lease and absolute deadline coexist: `expires_at` is the hard ceiling set at creation (immutable); `lease_ttl` + `last_heartbeat_at` define a rolling window that must be renewed. Evaluator computes `effective_expiry = min(expires_at, last_heartbeat_at + lease_ttl)` and fails closed past that. Rejected: (a) separate `Lease` entity — duplicates cascade paths; (b) collapse into `expires_at` with a renewable flag — drops the hard-deadline safety. Renewal: `guard.renew_delegation(delegation_id, caller)` sets `last_heartbeat_at = now()` if `caller in renewable_by` (default `[to_subject_id]`), does NOT extend `expires_at` (grantor-intent preserved). For `requires_approval=...` delegations, lease countdown starts on approval, not creation — otherwise the lease could expire during approval review. Expiry trumps usage: a lease-expired delegation dies with remaining uses intact (no grace period). Expiry is lazy at read (matches `ApprovalRequest.expires_at`); `DelegationManager.expire_stale(tenant_id)` optional sweeper for operators wanting eager cleanup.

---

### [DECISION] 2026-04-19 — `DelegationScope` shape: action_match + resource_type + resource_match + conditions
Topics: delegation-scope, abac-reuse, scope-shape
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0003-delegation-entity-and-api-shape.md
Detail: Scope grammar: `DelegationScope(action_match, resource_type, resource_match, conditions)`. **OR across scopes** on a delegation (match any); **AND within a scope** (all resource_match/conditions apply). Reuses ABAC's existing dict + operator language (`eq`, `in`, `contains_any`, `is_subset`, `not_regex`, `any_matches`, `chain.*`, `params.*`). Rejected alternatives: (a) policy-ID references — can't narrow beyond the referenced policy; (b) free-form scope strings (OAuth-style) — require a parser and converge back to structured match rules; (c) inline full `Policy` objects — duplicates fields that are nonsensical in a delegation context (priority, DENY effect, subject_match on the grantee). `DelegationScope.from_policy(policy)` classmethod provides a convenience for "narrow this policy I already have."

---

### [DECISION] 2026-04-19 — SHA-256 idempotency hash on `delegate()`; mirrors `ApprovalRequest.make_hash`
Topics: idempotency, hash, retry-safety
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0003-delegation-entity-and-api-shape.md
Detail: `Delegation.make_hash(tenant_id, from_subject_id, to_subject_id, scopes, parent_delegation_id, max_uses, budget, lease_ttl, expires_at)` computes a deterministic SHA-256. Duplicate `guard.delegate(...)` with the same canonical args returns the existing delegation (idempotent). Same shape as Phase 3's `ApprovalRequest.make_hash` — stable across process restarts because every field normalizes cleanly. Enables safe retries from agent frameworks that may re-invoke delegate() after transient errors.

---

### [DECISION] 2026-04-19 — MCP adapter integration: no new MCPGuard surface, one helper
Topics: mcp, integration-seam, tool-call-budget
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/phases/phase-4-agent-integration/overview.md, specs/architecture/auth-model.md
Detail: Phase 4's `MCPGuard.check_tool_call` already routes through `Guard.authorize`. Delegations flow through automatically — no new MCPGuard method needed for the authorize side. Only addition: `MCPGuard.consume_tool_call_budget(result, cost, amount=1)` — wraps `guard.consume_delegation` using `MCPAuthorizationResult.attributed_delegation_ids` (new field). The integration guide's Phase 5 section documents the common pattern: *"grant agent $5 across session"* → `delegate(to=agent, budget=Decimal("5.00"))` at session start, `consume_tool_call_budget(result, cost=Decimal("0.50"))` after each tool call.

---

### [DECISION] 2026-04-19 — Coverage target 98% (floor 95%); ~130-150 new tests; zero breaking changes
Topics: quality, coverage, testing, regression
Affects-phases: phase-5-delegation-bounds
Affects-specs: none
Detail: Phase 4 finished at 505 tests / 97% coverage. Phase 5 adds ~130-150 tests: entities + exceptions (10-15), stores (20-25 each for memory + SQL incl. concurrent CAS), manager (20-25), evaluator (25-30), Guard integration (15-20), MCP helper (5), `list_authorized` with delegation (10-15), integration tests (25-30), integration-guide mirrors (~10). Target: maintain 98%; acceptable floor 95% (any drop below blocks release). Breaking changes: zero — fully additive to Phase 4. All 505 Phase 4 tests pass unchanged.

---

### [ARCH_CHANGE] 2026-04-19 — Codebase-inspection gate surfaces evaluator port/state split
Topics: codebase-inspection, plan-hygiene, evaluator-port
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/phases/phase-5-delegation-bounds/plan.md
Detail: Following Phase 4 retrospective lesson 1 ("inspect codebase before sizing"), a pre-plan inspection of `Guard`, `EvaluatorPort`, `ApprovalManager` surfaced that `EvaluatorPort.evaluate(request, policies: list[Policy])` is policy-list-based — delegations are operational state, not policies, so the "fifth evaluator" design locked at Q8 can't verbatim fit the existing port. Resolution: `DelegationEvaluator` is a parallel evaluator type that produces the same `Evaluation` output (composes identically into `Decision.evaluations`) but is invoked by `Guard` separately from `PolicyRouter`. Compose semantics preserved; plumbing refined. Caught before writing `plan.md` code blocks — no pivot commit required during implementation.

---

### [NOTE] 2026-04-19 — Prior-art citation discipline carried from Phase 4
Topics: adr, prior-art, discipline
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/phases/phase-5-delegation-bounds/plan.md (T18)
Detail: Phase 4's two ADRs explicitly cited prior art (AWS Verified Permissions, Casbin, Cerbos, OPA, OpenFGA, SpiceDB) and documented the chosen design vs. rejected alternatives. Phase 5 inherits the discipline. Three ADRs planned: ADR-0003 (entity + API shape + hash idempotency — cite Thomas & Sandhu 1997, RFC 8693 OAuth Token Exchange, Google Zanzibar subject-sets, Auth0 Token Vault), ADR-0004 (evaluator wiring + non-delegable flag + meta-authz — cite AWS STS AssumeRole, Cerbos bounded sessions, OAuth impersonation rejection rationale), ADR-0005 (bounds: usage + budget + lease — cite Vault/etcd lease semantics, AWS Token Service refresh).

---

### [DECISION] 2026-04-19 — Max delegation chain depth: 10 (default), configurable on Guard
Topics: chain-depth, safety, limit
Affects-phases: phase-5-delegation-bounds
Affects-specs: specs/decisions/0003-delegation-entity-and-api-shape.md
Detail: `Guard(max_delegation_depth=10)` caps how deep the `parent_delegation_id` chain can go. Matches FEAT-001 detail doc default (10). Distinct from Phase 3 `max_chain_depth=5` (OBO identity chain) — these are two independent limits. Delegation depth tends to be higher than identity depth because agent-spawning hierarchies go deeper than delegator-identity hops.

---

### [DECISION] 2026-04-19 — Phase 5 complete: v0.6.0 released
Topics: delegation, delegation-bounds, delegation-evaluator, meta-authz, mcp-budget
Affects-phases: none
Affects-specs: specs/status.md, specs/phases/README.md
Detail: All T1-T20 tasks complete. 718 tests at 97% coverage, ruff clean, mypy strict clean. ADR-0003/0004/0005 written. Integration guide Phase 5 section added with 6 executable mirrors. FEAT-001/002/003 resolved in backlog. v0.6.0 released on phase-5-delegation-bounds branch.

---
