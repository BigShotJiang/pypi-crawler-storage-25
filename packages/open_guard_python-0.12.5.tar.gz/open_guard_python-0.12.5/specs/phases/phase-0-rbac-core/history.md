# Phase 0 — RBAC + ABAC Core: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [ARCH_CHANGE] 2026-04-16 — Adopted clean/hexagonal architecture from open-shield-python
Topics: architecture, clean-architecture, ports-adapters, hexagonal
Affects-phases: phase-1-tbac-rebac, phase-2-policy-engine
Affects-specs: specs/architecture/auth-model.md#design
Detail: Restructured Phase 0 from flat models/engines/api layout to clean architecture with domain/ports/adapters/api layers. Mirrors open-shield-python's architecture. All domain logic is pure Python with no external dependencies. Adapters implement ports. Framework layers are thin.

---

### [DECISION] 2026-04-16 — Build evaluators from scratch, no external engine dependencies
Topics: rbac, abac, build-vs-wrap, casbin, vendor-neutrality
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#design
Detail: Decided to build RBAC and ABAC evaluators from scratch rather than wrapping Casbin or other libraries. open-guard owns both policy data and evaluation compute. External engine adapters (Casbin, OPA, OpenFGA) can be added as optional adapters in Phase 2. This ensures true vendor neutrality and avoids data ownership conflicts.

---

### [DECISION] 2026-04-16 — open-guard owns policy data, engines are compute-only
Topics: policy-store, data-ownership, vendor-neutrality
Affects-phases: phase-1-tbac-rebac, phase-2-policy-engine
Affects-specs: specs/architecture/auth-model.md#design
Detail: All policy data is stored in open-guard's PolicyStorePort implementations, not in external engines' databases. When external engines are added as adapters (future), they receive policies at evaluation time — they are compute-only, not data stores. This prevents lock-in and enables engine swapping without data migration.

---

### [DECISION] 2026-04-16 — Hybrid evaluation: unified API + typed evaluator ports
Topics: architecture, evaluation, policy-router
Affects-phases: phase-1-tbac-rebac
Affects-specs: specs/architecture/auth-model.md#design
Detail: Chose Approach C: single unified Guard.authorize() entry point for consumers, with internally typed EvaluatorPort implementations per auth model. PolicyRouter dispatches to the right evaluators and combines results. New models (TBAC, ReBAC) are added by implementing EvaluatorPort — no existing code changes.

---

### [DECISION] 2026-04-16 — Flexible actor model for AI agents, devices, conversations
Topics: subject, actor-type, ai-agents, iot, multi-actor
Affects-phases: phase-1-tbac-rebac
Affects-specs: specs/architecture/auth-model.md#design
Detail: Subject entity uses ActorType enum (user, agent, service, device, conversation) with flexible attributes dict. Not hardcoded to "user with roles." This supports AI agents, IoT devices, M2M services, and AI conversations as first-class actors. TBAC in Phase 1 will add task-based scoping for agents.

---

### [SCOPE_CHANGE] 2026-04-16 — Expanded Phase 0 scope with FastAPI integration and bridge
Topics: fastapi, open-shield-python, api-layer, scope
Affects-phases: none
Affects-specs: specs/planning/roadmap.md#timeline
Detail: Added FastAPI middleware/dependencies and Subject.from_user_context() bridge to Phase 0 scope. Previously Phase 0 was just models + engines. Now includes full API layer for end-to-end usability. Estimated effort increased from 3 to 5 days.

---

### [DECISION] 2026-04-16 — SOLID and design principles as project standards
Topics: principles, solid, design-patterns
Affects-phases: phase-1-tbac-rebac, phase-2-policy-engine
Affects-specs: specs/architecture/auth-model.md#principles
Detail: Adopted 8 engineering principles (from open-shield-python, adapted), 5 SOLID principles, and 5 design principles as project standards. Key: composition over inheritance, immutable domain entities, least privilege by default, tenant isolation by design.

---

### [NOTE] 2026-04-16 — Competitive landscape validates the vision
Topics: landscape, competition, oso, tbac, gap-analysis
Affects-phases: none
Affects-specs: none
Detail: Research confirmed no existing open-source library combines RBAC+ABAC+TBAC+ReBAC with native AI agent support. Oso/Polar (closest competitor) deprecated open-source for SaaS. TBAC is absent from all general-purpose libraries. 27% of teams write custom auth code for AI agents. open-guard fills a clear gap.

---

### [DISCOVERY] 2026-04-16 — Post-implementation standards gap analysis for RBAC + ABAC
Topics: rbac, abac, nist, xacml, gap-analysis, standards
Affects-phases: phase-1-tbac, phase-2-rebac
Affects-specs: specs/backlog/backlog.md
Detail: Researched NIST RBAC (INCITS 359-2012), NIST SP 800-162 (ABAC), XACML 3.0, and industry implementations (AWS IAM, Azure, GCP, Cedar, OPA) post Phase 0 completion. RBAC gaps: sessions (activate role subset), SSD/DSD constraints. ABAC gaps: OR/NOT combinators (only AND currently), additional operators (starts_with, ends_with, in_cidr, set ops), PIP (lazy attribute resolution), obligations (post-decision hooks). Core implementation is solid — gaps are advanced features. Added ENH-001 through ENH-009 to backlog. ENH-004 (OR/NOT combinators) is P1; rest are P2/P3.

---
