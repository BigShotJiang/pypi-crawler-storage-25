# Phase 0 Retrospective — RBAC + ABAC Core

> **Completed**: 2026-04-16
> **Duration**: 1 day (planned 5 days)
> **Version**: v0.1.0

## What Went Well

- **Clean architecture pays off**: Mirroring open-shield-python's hexagonal structure made the design intuitive. Domain/ports/adapters separation worked cleanly.
- **Build from scratch was the right call**: RBAC and ABAC evaluators are straightforward pure Python. No need for Casbin dependency — simpler, we own everything.
- **Test coverage exceeded target**: 107 tests, 98% coverage (target was >95%). TDD approach caught edge cases early.
- **All tools green**: mypy --strict, ruff, pytest all passing from the start.
- **Brainstorm → design → implement flow** worked well. Extensive brainstorming (architecture, competitive landscape, ecosystem integration) front-loaded decisions so implementation was focused.

## What Didn't Go Well

- **Skill/command discovery**: Custom slash commands in `.claude/commands/` weren't visible. Had to convert to `.claude/skills/<name>/SKILL.md` format at parent workspace level. Lost time debugging.
- **Scope creep during brainstorm**: The brainstorm expanded well beyond Phase 0 (deployment modes, service architecture, full ecosystem). Good for vision but made it harder to scope Phase 0 tightly.
- **auth-model.md was a stub until phase completion**: The architecture doc wasn't updated during implementation (per Rule 9). This is correct behavior but means the doc was stale during the phase.

## Lessons Learned

1. **Skills format > commands format** for Claude Code custom workflows. Always use `.claude/skills/<name>/SKILL.md` at the project root.
2. **Brainstorm vision separately from phase scope**. The full vision (all deployment modes, all actor types, all phases) should live in architecture docs. Phase brainstorm should focus on what ships this phase.
3. **98% coverage is achievable** with focused edge-case testing. The remaining 2% is unreachable type guards.

## Metrics

| Metric | Value |
|--------|-------|
| Tests | 107 |
| Coverage | 98% |
| mypy errors | 0 |
| ruff errors | 0 |
| Commits | 12 |
| Files created | 21 source + 7 test |
| Backlog items | 0 |
