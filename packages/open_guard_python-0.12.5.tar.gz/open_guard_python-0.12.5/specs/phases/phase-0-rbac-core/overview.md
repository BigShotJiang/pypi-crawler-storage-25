# Phase 0: RBAC + ABAC Core

> **Status**: Not Started
> **Depends On**: Nothing — this is the foundation
> **Estimated Effort**: 5 days

## Goal

Build the core authorization engine with clean/hexagonal architecture (mirroring open-shield-python's design principles), implementing RBAC and ABAC evaluators with a unified `Guard.authorize()` entry point. Establish the domain layer (entities, ports, services), adapter layer (built-in evaluators, in-memory policy store), and FastAPI API layer — all from scratch, pure Python, no external authorization library dependencies.

## Key Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Architecture | Clean/Hexagonal (ports & adapters) | Matches open-shield-python, enables vendor neutrality |
| Build vs wrap | Build from scratch | We own data + compute; RBAC/ABAC are well-understood algorithms |
| Policy data ownership | open-guard owns all policy data | Avoids lock-in to any external engine's storage |
| Evaluation strategy | Hybrid — unified `Guard.authorize()` dispatches to typed evaluator ports | Clean consumer API + clean internal separation |
| Default deny | Fail closed — missing policies = denied | Security principle |
| Entity design | Frozen Pydantic models | Immutable domain objects, strict typing |
| Actor model | Flexible Subject with ActorType enum | Supports users, AI agents, services, devices, conversations |
| Multi-tenancy | Tenant-scoped policies from day one | Every query filtered by tenant_id |
| Tooling | uv + ruff + mypy --strict + pytest | Matches open-shield-python stack |

## Source Structure

```
src/open_guard/
├── __init__.py                  # Public API exports
├── domain/
│   ├── __init__.py
│   ├── entities.py              # Subject, Resource, Action, Policy, Decision, Evaluation
│   ├── exceptions.py            # OpenGuardError hierarchy
│   ├── ports/
│   │   ├── __init__.py
│   │   ├── evaluator.py         # EvaluatorPort (abstract)
│   │   └── policy_store.py      # PolicyStorePort (abstract)
│   └── services/
│       ├── __init__.py
│       ├── guard.py             # Guard — main entry point
│       └── policy_router.py     # PolicyRouter — dispatches to evaluators
├── adapters/
│   ├── __init__.py
│   ├── config.py                # OpenGuardConfig (Pydantic settings)
│   ├── evaluators/
│   │   ├── __init__.py
│   │   ├── rbac.py              # RBACEvaluator
│   │   └── abac.py              # ABACEvaluator
│   └── stores/
│       ├── __init__.py
│       └── memory.py            # InMemoryPolicyStore
└── api/
    └── fastapi/
        ├── __init__.py
        ├── middleware.py         # OpenGuardMiddleware
        └── dependencies.py      # RequirePermission, RequireActor, etc.

tests/
├── unit/
│   ├── domain/
│   │   ├── test_entities.py
│   │   └── services/
│   │       ├── test_guard.py
│   │       └── test_policy_router.py
│   └── adapters/
│       ├── evaluators/
│       │   ├── test_rbac.py
│       │   └── test_abac.py
│       └── stores/
│           └── test_memory.py
└── integration/
    └── api/
        └── test_fastapi.py
```

## Scope

### In Scope
- Domain entities: Subject (with ActorType), Resource, Action, Policy, Decision, Evaluation, AuthorizationRequest
- Ports: EvaluatorPort, PolicyStorePort
- Services: Guard (unified entry point), PolicyRouter (dispatches + combines)
- RBAC evaluator: role hierarchy, permission matching
- ABAC evaluator: attribute condition matching (equals, contains, in, gt, lt, regex)
- InMemoryPolicyStore: tenant-scoped policy storage
- OpenGuardConfig: Pydantic-based configuration
- FastAPI integration: middleware + dependencies (RequirePermission, RequireActor)
- open-shield-python bridge: `Subject.from_user_context()` convenience method
- Exception hierarchy: OpenGuardError, AuthorizationDeniedError, PolicyError, ConfigurationError
- Project infrastructure: pyproject.toml, uv, ruff, mypy --strict, pytest
- Full test suite: unit + integration, >95% coverage target

### Out of Scope
- TBAC (time-based / task-based access control) — Phase 1
- ReBAC (relationship-based access control) — Phase 1
- SQLPolicyStore / YAMLPolicyStore — Phase 1
- Policy DSL / declarative policy language — Phase 2
- External engine adapters (Casbin, OPA, OpenFGA) — Phase 2
- Service mode (HTTP/gRPC server) — Phase 2+
- Sidecar deployment — Phase 2+
- Flask / Django integrations — Phase 2+

## Key Deliverables

| # | Deliverable | Description | Verification |
|---|-------------|-------------|-------------|
| 1 | Domain layer | Entities, ports, services — pure Python, zero external deps | `mypy --strict` passes, unit tests pass |
| 2 | RBAC evaluator | Role hierarchy + permission matching | RBAC test suite passes (10+ cases) |
| 3 | ABAC evaluator | Attribute condition matching with operators | ABAC test suite passes (10+ cases) |
| 4 | InMemoryPolicyStore | Tenant-scoped CRUD for policies | Store test suite passes |
| 5 | Guard + PolicyRouter | Unified `guard.authorize()` combining evaluators | Integration tests pass |
| 6 | FastAPI integration | Middleware + dependencies | E2E tests pass |
| 7 | Project infrastructure | pyproject.toml, uv, ruff, mypy, pytest, CI | `uv run pytest && uv run mypy && uv run ruff check` all clean |

## Acceptance Criteria

- [ ] `guard.authorize(subject, action, resource)` returns Decision with allow/deny + reason
- [ ] RBAC evaluation with role hierarchy passes all test cases
- [ ] ABAC evaluation with attribute conditions passes all test cases
- [ ] All policies are tenant-scoped — cross-tenant access is impossible
- [ ] Default deny: missing policies → denied
- [ ] FastAPI middleware + dependencies work end-to-end
- [ ] Subject supports all ActorType values (user, agent, service, device, conversation)
- [ ] `Subject.from_user_context()` bridge works with open-shield-python's UserContext
- [ ] `mypy --strict` passes with zero errors
- [ ] `ruff check` passes with zero errors
- [ ] Test coverage >95% on domain and adapter layers
- [ ] README with usage examples and quick-start guide

## Exit Criteria

All acceptance criteria met AND:
- No P0 bugs remain open
- Architecture doc `specs/architecture/auth-model.md` updated with implemented design
