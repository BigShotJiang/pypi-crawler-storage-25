# Phase 0 Tasks

> **Status**: Complete | **Progress**: 11/11 tasks

## Infrastructure

- [x] **Set up project structure**
  - pyproject.toml with uv, ruff, mypy --strict, pytest
  - Create src/open_guard/ package layout (domain/, adapters/, api/)
  - Verification: `uv sync && uv run ruff check && uv run mypy src/`

## Domain Layer

- [x] **Implement domain entities**
  - ActorType enum, Subject, Resource, Action, AuthorizationRequest, Policy, PolicyEffect, Decision, Evaluation
  - All frozen Pydantic models
  - Exception hierarchy: OpenGuardError, AuthorizationDeniedError, PolicyError, ConfigurationError
  - Verification: unit tests pass, `mypy --strict` clean

- [x] **Implement ports (abstract interfaces)**
  - EvaluatorPort: evaluate(), supports()
  - PolicyStorePort: add(), get_by_tenant(), get_by_tenant_and_type(), remove()
  - Verification: ABCs cannot be instantiated directly

- [x] **Implement domain services**
  - PolicyRouter: dispatches to typed evaluators, combines results (any deny = deny)
  - Guard: unified entry point, constructs AuthorizationRequest, delegates to router
  - Verification: unit tests with mocks — deny-by-default, allow, deny, multi-evaluator, tenant isolation

## Adapter Layer

- [x] **Implement RBAC evaluator**
  - Role matching against subject attributes
  - Role hierarchy support (admin > editor > viewer)
  - Priority-based conflict resolution
  - Verification: 17 RBAC test cases pass

- [x] **Implement ABAC evaluator**
  - Condition operators: eq, neq, in, not_in, contains, gt, gte, lt, lte, regex, exists
  - AND logic within policy conditions
  - Match against subject, resource, action, and context attributes
  - Verification: 21 ABAC test cases pass

- [x] **Implement InMemoryPolicyStore**
  - Thread-safe dict-based storage
  - All operations tenant-scoped
  - Auto-generate policy IDs
  - Verification: 8 store tests pass, tenant isolation confirmed

- [x] **Implement OpenGuardConfig**
  - Pydantic BaseSettings with OPEN_GUARD_ prefix
  - Settings: default_effect, tenant_required
  - Verification: config loading tests pass

## API Layer

- [x] **Implement FastAPI integration**
  - OpenGuardMiddleware (ASGI)
  - get_guard(), RequirePermission(), RequireActor() dependencies
  - Verification: 9 E2E tests with TestClient pass

## Integration

- [x] **Implement Subject bridge + public API exports**
  - Subject bridge via middleware (from_user_context in middleware.py)
  - Public API exports in __init__.py files
  - Verification: bridge works via integration tests

## Documentation

- [x] **Write README with usage examples**
  - Quick start, architecture, FastAPI usage, actor types, multi-tenancy
  - Verification: README renders correctly on GitHub
