# Phase 0: Implementation Plan

## Approach

Build bottom-up following clean architecture: domain entities first, then ports, then services, then adapters, then API layer. Each layer is independently testable. Tests are written alongside implementation (not after).

## Principles

### Engineering Principles
1. **Vendor Neutrality** — Core logic never depends on specific policy engines or frameworks
2. **Fail Closed** — Authorization defaults to denial. Missing policies = denied
3. **No Sensitive Leakage** — Error messages don't expose policy internals
4. **Clean Architecture** — Domain is pure Python, isolated from IO and frameworks
5. **Strict Typing** — All public interfaces strictly typed. `mypy --strict`
6. **Test Everything** — Unit + integration + E2E. >95% coverage
7. **Conventional Commits** — For automated changelog
8. **Standards First** — Align with XACML concepts, OAuth 2.0, AAP standards

### SOLID Principles
- **S — Single Responsibility**: Each evaluator handles one auth model. PolicyStore handles storage only. PolicyRouter handles combining only.
- **O — Open/Closed**: New auth models added by implementing EvaluatorPort — no existing code changes.
- **L — Liskov Substitution**: Any EvaluatorPort implementation is interchangeable.
- **I — Interface Segregation**: Separate ports for separate concerns.
- **D — Dependency Inversion**: Domain depends on abstractions (ports), never on concrete adapters.

### Design Principles
- **Composition over Inheritance** — Evaluators composed into router, not inherited
- **Separation of Concerns** — Data ownership, computation, orchestration are separate
- **Least Privilege by Default** — Default deny. Policies grant access.
- **Immutable Domain Entities** — Frozen Pydantic models. No mutation after creation.
- **Tenant Isolation** — Every policy query scoped to tenant. Cross-tenant impossible.

## Prerequisites

- [ ] No dependent phases (this is Phase 0)

## Module / Directory Structure

```
src/open_guard/
├── __init__.py
├── domain/
│   ├── __init__.py
│   ├── entities.py
│   ├── exceptions.py
│   ├── ports/
│   │   ├── __init__.py
│   │   ├── evaluator.py
│   │   └── policy_store.py
│   └── services/
│       ├── __init__.py
│       ├── guard.py
│       └── policy_router.py
├── adapters/
│   ├── __init__.py
│   ├── config.py
│   ├── evaluators/
│   │   ├── __init__.py
│   │   ├── rbac.py
│   │   └── abac.py
│   └── stores/
│       ├── __init__.py
│       └── memory.py
└── api/
    └── fastapi/
        ├── __init__.py
        ├── middleware.py
        └── dependencies.py
```

## Implementation Steps

### Step 1: Project Infrastructure
Set up pyproject.toml with uv, ruff, mypy --strict, pytest. Create src/open_guard package structure. Configure CI basics.

**Commit**: `infra: initialize project with uv, ruff, mypy, pytest`

### Step 2: Domain Entities
Implement all domain models in `domain/entities.py`:
- `ActorType` enum (user, agent, service, device, conversation)
- `Subject` (id, actor_type, attributes, metadata) — frozen Pydantic model
- `Resource` (id, resource_type, attributes) — frozen
- `Action` (name, attributes) — frozen
- `AuthorizationRequest` (subject, action, resource, context, tenant_id) — frozen
- `PolicyEffect` enum (allow, deny)
- `Policy` (id, tenant_id, evaluator_type, subject_match, action_match, resource_match, conditions, effect, priority) — frozen
- `Evaluation` (evaluator, allowed, reason, matched_policies) — frozen
- `Decision` (allowed, reason, evaluations) — frozen

Implement `domain/exceptions.py`:
- `OpenGuardError` (base)
- `AuthorizationDeniedError`
- `PolicyError`
- `ConfigurationError`

**Tests**: Unit tests for entity creation, immutability, validation.
**Commit**: `feat(domain): add core entities and exceptions`

### Step 3: Ports (Abstract Interfaces)
Implement `domain/ports/evaluator.py`:
```python
class EvaluatorPort(ABC):
    @abstractmethod
    def evaluate(self, request: AuthorizationRequest, policies: list[Policy]) -> Evaluation: ...
    @abstractmethod
    def supports(self, policy: Policy) -> bool: ...
```

Implement `domain/ports/policy_store.py`:
```python
class PolicyStorePort(ABC):
    @abstractmethod
    def add(self, policy: Policy) -> Policy: ...
    @abstractmethod
    def get_by_tenant(self, tenant_id: str) -> list[Policy]: ...
    @abstractmethod
    def get_by_tenant_and_type(self, tenant_id: str, evaluator_type: str) -> list[Policy]: ...
    @abstractmethod
    def remove(self, policy_id: str, tenant_id: str) -> None: ...
```

**Tests**: Verify ABCs cannot be instantiated without implementing all methods.
**Commit**: `feat(domain): add EvaluatorPort and PolicyStorePort`

### Step 4: Domain Services
Implement `domain/services/policy_router.py`:
- Takes list of evaluators + policy store
- `evaluate(request)`: fetches policies by tenant → groups by evaluator_type → dispatches → combines (any deny = deny, else all allow = allow)
- Returns `Decision` with full audit trail

Implement `domain/services/guard.py`:
- Main entry point: `Guard(policy_store, evaluators, config)`
- `authorize(subject, action, resource, context)` → `Decision`
- `policy_store` property for CRUD access
- Constructs `AuthorizationRequest` internally

**Tests**: Unit tests with mock evaluators and mock store.
- Test deny-by-default (no policies → denied)
- Test single evaluator allow
- Test single evaluator deny
- Test multi-evaluator: one denies → denied
- Test multi-evaluator: all allow → allowed
- Test tenant isolation (policies from tenant-A don't affect tenant-B)

**Commit**: `feat(domain): add PolicyRouter and Guard services`

### Step 5: RBAC Evaluator
Implement `adapters/evaluators/rbac.py`:
- Implements `EvaluatorPort`
- `supports(policy)` → True if `policy.evaluator_type == "rbac"`
- `evaluate(request, policies)`:
  - Extract subject roles from `request.subject.attributes["roles"]`
  - For each policy: check if subject has matching role
  - Support role hierarchy via `role_hierarchy` config (dict mapping role → parent roles)
  - Apply effect (allow/deny) based on matched policies
  - Priority ordering: higher priority wins on conflict

**Tests**: 10+ test cases:
- Basic role match (has role → allowed)
- No matching role → denied
- Role hierarchy (viewer < editor < admin)
- Multiple roles on subject
- Deny policy overrides allow
- Priority ordering
- Empty policies → denied
- Wildcard role matching

**Commit**: `feat(rbac): implement RBACEvaluator with hierarchy support`

### Step 6: ABAC Evaluator
Implement `adapters/evaluators/abac.py`:
- Implements `EvaluatorPort`
- `supports(policy)` → True if `policy.evaluator_type == "abac"`
- `evaluate(request, policies)`:
  - For each policy: evaluate all conditions against subject, resource, action, context attributes
  - Condition operators: `eq`, `neq`, `in`, `not_in`, `contains`, `gt`, `gte`, `lt`, `lte`, `regex`, `exists`
  - All conditions in a policy must match (AND logic)
  - Apply effect based on matched policies

**Tests**: 10+ test cases:
- Attribute equals match
- Attribute in list
- Numeric comparison (gt, lt)
- Regex match
- Multiple conditions (AND)
- Resource attribute matching
- Context/environment attribute matching (e.g., IP range)
- No matching policy → denied
- Deny effect
- Actor type condition (e.g., agent-only policy)

**Commit**: `feat(abac): implement ABACEvaluator with condition operators`

### Step 7: InMemoryPolicyStore
Implement `adapters/stores/memory.py`:
- Implements `PolicyStorePort`
- Thread-safe dict-based storage
- All operations scoped by tenant_id
- Auto-generates policy IDs if not provided

**Tests**:
- Add and retrieve policies
- Tenant isolation (tenant-A can't see tenant-B)
- Remove policy
- Get by type filter
- Empty store returns empty list

**Commit**: `feat(store): implement InMemoryPolicyStore`

### Step 8: Configuration
Implement `adapters/config.py`:
- `OpenGuardConfig(BaseSettings)` with Pydantic
- Settings: default_effect, role_hierarchy, tenant_required
- Env var prefix: `OPEN_GUARD_`

**Tests**: Config loading, defaults, env var override.
**Commit**: `feat(config): add OpenGuardConfig with Pydantic settings`

### Step 9: FastAPI Integration
Implement `api/fastapi/middleware.py`:
- `OpenGuardMiddleware`: ASGI middleware
- Integrates with open-shield-python's UserContext if available on request.state
- Auto-converts UserContext → Subject via bridge method
- Attaches Guard instance to request.state for downstream use

Implement `api/fastapi/dependencies.py`:
- `get_guard(request)` → Guard from request.state
- `RequirePermission(action, resource_type)` → FastAPI dependency
- `RequireActor(*actor_types)` → FastAPI dependency (restrict by actor type)

**Tests**: E2E tests with TestClient.
- Middleware attaches guard
- RequirePermission allows/denies correctly
- RequireActor blocks wrong actor types
- 403 response on denial with safe error message

**Commit**: `feat(fastapi): add middleware and dependencies`

### Step 10: Subject Bridge + Public API
Add `Subject.from_user_context()` class method:
- Converts open-shield-python's UserContext → Subject
- Maps: user.id → subject.id, user.actor_type → subject.actor_type, user.roles → attributes["roles"], etc.
- Import is conditional (open-shield is optional dependency)

Set up public API exports in `__init__.py` files:
- `open_guard` → Guard, Subject, Resource, Action, Decision, Policy, etc.
- `open_guard.api.fastapi` → middleware + dependencies

**Commit**: `feat: add Subject bridge and public API exports`

### Step 11: README + Examples
Write README.md with:
- Quick start (pip install, basic usage)
- Architecture overview
- Usage with FastAPI
- Usage with open-shield-python
- Actor types
- Multi-tenancy
- Configuration

**Commit**: `docs: add README with usage examples`

## Risks

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| ABAC condition operators become complex | Medium | Medium | Start with core operators, extensible design |
| Role hierarchy performance with deep chains | Low | Medium | Memoize resolved hierarchies |
| Thread safety in InMemoryPolicyStore | Medium | High | Use threading.Lock from the start |
| open-shield-python bridge breaks on version changes | Low | Low | Conditional import, typed against interface not impl |
