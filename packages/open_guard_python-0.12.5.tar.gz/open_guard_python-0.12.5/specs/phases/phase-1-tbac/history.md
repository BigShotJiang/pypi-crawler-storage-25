# Phase 1 — TBAC: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [DECISION] 2026-04-16 — Split Phase 1 into TBAC-only; ReBAC moves to Phase 2
Topics: scope, phase-split, tbac, rebac
Affects-phases: phase-2-rebac
Affects-specs: specs/planning/roadmap.md#timeline
Detail: Original roadmap had Phase 1 as "TBAC + ReBAC". Split to keep phases focused and completable in a sprint. Phase 1 = TBAC (time + task). Phase 2 = ReBAC + SQLAlchemy PolicyStore. Phase 3 = Policy Engine + External Adapters (shifted from original Phase 2).

---

### [DECISION] 2026-04-16 — SQLAlchemy-based PolicyStore for Phase 2 (covers multiple DBs via dialect)
Topics: policy-store, sql, sqlalchemy, database
Affects-phases: phase-2-rebac
Affects-specs: specs/architecture/auth-model.md#design
Detail: Instead of building separate SQLite/Postgres/MySQL stores, will build one SQLAlchemy-based SQLPolicyStore that covers all SQL dialects via connection string. Standard Python library approach. Deferred to Phase 2.

---

### [DECISION] 2026-04-16 — UTC internally, IANA timezone for recurring schedules
Topics: time, timezone, utc, iana, dst
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#tbac
Detail: Following XACML/NIST/AWS IAM standards. All timestamps stored and compared in UTC. Recurring schedules (day-of-week + time-of-day) store IANA timezone (e.g., "Asia/Kolkata") for DST-aware evaluation. Uses Python stdlib `zoneinfo` (not pytz). Evaluator converts UTC now -> local timezone -> checks range.

---

### [DECISION] 2026-04-16 — Standard-level task lifecycle (no delegation/usage-counting)
Topics: tbac, task, lifecycle, scope
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#tbac
Detail: Phase 1 implements Thomas & Sandhu task lifecycle (create -> active -> complete/fail/expire) with parent-child hierarchy and permission narrowing. Full TBAC features (push/pull delegation FEAT-001, usage-counted permissions FEAT-002, heartbeat/lease renewal FEAT-003) backlogged for future phases. Research showed these are advanced patterns not needed for initial agent task scoping.

---

### [NOTE] 2026-04-16 — Research validated design approach
Topics: research, xacml, nist, thomas-sandhu, standards
Affects-phases: none
Affects-specs: none
Detail: Researched TBAC standards before planning. Key findings: (1) XACML/NIST treat time as environment attributes — aligns with our condition-based approach. (2) Thomas & Sandhu 1997 defines task lifecycle model we're adopting. (3) Industry patterns (AWS STS, Vault leases, K8s projected tokens, GitHub Actions OIDC) validate the task-scoped-permissions approach. (4) No existing open-source library combines all four auth models.

---

### [DISCOVERY] 2026-04-16 — RBAC + ABAC standards gap analysis identified 9 enhancements
Topics: rbac, abac, nist, xacml, gap-analysis, standards, backlog
Affects-phases: phase-2-rebac
Affects-specs: specs/backlog/backlog.md
Detail: Post-hoc standards research for Phase 0. Compared implementation against NIST RBAC (INCITS 359), NIST SP 800-162, XACML 3.0, AWS IAM, Cedar, OPA patterns. Core is solid. Gaps backlogged as ENH-001 to ENH-009: RBAC sessions + SSD/DSD (ENH-001–003), ABAC OR/NOT combinators (ENH-004, P1), additional operators (ENH-005–007), PIP (ENH-008), obligations (ENH-009).

---

### [SCOPE_CHANGE] 2026-04-16 — Backlogged full TBAC features as FEAT-001 through FEAT-004
Topics: backlog, scope, delegation, usage-counting, heartbeat, cron
Affects-phases: none
Affects-specs: specs/backlog/backlog.md
Detail: Added four backlog items for deferred TBAC features: FEAT-001 (push/pull delegation, P2), FEAT-002 (usage-counted permissions, P2), FEAT-003 (heartbeat/lease renewal, P3), FEAT-004 (cron expression schedules, P3).

---
