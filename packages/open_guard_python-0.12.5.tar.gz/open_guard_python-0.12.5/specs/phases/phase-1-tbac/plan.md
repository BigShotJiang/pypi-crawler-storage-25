# Phase 1 — TBAC Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add time-based and task-based access control to open-guard via a TBACEvaluator, Task entity with lifecycle management, and parent-child permission narrowing.

**Architecture:** New `TBACEvaluator` implements `EvaluatorPort` (same as RBAC/ABAC). New `Task` entity + `TaskStorePort` + `TaskManager` service for lifecycle. Evaluator auto-injects time context, checks time conditions on policies, and validates task status/scope for task-scoped policies. Clock injection enables deterministic testing.

**Tech Stack:** Python 3.12+, Pydantic v2 (frozen models), zoneinfo (stdlib), datetime (stdlib), ISO 8601 durations via manual parsing (no external deps).

---

## Task 1: Domain Entities — TaskStatus + Task

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Write failing tests for TaskStatus and Task**

Add to `tests/unit/domain/test_entities.py`:

```python
from datetime import datetime, timezone

from open_guard.domain.entities import (
    ActorType,
    Task,
    TaskStatus,
)


class TestTaskStatus:
    def test_task_status_values(self) -> None:
        assert TaskStatus.CREATED == "created"
        assert TaskStatus.ACTIVE == "active"
        assert TaskStatus.COMPLETED == "completed"
        assert TaskStatus.FAILED == "failed"
        assert TaskStatus.EXPIRED == "expired"

    def test_task_status_is_str_enum(self) -> None:
        assert isinstance(TaskStatus.CREATED, str)


class TestTask:
    def test_create_task_minimal(self) -> None:
        now = datetime(2026, 4, 16, 12, 0, 0, tzinfo=timezone.utc)
        task = Task(
            tenant_id="t1",
            actor_id="agent-1",
            created_at=now,
        )
        assert task.id  # auto-generated UUID
        assert task.tenant_id == "t1"
        assert task.actor_id == "agent-1"
        assert task.actor_type == ActorType.AGENT
        assert task.status == TaskStatus.CREATED
        assert task.parent_task_id is None
        assert task.allowed_actions == ["*"]
        assert task.allowed_resource_types == ["*"]
        assert task.expires_at is None
        assert task.activated_at is None
        assert task.completed_at is None
        assert task.metadata == {}

    def test_create_task_full(self) -> None:
        now = datetime(2026, 4, 16, 12, 0, 0, tzinfo=timezone.utc)
        later = datetime(2026, 4, 16, 14, 0, 0, tzinfo=timezone.utc)
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="user-1",
            actor_type=ActorType.USER,
            status=TaskStatus.ACTIVE,
            parent_task_id="task-0",
            allowed_actions=["read", "write"],
            allowed_resource_types=["document"],
            created_at=now,
            activated_at=now,
            expires_at=later,
            metadata={"workflow": "review"},
        )
        assert task.id == "task-1"
        assert task.actor_type == ActorType.USER
        assert task.allowed_actions == ["read", "write"]
        assert task.expires_at == later

    def test_task_is_frozen(self) -> None:
        now = datetime(2026, 4, 16, 12, 0, 0, tzinfo=timezone.utc)
        task = Task(tenant_id="t1", actor_id="a1", created_at=now)
        try:
            task.status = TaskStatus.ACTIVE  # type: ignore[misc]
            assert False, "Should have raised"
        except Exception:
            pass  # frozen — expected
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/domain/test_entities.py::TestTaskStatus -v && pytest tests/unit/domain/test_entities.py::TestTask -v`
Expected: ImportError — `TaskStatus` and `Task` not defined.

- [ ] **Step 3: Implement TaskStatus and Task**

Add to `src/open_guard/domain/entities.py` (after the `PolicyEffect` class, before `Evaluation`):

```python
from datetime import datetime


class TaskStatus(StrEnum):
    """Lifecycle states for a task."""

    CREATED = "created"
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"
    EXPIRED = "expired"


class Task(Entity):
    """A unit of work with scoped permissions and lifecycle.

    Tasks are first-class authorization objects. Permissions can be scoped
    to a task — they are only active while the task is in ACTIVE status.
    Parent-child hierarchy enforces permission narrowing (child <= parent).
    """

    id: str = Field(
        default_factory=lambda: str(uuid4()),
        description="Unique task identifier",
    )
    tenant_id: str = Field(..., description="Tenant this task belongs to")
    actor_id: str = Field(..., description="Subject who owns this task")
    actor_type: ActorType = Field(
        default=ActorType.AGENT, description="Type of actor owning the task"
    )
    parent_task_id: str | None = Field(
        default=None, description="Parent task ID for hierarchy"
    )
    status: TaskStatus = Field(
        default=TaskStatus.CREATED, description="Current lifecycle state"
    )
    allowed_actions: list[str] = Field(
        default_factory=lambda: ["*"],
        description="Actions this task can perform (* = all)",
    )
    allowed_resource_types: list[str] = Field(
        default_factory=lambda: ["*"],
        description="Resource types this task can access (* = all)",
    )
    created_at: datetime = Field(..., description="When the task was created (UTC)")
    activated_at: datetime | None = Field(
        default=None, description="When the task was activated (UTC)"
    )
    expires_at: datetime | None = Field(
        default=None, description="When the task expires (UTC, absolute)"
    )
    completed_at: datetime | None = Field(
        default=None, description="When the task completed/failed (UTC)"
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional task context",
    )
```

- [ ] **Step 4: Run tests to verify they pass**

Run: `pytest tests/unit/domain/test_entities.py -v`
Expected: All pass (including existing entity tests).

- [ ] **Step 5: Commit**

```bash
git add src/open_guard/domain/entities.py tests/unit/domain/test_entities.py
git commit -m "feat(domain): add TaskStatus and Task entities"
```

---

## Task 2: TaskError Exception

**Files:**
- Modify: `src/open_guard/domain/exceptions.py`

- [ ] **Step 1: Add TaskError**

Add to `src/open_guard/domain/exceptions.py`:

```python
class TaskError(OpenGuardError):
    """Raised for task-related errors (invalid state transition, not found)."""
```

- [ ] **Step 2: Run existing tests to verify no regression**

Run: `pytest tests/ -v --tb=short`
Expected: All 107 existing tests pass.

- [ ] **Step 3: Commit**

```bash
git add src/open_guard/domain/exceptions.py
git commit -m "feat(domain): add TaskError exception"
```

---

## Task 3: TaskStorePort + InMemoryTaskStore

**Files:**
- Create: `src/open_guard/domain/ports/task_store.py`
- Create: `src/open_guard/adapters/stores/memory_task.py`
- Create: `tests/unit/adapters/stores/test_memory_task.py`

- [ ] **Step 1: Write failing tests for InMemoryTaskStore**

Create `tests/unit/adapters/stores/test_memory_task.py`:

```python
"""Tests for InMemoryTaskStore."""

from datetime import datetime, timezone

import pytest

from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import Task, TaskStatus
from open_guard.domain.exceptions import TaskError


def _task(
    task_id: str = "task-1",
    tenant_id: str = "t1",
    actor_id: str = "agent-1",
    status: TaskStatus = TaskStatus.CREATED,
    parent_task_id: str | None = None,
) -> Task:
    return Task(
        id=task_id,
        tenant_id=tenant_id,
        actor_id=actor_id,
        status=status,
        parent_task_id=parent_task_id,
        created_at=datetime(2026, 4, 16, 12, 0, 0, tzinfo=timezone.utc),
    )


class TestInMemoryTaskStore:
    def test_add_and_get(self) -> None:
        store = InMemoryTaskStore()
        task = _task()
        stored = store.add(task)
        assert stored.id == "task-1"

        retrieved = store.get("task-1", "t1")
        assert retrieved is not None
        assert retrieved.id == "task-1"

    def test_get_nonexistent_returns_none(self) -> None:
        store = InMemoryTaskStore()
        assert store.get("nope", "t1") is None

    def test_get_wrong_tenant_returns_none(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task(tenant_id="t1"))
        assert store.get("task-1", "t2") is None

    def test_update_replaces_task(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task())
        updated = _task(status=TaskStatus.ACTIVE)
        store.update(updated)

        retrieved = store.get("task-1", "t1")
        assert retrieved is not None
        assert retrieved.status == TaskStatus.ACTIVE

    def test_update_nonexistent_raises(self) -> None:
        store = InMemoryTaskStore()
        with pytest.raises(TaskError, match="not found"):
            store.update(_task())

    def test_get_active_by_actor(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task(task_id="t1", status=TaskStatus.ACTIVE))
        store.add(_task(task_id="t2", status=TaskStatus.CREATED))
        store.add(_task(task_id="t3", status=TaskStatus.ACTIVE, actor_id="other"))

        active = store.get_active_by_actor("agent-1", "t1")
        assert len(active) == 1
        assert active[0].id == "t1"

    def test_remove(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task())
        store.remove("task-1", "t1")
        assert store.get("task-1", "t1") is None

    def test_remove_nonexistent_raises(self) -> None:
        store = InMemoryTaskStore()
        with pytest.raises(TaskError, match="not found"):
            store.remove("nope", "t1")

    def test_tenant_isolation(self) -> None:
        store = InMemoryTaskStore()
        store.add(_task(task_id="task-1", tenant_id="t1"))
        store.add(_task(task_id="task-2", tenant_id="t2"))

        assert store.get("task-1", "t1") is not None
        assert store.get("task-1", "t2") is None
        assert store.get("task-2", "t2") is not None
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/adapters/stores/test_memory_task.py -v`
Expected: ImportError — modules don't exist yet.

- [ ] **Step 3: Implement TaskStorePort**

Create `src/open_guard/domain/ports/task_store.py`:

```python
"""Abstract interface for task storage."""

from __future__ import annotations

from abc import ABC, abstractmethod

from open_guard.domain.entities import Task


class TaskStorePort(ABC):
    """Port for task storage — all operations are tenant-scoped.

    Implementations store task lifecycle state for TBAC evaluation.
    """

    @abstractmethod
    def add(self, task: Task) -> Task:
        """Add a task to the store."""

    @abstractmethod
    def get(self, task_id: str, tenant_id: str) -> Task | None:
        """Get a task by ID and tenant. Returns None if not found."""

    @abstractmethod
    def update(self, task: Task) -> Task:
        """Update an existing task. Raises TaskError if not found."""

    @abstractmethod
    def get_active_by_actor(self, actor_id: str, tenant_id: str) -> list[Task]:
        """Get all active tasks for an actor in a tenant."""

    @abstractmethod
    def remove(self, task_id: str, tenant_id: str) -> None:
        """Remove a task. Raises TaskError if not found."""
```

- [ ] **Step 4: Implement InMemoryTaskStore**

Create `src/open_guard/adapters/stores/memory_task.py`:

```python
"""In-memory task store — thread-safe, tenant-scoped."""

from __future__ import annotations

import threading

from open_guard.domain.entities import Task, TaskStatus
from open_guard.domain.exceptions import TaskError
from open_guard.domain.ports.task_store import TaskStorePort


class InMemoryTaskStore(TaskStorePort):
    """Thread-safe in-memory task store.

    All operations are tenant-scoped. Suitable for development and testing.
    """

    def __init__(self) -> None:
        self._tasks: dict[str, dict[str, Task]] = {}  # tenant_id -> {task_id -> Task}
        self._lock = threading.Lock()

    def add(self, task: Task) -> Task:
        with self._lock:
            if task.tenant_id not in self._tasks:
                self._tasks[task.tenant_id] = {}
            self._tasks[task.tenant_id][task.id] = task
        return task

    def get(self, task_id: str, tenant_id: str) -> Task | None:
        with self._lock:
            return self._tasks.get(tenant_id, {}).get(task_id)

    def update(self, task: Task) -> Task:
        with self._lock:
            tenant_tasks = self._tasks.get(task.tenant_id, {})
            if task.id not in tenant_tasks:
                raise TaskError(
                    f"Task '{task.id}' not found in tenant '{task.tenant_id}'"
                )
            tenant_tasks[task.id] = task
        return task

    def get_active_by_actor(self, actor_id: str, tenant_id: str) -> list[Task]:
        with self._lock:
            tenant_tasks = self._tasks.get(tenant_id, {})
            return [
                t
                for t in tenant_tasks.values()
                if t.actor_id == actor_id and t.status == TaskStatus.ACTIVE
            ]

    def remove(self, task_id: str, tenant_id: str) -> None:
        with self._lock:
            tenant_tasks = self._tasks.get(tenant_id, {})
            if task_id not in tenant_tasks:
                raise TaskError(
                    f"Task '{task_id}' not found in tenant '{tenant_id}'"
                )
            del tenant_tasks[task_id]
```

- [ ] **Step 5: Update port __init__.py**

Add to `src/open_guard/domain/ports/__init__.py`:

```python
from open_guard.domain.ports.task_store import TaskStorePort
```

Add to `src/open_guard/adapters/stores/__init__.py`:

```python
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
```

- [ ] **Step 6: Run tests to verify they pass**

Run: `pytest tests/unit/adapters/stores/test_memory_task.py -v`
Expected: All pass.

- [ ] **Step 7: Commit**

```bash
git add src/open_guard/domain/ports/task_store.py src/open_guard/adapters/stores/memory_task.py tests/unit/adapters/stores/test_memory_task.py src/open_guard/domain/ports/__init__.py src/open_guard/adapters/stores/__init__.py
git commit -m "feat(adapters): add TaskStorePort and InMemoryTaskStore"
```

---

## Task 4: TBACEvaluator — Time Conditions

**Files:**
- Create: `src/open_guard/adapters/evaluators/tbac.py`
- Create: `tests/unit/adapters/evaluators/test_tbac.py`

- [ ] **Step 1: Write failing tests for time condition evaluation**

Create `tests/unit/adapters/evaluators/test_tbac.py`:

```python
"""Tests for TBAC evaluator — time conditions."""

from datetime import datetime, timezone

from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.domain.entities import (
    Action,
    AuthorizationRequest,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
)


def _request(
    action: str = "read",
    resource_type: str = "document",
    tenant_id: str = "t1",
    context: dict | None = None,  # type: ignore[type-arg]
) -> AuthorizationRequest:
    return AuthorizationRequest(
        subject=Subject(id="agent-1", attributes={}),
        action=Action(name=action),
        resource=Resource(id="res-1", resource_type=resource_type),
        tenant_id=tenant_id,
        context=context or {},
    )


def _policy(
    conditions: dict | None = None,  # type: ignore[type-arg]
    action: str = "*",
    effect: PolicyEffect = PolicyEffect.ALLOW,
    priority: int = 0,
    policy_id: str = "p1",
) -> Policy:
    return Policy(
        id=policy_id,
        tenant_id="t1",
        evaluator_type="tbac",
        conditions=conditions or {},
        action_match=action,
        effect=effect,
        priority=priority,
    )


def _clock(year: int = 2026, month: int = 4, day: int = 16,
           hour: int = 12, minute: int = 0) -> datetime:
    """Create a UTC datetime for testing."""
    return datetime(year, month, day, hour, minute, 0, tzinfo=timezone.utc)


class TestTBACEvaluatorSupports:
    def test_supports_tbac_policy(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        assert evaluator.supports(Policy(tenant_id="t", evaluator_type="tbac"))
        assert not evaluator.supports(Policy(tenant_id="t", evaluator_type="rbac"))


class TestTBACTimeWindow:
    def test_within_time_window(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=12))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_before_time_window(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=15))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_after_time_window(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=18))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_not_before_only(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=20))
        policy = _policy(conditions={
            "time_window": {"not_before": "2026-04-16T00:00:00Z"}
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_not_after_only(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=15))
        policy = _policy(conditions={
            "time_window": {"not_after": "2026-04-17T00:00:00Z"}
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True


class TestTBACSchedule:
    def test_within_schedule(self) -> None:
        # 2026-04-16 is a Thursday (weekday 4, iso weekday)
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],  # Mon-Fri (ISO weekday)
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_outside_schedule_wrong_day(self) -> None:
        # 2026-04-18 is a Saturday (weekday 6)
        evaluator = TBACEvaluator(clock=lambda: _clock(day=18, hour=10))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_outside_schedule_wrong_time(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=20))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_schedule_with_iana_timezone(self) -> None:
        # 2026-04-16 12:00 UTC = 17:30 IST (Asia/Kolkata is UTC+5:30)
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=12))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "18:00"],
                "timezone": "Asia/Kolkata",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_schedule_timezone_outside_range(self) -> None:
        # 2026-04-16 02:00 UTC = 07:30 IST — before 09:00 IST
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=2))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "18:00"],
                "timezone": "Asia/Kolkata",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_schedule_days_only_no_time_range(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=23))
        policy = _policy(conditions={
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "timezone": "UTC",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True


class TestTBACTtl:
    def test_within_ttl(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=13))
        policy = _policy(conditions={
            "ttl": {
                "duration": "PT2H",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_expired_ttl(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=15))
        policy = _policy(conditions={
            "ttl": {
                "duration": "PT2H",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_ttl_days(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(day=17))
        policy = _policy(conditions={
            "ttl": {
                "duration": "P7D",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_ttl_minutes(self) -> None:
        evaluator = TBACEvaluator(
            clock=lambda: datetime(2026, 4, 16, 12, 45, 0, tzinfo=timezone.utc)
        )
        policy = _policy(conditions={
            "ttl": {
                "duration": "PT30M",
                "reference": "2026-04-16T12:00:00Z",
            }
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False


class TestTBACCombinedConditions:
    def test_window_and_schedule_both_pass(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_window_passes_schedule_fails(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=20))
        policy = _policy(conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
            "schedule": {
                "days": [1, 2, 3, 4, 5],
                "time_range": ["09:00", "17:00"],
                "timezone": "UTC",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_no_time_conditions_allows(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        policy = _policy(conditions={})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_deny_policy(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        policy = _policy(
            conditions={
                "time_window": {
                    "not_before": "2026-04-01T00:00:00Z",
                    "not_after": "2026-04-30T00:00:00Z",
                },
            },
            effect=PolicyEffect.DENY,
        )
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_deny_overrides_allow_at_same_priority(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock(hour=10))
        allow = _policy(policy_id="allow-1", conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
        })
        deny = _policy(policy_id="deny-1", conditions={
            "time_window": {
                "not_before": "2026-04-01T00:00:00Z",
                "not_after": "2026-04-30T00:00:00Z",
            },
        }, effect=PolicyEffect.DENY)
        result = evaluator.evaluate(_request(), [allow, deny])
        assert result.allowed is False

    def test_action_matching(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        policy = _policy(conditions={}, action="read")
        result = evaluator.evaluate(_request(action="write"), [policy])
        assert result.allowed is False

    def test_empty_policies(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())
        result = evaluator.evaluate(_request(), [])
        assert result.allowed is False
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/adapters/evaluators/test_tbac.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement TBACEvaluator (time conditions)**

Create `src/open_guard/adapters/evaluators/tbac.py`:

```python
"""TBAC evaluator — time-based and task-based access control."""

from __future__ import annotations

import re
from collections.abc import Callable
from datetime import datetime, timedelta, timezone
from typing import Any
from zoneinfo import ZoneInfo

from open_guard.domain.entities import (
    AuthorizationRequest,
    Evaluation,
    Policy,
    PolicyEffect,
)
from open_guard.domain.ports.evaluator import EvaluatorPort
from open_guard.domain.ports.task_store import TaskStorePort


class TBACEvaluator(EvaluatorPort):
    """Time-Based and Task-Based Access Control evaluator.

    Evaluates time conditions (absolute windows, recurring schedules, TTL)
    and task scoping (task must be active, permissions narrowed).

    Time conditions in policy.conditions:
        {
            "time_window": {"not_before": "ISO8601", "not_after": "ISO8601"},
            "schedule": {"days": [1-7], "time_range": ["HH:MM", "HH:MM"], "timezone": "IANA"},
            "ttl": {"duration": "ISO8601_DURATION", "reference": "ISO8601"},
            "task_id": "task-123",
        }

    Args:
        task_store: Optional task store for task-scoped policy evaluation.
        clock: Optional callable returning current UTC datetime (for testing).
    """

    def __init__(
        self,
        task_store: TaskStorePort | None = None,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._task_store = task_store
        self._clock = clock or (lambda: datetime.now(timezone.utc))

    def supports(self, policy: Policy) -> bool:
        return policy.evaluator_type == "tbac"

    def evaluate(
        self, request: AuthorizationRequest, policies: list[Policy]
    ) -> Evaluation:
        now = self._clock()

        matched_allow: list[str] = []
        matched_deny: list[str] = []
        best_deny_priority = -1
        best_allow_priority = -1

        for policy in sorted(policies, key=lambda p: p.priority, reverse=True):
            if not self._action_matches(request, policy):
                continue
            if not self._time_conditions_met(policy.conditions, now):
                continue
            if not self._task_conditions_met(policy.conditions, request):
                continue

            if policy.effect == PolicyEffect.DENY:
                matched_deny.append(policy.id)
                best_deny_priority = max(best_deny_priority, policy.priority)
            else:
                matched_allow.append(policy.id)
                best_allow_priority = max(best_allow_priority, policy.priority)

        if matched_deny and best_deny_priority >= best_allow_priority:
            return Evaluation(
                evaluator="tbac",
                allowed=False,
                reason="Deny policy matched",
                matched_policies=matched_deny,
            )

        if matched_allow:
            return Evaluation(
                evaluator="tbac",
                allowed=True,
                reason="Time/task conditions met",
                matched_policies=matched_allow,
            )

        return Evaluation(
            evaluator="tbac",
            allowed=False,
            reason="No matching TBAC policy",
            matched_policies=[],
        )

    def _action_matches(self, request: AuthorizationRequest, policy: Policy) -> bool:
        action_match = policy.action_match
        if action_match == "*":
            return True
        if isinstance(action_match, str):
            return request.action.name == action_match
        if isinstance(action_match, list):
            return request.action.name in action_match
        return False

    # --- Time condition evaluation ---

    def _time_conditions_met(
        self, conditions: dict[str, Any], now: datetime
    ) -> bool:
        """Evaluate all time conditions (AND logic). Returns True if all pass."""
        if "time_window" in conditions:
            if not self._check_time_window(conditions["time_window"], now):
                return False

        if "schedule" in conditions:
            if not self._check_schedule(conditions["schedule"], now):
                return False

        if "ttl" in conditions:
            if not self._check_ttl(conditions["ttl"], now):
                return False

        return True

    def _check_time_window(
        self, window: dict[str, str], now: datetime
    ) -> bool:
        """Check absolute time window (not_before / not_after)."""
        if "not_before" in window:
            not_before = datetime.fromisoformat(window["not_before"])
            if now < not_before:
                return False
        if "not_after" in window:
            not_after = datetime.fromisoformat(window["not_after"])
            if now > not_after:
                return False
        return True

    def _check_schedule(
        self, schedule: dict[str, Any], now: datetime
    ) -> bool:
        """Check recurring schedule (days + time range + timezone)."""
        tz_name = schedule.get("timezone", "UTC")
        local_now = now.astimezone(ZoneInfo(tz_name))

        # Check day of week (ISO: Monday=1, Sunday=7)
        if "days" in schedule:
            if local_now.isoweekday() not in schedule["days"]:
                return False

        # Check time range
        if "time_range" in schedule:
            time_range = schedule["time_range"]
            start_parts = time_range[0].split(":")
            end_parts = time_range[1].split(":")
            start_minutes = int(start_parts[0]) * 60 + int(start_parts[1])
            end_minutes = int(end_parts[0]) * 60 + int(end_parts[1])
            current_minutes = local_now.hour * 60 + local_now.minute

            if not (start_minutes <= current_minutes < end_minutes):
                return False

        return True

    def _check_ttl(self, ttl: dict[str, str], now: datetime) -> bool:
        """Check TTL / duration relative to a reference time."""
        reference = datetime.fromisoformat(ttl["reference"])
        duration = _parse_iso8601_duration(ttl["duration"])
        expiry = reference + duration
        return now <= expiry

    # --- Task condition evaluation ---

    def _task_conditions_met(
        self, conditions: dict[str, Any], request: AuthorizationRequest
    ) -> bool:
        """Check task-related conditions. Returns True if no task conditions."""
        task_id = conditions.get("task_id")
        if task_id is None:
            return True

        if self._task_store is None:
            return False  # task_id referenced but no store configured

        from open_guard.domain.entities import TaskStatus

        task = self._task_store.get(task_id, request.tenant_id)
        if task is None:
            return False

        # Auto-expire if past TTL
        if task.status.value == TaskStatus.ACTIVE and task.expires_at is not None:
            now = self._clock()
            if now > task.expires_at:
                expired_task = task.model_copy(update={"status": TaskStatus.EXPIRED})
                self._task_store.update(expired_task)
                return False

        if task.status != TaskStatus.ACTIVE:
            return False

        # Check task scope — does the task allow this action + resource type?
        if "*" not in task.allowed_actions:
            if request.action.name not in task.allowed_actions:
                return False

        if "*" not in task.allowed_resource_types:
            if request.resource.resource_type not in task.allowed_resource_types:
                return False

        return True


def _parse_iso8601_duration(duration_str: str) -> timedelta:
    """Parse a subset of ISO 8601 durations: P[n]D, PT[n]H[n]M[n]S, P[n]DT[n]H[n]M[n]S.

    Examples: PT2H, PT30M, P7D, P1DT12H, PT1H30M
    """
    pattern = r"^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?)?$"
    match = re.match(pattern, duration_str)
    if not match:
        raise ValueError(f"Invalid ISO 8601 duration: {duration_str}")

    days = int(match.group(1) or 0)
    hours = int(match.group(2) or 0)
    minutes = int(match.group(3) or 0)
    seconds = int(match.group(4) or 0)

    return timedelta(days=days, hours=hours, minutes=minutes, seconds=seconds)
```

- [ ] **Step 4: Update evaluators __init__.py**

Add to `src/open_guard/adapters/evaluators/__init__.py`:

```python
from open_guard.adapters.evaluators.tbac import TBACEvaluator
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `pytest tests/unit/adapters/evaluators/test_tbac.py -v`
Expected: All pass.

- [ ] **Step 6: Commit**

```bash
git add src/open_guard/adapters/evaluators/tbac.py tests/unit/adapters/evaluators/test_tbac.py src/open_guard/adapters/evaluators/__init__.py
git commit -m "feat(adapters): add TBACEvaluator with time window, schedule, and TTL support"
```

---

## Task 5: TaskManager Service

**Files:**
- Create: `src/open_guard/domain/services/task_manager.py`
- Create: `tests/unit/domain/services/test_task_manager.py`

- [ ] **Step 1: Write failing tests for TaskManager**

Create `tests/unit/domain/services/test_task_manager.py`:

```python
"""Tests for TaskManager service."""

from datetime import datetime, timezone

import pytest

from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import ActorType, Task, TaskStatus
from open_guard.domain.exceptions import TaskError
from open_guard.domain.services.task_manager import TaskManager


def _clock(hour: int = 12, day: int = 16) -> datetime:
    return datetime(2026, 4, day, hour, 0, 0, tzinfo=timezone.utc)


class TestTaskManagerCreate:
    def test_create_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        task = mgr.create_task(
            tenant_id="t1",
            actor_id="agent-1",
        )
        assert task.status == TaskStatus.CREATED
        assert task.tenant_id == "t1"
        assert task.actor_id == "agent-1"
        assert task.actor_type == ActorType.AGENT
        assert task.created_at == _clock()
        assert store.get(task.id, "t1") is not None

    def test_create_task_with_scope(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        task = mgr.create_task(
            tenant_id="t1",
            actor_id="user-1",
            actor_type=ActorType.USER,
            allowed_actions=["read"],
            allowed_resource_types=["document"],
            expires_at=_clock(hour=14),
        )
        assert task.allowed_actions == ["read"]
        assert task.allowed_resource_types == ["document"]
        assert task.expires_at == _clock(hour=14)


class TestTaskManagerActivate:
    def test_activate_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")

        activated = mgr.activate_task(task.id, "t1")
        assert activated.status == TaskStatus.ACTIVE
        assert activated.activated_at == _clock()

    def test_activate_non_created_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")
        mgr.activate_task(task.id, "t1")

        with pytest.raises(TaskError, match="Cannot activate"):
            mgr.activate_task(task.id, "t1")

    def test_activate_nonexistent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        with pytest.raises(TaskError, match="not found"):
            mgr.activate_task("nope", "t1")


class TestTaskManagerComplete:
    def test_complete_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")
        mgr.activate_task(task.id, "t1")

        completed = mgr.complete_task(task.id, "t1")
        assert completed.status == TaskStatus.COMPLETED
        assert completed.completed_at == _clock()

    def test_complete_non_active_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")

        with pytest.raises(TaskError, match="Cannot complete"):
            mgr.complete_task(task.id, "t1")


class TestTaskManagerFail:
    def test_fail_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")
        mgr.activate_task(task.id, "t1")

        failed = mgr.fail_task(task.id, "t1")
        assert failed.status == TaskStatus.FAILED
        assert failed.completed_at == _clock()

    def test_fail_non_active_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())
        task = mgr.create_task(tenant_id="t1", actor_id="a1")

        with pytest.raises(TaskError, match="Cannot fail"):
            mgr.fail_task(task.id, "t1")


class TestTaskManagerExpiry:
    def test_check_expiry_expires_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock(hour=15))
        # Manually add an active task with past expiry
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="a1",
            status=TaskStatus.ACTIVE,
            created_at=_clock(hour=10),
            activated_at=_clock(hour=10),
            expires_at=_clock(hour=12),
        )
        store.add(task)

        expired = mgr.check_expiry("task-1", "t1")
        assert expired.status == TaskStatus.EXPIRED

    def test_check_expiry_not_expired(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock(hour=11))
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="a1",
            status=TaskStatus.ACTIVE,
            created_at=_clock(hour=10),
            activated_at=_clock(hour=10),
            expires_at=_clock(hour=12),
        )
        store.add(task)

        result = mgr.check_expiry("task-1", "t1")
        assert result.status == TaskStatus.ACTIVE

    def test_check_expiry_no_expires_at(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock(hour=20))
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="a1",
            status=TaskStatus.ACTIVE,
            created_at=_clock(hour=10),
            activated_at=_clock(hour=10),
        )
        store.add(task)

        result = mgr.check_expiry("task-1", "t1")
        assert result.status == TaskStatus.ACTIVE


class TestTaskManagerChildTasks:
    def test_create_child_task(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read", "write"],
            allowed_resource_types=["document", "image"],
            expires_at=_clock(hour=18),
        )
        mgr.activate_task(parent.id, "t1")

        child = mgr.create_child_task(
            parent_task_id=parent.id,
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
            expires_at=_clock(hour=14),
        )
        assert child.parent_task_id == parent.id
        assert child.allowed_actions == ["read"]
        assert child.allowed_resource_types == ["document"]

    def test_child_actions_exceed_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
        )
        mgr.activate_task(parent.id, "t1")

        with pytest.raises(TaskError, match="exceeds parent"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
                allowed_actions=["read", "write"],
                allowed_resource_types=["document"],
            )

    def test_child_resource_types_exceed_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
        )
        mgr.activate_task(parent.id, "t1")

        with pytest.raises(TaskError, match="exceeds parent"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
                allowed_actions=["read"],
                allowed_resource_types=["document", "image"],
            )

    def test_child_expiry_exceeds_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(
            tenant_id="t1",
            actor_id="a1",
            expires_at=_clock(hour=14),
        )
        mgr.activate_task(parent.id, "t1")

        with pytest.raises(TaskError, match="exceeds parent"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
                expires_at=_clock(hour=18),
            )

    def test_child_inherits_wildcard_parent(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(tenant_id="t1", actor_id="a1")  # defaults: ["*"]
        mgr.activate_task(parent.id, "t1")

        child = mgr.create_child_task(
            parent_task_id=parent.id,
            tenant_id="t1",
            actor_id="a1",
            allowed_actions=["read", "write"],
            allowed_resource_types=["document"],
        )
        assert child.allowed_actions == ["read", "write"]

    def test_child_of_non_active_parent_raises(self) -> None:
        store = InMemoryTaskStore()
        mgr = TaskManager(task_store=store, clock=lambda: _clock())

        parent = mgr.create_task(tenant_id="t1", actor_id="a1")
        # Don't activate

        with pytest.raises(TaskError, match="not active"):
            mgr.create_child_task(
                parent_task_id=parent.id,
                tenant_id="t1",
                actor_id="a1",
            )
```

- [ ] **Step 2: Run tests to verify they fail**

Run: `pytest tests/unit/domain/services/test_task_manager.py -v`
Expected: ImportError.

- [ ] **Step 3: Implement TaskManager**

Create `src/open_guard/domain/services/task_manager.py`:

```python
"""TaskManager — lifecycle management for task-based access control."""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, timezone
from uuid import uuid4

from open_guard.domain.entities import ActorType, Task, TaskStatus
from open_guard.domain.exceptions import TaskError
from open_guard.domain.ports.task_store import TaskStorePort


class TaskManager:
    """Manages task lifecycle: create, activate, complete, fail, expire.

    Enforces state machine transitions and parent-child permission narrowing.

    Args:
        task_store: Storage for task state.
        clock: Optional callable returning current UTC datetime (for testing).
    """

    def __init__(
        self,
        task_store: TaskStorePort,
        clock: Callable[[], datetime] | None = None,
    ) -> None:
        self._task_store = task_store
        self._clock = clock or (lambda: datetime.now(timezone.utc))

    def create_task(
        self,
        tenant_id: str,
        actor_id: str,
        actor_type: ActorType = ActorType.AGENT,
        allowed_actions: list[str] | None = None,
        allowed_resource_types: list[str] | None = None,
        expires_at: datetime | None = None,
        metadata: dict | None = None,  # type: ignore[type-arg]
    ) -> Task:
        """Create a new task in CREATED state."""
        task = Task(
            id=str(uuid4()),
            tenant_id=tenant_id,
            actor_id=actor_id,
            actor_type=actor_type,
            status=TaskStatus.CREATED,
            allowed_actions=allowed_actions or ["*"],
            allowed_resource_types=allowed_resource_types or ["*"],
            created_at=self._clock(),
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return self._task_store.add(task)

    def activate_task(self, task_id: str, tenant_id: str) -> Task:
        """Transition task from CREATED to ACTIVE."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.CREATED:
            raise TaskError(
                f"Cannot activate task '{task_id}': status is '{task.status}', expected 'created'"
            )
        updated = task.model_copy(
            update={"status": TaskStatus.ACTIVE, "activated_at": self._clock()}
        )
        return self._task_store.update(updated)

    def complete_task(self, task_id: str, tenant_id: str) -> Task:
        """Transition task from ACTIVE to COMPLETED."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.ACTIVE:
            raise TaskError(
                f"Cannot complete task '{task_id}': status is '{task.status}', expected 'active'"
            )
        updated = task.model_copy(
            update={"status": TaskStatus.COMPLETED, "completed_at": self._clock()}
        )
        return self._task_store.update(updated)

    def fail_task(self, task_id: str, tenant_id: str) -> Task:
        """Transition task from ACTIVE to FAILED."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.ACTIVE:
            raise TaskError(
                f"Cannot fail task '{task_id}': status is '{task.status}', expected 'active'"
            )
        updated = task.model_copy(
            update={"status": TaskStatus.FAILED, "completed_at": self._clock()}
        )
        return self._task_store.update(updated)

    def check_expiry(self, task_id: str, tenant_id: str) -> Task:
        """Check if an active task has expired. Auto-transitions to EXPIRED if so."""
        task = self._get_task(task_id, tenant_id)
        if task.status != TaskStatus.ACTIVE:
            return task
        if task.expires_at is None:
            return task
        if self._clock() > task.expires_at:
            updated = task.model_copy(update={"status": TaskStatus.EXPIRED})
            return self._task_store.update(updated)
        return task

    def create_child_task(
        self,
        parent_task_id: str,
        tenant_id: str,
        actor_id: str,
        actor_type: ActorType = ActorType.AGENT,
        allowed_actions: list[str] | None = None,
        allowed_resource_types: list[str] | None = None,
        expires_at: datetime | None = None,
        metadata: dict | None = None,  # type: ignore[type-arg]
    ) -> Task:
        """Create a child task with permissions narrowed to parent's scope.

        Validates: child allowed_actions <= parent, child allowed_resource_types <= parent,
        child expires_at <= parent expires_at.
        """
        parent = self._get_task(parent_task_id, tenant_id)
        if parent.status != TaskStatus.ACTIVE:
            raise TaskError(
                f"Parent task '{parent_task_id}' is not active (status: '{parent.status}')"
            )

        child_actions = allowed_actions or ["*"]
        child_resources = allowed_resource_types or ["*"]

        self._validate_narrowing(parent, child_actions, child_resources, expires_at)

        task = Task(
            id=str(uuid4()),
            tenant_id=tenant_id,
            actor_id=actor_id,
            actor_type=actor_type,
            parent_task_id=parent_task_id,
            status=TaskStatus.CREATED,
            allowed_actions=child_actions,
            allowed_resource_types=child_resources,
            created_at=self._clock(),
            expires_at=expires_at,
            metadata=metadata or {},
        )
        return self._task_store.add(task)

    def _get_task(self, task_id: str, tenant_id: str) -> Task:
        task = self._task_store.get(task_id, tenant_id)
        if task is None:
            raise TaskError(f"Task '{task_id}' not found in tenant '{tenant_id}'")
        return task

    def _validate_narrowing(
        self,
        parent: Task,
        child_actions: list[str],
        child_resources: list[str],
        child_expires_at: datetime | None,
    ) -> None:
        """Validate child permissions don't exceed parent's scope."""
        # Actions narrowing
        if "*" not in parent.allowed_actions:
            if "*" in child_actions or not set(child_actions).issubset(
                set(parent.allowed_actions)
            ):
                raise TaskError(
                    f"Child actions {child_actions} exceeds parent scope {parent.allowed_actions}"
                )

        # Resource types narrowing
        if "*" not in parent.allowed_resource_types:
            if "*" in child_resources or not set(child_resources).issubset(
                set(parent.allowed_resource_types)
            ):
                raise TaskError(
                    f"Child resource types {child_resources} exceeds parent scope {parent.allowed_resource_types}"
                )

        # Expiry narrowing
        if parent.expires_at is not None and child_expires_at is not None:
            if child_expires_at > parent.expires_at:
                raise TaskError(
                    f"Child expires_at {child_expires_at} exceeds parent expires_at {parent.expires_at}"
                )
```

- [ ] **Step 4: Update services __init__.py**

Add to `src/open_guard/domain/services/__init__.py`:

```python
from open_guard.domain.services.task_manager import TaskManager
```

- [ ] **Step 5: Run tests to verify they pass**

Run: `pytest tests/unit/domain/services/test_task_manager.py -v`
Expected: All pass.

- [ ] **Step 6: Commit**

```bash
git add src/open_guard/domain/services/task_manager.py tests/unit/domain/services/test_task_manager.py src/open_guard/domain/services/__init__.py
git commit -m "feat(domain): add TaskManager with lifecycle and parent-child narrowing"
```

---

## Task 6: TBACEvaluator — Task-Scoped Policy Tests

**Files:**
- Modify: `tests/unit/adapters/evaluators/test_tbac.py`

This adds tests for the task-scoped evaluation path already implemented in Task 4.

- [ ] **Step 1: Add task-scoped policy tests**

Append to `tests/unit/adapters/evaluators/test_tbac.py`:

```python
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import Task, TaskStatus


def _active_task(
    task_id: str = "task-1",
    tenant_id: str = "t1",
    actor_id: str = "agent-1",
    allowed_actions: list[str] | None = None,
    allowed_resource_types: list[str] | None = None,
    expires_at: datetime | None = None,
) -> Task:
    return Task(
        id=task_id,
        tenant_id=tenant_id,
        actor_id=actor_id,
        status=TaskStatus.ACTIVE,
        allowed_actions=allowed_actions or ["*"],
        allowed_resource_types=allowed_resource_types or ["*"],
        created_at=_clock(),
        activated_at=_clock(),
        expires_at=expires_at,
    )


class TestTBACTaskScoping:
    def test_task_active_allows(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task())
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_task_not_found_denies(self) -> None:
        store = InMemoryTaskStore()
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "nonexistent"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_task_completed_denies(self) -> None:
        store = InMemoryTaskStore()
        task = Task(
            id="task-1",
            tenant_id="t1",
            actor_id="agent-1",
            status=TaskStatus.COMPLETED,
            created_at=_clock(),
            completed_at=_clock(),
        )
        store.add(task)
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_task_expired_auto_detected(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(expires_at=_clock(hour=11)))  # expired
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock(hour=12))

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

        # Verify task was auto-expired in store
        task = store.get("task-1", "t1")
        assert task is not None
        assert task.status == TaskStatus.EXPIRED

    def test_task_scoped_action_allowed(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(allowed_actions=["read", "write"]))
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(action="read"), [policy])
        assert result.allowed is True

    def test_task_scoped_action_denied(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(allowed_actions=["read"]))
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(action="delete"), [policy])
        assert result.allowed is False

    def test_task_scoped_resource_type_denied(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task(allowed_resource_types=["image"]))
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock())

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(resource_type="document"), [policy])
        assert result.allowed is False

    def test_no_task_store_denies_task_policy(self) -> None:
        evaluator = TBACEvaluator(clock=lambda: _clock())  # no task_store

        policy = _policy(conditions={"task_id": "task-1"})
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False

    def test_task_and_time_conditions_combined(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task())
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock(hour=10))

        policy = _policy(conditions={
            "task_id": "task-1",
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is True

    def test_task_passes_time_fails(self) -> None:
        store = InMemoryTaskStore()
        store.add(_active_task())
        evaluator = TBACEvaluator(task_store=store, clock=lambda: _clock(day=20))

        policy = _policy(conditions={
            "task_id": "task-1",
            "time_window": {
                "not_before": "2026-04-16T00:00:00Z",
                "not_after": "2026-04-17T00:00:00Z",
            },
        })
        result = evaluator.evaluate(_request(), [policy])
        assert result.allowed is False
```

- [ ] **Step 2: Run tests to verify they pass**

Run: `pytest tests/unit/adapters/evaluators/test_tbac.py -v`
Expected: All pass (both time and task tests).

- [ ] **Step 3: Commit**

```bash
git add tests/unit/adapters/evaluators/test_tbac.py
git commit -m "test(tbac): add task-scoped policy evaluation tests"
```

---

## Task 7: Public API Exports + Integration Tests

**Files:**
- Modify: `src/open_guard/__init__.py`
- Create: `tests/integration/test_tbac_integration.py`

- [ ] **Step 1: Update public API exports**

Add to `src/open_guard/__init__.py` imports:

```python
from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.adapters.stores.memory_task import InMemoryTaskStore as InMemoryTaskStore
from open_guard.domain.entities import Task, TaskStatus
from open_guard.domain.exceptions import TaskError
from open_guard.domain.ports.task_store import TaskStorePort
from open_guard.domain.services.task_manager import TaskManager
```

Add to `__all__`:

```python
"InMemoryTaskStore",  # (already exists for policy store — rename import or use full path)
"Task",
"TaskError",
"TaskManager",
"TaskStatus",
"TaskStorePort",
"TBACEvaluator",
```

Note: `InMemoryTaskStore` name conflicts with the policy store's `InMemoryPolicyStore` — no collision since they have different names. Add `InMemoryTaskStore` to `__all__`.

- [ ] **Step 2: Write integration tests**

Create `tests/integration/test_tbac_integration.py`:

```python
"""Integration tests — TBAC through Guard end-to-end."""

from datetime import datetime, timezone

from open_guard.adapters.evaluators.rbac import RBACEvaluator
from open_guard.adapters.evaluators.tbac import TBACEvaluator
from open_guard.adapters.stores.memory import InMemoryPolicyStore
from open_guard.adapters.stores.memory_task import InMemoryTaskStore
from open_guard.domain.entities import (
    Action,
    ActorType,
    Policy,
    PolicyEffect,
    Resource,
    Subject,
    Task,
    TaskStatus,
)
from open_guard.domain.services.guard import Guard
from open_guard.domain.services.task_manager import TaskManager


def _clock(hour: int = 12, day: int = 16) -> datetime:
    return datetime(2026, 4, day, hour, 0, 0, tzinfo=timezone.utc)


class TestTBACThroughGuard:
    def test_time_window_policy_allows(self) -> None:
        policy_store = InMemoryPolicyStore()
        tbac = TBACEvaluator(clock=lambda: _clock(hour=10))
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="read",
            conditions={
                "time_window": {
                    "not_before": "2026-04-16T00:00:00Z",
                    "not_after": "2026-04-17T00:00:00Z",
                },
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

    def test_time_window_policy_denies_outside(self) -> None:
        policy_store = InMemoryPolicyStore()
        tbac = TBACEvaluator(clock=lambda: _clock(day=20))
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="read",
            conditions={
                "time_window": {
                    "not_before": "2026-04-16T00:00:00Z",
                    "not_after": "2026-04-17T00:00:00Z",
                },
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_task_scoped_policy_with_guard(self) -> None:
        policy_store = InMemoryPolicyStore()
        task_store = InMemoryTaskStore()
        tbac = TBACEvaluator(task_store=task_store, clock=lambda: _clock())
        task_mgr = TaskManager(task_store=task_store, clock=lambda: _clock())
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        # Create and activate a task
        task = task_mgr.create_task(
            tenant_id="t1",
            actor_id="agent-1",
            allowed_actions=["read"],
            allowed_resource_types=["document"],
        )
        task = task_mgr.activate_task(task.id, "t1")

        # Add task-scoped policy
        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="read",
            conditions={"task_id": task.id},
        ))

        # Allowed: action and resource match task scope
        decision = guard.authorize(
            subject=Subject(id="agent-1", actor_type=ActorType.AGENT),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

        # Denied: action outside task scope
        decision = guard.authorize(
            subject=Subject(id="agent-1", actor_type=ActorType.AGENT),
            action=Action(name="delete"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_task_completed_revokes_access(self) -> None:
        policy_store = InMemoryPolicyStore()
        task_store = InMemoryTaskStore()
        tbac = TBACEvaluator(task_store=task_store, clock=lambda: _clock())
        task_mgr = TaskManager(task_store=task_store, clock=lambda: _clock())
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        task = task_mgr.create_task(tenant_id="t1", actor_id="agent-1")
        task = task_mgr.activate_task(task.id, "t1")

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="*",
            conditions={"task_id": task.id},
        ))

        # Allowed while active
        decision = guard.authorize(
            subject=Subject(id="agent-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True

        # Complete the task
        task_mgr.complete_task(task.id, "t1")

        # Denied after completion
        decision = guard.authorize(
            subject=Subject(id="agent-1"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is False

    def test_rbac_and_tbac_combined(self) -> None:
        """RBAC + TBAC evaluators work together through Guard."""
        policy_store = InMemoryPolicyStore()
        task_store = InMemoryTaskStore()
        rbac = RBACEvaluator()
        tbac = TBACEvaluator(task_store=task_store, clock=lambda: _clock(hour=10))
        guard = Guard(policy_store=policy_store, evaluators=[rbac, tbac])

        # RBAC allow
        policy_store.add(Policy(
            id="rbac-p1",
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="*",
        ))

        # TBAC deny (outside time window)
        policy_store.add(Policy(
            id="tbac-deny",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="*",
            effect=PolicyEffect.DENY,
            conditions={
                "time_window": {
                    "not_before": "2026-04-16T09:00:00Z",
                    "not_after": "2026-04-16T17:00:00Z",
                },
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-1", attributes={"roles": ["admin"]}),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        # RBAC allows, TBAC denies (within deny window) -> denied
        assert decision.allowed is False

    def test_schedule_with_timezone_through_guard(self) -> None:
        policy_store = InMemoryPolicyStore()
        # 2026-04-16 04:00 UTC = 09:30 IST
        tbac = TBACEvaluator(clock=lambda: _clock(hour=4))
        guard = Guard(policy_store=policy_store, evaluators=[tbac])

        policy_store.add(Policy(
            id="p1",
            tenant_id="t1",
            evaluator_type="tbac",
            action_match="*",
            conditions={
                "schedule": {
                    "days": [1, 2, 3, 4, 5],
                    "time_range": ["09:00", "18:00"],
                    "timezone": "Asia/Kolkata",
                }
            },
        ))

        decision = guard.authorize(
            subject=Subject(id="user-in"),
            action=Action(name="read"),
            resource=Resource(id="r1", resource_type="document"),
            tenant_id="t1",
        )
        assert decision.allowed is True
```

- [ ] **Step 3: Run all tests**

Run: `pytest -v`
Expected: All tests pass (existing 107 + new TBAC tests).

- [ ] **Step 4: Run type checking and linting**

Run: `mypy --strict src/` and `ruff check src/ tests/`
Expected: No errors.

- [ ] **Step 5: Run coverage**

Run: `pytest --cov=open_guard --cov-report=term-missing`
Expected: >95% coverage.

- [ ] **Step 6: Commit**

```bash
git add src/open_guard/__init__.py tests/integration/test_tbac_integration.py
git commit -m "feat: add TBAC public API exports and integration tests"
```

---

## Task 8: Final Verification + Cleanup

- [ ] **Step 1: Run full test suite**

Run: `pytest -v --tb=short`
Expected: All tests pass. Zero failures.

- [ ] **Step 2: Run mypy strict**

Run: `mypy --strict src/`
Expected: Success: no issues found.

- [ ] **Step 3: Run ruff**

Run: `ruff check src/ tests/`
Expected: All checks passed.

- [ ] **Step 4: Run coverage report**

Run: `pytest --cov=open_guard --cov-report=term-missing`
Expected: >95% coverage.

- [ ] **Step 5: Fix any issues found in steps 1-4**

Address mypy errors, ruff warnings, or coverage gaps. Common fixes:
- Add `# type: ignore[type-arg]` for `dict` in test helpers
- Ensure all new `__init__.py` files export properly
- Add edge case tests for uncovered branches

- [ ] **Step 6: Final commit**

```bash
git add -A
git commit -m "chore: phase 1 final cleanup and verification"
```
