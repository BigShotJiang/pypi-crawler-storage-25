# Phase 1 — TBAC (Time-Based + Task-Based Access Control)

> **Status**: Complete (v0.2.0)
> **Estimated Effort**: 5 days
> **Depends On**: Phase 0 (RBAC + ABAC Core) — v0.1.0

## Goal

Add time-based and task-based access control to open-guard. Time-based: policies with absolute time windows, recurring schedules (timezone-aware), and TTL/duration. Task-based: tasks as first-class domain objects with lifecycle state machines, permission scoping, parent-child hierarchy with narrowing, and auto-revocation on completion/expiry. Works for all actor types.

## Key Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Time handling | UTC internally, IANA timezone for recurring schedules | XACML/NIST standard. Avoids DST bugs. Python `zoneinfo` (stdlib). |
| Time constructs | Absolute windows, recurring schedules, TTL (ISO 8601 durations) | Covers all standard patterns. Cron expressions deferred (FEAT-004). |
| TBAC evaluator | Single evaluator handles both time + task conditions | Tightly coupled concerns. One `evaluator_type="tbac"`. |
| Task entity | Immutable (frozen Pydantic), state transitions create new instances | Follows existing entity pattern (Policy, Subject, etc.). |
| Task lifecycle | Created -> Active -> Completed/Failed/Expired | Thomas & Sandhu 1997 model. Auto-expire via TTL check at evaluation time. |
| Permission narrowing | Task has `allowed_actions` + `allowed_resource_types` lists | Simple, explicit. Child <= parent scope enforced by TaskManager. |
| Task store | New `TaskStorePort` + `InMemoryTaskStore` | Follows existing PolicyStorePort pattern. SQL adapter deferred to Phase 2. |
| Clock injection | `Callable[[], datetime]` parameter on evaluator + task manager | Enables deterministic testing without mocking `datetime`. |
| Evaluator dependency | TBACEvaluator takes `TaskStorePort` via constructor | Same pattern as RBACEvaluator taking `role_hierarchy`. |

## Source Structure

```
src/open_guard/
  domain/
    entities.py              # MODIFY — add TaskStatus, Task
    exceptions.py            # MODIFY — add TaskError
    ports/
      task_store.py          # NEW — TaskStorePort abstract interface
    services/
      task_manager.py        # NEW — task lifecycle management
  adapters/
    evaluators/
      tbac.py                # NEW — TBACEvaluator
    stores/
      memory_task.py         # NEW — InMemoryTaskStore
  __init__.py                # MODIFY — export new public API

tests/
  unit/
    domain/
      test_entities.py       # MODIFY — add Task/TaskStatus tests
      services/
        test_task_manager.py # NEW
    adapters/
      evaluators/
        test_tbac.py         # NEW
      stores/
        test_memory_task.py  # NEW
  integration/
    test_tbac_integration.py # NEW — end-to-end through Guard
```

## Scope

### In Scope
- `TBACEvaluator` implementing `EvaluatorPort` (plugs into existing PolicyRouter)
- Time conditions: absolute windows (`not_before`/`not_after`), recurring schedules (day + time + IANA timezone), TTL (ISO 8601 duration)
- `Task` domain entity with lifecycle state machine
- `TaskStorePort` + `InMemoryTaskStore`
- `TaskManager` service (create, activate, complete, fail, expire, create child)
- Parent-child task hierarchy with permission narrowing (child <= parent)
- Auto-expiration checked at evaluation time (lazy expiry)
- Clock injection for deterministic testing
- All actor types supported (user, agent, service, device, conversation)
- >95% test coverage, mypy --strict, ruff clean

### Out of Scope (Backlogged)
- Push/pull delegation patterns (FEAT-001)
- Usage-counted permissions (FEAT-002)
- Heartbeat/lease renewal (FEAT-003)
- Cron expression schedules (FEAT-004)
- SQL-backed task store (Phase 2)
- FastAPI task management endpoints (Phase 2 or later)

## Deliverables

| Deliverable | Verification |
|-------------|-------------|
| TBACEvaluator handles time + task policies | `pytest tests/unit/adapters/evaluators/test_tbac.py -v` |
| Task lifecycle works correctly | `pytest tests/unit/domain/services/test_task_manager.py -v` |
| InMemoryTaskStore stores/retrieves tasks | `pytest tests/unit/adapters/stores/test_memory_task.py -v` |
| End-to-end TBAC through Guard | `pytest tests/integration/test_tbac_integration.py -v` |
| All existing tests pass (no regression) | `pytest -v` |
| Type safety | `mypy --strict src/` |
| Code quality | `ruff check src/ tests/` |
| >95% coverage | `pytest --cov=open_guard --cov-report=term-missing` |

## Acceptance Criteria

1. `TBACEvaluator` implements `EvaluatorPort` and plugs into existing `PolicyRouter` with zero changes to RBAC/ABAC code
2. Time-based policies correctly enforce absolute windows, recurring schedules (with IANA timezone + DST handling), and TTL expiry
3. `Task` entity has a clean lifecycle: created -> active -> completed/failed/expired
4. Task-scoped policies are only active when the referenced task is in `active` status
5. Parent-child task hierarchy enforces permission narrowing (child `allowed_actions` <= parent, child `allowed_resource_types` <= parent, child `expires_at` <= parent)
6. Auto-expiration: expired tasks are detected and marked at evaluation time
7. Works for all actor types (user, agent, service, device, conversation)
8. Tests: >95% coverage, mypy --strict clean, ruff clean
9. All existing 107 RBAC + ABAC tests still pass

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/architecture/auth-model.md` | TBAC and ReBAC sections define the target model |
| Thomas & Sandhu 1997 (TBAC) | Academic foundation for task lifecycle model |
| XACML 3.0 (OASIS) | Time condition patterns (environment attributes) |
| NIST SP 800-162 | Time as ABAC environment attribute |
| ISO 8601 | Duration format (`PT2H`), datetime format |
