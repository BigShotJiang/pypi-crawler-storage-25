# Phase 1 — TBAC: Task Checklist

> Mirror of plan.md tasks. Mark `[x]` when done, `[/]` when in progress.

## Task 1: Domain Entities — TaskStatus + Task
- [x] Write failing tests for TaskStatus and Task
- [x] Run tests to verify they fail
- [x] Implement TaskStatus and Task in entities.py
- [x] Run tests to verify they pass
- [x] Commit

## Task 2: TaskError Exception
- [x] Add TaskError to exceptions.py
- [x] Run existing tests (no regression)
- [x] Commit

## Task 3: TaskStorePort + InMemoryTaskStore
- [x] Write failing tests for InMemoryTaskStore
- [x] Run tests to verify they fail
- [x] Implement TaskStorePort
- [x] Implement InMemoryTaskStore
- [x] Update port and adapter __init__.py
- [x] Run tests to verify they pass
- [x] Commit

## Task 4: TBACEvaluator — Time Conditions
- [x] Write failing tests (time window, schedule, TTL, combined)
- [x] Run tests to verify they fail
- [x] Implement TBACEvaluator with time condition evaluation
- [x] Update evaluators __init__.py
- [x] Run tests to verify they pass
- [x] Commit

## Task 5: TaskManager Service
- [x] Write failing tests (create, activate, complete, fail, expire, child tasks)
- [x] Run tests to verify they fail
- [x] Implement TaskManager
- [x] Update services __init__.py
- [x] Run tests to verify they pass
- [x] Commit

## Task 6: TBACEvaluator — Task-Scoped Policy Tests
- [x] Add task-scoped evaluation tests
- [x] Run tests to verify they pass
- [x] Commit

## Task 7: Public API Exports + Integration Tests
- [x] Update __init__.py exports
- [x] Write integration tests (Guard + TBAC end-to-end)
- [x] Run all tests
- [x] Run mypy --strict
- [x] Run ruff
- [x] Run coverage
- [x] Commit

## Task 8: Final Verification + Cleanup
- [x] Full test suite passes (178 tests)
- [x] mypy --strict clean
- [x] ruff clean
- [x] >95% coverage (98%)
- [x] Fix any issues
- [x] Final commit
