# Phase 1 Retrospective — TBAC (Time + Task Access Control)

> **Completed**: 2026-04-16
> **Version**: v0.2.0

## What Went Well

- **Clean architecture payoff**: TBACEvaluator plugged into existing PolicyRouter with zero changes to RBAC/ABAC code — the EvaluatorPort abstraction worked exactly as designed
- **TDD discipline**: Writing tests first for every component caught issues early (e.g., clock injection pattern made all time logic deterministic from the start)
- **Standards alignment**: Thomas & Sandhu task lifecycle model and XACML/NIST time patterns provided a solid foundation — no design ambiguity
- **Scope discipline**: Deferred advanced features (delegation, usage-counting, heartbeat, cron) to backlog rather than scope-creeping Phase 1
- **High coverage maintained**: 98% coverage with 178 tests (71 new), mypy --strict and ruff clean throughout

## What Didn't Go Well

- **Ruff lint issues on first pass**: Initial code had SIM102 (nested if), E501 (line length), and UP017 (timezone.utc → UTC) violations — could have been avoided by running ruff earlier in the cycle
- **Integration guide still a stub**: Not enough content yet to justify filling it out — will need attention in Phase 2+

## Lessons Learned

1. **Run ruff after each task, not just at the end** — saves cleanup time
2. **Clock injection is essential for time-based logic** — should be a standard pattern for any time-dependent evaluator
3. **Parent-child narrowing validation is straightforward with frozen Pydantic models** — model_copy(update={}) pattern works cleanly for state transitions
4. **Auto-expiry at evaluation time (lazy expiry) is simpler than background expiry** — no background threads needed, works with any store

## Metrics

| Metric | Phase 0 | Phase 1 | Delta |
|--------|---------|---------|-------|
| Tests | 107 | 178 | +71 |
| Coverage | 98% | 98% | same |
| Source files | 15 | 20 | +5 |
| New entities | — | Task, TaskStatus | +2 |
| New ports | — | TaskStorePort | +1 |
| New evaluators | — | TBACEvaluator | +1 |
| New services | — | TaskManager | +1 |
| New stores | — | InMemoryTaskStore | +1 |

## Delivered

- TBACEvaluator: time windows (absolute), recurring schedules (IANA timezone), TTL (ISO 8601 duration)
- Task entity with lifecycle state machine (created → active → completed/failed/expired)
- TaskStorePort + InMemoryTaskStore (thread-safe, tenant-scoped)
- TaskManager service (create, activate, complete, fail, expire, create_child)
- Parent-child task hierarchy with permission narrowing
- Auto-expiration at evaluation time
- Clock injection for deterministic testing
- All actor types supported
- Public API exports for all new types
- 6 end-to-end integration tests through Guard
