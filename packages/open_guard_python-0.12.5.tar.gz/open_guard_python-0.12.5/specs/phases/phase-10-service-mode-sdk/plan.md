# Phase 10 — Service Mode + Python SDK: Implementation Plan

> **Approach**: Build inside-out. (1) Decision schemas + service skeleton, (2) auth, (3) DecisionRouter, (4) AdminRouter mount + prefix, (5) error envelope + tenancy, (6) SDK base + namespaces, (7) e2e + docs. Each task is independently committable; auth lands before routers so endpoints are protected from day one.
> **Breaking changes**: None. All additions are new modules + new optional extras. `AdminRouter` gains an optional prefix parameter, default unchanged.
> **Commit convention**: `feat(service):`, `feat(client):`, `refactor(api):`, `docs:`, `test:`, `chore:`.

---

## Task 1: Service skeleton + ServiceConfig (FEAT-012a)

**Why first**: Establishes the module boundary and the `create_app` factory that every later task plugs into.

### 1.1 Create `src/open_guard/service/__init__.py`

Re-export `create_app`, `ServiceConfig`, `AuthBackend`, `CallerContext`.

### 1.2 Create `src/open_guard/service/version.py`

```python
SERVICE_API_VERSION = "v1"
DEFAULT_PREFIX = f"/{SERVICE_API_VERSION}"
```

### 1.3 Create `src/open_guard/service/app.py`

```python
from dataclasses import dataclass, field
from typing import Any
from fastapi import FastAPI

from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.guard import Guard, AsyncGuard
from .auth import AuthBackend
from .decision_router import build_decision_router
from .errors import install_exception_handlers
from .version import DEFAULT_PREFIX

@dataclass
class ServiceConfig:
    prefix: str = DEFAULT_PREFIX
    title: str = "open-guard"
    docs_url: str | None = "/docs"
    openapi_url: str | None = "/openapi.json"
    expose_admin: bool = True

def create_app(
    *,
    guard: Guard | AsyncGuard,
    admin: PolicyAdmin | None = None,
    auth: AuthBackend,
    config: ServiceConfig | None = None,
) -> FastAPI:
    cfg = config or ServiceConfig()
    app = FastAPI(title=cfg.title, docs_url=cfg.docs_url, openapi_url=cfg.openapi_url)

    install_exception_handlers(app)

    decision_router = build_decision_router(guard=guard, auth=auth)
    app.include_router(decision_router, prefix=cfg.prefix)

    if cfg.expose_admin and admin is not None:
        from open_guard.api.fastapi.admin_router import build_admin_router
        admin_router = build_admin_router(admin=admin, auth=auth)
        app.include_router(admin_router, prefix=f"{cfg.prefix}/admin")

    return app
```

### 1.4 Tests — `tests/service/test_app_factory.py`

- `create_app` returns a FastAPI instance
- `/openapi.json` lists Decision endpoints
- `expose_admin=False` omits admin paths
- Custom `prefix="/openguard/v1"` mounts everything under it
- Missing `auth` raises clearly

**Commit**: `feat(service): add create_app factory + ServiceConfig (FEAT-012a)`

---

## Task 2: Auth backend protocol + ApiKeyAuth (FEAT-012d)

**Why second**: Routers depend on the FastAPI auth dependency. Build the contract + the simplest impl first.

### 2.1 `src/open_guard/service/auth/__init__.py` — protocol + caller context

```python
from dataclasses import dataclass, field
from typing import Protocol, Sequence
from fastapi import Request

@dataclass(frozen=True)
class CallerContext:
    tenant_id: str
    service_identity: str          # e.g. "service:cerebrio-sapience"
    scopes: frozenset[str] = field(default_factory=frozenset)

    def has_scope(self, name: str) -> bool:
        return name in self.scopes

class AuthBackend(Protocol):
    async def authenticate(self, request: Request) -> CallerContext:
        """Raise AuthenticationError on invalid/missing credentials."""
        ...
```

### 2.2 `src/open_guard/service/auth/api_key.py`

```python
import hashlib, hmac, secrets
from dataclasses import dataclass
from fastapi import Request
from .api_key_store import ApiKeyStorePort, ApiKeyRecord
from open_guard.service.errors import AuthenticationError
from open_guard.service.auth import AuthBackend, CallerContext

class ApiKeyAuth(AuthBackend):
    def __init__(self, store: ApiKeyStorePort) -> None:
        self._store = store

    async def authenticate(self, request: Request) -> CallerContext:
        header = request.headers.get("Authorization", "")
        if not header.startswith("ApiKey "):
            raise AuthenticationError("missing_api_key")
        raw = header.removeprefix("ApiKey ").strip()
        digest = hashlib.sha256(raw.encode()).hexdigest()
        record = await self._store.get_by_hash(digest)
        if record is None or record.revoked:
            raise AuthenticationError("invalid_api_key")
        return CallerContext(
            tenant_id=record.tenant_id,
            service_identity=record.service_identity,
            scopes=frozenset(record.scopes),
        )

    @staticmethod
    def generate() -> tuple[str, str]:
        """Returns (cleartext, sha256_hash). Cleartext shown to user once."""
        cleartext = "og_" + secrets.token_urlsafe(32)
        return cleartext, hashlib.sha256(cleartext.encode()).hexdigest()
```

### 2.3 `src/open_guard/service/auth/api_key_store.py`

```python
from dataclasses import dataclass, field
from datetime import datetime
from typing import Protocol

@dataclass
class ApiKeyRecord:
    key_hash: str
    tenant_id: str
    service_identity: str
    scopes: list[str] = field(default_factory=list)
    created_at: datetime | None = None
    revoked: bool = False

class ApiKeyStorePort(Protocol):
    async def get_by_hash(self, key_hash: str) -> ApiKeyRecord | None: ...
    async def add(self, record: ApiKeyRecord) -> None: ...
    async def revoke(self, key_hash: str) -> None: ...
    async def list_for_tenant(self, tenant_id: str) -> list[ApiKeyRecord]: ...

class InMemoryApiKeyStore(ApiKeyStorePort):
    def __init__(self) -> None:
        self._records: dict[str, ApiKeyRecord] = {}

    async def get_by_hash(self, key_hash: str) -> ApiKeyRecord | None:
        return self._records.get(key_hash)

    async def add(self, record: ApiKeyRecord) -> None:
        self._records[record.key_hash] = record

    async def revoke(self, key_hash: str) -> None:
        if key_hash in self._records:
            self._records[key_hash].revoked = True

    async def list_for_tenant(self, tenant_id: str) -> list[ApiKeyRecord]:
        return [r for r in self._records.values() if r.tenant_id == tenant_id]
```

(SQL-backed `ApiKeyStore` can land in Phase 11 if real consumers ask; Phase 10 ships memory only — small surface, easy to extend.)

### 2.4 `src/open_guard/service/auth/byo.py`

```python
from typing import Awaitable, Callable
from fastapi import Request
from open_guard.service.auth import AuthBackend, CallerContext

class CallableAuth(AuthBackend):
    """BYO auth — consumer supplies a callable that returns CallerContext."""
    def __init__(self, fn: Callable[[Request], Awaitable[CallerContext]]) -> None:
        self._fn = fn

    async def authenticate(self, request: Request) -> CallerContext:
        return await self._fn(request)
```

### 2.5 `src/open_guard/service/auth/shield.py` (optional `[shield]` extra)

```python
try:
    from open_shield import TokenValidator  # placeholder import; pin actual API at impl time
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "ShieldAuth requires `pip install open-guard[shield]`"
    ) from exc

from fastapi import Request
from open_guard.service.auth import AuthBackend, CallerContext
from open_guard.service.errors import AuthenticationError

class ShieldAuth(AuthBackend):
    def __init__(
        self,
        validator: "TokenValidator",
        *,
        tenant_claim: str = "tenant_id",
        identity_claim: str = "sub",
        scopes_claim: str = "scope",
    ) -> None:
        self._validator = validator
        self._tenant_claim = tenant_claim
        self._identity_claim = identity_claim
        self._scopes_claim = scopes_claim

    async def authenticate(self, request: Request) -> CallerContext:
        header = request.headers.get("Authorization", "")
        if not header.startswith("Bearer "):
            raise AuthenticationError("missing_bearer_token")
        token = header.removeprefix("Bearer ").strip()
        try:
            claims = await self._validator.validate(token)
        except Exception as exc:
            raise AuthenticationError("invalid_token") from exc
        scopes_value = claims.get(self._scopes_claim, "")
        if isinstance(scopes_value, str):
            scopes = frozenset(scopes_value.split())
        else:
            scopes = frozenset(scopes_value or ())
        return CallerContext(
            tenant_id=str(claims[self._tenant_claim]),
            service_identity=str(claims[self._identity_claim]),
            scopes=scopes,
        )
```

> **Note on open-shield API**: pin the validator import at implementation time after reading open-shield's current public surface. Above is the shape the wrapper takes; the `validator.validate(token)` call may need adjustment.

### 2.6 FastAPI dependency factory — `src/open_guard/service/auth/dep.py`

```python
from fastapi import Depends, Request
from . import AuthBackend, CallerContext

def make_auth_dep(auth: AuthBackend):
    async def _dep(request: Request) -> CallerContext:
        return await auth.authenticate(request)
    return _dep
```

### 2.7 Tests

- `tests/service/test_auth_apikey.py` — generate, validate, revoke, missing header, malformed header, wrong key
- `tests/service/test_auth_byo.py` — callable returns CallerContext, can raise
- `tests/service/test_auth_shield.py` — `pytest.importorskip("open_shield")`; mock validator; valid + invalid + missing token

**Commit**: `feat(service): add AuthBackend protocol + ApiKeyAuth + CallableAuth + ShieldAuth (FEAT-012d)`

---

## Task 3: Tenant context + cross-tenant admin override (FEAT-012e)

### 3.1 `src/open_guard/service/tenant.py`

```python
from fastapi import Depends, Request, HTTPException
from .auth import CallerContext
from .auth.dep import make_auth_dep
from .errors import AuthorizationServiceError

CROSS_TENANT_ADMIN_SCOPE = "cross_tenant_admin"

def make_tenant_dep(auth):
    auth_dep = make_auth_dep(auth)

    async def _dep(
        request: Request,
        caller: CallerContext = Depends(auth_dep),
    ) -> tuple[CallerContext, str]:
        override = request.headers.get("X-Tenant-ID")
        if override and override != caller.tenant_id:
            if not caller.has_scope(CROSS_TENANT_ADMIN_SCOPE):
                raise AuthorizationServiceError(
                    code="cross_tenant_forbidden",
                    message="X-Tenant-ID override requires cross_tenant_admin scope",
                    status_code=403,
                )
            return caller, override
        return caller, caller.tenant_id

    return _dep
```

### 3.2 Tests — `tests/service/test_tenant_routing.py`

- No header → tenant from caller
- Header same as caller tenant → ok
- Header different + no scope → 403
- Header different + scope → effective tenant = header
- Request body `tenant_id` field stripped/ignored

**Commit**: `feat(service): add tenant context resolution with admin override (FEAT-012e)`

---

## Task 4: DecisionRouter (FEAT-012b)

### 4.1 Schemas — `src/open_guard/service/schemas.py`

Mirror existing entity Pydantic models; reuse `Subject`, `Action`, `Resource` directly where possible. New request models:

```python
from pydantic import BaseModel, Field
from typing import Any
from open_guard.domain.entities import Subject, Action, Resource

class AuthorizeRequest(BaseModel):
    subject: Subject
    action: Action
    resource: Resource
    session_id: str | None = None
    chain_depth_max: int | None = None

class AuthorizeResponse(BaseModel):
    status: str  # "ALLOWED" | "DENIED" | "PENDING_APPROVAL"
    allowed: bool
    reason: str | None = None
    approval_request_id: str | None = None

class AuthorizeTracedResponse(AuthorizeResponse):
    trace: dict[str, Any]  # DecisionTrace.model_dump()

class ListAuthorizedRequest(BaseModel):
    subject: Subject
    action: Action
    resource_type: str
    cursor: str | None = None
    limit: int = Field(default=100, ge=1, le=1000)

class ListAuthorizedResponse(BaseModel):
    resource_ids: list[str]
    next_cursor: str | None = None

class AuthorizeAndConsumeRequest(AuthorizeRequest):
    units: int = 1
    budget_cost: str | None = None  # Decimal as string

class AuthorizeAndConsumeResponse(AuthorizeResponse):
    consumed_delegation_ids: list[str] = []
```

### 4.2 Router — `src/open_guard/service/decision_router.py`

```python
import asyncio
from fastapi import APIRouter, Depends
from typing import Any

from open_guard.guard import Guard, AsyncGuard
from .schemas import (
    AuthorizeRequest, AuthorizeResponse,
    AuthorizeTracedResponse,
    ListAuthorizedRequest, ListAuthorizedResponse,
    AuthorizeAndConsumeRequest, AuthorizeAndConsumeResponse,
)
from .tenant import make_tenant_dep
from .auth import AuthBackend, CallerContext

def build_decision_router(*, guard: Guard | AsyncGuard, auth: AuthBackend) -> APIRouter:
    router = APIRouter(tags=["decisions"])
    tenant_dep = make_tenant_dep(auth)
    is_async = isinstance(guard, AsyncGuard)

    @router.post("/authorize", response_model=AuthorizeResponse)
    async def authorize(
        body: AuthorizeRequest,
        ctx: tuple[CallerContext, str] = Depends(tenant_dep),
    ) -> AuthorizeResponse:
        _caller, tenant_id = ctx
        body.subject.tenant_id = tenant_id   # tenant from auth claim, never trust body
        if is_async:
            decision = await guard.authorize(body.subject, body.action, body.resource,
                                             session_id=body.session_id)
        else:
            decision = await asyncio.to_thread(
                guard.authorize, body.subject, body.action, body.resource,
                session_id=body.session_id,
            )
        return AuthorizeResponse(
            status=decision.status.value,
            allowed=decision.allowed,
            reason=decision.reason,
            approval_request_id=decision.approval_request_id,
        )

    @router.post("/authorize/traced", response_model=AuthorizeTracedResponse)
    async def authorize_traced(...): ...   # parallel structure

    @router.post("/list_authorized", response_model=ListAuthorizedResponse)
    async def list_authorized(...): ...

    @router.post("/authorize_and_consume", response_model=AuthorizeAndConsumeResponse)
    async def authorize_and_consume(...): ...

    return router
```

### 4.3 Tests — `tests/service/test_decision_router.py`

For each endpoint × `Guard` and `AsyncGuard`:
- happy path matches in-process result
- 401 without auth
- 403 when tenant override without scope
- 422 on malformed body
- pending-approval path returns ALLOWED=False + approval_request_id

**Commit**: `feat(service): add DecisionRouter for runtime endpoints (FEAT-012b)`

---

## Task 5: AdminRouter prefix injection (FEAT-012c)

### 5.1 Modify `src/open_guard/api/fastapi/admin_router.py`

Today the admin router has hardcoded path prefixes inside route decorators. Refactor: define one APIRouter with no top-level prefix, mount at whatever caller chooses via `app.include_router(prefix=...)`. Keep the existing public `build_admin_router(admin)` signature backward-compatible — just stop hard-coding `/admin` inside.

### 5.2 Wire in `create_app`: `prefix=f"{cfg.prefix}/admin"`

### 5.3 Add auth dependency to AdminRouter

Currently AdminRouter has no auth. Add the same tenant_dep so admin endpoints require auth + tenant just like decisions.

### 5.4 Tests — `tests/service/test_admin_router_mount.py` + `test_prefix_configurable.py`

- Default prefix: `/v1/admin/policies` works
- Custom prefix `/openguard/v1`: `/openguard/v1/admin/policies` works
- `expose_admin=False`: no admin routes
- Existing `tests/test_admin_router.py` still passes

**Commit**: `refactor(api): allow AdminRouter to mount under arbitrary prefix (FEAT-012c)`

---

## Task 6: Error envelope + exception handlers

### 6.1 `src/open_guard/service/errors.py`

```python
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError

class ServiceError(Exception):
    code: str = "internal_error"
    status_code: int = 500
    def __init__(self, message: str = "", *, code: str | None = None,
                 status_code: int | None = None, details: dict | None = None):
        super().__init__(message)
        if code: self.code = code
        if status_code: self.status_code = status_code
        self.message = message
        self.details = details

class AuthenticationError(ServiceError):
    code = "authentication_failed"
    status_code = 401

class AuthorizationServiceError(ServiceError):
    code = "forbidden"
    status_code = 403

class NotFoundError(ServiceError):
    code = "not_found"
    status_code = 404

def install_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(ServiceError)
    async def _service_err(_: Request, exc: ServiceError):
        return JSONResponse(
            status_code=exc.status_code,
            content={"error": {"code": exc.code, "message": exc.message,
                               "details": exc.details}},
        )

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        return JSONResponse(
            status_code=422,
            content={"error": {"code": "validation_error",
                               "message": "Request body failed validation",
                               "details": {"errors": exc.errors()}}},
        )
```

### 6.2 Tests — `tests/service/test_error_envelope.py`

- Each ServiceError subclass produces the envelope with correct status + code
- 422 from FastAPI validation hits the custom handler
- Unhandled exception → 500 envelope (no traceback leak)

**Commit**: `feat(service): error envelope + FastAPI exception handlers`

---

## Task 7: SDK base client + auth helpers (FEAT-013-py)

### 7.1 `src/open_guard/client/exceptions.py`

```python
class OpenGuardError(Exception):
    code: str
    status_code: int | None
    details: dict | None
    def __init__(self, message: str, *, code: str = "unknown",
                 status_code: int | None = None, details: dict | None = None):
        super().__init__(message)
        self.code, self.status_code, self.details = code, status_code, details

class AuthenticationError(OpenGuardError): ...
class AuthorizationServiceError(OpenGuardError): ...
class NotFoundError(OpenGuardError): ...
class ValidationError(OpenGuardError): ...
class RateLimitedError(OpenGuardError): ...
class ServerError(OpenGuardError): ...
class TransportError(OpenGuardError): ...
```

### 7.2 `src/open_guard/client/retry.py`

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class RetryPolicy:
    attempts: int = 3
    base_delay: float = 0.1
    max_delay: float = 2.0
    retry_on_status: frozenset[int] = frozenset({502, 503, 504})
    retry_on_connection_error: bool = True
    idempotent_only: bool = True
```

### 7.3 `src/open_guard/client/base.py` — auth helpers

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class ClientAuth:
    header_name: str
    header_value: str

def ApiKey(key: str) -> ClientAuth:
    return ClientAuth("Authorization", f"ApiKey {key}")

def BearerToken(token: str) -> ClientAuth:
    return ClientAuth("Authorization", f"Bearer {token}")
```

### 7.4 `_BaseClient` — URL building, error mapping (in `base.py`)

Single class holds `base_url`, `prefix`, `auth: ClientAuth`, `retry: RetryPolicy`. Provides `_path(...) -> str` and `_map_error(response)`. No HTTP client — sync and async wrappers own their own httpx instance.

```python
class _BaseClient:
    def __init__(self, base_url: str, *, auth: ClientAuth,
                 prefix: str = "/v1", retry: RetryPolicy = RetryPolicy()):
        self._base_url = base_url.rstrip("/")
        self._prefix = prefix
        self._auth = auth
        self._retry = retry
        self._headers = {auth.header_name: auth.header_value}

    def _url(self, path: str) -> str:
        return f"{self._base_url}{self._prefix}{path}"

    def _map_error(self, status: int, body: dict | None) -> Exception:
        err = (body or {}).get("error") or {}
        code = err.get("code", "unknown")
        msg = err.get("message", f"HTTP {status}")
        details = err.get("details")
        cls = {
            401: AuthenticationError, 403: AuthorizationServiceError,
            404: NotFoundError, 422: ValidationError, 429: RateLimitedError,
        }.get(status, ServerError if status >= 500 else OpenGuardError)
        return cls(msg, code=code, status_code=status, details=details)
```

**Commit**: `feat(client): SDK base client + auth helpers + retry policy + exception hierarchy`

---

## Task 8: Sync + Async clients with namespaces (FEAT-013-py)

### 8.1 `src/open_guard/client/sync_client.py`

```python
import time, random
import httpx
from .base import _BaseClient, ClientAuth, RetryPolicy
from .exceptions import TransportError, ServerError
from .namespaces.decisions import DecisionsAPI
from .namespaces.admin import AdminAPI

class OpenGuardClient(_BaseClient):
    def __init__(self, base_url: str, *, auth: ClientAuth, prefix: str = "/v1",
                 retry: RetryPolicy = RetryPolicy(), timeout: float = 5.0):
        super().__init__(base_url, auth=auth, prefix=prefix, retry=retry)
        self._http = httpx.Client(timeout=timeout, headers=self._headers)
        self.decisions = DecisionsAPI(self)
        self.admin = AdminAPI(self)

    def __enter__(self): return self
    def __exit__(self, *_): self.close()
    def close(self): self._http.close()

    def _request(self, method: str, path: str, *, json=None, params=None,
                 idempotent: bool = True) -> dict:
        url = self._url(path)
        attempts = self._retry.attempts if (idempotent or not self._retry.idempotent_only) else 1
        last_exc: Exception | None = None
        for i in range(attempts):
            try:
                resp = self._http.request(method, url, json=json, params=params)
            except httpx.HTTPError as exc:
                last_exc = TransportError(str(exc), code="transport_error")
                if not self._retry.retry_on_connection_error: raise last_exc
            else:
                if resp.status_code < 400:
                    return resp.json() if resp.content else {}
                if resp.status_code in self._retry.retry_on_status and i < attempts - 1:
                    pass
                else:
                    body = resp.json() if resp.content else None
                    raise self._map_error(resp.status_code, body)
            delay = min(self._retry.base_delay * (2 ** i), self._retry.max_delay)
            time.sleep(delay + random.uniform(0, delay * 0.1))
        raise last_exc or ServerError("retries exhausted", code="retries_exhausted")
```

### 8.2 `src/open_guard/client/async_client.py`

Mirror with `httpx.AsyncClient` + `asyncio.sleep`. Same namespaces (each namespace class has both `def` and `async def` implementations or two classes — see 8.3).

### 8.3 Namespaces — `src/open_guard/client/namespaces/`

Two-class pattern per namespace (sync + async). Example for decisions:

```python
# decisions.py
class DecisionsAPI:
    def __init__(self, client): self._c = client

    def authorize(self, *, subject, action, resource, session_id=None) -> dict:
        body = {"subject": subject, "action": action, "resource": resource}
        if session_id: body["session_id"] = session_id
        return self._c._request("POST", "/authorize", json=body)

    def authorize_traced(self, **kw) -> dict:
        return self._c._request("POST", "/authorize/traced", json=kw)

    def list_authorized(self, *, subject, action, resource_type,
                        cursor=None, limit=100) -> dict:
        return self._c._request("POST", "/list_authorized", json={
            "subject": subject, "action": action,
            "resource_type": resource_type, "cursor": cursor, "limit": limit,
        })

    def authorize_and_consume(self, *, units=1, budget_cost=None, **kw) -> dict:
        body = {**kw, "units": units, "budget_cost": budget_cost}
        return self._c._request("POST", "/authorize_and_consume", json=body,
                                idempotent=False)

class AsyncDecisionsAPI:
    # same methods, async; awaits self._c._request(...)
    ...
```

Admin namespace is a small struct of sub-namespaces:

```python
# admin.py
class AdminAPI:
    def __init__(self, client):
        self.policies = PoliciesAPI(client)
        self.roles = RolesAPI(client)
        self.relationships = RelationshipsAPI(client)
        self.delegations = DelegationsAPI(client)
        self.sessions = SessionsAPI(client)
```

Each sub-namespace exposes the corresponding AdminRouter endpoints (list/create/delete + check_relationship).

### 8.4 Tests

- `tests/client/test_sync_client.py` — every endpoint, against an in-memory ASGI service via `httpx.MockTransport` or actual `create_app`
- `tests/client/test_async_client.py` — same, async
- `tests/client/test_namespacing.py` — `client.decisions.authorize` exists; `client.admin.policies.create` exists; `client.authorize` does **not** exist (no flat shortcut)
- `tests/client/test_retry.py` — `MockTransport` returning 503 then 200; assert 2 attempts, success
- `tests/client/test_error_mapping.py` — service returns each status; SDK raises the right exception subclass with `.code` populated
- `tests/client/test_auth_headers.py` — `ApiKey("og_x")` produces `Authorization: ApiKey og_x`; `BearerToken("eyJ")` produces `Bearer eyJ`

**Commit**: `feat(client): sync + async clients with namespaced API (FEAT-013-py)`

---

## Task 9: E2E tests

### 9.1 `tests/e2e/test_service_client_e2e.py`

```python
import pytest
from httpx import ASGITransport, AsyncClient

from open_guard.guard import Guard
from open_guard.adapters.factory import build_guard
from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.service.app import create_app
from open_guard.service.auth.api_key import ApiKeyAuth, InMemoryApiKeyStore, ApiKeyRecord
from open_guard.client.sync_client import OpenGuardClient
from open_guard.client.base import ApiKey

@pytest.fixture
def service_with_key():
    guard = build_guard()
    admin = PolicyAdmin(...)
    store = InMemoryApiKeyStore()
    cleartext, digest = ApiKeyAuth.generate()
    asyncio.run(store.add(ApiKeyRecord(
        key_hash=digest, tenant_id="t1",
        service_identity="svc", scopes=[],
    )))
    app = create_app(guard=guard, admin=admin, auth=ApiKeyAuth(store))
    return app, cleartext

def test_full_authorize_flow_through_sdk(service_with_key):
    app, key = service_with_key
    # Use an in-process transport — no network
    with httpx.Client(transport=httpx.WSGITransport(app=app), base_url="http://t") as http:
        client = OpenGuardClient.__from_existing__(http, auth=ApiKey(key))   # test helper
        # admin: create a policy
        client.admin.policies.create(...)
        # decision: authorize
        result = client.decisions.authorize(subject=..., action=..., resource=...)
        assert result["allowed"] is True
```

(Pattern: use httpx ASGI transport so tests run without a network port.)

### 9.2 `tests/e2e/test_service_sql_e2e.py`

Same flow but `build_async_guard("sqlite+aiosqlite:///./e2e.db")`. Verifies SQL backend round-trip survives the wire.

**Commit**: `test(e2e): SDK -> service -> backend round-trip tests`

---

## Task 10: Reference Dockerfile

### 10.1 `deploy/service/Dockerfile`

```dockerfile
FROM python:3.12-slim
WORKDIR /app
RUN pip install --no-cache-dir 'open-guard[service,sql-async,shield]'
COPY entrypoint.py /app/entrypoint.py
EXPOSE 8000
CMD ["uvicorn", "entrypoint:app", "--host", "0.0.0.0", "--port", "8000"]
```

### 10.2 `deploy/service/entrypoint.example.py`

Reference snippet showing how to wire `build_async_guard(dsn=os.environ["OPEN_GUARD_DSN"])`, `ApiKeyAuth`, and `create_app`.

### 10.3 README under `deploy/service/`

Short — env vars table, build command, docker-compose example, "this is a starting point, customize for your platform."

**Commit**: `docs(deploy): reference Dockerfile + entrypoint for service mode`

---

## Task 11: Integration guide section + executable mirrors

### 11.1 Append to `specs/architecture/integration-guide.md`

New section: **"Phase 10 — Over the wire (Service + SDK)"**:
- When to use embedded vs service mode
- `create_app` quickstart
- `OpenGuardClient` quickstart
- Auth modes (ApiKey, Shield, BYO)
- Tenancy model
- Error envelope reference

### 11.2 Mirror every code block in `tests/integration/test_integration_guide_examples.py`

Same anti-doc-rot pattern as Phase 4/6.

**Commit**: `docs(integration): Phase 10 service + SDK section with executable mirrors`

---

## Task 12: ADRs

### 12.1 `specs/decisions/0009-service-mode-wire-contract.md`

Records: (a) HTTP-only + Python SDK slim scope, (b) `/v1` prefix, (c) auth-claim tenancy + `cross_tenant_admin` override, (d) error envelope shape, (e) endpoint set. Status: Accepted.

### 12.2 `specs/decisions/0010-python-sdk-shape.md`

Records: (a) sync + async both, (b) namespaced API, (c) shared `_BaseClient`, (d) typed exception hierarchy, (e) RetryPolicy defaults + idempotency rules. Status: Accepted.

**Commit**: `docs: ADR-0009 + ADR-0010 for Phase 10`

---

## Task 13: pyproject extras + exports

### 13.1 Add to `[project.optional-dependencies]`

```toml
service = ["fastapi>=0.129.0", "uvicorn[standard]>=0.40.0"]
shield = ["open-shield-python>=X.Y.Z"]   # pin at impl time
client = ["httpx>=0.27.0"]
```

### 13.2 Top-level exports — `src/open_guard/__init__.py`

Add:
- `from open_guard.client.sync_client import OpenGuardClient`
- `from open_guard.client.async_client import AsyncOpenGuardClient`
- `from open_guard.client.base import ApiKey, BearerToken`

(Service module not auto-imported — keeps FastAPI optional.)

### 13.3 Tests

- `tests/test_imports.py` — top-level imports work
- Verify `pip install open-guard[client]` in CI does not pull FastAPI (manual or constrained env test)

**Commit**: `chore: add [service] [shield] [client] extras + top-level SDK exports`

---

## Task 14: Regression + release

- [ ] Full `pytest` run — all green, ≥93% coverage
- [ ] `mypy --strict` clean
- [ ] `ruff check` clean
- [ ] Bump version to `0.11.0`
- [ ] Update `CHANGELOG.md`
- [ ] Tag, push, run `/sync-docs`, run `/complete-phase`

**Commit**: `chore: bump to v0.11.0`

---

## Open items to resolve during implementation (not blockers)

- Exact `open-shield-python` validator import path — pin when writing `shield.py`
- Whether `Guard.authorize_traced` JSON payload size is acceptable (>1KB?) — measure; if large, document and possibly add `trace=summary` mode in Phase 11
- Whether `httpx.WSGITransport` or `ASGITransport` is the right pattern for E2E tests (FastAPI is ASGI; use `ASGITransport`) — confirm during 9.1
