# Phase 10 — Service Mode + Python SDK: Tasks

> **Convention**: `[ ]` = not started, `[/]` = in progress, `[x]` = done

---

## Task 1: Service skeleton + ServiceConfig (FEAT-012a)

- [x] 1.1 Create `src/open_guard/service/` package + `__init__.py` re-exports
- [x] 1.2 Create `service/version.py` with `SERVICE_API_VERSION = "v1"` + `DEFAULT_PREFIX`
- [x] 1.3 Create `service/app.py` with `ServiceConfig` dataclass + `create_app(...)` factory
- [x] 1.4 Tests — `tests/service/test_app_factory.py` (factory returns FastAPI; openapi lists routes; expose_admin toggle; custom prefix)
- [x] 1.5 Commit: `feat(service): add create_app factory + ServiceConfig (FEAT-012a)`

## Task 2: Auth backend protocol + implementations (FEAT-012d)

- [x] 2.1 `service/auth/__init__.py` — `AuthBackend` protocol + `CallerContext` dataclass
- [x] 2.2 `service/auth/api_key_store.py` — `ApiKeyStorePort` + `ApiKeyRecord` + `InMemoryApiKeyStore`
- [x] 2.3 `service/auth/api_key.py` — `ApiKeyAuth` + `generate()` helper (sha256 hashing)
- [x] 2.4 `service/auth/byo.py` — `CallableAuth`
- [x] 2.5 `service/auth/shield.py` — `ShieldAuth` (gated on `[shield]` extra)
- [x] 2.6 `service/auth/dep.py` — `make_auth_dep(auth)` FastAPI dependency factory
- [x] 2.7 Tests — `test_auth_apikey.py` (generate, validate, revoke, missing/bad header)
- [x] 2.8 Tests — `test_auth_byo.py` (callable returns context, raises)
- [x] 2.9 Tests — `test_auth_shield.py` (importorskip; mock validator; valid + invalid)
- [x] 2.10 Commit: `feat(service): add AuthBackend protocol + ApiKeyAuth + CallableAuth + ShieldAuth (FEAT-012d)`

## Task 3: Tenant context (FEAT-012e)

- [x] 3.1 `service/tenant.py` — `make_tenant_dep(auth)` + `CROSS_TENANT_ADMIN_SCOPE`
- [x] 3.2 Tests — `test_tenant_routing.py` (no header, matching header, mismatch w/o scope → 403, mismatch w/ scope → ok, body tenant_id stripped)
- [x] 3.3 Commit: `feat(service): tenant context resolution with cross-tenant admin override (FEAT-012e)`

## Task 4: DecisionRouter (FEAT-012b)

- [x] 4.1 `service/schemas.py` — Authorize/ListAuthorized/AuthorizeAndConsume request + response models
- [x] 4.2 `service/decision_router.py` — `build_decision_router(guard, auth)` with all 4 endpoints
- [x] 4.3 Handle sync `Guard` via `asyncio.to_thread`; native await for `AsyncGuard`
- [x] 4.4 Tests — `test_decision_router.py` for `/authorize` (Guard + AsyncGuard, parity with in-process)
- [x] 4.5 Tests — `/authorize/traced` (DecisionTrace round-trips as dict)
- [x] 4.6 Tests — `/list_authorized` (cursor pagination preserved)
- [x] 4.7 Tests — `/authorize_and_consume` (delegation budget decrement visible)
- [x] 4.8 Tests — pending-approval path returns approval_request_id + allowed=False
- [x] 4.9 Tests — 401 missing auth, 422 malformed body
- [x] 4.10 Commit: `feat(service): DecisionRouter with authorize/traced/list/consume (FEAT-012b)`

## Task 5: AdminRouter prefix injection + auth wiring (FEAT-012c)

- [x] 5.1 Refactor `api/fastapi/admin_router.py` — remove hard-coded `/admin` from internal routes; rely on `include_router(prefix=...)`
- [x] 5.2 Add tenant_dep to AdminRouter so admin endpoints require auth
- [x] 5.3 Wire AdminRouter mount in `create_app` at `f"{prefix}/admin"`
- [x] 5.4 Tests — `test_admin_router_mount.py` (default + custom prefix, auth required)
- [x] 5.5 Tests — `test_prefix_configurable.py` (`/openguard/v1`, `/v2/foo`)
- [x] 5.6 Verify existing `tests/test_admin_router.py` still passes (or adapt minimally)
- [x] 5.7 Commit: `refactor(api): allow AdminRouter mount under arbitrary prefix + require auth (FEAT-012c)`

## Task 6: Error envelope + exception handlers

- [x] 6.1 `service/errors.py` — `ServiceError` base + `AuthenticationError`/`AuthorizationServiceError`/`NotFoundError` + `install_exception_handlers`
- [x] 6.2 Map `RequestValidationError` → 422 envelope
- [x] 6.3 Catch-all 500 handler that hides traceback
- [x] 6.4 Tests — `test_error_envelope.py` (each subclass produces correct envelope; 422; 500 hides internals)
- [x] 6.5 Commit: `feat(service): error envelope + FastAPI exception handlers`

## Task 7: SDK base client + auth helpers (FEAT-013-py)

- [x] 7.1 `client/__init__.py` re-exports
- [x] 7.2 `client/exceptions.py` — `OpenGuardError` hierarchy
- [x] 7.3 `client/retry.py` — `RetryPolicy` dataclass with defaults
- [x] 7.4 `client/base.py` — `ClientAuth` + `ApiKey()` + `BearerToken()` helpers
- [x] 7.5 `client/base.py` — `_BaseClient` with `_url` + `_map_error`
- [x] 7.6 Tests — `test_auth_headers.py`
- [x] 7.7 Commit: `feat(client): SDK base client + auth helpers + retry policy + exception hierarchy`

## Task 8: Sync + Async clients with namespaces (FEAT-013-py)

- [x] 8.1 `client/sync_client.py` — `OpenGuardClient` + `_request` with retry loop + ctx manager
- [x] 8.2 `client/async_client.py` — `AsyncOpenGuardClient` (async ctx manager, asyncio.sleep)
- [x] 8.3 `client/namespaces/decisions.py` — `DecisionsAPI` + `AsyncDecisionsAPI`
- [x] 8.4 `client/namespaces/admin_policies.py` — sync + async
- [x] 8.5 `client/namespaces/admin_roles.py` — sync + async
- [x] 8.6 `client/namespaces/admin_relationships.py` — sync + async (incl. `check`)
- [x] 8.7 `client/namespaces/admin_delegations.py` — sync + async
- [x] 8.8 `client/namespaces/admin_sessions.py` — sync + async
- [x] 8.9 `client/namespaces/admin.py` — `AdminAPI` aggregator
- [x] 8.10 Tests — `test_sync_client.py` (every endpoint via in-process ASGI transport)
- [x] 8.11 Tests — `test_async_client.py` (every endpoint, async)
- [x] 8.12 Tests — `test_namespacing.py` (namespaced methods exist; flat shortcut does not)
- [x] 8.13 Tests — `test_retry.py` (503 → 200 succeeds; non-idempotent skipped)
- [x] 8.14 Tests — `test_error_mapping.py` (status → exception class)
- [x] 8.15 Commit: `feat(client): sync + async clients with namespaced API (FEAT-013-py)`

## Task 9: E2E tests

- [x] 9.1 `tests/e2e/test_service_client_e2e.py` — SDK ↔ service ↔ in-memory backend
- [x] 9.2 `tests/e2e/test_service_sql_e2e.py` — SDK ↔ service ↔ `sqlite+aiosqlite` backend
- [x] 9.3 Cover: create policy via admin → authorize via decisions → assert allowed
- [x] 9.4 Cover: assign role with `resource_match` → list_authorized returns scoped IDs
- [x] 9.5 Cover: delegate → authorize_and_consume → budget decremented
- [x] 9.6 Commit: `test(e2e): SDK -> service -> backend round-trip tests`

## Task 10: Reference Dockerfile

- [x] 10.1 `deploy/service/Dockerfile` (python:3.12-slim, uvicorn entrypoint)
- [x] 10.2 `deploy/service/entrypoint.example.py` (build_async_guard from env, ApiKeyAuth)
- [x] 10.3 `deploy/service/README.md` (env vars, build command, compose example)
- [x] 10.4 Manual smoke: `docker build -f deploy/service/Dockerfile .`
- [x] 10.5 Commit: `docs(deploy): reference Dockerfile + entrypoint for service mode`

## Task 11: Integration guide

- [x] 11.1 Append "Over the wire (Service + SDK)" section to `specs/architecture/integration-guide.md`
- [x] 11.2 Mirror every code block in `tests/integration/test_integration_guide_examples.py`
- [x] 11.3 Commit: `docs(integration): Phase 10 service + SDK section with executable mirrors`

## Task 12: ADRs

- [x] 12.1 Write `specs/decisions/0009-service-mode-wire-contract.md`
- [x] 12.2 Write `specs/decisions/0010-python-sdk-shape.md`
- [x] 12.3 Update `specs/decisions/impact-map.json` with phase-10 topics
- [x] 12.4 Commit: `docs: ADR-0009 + ADR-0010 for Phase 10`

## Task 13: pyproject extras + exports

- [x] 13.1 Add `[service]`, `[shield]`, `[client]` to `pyproject.toml` optional-dependencies
- [x] 13.2 Pin `open-shield-python` version (resolve at impl time)
- [x] 13.3 Add SDK exports to `src/open_guard/__init__.py`
- [x] 13.4 Tests — `tests/test_imports.py` (top-level imports work without server installed)
- [x] 13.5 Commit: `chore: add [service] [shield] [client] extras + top-level SDK exports`

## Task 14: Regression + release

- [x] 14.1 `pytest` full run — target ≥1170 tests, ≥93% coverage
- [x] 14.2 `mypy --strict` clean
- [x] 14.3 `ruff check` clean
- [x] 14.4 Bump `pyproject.toml` version to `0.11.0`
- [x] 14.5 Update `CHANGELOG.md`
- [x] 14.6 Run `/sync-docs` to propagate history → architecture docs
- [x] 14.7 Run `/complete-phase` to finalize and tag v0.11.0
- [x] 14.8 Commit: `chore: bump to v0.11.0`
