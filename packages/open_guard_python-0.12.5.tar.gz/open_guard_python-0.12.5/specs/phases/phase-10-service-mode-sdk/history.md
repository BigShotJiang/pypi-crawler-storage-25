# Phase 10 — Service Mode + Python SDK: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [SCOPE_CHANGE] 2026-05-04 — Phase 10 scoped slim: HTTP-only + Python SDK
Topics: scope, phase-theme, service-mode, sdk, python-client, grpc-deferred, ts-sdk-deferred, go-sdk-deferred
Affects-phases: phase-10-service-mode-sdk, phase-11 (future — gRPC + non-Python SDKs)
Affects-specs: specs/planning/roadmap.md, specs/status.md
Detail: Original Phase 10 (per roadmap) bundled HTTP service + gRPC service + thin clients in Python/TS/Go. Brainstorm narrowed to HTTP service + Python SDK only (Option 1 "Slim"). Rationale: HTTP unblocks 100% of cross-language consumers via plain HTTP libs; gRPC adds proto schema, codegen, streaming semantics that deserve their own design pass; ship one SDK first to validate the wire contract before duplicating in TS/Go. gRPC + TS/Go SDKs explicitly pushed to Phase 11.

---

### [DECISION] 2026-05-04 — API surface = DecisionRouter (new) + AdminRouter (existing) under configurable /v1 prefix
Topics: api-surface, decision-router, admin-router, prefix, versioning
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/architecture/integration-guide.md
Detail: Service exposes two routers: a new DecisionRouter for the runtime hot path (`/authorize`, `/authorize/traced`, `/list_authorized`, `/authorize_and_consume`) and the existing AdminRouter mounted under `/admin`. Both sit under a configurable global prefix, default `/v1` (matches OpenFGA / SpiceDB convention; no `/api` segment to keep URLs short). Configurable via `ServiceConfig(prefix="/openguard/v1")`. AdminRouter must be refactored to accept its prefix at mount time rather than hard-coding it inside route decorators.

---

### [SCOPE_CHANGE] 2026-05-04 — MCP /tools/check endpoint deferred to Phase 11
Topics: mcp, scope, optional-deps, service-image
Affects-phases: phase-10-service-mode-sdk, phase-11 (future)
Affects-specs: specs/architecture/integration-guide.md
Detail: Considered including `POST /v1/tools/check` (wraps `MCPGuard.check_tool_call`) in DecisionRouter. Deferred to Phase 11 to keep the optional `[mcp]` dep out of the default service image. Service Mode ships without MCP-specific endpoints; consumers using MCP can keep using the embedded `MCPGuard` for now.

---

### [DECISION] 2026-05-04 — Pluggable auth: built-in API keys + open-shield JWT (optional) + BYO callable
Topics: auth, api-keys, open-shield, jwt, byo, pluggable, security
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/architecture/auth-model.md
Detail: Service authentication supports three modes via an `AuthBackend` protocol. (1) `ApiKeyAuth` — built-in, hash-stored (sha256), bound to (tenant, service_identity, scopes), header `Authorization: ApiKey <key>`; floor every deployment can use. (2) `ShieldAuth` — wraps an open-shield validator, extracts tenant + identity + scopes from claims; gated on optional `[shield]` extra; default for Cerebrio. (3) `CallableAuth` — escape hatch accepting a `Callable[[Request], Awaitable[CallerContext]]` for mTLS / custom JWT / proxy-based auth. Auth is configured at `create_app(auth=...)` time. Open-shield is integrated as an *optional dependency* — the broader "merge open-shield into open-guard?" question stays explicitly deferred per roadmap.

---

### [DECISION] 2026-05-04 — Caller authenticates the service; subject lives in the request body
Topics: auth, subject-vs-caller, jwt-claims, security
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/architecture/auth-model.md
Detail: The JWT or API key answers "which service is asking?" — never "who is the subject being authorized?". Subject + on-behalf-of chain remain explicit in the request body, exactly as in the embedded library. This preserves the existing chain semantics and avoids overloading authentication with authorization input.

---

### [DECISION] 2026-05-04 — Tenant ID sourced from auth claim only; X-Tenant-ID override gated by cross_tenant_admin scope
Topics: tenancy, multi-tenant, cross-tenant-admin, security, openfga-pattern
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/architecture/auth-model.md
Detail: `CallerContext.tenant_id` (extracted from API key record or JWT claim) is the only legitimate source of `tenant_id`. The request body never carries `tenant_id`; if it does, the field is stripped server-side. `X-Tenant-ID` header override is honored *only* when the calling identity carries an explicit `cross_tenant_admin` scope (rare, intended for ops/console tooling). Eliminates a class of cross-tenant bugs by construction. Mirrors OpenFGA `store_id` and Auth0 FGA tenancy patterns.

---

### [DECISION] 2026-05-04 — Python SDK ships both sync and async clients with namespaced API
Topics: sdk, python-sdk, sync, async, namespacing, openguardclient
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/architecture/integration-guide.md
Detail: SDK provides `OpenGuardClient` (sync, `httpx.Client`) and `AsyncOpenGuardClient` (async, `httpx.AsyncClient`), both inheriting a shared `_BaseClient` for URL construction, auth headers, error mapping, and retry policy. Library users already pick sync vs async at the `Guard` / `AsyncGuard` boundary; the SDK preserves that choice. API is namespaced: `client.decisions.authorize(...)`, `client.admin.policies.create(...)`, `client.admin.relationships.check(...)`. Drop-in `client.authorize` was rejected — would collide once admin surface (~20 methods) is exposed. Stripe/AWS-style namespacing scales cleanly.

---

### [DECISION] 2026-05-04 — SDK retry policy: 5xx + connection errors, idempotent methods only
Topics: sdk, retry, idempotency, transport-errors, retry-policy
Affects-phases: phase-10-service-mode-sdk
Affects-specs: none
Detail: `RetryPolicy` defaults: 3 attempts, exponential backoff (100ms → 400ms → 1.6s capped at 2s), retry on HTTP 502/503/504 + connection/timeout errors. Critically, retries apply to idempotent operations only (`authorize`, `list_authorized`, all admin reads, idempotent writes). `authorize_and_consume` is non-idempotent (it decrements delegation budgets) — first attempt only by default. Per-call override available. Documented idempotency table will live in the integration guide.

---

### [DECISION] 2026-05-04 — Three new optional extras: [service], [shield], [client]
Topics: packaging, optional-extras, dependencies, pyproject
Affects-phases: phase-10-service-mode-sdk
Affects-specs: none
Detail: New optional-dependency groups in `pyproject.toml`: (a) `[service]` → `fastapi`, `uvicorn[standard]` for running the HTTP service; (b) `[shield]` → `open-shield-python` for JWT validation via ShieldAuth; (c) `[client]` → `httpx` for the SDK. Server-only consumers install `open-guard[service]` (no httpx). SDK-only consumers install `open-guard[client]` (no FastAPI). Both extras can coexist for local dev / monorepo deployment. The existing `[fastapi]` extra (which already pulls FastAPI) stays — Service Mode reuses it via `[service]` adding uvicorn.

---

### [DECISION] 2026-05-04 — Reference Dockerfile only; no published image this phase
Topics: deployment, docker, ops, ci
Affects-phases: phase-10-service-mode-sdk
Affects-specs: none
Detail: Phase 10 ships `deploy/service/Dockerfile` + `entrypoint.example.py` + a short README under `deploy/service/`. No image is published to a registry — that's an ops concern with credential implications, deferred until a real consumer requires it. The Dockerfile is a starting point; consumers customize for their platform.

---

### [DECISION] 2026-05-04 — Versioned API constant: SERVICE_API_VERSION = "v1"
Topics: versioning, api-stability, breaking-changes
Affects-phases: phase-10-service-mode-sdk
Affects-specs: none
Detail: A module-level `SERVICE_API_VERSION` constant (default `"v1"`) reserves the breaking-change budget for v2. Wire-contract decisions made in Phase 10 may need revision once real consumers exercise them; rather than risk silent drift, future breaking changes mount under a new prefix. Documented in ADR-0009.

---

### [NOTE] 2026-05-04 — Phase 10 brainstorm: orientation
Topics: brainstorm, planning, cerebrio-sapience-integration, open-shield-merge-question
Affects-phases: phase-10-service-mode-sdk
Affects-specs: none
Detail: User confirmed proceeding with the planned phase rather than deferring or repurposing. The "should open-shield merge into open-guard?" open question (raised 2026-04-21, flagged in roadmap as needing decision before Phase 10) was *not* resolved — instead, Phase 10 integrates open-shield as an optional dependency via `[shield]`, leaving the merge question to be reopened later if SDK + service deployments expose a real ergonomics problem.

---

### [DISCOVERY] 2026-05-04 — AdminRouter currently hard-codes /admin prefix
Topics: admin-router, prefix, refactor, tech-debt
Affects-phases: phase-10-service-mode-sdk
Affects-specs: none
Detail: During brainstorm, identified that `api/fastapi/admin_router.py` hard-codes `/admin` inside its route decorators. To support a configurable global prefix (`/v1/admin`, `/openguard/v1/admin`), the router must be refactored to expose routes without the prefix and rely on `app.include_router(prefix=...)` at mount time. Backward-compatible: `build_admin_router(admin)` signature stays the same; the change is internal. No new backlog item — handled as Task 5 in the phase plan.

---

### [NOTE] 2026-05-04 — AdminRouter discovery resolved at implementation
Topics: admin-router, prefix, no-refactor-needed
Affects-phases: phase-10-service-mode-sdk
Affects-specs: none
Detail: On reading `api/fastapi/admin_router.py` during Task 5, the hard-coded-prefix concern from the brainstorm discovery turned out to be a misread. AdminRouter routes are already declared with relative paths (`/policies`, `/roles`, ...); the prefix is supplied at mount time via `app.include_router(prefix=...)`. Task 5 reduced to wiring the AdminRouter under `{config.prefix}/admin` and adding the auth dependency. No internal refactor required.

---

### [ARCH_CHANGE] 2026-05-04 — DecisionRouter conditionally registers sync-only endpoints based on guard type
Topics: decision-router, async-guard, list-authorized, authorize-and-consume, openapi
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/architecture/integration-guide.md, specs/decisions/0009-service-mode-wire-contract.md
Detail: `AsyncGuard` does not implement `list_authorized` or `authorize_and_consume` (both depend on the sync delegation evaluator and CandidateResourcePort). Rather than register placeholder 501 endpoints, the router introspects the guard at build time (`isinstance(guard, AsyncGuard)`) and only registers endpoints the guard supports. Async deployments thus expose two endpoints (`/authorize`, `/authorize/traced`); sync deployments expose all four. OpenAPI spec accurately reflects available operations.

---

### [DECISION] 2026-05-04 — Sync OpenGuardClient accepts optional pre-built httpx.Client via http_client=
Topics: sync-client, openguard-client, http-client, testclient, dependency-injection
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/decisions/0010-python-sdk-shape.md
Detail: `httpx.ASGITransport` is async-only — the sync `OpenGuardClient` cannot directly test against an in-process ASGI app via that route. Added an optional `http_client: httpx.Client | None = None` parameter to `OpenGuardClient.__init__`. Tests pass `fastapi.testclient.TestClient` (an `httpx.Client` subclass) which uses anyio's blocking portal to drive the async ASGI app from sync code. This also benefits production consumers who want to share a configured `httpx.Client` (custom timeouts, proxies, observability hooks). Captured in ADR-0010 as decision `Optional http_client injection`.

---

### [NOTE] 2026-05-04 — Phase 10 implementation complete
Topics: implementation, regression, release, v0.11.0, completion
Affects-phases: phase-10-service-mode-sdk
Affects-specs: specs/status.md, specs/changelog/2026-05.md
Detail: All 14 task groups complete. 1186 tests passing (+117 from Phase 9 baseline of 1069), 93% coverage, 1 skipped (test_auth_shield, requires `[shield]` extra). Service module + Python SDK + reference Dockerfile + integration guide + ADR-0009 + ADR-0010 + pyproject extras + top-level exports all shipped. Zero breaking changes — embedded `Guard` / `AsyncGuard` / `PolicyAdmin` / `AdminRouter` continue to work unchanged. Version bumped to 0.11.0 in pyproject.toml, `__version__`, and uv.lock. Lint clean (ruff). Pending steps before release: `/sync-docs`, `/complete-phase`, branch merge to staging → main (user approval required).

---
