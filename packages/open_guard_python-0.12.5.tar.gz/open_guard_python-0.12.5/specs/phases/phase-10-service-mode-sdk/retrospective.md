# Phase 10 — Retrospective

> **Phase**: 10 — Service Mode + Python SDK
> **Version**: v0.11.0
> **Branch**: `phase-10-service-mode-sdk`
> **Duration**: 2026-05-04 (~1 session)
> **Predecessor**: Phase 9 — Production Integration (v0.10.0)

## Summary

Wrapped the existing `Guard` / `AsyncGuard` + `AdminRouter` engine in a
deployable HTTP service (`open_guard.service`) and shipped a typed
Python SDK (`open_guard.client`) on top. Both pieces sit behind
configurable auth (`ApiKeyAuth` / `ShieldAuth` / `CallableAuth`) and a
versioned `/v1` prefix. Zero breaking changes — embedded consumers
keep working unchanged.

| Metric | Phase 9 baseline | Phase 10 final | Delta |
|--------|------------------|----------------|-------|
| Tests passing | 1069 | 1186 | **+117** |
| Coverage | 94% | 93% | -1% (within target) |
| Source files | — | +25 (service + client + namespaces) | — |
| Test files | — | +13 (service + client + e2e + integration mirror + imports) | — |
| ADRs | 0001–0008 | 0001–0010 | **+2** (0009, 0010) |
| Optional extras | sql, sql-async, fastapi, mcp, cli | + service, client, shield | **+3** |

## What went well

### 1. The brainstorm scope decision held up under implementation

Slim scope (HTTP-only + Python SDK, gRPC + TS/Go deferred to Phase 11)
turned out to be the right call. Implementation took roughly one
session; bundling gRPC + non-Python SDKs would have at least doubled
the footprint and forced premature wire-contract decisions. Validating
the surface with one SDK first means the eventual TS/Go work inherits
a tested contract instead of co-evolving it.

### 2. AdminRouter required no refactor

The brainstorm flagged "AdminRouter hard-codes `/admin`" as a
discovery requiring refactor. On reading the file during Task 5, the
discovery turned out to be wrong — routes were already declared
relative to mount point, with the prefix injected via
`app.include_router(prefix=...)`. Task 5 collapsed to wiring auth +
mounting. **Lesson:** always re-verify discoveries against the actual
code at implementation time, not just at brainstorm.

### 3. Sync ASGI testing solved cleanly with `http_client=` injection

`httpx.ASGITransport` is async-only, so the sync SDK couldn't directly
test against an in-process FastAPI app via that transport. Rather than
spin up uvicorn in a thread, added an optional `http_client:
httpx.Client | None` param to `OpenGuardClient`. Tests pass
`fastapi.testclient.TestClient` (an `httpx.Client` subclass that
bridges sync→async via anyio's blocking portal). Side benefit:
production consumers wanting to share a configured `httpx.Client`
(custom timeouts / proxies / observability hooks) get this for free.

### 4. Conditional endpoint registration kept the OpenAPI honest

`AsyncGuard` doesn't implement `list_authorized` or
`authorize_and_consume` (sync-only delegation evaluator). Rather than
register 501 placeholders, the router introspects the guard at build
time and only registers endpoints the guard supports. Async
deployments get a clean OpenAPI surface; sync deployments get the
full four. Captured in ADR-0009.

### 5. Anti-doc-rot pattern continued

The integration guide's "Phase 10 — Over the wire" section mirrored
into `tests/integration/test_integration_guide_phase10_examples.py`
the same way Phases 4 / 6 / 7 / 9 did — every code block in the doc
runs as a test, so the doc cannot drift from working code without
test failures. 8 mirror tests added.

## What didn't go as well

### 1. Linter pass cosmetically rewrote multiple files mid-flight

`ruff check --fix` modified 14 files at once. While correct, the
batched rewrite obscured what changed in test files vs source files
during a single tool call. Two F821 false-positives (`CallerContext`
forward references in `auth/api_key.py`, `auth/byo.py`,
`auth/shield.py`) needed `TYPE_CHECKING` imports added back manually.
**Lesson:** keep TYPE_CHECKING imports for runtime forward references
explicit from the start — don't rely on local imports inside method
bodies for type annotations under `from __future__ import annotations`.

### 2. RBAC test setup was unintuitive

The first decision-router test used `evaluator_type="rbac"` with
`subject_match={"role": "reader"}`, which silently doesn't match —
RBAC's role assignment uses `subject_match={"roles": [role], "id":
subject_id}`, not arbitrary attributes. Switched to ABAC for the
generic `authorize_allowed_after_policy_create` test. **Lesson:**
RBAC's subject_match shape is policy-construction-specific; tests that
just want a "policy that allows" should use ABAC.

### 3. Pytest-asyncio fixture scoping required workaround

The async client fixture (`async_client_with_admin`) initially used
`async def` + `yield`, which pytest-asyncio strict-mode requires
inside an event loop scope. After hitting "asyncio.run() cannot be
called from a running event loop" twice, fell back to a synchronous
fixture that uses `asyncio.run` only when no loop is running, and
direct dict insertion when one is. Works, but ugly. **Lesson:** for
mixed sync/async test fixtures, either commit to `asyncio_mode=auto`
(repo doesn't) or carefully scope async-only fixtures to async-only
tests.

### 4. test_imports.py initially polluted sys.modules

The first version of `test_service_module_does_not_auto_load` deleted
`open_guard` from `sys.modules` and re-imported, which left other
tests holding stale class references and broke 35 unrelated tests.
Fixed by running the import-order check in a subprocess. **Lesson:**
never mutate `sys.modules` in tests that share a process — always
isolate via subprocess.

## Lessons learned

1. **Optional dependency hygiene matters.** Three new extras
   (`[service]`, `[client]`, `[shield]`) plus two import paths to
   guard (`open_guard.service` requires FastAPI; top-level SDK
   re-exports require httpx). Keeping the service module *not*
   auto-imported was the right call — `import open_guard` works on a
   server-only install with no httpx.
2. **TestClient is the bridge, not a replacement.** When sync code
   needs to talk to async ASGI in-process, FastAPI's `TestClient`
   (which uses anyio's blocking portal under the hood) is the cleanest
   route. The `http_client=` injection point in the sync SDK is the
   abstraction that makes this work without test-only code paths.
3. **ADRs anchor wire-contract decisions before they're final.**
   ADR-0009 + ADR-0010 captured the rationale (why `/v1` vs `/api/v1`,
   why namespaced vs flat, why idempotent-only retry, why
   tenant-from-claim) at the point where consumers haven't yet pushed
   back. When the first non-Python SDK (Phase 11) lands, those ADRs
   will be the source of truth for what's load-bearing vs incidental.

## Discoveries (per Rule 3)

No new bugs, tech debt, or feature requests surfaced during Phase 10
implementation. The `[DISCOVERY]` from brainstorm (AdminRouter prefix)
was resolved as a non-issue at implementation time.

## Cross-Repo Coordination

- **cerebrio-sapience** is the primary anticipated consumer of the
  Python SDK. Its existing in-process integration continues to work
  unchanged. Validation signal for the wire contract will come from
  the first cerebrio-sapience deployment that swaps embedded `Guard`
  for `OpenGuardClient`.
- **open-shield-python** is integrated as an *optional* dep via
  `[shield]`. The "should we merge open-shield into open-guard?"
  question stays explicitly deferred — Phase 10 leaves it as a
  pluggable backend; the merge question reopens if Phase 10
  deployments expose ergonomics issues.

## Next phase

**Phase 11 — gRPC + non-Python SDKs.** Pulls in:

- gRPC service wrapper (proto schema, codegen toolchain, streaming
  semantics)
- TypeScript SDK
- Go SDK
- MCP `/tools/check` endpoint (pulls `[mcp]` extra into the service
  image — deferred from Phase 10 to keep the default service image
  light)
- Possibly streaming endpoints (revocation push, change feeds) if
  real consumers demand them

Phase 11 is **not scheduled** — it lands when the first non-Python
consumer needs it.

## References

- Phase plan: `specs/phases/phase-10-service-mode-sdk/plan.md`
- Phase tasks: `specs/phases/phase-10-service-mode-sdk/tasks.md`
- Phase history: `specs/phases/phase-10-service-mode-sdk/history.md`
- ADR-0009 — Service Mode Wire Contract: `specs/decisions/0009-service-mode-wire-contract.md`
- ADR-0010 — Python SDK Shape: `specs/decisions/0010-python-sdk-shape.md`
- Integration guide: `specs/architecture/integration-guide.md` (Phase 10 section)
- Auth model: `specs/architecture/auth-model.md` (Service Mode Authentication section)
- Release entry: `specs/changelog/2026-05.md` (v0.11.0)
