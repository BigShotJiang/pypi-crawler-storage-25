# Phase 10 — Service Mode + Python SDK

> **Version**: v0.11.0
> **Status**: Planned
> **Predecessor**: Phase 9 — Production Integration (v0.10.0)
> **Theme**: Wrap the engine + admin surface in a deployable HTTP service and ship a first-class Python SDK so any Python consumer can use open-guard over the wire.

## Goal

After this phase, open-guard is consumable in two ways: as an embedded Python library (existing) **and** as a standalone HTTP service with a typed Python SDK. The service exposes the runtime decision surface (`authorize`, `list_authorized`, `authorize_and_consume`, `authorize_traced`) and the existing `AdminRouter` behind a versioned `/v1/...` prefix, with pluggable authentication (built-in API keys, optional open-shield JWT, BYO escape hatch) and tenant isolation enforced from the auth claim. The Python SDK ships sync + async clients with namespaced APIs (`client.decisions.*`, `client.admin.*`) sharing a common base.

gRPC and TS/Go SDKs are explicitly deferred to Phase 11.

## Key Decisions

| # | Decision | Rationale |
|---|----------|-----------|
| 1 | **Slim scope: HTTP-only + Python SDK** — gRPC and TS/Go SDKs deferred to Phase 11 | HTTP unblocks 100% of cross-language consumers via plain HTTP libs. gRPC adds proto schema, codegen, streaming semantics — deserves its own design pass. Validate the wire contract once before duplicating across languages. |
| 2 | **Two routers, one app**: `DecisionRouter` (new) for runtime + existing `AdminRouter` for management, both mounted under a configurable `/v1` prefix | Hot-path decision endpoints have different latency/observability needs than admin CRUD; clean separation makes per-router middleware (rate limits, tracing) trivial. Single deployable artifact keeps ops simple. |
| 3 | **Auth pluggable**: built-in `ApiKeyAuth` + `ShieldAuth` (open-shield JWT, optional `[shield]` extra) + BYO callable | API keys are the floor every deployment can use. open-shield is the Cerebrio default — must be first-class. BYO escape hatch lets consumers plug mTLS/custom JWT without us pre-committing. |
| 4 | **Tenant ID sourced from auth claim, not request body** | Eliminates a class of cross-tenant bugs by construction: the caller's identity *is* their tenant. Header override (`X-Tenant-ID`) only honored when the calling identity carries an explicit `cross_tenant_admin` scope (rare, ops tooling only). Matches OpenFGA `store_id` and Auth0 FGA tenancy patterns. |
| 5 | **Python SDK ships both sync + async clients** with shared `_BaseClient` | Library users already pick sync vs async at the `Guard` / `AsyncGuard` boundary; the SDK preserves that choice. Shared base = ~1.5x code of one flavor, not 2x. |
| 6 | **SDK uses namespaced API**: `client.decisions.authorize(...)`, `client.admin.policies.create(...)` | Drop-in `client.authorize` would collide once admin surface (~20 methods) is exposed. Stripe/AWS-style namespacing scales cleanly. |
| 7 | **Caller authenticates the service; subject is in the request body** | The JWT/API key answers "which service is asking?" — never "who is the subject being authorized?". Subject + chain remain explicit in the body. |
| 8 | **MCP `/tools/check` endpoint deferred to Phase 11** | Pulls the optional `[mcp]` dep into the service image. Decoupling lets us ship Service Mode without forcing MCP on every deployment. |
| 9 | **Configurable global prefix, default `/v1`** | Versioned-only (no `/api`) matches OpenFGA / SpiceDB conventions; keeps URLs short. Configurable so consumers can mount under `/openguard/v1`, `/authz/v1`, etc. |
| 10 | **Server entry point: `uvicorn open_guard.service.app:create_app --factory`** | Standard FastAPI deployment shape. Reference Dockerfile shipped; no published image in this phase. |

## Source Structure

```
src/open_guard/
├── service/                                # NEW — HTTP service module ([service] extra)
│   ├── __init__.py
│   ├── app.py                              # create_app() factory + ServiceConfig
│   ├── auth/
│   │   ├── __init__.py                     # AuthBackend protocol
│   │   ├── api_key.py                      # ApiKeyAuth (built-in)
│   │   ├── shield.py                       # ShieldAuth (under [shield] extra)
│   │   └── byo.py                          # CallableAuth (BYO escape hatch)
│   ├── tenant.py                           # TenantContext + cross_tenant_admin enforcement
│   ├── decision_router.py                  # DecisionRouter — /authorize, /list_authorized, /authorize_and_consume, /authorize/traced
│   ├── schemas.py                          # Pydantic request/response models for runtime endpoints
│   ├── errors.py                           # Error envelope + FastAPI exception handlers
│   └── version.py                          # SERVICE_API_VERSION constant
├── client/                                 # NEW — Python SDK ([client] extra)
│   ├── __init__.py                         # exports OpenGuardClient + AsyncOpenGuardClient
│   ├── base.py                             # _BaseClient — URL building, auth headers, serialization
│   ├── sync_client.py                      # OpenGuardClient (httpx.Client)
│   ├── async_client.py                     # AsyncOpenGuardClient (httpx.AsyncClient)
│   ├── namespaces/
│   │   ├── decisions.py                    # DecisionsAPI / AsyncDecisionsAPI
│   │   ├── admin_policies.py               # PoliciesAPI / AsyncPoliciesAPI
│   │   ├── admin_roles.py                  # RolesAPI / AsyncRolesAPI
│   │   ├── admin_relationships.py          # RelationshipsAPI / AsyncRelationshipsAPI
│   │   ├── admin_delegations.py            # DelegationsAPI / AsyncDelegationsAPI
│   │   └── admin_sessions.py               # SessionsAPI / AsyncSessionsAPI
│   ├── exceptions.py                       # OpenGuardError hierarchy
│   ├── retry.py                            # RetryPolicy (exponential backoff for 5xx + connect errors)
│   └── models.py                           # SDK-side dataclasses (mirrors body schemas)
└── api/fastapi/
    └── admin_router.py                     # MODIFY — accept prefix from caller; preserve current default

deploy/
└── service/
    └── Dockerfile                          # NEW — reference Dockerfile (uvicorn + asyncpg + aiosqlite extras)

tests/
├── service/
│   ├── test_app_factory.py
│   ├── test_auth_apikey.py
│   ├── test_auth_shield.py                 # only runs when open-shield installed
│   ├── test_auth_byo.py
│   ├── test_decision_router.py
│   ├── test_admin_router_mount.py
│   ├── test_tenant_routing.py              # tenant from auth claim, header rejection, admin override
│   ├── test_error_envelope.py
│   └── test_prefix_configurable.py
├── client/
│   ├── test_sync_client.py
│   ├── test_async_client.py
│   ├── test_namespacing.py
│   ├── test_retry.py
│   ├── test_error_mapping.py
│   └── test_auth_headers.py
└── e2e/
    ├── test_service_client_e2e.py          # SDK -> service over httpx ASGI transport, memory backend
    └── test_service_sql_e2e.py             # SDK -> service, sqlite+aiosqlite backend
```

## Scope

### In Scope

1. **FEAT-012a: HTTP Service Mode** — `open_guard.service` module with `create_app(...)` ASGI factory, configurable `/v1` prefix, two mounted routers (Decision + Admin), pluggable auth, tenant context, error envelope, OpenAPI auto-published at `/docs` and `/openapi.json`.

2. **FEAT-012b: DecisionRouter** — runtime decision endpoints over HTTP:
   - `POST /v1/authorize` → `Guard.authorize` / `AsyncGuard.authorize`
   - `POST /v1/authorize/traced` → `Guard.authorize_traced` / `AsyncGuard.authorize_traced`
   - `POST /v1/list_authorized` → `Guard.list_authorized` / `AsyncGuard.list_authorized`
   - `POST /v1/authorize_and_consume` → `Guard.authorize_and_consume` / `AsyncGuard.authorize_and_consume`

3. **FEAT-012c: AdminRouter mount** — existing `AdminRouter` mounted under `/v1/admin/*`. Internal modification: accept a prefix injection so the router does not hard-code its mount path.

4. **FEAT-012d: Pluggable auth** — `AuthBackend` protocol + three implementations:
   - `ApiKeyAuth` — hash-stored keys (one-way SHA-256), bound to `(tenant_id, service_identity, scopes)` records held in an in-process or SQL `ApiKeyStore`. `Authorization: ApiKey <key>` header. New `ApiKeyStorePort` + memory + SQL impls.
   - `ShieldAuth` — wraps an open-shield validator; extracts `tenant_id` and `service_identity` from validated claim set. Optional `[shield]` extra.
   - `CallableAuth` — accepts a `Callable[[Request], Awaitable[CallerContext]]`. Lets consumers supply mTLS / custom JWT logic.

5. **FEAT-012e: Tenant isolation from auth claim** — `CallerContext.tenant_id` is the only tenant source unless caller carries `cross_tenant_admin` scope **and** sends `X-Tenant-ID`. Request body never carries `tenant_id`; if it does, the field is stripped server-side (defensive).

6. **FEAT-013-py: Python SDK** — `open_guard.client` module:
   - `OpenGuardClient(base_url, auth, ...)` (sync, `httpx.Client`)
   - `AsyncOpenGuardClient(base_url, auth, ...)` (async, `httpx.AsyncClient`)
   - Namespaces: `.decisions`, `.admin.policies`, `.admin.roles`, `.admin.relationships`, `.admin.delegations`, `.admin.sessions`
   - Auth helpers: `ApiKey("og_...")`, `BearerToken("eyJ...")` (open-shield JWT)
   - `RetryPolicy` — defaults: 3 attempts, exponential backoff 100ms / 400ms, retry on 5xx + connect/timeout errors, idempotent methods only
   - Typed exceptions: `OpenGuardError` → `AuthenticationError`, `AuthorizationServiceError`, `NotFoundError`, `ValidationError`, `RateLimitedError`, `ServerError`, `TransportError`
   - Context manager support (`with OpenGuardClient(...) as c:`)

7. **FEAT-013-py: SDK ↔ engine parity tests** — every method on `Guard` / `AsyncGuard` covered by Decision endpoints has an SDK method that, when pointed at an in-process service, returns equivalent results.

8. **Reference Dockerfile** — `deploy/service/Dockerfile` building a minimal image with `[service,sql-async,shield]` extras. No published image.

9. **New optional extras** in `pyproject.toml`:
   - `[service]` → `fastapi>=0.129.0`, `uvicorn[standard]>=0.40.0`
   - `[shield]` → `open-shield-python>=...` (version pinned during implementation)
   - `[client]` → `httpx>=0.27.0`

10. **Integration guide section** for Service Mode + SDK with executable examples (mirrors prior phase pattern, prevents doc rot).

### Out of Scope (Deferred)

- **gRPC service** — Phase 11. Proto schema, codegen toolchain, streaming semantics warrant their own phase.
- **TypeScript / Go SDKs** — Phase 11. Validate the wire contract once with the Python SDK first.
- **MCP `/tools/check` endpoint** — Phase 11 (deferred to keep `[mcp]` out of the default service image).
- **Streaming / long-poll endpoints** (e.g., revocation event subscriptions) — Phase 11+ if real consumers ask. `RevocationStreamPort` stays in-process for now.
- **Webhooks for revocation events** — same.
- **Batch authorize endpoint** (`POST /v1/authorize/batch`) — defer until profiling shows N+1 over HTTP is a real bottleneck; consumers can also use `list_authorized`.
- **Published Docker image** — only Dockerfile shipped this phase.
- **Rate limiting / quota middleware** — operator concern; out of scope. Ports stay open for it.
- **OpenAPI client codegen** for non-Python languages — Phase 11.
- **Open-shield merge** (whether to absorb open-shield into open-guard) — explicitly deferred per roadmap; Phase 10 integrates open-shield as an *optional dependency*, not a merge.
- **AsyncDelegationEvaluator (FEAT-014)** / **Async ApprovalManager (FEAT-015)** — remain P2.

## Deliverables

| # | Deliverable | Verification |
|---|-------------|-------------|
| 1 | `uvicorn open_guard.service.app:create_app --factory` boots the service | Manual smoke + `tests/service/test_app_factory.py` |
| 2 | `POST /v1/authorize` round-trips through `Guard.authorize` | `pytest tests/service/test_decision_router.py` |
| 3 | `POST /v1/list_authorized`, `/authorize/traced`, `/authorize_and_consume` round-trip | same |
| 4 | `POST /v1/admin/*` (existing AdminRouter) mounts under configurable prefix | `pytest tests/service/test_admin_router_mount.py` + `test_prefix_configurable.py` |
| 5 | `ApiKeyAuth` validates a hashed key and binds tenant | `pytest tests/service/test_auth_apikey.py` |
| 6 | `ShieldAuth` validates an open-shield-issued JWT (when extra installed) | `pytest tests/service/test_auth_shield.py` (skipped if shield not installed) |
| 7 | BYO `CallableAuth` lets consumer plug custom logic | `pytest tests/service/test_auth_byo.py` |
| 8 | Tenant from auth claim; `X-Tenant-ID` rejected without admin scope | `pytest tests/service/test_tenant_routing.py` |
| 9 | Errors return `{"error": {"code", "message", "details"}}` envelope with correct HTTP codes | `pytest tests/service/test_error_envelope.py` |
| 10 | `OpenGuardClient` round-trips all Decision + Admin endpoints | `pytest tests/client/test_sync_client.py` |
| 11 | `AsyncOpenGuardClient` round-trips same | `pytest tests/client/test_async_client.py` |
| 12 | SDK retries 5xx + connect errors per `RetryPolicy` | `pytest tests/client/test_retry.py` |
| 13 | SDK maps HTTP errors to typed exceptions | `pytest tests/client/test_error_mapping.py` |
| 14 | E2E: SDK → service (ASGI transport) → in-memory backend | `pytest tests/e2e/test_service_client_e2e.py` |
| 15 | E2E: SDK → service → `sqlite+aiosqlite` backend | `pytest tests/e2e/test_service_sql_e2e.py` |
| 16 | Reference Dockerfile builds and runs | `docker build -f deploy/service/Dockerfile .` (manual / CI optional) |
| 17 | Integration guide section with executable examples | `pytest tests/integration/test_integration_guide_examples.py` |
| 18 | Full regression passes | `pytest` (target: 1170+ tests, ≥93% coverage) |

## Acceptance Criteria

1. `create_app(guard, auth=ApiKeyAuth(...))` returns a FastAPI app with both Decision and Admin routers mounted under `/v1` (default).
2. All 4 Decision endpoints accept the same input shapes as the corresponding `Guard` / `AsyncGuard` methods (Subject + Action + Resource + optional `session_id`, `chain_depth`, etc.) and return parity outputs.
3. All AdminRouter endpoints continue to work unchanged in semantics; only the mount prefix is parameterized.
4. Authentication is required by default; an unauthenticated request returns `401` with the error envelope. A request with valid auth but lacking required scope returns `403`.
5. The service never accepts `tenant_id` from the request body; tenant comes from `CallerContext.tenant_id`.
6. `X-Tenant-ID` override is honored only when the caller's scopes include `cross_tenant_admin`; otherwise rejected with `403`.
7. `ShieldAuth` is optional — the service runs without `open-shield-python` installed if `ApiKeyAuth` or `CallableAuth` is configured.
8. `OpenGuardClient` and `AsyncOpenGuardClient` cover every Decision and Admin endpoint; both raise typed exceptions; both honor `RetryPolicy`.
9. SDK is usable without installing the server: `pip install open-guard[client]` pulls only `httpx` + base deps.
10. Server is usable without the SDK: `pip install open-guard[service]` pulls FastAPI + uvicorn but no httpx.
11. Zero breaking changes: existing `Guard`, `AsyncGuard`, `PolicyAdmin`, and `AdminRouter` import paths and signatures unchanged.
12. Full test suite green; coverage ≥93%.
13. New ADR-0009 (Service Mode wire contract) and ADR-0010 (SDK shape) recorded in `specs/decisions/`.

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/architecture/integration-guide.md` | Existing in-process integration patterns; Phase 10 adds an "Over the wire" section |
| `specs/architecture/auth-model.md` | Tenant model, scopes, caller vs subject distinction |
| `specs/architecture/policy-engine.md` | What endpoints expose (authorize semantics) |
| Phase 7 plan/history | `AdminRouter` design, factory patterns to mirror for `create_app` |
| Phase 8 plan/history | OperationChain — service must round-trip the same evaluator-routing semantics |

## Cross-Repo Coordination

- **cerebrio-sapience** is the primary anticipated consumer of the SDK. Its existing in-process integration continues to work; Service Mode is additive. No coordination required to *complete* Phase 10 — but cerebrio-sapience consuming the SDK is the validation signal that tells us whether wire contract decisions held up.
- **open-shield-python** is consumed by `ShieldAuth` as an optional dep. Pin to a known-good release at implementation time. The "should we merge?" question stays explicitly deferred.

## Risk & Mitigations

| Risk | Mitigation |
|------|-----------|
| Wire-contract decisions ossify before real consumers exercise them | Ship with `SERVICE_API_VERSION = "v1"` constant + `Sunset` header support patterns documented; reserve breaking-change budget for v2 prefix if needed |
| `Guard.authorize_traced` returns rich nested structure that bloats wire payload | Trace serialization uses existing `DecisionTrace.model_dump()`; document size; offer optional `trace=false` short-circuit on `/authorize/traced` |
| API key storage cleartext leakage | Keys stored as SHA-256 hash only; cleartext returned exactly once on creation; SDK + admin docs warn explicitly |
| open-shield API drift breaks ShieldAuth | Pin version; ShieldAuth wraps a narrow surface (one validator call); drop-in replacement easy if shield evolves |
| SDK retry storms on `Guard.authorize_and_consume` (non-idempotent) | RetryPolicy default skips non-idempotent methods; documented per-method idempotency table |
