# Phase 3 — Agentic Core Contract: Tasks

> Mirrors plan.md. All tasks completed 2026-04-18. 417 tests pass, 98% coverage, mypy/ruff clean.

## Domain foundations

- [x] **T1** — `DecisionStatus` enum + backward-compatible `Decision.allowed` property (model_validator maps legacy `allowed=True/False` kwargs) — commit `2afff9c`
- [x] **T2** — `Subject.on_behalf_of` chain field + `chain_depth` + `root_actor` + `ancestors()` + `ChainDepthExceededError` — commit `40bada8`
- [x] **T3** — Trace entity graph: `PolicyMatch`, `ConditionResult`, `RelationMatch`, `SubjectSnapshot`, `EvaluatorTrace`, `DecisionTrace`; extend `Evaluation` additively with `matched_policies_detail`, `duration_ms`, `attributes_read` — commit `d94e796`
- [x] **T4** — `ApprovalStatus` enum, `ApprovalRequirement`, `ApprovalRequest` (with `make_hash`), `ApprovalDecision`, `ApprovalError` — commit `d94e796`
- [x] **T5** — Extend `Policy` with optional `requires_approval: ApprovalRequirement | None` — commit `d94e796`

## Approval substrate

- [x] **T6** — `ApprovalStorePort` abstract interface (create / get / find_by_hash / find_latest_by_hash / update / list_pending / expire_stale) — commit `dd3ce92`
- [x] **T7** — `InMemoryApprovalStore` + unit tests (tenant isolation, hash index, stale expiry) — commit `dd3ce92`
- [x] **T8** — `SQLAlchemyApprovalStore` + `approval_requests` table in `sql_models.py` + unit tests — commit `9a7cc79`
- [x] **T9** — `ApprovalManager` service (idempotent create, quorum any/all/N, TTL, clock injection) + unit tests — commits `162a6cc` (scaffold) + `93a723d` (tests)

## Chain + trace wiring

- [x] **T10** — `PolicyRouter.evaluate_traced()` builds `DecisionTrace` alongside `Decision`; chain snapshot rendered — commit `e79bc13`
- [x] **T11** — ABAC chain-aware attribute paths (`chain.root_actor.*`, `chain.depth`, `chain.immediate_actor.*`, `chain.ancestors` + `any_matches` operator) + tests — commit `c19d69a`
- [x] **T12** — All four evaluators emit `matched_policies_detail` (PolicyMatch list), `duration_ms`, `attributes_read` on `Evaluation` — commit `f485fde`

## Guard surface

- [x] **T13** — `Guard(approval_store=..., max_chain_depth=5, clock=...)` constructor; `authorize_traced()`, `approve()`, `reject()` APIs; chain-depth runtime enforcement — commit `34abd53`
- [x] **T14** — `authorize()` wires pending_approval flow: policy with `requires_approval` → `ApprovalManager.request_or_existing(...)` → `Decision(status=PENDING_APPROVAL, ...)`; subsequent calls honor approved/rejected/expired state via new `find_latest_by_hash` — commit `34abd53`

## Integration

- [x] **T15** — `tests/integration/test_chain_integration.py` — 5 cases: chain through all four evaluators, render in trace — commit `f545675`
- [x] **T16** — `tests/integration/test_approval_flow.py` — 7 cases: pending → approve/reject/expire; quorum cases; idempotency — commit `f545675`
- [x] **T17** — `tests/integration/test_decision_trace.py` — 5 cases: 4-evaluator trace; JSON roundtrip; deny composition; chain in trace — commit `f545675`
- [x] **T18** — `tests/integration/test_backward_compatibility.py` — 8 cases: Phase 0/1/2 patterns pass unchanged; legacy `Decision(allowed=...)` construction still works — commit `f545675`

## Release hygiene

- [x] **T19** — Public API exports in `__init__.py` (17 new symbols across chain, approval, trace) — commit `e512f5a`
- [x] **T20** — Bump version to `0.4.0` in `pyproject.toml` + `__init__.py`; append changelog entry; full suite ≥90% coverage (got 98%), mypy clean, ruff clean — commit `e512f5a`

## Phase close (not part of task execution — after T20)

- [x] Draft `retrospective.md` — commit pending in complete-phase
- [x] Run `/sync-docs` — auth-model.md extended with Phase 3 sections; impact-map.json gained 22 new topic mappings (commit `27a04f0`)
- [x] User ran `/complete-phase` — 2026-04-18; v0.4.0 released
