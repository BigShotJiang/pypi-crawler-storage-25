# Phase 3 — Agentic Core Contract: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:subagent-driven-development` (recommended) or `superpowers:executing-plans` to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add OBO identity chains, tri-state `Decision` with async approval, and `DecisionTrace` explainability to open-guard — all additively, zero breaking changes.

**Architecture:** `Subject` gains a recursive `on_behalf_of` field. `Decision` gains a `status` enum (ALLOWED/DENIED/PENDING_APPROVAL) while keeping `allowed` as a computed backward-compatible property. A new `ApprovalStorePort` + `ApprovalManager` handles async approval lifecycle. A new `DecisionTrace` entity captures per-evaluator reasoning, emitted only via opt-in `authorize_traced()`.

**Tech Stack:** Python 3.12+, Pydantic v2 (frozen models, computed fields, model validators), SQLAlchemy 2.0+ (approval_requests table).

**Dependency changes:** No new external deps.

---

## Execution order

TDD throughout: write failing tests, then implementation, then run, then lint/typecheck. Each task ends with a commit when its tests pass.

```
Domain foundations     →  T1 T2 T3 T4 T5
Approval substrate     →  T6 T7 T8 T9 T10
Chain + trace wiring   →  T11 T12 T13 T14
Guard surface          →  T15 T16
Integration            →  T17 T18 T19 T20
Release hygiene        →  T21 T22
```

---

## Task 1: `DecisionStatus` enum + backward-compatible `Decision`

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Failing tests**

Add test class `TestDecisionStatus`:

```python
from open_guard.domain.entities import Decision, DecisionStatus

class TestDecisionStatus:
    def test_allowed_construction_maps_to_status(self) -> None:
        d = Decision(allowed=True, reason="ok")
        assert d.status == DecisionStatus.ALLOWED
        assert d.allowed is True

    def test_denied_construction_maps_to_status(self) -> None:
        d = Decision(allowed=False, reason="nope")
        assert d.status == DecisionStatus.DENIED
        assert d.allowed is False

    def test_status_kwarg_precedence(self) -> None:
        d = Decision(status=DecisionStatus.PENDING_APPROVAL, reason="wait")
        assert d.status == DecisionStatus.PENDING_APPROVAL
        assert d.allowed is False  # derived: only ALLOWED -> True

    def test_pending_not_allowed(self) -> None:
        d = Decision(status=DecisionStatus.PENDING_APPROVAL)
        assert d.allowed is False

    def test_backward_compat_bool_check(self) -> None:
        """Existing user code: `if decision.allowed: ...` still works."""
        allowed = Decision(allowed=True)
        denied = Decision(allowed=False)
        assert bool(allowed.allowed) is True
        assert bool(denied.allowed) is False
```

- [ ] **Step 2: Implement**

```python
class DecisionStatus(StrEnum):
    ALLOWED = "allowed"
    DENIED = "denied"
    PENDING_APPROVAL = "pending_approval"


class Decision(Entity):
    status: DecisionStatus = Field(default=DecisionStatus.DENIED)
    reason: str = Field(default="")
    evaluations: list[Evaluation] = Field(default_factory=list)
    approval_request_id: str | None = Field(default=None)
    approval_requirement: "ApprovalRequirement | None" = Field(default=None)

    @model_validator(mode="before")
    @classmethod
    def _coerce_allowed(cls, data: Any) -> Any:
        if isinstance(data, dict) and "allowed" in data and "status" not in data:
            allowed = data.pop("allowed")
            data["status"] = (
                DecisionStatus.ALLOWED if allowed else DecisionStatus.DENIED
            )
        return data

    @computed_field  # type: ignore[prop-decorator]
    @property
    def allowed(self) -> bool:
        return self.status == DecisionStatus.ALLOWED
```

Import `model_validator, computed_field` from pydantic.

- [ ] **Step 3: Run tests, fix, lint**

```bash
pytest tests/unit/domain/test_entities.py::TestDecisionStatus -v
pytest tests/unit/domain/test_entities.py -v   # no regression
mypy --strict src/
ruff check src/ tests/
```

- [ ] **Step 4: Commit** — `feat(domain): add DecisionStatus enum with backward-compatible allowed property`

---

## Task 2: `Subject.on_behalf_of` chain field + depth validation

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `src/open_guard/domain/exceptions.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Failing tests**

```python
from open_guard.domain.entities import Subject, ActorType
from open_guard.domain.exceptions import ChainDepthExceededError

class TestSubjectChain:
    def test_no_chain_by_default(self) -> None:
        s = Subject(id="alice")
        assert s.on_behalf_of is None
        assert s.chain_depth == 0

    def test_two_link_chain(self) -> None:
        user = Subject(id="alice", actor_type=ActorType.USER)
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        assert agent.chain_depth == 1
        assert agent.on_behalf_of is user

    def test_three_link_chain(self) -> None:
        user = Subject(id="alice")
        a1 = Subject(id="agent1", on_behalf_of=user)
        a2 = Subject(id="agent2", on_behalf_of=a1)
        assert a2.chain_depth == 2

    def test_depth_exceeded_raises(self) -> None:
        """Default max_chain_depth is 5 — 6 links must raise."""
        s: Subject | None = None
        with pytest.raises(ChainDepthExceededError):
            for i in range(7):
                s = Subject(id=f"a{i}", on_behalf_of=s)

    def test_root_actor_helper(self) -> None:
        user = Subject(id="alice")
        agent = Subject(id="helper", on_behalf_of=user)
        sub = Subject(id="sub", on_behalf_of=agent)
        assert sub.root_actor is user

    def test_ancestors_iter(self) -> None:
        user = Subject(id="alice")
        agent = Subject(id="helper", on_behalf_of=user)
        sub = Subject(id="sub", on_behalf_of=agent)
        assert [a.id for a in sub.ancestors()] == ["helper", "alice"]
```

- [ ] **Step 2: Add exception**

```python
# exceptions.py
class ChainDepthExceededError(OpenGuardError):
    """Raised when a Subject.on_behalf_of chain exceeds the maximum depth."""
```

- [ ] **Step 3: Extend `Subject`**

```python
MAX_CHAIN_DEPTH_DEFAULT = 5

class Subject(Entity):
    id: str
    actor_type: ActorType = Field(default=ActorType.USER)
    attributes: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    on_behalf_of: "Subject | None" = Field(default=None)

    @model_validator(mode="after")
    def _check_depth(self) -> "Subject":
        if self.chain_depth > MAX_CHAIN_DEPTH_DEFAULT:
            raise ChainDepthExceededError(
                f"Subject chain depth {self.chain_depth} exceeds max "
                f"{MAX_CHAIN_DEPTH_DEFAULT}"
            )
        return self

    @computed_field  # type: ignore[prop-decorator]
    @property
    def chain_depth(self) -> int:
        if self.on_behalf_of is None:
            return 0
        return 1 + self.on_behalf_of.chain_depth

    @property
    def root_actor(self) -> "Subject":
        return self if self.on_behalf_of is None else self.on_behalf_of.root_actor

    def ancestors(self) -> Iterator["Subject"]:
        cur = self.on_behalf_of
        while cur is not None:
            yield cur
            cur = cur.on_behalf_of
```

Note: max_chain_depth is constructor-side bounded. `Guard(max_chain_depth=...)` in Task 15 enforces a *runtime* check with a configurable override, in addition to the construction-time default.

- [ ] **Step 4: Run tests, lint, commit** — `feat(domain): add Subject.on_behalf_of chain with depth enforcement`

---

## Task 3: `PolicyMatch`, `ConditionResult`, `RelationMatch`, `EvaluatorTrace`, `DecisionTrace` entities

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Failing tests**

```python
class TestDecisionTrace:
    def test_policy_match_shape(self) -> None:
        m = PolicyMatch(policy_id="p1", effect=PolicyEffect.ALLOW, matched=True, reason="ok")
        assert m.matched_conditions == []
        assert m.matched_relations == []

    def test_evaluator_trace_shape(self) -> None:
        t = EvaluatorTrace(evaluator="rbac", status=DecisionStatus.ALLOWED, duration_ms=1.5)
        assert t.matched_policies == []
        assert t.rejected_policies == []
        assert t.attributes_read == []

    def test_decision_trace_json_roundtrip(self) -> None:
        trace = DecisionTrace(
            decision_status=DecisionStatus.ALLOWED,
            final_reason="ok",
            composition="all-allow",
            duration_ms=2.0,
            timestamp=datetime(2026, 4, 17, tzinfo=timezone.utc),
        )
        js = trace.model_dump_json()
        back = DecisionTrace.model_validate_json(js)
        assert back == trace
        assert back.schema_version == "1.0"
```

- [ ] **Step 2: Implement**

```python
class ConditionResult(Entity):
    path: str
    operator: str
    expected: Any
    actual: Any
    matched: bool

class RelationMatch(Entity):
    object_type: str
    object_id: str
    relation: str
    subject: str  # "subject_type:subject_id"
    path: list[str] = Field(default_factory=list)

class PolicyMatch(Entity):
    policy_id: str
    effect: PolicyEffect
    matched: bool
    reason: str = ""
    matched_conditions: list[ConditionResult] = Field(default_factory=list)
    matched_relations: list[RelationMatch] = Field(default_factory=list)
    task_scope_ok: bool | None = None

class SubjectSnapshot(Entity):
    id: str
    actor_type: ActorType
    attributes: dict[str, Any] = Field(default_factory=dict)

class EvaluatorTrace(Entity):
    evaluator: str
    status: DecisionStatus
    matched_policies: list[PolicyMatch] = Field(default_factory=list)
    rejected_policies: list[PolicyMatch] = Field(default_factory=list)
    attributes_read: list[str] = Field(default_factory=list)
    duration_ms: float = 0.0

class DecisionTrace(Entity):
    schema_version: str = "1.0"
    decision_status: DecisionStatus
    final_reason: str = ""
    evaluator_results: list[EvaluatorTrace] = Field(default_factory=list)
    composition: str = ""
    actor_chain: list[SubjectSnapshot] = Field(default_factory=list)
    duration_ms: float = 0.0
    timestamp: datetime
```

- [ ] **Step 3: Extend existing `Evaluation` additively**

Add fields (keep old `matched_policies: list[str]` for BC):
```python
class Evaluation(Entity):
    evaluator: str
    allowed: bool
    reason: str = ""
    matched_policies: list[str] = Field(default_factory=list)  # BC
    # new:
    matched_policies_detail: list[PolicyMatch] = Field(default_factory=list)
    duration_ms: float = 0.0
    attributes_read: list[str] = Field(default_factory=list)
```

- [ ] **Step 4: Run, lint, commit** — `feat(domain): add DecisionTrace entity graph (PolicyMatch, EvaluatorTrace, ConditionResult, RelationMatch)`

---

## Task 4: `ApprovalStatus` enum + `ApprovalRequirement` + `ApprovalRequest` entities

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `src/open_guard/domain/exceptions.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Failing tests**

```python
class TestApprovalEntities:
    def test_approval_requirement_defaults(self) -> None:
        r = ApprovalRequirement(approvers=["role:manager"])
        assert r.quorum == "any"
        assert r.ttl is None
        assert r.channel is None

    def test_approval_requirement_quorum_int(self) -> None:
        r = ApprovalRequirement(approvers=["a", "b", "c"], quorum=2)
        assert r.quorum == 2

    def test_approval_request_hash_stable(self) -> None:
        r1 = ApprovalRequest.make_hash("t", "alice", "send", "email-42", "email")
        r2 = ApprovalRequest.make_hash("t", "alice", "send", "email-42", "email")
        assert r1 == r2
        assert len(r1) == 64  # sha256 hex

    def test_approval_request_hash_differs(self) -> None:
        h1 = ApprovalRequest.make_hash("t", "alice", "send", "email-42", "email")
        h2 = ApprovalRequest.make_hash("t", "alice", "send", "email-43", "email")
        assert h1 != h2
```

- [ ] **Step 2: Implement**

```python
class ApprovalStatus(StrEnum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"

class ApprovalRequirement(Entity):
    approvers: list[str]  # subject id patterns or role names
    quorum: int | Literal["any", "all"] = "any"
    ttl: timedelta | None = None
    channel: str | None = None  # "slack", "email", ...

class ApprovalRequest(Entity):
    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str
    request_hash: str  # sha256 of (tenant, subject_id, action, resource_id, resource_type)
    subject_id: str
    action_name: str
    resource_id: str
    resource_type: str
    status: ApprovalStatus = ApprovalStatus.PENDING
    requirement: ApprovalRequirement
    approvers_received: list[ApprovalDecision] = Field(default_factory=list)
    created_at: datetime
    expires_at: datetime | None = None
    resolved_at: datetime | None = None
    reason: str = ""

    @staticmethod
    def make_hash(tenant: str, subject_id: str, action: str, resource_id: str, resource_type: str) -> str:
        import hashlib
        raw = f"{tenant}|{subject_id}|{action}|{resource_id}|{resource_type}".encode()
        return hashlib.sha256(raw).hexdigest()

class ApprovalDecision(Entity):
    approver: str
    decision: Literal["approve", "reject"]
    reason: str = ""
    at: datetime
```

- [ ] **Step 3: Add `ApprovalError` to exceptions**

- [ ] **Step 4: Run, lint, commit** — `feat(domain): add ApprovalRequirement, ApprovalRequest, ApprovalStatus entities`

---

## Task 5: Extend `Policy` with `requires_approval`

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Failing test**

```python
def test_policy_requires_approval_defaults_none(self) -> None:
    p = Policy(tenant_id="t", evaluator_type="rbac")
    assert p.requires_approval is None

def test_policy_with_approval(self) -> None:
    req = ApprovalRequirement(approvers=["role:manager"])
    p = Policy(tenant_id="t", evaluator_type="rbac", requires_approval=req)
    assert p.requires_approval is req
```

- [ ] **Step 2: Add field**

```python
class Policy(Entity):
    # ... existing ...
    requires_approval: ApprovalRequirement | None = None
```

- [ ] **Step 3: Commit** — `feat(domain): add Policy.requires_approval field`

---

## Task 6: `ApprovalStorePort` interface

**Files:**
- Create: `src/open_guard/domain/ports/approval_store.py`
- Modify: `src/open_guard/domain/ports/__init__.py`

- [ ] **Step 1: Define port**

```python
from abc import ABC, abstractmethod
from open_guard.domain.entities import ApprovalRequest

class ApprovalStorePort(ABC):
    @abstractmethod
    def create(self, request: ApprovalRequest) -> ApprovalRequest: ...
    @abstractmethod
    def get(self, request_id: str, tenant_id: str) -> ApprovalRequest | None: ...
    @abstractmethod
    def find_by_hash(self, request_hash: str, tenant_id: str) -> ApprovalRequest | None: ...
    @abstractmethod
    def update(self, request: ApprovalRequest) -> ApprovalRequest: ...
    @abstractmethod
    def list_pending(self, tenant_id: str) -> list[ApprovalRequest]: ...
    @abstractmethod
    def expire_stale(self, tenant_id: str, now: datetime) -> int:
        """Mark pending requests whose expires_at <= now as EXPIRED. Returns count."""
```

- [ ] **Step 2: Export from __init__; commit** — `feat(ports): add ApprovalStorePort interface`

---

## Task 7: `InMemoryApprovalStore`

**Files:**
- Create: `src/open_guard/adapters/stores/memory_approval.py`
- Create: `tests/unit/adapters/stores/test_memory_approval.py`

- [ ] **Step 1: Write 8 tests** (create, get, find_by_hash, update idempotency, list_pending, expire_stale, tenant isolation, missing-id returns None)

- [ ] **Step 2: Implement with a `dict[tenant_id, dict[id, ApprovalRequest]]` and a hash-index**

- [ ] **Step 3: Run, lint, commit** — `feat(adapters): InMemoryApprovalStore`

---

## Task 8: `SQLAlchemyApprovalStore` + schema

**Files:**
- Modify: `src/open_guard/adapters/stores/sql_models.py` (add `approval_requests` table)
- Create: `src/open_guard/adapters/stores/sql_approval.py`
- Create: `tests/unit/adapters/stores/test_sql_approval.py`

- [ ] **Step 1: Add SQL table**

```python
approval_requests = Table(
    "approval_requests",
    metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(64), nullable=False, index=True),
    Column("request_hash", String(64), nullable=False, index=True),
    Column("subject_id", String(128), nullable=False),
    Column("action_name", String(128), nullable=False),
    Column("resource_id", String(128), nullable=False),
    Column("resource_type", String(64), nullable=False),
    Column("status", String(32), nullable=False),
    Column("requirement", JSON, nullable=False),
    Column("approvers_received", JSON, nullable=False),
    Column("created_at", DateTime(timezone=True), nullable=False),
    Column("expires_at", DateTime(timezone=True), nullable=True),
    Column("resolved_at", DateTime(timezone=True), nullable=True),
    Column("reason", String(1024), nullable=False, default=""),
    UniqueConstraint("tenant_id", "request_hash", "status", name="uq_tenant_hash_status"),
)
```

Unique on `(tenant, hash, status)` — multiple historical requests for the same hash are fine, but at most one PENDING at a time per hash.

- [ ] **Step 2: Mirror memory tests, implement store**

- [ ] **Step 3: Run, lint, commit** — `feat(adapters): SQLAlchemyApprovalStore + approval_requests table`

---

## Task 9: `ApprovalManager` service

**Files:**
- Create: `src/open_guard/domain/services/approval_manager.py`
- Create: `tests/unit/domain/services/test_approval_manager.py`

**Responsibilities:**
- `request_or_existing(tenant, subject, action, resource, requirement, clock) -> ApprovalRequest` — idempotent by hash; returns existing PENDING if one exists and not expired
- `approve(request_id, tenant, approver, clock) -> ApprovalRequest` — validates approver matches requirement, applies quorum, transitions status
- `reject(request_id, tenant, approver, reason, clock) -> ApprovalRequest` — any rejection = final REJECTED
- `check_status(request_id, tenant, clock) -> ApprovalStatus` — auto-expires on read

- [ ] **Step 1: Tests covering:**
  - Idempotency: same call twice returns same request
  - Quorum "any": one approve → APPROVED
  - Quorum "all": N approvals → APPROVED, one reject → REJECTED
  - Quorum int N: need N distinct approvers
  - TTL: expired request rejected on read
  - Approver mismatch: approval from non-listed approver raises `ApprovalError`

- [ ] **Step 2: Implement with injected `Clock` protocol (match Phase 1 TBAC pattern)**

- [ ] **Step 3: Commit** — `feat(services): ApprovalManager with idempotency, quorum, TTL`

---

## Task 10: Chain propagation through `PolicyRouter`

**Files:**
- Modify: `src/open_guard/domain/services/policy_router.py`
- Modify: `tests/unit/domain/services/test_policy_router.py`

Chain data already rides inside `request.subject.on_behalf_of` — no signature change needed. Router responsibilities added:
- Capture `request.subject` chain into a `SubjectSnapshot` list for the trace
- Pass-through — evaluators read `request.subject` and can walk the chain themselves

- [ ] **Step 1: Test — router invokes all evaluators and evaluations preserve chain context (indirect via evaluator assertions)**

- [ ] **Step 2: Refactor router to also build an optional `DecisionTrace` when requested**

Add a new method `evaluate_traced(request) -> tuple[Decision, DecisionTrace]` that:
- Records start/end timestamps per evaluator
- Collects `matched_policies_detail` into `EvaluatorTrace`
- Renders `actor_chain` from `request.subject`
- Returns both outputs

Keep `evaluate()` as the cheap path — still returns `Decision` only.

- [ ] **Step 3: Commit** — `refactor(router): add evaluate_traced with DecisionTrace assembly`

---

## Task 11: ABAC chain-aware predicates

**Files:**
- Modify: `src/open_guard/adapters/evaluators/abac.py`
- Modify: `tests/unit/adapters/evaluators/test_abac.py`

- [ ] **Step 1: Failing tests**

```python
class TestABACChain:
    def test_condition_reads_chain_root_attribute(self) -> None:
        user = Subject(id="alice", attributes={"trusted": True})
        agent = Subject(id="helper", actor_type=ActorType.AGENT, on_behalf_of=user)
        policy = Policy(
            tenant_id="t", evaluator_type="abac", effect=PolicyEffect.ALLOW,
            action_match="read",
            conditions={
                "chain.root_actor.attributes.trusted": {"op": "eq", "value": True}
            },
        )
        # evaluate: agent (delegated by alice) → allowed
        assert evaluator.evaluate(request_with(agent, policy)).allowed

    def test_condition_reads_chain_depth(self) -> None:
        # Policy: deny if chain_depth > 2
        ...

    def test_any_ancestor_matches(self) -> None:
        # Policy: "any ancestor has attribute admin=True"
        ...
```

- [ ] **Step 2: Implement attribute resolution for `chain.*` paths**

Extend `_resolve_attribute_path(path, request)`:
- `chain.root_actor.X` → walk `subject.root_actor`, then resolve `X`
- `chain.depth` → `subject.chain_depth`
- `chain.immediate_actor.X` → alias for `subject.X`
- `chain.any_ancestor` — special-cased in condition evaluator: returns a list of ancestors; the condition's expected shape becomes a sub-condition applied `any()` across them

- [ ] **Step 3: Commit** — `feat(abac): chain-aware attribute predicates (chain.root_actor, chain.depth, chain.any_ancestor)`

---

## Task 12: Evaluators emit `PolicyMatch` detail + timing + attributes_read

**Files (all 4):**
- Modify: `src/open_guard/adapters/evaluators/rbac.py`
- Modify: `src/open_guard/adapters/evaluators/abac.py`
- Modify: `src/open_guard/adapters/evaluators/tbac.py`
- Modify: `src/open_guard/adapters/evaluators/rebac.py`
- Modify corresponding test files.

- [ ] **Step 1: Per evaluator — add**
  - Build `PolicyMatch` with `matched_conditions` per policy evaluated (matched and rejected)
  - Track `attributes_read` as the set of attribute paths referenced
  - Time the evaluation with `time.perf_counter_ns()`
  - Populate `Evaluation.matched_policies_detail`, `.duration_ms`, `.attributes_read`
  - Keep existing `Evaluation.matched_policies: list[str]` unchanged (BC)

- [ ] **Step 2: Per-evaluator tests**
  - `Evaluation.matched_policies_detail` contains a `PolicyMatch` for each rule considered
  - `PolicyMatch.matched_conditions` records path/op/expected/actual/matched for each condition
  - `Evaluation.attributes_read` contains the attribute paths touched
  - Timing is > 0

- [ ] **Step 3: Commit** — `feat(evaluators): emit structured PolicyMatch detail, timing, attributes_read`

---

## Task 13: `Guard.authorize_traced()`, `.approve()`, `.reject()` + chain-depth config

**Files:**
- Modify: `src/open_guard/domain/services/guard.py`
- Modify: `tests/unit/domain/services/test_guard.py`

- [ ] **Step 1: Signature updates**

```python
class Guard:
    def __init__(
        self,
        policy_store: PolicyStorePort,
        evaluators: list[EvaluatorPort] | None = None,
        approval_store: ApprovalStorePort | None = None,
        clock: Clock | None = None,
        max_chain_depth: int = 5,
    ) -> None: ...

    def authorize(self, subject, action, resource, tenant_id, context=None) -> Decision:
        self._check_chain_depth(subject)
        ...

    def authorize_traced(self, subject, action, resource, tenant_id, context=None) -> tuple[Decision, DecisionTrace]:
        ...

    def approve(self, request_id: str, tenant_id: str, approver: str) -> ApprovalRequest:
        ...

    def reject(self, request_id: str, tenant_id: str, approver: str, reason: str = "") -> ApprovalRequest:
        ...
```

- [ ] **Step 2: Tests**
  - `authorize_traced` returns `(Decision, DecisionTrace)` with populated evaluator traces
  - `approve` fails if no `approval_store` was configured (clear error)
  - `authorize` with chain > max_chain_depth raises `ChainDepthExceededError`
  - `approve`/`reject` delegate to `ApprovalManager`

- [ ] **Step 3: Commit** — `feat(guard): add authorize_traced, approve, reject, max_chain_depth`

---

## Task 14: Approval flow wired into `authorize()`

**Files:**
- Modify: `src/open_guard/domain/services/policy_router.py`
- Modify: `src/open_guard/domain/services/guard.py`
- Modify: `tests/unit/domain/services/test_guard.py`

**Semantics:**
- During router evaluation: when a matched *allow* policy has `requires_approval` set, the router returns a `PENDING_APPROVAL` pseudo-outcome rather than `ALLOWED`.
- Guard intercepts PENDING_APPROVAL: calls `ApprovalManager.request_or_existing(...)`, returns `Decision(status=PENDING_APPROVAL, approval_request_id=..., approval_requirement=...)`.
- On subsequent `authorize()`: Guard first checks for an existing request by hash:
  - APPROVED → allow (skip requires_approval check on re-eval)
  - REJECTED → deny with rejection reason
  - EXPIRED → deny with "approval expired"
  - PENDING → return the same pending decision (idempotent)
  - None → normal router evaluation (may again require approval)

- [ ] **Step 1: Tests**

```python
class TestApprovalFlow:
    def test_authorize_creates_pending(self) -> None:
        # policy with requires_approval → decision.status == PENDING_APPROVAL
        ...

    def test_second_authorize_returns_same_pending(self) -> None:
        # idempotent
        ...

    def test_approve_then_authorize_returns_allowed(self) -> None:
        ...

    def test_reject_then_authorize_returns_denied(self) -> None:
        ...

    def test_expired_then_authorize_returns_denied(self) -> None:
        ...

    def test_no_approval_store_with_requires_approval_policy_raises(self) -> None:
        # ApprovalError with clear message
        ...
```

- [ ] **Step 2: Implement in Guard**

- [ ] **Step 3: Commit** — `feat(guard): wire pending_approval flow through authorize()`

---

## Task 15: Integration test — chain propagation end-to-end

**File:**
- Create: `tests/integration/test_chain_integration.py`

- [ ] Test matrix: `user → agent → subagent` (2-link chain) chain:
  - RBAC policy with immediate subject match (agent) → allow
  - ABAC policy with `chain.root_actor.attributes.cleared == True` → allow / deny paths
  - TBAC task owned by the agent — chain doesn't violate scope
  - ReBAC relation `document#viewer@user:alice` — chain traversal works when the immediate subject is the agent (policy walks to root)
- [ ] All pass → commit: `test(integration): chain propagation through all four evaluators`

---

## Task 16: Integration test — approval flow end-to-end

**File:**
- Create: `tests/integration/test_approval_flow.py`

- [ ] Setup Guard with InMemoryApprovalStore, Policy with requires_approval
- [ ] Walk: authorize → PENDING → approve → authorize → ALLOWED
- [ ] Walk: authorize → PENDING → reject → authorize → DENIED
- [ ] Walk: authorize → PENDING → (advance clock past TTL) → authorize → DENIED (expired)
- [ ] Quorum "all" with two approvers
- [ ] Commit: `test(integration): pending approval flow with quorum and TTL`

---

## Task 17: Integration test — DecisionTrace end-to-end

**File:**
- Create: `tests/integration/test_decision_trace.py`

- [ ] Compose four evaluators + policies covering each
- [ ] Call `authorize_traced(...)` → assert trace has 4 evaluator entries
- [ ] Each evaluator has `matched_policies` OR `rejected_policies` populated
- [ ] `actor_chain` rendered for delegated subject
- [ ] `trace.model_dump_json()` → `DecisionTrace.model_validate_json(json)` equals original
- [ ] `trace.schema_version == "1.0"`
- [ ] Commit: `test(integration): DecisionTrace end-to-end with JSON roundtrip`

---

## Task 18: Integration test — backward compatibility

**File:**
- Create: `tests/integration/test_backward_compatibility.py`

- [ ] Recreate five common v0.3.0 usage patterns verbatim (from Phase 2 integration tests)
- [ ] All return `Decision(allowed=True/False)` via legacy kwarg
- [ ] All read `decision.allowed` — still works
- [ ] All read `decision.evaluations[].matched_policies` — still a list of str
- [ ] No mention of `status` / `on_behalf_of` / trace
- [ ] Commit: `test(integration): prove v0.3.0 patterns unchanged`

---

## Task 19: Public API surface + `__init__.py` exports

**File:**
- Modify: `src/open_guard/__init__.py`
- Modify: `src/open_guard/domain/__init__.py`
- Modify: `src/open_guard/adapters/stores/__init__.py`

- [ ] Export new types: `DecisionStatus`, `ApprovalStatus`, `ApprovalRequirement`, `ApprovalRequest`, `DecisionTrace`, `EvaluatorTrace`, `PolicyMatch`, `ConditionResult`, `RelationMatch`, `SubjectSnapshot`, `ChainDepthExceededError`, `ApprovalError`, `ApprovalStorePort`, `InMemoryApprovalStore`, `SQLAlchemyApprovalStore`.
- [ ] Commit: `feat(api): export Phase 3 public types`

---

## Task 20: Version bump + CHANGELOG

**Files:**
- Modify: `pyproject.toml` → `version = "0.4.0"`
- Modify: `src/open_guard/__init__.py` → `__version__ = "0.4.0"`
- Create: `specs/changelog/2026-04.md` entry (or append) with Phase 3 summary

- [ ] Run full suite: `pytest -v --cov=open_guard --cov-report=term-missing`
- [ ] Verify coverage ≥ 90%
- [ ] `mypy --strict src/` clean
- [ ] `ruff check src/ tests/` clean
- [ ] Commit: `chore(release): bump version to 0.4.0`

---

## Task 21: Record history + architecture sync (at phase close)

**Files:**
- Modify: `specs/phases/phase-3-agentic-core/history.md` (append `[DECISION]` entries for each ADR as they land — done during T1-T20)
- Modify: `specs/architecture/auth-model.md` (via `/sync-docs` at phase close, NOT during tasks — per Rule 9)

Per Rule 9, architecture doc updates happen at phase close via `/sync-docs`, not mid-phase. History entries appended live as decisions are made.

- [ ] Final: retrospective.md drafted
- [ ] Run `/sync-docs` (before `/complete-phase`)
- [ ] Then user runs `/complete-phase`

---

## Design invariants (apply everywhere)

1. **No breaking changes.** Every change additive. All 270 v0.3.0 tests pass without modification.
2. **TDD.** Write tests first, fail, implement, pass, lint, commit.
3. **Frozen Pydantic.** All entities `model_config = ConfigDict(frozen=True)`.
4. **UTC internally.** All datetimes `tzinfo=timezone.utc`.
5. **Clock injection.** Any time-dependent service accepts a `Clock` protocol for tests.
6. **Chain depth is a hard limit.** Not a soft warning. Both construction (default 5) and Guard runtime (configurable) enforce.
7. **Approval dispatch is out.** Library never sends messages. Consumer reads `Decision.approval_requirement` and dispatches.
8. **Trace is opt-in.** Standard `authorize()` never materializes `DecisionTrace`.
9. **Hash-based idempotency.** `(tenant, subject.id, action.name, resource.id, resource.resource_type)` — order matters for determinism.
10. **Status is the source of truth.** `Decision.allowed` is derived. Never set both in new code.
