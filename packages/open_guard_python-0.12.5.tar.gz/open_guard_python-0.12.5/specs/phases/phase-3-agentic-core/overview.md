# Phase 3 — Agentic Core Contract

> **Status**: Not Started
> **Estimated Effort**: 5-6 days
> **Depends On**: Phase 2 (ReBAC + SQLAlchemy + ABAC Enhancements) — v0.3.0
> **Version Target**: v0.4.0
> **Breaking Changes**: None (fully additive)

## Goal

Evolve open-guard's core contracts — `Subject`, `Decision`, and `Evaluation` — to make it a first-class authorization substrate for agentic systems. Specifically:

1. **OBO identity chains** (FEAT-005): `Subject` becomes a recursive structure so agents can act on behalf of users or other agents, with enforced depth limits and chain-aware policy predicates.
2. **Tri-state Decision with async approval** (FEAT-007): `Decision` gains a `status` enum and optional approval fields; policies can require human approval; consumers resume via `guard.approve()` / `guard.reject()`.
3. **DecisionTrace — first-class explainability** (FEAT-008): Opt-in `authorize_traced()` returns a structured trace of which policies fired, which conditions matched, how the chain was resolved, and why competing policies lost.

Every change is **additive**. Existing `guard.authorize(subject, action, resource, tenant_id)` code keeps working unchanged. `Decision.allowed` remains a readable boolean via a derived property.

## Theme: Why these three together

Shipping these features independently would create churn:

- FEAT-007 without FEAT-008 → pending_approval returns an opaque state; approvers can't see *why* approval was required.
- FEAT-008 without FEAT-007 → traces encode a boolean world; no way to represent "not yet decided."
- Both without FEAT-005 → traces and approval reasons can't cite the chain (*"agent X acting on behalf of user Y triggered policy Z"*).

One breaking-contract-evolution release (even though it happens to be non-breaking in practice) is better than three. After v0.4.0, Phase 4 can layer agent-integration surface (`list_authorized`, MCP adapter) and Phase 5 can add delegation/budgets/leases — all on top of a stable chain + trace + approval foundation.

## Key Decisions

| Decision | Choice | Rationale | ADR |
|----------|--------|-----------|-----|
| Chain representation | Recursive `Subject.on_behalf_of: Subject \| None` field on the existing entity | Minimal surface; additive; composes with all four evaluators; typed traversal | ADR-0001 |
| Decision evolution | Add `DecisionStatus` enum (`allowed`/`denied`/`pending_approval`); keep `Decision.allowed` as a computed `@property` reading from status | Backward-compatible: every `if decision.allowed` check keeps working; new code reads `decision.status` | ADR-0002 |
| Trace API | Dual method — `authorize()` returns `Decision` (cheap), `authorize_traced()` returns `(Decision, DecisionTrace)` (full trace) | Pay trace cost only when needed; keeps hot path fast | ADR-0003 |
| Approval storage | New `ApprovalStorePort` + `InMemoryApprovalStore` + `SQLAlchemyApprovalStore` | Approvals have their own lifecycle distinct from policies/tasks/tuples; mirrors existing store pattern | ADR-0004 |
| Approval idempotency | Requests deduplicated by SHA-256 of `(tenant_id, subject.id, action.name, resource.id, resource.resource_type)` — same call twice → same pending request | Prevents approval storms when agents retry | ADR-0005 |
| Approval dispatch | Open-guard returns approval metadata (channel hint, approvers, ttl); consumer ships to Slack/email/webhook | Transport-neutral library; consumers control integration | ADR-0006 |
| Chain-aware ABAC | Add three operators: `chain.root_actor`, `chain.any_ancestor`, `chain.depth` accessible via attribute path | Lets existing ABAC condition machinery reason over chains — no new condition type | ADR-0007 |
| Chain depth limit | Default max depth 5, configurable on `Guard(max_chain_depth=...)` | Prevents runaway subagent trees; matches industry defaults (Auth0, Cerbos) | — |
| DecisionTrace schema | JSON-serializable Pydantic model with `schema_version: str = "1.0"` field | Consumers can pin; upgrades are contract changes requiring major bump | — |
| Trace privacy | Traces always returned only when explicitly requested (`authorize_traced`); never included in standard `authorize()` | Prevents accidental leakage of policy internals through API responses | — |

## Source Structure

```
src/open_guard/
  domain/
    entities.py                       # MODIFY — add DecisionStatus, ApprovalStatus, ApprovalRequirement,
                                      #          ApprovalRequest, PolicyMatch, DecisionTrace, EvaluatorTrace;
                                      #          extend Subject (on_behalf_of), Decision (status field),
                                      #          Evaluation (matched_policies_detail, duration_ms, attributes_read)
    exceptions.py                     # MODIFY — add ApprovalError, ChainDepthExceededError
    ports/
      approval_store.py               # NEW — ApprovalStorePort abstract interface
  adapters/
    evaluators/
      abac.py                         # MODIFY — chain-aware attribute resolution (chain.root_actor, any_ancestor, depth)
      rbac.py                         # MODIFY — emit PolicyMatch detail, timing
      tbac.py                         # MODIFY — emit PolicyMatch detail, timing
      rebac.py                        # MODIFY — emit PolicyMatch detail with relation trace, timing
    stores/
      memory_approval.py              # NEW — InMemoryApprovalStore
      sql_approval.py                 # NEW — SQLAlchemyApprovalStore
      sql_models.py                   # MODIFY — add approval_requests table
  domain/services/
    guard.py                          # MODIFY — add authorize_traced, approve, reject; chain propagation;
                                      #          approval lifecycle (request creation + resume)
    policy_router.py                  # MODIFY — build DecisionTrace; propagate chain; record timing
    approval_manager.py               # NEW — approval request creation, dedup, TTL, status management
  __init__.py                         # MODIFY — export new public API

tests/
  unit/
    domain/
      test_entities.py                # MODIFY — Subject.on_behalf_of, DecisionStatus, PolicyMatch,
                                      #          ApprovalRequirement, ApprovalRequest, depth enforcement
    adapters/
      evaluators/
        test_abac.py                  # MODIFY — chain-aware predicates
        test_rbac.py                  # MODIFY — chain subject fallback, PolicyMatch emission
        test_tbac.py                  # MODIFY — chain respects, PolicyMatch emission
        test_rebac.py                 # MODIFY — chain respects, relation trace
      stores/
        test_memory_approval.py       # NEW
        test_sql_approval.py          # NEW
    services/
      test_guard.py                   # MODIFY — authorize_traced, approve/reject, chain validation
      test_approval_manager.py        # NEW — idempotency, TTL, multi-approver quorum
      test_policy_router.py           # MODIFY — trace assembly
  integration/
    test_chain_integration.py         # NEW — end-to-end chain through all four evaluators
    test_approval_flow.py             # NEW — end-to-end pending_approval → approve → authorize(allow)
    test_decision_trace.py            # NEW — end-to-end trace output with JSON serialization
    test_backward_compatibility.py    # NEW — prove all v0.3.0 patterns still work unchanged
```

## Scope

### In Scope

**FEAT-005 — OBO identity chains:**
- `Subject.on_behalf_of: Subject | None` recursive field (default `None`)
- Chain-depth validation on `Subject` construction (raises `ChainDepthExceededError`)
- Configurable `Guard(max_chain_depth=5)` (default 5)
- Chain propagates through every evaluator's decision context
- ABAC chain predicates accessible via attribute paths:
  - `chain.root_actor.id`, `chain.root_actor.attributes.*`
  - `chain.any_ancestor` — used with conditions like `{"any": {"attributes.trusted": {"equals": True}}}`
  - `chain.depth` (integer)
- `DecisionTrace.actor_chain` renders the resolved chain

**FEAT-007 — Tri-state Decision + async approval:**
- `DecisionStatus` enum: `ALLOWED`, `DENIED`, `PENDING_APPROVAL`
- `Decision.status: DecisionStatus` field; `Decision.allowed: bool` becomes `@property` derived from status (True iff status == ALLOWED)
- `Decision.approval_request_id: str | None` when pending
- `Decision.approval_requirement: ApprovalRequirement | None` (hint for dispatch)
- `Policy.requires_approval: ApprovalRequirement | None` new field
- `ApprovalRequirement` entity with `approvers: list[str]`, `quorum: Literal["any", "all"] | int`, `ttl: timedelta | None`, `channel: str | None`
- `ApprovalRequest` entity with `id`, `tenant_id`, `subject_id`, `action_name`, `resource_id`, `resource_type`, `status`, `approvers_received`, `created_at`, `expires_at`, `requirement`, `request_hash`
- `ApprovalStatus` enum: `PENDING`, `APPROVED`, `REJECTED`, `EXPIRED`
- `ApprovalStorePort` with CRUD + `find_by_hash()` for idempotency
- `InMemoryApprovalStore` + `SQLAlchemyApprovalStore` (new table)
- `Guard.approve(request_id, approver)` and `Guard.reject(request_id, approver, reason)` APIs
- Idempotent creation: same `(tenant, subject.id, action.name, resource.id, resource.resource_type)` → same pending request (hash-keyed)
- TTL enforcement: expired requests return `DENIED` on next authorize; explicit cleanup method `ApprovalStorePort.expire_stale()`
- Multi-approver semantics: `quorum="any"` (default), `quorum="all"`, or integer N

**FEAT-008 — DecisionTrace:**
- `PolicyMatch` entity: `policy_id`, `effect`, `matched: bool`, `reason`, `matched_conditions: list[ConditionResult]`, `matched_relations: list[RelationMatch]` (ReBAC), `task_scope_ok: bool | None` (TBAC)
- `ConditionResult` entity: `path`, `operator`, `expected`, `actual`, `matched: bool`
- `RelationMatch` entity: `object_type`, `object_id`, `relation`, `subject`, `path: list[str]` (traversal path)
- `EvaluatorTrace` entity: `evaluator`, `status` (ALLOWED/DENIED), `matched_policies: list[PolicyMatch]`, `rejected_policies: list[PolicyMatch]`, `attributes_read: list[str]`, `duration_ms: float`
- `DecisionTrace` entity: `schema_version: str = "1.0"`, `decision_status`, `final_reason`, `evaluator_results: list[EvaluatorTrace]`, `composition: str`, `actor_chain: list[SubjectSnapshot]`, `duration_ms: float`, `timestamp: datetime`
- `Guard.authorize_traced(...)` returns `tuple[Decision, DecisionTrace]`
- `DecisionTrace.to_json()` / `.from_json()` — stable serialization
- Existing `Evaluation` extended (additive) with `matched_policies_detail: list[PolicyMatch]`, `duration_ms: float`, `attributes_read: list[str]` — kept to preserve v0.3.0 API shape

### Out of Scope (Backlogged)

- `list_authorized()` / RAG filter API (FEAT-006) — Phase 4
- MCP tool-call authorization adapter (FEAT-009) — Phase 4
- Push/pull delegation primitives (FEAT-001) — Phase 5
- Usage-counted / budget-capped permissions (FEAT-002) — Phase 5
- Heartbeat/lease renewal (FEAT-003) — Phase 5
- Prompt-injection-resistant policy isolation docs (FEAT-010) — Phase 5
- Approval dispatch integrations (Slack, email, webhook) — external concern
- Approval UI — external concern
- OpenTelemetry span integration — external concern
- SIEM forwarders / trace storage backends — external concern
- Scope narrowing *across* chain hops (intersection semantics) — FEAT-001 territory
- Token/JWT signature verification for chains — belongs in open-shield-python
- Declarative policy DSL — deferred (original Phase 3 item)
- Casbin / OPA / OpenFGA external adapters — deferred (original Phase 3 item)
- Service mode (HTTP/gRPC wrapper) — deferred (original Phase 3 item)

## Deliverables

| Deliverable | Verification |
|-------------|-------------|
| `Subject.on_behalf_of` recursive field + depth limit | `pytest tests/unit/domain/test_entities.py -v -k chain` |
| Chain propagates through all four evaluators | `pytest tests/integration/test_chain_integration.py -v` |
| ABAC chain-aware predicates (root_actor, any_ancestor, depth) | `pytest tests/unit/adapters/evaluators/test_abac.py -v -k chain` |
| `DecisionStatus` + backward-compatible `Decision.allowed` property | `pytest tests/unit/domain/test_entities.py -v -k decision_status` |
| `ApprovalStorePort` + both implementations | `pytest tests/unit/adapters/stores/test_memory_approval.py tests/unit/adapters/stores/test_sql_approval.py -v` |
| `Guard.approve()` / `Guard.reject()` APIs | `pytest tests/unit/domain/services/test_guard.py -v -k approval` |
| End-to-end pending → approve → allow flow | `pytest tests/integration/test_approval_flow.py -v` |
| Idempotent approval request creation | `pytest tests/unit/domain/services/test_approval_manager.py -v -k idempot` |
| Multi-approver quorum (any / all / N) | `pytest tests/unit/domain/services/test_approval_manager.py -v -k quorum` |
| TTL expiry of approval requests | `pytest tests/unit/domain/services/test_approval_manager.py -v -k ttl` |
| `DecisionTrace` full structure + JSON roundtrip | `pytest tests/integration/test_decision_trace.py -v` |
| `authorize_traced()` returns populated trace | `pytest tests/unit/domain/services/test_guard.py -v -k traced` |
| Chain-aware trace rendering | `pytest tests/integration/test_decision_trace.py -v -k chain` |
| All Phase 2 patterns still pass unchanged | `pytest tests/integration/test_backward_compatibility.py -v` |
| All 270 existing tests still pass | `pytest -v` |
| Type safety | `mypy --strict src/` |
| Code quality | `ruff check src/ tests/` |
| Coverage threshold | `pytest --cov=open_guard --cov-report=term-missing` ≥ 90% |

## Acceptance Criteria

1. `Subject(id="x", actor_type=USER)` — existing construction works unchanged; `on_behalf_of=None` by default
2. `Subject(id="agent", on_behalf_of=Subject(id="user"))` constructs a two-link chain; chains beyond `max_chain_depth` raise `ChainDepthExceededError`
3. `decision.allowed` returns `True` iff `decision.status == DecisionStatus.ALLOWED` — all v0.3.0 code using `if decision.allowed:` works identically
4. A policy with `requires_approval=ApprovalRequirement(...)` causes `authorize()` to return `Decision(status=PENDING_APPROVAL, approval_request_id=...)`
5. Calling `authorize()` twice with the same `(tenant, subject, action, resource)` while a pending request exists returns the *same* `approval_request_id`
6. `guard.approve(request_id, approver="alice")` transitions the request; subsequent `authorize()` with the same request returns `Decision(status=ALLOWED)`
7. `guard.reject(request_id, approver="alice", reason="...")` transitions to REJECTED; subsequent `authorize()` returns `Decision(status=DENIED, reason=...)`
8. Expired approval requests: subsequent `authorize()` returns `Decision(status=DENIED, reason="approval expired")`
9. `guard.authorize_traced(...)` returns `(Decision, DecisionTrace)` where the trace contains one `EvaluatorTrace` per participating evaluator with `matched_policies` and `rejected_policies` populated
10. `DecisionTrace.actor_chain` renders the full chain with each `Subject.id`, `actor_type`, and relevant attributes (minus secrets — `attributes` included as-is, no masking in this phase)
11. `DecisionTrace.to_json()` produces JSON that `DecisionTrace.from_json()` round-trips exactly
12. ABAC condition `{"attribute_path": "chain.root_actor.attributes.trusted", "operator": "equals", "value": True}` correctly evaluates against the chain root
13. `Guard(policy_store=..., evaluators=[...], max_chain_depth=3)` enforces the custom depth
14. All 270 Phase 2 tests pass with zero modifications (proves backward compatibility)
15. Tests: ≥90% coverage, `mypy --strict` clean, `ruff` clean
16. Version bumped to 0.4.0 in `pyproject.toml` and `__init__.py`
17. `specs/architecture/auth-model.md` updated with chain + approval + trace sections (sync-docs at phase close)

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/architecture/auth-model.md` | Current Subject/Decision/Evaluation shapes — the extension targets |
| `specs/backlog/details/FEAT-005.md` | OBO chains detail |
| `specs/backlog/details/FEAT-007.md` | Tri-state Decision detail |
| `specs/backlog/details/FEAT-008.md` | DecisionTrace detail |
| IETF draft-ietf-oauth-identity-chaining | Cross-domain chain semantics |
| RFC 8693 | OAuth Token Exchange — `act` claim chain representation |
| Auth0 for AI Agents — Async Authorization | Approval pattern reference |
| Cerbos `Plan Resources` API | DecisionTrace prior art |
| OpenFGA `Expand` API | Relation traversal in traces |
| NIST SP 800-162 (ABAC) | Audit-trail requirements |
| XACML 3.0 `AdviceExpressions` / `ObligationExpressions` | Obligation-adjacent trace structure |
