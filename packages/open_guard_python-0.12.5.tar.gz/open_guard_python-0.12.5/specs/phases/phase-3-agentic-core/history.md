# Phase 3 — Agentic Core Contract: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [DECISION] 2026-04-17 — Phase 3 theme: Agentic Core Contract (not original "Policy Engine + External Adapters")
Topics: scope, phase-theme, agentic-era, project-management
Affects-phases: phase-3-agentic-core, phase-4 (future), phase-5 (future)
Affects-specs: specs/planning/roadmap.md
Detail: Original Phase 3 framing (Policy DSL + Casbin/OPA/OpenFGA adapters + service mode) was written before the agentic-era backlog grooming on 2026-04-17 surfaced 9 new P1 items. Those nine items cannot fit one phase. Brainstorm converged on "Agentic Core Contract" as the theme: FEAT-005 (OBO chains) + FEAT-007 (tri-state Decision) + FEAT-008 (DecisionTrace) — three simultaneous evolutions of Guard's core contracts (Subject, Decision, Evaluation). Rationale: (1) the three features are symbiotic — pending_approval needs traces to be useful; traces need non-binary decisions to have meaning; both need chain to cite origins; (2) one contract evolution is better than three staggered ones; (3) deferring FEAT-009 MCP before FEAT-007 would mean shipping MCP twice. Follow-on: Phase 4 "Agent Integration Surface" (FEAT-006 + FEAT-009), Phase 5 "Delegation & Bounds" (FEAT-001/002/003). Original Phase 3 work (DSL, Casbin/OPA adapters) deferred to a later phase or dropped if agentic primitives make it unnecessary.

---

### [DECISION] 2026-04-17 — v0.4.0 is additive (not breaking) — keep Decision.allowed as a computed property
Topics: backward-compatibility, decision, api-evolution, pydantic
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#decision
Detail: Initially expected FEAT-007 to be a breaking change (binary → tri-state Decision). After inspecting current Decision shape (`allowed: bool`, `reason: str`, `evaluations: list[Evaluation]`), discovered we can keep Decision.allowed as a Pydantic `@computed_field @property` reading from a new `status: DecisionStatus` field. A `model_validator(mode="before")` translates legacy `Decision(allowed=True)` construction into `status=ALLOWED`. Every `if decision.allowed:` call site keeps working. All 270 Phase 2 tests will pass unmodified — enforced via tests/integration/test_backward_compatibility.py. ADR-0002 will record this.

---

### [DECISION] 2026-04-17 — Chain representation: recursive Subject.on_behalf_of (not separate entity)
Topics: obo, identity-chain, subject, data-model
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#subject
Detail: Considered three shapes for identity chains: (a) new ChainLink entity referencing subjects, (b) ReBAC tuples with `acts_on_behalf_of` relation, (c) recursive field on existing Subject. Chose (c). Reasoning: minimal surface, additive (`None` default), composes with all four evaluators without special-casing, typed traversal via `.on_behalf_of`, derived `chain_depth` / `root_actor` / `ancestors()` helpers. (a) is heavier; (b) conflates identity with ReBAC relations and forces a store lookup per authorize. Note: terminology in detail docs says "Actor" but actual code entity is `Subject` — implementation uses `Subject.on_behalf_of`. ADR-0001 will record this.

---

### [DECISION] 2026-04-17 — Dual API: authorize() returns Decision, authorize_traced() returns (Decision, DecisionTrace)
Topics: decision-trace, api-design, explainability, performance
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#decision-trace
Detail: DecisionTrace is expensive to materialize (per-evaluator PolicyMatch lists, timing, attributes_read). Considered always returning it, a flag argument, or a separate method. Chose separate method. Reasoning: (1) hot path stays cheap — existing `authorize()` callers pay nothing; (2) trace privacy defaults to off — preventing accidental leakage of policy internals through consumer API responses; (3) cleaner type signatures — one method returns one thing; (4) DecisionTrace schema carries `schema_version = "1.0"` so consumers can pin against breaking changes in trace shape. ADR-0003 will record this.

---

### [DECISION] 2026-04-17 — ApprovalStorePort as new port (not bolted onto PolicyStorePort)
Topics: approval, store, port, separation-of-concerns
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#approval
Detail: Approval requests are operational state with their own lifecycle (PENDING → APPROVED/REJECTED/EXPIRED), distinct from policies (rules) and tuples (facts). Mirrors the Phase 2 decision to give ReBAC tuples a separate RelationshipStorePort. Keeps single-responsibility at the port level. `ApprovalStorePort` + `InMemoryApprovalStore` + `SQLAlchemyApprovalStore` (new `approval_requests` table with unique constraint on tenant_id+hash+status). Clock injected into `ApprovalManager` service for testable TTL.

---

### [DECISION] 2026-04-17 — Idempotent approval requests keyed by SHA-256 of (tenant, subject.id, action.name, resource.id, resource.resource_type)
Topics: approval, idempotency, hashing
Affects-phases: none
Affects-specs: none
Detail: Prevents approval storms when agents retry. Field order matters — pipe-separated string hashed to stable 64-char hex. Unique index on (tenant, request_hash, status) ensures at most one PENDING per hash; historical completed records are fine (same hash allowed in APPROVED/REJECTED/EXPIRED state). `ApprovalStorePort.find_by_hash()` is the idempotency check during `ApprovalManager.request_or_existing()`.

---

### [DECISION] 2026-04-17 — Approval dispatch is consumer responsibility
Topics: approval, dispatch, transport-neutrality
Affects-phases: none
Affects-specs: specs/architecture/integration-guide.md#approval
Detail: open-guard stays transport-neutral. Decision carries `approval_requirement` (approvers, quorum, TTL, channel hint). Consumer reads this and dispatches via their own Slack/email/webhook/queue. Library never sends messages. Rationale: prevents forcing dependency on slack-sdk / smtplib / httpx into open-guard core; keeps security boundary clean; channel hints (`"slack"`, `"email"`, etc.) are advisory strings, not coupled types.

---

### [DECISION] 2026-04-17 — Chain-aware ABAC via attribute paths (chain.root_actor.*, chain.depth, chain.any_ancestor)
Topics: abac, chain, condition-operators
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#abac
Detail: Rather than new condition primitives, chain predicates are exposed through the existing ABAC attribute-path machinery. `chain.root_actor.attributes.trusted` resolves by walking to the chain root. `chain.depth` is an integer. `chain.any_ancestor` is special-cased: the expected shape becomes a sub-condition evaluated `any()` across ancestors. This keeps the ABAC DSL stable and avoids a parallel "chain language." Lands with policy examples in integration tests.

---

### [DECISION] 2026-04-17 — Chain depth default 5, configurable via Guard(max_chain_depth=...)
Topics: chain, limits, defense-in-depth
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#subject
Detail: Construction-time check (Pydantic validator) uses MAX_CHAIN_DEPTH_DEFAULT = 5 to reject obviously-bad chains early. Runtime check in `Guard.authorize()` accepts a custom `max_chain_depth` per Guard instance. Default 5 matches industry defaults (Auth0 typical, Cerbos configurable). Raises `ChainDepthExceededError` (new exception, subclass of `OpenGuardError`).

---

### [DECISION] 2026-04-17 — Detail docs layer introduced; Phase 3 brainstorm references them as source material
Topics: spec-driven-development, documentation-architecture
Affects-phases: none
Affects-specs: specs/README.md, specs/backlog/details/
Detail: Prior to brainstorm, the `specs/backlog/details/` directory existed (per `backlog.md` convention `[→](details/ID.md)`) but was empty. On 2026-04-17 six detail docs were written for complex P1 items (FEAT-001/005/006/007/008/009) plus a reusable TEMPLATE.md. specs/README.md was extended with the three-layer spec flow (row → detail → ADR → phase plan). This brainstorm draws its source material from those detail docs — ground-truthed then by inspecting the actual `Subject` / `Decision` / `Evaluation` shapes in code (which differ from the detail docs' "Actor" terminology).

---

### [NOTE] 2026-04-17 — Durable autonomy granted for Phase 3 execution
Topics: project-management, workflow
Affects-phases: phase-3-agentic-core
Affects-specs: none
Detail: User granted autonomy for Phase 3: plan and execute end-to-end (dev + tests + lint + typecheck), with user running `/complete-phase` at the end. Per Rule 6, merges to staging/main still require explicit approval. Feature-branch commits, pushes, and all implementation work proceed without per-step confirmation.

---
### [DECISION] 2026-04-18 — Drop Decision(allowed=True/False) legacy-kwarg BC shim
Topics: backward-compatibility, api-design, yagni, pre-1.0
Affects-phases: none
Affects-specs: specs/changelog/2026-04.md
Detail: Post-implementation, deliberately removed the `model_validator(mode="before")` that translated legacy `Decision(allowed=True/False)` construction to `status=`. Rationale: pre-1.0 library with no shipped consumers — BC shim is cost without benefit. `Decision.allowed` remains a `@computed_field` property for natural `if decision.allowed:` checks (that's API readability, not BC). All internal construction sites migrated to `Decision(status=DecisionStatus.ALLOWED/DENIED, ...)`. Also deleted `tests/integration/test_backward_compatibility.py` since v0.3.0 patterns are already covered by existing phase-specific integration suites. 417 -> 406 tests; 98% coverage unchanged.

---

