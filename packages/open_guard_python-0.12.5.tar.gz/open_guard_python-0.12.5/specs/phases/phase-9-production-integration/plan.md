# Phase 9 — Production Integration: Implementation Plan

> **Approach**: Bottom-up — smallest items first (ENH-020, ENH-021), then FEAT-017, then FEAT-016 (largest). Each task is independently committable.
> **Breaking changes**: None. All changes are additive.
> **Commit convention**: `feat(scope):` for new features, `refactor(scope):` for cleanups.

---

## Task 1: Public `sync_store` property (ENH-020)

**Why first**: Smallest change, immediate value. Any consumer sharing async/sync guard instances needs this.

### 1.1 Add `sync_store` property to all 6 async in-memory stores

```python
# src/open_guard/adapters/stores/async_memory.py

class AsyncInMemoryPolicyStore(AsyncPolicyStorePort):
    ...
    @property
    def sync_store(self) -> InMemoryPolicyStore:
        """Public accessor for the underlying sync store."""
        return self._sync
```

Apply the same pattern to:
- `AsyncInMemoryPolicyStore` → returns `InMemoryPolicyStore`
- `AsyncInMemoryRelationshipStore` → returns `InMemoryRelationshipStore`
- `AsyncInMemoryTaskStore` → returns `InMemoryTaskStore`
- `AsyncInMemoryApprovalStore` → returns `InMemoryApprovalStore`
- `AsyncInMemoryDelegationStore` → returns `InMemoryDelegationStore`
- `AsyncInMemorySessionStore` → returns `InMemorySessionStore`

### 1.2 Update factory to use `sync_store` instead of `_sync`

In `_build_async_memory_guard()` (factory.py line 181):
```python
# Before:
TBACEvaluator(task_store=task_store._sync)
# After:
TBACEvaluator(task_store=task_store.sync_store)
```

### 1.3 Tests

```python
# tests/test_sync_store_property.py
def test_async_policy_store_exposes_sync_store():
    store = AsyncInMemoryPolicyStore()
    assert isinstance(store.sync_store, InMemoryPolicyStore)
    assert store.sync_store is store._sync  # same instance
```

One test per store class (6 tests).

**Commit**: `feat(stores): expose public sync_store property on async in-memory stores (ENH-020)`

---

## Task 2: Relationship query API — `check_relationship` (ENH-021)

**Why second**: Small, self-contained, no dependencies on other tasks. Standard Zanzibar `Check` operation.

### 2.1 Add `check_relationship` to PolicyAdmin

```python
# src/open_guard/adapters/admin/sdk.py

def check_relationship(
    self,
    *,
    tenant_id: str,
    subject_id: str,
    subject_type: str = "user",
    relation: str,
    object_type: str,
    object_id: str,
) -> bool:
    """Check if a direct relationship exists between subject and object.

    Standard Zanzibar Check operation. Returns True if the relationship
    tuple exists, False otherwise. Does not traverse computed permissions
    — checks direct tuples only.
    """
    if not self._guard._relationship_store:
        raise ValueError("Guard has no relationship store configured")
    return self._guard._relationship_store.tuple_exists(
        tenant_id=tenant_id,
        object_type=object_type,
        object_id=object_id,
        relation=relation,
        subject_type=subject_type,
        subject_id=subject_id,
    )
```

### 2.2 Add AdminRouter endpoint

```python
# src/open_guard/api/fastapi/admin_router.py

@self._router.post("/relationships/check")
def check_relationship(req: CheckRelationshipRequest) -> dict:
    result = self._admin.check_relationship(
        tenant_id=req.tenant_id,
        subject_id=req.subject_id,
        subject_type=req.subject_type,
        relation=req.relation,
        object_type=req.object_type,
        object_id=req.object_id,
    )
    return {"exists": result}
```

### 2.3 Add schema

```python
# src/open_guard/api/fastapi/schemas.py

class CheckRelationshipRequest(BaseModel):
    """Check if a relationship exists."""
    tenant_id: str
    subject_id: str
    subject_type: str = "user"
    relation: str
    object_type: str
    object_id: str
```

### 2.4 Verification tests — standard membership patterns

Tests use domain-neutral vocabulary (groups, teams, organizations):

```python
# tests/test_check_relationship.py

def test_group_membership_pattern():
    """Standard pattern: is user X a member of group Y?"""
    guard = build_guard()
    admin = PolicyAdmin(guard)

    admin.add_relationship(
        tenant_id="t1", subject_id="alice", subject_type="user",
        relation="member_of", object_type="group", object_id="engineering",
    )

    # Positive — member exists
    assert admin.check_relationship(
        tenant_id="t1", subject_id="alice", subject_type="user",
        relation="member_of", object_type="group", object_id="engineering",
    ) is True

    # Negative — different group
    assert admin.check_relationship(
        tenant_id="t1", subject_id="alice", subject_type="user",
        relation="member_of", object_type="group", object_id="sales",
    ) is False

    # Negative — different relation
    assert admin.check_relationship(
        tenant_id="t1", subject_id="alice", subject_type="user",
        relation="owner_of", object_type="group", object_id="engineering",
    ) is False


def test_team_ownership_pattern():
    """Standard pattern: is user X an owner of team Y?"""
    ...

def test_org_hierarchy_pattern():
    """Standard pattern: is team X part of org Y?"""
    ...
```

Additional tests:
- Cross-tenant isolation (relationship in tenant A not visible in tenant B)
- Remove relationship → check returns False
- AdminRouter `/relationships/check` endpoint round-trip

**Commit**: `feat(admin): add check_relationship query API with membership pattern tests (ENH-021)`

---

## Task 3: Resource-scoped RBAC roles (FEAT-017)

**Standard pattern**: Google IAM binds roles to resources, AWS IAM scopes policies to resource ARNs, Azure RBAC assigns roles at resource group scope. open-guard extends `assign_role` to accept arbitrary `resource_match` constraints — consumer defines what scoping means.

### 3.1 Extend `PolicyAdmin.assign_role()`

```python
# src/open_guard/adapters/admin/sdk.py

def assign_role(
    self,
    *,
    tenant_id: str,
    subject_id: str,
    role: str,
    resource_type: str | None = None,
    resource_match: dict[str, Any] | None = None,   # NEW — arbitrary resource constraints
    actions: list[str] | None = None,
) -> Policy:
    """Assign a role by creating an RBAC policy scoped to the subject.

    If resource_match is provided, the role only applies when the resource
    being accessed has matching attributes. This enables resource-scoped
    role bindings (standard in Google IAM, AWS IAM, Azure RBAC).

    Examples:
        # Global role — applies everywhere
        assign_role(tenant_id="t1", subject_id="alice", role="admin")

        # Scoped to a department
        assign_role(tenant_id="t1", subject_id="alice", role="writer",
                    resource_match={"department": "engineering"})

        # Scoped to a region
        assign_role(tenant_id="t1", subject_id="alice", role="reader",
                    resource_match={"region": "us-east-1"})
    """
    rm: dict[str, Any] = dict(resource_match) if resource_match else {}
    if resource_type:
        rm["type"] = resource_type
    return self.create_policy(
        tenant_id=tenant_id,
        evaluator_type="rbac",
        subject_match={"roles": [role], "id": subject_id},
        action_match=actions[0] if actions and len(actions) == 1 else "*",
        resource_match=rm,
    )
```

### 3.2 Extend `PolicyAdmin.revoke_role()`

```python
def revoke_role(
    self, *, tenant_id: str, subject_id: str, role: str,
    resource_match: dict[str, Any] | None = None,
) -> None:
    """Revoke a role by removing matching RBAC policies.

    If resource_match is provided, only revokes the scoped policy (not global).
    """
    policies = self.list_policies(tenant_id, evaluator_type="rbac")
    for p in policies:
        sm = p.subject_match
        if (
            isinstance(sm, dict)
            and sm.get("id") == subject_id
            and role in sm.get("roles", [])
        ):
            if resource_match is not None:
                rm = p.resource_match
                if not isinstance(rm, dict) or rm != resource_match:
                    continue
            self.delete_policy(p.id, tenant_id)
```

### 3.3 Extend AdminRouter schema

```python
# src/open_guard/api/fastapi/schemas.py

class AssignRoleRequest(BaseModel):
    """Assign a role to a subject."""
    tenant_id: str
    subject_id: str
    role: str
    resource_type: str | None = None
    resource_match: dict[str, Any] | None = None   # NEW
    actions: list[str] | None = None
```

### 3.4 Wire `resource_match` in AdminRouter

```python
# src/open_guard/api/fastapi/admin_router.py — assign_role handler
return self._admin.assign_role(
    tenant_id=req.tenant_id,
    subject_id=req.subject_id,
    role=req.role,
    resource_type=req.resource_type,
    resource_match=req.resource_match,   # NEW
    actions=req.actions,
)
```

### 3.5 Tests — resource-scoped role scenarios

Tests use domain-neutral vocabulary:

```python
# tests/test_scoped_roles.py

def test_resource_scoped_roles():
    """Standard pattern: different roles for different resource scopes."""
    guard = build_guard()
    admin = PolicyAdmin(guard)
    tenant = "t1"

    # Writer in engineering department
    admin.assign_role(tenant_id=tenant, subject_id="alice", role="writer",
                      resource_match={"department": "engineering"})
    # Reader in support department
    admin.assign_role(tenant_id=tenant, subject_id="alice", role="reader",
                      resource_match={"department": "support"})

    # Writer in engineering → allowed
    decision = guard.authorize(AuthorizationRequest(
        subject=Subject(id="alice", attributes={"roles": ["writer"]}),
        action=Action(name="write"),
        resource=Resource(id="doc-1", resource_type="document",
                         attributes={"department": "engineering"}),
        tenant_id=tenant,
    ))
    assert decision.allowed is True

    # Writer in support → denied (only reader there)
    decision = guard.authorize(AuthorizationRequest(
        subject=Subject(id="alice", attributes={"roles": ["writer"]}),
        action=Action(name="write"),
        resource=Resource(id="doc-2", resource_type="document",
                         attributes={"department": "support"}),
        tenant_id=tenant,
    ))
    assert decision.allowed is False

def test_multi_attribute_resource_scope():
    """Resource match with multiple attributes (region + environment)."""
    ...

def test_global_role_still_works():
    """No resource_match = role applies everywhere (backward compatible)."""
    ...
```

Additional tests:
- Revoke scoped role without affecting other scopes
- `resource_type` + `resource_match` combined
- AdminRouter round-trip with `resource_match`

**Commit**: `feat(rbac): resource-scoped role assignment via resource_match (FEAT-017)`

---

## Task 4: SQL Backend for AsyncGuard factory (FEAT-016)

**Why last**: Largest task, depends on ENH-020 (uses `sync_store` property).

### 4.1 Add `_build_async_sql_guard()` to factory

```python
# src/open_guard/adapters/factory.py

async def _build_async_sql_guard(dsn: str, **kwargs: Any) -> Any:
    """Wire AsyncGuard with async SQLAlchemy stores and all 5 evaluators."""
    from sqlalchemy.ext.asyncio import create_async_engine

    from open_guard.adapters.evaluators.abac import ABACEvaluator
    from open_guard.adapters.evaluators.async_rebac import AsyncReBACEvaluator
    from open_guard.adapters.evaluators.rbac import RBACEvaluator
    from open_guard.adapters.evaluators.tbac import TBACEvaluator
    from open_guard.adapters.evaluators.trust import TrustGateEvaluator
    from open_guard.adapters.stores.async_sql import (
        AsyncSQLAlchemyPolicyStore,
        AsyncSQLAlchemyTaskStore,
    )
    from open_guard.adapters.stores.async_sql_approval import AsyncSQLAlchemyApprovalStore
    from open_guard.adapters.stores.async_sql_delegation import AsyncSQLAlchemyDelegationStore
    from open_guard.adapters.stores.async_sql_relationship import AsyncSQLAlchemyRelationshipStore
    from open_guard.adapters.stores.async_sql_session import AsyncSQLAlchemySessionStore
    from open_guard.adapters.stores.sql_models import metadata
    from open_guard.domain.ports.async_evaluator import AsyncEvaluatorPort
    from open_guard.domain.ports.evaluator import EvaluatorPort
    from open_guard.domain.services.async_guard import AsyncGuard

    engine = create_async_engine(dsn)

    # Create all tables
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)

    policy_store = AsyncSQLAlchemyPolicyStore(engine)
    task_store = AsyncSQLAlchemyTaskStore(engine)
    relationship_store = AsyncSQLAlchemyRelationshipStore(engine)

    # TBACEvaluator is sync — needs a sync task store.
    # For SQL backends, create a sync engine from the async DSN.
    sync_dsn = dsn.replace("+asyncpg", "").replace("+aiosqlite", "")
    from sqlalchemy import create_engine
    from open_guard.adapters.stores.sql import SQLAlchemyTaskStore
    sync_engine = create_engine(sync_dsn)
    sync_task_store = SQLAlchemyTaskStore(sync_engine)

    evaluators: list[EvaluatorPort | AsyncEvaluatorPort] = [
        RBACEvaluator(),
        ABACEvaluator(),
        TBACEvaluator(task_store=sync_task_store),
        AsyncReBACEvaluator(relationship_store=relationship_store),
        TrustGateEvaluator(),
    ]

    return AsyncGuard(
        policy_store=policy_store,
        evaluators=evaluators,
        approval_store=AsyncSQLAlchemyApprovalStore(engine),
        relationship_store=relationship_store,
        delegation_store=AsyncSQLAlchemyDelegationStore(engine),
        session_store=AsyncSQLAlchemySessionStore(engine),
        **kwargs,
    )
```

### 4.2 Update `build_async_guard()` to accept SQL backends

```python
async def build_async_guard(
    dsn: str | None = None, *, backend: str | None = None, **kwargs: Any
) -> Any:
    resolved = _resolve_backend(dsn, backend)

    if resolved == "memory":
        return _build_async_memory_guard(**kwargs)
    if resolved in ("sqlite", "postgresql"):
        return await _build_async_sql_guard(dsn, **kwargs)   # NEW
    raise ValueError(f"Unsupported async backend: {resolved!r}")
```

### 4.3 Update `_resolve_backend` for async DSN variants

```python
def _resolve_backend(dsn: str | None, backend: str | None) -> str:
    if backend:
        return backend
    if dsn is None:
        return "memory"
    if "sqlite" in dsn:          # catches sqlite+aiosqlite
        return "sqlite"
    if "postgresql" in dsn or "postgres" in dsn:  # catches postgresql+asyncpg
        return "postgresql"
    raise ValueError(...)
```

### 4.4 Tests

```python
# tests/test_async_sql_factory.py

import pytest
from open_guard.adapters.factory import build_async_guard

@pytest.mark.asyncio
async def test_build_async_guard_sqlite():
    """AsyncGuard with SQLite backend creates tables and works."""
    guard = await build_async_guard(dsn="sqlite+aiosqlite:///")
    assert guard is not None

@pytest.mark.asyncio
async def test_build_async_guard_memory_still_works():
    """Memory backend unchanged."""
    guard = await build_async_guard()
    assert guard is not None
```

Additional tests:
- Full authorize round-trip with SQL-backed AsyncGuard
- Policy persistence across guard rebuilds (same DB file)
- Verify all 6 stores are SQL-backed (not memory)

**Commit**: `feat(factory): wire async SQL backend for build_async_guard (FEAT-016)`

---

## Task 5: Integration test + regression

### 5.1 Full regression run

```bash
pytest --tb=short -q
```

Target: 1050+ tests, ≥94% coverage, zero failures.

### 5.2 Update `__init__.py` exports

Ensure `sync_store`, `check_relationship`, and async SQL factory are importable from expected paths.

**Commit**: `chore: Phase 9 integration test + export cleanup`
