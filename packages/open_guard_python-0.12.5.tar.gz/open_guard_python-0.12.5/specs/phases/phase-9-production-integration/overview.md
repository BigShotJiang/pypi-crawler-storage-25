# Phase 9 — Production Integration

> **Version**: v0.10.0
> **Status**: In Progress
> **Predecessor**: Phase 8 — AI-Era Primitives (v0.9.0)
> **Theme**: Close production-readiness gaps — persistent async backend, clean public APIs, resource-scoped RBAC, relationship queries

## Goal

Make open-guard fully production-ready for any consumer. After this phase, consumers can run AsyncGuard with persistent SQL backends, share state between async/sync guards via public APIs, assign roles scoped to specific resources, and query relationships directly — all standard authorization patterns found in Google IAM, AWS IAM, and Azure RBAC.

## Key Decisions

| # | Decision | Rationale |
|---|----------|-----------|
| 1 | Async SQL factory wiring, not new stores | All 6 async SQL stores already exist — the gap is factory `build_async_guard()` rejecting non-memory backends. Wire what exists. |
| 2 | `sync_store` as public `@property` on async memory stores | Any consumer sharing async/sync guard instances needs the underlying sync store. A public property is minimal, clean, and doesn't change internal structure. |
| 3 | Resource-scoped RBAC via `resource_match` dict on `assign_role` | Standard pattern (Google IAM resource bindings, AWS resource-scoped policies). Extends `assign_role` to accept arbitrary `resource_match` constraints — no evaluator changes needed. Consumer defines what scoping means for their domain. |
| 4 | `check_relationship()` as convenience method on PolicyAdmin | ReBAC evaluator already supports arbitrary relations. Gap is a public query API — add to PolicyAdmin (sync) and expose via AdminRouter. Standard in Zanzibar-derived systems (OpenFGA `Check`, SpiceDB `CheckPermission`). |
| 5 | Service Mode pushed to Phase 10 | These production-readiness items are higher priority. |

## Source Structure

```
src/open_guard/
├── adapters/
│   ├── factory.py                           # MODIFY — add _build_async_sql_guard()
│   ├── admin/
│   │   └── sdk.py                           # MODIFY — extend assign_role, add check_relationship
│   └── stores/
│       └── async_memory.py                  # MODIFY — add sync_store property to all 6 stores
├── api/
│   └── fastapi/
│       ├── schemas.py                       # MODIFY — add resource_match to AssignRoleRequest
│       └── admin_router.py                  # MODIFY — add check_relationship endpoint
```

## Scope

### In Scope

1. **FEAT-016: SQL Backend for AsyncGuard** — Wire `_build_async_sql_guard()` in factory using existing `AsyncSQLAlchemy{Policy,Task,Relationship,Approval,Delegation,Session}Store`. Accept `sqlite+aiosqlite://` and `postgresql+asyncpg://` DSNs. Auto-create tables. Mirror sync `_build_sql_guard()` pattern.

2. **ENH-020: Public `sync_store` accessor** — Add `@property sync_store` returning `self._sync` on all 6 `AsyncInMemory*Store` classes. Type-annotated with the concrete sync store type.

3. **FEAT-017: Resource-scoped RBAC roles** — Extend `PolicyAdmin.assign_role()` with optional `resource_match: dict` parameter for arbitrary resource constraints. Standard RBAC pattern — Google IAM binds roles to resources, AWS IAM scopes policies to resource ARNs, Azure RBAC assigns roles at resource group scope. Consumer defines their own resource attributes (e.g., `{"department": "engineering"}`, `{"region": "us-east"}`, `{"workspace_id": "ws-123"}`). Extend `revoke_role()` to match on `resource_match`. Extend `AssignRoleRequest` schema.

4. **ENH-021: Relationship query API — `check_relationship`** — Add `PolicyAdmin.check_relationship()` convenience method that queries the relationship store directly (no policy/authorize round-trip needed). Standard in Zanzibar-derived systems. Add `AdminRouter` endpoint. Write verification tests for common membership patterns (group membership, team membership, org hierarchy). Document as standard pattern in integration guide (history entry only — full doc sync at phase completion).

### Out of Scope (Deferred)

- Service Mode + SDKs — pushed to Phase 10
- Hierarchical scope resolution (e.g., parent-child resource inheritance) — generic design TBD
- Async `check_relationship` on AsyncGuard — can be added later; PolicyAdmin is sync
- Dedicated RoleAssignment entity — policy-based approach is sufficient
- AsyncDelegationEvaluator (FEAT-014) / Async ApprovalManager (FEAT-015) — remain P2

## Deliverables

| # | Deliverable | Verification |
|---|-------------|-------------|
| 1 | `build_async_guard(dsn="sqlite+aiosqlite:///...")` works | `pytest tests/test_async_sql_factory.py` |
| 2 | `build_async_guard(dsn="postgresql+asyncpg://...")` works | Manual or CI with PostgreSQL |
| 3 | `async_store.sync_store` returns sync store on all 6 classes | `pytest tests/test_sync_store_property.py` |
| 4 | `admin.assign_role(..., resource_match={"department": "eng"})` | `pytest tests/test_scoped_roles.py` |
| 5 | `admin.check_relationship(...)` returns bool | `pytest tests/test_check_relationship.py` |
| 6 | Full regression passes | `pytest` (target: 1050+ tests, ≥94% coverage) |

## Acceptance Criteria

1. `build_async_guard(dsn=...)` accepts SQLite and PostgreSQL DSNs, creates all tables, returns a working AsyncGuard
2. All 6 `AsyncInMemory*Store` classes expose `.sync_store` as a typed public property
3. `assign_role` with `resource_match` creates a policy that only matches resources with those attributes
4. `check_relationship` returns True/False for direct relationship existence
5. All existing tests pass — zero breaking changes
6. New tests cover all 4 deliverables

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/architecture/auth-model.md` | RBAC role model, ReBAC relation model |
| `specs/architecture/integration-guide.md` | Consumer integration patterns |
