# Phase 9 — Production Integration: Tasks

> **Convention**: `[ ]` = not started, `[/]` = in progress, `[x]` = done

---

## Task 1: Public `sync_store` property (ENH-020)

- [x] 1.1 Add `@property sync_store` to `AsyncInMemoryPolicyStore`
- [x] 1.2 Add `@property sync_store` to `AsyncInMemoryRelationshipStore`
- [x] 1.3 Add `@property sync_store` to `AsyncInMemoryTaskStore`
- [x] 1.4 Add `@property sync_store` to `AsyncInMemoryApprovalStore`
- [x] 1.5 Add `@property sync_store` to `AsyncInMemoryDelegationStore`
- [x] 1.6 Add `@property sync_store` to `AsyncInMemorySessionStore`
- [x] 1.7 Update factory `_build_async_memory_guard()` to use `.sync_store` instead of `._sync`
- [x] 1.8 Write tests — one per store class (6 tests) + idempotency test = 7 tests
- [x] 1.9 Commit: `feat(stores): expose public sync_store property on async in-memory stores (ENH-020)`

## Task 2: Relationship query API — `check_relationship` (ENH-021)

- [x] 2.1 Add `PolicyAdmin.check_relationship()` method
- [x] 2.2 Add `CheckRelationshipRequest` schema
- [x] 2.3 Add `AdminRouter` `/relationships/check` endpoint
- [x] 2.4 Write membership pattern tests (group, team, org — domain-neutral)
- [x] 2.5 Write cross-tenant isolation test
- [x] 2.6 Write AdminRouter endpoint round-trip test
- [x] 2.7 Commit: `feat(admin): add check_relationship query API with membership pattern tests (ENH-021)`

## Task 3: Resource-scoped RBAC roles (FEAT-017)

- [x] 3.1 Extend `PolicyAdmin.assign_role()` with `resource_match: dict` parameter
- [x] 3.2 Extend `PolicyAdmin.revoke_role()` to match on `resource_match`
- [x] 3.3 Add `resource_match` to `AssignRoleRequest` schema
- [x] 3.4 Wire `resource_match` in AdminRouter assign_role handler
- [x] 3.5 Write resource-scoped role scenario tests (department, region — domain-neutral)
- [x] 3.6 Write scoped revoke test (revoke one scope, keep others)
- [x] 3.7 Write backward compatibility test (no resource_match = works as before)
- [x] 3.8 Write multi-attribute resource_match test
- [x] 3.9 Commit: `feat(rbac): resource-scoped role assignment via resource_match (FEAT-017)`

## Task 4: SQL Backend for AsyncGuard factory (FEAT-016)

- [x] 4.1 `_resolve_backend()` already handles async DSN variants (sqlite+aiosqlite starts with "sqlite")
- [x] 4.2 Implement `_build_async_sql_guard()` — wire all 6 async SQL stores + sync TBACEvaluator
- [x] 4.3 Update `build_async_guard()` to route SQL backends to `_build_async_sql_guard()`
- [x] 4.4 Write test: `build_async_guard(dsn="sqlite+aiosqlite:///")` creates working guard
- [x] 4.5 Write test: full authorize round-trip with SQL-backed AsyncGuard
- [x] 4.6 Write test: policy persistence across guard rebuilds
- [x] 4.7 Write test: memory backend still works (backward compat)
- [x] 4.8 Commit: `feat(factory): wire async SQL backend for build_async_guard (FEAT-016)`

## Task 5: Integration + regression

- [x] 5.1 Full regression run — 1069 tests pass, 94% coverage
- [x] 5.2 Exports verified — build_async_guard, PolicyAdmin, AdminRouter all exported
