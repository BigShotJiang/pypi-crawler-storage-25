# Phase 9 — Production Integration: Retrospective

> **Completed**: 2026-04-28
> **Version**: v0.10.0
> **Duration**: ~1 session
> **Tests**: 1069 (1037 baseline + 32 new) | **Coverage**: 94%

## What Went Well

1. **Phase scope stayed tight to its mission.** Four narrowly-defined items (FEAT-016, FEAT-017, ENH-020, ENH-021) — each a P0 cerebrio-sapience integration blocker. No drift, no scope creep.

2. **Discovery cleared a fake task.** Initial plan assumed FEAT-016 needed building 6 async SQL stores. Investigation showed they already existed (Phase 7) — just unwired in the factory. Saved an entire phase of work.

3. **Reused existing primitives instead of inventing new ones.** Resource-scoped RBAC reuses the existing `resource_match` filter on RBAC policies — zero evaluator changes, zero new entities. `check_relationship` is a thin pass-through to the existing relationship store. Both shipped as pure API additions.

4. **Domain-neutral examples throughout.** Tests, history, and integration guide use generic vocabulary (department, region, group, team) — no consumer-specific leakage. open-guard remains vendor-neutral.

5. **Zero breaking changes.** All 4 items are additive: optional kwargs (`resource_match=None`), new methods (`check_relationship`), new factory routes (SQL DSNs), new public properties (`sync_store`).

## What Didn't Go Well

1. **Version drift in `pyproject.toml` discovered at completion.** `pyproject.toml` and `__version__` were still at 0.8.0 — Phase 8's release notes mentioned a bump but it didn't actually happen. Caught at /complete-phase, will bump straight to 0.10.0.

2. **No async `check_relationship` parity.** `check_relationship` is sync-only (PolicyAdmin is sync). Async consumers must reach into the relationship store directly. Added as a deferred follow-up — not blocking cerebrio-sapience.

## Lessons Learned

1. **Always re-check the codebase before planning new work.** The "build 6 async SQL stores" assumption nearly burned a sprint. A 5-minute grep saved a week. Pre-phase discovery should be mandatory.

2. **Wiring gaps are common, hidden, and high-leverage.** Phase 7 built async SQL stores but the factory rejected SQL DSNs. Phase 9 wired them. The fix was ~30 lines; the value (production-ready async backend) is huge. Watch for similar wiring gaps in future phases.

3. **Version-bump verification belongs in /complete-phase.** Two phases in a row with stale version strings (Phase 8's bump didn't land in pyproject) suggests this should be a hard check at completion time.

4. **A separate sync engine for sync evaluators inside async guards is a clean compromise.** Avoids forcing AsyncTBACEvaluator (which would cascade into AsyncTaskStorePort everywhere). Both engines share the database — the cost is one extra connection pool, the win is keeping TBAC simple.

## Metrics

| Metric | Target | Actual |
|--------|--------|--------|
| Tests | 1050+ | 1069 |
| Coverage | ≥94% | 94% |
| Breaking changes | 0 | 0 |
| P0 items closed | 4 | 4 (FEAT-016, FEAT-017, ENH-020, ENH-021) |
| New entities | 0 | 0 (pure API additions) |
| Commits | 4 feature + tracking | 4 feature + 1 tracking |

## Cross-Repo Impact

All 4 items are cerebrio-sapience integration blockers. With Phase 9 shipped, cerebrio-sapience can now:
- Run AsyncGuard against persistent SQL backends (SQLite or PostgreSQL)
- Share authorization state between async/sync guards via the public `sync_store` property
- Assign roles scoped to consumer-defined resource attributes (workspaces, projects, departments)
- Query relationship membership directly without a full authorize round-trip

## Next: Phase 10 — Service Mode + SDKs

- FEAT-012: HTTP/gRPC service wrapper around AdminRouter + Guard
- FEAT-013: Thin client SDKs in Python, TypeScript, Go
- Deferred from Phase 9 — production-readiness items took priority
