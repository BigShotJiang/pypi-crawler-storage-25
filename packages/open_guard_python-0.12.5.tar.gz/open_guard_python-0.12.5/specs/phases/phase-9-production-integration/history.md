# Phase 9 — Production Integration: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [SCOPE_CHANGE] 2026-04-20 — Phase 9 repurposed from Service Mode to Cerebrio P0 blockers
Topics: scope, phase-theme, roadmap, cerebrio-integration
Affects-phases: phase-9-production-integration, phase-10-service-mode (future)
Affects-specs: specs/planning/roadmap.md, specs/status.md
Detail: Original Phase 9 was "Service Mode + SDKs" (FEAT-012, FEAT-013). Repurposed to "Production Integration" — 4 P0 cerebrio-sapience blockers: FEAT-016 (async SQL factory), ENH-020 (sync_store accessor), FEAT-017 (workspace-scoped RBAC), ENH-021 (check_relationship API). Service Mode pushed to Phase 10.

---

### [DISCOVERY] 2026-04-20 — All 6 async SQL stores already exist
Topics: async, sql, stores, factory
Affects-phases: phase-9-production-integration
Affects-specs: none
Detail: Investigation revealed that all 6 `AsyncSQLAlchemy*Store` classes already exist (built in Phase 7). The factory's `build_async_guard()` simply never wired them — it rejects non-memory backends. FEAT-016 is factory wiring, not store creation.

---

### [DECISION] 2026-04-20 — Resource-scoped RBAC via resource_match dict, not dedicated entity
Topics: rbac, resource-scope, architecture
Affects-phases: phase-9-production-integration
Affects-specs: specs/architecture/auth-model.md
Detail: Resource-scoped roles could be modeled as a dedicated `RoleAssignment` entity with `scope` field, or by reusing existing RBAC policy `resource_match`. Chose policy-based approach: `assign_role(resource_match={"department": "eng"})` passes arbitrary constraints to the policy. No evaluator changes needed — RBAC evaluator already filters by resource_match. Standard pattern — Google IAM binds roles to resources, AWS IAM scopes to resource ARNs, Azure RBAC assigns at resource group scope. Consumer defines their own resource attributes.

---

### [DECISION] 2026-04-20 — check_relationship as PolicyAdmin method, not Guard method
Topics: rebac, api, convenience, zanzibar
Affects-phases: phase-9-production-integration
Affects-specs: specs/architecture/integration-guide.md
Detail: `check_relationship` queries the relationship store directly — it doesn't need policy evaluation. Standard Zanzibar `Check` operation (OpenFGA, SpiceDB). Placing it on PolicyAdmin (admin operations) rather than Guard (authorization decisions) is the right separation. Guard.authorize() is for "can X do Y to Z?" — check_relationship is for "does relationship R exist?" (data query, not authorization).

---

### [DECISION] 2026-04-20 — All domain vocabulary in phase must be generic, not consumer-specific
Topics: design, open-standard, naming
Affects-phases: phase-9-production-integration
Affects-specs: none
Detail: open-guard is a vendor-neutral authorization library. Phase files, tests, and documentation must use domain-neutral examples (groups, teams, departments, regions) — never consumer-specific vocabulary (workspaces, projects). Consumer-specific patterns belong in consumer repos, not in open-guard.

---

### [DECISION] 2026-04-20 — Sync TBACEvaluator in async SQL guard uses separate sync engine
Topics: tbac, async, sql, factory
Affects-phases: phase-9-production-integration
Affects-specs: none
Detail: TBACEvaluator is synchronous and needs a sync TaskStore. For async SQL guards, the factory creates a separate sync engine by stripping the async driver from the DSN (`+asyncpg` → ``, `+aiosqlite` → ``). Both engines share the same database. This avoids needing an AsyncTBACEvaluator (FEAT-014, still P2/deferred).

---

### [FEATURE] 2026-04-20 — All 4 P0 items implemented
Topics: enh-020, enh-021, feat-017, feat-016, implementation-complete
Affects-phases: phase-9-production-integration
Affects-specs: none
Detail: ENH-020 (sync_store property — 7 tests), ENH-021 (check_relationship API — 9 tests + AdminRouter endpoint), FEAT-017 (resource-scoped RBAC via resource_match — 8 tests), FEAT-016 (async SQL factory — 8 tests). 1069 total tests, 94% coverage, zero breaking changes. All 4 items committed and pushed to phase-9-production-integration branch.

---
