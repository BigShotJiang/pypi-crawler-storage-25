# Phase 7 — Consumer Integration

> **Status**: Planned
> **Target Version**: v0.8.0
> **Breaking Changes**: None (fully additive to v0.7.0)

## Goal

Make open-guard consumable by any Python application — sync or async — with minimal wiring. Provide one-liner factory construction, in-process administration SDK, tenant-scoped REST management API, database schema tooling, and native async support. After this phase, a consumer can go from `pip install open-guard[sql-async]` to a fully-wired async authorization system in under 10 lines of code.

## Motivation

open-guard has a complete authorization engine (RBAC + ABAC + TBAC + ReBAC, delegation, sessions, revocation) but no consumer-friendly onboarding path. Today, wiring a `Guard` requires manually importing and constructing 7+ stores, 4 evaluators, and multiple managers. There is no admin SDK, no migration tooling, and the entire library is synchronous — blocking adoption by async-first frameworks (FastAPI, Starlette, aiohttp) and async-first platforms.

This phase delivers the **integration surface** that turns open-guard from a collection of components into a batteries-included library.

## Consumption Patterns Enabled

| Pattern | Description | This Phase |
|---------|-------------|------------|
| **Embedded library** | `Guard.from_config()` / `AsyncGuard.from_config()` — in-process evaluation | Yes |
| **Library + Admin API** | Embedded eval + mounted FastAPI `AdminRouter` for management | Yes |
| **Centralized service** | Standalone deployment, all services talk to it via HTTP/gRPC | Phase 8 (architecture does not preclude) |

## Key Decisions

| # | Decision | Rationale |
|---|----------|-----------|
| 1 | `Guard.from_config(dsn, backend=)` factory — DSN string, no dict/YAML/TOML | Standard library pattern (SQLAlchemy `create_engine(url)`, Redis `from_url()`). Config file parsing is consumer responsibility. |
| 2 | Dual API: sync `Guard` unchanged, new `AsyncGuard` with native async stores | `to_thread()` wrapper causes thread pool saturation at 2-4 auth calls/request. SQLAlchemy `AsyncSession`, `redis.asyncio` set the precedent. |
| 3 | Evaluator logic stays sync inside `AsyncGuard` | RBAC/ABAC/TBAC evaluators are pure CPU (dict matching). Only store I/O goes async. ReBACEvaluator gets `AsyncReBACEvaluator` because it calls relationship store mid-traversal. |
| 4 | `PolicyAdmin` SDK as in-process class; `AdminRouter` as mountable FastAPI router | Layered: SDK is the core, REST wraps it. Phase 8 standalone server wraps the router. No tight coupling. |
| 5 | `create_all_tables()` + CLI + DDL export. No Alembic. | Schema creation is library concern. Migration history is consumer concern. |
| 6 | `[sql-async]` optional extra with `asyncpg` + `aiosqlite` | Mirrors `[sql]` pattern. Async consumers opt in explicitly. |

## Source Structure (New/Modified)

```
src/open_guard/
├── domain/
│   ├── ports/
│   │   ├── async_policy_store.py          # NEW — AsyncPolicyStorePort
│   │   ├── async_relationship_store.py    # NEW — AsyncRelationshipStorePort
│   │   ├── async_delegation_store.py      # NEW — AsyncDelegationStorePort
│   │   ├── async_session_store.py         # NEW — AsyncSessionStorePort
│   │   ├── async_approval_store.py        # NEW — AsyncApprovalStorePort
│   │   ├── async_task_store.py            # NEW — AsyncTaskStorePort
│   │   ├── async_candidate_resource.py    # NEW — AsyncCandidateResourcePort
│   │   └── async_evaluator.py             # NEW — AsyncEvaluatorPort (for ReBAC)
│   └── services/
│       ├── async_guard.py                 # NEW — AsyncGuard
│       ├── async_policy_router.py         # NEW — AsyncPolicyRouter
│       └── guard.py                       # MODIFIED — + from_config() class method
├── adapters/
│   ├── factory.py                         # NEW — from_config() wiring logic
│   ├── evaluators/
│   │   └── async_rebac.py                 # NEW — AsyncReBACEvaluator
│   ├── stores/
│   │   ├── async_memory.py                # NEW — async memory store wrappers
│   │   ├── async_sql.py                   # NEW — AsyncSQLAlchemyPolicyStore
│   │   ├── async_sql_relationship.py      # NEW — AsyncSQLAlchemyRelationshipStore
│   │   ├── async_sql_delegation.py        # NEW — AsyncSQLAlchemyDelegationStore
│   │   ├── async_sql_session.py           # NEW — AsyncSQLAlchemySessionStore
│   │   ├── async_sql_approval.py          # NEW — AsyncSQLAlchemyApprovalStore
│   │   └── async_sql_task.py              # NEW — AsyncSQLAlchemyTaskStore
│   └── admin/
│       ├── __init__.py                    # NEW
│       └── sdk.py                         # NEW — PolicyAdmin SDK
├── api/
│   └── fastapi/
│       ├── admin_router.py                # NEW — AdminRouter (REST management)
│       └── schemas.py                     # NEW — Request/response Pydantic models
├── cli/
│   ├── __init__.py                        # NEW
│   └── main.py                            # NEW — CLI entry point (db init, schema)
└── __init__.py                            # MODIFIED — re-exports

tests/
├── unit/
│   ├── test_factory.py                    # NEW — Guard.from_config() tests
│   ├── test_policy_admin.py               # NEW — PolicyAdmin SDK tests
│   ├── test_async_guard.py                # NEW — AsyncGuard tests
│   ├── test_async_stores_memory.py        # NEW — Async memory store tests
│   ├── test_async_stores_sql.py           # NEW — Async SQL store tests
│   └── test_async_rebac.py               # NEW — AsyncReBACEvaluator tests
├── integration/
│   ├── test_admin_router.py               # NEW — REST admin API tests
│   ├── test_async_integration.py          # NEW — Full async authorization flow
│   └── test_cli.py                        # NEW — CLI command tests
```

## Scope

### In Scope

- `Guard.from_config()` and `AsyncGuard.from_config()` factory methods
- `PolicyAdmin` in-process SDK (CRUD for roles, policies, relationships, delegations, sessions)
- `AdminRouter` mountable FastAPI router wrapping PolicyAdmin
- `create_all_tables()` programmatic function + CLI (`open-guard db init`) + DDL export (`open-guard db schema`)
- Async store port ABCs (mirrors of all 7 sync ports)
- Async memory store implementations
- Async SQLAlchemy store implementations (`[sql-async]` extra)
- `AsyncGuard` with `async def authorize()`, `authorize_traced()`, `list_authorized()`
- `AsyncReBACEvaluator` for async graph traversal
- `[sql-async]` optional extra (`asyncpg`, `aiosqlite`, `sqlalchemy[asyncio]`)

### Out of Scope (Explicitly Excluded)

- Standalone server / `open-guard serve` → Phase 8 (Service Mode)
- gRPC interface → Phase 8
- Language SDKs (TS/Go thin clients) → Phase 8+
- SSD/DSD constraints (ENH-002/003)
- PIP / Obligations (ENH-008/009)
- Alembic / migration history management
- Reverse-ABAC query compilation (ENH-014)
- Zookie consistency tokens (ENH-015)

## Deliverables & Acceptance Criteria

### D1: Guard Factory (`Guard.from_config()`)

```python
# Memory (tests)
guard = Guard.from_config(backend="memory")

# SQLite (edge)
guard = Guard.from_config("sqlite:///local.db")

# PostgreSQL (production)
guard = Guard.from_config("postgresql://user:pass@host/db")

# Async variants
guard = await AsyncGuard.from_config("postgresql+asyncpg://user:pass@host/db")
guard = await AsyncGuard.from_config("sqlite+aiosqlite:///local.db")
guard = await AsyncGuard.from_config(backend="memory")
```

**Acceptance**: All three backends work. Returns fully-wired Guard/AsyncGuard with all stores and evaluators. Zero manual wiring.

### D2: PolicyAdmin SDK

```python
admin = PolicyAdmin(guard)
await admin.assign_role(tenant_id="t1", subject_id="alice", role="editor", resource_type="doc")
await admin.add_relationship(tenant_id="t1", subject_id="alice", relation="member", object_type="project", object_id="p1")
await admin.create_policy(tenant_id="t1", evaluator_type="abac", action_match="read", conditions={...})
await admin.create_delegation(tenant_id="t1", from_subject_id="alice", to_subject_id="bob", scope={...})
```

**Acceptance**: CRUD for policies, roles (as RBAC policies), relationships, delegations, sessions. Tenant-scoped. Validation errors on bad input. Works with both sync Guard and AsyncGuard.

### D3: Admin REST API

```python
from open_guard.api.fastapi import AdminRouter
app.include_router(AdminRouter(admin=admin), prefix="/admin")
```

Routes: `POST/GET/DELETE /admin/policies`, `POST/GET/DELETE /admin/roles`, `POST/GET/DELETE /admin/relationships`, `POST/GET/DELETE /admin/delegations`, `POST/GET/DELETE /admin/sessions`, `GET /admin/health`.

**Acceptance**: All CRUD routes work. Tenant-scoped via header or path. Pagination. Proper error responses (400/404/409).

### D4: DB Schema Tooling

```bash
open-guard db init --dsn "postgresql://..."
open-guard db init --dsn "sqlite:///local.db"
open-guard db schema --dialect postgresql
open-guard db schema --dialect sqlite
```

**Acceptance**: `init` creates all tables. `schema` outputs DDL SQL. Programmatic `create_all_tables(engine)` also works.

### D5: Async Support

- `AsyncGuard` with `async def authorize()`, `authorize_traced()`, `list_authorized()`, `approve()`, `reject()`, `delegate()`, `authorize_and_consume()`
- Async store ports for all 7 stores
- Async memory store implementations
- Async SQLAlchemy store implementations
- `AsyncReBACEvaluator` for async graph traversal
- `[sql-async]` optional extra

**Acceptance**: Full async authorization flow (policy → evaluate → decide) works with asyncpg and aiosqlite. All existing sync tests still pass. Async tests cover the same scenarios.

## Backlog Items Resolved

| ID | Title |
|----|-------|
| FEAT-011 | Management APIs — Role/Policy/Delegation/Relationship CRUD |

## New Backlog Items (to be created)

| ID | Title | Priority |
|----|-------|----------|
| TBD | AsyncDelegationEvaluator (async delegation fallback in AsyncGuard) | P2 |
| TBD | Async ApprovalManager | P2 |

## Reference Specs

| Spec | Path | Relevant Sections |
|------|------|-------------------|
| Auth Model | `specs/architecture/auth-model.md` | All — defines the domain PolicyAdmin operates on |
| Integration Guide | `specs/architecture/integration-guide.md` | Quick Start, all phase sections — will need Phase 7 section |
| Policy Engine | `specs/architecture/policy-engine.md` | Policy structure — informs PolicyAdmin CRUD contracts |

## Quality Gates

- All 806+ existing tests pass unchanged (zero breaking changes)
- Coverage >= 95% (floor 93%)
- `ruff check src/ tests/` clean
- `mypy --strict src/` clean
- New async tests mirror key sync test scenarios
