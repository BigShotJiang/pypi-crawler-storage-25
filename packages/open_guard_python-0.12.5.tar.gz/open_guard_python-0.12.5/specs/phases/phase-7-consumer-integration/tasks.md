# Phase 7 — Consumer Integration: Task Checklist

> Mirrors `plan.md` tasks. Mark `[x]` on completion, `[/]` for in-progress.

## Deliverable 1: Guard Factory (OG-1)

- [x] **T1** — `Guard.from_config()` factory + wiring logic + tests

## Deliverable 2: DB Schema Tooling (OG-4)

- [x] **T2** — `create_all_tables()` + `get_ddl()` + tests
- [x] **T3** — CLI entry point (`open-guard db init/schema`) + pyproject.toml + tests

## Deliverable 3: PolicyAdmin SDK (OG-2 / FEAT-011)

- [x] **T4** — PolicyAdmin in-process SDK (policies, roles, relationships, delegations, sessions CRUD) + tests

## Deliverable 4: Admin REST API (OG-3 / FEAT-011)

- [x] **T5** — Request/response Pydantic schemas
- [x] **T6** — AdminRouter (FastAPI) wrapping PolicyAdmin + tests

## Deliverable 5: Async Support (OG-5 + OG-6)

- [x] **T7** — Async store port ABCs (all 7 stores + evaluator + candidate resource)
- [x] **T8** — Async in-memory store implementations + tests
- [x] **T9** — Async SQLAlchemy store implementations (`[sql-async]` extra) + tests
- [x] **T10** — AsyncReBACEvaluator (async graph traversal) + tests
- [x] **T11** — AsyncPolicyRouter (async policy fetch + evaluator dispatch)
- [x] **T12** — AsyncGuard (`from_config()`, `authorize()`, `list_authorized()`, full API) + tests

## Wrap-up

- [x] **T13** — Re-exports in `__init__.py` + pyproject.toml updates + version bump to v0.8.0
- [x] **T14** — Integration guide Phase 7 section + executable mirror tests
- [x] **T15** — Quality gates: full regression, coverage >= 95%, ruff, mypy --strict

## Quality Gates

- [x] All 806+ existing tests pass unchanged (zero breaking changes)
- [x] Coverage >= 95% (floor 93%) — achieved 94%
- [x] `ruff check src/ tests/` clean
- [x] `mypy --strict src/` clean
- [x] New async tests mirror key sync test scenarios
- [x] `Guard.from_config(backend="memory")` → working guard
- [x] `AsyncGuard.from_config(backend="memory")` → working async guard
- [x] `PolicyAdmin` CRUD works for all entity types
- [x] `AdminRouter` all routes return correct status codes
- [x] `open-guard db init --dsn ...` creates all tables
