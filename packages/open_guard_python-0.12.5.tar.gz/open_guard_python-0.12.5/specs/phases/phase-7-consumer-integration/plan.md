# Phase 7: Consumer Integration — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make open-guard consumable by any Python app — sync or async — with one-liner factory, admin SDK, REST management, DB tooling, and native async support.

**Architecture:** Five deliverables layered on the existing clean/hexagonal architecture. The factory wires existing components. Async ports mirror sync ports. AsyncGuard mirrors Guard. PolicyAdmin operates on existing stores. AdminRouter wraps PolicyAdmin. CLI wraps `create_all_tables()`.

**Tech Stack:** Python 3.12+, Pydantic v2, SQLAlchemy 2.0 (sync `[sql]` + async `[sql-async]`), asyncpg, aiosqlite, FastAPI, click/typer (CLI), pytest + pytest-asyncio, ruff, mypy --strict.

---

## File Map

### New Files

| File | Responsibility |
|------|---------------|
| `src/open_guard/adapters/factory.py` | `_build_guard()` / `_build_async_guard()` — internal wiring logic for `from_config()` |
| `src/open_guard/domain/ports/async_policy_store.py` | `AsyncPolicyStorePort` ABC |
| `src/open_guard/domain/ports/async_relationship_store.py` | `AsyncRelationshipStorePort` ABC |
| `src/open_guard/domain/ports/async_delegation_store.py` | `AsyncDelegationStorePort` ABC |
| `src/open_guard/domain/ports/async_session_store.py` | `AsyncSessionStorePort` ABC |
| `src/open_guard/domain/ports/async_approval_store.py` | `AsyncApprovalStorePort` ABC |
| `src/open_guard/domain/ports/async_task_store.py` | `AsyncTaskStorePort` ABC |
| `src/open_guard/domain/ports/async_candidate_resource.py` | `AsyncCandidateResourcePort` ABC |
| `src/open_guard/domain/ports/async_evaluator.py` | `AsyncEvaluatorPort` ABC |
| `src/open_guard/domain/services/async_guard.py` | `AsyncGuard` — async authorization entry point |
| `src/open_guard/domain/services/async_policy_router.py` | `AsyncPolicyRouter` — async policy fetch + sync evaluator dispatch |
| `src/open_guard/adapters/evaluators/async_rebac.py` | `AsyncReBACEvaluator` — async graph traversal |
| `src/open_guard/adapters/stores/async_memory.py` | Async wrappers for all in-memory stores |
| `src/open_guard/adapters/stores/async_sql.py` | `AsyncSQLAlchemyPolicyStore` |
| `src/open_guard/adapters/stores/async_sql_relationship.py` | `AsyncSQLAlchemyRelationshipStore` |
| `src/open_guard/adapters/stores/async_sql_delegation.py` | `AsyncSQLAlchemyDelegationStore` |
| `src/open_guard/adapters/stores/async_sql_session.py` | `AsyncSQLAlchemySessionStore` |
| `src/open_guard/adapters/stores/async_sql_approval.py` | `AsyncSQLAlchemyApprovalStore` |
| `src/open_guard/adapters/stores/async_sql_task.py` | `AsyncSQLAlchemyTaskStore` |
| `src/open_guard/adapters/admin/__init__.py` | Admin package init |
| `src/open_guard/adapters/admin/sdk.py` | `PolicyAdmin` — in-process CRUD SDK |
| `src/open_guard/api/fastapi/admin_router.py` | `AdminRouter` — FastAPI REST management |
| `src/open_guard/api/fastapi/schemas.py` | Request/response Pydantic models for admin API |
| `src/open_guard/cli/__init__.py` | CLI package init |
| `src/open_guard/cli/main.py` | CLI entry point (`open-guard db init`, `open-guard db schema`) |
| `tests/unit/test_factory.py` | Guard.from_config() tests |
| `tests/unit/test_policy_admin.py` | PolicyAdmin SDK tests |
| `tests/unit/test_async_guard.py` | AsyncGuard tests |
| `tests/unit/test_async_stores_memory.py` | Async memory store tests |
| `tests/unit/test_async_stores_sql.py` | Async SQL store tests |
| `tests/unit/test_async_rebac.py` | AsyncReBACEvaluator tests |
| `tests/integration/test_admin_router.py` | REST admin API tests |
| `tests/integration/test_async_integration.py` | Full async authorization flow |
| `tests/integration/test_cli.py` | CLI tests |

### Modified Files

| File | Changes |
|------|---------|
| `src/open_guard/domain/services/guard.py` | + `from_config()` classmethod |
| `src/open_guard/adapters/stores/sql_models.py` | + `create_all_tables()` convenience function |
| `src/open_guard/__init__.py` | + re-exports for AsyncGuard, PolicyAdmin, AdminRouter, factory |
| `pyproject.toml` | + `[sql-async]` extra, + `[cli]` extra, + `[project.scripts]` entry point |

---

## Deliverable 1: Guard Factory (OG-1)

### Task 1: Factory Wiring Logic

**Files:**
- Create: `src/open_guard/adapters/factory.py`
- Modify: `src/open_guard/domain/services/guard.py`
- Create: `tests/unit/test_factory.py`

- [ ] **Step 1: Write failing tests for `Guard.from_config()`**

```python
# tests/unit/test_factory.py
"""Tests for Guard.from_config() factory (Phase 7 — OG-1)."""
import pytest
from open_guard import Guard


class TestGuardFromConfig:
    def test_memory_backend(self):
        guard = Guard.from_config(backend="memory")
        assert guard is not None
        # Should have all evaluators wired
        assert len(guard._evaluators) == 4  # rbac, abac, tbac, rebac

    def test_memory_backend_authorize_works(self):
        """Fully-wired guard can authorize without errors."""
        from open_guard import Action, Policy, Resource, Subject
        guard = Guard.from_config(backend="memory")
        guard.policy_store.add(Policy(
            tenant_id="t1", evaluator_type="rbac",
            subject_match={"roles": ["admin"]},
            action_match="read",
            resource_match={"type": "doc"},
        ))
        decision = guard.authorize(
            Subject(id="alice", attributes={"roles": ["admin"]}),
            Action(name="read"),
            Resource(id="d1", resource_type="doc", attributes={"type": "doc"}),
            tenant_id="t1",
        )
        assert decision.allowed

    def test_sqlite_backend(self, tmp_path):
        dsn = f"sqlite:///{tmp_path}/test.db"
        guard = Guard.from_config(dsn)
        assert guard is not None

    def test_backend_auto_detection_sqlite(self, tmp_path):
        dsn = f"sqlite:///{tmp_path}/test.db"
        guard = Guard.from_config(dsn)
        # Should auto-detect sqlite from DSN scheme
        assert guard is not None

    def test_backend_auto_detection_postgresql(self):
        # Can't connect but should parse without error
        with pytest.raises(Exception):  # connection error, not config error
            Guard.from_config("postgresql://localhost:5432/nonexistent_db")

    def test_invalid_backend_raises(self):
        with pytest.raises(ValueError, match="Unsupported backend"):
            Guard.from_config(backend="redis")

    def test_custom_config_overrides(self):
        guard = Guard.from_config(
            backend="memory",
            max_chain_depth=10,
            max_delegation_depth=20,
        )
        assert guard._max_chain_depth == 10
```

- [ ] **Step 2: Implement factory**

```python
# src/open_guard/adapters/factory.py
"""Factory wiring for Guard and AsyncGuard."""
from __future__ import annotations
from typing import Any
from open_guard.domain.services.guard import Guard


def build_guard(dsn: str | None = None, *, backend: str | None = None, **kwargs: Any) -> Guard:
    """Wire all stores + evaluators from a DSN or backend name.

    Backend auto-detection:
      - "memory" or no dsn → in-memory stores
      - "sqlite://..." → SQLAlchemy + SQLite
      - "postgresql://..." → SQLAlchemy + PostgreSQL

    Extra kwargs forwarded to Guard.__init__ (max_chain_depth, etc.).
    """
    resolved_backend = _resolve_backend(dsn, backend)

    if resolved_backend == "memory":
        return _build_memory_guard(**kwargs)
    elif resolved_backend in ("sqlite", "postgresql"):
        return _build_sql_guard(dsn, **kwargs)
    else:
        raise ValueError(f"Unsupported backend: {resolved_backend!r}")
```

- [ ] **Step 3: Add `Guard.from_config()` classmethod**

```python
# In guard.py — add classmethod
@classmethod
def from_config(
    cls,
    dsn: str | None = None,
    *,
    backend: str | None = None,
    **kwargs: Any,
) -> Guard:
    from open_guard.adapters.factory import build_guard
    return build_guard(dsn, backend=backend, **kwargs)
```

- [ ] **Step 4: Tests green + ruff + mypy**

**Commit:** `feat(factory): Guard.from_config() one-liner wiring (OG-1)`

---

## Deliverable 2: DB Schema Tooling (OG-4)

### Task 2: `create_all_tables()` + DDL Export

**Files:**
- Modify: `src/open_guard/adapters/stores/sql_models.py`
- Create: `tests/unit/test_db_tooling.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_db_tooling.py
def test_create_all_tables_sqlite(tmp_path):
    from open_guard.db import create_all_tables
    from sqlalchemy import create_engine, inspect
    engine = create_engine(f"sqlite:///{tmp_path}/test.db")
    create_all_tables(engine)
    inspector = inspect(engine)
    tables = inspector.get_table_names()
    assert "policies" in tables
    assert "relationships" in tables
    assert "delegations" in tables
    assert "sessions" in tables
    assert "approvals" in tables
    assert "tasks" in tables

def test_get_ddl_postgresql():
    from open_guard.db import get_ddl
    ddl = get_ddl(dialect="postgresql")
    assert "CREATE TABLE" in ddl
    assert "policies" in ddl

def test_get_ddl_sqlite():
    from open_guard.db import get_ddl
    ddl = get_ddl(dialect="sqlite")
    assert "CREATE TABLE" in ddl
```

- [ ] **Step 2: Implement `create_all_tables()` and `get_ddl()`**

```python
# src/open_guard/db.py (new module)
"""Database schema utilities for open-guard."""
from open_guard.adapters.stores.sql_models import metadata

def create_all_tables(engine):
    metadata.create_all(engine)

def get_ddl(dialect="sqlite"):
    # Use CreateTable DDL compiler to emit SQL
    ...
```

- [ ] **Step 3: Tests green + ruff + mypy**

**Commit:** `feat(db): create_all_tables() + DDL export (OG-4)`

### Task 3: CLI Entry Point

**Files:**
- Create: `src/open_guard/cli/__init__.py`
- Create: `src/open_guard/cli/main.py`
- Modify: `pyproject.toml`
- Create: `tests/integration/test_cli.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/integration/test_cli.py
from click.testing import CliRunner

def test_db_init_sqlite(tmp_path):
    from open_guard.cli.main import cli
    runner = CliRunner()
    result = runner.invoke(cli, ["db", "init", "--dsn", f"sqlite:///{tmp_path}/test.db"])
    assert result.exit_code == 0

def test_db_schema_sqlite():
    from open_guard.cli.main import cli
    runner = CliRunner()
    result = runner.invoke(cli, ["db", "schema", "--dialect", "sqlite"])
    assert result.exit_code == 0
    assert "CREATE TABLE" in result.output
```

- [ ] **Step 2: Implement CLI with click**

```python
# src/open_guard/cli/main.py
import click

@click.group()
def cli():
    """open-guard CLI."""

@cli.group()
def db():
    """Database management commands."""

@db.command()
@click.option("--dsn", required=True)
def init(dsn: str):
    """Create all open-guard tables."""
    from sqlalchemy import create_engine
    from open_guard.db import create_all_tables
    engine = create_engine(dsn)
    create_all_tables(engine)
    click.echo("Tables created successfully.")

@db.command()
@click.option("--dialect", default="sqlite", type=click.Choice(["sqlite", "postgresql"]))
def schema(dialect: str):
    """Output DDL SQL for all open-guard tables."""
    from open_guard.db import get_ddl
    click.echo(get_ddl(dialect=dialect))
```

- [ ] **Step 3: Add pyproject.toml entries**

```toml
[project.optional-dependencies]
cli = ["click>=8.0"]

[project.scripts]
open-guard = "open_guard.cli.main:cli"
```

- [ ] **Step 4: Tests green + ruff + mypy**

**Commit:** `feat(cli): open-guard db init/schema commands (OG-4)`

---

## Deliverable 3: PolicyAdmin SDK (OG-2)

### Task 4: PolicyAdmin In-Process SDK

**Files:**
- Create: `src/open_guard/adapters/admin/__init__.py`
- Create: `src/open_guard/adapters/admin/sdk.py`
- Create: `tests/unit/test_policy_admin.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_policy_admin.py
"""Tests for PolicyAdmin SDK (Phase 7 — OG-2)."""
import pytest
from open_guard import Guard
from open_guard.adapters.admin.sdk import PolicyAdmin


class TestPolicyAdmin:
    @pytest.fixture
    def admin(self):
        guard = Guard.from_config(backend="memory")
        return PolicyAdmin(guard)

    def test_create_policy(self, admin):
        policy = admin.create_policy(
            tenant_id="t1",
            evaluator_type="rbac",
            subject_match={"roles": ["editor"]},
            action_match="read",
            resource_match={"type": "doc"},
        )
        assert policy.id is not None
        assert policy.tenant_id == "t1"

    def test_list_policies(self, admin):
        admin.create_policy(tenant_id="t1", evaluator_type="rbac",
                            subject_match={"roles": ["viewer"]}, action_match="read")
        policies = admin.list_policies(tenant_id="t1")
        assert len(policies) >= 1

    def test_delete_policy(self, admin):
        policy = admin.create_policy(tenant_id="t1", evaluator_type="rbac",
                                     subject_match={"roles": ["viewer"]}, action_match="read")
        admin.delete_policy(policy.id, tenant_id="t1")
        policies = admin.list_policies(tenant_id="t1")
        assert policy.id not in [p.id for p in policies]

    def test_assign_role(self, admin):
        """Assign role creates an RBAC policy scoped to subject + role."""
        policy = admin.assign_role(
            tenant_id="t1", subject_id="alice", role="editor",
            resource_type="doc", actions=["read", "write"],
        )
        assert policy is not None

    def test_add_relationship(self, admin):
        rel = admin.add_relationship(
            tenant_id="t1", subject_id="alice", subject_type="user",
            relation="member", object_type="project", object_id="p1",
        )
        assert rel is not None

    def test_delete_relationship(self, admin):
        rel = admin.add_relationship(
            tenant_id="t1", subject_id="alice", subject_type="user",
            relation="member", object_type="project", object_id="p1",
        )
        admin.delete_relationship(rel.id, tenant_id="t1")

    def test_create_delegation(self, admin):
        delegation = admin.create_delegation(
            tenant_id="t1",
            from_subject_id="alice",
            to_subject_id="bob",
            scope={"resource_type": "doc", "actions": ["read"]},
        )
        assert delegation is not None

    def test_list_delegations(self, admin):
        admin.create_delegation(
            tenant_id="t1", from_subject_id="alice",
            to_subject_id="bob",
            scope={"resource_type": "doc", "actions": ["read"]},
        )
        delegations = admin.list_delegations(tenant_id="t1", subject_id="bob")
        assert len(delegations) >= 1

    def test_create_session(self, admin):
        session = admin.create_session(
            tenant_id="t1", subject_id="alice",
            activated_roles=["editor", "viewer"],
        )
        assert session is not None
        assert session.activated_roles == ["editor", "viewer"]

    def test_deactivate_session(self, admin):
        session = admin.create_session(
            tenant_id="t1", subject_id="alice",
            activated_roles=["editor"],
        )
        deactivated = admin.deactivate_session(session.id, tenant_id="t1")
        assert deactivated.status.value == "deactivated"

    def test_tenant_isolation(self, admin):
        admin.create_policy(tenant_id="t1", evaluator_type="rbac",
                            subject_match={"roles": ["admin"]}, action_match="*")
        admin.create_policy(tenant_id="t2", evaluator_type="rbac",
                            subject_match={"roles": ["viewer"]}, action_match="read")
        t1_policies = admin.list_policies(tenant_id="t1")
        t2_policies = admin.list_policies(tenant_id="t2")
        assert len(t1_policies) >= 1
        assert len(t2_policies) >= 1
        assert set(p.id for p in t1_policies).isdisjoint(set(p.id for p in t2_policies))
```

- [ ] **Step 2: Implement PolicyAdmin**

```python
# src/open_guard/adapters/admin/sdk.py
"""PolicyAdmin — in-process administration SDK for open-guard."""
from __future__ import annotations
from typing import Any
from open_guard.domain.entities import Policy, RelationTuple, Session, Delegation
from open_guard.domain.services.guard import Guard


class PolicyAdmin:
    """Tenant-scoped CRUD for policies, roles, relationships, delegations, sessions.

    Usage:
        admin = PolicyAdmin(guard)
        admin.create_policy(tenant_id="t1", evaluator_type="rbac", ...)
        admin.assign_role(tenant_id="t1", subject_id="alice", role="editor", ...)
    """

    def __init__(self, guard: Guard) -> None:
        self._guard = guard

    # -- Policies --
    def create_policy(self, *, tenant_id: str, evaluator_type: str, **kwargs: Any) -> Policy: ...
    def list_policies(self, tenant_id: str, evaluator_type: str | None = None) -> list[Policy]: ...
    def delete_policy(self, policy_id: str, tenant_id: str) -> None: ...

    # -- Roles (convenience — creates RBAC policies) --
    def assign_role(self, *, tenant_id: str, subject_id: str, role: str, ...) -> Policy: ...
    def revoke_role(self, *, tenant_id: str, subject_id: str, role: str) -> None: ...

    # -- Relationships --
    def add_relationship(self, *, tenant_id: str, ...) -> RelationTuple: ...
    def delete_relationship(self, tuple_id: str, tenant_id: str) -> None: ...
    def list_relationships(self, tenant_id: str, ...) -> list[RelationTuple]: ...

    # -- Delegations --
    def create_delegation(self, *, tenant_id: str, ...) -> Delegation: ...
    def revoke_delegation(self, delegation_id: str, tenant_id: str) -> None: ...
    def list_delegations(self, tenant_id: str, subject_id: str | None = None) -> list[Delegation]: ...

    # -- Sessions --
    def create_session(self, *, tenant_id: str, ...) -> Session: ...
    def deactivate_session(self, session_id: str, tenant_id: str) -> Session: ...
    def list_sessions(self, tenant_id: str, subject_id: str | None = None) -> list[Session]: ...
```

- [ ] **Step 3: Tests green + ruff + mypy**

**Commit:** `feat(admin): PolicyAdmin in-process SDK (OG-2, FEAT-011)`

---

## Deliverable 4: Admin REST API (OG-3)

### Task 5: Request/Response Schemas

**Files:**
- Create: `src/open_guard/api/fastapi/schemas.py`

- [ ] **Step 1: Define Pydantic request/response models**

```python
# src/open_guard/api/fastapi/schemas.py
"""Request/response schemas for the admin REST API."""
from pydantic import BaseModel

class CreatePolicyRequest(BaseModel):
    tenant_id: str
    evaluator_type: str
    subject_match: dict | None = None
    action_match: str | None = None
    resource_match: dict | None = None
    conditions: dict | None = None
    effect: str = "allow"
    priority: int = 0

class PolicyResponse(BaseModel):
    id: str
    tenant_id: str
    evaluator_type: str
    # ... mirrors Policy entity

class AssignRoleRequest(BaseModel):
    tenant_id: str
    subject_id: str
    role: str
    resource_type: str | None = None
    actions: list[str] | None = None

class AddRelationshipRequest(BaseModel):
    tenant_id: str
    subject_id: str
    subject_type: str
    relation: str
    object_type: str
    object_id: str

# ... more schemas for delegations, sessions, pagination
```

**Commit:** `feat(api): admin REST request/response schemas`

### Task 6: AdminRouter Implementation

**Files:**
- Create: `src/open_guard/api/fastapi/admin_router.py`
- Create: `tests/integration/test_admin_router.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/integration/test_admin_router.py
"""Tests for AdminRouter REST API (Phase 7 — OG-3)."""
import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from open_guard import Guard
from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.api.fastapi.admin_router import AdminRouter

@pytest.fixture
def client():
    guard = Guard.from_config(backend="memory")
    admin = PolicyAdmin(guard)
    app = FastAPI()
    app.include_router(AdminRouter(admin=admin), prefix="/admin")
    return TestClient(app)

class TestPolicyRoutes:
    def test_create_policy(self, client):
        resp = client.post("/admin/policies", json={...})
        assert resp.status_code == 201

    def test_list_policies(self, client):
        resp = client.get("/admin/policies", params={"tenant_id": "t1"})
        assert resp.status_code == 200

    def test_delete_policy(self, client):
        # create then delete
        ...

class TestHealthRoute:
    def test_health(self, client):
        resp = client.get("/admin/health")
        assert resp.status_code == 200
```

- [ ] **Step 2: Implement AdminRouter**

```python
# src/open_guard/api/fastapi/admin_router.py
"""Mountable FastAPI router for open-guard administration."""
from fastapi import APIRouter, HTTPException
from open_guard.adapters.admin.sdk import PolicyAdmin

class AdminRouter(APIRouter):
    def __init__(self, admin: PolicyAdmin, **kwargs):
        super().__init__(**kwargs)
        self._admin = admin
        self._register_routes()

    def _register_routes(self):
        # POST /policies, GET /policies, DELETE /policies/{id}
        # POST /roles, DELETE /roles
        # POST /relationships, GET /relationships, DELETE /relationships/{id}
        # POST /delegations, GET /delegations, DELETE /delegations/{id}
        # POST /sessions, DELETE /sessions/{id}
        # GET /health
        ...
```

- [ ] **Step 3: Tests green + ruff + mypy**

**Commit:** `feat(api): AdminRouter REST management API (OG-3, FEAT-011)`

---

## Deliverable 5: Async Support (OG-5 + OG-6)

### Task 7: Async Store Port ABCs

**Files:**
- Create: `src/open_guard/domain/ports/async_policy_store.py`
- Create: `src/open_guard/domain/ports/async_relationship_store.py`
- Create: `src/open_guard/domain/ports/async_delegation_store.py`
- Create: `src/open_guard/domain/ports/async_session_store.py`
- Create: `src/open_guard/domain/ports/async_approval_store.py`
- Create: `src/open_guard/domain/ports/async_task_store.py`
- Create: `src/open_guard/domain/ports/async_candidate_resource.py`
- Create: `src/open_guard/domain/ports/async_evaluator.py`

- [ ] **Step 1: Define all async port ABCs**

Each mirrors its sync counterpart with `async def`:

```python
# src/open_guard/domain/ports/async_policy_store.py
from abc import ABC, abstractmethod
from open_guard.domain.entities import Policy

class AsyncPolicyStorePort(ABC):
    @abstractmethod
    async def add(self, policy: Policy) -> Policy: ...

    @abstractmethod
    async def get_by_tenant(self, tenant_id: str) -> list[Policy]: ...

    @abstractmethod
    async def get_by_tenant_and_type(self, tenant_id: str, evaluator_type: str) -> list[Policy]: ...

    @abstractmethod
    async def remove(self, policy_id: str, tenant_id: str) -> None: ...
```

Repeat pattern for all 7 store ports + evaluator port + candidate resource port.

- [ ] **Step 2: ruff + mypy clean**

**Commit:** `feat(ports): async store port ABCs for all 7 stores + evaluator (OG-5)`

### Task 8: Async Memory Stores

**Files:**
- Create: `src/open_guard/adapters/stores/async_memory.py`
- Create: `tests/unit/test_async_stores_memory.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_async_stores_memory.py
"""Tests for async in-memory stores (Phase 7 — OG-5)."""
import pytest

class TestAsyncInMemoryPolicyStore:
    @pytest.mark.asyncio
    async def test_add_and_get(self):
        from open_guard.adapters.stores.async_memory import AsyncInMemoryPolicyStore
        store = AsyncInMemoryPolicyStore()
        policy = await store.add(Policy(...))
        results = await store.get_by_tenant("t1")
        assert len(results) == 1

# Mirror key tests from each sync memory store
```

- [ ] **Step 2: Implement async memory stores**

Thin wrappers around sync memory stores — delegate to sync implementation, return directly (no I/O, so no real async benefit, but fulfills the port contract for testing and edge deployments).

```python
# src/open_guard/adapters/stores/async_memory.py
class AsyncInMemoryPolicyStore(AsyncPolicyStorePort):
    def __init__(self):
        self._sync = InMemoryPolicyStore()

    async def add(self, policy: Policy) -> Policy:
        return self._sync.add(policy)

    async def get_by_tenant(self, tenant_id: str) -> list[Policy]:
        return self._sync.get_by_tenant(tenant_id)
    # ...
```

- [ ] **Step 3: Tests green + ruff + mypy**

**Commit:** `feat(stores): async in-memory store implementations (OG-5)`

### Task 9: Async SQLAlchemy Stores

**Files:**
- Create: `src/open_guard/adapters/stores/async_sql.py`
- Create: `src/open_guard/adapters/stores/async_sql_relationship.py`
- Create: `src/open_guard/adapters/stores/async_sql_delegation.py`
- Create: `src/open_guard/adapters/stores/async_sql_session.py`
- Create: `src/open_guard/adapters/stores/async_sql_approval.py`
- Create: `src/open_guard/adapters/stores/async_sql_task.py`
- Modify: `pyproject.toml`
- Create: `tests/unit/test_async_stores_sql.py`

- [ ] **Step 1: Add `[sql-async]` extra to pyproject.toml**

```toml
[project.optional-dependencies]
sql-async = [
    "sqlalchemy[asyncio]>=2.0",
    "aiosqlite>=0.20.0",
]
```

(`asyncpg` is only needed for real PostgreSQL — consumers add it themselves. `aiosqlite` covers testing + SQLite deployments.)

- [ ] **Step 2: Write failing tests**

```python
# tests/unit/test_async_stores_sql.py
"""Tests for async SQLAlchemy stores (Phase 7 — OG-6)."""
import pytest
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession

@pytest.fixture
async def async_engine(tmp_path):
    engine = create_async_engine(f"sqlite+aiosqlite:///{tmp_path}/test.db")
    # create tables
    async with engine.begin() as conn:
        await conn.run_sync(metadata.create_all)
    yield engine
    await engine.dispose()

class TestAsyncSQLPolicyStore:
    @pytest.mark.asyncio
    async def test_add_and_get(self, async_engine):
        store = AsyncSQLAlchemyPolicyStore(async_engine)
        policy = await store.add(Policy(...))
        results = await store.get_by_tenant("t1")
        assert len(results) == 1
```

- [ ] **Step 3: Implement async SQL stores**

Each mirrors its sync counterpart using `AsyncSession`:

```python
# src/open_guard/adapters/stores/async_sql.py
from sqlalchemy.ext.asyncio import AsyncEngine, async_sessionmaker

class AsyncSQLAlchemyPolicyStore(AsyncPolicyStorePort):
    def __init__(self, engine: AsyncEngine):
        self._session_factory = async_sessionmaker(engine, expire_on_commit=False)

    async def add(self, policy: Policy) -> Policy:
        async with self._session_factory() as session:
            # Same logic as sync, but with await
            ...
```

- [ ] **Step 4: Tests green + ruff + mypy**

**Commit:** `feat(stores): async SQLAlchemy stores with aiosqlite (OG-6)`

### Task 10: AsyncReBACEvaluator

**Files:**
- Create: `src/open_guard/adapters/evaluators/async_rebac.py`
- Create: `tests/unit/test_async_rebac.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_async_rebac.py
"""Tests for AsyncReBACEvaluator (Phase 7 — OG-5)."""
import pytest

class TestAsyncReBACEvaluator:
    @pytest.mark.asyncio
    async def test_direct_relation(self):
        # Mirror test_rebac.py::test_direct_relation but with async
        ...

    @pytest.mark.asyncio
    async def test_graph_traversal(self):
        ...
```

- [ ] **Step 2: Implement AsyncReBACEvaluator**

Mirrors `ReBACEvaluator` but with `AsyncRelationshipStorePort`:

```python
# src/open_guard/adapters/evaluators/async_rebac.py
class AsyncReBACEvaluator(AsyncEvaluatorPort):
    def __init__(self, relationship_store: AsyncRelationshipStorePort, ...):
        self._store = relationship_store

    async def evaluate(self, request: AuthorizationRequest, policies: list[Policy]) -> Evaluation:
        # Same logic as sync, but await store calls
        ...

    async def _check_relation(self, ...):
        tuples = await self._store.read_tuples(...)
        # recursive traversal with await
        ...
```

- [ ] **Step 3: Tests green + ruff + mypy**

**Commit:** `feat(evaluators): AsyncReBACEvaluator for async graph traversal (OG-5)`

### Task 11: AsyncPolicyRouter

**Files:**
- Create: `src/open_guard/domain/services/async_policy_router.py`

- [ ] **Step 1: Implement AsyncPolicyRouter**

```python
# src/open_guard/domain/services/async_policy_router.py
class AsyncPolicyRouter:
    """Async policy fetch + evaluator dispatch.

    Fetches policies async from AsyncPolicyStorePort.
    Dispatches to sync evaluators (RBAC/ABAC/TBAC) inline.
    Dispatches to AsyncReBACEvaluator with await.
    """
    async def evaluate(self, request: AuthorizationRequest) -> Decision: ...
    async def evaluate_traced(self, request: AuthorizationRequest) -> tuple[Decision, DecisionTrace]: ...
```

- [ ] **Step 2: Tests (covered by AsyncGuard integration tests)**

**Commit:** `feat(services): AsyncPolicyRouter — async policy fetch + evaluator dispatch`

### Task 12: AsyncGuard

**Files:**
- Create: `src/open_guard/domain/services/async_guard.py`
- Create: `tests/unit/test_async_guard.py`
- Create: `tests/integration/test_async_integration.py`

- [ ] **Step 1: Write failing tests**

```python
# tests/unit/test_async_guard.py
"""Tests for AsyncGuard (Phase 7 — OG-5)."""
import pytest
from open_guard.domain.services.async_guard import AsyncGuard

class TestAsyncGuard:
    @pytest.mark.asyncio
    async def test_from_config_memory(self):
        guard = await AsyncGuard.from_config(backend="memory")
        assert guard is not None

    @pytest.mark.asyncio
    async def test_authorize(self):
        guard = await AsyncGuard.from_config(backend="memory")
        # add policy via admin
        ...
        decision = await guard.authorize(subject, action, resource, tenant_id="t1")
        assert decision.allowed

    @pytest.mark.asyncio
    async def test_authorize_traced(self):
        ...

    @pytest.mark.asyncio
    async def test_list_authorized(self):
        ...
```

```python
# tests/integration/test_async_integration.py
"""Full async flow: config → policy → authorize (Phase 7)."""
import pytest

class TestAsyncEndToEnd:
    @pytest.mark.asyncio
    async def test_full_rbac_flow_memory(self):
        """from_config → add policy → authorize → allowed."""
        guard = await AsyncGuard.from_config(backend="memory")
        # ... full flow

    @pytest.mark.asyncio
    async def test_full_flow_sqlite(self, tmp_path):
        """from_config with SQLite → add policy → authorize."""
        guard = await AsyncGuard.from_config(f"sqlite+aiosqlite:///{tmp_path}/test.db")
        # ... full flow

    @pytest.mark.asyncio
    async def test_rebac_async(self):
        """ReBAC graph traversal works async."""
        ...

    @pytest.mark.asyncio
    async def test_delegation_async(self):
        """Delegation fallback works async."""
        ...

    @pytest.mark.asyncio
    async def test_session_async(self):
        """Session-aware auth works async."""
        ...
```

- [ ] **Step 2: Implement AsyncGuard**

```python
# src/open_guard/domain/services/async_guard.py
class AsyncGuard:
    """Async authorization entry point. Mirrors Guard API with async def."""

    def __init__(self, policy_store: AsyncPolicyStorePort, ...):
        ...

    @classmethod
    async def from_config(cls, dsn=None, *, backend=None, **kwargs) -> AsyncGuard:
        from open_guard.adapters.factory import build_async_guard
        return await build_async_guard(dsn, backend=backend, **kwargs)

    async def authorize(self, subject, action, resource, tenant_id, ...) -> Decision: ...
    async def authorize_traced(self, ...) -> tuple[Decision, DecisionTrace]: ...
    async def list_authorized(self, ...) -> ListResult: ...
    async def approve(self, ...) -> ApprovalRequest: ...
    async def reject(self, ...) -> ApprovalRequest: ...
    async def delegate(self, **kwargs) -> Any: ...
    async def authorize_and_consume(self, ...) -> Decision: ...
```

- [ ] **Step 3: Add async factory to `adapters/factory.py`**

```python
async def build_async_guard(dsn=None, *, backend=None, **kwargs) -> AsyncGuard:
    resolved = _resolve_backend(dsn, backend)
    if resolved == "memory":
        return _build_async_memory_guard(**kwargs)
    elif resolved in ("sqlite", "postgresql"):
        return await _build_async_sql_guard(dsn, **kwargs)
    ...
```

- [ ] **Step 4: Tests green + ruff + mypy**

**Commit:** `feat(async): AsyncGuard with full async authorization pipeline (OG-5)`

---

## Wrap-up

### Task 13: Re-exports + pyproject.toml + Version Bump

**Files:**
- Modify: `src/open_guard/__init__.py`
- Modify: `pyproject.toml`

- [ ] **Step 1: Add re-exports**

```python
# __init__.py additions
from open_guard.adapters.admin.sdk import PolicyAdmin
from open_guard.domain.services.async_guard import AsyncGuard
# + async stores, async ports (for consumers who need to implement custom stores)
```

- [ ] **Step 2: Version bump to 0.8.0**
- [ ] **Step 3: Full regression — all tests pass**

**Commit:** `chore: re-exports + version bump to v0.8.0`

### Task 14: Integration Guide Phase 7 Section + Executable Mirrors

**Files:**
- Modify: `specs/architecture/integration-guide.md`
- Create: `tests/integration/test_integration_guide_phase7_examples.py`

- [ ] **Step 1: Add Phase 7 section to integration guide**

Cover: `Guard.from_config()`, `AsyncGuard.from_config()`, `PolicyAdmin`, `AdminRouter`, CLI, async authorization flow.

- [ ] **Step 2: Create executable mirror tests**

Every code block in the guide has a corresponding test.

- [ ] **Step 3: Tests green**

**Commit:** `docs: integration guide Phase 7 section + executable mirrors`

### Task 15: Quality Gates + Final Verification

- [ ] All 806+ existing tests pass unchanged
- [ ] New tests pass (target: 100+ new tests)
- [ ] Coverage >= 95%
- [ ] `ruff check src/ tests/` clean
- [ ] `mypy --strict src/` clean
- [ ] `Guard.from_config(backend="memory")` returns working guard
- [ ] `AsyncGuard.from_config(backend="memory")` returns working async guard
- [ ] `Guard.from_config("sqlite:///test.db")` creates tables + works
- [ ] `AsyncGuard.from_config("sqlite+aiosqlite:///test.db")` creates tables + works
- [ ] `PolicyAdmin` CRUD works for all entity types
- [ ] `AdminRouter` all routes return correct status codes
- [ ] `open-guard db init` creates all tables
- [ ] `open-guard db schema` outputs valid DDL

**Commit:** `feat(phase-7): Consumer Integration complete — v0.8.0`

---

## Task Dependency Graph

```
T1 (factory) ─────────────────────┐
T2 (create_all_tables + DDL) ─────┤
T3 (CLI) ─── depends on T2 ──────┤
T4 (PolicyAdmin) ─ depends on T1 ─┤
T5 (schemas) ─────────────────────┤
T6 (AdminRouter) ─ depends on T4,T5
T7 (async port ABCs) ────────────┐
T8 (async memory stores) ─ T7 ──┤
T9 (async SQL stores) ─── T7 ───┤
T10 (AsyncReBACEvaluator) ─ T7 ─┤
T11 (AsyncPolicyRouter) ── T7 ──┤
T12 (AsyncGuard) ── T7,T8,T10,T11
T13 (re-exports + version) ── all
T14 (docs) ──────────────── all
T15 (quality gates) ─────── all
```

Parallelizable groups:
- **Group A** (sync): T1, T2 — independent
- **Group B** (sync): T3 (after T2), T4 (after T1), T5 — semi-parallel
- **Group C** (sync): T6 (after T4, T5)
- **Group D** (async): T7, then T8+T9+T10+T11 in parallel, then T12
- **Group E** (wrap-up): T13, T14, T15
