# Phase 7 — Consumer Integration: Retrospective

> **Completed**: 2026-04-19
> **Version**: v0.8.0
> **Tests**: 959 (153 new, 806 existing unchanged)
> **Coverage**: 94%
> **Breaking Changes**: None

## What Went Well

1. **Parallelizable task structure** — The dependency graph (T1+T2 parallel, T3+T4+T5 parallel, T8+T9+T10+T11 parallel) enabled high throughput via subagent-driven development. Most deliverables were independent.

2. **Clean layering from prior phases** — The hexagonal architecture made async port creation mechanical: every sync port maps 1:1 to an async counterpart. No domain logic changes needed.

3. **Factory pattern simplicity** — `Guard.from_config()` wires 7 stores + 4 evaluators in one call. The DSN-based auto-detection (sqlite/postgresql from URL scheme) is intuitive and follows SQLAlchemy conventions.

4. **Zero breaking changes maintained** — 806 existing tests pass unchanged across all 7 phases. The additive-only constraint continues to hold.

5. **Sync evaluators inside AsyncGuard** — Keeping RBAC/ABAC/TBAC evaluators sync was the right call. They're pure CPU on pre-fetched policies. Only ReBACEvaluator needed async (graph traversal with mid-evaluation I/O).

## What Didn't Go Well

1. **AsyncGuard feature gap** — Delegation fallback and approval gates are not yet implemented on the async path. This is documented as FEAT-014 and FEAT-015 in the backlog, but consumers expecting full parity will hit gaps.

2. **Coverage dip** — 94% vs 97% in Phase 6. The async SQL stores have lower coverage because some edge paths (CAS counter races, concurrent session expiry) aren't fully tested with aiosqlite. Real PostgreSQL with asyncpg would exercise these better.

3. **PolicyAdmin accesses private Guard internals** — `guard._relationship_store`, `guard._delegation_manager`, `guard._session_store` are private. The SDK works but couples to internal structure. A proper public accessor pattern would be better.

## Lessons Learned

1. **Async ports are mechanical but voluminous** — 8 port ABCs + 6 memory stores + 5 SQL stores = 19 files of largely repetitive code. A code generation approach or generic async-wrapper base class could reduce this.

2. **CLI adds dependency surface** — click is now a dev dependency. The `[cli]` optional extra keeps it out of the main install, but it's another thing to maintain. Consider if a simpler argparse-based CLI would suffice.

3. **DSN-based factory has limits** — Custom configuration (e.g., connection pool size, echo, isolation level) requires passing extra kwargs. The factory pattern handles common cases but complex deployments will still construct stores manually.

## Metrics

| Metric | Phase 6 (v0.7.0) | Phase 7 (v0.8.0) | Delta |
|--------|-------------------|-------------------|-------|
| Tests | 806 | 959 | +153 |
| Coverage | 97% | 94% | -3% |
| Source files | ~45 | ~77 | +32 |
| New ports | 0 | 8 async ports | +8 |
| New stores | 0 | 11 async stores | +11 |

## What to Do Differently Next Time

- Consider generating async port ABCs from sync ports programmatically
- Add asyncpg integration tests (real PostgreSQL) in CI before claiming full async support
- Expose store accessors as public Guard properties to avoid SDK coupling to privates
