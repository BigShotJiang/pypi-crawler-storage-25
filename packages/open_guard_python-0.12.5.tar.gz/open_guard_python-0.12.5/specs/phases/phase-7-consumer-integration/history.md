# Phase 7 — Consumer Integration: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [SCOPE_CHANGE] 2026-04-19 — Phase 7 reframed from "Management APIs" to "Consumer Integration"
Topics: scope, phase-theme, roadmap, consumer-experience
Affects-phases: phase-7-consumer-integration
Affects-specs: specs/planning/roadmap.md, specs/status.md
Detail: Original Phase 7 was "Management APIs" (FEAT-011 only). Reframed to "Consumer Integration" to cover six action items needed for cerebrio-sapience (and any consumer) adoption: Guard.from_config() factory (OG-1), PolicyAdmin SDK (OG-2), Admin REST API (OG-3), DB migration tooling (OG-4), async authorize support (OG-5), async SQL stores (OG-6). FEAT-011 is subsumed by OG-2 + OG-3.

---

### [DECISION] 2026-04-19 — Guard.from_config() uses DSN string, no dict/YAML/TOML config
Topics: factory, configuration, dx
Affects-phases: phase-7-consumer-integration
Affects-specs: specs/architecture/integration-guide.md
Detail: Factory accepts DSN string with auto-detection from URL scheme (sqlite://, postgresql://) or explicit backend="memory". Config file parsing (YAML/TOML/dict) is consumer responsibility. Follows SQLAlchemy create_engine(url), Redis from_url(), Celery broker_url pattern. No config format dependency in the library.

---

### [DECISION] 2026-04-19 — Dual API: sync Guard unchanged, new AsyncGuard with native async stores
Topics: async, architecture, guard
Affects-phases: phase-7-consumer-integration
Affects-specs: specs/architecture/integration-guide.md, specs/architecture/auth-model.md
Detail: Rejected to_thread() wrapper — at 2-4 auth calls per request, thread pool saturation becomes bottleneck at scale. Chose native async: AsyncGuard class with async store ports and AsyncReBACEvaluator. RBAC/ABAC/TBAC evaluators stay sync (CPU-bound dict matching). Only I/O boundaries go async. Follows SQLAlchemy AsyncSession, redis.asyncio precedent. Sync Guard unchanged — zero breaking changes for existing consumers.

---

### [DECISION] 2026-04-19 — Evaluator logic stays sync inside AsyncGuard
Topics: async, evaluators, performance
Affects-phases: phase-7-consumer-integration
Affects-specs: none
Detail: RBAC, ABAC, and TBAC evaluators are pure CPU computation on pre-fetched policies — no I/O, no benefit from async. AsyncPolicyRouter fetches policies async from store, then calls sync evaluators inline. Exception: ReBACEvaluator does recursive graph traversal with store I/O mid-evaluation, so it gets a dedicated AsyncReBACEvaluator. This avoids duplicating 3 evaluators while still providing true async for the one that needs it.

---

### [DECISION] 2026-04-19 — AdminRouter as mountable FastAPI router, standalone deferred to Phase 8
Topics: admin-api, fastapi, deployment
Affects-phases: phase-7-consumer-integration, phase-8-service-mode
Affects-specs: specs/architecture/integration-guide.md
Detail: AdminRouter is a mountable APIRouter (app.include_router(AdminRouter(admin=admin))). Standalone server (open-guard serve) deferred to Phase 8 (Service Mode). Layered design: PolicyAdmin SDK is core, AdminRouter wraps it, Phase 8 standalone wraps the router. Consumer owns their app, auth middleware, deployment.

---

### [DECISION] 2026-04-19 — DB tooling: create_all_tables() + CLI + DDL export, no Alembic
Topics: database, migrations, schema
Affects-phases: phase-7-consumer-integration
Affects-specs: specs/architecture/integration-guide.md
Detail: Schema creation is library concern (create_all_tables(engine) + CLI open-guard db init). Migration history is consumer concern — they manage evolution in their own Alembic/migration tool. DDL export (open-guard db schema --dialect postgresql) lets consumers extract raw SQL for their own migration framework.

---

### [DECISION] 2026-04-19 — [sql-async] optional extra with asyncpg + aiosqlite
Topics: async, dependencies, extras
Affects-phases: phase-7-consumer-integration
Affects-specs: pyproject.toml
Detail: New [sql-async] extra: sqlalchemy[asyncio] + aiosqlite. asyncpg not bundled in extra — consumers targeting PostgreSQL add it themselves (matches SQLAlchemy's own pattern). Mirrors existing [sql] extra for sync stores.

---

### [NOTE] 2026-04-19 — Three consumption patterns validated
Topics: architecture, deployment, consumption
Affects-phases: phase-7-consumer-integration, phase-8-service-mode
Affects-specs: specs/architecture/integration-guide.md
Detail: open-guard supports three consumption patterns: (1) Embedded library — Guard.from_config() for in-process evaluation; (2) Library + Admin API — embedded eval + mounted AdminRouter for management; (3) Centralized service — standalone deployment via HTTP/gRPC (Phase 8). Phase 7 architecture does not preclude pattern 3 — PolicyAdmin → AdminRouter → standalone server is a clean layering.

---
