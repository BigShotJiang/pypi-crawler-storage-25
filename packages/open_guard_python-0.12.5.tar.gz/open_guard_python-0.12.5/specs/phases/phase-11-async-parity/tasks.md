# Phase 11 — Async Parity: Tasks

> **Convention**: `[ ]` = not started, `[/]` = in progress, `[x]` = done

---

## Task 1: `AsyncGuard.list_authorized` (FEAT-018)

- [x] 1.1 Add `candidate_source: AsyncCandidateResourcePort | None` to `AsyncGuard.__init__`; store as `self._candidate_source`
- [x] 1.2 Implement `AsyncGuard.list_authorized(...)` — signature parity with sync `Guard.list_authorized`
- [x] 1.3 Source 1 — candidate source path: `await cand_source.fetch_candidates(...)`, per-candidate `await self.authorize(...)`
- [x] 1.4 Source 2 — ReBAC native enumeration: `await rel_store.find_object_ids_for_subject(...)`, per-id `await self.authorize(...)`
- [x] 1.5 Source 3 — leave delegation-contribution stub (`None`); Task 2.5 lights it up
- [x] 1.6 Reuse `Cursor.encode` / `decode` unchanged; round-trip `rebac_offset` + `candidate_cursor` + `seen_ids`
- [x] 1.7 Wire `candidate_source` kwarg in `adapters/factory.py` (`_build_async_memory_guard`, `_build_async_sql_guard`)
- [x] 1.8 Tests — `tests/async/test_async_list_authorized.py` (~12 tests, mirror sync coverage matrix)
- [x] 1.9 Tests — cross-engine: parametrize one test against `sqlite+aiosqlite://` to confirm SQL backend works
- [x] 1.10 Tests — random-fixture parity: same fixture against `Guard.list_authorized` and `AsyncGuard.list_authorized` returns equivalent IDs
- [x] 1.11 Commit: `feat(async): AsyncGuard.list_authorized — async-native reverse-lookup parity (FEAT-018)`

## Task 2: `AsyncDelegationEvaluator` + delegation fallback on `AsyncGuard` (FEAT-014)

- [x] 2.1 Promote pure helpers in `domain/services/delegation_evaluator.py` to module level if class-private (scope match, memoization key) — verify reuse
- [x] 2.2 Create `domain/services/async_delegation_evaluator.py` — sibling class with `async def evaluate` / `async def list_contribution`
- [x] 2.3 Create `domain/services/async_delegation_manager.py` — sibling of sync `DelegationManager`; cascade revocation + chain depth + lease renewal on async store
- [x] 2.4 Wire `AsyncGuard.__init__` to construct `AsyncDelegationEvaluator` when `delegation_store` is provided
- [x] 2.5 Wire delegation fallback in `AsyncGuard.authorize` — on policy-router DENIED, `await self._delegation_evaluator.evaluate(...)`; `_skip_delegation` flag parity
- [x] 2.6 Update Task 1 — replace source-3 stub with `await self._delegation_evaluator.list_contribution(...)`; same loop body as sync
- [x] 2.7 Implement `AsyncGuard.delegate(...)` and `AsyncGuard.revoke_delegation(...)` — wrappers over `AsyncDelegationManager`
- [x] 2.8 Implement `AsyncGuard.authorize_and_consume(...)` — CAS-safe `UPDATE WHERE` on async SQL store; pattern verbatim from sync
- [x] 2.9 Update `AsyncGuard` docstring — remove the "not yet implemented" caveat at `async_guard.py:43`
- [x] 2.10 Tests — `tests/async/test_async_delegation_fallback.py` (~10 tests)
- [x] 2.11 Tests — concurrent `authorize_and_consume` via `asyncio.gather` — expects exactly `min(N, max_uses)` allows under CAS
- [x] 2.12 Tests — cascade revocation on async store; lease expiry; chain depth
- [x] 2.13 Tests — `list_authorized` includes delegation contribution (source 3 lit up)
- [x] 2.14 Commit: `feat(async): AsyncDelegationEvaluator + delegation fallback on AsyncGuard (FEAT-014)`

## Task 3: `AsyncApprovalManager` + approval gating + `AsyncGuard.approve` / `reject` (FEAT-015)

- [x] 3.1 Promote SHA-256 idempotency hash helper to module level in `domain/services/approval_manager.py` if class-private; verify pure
- [x] 3.2 Create `domain/services/async_approval_manager.py` — sibling class with async I/O over `AsyncApprovalStorePort`
- [x] 3.3 Wire `AsyncGuard.__init__` to construct `AsyncApprovalManager` when `approval_store` is provided
- [x] 3.4 Wire approval gating in `AsyncGuard.authorize` — `Policy.requires_approval` produces `Decision(status=PENDING_APPROVAL)` with attached `ApprovalRequest`
- [x] 3.5 Idempotent re-call returns the same approval request (same SHA-256 key over `(tenant, subject.id, action.name, resource.id, resource.resource_type)`)
- [x] 3.6 Quorum + TTL + state transitions parity with sync
- [x] 3.7 Implement `AsyncGuard.approve(request_id, ...)` — thin wrapper over `AsyncApprovalManager.approve`
- [x] 3.8 Implement `AsyncGuard.reject(request_id, ...)` — thin wrapper over `AsyncApprovalManager.reject`
- [x] 3.9 Tests — `tests/async/test_async_approval_gating.py` (~7 tests)
- [x] 3.10 Tests — `tests/async/test_async_guard_approve_reject.py` (~4 tests)
- [x] 3.11 Tests — `list_authorized` excludes pending-approval (explicit re-assertion under approval-gated policy)
- [x] 3.12 Commit: `feat(async): AsyncApprovalManager + approval gating + AsyncGuard.approve/reject (FEAT-015)`

## Task 4: Service-mode unbundling

- [x] 4.1 `service/decision_router.py:136` — remove `if not is_async` guard around `POST /list_authorized` registration
- [x] 4.2 Async branch awaits `async_guard.list_authorized(...)` directly (no `asyncio.to_thread` wrapper)
- [x] 4.3 Same treatment for `POST /authorize_and_consume` — register against `AsyncGuard` too (depends on Task 2)
- [x] 4.4 Confirm `/authorize` and `/authorize/traced` already engine-agnostic — no change
- [x] 4.5 Confirm `SERVICE_API_VERSION == "v1"` unchanged
- [x] 4.6 Tests — `tests/service/test_decision_router_async_list.py` (~5 tests)
- [x] 4.7 Tests — response payload byte-equivalence between sync-backed and async-backed deployments
- [x] 4.8 Commit: `feat(service): register POST /list_authorized + /authorize_and_consume for AsyncGuard (FEAT-018/FEAT-014)`

## Task 5: ADRs

- [x] 5.1 Write `specs/decisions/0011-async-list-authorized-concurrency.md` — Accepted; locks sequential per-candidate evaluation
- [x] 5.2 Write `specs/decisions/0012-async-parity-composition.md` — Accepted; locks "mirror, don't redesign" stance
- [x] 5.3 Update `specs/decisions/impact-map.json` — add topics for both ADRs
- [x] 5.4 Commit: `docs(adr): ADR-0011 list_authorized concurrency + ADR-0012 async-parity composition`

## Task 6: Integration-guide Phase 11 section

- [x] 6.1 Author "Phase 11 — Async parity" section in `specs/architecture/integration-guide.md` with side-by-side sync/async snippets
- [x] 6.2 Industry-standards intro paragraph (OpenFGA / Zanzibar / SpiceDB / AWS Verified Permissions / NIST RBAC delegation / XACML obligations)
- [x] 6.3 Mirror snippets in `tests/integration/test_integration_guide_phase11_examples.py` (~8 tests)
- [x] 6.4 Commit: `docs(integration): Phase 11 async parity section + executable mirrors`

## Task 7: Regression + release artifacts

- [x] 7.1 Full regression — `pytest --tb=short -q` — target ≥1230 tests, ≥93% coverage
- [x] 7.2 Bump `open_guard.__version__` to `0.12.0`
- [x] 7.3 Bump version in `pyproject.toml`; run `uv lock`
- [x] 7.4 Verify `__init__.py` exports — `AsyncGuard.list_authorized`, `AsyncGuard.authorize_and_consume`, `AsyncGuard.approve`, `AsyncGuard.reject`, `AsyncGuard.delegate`, `AsyncGuard.revoke_delegation` all reachable
- [x] 7.5 Run `/sync-docs` to propagate history entries to `auth-model.md`, `integration-guide.md`, `roadmap.md`
- [x] 7.6 Run `/complete-phase` to write retrospective, finalize tracking, prepare release tag
- [x] 7.7 Commit: `chore(phase-11): docs sync + version bump to v0.12.0`
