# Phase 11 — Async Parity

> **Version**: v0.12.0
> **Status**: Planned
> **Predecessor**: Phase 10 — Service Mode + Python SDK (v0.11.0)
> **Theme**: Close the remaining async-parity gaps so `AsyncGuard` has the same surface as `Guard`.

## Goal

After this phase, every authorization primitive the sync `Guard` exposes also exists natively on `AsyncGuard`. Consumers running on async SQL stores (`postgresql+asyncpg://`, `sqlite+aiosqlite://`) — the path open-guard recommends since Phase 9 — no longer encounter "this only works on sync `Guard`" gaps.

Three siblings ship together as a single minor release because they share the same shape (async sibling of an existing sync primitive), the same target consumers (anyone on `AsyncGuard.from_config(dsn=...)`), and the same risk profile (zero new public abstractions — every async sibling has a sync ancestor whose semantics it mirrors):

1. **FEAT-018** — `AsyncGuard.list_authorized` (P1)
2. **FEAT-014** — `AsyncDelegationEvaluator` + delegation fallback on `AsyncGuard.authorize` (P1, promoted from P2 for the bundle)
3. **FEAT-015** — `AsyncApprovalManager` + approval gating + `AsyncGuard.approve` / `reject` (P1, promoted from P2 for the bundle)

A side-effect of FEAT-018: `service/decision_router.py` drops the `if not is_async` guard, so `POST {prefix}/list_authorized` becomes available on every service mode deployment regardless of engine.

This phase is intentionally minor in scope. No new ports, no new entities, no wire-contract changes. Implementation is mostly assembling async equivalents from already-shipped pieces.

## Industry Alignment (vendor-neutral framing)

The three primitives map directly to industry-standard authz APIs. open-guard's async surface lands on the same shape as the rest of the field — no service-specific assumptions.

| Primitive | Industry-standard reverse / lifecycle API |
|-----------|-------------------------------------------|
| `AsyncGuard.list_authorized` | OpenFGA `ListObjects` · Auth0 FGA `listObjects` · Zanzibar / SpiceDB `LookupResources` · AWS Verified Permissions `BatchIsAuthorized` / `IsAuthorizedWithToken` · Cerbos `PlanResources` · Casbin `getImplicitResourcesForUser` |
| `AsyncDelegationEvaluator` | NIST RBAC delegation model (Sandhu et al.) · Vault / etcd lease-bound capability passing · capability-based security (POSIX capabilities, Object-capability model) |
| `AsyncApprovalManager` | XACML Obligations / advisory PDP-PAP flow · OAuth 2.0 Rich Authorization Requests (RFC 9396) · NIST SP 800-162 approval workflows · Cerbos `WORKFLOW` recipes |

Inherits the composition strategy locked in ADR-0001 (sync `Guard.list_authorized`) — async siblings reuse that contract, do not redesign it.

## Key Decisions

| # | Decision | Rationale |
|---|----------|-----------|
| 1 | **Bundle the three async-parity gaps into one minor phase** | They share consumers, shape, and risk. Three separate minor releases would be churn for the same release notes. Bundling promotes FEAT-014/015 from P2 to P1 *for this phase only* — they are P2 in isolation, P1 in aggregate with FEAT-018. |
| 2 | **Mirror sync signatures and semantics exactly** | The sync API is the contract. Anyone reading sync docs should be able to substitute `await` and have it work. No async-specific knobs, no renamed parameters, no shape drift. |
| 3 | **Reuse existing async ports — no new public abstractions** | `AsyncCandidateResourcePort` (Phase 7), `AsyncRelationshipStorePort.find_object_ids_for_subject` (Phase 7), `AsyncDelegationStorePort` (Phase 7), `AsyncApprovalStorePort` (Phase 7) are all already in place. The Phase 7 design anticipated this work — we're cashing in the option, not designing new ports. |
| 4 | **Sequential per-candidate evaluation in `AsyncGuard.list_authorized`** | Matches sync semantics exactly. Bounded `gather` concurrency is tempting but interacts with cursor stability and per-decision side effects; defer to a future ENH if profiling demands it. Document the choice in ADR-0011. |
| 5 | **`AsyncDelegationEvaluator` and `AsyncApprovalManager` are direct async ports of the sync services** — same class shape, same method names, same return types | The sync services already separate logic from I/O cleanly; the async siblings re-implement only the I/O. Pure-logic helpers (scope match, narrowing, idempotency hashing, quorum count) are shared where they're already pure. |
| 6 | **Drop the `if not is_async` guard in `service/decision_router.py`** | Once `AsyncGuard.list_authorized` exists, the service mode endpoint becomes engine-agnostic. No wire-contract change — same path, same request/response schemas, just available on more deployments. `SERVICE_API_VERSION` stays `"v1"`. |
| 7 | **Zero breaking changes** | All three are additive. Sync `Guard` and existing `AsyncGuard` callers see no signature changes. |
| 8 | **No new optional extras** | Reuses existing `[sql-async]`, `[service]`, `[client]`. |
| 9 | **Python SDK gets no signature changes** | The SDK's `client.decisions.list_authorized` already targets the wire endpoint; once the server-side guard registration is unbundled, async-backed deployments respond on the same method. |
| 10 | **ADR-0011 (concurrency model) + ADR-0012 (async parity composition) to be authored during implementation** | Captures the locked sequential-evaluation choice and the explicit-parity-not-redesign stance for posterity. |

## Source Structure

```
src/open_guard/
├── domain/services/
│   ├── async_delegation_evaluator.py        # NEW — async sibling of delegation_evaluator.py (FEAT-014)
│   ├── async_approval_manager.py            # NEW — async sibling of approval_manager.py (FEAT-015)
│   └── async_guard.py                       # MODIFY — wire delegation fallback + approval gating + add list_authorized + approve/reject (FEAT-014/015/018)
├── service/
│   └── decision_router.py                   # MODIFY — drop `if not is_async` guard; register POST /list_authorized for AsyncGuard too (FEAT-018)
└── client/
    └── (no changes — SDK already targets the wire endpoint)

specs/decisions/
├── 0011-async-list-authorized-concurrency.md     # NEW — locks sequential per-candidate evaluation
└── 0012-async-parity-composition.md              # NEW — locks the "mirror, don't redesign" stance

tests/
├── async/
│   ├── test_async_list_authorized.py             # NEW — parity with sync list_authorized test matrix
│   ├── test_async_delegation_fallback.py         # NEW — parity with sync delegation tests
│   ├── test_async_approval_gating.py             # NEW — parity with sync approval tests
│   └── test_async_guard_approve_reject.py        # NEW — AsyncGuard.approve / reject lifecycle
├── service/
│   └── test_decision_router_async_list.py        # NEW — POST /list_authorized works against AsyncGuard
└── integration/
    └── test_integration_guide_phase11_examples.py # NEW — executable mirrors for the integration-guide Phase 11 section
```

## Scope

### In Scope

1. **FEAT-018: `AsyncGuard.list_authorized`** — async-native parity with sync. Same signature, same semantics, same return shape. Composes three sources (candidate source → ReBAC native enumeration → delegation contribution from FEAT-014). Reuses existing `AsyncCandidateResourcePort.fetch_candidates` and `AsyncRelationshipStorePort.find_object_ids_for_subject`. Cursor semantics, deny precedence, chain enforcement, pending-approval exclusion all inherited via per-candidate `authorize()` calls.

2. **FEAT-014: `AsyncDelegationEvaluator` + delegation fallback on `AsyncGuard.authorize`** — async sibling of sync `DelegationEvaluator`. Same `evaluate(...)` and `list_contribution(...)` surface. Uses `AsyncDelegationStorePort` (already in place). Wired into `AsyncGuard.authorize` as the fallback when the policy router returns DENIED, matching sync behavior. CAS-safe `decrement_uses` / `decrement_budget` on async stores. `AsyncGuard.authorize_and_consume` ships as part of this.

3. **FEAT-015: `AsyncApprovalManager` + approval gating + `AsyncGuard.approve` / `reject`** — async sibling of sync `ApprovalManager`. Same `create_request`, `approve`, `reject`, `get_request`, `get_request_by_idempotency_key` surface. Uses `AsyncApprovalStorePort`. Wired into `AsyncGuard.authorize` so policies with `requires_approval=True` produce `Decision(status=PENDING_APPROVAL)` and return an `ApprovalRequest`. SHA-256 idempotency hashing reused from sync (pure helper).

4. **Service mode unbundling** — `service/decision_router.py:136` drops the `if not is_async` guard. `POST {prefix}/list_authorized` registers for both sync and async guards. No new endpoint; no schema change.

5. **Integration guide** — new "Phase 11 — Async parity" section showing the async siblings side-by-side with the sync versions. Executable mirrors in `tests/integration/test_integration_guide_phase11_examples.py`.

6. **ADR-0011 + ADR-0012** — authored during implementation.

### Out of Scope (Deferred)

- **gRPC service + TypeScript/Go SDKs** — moved to **Phase 12** (was Phase 11 before renumbering). The async parity work does not change the wire contract, so the Phase 12 plan is unaffected.
- **MCP `/tools/check` endpoint** — still Phase 12.
- **`AsyncMCPGuard.list_authorized_tools`** — natural follow-on once `AsyncGuard.list_authorized` exists, but file separately when the first async MCP consumer surfaces. Not blocking.
- **Concurrent / gathered per-candidate evaluation in `list_authorized`** — ADR-0011 locks sequential. A bounded-concurrency `ENH-NNN` can land later as a profiling-driven optimization.
- **Reverse-ABAC query compilation (ENH-014)** — still deferred. Affects both sync and async equally.
- **Per-result explainability for `list_authorized` (ENH-016)** — still deferred. Async inherits the same behavior as sync (no trace per result).
- **Zookie-style consistency tokens (ENH-015)** — still deferred.
- **Cascade revocation event emission for descendants (ENH-018)** — orthogonal; tracked separately.
- **Async SDK signature changes** — none planned. The wire contract is unchanged.

## Deliverables

| # | Deliverable | Verification |
|---|-------------|-------------|
| 1 | `AsyncGuard.list_authorized(subject, action, resource_type, tenant_id, ...)` returns a `ListResult` matching the sync `Guard.list_authorized` output for equivalent inputs | `pytest tests/async/test_async_list_authorized.py` |
| 2 | `AsyncGuard.list_authorized` honors candidate-source pagination, ReBAC native enumeration, and delegation contribution | same |
| 3 | Cursor round-trip on async path equivalent to sync (`encode` / `decode` reused; no new cursor format) | same |
| 4 | `AsyncDelegationEvaluator.evaluate` returns the same shape as sync `DelegationEvaluator.evaluate` for equivalent fixtures | `pytest tests/async/test_async_delegation_fallback.py` |
| 5 | `AsyncGuard.authorize` falls back to delegation when policy router DENIES, parity with sync | same |
| 6 | `AsyncGuard.authorize_and_consume` decrements uses / budget CAS-safely on async SQL store | same + concurrent-call test |
| 7 | Cascade revocation works on async delegation store | same |
| 8 | `AsyncApprovalManager.create_request` returns the same shape as sync for equivalent fixtures; SHA-256 idempotency key reused | `pytest tests/async/test_async_approval_gating.py` |
| 9 | `AsyncGuard.authorize` returns `Decision(status=PENDING_APPROVAL)` for policies with `requires_approval=True`, parity with sync | same |
| 10 | `AsyncGuard.approve(request_id, ...)` / `AsyncGuard.reject(request_id, ...)` advance approval state | `pytest tests/async/test_async_guard_approve_reject.py` |
| 11 | `POST {prefix}/list_authorized` reachable on a service running an `AsyncGuard` | `pytest tests/service/test_decision_router_async_list.py` |
| 12 | `SERVICE_API_VERSION` unchanged (`"v1"`); no breaking wire-contract changes | grep + service tests |
| 13 | Integration-guide Phase 11 section with executable mirrors | `pytest tests/integration/test_integration_guide_phase11_examples.py` |
| 14 | Full regression passes | `pytest` — target: ≥1230 tests (Phase 10 baseline 1186 + ~45 new), coverage ≥93% |
| 15 | ADR-0011 + ADR-0012 written and accepted; impact-map updated | files exist + `cat specs/decisions/impact-map.json` shows new topics |

## Acceptance Criteria

1. Every method on sync `Guard` related to `list_authorized`, delegation fallback, and async approval gates has an `AsyncGuard` equivalent with the same signature (modulo `async def` / `await`) and the same return shape.
2. `AsyncGuard.list_authorized` works against both async memory stores and async SQL stores (`sqlite+aiosqlite://` covered in tests; `postgresql+asyncpg://` covered by parametrized CI fixture where available).
3. Pending-approval and DENIED decisions are excluded from `AsyncGuard.list_authorized` output, identical to sync.
4. CAS-safe usage/budget decrement preserved on async SQL store under concurrent `authorize_and_consume` calls (regression test with `asyncio.gather` of N concurrent calls expecting exactly `min(N, max_uses)` allows).
5. `service/decision_router.py` no longer special-cases sync; both engines register the same four Decision endpoints.
6. Zero breaking changes: existing sync `Guard`, async `AsyncGuard.authorize` / `authorize_traced`, `PolicyAdmin`, `AdminRouter`, `OpenGuardClient`, `AsyncOpenGuardClient` import paths and signatures unchanged.
7. `SERVICE_API_VERSION` stays `"v1"`. No request/response schema changes on any endpoint.
8. Coverage ≥93%; ≥1230 tests; full suite green.
9. ADR-0011 (concurrency) and ADR-0012 (async-parity composition) accepted.
10. Integration-guide Phase 11 section ships with executable mirrors; doc cannot drift silently.

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/decisions/0001-list-authorized-composition.md` | Composition strategy inherited by `AsyncGuard.list_authorized` |
| `specs/decisions/0003-delegation-entity-and-api-shape.md` | Delegation entities are unchanged; only the evaluator becomes async |
| `specs/decisions/0004-delegation-evaluator-and-meta-authz.md` | Sync delegation evaluator semantics — direct port target for FEAT-014 |
| `specs/decisions/0005-delegation-bounds-usage-budget-lease.md` | CAS-safety contract preserved on async path |
| `specs/architecture/auth-model.md` | Sections for delegation and approval need an "async" callout |
| `specs/architecture/integration-guide.md` | New Phase 11 section |
| `specs/backlog/details/FEAT-018.md` | Full problem framing for the list_authorized async sibling |

## Cross-Repo Coordination

- **cerebrio-sapience** has filed ENH-088 on its side as the consumer-side adapter for `AsyncGuard.list_authorized`; it currently `hasattr`-guards the call and returns `[]`. On v0.12.0 release, cerebrio picks this up on next dependency bump — no cerebrio-side code change required beyond removing the guard. This is *not* coordination required to complete Phase 11; it is downstream awareness.
- **open-shield-python** is untouched.

## Risk & Mitigations

| Risk | Mitigation |
|------|-----------|
| Sequential per-candidate evaluation is too slow on async SQL backends with high candidate counts | Document the choice in ADR-0011 + roadmap a bounded-concurrency ENH for after real profiling data; sequential is the safe default that matches sync |
| `AsyncDelegationEvaluator` CAS path on async SQL drift from sync `UPDATE WHERE` pattern | Reuse the `UPDATE WHERE` pattern verbatim on the async store; concurrent-decrement test enforces the invariant |
| `AsyncApprovalManager` idempotency hash drifts from sync (silently making the two non-interoperable) | The SHA-256 hash helper is a pure function — import the sync helper, do not re-implement |
| Service mode `if not is_async` removal exposes a previously-hidden bug on AsyncGuard | Service-side parity test (`tests/service/test_decision_router_async_list.py`) runs the existing decision-router test matrix against an async-backed app |
| Phase scope creep — pulling in `AsyncMCPGuard.list_authorized_tools` because "it's just async" | Out-of-scope list above is explicit; file the MCP follow-on separately when a real consumer asks |
| Coverage drop from new code without paired tests | Each task group in `plan.md` ships its tests in the same commit |
