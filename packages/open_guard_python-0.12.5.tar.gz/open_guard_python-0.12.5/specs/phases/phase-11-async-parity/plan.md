# Phase 11 — Async Parity: Implementation Plan

> **Approach**: Bottom-up — ship the smallest, most-self-contained primitive first (FEAT-018), then the two manager/evaluator services (FEAT-014, FEAT-015), then the service-mode unbundling. Each task is independently committable; no task blocks an earlier one.
> **Breaking changes**: None. All changes are additive.
> **Commit convention**: `feat(scope):` for new behavior, `refactor(scope):` for cleanups, `docs(scope):` for guide updates.

---

## Order rationale

| Order | Task | Why this order |
|-------|------|----------------|
| 1 | FEAT-018 — `AsyncGuard.list_authorized` (sources 1 + 2 only) | All required async ports already exist (Phase 7). Smallest patch, ships immediate user value. Delegation contribution stubbed and lit up by Task 2. |
| 2 | FEAT-014 — `AsyncDelegationEvaluator` + `AsyncGuard.authorize_and_consume` | Extends Task 1's `list_authorized` with source 3 (delegation contribution). Wires delegation fallback into `AsyncGuard.authorize`. |
| 3 | FEAT-015 — `AsyncApprovalManager` + `AsyncGuard.approve` / `reject` | Independent from Tasks 1 / 2, but lands last because it touches the most authorize-time branches and benefits from the parity tests already written in Tasks 1 + 2. |
| 4 | Service-mode unbundling | Trivial once `AsyncGuard.list_authorized` exists; one-line guard removal + parity test. |
| 5 | ADRs + integration-guide section + regression | Doc + verification step at phase boundary. |

---

## Task 1: `AsyncGuard.list_authorized` (FEAT-018)

**Why first**: All four async ports it depends on (`AsyncPolicyStorePort`, `AsyncRelationshipStorePort.find_object_ids_for_subject`, `AsyncCandidateResourcePort.fetch_candidates`, `AsyncEvaluatorPort` evaluators) already exist from Phase 7. The work is the method on `AsyncGuard` and its tests.

### 1.1 Add `AsyncGuard.list_authorized`

Mirror sync `Guard.list_authorized` in `domain/services/guard.py:326` exactly. Method signature:

```python
# src/open_guard/domain/services/async_guard.py

async def list_authorized(
    self,
    subject: Subject,
    action: str,
    resource_type: str,
    tenant_id: str,
    prefilter: dict[str, Any] | None = None,
    limit: int = 100,
    cursor: str | None = None,
    context: dict[str, Any] | None = None,
    relationship_store: AsyncRelationshipStorePort | None = None,
    candidate_source: AsyncCandidateResourcePort | None = None,
    session_id: str | None = None,
) -> ListResult:
    """Async parity of :meth:`Guard.list_authorized` — see ADR-0001 for the
    composition strategy (industry-standard reverse-lookup; OpenFGA
    ``ListObjects`` / Zanzibar ``LookupResources`` / AWS Verified
    Permissions ``BatchIsAuthorized``).
    """
```

Implementation pattern: copy the sync implementation, change blocking calls to `await`. Three sources are evaluated sequentially, same as sync:

1. **Candidate source** — `await cand_source.fetch_candidates(...)`; per-candidate `await self.authorize(...)`.
2. **ReBAC native enumeration** — `await rel_store.find_object_ids_for_subject(...)`; per-id `await self.authorize(...)`.
3. **Delegation contribution** — stub `None` for now; populated by Task 2 once `AsyncDelegationEvaluator` exists.

Cursor: reuse the existing sync `Cursor` entity (`encode`/`decode`) — the cursor format is engine-agnostic.

`ListResult` entity is also reused unchanged.

### 1.2 Wire `candidate_source` injection on `AsyncGuard.__init__`

Sync `Guard` accepts `candidate_source` at construction (Phase 4). Add the same parameter to `AsyncGuard.__init__`:

```python
candidate_source: AsyncCandidateResourcePort | None = None,
```

Store as `self._candidate_source`.

### 1.3 Tests — parity matrix

`tests/async/test_async_list_authorized.py`. Each test mirrors a sync `tests/test_list_authorized*.py` case:

- `test_async_candidate_source_pagination` — multi-page candidate-source enumeration with cursor round-trip.
- `test_async_rebac_native_enumeration` — ReBAC-only enumeration (no candidate source) returns the same IDs as sync.
- `test_async_both_sources_composed` — candidate source + ReBAC, with overlap deduplication via `seen_ids`.
- `test_async_deny_excluded` — DENY policies remove matching IDs from the result, parity with sync.
- `test_async_pending_approval_excluded` — `Decision(status=PENDING_APPROVAL)` IDs not in result.
- `test_async_chain_enforcement` — OBO chain depth honored; `ChainDepthExceededError` raised identically.
- `test_async_prefilter_to_candidate_source` — prefilter forwarded; not applied to ReBAC tuples (documented).
- `test_async_limit_zero_returns_empty` — early-return parity.
- `test_async_cursor_round_trip_against_sql_backend` — backed by `sqlite+aiosqlite://`, full multi-page round-trip.
- `test_async_parity_with_sync_random_fixture` — generate a random fixture, run both `Guard.list_authorized` and `AsyncGuard.list_authorized`, assert equivalent output.

### 1.4 Wire in factory

`adapters/factory.py` — `_build_async_memory_guard` and `_build_async_sql_guard` accept an optional `candidate_source` kwarg, forwarded to `AsyncGuard(...)`. Sync factory already does this.

**Commit**: `feat(async): AsyncGuard.list_authorized — async-native reverse-lookup parity (FEAT-018)`

---

## Task 2: `AsyncDelegationEvaluator` + delegation fallback on `AsyncGuard` (FEAT-014)

**Why second**: Lights up source 3 in Task 1's `list_authorized`. Also adds delegation fallback to `AsyncGuard.authorize`, closing the docstring's "not yet implemented" caveat in `async_guard.py:43`.

### 2.1 Create `AsyncDelegationEvaluator`

`src/open_guard/domain/services/async_delegation_evaluator.py` — sibling of sync `delegation_evaluator.py`. Same class shape, same `EvaluationResult`, same `evaluate(...)` / `list_contribution(...)` surface, only the I/O becomes async.

```python
class AsyncDelegationEvaluator:
    def __init__(
        self,
        delegation_store: AsyncDelegationStorePort,
        guard: AsyncGuard,
        clock: Callable[[], datetime] | None = None,
        max_depth: int = 10,
    ) -> None: ...

    async def evaluate(
        self,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        context: dict[str, Any] | None = None,
    ) -> EvaluationResult: ...

    async def list_contribution(
        self,
        subject: Subject,
        tenant_id: str,
        *,
        resource_type: str | None = None,
    ) -> list[str]: ...
```

Reuse pure-logic helpers from sync (`_scope_matches`, idempotency hash, memoization key) by promoting them to module-level functions if they aren't already.

### 2.2 Wire delegation fallback in `AsyncGuard.authorize`

`AsyncGuard.__init__` constructs `AsyncDelegationEvaluator` when `delegation_store` is provided, mirroring sync `Guard.__init__:120`. `AsyncGuard.authorize` checks the policy-router decision; on DENIED, awaits `self._delegation_evaluator.evaluate(...)`. If delegation allows, return the rewritten decision. Same `_skip_delegation` private flag used by sync.

### 2.3 Implement `AsyncGuard.delegate` / `revoke_delegation`

Mirror sync `Guard.delegate(...)` / `Guard.revoke_delegation(...)`. Both are thin async wrappers around `AsyncDelegationManager` (new — sibling of sync `DelegationManager`). Cascade revocation logic identical.

Note: sync `DelegationManager` is mostly I/O over `DelegationStorePort`. The async manager is the same logic over `AsyncDelegationStorePort`. Pure helpers (chain-depth check, scope narrowing validation) are shared.

### 2.4 Implement `AsyncGuard.authorize_and_consume`

Mirror sync `Guard.authorize_and_consume`. CAS-safe decrement on `AsyncSQLAlchemyDelegationStore` already supports `UPDATE WHERE` (Phase 5 design). The pattern is preserved verbatim.

### 2.5 Update Task 1 — light up delegation contribution

In `AsyncGuard.list_authorized`, replace the source-3 stub with:

```python
if self._delegation_evaluator is not None and len(allow_ids) < limit:
    delegation_ids = await self._delegation_evaluator.list_contribution(
        subject, tenant_id, resource_type=resource_type
    )
    for obj_id in delegation_ids:
        ...  # same loop body as sync
```

### 2.6 Tests

`tests/async/test_async_delegation_fallback.py`:
- `test_async_delegation_allows_when_policy_denies` — fallback parity.
- `test_async_delegation_evaluator_list_contribution` — id:eq / id:in scopes enumerated.
- `test_async_authorize_and_consume_cas_safety_concurrent` — `asyncio.gather` of N concurrent `authorize_and_consume` calls expects exactly `min(N, max_uses)` allows.
- `test_async_cascade_revocation` — revoking a parent revokes descendants on async store.
- `test_async_lease_expiry` — `expires_at` honored on async path.
- `test_async_delegation_chain_depth_enforced` — `max_delegation_depth` limit.
- `test_async_list_authorized_includes_delegation_contribution` — source 3 lights up (parity with sync Phase 5 test).

**Commit**: `feat(async): AsyncDelegationEvaluator + delegation fallback on AsyncGuard (FEAT-014)`

---

## Task 3: `AsyncApprovalManager` + approval gating + `AsyncGuard.approve` / `reject` (FEAT-015)

**Why third**: Independent of Tasks 1 / 2. Lands last because it benefits from the parity-test scaffolding already in place.

### 3.1 Create `AsyncApprovalManager`

`src/open_guard/domain/services/async_approval_manager.py` — sibling of sync `approval_manager.py`. Same surface, async I/O:

```python
class AsyncApprovalManager:
    def __init__(
        self,
        approval_store: AsyncApprovalStorePort,
        clock: Callable[[], datetime] | None = None,
    ) -> None: ...

    async def create_request(
        self,
        *,
        subject: Subject,
        action: Action,
        resource: Resource,
        tenant_id: str,
        requirement: ApprovalRequirement,
    ) -> ApprovalRequest: ...

    async def approve(
        self, request_id: str, tenant_id: str, approver: str, reason: str | None = None
    ) -> ApprovalRequest: ...

    async def reject(
        self, request_id: str, tenant_id: str, approver: str, reason: str | None = None
    ) -> ApprovalRequest: ...

    async def get_request(
        self, request_id: str, tenant_id: str
    ) -> ApprovalRequest | None: ...

    async def get_request_by_idempotency_key(
        self, idempotency_key: str, tenant_id: str
    ) -> ApprovalRequest | None: ...
```

SHA-256 idempotency hash: import the existing pure helper from `approval_manager.py` (promote to module-level if it currently lives inside the sync class).

### 3.2 Wire approval gating in `AsyncGuard.authorize`

`AsyncGuard.__init__` constructs `AsyncApprovalManager` when `approval_store` is provided, mirroring sync `Guard.__init__:104`. The policy router already produces `Policy.requires_approval` matches; in `AsyncGuard.authorize`, after the policy router runs:

- If any matched policy has `requires_approval=True` and the result is ALLOWED → create / fetch the approval request, return `Decision(status=PENDING_APPROVAL)` with `approval_request` attached.
- Idempotent re-call with same (tenant, subject, action, resource, resource_type) returns the same `ApprovalRequest`.
- Quorum, TTL, expired-state transitions match sync.

### 3.3 Implement `AsyncGuard.approve` / `AsyncGuard.reject`

Thin async wrappers around `AsyncApprovalManager.approve` / `.reject`. Match sync `Guard.approve` / `Guard.reject` signature at `guard.py:312`+.

### 3.4 Tests

`tests/async/test_async_approval_gating.py`:
- `test_async_requires_approval_returns_pending` — parity with sync.
- `test_async_approval_idempotent_re_call` — same idempotency key → same request.
- `test_async_approval_quorum_reached` — quorum count advances state to APPROVED.
- `test_async_approval_ttl_expiry` — clock-injected expiry transitions state to EXPIRED.
- `test_async_pending_excluded_from_list_authorized` — already covered in Task 1; add an explicit assertion against this path.

`tests/async/test_async_guard_approve_reject.py`:
- `test_async_guard_approve_transitions_to_allowed_on_next_authorize` — lifecycle parity with sync.
- `test_async_guard_reject_transitions_to_denied_on_next_authorize` — same.
- `test_async_guard_approve_unknown_request_raises` — error parity.

### 3.5 SDK note

`open_guard.client.namespaces.decisions.list_authorized` already exists (sync + async) — no SDK change needed. `client.admin` does not surface approvals today; that remains a future ENH if real consumers ask.

**Commit**: `feat(async): AsyncApprovalManager + approval gating + AsyncGuard.approve/reject (FEAT-015)`

---

## Task 4: Service-mode unbundling

**Why fourth**: One-line guard removal once Task 1 lands. Kept as a separate task for a clean commit + targeted test.

### 4.1 Remove `if not is_async` guard

`src/open_guard/service/decision_router.py:136` currently registers `POST /list_authorized` only when the embedded guard is sync. Drop the conditional; register the endpoint for `AsyncGuard` too. The async branch calls `await async_guard.list_authorized(...)` directly (no `asyncio.to_thread` wrapper).

While there:
- `/authorize_and_consume` — currently sync-only too (`decision_router.py` registers it on `Guard` only). After Task 2, register it for `AsyncGuard` as well.
- `/authorize` and `/authorize/traced` — already engine-agnostic, no change.

### 4.2 Tests

`tests/service/test_decision_router_async_list.py`:
- `test_post_list_authorized_against_async_guard_memory` — service with `AsyncGuard.from_config(backend="memory")` responds 200 on `POST /v1/list_authorized`.
- `test_post_list_authorized_against_async_guard_sqlite` — same with `sqlite+aiosqlite://`.
- `test_post_authorize_and_consume_against_async_guard` — `AsyncGuard.authorize_and_consume` round-trip over the wire.
- `test_post_list_authorized_pagination_round_trip_async` — cursor round-trip over the wire.
- `test_post_list_authorized_response_shape_parity` — response payload byte-equivalent to the sync-backed deployment.

### 4.3 Confirm `SERVICE_API_VERSION` unchanged

`grep -r SERVICE_API_VERSION src/open_guard/service/` — value stays `"v1"`. No new endpoint added; only the registration condition relaxed.

**Commit**: `feat(service): register POST /list_authorized + /authorize_and_consume for AsyncGuard (FEAT-018/FEAT-014)`

---

## Task 5: ADRs

### 5.1 ADR-0011 — `AsyncGuard.list_authorized` concurrency model

`specs/decisions/0011-async-list-authorized-concurrency.md`. Captures:

- **Status**: Accepted (Phase 11).
- **Context**: Sync `Guard.list_authorized` iterates candidates sequentially. Async opens an obvious optimization (bounded `gather`) but interacts with cursor stability, per-decision side effects (approval state, delegation consumption), and observability.
- **Decision**: Sequential per-candidate `await self.authorize(...)`. Match sync semantics exactly.
- **Consequences**: A bounded-concurrency `ENH` can land later as a profile-driven optimization; today is not the time.
- **Alternatives considered**: bounded `gather(N)`, work-stealing across async tasks — both deferred.

### 5.2 ADR-0012 — Async-parity composition (mirror, don't redesign)

`specs/decisions/0012-async-parity-composition.md`. Captures:

- **Status**: Accepted (Phase 11).
- **Context**: Three async-parity gaps (FEAT-014/015/018) bundled. Each could have been an opportunity to redesign the sync surface.
- **Decision**: Mirror, don't redesign. Async siblings preserve sync signatures, return types, error semantics, and idempotency rules. Pure helpers (SHA-256 hashing, scope-narrowing validation, chain-depth checks) are shared, not re-implemented.
- **Consequences**: Anyone reading sync docs can substitute `await` and have it work. The two surfaces evolve together going forward. A future redesign that touches both at once is fine; a unilateral async-only redesign is not.

### 5.3 Update `specs/decisions/impact-map.json`

Add topics for ADR-0011 and ADR-0012 keyed to `auth-model.md` and `integration-guide.md`.

**Commit**: `docs(adr): ADR-0011 list_authorized concurrency + ADR-0012 async-parity composition`

---

## Task 6: Integration-guide Phase 11 section

### 6.1 Author the section

`specs/architecture/integration-guide.md` — new "Phase 11 — Async parity" section. Side-by-side snippets:

- `Guard.list_authorized(...)` vs `await AsyncGuard.list_authorized(...)`
- `Guard.authorize_and_consume(...)` vs `await AsyncGuard.authorize_and_consume(...)`
- `Guard.approve(...)` vs `await AsyncGuard.approve(...)`
- Service mode: `POST /v1/list_authorized` against a sync-backed app vs against an async-backed app (same request/response).

Each snippet is small, copy-pasteable, and references the standards (OpenFGA / Zanzibar / SpiceDB / AWS Verified Permissions / NIST RBAC delegation / XACML obligations) at the section intro — open-guard follows the same shape.

### 6.2 Executable mirrors

`tests/integration/test_integration_guide_phase11_examples.py` — every snippet has a paired test that compiles and runs against an in-memory async backend. The guide cannot drift silently. Same pattern as Phase 10.

**Commit**: `docs(integration): Phase 11 async parity section + executable mirrors`

---

## Task 7: Regression + release artifacts

### 7.1 Full regression

```bash
pytest --tb=short -q
```

Target: ≥1230 tests, ≥93% coverage, zero failures.

### 7.2 `pyproject.toml` + `open_guard.__version__`

Bump to `0.12.0`. Run `uv lock` to update `uv.lock`.

### 7.3 Phase wrap-up

Per Rule 9, run `/sync-docs` to propagate Phase 11 history entries to `auth-model.md`, `integration-guide.md`, and `roadmap.md`. Then run `/complete-phase` to write the retrospective, finalize tracking, and prepare the release tag.

**Commit**: `chore(phase-11): docs sync + version bump to v0.12.0`

---

## Test counts (rough)

| Source | New tests |
|--------|-----------|
| `tests/async/test_async_list_authorized.py` | ~12 |
| `tests/async/test_async_delegation_fallback.py` | ~10 |
| `tests/async/test_async_approval_gating.py` | ~7 |
| `tests/async/test_async_guard_approve_reject.py` | ~4 |
| `tests/service/test_decision_router_async_list.py` | ~5 |
| `tests/integration/test_integration_guide_phase11_examples.py` | ~8 |
| **Total** | **~46** |

Phase 10 baseline: 1186 tests. Phase 11 target: ≥1230 tests.

---

## Out-of-scope reminders (do not pull in)

- `AsyncMCPGuard.list_authorized_tools` — file separately when a real async MCP consumer asks.
- Bounded-concurrency `AsyncGuard.list_authorized` — wait for profiling data.
- Reverse-ABAC query compilation (ENH-014) — still deferred.
- Per-result explainability for `list_authorized` (ENH-016) — still deferred.
- Zookie-style consistency tokens (ENH-015) — still deferred.
- Cascade revocation event emission for descendants (ENH-018) — orthogonal item.
- gRPC + TS/Go SDKs — Phase 12.
- MCP `/tools/check` endpoint — Phase 12.

If any of these are tempting mid-phase, log them as `[DISCOVERY]` entries in `history.md`, do not implement.
