# Phase 11 — Retrospective

> **Phase**: 11 — Async Parity
> **Version**: v0.12.0
> **Branch**: `phase-11-async-parity`
> **Duration**: 2026-05-18 (~1 session)
> **Predecessor**: Phase 10 — Service Mode + Python SDK (v0.11.0)

## Summary

Closed the remaining async-parity gaps so `AsyncGuard` exposes the
same authorization surface as sync `Guard`. Bundled three primitives —
all async siblings of existing sync code, all additive, all governed
by ADR-0012's mirror-not-redesign rule:

1. **FEAT-018** — `AsyncGuard.list_authorized` (async-native reverse-lookup
   primitive; OpenFGA `ListObjects` / Zanzibar `LookupResources` / AWS
   Verified Permissions `BatchIsAuthorized` shape).
2. **FEAT-014** — `AsyncDelegationEvaluator` + `AsyncDelegationManager` +
   delegation fallback in `AsyncGuard.authorize` +
   `AsyncGuard.authorize_and_consume` with CAS-safe usage decrement.
3. **FEAT-015** — `AsyncApprovalManager` + approval gating in
   `AsyncGuard.authorize` / `authorize_traced` + `AsyncGuard.approve` /
   `reject`. SHA-256 idempotency hashing reused from sync — mixed
   deployments collide deterministically.

Side-effect: `service/decision_router.py` dropped the
`if not is_async` guard. `POST /v1/list_authorized` and
`POST /v1/authorize_and_consume` are now engine-agnostic.
`SERVICE_API_VERSION` stays `"v1"`.

| Metric | Phase 10 baseline | Phase 11 final | Delta |
|--------|-------------------|----------------|-------|
| Tests passing | 1186 | 1235 | **+49** |
| Coverage | 93% | 93% | flat (at target) |
| Source files | — | +3 (async_delegation_evaluator, async_delegation_manager, async_approval_manager) | — |
| Test files | — | +4 (test_async_list_authorized, test_async_delegation, test_async_approval, test_integration_guide_phase11_examples) | — |
| ADRs | 0001–0010 | 0001–0012 | **+2** (0011 concurrency, 0012 mirror) |
| Optional extras | sql, sql-async, fastapi, mcp, cli, service, client, shield | unchanged | **0** |
| Breaking changes | — | 0 | — |

## What went well

### 1. Phase-7 port investment paid off immediately

Pre-phase code scan revealed that `AsyncCandidateResourcePort.fetch_candidates`
and `AsyncRelationshipStorePort.find_object_ids_for_subject` were already
in place from Phase 7. FEAT-018 collapsed from "new port + new method"
to just "new method on `AsyncGuard`" + a kwarg on `__init__`. Phase 7
shipped these ports anticipating async list_authorized would land
eventually; the option got exercised four phases later with zero
redesign. Lesson: build the port shape when the sync version ships,
even when no async consumer exists yet.

### 2. Mirror-not-redesign (ADR-0012) kept implementation linear

Every async sibling started from the matching sync file:
`delegation_evaluator.py` → `async_delegation_evaluator.py`,
`delegation_manager.py` → `async_delegation_manager.py`,
`approval_manager.py` → `async_approval_manager.py`. Pure helpers
(`_scopes_match`, `_extract_concrete_ids`, `_approver_allowed`,
`_quorum_met`) were imported from sync, never re-implemented. Result:
~1100 LOC of new async code, but ~30% of that is direct semantic
copies of sync paths with `await` substitution. Bug fixes to either
side flow through the shared helpers; the two surfaces cannot drift
silently.

### 3. The Phase 10 hack pointed at the right next step

The service-mode endpoint registered `POST /list_authorized` only for
sync guards (`decision_router.py:136`) because async didn't have the
method. That bifurcation was the visible smell that motivated the
phase. The fix landed as a one-line guard removal in Task 4 once
FEAT-018 / FEAT-014 shipped — and importantly, the SDK didn't change
at all, because the wire contract was already engine-agnostic in
shape; the server-side registration was the only sync-locked piece.

### 4. CAS safety transferred from sync verbatim

The Phase 5 delegation store ports document a `UPDATE WHERE` pattern
for `decrement_uses` / `decrement_budget`. `AsyncSQLAlchemyDelegationStore`
already implemented it. `AsyncDelegationManager.consume()` just awaits
the existing port method — no concurrency primitive was added at the
manager layer. The `asyncio.gather`-of-10 concurrent test passes with
`allowed_count <= max_uses` consistently because the in-memory store's
RLock + the asyncio single-threaded event loop serialize naturally;
the SQL backend's `UPDATE WHERE` would serialize at the database.

### 5. Approval idempotency works across the sync/async boundary

`ApprovalRequest.make_hash` is a classmethod on the entity, not a method
on either manager. `AsyncApprovalManager` imports `_approver_allowed`
and `_quorum_met` from `approval_manager.py`. A mixed deployment that
runs sync `Guard` in some processes and `AsyncGuard` in others, sharing
an approval store, sees deterministic collisions on the same
`(tenant, subject, action, resource)` key. No async-only hash function
exists — that would have been a quiet correctness footgun.

## What needed adjusting

### 1. Existing service tests asserted the sync-only behavior we just fixed

Four tests across `test_app_factory.py`, `test_decision_router.py`,
`test_integration_guide_phase10_examples.py`, and
`test_service_sql_e2e.py` asserted that AsyncGuard does NOT expose
`/list_authorized` and `/authorize_and_consume`. Each had to flip to
assert the endpoints DO register and DO return 200. Caught immediately
by regression after Task 4; not a quality issue, just contract
inversion. **Lesson:** when the assertion is "X does not work yet",
note in the test name that this is a temporary state so future you
remembers to invert it when the gap closes.

### 2. The factory-side `candidate_source` wiring path

`AsyncGuard.__init__` accepts `candidate_source` but the factory
`_build_async_memory_guard` only forwards `**kwargs` — initially I
modified the factory to pass `candidate_source=` explicitly, which
shadowed an undefined local. Reverted to the `**kwargs` forwarding
path; works correctly because the kwarg name matches. **Lesson:**
when extending an `**kwargs`-forwarding factory, just verify the
kwarg name matches — don't add a parameter unless you're transforming
it.

### 3. RBAC subject_match for tests

Wrote a series of tests with `subject_match={"id": "alice"}` expecting
RBAC to match by ID. RBAC's `_role_matches` only checks `roles`. The
sync delegation E2E tests use a custom mock evaluator to sidestep
this. For the Phase 11 tests I switched to `subject_match={"roles": ["owner"]}`
and attached `attributes={"roles": ["owner"]}` to the subject.
**Lesson:** RBAC is role-based, full stop; for subject-id matching use
ABAC.

### 4. `authorize_and_consume` exhaustion semantics

Initially tested that the 4th `authorize_and_consume` call (after
exhausting max_uses=3) would raise `UsageExhaustedError`. It doesn't —
because `authorize_and_consume` calls `consume` only on ALLOWED
decisions, and once the delegation is EXHAUSTED, the delegation
evaluator excludes it from `list_active_for_grantee`, so the decision
becomes DENIED and consume never fires. The test was corrected to
assert the DENIED state. **Note:** this is consistent sync behavior;
the test was just initially wrong.

### 5. test_imports.py version pin

`tests/test_imports.py` had a hard-coded version assertion
`open_guard.__version__ == "0.11.0"`. Bumping to 0.12.0 broke it.
Updated the assertion. **Lesson:** the existing assertion is fine for
catching accidental version regressions; it just costs one line to
update on each minor.

## Surprises (none material)

No bugs surfaced in shared sync helpers. No coverage cliffs in async
modules — adding 6 short tests to `test_async_delegation.py` for the
manager paths (meta-authz denial, narrowing failure, idempotent
return, renew unauthorized, unknown delegation, consume proxy) lifted
overall coverage from 92% to 93% (matched the target). `AsyncDelegationManager`
ended at 71% — the uncovered paths are approval-request-on-delegate
and `on_approval_resolved`, both of which are wired but exercise an
edge consumer path (delegate-with-requires-approval) that has no
sync test coverage either.

## Deferred (out of scope, on purpose)

- **Bounded `asyncio.gather` concurrency** for `AsyncGuard.list_authorized`
  — ADR-0011. Profile-driven optimization for a future ENH.
- **AsyncMCPGuard** — `MCPGuard.list_authorized_tools` now has the
  primitive it needs (`AsyncGuard.list_authorized`), but no async MCP
  consumer has surfaced. File when a real workload asks.
- **Reverse-ABAC query compilation** (ENH-014) — still deferred. Applies
  to both sync and async equally.
- **Per-result explainability** for `list_authorized` (ENH-016) — still
  deferred.
- **Zookie-style consistency tokens** (ENH-015) — still deferred.
- **Cascade revocation event emission** for descendants (ENH-018) —
  orthogonal item.
- **gRPC + TS/Go SDKs + MCP `/tools/check` endpoint** — Phase 12.

## What's locked

- **ADR-0011** — sequential per-candidate evaluation in
  `AsyncGuard.list_authorized`.
- **ADR-0012** — async siblings mirror sync; no async-only API changes
  introduced without first landing the same shape on sync.
- **Wire contract** unchanged: `SERVICE_API_VERSION = "v1"`. No new
  endpoints; the four decision endpoints register on both engines.
- **Optional extras** unchanged.
- **Mixed sync/async deployments** are first-class:
  `ApprovalRequest.make_hash` collisions are deterministic across
  engines.

## Open items for Phase 12

- gRPC service (proto schema, codegen, streaming considerations)
- TypeScript + Go SDKs once the Python wire contract has been validated
  by a real consumer
- MCP `/tools/check` endpoint behind the `[mcp]` extra
- SQL-backed `ApiKeyStore` if real deployments demand it

## Files

```
src/open_guard/
├── domain/services/
│   ├── async_guard.py                       # MODIFY — wired delegation fallback + approval gate + list_authorized + approve/reject
│   ├── async_delegation_evaluator.py        # NEW
│   ├── async_delegation_manager.py          # NEW
│   └── async_approval_manager.py            # NEW
└── service/
    └── decision_router.py                   # MODIFY — dropped if-not-is_async guard

specs/decisions/
├── 0011-async-list-authorized-concurrency.md  # NEW
├── 0012-async-parity-composition.md           # NEW
└── impact-map.json                            # MODIFY — new topics

specs/architecture/
├── auth-model.md                              # MODIFY — Async Surfaces section appended
└── integration-guide.md                       # MODIFY — Phase 11 section added

specs/phases/phase-11-async-parity/
├── overview.md, plan.md, tasks.md, history.md, retrospective.md

tests/
├── unit/test_async_list_authorized.py         # NEW — 13 tests
├── unit/test_async_delegation.py              # NEW — 17 tests
├── unit/test_async_approval.py                # NEW — 14 tests
├── integration/test_integration_guide_phase11_examples.py  # NEW — 4 tests
├── service/test_decision_router.py            # MODIFY — async endpoints assert 200
├── service/test_app_factory.py                # MODIFY — async endpoints register
├── e2e/test_service_sql_e2e.py                # MODIFY — async sql endpoints work
├── integration/test_integration_guide_phase10_examples.py  # MODIFY — same
└── test_imports.py                            # MODIFY — version bump

pyproject.toml                                 # MODIFY — version 0.11.0 → 0.12.0
src/open_guard/__init__.py                     # MODIFY — __version__ bumped
uv.lock                                        # MODIFY — regenerated
```
