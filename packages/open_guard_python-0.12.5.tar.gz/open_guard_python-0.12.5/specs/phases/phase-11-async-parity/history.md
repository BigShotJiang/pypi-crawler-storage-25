# Phase 11 — Async Parity: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [SCOPE_CHANGE] 2026-05-18 — Phase 11 repurposed from gRPC + non-Python SDKs to Async Parity
Topics: scope, phase-theme, roadmap, async-parity, feat-014, feat-015, feat-018
Affects-phases: phase-11-async-parity, phase-12-grpc-sdks (renumbered from prior Phase 11)
Affects-specs: specs/planning/roadmap.md, specs/status.md, specs/backlog/backlog.md
Detail: Original Phase 11 ("gRPC + non-Python SDKs") was unscheduled. Repurposed to "Async Parity" — bundles three sibling async-parity gaps into one minor release (v0.12.0): FEAT-018 (AsyncGuard.list_authorized, new), FEAT-014 (AsyncDelegationEvaluator + delegation fallback, promoted from P2 to P1 for the bundle), FEAT-015 (AsyncApprovalManager + approval gating + AsyncGuard.approve/reject, promoted from P2 to P1 for the bundle). gRPC + TS/Go SDKs + MCP /tools/check endpoint moved to Phase 12. Async parity is genuinely minor — every primitive has a sync ancestor whose semantics it mirrors; zero new ports, zero new entities, zero wire-contract changes. SERVICE_API_VERSION stays "v1". Triggered by realising the service mode `POST /list_authorized` endpoint silently disappears when the embedded guard is async (`service/decision_router.py:136`) and that the wire contract was bifurcating on engine choice.

---

### [DECISION] 2026-05-18 — Bundle three async-parity gaps into one minor phase
Topics: phase-scope, async-parity, release-strategy
Affects-phases: phase-11-async-parity
Affects-specs: specs/planning/roadmap.md
Detail: Considered shipping FEAT-018 alone as the truly-minor option. Decided to bundle FEAT-014 + FEAT-015 + FEAT-018 because (a) they share consumers (anyone on `AsyncGuard.from_config(dsn=...)`), (b) they share shape (async sibling of an existing sync primitive), (c) they share risk profile (additive, zero new abstractions, ports already in place from Phase 7), and (d) three separate minor releases would be churn for the same release notes. FEAT-014 and FEAT-015 are P2 in isolation but become P1 in aggregate with FEAT-018 — bundling promotes them for this phase only. Phase 11 is still "minor" in the meaningful sense: no new abstractions, no wire-contract change, no breaking change.

---

### [DECISION] 2026-05-18 — Mirror sync signatures and semantics exactly; no new abstractions
Topics: api-design, async-parity, adr-0012
Affects-phases: phase-11-async-parity
Affects-specs: specs/architecture/auth-model.md, specs/architecture/integration-guide.md
Detail: Each of the three async-parity gaps could have been an opportunity to redesign the sync surface. Decided against. Async siblings preserve sync signatures, return types, error semantics, and idempotency rules. Pure helpers (SHA-256 idempotency hashing, scope-narrowing validation, chain-depth checks, memoization keys) are shared, not re-implemented. Consequence: anyone reading sync docs can substitute `await` and have it work. The two surfaces evolve together going forward; a future redesign that touches both at once is fine, a unilateral async-only redesign is not. To be captured as ADR-0012.

---

### [DECISION] 2026-05-18 — Sequential per-candidate evaluation in AsyncGuard.list_authorized
Topics: async-list-authorized, concurrency, performance, adr-0011
Affects-phases: phase-11-async-parity
Affects-specs: specs/architecture/integration-guide.md
Detail: AsyncGuard.list_authorized iterates candidates sequentially via `await self.authorize(...)`, matching sync Guard.list_authorized semantics exactly. Bounded `gather(N)` is an obvious optimization but interacts with cursor stability, per-decision side effects (approval state, delegation consumption), and observability. Defer to a future ENH driven by profiling data, not by aesthetic. Sequential is the safe default; sync sets the bar. To be captured as ADR-0011.

---

### [DISCOVERY] 2026-05-18 — All async ports needed for FEAT-018 already exist from Phase 7
Topics: async-ports, candidate-resource, relationship-store, phase-7
Affects-phases: phase-11-async-parity
Affects-specs: none
Detail: Pre-phase code scan revealed that `AsyncCandidateResourcePort.fetch_candidates` (src/open_guard/domain/ports/async_candidate_resource.py) and `AsyncRelationshipStorePort.find_object_ids_for_subject` (src/open_guard/domain/ports/async_relationship_store.py:94) are both already in place. Phase 7 design anticipated the async list_authorized work. FEAT-018 is therefore smaller than the backlog detail doc framed it — just `AsyncGuard.list_authorized` itself plus a `candidate_source` kwarg on `AsyncGuard.__init__` plus factory wiring. No new public abstractions introduced by FEAT-018.

---

### [NOTE] 2026-05-18 — Cross-repo awareness: cerebrio ENH-088 picks this up on next dependency bump
Topics: cross-repo, cerebrio, downstream
Affects-phases: phase-11-async-parity
Affects-specs: none
Detail: cerebrio-sapience filed ENH-088 on its side for the consumer-side adapter, currently `hasattr`-guards `AsyncGuard.list_authorized` and returns `[]`. On v0.12.0 release, cerebrio picks this up by removing the guard — no cerebrio-side code change required beyond that. This is downstream awareness, NOT coordination required to complete Phase 11. open-guard ships the standard primitive; consumers consume it on their own schedule.

---

### [NOTE] 2026-05-18 — Phase 11 started
Topics: phase-start, in-progress
Affects-phases: phase-11-async-parity
Affects-specs: specs/status.md, specs/phases/README.md, specs/phases/index.json
Detail: Phase 11 (Async Parity) moved from "planned" to "in-progress" via `/start-phase`. Branch `phase-11-async-parity` active (two precursor commits already on the branch: FEAT-018 backlog tracking, then phase planning artifacts). Pre-flight checks clean — no P0 blockers, no unrelated P1 blockers, no cross-repo dependencies to verify (open-guard is standalone), no locked-evaluator setup needed (Phase 11 adds no new evaluator). Next: Task 1 — `AsyncGuard.list_authorized` (FEAT-018), the smallest and most self-contained item; all required async ports already exist from Phase 7.

---

### [FEATURE] 2026-05-18 — All 7 task groups complete
Topics: feat-014, feat-015, feat-018, implementation-complete, v0.12.0
Affects-phases: phase-11-async-parity
Affects-specs: specs/architecture/auth-model.md, specs/architecture/integration-guide.md
Detail: Tasks 1-7 shipped end-to-end. FEAT-018 (AsyncGuard.list_authorized — 13 tests), FEAT-014 (AsyncDelegationEvaluator + AsyncDelegationManager + delegation fallback + authorize_and_consume — 17 tests), FEAT-015 (AsyncApprovalManager + approval gating + approve/reject — 14 tests), service-mode unbundling (4 service tests flipped, 2 new tests), ADR-0011 + ADR-0012, integration-guide Phase 11 section + 4 executable mirror tests, auth-model.md "Async Surfaces" section added. Final regression: 1235 passed (+49 from Phase 10 baseline of 1186), 1 skipped, 93% coverage. Zero breaking changes. SERVICE_API_VERSION unchanged ("v1"). Version bumped to 0.12.0 in pyproject.toml, __init__.py, uv.lock.
