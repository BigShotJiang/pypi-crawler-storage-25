# Phases Index

> Quick reference for all phases. See [roadmap](../planning/roadmap.md) for timeline.

| Phase | Name | Status | Directory |
|-------|------|--------|-----------|
| 0 | RBAC + ABAC Core | Complete (v0.1.0) | [phase-0-rbac-core/](phase-0-rbac-core/) |
| 1 | TBAC (Time + Task) | Complete (v0.2.0) | [phase-1-tbac/](phase-1-tbac/) |
| 2 | ReBAC + SQLAlchemy + ABAC Enhancements | Complete (v0.3.0) | [phase-2-rebac/](phase-2-rebac/) |
| 3 | Agentic Core Contract (OBO chains + async approval + traces) | Complete (v0.4.0) | [phase-3-agentic-core/](phase-3-agentic-core/) |
| 4 | Agent Integration Surface (list_authorized + MCP adapter + integration guide) | Complete (v0.5.0) | [phase-4-agent-integration/](phase-4-agent-integration/) |
| 5 | Delegation & Bounds (push/pull delegation + usage caps + leases) | Complete (v0.6.0) | [phase-5-delegation-bounds/](phase-5-delegation-bounds/) |
| 6 | Production Hardening (Sessions, Policy Isolation & Push Revocation) | Complete (v0.7.0) | [phase-6-production-hardening/](phase-6-production-hardening/) |
| 7 | Consumer Integration (Factory, Admin SDK, REST API, Async, CLI) | Complete (v0.8.0) | [phase-7-consumer-integration/](phase-7-consumer-integration/) |
| 8 | AI-Era Primitives (TrustGate + OperationChain + ActorType) | Complete (v0.9.0) | [phase-8-ai-era-primitives/](phase-8-ai-era-primitives/) |
| 9 | Production Integration (Cerebrio P0 Blockers) | Complete (v0.10.0) | [phase-9-production-integration/](phase-9-production-integration/) |
| 10 | Service Mode + Python SDK | Complete (v0.11.0) | [phase-10-service-mode-sdk/](phase-10-service-mode-sdk/) |
| 11 | Async Parity (AsyncGuard.list_authorized + AsyncDelegationEvaluator + AsyncApprovalManager) | Complete (v0.12.0) | [phase-11-async-parity/](phase-11-async-parity/) |

## Phase Structure

Each phase directory contains exactly these files (no separate design docs):

| File | Purpose | Created By |
|------|---------|------------|
| `overview.md` | Goal, key decisions, source structure, scope, deliverables, acceptance criteria | `/brainstorm` |
| `plan.md` | Implementation approach with complete task breakdown and code | `/brainstorm` |
| `tasks.md` | Granular checklist `[ ]` / `[x]` mirroring plan.md tasks | `/brainstorm` |
| `history.md` | Append-only log of decisions, changes, discoveries | `/brainstorm` (initialized), ongoing |
| `retrospective.md` | Post-completion review | `/complete-phase` |

## Dependencies

```
Phase 0 (RBAC + ABAC Core)
  └── Phase 1 (TBAC)
       └── Phase 2 (ReBAC + SQLAlchemy + ABAC Enhancements)
            └── Phase 3 (Agentic Core Contract — OBO chains + async approval + traces)
                 └── Phase 4 (Agent Integration Surface)
                      └── Phase 5 (Delegation & Bounds)
                           └── Phase 6 (Production Hardening)
                                └── Phase 7 (Consumer Integration)
                          └── Phase 8 (AI-Era Primitives)
                               └── Phase 9 (Production Integration)
                                    └── Phase 10 (Service Mode + Python SDK)
                                         └── Phase 11 (Async Parity)
```
