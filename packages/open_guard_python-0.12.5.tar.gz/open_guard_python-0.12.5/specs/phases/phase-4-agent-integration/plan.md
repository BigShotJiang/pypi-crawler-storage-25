# Phase 4 — Agent Integration Surface: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use `superpowers:executing-plans` or `superpowers:subagent-driven-development` to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add `list_authorized()` and an MCP tool-call adapter on top of Phase 3's chain/approval/trace foundation, and rewrite `integration-guide.md` from stub to a full guide with executable examples. All additively — no v0.4.0 test is modified.

**Architecture (revised post-codebase-inspection 2026-04-18):** Open-guard is an **attribute-based hybrid engine** (ABAC with ReBAC tuples layered in), not a pattern-based engine. The industry-standard `list_authorized` pattern for hybrid engines is *iterate-per-candidate with full `authorize()`* (AWS Verified Permissions, Casbin `enforce_batch`) combined with *native graph enumeration* for any ReBAC tuples. Reverse-ABAC partial evaluation (Cerbos `PlanResources`, OPA partial eval) is a follow-up optimization — deferred to ENH-014. `Guard.list_authorized` collects candidate IDs from ReBAC tuples (via a new `RelationshipStorePort.find_object_ids_for_subject`) ∪ `CandidateResourcePort` (consumer-provided for ABAC-heavy deployments), then calls the existing `Guard.authorize()` per candidate. Composition matches `authorize()` **by construction** — no new semantics to test or reason about.

MCP adapter lives in `open_guard.adapters.mcp`; SDK-agnostic dict shapes in core, optional `[mcp]` extra binds to the MCP SDK. Chain flows through `MCPSessionResolver` → `Subject.on_behalf_of`.

**Tech Stack:** Python 3.12+, Pydantic v2, existing Phase 0-3 primitives. No new mandatory deps; MCP SDK behind optional `[mcp]` extra.

**Dependency changes:** Add `[project.optional-dependencies] mcp = ["mcp>=0.3"]` (or the SDK's current name at implementation time).

---

## Execution order

TDD throughout: write failing tests, then implementation, then run, then lint/typecheck. Each task ends with a commit when its tests pass.

```
Domain foundations      → T1 T2 T3
Guard.list_authorized   → T4
MCP adapter             → T5 T6 T7 T8 T9 T10
Integration tests       → T11 T12
Docs + ADRs             → T13 T14 T15
Release hygiene         → T16
```

---

## Task 1: `ListRequest`, `ListResult`, `Cursor` entities + opaque cursor codec

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Failing tests**

```python
from open_guard.domain.entities import ListRequest, ListResult, Cursor

class TestListPagination:
    def test_cursor_roundtrip(self) -> None:
        c = Cursor(rebac_offset=50, seen_ids={"a", "b"})
        token = c.encode()
        decoded = Cursor.decode(token)
        assert decoded.rebac_offset == 50
        assert decoded.seen_ids == {"a", "b"}

    def test_empty_cursor(self) -> None:
        assert Cursor().is_empty() is True

    def test_list_request_defaults(self) -> None:
        r = ListRequest(
            subject_id="u1", action="read",
            resource_type="doc", tenant_id="t1",
        )
        assert r.limit == 100
        assert r.cursor is None

    def test_list_result_has_more(self) -> None:
        assert ListResult(ids=["a"], next_cursor="x").has_more() is True
        assert ListResult(ids=["a"], next_cursor=None).has_more() is False

    def test_cursor_decode_invalid_token_raises(self) -> None:
        with pytest.raises(ValueError):
            Cursor.decode("not-base64-json")
```

- [ ] **Step 2: Implement**

```python
import base64
import json

class Cursor(Entity):
    """Opaque pagination cursor for list_authorized.

    Encodes continuation state: offset into ReBAC tuple enumeration,
    offset into candidate source, and the set of IDs already returned.
    Stability under concurrent policy changes is undefined.
    """
    rebac_offset: int = 0
    candidate_cursor: dict[str, Any] = Field(default_factory=dict)
    seen_ids: set[str] = Field(default_factory=set)

    def encode(self) -> str:
        payload = {
            "r": self.rebac_offset,
            "c": self.candidate_cursor,
            "s": sorted(self.seen_ids),
        }
        return base64.urlsafe_b64encode(
            json.dumps(payload, separators=(",", ":")).encode()
        ).decode()

    @classmethod
    def decode(cls, token: str) -> Cursor:
        try:
            raw = json.loads(base64.urlsafe_b64decode(token.encode()).decode())
        except (ValueError, json.JSONDecodeError) as exc:
            raise ValueError(f"invalid cursor token: {exc}") from exc
        return cls(
            rebac_offset=raw.get("r", 0),
            candidate_cursor=raw.get("c", {}),
            seen_ids=set(raw.get("s", [])),
        )

    def is_empty(self) -> bool:
        return (
            self.rebac_offset == 0
            and not self.candidate_cursor
            and not self.seen_ids
        )


class ListRequest(Entity):
    subject_id: str
    action: str
    resource_type: str
    tenant_id: str
    prefilter: dict[str, Any] | None = None
    limit: int = 100
    cursor: Cursor | None = None


class ListResult(Entity):
    ids: list[str]
    next_cursor: str | None = None

    def has_more(self) -> bool:
        return self.next_cursor is not None
```

- [ ] **Step 3: Run tests + lint**

```bash
uv run pytest tests/unit/domain/test_entities.py -v -k "list or cursor"
uv run ruff check src/ tests/
uv run mypy --strict src/
```

- [ ] **Step 4: Commit**

`feat(domain): add ListRequest/ListResult/Cursor pagination entities for list_authorized`

---

## Task 2: `CandidateResourcePort` abstract port

**Files:**
- New: `src/open_guard/domain/ports/candidate_resource.py`
- New: `tests/unit/domain/ports/__init__.py` (if missing)
- New: `tests/unit/domain/ports/test_candidate_resource.py`

- [ ] **Step 1: Failing tests**

In-memory fixture test:

```python
class InMemoryCandidateSource(CandidateResourcePort):
    def __init__(self, resources: dict[tuple[str, str], list[Resource]]) -> None:
        # key is (tenant_id, resource_type)
        self._resources = resources

    def fetch_candidates(
        self, resource_type, tenant_id, prefilter, cursor, limit,
    ) -> tuple[list[Resource], dict | None]:
        all_items = self._resources.get((tenant_id, resource_type), [])
        if prefilter:
            all_items = [
                r for r in all_items
                if all(r.attributes.get(k) == v for k, v in prefilter.items())
            ]
        offset = (cursor or {}).get("offset", 0)
        slice_ = all_items[offset:offset + limit]
        next_cursor = (
            {"offset": offset + limit}
            if offset + limit < len(all_items) else None
        )
        return slice_, next_cursor


class TestCandidateResourcePort:
    def test_fetches_candidates_for_tenant_and_type(self) -> None: ...
    def test_pagination_via_cursor(self) -> None: ...
    def test_prefilter_applied(self) -> None: ...
    def test_cross_tenant_isolation(self) -> None: ...
```

- [ ] **Step 2: Implement**

```python
from abc import ABC, abstractmethod
from typing import Any

from open_guard.domain.entities import Resource


class CandidateResourcePort(ABC):
    """Produces candidate resources for list_authorized iteration.

    Consumers implement this for resource types that open-guard needs to
    enumerate over — typically in ABAC-heavy deployments where no ReBAC
    tuples exist to drive native enumeration.

    The cursor is opaque to open-guard — implementations choose their own
    continuation shape (offset, token, etc.).
    """

    @abstractmethod
    def fetch_candidates(
        self,
        resource_type: str,
        tenant_id: str,
        prefilter: dict[str, Any] | None,
        cursor: dict[str, Any] | None,
        limit: int,
    ) -> tuple[list[Resource], dict[str, Any] | None]:
        """Return ``(candidates, next_cursor)``. ``next_cursor`` is None
        when the source is exhausted.
        """
```

- [ ] **Step 3-4:** Run + commit `feat(ports): add CandidateResourcePort for ABAC iteration in list_authorized`

---

## Task 3: `RelationshipStorePort.find_object_ids_for_subject` + ReBAC native enumeration

**Files:**
- Modify: `src/open_guard/domain/ports/relationship_store.py`
- Modify: `src/open_guard/adapters/stores/memory_relationship.py`
- Modify: `src/open_guard/adapters/stores/sql_relationship.py`
- Modify: `tests/unit/adapters/stores/test_memory_relationship.py`
- Modify: `tests/unit/adapters/stores/test_sql_relationship.py`

- [ ] **Step 1: Failing tests** (for both memory + SQL)

```python
def test_find_object_ids_direct_relation(self, store) -> None:
    store.create_tuple(RelationTuple(
        object_type="doc", object_id="1", relation="owner",
        subject_id="alice", tenant_id="t1"))
    store.create_tuple(RelationTuple(
        object_type="doc", object_id="2", relation="viewer",
        subject_id="alice", tenant_id="t1"))
    ids = store.find_object_ids_for_subject(
        subject_id="alice", subject_type="user",
        object_type="doc", tenant_id="t1",
        offset=0, limit=100,
    )
    assert set(ids) == {"1", "2"}

def test_find_object_ids_pagination(self, store) -> None: ...

def test_find_object_ids_cross_tenant_isolation(self, store) -> None: ...

def test_find_object_ids_empty_when_no_tuples(self, store) -> None:
    assert store.find_object_ids_for_subject(
        "ghost", "user", "doc", "t1", 0, 100) == []
```

- [ ] **Step 2: Implement — port + both stores**

Port:
```python
@abstractmethod
def find_object_ids_for_subject(
    self,
    subject_id: str,
    subject_type: str,
    object_type: str,
    tenant_id: str,
    offset: int,
    limit: int,
) -> list[str]:
    """Return object IDs of the given type where the subject appears
    in any relation tuple (direct relation only — computed permissions
    are resolved at evaluate time against this candidate superset).
    Sorted by (object_id) for deterministic pagination.
    """
```

InMemory: filter `self._tuples` by tenant_id, subject_id, subject_type, object_type; dedupe object_ids; sort; slice.

SQLAlchemy: SELECT DISTINCT object_id FROM relation_tuples WHERE tenant_id=:t AND subject_id=:s AND subject_type=:st AND object_type=:ot ORDER BY object_id OFFSET :o LIMIT :l.

- [ ] **Step 3-4:** Run + commit `feat(rebac): RelationshipStorePort.find_object_ids_for_subject for list_authorized native enumeration`

---

## Task 4: `Guard.list_authorized` — candidate pool + iterate-per-candidate + authorize

**Files:**
- Modify: `src/open_guard/domain/services/guard.py`
- New: `tests/unit/domain/services/test_guard_list.py`

- [ ] **Step 1: Failing tests**

```python
class TestGuardListAuthorized:
    def test_rebac_native_enumeration_no_candidate_source_needed(self) -> None:
        """If only ReBAC tuples grant access, list works without a source."""
        store = InMemoryRelationshipStore()
        store.create_tuple(RelationTuple(
            object_type="doc", object_id="1", relation="owner",
            subject_id="alice", tenant_id="t1"))
        ...
        result = guard.list_authorized(alice, "read", "doc", tenant_id="t1")
        assert result.ids == ["1"]

    def test_abac_requires_candidate_source(self) -> None:
        """ABAC-only policies + no source → empty result (not an error)."""
        ...

    def test_abac_with_candidate_source_iterates(self) -> None: ...

    def test_rebac_and_abac_union(self) -> None:
        """Candidates come from both ReBAC tuples AND candidate source;
        dedupe by ID; authorize filters both."""
        ...

    def test_deny_policy_removes_from_result(self) -> None: ...

    def test_authorize_per_candidate_honors_chain(self) -> None: ...

    def test_authorize_per_candidate_honors_approval_pending(self) -> None:
        """Pending approval → resource excluded from list (not allowed yet)."""
        ...

    def test_pagination_cursor(self) -> None: ...

    def test_tenant_isolation(self) -> None: ...

    def test_max_chain_depth_enforced(self) -> None: ...

    def test_limit_zero_returns_empty(self) -> None: ...

    def test_resource_construction_honors_prefilter(self) -> None:
        """Prefilter is passed to candidate source; resources from ReBAC
        are built with minimal attrs {resource_type, id, tenant_id}."""
        ...
```

- [ ] **Step 2: Implement**

```python
def list_authorized(
    self,
    subject: Subject,
    action: str,
    resource_type: str,
    tenant_id: str,
    prefilter: dict[str, Any] | None = None,
    limit: int = 100,
    cursor: str | None = None,
    candidate_source: CandidateResourcePort | None = None,
    relationship_store: RelationshipStorePort | None = None,
) -> ListResult:
    self._validate_chain_depth(subject)
    cur = Cursor.decode(cursor) if cursor else Cursor()

    allow_ids: list[str] = []
    seen: set[str] = set(cur.seen_ids)
    action_obj = Action(name=action)

    # 1. ReBAC native enumeration (cheap when tuples exist)
    rebac_offset = cur.rebac_offset
    if relationship_store is not None:
        while len(allow_ids) < limit:
            batch = relationship_store.find_object_ids_for_subject(
                subject_id=subject.id, subject_type=subject.actor_type.value,
                object_type=resource_type, tenant_id=tenant_id,
                offset=rebac_offset, limit=max(limit * 2, 50),
            )
            if not batch:
                break
            for obj_id in batch:
                if obj_id in seen:
                    continue
                seen.add(obj_id)
                resource = Resource(
                    id=obj_id, resource_type=resource_type,
                    tenant_id=tenant_id,
                )
                decision = self.authorize(
                    subject, action_obj, resource, tenant_id)
                if decision.status == DecisionStatus.ALLOWED:
                    allow_ids.append(obj_id)
                    if len(allow_ids) >= limit:
                        break
            rebac_offset += len(batch)
            if len(batch) < max(limit * 2, 50):
                break  # exhausted

    # 2. External candidate source (for ABAC/RBAC-driven resources)
    source_cursor = cur.candidate_cursor or None
    source_exhausted = candidate_source is None
    while len(allow_ids) < limit and not source_exhausted:
        candidates, next_source_cursor = candidate_source.fetch_candidates(
            resource_type=resource_type, tenant_id=tenant_id,
            prefilter=prefilter, cursor=source_cursor,
            limit=max(limit * 2, 50),
        )
        if not candidates:
            source_exhausted = True
            break
        for resource in candidates:
            if resource.id in seen:
                continue
            seen.add(resource.id)
            decision = self.authorize(
                subject, action_obj, resource, tenant_id)
            if decision.status == DecisionStatus.ALLOWED:
                allow_ids.append(resource.id)
                if len(allow_ids) >= limit:
                    break
        if next_source_cursor is None:
            source_exhausted = True
            break
        source_cursor = next_source_cursor

    # 3. Build continuation cursor if exhaustion isn't complete
    has_more = len(allow_ids) >= limit and not (
        source_exhausted and rebac_offset == cur.rebac_offset
    )
    next_cursor_token: str | None = None
    if has_more:
        next_cursor_token = Cursor(
            rebac_offset=rebac_offset,
            candidate_cursor=source_cursor or {},
            seen_ids=seen,
        ).encode()
    return ListResult(ids=allow_ids, next_cursor=next_cursor_token)
```

**Design notes:**
- Composition = identical to `authorize()` by construction (we literally call it)
- `relationship_store` and `candidate_source` are optional — at least one must be set for results
- ReBAC tuples naturally carry tenant isolation; external source trusted to honor it
- `Decision(status=PENDING_APPROVAL)` is excluded from the list (it's not allowed yet)
- Chain depth validated up front (same as `authorize`)

Also update `Guard.__init__` to accept optional `candidate_source` and `relationship_store` keyword-only args so they can be wired once at construction rather than passed per call (preferred) — and per-call override is still supported.

- [ ] **Step 3-4:** Run + commit `feat(guard): list_authorized via ReBAC native enumeration + candidate source + authorize-per-candidate`

---

## Task 5: `open_guard.adapters.mcp` package + entities

**Files:**
- New: `src/open_guard/adapters/mcp/__init__.py`
- New: `src/open_guard/adapters/mcp/entities.py`
- New: `tests/unit/adapters/mcp/__init__.py`
- New: `tests/unit/adapters/mcp/test_entities.py`

- [ ] **Step 1: Failing tests**

```python
def test_mcp_tool_request_shape() -> None:
    req = MCPToolRequest(
        session_id="sess-1", tool_name="query_db", server_id="prod",
        params={"table": "users"}, claims={"sub": "agent-a"},
    )
    assert req.tool_name == "query_db"

def test_mcp_authorization_result_allow() -> None:
    r = MCPAuthorizationResult(status="allow", reason="matched p1")
    assert r.is_allowed() is True
    assert r.is_pending() is False

def test_mcp_authorization_result_pending_carries_metadata() -> None:
    r = MCPAuthorizationResult(
        status="pending",
        pending=MCPAuthorizationPending(
            approval_request_id="req-1",
            approvers=["alice"], quorum="any",
            channel="slack", ttl_seconds=300,
        ),
    )
    assert r.is_pending() is True
    assert r.pending.approval_request_id == "req-1"

def test_mcp_authorization_result_deny() -> None: ...
```

- [ ] **Step 2: Implement**

```python
from typing import Literal

class MCPToolRequest(Entity):
    session_id: str
    server_id: str
    tool_name: str
    params: dict[str, Any] = Field(default_factory=dict)
    claims: dict[str, Any] = Field(default_factory=dict)

class MCPToolResponse(Entity):
    content: Any
    is_error: bool = False

class MCPAuthorizationPending(Entity):
    approval_request_id: str
    approvers: list[str]
    quorum: str | int
    channel: str | None = None
    ttl_seconds: int | None = None

class MCPAuthorizationResult(Entity):
    status: Literal["allow", "deny", "pending"]
    reason: str | None = None
    pending: MCPAuthorizationPending | None = None

    def is_allowed(self) -> bool:
        return self.status == "allow"
    def is_pending(self) -> bool:
        return self.status == "pending"
    def is_denied(self) -> bool:
        return self.status == "deny"
```

- [ ] **Step 3-4:** Run + commit `feat(mcp): scaffold MCP adapter package with SDK-agnostic entities`

---

## Task 6: `MCPSessionResolver` protocol + `MCPGuard` constructor

**Files:**
- New: `src/open_guard/adapters/mcp/resolver.py`
- New: `src/open_guard/adapters/mcp/guard.py`
- New: `tests/unit/adapters/mcp/test_resolver.py`
- New: `tests/unit/adapters/mcp/test_guard.py`

- [ ] **Step 1: Failing tests**

```python
class TestMCPSessionResolver:
    def test_resolver_can_return_subject_with_chain(self) -> None:
        class MyResolver(MCPSessionResolver):
            def resolve(self, session_id, claims):
                return Subject(
                    id="agent-r", actor_type=ActorType.AGENT,
                    on_behalf_of=Subject(id="alice", actor_type=ActorType.USER),
                )
        s = MyResolver().resolve("sess-1", {})
        assert s.on_behalf_of.id == "alice"


class TestMCPGuardConstruction:
    def test_mcp_guard_default_namespace(self) -> None:
        mcp = MCPGuard(guard=guard, resolver=resolver, default_tenant_id="t1")
        assert mcp.resource_namespace == "tool:{server_id}:{tool_name}"

    def test_mcp_guard_custom_namespace(self) -> None: ...

    def test_make_resource_id(self) -> None: ...
```

- [ ] **Step 2: Implement**

```python
from typing import Protocol

class MCPSessionResolver(Protocol):
    """Consumer-provided: map MCP session claims to a Subject (with chain)."""
    def resolve(
        self, session_id: str, claims: dict[str, Any],
    ) -> Subject: ...


class MCPGuard:
    def __init__(
        self,
        guard: Guard,
        resolver: MCPSessionResolver,
        default_tenant_id: str,
        resource_namespace: str = "tool:{server_id}:{tool_name}",
    ) -> None:
        self._guard = guard
        self._resolver = resolver
        self._default_tenant_id = default_tenant_id
        self.resource_namespace = resource_namespace

    def _make_resource_id(self, server_id: str, tool_name: str) -> str:
        return self.resource_namespace.format(
            server_id=server_id, tool_name=tool_name)

    def _infer_tenant(
        self, claims: dict[str, Any] | None,
    ) -> str:
        return (claims or {}).get("tenant_id") or self._default_tenant_id
```

- [ ] **Step 3-4:** Run + commit `feat(mcp): MCPSessionResolver protocol + MCPGuard constructor`

---

## Task 7: `MCPGuard.check_tool_call` (schema hygiene → authz → decision mapping)

**Files:**
- Modify: `src/open_guard/adapters/mcp/guard.py`
- Extend: `tests/unit/adapters/mcp/test_guard.py`

- [ ] **Step 1: Failing tests**

```python
def test_check_tool_call_allow(self) -> None: ...
def test_check_tool_call_deny(self) -> None: ...
def test_check_tool_call_pending_approval(self) -> None: ...
def test_check_tool_call_schema_violation_blocks_before_authz(self) -> None:
    """Missing required param → deny with schema_violation reason;
    underlying guard.authorize NOT invoked."""
def test_check_tool_call_traced_returns_trace(self) -> None: ...
```

- [ ] **Step 2: Implement**

```python
def check_tool_call(
    self,
    session_id: str,
    tool_name: str,
    params: dict[str, Any],
    server_id: str,
    tool_schema: dict[str, Any] | None = None,
    claims: dict[str, Any] | None = None,
) -> MCPAuthorizationResult:
    if tool_schema is not None:
        err = self._validate_schema(params, tool_schema)
        if err:
            return MCPAuthorizationResult(
                status="deny", reason=f"schema_violation:{err}")
    subject = self._resolver.resolve(session_id, claims or {})
    tenant_id = self._infer_tenant(claims)
    resource = Resource(
        id=self._make_resource_id(server_id, tool_name),
        resource_type="tool",
        tenant_id=tenant_id,
        attributes={
            "params": params,
            "server_id": server_id,
            "tool_name": tool_name,
        },
    )
    decision = self._guard.authorize(
        subject, Action(name="invoke"), resource, tenant_id)
    return self._map_decision(decision)


def check_tool_call_traced(
    self, session_id, tool_name, params, server_id,
    tool_schema=None, claims=None,
) -> tuple[MCPAuthorizationResult, DecisionTrace | None]:
    # Same as above but calls guard.authorize_traced; schema violations
    # return (result, None).
    ...


def _validate_schema(self, params, schema) -> str | None:
    """Minimal structural check: required fields present, basic type match."""
    required = schema.get("required", [])
    for field in required:
        if field not in params:
            return f"missing required field '{field}'"
    properties = schema.get("properties", {})
    for field, spec in properties.items():
        if field not in params:
            continue
        expected_type = spec.get("type")
        if expected_type and not self._type_matches(
                params[field], expected_type):
            return f"field '{field}' has wrong type"
    return None


def _map_decision(self, decision: Decision) -> MCPAuthorizationResult:
    if decision.status == DecisionStatus.ALLOWED:
        return MCPAuthorizationResult(status="allow", reason=decision.reason)
    if decision.status == DecisionStatus.DENIED:
        return MCPAuthorizationResult(status="deny", reason=decision.reason)
    # PENDING
    req = decision.approval_requirement
    return MCPAuthorizationResult(
        status="pending",
        reason=decision.reason,
        pending=MCPAuthorizationPending(
            approval_request_id=decision.approval_request_id,
            approvers=req.approvers if req else [],
            quorum=req.quorum if req else "any",
            channel=req.channel if req else None,
            ttl_seconds=int(req.ttl.total_seconds())
                if req and req.ttl else None,
        ),
    )
```

- [ ] **Step 3-4:** Run + commit `feat(mcp): MCPGuard.check_tool_call with schema hygiene, chain, pending flow`

---

## Task 8: Parameter-level ABAC (dot-path params)

**Files:**
- Extend: `tests/unit/adapters/mcp/test_guard.py` (or new `test_guard_params.py`)

The ABAC evaluator already resolves dot-paths against `resource.attributes`. Because T7 puts `params` under `resource.attributes["params"]`, policies like `{"params.query": {"not_regex": "DROP"}}` already work. This task ADDS TESTS that prove the end-to-end hookup and documents the convention.

- [ ] **Step 1: Failing tests**

```python
def test_param_level_abac_blocks_destructive_query(self) -> None:
    policy = Policy(
        tenant_id="t1", evaluator_type="abac",
        subject_match={"roles": ["researcher"]},
        action_match="invoke",
        resource_match={"tool_name": "query_db"},
        conditions={
            "attribute_path": "params.query",
            "operator": "not_regex",
            "value": r"(?i)\\b(DROP|DELETE|TRUNCATE)\\b",
        },
    )
    ...
    # DROP → deny
    # SELECT → allow

def test_param_level_abac_nested_path(self) -> None:
    """conditions on params.options.safe == True."""

def test_param_level_abac_set_operator_is_subset(self) -> None:
    """conditions on params.tables is_subset of allowlist."""
```

No production code change expected — if tests fail, fix T7 to ensure params are faithfully embedded.

- [ ] **Step 3-4:** Run + commit `test(mcp): parameter-level ABAC via dot-path resource attributes`

---

## Task 9: `MCPGuard.list_authorized_tools` — filtered tool discovery

**Files:**
- Modify: `src/open_guard/adapters/mcp/guard.py`
- Extend: `tests/unit/adapters/mcp/test_guard.py`

- [ ] **Step 1: Failing tests**

```python
def test_list_authorized_tools_returns_ids_subject_can_invoke(self) -> None:
    """Researcher role: list returns tool:prod:query_db, tool:prod:read_file."""

def test_list_authorized_tools_server_filter(self) -> None: ...

def test_list_authorized_tools_respects_chain(self) -> None: ...
```

- [ ] **Step 2: Implement**

```python
def list_authorized_tools(
    self,
    session_id: str,
    server_id: str | None = None,
    limit: int = 100,
    cursor: str | None = None,
    claims: dict[str, Any] | None = None,
) -> ListResult:
    subject = self._resolver.resolve(session_id, claims or {})
    prefilter = {"server_id": server_id} if server_id else None
    tenant_id = self._infer_tenant(claims)
    return self._guard.list_authorized(
        subject=subject, action="invoke", resource_type="tool",
        tenant_id=tenant_id, prefilter=prefilter,
        limit=limit, cursor=cursor,
    )
```

Enumerating tools requires a `CandidateResourcePort` that returns tool resources — discovery is not native to open-guard. The integration guide documents how to build one.

- [ ] **Step 3-4:** Run + commit `feat(mcp): list_authorized_tools wraps Guard.list_authorized for filtered discovery`

---

## Task 10: Optional `[mcp]` extra — thin binding to MCP SDK

**Files:**
- Modify: `pyproject.toml` — add `[project.optional-dependencies] mcp = ["mcp>=0.3"]`
- New: `src/open_guard/adapters/mcp/sdk.py`
- New: `tests/unit/adapters/mcp/test_sdk_binding.py`

- [ ] **Step 1: Failing tests** (gated via `importorskip`)

```python
import pytest
pytest.importorskip("mcp")

def test_from_sdk_call_tool_request_converts(self) -> None:
    from mcp.types import CallToolRequest
    from open_guard.adapters.mcp.sdk import from_sdk_call_request
    sdk_req = CallToolRequest(name="query_db", arguments={"table": "users"})
    req = from_sdk_call_request(sdk_req, session_id="s1", server_id="prod")
    assert req.tool_name == "query_db"
    assert req.params["table"] == "users"

def test_to_sdk_response_allow(self) -> None: ...
def test_import_without_sdk_raises_clear_error(self, monkeypatch) -> None: ...
```

- [ ] **Step 2: Implement**

```python
try:
    import mcp.types as _mcp_types  # type: ignore
except ImportError:  # pragma: no cover
    _mcp_types = None

def _require_sdk() -> None:
    if _mcp_types is None:
        raise ImportError(
            "python-mcp-sdk is not installed. "
            "Install with: pip install 'open-guard[mcp]'"
        )

def from_sdk_call_request(
    sdk_request, *, session_id: str, server_id: str,
    claims: dict[str, Any] | None = None,
) -> MCPToolRequest:
    _require_sdk()
    return MCPToolRequest(
        session_id=session_id, server_id=server_id,
        tool_name=sdk_request.name,
        params=dict(sdk_request.arguments or {}),
        claims=claims or {},
    )

def to_sdk_response(result: MCPAuthorizationResult): ...
```

If the MCP SDK isn't installable in CI, mark this task "deferred to retrospective" and skip the binding — the core is useful on its own.

- [ ] **Step 3-4:** Run + commit `feat(mcp): optional [mcp] extra with SDK thin binding`

---

## Task 11: Integration — `tests/integration/test_list_authorized.py`

**Files:** New: `tests/integration/test_list_authorized.py`

- [ ] **Cases:**
  - ReBAC-only: list from tuples, no source needed
  - ABAC-only: list via `CandidateResourcePort`, denies filter correctly
  - Combined: ReBAC tuples ∪ candidate source, dedupe, unified authorize
  - Explicit DENY policy removes IDs
  - Chain-scoped list: agent `on_behalf_of` user, ABAC `chain.root_actor.attributes.department` narrows
  - Pagination across two calls
  - Pending-approval: resource with `requires_approval` policy excluded from list
  - Tenant isolation: two tenants cannot see each other's IDs

- [ ] Commit: `test(integration): end-to-end list_authorized scenarios`

---

## Task 12: Integration — `tests/integration/test_mcp_adapter.py`

**Files:** New: `tests/integration/test_mcp_adapter.py`

- [ ] **Cases:**
  - Allow / Deny paths
  - Destructive query blocked by ABAC `params.query` regex
  - Pending → approve → subsequent call allow
  - Chain: resolver builds `Subject(on_behalf_of=...)`, chain predicates evaluated
  - Schema hygiene: missing param → deny before policy eval (mock underlying `guard.authorize` to assert not called)
  - `list_authorized_tools` across two servers + per-server filter
  - `check_tool_call_traced` returns populated trace with tool as resource

- [ ] Commit: `test(integration): end-to-end MCP adapter flows`

---

## Task 13: Rewrite `specs/architecture/integration-guide.md` (TD-001)

**Files:** Rewrite: `specs/architecture/integration-guide.md`

- [ ] **Sections (all with runnable examples):**

1. Overview
2. Quick Start (10 lines)
3. Phase 0 — RBAC + ABAC basics
4. Phase 0 — FastAPI integration
5. Phase 1 — TBAC (time windows, schedules, tasks)
6. Phase 2 — ReBAC + SQLAlchemy stores
7. Phase 3 — OBO chains + `authorize_traced` + async approval
8. Phase 4 — `list_authorized` (with `CandidateResourcePort` example)
9. Phase 4 — MCP adapter
10. End-to-end RAG walk-through (ReBAC tuples → `list_authorized` → hydrate)
11. End-to-end MCP walk-through (session → chain → per-param ABAC → pending)

- [ ] Every code block is executable in T14.
- [ ] Commit: `docs(integration-guide): full rewrite with runnable examples (TD-001)`

---

## Task 14: Mirror every guide example as an executable test

**Files:** New: `tests/integration/test_integration_guide_examples.py`

- [ ] One `test_guide_<section>()` per guide code block; test runs the snippet and asserts the documented outcome.
- [ ] Commit: `test(integration-guide): every guide snippet is an executable integration test`

---

## Task 15: ADR-0001 (list composition) + ADR-0002 (MCP design)

**Files:**
- New: `specs/decisions/0001-list-authorized-composition.md`
- New: `specs/decisions/0002-mcp-adapter-design.md`

- [ ] **ADR-0001 must cover:**
  - Context: RAG use case + industry prior art (OpenFGA, SpiceDB, AWS VP, Cerbos, OPA, Casbin)
  - Options evaluated: pure graph walk (ReBAC-only), iterate-per-candidate (VP/Casbin), partial evaluation (Cerbos/OPA), pattern-based enumeration
  - **Chosen**: ReBAC native enumeration + `CandidateResourcePort` + iterate-per-candidate via `authorize()` — matches AWS Verified Permissions / Casbin `enforce_batch` pattern
  - Composition = authorize() by construction
  - Reverse-ABAC partial evaluation (Cerbos `PlanResources`) deferred to ENH-014
  - Cursor opacity + undefined stability (zookies deferred via ENH-015)
  - Why not per-evaluator `list_authorized` method: open-guard policies are attribute-based, not pattern-based, so there's nothing for individual evaluators to enumerate *from* — only ReBAC tuples carry IDs, and those live in the store layer not the evaluator layer

- [ ] **ADR-0002 must cover:** same as before — MCP SDK strategy, namespace, param paths, chain, schema hygiene

- [ ] Commit: `docs(adr): ADR-0001 list_authorized + ADR-0002 MCP adapter`

---

## Task 16: Release hygiene

**Files:**
- Modify: `src/open_guard/__init__.py`
- Modify: `pyproject.toml`
- Modify: `specs/changelog/2026-04.md`

- [ ] New public exports: `ListRequest`, `ListResult`, `Cursor`, `CandidateResourcePort`, `MCPGuard`, `MCPSessionResolver`, `MCPToolRequest`, `MCPToolResponse`, `MCPAuthorizationResult`, `MCPAuthorizationPending`
- [ ] Version bump to `0.5.0` in `pyproject.toml` + `__init__.py`
- [ ] Declare `[mcp]` optional extra in `pyproject.toml`
- [ ] Append changelog section for v0.5.0
- [ ] Suite gate:

```bash
uv run pytest -v --cov=open_guard --cov-report=term-missing  # ≥ 95%
uv run mypy --strict src/
uv run ruff check src/ tests/
```

- [ ] Commit: `release: v0.5.0 — Phase 4 Agent Integration Surface`

---

## Phase close (outside task execution)

- Draft `retrospective.md`
- Run `/sync-docs`
- `/complete-phase`

---

## Rollback / abort

- If ReBAC `find_object_ids_for_subject` has unacceptable latency on realistic tuple counts (>100k): add an optional ReBAC list cap + document; don't block release.
- If MCP SDK is unstable at implementation time: ship core adapter, skip T10 SDK binding; file as ENH.
- TD-001 (T13-T14) too large to land: ship T13 as a stub-backfill with Phase 0-3 examples and a "Phase 4 examples coming in v0.5.1" note; track remaining work as a Phase 4+ task.

---

## Test targets

| Metric | Baseline (v0.4.0) | Phase 4 target (v0.5.0) | Floor |
|--------|-------------------|--------------------------|-------|
| Tests | 406 | 490-510 | ≥ 460 |
| Coverage | 98% | maintain 98% | ≥ 95% |
| mypy --strict | clean | clean | clean |
| ruff | clean | clean | clean |
| Breaking changes | 0 | 0 | 0 |
