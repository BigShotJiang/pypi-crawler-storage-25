# Phase 4 — Agent Integration Surface: Retrospective

> Completed 2026-04-18. Released as v0.5.0.

## Headline metrics

| Metric | Baseline (v0.4.0) | Phase 4 (v0.5.0) | Delta |
|--------|-------------------|-------------------|-------|
| Tests | 406 | 505 | +99 |
| Coverage | 98% | 97% | -1 pt |
| Source files (src/) | 35 | 41 | +6 |
| ADRs written | 0 | 2 | +2 (first ADRs in repo) |
| Breaking changes | — | **0** | — |
| mypy --strict | clean | clean | — |
| ruff | clean | clean | — |
| Tasks planned → executed | 21 → 16 (pivot) → 16 | 100% | — |
| Effort (planned → actual) | 4-5 days | ~1 session | ahead of estimate |

## What shipped

- **FEAT-006 — `Guard.list_authorized()`**: industry-standard hybrid pattern (AWS Verified Permissions / Casbin `enforce_batch`). ReBAC native enumeration via new `RelationshipStorePort.find_object_ids_for_subject` (memory + SQL); consumer-provided `CandidateResourcePort` for ABAC / RBAC-driven resources; iterate-per-candidate via `Guard.authorize()` for composition identical to the standard authz call. Cursor pagination is opaque base64-JSON; cursor stability under concurrent policy changes documented as undefined (zookies deferred to ENH-015). New entities: `ListRequest`, `ListResult`, `Cursor`.
- **FEAT-009 — MCP tool-call adapter**: `open_guard.adapters.mcp.MCPGuard` with `check_tool_call`, `check_tool_call_traced`, `list_authorized_tools`. SDK-agnostic core (plain dict / protocol shapes); optional `[mcp]` extra ships duck-typed binding. `MCPSessionResolver` protocol carries Phase 3 chain through every tool call. Parameter-level ABAC via existing dot-paths — no new condition language. Pre-authorization schema hygiene rejects malformed calls before policy evaluation. Pending-approval surface hydrates approver / quorum / channel / TTL metadata.
- **TD-001 — `integration-guide.md` rewrite**: from a 12-line stub to a complete guide spanning Phases 0-4 with runnable examples. Every demonstrative code block mirrored as an executable test in `tests/integration/test_integration_guide_examples.py` — guide and code cannot drift silently.
- **ADR-0001 + ADR-0002**: first ADRs ever written in `specs/decisions/`. Cite prior art (AWS VP, Casbin, Cerbos, OPA, OpenFGA, SpiceDB) and document the chosen design vs. each rejected alternative.
- **`auth-model.md`**: updated with Phase 4 surface (list_authorized, MCP adapter sections).

## What went well

1. **Pre-implementation pivot saved the phase.** The brainstorm assumed an OpenFGA-style pattern-based policy model. A 60-second codebase inspection before T1 surfaced that open-guard is attribute-based — the entire "hybrid per-evaluator list" design didn't apply. Pivoted in one commit to the AWS VP / Casbin pattern (iterate-per-candidate via `authorize()`), dropped the per-evaluator `list_authorized` port method, simplified 21 tasks to 16. Without this pivot the implementation would have produced a wrong abstraction the brainstorm couldn't see.
2. **TDD cadence held throughout.** 14 commits, each with failing tests first, implementation, full suite green, lint clean, mypy clean. Zero cleanup commits.
3. **Composition by construction.** `list_authorized` literally calls `authorize()` per candidate, so deny precedence, chain enforcement, and pending-approval exclusion all "just work" — zero new test surface for composition semantics.
4. **Integration guide became code.** Mirroring every snippet as an executable test (T14) caught two real bugs in the guide examples (operator naming, attribute path), prevented two more from shipping. Anti-doc-rot insurance for the lifetime of the repo.
5. **First ADRs written, with prior-art comparison.** ADR-0001 and ADR-0002 cite AWS VP, Casbin, Cerbos, OPA, OpenFGA, SpiceDB so future readers see why we chose this pattern over the alternatives. Pattern worth keeping for future ADRs.
6. **Pagination cursor logic survived two design rounds.** First impl over-pulled from sources and stranded uninspected rows behind terminal cursors. The fix (`fetch_size = max(remaining, 10)`, advance only by processed items) was small and made the cursor mathematically correct.
7. **Industry-standard answer for an industry-standard question.** The user asked "what's the right way to do this?" — answering with explicit prior art (AWS VP, Casbin, OpenFGA, SpiceDB, Cerbos, OPA) and why this codebase fits one pattern over another shaped a much better design than reasoning from first principles would have.

## What didn't go well

1. **Brainstorm got the policy model wrong.** Plan was written assuming pattern-based policies (`resources=["doc:*"]`); actual policies are attribute-dict-based (`resource_match={"type": "doc"}`). This is a workflow gap — the brainstorm should have inspected the actual `Policy` entity shape before sizing the design. Cost: one pivot commit. Would have been worse if caught after T4.
2. **Coverage dropped from 98% → 97%.** MCP adapter paths (specifically the `list_authorized_tools` flow and SDK binding) aren't fully exercised in unit tests; integration tests cover the end-to-end happy path but miss some branches. Acceptable for v0.5.0 release; raise to 98% in v0.5.1 with a focused MCPGuard unit-test pass.
3. **Test fixtures duplicated across files.** `InMemoryCandidateSource`, `_StaticResolver`, `_doc_typedefs()` show up in 3-4 test files each. Should have built a shared `tests/conftest.py` or `tests/fixtures/` package. Tracked as a follow-up (low priority).
4. **`integration-guide.md` is long — 1.5k lines of examples.** Pragmatic, but a hierarchical README pointing into per-section files would scale better. Worth revisiting if the guide grows further.
5. **MCP composition footgun.** When a Guard has both ABAC and ReBAC evaluators, fail-closed AND semantics require both to have at least one matching ALLOW policy. Easy to get wrong. The integration guide now has a "Composition rules" section warning about this, and the executable mirror test demonstrates the failure mode — but it's still a real footgun for new consumers.

## Lessons learned

1. **Inspect the codebase before sizing implementations.** Brainstorming from prior art (FEAT-006 detail doc, OpenFGA inspiration) is valuable, but assumptions about *this* codebase's shape need a 60-second sanity check before committing to a design. This is the second time (Phase 3 had a similar moment about Decision shape) — the pattern is real.
2. **Cite prior art explicitly when designing.** Rather than reasoning through alternatives from first principles, naming AWS Verified Permissions / Casbin / Cerbos / OPA / OpenFGA / SpiceDB and what each one does made the right design obvious in three minutes. ADRs should follow the same pattern.
3. **Make docs executable.** Every code block in `integration-guide.md` becoming an integration test cost ~1 hour and provides anti-rot insurance forever. This is the only honest way to keep public docs accurate as the library evolves. Should become standard practice for any consumer-facing doc.
4. **`authorize()` reuse is a force multiplier.** Implementing `list_authorized` by calling `authorize()` per candidate (instead of inventing a parallel pipeline) meant every Phase 0-3 feature — chain, deny precedence, pending approval, traces, tenant isolation — flowed through automatically. The simplest possible composition was also the most correct.
5. **Optional extras pattern works.** `[sql]` (Phase 2), `[fastapi]` (Phase 0), `[mcp]` (Phase 4) — each lets us ship a specific integration without forcing the dependency on every consumer. Pattern is now well-established; consider it for any future external-system adapter.
6. **Duck-typing across SDK boundaries beats hard pinning.** The MCP SDK binding reads `.name` / `.tool_name` / `.arguments` / `.params` so future SDK renames don't break consumers. Worth applying to any other "thin binding to a moving SDK" we ship.
7. **Phase 4's task-count revision (21 → 16) was the right move.** Compressing tasks that share helpers (T5-T9 became one MCP commit) kept commits coherent and reviewable instead of arbitrarily atomic. Preserve this judgment in future phases — granularity should follow logical structure, not enforce it.

## Discoveries flagged for backlog / future phases

- **ENH-014** — reverse-ABAC query compilation (Cerbos `PlanResources`, OPA partial eval) for `list_authorized` on simple condition shapes. Already filed during brainstorm.
- **ENH-015** — Zanzibar-style zookies for `list_authorized` cursor stability under concurrent policy changes. Already filed.
- **ENH-016** — per-result explainability for `list_authorized` (sampled / aggregate trace). Already filed.
- **ENH-017** — MCP streaming-chunk authorization (per-chunk content filtering). Already filed.
- **TD-003** — Phase 3 ADR backfill (ADR-0001..0007 referenced in Phase 3 overview but never written). Already filed; doc-only, can land between phases.
- **NEW (v0.5.1 candidate)** — raise MCP adapter unit-test coverage from ~70% to 95%+ to bring overall coverage back to 98%. Branches needed: `list_authorized_tools` cursor pagination, schema hygiene type-mapping for all JSON Schema types, SDK binding error paths.
- **NEW (v0.5.1 candidate)** — share fixtures (`InMemoryCandidateSource`, `_StaticResolver`) via `tests/conftest.py` to remove ~150 lines of duplication.

## Readiness for Phase 5

- Phase 5 (Delegation & Bounds — FEAT-001 push/pull delegation, FEAT-002 usage caps, FEAT-003 leases, FEAT-010 prompt-injection-resistant policy isolation) builds directly on Phase 4 primitives:
  - Delegation chains layer on top of Phase 3 OBO chain machinery (`Subject.on_behalf_of`).
  - Usage-counted permissions can express their state as a lightweight `LeaseStorePort` mirroring `ApprovalStorePort` shape.
  - Heartbeat / lease renewal is a pull mechanism that pairs naturally with the `ApprovalStorePort.expire_stale` pattern.
- Nothing in Phase 4 blocks Phase 5.
- Phase 5 brainstorm should start with the FEAT-001 detail doc (already written 2026-04-17) and the codebase-inspection discipline from this phase: read `Subject`, `Decision`, and the existing service layer BEFORE sizing the design.

## Credits

Implemented by Claude Opus 4.7 (1M context) under durable autonomy grant. User provided the critical "what's the right way to do this?" challenge that triggered the pre-implementation pivot from the wrong design to the AWS VP / Casbin pattern. ADR prior-art comparison style was driven by the same exchange.
