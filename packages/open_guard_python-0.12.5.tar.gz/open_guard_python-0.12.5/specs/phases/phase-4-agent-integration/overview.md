# Phase 4 — Agent Integration Surface

> **Status**: Not Started
> **Estimated Effort**: 4-5 days (roadmap); likely ~1-2 sessions at Phase 3 velocity
> **Depends On**: Phase 3 (Agentic Core Contract) — v0.4.0
> **Version Target**: v0.5.0
> **Breaking Changes**: None (fully additive)

## Goal

Deliver the outward-facing integration layer agentic systems need, on top of Phase 3's chain/approval/trace foundation:

1. **`list_authorized()`** (FEAT-006) — inverse of `authorize()`. "Which resources of type T can actor A perform action X on?" Returns paginated IDs. The RAG / filtered-retrieval primitive.
2. **MCP tool-call adapter** (FEAT-009) — `open_guard.adapters.mcp.MCPGuard` maps Model Context Protocol tool invocations to `Guard.authorize()` with parameter-level ABAC conditions, session-to-Subject resolution (chain-aware), and Phase 3 pending_approval flow for dangerous tools.
3. **Integration guide backfill** (TD-001) — rewrite `specs/architecture/integration-guide.md` from a 12-line stub to a real guide with working examples spanning Phases 0-4, with every snippet mirrored as an executable integration test.

Every change is **additive**. Existing `guard.authorize()` / `guard.authorize_traced()` / `guard.approve()` code from v0.4.0 keeps working unchanged. No v0.4.0 test is modified.

## Theme: Why these three together

Shipping them independently would create churn:

- **FEAT-009 without FEAT-006** → MCP `list_tools` can't filter by what the agent may invoke; every consumer rebuilds filtered discovery on their own.
- **FEAT-006 without FEAT-009** → the canonical agentic use case (per-tool authorization) stays undocumented and uncovered; the "why `list_authorized`?" argument feels abstract.
- **Both without TD-001** → integration-guide.md drifts further from reality; Phase 3 surface (chain, approval, trace) stays undocumented from a consumer's point of view; new Phase 4 primitives ship without narrative.

One integration-surface release is better than three staggered ones. After v0.5.0, Phase 5 can layer delegation / budgets / leases on top of an already-complete consumer-facing API.

## Key Decisions

All locked during the 2026-04-18 brainstorm. Two ADRs will be written in-phase (T20).

| Decision | Choice | Rationale | ADR |
|----------|--------|-----------|-----|
| `list_authorized` composition semantics | Identical to `authorize()` — union of per-evaluator ALLOWs, minus explicit DENY | Zero new semantics for users to learn; composition is the same story as `authorize()` | ADR-0001 |
| `list_authorized` per-evaluator strategy | Hybrid: ReBAC (Zanzibar `list_objects` graph walk), RBAC (resource-pattern predicates), TBAC (active-task-scope filter), ABAC (iteration via new port) | Each evaluator contributes natively; scales where it can; no reverse-ABAC compiler burden | ADR-0001 |
| Candidate source for ABAC iteration | New `CandidateResourcePort` — consumer implements `fetch_candidates(resource_type, prefilter, cursor, limit)` for listable types | Preserves open-guard's invariant "doesn't own resource storage"; only needed when ABAC iteration is the only path | ADR-0001 |
| Reverse-ABAC query compilation | **Out of scope** — iteration-with-early-termination only | One compiler per store backend is a forever tax; chain predicates / regex / set ops don't push down cleanly; can bolt on later as targeted optimization | ADR-0001 |
| Result shape | IDs only (no attributes, no per-result DecisionTrace) | Caller enriches; per-result traces explode output at scale | ADR-0001 |
| Pagination | Opaque base64-JSON cursor; default `limit=100`; no server-side enforcement of max limit | Stateless, simple; consumers who need caps enforce them at their layer | ADR-0001 |
| Cursor stability under policy change | **Undefined** — documented as such | Snapshot isolation requires zookies, which Phase 2 explicitly deferred | ADR-0001 |
| MCP SDK dependency | SDK-agnostic core (dict/protocol shapes); `[mcp]` optional extra for `python-mcp-sdk` thin binding | Mirrors existing `[sql]` extra pattern; keeps core dependency-free | ADR-0002 |
| MCP resource namespace | `tool:<server_id>:<tool_name>` default, configurable via `MCPGuard(resource_namespace=...)` | Disambiguates multi-server deployments | ADR-0002 |
| MCP parameter path syntax in ABAC | Dot-paths (`params.query`, `params.table`) | Existing ABAC convention; no new syntax to learn | ADR-0002 |
| MCP parameter schema enforcement | Pre-authorization hygiene — reject malformed calls before policy evaluation | Defense-in-depth; rejects at the structural layer before evaluator sees anything | ADR-0002 |
| Chain propagation through MCP | Consumer-provided `MCPSessionResolver` returns full `Subject` including `on_behalf_of` chain | Reuses Phase 3 primitives untouched; MCP adapter stays stateless | ADR-0002 |
| Filtered tool discovery | `MCPGuard.list_authorized_tools(session_id, server_id=None)` wraps `guard.list_authorized(subject, "invoke", "tool")` | FEAT-006 ↔ FEAT-009 seam; no new surface to invent | — |
| Streaming-tool chunk authorization | **Out of scope**; tool-call granularity only | Detail doc deferred this; Phase 5+ territory | — |
| ADR numbering | Phase 4 starts at ADR-0001 (Phase 3 overview referenced ADR-0001..0007 aspirationally but none were written — directory is empty) | Avoids numbering conflict; Phase 3 ADR backfill tracked as TD-003 | — |

## Source Structure

```
src/open_guard/
  domain/
    entities.py                       # MODIFY — add ListRequest, ListResult, Cursor (pagination types)
    ports/
      evaluator.py                    # MODIFY — add optional list_authorized method with NotSupported sentinel
      candidate_resource.py           # NEW — CandidateResourcePort abstract interface
  adapters/
    evaluators/
      rbac.py                         # MODIFY — list_authorized via resource-pattern predicate extraction
      rebac.py                        # MODIFY — list_authorized via Zanzibar graph walk
      tbac.py                         # MODIFY — list_authorized via active-task-scope filter
      abac.py                         # MODIFY — list_authorized via CandidateResourcePort iteration
    mcp/                              # NEW — MCP adapter package
      __init__.py                     # NEW — public exports
      guard.py                        # NEW — MCPGuard
      entities.py                     # NEW — MCPToolRequest, MCPToolResponse, MCPAuthorizationResult, MCPAuthorizationPending
      resolver.py                     # NEW — MCPSessionResolver protocol
      sdk.py                          # NEW — optional [mcp] extra thin binding to python-mcp-sdk
  domain/services/
    guard.py                          # MODIFY — Guard.list_authorized orchestration
    policy_router.py                  # MODIFY — compose list results; cursor encode/decode
  __init__.py                         # MODIFY — export new public API

specs/
  architecture/
    integration-guide.md              # REWRITE — stub → full guide with working examples spanning Phases 0-4
  decisions/
    0001-list-authorized-composition.md   # NEW — composition semantics + reverse-ABAC strategy
    0002-mcp-adapter-design.md            # NEW — SDK strategy + resource namespacing + chain propagation

tests/
  unit/
    domain/
      test_entities.py                # MODIFY — ListRequest, ListResult, Cursor round-trip
    adapters/
      evaluators/
        test_rbac_list.py             # NEW — RBAC pattern-predicate extraction
        test_rebac_list.py            # NEW — Zanzibar graph walk
        test_tbac_list.py             # NEW — active-task-scope filtering
        test_abac_list.py             # NEW — iteration via CandidateResourcePort
      mcp/
        test_guard.py                 # NEW — MCPGuard orchestration
        test_resolver.py              # NEW — session-to-Subject resolution
        test_entities.py              # NEW — MCP dataclass shapes
    services/
      test_guard_list.py              # NEW — Guard.list_authorized composition + deny filter
  integration/
    test_list_authorized.py           # NEW — 4-evaluator composition, cursor, explicit-DENY, chain-scoped
    test_mcp_adapter.py               # NEW — full MCP flow: resolver → hygiene → authz → allow/deny/pending
    test_integration_guide_examples.py  # NEW — every code snippet in integration-guide.md is executable
```

## Scope

### In Scope

**FEAT-006 — `list_authorized()`:**
- `Guard.list_authorized(subject, action, resource_type, tenant_id, prefilter=None, limit=100, cursor=None) -> ListResult`
- `ListRequest`, `ListResult`, `Cursor` entities (Pydantic; cursor is opaque base64-JSON)
- Per-evaluator `list_authorized` contribution via `EvaluatorPort` (optional method with `NotSupported` sentinel — all existing v0.4.0 evaluator instances remain valid)
- `CandidateResourcePort` abstract interface + fixture implementation for tests (no production adapter shipped in Phase 4 — consumers implement)
- Composition: union of per-evaluator ALLOWs; explicit-DENY second pass (skipped when no DENY policies exist for the (action, resource_type) pair)
- RBAC strategy: extract resource patterns from matched policies; pattern-based prefilter (no iteration)
- ReBAC strategy: Zanzibar graph walk reusing existing `max_depth` + memoization; subject-set expansion; wildcard handling
- TBAC strategy: filter by active task scopes at current clock
- ABAC strategy: iterate candidates from `CandidateResourcePort` with early termination at `limit`; chain predicates respected
- Cursor pagination is stateless (cursor encodes per-evaluator continuation state + evaluated-so-far set); cursor stability under concurrent policy changes is **undefined** and documented
- Default `limit=100`; no enforced upper bound

**FEAT-009 — MCP tool-call adapter:**
- `open_guard.adapters.mcp` package
- `MCPGuard(guard, resolver, resource_namespace="tool:{server_id}:{tool_name}")` — orchestrator
- `MCPSessionResolver` protocol: `async resolve(session_id, claims) -> Subject` (supports chain via `Subject.on_behalf_of`)
- `MCPToolRequest` / `MCPToolResponse` / `MCPAuthorizationResult` / `MCPAuthorizationPending` dataclasses (SDK-agnostic dict shapes)
- `MCPGuard.check_tool_call(session_id, tool_name, params, server_id, tool_schema=None)` — main entry
  - Resolver → Subject
  - Pre-authorization schema hygiene (structural param validation against `tool_schema` if supplied)
  - Build `Resource(resource_type="tool", id=namespaced_id, attributes={"params": params, "server_id": server_id, "tool_name": tool_name})`
  - `guard.authorize(...)` with action `"invoke"`
  - Map decision → `MCPAuthorizationResult` (allow / deny / pending)
  - Pending decisions carry `approval_request_id` + approval metadata for consumer dispatch
- `MCPGuard.check_tool_call_traced(...)` — same as above plus `DecisionTrace`
- `MCPGuard.list_authorized_tools(session_id, server_id=None, limit=100, cursor=None)` — wraps `guard.list_authorized(subject, "invoke", "tool", ...)`; returns namespaced tool IDs
- Parameter-level ABAC: params are flattened to dot-paths (`params.query`, `params.table.name`, `params.options.*`) and available to ABAC conditions on the resource
- Optional `[mcp]` extra: `open_guard.adapters.mcp.sdk` provides thin adapters from `python-mcp-sdk` types to the SDK-agnostic shapes

**TD-001 — Integration guide:**
- Rewrite `specs/architecture/integration-guide.md` from 12-line stub to a complete guide
- Sections required:
  1. Overview — what open-guard is, what it isn't
  2. Quick Start — 10-line minimal `Guard` + RBAC policy + `authorize()`
  3. Phase 0 — RBAC + ABAC basics (entities, policies, operators)
  4. Phase 0 — FastAPI integration (`open_guard.fastapi.OpenGuardMiddleware`)
  5. Phase 1 — TBAC (time windows, schedules, tasks)
  6. Phase 2 — ReBAC (relation tuples, computed permissions) + SQLAlchemy stores
  7. Phase 3 — Identity chains (`Subject.on_behalf_of`), async approval, `authorize_traced`
  8. Phase 4 — `list_authorized()` for RAG pipelines
  9. Phase 4 — MCP adapter for tool-call authorization
  10. End-to-end RAG walk-through (documents + ReBAC + `list_authorized`)
  11. End-to-end MCP walk-through (agent session + chain + per-parameter ABAC + pending approval)
- Every code snippet is mirrored as an executable test in `tests/integration/test_integration_guide_examples.py` — the guide and the tests share a single source of truth

### Out of Scope (Backlogged)

- Reverse-ABAC query compilation → **ENH-014** (future optimization)
- Zookie-style consistency tokens for `list_authorized` / `authorize` → **ENH-015**
- Per-result DecisionTrace for `list_authorized` (sampled / aggregate) → **ENH-016**
- MCP streaming-chunk authorization → **ENH-017**
- MCP capability negotiation, MCP transport security — user-level concerns (TLS / mTLS / auth)
- Push / pull delegation primitives (FEAT-001) — Phase 5
- Usage-counted / budget-capped permissions (FEAT-002) — Phase 5
- Heartbeat / lease renewal (FEAT-003) — Phase 5
- Prompt-injection-resistant policy isolation docs (FEAT-010) — Phase 5
- Reference `ApprovalDispatcher` protocol + Slack/webhook impls (ENH-013) — Phase 5
- `ApprovalRequirement.channel` as enum (ENH-012) — Phase 4 or 5 (revisit after MCP integration tightens the vocabulary)
- Policy engine doc backfill (TD-002) — Phase 6
- Phase 3 ADR backfill (TD-003) — separate doc-only task, not Phase 4

## Deliverables

| Deliverable | Verification |
|-------------|-------------|
| `ListRequest` / `ListResult` / `Cursor` entities + opaque cursor codec | `pytest tests/unit/domain/test_entities.py -v -k list` |
| `CandidateResourcePort` abstract interface | `pytest tests/unit/adapters/evaluators/test_abac_list.py -v` |
| RBAC `list_authorized` (pattern predicates) | `pytest tests/unit/adapters/evaluators/test_rbac_list.py -v` |
| ReBAC `list_authorized` (Zanzibar walk) | `pytest tests/unit/adapters/evaluators/test_rebac_list.py -v` |
| TBAC `list_authorized` (task-scope filter) | `pytest tests/unit/adapters/evaluators/test_tbac_list.py -v` |
| ABAC `list_authorized` (iteration) | `pytest tests/unit/adapters/evaluators/test_abac_list.py -v` |
| `Guard.list_authorized` orchestration + deny filter | `pytest tests/unit/domain/services/test_guard_list.py -v` |
| End-to-end 4-evaluator composition | `pytest tests/integration/test_list_authorized.py -v` |
| `MCPGuard.check_tool_call` flow (allow / deny / pending) | `pytest tests/unit/adapters/mcp/test_guard.py tests/integration/test_mcp_adapter.py -v` |
| `MCPSessionResolver` + chain propagation | `pytest tests/unit/adapters/mcp/test_resolver.py -v -k chain` |
| Parameter-level ABAC enforcement | `pytest tests/integration/test_mcp_adapter.py -v -k params` |
| `MCPGuard.list_authorized_tools` filtered discovery | `pytest tests/integration/test_mcp_adapter.py -v -k list_tools` |
| Optional `[mcp]` extra binding | `pip install -e '.[mcp]' && pytest tests/unit/adapters/mcp/test_sdk_binding.py -v` |
| Integration guide has working examples | `pytest tests/integration/test_integration_guide_examples.py -v` |
| ADR-0001 (list composition) + ADR-0002 (MCP design) written | `ls specs/decisions/0001-*.md specs/decisions/0002-*.md` |
| All 406 Phase 3 tests still pass unchanged | `pytest -v` |
| Type safety | `mypy --strict src/` |
| Code quality | `ruff check src/ tests/` |
| Coverage threshold | `pytest --cov=open_guard --cov-report=term-missing` ≥ 95% (target: maintain 98%) |

## Acceptance Criteria

1. `guard.list_authorized(subject, "read", "document", tenant_id="acme")` returns `ListResult(ids=[...], next_cursor=None)` when results fit within `limit`.
2. Pagination: a second call with the returned `next_cursor` continues the enumeration without repeats.
3. RBAC-only configuration returns IDs matching resource-pattern predicates from matched policies (no `CandidateResourcePort` needed).
4. ReBAC-only configuration returns IDs from the Zanzibar graph walk; respects `max_depth`; subject sets expand correctly.
5. ABAC-only configuration requires a `CandidateResourcePort`; iterates candidates; early-terminates at `limit`.
6. TBAC-only configuration returns only resources inside currently active task scopes.
7. Four-evaluator composition: result = union of per-evaluator allow-sets, minus IDs matched by any explicit DENY policy for (action, resource_type).
8. No DENY policies for (action, resource_type) → deny-filter pass is skipped entirely (verified via evaluator-invocation count in test).
9. Cursor stability under policy change is documented as undefined; no test asserts stability.
10. `MCPGuard(guard=g, resolver=r).check_tool_call(session_id, "query_db", {"table": "users"}, server_id="prod")` returns `MCPAuthorizationResult` with `status in {"allow", "deny", "pending"}`.
11. `MCPGuard` pending path: when `authorize()` returns `PENDING_APPROVAL`, result carries `approval_request_id` and `approval_requirement` (channel hint, approvers, TTL).
12. `MCPGuard` chain propagation: resolver returns `Subject(on_behalf_of=...)` → ABAC `chain.*` predicates evaluate against the chain.
13. Per-parameter ABAC: a policy with `{"conditions": {"params.query": {"not_regex": "DROP|DELETE|TRUNCATE"}}}` denies matching tool calls.
14. `MCPGuard.list_authorized_tools(session_id)` returns namespaced tool IDs the subject may invoke.
15. Parameter-schema hygiene: calls with missing required params or wrong types are rejected with `MCPAuthorizationResult(status="deny", reason="schema_violation:...")` before policy evaluation.
16. `integration-guide.md` Quick Start snippet is a copy-paste-runnable 10-line example.
17. Every code block in `integration-guide.md` appears verbatim as an integration test.
18. ADR-0001 and ADR-0002 follow the `0000-template.md` structure and are referenced from Phase 4 decisions.
19. All 406 Phase 3 tests pass with zero modifications.
20. Coverage ≥ 95% (target: 98%), `mypy --strict` clean, `ruff` clean.
21. Version bumped to `0.5.0` in `pyproject.toml` and `open_guard.__version__`.
22. Public API exports (`open_guard/__init__.py`) include: `ListRequest`, `ListResult`, `Cursor`, `CandidateResourcePort`, `MCPGuard`, `MCPSessionResolver`, `MCPAuthorizationResult`, `MCPAuthorizationPending`, `MCPToolRequest`, `MCPToolResponse`.

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/architecture/auth-model.md` | Phase 3 chain/approval/trace surface — Phase 4 composes on top |
| `specs/backlog/details/FEAT-006.md` | `list_authorized` detail doc |
| `specs/backlog/details/FEAT-009.md` | MCP adapter detail doc |
| `specs/architecture/integration-guide.md` | The stub being rewritten (TD-001) |
| `specs/phases/phase-3-agentic-core/retrospective.md` | Lessons learned from Phase 3 (BC shims, dual-mode APIs, clock injection, detail-doc-first workflow) |
| Google Zanzibar paper | `list_objects` is implementation-defined but canonical; ReBAC list strategy reference |
| OpenFGA `ListObjects` API | Industry API shape for ReBAC list |
| SpiceDB `LookupResources` API | Alternative ReBAC list shape |
| Auth0 FGA "FGA for RAG" | Product positioning for the RAG filter use case |
| Anthropic MCP specification | Protocol the adapter binds to |
| Cerbos MCP authorization | Prior art for MCP tool-call ACLs |
| Kong AI Gateway MCP Tool ACLs | Prior art for per-parameter tool restrictions |
| AgentBound (arXiv 2510.21236) | Academic framing of MCP access control |
