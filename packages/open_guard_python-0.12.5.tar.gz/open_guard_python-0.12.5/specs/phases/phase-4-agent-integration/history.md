# Phase 4 — Agent Integration Surface: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [DECISION] 2026-04-18 — Phase 4 theme: Agent Integration Surface (FEAT-006 + FEAT-009 + TD-001)
Topics: scope, phase-theme, list-authorized, mcp, integration-guide
Affects-phases: phase-4-agent-integration
Affects-specs: specs/planning/roadmap.md
Detail: Phase 4 delivers three tightly-coupled items: (a) FEAT-006 `list_authorized()` as the RAG / filtered-retrieval primitive, (b) FEAT-009 MCP tool-call adapter with parameter-level ABAC and Phase 3 pending_approval integration, (c) TD-001 full rewrite of `integration-guide.md` from a 12-line stub. Rationale: FEAT-006 and FEAT-009 share a tight seam (MCP `list_tools` filtered via `list_authorized(..., "invoke", "tool")`) — splitting them means designing the seam twice and shipping MCP without filtered discovery. TD-001 travels with them because every new Phase 4 code path needs documented consumer usage while the design is fresh. One release (v0.5.0) beats three staggered ones.

---

### [DECISION] 2026-04-18 — `list_authorized` composition = identical to `authorize()`
Topics: list-authorized, composition, semantics, policy-engine
Affects-phases: none
Affects-specs: specs/decisions/0001-list-authorized-composition.md (to be written in T20), specs/architecture/auth-model.md (sync-docs at close)
Detail: `guard.list_authorized(subject, action, resource_type, tenant_id)` returns `{R | authorize(subject, action, R) == ALLOWED}`. Zero new composition semantics for users to learn. Implementation is the hybrid per-evaluator strategy (ReBAC Zanzibar walk, RBAC patterns, TBAC task scope, ABAC iteration) with a DENY-filter second pass that is **skipped entirely** when no DENY policies exist for the (action, resource_type) pair — preserving O(1) fast path for common deny-absent deployments.

---

### [DECISION] 2026-04-18 — Hybrid per-evaluator list strategy (not a monolithic iteration or query compiler)
Topics: list-authorized, evaluator-port, rebac, rbac, tbac, abac, architecture
Affects-phases: none
Affects-specs: specs/decisions/0001-list-authorized-composition.md
Detail: Each evaluator contributes natively to `list_authorized`: ReBAC does a Zanzibar graph walk (O(results), not O(candidates)); RBAC extracts resource-pattern predicates from matched policies (no iteration); TBAC filters by active task scopes at the current clock; ABAC iterates via a new `CandidateResourcePort`. Rejected alternatives: (a) single iteration strategy across all evaluators — drops ReBAC's graph advantage; (b) reverse-ABAC query compilation — one compiler per store backend is a forever maintenance tax, chain predicates and regex/set ops don't push down cleanly, so we defer as ENH-014. The `Guard` composition is unchanged: the orchestrator collects per-evaluator `EvaluatorListContribution` objects (allow_ids + allow_patterns + continuation) and unions them.

---

### [DECISION] 2026-04-18 — New `CandidateResourcePort` for ABAC iteration (preserves "open-guard doesn't own storage")
Topics: list-authorized, abac, ports, candidate-source, clean-architecture
Affects-phases: none
Affects-specs: specs/decisions/0001-list-authorized-composition.md, specs/architecture/auth-model.md
Detail: open-guard's clean/hexagonal invariant is that the library doesn't own resource storage — `authorize()` takes a `Resource` built by the caller. `list_authorized` for ABAC-only deployments can't iterate without a candidate source, so we add a thin `CandidateResourcePort` that the consumer implements: `fetch_candidates(resource_type, tenant_id, prefilter, cursor, limit) -> (list[Resource], next_cursor)`. The port is optional — ReBAC / RBAC-pattern / TBAC deployments don't need one. Phase 4 ships the port abstraction + an in-memory fixture for tests; consumers implement their own production adapter (SQLAlchemy / Mongo / Elastic / custom). No production `CandidateResource` adapter shipped in Phase 4 itself.

---

### [DECISION] 2026-04-18 — `list_authorized` result shape: IDs only, opaque base64-JSON cursor, undefined stability
Topics: list-authorized, api-shape, pagination
Affects-phases: none
Affects-specs: specs/decisions/0001-list-authorized-composition.md
Detail: (1) Result is `ListResult(ids: list[str], next_cursor: str | None)` — IDs only, no attributes, no per-result DecisionTrace. Caller enriches resources via their own data layer; per-result traces would explode output at scale (see ENH-016 for the proper aggregate shape). (2) Default `limit=100`, no server-side upper bound enforced. (3) Cursor encodes per-evaluator continuation state + seen-ID set as base64-URL-safe JSON — stateless; no server-side pagination store. (4) Cursor stability under concurrent policy changes is **undefined behavior, documented as such** — snapshot isolation requires Zanzibar-style zookies, which Phase 2 explicitly deferred and Phase 4 continues to defer (see ENH-015).

---

### [DECISION] 2026-04-18 — Reverse-ABAC query compilation is out of scope; ENH-014 tracks it
Topics: abac, reverse-query, out-of-scope, enh
Affects-phases: none
Affects-specs: specs/backlog/backlog.md (ENH-014 row to be added)
Detail: Compiling ABAC conditions into store-native queries (SQL WHERE, Elastic filters) is how you'd scale ABAC iteration beyond O(N). Industry prior art: OpenFGA punts, Cerbos punts on complex conditions, Auth0 FGA punts. We punt too. Reasons: (a) compiler per store backend is a forever tax; (b) chain predicates (`chain.root_actor.attributes.*`) materialize only after chain walk — can't push down; (c) regex / set operators / dynamic PIP lookups don't cleanly lower to SQL. Iteration-with-early-termination is correct for P1. Targeted optimization for specific condition shapes can bolt on later if profiling demands; that's the ENH-014 story.

---

### [DECISION] 2026-04-18 — MCP adapter: SDK-agnostic core + `[mcp]` optional extra
Topics: mcp, sdk, optional-deps, packaging
Affects-phases: none
Affects-specs: specs/decisions/0002-mcp-adapter-design.md (to be written in T20)
Detail: Core `open_guard.adapters.mcp` takes plain dict / protocol shapes (`MCPToolRequest`, `MCPAuthorizationResult`) and works with any MCP server implementation — including future non-Python ones serialized over the wire. A thin binding layer (`open_guard.adapters.mcp.sdk`) maps `python-mcp-sdk` types to the agnostic shapes; it lives behind a `[mcp]` optional extra, mirroring the existing `[sql]` extra for SQLAlchemy stores. Rejected: hard-pinning `python-mcp-sdk` as a core dep. Reason: keeps open-guard core dependency-free; lets consumers bring their own SDK version; works for MCP-over-JSON-RPC-over-any-transport.

---

### [DECISION] 2026-04-18 — MCP resource namespace: `tool:<server_id>:<tool_name>` (configurable)
Topics: mcp, resource-namespace, multi-server
Affects-phases: none
Affects-specs: specs/decisions/0002-mcp-adapter-design.md
Detail: An MCP client may connect to multiple MCP servers; the same `tool_name` can exist on different servers with different semantics. Default namespace is `tool:<server_id>:<tool_name>` (e.g., `tool:prod:query_db` vs `tool:staging:query_db`). Configurable via `MCPGuard(resource_namespace="tool:{server_id}:{tool_name}")` — consumers with a single-server deployment can override to `tool:{tool_name}`. Policies reference tools via glob patterns: `tool:prod:*` grants a role every tool on prod; `tool:*:query_db` grants across all servers.

---

### [DECISION] 2026-04-18 — Parameter-level ABAC via existing dot-paths, not a new condition language
Topics: mcp, abac, conditions, parameter-authz
Affects-phases: none
Affects-specs: specs/decisions/0002-mcp-adapter-design.md, specs/architecture/auth-model.md
Detail: MCP tool calls carry a `params` dict. The adapter exposes params on the resource as `attributes["params"]`, which makes existing ABAC dot-path resolution work without extension: `{"params.query": {"not_regex": "DROP|DELETE"}}`, `{"params.tables": {"is_subset": ["public.users"]}}`, `{"params.options.safe": {"equals": True}}`. No new condition primitives; reuses the full Phase 0-2 ABAC operator set (equals, in, contains_any, not_regex, etc.) and the Phase 3 chain predicates (`chain.*`). This means policy authors don't learn a new language for MCP.

---

### [DECISION] 2026-04-18 — Pre-authorization schema hygiene (reject malformed before policy eval)
Topics: mcp, validation, defense-in-depth, parameter-schema
Affects-phases: none
Affects-specs: specs/decisions/0002-mcp-adapter-design.md
Detail: `MCPGuard.check_tool_call(session_id, tool_name, params, server_id, tool_schema=None)` accepts an optional tool schema (dict). When provided, the adapter validates `params` structurally (required fields, types) BEFORE invoking `guard.authorize`. Malformed calls return `MCPAuthorizationResult(status="deny", reason="schema_violation:<detail>")`. Rationale: keeps ABAC from having to encode structural invariants; matches "reject garbage early" discipline; prevents attackers from using policy-eval traces as a fuzzing oracle.

---

### [DECISION] 2026-04-18 — Chain propagation via consumer-provided `MCPSessionResolver`
Topics: mcp, chain, session-identity, resolver-pattern, obo
Affects-phases: none
Affects-specs: specs/decisions/0002-mcp-adapter-design.md
Detail: An MCP session carries claims (token, session ID). open-guard doesn't know how to map claims → `Subject` — that's consumer-specific (open-shield-python? custom JWT issuer? vendor SSO?). The adapter defines a minimal `MCPSessionResolver` protocol — `async resolve(session_id, claims) -> Subject` — and composes the returned Subject (including any `on_behalf_of` chain) into the authorization call. Phase 3 chain primitives flow through MCP untouched. Reference implementations for common issuers are *not* in Phase 4 scope — consumers write their own (similar to how Phase 0 FastAPI middleware expects a consumer-provided token-to-Subject mapping).

---

### [DECISION] 2026-04-18 — Filtered tool discovery via `MCPGuard.list_authorized_tools` (wraps `list_authorized`)
Topics: mcp, list-authorized, tool-discovery, composition
Affects-phases: none
Affects-specs: specs/decisions/0002-mcp-adapter-design.md
Detail: An LLM agent typically calls MCP `list_tools` once per session to discover available tools. For authz-aware deployments, this discovery should be filtered to tools the agent may actually invoke. `MCPGuard.list_authorized_tools(session_id, server_id=None, ...)` resolves the subject via the resolver, then calls `guard.list_authorized(subject, action="invoke", resource_type="tool", prefilter={"server_id": server_id} if server_id else None)`. Returns namespaced tool IDs (e.g., `"tool:prod:query_db"`). This is the concrete FEAT-006 ↔ FEAT-009 seam and validates that the `list_authorized` API generalizes beyond documents to any resource type.

---

### [SCOPE_CHANGE] 2026-04-18 — Streaming-chunk authorization out of scope (ENH-017 tracks)
Topics: mcp, streaming, out-of-scope, enh
Affects-phases: phase-4-agent-integration
Affects-specs: specs/backlog/backlog.md (ENH-017 to be added)
Detail: Some MCP tools return streaming results (server-sent events, chunked responses). Per-chunk authorization (filtering or blocking individual chunks based on content) is a valid but distinct problem — it's a data-flow authz pattern, not a call authz pattern. Phase 4 explicitly scopes to tool-call granularity: decide allow/deny/pending at call time, then chunks flow per the tool implementation. Per-chunk authz deferred to ENH-017.

---

### [DISCOVERY] 2026-04-18 — Phase 3 ADRs were referenced but never written (backfill via TD-003)
Topics: adr, documentation, phase-3, tech-debt
Affects-phases: none
Affects-specs: specs/decisions/, specs/backlog/backlog.md (TD-003 to be added)
Detail: Phase 3's `overview.md` referenced ADR-0001 through ADR-0007 in its Key Decisions table as the authoritative record of each decision. However, inspection shows `specs/decisions/` contains only `0000-template.md`, `README.md`, and `impact-map.json` — no actual ADR files were written during Phase 3 execution. The decisions themselves are captured in Phase 3's `history.md`, but the ADR contract was not fulfilled. Phase 4 starts fresh at ADR-0001 / ADR-0002 to avoid numbering conflicts. Phase 3 ADR backfill is tracked as TD-003 in the backlog and is explicitly NOT in Phase 4 scope (doc-only work, can be done between phases).

---

### [NOTE] 2026-04-18 — Integration guide snippets become executable tests (T19)
Topics: documentation, tests, doc-rot, anti-drift
Affects-phases: phase-4-agent-integration
Affects-specs: specs/phases/phase-4-agent-integration/plan.md (T18, T19)
Detail: Phase 3 retrospective flagged `integration-guide.md` as stub-drift risk. Phase 4's TD-001 rewrite pairs with T19: every code block in the guide is mirrored as an integration test in `tests/integration/test_integration_guide_examples.py`. If a future change breaks a guide snippet, the test fails — guide and code can't drift silently. This adds ~0.5 day of test-writing but provides permanent anti-drift insurance, which matters more for an external-facing doc than for internal code.

---

### [DECISION] 2026-04-18 — Test target: maintain 98% coverage (floor 95%); 500-530 tests total
Topics: quality, coverage, testing
Affects-phases: phase-4-agent-integration
Affects-specs: none
Detail: Phase 3 finished at 406 tests / 98% coverage. Phase 4 adds ~100-125 tests: per-evaluator list (30-40), Guard orchestration + deny filter (15-20), MCP adapter core (15), MCP chain/pending/traced (10-15), parameter-level ABAC (8-10), filtered tool discovery (5-8), [mcp] extra binding (5), integration guide mirrors (~15), integration tests across the surface (15-20). Target: maintain 98%; acceptable floor 95%. Any drop below 95% is a blocker for release.

---

### [ARCH_CHANGE] 2026-04-18 — Pivot from "hybrid per-evaluator list" to "iterate-per-candidate via authorize()" (AWS Verified Permissions / Casbin pattern)
Topics: list-authorized, architecture, evaluator-port, composition, prior-art
Affects-phases: phase-4-agent-integration
Affects-specs: specs/phases/phase-4-agent-integration/plan.md, specs/phases/phase-4-agent-integration/tasks.md, specs/decisions/0001-list-authorized-composition.md (will be written with revised story)
Detail: Pre-implementation codebase inspection surfaced that the brainstorm's "hybrid per-evaluator list" design was based on an OpenFGA-style pattern-based policy model that open-guard does NOT use. Actual policy shape: `Policy.resource_match: dict[str, Any]` (attribute-matching), `Task.allowed_resource_types: list[str]` (types only, no IDs), `Policy.action_match`, `Policy.subject_match`. No policy carries resource IDs — only ReBAC `RelationTuple` does. Consequence: RBAC/ABAC/TBAC evaluators cannot enumerate authorized resource IDs natively; only ReBAC can (via tuples). This matches exactly the pattern industry-standard hybrid engines converge on: AWS Verified Permissions `is_authorized_batch`, Casbin `enforce_batch`, Cedar iterate-per-candidate. Revised Phase 4 approach: (1) ReBAC native enumeration via new `RelationshipStorePort.find_object_ids_for_subject`, (2) optional `CandidateResourcePort` for ABAC/RBAC-driven resources, (3) union candidates, iterate, call existing `Guard.authorize()` per candidate. Composition matches `authorize()` **by construction** (we literally call it). No new `EvaluatorPort.list_authorized` method — evaluator port stays at its v0.4.0 shape. Task count: 21 → 16. Public API, brainstorm decisions, and acceptance criteria are all preserved; only the internal implementation strategy simplifies. Reverse-ABAC partial evaluation (Cerbos `PlanResources`, OPA partial eval) stays deferred to ENH-014 as before.

---

### [DECISION] 2026-04-18 — Industry-standard pattern reference for ADR-0001
Topics: adr, list-authorized, prior-art
Affects-phases: none
Affects-specs: specs/decisions/0001-list-authorized-composition.md
Detail: ADR-0001 will explicitly cite and compare prior art across the four archetypes: (a) pure-ReBAC graph walk (OpenFGA `ListObjects`, SpiceDB `LookupResources`, Auth0 FGA), (b) iterate-per-candidate (AWS Verified Permissions `is_authorized_batch`, Casbin `enforce_batch`, Cedar), (c) partial evaluation (Cerbos `PlanResources`, OPA partial eval), (d) pattern-based enumeration (not used by any production hybrid engine known). Open-guard adopts a composition of (a) for ReBAC + (b) for everything else — the standard choice for a hybrid ABAC+ReBAC engine. (c) deferred to ENH-014 as an optimization once the v0.5.0 API has real-world usage data.

---
