# Phase 4 — Agent Integration Surface: Tasks

> Mirrors plan.md. All tasks completed 2026-04-18. 505 tests pass, 97% coverage, mypy/ruff clean, zero breaking changes.
>
> **Revised 2026-04-18** after codebase inspection: pivoted from "hybrid per-evaluator list" to industry-standard "ReBAC native enumeration + CandidateResourcePort + iterate-per-candidate via authorize()" (AWS Verified Permissions / Casbin pattern). 21 tasks → 16. Same deliverables, simpler implementation. See history.md entry dated 2026-04-18.

## Domain foundations

- [x] **T1** — `ListRequest`, `ListResult`, `Cursor` entities in `domain/entities.py`; opaque base64-JSON cursor codec — commit `134b639`
- [x] **T2** — `CandidateResourcePort` abstract port in `domain/ports/candidate_resource.py` — commit `128e924`
- [x] **T3** — `RelationshipStorePort.find_object_ids_for_subject` + memory + SQL impls — commit `58218a5`

## Guard.list_authorized

- [x] **T4** — `Guard.list_authorized` — ReBAC native enumeration ∪ CandidateResourcePort, iterate-per-candidate via `authorize()`, cursor pagination, chain depth, deny precedence, pending-approval exclusion — commit `632356d`

## MCP adapter

- [x] **T5-T9** — `open_guard.adapters.mcp` package + entities + `MCPSessionResolver` protocol + `MCPGuard` constructor + `check_tool_call` + `check_tool_call_traced` + `list_authorized_tools` + parameter-level ABAC via dot-paths — commit `67f685b`
- [x] **T10** — Optional `[mcp]` extra + duck-typed `from_sdk_call_request` binding — commit `aeee155`

## Integration tests

- [x] **T11+T12** — `tests/integration/test_list_authorized.py` (RAG flow, chain-scoped list, pending exclusion, tenant isolation) + `tests/integration/test_mcp_adapter.py` (allow/deny/pending/resume/chain/schema-hygiene/filtered discovery/traced) — commit `a5d650f`

## Docs + ADRs

- [x] **T13+T14** — Rewrite `integration-guide.md` (stub → complete guide spanning Phases 0-4) + `tests/integration/test_integration_guide_examples.py` (every demonstrative snippet is an executable test) — commit `e0d1029`
- [x] **T15** — ADR-0001 (`list_authorized` composition + reverse-ABAC strategy) + ADR-0002 (MCP adapter design) — commit `18a268a`

## Release hygiene

- [x] **T16** — Public API exports (`ListRequest`, `ListResult`, `Cursor`, `CandidateResourcePort`); version bump to `0.5.0`; `[mcp]` optional extra; changelog entry; suite gate (505 tests, 97% coverage, mypy/ruff clean) — commit `5e5f1fb`

## Phase close (not part of task execution — after T16)

- [ ] Draft `retrospective.md`
- [ ] Run `/sync-docs` — propagate list / MCP / integration-guide decisions to `auth-model.md` + `impact-map.json`
- [ ] User runs `/complete-phase` — tags v0.5.0 and merges phase branch to staging → main
