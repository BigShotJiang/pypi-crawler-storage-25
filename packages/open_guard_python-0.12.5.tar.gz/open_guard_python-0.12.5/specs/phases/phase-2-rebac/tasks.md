# Phase 2 — ReBAC + SQLAlchemy + ABAC Enhancements: Task Checklist

> Mirror of plan.md tasks. Mark `[x]` when done, `[/]` when in progress.

## Task 1: ABAC Enhancement — Set Operators (ENH-007)
- [x] Write failing tests for set operators (contains_any, contains_all, is_subset)
- [x] Implement set operators in `_evaluate_operator`
- [x] Run tests, verify pass
- [x] Commit

## Task 2: ABAC Enhancement — Negated Operators + OR Logic (ENH-004)
- [x] Write failing tests for negated operators (not_contains, not_regex)
- [x] Implement negated operators
- [x] Write failing tests for OR logic (condition_groups)
- [x] Implement OR logic via condition_groups in ABACEvaluator
- [x] Run all tests, verify pass (including existing ABAC — no regression)
- [x] Commit

## Task 3: ABAC Enhancement — Integration Tests
- [x] Write integration tests (OR logic + set ops + negated ops through Guard)
- [x] Run tests, verify pass
- [x] Commit

## Task 4: ReBAC Domain Entities
- [x] Write failing tests for RelationTuple, TypeDefinition, PermissionRule
- [x] Implement ReBAC entities in entities.py
- [x] Run tests, verify pass
- [x] Commit

## Task 5: RelationshipStorePort + InMemoryRelationshipStore
- [x] Write failing tests for InMemoryRelationshipStore
- [x] Implement RelationshipStorePort
- [x] Implement InMemoryRelationshipStore
- [x] Run tests, verify pass
- [x] Commit

## Task 6: ReBACEvaluator — Core Graph Traversal
- [x] Write failing tests (direct relations, wildcards, subject sets, computed permissions, max depth)
- [x] Implement ReBACEvaluator with graph traversal
- [x] Run tests, verify pass
- [x] Commit

## Task 7: ReBAC Integration Tests
- [x] Write integration tests (Google Drive-style, team membership, arrow traversal, deny override)
- [x] Run tests, verify pass
- [x] Commit

## Task 8: SQLAlchemy Table Definitions
- [x] Add `sqlalchemy>=2.0` optional dependency to pyproject.toml
- [x] Define SQLAlchemy table models (policies, tasks, relationship_tuples)
- [x] Run existing tests (no regression)
- [x] Commit

## Task 9: SQLAlchemyPolicyStore
- [x] Write failing tests (SQLite in-memory)
- [x] Implement SQLAlchemyPolicyStore
- [x] Run tests, verify pass
- [x] Commit

## Task 10: SQLAlchemyTaskStore
- [x] Write failing tests (SQLite in-memory)
- [x] Implement SQLAlchemyTaskStore
- [x] Run tests, verify pass
- [x] Commit

## Task 11: SQLAlchemyRelationshipStore
- [x] Write failing tests (SQLite in-memory)
- [x] Implement SQLAlchemyRelationshipStore
- [x] Run tests, verify pass
- [x] Commit

## Task 12: SQL Integration Tests
- [x] Write integration tests (full Guard flow with SQL stores)
- [x] Run tests, verify pass
- [x] Commit

## Task 13: Public API Exports + RelationshipError
- [x] Add RelationshipError exception
- [x] Update __init__.py exports (ReBAC entities, stores, evaluator)
- [x] Run all tests, verify pass
- [x] Commit

## Task 14: Final Verification + Cleanup
- [x] Full test suite passes
- [x] mypy --strict clean
- [x] ruff clean
- [x] >95% coverage
- [x] Verify backward compatibility (all 178 existing tests unchanged)
- [x] Fix any issues
- [x] Final commit
