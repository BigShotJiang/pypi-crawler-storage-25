# Phase 2 — ReBAC + SQLAlchemy + ABAC Enhancements

> **Status**: Not Started
> **Estimated Effort**: 6 days
> **Depends On**: Phase 1 (TBAC) — v0.2.0

## Goal

Add relationship-based access control (ReBAC) as the fourth authorization model based on the Google Zanzibar data model, persist all policy and task data via SQLAlchemy (SQLite/PostgreSQL/MySQL), and strengthen the ABAC evaluator with OR/NOT logical combinators and set operators — completing the four-model authorization engine.

## Key Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| ReBAC data model | Zanzibar-style relation tuples: `(object_type, object_id, relation, subject_type, subject_id, subject_relation)` | Industry standard. Used by Google, OpenFGA, SpiceDB, Ory Keto. |
| ReBAC schema | Type definitions with relations and computed permissions (union, intersection, exclusion, arrow) | Matches SpiceDB/OpenFGA patterns. Required for inherited permissions. |
| Graph traversal | Recursive subproblem decomposition with max depth limiting | Standard Zanzibar approach. Union short-circuits on first YES, intersection on first NO. |
| Wildcard support | `*` as subject_id means "all subjects of that type" | Required for public access patterns. All Zanzibar implementations support this. |
| ABAC OR logic | Structural OR via `condition_groups` — list of condition sets, any group match = pass | XACML/OPA/Cedar pattern. Keeps individual condition evaluation simple (always AND within a group). |
| ABAC NOT logic | Negated operators (`not_contains`, `not_regex`) added to existing operator set | AWS IAM pattern. Simpler than general-purpose NOT wrapper. |
| Set operators | `contains_any`, `contains_all`, `is_subset` | Cedar `containsAny`/`containsAll` + XACML `string-subset`. Industry must-haves. |
| SQLAlchemy approach | Consumer-owned engine, `create_tables()` method, typed normalized tables | Casbin adapter pattern + OpenFGA. No mandatory Alembic. SQLite-first. |
| SQL table design | Separate `policies`, `tasks`, `relationship_tuples` tables with `tenant_id` column | Typed tables for queryability. Row-level tenant isolation. |
| Multi-dialect | `sqlalchemy.types.JSON` for conditions, no ARRAY columns, `String` with explicit lengths | Portable across SQLite/PostgreSQL/MySQL without dialect-specific code. |
| ReBAC store | New `RelationshipStorePort` + `InMemoryRelationshipStore` + `SQLAlchemyRelationshipStore` | Follows existing port pattern. Separate from PolicyStore — relationships are their own data. |
| Backward compatibility | Existing ABAC `conditions` dict format still works (single group = legacy AND-only) | Zero breaking changes for existing users. |

## Source Structure

```
src/open_guard/
  domain/
    entities.py                  # MODIFY — add RelationTuple, TypeDefinition, Permission, ReBAC entities
    exceptions.py                # MODIFY — add RelationshipError
    ports/
      relationship_store.py      # NEW — RelationshipStorePort abstract interface
  adapters/
    evaluators/
      abac.py                    # MODIFY — add condition_groups, OR logic, set operators, negated operators
      rebac.py                   # NEW — ReBACEvaluator (graph traversal, Zanzibar Check)
    stores/
      memory_relationship.py     # NEW — InMemoryRelationshipStore
      sql.py                     # NEW — SQLAlchemyPolicyStore + SQLAlchemyTaskStore
      sql_relationship.py        # NEW — SQLAlchemyRelationshipStore
      sql_models.py              # NEW — SQLAlchemy table definitions (policies, tasks, relationship_tuples)
  __init__.py                    # MODIFY — export new public API

tests/
  unit/
    domain/
      test_entities.py           # MODIFY — add ReBAC entity tests
    adapters/
      evaluators/
        test_abac.py             # MODIFY — add OR/NOT/set operator tests
        test_rebac.py            # NEW — ReBAC evaluator tests
      stores/
        test_memory_relationship.py  # NEW
        test_sql_policy.py       # NEW — SQLAlchemy policy store tests
        test_sql_task.py         # NEW — SQLAlchemy task store tests
        test_sql_relationship.py # NEW — SQLAlchemy relationship store tests
  integration/
    test_rebac_integration.py    # NEW — end-to-end ReBAC through Guard
    test_sql_integration.py      # NEW — end-to-end with SQL stores
    test_abac_enhancements.py    # NEW — OR/NOT/set operators through Guard
```

## Scope

### In Scope

**ReBAC (ENH — new evaluator):**
- `RelationTuple` entity: `(object_type, object_id, relation, subject_type, subject_id, subject_relation)`
- `TypeDefinition` + `Permission` entities for schema definition
- `ReBACEvaluator` implementing `EvaluatorPort` with graph traversal
- Computed permissions: union (`+`), intersection (`&`), exclusion (`-`), arrow (`->`)
- Direct relations and subject sets (usersets / indirect membership)
- Wildcard support (`*` = all subjects of a type)
- Max depth limiting for cycle prevention (configurable, default 25)
- Result memoization within a single check traversal
- `RelationshipStorePort` + `InMemoryRelationshipStore`
- Check API: does subject have permission on object?
- Expand API: tree of subjects with a relation on an object

**SQLAlchemy stores:**
- `SQLAlchemyPolicyStore` implementing `PolicyStorePort`
- `SQLAlchemyTaskStore` implementing `TaskStorePort`
- `SQLAlchemyRelationshipStore` implementing `RelationshipStorePort`
- Typed normalized tables: `policies`, `tasks`, `relationship_tuples`
- `create_tables()` method for simple setup
- `from_url()` convenience constructor
- Consumer-owned engine pattern (accept `Engine` or `sessionmaker`)
- Row-level tenant isolation via `tenant_id` column
- `sqlalchemy.types.JSON` for conditions/metadata (dialect-portable)
- Multi-dialect: SQLite + PostgreSQL + MySQL
- Exportable `metadata` for consumer Alembic integration

**ABAC enhancements (ENH-004 + ENH-007):**
- Structural OR: `condition_groups` field — list of condition dicts, any match = pass
- Backward-compatible: existing `conditions` dict works as single group
- Negated operators: `not_contains`, `not_regex`
- Set operators: `contains_any`, `contains_all`, `is_subset`

### Out of Scope (Backlogged)

- Conditional relations / caveats on tuples (ABAC-in-ReBAC)
- ListObjects / ListSubjects reverse lookup APIs
- Consistency tokens (zookies) for distributed storage
- Alembic migrations shipped by library
- RBAC sessions / Separation of Duty (ENH-001–003)
- PIP / Obligations (ENH-008–009)
- Policy versioning / rollback
- General-purpose NOT wrapper on condition groups
- Soft-delete / audit trail on stores
- Watch/changelog API for tuple changes

## Deliverables

| Deliverable | Verification |
|-------------|-------------|
| ReBACEvaluator handles relationship-based policies | `pytest tests/unit/adapters/evaluators/test_rebac.py -v` |
| ReBAC graph traversal (union, intersection, exclusion, arrow) | `pytest tests/unit/adapters/evaluators/test_rebac.py -v -k graph` |
| InMemoryRelationshipStore CRUD | `pytest tests/unit/adapters/stores/test_memory_relationship.py -v` |
| ABAC OR/NOT/set operators | `pytest tests/unit/adapters/evaluators/test_abac.py -v` |
| SQLAlchemyPolicyStore (SQLite) | `pytest tests/unit/adapters/stores/test_sql_policy.py -v` |
| SQLAlchemyTaskStore (SQLite) | `pytest tests/unit/adapters/stores/test_sql_task.py -v` |
| SQLAlchemyRelationshipStore (SQLite) | `pytest tests/unit/adapters/stores/test_sql_relationship.py -v` |
| End-to-end ReBAC through Guard | `pytest tests/integration/test_rebac_integration.py -v` |
| End-to-end SQL stores through Guard | `pytest tests/integration/test_sql_integration.py -v` |
| End-to-end ABAC enhancements through Guard | `pytest tests/integration/test_abac_enhancements.py -v` |
| All existing tests pass (no regression) | `pytest -v` |
| Type safety | `mypy --strict src/` |
| Code quality | `ruff check src/ tests/` |
| >95% coverage | `pytest --cov=open_guard --cov-report=term-missing` |

## Acceptance Criteria

1. `ReBACEvaluator` implements `EvaluatorPort` and plugs into existing `PolicyRouter` with zero changes to RBAC/ABAC/TBAC code
2. ReBAC supports Zanzibar-style relation tuples, type definitions with computed permissions (union, intersection, exclusion, arrow), and max-depth cycle prevention
3. Wildcards work: `*` subject grants access to all subjects of that type
4. ABAC evaluator supports `condition_groups` for OR logic, with backward-compatible single-group fallback
5. ABAC evaluator supports `contains_any`, `contains_all`, `is_subset`, `not_contains`, `not_regex` operators
6. SQLAlchemy stores work on SQLite (in-memory for tests) with `create_tables()` setup
7. SQLAlchemy stores implement the same port interfaces as in-memory stores — drop-in replaceable
8. Row-level tenant isolation enforced on all SQL queries
9. Consumer-owned engine pattern: stores accept `Engine` and provide `from_url()` convenience
10. All existing 178 tests still pass (zero regression)
11. Tests: >95% coverage, `mypy --strict` clean, `ruff` clean

## Reference Specs

| Spec | Relevance |
|------|-----------|
| `specs/architecture/auth-model.md` | ReBAC section defines target model |
| Google Zanzibar (USENIX 2019) | Foundational ReBAC data model and algorithms |
| OpenFGA docs | Open-source Zanzibar reference implementation |
| SpiceDB docs | Schema language and permission computation patterns |
| XACML 3.0 (OASIS) | Policy combining algorithms (OR logic), set functions |
| Cedar (AWS) | Set operators (`containsAny`, `containsAll`), condition syntax |
| AWS IAM | Negated operators, `ForAnyValue`/`ForAllValues` set qualifiers |
| Casbin SQLAlchemy adapter | SQLAlchemy pattern for authorization policy storage |
| SQLAlchemy 2.0 docs | Multi-dialect best practices, JSON type portability |
