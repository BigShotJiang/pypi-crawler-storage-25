# Phase 2 — ReBAC + SQLAlchemy + ABAC Enhancements: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [DECISION] 2026-04-16 — Bundle ENH-004 + ENH-007 into Phase 2 (not a separate hardening sprint)
Topics: scope, abac, enhancements, project-management
Affects-phases: none
Affects-specs: specs/backlog/backlog.md
Detail: Industry research shows standalone "hardening sprints" are an Agile anti-pattern (Scrum.org, SAFe 5.1). Better to fold related enhancements into the next feature phase. ENH-004 (ABAC OR/NOT) and ENH-007 (set operators) strengthen the ABAC evaluator and directly benefit ReBAC policy writing. Bundled into Phase 2 as Option A.

---

### [DECISION] 2026-04-16 — Zanzibar-style relation tuples as ReBAC data model
Topics: rebac, zanzibar, data-model, relation-tuples
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#rebac
Detail: Research across Google Zanzibar, OpenFGA, SpiceDB, Ory Keto, Cedar, and Warrant confirms universal convergence on relation tuples: (object_type, object_id, relation, subject_type, subject_id, subject_relation). Adopted as open-guard's ReBAC data model. Type definitions with computed permissions (union, intersection, exclusion, arrow) follow SpiceDB/OpenFGA schema patterns.

---

### [DECISION] 2026-04-16 — Recursive subproblem decomposition for graph traversal (not BFS/DFS)
Topics: rebac, algorithm, graph-traversal, zanzibar
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#rebac
Detail: All Zanzibar-derived systems break a Check into sub-checks per schema rule. Union branches short-circuit on first YES, intersection on first NO, exclusion confirms base=YES and exclude=NO. Max depth limiting (configurable, default 25) prevents infinite traversal. Result memoization within a single check avoids re-checking the same subproblem.

---

### [DECISION] 2026-04-16 — Structural OR for ABAC conditions (not explicit OR operator)
Topics: abac, or-logic, xacml, cedar, opa
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#abac
Detail: Research across XACML, Cedar, OPA, and AWS IAM shows universal two-tier composition: AND within a rule/group, OR across rules/groups. Adding `condition_groups` field (list of condition dicts) where any group match = policy match. Existing `conditions` dict works as single group (backward-compatible). This is the XACML "multiple rules with permit-overrides" pattern.

---

### [DECISION] 2026-04-16 — Negated operators instead of general NOT wrapper
Topics: abac, negation, operators, aws-iam
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#abac
Detail: AWS IAM uses negated condition operators (`StringNotEquals`, `ArnNotLike`) rather than a general-purpose `not` wrapper. This avoids the complexity of arbitrary negation while covering all practical use cases. Adding `not_contains` and `not_regex` to the existing operator set. A general `not` wrapper can be added in a future phase if needed.

---

### [DECISION] 2026-04-16 — Set operators: contains_any, contains_all, is_subset
Topics: abac, set-operators, cedar, aws-iam, xacml
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#abac
Detail: Cedar `containsAny`/`containsAll`, AWS IAM `ForAnyValue`/`ForAllValues`, XACML `string-at-least-one-member-of`/`string-subset` are industry must-haves. `is_subset` covers the XACML subset check. `is_superset` deferred as it's equivalent to `contains_all` with flipped operands.

---

### [DECISION] 2026-04-16 — Consumer-owned engine with create_tables() for SQLAlchemy stores
Topics: sqlalchemy, policy-store, task-store, connection-management
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#design
Detail: Industry consensus: library accepts an Engine or sessionmaker, never creates one internally. Provide `from_url()` convenience for simple cases. Table creation via `metadata.create_all()` (Casbin pattern). No mandatory Alembic dependency — consumers can include our exportable metadata in their own Alembic env. Typed normalized tables (not Casbin's generic v0-v5).

---

### [DECISION] 2026-04-16 — Separate RelationshipStorePort for ReBAC tuple storage
Topics: rebac, store, port, separation-of-concerns
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#rebac
Detail: Relationship tuples are distinct from policies. Policies define rules; tuples define facts. Separate `RelationshipStorePort` follows the same pattern as `PolicyStorePort` and `TaskStorePort`. CRUD for tuples: write, delete, read (by object, by subject, by partial match). Tenant-scoped.

---

### [SCOPE_CHANGE] 2026-04-16 — Deferred: ListObjects/ListSubjects, caveats, consistency tokens
Topics: rebac, scope, deferral
Affects-phases: phase-3-policy-engine
Affects-specs: none
Detail: ListObjects/ListSubjects reverse lookups require streaming pipeline algorithms (expensive). Conditional relations/caveats add significant complexity. Consistency tokens only needed for distributed storage. All deferred to Phase 3+. Phase 2 focuses on the core Check flow.

---

### [ARCH_CHANGE] 2026-04-17 — ReBACEvaluator honors policy.action_match
Topics: rebac, action-matching, evaluator, policy-router
Affects-phases: none
Affects-specs: specs/architecture/auth-model.md#rebac
Detail: Added `_action_matches()` to `ReBACEvaluator` matching the pattern in ABACEvaluator. Required so multiple ReBAC policies (e.g. `can_view` for reads, `can_edit` for writes) can coexist per object type and only fire on the appropriate action. Discovered during Phase 2 integration tests when a `can_view` policy with default `action_match="*"` was allowing write requests. No breaking change — default remains `"*"`.

---

### [DECISION] 2026-04-17 — Application-level duplicate check for SQL relationship tuples
Topics: rebac, sqlalchemy, null-handling, duplicate-prevention
Affects-phases: none
Affects-specs: none
Detail: SQLite treats NULLs as distinct in UNIQUE constraints, so the DB-level uniqueness check on (tenant_id, object_type, object_id, relation, subject_type, subject_id, subject_relation) does not catch duplicates when `subject_relation IS NULL`. Added an application-level pre-check via `tuple_exists()` in `SQLAlchemyRelationshipStore.write_tuple()`. Matches the in-memory store behavior. Low cost (indexed lookup) and portable across dialects.

---
