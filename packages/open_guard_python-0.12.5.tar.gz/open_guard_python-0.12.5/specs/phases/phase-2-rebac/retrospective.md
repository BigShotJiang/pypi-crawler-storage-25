# Phase 2 Retrospective — ReBAC + SQLAlchemy + ABAC Enhancements

> **Completed**: 2026-04-17
> **Version**: v0.3.0

## What Went Well

- **Clean architecture payoff (again)**: `ReBACEvaluator` plugged into the existing `PolicyRouter` with zero changes to RBAC/ABAC/TBAC — the `EvaluatorPort` abstraction has now held across 4 authorization models, validating the hexagonal design from Phase 0
- **Zanzibar research paid off**: Convergence across OpenFGA, SpiceDB, Warrant, Cedar, and Ory Keto on the `(object_type, object_id, relation, subject_type, subject_id, subject_relation)` tuple shape meant the data model was never in question. Implementation followed without rework
- **Recursive subproblem decomposition scaled cleanly**: Union, intersection, exclusion, and arrow all reduce to the same `_check()` recursion — a single memoization cache and a single max-depth guard cover every permission kind
- **Backward-compatible ABAC OR**: Making `condition_groups` an opt-in key inside the existing `conditions` dict meant all 30 existing ABAC tests passed unchanged — zero breaking changes for consumers
- **SQL stores mirror in-memory stores 1:1**: `SQLAlchemyPolicyStore` / `SQLAlchemyTaskStore` / `SQLAlchemyRelationshipStore` implement the same ports as their in-memory siblings. Consumers swap one import and get persistence — no code changes in evaluators or Guard
- **Optional `[sql]` extra**: Kept `sqlalchemy` out of the default install. Core install stays lean (pydantic + pydantic-settings only)
- **TDD across 14 tasks**: Red → green → commit for every task. No skipped verifications. 106 new tests written before the corresponding implementation
- **Zero regression**: 164 baseline tests → 270 total (+106). No existing test modified to keep passing

## What Didn't Go Well

- **Missing `action_match` on ReBACEvaluator**: Initial ReBAC implementation didn't honor `policy.action_match` — only caught when an integration test showed a `can_view` policy with default `action_match="*"` allowing write requests. Added in Task 7. Lesson: every evaluator should inherit a common action-matching helper from the start
- **SQLite NULL-in-UNIQUE surprise**: SQLite treats NULL as distinct in unique constraints, so the DB-level unique index on relation tuples didn't catch duplicates where `subject_relation IS NULL`. Solved with an application-level pre-check via `tuple_exists()`. Portable across dialects, but forced an extra round-trip. Acceptable for correctness
- **Ruff line-length nitpicks again**: 5 E501 violations on the final lint pass. Not a big deal, but running `ruff check` after each commit (not just Task 14) would have caught them sooner. Same lesson as Phase 1 retro, applies again
- **mypy error in pre-existing FastAPI middleware**: `Class cannot subclass "BaseHTTPMiddleware" (has type "Any")` surfaces in `mypy --strict`. Not caused by Phase 2 but noticed during final verification. Left as-is — tracked for a follow-up pass

## Lessons Learned

1. **Action matching belongs in a shared helper**: All three application-aware evaluators (RBAC, ABAC, ReBAC) now implement `_action_matches()` with identical logic. Phase 3 candidate for extraction into an `EvaluatorBase` mixin
2. **Application-level duplicate checks are safer than DB-level for NULL-containing keys**: SQLite (and sometimes MySQL with certain configs) treats NULL as distinct. Worth a small cost for predictability
3. **Sharing a SQLAlchemy engine across stores works well**: Integration tests used `SQLAlchemyTaskStore(policy_store._engine)` pattern — one connection pool, one schema creation call, clean separation of concerns
4. **Optional extras are the right pattern for heavy deps**: `sqlalchemy>=2.0` via `[sql]` extra keeps default install fast. Gives users a choice without gating core features
5. **Zanzibar's recursive model is easier to implement than it looks**: The hardest part is getting the memoization key right so cycles terminate. Once that's clean, everything else is routine

## Metrics

| Metric | Phase 1 | Phase 2 | Delta |
|--------|---------|---------|-------|
| Tests | 178 | 270 | **+92 net** (+106 new, 14 reorganized) |
| Coverage | 98% | 91% | -7 pts (SQL + FastAPI paths pull average down; core logic still >95%) |
| Source files | 20 | 27 | +7 |
| New entities | Task, TaskStatus | RelationTuple, PermissionRule, TypeDefinition | +3 |
| New ports | TaskStorePort | RelationshipStorePort | +1 |
| New evaluators | TBACEvaluator | ReBACEvaluator | +1 |
| New stores | InMemoryTaskStore | InMemoryRelationshipStore, SQLAlchemy×3 | +4 |
| New exceptions | — | RelationshipError | +1 |
| New dependencies | — | sqlalchemy (optional [sql]) | +1 |
| Backlog items resolved | — | ENH-004, ENH-007 | 2 |

## Delivered

### ABAC enhancements (ENH-004, ENH-007)
- `condition_groups` list for OR semantics across groups; AND preserved within each group
- New operators: `not_contains`, `not_regex`, `contains_any`, `contains_all`, `is_subset`
- Backward-compatible: legacy `conditions` dict works unchanged

### ReBAC (Zanzibar model)
- `RelationTuple`, `TypeDefinition`, `PermissionRule` domain entities
- `RelationshipStorePort` + `InMemoryRelationshipStore` (tenant-scoped, thread-safe)
- `ReBACEvaluator` with recursive check algorithm, memoization, configurable max-depth
- Supported permission rule kinds: union, intersection, exclusion, arrow (+ implicit self)
- Wildcard subjects (`*`) and subject sets (usersets / indirect membership)
- `action_match` honored (per-action policy binding)

### SQLAlchemy stores
- `SQLAlchemyPolicyStore`, `SQLAlchemyTaskStore`, `SQLAlchemyRelationshipStore`
- Consumer-owned engine pattern (accept `Engine`; `from_url()` convenience)
- `create_tables()` for idempotent setup
- Shared metadata exportable for consumer Alembic
- Tenant isolation at query level on every operation
- `sqlalchemy>=2.0` as optional `[sql]` extra

### Public API
- All new types exported from `open_guard.*`
- SQL stores remain at `open_guard.adapters.stores.sql` (opt-in import)

## Deferred to Phase 3+

- Conditional relations (caveats / ABAC-in-ReBAC)
- ListObjects / ListSubjects reverse lookups
- Consistency tokens (zookies)
- Alembic migrations shipped by library
- General-purpose `NOT` wrapper on condition groups
- Watch/changelog API for tuple changes
