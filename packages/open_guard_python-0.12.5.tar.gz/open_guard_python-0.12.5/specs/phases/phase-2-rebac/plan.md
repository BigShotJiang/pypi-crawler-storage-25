# Phase 2 — ReBAC + SQLAlchemy + ABAC Enhancements: Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add ReBAC (Zanzibar model), SQLAlchemy persistence, and ABAC OR/NOT/set operators to open-guard.

**Architecture:** New `ReBACEvaluator` implements `EvaluatorPort` (same pattern as RBAC/ABAC/TBAC). New `RelationTuple` + `TypeDefinition` entities. New `RelationshipStorePort` for tuple storage. SQLAlchemy stores implement existing `PolicyStorePort`, `TaskStorePort`, and new `RelationshipStorePort`. ABAC enhancements are backward-compatible additions to `ABACEvaluator`.

**Tech Stack:** Python 3.12+, Pydantic v2 (frozen models), SQLAlchemy 2.0+ (async-compatible, but sync-first for Phase 2).

**Dependency:** Add `sqlalchemy>=2.0` to `pyproject.toml` (optional dependency group `[sql]`).

---

## Task 1: ABAC Enhancement — Set Operators (ENH-007)

**Files:**
- Modify: `src/open_guard/adapters/evaluators/abac.py`
- Modify: `tests/unit/adapters/evaluators/test_abac.py`

Start with the simplest enhancement — new operators that slot into the existing `_evaluate_operator` method.

- [ ] **Step 1: Write failing tests for set operators**

Add test class `TestABACSetOperators` to existing test file:

```python
class TestABACSetOperators:
    def test_contains_any_match(self) -> None:
        """At least one element overlaps."""
        # subject.tags = ["admin", "dev"], check contains_any ["admin", "ops"]
        # → True (admin overlaps)

    def test_contains_any_no_match(self) -> None:
        # subject.tags = ["dev"], check contains_any ["admin", "ops"] → False

    def test_contains_any_empty_actual(self) -> None:
        # subject.tags = [], check contains_any ["admin"] → False

    def test_contains_all_match(self) -> None:
        """All specified elements present."""
        # subject.certs = ["soc2", "hipaa", "gdpr"], check contains_all ["soc2", "hipaa"]
        # → True

    def test_contains_all_partial_match(self) -> None:
        # subject.certs = ["soc2"], check contains_all ["soc2", "hipaa"] → False

    def test_is_subset_true(self) -> None:
        """Left is subset of right."""
        # subject.roles = ["viewer"], check is_subset ["viewer", "editor", "admin"]
        # → True

    def test_is_subset_false(self) -> None:
        # subject.roles = ["viewer", "superadmin"], check is_subset ["viewer", "editor"]
        # → False

    def test_set_operators_with_non_list_actual(self) -> None:
        # Non-list attribute → False for all set ops
```

- [ ] **Step 2: Implement set operators in `_evaluate_operator`**

Add to `abac.py` `_evaluate_operator` method:

```python
if op == "contains_any":
    if not isinstance(actual, list) or not isinstance(expected, list):
        return False
    return bool(set(actual) & set(expected))
if op == "contains_all":
    if not isinstance(actual, list) or not isinstance(expected, list):
        return False
    return set(expected).issubset(set(actual))
if op == "is_subset":
    if not isinstance(actual, list) or not isinstance(expected, list):
        return False
    return set(actual).issubset(set(expected))
```

- [ ] **Step 3: Run tests, verify pass**
- [ ] **Step 4: Commit** — `feat(abac): add set operators — contains_any, contains_all, is_subset (ENH-007)`

---

## Task 2: ABAC Enhancement — Negated Operators + OR Logic (ENH-004)

**Files:**
- Modify: `src/open_guard/adapters/evaluators/abac.py`
- Modify: `tests/unit/adapters/evaluators/test_abac.py`

- [ ] **Step 1: Write failing tests for negated operators**

```python
class TestABACNegatedOperators:
    def test_not_contains_string(self) -> None:
        # subject.email = "alice@example.com", not_contains "evil.com" → True

    def test_not_contains_list(self) -> None:
        # subject.tags = ["admin", "dev"], not_contains "banned" → True

    def test_not_contains_fails(self) -> None:
        # subject.tags = ["banned", "dev"], not_contains "banned" → False

    def test_not_regex_match(self) -> None:
        # subject.email = "alice@company.com", not_regex ".*@evil\\.com" → True

    def test_not_regex_fails(self) -> None:
        # subject.email = "alice@evil.com", not_regex ".*@evil\\.com" → False
```

- [ ] **Step 2: Implement negated operators**

```python
if op == "not_contains":
    if isinstance(actual, (list, str)):
        return expected not in actual
    return True  # attribute doesn't contain anything
if op == "not_regex":
    if not isinstance(actual, str) or not isinstance(expected, str):
        return True
    return not bool(re.search(expected, actual))
```

- [ ] **Step 3: Write failing tests for OR logic (condition_groups)**

```python
class TestABACConditionGroups:
    def test_single_group_matches(self) -> None:
        """Single condition group — same as legacy AND."""
        # condition_groups: [{"subject.department": {"op": "eq", "value": "engineering"}}]
        # subject.department = "engineering" → True

    def test_any_group_matches_allows(self) -> None:
        """Multiple groups — OR semantics (any group match = pass)."""
        # Group 1: department=engineering → fails
        # Group 2: department=security → matches
        # → True (OR)

    def test_no_group_matches_denies(self) -> None:
        # Group 1: department=engineering → fails
        # Group 2: department=security → fails
        # subject.department = "marketing" → False

    def test_backward_compatible_conditions_dict(self) -> None:
        """Legacy 'conditions' dict works as single group (AND-only)."""
        # Use conditions={...} (not condition_groups) → works exactly as before

    def test_empty_condition_groups_matches(self) -> None:
        # No conditions → matches (same as existing behavior)

    def test_condition_groups_with_set_operators(self) -> None:
        """OR logic combined with set operators."""
        # Group 1: subject.tags contains_any ["admin"] → True
        # → matches on first group
```

- [ ] **Step 4: Implement OR logic via condition_groups**

Modify `_conditions_match` in `abac.py`:

```python
def _conditions_match(self, request: AuthorizationRequest, policy: Policy) -> bool:
    """Evaluate conditions with OR logic across groups, AND within each group."""
    condition_groups = policy.conditions.get("condition_groups")

    if condition_groups is not None:
        # New OR path: any group match = pass
        if not isinstance(condition_groups, list) or len(condition_groups) == 0:
            return True
        attr_map = self._build_attribute_map(request)
        return any(
            self._group_matches(attr_map, group)
            for group in condition_groups
        )

    # Legacy path: single conditions dict (AND logic, backward-compatible)
    if not policy.conditions:
        return True
    attr_map = self._build_attribute_map(request)
    return self._group_matches(attr_map, policy.conditions)

def _group_matches(self, attr_map: dict[str, Any], group: dict[str, Any]) -> bool:
    """All conditions in a group must match (AND logic)."""
    for path, condition in group.items():
        if path == "condition_groups":
            continue  # skip the meta-key
        if not isinstance(condition, dict):
            actual = self._resolve_path(attr_map, path)
            if actual != condition:
                return False
            continue
        op = condition.get("op", "eq")
        expected = condition.get("value")
        actual = self._resolve_path(attr_map, path)
        if not self._evaluate_operator(op, actual, expected):
            return False
    return True
```

- [ ] **Step 5: Run all tests, verify pass (including existing ABAC tests — no regression)**
- [ ] **Step 6: Commit** — `feat(abac): add OR logic via condition_groups and negated operators (ENH-004)`

---

## Task 3: ABAC Enhancement — Integration Tests

**Files:**
- Create: `tests/integration/test_abac_enhancements.py`

- [ ] **Step 1: Write integration tests**

Test OR logic, set operators, and negated operators through Guard end-to-end:
- OR condition_groups allowing access when one group matches
- Set operators (contains_any, contains_all) in real policies
- Negated operators blocking access
- Combined with RBAC/TBAC evaluators

- [ ] **Step 2: Run tests, verify pass**
- [ ] **Step 3: Commit** — `test: add ABAC enhancement integration tests`

---

## Task 4: ReBAC Domain Entities

**Files:**
- Modify: `src/open_guard/domain/entities.py`
- Modify: `tests/unit/domain/test_entities.py`

- [ ] **Step 1: Write failing tests for ReBAC entities**

```python
class TestRelationTuple:
    def test_create_direct_relation(self) -> None:
        # document:readme#viewer@user:alice
        tuple = RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="readme",
            relation="viewer",
            subject_type="user", subject_id="alice",
        )
        assert tuple.subject_relation is None  # direct

    def test_create_subject_set(self) -> None:
        # document:readme#viewer@group:devs#member
        tuple = RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="readme",
            relation="viewer",
            subject_type="group", subject_id="devs",
            subject_relation="member",
        )
        assert tuple.subject_relation == "member"

    def test_create_wildcard(self) -> None:
        # document:readme#viewer@user:*
        tuple = RelationTuple(
            tenant_id="t1",
            object_type="document", object_id="readme",
            relation="viewer",
            subject_type="user", subject_id="*",
        )

    def test_relation_tuple_is_frozen(self) -> None:
        # frozen Pydantic model

class TestTypeDefinition:
    def test_create_type_definition(self) -> None:
        td = TypeDefinition(
            name="document",
            relations={"owner": ..., "editor": ..., "viewer": ...},
            permissions={"can_edit": ..., "can_view": ...},
        )

class TestPermission:
    def test_union_permission(self) -> None:
        # can_view = editor + viewer (union)

    def test_intersection_permission(self) -> None:
        # can_view = viewer & org_member (intersection)

    def test_exclusion_permission(self) -> None:
        # can_view = viewer - banned (exclusion)

    def test_arrow_permission(self) -> None:
        # can_view = parent->can_view (traverse relation, check permission)
```

- [ ] **Step 2: Implement ReBAC entities**

Add to `entities.py`:

```python
class RelationTuple(Entity):
    """A relationship fact: object#relation@subject[#subject_relation]."""
    id: str = Field(default_factory=lambda: str(uuid4()))
    tenant_id: str
    object_type: str
    object_id: str
    relation: str
    subject_type: str
    subject_id: str  # "*" = wildcard (all subjects of type)
    subject_relation: str | None = None  # For subject sets (usersets)

class PermissionRule(Entity):
    """A computed permission rule within a type definition."""
    kind: str  # "self" | "union" | "intersection" | "exclusion" | "arrow"
    relations: list[str] = []  # For union/intersection/exclusion
    base: str | None = None  # For exclusion: base relation
    subtract: str | None = None  # For exclusion: relation to subtract
    from_relation: str | None = None  # For arrow: walk this relation...
    to_permission: str | None = None  # ...then check this permission

class TypeDefinition(Entity):
    """Defines a type, its relations, and computed permissions."""
    name: str
    relations: dict[str, list[str]]  # relation_name -> allowed subject types
    permissions: dict[str, PermissionRule] = {}  # permission_name -> rule
```

- [ ] **Step 3: Run tests, verify pass**
- [ ] **Step 4: Commit** — `feat(domain): add ReBAC entities — RelationTuple, TypeDefinition, PermissionRule`

---

## Task 5: RelationshipStorePort + InMemoryRelationshipStore

**Files:**
- Create: `src/open_guard/domain/ports/relationship_store.py`
- Create: `src/open_guard/adapters/stores/memory_relationship.py`
- Create: `tests/unit/adapters/stores/test_memory_relationship.py`

- [ ] **Step 1: Write failing tests for InMemoryRelationshipStore**

Test CRUD operations:
- write_tuple / delete_tuple
- read_tuples (by object, by subject, by partial filter)
- get_subjects_for_relation (object_type, object_id, relation, tenant_id)
- get_objects_for_subject (subject_type, subject_id, relation, tenant_id)
- Tenant isolation
- Duplicate tuple prevention

- [ ] **Step 2: Implement RelationshipStorePort**

```python
class RelationshipStorePort(ABC):
    @abstractmethod
    def write_tuple(self, tuple: RelationTuple) -> RelationTuple: ...
    @abstractmethod
    def delete_tuple(self, tuple_id: str, tenant_id: str) -> None: ...
    @abstractmethod
    def read_tuples(self, tenant_id: str, object_type: str | None = None,
                    object_id: str | None = None, relation: str | None = None,
                    subject_type: str | None = None, subject_id: str | None = None,
                    ) -> list[RelationTuple]: ...
    @abstractmethod
    def tuple_exists(self, tenant_id: str, object_type: str, object_id: str,
                     relation: str, subject_type: str, subject_id: str,
                     subject_relation: str | None = None) -> bool: ...
```

- [ ] **Step 3: Implement InMemoryRelationshipStore**
- [ ] **Step 4: Run tests, verify pass**
- [ ] **Step 5: Commit** — `feat(adapters): add RelationshipStorePort and InMemoryRelationshipStore`

---

## Task 6: ReBACEvaluator — Core Graph Traversal

**Files:**
- Create: `src/open_guard/adapters/evaluators/rebac.py`
- Create: `tests/unit/adapters/evaluators/test_rebac.py`

This is the most complex task. The evaluator takes a `RelationshipStorePort` and a dict of `TypeDefinition`s, and evaluates ReBAC policies via graph traversal.

- [ ] **Step 1: Write failing tests for ReBACEvaluator**

```python
class TestReBACEvaluatorSupports:
    def test_supports_rebac_policy(self) -> None: ...

class TestReBACDirectRelations:
    def test_direct_relation_allows(self) -> None:
        # Tuple: document:readme#viewer@user:alice
        # Check: can user:alice view document:readme? → True

    def test_no_relation_denies(self) -> None:
        # No tuple → False

    def test_wrong_relation_denies(self) -> None:
        # Tuple: document:readme#viewer@user:alice
        # Check: can user:alice edit document:readme? → False

class TestReBACWildcard:
    def test_wildcard_allows_any_subject(self) -> None:
        # Tuple: document:readme#viewer@user:*
        # Check: can user:bob view document:readme? → True

class TestReBACSubjectSets:
    def test_subject_set_indirect_membership(self) -> None:
        # Tuples:
        #   document:readme#viewer@group:devs#member
        #   group:devs#member@user:alice
        # Check: can user:alice view document:readme? → True (via group membership)

class TestReBACComputedPermissions:
    def test_union_permission(self) -> None:
        # TypeDef: document { permission can_view = editor + viewer }
        # Tuple: document:readme#editor@user:alice
        # Check: can user:alice can_view document:readme? → True (via editor union)

    def test_intersection_permission(self) -> None:
        # TypeDef: document { permission can_view = viewer & org_member }
        # Tuples: document:readme#viewer@user:alice, document:readme#org_member@user:alice
        # Check: → True (both hold)
        # Remove org_member tuple → False

    def test_exclusion_permission(self) -> None:
        # TypeDef: document { permission can_view = viewer - banned }
        # Tuples: document:readme#viewer@user:alice
        # Check: → True
        # Add document:readme#banned@user:alice → False

    def test_arrow_permission(self) -> None:
        # TypeDef: document { relation parent: folder; permission can_view = parent->can_view }
        # TypeDef: folder { permission can_view = viewer }
        # Tuples: document:readme#parent@folder:engineering, folder:engineering#viewer@user:alice
        # Check: can user:alice can_view document:readme? → True (traverse parent → check can_view on folder)

class TestReBACMaxDepth:
    def test_max_depth_prevents_infinite_recursion(self) -> None:
        # Create circular references, verify traversal stops at max_depth

class TestReBACDenyOverride:
    def test_deny_policy_overrides_allow(self) -> None:
        # ReBAC deny policy at same/higher priority overrides allow
```

- [ ] **Step 2: Implement ReBACEvaluator**

Key implementation details:
- Constructor: `ReBACEvaluator(relationship_store, type_definitions, max_depth=25)`
- `supports()`: returns `policy.evaluator_type == "rebac"`
- `evaluate()`: for each matching policy, extract the check parameters and run `_check()`
- `_check(object_type, object_id, permission_or_relation, subject_type, subject_id, depth, memo)`:
  1. Check memo cache for this subproblem
  2. Check depth limit
  3. Check direct tuples (including wildcards)
  4. If permission exists in TypeDefinition.permissions, resolve via PermissionRule:
     - `self`: check if relation exists directly
     - `union`: any sub-relation holds → True
     - `intersection`: all sub-relations hold → True
     - `exclusion`: base holds AND subtract doesn't → True
     - `arrow`: walk `from_relation` to get target objects, then check `to_permission` on each
  5. Check subject sets: find tuples where subject has a subject_relation, then check if the requesting subject has that relation on the subject entity

- [ ] **Step 3: Run tests, verify pass**
- [ ] **Step 4: Commit** — `feat(adapters): add ReBACEvaluator with Zanzibar-style graph traversal`

---

## Task 7: ReBAC Integration Tests

**Files:**
- Create: `tests/integration/test_rebac_integration.py`

- [ ] **Step 1: Write integration tests through Guard**

Test real-world scenarios:
- Google Drive-style: user owns doc → can edit → can view (role hierarchy via union)
- Team membership: user in group → group has access → user has access (subject sets)
- Organization-wide: folder viewer = folder.viewer + parent_folder->viewer (arrow traversal)
- Deny override: user is viewer but also banned → denied
- Combined: RBAC admin + ReBAC relationship checks in same request

- [ ] **Step 2: Run tests, verify pass**
- [ ] **Step 3: Commit** — `test: add ReBAC integration tests through Guard`

---

## Task 8: SQLAlchemy Table Definitions

**Files:**
- Create: `src/open_guard/adapters/stores/sql_models.py`
- Modify: `pyproject.toml` — add `sqlalchemy>=2.0` optional dependency

- [ ] **Step 1: Add SQLAlchemy optional dependency**

In `pyproject.toml`, add optional dependency group:
```toml
[project.optional-dependencies]
sql = ["sqlalchemy>=2.0"]
```

- [ ] **Step 2: Define SQLAlchemy table models**

```python
# sql_models.py
from sqlalchemy import Column, DateTime, Index, Integer, MetaData, String, Table, Text
from sqlalchemy.types import JSON

metadata = MetaData()

policies_table = Table(
    "open_guard_policies", metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("evaluator_type", String(32), nullable=False),
    Column("subject_match", JSON, nullable=False, default={}),
    Column("action_match", JSON, nullable=False, default="*"),
    Column("resource_match", JSON, nullable=False, default={}),
    Column("conditions", JSON, nullable=False, default={}),
    Column("effect", String(16), nullable=False, default="allow"),
    Column("priority", Integer, nullable=False, default=0),
    Index("ix_policies_tenant_type", "tenant_id", "evaluator_type"),
)

tasks_table = Table(
    "open_guard_tasks", metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("actor_id", String(256), nullable=False),
    Column("actor_type", String(32), nullable=False, default="agent"),
    Column("parent_task_id", String(36), nullable=True),
    Column("status", String(32), nullable=False, default="created"),
    Column("allowed_actions", JSON, nullable=False),
    Column("allowed_resource_types", JSON, nullable=False),
    Column("created_at", DateTime, nullable=False),
    Column("activated_at", DateTime, nullable=True),
    Column("expires_at", DateTime, nullable=True),
    Column("completed_at", DateTime, nullable=True),
    Column("metadata_", JSON, nullable=False, default={}),
    Index("ix_tasks_tenant_actor", "tenant_id", "actor_id"),
    Index("ix_tasks_tenant_status", "tenant_id", "status"),
)

relationship_tuples_table = Table(
    "open_guard_relationship_tuples", metadata,
    Column("id", String(36), primary_key=True),
    Column("tenant_id", String(128), nullable=False, index=True),
    Column("object_type", String(128), nullable=False),
    Column("object_id", String(256), nullable=False),
    Column("relation", String(128), nullable=False),
    Column("subject_type", String(128), nullable=False),
    Column("subject_id", String(256), nullable=False),
    Column("subject_relation", String(128), nullable=True),
    Index("ix_tuples_object", "tenant_id", "object_type", "object_id", "relation"),
    Index("ix_tuples_subject", "tenant_id", "subject_type", "subject_id"),
    # Unique constraint: no duplicate tuples
    Index("ix_tuples_unique", "tenant_id", "object_type", "object_id", "relation",
          "subject_type", "subject_id", "subject_relation", unique=True),
)
```

- [ ] **Step 3: Run existing tests (no regression — SQLAlchemy is optional)**
- [ ] **Step 4: Commit** — `feat(adapters): add SQLAlchemy table definitions for policies, tasks, and tuples`

---

## Task 9: SQLAlchemyPolicyStore

**Files:**
- Create: `src/open_guard/adapters/stores/sql.py`
- Create: `tests/unit/adapters/stores/test_sql_policy.py`

- [ ] **Step 1: Write failing tests for SQLAlchemyPolicyStore**

Use SQLite in-memory (`sqlite://`) for all tests:
- add and get_by_tenant
- get_by_tenant_and_type
- remove
- tenant isolation
- from_url convenience constructor
- create_tables method

- [ ] **Step 2: Implement SQLAlchemyPolicyStore**

```python
class SQLAlchemyPolicyStore(PolicyStorePort):
    def __init__(self, engine: Engine) -> None:
        self._engine = engine

    @classmethod
    def from_url(cls, url: str, **kwargs: Any) -> SQLAlchemyPolicyStore:
        engine = create_engine(url, **kwargs)
        return cls(engine)

    def create_tables(self) -> None:
        metadata.create_all(self._engine)

    # Implement all PolicyStorePort methods using raw SQL via engine.connect()
    # Serialize Policy ↔ row using JSON for dict fields
```

- [ ] **Step 3: Run tests, verify pass**
- [ ] **Step 4: Commit** — `feat(adapters): add SQLAlchemyPolicyStore`

---

## Task 10: SQLAlchemyTaskStore

**Files:**
- Modify: `src/open_guard/adapters/stores/sql.py` (or new file `sql_task.py`)
- Create: `tests/unit/adapters/stores/test_sql_task.py`

- [ ] **Step 1: Write failing tests for SQLAlchemyTaskStore**

Same tests as InMemoryTaskStore but using SQLite in-memory:
- add, get, update, get_active_by_actor, remove
- tenant isolation

- [ ] **Step 2: Implement SQLAlchemyTaskStore**

Same pattern as SQLAlchemyPolicyStore. Serialize Task ↔ row.

- [ ] **Step 3: Run tests, verify pass**
- [ ] **Step 4: Commit** — `feat(adapters): add SQLAlchemyTaskStore`

---

## Task 11: SQLAlchemyRelationshipStore

**Files:**
- Create: `src/open_guard/adapters/stores/sql_relationship.py`
- Create: `tests/unit/adapters/stores/test_sql_relationship.py`

- [ ] **Step 1: Write failing tests for SQLAlchemyRelationshipStore**

Same tests as InMemoryRelationshipStore but using SQLite in-memory.

- [ ] **Step 2: Implement SQLAlchemyRelationshipStore**
- [ ] **Step 3: Run tests, verify pass**
- [ ] **Step 4: Commit** — `feat(adapters): add SQLAlchemyRelationshipStore`

---

## Task 12: SQL Integration Tests

**Files:**
- Create: `tests/integration/test_sql_integration.py`

- [ ] **Step 1: Write integration tests**

End-to-end through Guard with SQLAlchemy stores:
- RBAC + ABAC + TBAC + ReBAC all using SQL stores
- Full authorization flow: create policies via SQL store, authorize via Guard
- Task lifecycle with SQLAlchemy task store
- ReBAC with SQLAlchemy relationship store

- [ ] **Step 2: Run tests, verify pass**
- [ ] **Step 3: Commit** — `test: add SQL store integration tests`

---

## Task 13: Public API Exports + RelationshipError

**Files:**
- Modify: `src/open_guard/__init__.py`
- Modify: `src/open_guard/domain/exceptions.py`

- [ ] **Step 1: Add RelationshipError exception**

```python
class RelationshipError(OpenGuardError):
    """Raised for relationship tuple errors (not found, duplicate)."""
```

- [ ] **Step 2: Update public API exports**

Add to `__init__.py`:
```python
from open_guard.adapters.evaluators.rebac import ReBACEvaluator
from open_guard.adapters.stores.memory_relationship import InMemoryRelationshipStore
from open_guard.domain.entities import RelationTuple, TypeDefinition, PermissionRule
from open_guard.domain.exceptions import RelationshipError
from open_guard.domain.ports.relationship_store import RelationshipStorePort
```

SQL stores are optional — import conditionally or document as separate import:
```python
# Users install with: pip install open-guard[sql]
# Then import: from open_guard.adapters.stores.sql import SQLAlchemyPolicyStore
```

- [ ] **Step 3: Run all tests, verify pass**
- [ ] **Step 4: Commit** — `feat: add ReBAC + SQL public API exports`

---

## Task 14: Final Verification + Cleanup

- [ ] **Step 1: Run full test suite** — `pytest -v --tb=short`
- [ ] **Step 2: Run mypy strict** — `mypy --strict src/`
- [ ] **Step 3: Run ruff** — `ruff check src/ tests/`
- [ ] **Step 4: Run coverage** — `pytest --cov=open_guard --cov-report=term-missing`
- [ ] **Step 5: Fix any issues found in steps 1-4**
- [ ] **Step 6: Verify backward compatibility** — all 178 existing tests pass unchanged
- [ ] **Step 7: Final commit** — `chore: phase 2 final cleanup and verification`
