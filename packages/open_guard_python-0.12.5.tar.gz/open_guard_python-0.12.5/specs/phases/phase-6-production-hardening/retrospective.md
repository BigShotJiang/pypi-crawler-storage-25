# Phase 6 — Production Hardening: Retrospective

> **Completed**: 2026-04-19
> **Version**: v0.7.0
> **Tests**: 806 (+94 from Phase 5 baseline of 712, plus pre-existing ruff fixes)
> **Coverage**: 97%
> **Breaking changes**: None

---

## What Was Delivered

- **RBAC Sessions (ENH-001)**: `Session` + `SessionStatus` entities; `SessionError`/`SessionNotFoundError`/`SessionExpiredError`; `SessionStorePort` ABC; `InMemorySessionStore` (thread-safe RLock); `SQLAlchemySessionStore` + `session_table`; `SessionManager` (create_session, get_session, deactivate, expire_stale); session-aware `RBACEvaluator._get_subject_roles`; `session.*` ABAC attribute namespace; `Guard.authorize(session_id=...)` with lazy expiry + context injection; multiple concurrent sessions per subject; fail-open on expired/deactivated sessions
- **Policy Isolation (FEAT-010)**: `ReadOnlyPolicyView` auto-wired in `PolicyRouter.__init__`; `_trusted: {attr_name: False}` taint marking convention; `trusted_only: True` ABAC condition modifier; `_is_untrusted` walks nested attribute paths; 10-scenario adversarial test suite (`test_prompt_injection.py`)
- **Push Revocation (ENH-010)**: `RevocationEvent` + `RevocationEventType` entities; `RevocationStreamPort` ABC (publish/subscribe/unsubscribe); `InMemoryRevocationStream` (synchronous callback pub/sub, snapshot-before-invoke); event emission from `SessionManager.deactivate()` (`SESSION_DEACTIVATED`) and `DelegationManager.revoke()` (`DELEGATION_REVOKED`); `Guard` wired with `revocation_stream`
- **ADRs**: ADR-0006 (RBAC sessions), ADR-0007 (policy isolation), ADR-0008 (push revocation) — all with prior-art citations
- **Integration guide**: Phase 6 section with 7 executable mirror tests (`test_integration_guide_phase6_examples.py`)
- **Refactor**: extracted `Guard._resolve_session` helper (DRY across 3 methods); fixed `InMemoryRevocationStream.publish()` callback-under-lock hazard
- **Pre-existing ruff cleanup**: 166 violations across Phase 1-5 test files fixed as part of T18 quality gate

---

## What Went Well

### Clean three-deliverable structure
Phase 6 had three independent deliverables (Sessions, Policy Isolation, Push Revocation) that could be implemented in strict sequence with no cross-deliverable entanglement. Each deliverable followed the established port/adapter hexagonal pattern without requiring new architectural patterns. Implementation was mechanical — the planning work done in brainstorm eliminated all major design questions upfront.

### Subagent-driven development speed
Using fresh subagents per task with two-stage review (spec + quality) kept each task focused and caught issues early. Most tasks were implemented correctly on the first attempt. The few issues that did arise (wrong exception names in ADR-0006, fabricated method in ADR-0007, lock scope in revocation stream) were caught by the code quality reviewer and fixed before any downstream tasks were affected.

### Zero breaking changes maintained through 18 tasks
All 712 Phase 5 tests passed unchanged throughout. Session, isolation, and revocation are all strictly additive — each requires explicit opt-in (`session_id=`, `_trusted=`, `revocation_stream=`). Consumers without these features see identical behavior.

### ADR quality
Three ADRs written after implementation (not before) let them document what was actually built, not what was planned. The code quality reviewer caught five accuracy issues (wrong exception name, wrong method name, Guard behavior overstatement, fabricated snippet, wiring scope) that were fixed before commit. Final ADRs are accurate to the implementation.

### Policy isolation two-layer defense
`ReadOnlyPolicyView` wired automatically in `PolicyRouter.__init__` (structural defense) + `trusted_only` taint checking (attribute-level defense) compose cleanly. The adversarial test suite (`test_prompt_injection.py`) validated 10 attack scenarios without discovering any gaps in the implementation.

---

## What Didn't Go Well

### Pre-existing ruff violations discovered at T18
166 ruff violations in Phase 1-5 test files were discovered during T18's quality gate. These were not introduced by Phase 6, but the `ruff check src/ tests/` requirement meant they had to be fixed. This added ~1 extra task worth of cleanup. Running quality gates at the start of each phase would surface these earlier.

### T16 ADR accuracy required two fix rounds
The ADR implementer introduced five accuracy errors (wrong exception/method names, overstatement about Guard behavior, fabricated `ReadOnlyPolicyView` snippet, incorrect revocation stream wiring description). The code quality reviewer caught all five, but the extra round of fixes added latency. For ADRs written post-implementation, providing the exact method/exception names and API surface in the dispatch prompt would avoid this.

### Cascade revocation events not emitted for descendants
`DelegationManager.revoke()` emits `DELEGATION_REVOKED` only for the root delegation. Sub-delegations are cascade-revoked by the store but no events are published for them. Subscribers watching a descendant subject will not be notified. Tracked as ENH-018; documented in ADR-0008 Consequences.

### Plan test file paths were wrong
`plan.md` specified flat test paths (`tests/unit/test_*.py`) but the project convention is subdirectory-based (`tests/unit/domain/`, `tests/unit/adapters/stores/`, etc.). This had to be corrected at the start of each task. Updating `plan.md` test paths to match actual convention would prevent this pattern recurring.

---

## Lessons Learned

1. **Run `ruff check src/ tests/` before starting a phase, not just at the end.** Accumulated lint debt from previous phases shows up at the worst time — during a phase-completion quality gate. A pre-phase lint sweep costs nothing and prevents surprise cleanup tasks.

2. **For post-implementation ADRs, provide exact API signatures in the dispatch prompt.** The implementer will fabricate plausible-but-wrong method names and exception names without them. The code quality reviewer catches these, but the round-trip wastes tokens.

3. **Snapshot-before-callback is the correct observer pattern.** `InMemoryRevocationStream.publish()` originally invoked callbacks while holding the lock — a latency hazard. The fix (snapshot subscribers under lock, invoke outside) is the standard pattern for all in-process pub/sub implementations.

4. **`ReadOnlyPolicyView` as a wrapper (not interface segregation) was the right choice.** Alternatives considered — a separate `ReadPolicyPort` / `WritePolicyPort` split, or deep-copying policies before evaluation — would have broken existing consumer code or added unnecessary overhead. Wrapping at the `PolicyRouter` level is transparent and correctly localized.

5. **Three-deliverable independence is a real advantage.** When T12 (revocation entity) was combined with T13-T15 into one subagent dispatch, the implementer completed all four tasks cleanly because they had no interaction with T1-T11. Partitioning phase work by independent deliverable (not just by layer) reduces mid-task context load.

6. **Fail-open on expired sessions is the correct default.** A session expiring mid-request should not suddenly deny access — that would be worse than stale authorization. The fall-through to full roles is consistent with how expiry works for delegations (evaluated lazily, not as an interrupt). This is a security policy decision by the consumer, not an open-guard enforcement point.
