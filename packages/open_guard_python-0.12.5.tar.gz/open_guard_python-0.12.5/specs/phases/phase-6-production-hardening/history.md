# Phase 6 — Production Hardening: Implementation History

> Append-only log. Do NOT edit existing entries.
> Claude appends automatically when significant changes occur (Rule 8).
> Use `/log <message>` to add a manual entry at any time.

## Entry Types
| Type | When to use |
|------|------------|
| [DECISION] | ADR created or updated, technology choice made |
| [SCOPE_CHANGE] | Phase deliverables added, removed, or reprioritized |
| [DISCOVERY] | Bug, tech debt, or enhancement found |
| [FEATURE] | New planned feature added to this phase |
| [ARCH_CHANGE] | Architectural pattern or integration changed |
| [EVALUATOR] | Locked evaluator defined or evaluation set changed |
| [NOTE] | Anything else worth recording |

## Entries

### [SCOPE_CHANGE] 2026-04-19 — Phase 6 replaces "External Adapters & DSL" with production hardening
Topics: scope, phase-theme, roadmap, external-adapters
Affects-phases: phase-6-production-hardening
Affects-specs: specs/planning/roadmap.md, specs/status.md
Detail: Original Phase 6 (External Adapters & DSL — Casbin/OPA/OpenFGA adapters, policy DSL, service mode) replaced entirely. External adapters dropped — open-guard builds all four authorization models from scratch (explicit decision). Policy DSL dropped — tenants use a console UI that sends structured API calls, not text files; Pydantic models serialize to JSON. Service mode deferred to a later phase (FEAT-012). New Phase 6 scope: ENH-001 (RBAC sessions), FEAT-010 (prompt-injection policy isolation), ENH-010 (CAEP push revocation).

---

### [DECISION] 2026-04-19 — Session as first-class entity, not Subject.metadata
Topics: session, entity-shape, rbac, nist
Affects-phases: phase-6-production-hardening
Affects-specs: specs/decisions/0006-rbac-sessions.md (to be written T16)
Detail: Chose a dedicated `Session` entity + `SessionStorePort` over storing session state in `Subject.metadata`. Rationale: (1) sessions have their own lifecycle (ACTIVE → DEACTIVATED → EXPIRED) independent of the Subject; (2) multiple concurrent sessions per subject needed (different scopes/contexts); (3) SessionStorePort follows the established rule-vs-state separation (same pattern as ApprovalStorePort, DelegationStorePort); (4) NIST Core RBAC defines sessions as a distinct concept. Prior art: NIST RBAC (Sandhu et al. 2000), AWS IAM session policies, Google Cloud Workload Identity sessions.

---

### [DECISION] 2026-04-19 — Multiple concurrent sessions per subject allowed
Topics: session, concurrency, scope
Affects-phases: phase-6-production-hardening
Affects-specs: specs/decisions/0006-rbac-sessions.md
Detail: An actor can have multiple ACTIVE sessions simultaneously — e.g., one session at PROJECT scope activating [editor, viewer], another at WORKSPACE scope activating [workspace:validator]. This maps directly to cerebrio-sapience's epistemic scopes where an agent may operate across scopes concurrently. `SessionStorePort.get_active_for_subject()` returns a list. Guard resolves a specific session via `session_id` parameter.

---

### [DECISION] 2026-04-19 — session.* ABAC attribute namespace (mirrors chain.* from Phase 3)
Topics: session, abac, namespace, scope-aware-policies
Affects-phases: phase-6-production-hardening
Affects-specs: specs/decisions/0006-rbac-sessions.md, specs/architecture/auth-model.md
Detail: ABAC evaluator builds a `session.*` attribute namespace from `request.context["_session"]` — mirrors the `chain.*` namespace added in Phase 3. Exposes: `session.activated_roles`, `session.status`, `session.id`, plus all keys from `session.metadata` (e.g., `session.scope`). Enables policies like `{"session.scope": {"op": "eq", "value": "WORKSPACE"}}` — cerebrio defines scope semantics; open-guard provides the mechanism.

---

### [DECISION] 2026-04-19 — Guard session resolution via context injection, not evaluator parameter
Topics: session, guard, context, evaluator-contract
Affects-phases: phase-6-production-hardening
Affects-specs: specs/decisions/0006-rbac-sessions.md
Detail: Guard resolves `session_id` → Session entity and injects it into `request.context["_session"]` before evaluation. Evaluators read the session from context — no change to `EvaluatorPort.evaluate(request, policies)` signature. Same pattern used for clock injection and delegation re-check flags. Preserves evaluator port contract stability.

---

### [DECISION] 2026-04-19 — ReadOnlyPolicyView for evaluation-path isolation
Topics: policy-isolation, prompt-injection, security
Affects-phases: phase-6-production-hardening
Affects-specs: specs/decisions/0007-policy-isolation.md (to be written T16)
Detail: PolicyRouter wraps the PolicyStorePort in a `ReadOnlyPolicyView` that exposes `get_by_tenant` and `get_by_tenant_and_type` but raises `AttributeError` on `add`/`remove`. Evaluators receive policies through this view — the evaluation path cannot mutate policies. Structural defense: even if LLM-generated input reaches the evaluator, it cannot write back to the policy store. Rejected: (a) interface segregation (separate ReadPolicyPort/WritePolicyPort) — breaks existing consumer code; (b) copy-on-read (deep copy policies before evaluation) — unnecessary overhead, policies are frozen Pydantic models.

---

### [DECISION] 2026-04-19 — Taint marking via _trusted convention + trusted_only modifier
Topics: taint, prompt-injection, abac, security
Affects-phases: phase-6-production-hardening
Affects-specs: specs/decisions/0007-policy-isolation.md
Detail: Attributes sourced from LLM output carry `_trusted: {attr_name: False}` on their parent dict (Subject.attributes, Resource.attributes). ABAC conditions gain an optional `trusted_only: True` flag — when set, the evaluator checks `_trusted` and rejects the condition if the leaf attribute is marked untrusted. Convention-based (not enforced at entity level) — consumers decide which attributes to taint. Rejected: (a) separate TaintedAttribute wrapper type — breaks existing dict-based attribute patterns; (b) global trust level on Subject — too coarse, individual attributes need independent trust.

---

### [DECISION] 2026-04-19 — RevocationStreamPort as callback-based pub/sub
Topics: revocation, push, caep, events
Affects-phases: phase-6-production-hardening
Affects-specs: specs/decisions/0008-push-revocation.md (to be written T16)
Detail: RevocationStreamPort uses a callback-based pub/sub model: `subscribe(tenant_id, callback, subject_id=None) → subscription_id`. Events are delivered synchronously in-process (InMemoryRevocationStream). Subscribers can filter by tenant + optional subject. Event types: delegation_revoked, delegation_expired, session_deactivated, policy_removed. Rejected: (a) async event bus (asyncio, celery) — adds dependency, open-guard stays sync-first; (b) webhook-based push — transport concern, consumer wraps the callback; (c) polling API — defeats the purpose of push.

---

### [SCOPE_CHANGE] 2026-04-19 — New backlog items: FEAT-011, FEAT-012, FEAT-013
Topics: backlog, management-apis, service-mode, sdks
Affects-phases: none (future phases)
Affects-specs: specs/backlog/backlog.md
Detail: Three new features added to backlog for post-Phase-6 phases: FEAT-011 (Management APIs — Role/Policy/Delegation/Relationship CRUD with tenant scoping, for the tenant console), FEAT-012 (Service Mode — HTTP/gRPC wrapper for cross-language consumption), FEAT-013 (Language SDKs — thin HTTP clients in Python/TS/Go). These arise from the brainstorm discussion about cerebrio-sapience deployment (monorepo, multi-service, future non-Python services, tenant console).

---

### [NOTE] 2026-04-19 — Epistemic scopes model validated against Phase 6 design
Topics: cerebrio, epistemic-scopes, validation
Affects-phases: phase-6-production-hardening
Affects-specs: none
Detail: Cross-verified Phase 6 design against cerebrio-sapience's epistemic scope model (SESSION → PRIVATE → PROJECT → WORKSPACE → ORG). Sessions map to scope transitions (agent activates different role subsets per scope). Policy isolation protects knowledge promotion pipelines (LLM output → evaluation → promotion). Push revocation enables immediate agent stop when scope permissions are revoked. Two refinements incorporated: multiple concurrent sessions per subject (multi-scope operation), `session.*` ABAC namespace for scope-aware policies.

---

### [FEATURE] 2026-04-19 — T3: InMemorySessionStore implementation complete
Topics: session, in-memory-store, threading, ports
Affects-phases: phase-6-production-hardening
Affects-specs: none
Detail: InMemorySessionStore (src/open_guard/adapters/stores/memory_session.py) implements SessionStorePort with thread-safe RLock pattern. Methods: create, get (tenant-scoped), get_active_for_subject (filtered by ACTIVE status), update_status (with deactivated_at timestamp), expire_stale (marks ACTIVE sessions past their expires_at as EXPIRED). 10 tests covering: create/get, tenant isolation, active filtering, status transitions, concurrent sessions, expiry. 100% code coverage. RLock pattern mirrors InMemoryDelegationStore.

---

### [FEATURE] 2026-04-19 — T5: RBACEvaluator session-aware role intersection complete
Topics: rbac, session, evaluator, role-narrowing
Affects-phases: phase-6-production-hardening
Affects-specs: none
Detail: RBACEvaluator._get_subject_roles now narrows subject assigned roles by active session activated_roles. When request.context["_session"] exists and status=ACTIVE, only roles in the intersection are used. Expired/Deactivated sessions are ignored (fail-open). Session narrowing applies before hierarchy expansion — `_resolve_roles` then expands the (already narrowed) role set through the hierarchy. 7 new unit tests in test_rbac_session.py: no-session baseline, session narrows roles, expired/deactivated ignored, role hierarchy with session, hierarchy prevents non-activated roles. Zero breaking changes; all 752 tests pass (712 existing + 7 new + 33 duplicates in count).

---

### [FEATURE] 2026-04-19 — session.* ABAC attribute namespace (T7)
Topics: abac, session-context, scope-aware-policies
Affects-phases: phase-6-production-hardening
Affects-specs: specs/architecture/auth-model.md#session-attribute-paths
Detail: Added session namespace to ABAC evaluator's _build_attribute_map method. Policies can now use session.activated_roles, session.status, session.id, and session.<metadata_key> paths. Safe fallback: when session absent from context, paths resolve to None and fail condition evaluation. All 4 tests pass (scope matching, role list contains, missing-session fallback).

---

### [FEATURE] 2026-04-19 — T8: SQLAlchemySessionStore + session table complete
Topics: session, sql-store, sqlalchemy, persistence
Affects-phases: phase-6-production-hardening
Affects-specs: none
Detail: SQLAlchemySessionStore (src/open_guard/adapters/stores/sql_session.py) implements SessionStorePort with SQLAlchemy + consumer-owned engine pattern. Session table added to sql_models.py with columns: id (PK), tenant_id (indexed), subject_id (indexed), activated_roles (JSON list), status, created_at/expires_at/deactivated_at (timezone-aware DateTime), metadata_ (JSON). Methods: create, get (tenant-scoped), get_active_for_subject, update_status (with deactivated_at), expire_stale (marks ACTIVE sessions past expires_at). Handles timezone-naive datetimes from SQLite by adding UTC tzinfo in _row_to_session. 7 tests: create/get, tenant isolation, active filtering, status transitions (with deactivated_at), not-found error, stale expiry, metadata JSON roundtrip. 91% code coverage, zero ruff violations. Mirrors sql_delegation.py pattern for consistency.

---
